# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import importlib
import inspect
import json
import time
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from . import lifecycle, manager_bridge, settings_io, storage
from bpy.props import BoolProperty, StringProperty
_ROOT_PACKAGE = (__package__ or __name__ or '').strip()
_BUNDLED_PACKAGE = _ROOT_PACKAGE
_STANDARD_NPANEL_TOOLS = (('core', 'Smart Cloth Suite Companion'), ('quick_rigid', 'Quick Rigid'), ('jiggle_physics', 'Jiggle Physics'))
_STANDARD_NPANEL_TOOL_NAMES = frozenset((name for name, _friendly in _STANDARD_NPANEL_TOOLS))
_STANDARD_NPANEL_TOOL_LABELS = dict(_STANDARD_NPANEL_TOOLS)
_TOOL_PANEL_META = {'core': {'name_en': 'Smart Cloth Suite', 'name_ja': 'Smart Cloth Suite', 'icon': 'MOD_CLOTH', 'description_en': 'Companion workflow for an externally installed Simply Cloth Studio, adding batch setup, performance preview, adaptive precision, analysis, diagnostics, and safe output.', 'description_ja': '外部インストールされた Simply Cloth Studio と併用し、一括セットアップ、軽量プレビュー、自動精度、解析、診断、安全な出力を追加する連携ワークフローです。'}, 'quick_rigid': {'name_en': 'Quick Rigid', 'name_ja': 'Quick Rigid', 'icon': 'PHYSICS', 'description_en': 'Rigid-body setup, presets, bake/cache tools, and manual shortcut registration information.', 'description_ja': '剛体セットアップ、プリセット、ベイク / キャッシュ、手動ショートカット登録情報です。'}, 'jiggle_physics': {'name_en': 'Jiggle Physics', 'name_ja': 'Jiggle Physics', 'icon': 'ARMATURE_DATA', 'description_en': 'Bone jiggle simulation, runtime callbacks, overlays, wind, profiling, and bake tools.', 'description_ja': 'ボーン揺れ、ランタイムコールバック、オーバーレイ、風、プロファイル、ベイクです。'}}
_RUNTIME_STATE: dict[str, dict[str, object]] = {}
_INTEGRATED_RUNTIME_STATE: dict[str, object] = {}
_PREFERENCES_MODULE = None
_STARTUP_PANEL_GUARD_UNTIL = 0.0
_HELP_POPUP_MODULE = None
_APPLYING_EXTERNAL_NPANEL_STATE = False
_LAST_WINDOW_SCENE_NAMES: dict[int, str] = {}
_SCENE_SWITCH_SUSPENDED = False
_SCENE_MSGBUS_OWNER = object()
_HELP_TOPIC_META = {'suite': ('Smart Cloth Suite Help', 'Smart Cloth Suite ヘルプ', 'MOD_CLOTH'), 'always_on': ('Always-on Toggles Help', '常時機能切り替えヘルプ', 'TIME'), 'companion_integration': ('External Tool Integration Help', '外部ツール連携 ヘルプ', 'LINKED'), 'companion_workflow': ('Smart Workflow Help', 'スマートワークフロー ヘルプ', 'MOD_CLOTH'), 'companion_performance': ('Batch / Performance Help', '一括処理 / パフォーマンス ヘルプ', 'HIDE_OFF'), 'companion_precision': ('Precision / Collision Help', '精度 / 衝突 ヘルプ', 'MOD_PHYSICS'), 'companion_analysis': ('Analysis / Diagnostics Help', '解析 / 診断 ヘルプ', 'VIEWZOOM'), 'companion_output': ('Bake / Output Help', 'ベイク / 出力 ヘルプ', 'OUTPUT'), 'quick_rigid': ('Quick Rigid Help', 'Quick Rigid ヘルプ', 'PHYSICS'), 'jiggle_physics': ('Jiggle Physics Help', 'Jiggle Physics ヘルプ', 'ARMATURE_DATA'), 'quick_rigid_menu': ('Quick Rigid Menu Help', 'Quick Rigid メニュー ヘルプ', 'MENU_PANEL'), 'quick_rigid_setup': ('Rigid Body Setup Help', '剛体セットアップ ヘルプ', 'PHYSICS'), 'quick_rigid_active_body': ('Active Rigid Body Help', 'アクティブ剛体 ヘルプ', 'PHYSICS'), 'quick_rigid_presets': ('Presets / Bake Help', 'プリセット / ベイク ヘルプ', 'PRESET'), 'jiggle_scene': ('Jiggle Scene Settings Help', 'Jiggle シーン設定 ヘルプ', 'SCENE_DATA'), 'jiggle_armature': ('Jiggle Armature Help', 'Jiggle アーマチュア ヘルプ', 'ARMATURE_DATA'), 'jiggle_bone': ('Jiggle Active Bone Help', 'Jiggle アクティブボーン ヘルプ', 'BONE_DATA'), 'jiggle_utilities': ('Jiggle Utilities / Bake / Presets Help', 'Jiggle 補助 / ベイク / プリセット ヘルプ', 'TOOL_SETTINGS')}

def _startup_panel_guard_active() -> bool:
    return False

def _root_is_japanese_locale(context=None) -> bool:
    return _compute_is_japanese_locale(context)

def _compute_is_japanese_locale(context=None) -> bool:
    try:
        view = getattr(getattr(context, 'preferences', None), 'view', None) if context is not None else None
    except Exception:
        view = None
    if view is None:
        try:
            view = getattr(getattr(getattr(bpy, 'context', None), 'preferences', None), 'view', None)
        except Exception:
            view = None
    try:
        use_translate = bool(getattr(view, 'use_translate_interface', True)) if view is not None else True
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
    except Exception:
        return False
    raw = (locale or language).upper()
    return bool(use_translate and any((token in raw for token in ('JA', 'JA_JP', 'JAPANESE', 'JP'))))

def _begin_draw_pass(context=None) -> None:
    del context
    return None

def _end_draw_pass() -> None:
    return None

def _invalidate_runtime_ui_caches() -> None:
    """Compatibility no-op: Panel.draw owns no mutable UI cache."""
    return None

def _root_ui_text(en: str, ja: str, context=None) -> str:
    if context is None:
        return str(en)
    return str(ja if _root_is_japanese_locale(context) else en)
_STABLE_PANEL_MODES = {'OBJECT', 'POSE', 'EDIT_MESH', 'SCULPT', 'PAINT_WEIGHT', 'EDIT_CURVE', 'PAINT_GREASE_PENCIL'}
_UNSAFE_PANEL_MODES = {'EDIT', 'EDIT_ARMATURE', 'EDIT_METABALL', 'EDIT_LATTICE', 'EDIT_TEXT', 'EDIT_GREASE_PENCIL', 'EDIT_GPENCIL', 'SCULPT_CURVES', 'PAINT_TEXTURE', 'PAINT_VERTEX', 'PAINT_GPENCIL', 'VERTEX_GPENCIL', 'WEIGHT_GPENCIL', 'PARTICLE'}

def _safe_context_mode(context=None) -> str:
    try:
        return str(getattr(context, 'mode', '') or '').upper()
    except Exception:
        return ''

def _safe_active_object(context=None):
    try:
        return getattr(context, 'active_object', None)
    except Exception:
        return None

def _safe_area_type(context=None) -> str:
    try:
        return str(getattr(getattr(context, 'area', None), 'type', '') or '').upper()
    except Exception:
        return ''
_SUPPORTED_NPANEL_SPACE_TYPES = frozenset({'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'})

def _main_panel_context_available(context=None) -> bool:
    if context is None:
        return False
    area_type = _safe_area_type(context)
    return bool(area_type in _SUPPORTED_NPANEL_SPACE_TYPES)

def _persistence_context_safe(context=None) -> bool:
    if context is None:
        return False
    try:
        return getattr(context, 'scene', None) is not None
    except Exception:
        return False

def _qualify_module_name(module_name: str) -> str:
    text = str(module_name or '').strip().strip('.')
    if not text:
        return text
    if _ROOT_PACKAGE and (text == _ROOT_PACKAGE or text.startswith(_ROOT_PACKAGE + '.')):
        return text
    return f'{_BUNDLED_PACKAGE}.{text}' if _BUNDLED_PACKAGE else text

def _preferences_module():
    global _PREFERENCES_MODULE
    if _PREFERENCES_MODULE is None:
        _PREFERENCES_MODULE = importlib.import_module('.preferences', _ROOT_PACKAGE or __name__)
    return _PREFERENCES_MODULE

def _manual_import(module_name: str):
    return importlib.import_module(_qualify_module_name(module_name))

def _call_register_without_panels(register_fn) -> None:
    try:
        signature = inspect.signature(register_fn)
        if 'include_ui' in signature.parameters:
            register_fn(include_ui=False)
            return
    except Exception:
        pass
    try:
        register_fn(include_ui=False)
    except TypeError as exc:
        text = str(exc).lower()
        if 'include_ui' not in text and 'unexpected keyword' not in text and ('positional' not in text):
            raise
        register_fn()

def _manual_register(module_name: str):
    module = _manual_import(module_name)
    if bool(getattr(module, '_smart_suite_panelless_registered', False)):
        return module
    register_fn = getattr(module, 'register', None)
    if callable(register_fn):
        _call_register_without_panels(register_fn)
    setattr(module, '_smart_suite_panelless_registered', True)
    return module

def _manual_unregister(module_name: str) -> None:
    state = _RUNTIME_STATE.get(str(module_name), {})
    module = state.get('module') if isinstance(state, dict) else None
    if module is None:
        return
    unregister_fn = getattr(module, 'unregister', None)
    try:
        if callable(unregister_fn):
            unregister_fn()
    finally:
        try:
            setattr(module, '_smart_suite_panelless_registered', False)
        except Exception:
            pass

def _enable_tool(module_name: str, friendly_name: str, *, context=None) -> None:
    global _APPLYING_EXTERNAL_NPANEL_STATE
    saved_state = _read_runtime_state_file()
    previous_applying = bool(_APPLYING_EXTERNAL_NPANEL_STATE)
    _APPLYING_EXTERNAL_NPANEL_STATE = True
    try:
        module = _manual_register(module_name)
    finally:
        _APPLYING_EXTERNAL_NPANEL_STATE = previous_applying
    _RUNTIME_STATE[module_name] = {'friendly_name': friendly_name, 'mode': 'lazy-panelless-startup-safe', 'module': module, 'qualified_name': _qualify_module_name(module_name)}
    try:
        _apply_saved_npanel_settings_for_module(context, module_name, saved_state=saved_state)
    except Exception:
        pass
    try:
        _sync_always_on_preferences_for_loaded_module(context, module_name)
    except Exception:
        pass

def _disable_tool(module_name: str) -> None:
    try:
        _manual_unregister(module_name)
    finally:
        _RUNTIME_STATE.pop(module_name, None)

def _tool_loaded(module_name: str) -> bool:
    state = _RUNTIME_STATE.get(module_name, {}) if isinstance(_RUNTIME_STATE, dict) else {}
    return bool(state and state.get('module') is not None)

def _suite_core_runtime_loaded() -> bool:
    return all((_tool_loaded(module_name) for module_name, _friendly_name in _STANDARD_NPANEL_TOOLS))

def _suite_runtime_loaded() -> bool:
    return _suite_core_runtime_loaded()

def _tool_meta(module_name: str) -> dict[str, str]:
    return dict(_TOOL_PANEL_META.get(str(module_name or ''), {}))

def _tool_icon(module_name: str) -> str:
    return str(_tool_meta(module_name).get('icon') or 'PLUGIN')

def _tool_display_name(module_name: str, context=None) -> str:
    meta = _tool_meta(module_name)
    fallback = _STANDARD_NPANEL_TOOL_LABELS.get(module_name, module_name)
    return _root_ui_text(str(meta.get('name_en') or fallback), str(meta.get('name_ja') or fallback), context)

def _tool_description(module_name: str, context=None) -> str:
    meta = _tool_meta(module_name)
    return _root_ui_text(str(meta.get('description_en') or ''), str(meta.get('description_ja') or ''), context)

def _help_topic_title(topic: str, context=None) -> str:
    meta = _HELP_TOPIC_META.get(str(topic or '').strip(), _HELP_TOPIC_META['suite'])
    return _root_ui_text(str(meta[0]), str(meta[1]), context)

def _help_topic_icon(topic: str) -> str:
    meta = _HELP_TOPIC_META.get(str(topic or '').strip(), _HELP_TOPIC_META['suite'])
    return str(meta[2] or 'HELP')

def _help_button(layout, context, topic: str):
    help_layout = layout
    try:
        help_layout = layout.row(align=True)
        help_layout.scale_x = 0.82
        help_layout.scale_y = 1.0
    except Exception:
        help_layout = layout
    previous_context = getattr(help_layout, 'operator_context', None)
    try:
        try:
            help_layout.operator_context = 'INVOKE_DEFAULT'
        except Exception:
            pass
        icon_value = _scsmart_icon_id('help')
        try:
            if icon_value:
                op = help_layout.operator('smart_core.show_help_popup', text='', icon_value=icon_value)
            else:
                op = help_layout.operator('smart_core.show_help_popup', text='', icon='QUESTION')
        except TypeError:
            if icon_value:
                op = help_layout.operator('smart_core.show_help_popup', text='', icon_value=icon_value)
            else:
                op = help_layout.operator('smart_core.show_help_popup', text='', icon='QUESTION')
        op.topic = str(topic or 'suite')
        return op
    except Exception:
        return None
    finally:
        if previous_context is not None:
            try:
                help_layout.operator_context = previous_context
            except Exception:
                pass

def _section_header(layout, context, label_en: str, label_ja: str, *, icon: str='NONE', topic: str='suite'):
    row = layout.row(align=True)
    try:
        row.label(text=_root_ui_text(label_en, label_ja, context), icon=icon)
    except Exception:
        row.label(text=_root_ui_text(label_en, label_ja, context))
    _help_button(row, context, topic)
    return row

class _NullOperator:

    def __setattr__(self, name, value):
        try:
            object.__setattr__(self, name, value)
        except Exception:
            pass

    def __getattr__(self, name):
        return self

    def __call__(self, *args, **kwargs):
        return self

class _NullUILayout:
    """No-op layout used for collapsed sections.

    Blender UI code below can stay simple: every section draws into the returned
    layout, and when the section is closed this object discards child rows,
    operators, properties, and menus without touching Blender RNA/UI state.
    """

    def __init__(self):
        self.enabled = True
        self.alert = False
        self.active = True
        self.alignment = 'EXPAND'
        self.scale_x = 1.0
        self.scale_y = 1.0
        self.use_property_split = False
        self.use_property_decorate = False
        self.operator_context = 'INVOKE_DEFAULT'

    def __getattr__(self, name):
        return self

    def __call__(self, *args, **kwargs):
        return self

    def row(self, *args, **kwargs):
        return self

    def column(self, *args, **kwargs):
        return self

    def box(self, *args, **kwargs):
        return self

    def split(self, *args, **kwargs):
        return self

    def grid_flow(self, *args, **kwargs):
        return self

    def label(self, *args, **kwargs):
        return None

    def prop(self, *args, **kwargs):
        return None

    def operator(self, *args, **kwargs):
        return _NullOperator()

    def menu(self, *args, **kwargs):
        return None

    def separator(self, *args, **kwargs):
        return None
_NULL_LAYOUT = _NullUILayout()
_UI_SECTION_DEFAULTS = {'show_always_on_toggles': False, 'show_displayed_tool_modules': False, 'ui_open_scs_external': False, 'ui_open_scs_workflow': False, 'ui_open_scs_performance': False, 'ui_open_scs_precision': False, 'ui_open_scs_analysis': False, 'ui_open_scs_output': False, 'ui_open_tool_quick_rigid': False, 'ui_open_tool_jiggle_physics': False, 'ui_open_quick_rigid_all_commands': False, 'ui_open_jiggle_all_commands': False, 'ui_open_quick_rigid_menu': False, 'ui_open_quick_rigid_setup': False, 'ui_open_quick_rigid_active_body': False, 'ui_open_quick_rigid_presets': False, 'ui_open_jiggle_scene': False, 'ui_open_jiggle_utilities': False, 'ui_open_jiggle_armature': False, 'ui_open_jiggle_bone': False}
_RUNTIME_UI_SECTION_STATES: dict[str, bool] = {}

def _ui_section_state_get(context, section_key: str, default: bool | None=None) -> bool:
    """Pure read used from Panel.draw; no caches, I/O, or RNA writes."""
    key = str(section_key or '').strip()
    if not key:
        return bool(default)
    fallback = _UI_SECTION_DEFAULTS.get(key, False if default is None else bool(default))
    prefs = _root_preferences(context)
    if prefs is not None and hasattr(prefs, key):
        try:
            value = getattr(prefs, key)
            return value if type(value) is bool else bool(fallback)
        except Exception:
            pass
    return bool(_RUNTIME_UI_SECTION_STATES.get(key, fallback))

def _ui_section_state_set(context, section_key: str, value: bool) -> bool:
    key = str(section_key or '').strip()
    if not key:
        return False
    desired = bool(value)
    _RUNTIME_UI_SECTION_STATES[key] = desired
    if _set_pref_bool(context, key, desired, save=True):
        return True
    return True

def _tag_view3d_redraw(context=None) -> None:
    try:
        screen = getattr(context, 'screen', None) or getattr(getattr(bpy, 'context', None), 'screen', None)
        for area in list(getattr(screen, 'areas', ()) or ()):
            try:
                area.tag_redraw()
            except Exception:
                pass
    except Exception:
        pass

def _section_toggle_button(layout, section_key: str, label: str, icon: str, expanded: bool, *, icon_only: bool=False):
    try:
        if icon_only:
            op = layout.operator('smart_core.toggle_ui_section', text='', icon=icon, emboss=True, depress=bool(expanded))
        else:
            op = layout.operator('smart_core.toggle_ui_section', text=label, icon=icon, emboss=False, depress=bool(expanded))
    except TypeError:
        op = layout.operator('smart_core.toggle_ui_section', text='' if icon_only else label, icon=icon)
    try:
        op.section_key = str(section_key or '')
        op.label = str(label or '')
    except Exception:
        pass
    return op

def _begin_collapsible_section(layout, context, section_key: str, label_en: str, label_ja: str, *, icon: str='NONE', topic: str='suite', default: bool | None=None, container=None, defer_body: bool=False):
    """Draw a Smart Modeling-style collapsible section and return its body layout.

    Header format: disclosure button, icon+section-name button, then a compact
    help icon button.  The open body never repeats the section title.
    """
    key = str(section_key or '').strip()
    label = _root_ui_text(label_en, label_ja, context)
    expanded = _ui_section_state_get(context, key, _UI_SECTION_DEFAULTS.get(key, default if default is not None else False))
    box = container if container is not None else layout.box()
    try:
        box.use_property_split = False
        box.use_property_decorate = False
    except Exception:
        pass
    row = box.row(align=True)
    try:
        row.use_property_split = False
        row.use_property_decorate = False
    except Exception:
        pass
    _section_toggle_button(row, key, label, 'TRIA_DOWN' if expanded else 'TRIA_RIGHT', expanded, icon_only=True)
    _section_toggle_button(row, key, label, icon or 'TOOL_SETTINGS', expanded, icon_only=False)
    try:
        row.separator(factor=0.35)
    except Exception:
        try:
            row.separator()
        except Exception:
            pass
    _help_button(row, context, topic)
    if not expanded:
        return _NULL_LAYOUT
    if defer_body:
        return box
    body = box.column(align=True)
    try:
        body.use_property_split = False
        body.use_property_decorate = False
    except Exception:
        pass
    return body

def _begin_child_collapsible_section(layout, context, section_key: str, label_en: str, label_ja: str, *, icon: str='NONE', topic: str='suite', default: bool | None=None):
    """Draw a non-top-level section using Blender's standard disclosure UI.

    Top-level groups keep the Smart Modeling-style header. Child groups use
    Blender's built-in panel disclosure when available, so the left side is the
    standard compact ">" / expanded arrow instead of the custom two-button
    section header.
    """
    key = str(section_key or '').strip()
    label = _root_ui_text(label_en, label_ja, context)
    expanded = _ui_section_state_get(context, key, _UI_SECTION_DEFAULTS.get(key, default if default is not None else False))
    prefs = _root_preferences(context)
    del icon
    row = layout.row(align=True)
    try:
        row.use_property_split = False
        row.use_property_decorate = False
    except Exception:
        pass
    try:
        if prefs is not None and key and hasattr(prefs, key):
            row.prop(prefs, key, text=label, icon='DOWNARROW_HLT' if expanded else 'RIGHTARROW', emboss=False)
        else:
            op = row.operator('smart_core.toggle_ui_section', text=label, icon='DOWNARROW_HLT' if expanded else 'RIGHTARROW', emboss=False)
            op.section_key = key
            op.label = label
    except Exception:
        try:
            row.label(text=label, icon='DOWNARROW_HLT' if expanded else 'RIGHTARROW')
        except Exception:
            pass
    _help_button(row, context, topic)
    if not expanded:
        return _NULL_LAYOUT
    body = layout.column(align=True)
    try:
        body.use_property_split = False
        body.use_property_decorate = False
    except Exception:
        pass
    return body

def _load_help_popup_module():
    global _HELP_POPUP_MODULE
    if _HELP_POPUP_MODULE is None:
        _HELP_POPUP_MODULE = importlib.import_module('.help', _ROOT_PACKAGE or __name__)
    return _HELP_POPUP_MODULE

def _wrap_lines(layout, text: str, *, context=None, width: int=82, icon: str='NONE') -> None:
    try:
        import textwrap
        cleaned = str(text or '').strip()
        if not cleaned:
            return
        lines = textwrap.wrap(cleaned, width=max(24, int(width))) or [cleaned]
        first = True
        for line in lines:
            layout.label(text=line, icon=icon if first else 'NONE')
            first = False
    except Exception:
        try:
            layout.label(text=str(text or ''), icon=icon)
        except Exception:
            pass

def _safe_label(layout, text: str, *, icon: str='NONE') -> None:
    if layout is _NULL_LAYOUT:
        return
    try:
        layout.label(text=str(text or ''), icon=icon)
    except Exception:
        pass

def _scsmart_icon_id(icon_name: str) -> int:
    del icon_name
    return 0
SCSMART_ICON_BUTTON_SCALE = 2.0

def _boost_icon_layout(layout, scale: float=SCSMART_ICON_BUTTON_SCALE) -> None:
    try:
        current = float(getattr(layout, 'scale_y', 1.0) or 1.0)
        layout.scale_y = max(current, float(scale))
    except Exception:
        pass

def _safe_label_icon(layout, text: str, *, icon: str='NONE', custom_icon: str='') -> None:
    if layout is _NULL_LAYOUT:
        return
    try:
        icon_value = _scsmart_icon_id(custom_icon) if custom_icon else 0
        if icon_value:
            layout.label(text=str(text or ''), icon_value=icon_value)
        else:
            layout.label(text=str(text or ''), icon=icon)
    except Exception:
        _safe_label(layout, text, icon=icon)

def _safe_operator(layout, operator_id: str, text: str, *, icon: str='NONE', icon_value: int=0, **props) -> None:
    if layout is _NULL_LAYOUT:
        return
    emboss = bool(props.pop('_emboss', True))
    try:
        try:
            if int(icon_value or 0):
                op = layout.operator(operator_id, text=text, icon_value=int(icon_value or 0), emboss=emboss)
            else:
                op = layout.operator(operator_id, text=text, icon=icon, emboss=emboss)
        except TypeError:
            if int(icon_value or 0):
                op = layout.operator(operator_id, text=text, icon_value=int(icon_value or 0))
            else:
                op = layout.operator(operator_id, text=text, icon=icon)
        for key, value in props.items():
            try:
                setattr(op, key, value)
            except Exception:
                pass
    except Exception:
        try:
            layout.label(text=text, icon='ERROR')
        except Exception:
            pass

def _safe_operator_icon(layout, operator_id: str, text: str, *, icon: str='NONE', custom_icon: str='', **props) -> None:
    if layout is _NULL_LAYOUT:
        return
    icon_value = _scsmart_icon_id(custom_icon) if custom_icon else 0
    if custom_icon:
        _boost_icon_layout(layout)
    _safe_operator(layout, operator_id, text, icon=icon, icon_value=icon_value, _emboss=True, **props)

def _safe_operator_big_icon(layout, operator_id: str, *, icon: str='NONE', custom_icon: str='', **props) -> None:
    if layout is _NULL_LAYOUT:
        return
    icon_value = _scsmart_icon_id(custom_icon) if custom_icon else 0
    _safe_operator(layout, operator_id, '', icon=icon, icon_value=icon_value, _emboss=True, **props)

def _draw_scsmart_command_ribbon(layout, context, commands) -> None:
    try:
        grid = layout.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=True, align=True)
    except Exception:
        grid = layout
    for operator_id, label_en, label_ja, icon, custom_icon in commands:
        try:
            cell = grid.column(align=True)
        except Exception:
            cell = grid.row(align=True)
        button = cell.row(align=True)
        button.scale_y = 3.75
        _safe_operator_big_icon(button, operator_id, icon=icon, custom_icon=custom_icon)
        caption = cell.row(align=True)
        try:
            caption.alignment = 'CENTER'
        except Exception:
            pass
        caption.scale_y = 0.68
        caption.label(text=_root_ui_text(label_en, label_ja, context))

def _clamp_float(value: float, low: float, high: float) -> float:
    return max(low, min(high, float(value)))


def _score_bar_text(label: str, value: float, *, invert: bool=False) -> str:
    try:
        v = _clamp_float(float(value), 0.0, 100.0)
    except Exception:
        v = 0.0
    filled = max(0, min(10, int(round(v / 10.0))))
    if invert:
        filled = 10 - filled
    return f"{label} [{'█' * filled}{'·' * (10 - filled)}] {v:.1f}"

def _safe_prop(layout, data, identifier: str, *, text: str | None=None, toggle: bool=False, **kwargs) -> None:
    if layout is _NULL_LAYOUT:
        return
    if data is None:
        return
    try:
        if text is None:
            layout.prop(data, identifier, toggle=toggle, **kwargs)
        else:
            layout.prop(data, identifier, text=text, toggle=toggle, **kwargs)
    except Exception:
        pass

def _scene(context=None):
    scene = getattr(context, 'scene', None) if context is not None else None
    if scene is None:
        scene = getattr(getattr(bpy, 'context', None), 'scene', None)
    return scene

def _pcw_settings(context=None):
    scene = _scene(context)
    return getattr(scene, 'pcw', None) if scene is not None else None

def _scsmart_settings(context=None):
    scene = _scene(context)
    return getattr(scene, 'scsmart', None) if scene is not None else None

def _quick_rigid_settings(context=None):
    scene = _scene(context)
    return getattr(scene, 'quick_rigid_settings', None) if scene is not None else None

def _quick_rigid_presets(context=None):
    scene = _scene(context)
    return getattr(scene, 'rigid_body_presets', None) if scene is not None else None

def _jiggle_settings(context=None):
    scene = _scene(context)
    return getattr(scene, 'jiggle', None) if scene is not None else None

def _root_preferences_uncached(context=None):
    """Pure read of the already-registered preferences module for Panel.draw."""
    module = _PREFERENCES_MODULE
    if module is None:
        return None
    try:
        peek = getattr(module, 'peek_root_preferences', None)
        return peek(context) if callable(peek) else None
    except Exception:
        return None

def _root_preferences(context=None):
    return _root_preferences_uncached(context)

def _save_root_preferences(context=None, *, force: bool=False) -> bool:
    if not bool(force) and (not _suite_npanel_persistence_enabled(context)):
        return False
    try:
        module = _preferences_module()
        saver = getattr(module, 'save_runtime_settings', None)
        if callable(saver):
            return bool(saver(context))
    except Exception:
        pass
    return False

def _pref_bool(context, attr_name: str, default: bool=False) -> bool:
    prefs = _root_preferences(context)
    if prefs is None:
        return bool(default)
    try:
        value = getattr(prefs, str(attr_name or '').strip(), default)
        return value if type(value) is bool else bool(default)
    except Exception:
        return bool(default)

def _suite_npanel_persistence_enabled(context=None) -> bool:
    return _pref_bool(context, 'always_suite_npanel_persistence', True)

def _should_save_runtime_preference_change(context=None, attr_name: str='', *, force: bool=False) -> bool:
    if bool(force):
        return True
    if str(attr_name or '').strip() == 'always_suite_npanel_persistence':
        return True
    return _suite_npanel_persistence_enabled(context)

def _set_pref_bool(context, attr_name: str, value: bool, *, save: bool=True) -> bool:
    prefs = _root_preferences(context)
    if prefs is None or not hasattr(prefs, attr_name):
        return False
    desired = bool(value)
    try:
        current = bool(getattr(prefs, attr_name))
    except Exception:
        current = None
    try:
        if current is not desired:
            setattr(prefs, attr_name, desired)
        if save and _should_save_runtime_preference_change(context, attr_name):
            _save_root_preferences(context, force=str(attr_name or '').strip() == 'always_suite_npanel_persistence')
        return True
    except Exception:
        return False

def _module_visibility_pref(module_name: str) -> str:
    mapping = {'quick_rigid': 'show_quick_rigid_tools', 'jiggle_physics': 'show_jiggle_physics_tools'}
    return mapping.get(str(module_name or ''), '')

def _module_visible(module_name: str, context=None) -> bool:
    attr = _module_visibility_pref(module_name)
    if not attr:
        return True
    return _pref_bool(context, attr, True)

def _runtime_state_path() -> Path:
    getter = getattr(storage, 'smart_suite_config_file', None)
    if callable(getter):
        return getter(create_parent=False)
    return storage.user_data_file('smart_suite', 'settings', 'Smart_Cloth_Suite', 'Smart_Cloth_Suite.json', create_parent=False)
_LAST_NPANEL_STATE_FINGERPRINT = ''
_LAST_NPANEL_STATE_CACHE: dict[str, object] | None = None
_LAST_NPANEL_STATE_PATH = ''
_LAST_NPANEL_STATE_MTIME = 0.0
_RESTORED_SCENE_KEYS: dict[str, str] = {}
_RESTORED_SCENE_KEY_LIMIT = 256
_LAST_PERSIST_TIME = 0.0
_SCENE_STATE_EXTERNAL_RESTORE_BLOCKLIST = {'quick_rigid_scene_physics', 'quick_rigid_objects', 'jiggle_named_state'}
_SCENE_SETTING_KEYS_SAFE_FOR_EXTERNAL_RESTORE: set[str] = {'smart_cloth_suite_companion', 'quick_rigid_settings', 'jiggle'}
# These change what the next bake does to the user's action, so they stay with the scene they were set on.
_SCENE_SETTING_PROPS_NOT_CARRIED: dict[str, set[str]] = {'jiggle': {'bake_overwrite', 'bake_nla'}}

def _read_runtime_state_file() -> dict:
    global _LAST_NPANEL_STATE_CACHE, _LAST_NPANEL_STATE_FINGERPRINT, _LAST_NPANEL_STATE_PATH, _LAST_NPANEL_STATE_MTIME
    path = _runtime_state_path()
    result = settings_io.read_document(path, recover=True)
    if result.document is None:
        if result.status == 'CORRUPT' and isinstance(_LAST_NPANEL_STATE_CACHE, dict):
            return dict(_LAST_NPANEL_STATE_CACHE)
        return {}
    data = dict(result.document)
    if data.get('schema') != settings_io.DOCUMENT_SCHEMA:
        settings_io.mark_dirty()
        return dict(_LAST_NPANEL_STATE_CACHE or {})
    _LAST_NPANEL_STATE_CACHE = data
    _LAST_NPANEL_STATE_PATH = str(path)
    try:
        _LAST_NPANEL_STATE_MTIME = float(path.stat().st_mtime or 0.0)
    except Exception:
        _LAST_NPANEL_STATE_MTIME = 0.0
    try:
        _LAST_NPANEL_STATE_FINGERPRINT = settings_io.serialize_document(data).decode('utf-8')
    except Exception:
        _LAST_NPANEL_STATE_FINGERPRINT = ''
    return dict(data)

def _write_runtime_state_file(data: dict) -> bool:
    global _LAST_NPANEL_STATE_FINGERPRINT, _LAST_NPANEL_STATE_CACHE, _LAST_NPANEL_STATE_PATH, _LAST_NPANEL_STATE_MTIME
    payload_data = dict(data or {})
    payload_data['schema'] = settings_io.DOCUMENT_SCHEMA
    try:
        serialized = settings_io.serialize_document(payload_data).decode('utf-8')
    except Exception:
        settings_io.mark_dirty()
        return False
    if serialized == _LAST_NPANEL_STATE_FINGERPRINT:
        return True
    path = _runtime_state_path()
    if not settings_io.write_document(path, payload_data, allow_create=True):
        return False
    _LAST_NPANEL_STATE_FINGERPRINT = serialized
    _LAST_NPANEL_STATE_CACHE = dict(payload_data)
    _LAST_NPANEL_STATE_PATH = str(path)
    try:
        _LAST_NPANEL_STATE_MTIME = float(path.stat().st_mtime or 0.0)
    except Exception:
        _LAST_NPANEL_STATE_MTIME = 0.0
    return True

def _saved_scene_settings_fingerprint() -> str:
    try:
        data = _read_runtime_state_file().get('scene_settings', {})
        if not isinstance(data, dict):
            data = {}
        safe = {str(key): value for key, value in data.items() if str(key) in _SCENE_SETTING_KEYS_SAFE_FOR_EXTERNAL_RESTORE}
        return json.dumps(safe, ensure_ascii=False, sort_keys=True, default=str)
    except Exception:
        return ''
_TRANSIENT_NPANEL_PROPERTY_IDENTIFIERS = {'rna_type', 'name', 'last_report_path', 'last_status', 'lastframe'}

def _serialize_rna_simple_properties(owner) -> dict[str, object]:
    if owner is None:
        return {}
    rna = getattr(owner, 'bl_rna', None)
    props = getattr(rna, 'properties', ()) if rna is not None else ()
    data: dict[str, object] = {}
    for prop in props:
        identifier = str(getattr(prop, 'identifier', '') or '')
        if not identifier or identifier in _TRANSIENT_NPANEL_PROPERTY_IDENTIFIERS:
            continue
        if bool(getattr(prop, 'is_readonly', False)):
            continue
        prop_type = str(getattr(prop, 'type', '') or '').upper()
        try:
            value = getattr(owner, identifier)
        except Exception:
            continue
        try:
            if prop_type in {'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM'}:
                if isinstance(value, (bool, int, float, str)) or value is None:
                    data[identifier] = value
                elif hasattr(value, '__len__') and (not isinstance(value, (bytes, bytearray))):
                    seq = list(value)
                    if all((isinstance(item, (bool, int, float, str)) for item in seq)):
                        data[identifier] = seq
            elif prop_type == 'POINTER':
                name = str(getattr(value, 'name', '') or '') if value is not None else ''
                if name:
                    fixed_type = getattr(getattr(prop, 'fixed_type', None), 'identifier', '') or type(value).__name__
                    data[identifier] = {'__pointer__': str(fixed_type), 'name': name}
                else:
                    data[identifier] = {'__pointer__': '', 'name': ''}
        except Exception:
            continue
    return data

def _resolve_saved_pointer(value):
    if not isinstance(value, dict) or '__pointer__' not in value:
        return None
    name = str(value.get('name') or '')
    if not name:
        return None
    pointer_type = str(value.get('__pointer__') or '').lower()
    try:
        if 'collection' in pointer_type:
            return bpy.data.collections.get(name)
        if 'object' in pointer_type or pointer_type in {'mesh', 'armature', 'curve'}:
            return bpy.data.objects.get(name)
        if 'material' in pointer_type:
            return bpy.data.materials.get(name)
    except Exception:
        return None
    return None

def _apply_rna_simple_properties(owner, values: dict[str, object] | None) -> None:
    if owner is None or not isinstance(values, dict):
        return
    rna = getattr(owner, 'bl_rna', None)
    props = getattr(rna, 'properties', ()) if rna is not None else ()
    writable: dict[str, str] = {}
    for prop in props:
        identifier = str(getattr(prop, 'identifier', '') or '')
        if not identifier or identifier in _TRANSIENT_NPANEL_PROPERTY_IDENTIFIERS or bool(getattr(prop, 'is_readonly', False)):
            continue
        prop_type = str(getattr(prop, 'type', '') or '').upper()
        if prop_type in {'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM', 'POINTER'}:
            writable[identifier] = prop_type
    for identifier, value in values.items():
        key = str(identifier)
        prop_type = writable.get(key)
        if prop_type is None:
            continue
        valid = False
        converted = value
        if prop_type == 'BOOLEAN':
            valid = type(value) is bool
        elif prop_type == 'INT':
            valid = type(value) is int
        elif prop_type == 'FLOAT':
            valid = type(value) in {int, float} and (not isinstance(value, bool))
            converted = float(value) if valid else value
        elif prop_type in {'STRING', 'ENUM'}:
            valid = isinstance(value, str)
        elif prop_type == 'POINTER':
            valid = isinstance(value, dict) and type(value.get('__pointer__', '')) is str and (type(value.get('name', '')) is str)
            converted = _resolve_saved_pointer(value) if valid else None
            if valid and value.get('name') and (converted is None):
                continue
        if not valid:
            continue
        try:
            setattr(owner, key, converted)
        except Exception:
            continue

def _scene_settings_snapshot(scene) -> dict[str, object]:
    if bool(_APPLYING_EXTERNAL_NPANEL_STATE) or scene is None:
        return {}
    roots = {'smart_cloth_suite_companion': getattr(scene, 'smart_cloth_suite_companion', None), 'quick_rigid_settings': getattr(scene, 'quick_rigid_settings', None), 'jiggle': getattr(scene, 'jiggle', None)}
    payload: dict[str, object] = {}
    for key, owner in roots.items():
        if key not in _SCENE_SETTING_KEYS_SAFE_FOR_EXTERNAL_RESTORE or owner is None:
            continue
        try:
            data = _serialize_rna_simple_properties(owner)
        except Exception:
            data = {}
        for name in _SCENE_SETTING_PROPS_NOT_CARRIED.get(key, ()):
            data.pop(name, None)
        if data:
            payload[key] = data
    return payload

def _current_scene_settings_snapshot(context=None) -> dict[str, object]:
    if bool(_APPLYING_EXTERNAL_NPANEL_STATE):
        return {}
    ctx = context or getattr(bpy, 'context', None)
    if not _persistence_context_safe(ctx):
        return {}
    return _scene_settings_snapshot(_scene(ctx))

def _merge_scene_snapshot_into_runtime_state(snapshot: dict[str, object], *, preserve_unresolved_pointers: bool=False, preserve_existing_named_pointers: bool=False) -> bool:
    state = _read_runtime_state_file()
    state['version'] = 283
    state['file'] = 'Smart_Cloth_Suite.json'
    existing = state.get('scene_settings', {})
    scene_settings = dict(existing) if isinstance(existing, dict) else {}
    for blocked in _SCENE_STATE_EXTERNAL_RESTORE_BLOCKLIST:
        scene_settings.pop(str(blocked), None)
    for key in list(scene_settings.keys()):
        if str(key) not in _SCENE_SETTING_KEYS_SAFE_FOR_EXTERNAL_RESTORE:
            scene_settings.pop(key, None)
    for key, value in dict(snapshot or {}).items():
        key = str(key)
        if key not in _SCENE_SETTING_KEYS_SAFE_FOR_EXTERNAL_RESTORE:
            continue
        incoming = dict(value) if isinstance(value, dict) else value
        if preserve_unresolved_pointers and isinstance(incoming, dict):
            previous = scene_settings.get(key)
            previous = previous if isinstance(previous, dict) else {}
            for prop_name, prop_value in tuple(incoming.items()):
                if not isinstance(prop_value, dict) or '__pointer__' not in prop_value or prop_value.get('name'):
                    continue
                saved_value = previous.get(prop_name)
                if not isinstance(saved_value, dict) or not saved_value.get('name'):
                    continue
                if preserve_existing_named_pointers or _resolve_saved_pointer(saved_value) is None:
                    incoming[prop_name] = saved_value
        scene_settings[key] = incoming
    state['scene_settings'] = scene_settings
    return _write_runtime_state_file(state)

def _save_npanel_runtime_state(context=None, *, force: bool=False) -> bool:
    if bool(_APPLYING_EXTERNAL_NPANEL_STATE):
        return True
    if not bool(force) and (not _suite_npanel_persistence_enabled(context)):
        return True
    return _merge_scene_snapshot_into_runtime_state(_current_scene_settings_snapshot(context))

def _save_scene_npanel_runtime_state(scene, context=None, *, force: bool=False) -> bool:
    if bool(_APPLYING_EXTERNAL_NPANEL_STATE):
        return True
    if not bool(force) and (not _suite_npanel_persistence_enabled(context)):
        return True
    return _merge_scene_snapshot_into_runtime_state(_scene_settings_snapshot(scene))

def _scene_setting_keys_for_module(module_name: str='') -> tuple[str, ...]:
    module_name = str(module_name or '').strip()
    mapping = {'core': ('smart_cloth_suite_companion',), 'quick_rigid': ('quick_rigid_settings',), 'jiggle_physics': ('jiggle',)}
    if module_name:
        return mapping.get(module_name, ())
    return ('smart_cloth_suite_companion', 'quick_rigid_settings', 'jiggle')

def _apply_saved_npanel_settings_to_scene(scene, module_name: str='', saved_state: dict | None=None) -> None:
    global _APPLYING_EXTERNAL_NPANEL_STATE
    if scene is None:
        return None
    state = dict(saved_state) if isinstance(saved_state, dict) else _read_runtime_state_file()
    scene_settings = state.get('scene_settings', {})
    if not isinstance(scene_settings, dict) or not scene_settings:
        return None
    keys = _scene_setting_keys_for_module(module_name)
    if not keys:
        return None
    previous_applying = bool(_APPLYING_EXTERNAL_NPANEL_STATE)
    _APPLYING_EXTERNAL_NPANEL_STATE = True
    try:
        for key in keys:
            if key not in _SCENE_SETTING_KEYS_SAFE_FOR_EXTERNAL_RESTORE:
                continue
            values = scene_settings.get(key)
            if not isinstance(values, dict):
                continue
            owner = getattr(scene, key, None)
            if owner is None:
                continue
            not_carried = _SCENE_SETTING_PROPS_NOT_CARRIED.get(key, ())
            _apply_rna_simple_properties(owner, {name: value for name, value in values.items() if name not in not_carried})
    finally:
        _APPLYING_EXTERNAL_NPANEL_STATE = previous_applying
    return None

def _apply_saved_npanel_settings_for_module(context=None, module_name: str='', saved_state: dict | None=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    if not _persistence_context_safe(ctx):
        return None
    return _apply_saved_npanel_settings_to_scene(_scene(ctx), module_name, saved_state)

def _scene_restore_key(context=None) -> str:
    scene = _scene(context)
    if scene is None:
        return ''
    try:
        return str(scene.as_pointer())
    except Exception:
        return str(getattr(scene, 'name_full', '') or getattr(scene, 'name', '') or '')

def _prune_restored_scene_keys(keep_key: str='') -> None:
    """Bound the per-scene restore fingerprint cache to live scene IDs."""
    live_keys: set[str] = set()
    try:
        for scene in getattr(getattr(bpy, 'data', None), 'scenes', ()) or ():
            try:
                live_keys.add(str(scene.as_pointer()))
            except Exception:
                pass
            try:
                live_keys.add(str(getattr(scene, 'name_full', '') or getattr(scene, 'name', '') or ''))
            except Exception:
                pass
    except Exception:
        live_keys = set()
    if live_keys:
        for key in tuple(_RESTORED_SCENE_KEYS):
            if key != keep_key and key not in live_keys:
                _RESTORED_SCENE_KEYS.pop(key, None)
    while len(_RESTORED_SCENE_KEYS) > _RESTORED_SCENE_KEY_LIMIT:
        oldest = next(iter(_RESTORED_SCENE_KEYS), '')
        if not oldest:
            break
        if oldest == keep_key and len(_RESTORED_SCENE_KEYS) > 1:
            _RESTORED_SCENE_KEYS[oldest] = _RESTORED_SCENE_KEYS.pop(oldest)
            oldest = next(iter(_RESTORED_SCENE_KEYS), '')
        if not oldest:
            break
        _RESTORED_SCENE_KEYS.pop(oldest, None)

def _ensure_scene_npanel_settings_restored(context=None) -> None:
    key = _scene_restore_key(context)
    if not key:
        return
    fingerprint = _saved_scene_settings_fingerprint()
    if _RESTORED_SCENE_KEYS.get(key) == fingerprint:
        return
    _apply_saved_npanel_settings_for_module(context, '')
    _RESTORED_SCENE_KEYS[key] = fingerprint
    _prune_restored_scene_keys(key)

def _persist_npanel_runtime_state(context=None, *, force: bool=False) -> bool:
    global _LAST_PERSIST_TIME
    if bool(_APPLYING_EXTERNAL_NPANEL_STATE):
        return True
    if not bool(force) and (not _suite_npanel_persistence_enabled(context)):
        return True
    try:
        _LAST_PERSIST_TIME = time.monotonic()
    except Exception:
        _LAST_PERSIST_TIME = 0.0
    preferences_ok = _save_root_preferences(context, force=force)
    scene_ok = _save_npanel_runtime_state(context, force=force)
    if not (preferences_ok and scene_ok):
        settings_io.mark_dirty()
    return bool(preferences_ok and scene_ok)

def _jiggle_module():
    state = _RUNTIME_STATE.get('jiggle_physics', {})
    return state.get('module') if isinstance(state, dict) else None

def _find_view3d_area(context=None):
    try:
        area = getattr(context, 'area', None)
        if area is not None and getattr(area, 'type', None) == 'VIEW_3D':
            return area
    except Exception:
        pass
    try:
        screen = getattr(getattr(context, 'window', None), 'screen', None) or getattr(getattr(bpy, 'context', None), 'screen', None)
        for area in getattr(screen, 'areas', ()) or ():
            if getattr(area, 'type', None) == 'VIEW_3D':
                return area
    except Exception:
        pass
    return None

def _jiggle_overlay_state(context=None, *, create: bool=False):
    module = _jiggle_module()
    globals_obj = getattr(module, '_jiggle_globals', None) if module is not None else None
    if globals_obj is None:
        return None
    area = _find_view3d_area(context)
    if area is None:
        return None
    try:
        getter = globals_obj.get_area_overlay_properties if create else globals_obj.peek_area_overlay_properties
        return getter(area)
    except Exception:
        return None

def _disable_quick_rigid_always_on_features(context=None) -> None:
    return None

def _disable_jiggle_always_on_features(context=None) -> None:
    module = _jiggle_module()
    globals_obj = getattr(module, '_jiggle_globals', None) if module is not None else None
    if globals_obj is not None:
        try:
            for area_props in list(getattr(globals_obj, 'area_overlays', {}).values()):
                try:
                    area_props.overlay_pose = False
                    area_props.overlay_simulation = False
                except Exception:
                    pass
        except Exception:
            pass
        try:
            globals_obj.update_overlay_draw_handler()
        except Exception:
            pass
    remove = getattr(module, '_remove_runtime_handlers', None) if module is not None else None
    if callable(remove):
        try:
            remove()
        except Exception:
            pass

def _disable_all_always_on_features(context=None) -> None:
    for spec in _ALWAYS_ON_SPECS:
        if str(spec.get('key') or '') == 'suite_npanel_persistence':
            continue
        pref_name = str(spec.get('pref') or '')
        if pref_name:
            _set_pref_bool(context, pref_name, False)
        try:
            _apply_always_on_feature(context, str(spec.get('key') or ''), False, load_if_needed=False, save=False)
        except Exception:
            pass
    _disable_quick_rigid_always_on_features(context)
    _disable_jiggle_always_on_features(context)
_ALWAYS_ON_SPECS: tuple[dict[str, object], ...] = ({'key': 'suite_npanel_persistence', 'module': '', 'pref': 'always_suite_npanel_persistence', 'default': True, 'label_en': 'N-panel State Save', 'label_ja': 'Nパネル状態保存', 'tooltip_en': 'Function: when enabled, every Smart Cloth N-panel setting change is saved immediately to Smart_Cloth_Suite.json in Blender 5.1 config/Smart_Cloth_Suite. When disabled, changes are saved only when the current scene is closed/switched or when preferences are saved. How to use: keep enabled to preserve changes as soon as they are made; disable it when you want deferred saving.', 'tooltip_ja': '機能: 有効時は Smart Cloth のNパネル内で行った全設定変更を、Blender 5.1 config/Smart_Cloth_Suite 内の Smart_Cloth_Suite.json へ即時保存します。無効時は現在のシーンを閉じる / 切り替えるタイミング、またはプリファレンス保存時だけ保存します。使い方: 変更した時点で確実に維持したい場合は有効、保存タイミングを遅らせたい場合は無効にします。', 'kind': 'suite_persistence'}, {'key': 'jiggle_runtime_callbacks', 'module': 'jiggle_physics', 'pref': 'always_jiggle_runtime_callbacks', 'default': False, 'label_en': 'Jiggle Callbacks', 'label_ja': 'Jiggle コールバック', 'tooltip_en': 'Function: installs or removes only the frame-change, playback, render, and overlay callbacks required for live Jiggle evaluation. How to use: enable only while previewing, rendering, baking, or validating live Jiggle behavior; disable it for normal idle work. Scene simulation, scrub, debug, and wind are ordinary Jiggle settings and no longer load always-on services by themselves.', 'tooltip_ja': '機能: ライブ Jiggle 評価に必要なフレーム変更、再生、レンダー、オーバーレイ用コールバックだけを追加 / 削除します。使い方: ライブ Jiggle の確認、レンダー、ベイク、検証中だけ有効にし、通常の待機作業では無効にします。シーンシミュレーション、スクラブ、デバッグ、風は通常の Jiggle 設定として扱い、単体では常時起動サービスを読み込みません。', 'kind': 'jiggle_runtime_callbacks'}, {'key': 'jiggle_overlay_rest_pose', 'module': 'jiggle_physics', 'pref': 'always_jiggle_overlay_rest_pose', 'default': False, 'label_en': 'Jiggle Rest Pose', 'label_ja': 'Jiggle レスト姿勢', 'tooltip_en': 'Function: keeps the Jiggle rest-pose overlay visible in the current 3D View. How to use: enable while checking rest particles or chain setup; disable to remove the draw callback.', 'tooltip_ja': '機能: 現在の3Dビューに Jiggle のレスト姿勢オーバーレイを表示します。使い方: レスト粒子やチェーン設定を確認する間だけ有効にし、不要な場合は描画コールバックを削除するため無効にします。', 'kind': 'jiggle_overlay_pose'}, {'key': 'jiggle_overlay_simulation', 'module': 'jiggle_physics', 'pref': 'always_jiggle_overlay_simulation', 'default': False, 'label_en': 'Jiggle Simulation', 'label_ja': 'Jiggle シミュレーション', 'tooltip_en': 'Function: keeps the Jiggle simulated-particle overlay visible in the current 3D View. How to use: enable while inspecting live simulation positions; disable to remove the draw callback.', 'tooltip_ja': '機能: 現在の3Dビューに Jiggle のシミュレーション粒子オーバーレイを表示します。使い方: ライブシミュレーション位置を確認する間だけ有効にし、不要な場合は描画コールバックを削除するため無効にします。', 'kind': 'jiggle_overlay_sim'})
_ALWAYS_ON_SPEC_BY_KEY = {str(item.get('key')): item for item in _ALWAYS_ON_SPECS}

def _always_on_spec(feature_key: str) -> dict[str, object] | None:
    return _ALWAYS_ON_SPEC_BY_KEY.get(str(feature_key or '').strip())

def _always_on_label(spec: dict[str, str], context=None) -> str:
    return _root_ui_text(str(spec.get('label_en') or ''), str(spec.get('label_ja') or ''), context)

def _always_on_tooltip(spec: dict[str, str], context=None) -> str:
    return _root_ui_text(str(spec.get('tooltip_en') or ''), str(spec.get('tooltip_ja') or ''), context)

def _always_on_enabled(context, feature_key: str) -> bool:
    spec = _always_on_spec(feature_key)
    if not spec:
        return False
    pref_name = str(spec.get('pref') or '')
    return _pref_bool(context, pref_name, bool(spec.get('default', False)))

def _jiggle_sync_handlers_if_available(scene=None) -> None:
    module = _jiggle_module()
    sync = getattr(module, '_sync_runtime_handlers', None) if module is not None else None
    if callable(sync):
        try:
            sync(scene)
        except Exception:
            pass

def _jiggle_update_overlay_if_available() -> None:
    module = _jiggle_module()
    globals_obj = getattr(module, '_jiggle_globals', None) if module is not None else None
    update = getattr(globals_obj, 'update_overlay_draw_handler', None) if globals_obj is not None else None
    if callable(update):
        try:
            update()
        except Exception:
            pass

def _apply_always_on_feature(context, feature_key: str, value: bool, *, load_if_needed: bool=True, save: bool=True) -> bool:
    spec = _always_on_spec(feature_key)
    if not spec:
        return False
    module_name = str(spec.get('module') or '')
    pref_name = str(spec.get('pref') or '')
    value = bool(value)
    if pref_name:
        _set_pref_bool(context, pref_name, value, save=save)
    if not value and module_name and (not _tool_loaded(module_name)):
        return True
    if value and module_name and load_if_needed:
        _enable_tool(module_name, _STANDARD_NPANEL_TOOL_LABELS.get(module_name, module_name), context=context)
    kind = str(spec.get('kind') or '')
    if kind == 'suite_persistence':
        try:
            _register_load_post_restore_handler()
            _register_persistence_handlers()
            _unregister_persistence_timer()
            if bool(save):
                _persist_npanel_runtime_state(context, force=True)
            return True
        except Exception:
            pass
            return False
    scene = _scene(context)
    jiggle = _jiggle_settings(context)
    if kind.startswith('jiggle_') and jiggle is None:
        return not value
    try:
        if kind == 'jiggle_runtime_callbacks':
            if value and hasattr(jiggle, 'enable'):
                jiggle.enable = True
            if hasattr(jiggle, 'runtime_callbacks_enabled'):
                jiggle.runtime_callbacks_enabled = value
            _jiggle_sync_handlers_if_available(scene)
            return True
        if kind in {'jiggle_overlay_pose', 'jiggle_overlay_sim'}:
            state = _jiggle_overlay_state(context, create=value)
            if state is None:
                return not value
            if kind == 'jiggle_overlay_pose':
                state.overlay_pose = value
            else:
                state.overlay_simulation = value
            _jiggle_update_overlay_if_available()
            return True
        if kind in {'jiggle_armature_enable', 'jiggle_armature_mute', 'jiggle_armature_freeze'}:
            obj = getattr(context, 'object', None) if context is not None else getattr(getattr(bpy, 'context', None), 'object', None)
            obj_jiggle = getattr(obj, 'jiggle', None) if obj is not None and getattr(obj, 'type', None) == 'ARMATURE' else None
            if obj_jiggle is None:
                return not value
            attr = {'jiggle_armature_enable': 'enable', 'jiggle_armature_mute': 'mute', 'jiggle_armature_freeze': 'freeze'}[kind]
            if hasattr(obj_jiggle, attr):
                setattr(obj_jiggle, attr, value)
            return True
        if kind == 'jiggle_bone_enable':
            bone = getattr(context, 'active_pose_bone', None) if context is not None else getattr(getattr(bpy, 'context', None), 'active_pose_bone', None)
            bone_jiggle = getattr(bone, 'jiggle', None) if bone is not None else None
            if bone_jiggle is None:
                return not value
            if hasattr(bone_jiggle, 'enable'):
                bone_jiggle.enable = value
            return True
    except Exception:
        return False
    return True

def _sync_always_on_preferences_for_loaded_module(context=None, module_name: str='') -> None:
    module_name = str(module_name or '').strip()
    if not module_name:
        return
    for spec in _ALWAYS_ON_SPECS:
        if str(spec.get('module') or '') != module_name:
            continue
        pref_name = str(spec.get('pref') or '')
        value = _pref_bool(context, pref_name, bool(spec.get('default', False))) if pref_name else bool(spec.get('default', False))
        try:
            _apply_always_on_feature(context, str(spec.get('key') or ''), value, load_if_needed=False, save=False)
        except Exception:
            pass

def _apply_saved_always_on_preferences(context=None, *, startup: bool=False) -> None:
    prefs = _root_preferences(context)
    if prefs is None:
        return
    for spec in _ALWAYS_ON_SPECS:
        pref_name = str(spec.get('pref') or '')
        default = bool(spec.get('default', False))
        if not pref_name:
            value = default
        else:
            try:
                value = bool(getattr(prefs, pref_name, default))
            except Exception:
                value = default
        if not value:
            continue
        try:
            _apply_always_on_feature(context, str(spec.get('key') or ''), True, load_if_needed=True, save=False)
        except Exception:
            pass

def sync_always_on_from_preferences(context=None) -> None:
    """Apply all saved always-on BoolProperties after direct N-panel prop toggles."""
    for spec in _ALWAYS_ON_SPECS:
        pref_name = str(spec.get('pref') or '')
        default = bool(spec.get('default', False))
        value = _pref_bool(context, pref_name, default) if pref_name else default
        try:
            _apply_always_on_feature(context, str(spec.get('key') or ''), value, load_if_needed=bool(value), save=False)
        except Exception:
            pass

class SMARTCLOTHSUITE_OT_show_help_popup(bpy.types.Operator):
    bl_idname = 'smart_core.show_help_popup'
    bl_label = _root_ui_text('Help', 'ヘルプ')
    bl_description = _root_ui_text('Open detailed help for this Smart Cloth section.', 'この Smart Cloth セクションの詳細ヘルプを開きます。')
    bl_options = {'INTERNAL'}
    topic: StringProperty(name=_root_ui_text('Help Topic', 'ヘルプ項目'), description=_root_ui_text('Internal help topic identifier used to draw the matching Smart Cloth popup contents.', '対応する Smart Cloth ヘルプポップアップ本文を描画するための内部ヘルプ項目識別子です。'), default='suite', options={'SKIP_SAVE', 'HIDDEN'})

    @classmethod
    def description(cls, context, properties):
        topic = str(getattr(properties, 'topic', '') or 'suite')
        title = _help_topic_title(topic, context)
        return _root_ui_text('Open the %(title)s popup.', '%(title)s のポップアップを開きます。', context) % {'title': title}

    def _help_module(self):
        return _load_help_popup_module()

    def _dialog_width(self, context) -> int:
        try:
            module = self._help_module()
            width_func = getattr(module, 'help_dialog_width', None)
            if callable(width_func):
                return int(width_func(context))
        except Exception:
            pass
        return 900

    def invoke(self, context, event):
        try:
            self._help_module()
            wm = getattr(context, 'window_manager', None)
            if wm is None:
                return {'CANCELLED'}
            width = self._dialog_width(context)
            self._help_popup_width_px = int(width)
            self._suppress_execute_popup = True
            if hasattr(wm, 'invoke_popup'):
                return wm.invoke_popup(self, width=width)
            if hasattr(wm, 'invoke_props_dialog'):
                return wm.invoke_props_dialog(self, width=width)
        except Exception:
            self.report({'ERROR'}, _root_ui_text('Help popup failed.', 'ヘルプポップアップの表示に失敗しました。', context))
            return {'CANCELLED'}
        return self.execute(context)

    def draw(self, context):
        try:
            module = self._help_module()
            draw_contents = getattr(module, 'draw_help_contents', None)
            if callable(draw_contents):
                popup_width = int(getattr(self, '_help_popup_width_px', 0) or self._dialog_width(context))
                draw_contents(self.layout, context, str(self.topic or 'suite').strip() or 'suite', popup_width=popup_width)
                return
        except Exception:
            pass
        try:
            self.layout.label(text=_root_ui_text('Help popup failed.', 'ヘルプポップアップの表示に失敗しました。', context), icon='ERROR')
        except Exception:
            pass

    def execute(self, context):
        if bool(getattr(self, '_suppress_execute_popup', False)):
            return {'FINISHED'}
        topic = str(self.topic or 'suite').strip() or 'suite'
        try:
            module = self._help_module()
            show = getattr(module, 'show_help_popup', None)
            if callable(show):
                show(context, topic)
            else:
                raise RuntimeError('show_help_popup is not available')
        except Exception:
            self.report({'ERROR'}, _root_ui_text('Help popup failed.', 'ヘルプポップアップの表示に失敗しました。', context))
            return {'CANCELLED'}
        return {'FINISHED'}

class SMARTCLOTHSUITE_OT_toggle_ui_section(bpy.types.Operator):
    bl_idname = 'smart_core.toggle_ui_section'
    bl_label = _root_ui_text('Toggle UI Section', 'UIセクションを開閉')
    bl_description = _root_ui_text('Open or close this Smart Cloth UI section.', 'この Smart Cloth UI セクションを開閉します。')
    bl_options = {'INTERNAL'}
    _sms_no_undo = True
    section_key: StringProperty(name=_root_ui_text('Section Key', 'セクションキー'), description=_root_ui_text('Internal identifier for the UI section to open or close.', '開閉するUIセクションの内部識別子です。'), options={'SKIP_SAVE', 'HIDDEN'})
    label: StringProperty(name=_root_ui_text('Section Label', 'セクション名'), description=_root_ui_text('Display label used in status reports and tooltips.', 'ステータス表示とツールチップに使う表示名です。'), options={'SKIP_SAVE', 'HIDDEN'})

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, 'label', '') or getattr(properties, 'section_key', '') or '').strip()
        if label:
            return _root_ui_text('Open or close the %(section)s section.', '%(section)s セクションを開閉します。', context) % {'section': label}
        return _root_ui_text('Open or close this UI section.', 'このUIセクションを開閉します。', context)

    def execute(self, context):
        key = str(self.section_key or '').strip()
        if not key:
            return {'CANCELLED'}
        current = _ui_section_state_get(context, key, _UI_SECTION_DEFAULTS.get(key, False))
        _ui_section_state_set(context, key, not current)
        _tag_view3d_redraw(context)
        return {'FINISHED'}

class SMARTCLOTHSUITE_OT_toggle_standard_npanel_tool(bpy.types.Operator):
    bl_idname = 'smart_core.toggle_standard_npanel_tool'
    bl_label = _root_ui_text('Toggle Tool Module', 'ツールモジュールを切り替え')
    bl_description = _root_ui_text('Enable or disable one bundled tool module. Disabled modules are unloaded and do not run background handlers.', '同梱ツールモジュールを個別に有効 / 無効化します。無効のモジュールは読み込みを解除し、バックグラウンド処理を動かしません。')
    bl_options = set()
    _sms_no_undo = True
    module_name: StringProperty(name=_root_ui_text('Module Name', 'モジュール名'), description=_root_ui_text('Internal bundled tool module identifier to enable or disable.', '有効化または無効化する同梱ツールモジュールの内部識別子です。'), options={'SKIP_SAVE', 'HIDDEN'})
    enable: BoolProperty(name=_root_ui_text('Enable Module', 'モジュールを有効化'), description=_root_ui_text('When enabled, the selected bundled module is loaded; when disabled, it is unloaded and its always-on handlers are removed when applicable.', '有効時は選択した同梱モジュールを読み込み、無効時は読み込み解除し、対象の常時起動ハンドラも解除します。'), default=True, options={'SKIP_SAVE', 'HIDDEN'})

    def execute(self, context):
        module_name = str(self.module_name or '').strip()
        valid_modules = _STANDARD_NPANEL_TOOL_NAMES
        if module_name not in valid_modules:
            self.report({'ERROR'}, _root_ui_text('Unknown tool module.', '不明なツールモジュールです。', context))
            return {'CANCELLED'}
        try:
            if bool(self.enable):
                _enable_tool(module_name, _STANDARD_NPANEL_TOOL_LABELS.get(module_name, module_name), context=context)
                self.report({'INFO'}, _root_ui_text('Tool module enabled.', 'ツールモジュールを有効化しました。', context))
            else:
                if module_name == 'jiggle_physics':
                    _disable_jiggle_always_on_features(context)
                elif module_name == 'quick_rigid':
                    _disable_quick_rigid_always_on_features(context)
                _disable_tool(module_name)
                self.report({'INFO'}, _root_ui_text('Tool module disabled.', 'ツールモジュールを無効化しました。', context))
        except Exception:
            self.report({'ERROR'}, _root_ui_text('Failed to change the tool module.', 'ツールモジュールの切り替えに失敗しました。', context))
            return {'CANCELLED'}
        return {'FINISHED'}

def _bpy_operator_callable(operator_id: str):
    parts = [part for part in str(operator_id or '').split('.') if part]
    if len(parts) < 2:
        return None
    current = bpy.ops
    try:
        for part in parts:
            current = getattr(current, part)
        return current
    except Exception:
        return None

def _error_detail(exc, context=None) -> str:
    # A failed bpy.ops call carries the operator's own report behind "Error: ",
    # already in the UI language. Anything else is not shown as it is.
    if isinstance(exc, OSError):
        return _root_ui_text('Check that the location exists and can be written to.', 'フォルダーの場所と書き込みの権限を確かめてください。', context)
    text = str(exc).strip()
    if text.startswith('Error: '):
        text = text[len('Error: '):].strip()
    text = text.split('\n', 1)[0].strip()
    if 'bpy.ops.' in text or 'poll()' in text:
        return _root_ui_text('Check the selection and mode.', '選択とモードを確かめてください。', context)
    if isinstance(exc, RuntimeError) and text and not text.startswith(('Python:', 'Traceback')):
        if not _root_is_japanese_locale(context) or any(ord(ch) >= 0x3040 for ch in text):
            return text
    return _root_ui_text('The command could not be completed.', '処理を完了できませんでした。', context)

class SMARTCLOTHSUITE_OT_lazy_execute_tool(bpy.types.Operator):
    bl_idname = 'smart_core.lazy_execute_tool'
    bl_label = _root_ui_text('Run Tool Command', 'ツールコマンドを実行')
    bl_description = _root_ui_text('Load only the required bundled tool module, then run the selected command. This keeps startup and idle N-panel drawing lightweight.', '必要な同梱ツールモジュールだけを読み込んでから、選択したコマンドを実行します。起動時と待機中のNパネル描画を軽く保ちます。')
    bl_options = set()
    module_name: StringProperty(name=_root_ui_text('Module Name', 'モジュール名'), description=_root_ui_text('Internal bundled tool module identifier that should be loaded before running the command.', 'コマンド実行前に読み込む同梱ツールモジュールの内部識別子です。'), options={'SKIP_SAVE', 'HIDDEN'})
    operator_id: StringProperty(name=_root_ui_text('Operator ID', 'オペレーターID'), description=_root_ui_text('Blender operator identifier to execute after the required module is loaded.', '必要なモジュールを読み込んだあとに実行する Blender オペレーター識別子です。'), options={'SKIP_SAVE', 'HIDDEN'})
    menu_id: StringProperty(name=_root_ui_text('Menu ID', 'メニューID'), description=_root_ui_text('Optional Blender menu identifier to call after the required module is loaded.', '必要なモジュールを読み込んだあとに呼び出す任意の Blender メニュー識別子です。'), options={'SKIP_SAVE', 'HIDDEN'})
    execution_context: StringProperty(name=_root_ui_text('Execution Context', '実行コンテキスト'), description=_root_ui_text('Operator execution context, such as INVOKE_DEFAULT or EXEC_DEFAULT.', 'INVOKE_DEFAULT や EXEC_DEFAULT などのオペレーター実行コンテキストです。'), default='INVOKE_DEFAULT', options={'SKIP_SAVE', 'HIDDEN'})
    operator_props_json: StringProperty(name=_root_ui_text('Operator Properties', 'オペレータープロパティ'), description=_root_ui_text('JSON-encoded operator properties passed to the delayed command.', '遅延実行コマンドへ渡すJSON形式のオペレータープロパティです。'), default='', options={'SKIP_SAVE', 'HIDDEN'})
    tooltip_en: StringProperty(name=_root_ui_text('Source Tooltip', '元ツールチップ'), description=_root_ui_text('Source tooltip text used as the fallback for the lazy command button.', '遅延実行コマンドボタンのフォールバックとして使う元ツールチップ文です。'), options={'SKIP_SAVE', 'HIDDEN'})
    tooltip_ja: StringProperty(name=_root_ui_text('Localized Tooltip', 'ローカライズ済みツールチップ'), description=_root_ui_text('Localized tooltip text displayed for the lazy command button when the current UI language uses it.', '現在のUI言語で使用する場合に、遅延実行コマンドボタンへ表示するローカライズ済みツールチップ文です。'), options={'SKIP_SAVE', 'HIDDEN'})

    @classmethod
    def description(cls, context, properties):
        en = str(getattr(properties, 'tooltip_en', '') or '')
        ja = str(getattr(properties, 'tooltip_ja', '') or '')
        if en or ja:
            return _root_ui_text(en or ja, ja or en, context)
        return cls.bl_description

    def execute(self, context):
        module_name = str(self.module_name or '').strip()
        try:
            if module_name:
                if module_name not in _STANDARD_NPANEL_TOOL_NAMES:
                    self.report({'ERROR'}, _root_ui_text('Unknown tool module.', '不明なツールモジュールです。', context))
                    return {'CANCELLED'}
                _enable_tool(module_name, _STANDARD_NPANEL_TOOL_LABELS.get(module_name, module_name), context=context)
            menu_id = str(self.menu_id or '').strip()
            if menu_id:
                try:
                    result = bpy.ops.wm.call_menu(name=menu_id)
                    try:
                        _save_npanel_runtime_state(context)
                    except Exception:
                        pass
                    return result
                except Exception as exc:
                    self.report({'ERROR'}, _root_ui_text('Menu call failed: %(error)s', 'メニュー呼び出しに失敗しました: %(error)s', context) % {'error': _error_detail(exc, context)})
                    return {'CANCELLED'}
            operator_id = str(self.operator_id or '').strip()
            op = _bpy_operator_callable(operator_id)
            if op is None:
                self.report({'ERROR'}, _root_ui_text('Target operator was not found.', '対象オペレーターが見つかりません。', context))
                return {'CANCELLED'}
            exec_context = str(self.execution_context or 'INVOKE_DEFAULT')
            if not op.poll(exec_context):
                self.report({'WARNING'}, _root_ui_text('This command cannot run in the current state. Check the selection and mode.', 'このコマンドは今の状態では実行できません。選択とモードを確かめてください。', context))
                return {'CANCELLED'}
            try:
                raw_props = json.loads(str(self.operator_props_json or '').strip() or '{}')
                operator_props = raw_props if isinstance(raw_props, dict) else {}
            except Exception:
                operator_props = {}
            try:
                result = op(exec_context, **operator_props)
            except TypeError:
                try:
                    result = op(**operator_props)
                except TypeError:
                    result = op()
            try:
                _save_npanel_runtime_state(context)
            except Exception:
                pass
            return result if isinstance(result, set) else {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, _root_ui_text('Command failed: %(error)s', 'コマンドに失敗しました: %(error)s', context) % {'error': _error_detail(exc, context)})
            return {'CANCELLED'}

class SMARTCLOTHSUITE_OT_toggle_always_on_feature(bpy.types.Operator):
    bl_idname = 'smart_core.toggle_always_on_feature'
    bl_label = _root_ui_text('Toggle Always-on Feature', '常時起動機能を切り替え')
    bl_description = _root_ui_text('Enable or disable the selected always-on feature and save it according to the N-panel State Save policy.', '選択した常時起動機能の有効 / 無効を切り替え、Nパネル状態保存の方針に従って保存します。')
    bl_options = set()
    _sms_no_undo = True
    feature_key: StringProperty(name=_root_ui_text('Always-on Feature Key', '常時起動機能キー'), description=_root_ui_text('Internal key for the always-on feature that should be toggled and persisted.', '切り替え・保存する常時起動機能の内部キーです。'), options={'SKIP_SAVE', 'HIDDEN'})

    @classmethod
    def description(cls, context, properties):
        spec = _always_on_spec(str(getattr(properties, 'feature_key', '') or ''))
        if spec:
            return _always_on_tooltip(spec, context)
        return cls.bl_description

    def execute(self, context):
        key = str(self.feature_key or '').strip()
        spec = _always_on_spec(key)
        if not spec:
            self.report({'ERROR'}, _root_ui_text('Unknown always-on feature.', '不明な常時起動機能です。', context))
            return {'CANCELLED'}
        target_value = not _always_on_enabled(context, key)
        ok = _apply_always_on_feature(context, key, target_value, load_if_needed=target_value, save=True)
        if not ok and target_value:
            pref_name = str(spec.get('pref') or '')
            if pref_name:
                _set_pref_bool(context, pref_name, False, save=True)
            self.report({'WARNING'}, _root_ui_text('The target for this always-on feature is not available.', 'この常時起動機能の対象を取得できません。', context))
            return {'CANCELLED'}
        _save_root_preferences(context, force=key == 'suite_npanel_persistence')
        try:
            _save_npanel_runtime_state(context, force=key == 'suite_npanel_persistence')
        except Exception:
            pass
        self.report({'INFO'}, _root_ui_text('Always-on setting saved.', '常時起動設定を保存しました。', context))
        return {'FINISHED'}

class SMARTCLOTHSUITE_OT_toggle_tool_panel_visibility(bpy.types.Operator):
    bl_idname = 'smart_core.toggle_tool_panel_visibility'
    bl_label = _root_ui_text('Toggle Tool Section Visibility', 'ツールセクション表示を切り替え')
    bl_description = _root_ui_text('Show or hide one lightweight tool section inside the single Smart Cloth N-panel and save it according to the N-panel State Save policy. This does not load the tool module by itself.', '単一の Smart Cloth Nパネル内にある軽量ツールセクションを表示または非表示にし、Nパネル状態保存の方針に従って保存します。この操作だけではツールモジュールを読み込みません。')
    bl_options = set()
    _sms_no_undo = True
    module_name: StringProperty(name=_root_ui_text('Module Name', 'モジュール名'), description=_root_ui_text('Internal bundled tool module identifier whose N-panel section visibility should be toggled.', 'Nパネル内セクションの表示状態を切り替える同梱ツールモジュールの内部識別子です。'), options={'SKIP_SAVE', 'HIDDEN'})

    def execute(self, context):
        attr = _module_visibility_pref(str(self.module_name or '').strip())
        if not attr:
            self.report({'ERROR'}, _root_ui_text('Unknown tool module.', '不明なツールモジュールです。', context))
            return {'CANCELLED'}
        current = _pref_bool(context, attr, True)
        if not _set_pref_bool(context, attr, not current, save=True):
            self.report({'ERROR'}, _root_ui_text('Could not change section visibility.', 'セクションの表示を変更できませんでした。', context))
            return {'CANCELLED'}
        try:
            _save_npanel_runtime_state(context)
        except Exception:
            pass
        self.report({'INFO'}, _root_ui_text('Section visibility setting saved.', 'セクション表示設定を保存しました。', context))
        return {'FINISHED'}

class SMARTCLOTHSUITE_OT_disable_all_always_on_features(bpy.types.Operator):
    bl_idname = 'smart_core.disable_all_always_on_features'
    bl_label = _root_ui_text('Disable All Always-on Features', '常時起動機能をすべて無効化')
    bl_description = _root_ui_text('Turn off optional Smart Cloth always-on runtime features such as Jiggle callbacks and overlays. The N-panel State Save policy is left unchanged.', 'Jiggle のコールバックやオーバーレイなど、任意の Smart Cloth 常時起動ランタイム機能をOFFにします。Nパネル状態保存の方針は変更しません。')
    bl_options = {'UNDO'}

    def execute(self, context):
        _disable_all_always_on_features(context)
        try:
            _save_npanel_runtime_state(context, force=True)
        except Exception:
            pass
        self.report({'INFO'}, _root_ui_text('All always-on runtime features were disabled.', '常時起動ランタイム機能をすべて無効化しました。', context))
        return {'FINISHED'}

class SMARTCLOTHSUITE_OT_toggle_jiggle_overlay_runtime(bpy.types.Operator):
    bl_idname = 'smart_core.toggle_jiggle_overlay_runtime'
    bl_label = _root_ui_text('Toggle Jiggle Overlay', 'Jiggle オーバーレイを切り替え')
    bl_description = _root_ui_text('Toggle one Jiggle Physics overlay from the unified always-on controls. Runtime callbacks must be enabled for live drawing.', '統一された常時起動コントロールから Jiggle Physics のオーバーレイを切り替えます。ライブ描画には実行コールバックの有効化が必要です。')
    bl_options = set()
    _sms_no_undo = True
    overlay_kind: StringProperty(name=_root_ui_text('Overlay Kind', 'オーバーレイ種別'), description=_root_ui_text('Internal Jiggle overlay kind to toggle, such as rest-pose or simulation overlay drawing.', 'レスト姿勢やシミュレーション描画など、切り替える Jiggle オーバーレイの内部種別です。'), default='POSE', options={'SKIP_SAVE', 'HIDDEN'})

    def execute(self, context):
        if not _tool_loaded('jiggle_physics'):
            self.report({'ERROR'}, _root_ui_text('Enable the Jiggle Physics module first.', '先に Jiggle Physics モジュールを有効化してください。', context))
            return {'CANCELLED'}
        module = _jiggle_module()
        globals_obj = getattr(module, '_jiggle_globals', None) if module is not None else None
        if globals_obj is None:
            self.report({'ERROR'}, _root_ui_text('Jiggle overlay state is not available.', 'Jiggle オーバーレイ状態を取得できません。', context))
            return {'CANCELLED'}
        area = _find_view3d_area(context)
        if area is None:
            self.report({'ERROR'}, _root_ui_text('No 3D Viewport is available for this command', 'このコマンドに使える 3D ビューエリアがありません', context))
            return {'CANCELLED'}
        try:
            state = globals_obj.get_area_overlay_properties(area)
            kind = str(self.overlay_kind or 'POSE').upper()
            if kind == 'SIMULATION':
                state.overlay_simulation = not bool(getattr(state, 'overlay_simulation', False))
            else:
                state.overlay_pose = not bool(getattr(state, 'overlay_pose', False))
            globals_obj.update_overlay_draw_handler()
        except Exception:
            self.report({'ERROR'}, _root_ui_text('Jiggle overlay toggle failed.', 'Jiggle オーバーレイの切り替えに失敗しました。', context))
            return {'CANCELLED'}
        return {'FINISHED'}

def _stable_toggle_operator(layout, operator_id: str, *, text: str, icon: str, depressed: bool):
    """Create a toggle-like operator button whose visual pressed state is explicit.

    Blender's checked icon alone does not guarantee the blue active overlay on
    every redraw/theme combination. Passing ``depress`` makes the button state
    deterministic while keeping the normal operator-based toggle behavior.
    """
    try:
        return layout.operator(operator_id, text=text, icon=icon, depress=bool(depressed))
    except TypeError:
        return layout.operator(operator_id, text=text, icon=icon)

def _draw_tool_visibility_row(layout, context, module_name: str) -> None:
    attr = _module_visibility_pref(module_name)
    visible = _pref_bool(context, attr, True) if attr else True
    row = layout.row(align=True)
    split = row.split(factor=0.7, align=True)
    split.label(text=_tool_display_name(module_name, context))
    eye_icon_name = 'visible_on' if visible else 'visible_off'
    eye_icon_value = _scsmart_icon_id(eye_icon_name)
    try:
        op = split.operator('smart_core.toggle_tool_panel_visibility', text=_root_ui_text('Enabled', '有効', context) if visible else _root_ui_text('Disabled', '無効', context), icon_value=eye_icon_value if eye_icon_value else 0, icon='RESTRICT_VIEW_OFF' if visible else 'RESTRICT_VIEW_ON', depress=bool(visible))
    except TypeError:
        if eye_icon_value:
            op = split.operator('smart_core.toggle_tool_panel_visibility', text=_root_ui_text('Enabled', '有効', context) if visible else _root_ui_text('Disabled', '無効', context), icon_value=eye_icon_value)
        else:
            op = _stable_toggle_operator(split, 'smart_core.toggle_tool_panel_visibility', text=_root_ui_text('Enabled', '有効', context) if visible else _root_ui_text('Disabled', '無効', context), icon='RESTRICT_VIEW_OFF' if visible else 'RESTRICT_VIEW_ON', depressed=visible)
    op.module_name = module_name

def _draw_displayed_tool_sections(layout, context) -> None:
    col = _begin_collapsible_section(layout, context, 'show_displayed_tool_modules', 'Displayed Tool Sections', '表示するツールセクション', icon='RESTRICT_VIEW_OFF', topic='display_sections', default=False)
    if col is _NULL_LAYOUT:
        return
    for module_name, _friendly_name in _STANDARD_NPANEL_TOOLS:
        _draw_tool_visibility_row(col, context, module_name)

def _draw_always_on_feature_row(layout, context, spec: dict[str, object]) -> None:
    key = str(spec.get('key') or '')
    pref_name = str(spec.get('pref') or '')
    enabled = _always_on_enabled(context, key)
    prefs = _root_preferences(context)
    row = layout.row(align=True)
    row.scale_y = 0.95
    split = row.split(factor=0.72, align=True)
    left = split.row(align=True)
    left.label(text=_always_on_label(spec, context))
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    right.use_property_split = False
    right.use_property_decorate = False
    if prefs is not None and pref_name and hasattr(prefs, pref_name):
        try:
            right.row(align=True).prop(prefs, pref_name, text=_root_ui_text('On', '有効', context) if enabled else _root_ui_text('Off', '無効', context), icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT', toggle=True)
        except Exception:
            _safe_label(right, _root_ui_text('Off', '無効', context), icon='CHECKBOX_DEHLT')
    else:
        disabled = right.row(align=True)
        disabled.enabled = False
        disabled.label(text=_root_ui_text('Off', '無効', context), icon='CHECKBOX_DEHLT')

def _draw_always_on_toggle_group(layout, context) -> None:
    col = _begin_collapsible_section(layout, context, 'show_always_on_toggles', 'Always-on Toggles', '常時機能切り替え', icon='TIME', topic='always_on', default=False)
    try:
        col.use_property_split = False
        col.use_property_decorate = False
    except Exception:
        pass
    if col is _NULL_LAYOUT:
        return
    for index, spec in enumerate(_ALWAYS_ON_SPECS):
        _draw_always_on_feature_row(col, context, spec)
        if index == 0:
            col.separator(factor=0.5)

def _safe_lazy_operator(layout, module_name: str, operator_id: str, text: str, *, icon: str='NONE', custom_icon: str='', tooltip_en: str='', tooltip_ja: str='', menu_id: str='', execution_context: str='INVOKE_DEFAULT', _emboss: bool | None=None, **operator_props):
    """Draw a native operator when its module is loaded, otherwise a finite lazy loader.

    Native drawing is important because Blender evaluates the target operator's
    own ``poll`` and disables only the unavailable command while the fixed root
    Panel remains visible in Edit, Sculpt, Paint, and other modes.
    """
    if layout is _NULL_LAYOUT:
        return None
    icon_value = _scsmart_icon_id(custom_icon) if custom_icon else 0
    emboss = bool(_emboss) if _emboss is not None else True

    if operator_id and _tool_loaded(module_name):
        try:
            try:
                if icon_value:
                    direct = layout.operator(operator_id, text=text, icon_value=icon_value, emboss=emboss)
                else:
                    direct = layout.operator(operator_id, text=text, icon=icon, emboss=emboss)
            except TypeError:
                if icon_value:
                    direct = layout.operator(operator_id, text=text, icon_value=icon_value)
                else:
                    direct = layout.operator(operator_id, text=text, icon=icon)
            for key, value in dict(operator_props or {}).items():
                try:
                    setattr(direct, str(key), value)
                except Exception:
                    pass
            return direct
        except Exception:
            # A missing target operator falls back to the explicit lazy command;
            # no registration or state mutation is performed from Panel.draw.
            pass

    try:
        try:
            if icon_value:
                op = layout.operator('smart_core.lazy_execute_tool', text=text, icon_value=icon_value, emboss=emboss)
            else:
                op = layout.operator('smart_core.lazy_execute_tool', text=text, icon=icon, emboss=emboss)
        except TypeError:
            if icon_value:
                op = layout.operator('smart_core.lazy_execute_tool', text=text, icon_value=icon_value)
            else:
                op = layout.operator('smart_core.lazy_execute_tool', text=text, icon=icon)
        op.module_name = module_name
        op.operator_id = operator_id
        op.menu_id = menu_id
        op.execution_context = execution_context
        try:
            clean_props = {str(k): v for k, v in dict(operator_props or {}).items() if isinstance(v, (str, int, float, bool)) or v is None}
            op.operator_props_json = json.dumps(clean_props, ensure_ascii=False, separators=(',', ':'))
        except Exception:
            op.operator_props_json = ''
        op.tooltip_en = tooltip_en
        op.tooltip_ja = tooltip_ja
        return op
    except Exception:
        try:
            layout.label(text=text, icon='ERROR')
        except Exception:
            pass
        return None

def _draw_quick_rigid_extra_lazy_commands(layout, context) -> None:
    extra = _begin_child_collapsible_section(layout, context, 'ui_open_quick_rigid_all_commands', 'All Quick Rigid Commands', 'Quick Rigid 全コマンド', icon='TOOL_SETTINGS', topic='quick_rigid')
    if extra is _NULL_LAYOUT:
        return
    row = extra.column(align=True)
    _safe_lazy_operator(row, 'quick_rigid', 'rigid_body.toggle_animated', _root_ui_text('Toggle Animated', 'アニメーション切替', context), icon='RENDER_ANIMATION', tooltip_en='Load Quick Rigid only for this command and toggle the active rigid body animated state.', tooltip_ja='このコマンド実行時だけ Quick Rigid を読み込み、アクティブ剛体のアニメーション状態を切り替えます。')
    _safe_lazy_operator(row, 'quick_rigid', 'quick_rigid.apply_shortcut_key', _root_ui_text('Copy Shortcut Setup', 'ショートカット設定をコピー', context), icon='COPYDOWN', tooltip_en='Load Quick Rigid only for this command and copy the manual shortcut registration details.', tooltip_ja='このコマンド実行時だけ Quick Rigid を読み込み、手動ショートカット登録情報をコピーします。')

def _draw_jiggle_extra_lazy_commands(layout, context) -> None:
    extra = _begin_child_collapsible_section(layout, context, 'ui_open_jiggle_all_commands', 'All Jiggle Commands', 'Jiggle 全コマンド', icon='TOOL_SETTINGS', topic='jiggle_physics')
    if extra is _NULL_LAYOUT:
        return
    row = extra.column(align=True)
    _safe_lazy_operator(row, 'jiggle_physics', 'armature.jiggle_bone_constraints_disable', _root_ui_text('Disable Bone Constraints', 'ボーン制約を無効化', context), icon='CONSTRAINT_BONE', tooltip_en='Load Jiggle Physics only for this command and disable constraints on selected bones.', tooltip_ja='このコマンド実行時だけ Jiggle Physics を読み込み、選択ボーンの制約を無効化します。')

def _draw_quick_rigid_native_panel_if_loaded(layout, context) -> bool:
    return False

def _draw_quick_rigid_lazy_tools(layout, context) -> None:
    menu = _begin_child_collapsible_section(layout, context, 'ui_open_quick_rigid_menu', 'Quick Menu', 'クイックメニュー', icon='MENU_PANEL', topic='quick_rigid_menu')
    _safe_lazy_operator(menu, 'quick_rigid', '', _root_ui_text('Open Quick Rigid Menu', 'Quick Rigid メニューを開く', context), icon='COLLAPSEMENU', menu_id='VIEW3D_MT_quick_rigid', tooltip_en='Load Quick Rigid only for this command and open the main menu.', tooltip_ja='このコマンド実行時だけ Quick Rigid を読み込み、メインメニューを開きます。')
    for menu_id, en, ja, icon in (('VIEW3D_MT_quick_rigid_main_submenu', 'Main Settings', 'メイン設定', 'SETTINGS'), ('VIEW3D_MT_quick_rigid_physics_submenu', 'Physical Properties', '物理プロパティ', 'PHYSICS'), ('VIEW3D_MT_quick_rigid_sim_submenu', 'Simulation Settings', 'シミュレーション設定', 'PLAY'), ('VIEW3D_MT_quick_rigid_presets_submenu', 'Presets', 'プリセット', 'PRESET'), ('VIEW3D_MT_quick_rigid_bake_submenu', 'Bake Options', 'ベイクオプション', 'KEY_HLT')):
        _safe_lazy_operator(menu, 'quick_rigid', '', _root_ui_text(en, ja, context), icon=icon, menu_id=menu_id, tooltip_en=f'Load Quick Rigid only for this command and open {en}.', tooltip_ja=f'このコマンド実行時だけ Quick Rigid を読み込み、{ja}を開きます。')
    box = _begin_child_collapsible_section(layout, context, 'ui_open_quick_rigid_setup', 'Rigid Body Setup', '剛体セットアップ', icon='PHYSICS', topic='quick_rigid_setup')
    row = box.column(align=True)
    _safe_lazy_operator(row, 'quick_rigid', 'object.add_active_rigid_body', _root_ui_text('Add Active', 'アクティブを追加', context), icon='MESH_MONKEY', tooltip_en='Load Quick Rigid only for this command and add an active rigid body to selected meshes.', tooltip_ja='このコマンド実行時だけ Quick Rigid を読み込み、選択メッシュへ アクティブ剛体を追加します。')
    _safe_lazy_operator(row, 'quick_rigid', 'object.add_passive_rigid_body', _root_ui_text('Add Passive', 'パッシブを追加', context), icon='MESH_CUBE', tooltip_en='Load Quick Rigid only for this command and add a passive rigid body to selected meshes.', tooltip_ja='このコマンド実行時だけ Quick Rigid を読み込み、選択メッシュへ パッシブ剛体を追加します。')
    row = box.row(align=True)
    _safe_operator(row, 'rigidbody.object_settings_copy', _root_ui_text('Copy Settings', '設定をコピー', context), icon='COPYDOWN')
    _safe_operator(row, 'rigidbody.object_remove', _root_ui_text('Remove Body', '剛体を削除', context), icon='X')
    preset = _begin_child_collapsible_section(layout, context, 'ui_open_quick_rigid_presets', 'Presets / Bake', 'プリセット / ベイク', icon='PRESET', topic='quick_rigid_presets')
    col = preset.column(align=True)
    _safe_lazy_operator(col, 'quick_rigid', 'object.add_rigid_body_preset', _root_ui_text('Add Preset', 'プリセット追加', context), icon='ADD', tooltip_en='Load Quick Rigid only for this command and add a rigid body preset.', tooltip_ja='このコマンド実行時だけ Quick Rigid を読み込み、剛体プリセットを追加します。')
    _safe_lazy_operator(col, 'quick_rigid', 'object.apply_rigid_body_preset', _root_ui_text('Apply Preset', 'プリセットを適用', context), icon='IMPORT', tooltip_en='Load Quick Rigid only for this command, then choose a saved preset to apply.', tooltip_ja='このコマンド実行時だけ Quick Rigid を読み込み、保存済みのプリセットを選んで適用します。')
    _safe_lazy_operator(col, 'quick_rigid', 'object.delete_rigid_body_preset', _root_ui_text('Delete Preset', 'プリセット削除', context), icon='TRASH', tooltip_en='Load Quick Rigid only for this command, then choose a saved preset to delete.', tooltip_ja='このコマンド実行時だけ Quick Rigid を読み込み、保存済みのプリセットを選んで削除します。')
    col = preset.column(align=True)
    _safe_operator_icon(col, 'ptcache.bake_all', _root_ui_text('Bake All Dynamics', '全ダイナミクスをベイク', context), icon='REC', custom_icon='')
    _safe_operator_icon(col, 'ptcache.free_bake_all', _root_ui_text('Free All Bakes', '全ベイク解除', context), icon='X', custom_icon='')
    _draw_quick_rigid_extra_lazy_commands(layout, context)

def _draw_jiggle_lazy_tools(layout, context) -> None:
    scene_box = _begin_child_collapsible_section(layout, context, 'ui_open_jiggle_scene', 'Scene Settings', 'シーン設定', icon='SCENE_DATA', topic='jiggle_scene')
    row = scene_box.column(align=True)
    _safe_lazy_operator(row, 'jiggle_physics', 'scene.jiggle_reset', _root_ui_text('Reset Physics', '物理をリセット', context), icon='LOOP_BACK', custom_icon='', tooltip_en='Load Jiggle Physics only for this command and reset the simulation state.', tooltip_ja='このコマンド実行時だけ Jiggle Physics を読み込み、シミュレーション状態をリセットします。')
    _safe_lazy_operator(row, 'jiggle_physics', 'scene.jiggle_profile', _root_ui_text('Print Profiling Information', '計測結果を出力', context), icon='TEXT', tooltip_en='Load Jiggle Physics only for this command and print profiling information.', tooltip_ja='このコマンド実行時だけ Jiggle Physics を読み込み、計測結果を出力します。')
    bone_box = _begin_child_collapsible_section(layout, context, 'ui_open_jiggle_utilities', 'Armature / Bone Utilities', 'アーマチュア / ボーン補助', icon='ARMATURE_DATA', topic='jiggle_utilities')
    row = bone_box.column(align=True)
    _safe_lazy_operator(row, 'jiggle_physics', 'armature.jiggle_copy', _root_ui_text('Copy Settings to Selected', '設定を選択ボーンへコピー', context), icon='COPYDOWN', tooltip_en='Load Jiggle Physics only for this command and copy Jiggle settings to selected bones.', tooltip_ja='このコマンド実行時だけ Jiggle Physics を読み込み、Jiggle 設定を選択ボーンへコピーします。')
    _safe_lazy_operator(row, 'jiggle_physics', 'armature.jiggle_select', _root_ui_text('Select Enabled', '有効ボーンを選択', context), icon='RESTRICT_SELECT_OFF', tooltip_en='Load Jiggle Physics only for this command and select bones with Jiggle enabled.', tooltip_ja='このコマンド実行時だけ Jiggle Physics を読み込み、Jiggle 有効ボーンを選択します。')
    row = bone_box.column(align=True)
    _safe_lazy_operator(row, 'jiggle_physics', 'armature.jiggle_bake', _root_ui_text('Bake Jiggle', 'Jiggle をベイク', context), icon='REC', tooltip_en='Load Jiggle Physics only for this command and bake the Jiggle result.', tooltip_ja='このコマンド実行時だけ Jiggle Physics を読み込み、Jiggle 結果をベイクします。')
    _safe_lazy_operator(row, 'jiggle_physics', 'anim.jiggle_clear_keyframes', _root_ui_text('Clear Parameter Keyframes', 'パラメーターキーフレームを削除', context), icon='KEY_DEHLT', custom_icon='', tooltip_en='Load Jiggle Physics only for this command and clear Jiggle parameter keyframes.', tooltip_ja='このコマンド実行時だけ Jiggle Physics を読み込み、Jiggle パラメータのキーフレームを削除します。')
    row = bone_box.column(align=True)
    _safe_lazy_operator(row, 'jiggle_physics', 'armature.jiggle_bone_connected_disable', _root_ui_text('Disconnect Selected Bones', '選択ボーンの接続を解除', context), icon='CONSTRAINT_BONE', tooltip_en='Load Jiggle Physics only for this command and disconnect selected bones for Jiggle movement.', tooltip_ja='このコマンド実行時だけ Jiggle Physics を読み込み、Jiggle の動き用に選択ボーンを非接続化します。')
    _safe_lazy_operator(row, 'jiggle_physics', 'armature.add_jigglebone_preset', _root_ui_text('Save Preset', 'プリセットを保存', context), icon='ADD', tooltip_en='Load Jiggle Physics only for this command and save a Jiggle bone preset.', tooltip_ja='このコマンド実行時だけ Jiggle Physics を読み込み、Jiggle ボーンプリセットを保存します。')
    _draw_jiggle_extra_lazy_commands(layout, context)

def _draw_quick_rigid_tools(layout, context) -> None:
    if not _tool_loaded('quick_rigid'):
        _draw_quick_rigid_lazy_tools(layout, context)
        return
    if _draw_quick_rigid_native_panel_if_loaded(layout, context):
        return
    settings = _quick_rigid_settings(context)
    if settings is None:
        layout.label(text=_root_ui_text('Quick Rigid settings are not available.', 'Quick Rigid 設定を取得できません。', context), icon='ERROR')
        return
    menu = _begin_child_collapsible_section(layout, context, 'ui_open_quick_rigid_menu', 'Quick Menu', 'クイックメニュー', icon='MENU_PANEL', topic='quick_rigid_menu')
    try:
        op = menu.operator('wm.call_menu', text=_root_ui_text('Open Quick Rigid Menu', 'Quick Rigid メニューを開く', context), icon='COLLAPSEMENU')
        op.name = 'VIEW3D_MT_quick_rigid'
    except Exception:
        menu.label(text=_root_ui_text('Quick Rigid menu is not available.', 'Quick Rigid メニューを使用できません。', context), icon='ERROR')
    for menu_id, en, ja, icon in (('VIEW3D_MT_quick_rigid_main_submenu', 'Main Settings', 'メイン設定', 'SETTINGS'), ('VIEW3D_MT_quick_rigid_physics_submenu', 'Physical Properties', '物理プロパティ', 'PHYSICS'), ('VIEW3D_MT_quick_rigid_sim_submenu', 'Simulation Settings', 'シミュレーション設定', 'PLAY'), ('VIEW3D_MT_quick_rigid_presets_submenu', 'Presets', 'プリセット', 'PRESET'), ('VIEW3D_MT_quick_rigid_bake_submenu', 'Bake Options', 'ベイクオプション', 'KEY_HLT')):
        try:
            menu.menu(menu_id, text=_root_ui_text(en, ja, context), icon=icon)
        except Exception:
            pass
    active = _safe_active_object(context)
    meshes = [active] if active is not None and getattr(active, 'type', None) == 'MESH' else []
    box = _begin_child_collapsible_section(layout, context, 'ui_open_quick_rigid_setup', 'Rigid Body Setup', '剛体セットアップ', icon='PHYSICS', topic='quick_rigid_setup')
    if not meshes:
        box.label(text=_root_ui_text('Select a mesh.', 'メッシュを選択してください。', context))
    row = box.column(align=True)
    _safe_operator(row, 'object.add_active_rigid_body', _root_ui_text('Add Active', 'アクティブを追加', context), icon='MESH_MONKEY')
    _safe_operator(row, 'object.add_passive_rigid_body', _root_ui_text('Add Passive', 'パッシブを追加', context), icon='MESH_CUBE')
    row = box.row(align=True)
    _safe_operator(row, 'rigidbody.object_settings_copy', _root_ui_text('Copy Settings', '設定をコピー', context), icon='COPYDOWN')
    _safe_operator(row, 'rigidbody.object_remove', _root_ui_text('Remove Body', '剛体を削除', context), icon='X')
    rb = getattr(active, 'rigid_body', None) if active is not None else None
    if rb is not None:
        rb_box = _begin_child_collapsible_section(layout, context, 'ui_open_quick_rigid_active_body', 'Active Rigid Body', 'アクティブ剛体', icon='PHYSICS', topic='quick_rigid_active_body')
        for attr, en, ja in (('type', 'Type', 'タイプ'), ('collision_shape', 'Shape', '形状'), ('kinematic', 'Animated', 'アニメーション'), ('mass', 'Mass', '質量'), ('friction', 'Friction', '摩擦'), ('restitution', 'Bounciness', '反発'), ('linear_damping', 'Linear Damping', 'リニア減衰'), ('angular_damping', 'Angular Damping', '角度減衰')):
            _safe_prop(rb_box, rb, attr, text=_root_ui_text(en, ja, context))
    preset = _begin_child_collapsible_section(layout, context, 'ui_open_quick_rigid_presets', 'Presets / Bake', 'プリセット / ベイク', icon='PRESET', topic='quick_rigid_presets')
    col = preset.column(align=True)
    _safe_operator(col, 'object.add_rigid_body_preset', _root_ui_text('Add Preset', 'プリセット追加', context), icon='ADD')
    _safe_operator(col, 'object.apply_rigid_body_preset', _root_ui_text('Apply Preset', 'プリセットを適用', context), icon='IMPORT')
    _safe_operator(col, 'object.delete_rigid_body_preset', _root_ui_text('Delete Preset', 'プリセット削除', context), icon='TRASH')
    col = preset.column(align=True)
    _safe_operator_icon(col, 'ptcache.bake_all', _root_ui_text('Bake All Dynamics', '全ダイナミクスをベイク', context), icon='REC', custom_icon='')
    _safe_operator_icon(col, 'ptcache.free_bake_all', _root_ui_text('Free All Bakes', '全ベイク解除', context), icon='X', custom_icon='')
    _draw_quick_rigid_extra_lazy_commands(layout, context)

def _draw_jiggle_tools(layout, context) -> None:
    if not _tool_loaded('jiggle_physics'):
        _draw_jiggle_lazy_tools(layout, context)
        return
    jiggle = _jiggle_settings(context)
    if jiggle is None:
        layout.label(text=_root_ui_text('Jiggle Physics settings are not available.', 'Jiggle Physics 設定を取得できません。', context), icon='ERROR')
        return
    scene_box = _begin_child_collapsible_section(layout, context, 'ui_open_jiggle_scene', 'Scene Settings', 'シーン設定', icon='SCENE_DATA', topic='jiggle_scene')
    for attr, en, ja in (('enable', 'Enable Scene Jiggle', 'シーン Jiggle 有効'), ('gravity', 'Gravity Scale', '重力スケール'), ('substeps', 'Substeps', 'サブステップ'), ('iterations', 'Constraint Iterations', '拘束反復'), ('loop', 'Loop Simulation', 'ループシミュレーション'), ('simulate_during_scrub', 'Timeline Scrub Simulation', 'スクラブ中もシミュレーション'), ('debug', 'Profiler / Debug Output', 'プロファイラー / デバッグ出力'), ('enable_wind', 'Enable Wind Force', '風フォース有効'), ('wind_direction', 'Wind Direction', '風向き'), ('wind_speed', 'Wind Speed', '風速'), ('wind_turbulence_scale', 'Wind Turbulence Scale', '風の乱流スケール'), ('wind_evolution_speed', 'Wind Evolution Speed', '風の変化速度')):
        _safe_prop(scene_box, jiggle, attr, text=_root_ui_text(en, ja, context))
    obj = getattr(context, 'object', None)
    obj_jiggle = getattr(obj, 'jiggle', None) if obj is not None else None
    arm_box = _begin_child_collapsible_section(layout, context, 'ui_open_jiggle_armature', 'Armature', 'アーマチュア', icon='ARMATURE_DATA', topic='jiggle_armature')
    if obj is not None and getattr(obj, 'type', None) == 'ARMATURE' and (obj_jiggle is not None):
        arm_box.label(text=str(getattr(obj, 'name', 'Armature') or 'Armature'), icon='ARMATURE_DATA', translate=False)
        row = arm_box.column(align=True)
        _safe_prop(row, obj_jiggle, 'enable', text=_root_ui_text('Enable Armature Jiggle', 'アーマチュア Jiggle 有効', context), toggle=True)
        _safe_prop(row, obj_jiggle, 'mute', text=_root_ui_text('Mute', 'ミュート', context), toggle=True)
        _safe_prop(row, obj_jiggle, 'freeze', text=_root_ui_text('Freeze', '固定', context), toggle=True)
    else:
        arm_box.label(text=_root_ui_text('Select an armature.', 'アーマチュアを選択してください。', context))
    bone = getattr(context, 'active_pose_bone', None)
    bone_box = _begin_child_collapsible_section(layout, context, 'ui_open_jiggle_bone', 'Active Bone', 'アクティブボーン', icon='BONE_DATA', topic='jiggle_bone')
    bone_jiggle = getattr(bone, 'jiggle', None) if bone is not None else None
    if bone is not None and bone_jiggle is not None:
        _safe_prop(bone_box, bone_jiggle, 'enable', text=_root_ui_text('Enable Bone Jiggle', 'ボーン Jiggle を有効化', context), toggle=True)
        for data, attr, en, ja in ((bone, 'jiggle_angle_elasticity', 'Angle Elasticity', '角度弾性'), (bone, 'jiggle_length_elasticity', 'Length Elasticity', '長さ弾性'), (bone, 'jiggle_root_elasticity', 'Root Elasticity', 'ルート弾性'), (bone, 'jiggle_gravity', 'Gravity', '重力'), (bone, 'jiggle_blend', 'Blend', 'ブレンド'), (bone, 'jiggle_air_drag', 'Air Drag', '空気抵抗'), (bone, 'jiggle_friction', 'Friction', '摩擦'), (bone, 'jiggle_collision_radius', 'Collision Radius', '衝突半径')):
            _safe_prop(bone_box, data, attr, text=_root_ui_text(en, ja, context))
        row = bone_box.column(align=True)
        _safe_operator_icon(row, 'anim.jiggle_clear_keyframes', _root_ui_text('Clear Parameter Keyframes', 'パラメーターキーフレームを削除', context), icon='KEY_DEHLT', custom_icon='')
        _safe_operator(row, 'armature.jiggle_bone_connected_disable', _root_ui_text('Disconnect Selected Bones', '選択ボーンの接続を解除', context), icon='CONSTRAINT_BONE')
    else:
        bone_box.label(text=_root_ui_text('Select a pose bone.', 'ポーズボーンを選択してください。', context))
    utility = _begin_child_collapsible_section(layout, context, 'ui_open_jiggle_utilities', 'Utilities / Bake / Presets', '補助 / ベイク / プリセット', icon='TOOL_SETTINGS', topic='jiggle_utilities')
    row = utility.column(align=True)
    _safe_operator(row, 'armature.jiggle_copy', _root_ui_text('Copy Settings to Selected', '設定を選択ボーンへコピー', context), icon='COPYDOWN')
    _safe_operator(row, 'armature.jiggle_select', _root_ui_text('Select Enabled', '有効ボーンを選択', context), icon='RESTRICT_SELECT_OFF')
    row = utility.column(align=True)
    _safe_prop(row, jiggle, 'preroll', text=_root_ui_text('Preroll', 'プリロール', context))
    _safe_prop(row, jiggle, 'bake_overwrite', text=_root_ui_text('Overwrite Current Action', '現在のアクションを上書き', context))
    nla_row = row.row()
    nla_row.enabled = not bool(getattr(jiggle, 'bake_overwrite', False))
    _safe_prop(nla_row, jiggle, 'bake_nla', text=_root_ui_text('Current Action to NLA', '現在のアクションを NLA へ移動', context))
    row = utility.column(align=True)
    _safe_operator(row, 'armature.jiggle_bake', _root_ui_text('Bake Jiggle', 'Jiggle をベイク', context), icon='REC')
    _safe_operator_icon(row, 'scene.jiggle_reset', _root_ui_text('Reset Physics', '物理をリセット', context), icon='LOOP_BACK', custom_icon='')
    row = utility.column(align=True)
    _safe_operator(row, 'scene.jiggle_profile', _root_ui_text('Print Profiling Information', '計測結果を出力', context), icon='TEXT')
    _safe_operator(row, 'armature.add_jigglebone_preset', _root_ui_text('Save Preset', 'プリセットを保存', context), icon='ADD')
    try:
        utility.menu('JIGGLE_MT_JiggleBonePresets', text=_root_ui_text('Jiggle Bone Presets', 'Jiggle ボーンプリセット', context), icon='PRESET')
    except Exception:
        pass
    _draw_jiggle_extra_lazy_commands(layout, context)

def _draw_startup_guard_message(layout, context) -> None:
    _safe_label(layout, _root_ui_text('Smart Cloth UI is initializing.', 'Smart Cloth UI を初期化中です。', context))
    _safe_label(layout, _root_ui_text('Only lightweight N-panel shells are drawn during Blender startup.', 'Blender 起動中は軽量なNパネル外枠だけを描画します。', context), icon='TIME')

def _safe_panel_draw(draw_fn):

    def _wrapped(self, context):
        layout = self.layout
        try:
            layout.use_property_split = False
            layout.use_property_decorate = False
        except Exception:
            pass
        if not _main_panel_context_available(context):
            return None
        try:
            return draw_fn(layout, context)
        except Exception:
            try:
                layout.label(text=_root_ui_text('Panel content is temporarily unavailable.', 'パネル本文を一時的に表示できません。', context), icon='ERROR')
            except Exception:
                pass
            return None
    return _wrapped
_SCS_WORKFLOW_TOP_SECTIONS = (('integration', 'ui_open_scs_external', 'External Tool Integration', '外部ツール連携', 'LINKED', 'companion_integration'), ('workflow', 'ui_open_scs_workflow', 'Smart Workflow', 'スマートワークフロー', 'MOD_CLOTH', 'companion_workflow'), ('performance', 'ui_open_scs_performance', 'Batch / Performance', '一括処理 / パフォーマンス', 'HIDE_OFF', 'companion_performance'), ('precision', 'ui_open_scs_precision', 'Precision / Collision', '精度 / 衝突', 'MOD_PHYSICS', 'companion_precision'), ('analysis', 'ui_open_scs_analysis', 'Analysis / Diagnostics', '解析 / 診断', 'VIEWZOOM', 'companion_analysis'), ('output', 'ui_open_scs_output', 'Bake / Output', 'ベイク / 出力', 'OUTPUT', 'companion_output'))

def _draw_scs_lazy_section_tools(layout, context, section_id: str) -> None:
    section_id = str(section_id or '').strip().lower()
    rows = {'integration': ((('smart_cloth_suite.refresh_external_status', 'Refresh Status', '状態を更新', 'FILE_REFRESH', {}), ('smart_cloth_suite.open_external_preferences', 'Open Add-on Settings', 'アドオン設定を開く', 'PREFERENCES', {})),), 'workflow': ((('smart_cloth_suite.smart_setup', 'Smart Setup', 'スマートセットアップ', 'MOD_CLOTH', {}), ('smart_cloth_suite.apply_quality_profile', 'Apply Profile', 'プロファイル適用', 'PRESET', {})),), 'performance': ((('smart_cloth_suite.batch_preview', 'Apply Batch Preview', '一括プレビュー適用', 'HIDE_OFF', {'action': 'APPLY'}), ('smart_cloth_suite.batch_preview', 'Restore Preview', 'プレビュー復元', 'LOOP_BACK', {'action': 'RESTORE'})),), 'precision': ((('smart_cloth_suite.auto_collision_distance', 'Auto Distance', '距離を自動調整', 'DRIVER_DISTANCE', {}), ('smart_cloth_suite.temporal_guard', 'Temporal Guard', '時間方向ガード', 'TIME', {})), (('smart_cloth_suite.layer_clearance', 'Layer Clearance', 'レイヤー間隔', 'SORT_ASC', {}),)), 'analysis': ((('smart_cloth_suite.build_analysis_maps', 'Build Analysis Maps', '解析マップ作成', 'GROUP_VERTEX', {}), ('smart_cloth_suite.preflight', 'Run Preflight', 'プリフライト実行', 'VIEWZOOM', {})), (('smart_cloth_suite.repair_topology', 'Safe Topology Repair', '安全なトポロジー補正', 'TOOL_SETTINGS', {}),)), 'output': ((('smart_cloth_suite.safe_output', 'Safe Bake', '安全ベイク', 'REC', {'action': 'BAKE'}), ('smart_cloth_suite.safe_output', 'Safe Finish', '安全仕上げ', 'CHECKMARK', {'action': 'FINISH'})), (('smart_cloth_suite.open_data_folder', 'Open Data Folder', 'データフォルダーを開く', 'FILE_FOLDER', {}),))}
    for row_specs in rows.get(section_id, ()):
        row = layout.row(align=True)
        for operator_id, en, ja, icon, props in row_specs:
            _safe_lazy_operator(row, 'core', operator_id, _root_ui_text(en, ja, context), icon=icon, tooltip_en=f'Load Smart Cloth Suite companion controls and run {en}.', tooltip_ja=f'Smart Cloth Suite 連携機能を読み込み、「{ja}」を実行します。', **dict(props or {}))

def _draw_scs_workflow_top_section(layout, context, section_id: str, section_key: str, label_en: str, label_ja: str, icon: str, topic: str) -> None:
    body = _begin_collapsible_section(layout, context, section_key, label_en, label_ja, icon=icon, topic=topic, default=False)
    if body is _NULL_LAYOUT:
        return
    state = _RUNTIME_STATE.get('core', {})
    module = state.get('module') if isinstance(state, dict) else None
    draw_section = getattr(module, 'draw_smart_cloth_suite_section', None) if module is not None else None
    if callable(draw_section):
        try:
            draw_section(body, context, section_id)
            return
        except Exception:
            pass
    _draw_scs_lazy_section_tools(body, context, section_id)

def _draw_tool_module_group(layout, context, module_name: str, draw_fn, *, icon: str='PLUGIN') -> None:
    if not _module_visible(module_name, context):
        return
    meta = _TOOL_PANEL_META.get(str(module_name or ''), {})
    label_en = str(meta.get('name_en') or _tool_display_name(module_name, None) or module_name)
    label_ja = str(meta.get('name_ja') or label_en)
    body = _begin_collapsible_section(layout, context, f'ui_open_tool_{module_name}', label_en, label_ja, icon=icon or _tool_icon(module_name), topic=module_name, default=False)
    if body is _NULL_LAYOUT:
        return
    try:
        draw_fn(body, context)
    except Exception:
        _safe_label(body, _root_ui_text('This tool section is temporarily unavailable.', 'このツールセクションを一時的に表示できません。', context), icon='ERROR')

def _draw_smart_suite_panel(layout, context) -> None:
    entries = [
        {
            'kind': 'always_on',
            'section_key': 'show_always_on_toggles',
            'label_en': 'Always-on Toggles',
            'label_ja': '常時機能切り替え',
            'icon': 'TIME',
            'topic': 'always_on',
        },
    ]
    for section_id, section_key, label_en, label_ja, icon, topic in _SCS_WORKFLOW_TOP_SECTIONS:
        entries.append(
            {
                'kind': 'workflow',
                'section_id': section_id,
                'section_key': section_key,
                'label_en': label_en,
                'label_ja': label_ja,
                'icon': icon,
                'topic': topic,
            }
        )
    for module_name, draw_fn, icon in (
        ('quick_rigid', _draw_quick_rigid_tools, 'PHYSICS'),
        ('jiggle_physics', _draw_jiggle_tools, 'ARMATURE_DATA'),
    ):
        if not _module_visible(module_name, context):
            continue
        meta = _TOOL_PANEL_META.get(module_name, {})
        label_en = str(meta.get('name_en') or _tool_display_name(module_name, None) or module_name)
        entries.append(
            {
                'kind': 'tool',
                'module_name': module_name,
                'draw_fn': draw_fn,
                'section_key': f'ui_open_tool_{module_name}',
                'label_en': label_en,
                'label_ja': str(meta.get('name_ja') or label_en),
                'icon': icon or _tool_icon(module_name),
                'topic': module_name,
            }
        )

    top_slots = tuple(layout.row(align=False) for _unused in entries)
    top_boxes = tuple(slot.box() for slot in top_slots)
    prepared = []
    for box, entry in zip(top_boxes, entries):
        prepared_box = _begin_collapsible_section(
            layout,
            context,
            entry['section_key'],
            entry['label_en'],
            entry['label_ja'],
            icon=entry['icon'],
            topic=entry['topic'],
            default=False,
            container=box,
            defer_body=True,
        )
        prepared.append((entry, prepared_box))

    for entry, box in prepared:
        if box is _NULL_LAYOUT:
            continue
        body = box.column(align=True)
        try:
            body.use_property_split = False
            body.use_property_decorate = False
        except Exception:
            pass
        if entry['kind'] == 'always_on':
            for index, spec in enumerate(_ALWAYS_ON_SPECS):
                _draw_always_on_feature_row(body, context, spec)
                if index == 0:
                    body.separator(factor=0.5)
            continue
        if entry['kind'] == 'workflow':
            state = _RUNTIME_STATE.get('core', {})
            module = state.get('module') if isinstance(state, dict) else None
            draw_section = getattr(module, 'draw_smart_cloth_suite_section', None) if module is not None else None
            if callable(draw_section):
                try:
                    draw_section(body, context, entry['section_id'])
                    continue
                except Exception:
                    pass
            _draw_scs_lazy_section_tools(body, context, entry['section_id'])
            continue
        try:
            entry['draw_fn'](body, context)
        except Exception:
            _safe_label(body, _root_ui_text('This tool section is temporarily unavailable.', 'このツールセクションを一時的に表示できません。', context), icon='ERROR')

def _fixed_root_poll(context, physical_space: str) -> bool:
    return _main_panel_context_available(context) and manager_bridge.panel_allowed(context, physical_space=physical_space)

def _fixed_root_header(self, context) -> None:
    _help_button(self.layout, context, 'suite')

def _fixed_root_draw(self, context) -> None:
    return _safe_panel_draw(_draw_smart_suite_panel)(self, context)

class SMARTCLOTHSUITE_PT_main_panel_view3d_v283(bpy.types.Panel):
    bl_label = 'Smart Cloth'
    bl_idname = 'SMARTCLOTHSUITE_PT_main_panel_view3d_v283'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Cloth'
    bl_order = -10000
    _smart_tools_manager_tool_key = 'SMART_CLOTH'
    _smart_tools_manager_editor_keys = ('VIEW_3D',)
    _smart_tools_manager_native_fixed_root = True

    @classmethod
    def poll(cls, context):
        return _fixed_root_poll(context, 'VIEW_3D')

    draw_header_preset = _fixed_root_header

    def draw(self, context):
        return _fixed_root_draw(self, context)

class SMARTCLOTHSUITE_PT_main_panel_image_v283(bpy.types.Panel):
    bl_label = 'Smart Cloth'
    bl_idname = 'SMARTCLOTHSUITE_PT_main_panel_image_v283'
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Cloth'
    bl_order = -10000
    _smart_tools_manager_tool_key = 'SMART_CLOTH'
    _smart_tools_manager_editor_keys = ('IMAGE_EDITOR', 'UV_EDITOR')
    _smart_tools_manager_native_fixed_root = True

    @classmethod
    def poll(cls, context):
        return _fixed_root_poll(context, 'IMAGE_EDITOR')

    draw_header_preset = _fixed_root_header

    def draw(self, context):
        return _fixed_root_draw(self, context)

class SMARTCLOTHSUITE_PT_main_panel_node_v283(bpy.types.Panel):
    bl_label = 'Smart Cloth'
    bl_idname = 'SMARTCLOTHSUITE_PT_main_panel_node_v283'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Cloth'
    bl_order = -10000
    _smart_tools_manager_tool_key = 'SMART_CLOTH'
    _smart_tools_manager_editor_keys = ('SHADER_EDITOR', 'COMPOSITOR', 'GEOMETRY_NODE_EDITOR', 'TEXTURE_NODE_EDITOR')
    _smart_tools_manager_native_fixed_root = True

    @classmethod
    def poll(cls, context):
        return _fixed_root_poll(context, 'NODE_EDITOR')

    draw_header_preset = _fixed_root_header

    def draw(self, context):
        return _fixed_root_draw(self, context)

class SMARTCLOTHSUITE_PT_main_panel_sequence_v283(bpy.types.Panel):
    bl_label = 'Smart Cloth'
    bl_idname = 'SMARTCLOTHSUITE_PT_main_panel_sequence_v283'
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Cloth'
    bl_order = -10000
    _smart_tools_manager_tool_key = 'SMART_CLOTH'
    _smart_tools_manager_editor_keys = ('VIDEO_SEQUENCER',)
    _smart_tools_manager_native_fixed_root = True

    @classmethod
    def poll(cls, context):
        return _fixed_root_poll(context, 'SEQUENCE_EDITOR')

    draw_header_preset = _fixed_root_header

    def draw(self, context):
        return _fixed_root_draw(self, context)

class SMARTCLOTHSUITE_PT_main_panel_clip_v283(bpy.types.Panel):
    bl_label = 'Smart Cloth'
    bl_idname = 'SMARTCLOTHSUITE_PT_main_panel_clip_v283'
    bl_space_type = 'CLIP_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Cloth'
    bl_order = -10000
    _smart_tools_manager_tool_key = 'SMART_CLOTH'
    _smart_tools_manager_editor_keys = ('MOVIE_CLIP_EDITOR',)
    _smart_tools_manager_native_fixed_root = True

    @classmethod
    def poll(cls, context):
        return _fixed_root_poll(context, 'CLIP_EDITOR')

    draw_header_preset = _fixed_root_header

    def draw(self, context):
        return _fixed_root_draw(self, context)

class SMARTCLOTHSUITE_PT_main_panel_dopesheet_v283(bpy.types.Panel):
    bl_label = 'Smart Cloth'
    bl_idname = 'SMARTCLOTHSUITE_PT_main_panel_dopesheet_v283'
    bl_space_type = 'DOPESHEET_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Cloth'
    bl_order = -10000
    _smart_tools_manager_tool_key = 'SMART_CLOTH'
    _smart_tools_manager_editor_keys = ('DOPE_SHEET',)
    _smart_tools_manager_native_fixed_root = True

    @classmethod
    def poll(cls, context):
        return _fixed_root_poll(context, 'DOPESHEET_EDITOR')

    draw_header_preset = _fixed_root_header

    def draw(self, context):
        return _fixed_root_draw(self, context)

class SMARTCLOTHSUITE_PT_main_panel_graph_v283(bpy.types.Panel):
    bl_label = 'Smart Cloth'
    bl_idname = 'SMARTCLOTHSUITE_PT_main_panel_graph_v283'
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Cloth'
    bl_order = -10000
    _smart_tools_manager_tool_key = 'SMART_CLOTH'
    _smart_tools_manager_editor_keys = ('GRAPH_EDITOR', 'DRIVERS')
    _smart_tools_manager_native_fixed_root = True

    @classmethod
    def poll(cls, context):
        return _fixed_root_poll(context, 'GRAPH_EDITOR')

    draw_header_preset = _fixed_root_header

    def draw(self, context):
        return _fixed_root_draw(self, context)

class SMARTCLOTHSUITE_PT_main_panel_nla_v283(bpy.types.Panel):
    bl_label = 'Smart Cloth'
    bl_idname = 'SMARTCLOTHSUITE_PT_main_panel_nla_v283'
    bl_space_type = 'NLA_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Cloth'
    bl_order = -10000
    _smart_tools_manager_tool_key = 'SMART_CLOTH'
    _smart_tools_manager_editor_keys = ('NLA_EDITOR',)
    _smart_tools_manager_native_fixed_root = True

    @classmethod
    def poll(cls, context):
        return _fixed_root_poll(context, 'NLA_EDITOR')

    draw_header_preset = _fixed_root_header

    def draw(self, context):
        return _fixed_root_draw(self, context)

class SMARTCLOTHSUITE_PT_main_panel_text_v283(bpy.types.Panel):
    bl_label = 'Smart Cloth'
    bl_idname = 'SMARTCLOTHSUITE_PT_main_panel_text_v283'
    bl_space_type = 'TEXT_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Cloth'
    bl_order = -10000
    _smart_tools_manager_tool_key = 'SMART_CLOTH'
    _smart_tools_manager_editor_keys = ('TEXT_EDITOR',)
    _smart_tools_manager_native_fixed_root = True

    @classmethod
    def poll(cls, context):
        return _fixed_root_poll(context, 'TEXT_EDITOR')

    draw_header_preset = _fixed_root_header

    def draw(self, context):
        return _fixed_root_draw(self, context)

class SMARTCLOTHSUITE_PT_main_panel_file_v283(bpy.types.Panel):
    bl_label = 'Smart Cloth'
    bl_idname = 'SMARTCLOTHSUITE_PT_main_panel_file_v283'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'UI'
    bl_category = 'Smart Cloth'
    bl_order = -10000
    _smart_tools_manager_tool_key = 'SMART_CLOTH'
    _smart_tools_manager_editor_keys = ('FILE_BROWSER',)
    _smart_tools_manager_native_fixed_root = True

    @classmethod
    def poll(cls, context):
        return (manager_bridge.logical_editor_key(context) == 'FILE_BROWSER'
                and _fixed_root_poll(context, 'FILE_BROWSER'))

    draw_header_preset = _fixed_root_header

    def draw(self, context):
        return _fixed_root_draw(self, context)

class SMARTCLOTHSUITE_PT_main_panel_asset_v283(bpy.types.Panel):
    bl_label = 'Smart Cloth'
    bl_idname = 'SMARTCLOTHSUITE_PT_main_panel_asset_v283'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOL_PROPS'
    bl_options = {'DEFAULT_CLOSED'}
    bl_category = 'Smart Cloth'
    bl_order = -10000
    _smart_tools_manager_tool_key = 'SMART_CLOTH'
    _smart_tools_manager_editor_keys = ('ASSET_BROWSER',)
    _smart_tools_manager_native_fixed_root = True

    @classmethod
    def poll(cls, context):
        return (manager_bridge.logical_editor_key(context) == 'ASSET_BROWSER'
                and _fixed_root_poll(context, 'FILE_BROWSER'))

    draw_header_preset = _fixed_root_header

    def draw(self, context):
        return _fixed_root_draw(self, context)

class SMARTCLOTHSUITE_PT_main_panel_spreadsheet_v283(bpy.types.Panel):
    bl_label = 'Smart Cloth'
    bl_idname = 'SMARTCLOTHSUITE_PT_main_panel_spreadsheet_v283'
    bl_space_type = 'SPREADSHEET'
    bl_region_type = 'UI'
    bl_category = 'Smart Cloth'
    bl_order = -10000
    _smart_tools_manager_tool_key = 'SMART_CLOTH'
    _smart_tools_manager_editor_keys = ('SPREADSHEET',)
    _smart_tools_manager_native_fixed_root = True

    @classmethod
    def poll(cls, context):
        return _fixed_root_poll(context, 'SPREADSHEET')

    draw_header_preset = _fixed_root_header

    def draw(self, context):
        return _fixed_root_draw(self, context)
_MAIN_PANEL_CLASSES = (SMARTCLOTHSUITE_PT_main_panel_view3d_v283, SMARTCLOTHSUITE_PT_main_panel_image_v283, SMARTCLOTHSUITE_PT_main_panel_node_v283, SMARTCLOTHSUITE_PT_main_panel_sequence_v283, SMARTCLOTHSUITE_PT_main_panel_clip_v283, SMARTCLOTHSUITE_PT_main_panel_dopesheet_v283, SMARTCLOTHSUITE_PT_main_panel_graph_v283, SMARTCLOTHSUITE_PT_main_panel_nla_v283, SMARTCLOTHSUITE_PT_main_panel_text_v283, SMARTCLOTHSUITE_PT_main_panel_file_v283, SMARTCLOTHSUITE_PT_main_panel_asset_v283, SMARTCLOTHSUITE_PT_main_panel_spreadsheet_v283)
SMARTCLOTHSUITE_PT_main_panel = SMARTCLOTHSUITE_PT_main_panel_view3d_v283
_ROOT_RUNTIME_CLASSES = (SMARTCLOTHSUITE_OT_show_help_popup, SMARTCLOTHSUITE_OT_toggle_ui_section, SMARTCLOTHSUITE_OT_toggle_standard_npanel_tool, SMARTCLOTHSUITE_OT_lazy_execute_tool, SMARTCLOTHSUITE_OT_toggle_always_on_feature, SMARTCLOTHSUITE_OT_toggle_tool_panel_visibility, SMARTCLOTHSUITE_OT_disable_all_always_on_features, SMARTCLOTHSUITE_OT_toggle_jiggle_overlay_runtime, *_MAIN_PANEL_CLASSES)

def _safe_register_runtime_class(cls: type) -> None:
    lifecycle.register_class(cls, scope='runtime.root')

def _safe_unregister_runtime_class(cls: type) -> None:
    del cls
    lifecycle.release_scope('runtime.root')

def cleanup_stale_blend_proxy_data(context=None, *, reason: str='') -> int:
    del context, reason
    return 0

def _register_root_runtime_classes() -> None:
    mark = lifecycle.checkpoint()
    try:
        for cls in _ROOT_RUNTIME_CLASSES:
            lifecycle.register_class(cls, scope='runtime.root')
    except Exception:
        lifecycle.rollback_to(mark)
        raise

def _unregister_root_runtime_classes() -> None:
    lifecycle.release_scope('runtime.root')

def _cancel_deferred_core_runtime_initialization() -> None:
    return None

@persistent
def _smart_suite_load_post_restore(_scene=None) -> None:
    global _SCENE_SWITCH_SUSPENDED
    previous = bool(_SCENE_SWITCH_SUSPENDED)
    _SCENE_SWITCH_SUSPENDED = True
    try:
        context = getattr(bpy, 'context', None)
        _RESTORED_SCENE_KEYS.clear()
        reload_settings = getattr(_preferences_module(), 'reload_runtime_settings', None)
        if callable(reload_settings):
            reload_settings(context)
        manager_bridge.bind(context)
        _apply_saved_always_on_preferences(context, startup=False)
        _ensure_scene_npanel_settings_restored(context)
        for module_name, _friendly_name in _STANDARD_NPANEL_TOOLS:
            if _tool_loaded(module_name):
                _sync_always_on_preferences_for_loaded_module(context, module_name)
        module = _jiggle_module()
        clear_debug = getattr(module, 'clear_debug_runtime_data', None) if module is not None else None
        if callable(clear_debug):
            clear_debug()
    except Exception:
        settings_io.mark_dirty()
    finally:
        _SCENE_SWITCH_SUSPENDED = previous
        _capture_window_scene_names()

def _register_load_post_restore_handler() -> None:
    lifecycle.register_handler(bpy.app.handlers.load_post, _smart_suite_load_post_restore, scope='runtime.lifecycle')

def _unregister_load_post_restore_handler() -> None:
    lifecycle.release_scope('runtime.lifecycle')

def _remove_stale_handler_entries(collection, desired) -> None:
    del collection, desired
    return None

def _window_scene_name(window) -> str:
    try:
        scene = getattr(window, 'scene', None)
        return str(getattr(scene, 'name_full', '') or getattr(scene, 'name', '') or '')
    except Exception:
        return ''

def _capture_window_scene_names() -> None:
    _LAST_WINDOW_SCENE_NAMES.clear()
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        for window in tuple(getattr(wm, 'windows', ()) or ()):
            try:
                pointer = int(window.as_pointer())
            except Exception:
                pointer = id(window)
            _LAST_WINDOW_SCENE_NAMES[pointer] = _window_scene_name(window)
    except Exception:
        pass

def _process_scene_switches() -> bool:
    if bool(_SCENE_SWITCH_SUSPENDED):
        return True
    context = getattr(bpy, 'context', None)
    if context is None:
        return True
    try:
        wm = getattr(context, 'window_manager', None)
        windows = tuple(getattr(wm, 'windows', ()) or ())
    except Exception:
        windows = ()
    current_pointers: set[int] = set()
    changes: list[tuple[str, object]] = []
    for window in windows:
        try:
            pointer = int(window.as_pointer())
        except Exception:
            pointer = id(window)
        current_pointers.add(pointer)
        new_name = _window_scene_name(window)
        old_name = _LAST_WINDOW_SCENE_NAMES.get(pointer, '')
        _LAST_WINDOW_SCENE_NAMES[pointer] = new_name
        if old_name and new_name and (old_name != new_name):
            changes.append((old_name, getattr(window, 'scene', None)))
    for pointer in tuple(_LAST_WINDOW_SCENE_NAMES):
        if pointer not in current_pointers:
            _LAST_WINDOW_SCENE_NAMES.pop(pointer, None)
    if not changes:
        return True
    ok = _save_root_preferences(context, force=True)
    saved_old: set[str] = set()
    state = _read_runtime_state_file()
    for old_name, new_scene in changes:
        if old_name not in saved_old:
            old_scene = bpy.data.scenes.get(old_name)
            if old_scene is not None:
                ok = _save_scene_npanel_runtime_state(old_scene, context, force=True) and ok
            saved_old.add(old_name)
        if new_scene is None:
            continue
        _apply_saved_npanel_settings_to_scene(new_scene, '', state)
        try:
            key = str(new_scene.as_pointer())
        except Exception:
            key = str(getattr(new_scene, 'name_full', '') or getattr(new_scene, 'name', '') or '')
        if key:
            _RESTORED_SCENE_KEYS[key] = _saved_scene_settings_fingerprint()
            _prune_restored_scene_keys(key)
    if not ok:
        settings_io.mark_dirty()
    return bool(ok)

def _scene_switch_notify() -> None:
    try:
        if not _process_scene_switches():
            settings_io.mark_dirty()
    except Exception:
        settings_io.mark_dirty()

def _register_scene_switch_monitor() -> None:
    _capture_window_scene_names()
    lifecycle.register_msgbus(key=(bpy.types.Window, 'scene'), notify=_scene_switch_notify, scope='runtime.lifecycle', options={'PERSISTENT'})

def _unregister_scene_switch_monitor() -> None:
    _LAST_WINDOW_SCENE_NAMES.clear()
    lifecycle.release_scope('runtime.lifecycle')

@persistent
def _smart_suite_scene_close_persist_handler(*_args) -> None:
    global _SCENE_SWITCH_SUSPENDED
    previous = bool(_SCENE_SWITCH_SUSPENDED)
    _SCENE_SWITCH_SUSPENDED = True
    try:
        context = getattr(bpy, 'context', None)
        snapshot = _current_scene_settings_snapshot(context)
        preferences_ok = _save_root_preferences(context, force=True)
        scene_ok = _merge_scene_snapshot_into_runtime_state(snapshot, preserve_unresolved_pointers=True, preserve_existing_named_pointers=True)
        core_state = _RUNTIME_STATE.get('core', {})
        core_module = core_state.get('module') if isinstance(core_state, dict) else None
        core_operators = getattr(core_module, 'operators', None) if core_module is not None else None
        cancel_core = getattr(core_operators, 'cancel_active_safe_output_transaction', None) if core_operators is not None else None
        if callable(cancel_core):
            cancel_core()
        module = _jiggle_module()
        cancel = getattr(module, 'cancel_active_bake_transaction', None) if module is not None else None
        if callable(cancel):
            cancel()
        clear_debug = getattr(module, 'clear_debug_runtime_data', None) if module is not None else None
        if callable(clear_debug):
            clear_debug()
        if not (preferences_ok and scene_ok):
            settings_io.mark_dirty()
    except Exception:
        settings_io.mark_dirty()
    finally:
        _SCENE_SWITCH_SUSPENDED = previous

@persistent
def _smart_suite_blend_save_persist_handler(*_args) -> None:
    """Save during .blend save only while continuous N-panel State Save is enabled."""
    try:
        context = getattr(bpy, 'context', None)
        cleanup_stale_blend_proxy_data(context, reason='save')
        if not _suite_npanel_persistence_enabled(context):
            return
        if not _persistence_context_safe(context):
            return
        _persist_npanel_runtime_state(context, force=False)
    except Exception:
        settings_io.mark_dirty()

@persistent
def _smart_suite_blend_post_save_persist_handler(*_args) -> None:
    """Save external N-panel JSON after .blend save without touching .blend ID data."""
    try:
        context = getattr(bpy, 'context', None)
        if not _suite_npanel_persistence_enabled(context):
            return
        if not _persistence_context_safe(context):
            return
        _persist_npanel_runtime_state(context, force=False)
    except Exception:
        settings_io.mark_dirty()

@persistent
def _smart_suite_undo_redo_persist_handler(*_args) -> None:
    """Keep external N-panel JSON aligned after Blender Undo/Redo restores RNA."""
    try:
        context = getattr(bpy, 'context', None)
        if not _suite_npanel_persistence_enabled(context):
            return
        if not _persistence_context_safe(context):
            return
        _persist_npanel_runtime_state(context, force=False)
    except Exception:
        settings_io.mark_dirty()

def _register_persistence_handlers() -> None:
    handlers = bpy.app.handlers
    mapping = ((handlers.load_pre, _smart_suite_scene_close_persist_handler), (handlers.exit_pre, _smart_suite_scene_close_persist_handler), (handlers.save_pre, _smart_suite_blend_save_persist_handler), (handlers.save_post, _smart_suite_blend_post_save_persist_handler), (handlers.undo_post, _smart_suite_undo_redo_persist_handler), (handlers.redo_post, _smart_suite_undo_redo_persist_handler))
    for collection, callback in mapping:
        lifecycle.register_handler(collection, callback, scope='runtime.lifecycle')

def _unregister_persistence_handlers() -> None:
    lifecycle.release_scope('runtime.lifecycle')

def _register_preference_save_checkpoint_timer() -> None:
    return None

def _unregister_preference_save_checkpoint_timer() -> None:
    return None
_PERSISTENCE_TIMER_ACTIVE = False

def _smart_suite_periodic_persist_timer():
    return None

def _register_persistence_timer() -> None:
    return None

def _unregister_persistence_timer() -> None:
    return None

def _register_stale_proxy_cleanup_timer() -> None:
    return None

def _unregister_stale_proxy_cleanup_timer() -> None:
    return None

def schedule_core_runtime_initialization(context=None) -> bool:
    return ensure_core_runtime_initialized(context=context)

def ensure_core_runtime_initialized(context=None) -> bool:
    for module_name, friendly_name in _STANDARD_NPANEL_TOOLS:
        if _tool_loaded(module_name):
            continue
        try:
            _enable_tool(module_name, friendly_name, context=context)
        except Exception:
            return False
    return _suite_core_runtime_loaded()

def ensure_runtime_initialized(context=None) -> bool:
    return ensure_core_runtime_initialized(context=context)

def register() -> None:
    global _STARTUP_PANEL_GUARD_UNTIL
    _STARTUP_PANEL_GUARD_UNTIL = 0.0
    _invalidate_runtime_ui_caches()
    mark = lifecycle.checkpoint()
    enabled_modules: list[str] = []
    try:
        icon_module = importlib.import_module('.ui_icons', _ROOT_PACKAGE or __name__)
        load_icons = getattr(icon_module, 'load_icons', None)
        if callable(load_icons):
            load_icons()
        lifecycle.record_cleanup(icon_module, lambda _module=icon_module: getattr(_module, 'unload_icons', lambda: None)(), scope='runtime.icons', kind='ICON_RESOURCE')
        manager_bridge.bind(getattr(bpy, 'context', None))
        lifecycle.record_cleanup(manager_bridge, manager_bridge.unbind, scope='runtime.manager', kind='MANAGER_BINDING')
        _register_root_runtime_classes()
        preferences_module = _preferences_module()
        preferences_module.register()
        context = getattr(bpy, 'context', None)
        for module_name, friendly_name in _STANDARD_NPANEL_TOOLS:
            _enable_tool(module_name, friendly_name, context=context)
            enabled_modules.append(module_name)
        _apply_saved_always_on_preferences(context, startup=True)
        _ensure_scene_npanel_settings_restored(context)
        _register_load_post_restore_handler()
        _register_persistence_handlers()
        _register_scene_switch_monitor()
    except Exception:
        for module_name in reversed(enabled_modules):
            try:
                _disable_tool(module_name)
            except Exception:
                pass
        try:
            _preferences_module().unregister(persist=False)
        except Exception:
            pass
        lifecycle.rollback_to(mark)
        _RUNTIME_STATE.clear()
        _INTEGRATED_RUNTIME_STATE.clear()
        _RUNTIME_UI_SECTION_STATES.clear()
        globals()['_PREFERENCES_MODULE'] = None
        globals()['_HELP_POPUP_MODULE'] = None
        raise

def unregister() -> None:
    global _PREFERENCES_MODULE, _HELP_POPUP_MODULE
    global _LAST_NPANEL_STATE_CACHE, _LAST_NPANEL_STATE_FINGERPRINT
    global _LAST_NPANEL_STATE_PATH, _LAST_NPANEL_STATE_MTIME, _LAST_PERSIST_TIME
    context = getattr(bpy, 'context', None)
    try:
        _persist_npanel_runtime_state(context, force=True)
    except Exception:
        settings_io.mark_dirty()
    core_state = _RUNTIME_STATE.get('core', {})
    core_module = core_state.get('module') if isinstance(core_state, dict) else None
    core_operators = getattr(core_module, 'operators', None) if core_module is not None else None
    cancel_core = getattr(core_operators, 'cancel_active_safe_output_transaction', None) if core_operators is not None else None
    if callable(cancel_core):
        try:
            cancel_core()
        except Exception:
            pass
    module = _jiggle_module()
    if module is not None:
        for name in ('cancel_active_bake_transaction', 'clear_debug_runtime_data'):
            fn = getattr(module, name, None)
            if callable(fn):
                try:
                    fn()
                except Exception:
                    pass
    _disable_quick_rigid_always_on_features(context)
    _disable_jiggle_always_on_features(context)
    for module_name, _friendly_name in reversed(_STANDARD_NPANEL_TOOLS):
        try:
            _disable_tool(module_name)
        except Exception:
            pass
    try:
        _preferences_module().unregister()
    except Exception:
        pass
    lifecycle.release_scope('runtime.lifecycle')
    lifecycle.release_scope('runtime.root')
    lifecycle.release_scope('runtime.manager')
    lifecycle.release_scope('runtime.icons')
    manager_bridge.unbind()
    _RUNTIME_STATE.clear()
    _INTEGRATED_RUNTIME_STATE.clear()
    _RESTORED_SCENE_KEYS.clear()
    _LAST_WINDOW_SCENE_NAMES.clear()
    _RUNTIME_UI_SECTION_STATES.clear()
    _LAST_NPANEL_STATE_CACHE = None
    _LAST_NPANEL_STATE_FINGERPRINT = ''
    _LAST_NPANEL_STATE_PATH = ''
    _LAST_NPANEL_STATE_MTIME = 0.0
    _LAST_PERSIST_TIME = 0.0
    _PREFERENCES_MODULE = None
    _HELP_POPUP_MODULE = None
    _invalidate_runtime_ui_caches()
