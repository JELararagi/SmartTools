"""Observe evaluated baked Cloth in world space and animate an isolated, owned helper rig."""
from dataclasses import dataclass
from uuid import uuid4
from hashlib import sha256
from math import isfinite
from mathutils import Vector,Matrix
import bpy,json
PROFILE='_smart_cloth_suite_bone_bridge_v1'
OWNER='_smart_cloth_suite_bone_bridge_owner_v1'
@dataclass(frozen=True)
class BridgeStatusV1:
    contract_version:int
    state:str
    armature_name:str
    source_name:str
    driven_bones:tuple
    reason:str
def profile(rig):return json.loads(rig.get(PROFILE,'{}'))
def status(rig,garment=None):
    name=rig.name if rig else '';source='';bones=()
    def result(state,reason=''):return BridgeStatusV1(1,state,name,source,bones,reason)
    if not rig or rig.type!='ARMATURE':return result('INVALID','missing_armature')
    try:p=profile(rig)
    except (ValueError,TypeError):return result('INVALID','invalid_profile')
    all_outputs=[(b.name,c) for b in rig.pose.bones for c in b.constraints if c.type=='COPY_TRANSFORMS' and c.target and c.target.get(OWNER)]
    if not p:return result('INVALID','orphan_owned_output') if all_outputs else result('ABSENT')
    source=p.get('source','');bones=tuple(row['bone'] for row in p.get('constraints',[]))
    if garment and garment.name!=source:return result('INVALID','source_mismatch')
    helper=bpy.data.objects.get(p.get('helper',''));token=p.get('token');saved=p.get('mode')
    if saved not in ('CLOTH_BAKED','STANDARD'):return result('INVALID','unknown_saved_mode')
    if not helper or helper.type!='ARMATURE' or helper.get('sc_bridge_id')!=p.get('helper_id') or helper.get(OWNER)!=token or helper.data.get(OWNER)!=token:return result('INVALID','missing_helper')
    action=helper.animation_data.action if helper.animation_data else None
    if not action or action.get(OWNER)!=token:return result('INVALID','missing_owned_action')
    expected={(r['bone'],r['name']) for r in p['constraints']}
    if any((n,c.name) not in expected for n,c in all_outputs if c.target==helper):return result('INVALID','unrecorded_owned_output')
    for row in p['constraints']:
        b=rig.pose.bones.get(row['bone']);co=b.constraints.get(row['name']) if b else None
        if row['helper_bone'] not in helper.data.bones:return result('INVALID','missing_helper_bone')
        if not co or co.type!='COPY_TRANSFORMS' or co.target!=helper or co.subtarget!=row['helper_bone'] or co.owner_space!='WORLD' or co.target_space!='WORLD':return result('INVALID','invalid_constraint')
        if not isfinite(co.influence):return result('INVALID','missing_or_nonfinite_owned_influence')
        if co.influence<.99999:return result('MIXED','owned_output_influence_not_full')
        if co.mute!=(saved=='STANDARD'):return result('MIXED','owned_output_mute')
    return result(saved)
def mode(rig,new):
    p=profile(rig);state=status(rig)
    if state.state in ('ABSENT','INVALID'):raise ValueError(state.reason or 'Prepare the bridge first.')
    for row in p['constraints']:
        co=rig.pose.bones[row['bone']].constraints[row['name']];co.influence=1;co.mute=new=='STANDARD'
    p['mode']=new;rig[PROFILE]=json.dumps(p)
def clear(rig):
    p=profile(rig)
    if not p:return
    state=status(rig)
    if state.state=='INVALID':raise ValueError(state.reason)
    for row in p['constraints']:
        b=rig.pose.bones[row['bone']];b.constraints.remove(b.constraints[row['name']])
    helper=bpy.data.objects[p['helper']];data=helper.data;action=helper.animation_data.action;bpy.data.objects.remove(helper,do_unlink=True)
    if not data.users:bpy.data.armatures.remove(data)
    if action and not action.users:bpy.data.actions.remove(action)
    del rig[PROFILE]
def plan(ctx,c):
    g=c.bridge_source_mesh or c.skirt_garment;r=c.bridge_target_armature or c.skirt_armature
    if not g or not r or g.type!='MESH' or r.type!='ARMATURE':raise ValueError('Choose a fabric mesh and armature.')
    m=next((m for m in g.modifiers if m.type=='CLOTH'),None)
    if not m or not m.point_cache.is_baked:raise ValueError('Bake the Cloth point cache first.')
    a,b=c.bridge_frame_start,c.bridge_frame_end
    if not m.point_cache.frame_start<=a<=b<=m.point_cache.frame_end:raise ValueError('Choose a range inside the baked cache.')
    selected=[p for p in r.pose.bones if p.select];tree={p.name for p in selected};children=[p for p in selected if p.parent and p.parent.name in tree];roots=[p.name for p in selected if p not in children]
    if not children:raise ValueError('Select a weighted child bone and its fixed parent.')
    indices={}
    for p in children:
        if any(not ct.mute and ct.influence>0 for ct in p.constraints):raise ValueError('An active constraint already controls '+p.name)
        for name in (p.name,p.parent.name):
            group=g.vertex_groups.get(name)
            if not group:raise ValueError('Missing garment weights for '+name)
            points=[(v.index,x.weight) for v in g.data.vertices for x in v.groups if x.group==group.index and x.weight>0]
            if not points:raise ValueError('Empty weights for '+name)
            indices[name]=points
        for other in ctx.scene.objects:
            if other.type!='MESH' or other==g or other.find_armature()!=r:continue
            group=other.vertex_groups.get(p.name)
            if group and any(x.group==group.index and x.weight>0 for v in other.data.vertices for x in v.groups):raise ValueError('The driven bone also deforms '+other.name)
    if (b-a+1)*sum(map(len,indices.values()))>24000000:raise ValueError('Choose a shorter sample range.')
    return g,r,m,children,roots,indices,range(a,b+1)
def sample(ctx,g,r,m,children,indices,frames):
    scene=ctx.scene;current=scene.frame_current;result=[];base=None;last_topology=len(g.data.vertices);moving=0
    try:
        for f in frames:
            scene.frame_set(f);dg=ctx.evaluated_depsgraph_get();evaluated=g.evaluated_get(dg);em=evaluated.modifiers.get(m.name)
            if not em or not em.show_viewport or not em.point_cache.is_baked:raise ValueError(f'Cloth is inactive at frame {f}.')
            verts=evaluated.data.vertices
            if len(verts)!=last_topology:raise ValueError('Changing topology requires a fixed simulation surface.')
            centers={n:sum((evaluated.matrix_world@verts[i].co*w for i,w in points),Vector())/sum(w for i,w in points) for n,points in indices.items()}
            if not all(isfinite(v) for point in centers.values() for v in point):raise ValueError('Nonfinite sampled coordinates.')
            if base is None:base={n:v.copy() for n,v in centers.items()}
            poses={}
            for bone in children:
                k=bone.name;parent=bone.parent.name;rot0=base[k]-base[parent];rot1=centers[k]-centers[parent];p=r.evaluated_get(dg).pose.bones[k];mat=r.matrix_world@p.matrix
                if rot0.length>1e-7 and rot1.length>1e-7:mat=rot0.rotation_difference(rot1).to_matrix().to_4x4()@mat
                mat.translation=r.matrix_world@p.head+(centers[k]-base[k]);poses[k]=r.matrix_world.inverted_safe()@mat
                moving=max(moving,(centers[k]-base[k]).length)
            result.append((f,poses))
    finally:scene.frame_set(current)
    return result,moving
def bake(ctx,c):
    g,r,m,children,roots,indices,frames=plan(ctx,c)
    if status(r).state!='ABSENT':raise ValueError('Clear the existing bridge before replacing it.')
    samples,motion=sample(ctx,g,r,m,children,indices,frames);token=uuid4().hex;original_frame=ctx.scene.frame_current
    # Copy the skeleton data so the source armature, its animation and its active action slot remain intact.
    data=r.data.copy();data[OWNER]=token;helper=bpy.data.objects.new('SC_BoneBridge_'+token[:8],data);helper[OWNER]=token;helper['sc_bridge_id']=uuid4().hex;ctx.collection.objects.link(helper);helper.matrix_world=r.matrix_world;helper.hide_render=True;ctx.view_layer.update()
    records=[];action=None
    try:
        action=bpy.data.actions.new(helper.name+'Action');action[OWNER]=token;helper.animation_data_create().action=action
        for f,matrices in samples:
            for b in children:
                p=helper.pose.bones[b.name];p.rotation_mode='QUATERNION';p.matrix=matrices[b.name]
                for channel in ('location','rotation_quaternion','scale'):p.keyframe_insert(data_path=channel,frame=f,group=b.name)
        for i,b in enumerate(children):
            co=b.constraints.new('COPY_TRANSFORMS');co.name='SCB_'+token[:8]+f'_{i:03}';co.target=helper;co.subtarget=b.name;co.owner_space=co.target_space='WORLD';records.append(dict(bone=b.name,name=co.name,helper_bone=b.name))
        p=dict(schema=1,token=token,helper=helper.name,helper_id=helper['sc_bridge_id'],source=g.name,armature=r.name,frame_start=frames.start,frame_end=frames.stop-1,fps=ctx.scene.render.fps,fps_base=ctx.scene.render.fps_base,fixed_roots=roots,topology_sha256=sha256(str([(p.index,tuple(p.vertices)) for p in g.data.polygons]).encode()).hexdigest(),constraints=records,mode='CLOTH_BAKED',max_sample_displacement=motion)
        r[PROFILE]=json.dumps(p);helper.hide_set(True)
    except Exception:
        for row in records:
            b=r.pose.bones[row['bone']];b.constraints.remove(b.constraints[row['name']])
        bpy.data.objects.remove(helper,do_unlink=True)
        if not data.users:bpy.data.armatures.remove(data)
        if action and not action.users:bpy.data.actions.remove(action)
        raise
    finally:ctx.scene.frame_set(original_frame)
def execute(key,op,ctx):
    c=ctx.scene.smart_cloth_suite_companion;rig=c.bridge_target_armature or c.skirt_armature
    if key=='bridge_preview':
        g,r,m,children,roots,indices,frames=plan(ctx,c);c.last_status=f'{len(children)} driven bones / {len(frames)} frames'
    elif key=='bridge_bake':bake(ctx,c)
    elif not rig:raise ValueError('Choose the bridge target armature.')
    elif key=='bridge_mode':mode(rig,op.mode)
    else:clear(rig)
