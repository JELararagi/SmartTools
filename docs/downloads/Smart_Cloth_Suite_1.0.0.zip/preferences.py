"""Public suite settings entry points, including an immediate save and reload."""
from . import persistence,properties
def get_root_preferences(context=None):return properties.prefs(context)
def peek_root_preferences(context=None):return properties.prefs(context)
def save_runtime_settings(context=None):
    try:persistence.save(context,force=True);return True
    except (ValueError,OSError):return False
def save_root_preferences(context=None):return save_runtime_settings(context)
def reload_runtime_settings(context=None):persistence.load();return properties.prefs(context)
def load_root_preferences(context=None):return reload_runtime_settings(context)
def get_runtime_bool(name,default=False,context=None):return bool(getattr(properties.prefs(context),name,default))
def set_runtime_bool(name,value,context=None):
    p=properties.prefs(context)
    if not p or name not in properties.DATA['groups']['SMARTCLOTHSUITE_PG_RuntimePreferences'] or not isinstance(getattr(p,name),bool):return False
    setattr(p,name,bool(value));return True
