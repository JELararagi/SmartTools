# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Detailed locale-aware help for the Smart Cloth Suite N-panel."""

from __future__ import annotations

import textwrap
import bpy


def _is_japanese(context=None) -> bool:
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        return (locale or language).lower().startswith('ja')
    except Exception:
        return False


def _t(pair, context=None) -> str:
    en, ja = pair
    return str(ja if _is_japanese(context) else en)


def _item(en: str, ja: str, desc_en: str, desc_ja: str):
    return ((en, ja), (desc_en, desc_ja))


_TOPICS = {
    'suite': {
        'title': ('Smart Cloth Suite', 'Smart Cloth Suite'),
        'overview': (
            'Smart Cloth Suite is a companion workflow for a separately installed Simply Cloth Studio. It does not contain or import the external implementation. It calls only the external add-on’s public Blender operators, then adds batch setup, reversible performance controls, adaptive collision spacing, analysis, diagnostics, guarded output, Quick Rigid, and Jiggle Physics.',
            'Smart Cloth Suite は、別途インストールされた Simply Cloth Studio と併用する連携ツールです。外部ツールの実装は含まず、公開された操作だけを呼び出します。その上で、一括セットアップ、復元可能な軽量化、自動衝突間隔、解析、診断、安全確認付き出力、Quick Rigid、Jiggle Physicsを追加します。',
        ),
        'steps': (
            ('Install and enable Simply Cloth Studio as a separate Blender Extension.', 'Simply Cloth Studio を別の拡張機能としてインストールし、有効化します。'),
            ('Open the Smart Cloth N-panel and confirm that External Tool Integration reports Ready.', 'Smart Cloth Nパネルを開き、「外部ツール連携」が使用可能と表示されることを確認します。'),
            ('Set the body collider, optional collider collection, target scope, and quality profile.', 'ボディコライダー、必要に応じてコライダーコレクション、対象範囲、品質プロファイルを設定します。'),
            ('Run Smart Setup for a complete setup pass, or use the individual sections for targeted adjustments.', '一括設定にはスマートセットアップを実行し、個別調整には各セクションのコマンドを使用します。'),
            ('Run Preflight before bake or finish. Safe Bake and Safe Finish can stop when blocking errors are detected.', 'ベイクまたは仕上げ前にプリフライトを実行します。安全ベイク / 安全仕上げは重大エラー時に停止できます。'),
        ),
        'controls': (
            _item('Always-on Toggles', '常時機能切り替え', 'Controls persistent N-panel saving and the optional Jiggle callbacks/overlays. Disabled runtime entries install no continuous handlers.', 'Nパネル設定保存と、任意のJiggleコールバック / オーバーレイを制御します。無効なランタイム項目は常駐ハンドラを登録しません。'),
            _item('External Tool Integration', '外部ツール連携', 'Checks the external installation and defines body/collider targets.', '外部ツールの状態を確認し、ボディ / コライダー対象を指定します。'),
            _item('Smart Workflow', 'スマートワークフロー', 'Runs external cloth creation followed by Smart Cloth Suite extensions as one user operation.', '外部クロス作成とSmart Cloth Suiteの拡張処理を、ユーザーの1操作としてまとめて実行します。'),
            _item('Batch / Performance', '一括処理 / パフォーマンス', 'Applies profiles to multiple cloth objects and creates a reversible low-cost preview state.', '複数クロスへ品質プロファイルを適用し、復元可能な低負荷プレビュー状態を作成します。'),
            _item('Precision / Collision', '精度 / 衝突', 'Calculates mesh-aware collision distance, temporal padding, and garment-layer clearance.', 'メッシュ密度に応じた衝突距離、時間方向パディング、衣服レイヤー間隔を計算します。'),
            _item('Analysis / Diagnostics', '解析 / 診断', 'Builds non-destructive analysis groups, reports setup risks, and performs conservative topology repair.', '非破壊解析グループ、セットアップ危険度レポート、保守的なトポロジー補正を提供します。'),
            _item('Bake / Output', 'ベイク / 出力', 'Runs preflight before external bake/finish and stores reports in the Smart Cloth Suite config folder.', '外部ベイク / 仕上げ前にプリフライトを行い、Smart Cloth Suite設定フォルダーへレポートを保存します。'),
        ),
    },
    'always_on': {
        'title': ('Always-on Toggles', '常時機能切り替え'),
        'overview': (
            'This section contains only settings that require persistent behavior or control when persistent behavior is allowed. N-panel State Save is listed first. Jiggle runtime entries remain disabled until explicitly enabled.',
            'このセクションには、継続動作が必要な設定、または継続動作の可否を制御する設定だけを表示します。「Nパネル状態保存」を先頭に配置し、Jiggleランタイム項目は明示的に有効化するまで停止しています。',
        ),
        'steps': (
            ('Enable N-panel State Save to write every setting change immediately.', '各設定変更を即時保存する場合は「Nパネル状態保存」を有効にします。'),
            ('Disable it to defer ordinary writes until file/scene switching, preference save, or add-on shutdown.', '通常の書き込みをファイル / シーン切り替え、プリファレンス保存、アドオン終了時まで遅らせる場合は無効にします。'),
            ('Enable Jiggle Callbacks only while live Jiggle evaluation is required.', 'ライブJiggle評価が必要な間だけ「Jiggle コールバック」を有効にします。'),
            ('Enable each overlay only when it must be drawn in the 3D View.', '各オーバーレイは3Dビューへ描画する必要がある場合だけ有効にします。'),
        ),
        'controls': (
            _item('N-panel State Save', 'Nパネル状態保存', 'Enabled: all N-panel settings are immediately written to config/Smart_Cloth_Suite/Smart_Cloth_Suite.json. Disabled: ordinary changes remain in memory and are written at the defined checkpoints.', '有効時は全Nパネル設定を config/Smart_Cloth_Suite/Smart_Cloth_Suite.json へ即時保存します。無効時は通常変更をメモリに保持し、指定の保存タイミングで書き込みます。'),
            _item('Jiggle Callbacks', 'Jiggle コールバック', 'Installs Jiggle frame/playback/render evaluation callbacks. Leave disabled when live secondary motion is not needed.', 'Jiggleのフレーム / 再生 / レンダー評価コールバックを登録します。ライブ二次揺れが不要な場合は無効にします。'),
            _item('Jiggle Rest Pose', 'Jiggle レスト姿勢', 'Draws the Jiggle rest-pose guide in 3D View areas.', '3DビューにJiggleレスト姿勢ガイドを描画します。'),
            _item('Jiggle Simulation', 'Jiggle シミュレーション', 'Draws the evaluated Jiggle simulation guide in 3D View areas.', '3Dビューに評価済みJiggleシミュレーションガイドを描画します。'),
        ),
    },
    'companion_integration': {
        'title': ('External Tool Integration', '外部ツール連携'),
        'overview': (
            'Detects the separately installed Simply Cloth Studio extension, its enabled state, version, and required public operators. No external implementation is copied into Smart Cloth Suite.',
            '別途インストールされた Simply Cloth Studio のインストール状態、有効状態、バージョン、必須公開オペレーターを検出します。外部実装はSmart Cloth Suiteへコピーしません。',
        ),
        'steps': (
            ('Use Refresh Status after installing, updating, enabling, or disabling Simply Cloth Studio.', 'Simply Cloth Studioのインストール、更新、有効 / 無効切り替え後に「状態を更新」を実行します。'),
            ('Use Open Add-on Settings to open Blender Preferences and manage the external extension.', '「アドオン設定を開く」でBlender のプリファレンスを開き、外部の拡張機能を管理します。'),
            ('Set Body Collider for proximity analysis, temporal/layer decisions, and optional collision setup.', '近接解析、時間 / レイヤー判定、任意の衝突設定に使う「ボディコライダー」を指定します。'),
            ('Set Collider Collection when additional meshes must receive external Collision setup.', '追加メッシュへ外部の衝突設定を適用する場合は「コライダーコレクション」を指定します。'),
            ('Run Apply Colliders to add external collision only to targets that do not already have a Collision modifier.', '「コライダー適用」は衝突モディファイアが未設定の対象だけへ外部衝突設定を追加します。'),
        ),
        'controls': (
            _item('Status', '状態', 'Ready means every required command is available. Installed but disabled means the external files were found but the add-on is not active.', '「使用可能」は必須の操作がすべてそろっています。「インストール済み・無効」はファイルを検出しましたがアドオンが有効ではありません。'),
            _item('Body Collider', 'ボディコライダー', 'Primary body mesh for analysis and collision extension features.', '解析と衝突拡張機能で使う主ボディメッシュです。'),
            _item('Collider Collection', 'コライダーコレクション', 'Optional collection of additional mesh colliders.', '追加メッシュコライダーをまとめる任意のコレクションです。'),
            _item('Apply Colliders', 'コライダー適用', 'Calls the external collision operator while preserving object names, selection, active object, mode, and frame.', 'オブジェクト名、選択、アクティブ、モード、フレームを保持しながら外部衝突オペレーターを呼び出します。'),
        ),
    },
    'companion_workflow': {
        'title': ('Smart Workflow', 'スマートワークフロー'),
        'overview': (
            'Smart Setup combines external cloth creation with compatible Smart Cloth Suite extensions as one undoable operation. It does not replace the external fabric preset system.',
            'スマートセットアップは、外部クロス作成と互換性のあるSmart Cloth Suite拡張処理を1回のUndo可能な操作へまとめます。外部ツールの布プリセット機能は置き換えません。',
        ),
        'steps': (
            ('Select garment mesh objects and choose Target Scope.', '衣服メッシュを選択し、「対象範囲」を選びます。'),
            ('Choose Existing Modifiers handling to pass to the external Create Cloth operator.', '外部のクロス作成へ渡す「既存モディファイア」の処理方法を選びます。'),
            ('Choose a Quality Profile and the optional post-setup operations.', '品質プロファイルと、セットアップ後に実行する任意処理を選びます。'),
            ('Run Smart Setup. Existing Cloth objects are not recreated; compatible extension settings are still applied.', 'スマートセットアップを実行します。既にクロスのあるオブジェクトは再作成せず、互換拡張設定だけを適用します。'),
            ('For a reusable skirt, map the garment, armature, skirt bones, leg bones and body colliders in Reusable Skirt Setup. Preview, apply, validate, then save the mapping on the garment.', '再利用可能なスカートでは「再利用可能なスカート設定」で衣装、アーマチュア、スカート骨、脚骨、ボディ衝突対象を割り当てます。確認、適用、検証の後、衣装に割当てを保存します。'),
            ('Configuration Consistency checks mapping and modifier state, not surface clearance. Shared deformation bones cannot move only the garment, so no avoidance constraint is added to them. Outside Correction is an optional garment-only Shrinkwrap that pushes the garment outside the nearest body surface by an offset; intersections may remain, so inspect the deformed garment. The original modifier order and Bone appearance are restored when returning from Cloth.', '設定整合は割当てとモディファイア状態を確認し、表面の非交差は証明しません。衣装と体に共有される変形骨では衣装だけを動かせないため、回避制約を追加しません。外側補正は衣装だけに適用する任意のシュリンクラップで、衣装を体の面の外側へ指定の距離だけ押し出します。交差は残る場合があるので、変形後の衣装を確かめてください。クロスからボーンへ戻すと元のモディファイア順序と表示を復元します。'),
            ('To make Simply Cloth Studio the cloth of a garment that already has a Cloth (for example one built by SmartRig), select it and use Move Cloth to Simply. The values, pin weights, collider collection and the rig property switch are carried over; Simply Cloth Studio side effects (time scale, sewing, gravity keys, backup copy) are put back. Restore Original Cloth undoes it and also works when Simply Cloth Studio has been disabled. Bake and Check Intersections bakes the cloth and reports vertices inside the body; it uses Blender cloth and works without Simply Cloth Studio. Moving needs Simply Cloth Studio and is refused without it.', '既にクロスがある衣装（SmartRig で作った物など）を Simply Cloth Studio 主体にするには、衣装を選んで「Simply に載せ替え」を押します。値・固定の重み・衝突対象のコレクション・リグのプロパティでの切替を引き継ぎ、Simply Cloth Studio が変える値（時間の倍率・縫い・重力のキー・控えの複製）は元に戻します。「元のクロスに戻す」で取り消せます。これは Simply Cloth Studio を外した後でも使えます。「焼きと交差の確認」はクロスを焼き、体の内側に入った頂点の数を出します。Blender 標準のクロスで動くので Simply Cloth Studio が無くても使えます。載せ替えだけは Simply Cloth Studio が必要で、無い時は拒否します。'),
            ('For fabric-only simulation, choose a material slot or vertex group, support armature/bone, pin group or top-height fraction, total kilograms and stiffness. Preview before creating. Existing garment Cloth, shape keys and unsupported modifiers stop without changing the source. Simply Cloth Studio Create Cloth runs on a copied fabric helper; the copied trim remains skinned, and Bones restores the original garment exactly. The total mass is divided by the actual fabric helper vertex count. Remove Cloth Simulation can be pressed repeatedly. Creation does not check motion or penetration.', '布だけをシミュレーションする場合、材質スロットまたは頂点グループ、支持アーマチュア/ボーン、固定グループまたは上端高さ、総重量kg、剛性を選び、作成前に確認します。元衣装の既存クロス、シェイプキー、未対応モディファイアは無変更で拒否します。複製した布の補助物だけに Simply Cloth Studio のクロス作成を実行し、装飾の補助物はスキニングを保持します。ボーンへ戻すと元の衣装を復元します。総重量は布の補助物の実際の頂点数で割ります。「布シミュレーションを解除」は何度でも押せます。作成の時に動きや貫通は確かめません。'),
        ),
        'controls': (
            _item('Target Scope', '対象範囲', 'Active processes the active mesh; Selected processes selected meshes; All processes all cloth meshes in the current scene.', 'アクティブクロスはアクティブメッシュ、選択クロスは選択メッシュ、シーン内の全クロスは現在のシーンの全クロスメッシュを処理します。'),
            _item('Quality Profile', '品質プロファイル', 'Selects Preview, Balanced, Production, or Hero solver/collision values.', 'プレビュー・バランス・プロダクション・ヒーローのソルバー / 衝突品質値を選びます。'),
            _item('Existing Modifiers', '既存モディファイア', 'Keep, Apply, or Remove is passed to the external cloth-creation operator.', '維持・適用・削除のどれかを外部のクロス作成へ渡します。'),
            _item('Apply Quality Profile', '品質プロファイルを適用', 'Applies Smart Cloth Suite quality values after external setup.', '外部セットアップ後にSmart Cloth Suite品質値を適用します。'),
            _item('Auto Collision Distance', '衝突距離を自動調整', 'Calculates collision distance from world-space average edge length.', 'ワールド空間の平均エッジ長から衝突距離を計算します。'),
            _item('Apply Collider Setup', 'コライダー設定を適用', 'Runs external collision setup for the configured body/collection.', '設定したボディ / コレクションへ外部衝突設定を実行します。'),
            _item('Create Top Pin When Missing', '未設定時に上端ピンを作成', 'Creates SimplyPin on the top garment band only when no weighted external pin exists.', 'ウェイト付き外部ピングループが無い場合だけ、衣服上端帯にSimplyPinを作成します。'),
            _item('Preserve Existing Pin Weights', '既存ピンウェイトを保持', 'Prevents automatic pin generation from replacing non-zero existing pin weights.', '自動ピン生成が既存の非ゼロピンウェイトを上書きしないようにします。'),
            _item('Move Cloth to Simply', 'Simply に載せ替え', 'Replaces the one existing Cloth with Simply Cloth Studio Create Cloth, writes the recorded values through its sliders, reads them back, copies the pin into SimplyPin as a pin layer and copies the show/hide drivers. A second press changes nothing. Without Simply Cloth Studio it is refused and nothing is changed, even on a garment already moved. A baked cloth is refused until its bake is freed.', '既存のクロス 1 つを Simply Cloth Studio のクロス作成に置き換え、記録した値をスライダーで入れて読み返し、固定を SimplyPin のピンの層として写し、表示切替のドライバーも写します。2 回目は何も変えません。Simply Cloth Studio が無い時は、載せ替え済みの服でも拒否し、何も変えません。焼き済みのクロスは焼きを解除するまで拒否します。'),
            _item('Restore Original Cloth', '元のクロスに戻す', 'Removes what Move Cloth added and rebuilds the recorded original Cloth, its cache settings and drivers. Works without Simply Cloth Studio.', '載せ替えで足した物を外し、記録した元のクロスをキャッシュの設定とドライバーごと作り直します。Simply Cloth Studio が無くても使えます。'),
            _item('Cloth / Switch line', 'クロス／切替の行', 'Shows whether the garment cloth is Simply primary, an own cloth or none, and which property switches it.', '衣装のクロスが Simply 主体・自前クロス・無しのどれか、どのプロパティで切り替えるかを表示します。'),
            _item('Bake and Check Intersections', '焼きと交差の確認', 'Bakes with Blender point cache bake, samples up to 48 frames and reports vertices inside the colliders, the lowest point and invalid positions. The bake is kept. Works without Simply Cloth Studio.', 'Blender のポイントキャッシュで焼き、最大 48 フレームを調べ、体の内側に入った頂点・最も低い点・不正な位置を報告します。焼きは残します。Simply Cloth Studio が無くても使えます。'),
            _item('Outside Correction', '外側補正', 'Optional garment-only correction that pushes the garment outside the body. Surface intersections may remain; inspect the deformed garment.', '衣装だけを体の外側へ押し出す任意の補正です。表面の交差は残ることがあるので、変形後の衣装を確かめてください。'),
            _item('Cloth to Garment Bones', 'クロスから衣装ボーンへ', 'Select the garment bone columns in Pose Mode; the roots stay fixed. Set the baked cloth mesh, target armature and frame range, then use Preview and Bake to Bones. The original animation is kept; the baked output overrides the selected bones only. Standard and Cloth Baked switch between them, and Clear Bone Bake removes the bake.', 'ポーズモードで衣装のボーンの列を選びます。根元は固定します。ベイク済みクロスメッシュ・対象アーマチュア・フレームの範囲を入れ、「確認」「ボーンへ焼付け」を押します。元のアニメーションは残し、選んだ骨だけ焼付けの結果で上書きします。「標準」「クロス焼付け」で切り替え、「ボーン焼付けを解除」で外します。'),
            _item('Reusable Skirt Setup', '再利用可能なスカート設定', 'Maps this garment without fixed object or bone names. The owned Blender route works without Simply Cloth Studio; the external route calls its Create Cloth command only when available and checks the resulting Cloth modifier when applied.', '固定のオブジェクト名や骨名を使わず衣装を割り当てます。Blender標準経路はSimply Cloth Studioなしで使用できます。外部経路はクロス作成の操作を利用できる場合だけ呼び出し、適用の時に生成されたクロスモディファイアを確認します。'),
        ),
    },
    'companion_performance': {
        'title': ('Batch / Performance', '一括処理 / パフォーマンス'),
        'overview': (
            'Provides batch quality changes and a reversible preview state. The preview command stores exact original Cloth and modifier visibility values on each object before reducing viewport cost.',
            '一括品質変更と復元可能なプレビュー状態を提供します。プレビュー適用前に各オブジェクトのクロス値とモディファイア表示状態を正確に保存してから、ビューポート負荷を下げます。',
        ),
        'steps': (
            ('Choose Target Scope and Quality Profile, then use Apply Selected Profile for normal quality changes.', '対象範囲と品質プロファイルを選び、通常の品質変更には「選択プロファイルを適用」を使います。'),
            ('Use Apply Batch Preview while blocking, posing, or navigating heavy scenes.', 'ブロッキング、ポーズ、重いシーンのビュー操作中は「一括プレビュー適用」を使います。'),
            ('Use Restore Preview State before final review or bake.', '最終確認またはベイク前に「プレビュー状態を復元」を実行します。'),
        ),
        'controls': (
            _item('Preview Solver Quality', 'プレビューソルバー品質', 'Temporary Cloth quality used only while preview state is active.', 'プレビュー状態中だけ使う一時クロス品質です。'),
            _item('Hide Heavy Modifiers', '高負荷モディファイアを非表示', 'Temporarily hides Subdivision, Geometry Nodes, Solidify, and smoothing-related modifiers after recording each original visibility state.', '元の表示状態を記録してから、サブディビジョン、ジオメトリーノード、厚み付け、スムーズ系モディファイアを一時非表示にします。'),
            _item('Restore Preview State', 'プレビュー状態を復元', 'Restores saved quality, collision quality, self-collision, and modifier visibility, then deletes the temporary state record.', '保存した品質、衝突品質、自己衝突、モディファイア表示を復元し、一時状態記録を削除します。'),
        ),
    },
    'companion_precision': {
        'title': ('Precision / Collision', '精度 / 衝突'),
        'overview': (
            'Adds mesh-aware collision spacing without replacing external material parameters. All commands are manual and install no continuous evaluation handler.',
            '外部マテリアル値を置き換えず、メッシュに応じた衝突間隔を追加します。全コマンドは手動実行で、常時評価ハンドラを登録しません。',
        ),
        'steps': (
            ('Set the minimum, maximum, and edge-distance factor.', '最小距離、最大距離、エッジ距離係数を設定します。'),
            ('Run Auto Distance after changing topology or object scale.', 'トポロジーまたはオブジェクトスケール変更後に「距離を自動調整」を実行します。'),
            ('Run Temporal Guard on an animation frame to sample future evaluated motion and add only required padding.', 'アニメーションフレームで「時間方向ガード」を実行し、未来の評価済み移動量から必要な分だけパディングを追加します。'),
            ('Set Body Collider and run Layer Clearance for multiple nested garments.', '多層衣服ではボディコライダーを設定し、「レイヤー間隔」を実行します。'),
        ),
        'controls': (
            _item('Self Collision', '自己衝突', 'Controls self-collision when profiles or distances are applied.', 'プロファイルまたは距離適用時の自己衝突を制御します。'),
            _item('Edge Distance Factor', 'エッジ距離係数', 'Multiplies average world-space edge length to estimate collision distance.', 'ワールド空間の平均エッジ長へ乗算して衝突距離を推定します。'),
            _item('Minimum / Maximum', '最小距離 / 最大距離', 'Clamp all automatic and temporal collision distances.', '自動計算と時間方向計算の衝突距離を制限します。'),
            _item('Layer Gap', 'レイヤー間隔', 'Adds this distance for each outer garment layer.', '外側の衣服レイヤーごとにこの距離を追加します。'),
            _item('Motion Sample Frames', '動きサンプルフレーム', 'Future-frame offset used by Temporal Guard.', '時間方向ガードが評価する未来フレーム数です。'),
            _item('Temporal Guard Multiplier', '時間方向ガード倍率', 'Scales measured vertex motion before applying padding.', '計測した頂点移動量へ乗算してパディングを算出します。'),
        ),
    },
    'companion_analysis': {
        'title': ('Analysis / Diagnostics', '解析 / 診断'),
        'overview': (
            'Creates non-destructive diagnostic vertex groups and detailed reports. Safe Topology Repair performs only conservative corrections and skips meshes with shape keys.',
            '非破壊の診断頂点グループと詳細レポートを作成します。安全なトポロジー補正は保守的な修正だけを行い、シェイプキー付きメッシュをスキップします。',
        ),
        'steps': (
            ('Set the body collider and proximity distance when collision proximity must be evaluated.', '衝突近接度を評価する場合はボディコライダーと近接解析距離を設定します。'),
            ('Run Build Analysis Maps to create CurvatureRisk, PinSuggestion, and CollisionProximity groups.', '「解析マップ作成」で曲率リスク・ピン候補・衝突近接度の頂点グループを作成します。'),
            ('Run Preflight to inspect modifiers, topology, transforms, pins, cache, and solver quality.', '「プリフライト実行」でモディファイア、トポロジー、トランスフォーム、ピン、キャッシュ、ソルバー品質を検査します。'),
            ('Review the report before using Safe Topology Repair.', '安全なトポロジー補正を行う前にレポートを確認します。'),
        ),
        'controls': (
            _item('Proximity Distance', '近接解析距離', 'Distance at which the Collision Proximity weight reaches zero.', '衝突近接度のウェイトがゼロになる距離です。'),
            _item('Merge Distance Factor', 'マージ距離係数', 'Very small fraction of average edge length used to merge nearly coincident vertices.', 'ほぼ同位置の頂点をマージするために平均エッジ長へ掛けるごく小さい係数です。'),
            _item('Remove Isolated Vertices', '孤立頂点を削除', 'Optionally removes vertices with no connected edge. Boundary and sewing edges are not deliberately deleted.', '接続エッジを持たない頂点だけを任意で削除します。境界 / 縫製エッジを意図的に削除しません。'),
            _item('Generated Groups', '作られる頂点グループ', 'Build Analysis Maps creates three vertex groups: Curvature Risk (SCSuite_CurvatureRisk), Pin Suggestion (SCSuite_PinSuggestion) and Collision Proximity (SCSuite_CollisionProximity).', '「解析マップ作成」は、曲率リスク（SCSuite_CurvatureRisk）・ピン候補（SCSuite_PinSuggestion）・衝突近接度（SCSuite_CollisionProximity）の 3 つの頂点グループを作ります。'),
            _item('Preflight Report', 'プリフライトレポート', 'Lists blocking errors, warnings, information, and a per-object score, then writes JSON or text under config/Smart_Cloth_Suite/reports.', '重大エラー、警告、情報、オブジェクト別スコアを記録し、config/Smart_Cloth_Suite/reportsへJSONまたはテキストで保存します。'),
        ),
    },
    'companion_output': {
        'title': ('Bake / Output', 'ベイク / 出力'),
        'overview': (
            'Wraps external bake and finish operations with Smart Cloth Suite preflight and reporting. This section does not implement the external solver or finalization algorithm.',
            '外部のベイク / 仕上げ操作へSmart Cloth Suiteのプリフライトとレポートを追加します。外部ソルバーや仕上げアルゴリズム自体は実装しません。',
        ),
        'steps': (
            ('Choose target scope and report format.', '対象範囲とレポート形式を選びます。'),
            ('Enable Stop on Preflight Error when destructive output must be blocked by serious setup errors.', '重大なセットアップエラー時に破壊的出力を止める場合は「プリフライトエラー時に停止」を有効にします。'),
            ('Run Safe Bake or Safe Finish. A report is always written before the external action.', '安全ベイクまたは安全仕上げを実行します。外部操作の前に必ずレポートを書き出します。'),
            ('Use Free Bake to release target Cloth caches.', '対象クロスキャッシュを解除する場合は「ベイク解除」を使います。'),
        ),
        'controls': (
            _item('Safe Bake', '安全ベイク', 'Preflights the targets, then bakes each Cloth cache that is not baked yet with Blender\'s standard bake. Esc or right-click stops and restores the previous state.', '対象をプリフライトし、まだベイクしていないクロスを Blender 標準のベイクで1つずつベイクします。Esc または右クリックで止めると元の状態に戻します。'),
            _item('Safe Finish', '安全仕上げ', 'Preflights the targets and fixes the shape each Cloth shows at the current frame into the mesh. A Cloth that is not baked is baked first. Modifiers before the Cloth are included in the shape and removed, then the external cloth finish operator handles the rest.', '対象をプリフライトし、各クロスが今のフレームで見せている形をメッシュに確定します。まだベイクしていないクロスは先にベイクします。クロス より前のモディファイアは形に含めて外し、残りは外部クロス仕上げオペレーターが処理します。'),
            _item('Free Bake', 'ベイク解除', 'Releases the Cloth point cache on each target without requiring external bake state.', '外部ベイク状態に依存せず、各対象のクロスポイントキャッシュを解除します。'),
            _item('Report Format', 'レポート形式', 'JSON creates structured data; Text creates a human-readable report.', 'JSON は構造化データ、テキストは読みやすいレポートを作成します。'),
            _item('Open Data Folder', 'データフォルダーを開く', 'Opens Blender config/Smart_Cloth_Suite containing the settings JSON and reports folder.', '設定JSONとreportsフォルダーを含むBlender config/Smart_Cloth_Suiteを開きます。'),
        ),
    },
    'quick_rigid': {
        'title': ('Quick Rigid', 'Quick Rigid'),
        'overview': ('Adds and edits Blender rigid bodies, presets, physical response, and cache/bake controls.', 'Blender剛体の追加 / 編集、プリセット、物理応答、キャッシュ / ベイクを操作します。'),
        'steps': (('Select one or more mesh objects.', '1つ以上のメッシュを選択します。'), ('Add Active or Passive rigid bodies.', 'アクティブまたはパッシブ剛体を追加します。'), ('Adjust properties, presets, and bake controls.', '物理特性、プリセット、ベイクを調整します。')),
        'controls': (
            _item('Active', 'アクティブ', 'Simulated rigid body affected by forces and collisions.', '力と衝突の影響を受けてシミュレーションされる剛体です。'),
            _item('Passive', 'パッシブ', 'Collision body that does not move under rigid-body dynamics.', '剛体ダイナミクスでは移動しない衝突用剛体です。'),
            _item('Presets / Bake', 'プリセット / ベイク', 'Stores reusable physical values and controls rigid-body cache calculation/removal. Apply Preset and Delete Preset open a list of the saved presets to choose from.', '再利用する物理値を保存し、剛体キャッシュの計算 / 解除を操作します。「プリセットを適用」「プリセット削除」は、押すと保存済みのプリセットの一覧が出るので、そこから選びます。'),
            _item('All Quick Rigid Commands', 'Quick Rigid 全コマンド', 'Toggle Animated switches the active rigid body between following its keys and being simulated. Copy Shortcut Setup copies the details for registering the Quick Rigid menu shortcut yourself in Preferences > Keymap.', '「アニメーション切替」は、アクティブな剛体を、キーのとおりに動く状態と物理で動く状態の間で切り替えます。「ショートカット設定をコピー」は、Quick Rigid のメニューのショートカットをプリファレンス > キーマップで自分で登録するための情報をクリップボードへコピーします。'),
        ),
    },
    'quick_rigid_menu': {'alias': 'quick_rigid'},
    'quick_rigid_setup': {'alias': 'quick_rigid'},
    'quick_rigid_active_body': {'alias': 'quick_rigid'},
    'quick_rigid_presets': {'alias': 'quick_rigid'},
    'jiggle_physics': {
        'title': ('Jiggle Physics', 'Jiggle Physics'),
        'overview': ('Provides bone-based secondary motion with optional live callbacks, overlays, wind, presets, utilities, and bake.', '任意のライブコールバック、オーバーレイ、風、プリセット、補助、ベイクを備えたボーン二次揺れです。'),
        'steps': (('Select an armature and pose bone.', 'アーマチュアとポーズボーンを選択します。'), ('Configure scene, armature, and bone values.', 'シーン、アーマチュア、ボーン値を設定します。'), ('Enable only the runtime callbacks or overlays required for the current task.', '現在の作業に必要なランタイムコールバック / オーバーレイだけを有効にします。'), ('Bake after confirming the motion.', '動きを確認してからベイクします。')),
        'controls': (
            _item('Scene Settings', 'シーン設定', 'Controls gravity, substeps, constraints, loop, and wind parameters.', '重力、サブステップ、拘束、ループ、風パラメーターを設定します。'),
            _item('Armature', 'アーマチュア', 'Enables, mutes, or freezes Jiggle for the active armature.', 'アクティブアーマチュアのJiggleを有効、ミュート、固定します。'),
            _item('Active Bone', 'アクティブボーン', 'Controls elasticity, gravity, blend, drag, friction, and collision radius for the active pose bone.', 'アクティブポーズボーンの弾性、重力、ブレンド、空気抵抗、摩擦、衝突半径を設定します。'),
            _item('Utilities / Bake / Presets', '補助 / ベイク / プリセット', 'Copies settings, selects enabled bones, bakes motion, resets physics, profiles, and stores presets.', '設定コピー、有効ボーン選択、ベイク、物理リセット、計測、プリセット保存を行います。'),
            _item('Bake Jiggle', 'Jiggle をベイク', 'Runs the simulation over the frame range and writes the motion seen in playback, including the lag behind parent bones, to keys of the enabled bones. Preroll runs that many frames first. By default a new action is made; Overwrite Current Action replaces the current action, and Current Action to NLA moves the current action into an NLA strip. These two settings stay with the current scene and are not carried to a new scene.', '再生の範囲を計算し、親の骨に遅れる揺れも含めて、再生で見える動きを有効な骨のキーにします。プリロールは、焼く前に先に計算するフレームの数です。普段は新しいアクションを作ります。「現在のアクションを上書き」は今のアクションを置き換え、「現在のアクションを NLA へ移動」は今のアクションを NLA のストリップへ移します。この 2 つの設定は今のシーンにだけ残り、新しいシーンには引き継がれません。'),
            _item('Reset Physics', '物理をリセット', 'Starts the simulation over from the current pose and returns channels without keys to their values from before the simulation. With Loop Simulation off, this also happens when you return to the first frame.', '揺れの計算を今の姿勢から始め直し、キーの無い項目を揺れで動く前の値に戻します。「ループシミュレーション」がオフなら、最初のフレームへ戻った時にも同じことが行われます。'),
        ),
    },
    'jiggle_scene': {'alias': 'jiggle_physics'},
    'jiggle_armature': {'alias': 'jiggle_physics'},
    'jiggle_bone': {'alias': 'jiggle_physics'},
    'jiggle_utilities': {'alias': 'jiggle_physics'},
    'jiggle_warning_no_keyframes': {
        'title': ('No Keyframes Detected', 'キーフレームが見つかりません'),
        'overview': ('Position and rotation keyframes are used for the rest pose. You can safely ignore this if you are using actions in the NLA.', '位置と回転のキーフレームをレスト姿勢の基準として使います。NLA 上のアクションを使っている場合は、この警告を無視して構いません。'),
    },
    'jiggle_warning_bone_constraints': {
        'title': ('Bone Constraints Detected', 'ボーン制約を検出'),
        'overview': ('Bone constraints are applied after jiggle, which can cause strange behavior. Be weary that using constraints in place of parenting can also cause the jiggle pose to not work as intended. Click the button below to automatically disable constraints on selected bones. You can safely ignore this if you are intending to constrain the jiggle pose.', 'ボーン制約は Jiggle 後に適用されるため、不自然な挙動の原因になります。親子関係の代わりに制約を使っている場合も、Jiggle 姿勢が意図通りに動かないことがあります。下のボタンを押すと、選択ボーンの制約を自動で無効化できます。Jiggle 姿勢を意図的に制約している場合は、この警告を無視して構いません。'),
    },
    'jiggle_warning_connected_bones': {
        'title': ('Connected Bones Detected', '接続ボーンを検出'),
        'overview': ('Bones that are connected cannot be translated, preventing them from stretching. This makes them ignore length elasticity. You can safely ignore this if stretchiness is not desired.', '接続されたボーンは移動できないため、伸び方向の挙動が制限されます。その結果、長さ弾性が効かなくなります。伸びる挙動が不要な場合は、この警告を無視して構いません。'),
    },
    'jiggle_warning_frame_skipping_enabled': {
        'title': ('Frame Dropping Detected', 'フレームドロップを検出'),
        'overview': ('Playback set to Frame Dropping can cause the preview to be inaccurate. Bakes will look very different.', '再生がフレームドロップになっていると、プレビュー精度が下がることがあります。ベイク結果が大きく異なって見える場合があります。'),
    },
    'jiggle_warning_mesh_collision': {
        'title': ('Mesh Collision Detected', 'メッシュ衝突を検出'),
        'overview': ('Meshes are not convex, making them suboptimal for collisions. Please use scaled Empty spheres instead (Add -> Empty -> Sphere)', 'メッシュは凸形状ではないため、衝突判定には最適ではありません。代わりにスケールした球のエンプティを使ってください（追加 > エンプティ > 球）。'),
    },
}


def _topic_data(topic: str):
    key = str(topic or 'suite').strip() or 'suite'
    data = _TOPICS.get(key, _TOPICS['suite'])
    alias = data.get('alias') if isinstance(data, dict) else None
    return _TOPICS.get(alias, _TOPICS['suite']) if alias else data


def help_dialog_width(context=None) -> int:
    try:
        region_width = int(getattr(getattr(context, 'region', None), 'width', 0) or 0)
    except Exception:
        region_width = 0
    return max(720, min(1080, region_width * 2 if region_width else 900))


def _wrap(layout, text: str, popup_width: int, *, icon: str = 'NONE', indent: int = 0) -> None:
    chars = max(42, min(155, int(max(500, popup_width - 90 - indent * 24) / 7.2)))
    first = True
    for line in textwrap.wrap(str(text or ''), width=chars, break_long_words=False, break_on_hyphens=False) or ['']:
        row = layout.row()
        if indent:
            row.separator(factor=0.35 * indent)
        row.label(text=line, icon=icon if first else 'NONE')
        first = False


def draw_help_contents(layout, context, topic: str, popup_width: int | None = None) -> None:
    width = int(popup_width or help_dialog_width(context))
    data = _topic_data(topic)
    title = _t(data['title'], context)
    layout.label(text=title, icon='HELP')

    box = layout.box()
    box.label(text=_t(('Function', '機能'), context))
    _wrap(box, _t(data['overview'], context), width)

    steps = tuple(data.get('steps', ()))
    if steps:
        box = layout.box()
        box.label(text=_t(('How to Use', '使い方'), context), icon='TOOL_SETTINGS')
        for index, pair in enumerate(steps, 1):
            _wrap(box, f'{index}. {_t(pair, context)}', width, icon='DOT')

    controls = tuple(data.get('controls', ()))
    if controls:
        box = layout.box()
        box.label(text=_t(('UI / Settings', 'UI / 設定項目'), context), icon='PREFERENCES')
        for label_pair, desc_pair in controls:
            item = box.box()
            item.label(text=_t(label_pair, context), icon='DOT')
            _wrap(item, _t(desc_pair, context), width, indent=1)


def show_help_popup(context, topic: str) -> None:
    data = _topic_data(topic)
    title = _t(data['title'], context)

    def _draw(self, popup_context):
        draw_help_contents(self.layout, popup_context, topic, popup_width=help_dialog_width(popup_context))

    context.window_manager.popup_menu(_draw, title=title, icon='HELP')
