# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible storage helpers.

from __future__ import annotations

import copy
import json
import os
import shutil
import sys
from pathlib import Path
from typing import Any, Iterable

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

PACKAGE_ID = 'smart_shader_suite'
USER_DATA_DIRNAME = 'user_data'
SUITE_SETTINGS_DIRNAME = 'Smart_Shader_Suite'
SUITE_SETTINGS_FILENAME = 'Smart_Shader_Suite.json'
PRESET_PREVIEW_DIRNAME = 'preset_previews'
_IGNORED_MIGRATION_NAMES = {'.DS_Store', 'Thumbs.db', '__pycache__'}
_MIGRATED_EXTENSION_DATA_PACKAGES: set[str] = set()
_REGISTRATION_WRITE_GUARD_DEPTH = 0
_SETTINGS_CACHE_DATA: dict | None = None
_SETTINGS_CACHE_SIGNATURE: tuple[int, int] | None = None
_SETTINGS_CACHE_PATH: str = ""
_SETTINGS_READ_ERROR: str = ""
_LAST_WRITE_STATUS = {"ok": True, "code": "NOT_RUN", "detail": ""}
_PERSISTENCE_OWNER_STATE: dict | None = None
_PENDING_TOGGLE_CAPABILITY = None
_EXPECTED_SETTINGS_RNA = 'SSS_NPanelSettings'


def begin_registration_write_guard() -> None:
    """Block synthetic RNA-default writes while Blender registers the suite.

    The canonical JSON remains readable throughout registration.  This lets
    every PropertyGroup restore its saved value without a newly-materialised
    default replacing the profile first.
    """
    global _REGISTRATION_WRITE_GUARD_DEPTH
    _REGISTRATION_WRITE_GUARD_DEPTH += 1


def end_registration_write_guard() -> None:
    global _REGISTRATION_WRITE_GUARD_DEPTH
    _REGISTRATION_WRITE_GUARD_DEPTH = max(0, _REGISTRATION_WRITE_GUARD_DEPTH - 1)


def registration_write_guarded() -> bool:
    return _REGISTRATION_WRITE_GUARD_DEPTH > 0


def config_root(create: bool = True) -> Path:
    """Return Blender's versioned config directory."""
    path = None
    if bpy is not None:
        try:
            value = bpy.utils.user_resource('CONFIG', create=bool(create))
            if value:
                path = Path(value)
        except Exception:
            path = None
    if path is None:
        version = _blender_version()
        if os.name == 'nt':
            roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
            path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config'
        elif sys.platform == 'darwin':
            path = Path.home() / 'Library' / 'Application Support' / 'Blender' / version / 'config'
        else:
            path = Path.home() / '.config' / 'blender' / version / 'config'
    if create:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def suite_settings_dir(create: bool = True) -> Path:
    """Return the commercial package config folder.

    Windows target:
    C:/Users/<User>/AppData/Roaming/Blender Foundation/Blender/5.1/config/Smart_Shader_Suite
    """
    path = config_root(create=create) / SUITE_SETTINGS_DIRNAME
    if create:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def legacy_suite_settings_path(create: bool = False) -> Path:
    """Return the legacy flat JSON path used by older builds."""
    path = config_root(create=create) / SUITE_SETTINGS_FILENAME
    if create:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def suite_settings_path(create: bool = True) -> Path:
    path = suite_settings_dir(create=create) / SUITE_SETTINGS_FILENAME
    if create:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def bundled_preset_previews_dir() -> Path:
    """Return the read-only preview images shipped inside the Extension."""
    return _package_root() / PRESET_PREVIEW_DIRNAME


def preset_previews_dir(create: bool = True) -> Path:
    """Return the writable directory for generated preset preview images.

    The installed Extension directory is immutable.  Bundled preview PNGs are
    resolved separately by :func:`bundled_preset_previews_dir`, while every
    newly rendered or updated image is stored in Blender's versioned
    ``config/Smart_Shader_Suite/preset_previews`` directory.
    """
    path = suite_settings_dir(create=create) / PRESET_PREVIEW_DIRNAME
    if create:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def preset_preview_path(preset_id: object, *, create_parent: bool = True) -> Path:
    """Return a safe writable PNG path for one generated preset preview."""
    key = _clean_storage_identifier(preset_id, fallback='preset_preview')
    path = preset_previews_dir(create=create_parent) / f'{key}.png'
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def migrate_legacy_suite_settings(force: bool = False) -> bool:
    """Move/copy old config/Smart_Shader_Suite.json into the new folder path.

    The old file is left in place unless force=True; leaving it avoids destructive
    behavior while guaranteeing the new canonical file is populated.
    """
    new_path = suite_settings_path(create=True)
    old_path = legacy_suite_settings_path(create=False)
    try:
        if not old_path.exists():
            return False
        if new_path.exists() and not force:
            return False
        data = _read_json_dict(old_path)
        if not data:
            return False
        try:
            new_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        new_path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True), encoding='utf-8')
        invalidate_suite_settings_cache()
        return True
    except Exception:
        return False


def _read_json_dict(path: Path) -> dict:
    try:
        if path.exists():
            raw = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(raw, dict):
                return raw
    except Exception:
        pass
    return {}


def _settings_file_signature(path: Path) -> tuple[int, int] | None:
    try:
        stat = path.stat()
        return int(getattr(stat, 'st_mtime_ns', 0)), int(stat.st_size)
    except Exception:
        return None


def invalidate_suite_settings_cache() -> None:
    global _SETTINGS_CACHE_DATA, _SETTINGS_CACHE_SIGNATURE, _SETTINGS_CACHE_PATH, _SETTINGS_READ_ERROR
    _SETTINGS_CACHE_DATA = None
    _SETTINGS_CACHE_SIGNATURE = None
    _SETTINGS_CACHE_PATH = ''
    _SETTINGS_READ_ERROR = ''


class _PersistenceToggleCapability:
    __slots__ = ('owner_pointer', 'rna_identifier', 'previous', 'current', 'file_signature')

    def __init__(self, owner_pointer: int, rna_identifier: str, previous: bool, current: bool, file_signature):
        self.owner_pointer = int(owner_pointer)
        self.rna_identifier = str(rna_identifier)
        self.previous = bool(previous)
        self.current = bool(current)
        self.file_signature = file_signature


def _native_rna_identity(owner) -> tuple[int, str] | None:
    if owner is None:
        return None
    try:
        pointer = int(owner.as_pointer())
        identifier = str(getattr(getattr(owner, 'bl_rna', None), 'identifier', '') or '')
    except Exception:
        return None
    if pointer <= 0 or identifier != _EXPECTED_SETTINGS_RNA:
        return None
    return pointer, identifier


def _live_persistence_owner():
    if bpy is None:
        return None
    try:
        context = getattr(bpy, 'context', None)
        wm = getattr(context, 'window_manager', None) if context is not None else None
        return getattr(wm, 'sss_npanel_settings', None) if wm is not None else None
    except Exception:
        return None


def _authenticated_owner_identity(owner) -> tuple[int, str] | None:
    supplied = _native_rna_identity(owner)
    live = _native_rna_identity(_live_persistence_owner())
    return supplied if supplied is not None and supplied == live else None


def bind_persistence_owner(owner, saved_enabled: bool) -> bool:
    """Bind live RNA native identity to the last successfully restored value."""
    global _PERSISTENCE_OWNER_STATE, _PENDING_TOGGLE_CAPABILITY
    if not isinstance(saved_enabled, bool):
        return False
    identity = _authenticated_owner_identity(owner)
    if identity is None:
        return False
    current = _read_suite_settings_cached()
    if _SETTINGS_READ_ERROR:
        return False
    disk_enabled = bool(dict(current.get('preferences') or {}).get('npanel_state_save', True))
    try:
        actual_enabled = getattr(_live_persistence_owner(), 'npanel_state_save')
    except Exception:
        return False
    if not isinstance(actual_enabled, bool) or actual_enabled is not saved_enabled or disk_enabled is not saved_enabled:
        return False
    _PERSISTENCE_OWNER_STATE = {
        'owner_pointer': identity[0],
        'rna_identifier': identity[1],
        'saved_enabled': saved_enabled,
    }
    _PENDING_TOGGLE_CAPABILITY = None
    return True


def clear_persistence_owner() -> None:
    global _PERSISTENCE_OWNER_STATE, _PENDING_TOGGLE_CAPABILITY
    _PERSISTENCE_OWNER_STATE = None
    _PENDING_TOGGLE_CAPABILITY = None


def persistence_saved_state(owner):
    identity = _authenticated_owner_identity(owner)
    state = _PERSISTENCE_OWNER_STATE
    if identity is None or not isinstance(state, dict):
        return None
    if (state.get('owner_pointer'), state.get('rna_identifier')) != identity:
        return None
    value = state.get('saved_enabled')
    return value if isinstance(value, bool) else None


def authorize_persistence_toggle(owner, previous_enabled: bool, current_enabled: bool):
    """Issue one opaque capability for one genuine live-RNA state transition."""
    global _PENDING_TOGGLE_CAPABILITY
    if registration_write_guarded():
        _set_write_status(False, 'REGISTRATION_GUARD')
        return None
    if not isinstance(previous_enabled, bool) or not isinstance(current_enabled, bool) or previous_enabled is current_enabled:
        _set_write_status(False, 'NOT_A_TOGGLE_TRANSITION')
        return None
    if _PENDING_TOGGLE_CAPABILITY is not None:
        _set_write_status(False, 'CAPABILITY_ALREADY_PENDING')
        return None
    identity = _authenticated_owner_identity(owner)
    state = _PERSISTENCE_OWNER_STATE
    if identity is None or not isinstance(state, dict):
        _set_write_status(False, 'OWNER_NOT_AUTHENTIC')
        return None
    if (state.get('owner_pointer'), state.get('rna_identifier')) != identity or state.get('saved_enabled') is not previous_enabled:
        _set_write_status(False, 'OWNER_STATE_STALE')
        return None
    try:
        actual_enabled = getattr(_live_persistence_owner(), 'npanel_state_save')
    except Exception:
        actual_enabled = None
    if not isinstance(actual_enabled, bool) or actual_enabled is not current_enabled:
        _set_write_status(False, 'LIVE_VALUE_MISMATCH')
        return None
    document = _read_suite_settings_cached()
    if _SETTINGS_READ_ERROR:
        _set_write_status(False, 'READ_ERROR_PRESERVED', _SETTINGS_READ_ERROR)
        return None
    disk_enabled = bool(dict(document.get('preferences') or {}).get('npanel_state_save', True))
    if disk_enabled is not previous_enabled:
        _set_write_status(False, 'DISK_STATE_STALE')
        return None
    capability = _PersistenceToggleCapability(identity[0], identity[1], previous_enabled, current_enabled, _SETTINGS_CACHE_SIGNATURE)
    _PENDING_TOGGLE_CAPABILITY = capability
    return capability


def commit_persistence_toggle(capability, preferences_payload: dict) -> bool:
    """Build the preferences-only document; the lowest writer authenticates."""
    if not isinstance(preferences_payload, dict):
        _set_write_status(False, 'INVALID_TOGGLE_PAYLOAD')
        return False
    if registration_write_guarded():
        return _write_suite_settings({}, capability=capability)
    current = _read_suite_settings_cached()
    data = dict(current)
    data['preferences'] = _deep_merge_unknown(current.get('preferences'), preferences_payload)
    return _write_suite_settings(data, capability=capability)


def last_write_status() -> dict:
    return dict(_LAST_WRITE_STATUS)


def _set_write_status(ok: bool, code: str, detail: object = "") -> None:
    _LAST_WRITE_STATUS.update(ok=bool(ok), code=str(code), detail=str(detail or ""))


def _deep_merge_unknown(existing, replacement):
    if not isinstance(existing, dict) or not isinstance(replacement, dict):
        return copy.deepcopy(replacement)
    merged = copy.deepcopy(existing)
    for key, value in replacement.items():
        merged[key] = _deep_merge_unknown(existing.get(key), value)
    return merged


def _cache_suite_settings(path: Path, data: dict, signature=None) -> dict:
    global _SETTINGS_CACHE_DATA, _SETTINGS_CACHE_SIGNATURE, _SETTINGS_CACHE_PATH
    _SETTINGS_CACHE_DATA = data if isinstance(data, dict) else {}
    _SETTINGS_CACHE_SIGNATURE = signature if signature is not None else _settings_file_signature(path)
    try:
        _SETTINGS_CACHE_PATH = str(path.resolve())
    except Exception:
        _SETTINGS_CACHE_PATH = str(path)
    return _SETTINGS_CACHE_DATA


def _read_suite_settings_cached() -> dict:
    global _SETTINGS_READ_ERROR
    migrate_legacy_suite_settings(force=False)
    path = suite_settings_path(create=True)
    try:
        path_key = str(path.resolve())
    except Exception:
        path_key = str(path)
    signature = _settings_file_signature(path)
    if (
        isinstance(_SETTINGS_CACHE_DATA, dict)
        and _SETTINGS_CACHE_PATH == path_key
        and _SETTINGS_CACHE_SIGNATURE == signature
    ):
        return _SETTINGS_CACHE_DATA
    try:
        if not path.exists():
            _SETTINGS_READ_ERROR = ''
            return _cache_suite_settings(path, {}, signature=signature)
        raw = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(raw, dict):
            raise ValueError('root is not a JSON object')
        _SETTINGS_READ_ERROR = ''
        return _cache_suite_settings(path, raw, signature=signature)
    except Exception as exc:
        _SETTINGS_READ_ERROR = f'{type(exc).__name__}: {exc}'
        return _cache_suite_settings(path, {}, signature=signature)


def read_suite_settings() -> dict:
    """Return an isolated copy while parsing the canonical JSON at most once."""
    try:
        return copy.deepcopy(_read_suite_settings_cached())
    except Exception:
        return dict(_read_suite_settings_cached())


def _write_suite_settings(data: dict, *, capability=None) -> bool:
    """Lowest write boundary; only the exact pending capability can transition."""
    global _PENDING_TOGGLE_CAPABILITY, _PERSISTENCE_OWNER_STATE
    if not isinstance(data, dict):
        _set_write_status(False, 'INVALID_PAYLOAD')
        return False
    if registration_write_guarded():
        if capability is _PENDING_TOGGLE_CAPABILITY:
            _PENDING_TOGGLE_CAPABILITY = None
        _set_write_status(False, 'REGISTRATION_GUARD')
        return False
    current = _read_suite_settings_cached()
    if _SETTINGS_READ_ERROR:
        _set_write_status(False, 'READ_ERROR_PRESERVED', _SETTINGS_READ_ERROR)
        return False
    enabled = bool(dict(current.get('preferences') or {}).get('npanel_state_save', True))
    next_enabled = bool(dict(data.get('preferences') or {}).get('npanel_state_save', enabled))
    changing = next_enabled is not enabled
    if capability is not None:
        if capability is not _PENDING_TOGGLE_CAPABILITY:
            _set_write_status(False, 'CAPABILITY_INVALID_OR_CONSUMED')
            return False
        # Consume before any subsequent validation or filesystem write.  A
        # failed/stale capability can never be retried.
        _PENDING_TOGGLE_CAPABILITY = None
        state = _PERSISTENCE_OWNER_STATE
        identity = _authenticated_owner_identity(_live_persistence_owner())
        try:
            actual_enabled = getattr(_live_persistence_owner(), 'npanel_state_save')
        except Exception:
            actual_enabled = None
        valid = (
            isinstance(capability, _PersistenceToggleCapability)
            and changing
            and identity == (capability.owner_pointer, capability.rna_identifier)
            and isinstance(state, dict)
            and state.get('owner_pointer') == capability.owner_pointer
            and state.get('rna_identifier') == capability.rna_identifier
            and state.get('saved_enabled') is capability.previous
            and enabled is capability.previous
            and next_enabled is capability.current
            and isinstance(actual_enabled, bool)
            and actual_enabled is capability.current
            and _SETTINGS_CACHE_SIGNATURE == capability.file_signature
            and all(key == 'preferences' or data.get(key) == value for key, value in current.items())
            and all(key == 'preferences' or key in current for key in data)
        )
        if not valid:
            _set_write_status(False, 'CAPABILITY_BOUNDARY_REJECTED')
            return False
    elif changing:
        _set_write_status(False, 'TOGGLE_CAPABILITY_REQUIRED')
        return False
    if not enabled and not (capability is not None and changing and next_enabled is True):
        _set_write_status(False, 'PERSISTENCE_DISABLED')
        return False
    path = suite_settings_path(create=True)
    try:
        serialized = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
        try:
            if path.exists() and path.read_text(encoding='utf-8') == serialized:
                _cache_suite_settings(path, copy.deepcopy(data))
                _set_write_status(True, 'UNCHANGED')
                return True
        except Exception:
            pass
        tmp = path.with_suffix(path.suffix + '.tmp')
        tmp.write_text(serialized, encoding='utf-8')
        os.replace(str(tmp), str(path))
        try:
            cached = copy.deepcopy(data)
        except Exception:
            cached = dict(data)
        _cache_suite_settings(path, cached)
        if capability is not None:
            _PERSISTENCE_OWNER_STATE = {
                'owner_pointer': capability.owner_pointer,
                'rna_identifier': capability.rna_identifier,
                'saved_enabled': capability.current,
            }
        _set_write_status(True, 'REPLACED')
        return True
    except Exception as exc:
        try:
            path.with_suffix(path.suffix + '.tmp').unlink(missing_ok=True)
        except Exception:
            pass
        _set_write_status(False, 'REPLACE_ERROR', exc)
        return False


def write_suite_settings(data: dict) -> bool:
    return _write_suite_settings(data, capability=None)


def read_suite_section(section_name: str, default=None):
    key = str(section_name or '').strip()
    default = {} if default is None else default
    if not key:
        return default
    value = _read_suite_settings_cached().get(key, default)
    if isinstance(default, dict):
        if not isinstance(value, dict):
            return dict(default)
        try:
            return copy.deepcopy(value)
        except Exception:
            return dict(value)
    try:
        return copy.deepcopy(value)
    except Exception:
        return default if value is None else value


def write_suite_sections(sections: dict) -> bool:
    """Atomically update multiple top-level sections using the cached document."""
    if not isinstance(sections, dict) or not sections:
        return False
    if registration_write_guarded():
        return False
    current = _read_suite_settings_cached()
    if _SETTINGS_READ_ERROR:
        _set_write_status(False, 'READ_ERROR_PRESERVED', _SETTINGS_READ_ERROR)
        return False
    data = dict(current)
    for raw_key, payload in sections.items():
        key = str(raw_key or '').strip()
        if not key:
            continue
        try:
            data[key] = _deep_merge_unknown(current.get(key), payload)
        except Exception:
            data[key] = payload
    return write_suite_settings(data)


def write_suite_section(section_name: str, payload) -> bool:
    key = str(section_name or '').strip()
    if not key:
        return False
    return write_suite_sections({key: payload})


def npanel_state_save_enabled(default: bool = True) -> bool:
    """Return whether N-panel state changes should be saved immediately."""
    try:
        prefs = read_suite_section('preferences', {})
        if isinstance(prefs, dict) and 'npanel_state_save' in prefs:
            return bool(prefs.get('npanel_state_save'))
    except Exception:
        pass
    return bool(default)


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _clean_storage_identifier(value: object, fallback: str = PACKAGE_ID) -> str:
    text = str(value or '').replace('\\', '/').strip().strip('/')
    if not text:
        return fallback
    if '.user_default.' in text or text.startswith('bl_ext.'):
        text = text.rsplit('.', 1)[-1]
    text = text.rsplit('/', 1)[-1].rsplit('.', 1)[-1]
    cleaned = ''.join(ch if (ch.isalnum() or ch in {'_', '-'}) else '_' for ch in text).strip('_-')
    return cleaned or fallback


def _clean_part(value: object) -> str:
    text = str(value or '').replace('\\', '/').strip('/')
    pieces = [piece for piece in text.split('/') if piece and piece not in {'.', '..'}]
    return '/'.join(pieces)


def _clean_parts(parts: Iterable[object]) -> list[str]:
    result: list[str] = []
    for part in parts:
        cleaned = _clean_part(part)
        if cleaned:
            result.extend([piece for piece in cleaned.split('/') if piece])
    return result


def _blender_version() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None) if bpy is not None else None
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def _path_is_inside_package(path: Path) -> bool:
    try:
        target = path.resolve()
        root = _package_root().resolve()
        return target == root or root in target.parents
    except Exception:
        return False


def _extension_identifier_candidates(package_id: str) -> list[str]:
    candidates: list[str] = []
    raw_values = [
        str(package_id or '').strip(),
        str(__package__ or '').strip(),
        str(__name__.rpartition('.')[0] if '.' in __name__ else '').strip(),
        PACKAGE_ID,
    ]
    for value in raw_values:
        if not value:
            continue
        for candidate in (value, value.rsplit('.', 1)[-1]):
            candidate = str(candidate or '').strip()
            if candidate and candidate not in candidates:
                candidates.append(candidate)
    return candidates


def _suite_storage_root(package: object | None = None, create: bool = False) -> Path:
    """Return the canonical writable root for all Smart Shader runtime data.

    New builds intentionally keep generated JSON, reports, caches, runtime helper
    files, and migrated extension data inside Blender's versioned
    config/Smart_Shader_Suite directory instead of writing new data into
    config/extension_data.
    """
    # All first-party Smart Shader package aliases share one commercial data
    # folder so the user can back up, inspect, or remove the package data from a
    # single place.  Non-default package identifiers are kept as nested package
    # folders only as a defensive compatibility path for external callers.
    identifier = _clean_storage_identifier(package or PACKAGE_ID)
    root = suite_settings_dir(create=create)
    if identifier not in {_clean_storage_identifier(PACKAGE_ID), _clean_storage_identifier('smart_shader_suite')}:
        root = root / 'packages' / identifier
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


def _legacy_user_resource_path(kind: str, rel: str) -> Path | None:
    if bpy is None:
        return None
    user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
    if not callable(user_resource):
        return None
    try:
        value = user_resource(kind, path=rel, create=False)
    except TypeError:
        try:
            value = user_resource(kind, rel, False)
        except Exception:
            value = ''
    except Exception:
        value = ''
    return Path(value) if value else None


def _legacy_extension_roots(package_id: str) -> list[Path]:
    """Return old automatic storage roots without creating them.

    These paths are read only for one-time migration. They are deliberately not
    returned as active write destinations anymore.
    """
    roots: list[Path] = []

    def add(path: Path | None) -> None:
        if path is None:
            return
        try:
            path = path.resolve()
        except Exception:
            pass
        if _path_is_inside_package(path):
            return
        if path not in roots:
            roots.append(path)

    if bpy is not None:
        fn = getattr(getattr(bpy, 'utils', None), 'extension_path_user', None)
        if callable(fn):
            for identifier in _extension_identifier_candidates(package_id):
                for args, kwargs in (
                    ((identifier,), {'path': '', 'create': False}),
                    ((identifier,), {'create': False}),
                    ((identifier, ''), {'create': False}),
                ):
                    try:
                        value = fn(*args, **kwargs)
                    except TypeError:
                        continue
                    except Exception:
                        continue
                    if value:
                        add(Path(value))
        for identifier in _extension_identifier_candidates(package_id):
            add(_legacy_user_resource_path('CONFIG', f'extension_data/user_default/{identifier}'))
            add(_legacy_user_resource_path('DATAFILES', f'extensions/user_default/{identifier}'))
            add(_legacy_user_resource_path('DATAFILES', f'smart_shader_suite/{identifier}'))
        try:
            config = bpy.utils.user_resource('CONFIG', create=False) or ''
            if config:
                for identifier in _extension_identifier_candidates(package_id):
                    add(Path(config) / 'extension_data' / 'user_default' / identifier)
        except Exception:
            pass

    version = _blender_version()
    identifiers = _extension_identifier_candidates(package_id)
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        base = Path(roaming) / 'Blender Foundation' / 'Blender' / version
    elif sys.platform == 'darwin':
        base = Path.home() / 'Library' / 'Application Support' / 'Blender' / version
    else:
        base = Path.home() / '.config' / 'blender' / version
    for identifier in identifiers:
        add(base / 'extension_data' / 'user_default' / identifier)
    return roots


def _merge_legacy_tree(src: Path, dst: Path) -> bool:
    try:
        src = Path(src)
        dst = Path(dst)
        if not src.exists() or not src.is_dir():
            return False
        try:
            src_resolved = src.resolve()
            dst_resolved = dst.resolve()
            if src_resolved == dst_resolved or src_resolved in dst_resolved.parents or dst_resolved in src_resolved.parents:
                return False
        except Exception:
            pass
        copied = False
        dst.mkdir(parents=True, exist_ok=True)
        for item in src.iterdir():
            if item.name in _IGNORED_MIGRATION_NAMES:
                continue
            target = dst / item.name
            if item.is_dir():
                if _merge_legacy_tree(item, target):
                    copied = True
            elif item.is_file():
                if not target.exists():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(item, target)
                    copied = True
        return copied
    except Exception:
        return False


def migrate_legacy_extension_data(package: object | None = None, *, create: bool = True) -> bool:
    """Merge old extension_data/user_default files into Smart_Shader_Suite.

    The migration is non-destructive: old files are copied only when the new
    canonical target does not already contain a file with the same relative path.
    New writes always go to Smart_Shader_Suite regardless of whether migration
    finds legacy data.
    """
    pkg = package_id(package)
    marker = _clean_storage_identifier(pkg)
    if marker in _MIGRATED_EXTENSION_DATA_PACKAGES:
        return False
    _MIGRATED_EXTENSION_DATA_PACKAGES.add(marker)
    target = _suite_storage_root(pkg, create=create)
    migrated = False
    for legacy_root in _legacy_extension_roots(pkg):
        if _merge_legacy_tree(legacy_root, target):
            migrated = True
    return migrated


def _extension_path_user_root(package_id: str, create: bool) -> Path | None:
    return _suite_storage_root(package_id, create=create)


def _user_resource_root(package_id: str, create: bool) -> Path | None:
    return _suite_storage_root(package_id, create=create)


def _platform_user_default_package_root(package_id: str, create: bool) -> Path:
    return _suite_storage_root(package_id, create=create)

def package_id(default: object = None) -> str:
    value = str(default or PACKAGE_ID or '').strip()
    return value or PACKAGE_ID


def manifest_extension_id(default: str = PACKAGE_ID) -> str:
    return package_id(default)


def extension_user_root(package: object | None = None, *, create: bool = False) -> Path:
    pkg = package_id(package)
    root = _suite_storage_root(pkg, create=create)
    if create:
        migrate_legacy_extension_data(pkg, create=True)
    return root


def user_default_root(*parts: object, package_id: str | None = None, create: bool = True) -> Path:
    root = extension_user_root(package_id or PACKAGE_ID, create=create)
    clean = _clean_parts(parts)
    path = root.joinpath(*clean) if clean else root
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def extension_dir(create: bool = False) -> Path:
    return extension_user_root(PACKAGE_ID, create=create)


def user_data_dir(*parts: object, create: bool = False) -> Path:
    path = extension_user_root(PACKAGE_ID, create=create) / USER_DATA_DIRNAME
    clean = _clean_parts(parts)
    if clean:
        path = path.joinpath(*clean)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def user_data_file(*parts: object, create_parent: bool = False) -> Path:
    if not parts:
        raise ValueError('user_data_file requires at least one path component')
    clean = _clean_parts(parts)
    if not clean:
        raise ValueError('user_data_file requires a non-empty filename')
    path = user_data_dir(*clean[:-1], create=create_parent) / clean[-1]
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def addon_data_path(*parts: object, create: bool = True) -> Path:
    clean = _clean_parts(parts)
    if not clean:
        return addon_data_dir(create=create)
    path = addon_data_dir(*clean[:-1], create=create) / clean[-1]
    return path


def storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def storage_path(filename: object, *parts: object, create: bool = True) -> Path:
    clean = _clean_parts([*parts, filename])
    if not clean:
        raise ValueError('storage_path requires a filename')
    path = storage_dir(*clean[:-1], create=create) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def settings_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('settings', *parts, create=create)


def runtime_dir(*parts: object, create: bool = True, package: object | None = None) -> Path:
    pkg = package_id(package)
    root = extension_user_root(pkg, create=create) / USER_DATA_DIRNAME / 'runtime'
    clean = _clean_parts(parts)
    if clean:
        root = root.joinpath(*clean)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def settings_file(name: object, *, create: bool = True) -> Path:
    clean = _clean_part(name)
    if not clean:
        raise ValueError('settings_file requires a filename')
    path = settings_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def runtime_file(filename: object, *subdirs: object, create: bool = True, package: object | None = None) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('runtime_file requires a filename')
    path = runtime_dir(*clean[:-1], create=create, package=package) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_path(filename: object, *subdirs: object, package_id: str | None = None, create: bool = True) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('addon_storage_path requires a filename')
    root = extension_user_root(package_id or PACKAGE_ID, create=create) / USER_DATA_DIRNAME / 'storage'
    if len(clean) > 1:
        root = root.joinpath(*clean[:-1])
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root / clean[-1]


def write_json(filename: object, payload: Any, subdir: str = 'reports') -> Path:
    path = user_data_file(subdir, filename, create_parent=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    return path


def read_json(path: str | Path, default: Any = None) -> Any:
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return default


def atomic_write_text(path: str | Path, text: str, *, encoding: str = 'utf-8') -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + '.tmp')
    tmp.write_text(text, encoding=encoding)
    tmp.replace(target)


def atomic_write_json(path: str | Path, data: Any, *, indent: int = 2, ensure_ascii: bool = False, sort_keys: bool = False) -> None:
    atomic_write_text(path, json.dumps(data, indent=indent, ensure_ascii=ensure_ascii, sort_keys=sort_keys, default=str), encoding='utf-8')


def migrate_legacy_file(legacy_path: Path | None, target_path: Path | None, *, remove_legacy: bool = True) -> bool:
    if legacy_path is None or target_path is None:
        return False
    legacy = Path(legacy_path)
    target = Path(target_path)
    try:
        if not legacy.exists() or target.exists():
            return False
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(legacy, target)
        if remove_legacy:
            try:
                legacy.unlink()
            except Exception:
                pass
        return True
    except Exception:
        return False
