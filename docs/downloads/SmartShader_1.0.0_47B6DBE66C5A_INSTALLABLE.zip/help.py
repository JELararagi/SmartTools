# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Lazy-loaded help popups for Smart Shader.

This module intentionally contains only the popup runtime and the source-property
scanner used by the popup. Long help text and topic tables live in
help_catalog.py and are imported only after a Help button is clicked.
"""

from __future__ import annotations

import ast
import re
import unicodedata
from pathlib import Path
from typing import Iterable

from .translation import loc_text as _lt
from .translation import tx
try:
    from .translation import _STATIC_EN_JA as _HELP_STATIC_EN_JA
except Exception:  # pragma: no cover - defensive fallback for stripped builds.
    _HELP_STATIC_EN_JA = {}


def _scene(context):
    return getattr(context, 'scene', None) if context is not None else None


def _t(context, en: str, ja: str) -> str:
    return tx(_scene(context), str(en or ''), str(ja or ''))


def _display_units(value: str) -> int:
    total = 0
    for char in str(value or ''):
        if char == '\t':
            total += 4
        elif unicodedata.east_asian_width(char) in {'F', 'W'}:
            total += 2
        else:
            total += 1
    return total


_BREAK_CHARS = '/\\-–—、。・，．,.;:;:!?！？)]}）】』」〉》'
_DEFAULT_POPUP_WIDTH_PX = 860
_MIN_TEXT_WIDTH_PX = 180
_MAX_TEXT_WIDTH_PX = 2400
_BASE_POPUP_PADDING_PX = 64
_NESTED_POPUP_PADDING_PX = 28
_ICON_TEXT_PADDING_PX = 28


def _last_break_index(value: str) -> int:
    last = -1
    for index, char in enumerate(str(value or '')):
        if char.isspace() or char in _BREAK_CHARS:
            last = index + 1
    return last


def _ui_scale(context) -> float:
    try:
        prefs = getattr(context, 'preferences', None)
        system = getattr(prefs, 'system', None)
        scale = float(getattr(system, 'ui_scale', 1.0) or 1.0)
        return max(0.5, min(scale, 4.0))
    except Exception:
        return 1.0


def _ui_font_size(context) -> int:
    points = 12.0
    try:
        prefs = getattr(context, 'preferences', None)
        styles = getattr(prefs, 'ui_styles', None)
        style = styles[0] if styles else None
        for attr in ('widget_label', 'widget', 'menu_item'):
            block = getattr(style, attr, None)
            value = float(getattr(block, 'points', 0) or 0)
            if value > 0:
                points = value
                break
    except Exception:
        points = 12.0
    return max(8, min(32, int(round(points * _ui_scale(context)))))


def _measure_text_px(context, value: str) -> float:
    text = str(value or '')
    if not text:
        return 0.0
    try:
        import blf  # type: ignore

        font_id = 0
        size = _ui_font_size(context)
        try:
            blf.size(font_id, size)
        except TypeError:
            blf.size(font_id, size, 72)
        width = float((blf.dimensions(font_id, text) or (0.0, 0.0))[0] or 0.0)
        if width > 0.0:
            return width
    except Exception:
        pass
    # Fallback for syntax checks or unusual Blender states.  It is pixel based:
    # ASCII-like glyphs are estimated at roughly 0.58em and full-width glyphs at
    # about one em, so wrapping still follows popup pixel width rather than a
    # fixed character count.
    font_size = float(_ui_font_size(context))
    return float(_display_units(text)) * max(4.0, font_size * 0.58)


def _context_region_width_px(context) -> int:
    try:
        region = getattr(context, 'region', None)
        return int(getattr(region, 'width', 0) or 0)
    except Exception:
        return 0


def _context_region_type(context) -> str:
    try:
        region = getattr(context, 'region', None)
        return str(getattr(region, 'type', '') or '')
    except Exception:
        return ''


def _resolve_popup_width_px(context, popup_width: int | None = None) -> int:
    requested = int(popup_width or _DEFAULT_POPUP_WIDTH_PX)
    requested = max(240, min(requested, _MAX_TEXT_WIDTH_PX))
    region_width = _context_region_width_px(context)
    region_type = _context_region_type(context)
    if region_width > 0 and region_type not in {'UI', 'TOOLS'}:
        # During invoke_popup drawing Blender normally exposes the popup region.
        # If the draw context still points at the large source editor, keep the
        # requested popup width.  If the popup is smaller because of screen
        # bounds or scaling, use that actual smaller width.
        if region_width <= requested + 120:
            return max(240, min(region_width, requested))
    return requested


def _effective_text_width_px(
    context,
    *,
    popup_width: int | None = None,
    inset_level: int = 0,
    icon: bool = False,
) -> float:
    popup_px = float(_resolve_popup_width_px(context, popup_width))
    padding = _BASE_POPUP_PADDING_PX + max(0, int(inset_level)) * _NESTED_POPUP_PADDING_PX
    if icon:
        padding += _ICON_TEXT_PADDING_PX
    return float(max(_MIN_TEXT_WIDTH_PX, min(_MAX_TEXT_WIDTH_PX, popup_px - padding)))


def _wrap_to_pixel_width(
    paragraph: str,
    context,
    *,
    first_width_px: float,
    rest_width_px: float,
) -> list[str]:
    paragraph = str(paragraph or '').replace('\t', '    ').strip()
    if not paragraph:
        return []
    first_limit = max(_MIN_TEXT_WIDTH_PX, float(first_width_px or 0.0))
    rest_limit = max(_MIN_TEXT_WIDTH_PX, float(rest_width_px or first_limit))
    if _measure_text_px(context, paragraph) <= first_limit:
        return [paragraph]

    lines: list[str] = []
    current = ''
    break_index = -1

    for char in paragraph:
        if current:
            limit = first_limit if not lines else rest_limit
            trial = f'{current}{char}'
            if _measure_text_px(context, trial) > limit:
                if 0 < break_index < len(current):
                    line = current[:break_index].rstrip()
                    remainder = current[break_index:].lstrip()
                    if line:
                        lines.append(line)
                    current = remainder
                    break_index = _last_break_index(current)
                    limit = rest_limit
                    if current and _measure_text_px(context, f'{current}{char}') > limit:
                        lines.append(current.rstrip())
                        current = ''
                        break_index = -1
                else:
                    if current.strip():
                        lines.append(current.rstrip())
                    current = ''
                    break_index = -1
        if not current and char.isspace():
            continue
        current += char
        if char.isspace() or char in _BREAK_CHARS:
            break_index = len(current)

    if current.strip():
        lines.append(current.strip())
    return lines or [paragraph]


def _wrap_raw(
    layout,
    context,
    text: str,
    *,
    width: int | None = None,
    popup_width: int | None = None,
    inset_level: int = 0,
    icon: str = 'NONE',
) -> None:
    del width  # Legacy keyword kept for compatibility; wrapping is popup-width based.
    text = str(text or '').strip()
    if not text:
        return
    rest_width = _effective_text_width_px(context, popup_width=popup_width, inset_level=inset_level, icon=False)
    icon_width = _effective_text_width_px(context, popup_width=popup_width, inset_level=inset_level, icon=True)
    first_line = True
    for paragraph in text.splitlines() or [text]:
        if not paragraph.strip():
            layout.separator(factor=0.4)
            continue
        first_width = icon_width if first_line and icon and icon != 'NONE' else rest_width
        for line in _wrap_to_pixel_width(paragraph, context, first_width_px=first_width, rest_width_px=rest_width):
            kwargs = {'text': line}
            if first_line and icon and icon != 'NONE':
                kwargs['icon'] = icon
            layout.label(**kwargs)
            first_line = False


def _wrap(
    layout,
    context,
    en: str,
    ja: str | None = None,
    *,
    width: int | None = None,
    popup_width: int | None = None,
    inset_level: int = 0,
    icon: str = 'NONE',
) -> None:
    _wrap_raw(
        layout,
        context,
        _t(context, en, ja if ja is not None else en),
        width=width,
        popup_width=popup_width,
        inset_level=inset_level,
        icon=icon,
    )

def _slug(value: str) -> str:
    return re.sub(r'[^0-9a-z]+', '_', str(value or '').strip().lower()).strip('_')


def _catalog_module():
    import importlib
    return importlib.import_module(f"{__package__}.help_catalog")


def _catalog_aliases() -> dict[str, str]:
    try:
        aliases = getattr(_catalog_module(), "ALIASES", {})
        return aliases if isinstance(aliases, dict) else {}
    except Exception:
        return {}


def _catalog_topics() -> dict[str, dict]:
    try:
        topics = getattr(_catalog_module(), "TOPICS", {})
        return topics if isinstance(topics, dict) else {}
    except Exception:
        return {}



def _literal_raw_text(node) -> str:
    if node is None:
        return ''
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.JoinedStr):
        parts: list[str] = []
        for item in node.values:
            if isinstance(item, ast.Constant) and isinstance(item.value, str):
                parts.append(item.value)
            else:
                return ''
        return ''.join(parts)
    return ''


def _split_marked_pair_for_help(raw: str) -> tuple[str, str]:
    text = str(raw or '').strip()
    if not text:
        return '', ''
    markers = list(re.finditer(r'(?i)\b(EN|JP|JA)\b\s*:\s*', text))
    if len(markers) >= 2:
        en_parts: list[str] = []
        ja_parts: list[str] = []
        for index, marker in enumerate(markers):
            tag = marker.group(1).upper()
            start = marker.end()
            end = markers[index + 1].start() if index + 1 < len(markers) else len(text)
            chunk = text[start:end].strip().strip('/').strip()
            if not chunk:
                continue
            if tag == 'EN':
                en_parts.append(chunk)
            else:
                ja_parts.append(chunk)
        return '\n'.join(en_parts).strip(), '\n'.join(ja_parts).strip()
    if ' / ' in text and text.count(' / ') == 1:
        left, right = (part.strip() for part in text.split(' / ', 1))
        if left and right:
            left_has_ja = any('\u3040' <= ch <= '\u30ff' or '\u4e00' <= ch <= '\u9fff' for ch in left)
            right_has_ja = any('\u3040' <= ch <= '\u30ff' or '\u4e00' <= ch <= '\u9fff' for ch in right)
            if left_has_ja and not right_has_ja:
                return right, left
            if right_has_ja and not left_has_ja:
                return left, right
    # Plain English RNA labels from bundled tools are translated through the
    # shared static table so the popup can still display only the active
    # language instead of a mixed or bilingual label.
    try:
        static_ja = str(_HELP_STATIC_EN_JA.get(text, '') or '')
    except Exception:
        static_ja = ''
    if static_ja and static_ja != text:
        return text, static_ja
    return text, text


def _literal_pair(node, context=None) -> tuple[str, str]:
    if node is None:
        return '', ''
    raw = _literal_raw_text(node)
    if raw:
        return _split_marked_pair_for_help(raw)
    if isinstance(node, ast.Call):
        func_name = ''
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = node.func.attr
        args = list(node.args or [])
        if func_name in {'_ui'} and len(args) >= 2:
            return _literal_raw_text(args[0]), _literal_raw_text(args[1])
        if func_name == 'tx' and len(args) >= 3:
            return _literal_raw_text(args[1]), _literal_raw_text(args[2])
        if func_name in {'_lt', 'loc_text'}:
            if len(args) >= 2:
                return _literal_raw_text(args[0]), _literal_raw_text(args[1])
            if args:
                return _split_marked_pair_for_help(_literal_raw_text(args[0]))
    return '', ''


def _literal_text(node, context=None) -> str:
    en, ja = _literal_pair(node, context)
    if en or ja:
        return tx(_scene(context), en or ja, ja or en)
    return ''


def _call_func_name(node) -> str:
    if not isinstance(node, ast.Call):
        return ''
    func = node.func
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return ''


def _property_target_name(target) -> str:
    if isinstance(target, ast.Name):
        return target.id
    if isinstance(target, ast.Attribute):
        return target.attr
    if isinstance(target, ast.Tuple) and target.elts:
        return _property_target_name(target.elts[0])
    return ''


_SOURCE_RULE_FILES_DEFAULT: tuple[str, ...] = ()  # guard: referenced but never defined (pre-existing)


def _addon_root() -> Path:
    """Package root used to resolve help source-scanning paths (guard: was undefined)."""
    return Path(__file__).resolve().parent


_PROPERTY_SOURCE_CACHE: dict[tuple[str, ...], tuple[dict[str, str], ...]] = {}


def _parsed_property_sources(files_filter: tuple[str, ...] | None = None) -> tuple[dict[str, str], ...]:
    root = _addon_root()
    key = tuple(sorted(str(item) for item in (files_filter or ())))
    cached = _PROPERTY_SOURCE_CACHE.get(key)
    if cached is not None:
        return cached
    records: list[dict[str, str]] = []
    if key:
        candidate_paths = [root / item for item in key]
    else:
        # Fallback scanning remains available, but skip vendored libraries and
        # cache files so a Help click never spends time parsing unrelated code.
        candidate_paths = sorted(root.rglob('*.py'))
    for path in candidate_paths:
        try:
            rel = path.relative_to(root).as_posix()
        except Exception:
            continue
        if rel == 'help.py' or '/__pycache__/' in rel:
            continue
        if not path.exists():
            continue
        try:
            tree = ast.parse(path.read_text(encoding='utf-8'))
        except Exception:
            continue
        for node in ast.walk(tree):
            value = None
            target = ''
            if isinstance(node, ast.AnnAssign):
                value = node.value
                # Blender property declarations often use PEP-526 syntax:
                #     prop_name: StringProperty(...)
                # In that form the call lives in the annotation, not in value.
                if not isinstance(value, ast.Call):
                    value = getattr(node, 'annotation', None)
                target = _property_target_name(node.target)
            elif isinstance(node, ast.Assign) and node.targets:
                value = node.value
                target = _property_target_name(node.targets[0])
            if not isinstance(value, ast.Call):
                continue
            func_name = _call_func_name(value)
            if not func_name.endswith('Property'):
                continue
            label_en = label_ja = ''
            desc_en = desc_ja = ''
            for kw in value.keywords or []:
                if kw.arg == 'name':
                    label_en, label_ja = _literal_pair(kw.value, None)
                elif kw.arg == 'description':
                    desc_en, desc_ja = _literal_pair(kw.value, None)
            if not (label_en or label_ja):
                generated = target.replace('_', ' ').strip().title()
                label_en = label_ja = generated
            records.append({'id': target, 'label_en': label_en or label_ja, 'label_ja': label_ja or label_en, 'description_en': desc_en or desc_ja, 'description_ja': desc_ja or desc_en, 'file': rel, 'type': func_name})
    result = tuple(records)
    _PROPERTY_SOURCE_CACHE[key] = result
    return result


def _source_settings_for_topic(topic: str) -> list[dict[str, str]]:
    content = _catalog_topics().get(topic) or {}
    prefixes_raw = content.get('source_prefixes')
    files_raw = content.get('source_files')
    # Source scanning is explicit opt-in per help topic.  Topics without these
    # keys stay lightweight and do not accidentally list unrelated settings.
    if prefixes_raw is None and files_raw is None:
        return []
    prefixes = tuple(str(item) for item in (prefixes_raw or ()))
    files = tuple(str(item) for item in (files_raw if files_raw is not None else _SOURCE_RULE_FILES_DEFAULT))
    if not prefixes and not files:
        return []
    out: list[dict[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for rec in _parsed_property_sources(files):
        rel = str(rec.get('file') or '')
        ident = str(rec.get('id') or '')
        if files and rel not in files:
            continue
        if prefixes and not any(ident.startswith(prefix) or ident == prefix for prefix in prefixes):
            if not any(str(rec.get('label') or '').lower().startswith(prefix.lower()) for prefix in prefixes):
                continue
        key = (ident, rel)
        if key in seen:
            continue
        seen.add(key)
        label_en = str(rec.get('label_en') or rec.get('label') or ident).strip()
        label_ja = str(rec.get('label_ja') or rec.get('label') or label_en).strip()
        desc_en = str(rec.get('description_en') or rec.get('description') or '').strip()
        desc_ja = str(rec.get('description_ja') or rec.get('description') or '').strip()
        if not (desc_en or desc_ja):
            desc_en = 'This setting is registered by the feature and is saved or used by its UI.'
            desc_ja = 'この設定は機能側で登録され、UIで保存または使用されます。'
        out.append({'label_en': label_en or label_ja, 'label_ja': label_ja or label_en, 'desc_en': desc_en or desc_ja, 'desc_ja': desc_ja or desc_en})
    return out


def _resolved_topic(topic: str) -> str:
    raw = _slug(topic)
    topics = _catalog_topics()
    return _catalog_aliases().get(raw, raw if raw in topics else 'smart_shader_root')


def _draw_section(
    layout,
    context,
    title_en: str,
    title_ja: str,
    paragraphs_en: Iterable[str],
    paragraphs_ja: Iterable[str],
    *,
    popup_width: int | None = None,
) -> None:
    box = layout.box()
    _wrap_raw(box, context, _t(context, title_en, title_ja), popup_width=popup_width, icon='BOOKMARKS')
    en_items = list(paragraphs_en or [])
    ja_items = list(paragraphs_ja or [])
    count = max(len(en_items), len(ja_items))
    for index in range(count):
        en = en_items[index] if index < len(en_items) else (en_items[-1] if en_items else '')
        ja = ja_items[index] if index < len(ja_items) else (ja_items[-1] if ja_items else en)
        _wrap(box, context, en, ja, popup_width=popup_width)
        if index + 1 < count:
            box.separator(factor=0.4)


def _draw_setting_entries(layout, context, entries: list[dict[str, str]], *, popup_width: int | None = None) -> None:
    box = layout.box()
    _wrap_raw(box, context, _t(context, '3. Settings', '3. 設定項目'), popup_width=popup_width, icon='PREFERENCES')
    if not entries:
        _wrap(
            box,
            context,
            'This tool exposes commands only or its settings are inherited from the related sections listed in this help popup.',
            'このツールはコマンド中心の機能、またはこのヘルプ内の関連セクションに記載した設定を継承して使います。',
            popup_width=popup_width,
        )
        return
    seen_labels: set[str] = set()
    for item in entries:
        label = _t(context, item.get('label_en', ''), item.get('label_ja', ''))
        desc = _t(context, item.get('desc_en', ''), item.get('desc_ja', ''))
        key = label.strip().lower()
        if not label.strip() or key in seen_labels:
            continue
        seen_labels.add(key)
        row_box = box.box()
        _wrap_raw(row_box, context, label, popup_width=popup_width, inset_level=1, icon='BLANK1')
        if desc.strip():
            _wrap_raw(row_box, context, desc, popup_width=popup_width, inset_level=1)


def draw_help(layout, context, topic: str, *, popup_width: int | None = None) -> None:
    topic_key = _resolved_topic(topic)
    topics = _catalog_topics()
    content = topics.get(topic_key) or topics.get('smart_shader_root') or {}
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass

    title_box = layout.box()
    _wrap_raw(title_box, context, _t(context, str(content.get('title_en') or 'Help'), str(content.get('title_ja') or 'ヘルプ')), popup_width=popup_width, icon='BOOKMARKS')

    _draw_section(
        layout,
        context,
        '1. Feature Overview',
        '1. 機能概要',
        content.get('overview_en') or (),
        content.get('overview_ja') or (),
        popup_width=popup_width,
    )
    _draw_section(
        layout,
        context,
        '2. Usage',
        '2. 使用方法',
        content.get('usage_en') or (),
        content.get('usage_ja') or (),
        popup_width=popup_width,
    )
    entries = list(content.get('settings') or [])
    try:
        entries.extend(_source_settings_for_topic(topic_key))
    except Exception:
        pass
    _draw_setting_entries(layout, context, entries, popup_width=popup_width)
