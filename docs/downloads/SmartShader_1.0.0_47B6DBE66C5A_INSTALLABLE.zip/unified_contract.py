"""Machine-readable SmartTools N-panel, ownership, and persistence contract."""

CONTRACT_VERSION = 2
EXTENSION_ID = 'smart_shader_suite'
SUITE_ID = 'smart_shader_suite'
SUITE_OWNER_UUID = '3f6d8d7f-671d-4ff1-bf32-bf15518208aa'
GENERATION = '5.18.230'
MANAGER_TOOL_KEY = 'SMART_SHADER'
MANAGER_PUBLIC_API = 'get_placement_state'
MANAGER_API_CALL = 'get_placement_state(tool_key, context, editor_key=...)'
CONFIG_FOLDER = 'Smart_Shader_Suite'
CONFIG_FILE = 'Smart_Shader_Suite.json'
STATE_SAVE_PATH = 'window_manager.sss_npanel_settings.npanel_state_save'
SECTION_OPEN_PATH = 'window_manager.sss_npanel_settings.show_always_on_toggles'
RUNTIME_TOGGLE_PATHS = (
    'window_manager.sss_npanel_settings.integrated_material_library_auto_refresh_on_load',
    'window_manager.sss_npanel_settings.smart_material_smart_settings_handlers',
    'window_manager.sss_npanel_settings.smart_toon_live_sync_enabled',
    'window_manager.sss_npanel_settings.material_editor_load_restore_enabled',
    'window_manager.sss_npanel_settings.transform_guard_enabled',
    'window_manager.sss_npanel_settings.legacy_proxy_cleanup_enabled',
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()

LOGICAL_EDITORS = (
    'VIEW_3D', 'IMAGE_EDITOR', 'UV_EDITOR', 'SHADER_EDITOR', 'COMPOSITOR',
    'GEOMETRY_NODE_EDITOR', 'TEXTURE_NODE_EDITOR', 'VIDEO_SEQUENCER',
    'MOVIE_CLIP_EDITOR', 'DOPE_SHEET', 'GRAPH_EDITOR', 'DRIVERS',
    'NLA_EDITOR', 'TEXT_EDITOR', 'ASSET_BROWSER', 'FILE_BROWSER', 'SPREADSHEET',
)
PHYSICAL_ROOTS = (
    'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR',
    'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR',
    'FILE_BROWSER', 'SPREADSHEET',
)
LOGICAL_TO_PHYSICAL = {
    'VIEW_3D': 'VIEW_3D',
    'IMAGE_EDITOR': 'IMAGE_EDITOR', 'UV_EDITOR': 'IMAGE_EDITOR',
    'SHADER_EDITOR': 'NODE_EDITOR', 'COMPOSITOR': 'NODE_EDITOR',
    'GEOMETRY_NODE_EDITOR': 'NODE_EDITOR', 'TEXTURE_NODE_EDITOR': 'NODE_EDITOR',
    'VIDEO_SEQUENCER': 'SEQUENCE_EDITOR', 'MOVIE_CLIP_EDITOR': 'CLIP_EDITOR',
    'DOPE_SHEET': 'DOPESHEET_EDITOR',
    'GRAPH_EDITOR': 'GRAPH_EDITOR', 'DRIVERS': 'GRAPH_EDITOR',
    'NLA_EDITOR': 'NLA_EDITOR', 'TEXT_EDITOR': 'TEXT_EDITOR',
    'ASSET_BROWSER': 'FILE_BROWSER', 'FILE_BROWSER': 'FILE_BROWSER',
    'SPREADSHEET': 'SPREADSHEET',
}
ROOT_PANEL_IDS = (
    'SSS_PT_shader_tools',
    'SSS_PT_shader_tools_image_editor',
    'SSS_PT_shader_tools_shader_editor',
    'SSS_PT_shader_tools_video_sequencer',
    'SSS_PT_shader_tools_movie_clip_editor',
    'SSS_PT_shader_tools_dope_sheet',
    'SSS_PT_shader_tools_graph_editor',
    'SSS_PT_shader_tools_nla_editor',
    'SSS_PT_shader_tools_text_editor',
    'SSS_PT_shader_tools_file_browser',
    'SSS_PT_shader_tools_asset_browser',
    'SSS_PT_shader_tools_spreadsheet',
)
ROOT_LOGICAL_EDITOR_KEYS = {
    'SSS_PT_shader_tools': ('VIEW_3D',),
    'SSS_PT_shader_tools_image_editor': ('IMAGE_EDITOR', 'UV_EDITOR'),
    'SSS_PT_shader_tools_shader_editor': ('SHADER_EDITOR', 'COMPOSITOR', 'GEOMETRY_NODE_EDITOR', 'TEXTURE_NODE_EDITOR'),
    'SSS_PT_shader_tools_video_sequencer': ('VIDEO_SEQUENCER',),
    'SSS_PT_shader_tools_movie_clip_editor': ('MOVIE_CLIP_EDITOR',),
    'SSS_PT_shader_tools_dope_sheet': ('DOPE_SHEET',),
    'SSS_PT_shader_tools_graph_editor': ('GRAPH_EDITOR', 'DRIVERS'),
    'SSS_PT_shader_tools_nla_editor': ('NLA_EDITOR',),
    'SSS_PT_shader_tools_text_editor': ('TEXT_EDITOR',),
    'SSS_PT_shader_tools_file_browser': ('FILE_BROWSER',),
    'SSS_PT_shader_tools_asset_browser': ('ASSET_BROWSER',),
    'SSS_PT_shader_tools_spreadsheet': ('SPREADSHEET',),
}
ROOT_BODY_CALLABLE = 'ui.draw_npanel_root'
ROOT_BODY_FINGERPRINT_POLICY = 'identical_callable_identity'
POLL_MUTATION_ALLOWED = False
DRAW_MUTATION_ALLOWED = False
MANAGER_MISSING_POLICY = 'FAIL_OPEN'
MANAGER_NOT_READY_POLICY = 'MANAGER_LAST_KNOWN_CURRENT_CELL'

PERSISTENCE_ROOTS = (
    'window_manager.sss_npanel_settings',
    'window_manager.sss_smart_material_smart',
    'scene.sss_*',
    'scene.sss_material_editor',
    'material.smart_toon_settings',
)
EXCLUDED_TRANSIENT_PATHS = (
    'window_manager.sss_npanel_settings.name',
    'window_manager.sss_smart_material_smart.name',
    'scene.sss_material_editor',
    'scene.sss_material_editor.name',
    'scene.sss_material_editor.video_result',
    'scene.sss_material_editor.scene_material_page',
    'scene.sss_last_report',
    'material.smart_toon_settings.name',
    'material.pbr_properties.name',
    'scene.matlib.name',
)
PERSISTED_DYNAMIC_RNA_PATTERNS = (
    'window_manager.sss_ft_*',
    'scene.matlib',
    'material.pbr_properties',
)
PERSISTED_INTERNAL_STATE_KEYS = ('window_manager.pbr_ui_state',)
PERSISTED_IDPROPERTY_PATTERNS = ('window_manager["sss_ui_section_open__*"]',)
