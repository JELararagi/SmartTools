# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Explicit-operation transform transaction guard for Smart Shader Suite.

No load/save handler, timer, worker, or module alias is installed.  The guard is
used only around an explicit operation that has already chosen to protect scene
object transforms.  File-open persistence does not call this module.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any

import bpy

_GUARD_NAMESPACE_KEY = "SMART_SHADER_SUITE_TRANSFORM_GUARD_LAST_REPORT"
_EPSILON = 1.0e-7
_REGISTERED = False


def _tuple3(value) -> tuple[float, float, float]:
    try:
        return (float(value[0]), float(value[1]), float(value[2]))
    except Exception:
        return (0.0, 0.0, 0.0)


def _tuple4(value) -> tuple[float, float, float, float]:
    try:
        return (float(value[0]), float(value[1]), float(value[2]), float(value[3]))
    except Exception:
        return (1.0, 0.0, 0.0, 0.0)


def _matrix_tuple(matrix) -> tuple[tuple[float, float, float, float], ...]:
    try:
        return tuple(tuple(float(matrix[row][col]) for col in range(4)) for row in range(4))
    except Exception:
        return ()


def _matrix_from_tuple(value):
    try:
        from mathutils import Matrix
        return Matrix(value) if value else None
    except Exception:
        return None


def _object_key(obj) -> tuple[int, str, str]:
    try:
        pointer = int(obj.as_pointer())
    except Exception:
        pointer = id(obj)
    try:
        library = str(getattr(getattr(obj, "library", None), "filepath", "") or "")
    except Exception:
        library = ""
    try:
        name = str(obj.name)
    except Exception:
        name = ""
    return pointer, library, name


def _snapshot_object(obj) -> dict[str, Any] | None:
    if obj is None:
        return None
    try:
        pointer = int(obj.as_pointer())
        _ = obj.name
    except Exception:
        return None
    return {
        "pointer": pointer,
        "location": _tuple3(getattr(obj, "location", (0.0, 0.0, 0.0))),
        "rotation_mode": str(getattr(obj, "rotation_mode", "XYZ") or "XYZ"),
        "rotation_euler": _tuple3(getattr(obj, "rotation_euler", (0.0, 0.0, 0.0))),
        "rotation_quaternion": _tuple4(getattr(obj, "rotation_quaternion", (1.0, 0.0, 0.0, 0.0))),
        "rotation_axis_angle": _tuple4(getattr(obj, "rotation_axis_angle", (0.0, 0.0, 1.0, 0.0))),
        "scale": _tuple3(getattr(obj, "scale", (1.0, 1.0, 1.0))),
        "delta_location": _tuple3(getattr(obj, "delta_location", (0.0, 0.0, 0.0))),
        "delta_rotation_euler": _tuple3(getattr(obj, "delta_rotation_euler", (0.0, 0.0, 0.0))),
        "delta_rotation_quaternion": _tuple4(getattr(obj, "delta_rotation_quaternion", (1.0, 0.0, 0.0, 0.0))),
        "delta_scale": _tuple3(getattr(obj, "delta_scale", (1.0, 1.0, 1.0))),
        "matrix_parent_inverse": _matrix_tuple(getattr(obj, "matrix_parent_inverse", None)),
        "matrix_basis": _matrix_tuple(getattr(obj, "matrix_basis", None)),
    }


def snapshot_scene_object_transforms(objects=None) -> dict[tuple[int, str, str], dict[str, Any]]:
    """Snapshot a caller-supplied object set, or the current scene for explicit use."""
    if objects is None:
        try:
            scene = getattr(getattr(bpy, "context", None), "scene", None)
            objects = tuple(getattr(scene, "objects", ()) or ()) if scene is not None else ()
        except Exception:
            objects = ()
    result: dict[tuple[int, str, str], dict[str, Any]] = {}
    for obj in tuple(objects or ()):
        snapshot = _snapshot_object(obj)
        if snapshot is not None:
            result[_object_key(obj)] = snapshot
    return result


def _different(current, saved) -> bool:
    try:
        if len(current) != len(saved):
            return True
        return any(abs(float(a) - float(b)) > _EPSILON for a, b in zip(current, saved))
    except Exception:
        return True


def _restore_object(obj, snapshot: dict[str, Any]) -> bool:
    try:
        if int(obj.as_pointer()) != int(snapshot.get("pointer", 0)):
            return False
    except Exception:
        return False
    changed = False
    scalar_vectors = (
        "location", "rotation_euler", "rotation_quaternion", "rotation_axis_angle",
        "scale", "delta_location", "delta_rotation_euler", "delta_rotation_quaternion",
        "delta_scale",
    )
    try:
        if str(getattr(obj, "rotation_mode", "")) != str(snapshot.get("rotation_mode", "")):
            obj.rotation_mode = snapshot.get("rotation_mode", "XYZ")
            changed = True
    except Exception:
        pass
    for name in scalar_vectors:
        value = snapshot.get(name)
        try:
            current = tuple(getattr(obj, name))
            if value is not None and _different(current, value):
                setattr(obj, name, value)
                changed = True
        except Exception:
            pass
    for name in ("matrix_parent_inverse", "matrix_basis"):
        value = snapshot.get(name)
        try:
            current = _matrix_tuple(getattr(obj, name))
            if value and _different(tuple(v for row in current for v in row), tuple(v for row in value for v in row)):
                matrix = _matrix_from_tuple(value)
                if matrix is not None:
                    setattr(obj, name, matrix)
                    changed = True
        except Exception:
            pass
    if changed:
        try:
            obj.update_tag(refresh={"OBJECT"})
        except Exception:
            pass
    return changed


def restore_scene_object_transforms(snapshot, *, reason: str = "", objects=None) -> int:
    if not snapshot:
        return 0
    if objects is None:
        try:
            scene = getattr(getattr(bpy, "context", None), "scene", None)
            objects = tuple(getattr(scene, "objects", ()) or ()) if scene is not None else ()
        except Exception:
            objects = ()
    by_key = {_object_key(obj): obj for obj in tuple(objects or ()) if obj is not None}
    restored = 0
    for key, values in dict(snapshot).items():
        obj = by_key.get(key)
        if obj is not None and _restore_object(obj, values):
            restored += 1
    if restored:
        try:
            bpy.app.driver_namespace[_GUARD_NAMESPACE_KEY] = {
                "restored_objects": restored,
                "reason": str(reason or ""),
            }
        except Exception:
            pass
    return restored


@contextmanager
def preserve_object_transforms(reason: str = "", objects=None):
    snapshot = snapshot_scene_object_transforms(objects)
    try:
        yield
    finally:
        restore_scene_object_transforms(snapshot, reason=reason, objects=objects)


def register() -> None:
    """Compatibility entry point; no resident resource is installed."""
    global _REGISTERED
    _REGISTERED = True


def unregister() -> None:
    global _REGISTERED
    _REGISTERED = False
