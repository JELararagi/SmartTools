# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import importlib
import json
import sys
import textwrap
from pathlib import Path

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, PointerProperty, StringProperty
from .translation import rna_text_context_prop as _rna_prop
BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, StringProperty = map(_rna_prop, (BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, StringProperty))
from bpy.types import PropertyGroup

from . import storage
from . import ui_sections
from . import tool_preferences as tool_prefs
from .translation import tx, loc_text as _lt



_INTEGRATED_REFRESH_SCHEDULED = False
_INTEGRATED_REFRESH_RUNNING = False


def _run_runtime_refresh_now(context=None) -> bool:
    global _INTEGRATED_REFRESH_RUNNING
    if _INTEGRATED_REFRESH_RUNNING:
        return False
    _INTEGRATED_REFRESH_RUNNING = True
    try:
        if _request_staged_runtime_refresh(context):
            return True
        try:
            from . import loader, ui_runtime

            loader.initialize_records(force=False)
            loader.refresh_record_statuses()
            ui_runtime.register()
            ui_runtime.refresh_all_suites(context)
            return True
        except Exception:
            return False
    finally:
        _INTEGRATED_REFRESH_RUNNING = False


def _deferred_runtime_refresh():
    """Compatibility one-shot; no timer is registered."""
    global _INTEGRATED_REFRESH_SCHEDULED
    _INTEGRATED_REFRESH_SCHEDULED = False
    return _run_runtime_refresh_now(getattr(bpy, 'context', None))


def _schedule_runtime_refresh(context=None) -> None:
    """Refresh synchronously only in response to the explicit preference edit."""
    global _INTEGRATED_REFRESH_SCHEDULED
    if _INTEGRATED_REFRESH_SCHEDULED:
        return
    _INTEGRATED_REFRESH_SCHEDULED = True
    try:
        _run_runtime_refresh_now(context or getattr(bpy, 'context', None))
    finally:
        _INTEGRATED_REFRESH_SCHEDULED = False


def _root_addon_id() -> str:
    text = str(__package__ or '').strip()
    if text:
        return text
    name = str(__name__ or '').strip()
    if '.' in name:
        return name.rsplit('.', 1)[0]
    return name or 'smart_shader_suite'



def _ui(en: str, ja: str) -> str:
    return tx(None, str(en or ''), str(ja or ''))


_PREFS_PERSISTENCE_APPLYING = False
_PREFS_UPDATE_DEPTH = 0
_PREFS_CACHE: dict[str, object] | None = None
_PERSISTENT_PREF_NAMES = (
    'npanel_state_save',
    'show_always_on_toggles',
    'show_integrated_tools',
    'show_integrated_material_library',
    'show_integrated_math_controller',
    'show_integrated_pbr_lookdev',
    'library_path',
    'smart_material_smart_settings_handlers',
    'integrated_material_library_enabled',
    'integrated_math_controller_enabled',
    'integrated_pbr_lookdev_enabled',
    'integrated_material_library_path',
    'integrated_material_library_auto_refresh_on_load',
    'smart_toon_live_sync_enabled',
    'legacy_proxy_cleanup_enabled',
    'transform_guard_enabled',
    'material_editor_load_restore_enabled',
)


def _settings_path() -> Path | None:
    try:
        return storage.suite_settings_path(create=True)
    except Exception:
        return None


def _legacy_settings_path() -> Path | None:
    try:
        return storage.settings_file('smart_shader_suite_npanel_preferences.json', create=False)
    except Exception:
        return None


def _read_saved_preferences() -> dict[str, object]:
    try:
        data = storage.read_suite_section('preferences', {})
        if isinstance(data, dict) and data:
            return data
    except Exception:
        pass
    path = _legacy_settings_path()
    if path is None or not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _owner_has_rna_property(owner, name: str) -> bool:
    if owner is None or not name:
        return False
    try:
        props = getattr(getattr(owner, 'bl_rna', None), 'properties', None)
    except Exception:
        props = None
    if props is None:
        return False
    try:
        return props.get(str(name)) is not None
    except Exception:
        pass
    try:
        return str(name) in props.keys()
    except Exception:
        return False


def _collect_preferences(owner) -> dict[str, object]:
    data: dict[str, object] = {}
    if owner is None:
        return data
    for name in _PERSISTENT_PREF_NAMES:
        if not _owner_has_rna_property(owner, name):
            continue
        try:
            value = getattr(owner, name)
        except Exception:
            continue
        if isinstance(value, (str, int, float, bool)):
            data[name] = value
    return data


def save_persistent_preferences(owner=None, *, force: bool = False) -> None:
    global _PREFS_CACHE
    if _PREFS_PERSISTENCE_APPLYING:
        return
    owner = owner or addon_preferences_owner(getattr(bpy, 'context', None))
    data = _collect_preferences(owner)
    if not data or (not force and data == _PREFS_CACHE):
        return
    try:
        if storage.write_suite_section('preferences', data):
            _PREFS_CACHE = dict(data)
            return
    except Exception:
        pass


def apply_persistent_preferences(owner=None) -> None:
    global _PREFS_PERSISTENCE_APPLYING, _PREFS_CACHE
    owner = owner or addon_preferences_owner(getattr(bpy, 'context', None))
    if owner is None:
        return
    data = _read_saved_preferences()
    if not data:
        _PREFS_CACHE = _collect_preferences(owner)
        storage.bind_persistence_owner(owner, bool(getattr(owner, 'npanel_state_save', True)))
        _sync_persistence_resources(bool(getattr(owner, 'npanel_state_save', True)))
        _sync_resident_feature_resources(owner, getattr(bpy, 'context', None))
        return
    _PREFS_PERSISTENCE_APPLYING = True
    try:
        for name, value in data.items():
            if name in _PERSISTENT_PREF_NAMES and _owner_has_rna_property(owner, name):
                try:
                    setattr(owner, name, value)
                except Exception:
                    pass
    finally:
        _PREFS_PERSISTENCE_APPLYING = False
    _PREFS_CACHE = _collect_preferences(owner)
    storage.bind_persistence_owner(owner, bool(getattr(owner, 'npanel_state_save', True)))
    _sync_persistence_resources(bool(getattr(owner, 'npanel_state_save', True)))
    _sync_resident_feature_resources(owner, getattr(bpy, 'context', None))


def _optional_call(callback, *args, **kwargs) -> None:
    if not callable(callback):
        return
    try:
        callback(*args, **kwargs)
        return
    except TypeError:
        try:
            callback(*args)
            return
        except TypeError:
            try:
                callback()
            except Exception:
                pass
        except Exception:
            pass
    except Exception:
        pass


def _loaded_runtime_modules() -> list[object]:
    modules: list[object] = []
    seen: set[int] = set()
    try:
        from . import loader
        for record in loader.get_records():
            if isinstance(record, dict):
                module = record.get('module')
                if module is not None and id(module) not in seen:
                    modules.append(module)
                    seen.add(id(module))
    except Exception:
        pass
    package_prefix = str(__package__ or _root_addon_id() or 'smart_shader_suite').strip()
    suffixes = (
        'material_library',
        'pbr_lookdev',
    )
    for suffix in suffixes:
        for name in (f'{package_prefix}.{suffix}' if package_prefix else suffix, suffix):
            module = sys.modules.get(name)
            if module is not None and id(module) not in seen:
                modules.append(module)
                seen.add(id(module))
    return modules


def save_all_npanel_settings(context=None) -> None:
    """Persist every Smart Shader N-panel state file before Blender saves preferences."""
    ctx = context or getattr(bpy, 'context', None)
    owner = addon_preferences_owner(ctx)
    save_persistent_preferences(owner, force=True)

    try:
        from . import material_editor as _material_editor
        _optional_call(
            getattr(_material_editor, 'save_material_editor_settings', None),
            getattr(ctx, 'scene', None) if ctx is not None else None,
            force=True,
        )
    except Exception:
        pass

    try:
        from . import smart_toon as _smart_toon
        _optional_call(getattr(_smart_toon, 'save_smart_toon_material_settings', None), force=True)
    except Exception:
        pass

    try:
        from . import ui_sections as _sss_ui_sections
        _optional_call(getattr(_sss_ui_sections, 'save_section_state', None), ctx, force=True)
    except Exception:
        pass

    try:
        from . import common as _sss_common
        _optional_call(getattr(_sss_common, 'save_persistent_settings', None), ctx, force=True)
    except Exception:
        pass

    try:
        from . import properties as _scene_properties
        scenes = list(getattr(getattr(bpy, 'data', None), 'scenes', []) or [])
        active_scene = getattr(ctx, 'scene', None) if ctx is not None else None
        if active_scene is not None:
            scenes = [scene for scene in scenes if scene is not active_scene]
            scenes.append(active_scene)
        for scene in scenes:
            _optional_call(getattr(_scene_properties, 'save_persistent_scene_settings', None), scene, force=True)
    except Exception:
        pass

    try:
        from . import feature_toggle
        fn = getattr(feature_toggle, 'save_feature_toggle_state', None)
        if callable(fn):
            _optional_call(fn, force=True)
    except Exception:
        pass

    for module_name in ('smart_material_smart',):
        try:
            module = importlib.import_module(f'.{module_name}', __package__)
            _optional_call(getattr(module, 'save_settings', None), force=True)
        except Exception:
            pass

    for module in _loaded_runtime_modules():
        try:
            scene = getattr(ctx, 'scene', None) if ctx is not None else None
            fn = getattr(module, 'save_matlib_ui_settings', None)
            if callable(fn):
                _optional_call(fn, getattr(scene, 'matlib', None) if scene is not None else None)
            fn = getattr(module, '_pbr_save_ui_state', None)
            if callable(fn):
                _optional_call(fn, ctx, force=True)
            _optional_call(getattr(module, 'save_pbr_material_settings', None), force=True)
        except Exception:
            pass

    # Some material feature savers normalize shared/instanced Smart Toon map
    # values while they snapshot their own state.  Smart Toon is deliberately
    # saved once more at the end so re-enabling N-panel State Save commits the
    # final live RNA values, rather than the values that existed before those
    # normalizers ran.  The storage layer suppresses an identical rewrite.
    try:
        from . import smart_toon as _smart_toon
        _optional_call(
            getattr(_smart_toon, 'save_smart_toon_material_settings', None),
            force=True,
        )
    except Exception:
        pass


def apply_all_npanel_settings(context=None) -> None:
    """Restore Smart Shader N-panel state from the single Blender config JSON."""
    ctx = context or getattr(bpy, 'context', None)
    apply_persistent_preferences(addon_preferences_owner(ctx))
    try:
        from . import material_editor as _material_editor
        _optional_call(
            getattr(_material_editor, 'restore_material_editor_settings', None),
            getattr(ctx, 'scene', None) if ctx is not None else None,
            force=True,
        )
    except Exception:
        pass
    try:
        from . import smart_toon as _smart_toon
        _optional_call(getattr(_smart_toon, 'restore_smart_toon_profile_scalars_on_load', None))
    except Exception:
        pass
    try:
        from . import ui_sections as _sss_ui_sections
        _optional_call(getattr(_sss_ui_sections, 'apply_section_state', None), ctx)
    except Exception:
        pass
    try:
        from . import common as _sss_common
        _optional_call(getattr(_sss_common, 'load_settings_file', None))
        _optional_call(getattr(_sss_common, 'apply_persistent_settings', None), ctx)
    except Exception:
        pass
    try:
        from . import properties as _scene_properties
        _optional_call(getattr(_scene_properties, 'initialize_scene_defaults', None))
    except Exception:
        pass
    for module_name in ('smart_material_smart',):
        try:
            module = importlib.import_module(f'.{module_name}', __package__)
            _optional_call(getattr(module, 'apply_settings', None))
        except Exception:
            pass
    for module in _loaded_runtime_modules():
        try:
            _optional_call(getattr(module, '_pbr_apply_ui_state', None), ctx)
            _optional_call(getattr(module, 'restore_pbr_material_settings', None))
        except Exception:
            pass


def is_npanel_state_save_enabled(context=None, owner=None) -> bool:
    owner = owner or addon_preferences_owner(context or getattr(bpy, 'context', None))
    try:
        if owner is not None and _owner_has_rna_property(owner, 'npanel_state_save'):
            return bool(getattr(owner, 'npanel_state_save'))
    except Exception:
        pass
    try:
        return storage.npanel_state_save_enabled(default=True)
    except Exception:
        return True


def _npanel_state_save_update(self, context) -> None:
    global _PREFS_CACHE, _PREFS_PERSISTENCE_APPLYING
    enabled = bool(getattr(self, 'npanel_state_save', True))
    previous = storage.persistence_saved_state(self)
    capability = storage.authorize_persistence_toggle(self, previous, enabled)
    payload = _collect_preferences(self)
    committed = capability is not None and storage.commit_persistence_toggle(capability, payload)
    if not committed:
        fallback = previous if isinstance(previous, bool) else storage.npanel_state_save_enabled(default=True)
        _PREFS_PERSISTENCE_APPLYING = True
        try:
            setattr(self, 'npanel_state_save', fallback)
        finally:
            _PREFS_PERSISTENCE_APPLYING = False
        _sync_persistence_resources(fallback)
        return
    _PREFS_CACHE = dict(payload)
    _sync_persistence_resources(enabled)
    if enabled:
        save_all_npanel_settings(context)


def _save_pref_update(self, context) -> None:
    del context
    if is_npanel_state_save_enabled(owner=self):
        save_persistent_preferences(self)


def _chain_pref_update(callback):
    def _update(self, context):
        global _PREFS_UPDATE_DEPTH
        if _PREFS_PERSISTENCE_APPLYING or _PREFS_UPDATE_DEPTH > 0:
            return
        _PREFS_UPDATE_DEPTH += 1
        try:
            if callable(callback):
                callback(self, context)
        finally:
            try:
                # One outer callback snapshots every preference, including any
                # dependent values changed by that callback.  This prevents
                # mutually updating migrated preferences from recursively
                # re-entering JSON collection during an exhaustive UI edit.
                _save_pref_update(self, context)
            finally:
                _PREFS_UPDATE_DEPTH = max(0, _PREFS_UPDATE_DEPTH - 1)
    return _update


def _fallback_pref_property_description(kwargs: dict) -> str:
    label = str(kwargs.get('name') or '').strip() or 'Smart Shader setting'
    return _ui(
        f'{label} setting for the Smart Shader N-panel. Changes are written to Blender config/Smart_Shader_Suite storage and restored after Blender restarts, file loads, and preference saves.',
        f'{label} の スマートシェーダーNパネル設定です。変更内容は Blender の設定フォルダー 内の Smart_Shader_Suite 保存領域へ書き込まれ、Blender再起動・ファイル読み込み・プリファレンス保存後も復元されます。',
    )


def _wrap_pref_property(factory):
    def _wrapped(*args, **kwargs):
        kwargs = dict(kwargs)
        if not kwargs.get('description'):
            kwargs['description'] = _fallback_pref_property_description(kwargs)
        kwargs['update'] = _chain_pref_update(kwargs.get('update'))
        return factory(*args, **kwargs)
    return _wrapped


BoolProperty = _wrap_pref_property(BoolProperty)
EnumProperty = _wrap_pref_property(EnumProperty)
FloatProperty = _wrap_pref_property(FloatProperty)
FloatVectorProperty = _wrap_pref_property(FloatVectorProperty)
IntProperty = _wrap_pref_property(IntProperty)
StringProperty = _wrap_pref_property(StringProperty)



def _wrap_labels(layout, text: str, width: int = 88, icon: str = 'NONE') -> None:
    cleaned = str(text or '').strip()
    if not cleaned:
        return
    lines = textwrap.wrap(cleaned, width=max(32, int(width))) or [cleaned]
    first = True
    for line in lines:
        if first:
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)



def _safe_loaded_module(alias: str):
    try:
        from . import loader

        record = loader.record_for_alias(alias)
        if isinstance(record, dict):
            return record.get('module')
    except Exception:
        pass
    return None



def _request_staged_runtime_refresh(context=None) -> bool:
    module_name = str(__package__ or _root_addon_id() or 'smart_shader_suite').strip()
    if not module_name:
        return False
    try:
        root_module = importlib.import_module(module_name)
    except Exception:
        return False

    try:
        ensure_fn = getattr(root_module, 'ensure_runtime_initialized', None)
        if callable(ensure_fn):
            ensure_fn(context)
    except Exception:
        pass

    sync_fn = getattr(root_module, '_stx_refresh_runtime_state', None)
    if not callable(sync_fn):
        return False
    try:
        return bool(sync_fn(context=context, rebuild_records=True))
    except TypeError:
        try:
            return bool(sync_fn(context))
        except Exception:
            return False
    except Exception:
        return False


def _refresh_runtime(context=None) -> None:
    # Property update callbacks may run from Blender UI handling.  Re-registering
    # operators, properties, or hidden panel classes immediately from that path is
    # unsafe and can corrupt the active Panel.draw() call stack.  Defer the heavy
    # runtime rebuild until Blender returns to the timer loop.
    _schedule_runtime_refresh(context)



def _tool_toggle_update(_self, context) -> None:
    """Refresh the bundled-feature UI without destroying its settings RNA.

    Unloading a migrated module from an RNA update callback removed the whole
    PropertyGroup (for example ``Scene.matlib``) while Blender was still
    iterating the N-panel settings.  Besides making the next controls invalid,
    this also made it impossible to restore their saved values when the feature
    was enabled again.  Bundled features are already hidden and blocked by
    ``tool_enabled``; their optional handlers are controlled by the dedicated
    always-on switches.  Keep the lightweight classes resident and only update
    the record status and redraw the existing panel.
    """
    try:
        from . import loader, ui_runtime
        loader.initialize_records(force=False)
        status_fn = getattr(loader, '_status_for_spec', None)
        for record in loader.get_records():
            if str(record.get('status') or '') == 'loaded':
                continue
            if callable(status_fn):
                record['status'] = status_fn(record.get('spec') or {})
        collect = getattr(ui_runtime, '_collect_records', None)
        if callable(collect):
            collect()
        wm = getattr(context or getattr(bpy, 'context', None), 'window_manager', None)
        for window in getattr(wm, 'windows', ()) if wm is not None else ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) if screen is not None else ():
                try:
                    area.tag_redraw()
                except Exception:
                    pass
        return
    except Exception:
        pass




def _sync_module_settings_handlers(module_name: str, context=None) -> None:
    try:
        module = importlib.import_module(f'.{module_name}', _root_addon_id())
    except Exception:
        return
    for fn_name in ('sync_settings_handlers', '_sync_settings_handlers'):
        fn = getattr(module, fn_name, None)
        if callable(fn):
            try:
                fn(context)
            except Exception:
                pass
            return


def _smart_material_handlers_update(_self, context) -> None:
    _sync_module_settings_handlers('smart_material_smart', context)


def _material_library_path_update(self, context) -> None:
    value = str(getattr(self, 'integrated_material_library_path', '') or '').strip()
    mod = _safe_loaded_module('material_library')
    if mod is not None:
        try:
            if hasattr(mod, '_set_matlib_pref_path'):
                value = str(mod._set_matlib_pref_path(value) or value)
            if hasattr(mod, 'refresh_libs'):
                mod.refresh_libs()
            matlib = getattr(getattr(context, 'scene', None), 'matlib', None)
            if matlib is not None and hasattr(matlib, 'reload'):
                try:
                    matlib.reload_library()
                except Exception:
                    pass
        except Exception:
            pass



def _material_library_resident_module(enabled: bool, context=None):
    """Resolve only the material-library module when its resident switch is ON."""
    mod = _safe_loaded_module('material_library')
    if bool(enabled) and mod is None and tool_prefs.tool_enabled('material_library', context=context, default=True):
        try:
            from . import loader
            record = loader.load_addon('material_library')
            mod = (record or {}).get('module') if isinstance(record, dict) else _safe_loaded_module('material_library')
        except Exception:
            mod = _safe_loaded_module('material_library')
    return mod


def _material_library_auto_refresh_update(_self, context) -> None:
    enabled = bool(getattr(_self, 'integrated_material_library_auto_refresh_on_load', False))
    previously_loaded = _safe_loaded_module('material_library')
    mod = _material_library_resident_module(enabled, context)
    if enabled and previously_loaded is None and mod is not None:
        try:
            from . import ui_runtime
            ui_runtime.register()
            ui_runtime.refresh_all_suites(context)
        except Exception:
            pass
    if mod is not None and hasattr(mod, '_sync_matlib_load_post_handler'):
        try:
            mod._sync_matlib_load_post_handler(context)
        except Exception:
            pass


def _smart_toon_live_sync_update(self, context) -> None:
    try:
        from . import smart_toon
        smart_toon.set_live_runtime_enabled(bool(getattr(self, 'smart_toon_live_sync_enabled', False)))
    except Exception:
        pass


def _legacy_proxy_cleanup_update(self, context) -> None:
    try:
        from . import legacy_proxy_cleanup
        if bool(getattr(self, 'legacy_proxy_cleanup_enabled', False)):
            legacy_proxy_cleanup.register()
        else:
            legacy_proxy_cleanup.unregister()
    except Exception:
        pass


def _transform_guard_update(self, context) -> None:
    try:
        from . import transform_guard
        if bool(getattr(self, 'transform_guard_enabled', False)):
            transform_guard.register()
        else:
            transform_guard.unregister()
    except Exception:
        pass


def _material_editor_load_restore_update(self, context) -> None:
    try:
        from . import material_editor
        setter = getattr(material_editor, 'set_load_restore_enabled', None)
        if callable(setter):
            setter(bool(getattr(self, 'material_editor_load_restore_enabled', False)))
    except Exception:
        pass


def _sync_persistence_resources(enabled: bool | None = None) -> None:
    """Install/release the exact central save/load/msgbus resource set."""
    if enabled is None:
        enabled = is_npanel_state_save_enabled()
    _unregister_persistent_preference_handlers()
    if enabled:
        _register_persistent_preference_handlers()
    try:
        _scene_properties = sys.modules.get(f'{__package__}.properties')
        setter = getattr(_scene_properties, 'set_scene_persistence_enabled', None)
        if callable(setter):
            setter(bool(enabled))
    except Exception:
        pass
    for module in _loaded_runtime_modules():
        callback = getattr(module, 'set_ui_persistence_enabled', None)
        if callable(callback):
            callback(bool(enabled))


def _sync_resident_feature_resources(owner=None, context=None) -> None:
    """Apply saved toggles, loading only the selected library resident when ON."""
    owner = owner or addon_preferences_owner(context or getattr(bpy, 'context', None))
    if owner is None:
        return
    for suffix, callback_name, prop_name in (
        ('smart_toon', 'set_live_runtime_enabled', 'smart_toon_live_sync_enabled'),
        ('material_editor', 'set_load_restore_enabled', 'material_editor_load_restore_enabled'),
    ):
        module = sys.modules.get(f'{__package__}.{suffix}')
        callback = getattr(module, callback_name, None) if module is not None else None
        if callable(callback):
            callback(bool(getattr(owner, prop_name, False)))
    module = sys.modules.get(f'{__package__}.smart_material_smart')
    callback = getattr(module, 'sync_settings_handlers', None) if module is not None else None
    if callable(callback):
        callback(context)
    library_enabled = bool(getattr(owner, 'integrated_material_library_auto_refresh_on_load', False))
    library_module = _material_library_resident_module(library_enabled, context)
    callback = getattr(library_module, '_sync_matlib_load_post_handler', None) if library_module is not None else None
    if callable(callback):
        callback(context)






_SETTINGS_PROP_NAME = 'sss_npanel_settings'


def npanel_settings_owner(context=None):
    try:
        context = context or getattr(bpy, 'context', None)
        wm = getattr(context, 'window_manager', None) if context is not None else getattr(getattr(bpy, 'context', None), 'window_manager', None)
        if wm is not None and hasattr(wm, _SETTINGS_PROP_NAME):
            return getattr(wm, _SETTINGS_PROP_NAME)
    except Exception:
        pass
    return None


def addon_preferences_owner(context=None):
    # Compatibility shim for older internal callers: returns the N-panel settings
    # PropertyGroup, not bpy.types.AddonPreferences.
    return npanel_settings_owner(context)


def _draw_path_field(layout, owner, prop_name: str) -> None:
    # The name sits above the field so it stays readable at the default sidebar width.
    column = layout.column(align=True)
    rna = owner.bl_rna.properties[prop_name]
    column.label(text=rna.name, text_ctxt=rna.translation_context)
    column.prop(owner, prop_name, text='')


def _draw_storage_settings(owner, layout) -> None:
    context = getattr(bpy, 'context', None)
    _box, outer, _expanded = ui_sections.draw_group(layout, context, 'prefs_persistent_storage', _ui('Persistent Storage', '永続保存'), icon='FILE_FOLDER', topic='settings', default_open=False)
    _draw_path_field(outer, owner, 'library_path')



def _draw_tool_settings(alias: str, owner, box) -> None:
    if alias == 'material_library':
        _draw_path_field(box, owner, 'integrated_material_library_path')
        return




def _draw_integrated_tools(owner, layout) -> None:
    context = getattr(bpy, 'context', None)
    _box, outer, _expanded = ui_sections.draw_group(layout, context, 'prefs_bundled_features', _ui('Bundled Features', '同梱機能'), icon='PLUGIN', topic='settings', default_open=False)

    for alias in tool_prefs.TOOL_ORDER:
        meta = tool_prefs.tool_meta(alias)
        display = _ui(meta.get('display_en', alias), meta.get('display_ja', alias))
        icon = meta.get('icon', 'PLUGIN')
        _box, box, _expanded = ui_sections.draw_group(outer, context, 'prefs_tool_' + str(alias), display, icon=icon, topic=str(alias), default_open=False)
        enable_prop = tool_prefs.prop_name(alias, 'enabled')
        if _owner_has_rna_property(owner, enable_prop):
            box.prop(owner, enable_prop, text=_ui('Enable this on-demand tool', 'このオンデマンド機能を有効化'), toggle=True)
        if alias not in {'material_library'}:
            continue

        _box, settings, _expanded = ui_sections.draw_group(box, context, 'prefs_tool_settings_' + str(alias), _ui('Settings', '設定'), icon='PREFERENCES', topic=str(alias), default_open=False)
        _draw_tool_settings(alias, owner, settings)




def draw_preferences_contents(owner, layout) -> None:
    layout.use_property_split = False
    layout.use_property_decorate = False
    _draw_storage_settings(owner, layout)


def draw_storage_settings(layout, context=None) -> None:
    layout.use_property_split = False
    layout.use_property_decorate = False
    owner = addon_preferences_owner(context)
    if owner is None:
        warn = layout.box()
        warn.alert = True
        warn.label(text=_ui('Persistent settings could not be loaded.', '永続設定を読み込めませんでした。'), icon='ERROR')
        return
    _draw_storage_settings(owner, layout)
    status = storage.last_write_status()
    if not status.get('ok') and status.get('code') in {'READ_ERROR_PRESERVED', 'REPLACE_ERROR'}:
        warn = layout.box()
        warn.alert = True
        warn.label(text=_ui('Settings file was kept unchanged because saving failed.', '保存に失敗したため設定ファイルを変更せず保持しました。'), icon='ERROR')
    _draw_integrated_tools(owner, layout)


def draw_preferences_settings(layout, context=None) -> None:
    draw_storage_settings(layout, context)


class SSS_NPanelSettings(PropertyGroup):

    npanel_state_save: BoolProperty(
        name=_ui('N-panel State Save', 'Nパネル状態保存'),
        description=_ui(
            'When enabled, every portable Smart Shader N-panel setting change is written immediately to Smart_Shader_Suite/Smart_Shader_Suite.json in Blender config. Turning this off records OFF once, releases owned persistence resources, and blocks later automatic, forced, fallback, and shutdown writes.',
            '有効時は、スマートシェーダーNパネルの移植可能な設定変更を Blender の設定フォルダー 内の Smart_Shader_Suite/Smart_Shader_Suite.json へ即時保存します。無効へ切り替えた時だけOFFを1回記録し、所有する保存リソースを解放して、その後の自動・強制・代替・終了時書き込みを遮断します。',
        ),
        default=True,
        update=_npanel_state_save_update,
    )

    show_always_on_toggles: BoolProperty(
        name=_ui('Resident Feature Toggles', '常時機能切り替え'),
        description=_ui(
            'Open or close the Resident Feature Toggles group at the top of the Smart Shader panel. It is closed by default to keep the N-panel compact.',
            'スマートシェーダー パネル最上部の常時機能切り替えグループを開閉します。既定では閉じた状態にして、Nパネルをコンパクトに保ちます。',
        ),
        default=False,
    )

    show_integrated_tools: BoolProperty(name=_ui('Bundled Features', '同梱機能'), description=_ui('Show or hide bundled feature switches and settings. Disabling a specific feature prevents Smart Shader from loading that runtime module.', '同梱機能の有効切替と設定を表示または非表示にします。個別機能を無効にすると、スマートシェーダーはそのランタイムモジュールを読み込みません。'), default=True)
    show_integrated_material_library: BoolProperty(name=_lt('Material Library'), description=_ui('Material Library settings section.', 'マテリアルライブラリの設定セクションを開閉します。'), default=False)
    show_integrated_math_controller: BoolProperty(name=_lt('Math Controller'), description=_ui('Math Controller settings section.', '数式コントローラーの設定セクションを開閉します。'), default=False)
    show_integrated_pbr_lookdev: BoolProperty(name=_lt('PBR Lookdev'), description=_ui('PBR Lookdev settings section.', 'PBR ルックデブ の設定セクションを開閉します。'), default=False)
    library_path: StringProperty(
        name=_ui('Library Path', 'ライブラリ保存先'),
        description=_ui(
            'Legacy/manual reference folder. Automatic Smart Shader settings, generated support JSON, reports, and runtime helper files always stay inside Blender\'s versioned config/Smart_Shader_Suite folder. Use feature-specific folder selectors only for explicit external libraries, imports, exports, or searches.',
            '旧設定との互換用・手動参照用フォルダです。スマートシェーダーの自動設定、生成JSON、レポート、実行時補助ファイルは常に Blender のバージョン別 config/Smart_Shader_Suite フォルダ内に保存されます。外部フォルダを使う場合は、各機能専用のライブラリ・読み込み・書き出し・検索フォルダ指定だけを使用してください。',
        ),
        subtype='DIR_PATH',
        default='',
    )

    smart_material_smart_settings_handlers: BoolProperty(
        name=_ui('Settings Load Restore', '設定の読込時復元'),
        description=_ui('Optional legacy per-feature load/save handlers for Smart Shader. Normally leave this disabled because N-panel State Save now restores these settings through the central Smart Shader JSON persistence system.', 'スマートシェーダー用の旧式個別ロード/保存ハンドラーです。通常は無効のままで問題ありません。現在はNパネル状態保存の中央JSON復元で同じ設定維持を行います。'),
        default=False,
        update=_smart_material_handlers_update,
    )

    integrated_material_library_enabled: BoolProperty(
        name=_ui('Enable Material Library', 'マテリアルライブラリを有効化'),
        description=_ui('Load the Material Library tool into Smart Shader.', 'マテリアルライブラリを スマートシェーダーで読み込めるようにします。'),
        default=True,
        update=_tool_toggle_update,
    )
    integrated_math_controller_enabled: BoolProperty(
        name=_ui('Enable Math Controller', '数式コントローラーを有効化'),
        description=_ui('Load the Math Controller tool into Smart Shader.', '数式コントローラーを スマートシェーダーで読み込めるようにします。'),
        default=True,
        update=_tool_toggle_update,
    )
    integrated_pbr_lookdev_enabled: BoolProperty(
        name=_ui('Enable PBR Lookdev', 'PBR ルックデブを有効化'),
        description=_ui('Load the PBR Lookdev tool into Smart Shader.', 'PBR ルックデブ を スマートシェーダーで読み込めるようにします。'),
        default=True,
        update=_tool_toggle_update,
    )

    integrated_material_library_path: StringProperty(
        name=_ui('Material Library Folder', 'マテリアルライブラリフォルダ'),
        description=_ui('Folder that contains reusable .blend material libraries for Material Library.', 'マテリアルライブラリで使う再利用可能な .blend マテリアルライブラリの保存フォルダです。'),
        subtype='DIR_PATH',
        default='',
        update=_material_library_path_update,
    )
    integrated_material_library_auto_refresh_on_load: BoolProperty(
        name=_ui('Auto refresh on file load', 'ファイル読込時に自動更新'),
        description=_ui('Refresh the material-library list automatically after every .blend file load. Keep this disabled for lighter startup and file opening.', '.blend 読込後にマテリアルライブラリ一覧を自動更新します。起動とファイル読込を軽くするには通常無効のままにしてください。'),
        default=False,
        update=_material_library_auto_refresh_update,
    )
    smart_toon_live_sync_enabled: BoolProperty(
        name=_ui('Toon Live Sync', 'トゥーン ライブ同期'),
        description=_ui('Keep Smart Toon depsgraph and render-pre synchronization handlers active. Leave disabled for zero idle load; rebuilding and render preparation still run when explicitly requested.', 'スマート トゥーンの依存グラフ・レンダー前同期ハンドラーを常駐させます。待機負荷をゼロにする場合は無効にしてください。明示実行した再構築とレンダー準備は引き続き利用できます。'),
        default=False,
        update=_smart_toon_live_sync_update,
    )
    legacy_proxy_cleanup_enabled: BoolProperty(
        name=_ui('Legacy Proxy Cleanup Watch', '旧プロキシ清掃監視'),
        description=_ui('Keep legacy proxy cleanup load/save/depsgraph handlers active. Enable only while repairing files created by old Smart Shader builds.', '旧スマートシェーダー版のプロキシを清掃する読込・保存・依存グラフハンドラーを常駐させます。旧ファイル修復時だけ有効にしてください。'),
        default=False,
        update=_legacy_proxy_cleanup_update,
    )
    transform_guard_enabled: BoolProperty(
        name=_ui('Transform Guard', 'トランスフォーム保護'),
        description=_ui('Keep the file-load transform snapshot/restore guard active around Smart Shader restoration. Leave disabled unless compatibility with a transform-mutating legacy workflow is required.', 'スマートシェーダー復元時のトランスフォーム・スナップショット保護をファイル読込時に常駐させます。旧処理との互換で必要な場合だけ有効にしてください。'),
        default=False,
        update=_transform_guard_update,
    )
    material_editor_load_restore_enabled: BoolProperty(
        name=_ui('Material Editor Restore on File Load', 'マテリアルエディター読込時復元'),
        description=_ui('Restore global Material Editor N-panel settings and named slots automatically after each file load. Leave disabled for zero idle load; settings still save and can be restored when the panel is used.', 'ファイル読込後にマテリアルエディターのNパネル設定と名前付きスロットを自動復元します。待機負荷をゼロにする場合は無効にしてください。設定保存と手動使用時の復元は維持されます。'),
        default=False,
        update=_material_editor_load_restore_update,
    )

    def draw(self, _context):
        pass


SSSPreferences = SSS_NPanelSettings

classes = (
    SSS_NPanelSettings,
)


def _suppress_addon_preferences_draw() -> None:
    # Never mutate another add-on's AddonPreferences draw callback by name.
    return None



def _class_has_bl_rna(cls: type) -> bool:
    try:
        rna = vars(cls).get('bl_rna') or getattr(cls, 'bl_rna', None)
        identifier = str(getattr(rna, 'identifier', '') or '')
        inherited = {'PropertyGroup', 'Panel', 'Operator', 'Menu', 'UIList', 'AddonPreferences'}
        return bool(identifier and identifier not in inherited)
    except Exception:
        return False

def _register_npanel_settings_pointer() -> None:
    # PointerProperty requires a registered RNA class.  Some Blender reload paths
    # can leave a stale Python class object with the same name, so always ensure
    # the actual class is registered before creating the pointer.
    if not _class_has_bl_rna(SSS_NPanelSettings):
        try:
            _safe_register_class(SSS_NPanelSettings)
        except Exception:
            return
    if not _class_has_bl_rna(SSS_NPanelSettings):
        return
    try:
        if hasattr(bpy.types.WindowManager, _SETTINGS_PROP_NAME):
            try:
                delattr(bpy.types.WindowManager, _SETTINGS_PROP_NAME)
            except Exception:
                return
        setattr(bpy.types.WindowManager, _SETTINGS_PROP_NAME, PointerProperty(type=SSS_NPanelSettings))
    except Exception:
        # Never let a pointer-registration issue prevent the add-on from
        # unregistering cleanly or reporting the original registration error.
        pass


def _unregister_npanel_settings_pointer() -> None:
    if hasattr(bpy.types.WindowManager, _SETTINGS_PROP_NAME):
        try:
            delattr(bpy.types.WindowManager, _SETTINGS_PROP_NAME)
        except Exception:
            pass


@persistent
def _save_all_npanel_settings_on_load_pre(_dummy=None):
    # Blender is about to discard the current Main database.  Material-owned
    # PointerProperties can already be provisional ``None`` values at this
    # boundary, so taking a full N-panel snapshot here destroys the stable
    # Image records needed by load_post.  Every ordinary edit is saved by its
    # update callback and save_pre/Save Preferences remain explicit flush
    # boundaries; load_pre must therefore be read-only.
    return None


@persistent
def _save_persistent_preferences_on_save(_dummy=None):
    # Headless wm.save_as_mainfile must never enter UI-capable save callbacks.
    if bool(getattr(getattr(bpy, 'app', None), 'background', False)):
        return None
    try:
        from . import transform_guard as _sss_transform_guard
        with _sss_transform_guard.preserve_object_transforms('preferences save_pre'):
            try:
                save_all_npanel_settings(getattr(bpy, 'context', None))
            except Exception:
                try:
                    save_persistent_preferences(addon_preferences_owner(getattr(bpy, 'context', None)), force=True)
                except Exception:
                    pass
    except Exception:
        pass


@persistent
def _apply_persistent_preferences_on_load(_dummy=None):
    try:
        from . import transform_guard as _sss_transform_guard
        with _sss_transform_guard.preserve_object_transforms('preferences load_post'):
            apply_all_npanel_settings(getattr(bpy, 'context', None))
    except Exception:
        pass


def _register_persistent_preference_handlers() -> None:
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is None:
            return
        save_pre = getattr(handlers, 'save_pre', None)
        load_pre = getattr(handlers, 'load_pre', None)
        load_post = getattr(handlers, 'load_post', None)
        if save_pre is not None and _save_persistent_preferences_on_save not in save_pre:
            save_pre.append(_save_persistent_preferences_on_save)
        if load_pre is not None and _save_all_npanel_settings_on_load_pre not in load_pre:
            load_pre.append(_save_all_npanel_settings_on_load_pre)
        if load_post is not None and _apply_persistent_preferences_on_load not in load_post:
            load_post.append(_apply_persistent_preferences_on_load)
    except Exception:
        pass


def _unregister_persistent_preference_handlers() -> None:
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is None:
            return
        save_pre = getattr(handlers, 'save_pre', None)
        load_pre = getattr(handlers, 'load_pre', None)
        load_post = getattr(handlers, 'load_post', None)
        if save_pre is not None and _save_persistent_preferences_on_save in save_pre:
            save_pre.remove(_save_persistent_preferences_on_save)
        if load_pre is not None and _save_all_npanel_settings_on_load_pre in load_pre:
            load_pre.remove(_save_all_npanel_settings_on_load_pre)
        if load_post is not None and _apply_persistent_preferences_on_load in load_post:
            load_post.remove(_apply_persistent_preferences_on_load)
    except Exception:
        pass


def _ensure_operator_undo_options(cls: type) -> None:
    del cls
    return None


def _safe_register_class(cls: type) -> None:
    if not isinstance(cls, type):
        raise TypeError('RNA class must be a Python type')
    if cls in _SSS_V1208_REGISTERED_CLASSES and _class_has_bl_rna(cls):
        return
    if _class_has_bl_rna(cls):
        raise RuntimeError(f'RNA class is already registered outside this generation ledger: {getattr(cls, "__name__", "<unnamed>")}')
    try:
        bpy.utils.register_class(cls)
    except Exception:
        if cls in _SSS_V1208_REGISTERED_CLASSES and _class_has_bl_rna(cls):
            return
        raise
    if not _class_has_bl_rna(cls):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        raise RuntimeError(f'RNA class registration did not publish class bl_rna: {getattr(cls, "__name__", "<unnamed>")}')
    if cls not in _SSS_V1208_REGISTERED_CLASSES:
        _SSS_V1208_REGISTERED_CLASSES.append(cls)

def _unregister_stale_class(name: str) -> None:
    del name
    return None



def register() -> None:
    _unregister_stale_class(('SMART' + 'TOOLS_AddonPreferences'))
    _unregister_stale_class('SSSPreferences')
    for cls in classes:
        _safe_register_class(cls)
    _register_npanel_settings_pointer()
    _suppress_addon_preferences_draw()
    _register_persistent_preference_handlers()
    owner = addon_preferences_owner(getattr(bpy, 'context', None))
    apply_persistent_preferences(owner)



def unregister() -> None:
    try:
        save_all_npanel_settings(getattr(bpy, 'context', None))
    except Exception:
        try:
            save_persistent_preferences(addon_preferences_owner(getattr(bpy, 'context', None)), force=True)
        except Exception:
            pass
    _unregister_persistent_preference_handlers()
    _unregister_npanel_settings_pointer()
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _unregister_stale_class(('SMART' + 'TOOLS_AddonPreferences'))
    _unregister_stale_class('SSSPreferences')

# -----------------------------------------------------------------------------
# Smart Shader Suite 5.18.224: exact registration and load-safe persistence.
# -----------------------------------------------------------------------------
_SSS_V1208_REGISTERED_CLASSES: list[type] = []
_SSS_V1208_OWNED_SETTINGS_POINTER = False
_SSS_V1208_REGISTERED_HANDLERS: list[tuple[object, object]] = []


def _ensure_operator_undo_options(cls: type) -> None:
    """Compatibility no-op: operator authors declare UNDO explicitly."""
    return None


def _unregister_stale_class(name: str) -> None:
    """Never unregister a class by name; foreign and old generations stay intact."""
    return None


def _safe_register_class(cls: type) -> None:
    if not isinstance(cls, type):
        raise TypeError('RNA class must be a Python type')
    if cls in _SSS_V1208_REGISTERED_CLASSES and _class_has_bl_rna(cls):
        return
    if _class_has_bl_rna(cls):
        if cls not in _SSS_V1208_REGISTERED_CLASSES:
            _SSS_V1208_REGISTERED_CLASSES.append(cls)
        return
    try:
        bpy.utils.register_class(cls)
    except Exception:
        if cls in _SSS_V1208_REGISTERED_CLASSES and _class_has_bl_rna(cls):
            return
        raise
    if not _class_has_bl_rna(cls):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        raise RuntimeError(f'RNA class registration did not publish bl_rna: {getattr(cls, "__name__", "<unnamed>")}')
    if cls not in _SSS_V1208_REGISTERED_CLASSES:
        _SSS_V1208_REGISTERED_CLASSES.append(cls)


def _register_npanel_settings_pointer() -> None:
    global _SSS_V1208_OWNED_SETTINGS_POINTER
    if not _class_has_bl_rna(SSS_NPanelSettings):
        _safe_register_class(SSS_NPanelSettings)
    if not _class_has_bl_rna(SSS_NPanelSettings):
        raise RuntimeError('SSS_NPanelSettings RNA is unavailable')
    if hasattr(bpy.types.WindowManager, _SETTINGS_PROP_NAME):
        # Existing RNA is not owned by this generation; keep it unchanged.
        return
    setattr(bpy.types.WindowManager, _SETTINGS_PROP_NAME, PointerProperty(type=SSS_NPanelSettings))
    _SSS_V1208_OWNED_SETTINGS_POINTER = True


def _unregister_npanel_settings_pointer() -> None:
    global _SSS_V1208_OWNED_SETTINGS_POINTER
    if not _SSS_V1208_OWNED_SETTINGS_POINTER:
        return
    try:
        prop = getattr(getattr(bpy.types.WindowManager, 'bl_rna', None), 'properties', {}).get(_SETTINGS_PROP_NAME)
        fixed_type = getattr(prop, 'fixed_type', None) if prop is not None else None
        owned = fixed_type is None or str(getattr(fixed_type, 'identifier', '') or '') == str(getattr(SSS_NPanelSettings, '__name__', ''))
    except Exception:
        owned = False
    if owned and hasattr(bpy.types.WindowManager, _SETTINGS_PROP_NAME):
        try:
            delattr(bpy.types.WindowManager, _SETTINGS_PROP_NAME)
        except Exception:
            pass
    _SSS_V1208_OWNED_SETTINGS_POINTER = False


def _register_persistent_preference_handlers() -> None:
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return
    for container_name, callback in (
        ('save_pre', _save_persistent_preferences_on_save),
        ('load_pre', _save_all_npanel_settings_on_load_pre),
        ('load_post', _apply_persistent_preferences_on_load),
    ):
        container = getattr(handlers, container_name, None)
        if container is not None and callback not in container:
            container.append(callback)
            _SSS_V1208_REGISTERED_HANDLERS.append((container, callback))


def _unregister_persistent_preference_handlers() -> None:
    for container, callback in reversed(tuple(_SSS_V1208_REGISTERED_HANDLERS)):
        try:
            if callback in container:
                container.remove(callback)
        except Exception:
            pass
    _SSS_V1208_REGISTERED_HANDLERS.clear()


def apply_all_npanel_settings(context=None, *, include_smart_toon_graphs: bool = False) -> None:
    """Restore bounded scalar/UI state only; graph migration is explicit-use only."""
    del include_smart_toon_graphs
    ctx = context or getattr(bpy, 'context', None)
    apply_persistent_preferences(addon_preferences_owner(ctx))
    try:
        from . import material_editor as _material_editor
        _optional_call(
            getattr(_material_editor, 'restore_material_editor_settings', None),
            getattr(ctx, 'scene', None) if ctx is not None else None,
            force=True,
        )
    except Exception:
        pass
    try:
        from . import smart_toon as _smart_toon
        _optional_call(getattr(_smart_toon, 'restore_smart_toon_profile_scalars_on_load', None), ctx)
    except Exception:
        pass
    try:
        from . import ui_sections as _sss_ui_sections
        _optional_call(getattr(_sss_ui_sections, 'apply_section_state', None), ctx)
    except Exception:
        pass
    try:
        from . import common as _sss_common
        _optional_call(getattr(_sss_common, 'load_settings_file', None))
        _optional_call(getattr(_sss_common, 'apply_persistent_settings', None), ctx)
    except Exception:
        pass
    try:
        from . import properties as _scene_properties
        scene = getattr(ctx, 'scene', None) if ctx is not None else None
        if scene is not None:
            _optional_call(getattr(_scene_properties, 'apply_persistent_scene_settings', None), scene)
    except Exception:
        pass
    try:
        module = importlib.import_module('.smart_material_smart', __package__)
        _optional_call(getattr(module, 'apply_settings', None))
    except Exception:
        pass
    # Integrated material/profile graph replay is intentionally not performed
    # from load_post.  Each explicit tool restores its own scalar/UI state when
    # first used; no module scan, material scan, image access, or graph mutation
    # is allowed on file open.


def register() -> None:
    registered_before = len(_SSS_V1208_REGISTERED_CLASSES)
    try:
        for cls in classes:
            _safe_register_class(cls)
        _register_npanel_settings_pointer()
        _suppress_addon_preferences_draw()
        apply_persistent_preferences(addon_preferences_owner(getattr(bpy, 'context', None)))
    except Exception:
        _unregister_persistent_preference_handlers()
        _unregister_npanel_settings_pointer()
        for cls in reversed(_SSS_V1208_REGISTERED_CLASSES[registered_before:]):
            try:
                if _class_has_bl_rna(cls):
                    bpy.utils.unregister_class(cls)
            except Exception:
                pass
        del _SSS_V1208_REGISTERED_CLASSES[registered_before:]
        raise


def unregister() -> None:
    _unregister_persistent_preference_handlers()
    storage.clear_persistence_owner()
    _unregister_npanel_settings_pointer()
    for cls in reversed(tuple(_SSS_V1208_REGISTERED_CLASSES)):
        try:
            if _class_has_bl_rna(cls):
                bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _SSS_V1208_REGISTERED_CLASSES.clear()


# 5.18.224: never modify another add-on's AddonPreferences draw function.
def _suppress_addon_preferences_draw() -> None:
    return None

@persistent
def _apply_persistent_preferences_on_load(_dummy=None):
    """Restore scalar/UI state and migrate only stale light drivers."""
    context = getattr(bpy, 'context', None)
    try:
        apply_all_npanel_settings(context, include_smart_toon_graphs=False)
    except Exception:
        pass
    try:
        from . import smart_toon as _smart_toon
        _optional_call(getattr(_smart_toon, 'refresh_standard_light_drivers_on_load_fast', None), context)
    except Exception:
        pass
