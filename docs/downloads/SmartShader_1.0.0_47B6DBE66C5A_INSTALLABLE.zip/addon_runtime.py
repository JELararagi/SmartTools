# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import importlib
import sys
from dataclasses import dataclass, field
from typing import Callable

import bpy

bl_info = {
    "name": "Smart Shader",
    "author": "JELararagi",
    "version": (5, 18, 230),
    "blender": (5, 1, 0),
    "location": "N-panel > Smart Shader",
    "description": "Blender 5 material platform with Smart Shader Smart, PBR material generation, high-precision material finishing, and large frame-free custom icon command deck in supported Blender editor N-panels.",
    "category": "Material",
}

_SUITE_ID = "smart_shader_suite"
_OWNER_UUID = "3f6d8d7f-671d-4ff1-bf32-bf15518208aa"
_GENERATION = "5.18.230"
_PACKAGE_NAME = str(__package__ or (__name__.rpartition(".")[0] if "." in __name__ else __name__) or "").strip()
_EAGER_SUBMODULE_NAMES = (
    "properties", "operators", "slot_selection", "preset_preview_browser", "ui",
    "material_editor", "smart_toon", "legacy_proxy_cleanup", "smart_ui_assets",
    "smart_material_smart", "runtime",
)
_RUNTIME_LOADED = False


@dataclass
class _RuntimeLedger:
    generation: str
    classes: list[type] = field(default_factory=list)
    cleanup: list[Callable[[], None]] = field(default_factory=list)


_LEDGER = _RuntimeLedger(_GENERATION)


def _import_submodule(name: str):
    qualified = f"{_PACKAGE_NAME}.{name}" if _PACKAGE_NAME else name
    existing = sys.modules.get(qualified)
    if existing is not None:
        return existing
    return importlib.import_module(f".{name}", _PACKAGE_NAME or __package__ or __name__)


def _load_runtime_modules() -> dict[str, object]:
    return {name: _import_submodule(name) for name in _EAGER_SUBMODULE_NAMES}


globals().update(_load_runtime_modules())
CLASSES = (
    properties.CLASSES
    + operators.CLASSES
    + ui.CLASSES
    + material_editor.CLASSES
    + smart_material_smart.CLASSES
    + smart_toon.CLASSES
)


def _class_has_own_bl_rna(cls: type) -> bool:
    try:
        rna = vars(cls).get("bl_rna") or getattr(cls, "bl_rna", None)
        identifier = str(getattr(rna, "identifier", "") or "")
        inherited = {"Operator", "Panel", "PropertyGroup", "Menu", "UIList", "AddonPreferences"}
        return bool(identifier and identifier not in inherited)
    except Exception:
        return False

def _register_class_exact(cls: type, ledger: _RuntimeLedger) -> None:
    if not isinstance(cls, type):
        raise TypeError("Blender class must be a Python type")
    if cls in ledger.classes and _class_has_own_bl_rna(cls):
        return
    if _class_has_own_bl_rna(cls):
        raise RuntimeError(f"RNA class is already registered outside this generation ledger: {getattr(cls, '__name__', '<unnamed>')}")
    try:
        from . import translation
        translation.apply_rna_text_context(cls)
        bpy.utils.register_class(cls)
    except Exception:
        if cls in ledger.classes and _class_has_own_bl_rna(cls):
            return
        raise
    if not _class_has_own_bl_rna(cls):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        raise RuntimeError(f"RNA class registration did not publish class bl_rna: {getattr(cls, '__name__', '<unnamed>')}")
    ledger.classes.append(cls)

def _unregister_class_exact(cls: type) -> None:
    if _class_has_own_bl_rna(cls):
        bpy.utils.unregister_class(cls)


def _rollback_ledger(ledger: _RuntimeLedger) -> None:
    for cleanup in reversed(tuple(ledger.cleanup)):
        try:
            cleanup()
        except Exception:
            pass
    ledger.cleanup.clear()
    for cls in reversed(tuple(ledger.classes)):
        try:
            _unregister_class_exact(cls)
        except Exception:
            pass
    ledger.classes.clear()


def _restore_scene_settings_after_register():
    """Apply only bounded scalar state; never rebuild material graphs or inspect pixels."""
    scene = getattr(getattr(bpy, "context", None), "scene", None)
    if scene is not None:
        try:
            properties._set_scene_persistence_applied(scene, False)
            properties.apply_persistent_scene_settings(scene)
        except Exception:
            pass
        try:
            material_editor.restore_material_editor_settings(scene, force=True)
        except Exception:
            pass
    try:
        smart_toon.restore_smart_toon_profile_scalars_on_load(getattr(bpy, "context", None))
    except Exception:
        pass
    try:
        preferences.apply_all_npanel_settings(getattr(bpy, "context", None), include_smart_toon_graphs=False)
    except TypeError:
        try:
            preferences.apply_all_npanel_settings(getattr(bpy, "context", None))
        except Exception:
            pass
    except Exception:
        pass
    return None


def _register_impl():
    global _RUNTIME_LOADED, _LEDGER
    if _RUNTIME_LOADED:
        return None
    attempt = _RuntimeLedger(_GENERATION)
    integrated_registered = False
    smart_material_registered = False
    material_editor_registered = False
    smart_toon_registered = False
    properties_registered = False
    slot_properties_registered = False
    preview_properties_registered = False
    try:
        ui.end_ui_shutdown()
        ui.configure_manager_placement_api()
        attempt.cleanup.append(ui.clear_manager_placement_api)
        for cls in getattr(preset_preview_browser, "CLASSES", ()):
            _register_class_exact(cls, attempt)
        slot_selection.register_properties()
        slot_properties_registered = True
        properties.register_properties()
        properties_registered = True
        preset_preview_browser.register_properties()
        preview_properties_registered = True
        smart_ui_assets.register(force=True)
        attempt.cleanup.append(smart_ui_assets.unregister)
        for cls in CLASSES:
            _register_class_exact(cls, attempt)
        material_editor.register_properties()
        material_editor_registered = True
        smart_toon.register_properties()
        smart_toon_registered = True
        smart_material_smart.register()
        smart_material_registered = True
        runtime.register()
        integrated_registered = True
        _LEDGER = attempt
        _RUNTIME_LOADED = True
        _restore_scene_settings_after_register()
        return None
    except Exception:
        _RUNTIME_LOADED = False
        if integrated_registered:
            try:
                runtime.unregister()
            except Exception:
                pass
        if smart_material_registered:
            try:
                smart_material_smart.unregister()
            except Exception:
                pass
        if smart_toon_registered:
            try:
                smart_toon.unregister_properties()
            except Exception:
                pass
        if material_editor_registered:
            try:
                material_editor.unregister_properties()
            except Exception:
                pass
        try:
            ui.begin_ui_shutdown()
        except Exception:
            pass
        _rollback_ledger(attempt)
        if preview_properties_registered:
            try:
                preset_preview_browser.unregister_properties()
            except Exception:
                pass
        if properties_registered:
            try:
                properties.unregister_properties()
            except Exception:
                pass
        if slot_properties_registered:
            try:
                slot_selection.unregister_properties()
            except Exception:
                pass
        raise


def _unregister_impl():
    global _RUNTIME_LOADED
    if not _RUNTIME_LOADED:
        return None
    _RUNTIME_LOADED = False
    try:
        legacy_proxy_cleanup.unregister()
    except Exception:
        pass
    try:
        runtime.unregister()
    except Exception:
        pass
    try:
        smart_material_smart.unregister()
    except Exception:
        pass
    try:
        smart_toon.unregister_properties()
    except Exception:
        pass
    try:
        material_editor.unregister_properties()
    except Exception:
        pass
    try:
        ui.begin_ui_shutdown()
    except Exception:
        pass
    _rollback_ledger(_LEDGER)
    try:
        ui.clear_manager_placement_api()
    except Exception:
        pass
    try:
        preset_preview_browser.unregister_properties()
    except Exception:
        pass
    try:
        properties.unregister_properties()
    except Exception:
        pass
    try:
        slot_selection.unregister_properties()
    except Exception:
        pass
    try:
        clear_cache = getattr(preset_preview_browser, "clear_preview_cache", None)
        if callable(clear_cache):
            clear_cache()
    except Exception:
        pass
    return None


register = _register_impl
unregister = _unregister_impl

if __name__ == "__main__":
    register()
