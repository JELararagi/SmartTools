"""Smart material layers, reusable masks, and non-destructive overlay helpers."""
from __future__ import annotations
from .translation import loc_text as _lt
from .translation import AddonError
import json
from datetime import datetime
from pathlib import Path
import re
from typing import Iterable
import bpy
from . import builders, core, textures
from .translation import tx
LAYER_STACK_KEY = 'sss_layer_stack'
TAG_SPLIT_RE = re.compile('[,;、/|]+')

def _split_recipe_tag_values(values) -> list[str]:
    if values is None:
        return []
    if isinstance(values, str):
        raw_items = TAG_SPLIT_RE.split(values)
    elif isinstance(values, (list, tuple, set)):
        raw_items = []
        for item in values:
            raw_items.extend(_split_recipe_tag_values(item))
        return raw_items
    else:
        raw_items = [str(values)]
    return [str(item or '').strip() for item in raw_items if str(item or '').strip()]

def _recipe_tags(values) -> list[str]:
    tags: list[str] = []
    seen: set[str] = set()
    for tag in _split_recipe_tag_values(values):
        clean = core.clean_library_name(tag)
        if not clean:
            continue
        key = core.library_name_key(clean)
        if key in seen:
            continue
        seen.add(key)
        tags.append(clean)
    return tags
SMART_LAYER_PRESET_ORDER = ['EDGE_WEAR_LAYER', 'PAINT_CHIPS_LAYER', 'RUST_LAYER', 'PATINA_LAYER', 'MOSS_LAYER', 'SNOW_LAYER', 'WET_LAYER', 'DUST_LAYER', 'SOOT_LAYER', 'FINGERPRINTS_LAYER']
SMART_LAYER_PRESET_META = {'EDGE_WEAR_LAYER': {'label_en': 'Edge Wear Layer', 'label_ja': 'エッジ摩耗レイヤー', 'summary_en': 'Add a non-destructive wear pass suited to chipped paint, softened corners, and handled surfaces.', 'summary_ja': '塗装ハゲ、角の摩耗、手で触れられた面の擦れを、非破壊で重ねるレイヤーです。', 'usage_en': 'Best for hard-surface properties, painted metal, plastic housings, and presentation lookdev where edge breakup should remain adjustable.', 'usage_ja': 'ハードサーフェス、小物、塗装金属、樹脂外装などで、エッジ表現を後から調整したい場合に向きます。', 'controls_en': 'Mask mode, strength, noise scale, and mask contrast. AUTO prefers curvature/cavity when available and otherwise falls back to an edge mask.', 'controls_ja': 'マスク方式、強度、ノイズスケール、マスクコントラストを調整できます。自動は利用可能なら曲率やキャビティを優先し、なければエッジマスクへフォールバックします。', 'default_mask': 'EDGE', 'payload': {'base_color': (0.82, 0.8, 0.76, 1.0), 'roughness': 0.28, 'metalness': 0.0, 'coat_weight': 0.0}}, 'RUST_LAYER': {'label_en': 'Rust Layer', 'label_ja': '錆レイヤー', 'summary_en': 'Overlay oxidized breakup and rougher earthy color for aged metal, bolts, and exposed seams.', 'summary_ja': '古びた金属、ボルト、継ぎ目の露出部向けに、酸化した色味と荒れた粗さを重ねるレイヤーです。', 'usage_en': 'Use on metal assets that need optional aging without rebuilding the base material.', 'usage_ja': 'ベース材質を作り直さずに、金属アセットへ経年劣化を足したいときに向きます。', 'controls_en': 'Mask mode, strength, noise scale, and contrast. Curvature and cavity maps are preferred when present.', 'controls_ja': 'マスク方式、強度、ノイズスケール、コントラストを調整できます。曲率・キャビティマップがある場合はそれを優先します。', 'default_mask': 'EDGE', 'payload': {'base_color': (0.4, 0.18, 0.08, 1.0), 'roughness': 0.86, 'metalness': 0.0, 'coat_weight': 0.0}}, 'MOSS_LAYER': {'label_en': 'Moss Layer', 'label_ja': '苔レイヤー', 'summary_en': 'Add upward-growing organic breakup for damp stone, bark, masonry, and outdoor properties.', 'summary_ja': '湿った石、樹皮、外壁、屋外小物に、上向きに育つ有機的な付着感を足すレイヤーです。', 'usage_en': 'Use for natural accumulation on surfaces that stay damp or receive little direct cleaning.', 'usage_ja': '湿気が残りやすい面や清掃されにくい面への自然付着表現に向きます。', 'controls_en': 'AUTO prefers thickness maps when present and otherwise builds an upward mask with subtle noise breakup.', 'controls_ja': '自動は厚みマップがあればそれを優先し、なければ軽いノイズを加えた上向きマスクを生成します。', 'default_mask': 'UPWARD', 'payload': {'base_color': (0.22, 0.35, 0.16, 1.0), 'roughness': 0.78, 'metalness': 0.0, 'coat_weight': 0.0}}, 'SNOW_LAYER': {'label_en': 'Snow Layer', 'label_ja': '雪レイヤー', 'summary_en': 'Add bright cold accumulation for rooftops, ledges, terrain, and exposed top-facing forms.', 'summary_ja': '屋根、段差、地形、上面へ積もる雪の表現を足すレイヤーです。', 'usage_en': 'Useful for fast season variants and top-facing accumulation studies.', 'usage_ja': '季節差分や、上面への堆積スタディを素早く作る用途に向きます。', 'controls_en': 'AUTO prefers thickness maps when available and otherwise uses an upward mask with light breakup.', 'controls_ja': '自動は厚みマップがあればそれを優先し、なければ軽い揺らぎのある上向きマスクを使います。', 'default_mask': 'UPWARD', 'payload': {'base_color': (0.96, 0.98, 1.0, 1.0), 'roughness': 0.36, 'metalness': 0.0, 'coat_weight': 0.06, 'coat_roughness': 0.18, 'subsurface_weight': 0.05}}, 'WET_LAYER': {'label_en': 'Wet Layer', 'label_ja': '濡れレイヤー', 'summary_en': 'Add a darker, smoother wet pass for rain-darkened concrete, stone, bark, and puddled surfaces.', 'summary_ja': '雨で濡れたコンクリート、石、樹皮、濡れた面の暗さと滑らかさを重ねるレイヤーです。', 'usage_en': 'Use when you want quick rain, splash, or fresh-wash variants while preserving the original graph underneath.', 'usage_ja': '元のグラフを残したまま、雨・飛沫・洗いたて差分を素早く作りたいときに向きます。', 'controls_en': 'AUTO leans toward a facing/noise blend so exposed planes receive broader wet coverage, but you can force any mask mode.', 'controls_ja': '自動は面方向とノイズを混ぜた広めの濡れマスクを使いますが、任意の方式へ固定もできます。', 'default_mask': 'FACING', 'payload': {'base_color': (0.12, 0.12, 0.13, 1.0), 'roughness': 0.04, 'metalness': 0.0, 'coat_weight': 0.42, 'coat_roughness': 0.02}}, 'DUST_LAYER': {'label_en': 'Dust Layer', 'label_ja': '埃レイヤー', 'summary_en': 'Add soft dusty lift for shelves, machinery, properties, and presentation renders that need gentle age or storage buildup.', 'summary_ja': '棚、機械、小物、プレゼン用レンダーへ、保管汚れや軽い経年感としての埃を足すレイヤーです。', 'usage_en': 'Good for archviz staging, prop storage, and subtle surface breakup rather than heavy weathering.', 'usage_ja': '強い劣化ではなく、アーキビズの演出や小物保管汚れのような軽い表面変化に向きます。', 'controls_en': 'AUTO uses an upward/noise style mask so horizontal surfaces catch more dust by default.', 'controls_ja': '自動は上向きとノイズを組み合わせたマスクを使い、水平面ほど埃が乗りやすい挙動にします。', 'default_mask': 'UPWARD', 'payload': {'base_color': (0.74, 0.72, 0.68, 1.0), 'roughness': 0.72, 'metalness': 0.0, 'coat_weight': 0.0}}}
SMART_LAYER_PRESET_META.update({'PAINT_CHIPS_LAYER': {'label_en': 'Paint Chips Layer', 'label_ja': _lt('塗装チップレイヤー'), 'summary_en': 'Overlay chipped paint and exposed primer style breakup for machinery, helmets, railings, and coated hard-surface assets.', 'summary_ja': _lt('機械、ヘルメット、手すり、塗装ハードサーフェス向けに、剥がれた塗装と下地露出風の崩れを重ねるレイヤーです。'), 'usage_en': 'Use when you need more graphic paint-loss breakup than a soft edge-wear pass.', 'usage_ja': _lt('柔らかい摩耗よりも、もっとグラフィックな塗装剥離感が欲しい場合に向きます。'), 'controls_en': 'EDGE is the default. Increase contrast for sharper chips and reduce strength for older faded coating loss.', 'controls_ja': _lt('既定はエッジです。コントラストを上げると欠けが鋭くなり、強度を下げると古い塗膜の薄れのように扱えます。'), 'default_mask': 'EDGE', 'payload': {'base_color': (0.58, 0.54, 0.47, 1.0), 'roughness': 0.46, 'metalness': 0.0, 'coat_weight': 0.0}}, 'PATINA_LAYER': {'label_en': 'Patina Layer', 'label_ja': _lt('パティナレイヤー'), 'summary_en': 'Add aged verdigris or oxidized color drift for copper, bronze, architectural trim, and outdoor metal details.', 'summary_ja': _lt('銅、青銅、建築金物、屋外金属ディテール向けに、緑青や酸化による色移りを重ねるレイヤーです。'), 'usage_en': 'Useful for statues, roof trim, heritage properties, and product looks that need optional aged oxidation.', 'usage_ja': _lt('像、屋根金物、年代物の小物、製品CG の経年酸化差分に向きます。'), 'controls_en': 'UPWARD is the default, but EDGE or CAVITY can make the oxidation cling to seams and recesses.', 'controls_ja': _lt('既定は上向きですが、エッジやキャビティ にすると継ぎ目や凹部へ寄せられます。'), 'default_mask': 'UPWARD', 'payload': {'base_color': (0.2, 0.42, 0.34, 1.0), 'roughness': 0.74, 'metalness': 0.0, 'coat_weight': 0.0}}, 'SOOT_LAYER': {'label_en': 'Soot Layer', 'label_ja': _lt('煤レイヤー'), 'summary_en': 'Overlay smoky dark residue for vents, exhausts, candles, fire damage, and industrial grime accents.', 'summary_ja': _lt('換気口、排気口、蝋燭、火傷表現、工業汚れのアクセント向けに、煤のような暗い残留物を重ねるレイヤーです。'), 'usage_en': 'Use for local dark staining around emission points, vents, scorched areas, or stylized grime buildup.', 'usage_ja': _lt('発生源周辺の局所的な黒ずみ、排気痕、焦げ、演出的な汚れの蓄積に向きます。'), 'controls_en': 'FACING is the default for broad residue, while NOISE gives a dustier breakup.', 'controls_ja': _lt('広い残留には面方向、粉っぽい崩れにはノイズ が向きます。'), 'default_mask': 'FACING', 'payload': {'base_color': (0.04, 0.04, 0.045, 1.0), 'roughness': 0.68, 'metalness': 0.0, 'coat_weight': 0.0}}, 'FINGERPRINTS_LAYER': {'label_en': 'Fingerprints Layer', 'label_ja': _lt('指紋レイヤー'), 'summary_en': 'Add oily touch marks and handling residue suited to glossy plastics, painted panels, glass, and consumer products.', 'summary_ja': _lt('光沢樹脂、塗装パネル、ガラス、コンシューマ製品向けに、触れ跡や皮脂汚れ風の残留を重ねるレイヤーです。'), 'usage_en': 'Useful for product CGI, close-up hero properties, touch surfaces, and realism passes that need subtle handling evidence.', 'usage_ja': _lt('製品CG、寄りの小物、タッチ面、扱われた痕跡を少しだけ見せたいリアル寄り差分に向きます。'), 'controls_en': 'NOISE is the default for scattered residue, while IMAGE_ALPHA lets you drive the layer from custom touch masks.', 'controls_ja': _lt('点在する残留にはノイズ、手描きや焼き込みマスクから制御したい場合は 画像アルファ が向きます。'), 'default_mask': 'NOISE', 'payload': {'base_color': (0.08, 0.08, 0.085, 1.0), 'roughness': 0.06, 'metalness': 0.0, 'coat_weight': 0.22, 'coat_roughness': 0.03}}})
SMART_MASK_ORDER = ['AUTO', 'UPWARD', 'EDGE', 'FACING', 'NOISE', 'CURVATURE', 'CAVITY', 'THICKNESS', 'WORLD_NORMAL', 'POSITION', 'IMAGE_ALPHA', 'WHITE']
SMART_MASK_META = {'AUTO': {'label_en': 'Auto', 'label_ja': '自動', 'summary_en': 'Choose the safest mask source for the selected layer, preferring advisory texture maps when they exist.', 'summary_ja': '選択中レイヤーに対して最も安全なマスク源を選び、利用可能なら補助テクスチャマップを優先します。'}, 'UPWARD': {'label_en': 'Upward', 'label_ja': '上向き', 'summary_en': 'Use world/object-facing upward accumulation, helpful for snow, moss, and dust.', 'summary_ja': '上向き面を優先する堆積マスクです。雪、苔、埃に向きます。'}, 'EDGE': {'label_en': 'Edge', 'label_ja': 'エッジ', 'summary_en': 'Use pointiness or facing-based edge breakup for wear, rust, and chipped areas.', 'summary_ja': 'ポイントネスまたは面方向を用いたエッジ強調マスクです。摩耗や錆に向きます。'}, 'FACING': {'label_en': 'Facing', 'label_ja': '面方向', 'summary_en': 'Use a view/facing-style broad mask for wet passes, broad coatings, and presentation accent layers.', 'summary_ja': '視線・面方向ベースの広めマスクです。濡れや広いコート表現に向きます。'}, 'NOISE': {'label_en': 'Noise', 'label_ja': 'ノイズ', 'summary_en': 'Pure procedural breakup. Good when no supporting textures exist and you want fast variation.', 'summary_ja': '純プロシージャルの揺らぎマスクです。補助テクスチャが無い場合の素早い変化付けに向きます。'}, 'CURVATURE': {'label_en': 'Curvature Map', 'label_ja': '曲率マップ', 'summary_en': 'Use a detected curvature texture if one is already present in the material graph.', 'summary_ja': '既にグラフへある曲率テクスチャをマスクとして使います。'}, 'CAVITY': {'label_en': 'Cavity Map', 'label_ja': 'キャビティマップ', 'summary_en': 'Use a detected cavity texture if one is present. Good for recess-driven buildup.', 'summary_ja': '既存のキャビティテクスチャを使います。凹部への付着表現に向きます。'}, 'THICKNESS': {'label_en': 'Thickness Map', 'label_ja': '厚みマップ', 'summary_en': 'Use a detected thickness texture for shell-style buildup or imported utility maps.', 'summary_ja': '既存の厚みテクスチャを使います。シェル状の付着や外部ユーティリティマップの活用に向きます。'}, 'WORLD_NORMAL': {'label_en': 'World Normal Map', 'label_ja': 'ワールド法線マップ', 'summary_en': 'Use a detected world-space normal texture. The blue channel is treated as upward exposure for accumulation-style masks.', 'summary_ja': '既存のワールド空間法線テクスチャを使います。青チャンネルを上向き露出として扱い、堆積系マスクに利用します。'}, 'POSITION': {'label_en': 'Position Map', 'label_ja': '位置マップ', 'summary_en': 'Use a detected world/object position texture. The blue channel is treated as height for upward accumulation and distribution masks.', 'summary_ja': '既存の位置テクスチャを使います。青チャンネルを高さとして扱い、上向き堆積や分布の制御に使います。'}, 'IMAGE_ALPHA': {'label_en': 'Image Alpha', 'label_ja': '画像アルファ', 'summary_en': 'Use the alpha output of a detected image node when you already have a mask baked into a texture.', 'summary_ja': '既存画像ノードのアルファ出力を使います。マスクが画像へ焼き込まれている場合に便利です。'}, 'WHITE': {'label_en': 'Solid White', 'label_ja': '白ベタ', 'summary_en': 'Apply the layer everywhere. Useful as a quick full-surface pass before manual editing.', 'summary_ja': '全面へ一括適用します。あとから手動調整する前提の全体パスに向きます。'}}

def _bilingual_label(scene, meta: dict, key: str='label') -> str:
    return tx(scene, meta[f'{key}_en'], meta[f'{key}_ja'])

def layer_preset_items(scene=None):
    items = []
    for preset_id in SMART_LAYER_PRESET_ORDER:
        meta = SMART_LAYER_PRESET_META[preset_id]
        en = f"{meta['summary_en']}\nUse: {meta['usage_en']}\nControls: {meta['controls_en']}"
        ja = _lt(f"{meta['summary_ja']}\n用途: {meta['usage_ja']}\n操作項目: {meta['controls_ja']}")
        items.append((preset_id, _bilingual_label(scene, meta), tx(scene, en, ja)))
    return items

def mask_mode_items(scene=None):
    items = []
    for mask_id in SMART_MASK_ORDER:
        meta = SMART_MASK_META[mask_id]
        items.append((mask_id, _bilingual_label(scene, meta), tx(scene, meta['summary_en'], meta['summary_ja'])))
    return items

def layer_preset_meta(preset_id: str) -> dict:
    return SMART_LAYER_PRESET_META.get(str(preset_id or '').strip().upper(), SMART_LAYER_PRESET_META[SMART_LAYER_PRESET_ORDER[0]])

def mask_mode_meta(mask_id: str) -> dict:
    return SMART_MASK_META.get(str(mask_id or '').strip().upper(), SMART_MASK_META[SMART_MASK_ORDER[0]])

def layer_description(scene, preset_id: str) -> str:
    meta = layer_preset_meta(preset_id)
    return tx(scene, f"{meta['summary_en']}\nUse: {meta['usage_en']}\nControls: {meta['controls_en']}", _lt(f"{meta['summary_ja']}\n用途: {meta['usage_ja']}\n操作項目: {meta['controls_ja']}"))

def mask_description(scene, mask_id: str) -> str:
    meta = mask_mode_meta(mask_id)
    return tx(scene, meta['summary_en'], meta['summary_ja'])

def _sanitize_layer_stack_entry(entry: dict) -> dict | None:
    if not isinstance(entry, dict):
        return None
    preset = str(entry.get('preset', '') or '').strip().upper()
    if preset not in SMART_LAYER_PRESET_META:
        return None
    mask_mode = str(entry.get('mask_mode', 'AUTO') or 'AUTO').strip().upper()
    if mask_mode not in SMART_MASK_META:
        mask_mode = 'AUTO'

    def _number(value, default):
        try:
            return float(value)
        except Exception:
            return float(default)
    return {'preset': preset, 'mask_mode': mask_mode, 'source': str(entry.get('source', '') or '').strip(), 'strength': _number(entry.get('strength', 0.65), 0.65), 'noise_scale': _number(entry.get('noise_scale', 8.0), 8.0), 'contrast': _number(entry.get('contrast', 1.0), 1.0)}

def material_layer_stack(material) -> list[dict]:
    if material is None:
        return []
    try:
        raw = material.get(LAYER_STACK_KEY)
        payload = json.loads(raw) if raw else []
    except Exception:
        payload = []
    if not isinstance(payload, list):
        return []
    clean: list[dict] = []
    for entry in payload:
        item = _sanitize_layer_stack_entry(entry)
        if item is not None:
            clean.append(item)
    return clean

def layer_stack_count(material) -> int:
    return len(material_layer_stack(material))

def set_material_layer_stack(material, stack: list[dict]) -> None:
    if material is None:
        return
    clean = [item for item in (_sanitize_layer_stack_entry(entry) for entry in stack or []) if item is not None]
    material[LAYER_STACK_KEY] = json.dumps(clean, ensure_ascii=False)

def layer_recipe_path() -> Path:
    return core.addon_storage_dir() / 'smart_shader_suite_layer_recipes.json'

def _sanitize_layer_recipe_entry(entry: dict) -> dict | None:
    if not isinstance(entry, dict):
        return None
    name = core.clean_library_name(entry.get('name', ''))
    if not name:
        return None
    stack = [item for item in (_sanitize_layer_stack_entry(it) for it in entry.get('stack') or []) if item is not None]
    if not stack:
        return None
    tags = _recipe_tags(entry.get('tags') or [])
    return {'name': name, 'summary_en': str(entry.get('summary_en', '') or '').strip(), 'summary_ja': str(entry.get('summary_ja', '') or '').strip(), 'saved_at': str(entry.get('saved_at', '') or '').strip(), 'tags': tags, 'stack': stack, 'layer_count': len(stack)}

def list_layer_recipes() -> list[dict]:
    recipes = [item for item in (_sanitize_layer_recipe_entry(entry) for entry in core.safe_json_load(layer_recipe_path())) if item is not None]
    recipes.sort(key=lambda item: core.library_name_key(item.get('name', '')))
    return recipes

def find_layer_recipe(name: str):
    target = core.library_name_key(name)
    if not target:
        return None
    for entry in list_layer_recipes():
        if core.library_name_key(entry.get('name', '')) == target:
            return entry
    return None

def layer_recipe_count() -> int:
    return len(list_layer_recipes())

def layer_recipe_items(scene=None):
    items = []
    for entry in list_layer_recipes():
        name = str(entry.get('name', '') or '')
        count = int(entry.get('layer_count', 0) or 0)
        summary_en = str(entry.get('summary_en', '') or '').strip() or f'Reusable smart-material style stack with {count} layers.'
        summary_ja = str(entry.get('summary_ja', '') or '').strip() or _lt(f'{count} レイヤーを持つ再利用スマートマテリアル風スタックです。')
        tags = ', '.join(entry.get('tags', []))
        en = f"{summary_en}\nLayers: {count}\nTags: {tags or '-'}"
        ja = _lt(f"{summary_ja}\nレイヤー数: {count}\nタグ: {tags or '-'}")
        items.append((name, name, tx(scene, en, ja)))
    if not items:
        items.append(('NO_LAYER_RECIPES', tx(scene, 'No Layer Recipes', _lt('保存済みレシピなし')), tx(scene, 'Save a smart-layer recipe first.', _lt('先にスマートレイヤーレシピを保存してください。'))))
    return items

def save_layer_recipe_from_material(material, name: str) -> dict:
    if material is None:
        raise AddonError(_lt('No material provided.', 'マテリアルが指定されていません。'))
    recipe_name = core.clean_library_name(name)
    if not recipe_name:
        raise AddonError(_lt('Layer recipe name is required.', 'レイヤーレシピ名が必要です。'))
    stack = material_layer_stack(material)
    if not stack:
        raise AddonError(_lt('No smart-layer stack is stored on this material yet.', 'このマテリアルにはまだスマートレイヤースタックが保存されていません。'))
    labels_en = [layer_preset_meta(item['preset'])['label_en'] for item in stack]
    labels_ja = [layer_preset_meta(item['preset'])['label_ja'] for item in stack]
    entry = {'name': recipe_name, 'summary_en': f"Reusable smart-material stack captured from {material.name} with {len(stack)} layers: {', '.join(labels_en[:4])}.", 'summary_ja': _lt(f"{material.name} から取得した {len(stack)} レイヤーの再利用スマートマテリアルスタックです: {', '.join(labels_ja[:4])}。"), 'saved_at': datetime.utcnow().isoformat(timespec='seconds') + 'Z', 'tags': _recipe_tags(['Smart Material', 'Smart Layers', *labels_en[:4]]), 'stack': stack, 'layer_count': len(stack)}
    db = list_layer_recipes()
    replaced = False
    for index, item in enumerate(db):
        if core.library_name_key(item.get('name', '')) == core.library_name_key(recipe_name):
            db[index] = entry
            replaced = True
            break
    if not replaced:
        db.append(entry)
    db.sort(key=lambda item: core.library_name_key(item.get('name', '')))
    core.safe_json_save(layer_recipe_path(), db)
    return {'saved': True, 'replaced': replaced, 'layer_count': len(stack), 'name': recipe_name}

def delete_layer_recipe(name: str) -> bool:
    target = core.library_name_key(name)
    if not target:
        return False
    db = list_layer_recipes()
    kept = [entry for entry in db if core.library_name_key(entry.get('name', '')) != target]
    if len(kept) == len(db):
        return False
    core.safe_json_save(layer_recipe_path(), kept)
    return True

def export_layer_recipe_library(path: Path) -> int:
    payload = list_layer_recipes()
    core.safe_json_save(Path(path), payload)
    return len(payload)

def _load_layer_recipe_library_payload(path: Path) -> list[dict]:
    if not Path(path).exists():
        return []
    try:
        payload = json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return []
    if isinstance(payload, dict):
        for key in ('recipes', 'items', 'library', 'presets', 'layers'):
            value = payload.get(key)
            if isinstance(value, list):
                payload = value
                break
        else:
            if payload.get('name'):
                payload = [payload]
            else:
                return []
    if not isinstance(payload, list):
        return []
    return [entry for entry in payload if isinstance(entry, dict)]

def import_layer_recipe_library(path: Path, mode: str='MERGE') -> dict:
    incoming_raw = _load_layer_recipe_library_payload(Path(path))
    incoming = []
    skipped_invalid = 0
    for entry in incoming_raw:
        clean = _sanitize_layer_recipe_entry(entry)
        if clean is None:
            skipped_invalid += 1
            continue
        incoming.append(clean)
    if mode == 'REPLACE':
        incoming.sort(key=lambda item: core.library_name_key(item.get('name', '')))
        core.safe_json_save(layer_recipe_path(), incoming)
        return {'imported': len(incoming), 'replaced': 0, 'skipped_invalid': skipped_invalid, 'total': len(incoming), 'mode': 'REPLACE'}
    merged = []
    seen: dict[str, int] = {}
    for entry in list_layer_recipes():
        key = core.library_name_key(entry.get('name', ''))
        seen[key] = len(merged)
        merged.append(entry)
    imported = 0
    replaced = 0
    for entry in incoming:
        key = core.library_name_key(entry.get('name', ''))
        if key in seen:
            merged[seen[key]] = entry
            replaced += 1
        else:
            seen[key] = len(merged)
            merged.append(entry)
            imported += 1
    merged.sort(key=lambda item: core.library_name_key(item.get('name', '')))
    core.safe_json_save(layer_recipe_path(), merged)
    return {'imported': imported, 'replaced': replaced, 'skipped_invalid': skipped_invalid, 'total': len(merged), 'mode': 'MERGE'}

def repair_layer_recipe_library() -> dict:
    original = _load_layer_recipe_library_payload(layer_recipe_path())
    repaired: list[dict] = []
    seen: dict[str, int] = {}
    dropped = 0
    duplicates = 0
    for entry in original:
        clean = _sanitize_layer_recipe_entry(entry)
        if clean is None:
            dropped += 1
            continue
        key = core.library_name_key(clean['name'])
        if key in seen:
            repaired[seen[key]] = clean
            duplicates += 1
        else:
            seen[key] = len(repaired)
            repaired.append(clean)
    repaired.sort(key=lambda item: core.library_name_key(item.get('name', '')))
    core.safe_json_save(layer_recipe_path(), repaired)
    return {'before': len(original), 'after': len(repaired), 'dropped': dropped, 'duplicates': duplicates}

def apply_layer_recipe(material, recipe_name: str) -> dict:
    recipe = find_layer_recipe(recipe_name)
    if recipe is None:
        raise AddonError(_lt('Layer recipe not found.', 'レイヤーレシピが見つかりません。'))
    stack = [item for item in (_sanitize_layer_stack_entry(entry) for entry in recipe.get('stack') or []) if item is not None]
    if not stack:
        raise AddonError(_lt('Saved layer recipe has no valid layers.', '保存済みレイヤーレシピに有効なレイヤーがありません。'))
    created_nodes = 0
    notes: list[str] = []
    applied_labels_en: list[str] = []
    applied_labels_ja: list[str] = []
    for entry in stack:
        result = apply_smart_layer(material, preset_id=entry.get('preset', 'EDGE_WEAR_LAYER'), mask_mode=entry.get('mask_mode', 'AUTO'), strength=float(entry.get('strength', 0.65)), noise_scale=float(entry.get('noise_scale', 8.0)), contrast=float(entry.get('contrast', 1.0)))
        created_nodes += int(result.get('created_nodes', 0) or 0)
        notes.extend(result.get('notes', []) or [])
        applied_labels_en.append(result.get('label_en', layer_preset_meta(entry['preset'])['label_en']))
        applied_labels_ja.append(result.get('label_ja', layer_preset_meta(entry['preset'])['label_ja']))
    return {'recipe_name': str(recipe.get('name', '') or recipe_name), 'layers_applied': len(stack), 'created_nodes': created_nodes, 'notes': notes, 'summary_en': str(recipe.get('summary_en', '') or '').strip(), 'summary_ja': str(recipe.get('summary_ja', '') or '').strip(), 'applied_labels_en': applied_labels_en, 'applied_labels_ja': applied_labels_ja}

def _append_layer_stack(material, entry: dict) -> None:
    stack = material_layer_stack(material)
    clean = _sanitize_layer_stack_entry(entry)
    if clean is None:
        return
    stack.append(clean)
    set_material_layer_stack(material, stack)

def _first_image_nodes(material) -> list:
    try:
        return list(core.iter_image_nodes(material))
    except Exception:
        return []

def _find_usage_node(material, *usages: str):
    wanted = {str(usage or '').strip().lower() for usage in usages if usage}
    if not wanted:
        return (None, '')
    for node in _first_image_nodes(material):
        usage = textures.guess_image_usage(node)
        if usage in wanted:
            return (node, usage)
    return (None, '')

def _first_alpha_capable_image(material):
    nodes = _first_image_nodes(material)
    ranked = sorted(nodes, key=lambda node: 0 if textures.guess_image_usage(node) in {'alpha', 'opacity', 'mask', 'base_color'} else 1)
    for node in ranked:
        alpha = core.socket_by_name(getattr(node, 'outputs', []), 'Alpha')
        if alpha is not None:
            return (node, alpha)
    return (None, None)

def _value_socket_from_source(nt, source_socket, x: float, y: float, label: str):
    if source_socket is None:
        return None
    stype = str(getattr(source_socket, 'type', '') or '').upper()
    sname = str(getattr(source_socket, 'name', '') or '').lower()
    if stype in {'RGBA', 'COLOR', 'VECTOR'} or 'color' in sname:
        rgb_to_bw = builders.create_node(nt, 'ShaderNodeRGBToBW', x, y, label)
        builders.link(nt, source_socket, builders.try_input(rgb_to_bw, 'Color'))
        return builders.try_output(rgb_to_bw, 'Val', 'Value')
    return source_socket

def _channel_socket_from_usage_node(nt, node, usage: str, x: float, y: float, label: str):
    if node is None:
        return None
    usage = str(usage or '').strip().lower()
    color = core.socket_by_name(getattr(node, 'outputs', []), 'Color')
    alpha = core.socket_by_name(getattr(node, 'outputs', []), 'Alpha', 'Fac', 'Value')
    if usage in {'world_normal', 'position'} and color is not None:
        sep = builders.create_node(nt, 'ShaderNodeSeparateRGB', x, y, f'{label} Separate')
        builders.link(nt, color, builders.try_input(sep, 'Image', 'Color'))
        return builders.try_output(sep, 'B', 'Blue')
    return alpha or color

def _ramp_positions(contrast: float) -> tuple[float, float]:
    value = max(0.1, float(contrast))
    spread = max(0.06, min(0.4, 0.22 / value))
    return (max(0.0, 0.5 - spread), min(1.0, 0.5 + spread))

def _apply_contrast(nt, source_socket, contrast: float, x: float, y: float, label: str):
    source_socket = _value_socket_from_source(nt, source_socket, x, y, f'{label} BW')
    if source_socket is None:
        return None
    if abs(float(contrast) - 1.0) < 0.025:
        return source_socket
    pos0, pos1 = _ramp_positions(contrast)
    ramp = builders.new_bw_ramp(nt, x + 220, y, label, pos0, pos1)
    builders.link(nt, source_socket, builders.try_input(ramp, 'Fac'))
    return _value_socket_from_source(nt, builders.try_output(ramp, 'Color'), x + 440, y, f'{label} Value')

def _set_mapping_uniform_scale(mapping, scale: float) -> None:
    sock = core.socket_by_name(getattr(mapping, 'inputs', []), 'Scale')
    if sock is None:
        return
    try:
        current = getattr(sock, 'default_value', None)
        if hasattr(current, '__len__') and len(current) >= 3:
            sock.default_value = (float(scale), float(scale), float(scale))
        else:
            sock.default_value = float(scale)
    except Exception:
        pass

def _facing_mask(nt, x: float, y: float, label: str, contrast: float):
    layer = builders.create_node(nt, 'ShaderNodeLayerWeight', x, y, f'{label} Facing')
    ramp = builders.new_bw_ramp(nt, x + 220, y, f'{label} Ramp', *_ramp_positions(contrast))
    builders.link(nt, builders.try_output(layer, 'Facing'), builders.try_input(ramp, 'Fac'))
    return _value_socket_from_source(nt, builders.try_output(ramp, 'Color'), x + 440, y, f'{label} Value')

def _noise_mask(nt, vector_socket, x: float, y: float, label: str, noise_scale: float, contrast: float):
    noise = builders.create_node(nt, 'ShaderNodeTexNoise', x, y, f'{label} Noise')
    scale = builders.new_value(nt, x - 220, y - 180, float(noise_scale), f'{label} Scale')
    ramp = builders.new_bw_ramp(nt, x + 240, y, f'{label} Ramp', *_ramp_positions(contrast))
    if vector_socket is not None:
        builders.link(nt, vector_socket, builders.try_input(noise, 'Vector'))
    builders.link(nt, builders.try_output(scale, 'Value'), builders.try_input(noise, 'Scale'))
    try:
        builders.set_socket_value(builders.try_input(noise, 'Detail'), 8.0)
    except Exception:
        pass
    builders.link(nt, builders.try_output(noise, 'Fac'), builders.try_input(ramp, 'Fac'))
    return _value_socket_from_source(nt, builders.try_output(ramp, 'Color'), x + 460, y, f'{label} Value')

def _white_mask(nt, x: float, y: float, label: str):
    node = builders.new_value(nt, x, y, 1.0, label)
    return builders.try_output(node, 'Value')

def _build_overlay_principled(nt, preset_id: str, x: float, y: float):
    meta = layer_preset_meta(preset_id)
    payload = dict(meta.get('payload') or {})
    bsdf = builders.create_node(nt, 'ShaderNodeBsdfPrincipled', x, y, f"{meta['label_en']} Overlay")
    builders.set_socket_value(builders.principled_socket(bsdf, 'Base Color'), payload.get('base_color', (0.8, 0.8, 0.8, 1.0)))
    builders.set_socket_value(builders.principled_socket(bsdf, 'Roughness'), payload.get('roughness', 0.5))
    builders.set_socket_value(builders.principled_socket(bsdf, 'Metallic'), payload.get('metalness', 0.0))
    builders.set_socket_value(builders.principled_socket(bsdf, 'IOR'), payload.get('ior', 1.45))
    builders.set_socket_value(builders.principled_socket(bsdf, 'Transmission Weight', 'Transmission'), payload.get('transmission', 0.0))
    builders.set_socket_value(builders.principled_socket(bsdf, 'Subsurface Weight', 'Subsurface'), payload.get('subsurface_weight', 0.0))
    builders.set_socket_value(builders.principled_socket(bsdf, 'Coat Weight', 'Clearcoat'), payload.get('coat_weight', 0.0))
    builders.set_socket_value(builders.principled_socket(bsdf, 'Coat Roughness', 'Clearcoat Roughness'), payload.get('coat_roughness', 0.03))
    builders.set_socket_value(builders.principled_socket(bsdf, 'Sheen Weight', 'Sheen'), payload.get('sheen_weight', 0.0))
    return (bsdf, builders.try_output(bsdf, 'BSDF'))

def _resolve_auto_mode(material, preset_id: str) -> tuple[str, list[str]]:
    meta = layer_preset_meta(preset_id)
    default_mode = str(meta.get('default_mask', 'EDGE') or 'EDGE').upper()
    notes: list[str] = []
    if default_mode == 'EDGE':
        node, usage = _find_usage_node(material, 'curvature', 'cavity')
        if node is not None:
            notes.append(_lt(f'JP: 補助マップ {usage} を優先しました。 / EN: Preferred advisory map: {usage}.'))
            return (usage.upper(), notes)
    if default_mode == 'UPWARD':
        for usage in ('thickness', 'position', 'world_normal'):
            node, resolved = _find_usage_node(material, usage)
            if node is not None:
                if usage == 'thickness':
                    notes.append(_lt('JP: 補助マップ thickness を優先しました。 / EN: Preferred advisory map: thickness.'))
                    return ('THICKNESS', notes)
                if usage == 'position':
                    notes.append(_lt('JP: 補助マップ position を優先しました。 / EN: Preferred advisory map: position.'))
                    return ('POSITION', notes)
                if usage == 'world_normal':
                    notes.append(_lt('JP: 補助マップ world_normal を優先しました。 / EN: Preferred advisory map: world_normal.'))
                    return ('WORLD_NORMAL', notes)
    if default_mode == 'FACING':
        return ('FACING', notes)
    return (default_mode, notes)

def build_mask_source(material, preset_id: str, mask_mode: str='AUTO', noise_scale: float=8.0, contrast: float=1.0, x: float=-1540, y: float=320) -> dict:
    nt = getattr(material, 'node_tree', None)
    if nt is None:
        return {'socket': None, 'mode': '', 'source': '', 'notes': [_lt('JP: ノードツリーがありません。 / EN: No node tree available.')]}
    requested = str(mask_mode or 'AUTO').strip().upper() or 'AUTO'
    notes: list[str] = []
    actual = requested
    if requested == 'AUTO':
        actual, auto_notes = _resolve_auto_mode(material, preset_id)
        notes.extend(auto_notes)
    advisory_map = {'CURVATURE': ('curvature', 'EDGE'), 'CAVITY': ('cavity', 'EDGE'), 'THICKNESS': ('thickness', 'UPWARD'), 'WORLD_NORMAL': ('world_normal', 'UPWARD'), 'POSITION': ('position', 'UPWARD')}
    if actual in advisory_map:
        usage, fallback = advisory_map[actual]
        node, resolved_usage = _find_usage_node(material, usage)
        if node is not None:
            source = _channel_socket_from_usage_node(nt, node, resolved_usage or usage, x + 20, y + 200, f'{actual.title()} Source')
            value = _apply_contrast(nt, source, contrast, x + 220, y + 200, f'{actual.title()} Contrast')
            return {'socket': value, 'mode': actual, 'source': resolved_usage or usage, 'notes': notes}
        notes.append(_lt(f'JP: {usage} マップが見つからないため {fallback} にフォールバックしました。 / EN: {usage} map was not found, so the mask fell back to {fallback}.'))
        actual = fallback
    if actual == 'IMAGE_ALPHA':
        node, alpha = _first_alpha_capable_image(material)
        if alpha is not None:
            value = _apply_contrast(nt, alpha, contrast, x + 220, y + 200, 'Image Alpha Contrast')
            return {'socket': value, 'mode': actual, 'source': getattr(node, 'name', 'image_alpha'), 'notes': notes}
        notes.append(_lt('JP: 使える画像アルファが見つからないため NOISE にフォールバックしました。 / EN: No usable image alpha was found, so the mask fell back to NOISE.'))
        actual = 'NOISE'
    vector_socket = None
    if actual in {'UPWARD', 'EDGE', 'NOISE', 'FACING'}:
        _, mapping = builders.add_mapping_chain(nt, x, y - 140, f'{actual.title()} Mask')
        _set_mapping_uniform_scale(mapping, noise_scale)
        vector_socket = builders.try_output(mapping, 'Vector')
    if actual == 'UPWARD':
        source = builders.add_upward_mask(nt, x + 460, y + 120, f"{layer_preset_meta(preset_id)['label_en']} Upward", noise_vector=vector_socket, noise_scale=max(1.0, float(noise_scale)), noise_strength=0.2, range_pos=_ramp_positions(contrast))
        source = _value_socket_from_source(nt, source, x + 880, y + 120, 'Upward Value')
        return {'socket': source, 'mode': actual, 'source': 'upward', 'notes': notes}
    if actual == 'EDGE':
        source = builders.add_edge_mask(nt, x + 420, y + 80, f"{layer_preset_meta(preset_id)['label_en']} Edge", noise_vector=vector_socket, noise_scale=max(6.0, float(noise_scale) * 2.0), edge_strength=1.0)
        source = _apply_contrast(nt, source, contrast, x + 840, y + 80, 'Edge Contrast')
        return {'socket': source, 'mode': actual, 'source': 'edge', 'notes': notes}
    if actual == 'FACING':
        source = _facing_mask(nt, x + 440, y + 60, layer_preset_meta(preset_id)['label_en'], contrast)
        return {'socket': source, 'mode': actual, 'source': 'facing', 'notes': notes}
    if actual == 'WHITE':
        source = _white_mask(nt, x + 420, y + 20, 'Solid White Mask')
        return {'socket': source, 'mode': actual, 'source': 'white', 'notes': notes}
    source = _noise_mask(nt, vector_socket, x + 440, y + 20, layer_preset_meta(preset_id)['label_en'], max(1.0, float(noise_scale)), contrast)
    return {'socket': source, 'mode': actual if actual else 'NOISE', 'source': 'noise', 'notes': notes}

def apply_smart_layer(material, preset_id: str, mask_mode: str='AUTO', strength: float=0.65, noise_scale: float=8.0, contrast: float=1.0) -> dict:
    if material is None:
        raise AddonError(_lt('No material provided.', 'マテリアルが指定されていません。'))
    material.use_nodes = True
    nt = material.node_tree
    if nt is None:
        raise AddonError(_lt('Material has no node tree.', 'マテリアルにノードツリーがありません。'))
    before_nodes = len(getattr(nt, 'nodes', []))
    out = core.ensure_output_node(nt, engine=core.render_engine())
    surface_input = core.socket_by_name(getattr(out, 'inputs', []), 'Surface') if out is not None else None
    if surface_input is None:
        raise AddonError(_lt('Material Output surface input was not found.', 'マテリアル出力のサーフェス入力が見つかりません。'))
    previous_socket = None
    previous_link = None
    if getattr(surface_input, 'is_linked', False):
        try:
            previous_link = surface_input.links[0]
            previous_socket = previous_link.from_socket
        except Exception:
            previous_socket = None
            previous_link = None
    if previous_socket is None:
        base_bsdf = core.first_principled_on_output_path(material, engine=core.render_engine())
        if base_bsdf is None:
            base_bsdf = builders.create_node(nt, 'ShaderNodeBsdfPrincipled', -220, -120, 'Base Principled')
        previous_socket = builders.try_output(base_bsdf, 'BSDF')
    overlay_bsdf, overlay_socket = _build_overlay_principled(nt, preset_id, getattr(out, 'location', (320, 0))[0] - 520, getattr(out, 'location', (320, 0))[1] - 220)
    mask = build_mask_source(material, preset_id, mask_mode=mask_mode, noise_scale=noise_scale, contrast=contrast, x=getattr(out, 'location', (320, 0))[0] - 1500, y=getattr(out, 'location', (320, 0))[1] + 260)
    fac_source = mask.get('socket')
    fac_source = _value_socket_from_source(nt, fac_source, getattr(out, 'location', (320, 0))[0] - 760, getattr(out, 'location', (320, 0))[1] - 420, 'Layer Factor')
    if fac_source is None:
        fac_source = _white_mask(nt, getattr(out, 'location', (320, 0))[0] - 980, getattr(out, 'location', (320, 0))[1] - 420, 'Fallback White')
    strength_node = builders.new_value(nt, getattr(out, 'location', (320, 0))[0] - 760, getattr(out, 'location', (320, 0))[1] - 560, float(strength), f"{layer_preset_meta(preset_id)['label_en']} Strength")
    fac_mul = builders.new_math(nt, getattr(out, 'location', (320, 0))[0] - 520, getattr(out, 'location', (320, 0))[1] - 500, 'MULTIPLY', f"{layer_preset_meta(preset_id)['label_en']} Factor")
    builders.link(nt, fac_source, builders.try_input(fac_mul, 0))
    builders.link(nt, builders.try_output(strength_node, 'Value'), builders.try_input(fac_mul, 1))
    mix = builders.create_node(nt, 'ShaderNodeMixShader', getattr(out, 'location', (320, 0))[0] - 240, getattr(out, 'location', (320, 0))[1], f"{layer_preset_meta(preset_id)['label_en']} Mix")
    try:
        if previous_link is not None:
            nt.links.remove(previous_link)
    except Exception:
        pass
    builders.link(nt, builders.try_output(fac_mul, 'Value'), mix.inputs[0])
    builders.link(nt, previous_socket, mix.inputs[1])
    builders.link(nt, overlay_socket, mix.inputs[2])
    builders.link(nt, mix.outputs[0], surface_input)
    tags = list(core.get_material_tags(material) or [])
    for tag in ['Layered', 'Smart Layer', layer_preset_meta(preset_id)['label_en']]:
        if tag not in tags:
            tags.append(tag)
    core.set_managed_metadata_only(material, note_en='Managed material with Smart Shader smart layers.', note_ja=_lt('スマートシェーダーのスマートレイヤーで管理されているマテリアルです。'), params=core.get_material_params(material) or core.approx_params_from_material(material), tags=tags)
    _append_layer_stack(material, {'preset': preset_id, 'mask_mode': mask.get('mode') or mask_mode, 'source': mask.get('source') or '', 'strength': float(strength), 'noise_scale': float(noise_scale), 'contrast': float(contrast)})
    return {'created_nodes': max(0, len(getattr(nt, 'nodes', [])) - before_nodes), 'mask_mode': mask.get('mode') or mask_mode, 'mask_source': mask.get('source') or '', 'notes': mask.get('notes') or [], 'label_en': layer_preset_meta(preset_id)['label_en'], 'label_ja': layer_preset_meta(preset_id)['label_ja']}

def add_mask_utilities(material, noise_scale: float=8.0, contrast: float=1.0) -> dict:
    if material is None:
        raise AddonError(_lt('No material provided.', 'マテリアルが指定されていません。'))
    material.use_nodes = True
    nt = material.node_tree
    if nt is None:
        raise AddonError(_lt('Material has no node tree.', 'マテリアルにノードツリーがありません。'))
    before_nodes = len(getattr(nt, 'nodes', []))
    locations = [getattr(node, 'location', (0.0, 0.0)) for node in getattr(nt, 'nodes', [])]
    min_x = min((float(loc[0]) for loc in locations), default=0.0)
    max_y = max((float(loc[1]) for loc in locations), default=0.0)
    start_x = min_x - 1180.0
    start_y = max_y + 120.0
    _, mapping = builders.add_mapping_chain(nt, start_x, start_y - 240, 'SSS Mask Utility')
    _set_mapping_uniform_scale(mapping, noise_scale)
    vector_socket = builders.try_output(mapping, 'Vector')
    builders.add_upward_mask(nt, start_x + 420, start_y + 220, 'SSS Upward Utility', noise_vector=vector_socket, noise_scale=max(1.0, float(noise_scale)), range_pos=_ramp_positions(contrast))
    builders.add_edge_mask(nt, start_x + 400, start_y - 40, 'SSS Edge Utility', noise_vector=vector_socket, noise_scale=max(6.0, float(noise_scale) * 2.0), edge_strength=1.0)
    _facing_mask(nt, start_x + 420, start_y - 320, 'SSS', contrast)
    _noise_mask(nt, vector_socket, start_x + 420, start_y - 600, 'SSS', max(1.0, float(noise_scale)), contrast)
    _white_mask(nt, start_x + 420, start_y - 820, 'SSS White Utility')
    advisory_found: list[str] = []
    for usage in ('curvature', 'cavity', 'thickness', 'world_normal', 'position'):
        node, _ = _find_usage_node(material, usage)
        if node is not None:
            advisory_found.append(usage)
    return {'created_nodes': max(0, len(getattr(nt, 'nodes', [])) - before_nodes), 'advisory_maps': advisory_found, 'notes': [_lt('JP: 各ユーティリティは未接続で追加されるため、既存の見た目を壊さずに手動利用できます。 / EN: Utilities are added unconnected so you can reuse them manually without altering the current look.')]}
