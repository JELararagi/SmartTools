# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

from . import loader as loader, ui_runtime as ui_runtime


def register() -> None:
    loader.register_all()
    ui_runtime.register()


def unregister() -> None:
    ui_runtime.unregister()
    loader.unregister_all()
