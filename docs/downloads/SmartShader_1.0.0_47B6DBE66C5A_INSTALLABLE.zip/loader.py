# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import importlib
import platform
from pathlib import Path
from typing import Any

import bpy

from . import feature_toggle as _feature_toggle
from . import registry, storage
from . import tool_preferences as tool_prefs
from .translation import loc_text as _lt

_SUITE_ID = 'smart_shader_suite'
_OWNER_UUID = '3f6d8d7f-671d-4ff1-bf32-bf15518208aa'
_GENERATION = '5.18.230'
_RECORDS: list[dict[str, Any]] = []


def clear_records() -> None:
    _RECORDS.clear()


def get_records() -> list[dict[str, Any]]:
    return list(_RECORDS)


def _platform_supported(outer_zip: str) -> bool:
    text = str(outer_zip or '').lower()
    system = platform.system().lower()
    machine = platform.machine().lower()
    if 'windows-x64' in text:
        return system == 'windows' and machine in {'amd64', 'x86_64'}
    if 'linux-x64' in text:
        return system == 'linux' and machine in {'amd64', 'x86_64'}
    if 'macos-arm64' in text:
        return system == 'darwin' and machine in {'arm64', 'aarch64'}
    if 'macos-x64' in text:
        return system == 'darwin' and machine in {'amd64', 'x86_64'}
    return True


def _module_name_for_spec(spec: dict[str, Any]) -> str:
    folder = str(spec.get('folder') or spec.get('alias') or '').strip()
    package = str(__package__ or '').strip()
    return f'{package}.{folder}' if package and folder else folder


def _spec_init_path(spec: dict[str, Any]) -> Path:
    src_dir = Path(str(spec.get('src_dir') or ''))
    init_relpath = Path(str(spec.get('init_relpath') or '__init__.py'))
    return (src_dir / init_relpath).resolve()


def _load_module_from_spec(spec: dict[str, Any]):
    init_path = _spec_init_path(spec)
    if not init_path.exists():
        raise FileNotFoundError(f'Missing init file: {init_path}')
    module_name = _module_name_for_spec(spec)
    if not module_name:
        raise ImportError(_lt('Integrated module name is empty.', '統合モジュール名が空です。'))
    # Import through the normal extension package.  Modules are never purged by
    # prefix and no shared Blender API is monkeypatched during registration.
    return importlib.import_module(module_name)


def _class_has_own_bl_rna(cls: type) -> bool:
    try:
        rna = vars(cls).get('bl_rna') or getattr(cls, 'bl_rna', None)
        identifier = str(getattr(rna, 'identifier', '') or '')
        inherited = {'Operator', 'Panel', 'PropertyGroup', 'Menu', 'UIList', 'AddonPreferences', 'NodeCustomGroup', 'ShaderNodeCustomGroup', 'CompositorNodeCustomGroup', 'GeometryNodeCustomGroup'}
        return bool(identifier and identifier not in inherited)
    except Exception:
        return False

def _register_class_exact(cls: type, record: dict[str, Any]) -> None:
    if not isinstance(cls, type):
        raise TypeError('RNA class must be a Python type')
    registered = record.setdefault('registered_classes', [])
    if cls in registered and _class_has_own_bl_rna(cls):
        return
    if _class_has_own_bl_rna(cls):
        raise RuntimeError(f'RNA class is already registered outside this generation ledger: {getattr(cls, "__name__", "<unnamed>")}')
    try:
        bpy.utils.register_class(cls)
    except Exception:
        if cls in registered and _class_has_own_bl_rna(cls):
            return
        raise
    if not _class_has_own_bl_rna(cls):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        raise RuntimeError(f'RNA class registration did not publish class bl_rna: {getattr(cls, "__name__", "<unnamed>")}')
    if cls not in registered:
        registered.append(cls)

def _unregister_class_exact(cls: type) -> None:
    if _class_has_own_bl_rna(cls):
        bpy.utils.unregister_class(cls)


def _is_subclass(cls: type, base_name: str) -> bool:
    base = getattr(bpy.types, base_name, None)
    try:
        return base is not None and isinstance(cls, type) and issubclass(cls, base)
    except Exception:
        return False


def _categorize_classes(classes) -> tuple[list[type], list[type], list[type], list[type]]:
    panels: list[type] = []
    operators: list[type] = []
    menus: list[type] = []
    preferences: list[type] = []
    for cls in tuple(classes or ()):
        if _is_subclass(cls, 'Panel'):
            panels.append(cls)
        elif _is_subclass(cls, 'Operator'):
            operators.append(cls)
        elif _is_subclass(cls, 'Menu'):
            menus.append(cls)
        elif _is_subclass(cls, 'AddonPreferences'):
            preferences.append(cls)
    return panels, operators, menus, preferences


def _rna_property(owner, name: str):
    try:
        props = getattr(getattr(owner, 'bl_rna', None), 'properties', None)
        return props.get(name) if props is not None else None
    except Exception:
        return None


def _property_fixed_type_identifier(owner, name: str) -> str:
    prop = _rna_property(owner, name)
    fixed = getattr(prop, 'fixed_type', None) if prop is not None else None
    return str(getattr(fixed, 'identifier', '') or '')


def _expected_fixed_type_identifier(fixed_type) -> str:
    if fixed_type is None:
        return ''
    try:
        rna = vars(fixed_type).get('bl_rna')
        ident = str(getattr(rna, 'identifier', '') or '') if rna is not None else ''
        if ident:
            return ident
    except Exception:
        pass
    return str(getattr(fixed_type, '__name__', '') or '')


def _register_property_exact(record: dict[str, Any], owner, name: str, value, *, fixed_type=None) -> None:
    if hasattr(owner, name):
        raise RuntimeError(f'RNA property collision kept unchanged: {owner.__name__}.{name}')
    setattr(owner, name, value)
    if not hasattr(owner, name):
        raise RuntimeError(f'RNA property registration failed: {owner.__name__}.{name}')
    record.setdefault('registered_properties', []).append((owner, name, fixed_type))


def _unregister_properties_exact(record: dict[str, Any]) -> None:
    for owner, name, fixed_type in reversed(tuple(record.get('registered_properties') or ())):
        try:
            if not hasattr(owner, name):
                continue
            if fixed_type is not None:
                actual_identifier = _property_fixed_type_identifier(owner, name)
                expected_identifier = _expected_fixed_type_identifier(fixed_type)
                if actual_identifier and expected_identifier and actual_identifier != expected_identifier:
                    continue
            delattr(owner, name)
        except Exception:
            pass
    record['registered_properties'] = []


def _module_classes(module) -> tuple[type, ...]:
    values = getattr(module, 'classes', getattr(module, 'CLASSES', ()))
    return tuple(cls for cls in tuple(values or ()) if isinstance(cls, type))


def _register_feature_surface(module, alias: str, record: dict[str, Any]) -> None:
    classes = _module_classes(module)
    panels, operators, menus, preferences = _categorize_classes(classes)
    record['panels'] = panels
    record['operators'] = operators
    record['menus'] = menus
    record['preferences'] = preferences

    # Suite-owned N-panel roots provide the complete UI.  Integrated source
    # Panels and AddonPreferences remain unregistered; all functional RNA types,
    # operators, menus and custom node classes retain their public identities.
    for cls in classes:
        if cls in panels or cls in preferences:
            continue
        _register_class_exact(cls, record)

    if alias == 'material_library':
        empty_group = getattr(module, 'EmptyGroup')
        matlib_props = getattr(module, 'matlibProperties')
        collection_factory = getattr(module, 'CollectionProperty')
        pointer_factory = getattr(module, 'PointerProperty')
        _register_property_exact(
            record, bpy.types.Scene, 'matlib_categories',
            collection_factory(type=empty_group), fixed_type=empty_group,
        )
        _register_property_exact(
            record, bpy.types.Scene, 'matlib',
            pointer_factory(type=matlib_props), fixed_type=matlib_props,
        )
        unregister_owned_callbacks = getattr(module, 'unregister_owned_callbacks', None)
        if callable(unregister_owned_callbacks):
            record.setdefault('unregister_callbacks', []).append(unregister_owned_callbacks)
        scene = getattr(getattr(bpy, 'context', None), 'scene', None)
        owner = getattr(scene, 'matlib', None) if scene is not None else None
        apply_ui = getattr(module, 'apply_matlib_ui_settings', None)
        if owner is not None and callable(apply_ui):
            apply_ui(owner)
        sync_resident = getattr(module, '_sync_matlib_load_post_handler', None)
        if callable(sync_resident):
            sync_resident(getattr(bpy, 'context', None))
    elif alias == 'pbr_lookdev':
        props_cls = getattr(module, 'PBR_MaterialProps')
        state_cls = getattr(module, 'PBR_UISectionState')
        pointer_factory = getattr(module, 'PointerProperty')
        string_factory = getattr(module, 'StringProperty')
        collection_factory = getattr(module, 'CollectionProperty')
        _register_property_exact(
            record, bpy.types.Material, 'pbr_properties',
            pointer_factory(type=props_cls), fixed_type=props_cls,
        )
        _register_property_exact(
            record, bpy.types.WindowManager, 'pbr_ui_state',
            string_factory(default='{}'), fixed_type=None,
        )
        _register_property_exact(
            record, bpy.types.WindowManager, 'pbr_ui_sections',
            collection_factory(type=state_cls, options={'SKIP_SAVE'}), fixed_type=state_cls,
        )
        register_handlers = getattr(module, '_pbr_register_ui_state_handlers', None)
        unregister_handlers = getattr(module, '_pbr_unregister_ui_state_handlers', None)
        if callable(register_handlers):
            register_handlers()
            if callable(unregister_handlers):
                record.setdefault('unregister_callbacks', []).append(unregister_handlers)
        apply_ui = getattr(module, '_pbr_apply_ui_state', None)
        if callable(apply_ui):
            apply_ui(getattr(bpy, 'context', None))


def _rollback_record(record: dict[str, Any]) -> None:
    for callback in reversed(tuple(record.get('unregister_callbacks') or ())):
        try:
            callback()
        except Exception:
            pass
    record['unregister_callbacks'] = []
    _unregister_properties_exact(record)
    for cls in reversed(tuple(record.get('registered_classes') or ())):
        try:
            _unregister_class_exact(cls)
        except Exception:
            pass
    record['registered_classes'] = []


def _status_for_spec(spec: dict[str, Any]) -> str:
    alias = str((spec or {}).get('alias') or '').strip()
    if alias and not tool_prefs.tool_enabled(alias, default=True):
        return 'disabled_by_user'
    if not _platform_supported(str((spec or {}).get('outer_zip') or '')):
        return 'unsupported_platform'
    return 'ready'


def _reset_record(record: dict[str, Any], *, clear_error: bool = True) -> dict[str, Any]:
    spec = dict(record.get('spec') or {})
    record.update({
        'module': None,
        'registered_classes': [],
        'registered_properties': [],
        'unregister_callbacks': [],
        'proxy_panels': [],
        'panels': [],
        'operators': [],
        'menus': [],
        'preferences': [],
        'owner_uuid': _OWNER_UUID,
        'suite_id': _SUITE_ID,
        'generation': _GENERATION,
    })
    if clear_error:
        record['error'] = ''
    record['status'] = _status_for_spec(spec)
    return record


def _new_record(spec: dict[str, Any]) -> dict[str, Any]:
    return _reset_record({'spec': spec, 'error': ''})


def initialize_records(force: bool = False) -> list[dict[str, Any]]:
    if _RECORDS and not force:
        return get_records()
    if force:
        unregister_all()
    clear_records()
    for spec in registry.build_specs(force=force):
        _RECORDS.append(_new_record(spec))
    return get_records()


def record_for_alias(alias: str) -> dict[str, Any] | None:
    token = str(alias or '').strip()
    if not token:
        return None
    if not _RECORDS:
        initialize_records(force=False)
    for record in _RECORDS:
        if str((record.get('spec') or {}).get('alias') or '').strip() == token:
            return record
    return None


def _load_record(record: dict[str, Any]) -> dict[str, Any]:
    status = str(record.get('status') or '')
    if status == 'loaded' or status in {'disabled_by_user', 'unsupported_platform'}:
        return record
    spec = dict(record.get('spec') or {})
    alias = str(spec.get('alias') or '').strip()
    record['error'] = ''
    record['registered_classes'] = []
    record['registered_properties'] = []
    record['unregister_callbacks'] = []
    module = None
    guarded = False
    try:
        storage.begin_registration_write_guard()
        guarded = True
    except Exception:
        pass
    try:
        module = _load_module_from_spec(spec)
        record['module'] = module
        _register_feature_surface(module, alias, record)
        record['status'] = 'loaded'
    except Exception as exc:
        _rollback_record(record)
        record['module'] = None
        record['status'] = 'failed'
        record['error'] = str(exc)[:1000]
    finally:
        if guarded:
            try:
                storage.end_registration_write_guard()
            except Exception:
                pass
    return record


def load_addon(alias: str) -> dict[str, Any] | None:
    record = record_for_alias(alias)
    return _load_record(record) if record is not None else None


def unload_addon(alias: str, *, clear_error: bool = True) -> dict[str, Any] | None:
    record = record_for_alias(alias)
    if record is None:
        return None
    _rollback_record(record)
    return _reset_record(record, clear_error=clear_error)


def refresh_record_statuses() -> list[dict[str, Any]]:
    initialize_records(force=False)
    for record in tuple(_RECORDS):
        alias = str((record.get('spec') or {}).get('alias') or '')
        if str(record.get('status') or '') == 'loaded':
            if alias and not tool_prefs.tool_enabled(alias, default=True):
                unload_addon(alias)
        else:
            record['status'] = _status_for_spec(record.get('spec') or {})
    return get_records()


def register_all(*, load_enabled: bool = False) -> list[dict[str, Any]]:
    _feature_toggle.register_ui()
    initialize_records(force=False)
    if load_enabled:
        for record in tuple(_RECORDS):
            if str(record.get('status') or '') == 'ready':
                load_addon(str((record.get('spec') or {}).get('alias') or ''))
    else:
        refresh_record_statuses()
    return get_records()


def unregister_all() -> None:
    _feature_toggle.unregister_all()
    for record in reversed(tuple(_RECORDS)):
        _rollback_record(record)
        record['module'] = None
    clear_records()
    registry.clear_cache()
