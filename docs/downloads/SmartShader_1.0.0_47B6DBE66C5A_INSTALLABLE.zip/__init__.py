# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Smart Shader Suite Blender Extension bootstrap."""

from __future__ import annotations

import importlib

import bpy
from bpy.app.handlers import persistent

__addon_enabled__ = False
__addon_persistent__ = False

bl_info = {
    "name": 'Smart Shader',
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "N-panel > Smart Shader",
    "description": "Smart Shader exposes shader, material, Smart Shader Smart, PBR lookdev, and DCC-style integrated tools in supported Blender editor N-panels.",
    "category": "Smart Shader",
}

_SUITE_ID = "smart_shader_suite"
_OWNER_UUID = "3f6d8d7f-671d-4ff1-bf32-bf15518208aa"
_GENERATION = "5.18.271"
_OWNER_KEY = "SMART_SHADER_SUITE_RUNTIME_OWNER_V2"
_TOKEN = object()
_PACKAGE = str(__package__ or __name__ or "smart_shader_suite")
_REGISTERED = False
_REGISTERED_PARTS: list[tuple[str, object]] = []
_LAST_POST_REGISTER_DRIVER_REFRESH = None
_POST_REGISTER_READY_ATTEMPTS = 0
_POST_REGISTER_READY_MAX_ATTEMPTS = 8


def _module(name: str):
    return importlib.import_module(f".{name}", _PACKAGE)


def _namespace():
    try:
        return bpy.app.driver_namespace
    except Exception:
        return None


def _owner_record():
    namespace = _namespace()
    try:
        value = namespace.get(_OWNER_KEY) if namespace is not None else None
    except Exception:
        value = None
    return value if isinstance(value, dict) else None


def _install_owner_record() -> None:
    namespace = _namespace()
    if namespace is None:
        return
    namespace[_OWNER_KEY] = {
        "suite_id": _SUITE_ID,
        "owner_uuid": _OWNER_UUID,
        "generation": _GENERATION,
        "token": _TOKEN,
        "cleanup": unregister,
    }


def _clear_owner_record() -> None:
    namespace = _namespace()
    if namespace is None:
        return
    try:
        record = namespace.get(_OWNER_KEY)
        if isinstance(record, dict) and record.get("token") is _TOKEN:
            namespace.pop(_OWNER_KEY, None)
    except Exception:
        pass


def _retire_exact_previous_generation() -> None:
    record = _owner_record()
    if not record or record.get("token") is _TOKEN:
        return
    if record.get("suite_id") != _SUITE_ID or record.get("owner_uuid") != _OWNER_UUID:
        raise RuntimeError("Smart Shader runtime owner collision")
    cleanup = record.get("cleanup")
    if not callable(cleanup):
        raise RuntimeError("Previous Smart Shader generation has no exact cleanup callback")
    cleanup()
    remaining = _owner_record()
    if remaining is not None and remaining.get("token") is record.get("token"):
        raise RuntimeError("Previous Smart Shader generation did not release ownership")


def ensure_runtime_initialized(context=None, *args, force: bool = False, **kwargs):
    del context, args, kwargs
    if force or not _REGISTERED:
        register()
    return bool(_REGISTERED)


def _post_register_smart_toon_driver_refresh():
    """Restore portable state only after RNA/context is ready, then migrate drivers."""
    global _LAST_POST_REGISTER_DRIVER_REFRESH, _POST_REGISTER_READY_ATTEMPTS
    storage = _module("storage")
    if not _REGISTERED or not __addon_enabled__:
        storage.end_registration_write_guard()
        return None
    _POST_REGISTER_READY_ATTEMPTS += 1
    context = getattr(bpy, "context", None)
    ready = context is not None and getattr(context, "window_manager", None) is not None and getattr(context, "scene", None) is not None
    if not ready:
        if _POST_REGISTER_READY_ATTEMPTS < _POST_REGISTER_READY_MAX_ATTEMPTS:
            return 0.05
        _LAST_POST_REGISTER_DRIVER_REFRESH = {"error": "READY_CONTEXT_UNAVAILABLE"}
        storage.end_registration_write_guard()
        return None
    try:
        preferences = _module("preferences")
        preferences.apply_all_npanel_settings(context, include_smart_toon_graphs=False)
    except Exception as exc:
        _LAST_POST_REGISTER_DRIVER_REFRESH = {"error": f"SETTINGS_RESTORE:{type(exc).__name__}: {exc}"}
    try:
        smart_toon = _module("smart_toon")
        _LAST_POST_REGISTER_DRIVER_REFRESH = smart_toon.refresh_standard_light_drivers_on_load_fast(
            context
        )
    except Exception as exc:
        _LAST_POST_REGISTER_DRIVER_REFRESH = {
            "error": f"{type(exc).__name__}: {exc}",
        }
        record = getattr(smart_toon, "_smart_toon_v1208_record_diagnostic", None)
        if callable(record):
            record(
                "STANDARD_LIGHT_DRIVER:REGISTER_REFRESH_FAILED",
                _LAST_POST_REGISTER_DRIVER_REFRESH["error"],
            )
    finally:
        storage.end_registration_write_guard()
    return None


def _schedule_post_register_smart_toon_driver_refresh() -> bool:
    global _POST_REGISTER_READY_ATTEMPTS
    _POST_REGISTER_READY_ATTEMPTS = 0
    timers = getattr(getattr(bpy, "app", None), "timers", None)
    if timers is None:
        return False
    try:
        if not timers.is_registered(_post_register_smart_toon_driver_refresh):
            timers.register(_post_register_smart_toon_driver_refresh, first_interval=0.0, persistent=False)
        return True
    except Exception:
        return False


def _cancel_post_register_smart_toon_driver_refresh() -> None:
    timers = getattr(getattr(bpy, "app", None), "timers", None)
    if timers is None:
        return
    try:
        if timers.is_registered(_post_register_smart_toon_driver_refresh):
            timers.unregister(_post_register_smart_toon_driver_refresh)
    except Exception:
        pass
    try:
        _module("storage").end_registration_write_guard()
    except Exception:
        pass


@persistent
def _smart_toon_load_post(_unused) -> None:
    """Refresh saved Smart Toon light drivers after every blend-file load."""
    if _REGISTERED and __addon_enabled__:
        _schedule_post_register_smart_toon_driver_refresh()


def _remove_smart_toon_load_post_handlers() -> None:
    handlers = getattr(getattr(bpy.app, "handlers", None), "load_post", None)
    if handlers is None:
        return
    for handler in tuple(handlers):
        if (
            getattr(handler, "__module__", "") == __name__
            and getattr(handler, "__name__", "") == _smart_toon_load_post.__name__
        ):
            try:
                handlers.remove(handler)
            except Exception:
                pass


def _install_smart_toon_load_post_handler() -> None:
    handlers = getattr(getattr(bpy.app, "handlers", None), "load_post", None)
    if handlers is None:
        return
    _remove_smart_toon_load_post_handlers()
    try:
        handlers.append(_smart_toon_load_post)
    except Exception:
        pass


def register():
    global __addon_enabled__, _REGISTERED
    if _REGISTERED:
        return None
    _retire_exact_previous_generation()
    storage = _module("storage")
    common = _module("common")
    preferences = _module("preferences")
    translation = _module("translation")
    runtime = _module("addon_runtime")
    registered: list[tuple[str, object]] = []
    guarded = False
    guard_handed_off = False
    try:
        storage.begin_registration_write_guard()
        guarded = True
        common.begin_register()
        translation.begin_rna_text_registration()
        preferences.register()
        registered.append(("preferences", preferences))
        runtime.register()
        registered.append(("runtime", runtime))
        common.register()
        registered.append(("common", common))
        # Built last so the table holds the pairs remembered while registering.
        translation.register_translations()
        registered.append(("translation", translation))
        _REGISTERED_PARTS[:] = registered
        _REGISTERED = True
        __addon_enabled__ = True
        _install_owner_record()
        _remove_smart_toon_load_post_handlers()
        guard_handed_off = _schedule_post_register_smart_toon_driver_refresh()
        return None
    except Exception:
        for kind, module in reversed(registered):
            try:
                if kind == "translation":
                    module.unregister_translations()
                else:
                    module.unregister()
            except Exception:
                pass
        _REGISTERED_PARTS.clear()
        _REGISTERED = False
        __addon_enabled__ = False
        _clear_owner_record()
        raise
    finally:
        translation.end_rna_text_registration()
        try:
            common.end_register()
        except Exception:
            pass
        if guarded and not guard_handed_off:
            try:
                storage.end_registration_write_guard()
            except Exception:
                pass


def unregister():
    global __addon_enabled__, _REGISTERED
    record = _owner_record()
    if record is not None and record.get("token") is not _TOKEN:
        return None
    _remove_smart_toon_load_post_handlers()
    _cancel_post_register_smart_toon_driver_refresh()
    for kind, module in reversed(tuple(_REGISTERED_PARTS)):
        try:
            if kind == "translation":
                module.unregister_translations()
            else:
                module.unregister()
        except Exception:
            pass
    _REGISTERED_PARTS.clear()
    _REGISTERED = False
    __addon_enabled__ = False
    _clear_owner_record()
    return None


if __name__ == "__main__":
    register()

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)
