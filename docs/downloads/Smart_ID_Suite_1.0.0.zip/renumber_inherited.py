# SPDX-License-Identifier: GPL-3.0-or-later
"""Independently authored saved renumber operation and its explicit domain adapters."""
from .colors import generated_color
from .library import selected_indices as selected_entry_indices,visible_indices
from .language import tr

def get_settings(scene):return scene.settings
def get_entries(scene):return scene.entries
def visible_entry_indices(scene,context):return visible_indices(scene)
def is_japanese(context):return context.locale.startswith('ja')
def t(key,context):return tr(key,context.locale)

def execute(self, context):
    scene = context.scene
    options = get_settings(scene)
    checked = set(selected_entry_indices(scene))
    displayed = set(visible_entry_indices(scene, context))
    rows = [
        row for index, row in enumerate(get_entries(scene))
        if index in displayed and not row.locked and (not checked or index in checked)
    ]
    count = len(rows)
    start = options.renumber_start
    step = options.renumber_step
    if rows:
        limit = rows[0].bl_rna.properties["id_number"].hard_max
        if start + (count - 1) * step > limit:
            options.last_report = (
                f"番号が上限 {limit} を超えます。開始番号または増分を小さくしてください。"
                if is_japanese(context) else
                f"The last ID would exceed {limit}. Reduce the start number or increment."
            )
            self.report({'WARNING'}, options.last_report)
            return {'CANCELLED'}

    for ordinal, row in enumerate(rows):
        number = start + ordinal * step
        row.id_number = number
        if row.type == 'MAP_CHANNEL':
            bounds = row.bl_rna.properties["map_channel"]
            row.map_channel = min(bounds.hard_max, max(bounds.hard_min, number))
        if options.auto_color:
            row.color = generated_color(number)
    options.last_report = t("report_renumbered_entries", context).format(count=count)
    return {'FINISHED'}
