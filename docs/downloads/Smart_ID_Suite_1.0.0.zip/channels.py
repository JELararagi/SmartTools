# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Original channel operations on a detached state, committed by the service."""
from .data_schema import ContractError
from .model import Channel
from .library import channel_name

CHANNEL_KINDS = frozenset(('MAP_CHANNEL','UV_CHANNEL','COLOR_ATTRIBUTE','GEOMETRY_ATTRIBUTE','WEIGHT_GROUP','UDIM_TILE'))
BUCKET = 'independent_v1'


def metadata(owner):
    value = owner.metadata.get(BUCKET, {})
    return value if isinstance(value, dict) else {}


def edit_metadata(owner):
    if BUCKET in owner.metadata and not isinstance(owner.metadata[BUCKET], dict):
        raise ContractError('metadata_conflict')
    return owner.metadata.setdefault(BUCKET, {})


def check_editable(obj, mesh=False):
    if obj.readonly or (mesh and obj.mesh and obj.mesh.readonly):
        raise ContractError('read_only', name=obj.name)


def preflight_mesh_scope(state, keys, entries):
    if not any(row.type in CHANNEL_KINDS or row.type == 'MATERIAL_ID' for row in entries): return
    wanted = set(keys)
    meshes = {state.objects[key].mesh.key for key in keys if state.objects[key].mesh is not None}
    for key,obj in state.objects.items():
        if key not in wanted and obj.mesh is not None and obj.mesh.key in meshes:
            raise ContractError('shared_mesh_scope', name=obj.name)


def bucket_for(mesh, kind):
    if kind in ('MAP_CHANNEL','UV_CHANNEL'): return mesh.uv
    if kind == 'COLOR_ATTRIBUTE': return mesh.colors
    if kind == 'GEOMETRY_ATTRIBUTE': return mesh.attributes
    return None


def ensure_channel(obj, entry, assign_weights=False):
    if obj.kind != 'MESH' or obj.mesh is None: return False
    check_editable(obj, mesh=True)
    mesh = obj.mesh
    name = channel_name(entry)
    if not name: raise ContractError('empty_channel')
    if entry.type == 'UDIM_TILE':
        edit_metadata(mesh)['udim_tile'] = entry.udim_tile
        return True
    if entry.type == 'WEIGHT_GROUP':
        group = obj.groups.setdefault(name, {})
        obj.active_group = name
        if assign_weights:
            for index,vertex in enumerate(mesh.vertices):
                if not vertex.hidden and (obj.mode != 'EDIT' or vertex.selected): group[index] = 1.0
        return True
    bucket = bucket_for(mesh, entry.type)
    if bucket is None: return False
    for other in (mesh.uv,mesh.colors,mesh.attributes):
        if other is not bucket and name in other: raise ContractError('channel_name_conflict', name=name)
    if name.startswith('.') or name == 'position': raise ContractError('protected_data', name=name)
    if name not in bucket:
        if entry.type in ('MAP_CHANNEL','UV_CHANNEL'):
            bucket[name] = Channel(name, 'FLOAT2', 'CORNER')
        elif entry.type == 'COLOR_ATTRIBUTE':
            domain = entry.attribute_domain if entry.attribute_domain in ('POINT','CORNER') else 'CORNER'
            bucket[name] = Channel(name, 'BYTE_COLOR', domain, fill=(1.0,1.0,1.0,1.0))
        else:
            bucket[name] = Channel(name, entry.attribute_type, entry.attribute_domain)
    elif bucket[name].protected:
        raise ContractError('protected_data', name=name)
    for layer in bucket.values(): layer.active = layer.name == name
    if entry.type == 'MAP_CHANNEL':
        mapping = edit_metadata(mesh).setdefault('map_channels', {})
        if not isinstance(mapping,dict): raise ContractError('metadata_conflict')
        mapping[name] = entry.map_channel
    return True


def delete_channel(obj, entry, selected_weights_only=False):
    if obj.kind != 'MESH' or obj.mesh is None: return False
    check_editable(obj, mesh=True)
    mesh=obj.mesh; name=channel_name(entry)
    if entry.type == 'UDIM_TILE':
        if metadata(mesh).get('udim_tile') == entry.udim_tile:
            edit_metadata(mesh).pop('udim_tile',None)
            return True
        return False
    if entry.type == 'WEIGHT_GROUP':
        if name not in obj.groups: return False
        if selected_weights_only and obj.mode == 'EDIT':
            for index,vertex in enumerate(mesh.vertices):
                if vertex.selected and not vertex.hidden: obj.groups[name].pop(index,None)
        else:
            del obj.groups[name]
            obj.group_origins.pop(name,None)
            if obj.active_group == name: obj.active_group = ''
        return True
    bucket=bucket_for(mesh,entry.type)
    if bucket is None or name not in bucket: return False
    if bucket[name].protected or name.startswith('.') or name == 'position':
        raise ContractError('protected_data',name=name)
    del bucket[name]
    if bucket and not any(channel.active for channel in bucket.values()): next(iter(bucket.values())).active=True
    mapping=metadata(mesh).get('map_channels',{})
    if isinstance(mapping,dict) and name in mapping: mapping.pop(name)
    return True


def rename_channel(obj, kind, old, new):
    check_editable(obj,mesh=True)
    if not new.strip(): raise ContractError('empty_channel')
    if kind == 'WEIGHT_GROUP':
        if old not in obj.groups: raise ContractError('stale_inspector')
        if new != old and new in obj.groups: raise ContractError('channel_name_conflict',name=new)
        group=obj.groups.pop(old); obj.groups[new]=group
        origin=obj.group_origins.pop(old,old); obj.group_origins[new]=origin
        if obj.active_group == old: obj.active_group=new
        return
    bucket=bucket_for(obj.mesh,kind)
    if bucket is None or old not in bucket: raise ContractError('stale_inspector')
    layer=bucket[old]
    if layer.protected or old.startswith('.') or old == 'position': raise ContractError('protected_data',name=old)
    for other in (obj.mesh.uv,obj.mesh.colors,obj.mesh.attributes):
        if new in other and not (other is bucket and new == old): raise ContractError('channel_name_conflict',name=new)
    if new.startswith('.') or new == 'position': raise ContractError('protected_data',name=new)
    del bucket[old]; layer.name=new; bucket[new]=layer
    mapping=metadata(obj.mesh).get('map_channels',{})
    if isinstance(mapping,dict) and old in mapping: mapping[new]=mapping.pop(old)
