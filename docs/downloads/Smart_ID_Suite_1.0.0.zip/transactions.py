# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Reversible mutation plans. Validation belongs before commit."""
from .data_schema import ContractError


class MutationPlan:
    def __init__(self):
        self.steps = []
        self.committed = False

    def add(self, apply, restore):
        if self.committed:
            raise ContractError('plan_already_committed')
        self.steps.append((apply, restore))

    def set_attr(self, owner, key, value):
        old = getattr(owner, key)
        if hasattr(old, 'to_tuple'):
            old = old.to_tuple()
        elif isinstance(old, list):
            old = list(old)
        self.add(lambda: setattr(owner, key, value), lambda: setattr(owner, key, old))

    def set_key(self, owner, key, value):
        existed = key in owner
        old = owner.get(key)
        def restore():
            if existed:
                owner[key] = old
            elif key in owner:
                del owner[key]
        self.add(lambda: owner.__setitem__(key, value), restore)

    def delete_key(self, owner, key):
        if key not in owner:
            return
        old = owner[key]
        self.add(lambda: owner.__delitem__(key), lambda: owner.__setitem__(key, old))

    def commit(self):
        if self.committed:
            raise ContractError('plan_already_committed')
        restores = []
        try:
            for apply, restore in self.steps:
                restores.append(restore)
                apply()
        except Exception as cause:
            failures = []
            for restore in reversed(restores):
                try:
                    restore()
                except Exception as exc:
                    failures.append(type(exc).__name__ + ': ' + str(exc))
            if failures:
                raise ContractError('rollback_failed', count=len(failures), details='; '.join(failures)) from cause
            raise
        self.committed = True
        return len(self.steps)
