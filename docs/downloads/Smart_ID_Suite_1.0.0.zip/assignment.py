# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Original assignments for the twelve public entry kinds."""
from .data_schema import ContractError, checked_record
from .model import Material
from .library import channel_name
from .channels import CHANNEL_KINDS, metadata, edit_metadata, check_editable, preflight_mesh_scope, ensure_channel, delete_channel
from .matching import matches, material_matches

PASS_INDEX_MAX=32767


def remember(owner,entry,key):
    edit_metadata(owner)[key]={'uid':entry.uid,'type':entry.type,'number':entry.id_number,'name':entry.name,'tag':entry.export_tag,'channel':entry.channel_name}


def forget(owner,entry,key):
    saved=metadata(owner).get(key)
    if isinstance(saved,dict) and saved.get('number') == entry.id_number and saved.get('type') == entry.type:
        edit_metadata(owner).pop(key,None)


def update_material(state,material,entry):
    if material.readonly: raise ContractError('read_only',name=material.name)
    if state.settings.use_pass_index: material.pass_index=min(PASS_INDEX_MAX,entry.id_number)
    material.color=tuple(entry.color)
    if state.settings.write_custom_props: remember(material,entry,'material_id')


def ensure_material(state,entry,allow_create=True):
    name=channel_name(entry)
    if not name: raise ContractError('empty_channel')
    if name not in state.materials:
        if not allow_create: raise ContractError('missing_material',name=name)
        state.materials[name]=Material(name)
    material=state.materials[name]
    update_material(state,material,entry)
    entry.material_name=name
    return name


def assign_material(state,obj,entry):
    mode=state.settings.material_mode
    if obj.kind != 'MESH' or obj.mesh is None: return False
    check_editable(obj,mesh=True)
    named_material = None
    if state.settings.create_missing_material or mode in ('SELECTED_FACES','CREATE_ASSIGN'):
        named_material=ensure_material(state,entry,True)
    if mode == 'CREATE_ASSIGN':
        if 0 <= obj.active_slot < len(obj.slots):obj.slots[obj.active_slot]=named_material
        else:obj.slots.append(named_material);obj.active_slot=len(obj.slots)-1
        return True
    if mode == 'SELECTED_FACES':
        targets=[face for face in obj.mesh.faces if face.selected and not face.hidden]
        if not targets:return False
        if named_material not in obj.slots:obj.slots.append(named_material)
        index=obj.slots.index(named_material)
        for face in targets:face.material_index=index
        return True
    indices=range(len(obj.slots)) if mode == 'ALL_SLOTS' else (obj.active_slot,)
    materials=[state.materials[obj.slots[i]] for i in indices if 0 <= i < len(obj.slots) and obj.slots[i] in state.materials]
    if not materials:
        if not state.settings.create_missing_material: return False
        name=ensure_material(state,entry,True)
        if 0 <= obj.active_slot < len(obj.slots) and obj.slots[obj.active_slot] is None:
            obj.slots[obj.active_slot]=name
        else:
            obj.slots.append(name); obj.active_slot=len(obj.slots)-1
        return True
    for material in materials: update_material(state,material,entry)
    return True


def create_collection(state,entry,keys):
    name=channel_name(entry)
    if not name: raise ContractError('empty_channel')
    if name in state.collection_readonly: raise ContractError('read_only',name=name)
    members=state.collections.setdefault(name,set())
    for key in keys: members.add(key)
    return len(keys)


def apply_entries(state,entries,keys=None,channel_only=False,remove=False):
    entries=[row for row in entries if row.enabled and not row.locked]
    keys=list(state.scope(state.settings.target_scope) if keys is None else keys)
    for row in entries: checked_record(row)
    mesh_entries=[row for row in entries if row.type in CHANNEL_KINDS or (row.type=='MATERIAL_ID' and state.settings.material_mode in ('SELECTED_FACES','CREATE_ASSIGN'))]
    preflight_mesh_scope(state,keys,mesh_entries)
    count=0
    for entry in entries:
        kind=entry.type
        if channel_only and kind not in CHANNEL_KINDS: continue
        if kind == 'RENDER_AOV':
            name=channel_name(entry)
            if not name: raise ContractError('empty_channel')
            if remove: state.aovs.pop(name,None)
            else: state.aovs.setdefault(name,'COLOR')
            count+=1
            continue
        if kind == 'SELECTION_SET':
            name=channel_name(entry)
            if name in state.collection_readonly: raise ContractError('read_only',name=name)
            if remove:
                members=state.collections.get(name,set())
                for key in keys: members.discard(key)
                count+=len(keys)
            else:
                count+=create_collection(state,entry,keys)
                if state.settings.write_custom_props:
                    for target in keys:remember(state.objects[target],entry,"assigned_channel")
            continue
        for key in keys:
            obj=state.objects[key]
            if kind in CHANNEL_KINDS:
                if remove: count+=delete_channel(obj,entry,selected_weights_only=not channel_only)
                else:
                    count+=ensure_channel(obj,entry,assign_weights=not channel_only)
                if state.settings.write_custom_props:
                    owner=obj if kind=="WEIGHT_GROUP" else obj.mesh
                    if owner is not None:
                        if remove:forget(owner,entry,"assigned_channel")
                        else:remember(owner,entry,"assigned_channel")
                continue
            check_editable(obj)
            if kind == 'OBJECT_ID':
                if remove:
                    if state.settings.use_pass_index and obj.pass_index == entry.id_number: obj.pass_index=0
                    forget(obj,entry,'object_id')
                else:
                    if state.settings.use_pass_index: obj.pass_index=min(PASS_INDEX_MAX,entry.id_number)
                    obj.color=tuple(entry.color)
                    if state.settings.write_custom_props: remember(obj,entry,'object_id')
                count+=1
            elif kind == 'MATERIAL_ID':
                if remove:
                    for index,name in enumerate(obj.slots):
                        material=state.materials.get(name)
                        if material_matches(material,entry): obj.slots[index]=None
                    count+=1
                else: count+=assign_material(state,obj,entry)
            elif kind in ('CUSTOM_ID','CRYPTOMATTE_ID'):
                if remove: forget(obj,entry,'identity')
                elif state.settings.write_custom_props: remember(obj,entry,'identity')
                count+=1
    return count


def read_active(state,entry):
    if entry.locked: raise ContractError('locked_entry')
    obj=state.objects.get(state.active_object)
    if obj is None: raise ContractError('no_active_object')
    kind=entry.type
    if kind == 'OBJECT_ID':
        entry.id_number=obj.pass_index; entry.color=tuple(obj.color)
    elif kind == 'MATERIAL_ID':
        if not 0 <= obj.active_slot < len(obj.slots): raise ContractError('missing_active_data')
        material=state.materials.get(obj.slots[obj.active_slot])
        if material is None: raise ContractError('missing_active_data')
        entry.id_number=material.pass_index; entry.color=tuple(material.color); entry.material_name=material.name
    elif kind == 'WEIGHT_GROUP':
        if not obj.active_group: raise ContractError('missing_active_data')
        entry.group_name=obj.active_group; entry.channel_name=obj.active_group
    elif kind in ('MAP_CHANNEL','UV_CHANNEL','COLOR_ATTRIBUTE','GEOMETRY_ATTRIBUTE'):
        if obj.mesh is None: raise ContractError('missing_active_data')
        from .channels import bucket_for
        bucket=bucket_for(obj.mesh,kind)
        layer=next((value for value in bucket.values() if value.active),None)
        if layer is None: raise ContractError('missing_active_data')
        entry.channel_name=layer.name
        if kind in ('MAP_CHANNEL','UV_CHANNEL'): entry.uv_map=layer.name
        if kind == 'COLOR_ATTRIBUTE': entry.color_attribute=layer.name
        if kind == 'GEOMETRY_ATTRIBUTE': entry.attribute_name=layer.name; entry.attribute_type=layer.data_type; entry.attribute_domain=layer.domain
        if kind == 'MAP_CHANNEL': entry.map_channel=metadata(obj.mesh).get('map_channels',{}).get(layer.name,entry.map_channel)
    elif kind == 'UDIM_TILE':
        if obj.mesh is None or 'udim_tile' not in metadata(obj.mesh): raise ContractError('missing_active_data')
        entry.udim_tile=metadata(obj.mesh)['udim_tile']
    elif kind == 'SELECTION_SET':
        names=[name for name,keys in state.collections.items() if obj.key in keys]
        if not names: raise ContractError('missing_active_data')
        entry.group_name=sorted(names)[0]
    elif kind == 'RENDER_AOV':
        if not state.aovs: raise ContractError('missing_active_data')
        entry.export_tag=next(iter(state.aovs))
    else:
        record=metadata(obj).get('identity',{})
        if record.get('type') != kind: raise ContractError('missing_active_data')
        entry.id_number=record['number']; entry.channel_name=record.get('name','')
    return entry
