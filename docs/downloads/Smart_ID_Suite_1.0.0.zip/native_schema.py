import json
from pathlib import Path
import bpy
DATA=json.loads(Path(__file__).with_suffix(".json").read_text("utf8"))
GROUPS={}
ATTACHED=[]
def name(key):return key.replace("_"," ").title()
def field(key,spec,callback=None):
    kind=spec["type"]
    options={"name":name(key)}
    if kind in {"COLLECTION","POINTER"}:
        options["type"]=GROUPS[spec["ref"]]
        return (bpy.props.CollectionProperty if kind=="COLLECTION" else bpy.props.PointerProperty)(**options)
    if callback:options["update"]=callback
    if spec.get("options"):options["options"]=set(spec["options"])
    if "default" in spec:options["default"]=spec["default"]
    if spec.get("subtype") not in (None,"","NONE"):options["subtype"]=spec["subtype"]
    if "min" in spec:options.update(min=spec["min"],max=spec["max"])
    if kind=="ENUM":
        options["items"]=[(key,name(key),"",number) for key,number in spec["items"]]
        constructor=bpy.props.EnumProperty
    elif kind=="FLOAT" and spec.get("array_length"):
        options["size"]=spec["array_length"];constructor=bpy.props.FloatVectorProperty
    else:constructor={"BOOLEAN":bpy.props.BoolProperty,"FLOAT":bpy.props.FloatProperty,"INT":bpy.props.IntProperty,"STRING":bpy.props.StringProperty}[kind]
    return constructor(**options)
def changed(item,ctx):
    from . import lifecycle
    lifecycle.setting_changed(ctx)
def register():
    for key,fields in DATA["groups"].items():
        cls=type(key,(bpy.types.PropertyGroup,),{"__module__":__name__,"__annotations__":{n:field(n,v,changed if key=="SMARTID_PG_settings" else None) for n,v in fields.items()}})
        bpy.utils.register_class(cls);GROUPS[key]=cls
    for name,spec in DATA["scene"].items():
        if hasattr(bpy.types.Scene,name):raise RuntimeError("Scene field already registered: "+name)
        setattr(bpy.types.Scene,name,field(name,spec));ATTACHED.append(name)
def unregister():
    for n in reversed(ATTACHED):delattr(bpy.types.Scene,n)
    ATTACHED.clear()
    for c in reversed(list(GROUPS.values())):bpy.utils.unregister_class(c)
    GROUPS.clear()
def arguments(op):return {k:field(k,v) for k,v in DATA["operators"][op].items()}

