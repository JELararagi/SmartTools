import sys
from . import help_text
import bpy
from . import native_data as nd,native_schema as schema,operators,lifecycle,library,inspection
SECTIONS=[
("always_on","Always-on Tools","常時機能"),("library","ID and Channel Library","ID・チャンネル一覧"),("entry_details","Selected Entry","選択した項目"),
("assignment","Assignment Settings","割り当て設定"),("selection_actions","Selection and Assignment","選択と割り当て"),("channel_tools","Channel Tools","チャンネル操作"),
("selection_inspector","Selection Inspector","選択物の調査"),("visual_overlay","Visual Overlay","画面表示"),("validation_io","Validation and Files","検証・入出力")]
FIELDS={
"always_on":"n_panel_state_save always_on_selection_inspector always_on_automatic_metadata_cleanup overlay_enabled",
"assignment":"target_scope material_mode use_pass_index write_custom_props create_missing_material select_faces auto_color",
"visual_overlay":"overlay_enabled overlay_source overlay_show_ids overlay_show_channels overlay_show_groups overlay_show_labels overlay_object_boxes overlay_element_marks overlay_alpha overlay_line_width",
"validation_io":"include_disabled clear_on_import"}
OPS={"selection_actions":"apply_entry unassign_entry select_by_entry deselect_by_entry select_entry_elements read_active",
"channel_tools":"channel_apply channel_delete create_materials create_collection create_aov",
"validation_io":"validate_registry export_json import_json export_csv"}
JA={"Object Id":"オブジェクトID","Material Id":"マテリアルID","Map Channel":"マップチャンネル","Uv Channel":"UVチャンネル","Color Attribute":"カラー属性","Geometry Attribute":"ジオメトリ属性","Selection Set":"選択セット","Render Aov":"レンダーAOV","Weight Group":"頂点グループ","Custom Id":"カスタムID","Name":"名前","Color":"色","Type":"種類","Search":"検索","Filter Type":"種類で絞り込み","Library Scope":"一覧の対象","Target Scope":"割り当て対象","Id Number":"ID番号","New Entry Type":"追加する種類","Naming Profile":"命名方式","Channel Name":"チャンネル名","Group Name":"グループ名","Locked":"ロック","Enabled":"有効","Notes":"メモ","Renumber Start":"開始番号","Renumber Step":"増分","Overlay Enabled":"オーバーレイを表示","Overlay Source":"表示対象","Overlay Show Labels":"名前を表示","Open Manual":"解説書を開く","Apply Entry":"項目を割り当て","Unassign Entry":"割り当てを解除","Select By Entry":"一致する物を選択","Deselect By Entry":"一致する物を選択解除","Select Entry Elements":"一致する要素を選択","Read Active":"アクティブから取得","Channel Apply":"チャンネルを作成","Channel Delete":"チャンネルを削除","Create Materials":"マテリアルを作成","Create Collection":"コレクションを作成","Create Aov":"AOVを作成","Validate Registry":"一覧を検証","Export Json":"JSONを書き出す","Import Json":"JSONを読み込む","Export Csv":"CSVを書き出す","Refresh Counts":"使用数を更新","Renumber Entries":"番号を振り直す","Sync From Selection":"選択物から登録","Sync From Scene":"シーンから登録","Entry Select Visible":"表示項目を選択","Entry Clear Selection":"チェックを解除","Entry Delete Selected":"チェック項目を削除","Inspector Refresh":"調査を更新","Inspector Apply":"変更を適用","Inspector Delete":"項目を削除","Inspector Make Entry":"一覧に登録","Inspector Select Owner":"所有物を選択","Inspector Apply Entry":"登録内容を適用","Inspector Select Elements":"該当要素を選択","Inspector Assign Selection":"選択に割り当て","Inspector Unassign Selection":"選択から解除","Inspector Select Visible":"表示行を選択","Inspector Clear Selection":"チェックを解除","Inspector Delete Selected":"チェック行を削除","Matches":"使用数","Add":"追加","Remove":"削除","Duplicate":"複製","Selected":"選択中","Scene":"シーン","Active":"アクティブ"}
JA.update({"Type Id":"種類・番号","Cryptomatte Id":"クリプトマットID","Udim Tile":"UDIMタイル","Id":"ID","Material Name":"マテリアル名","Uv Map":"UVマップ","Map Channel":"マップチャンネル","Attribute Name":"属性名","Attribute Type":"属性の形式","Attribute Domain":"属性のドメイン","Export Tag":"書き出しタグ","Inspected Objects":"調査対象","Inspector Scope":"調査対象","Inspector Filter Type":"調査の種類","Inspector Search":"調査結果を検索","Edit Name":"変更後の名前","Render":"レンダー","Overlay Show Ids":"IDを表示","Overlay Show Channels":"チャンネルを表示","Overlay Show Groups":"グループを表示","Overlay Object Boxes":"境界ボックス","Overlay Element Marks":"要素に印を付ける","Overlay Alpha":"不透明度","Overlay Line Width":"線の太さ","Material Mode":"マテリアルの扱い","Use Pass Index":"パスインデックスを使う","Write Custom Props":"カスタムプロパティを記録","Create Missing Material":"不足マテリアルを作成","Select Faces":"面を選択","Auto Color":"自動配色","Include Disabled":"無効項目を含む","Clear On Import":"読み込み時に一覧を置換","N Panel State Save":"サイドバーの設定を保存","Always On Selection Inspector":"選択変更時に調査を更新","Always On Automatic Metadata Cleanup":"不要な記録を自動整理","Objects":"オブジェクト","Materials":"マテリアル","Channels":"チャンネル"})
JA.update(help_text.JA)
JA.update({en:ja for _,en,ja in SECTIONS})
def label(en):return JA.get(en,en) if bpy.app.translations.locale.startswith("ja") else en
def title(key):return schema.name(key)
def question(row,key):
    btn=row.operator("smart_id.open_help",text="",icon="QUESTION",emboss=False);btn.help_key="info_"+key;btn.title_key="section_"+key
def help_popup(op,ctx):
    key=(op.help_key or op.title_key).removeprefix("info_").removeprefix("section_")
    match=next(((i,en,ja) for i,(slug,en,ja) in enumerate(SECTIONS,1) if slug==key),None)
    ja=bpy.app.translations.locale.startswith("ja");name=("一覧" if ja else "Library") if key=="library" else (match[2 if ja else 1] if match else "Smart ID")
    def draw(menu,c):
        menu.layout.label(text=help_text.HELP.get(key,help_text.HELP["overview"])[1 if ja else 0])
        url=menu.layout.operator("wm.url_open",text=label("Open Manual"),icon="URL")
        url.url="https://jelararagi.github.io/SmartTools/"+("" if ja else "en/")+"manuals/SmartID/#"+("f"+str(match[0]) if match else "s1")
    if not bpy.app.background:ctx.window_manager.popup_menu(draw,title=name,icon="QUESTION")
    return {"FINISHED"}
def button(ui,key,text=None,icon="NONE"):
    return ui.operator("smart_id."+key,text=label(text if text is not None else title(key)),icon=icon)
def filtered(ul,ctx,inspector):
    state=nd.snapshot(ctx,library_only=True)
    keep=set(inspection.visible_inspector_indices(state) if inspector else library.visible_indices(state))
    return [ul.bitflag_filter_item if i in keep else 0 for i in range(len(state.inspector if inspector else state.entries))],[]
class SMARTID_UL_entries(bpy.types.UIList):
    bl_idname="SMARTID_UL_entries"
    def filter_items(self,ctx,data,propname):return filtered(self,ctx,False)
    def draw_item(self,ctx,layout,data,item,icon,active_data,active_propname,index):
        row=layout.row(align=True);row.operator("smart_id.entry_multi_select",text="",icon="CHECKBOX_HLT" if item.selected else "CHECKBOX_DEHLT",emboss=False).index=index
        row.prop(item,"color",text="");row.label(text=item.name);row.label(text=str(item.id_number));row.prop(item,"locked",text="",icon="LOCKED" if item.locked else "UNLOCKED",emboss=False)
class SMARTID_UL_inspector_items(bpy.types.UIList):
    bl_idname="SMARTID_UL_inspector_items"
    def filter_items(self,ctx,data,propname):return filtered(self,ctx,True)
    def draw_item(self,ctx,layout,data,item,icon,active_data,active_propname,index):
        row=layout.row(align=True);row.operator("smart_id.inspector_multi_select",text="",icon="CHECKBOX_HLT" if item.selected else "CHECKBOX_DEHLT",emboss=False).index=index
        row.label(text=item.name or item.owner_object);row.label(text=label(title(item.item_type.lower())))
def content(key,ui,ctx):
    s=ctx.scene;cfg=s.smart_id_settings;rows=nd.entries(s)
    if key=="library":
        ui.prop(cfg,"new_entry_type",text=label("New Entry Type"));r=ui.row(align=True)
        button(r,"add_entry","Add","ADD").entry_type=cfg.new_entry_type;button(r,"remove_entry","Remove","REMOVE");button(r,"duplicate_entry","Duplicate","DUPLICATE")
        ui.prop(cfg,"library_scope");ui.prop(cfg,"search",icon="VIEWZOOM");ui.prop(cfg,"filter_type")
        ui.template_list("SMARTID_UL_entries","",s,rows.path_from_id(),s,"smart_id_active_index",rows=4)
        r=ui.row(align=True);button(r,"move_entry","", "TRIA_UP").direction="UP";button(r,"move_entry","","TRIA_DOWN").direction="DOWN"
        r.prop(cfg,"sort_mode",text="");button(r,"sort_entries","","SORTALPHA")
        for name in ("entry_select_visible","entry_clear_selection","entry_delete_selected","refresh_counts","sync_from_selection","sync_from_scene"):button(ui,name)
        r=ui.row(align=True);r.prop(cfg,"renumber_start");r.prop(cfg,"renumber_step");button(ui,"renumber_entries");ui.prop(cfg,"naming_profile");return
    if key=="entry_details":
        if 0<=s.smart_id_active_index<len(rows):
            e=rows[s.smart_id_active_index]
            for n in ("name","type","id_number","color","enabled","locked","channel_name","material_name","uv_map","color_attribute","attribute_name","attribute_type","attribute_domain","group_name","map_channel","udim_tile","export_tag","notes"):ui.prop(e,n)
            ui.label(text=label("Matches")+"  ("+label("Selected")+" / "+label("Scene")+")")
            for kind in ("objects","materials","channels"):
                ui.label(text=label(kind.title())+"   "+str(getattr(e,"count_selected_"+kind))+"  /  "+str(getattr(e,"count_"+kind)))
        return
    if key=="selection_inspector":
        ui.prop(cfg,"inspector_scope");ui.prop(cfg,"inspector_search",icon="VIEWZOOM");ui.prop(cfg,"inspector_filter_type")
        button(ui,"inspector_refresh");ui.template_list("SMARTID_UL_inspector_items","",s,"smart_id_inspector_items",s,"smart_id_inspector_active_index",rows=4)
        if 0<=s.smart_id_inspector_active_index<len(s.smart_id_inspector_items):
            x=s.smart_id_inspector_items[s.smart_id_inspector_active_index]
            for n in ("edit_name","id_number","active","render","map_channel","color"):ui.prop(x,n)
        for name in ("inspector_apply","inspector_delete","inspector_make_entry","inspector_select_owner","inspector_apply_entry","inspector_select_elements","inspector_assign_selection","inspector_unassign_selection","inspector_select_visible","inspector_clear_selection","inspector_delete_selected"):button(ui,name)
        return
    for n in FIELDS.get(key,"").split():ui.prop(cfg,n)
    for n in OPS.get(key,"").split():button(ui,n)
class RootPanel:
    bl_label="Smart ID"
    bl_category="Smart ID";bl_region_type="UI"
    @classmethod
    def poll(cls,ctx):
        area=ctx.area
        if not area:return False
        if area.type=="FILE_BROWSER" and (cls.__name__=="SMARTID_PT_asset_browser_root")!=(area.ui_type=="ASSETS"):return False
        for item in ctx.preferences.addons:
            if item.module.rsplit(".",1)[-1]=="smart_tools_manager":
                m=sys.modules.get(item.module+".manager")
                if m:return bool(m.panel_rule_allows_context("SMART_ID",ctx,m.logical_editor_key_from_context(ctx)))
        return True
    def draw_header_preset(self,ctx):question(self.layout,"overview")
    def draw(self,ctx):
        cfg=ctx.scene.smart_id_settings
        for key,en,ja in SECTIONS:
            ui=self.layout;row=ui.row(align=True);field="ui_section_"+key;opened=getattr(cfg,field)
            row.prop(cfg,field,text=label(en),icon="TRIA_DOWN" if opened else "TRIA_RIGHT",emboss=False);question(row,key)
            if opened:content(key,ui.column(align=True),ctx)
classes=[];translated=False
def register():
    from . import panels
    global translated
    try:
        schema.register()
        for cls in (*operators.CLASSES,SMARTID_UL_entries,SMARTID_UL_inspector_items,*panels.CLASSES):
            bpy.utils.register_class(cls);classes.append(cls)
        pairs={(c,e):j for e,j in JA.items() for c in ("*","Operator")}
        bpy.app.translations.register(__package__,{"ja_JP":pairs});translated=True
        lifecycle.register()
    except Exception:
        unregister();raise
def unregister():
    global translated
    lifecycle.unregister()
    if translated:bpy.app.translations.unregister(__package__);translated=False
    for cls in reversed(classes):bpy.utils.unregister_class(cls)
    classes.clear();schema.unregister()

