# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Wire the unchanged inherited independent execute to newly written services."""
from types import SimpleNamespace
from . import renumber_inherited as inherited


def renumber(state, locale='en_US'):
    reports = []
    operator = SimpleNamespace(report=lambda level, text: reports.append((tuple(sorted(level)), text)))
    before = [row.id_number for row in state.entries]
    status = inherited.execute(operator, SimpleNamespace(scene=state, locale=locale))
    changed = sum(old != row.id_number for old, row in zip(before, state.entries))
    return status, changed, reports
