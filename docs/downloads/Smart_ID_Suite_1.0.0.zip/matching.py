# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Read-only matching, counts and element selection masks."""
from .library import channel_name
from .channels import metadata, bucket_for


def material_matches(material, entry):
    if material is None: return False
    record=metadata(material).get('material_id',{})
    if entry.material_name and material.name == entry.material_name: return True
    return material.pass_index == entry.id_number or (isinstance(record,dict) and record.get('number') == entry.id_number)


def material_slots(state,obj,entry):
    return {index for index,name in enumerate(obj.slots) if name in state.materials and material_matches(state.materials[name],entry)}


def matches(state,obj,entry):
    kind=entry.type; name=channel_name(entry)
    if kind == 'OBJECT_ID':
        saved=metadata(obj).get('object_id',{})
        return obj.pass_index == entry.id_number or (isinstance(saved,dict) and saved.get('number') == entry.id_number)
    if kind == 'MATERIAL_ID': return bool(material_slots(state,obj,entry))
    if kind == 'SELECTION_SET': return obj.key in state.collections.get(name,set())
    if kind == 'RENDER_AOV': return False
    if kind in ('CUSTOM_ID','CRYPTOMATTE_ID'):
        saved=metadata(obj).get('identity',{})
        return isinstance(saved,dict) and saved.get('type') == kind and saved.get('number') == entry.id_number
    if kind == 'WEIGHT_GROUP': return name in obj.groups
    if obj.mesh is None: return False
    if kind == 'UDIM_TILE': return metadata(obj.mesh).get('udim_tile') == entry.udim_tile
    if kind == 'MAP_CHANNEL':
        mapping=metadata(obj.mesh).get('map_channels',{})
        return name in obj.mesh.uv and isinstance(mapping,dict) and mapping.get(name) == entry.map_channel
    bucket=bucket_for(obj.mesh,kind)
    return bucket is not None and name in bucket


def element_indices(state,obj,entry):
    if obj.mesh is None: return ('NONE',set())
    if entry.type == 'MATERIAL_ID':
        slots=material_slots(state,obj,entry)
        return ('FACE',{i for i,face in enumerate(obj.mesh.faces) if face.material_index in slots and not face.hidden})
    if entry.type == 'WEIGHT_GROUP':
        weights=obj.groups.get(channel_name(entry),{})
        return ('VERTEX',{i for i,weight in weights.items() if weight > 0 and 0 <= i < len(obj.mesh.vertices) and not obj.mesh.vertices[i].hidden})
    if matches(state,obj,entry):
        return ('VERTEX',{i for i,vertex in enumerate(obj.mesh.vertices) if not vertex.hidden})
    return ('NONE',set())


def refresh_counts(state):
    selected=set(state.scope('ACTIVE' if state.settings.library_scope=='ACTIVE' else 'SELECTED'))
    scene=[state.objects[key] for key in state.scope('SCENE')]
    for entry in state.entries:
        found=[obj for obj in scene if matches(state,obj,entry)]
        local=[obj for obj in found if obj.key in selected]
        entry.count_objects=len(found); entry.count_selected_objects=len(local)
        if entry.type == 'MATERIAL_ID':
            entry.count_materials=len({name for obj in found for name in obj.slots if name in state.materials and material_matches(state.materials[name],entry)})
            entry.count_selected_materials=len({name for obj in local for name in obj.slots if name in state.materials and material_matches(state.materials[name],entry)})
        else:
            entry.count_materials=entry.count_selected_materials=0
        channel=entry.type in ('MAP_CHANNEL','UV_CHANNEL','COLOR_ATTRIBUTE','GEOMETRY_ATTRIBUTE','WEIGHT_GROUP','UDIM_TILE')
        entry.count_channels=len({obj.mesh.key for obj in found if obj.mesh}) if channel else 0
        entry.count_selected_channels=len({obj.mesh.key for obj in local if obj.mesh}) if channel else 0
        if entry.type == 'RENDER_AOV': entry.count_channels=int(channel_name(entry) in state.aovs)
    state.counts_signature=state.selection_signature()


def select_objects(state,entries,deselect=False):
    matched=[key for key in state.scope('SCENE') if not state.objects[key].hidden and any(matches(state,state.objects[key],row) for row in entries)]
    if deselect:
        for key in matched: state.objects[key].selected=False
    else:
        wanted=set(matched)
        for key in state.scope('SCENE'):
            if not state.objects[key].hidden: state.objects[key].selected=key in wanted
        if matched and state.active_object not in wanted: state.active_object=matched[0]
    return len(matched)


def select_elements(state,entries,keys=None,deselect=False):
    changed=0
    for key in (state.scope('SCENE') if keys is None else keys):
        obj=state.objects[key]
        if obj.hidden or obj.mesh is None: continue
        for row in entries:
            kind,indices=element_indices(state,obj,row)
            elements=obj.mesh.faces if kind == 'FACE' else obj.mesh.vertices
            for index in indices:
                element=elements[index]
                if element.selected == deselect: changed+=1
                element.selected=not deselect
    return changed
