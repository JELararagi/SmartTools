"""Adapt inspector rows to public owner/slot identifiers, retaining a stable editing reference."""
from uuid import uuid5,NAMESPACE_URL
from .data_schema import MAX_TEXT
from .channels import metadata

OWNERS={'OBJECT_ID':'OBJECT','MATERIAL_ID':'MATERIAL_SLOT','MAP_CHANNEL':'MESH_METADATA','UV_CHANNEL':'MESH_UV','COLOR_ATTRIBUTE':'MESH_COLOR_ATTRIBUTE','GEOMETRY_ATTRIBUTE':'MESH_ATTRIBUTE','UDIM_TILE':'MESH_METADATA','WEIGHT_GROUP':'VERTEX_GROUP','SELECTION_SET':'COLLECTION'}
ORDER={'OBJECT_ID':0,'MATERIAL_ID':2,'UV_CHANNEL':4,'MAP_CHANNEL':5,'COLOR_ATTRIBUTE':6,'GEOMETRY_ATTRIBUTE':7,'UDIM_TILE':8,'WEIGHT_GROUP':10,'SELECTION_SET':11}
MSG={'OBJECT_ID':'details_object_type','MATERIAL_ID':'details_material_slot_assignment','UV_CHANNEL':'details_uv_map','MAP_CHANNEL':'details_map_channel_with_uv','COLOR_ATTRIBUTE':'details_color_attribute','GEOMETRY_ATTRIBUTE':'details_geometry_attribute','UDIM_TILE':'details_udim_metadata','WEIGHT_GROUP':'details_vertex_group','SELECTION_SET':'details_collection_membership'}
def stored_uid(reference):
    return uuid5(NAMESPACE_URL,'smart-id-suite/inspection/'+reference).hex
def identity(row):
    return (row.owner_object,row.item_type,row.name,row.owner_data,row.slot_index,row.material_name)
def meta_owner(state,obj,row):
    if row.owner_data=='MESH':return obj.mesh
    if row.owner_data=='MATERIAL':return state.materials.get(row.material_name)
    return obj
def meta_key(state,obj,row):
    return next((meta['key'] for meta in state.inspector_meta.get(obj.key,()) if meta['owner_data']==row.owner_data and meta['material_name']==row.material_name),row.name)
def rows(state,keys):
    from .inspection import raw_items,_item,reference
    for key in keys:
        obj=state.objects.get(key)
        if obj is None:continue
        ordered=[]
        for row in raw_items(state,[key]):
            kind=row.item_type
            if kind=='SMART_METADATA':continue
            row.owner_data=OWNERS[kind];row.details_message_id=MSG[kind]
            if kind=='WEIGHT_GROUP':row.slot_index=list(obj.groups).index(row.name);row.value_text='index='+str(row.slot_index)
            elif kind=='MAP_CHANNEL':row.slot_index=row.map_channel;row.value_text=f'channel={row.map_channel}, uv={row.name}'
            elif kind=='UDIM_TILE':row.name=row.edit_name='UDIM_'+str(row.id_number);row.value_text='tile='+str(row.id_number)
            elif kind=='OBJECT_ID':row.value_text='pass_index='+str(row.id_number)
            elif kind=='MATERIAL_ID':row.value_text=f'slot={row.slot_index}, pass_index={row.id_number}'
            elif kind=='UV_CHANNEL':
                row.value_text='active' if row.active else 'uv'
                if row.name in metadata(obj.mesh).get('map_channels',{}):row.details_message_id='details_map_channels_prefix'
            elif kind=='SELECTION_SET':row.value_text='linked'
            else:
                row.value_text=row.data_type+' / '+row.domain
                if kind=='GEOMETRY_ATTRIBUTE' and not row.safe_to_delete:row.details_message_id='details_protected_geometry_attribute'
            row.uid=reference(obj.key,kind,row.name,row.slot_index)
            ordered.append((ORDER[kind],row))
        for meta in state.inspector_meta.get(obj.key,()):
            side=meta['owner_data'];name=meta['name']
            row=_item(obj,'SMART_METADATA',name=name,id_number=meta['id_number'],owner_data=side,material_name=meta['material_name'],value_text=meta['value_text'][:MAX_TEXT],details_message_id='details_smart_id_custom_props',safe_to_delete=meta['editable'])
            row.uid=reference(obj.key,row.item_type,side+'/'+meta['material_name'],-1)
            ordered.append(({'OBJECT':1,'MATERIAL':3,'MESH':9}[side],row))
        yield from (row for _,row in sorted(ordered,key=lambda pair:pair[0]))

