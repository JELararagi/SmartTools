# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Machine-readable SmartTools N-panel, lifecycle and ownership contract."""

CONTRACT_VERSION = 8
EXTENSION_ID = "smart_id_suite"
SUITE_ID = "smart_id_suite"
TOOL_KEY = "SMART_ID"
OWNER_UUID = "8e52635f-4b48-47a2-9513-8edc0e7e62a5"
EXTENSION_VERSION = "0.6.23"
CONFIG_FOLDER = "Smart_ID_Suite"
CONFIG_FILE = "Smart_ID_Suite.json"
STATE_SAVE_PATH = "scene.smart_id_settings.n_panel_state_save"
SECTION_OPEN_PATH = "scene.smart_id_settings.ui_section_always_on"
MANAGER_MIN_VERSION = (1, 5, 57)
MANAGER_PLACEMENT_API = "placement_allowed"
MANAGER_API_SIGNATURE = "placement_allowed(tool_key, context, editor_key=...)"
MANAGER_API_SOURCE = "fixed sys.modules lookup of the already-loaded Smart Tools Manager package"
MANAGER_FAIL_OPEN_STATES = ("ABSENT", "DISABLED", "NOT_READY", "API_EXCEPTION", "NON_BOOLEAN")
MANAGER_NOT_READY_POLICY = "fail open only without verified Manager authority; READY bool is exact; invalid key/editor mismatch fails closed"

PHYSICAL_ROOTS = (
    ("SMARTID_PT_main", "VIEW_3D", "UI", "Smart ID"),
    ("SMARTID_PT_image_editor_root", "IMAGE_EDITOR", "UI", "Smart ID"),
    ("SMARTID_PT_node_editor_root", "NODE_EDITOR", "UI", "Smart ID"),
    ("SMARTID_PT_sequence_editor_root", "SEQUENCE_EDITOR", "UI", "Smart ID"),
    ("SMARTID_PT_clip_editor_root", "CLIP_EDITOR", "UI", "Smart ID"),
    ("SMARTID_PT_dopesheet_editor_root", "DOPESHEET_EDITOR", "UI", "Smart ID"),
    ("SMARTID_PT_graph_editor_root", "GRAPH_EDITOR", "UI", "Smart ID"),
    ("SMARTID_PT_nla_editor_root", "NLA_EDITOR", "UI", "Smart ID"),
    ("SMARTID_PT_text_editor_root", "TEXT_EDITOR", "UI", "Smart ID"),
    ("SMARTID_PT_file_browser_root", "FILE_BROWSER", "UI", "Smart ID"),
    ("SMARTID_PT_spreadsheet_root", "SPREADSHEET", "UI", "Smart ID"),
    ("SMARTID_PT_asset_browser_root", "FILE_BROWSER", "TOOL_PROPS", "Smart ID"),
)
ROOT_PANEL_IDS = (
    "SMARTID_PT_main",
    "SMARTID_PT_image_editor_root",
    "SMARTID_PT_node_editor_root",
    "SMARTID_PT_sequence_editor_root",
    "SMARTID_PT_clip_editor_root",
    "SMARTID_PT_dopesheet_editor_root",
    "SMARTID_PT_graph_editor_root",
    "SMARTID_PT_nla_editor_root",
    "SMARTID_PT_text_editor_root",
    "SMARTID_PT_file_browser_root",
    "SMARTID_PT_spreadsheet_root",
    "SMARTID_PT_asset_browser_root",
)
PHYSICAL_ROOT_IDS = tuple(item[0] for item in PHYSICAL_ROOTS)
if ROOT_PANEL_IDS != PHYSICAL_ROOT_IDS:
    raise RuntimeError("Smart ID physical root contract is inconsistent")
REGISTRATION_CONFLICT_POLICY = "exact self-owned owner/generation residue is reclaimed; foreign identity enters RESTART_REQUIRED without enable failure"
RESTART_REQUIRED_BODY_POLICY = "Scene-independent safe body; foreign resources unchanged; twelve manager-controlled roots retained through exact or private fallback identities"
LOGICAL_EDITOR_TO_PHYSICAL = {
    "VIEW_3D": "VIEW_3D",
    "IMAGE_EDITOR": "IMAGE_EDITOR",
    "UV_EDITOR": "IMAGE_EDITOR",
    "SHADER_EDITOR": "NODE_EDITOR",
    "COMPOSITOR": "NODE_EDITOR",
    "GEOMETRY_NODE_EDITOR": "NODE_EDITOR",
    "TEXTURE_NODE_EDITOR": "NODE_EDITOR",
    "VIDEO_SEQUENCER": "SEQUENCE_EDITOR",
    "MOVIE_CLIP_EDITOR": "CLIP_EDITOR",
    "DOPE_SHEET": "DOPESHEET_EDITOR",
    "GRAPH_EDITOR": "GRAPH_EDITOR",
    "DRIVERS": "GRAPH_EDITOR",
    "NLA_EDITOR": "NLA_EDITOR",
    "TEXT_EDITOR": "TEXT_EDITOR",
    "ASSET_BROWSER": "FILE_BROWSER",
    "FILE_BROWSER": "FILE_BROWSER",
    "SPREADSHEET": "SPREADSHEET",
}
FULL_BODY_FUNCTION = "_draw_smart_id_full_body"
ROOT_PANEL_LOGICAL_EDITOR_KEYS = {
    "SMARTID_PT_file_browser_root": ("FILE_BROWSER",),
    "SMARTID_PT_asset_browser_root": ("ASSET_BROWSER",),
}
FULL_BODY_FINGERPRINT_SOURCE = "ordered _SECTION_DEFS property keys"

BASELINE_REGISTERED_CLASS_COUNT = 49
REGISTERED_CLASS_COUNT = 60
OPERATOR_CLASS_COUNT = 43
PROPERTY_GROUP_CLASS_COUNT = 3
UI_LIST_CLASS_COUNT = 2
PANEL_CLASS_COUNT = 12
REGISTERED_PROPERTY_DEFINITION_COUNT = 103
BASELINE_PUBLIC_SURFACE_POLICY = "first 49 class identities and all existing bl_idname/options/property definitions remain ordered"

RESOURCE_LEDGER_FIELDS = (
    "kind",
    "owner_uuid",
    "suite_id",
    "generation",
    "owner_token",
    "identity",
    "native_remover",
    "removed",
)
UNREGISTER_POLICY = "reverse exact identity only; old module generation is a no-op against current registration ledger"
GLOBAL_API_MONKEYPATCH = False
BROAD_FOREIGN_CLEANUP = False
RAW_BLEND_FILE_ACCESS = False
AUTOMATIC_KEYMAP_REGISTRATION = False
PERIODIC_STATUS_TIMER = False
PERIODIC_CLEANUP_TIMER = False

RUNTIME_RESOURCE_RELEASE_RETRY_LIMIT = 3
TIMER_POLICY = "generation-owned coalesced one-shot only; every callback untracks itself and returns None"
DEPSGRAPH_POLICY = "feature-gated registration; cheap relevant-ID rejection precedes Scene settings, scans, evaluated data, or enqueue"
REDRAW_POLICY = "event completion or visible Overlay removal only; no idle or unconditional settings redraw"
DRAW_MUTATION = False
POLL_MUTATION = False
EXIT_RUNTIME_POLICY = "exit_pre invokes the exact-ledger unregister transaction; timers, handlers, draw callbacks, msgbus, RNA properties/classes and translations are released without scans"

CACHE_HARD_BUDGET_BYTES = 256 * 1024 * 1024
CACHE_POLICY = "shared 256 MiB byte-charged TTL/LRU for every mutable operation cache; event-time eviction and immediate OFF/load/unregister clear"
MANAGER_CELL_CACHE_LIMIT = 0
MANAGER_CELL_CACHE_HARD_BYTES = 0
INSPECTOR_PROXY_LIMIT = 4096
INSPECTOR_LIMIT_POLICY = "explicit truncated flag plus total/shown/omitted counts; source data untouched"
OVERLAY_REBUILD_MAX_HZ = 10
OVERLAY_DRAW_POLICY = "read-only immutable published snapshot and completed GPU batches only; no RNA, evaluation, batch build, timer, cache mutation, or redraw request in draw"

EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
RUNTIME_TOGGLE_PATHS = (
    "scene.smart_id_settings.always_on_selection_inspector",
    "scene.smart_id_settings.always_on_automatic_metadata_cleanup",
    "scene.smart_id_settings.overlay_enabled",
)
PERSISTENCE_ROOTS = ("scene.smart_id_settings",)
EXCLUDED_TRANSIENT_PATHS = (
    "scene.smart_id_settings.last_library_autosync_signature",
    "scene.smart_id_settings.last_report",
    "scene.smart_id_inspector_items",
    "scene.smart_id_inspector_active_index",
    "scene.smart_id_inspector_selection_anchor_index",
    "scene.smart_id_inspector_total_count",
    "scene.smart_id_inspector_omitted_count",
    "scene.smart_id_inspector_truncated",
    "scene.smart_id_selection_anchor_index",
    "scene.smart_id_settings.name",
)

BLEND_OWNED_NPANEL_PATHS = (
    "scene.smart_id_entries",
    "scene.smart_id_entries_staging",
    "scene['_smart_id_suite_registry_bank_v1']",
    "scene.smart_id_active_index",
)
