"""Apply validated differences to Blender, retaining unrelated datablocks and attributes."""
import bpy,bmesh
from uuid import uuid4
from . import native_data as nd
from .channels import BUCKET

def metadata(owner,before,after):
    if before==after:return
    a=before.get(BUCKET,{})
    b=after.get(BUCKET,{})
    if b:owner["smart_id_native_records"]=b
    elif "smart_id_native_records" in owner:del owner["smart_id_native_records"]
    def put(key,value):
        n=nd.PREFIX+key
        if value is not None:owner[n]=value
        elif n in owner:del owner[n]
    if a.get("udim_tile")!=b.get("udim_tile"):put("udim_tile",b.get("udim_tile"))
    ma,mb=a.get("map_channels",{}),b.get("map_channels",{})
    if ma!=mb:
        for value in set(ma.values())-set(mb.values()):put("map_channel_"+str(value),None)
        for name,num in mb.items():put("map_channel_"+str(num),name)
    for key in ("object_id","material_id","identity","assigned_channel"):
        src=a.get(key);dst=b.get(key)
        if src==dst:continue
        if dst is None:
            if src and owner.get(nd.PREFIX+"uid")==src.get("uid"):
                for n in ("uid","type","name","role","id_number","export_tag","channel_name","suite_id","generation","operation_uuid"):put(n,None)
            continue
        for native,record in (("uid","uid"),("name","name"),("type","type"),("id_number","number"),("export_tag","tag"),("channel_name","channel")):put(native,dst.get(record,""))
        role={"OBJECT_ID":"object","MATERIAL_ID":"material","CUSTOM_ID":"custom","CRYPTOMATTE_ID":"custom","UV_CHANNEL":"mesh_channel","MAP_CHANNEL":"mesh_channel","COLOR_ATTRIBUTE":"color_attribute","GEOMETRY_ATTRIBUTE":"geometry_attribute","UDIM_TILE":"udim_tile","WEIGHT_GROUP":"weight_group","SELECTION_SET":"selection_set"}.get(dst["type"],key)
        put("role",role);put("suite_id","smart_id_suite");put("generation",1);put("operation_uuid",uuid4().hex)
        if not owner.get(nd.PREFIX+"owner_uuid"):put("owner_uuid",str(uuid4()))
        if dst["type"]=="CRYPTOMATTE_ID":put("cryptomatte_name",dst["name"])

def write_channels(mesh,old,new,kind):
    if old==new:return
    layers={"uv":mesh.uv_layers,"attributes":mesh.attributes,"colors":mesh.color_attributes}[kind]
    claimed=set()
    for name,item in new.items():
        source=item.origin or name
        if source!=name and source in old and name not in old and layers.get(source):
            layers[source].name=name;claimed.add(source)
    for name,old_item in old.items():
        if name not in new and name not in claimed and layers.get(name) and not old_item.protected:layers.remove(layers[name])
    for name,item in new.items():
        layer=layers.get(name)
        if layer is None:
            layer=layers.new(name=name) if kind=="uv" else layers.new(name=name,type=item.data_type,domain=item.domain)
            if kind=="colors" and item.fill is not None:
                for datum in layer.data:datum.color=item.fill
        if (name not in old or old[name].active!=item.active) and item.active:
            if kind=="uv":layers.active=layer
            elif kind=="colors":layers.active_color=layer
            else:layers.active=layer
        if kind=="uv" and item.render and not layer.active_render:layer.active_render=True

def mesh_values(ob,old,new):
    mesh=ob.data
    for kind in ("uv","colors","attributes"):write_channels(mesh,getattr(old,kind),getattr(new,kind),kind)
    metadata(mesh,old.metadata,new.metadata)
    if (old.vertices,new.vertices)==([],[]) or old.vertices==new.vertices and old.faces==new.faces:return
    if ob.mode=="EDIT":
        bm=bmesh.from_edit_mesh(mesh);bm.verts.ensure_lookup_table();bm.faces.ensure_lookup_table()
        for i,(a,b) in enumerate(zip(old.vertices,new.vertices)):
            if a.selected!=b.selected:bm.verts[i].select_set(b.selected)
        for i,(a,b) in enumerate(zip(old.faces,new.faces)):
            if a.selected!=b.selected:bm.faces[i].select_set(b.selected)
            if a.material_index!=b.material_index:bm.faces[i].material_index=b.material_index
        bm.select_flush_mode();bmesh.update_edit_mesh(mesh,loop_triangles=False,destructive=False)
    else:
        for target,a,b in zip(mesh.vertices,old.vertices,new.vertices):
            if a.selected!=b.selected:target.select=b.selected
        for target,a,b in zip(mesh.polygons,old.faces,new.faces):
            if a.selected!=b.selected:target.select=b.selected
            if a.material_index!=b.material_index:target.material_index=b.material_index
        mesh.update()

def groups(ob,old,new):
    if ob.type!="MESH" or (old.groups==new.groups and old.active_group==new.active_group):return
    keep=set()
    for name,source in new.group_origins.items():
        if source!=name and source in ob.vertex_groups:
            ob.vertex_groups[source].name=name;keep.add(source)
    for name in old.groups.keys()-new.groups.keys()-keep:
        if ob.vertex_groups.get(name):ob.vertex_groups.remove(ob.vertex_groups[name])
    for name,weights in new.groups.items():
        g=ob.vertex_groups.get(name) or ob.vertex_groups.new(name=name)
        previous=old.groups.get(new.group_origins.get(name,name),{})
        if previous==weights:continue
        if ob.mode=="EDIT":
            bm=bmesh.from_edit_mesh(ob.data);bm.verts.ensure_lookup_table();layer=bm.verts.layers.deform.verify()
            for index in previous.keys()|weights.keys():
                data=bm.verts[index][layer]
                if index in weights:data[g.index]=weights[index]
                elif g.index in data:del data[g.index]
            bmesh.update_edit_mesh(ob.data,loop_triangles=False,destructive=False)
        else:
            dropped=list(previous.keys()-weights.keys())
            if dropped:g.remove(dropped)
            for index,weight in weights.items():
                if previous.get(index)!=weight:g.add([index],weight,"REPLACE")
    if new.active_group in ob.vertex_groups:ob.vertex_groups.active_index=ob.vertex_groups[new.active_group].index

def materials(old,new):
    for key,rec in new.materials.items():
        was=old.materials.get(rec.origin or key)
        if was==rec:continue
        mat=bpy.data.materials.get(rec.origin or key) or bpy.data.materials.new(key)
        if mat.name!=rec.name:mat.name=rec.name
        if not was or was.pass_index!=rec.pass_index:mat.pass_index=rec.pass_index
        if not was or was.color!=rec.color:mat.diffuse_color=rec.color
        metadata(mat,was.metadata if was else {},rec.metadata)

def apply(ctx,old,new,import_registry=False):
    materials(old,new)
    original_objs={key:bpy.data.objects.get(key) for key in new.objects}
    for key,item in new.objects.items():
        ob=original_objs[key];prev=old.objects[key]
        if ob is None:continue
        if prev.name!=item.name:ob.name=item.name
        if prev.pass_index!=item.pass_index:ob.pass_index=item.pass_index
        if prev.color!=item.color:ob.color=item.color
        if prev.selected!=item.selected:ob.select_set(item.selected)
        if prev.slots!=item.slots and ob.data and hasattr(ob.data,"materials"):
            while len(ob.material_slots)>len(item.slots):ob.data.materials.pop(index=len(ob.material_slots)-1)
            for i,mat in enumerate(item.slots):
                desired=bpy.data.materials.get(mat) if mat else None
                if i>=len(ob.material_slots):ob.data.materials.append(desired)
                elif ob.material_slots[i].material!=desired:ob.material_slots[i].material=desired
        if prev.active_slot!=item.active_slot:ob.active_material_index=item.active_slot
        groups(ob,prev,item);metadata(ob,prev.metadata,item.metadata)
    seen=set()
    for key,obj in new.objects.items():
        if obj.mesh and obj.mesh.key not in seen and obj.mesh!=old.objects[key].mesh:
            mesh_values(original_objs[key],old.objects[key].mesh,obj.mesh);seen.add(obj.mesh.key)
    removed=set(old.collections)-set(new.collections)
    for n,members in new.collections.items():
        if n in old.collections and members==old.collections[n]:continue
        rename=next((k for k in removed if old.collections[k]==members and n not in old.collections),None)
        if rename:
            coll=bpy.data.collections[rename];coll.name=n;removed.remove(rename);continue
        coll=bpy.data.collections.get(n)
        if coll is None:
            coll=bpy.data.collections.new(n);ctx.scene.collection.children.link(coll)
        prev=old.collections.get(n,set())
        for k in members-prev:
            if k in original_objs and original_objs[k].name not in coll.objects:coll.objects.link(original_objs[k])
        for k in prev-members:
            if k in original_objs and original_objs[k].name in coll.objects:coll.objects.unlink(original_objs[k])
    for n in old.aovs.keys()-new.aovs.keys():
        a=ctx.view_layer.aovs.get(n)
        if a:
            ctx.view_layer.active_aov_index=list(ctx.view_layer.aovs).index(a)
            bpy.ops.scene.view_layer_remove_aov()
    for n,t in new.aovs.items():
        if old.aovs.get(n)==t:continue
        a=ctx.view_layer.aovs.get(n) or ctx.view_layer.aovs.add();a.name=n;a.type=t
    if import_registry:
        old_flag=int(ctx.scene.get("_smart_id_suite_registry_bank_v1",0))==1
        alternate=ctx.scene.smart_id_entries if old_flag else ctx.scene.smart_id_entries_staging
        nd.table(alternate,new.entries)
        ctx.scene["_smart_id_suite_registry_bank_v1"]=int(not old_flag)
    elif old.entries!=new.entries:nd.table(nd.entries(ctx.scene),new.entries)
    if old.inspector!=new.inspector:
        from copy import copy
        from .inspector_view import stored_uid
        rows=[]
        for item in new.inspector:
            row=copy(item);row.uid=stored_uid(row.uid);rows.append(row)
        nd.table(ctx.scene.smart_id_inspector_items,rows)
    if old.counts_signature!=new.counts_signature:
        import json
        new.settings.last_library_autosync_signature=json.dumps(new.counts_signature,ensure_ascii=False)
    if old.settings!=new.settings:nd.store_record(ctx.scene.smart_id_settings,new.settings)
    for key,attr in nd.ROOT_KEYS.items():
        if getattr(old,key)!=getattr(new,key):setattr(ctx.scene,attr,getattr(new,key))
    if old.inspector!=new.inspector or old.inspector_omitted!=new.inspector_omitted:
        ctx.scene.smart_id_inspector_total_count=len(new.inspector)+new.inspector_omitted
        ctx.scene.smart_id_inspector_truncated=new.inspector_omitted>0
    if new.active_object!=old.active_object and new.active_object in original_objs:ctx.view_layer.objects.active=original_objs[new.active_object]

