"""Map the scene and the view layer into the independent ID domain model."""
import bpy,bmesh
from .data_schema import Entry,Settings,InspectorItem,SCHEMA
from .model import State,Object,Mesh,Channel,Material,Vertex,Face
from .channels import BUCKET

TYPES={"settings":Settings,"entry":Entry,"inspector_item":InspectorItem}
ROOT_KEYS={"active_index":"smart_id_active_index","anchor_index":"smart_id_selection_anchor_index","inspector_index":"smart_id_inspector_active_index","inspector_anchor":"smart_id_inspector_selection_anchor_index","inspector_omitted":"smart_id_inspector_omitted_count"}
PREFIX="smart_id_suite_"
BUSY=False

def entries(scene):
    return scene.smart_id_entries_staging if scene.get("_smart_id_suite_registry_bank_v1",0)==1 else scene.smart_id_entries

def record(rna,kind):
    return TYPES[kind](**{n:(tuple(getattr(rna,n)) if f["type"]=="FloatVectorProperty" else getattr(rna,n)) for n,f in SCHEMA["records"][kind].items()})
def store_record(rna,data):
    for k in SCHEMA["records"][data._kind]:
        value=getattr(data,k);old=getattr(rna,k)
        if (tuple(old) if isinstance(value,tuple) else old)!=value:setattr(rna,k,value)
def table(collection,items):
    while len(collection)>len(items):collection.remove(len(collection)-1)
    for i,row in enumerate(items):store_record(collection[i] if i<len(collection) else collection.add(),row)
def read_meta(owner):
    raw=owner.get("smart_id_native_records")
    data=raw.to_dict() if hasattr(raw,"to_dict") else {}
    kind=owner.get(PREFIX+"type","")
    if kind:
        key={"OBJECT_ID":"object_id","MATERIAL_ID":"material_id","CRYPTOMATTE_ID":"identity","CUSTOM_ID":"identity"}.get(kind)
        key=key or "assigned_channel"
        if key:data[key]={k:owner.get(PREFIX+n,default) for k,n,default in (("uid","uid",""),("type","type",""),("name","name",""),("number","id_number",0),("tag","export_tag",""),("channel","channel_name",""))}
    mapping={v:int(k.rsplit("_",1)[1]) for k,v in owner.items() if k.startswith(PREFIX+"map_channel_") and k.rsplit("_",1)[-1].isdigit() and isinstance(v,str)}
    if mapping:data["map_channels"]=mapping
    if PREFIX+"udim_tile" in owner:data["udim_tile"]=int(owner[PREFIX+"udim_tile"])
    return {BUCKET:data} if data else {}
def mesh_state(obj,geometry):
    d=obj.data
    m=Mesh(d.name_full,d.name,readonly=not d.is_editable,metadata=read_meta(d))
    if obj.mode=="EDIT":obj.update_from_editmode()
    for x in d.uv_layers:m.uv[x.name]=Channel(x.name,"FLOAT2","CORNER",x.active,x.active_render,origin=x.name)
    for x in d.color_attributes:m.colors[x.name]=Channel(x.name,x.data_type,x.domain,x==d.color_attributes.active_color,origin=x.name)
    for x in d.attributes:
        if x.name not in m.uv and x.name not in m.colors:m.attributes[x.name]=Channel(x.name,x.data_type,x.domain,x==d.attributes.active,protected=x.is_required or x.is_internal or x.name.startswith("."),origin=x.name)
    if geometry:
        m.vertices=[Vertex(tuple(v.co),v.select,v.hide) for v in d.vertices]
        m.faces=[Face(tuple(f.vertices),f.material_index,f.select,f.hide,tuple(f.center)) for f in d.polygons]
    return m
def snapshot(ctx,geometry=False,library_only=False):
    scene=ctx.scene
    state=State(entries=[record(e,"entry") for e in entries(scene)],settings=record(scene.smart_id_settings,"settings"),inspector=[record(x,"inspector_item") for x in scene.smart_id_inspector_items])
    for key,attr in ROOT_KEYS.items():setattr(state,key,getattr(scene,attr))
    state.inspector_meta={}
    state.active_object=ctx.active_object.name_full if ctx.active_object else ""
    try:
        import json
        scope,active,selected=json.loads(state.settings.last_library_autosync_signature)
        state.counts_signature=(scope,active,tuple(selected))
    except (ValueError,TypeError):
        pass
    visible={o.name_full for o in ctx.view_layer.objects}
    scoped={o.name_full for o in scene.objects}
    state.scene_keys=[o.name_full for o in scene.objects]
    selected={o.name_full for o in ctx.selected_objects}
    cached={}
    for ob in (scene.objects if library_only else bpy.data.objects):
        key=ob.name_full
        obj=Object(key,ob.name,ob.type,pass_index=ob.pass_index,color=tuple(ob.color),selected=key in selected,readonly=not ob.is_editable,mode=ob.mode,hidden=key not in visible or not ob.visible_get(view_layer=ctx.view_layer))
        state.objects[key]=obj
        if library_only:continue
        owners=[(ob,"OBJECT","")]+[(slot.material,"MATERIAL",slot.material.name_full) for slot in ob.material_slots if slot.material]
        if ob.type=="MESH":owners.append((ob.data,"MESH",""))
        state.inspector_meta[key]=[]
        seen=set()
        for owner,group,material in owners:
            ident=(group,material)
            kind=owner.get(PREFIX+"type","")
            if ident in seen or not kind:continue
            seen.add(ident)
            token={"OBJECT_ID":"object_id","MATERIAL_ID":"material_id","CUSTOM_ID":"identity","CRYPTOMATTE_ID":"identity"}.get(kind,"assigned_channel")
            state.inspector_meta[key].append(dict(owner_data=group,material_name=material,key=token,name=owner.get(PREFIX+"name",owner.name),id_number=owner.get(PREFIX+"id_number",0),value_text=", ".join(k+"="+str(v) for k,v in owner.items() if k.startswith(PREFIX)),editable=owner.is_editable))
        obj.metadata=read_meta(ob);obj.slots=[slot.material.name_full if slot.material else None for slot in ob.material_slots]
        obj.active_slot=ob.active_material_index;obj.world_matrix=tuple(tuple(v) for v in ob.matrix_world);obj.box=tuple(tuple(v) for v in ob.bound_box)
        if ob.type=="MESH":
            if ob.data.name_full not in cached:cached[ob.data.name_full]=mesh_state(ob,geometry)
            obj.mesh=cached[ob.data.name_full]
            obj.groups={g.name:{} for g in ob.vertex_groups};obj.group_origins={g.name:g.name for g in ob.vertex_groups}
            obj.active_group=ob.vertex_groups.active.name if ob.vertex_groups.active else ""
            if geometry:
                for v in ob.data.vertices:
                    for weight in v.groups:
                        if weight.group<len(ob.vertex_groups):obj.groups[ob.vertex_groups[weight.group].name][v.index]=weight.weight
    if not library_only:
        state.materials={m.name_full:Material(m.name,m.pass_index,tuple(m.diffuse_color),read_meta(m),not m.is_editable,m.name) for m in bpy.data.materials}
        state.collections={c.name_full:{o.name_full for o in c.objects} for c in bpy.data.collections}
        state.collection_readonly={c.name_full for c in bpy.data.collections if not c.is_editable}
        state.aovs={a.name:a.type for a in ctx.view_layer.aovs}
    if not library_only and state.inspector:
        from . import inspection,inspector_view
        owners={row.owner_object for row in state.inspector}
        lookup={inspector_view.identity(row):row.uid for row in inspection.iter_items(state,owners)}
        for row in state.inspector:
            uid=lookup.get(inspector_view.identity(row))
            if uid:row.uid=uid
    return state

