# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Explicit-call-only SmartTools status compatibility for Smart ID Suite.

This module is deliberately isolated from Blender.  It does not import ``bpy``
and never intercepts, replaces, wraps, or inspects any process-global Blender
API.  No timer, handler, draw callback, msgbus subscription, thread, process,
socket, file watcher, or lifecycle hook is installed.

The small status store below changes only when a Smart ID caller explicitly
invokes one of these compatibility functions.  Resource instrumentation entry
points remain as inert no-ops for callers compiled against earlier Suite
versions.
"""

from contextlib import contextmanager
import time

_MAX_ENTRIES = 64
_MAX_TEXT_CHARS = 512
_MAX_KEY_CHARS = 192
_MAX_CACHE_BYTES = 256 * 1024
_STATE_VERSION = 3
_STATE = {
    "version": _STATE_VERSION,
    "sequence": 0,
    "entries": {},
    "current_bytes": 0,
    "peak_bytes": 0,
}


def _now():
    return float(time.monotonic())


def _bounded_text(value, limit=_MAX_TEXT_CHARS):
    return str(value or "")[: max(0, int(limit))]


def _entry_size(entry):
    if not isinstance(entry, dict):
        return 0
    size = 256
    for key, value in entry.items():
        size += len(str(key).encode("utf-8", "replace"))
        if isinstance(value, str):
            size += len(value.encode("utf-8", "replace"))
        else:
            size += 32
    return int(size)


def _recount():
    current = sum(_entry_size(item) for item in _STATE["entries"].values())
    _STATE["current_bytes"] = int(current)
    _STATE["peak_bytes"] = max(int(_STATE.get("peak_bytes", 0)), int(current))
    return current


def _prune_expired(now=None):
    now = _now() if now is None else float(now)
    expired = [
        key
        for key, item in tuple(_STATE["entries"].items())
        if isinstance(item, dict)
        and float(item.get("expires_at", 0.0) or 0.0) > 0.0
        and float(item.get("expires_at", 0.0)) <= now
    ]
    for key in expired:
        _STATE["entries"].pop(key, None)
    _recount()


def _oldest_key():
    entries = _STATE["entries"]
    try:
        return min(entries, key=lambda key: int(entries[key].get("sequence", 0)))
    except Exception:
        try:
            return next(iter(entries))
        except StopIteration:
            return None


def _trim_entries():
    _recount()
    while len(_STATE["entries"]) > _MAX_ENTRIES or int(_STATE["current_bytes"]) > _MAX_CACHE_BYTES:
        oldest = _oldest_key()
        if oldest is None:
            break
        _STATE["entries"].pop(oldest, None)
        _recount()


def _upsert(key, *, suite_id="", label="", text="", progress=None, ttl=0.0, kind="status"):
    _prune_expired()
    _STATE["sequence"] = int(_STATE.get("sequence", 0)) + 1
    now = _now()
    key_text = _bounded_text(key, _MAX_KEY_CHARS)
    entry = {
        "key": key_text,
        "suite_id": _bounded_text(suite_id, 128),
        "label": _bounded_text(label, 256),
        "text": _bounded_text(text, _MAX_TEXT_CHARS),
        "kind": _bounded_text(kind, 32),
        "progress": None if progress is None else max(0.0, min(1.0, float(progress))),
        "updated_at": now,
        "expires_at": now + max(0.0, float(ttl)) if float(ttl or 0.0) > 0.0 else 0.0,
        "sequence": _STATE["sequence"],
    }
    _STATE["entries"].pop(key_text, None)
    _STATE["entries"][key_text] = entry
    _trim_entries()
    return dict(entry)


def set_transient(key, text, *, suite_id="", label="", ttl=2.0, **_kwargs):
    return _upsert(key, suite_id=suite_id, label=label, text=text, ttl=ttl, kind="transient")


def set_service(key, text, *, suite_id="", label="", **_kwargs):
    return _upsert(key, suite_id=suite_id, label=label, text=text, ttl=0.0, kind="service")


def begin_task(key, text="", *, suite_id="", label="", progress=0.0, **_kwargs):
    return _upsert(key, suite_id=suite_id, label=label, text=text, progress=progress, ttl=0.0, kind="task")


def update_task(key, text="", *, suite_id="", label="", progress=None, **_kwargs):
    return _upsert(key, suite_id=suite_id, label=label, text=text, progress=progress, ttl=0.0, kind="task")


def finish_task(key, text="", *, suite_id="", label="", ttl=2.0, **_kwargs):
    return _upsert(key, suite_id=suite_id, label=label, text=text, progress=1.0, ttl=ttl, kind="transient")


def clear(key):
    removed = _STATE["entries"].pop(_bounded_text(key, _MAX_KEY_CHARS), None) is not None
    _recount()
    return removed


def clear_prefix(prefix):
    prefix = _bounded_text(prefix, _MAX_KEY_CHARS)
    keys = [key for key in tuple(_STATE["entries"]) if str(key).startswith(prefix)]
    for key in keys:
        _STATE["entries"].pop(key, None)
    _recount()
    return len(keys)


def clear_all():
    count = len(_STATE["entries"])
    _STATE["entries"].clear()
    _recount()
    return count


def snapshot():
    _prune_expired()
    return {
        "version": _STATE_VERSION,
        "sequence": int(_STATE.get("sequence", 0)),
        "entries": tuple(dict(item) for item in _STATE["entries"].values()),
        "current_bytes": int(_STATE.get("current_bytes", 0)),
        "peak_bytes": int(_STATE.get("peak_bytes", 0)),
        "hard_budget_bytes": _MAX_CACHE_BYTES,
        "resource_monitor_enabled": False,
        "api_capture_enabled": False,
        "blender_api_access": False,
    }


@contextmanager
def task_scope(key, text="", *, suite_id="", label="", **kwargs):
    begin_task(key, text, suite_id=suite_id, label=label, **kwargs)
    try:
        yield
    except Exception:
        clear(key)
        raise
    else:
        finish_task(key, text, suite_id=suite_id, label=label)


# ---------------------------------------------------------------------------
# Legacy resource-instrumentation compatibility: intentionally inert.
# ---------------------------------------------------------------------------

def disable_resource_monitor_unless_debug():
    return True


def instrument_operator_class(*_args, **_kwargs):
    return False


def instrument_loaded_package_operators(*_args, **_kwargs):
    return 0


def instrument_loaded_package_handlers(*_args, **_kwargs):
    return 0


def restore_package_handlers(*_args, **_kwargs):
    return 0


def prune_orphan_persistent_handler_markers(*_args, **_kwargs):
    return 0


@contextmanager
def capture_registration_callbacks(*_args, **_kwargs):
    yield


@contextmanager
def capture_runtime_resources(*_args, **_kwargs):
    yield
