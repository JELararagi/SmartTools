# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Discover existing data without changing it; validate before adding records."""
from uuid import uuid4
from .data_schema import Entry, ContractError, MAX_ENTRIES, checked_record
from .inspection import iter_items, entry_from_item
from .library import identity, next_number, channel_name
from .channels import CHANNEL_KINDS
from .matching import matches
from .assignment import PASS_INDEX_MAX

NUMBERED_TYPES = {'OBJECT_ID', 'MATERIAL_ID', 'CUSTOM_ID', 'CRYPTOMATTE_ID', 'MAP_CHANNEL'}


def make_entry(state, item):
    row = entry_from_item(state, item)
    existing = next((i for i, entry in enumerate(state.entries) if identity(entry) == identity(row)), None)
    if existing is not None:
        state.active_index = existing
        return False
    if len(state.entries) >= MAX_ENTRIES:
        raise ContractError('too_many_entries', count=len(state.entries))
    if row.type not in NUMBERED_TYPES:
        row.id_number = next_number(state.entries, row.type)
    state.entries.append(row)
    state.active_index = len(state.entries) - 1
    return True


def sync_entries(state, keys, include_aovs=False):
    known = {identity(row) for row in state.entries}
    pending = []
    skipped = []
    for item in iter_items(state, keys):
        if item.item_type in ('GEOMETRY_ATTRIBUTE', 'COLOR_ATTRIBUTE') and (item.name.startswith('.') or item.name == 'position'):
            skipped.append({'code': 'protected_data', 'name': item.name})
            continue
        try:
            row = entry_from_item(state, item, refresh=False)
        except ContractError as exc:
            if exc.code not in ('unsupported_attribute', 'metadata_not_entry', 'missing_active_data'):
                raise
            skipped.append({'code': exc.code, 'name': item.name})
            continue
        key = identity(row)
        if key in known:
            continue
        if row.type not in NUMBERED_TYPES:
            row.id_number = next_number(state.entries + pending, row.type)
        known.add(key)
        pending.append(row)
    if include_aovs:
        for name in state.aovs:
            row = Entry(uid=uuid4().hex, type='RENDER_AOV', name=name, export_tag=name, channel_name=name)
            if identity(row) not in known:
                row.id_number = next_number(state.entries + pending, row.type)
                known.add(identity(row))
                pending.append(row)
    if len(state.entries) + len(pending) > MAX_ENTRIES:
        raise ContractError('too_many_entries', count=len(state.entries) + len(pending))
    for row in pending:
        checked_record(row)
    state.entries.extend(pending)
    if state.active_index < 0 and state.entries:
        state.active_index = 0
    return {'added': len(pending), 'skipped': skipped}


def validate_registry(state):
    issues = []
    identities = set()
    uids = set()
    for row in state.entries:
        if not row.enabled and not state.settings.include_disabled:
            continue
        def issue(code, **values):
            issues.append({'code': code, 'uid': row.uid, 'values': values})
        try:
            checked_record(row)
        except ContractError as exc:
            issue(exc.code, **exc.values)
            continue
        if not row.name.strip():
            issue('empty_name')
        if not row.uid or row.uid in uids:
            issue('duplicate_uid')
        uids.add(row.uid)
        key = identity(row)
        if key in identities:
            issue('duplicate_entry', name=row.name)
        identities.add(key)
        if row.type in ('OBJECT_ID', 'MATERIAL_ID') and row.id_number > PASS_INDEX_MAX:
            issue('pass_index_range', number=row.id_number, limit=PASS_INDEX_MAX)
        if row.type in CHANNEL_KINDS:
            missing = sum(1 for key in state.scope('SCENE') if state.objects[key].mesh is not None and not matches(state, state.objects[key], row))
            if missing:
                issue('missing_channel', name=channel_name(row), count=missing)
    return issues
