import json
from pathlib import Path
import bpy
from bpy.app.handlers import persistent
from . import native_data as nd,overlay,io_codec,inspection,native_commit,matching
cache={}
draw_handles=[]
last_selection={}
settings_pending=False
def pref_file():
    return Path(bpy.utils.user_resource("CONFIG"))/"Smart_ID_Suite"/"Smart_ID_Suite.json"
def flush():
    global settings_pending
    settings_pending=False
    ctx=bpy.context
    if getattr(ctx,"scene",None) and hasattr(ctx.scene,"smart_id_settings"):
        cfg=ctx.scene.smart_id_settings
        if cfg.n_panel_state_save:
            path=pref_file();path.parent.mkdir(parents=True,exist_ok=True)
            io_codec.write_atomic(path,io_codec.encode_settings(nd.record(cfg,"settings")))
    return None
def setting_changed(ctx):
    global settings_pending
    cache.clear()
    if nd.BUSY or not ctx or not getattr(ctx,"scene",None):return
    if bpy.app.timers.is_registered(load_prefs):
        bpy.app.timers.unregister(load_prefs)
    sync_hooks()
    if not ctx.scene.smart_id_settings.n_panel_state_save:
        if bpy.app.timers.is_registered(flush):bpy.app.timers.unregister(flush)
        settings_pending=False
    elif not bpy.app.timers.is_registered(flush):
        settings_pending=True;bpy.app.timers.register(flush,first_interval=.3)
def load_prefs():
    if not getattr(bpy.context,"scene",None):return
    file=pref_file()
    if not file.exists():sync_hooks();return
    try:
        settings=io_codec.decode_settings(io_codec.read_text(file))
        nd.BUSY=True;nd.store_record(bpy.context.scene.smart_id_settings,settings)
    except (ValueError,OSError):pass
    finally:nd.BUSY=False
    sync_hooks()
def clear_stale(scene):
    if not scene.smart_id_settings.always_on_automatic_metadata_cleanup:return
    scene.smart_id_inspector_items.clear()
    scene.smart_id_inspector_active_index=-1;scene.smart_id_inspector_selection_anchor_index=-1
    scene.smart_id_inspector_total_count=0;scene.smart_id_inspector_omitted_count=0;scene.smart_id_inspector_truncated=False
    for obj in scene.objects:
        if obj.type!="MESH" or not obj.data.is_editable:continue
        mesh=obj.data
        for key in tuple(mesh.keys()):
            if key.startswith(nd.PREFIX+"map_channel_") and isinstance(mesh[key],str) and mesh.uv_layers.get(mesh[key]) is None:del mesh[key]
        bucket=mesh.get("smart_id_native_records")
        if bucket and "map_channels" in bucket:
            layers=bucket["map_channels"]
            for name in tuple(layers.keys()):
                if not mesh.uv_layers.get(name):del layers[name]
@persistent
def save_scene(*_):
    if settings_pending:flush()
    for scene in bpy.data.scenes:clear_stale(scene)
@persistent
def before_load(*_):
    if settings_pending:flush()
@persistent
def loaded(*_):
    cache.clear();last_selection.clear();load_prefs();sync_hooks()
    for scene in bpy.data.scenes:clear_stale(scene)
@persistent
def deps(scene,graph):
    cache.clear()
    if nd.BUSY or not getattr(bpy.context,"view_layer",None) or not hasattr(scene,"smart_id_settings"):return
    cfg=scene.smart_id_settings
    if not cfg.always_on_selection_inspector:return
    ctx=bpy.context
    if ctx.scene!=scene:return
    sig=(ctx.view_layer.name,ctx.active_object.name_full if ctx.active_object else "",tuple(sorted(o.name_full for o in ctx.selected_objects)))
    if last_selection.get(scene.as_pointer())==sig:return
    last_selection[scene.as_pointer()]=sig
    if not bpy.app.timers.is_registered(refresh):bpy.app.timers.register(refresh,first_interval=.1)
def refresh():
    if nd.BUSY:return .2
    ctx=bpy.context
    if getattr(ctx,"scene",None) and ctx.scene.smart_id_settings.always_on_selection_inspector:
        nd.BUSY=True
        try:
            old=nd.snapshot(ctx);new=old.clone();inspection.refresh_inspector(new);matching.refresh_counts(new);native_commit.apply(ctx,old,new)
        finally:nd.BUSY=False
    return None
def picture(ctx):
    cfg=ctx.scene.smart_id_settings
    if not cfg.overlay_enabled:return None
    key=(ctx.scene.as_pointer(),ctx.view_layer.as_pointer(),ctx.scene.smart_id_active_index,ctx.scene.smart_id_inspector_active_index,bpy.app.translations.locale)
    if key not in cache:
        data=nd.snapshot(ctx,geometry=cfg.overlay_element_marks)
        from .blender_ui import label,title
        cache[key]=overlay.build_overlay(data,label_for=lambda kind,name:label(title(kind.lower()))+" · "+name)
    return cache[key]
def draw3():
    import gpu
    from gpu_extras.batch import batch_for_shader
    ctx=bpy.context;snap=picture(ctx)
    if not snap:return
    shader=gpu.shader.from_builtin("UNIFORM_COLOR")
    old=gpu.state.blend_get();width=gpu.state.line_width_get()
    try:
        gpu.state.blend_set("ALPHA");gpu.state.line_width_set(ctx.scene.smart_id_settings.overlay_line_width)
        for row in snap.records:
            points=[co for pair in row.segments for co in pair]
            shader.bind();shader.uniform_float("color",row.color)
            if points:batch_for_shader(shader,"LINES",{"pos":points}).draw(shader)
            if row.marks:batch_for_shader(shader,"POINTS",{"pos":row.marks}).draw(shader)
    finally:gpu.state.line_width_set(width);gpu.state.blend_set(old)
def draw2():
    import blf
    from bpy_extras.view3d_utils import location_3d_to_region_2d
    ctx=bpy.context;snap=picture(ctx)
    if not snap:return
    for label in snap.labels:
        screen=location_3d_to_region_2d(ctx.region,ctx.region_data,label.position)
        if screen is not None:
            blf.position(0,screen.x,screen.y,0);blf.size(0,13);blf.color(0,*label.color);blf.draw(0,label.text)
def sync_hooks():
    scenes=getattr(bpy.data,"scenes",())
    configs=[s.smart_id_settings for s in scenes if hasattr(s,"smart_id_settings")]
    save=any(c.n_panel_state_save for c in configs)
    cleanup=any(c.always_on_automatic_metadata_cleanup for c in configs)
    inspector=any(c.always_on_selection_inspector for c in configs)
    overlay_on=any(c.overlay_enabled for c in configs)
    for hooks,fn,needed in ((bpy.app.handlers.load_pre,before_load,save),(bpy.app.handlers.load_post,loaded,save or cleanup or inspector or overlay_on),(bpy.app.handlers.save_pre,save_scene,save or cleanup),(bpy.app.handlers.depsgraph_update_post,deps,inspector or overlay_on)):
        if needed and fn not in hooks:hooks.append(fn)
        elif not needed and fn in hooks:hooks.remove(fn)
    if not inspector and bpy.app.timers.is_registered(refresh):bpy.app.timers.unregister(refresh)
    if not bpy.app.background and overlay_on and not draw_handles:
        for fn,phase in ((draw3,"POST_VIEW"),(draw2,"POST_PIXEL")):
            draw_handles.append(bpy.types.SpaceView3D.draw_handler_add(fn,(),"WINDOW",phase))
    if not overlay_on:
        while draw_handles:bpy.types.SpaceView3D.draw_handler_remove(draw_handles.pop(),"WINDOW")
        cache.clear()
def register():
    if getattr(bpy.context,"scene",None):load_prefs();sync_hooks()
    elif not bpy.app.timers.is_registered(load_prefs):bpy.app.timers.register(load_prefs,first_interval=.1)
def unregister():
    global settings_pending
    for fn in (refresh,flush,load_prefs):
        if bpy.app.timers.is_registered(fn):bpy.app.timers.unregister(fn)
    if settings_pending:flush()
    settings_pending=False
    for arr,fn in ((bpy.app.handlers.load_pre,before_load),(bpy.app.handlers.save_pre,save_scene),(bpy.app.handlers.load_post,loaded),(bpy.app.handlers.depsgraph_update_post,deps)):
        if fn in arr:arr.remove(fn)
    while draw_handles:bpy.types.SpaceView3D.draw_handler_remove(draw_handles.pop(),"WINDOW")
    cache.clear();last_selection.clear()
