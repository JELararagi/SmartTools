# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Validated JSON/CSV interchange and same-directory atomic file replacement."""
import csv
import io
import json
import os
from pathlib import Path
import tempfile
from uuid import uuid4,UUID
from .data_schema import ContractError, MAX_ENTRIES, from_dict, to_dict, checked_record

REGISTRY_SCHEMA = 'smart_id_suite.registry.v1'
SETTINGS_SCHEMA = 'smart_id_suite.npanel_settings.v1'
MAX_BYTES = 32 * 1024 * 1024


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ContractError('duplicate_json_key', field=key)
        result[key] = value
    return result


def _constant(value):
    raise ContractError('invalid_json_number', field=value)


def parse_json(text):
    if not isinstance(text, str) or len(text.encode('utf-8')) > MAX_BYTES:
        raise ContractError('input_too_large')
    try:
        return json.loads(text.lstrip('\ufeff'), object_pairs_hook=_pairs, parse_constant=_constant)
    except (json.JSONDecodeError, RecursionError) as exc:
        raise ContractError('invalid_json') from exc


def encode_registry(entries, include_disabled=False):
    rows = [to_dict(checked_record(e)) for e in entries if include_disabled or e.enabled]
    if len(rows) > MAX_ENTRIES:
        raise ContractError('too_many_entries', count=len(rows))
    return json.dumps({**{'schema': 'smart_id_suite.registry.v1', 'version': '1.0.0', 'type': 'smart_id_suite.registry', 'addon': 'Smart ID Suite', 'author': 'JELararagi', 'license': 'SPDX-License-Identifier: GPL-3.0-or-later', 'copyright': 'Copyright (C) 2026 JELararagi', 'blender_version_min': '5.1.0'},'entries': rows}, ensure_ascii=False, indent=2, allow_nan=False) + '\n'


def decode_registry(text,strict_uid=False):
    payload = parse_json(text)
    if not isinstance(payload, dict) or payload.get('schema') != REGISTRY_SCHEMA:
        raise ContractError('invalid_schema')
    rows = payload.get('entries')
    if not isinstance(rows, list) or len(rows) > MAX_ENTRIES:
        raise ContractError('invalid_entries')
    result = [from_dict('entry', row) for row in rows]
    seen = set()
    for row in result:
        if not row.uid:
            row.uid = uuid4().hex
        if strict_uid:
            try:row.uid=UUID(row.uid).hex
            except (TypeError,ValueError,AttributeError):raise ContractError('invalid_field',field='uid') from None
        if row.uid in seen:
            raise ContractError('duplicate_uid', field=row.uid)
        seen.add(row.uid)
    return result


def prepare_import(existing, text, clear=False, strict_uid=False):
    incoming = decode_registry(text, strict_uid=strict_uid)
    kept = [] if clear else list(existing)
    if len(kept) + len(incoming) > MAX_ENTRIES:
        raise ContractError('too_many_entries', count=len(kept) + len(incoming))
    taken = {row.uid for row in kept}
    for row in incoming:
        if row.uid in taken:
            row.uid = uuid4().hex
        taken.add(row.uid)
    return kept + incoming


def encode_csv(entries, include_disabled=False):
    rows = [to_dict(checked_record(e)) for e in entries if include_disabled or e.enabled]
    from .data_schema import SCHEMA
    fields = ['uid', 'enabled', 'locked', 'type', 'name', 'id_number', 'map_channel', 'channel_name', 'uv_map', 'color_attribute', 'attribute_name', 'attribute_type', 'attribute_domain', 'group_name', 'material_name', 'udim_tile', 'export_tag', 'notes']
    out = io.StringIO(newline='')
    writer = csv.DictWriter(out, fieldnames=fields, extrasaction='ignore', lineterminator='\r\n')
    writer.writeheader()
    for row in rows:
        row['color'] = json.dumps(row['color'], separators=(',', ':'))
        writer.writerow(row)
    return out.getvalue()


def encode_settings(settings):
    return json.dumps({'schema': SETTINGS_SCHEMA,'type':'smart_id_suite.settings','version':'1.0.0','settings': {k:v for k,v in to_dict(checked_record(settings)).items() if k not in {'last_report','last_report_language'}}}, ensure_ascii=False, indent=2, allow_nan=False) + '\n'


def decode_settings(text):
    payload = parse_json(text)
    if not isinstance(payload, dict) or payload.get('schema') != SETTINGS_SCHEMA:
        raise ContractError('invalid_schema')
    return from_dict('settings', payload.get('settings'))


def read_text(path):
    with Path(path).open('rb') as stream:
        raw = stream.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ContractError('input_too_large')
    try:
        return raw.decode('utf-8-sig')
    except UnicodeDecodeError as exc:
        raise ContractError('invalid_encoding') from exc


def write_atomic(path, text):
    path = Path(path)
    if not path.name or not path.parent.is_dir():
        raise ContractError('invalid_path')
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', newline='\n', dir=path.parent, prefix='.' + path.name + '.smartid-', suffix='.tmp', delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        temporary = None
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()
