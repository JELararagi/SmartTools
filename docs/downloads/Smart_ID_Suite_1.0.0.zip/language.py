# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Independent Japanese and English messages. One locale per rendered string."""
CATALOG = {
    'report_renumbered_entries': ('Renumbered {count} entries', '{count}件の項目に番号を付け直しました'),
}


def tr(key, locale='en_US', **values):
    if key not in CATALOG:
        raise KeyError('Unregistered SmartID message: ' + key)
    return CATALOG[key][1 if str(locale).startswith('ja') else 0].format(**values) if values else CATALOG[key][1 if str(locale).startswith('ja') else 0]
