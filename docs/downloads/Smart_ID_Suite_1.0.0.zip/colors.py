# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Original deterministic color mapping; no palette or third-party image assets."""
import colorsys
import hashlib
from .data_schema import ContractError, MAX_ID


def generated_color(number):
    if type(number) is not int or not 0 <= number <= MAX_ID:
        raise ContractError('invalid_field', field='id_number')
    hue = (number * 0.618033988749895) % 1.0
    return (*colorsys.hsv_to_rgb(hue,0.62,0.88),1.0)


def named_color(name):
    value = int.from_bytes(hashlib.sha256(name.encode('utf-8')).digest()[:4], 'big') & MAX_ID
    return generated_color(value)
