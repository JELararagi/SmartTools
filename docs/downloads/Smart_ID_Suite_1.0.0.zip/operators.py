import bpy
from . import native_schema,commands

class SMARTID_OT_add_entry(bpy.types.Operator):
    bl_idname='smart_id.add_entry'
    bl_label='Add Entry'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.add_entry')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_apply_entry(bpy.types.Operator):
    bl_idname='smart_id.apply_entry'
    bl_label='Apply Entry'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.apply_entry')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_channel_apply(bpy.types.Operator):
    bl_idname='smart_id.channel_apply'
    bl_label='Channel Apply'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.channel_apply')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_channel_delete(bpy.types.Operator):
    bl_idname='smart_id.channel_delete'
    bl_label='Channel Delete'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.channel_delete')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_create_aov(bpy.types.Operator):
    bl_idname='smart_id.create_aov'
    bl_label='Create Aov'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.create_aov')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_create_collection(bpy.types.Operator):
    bl_idname='smart_id.create_collection'
    bl_label='Create Collection'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.create_collection')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_create_materials(bpy.types.Operator):
    bl_idname='smart_id.create_materials'
    bl_label='Create Materials'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.create_materials')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_deselect_by_entry(bpy.types.Operator):
    bl_idname='smart_id.deselect_by_entry'
    bl_label='Deselect By Entry'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.deselect_by_entry')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_duplicate_entry(bpy.types.Operator):
    bl_idname='smart_id.duplicate_entry'
    bl_label='Duplicate Entry'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.duplicate_entry')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_entry_clear_selection(bpy.types.Operator):
    bl_idname='smart_id.entry_clear_selection'
    bl_label='Entry Clear Selection'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.entry_clear_selection')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_entry_delete_selected(bpy.types.Operator):
    bl_idname='smart_id.entry_delete_selected'
    bl_label='Entry Delete Selected'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.entry_delete_selected')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_entry_multi_select(bpy.types.Operator):
    bl_idname='smart_id.entry_multi_select'
    bl_label='Entry Multi Select'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.entry_multi_select')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_entry_select_visible(bpy.types.Operator):
    bl_idname='smart_id.entry_select_visible'
    bl_label='Entry Select Visible'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.entry_select_visible')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_export_csv(bpy.types.Operator):
    bl_idname='smart_id.export_csv'
    bl_label='Export Csv'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.export_csv')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_export_json(bpy.types.Operator):
    bl_idname='smart_id.export_json'
    bl_label='Export Json'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.export_json')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_import_json(bpy.types.Operator):
    bl_idname='smart_id.import_json'
    bl_label='Import Json'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.import_json')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_inspector_apply(bpy.types.Operator):
    bl_idname='smart_id.inspector_apply'
    bl_label='Inspector Apply'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.inspector_apply')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_inspector_apply_entry(bpy.types.Operator):
    bl_idname='smart_id.inspector_apply_entry'
    bl_label='Inspector Apply Entry'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.inspector_apply_entry')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_inspector_assign_selection(bpy.types.Operator):
    bl_idname='smart_id.inspector_assign_selection'
    bl_label='Inspector Assign Selection'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.inspector_assign_selection')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_inspector_clear_selection(bpy.types.Operator):
    bl_idname='smart_id.inspector_clear_selection'
    bl_label='Inspector Clear Selection'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.inspector_clear_selection')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_inspector_delete(bpy.types.Operator):
    bl_idname='smart_id.inspector_delete'
    bl_label='Inspector Delete'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.inspector_delete')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_inspector_delete_selected(bpy.types.Operator):
    bl_idname='smart_id.inspector_delete_selected'
    bl_label='Inspector Delete Selected'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.inspector_delete_selected')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_inspector_make_entry(bpy.types.Operator):
    bl_idname='smart_id.inspector_make_entry'
    bl_label='Inspector Make Entry'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.inspector_make_entry')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_inspector_multi_select(bpy.types.Operator):
    bl_idname='smart_id.inspector_multi_select'
    bl_label='Inspector Multi Select'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.inspector_multi_select')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_inspector_refresh(bpy.types.Operator):
    bl_idname='smart_id.inspector_refresh'
    bl_label='Inspector Refresh'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.inspector_refresh')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_inspector_select_elements(bpy.types.Operator):
    bl_idname='smart_id.inspector_select_elements'
    bl_label='Inspector Select Elements'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.inspector_select_elements')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_inspector_select_owner(bpy.types.Operator):
    bl_idname='smart_id.inspector_select_owner'
    bl_label='Inspector Select Owner'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.inspector_select_owner')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_inspector_select_visible(bpy.types.Operator):
    bl_idname='smart_id.inspector_select_visible'
    bl_label='Inspector Select Visible'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.inspector_select_visible')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_inspector_unassign_selection(bpy.types.Operator):
    bl_idname='smart_id.inspector_unassign_selection'
    bl_label='Inspector Unassign Selection'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.inspector_unassign_selection')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_move_entry(bpy.types.Operator):
    bl_idname='smart_id.move_entry'
    bl_label='Move Entry'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.move_entry')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_open_help(bpy.types.Operator):
    bl_idname='smart_id.open_help'
    bl_label='Open Help'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.open_help')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_read_active(bpy.types.Operator):
    bl_idname='smart_id.read_active'
    bl_label='Read Active'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.read_active')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_refresh_counts(bpy.types.Operator):
    bl_idname='smart_id.refresh_counts'
    bl_label='Refresh Counts'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.refresh_counts')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_remove_entry(bpy.types.Operator):
    bl_idname='smart_id.remove_entry'
    bl_label='Remove Entry'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.remove_entry')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_renumber_entries(bpy.types.Operator):
    bl_idname='smart_id.renumber_entries'
    bl_label='Renumber Entries'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.renumber_entries')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_select_by_entry(bpy.types.Operator):
    bl_idname='smart_id.select_by_entry'
    bl_label='Select By Entry'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.select_by_entry')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_select_entry_elements(bpy.types.Operator):
    bl_idname='smart_id.select_entry_elements'
    bl_label='Select Entry Elements'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.select_entry_elements')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_sort_entries(bpy.types.Operator):
    bl_idname='smart_id.sort_entries'
    bl_label='Sort Entries'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.sort_entries')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_sync_from_scene(bpy.types.Operator):
    bl_idname='smart_id.sync_from_scene'
    bl_label='Sync From Scene'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.sync_from_scene')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_sync_from_selection(bpy.types.Operator):
    bl_idname='smart_id.sync_from_selection'
    bl_label='Sync From Selection'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.sync_from_selection')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_toggle_ui_section(bpy.types.Operator):
    bl_idname='smart_id.toggle_ui_section'
    bl_label='Toggle Ui Section'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.toggle_ui_section')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_unassign_entry(bpy.types.Operator):
    bl_idname='smart_id.unassign_entry'
    bl_label='Unassign Entry'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.unassign_entry')
    execute=commands.execute
    invoke=commands.invoke

class SMARTID_OT_validate_registry(bpy.types.Operator):
    bl_idname='smart_id.validate_registry'
    bl_label='Validate Registry'
    bl_options={'UNDO'}
    __annotations__=native_schema.arguments('smart_id.validate_registry')
    execute=commands.execute
    invoke=commands.invoke

CLASSES=(SMARTID_OT_add_entry,SMARTID_OT_apply_entry,SMARTID_OT_channel_apply,SMARTID_OT_channel_delete,SMARTID_OT_create_aov,SMARTID_OT_create_collection,SMARTID_OT_create_materials,SMARTID_OT_deselect_by_entry,SMARTID_OT_duplicate_entry,SMARTID_OT_entry_clear_selection,SMARTID_OT_entry_delete_selected,SMARTID_OT_entry_multi_select,SMARTID_OT_entry_select_visible,SMARTID_OT_export_csv,SMARTID_OT_export_json,SMARTID_OT_import_json,SMARTID_OT_inspector_apply,SMARTID_OT_inspector_apply_entry,SMARTID_OT_inspector_assign_selection,SMARTID_OT_inspector_clear_selection,SMARTID_OT_inspector_delete,SMARTID_OT_inspector_delete_selected,SMARTID_OT_inspector_make_entry,SMARTID_OT_inspector_multi_select,SMARTID_OT_inspector_refresh,SMARTID_OT_inspector_select_elements,SMARTID_OT_inspector_select_owner,SMARTID_OT_inspector_select_visible,SMARTID_OT_inspector_unassign_selection,SMARTID_OT_move_entry,SMARTID_OT_open_help,SMARTID_OT_read_active,SMARTID_OT_refresh_counts,SMARTID_OT_remove_entry,SMARTID_OT_renumber_entries,SMARTID_OT_select_by_entry,SMARTID_OT_select_entry_elements,SMARTID_OT_sort_entries,SMARTID_OT_sync_from_scene,SMARTID_OT_sync_from_selection,SMARTID_OT_toggle_ui_section,SMARTID_OT_unassign_entry,SMARTID_OT_validate_registry,)
