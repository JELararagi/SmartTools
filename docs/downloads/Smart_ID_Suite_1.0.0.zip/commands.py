"""UI operations shared by the sidebar, search menu and scripted callers."""
from pathlib import Path
from uuid import uuid4
import json
import bpy
from . import native_data as nd,native_commit as commit,assignment as assign,inspection as inspect,inspection_edit as edit
from . import library as lib,matching,synchronization as sync,io_codec,renumber_bridge
from .data_schema import ContractError
PATTERNS=json.loads(Path(__file__).with_name("naming_patterns.json").read_text("utf8"))
LIB_ONLY={"add_entry","remove_entry","duplicate_entry","move_entry","sort_entries","renumber_entries","entry_select_visible","entry_clear_selection","entry_delete_selected","entry_multi_select","toggle_ui_section","export_json","export_csv","import_json","inspector_multi_select","inspector_select_visible","inspector_clear_selection"}
GEOMETRY={"apply_entry","channel_apply","channel_delete","unassign_entry","inspector_apply","inspector_delete","inspector_delete_selected","inspector_apply_entry","inspector_assign_selection","inspector_unassign_selection","inspector_select_elements","select_entry_elements"}
def kind(op):return op.bl_idname.lower().split("_ot_")[-1].split(".")[-1]
def pick_row(state,op,inspect_mode,key):
    rows=state.inspector if inspect_mode else state.entries
    active="inspector_index" if inspect_mode else "active_index";anchor="inspector_anchor" if inspect_mode else "anchor_index"
    visible=inspect.visible_inspector_indices(state) if inspect_mode else lib.visible_indices(state)
    if key.endswith("clear_selection"):
        for item in rows:item.selected=False
    elif key.endswith("select_visible"):
        for i in visible:rows[i].selected=True
    else:
        lib.toggle_check(rows,op.index,visible,getattr(state,anchor),op.extend)
        setattr(state,anchor,op.index);setattr(state,active,op.index)
def add(state,op):
    typ=op.entry_type if op.properties.is_property_set("entry_type") else state.settings.new_entry_type
    entry=lib.add_entry(state,typ)
    n=entry.id_number
    if typ=='MAP_CHANNEL':entry.uv_map=''
    if typ=='COLOR_ATTRIBUTE':entry.attribute_domain='CORNER'
    for key,template in PATTERNS[state.settings.naming_profile][typ].items():
        setattr(entry,key,template.format(n=n,tile=1000+n))
    entry.map_channel=min(n,999);entry.udim_tile=min(1000+n,9999)
def inspect_actions(state,key):
    if key=="inspector_refresh":return inspect.refresh_inspector(state)
    rows=inspect.action_items(state) if key=="inspector_delete_selected" else [inspect.active_item(state)]
    if not rows:raise ContractError("no_inspector_item")
    if key=="inspector_select_owner":
        obj,_=inspect.current_item(state,rows[0])
        for x in state.objects.values():x.selected=x==obj
        state.active_object=obj.key;return
    for row in rows:
        if key in {"inspector_delete","inspector_delete_selected"}:edit.delete_item(state,row)
        elif key=="inspector_apply":edit.edit_item(state,row)
        elif key=="inspector_apply_entry":edit.apply_entry_to_item(state,lib.active_entry(state),row)
        elif key=="inspector_make_entry":
            entry=inspect.entry_from_item(state,row);state.entries.append(entry);state.active_index=len(state.entries)-1
        elif key=="inspector_select_elements":
            entry=inspect.entry_from_item(state,row)
            if row.item_type=="MATERIAL_ID":
                owner,_=inspect.current_item(state,row)
                for face in owner.mesh.faces:
                    if not face.hidden:face.selected=face.material_index==row.slot_index
            else:matching.select_elements(state,[entry],keys=[row.owner_object])
        elif key in {"inspector_assign_selection","inspector_unassign_selection"}:
            entry=inspect.entry_from_item(state,row);assign.apply_entries(state,[entry],keys=state.scope("SELECTED"),remove=key=="inspector_unassign_selection")
        else:raise ContractError("unsupported_inspector_type",kind=key)
    if key in {"inspector_apply","inspector_apply_entry","inspector_delete","inspector_delete_selected"}:inspect.refresh_inspector(state)
def registry_report(state):
    issues=sync.validate_registry(state)
    known={};lines=[]
    for e in state.entries:
        if not e.enabled and not state.settings.include_disabled:continue
        ident=lib.identity(e)
        if ident in known:lines.append(f"[Warning] Duplicate {e.type} ID {e.id_number}: {known[ident]} / {e.name}")
        known[ident]=e.name
    lines += ["[Warning] "+r["code"] for r in issues if r["code"]!="duplicate_entry"]
    return "\n".join(["Smart ID Suite Validation",*lines,f"Warnings: {len(lines)}"])
def operate(state,op,ctx):
    key=kind(op)
    if key.endswith(("multi_select","clear_selection","select_visible")):return pick_row(state,op,key.startswith("inspector"),key)
    if key.startswith("inspector_"):return inspect_actions(state,key)
    if key=="add_entry":return add(state,op)
    if key=="remove_entry":return lib.remove_entries(state,[state.active_index])
    if key=="entry_delete_selected":return lib.remove_entries(state,lib.selected_indices(state))
    if key=="duplicate_entry":
        original=lib.active_entry(state).name;duplicate=lib.duplicate_entry(state);duplicate.name=original+'_Copy';state.entries.remove(duplicate);state.entries.append(duplicate);state.active_index=len(state.entries)-1;return
    if key=="move_entry":return lib.move_entry(state,op.direction)
    if key=="sort_entries":return lib.sort_entries(state)
    if key=="renumber_entries":
        status,_,reports=renumber_bridge.renumber(state,bpy.app.translations.locale)
        if "CANCELLED" in status:raise ValueError(reports[-1][-1] if reports else "Select an unlocked registry row")
        return
    if key=="refresh_counts":return matching.refresh_counts(state)
    if key in {"sync_from_scene","sync_from_selection"}:
        return sync.sync_entries(state,state.scope("SCENE" if key.endswith("scene") else "SELECTED"),key.endswith("scene"))
    if key in {"select_by_entry","deselect_by_entry"}:return matching.select_objects(state,lib.action_entries(state),deselect=key.startswith("deselect"))
    if key=="select_entry_elements":return matching.select_elements(state,lib.action_entries(state))
    if key=="read_active":return assign.read_active(state,lib.active_entry(state))
    if key in {"apply_entry","unassign_entry","channel_apply","channel_delete"}:
        rows=lib.action_entries(state,True)
        names=[e.material_name for e in rows]
        for e in rows:
            if e.type=="MATERIAL_ID" and not e.material_name:e.material_name="SIS_"+e.name.strip().replace(" ","_")
        result=assign.apply_entries(state,rows,channel_only=key.startswith("channel"),remove=key in {"unassign_entry","channel_delete"})
        for e,old_name in zip(rows,names):
            if e.type=="MATERIAL_ID":e.material_name=old_name
        return result
    if key=="create_materials":
        for row in state.entries:
            if row.type=="MATERIAL_ID" and row.enabled and not row.locked:
                previous=row.material_name
                if not previous:row.material_name="SIS_"+row.name.strip().replace(" ","_")
                assign.ensure_material(state,row,True)
                row.material_name=previous
        return
    if key=="create_aov":
        for row in lib.action_entries(state,True):
            if row.type=="RENDER_AOV":state.aovs.setdefault(lib.channel_name(row),"COLOR")
        return
    if key=="create_collection":return assign.create_collection(state,lib.active_entry(state),state.scope("SELECTED"))
    if key=="validate_registry":
        text=bpy.data.texts.get("Smart ID Suite Validation") or bpy.data.texts.new("Smart ID Suite Validation")
        text.from_string(registry_report(state));return
    if key=="toggle_ui_section":
        if not op.section_key.startswith("ui_section_") or not hasattr(state.settings,op.section_key):raise ValueError("Unknown sidebar section")
        setattr(state.settings,op.section_key,not getattr(state.settings,op.section_key));return
    if key=="import_json":
        state.entries=io_codec.prepare_import(state.entries,io_codec.read_text(op.filepath),state.settings.clear_on_import,strict_uid=True)
        state.active_index=0 if state.entries else -1;return
    if key in {"export_json","export_csv"}:
        content=(io_codec.encode_registry if key=="export_json" else io_codec.encode_csv)(state.entries,state.settings.include_disabled)
        return io_codec.write_atomic(op.filepath,content)
    raise ValueError("Unknown Smart ID operation")
def execute(op,ctx):
    key=kind(op)
    if key=="open_help":
        from .blender_ui import help_popup
        return help_popup(op,ctx)
    if nd.BUSY:return {"CANCELLED"}
    nd.BUSY=True
    try:
        before=nd.snapshot(ctx,key in GEOMETRY,key in LIB_ONLY)
        state=before.clone()
        operate(state,op,ctx)
        try:commit.apply(ctx,before,state,import_registry=key=="import_json")
        except Exception:
            live=nd.snapshot(ctx,key in GEOMETRY,key in LIB_ONLY)
            commit.apply(ctx,live,before)
            raise
        if ctx.area:ctx.area.tag_redraw()
        return {"FINISHED"}
    except (ValueError,TypeError,KeyError,IndexError,RuntimeError,OSError,AttributeError) as exc:
        op.report({"WARNING"},str(exc));return {"CANCELLED"}
    finally:nd.BUSY=False
def invoke(op,ctx,event):
    key=kind(op)
    if key in {"import_json","export_json","export_csv"}:
        ctx.window_manager.fileselect_add(op);return {"RUNNING_MODAL"}
    if hasattr(op,"extend"):op.extend=event.shift
    return execute(op,ctx)

