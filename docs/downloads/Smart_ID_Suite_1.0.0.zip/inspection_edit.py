# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Edits planned on detached state; references and protection are checked again."""
from copy import deepcopy
from .data_schema import ContractError, checked_record
from .inspection import current_item, decode_reference, reference
from .channels import metadata, edit_metadata, check_editable, bucket_for, rename_channel
from .assignment import PASS_INDEX_MAX, update_material, apply_entries, remember
from .library import channel_name


def _name(value):
    if not value.strip():
        raise ContractError('empty_channel')
    return value


def _rename_material(state, old, new):
    if old == new:
        return
    if new in state.materials:
        raise ContractError('name_conflict', name=new)
    material = state.materials.pop(old)
    material.origin = material.origin or old
    material.name = new
    state.materials[new] = material
    for obj in state.objects.values():
        obj.slots[:] = [new if value == old else value for value in obj.slots]


def edit_item(state, item):
    checked_record(item)
    obj, fresh = current_item(state, item)
    key, kind, old, slot = decode_reference(fresh)
    check_editable(obj)
    if kind in ('MAP_CHANNEL', 'UV_CHANNEL', 'COLOR_ATTRIBUTE', 'GEOMETRY_ATTRIBUTE', 'WEIGHT_GROUP', 'UDIM_TILE'):
        check_editable(obj, mesh=True)
        if not fresh.safe_to_delete:
            raise ContractError('protected_data', name=fresh.name)
    if kind == 'OBJECT_ID':
        name = _name(item.edit_name)
        if any(other.key != key and other.name == name for other in state.objects.values()):
            raise ContractError('name_conflict', name=name)
        obj.name = name
        obj.pass_index = min(PASS_INDEX_MAX, item.id_number)
        obj.color = tuple(item.color)
        saved = metadata(obj).get('object_id')
        if isinstance(saved, dict):
            saved['number'] = item.id_number
        item.owner_object = name
    elif kind == 'MATERIAL_ID':
        material = state.materials.get(fresh.material_name)
        if material is None:
            raise ContractError('missing_active_data')
        if material.readonly:
            raise ContractError('read_only', name=material.name)
        name = _name(item.edit_name)
        _rename_material(state, material.name, name)
        material.pass_index = min(PASS_INDEX_MAX, item.id_number)
        material.color = tuple(item.color)
        saved = metadata(material).get('material_id')
        if isinstance(saved, dict):
            saved['number'] = item.id_number
        if item.active:
            obj.active_slot = slot
        item.material_name = name
        item.name = name
        item.uid = reference(key, kind, name, slot)
    elif kind in ('MAP_CHANNEL', 'UV_CHANNEL', 'COLOR_ATTRIBUTE', 'GEOMETRY_ATTRIBUTE', 'WEIGHT_GROUP'):
        name = _name(item.edit_name)
        if kind == 'MAP_CHANNEL' and not 1 <= item.map_channel <= 999:
            raise ContractError('invalid_field', field='map_channel')
        rename_channel(obj, kind, old, name)
        if kind == 'WEIGHT_GROUP':
            if item.active:
                obj.active_group = name
            elif obj.active_group == name:
                obj.active_group = ''
        else:
            bucket = bucket_for(obj.mesh, kind)
            for layer_name, layer in bucket.items():
                if layer_name == name or item.active:
                    layer.active = item.active and layer_name == name
                if kind in ('MAP_CHANNEL', 'UV_CHANNEL') and (layer_name == name or item.render):
                    layer.render = item.render and layer_name == name
            if kind == 'MAP_CHANNEL':
                edit_metadata(obj.mesh).setdefault('map_channels', {})[name] = item.map_channel
        item.name = name
        item.uid = reference(key, kind, name, slot)
    elif kind == 'SELECTION_SET':
        if old in state.collection_readonly:
            raise ContractError('read_only', name=old)
        name = _name(item.edit_name)
        if name != old:
            if name in state.collections:
                raise ContractError('name_conflict', name=name)
            state.collections[name] = state.collections.pop(old)
        item.name = name
        item.collection_name = name
        item.uid = reference(key, kind, name, slot)
    elif kind == 'UDIM_TILE':
        if not 1001 <= item.id_number <= 9999:
            raise ContractError('invalid_field', field='udim_tile')
        edit_metadata(obj.mesh)['udim_tile'] = item.id_number
    elif kind == 'SMART_METADATA':
        from .inspector_view import meta_owner,meta_key
        owner=meta_owner(state,obj,item) if hasattr(state,'inspector_meta') else obj
        key=meta_key(state,obj,item) if hasattr(state,'inspector_meta') else old
        if getattr(owner,'readonly',False):raise ContractError('read_only',name=item.name)
        saved=metadata(owner).get(key)
        if not isinstance(saved, dict) or not saved.get('type'):
            raise ContractError('metadata_not_entry', name=old)
        saved['name'] = _name(item.edit_name)
        saved['number'] = item.id_number
    else:
        raise ContractError('unsupported_inspector_type', kind=kind)
    return 1


def delete_item(state, item):
    obj, fresh = current_item(state, item)
    key, kind, name, slot = decode_reference(fresh)
    if not fresh.safe_to_delete:
        return False
    if kind == 'OBJECT_ID':
        obj.pass_index = 0
        if 'object_id' in metadata(obj):
            edit_metadata(obj).pop('object_id')
    elif kind == 'MATERIAL_ID':
        obj.slots[slot] = None
    elif kind in ('MAP_CHANNEL', 'UV_CHANNEL', 'COLOR_ATTRIBUTE', 'GEOMETRY_ATTRIBUTE'):
        bucket = bucket_for(obj.mesh, kind)
        bucket.pop(name)
        if bucket and not any(layer.active for layer in bucket.values()):
            next(iter(bucket.values())).active = True
        mapping = metadata(obj.mesh).get('map_channels')
        if isinstance(mapping, dict) and kind in ('MAP_CHANNEL', 'UV_CHANNEL'):
            mapping.pop(name, None)
    elif kind == 'WEIGHT_GROUP':
        obj.groups.pop(name)
        obj.group_origins.pop(name, None)
        if obj.active_group == name:
            obj.active_group = next(iter(obj.groups), '')
    elif kind == 'SELECTION_SET':
        state.collections[name].discard(key)
    elif kind == 'UDIM_TILE':
        edit_metadata(obj.mesh).pop('udim_tile', None)
    elif kind == 'SMART_METADATA':
        from .inspector_view import meta_owner,meta_key
        owner=meta_owner(state,obj,item) if hasattr(state,'inspector_meta') else obj
        key=meta_key(state,obj,item) if hasattr(state,'inspector_meta') else name
        edit_metadata(owner).pop(key,None)
    else:
        raise ContractError('unsupported_inspector_type', kind=kind)
    return True


def apply_entry_to_item(state, entry, item):
    if not entry.enabled or entry.locked:
        return 0
    obj, fresh = current_item(state, item)
    kind = fresh.item_type
    if kind == 'SMART_METADATA':
        saved = metadata(obj).get(fresh.name)
        if not isinstance(saved, dict) or saved.get('type') != entry.type:
            raise ContractError('kind_mismatch')
        check_editable(obj)
        remember(obj, entry, fresh.name)
        return 1
    uv_pair = {kind, entry.type} <= {'MAP_CHANNEL', 'UV_CHANNEL'}
    if kind != entry.type and not uv_pair:
        raise ContractError('kind_mismatch')
    if kind == 'OBJECT_ID':
        return apply_entries(state, [entry], keys=[obj.key])
    if kind == 'MATERIAL_ID':
        material = state.materials.get(fresh.material_name)
        if material is None:
            raise ContractError('missing_active_data')
        update_material(state, material, entry)
        return 1
    edited = deepcopy(fresh)
    edited.edit_name = channel_name(entry)
    edited.id_number = entry.udim_tile if kind == 'UDIM_TILE' else entry.id_number
    edited.map_channel = entry.map_channel
    edited.color = tuple(entry.color)
    return edit_item(state, edited)
