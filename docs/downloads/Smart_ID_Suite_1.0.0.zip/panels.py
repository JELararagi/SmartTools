import bpy
from .blender_ui import RootPanel

class SMARTID_PT_asset_browser_root(RootPanel,bpy.types.Panel):
    bl_idname='SMARTID_PT_asset_browser_root'
    bl_space_type='FILE_BROWSER'
    bl_region_type='TOOL_PROPS'

class SMARTID_PT_clip_editor_root(RootPanel,bpy.types.Panel):
    bl_idname='SMARTID_PT_clip_editor_root'
    bl_space_type='CLIP_EDITOR'
    bl_region_type='UI'

class SMARTID_PT_dopesheet_editor_root(RootPanel,bpy.types.Panel):
    bl_idname='SMARTID_PT_dopesheet_editor_root'
    bl_space_type='DOPESHEET_EDITOR'
    bl_region_type='UI'

class SMARTID_PT_file_browser_root(RootPanel,bpy.types.Panel):
    bl_idname='SMARTID_PT_file_browser_root'
    bl_space_type='FILE_BROWSER'
    bl_region_type='UI'

class SMARTID_PT_graph_editor_root(RootPanel,bpy.types.Panel):
    bl_idname='SMARTID_PT_graph_editor_root'
    bl_space_type='GRAPH_EDITOR'
    bl_region_type='UI'

class SMARTID_PT_image_editor_root(RootPanel,bpy.types.Panel):
    bl_idname='SMARTID_PT_image_editor_root'
    bl_space_type='IMAGE_EDITOR'
    bl_region_type='UI'

class SMARTID_PT_main(RootPanel,bpy.types.Panel):
    bl_idname='SMARTID_PT_main'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'

class SMARTID_PT_nla_editor_root(RootPanel,bpy.types.Panel):
    bl_idname='SMARTID_PT_nla_editor_root'
    bl_space_type='NLA_EDITOR'
    bl_region_type='UI'

class SMARTID_PT_node_editor_root(RootPanel,bpy.types.Panel):
    bl_idname='SMARTID_PT_node_editor_root'
    bl_space_type='NODE_EDITOR'
    bl_region_type='UI'

class SMARTID_PT_sequence_editor_root(RootPanel,bpy.types.Panel):
    bl_idname='SMARTID_PT_sequence_editor_root'
    bl_space_type='SEQUENCE_EDITOR'
    bl_region_type='UI'

class SMARTID_PT_spreadsheet_root(RootPanel,bpy.types.Panel):
    bl_idname='SMARTID_PT_spreadsheet_root'
    bl_space_type='SPREADSHEET'
    bl_region_type='UI'

class SMARTID_PT_text_editor_root(RootPanel,bpy.types.Panel):
    bl_idname='SMARTID_PT_text_editor_root'
    bl_space_type='TEXT_EDITOR'
    bl_region_type='UI'

CLASSES=(SMARTID_PT_asset_browser_root,SMARTID_PT_clip_editor_root,SMARTID_PT_dopesheet_editor_root,SMARTID_PT_file_browser_root,SMARTID_PT_graph_editor_root,SMARTID_PT_image_editor_root,SMARTID_PT_main,SMARTID_PT_nla_editor_root,SMARTID_PT_node_editor_root,SMARTID_PT_sequence_editor_root,SMARTID_PT_spreadsheet_root,SMARTID_PT_text_editor_root,)
