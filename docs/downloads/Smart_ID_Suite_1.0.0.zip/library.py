# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Original library, naming, filtering and multi-selection implementation."""
from copy import deepcopy
from uuid import uuid4
from .data_schema import Entry, ContractError, KINDS, MAX_ID, MAX_ENTRIES, SCHEMA
from .colors import generated_color

SEARCH_FIELDS = ('name', 'channel_name', 'uv_map', 'attribute_name', 'color_attribute', 'group_name', 'export_tag', 'notes', 'material_name')


def channel_name(entry):
    fields = {
        'MAP_CHANNEL': ('channel_name', 'uv_map'),
        'UV_CHANNEL': ('uv_map', 'channel_name'),
        'COLOR_ATTRIBUTE': ('color_attribute', 'channel_name'),
        'GEOMETRY_ATTRIBUTE': ('attribute_name', 'channel_name'),
        'WEIGHT_GROUP': ('group_name', 'channel_name'),
        'SELECTION_SET': ('group_name', 'channel_name'),
        'RENDER_AOV': ('export_tag', 'name'),
        'MATERIAL_ID': ('material_name', 'name'),
    }.get(entry.type, ('channel_name', 'name'))
    return next((getattr(entry, key).strip() for key in fields if getattr(entry, key).strip()), entry.name.strip())


def identity(entry):
    if entry.type in ('OBJECT_ID', 'MATERIAL_ID', 'CUSTOM_ID', 'CRYPTOMATTE_ID'):
        return (entry.type, entry.id_number)
    if entry.type == 'UDIM_TILE':
        return (entry.type, entry.udim_tile)
    if entry.type == 'MAP_CHANNEL':
        return (entry.type, entry.map_channel, channel_name(entry))
    return (entry.type, channel_name(entry))


def next_number(entries, kind):
    used = {entry.id_number for entry in entries if entry.type == kind}
    number = max(used, default=0) + 1
    if number > MAX_ID:
        number = next((n for n in range(1, len(used) + 2) if n not in used), MAX_ID + 1)
    if number > MAX_ID:
        raise ContractError('id_exhausted')
    return number


def suggested_name(kind, number, profile):
    prefixes = dict(zip(KINDS, ('ObjectID', 'MaterialID', 'Map', 'UV', 'Color', 'Attribute', 'UDIM', 'Set', 'AOV', 'Crypto', 'Weight', 'CustomID')))
    if kind in ('MAP_CHANNEL', 'UV_CHANNEL'):
        patterns = {'BLENDER': 'UVMap_{n:03d}', '3DSMAX': 'MapChannel_{n}', 'MAYA': 'map{n}',
                    'MARI': 'UV_{n:03d}', 'ZBRUSH': 'UVSet_{n}', 'C4D': 'UVW_{n}',
                    'LIGHTWAVE': 'UVMap_{n}', 'CUSTOM': 'Channel_{n}'}
        return patterns[profile].format(n=number)
    return prefixes[kind] + '_' + str(number).zfill(3)


def add_entry(state, kind=None):
    kind = kind or state.settings.new_entry_type
    if kind not in KINDS:
        raise ContractError('invalid_field', field='type')
    if len(state.entries) >= MAX_ENTRIES:
        raise ContractError('too_many_entries', count=len(state.entries))
    number = next_number(state.entries, kind)
    name = suggested_name(kind, number, state.settings.naming_profile)
    row = Entry(uid=uuid4().hex, type=kind, name=name, id_number=number)
    row.channel_name = name
    row.map_channel = min(999, max(1, number))
    row.udim_tile = min(9999, 1000 + number)
    if kind in ('MAP_CHANNEL', 'UV_CHANNEL'): row.uv_map = name
    if kind == 'COLOR_ATTRIBUTE': row.color_attribute = name
    if kind == 'GEOMETRY_ATTRIBUTE': row.attribute_name = name
    if kind in ('SELECTION_SET', 'WEIGHT_GROUP'): row.group_name = name
    if state.settings.auto_color: row.color = generated_color(number)
    state.entries.append(row)
    state.active_index = len(state.entries) - 1
    return row


def active_entry(state):
    if not 0 <= state.active_index < len(state.entries):
        raise ContractError('no_entry')
    return state.entries[state.active_index]


def selected_indices(state):
    return [i for i, entry in enumerate(state.entries) if entry.selected]


def action_entries(state, writable=False):
    indices = selected_indices(state)
    if not indices and 0 <= state.active_index < len(state.entries): indices = [state.active_index]
    return [state.entries[i] for i in indices if not writable or (state.entries[i].enabled and not state.entries[i].locked)]


def visible_indices(state):
    settings = state.settings
    scoped = state.scope(settings.library_scope)
    stale = state.counts_signature != state.selection_signature()
    result = []
    for index, row in enumerate(state.entries):
        matches_filter = settings.filter_type == 'ALL' or row.type == settings.filter_type
        query = settings.search.casefold().strip()
        matches_text = not query or any(query in getattr(row, key).casefold() for key in SEARCH_FIELDS)
        count = row.count_selected_objects if row.type not in ('MAP_CHANNEL', 'UV_CHANNEL', 'COLOR_ATTRIBUTE', 'GEOMETRY_ATTRIBUTE') else row.count_selected_channels
        forced = not stale and bool(scoped) and row.type == 'OBJECT_ID' and row.count_selected_objects > 0
        if not forced and not (matches_filter and matches_text): continue
        unused = row.count_objects + row.count_materials + row.count_channels == 0
        in_scope = settings.library_scope == 'SCENE' or not scoped or stale or count > 0
        pinned = index == state.active_index or row.selected or row.type == 'RENDER_AOV' or unused
        if in_scope or pinned: result.append(index)
    return result


def toggle_check(rows, index, visible, anchor=-1, extend=False):
    if not 0 <= index < len(rows): raise ContractError('invalid_row')
    if extend and anchor in visible and index in visible:
        left, right = sorted((visible.index(anchor), visible.index(index)))
        for candidate in visible[left:right+1]: rows[candidate].selected = True
    else:
        rows[index].selected = not rows[index].selected
    return index


def remove_entries(state, indices):
    active_uid = state.entries[state.active_index].uid if 0 <= state.active_index < len(state.entries) else ''
    wanted = set(indices)
    removed = sum(1 for i, row in enumerate(state.entries) if i in wanted and not row.locked)
    state.entries[:] = [row for i, row in enumerate(state.entries) if i not in wanted or row.locked]
    state.active_index = next((i for i, row in enumerate(state.entries) if row.uid == active_uid), min(state.active_index, len(state.entries)-1))
    state.anchor_index = -1
    return removed


def duplicate_entry(state):
    source = active_entry(state)
    if len(state.entries) >= MAX_ENTRIES: raise ContractError('too_many_entries', count=len(state.entries))
    row = deepcopy(source)
    row.uid = uuid4().hex
    row.id_number = next_number(state.entries, source.type)
    row.selected = False
    existing = {e.name for e in state.entries}
    suffix = 1
    while source.name + '.' + str(suffix).zfill(3) in existing: suffix += 1
    row.name = source.name + '.' + str(suffix).zfill(3)
    for key in SCHEMA['records']['entry']:
        if key.startswith('count_'): setattr(row, key, 0)
    if state.settings.auto_color: row.color = generated_color(row.id_number)
    if row.type == 'MAP_CHANNEL': row.map_channel = min(999, max(1, row.id_number))
    state.entries.insert(state.active_index + 1, row)
    state.active_index += 1
    return row


def move_entry(state, direction):
    active_entry(state)
    if direction not in ('UP', 'DOWN'): raise ContractError('invalid_field', field='direction')
    destination = state.active_index + (-1 if direction == 'UP' else 1)
    if 0 <= destination < len(state.entries):
        source = state.active_index
        state.entries[source], state.entries[destination] = state.entries[destination], state.entries[source]
        state.active_index = destination


def sort_entries(state):
    mode = state.settings.sort_mode
    if mode == 'MANUAL': return
    uid = state.entries[state.active_index].uid if 0 <= state.active_index < len(state.entries) else ''
    keys = {'TYPE_ID': lambda e: (KINDS.index(e.type), e.id_number, e.name.casefold()),
            'ID': lambda e: (e.id_number, e.name.casefold()), 'NAME': lambda e: e.name.casefold()}
    state.entries.sort(key=keys[mode])
    state.active_index = next((i for i,e in enumerate(state.entries) if e.uid == uid), -1)
    state.anchor_index = -1
