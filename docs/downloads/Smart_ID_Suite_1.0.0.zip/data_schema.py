# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Typed records built solely from the documented public property contract."""
from dataclasses import make_dataclass, field
from pathlib import Path
from types import SimpleNamespace
import json
import math

SCHEMA = json.loads(Path(__file__).with_name('contract_schema.json').read_text(encoding='utf-8'))
KINDS = tuple(SCHEMA['enums']['ID_TYPE_ITEMS'])
OPERATIONS = tuple(SCHEMA['operations'])
MAX_ID = 2147483647
MAX_ENTRIES = 4096
MAX_TEXT = 65535


class ContractError(ValueError):
    def __init__(self, code, **values):
        self.code = code
        self.values = values
        super().__init__(code + (': ' + repr(values) if values else ''))


class Record:
    _kind = ''

    @property
    def bl_rna(self):
        return SimpleNamespace(properties={
            name: SimpleNamespace(hard_min=spec.get('min', 0), hard_max=spec.get('max', MAX_ID))
            for name, spec in SCHEMA['records'][self._kind].items()
        })


def make_record_type(name, kind):
    definitions = []
    python_types = {'StringProperty': str, 'BoolProperty': bool, 'IntProperty': int,
                    'FloatProperty': float, 'EnumProperty': str, 'FloatVectorProperty': tuple}
    for key, spec in SCHEMA['records'][kind].items():
        default = spec['default']
        if isinstance(default, list):
            default = tuple(default)
        definitions.append((key, python_types[spec['type']], field(default=default)))
    cls = make_dataclass(name, definitions, bases=(Record,))
    cls._kind = kind
    cls.__module__ = __name__
    return cls


Entry = make_record_type('Entry', 'entry')
Settings = make_record_type('Settings', 'settings')
InspectorItem = make_record_type('InspectorItem', 'inspector_item')
RECORD_TYPES = {'entry': Entry, 'settings': Settings, 'inspector_item': InspectorItem}


def validate_value(name, value, spec):
    kind = spec['type']
    valid = True
    if kind == 'BoolProperty':
        valid = type(value) is bool
    elif kind == 'IntProperty':
        valid = type(value) is int
    elif kind == 'FloatProperty':
        valid = type(value) in (float, int) and math.isfinite(value)
    elif kind in ('StringProperty', 'EnumProperty'):
        valid = isinstance(value, str) and len(value) <= MAX_TEXT and '\x00' not in value
        if kind == 'EnumProperty':
            valid = valid and value in spec['items']
    elif kind == 'FloatVectorProperty':
        valid = isinstance(value, (tuple, list)) and len(value) == spec['size']
        if valid:
            valid = all(type(x) in (int, float) and math.isfinite(x) and spec.get('min', -math.inf) <= x <= spec.get('max', math.inf) for x in value)
    if valid and kind in ('IntProperty', 'FloatProperty'):
        valid = spec.get('min', -math.inf) <= value <= spec.get('max', math.inf)
    if not valid:
        raise ContractError('invalid_field', field=name)
    return tuple(value) if kind == 'FloatVectorProperty' else value


def to_dict(record, persistent_only=True):
    fields = SCHEMA['records'][record._kind]
    return {name: getattr(record, name) for name, spec in fields.items()
            if not persistent_only or 'SKIP_SAVE' not in spec.get('options', ())}


def from_dict(kind, payload, allow_transient=False):
    if not isinstance(payload, dict):
        raise ContractError('invalid_record')
    specs = SCHEMA['records'][kind]
    unknown = set(payload) - set(specs)
    if unknown:
        raise ContractError('unknown_field', field=sorted(unknown)[0])
    values = {}
    for key, value in payload.items():
        if not allow_transient and 'SKIP_SAVE' in specs[key].get('options', ()):
            continue
        values[key] = validate_value(key, value, specs[key])
    return RECORD_TYPES[kind](**values)


def checked_record(record):
    return from_dict(record._kind, to_dict(record, persistent_only=False), allow_transient=True)
