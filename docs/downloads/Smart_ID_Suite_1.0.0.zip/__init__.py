# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Smart ID Suite: independently implemented private review candidate."""
bl_info = {
    'name': 'Smart ID Suite',
    'author': 'JELararagi',
    'version': (1, 0, 0),
    'blender': (5, 1, 0),
    'location': 'Sidebar > Smart ID',
    'description': 'Manage IDs, channels and assignments',
    'category': 'Object',
}
__version__ = '1.0.0'


def register():
    from . import blender_ui
    blender_ui.register()


def unregister():
    from . import blender_ui
    blender_ui.unregister()

def get_entries(scene):
    from .native_data import entries
    return entries(scene)
def get_settings(scene):return scene.smart_id_settings
