# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Smart ID Suite - list-managed IDs and channels for Blender 5.1."""

__version__ = "1.0.0"

bl_info = {
    "name": 'Smart ID',
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "Supported Editors > Sidebar > Smart ID",
    "description": "List-manage material IDs, object IDs, map channels, attributes, UDIM metadata, selection sets and render channel tags.",
    "category": "Object",
    "support": "COMMUNITY",
    "doc_url": "",
    "tracker_url": "",
}

import csv
import json
from collections import namedtuple
import hashlib
import io
import math
import os
import re
import sys
import time
import types
import uuid
from pathlib import Path

import blf
import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy_extras.io_utils import ExportHelper, ImportHelper
from bpy_extras.view3d_utils import location_3d_to_region_2d
from bpy.app.handlers import persistent
from mathutils import Color, Vector

ADDON_ID = "smart_id_suite"
COPYRIGHT_NOTICE = "Copyright (C) 2026 JELararagi"
LICENSE_NOTICE = "SPDX-License-Identifier: GPL-3.0-or-later"
CUSTOM_PREFIX = "smart_id_suite"

_SETTINGS_FOLDER = "Smart_ID_Suite"
_SETTINGS_FILE = "Smart_ID_Suite.json"
_SETTINGS_SCHEMA = "smart_id_suite.npanel_settings.v1"
_SETTINGS_VERSION = "0.6.30"
_SETTINGS_COMPATIBLE_VERSIONS = frozenset({"0.6.10", "0.6.11", "0.6.12", "0.6.13", "0.6.14", "0.6.15", "0.6.16", "0.6.17", "0.6.18", "0.6.20", "0.6.29", _SETTINGS_VERSION})
_SETTINGS_PAYLOAD_TYPE = "smart_id_suite.settings"
_SETTINGS_APPLYING = False
_LAST_SETTINGS_SERIALIZED = ""
_PENDING_SETTINGS_PAYLOAD = None
_SETTINGS_DIRTY = False
_SETTINGS_UNKNOWN_ROOT = {}
_SETTINGS_UNKNOWN_VALUES = {}
_SETTINGS_RESTORE_SERIAL = 0
_SETTINGS_RESTORE_SCENE_KEY = ""
_SETTINGS_LAST_ERROR = ""
_SETTINGS_WRITE_BLOCKED = False
_SETTINGS_OFF_COMMIT_TOKEN = None
_SETTINGS_MSGBUS_OWNER = object()
_TRANSIENT_SETTING_NAMES = {
    "last_library_autosync_signature",
    "last_report",
    "last_report_language",
}

_RUNTIME_REGISTRY_NAMESPACE_KEY = "JELARARAGI_SMART_ID_RUNTIME_V1"
_RUNTIME_REGISTRY_VERSION = 1
_RUNTIME_FALLBACK_STATE = None
# Process-lifetime anchor for the runtime registry state.  Blender REPLACES the
# contents of ``bpy.app.driver_namespace`` on every file load (measured on
# 5.1.2 ec6e62d40fa9: after ``wm.open_mainfile`` the Smart ID key is gone, so
# ``_runtime_registry_state()`` minted a fresh empty state and the Suite lost
# ``registered_classes`` 59 -> 0, ``resource_ledger`` 76 -> 0 and
# ``registration_mode`` FULL -> UNREGISTERED).  ``unregister()`` then found no
# ownership and returned without releasing anything, leaking 3 PropertyGroups,
# 2 UILists, ``Scene.smart_id_settings`` and 4 handlers.  A synthetic
# ``sys.modules`` entry keeps the exact state object reachable across file
# loads and across this package's own live-update reload, so the Suite's own
# prior generation can be re-adopted deterministically.  The anchor is scoped
# to this Suite only and never stores or reads foreign state.
_RUNTIME_ANCHOR_MODULE_NAME = "jelararagi_smart_id_runtime_anchor_v1"
_RUNTIME_ANCHOR_ATTRIBUTE = "SMART_ID_RUNTIME_STATES"
_SMART_ID_MODULE_GENERATION = 0
_SMART_ID_RUNTIME_OWNER_TOKEN = ""
_SMART_ID_RUNTIME_ACTIVE = False
_SMART_ID_POST_REGISTER_TIMER_FN = None
_SMART_ID_SUITE_OWNER_UUID = "8e52635f-4b48-47a2-9513-8edc0e7e62a5"
_SMART_ID_REGISTRATION_OWNER_TOKEN = ""
_SMART_ID_REGISTRATION_GENERATION = 0
_REGISTRATION_MODE_UNREGISTERED = "UNREGISTERED"
_REGISTRATION_MODE_FULL = "FULL"
_REGISTRATION_MODE_RESTART_REQUIRED = "RESTART_REQUIRED"
_SMART_ID_REGISTRATION_MODE = _REGISTRATION_MODE_UNREGISTERED
_SMART_ID_REGISTRATION_CONFLICTS = ()
_SMART_ID_RESOURCE_RELEASE_RETRY_LIMIT = 3
_SMART_ID_EXIT_TEARDOWN_ACTIVE = False


def _new_runtime_registry_state():
    return {
        "version": _RUNTIME_REGISTRY_VERSION,
        "suite_id": ADDON_ID,
        "owner_uuid": _SMART_ID_SUITE_OWNER_UUID,
        "generation": 0,
        "owner_token": "",
        "active": False,
        "initialized_generation": 0,
        "initialized_scene_key": "",
        "timer_callbacks": [],
        "handler_callbacks": [],
        "msgbus_owners": [],
        "draw_handles": [],
        "registration_owner_token": "",
        "registration_generation": 0,
        "registration_mode": _REGISTRATION_MODE_UNREGISTERED,
        "registration_status": _REGISTRATION_MODE_UNREGISTERED,
        "registration_conflicts": [],
        "registration_root_class_ids": [],
        "registered_classes": [],
        "registered_scene_properties": [],
        "translations_owner_token": "",
        "resource_ledger": [],
    }


def _normalize_runtime_registry_state(state):
    if not isinstance(state, dict):
        state = _new_runtime_registry_state()
    defaults = _new_runtime_registry_state()
    for name, value in defaults.items():
        if name not in state:
            state[name] = value.copy() if isinstance(value, dict) else list(value) if isinstance(value, list) else value
    state["version"] = _RUNTIME_REGISTRY_VERSION
    for name in (
        "timer_callbacks",
        "handler_callbacks",
        "msgbus_owners",
        "draw_handles",
        "registered_classes",
        "registered_scene_properties",
        "registration_conflicts",
        "registration_root_class_ids",
        "resource_ledger",
    ):
        if not isinstance(state.get(name), list):
            try:
                state[name] = list(state.get(name) or ())
            except Exception:
                state[name] = []
    # 0.6.17 removed the obsolete Suite-side Manager placement cache.
    # Discard only this primitive legacy state owned by Smart ID; no Manager or
    # foreign resource is inspected or modified.
    state.pop("placement_last_known", None)
    mode = str(state.get("registration_mode", _REGISTRATION_MODE_UNREGISTERED) or _REGISTRATION_MODE_UNREGISTERED)
    if mode not in {_REGISTRATION_MODE_UNREGISTERED, _REGISTRATION_MODE_FULL, _REGISTRATION_MODE_RESTART_REQUIRED}:
        mode = _REGISTRATION_MODE_UNREGISTERED
    state["registration_mode"] = mode
    state["registration_status"] = mode
    return state


def _runtime_anchor_store():
    """Process-lifetime dict holding this Suite's exact runtime state object.

    Lives in a synthetic ``sys.modules`` entry so it survives both a Blender
    file load (which wipes ``bpy.app.driver_namespace``) and this package's own
    live-update reload (which only purges ``<package>.`` keys).  It is not an
    importable module and holds nothing but this Suite's own state.
    """
    module = sys.modules.get(_RUNTIME_ANCHOR_MODULE_NAME)
    if not isinstance(module, types.ModuleType):
        module = types.ModuleType(_RUNTIME_ANCHOR_MODULE_NAME)
        module.__doc__ = (
            "Smart ID Suite runtime-state anchor. Keeps the exact runtime "
            "registry state reachable across Blender file loads, which replace "
            "bpy.app.driver_namespace. Not an importable module."
        )
        setattr(module, _RUNTIME_ANCHOR_ATTRIBUTE, {})
        sys.modules[_RUNTIME_ANCHOR_MODULE_NAME] = module
    store = getattr(module, _RUNTIME_ANCHOR_ATTRIBUTE, None)
    if not isinstance(store, dict):
        store = {}
        setattr(module, _RUNTIME_ANCHOR_ATTRIBUTE, store)
    return store


def _runtime_state_is_own(state):
    """True only for a state minted by this exact Suite identity.

    Smart ID declines foreign storage as policy: the anchor is only ever
    adopted when the stamped Suite id and owner UUID match, so an unrelated
    object left under this name is ignored rather than repaired or consumed.
    """
    return (
        isinstance(state, dict)
        and str(state.get("suite_id", "")) == ADDON_ID
        and str(state.get("owner_uuid", "")) == _SMART_ID_SUITE_OWNER_UUID
    )


def _runtime_state_matches_this_module(state):
    """True when THIS module instance's own live ownership is recorded here.

    The module globals survive a file load, so they are the only trustworthy
    tie-break between this Suite's authoritative state and an empty one minted
    while the registry was momentarily unreachable.
    """
    if not _runtime_state_is_own(state):
        return False
    registration_token = str(_SMART_ID_REGISTRATION_OWNER_TOKEN)
    runtime_token = str(_SMART_ID_RUNTIME_OWNER_TOKEN)
    if registration_token and str(state.get("registration_owner_token", "")) == registration_token:
        return True
    if runtime_token and str(state.get("owner_token", "")) == runtime_token:
        return True
    return False


def _runtime_registry_state():
    global _RUNTIME_FALLBACK_STATE
    try:
        namespace = bpy.app.driver_namespace
    except Exception:
        namespace = None
    if not isinstance(namespace, dict):
        _RUNTIME_FALLBACK_STATE = _normalize_runtime_registry_state(_RUNTIME_FALLBACK_STATE)
        _runtime_anchor_store()[_RUNTIME_REGISTRY_NAMESPACE_KEY] = _RUNTIME_FALLBACK_STATE
        return _RUNTIME_FALLBACK_STATE
    published = namespace.get(_RUNTIME_REGISTRY_NAMESPACE_KEY)
    anchored = _runtime_anchor_store().get(_RUNTIME_REGISTRY_NAMESPACE_KEY)
    if published is None:
        # A file load replaced driver_namespace.  Every resource the ledger
        # journals (classes, RNA descriptors, handlers, timers, msgbus owners,
        # draw handles) is process-global and still live, so this Suite's own
        # anchored state remains authoritative.  Re-publish it instead of
        # minting an empty one, which is what made unregister a no-op.
        if _runtime_state_is_own(anchored):
            published = anchored
    elif (
        published is not anchored
        and _runtime_state_matches_this_module(anchored)
        and not _runtime_state_matches_this_module(published)
    ):
        # Something touched the registry between the wipe and this generation's
        # ``load_post`` re-arm and minted an empty state.  This module instance's
        # own live ownership is still recorded in the anchored object, so that
        # exact object - and only that one - is re-published.
        published = anchored
    state = _normalize_runtime_registry_state(published)
    namespace[_RUNTIME_REGISTRY_NAMESPACE_KEY] = state
    # Keep the anchor pointing at the exact live object, so every later touch
    # (including one made by a prior generation of this Suite) heals the same
    # state rather than forking a second one.
    _RUNTIME_FALLBACK_STATE = state
    _runtime_anchor_store()[_RUNTIME_REGISTRY_NAMESPACE_KEY] = state
    return state


def _smart_id_runtime_rearm_load_post(_dummy=None):
    """Re-publish the anchored runtime state after a file load replaces it.

    Called first by the single load_post handler (_smart_id_settings_load_post).
    It never raises: a persistent handler must not fail foreign handlers or the
    user's file load.
    """
    try:
        _runtime_registry_state()
    except Exception:
        pass


def _runtime_handler_list(name):
    try:
        return getattr(bpy.app.handlers, str(name))
    except Exception:
        return None


def _native_sequence_contains_exact_identity(container, identity):
    """Check a Blender callback sequence without invoking foreign equality."""
    try:
        return any(item is identity for item in container)
    except Exception:
        return False


def _native_sequence_remove_exact_identity(container, identity):
    """Delete one exact callback object; never use equality-based ``remove``."""
    try:
        index = next(
            index for index, item in enumerate(container)
            if item is identity
        )
        if container[index] is not identity:
            return False
        del container[index]
        return True
    except (StopIteration, IndexError):
        return False
    except Exception:
        return False


def _new_owned_resource_record(
    kind,
    identity,
    native_remover,
    *,
    owner_token=None,
    generation=None,
    **metadata,
):
    return {
        "kind": str(kind),
        "owner_uuid": _SMART_ID_SUITE_OWNER_UUID,
        "suite_id": ADDON_ID,
        "generation": int(_SMART_ID_MODULE_GENERATION if generation is None else generation),
        "owner_token": str(_SMART_ID_RUNTIME_OWNER_TOKEN if owner_token is None else owner_token),
        "identity": identity,
        "native_remover": native_remover,
        "removed": False,
        **metadata,
    }


def _resource_record_is_owned(record, *, owner_token=None, generation=None):
    if not isinstance(record, dict):
        return False
    if str(record.get("owner_uuid", "")) != _SMART_ID_SUITE_OWNER_UUID:
        return False
    if str(record.get("suite_id", "")) != ADDON_ID:
        return False
    if owner_token is not None and str(record.get("owner_token", "")) != str(owner_token):
        return False
    if generation is not None:
        try:
            if int(record.get("generation", -1)) != int(generation):
                return False
        except Exception:
            return False
    return True


def _resource_ledger_add(record, state=None):
    if not _resource_record_is_owned(record):
        raise RuntimeError("invalid Smart ID resource ownership record")
    state = state or _runtime_registry_state()
    ledger = state.setdefault("resource_ledger", [])
    if not any(item is record for item in ledger):
        ledger.append(record)
    return record


def _resource_ledger_drop(record, state=None):
    state = state or _runtime_registry_state()
    ledger = state.setdefault("resource_ledger", [])
    before = len(ledger)
    state["resource_ledger"] = [item for item in ledger if item is not record]
    return len(state["resource_ledger"]) != before


def _resource_ledger_find(kind, identity, *, owner_token=None, state=None):
    state = state or _runtime_registry_state()
    for record in state.get("resource_ledger", ()):
        if not _resource_record_is_owned(record, owner_token=owner_token):
            continue
        if str(record.get("kind", "")) == str(kind) and record.get("identity") is identity:
            return record
    return None


def _resource_ledger_records(kind=None, *, owner_token=None, generation=None, state=None):
    state = state or _runtime_registry_state()
    result = []
    for record in state.get("resource_ledger", ()):
        if not _resource_record_is_owned(record, owner_token=owner_token, generation=generation):
            continue
        if kind is not None and str(record.get("kind", "")) != str(kind):
            continue
        result.append(record)
    return tuple(result)


def _resource_record_is_exact_ledger_member(record, *, kind=None, state=None):
    """Return True only for this Suite's exact record object in its own ledger."""
    if not isinstance(record, dict) or not _resource_record_is_owned(record):
        return False
    if kind is not None and str(record.get("kind", "")) != str(kind):
        return False
    state = state or _runtime_registry_state()
    return any(item is record for item in state.get("resource_ledger", ()))


def _coerce_runtime_draw_record(record):
    """Accept only exact Smart ID-owned draw records already in the ledger.

    Older tuple/name-based records are intentionally not upgraded or removed:
    they do not carry the exact owner UUID, generation, callback identity and
    native remover required by the current lifecycle contract.
    """
    if not isinstance(record, dict) or not _resource_record_is_owned(record):
        return None
    if str(record.get("kind", "")) != "draw_handler":
        return None
    if not callable(record.get("callback")) or record.get("identity") is not record.get("callback"):
        return None
    if not callable(record.get("native_remover")):
        return None
    try:
        generation = int(record.get("generation", 0) or 0)
    except Exception:
        return None
    if not str(record.get("owner_token", "")) or generation <= 0:
        return None
    record.setdefault("space", "SpaceView3D")
    record.setdefault("region", "WINDOW")
    record.setdefault("draw_type", "")
    record.setdefault("retired", False)
    record.setdefault("remove_attempts", 0)
    record.setdefault("last_remove_error", "")
    record.setdefault("removed", False)
    return record


def _remove_runtime_draw_record(record, *, state=None, mark_retired=True):
    """Remove one exact owned native handle; retain its ledger on any failure."""
    state = state or _runtime_registry_state()
    record = _coerce_runtime_draw_record(record)
    if record is None or not _resource_record_is_exact_ledger_member(
        record, kind="draw_handler", state=state
    ):
        return False
    if mark_retired:
        record["retired"] = True
    handle = record.get("handle")
    if handle is not None:
        remover = record.get("native_remover")
        try:
            remover(handle, str(record.get("region") or "WINDOW"))
        except Exception as exc:
            record["last_remove_error"] = f"{type(exc).__name__}: {exc}"
            record["remove_attempts"] = int(record.get("remove_attempts", 0)) + 1
            return False
    state["draw_handles"] = [
        item for item in state.get("draw_handles", ()) if item is not record
    ]
    record["removed"] = True
    record["last_remove_error"] = ""
    _resource_ledger_drop(record, state)
    return True


def _cleanup_tracked_runtime_resources(state=None):
    """Release exact Smart ID-owned resources with bounded immediate retries.

    Cleanup never scans Blender namespaces and never removes a resource by name,
    module, prefix, or ``bl_idname``.  A native removal failure keeps the exact
    ledger record so the next explicit lifecycle boundary can retry it.  Foreign
    or malformed records are left byte-for-byte untouched and are not counted as
    Smart ID residue.
    """
    state = state or _runtime_registry_state()
    retry_limit = max(1, int(_SMART_ID_RESOURCE_RELEASE_RETRY_LIMIT))

    remaining_timers = []
    for record in tuple(state.get("timer_callbacks", ())):
        if not _resource_record_is_exact_ledger_member(record, kind="timer", state=state):
            remaining_timers.append(record)
            continue
        callback = record.get("identity")
        remover = record.get("native_remover")
        checker = record.get("native_is_registered")
        removed = False
        last_error = ""
        attempts = 0
        for _attempt in range(retry_limit):
            attempts += 1
            try:
                registered = bool(checker(callback)) if callable(checker) else True
                if registered:
                    if not callable(remover):
                        raise RuntimeError("native timer remover unavailable")
                    remover(callback)
                if callable(checker) and bool(checker(callback)):
                    raise RuntimeError("timer remained registered")
                removed = True
                break
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
        record["remove_attempts"] = int(record.get("remove_attempts", 0)) + attempts
        if not removed:
            record["last_remove_error"] = last_error
            remaining_timers.append(record)
        else:
            record["removed"] = True
            record["last_remove_error"] = ""
            _resource_ledger_drop(record, state)
    state["timer_callbacks"] = remaining_timers

    remaining_handlers = []
    for record in tuple(state.get("handler_callbacks", ())):
        if not _resource_record_is_exact_ledger_member(record, kind="handler", state=state):
            remaining_handlers.append(record)
            continue
        callback = record.get("identity")
        handler_list = record.get("native_container")
        removed = False
        last_error = ""
        attempts = 0
        for _attempt in range(retry_limit):
            attempts += 1
            try:
                if handler_list is None:
                    raise RuntimeError("native handler list unavailable")
                before = sum(1 for item in handler_list if item is callback)
                if before > 0:
                    if not _native_sequence_remove_exact_identity(handler_list, callback):
                        raise RuntimeError("exact handler occurrence was not removed")
                    after = sum(1 for item in handler_list if item is callback)
                    if after != before - 1:
                        raise RuntimeError("exact handler occurrence was not removed")
                removed = True
                break
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
        record["remove_attempts"] = int(record.get("remove_attempts", 0)) + attempts
        if not removed:
            record["last_remove_error"] = last_error
            remaining_handlers.append(record)
        else:
            record["removed"] = True
            record["last_remove_error"] = ""
            _resource_ledger_drop(record, state)
    state["handler_callbacks"] = remaining_handlers

    remaining_owners = []
    for record in tuple(state.get("msgbus_owners", ())):
        if not _resource_record_is_exact_ledger_member(record, kind="msgbus", state=state):
            remaining_owners.append(record)
            continue
        owner = record.get("identity")
        remover = record.get("native_remover")
        removed = False
        last_error = ""
        attempts = 0
        for _attempt in range(retry_limit):
            attempts += 1
            try:
                if not callable(remover):
                    raise RuntimeError("native msgbus remover unavailable")
                remover(owner)
                removed = True
                break
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
        record["remove_attempts"] = int(record.get("remove_attempts", 0)) + attempts
        if not removed:
            record["last_remove_error"] = last_error
            remaining_owners.append(record)
        else:
            record["removed"] = True
            record["last_remove_error"] = ""
            _resource_ledger_drop(record, state)
    state["msgbus_owners"] = remaining_owners

    remaining_draw = []
    for record in tuple(state.get("draw_handles", ())):
        if not _resource_record_is_exact_ledger_member(record, kind="draw_handler", state=state):
            remaining_draw.append(record)
            continue
        removed = False
        for _attempt in range(retry_limit):
            if _remove_runtime_draw_record(record, state=state, mark_retired=True):
                removed = True
                break
        if not removed:
            remaining_draw.append(record)
    # Successful native removal was not appended to ``remaining_draw``.  Keep
    # every other record by exact object identity, including malformed or
    # foreign fixtures that are deliberately outside this Suite's ledger.
    state["draw_handles"] = remaining_draw

    def _owned_unresolved(records, kind):
        return sum(
            1 for record in records
            if _resource_record_is_exact_ledger_member(record, kind=kind, state=state)
        )

    return {
        "timers": _owned_unresolved(state.get("timer_callbacks", ()), "timer"),
        "handlers": _owned_unresolved(state.get("handler_callbacks", ()), "handler"),
        "msgbus": _owned_unresolved(state.get("msgbus_owners", ()), "msgbus"),
        "draw_handlers": _owned_unresolved(state.get("draw_handles", ()), "draw_handler"),
    }


def _begin_runtime_generation(owner_token=None):
    global _SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN, _SMART_ID_RUNTIME_ACTIVE, _SMART_ID_LOAD_IN_PROGRESS
    state = _runtime_registry_state()
    unresolved = _cleanup_tracked_runtime_resources(state)
    if any(int(unresolved.get(name, 0)) for name in ("timers", "handlers", "msgbus", "draw_handlers")):
        raise RuntimeError("previous Smart ID runtime resources could not be removed exactly")
    generation = int(state.get("generation", 0)) + 1
    token = str(owner_token or f"{ADDON_ID}:{generation}:{uuid.uuid4().hex}")
    state["generation"] = generation
    state["owner_token"] = token
    state["active"] = True
    state["initialized_generation"] = 0
    state["initialized_scene_key"] = ""
    _SMART_ID_MODULE_GENERATION = generation
    _SMART_ID_RUNTIME_OWNER_TOKEN = token
    _SMART_ID_RUNTIME_ACTIVE = True
    _SMART_ID_LOAD_IN_PROGRESS = False
    return generation


def _retire_runtime_generation_callbacks(owner_token=None):
    """Make every generation-guarded callback a no-op before native removal."""
    global _SMART_ID_LOAD_IN_PROGRESS, _SMART_ID_RUNTIME_ACTIVE
    state = _runtime_registry_state()
    expected_owner = _SMART_ID_RUNTIME_OWNER_TOKEN if owner_token is None else str(owner_token)
    if (
        int(state.get("generation", 0)) != int(_SMART_ID_MODULE_GENERATION)
        or str(state.get("owner_token", "")) != str(expected_owner)
        or str(_SMART_ID_RUNTIME_OWNER_TOKEN) != str(expected_owner)
    ):
        return False
    state["active"] = False
    _SMART_ID_RUNTIME_ACTIVE = False
    _SMART_ID_LOAD_IN_PROGRESS = False
    return True


def _end_runtime_generation(owner_token=None):
    global _SMART_ID_LOAD_IN_PROGRESS, _SMART_ID_RUNTIME_OWNER_TOKEN, _SMART_ID_RUNTIME_ACTIVE
    state = _runtime_registry_state()
    expected_owner = _SMART_ID_RUNTIME_OWNER_TOKEN if owner_token is None else str(owner_token)
    if (
        int(state.get("generation", 0)) != int(_SMART_ID_MODULE_GENERATION)
        or str(state.get("owner_token", "")) != str(expected_owner)
        or str(_SMART_ID_RUNTIME_OWNER_TOKEN) != str(expected_owner)
    ):
        return False

    # Retire callbacks before touching native containers.  A transient native
    # removal failure therefore leaves an exact ledger record whose callback is
    # already a generation-guarded no-op and can be retried at the next explicit
    # lifecycle boundary without any idle watchdog.
    state["active"] = False
    _SMART_ID_RUNTIME_ACTIVE = False
    _SMART_ID_LOAD_IN_PROGRESS = False
    unresolved = _cleanup_tracked_runtime_resources(state)
    state["initialized_generation"] = 0
    state["initialized_scene_key"] = ""
    if any(int(unresolved.get(name, 0)) for name in ("timers", "handlers", "msgbus", "draw_handlers")):
        # Preserve the exact owner/generation while unresolved records exist.
        return False
    state["owner_token"] = ""
    _SMART_ID_RUNTIME_OWNER_TOKEN = ""
    return True


def _runtime_generation_guard_fast(generation, owner_token):
    """Pure scalar guard safe for native draw callbacks."""
    try:
        return (
            bool(_SMART_ID_RUNTIME_ACTIVE)
            and int(_SMART_ID_MODULE_GENERATION) == int(generation)
            and str(_SMART_ID_RUNTIME_OWNER_TOKEN) == str(owner_token)
        )
    except Exception:
        return False


def _runtime_generation_is_current(generation=None, owner_token=None):
    generation = _SMART_ID_MODULE_GENERATION if generation is None else int(generation)
    owner_token = _SMART_ID_RUNTIME_OWNER_TOKEN if owner_token is None else str(owner_token)
    try:
        state = _runtime_registry_state()
        return (
            bool(state.get("active", False))
            and int(state.get("generation", 0)) == generation
            and str(state.get("owner_token", "")) == owner_token
        )
    except Exception:
        return False


def _runtime_generation_is_initialized(generation=None, scene=None):
    generation = _SMART_ID_MODULE_GENERATION if generation is None else int(generation)
    state = _runtime_registry_state()
    scene = scene or getattr(getattr(bpy, "context", None), "scene", None)
    return (
        _runtime_generation_is_current(generation)
        and int(state.get("initialized_generation", 0)) == generation
        and str(state.get("initialized_scene_key", "")) == _selection_scene_key(scene)
    )


def _mark_runtime_generation_initialized(generation=None, scene=None):
    generation = _SMART_ID_MODULE_GENERATION if generation is None else int(generation)
    state = _runtime_registry_state()
    if _runtime_generation_is_current(generation):
        state["initialized_generation"] = generation
        state["initialized_scene_key"] = _selection_scene_key(
            scene or getattr(getattr(bpy, "context", None), "scene", None)
        )


def _invalidate_runtime_generation_initialization(generation=None):
    generation = _SMART_ID_MODULE_GENERATION if generation is None else int(generation)
    state = _runtime_registry_state()
    if _runtime_generation_is_current(generation):
        state["initialized_generation"] = 0
        state["initialized_scene_key"] = ""


def _track_runtime_timer(callback):
    if not callable(callback):
        return None
    state = _runtime_registry_state()
    existing = _resource_ledger_find("timer", callback, owner_token=_SMART_ID_RUNTIME_OWNER_TOKEN, state=state)
    if existing is not None:
        return existing
    record = _new_owned_resource_record(
        "timer",
        callback,
        getattr(bpy.app.timers, "unregister", None),
        native_is_registered=getattr(bpy.app.timers, "is_registered", None),
    )
    _resource_ledger_add(record, state)
    state.setdefault("timer_callbacks", []).append(record)
    return record


def _untrack_runtime_timer(callback):
    state = _runtime_registry_state()
    kept = []
    for record in state.get("timer_callbacks", ()):
        if (
            _resource_record_is_exact_ledger_member(record, kind="timer", state=state)
            and record.get("identity") is callback
        ):
            record["removed"] = True
            _resource_ledger_drop(record, state)
            continue
        kept.append(record)
    state["timer_callbacks"] = kept


def _track_runtime_handler(list_name, callback):
    if not callable(callback):
        return None
    state = _runtime_registry_state()
    existing = _resource_ledger_find("handler", callback, owner_token=_SMART_ID_RUNTIME_OWNER_TOKEN, state=state)
    if existing is not None and str(existing.get("list_name", "")) == str(list_name):
        return existing
    handler_list = _runtime_handler_list(list_name)
    if handler_list is None:
        return None
    record = _new_owned_resource_record(
        "handler",
        callback,
        getattr(handler_list, "remove", None),
        list_name=str(list_name),
        native_container=handler_list,
    )
    _resource_ledger_add(record, state)
    state.setdefault("handler_callbacks", []).append(record)
    return record


def _untrack_runtime_handler(list_name, callback):
    state = _runtime_registry_state()
    name = str(list_name)
    kept = []
    for record in state.get("handler_callbacks", ()):
        if (
            _resource_record_is_exact_ledger_member(record, kind="handler", state=state)
            and str(record.get("list_name", "")) == name
            and record.get("identity") is callback
        ):
            record["removed"] = True
            _resource_ledger_drop(record, state)
            continue
        kept.append(record)
    state["handler_callbacks"] = kept


def _track_runtime_msgbus_owner(owner):
    state = _runtime_registry_state()
    existing = _resource_ledger_find("msgbus", owner, owner_token=_SMART_ID_RUNTIME_OWNER_TOKEN, state=state)
    if existing is not None:
        return existing
    record = _new_owned_resource_record(
        "msgbus",
        owner,
        getattr(bpy.msgbus, "clear_by_owner", None),
    )
    _resource_ledger_add(record, state)
    state.setdefault("msgbus_owners", []).append(record)
    return record


def _untrack_runtime_msgbus_owner(owner):
    state = _runtime_registry_state()
    kept = []
    for record in state.get("msgbus_owners", ()):
        if (
            _resource_record_is_exact_ledger_member(record, kind="msgbus", state=state)
            and record.get("identity") is owner
        ):
            record["removed"] = True
            _resource_ledger_drop(record, state)
            continue
        kept.append(record)
    state["msgbus_owners"] = kept


def _register_runtime_handler_exact(list_name, callback):
    handler_list = _runtime_handler_list(list_name)
    if handler_list is None or not callable(callback):
        raise RuntimeError(f"handler list unavailable: {list_name}")
    state = _runtime_registry_state()
    existing_record = _resource_ledger_find(
        "handler", callback, owner_token=_SMART_ID_RUNTIME_OWNER_TOKEN, state=state
    )
    if _native_sequence_contains_exact_identity(handler_list, callback):
        if existing_record is not None and existing_record.get("native_container") is handler_list:
            return existing_record
        raise RuntimeError(f"handler identity already registered without this generation ownership: {list_name}")
    handler_list.append(callback)
    try:
        record = _track_runtime_handler(list_name, callback)
        if record is None:
            raise RuntimeError("handler ledger acquisition failed")
        return record
    except Exception:
        try:
            _native_sequence_remove_exact_identity(handler_list, callback)
        except Exception:
            pass
        raise


def _remove_runtime_handler_exact(list_name, callback):
    state = _runtime_registry_state()
    record = None
    for candidate in _resource_ledger_records("handler", state=state):
        if (
            candidate.get("identity") is callback
            and str(candidate.get("list_name", "")) == str(list_name)
            and _resource_record_is_exact_ledger_member(candidate, kind="handler", state=state)
        ):
            record = candidate
            break
    if record is None:
        return True
    handler_list = record.get("native_container")
    if handler_list is None:
        return False
    for _attempt in range(max(1, int(_SMART_ID_RESOURCE_RELEASE_RETRY_LIMIT))):
        try:
            before = sum(1 for item in handler_list if item is callback)
            if before > 0:
                if not _native_sequence_remove_exact_identity(handler_list, callback):
                    continue
                after = sum(1 for item in handler_list if item is callback)
                if after != before - 1:
                    continue
            _untrack_runtime_handler(list_name, callback)
            return True
        except Exception:
            continue
    return False


def _register_runtime_timer_exact(callback, *, first_interval=0.0):
    if not callable(callback):
        raise RuntimeError("timer callback is not callable")
    state = _runtime_registry_state()
    existing = _resource_ledger_find(
        "timer", callback, owner_token=_SMART_ID_RUNTIME_OWNER_TOKEN, state=state
    )
    try:
        registered = bool(bpy.app.timers.is_registered(callback))
    except Exception:
        registered = False
    if registered:
        if existing is not None:
            return existing
        raise RuntimeError("timer identity already registered without this generation ownership")
    bpy.app.timers.register(callback, first_interval=max(0.0, float(first_interval)))
    try:
        record = _track_runtime_timer(callback)
        if record is None:
            raise RuntimeError("timer ledger acquisition failed")
        return record
    except Exception:
        try:
            if bpy.app.timers.is_registered(callback):
                bpy.app.timers.unregister(callback)
        except Exception:
            pass
        raise


def _remove_runtime_timer_exact(callback):
    state = _runtime_registry_state()
    record = _resource_ledger_find("timer", callback, state=state)
    if record is None:
        return True
    remover = record.get("native_remover")
    checker = record.get("native_is_registered")
    for _attempt in range(max(1, int(_SMART_ID_RESOURCE_RELEASE_RETRY_LIMIT))):
        try:
            registered = bool(checker(callback)) if callable(checker) else True
            if registered:
                if not callable(remover):
                    return False
                remover(callback)
            if callable(checker) and checker(callback):
                continue
            _untrack_runtime_timer(callback)
            return True
        except Exception:
            continue
    return False


def _track_runtime_draw_handle(
    space_name,
    handle,
    region_type,
    *,
    callback,
    native_remover,
    draw_type,
    generation=None,
    owner_token=None,
):
    if handle is None or not callable(callback) or not callable(native_remover):
        return None
    generation = _SMART_ID_MODULE_GENERATION if generation is None else int(generation)
    owner_token = _SMART_ID_RUNTIME_OWNER_TOKEN if owner_token is None else str(owner_token)
    record = _new_owned_resource_record(
        "draw_handler",
        callback,
        native_remover,
        generation=generation,
        owner_token=owner_token,
        callback=callback,
        space=str(space_name),
        region=str(region_type),
        draw_type=str(draw_type),
        handle=handle,
        retired=False,
        remove_attempts=0,
        last_remove_error="",
    )
    state = _runtime_registry_state()
    records = state.setdefault("draw_handles", [])
    for stored in records:
        current = _coerce_runtime_draw_record(stored)
        if current is not None and current.get("handle") is handle:
            return current
    records.append(record)
    _resource_ledger_add(record, state)
    return record


def _runtime_draw_record_for(*, handle=None, callback=None, owner_token=None):
    state = _runtime_registry_state()
    for raw_record in state.get("draw_handles", ()):
        record = _coerce_runtime_draw_record(raw_record)
        if record is None:
            continue
        if handle is not None and record.get("handle") is not handle:
            continue
        if callback is not None and record.get("callback") is not callback:
            continue
        if owner_token is not None and str(record.get("owner_token", "")) != str(owner_token):
            continue
        return record
    return None


def _runtime_draw_callback_is_current(callback, generation, owner_token):
    if not _runtime_generation_is_current(generation, owner_token):
        return False
    record = _runtime_draw_record_for(callback=callback, owner_token=owner_token)
    return bool(
        record is not None
        and int(record.get("generation", -1)) == int(generation)
        and not bool(record.get("retired", False))
    )


def _settings_path(create=True):
    root = Path(bpy.utils.user_resource("CONFIG")) / _SETTINGS_FOLDER
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root / _SETTINGS_FILE


def _portable_setting_names():
    try:
        annotations = getattr(SMARTID_PG_settings, "__annotations__", {}) or {}
        return tuple(name for name in annotations if name not in _TRANSIENT_SETTING_NAMES and not str(name).startswith("_"))
    except Exception:
        return ()


def _json_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    try:
        return list(value)
    except Exception:
        return str(value)


class _LocalizedMessageError(ValueError):
    """Stable message ID plus verbatim technical values.

    ``str()`` preserves the English baseline for logs and non-UI consumers;
    user-visible paths explicitly render the active locale catalog.
    """

    def __init__(self, message_id, **kwargs):
        self.message_id = message_id
        self.kwargs = dict(kwargs)
        super().__init__(self.render(UI_EN))

    def render(self, catalog):
        template = catalog.get(self.message_id) or UI_EN.get(self.message_id)
        if not template:
            return self.message_id
        values = dict(self.kwargs)
        nested = values.get("detail")
        if isinstance(nested, _LocalizedMessageError):
            values["detail"] = nested.render(catalog)
        try:
            return template.format(**values)
        except Exception:
            fallback = UI_EN.get(self.message_id)
            if not fallback:
                return self.message_id
            try:
                return fallback.format(**values)
            except Exception:
                return self.message_id

    def __str__(self):
        return self.render(UI_EN)


class _StrictJSONError(_LocalizedMessageError):
    pass


def _strict_json_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise _StrictJSONError("msg_json_parse_duplicate_key", key=key)
        result[key] = value
    return result


def _strict_json_constant(token):
    raise _StrictJSONError("msg_json_parse_nonfinite_number", token=token)


def _strict_json_float(token):
    value = float(token)
    if not math.isfinite(value):
        raise _StrictJSONError("msg_json_parse_nonfinite_number", token=token)
    return value


def _strict_json_loads(text):
    if type(text) is not str:
        raise _StrictJSONError("msg_json_parse_input_text")
    return json.loads(
        text,
        object_pairs_hook=_strict_json_object,
        parse_constant=_strict_json_constant,
        parse_float=_strict_json_float,
    )


def _collect_npanel_settings(scene=None):
    scene = scene or getattr(bpy.context, "scene", None)
    settings = get_settings(scene) if scene is not None and hasattr(scene, "smart_id_settings") else None
    values = {}
    if settings is not None:
        for name in _portable_setting_names():
            try:
                values[name] = _json_value(getattr(settings, name))
            except Exception:
                pass
    return values


def _off_commit_token_is_current(token, scene):
    return bool(
        token is not None
        and token is _SETTINGS_OFF_COMMIT_TOKEN
        and _settings_restore_token_is_current(token[:2])
        and str(token[1]) == _selection_scene_key(scene)
    )


def _arm_off_commit(scene):
    global _SETTINGS_OFF_COMMIT_TOKEN
    _SETTINGS_OFF_COMMIT_TOKEN = (
        int(_SETTINGS_RESTORE_SERIAL),
        _selection_scene_key(scene),
        object(),
    )
    return _SETTINGS_OFF_COMMIT_TOKEN


def _consume_off_commit(token):
    global _SETTINGS_OFF_COMMIT_TOKEN
    if token is not None and token is _SETTINGS_OFF_COMMIT_TOKEN:
        _SETTINGS_OFF_COMMIT_TOKEN = None


def _npanel_write_allowed(scene=None, *, off_commit_token=None):
    """Single policy gate used by every settings writer, including low-level callers."""
    if _SETTINGS_APPLYING:
        return False
    scene = scene or getattr(getattr(bpy, "context", None), "scene", None)
    settings = get_settings(scene) if scene is not None and hasattr(scene, "smart_id_settings") else None
    if settings is None or _SETTINGS_WRITE_BLOCKED:
        return False
    return bool(getattr(settings, "n_panel_state_save", True)) or _off_commit_token_is_current(off_commit_token, scene)


def _npanel_payload(scene=None):
    payload = dict(_SETTINGS_UNKNOWN_ROOT)
    values = dict(_SETTINGS_UNKNOWN_VALUES)
    values.update(_collect_npanel_settings(scene))
    payload.update({
        "schema": _SETTINGS_SCHEMA,
        "version": _SETTINGS_VERSION,
        "type": _SETTINGS_PAYLOAD_TYPE,
        "settings": values,
    })
    return payload


def _write_npanel_payload(payload, scene=None, *, off_commit_token=None):
    global _LAST_SETTINGS_SERIALIZED, _PENDING_SETTINGS_PAYLOAD, _SETTINGS_DIRTY
    if not _npanel_write_allowed(scene, off_commit_token=off_commit_token):
        return None
    serialized = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    path = _settings_path(create=True)
    if serialized == _LAST_SETTINGS_SERIALIZED and path.exists():
        _PENDING_SETTINGS_PAYLOAD = None
        _SETTINGS_DIRTY = False
        _consume_off_commit(off_commit_token)
        return path
    try:
        if path.exists() and path.read_text(encoding="utf-8") == serialized:
            _LAST_SETTINGS_SERIALIZED = serialized
            _PENDING_SETTINGS_PAYLOAD = None
            _SETTINGS_DIRTY = False
            _consume_off_commit(off_commit_token)
            return path
    except Exception:
        pass
    temporary = path.with_suffix(path.suffix + ".tmp")
    try:
        with temporary.open("w", encoding="utf-8", newline="") as handle:
            handle.write(serialized)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except OSError:
                pass
        os.replace(temporary, path)
    except Exception:
        try:
            temporary.unlink(missing_ok=True)
        except Exception:
            pass
        raise
    _LAST_SETTINGS_SERIALIZED = serialized
    _PENDING_SETTINGS_PAYLOAD = None
    _SETTINGS_DIRTY = False
    _consume_off_commit(off_commit_token)
    return path


def save_npanel_settings(scene=None, *, force=False, _off_commit_token=None):
    """Atomically persist portable settings after an actual user checkpoint."""
    del force  # Retained for backwards-compatible callers.
    if _SETTINGS_APPLYING:
        return None
    if not _npanel_write_allowed(scene, off_commit_token=_off_commit_token):
        return None
    return _write_npanel_payload(
        _npanel_payload(scene),
        scene,
        off_commit_token=_off_commit_token,
    )


def _defer_npanel_settings(scene=None):
    """Compatibility no-op: OFF mode never queues a later writer."""
    global _PENDING_SETTINGS_PAYLOAD, _SETTINGS_DIRTY
    del scene
    _PENDING_SETTINGS_PAYLOAD = None
    _SETTINGS_DIRTY = False


def flush_deferred_npanel_settings():
    """Compatibility no-op: direct/force/shutdown paths cannot write while OFF."""
    global _PENDING_SETTINGS_PAYLOAD, _SETTINGS_DIRTY
    _PENDING_SETTINGS_PAYLOAD = None
    _SETTINGS_DIRTY = False
    return None


def _setting_definition_keywords(name):
    try:
        prop_def = (getattr(SMARTID_PG_settings, "__annotations__", {}) or {}).get(str(name))
        keywords = getattr(prop_def, "keywords", None)
        return dict(keywords) if isinstance(keywords, dict) else {}
    except Exception:
        return {}


def _enum_item_identifiers(items):
    if not isinstance(items, (tuple, list)):
        return frozenset()
    result = set()
    for item in items:
        try:
            if isinstance(item, (tuple, list)) and item:
                result.add(str(item[0]))
        except Exception:
            pass
    return frozenset(result)


def _validate_setting_value(name, value):
    keywords = _setting_definition_keywords(name)
    if not keywords:
        return False, None
    if "items" in keywords:
        identifiers = _enum_item_identifiers(keywords.get("items"))
        if type(value) is not str or (identifiers and value not in identifiers):
            return False, None
        return True, value

    default = keywords.get("default")
    if type(default) is bool:
        return (type(value) is bool), value if type(value) is bool else None
    if type(default) is int:
        if type(value) is not int:
            return False, None
        minimum = keywords.get("min")
        maximum = keywords.get("max")
        if minimum is not None and value < int(minimum):
            return False, None
        if maximum is not None and value > int(maximum):
            return False, None
        return True, value
    if type(default) is float:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return False, None
        normalized = float(value)
        if not math.isfinite(normalized):
            return False, None
        minimum = keywords.get("min")
        maximum = keywords.get("max")
        if minimum is not None and normalized < float(minimum):
            return False, None
        if maximum is not None and normalized > float(maximum):
            return False, None
        return True, normalized
    if type(default) is str:
        if type(value) is not str:
            return False, None
        maxlen = keywords.get("maxlen")
        if maxlen is not None and len(value) > int(maxlen):
            return False, None
        return True, value
    return False, None


def _validate_npanel_payload(raw):
    if type(raw) is not dict:
        return None, "root must be an object"
    if type(raw.get("schema")) is not str or raw.get("schema") != _SETTINGS_SCHEMA:
        return None, "schema mismatch"
    version = raw.get("version")
    if type(version) is not str or version not in _SETTINGS_COMPATIBLE_VERSIONS:
        return None, "version mismatch"
    payload_type = raw.get("type")
    if version == _SETTINGS_VERSION:
        if type(payload_type) is not str or payload_type != _SETTINGS_PAYLOAD_TYPE:
            return None, "type mismatch"
    elif payload_type is not None and (type(payload_type) is not str or payload_type != _SETTINGS_PAYLOAD_TYPE):
        return None, "legacy type mismatch"
    values = raw.get("settings")
    if type(values) is not dict:
        return None, "settings must be an object"

    allowed = set(_portable_setting_names())
    normalized = {}
    for name, value in values.items():
        if type(name) is not str or name not in allowed:
            continue
        valid, normalized_value = _validate_setting_value(name, value)
        if not valid:
            return None, f"invalid setting type or range: {name}"
        normalized[name] = normalized_value
    return normalized, "ok"


def _load_npanel_values():
    global _LAST_SETTINGS_SERIALIZED, _SETTINGS_UNKNOWN_ROOT, _SETTINGS_UNKNOWN_VALUES, _SETTINGS_WRITE_BLOCKED
    path = _settings_path(create=False)
    try:
        serialized = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        _SETTINGS_WRITE_BLOCKED = False
        return {}, "missing"
    except Exception:
        _SETTINGS_WRITE_BLOCKED = True
        return {}, "unreadable"
    try:
        raw = _strict_json_loads(serialized)
    except Exception:
        _SETTINGS_WRITE_BLOCKED = True
        return {}, "invalid_json"
    values, status = _validate_npanel_payload(raw)
    if values is None:
        _SETTINGS_WRITE_BLOCKED = True
        return {}, status
    allowed = set(_portable_setting_names())
    _SETTINGS_UNKNOWN_ROOT = {
        key: value for key, value in raw.items()
        if key not in {"schema", "version", "type", "settings"}
    }
    raw_values = raw.get("settings", {})
    _SETTINGS_UNKNOWN_VALUES = {
        key: value for key, value in raw_values.items()
        if type(key) is str and key not in allowed
    }
    _LAST_SETTINGS_SERIALIZED = json.dumps(raw, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    _SETTINGS_WRITE_BLOCKED = False
    return values, "ok"


def _begin_settings_restore(scene):
    """Publish the restore barrier before RNA is materialized or assigned."""
    global _SETTINGS_RESTORE_SERIAL, _SETTINGS_RESTORE_SCENE_KEY, _SETTINGS_OFF_COMMIT_TOKEN
    _SETTINGS_RESTORE_SERIAL += 1
    _SETTINGS_RESTORE_SCENE_KEY = _selection_scene_key(scene)
    _SETTINGS_OFF_COMMIT_TOKEN = None
    return _SETTINGS_RESTORE_SERIAL, _SETTINGS_RESTORE_SCENE_KEY


def _settings_restore_token_is_current(token):
    return bool(
        isinstance(token, tuple)
        and len(token) == 2
        and int(token[0]) == int(_SETTINGS_RESTORE_SERIAL)
        and str(token[1]) == str(_SETTINGS_RESTORE_SCENE_KEY)
    )


def _invalidate_obsolete_same_scene_restore(scene):
    """A real user edit makes any older queued replay for this scene harmless."""
    return _begin_settings_restore(scene)


def _expose_settings_error(settings, status):
    global _SETTINGS_APPLYING, _SETTINGS_LAST_ERROR
    _SETTINGS_LAST_ERROR = str(status or "settings_error")
    if settings is None or not hasattr(settings, "last_report"):
        return
    previous = _SETTINGS_APPLYING
    _SETTINGS_APPLYING = True
    try:
        settings.last_report = t("report_settings_error")
    except Exception:
        pass
    finally:
        _SETTINGS_APPLYING = previous


def _commit_npanel_values(settings, values, restore_token=None):
    global _SETTINGS_APPLYING
    if settings is None or type(values) is not dict:
        return False
    previous_applying = _SETTINGS_APPLYING
    _SETTINGS_APPLYING = True
    changed = False
    try:
        for name, value in values.items():
            if restore_token is not None and not _settings_restore_token_is_current(restore_token):
                break
            if not hasattr(settings, name):
                continue
            try:
                if getattr(settings, name) != value:
                    setattr(settings, name, value)
                    changed = True
            except Exception:
                pass
    finally:
        _SETTINGS_APPLYING = previous_applying
    return changed


def apply_npanel_settings(scene=None, *, sync_runtime=True, restore_token=None):
    """Read and validate CONFIG without creating or modifying it, then commit once."""
    global _SETTINGS_APPLYING
    previous_applying = _SETTINGS_APPLYING
    _SETTINGS_APPLYING = True
    try:
        scene = scene or getattr(bpy.context, "scene", None)
        restore_token = restore_token or _begin_settings_restore(scene)
        settings = get_settings(scene) if scene is not None and hasattr(scene, "smart_id_settings") else None
        values, status = _load_npanel_values()
        changed = _commit_npanel_values(settings, values, restore_token) if settings is not None else False
        if status not in {"ok", "missing"}:
            _expose_settings_error(settings, status)
    finally:
        _SETTINGS_APPLYING = previous_applying
    if sync_runtime:
        sync_all_runtime_features(getattr(bpy, "context", None))
    return changed


def _on_npanel_setting_changed(context, property_name=""):
    if _SETTINGS_APPLYING:
        return
    scene = getattr(context or bpy.context, "scene", None)
    settings = get_settings(scene) if scene is not None and hasattr(scene, "smart_id_settings") else None
    _invalidate_obsolete_same_scene_restore(scene)
    if property_name in {"always_on_selection_inspector", "always_on_automatic_metadata_cleanup"}:
        sync_all_runtime_features(context)
    if settings is not None and property_name == "inspector_scope" and bool(getattr(settings, "always_on_selection_inspector", False)):
        _mark_inspector_data_dirty(scene, reason="inspector_scope", bump_revision=True)
    if settings is not None and bool(getattr(settings, "overlay_enabled", False)) and property_name in {
        "filter_type", "library_scope", "search", "naming_profile",
    }:
        schedule_overlay_snapshot_rebuild(scene)
    if settings is not None:
        try:
            if property_name == "n_panel_state_save":
                enabled = bool(getattr(settings, "n_panel_state_save", True))
                off_commit_token = None if enabled else _arm_off_commit(scene)
                save_npanel_settings(
                    scene,
                    force=True,
                    _off_commit_token=off_commit_token,
                )
            elif bool(getattr(settings, "n_panel_state_save", True)):
                save_npanel_settings(scene)
        except Exception as exc:
            _expose_settings_error(settings, f"write_failed:{type(exc).__name__}")


def _wrap_setting_update(previous, property_name):
    def _update(self, context):
        if callable(previous) and not _SETTINGS_APPLYING:
            previous(self, context)
        _on_npanel_setting_changed(context, property_name)
    _update.__name__ = f"_smart_id_setting_update_{property_name}"
    _update._smart_id_wrapped_update = previous
    _update._smart_id_property_name = property_name
    return _update

# -----------------------------------------------------------------------------
# Localization
# -----------------------------------------------------------------------------

UI_EN = {
    "panel_title": "Smart ID Suite",
    "selection_inspector_auto_refresh": "Selection Inspector Auto Refresh",
    "library": "ID / Channel Library",
    "entry_details": "Selected Entry",
    "assignment": "Assignment",
    "channel_tools": "Map / Attribute Channels",
    "validation_io": "Validation / Import / Export",
    "add": "Add",
    "remove": "Remove",
    "duplicate": "Duplicate",
    "move_up": "Move Up",
    "move_down": "Move Down",
    "sort": "Sort",
    "renumber": "Renumber",
    "refresh": "Refresh Counts",
    "refresh_selection_changed": "Selection Changed: Refresh",
    "apply": "Apply to Selection",
    "select": "Select by Entry",
    "sync": "Sync from Scene",
    "validate": "Validate",
    "create_materials": "Create ID Materials",
    "export_json": "Export JSON",
    "import_json": "Import JSON",
    "export_csv": "Export CSV",
    "active_entry": "Active Entry",
    "no_entry": "No entry is selected.",
    "enabled": "Enabled",
    "locked": "Locked",
    "type": "Type",
    "name": "Name",
    "id_number": "ID Number",
    "color": "Display Color",
    "map_channel": "Map Channel",
    "channel_name": "Channel Name",
    "uv_map": "UV Map",
    "color_attribute": "Color Attribute",
    "attribute_name": "Attribute Name",
    "attribute_type": "Attribute Type",
    "attribute_domain": "Attribute Domain",
    "group_name": "Group Name",
    "udim_tile": "UDIM Tile",
    "export_tag": "Export Tag",
    "notes": "Notes",
    "scope": "Target Scope",
    "material_mode": "Material Target",
    "new_type": "New Entry Type",
    "naming_profile": "Naming Profile",
    "filter_type": "Filter Type",
    "library_scope": "Library Match Scope",
    "library_scope_selected": "Selected Objects",
    "library_scope_active": "Active Object",
    "library_scope_scene": "Scene Objects",
    "sync_selected": "Sync from Selection",
    "selection_matches": "Selection Matches",
    "scene_matches": "Scene Matches",
    "search": "Search",
    "sort_mode": "Sort Mode",
    "renumber_start": "Renumber Start",
    "renumber_step": "Renumber Step",
    "use_pass_index": "Write Blender Pass Index",
    "write_custom_props": "Write Custom Properties",
    "create_missing_material": "Create Missing ID Material",
    "select_faces": "Select Matching Faces",
    "include_disabled": "Include Disabled Entries",
    "clear_on_import": "Clear Existing on Import",
    "auto_color": "Auto Color",
    "result": "Result",
    "last_report": "Last Report",
    "object_count": "Objects",
    "material_count": "Materials",
    "channel_count": "Channels",
    "list_count": "Items",
    "multi_selected": "Multi Select",
    "selected_count": "Selected",
    "select_visible": "Select Visible",
    "clear_selection": "Clear Selection",
    "delete_selected": "Delete Selected",
    "selected_objects_in_inspector": "In Inspector",
    "object_id": "Object ID",
    "material_id": "Material ID",
    "map_channel_id": "Map Channel",
    "uv_channel": "UV Channel",
    "color_attribute_id": "Color Attribute",
    "geometry_attribute": "Geometry Attribute",
    "udim_tile_id": "UDIM Tile",
    "selection_set": "Selection Set",
    "render_aov": "Render AOV",
    "cryptomatte_id": "Cryptomatte Tag",
    "weight_group": "Weight Group",
    "custom_id": "Custom ID",
    "all": "All",
    "selected": "Selected Objects",
    "active": "Active Object",
    "scene": "Scene Objects",
    "all_meshes": "All Mesh Objects",
    "active_slot": "Active Material Slot",
    "all_slots": "All Material Slots",
    "selected_faces": "Selected Faces",
    "create_assign": "Create and Assign ID Material",
    "sort_manual": "Manual",
    "sort_type": "Type then ID",
    "sort_id": "ID Number",
    "sort_name": "Name",
    "profile_blender": "Blender",
    "profile_3dsmax": "3ds Max",
    "profile_maya": "Maya",
    "profile_mari": "Mari",
    "profile_zbrush": "ZBrush",
    "profile_c4d": "Cinema 4D",
    "profile_lightwave": "LightWave",
    "profile_custom": "Custom",
    "apply_channel": "Create / Activate Channel",
    "delete_channel": "Delete Channel from Selection",
    "copy_active_to_entry": "Read Active Selection",
    "create_aov": "Create View Layer AOV",
    "create_selection_collection": "Create Selection Collection",
    "info_library": "Manage each production ID as a list entry, then apply it to objects, materials or channels. The library can judge rows against the active or selected objects, so only IDs, channels and groups found in the current selection are shown when that scope is enabled. Entries nothing uses yet, such as one you just added, stay visible in every scope. Render AOV rows belong to the view layer, not to objects, so they also stay visible. The active row and checked rows stay visible as well, because the operation buttons act on them.\nThe list judges against the selection at the last count. After you change the selection, all rows are shown with '-' as the selected count until you press the button under the list (or turn on Selection Inspector Auto Refresh).\nThe right number counts objects (mesh channels for channel rows). A material row counts the objects using that material.\nClick the row checkbox to multi-select. Shift-click selects the visible range from the previous selection anchor to the clicked row.\nWhen Smart ID rows are multi-selected, operation buttons use the selected rows together. With no checked rows, they use the active row.",
    "info_assignment": "Apply the selected entry to the chosen target scope. Disabled or locked entries are protected.",
    "info_channels": "Create UV sets, color attributes, geometry attributes and map-channel mappings on selected mesh objects.",
    "info_io": "Validate duplicates and missing data, then export or import the registry as a JSON preset.",
}

UI_JA = {
    "panel_title": "Smart ID Suite",
    "selection_inspector_auto_refresh": "検査の自動更新",
    "library": "ID / チャンネルライブラリ",
    "entry_details": "選択項目",
    "assignment": "割り当て",
    "channel_tools": "マップ / 属性チャンネル",
    "validation_io": "検証 / 読み込み / 書き出し",
    "add": "追加",
    "remove": "削除",
    "duplicate": "複製",
    "move_up": "上へ",
    "move_down": "下へ",
    "sort": "並べ替え",
    "renumber": "番号振り直し",
    "refresh": "件数更新",
    "refresh_selection_changed": "選択変更：件数更新",
    "apply": "選択へ適用",
    "select": "項目で選択",
    "sync": "シーンから同期",
    "validate": "検証",
    "create_materials": "IDマテリアル作成",
    "export_json": "JSON書き出し",
    "import_json": "JSON読み込み",
    "export_csv": "CSV書き出し",
    "active_entry": "現在の項目",
    "no_entry": "項目が選択されていません。",
    "enabled": "有効",
    "locked": "ロック",
    "type": "種類",
    "name": "名前",
    "id_number": "ID番号",
    "color": "表示色",
    "map_channel": "マップチャンネル",
    "channel_name": "チャンネル名",
    "uv_map": "UVマップ",
    "color_attribute": "カラー属性",
    "attribute_name": "属性名",
    "attribute_type": "属性タイプ",
    "attribute_domain": "属性ドメイン",
    "group_name": "グループ名",
    "udim_tile": "UDIMタイル",
    "export_tag": "書き出しタグ",
    "notes": "メモ",
    "scope": "対象範囲",
    "material_mode": "マテリアル対象",
    "new_type": "新規項目タイプ",
    "naming_profile": "命名プロファイル",
    "filter_type": "表示タイプ",
    "library_scope": "ライブラリ判定範囲",
    "library_scope_selected": "選択オブジェクト",
    "library_scope_active": "アクティブオブジェクト",
    "library_scope_scene": "シーン内オブジェクト",
    "sync_selected": "選択から同期",
    "selection_matches": "選択一致",
    "scene_matches": "シーン一致",
    "search": "検索",
    "sort_mode": "並べ替え方式",
    "renumber_start": "開始番号",
    "renumber_step": "増分",
    "use_pass_index": "Blenderパス番号へ書き込み",
    "write_custom_props": "カスタムプロパティへ書き込み",
    "create_missing_material": "不足IDマテリアルを作成",
    "select_faces": "一致フェイスも選択",
    "include_disabled": "無効項目も含める",
    "clear_on_import": "読み込み時に既存項目を消去",
    "auto_color": "自動色",
    "result": "結果",
    "last_report": "前回レポート",
    "object_count": "オブジェクト",
    "material_count": "マテリアル",
    "channel_count": "チャンネル",
    "list_count": "項目数",
    "multi_selected": "複数選択",
    "selected_count": "選択数",
    "select_visible": "表示中を選択",
    "clear_selection": "選択解除",
    "delete_selected": "選択項目を削除",
    "selected_objects_in_inspector": "検査中",
    "object_id": "オブジェクトID",
    "material_id": "マテリアルID",
    "map_channel_id": "マップチャンネル",
    "uv_channel": "UVチャンネル",
    "color_attribute_id": "カラー属性",
    "geometry_attribute": "ジオメトリ属性",
    "udim_tile_id": "UDIMタイル",
    "selection_set": "選択セット",
    "render_aov": "レンダーAOV",
    "cryptomatte_id": "Cryptomatteタグ",
    "weight_group": "ウェイトグループ",
    "custom_id": "カスタムID",
    "all": "すべて",
    "selected": "選択オブジェクト",
    "active": "アクティブオブジェクト",
    "scene": "シーン内オブジェクト",
    "all_meshes": "全メッシュオブジェクト",
    "active_slot": "アクティブマテリアルスロット",
    "all_slots": "全マテリアルスロット",
    "selected_faces": "選択フェイス",
    "create_assign": "IDマテリアルを作成して割り当て",
    "sort_manual": "手動",
    "sort_type": "種類とID順",
    "sort_id": "ID番号順",
    "sort_name": "名前順",
    "profile_blender": "Blender",
    "profile_3dsmax": "3ds Max",
    "profile_maya": "Maya",
    "profile_mari": "Mari",
    "profile_zbrush": "ZBrush",
    "profile_c4d": "Cinema 4D",
    "profile_lightwave": "LightWave",
    "profile_custom": "カスタム",
    "apply_channel": "チャンネル作成 / 有効化",
    "delete_channel": "選択からチャンネル削除",
    "copy_active_to_entry": "アクティブ選択を読み取り",
    "create_aov": "ビュー レイヤーAOV作成",
    "create_selection_collection": "選択コレクション作成",
    "info_library": "制作で使う各IDをリスト項目として管理し、オブジェクト・マテリアル・チャンネルへ適用します。ライブラリ判定範囲を選択またはアクティブにすると、現在の選択に含まれるID、チャンネル、属性、グループだけを判定して表示できます。どこにも使われていない項目（追加したばかりの項目など）は、判定範囲に関わらず表示します。レンダーAOVの行はオブジェクトでなくビューレイヤーの物なので、これも常に表示します。選んでいる行とチェックした行も、操作ボタンの対象なので表示したままにします。\n判定に使うのは、最後に数えた時の選択です。選択を変えると、一覧の下のボタンを押すまで（または「検査の自動更新」を有効にするまで）、全部の行を表示し、選択の数を「-」で出します。\n右の数はオブジェクトの数です（チャンネルの行はメッシュチャンネルの数）。マテリアルの行は、そのマテリアルを使うオブジェクトの数です。\n行頭のチェックボックスで複数選択します。Shiftクリックすると、前回の選択基準行からクリックした行までの表示中範囲を選択します。\nSmart ID行を複数選択している場合、各操作ボタンは選択行をまとめて処理します。チェック行が無い場合はアクティブ行だけを処理します。",
    "info_assignment": "選択中の項目を指定した対象範囲へ適用します。無効またはロック中の項目は保護されます。",
    "info_channels": "選択メッシュにUVセット、カラー属性、ジオメトリ属性、マップチャンネル対応情報を作成します。",
    "info_io": "重複や不足データを検証し、登録リストをJSONプリセットとして読み書きします。",
}

DESCRIPTIONS_EN = {
    "entry_enabled": "Enable this entry. Disabled entries remain in the library but are skipped by apply, validation and export actions unless the relevant option includes them.",
    "entry_locked": "Lock this entry so destructive actions cannot change or delete it. Use this for production IDs that must stay stable across files and exports.",
    "entry_type": "Choose what kind of production identifier this item controls, such as an Object ID, Material ID, 3ds Max-style map channel, Maya-style UV/color set, Mari-style UDIM metadata or a Blender attribute.",
    "entry_name": "Readable list name used in the Smart ID Suite UI and exported presets. Keep it stable if other artists or tools reference this ID.",
    "entry_id_number": "Numeric ID used for Blender pass index values, external pipeline IDs and list sorting. Object and material IDs can write this value to Blender's Index OB/Index MA compatible pass index.",
    "entry_color": "Display color used for generated ID materials, object viewport color and visual identification in the list. This does not alter rendered shading unless you assign the generated material.",
    "entry_map_channel": "Numeric map channel used to emulate 3ds Max map channels. In Blender this is stored as custom metadata and resolved to a UV map name on mesh objects.",
    "entry_channel_name": "Channel name to create or activate on selected mesh objects. Use this for UV sets, map-channel mappings, color attributes, geometry attributes or DCC-compatible export names.",
    "entry_uv_map": "Explicit UV map name. When empty, Smart ID Suite uses the channel name or generates a name from the selected naming profile.",
    "entry_color_attribute": "Color attribute name for vertex color or corner color data. This is the Blender equivalent of color sets and can be used for masks, IDs or paint channels.",
    "entry_attribute_name": "Generic geometry attribute name. Use this for integer, float, vector, color or boolean channel data stored on a mesh domain.",
    "entry_attribute_type": "Data type for a new geometry attribute. Choose a type that matches the target pipeline: integer IDs, float masks, vector channels, colors or booleans.",
    "entry_attribute_domain": "Mesh domain for a new geometry attribute. Point stores per-vertex data, Face stores per-polygon data, and Corner stores per-face-corner data similar to UVs.",
    "entry_group_name": "Selection set, collection or vertex group name created from this entry. This keeps DCC-style sets visible in Blender's scene structure.",
    "entry_udim_tile": "UDIM tile number such as 1001. Smart ID Suite stores this as metadata so Mari, texture-paint and export workflows can keep tile assignments in the ID registry.",
    "entry_export_tag": "Optional export-facing tag. Use this when a USD, FBX, game, render or look-dev pipeline needs a stable short token different from the visible name.",
    "entry_notes": "Free-form production notes for the ID. Use this for assignment rules, asset-owner information, map-channel meaning or downstream export instructions.",
    "settings_scope": "Select which objects the operation affects. Selected Objects is safest; Scene Objects is useful for file-wide synchronization or validation.",
    "settings_material_mode": "Choose which material slots receive a Material ID. Active Slot changes only the active slot, All Slots touches every slot, Selected Faces assigns the generated material to selected polygons when possible.",
    "settings_new_type": "Choose the type used by the Add button. The type determines which Blender data block or channel is created when applying the entry.",
    "settings_naming_profile": "Select naming conventions inspired by common DCC workflows. It changes generated channel names only; it does not change existing names.",
    "settings_filter_type": "Limit the list to one ID or channel type. Choose All to show every registered entry.",
    "settings_search": "Text filter for the list. It searches entry names, channel names, export tags and notes.",
    "entry_multi_selected": "Mark this Smart ID entry as part of the multi-selection set. Use this for batch deletion while keeping the normal active-row selection available for editing and single-entry operations.",
    "inspector_multi_selected": "Mark this selected-object inspector row as part of the multi-selection set. Batch deletion uses the selected rows and removes or clears their corresponding real object, material, mesh, attribute, channel or group data.",
    "operator_entry_multi_select": "Toggle this Smart ID row in the multi-selection set. Shift-click selects the visible filtered range between the previous selection anchor and this row, so large ID or channel blocks can be selected quickly.",
    "operator_inspector_multi_select": "Toggle this selected-object inspector row in the multi-selection set. Shift-click selects the visible filtered range between the previous selection anchor and this row for batch operations.",
    "operator_entry_select_visible": "Select every Smart ID row that is currently visible under the active type filter and search text. Hidden rows are not changed, so filtered batch deletion stays controllable.",
    "operator_entry_clear_selection": "Clear the Smart ID multi-selection marks from all rows. This does not change the active row or any object assignment; it only resets the batch-selection state.",
    "operator_entry_delete_selected": "Delete all selected Smart ID rows at once. Locked rows are skipped to protect stable production IDs, and the active row is moved to the nearest remaining entry.",
    "operator_inspector_select_visible": "Select every visible selected-object inspector row under the current inspector type filter and search text. Hidden rows are not changed.",
    "operator_inspector_clear_selection": "Clear the selected-object inspector multi-selection marks from all rows. This does not change scene data; it only resets the batch-selection state.",
    "operator_inspector_delete_selected": "Delete or clear all selected inspector rows from their real owners. Protected rows are skipped; UV maps, attributes, vertex groups, material slots, collection links and metadata are removed using the same safeguards as single-row deletion.",
    "settings_sort_mode": "Choose how the Sort button orders the list. Manual keeps your current order, while Type, ID and Name are useful for larger registries.",
    "settings_renumber_start": "First number used by Renumber. This is useful when reserving ID ranges for departments, assets or render passes.",
    "settings_renumber_step": "Increment used by Renumber. A value above one leaves gaps for later insertions.",
    "settings_use_pass_index": "When enabled, Object ID and Material ID entries write their number to Blender's pass index for Index OB / Index MA style render workflows.",
    "settings_write_custom_props": "When enabled, Smart ID Suite writes stable custom properties to objects, materials and meshes so IDs remain searchable even if pass indices change.",
    "settings_create_missing_material": "When enabled, Material ID operations create an ID material if the selected object has no suitable material slot.",
    "settings_select_faces": "When enabled, Select by Entry also selects polygons that use a matching material ID when Blender can safely switch mesh selection state.",
    "settings_include_disabled": "When enabled, export and validation tools include disabled entries. Keep this off when disabled entries are only drafts.",
    "settings_clear_on_import": "When enabled, JSON import removes the current registry before loading. Keep it off to merge an imported preset into the current list.",
    "operator_add": "Add a new Smart ID entry using the selected entry type, the next available ID number and a generated name based on the active naming profile.",
    "operator_remove": "Delete the selected Smart ID entry. Locked entries are protected so stable production IDs are not removed accidentally.",
    "operator_duplicate": "Duplicate the selected Smart ID entry with a new unique ID number and UID. This is useful when creating related masks or adjacent map channels.",
    "operator_move_up": "Move the selected entry upward in the list. Manual ordering is preserved until Sort is used.",
    "operator_move_down": "Move the selected entry downward in the list. Manual ordering is preserved until Sort is used.",
    "operator_sort": "Sort the Smart ID list using the selected sort mode. Locked entries keep their data, but their list position may change.",
    "operator_renumber": "Renumber unlocked visible entries from the configured start value and step. This is useful after restructuring a large ID list.",
    "operator_refresh": "Recount how many objects or mesh channels currently match each entry, and judge the list again against the current selection. Unless the scope is Scene Objects, IDs and channels found on the target objects that are not in the list yet are added as new rows. The active row does not change.",
    "operator_apply": "Apply the selected entry to the target scope. Depending on type, this writes pass indices, custom properties, materials, UV maps, attributes, collections, AOVs or vertex groups.",
    "operator_select": "Select scene objects that match the selected entry. For material IDs it selects objects using matching materials; for channels it selects meshes containing the target channel.",
    "operator_sync": "Scan the scene and add missing Smart ID entries for existing object pass indices, material pass indices, UV maps, color attributes, geometry attributes, vertex groups and stored Smart ID metadata.",
    "operator_validate": "Check the registry for duplicate IDs, empty names, missing channels and invalid target data. A detailed report is written to a Blender text block.",
    "operator_create_materials": "Create or update ID materials for all material-ID entries. Generated materials use the entry color and pass index for quick viewport identification.",
    "operator_export_json": "Export the Smart ID registry to a JSON preset file that can be reused in another Blender file or pipeline tool.",
    "operator_import_json": "Import Smart ID entries from a JSON preset. You can merge the preset or clear the current list first using the import option.",
    "operator_export_csv": "Export the registry to CSV for review in spreadsheet tools, production trackers or pipeline documentation.",
    "operator_channel_apply": "Create or activate the selected entry's UV map, map channel, color attribute or geometry attribute on the target mesh objects.",
    "operator_channel_delete": "Delete the selected entry's channel from the target mesh objects. Locked entries are protected and object/material IDs are not affected.",
    "operator_read_active": "Read the active object's current material, UV map, color attribute or pass index into the selected entry, depending on the entry type.",
    "operator_create_aov": "Create a View Layer AOV using the selected entry name. This is a render-channel convenience for mask and look-dev workflows.",
    "operator_create_collection": "Create or update a collection from the selected objects using the entry group name. This behaves like a simple DCC-style selection set.",
}

DESCRIPTIONS_JA = {
    "entry_enabled": "この項目を有効にします。無効の項目はライブラリには残りますが、関連オプションで含めない限り、適用・検証・書き出し処理ではスキップされます。",
    "entry_locked": "この項目をロックし、破壊的な変更や削除から保護します。複数ファイルや書き出し先で固定する必要がある制作IDに使用してください。",
    "entry_type": "この項目が管理する制作IDの種類を選びます。オブジェクトID、マテリアルID、3ds Max風マップチャンネル、Maya風UV/カラーセット、Mari風UDIM情報、Blender属性などを扱えます。",
    "entry_name": "Smart ID SuiteのUIと書き出しプリセットで使う読みやすい名前です。他の作業者や外部ツールが参照するIDでは安定した名前にしてください。",
    "entry_id_number": "Blenderのパス番号、外部パイプラインID、リスト並べ替えに使う数値IDです。オブジェクトIDとマテリアルIDではIndex OB / Index MA互換のパス番号へ書き込めます。",
    "entry_color": "生成IDマテリアル、オブジェクトのビューポート色、リスト上の識別に使う表示色です。生成マテリアルを割り当てない限り、通常のレンダーシェーディングは変更しません。",
    "entry_map_channel": "3ds Maxのマップチャンネルを再現するための数値チャンネルです。Blenderではカスタムメタデータとして保存し、メッシュ上のUVマップ名へ解決します。",
    "entry_channel_name": "選択メッシュ上に作成または有効化するチャンネル名です。UVセット、マップチャンネル対応、カラー属性、ジオメトリ属性、DCC互換の書き出し名に使用します。",
    "entry_uv_map": "明示的なUVマップ名です。空の場合はチャンネル名を使い、それも空の場合は選択中の命名プロファイルから名前を生成します。",
    "entry_color_attribute": "頂点カラーまたはコーナーカラー用のカラー属性名です。カラーセットに相当し、マスク、ID、ペイントチャンネルとして使用できます。",
    "entry_attribute_name": "汎用ジオメトリ属性名です。整数、浮動小数、ベクトル、カラー、真偽値のチャンネルデータをメッシュドメインに保存できます。",
    "entry_attribute_type": "新規ジオメトリ属性のデータ型です。整数ID、浮動小数マスク、ベクトルチャンネル、カラー、真偽値など、対象パイプラインに合わせて選びます。",
    "entry_attribute_domain": "新規ジオメトリ属性のメッシュドメインです。「ポイント」は頂点単位、「面」はポリゴン単位、「コーナー」はUVのような面コーナー単位で保存します。",
    "entry_group_name": "この項目から作成する選択セット、コレクション、または頂点グループ名です。DCC風のセットをBlenderのシーン構造内で見える状態に保ちます。",
    "entry_udim_tile": "1001などのUDIMタイル番号です。Mari、テクスチャペイント、書き出しワークフローでタイル割り当てをIDレジストリ内に保持するためのメタデータとして保存します。",
    "entry_export_tag": "書き出し用の任意タグです。USD、FBX、ゲーム、レンダー、ルック開発パイプラインで表示名とは別の安定した短いトークンが必要な場合に使います。",
    "entry_notes": "IDに関する自由記述の制作メモです。割り当てルール、担当情報、マップチャンネルの意味、下流工程の書き出し指示などに使います。",
    "settings_scope": "処理対象のオブジェクト範囲を選びます。通常は選択オブジェクトが安全で、シーン全体の同期や検証にはシーン内オブジェクトが便利です。",
    "settings_material_mode": "マテリアルIDを書き込むスロットを選びます。アクティブスロットは1つだけ、全スロットはすべて、選択フェイスでは可能な場合に選択ポリゴンへ生成マテリアルを割り当てます。",
    "settings_new_type": "追加ボタンで作成する項目タイプを選びます。タイプによって、適用時に作成されるBlenderデータブロックやチャンネルが変わります。",
    "settings_naming_profile": "主要DCCの運用を参考にした命名規則を選びます。生成されるチャンネル名だけが変わり、既存名は変更しません。",
    "settings_filter_type": "リスト表示を特定のIDまたはチャンネルタイプに絞り込みます。すべてを選ぶと登録済みの全項目を表示します。",
    "settings_search": "リストの文字検索です。項目名、チャンネル名、書き出しタグ、メモを検索します。",
    "entry_multi_selected": "このSmart ID項目を複数選択対象にします。通常のアクティブ行選択は編集や単体操作用に残したまま、一括削除用の選択状態として使います。",
    "inspector_multi_selected": "この選択オブジェクト検査行を複数選択対象にします。一括削除では、選択された行が表す実際のオブジェクト、マテリアル、メッシュ、属性、チャンネル、グループデータを削除または解除します。",
    "operator_entry_multi_select": "このSmart ID行の複数選択状態を切り替えます。Shiftクリックでは、前回の選択基準行からこの行までの表示中フィルター範囲をまとめて選択できます。",
    "operator_inspector_multi_select": "この選択オブジェクト検査行の複数選択状態を切り替えます。Shiftクリックでは、前回の選択基準行からこの行までの表示中フィルター範囲をまとめて選択できます。",
    "operator_entry_select_visible": "現在の表示タイプと検索条件で見えているSmart ID行をすべて選択します。非表示行は変更しないため、絞り込み中の一括削除を安全に行えます。",
    "operator_entry_clear_selection": "すべてのSmart ID行の複数選択マークを解除します。アクティブ行やオブジェクトへの割り当ては変更せず、一括処理用の選択状態だけをリセットします。",
    "operator_entry_delete_selected": "選択済みのSmart ID行をまとめて削除します。ロック中の行は安定した制作IDを保護するためスキップし、削除後は近い残存行をアクティブにします。",
    "operator_inspector_select_visible": "現在の検査表示タイプと検索条件で見えている選択オブジェクト検査行をすべて選択します。非表示行は変更しません。",
    "operator_inspector_clear_selection": "すべての選択オブジェクト検査行の複数選択マークを解除します。シーンデータは変更せず、一括処理用の選択状態だけをリセットします。",
    "operator_inspector_delete_selected": "選択済みの検査行をまとめて実データから削除または解除します。保護行はスキップし、UVマップ、属性、頂点グループ、マテリアルスロット、コレクションリンク、メタデータを単体削除と同じ保護付き処理で削除します。",
    "settings_sort_mode": "並べ替えボタンで使う順序を選びます。手動は現在の順序を維持し、種類、ID、名前は大きいレジストリで便利です。",
    "settings_renumber_start": "番号振り直しで使う最初の番号です。部署、アセット、レンダーパスごとにID範囲を予約する場合に便利です。",
    "settings_renumber_step": "番号振り直しの増分です。1より大きい値にすると、後から挿入できる番号の隙間を残せます。",
    "settings_use_pass_index": "有効にすると、オブジェクトIDとマテリアルIDの番号をBlenderのパス番号へ書き込み、Index OB / Index MA系のレンダーワークフローに対応します。",
    "settings_write_custom_props": "有効にすると、オブジェクト、マテリアル、メッシュに安定したカスタムプロパティを書き込み、パス番号が変わってもID検索できるようにします。",
    "settings_create_missing_material": "有効にすると、選択オブジェクトに適切なマテリアルスロットがない場合、マテリアルID処理でIDマテリアルを作成します。",
    "settings_select_faces": "有効にすると、項目で選択する処理で、一致するマテリアルIDを使用しているポリゴンも安全に選択できる場合に選択します。",
    "settings_include_disabled": "有効にすると、書き出しと検証で無効項目も含めます。無効項目を下書きとして使う場合はオフのままにしてください。",
    "settings_clear_on_import": "有効にすると、JSON読み込み前に現在のレジストリを削除します。現在のリストへ統合したい場合はオフにしてください。",
    "operator_add": "選択中の項目タイプ、次に使えるID番号、アクティブな命名プロファイルに基づく生成名で、新しいSmart ID項目を追加します。",
    "operator_remove": "選択中のSmart ID項目を削除します。安定した制作IDを誤って消さないように、ロック中の項目は保護されます。",
    "operator_duplicate": "選択中のSmart ID項目を、新しい一意のID番号とUIDで複製します。関連マスクや隣接するマップチャンネルを作る場合に便利です。",
    "operator_move_up": "選択中の項目をリスト内で上へ移動します。並べ替えを実行するまで、手動順序は保持されます。",
    "operator_move_down": "選択中の項目をリスト内で下へ移動します。並べ替えを実行するまで、手動順序は保持されます。",
    "operator_sort": "選択中の並べ替え方式でSmart IDリストを並べ替えます。ロック中の項目もデータは保持されますが、表示位置は変わる場合があります。",
    "operator_renumber": "表示中の未ロック項目を、設定した開始番号と増分で振り直します。大きなIDリストを整理した後に便利です。",
    "operator_refresh": "各項目に一致するオブジェクトとメッシュチャンネルの数を数え直し、今の選択で一覧を判定し直します。判定範囲が選択かアクティブの時は、対象の物にあって一覧に無い ID とチャンネルを行として足します。選んでいる行は変わりません。",
    "operator_apply": "選択中の項目を対象範囲へ適用します。タイプに応じて、パス番号、カスタムプロパティ、マテリアル、UVマップ、属性、コレクション、AOV、頂点グループを書き込みます。",
    "operator_select": "選択中の項目に一致するシーンオブジェクトを選択します。マテリアルIDでは一致マテリアル使用オブジェクトを、チャンネルでは対象チャンネルを持つメッシュを選択します。",
    "operator_sync": "シーンを走査し、既存のオブジェクトパス番号、マテリアルパス番号、UVマップ、カラー属性、ジオメトリ属性、頂点グループ、保存済みSmart IDメタデータから不足項目を追加します。",
    "operator_validate": "レジストリ内の重複ID、空の名前、不足チャンネル、無効な対象データを確認します。詳細レポートはBlenderのテキストブロックへ書き込みます。",
    "operator_create_materials": "すべてのマテリアルID項目に対してIDマテリアルを作成または更新します。生成マテリアルは項目の色とパス番号を使い、ビューポート上で識別しやすくします。",
    "operator_export_json": "Smart IDレジストリをJSONプリセットとして書き出し、別のBlenderファイルやパイプラインツールで再利用できるようにします。",
    "operator_import_json": "JSONプリセットからSmart ID項目を読み込みます。読み込みオプションにより、現在のリストへ統合するか、先に消去するかを選べます。",
    "operator_export_csv": "スプレッドシート、制作トラッカー、パイプライン資料で確認できるように、レジストリをCSVとして書き出します。",
    "operator_channel_apply": "選択中の項目に対応するUVマップ、マップチャンネル、カラー属性、ジオメトリ属性を対象メッシュに作成または有効化します。",
    "operator_channel_delete": "選択中の項目に対応するチャンネルを対象メッシュから削除します。ロック中の項目は保護され、オブジェクトIDとマテリアルIDには影響しません。",
    "operator_read_active": "選択中の項目タイプに応じて、アクティブオブジェクトの現在のマテリアル、UVマップ、カラー属性、またはパス番号を項目へ読み取ります。",
    "operator_create_aov": "選択中の項目名を使ってビュー レイヤーAOVを作成します。マスクやルック開発向けのレンダーチャンネル補助機能です。",
    "operator_create_collection": "選択中のオブジェクトから、項目のグループ名を使ったコレクションを作成または更新します。簡易的なDCC風選択セットとして機能します。",
}


# Selection inspector localization additions.
UI_EN.update({
    "selection_inspector": "Selected Object Inspector",
    "inspector_scope": "Inspector Scope",
    "inspector_filter": "Inspector Filter",
    "inspector_search": "Inspector Search",
    "inspector_refresh": "Refresh Selection Data",
    "inspector_apply": "Apply Item Settings",
    "inspector_delete": "Delete / Clear Item",
    "inspector_make_entry": "Create Smart ID Entry",
    "inspector_select_owner": "Select Owner",
    "inspector_apply_entry": "Set from Active Smart ID",
    "inspector_no_item": "No selected-object data is listed. Select objects and refresh.",
    "inspector_truncated": "Inspector display is limited to {shown} of {total} items; {omitted} additional items are not shown. Source data is unchanged.",
    "inspector_item_details": "Selected Data Item",
    "inspector_item_type": "Data Type",
    "inspector_owner_object": "Owner Object",
    "inspector_owner_data": "Owner Data",
    "inspector_item_name": "Current Name",
    "inspector_edit_name": "Name / Channel",
    "inspector_slot_index": "Slot Index",
    "inspector_value": "Value",
    "inspector_active": "Active",
    "inspector_render": "Render",
    "inspector_data_type": "Attribute Type",
    "inspector_domain": "Domain",
    "inspector_safe_delete": "Deletable",
    "inspect_smart_metadata": "Smart ID Metadata",
    "inspect_custom_property": "Custom Property",
    "inspector_protected": "Protected",
    "info_inspector": "Scan the selected objects and edit the IDs, material slots, UVs, attributes, groups and Smart ID metadata they already contain.\nClick the row checkbox to multi-select. Shift-click selects the visible range from the previous selection anchor to the clicked row.\nWhen inspector rows are multi-selected, operation buttons process all selected rows. With no checked rows, they process the active row.",
})

UI_JA.update({
    "selection_inspector": "選択オブジェクト検査",
    "inspector_scope": "検査範囲",
    "inspector_filter": "検査表示タイプ",
    "inspector_search": "検査検索",
    "inspector_refresh": "選択データ更新",
    "inspector_apply": "項目設定を適用",
    "inspector_delete": "項目を削除 / 解除",
    "inspector_make_entry": "Smart ID項目化",
    "inspector_select_owner": "所有オブジェクトを選択",
    "inspector_apply_entry": "アクティブSmart IDから設定",
    "inspector_no_item": "選択オブジェクト内データが表示されていません。オブジェクトを選択して更新してください。",
    "inspector_truncated": "検査表示は全{total}項目中{shown}項目までです。残り{omitted}項目は表示されていませんが、元データは変更されていません。",
    "inspector_item_details": "選択データ項目",
    "inspector_item_type": "データタイプ",
    "inspector_owner_object": "所有オブジェクト",
    "inspector_owner_data": "所有データ",
    "inspector_item_name": "現在名",
    "inspector_edit_name": "名前 / チャンネル",
    "inspector_slot_index": "スロット番号",
    "inspector_value": "値",
    "inspector_active": "アクティブ",
    "inspector_render": "レンダー",
    "inspector_data_type": "属性タイプ",
    "inspector_domain": "ドメイン",
    "inspector_safe_delete": "削除可能",
    "inspect_smart_metadata": "Smart IDメタデータ",
    "inspect_custom_property": "カスタムプロパティ",
    "inspector_protected": "保護中",
    "info_inspector": "選択中オブジェクトに含まれる既存のID、マテリアルスロット、UV、属性、グループ、Smart IDメタデータを走査し、その場で編集します。\n行頭のチェックボックスで複数選択します。Shiftクリックすると、前回の選択基準行からクリックした行までの表示中範囲を選択します。\n検査行を複数選択している場合、各操作ボタンは選択行をまとめて処理します。チェック行が無い場合はアクティブ行だけを処理します。",
})

DESCRIPTIONS_EN.update({
    "settings_inspector_scope": "Choose whether the inspector reads all selected objects or only the active object. Use Active when editing one asset precisely, and Selected when auditing multiple selected assets together.",
    "settings_inspector_filter": "Limit the selected-object inspector list to a single data category such as UV maps, material IDs, geometry attributes or vertex groups.",
    "settings_inspector_search": "Search inside the selected-object inspector. It matches object names, material names, channel names, attribute names, collection names, values and notes.",
    "settings_selection_inspector_auto_refresh": "Keeps the selected-object inspector synchronized with selection and dependency-graph events. Disable to remove its handlers and message-bus subscription completely.",
    "settings_auto_color": "Generate a readable color when a new entry is created",
    "inspector_item_type": "Type of data found on the selected object: object pass index, material slot, UV map, color attribute, geometry attribute, vertex group, selection collection, UDIM metadata or Smart ID metadata.",
    "inspector_owner_object": "Object that owns this row. For mesh channels this is the object using the mesh; for material slots this is the object holding the slot.",
    "inspector_owner_data": "Underlying Blender data-block or storage role for this row. It identifies whether the item is stored on the object, mesh, material or collection.",
    "inspector_item_name": "Current data name found in the selected object. This is read from Blender before editing and is used to locate the data when applying changes.",
    "inspector_edit_name": "Editable target name. Apply Item Settings renames channels, materials, vertex groups, collections or the owner object when that operation is supported.",
    "inspector_id_number": "Editable numeric ID. For objects and materials this writes the pass index; for UDIM rows it stores the tile number; for map-channel rows it stores the channel number.",
    "inspector_color": "Editable display color for object IDs and material IDs. Object rows write viewport color; material rows write material diffuse color.",
    "inspector_active": "Make this UV map, color attribute, geometry attribute, vertex group or collection membership active when applying the row settings.",
    "inspector_render": "Set this UV map as the render UV map when applying the row settings. It is ignored by data types that do not support render-active state.",
    "inspector_data_type": "Existing Blender attribute data type. It is shown for inspection; changing the type of an existing attribute is not forced because Blender stores type at creation time.",
    "inspector_domain": "Existing Blender attribute domain. It is shown for inspection; changing the domain of an existing attribute is not forced because Blender stores domain at creation time.",
    "inspector_safe_delete": "Shows whether this row can be removed by the inspector. Required or internal geometry attributes are protected from destructive deletion.",
    "inspector_material_name": "Material datablock name used by this row. For material slots it identifies the assigned material; for metadata rows it identifies the material that stores Smart ID custom properties.",
    "inspector_collection_name": "Collection name used by this row. Selection-set rows can rename the collection or unlink the owner object from it.",
    "inspector_slot_index": "Slot or original index used to locate this data. For materials it is the material slot index; for vertex groups it is the group index; for map-channel metadata it is the original channel number.",
    "inspector_value_text": "Compact read-only summary of the current value, such as the pass index, material slot assignment, attribute type or stored Smart ID metadata.",
    "inspector_details": "Additional read-only details about the selected-object data row, including storage role and protection notes.",
    "inspect_smart_metadata": "Smart ID custom properties found on the object, mesh or material. These keep registry identity, type, ID number and export tags searchable even if Blender pass indices change.",
    "operator_inspector_refresh": "Rebuild the selected-object inspector list from the active selection. This scans object IDs, material slots, UV maps, map-channel metadata, color attributes, geometry attributes, vertex groups, collection membership, UDIM metadata and Smart ID custom properties.",
    "operator_inspector_apply": "Apply the editable settings of the selected inspector row back to the Blender data it represents. This can rename data, set pass indices, activate channels, set render UVs, write colors and update map-channel or UDIM metadata.",
    "operator_inspector_delete": "Remove or clear the selected inspector row from its owner. Object IDs are reset, material slots are cleared, channels and vertex groups are removed, collection membership is unlinked, UDIM metadata is cleared, and protected attributes are left untouched.",
    "operator_inspector_make_entry": "Create or focus a Smart ID library entry from the selected inspector row. Use this to turn existing object data into managed Smart ID Suite registry items.",
    "operator_inspector_select_owner": "Select the object that owns the selected inspector row and make it active. This is useful when auditing multiple selected objects.",
    "operator_inspector_apply_entry": "Apply the active Smart ID library entry directly to the selected inspector row. This lets one existing UV, material, attribute, group or metadata item inherit the currently selected registry definition without touching all selected objects.",
})

DESCRIPTIONS_JA.update({
    "settings_inspector_scope": "検査対象を、選択中の全オブジェクトにするか、アクティブオブジェクトだけにするかを選びます。1つのアセットを正確に編集する場合はアクティブ、複数アセットをまとめて確認する場合は選択中を使います。",
    "settings_inspector_filter": "選択オブジェクト検査リストを、UVマップ、マテリアルID、ジオメトリ属性、頂点グループなど、1つのデータ分類に絞り込みます。",
    "settings_inspector_search": "選択オブジェクト検査内の検索です。オブジェクト名、マテリアル名、チャンネル名、属性名、コレクション名、値、メモを検索します。",
    "settings_selection_inspector_auto_refresh": "選択の変更に合わせて選択オブジェクト検査を更新します。無効にすると、そのための常時処理を止めます。",
    "settings_auto_color": "新しい項目の作成時に識別しやすい色を自動生成します。",
    "inspector_item_type": "選択オブジェクトから見つかったデータ種別です。オブジェクトパス番号、マテリアルスロット、UVマップ、カラー属性、ジオメトリ属性、頂点グループ、選択コレクション、UDIMメタデータ、Smart IDメタデータを表示します。",
    "inspector_owner_object": "この行を所有するオブジェクトです。メッシュチャンネルでは対象メッシュを使うオブジェクト、マテリアルスロットではスロットを持つオブジェクトを示します。",
    "inspector_owner_data": "この行の保存先となるBlenderデータブロックまたは保存役割です。オブジェクト、メッシュ、マテリアル、コレクションのどこに保存されているかを識別します。",
    "inspector_item_name": "選択オブジェクト内から読み取った現在のデータ名です。変更適用時に対象データを探す基準として使われます。",
    "inspector_edit_name": "変更後に使う編集可能な名前です。対応しているデータでは、項目設定を適用するとチャンネル、マテリアル、頂点グループ、コレクション、所有オブジェクト名を変更します。",
    "inspector_id_number": "編集可能な数値IDです。オブジェクトとマテリアルではパス番号へ、UDIM行ではタイル番号へ、マップチャンネル行ではチャンネル番号へ書き込みます。",
    "inspector_color": "オブジェクトIDとマテリアルIDの表示色です。オブジェクト行ではビューポートカラー、マテリアル行ではマテリアルの拡散色へ書き込みます。",
    "inspector_active": "このUVマップ、カラー属性、ジオメトリ属性、頂点グループ、またはコレクション所属を、設定適用時にアクティブにします。",
    "inspector_render": "設定適用時に、このUVマップをレンダー用UVとして設定します。レンダー用状態を持たないデータタイプでは無視されます。",
    "inspector_data_type": "既存Blender属性のデータ型です。確認用に表示します。既存属性の型変更はBlender側で作成時に固定されるため強制変更しません。",
    "inspector_domain": "既存Blender属性のドメインです。確認用に表示します。既存属性のドメイン変更はBlender側で作成時に固定されるため強制変更しません。",
    "inspector_safe_delete": "この行を検査機能から削除できるかを示します。必須または内部ジオメトリ属性は破壊的削除から保護されます。",
    "inspector_material_name": "この行で使うマテリアルデータブロック名です。マテリアルスロットでは割り当て済みマテリアルを、メタデータ行ではSmart IDカスタムプロパティを保存しているマテリアルを識別します。",
    "inspector_collection_name": "この行で使うコレクション名です。選択セット行では、コレクション名の変更や所有オブジェクトの所属解除に使用します。",
    "inspector_slot_index": "このデータを探すためのスロット番号または元インデックスです。マテリアルではマテリアルスロット番号、頂点グループではグループ番号、マップチャンネルメタデータでは元のチャンネル番号を示します。",
    "inspector_value_text": "現在値の短い読み取り専用要約です。パス番号、マテリアルスロット割り当て、属性タイプ、保存済みSmart IDメタデータなどを表示します。",
    "inspector_details": "選択オブジェクト内データ行に関する追加の読み取り専用情報です。保存先の役割や保護状態などを確認できます。",
    "inspect_smart_metadata": "オブジェクト、メッシュ、マテリアル上で見つかったSmart IDカスタムプロパティです。レジストリ識別子、タイプ、ID番号、書き出しタグを保持し、Blenderのパス番号が変わっても検索しやすくします。",
    "operator_inspector_refresh": "アクティブな選択状態から、選択オブジェクト検査リストを再構築します。オブジェクトID、マテリアルスロット、UVマップ、マップチャンネルメタデータ、カラー属性、ジオメトリ属性、頂点グループ、コレクション所属、UDIMメタデータ、Smart IDカスタムプロパティを走査します。",
    "operator_inspector_apply": "選択中の検査行にある編集可能な設定を、対応するBlenderデータへ書き戻します。名前変更、パス番号設定、チャンネル有効化、レンダーUV設定、色設定、マップチャンネルやUDIMメタデータ更新に対応します。",
    "operator_inspector_delete": "選択中の検査行を所有元から削除または解除します。オブジェクトIDはリセット、マテリアルスロットはクリア、チャンネルと頂点グループは削除、コレクション所属は解除、UDIMメタデータは消去し、保護属性は変更しません。",
    "operator_inspector_make_entry": "選択中の検査行からSmart IDライブラリ項目を作成、または既存項目へフォーカスします。既にあるオブジェクト内データをSmart ID Suiteの管理対象に変換するために使います。",
    "operator_inspector_select_owner": "選択中の検査行を所有しているオブジェクトを選択し、アクティブにします。複数選択オブジェクトを確認するときに便利です。",
    "operator_inspector_apply_entry": "アクティブなSmart IDライブラリ項目を、選択中の検査行へ直接適用します。選択中の既存UV、マテリアル、属性、グループ、メタデータだけに現在のレジストリ定義を反映でき、選択オブジェクト全体には影響しません。",
})


# Selection, overlay and collapsible-section localization additions.
UI_EN.update({
    "panel_title": "Smart ID",
    "selection_actions": "Selection / Assignment Actions",
    "visual_overlay": "Visual Overlay",
    "section_library": "ID / Channel Library",
    "section_entry_details": "Selected Entry",
    "section_assignment": "Assignment Settings",
    "section_selection_actions": "Selection / Assignment",
    "section_channel_tools": "Map / Attribute Channels",
    "section_selection_inspector": "Selected Object Inspector",
    "section_visual_overlay": "Visual Overlay",
    "section_validation_io": "Check / Import / Export",
    "select_objects": "Select Objects",
    "select_elements": "Select Elements",
    "deselect_matches": "Deselect Matches",
    "unassign_from_selection": "Unassign from Selection",
    "inspector_select_elements": "Select Item Elements",
    "inspector_assign_selection": "Assign Item to Selection",
    "inspector_unassign_selection": "Unassign Item from Selection",
    "overlay_enabled": "Enable Overlay",
    "overlay_source": "Overlay Source",
    "overlay_source_active": "Active Entry",
    "overlay_source_visible": "Visible Entries",
    "overlay_source_inspector": "Inspector Items",
    "overlay_source_both": "Visible + Inspector",
    "overlay_show_ids": "Show IDs",
    "overlay_show_channels": "Show Channels",
    "overlay_show_groups": "Show Groups",
    "overlay_show_labels": "Show Labels",
    "overlay_alpha": "Opacity",
    "overlay_line_width": "Line Width",
    "overlay_object_boxes": "Object Boxes",
    "overlay_element_marks": "Element Marks",
    "overlay_status_on": "Overlay is on",
    "overlay_status_off": "Overlay is off",
    "help": "Help",
    "global_list_actions": "Library List",
    "inspector_list_actions": "Selected Object List",
})

UI_JA.update({
    "panel_title": "Smart ID",
    "selection_actions": "選択 / 割り当て操作",
    "visual_overlay": "確認オーバーレイ",
    "section_library": "ID / チャンネルライブラリ",
    "section_entry_details": "選択項目",
    "section_assignment": "割り当て設定",
    "section_selection_actions": "選択 / 割り当て操作",
    "section_channel_tools": "マップ / 属性チャンネル",
    "section_selection_inspector": "選択オブジェクト検査",
    "section_visual_overlay": "確認オーバーレイ",
    "section_validation_io": "検証 / 読み込み / 書き出し",
    "select_objects": "オブジェクト選択",
    "select_elements": "エレメント選択",
    "deselect_matches": "一致選択解除",
    "unassign_from_selection": "選択から解除",
    "inspector_select_elements": "項目エレメント選択",
    "inspector_assign_selection": "項目を選択へ割り当て",
    "inspector_unassign_selection": "項目を選択から解除",
    "overlay_enabled": "オーバーレイ有効",
    "overlay_source": "オーバーレイ対象",
    "overlay_source_active": "アクティブ項目",
    "overlay_source_visible": "表示中の全項目",
    "overlay_source_inspector": "検査リスト項目",
    "overlay_source_both": "表示項目 + 検査リスト",
    "overlay_show_ids": "IDを表示",
    "overlay_show_channels": "チャンネルを表示",
    "overlay_show_groups": "グループを表示",
    "overlay_show_labels": "ラベルを表示",
    "overlay_alpha": "不透明度",
    "overlay_line_width": "線の太さ",
    "overlay_object_boxes": "オブジェクト枠",
    "overlay_element_marks": "エレメント印",
    "overlay_status_on": "オーバーレイ表示中",
    "overlay_status_off": "オーバーレイ停止中",
    "help": "ヘルプ",
    "global_list_actions": "全体リスト",
    "inspector_list_actions": "選択中リスト",
})

DESCRIPTIONS_EN.update({
    "info_selection_actions": "Use the active Smart ID entry or the selected inspector row to select matching objects, select matching mesh elements, assign the definition to the current 3D-view selection, or remove that assignment from the selection.",
    "info_overlay": "Draw non-destructive colored guide overlays in the 3D View. Rows are drawn in their display color (rows without one get a color generated from their name) so you can verify assignments without changing the actual materials or mesh data. With Visible Entries, the boxes follow the library list: under a selected or active Library Match Scope only the objects in that scope are boxed, so use Scene Objects to see the whole scene.",
    "settings_overlay_enabled": "Turn the Smart ID overlay drawing on or off. The overlay draws guide boxes, points and labels only in the 3D View and does not modify object materials, mesh channels or saved data.",
    "settings_overlay_source": "Choose which rows are visualized: only the active library entry, all rows currently shown in the library list (following its type filter and search; with a selected or active Library Match Scope, only the objects in that scope are drawn), the selected-object inspector rows, or both shown library rows and inspector rows.",
    "settings_overlay_show_ids": "Display object IDs, material IDs, UDIM metadata, Cryptomatte tags and custom ID rows in the overlay. Disable this when you only want to inspect channels or groups.",
    "settings_overlay_show_channels": "Display map channels, UV maps, color attributes and geometry attributes in the overlay. Matching mesh objects receive colored guide boxes and optional element marks.",
    "settings_overlay_show_groups": "Display selection sets and vertex groups in the overlay. Collection-based sets highlight member objects; vertex groups also show vertex-domain marks when possible.",
    "settings_overlay_show_labels": "Draw compact text labels beside overlay boxes. Labels show the ID, channel or group name so the colored guides remain understandable in dense scenes.",
    "settings_overlay_alpha": "Opacity of overlay guide colors. Lower values keep the 3D View readable; higher values make assignment checks easier in crowded assets.",
    "settings_overlay_line_width": "Line thickness for overlay object boxes. Increase it for high-resolution displays or when many objects overlap.",
    "settings_overlay_object_boxes": "Draw colored bounding boxes around objects that match the selected ID, channel or group rows. This is the safest overview mode because it does not depend on edit selection state.",
    "settings_overlay_element_marks": "Draw small colored points at representative mesh element centers for material faces, UV/channel faces, attribute domains and vertex groups. These marks are visual guides, not actual selections.",
    "operator_select_elements": "Select mesh elements matching the active Smart ID entry. Material IDs select matching faces, vertex groups select member vertices, and channels or attributes activate the channel and select elements on their storage domain.",
    "operator_deselect_matches": "Remove objects and mesh elements matching the active Smart ID entry from the current 3D View selection. This only changes selection state and does not remove any ID or channel data.",
    "operator_unassign_entry": "Remove the active Smart ID assignment from the current target selection. Depending on type, it resets pass indices, clears matching material slots or selected faces, removes channels or attributes, unlinks selection sets, or clears matching metadata.",
    "operator_inspector_select_elements": "Select the owner object or exact mesh elements represented by the selected inspector row. This is useful for jumping from a listed material slot, UV, attribute or vertex group to the actual 3D View data.",
    "operator_inspector_assign_selection": "Apply the selected inspector row's ID, channel, material, collection or group definition to the current 3D View selection without first creating a permanent Smart ID library entry.",
    "operator_inspector_unassign_selection": "Remove the selected inspector row's ID, channel, material, collection or group definition from the current 3D View selection. The inspector row itself remains listed until refreshed.",
    "operator_toggle_section": "Expand or collapse this Smart ID section. The header keeps only the disclosure arrow, feature icon, section name and help button so the top level stays compact.",
    "operator_open_help": "Show a short explanation of this Smart ID section or command. Use it when you need to confirm what a section changes before running operations.",
})

DESCRIPTIONS_JA.update({
    "info_selection_actions": "アクティブなSmart ID項目、または選択中の検査行を基準に、一致オブジェクト選択、メッシュエレメント選択、現在の3Dビュー選択への割り当て、選択からの割り当て解除を行います。",
    "info_overlay": "3Dビュー上に非破壊の確認用カラーオーバーレイを描画します。各行をその表示色で描き（表示色を持たない行は名前から作った色）、実際のマテリアルやメッシュデータを変更せずに割り当て状態を確認できます。「表示中の全項目」の枠は一覧に合わせて描きます。ライブラリ判定範囲が選択かアクティブの時はその範囲の物だけに枠が出るので、シーン全体を見る時は「シーンオブジェクト」にしてください。",
    "settings_overlay_enabled": "Smart IDのオーバーレイ描画をオン/オフします。3Dビューに確認用の枠、点、ラベルだけを描画し、オブジェクトのマテリアル、メッシュチャンネル、保存データは変更しません。",
    "settings_overlay_source": "可視化する行を選びます。アクティブなライブラリ項目のみ、ライブラリの一覧に今出ている行（表示タイプと検索に従います。ライブラリ判定範囲が選択かアクティブの時は、その範囲の物だけを描きます）、選択オブジェクト検査リスト、またはライブラリ表示項目と検査リストの両方を表示できます。",
    "settings_overlay_show_ids": "オブジェクトID、マテリアルID、UDIMメタデータ、Cryptomatteタグ、カスタムIDをオーバーレイ表示します。チャンネルやグループだけを確認したい場合はオフにしてください。",
    "settings_overlay_show_channels": "マップチャンネル、UVマップ、カラー属性、ジオメトリ属性をオーバーレイ表示します。一致するメッシュオブジェクトに色付き枠と、必要に応じたエレメント印を表示します。",
    "settings_overlay_show_groups": "選択セットと頂点グループをオーバーレイ表示します。コレクション型セットは所属オブジェクトを強調し、頂点グループは可能な範囲で頂点ドメインの印も表示します。",
    "settings_overlay_show_labels": "オーバーレイ枠の近くに短い文字ラベルを描画します。ラベルにはID、チャンネル、グループ名が表示されるため、密集したシーンでも色の意味を確認できます。",
    "settings_overlay_alpha": "オーバーレイ確認色の不透明度です。低い値では3Dビューが見やすく、高い値では混雑したアセットでも割り当て確認がしやすくなります。",
    "settings_overlay_line_width": "オーバーレイのオブジェクト枠の線幅です。高解像度モニターや、複数オブジェクトが重なる場面では値を上げると確認しやすくなります。",
    "settings_overlay_object_boxes": "選択中のID、チャンネル、グループ行に一致するオブジェクトへ色付きバウンディングボックスを描画します。編集選択状態に依存しないため、最も安全な全体確認モードです。",
    "settings_overlay_element_marks": "マテリアル面、UV/チャンネル面、属性ドメイン、頂点グループの代表位置へ小さな色付き点を描画します。この印は確認用であり、実際の選択状態ではありません。",
    "operator_select_elements": "アクティブなSmart ID項目に一致するメッシュエレメントを選択します。マテリアルIDでは一致フェイス、頂点グループでは所属頂点、チャンネルや属性では対象チャンネルをアクティブ化して保存ドメイン上の要素を選択します。",
    "operator_deselect_matches": "アクティブなSmart ID項目に一致するオブジェクトとメッシュエレメントを、現在の3Dビュー選択から外します。選択状態だけを変更し、IDやチャンネルのデータは削除しません。",
    "operator_unassign_entry": "アクティブなSmart ID割り当てを、現在の対象選択から解除します。種類に応じてパス番号のリセット、一致マテリアルスロットや選択フェイスのクリア、チャンネルや属性の削除、選択セット解除、メタデータ消去を行います。",
    "operator_inspector_select_elements": "選択中の検査行が表す所有オブジェクト、または実際のメッシュエレメントを選択します。リスト上のマテリアルスロット、UV、属性、頂点グループから3Dビュー上の実データへ移動するために使います。",
    "operator_inspector_assign_selection": "選択中の検査行にあるID、チャンネル、マテリアル、コレクション、グループ定義を、恒久的なSmart IDライブラリ項目を先に作らずに現在の3Dビュー選択へ適用します。",
    "operator_inspector_unassign_selection": "選択中の検査行にあるID、チャンネル、マテリアル、コレクション、グループ定義を、現在の3Dビュー選択から解除します。検査行自体は更新するまでリストに残ります。",
    "operator_toggle_section": "このSmart IDセクションを展開または折りたたみます。最上層のヘッダーは、展開アイコン、機能アイコン、セクション名、ヘルプボタンだけにして、一覧性を保ちます。",
    "operator_open_help": "このSmart IDセクションまたはコマンドの短い説明を表示します。操作前に、そのセクションが何を変更するか確認したい場合に使います。",
})


DESCRIPTIONS_EN.update({
    "settings_library_scope": "Choose what the ID / Channel Library uses when judging row visibility and match counts. Selected Objects shows only entries found on the current multi-object selection; Active Object uses only the active object; Scene Objects shows the full registry. Entries nothing uses yet stay visible in every scope, and so do the active row and checked rows. After the selection changes, all rows stay visible until the counts are refreshed. If the selected scope is empty, the full library remains visible so entries are not hidden accidentally.",
    "operator_sync_selected": "Scan the currently selected objects and add any missing object IDs, material IDs, UV channels, map-channel metadata, color attributes, geometry attributes, vertex groups, selection-set collections and UDIM metadata to the Smart ID library. This is the selection-focused equivalent of scene sync and is useful when the library does not yet contain the IDs found on the selected assets.",
})

DESCRIPTIONS_JA.update({
    "settings_library_scope": "ID / チャンネルライブラリが行の表示と一致件数を判定するときの対象を選びます。選択オブジェクトでは現在のマルチ選択に含まれる項目だけを表示し、アクティブオブジェクトではアクティブだけを使い、シーン内オブジェクトでは登録済み全体を表示します。どこにも使われていない項目と、選んでいる行・チェックした行は常に表示します。選択を変えた後は、件数を更新するまで全部の行を表示します。対象が空の場合は、項目を誤って隠さないように全体表示へ戻します。",
    "operator_sync_selected": "現在選択中のオブジェクトを走査し、未登録のオブジェクトID、マテリアルID、UVチャンネル、マップチャンネルメタデータ、カラー属性、ジオメトリ属性、頂点グループ、選択セット用コレクション、UDIMメタデータをSmart IDライブラリへ追加します。選択中アセットに実在するIDがライブラリに無い場合に使う、選択特化の同期です。",
})


UI_EN.update({
    "report_entries_warnings": "{entries} entries, {warnings} warnings",
    "report_smart_rows_selected": "Smart ID selected rows: {count}",
    "report_selected_visible_rows": "Selected {count} visible Smart ID row(s)",
    "report_cleared_row_selection": "Cleared Smart ID row selection",
    "report_no_rows_selected": "No Smart ID rows are selected",
    "report_deleted_selected_rows": "Deleted {count} selected Smart ID row(s)",
    "report_skipped_locked_rows": "Skipped {count} locked row(s)",
    "report_inspector_rows_selected": "Inspector selected rows: {count}",
    "report_selected_visible_inspector_rows": "Selected {count} visible inspector row(s)",
    "report_cleared_inspector_selection": "Cleared inspector row selection",
    "report_no_inspector_rows_selected": "No inspector rows are selected",
    "report_deleted_selected_inspector_items": "Deleted or cleared {count} selected inspector item(s)",
    "report_skipped_protected_rows": "Skipped {count} protected row(s)",
    "report_added_entry": "Added {name}",
    "report_entry_locked": "Entry is locked",
    "report_entry_removed": "Entry removed",
    "report_duplicated_rows": "Duplicated {count} Smart ID row(s)",
    "report_list_sorted": "List sorted",
    "report_renumbered_entries": "Renumbered {count} entries",
    "report_counts_refreshed": "Counts refreshed",
    "report_counts_refreshed_added": "Counts refreshed; added {count} row(s) found on the targets",
    "report_applied_rows_to_targets": "Applied {rows} Smart ID row(s) to {targets} target(s)",
    "report_no_targets_changed": "No targets were changed",
    "report_selected_objects_from_rows": "Selected {count} object(s) from {rows} Smart ID row(s)",
    "report_selected_matches_from_rows": "Selected {count} element/object match(es) from {rows} Smart ID row(s)",
    "report_no_matching_elements": "No matching elements were found",
    "report_deselected_matches_from_rows": "Deselected {count} match(es) from {rows} Smart ID row(s)",
    "report_no_unlocked_row": "No unlocked Smart ID row is available",
    "report_unassigned_targets_from_rows": "Unassigned {targets} target(s) from {rows} Smart ID row(s)",
    "report_no_matching_assignment_removed": "No matching assignment was removed",
    "report_no_object_to_sync": "No selected or active object to sync",
    "report_synced_selected_entries": "Synced {count} selected-object entrie(s)",
    "report_synced_new_entries": "Synced {count} new entrie(s)",
    "report_validation_warnings": "Validation finished with {count} warning(s)",
    "report_validation_no_warnings": "Validation finished without warnings",
    "report_created_updated_materials": "Created/updated {count} material(s)",
    "report_row_not_mesh_channel": "Selected Smart ID row is not a mesh channel type",
    "report_applied_channel_rows": "Applied {rows} channel row(s) to {objects} mesh object(s)",
    "report_removed_channels_from_rows": "Removed {count} channel(s) from {rows} Smart ID row(s)",
    "report_active_data_read": "Active data read into entry",
    "report_created_aovs_from_rows": "Created {count} AOV(s) from {rows} Smart ID row(s)",
    "report_collection_updated": "Collection updated with {objects} object(s) from {rows} Smart ID row(s)",
    "report_inspector_showing_omitted": "Selection inspector: showing {count} of {total} item(s); {omitted} omitted",
    "report_inspector_items": "Selection inspector: {count} item(s)",
    "report_inspector_applied_changes": "Inspector applied {count} change(s) from {rows} row(s)",
    "report_no_inspector_data_changed": "No selected-object data was changed",
    "report_inspector_removed_items": "Inspector removed {count} item(s) from {rows} row(s)",
    "report_no_inspector_data_removed": "No selected-object data was removed",
    "report_created_focused_rows": "Created {created} / focused {focused} Smart ID row(s) from inspector",
    "report_selected_inspector_owners": "Selected {count} inspector owner object(s)",
    "report_skipped_incompatible_rows": "Skipped {count} incompatible inspector row(s)",
    "report_applied_active_to_inspector": "Applied active Smart ID to {count} inspector item(s)",
    "report_inspector_selected_matches": "Inspector selected {count} element/object match(es) from {rows} row(s)",
    "report_no_matching_inspector_elements": "No matching inspector elements were found",
    "report_inspector_assigned": "Inspector item(s) assigned to {targets} target(s) from {rows} row(s)",
    "report_no_target_received": "No target received the inspector item",
    "report_inspector_unassigned": "Inspector item(s) unassigned from {targets} target(s) from {rows} row(s)",
    "report_no_matching_inspector_assignment": "No matching inspector assignment was removed",
    "report_error_bad_json": "the file is not valid JSON (line {line})",
    "report_error_not_utf8": "the file is not UTF-8 text",
    "report_error_access_denied": "access to the file was denied",
    "report_error_file_not_found": "the file was not found",
    "report_error_file_io": "the file could not be read or written",
    "report_error_unexpected": "an unexpected problem occurred",
    "report_import_stage_failed": "the import data could not be prepared",
    "report_import_commit_failed": "the import could not be committed",
    "report_import_commit_warning": "the import was committed, but a problem was reported afterwards",
    "report_invalid_value": "a value is invalid",
    "report_json_export_failed": "JSON export failed: {error}",
    "report_exported_entries": "Exported {count} entries",
    "report_json_import_failed": "JSON import failed: {error}",
    "report_json_import_cancelled": "JSON import cancelled: {detail}",
    "report_invalid_payload": "the file contents are not valid",
    "report_transaction_failed": "the import could not be completed",
    "report_and_more": "; and {count} more",
    "report_count_refresh_deferred": "; count refresh deferred",
    "report_imported_entries": "Imported {count} entries{extra}",
    "report_csv_export_failed": "CSV export failed: {error}",
    "report_exported_csv_rows": "Exported {count} CSV rows",
    "details_smart_id_custom_props": "{owner} Smart ID custom properties",
    "details_object_type": "Object type: {type}",
    "details_collection_membership": "Object collection membership",
    "details_material_slot_assignment": "Material slot assignment",
    "details_empty_material_slot": "Empty material slot",
    "details_map_channels_prefix": "Map channels: {channels}",
    "details_uv_map": "UV map",
    "details_map_channel_with_uv": "Map-channel metadata with existing UV",
    "details_map_channel_without_uv": "Map-channel metadata without matching UV",
    "details_color_attribute": "Color attribute",
    "details_protected_geometry_attribute": "Protected geometry attribute",
    "details_geometry_attribute": "Geometry attribute",
    "details_udim_metadata": "Smart ID Suite UDIM metadata",
    "details_vertex_group": "Vertex group",
    "msg_json_val_field_boolean": "{name} must be boolean",
    "msg_json_val_field_integer": "{name} must be integer",
    "msg_json_val_field_range": "{name} is outside {minimum}..{maximum}",
    "msg_json_val_field_required": "{name} is required",
    "msg_json_val_field_string": "{name} must be string",
    "msg_json_val_field_too_long": "{name} is too long",
    "msg_json_val_field_unsupported": "{name} has unsupported value {value!r}",
    "msg_json_val_color_shape": "color must be a 3- or 4-number array",
    "msg_json_val_color_number": "color components must be numbers",
    "msg_json_val_color_range": "color components must be finite values in 0..1",
    "msg_json_val_uid_uuid": "uid must be a valid UUID",
    "msg_json_val_uid_nil": "uid must not be the nil UUID",
    "msg_json_val_row_entry_object": "row {row_number}: entry must be an object",
    "msg_json_val_row_unknown_members": "row {row_number}: unknown member(s): {members}",
    "msg_json_val_row_missing_members": "row {row_number}: missing member(s): {members}",
    "msg_json_val_row_detail": "row {row_number}: {detail}",
    "msg_json_val_root_object": "root must be an object",
    "msg_json_val_root_unknown_members": "unknown root member(s): {members}",
    "msg_json_val_root_missing_members": "missing root member(s): {members}",
    "msg_json_val_schema_mismatch": "schema mismatch",
    "msg_json_val_version_mismatch": "version mismatch",
    "msg_json_val_payload_type_mismatch": "this is not a Smart ID file",
    "msg_json_val_root_member_string": "root member {member} must be string",
    "msg_json_val_entries_list": "entries must be a list",
    "msg_json_val_row_duplicate_uid": "row {row_number}: duplicate uid {uid_value}",
    "msg_json_val_no_valid_entries": "no valid entries",
    "msg_json_parse_duplicate_key": "duplicate JSON key: {key}",
    "msg_json_parse_nonfinite_number": "non-finite JSON number is not allowed: {token}",
    "msg_json_parse_input_text": "JSON input must be text",
})

UI_JA.update({
    "report_entries_warnings": "項目 {entries} 件、警告 {warnings} 件",
    "report_smart_rows_selected": "Smart ID選択行数: {count}",
    "report_selected_visible_rows": "表示中のSmart ID行 {count} 件を選択しました",
    "report_cleared_row_selection": "Smart ID行の選択を解除しました",
    "report_no_rows_selected": "Smart ID行が選択されていません",
    "report_deleted_selected_rows": "選択したSmart ID行 {count} 件を削除しました",
    "report_skipped_locked_rows": "ロック中の行 {count} 件をスキップしました",
    "report_inspector_rows_selected": "検査の選択行数: {count}",
    "report_selected_visible_inspector_rows": "表示中の検査の行 {count} 件を選択しました",
    "report_cleared_inspector_selection": "検査の行の選択を解除しました",
    "report_no_inspector_rows_selected": "検査の行が選択されていません",
    "report_deleted_selected_inspector_items": "選択した検査の行 {count} 件を削除または解除しました",
    "report_skipped_protected_rows": "保護された行 {count} 件をスキップしました",
    "report_added_entry": "{name} を追加しました",
    "report_entry_locked": "項目はロックされています",
    "report_entry_removed": "項目を削除しました",
    "report_duplicated_rows": "Smart ID行 {count} 件を複製しました",
    "report_list_sorted": "リストを並べ替えました",
    "report_renumbered_entries": "項目 {count} 件を再採番しました",
    "report_counts_refreshed": "件数を更新しました",
    "report_counts_refreshed_added": "件数を更新し、対象の物にあった {count} 行を追加しました",
    "report_applied_rows_to_targets": "Smart ID行 {rows} 件を対象 {targets} 件へ適用しました",
    "report_no_targets_changed": "変更された対象はありません",
    "report_selected_objects_from_rows": "Smart ID行 {rows} 件からオブジェクト {count} 件を選択しました",
    "report_selected_matches_from_rows": "Smart ID行 {rows} 件から要素／オブジェクトの一致 {count} 件を選択しました",
    "report_no_matching_elements": "一致する要素が見つかりませんでした",
    "report_deselected_matches_from_rows": "Smart ID行 {rows} 件から一致 {count} 件を選択解除しました",
    "report_no_unlocked_row": "ロックされていないSmart ID行がありません",
    "report_unassigned_targets_from_rows": "Smart ID行 {rows} 件の割り当てを対象 {targets} 件から解除しました",
    "report_no_matching_assignment_removed": "解除された一致する割り当てはありません",
    "report_no_object_to_sync": "同期する選択中またはアクティブなオブジェクトがありません",
    "report_synced_selected_entries": "選択オブジェクトの項目 {count} 件を同期しました",
    "report_synced_new_entries": "新規項目 {count} 件を同期しました",
    "report_validation_warnings": "検証が警告 {count} 件で完了しました",
    "report_validation_no_warnings": "検証が警告なしで完了しました",
    "report_created_updated_materials": "マテリアル {count} 件を作成または更新しました",
    "report_row_not_mesh_channel": "選択したSmart ID行はメッシュチャンネル系のタイプではありません",
    "report_applied_channel_rows": "チャンネル行 {rows} 件をメッシュオブジェクト {objects} 件へ適用しました",
    "report_removed_channels_from_rows": "Smart ID行 {rows} 件からチャンネル {count} 件を削除しました",
    "report_active_data_read": "アクティブデータを項目へ読み込みました",
    "report_created_aovs_from_rows": "Smart ID行 {rows} 件からAOV {count} 件を作成しました",
    "report_collection_updated": "Smart ID行 {rows} 件のオブジェクト {objects} 件でコレクションを更新しました",
    "report_inspector_showing_omitted": "検査: {total} 件中 {count} 件を表示、{omitted} 件は省略しました",
    "report_inspector_items": "検査: {count} 件",
    "report_inspector_applied_changes": "検査の行 {rows} 件から変更 {count} 件を適用しました",
    "report_no_inspector_data_changed": "変更された選択オブジェクトデータはありません",
    "report_inspector_removed_items": "検査の行 {rows} 件から項目 {count} 件を削除しました",
    "report_no_inspector_data_removed": "削除された選択オブジェクトデータはありません",
    "report_created_focused_rows": "検査からSmart ID行を作成 {created} 件／フォーカス {focused} 件",
    "report_selected_inspector_owners": "検査の所有オブジェクト {count} 件を選択しました",
    "report_skipped_incompatible_rows": "互換性のない検査の行 {count} 件をスキップしました",
    "report_applied_active_to_inspector": "アクティブなSmart IDを検査の行 {count} 件へ適用しました",
    "report_inspector_selected_matches": "検査の行 {rows} 件から要素／オブジェクトの一致 {count} 件を選択しました",
    "report_no_matching_inspector_elements": "一致する検査の要素が見つかりませんでした",
    "report_inspector_assigned": "検査の行 {rows} 件を対象 {targets} 件へ割り当てました",
    "report_no_target_received": "検査の行を受け取った対象はありません",
    "report_inspector_unassigned": "検査の行 {rows} 件の割り当てを対象 {targets} 件から解除しました",
    "report_no_matching_inspector_assignment": "解除された検査の割り当てはありません",
    "report_error_bad_json": "ファイルがJSONとして正しくありません（{line} 行目）",
    "report_error_not_utf8": "ファイルがUTF-8のテキストではありません",
    "report_error_access_denied": "ファイルへのアクセスが拒否されました",
    "report_error_file_not_found": "ファイルが見つかりません",
    "report_error_file_io": "ファイルを読み書きできませんでした",
    "report_error_unexpected": "予期しない問題が起きました",
    "report_import_stage_failed": "読み込むデータを準備できませんでした",
    "report_import_commit_failed": "読み込みを確定できませんでした",
    "report_import_commit_warning": "読み込みは確定しましたが、その後に問題が報告されました",
    "report_invalid_value": "値が正しくありません",
    "report_json_export_failed": "JSON書き出しに失敗しました: {error}",
    "report_exported_entries": "項目 {count} 件を書き出しました",
    "report_json_import_failed": "JSON読み込みに失敗しました: {error}",
    "report_json_import_cancelled": "JSON読み込みを中止しました: {detail}",
    "report_invalid_payload": "ファイルの中身が正しくありません",
    "report_transaction_failed": "読み込みを確定できませんでした",
    "report_and_more": "、他 {count} 件",
    "report_count_refresh_deferred": "、件数更新を延期しました",
    "report_imported_entries": "項目 {count} 件を読み込みました{extra}",
    "report_csv_export_failed": "CSV書き出しに失敗しました: {error}",
    "report_exported_csv_rows": "CSV行 {count} 件を書き出しました",
    "details_smart_id_custom_props": "{owner}のSmart IDカスタムプロパティ",
    "details_object_type": "オブジェクトタイプ: {type}",
    "details_collection_membership": "オブジェクトのコレクション所属",
    "details_material_slot_assignment": "マテリアルスロット割り当て",
    "details_empty_material_slot": "空のマテリアルスロット",
    "details_map_channels_prefix": "マップチャンネル: {channels}",
    "details_uv_map": "UVマップ",
    "details_map_channel_with_uv": "既存UVと対応するマップチャンネルメタデータ",
    "details_map_channel_without_uv": "対応するUVが無いマップチャンネルメタデータ",
    "details_color_attribute": "カラー属性",
    "details_protected_geometry_attribute": "保護されたジオメトリ属性",
    "details_geometry_attribute": "ジオメトリ属性",
    "details_udim_metadata": "Smart ID SuiteのUDIMメタデータ",
    "details_vertex_group": "頂点グループ",
    "msg_json_val_field_boolean": "{name}は真偽値である必要があります",
    "msg_json_val_field_integer": "{name}は整数である必要があります",
    "msg_json_val_field_range": "{name}は{minimum}～{maximum}の範囲内である必要があります",
    "msg_json_val_field_required": "{name}は必須です",
    "msg_json_val_field_string": "{name}は文字列である必要があります",
    "msg_json_val_field_too_long": "{name}が長すぎます",
    "msg_json_val_field_unsupported": "{name}に未対応の値{value!r}が指定されています",
    "msg_json_val_color_shape": "colorは3個または4個の数値からなる配列である必要があります",
    "msg_json_val_color_number": "colorの各要素は数値である必要があります",
    "msg_json_val_color_range": "colorの各要素は0～1の有限値である必要があります",
    "msg_json_val_uid_uuid": "uidは有効なUUIDである必要があります",
    "msg_json_val_uid_nil": "uidに空のUUIDは使用できません",
    "msg_json_val_row_entry_object": "行{row_number}: 項目の形が正しくありません",
    "msg_json_val_row_unknown_members": "行{row_number}: 知らない項目があります: {members}",
    "msg_json_val_row_missing_members": "行{row_number}: 必要な項目がありません: {members}",
    "msg_json_val_row_detail": "行{row_number}: {detail}",
    "msg_json_val_root_object": "ファイルの形がSmart IDの書き出しと違います",
    "msg_json_val_root_unknown_members": "知らない項目があります: {members}",
    "msg_json_val_root_missing_members": "必要な項目がありません: {members}",
    "msg_json_val_schema_mismatch": "ファイルの形式が違います",
    "msg_json_val_version_mismatch": "バージョンが一致しません",
    "msg_json_val_payload_type_mismatch": "Smart ID のファイルではありません",
    "msg_json_val_root_member_string": "{member}は文字列である必要があります",
    "msg_json_val_entries_list": "entriesはリストである必要があります",
    "msg_json_val_row_duplicate_uid": "行{row_number}: uid {uid_value}が重複しています",
    "msg_json_val_no_valid_entries": "有効な項目がありません",
    "msg_json_parse_duplicate_key": "JSONキーが重複しています: {key}",
    "msg_json_parse_nonfinite_number": "有限でないJSON数値は使用できません: {token}",
    "msg_json_parse_input_text": "JSON入力は文字列である必要があります",
})

def is_japanese(context=None):
    try:
        prefs = (context or bpy.context).preferences
        lang = prefs.view.language
        if lang == "DEFAULT":
            lang = bpy.app.translations.locale
        return str(lang).lower().startswith("ja")
    except Exception:
        return False


def t(key, context=None):
    return (UI_JA if is_japanese(context) else UI_EN).get(key, key)


def _report_language(context=None):
    return "ja" if is_japanese(context) else "en"


def _on_last_report_changed(self, context):
    # A report keeps the language it was written in, so it is shown only in that language.
    self.last_report_language = _report_language(context)


def desc(key, context=None):
    return (DESCRIPTIONS_JA if is_japanese(context) else DESCRIPTIONS_EN).get(key, key)


EXTRA_TRANSLATIONS_JA = {
    "Supported Editors > Sidebar > Smart ID": "対応エディター > サイドバー > Smart ID",
    "List-manage material IDs, object IDs, map channels, attributes, UDIM metadata, selection sets and render channel tags.": "マテリアルID、オブジェクトID、マップチャンネル、属性、UDIMメタデータ、選択セット、レンダーチャンネルタグをリストで管理します。",
    "Object": "オブジェクト",
    "Always-On Features": "常時機能切り替え",
    "N-panel State Save": "Nパネル状態保存",
    "Selection Inspector Auto Refresh": "検査の自動更新",
    "Last Report Language": "前回レポートの言語",
    "Automatic Metadata Cleanup": "メタデータ自動整理",
    "Up": "上",
    "Move up": "上へ移動",
    "Down": "下",
    "Move down": "下へ移動",
    "Stable internal unique identifier for this Smart ID entry": "このSmart ID項目を内部で一意に識別する固定IDです。",
    "Number of objects currently matching this entry": "現在この項目に一致しているオブジェクト数です。",
    "Number of materials currently matching this entry": "現在この項目に一致しているマテリアル数です。",
    "Number of mesh channels currently matching this entry": "現在この項目に一致しているメッシュチャンネル数です。",
    "Number of selected or active objects matching this entry under the current library match scope": "現在のライブラリ照合範囲で、この項目に一致する選択中またはアクティブなオブジェクト数です。",
    "Number of material slots or materials on the selected or active objects matching this entry under the current library match scope": "現在のライブラリ照合範囲で、この項目に一致する選択中またはアクティブなオブジェクト上のマテリアル／スロット数です。",
    "Number of mesh channels on the selected or active objects matching this entry under the current library match scope": "現在のライブラリ照合範囲で、この項目に一致する選択中またはアクティブなオブジェクト上のメッシュチャンネル数です。",
    "Stable internal identifier for this selected-object inspector row": "選択オブジェクト検査のこの行を内部で一意に識別する固定IDです。",
    "Expand or collapse the unified Smart ID runtime controls.": "Smart IDの常時動作設定をまとめたセクションを開閉します。",
    "Persist every portable Smart ID N-panel option to Smart_ID_Suite/Smart_ID_Suite.json on change. Turning this off records OFF once; while off, ordinary, direct, forced and shutdown paths do not write. Turning it on immediately snapshots current values.": "Smart IDの移植可能なNパネル設定を変更時にSmart_ID_Suite/Smart_ID_Suite.jsonへ保存します。無効化時はオフを最後に1回だけ記録し、無効中は通常・直接・強制・終了処理のどの経路からも書き込みません。再び有効にすると現在値を直ちに保存します。",
    "Controls when every portable Smart ID N-panel option is written to Smart_ID_Suite/Smart_ID_Suite.json. Enable for immediate saving; disable to defer writes until the scene/file is switched or closed, the .blend is saved, or this option is enabled again.": "Smart IDの移植可能なNパネル設定をSmart_ID_Suite/Smart_ID_Suite.jsonへ保存するタイミングを指定します。有効時は変更直後に保存し、無効時はシーン／ファイル切替・終了、.blend保存、またはこの項目の再有効化まで書き込みを延期します。",
    "Keeps the selected-object inspector synchronized with selection and dependency-graph events. Disable to remove its handlers and message-bus subscription completely.": "選択の変更に合わせて選択オブジェクト検査を更新します。無効にすると、そのための常時処理を止めます。",
    "Automatically clears transient inspector rows and orphan Smart ID metadata on file load/save. Disable to remove both lifecycle handlers.": "ファイルの読み込み／保存時に、一時的な検査の行と、持ち主のなくなった Smart ID のメタデータを片付けます。無効にすると、そのための処理を止めます。",
    "Generate a readable color when a new entry is created": "新しい項目の作成時に識別しやすい色を自動生成します。",
    "Internal non-saved signature used to refresh selected-object library rows only when the active selection or its ID/channel data changes.": "アクティブな選択またはID／チャンネルデータが変化した場合だけ選択オブジェクトのライブラリ行を更新するための、保存されない内部署名です。",
    "Short status text from the last Smart ID operation": "直前に実行したSmart ID操作の簡潔な状態表示です。",
    "Toggle Smart ID Row Selection": "Smart ID行の選択を切り替え",
    "Select Visible Smart ID Rows": "表示中のSmart ID行を選択",
    "Clear Smart ID Row Selection": "Smart ID行の選択を解除",
    "Delete Selected Smart ID Rows": "選択したSmart ID行を削除",
    "Toggle Inspector Row Selection": "検査の行の選択を切り替え",
    "Select Visible Inspector Rows": "表示中の検査の行を選択",
    "Clear Inspector Row Selection": "検査の行の選択を解除",
    "Delete Selected Inspector Rows": "選択した検査の行を削除",
    "Add Smart ID Entry": "Smart ID項目を追加",
    "Remove Smart ID Entry": "Smart ID項目を削除",
    "Duplicate Smart ID Entry": "Smart ID項目を複製",
    "Move Smart ID Entry": "Smart ID項目を移動",
    "Sort Smart ID Entries": "Smart ID項目を並べ替え",
    "Renumber Smart ID Entries": "Smart ID項目を再採番",
    "Refresh Smart ID Counts": "Smart ID件数を更新",
    "Apply Smart ID Entry": "Smart ID項目を適用",
    "Select by Smart ID Entry": "Smart ID項目で選択",
    "Select Smart ID Elements": "Smart ID要素を選択",
    "Deselect Smart ID Matches": "Smart ID一致対象を選択解除",
    "Unassign Smart ID from Selection": "選択対象からSmart IDを解除",
    "Sync Smart IDs from Selection": "選択対象からSmart IDを同期",
    "Sync Smart IDs from Scene": "シーンからSmart IDを同期",
    "Validate Smart ID Registry": "Smart IDレジストリを検証",
    "Create Smart ID Materials": "Smart IDマテリアルを作成",
    "Create or Activate Smart ID Channel": "Smart IDチャンネルを作成または有効化",
    "Delete Smart ID Channel": "Smart IDチャンネルを削除",
    "Read Active Selection into Smart ID Entry": "アクティブ選択をSmart ID項目へ読み込み",
    "Create Smart ID View Layer AOV": "Smart IDビューレイヤーAOVを作成",
    "Create Smart ID Selection Collection": "Smart ID選択コレクションを作成",
    "Refresh Selected Object Data": "選択オブジェクトデータを更新",
    "Apply Selected Object Data Settings": "選択オブジェクトデータ設定を適用",
    "Delete or Clear Selected Object Data": "選択オブジェクトデータを削除または解除",
    "Create Smart ID Entry from Selected Object Data": "選択オブジェクトデータからSmart ID項目を作成",
    "Select Selected Object Data Owner": "選択オブジェクトデータの所有元を選択",
    "Apply Active Smart ID Entry to Selected Object Data": "アクティブなSmart ID項目を選択オブジェクトデータへ適用",
    "Select Selected Inspector Row Elements": "選択した検査の行の要素を選択",
    "Assign Selected Inspector Row to Selection": "選択した検査の行を選択対象へ割り当て",
    "Unassign Selected Inspector Row from Selection": "選択した検査の行を選択対象から解除",
    "Toggle Smart ID Section": "Smart IDセクションを開閉",
    "Smart ID Help": "Smart IDヘルプ",
    "Export Smart ID JSON": "Smart ID JSONを書き出し",
    "Import Smart ID JSON": "Smart ID JSONを読み込み",
    "Export Smart ID CSV": "Smart ID CSVを書き出し",
    "Index": "インデックス",
    "Range Select": "範囲選択",
    "Section Key": "セクションキー",
    "Label": "ラベル",
    "Help Key": "ヘルプキー",
    "Title Key": "タイトルキー",
    "Show all Smart ID entries": "すべてのSmart ID項目を表示します。",
    "Floating Point": "浮動小数点",
    "Integer": "整数",
    "Boolean": "ブール",
    "Vector": "ベクトル",
    "Floating Point Color": "浮動小数点カラー",
    "Single floating-point channel for masks, weights or scalar IDs": "マスク、ウェイト、スカラーID用の単一浮動小数点チャンネルです。",
    "Integer channel for exact IDs and index data": "正確なIDやインデックスデータ用の整数チャンネルです。",
    "True/false channel for binary masks": "二値マスク用の真／偽チャンネルです。",
    "Three-component vector channel": "3成分のベクトルチャンネルです。",
    "Floating-point color channel": "浮動小数点カラーのチャンネルです。",
    "Point": "ポイント",
    "Edge": "辺",
    "Face": "面",
    "Corner": "コーナー",
    "Store one value per mesh vertex": "メッシュ頂点ごとに1つの値を保存します。",
    "Store one value per edge": "辺ごとに1つの値を保存します。",
    "Store one value per polygon face": "ポリゴン面ごとに1つの値を保存します。",
    "Store one value per face corner, similar to UV data": "UVデータと同様に面コーナーごとに1つの値を保存します。",
}


def _register_translations():
    """Register this transaction's translation dictionary and report ownership."""
    translations = {"ja_JP": {}}
    for dictionary in (UI_EN, DESCRIPTIONS_EN):
        for key, english in dictionary.items():
            japanese = UI_JA.get(key) or DESCRIPTIONS_JA.get(key)
            if japanese and english != japanese:
                for ctxt in ("*", "Operator", "Property", "UI"):
                    translations["ja_JP"][(ctxt, english)] = japanese
    for english, japanese in EXTRA_TRANSLATIONS_JA.items():
        if not english or not japanese or english == japanese:
            continue
        for ctxt in ("*", "Operator", "Property", "UI"):
            translations["ja_JP"][(ctxt, english)] = japanese
    try:
        bpy.app.translations.register(ADDON_ID, translations)
    except ValueError:
        # A pre-existing dictionary is not owned by this registration
        # transaction and must never be removed by its rollback.
        return False
    return True


def _unregister_translations():
    try:
        bpy.app.translations.unregister(ADDON_ID)
        return True
    except Exception:
        return False

# -----------------------------------------------------------------------------
# Data definitions
# -----------------------------------------------------------------------------

ID_TYPE_ITEMS = (
    ("OBJECT_ID", UI_EN["object_id"], DESCRIPTIONS_EN["entry_type"], "OBJECT_DATA", 10),
    ("MATERIAL_ID", UI_EN["material_id"], DESCRIPTIONS_EN["entry_type"], "MATERIAL", 20),
    ("MAP_CHANNEL", UI_EN["map_channel_id"], DESCRIPTIONS_EN["entry_map_channel"], "UV", 30),
    ("UV_CHANNEL", UI_EN["uv_channel"], DESCRIPTIONS_EN["entry_uv_map"], "GROUP_UVS", 40),
    ("COLOR_ATTRIBUTE", UI_EN["color_attribute_id"], DESCRIPTIONS_EN["entry_color_attribute"], "COLOR", 50),
    ("GEOMETRY_ATTRIBUTE", UI_EN["geometry_attribute"], DESCRIPTIONS_EN["entry_attribute_name"], "GEOMETRY_NODES", 60),
    ("UDIM_TILE", UI_EN["udim_tile_id"], DESCRIPTIONS_EN["entry_udim_tile"], "IMAGE_DATA", 70),
    ("SELECTION_SET", UI_EN["selection_set"], DESCRIPTIONS_EN["entry_group_name"], "OUTLINER_COLLECTION", 80),
    ("RENDER_AOV", UI_EN["render_aov"], DESCRIPTIONS_EN["operator_create_aov"], "RENDERLAYERS", 90),
    ("CRYPTOMATTE_ID", UI_EN["cryptomatte_id"], DESCRIPTIONS_EN["entry_export_tag"], "SHADING_TEXTURE", 100),
    ("WEIGHT_GROUP", UI_EN["weight_group"], DESCRIPTIONS_EN["entry_group_name"], "GROUP_VERTEX", 110),
    ("CUSTOM_ID", UI_EN["custom_id"], DESCRIPTIONS_EN["entry_export_tag"], "PROPERTIES", 120),
)

FILTER_TYPE_ITEMS = (("ALL", UI_EN["all"], "Show all Smart ID entries", "FILTER", 0),) + ID_TYPE_ITEMS

LIBRARY_SCOPE_ITEMS = (
    ("SELECTED", UI_EN["library_scope_selected"], DESCRIPTIONS_EN["settings_library_scope"], "RESTRICT_SELECT_OFF", 0),
    ("ACTIVE", UI_EN["library_scope_active"], DESCRIPTIONS_EN["settings_library_scope"], "OBJECT_DATA", 1),
    ("SCENE", UI_EN["library_scope_scene"], DESCRIPTIONS_EN["settings_library_scope"], "SCENE_DATA", 2),
)

SCOPE_ITEMS = (
    ("SELECTED", UI_EN["selected"], DESCRIPTIONS_EN["settings_scope"], "RESTRICT_SELECT_OFF", 0),
    ("ACTIVE", UI_EN["active"], DESCRIPTIONS_EN["settings_scope"], "OBJECT_DATA", 1),
    ("SCENE", UI_EN["scene"], DESCRIPTIONS_EN["settings_scope"], "SCENE_DATA", 2),
    ("ALL_MESHES", UI_EN["all_meshes"], DESCRIPTIONS_EN["settings_scope"], "MESH_DATA", 3),
)

MATERIAL_MODE_ITEMS = (
    ("ACTIVE_SLOT", UI_EN["active_slot"], DESCRIPTIONS_EN["settings_material_mode"], "MATERIAL", 0),
    ("ALL_SLOTS", UI_EN["all_slots"], DESCRIPTIONS_EN["settings_material_mode"], "MATERIAL_DATA", 1),
    ("SELECTED_FACES", UI_EN["selected_faces"], DESCRIPTIONS_EN["settings_material_mode"], "FACESEL", 2),
    ("CREATE_ASSIGN", UI_EN["create_assign"], DESCRIPTIONS_EN["settings_material_mode"], "ADD", 3),
)

SORT_MODE_ITEMS = (
    ("MANUAL", UI_EN["sort_manual"], DESCRIPTIONS_EN["settings_sort_mode"], "SORT_ASC", 0),
    ("TYPE_ID", UI_EN["sort_type"], DESCRIPTIONS_EN["settings_sort_mode"], "SORTBYEXT", 1),
    ("ID", UI_EN["sort_id"], DESCRIPTIONS_EN["settings_sort_mode"], "LINENUMBERS_ON", 2),
    ("NAME", UI_EN["sort_name"], DESCRIPTIONS_EN["settings_sort_mode"], "SORTALPHA", 3),
)

NAMING_PROFILE_ITEMS = (
    ("BLENDER", UI_EN["profile_blender"], DESCRIPTIONS_EN["settings_naming_profile"], 0),
    ("3DSMAX", UI_EN["profile_3dsmax"], DESCRIPTIONS_EN["settings_naming_profile"], 1),
    ("MAYA", UI_EN["profile_maya"], DESCRIPTIONS_EN["settings_naming_profile"], 2),
    ("MARI", UI_EN["profile_mari"], DESCRIPTIONS_EN["settings_naming_profile"], 3),
    ("ZBRUSH", UI_EN["profile_zbrush"], DESCRIPTIONS_EN["settings_naming_profile"], 4),
    ("C4D", UI_EN["profile_c4d"], DESCRIPTIONS_EN["settings_naming_profile"], 5),
    ("LIGHTWAVE", UI_EN["profile_lightwave"], DESCRIPTIONS_EN["settings_naming_profile"], 6),
    ("CUSTOM", UI_EN["profile_custom"], DESCRIPTIONS_EN["settings_naming_profile"], 7),
)

ATTRIBUTE_TYPE_ITEMS = (
    ("FLOAT", "Floating Point", "Single floating-point channel for masks, weights or scalar IDs", 0),
    ("INT", "Integer", "Integer channel for exact IDs and index data", 1),
    ("BOOLEAN", "Boolean", "True/false channel for binary masks", 2),
    ("FLOAT_VECTOR", "Vector", "Three-component vector channel", 3),
    ("FLOAT_COLOR", "Floating Point Color", "Floating-point color channel", 4),
)

ATTRIBUTE_DOMAIN_ITEMS = (
    ("POINT", "Point", "Store one value per mesh vertex", 0),
    ("EDGE", "Edge", "Store one value per edge", 1),
    ("FACE", "Face", "Store one value per polygon face", 2),
    ("CORNER", "Corner", "Store one value per face corner, similar to UV data", 3),
)


INSPECTOR_TYPE_ITEMS = (
    ("OBJECT_ID", UI_EN["object_id"], DESCRIPTIONS_EN["inspector_item_type"], "OBJECT_DATA", 10),
    ("MATERIAL_ID", UI_EN["material_id"], DESCRIPTIONS_EN["inspector_item_type"], "MATERIAL", 20),
    ("MAP_CHANNEL", UI_EN["map_channel_id"], DESCRIPTIONS_EN["entry_map_channel"], "UV", 30),
    ("UV_CHANNEL", UI_EN["uv_channel"], DESCRIPTIONS_EN["entry_uv_map"], "GROUP_UVS", 40),
    ("COLOR_ATTRIBUTE", UI_EN["color_attribute_id"], DESCRIPTIONS_EN["entry_color_attribute"], "COLOR", 50),
    ("GEOMETRY_ATTRIBUTE", UI_EN["geometry_attribute"], DESCRIPTIONS_EN["entry_attribute_name"], "GEOMETRY_NODES", 60),
    ("WEIGHT_GROUP", UI_EN["weight_group"], DESCRIPTIONS_EN["entry_group_name"], "GROUP_VERTEX", 70),
    ("SELECTION_SET", UI_EN["selection_set"], DESCRIPTIONS_EN["entry_group_name"], "OUTLINER_COLLECTION", 80),
    ("UDIM_TILE", UI_EN["udim_tile_id"], DESCRIPTIONS_EN["entry_udim_tile"], "IMAGE_DATA", 90),
    ("SMART_METADATA", UI_EN["inspect_smart_metadata"], DESCRIPTIONS_EN["inspect_smart_metadata"], "PROPERTIES", 100),
)

INSPECTOR_FILTER_ITEMS = (("ALL", UI_EN["all"], DESCRIPTIONS_EN["settings_inspector_filter"], "FILTER", 0),) + INSPECTOR_TYPE_ITEMS

INSPECTOR_SCOPE_ITEMS = (
    ("SELECTED", UI_EN["selected"], DESCRIPTIONS_EN["settings_inspector_scope"], "RESTRICT_SELECT_OFF", 0),
    ("ACTIVE", UI_EN["active"], DESCRIPTIONS_EN["settings_inspector_scope"], "OBJECT_DATA", 1),
)

OVERLAY_SOURCE_ITEMS = (
    ("ACTIVE_ENTRY", UI_EN["overlay_source_active"], DESCRIPTIONS_EN["settings_overlay_source"], "RADIOBUT_ON", 0),
    ("VISIBLE_ENTRIES", UI_EN["overlay_source_visible"], DESCRIPTIONS_EN["settings_overlay_source"], "FILTER", 1),
    ("INSPECTOR_ITEMS", UI_EN["overlay_source_inspector"], DESCRIPTIONS_EN["settings_overlay_source"], "VIEWZOOM", 2),
    ("BOTH", UI_EN["overlay_source_both"], DESCRIPTIONS_EN["settings_overlay_source"], "OVERLAY", 3),
)


def tag_redraw_view3d():
    try:
        wm = bpy.context.window_manager
        for window in wm.windows:
            screen = window.screen
            if not screen:
                continue
            for area in screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()
    except Exception:
        pass


def sync_overlay_handlers(context=None):
    if not _runtime_generation_is_current():
        remove_overlay_handlers()
        return False
    try:
        ctx = context or bpy.context
        scene = getattr(ctx, "scene", None)
        settings = get_settings(scene) if scene is not None and hasattr(scene, "smart_id_settings") else None
        requested = bool(settings is not None and getattr(settings, "overlay_enabled", False))
        if requested:
            active = bool(add_overlay_handlers())
            if active:
                schedule_overlay_snapshot_rebuild(scene)
            return active
        remove_overlay_handlers()
        return False
    except Exception:
        remove_overlay_handlers()
        return False


def overlay_setting_update(self, context):
    del self
    sync_overlay_handlers(context)


def _on_entry_overlay_changed(self, context):
    del self
    try:
        scene = getattr(context or bpy.context, "scene", None)
        settings = get_settings(scene) if scene is not None and hasattr(scene, "smart_id_settings") else None
        # Direct RNA edits to Smart ID entry metadata do not necessarily emit a
        # useful depsgraph ID update.  Bump the Inspector data revision here so
        # an unchanged selection still rebuilds through the coalesced one-shot.
        _mark_inspector_data_dirty(scene, reason="entry_metadata", bump_revision=True)
        if settings is not None and bool(getattr(settings, "overlay_enabled", False)):
            schedule_overlay_snapshot_rebuild(scene)
    except Exception:
        pass


def _on_active_entry_index_changed(scene, context):
    try:
        settings = get_settings(scene) if scene is not None and hasattr(scene, "smart_id_settings") else None
        if settings is not None and bool(getattr(settings, "overlay_enabled", False)):
            schedule_overlay_snapshot_rebuild(scene)
    except Exception:
        pass


def _on_entry_checked_changed(self, context):
    _on_active_entry_index_changed(self.id_data, context)

TYPE_LABEL_KEY = {
    "OBJECT_ID": "object_id",
    "MATERIAL_ID": "material_id",
    "MAP_CHANNEL": "map_channel_id",
    "UV_CHANNEL": "uv_channel",
    "COLOR_ATTRIBUTE": "color_attribute_id",
    "GEOMETRY_ATTRIBUTE": "geometry_attribute",
    "UDIM_TILE": "udim_tile_id",
    "SELECTION_SET": "selection_set",
    "RENDER_AOV": "render_aov",
    "CRYPTOMATTE_ID": "cryptomatte_id",
    "WEIGHT_GROUP": "weight_group",
    "CUSTOM_ID": "custom_id",
}

TYPE_ICON = {item[0]: item[3] for item in ID_TYPE_ITEMS}
TYPE_ORDER = {item[0]: index for index, item in enumerate(ID_TYPE_ITEMS)}

INSPECTOR_TYPE_ICON = {item[0]: item[3] for item in INSPECTOR_TYPE_ITEMS}
INSPECTOR_TYPE_LABEL_KEY = {
    "OBJECT_ID": "object_id",
    "MATERIAL_ID": "material_id",
    "MAP_CHANNEL": "map_channel_id",
    "UV_CHANNEL": "uv_channel",
    "COLOR_ATTRIBUTE": "color_attribute_id",
    "GEOMETRY_ATTRIBUTE": "geometry_attribute",
    "WEIGHT_GROUP": "weight_group",
    "SELECTION_SET": "selection_set",
    "UDIM_TILE": "udim_tile_id",
    "SMART_METADATA": "inspect_smart_metadata",
}


def _prop_key(name):
    return f"{CUSTOM_PREFIX}_{name}"


SMART_IDENTITY_PROP_NAMES = (
    "uid",
    "type",
    "name",
    "id_number",
    "role",
    "export_tag",
    "channel_name",
    "owner_uuid",
    "suite_id",
    "generation",
    "operation_uuid",
)


def smart_identity_prop_keys(id_data):
    if id_data is None:
        return []
    keys = []
    try:
        for name in SMART_IDENTITY_PROP_NAMES:
            key = _prop_key(name)
            if id_data.get(key) is not None:
                keys.append(key)
    except Exception:
        return []
    return keys


def clear_smart_identity_props(id_data):
    removed = 0
    for key in smart_identity_prop_keys(id_data):
        try:
            del id_data[key]
            removed += 1
        except Exception:
            pass
    return removed


_SMART_ID_METADATA_ASSIGNMENT_MANIFEST = {}
_SMART_ID_METADATA_MANIFEST_LIMIT = 4096
_SMART_ID_METADATA_SCAN_LIMIT = 100000


def _smart_id_data_pointer(id_data):
    if id_data is None:
        return 0
    try:
        return int(id_data.as_pointer())
    except Exception:
        return 0


def _record_smart_identity_assignment(id_data, operation_uuid):
    """Record only primitive exact ownership for metadata written this session.

    The manifest never stores Blender RNA and is bounded.  Cleanup can therefore
    touch only identities written by this Suite generation, never data selected by
    a name, prefix, module, or database-wide search.
    """
    if not _automatic_cleanup_requested():
        return False
    pointer = _smart_id_data_pointer(id_data)
    scene = getattr(getattr(bpy, "context", None), "scene", None)
    scene_key = _selection_scene_key(scene) if scene is not None else ""
    if not pointer or not scene_key:
        return False
    key = (scene_key, pointer)
    record = {
        "scene_key": scene_key,
        "pointer": int(pointer),
        "name": str(getattr(id_data, "name", ""))[:256],
        "operation_uuid": str(operation_uuid),
        "generation": int(_SMART_ID_MODULE_GENERATION),
        "owner_token": str(_SMART_ID_RUNTIME_OWNER_TOKEN),
    }
    return _bounded_cache_put(
        _SMART_ID_METADATA_ASSIGNMENT_MANIFEST,
        key,
        record,
        _SMART_ID_METADATA_MANIFEST_LIMIT,
        account_name="metadata_assignment_manifest",
    )


def _current_scene_reachable_id_map(scene, *, hard_limit=_SMART_ID_METADATA_SCAN_LIMIT):
    """Return a bounded pointer map for IDs reachable from the current Scene only.

    This is invoked only by an explicit/save event while automatic cleanup is ON.
    It never walks global ``bpy.data`` and returns ``None`` instead of performing
    destructive cleanup if the safety limit is reached.
    """
    if scene is None:
        return {}
    result = {}
    count = 0

    def add(id_data):
        nonlocal count
        if id_data is None:
            return True
        pointer = _smart_id_data_pointer(id_data)
        if pointer and pointer not in result:
            count += 1
            if count > int(hard_limit):
                return False
            result[pointer] = id_data
        return True

    try:
        if not add(scene):
            return None
        for obj in tuple(getattr(scene, "objects", ()) or ()):
            if not add(obj) or not add(getattr(obj, "data", None)):
                return None
            for slot in tuple(getattr(obj, "material_slots", ()) or ()):
                if not add(getattr(slot, "material", None)):
                    return None
        root_collection = getattr(scene, "collection", None)
        stack = [root_collection] if root_collection is not None else []
        seen_collections = set()
        while stack:
            collection = stack.pop()
            pointer = _smart_id_data_pointer(collection)
            if pointer in seen_collections:
                continue
            seen_collections.add(pointer)
            if not add(collection):
                return None
            stack.extend(tuple(getattr(collection, "children", ()) or ()))
    except Exception:
        return None
    return result


def cleanup_orphan_smart_identity_metadata(scene):
    """Remove only exact metadata written by this Suite generation.

    Legacy/unowned metadata is deliberately preserved.  A missing or truncated
    reachability map aborts cleanup without touching any datablock.
    """
    scene_key = _selection_scene_key(scene)
    candidates = tuple(
        (key, record)
        for key, record in _SMART_ID_METADATA_ASSIGNMENT_MANIFEST.items()
        if isinstance(record, dict) and str(record.get("scene_key", "")) == scene_key
    )
    if not candidates:
        return 0, 0
    reachable = _current_scene_reachable_id_map(scene)
    if reachable is None:
        return 0, 0
    try:
        valid_uids = {str(entry.uid) for entry in get_entries(scene) if str(getattr(entry, "uid", ""))}
    except Exception:
        return 0, 0
    removed_blocks = 0
    removed_props = 0
    drop_keys = []
    for key, record in candidates:
        id_data = reachable.get(int(record.get("pointer", 0)))
        if id_data is None:
            drop_keys.append(key)
            continue
        try:
            exact_owner = (
                str(id_data.get(_prop_key("owner_uuid"), "")) == _SMART_ID_SUITE_OWNER_UUID
                and str(id_data.get(_prop_key("suite_id"), "")) == ADDON_ID
                and str(id_data.get(_prop_key("operation_uuid"), "")) == str(record.get("operation_uuid", ""))
                and int(id_data.get(_prop_key("generation"), -1)) == int(record.get("generation", -2))
            )
            uid = str(id_data.get(_prop_key("uid"), "") or "")
        except Exception:
            continue
        if not exact_owner:
            # Identity changed or metadata was replaced; retain foreign/current data.
            drop_keys.append(key)
            continue
        if uid and uid in valid_uids:
            continue
        count = clear_smart_identity_props(id_data)
        if count:
            removed_blocks += 1
            removed_props += count
        drop_keys.append(key)
    for key in drop_keys:
        _SMART_ID_METADATA_ASSIGNMENT_MANIFEST.pop(key, None)
        _cache_forget_timestamp(_SMART_ID_METADATA_ASSIGNMENT_MANIFEST, key)
    _cache_account_container("metadata_assignment_manifest", _SMART_ID_METADATA_ASSIGNMENT_MANIFEST)
    return removed_blocks, removed_props


def cleanup_transient_inspector_proxy_data(scene):
    removed_items = 0
    try:
        items = getattr(scene, "smart_id_inspector_items", None)
        if items is not None:
            removed_items = len(items)
            if removed_items:
                items.clear()
    except Exception:
        removed_items = 0
    for attr in ("smart_id_inspector_active_index", "smart_id_inspector_selection_anchor_index"):
        try:
            if hasattr(scene, attr):
                setattr(scene, attr, -1)
        except Exception:
            pass
    for attr, value in (
        ("smart_id_inspector_total_count", 0),
        ("smart_id_inspector_omitted_count", 0),
        ("smart_id_inspector_truncated", False),
    ):
        try:
            if hasattr(scene, attr):
                setattr(scene, attr, value)
        except Exception:
            pass
    return removed_items


def cleanup_smart_id_proxy_data(scene, *, clear_inspector=True, remove_orphan_metadata=True):
    result = {"inspector_items": 0, "metadata_blocks": 0, "metadata_props": 0}
    if scene is None:
        return result
    if clear_inspector:
        result["inspector_items"] = cleanup_transient_inspector_proxy_data(scene)
    if remove_orphan_metadata:
        blocks, props = cleanup_orphan_smart_identity_metadata(scene)
        result["metadata_blocks"] = int(blocks or 0)
        result["metadata_props"] = int(props or 0)
    return result


def cleanup_smart_id_proxy_data_all(*, clear_inspector=True, remove_orphan_metadata=True):
    """Compatibility entry point restricted to the current Scene.

    The previous database-wide sweep is intentionally removed.
    """
    scene = getattr(getattr(bpy, "context", None), "scene", None)
    return cleanup_smart_id_proxy_data(
        scene,
        clear_inspector=clear_inspector,
        remove_orphan_metadata=remove_orphan_metadata,
    )


@persistent
def smart_id_cleanup_load_post(_dummy):
    if not _runtime_generation_guard_fast(_SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN):
        return
    if not _SMART_ID_CLEANUP_RUNTIME_ACTIVE:
        return
    _clear_inspector_runtime_caches(clear_metadata_manifest=True)
    scene = getattr(getattr(bpy, "context", None), "scene", None)
    try:
        if scene is not None and hasattr(scene, "smart_id_settings"):
            scene.smart_id_settings.last_library_autosync_signature = ""
    except Exception:
        pass
    # The operation manifest is session-local and is cleared above.  Load never
    # scans or removes saved metadata from foreign/legacy datablocks.
    cleanup_smart_id_proxy_data(scene, clear_inspector=True, remove_orphan_metadata=False)


@persistent
def smart_id_cleanup_save_pre(_dummy):
    if not _runtime_generation_guard_fast(_SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN):
        return
    if not _SMART_ID_CLEANUP_RUNTIME_ACTIVE:
        return
    scene = getattr(getattr(bpy, "context", None), "scene", None)
    # Inspector rows are SKIP_SAVE runtime proxies.  Exact-owned metadata cleanup
    # is limited to this session's bounded operation manifest.
    cleanup_smart_id_proxy_data(scene, clear_inspector=False, remove_orphan_metadata=True)


_SMART_ID_AUTO_REFRESH_RUNNING = False
_SMART_ID_LIBRARY_AUTOSYNC_RUNNING = False
_SMART_ID_LAST_SELECTION_SIGNATURES = {}
_SMART_ID_LAST_DRAW_SELECTION_SIGNATURES = {}
_SMART_ID_SCENE_DATA_REVISIONS = {}
_SMART_ID_PENDING_INSPECTOR_REFRESHES = {}
_SMART_ID_COUNTED_LIBRARY_SELECTIONS = {}
_SMART_ID_SELECTION_SIGNATURE_CACHE_LIMIT = 64
_SMART_ID_DRAW_SIGNATURE_CACHE_LIMIT = 64
_SMART_ID_SCENE_REVISION_CACHE_LIMIT = 64
_SMART_ID_PENDING_REFRESH_LIMIT = 64
_SMART_ID_SELECTION_MSGBUS_OWNER = object()
_SMART_ID_SELECTION_RUNTIME_ACTIVE = False
_SMART_ID_CLEANUP_RUNTIME_ACTIVE = False
_SMART_ID_SELECTION_REFRESH_TIMER_ACTIVE = False
_SMART_ID_DATA_REVISION_COUNTER = 0
_SMART_ID_LOAD_IN_PROGRESS = False

# Every transient CPU/GPU cache in this Suite shares one explicit byte budget.
# Accounting uses Python object sizes for primitive caches and conservative
# uploaded-vertex byte estimates for GPU batches.  No RNA is retained by these
# caches, and eviction/expiry occurs only on real events (never by a watchdog).
_SMART_ID_CACHE_HARD_BUDGET_BYTES = 256 * 1024 * 1024
_SMART_ID_CACHE_DEFAULT_TTL_SECONDS = 600.0
_SMART_ID_CACHE_CURRENT_BYTES = 0
_SMART_ID_CACHE_PEAK_BYTES = 0
_SMART_ID_CACHE_ACCOUNTING = {}
_SMART_ID_CACHE_ENTRY_TIMESTAMPS = {}
_SMART_ID_CACHE_REJECTED_WRITES = 0
_INSPECTOR_RELEVANT_ID_TYPES = frozenset({"Object", "Mesh", "Material", "Collection"})
_INSPECTOR_MSGBUS_KEYS = (
    ("WindowManager", "operators"),
    ("LayerObjects", "active"),
    ("Object", "name"),
    ("Object", "pass_index"),
    ("Object", "active_material_index"),
    ("Object", "active_material"),
    ("Object", "material_slots"),
    ("Object", "vertex_groups"),
    ("Object", "color"),
    ("Object", "data"),
    ("Material", "name"),
    ("Material", "pass_index"),
    ("Material", "diffuse_color"),
    ("Mesh", "name"),
    ("Mesh", "uv_layers"),
    ("Mesh", "attributes"),
    ("Mesh", "color_attributes"),
    ("MaterialSlot", "material"),
    ("VertexGroup", "name"),
    ("MeshUVLoopLayer", "name"),
    ("MeshUVLoopLayer", "active_render"),
    ("Attribute", "name"),
    ("Attribute", "data_type"),
    ("Attribute", "domain"),
    ("Collection", "name"),
)


def maybe_cleanup_smart_id_proxy_data(
    scene,
    *,
    clear_inspector=False,
    remove_orphan_metadata=True,
    min_interval=None,
    force=False,
):
    """Compatibility wrapper; cleanup is already event-only and bounded."""
    del min_interval, force
    return cleanup_smart_id_proxy_data(
        scene,
        clear_inspector=clear_inspector,
        remove_orphan_metadata=remove_orphan_metadata,
    )


def _smart_id_selection_runtime_requested(context=None, scene=None):
    try:
        ctx = context or bpy.context
        scene = scene or getattr(ctx, "scene", None)
        if scene is None or not hasattr(scene, "smart_id_settings"):
            return False
        settings = get_settings(scene)
        return bool(getattr(settings, "always_on_selection_inspector", False))
    except Exception:
        return False


def _selection_scene_key(scene):
    if scene is None:
        return ""
    try:
        return f"{int(scene.as_pointer())}:{scene.name}"
    except Exception:
        return str(getattr(scene, "name", ""))


def _cache_estimate_bytes(value, *, _seen=None, _depth=0):
    """Measure a bounded primitive container without traversing Blender RNA."""
    if _depth > 12:
        return 0
    if _seen is None:
        _seen = set()
    identity = id(value)
    if identity in _seen:
        return 0
    _seen.add(identity)
    try:
        own_size = int(value.__sizeof__())
    except Exception:
        own_size = 64
    if value is None or isinstance(value, (bool, int, float, str, bytes)):
        return max(0, own_size)
    if isinstance(value, dict):
        total = max(0, own_size)
        for key, item in tuple(value.items()):
            total += _cache_estimate_bytes(key, _seen=_seen, _depth=_depth + 1)
            total += _cache_estimate_bytes(item, _seen=_seen, _depth=_depth + 1)
        return total
    if isinstance(value, (tuple, list, set, frozenset)):
        total = max(0, own_size)
        for item in tuple(value):
            total += _cache_estimate_bytes(item, _seen=_seen, _depth=_depth + 1)
        return total
    # Unknown objects (including GPU wrappers) are never recursively inspected.
    return max(0, own_size)


def _cache_account_replace(name, byte_count):
    global _SMART_ID_CACHE_CURRENT_BYTES, _SMART_ID_CACHE_PEAK_BYTES
    global _SMART_ID_CACHE_REJECTED_WRITES
    name = str(name or "")
    if not name:
        return True
    byte_count = max(0, int(byte_count))
    old = int(_SMART_ID_CACHE_ACCOUNTING.get(name, 0))
    proposed = int(_SMART_ID_CACHE_CURRENT_BYTES) - old + byte_count
    if proposed > _SMART_ID_CACHE_HARD_BUDGET_BYTES:
        _SMART_ID_CACHE_REJECTED_WRITES += 1
        return False
    _SMART_ID_CACHE_ACCOUNTING[name] = byte_count
    _SMART_ID_CACHE_CURRENT_BYTES = proposed
    _SMART_ID_CACHE_PEAK_BYTES = max(int(_SMART_ID_CACHE_PEAK_BYTES), proposed)
    return True


def _cache_account_drop(name):
    global _SMART_ID_CACHE_CURRENT_BYTES
    name = str(name or "")
    old = int(_SMART_ID_CACHE_ACCOUNTING.pop(name, 0))
    _SMART_ID_CACHE_CURRENT_BYTES = max(0, int(_SMART_ID_CACHE_CURRENT_BYTES) - old)


def _cache_timestamp_key(cache, key):
    return (id(cache), key)


def _cache_forget_timestamp(cache, key):
    _SMART_ID_CACHE_ENTRY_TIMESTAMPS.pop(_cache_timestamp_key(cache, key), None)


def _cache_prune_expired(cache, ttl_seconds):
    ttl = max(0.0, float(ttl_seconds or 0.0))
    if ttl <= 0.0 or not cache:
        return 0
    now = time.monotonic()
    expired = []
    for key in tuple(cache):
        touched = float(_SMART_ID_CACHE_ENTRY_TIMESTAMPS.get(_cache_timestamp_key(cache, key), now))
        if now - touched > ttl:
            expired.append(key)
    for key in expired:
        cache.pop(key, None)
        _cache_forget_timestamp(cache, key)
    return len(expired)


def _cache_account_container(account_name, cache):
    if not account_name:
        return True
    return _cache_account_replace(account_name, _cache_estimate_bytes(cache))


def _bounded_cache_put(
    cache,
    key,
    value,
    limit,
    *,
    ttl_seconds=_SMART_ID_CACHE_DEFAULT_TTL_SECONDS,
    account_name=None,
):
    """Event-time TTL/LRU insertion with atomic shared-byte-budget admission."""
    if not key:
        return False
    _cache_prune_expired(cache, ttl_seconds)
    missing = object()
    old_value = cache.get(key, missing)
    old_timestamp = _SMART_ID_CACHE_ENTRY_TIMESTAMPS.get(_cache_timestamp_key(cache, key), missing)
    cache.pop(key, None)
    cache[key] = value
    _SMART_ID_CACHE_ENTRY_TIMESTAMPS[_cache_timestamp_key(cache, key)] = time.monotonic()
    evicted = []
    while len(cache) > int(limit):
        try:
            oldest = next(iter(cache))
        except StopIteration:
            break
        evicted.append((oldest, cache.pop(oldest)))
        _cache_forget_timestamp(cache, oldest)
    if not _cache_account_container(account_name, cache):
        cache.pop(key, None)
        _cache_forget_timestamp(cache, key)
        for evicted_key, evicted_value in reversed(evicted):
            cache[evicted_key] = evicted_value
            _SMART_ID_CACHE_ENTRY_TIMESTAMPS[_cache_timestamp_key(cache, evicted_key)] = time.monotonic()
        if old_value is not missing:
            cache.pop(key, None)
            cache[key] = old_value
            if old_timestamp is not missing:
                _SMART_ID_CACHE_ENTRY_TIMESTAMPS[_cache_timestamp_key(cache, key)] = old_timestamp
        _cache_account_container(account_name, cache)
        return False
    return True


def _bounded_cache_get(
    cache,
    key,
    default=None,
    *,
    ttl_seconds=_SMART_ID_CACHE_DEFAULT_TTL_SECONDS,
    account_name=None,
):
    _cache_prune_expired(cache, ttl_seconds)
    if key not in cache:
        _cache_account_container(account_name, cache)
        return default
    value = cache.pop(key)
    cache[key] = value
    _SMART_ID_CACHE_ENTRY_TIMESTAMPS[_cache_timestamp_key(cache, key)] = time.monotonic()
    _cache_account_container(account_name, cache)
    return value


def _bounded_cache_clear(cache, account_name=None):
    for key in tuple(cache):
        _cache_forget_timestamp(cache, key)
    cache.clear()
    if account_name:
        _cache_account_drop(account_name)


def _bounded_cache_pop(cache, key, default=None, *, account_name=None):
    if key not in cache:
        return default
    value = cache.pop(key)
    _cache_forget_timestamp(cache, key)
    _cache_account_container(account_name, cache)
    return value


def _clear_inspector_runtime_caches(*, clear_metadata_manifest=False):
    _bounded_cache_clear(_SMART_ID_PENDING_INSPECTOR_REFRESHES, "pending_inspector")
    _bounded_cache_clear(_SMART_ID_LAST_SELECTION_SIGNATURES, "selection_signatures")
    _bounded_cache_clear(_SMART_ID_LAST_DRAW_SELECTION_SIGNATURES, "draw_selection_signatures")
    _bounded_cache_clear(_SMART_ID_SCENE_DATA_REVISIONS, "scene_revisions")
    if clear_metadata_manifest:
        _bounded_cache_clear(_SMART_ID_METADATA_ASSIGNMENT_MANIFEST, "metadata_assignment_manifest")
        _SMART_ID_COUNTED_LIBRARY_SELECTIONS.clear()


def _reset_transient_cache_accounting_if_empty():
    """Drop bounded-cache bookkeeping after every owned cache is empty."""
    global _SMART_ID_CACHE_CURRENT_BYTES
    caches = (
        _SMART_ID_METADATA_ASSIGNMENT_MANIFEST,
        _SMART_ID_PENDING_INSPECTOR_REFRESHES,
        _SMART_ID_LAST_SELECTION_SIGNATURES,
        _SMART_ID_LAST_DRAW_SELECTION_SIGNATURES,
        _SMART_ID_SCENE_DATA_REVISIONS,
        _OVERLAY_SNAPSHOTS,
        _OVERLAY_PENDING_SCENE_NAMES,
    )
    if any(cache for cache in caches) or _OVERLAY_ACTIVE_RENDER_SNAPSHOT is not None:
        return False
    _SMART_ID_CACHE_ENTRY_TIMESTAMPS.clear()
    _SMART_ID_CACHE_ACCOUNTING.clear()
    _SMART_ID_CACHE_CURRENT_BYTES = 0
    return True


def _smart_id_cache_metrics():
    return {
        "hard_budget_bytes": int(_SMART_ID_CACHE_HARD_BUDGET_BYTES),
        "current_bytes": int(_SMART_ID_CACHE_CURRENT_BYTES),
        "peak_bytes": int(_SMART_ID_CACHE_PEAK_BYTES),
        "rejected_writes": int(_SMART_ID_CACHE_REJECTED_WRITES),
        "slots": {str(key): int(value) for key, value in _SMART_ID_CACHE_ACCOUNTING.items()},
    }


def _remember_selection_signature(scene, signature):
    _bounded_cache_put(
        _SMART_ID_LAST_SELECTION_SIGNATURES,
        _selection_scene_key(scene),
        signature,
        _SMART_ID_SELECTION_SIGNATURE_CACHE_LIMIT,
        account_name="selection_signatures",
    )


def _remember_draw_selection_signature(scene, signature):
    _bounded_cache_put(
        _SMART_ID_LAST_DRAW_SELECTION_SIGNATURES,
        _selection_scene_key(scene),
        signature,
        _SMART_ID_DRAW_SIGNATURE_CACHE_LIMIT,
        account_name="draw_selection_signatures",
    )


def _scene_data_revision(scene):
    return int(
        _bounded_cache_get(
            _SMART_ID_SCENE_DATA_REVISIONS,
            _selection_scene_key(scene),
            0,
            account_name="scene_revisions",
        )
    )


def _bump_scene_data_revision(scene):
    global _SMART_ID_DATA_REVISION_COUNTER
    key = _selection_scene_key(scene)
    if not key:
        return 0
    _SMART_ID_DATA_REVISION_COUNTER += 1
    revision = int(_SMART_ID_DATA_REVISION_COUNTER)
    _bounded_cache_put(
        _SMART_ID_SCENE_DATA_REVISIONS,
        key,
        revision,
        _SMART_ID_SCENE_REVISION_CACHE_LIMIT,
        account_name="scene_revisions",
    )
    return revision


def _primitive_object_token(obj):
    if obj is None:
        return 0, ""
    try:
        pointer = int(obj.as_pointer())
    except Exception:
        pointer = id(obj)
    try:
        name = str(obj.name)
    except Exception:
        name = ""
    return pointer, name


def _primitive_selection_digest(objects):
    """Fixed-size, order-independent signature from pointer/name primitives only."""
    count = 0
    xor_value = 0
    sum_value = 0
    square_sum = 0
    mask = (1 << 64) - 1
    for obj in (objects or ()):
        if obj is None:
            continue
        pointer, name = _primitive_object_token(obj)
        # SplitMix64-style integer avalanche.  This avoids cryptographic hashing
        # and temporary byte strings in event-driven signature capture while retaining three
        # independent order-insensitive accumulators for collision resistance.
        value = ((int(pointer) & mask) ^ (hash(name) & mask)) & mask
        value = (value + 0x9E3779B97F4A7C15) & mask
        value = ((value ^ (value >> 30)) * 0xBF58476D1CE4E5B9) & mask
        value = ((value ^ (value >> 27)) * 0x94D049BB133111EB) & mask
        value ^= value >> 31
        xor_value ^= value
        sum_value = (sum_value + value) & mask
        square_sum = (square_sum + ((value * value) & mask)) & mask
        count += 1
    return count, f"{xor_value:016x}", f"{sum_value:016x}", f"{square_sum:016x}"


def _primitive_selection_signature(context):
    """Draw-safe signature: no object-data traversal and no inspector rebuild."""
    scene = getattr(context, "scene", None)
    if scene is None:
        return None
    try:
        settings = get_settings(scene)
        scope = str(getattr(settings, "inspector_scope", "SELECTED"))
    except Exception:
        scope = "SELECTED"
    active = context_active_object(context)
    active_pointer, active_name = _primitive_object_token(active)
    try:
        active_mode = str(getattr(active, "mode", "")) if active is not None else ""
    except Exception:
        active_mode = ""
    if scope == "ACTIVE":
        targets = (active,) if active is not None else ()
    else:
        try:
            targets = getattr(context, "selected_objects", ()) or ()
        except Exception:
            targets = ()
    count, xor_digest, sum_digest, square_digest = _primitive_selection_digest(targets)
    return (
        _selection_scene_key(scene),
        scope,
        active_pointer,
        active_name,
        active_mode,
        count,
        xor_digest,
        sum_digest,
        square_digest,
        _scene_data_revision(scene),
    )


def _selection_signature(context):
    """Backwards-compatible alias for the fixed-size primitive signature."""
    return _primitive_selection_signature(context)


def _enqueue_inspector_refresh_request(scene=None, *, reason="event", bump_revision=False):
    """Record one bounded primitive refresh request without starting work.

    This function is the only Inspector invalidation function reachable from a
    Panel/UIList draw path.  It performs no RNA traversal, rebuild, timer API
    call, file I/O, dependency-graph access, or registration mutation.
    """
    current_scene = getattr(getattr(bpy, "context", None), "scene", None)
    scene = scene or current_scene
    if scene is None or current_scene is None or not _runtime_generation_guard_fast(
        _SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN
    ):
        return False
    if _selection_scene_key(scene) != _selection_scene_key(current_scene):
        return False
    if not _smart_id_selection_runtime_requested(scene=scene):
        return False
    revision = _bump_scene_data_revision(scene) if bump_revision else _scene_data_revision(scene)
    key = _selection_scene_key(scene)
    if not key:
        return False
    pending = {
        "scene_name": str(getattr(scene, "name", ""))[:256],
        "revision": int(revision),
        "reason": str(reason or "event")[:64],
        "generation": int(_SMART_ID_MODULE_GENERATION),
    }
    return _bounded_cache_put(
        _SMART_ID_PENDING_INSPECTOR_REFRESHES,
        key,
        pending,
        _SMART_ID_PENDING_REFRESH_LIMIT,
        account_name="pending_inspector",
    )


def _mark_inspector_data_dirty(scene=None, *, reason="event", bump_revision=False):
    if not _enqueue_inspector_refresh_request(
        scene, reason=reason, bump_revision=bump_revision
    ):
        return False
    return _schedule_selection_auto_refresh()


def _draw_maybe_enqueue_inspector_refresh(_context):
    """Compatibility no-op: Panel/UIList draw paths never mutate runtime state."""
    return None


def _perform_selection_auto_refresh():
    global _SMART_ID_AUTO_REFRESH_RUNNING
    if _SMART_ID_AUTO_REFRESH_RUNNING or not _runtime_generation_is_current():
        return
    try:
        context = bpy.context
        scene = context.scene
        if scene is None or not hasattr(scene, "smart_id_settings") or not hasattr(scene, "smart_id_inspector_items"):
            return
        if not _smart_id_selection_runtime_requested(context, scene):
            return
        scene_key = _selection_scene_key(scene)
        pending = _bounded_cache_pop(
            _SMART_ID_PENDING_INSPECTOR_REFRESHES,
            scene_key,
            None,
            account_name="pending_inspector",
        )
        signature = _primitive_selection_signature(context)
        if signature is None:
            return
        previous = _bounded_cache_get(
            _SMART_ID_LAST_SELECTION_SIGNATURES,
            scene_key,
            None,
            account_name="selection_signatures",
        )
        if pending is None and previous == signature:
            return
        _SMART_ID_AUTO_REFRESH_RUNNING = True
        try:
            refresh_selection_inspector(context)
            refresh_counts(scene, context)
            final_signature = _primitive_selection_signature(context)
            if final_signature is not None:
                _remember_selection_signature(scene, final_signature)
                _remember_draw_selection_signature(scene, final_signature)
            tag_redraw_view3d()
        finally:
            _SMART_ID_AUTO_REFRESH_RUNNING = False
    except Exception:
        _SMART_ID_AUTO_REFRESH_RUNNING = False
    finally:
        try:
            scene = getattr(bpy.context, "scene", None)
            if scene is not None and _selection_scene_key(scene) in _SMART_ID_PENDING_INSPECTOR_REFRESHES:
                _schedule_selection_auto_refresh()
        except Exception:
            pass


def _smart_id_selection_refresh_timer():
    global _SMART_ID_SELECTION_REFRESH_TIMER_ACTIVE
    _untrack_runtime_timer(_smart_id_selection_refresh_timer)
    _SMART_ID_SELECTION_REFRESH_TIMER_ACTIVE = False
    if not _runtime_generation_is_current(_SMART_ID_MODULE_GENERATION):
        return None
    _perform_selection_auto_refresh()
    return None


def _cancel_selection_refresh_timer():
    global _SMART_ID_SELECTION_REFRESH_TIMER_ACTIVE
    _remove_runtime_timer_exact(_smart_id_selection_refresh_timer)
    _SMART_ID_SELECTION_REFRESH_TIMER_ACTIVE = False


def _schedule_selection_auto_refresh():
    global _SMART_ID_SELECTION_REFRESH_TIMER_ACTIVE
    if not _runtime_generation_is_current() or not _smart_id_selection_runtime_requested():
        return False
    if _SMART_ID_SELECTION_REFRESH_TIMER_ACTIVE:
        return True
    try:
        _register_runtime_timer_exact(_smart_id_selection_refresh_timer, first_interval=0.0)
        _SMART_ID_SELECTION_REFRESH_TIMER_ACTIVE = True
        return True
    except Exception:
        # Never rebuild synchronously from a Panel/UIList draw path.
        _SMART_ID_SELECTION_REFRESH_TIMER_ACTIVE = False
        _untrack_runtime_timer(_smart_id_selection_refresh_timer)
        return False


def _depsgraph_update_is_inspector_relevant(update):
    try:
        id_data = update.id
    except Exception:
        return False
    try:
        identifier = str(getattr(getattr(id_data, "bl_rna", None), "identifier", ""))
    except Exception:
        identifier = ""
    if not identifier:
        identifier = type(id_data).__name__
    if identifier not in _INSPECTOR_RELEVANT_ID_TYPES:
        return False
    if identifier == "Object":
        try:
            transform_only = bool(getattr(update, "is_updated_transform", False)) and not bool(
                getattr(update, "is_updated_geometry", False)
            ) and not bool(getattr(update, "is_updated_shading", False))
            if transform_only:
                return False
        except Exception:
            pass
    return True


@persistent
def smart_id_selection_auto_refresh(scene=None, depsgraph=None):
    if not _runtime_generation_guard_fast(_SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN):
        return
    if not _SMART_ID_SELECTION_RUNTIME_ACTIVE or not _runtime_generation_is_current():
        return
    if depsgraph is None:
        return
    relevant = False
    try:
        for update in depsgraph.updates:
            if _depsgraph_update_is_inspector_relevant(update):
                relevant = True
                break
    except Exception:
        return
    if not relevant:
        return
    _mark_inspector_data_dirty(scene, reason="depsgraph", bump_revision=True)


def _smart_id_inspector_msgbus_changed(*_args):
    if not _runtime_generation_guard_fast(_SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN):
        return
    if not _SMART_ID_SELECTION_RUNTIME_ACTIVE:
        return
    scene = getattr(getattr(bpy, "context", None), "scene", None)
    _mark_inspector_data_dirty(scene, reason="msgbus", bump_revision=True)


def _smart_id_operator_finished(context=None, operator_id=""):
    if not _runtime_generation_guard_fast(_SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN):
        return
    scene = getattr(context or getattr(bpy, "context", None), "scene", None)
    _mark_inspector_data_dirty(scene, reason=f"operator:{operator_id}", bump_revision=True)


def smart_id_selection_poll_timer():
    """Legacy compatibility callback; it is never registered."""
    return None


def _clear_selection_runtime_msgbus():
    record = _resource_ledger_find("msgbus", _SMART_ID_SELECTION_MSGBUS_OWNER)
    if record is None:
        return True
    remover = record.get("native_remover")
    if not callable(remover):
        return False
    for _attempt in range(max(1, int(_SMART_ID_RESOURCE_RELEASE_RETRY_LIMIT))):
        try:
            remover(_SMART_ID_SELECTION_MSGBUS_OWNER)
            _untrack_runtime_msgbus_owner(_SMART_ID_SELECTION_MSGBUS_OWNER)
            return True
        except Exception:
            continue
    return False


def _subscribe_selection_runtime_msgbus():
    existing = _resource_ledger_find(
        "msgbus", _SMART_ID_SELECTION_MSGBUS_OWNER,
        owner_token=_SMART_ID_RUNTIME_OWNER_TOKEN,
    )
    if existing is not None:
        return len(_INSPECTOR_MSGBUS_KEYS)
    subscribed = 0
    for type_name, property_name in _INSPECTOR_MSGBUS_KEYS:
        try:
            rna_type = getattr(bpy.types, type_name)
            bpy.msgbus.subscribe_rna(
                key=(rna_type, property_name),
                owner=_SMART_ID_SELECTION_MSGBUS_OWNER,
                args=(),
                notify=_smart_id_inspector_msgbus_changed,
                options={"PERSISTENT"},
            )
            subscribed += 1
        except Exception:
            continue
    if subscribed:
        _track_runtime_msgbus_owner(_SMART_ID_SELECTION_MSGBUS_OWNER)
    return subscribed


def sync_selection_runtime_handlers(context=None):
    global _SMART_ID_SELECTION_RUNTIME_ACTIVE
    requested = _runtime_generation_is_current() and _smart_id_selection_runtime_requested(context)
    if requested:
        was_active = bool(_SMART_ID_SELECTION_RUNTIME_ACTIVE)
        _register_runtime_handler_exact("depsgraph_update_post", smart_id_selection_auto_refresh)
        _subscribe_selection_runtime_msgbus()
        _SMART_ID_SELECTION_RUNTIME_ACTIVE = True
        if not was_active:
            scene = getattr(context or bpy.context, "scene", None)
            _mark_inspector_data_dirty(scene, reason="runtime_enabled", bump_revision=True)
        return True
    _remove_runtime_handler_exact("depsgraph_update_post", smart_id_selection_auto_refresh)
    _clear_selection_runtime_msgbus()
    _cancel_selection_refresh_timer()
    _clear_inspector_runtime_caches()
    _SMART_ID_SELECTION_RUNTIME_ACTIVE = False
    return False


def _automatic_cleanup_requested(context=None):
    try:
        scene = getattr(context or bpy.context, "scene", None)
        settings = get_settings(scene) if scene is not None and hasattr(scene, "smart_id_settings") else None
        return bool(settings and getattr(settings, "always_on_automatic_metadata_cleanup", False))
    except Exception:
        return False


def sync_proxy_cleanup_handlers(context=None):
    global _SMART_ID_CLEANUP_RUNTIME_ACTIVE
    resources = (
        ("load_post", smart_id_cleanup_load_post),
        ("save_pre", smart_id_cleanup_save_pre),
    )
    requested = _runtime_generation_is_current() and _automatic_cleanup_requested(context)
    if not requested:
        # Guard callbacks first.  A transient native removal failure therefore
        # leaves only an exact-ledger no-op until the next lifecycle retry.
        _SMART_ID_CLEANUP_RUNTIME_ACTIVE = False
        _bounded_cache_clear(_SMART_ID_METADATA_ASSIGNMENT_MANIFEST, "metadata_assignment_manifest")
        for list_name, handler in resources:
            _remove_runtime_handler_exact(list_name, handler)
        return False

    state = _runtime_registry_state()
    acquired = []
    try:
        for list_name, handler in resources:
            existed = _resource_ledger_find(
                "handler", handler,
                owner_token=_SMART_ID_RUNTIME_OWNER_TOKEN,
                state=state,
            ) is not None
            _register_runtime_handler_exact(list_name, handler)
            if not existed:
                acquired.append((list_name, handler))
    except Exception:
        _SMART_ID_CLEANUP_RUNTIME_ACTIVE = False
        for list_name, handler in reversed(acquired):
            _remove_runtime_handler_exact(list_name, handler)
        return False
    _SMART_ID_CLEANUP_RUNTIME_ACTIVE = True
    return True


def sync_all_runtime_features(context=None):
    """Single runtime commit point used after one validated settings commit."""
    sync_overlay_handlers(context)
    sync_selection_runtime_handlers(context)
    sync_proxy_cleanup_handlers(context)


def add_proxy_cleanup_handlers():
    # Backwards-compatible entry point used by older registration code.
    sync_proxy_cleanup_handlers(bpy.context)
    sync_selection_runtime_handlers(bpy.context)


def remove_proxy_cleanup_handlers():
    global _SMART_ID_SELECTION_RUNTIME_ACTIVE, _SMART_ID_CLEANUP_RUNTIME_ACTIVE
    _SMART_ID_CLEANUP_RUNTIME_ACTIVE = False
    for list_name, handler in (
        ("load_post", smart_id_cleanup_load_post),
        ("save_pre", smart_id_cleanup_save_pre),
        ("depsgraph_update_post", smart_id_selection_auto_refresh),
    ):
        _remove_runtime_handler_exact(list_name, handler)
    _clear_selection_runtime_msgbus()
    _cancel_selection_refresh_timer()
    _clear_inspector_runtime_caches()
    _SMART_ID_SELECTION_RUNTIME_ACTIVE = False


def _initialize_settings_and_runtime_once(scene=None, *, generation=None, force=False):
    """Validated settings load -> one property commit -> exactly one runtime sync."""
    generation = _SMART_ID_MODULE_GENERATION if generation is None else int(generation)
    if not _runtime_generation_is_current(generation):
        return False
    context = getattr(bpy, "context", None)
    scene = scene or getattr(context, "scene", None)
    restore_token = _begin_settings_restore(scene)
    if scene is None or not hasattr(scene, "smart_id_settings"):
        return False
    if not force and _runtime_generation_is_initialized(generation, scene):
        return True
    apply_npanel_settings(scene, sync_runtime=False, restore_token=restore_token)
    sync_all_runtime_features(context)
    _mark_runtime_generation_initialized(generation, scene)
    return True


@persistent
def _smart_id_settings_load_post(_dummy=None):
    global _SMART_ID_LOAD_IN_PROGRESS
    _smart_id_runtime_rearm_load_post()
    if not _runtime_generation_guard_fast(_SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN):
        return
    _SMART_ID_LOAD_IN_PROGRESS = False
    try:
        _initialize_settings_and_runtime_once(
            getattr(bpy.context, "scene", None),
            generation=_SMART_ID_MODULE_GENERATION,
            force=False,
        )
    except Exception:
        pass


@persistent
def _smart_id_settings_load_pre(_dummy=None):
    global _SMART_ID_SELECTION_RUNTIME_ACTIVE, _SMART_ID_LOAD_IN_PROGRESS
    if not _runtime_generation_guard_fast(_SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN):
        return
    _SMART_ID_LOAD_IN_PROGRESS = True
    _invalidate_runtime_generation_initialization()
    try:
        flush_deferred_npanel_settings()
    except Exception:
        pass
    try:
        remove_proxy_cleanup_handlers()
    except Exception:
        pass
    try:
        remove_overlay_handlers()
    except Exception:
        pass
    _clear_inspector_runtime_caches(clear_metadata_manifest=True)
    _reset_transient_cache_accounting_if_empty()
    _SMART_ID_SELECTION_RUNTIME_ACTIVE = False


@persistent
def _smart_id_settings_save_pre(_dummy=None):
    if not _runtime_generation_guard_fast(_SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN):
        return
    try:
        flush_deferred_npanel_settings()
    except Exception:
        pass


@persistent
def _smart_id_settings_exit_pre(_dummy=None):
    """Perform the same exact-identity teardown as an explicit add-on disable."""
    global _SMART_ID_EXIT_TEARDOWN_ACTIVE
    if _SMART_ID_EXIT_TEARDOWN_ACTIVE:
        return
    if not _runtime_generation_guard_fast(_SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN):
        return
    _SMART_ID_EXIT_TEARDOWN_ACTIVE = True
    try:
        # ``unregister`` releases timers, all app handlers (including this one),
        # draw handlers, msgbus owners, RNA properties/classes and translations
        # from the exact registration/runtime ledgers.  It does not scan names or
        # Blender namespaces and cannot consume a newer/foreign generation.
        unregister()
    finally:
        _SMART_ID_EXIT_TEARDOWN_ACTIVE = False


def _smart_id_scene_switched():
    if not _runtime_generation_guard_fast(_SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN):
        return
    if _SMART_ID_LOAD_IN_PROGRESS:
        # ``load_post`` owns the single validated commit/sync for a file load.
        # Window.scene may publish several times while Blender is still loading.
        return
    try:
        flush_deferred_npanel_settings()
    except Exception:
        pass
    try:
        _initialize_settings_and_runtime_once(
            getattr(bpy.context, "scene", None),
            generation=_SMART_ID_MODULE_GENERATION,
            force=False,
        )
    except Exception:
        pass


def _smart_id_post_register_restore_timer():
    """Legacy name retained for stale-version cleanup; never registered directly."""
    return None


def _cancel_post_register_restore_timer():
    global _SMART_ID_POST_REGISTER_TIMER_FN
    callback = _SMART_ID_POST_REGISTER_TIMER_FN
    if callable(callback):
        _remove_runtime_timer_exact(callback)
    _SMART_ID_POST_REGISTER_TIMER_FN = None


def _schedule_post_register_restore(generation):
    global _SMART_ID_POST_REGISTER_TIMER_FN
    _cancel_post_register_restore_timer()
    generation = int(generation)
    scheduled_restore_serial = int(_SETTINGS_RESTORE_SERIAL)
    scheduled_scene_key = _selection_scene_key(
        getattr(getattr(bpy, "context", None), "scene", None)
    )

    def _post_register_restore_once():
        global _SMART_ID_POST_REGISTER_TIMER_FN
        _untrack_runtime_timer(_post_register_restore_once)
        if _SMART_ID_POST_REGISTER_TIMER_FN is _post_register_restore_once:
            _SMART_ID_POST_REGISTER_TIMER_FN = None
        if not _runtime_generation_is_current(generation):
            return None
        current_scene = getattr(getattr(bpy, "context", None), "scene", None)
        current_scene_key = _selection_scene_key(current_scene)
        if (
            current_scene_key == scheduled_scene_key
            and int(_SETTINGS_RESTORE_SERIAL) != scheduled_restore_serial
        ):
            return None
        if not _runtime_generation_is_initialized(generation):
            try:
                _initialize_settings_and_runtime_once(
                    current_scene,
                    generation=generation,
                    force=False,
                )
            except Exception:
                pass
        return None

    _post_register_restore_once.__name__ = f"_smart_id_post_register_restore_once_g{generation}"
    _post_register_restore_once._smart_id_generation = generation
    _SMART_ID_POST_REGISTER_TIMER_FN = _post_register_restore_once
    try:
        _register_runtime_timer_exact(_post_register_restore_once, first_interval=0.0)
        return True
    except Exception:
        _SMART_ID_POST_REGISTER_TIMER_FN = None
        return False


def _register_settings_persistence():
    acquired = []
    try:
        for list_name, handler in (
            ("load_pre", _smart_id_settings_load_pre),
            ("load_post", _smart_id_settings_load_post),
            ("save_pre", _smart_id_settings_save_pre),
            ("exit_pre", _smart_id_settings_exit_pre),
        ):
            _register_runtime_handler_exact(list_name, handler)
            acquired.append((list_name, handler))
        bpy.msgbus.subscribe_rna(
            key=(bpy.types.Window, "scene"),
            owner=_SETTINGS_MSGBUS_OWNER,
            args=(),
            notify=_smart_id_scene_switched,
            options={"PERSISTENT"},
        )
        if _track_runtime_msgbus_owner(_SETTINGS_MSGBUS_OWNER) is None:
            raise RuntimeError("settings msgbus ownership ledger acquisition failed")
    except Exception:
        try:
            bpy.msgbus.clear_by_owner(_SETTINGS_MSGBUS_OWNER)
        except Exception:
            pass
        _untrack_runtime_msgbus_owner(_SETTINGS_MSGBUS_OWNER)
        for list_name, handler in reversed(acquired):
            _remove_runtime_handler_exact(list_name, handler)
        raise


def _unregister_settings_persistence():
    for list_name, handler in (
        ("load_pre", _smart_id_settings_load_pre),
        ("load_post", _smart_id_settings_load_post),
        ("save_pre", _smart_id_settings_save_pre),
        ("exit_pre", _smart_id_settings_exit_pre),
    ):
        _remove_runtime_handler_exact(list_name, handler)
    record = _resource_ledger_find("msgbus", _SETTINGS_MSGBUS_OWNER)
    if record is not None:
        remover = record.get("native_remover")
        if not callable(remover):
            return False
        removed = False
        for _attempt in range(max(1, int(_SMART_ID_RESOURCE_RELEASE_RETRY_LIMIT))):
            try:
                remover(_SETTINGS_MSGBUS_OWNER)
                removed = True
                break
            except Exception:
                continue
        if not removed:
            return False
        _untrack_runtime_msgbus_owner(_SETTINGS_MSGBUS_OWNER)
    return True



class SMARTID_PG_entry(bpy.types.PropertyGroup):
    uid: StringProperty(name="UID", description="Stable internal unique identifier for this Smart ID entry")
    selected: BoolProperty(name=UI_EN["multi_selected"], description=DESCRIPTIONS_EN["entry_multi_selected"], default=False, options={"SKIP_SAVE"}, update=_on_entry_checked_changed)
    enabled: BoolProperty(name=UI_EN["enabled"], description=DESCRIPTIONS_EN["entry_enabled"], default=True)
    locked: BoolProperty(name=UI_EN["locked"], description=DESCRIPTIONS_EN["entry_locked"], default=False)
    type: EnumProperty(name=UI_EN["type"], description=DESCRIPTIONS_EN["entry_type"], items=ID_TYPE_ITEMS, default="OBJECT_ID")
    name: StringProperty(name=UI_EN["name"], description=DESCRIPTIONS_EN["entry_name"], default="ID Entry")
    id_number: IntProperty(name=UI_EN["id_number"], description=DESCRIPTIONS_EN["entry_id_number"], default=1, min=0, max=2147483647)
    color: FloatVectorProperty(name=UI_EN["color"], description=DESCRIPTIONS_EN["entry_color"], subtype="COLOR", size=4, min=0.0, max=1.0, default=(0.75, 0.75, 0.75, 1.0))
    map_channel: IntProperty(name=UI_EN["map_channel"], description=DESCRIPTIONS_EN["entry_map_channel"], default=1, min=1, max=999)
    channel_name: StringProperty(name=UI_EN["channel_name"], description=DESCRIPTIONS_EN["entry_channel_name"], default="")
    material_name: StringProperty(name=UI_EN["material_id"], description=DESCRIPTIONS_EN["inspector_material_name"], default="")
    uv_map: StringProperty(name=UI_EN["uv_map"], description=DESCRIPTIONS_EN["entry_uv_map"], default="")
    color_attribute: StringProperty(name=UI_EN["color_attribute"], description=DESCRIPTIONS_EN["entry_color_attribute"], default="")
    attribute_name: StringProperty(name=UI_EN["attribute_name"], description=DESCRIPTIONS_EN["entry_attribute_name"], default="")
    attribute_type: EnumProperty(name=UI_EN["attribute_type"], description=DESCRIPTIONS_EN["entry_attribute_type"], items=ATTRIBUTE_TYPE_ITEMS, default="FLOAT")
    attribute_domain: EnumProperty(name=UI_EN["attribute_domain"], description=DESCRIPTIONS_EN["entry_attribute_domain"], items=ATTRIBUTE_DOMAIN_ITEMS, default="POINT")
    group_name: StringProperty(name=UI_EN["group_name"], description=DESCRIPTIONS_EN["entry_group_name"], default="")
    udim_tile: IntProperty(name=UI_EN["udim_tile"], description=DESCRIPTIONS_EN["entry_udim_tile"], default=1001, min=1001, max=9999)
    export_tag: StringProperty(name=UI_EN["export_tag"], description=DESCRIPTIONS_EN["entry_export_tag"], default="")
    notes: StringProperty(name=UI_EN["notes"], description=DESCRIPTIONS_EN["entry_notes"], default="")
    count_objects: IntProperty(name=UI_EN["object_count"], description="Number of objects currently matching this entry", default=0, min=0, options={"SKIP_SAVE"})
    count_materials: IntProperty(name=UI_EN["material_count"], description="Number of materials currently matching this entry", default=0, min=0, options={"SKIP_SAVE"})
    count_channels: IntProperty(name=UI_EN["channel_count"], description="Number of mesh channels currently matching this entry", default=0, min=0, options={"SKIP_SAVE"})
    count_selected_objects: IntProperty(name=UI_EN["object_count"], description="Number of selected or active objects matching this entry under the current library match scope", default=0, min=0, options={"SKIP_SAVE"})
    count_selected_materials: IntProperty(name=UI_EN["material_count"], description="Number of material slots or materials on the selected or active objects matching this entry under the current library match scope", default=0, min=0, options={"SKIP_SAVE"})
    count_selected_channels: IntProperty(name=UI_EN["channel_count"], description="Number of mesh channels on the selected or active objects matching this entry under the current library match scope", default=0, min=0, options={"SKIP_SAVE"})


class SMARTID_PG_inspector_item(bpy.types.PropertyGroup):
    uid: StringProperty(name="UID", description="Stable internal identifier for this selected-object inspector row")
    selected: BoolProperty(name=UI_EN["multi_selected"], description=DESCRIPTIONS_EN["inspector_multi_selected"], default=False, options={"SKIP_SAVE"})
    item_type: EnumProperty(name=UI_EN["inspector_item_type"], description=DESCRIPTIONS_EN["inspector_item_type"], items=INSPECTOR_TYPE_ITEMS, default="OBJECT_ID")
    owner_object: StringProperty(name=UI_EN["inspector_owner_object"], description=DESCRIPTIONS_EN["inspector_owner_object"], default="")
    owner_data: StringProperty(name=UI_EN["inspector_owner_data"], description=DESCRIPTIONS_EN["inspector_owner_data"], default="")
    material_name: StringProperty(name=UI_EN["material_id"], description=DESCRIPTIONS_EN["inspector_material_name"], default="")
    collection_name: StringProperty(name=UI_EN["selection_set"], description=DESCRIPTIONS_EN["inspector_collection_name"], default="")
    name: StringProperty(name=UI_EN["inspector_item_name"], description=DESCRIPTIONS_EN["inspector_item_name"], default="")
    edit_name: StringProperty(name=UI_EN["inspector_edit_name"], description=DESCRIPTIONS_EN["inspector_edit_name"], default="")
    id_number: IntProperty(name=UI_EN["id_number"], description=DESCRIPTIONS_EN["inspector_id_number"], default=0, min=0, max=2147483647)
    slot_index: IntProperty(name=UI_EN["inspector_slot_index"], description=DESCRIPTIONS_EN["inspector_slot_index"], default=-1, min=-1, max=2147483647)
    map_channel: IntProperty(name=UI_EN["map_channel"], description=DESCRIPTIONS_EN["entry_map_channel"], default=0, min=0, max=999)
    color: FloatVectorProperty(name=UI_EN["color"], description=DESCRIPTIONS_EN["inspector_color"], subtype="COLOR", size=4, min=0.0, max=1.0, default=(0.75, 0.75, 0.75, 1.0))
    active: BoolProperty(name=UI_EN["inspector_active"], description=DESCRIPTIONS_EN["inspector_active"], default=False)
    render: BoolProperty(name=UI_EN["inspector_render"], description=DESCRIPTIONS_EN["inspector_render"], default=False)
    data_type: StringProperty(name=UI_EN["inspector_data_type"], description=DESCRIPTIONS_EN["inspector_data_type"], default="")
    domain: StringProperty(name=UI_EN["inspector_domain"], description=DESCRIPTIONS_EN["inspector_domain"], default="")
    value_text: StringProperty(name=UI_EN["inspector_value"], description=DESCRIPTIONS_EN["inspector_value_text"], default="")
    details: StringProperty(name=UI_EN["notes"], description=DESCRIPTIONS_EN["inspector_details"], default="")
    # These display-routing fields are transient. Canonical English remains in
    # ``details`` for search, notes, export, and stored-data compatibility.
    details_message_id: StringProperty(default="", options={"SKIP_SAVE"})
    details_message_value: StringProperty(default="", options={"SKIP_SAVE"})
    safe_to_delete: BoolProperty(name=UI_EN["inspector_safe_delete"], description=DESCRIPTIONS_EN["inspector_safe_delete"], default=True)


class SMARTID_PG_settings(bpy.types.PropertyGroup):
    ui_section_always_on: BoolProperty(name="Always-On Features", description="Expand or collapse the unified Smart ID runtime controls.", default=False)
    n_panel_state_save: BoolProperty(name="N-panel State Save", description="Persist every portable Smart ID N-panel option to Smart_ID_Suite/Smart_ID_Suite.json on change. Turning this off records OFF once; while off, ordinary, direct, forced and shutdown paths do not write. Turning it on immediately snapshots current values.", default=True)
    always_on_selection_inspector: BoolProperty(name=UI_EN["selection_inspector_auto_refresh"], description=DESCRIPTIONS_EN["settings_selection_inspector_auto_refresh"], default=False)
    always_on_automatic_metadata_cleanup: BoolProperty(name="Automatic Metadata Cleanup", description="Automatically clears transient inspector rows and orphan Smart ID metadata on file load/save. Disable to remove both lifecycle handlers.", default=False)
    new_entry_type: EnumProperty(name=UI_EN["new_type"], description=DESCRIPTIONS_EN["settings_new_type"], items=ID_TYPE_ITEMS, default="OBJECT_ID")
    naming_profile: EnumProperty(name=UI_EN["naming_profile"], description=DESCRIPTIONS_EN["settings_naming_profile"], items=NAMING_PROFILE_ITEMS, default="BLENDER")
    filter_type: EnumProperty(name=UI_EN["filter_type"], description=DESCRIPTIONS_EN["settings_filter_type"], items=FILTER_TYPE_ITEMS, default="ALL")
    library_scope: EnumProperty(name=UI_EN["library_scope"], description=DESCRIPTIONS_EN["settings_library_scope"], items=LIBRARY_SCOPE_ITEMS, default="SELECTED")
    search: StringProperty(name=UI_EN["search"], description=DESCRIPTIONS_EN["settings_search"], default="")
    inspector_scope: EnumProperty(name=UI_EN["inspector_scope"], description=DESCRIPTIONS_EN["settings_inspector_scope"], items=INSPECTOR_SCOPE_ITEMS, default="SELECTED")
    inspector_filter_type: EnumProperty(name=UI_EN["inspector_filter"], description=DESCRIPTIONS_EN["settings_inspector_filter"], items=INSPECTOR_FILTER_ITEMS, default="ALL")
    inspector_search: StringProperty(name=UI_EN["inspector_search"], description=DESCRIPTIONS_EN["settings_inspector_search"], default="")
    sort_mode: EnumProperty(name=UI_EN["sort_mode"], description=DESCRIPTIONS_EN["settings_sort_mode"], items=SORT_MODE_ITEMS, default="TYPE_ID")
    target_scope: EnumProperty(name=UI_EN["scope"], description=DESCRIPTIONS_EN["settings_scope"], items=SCOPE_ITEMS, default="SELECTED")
    material_mode: EnumProperty(name=UI_EN["material_mode"], description=DESCRIPTIONS_EN["settings_material_mode"], items=MATERIAL_MODE_ITEMS, default="ACTIVE_SLOT")
    renumber_start: IntProperty(name=UI_EN["renumber_start"], description=DESCRIPTIONS_EN["settings_renumber_start"], default=1, min=0, max=2147483647)
    renumber_step: IntProperty(name=UI_EN["renumber_step"], description=DESCRIPTIONS_EN["settings_renumber_step"], default=1, min=1, max=1000000)
    use_pass_index: BoolProperty(name=UI_EN["use_pass_index"], description=DESCRIPTIONS_EN["settings_use_pass_index"], default=True)
    write_custom_props: BoolProperty(name=UI_EN["write_custom_props"], description=DESCRIPTIONS_EN["settings_write_custom_props"], default=True)
    create_missing_material: BoolProperty(name=UI_EN["create_missing_material"], description=DESCRIPTIONS_EN["settings_create_missing_material"], default=True)
    select_faces: BoolProperty(name=UI_EN["select_faces"], description=DESCRIPTIONS_EN["settings_select_faces"], default=False)
    include_disabled: BoolProperty(name=UI_EN["include_disabled"], description=DESCRIPTIONS_EN["settings_include_disabled"], default=False)
    clear_on_import: BoolProperty(name=UI_EN["clear_on_import"], description=DESCRIPTIONS_EN["settings_clear_on_import"], default=False)
    auto_color: BoolProperty(name=UI_EN["auto_color"], description=DESCRIPTIONS_EN["settings_auto_color"], default=True)
    last_library_autosync_signature: StringProperty(name="Smart ID Library Auto Sync Signature", description="Internal non-saved signature used to refresh selected-object library rows only when the active selection or its ID/channel data changes.", default="", options={"SKIP_SAVE"})
    ui_section_library: BoolProperty(name=UI_EN["section_library"], description=DESCRIPTIONS_EN["operator_toggle_section"], default=True)
    ui_section_entry_details: BoolProperty(name=UI_EN["section_entry_details"], description=DESCRIPTIONS_EN["operator_toggle_section"], default=True)
    ui_section_assignment: BoolProperty(name=UI_EN["section_assignment"], description=DESCRIPTIONS_EN["operator_toggle_section"], default=False)
    ui_section_selection_actions: BoolProperty(name=UI_EN["section_selection_actions"], description=DESCRIPTIONS_EN["operator_toggle_section"], default=True)
    ui_section_channel_tools: BoolProperty(name=UI_EN["section_channel_tools"], description=DESCRIPTIONS_EN["operator_toggle_section"], default=False)
    ui_section_selection_inspector: BoolProperty(name=UI_EN["section_selection_inspector"], description=DESCRIPTIONS_EN["operator_toggle_section"], default=False)
    ui_section_visual_overlay: BoolProperty(name=UI_EN["section_visual_overlay"], description=DESCRIPTIONS_EN["operator_toggle_section"], default=False)
    ui_section_validation_io: BoolProperty(name=UI_EN["section_validation_io"], description=DESCRIPTIONS_EN["operator_toggle_section"], default=False)
    overlay_enabled: BoolProperty(name=UI_EN["overlay_enabled"], description=DESCRIPTIONS_EN["settings_overlay_enabled"], default=False, update=overlay_setting_update)
    overlay_source: EnumProperty(name=UI_EN["overlay_source"], description=DESCRIPTIONS_EN["settings_overlay_source"], items=OVERLAY_SOURCE_ITEMS, default="VISIBLE_ENTRIES", update=overlay_setting_update)
    overlay_show_ids: BoolProperty(name=UI_EN["overlay_show_ids"], description=DESCRIPTIONS_EN["settings_overlay_show_ids"], default=True, update=overlay_setting_update)
    overlay_show_channels: BoolProperty(name=UI_EN["overlay_show_channels"], description=DESCRIPTIONS_EN["settings_overlay_show_channels"], default=True, update=overlay_setting_update)
    overlay_show_groups: BoolProperty(name=UI_EN["overlay_show_groups"], description=DESCRIPTIONS_EN["settings_overlay_show_groups"], default=True, update=overlay_setting_update)
    overlay_show_labels: BoolProperty(name=UI_EN["overlay_show_labels"], description=DESCRIPTIONS_EN["settings_overlay_show_labels"], default=True, update=overlay_setting_update)
    overlay_object_boxes: BoolProperty(name=UI_EN["overlay_object_boxes"], description=DESCRIPTIONS_EN["settings_overlay_object_boxes"], default=True, update=overlay_setting_update)
    overlay_element_marks: BoolProperty(name=UI_EN["overlay_element_marks"], description=DESCRIPTIONS_EN["settings_overlay_element_marks"], default=True, update=overlay_setting_update)
    overlay_alpha: FloatProperty(name=UI_EN["overlay_alpha"], description=DESCRIPTIONS_EN["settings_overlay_alpha"], default=0.75, min=0.05, max=1.0, update=overlay_setting_update)
    overlay_line_width: FloatProperty(name=UI_EN["overlay_line_width"], description=DESCRIPTIONS_EN["settings_overlay_line_width"], default=2.0, min=1.0, max=8.0, update=overlay_setting_update)
    last_report: StringProperty(name=UI_EN["last_report"], description="Short status text from the last Smart ID operation", default="", update=_on_last_report_changed)
    last_report_language: StringProperty(name="Last Report Language", default="", options={"HIDDEN"})


def _install_setting_persistence_updates():
    annotations = getattr(SMARTID_PG_settings, "__annotations__", {}) or {}
    for name, prop_def in annotations.items():
        if name in _TRANSIENT_SETTING_NAMES:
            continue
        keywords = getattr(prop_def, "keywords", None)
        if not isinstance(keywords, dict):
            continue
        keywords["update"] = _wrap_setting_update(keywords.get("update"), str(name))


_install_setting_persistence_updates()


def _wrap_entry_overlay_update(previous, property_name):
    def _update(self, context):
        if callable(previous):
            previous(self, context)
        _on_entry_overlay_changed(self, context)
    _update.__name__ = f"_smart_id_entry_overlay_update_{property_name}"
    _update._smart_id_wrapped_update = previous
    _update._smart_id_property_name = property_name
    return _update


def _install_entry_overlay_updates():
    transient_names = {
        "selected",
        "count_objects",
        "count_materials",
        "count_channels",
        "count_selected_objects",
        "count_selected_materials",
        "count_selected_channels",
    }
    annotations = getattr(SMARTID_PG_entry, "__annotations__", {}) or {}
    for name, prop_def in annotations.items():
        if name in transient_names:
            continue
        keywords = getattr(prop_def, "keywords", None)
        if not isinstance(keywords, dict):
            continue
        keywords["update"] = _wrap_entry_overlay_update(keywords.get("update"), str(name))


_install_entry_overlay_updates()

# -----------------------------------------------------------------------------
# Core helpers
# -----------------------------------------------------------------------------


_REGISTRY_BANK_IDPROP = "_smart_id_suite_registry_bank_v1"
_REGISTRY_COLLECTION_NAMES = ("smart_id_entries", "smart_id_entries_staging")


def _registry_active_bank(scene):
    try:
        value = int(scene.get(_REGISTRY_BANK_IDPROP, 0))
    except Exception:
        value = 0
    return 1 if value == 1 and hasattr(scene, _REGISTRY_COLLECTION_NAMES[1]) else 0


def _registry_collection_name(scene, bank=None):
    bank = _registry_active_bank(scene) if bank is None else (1 if int(bank) == 1 else 0)
    return _REGISTRY_COLLECTION_NAMES[bank]


def _registry_collection_for_bank(scene, bank):
    return getattr(scene, _registry_collection_name(scene, bank))


def _registry_inactive_bank(scene):
    return 1 - _registry_active_bank(scene)


def get_entries(scene):
    return _registry_collection_for_bank(scene, _registry_active_bank(scene))


def get_settings(scene):
    return scene.smart_id_settings


def active_entry(scene):
    entries = get_entries(scene)
    index = scene.smart_id_active_index
    if 0 <= index < len(entries):
        return entries[index]
    return None


def _library_scope_has_targets(context, settings):
    """Return scope availability without traversing object data from UI draw paths."""
    if context is None:
        return False
    scope = str(getattr(settings, "library_scope", "SCENE"))
    if scope == "SCENE":
        return False
    if scope == "ACTIVE":
        return context_active_object(context) is not None
    try:
        if bool(getattr(context, "selected_objects", ()) or ()):
            return True
    except Exception:
        pass
    return context_active_object(context) is not None


def _library_selection_signature(context, settings):
    """Draw-safe identity of the library scope targets: no object-data traversal."""
    scope = str(getattr(settings, "library_scope", "SCENE"))
    active = context_active_object(context)
    targets = ()
    if scope == "SELECTED":
        try:
            targets = getattr(context, "selected_objects", ()) or ()
        except Exception:
            targets = ()
    if not targets and scope != "SCENE" and active is not None:
        targets = (active,)
    return (scope,) + tuple(_primitive_selection_digest(targets))


def _remember_counted_library_selection(context, scene, settings):
    if len(_SMART_ID_COUNTED_LIBRARY_SELECTIONS) >= _SMART_ID_SELECTION_SIGNATURE_CACHE_LIMIT:
        _SMART_ID_COUNTED_LIBRARY_SELECTIONS.clear()
    _SMART_ID_COUNTED_LIBRARY_SELECTIONS[_selection_scene_key(scene)] = _library_selection_signature(context, settings)


def library_counts_are_stale(context, settings):
    # The count cache is only rebuilt by explicit operations, so it can describe
    # an earlier selection.  Rows must not be hidden or matched against it.
    if not _library_scope_has_targets(context, settings):
        return False
    counted = _SMART_ID_COUNTED_LIBRARY_SELECTIONS.get(_selection_scene_key(context.scene))
    return counted is not None and counted != _library_selection_signature(context, settings)


def _entry_selected_match_count(entry):
    if getattr(entry, "type", "") == "MATERIAL_ID":
        return int(getattr(entry, "count_selected_objects", 0) or 0)
    return (
        int(getattr(entry, "count_selected_objects", 0) or 0)
        + int(getattr(entry, "count_selected_materials", 0) or 0)
        + int(getattr(entry, "count_selected_channels", 0) or 0)
    )


def _entry_total_match_count(entry):
    if getattr(entry, "type", "") == "MATERIAL_ID":
        return int(getattr(entry, "count_objects", 0) or 0)
    return (
        int(getattr(entry, "count_objects", 0) or 0)
        + int(getattr(entry, "count_materials", 0) or 0)
        + int(getattr(entry, "count_channels", 0) or 0)
    )


def entry_visible_in_list(entry, settings, context=None, counts_stale=None, active=None):
    # UI filtering consumes the explicit-operation count cache only.  It never
    # traverses scene objects, materials or mesh channels during Panel/UIList draw.
    scoped_targets = _library_scope_has_targets(context, settings)
    if counts_stale is None:
        counts_stale = library_counts_are_stale(context, settings)
    selected_match = not counts_stale and _entry_selected_match_count(entry) > 0
    if settings.filter_type != "ALL" and entry.type != settings.filter_type:
        # Keep the selected object's ID row visible as an anchor for filtered views.
        if not (entry.type == "OBJECT_ID" and scoped_targets and selected_match):
            return False
    search = settings.search.lower().strip()
    if search:
        haystack = " ".join([
            entry.name,
            entry.channel_name,
            getattr(entry, "material_name", ""),
            material_entry_display_name(entry) if entry.type == "MATERIAL_ID" else "",
            entry.uv_map,
            entry.color_attribute,
            entry.attribute_name,
            entry.group_name,
            entry.export_tag,
            entry.notes,
        ]).lower()
        if search not in haystack:
            if not (entry.type == "OBJECT_ID" and scoped_targets and selected_match):
                return False
    if scoped_targets:
        if counts_stale or entry.type == "RENDER_AOV":
            return True
        # The operation buttons act on the active and checked rows, so those stay on screen.
        if entry.selected or (active is not None and entry == active):
            return True
        # An entry nothing uses yet, such as one just added, has no selection to match.
        return selected_match or _entry_total_match_count(entry) == 0
    return True


def visible_entry_indices(scene, context=None):
    settings = get_settings(scene)
    counts_stale = library_counts_are_stale(context, settings)
    active = active_entry(scene)
    return [index for index, entry in enumerate(get_entries(scene)) if entry_visible_in_list(entry, settings, context, counts_stale, active)]


def selected_entry_indices(scene):
    return [index for index, entry in enumerate(get_entries(scene)) if bool(entry.selected)]


def inspector_item_visible_in_list(item, settings):
    search = settings.inspector_search.lower().strip()
    if search:
        haystack = " ".join([
            item.owner_object,
            item.owner_data,
            item.material_name,
            item.collection_name,
            item.name,
            item.edit_name,
            _inspector_name_display_text(item),
            UI_EN["inspector_empty_slot"].format(index=item.slot_index) if _inspector_is_empty_slot(item) else "",
            _inspector_enum_label("owner_data", item.owner_data),
            item.value_text,
            _inspector_value_display_text(item),
            item.details,
            _inspector_details_display_text(item),
        ]).lower()
        if search not in haystack:
            return False
    filter_type = settings.inspector_filter_type
    if filter_type != "ALL" and item.item_type != filter_type:
        # Keep selected-object ID rows visible as anchors for every filtered inspector view.
        # This guarantees multi-object selections always show each selected object's ID.
        if item.item_type != "OBJECT_ID":
            return False
    return True


def visible_inspector_indices(scene):
    settings = get_settings(scene)
    return [index for index, item in enumerate(scene.smart_id_inspector_items) if inspector_item_visible_in_list(item, settings)]


def selected_inspector_indices(scene):
    return [index for index, item in enumerate(scene.smart_id_inspector_items) if bool(item.selected)]


def active_or_selected_entry_indices(scene, *, allowed_types=None, include_locked=True, include_disabled=True):
    entries = get_entries(scene)
    selected = selected_entry_indices(scene)
    if selected:
        indices = selected
    else:
        active_index = int(getattr(scene, "smart_id_active_index", -1))
        indices = [active_index] if 0 <= active_index < len(entries) else []
    result = []
    allowed = set(allowed_types) if allowed_types else None
    for index in indices:
        if not (0 <= index < len(entries)):
            continue
        entry = entries[index]
        if allowed is not None and entry.type not in allowed:
            continue
        if not include_locked and entry.locked:
            continue
        if not include_disabled and not entry.enabled:
            continue
        result.append(index)
    return result


def active_or_selected_entries(scene, *, allowed_types=None, include_locked=True, include_disabled=True):
    return [get_entries(scene)[index] for index in active_or_selected_entry_indices(scene, allowed_types=allowed_types, include_locked=include_locked, include_disabled=include_disabled)]


def active_or_selected_inspector_indices(scene, *, require_safe_delete=False):
    items = get_inspector_items(scene) if hasattr(scene, "smart_id_inspector_items") else []
    selected = selected_inspector_indices(scene)
    if selected:
        indices = selected
    else:
        active_index = int(getattr(scene, "smart_id_inspector_active_index", -1))
        indices = [active_index] if 0 <= active_index < len(items) else []
    result = []
    for index in indices:
        if not (0 <= index < len(items)):
            continue
        if require_safe_delete and not items[index].safe_to_delete:
            continue
        result.append(index)
    return result


def active_or_selected_inspector_items(scene, *, require_safe_delete=False):
    items = get_inspector_items(scene) if hasattr(scene, "smart_id_inspector_items") else []
    return [items[index] for index in active_or_selected_inspector_indices(scene, require_safe_delete=require_safe_delete)]


def visible_range_indices(visible_indices, anchor_index, target_index):
    if not visible_indices:
        return []
    if anchor_index in visible_indices and target_index in visible_indices:
        start = visible_indices.index(anchor_index)
        end = visible_indices.index(target_index)
        if start > end:
            start, end = end, start
        return visible_indices[start:end + 1]
    start = min(anchor_index, target_index)
    end = max(anchor_index, target_index)
    return [index for index in visible_indices if start <= index <= end]


def clamp_active_index_after_remove(scene, collection_name, active_prop):
    collection = getattr(scene, collection_name)
    if not collection:
        setattr(scene, active_prop, -1)
        return
    current = int(getattr(scene, active_prop, -1))
    setattr(scene, active_prop, max(0, min(current, len(collection) - 1)))


def clamp_pass_index(value):
    # Blender pass_index is an integer ID used by Index OB / Index MA passes. Keep it in a safe signed-short-like range.
    return max(0, min(int(value), 32767))


def next_id(scene, entry_type=None):
    used = {entry.id_number for entry in get_entries(scene) if entry_type is None or entry.type == entry_type}
    value = 1
    while value in used:
        value += 1
    return value


def generated_color(id_number):
    # Deterministic HSV-like color without importing colorsys repeatedly in hot paths.
    import colorsys
    hue = ((int(id_number) * 0.61803398875) % 1.0)
    sat = 0.62
    val = 0.88
    r, g, b = colorsys.hsv_to_rgb(hue, sat, val)
    return (r, g, b, 1.0)


def safe_name(text, fallback="ID"):
    text = (text or "").strip()
    if not text:
        text = fallback
    return "_".join(text.replace("/", "_").replace("\\", "_").split())


def profile_channel_name(entry_type, id_number, profile):
    num2 = f"{int(id_number):02d}"
    num3 = f"{int(id_number):03d}"
    if entry_type in {"MAP_CHANNEL", "UV_CHANNEL"}:
        if profile == "3DSMAX":
            return f"MapChannel_{num2}"
        if profile == "MAYA":
            return f"uvSet{num2}"
        if profile == "MARI":
            return f"UDIM_{1000 + int(id_number)}"
        if profile == "ZBRUSH":
            return f"UVTile_{num2}"
        if profile == "C4D":
            return f"UVW_Tag_{num2}"
        if profile == "LIGHTWAVE":
            return f"VMAP_UV_{num2}"
        return f"UVMap_{num2}"
    if entry_type == "COLOR_ATTRIBUTE":
        if profile == "MAYA":
            return f"colorSet{num2}"
        if profile == "ZBRUSH":
            return f"PolyPaint_{num3}"
        return f"Color_ID_{num2}"
    if entry_type == "GEOMETRY_ATTRIBUTE":
        return f"attr_id_{num2}"
    if entry_type == "SELECTION_SET":
        return f"Selection_Set_{num2}"
    if entry_type == "WEIGHT_GROUP":
        return f"Weight_ID_{num2}"
    if entry_type == "UDIM_TILE":
        return f"UDIM_{1000 + int(id_number)}"
    return f"ID_{num3}"


def default_entry_name(entry_type, id_number, profile):
    key = TYPE_LABEL_KEY.get(entry_type, "custom_id")
    base = UI_EN.get(key, "ID")
    return f"{base}_{int(id_number):03d}"


def resolve_channel_name(entry, settings=None):
    profile = settings.naming_profile if settings else "BLENDER"
    if entry.type == "UV_CHANNEL":
        return entry.uv_map or entry.channel_name or profile_channel_name(entry.type, entry.id_number, profile)
    if entry.type == "MAP_CHANNEL":
        return entry.channel_name or entry.uv_map or profile_channel_name(entry.type, entry.map_channel or entry.id_number, profile)
    if entry.type == "COLOR_ATTRIBUTE":
        return entry.color_attribute or entry.channel_name or profile_channel_name(entry.type, entry.id_number, profile)
    if entry.type == "GEOMETRY_ATTRIBUTE":
        return entry.attribute_name or entry.channel_name or profile_channel_name(entry.type, entry.id_number, profile)
    if entry.type in {"SELECTION_SET", "WEIGHT_GROUP"}:
        return entry.group_name or entry.channel_name or profile_channel_name(entry.type, entry.id_number, profile)
    if entry.type == "UDIM_TILE":
        return entry.channel_name or profile_channel_name(entry.type, entry.id_number, profile)
    return entry.channel_name or entry.export_tag or entry.name


def write_id_custom_props(id_data, entry, data_role):
    clear_smart_identity_props(id_data)
    operation_uuid = uuid.uuid4().hex
    id_data[_prop_key("uid")] = entry.uid
    id_data[_prop_key("type")] = entry.type
    id_data[_prop_key("name")] = entry.name
    id_data[_prop_key("id_number")] = int(entry.id_number)
    id_data[_prop_key("role")] = data_role
    id_data[_prop_key("export_tag")] = entry.export_tag
    id_data[_prop_key("channel_name")] = resolve_channel_name(entry)
    id_data[_prop_key("owner_uuid")] = _SMART_ID_SUITE_OWNER_UUID
    id_data[_prop_key("suite_id")] = ADDON_ID
    id_data[_prop_key("generation")] = int(_SMART_ID_MODULE_GENERATION)
    id_data[_prop_key("operation_uuid")] = operation_uuid
    _record_smart_identity_assignment(id_data, operation_uuid)


def context_active_object(context):
    try:
        if context.object:
            return context.object
    except Exception:
        pass
    try:
        view_layer = getattr(context, "view_layer", None)
        if view_layer and view_layer.objects.active:
            return view_layer.objects.active
    except Exception:
        pass
    return None


def _extend_selected_candidates(candidates, iterable):
    try:
        for obj in iterable:
            if obj:
                candidates.append(obj)
    except Exception:
        pass


def selected_scene_objects(context):
    objs = []
    seen = set()
    candidates = []
    _extend_selected_candidates(candidates, getattr(context, "selected_objects", []))
    _extend_selected_candidates(candidates, getattr(context, "objects_in_mode", []))
    _extend_selected_candidates(candidates, getattr(context, "objects_in_mode_unique_data", []))
    try:
        view_layer = getattr(context, "view_layer", None)
        if view_layer:
            _extend_selected_candidates(candidates, [obj for obj in view_layer.objects if obj.select_get()])
    except Exception:
        pass
    try:
        scene = getattr(context, "scene", None)
        if scene:
            _extend_selected_candidates(candidates, [obj for obj in scene.objects if obj.select_get()])
    except Exception:
        pass
    active = context_active_object(context)
    if active:
        try:
            if active.select_get() or not candidates:
                candidates.insert(0, active)
        except Exception:
            if not candidates:
                candidates.insert(0, active)
    for obj in candidates:
        if obj and obj.name not in seen:
            objs.append(obj)
            seen.add(obj.name)
    return objs


def library_scope_objects(context, settings=None, *, fallback_to_scene=True):
    scene = getattr(context, "scene", None)
    if scene is None:
        return []
    settings = settings or get_settings(scene)
    scope = getattr(settings, "library_scope", "SCENE")
    if scope == "ACTIVE":
        active = context_active_object(context)
        if active:
            return [active]
        return list(scene.objects) if fallback_to_scene else []
    if scope == "SELECTED":
        selected = selected_scene_objects(context)
        if selected:
            return selected
        active = context_active_object(context)
        if active:
            return [active]
        return list(scene.objects) if fallback_to_scene else []
    return list(scene.objects)


def unique_materials_from_objects(objects):
    materials = []
    seen = set()
    for obj in objects or []:
        for slot in getattr(obj, "material_slots", []):
            mat = getattr(slot, "material", None)
            if mat and mat.name not in seen:
                seen.add(mat.name)
                materials.append(mat)
    return materials


def object_scope(context, scope):
    scene = context.scene
    if scope == "ACTIVE":
        return [context.object] if context.object else []
    if scope == "SCENE":
        return list(scene.objects)
    if scope == "ALL_MESHES":
        return [obj for obj in scene.objects if obj.type == "MESH"]
    return selected_scene_objects(context)


def mesh_scope(context, scope):
    return [obj for obj in object_scope(context, scope) if obj and obj.type == "MESH" and obj.data]


ID_ENTRY_TYPES = {"OBJECT_ID", "MATERIAL_ID", "UDIM_TILE", "RENDER_AOV", "CRYPTOMATTE_ID", "CUSTOM_ID"}
# Rows whose element selection falls back to selecting the owning object.
OBJECT_LEVEL_SELECT_TYPES = ID_ENTRY_TYPES | {"SELECTION_SET"}
CHANNEL_ENTRY_TYPES = {"MAP_CHANNEL", "UV_CHANNEL", "COLOR_ATTRIBUTE", "GEOMETRY_ATTRIBUTE"}
GROUP_ENTRY_TYPES = {"SELECTION_SET", "WEIGHT_GROUP"}


def entry_kind(entry_type):
    if entry_type in CHANNEL_ENTRY_TYPES:
        return "CHANNEL"
    if entry_type in GROUP_ENTRY_TYPES:
        return "GROUP"
    return "ID"


def entry_allowed_by_overlay_filters(entry_type, settings):
    kind = entry_kind(entry_type)
    if kind == "ID" and not settings.overlay_show_ids:
        return False
    if kind == "CHANNEL" and not settings.overlay_show_channels:
        return False
    if kind == "GROUP" and not settings.overlay_show_groups:
        return False
    return True


def _is_auto_material_id_name(name, id_number=None):
    text = str(name or "").strip()
    if not text:
        return True
    if text.startswith("Material_ID_") or text.startswith("Material ID_") or text.startswith("SIS_Material_ID_"):
        return True
    if id_number is not None:
        try:
            number = int(id_number)
            return text in {f"Material_ID_{number:03d}", f"SIS_Material_ID_{number:03d}"}
        except Exception:
            return False
    return False


def material_entry_stack_name(entry):
    if not entry or getattr(entry, "type", "") != "MATERIAL_ID":
        return ""
    for attr in ("material_name", "channel_name"):
        try:
            value = str(getattr(entry, attr, "") or "").strip()
        except Exception:
            value = ""
        if value:
            return value
    name = str(getattr(entry, "name", "") or "").strip()
    if name and not _is_auto_material_id_name(name, getattr(entry, "id_number", None)):
        return name
    return ""


def material_matches_entry(mat, entry):
    if not mat or not entry:
        return False
    mat_name = str(getattr(mat, "name", "") or "").strip()
    stack_name = material_entry_stack_name(entry)
    if stack_name:
        if mat_name == stack_name:
            return True
        try:
            if mat.get(_prop_key("uid")) == entry.uid:
                return True
        except Exception:
            pass
        return False
    try:
        if mat.get(_prop_key("uid")) == entry.uid:
            return True
        if entry.id_number > 0 and mat.get(_prop_key("id_number")) == int(entry.id_number) and mat.get(_prop_key("type")) == entry.type:
            return True
    except Exception:
        pass
    try:
        if int(getattr(entry, "id_number", -1)) >= 0 and int(getattr(mat, "pass_index", -1)) == int(entry.id_number):
            return True
    except Exception:
        pass
    names = {entry.name, safe_name(entry.name or ""), f"SIS_{safe_name(entry.name or '')}"}
    return bool(mat_name and mat_name in names)


def material_names_for_entry_in_scope(entry, context=None):
    if not entry or getattr(entry, "type", "") != "MATERIAL_ID":
        return []
    names = []
    seen = set()

    def add(mat):
        if mat and getattr(mat, "name", "") and mat.name not in seen:
            seen.add(mat.name)
            names.append(mat.name)

    stack_name = material_entry_stack_name(entry)
    if stack_name:
        add(bpy.data.materials.get(stack_name))
        if names:
            return names
        return [stack_name]

    objects = []
    if context is not None and getattr(context, "scene", None) is not None:
        try:
            settings = get_settings(context.scene)
            if getattr(settings, "library_scope", "SCENE") != "SCENE":
                objects = library_scope_objects(context, settings, fallback_to_scene=False)
        except Exception:
            objects = []
    for obj in objects:
        for slot in getattr(obj, "material_slots", []):
            mat = getattr(slot, "material", None)
            if material_matches_entry(mat, entry):
                add(mat)
    return names


def material_entry_display_name(entry, context=None):
    del context  # Kept for compatibility with older callers.
    if not entry or getattr(entry, "type", "") != "MATERIAL_ID":
        return str(getattr(entry, "name", "") or "") if entry else ""
    return str(
        getattr(entry, "material_name", "")
        or getattr(entry, "channel_name", "")
        or getattr(entry, "name", "")
        or ""
    )

def object_matches_entry(obj, entry, settings=None):
    if not obj or not entry:
        return False
    settings = settings or get_settings(bpy.context.scene)
    channel_name = resolve_channel_name(entry, settings)
    if entry.type == "OBJECT_ID":
        try:
            if int(getattr(entry, "id_number", -1)) >= 0 and int(getattr(obj, "pass_index", -1)) == int(entry.id_number):
                return True
        except Exception:
            pass
        try:
            return obj.get(_prop_key("uid")) == entry.uid or (entry.id_number > 0 and obj.get(_prop_key("id_number")) == int(entry.id_number) and obj.get(_prop_key("type")) == entry.type)
        except Exception:
            return False
    if entry.type == "MATERIAL_ID":
        for slot in getattr(obj, "material_slots", []):
            if material_matches_entry(slot.material, entry):
                return True
        return False
    if entry.type == "SELECTION_SET":
        collection = bpy.data.collections.get(channel_name)
        return bool(collection and collection.objects.get(obj.name))
    if entry.type in {"CRYPTOMATTE_ID", "CUSTOM_ID"}:
        try:
            return obj.get(_prop_key("uid")) == entry.uid or (entry.id_number > 0 and obj.get(_prop_key("id_number")) == int(entry.id_number) and obj.get(_prop_key("type")) == entry.type)
        except Exception:
            return False
    if obj.type != "MESH" or not obj.data:
        return False
    mesh = obj.data
    if entry.type in {"MAP_CHANNEL", "UV_CHANNEL"}:
        return mesh.uv_layers.get(channel_name) is not None
    if entry.type == "COLOR_ATTRIBUTE":
        return mesh.color_attributes.get(channel_name) is not None
    if entry.type == "GEOMETRY_ATTRIBUTE":
        return mesh.attributes.get(channel_name) is not None
    if entry.type == "UDIM_TILE":
        try:
            return int(mesh.get(_prop_key("udim_tile"), -1)) == int(entry.udim_tile)
        except Exception:
            return False
    if entry.type == "WEIGHT_GROUP":
        return obj.vertex_groups.get(channel_name) is not None
    return False


def entry_matches_objects(entry, objects, settings=None):
    settings = settings or get_settings(bpy.context.scene)
    for obj in objects or []:
        if object_matches_entry(obj, entry, settings):
            return True
    return False


def count_entry_matches_on_objects(entry, objects, settings=None):
    settings = settings or get_settings(bpy.context.scene)
    object_count = 0
    material_count = 0
    channel_count = 0
    channel = resolve_channel_name(entry, settings)
    for obj in objects or []:
        if not obj:
            continue
        if entry.type == "MATERIAL_ID":
            slots = matching_material_slots(obj, entry)
            if slots:
                object_count += 1
                material_count += len(slots)
            continue
        if entry.type == "SELECTION_SET":
            collection = bpy.data.collections.get(channel)
            if collection and collection.objects.get(obj.name):
                object_count += 1
            continue
        if entry.type in {"MAP_CHANNEL", "UV_CHANNEL", "COLOR_ATTRIBUTE", "GEOMETRY_ATTRIBUTE", "UDIM_TILE", "WEIGHT_GROUP"}:
            if object_matches_entry(obj, entry, settings):
                channel_count += 1
            continue
        if object_matches_entry(obj, entry, settings):
            object_count += 1
    return object_count, material_count, channel_count



def matching_material_slots(obj, entry):
    slots = []
    for index, slot in enumerate(getattr(obj, "material_slots", [])):
        if material_matches_entry(slot.material, entry):
            slots.append(index)
    return slots


def make_entry_proxy_from_inspector(item):
    class EntryProxy:
        pass
    entry = EntryProxy()
    entry.uid = item.uid or uuid.uuid4().hex
    entry.enabled = True
    entry.locked = False
    entry.type = item.item_type if item.item_type in TYPE_ORDER else "CUSTOM_ID"
    if item.item_type == "SMART_METADATA" and item.data_type in TYPE_ORDER:
        entry.type = item.data_type
    entry.name = item.edit_name or item.name or default_entry_name(entry.type, item.id_number or 1, "")
    entry.id_number = int(item.id_number or 0)
    entry.color = tuple(item.color)
    entry.map_channel = max(1, int(item.map_channel or item.id_number or item.slot_index or 1))
    entry.channel_name = item.edit_name or item.name or ""
    entry.uv_map = entry.channel_name if entry.type in {"UV_CHANNEL", "MAP_CHANNEL"} else ""
    entry.color_attribute = entry.channel_name if entry.type == "COLOR_ATTRIBUTE" else ""
    entry.attribute_name = entry.channel_name if entry.type == "GEOMETRY_ATTRIBUTE" else ""
    entry.attribute_type = item.data_type if item.data_type in {x[0] for x in ATTRIBUTE_TYPE_ITEMS} else "FLOAT"
    entry.attribute_domain = item.domain if item.domain in {x[0] for x in ATTRIBUTE_DOMAIN_ITEMS} else "POINT"
    entry.group_name = entry.channel_name if entry.type in {"WEIGHT_GROUP", "SELECTION_SET"} else ""
    entry.udim_tile = max(1001, int(item.id_number or 1001))
    entry.export_tag = item.value_text or ""
    entry.notes = item.details or ""
    entry.material_name = item.material_name or item.name or ""
    entry.slot_index = int(item.slot_index)
    entry.owner_object = item.owner_object or ""
    return entry


def ensure_object_mode(context):
    try:
        if context.object and context.object.mode != "OBJECT":
            bpy.ops.object.mode_set("EXEC_DEFAULT", False, mode="OBJECT")
    except Exception:
        pass


def clear_mesh_element_selection(obj):
    if not obj or obj.type != "MESH" or not obj.data:
        return
    mesh = obj.data
    for vertex in mesh.vertices:
        vertex.select = False
    for edge in mesh.edges:
        edge.select = False
    for polygon in mesh.polygons:
        polygon.select = False


def select_mesh_domain(obj, domain, *, value_filter=None, additive=False):
    if not obj or obj.type != "MESH" or not obj.data:
        return 0, "FACE"
    mesh = obj.data
    count = 0
    domain = str(domain or "FACE")
    if domain == "POINT":
        for vertex in mesh.vertices:
            ok = True if value_filter is None else bool(value_filter(vertex.index))
            if additive:
                if ok:
                    vertex.select = True
                    count += 1
            else:
                vertex.select = ok
                count += int(ok)
        return count, "VERT"
    if domain == "EDGE":
        for edge in mesh.edges:
            ok = True if value_filter is None else bool(value_filter(edge.index))
            if additive:
                if ok:
                    edge.select = True
                    count += 1
            else:
                edge.select = ok
                count += int(ok)
        return count, "EDGE"
    # FACE and CORNER data are most useful when shown as selected faces.
    for polygon in mesh.polygons:
        ok = True if value_filter is None else bool(value_filter(polygon.index))
        if additive:
            if ok:
                polygon.select = True
                count += 1
        else:
            polygon.select = ok
            count += int(ok)
    return count, "FACE"


def select_vertices_in_group(obj, group_name, *, additive=False):
    if not obj or obj.type != "MESH" or not obj.data:
        return 0, "VERT"
    group = obj.vertex_groups.get(group_name)
    if group is None:
        return 0, "VERT"
    count = 0
    target_index = group.index
    for vertex in obj.data.vertices:
        selected = any(weight.group == target_index and weight.weight > 0.0 for weight in vertex.groups)
        if additive:
            if selected:
                vertex.select = True
                count += 1
        else:
            vertex.select = selected
            count += int(selected)
    return count, "VERT"


def select_material_faces(obj, slot_indices, *, additive=False):
    if not obj or obj.type != "MESH" or not obj.data:
        return 0, "FACE"
    slot_indices = {int(index) for index in slot_indices if index is not None and int(index) >= 0}
    count = 0
    for polygon in obj.data.polygons:
        selected = int(polygon.material_index) in slot_indices
        if additive:
            if selected:
                polygon.select = True
                count += 1
        else:
            polygon.select = selected
            count += int(selected)
    return count, "FACE"


def activate_channel_for_entry(obj, entry, settings):
    if not obj or obj.type != "MESH" or not obj.data:
        return None, "FACE"
    mesh = obj.data
    name = resolve_channel_name(entry, settings)
    if entry.type in {"MAP_CHANNEL", "UV_CHANNEL"}:
        layer = mesh.uv_layers.get(name)
        if layer:
            _set_active_uv(mesh, layer)
        return layer, "FACE"
    if entry.type == "COLOR_ATTRIBUTE":
        attr = mesh.color_attributes.get(name)
        if attr:
            _set_active_color_attribute(mesh, attr)
            domain = getattr(attr, "domain", "CORNER")
            return attr, "VERT" if domain == "POINT" else "FACE"
        return None, "FACE"
    if entry.type == "GEOMETRY_ATTRIBUTE":
        attr = mesh.attributes.get(name)
        if attr:
            _set_active_geometry_attribute(mesh, attr)
            domain = getattr(attr, "domain", "POINT")
            if domain == "POINT":
                return attr, "VERT"
            if domain == "EDGE":
                return attr, "EDGE"
            return attr, "FACE"
        return None, "FACE"
    return None, "FACE"


def select_objects_matching_entry(context, entry, *, deselect=False):
    settings = get_settings(context.scene)
    ensure_object_mode(context)
    count = 0
    first = None
    if not deselect:
        for obj in context.scene.objects:
            try:
                obj.select_set(False)
            except Exception:
                pass
    for obj in context.scene.objects:
        if object_matches_entry(obj, entry, settings):
            try:
                obj.select_set(not deselect)
                count += 1
                if first is None and not deselect:
                    first = obj
            except Exception:
                pass
    if first is not None:
        context.view_layer.objects.active = first
    return count


def select_elements_matching_entry(context, entry, *, deselect=False):
    settings = get_settings(context.scene)
    ensure_object_mode(context)
    if not deselect:
        for obj in context.scene.objects:
            try:
                obj.select_set(False)
            except Exception:
                pass
    selected_objects = []
    element_count = 0
    select_mode = "FACE"
    channel_name = resolve_channel_name(entry, settings)
    for obj in context.scene.objects:
        if obj.type != "MESH" or not obj.data:
            continue
        if not object_matches_entry(obj, entry, settings):
            if not deselect:
                clear_mesh_element_selection(obj)
            continue
        if not deselect:
            clear_mesh_element_selection(obj)
        local_count = 0
        local_mode = "FACE"
        if entry.type == "MATERIAL_ID":
            local_count, local_mode = select_material_faces(obj, matching_material_slots(obj, entry))
        elif entry.type in {"MAP_CHANNEL", "UV_CHANNEL"}:
            activate_channel_for_entry(obj, entry, settings)
            local_count, local_mode = select_mesh_domain(obj, "FACE")
        elif entry.type == "COLOR_ATTRIBUTE":
            attr, local_mode = activate_channel_for_entry(obj, entry, settings)
            domain = getattr(attr, "domain", "CORNER") if attr else "CORNER"
            local_count, local_mode = select_mesh_domain(obj, domain)
        elif entry.type == "GEOMETRY_ATTRIBUTE":
            attr, local_mode = activate_channel_for_entry(obj, entry, settings)
            domain = getattr(attr, "domain", "POINT") if attr else "POINT"
            local_count, local_mode = select_mesh_domain(obj, domain)
        elif entry.type == "WEIGHT_GROUP":
            local_count, local_mode = select_vertices_in_group(obj, channel_name)
        else:
            # ID rows that have no exact mesh element domain still select the owning object.
            local_count = 0
        if deselect:
            clear_mesh_element_selection(obj)
            try:
                obj.select_set(False)
            except Exception:
                pass
        elif local_count > 0:
            try:
                obj.select_set(True)
            except Exception:
                pass
            selected_objects.append(obj)
            element_count += local_count
            select_mode = local_mode
        elif entry.type in OBJECT_LEVEL_SELECT_TYPES and object_matches_entry(obj, entry, settings):
            try:
                obj.select_set(True)
            except Exception:
                pass
            selected_objects.append(obj)
    if selected_objects:
        context.view_layer.objects.active = selected_objects[0]
        try:
            bpy.ops.object.mode_set("EXEC_DEFAULT", False, mode="EDIT")
            bpy.ops.mesh.select_mode("EXEC_DEFAULT", False, type=select_mode)
        except Exception:
            pass
    return element_count if element_count else len(selected_objects)


def select_elements_for_inspector_item(context, item, *, deselect=False, clear_existing=True):
    if not item:
        return 0
    ensure_object_mode(context)
    if item.item_type == "SELECTION_SET" and item.collection_name:
        collection = bpy.data.collections.get(item.collection_name)
        if not collection:
            return 0
        if not deselect and clear_existing:
            for obj in context.scene.objects:
                obj.select_set(False)
        count = 0
        first = None
        for obj in collection.objects:
            try:
                obj.select_set(not deselect)
                count += 1
                if first is None and not deselect:
                    first = obj
            except Exception:
                pass
        if first:
            context.view_layer.objects.active = first
        return count
    obj = inspector_owner_object(item)
    if not obj:
        return 0
    if not deselect and clear_existing:
        for scene_obj in context.scene.objects:
            try:
                scene_obj.select_set(False)
            except Exception:
                pass
    if item.item_type == "OBJECT_ID" or obj.type != "MESH":
        try:
            obj.select_set(not deselect)
            if not deselect:
                context.view_layer.objects.active = obj
            return 1
        except Exception:
            return 0
    if clear_existing:
        clear_mesh_element_selection(obj)
    count = 0
    select_mode = "FACE"
    if item.item_type == "MATERIAL_ID":
        if item.slot_index >= 0:
            count, select_mode = select_material_faces(obj, [item.slot_index], additive=not clear_existing)
    elif item.item_type in {"UV_CHANNEL", "MAP_CHANNEL"}:
        name = item.edit_name or item.name
        layer = obj.data.uv_layers.get(name)
        if layer:
            _set_active_uv(obj.data, layer)
            count, select_mode = select_mesh_domain(obj, "FACE", additive=not clear_existing)
    elif item.item_type == "COLOR_ATTRIBUTE":
        attr = obj.data.color_attributes.get(item.edit_name or item.name)
        if attr:
            _set_active_color_attribute(obj.data, attr)
            count, select_mode = select_mesh_domain(obj, getattr(attr, "domain", "CORNER"), additive=not clear_existing)
    elif item.item_type == "GEOMETRY_ATTRIBUTE":
        attr = obj.data.attributes.get(item.edit_name or item.name)
        if attr:
            _set_active_geometry_attribute(obj.data, attr)
            count, select_mode = select_mesh_domain(obj, getattr(attr, "domain", "POINT"), additive=not clear_existing)
    elif item.item_type == "WEIGHT_GROUP":
        count, select_mode = select_vertices_in_group(obj, item.edit_name or item.name, additive=not clear_existing)
    elif item.item_type in {"UDIM_TILE", "SMART_METADATA"}:
        count = 0
    if deselect:
        clear_mesh_element_selection(obj)
        obj.select_set(False)
        return 1
    obj.select_set(True)
    context.view_layer.objects.active = obj
    if count > 0:
        try:
            bpy.ops.object.mode_set("EXEC_DEFAULT", False, mode="EDIT")
            bpy.ops.mesh.select_mode("EXEC_DEFAULT", False, type=select_mode)
        except Exception:
            pass
        return count
    return 1


def select_elements_for_inspector_items(context, items, *, deselect=False):
    items = [item for item in items if item]
    if not items:
        return 0
    total = 0
    first = True
    for item in items:
        total += int(select_elements_for_inspector_item(context, item, deselect=deselect, clear_existing=first) or 0)
        first = False
    return total


def select_inspector_owners(context, items):
    items = [item for item in items if item]
    if not items:
        return 0
    ensure_object_mode(context)
    for scene_obj in context.scene.objects:
        try:
            scene_obj.select_set(False)
        except Exception:
            pass
    selected = []
    for item in items:
        obj = inspector_owner_object(item)
        if obj and obj.name not in {existing.name for existing in selected}:
            try:
                obj.select_set(True)
                selected.append(obj)
            except Exception:
                pass
    if selected:
        context.view_layer.objects.active = selected[0]
    return len(selected)


def clear_matching_smart_props(id_data, entry_type=None, id_number=None, uid=None):
    if id_data is None:
        return 0
    try:
        matched = False
        if uid and id_data.get(_prop_key("uid")) == uid:
            matched = True
        if entry_type and id_data.get(_prop_key("type")) == entry_type:
            if id_number is None or id_number <= 0 or id_data.get(_prop_key("id_number")) == int(id_number):
                matched = True
        if matched:
            return clear_smart_props(id_data)
    except Exception:
        pass
    return 0


def _forget_map_channel_key(mesh, entry, name):
    """Apply records map_channel_<n> for UV and map rows alike; drop it with the channel."""
    key = _prop_key(f"map_channel_{int(entry.map_channel or entry.id_number or 1)}")
    if mesh.get(key) != name:
        return False
    del mesh[key]
    return True


def unassign_entry_from_selection(context, entry):
    settings = get_settings(context.scene)
    ensure_object_mode(context)
    targets = object_scope(context, settings.target_scope)
    changed = 0
    name = resolve_channel_name(entry, settings)
    for obj in targets:
        if not obj:
            continue
        if entry.type == "OBJECT_ID":
            if object_matches_entry(obj, entry, settings):
                try:
                    obj.pass_index = 0
                except Exception:
                    pass
                clear_matching_smart_props(obj, entry.type, entry.id_number, entry.uid)
                changed += 1
            continue
        if entry.type in {"CRYPTOMATTE_ID", "CUSTOM_ID"}:
            cleared = clear_matching_smart_props(obj, entry.type, entry.id_number, entry.uid)
            if entry.type == "CRYPTOMATTE_ID" and obj.get(_prop_key("cryptomatte_name")) is not None:
                try:
                    del obj[_prop_key("cryptomatte_name")]
                    cleared += 1
                except Exception:
                    pass
            changed += int(bool(cleared))
            continue
        if entry.type == "SELECTION_SET":
            collection = bpy.data.collections.get(name)
            if collection and obj.name in collection.objects:
                try:
                    collection.objects.unlink(obj)
                    changed += 1
                    clear_matching_smart_props(obj, entry.type, entry.id_number, entry.uid)
                except Exception:
                    pass
            continue
        if obj.type != "MESH" or not obj.data:
            continue
        mesh = obj.data
        if entry.type == "MATERIAL_ID":
            if settings.material_mode == "SELECTED_FACES":
                matching = set(matching_material_slots(obj, entry))
                for poly in mesh.polygons:
                    if poly.select and int(poly.material_index) in matching:
                        poly.material_index = 0
                        changed += 1
            else:
                for index, slot in enumerate(obj.material_slots):
                    if material_matches_entry(slot.material, entry):
                        if settings.material_mode == "ACTIVE_SLOT" and index != obj.active_material_index:
                            continue
                        slot.material = None
                        changed += 1
            continue
        if entry.type in {"MAP_CHANNEL", "UV_CHANNEL"}:
            removed = _forget_map_channel_key(mesh, entry, name)
            if remove_uv_layer(obj, name):
                removed = True
            if removed:
                changed += 1
                clear_matching_smart_props(mesh, entry.type, entry.id_number, entry.uid)
            continue
        if entry.type == "COLOR_ATTRIBUTE":
            if remove_color_attribute(obj, name):
                changed += 1
                clear_matching_smart_props(mesh, entry.type, entry.id_number, entry.uid)
            continue
        if entry.type == "GEOMETRY_ATTRIBUTE":
            if remove_geometry_attribute(obj, name):
                changed += 1
                clear_matching_smart_props(mesh, entry.type, entry.id_number, entry.uid)
            continue
        if entry.type == "WEIGHT_GROUP":
            group = obj.vertex_groups.get(name)
            if group:
                selected_indices = [vertex.index for vertex in mesh.vertices if vertex.select]
                if selected_indices:
                    try:
                        group.remove(selected_indices)
                        changed += len(selected_indices)
                    except Exception:
                        pass
                else:
                    obj.vertex_groups.remove(group)
                    changed += 1
                    clear_matching_smart_props(obj, entry.type, entry.id_number, entry.uid)
            continue
        if entry.type == "UDIM_TILE":
            key = _prop_key("udim_tile")
            try:
                if int(mesh.get(key, -1)) == int(entry.udim_tile):
                    del mesh[key]
                    changed += 1
                    clear_matching_smart_props(mesh, entry.type, entry.id_number, entry.uid)
            except Exception:
                pass
    return changed


def assign_inspector_item_to_selection(context, item):
    if not item:
        return 0
    entry = make_entry_proxy_from_inspector(item)
    settings = get_settings(context.scene)
    previous_scope = settings.target_scope
    previous_write_custom_props = settings.write_custom_props
    try:
        settings.target_scope = "SELECTED"
        settings.write_custom_props = False
        return apply_entry(context, entry)
    finally:
        settings.target_scope = previous_scope
        settings.write_custom_props = previous_write_custom_props


def unassign_inspector_item_from_selection(context, item):
    if not item:
        return 0
    entry = make_entry_proxy_from_inspector(item)
    previous_scope = get_settings(context.scene).target_scope
    try:
        get_settings(context.scene).target_scope = "SELECTED"
        return unassign_entry_from_selection(context, entry)
    finally:
        get_settings(context.scene).target_scope = previous_scope



def get_inspector_items(scene):
    return scene.smart_id_inspector_items


def active_inspector_item(scene):
    items = get_inspector_items(scene)
    index = scene.smart_id_inspector_active_index
    if 0 <= index < len(items):
        return items[index]
    return None


def inspector_objects(context):
    settings = get_settings(context.scene)
    if settings.inspector_scope == "ACTIVE":
        active = context_active_object(context)
        return [active] if active else []
    return selected_scene_objects(context)


def smart_prop_keys(id_data):
    try:
        return [str(key) for key in id_data.keys() if str(key).startswith(CUSTOM_PREFIX)]
    except Exception:
        return []


def smart_props_summary(id_data, limit=220):
    parts = []
    for key in smart_prop_keys(id_data):
        try:
            parts.append(f"{key}={id_data[key]}")
        except Exception:
            parts.append(str(key))
    text = ", ".join(parts)
    if len(text) > limit:
        text = text[: max(0, limit - 1)] + "…"
    return text


def clear_smart_props(id_data):
    removed = 0
    for key in list(smart_prop_keys(id_data)):
        try:
            del id_data[key]
            removed += 1
        except Exception:
            pass
    return removed


def write_custom_props_from_inspector(id_data, item, data_role, entry_type=None):
    uid_key = _prop_key("uid")
    try:
        uid_value = id_data.get(uid_key)
        if not uid_value:
            return False
        id_data[uid_key] = uid_value
        id_data[_prop_key("type")] = entry_type or item.item_type
        if item.edit_name or item.name:
            id_data[_prop_key("name")] = item.edit_name or item.name
        id_data[_prop_key("id_number")] = int(item.id_number)
        id_data[_prop_key("role")] = data_role
        id_data[_prop_key("export_tag")] = str(id_data.get(_prop_key("export_tag"), "") or "")
        if item.edit_name or item.name:
            id_data[_prop_key("channel_name")] = item.edit_name or item.name
        return True
    except Exception:
        return False


def inspector_filter_matches(settings, item_type, *fields):
    search = (settings.inspector_search or "").strip().lower()
    if search:
        found = False
        for field in fields:
            if field is not None and search in str(field).lower():
                found = True
                break
        if not found:
            return False
    filter_type = settings.inspector_filter_type
    if filter_type != "ALL" and item_type != filter_type:
        return item_type == "OBJECT_ID"
    return True


_SMART_ID_INSPECTOR_ITEM_LIMIT = 4096
# Compatibility alias retained for internal callers from 0.6.12.
_INSPECTOR_MAX_ITEMS = _SMART_ID_INSPECTOR_ITEM_LIMIT


UI_EN.update({
    "attr_type_FLOAT": "Floating Point",
    "attr_type_INT": "Integer",
    "attr_type_BOOLEAN": "Boolean",
    "attr_type_FLOAT_VECTOR": "Vector",
    "attr_type_FLOAT_COLOR": "Floating Point Color",
    "attr_type_QUATERNION": "Quaternion",
    "attr_type_FLOAT4X4": "4x4 Matrix",
    "attr_type_STRING": "String",
    "attr_type_INT8": "8-Bit Integer",
    "attr_type_INT16_2D": "2D 16-Bit Integer",
    "attr_type_INT32_2D": "2D Integer",
    "attr_type_FLOAT2": "2D Vector",
    "attr_type_BYTE_COLOR": "Byte Color",
    "attr_domain_POINT": "Point",
    "attr_domain_EDGE": "Edge",
    "attr_domain_FACE": "Face",
    "attr_domain_CORNER": "Corner",
    "attr_domain_CURVE": "Curve",
    "attr_domain_INSTANCE": "Instance",
    "attr_domain_LAYER": "Layer",
    "object_type_MESH": "Mesh",
    "object_type_CURVE": "Curve",
    "object_type_SURFACE": "Surface",
    "object_type_META": "Metaball",
    "object_type_FONT": "Text",
    "object_type_CURVES": "Hair Curves",
    "object_type_POINTCLOUD": "Point Cloud",
    "object_type_VOLUME": "Volume",
    "object_type_GREASEPENCIL": "Grease Pencil",
    "object_type_ARMATURE": "Armature",
    "object_type_LATTICE": "Lattice",
    "object_type_EMPTY": "Empty",
    "object_type_LIGHT": "Light",
    "object_type_LIGHT_PROBE": "Light Probe",
    "object_type_CAMERA": "Camera",
    "object_type_SPEAKER": "Speaker",
    "owner_data_OBJECT": "Object",
    "owner_data_MATERIAL": "Material",
    "owner_data_MATERIAL_SLOT": "Material Slot",
    "owner_data_MESH": "Mesh",
    "owner_data_MESH_METADATA": "Mesh Metadata",
    "owner_data_MESH_UV": "Mesh UV",
    "owner_data_MESH_COLOR_ATTRIBUTE": "Mesh Color Attribute",
    "owner_data_MESH_ATTRIBUTE": "Mesh Attribute",
    "owner_data_VERTEX_GROUP": "Vertex Group",
    "owner_data_COLLECTION": "Collection",
    "inspector_value_linked": "Linked",
    "inspector_value_active": "Active",
    "inspector_value_uv": "UV",
    "inspector_empty_slot": "Empty Slot {index}",
    "entry_notes_from_inspector": "Created from the inspector: {owner} / {data}",
    "report_settings_error": "Could not read or write the Smart ID settings",
})

UI_JA.update({
    "attr_type_FLOAT": "浮動小数点",
    "attr_type_INT": "整数",
    "attr_type_BOOLEAN": "ブーリアン",
    "attr_type_FLOAT_VECTOR": "ベクトル",
    "attr_type_FLOAT_COLOR": "浮動小数点カラー",
    "attr_type_QUATERNION": "クォータニオン",
    "attr_type_FLOAT4X4": "4×4行列",
    "attr_type_STRING": "文字列",
    "attr_type_INT8": "8ビット整数",
    "attr_type_INT16_2D": "2D 16ビット整数",
    "attr_type_INT32_2D": "2D整数",
    "attr_type_FLOAT2": "2Dベクトル",
    "attr_type_BYTE_COLOR": "バイトカラー",
    "attr_domain_POINT": "ポイント",
    "attr_domain_EDGE": "辺",
    "attr_domain_FACE": "面",
    "attr_domain_CORNER": "コーナー",
    "attr_domain_CURVE": "カーブ",
    "attr_domain_INSTANCE": "インスタンス",
    "attr_domain_LAYER": "レイヤー",
    "object_type_MESH": "メッシュ",
    "object_type_CURVE": "カーブ",
    "object_type_SURFACE": "サーフェス",
    "object_type_META": "メタボール",
    "object_type_FONT": "テキスト",
    "object_type_CURVES": "ヘアカーブ",
    "object_type_POINTCLOUD": "ポイントクラウド",
    "object_type_VOLUME": "ボリューム",
    "object_type_GREASEPENCIL": "グリースペンシル",
    "object_type_ARMATURE": "アーマチュア",
    "object_type_LATTICE": "ラティス",
    "object_type_EMPTY": "エンプティ",
    "object_type_LIGHT": "ライト",
    "object_type_LIGHT_PROBE": "ライトプローブ",
    "object_type_CAMERA": "カメラ",
    "object_type_SPEAKER": "スピーカー",
    "owner_data_OBJECT": "オブジェクト",
    "owner_data_MATERIAL": "マテリアル",
    "owner_data_MATERIAL_SLOT": "マテリアルスロット",
    "owner_data_MESH": "メッシュ",
    "owner_data_MESH_METADATA": "メッシュのメタデータ",
    "owner_data_MESH_UV": "メッシュのUV",
    "owner_data_MESH_COLOR_ATTRIBUTE": "メッシュのカラー属性",
    "owner_data_MESH_ATTRIBUTE": "メッシュの属性",
    "owner_data_VERTEX_GROUP": "頂点グループ",
    "owner_data_COLLECTION": "コレクション",
    "inspector_value_linked": "リンク",
    "inspector_value_active": "アクティブ",
    "inspector_value_uv": "UV",
    "inspector_empty_slot": "空のスロット {index}",
    "entry_notes_from_inspector": "検査から作成: {owner} / {data}",
    "report_settings_error": "Smart ID の設定を読み書きできませんでした",
})

_INSPECTOR_DETAIL_MESSAGE_IDS = frozenset({
    "details_smart_id_custom_props",
    "details_object_type",
    "details_collection_membership",
    "details_material_slot_assignment",
    "details_empty_material_slot",
    "details_map_channels_prefix",
    "details_uv_map",
    "details_map_channel_with_uv",
    "details_map_channel_without_uv",
    "details_color_attribute",
    "details_protected_geometry_attribute",
    "details_geometry_attribute",
    "details_udim_metadata",
    "details_vertex_group",
})

_INSPECTOR_DETAIL_VALUE_PLACEHOLDERS = {
    "details_smart_id_custom_props": "owner",
    "details_object_type": "type",
    "details_map_channels_prefix": "channels",
}


def _inspector_enum_label(prefix, value, context=None):
    """Return the display label for a stored internal name; unknown names stay as they are."""
    key = f"{prefix}_{value}"
    return t(key, context) if key in UI_EN else str(value or "")


def _inspector_data_type_display_text(item, context=None):
    if item.item_type == "SMART_METADATA":
        key = TYPE_LABEL_KEY.get(item.data_type)
        return t(key, context) if key else item.data_type
    return _inspector_enum_label("attr_type", item.data_type, context)


_INSPECTOR_VALUE_KEYS_JA = {"slot": "スロット", "channel": "チャンネル", "tile": "タイル", "index": "番号", "uv": "UV", "pass_index": "パス番号"}
_INSPECTOR_VALUE_KEYS_EN = {"slot": "Slot", "channel": "Channel", "tile": "Tile", "index": "Index", "uv": "UV", "pass_index": "Pass Index"}
_INSPECTOR_VALUE_KEY_RE = re.compile(r"(^|, )(slot|channel|tile|index|uv|pass_index)=")


def _inspector_is_empty_slot(item):
    return item.item_type == "MATERIAL_ID" and item.owner_data == "MATERIAL_SLOT" and not item.material_name


def _inspector_name_display_text(item, context=None):
    """Return the name shown for a row; rows without a real data name get a localized one."""
    if _inspector_is_empty_slot(item):
        return t("inspector_empty_slot", context).format(index=item.slot_index)
    name = item.edit_name or item.name
    if item.item_type == "SMART_METADATA" and (not name or name == item.owner_data):
        return _inspector_enum_label("owner_data", item.owner_data, context)
    return name


def _inspector_value_display_text(item, context=None):
    """Localize the value summary only while drawing it; value_text keeps the stored internal names."""
    stored = str(getattr(item, "value_text", "") or "")
    if item.item_type == "SMART_METADATA":
        key = TYPE_LABEL_KEY.get(item.data_type)
        number = f"{t('id_number', context)}={item.id_number}"
        return f"{t(key, context)} / {number}" if key else number
    if item.item_type in {"COLOR_ATTRIBUTE", "GEOMETRY_ATTRIBUTE"} and item.data_type:
        data_type = _inspector_enum_label("attr_type", item.data_type, context)
        return f"{data_type} / {_inspector_enum_label('attr_domain', item.domain, context)}"
    if stored in {"linked", "active", "uv"}:
        return t(f"inspector_value_{stored}", context)
    keys = _INSPECTOR_VALUE_KEYS_JA if is_japanese(context) else _INSPECTOR_VALUE_KEYS_EN
    return _INSPECTOR_VALUE_KEY_RE.sub(lambda m: f"{m.group(1)}{keys[m.group(2)]}=", stored)


def _inspector_details_display_text(item, context=None):
    """Localize an inspector detail only while drawing it."""
    stored = str(getattr(item, "details", "") or "")
    message_id = str(getattr(item, "details_message_id", "") or "")
    placeholder = _INSPECTOR_DETAIL_VALUE_PLACEHOLDERS.get(message_id)
    value = str(getattr(item, "details_message_value", "") or "")
    if message_id == "details_object_type":
        value = _inspector_enum_label("object_type", value, context)
    elif message_id == "details_smart_id_custom_props":
        value = _inspector_enum_label("owner_data", value, context)
    if not is_japanese(context):
        if message_id in {"details_object_type", "details_smart_id_custom_props"}:
            try:
                return UI_EN[message_id].format(**{placeholder: value})
            except Exception:
                return stored
        return stored
    if message_id not in _INSPECTOR_DETAIL_MESSAGE_IDS:
        return stored
    if placeholder is None and value:
        return stored
    template = UI_JA.get(message_id)
    if not template:
        return stored
    try:
        if placeholder is None:
            return template.format()
        return template.format(**{placeholder: value})
    except Exception:
        return stored


def inspector_add_item(collection, settings, item_type, *, owner_object="", owner_data="", material_name="", collection_name="", name="", edit_name=None, id_number=0, slot_index=-1, map_channel=0, color=None, active=False, render=False, data_type="", domain="", value_text="", details="", details_message_id="", details_message_value="", safe_to_delete=True, capacity_state=None):
    del settings  # Retained for compatibility with existing callers.
    if isinstance(capacity_state, dict):
        capacity_state["total"] = int(capacity_state.get("total", 0)) + 1
    if len(collection) >= _INSPECTOR_MAX_ITEMS:
        if isinstance(capacity_state, dict):
            capacity_state["omitted"] = int(capacity_state.get("omitted", 0)) + 1
        return None
    edit_name = name if edit_name is None else edit_name
    item = collection.add()
    item.uid = uuid.uuid4().hex
    item.item_type = item_type
    item.owner_object = owner_object or ""
    item.owner_data = owner_data or ""
    item.material_name = material_name or ""
    item.collection_name = collection_name or ""
    item.name = name or ""
    item.edit_name = edit_name or ""
    item.id_number = int(id_number or 0)
    item.slot_index = int(slot_index if slot_index is not None else -1)
    item.map_channel = int(map_channel or 0)
    if color:
        values = list(color)
        if len(values) == 3:
            values.append(1.0)
        item.color = tuple(float(v) for v in values[:4])
    item.active = bool(active)
    item.render = bool(render)
    item.data_type = str(data_type or "")
    item.domain = str(domain or "")
    item.value_text = str(value_text or "")
    item.details = str(details or "")
    item.details_message_id = str(details_message_id or "")
    item.details_message_value = str(details_message_value or "")
    item.safe_to_delete = bool(safe_to_delete)
    if isinstance(capacity_state, dict):
        capacity_state["stored"] = int(capacity_state.get("stored", 0)) + 1
    return item


def attribute_is_protected(attribute):
    name = getattr(attribute, "name", "")
    if str(name).startswith("."):
        return True
    if name in {"position", "normal", "id", "material_index"}:
        return True
    for attr_name in ("is_internal", "is_required"):
        try:
            if bool(getattr(attribute, attr_name)):
                return True
        except Exception:
            pass
    return False


def add_metadata_inspector_item(collection, settings, id_data, owner_object, owner_data, *, material_name="", capacity_state=None):
    summary = smart_props_summary(id_data)
    if not summary:
        return None
    try:
        etype = str(id_data.get(_prop_key("type"), ""))
        number = int(id_data.get(_prop_key("id_number"), 0))
        stored_name = str(id_data.get(_prop_key("name"), ""))
    except Exception:
        etype = ""
        number = 0
        stored_name = ""
    if stored_name == owner_data:
        stored_name = ""
    return inspector_add_item(
        collection,
        settings,
        "SMART_METADATA",
        owner_object=owner_object,
        owner_data=owner_data,
        material_name=material_name,
        name=stored_name,
        edit_name=stored_name,
        id_number=number,
        data_type=etype,
        value_text=summary,
        details=f"{owner_data} Smart ID custom properties",
        details_message_id="details_smart_id_custom_props",
        details_message_value=owner_data,
        safe_to_delete=True,
        capacity_state=capacity_state,
    )


def refresh_selection_inspector(context):
    scene = context.scene
    settings = get_settings(scene)
    items = get_inspector_items(scene)
    items.clear()
    capacity_state = {"total": 0, "stored": 0, "omitted": 0}

    for obj in inspector_objects(context):
        if not obj:
            continue
        inspector_add_item(
            items,
            settings,
            "OBJECT_ID",
            owner_object=obj.name,
            owner_data="OBJECT",
            name=obj.name,
            edit_name=obj.name,
            id_number=int(getattr(obj, "pass_index", 0)),
            color=tuple(getattr(obj, "color", (0.75, 0.75, 0.75, 1.0))),
            value_text=f"pass_index={int(getattr(obj, 'pass_index', 0))}",
            details=f"Object type: {obj.type}",
            details_message_id="details_object_type",
            details_message_value=obj.type,
            safe_to_delete=True,
            capacity_state=capacity_state,
        )
        add_metadata_inspector_item(
            items, settings, obj, obj.name, "OBJECT", capacity_state=capacity_state
        )

        if obj.type != "MESH" or not obj.data:
            for collection in getattr(obj, "users_collection", []):
                inspector_add_item(
                    items,
                    settings,
                    "SELECTION_SET",
                    owner_object=obj.name,
                    owner_data="COLLECTION",
                    collection_name=collection.name,
                    name=collection.name,
                    edit_name=collection.name,
                    active=True,
                    value_text="linked",
                    details="Object collection membership",
                    details_message_id="details_collection_membership",
                    safe_to_delete=True,
                    capacity_state=capacity_state,
                )
            continue

        mesh = obj.data
        for index, slot in enumerate(obj.material_slots):
            mat = slot.material
            mat_name = mat.name if mat else ""
            inspector_add_item(
                items,
                settings,
                "MATERIAL_ID",
                owner_object=obj.name,
                owner_data="MATERIAL_SLOT",
                material_name=mat_name,
                name=mat_name,
                edit_name=mat_name,
                id_number=int(getattr(mat, "pass_index", 0)) if mat else 0,
                slot_index=index,
                color=tuple(mat.diffuse_color) if mat else (0.75, 0.75, 0.75, 1.0),
                active=(index == obj.active_material_index),
                value_text=f"slot={index}, pass_index={int(getattr(mat, 'pass_index', 0)) if mat else 0}",
                details="Material slot assignment" if mat else "Empty material slot",
                details_message_id="details_material_slot_assignment" if mat else "details_empty_material_slot",
                safe_to_delete=True,
                capacity_state=capacity_state,
            )
            if mat:
                add_metadata_inspector_item(
                    items,
                    settings,
                    mat,
                    obj.name,
                    "MATERIAL",
                    material_name=mat.name,
                    capacity_state=capacity_state,
                )

        for uv in mesh.uv_layers:
            active = False
            try:
                active = mesh.uv_layers.active and mesh.uv_layers.active.name == uv.name
            except Exception:
                pass
            render = bool(getattr(uv, "active_render", False))
            map_channels = []
            prefix = _prop_key("map_channel_")
            for key in mesh.keys():
                if str(key).startswith(prefix):
                    try:
                        if str(mesh[key]) == uv.name:
                            map_channels.append(str(key)[len(prefix):])
                    except Exception:
                        pass
            inspector_add_item(
                items,
                settings,
                "UV_CHANNEL",
                owner_object=obj.name,
                owner_data="MESH_UV",
                name=uv.name,
                edit_name=uv.name,
                active=active,
                render=render,
                value_text="active" if active else "uv",
                details=("Map channels: " + ", ".join(map_channels)) if map_channels else "UV map",
                details_message_id="details_map_channels_prefix" if map_channels else "details_uv_map",
                details_message_value=", ".join(map_channels) if map_channels else "",
                safe_to_delete=True,
                capacity_state=capacity_state,
            )

        prefix = _prop_key("map_channel_")
        for key in mesh.keys():
            key_text = str(key)
            if not key_text.startswith(prefix):
                continue
            number_text = key_text[len(prefix):]
            try:
                channel_number = int(number_text)
            except Exception:
                channel_number = 0
            try:
                uv_name = str(mesh[key])
            except Exception:
                uv_name = ""
            uv_exists = bool(mesh.uv_layers.get(uv_name)) if uv_name else False
            inspector_add_item(
                items,
                settings,
                "MAP_CHANNEL",
                owner_object=obj.name,
                owner_data="MESH_METADATA",
                name=uv_name or f"MapChannel_{channel_number:02d}",
                edit_name=uv_name,
                id_number=channel_number,
                slot_index=channel_number,
                map_channel=channel_number,
                active=uv_exists,
                value_text=f"channel={channel_number}, uv={uv_name}",
                details="Map-channel metadata with existing UV" if uv_exists else "Map-channel metadata without matching UV",
                details_message_id="details_map_channel_with_uv" if uv_exists else "details_map_channel_without_uv",
                safe_to_delete=True,
                capacity_state=capacity_state,
            )

        for attr in mesh.color_attributes:
            active = False
            try:
                active = mesh.color_attributes.active_color and mesh.color_attributes.active_color.name == attr.name
            except Exception:
                pass
            inspector_add_item(
                items,
                settings,
                "COLOR_ATTRIBUTE",
                owner_object=obj.name,
                owner_data="MESH_COLOR_ATTRIBUTE",
                name=attr.name,
                edit_name=attr.name,
                active=active,
                data_type=getattr(attr, "data_type", ""),
                domain=getattr(attr, "domain", ""),
                value_text=f"{getattr(attr, 'data_type', '')} / {getattr(attr, 'domain', '')}",
                details="Color attribute",
                details_message_id="details_color_attribute",
                safe_to_delete=True,
                capacity_state=capacity_state,
            )

        for attr in mesh.attributes:
            # UV maps are attributes too; they already have their own UV_CHANNEL row.
            if mesh.color_attributes.get(attr.name) or mesh.uv_layers.get(attr.name):
                continue
            active = False
            try:
                active = mesh.attributes.active and mesh.attributes.active.name == attr.name
            except Exception:
                pass
            protected = attribute_is_protected(attr)
            inspector_add_item(
                items,
                settings,
                "GEOMETRY_ATTRIBUTE",
                owner_object=obj.name,
                owner_data="MESH_ATTRIBUTE",
                name=attr.name,
                edit_name=attr.name,
                active=active,
                data_type=getattr(attr, "data_type", ""),
                domain=getattr(attr, "domain", ""),
                value_text=f"{getattr(attr, 'data_type', '')} / {getattr(attr, 'domain', '')}",
                details="Protected geometry attribute" if protected else "Geometry attribute",
                details_message_id="details_protected_geometry_attribute" if protected else "details_geometry_attribute",
                safe_to_delete=not protected,
                capacity_state=capacity_state,
            )

        if mesh.get(_prop_key("udim_tile")) is not None:
            tile = int(mesh.get(_prop_key("udim_tile"), 1001))
            inspector_add_item(
                items,
                settings,
                "UDIM_TILE",
                owner_object=obj.name,
                owner_data="MESH_METADATA",
                name=f"UDIM_{tile}",
                edit_name=f"UDIM_{tile}",
                id_number=tile,
                value_text=f"tile={tile}",
                details="Smart ID Suite UDIM metadata",
                details_message_id="details_udim_metadata",
                safe_to_delete=True,
                capacity_state=capacity_state,
            )

        add_metadata_inspector_item(
            items, settings, mesh, obj.name, "MESH", capacity_state=capacity_state
        )

        for vg in obj.vertex_groups:
            active = False
            try:
                active = obj.vertex_groups.active and obj.vertex_groups.active.name == vg.name
            except Exception:
                pass
            inspector_add_item(
                items,
                settings,
                "WEIGHT_GROUP",
                owner_object=obj.name,
                owner_data="VERTEX_GROUP",
                name=vg.name,
                edit_name=vg.name,
                slot_index=vg.index,
                active=active,
                value_text=f"index={vg.index}",
                details="Vertex group",
                details_message_id="details_vertex_group",
                safe_to_delete=True,
                capacity_state=capacity_state,
            )

        for collection in getattr(obj, "users_collection", []):
            inspector_add_item(
                items,
                settings,
                "SELECTION_SET",
                owner_object=obj.name,
                owner_data="COLLECTION",
                collection_name=collection.name,
                name=collection.name,
                edit_name=collection.name,
                active=True,
                value_text="linked",
                details="Object collection membership",
                details_message_id="details_collection_membership",
                safe_to_delete=True,
                capacity_state=capacity_state,
            )

    total_count = int(capacity_state.get("total", len(items)))
    omitted_count = int(capacity_state.get("omitted", max(0, total_count - len(items))))
    try:
        scene.smart_id_inspector_total_count = total_count
        scene.smart_id_inspector_omitted_count = omitted_count
        scene.smart_id_inspector_truncated = omitted_count > 0
    except Exception:
        pass

    visible = visible_inspector_indices(scene)
    scene.smart_id_inspector_active_index = visible[0] if visible else (0 if items else -1)
    try:
        if bool(getattr(settings, "overlay_enabled", False)):
            schedule_overlay_snapshot_rebuild(scene)
    except Exception:
        pass
    if _smart_id_selection_runtime_requested(context, scene):
        signature = _primitive_selection_signature(context)
        if signature is not None:
            _remember_selection_signature(scene, signature)
            _remember_draw_selection_signature(scene, signature)
    return len(items)


def inspector_owner_object(item):
    return bpy.data.objects.get(item.owner_object) if item else None


def inspector_material(item):
    obj = inspector_owner_object(item)
    if obj and 0 <= item.slot_index < len(obj.material_slots):
        mat = obj.material_slots[item.slot_index].material
        if mat:
            return mat
    if item.material_name:
        return bpy.data.materials.get(item.material_name)
    return None


def inspector_owner_id_data(item):
    obj = inspector_owner_object(item)
    if item.owner_data == "OBJECT":
        return obj
    if item.owner_data in {"MESH", "MESH_METADATA", "MESH_UV", "MESH_COLOR_ATTRIBUTE", "MESH_ATTRIBUTE"}:
        return obj.data if obj and obj.type == "MESH" else None
    if item.owner_data == "MATERIAL":
        return inspector_material(item)
    if item.owner_data == "COLLECTION":
        return bpy.data.collections.get(item.collection_name or item.name)
    return None


def _set_active_uv(mesh, layer):
    try:
        mesh.uv_layers.active = layer
    except Exception:
        pass
    try:
        mesh.uv_layers.active_index = list(mesh.uv_layers).index(layer)
    except Exception:
        pass


def _set_active_color_attribute(mesh, attribute):
    try:
        mesh.color_attributes.active = attribute
        mesh.color_attributes.active_color = attribute
    except Exception:
        pass


def _set_active_geometry_attribute(mesh, attribute):
    try:
        mesh.attributes.active = attribute
    except Exception:
        pass


def apply_inspector_item(context, item, source_entry=None):
    if not item:
        return 0
    settings = get_settings(context.scene)
    obj = inspector_owner_object(item)
    new_name = (item.edit_name or item.name or "").strip()
    changed = 0

    if item.item_type == "OBJECT_ID":
        if not obj:
            return 0
        if new_name and new_name != obj.name:
            obj.name = new_name
            item.owner_object = obj.name
        try:
            obj.pass_index = clamp_pass_index(item.id_number)
        except Exception:
            pass
        try:
            obj.color = tuple(item.color)
        except Exception:
            pass
        if settings.write_custom_props:
            if source_entry is not None:
                write_id_custom_props(obj, source_entry, "object")
            else:
                write_custom_props_from_inspector(obj, item, "object", "OBJECT_ID")
        return 1

    if item.item_type == "MATERIAL_ID":
        if not obj or obj.type != "MESH":
            return 0
        mat = inspector_material(item)
        if mat is None:
            mat = bpy.data.materials.new(new_name or default_entry_name("MATERIAL_ID", item.id_number or next_id(context.scene, "MATERIAL_ID"), settings.naming_profile))
        if mat is None:
            return 0
        if new_name:
            mat.name = new_name
        try:
            mat.pass_index = clamp_pass_index(item.id_number)
        except Exception:
            pass
        try:
            mat.diffuse_color = tuple(item.color)
        except Exception:
            pass
        if 0 <= item.slot_index < len(obj.material_slots):
            obj.material_slots[item.slot_index].material = mat
            if item.active:
                obj.active_material_index = item.slot_index
        elif mat.name not in [m.name for m in obj.data.materials if m]:
            obj.data.materials.append(mat)
        if settings.write_custom_props:
            if source_entry is not None:
                write_id_custom_props(mat, source_entry, "material")
            else:
                write_custom_props_from_inspector(mat, item, "material", "MATERIAL_ID")
        return 1

    if not obj or obj.type != "MESH" or not obj.data:
        if item.item_type == "SELECTION_SET":
            collection = bpy.data.collections.get(item.collection_name or item.name)
            if collection and new_name and collection.name != new_name:
                collection.name = new_name
                item.collection_name = collection.name
                return 1
        return 0

    mesh = obj.data

    if item.item_type == "UV_CHANNEL":
        layer = mesh.uv_layers.get(item.name) or mesh.uv_layers.get(new_name)
        if layer is None and new_name:
            layer = mesh.uv_layers.new(name=new_name)
        if layer is None:
            return 0
        old_name = layer.name
        if new_name:
            layer.name = new_name
        if item.active:
            _set_active_uv(mesh, layer)
        if item.render:
            try:
                layer.active_render = True
            except Exception:
                pass
        for key in list(mesh.keys()):
            if str(key).startswith(_prop_key("map_channel_")):
                try:
                    if str(mesh[key]) == old_name:
                        mesh[key] = layer.name
                except Exception:
                    pass
        if item.map_channel > 0:
            mesh[_prop_key(f"map_channel_{item.map_channel}")] = layer.name
        if source_entry is not None and settings.write_custom_props:
            write_id_custom_props(mesh, source_entry, "uv_channel")
        return 1

    if item.item_type == "MAP_CHANNEL":
        channel = int(item.map_channel or item.id_number or item.slot_index or 1)
        if item.slot_index > 0 and item.slot_index != channel:
            old_key = _prop_key(f"map_channel_{item.slot_index}")
            if mesh.get(old_key) is not None:
                try:
                    del mesh[old_key]
                except Exception:
                    pass
        channel_name = new_name or item.name or profile_channel_name("MAP_CHANNEL", channel, settings.naming_profile)
        mesh[_prop_key(f"map_channel_{channel}")] = channel_name
        layer = mesh.uv_layers.get(channel_name)
        if layer is None:
            layer = mesh.uv_layers.new(name=channel_name)
        if item.active:
            _set_active_uv(mesh, layer)
        if item.render:
            try:
                layer.active_render = True
            except Exception:
                pass
        item.map_channel = channel
        item.id_number = channel
        if source_entry is not None and settings.write_custom_props:
            write_id_custom_props(mesh, source_entry, "map_channel")
        return 1

    if item.item_type == "COLOR_ATTRIBUTE":
        attr = mesh.color_attributes.get(item.name) or mesh.color_attributes.get(new_name)
        if attr is None and new_name:
            domain = item.domain if item.domain in {"POINT", "CORNER"} else "CORNER"
            attr = ensure_color_attribute(obj, new_name, domain=domain)
        if attr is None:
            return 0
        if new_name:
            attr.name = new_name
        if item.active:
            _set_active_color_attribute(mesh, attr)
        if source_entry is not None and settings.write_custom_props:
            write_id_custom_props(mesh, source_entry, "color_attribute")
        return 1

    if item.item_type == "GEOMETRY_ATTRIBUTE":
        attr = mesh.attributes.get(item.name) or mesh.attributes.get(new_name)
        if attr is None and new_name:
            data_type = item.data_type if item.data_type in {x[0] for x in ATTRIBUTE_TYPE_ITEMS} else "FLOAT"
            domain = item.domain if item.domain in {x[0] for x in ATTRIBUTE_DOMAIN_ITEMS} else "POINT"
            attr = ensure_geometry_attribute(obj, new_name, data_type, domain)
        if attr is None:
            return 0
        if new_name and not attribute_is_protected(attr):
            try:
                attr.name = new_name
            except Exception:
                pass
        if item.active:
            _set_active_geometry_attribute(mesh, attr)
        if source_entry is not None and settings.write_custom_props:
            write_id_custom_props(mesh, source_entry, "geometry_attribute")
        return 1

    if item.item_type == "WEIGHT_GROUP":
        group = obj.vertex_groups.get(item.name) or obj.vertex_groups.get(new_name)
        if group is None and new_name:
            group = obj.vertex_groups.new(name=new_name)
        if group is None:
            return 0
        if new_name:
            group.name = new_name
        if item.active:
            try:
                obj.vertex_groups.active_index = group.index
            except Exception:
                pass
        if source_entry is not None and settings.write_custom_props:
            write_id_custom_props(obj, source_entry, "weight_group")
        return 1

    if item.item_type == "SELECTION_SET":
        collection = bpy.data.collections.get(item.collection_name or item.name)
        if collection is None and new_name:
            collection = bpy.data.collections.new(new_name)
            context.scene.collection.children.link(collection)
        if collection is None:
            return 0
        if new_name and collection.name != new_name:
            collection.name = new_name
        if item.active:
            if obj.name not in collection.objects:
                try:
                    collection.objects.link(obj)
                except RuntimeError:
                    pass
        else:
            try:
                collection.objects.unlink(obj)
            except Exception:
                pass
        item.collection_name = collection.name
        if source_entry is not None and settings.write_custom_props:
            write_id_custom_props(obj, source_entry, "selection_set")
        return 1

    if item.item_type == "UDIM_TILE":
        tile = int(item.id_number or 1001)
        mesh[_prop_key("udim_tile")] = tile
        if source_entry is not None and settings.write_custom_props:
            write_id_custom_props(mesh, source_entry, "udim_tile")
        return 1

    if item.item_type == "SMART_METADATA":
        id_data = inspector_owner_id_data(item)
        if id_data is None:
            return 0
        write_custom_props_from_inspector(id_data, item, item.owner_data.lower() or "custom", item.data_type if item.data_type in TYPE_ORDER else "CUSTOM_ID")
        return 1

    return changed


def delete_inspector_item(context, item):
    if not item or not item.safe_to_delete:
        return 0
    obj = inspector_owner_object(item)
    if item.item_type == "OBJECT_ID":
        if not obj:
            return 0
        try:
            obj.pass_index = 0
        except Exception:
            pass
        clear_smart_props(obj)
        return 1

    if item.item_type == "MATERIAL_ID":
        if obj and 0 <= item.slot_index < len(obj.material_slots):
            obj.material_slots[item.slot_index].material = None
            return 1
        return 0

    if item.item_type == "SMART_METADATA":
        id_data = inspector_owner_id_data(item)
        return 1 if id_data is not None and clear_smart_props(id_data) else 0

    if item.item_type == "SELECTION_SET":
        collection = bpy.data.collections.get(item.collection_name or item.name)
        if collection and obj:
            try:
                collection.objects.unlink(obj)
                return 1
            except Exception:
                return 0
        return 0

    if not obj or obj.type != "MESH" or not obj.data:
        return 0
    mesh = obj.data

    if item.item_type == "UV_CHANNEL":
        return int(remove_uv_layer(obj, item.name) or remove_uv_layer(obj, item.edit_name))
    if item.item_type == "MAP_CHANNEL":
        removed = 0
        for channel in {item.slot_index, item.map_channel, item.id_number}:
            if channel is None or int(channel) <= 0:
                continue
            key = _prop_key(f"map_channel_{int(channel)}")
            if mesh.get(key) is not None:
                try:
                    del mesh[key]
                    removed += 1
                except Exception:
                    pass
        return removed
    if item.item_type == "COLOR_ATTRIBUTE":
        return int(remove_color_attribute(obj, item.name) or remove_color_attribute(obj, item.edit_name))
    if item.item_type == "GEOMETRY_ATTRIBUTE":
        attr = mesh.attributes.get(item.name) or mesh.attributes.get(item.edit_name)
        if attr and attribute_is_protected(attr):
            return 0
        return int(remove_geometry_attribute(obj, item.name) or remove_geometry_attribute(obj, item.edit_name))
    if item.item_type == "WEIGHT_GROUP":
        group = obj.vertex_groups.get(item.name) or obj.vertex_groups.get(item.edit_name)
        if group:
            obj.vertex_groups.remove(group)
            return 1
        return 0
    if item.item_type == "UDIM_TILE":
        key = _prop_key("udim_tile")
        if mesh.get(key) is not None:
            del mesh[key]
            return 1
        return 0
    return 0


def configure_entry_from_inspector_item(entry, item, settings):
    entry_type = item.item_type if item.item_type in TYPE_ORDER else "CUSTOM_ID"
    if item.item_type == "SMART_METADATA" and item.data_type in TYPE_ORDER:
        entry_type = item.data_type
    entry.type = entry_type
    entry.name = item.edit_name or item.name or default_entry_name(entry_type, item.id_number or next_id(bpy.context.scene, entry_type), settings.naming_profile)
    entry.id_number = int(item.id_number) if int(item.id_number) > 0 else next_id(bpy.context.scene, entry_type)
    entry.color = tuple(item.color)
    if entry_type == "MAP_CHANNEL":
        entry.map_channel = max(1, int(item.map_channel or item.id_number or 1))
        entry.channel_name = item.edit_name or item.name
        entry.uv_map = item.edit_name or item.name
    elif entry_type == "UV_CHANNEL":
        entry.uv_map = item.edit_name or item.name
        entry.channel_name = item.edit_name or item.name
    elif entry_type == "COLOR_ATTRIBUTE":
        entry.color_attribute = item.edit_name or item.name
        entry.channel_name = item.edit_name or item.name
        if item.domain in {x[0] for x in ATTRIBUTE_DOMAIN_ITEMS}:
            entry.attribute_domain = item.domain
    elif entry_type == "GEOMETRY_ATTRIBUTE":
        entry.attribute_name = item.edit_name or item.name
        entry.channel_name = item.edit_name or item.name
        if item.data_type in {x[0] for x in ATTRIBUTE_TYPE_ITEMS}:
            entry.attribute_type = item.data_type
        if item.domain in {x[0] for x in ATTRIBUTE_DOMAIN_ITEMS}:
            entry.attribute_domain = item.domain
    elif entry_type in {"WEIGHT_GROUP", "SELECTION_SET"}:
        entry.group_name = item.edit_name or item.name
        entry.channel_name = item.edit_name or item.name
    elif entry_type == "UDIM_TILE":
        entry.udim_tile = max(1001, int(item.id_number or 1001))
        entry.channel_name = item.edit_name or item.name
    else:
        entry.channel_name = item.edit_name or item.name
    entry.notes = t("entry_notes_from_inspector").format(owner=item.owner_object, data=_inspector_enum_label("owner_data", item.owner_data))
    return entry


def create_entry_from_inspector_item(context, item):
    if not item:
        return None, False
    scene = context.scene
    settings = get_settings(scene)
    entry_type = item.item_type if item.item_type in TYPE_ORDER else "CUSTOM_ID"
    if item.item_type == "SMART_METADATA" and item.data_type in TYPE_ORDER:
        entry_type = item.data_type
    channel_name = item.edit_name or item.name
    existing = None
    if entry_type in {"OBJECT_ID", "MATERIAL_ID", "UDIM_TILE"} and item.id_number > 0:
        existing = find_entry(scene, entry_type, id_number=item.id_number)
    if existing is None and channel_name:
        existing = find_entry(scene, entry_type, channel_name=channel_name)
    if existing:
        configure_entry_from_inspector_item(existing, item, settings)
        for index, entry in enumerate(get_entries(scene)):
            if entry.uid == existing.uid:
                scene.smart_id_active_index = index
                break
        return existing, False
    entry = get_entries(scene).add()
    entry.uid = uuid.uuid4().hex
    configure_entry_from_inspector_item(entry, item, settings)
    scene.smart_id_active_index = len(get_entries(scene)) - 1
    return entry, True


def inspector_entry_compatible(entry, item):
    if not entry or not item:
        return False
    if item.item_type == "SMART_METADATA":
        return True
    if item.item_type == entry.type:
        return True
    if item.item_type in {"UV_CHANNEL", "MAP_CHANNEL"} and entry.type in {"UV_CHANNEL", "MAP_CHANNEL"}:
        return True
    return False


def apply_active_entry_to_inspector_item(context, item, entry):
    if not inspector_entry_compatible(entry, item):
        return 0
    settings = get_settings(context.scene)
    item.id_number = int(entry.udim_tile if entry.type == "UDIM_TILE" else entry.id_number)
    item.color = tuple(entry.color)
    if entry.type == "MAP_CHANNEL":
        item.map_channel = max(1, int(entry.map_channel))
        item.edit_name = resolve_channel_name(entry, settings)
    elif entry.type == "UDIM_TILE":
        item.edit_name = f"UDIM_{entry.udim_tile}"
    elif entry.type in {"UV_CHANNEL", "COLOR_ATTRIBUTE", "GEOMETRY_ATTRIBUTE", "WEIGHT_GROUP", "SELECTION_SET"}:
        item.edit_name = resolve_channel_name(entry, settings)
    else:
        item.edit_name = entry.name
    if item.item_type == "SMART_METADATA":
        id_data = inspector_owner_id_data(item)
        if id_data is None:
            return 0
        write_id_custom_props(id_data, entry, item.owner_data.lower() or "custom")
        return 1
    return apply_inspector_item(context, item, source_entry=entry)

def find_entry(scene, entry_type, *, id_number=None, name=None, channel_name=None, uid=None):
    for entry in get_entries(scene):
        if entry.type != entry_type:
            continue
        if uid and entry.uid == uid:
            return entry
        if id_number is not None and entry.id_number == id_number:
            return entry
        if name and entry.name == name:
            return entry
        if channel_name and resolve_channel_name(entry, get_settings(scene)) == channel_name:
            return entry
    return None


_REGISTRY_SCHEMA = "smart_id_suite.registry.v1"
_REGISTRY_VERSION = "0.6.20"
_REGISTRY_PAYLOAD_TYPE = "smart_id_suite.registry"
_REGISTRY_COMPATIBLE_VERSIONS = frozenset({"0.6.10", "0.6.11", "0.6.12", "0.6.13", "0.6.14", "0.6.15", "0.6.16", "0.6.17", "0.6.18", _REGISTRY_VERSION})
_REGISTRY_TEXT_LIMIT = 65535
_REGISTRY_ENTRY_FIELDS = frozenset({
    "uid", "enabled", "locked", "type", "name", "id_number", "color",
    "map_channel", "channel_name", "uv_map", "color_attribute",
    "attribute_name", "attribute_type", "attribute_domain", "group_name",
    "material_name", "udim_tile", "export_tag", "notes",
})
_REGISTRY_ROOT_FIELDS = frozenset({
    "schema", "version", "type", "addon", "author", "license",
    "copyright", "blender_version_min", "entries",
})
_REGISTRY_REQUIRED_ROOT_FIELDS = frozenset({"schema", "version", "type", "entries"})
_REGISTRY_OPTIONAL_TEXT_ROOT_FIELDS = frozenset({
    "addon", "author", "license", "copyright", "blender_version_min",
})
_REGISTRY_REQUIRED_ENTRY_FIELDS = _REGISTRY_ENTRY_FIELDS


def entry_to_dict(entry):
    return {
        "uid": entry.uid,
        "enabled": bool(entry.enabled),
        "locked": bool(entry.locked),
        "type": entry.type,
        "name": entry.name,
        "id_number": int(entry.id_number),
        "color": [float(v) for v in entry.color],
        "map_channel": int(entry.map_channel),
        "channel_name": entry.channel_name,
        "uv_map": entry.uv_map,
        "color_attribute": entry.color_attribute,
        "attribute_name": entry.attribute_name,
        "attribute_type": entry.attribute_type,
        "attribute_domain": entry.attribute_domain,
        "group_name": entry.group_name,
        "material_name": entry.material_name,
        "udim_tile": int(entry.udim_tile),
        "export_tag": entry.export_tag,
        "notes": entry.notes,
    }


class _RegistryValidationIssue(_LocalizedMessageError):
    """Registry import failure retained as a message ID until display."""
    pass


def _render_validation_issue(issue, context=None):
    if isinstance(issue, _LocalizedMessageError):
        return issue.render(UI_JA if is_japanese(context) else UI_EN)
    return str(issue)


def _render_strict_json_error(error, context=None):
    # Interpreter exception text is never shown; every failure gets a localized sentence.
    if isinstance(error, _StrictJSONError):
        return error.render(UI_JA if is_japanese(context) else UI_EN)
    if isinstance(error, json.JSONDecodeError):
        return t("report_error_bad_json", context).format(line=error.lineno)
    if isinstance(error, UnicodeError):
        return t("report_error_not_utf8", context)
    if isinstance(error, PermissionError):
        return t("report_error_access_denied", context)
    if isinstance(error, FileNotFoundError):
        return t("report_error_file_not_found", context)
    if isinstance(error, OSError):
        return t("report_error_file_io", context)
    return t("report_error_unexpected", context)


def _strict_bool(data, name, default):
    value = data.get(name, default)
    if type(value) is not bool:
        raise _RegistryValidationIssue("msg_json_val_field_boolean", name=name)
    return value


def _strict_int(data, name, default, minimum, maximum):
    value = data.get(name, default)
    if type(value) is not int:
        raise _RegistryValidationIssue("msg_json_val_field_integer", name=name)
    if value < int(minimum) or value > int(maximum):
        raise _RegistryValidationIssue(
            "msg_json_val_field_range", name=name, minimum=minimum, maximum=maximum
        )
    return value


def _strict_text(data, name, default="", *, required=False):
    if required and name not in data:
        raise _RegistryValidationIssue("msg_json_val_field_required", name=name)
    value = data.get(name, default)
    if type(value) is not str:
        raise _RegistryValidationIssue("msg_json_val_field_string", name=name)
    if len(value) > _REGISTRY_TEXT_LIMIT:
        raise _RegistryValidationIssue("msg_json_val_field_too_long", name=name)
    return value


def _strict_enum(data, name, default, identifiers, *, required=False):
    value = _strict_text(data, name, default, required=required)
    if value not in identifiers:
        raise _RegistryValidationIssue(
            "msg_json_val_field_unsupported", name=name, value=value
        )
    return value


def _strict_color(data):
    value = data.get("color", [0.75, 0.75, 0.75, 1.0])
    if type(value) not in {list, tuple} or len(value) not in {3, 4}:
        raise _RegistryValidationIssue("msg_json_val_color_shape")
    normalized = []
    for component in value:
        if isinstance(component, bool) or not isinstance(component, (int, float)):
            raise _RegistryValidationIssue("msg_json_val_color_number")
        number = float(component)
        if not math.isfinite(number) or number < 0.0 or number > 1.0:
            raise _RegistryValidationIssue("msg_json_val_color_range")
        normalized.append(number)
    if len(normalized) == 3:
        normalized.append(1.0)
    return normalized


def _strict_uid(data):
    raw = _strict_text(data, "uid", required=True).strip()
    try:
        parsed = uuid.UUID(raw)
    except Exception as exc:
        raise _RegistryValidationIssue("msg_json_val_uid_uuid") from exc
    if parsed.int == 0:
        raise _RegistryValidationIssue("msg_json_val_uid_nil")
    return parsed.hex


def _validate_registry_entry_payload(data, row_number):
    if type(data) is not dict:
        return None, _RegistryValidationIssue(
            "msg_json_val_row_entry_object", row_number=row_number
        )
    unknown_members = sorted(set(data) - _REGISTRY_ENTRY_FIELDS)
    if unknown_members:
        return None, _RegistryValidationIssue(
            "msg_json_val_row_unknown_members",
            row_number=row_number,
            members=", ".join(unknown_members),
        )
    missing_members = sorted(_REGISTRY_REQUIRED_ENTRY_FIELDS - set(data))
    if missing_members:
        return None, _RegistryValidationIssue(
            "msg_json_val_row_missing_members",
            row_number=row_number,
            members=", ".join(missing_members),
        )
    try:
        entry_type = _strict_enum(data, "type", "OBJECT_ID", frozenset(TYPE_ORDER), required=True)
        id_number = _strict_int(data, "id_number", 1, 0, 2147483647)
        default_map_channel = max(1, min(999, id_number if id_number > 0 else 1))
        normalized = {
            "uid": _strict_uid(data),
            "enabled": _strict_bool(data, "enabled", True),
            "locked": _strict_bool(data, "locked", False),
            "type": entry_type,
            "name": _strict_text(data, "name", "ID Entry", required=True),
            "id_number": id_number,
            "color": _strict_color(data),
            "map_channel": _strict_int(data, "map_channel", default_map_channel, 1, 999),
            "channel_name": _strict_text(data, "channel_name"),
            "uv_map": _strict_text(data, "uv_map"),
            "color_attribute": _strict_text(data, "color_attribute"),
            "attribute_name": _strict_text(data, "attribute_name"),
            "attribute_type": _strict_enum(
                data, "attribute_type", "FLOAT", frozenset(item[0] for item in ATTRIBUTE_TYPE_ITEMS)
            ),
            "attribute_domain": _strict_enum(
                data, "attribute_domain", "POINT", frozenset(item[0] for item in ATTRIBUTE_DOMAIN_ITEMS)
            ),
            "group_name": _strict_text(data, "group_name"),
            "material_name": _strict_text(data, "material_name"),
            "udim_tile": _strict_int(data, "udim_tile", 1001, 1001, 9999),
            "export_tag": _strict_text(data, "export_tag"),
            "notes": _strict_text(data, "notes"),
        }
    except _RegistryValidationIssue as issue:
        return None, _RegistryValidationIssue(
            "msg_json_val_row_detail", row_number=row_number, detail=issue
        )
    except (TypeError, ValueError):
        return None, _RegistryValidationIssue(
            "msg_json_val_row_detail", row_number=row_number, detail=t("report_invalid_value")
        )
    return normalized, ""


def _validate_registry_import_payload(payload, existing_uids, *, clear_existing):
    if type(payload) is not dict:
        return None, [_RegistryValidationIssue("msg_json_val_root_object")]

    unknown_root = sorted(set(payload) - _REGISTRY_ROOT_FIELDS)
    if unknown_root:
        return None, [_RegistryValidationIssue(
            "msg_json_val_root_unknown_members", members=", ".join(unknown_root)
        )]
    missing_root = sorted(_REGISTRY_REQUIRED_ROOT_FIELDS - set(payload))
    if missing_root:
        return None, [_RegistryValidationIssue(
            "msg_json_val_root_missing_members", members=", ".join(missing_root)
        )]

    if type(payload.get("schema")) is not str or payload.get("schema") != _REGISTRY_SCHEMA:
        return None, [_RegistryValidationIssue("msg_json_val_schema_mismatch")]

    version = payload.get("version")
    if type(version) is not str or version not in _REGISTRY_COMPATIBLE_VERSIONS:
        return None, [_RegistryValidationIssue("msg_json_val_version_mismatch")]

    payload_type = payload.get("type")
    if type(payload_type) is not str or payload_type != _REGISTRY_PAYLOAD_TYPE:
        return None, [_RegistryValidationIssue("msg_json_val_payload_type_mismatch")]

    for member in _REGISTRY_OPTIONAL_TEXT_ROOT_FIELDS:
        if member in payload and type(payload.get(member)) is not str:
            return None, [_RegistryValidationIssue(
                "msg_json_val_root_member_string", member=member
            )]

    data = payload.get("entries")
    if type(data) is not list:
        return None, [_RegistryValidationIssue("msg_json_val_entries_list")]

    valid_entries = []
    errors = []
    seen_uids = set()
    if not clear_existing:
        for value in existing_uids:
            raw_uid = str(value or "").strip()
            if not raw_uid:
                continue
            seen_uids.add(raw_uid)
            try:
                seen_uids.add(uuid.UUID(raw_uid).hex)
            except Exception:
                pass
    for row_number, item in enumerate(data, 1):
        normalized, error = _validate_registry_entry_payload(item, row_number)
        if normalized is None:
            errors.append(error)
            continue
        uid_value = normalized["uid"]
        if uid_value in seen_uids:
            errors.append(_RegistryValidationIssue(
                "msg_json_val_row_duplicate_uid",
                row_number=row_number,
                uid_value=uid_value,
            ))
            continue
        seen_uids.add(uid_value)
        valid_entries.append(normalized)
    if not valid_entries:
        errors.append(_RegistryValidationIssue("msg_json_val_no_valid_entries"))
    if errors:
        return None, errors
    return valid_entries, []


def entry_from_dict(entry, data):
    uid_value = data.get("uid")
    entry.uid = str(uid_value) if type(uid_value) is str and uid_value else uuid.uuid4().hex
    enabled = data.get("enabled", True)
    locked = data.get("locked", False)
    entry.enabled = enabled if type(enabled) is bool else True
    entry.locked = locked if type(locked) is bool else False
    entry_type = data.get("type", "OBJECT_ID")
    entry.type = entry_type if entry_type in TYPE_ORDER else "CUSTOM_ID"
    name = data.get("name", "ID Entry")
    entry.name = name if type(name) is str else "ID Entry"
    entry.id_number = int(data.get("id_number", 1))
    color = data.get("color", (0.75, 0.75, 0.75, 1.0))
    if len(color) == 3:
        color = list(color) + [1.0]
    entry.color = tuple(float(v) for v in color[:4])
    entry.map_channel = int(data.get("map_channel", max(1, min(999, entry.id_number or 1))))
    entry.channel_name = data.get("channel_name", "")
    entry.uv_map = data.get("uv_map", "")
    entry.color_attribute = data.get("color_attribute", "")
    entry.attribute_name = data.get("attribute_name", "")
    attribute_type = data.get("attribute_type", "FLOAT")
    entry.attribute_type = attribute_type if attribute_type in {x[0] for x in ATTRIBUTE_TYPE_ITEMS} else "FLOAT"
    attribute_domain = data.get("attribute_domain", "POINT")
    entry.attribute_domain = attribute_domain if attribute_domain in {x[0] for x in ATTRIBUTE_DOMAIN_ITEMS} else "POINT"
    entry.group_name = data.get("group_name", "")
    entry.material_name = data.get("material_name", "")
    entry.udim_tile = int(data.get("udim_tile", 1001))
    entry.export_tag = data.get("export_tag", "")
    entry.notes = data.get("notes", "")


_REGISTRY_TRANSIENT_COUNT_FIELDS = (
    "count_objects",
    "count_materials",
    "count_channels",
    "count_selected_objects",
    "count_selected_materials",
    "count_selected_channels",
)


def _registry_entry_snapshot(entry):
    data = entry_to_dict(entry)
    data["_selected"] = bool(getattr(entry, "selected", False))
    for name in _REGISTRY_TRANSIENT_COUNT_FIELDS:
        try:
            data[f"_{name}"] = int(getattr(entry, name, 0))
        except Exception:
            data[f"_{name}"] = 0
    return data


def _restore_registry_snapshot(entries, snapshot):
    entries.clear()
    for data in snapshot:
        entry = entries.add()
        entry_from_dict(entry, data)
        entry.selected = bool(data.get("_selected", False))
        for name in _REGISTRY_TRANSIENT_COUNT_FIELDS:
            try:
                setattr(entry, name, int(data.get(f"_{name}", 0)))
            except Exception:
                pass


_REGISTRY_IMPORT_FAULT_HOOK = None


def _registry_import_fault(phase):
    hook = _REGISTRY_IMPORT_FAULT_HOOK
    if callable(hook):
        hook(str(phase))


def _registry_import_snapshot_from_validated(data):
    snapshot = dict(data)
    snapshot["_selected"] = False
    for name in _REGISTRY_TRANSIENT_COUNT_FIELDS:
        snapshot[f"_{name}"] = 0
    return snapshot


def _registry_snapshot_canonical(snapshot):
    result = []
    for data in snapshot:
        item = {name: data[name] for name in _REGISTRY_ENTRY_FIELDS}
        item["color"] = [float(value) for value in item["color"]]
        item["_selected"] = bool(data.get("_selected", False))
        for name in _REGISTRY_TRANSIENT_COUNT_FIELDS:
            item[f"_{name}"] = int(data.get(f"_{name}", 0))
        result.append(item)
    return result


def _populate_registry_collection(collection, target_snapshot):
    """Build a complete inactive registry bank before the atomic bank flip."""
    _registry_import_fault("before_stage_clear")
    collection.clear()
    _registry_import_fault("after_stage_clear")
    for row_number, data in enumerate(target_snapshot, 1):
        _registry_import_fault(f"before_stage_add:{row_number}")
        entry = collection.add()
        entry_from_dict(entry, data)
        entry.selected = bool(data.get("_selected", False))
        for name in _REGISTRY_TRANSIENT_COUNT_FIELDS:
            setattr(entry, name, int(data.get(f"_{name}", 0)))
        _registry_import_fault(f"after_stage_add:{row_number}")
    measured = [_registry_entry_snapshot(entry) for entry in collection]
    if _registry_snapshot_canonical(measured) != _registry_snapshot_canonical(target_snapshot):
        raise RuntimeError("staged registry verification mismatch")
    _registry_import_fault("after_stage_verify")


def _commit_registry_import_atomic(scene, validated, *, clear_existing):
    """Return (committed, imported_count, error) without mutating the active bank on failure.

    The complete target is written to the inactive CollectionProperty.  The only
    commit primitive is one Scene IDProperty integer assignment selecting that
    completed bank.  Cleanup of a failed staging bank is best effort and cannot
    affect the active registry, even when cleanup itself is fault-injected.
    """
    active_bank = _registry_active_bank(scene)
    inactive_bank = 1 - active_bank
    active_entries = _registry_collection_for_bank(scene, active_bank)
    inactive_entries = _registry_collection_for_bank(scene, inactive_bank)
    original_snapshot = [_registry_entry_snapshot(entry) for entry in active_entries]
    imported_snapshot = [_registry_import_snapshot_from_validated(item) for item in validated]
    target_snapshot = imported_snapshot if clear_existing else original_snapshot + imported_snapshot

    try:
        _populate_registry_collection(inactive_entries, target_snapshot)
        _registry_import_fault("before_atomic_flip")
    except Exception:
        try:
            _registry_import_fault("before_failed_stage_cleanup")
            inactive_entries.clear()
            _registry_import_fault("after_failed_stage_cleanup")
        except Exception:
            # The inactive bank may retain partial staging rows.  It is not the
            # selected registry and will be cleared before the next transaction.
            pass
        return False, 0, t("report_import_stage_failed")

    try:
        scene[_REGISTRY_BANK_IDPROP] = int(inactive_bank)
    except Exception:
        # Treat an assignment that became visible as committed; never return
        # CANCELLED after the active bank has changed.
        if _registry_active_bank(scene) == inactive_bank:
            return True, len(imported_snapshot), t("report_import_commit_warning")
        try:
            _registry_import_fault("before_failed_commit_cleanup")
            inactive_entries.clear()
            _registry_import_fault("after_failed_commit_cleanup")
        except Exception:
            pass
        return False, 0, t("report_import_commit_failed")

    if _registry_active_bank(scene) != inactive_bank:
        return False, 0, t("report_import_commit_failed")
    return True, len(imported_snapshot), ""



def ensure_uv_layer(obj, name):
    mesh = obj.data
    layer = mesh.uv_layers.get(name)
    if layer is None:
        layer = mesh.uv_layers.new(name=name)
    mesh.uv_layers.active = layer
    try:
        mesh.uv_layers.active_index = list(mesh.uv_layers).index(layer)
    except Exception:
        pass
    try:
        layer.active_render = True
    except Exception:
        pass
    return layer


def remove_uv_layer(obj, name):
    mesh = obj.data
    layer = mesh.uv_layers.get(name)
    if layer:
        mesh.uv_layers.remove(layer)
        return True
    return False


def ensure_color_attribute(obj, name, domain="CORNER"):
    mesh = obj.data
    color_attribute = mesh.color_attributes.get(name)
    if color_attribute is None:
        color_attribute = mesh.color_attributes.new(name=name, type="BYTE_COLOR", domain=domain if domain in {"POINT", "CORNER"} else "CORNER")
    try:
        mesh.color_attributes.active = color_attribute
        mesh.color_attributes.active_color = color_attribute
    except Exception:
        pass
    return color_attribute


def remove_color_attribute(obj, name):
    mesh = obj.data
    attribute = mesh.color_attributes.get(name)
    if attribute:
        mesh.color_attributes.remove(attribute)
        return True
    return False


def ensure_geometry_attribute(obj, name, data_type="FLOAT", domain="POINT"):
    mesh = obj.data
    attr = mesh.attributes.get(name)
    if attr is None:
        try:
            attr = mesh.attributes.new(name=name, type=data_type, domain=domain)
        except TypeError:
            attr = mesh.attributes.new(name=name, type="FLOAT", domain="POINT")
        except RuntimeError:
            attr = mesh.attributes.new(name=name, type="FLOAT", domain="POINT")
    return attr


def remove_geometry_attribute(obj, name):
    mesh = obj.data
    attr = mesh.attributes.get(name)
    if attr:
        try:
            mesh.attributes.remove(attr)
            return True
        except RuntimeError:
            return False
    return False


def ensure_vertex_group(obj, name):
    group = obj.vertex_groups.get(name)
    if group is None:
        group = obj.vertex_groups.new(name=name)
    return group


def ensure_id_material(entry):
    mat_name = safe_name(entry.name or f"Material_ID_{entry.id_number}")
    if not mat_name.startswith("SIS_"):
        mat_name = f"SIS_{mat_name}"
    mat = bpy.data.materials.get(mat_name)
    if mat is None:
        mat = bpy.data.materials.new(mat_name)
    mat.diffuse_color = tuple(entry.color)
    try:
        mat.pass_index = clamp_pass_index(entry.id_number)
    except Exception:
        pass
    write_id_custom_props(mat, entry, "material")
    return mat


def apply_material_to_object(context, obj, entry, settings):
    changed = 0
    if obj.type != "MESH":
        return 0

    mat = None
    if settings.material_mode == "CREATE_ASSIGN" or settings.create_missing_material:
        mat = ensure_id_material(entry)

    if settings.material_mode == "ALL_SLOTS":
        if not obj.material_slots and mat:
            obj.data.materials.append(mat)
        for slot in obj.material_slots:
            if slot.material is None and mat:
                slot.material = mat
            if slot.material:
                try:
                    slot.material.pass_index = clamp_pass_index(entry.id_number)
                except Exception:
                    pass
                if settings.write_custom_props:
                    write_id_custom_props(slot.material, entry, "material")
                changed += 1
        return changed

    if settings.material_mode == "SELECTED_FACES":
        mat = mat or ensure_id_material(entry)
        if mat.name not in [slot.material.name if slot.material else "" for slot in obj.material_slots]:
            obj.data.materials.append(mat)
        mat_index = list(obj.data.materials).index(mat)
        previous_mode = obj.mode
        try:
            if previous_mode != "OBJECT":
                bpy.ops.object.mode_set("EXEC_DEFAULT", False, mode="OBJECT")
            any_selected = False
            for poly in obj.data.polygons:
                if poly.select:
                    poly.material_index = mat_index
                    any_selected = True
                    changed += 1
            if not any_selected:
                for poly in obj.data.polygons:
                    poly.material_index = mat_index
                    changed += 1
        finally:
            try:
                if previous_mode != "OBJECT":
                    bpy.ops.object.mode_set("EXEC_DEFAULT", False, mode=previous_mode)
            except Exception:
                pass
        return changed

    # Active slot and create/assign fallback.
    if not obj.material_slots:
        obj.data.materials.append(mat or ensure_id_material(entry))
    slot_index = max(0, min(obj.active_material_index, len(obj.material_slots) - 1))
    slot = obj.material_slots[slot_index]
    if settings.material_mode == "CREATE_ASSIGN" or slot.material is None:
        slot.material = mat or ensure_id_material(entry)
    if slot.material:
        try:
            slot.material.pass_index = clamp_pass_index(entry.id_number)
        except Exception:
            pass
        if settings.write_custom_props:
            write_id_custom_props(slot.material, entry, "material")
        changed += 1
    return changed


def apply_entry(context, entry):
    scene = context.scene
    settings = get_settings(scene)
    if not entry or not entry.enabled or entry.locked:
        return 0
    objs = object_scope(context, settings.target_scope)
    meshes = [obj for obj in objs if obj and obj.type == "MESH"]
    changed = 0

    if entry.type == "OBJECT_ID":
        for obj in objs:
            if not obj:
                continue
            if settings.use_pass_index:
                try:
                    obj.pass_index = clamp_pass_index(entry.id_number)
                except Exception:
                    pass
            obj.color = tuple(entry.color)
            if settings.write_custom_props:
                write_id_custom_props(obj, entry, "object")
            changed += 1
        return changed

    if entry.type == "MATERIAL_ID":
        for obj in meshes:
            changed += apply_material_to_object(context, obj, entry, settings)
        return changed

    if entry.type in {"MAP_CHANNEL", "UV_CHANNEL"}:
        name = resolve_channel_name(entry, settings)
        for obj in meshes:
            ensure_uv_layer(obj, name)
            if settings.write_custom_props:
                obj.data[_prop_key(f"map_channel_{entry.map_channel}")] = name
                write_id_custom_props(obj.data, entry, "mesh_channel")
            changed += 1
        return changed

    if entry.type == "COLOR_ATTRIBUTE":
        name = resolve_channel_name(entry, settings)
        domain = entry.attribute_domain if entry.attribute_domain in {"POINT", "CORNER"} else "CORNER"
        for obj in meshes:
            ensure_color_attribute(obj, name, domain=domain)
            if settings.write_custom_props:
                write_id_custom_props(obj.data, entry, "color_attribute")
            changed += 1
        return changed

    if entry.type == "GEOMETRY_ATTRIBUTE":
        name = resolve_channel_name(entry, settings)
        for obj in meshes:
            ensure_geometry_attribute(obj, name, entry.attribute_type, entry.attribute_domain)
            if settings.write_custom_props:
                write_id_custom_props(obj.data, entry, "geometry_attribute")
            changed += 1
        return changed

    if entry.type == "WEIGHT_GROUP":
        name = resolve_channel_name(entry, settings)
        for obj in meshes:
            ensure_vertex_group(obj, name)
            if settings.write_custom_props:
                write_id_custom_props(obj, entry, "weight_group")
            changed += 1
        return changed

    if entry.type == "SELECTION_SET":
        collection_name = resolve_channel_name(entry, settings)
        collection = bpy.data.collections.get(collection_name)
        if collection is None:
            collection = bpy.data.collections.new(collection_name)
            scene.collection.children.link(collection)
        for obj in objs:
            if not obj:
                continue
            if obj.name not in collection.objects:
                try:
                    collection.objects.link(obj)
                except RuntimeError:
                    pass
            if settings.write_custom_props:
                write_id_custom_props(obj, entry, "selection_set")
            changed += 1
        return changed

    if entry.type == "UDIM_TILE":
        for obj in meshes:
            obj.data[_prop_key("udim_tile")] = int(entry.udim_tile)
            if settings.write_custom_props:
                write_id_custom_props(obj.data, entry, "udim_tile")
            changed += 1
        return changed

    if entry.type == "RENDER_AOV":
        return create_view_layer_aov(context, entry)

    if entry.type in {"CRYPTOMATTE_ID", "CUSTOM_ID"}:
        for obj in objs:
            if settings.write_custom_props:
                write_id_custom_props(obj, entry, "custom")
            if entry.type == "CRYPTOMATTE_ID":
                obj[_prop_key("cryptomatte_name")] = entry.export_tag or entry.name
            changed += 1
        return changed

    return changed


def _render_aov_name(entry):
    return safe_name(entry.export_tag or entry.name or resolve_channel_name(entry), "AOV")


def create_view_layer_aov(context, entry):
    view_layer = context.view_layer
    name = _render_aov_name(entry)
    changed = 0
    if hasattr(view_layer, "aovs"):
        existing = view_layer.aovs.get(name)
        if existing is None:
            try:
                aov = view_layer.aovs.add()
                aov.name = name
            except Exception:
                try:
                    aov = view_layer.aovs.new(name=name)
                except Exception:
                    aov = None
            if aov:
                try:
                    aov.type = "COLOR"
                except Exception:
                    pass
                changed += 1
    return changed


def select_by_entry(context, entry):
    return select_objects_matching_entry(context, entry, deselect=False)


def _select_matching_material_faces(obj, entries):
    """Option "Select Matching Faces": also select the faces of the matching material IDs."""
    if obj.type != "MESH" or not obj.data:
        return
    slots = set()
    for entry in entries:
        if entry.type == "MATERIAL_ID":
            slots.update(matching_material_slots(obj, entry))
    if not slots:
        return
    mesh = obj.data
    clear_mesh_element_selection(obj)
    select_material_faces(obj, slots)
    # Edit mode rebuilds face selection from vertices in vertex select mode.
    selected_edges = set()
    for polygon in mesh.polygons:
        if polygon.select:
            for index in polygon.vertices:
                mesh.vertices[index].select = True
            selected_edges.update(polygon.edge_keys)
    for edge in mesh.edges:
        if tuple(sorted(edge.vertices)) in selected_edges:
            edge.select = True
    return any(polygon.select for polygon in mesh.polygons)


def select_objects_matching_entries(context, entries, *, deselect=False):
    entries = [entry for entry in entries if entry]
    if not entries:
        return 0
    settings = get_settings(context.scene)
    ensure_object_mode(context)
    count = 0
    first = None
    if not deselect:
        for obj in context.scene.objects:
            try:
                obj.select_set(False)
            except Exception:
                pass
    for obj in context.scene.objects:
        if any(object_matches_entry(obj, entry, settings) for entry in entries):
            try:
                obj.select_set(not deselect)
                count += 1
                if first is None and not deselect:
                    first = obj
            except Exception:
                pass
            if not deselect and settings.select_faces:
                if _select_matching_material_faces(obj, entries):
                    # Faces are authoritative for this explicit option. Vertex mode
                    # would expand adjacent faces when their boundary vertices overlap.
                    context.tool_settings.mesh_select_mode = (False, False, True)
    if first is not None:
        context.view_layer.objects.active = first
    return count


def _element_selection_state(mesh):
    return (
        [vertex.select for vertex in mesh.vertices],
        [edge.select for edge in mesh.edges],
        [polygon.select for polygon in mesh.polygons],
    )


def _subtract_element_selection(mesh, before):
    """The mesh flags now mark the matched elements; restore `before` without them."""
    before_verts, before_edges, before_faces = before
    matched_verts = {vertex.index for vertex in mesh.vertices if vertex.select}
    matched_edges = {edge.index for edge in mesh.edges if edge.select}
    matched_faces = {polygon.index for polygon in mesh.polygons if polygon.select}
    released = set()
    keep_faces = set()
    for polygon in mesh.polygons:
        if polygon.index in matched_faces:
            released.update(polygon.vertices)
        elif before_faces[polygon.index] and not matched_verts.intersection(polygon.vertices):
            keep_faces.add(polygon.index)
    held = set()
    for index in keep_faces:
        held.update(mesh.polygons[index].vertices)
    released -= held
    gone = matched_verts | released
    for vertex in mesh.vertices:
        vertex.select = before_verts[vertex.index] and vertex.index not in gone
    for edge in mesh.edges:
        edge.select = (
            before_edges[edge.index]
            and edge.index not in matched_edges
            and not gone.intersection(edge.vertices)
        )
    for polygon in mesh.polygons:
        polygon.select = polygon.index in keep_faces


def select_elements_matching_entries(context, entries, *, deselect=False):
    entries = [entry for entry in entries if entry]
    if not entries:
        return 0
    settings = get_settings(context.scene)
    ensure_object_mode(context)
    if not deselect:
        for obj in context.scene.objects:
            try:
                obj.select_set(False)
            except Exception:
                pass
            if obj.type == "MESH" and obj.data:
                clear_mesh_element_selection(obj)
    selected_objects = []
    element_count = 0
    select_mode = "FACE"
    for obj in context.scene.objects:
        if obj.type != "MESH" or not obj.data:
            if any(object_matches_entry(obj, entry, settings) for entry in entries if entry.type in OBJECT_LEVEL_SELECT_TYPES):
                try:
                    obj.select_set(not deselect)
                    if not deselect:
                        selected_objects.append(obj)
                except Exception:
                    pass
            continue
        object_had_match = False
        for entry in entries:
            if not object_matches_entry(obj, entry, settings):
                continue
            object_had_match = True
            local_count = 0
            local_mode = "FACE"
            channel_name = resolve_channel_name(entry, settings)
            element_state = None
            if deselect:
                element_state = _element_selection_state(obj.data)
                clear_mesh_element_selection(obj)
            if entry.type == "MATERIAL_ID":
                local_count, local_mode = select_material_faces(obj, matching_material_slots(obj, entry), additive=not deselect)
            elif entry.type in {"MAP_CHANNEL", "UV_CHANNEL"}:
                if not deselect:
                    activate_channel_for_entry(obj, entry, settings)
                local_count, local_mode = select_mesh_domain(obj, "FACE", additive=not deselect)
            elif entry.type == "COLOR_ATTRIBUTE":
                attr = obj.data.color_attributes.get(channel_name) if deselect else activate_channel_for_entry(obj, entry, settings)[0]
                domain = getattr(attr, "domain", "CORNER") if attr else "CORNER"
                local_count, local_mode = select_mesh_domain(obj, domain, additive=not deselect)
            elif entry.type == "GEOMETRY_ATTRIBUTE":
                attr = obj.data.attributes.get(channel_name) if deselect else activate_channel_for_entry(obj, entry, settings)[0]
                domain = getattr(attr, "domain", "POINT") if attr else "POINT"
                local_count, local_mode = select_mesh_domain(obj, domain, additive=not deselect)
            elif entry.type == "WEIGHT_GROUP":
                local_count, local_mode = select_vertices_in_group(obj, channel_name, additive=not deselect)
            if deselect:
                _subtract_element_selection(obj.data, element_state)
                if local_count > 0 or entry.type in OBJECT_LEVEL_SELECT_TYPES:
                    try:
                        obj.select_set(False)
                    except Exception:
                        pass
            elif local_count > 0:
                try:
                    obj.select_set(True)
                except Exception:
                    pass
                if obj not in selected_objects:
                    selected_objects.append(obj)
                element_count += local_count
                select_mode = local_mode
        if not deselect and object_had_match and not any(obj is selected for selected in selected_objects):
            if any(object_matches_entry(obj, entry, settings) for entry in entries if entry.type in OBJECT_LEVEL_SELECT_TYPES):
                try:
                    obj.select_set(True)
                    selected_objects.append(obj)
                except Exception:
                    pass
    if selected_objects:
        context.view_layer.objects.active = selected_objects[0]
        if element_count > 0:
            try:
                bpy.ops.object.mode_set("EXEC_DEFAULT", False, mode="EDIT")
                bpy.ops.mesh.select_mode("EXEC_DEFAULT", False, type=select_mode)
            except Exception:
                pass
    return element_count if element_count else len(selected_objects)


def refresh_counts(scene, context=None):
    settings = get_settings(scene)
    if context is None:
        try:
            if bpy.context.scene == scene:
                context = bpy.context
        except Exception:
            context = None
    selected_targets = library_scope_objects(context, settings, fallback_to_scene=False) if context is not None else []
    for entry in get_entries(scene):
        entry.count_objects = 0
        entry.count_materials = 0
        entry.count_channels = 0
        entry.count_selected_objects = 0
        entry.count_selected_materials = 0
        entry.count_selected_channels = 0
        channel = resolve_channel_name(entry, settings)
        for obj in scene.objects:
            if entry.type == "OBJECT_ID":
                if getattr(obj, "pass_index", -1) == entry.id_number or obj.get(_prop_key("uid")) == entry.uid or (obj.get(_prop_key("type")) == entry.type and obj.get(_prop_key("id_number")) == entry.id_number):
                    entry.count_objects += 1
            elif entry.type == "MATERIAL_ID":
                if matching_material_slots(obj, entry):
                    entry.count_objects += 1
            elif entry.type in {"CRYPTOMATTE_ID", "CUSTOM_ID"}:
                if object_matches_entry(obj, entry, settings):
                    entry.count_objects += 1
            if obj.type == "MESH":
                mesh = obj.data
                if entry.type in {"MAP_CHANNEL", "UV_CHANNEL"} and mesh.uv_layers.get(channel):
                    entry.count_channels += 1
                elif entry.type == "COLOR_ATTRIBUTE" and mesh.color_attributes.get(channel):
                    entry.count_channels += 1
                elif entry.type == "GEOMETRY_ATTRIBUTE" and mesh.attributes.get(channel):
                    entry.count_channels += 1
                elif entry.type == "UDIM_TILE" and mesh.get(_prop_key("udim_tile")) == entry.udim_tile:
                    entry.count_channels += 1
                elif entry.type == "WEIGHT_GROUP" and obj.vertex_groups.get(channel):
                    entry.count_channels += 1
        if entry.type == "MATERIAL_ID":
            for mat in bpy.data.materials:
                if material_matches_entry(mat, entry):
                    entry.count_materials += 1
        if entry.type == "SELECTION_SET":
            collection = bpy.data.collections.get(channel)
            if collection:
                entry.count_objects = len(collection.objects)
        if entry.type == "RENDER_AOV":
            aov_name = _render_aov_name(entry)
            entry.count_channels = sum(1 for view_layer in scene.view_layers if view_layer.aovs.get(aov_name) is not None)
        if selected_targets:
            selected_counts = count_entry_matches_on_objects(entry, selected_targets, settings)
            entry.count_selected_objects, entry.count_selected_materials, entry.count_selected_channels = selected_counts
    if context is not None:
        _remember_counted_library_selection(context, scene, settings)
    try:
        if bool(getattr(settings, "overlay_enabled", False)):
            schedule_overlay_snapshot_rebuild(scene)
    except Exception:
        pass
    return True


def add_missing_entry(scene, entry_type, name, id_number=None, channel_name=None, configure=None, material_name=None):
    if entry_type == "MATERIAL_ID" and (material_name or channel_name):
        mat_key = material_name or channel_name
        if find_entry(scene, entry_type, channel_name=mat_key) or find_entry(scene, entry_type, name=mat_key):
            return None
    else:
        if id_number is not None and find_entry(scene, entry_type, id_number=id_number):
            return None
        if channel_name and find_entry(scene, entry_type, channel_name=channel_name):
            return None
    entry = get_entries(scene).add()
    entry.uid = uuid.uuid4().hex
    entry.type = entry_type
    entry.id_number = int(id_number if id_number is not None else next_id(scene, entry_type))
    entry.name = name
    entry.color = generated_color(entry.id_number)
    if channel_name:
        entry.channel_name = channel_name
    if material_name and entry_type == "MATERIAL_ID":
        entry.material_name = material_name
        entry.channel_name = entry.channel_name or material_name
        if _is_auto_material_id_name(entry.name, entry.id_number):
            entry.name = material_name
    if configure:
        configure(entry)
    scene.smart_id_active_index = len(get_entries(scene)) - 1
    return entry


def find_material_stack_entry(scene, material, material_id=None):
    if material is None:
        return None
    mat_name = str(getattr(material, "name", "") or "").strip()
    if not mat_name:
        return None
    for entry in get_entries(scene):
        if entry.type != "MATERIAL_ID":
            continue
        if material_entry_stack_name(entry) == mat_name or entry.name == mat_name:
            return entry
    if material_id is not None:
        try:
            material_id = int(material_id)
        except Exception:
            material_id = None
    if material_id is not None:
        for entry in get_entries(scene):
            if entry.type == "MATERIAL_ID" and int(getattr(entry, "id_number", -1)) == material_id and not material_entry_stack_name(entry) and _is_auto_material_id_name(entry.name, material_id):
                return entry
    return None


def configure_material_entry_from_material(entry, material, material_id=None):
    if entry is None or material is None:
        return False
    mat_name = str(getattr(material, "name", "") or "").strip()
    if not mat_name:
        return False
    if material_id is None:
        material_id = getattr(material, "pass_index", 0)
    entry.id_number = int(material_id)
    entry.name = mat_name
    entry.channel_name = mat_name
    entry.material_name = mat_name
    try:
        entry.color = tuple(material.diffuse_color)
    except Exception:
        pass
    return True


def ensure_material_stack_entry(scene, material, material_id=None):
    if material is None:
        return None, False
    if material_id is None:
        material_id = getattr(material, "pass_index", 0)
    try:
        material_id = int(material_id)
    except Exception:
        material_id = 0
    existing = find_material_stack_entry(scene, material, material_id)
    if existing:
        configure_material_entry_from_material(existing, material, material_id)
        return existing, False
    entry = get_entries(scene).add()
    entry.uid = uuid.uuid4().hex
    entry.type = "MATERIAL_ID"
    entry.enabled = True
    entry.locked = False
    configure_material_entry_from_material(entry, material, material_id)
    scene.smart_id_active_index = len(get_entries(scene)) - 1
    return entry, True


def _entry_id_from_pass_index(value, *, include_zero=False):
    try:
        number = int(value)
    except Exception:
        return None
    if number > 0 or include_zero:
        return number
    return None


def sync_from_objects(scene, objects, *, include_zero_ids=False, include_zero_material_ids=False, include_collections=True):
    added = 0
    objects = [obj for obj in objects or [] if obj]
    seen_objects = set()
    unique_objects = []
    for obj in objects:
        if obj.name not in seen_objects:
            seen_objects.add(obj.name)
            unique_objects.append(obj)
    for obj in unique_objects:
        object_id = _entry_id_from_pass_index(getattr(obj, "pass_index", 0), include_zero=include_zero_ids)
        if object_id is not None:
            if add_missing_entry(scene, "OBJECT_ID", f"Object_ID_{object_id:03d}", id_number=object_id):
                added += 1
        if obj.get(_prop_key("uid")) and obj.get(_prop_key("type")):
            etype = obj.get(_prop_key("type"))
            if etype in TYPE_ORDER and not find_entry(scene, etype, uid=obj.get(_prop_key("uid"))):
                entry = add_missing_entry(scene, etype, obj.get(_prop_key("name"), f"{etype}_{obj.get(_prop_key('id_number'), next_id(scene, etype))}"), id_number=obj.get(_prop_key("id_number")))
                if entry:
                    entry.uid = obj.get(_prop_key("uid"))
                    entry.export_tag = obj.get(_prop_key("export_tag"), "")
                    entry.channel_name = obj.get(_prop_key("channel_name"), "")
                    added += 1
        if include_collections:
            for collection in getattr(obj, "users_collection", []):
                def cfg_collection(e, collection_name=collection.name):
                    e.group_name = collection_name
                    e.channel_name = collection_name
                if add_missing_entry(scene, "SELECTION_SET", f"Set_{collection.name}", channel_name=collection.name, configure=cfg_collection):
                    added += 1
        if obj.type != "MESH" or not obj.data:
            continue
        mesh = obj.data
        for index, slot in enumerate(getattr(obj, "material_slots", [])):
            mat = slot.material
            if not mat:
                continue
            material_id = _entry_id_from_pass_index(getattr(mat, "pass_index", 0), include_zero=include_zero_material_ids)
            if material_id is not None:
                entry, created = ensure_material_stack_entry(scene, mat, material_id)
                if created:
                    added += 1
            if mat.get(_prop_key("uid")) and mat.get(_prop_key("type")) == "MATERIAL_ID":
                entry = find_entry(scene, "MATERIAL_ID", uid=mat.get(_prop_key("uid")))
                if not entry:
                    entry, created = ensure_material_stack_entry(scene, mat, mat.get(_prop_key("id_number"), next_id(scene, "MATERIAL_ID")))
                    if entry:
                        entry.uid = mat.get(_prop_key("uid"))
                        entry.export_tag = mat.get(_prop_key("export_tag"), "")
                    if created:
                        added += 1
                else:
                    configure_material_entry_from_material(entry, mat, mat.get(_prop_key("id_number"), getattr(mat, "pass_index", 0)))
        for uv in mesh.uv_layers:
            def cfg_uv(e, uv_name=uv.name):
                e.uv_map = uv_name
                e.channel_name = uv_name
                e.map_channel = max(1, e.id_number)
            if add_missing_entry(scene, "UV_CHANNEL", f"UV_{uv.name}", channel_name=uv.name, configure=cfg_uv):
                added += 1
        prefix = _prop_key("map_channel_")
        for key in mesh.keys():
            key_text = str(key)
            if not key_text.startswith(prefix):
                continue
            try:
                number = int(key_text[len(prefix):])
            except Exception:
                number = next_id(scene, "MAP_CHANNEL")
            try:
                uv_name = str(mesh[key])
            except Exception:
                uv_name = f"MapChannel_{number:02d}"
            def cfg_map(e, channel_number=number, uv_name=uv_name):
                e.map_channel = max(1, int(channel_number or e.id_number or 1))
                e.uv_map = uv_name
                e.channel_name = uv_name
            if add_missing_entry(scene, "MAP_CHANNEL", f"MapChannel_{number:03d}", id_number=number, channel_name=uv_name, configure=cfg_map):
                added += 1
        for attr in mesh.color_attributes:
            def cfg_col(e, attr_name=attr.name, attr_domain=getattr(attr, "domain", "CORNER")):
                e.color_attribute = attr_name
                e.channel_name = attr_name
                if attr_domain in {x[0] for x in ATTRIBUTE_DOMAIN_ITEMS}:
                    e.attribute_domain = attr_domain
            if add_missing_entry(scene, "COLOR_ATTRIBUTE", f"Color_{attr.name}", channel_name=attr.name, configure=cfg_col):
                added += 1
        for attr in mesh.attributes:
            if attr.name.startswith(".") or attr.name in {"position", "normal"}:
                continue
            # UV maps are attributes too; they already have their own UV_CHANNEL row.
            if mesh.color_attributes.get(attr.name) or mesh.uv_layers.get(attr.name):
                continue
            def cfg_attr(e, attr_name=attr.name, attr_type=getattr(attr, "data_type", "FLOAT"), attr_domain=getattr(attr, "domain", "POINT")):
                e.attribute_name = attr_name
                e.channel_name = attr_name
                if attr_type in {x[0] for x in ATTRIBUTE_TYPE_ITEMS}:
                    e.attribute_type = attr_type
                if attr_domain in {x[0] for x in ATTRIBUTE_DOMAIN_ITEMS}:
                    e.attribute_domain = attr_domain
            if add_missing_entry(scene, "GEOMETRY_ATTRIBUTE", f"Attr_{attr.name}", channel_name=attr.name, configure=cfg_attr):
                added += 1
        if mesh.get(_prop_key("udim_tile")) is not None:
            try:
                tile = int(mesh.get(_prop_key("udim_tile")))
            except Exception:
                tile = 1001
            def cfg_udim(e, udim_tile=tile):
                e.udim_tile = int(udim_tile)
                e.channel_name = f"UDIM_{udim_tile}"
            if add_missing_entry(scene, "UDIM_TILE", f"UDIM_{tile}", id_number=tile, channel_name=f"UDIM_{tile}", configure=cfg_udim):
                added += 1
        add_metadata = False
        for vg in obj.vertex_groups:
            def cfg_vg(e, vg_name=vg.name):
                e.group_name = vg_name
                e.channel_name = vg_name
            if add_missing_entry(scene, "WEIGHT_GROUP", f"Weight_{vg.name}", channel_name=vg.name, configure=cfg_vg):
                added += 1
    refresh_counts(scene)
    return added




def _library_autosync_signature(scope, objects):
    """Return a compact signature for the selected or active objects and their library-visible data."""
    rows = []
    for obj in objects or []:
        if not obj:
            continue
        obj_props = []
        for key in (_prop_key("uid"), _prop_key("type"), _prop_key("id_number"), _prop_key("channel_name"), _prop_key("udim_tile")):
            try:
                obj_props.append((key, str(obj.get(key, ""))))
            except Exception:
                pass
        mats = []
        try:
            for slot in getattr(obj, "material_slots", []):
                mat = getattr(slot, "material", None)
                if mat:
                    mat_props = []
                    for key in (_prop_key("uid"), _prop_key("type"), _prop_key("id_number"), _prop_key("channel_name")):
                        try:
                            mat_props.append((key, str(mat.get(key, ""))))
                        except Exception:
                            pass
                    mats.append((mat.name, int(getattr(mat, "pass_index", 0)), tuple(mat_props)))
                else:
                    mats.append(("", -1, ()))
        except Exception:
            pass
        mesh_state = ()
        if getattr(obj, "type", None) == "MESH" and getattr(obj, "data", None):
            mesh = obj.data
            map_meta = []
            prefix = _prop_key("map_channel_")
            try:
                for key in mesh.keys():
                    key_text = str(key)
                    if key_text.startswith(prefix):
                        map_meta.append((key_text, str(mesh[key])))
            except Exception:
                pass
            try:
                udim = str(mesh.get(_prop_key("udim_tile"), ""))
            except Exception:
                udim = ""
            mesh_state = (
                getattr(mesh, "name", ""),
                tuple(uv.name for uv in getattr(mesh, "uv_layers", [])),
                tuple(attr.name for attr in getattr(mesh, "color_attributes", [])),
                tuple((attr.name, str(getattr(attr, "data_type", "")), str(getattr(attr, "domain", ""))) for attr in getattr(mesh, "attributes", [])),
                tuple(sorted(map_meta)),
                udim,
            )
        try:
            groups = tuple(group.name for group in getattr(obj, "vertex_groups", []))
        except Exception:
            groups = ()
        try:
            collections = tuple(sorted(collection.name for collection in getattr(obj, "users_collection", [])))
        except Exception:
            collections = ()
        rows.append((obj.name, getattr(obj, "type", ""), int(getattr(obj, "pass_index", 0)), tuple(obj_props), tuple(mats), mesh_state, groups, collections))
    payload = repr((scope, tuple(sorted(rows, key=lambda item: item[0])))).encode("utf-8", "replace")
    return hashlib.sha256(payload).hexdigest()


def ensure_library_selection_entries(context, *, force=False, refresh=True):
    """Synchronize selected/active object IDs and channels during an explicit operation."""
    global _SMART_ID_LIBRARY_AUTOSYNC_RUNNING
    if _SMART_ID_LIBRARY_AUTOSYNC_RUNNING:
        return 0
    scene = getattr(context, "scene", None)
    if scene is None or not hasattr(scene, "smart_id_settings") or not hasattr(scene, "smart_id_entries"):
        return 0
    settings = get_settings(scene)
    scope = getattr(settings, "library_scope", "SCENE")
    if scope == "SCENE":
        return 0
    objects = library_scope_objects(context, settings, fallback_to_scene=False)
    if not objects:
        return 0
    signature = _library_autosync_signature(scope, objects)
    previous = getattr(settings, "last_library_autosync_signature", "")
    if not force and previous == signature:
        try:
            if visible_entry_indices(scene, context):
                return 0
        except Exception:
            return 0
    _SMART_ID_LIBRARY_AUTOSYNC_RUNNING = True
    previous_active = int(getattr(scene, "smart_id_active_index", -1))
    try:
        added = sync_from_objects(scene, objects, include_zero_ids=True, include_zero_material_ids=True, include_collections=True)
        # Rows are only appended here; the row the user chose stays chosen.
        scene.smart_id_active_index = previous_active
        if refresh:
            refresh_counts(scene, context)
        settings.last_library_autosync_signature = signature
        return int(added or 0)
    finally:
        _SMART_ID_LIBRARY_AUTOSYNC_RUNNING = False

def sync_from_scene(scene):
    added = 0
    settings = get_settings(scene)
    for obj in scene.objects:
        if getattr(obj, "pass_index", 0) > 0:
            if add_missing_entry(scene, "OBJECT_ID", f"Object_ID_{obj.pass_index:03d}", id_number=obj.pass_index):
                added += 1
        if obj.get(_prop_key("uid")) and obj.get(_prop_key("type")):
            etype = obj.get(_prop_key("type"))
            if etype in TYPE_ORDER and not find_entry(scene, etype, uid=obj.get(_prop_key("uid"))):
                entry = add_missing_entry(scene, etype, obj.get(_prop_key("name"), f"{etype}_{obj.get(_prop_key('id_number'), next_id(scene, etype))}"), id_number=obj.get(_prop_key("id_number")))
                if entry:
                    entry.uid = obj.get(_prop_key("uid"))
                    entry.export_tag = obj.get(_prop_key("export_tag"), "")
                    entry.channel_name = obj.get(_prop_key("channel_name"), "")
                    added += 1
        if obj.type != "MESH":
            continue
        mesh = obj.data
        for uv in mesh.uv_layers:
            def cfg_uv(e, uv_name=uv.name):
                e.uv_map = uv_name
                e.channel_name = uv_name
                e.map_channel = e.id_number
            if add_missing_entry(scene, "UV_CHANNEL", f"UV_{uv.name}", channel_name=uv.name, configure=cfg_uv):
                added += 1
        for attr in mesh.color_attributes:
            def cfg_col(e, attr_name=attr.name):
                e.color_attribute = attr_name
                e.channel_name = attr_name
                try:
                    e.attribute_domain = attr.domain
                except Exception:
                    pass
            if add_missing_entry(scene, "COLOR_ATTRIBUTE", f"Color_{attr.name}", channel_name=attr.name, configure=cfg_col):
                added += 1
        for attr in mesh.attributes:
            if attr.name.startswith(".") or attr.name in {"position", "normal"}:
                continue
            # UV maps are attributes too; they already have their own UV_CHANNEL row.
            if mesh.color_attributes.get(attr.name) or mesh.uv_layers.get(attr.name):
                continue
            def cfg_attr(e, attr_name=attr.name, attr_type=getattr(attr, "data_type", "FLOAT"), attr_domain=getattr(attr, "domain", "POINT")):
                e.attribute_name = attr_name
                e.channel_name = attr_name
                if attr_type in {x[0] for x in ATTRIBUTE_TYPE_ITEMS}:
                    e.attribute_type = attr_type
                if attr_domain in {x[0] for x in ATTRIBUTE_DOMAIN_ITEMS}:
                    e.attribute_domain = attr_domain
            if add_missing_entry(scene, "GEOMETRY_ATTRIBUTE", f"Attr_{attr.name}", channel_name=attr.name, configure=cfg_attr):
                added += 1
        for vg in obj.vertex_groups:
            def cfg_vg(e, vg_name=vg.name):
                e.group_name = vg_name
                e.channel_name = vg_name
            if add_missing_entry(scene, "WEIGHT_GROUP", f"Weight_{vg.name}", channel_name=vg.name, configure=cfg_vg):
                added += 1
    for mat in bpy.data.materials:
        if getattr(mat, "pass_index", 0) > 0:
            def cfg_mat(e, material=mat):
                e.color = tuple(material.diffuse_color)
            if add_missing_entry(scene, "MATERIAL_ID", f"Material_ID_{mat.pass_index:03d}", id_number=mat.pass_index, configure=cfg_mat):
                added += 1
        if mat.get(_prop_key("uid")) and mat.get(_prop_key("type")) == "MATERIAL_ID":
            if not find_entry(scene, "MATERIAL_ID", uid=mat.get(_prop_key("uid"))):
                entry = add_missing_entry(scene, "MATERIAL_ID", mat.get(_prop_key("name"), mat.name), id_number=mat.get(_prop_key("id_number"), next_id(scene, "MATERIAL_ID")))
                if entry:
                    entry.uid = mat.get(_prop_key("uid"))
                    entry.color = tuple(mat.diffuse_color)
                    added += 1
    refresh_counts(scene)
    return added


def validate_registry(scene):
    settings = get_settings(scene)
    refresh_counts(scene)
    lines = []
    warnings = 0
    entries = [entry for entry in get_entries(scene) if entry.enabled or settings.include_disabled]
    lines.append("Smart ID Suite Validation Report")
    lines.append(COPYRIGHT_NOTICE)
    lines.append(f"Entries checked: {len(entries)}")
    seen = {}
    for index, entry in enumerate(entries):
        if not entry.name.strip():
            lines.append(f"[Warning] Entry {index} has an empty name.")
            warnings += 1
        key = (entry.type, entry.id_number)
        if key in seen:
            lines.append(f"[Warning] Duplicate {entry.type} ID {entry.id_number}: {seen[key]} / {entry.name}")
            warnings += 1
        else:
            seen[key] = entry.name
        if entry.type in {"MAP_CHANNEL", "UV_CHANNEL", "COLOR_ATTRIBUTE", "GEOMETRY_ATTRIBUTE", "WEIGHT_GROUP"}:
            channel = resolve_channel_name(entry, settings)
            if not channel:
                lines.append(f"[Warning] {entry.name} has no channel name.")
                warnings += 1
            elif entry.count_channels == 0 and entry.type != "WEIGHT_GROUP":
                lines.append(f"[Info] {entry.name} channel '{channel}' is not present on scene meshes yet.")
        if entry.type == "OBJECT_ID" and entry.count_objects == 0:
            lines.append(f"[Info] {entry.name} Object ID {entry.id_number} is not assigned to any object yet.")
        if entry.type == "MATERIAL_ID" and entry.count_materials == 0:
            lines.append(f"[Info] {entry.name} Material ID {entry.id_number} is not assigned to any material yet.")
        if entry.type == "UDIM_TILE" and entry.udim_tile < 1001:
            lines.append(f"[Warning] {entry.name} has an invalid UDIM tile {entry.udim_tile}.")
            warnings += 1
    lines.append(f"Warnings: {warnings}")
    report = "\n".join(lines)
    text = bpy.data.texts.get("Smart ID Suite Validation") or bpy.data.texts.new("Smart ID Suite Validation")
    text.clear()
    text.write(report)
    settings.last_report = t("report_entries_warnings").format(entries=len(entries), warnings=warnings)
    return report, warnings


# -----------------------------------------------------------------------------
# Viewport overlay helpers
# -----------------------------------------------------------------------------

_OVERLAY_VIEW_HANDLE = None
_OVERLAY_TEXT_HANDLE = None
_OVERLAY_VIEW_CALLBACK = None
_OVERLAY_TEXT_CALLBACK = None
_OVERLAY_VIEW_RECORD = None
_OVERLAY_TEXT_RECORD = None
_OVERLAY_MAX_RECORDS = 240
_OVERLAY_MAX_POINTS = 1200
_OVERLAY_MAX_LABELS = 80
_OVERLAY_MAX_LABEL_CHARS = 48
_OVERLAY_LABEL_FONT_POINTS = 12
_OVERLAY_SNAPSHOT_SCENE_LIMIT = 8
_OVERLAY_PENDING_SCENE_LIMIT = 8
_OVERLAY_SNAPSHOTS = {}
_OVERLAY_PENDING_SCENE_NAMES = {}
_OVERLAY_REBUILD_TIMER_ACTIVE = False
_SMART_ID_OVERLAY_RUNTIME_ACTIVE = False
_OVERLAY_RELEVANT_ID_TYPES = frozenset({"Object", "Mesh", "Material", "Collection", "Scene"})
_OVERLAY_RENDER_SNAPSHOT_VERSION = 2
_OVERLAY_ACTIVE_RENDER_SNAPSHOT = None
_OverlayRenderSnapshot = namedtuple(
    "_OverlayRenderSnapshot",
    (
        "version", "generation", "owner_token", "scene_key",
        "gpu_state", "shader", "line_width",
        "line_commands", "point_commands", "label_commands",
        "estimated_bytes",
    ),
)


def stable_color_seed(text):
    value = 0
    for index, char in enumerate(str(text or "Smart ID")):
        value = (value + (index + 1) * ord(char)) % 9973
    return max(1, value)


def overlay_color(label, base_color=None, alpha=0.75):
    # Entry colors are scene-linear (the panel swatch shows them converted);
    # overlay draw callbacks write display values directly.
    # Rows without a display color pass None and get a color from their label.
    values = list(base_color)[:3] if base_color is not None else ()
    if len(values) < 3:
        values = generated_color(stable_color_seed(label))[:3]
    r, g, b = Color(values).from_scene_linear_to_srgb()
    return (r, g, b, float(alpha))


def overlay_entry_label(entry, context=None, settings=None):
    key = TYPE_LABEL_KEY.get(entry.type, "custom_id")
    if settings is None:
        try:
            scene = getattr(context or bpy.context, "scene", None)
            settings = get_settings(scene)
        except Exception:
            settings = None
    try:
        resolved = resolve_channel_name(entry, settings) if settings is not None else ""
    except Exception:
        resolved = ""
    return f"{t(key, context)}: {entry.name or resolved}"


def overlay_inspector_label(item, context=None):
    key = INSPECTOR_TYPE_LABEL_KEY.get(item.item_type, "custom_id")
    return f"{t(key, context)}: {_inspector_name_display_text(item, context) or item.owner_object}"


def overlay_sources_from_entries(context, scene, settings):
    entries = []
    if settings.overlay_source == "ACTIVE_ENTRY":
        entry = active_entry(scene)
        if entry:
            entries.append(entry)
    elif settings.overlay_source in {"VISIBLE_ENTRIES", "BOTH"}:
        counts_stale = library_counts_are_stale(context, settings)
        active = active_entry(scene)
        entries = [entry for entry in get_entries(scene) if entry.enabled and entry_visible_in_list(entry, settings, context, counts_stale, active)]
    return entries


def overlay_entry_objects(context, scene, settings):
    # Shown rows are judged against the scope targets, so only those objects get a box.
    if settings.overlay_source in {"VISIBLE_ENTRIES", "BOTH"} and _library_scope_has_targets(context, settings) and not library_counts_are_stale(context, settings):
        return library_scope_objects(context, settings, fallback_to_scene=False) or scene.objects
    return scene.objects


def overlay_entry_records(context, scene, settings):
    records = []
    objects = overlay_entry_objects(context, scene, settings)
    for entry in overlay_sources_from_entries(context, scene, settings):
        if not entry_allowed_by_overlay_filters(entry.type, settings):
            continue
        color = overlay_color(entry.name or entry.uid, entry.color, settings.overlay_alpha)
        label = overlay_entry_label(entry, context, settings)
        for obj in objects:
            if object_matches_entry(obj, entry, settings):
                records.append((obj, entry, color, label, entry.type, "ENTRY"))
                if len(records) >= _OVERLAY_MAX_RECORDS:
                    return records
    return records


def overlay_inspector_records(context, scene, settings):
    records = []
    if settings.overlay_source not in {"INSPECTOR_ITEMS", "BOTH"}:
        return records
    for item in get_inspector_items(scene):
        entry = make_entry_proxy_from_inspector(item)
        if not entry_allowed_by_overlay_filters(entry.type, settings):
            continue
        base_color = item.color if item.item_type in {"OBJECT_ID", "MATERIAL_ID"} else None
        color = overlay_color(item.uid or item.name, base_color, settings.overlay_alpha)
        label = overlay_inspector_label(item, context)
        if item.item_type == "SELECTION_SET" and item.collection_name:
            collection = bpy.data.collections.get(item.collection_name)
            if collection:
                for obj in collection.objects:
                    records.append((obj, entry, color, label, entry.type, "INSPECTOR"))
                    if len(records) >= _OVERLAY_MAX_RECORDS:
                        return records
            continue
        obj = inspector_owner_object(item)
        if obj:
            records.append((obj, entry, color, label, entry.type, "INSPECTOR"))
            if len(records) >= _OVERLAY_MAX_RECORDS:
                return records
    return records


def collect_overlay_records_for_scene(scene, context=None):
    try:
        settings = get_settings(scene)
    except Exception:
        return []
    if not bool(getattr(settings, "overlay_enabled", False)):
        return []
    context = context or bpy.context
    records = []
    records.extend(overlay_entry_records(context, scene, settings))
    if len(records) < _OVERLAY_MAX_RECORDS:
        records.extend(overlay_inspector_records(context, scene, settings))
    return records[:_OVERLAY_MAX_RECORDS]


def collect_overlay_records(context):
    """Compatibility wrapper used only by explicit/event-time snapshot rebuilds."""
    scene = getattr(context, "scene", None)
    return collect_overlay_records_for_scene(scene, context) if scene is not None else []


def object_world_bbox_corners(obj):
    try:
        return [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    except Exception:
        return []


def bbox_line_coords(obj, corners=None):
    corners = corners if corners is not None else object_world_bbox_corners(obj)
    if len(corners) != 8:
        return []
    edges = ((0, 1), (1, 2), (2, 3), (3, 0), (4, 5), (5, 6), (6, 7), (7, 4), (0, 4), (1, 5), (2, 6), (3, 7))
    coords = []
    for a, b in edges:
        coords.append(corners[a])
        coords.append(corners[b])
    return coords


def face_center_world(obj, polygon):
    try:
        coords = [obj.matrix_world @ obj.data.vertices[index].co for index in polygon.vertices]
        if not coords:
            return None
        center = Vector((0.0, 0.0, 0.0))
        for coord in coords:
            center += coord
        return center / len(coords)
    except Exception:
        return None


def overlay_points_for_record(obj, entry, settings, limit=80):
    if not settings.overlay_element_marks:
        return []
    if not obj or obj.type != "MESH" or not obj.data:
        return []
    mesh = obj.data
    points = []
    name = resolve_channel_name(entry, settings)
    try:
        if entry.type == "MATERIAL_ID":
            slots = set(matching_material_slots(obj, entry))
            for poly in mesh.polygons:
                if int(poly.material_index) in slots:
                    pt = face_center_world(obj, poly)
                    if pt:
                        points.append(pt)
                if len(points) >= limit:
                    return points
        elif entry.type in {"MAP_CHANNEL", "UV_CHANNEL"} and mesh.uv_layers.get(name):
            for poly in mesh.polygons:
                pt = face_center_world(obj, poly)
                if pt:
                    points.append(pt)
                if len(points) >= limit:
                    return points
        elif entry.type == "COLOR_ATTRIBUTE" and mesh.color_attributes.get(name):
            attr = mesh.color_attributes.get(name)
            domain = getattr(attr, "domain", "CORNER")
            if domain == "POINT":
                for vertex in mesh.vertices:
                    points.append(obj.matrix_world @ vertex.co)
                    if len(points) >= limit:
                        return points
            else:
                for poly in mesh.polygons:
                    pt = face_center_world(obj, poly)
                    if pt:
                        points.append(pt)
                    if len(points) >= limit:
                        return points
        elif entry.type == "GEOMETRY_ATTRIBUTE" and mesh.attributes.get(name):
            attr = mesh.attributes.get(name)
            domain = getattr(attr, "domain", "POINT")
            if domain == "POINT":
                for vertex in mesh.vertices:
                    points.append(obj.matrix_world @ vertex.co)
                    if len(points) >= limit:
                        return points
            elif domain == "EDGE":
                for edge in mesh.edges:
                    v0 = mesh.vertices[edge.vertices[0]].co
                    v1 = mesh.vertices[edge.vertices[1]].co
                    points.append(obj.matrix_world @ ((v0 + v1) * 0.5))
                    if len(points) >= limit:
                        return points
            else:
                for poly in mesh.polygons:
                    pt = face_center_world(obj, poly)
                    if pt:
                        points.append(pt)
                    if len(points) >= limit:
                        return points
        elif entry.type == "WEIGHT_GROUP":
            group = obj.vertex_groups.get(name)
            if group:
                group_index = group.index
                for vertex in mesh.vertices:
                    if any(weight.group == group_index and weight.weight > 0.0 for weight in vertex.groups):
                        points.append(obj.matrix_world @ vertex.co)
                    if len(points) >= limit:
                        return points
    except Exception:
        return points
    return points


def _overlay_scene_key(scene):
    if scene is None:
        return ""
    try:
        return f"{int(scene.as_pointer())}:{scene.name}"
    except Exception:
        return str(getattr(scene, "name", ""))


def _vector_tuple(value):
    try:
        return (float(value[0]), float(value[1]), float(value[2]))
    except Exception:
        return None


def _store_overlay_snapshot(scene, snapshot):
    key = _overlay_scene_key(scene)
    if not key:
        return False
    return _bounded_cache_put(
        _OVERLAY_SNAPSHOTS,
        key,
        tuple(snapshot),
        _OVERLAY_SNAPSHOT_SCENE_LIMIT,
        ttl_seconds=300.0,
        account_name="overlay_primitives",
    )


def overlay_snapshot_for_scene(scene):
    return _bounded_cache_get(
        _OVERLAY_SNAPSHOTS,
        _overlay_scene_key(scene),
        (),
        ttl_seconds=300.0,
        account_name="overlay_primitives",
    )


def _publish_overlay_render_snapshot(snapshot):
    global _OVERLAY_ACTIVE_RENDER_SNAPSHOT
    if snapshot is None:
        _OVERLAY_ACTIVE_RENDER_SNAPSHOT = None
        _cache_account_drop("overlay_gpu")
        return True
    if not isinstance(snapshot, _OverlayRenderSnapshot):
        return False
    if not _cache_account_replace("overlay_gpu", int(snapshot.estimated_bytes)):
        return False
    _OVERLAY_ACTIVE_RENDER_SNAPSHOT = snapshot
    return True


def clear_overlay_snapshot(scene=None):
    global _OVERLAY_ACTIVE_RENDER_SNAPSHOT
    if scene is None:
        _bounded_cache_clear(_OVERLAY_SNAPSHOTS, "overlay_primitives")
        _OVERLAY_ACTIVE_RENDER_SNAPSHOT = None
        _cache_account_drop("overlay_gpu")
        return
    key = _overlay_scene_key(scene)
    _bounded_cache_pop(_OVERLAY_SNAPSHOTS, key, None, account_name="overlay_primitives")
    current = _OVERLAY_ACTIVE_RENDER_SNAPSHOT
    if isinstance(current, _OverlayRenderSnapshot) and current.scene_key == key:
        _OVERLAY_ACTIVE_RENDER_SNAPSHOT = None
        _cache_account_drop("overlay_gpu")


def _overlay_label_scale(box_coords, points):
    coords = tuple(box_coords) if box_coords else tuple(points)
    if not coords:
        return 0.01
    try:
        xs = [float(value[0]) for value in coords]
        ys = [float(value[1]) for value in coords]
        zs = [float(value[2]) for value in coords]
        diagonal = math.sqrt((max(xs) - min(xs)) ** 2 + (max(ys) - min(ys)) ** 2 + (max(zs) - min(zs)) ** 2)
    except Exception:
        diagonal = 1.0
    return max(0.001, min(0.25, diagonal * 0.0125 if diagonal > 0.0 else 0.01))


def _overlay_point_marker_line_coords(points, scale):
    """Convert point marks to bounded 3-axis line crosses outside draw.

    Blender 5.1 exposes ``gpu.state.point_size_set`` but no matching getter.
    Smart ID therefore never mutates the unqueryable point-size state: point
    marks are completed line batches, so an arbitrary pre-draw point size is
    preserved exactly by non-mutation.
    """
    try:
        radius = max(0.0005, min(0.125, float(scale)))
    except Exception:
        radius = 0.005
    coords = []
    for value in tuple(points or ()):
        point = _vector_tuple(value)
        if point is None:
            continue
        x, y, z = point
        coords.extend((
            (x - radius, y, z), (x + radius, y, z),
            (x, y - radius, z), (x, y + radius, z),
            (x, y, z - radius), (x, y, z + radius),
        ))
        if len(coords) >= _OVERLAY_MAX_POINTS * 6:
            break
    return tuple(coords[:_OVERLAY_MAX_POINTS * 6])


def _build_overlay_render_snapshot(scene, primitive_snapshot, settings):
    """Create shader and every GPU batch outside all draw callbacks."""
    try:
        import gpu
        from gpu_extras.batch import batch_for_shader
    except Exception:
        return None
    try:
        shader = gpu.shader.from_builtin("UNIFORM_COLOR")
        state_api = gpu.state
    except Exception:
        return None

    line_commands = []
    point_commands = []
    label_commands = []
    estimated_gpu_bytes = 4096
    show_labels = bool(getattr(settings, "overlay_show_labels", False))
    for box_coords, points, color, label, anchor in primitive_snapshot:
        if box_coords:
            try:
                batch = batch_for_shader(shader, "LINES", {"pos": box_coords})
                line_commands.append((batch, tuple(color)))
                estimated_gpu_bytes += len(box_coords) * 12 + 256
            except Exception:
                pass
        if points:
            marker_scale = _overlay_label_scale(box_coords, points) * 0.45
            marker_coords = _overlay_point_marker_line_coords(points, marker_scale)
            if marker_coords:
                try:
                    batch = batch_for_shader(shader, "LINES", {"pos": marker_coords})
                    point_commands.append((batch, tuple(color)))
                    estimated_gpu_bytes += len(marker_coords) * 12 + 256
                except Exception:
                    pass
        if show_labels and anchor is not None and len(label_commands) < _OVERLAY_MAX_LABELS:
            text = str(label or "")[:_OVERLAY_MAX_LABEL_CHARS]
            if text:
                label_commands.append((text, tuple(anchor), tuple(color)))
                estimated_gpu_bytes += len(text) * 4 + 256

    try:
        line_width = float(getattr(settings, "overlay_line_width", 2.0))
    except Exception:
        line_width = 2.0
    return _OverlayRenderSnapshot(
        _OVERLAY_RENDER_SNAPSHOT_VERSION,
        int(_SMART_ID_MODULE_GENERATION),
        str(_SMART_ID_RUNTIME_OWNER_TOKEN),
        _overlay_scene_key(scene),
        state_api,
        shader,
        max(1.0, min(8.0, line_width)),
        tuple(line_commands),
        tuple(point_commands),
        tuple(label_commands),
        int(estimated_gpu_bytes),
    )


def rebuild_overlay_snapshot(scene, context=None):
    if scene is None or not hasattr(scene, "smart_id_settings"):
        clear_overlay_snapshot(scene)
        return 0
    try:
        settings = get_settings(scene)
    except Exception:
        clear_overlay_snapshot(scene)
        return 0
    if not bool(getattr(settings, "overlay_enabled", False)):
        clear_overlay_snapshot(scene)
        return 0
    context = context or bpy.context
    snapshot = []
    total_points = 0
    for obj, entry, color, label, _entry_type, _source in collect_overlay_records_for_scene(scene, context):
        corners = object_world_bbox_corners(obj)
        box_coords = bbox_line_coords(obj, corners) if settings.overlay_object_boxes else []
        remaining = max(0, _OVERLAY_MAX_POINTS - total_points)
        points = overlay_points_for_record(obj, entry, settings, limit=min(80, remaining)) if remaining else []
        total_points += len(points)
        anchor = max(corners, key=lambda value: value.z) if corners else None
        snapshot.append((
            tuple(coord for coord in (_vector_tuple(value) for value in box_coords) if coord is not None),
            tuple(point for point in (_vector_tuple(value) for value in points) if point is not None),
            tuple(float(value) for value in color[:4]),
            str(label)[:72],
            _vector_tuple(anchor),
        ))
        if len(snapshot) >= _OVERLAY_MAX_RECORDS:
            break
    primitive_snapshot = tuple(snapshot)
    completed = _build_overlay_render_snapshot(scene, primitive_snapshot, settings)
    _store_overlay_snapshot(scene, primitive_snapshot)
    if completed is None or not _publish_overlay_render_snapshot(completed):
        return 0
    tag_redraw_view3d()
    return len(primitive_snapshot)


def _cancel_overlay_snapshot_rebuild_timer():
    global _OVERLAY_REBUILD_TIMER_ACTIVE
    _remove_runtime_timer_exact(_overlay_snapshot_rebuild_timer)
    _bounded_cache_clear(_OVERLAY_PENDING_SCENE_NAMES, "overlay_pending")
    _OVERLAY_REBUILD_TIMER_ACTIVE = False


def _overlay_snapshot_rebuild_timer():
    global _OVERLAY_REBUILD_TIMER_ACTIVE
    _untrack_runtime_timer(_overlay_snapshot_rebuild_timer)
    pending = tuple(_OVERLAY_PENDING_SCENE_NAMES.items())
    _bounded_cache_clear(_OVERLAY_PENDING_SCENE_NAMES, "overlay_pending")
    _OVERLAY_REBUILD_TIMER_ACTIVE = False
    if not _SMART_ID_OVERLAY_RUNTIME_ACTIVE:
        return None
    if not _runtime_generation_guard_fast(_SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN):
        return None
    if not _runtime_generation_is_current(_SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN):
        return None
    scene = getattr(getattr(bpy, "context", None), "scene", None)
    current_key = _overlay_scene_key(scene)
    for key, request in pending:
        if key != current_key or not isinstance(request, dict):
            continue
        if int(request.get("generation", -1)) != int(_SMART_ID_MODULE_GENERATION):
            continue
        try:
            rebuild_overlay_snapshot(scene)
        except Exception:
            pass
        break
    return None


def schedule_overlay_snapshot_rebuild(scene=None):
    global _OVERLAY_REBUILD_TIMER_ACTIVE
    if not _SMART_ID_OVERLAY_RUNTIME_ACTIVE or not _runtime_generation_is_current():
        return False
    scene = scene or getattr(bpy.context, "scene", None)
    if scene is None or not hasattr(scene, "smart_id_settings"):
        return False
    try:
        if not bool(getattr(get_settings(scene), "overlay_enabled", False)):
            clear_overlay_snapshot(scene)
            return False
    except Exception:
        return False
    key = _overlay_scene_key(scene)
    request = {
        "scene_name": str(getattr(scene, "name", ""))[:256],
        "generation": int(_SMART_ID_MODULE_GENERATION),
    }
    if not _bounded_cache_put(
        _OVERLAY_PENDING_SCENE_NAMES,
        key,
        request,
        _OVERLAY_PENDING_SCENE_LIMIT,
        ttl_seconds=5.0,
        account_name="overlay_pending",
    ):
        return False
    if not _OVERLAY_REBUILD_TIMER_ACTIVE:
        try:
            _register_runtime_timer_exact(_overlay_snapshot_rebuild_timer, first_interval=0.10)
            _OVERLAY_REBUILD_TIMER_ACTIVE = True
        except Exception:
            _untrack_runtime_timer(_overlay_snapshot_rebuild_timer)
            _OVERLAY_REBUILD_TIMER_ACTIVE = False
            return False
    return True


def any_overlay_enabled():
    scene = getattr(getattr(bpy, "context", None), "scene", None)
    try:
        settings = get_settings(scene) if scene is not None and hasattr(scene, "smart_id_settings") else None
        return bool(settings is not None and getattr(settings, "overlay_enabled", False))
    except Exception:
        return False


def _depsgraph_update_is_overlay_relevant(update):
    try:
        id_data = update.id
    except Exception:
        return False
    try:
        identifier = str(getattr(getattr(id_data, "bl_rna", None), "identifier", ""))
    except Exception:
        identifier = ""
    if not identifier:
        identifier = type(id_data).__name__
    return identifier in _OVERLAY_RELEVANT_ID_TYPES


@persistent
def smart_id_overlay_depsgraph_update(scene, depsgraph):
    if not _runtime_generation_guard_fast(_SMART_ID_MODULE_GENERATION, _SMART_ID_RUNTIME_OWNER_TOKEN):
        return
    if not _SMART_ID_OVERLAY_RUNTIME_ACTIVE or not _runtime_generation_is_current():
        return
    if depsgraph is None:
        return
    try:
        if not any(_depsgraph_update_is_overlay_relevant(update) for update in depsgraph.updates):
            return
    except Exception:
        return
    # Only after a relevant ID update has been established may Scene settings be
    # read and one coalesced snapshot job be enqueued.  No evaluated data or Scene
    # traversal occurs in this callback.
    try:
        settings = get_settings(scene) if scene is not None and hasattr(scene, "smart_id_settings") else None
        if settings is not None and bool(getattr(settings, "overlay_enabled", False)):
            schedule_overlay_snapshot_rebuild(scene)
    except Exception:
        return


def _overlay_render_snapshot_is_current(snapshot, generation=None, owner_token=None):
    generation = _SMART_ID_MODULE_GENERATION if generation is None else int(generation)
    owner_token = _SMART_ID_RUNTIME_OWNER_TOKEN if owner_token is None else str(owner_token)
    return bool(
        isinstance(snapshot, _OverlayRenderSnapshot)
        and int(snapshot.version) == _OVERLAY_RENDER_SNAPSHOT_VERSION
        and int(snapshot.generation) == generation
        and str(snapshot.owner_token) == owner_token
        and _runtime_generation_guard_fast(generation, owner_token)
    )


def _capture_gpu_state_exact(state_api):
    values = []
    # Capture every state this draw path mutates.  Point size is deliberately
    # not mutated because Blender 5.1 has no point_size_get API; preserving it
    # by non-mutation is the only exact restoration contract.
    for name in ("blend", "depth_test", "line_width"):
        getter = getattr(state_api, f"{name}_get", None)
        setter = getattr(state_api, f"{name}_set", None)
        if not callable(getter) or not callable(setter):
            raise RuntimeError(f"GPU state {name} getter/setter is unavailable")
        values.append((name, getter(), setter))
    return tuple(values)


def _restore_gpu_state_exact(captured):
    errors = []
    for name, value, setter in reversed(tuple(captured)):
        try:
            setter(value)
        except Exception as exc:
            errors.append((name, exc))
    if errors:
        name, exc = errors[0]
        raise RuntimeError(f"GPU state restore failed for {name}: {exc}") from exc


def _draw_completed_overlay_batches(snapshot):
    state_api = snapshot.gpu_state
    captured = _capture_gpu_state_exact(state_api)
    try:
        state_api.blend_set("ALPHA")
        state_api.depth_test_set("LESS_EQUAL")
        state_api.line_width_set(max(1.0, float(snapshot.line_width)))
        for batch, color in snapshot.line_commands:
            snapshot.shader.bind()
            snapshot.shader.uniform_float("color", color)
            batch.draw(snapshot.shader)
        for batch, color in snapshot.point_commands:
            snapshot.shader.bind()
            snapshot.shader.uniform_float("color", color)
            batch.draw(snapshot.shader)
    finally:
        _restore_gpu_state_exact(captured)


def _draw_overlay_label_text(label_commands):
    context = bpy.context
    region = context.region
    region_3d = context.region_data
    if region is None or region_3d is None:
        return
    ui_scale = float(context.preferences.system.ui_scale)
    font_id = 0
    blf.size(font_id, _OVERLAY_LABEL_FONT_POINTS * ui_scale)
    blf.enable(font_id, blf.SHADOW)
    try:
        blf.shadow(font_id, 3, 0.0, 0.0, 0.0, 0.85)
        blf.shadow_offset(font_id, 1, -1)
        for text, anchor, color in label_commands:
            position = location_3d_to_region_2d(region, region_3d, anchor)
            if position is None:
                continue
            blf.position(font_id, position.x + 4.0 * ui_scale, position.y + 4.0 * ui_scale, 0.0)
            blf.color(font_id, *color)
            blf.draw(font_id, text)
    finally:
        blf.disable(font_id, blf.SHADOW)


def draw_overlay_view(generation=None, owner_token=None):
    """Draw only the atomically published immutable snapshot and completed batches."""
    snapshot = _OVERLAY_ACTIVE_RENDER_SNAPSHOT
    if not _overlay_render_snapshot_is_current(snapshot, generation, owner_token):
        return
    try:
        _draw_completed_overlay_batches(snapshot)
    except Exception:
        return


def draw_overlay_text(generation=None, owner_token=None):
    """Draw snapshot labels as screen-facing text at their projected anchors."""
    snapshot = _OVERLAY_ACTIVE_RENDER_SNAPSHOT
    if not _overlay_render_snapshot_is_current(snapshot, generation, owner_token):
        return
    if not snapshot.label_commands:
        return
    try:
        _draw_overlay_label_text(snapshot.label_commands)
    except Exception:
        return


def _make_generation_guarded_draw_callback(target, generation, owner_token, label):
    holder = {}

    def callback():
        current = holder.get("callback")
        record = getattr(current, "_smart_id_draw_record", None) if current is not None else None
        if (
            current is None
            or not _SMART_ID_OVERLAY_RUNTIME_ACTIVE
            or not _runtime_generation_guard_fast(generation, owner_token)
            or not isinstance(record, dict)
            or bool(record.get("retired", False))
            or record.get("callback") is not current
        ):
            return None
        return target(generation, owner_token)

    callback.__name__ = str(label)
    callback.__qualname__ = str(label)
    callback._smart_id_generation = int(generation)
    callback._smart_id_owner_token = str(owner_token)
    callback._smart_id_draw_target = target
    holder["callback"] = callback
    return callback


def _add_one_overlay_draw_handler(target, label, draw_type):
    generation = int(_SMART_ID_MODULE_GENERATION)
    owner_token = str(_SMART_ID_RUNTIME_OWNER_TOKEN)
    space_cls = bpy.types.SpaceView3D
    native_add = getattr(space_cls, "draw_handler_add")
    native_remove = getattr(space_cls, "draw_handler_remove")
    callback = _make_generation_guarded_draw_callback(target, generation, owner_token, label)
    handle = native_add(callback, (), "WINDOW", str(draw_type))
    record = _track_runtime_draw_handle(
        "SpaceView3D",
        handle,
        "WINDOW",
        callback=callback,
        native_remover=native_remove,
        draw_type=draw_type,
        generation=generation,
        owner_token=owner_token,
    )
    if record is None:
        native_remove(handle, "WINDOW")
        raise RuntimeError("draw handler ledger registration failed")
    callback._smart_id_draw_record = record
    return handle, callback, record


def _remove_one_overlay_draw_handler(record, handle):
    if record is None and handle is not None:
        record = _runtime_draw_record_for(handle=handle)
    if record is None:
        return handle is None
    record["retired"] = True
    for _attempt in range(max(1, int(_SMART_ID_RESOURCE_RELEASE_RETRY_LIMIT))):
        if _remove_runtime_draw_record(record, state=_runtime_registry_state(), mark_retired=True):
            return True
    return False


def _retry_retired_runtime_draw_records_before_add(skip_records=()):
    """Retry old native removals and block new acquisition while one is unresolved."""
    state = _runtime_registry_state()
    current_generation = int(_SMART_ID_MODULE_GENERATION)
    current_owner = str(_SMART_ID_RUNTIME_OWNER_TOKEN)
    skipped = tuple(record for record in skip_records if isinstance(record, dict))
    unresolved = False
    for raw_record in tuple(state.get("draw_handles", ())):
        # Driver-namespace fixtures not carrying this Suite's exact ownership
        # and ledger identity are foreign and neither removed nor allowed to
        # influence Overlay availability.  A malformed exact-owned record does
        # block new acquisition because its native handle cannot be proven gone.
        if not _resource_record_is_exact_ledger_member(
            raw_record, kind="draw_handler", state=state
        ):
            continue
        record = _coerce_runtime_draw_record(raw_record)
        if record is None:
            unresolved = True
            continue
        if any(record is item for item in skipped):
            continue
        is_current = (
            not bool(record.get("retired", False))
            and int(record.get("generation", 0)) == current_generation
            and str(record.get("owner_token", "")) == current_owner
        )
        if is_current:
            continue
        record["retired"] = True
        removed = False
        for _attempt in range(max(1, int(_SMART_ID_RESOURCE_RELEASE_RETRY_LIMIT))):
            if _remove_runtime_draw_record(record, state=state, mark_retired=True):
                removed = True
                break
        if not removed:
            unresolved = True
    return not unresolved


def add_overlay_handlers():
    global _OVERLAY_VIEW_HANDLE, _OVERLAY_TEXT_HANDLE
    global _OVERLAY_VIEW_CALLBACK, _OVERLAY_TEXT_CALLBACK
    global _OVERLAY_VIEW_RECORD, _OVERLAY_TEXT_RECORD
    global _SMART_ID_OVERLAY_RUNTIME_ACTIVE
    if not _runtime_generation_is_current():
        _SMART_ID_OVERLAY_RUNTIME_ACTIVE = False
        return False

    # Retire unresolved local records before any new native acquisition.
    for kind in ("view", "text"):
        record = _OVERLAY_VIEW_RECORD if kind == "view" else _OVERLAY_TEXT_RECORD
        handle = _OVERLAY_VIEW_HANDLE if kind == "view" else _OVERLAY_TEXT_HANDLE
        if isinstance(record, dict) and bool(record.get("retired", False)):
            if _remove_one_overlay_draw_handler(record, handle):
                if kind == "view":
                    _OVERLAY_VIEW_HANDLE = _OVERLAY_VIEW_CALLBACK = _OVERLAY_VIEW_RECORD = None
                else:
                    _OVERLAY_TEXT_HANDLE = _OVERLAY_TEXT_CALLBACK = _OVERLAY_TEXT_RECORD = None

    if not _retry_retired_runtime_draw_records_before_add(
        (_OVERLAY_VIEW_RECORD, _OVERLAY_TEXT_RECORD)
    ):
        _SMART_ID_OVERLAY_RUNTIME_ACTIVE = False
        return False

    state = _runtime_registry_state()
    handler_was_owned = _resource_ledger_find(
        "handler", smart_id_overlay_depsgraph_update,
        owner_token=_SMART_ID_RUNTIME_OWNER_TOKEN,
        state=state,
    ) is not None
    acquired_draw = []
    try:
        _register_runtime_handler_exact("depsgraph_update_post", smart_id_overlay_depsgraph_update)
        if _OVERLAY_VIEW_HANDLE is None:
            values = _add_one_overlay_draw_handler(
                draw_overlay_view, "smart_id_overlay_view_guarded", "POST_VIEW"
            )
            _OVERLAY_VIEW_HANDLE, _OVERLAY_VIEW_CALLBACK, _OVERLAY_VIEW_RECORD = values
            acquired_draw.append("view")
        if _OVERLAY_TEXT_HANDLE is None:
            values = _add_one_overlay_draw_handler(
                draw_overlay_text, "smart_id_overlay_text_guarded", "POST_PIXEL"
            )
            _OVERLAY_TEXT_HANDLE, _OVERLAY_TEXT_CALLBACK, _OVERLAY_TEXT_RECORD = values
            acquired_draw.append("text")
        if _OVERLAY_VIEW_HANDLE is None or _OVERLAY_TEXT_HANDLE is None:
            raise RuntimeError("overlay draw handler transaction incomplete")
        _SMART_ID_OVERLAY_RUNTIME_ACTIVE = True
        return True
    except Exception:
        _SMART_ID_OVERLAY_RUNTIME_ACTIVE = False
        # Roll back exactly the callbacks acquired by this call, in reverse order.
        for kind in reversed(acquired_draw):
            if kind == "text":
                if _remove_one_overlay_draw_handler(_OVERLAY_TEXT_RECORD, _OVERLAY_TEXT_HANDLE):
                    _OVERLAY_TEXT_HANDLE = _OVERLAY_TEXT_CALLBACK = _OVERLAY_TEXT_RECORD = None
            else:
                if _remove_one_overlay_draw_handler(_OVERLAY_VIEW_RECORD, _OVERLAY_VIEW_HANDLE):
                    _OVERLAY_VIEW_HANDLE = _OVERLAY_VIEW_CALLBACK = _OVERLAY_VIEW_RECORD = None
        if not handler_was_owned:
            _remove_runtime_handler_exact("depsgraph_update_post", smart_id_overlay_depsgraph_update)
        return False


def remove_overlay_handlers():
    global _OVERLAY_VIEW_HANDLE, _OVERLAY_TEXT_HANDLE
    global _OVERLAY_VIEW_CALLBACK, _OVERLAY_TEXT_CALLBACK
    global _OVERLAY_VIEW_RECORD, _OVERLAY_TEXT_RECORD
    global _SMART_ID_OVERLAY_RUNTIME_ACTIVE
    had_visible_state = bool(
        _SMART_ID_OVERLAY_RUNTIME_ACTIVE
        or _OVERLAY_ACTIVE_RENDER_SNAPSHOT is not None
        or _OVERLAY_VIEW_HANDLE is not None
        or _OVERLAY_TEXT_HANDLE is not None
    )
    # Guard callbacks before native removal; unresolved exact records remain
    # tracked and become harmless no-ops until a later explicit retry.
    _SMART_ID_OVERLAY_RUNTIME_ACTIVE = False
    handler_removed = _remove_runtime_handler_exact(
        "depsgraph_update_post", smart_id_overlay_depsgraph_update
    )
    _cancel_overlay_snapshot_rebuild_timer()
    clear_overlay_snapshot()

    view_removed = _remove_one_overlay_draw_handler(_OVERLAY_VIEW_RECORD, _OVERLAY_VIEW_HANDLE)
    if view_removed:
        _OVERLAY_VIEW_HANDLE = _OVERLAY_VIEW_CALLBACK = _OVERLAY_VIEW_RECORD = None
    text_removed = _remove_one_overlay_draw_handler(_OVERLAY_TEXT_RECORD, _OVERLAY_TEXT_HANDLE)
    if text_removed:
        _OVERLAY_TEXT_HANDLE = _OVERLAY_TEXT_CALLBACK = _OVERLAY_TEXT_RECORD = None
    if had_visible_state:
        tag_redraw_view3d()
    return bool(handler_removed and view_removed and text_removed)

# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------


class SMARTID_OT_entry_multi_select(bpy.types.Operator):
    bl_idname = "smart_id.entry_multi_select"
    bl_label = "Toggle Smart ID Row Selection"
    bl_options = {"INTERNAL"}
    _sms_no_undo = True

    index: IntProperty(name="Index", default=-1, options={"HIDDEN"})
    extend: BoolProperty(name="Range Select", default=False, options={"HIDDEN"})

    @classmethod
    def description(cls, context, properties):
        return desc("operator_entry_multi_select", context)

    def invoke(self, context, event):
        self.extend = bool(getattr(event, "shift", False))
        return self.execute(context)

    def execute(self, context):
        scene = context.scene
        entries = get_entries(scene)
        if not (0 <= self.index < len(entries)):
            return {"CANCELLED"}
        previous_active = int(getattr(scene, "smart_id_active_index", -1))
        scene.smart_id_active_index = self.index
        if self.extend:
            anchor = int(getattr(scene, "smart_id_selection_anchor_index", -1))
            if not (0 <= anchor < len(entries)):
                anchor = previous_active if 0 <= previous_active < len(entries) else self.index
            for idx in visible_range_indices(visible_entry_indices(scene, context), anchor, self.index):
                entries[idx].selected = True
        else:
            entries[self.index].selected = not bool(entries[self.index].selected)
            scene.smart_id_selection_anchor_index = self.index
        get_settings(scene).last_report = t("report_smart_rows_selected").format(count=len(selected_entry_indices(scene)))
        return {"FINISHED"}


class SMARTID_OT_entry_select_visible(bpy.types.Operator):
    bl_idname = "smart_id.entry_select_visible"
    bl_label = "Select Visible Smart ID Rows"
    bl_options = {"INTERNAL"}
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return desc("operator_entry_select_visible", context)

    def execute(self, context):
        scene = context.scene
        entries = get_entries(scene)
        visible = visible_entry_indices(scene, context)
        for idx in visible:
            entries[idx].selected = True
        if visible and not (0 <= getattr(scene, "smart_id_selection_anchor_index", -1) < len(entries)):
            scene.smart_id_selection_anchor_index = visible[0]
        get_settings(scene).last_report = t("report_selected_visible_rows").format(count=len(visible))
        return {"FINISHED"}


class SMARTID_OT_entry_clear_selection(bpy.types.Operator):
    bl_idname = "smart_id.entry_clear_selection"
    bl_label = "Clear Smart ID Row Selection"
    bl_options = {"INTERNAL"}
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return desc("operator_entry_clear_selection", context)

    def execute(self, context):
        scene = context.scene
        for entry in get_entries(scene):
            entry.selected = False
        scene.smart_id_selection_anchor_index = -1
        get_settings(scene).last_report = t("report_cleared_row_selection")
        return {"FINISHED"}


class SMARTID_OT_entry_delete_selected(bpy.types.Operator):
    bl_idname = "smart_id.entry_delete_selected"
    bl_label = "Delete Selected Smart ID Rows"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_entry_delete_selected", context)

    def execute(self, context):
        scene = context.scene
        entries = get_entries(scene)
        indices = selected_entry_indices(scene)
        if not indices:
            self.report({"WARNING"}, t("report_no_rows_selected"))
            return {"CANCELLED"}
        locked = [idx for idx in indices if entries[idx].locked]
        removed = 0
        first_index = min(indices)
        for idx in reversed(indices):
            if entries[idx].locked:
                continue
            entries.remove(idx)
            removed += 1
        scene.smart_id_active_index = min(first_index, len(entries) - 1) if entries else -1
        scene.smart_id_selection_anchor_index = -1
        settings = get_settings(scene)
        settings.last_report = t("report_deleted_selected_rows").format(count=removed)
        if locked:
            self.report({"WARNING"}, t("report_skipped_locked_rows").format(count=len(locked)))
        if removed == 0:
            return {"CANCELLED"}
        return {"FINISHED"}


class SMARTID_OT_inspector_multi_select(bpy.types.Operator):
    bl_idname = "smart_id.inspector_multi_select"
    bl_label = "Toggle Inspector Row Selection"
    bl_options = {"INTERNAL"}
    _sms_no_undo = True

    index: IntProperty(name="Index", default=-1, options={"HIDDEN"})
    extend: BoolProperty(name="Range Select", default=False, options={"HIDDEN"})

    @classmethod
    def description(cls, context, properties):
        return desc("operator_inspector_multi_select", context)

    def invoke(self, context, event):
        self.extend = bool(getattr(event, "shift", False))
        return self.execute(context)

    def execute(self, context):
        scene = context.scene
        items = scene.smart_id_inspector_items
        if not (0 <= self.index < len(items)):
            return {"CANCELLED"}
        previous_active = int(getattr(scene, "smart_id_inspector_active_index", -1))
        scene.smart_id_inspector_active_index = self.index
        if self.extend:
            anchor = int(getattr(scene, "smart_id_inspector_selection_anchor_index", -1))
            if not (0 <= anchor < len(items)):
                anchor = previous_active if 0 <= previous_active < len(items) else self.index
            for idx in visible_range_indices(visible_inspector_indices(scene), anchor, self.index):
                items[idx].selected = True
        else:
            items[self.index].selected = not bool(items[self.index].selected)
            scene.smart_id_inspector_selection_anchor_index = self.index
        get_settings(scene).last_report = t("report_inspector_rows_selected").format(count=len(selected_inspector_indices(scene)))
        return {"FINISHED"}


class SMARTID_OT_inspector_select_visible(bpy.types.Operator):
    bl_idname = "smart_id.inspector_select_visible"
    bl_label = "Select Visible Inspector Rows"
    bl_options = {"INTERNAL"}
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return desc("operator_inspector_select_visible", context)

    def execute(self, context):
        scene = context.scene
        items = scene.smart_id_inspector_items
        visible = visible_inspector_indices(scene)
        for idx in visible:
            items[idx].selected = True
        if visible and not (0 <= getattr(scene, "smart_id_inspector_selection_anchor_index", -1) < len(items)):
            scene.smart_id_inspector_selection_anchor_index = visible[0]
        get_settings(scene).last_report = t("report_selected_visible_inspector_rows").format(count=len(visible))
        return {"FINISHED"}


class SMARTID_OT_inspector_clear_selection(bpy.types.Operator):
    bl_idname = "smart_id.inspector_clear_selection"
    bl_label = "Clear Inspector Row Selection"
    bl_options = {"INTERNAL"}
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return desc("operator_inspector_clear_selection", context)

    def execute(self, context):
        scene = context.scene
        for item in scene.smart_id_inspector_items:
            item.selected = False
        scene.smart_id_inspector_selection_anchor_index = -1
        get_settings(scene).last_report = t("report_cleared_inspector_selection")
        return {"FINISHED"}


class SMARTID_OT_inspector_delete_selected(bpy.types.Operator):
    bl_idname = "smart_id.inspector_delete_selected"
    bl_label = "Delete Selected Inspector Rows"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_inspector_delete_selected", context)

    def execute(self, context):
        scene = context.scene
        items = scene.smart_id_inspector_items
        indices = selected_inspector_indices(scene)
        if not indices:
            self.report({"WARNING"}, t("report_no_inspector_rows_selected"))
            return {"CANCELLED"}
        protected = 0
        removed = 0
        for idx in indices:
            item = items[idx]
            if not item.safe_to_delete:
                protected += 1
                continue
            removed += int(delete_inspector_item(context, item) or 0)
        refresh_selection_inspector(context)
        scene.smart_id_inspector_selection_anchor_index = -1
        settings = get_settings(scene)
        settings.last_report = t("report_deleted_selected_inspector_items").format(count=removed)
        if protected:
            self.report({"WARNING"}, t("report_skipped_protected_rows").format(count=protected))
        if removed == 0:
            return {"CANCELLED"}
        return {"FINISHED"}


class SMARTID_OT_add_entry(bpy.types.Operator):
    bl_idname = "smart_id.add_entry"
    bl_label = "Add Smart ID Entry"
    bl_options = {"UNDO"}

    entry_type: EnumProperty(name=UI_EN["type"], description=DESCRIPTIONS_EN["settings_new_type"], items=ID_TYPE_ITEMS, default="OBJECT_ID")

    @classmethod
    def description(cls, context, properties):
        return desc("operator_add", context)

    def execute(self, context):
        scene = context.scene
        settings = get_settings(scene)
        entry_type = self.entry_type or settings.new_entry_type
        id_number = next_id(scene, entry_type)
        entry = get_entries(scene).add()
        entry.uid = uuid.uuid4().hex
        entry.type = entry_type
        entry.id_number = id_number
        entry.map_channel = max(1, id_number)
        entry.name = default_entry_name(entry_type, id_number, settings.naming_profile)
        generated = profile_channel_name(entry_type, id_number, settings.naming_profile)
        entry.channel_name = generated
        if entry_type == "UV_CHANNEL":
            entry.uv_map = generated
        elif entry_type == "COLOR_ATTRIBUTE":
            entry.color_attribute = generated
            entry.attribute_domain = "CORNER"
        elif entry_type == "GEOMETRY_ATTRIBUTE":
            entry.attribute_name = generated
        elif entry_type in {"SELECTION_SET", "WEIGHT_GROUP"}:
            entry.group_name = generated
        elif entry_type == "UDIM_TILE":
            entry.udim_tile = 1000 + id_number
        if settings.auto_color:
            entry.color = generated_color(id_number)
        scene.smart_id_active_index = len(get_entries(scene)) - 1
        settings.last_report = t("report_added_entry").format(name=entry.name)
        return {"FINISHED"}


class SMARTID_OT_remove_entry(bpy.types.Operator):
    bl_idname = "smart_id.remove_entry"
    bl_label = "Remove Smart ID Entry"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_remove", context)

    def execute(self, context):
        scene = context.scene
        index = scene.smart_id_active_index
        entries = get_entries(scene)
        if not (0 <= index < len(entries)):
            return {"CANCELLED"}
        if entries[index].locked:
            self.report({"WARNING"}, t("report_entry_locked"))
            return {"CANCELLED"}
        entries.remove(index)
        scene.smart_id_active_index = min(index, len(entries) - 1)
        get_settings(scene).last_report = t("report_entry_removed")
        return {"FINISHED"}


class SMARTID_OT_duplicate_entry(bpy.types.Operator):
    bl_idname = "smart_id.duplicate_entry"
    bl_label = "Duplicate Smart ID Entry"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_duplicate", context)

    def execute(self, context):
        scene = context.scene
        sources = active_or_selected_entries(scene)
        if not sources:
            return {"CANCELLED"}
        created = 0
        for source in sources:
            data = entry_to_dict(source)
            data["uid"] = uuid.uuid4().hex
            data["id_number"] = next_id(scene, source.type)
            data["name"] = f"{source.name}_Copy"
            data["locked"] = False
            data["selected"] = False
            entry = get_entries(scene).add()
            entry_from_dict(entry, data)
            created += 1
        scene.smart_id_active_index = len(get_entries(scene)) - 1
        get_settings(scene).last_report = t("report_duplicated_rows").format(count=created)
        return {"FINISHED"}


class SMARTID_OT_move_entry(bpy.types.Operator):
    bl_idname = "smart_id.move_entry"
    bl_label = "Move Smart ID Entry"
    bl_options = {"UNDO"}

    direction: EnumProperty(items=(("UP", "Up", "Move up"), ("DOWN", "Down", "Move down")), default="UP")

    @classmethod
    def description(cls, context, properties):
        return desc("operator_move_up" if getattr(properties, "direction", "UP") == "UP" else "operator_move_down", context)

    def execute(self, context):
        scene = context.scene
        entries = get_entries(scene)
        index = scene.smart_id_active_index
        if self.direction == "UP":
            new_index = index - 1
        else:
            new_index = index + 1
        if not (0 <= index < len(entries)) or not (0 <= new_index < len(entries)):
            return {"CANCELLED"}
        entries.move(index, new_index)
        scene.smart_id_active_index = new_index
        return {"FINISHED"}


class SMARTID_OT_sort_entries(bpy.types.Operator):
    bl_idname = "smart_id.sort_entries"
    bl_label = "Sort Smart ID Entries"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_sort", context)

    def execute(self, context):
        scene = context.scene
        settings = get_settings(scene)
        if settings.sort_mode == "MANUAL":
            return {"CANCELLED"}
        entries = get_entries(scene)
        data = [entry_to_dict(entry) | {"_selected": bool(entry.selected)} for entry in entries]
        if settings.sort_mode == "TYPE_ID":
            data.sort(key=lambda item: (TYPE_ORDER.get(item["type"], 999), item["id_number"], item["name"].lower()))
        elif settings.sort_mode == "ID":
            data.sort(key=lambda item: (item["id_number"], TYPE_ORDER.get(item["type"], 999), item["name"].lower()))
        elif settings.sort_mode == "NAME":
            data.sort(key=lambda item: item["name"].lower())
        entries.clear()
        for item in data:
            entry = entries.add()
            entry_from_dict(entry, item)
            entry.selected = bool(item.get("_selected", False))
        scene.smart_id_active_index = 0 if entries else -1
        settings.last_report = t("report_list_sorted")
        return {"FINISHED"}


class SMARTID_OT_renumber_entries(bpy.types.Operator):
    bl_idname = "smart_id.renumber_entries"
    bl_label = "Renumber Smart ID Entries"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_renumber", context)

    def execute(self, context):
        scene = context.scene
        settings = get_settings(scene)
        value = settings.renumber_start
        count = 0
        selected = selected_entry_indices(scene)
        target_indices = selected if selected else list(range(len(get_entries(scene))))
        visible = set(visible_entry_indices(scene, context))
        # 最後の番号が上限を越えると途中の項目で例外になり、一部だけ番号が変わるので、先に調べて取り消す
        entries = get_entries(scene)
        targets = [index for index in target_indices if not entries[index].locked and index in visible]
        if targets:
            limit = entries[targets[0]].bl_rna.properties["id_number"].hard_max
            if value + settings.renumber_step * (len(targets) - 1) > limit:
                settings.last_report = t("report_invalid_value")
                self.report({"WARNING"}, settings.last_report)
                return {"CANCELLED"}
        for index in target_indices:
            entry = get_entries(scene)[index]
            if entry.locked or index not in visible:
                continue
            entry.id_number = value
            if entry.type == "MAP_CHANNEL":
                entry.map_channel = max(1, value)
            if settings.auto_color:
                entry.color = generated_color(value)
            value += settings.renumber_step
            count += 1
        settings.last_report = t("report_renumbered_entries").format(count=count)
        return {"FINISHED"}


class SMARTID_OT_refresh_counts(bpy.types.Operator):
    bl_idname = "smart_id.refresh_counts"
    bl_label = "Refresh Smart ID Counts"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_refresh", context)

    def execute(self, context):
        added = ensure_library_selection_entries(context, force=True, refresh=False)
        refresh_counts(context.scene, context)
        get_settings(context.scene).last_report = t("report_counts_refreshed_added").format(count=added) if added else t("report_counts_refreshed")
        return {"FINISHED"}


class SMARTID_OT_apply_entry(bpy.types.Operator):
    bl_idname = "smart_id.apply_entry"
    bl_label = "Apply Smart ID Entry"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_apply", context)

    def execute(self, context):
        scene = context.scene
        entries = active_or_selected_entries(scene, include_locked=False, include_disabled=False)
        if not entries:
            return {"CANCELLED"}
        changed = 0
        for entry in entries:
            changed += int(apply_entry(context, entry) or 0)
        refresh_counts(scene)
        refresh_selection_inspector(context)
        get_settings(scene).last_report = t("report_applied_rows_to_targets").format(rows=len(entries), targets=changed)
        if changed == 0:
            self.report({"WARNING"}, t("report_no_targets_changed"))
        return {"FINISHED"}


class SMARTID_OT_select_by_entry(bpy.types.Operator):
    bl_idname = "smart_id.select_by_entry"
    bl_label = "Select by Smart ID Entry"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_select", context)

    def execute(self, context):
        entries = active_or_selected_entries(context.scene)
        if not entries:
            return {"CANCELLED"}
        count = select_objects_matching_entries(context, entries, deselect=False)
        get_settings(context.scene).last_report = t("report_selected_objects_from_rows").format(count=count, rows=len(entries))
        return {"FINISHED"}



class SMARTID_OT_select_entry_elements(bpy.types.Operator):
    bl_idname = "smart_id.select_entry_elements"
    bl_label = "Select Smart ID Elements"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_select_elements", context)

    def execute(self, context):
        entries = active_or_selected_entries(context.scene)
        if not entries:
            return {"CANCELLED"}
        count = select_elements_matching_entries(context, entries, deselect=False)
        get_settings(context.scene).last_report = t("report_selected_matches_from_rows").format(count=count, rows=len(entries))
        if count == 0:
            self.report({"WARNING"}, t("report_no_matching_elements"))
        return {"FINISHED"}


class SMARTID_OT_deselect_by_entry(bpy.types.Operator):
    bl_idname = "smart_id.deselect_by_entry"
    bl_label = "Deselect Smart ID Matches"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_deselect_matches", context)

    def execute(self, context):
        entries = active_or_selected_entries(context.scene)
        if not entries:
            return {"CANCELLED"}
        object_count = select_objects_matching_entries(context, entries, deselect=True)
        element_count = select_elements_matching_entries(context, entries, deselect=True)
        get_settings(context.scene).last_report = t("report_deselected_matches_from_rows").format(count=object_count + element_count, rows=len(entries))
        return {"FINISHED"}


class SMARTID_OT_unassign_entry(bpy.types.Operator):
    bl_idname = "smart_id.unassign_entry"
    bl_label = "Unassign Smart ID from Selection"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_unassign_entry", context)

    def execute(self, context):
        entries = active_or_selected_entries(context.scene, include_locked=False)
        if not entries:
            self.report({"WARNING"}, t("report_no_unlocked_row"))
            return {"CANCELLED"}
        changed = 0
        for entry in entries:
            changed += int(unassign_entry_from_selection(context, entry) or 0)
        refresh_counts(context.scene)
        refresh_selection_inspector(context)
        get_settings(context.scene).last_report = t("report_unassigned_targets_from_rows").format(targets=changed, rows=len(entries))
        if changed == 0:
            self.report({"WARNING"}, t("report_no_matching_assignment_removed"))
        return {"FINISHED"}


class SMARTID_OT_sync_from_selection(bpy.types.Operator):
    bl_idname = "smart_id.sync_from_selection"
    bl_label = "Sync Smart IDs from Selection"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_sync_selected", context)

    def execute(self, context):
        settings = get_settings(context.scene)
        objects = library_scope_objects(context, settings, fallback_to_scene=False)
        if not objects:
            self.report({"WARNING"}, t("report_no_object_to_sync"))
            return {"CANCELLED"}
        added = sync_from_objects(context.scene, objects, include_zero_ids=True, include_zero_material_ids=True, include_collections=True)
        try:
            settings.last_library_autosync_signature = _library_autosync_signature(getattr(settings, "library_scope", "SELECTED"), objects)
        except Exception:
            settings.last_library_autosync_signature = ""
        refresh_counts(context.scene, context)
        refresh_selection_inspector(context)
        settings.last_report = t("report_synced_selected_entries").format(count=added)
        return {"FINISHED"}


class SMARTID_OT_sync_from_scene(bpy.types.Operator):
    bl_idname = "smart_id.sync_from_scene"
    bl_label = "Sync Smart IDs from Scene"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_sync", context)

    def execute(self, context):
        added = sync_from_scene(context.scene)
        refresh_counts(context.scene, context)
        get_settings(context.scene).last_report = t("report_synced_new_entries").format(count=added)
        return {"FINISHED"}


class SMARTID_OT_validate_registry(bpy.types.Operator):
    bl_idname = "smart_id.validate_registry"
    bl_label = "Validate Smart ID Registry"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_validate", context)

    def execute(self, context):
        report, warnings = validate_registry(context.scene)
        if warnings:
            self.report({"WARNING"}, t("report_validation_warnings").format(count=warnings))
        else:
            self.report({"INFO"}, t("report_validation_no_warnings"))
        return {"FINISHED"}


class SMARTID_OT_create_materials(bpy.types.Operator):
    bl_idname = "smart_id.create_materials"
    bl_label = "Create Smart ID Materials"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_create_materials", context)

    def execute(self, context):
        count = 0
        for entry in get_entries(context.scene):
            if entry.type == "MATERIAL_ID" and entry.enabled:
                ensure_id_material(entry)
                count += 1
        refresh_counts(context.scene)
        get_settings(context.scene).last_report = t("report_created_updated_materials").format(count=count)
        return {"FINISHED"}


class SMARTID_OT_channel_apply(bpy.types.Operator):
    bl_idname = "smart_id.channel_apply"
    bl_label = "Create or Activate Smart ID Channel"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_channel_apply", context)

    def execute(self, context):
        allowed = {"MAP_CHANNEL", "UV_CHANNEL", "COLOR_ATTRIBUTE", "GEOMETRY_ATTRIBUTE", "WEIGHT_GROUP", "UDIM_TILE"}
        entries = active_or_selected_entries(context.scene, allowed_types=allowed, include_locked=False, include_disabled=False)
        if not entries:
            self.report({"WARNING"}, t("report_row_not_mesh_channel"))
            return {"CANCELLED"}
        changed = 0
        for entry in entries:
            changed += int(apply_entry(context, entry) or 0)
        refresh_counts(context.scene)
        refresh_selection_inspector(context)
        get_settings(context.scene).last_report = t("report_applied_channel_rows").format(rows=len(entries), objects=changed)
        return {"FINISHED"}


class SMARTID_OT_channel_delete(bpy.types.Operator):
    bl_idname = "smart_id.channel_delete"
    bl_label = "Delete Smart ID Channel"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_channel_delete", context)

    def execute(self, context):
        scene = context.scene
        settings = get_settings(scene)
        allowed = {"MAP_CHANNEL", "UV_CHANNEL", "COLOR_ATTRIBUTE", "GEOMETRY_ATTRIBUTE", "WEIGHT_GROUP", "UDIM_TILE"}
        entries = active_or_selected_entries(scene, allowed_types=allowed, include_locked=False)
        if not entries:
            return {"CANCELLED"}
        removed = 0
        for entry in entries:
            name = resolve_channel_name(entry, settings)
            for obj in mesh_scope(context, settings.target_scope):
                if entry.type in {"MAP_CHANNEL", "UV_CHANNEL"}:
                    had_key = _forget_map_channel_key(obj.data, entry, name)
                    if remove_uv_layer(obj, name) or had_key:
                        removed += 1
                        clear_matching_smart_props(obj.data, entry.type, entry.id_number, entry.uid)
                elif entry.type == "COLOR_ATTRIBUTE":
                    if remove_color_attribute(obj, name):
                        removed += 1
                        clear_matching_smart_props(obj.data, entry.type, entry.id_number, entry.uid)
                elif entry.type == "GEOMETRY_ATTRIBUTE":
                    if remove_geometry_attribute(obj, name):
                        removed += 1
                        clear_matching_smart_props(obj.data, entry.type, entry.id_number, entry.uid)
                elif entry.type == "WEIGHT_GROUP":
                    group = obj.vertex_groups.get(name)
                    if group:
                        obj.vertex_groups.remove(group)
                        removed += 1
                        clear_matching_smart_props(obj, entry.type, entry.id_number, entry.uid)
                elif entry.type == "UDIM_TILE" and obj.data.get(_prop_key("udim_tile")) == entry.udim_tile:
                    del obj.data[_prop_key("udim_tile")]
                    removed += 1
                    clear_matching_smart_props(obj.data, entry.type, entry.id_number, entry.uid)
        refresh_counts(scene)
        refresh_selection_inspector(context)
        settings.last_report = t("report_removed_channels_from_rows").format(count=removed, rows=len(entries))
        return {"FINISHED"}


class SMARTID_OT_read_active(bpy.types.Operator):
    bl_idname = "smart_id.read_active"
    bl_label = "Read Active Selection into Smart ID Entry"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_read_active", context)

    def execute(self, context):
        scene = context.scene
        entry = active_entry(scene)
        obj = context.object
        if not entry or not obj:
            return {"CANCELLED"}
        if entry.type == "OBJECT_ID":
            entry.id_number = int(getattr(obj, "pass_index", entry.id_number))
            entry.name = entry.name or obj.name
        elif entry.type == "MATERIAL_ID" and obj.active_material:
            mat = obj.active_material
            entry.id_number = int(getattr(mat, "pass_index", entry.id_number))
            entry.color = tuple(mat.diffuse_color)
            entry.name = mat.name
        elif obj.type == "MESH":
            mesh = obj.data
            if entry.type in {"MAP_CHANNEL", "UV_CHANNEL"} and mesh.uv_layers.active:
                entry.uv_map = mesh.uv_layers.active.name
                entry.channel_name = mesh.uv_layers.active.name
            elif entry.type == "COLOR_ATTRIBUTE" and mesh.color_attributes.active_color:
                # color_attributes.active is the generic active attribute (position, .corner_edge ...).
                entry.color_attribute = mesh.color_attributes.active_color.name
                entry.channel_name = mesh.color_attributes.active_color.name
                if mesh.color_attributes.active_color.domain in {x[0] for x in ATTRIBUTE_DOMAIN_ITEMS}:
                    entry.attribute_domain = mesh.color_attributes.active_color.domain
            elif entry.type == "GEOMETRY_ATTRIBUTE" and mesh.attributes.active and not mesh.attributes.active.name.startswith("."):
                entry.attribute_name = mesh.attributes.active.name
                entry.channel_name = mesh.attributes.active.name
                if mesh.attributes.active.data_type in {x[0] for x in ATTRIBUTE_TYPE_ITEMS}:
                    entry.attribute_type = mesh.attributes.active.data_type
                if mesh.attributes.active.domain in {x[0] for x in ATTRIBUTE_DOMAIN_ITEMS}:
                    entry.attribute_domain = mesh.attributes.active.domain
            elif entry.type == "WEIGHT_GROUP" and obj.vertex_groups.active:
                entry.group_name = obj.vertex_groups.active.name
                entry.channel_name = obj.vertex_groups.active.name
        get_settings(scene).last_report = t("report_active_data_read")
        return {"FINISHED"}


class SMARTID_OT_create_aov(bpy.types.Operator):
    bl_idname = "smart_id.create_aov"
    bl_label = "Create Smart ID View Layer AOV"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_create_aov", context)

    def execute(self, context):
        entries = active_or_selected_entries(context.scene, allowed_types={"RENDER_AOV"})
        if not entries:
            return {"CANCELLED"}
        changed = 0
        for entry in entries:
            changed += int(create_view_layer_aov(context, entry) or 0)
        get_settings(context.scene).last_report = t("report_created_aovs_from_rows").format(count=changed, rows=len(entries))
        return {"FINISHED"}


class SMARTID_OT_create_collection(bpy.types.Operator):
    bl_idname = "smart_id.create_collection"
    bl_label = "Create Smart ID Selection Collection"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_create_collection", context)

    def execute(self, context):
        entries = active_or_selected_entries(context.scene)
        if not entries:
            return {"CANCELLED"}
        changed = 0
        for entry in entries:
            previous_type = entry.type
            entry.type = "SELECTION_SET"
            changed += int(apply_entry(context, entry) or 0)
            entry.type = previous_type
        refresh_counts(context.scene)
        refresh_selection_inspector(context)
        get_settings(context.scene).last_report = t("report_collection_updated").format(objects=changed, rows=len(entries))
        return {"FINISHED"}



class SMARTID_OT_inspector_refresh(bpy.types.Operator):
    bl_idname = "smart_id.inspector_refresh"
    bl_label = "Refresh Selected Object Data"
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return desc("operator_inspector_refresh", context)

    def execute(self, context):
        count = refresh_selection_inspector(context)
        scene = context.scene
        settings = get_settings(scene)
        total = int(getattr(scene, "smart_id_inspector_total_count", count))
        omitted = int(getattr(scene, "smart_id_inspector_omitted_count", max(0, total - count)))
        if omitted > 0:
            settings.last_report = t("report_inspector_showing_omitted").format(count=count, total=total, omitted=omitted)
            self.report({"WARNING"}, settings.last_report)
        else:
            settings.last_report = t("report_inspector_items").format(count=count)
        return {"FINISHED"}


class SMARTID_OT_inspector_apply(bpy.types.Operator):
    bl_idname = "smart_id.inspector_apply"
    bl_label = "Apply Selected Object Data Settings"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_inspector_apply", context)

    def execute(self, context):
        items = active_or_selected_inspector_items(context.scene)
        if not items:
            return {"CANCELLED"}
        changed = 0
        for item in items:
            changed += int(apply_inspector_item(context, item) or 0)
        refresh_selection_inspector(context)
        get_settings(context.scene).last_report = t("report_inspector_applied_changes").format(count=changed, rows=len(items))
        if changed == 0:
            self.report({"WARNING"}, t("report_no_inspector_data_changed"))
        return {"FINISHED"}


class SMARTID_OT_inspector_delete(bpy.types.Operator):
    bl_idname = "smart_id.inspector_delete"
    bl_label = "Delete or Clear Selected Object Data"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_inspector_delete", context)

    def execute(self, context):
        items = active_or_selected_inspector_items(context.scene)
        if not items:
            return {"CANCELLED"}
        protected = sum(1 for item in items if not item.safe_to_delete)
        removed = 0
        for item in items:
            if item.safe_to_delete:
                removed += int(delete_inspector_item(context, item) or 0)
        refresh_selection_inspector(context)
        get_settings(context.scene).last_report = t("report_inspector_removed_items").format(count=removed, rows=len(items))
        if protected:
            self.report({"WARNING"}, t("report_skipped_protected_rows").format(count=protected))
        if removed == 0:
            self.report({"WARNING"}, t("report_no_inspector_data_removed"))
        return {"FINISHED"}


class SMARTID_OT_inspector_make_entry(bpy.types.Operator):
    bl_idname = "smart_id.inspector_make_entry"
    bl_label = "Create Smart ID Entry from Selected Object Data"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_inspector_make_entry", context)

    def execute(self, context):
        items = active_or_selected_inspector_items(context.scene)
        if not items:
            return {"CANCELLED"}
        created_count = 0
        focused_count = 0
        last_entry = None
        for item in items:
            entry, created = create_entry_from_inspector_item(context, item)
            if entry:
                last_entry = entry
                created_count += int(created)
                focused_count += int(not created)
        if not last_entry:
            return {"CANCELLED"}
        refresh_counts(context.scene)
        get_settings(context.scene).last_report = t("report_created_focused_rows").format(created=created_count, focused=focused_count)
        return {"FINISHED"}


class SMARTID_OT_inspector_select_owner(bpy.types.Operator):
    bl_idname = "smart_id.inspector_select_owner"
    bl_label = "Select Selected Object Data Owner"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_inspector_select_owner", context)

    def execute(self, context):
        items = active_or_selected_inspector_items(context.scene)
        if not items:
            return {"CANCELLED"}
        count = select_inspector_owners(context, items)
        if count == 0:
            return {"CANCELLED"}
        get_settings(context.scene).last_report = t("report_selected_inspector_owners").format(count=count)
        return {"FINISHED"}


class SMARTID_OT_inspector_apply_entry(bpy.types.Operator):
    bl_idname = "smart_id.inspector_apply_entry"
    bl_label = "Apply Active Smart ID Entry to Selected Object Data"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_inspector_apply_entry", context)

    def execute(self, context):
        items = active_or_selected_inspector_items(context.scene)
        entry = active_entry(context.scene)
        if not items or not entry:
            return {"CANCELLED"}
        incompatible = [item for item in items if not inspector_entry_compatible(entry, item)]
        changed = 0
        for item in items:
            if inspector_entry_compatible(entry, item):
                changed += int(apply_active_entry_to_inspector_item(context, item, entry) or 0)
        refresh_selection_inspector(context)
        refresh_counts(context.scene)
        if incompatible:
            self.report({"WARNING"}, t("report_skipped_incompatible_rows").format(count=len(incompatible)))
        get_settings(context.scene).last_report = t("report_applied_active_to_inspector").format(count=changed)
        return {"FINISHED"}



class SMARTID_OT_inspector_select_elements(bpy.types.Operator):
    bl_idname = "smart_id.inspector_select_elements"
    bl_label = "Select Selected Inspector Row Elements"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_inspector_select_elements", context)

    def execute(self, context):
        items = active_or_selected_inspector_items(context.scene)
        if not items:
            return {"CANCELLED"}
        count = select_elements_for_inspector_items(context, items, deselect=False)
        get_settings(context.scene).last_report = t("report_inspector_selected_matches").format(count=count, rows=len(items))
        if count == 0:
            self.report({"WARNING"}, t("report_no_matching_inspector_elements"))
        return {"FINISHED"}


class SMARTID_OT_inspector_assign_selection(bpy.types.Operator):
    bl_idname = "smart_id.inspector_assign_selection"
    bl_label = "Assign Selected Inspector Row to Selection"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_inspector_assign_selection", context)

    def execute(self, context):
        items = active_or_selected_inspector_items(context.scene)
        if not items:
            return {"CANCELLED"}
        changed = 0
        for item in items:
            changed += int(assign_inspector_item_to_selection(context, item) or 0)
        refresh_counts(context.scene)
        refresh_selection_inspector(context)
        get_settings(context.scene).last_report = t("report_inspector_assigned").format(targets=changed, rows=len(items))
        if changed == 0:
            self.report({"WARNING"}, t("report_no_target_received"))
        return {"FINISHED"}


class SMARTID_OT_inspector_unassign_selection(bpy.types.Operator):
    bl_idname = "smart_id.inspector_unassign_selection"
    bl_label = "Unassign Selected Inspector Row from Selection"
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, context, properties):
        return desc("operator_inspector_unassign_selection", context)

    def execute(self, context):
        items = active_or_selected_inspector_items(context.scene)
        if not items:
            return {"CANCELLED"}
        changed = 0
        for item in items:
            changed += int(unassign_inspector_item_from_selection(context, item) or 0)
        refresh_counts(context.scene)
        refresh_selection_inspector(context)
        get_settings(context.scene).last_report = t("report_inspector_unassigned").format(targets=changed, rows=len(items))
        if changed == 0:
            self.report({"WARNING"}, t("report_no_matching_inspector_assignment"))
        return {"FINISHED"}


class SMARTID_OT_toggle_ui_section(bpy.types.Operator):
    bl_idname = "smart_id.toggle_ui_section"
    bl_label = "Toggle Smart ID Section"
    bl_options = {"INTERNAL"}

    section_key: StringProperty(name="Section Key", default="")
    label: StringProperty(name="Label", default="")

    @classmethod
    def description(cls, context, properties):
        return desc("operator_toggle_section", context)

    def execute(self, context):
        settings = get_settings(context.scene)
        key = str(self.section_key or "")
        if not key or not hasattr(settings, key):
            return {"CANCELLED"}
        setattr(settings, key, not bool(getattr(settings, key)))
        return {"FINISHED"}


class SMARTID_OT_open_help(bpy.types.Operator):
    bl_idname = "smart_id.open_help"
    bl_label = "Smart ID Help"
    bl_options = {"INTERNAL"}

    help_key: StringProperty(name="Help Key", default="info_library")
    title_key: StringProperty(name="Title Key", default="help")

    @classmethod
    def description(cls, context, properties):
        return desc("operator_open_help", context)

    def execute(self, context):
        title = t(self.title_key or "help", context)
        text = desc(self.help_key, context) if self.help_key in (DESCRIPTIONS_JA if is_japanese(context) else DESCRIPTIONS_EN) else t(self.help_key, context)
        def draw_popup(self_popup, popup_context):
            col = self_popup.layout.column(align=True)
            col.label(text=title, icon="QUESTION")
            chunks = []
            for paragraph in str(text).splitlines():
                if is_japanese(popup_context):
                    # Japanese often has no spaces, so use fixed-width chunks.
                    chunks.extend(paragraph[i:i + 34] for i in range(0, len(paragraph), 34))
                else:
                    line = ""
                    for word in paragraph.split():
                        candidate = (line + " " + word).strip()
                        if len(candidate) > 58 and line:
                            chunks.append(line)
                            line = word
                        else:
                            line = candidate
                    if line:
                        chunks.append(line)
            for chunk in chunks:
                col.label(text=chunk, translate=False)
        context.window_manager.popup_menu(draw_popup, title=title, icon="QUESTION")
        return {"FINISHED"}


def _atomic_write_text_file(path, text):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    try:
        with temporary.open("w", encoding="utf-8", newline="") as handle:
            handle.write(text)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except OSError:
                pass
        os.replace(temporary, path)
    except Exception:
        try:
            temporary.unlink(missing_ok=True)
        except Exception:
            pass
        raise


class SMARTID_OT_export_json(bpy.types.Operator, ExportHelper):
    bl_idname = "smart_id.export_json"
    bl_label = "Export Smart ID JSON"
    bl_options = set()
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    @classmethod
    def description(cls, context, properties):
        return desc("operator_export_json", context)

    def execute(self, context):
        scene = context.scene
        settings = get_settings(scene)
        entries = [entry_to_dict(entry) for entry in get_entries(scene) if entry.enabled or settings.include_disabled]
        payload = {
            "schema": _REGISTRY_SCHEMA,
            "version": _REGISTRY_VERSION,
            "type": _REGISTRY_PAYLOAD_TYPE,
            "addon": "Smart ID Suite",
            "author": "JELararagi",
            "license": LICENSE_NOTICE,
            "copyright": COPYRIGHT_NOTICE,
            "blender_version_min": "5.1.0",
            "entries": entries,
        }
        try:
            serialized = json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
            _atomic_write_text_file(self.filepath, serialized)
        except Exception as exc:
            message = t("report_json_export_failed").format(error=_render_strict_json_error(exc, context))
            settings.last_report = message
            self.report({"ERROR"}, message)
            return {"CANCELLED"}
        settings.last_report = t("report_exported_entries").format(count=len(entries))
        return {"FINISHED"}


class SMARTID_OT_import_json(bpy.types.Operator, ImportHelper):
    bl_idname = "smart_id.import_json"
    bl_label = "Import Smart ID JSON"
    bl_options = {"UNDO"}
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    @classmethod
    def description(cls, context, properties):
        return desc("operator_import_json", context)

    def execute(self, context):
        scene = context.scene
        settings = get_settings(scene)
        path = Path(self.filepath)
        try:
            payload = _strict_json_loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            message = t("report_json_import_failed", context).format(
                error=_render_strict_json_error(exc, context)
            )
            settings.last_report = message
            self.report({"ERROR"}, message)
            return {"CANCELLED"}

        entries = get_entries(scene)
        clear_existing = bool(getattr(settings, "clear_on_import", False))
        existing_uids = {str(entry.uid) for entry in entries if str(entry.uid)}
        validated, validation_errors = _validate_registry_import_payload(
            payload,
            existing_uids,
            clear_existing=clear_existing,
        )
        if validated is None:
            detail = "; ".join(
                _render_validation_issue(item, context) for item in validation_errors[:4]
            )
            if len(validation_errors) > 4:
                detail += t("report_and_more").format(count=len(validation_errors) - 4)
            message = t("report_json_import_cancelled").format(detail=detail or t("report_invalid_payload"))
            settings.last_report = message
            self.report({"ERROR"}, message)
            return {"CANCELLED"}

        committed, imported_count, commit_note = _commit_registry_import_atomic(
            scene,
            validated,
            clear_existing=clear_existing,
        )
        if not committed:
            message = t("report_json_import_cancelled").format(detail=commit_note or t("report_transaction_failed"))
            settings.last_report = message
            self.report({"ERROR"}, message)
            return {"CANCELLED"}

        # The bank flip above is the single registry commit.  Derived counts and
        # the active-row convenience index are post-commit maintenance; a
        # failure here must not misreport a committed registry as CANCELLED.
        active_entries = get_entries(scene)
        try:
            if not (0 <= int(getattr(scene, "smart_id_active_index", -1)) < len(active_entries)):
                scene.smart_id_active_index = len(active_entries) - 1 if active_entries else -1
        except Exception:
            pass
        maintenance_warning = ""
        try:
            refresh_counts(scene, context)
        except Exception:
            maintenance_warning = t("report_count_refresh_deferred")
        message = t("report_imported_entries").format(count=imported_count, extra=maintenance_warning)
        if commit_note:
            message += f"; {commit_note}"
            self.report({"WARNING"}, message)
        settings.last_report = message
        return {"FINISHED"}



class SMARTID_OT_export_csv(bpy.types.Operator, ExportHelper):
    bl_idname = "smart_id.export_csv"
    bl_label = "Export Smart ID CSV"
    bl_options = set()
    filename_ext = ".csv"
    filter_glob: StringProperty(default="*.csv", options={"HIDDEN"})

    @classmethod
    def description(cls, context, properties):
        return desc("operator_export_csv", context)

    def execute(self, context):
        scene = context.scene
        settings = get_settings(scene)
        rows = [entry_to_dict(entry) for entry in get_entries(scene) if entry.enabled or settings.include_disabled]
        fields = ["uid", "enabled", "locked", "type", "name", "id_number", "map_channel", "channel_name", "uv_map", "color_attribute", "attribute_name", "attribute_type", "attribute_domain", "group_name", "material_name", "udim_tile", "export_tag", "notes"]
        try:
            output = io.StringIO(newline="")
            writer = csv.DictWriter(output, fieldnames=fields)
            writer.writeheader()
            for row in rows:
                writer.writerow({field: row.get(field, "") for field in fields})
            _atomic_write_text_file(self.filepath, output.getvalue())
        except Exception as exc:
            message = t("report_csv_export_failed").format(error=_render_strict_json_error(exc, context))
            settings.last_report = message
            self.report({"ERROR"}, message)
            return {"CANCELLED"}
        settings.last_report = t("report_exported_csv_rows").format(count=len(rows))
        return {"FINISHED"}

# -----------------------------------------------------------------------------
# UI
# -----------------------------------------------------------------------------


class SMARTID_UL_entries(bpy.types.UIList):
    def filter_items(self, context, data, propname):
        entries = getattr(data, propname)
        settings = get_settings(context.scene)
        flags = []
        counts_stale = library_counts_are_stale(context, settings)
        active = active_entry(context.scene)
        for entry in entries:
            visible = entry_visible_in_list(entry, settings, context, counts_stale, active)
            flags.append(self.bitflag_filter_item if visible else 0)
        return flags, []

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        entry = item
        row = layout.row(align=True)
        op = row.operator("smart_id.entry_multi_select", text="", icon="CHECKBOX_HLT" if entry.selected else "CHECKBOX_DEHLT", emboss=False)
        op.index = index
        row.prop(entry, "enabled", text="")
        number = row.row(align=True)
        number.alignment = "LEFT"
        number.label(text=f"{entry.id_number:03d}", icon=TYPE_ICON.get(entry.type, "DOT"))
        wide = _list_is_wide(context)
        name_area = row.split(factor=0.55, align=True) if wide else row.row(align=True)
        display_name = material_entry_display_name(entry) if entry.type == "MATERIAL_ID" else entry.name
        if entry.type == "MATERIAL_ID" and display_name and display_name != entry.name:
            name_area.label(text=display_name, icon="MATERIAL", translate=False)
        else:
            name_area.prop(entry, "name", text="", emboss=False)
        if wide:
            name_area.label(text=t(TYPE_LABEL_KEY.get(entry.type, "custom_id"), context))
        total_count = _entry_total_match_count(entry)
        selected_count = _entry_selected_match_count(entry)
        settings = get_settings(context.scene)
        scoped_targets = _library_scope_has_targets(context, settings)
        count = row.row(align=True)
        count.alignment = "RIGHT"
        if scoped_targets and library_counts_are_stale(context, settings):
            selected_count = "-"
        count.label(text=f"{selected_count}/{total_count}" if scoped_targets else str(total_count), translate=False)
        if entry.locked:
            row.label(text="", icon="LOCKED")


class SMARTID_UL_inspector_items(bpy.types.UIList):
    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        settings = get_settings(context.scene)
        flags = []
        for item in items:
            visible = inspector_item_visible_in_list(item, settings)
            flags.append(self.bitflag_filter_item if visible else 0)
        return flags, []

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        op = row.operator("smart_id.inspector_multi_select", text="", icon="CHECKBOX_HLT" if item.selected else "CHECKBOX_DEHLT", emboss=False)
        op.index = index
        item_icon = INSPECTOR_TYPE_ICON.get(item.item_type, "DOT")
        if item.item_type == "MATERIAL_ID" and item.owner_data == "MATERIAL_SLOT":
            name_text = item.material_name or _inspector_name_display_text(item, context) or "-"
        else:
            name_text = _inspector_name_display_text(item, context) or "-"
        value = _inspector_value_display_text(item, context)
        if _list_is_wide(context):
            row.label(text="", icon=item_icon)
            split = row.split(factor=0.3, align=True)
            split.label(text=item.owner_object or "-", translate=False)
            split = split.split(factor=0.45, align=True)
            split.label(text=name_text, translate=False)
            split.label(text=value, translate=False)
        else:
            text = row.column(align=True)
            for i, line in enumerate(_wrapped_lines(context, name_text, first_line_icon=True, max_width=115)):
                text.label(text=line, icon=item_icon if i == 0 else "NONE", translate=False)
            for line in _wrapped_lines(context, value, max_width=115):
                text.label(text=line, translate=False)
        if not item.safe_to_delete:
            row.label(text="", icon="LOCKED")




def _safe_icon_name(name, default="NONE"):
    value = str(name or "").strip()
    return value if value else default


def _set_op_props(op, **props):
    if op is None:
        return op
    for key, value in props.items():
        try:
            setattr(op, key, value)
        except Exception:
            pass
    return op


def _button_flow(layout, columns=0):
    """Buttons share a row only when every label fits; otherwise they stack."""
    return layout.grid_flow(row_major=True, columns=columns, even_columns=True, even_rows=False, align=True)


def _stacked_prop(layout, data, prop_name, label):
    """Long labels go above the field so neither is cut off at the default width."""
    col = layout.column(align=True)
    col.label(text=label)
    col.prop(data, prop_name, text="")
    return col


def _wrapped_lines(context, text, first_line_icon=False, *, max_width=None):
    """Split a message into lines that fit the sidebar; Japanese text has no spaces to break at."""
    scale = context.preferences.system.ui_scale
    width = max(60.0, context.region.width - 90.0 * scale)
    if max_width is not None:
        width = min(width, max_width * scale)
    icon_width = 20.0 * scale if first_line_icon else 0.0
    blf.size(0, 11.0 * scale)
    lines = []
    line = ""
    for char in str(text):
        limit = width if lines else width - icon_width
        if line and char not in "。、」）" and blf.dimensions(0, line + char)[0] > limit:
            cut = line.rfind(" ")
            if cut > len(line) // 2:
                lines.append(line[:cut])
                line = line[cut + 1:]
            else:
                lines.append(line)
                line = ""
        line += char
    if line:
        lines.append(line)
    return lines


def _list_is_wide(context):
    """True when the sidebar has been widened enough for the optional list columns."""
    try:
        return context.region.width / context.preferences.system.ui_scale >= 340
    except Exception:
        return False


def _help_button(layout, context, title_key, help_key):
    try:
        op = layout.operator("smart_id.open_help", text="", icon="QUESTION", emboss=True)
    except TypeError:
        op = layout.operator("smart_id.open_help", text="?")
    _set_op_props(op, title_key=title_key, help_key=help_key)
    return op


def _narrow_text_sidebar(context):
    return _context_physical_space_type(context) == "TEXT_EDITOR" and not _list_is_wide(context)


def _draw_section_header(layout, context, settings, prop_name, label_key, icon, help_key, *, container=None):
    expanded = bool(getattr(settings, prop_name, False))
    box = container if container is not None else layout.box()
    row = box.row(align=True)
    row.use_property_split = False
    row.use_property_decorate = False
    tri_icon = "TRIA_DOWN" if expanded else "TRIA_RIGHT"
    try:
        op = row.operator("smart_id.toggle_ui_section", text="", icon=tri_icon, emboss=True, depress=expanded)
    except TypeError:
        op = row.operator("smart_id.toggle_ui_section", text="", icon=tri_icon)
    _set_op_props(op, section_key=prop_name, label=t(label_key, context))
    title = t(label_key, context)
    # Shared Smart Tools section header: triangle, borderless icon+title, small gap, compact help.
    try:
        op = row.operator("smart_id.toggle_ui_section", text=title, icon=_safe_icon_name(icon, "PROPERTIES"), emboss=False, depress=expanded, translate=False)
    except TypeError:
        op = row.operator("smart_id.toggle_ui_section", text=title, icon=_safe_icon_name(icon, "PROPERTIES"), emboss=False, translate=False)
    _set_op_props(op, section_key=prop_name, label=title)
    try:
        row.separator(factor=0.35)
    except Exception:
        pass
    help_row = row.row(align=True)
    help_row.scale_x = 0.82
    _help_button(help_row, context, label_key, help_key)
    return box, expanded


def _draw_library_body(layout, context):
    scene = context.scene
    settings = get_settings(scene)
    filter_box = layout.box()
    col = _stacked_prop(filter_box, settings, "filter_type", t("filter_type", context))
    col.prop(settings, "search", text="", icon="VIEWZOOM")
    col = filter_box.column(align=True)
    col.label(text=t("library_scope", context))
    row = col.row(align=True)
    row.prop(settings, "library_scope", text="")
    scope = str(getattr(settings, "library_scope", "SELECTED"))
    if scope == "ACTIVE":
        scoped_count = 1 if context_active_object(context) is not None else 0
    elif scope == "SCENE":
        scoped_count = len(getattr(scene, "objects", ()) or ())
    else:
        scoped_count = len(getattr(context, "selected_objects", ()) or ())
    count = row.row(align=True)
    count.ui_units_x = 2.0
    count.label(text=f"{scoped_count}", icon="RESTRICT_SELECT_OFF" if scoped_count else "BLANK1")
    col = filter_box.column(align=True)
    col.label(text=t("new_type", context))
    row = col.row(align=True)
    row.prop(settings, "new_entry_type", text="")
    add = row.row(align=True)
    add.alignment = "RIGHT"
    op = add.operator("smart_id.add_entry", text=t("add", context), icon="ADD")
    op.entry_type = settings.new_entry_type

    col = layout.column(align=True)
    col.template_list("SMARTID_UL_entries", "", scene, _registry_collection_name(scene), scene, "smart_id_active_index", rows=8)
    row = col.row(align=True)
    row.operator("smart_id.remove_entry", text="", icon="REMOVE")
    row.operator("smart_id.duplicate_entry", text="", icon="DUPLICATE")
    op = row.operator("smart_id.move_entry", text="", icon="TRIA_UP")
    op.direction = "UP"
    op = row.operator("smart_id.move_entry", text="", icon="TRIA_DOWN")
    op.direction = "DOWN"
    row.operator("smart_id.refresh_counts", text="", icon="FILE_REFRESH")
    if library_counts_are_stale(context, settings):
        col.operator("smart_id.refresh_counts", text=t("refresh_selection_changed", context), icon="FILE_REFRESH")

    multi = layout.box()
    multi.label(text=f"{t('selected_count', context)}: {len(selected_entry_indices(scene))}", icon="CHECKBOX_HLT")
    row = multi.column(align=True)
    row.operator("smart_id.entry_select_visible", text=t("select_visible", context), icon="CHECKBOX_HLT")
    row.operator("smart_id.entry_clear_selection", text=t("clear_selection", context), icon="X")
    multi.operator("smart_id.entry_delete_selected", text=t("delete_selected", context), icon="TRASH")

    ops = _button_flow(layout)
    ops.operator("smart_id.apply_entry", text=t("apply", context), icon="CHECKMARK")
    ops.operator("smart_id.select_by_entry", text=t("select", context), icon="RESTRICT_SELECT_OFF")
    ops.operator("smart_id.sync_from_selection", text=t("sync_selected", context), icon="RESTRICT_SELECT_OFF")
    ops.operator("smart_id.sync_from_scene", text=t("sync", context), icon="FILE_REFRESH")
    ops = layout.row(align=True)
    ops.operator("smart_id.validate_registry", text=t("validate", context), icon="VIEWZOOM")


def _draw_entry_details_body(layout, context):
    scene = context.scene
    settings = get_settings(scene)
    entry = active_entry(scene)
    if not entry:
        layout.label(text=t("no_entry", context))
        return
    col = layout.column(align=True)
    row = col.row(align=True)
    row.prop(entry, "enabled", text=t("enabled", context))
    row.prop(entry, "locked", text=t("locked", context))
    col.prop(entry, "type", text=t("type", context))
    col.prop(entry, "name", text=t("name", context))
    col.prop(entry, "id_number", text=t("id_number", context))
    col.prop(entry, "color", text=t("color", context))

    box = layout.box()
    box.label(text=t(TYPE_LABEL_KEY.get(entry.type, "custom_id"), context), icon=TYPE_ICON.get(entry.type, "PROPERTIES"))
    if entry.type == "MAP_CHANNEL":
        _stacked_prop(box, entry, "map_channel", t("map_channel", context))
        _stacked_prop(box, entry, "channel_name", t("channel_name", context))
        _stacked_prop(box, entry, "uv_map", t("uv_map", context))
    elif entry.type == "UV_CHANNEL":
        _stacked_prop(box, entry, "uv_map", t("uv_map", context))
        _stacked_prop(box, entry, "channel_name", t("channel_name", context))
    elif entry.type == "COLOR_ATTRIBUTE":
        _stacked_prop(box, entry, "color_attribute", t("color_attribute", context))
        _stacked_prop(box, entry, "attribute_domain", t("attribute_domain", context))
    elif entry.type == "GEOMETRY_ATTRIBUTE":
        _stacked_prop(box, entry, "attribute_name", t("attribute_name", context))
        _stacked_prop(box, entry, "attribute_type", t("attribute_type", context))
        _stacked_prop(box, entry, "attribute_domain", t("attribute_domain", context))
    elif entry.type in {"SELECTION_SET", "WEIGHT_GROUP"}:
        _stacked_prop(box, entry, "group_name", t("group_name", context))
        _stacked_prop(box, entry, "channel_name", t("channel_name", context))
    elif entry.type == "UDIM_TILE":
        _stacked_prop(box, entry, "udim_tile", t("udim_tile", context))
        _stacked_prop(box, entry, "channel_name", t("channel_name", context))
    elif entry.type in {"RENDER_AOV", "CRYPTOMATTE_ID", "CUSTOM_ID"}:
        _stacked_prop(box, entry, "channel_name", t("channel_name", context))
    _stacked_prop(box, entry, "export_tag", t("export_tag", context))
    _stacked_prop(box, entry, "notes", t("notes", context))

    counts = layout.column(align=True)
    counts.label(text=t("scene_matches", context))
    counts.label(text=f"{t('object_count', context)}: {entry.count_objects}")
    counts.label(text=f"{t('material_count', context)}: {entry.count_materials}")
    counts.label(text=f"{t('channel_count', context)}: {entry.count_channels}")
    if str(getattr(settings, "library_scope", "SELECTED")) == "ACTIVE":
        has_scoped_targets = context_active_object(context) is not None
    elif str(getattr(settings, "library_scope", "SELECTED")) == "SCENE":
        has_scoped_targets = bool(len(getattr(scene, "objects", ()) or ()))
    else:
        has_scoped_targets = bool(getattr(context, "selected_objects", ()) or ())
    if has_scoped_targets and not library_counts_are_stale(context, settings):
        counts = layout.column(align=True)
        counts.label(text=t("selection_matches", context))
        counts.label(text=f"{t('object_count', context)}: {entry.count_selected_objects}")
        counts.label(text=f"{t('material_count', context)}: {entry.count_selected_materials}")
        counts.label(text=f"{t('channel_count', context)}: {entry.count_selected_channels}")


def _draw_assignment_body(layout, context):
    scene = context.scene
    settings = get_settings(scene)
    _stacked_prop(layout, settings, "target_scope", t("scope", context))
    _stacked_prop(layout, settings, "material_mode", t("material_mode", context))
    col = layout.column(align=True)
    col.prop(settings, "use_pass_index", text=t("use_pass_index", context))
    col.prop(settings, "write_custom_props", text=t("write_custom_props", context))
    col.prop(settings, "create_missing_material", text=t("create_missing_material", context))
    col.prop(settings, "select_faces", text=t("select_faces", context))
    row = _button_flow(layout)
    row.operator("smart_id.apply_entry", text=t("apply", context), icon="CHECKMARK")
    row.operator("smart_id.unassign_entry", text=t("unassign_from_selection", context), icon="X")
    row.operator("smart_id.create_materials", text=t("create_materials", context), icon="MATERIAL")
    row.operator("smart_id.create_collection", text=t("create_selection_collection", context), icon="OUTLINER_COLLECTION")


def _draw_selection_actions_body(layout, context):
    scene = context.scene
    entry = active_entry(scene)
    box = layout.box()
    box.label(text=t("global_list_actions", context), icon="ASSET_MANAGER")
    if entry:
        box.label(text=material_entry_display_name(entry) if entry.type == "MATERIAL_ID" else entry.name, icon=TYPE_ICON.get(entry.type, "DOT"), translate=False)
    else:
        box.label(text=t("no_entry", context))
    row = _button_flow(box)
    row.operator("smart_id.select_by_entry", text=t("select_objects", context), icon="RESTRICT_SELECT_OFF")
    row.operator("smart_id.select_entry_elements", text=t("select_elements", context), icon="EDITMODE_HLT")
    row.operator("smart_id.apply_entry", text=t("apply", context), icon="CHECKMARK")
    row.operator("smart_id.unassign_entry", text=t("unassign_from_selection", context), icon="X")
    box.operator("smart_id.deselect_by_entry", text=t("deselect_matches", context), icon="RESTRICT_SELECT_ON")

    item = active_inspector_item(scene)
    box = layout.box()
    box.label(text=t("inspector_list_actions", context), icon="VIEWZOOM")
    if item:
        box.label(text=f"{item.owner_object or '-'} / {_inspector_name_display_text(item, context) or '-'}", icon=INSPECTOR_TYPE_ICON.get(item.item_type, "DOT"), translate=False)
    else:
        col = box.column(align=True)
        for line in _wrapped_lines(context, t("inspector_no_item", context)):
            col.label(text=line, translate=False)
    row = _button_flow(box)
    row.operator("smart_id.inspector_select_owner", text=t("inspector_select_owner", context), icon="RESTRICT_SELECT_OFF")
    row.operator("smart_id.inspector_select_elements", text=t("inspector_select_elements", context), icon="EDITMODE_HLT")
    row.operator("smart_id.inspector_assign_selection", text=t("inspector_assign_selection", context), icon="CHECKMARK")
    row.operator("smart_id.inspector_unassign_selection", text=t("inspector_unassign_selection", context), icon="X")


def _draw_channel_tools_body(layout, context):
    scene = context.scene
    settings = get_settings(scene)
    _stacked_prop(layout, settings, "naming_profile", t("naming_profile", context))
    _stacked_prop(layout, settings, "target_scope", t("scope", context))
    row = _button_flow(layout)
    row.operator("smart_id.channel_apply", text=t("apply_channel", context), icon="ADD")
    row.operator("smart_id.channel_delete", text=t("delete_channel", context), icon="TRASH")
    row.operator("smart_id.create_aov", text=t("create_aov", context), icon="RENDERLAYERS")
    row.operator("smart_id.read_active", text=t("copy_active_to_entry", context), icon="EYEDROPPER")


def _draw_inspector_body(layout, context):
    scene = context.scene
    settings = get_settings(scene)
    _stacked_prop(layout, settings, "inspector_scope", t("inspector_scope", context))
    _stacked_prop(layout, settings, "inspector_filter_type", t("inspector_filter", context))
    _stacked_prop(layout, settings, "inspector_search", t("inspector_search", context))
    layout.operator("smart_id.inspector_refresh", text=t("inspector_refresh", context), icon="FILE_REFRESH")
    selected_count = 0
    selected_name_preview = []
    if str(getattr(settings, "inspector_scope", "SELECTED")) == "ACTIVE":
        active = context_active_object(context)
        if active is not None:
            selected_count = 1
            selected_name_preview.append(str(getattr(active, "name", "")))
    else:
        try:
            selected_objects = getattr(context, "selected_objects", ()) or ()
        except Exception:
            selected_objects = ()
        for obj in selected_objects:
            if obj is None:
                continue
            selected_count += 1
            if len(selected_name_preview) < 6:
                selected_name_preview.append(str(getattr(obj, "name", "")))
    if selected_count:
        name_text = ", ".join(selected_name_preview)
        if selected_count > len(selected_name_preview):
            name_text += "…"
        layout.label(text=f"{t('selected_objects_in_inspector', context)}: {selected_count} / {name_text}", icon="OBJECT_DATA", translate=False)

    if bool(getattr(scene, "smart_id_inspector_truncated", False)):
        shown = len(getattr(scene, "smart_id_inspector_items", ()))
        total = int(getattr(scene, "smart_id_inspector_total_count", shown))
        omitted = int(getattr(scene, "smart_id_inspector_omitted_count", max(0, total - shown)))
        col = layout.column(align=True)
        for number, line in enumerate(_wrapped_lines(context, t("inspector_truncated", context).format(shown=shown, total=total, omitted=omitted), first_line_icon=True)):
            col.label(text=line, icon="ERROR" if number == 0 else "NONE", translate=False)

    col = layout.column(align=True)
    col.template_list("SMARTID_UL_inspector_items", "", scene, "smart_id_inspector_items", scene, "smart_id_inspector_active_index", rows=7)
    row = col.row(align=True)
    row.operator("smart_id.inspector_select_owner", text="", icon="RESTRICT_SELECT_OFF")
    row.operator("smart_id.inspector_select_elements", text="", icon="EDITMODE_HLT")
    row.operator("smart_id.inspector_make_entry", text="", icon="ADD")
    row.operator("smart_id.inspector_apply", text="", icon="CHECKMARK")
    row.operator("smart_id.inspector_delete", text="", icon="TRASH")

    multi = layout.box()
    multi.label(text=f"{t('selected_count', context)}: {len(selected_inspector_indices(scene))}", icon="CHECKBOX_HLT")
    row = _button_flow(multi, columns=2)
    row.operator("smart_id.inspector_select_visible", text=t("select_visible", context), icon="CHECKBOX_HLT")
    row.operator("smart_id.inspector_clear_selection", text=t("clear_selection", context), icon="X")
    multi.operator("smart_id.inspector_delete_selected", text=t("delete_selected", context), icon="TRASH")

    item = active_inspector_item(scene)
    if not item:
        col = layout.column(align=True)
        for line in _wrapped_lines(context, t("inspector_no_item", context)):
            col.label(text=line, translate=False)
        return

    box = layout.box()
    box.label(text=t("inspector_item_details", context), icon=INSPECTOR_TYPE_ICON.get(item.item_type, "DOT"))
    box.label(text=f"{t('type', context)}: {t(INSPECTOR_TYPE_LABEL_KEY.get(item.item_type, 'custom_id'), context)}")
    box.label(text=f"{t('inspector_owner_object', context)}: {item.owner_object or '-'}", translate=False)
    box.label(text=f"{t('inspector_owner_data', context)}: {_inspector_enum_label('owner_data', item.owner_data, context) or '-'}")
    if item.slot_index >= 0:
        box.label(text=f"{t('inspector_slot_index', context)}: {item.slot_index}")
    if item.material_name:
        box.label(text=f"{t('material_id', context)}: {item.material_name}", translate=False)
    if item.collection_name:
        box.label(text=f"{t('selection_set', context)}: {item.collection_name}", translate=False)

    _stacked_prop(box, item, "edit_name", t("inspector_edit_name", context))
    editable = box.column(align=True)
    if item.item_type in {"OBJECT_ID", "MATERIAL_ID", "MAP_CHANNEL", "UDIM_TILE", "SMART_METADATA"}:
        editable.prop(item, "id_number", text=t("id_number", context))
    if item.item_type == "MAP_CHANNEL":
        editable.prop(item, "map_channel", text=t("map_channel", context))
    if item.item_type in {"OBJECT_ID", "MATERIAL_ID"}:
        editable.prop(item, "color", text=t("color", context))
    if item.item_type in {"MATERIAL_ID", "UV_CHANNEL", "MAP_CHANNEL", "COLOR_ATTRIBUTE", "GEOMETRY_ATTRIBUTE", "WEIGHT_GROUP", "SELECTION_SET"}:
        editable.prop(item, "active", text=t("inspector_active", context))
    if item.item_type in {"UV_CHANNEL", "MAP_CHANNEL"}:
        editable.prop(item, "render", text=t("inspector_render", context))
    if item.data_type:
        box.label(text=f"{t('inspector_data_type', context)}: {_inspector_data_type_display_text(item, context)}")
    if item.domain:
        box.label(text=f"{t('inspector_domain', context)}: {_inspector_enum_label('attr_domain', item.domain, context)}")
    if item.value_text:
        box.label(text=f"{t('inspector_value', context)}: {_inspector_value_display_text(item, context)}")
    if item.details:
        box.label(text=_inspector_details_display_text(item, context), translate=False)
    if not item.safe_to_delete:
        box.label(text=t("inspector_protected", context), icon="LOCKED")

    row = _button_flow(layout)
    row.operator("smart_id.inspector_apply", text=t("inspector_apply", context), icon="CHECKMARK")
    row.operator("smart_id.inspector_apply_entry", text=t("inspector_apply_entry", context), icon="FORWARD")
    row.operator("smart_id.inspector_make_entry", text=t("inspector_make_entry", context), icon="ADD")
    row.operator("smart_id.inspector_delete", text=t("inspector_delete", context), icon="TRASH")


def _draw_overlay_body(layout, context):
    scene = context.scene
    settings = get_settings(scene)
    _stacked_prop(layout, settings, "overlay_source", t("overlay_source", context))
    row = _button_flow(layout, columns=2)
    row.prop(settings, "overlay_show_ids", text=t("overlay_show_ids", context), toggle=True)
    row.prop(settings, "overlay_show_channels", text=t("overlay_show_channels", context), toggle=True)
    row.prop(settings, "overlay_show_groups", text=t("overlay_show_groups", context), toggle=True)
    row.prop(settings, "overlay_show_labels", text=t("overlay_show_labels", context), toggle=True)
    row.prop(settings, "overlay_object_boxes", text=t("overlay_object_boxes", context), toggle=True)
    row.prop(settings, "overlay_element_marks", text=t("overlay_element_marks", context), toggle=True)
    col = layout.column(align=True)
    col.prop(settings, "overlay_alpha", text=t("overlay_alpha", context))
    col.prop(settings, "overlay_line_width", text=t("overlay_line_width", context))
    layout.label(text=t("overlay_status_on" if settings.overlay_enabled else "overlay_status_off", context), icon="OVERLAY" if settings.overlay_enabled else "HIDE_ON")


def _draw_validation_body(layout, context):
    scene = context.scene
    settings = get_settings(scene)
    _stacked_prop(layout, settings, "sort_mode", t("sort_mode", context))
    col = layout.column(align=True)
    col.prop(settings, "renumber_start", text=t("renumber_start", context))
    col.prop(settings, "renumber_step", text=t("renumber_step", context))
    row = layout.row(align=True)
    row.operator("smart_id.sort_entries", text=t("sort", context), icon="SORT_ASC")
    row.operator("smart_id.renumber_entries", text=t("renumber", context), icon="LINENUMBERS_ON")
    col = layout.column(align=True)
    col.prop(settings, "include_disabled", text=t("include_disabled", context))
    col.prop(settings, "clear_on_import", text=t("clear_on_import", context))
    row = layout.row(align=True)
    row.operator("smart_id.validate_registry", text=t("validate", context), icon="VIEWZOOM")
    row.operator("smart_id.refresh_counts", text=t("refresh", context), icon="FILE_REFRESH")
    row = layout.row(align=True)
    row.operator("smart_id.export_json", text=t("export_json", context), icon="EXPORT")
    row.operator("smart_id.import_json", text=t("import_json", context), icon="IMPORT")
    layout.operator("smart_id.export_csv", text=t("export_csv", context), icon="TEXT")
    if settings.last_report and settings.last_report_language == _report_language(context):
        col = layout.column(align=True)
        col.label(text=t("last_report", context))
        for line in _wrapped_lines(context, settings.last_report):
            col.label(text=line, translate=False)


UI_EN.update({
    "always_on_toggles": "Always-on Toggles",
    "n_panel_state_save": "N-panel State Save",
    "selection_inspector_auto_refresh": "Selection Inspector Auto Refresh",
    "automatic_metadata_cleanup": "Automatic Metadata Cleanup",
    "disabled": "Disabled",
    "always_on_on": "On",
    "always_on_off": "Off",
    "restart_required": "Restart Required",
    "restart_required_title": "RESTART REQUIRED",
    "restart_required_reason": "Smart ID was enabled in safe mode because registered Blender resources are owned by another identity.",
    "restart_required_action": "Restart Blender before using Smart ID. Foreign classes, properties and callbacks were not changed.",
    "restart_required_conflicts": "Conflicting resources",
})
UI_JA.update({
    "always_on_toggles": "常時機能切り替え",
    "n_panel_state_save": "Nパネル状態保存",
    "selection_inspector_auto_refresh": "検査の自動更新",
    "automatic_metadata_cleanup": "メタデータ自動整理",
    "disabled": "無効",
    "always_on_on": "有効",
    "always_on_off": "無効",
    "restart_required": "再起動が必要",
    "restart_required_title": "再起動が必要です",
    "restart_required_reason": "別のアドオンが所有するBlenderのリソースが登録済みのため、Smart IDを安全なモードで有効にしました。",
    "restart_required_action": "Smart IDを使う前にBlenderを再起動してください。他のアドオンのクラス・プロパティ・コールバックは変更していません。",
    "restart_required_conflicts": "競合リソース",
})
DESCRIPTIONS_EN["info_always_on"] = "Controls every Smart ID feature that remains active outside an explicit command. Disable every runtime row for zero recurring Smart ID work."
DESCRIPTIONS_JA["info_always_on"] = "明示的なコマンド実行外でも動作を継続するSmart ID機能をすべて管理します。全ランタイム項目を無効にするとSmart IDの反復処理はゼロになります。"


def _draw_runtime_toggle_row(layout, context, settings, property_name, label_key, icon="CHECKBOX_HLT"):
    enabled = bool(getattr(settings, property_name, False))
    label = t(label_key, context)
    # Shared Smart Tools always-on row: label on the left, right-aligned Enabled/Disabled toggle.
    row = layout.row(align=True)
    row.scale_y = 0.95
    split = row.split(factor=0.72, align=True)
    left = split.row(align=True)
    left.label(text=label)
    right = split.row(align=True)
    right.alignment = "RIGHT"
    right.use_property_split = False
    right.use_property_decorate = False
    right.row(align=True).prop(
        settings,
        property_name,
        text=t("always_on_on", context) if enabled else t("always_on_off", context),
        icon="CHECKBOX_HLT" if enabled else "CHECKBOX_DEHLT",
        toggle=True,
    )


def _draw_always_on_body(layout, context):
    settings = get_settings(context.scene)
    # Canonical first row across every SmartTools N-panel.
    _draw_runtime_toggle_row(layout, context, settings, "n_panel_state_save", "n_panel_state_save")
    layout.separator(factor=0.5)
    _draw_runtime_toggle_row(layout, context, settings, "always_on_selection_inspector", "selection_inspector_auto_refresh")
    _draw_runtime_toggle_row(layout, context, settings, "always_on_automatic_metadata_cleanup", "automatic_metadata_cleanup")
    _draw_runtime_toggle_row(layout, context, settings, "overlay_enabled", "overlay_enabled")


_SECTION_DEFS = (
    ("ui_section_always_on", "always_on_toggles", "TIME", "info_always_on", _draw_always_on_body),
    ("ui_section_library", "section_library", "ASSET_MANAGER", "info_library", _draw_library_body),
    ("ui_section_entry_details", "section_entry_details", "PROPERTIES", "entry_name", _draw_entry_details_body),
    ("ui_section_assignment", "section_assignment", "CHECKMARK", "info_assignment", _draw_assignment_body),
    ("ui_section_selection_actions", "section_selection_actions", "RESTRICT_SELECT_OFF", "info_selection_actions", _draw_selection_actions_body),
    ("ui_section_channel_tools", "section_channel_tools", "UV", "info_channels", _draw_channel_tools_body),
    ("ui_section_selection_inspector", "section_selection_inspector", "VIEWZOOM", "info_inspector", _draw_inspector_body),
    ("ui_section_visual_overlay", "section_visual_overlay", "SHADING_TEXTURE", "info_overlay", _draw_overlay_body),
    ("ui_section_validation_io", "section_validation_io", "EXPORT", "info_io", _draw_validation_body),
)


_SMART_TOOLS_MANAGER_TOOL_KEY = "SMART_ID"
_SMART_TOOLS_LOGICAL_EDITOR_TO_SPACE = {
    "VIEW_3D": "VIEW_3D",
    "IMAGE_EDITOR": "IMAGE_EDITOR",
    "UV_EDITOR": "IMAGE_EDITOR",
    "SHADER_EDITOR": "NODE_EDITOR",
    "COMPOSITOR": "NODE_EDITOR",
    "GEOMETRY_NODE_EDITOR": "NODE_EDITOR",
    "TEXTURE_NODE_EDITOR": "NODE_EDITOR",
    "VIDEO_SEQUENCER": "SEQUENCE_EDITOR",
    "MOVIE_CLIP_EDITOR": "CLIP_EDITOR",
    "DOPE_SHEET": "DOPESHEET_EDITOR",
    "GRAPH_EDITOR": "GRAPH_EDITOR",
    "DRIVERS": "GRAPH_EDITOR",
    "NLA_EDITOR": "NLA_EDITOR",
    "TEXT_EDITOR": "TEXT_EDITOR",
    "ASSET_BROWSER": "FILE_BROWSER",
    "FILE_BROWSER": "FILE_BROWSER",
    "SPREADSHEET": "SPREADSHEET",
}
_SMART_TOOLS_PHYSICAL_SPACES = (
    "VIEW_3D",
    "IMAGE_EDITOR",
    "NODE_EDITOR",
    "SEQUENCE_EDITOR",
    "CLIP_EDITOR",
    "DOPESHEET_EDITOR",
    "GRAPH_EDITOR",
    "NLA_EDITOR",
    "TEXT_EDITOR",
    "FILE_BROWSER",
    "SPREADSHEET",
)
_SMART_TOOLS_MANAGER_MODULE_NAMES = (
    "bl_ext.user_default.smart_tools_manager",
    "smart_tools_manager",
)


def _manager_loaded_placement_allowed():
    """Return the already-loaded Manager package's pure placement API.

    This is deliberately a fixed two-key ``sys.modules.get`` lookup.  It does
    not import, reload, scan modules, read driver_namespace, access settings,
    perform file I/O, start timers, request redraws, mutate Manager state, or
    retain a Suite-side placement cache.  ``vars(module)`` avoids invoking a
    module-level ``__getattr__`` that could lazily import or repair state.
    """
    modules = sys.modules
    for module_name in _SMART_TOOLS_MANAGER_MODULE_NAMES:
        module = modules.get(module_name)
        if module is None:
            continue
        try:
            callback = vars(module).get("placement_allowed")
        except Exception:
            callback = None
        # The first loaded fixed-name package is the authority candidate.
        # A loaded-but-not-ready package must fail open instead of falling
        # through to a potentially stale alias from another generation.
        return callback if callable(callback) else None
    return None


def _call_manager_placement_allowed(callback, context, editor_key):
    return callback(_SMART_TOOLS_MANAGER_TOOL_KEY, context, editor_key=editor_key)


def _smart_id_root_panel_placement_allowed(context, editor_key):
    """Return the current Manager cell decision without poll-time mutation.

    Smart ID itself validates the exact logical/physical classification and
    fails closed for an invalid key or editor mismatch.  A missing/disabled
    Manager, an API that is genuinely not ready, an exception, or a non-bool
    result has no verified Manager authority and therefore fails open.  Once
    the loaded Manager package returns a real bool, that value is authoritative
    and is returned unchanged.
    """
    editor_key = str(editor_key or "")
    expected_space = _SMART_TOOLS_LOGICAL_EDITOR_TO_SPACE.get(editor_key)
    if expected_space is None:
        return False
    if _context_physical_space_type(context) != expected_space:
        return False

    callback = _manager_loaded_placement_allowed()
    if callback is None:
        return True
    try:
        decision = _call_manager_placement_allowed(callback, context, editor_key)
    except Exception:
        return True
    return decision if type(decision) is bool else True

def _context_physical_space_type(context):
    try:
        area = getattr(context, "area", None)
        return str(getattr(area, "type", "") or "")
    except Exception:
        return ""


def _context_area_ui_type(context):
    try:
        return str(getattr(getattr(context, "area", None), "ui_type", "") or "").upper()
    except Exception:
        return ""


def _context_space_string(context, name):
    try:
        return str(getattr(getattr(context, "space_data", None), name, "") or "").upper()
    except Exception:
        return ""


def _logical_editor_key_for_context(context, physical_space=None):
    physical_space = str(physical_space or _context_physical_space_type(context))
    area_ui_type = _context_area_ui_type(context)
    if physical_space == "VIEW_3D":
        return "VIEW_3D"
    if physical_space == "IMAGE_EDITOR":
        mode = _context_space_string(context, "mode")
        if area_ui_type in {"UV", "UV_EDITOR"} or mode == "UV":
            return "UV_EDITOR"
        return "IMAGE_EDITOR"
    if physical_space == "NODE_EDITOR":
        tree_type = _context_space_string(context, "tree_type")
        shader_type = _context_space_string(context, "shader_type")
        probe = "|".join((area_ui_type, tree_type, shader_type))
        if "COMPOSITOR" in probe:
            return "COMPOSITOR"
        if "GEOMETRY" in probe:
            return "GEOMETRY_NODE_EDITOR"
        if "TEXTURE" in probe:
            return "TEXTURE_NODE_EDITOR"
        return "SHADER_EDITOR"
    if physical_space == "SEQUENCE_EDITOR":
        return "VIDEO_SEQUENCER"
    if physical_space == "CLIP_EDITOR":
        return "MOVIE_CLIP_EDITOR"
    if physical_space == "DOPESHEET_EDITOR":
        return "DOPE_SHEET"
    if physical_space == "GRAPH_EDITOR":
        mode = _context_space_string(context, "mode")
        if area_ui_type in {"DRIVERS", "DRIVER"} or mode in {"DRIVERS", "DRIVER"}:
            return "DRIVERS"
        return "GRAPH_EDITOR"
    if physical_space == "NLA_EDITOR":
        return "NLA_EDITOR"
    if physical_space == "TEXT_EDITOR":
        return "TEXT_EDITOR"
    if physical_space == "FILE_BROWSER":
        browse_mode = _context_space_string(context, "browse_mode")
        if area_ui_type in {"ASSETS", "ASSET_BROWSER"} or browse_mode in {"ASSETS", "ASSET_BROWSER"}:
            return "ASSET_BROWSER"
        return "FILE_BROWSER"
    if physical_space == "SPREADSHEET":
        return "SPREADSHEET"
    return "VIEW_3D"


_SMART_ID_FULL_BODY_FINGERPRINT = hashlib.sha256(
    "|".join(item[0] for item in _SECTION_DEFS).encode("utf-8")
).hexdigest()


def _registration_requires_restart():
    return _SMART_ID_REGISTRATION_MODE == _REGISTRATION_MODE_RESTART_REQUIRED


def _draw_restart_required_body(panel, context):
    """Draw the data-independent safe-mode body without touching Scene RNA."""
    layout = panel.layout
    box = layout.box()
    box.alert = True
    box.label(text=t("restart_required_title", context), icon="ERROR")
    box.label(text=t("restart_required_reason", context))
    box.label(text=t("restart_required_action", context), icon="FILE_REFRESH")
    conflict_count = len(_SMART_ID_REGISTRATION_CONFLICTS)
    if conflict_count:
        box.label(
            text=f"{t('restart_required_conflicts', context)}: {conflict_count}",
            icon="LOCKED",
        )


def _draw_smart_id_full_body(panel, context):
    """Single complete body shared by every native root."""
    if _registration_requires_restart():
        _draw_restart_required_body(panel, context)
        return
    # Draw is read-only: all Inspector synchronization is completed by
    # event-driven coalesced one-shot work before this body executes.
    layout = panel.layout
    settings = get_settings(context.scene)
    boxes = tuple(layout.box() for _unused in _SECTION_DEFS)
    prepared = []
    for box, (prop_name, label_key, icon, help_key, drawer) in zip(boxes, _SECTION_DEFS):
        section_box, expanded = _draw_section_header(
            layout,
            context,
            settings,
            prop_name,
            label_key,
            icon,
            help_key,
            container=box,
        )
        prepared.append((section_box, expanded, drawer))

    for box, expanded, drawer in prepared:
        if not expanded:
            continue
        drawer(box.column(align=True), context)


class SMARTID_PT_root_base:
    def draw_header_preset(self, context):
        _help_button(self.layout, context, 'section_library', 'info_library')

    bl_region_type = "UI"
    bl_category = "Smart ID"
    bl_label = "Smart ID"
    bl_owner_id = ADDON_ID
    _smart_suite_host_panel = True
    _smart_tools_manager_tool_key = _SMART_TOOLS_MANAGER_TOOL_KEY
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_no_cross_editor_proxy = True
    _smart_id_full_body_fingerprint = _SMART_ID_FULL_BODY_FINGERPRINT

    @classmethod
    def poll(cls, context):
        physical_space = str(getattr(cls, "bl_space_type", "") or "")
        if _context_physical_space_type(context) != physical_space:
            return False
        editor_key = _logical_editor_key_for_context(context, physical_space)
        if _SMART_TOOLS_LOGICAL_EDITOR_TO_SPACE.get(editor_key) != physical_space:
            return False
        supported = getattr(cls, "_smart_tools_manager_editor_keys", ())
        if supported and editor_key not in supported:
            return False
        return _smart_id_root_panel_placement_allowed(context, editor_key)

    def draw(self, context):
        _draw_smart_id_full_body(self, context)


class SMARTID_PT_main(SMARTID_PT_root_base, bpy.types.Panel):
    bl_idname = "SMARTID_PT_main"
    bl_space_type = "VIEW_3D"


class SMARTID_PT_image_editor_root(SMARTID_PT_root_base, bpy.types.Panel):
    bl_idname = "SMARTID_PT_image_editor_root"
    bl_space_type = "IMAGE_EDITOR"


class SMARTID_PT_node_editor_root(SMARTID_PT_root_base, bpy.types.Panel):
    bl_idname = "SMARTID_PT_node_editor_root"
    bl_space_type = "NODE_EDITOR"


class SMARTID_PT_sequence_editor_root(SMARTID_PT_root_base, bpy.types.Panel):
    bl_idname = "SMARTID_PT_sequence_editor_root"
    bl_space_type = "SEQUENCE_EDITOR"


class SMARTID_PT_clip_editor_root(SMARTID_PT_root_base, bpy.types.Panel):
    bl_idname = "SMARTID_PT_clip_editor_root"
    bl_space_type = "CLIP_EDITOR"


class SMARTID_PT_dopesheet_editor_root(SMARTID_PT_root_base, bpy.types.Panel):
    bl_idname = "SMARTID_PT_dopesheet_editor_root"
    bl_space_type = "DOPESHEET_EDITOR"


class SMARTID_PT_graph_editor_root(SMARTID_PT_root_base, bpy.types.Panel):
    bl_idname = "SMARTID_PT_graph_editor_root"
    bl_space_type = "GRAPH_EDITOR"


class SMARTID_PT_nla_editor_root(SMARTID_PT_root_base, bpy.types.Panel):
    bl_idname = "SMARTID_PT_nla_editor_root"
    bl_space_type = "NLA_EDITOR"


class SMARTID_PT_text_editor_root(SMARTID_PT_root_base, bpy.types.Panel):
    bl_idname = "SMARTID_PT_text_editor_root"
    bl_space_type = "TEXT_EDITOR"


class SMARTID_PT_file_browser_root(SMARTID_PT_root_base, bpy.types.Panel):
    bl_idname = "SMARTID_PT_file_browser_root"
    bl_space_type = "FILE_BROWSER"
    _smart_tools_manager_editor_keys = ("FILE_BROWSER",)


class SMARTID_PT_spreadsheet_root(SMARTID_PT_root_base, bpy.types.Panel):
    bl_idname = "SMARTID_PT_spreadsheet_root"
    bl_space_type = "SPREADSHEET"


class SMARTID_PT_asset_browser_root(SMARTID_PT_root_base, bpy.types.Panel):
    bl_idname = "SMARTID_PT_asset_browser_root"
    bl_space_type = "FILE_BROWSER"
    bl_region_type = "TOOL_PROPS"
    _smart_tools_manager_editor_keys = ("ASSET_BROWSER",)


_SMART_ID_CANONICAL_ROOT_CLASSES = (
    SMARTID_PT_main,
    SMARTID_PT_image_editor_root,
    SMARTID_PT_node_editor_root,
    SMARTID_PT_sequence_editor_root,
    SMARTID_PT_clip_editor_root,
    SMARTID_PT_dopesheet_editor_root,
    SMARTID_PT_graph_editor_root,
    SMARTID_PT_nla_editor_root,
    SMARTID_PT_text_editor_root,
    SMARTID_PT_file_browser_root,
    SMARTID_PT_spreadsheet_root,
    SMARTID_PT_asset_browser_root,
)


# -----------------------------------------------------------------------------
# Registration
# -----------------------------------------------------------------------------

classes = (
    SMARTID_PG_entry,
    SMARTID_PG_inspector_item,
    SMARTID_PG_settings,
    SMARTID_OT_entry_multi_select,
    SMARTID_OT_entry_select_visible,
    SMARTID_OT_entry_clear_selection,
    SMARTID_OT_entry_delete_selected,
    SMARTID_OT_inspector_multi_select,
    SMARTID_OT_inspector_select_visible,
    SMARTID_OT_inspector_clear_selection,
    SMARTID_OT_inspector_delete_selected,
    SMARTID_OT_add_entry,
    SMARTID_OT_remove_entry,
    SMARTID_OT_duplicate_entry,
    SMARTID_OT_move_entry,
    SMARTID_OT_sort_entries,
    SMARTID_OT_renumber_entries,
    SMARTID_OT_refresh_counts,
    SMARTID_OT_apply_entry,
    SMARTID_OT_select_by_entry,
    SMARTID_OT_select_entry_elements,
    SMARTID_OT_deselect_by_entry,
    SMARTID_OT_unassign_entry,
    SMARTID_OT_sync_from_selection,
    SMARTID_OT_sync_from_scene,
    SMARTID_OT_validate_registry,
    SMARTID_OT_create_materials,
    SMARTID_OT_channel_apply,
    SMARTID_OT_channel_delete,
    SMARTID_OT_read_active,
    SMARTID_OT_create_aov,
    SMARTID_OT_create_collection,
    SMARTID_OT_inspector_refresh,
    SMARTID_OT_inspector_apply,
    SMARTID_OT_inspector_delete,
    SMARTID_OT_inspector_make_entry,
    SMARTID_OT_inspector_select_owner,
    SMARTID_OT_inspector_apply_entry,
    SMARTID_OT_inspector_select_elements,
    SMARTID_OT_inspector_assign_selection,
    SMARTID_OT_inspector_unassign_selection,
    SMARTID_OT_toggle_ui_section,
    SMARTID_OT_open_help,
    SMARTID_OT_export_json,
    SMARTID_OT_import_json,
    SMARTID_OT_export_csv,
    SMARTID_UL_entries,
    SMARTID_UL_inspector_items,
    SMARTID_PT_main,
    SMARTID_PT_image_editor_root,
    SMARTID_PT_node_editor_root,
    SMARTID_PT_sequence_editor_root,
    SMARTID_PT_clip_editor_root,
    SMARTID_PT_dopesheet_editor_root,
    SMARTID_PT_graph_editor_root,
    SMARTID_PT_nla_editor_root,
    SMARTID_PT_text_editor_root,
    SMARTID_PT_file_browser_root,
    SMARTID_PT_spreadsheet_root,
    SMARTID_PT_asset_browser_root,
)


def _operator_result_is_finished(result):
    try:
        return "FINISHED" in result
    except Exception:
        return False


def _wrap_operator_after_event(cls):
    execute = getattr(cls, "execute", None)
    if not callable(execute) or bool(getattr(execute, "_smart_id_after_event_wrapper", False)):
        return

    def _execute_with_after_event(self, context, *args, **kwargs):
        result = execute(self, context, *args, **kwargs)
        if _operator_result_is_finished(result):
            try:
                _smart_id_operator_finished(context, getattr(cls, "bl_idname", cls.__name__))
            except Exception:
                pass
        return result

    _execute_with_after_event.__name__ = getattr(execute, "__name__", "execute")
    _execute_with_after_event.__qualname__ = getattr(execute, "__qualname__", _execute_with_after_event.__name__)
    _execute_with_after_event.__doc__ = getattr(execute, "__doc__", None)
    _execute_with_after_event.__module__ = getattr(execute, "__module__", __name__)
    _execute_with_after_event._smart_id_after_event_wrapper = True
    _execute_with_after_event._smart_id_original_execute = execute
    cls.execute = _execute_with_after_event


def _install_operator_after_events():
    for cls in classes:
        if str(getattr(cls, "__name__", "")).startswith("SMARTID_OT_"):
            _wrap_operator_after_event(cls)


_install_operator_after_events()



_SCENE_RNA_PROPERTY_NAMES = (
    "smart_id_entries",
    "smart_id_entries_staging",
    "smart_id_active_index",
    "smart_id_selection_anchor_index",
    "smart_id_inspector_items",
    "smart_id_inspector_active_index",
    "smart_id_inspector_selection_anchor_index",
    "smart_id_inspector_total_count",
    "smart_id_inspector_omitted_count",
    "smart_id_inspector_truncated",
    "smart_id_settings",
)
_REGISTRATION_MISSING = object()


def _scene_rna_property_definitions():
    """Return fresh deferred RNA definitions and exact expected RNA types."""
    return (
        ("smart_id_entries", CollectionProperty(type=SMARTID_PG_entry), SMARTID_PG_entry),
        ("smart_id_entries_staging", CollectionProperty(type=SMARTID_PG_entry), SMARTID_PG_entry),
        (
            "smart_id_active_index",
            IntProperty(
                name="Smart ID Active Index",
                default=-1,
                update=_on_active_entry_index_changed,
            ),
            None,
        ),
        (
            "smart_id_selection_anchor_index",
            IntProperty(
                name="Smart ID Selection Anchor Index",
                default=-1,
                options={"SKIP_SAVE"},
            ),
            None,
        ),
        (
            "smart_id_inspector_items",
            CollectionProperty(
                type=SMARTID_PG_inspector_item,
                options={"SKIP_SAVE"},
            ),
            SMARTID_PG_inspector_item,
        ),
        (
            "smart_id_inspector_active_index",
            IntProperty(
                name="Smart ID Inspector Active Index",
                default=-1,
                options={"SKIP_SAVE"},
            ),
            None,
        ),
        (
            "smart_id_inspector_selection_anchor_index",
            IntProperty(
                name="Smart ID Inspector Selection Anchor Index",
                default=-1,
                options={"SKIP_SAVE"},
            ),
            None,
        ),
        (
            "smart_id_inspector_total_count",
            IntProperty(
                name="Smart ID Inspector Total Count",
                default=0,
                min=0,
                options={"SKIP_SAVE"},
            ),
            None,
        ),
        (
            "smart_id_inspector_omitted_count",
            IntProperty(
                name="Smart ID Inspector Omitted Count",
                default=0,
                min=0,
                options={"SKIP_SAVE"},
            ),
            None,
        ),
        (
            "smart_id_inspector_truncated",
            BoolProperty(
                name="Smart ID Inspector Truncated",
                default=False,
                options={"SKIP_SAVE"},
            ),
            None,
        ),
        ("smart_id_settings", PointerProperty(type=SMARTID_PG_settings), SMARTID_PG_settings),
    )


def _static_type_member(type_object, name):
    """Read the actual type-dictionary identity without invoking RNA values."""
    try:
        mapping = vars(type_object)
    except Exception:
        mapping = None
    if mapping is not None:
        try:
            if name in mapping:
                return mapping[name]
        except Exception:
            pass
    try:
        return getattr(type_object, name)
    except Exception:
        return _REGISTRATION_MISSING


def _registered_class_at_name(cls):
    """Best-effort collision probe only; Extension RNA need not publish here."""
    try:
        return getattr(bpy.types, str(cls.__name__))
    except Exception:
        return _REGISTRATION_MISSING


def _class_own_rna_identifier(cls):
    """Return a valid identifier only when *cls itself* owns ``bl_rna``.

    Blender Extensions do not guarantee publication as ``bpy.types.<PythonName>``.
    Using ``vars(cls)`` also prevents an inherited base PropertyGroup/Operator/
    Panel ``bl_rna`` descriptor from being mistaken for this class's own RNA.
    """
    try:
        own_rna = vars(cls).get("bl_rna", _REGISTRATION_MISSING)
    except Exception:
        return ""
    if own_rna is _REGISTRATION_MISSING or own_rna is None:
        return ""
    try:
        identifier = getattr(own_rna, "identifier", "")
    except Exception:
        return ""
    if type(identifier) is not str:
        return ""
    identifier = identifier.strip()
    if not identifier or "\x00" in identifier:
        return ""
    return identifier


def _class_registration_is_published(cls):
    return bool(_class_own_rna_identifier(cls))


def _deferred_property_expected_type_matches(descriptor, expected_type):
    """Accept Blender's deferred Pointer/Collection descriptor by exact type."""
    if expected_type is None or descriptor is _REGISTRATION_MISSING:
        return False
    try:
        keywords = getattr(descriptor, "keywords", None)
    except Exception:
        return False
    if not isinstance(keywords, dict):
        return False
    return keywords.get("type", _REGISTRATION_MISSING) is expected_type


def _scene_property_record_matches_published(record, published):
    if not isinstance(record, dict) or published is _REGISTRATION_MISSING:
        return False
    if published is record.get("identity", _REGISTRATION_MISSING):
        return True
    expected_type = record.get("expected_type")
    return _deferred_property_expected_type_matches(published, expected_type)


def _registration_record_matches_current(record):
    if not isinstance(record, dict):
        return False
    kind = str(record.get("kind", ""))
    identity = record.get("identity", _REGISTRATION_MISSING)
    if kind == "class":
        cls = record.get("class")
        return cls is identity and _class_registration_is_published(cls)
    if kind == "scene_property":
        name = str(record.get("name", ""))
        published = _static_type_member(bpy.types.Scene, name) if name else _REGISTRATION_MISSING
        return bool(name) and _scene_property_record_matches_published(record, published)
    return False


class _RegistrationConflict(RuntimeError):
    """Internal signal for a registration identity occupied by another owner."""

    def __init__(self, conflicts):
        normalized = tuple(
            item for item in (conflicts or ()) if isinstance(item, dict)
        )
        self.conflicts = normalized
        super().__init__("Smart ID registration identity conflict")


def _registration_conflict(kind, name, reason="occupied"):
    return {
        "kind": str(kind or "resource")[:48],
        "name": str(name or "unknown")[:192],
        "reason": str(reason or "occupied")[:192],
    }


def _normalize_registration_conflicts(conflicts):
    normalized = []
    seen = set()
    for raw in conflicts or ():
        if isinstance(raw, dict):
            item = _registration_conflict(
                raw.get("kind", "resource"),
                raw.get("name", "unknown"),
                raw.get("reason", "occupied"),
            )
        else:
            item = _registration_conflict("resource", raw, "occupied")
        key = (item["kind"], item["name"], item["reason"])
        if key in seen:
            continue
        seen.add(key)
        normalized.append(item)
        if len(normalized) >= 128:
            break
    return tuple(normalized)


def _set_registration_presentation(mode, conflicts=(), state=None):
    global _SMART_ID_REGISTRATION_MODE, _SMART_ID_REGISTRATION_CONFLICTS
    mode = str(mode or _REGISTRATION_MODE_UNREGISTERED)
    if mode not in {
        _REGISTRATION_MODE_UNREGISTERED,
        _REGISTRATION_MODE_FULL,
        _REGISTRATION_MODE_RESTART_REQUIRED,
    }:
        mode = _REGISTRATION_MODE_UNREGISTERED
    normalized = _normalize_registration_conflicts(conflicts)
    _SMART_ID_REGISTRATION_MODE = mode
    _SMART_ID_REGISTRATION_CONFLICTS = normalized
    state = _runtime_registry_state() if state is None else state
    state["registration_mode"] = mode
    state["registration_status"] = mode
    state["registration_conflicts"] = [dict(item) for item in normalized]
    return mode


def _registration_record_has_complete_ownership(
    record,
    state,
    *,
    kind,
    owner_token,
    generation,
):
    if not _resource_record_is_exact_ledger_member(record, kind=kind, state=state):
        return False
    if not _resource_record_is_owned(
        record,
        owner_token=owner_token,
        generation=generation,
    ):
        return False
    if not callable(record.get("native_remover")):
        return False
    identity = record.get("identity", _REGISTRATION_MISSING)
    if identity is _REGISTRATION_MISSING:
        return False
    if kind == "class":
        return record.get("class") is identity
    if kind == "scene_property":
        return bool(
            str(record.get("name", ""))
            and record.get("native_container") is bpy.types.Scene
        )
    if kind == "handler":
        return callable(identity) and record.get("native_container") is not None
    if kind == "timer":
        return callable(identity)
    if kind == "msgbus":
        return identity is not None
    if kind == "draw_handler":
        return _coerce_runtime_draw_record(record) is record
    return False


def _registration_is_exact_current(state=None):
    state = _runtime_registry_state() if state is None else state
    owner_token = str(state.get("registration_owner_token", ""))
    generation = int(state.get("registration_generation", 0) or 0)
    class_records = tuple(state.get("registered_classes", ()))
    property_records = tuple(state.get("registered_scene_properties", ()))
    if str(state.get("registration_mode", "")) != _REGISTRATION_MODE_FULL:
        return False
    if (
        not owner_token
        or generation <= 0
        or owner_token != str(_SMART_ID_REGISTRATION_OWNER_TOKEN)
        or generation != int(_SMART_ID_REGISTRATION_GENERATION)
        or len(class_records) != len(classes)
        or len(property_records) != len(_SCENE_RNA_PROPERTY_NAMES)
    ):
        return False
    if not all(
        _registration_record_has_complete_ownership(
            record,
            state,
            kind="class",
            owner_token=owner_token,
            generation=generation,
        )
        and _registration_record_matches_current(record)
        for record in class_records
    ):
        return False
    if not all(
        _registration_record_has_complete_ownership(
            record,
            state,
            kind="scene_property",
            owner_token=owner_token,
            generation=generation,
        )
        and _registration_record_matches_current(record)
        for record in property_records
    ):
        return False
    return tuple(record.get("class") for record in class_records) == tuple(classes)


def _registration_is_current_degraded(state=None):
    state = _runtime_registry_state() if state is None else state
    owner_token = str(state.get("registration_owner_token", ""))
    generation = int(state.get("registration_generation", 0) or 0)
    class_records = tuple(state.get("registered_classes", ()))
    property_records = tuple(state.get("registered_scene_properties", ()))
    if str(state.get("registration_mode", "")) != _REGISTRATION_MODE_RESTART_REQUIRED:
        return False
    if (
        not owner_token
        or generation <= 0
        or owner_token != str(_SMART_ID_REGISTRATION_OWNER_TOKEN)
        or generation != int(_SMART_ID_REGISTRATION_GENERATION)
        or not class_records
    ):
        return False

    def _record_is_current_or_stale_exact(record, kind):
        if bool(record.get("stale_owned_retained", False)):
            return bool(
                _resource_record_is_exact_ledger_member(record, kind=kind, state=state)
                and _resource_record_is_owned(record)
                and _registration_record_matches_current(record)
            )
        return bool(
            _registration_record_has_complete_ownership(
                record,
                state,
                kind=kind,
                owner_token=owner_token,
                generation=generation,
            )
            and _registration_record_matches_current(record)
        )

    if not all(
        _record_is_current_or_stale_exact(record, "class")
        for record in class_records
    ):
        return False
    if not all(
        _record_is_current_or_stale_exact(record, "scene_property")
        for record in property_records
    ):
        return False
    root_ids = {
        str(record.get("canonical_root_id", ""))
        for record in class_records
        if bool(record.get("restart_required_root", False))
    }
    expected_root_ids = {
        str(getattr(cls, "bl_idname", cls.__name__))
        for cls in _SMART_ID_CANONICAL_ROOT_CLASSES
    }
    return root_ids == expected_root_ids

def _registration_is_current_module(state=None):
    state = _runtime_registry_state() if state is None else state
    return _registration_is_exact_current(state) or _registration_is_current_degraded(state)


def _remove_exact_runtime_record(record, state):
    kind = str(record.get("kind", "")) if isinstance(record, dict) else ""
    if kind == "draw_handler":
        return _remove_runtime_draw_record(record, state=state, mark_retired=True)
    if not _resource_record_is_exact_ledger_member(record, kind=kind, state=state):
        return False
    identity = record.get("identity")
    remover = record.get("native_remover")
    try:
        if kind == "timer":
            checker = record.get("native_is_registered")
            registered = bool(checker(identity)) if callable(checker) else True
            if registered:
                remover(identity)
            if callable(checker) and bool(checker(identity)):
                raise RuntimeError("timer remained registered")
            list_name = "timer_callbacks"
        elif kind == "handler":
            container = record.get("native_container")
            before = sum(1 for item in container if item is identity)
            if before:
                container.remove(identity)
                after = sum(1 for item in container if item is identity)
                if after != before - 1:
                    raise RuntimeError("exact handler occurrence was not removed")
            list_name = "handler_callbacks"
        elif kind == "msgbus":
            remover(identity)
            list_name = "msgbus_owners"
        else:
            return False
    except Exception as exc:
        record["last_remove_error"] = f"{type(exc).__name__}: {exc}"
        record["remove_attempts"] = int(record.get("remove_attempts", 0)) + 1
        return False
    state[list_name] = [item for item in state.get(list_name, ()) if item is not record]
    record["removed"] = True
    record["last_remove_error"] = ""
    _resource_ledger_drop(record, state)
    return True


def _cleanup_runtime_resources_for_owner(state, owner_token, generation):
    removed = {"timer": 0, "handler": 0, "msgbus": 0, "draw_handler": 0}
    unresolved = {"timer": 0, "handler": 0, "msgbus": 0, "draw_handler": 0}
    list_specs = (
        ("timer", "timer_callbacks"),
        ("handler", "handler_callbacks"),
        ("msgbus", "msgbus_owners"),
        ("draw_handler", "draw_handles"),
    )
    for kind, list_name in list_specs:
        for record in tuple(state.get(list_name, ())):
            if not _resource_record_is_owned(
                record,
                owner_token=owner_token,
                generation=generation,
            ):
                continue
            if not _registration_record_has_complete_ownership(
                record,
                state,
                kind=kind,
                owner_token=owner_token,
                generation=generation,
            ):
                unresolved[kind] += 1
                continue
            if _remove_exact_runtime_record(record, state):
                removed[kind] += 1
            else:
                unresolved[kind] += 1
    return {"removed": removed, "unresolved": unresolved}


def _reclaim_stale_owned_registration(state=None):
    """Recover only exact stale identities whose owner and generation are complete."""
    state = _runtime_registry_state() if state is None else state
    owner_token = str(state.get("registration_owner_token", ""))
    generation = int(state.get("registration_generation", 0) or 0)
    report = {
        "owner_token_present": bool(owner_token),
        "generation": generation,
        "classes_removed": 0,
        "properties_removed": 0,
        "runtime_removed": 0,
        "runtime_unresolved": 0,
        "class_unresolved": 0,
        "property_unresolved": 0,
        "retained_classes": (),
        "retained_properties": (),
    }
    if not owner_token or generation <= 0:
        return report

    if (
        str(state.get("owner_token", "")) == owner_token
        and int(state.get("generation", 0) or 0) == generation
    ):
        runtime_report = _cleanup_runtime_resources_for_owner(
            state,
            owner_token,
            generation,
        )
        report["runtime_removed"] = sum(runtime_report["removed"].values())
        report["runtime_unresolved"] = sum(runtime_report["unresolved"].values())
        if report["runtime_unresolved"] == 0:
            state["active"] = False
            state["owner_token"] = ""
            state["initialized_generation"] = 0
            state["initialized_scene_key"] = ""

    # Scene descriptors must be released before the PropertyGroup classes they
    # reference.  Both rollback helpers still verify exact published identity.
    property_records = tuple(state.get("registered_scene_properties", ()))
    owned_property_records = tuple(
        record
        for record in property_records
        if _registration_record_has_complete_ownership(
            record,
            state,
            kind="scene_property",
            owner_token=owner_token,
            generation=generation,
        )
    )
    removed_properties, retained_properties = _rollback_scene_rna_properties(
        owned_property_records
    )
    report["properties_removed"] = len(removed_properties)
    report["property_unresolved"] = len(retained_properties)
    for record in retained_properties:
        record["stale_owned_retained"] = True
    report["retained_properties"] = tuple(retained_properties)
    retained_property_ids = {id(record) for record in retained_properties}
    state["registered_scene_properties"] = [
        record
        for record in property_records
        if id(record) in retained_property_ids
    ]

    class_records = tuple(state.get("registered_classes", ()))
    owned_class_records = tuple(
        record
        for record in class_records
        if _registration_record_has_complete_ownership(
            record,
            state,
            kind="class",
            owner_token=owner_token,
            generation=generation,
        )
    )
    removed_classes, retained_classes = _rollback_registered_classes(
        owned_class_records
    )
    report["classes_removed"] = len(removed_classes)
    report["class_unresolved"] = len(retained_classes)
    for record in retained_classes:
        record["stale_owned_retained"] = True
    report["retained_classes"] = tuple(retained_classes)
    retained_class_ids = {id(record) for record in retained_classes}
    state["registered_classes"] = [
        record
        for record in class_records
        if id(record) in retained_class_ids
    ]

    if (
        report["runtime_unresolved"] == 0
        and report["class_unresolved"] == 0
        and report["property_unresolved"] == 0
    ):
        state["registration_owner_token"] = ""
        state["registration_generation"] = 0
        state["registered_classes"] = []
        state["registered_scene_properties"] = []
        state["registration_root_class_ids"] = []
        if str(state.get("translations_owner_token", "")) == owner_token:
            # Translation registration has no exact dictionary identity API.
            # Treat any existing dictionary as foreign and never unregister it.
            state["translations_owner_token"] = ""
        _set_registration_presentation(
            _REGISTRATION_MODE_UNREGISTERED,
            (),
            state,
        )
    return report

def _scan_registration_conflicts(state=None):
    state = _runtime_registry_state() if state is None else state
    conflicts = []
    if bool(state.get("active", False)) or str(state.get("owner_token", "")):
        conflicts.append(
            _registration_conflict(
                "runtime_generation",
                "Smart ID runtime",
                "unresolved owned or untrusted runtime generation",
            )
        )
    for cls in classes:
        if _registered_class_at_name(cls) is not _REGISTRATION_MISSING:
            conflicts.append(
                _registration_conflict(
                    "class",
                    cls.__name__,
                    "published identity is not owned by this registration transaction",
                )
            )
    for name in _SCENE_RNA_PROPERTY_NAMES:
        if _static_type_member(bpy.types.Scene, name) is not _REGISTRATION_MISSING:
            conflicts.append(
                _registration_conflict(
                    "scene_property",
                    name,
                    "published descriptor is not owned by this registration transaction",
                )
            )
    return _normalize_registration_conflicts(conflicts)


def _preflight_registration(state=None):
    """Recover exact stale ownership; degrade safely for every foreign conflict."""
    state = _runtime_registry_state() if state is None else state
    if _registration_is_current_module(state):
        return {
            "status": "ALREADY_CURRENT",
            "mode": str(state.get("registration_mode", _REGISTRATION_MODE_FULL)),
            "conflicts": tuple(state.get("registration_conflicts", ())),
            "reclaimed": {},
        }
    reclaimed = _reclaim_stale_owned_registration(state)
    conflicts = _scan_registration_conflicts(state)
    mode = (
        _REGISTRATION_MODE_RESTART_REQUIRED
        if conflicts
        else _REGISTRATION_MODE_FULL
    )
    return {
        "status": "READY",
        "mode": mode,
        "conflicts": conflicts,
        "reclaimed": reclaimed,
    }

def _register_scene_rna_properties_transaction(owner_token, records=None, generation=None):
    records = records if isinstance(records, list) else []
    for name, definition, expected_type in _scene_rna_property_definitions():
        if _static_type_member(bpy.types.Scene, name) is not _REGISTRATION_MISSING:
            raise _RegistrationConflict((
                _registration_conflict(
                    "scene_property",
                    name,
                    "descriptor became occupied during registration",
                ),
            ))
        setattr(bpy.types.Scene, name, definition)
        published = _static_type_member(bpy.types.Scene, name)
        identity = definition if published is _REGISTRATION_MISSING else published
        record = _new_owned_resource_record(
            "scene_property",
            identity,
            delattr,
            owner_token=owner_token,
            generation=generation,
            name=str(name),
            native_container=bpy.types.Scene,
            expected_type=expected_type,
            deferred_definition=definition,
            native_registration_succeeded=True,
        )
        records.append(record)
        _resource_ledger_add(record)
        publication_valid = bool(
            published is definition
            or (
                expected_type is not None
                and _deferred_property_expected_type_matches(published, expected_type)
            )
            or (expected_type is None and published is not _REGISTRATION_MISSING)
        )
        record["publication_verified"] = publication_valid
        if not publication_valid:
            # Do not fail add-on enablement because a post-registration probe is
            # inconclusive.  The caller rolls back this exact transaction and
            # enters the RESTART_REQUIRED roots without touching foreign data.
            raise _RegistrationConflict((
                _registration_conflict(
                    "scene_property",
                    name,
                    "registered descriptor could not be verified exactly",
                ),
            ))
    return records


def _rollback_scene_rna_properties(records):
    """Remove only complete exact-owned descriptors, in reverse acquisition order."""
    removed = []
    retained = []
    state = _runtime_registry_state()
    for record in reversed(tuple(records or ())):
        if not isinstance(record, dict) or record.get("kind") != "scene_property":
            retained.append(record)
            continue
        owner_token = str(record.get("owner_token", ""))
        try:
            generation = int(record.get("generation", 0) or 0)
        except Exception:
            generation = 0
        if not owner_token or generation <= 0 or not _registration_record_has_complete_ownership(
            record,
            state,
            kind="scene_property",
            owner_token=owner_token,
            generation=generation,
        ):
            retained.append(record)
            continue
        name = str(record.get("name", ""))
        identity = record.get("identity", _REGISTRATION_MISSING)
        container = record.get("native_container")
        remover = record.get("native_remover")
        published = _static_type_member(container, name) if name else _REGISTRATION_MISSING
        if not _scene_property_record_matches_published(record, published):
            # Our exact descriptor is already absent or was replaced.  Never
            # delete the replacement; release only this stale ownership record.
            record["removed"] = True
            record["replaced_or_missing"] = True
            _resource_ledger_drop(record, state)
            removed.append(record)
            continue
        try:
            remover(container, name)
        except Exception as exc:
            record["last_remove_error"] = f"{type(exc).__name__}: {exc}"
            record["remove_attempts"] = int(record.get("remove_attempts", 0)) + 1
            retained.append(record)
            continue
        published_after = _static_type_member(container, name)
        if not _scene_property_record_matches_published(record, published_after):
            record["removed"] = True
            record["last_remove_error"] = ""
            _resource_ledger_drop(record, state)
            removed.append(record)
        else:
            retained.append(record)
    retained.reverse()
    return removed, retained


def _register_class_identity_transaction(
    cls,
    owner_token,
    records,
    *,
    generation,
    restart_required_root=False,
    canonical_root_id="",
):
    if _registered_class_at_name(cls) is not _REGISTRATION_MISSING:
        raise _RegistrationConflict((
            _registration_conflict(
                "class",
                cls.__name__,
                "class name became occupied during registration",
            ),
        ))
    try:
        bpy.utils.register_class(cls)
    except Exception as exc:
        message = str(exc).lower()
        collision = bool(
            _registered_class_at_name(cls) is not _REGISTRATION_MISSING
            or isinstance(exc, ValueError)
            or "already registered" in message
            or "bl_idname" in message
        )
        if collision:
            raise _RegistrationConflict((
                _registration_conflict(
                    "class",
                    cls.__name__,
                    f"registration collision: {type(exc).__name__}",
                ),
            )) from None
        raise
    record = _new_owned_resource_record(
        "class",
        cls,
        getattr(bpy.utils, "unregister_class", None),
        owner_token=owner_token,
        generation=generation,
        restart_required_root=bool(restart_required_root),
        canonical_root_id=str(canonical_root_id or ""),
        native_registration_succeeded=True,
        **{"class": cls},
    )
    records.append(record)
    _resource_ledger_add(record)
    rna_identifier = _class_own_rna_identifier(cls)
    record["rna_identifier"] = rna_identifier
    record["publication_verified"] = bool(rna_identifier)
    if not rna_identifier:
        # ``bpy.types.<PythonName>`` publication is intentionally not required.
        # An inconclusive own-RNA probe becomes a handled registration conflict
        # so enablement degrades safely instead of raising RuntimeError.
        raise _RegistrationConflict((
            _registration_conflict(
                "class",
                cls.__name__,
                "registered class own bl_rna identifier could not be verified",
            ),
        ))
    return record


def _register_classes_transaction(owner_token, records=None, generation=None):
    records = records if isinstance(records, list) else []
    for cls in classes:
        _register_class_identity_transaction(
            cls,
            owner_token,
            records,
            generation=generation,
        )
    return records


def _make_restart_required_root_class(root_cls, owner_token, attempt):
    physical = str(getattr(root_cls, "bl_space_type", "VIEW_3D") or "VIEW_3D")
    slug = re.sub(r"[^A-Z0-9]+", "_", physical.upper()).strip("_") or "EDITOR"
    seed = f"{owner_token}|{getattr(root_cls, 'bl_idname', root_cls.__name__)}|{int(attempt)}"
    suffix = hashlib.sha256(seed.encode("utf-8")).hexdigest()[:12].upper()
    class_name = f"SMARTIDSAFE_PT_{slug}_{suffix}"
    attributes = {
        "__module__": __name__,
        "bl_idname": class_name,
        "bl_label": "Smart ID",
        "bl_space_type": physical,
        "bl_region_type": root_cls.bl_region_type,
        "bl_category": "Smart ID",
        "bl_owner_id": ADDON_ID,
        "_smart_id_restart_required_root": True,
        "_smart_id_canonical_root_id": str(getattr(root_cls, "bl_idname", root_cls.__name__)),
        "_smart_tools_manager_editor_keys": getattr(root_cls, "_smart_tools_manager_editor_keys", ()),
    }
    return type(class_name, (SMARTID_PT_root_base, bpy.types.Panel), attributes)


def _register_restart_required_roots_transaction(
    owner_token,
    records=None,
    *,
    generation,
    conflicts=(),
):
    records = records if isinstance(records, list) else []
    accumulated = list(_normalize_registration_conflicts(conflicts))
    retained_root_ids = set()
    state = _runtime_registry_state()
    expected_root_ids = {
        str(getattr(root_cls, "bl_idname", root_cls.__name__))
        for root_cls in _SMART_ID_CANONICAL_ROOT_CLASSES
    }
    for record in tuple(records):
        if not isinstance(record, dict) or str(record.get("kind", "")) != "class":
            continue
        record_owner = str(record.get("owner_token", ""))
        try:
            record_generation = int(record.get("generation", 0) or 0)
        except Exception:
            record_generation = 0
        if not record_owner or record_generation <= 0:
            continue
        if not _registration_record_has_complete_ownership(
            record,
            state,
            kind="class",
            owner_token=record_owner,
            generation=record_generation,
        ) or not _registration_record_matches_current(record):
            continue
        canonical_id = str(record.get("canonical_root_id", "") or "")
        if not canonical_id:
            canonical_id = str(getattr(record.get("class"), "bl_idname", "") or "")
        if canonical_id in expected_root_ids:
            record["restart_required_root"] = True
            record["canonical_root_id"] = canonical_id
            retained_root_ids.add(canonical_id)

    for root_cls in _SMART_ID_CANONICAL_ROOT_CLASSES:
        canonical_id = str(getattr(root_cls, "bl_idname", root_cls.__name__))
        registered = canonical_id in retained_root_ids
        if _registered_class_at_name(root_cls) is _REGISTRATION_MISSING:
            try:
                _register_class_identity_transaction(
                    root_cls,
                    owner_token,
                    records,
                    generation=generation,
                    restart_required_root=True,
                    canonical_root_id=canonical_id,
                )
                registered = True
            except _RegistrationConflict as exc:
                accumulated.extend(exc.conflicts)
            except Exception as exc:
                accumulated.append(
                    _registration_conflict(
                        "restart_root",
                        canonical_id,
                        f"canonical root registration failed: {type(exc).__name__}",
                    )
                )
        if registered:
            continue
        for attempt in range(1, 5):
            fallback_cls = _make_restart_required_root_class(
                root_cls,
                owner_token,
                attempt,
            )
            try:
                _register_class_identity_transaction(
                    fallback_cls,
                    owner_token,
                    records,
                    generation=generation,
                    restart_required_root=True,
                    canonical_root_id=canonical_id,
                )
                registered = True
                break
            except _RegistrationConflict as exc:
                accumulated.extend(exc.conflicts)
            except Exception as exc:
                accumulated.append(
                    _registration_conflict(
                        "restart_root",
                        canonical_id,
                        f"fallback registration failed: {type(exc).__name__}",
                    )
                )
        if not registered:
            accumulated.append(
                _registration_conflict(
                    "restart_root",
                    canonical_id,
                    "no safe root identity could be registered",
                )
            )
    return records, _normalize_registration_conflicts(accumulated)


def _rollback_registered_classes(records):
    """Unregister only complete exact-owned class identities, in reverse order."""
    removed = []
    retained = []
    state = _runtime_registry_state()
    for record in reversed(tuple(records or ())):
        if not isinstance(record, dict) or record.get("kind") != "class":
            retained.append(record)
            continue
        owner_token = str(record.get("owner_token", ""))
        try:
            generation = int(record.get("generation", 0) or 0)
        except Exception:
            generation = 0
        if not owner_token or generation <= 0 or not _registration_record_has_complete_ownership(
            record,
            state,
            kind="class",
            owner_token=owner_token,
            generation=generation,
        ):
            retained.append(record)
            continue
        cls = record.get("class")
        identity = record.get("identity", _REGISTRATION_MISSING)
        remover = record.get("native_remover")
        if cls is not identity or not callable(remover):
            retained.append(record)
            continue
        # Exact transaction ownership is sufficient to call Blender's native
        # remover with the exact class object.  Extension registration does not
        # require a ``bpy.types.<PythonName>`` alias.
        try:
            remover(identity)
        except Exception as exc:
            record["last_remove_error"] = f"{type(exc).__name__}: {exc}"
            record["remove_attempts"] = int(record.get("remove_attempts", 0)) + 1
            retained.append(record)
            continue
        if not _class_registration_is_published(cls):
            record["removed"] = True
            record["last_remove_error"] = ""
            _resource_ledger_drop(record, state)
            removed.append(record)
        else:
            retained.append(record)
    retained.reverse()
    return removed, retained


def _store_registration_ownership(
    state,
    owner_token,
    class_records,
    property_records,
    translations_owned,
    *,
    generation,
    mode=_REGISTRATION_MODE_FULL,
    conflicts=(),
):
    global _SMART_ID_REGISTRATION_OWNER_TOKEN, _SMART_ID_REGISTRATION_GENERATION
    token = str(owner_token)
    state["registration_owner_token"] = token
    state["registration_generation"] = int(generation)
    state["registered_classes"] = list(class_records)
    state["registered_scene_properties"] = list(property_records)
    state["translations_owner_token"] = token if translations_owned else ""
    state["registration_root_class_ids"] = [
        str(record.get("canonical_root_id", ""))
        or str(getattr(record.get("class"), "bl_idname", ""))
        for record in class_records
        if bool(record.get("restart_required_root", False))
        or record.get("class") in _SMART_ID_CANONICAL_ROOT_CLASSES
    ]
    _SMART_ID_REGISTRATION_OWNER_TOKEN = token
    _SMART_ID_REGISTRATION_GENERATION = int(generation)
    _set_registration_presentation(mode, conflicts, state)


def _registration_ownership_is_this_module(state, owner_token, generation):
    return bool(
        str(owner_token)
        and int(generation) > 0
        and str(state.get("registration_owner_token", "")) == str(owner_token)
        and int(state.get("registration_generation", 0)) == int(generation)
        and str(_SMART_ID_REGISTRATION_OWNER_TOKEN) == str(owner_token)
        and int(_SMART_ID_REGISTRATION_GENERATION) == int(generation)
    )


def _clear_registration_ownership_if_owner(state, owner_token, generation):
    global _SMART_ID_REGISTRATION_OWNER_TOKEN, _SMART_ID_REGISTRATION_GENERATION
    if not _registration_ownership_is_this_module(state, owner_token, generation):
        return False
    state["registration_owner_token"] = ""
    state["registration_generation"] = 0
    state["registered_classes"] = []
    state["registered_scene_properties"] = []
    state["registration_root_class_ids"] = []
    if str(state.get("translations_owner_token", "")) == str(owner_token):
        state["translations_owner_token"] = ""
    _SMART_ID_REGISTRATION_OWNER_TOKEN = ""
    _SMART_ID_REGISTRATION_GENERATION = 0
    _set_registration_presentation(
        _REGISTRATION_MODE_UNREGISTERED,
        (),
        state,
    )
    return True


def _activate_restart_required_registration(
    state,
    owner_token,
    pending_generation,
    conflicts,
    *,
    retained_classes=(),
    retained_properties=(),
    translations_retained=False,
):
    class_records = list(retained_classes or ())
    property_records = list(retained_properties or ())
    state["generation"] = max(int(state.get("generation", 0) or 0), int(pending_generation))
    normalized = list(_normalize_registration_conflicts(conflicts))
    _set_registration_presentation(
        _REGISTRATION_MODE_RESTART_REQUIRED,
        normalized,
        state,
    )
    try:
        class_records, normalized_conflicts = _register_restart_required_roots_transaction(
            owner_token,
            class_records,
            generation=pending_generation,
            conflicts=normalized,
        )
        normalized = list(normalized_conflicts)
    except Exception as exc:
        normalized.append(
            _registration_conflict(
                "restart_root",
                "Smart ID roots",
                f"safe root setup failed: {type(exc).__name__}",
            )
        )
    _store_registration_ownership(
        state,
        owner_token,
        class_records,
        property_records,
        bool(translations_retained),
        generation=pending_generation,
        mode=_REGISTRATION_MODE_RESTART_REQUIRED,
        conflicts=normalized,
    )
    return True


def register():
    state = _runtime_registry_state()
    plan = _preflight_registration(state)
    if str(plan.get("status", "")) == "ALREADY_CURRENT":
        _set_registration_presentation(
            plan.get("mode", _REGISTRATION_MODE_FULL),
            plan.get("conflicts", ()),
            state,
        )
        return

    owner_token = f"{ADDON_ID}:registration:{uuid.uuid4().hex}"
    pending_generation = max(
        int(state.get("generation", 0) or 0),
        int(state.get("registration_generation", 0) or 0),
    ) + 1
    if plan.get("mode") == _REGISTRATION_MODE_RESTART_REQUIRED:
        reclaimed = plan.get("reclaimed", {}) if isinstance(plan.get("reclaimed", {}), dict) else {}
        _activate_restart_required_registration(
            state,
            owner_token,
            pending_generation,
            plan.get("conflicts", ()),
            retained_classes=reclaimed.get("retained_classes", ()),
            retained_properties=reclaimed.get("retained_properties", ()),
        )
        return

    class_records = []
    property_records = []
    translations_owned = False
    generation = None
    try:
        # Every successful acquisition is recorded immediately.  A registration
        # identity occupied after preflight converts to safe mode instead of
        # failing add-on enablement or touching the occupying identity.
        translations_owned = bool(_register_translations())
        _register_classes_transaction(
            owner_token,
            class_records,
            generation=pending_generation,
        )
        _register_scene_rna_properties_transaction(
            owner_token,
            property_records,
            generation=pending_generation,
        )

        generation = _begin_runtime_generation(owner_token)
        _cancel_post_register_restore_timer()
        _register_settings_persistence()

        # Registration is read-only with respect to CONFIG.  A missing or
        # invalid file leaves RNA defaults untouched and does not create the
        # production settings directory or JSON file.
        initialized = _initialize_settings_and_runtime_once(
            getattr(getattr(bpy, "context", None), "scene", None),
            generation=generation,
            force=False,
        )
        if not initialized:
            _schedule_post_register_restore(generation)
        _store_registration_ownership(
            state,
            owner_token,
            class_records,
            property_records,
            translations_owned,
            generation=pending_generation,
            mode=_REGISTRATION_MODE_FULL,
            conflicts=(),
        )
    except _RegistrationConflict as conflict:
        # Roll back only identities acquired by this attempt, then expose a
        # data-independent RESTART REQUIRED body through safe root panels.
        if generation is not None:
            try:
                _cancel_post_register_restore_timer()
                _unregister_settings_persistence()
                remove_proxy_cleanup_handlers()
                remove_overlay_handlers()
            except Exception:
                pass
            try:
                _end_runtime_generation(owner_token)
            except Exception:
                pass
        _removed_properties, retained_properties = _rollback_scene_rna_properties(
            property_records
        )
        _removed_classes, retained_classes = _rollback_registered_classes(
            class_records
        )
        translations_retained = False
        if translations_owned:
            translations_retained = not bool(_unregister_translations())
        combined_conflicts = list(plan.get("conflicts", ()))
        combined_conflicts.extend(conflict.conflicts)
        combined_conflicts.extend(_scan_registration_conflicts(state))
        _activate_restart_required_registration(
            state,
            owner_token,
            pending_generation,
            combined_conflicts,
            retained_classes=retained_classes,
            retained_properties=retained_properties,
            translations_retained=translations_retained,
        )
        return
    except Exception:
        # Never call a blanket cleanup here.  Existing/foreign resources are
        # preserved; only identities acquired above are eligible for rollback.
        if generation is not None:
            try:
                _cancel_post_register_restore_timer()
                _unregister_settings_persistence()
                remove_proxy_cleanup_handlers()
                remove_overlay_handlers()
            except Exception:
                pass
            try:
                _end_runtime_generation(owner_token)
            except Exception:
                pass
        _removed_properties, retained_properties = _rollback_scene_rna_properties(
            property_records
        )
        _removed_classes, retained_classes = _rollback_registered_classes(
            class_records
        )
        translations_retained = False
        if translations_owned:
            translations_retained = not bool(_unregister_translations())
        if retained_properties or retained_classes or translations_retained:
            _store_registration_ownership(
                state,
                owner_token,
                retained_classes,
                retained_properties,
                translations_retained,
                generation=pending_generation,
                mode=_REGISTRATION_MODE_RESTART_REQUIRED,
                conflicts=(
                    _registration_conflict(
                        "registration",
                        "Smart ID",
                        "unexpected registration failure left exact owned resources",
                    ),
                ),
            )
        else:
            _set_registration_presentation(
                _REGISTRATION_MODE_UNREGISTERED,
                (),
                state,
            )
        raise


def unregister():
    state = _runtime_registry_state()
    owner_token = str(state.get("registration_owner_token", ""))
    registration_generation = int(state.get("registration_generation", 0) or 0)
    # An unregister function retained from generation A must never consume the
    # shared generation-B ledger.  Only the module instance that acquired these
    # exact registration identities may release them.
    if not _registration_ownership_is_this_module(
        state,
        owner_token,
        registration_generation,
    ):
        return

    registration_mode = str(
        state.get("registration_mode", _REGISTRATION_MODE_UNREGISTERED)
    )
    registration_conflicts = tuple(state.get("registration_conflicts", ()))
    class_records = list(state.get("registered_classes", ()))
    property_records = list(state.get("registered_scene_properties", ()))
    translations_owned = str(state.get("translations_owner_token", "")) == owner_token
    try:
        if registration_mode == _REGISTRATION_MODE_FULL:
            # Retire every generation-guarded callback before touching any
            # native container, RNA descriptor, or class.  A failed native
            # removal therefore leaves only no-op exact records for retry.
            _retire_runtime_generation_callbacks(owner_token)
            # Persist only an actual deferred user change; registration itself
            # never marks settings dirty and cannot create the default JSON.
            try:
                flush_deferred_npanel_settings()
            except Exception:
                pass
            _cancel_post_register_restore_timer()
            _unregister_settings_persistence()
            remove_proxy_cleanup_handlers()
            remove_overlay_handlers()
            _clear_inspector_runtime_caches(clear_metadata_manifest=True)
            _reset_transient_cache_accounting_if_empty()
    finally:
        _removed_properties, retained_properties = _rollback_scene_rna_properties(
            property_records
        )
        _removed_classes, retained_classes = _rollback_registered_classes(
            class_records
        )
        translations_retained = False
        if translations_owned:
            translations_retained = not bool(_unregister_translations())
        runtime_released = True
        if registration_mode == _REGISTRATION_MODE_FULL:
            runtime_released = bool(_end_runtime_generation(owner_token))
        if retained_properties or retained_classes or translations_retained or not runtime_released:
            # Keep the exact registration owner only while a native identity is
            # unresolved.  A second explicit unregister can then retry the same
            # ledger records; no watchdog or foreign/name-based cleanup is used.
            _store_registration_ownership(
                state,
                owner_token,
                retained_classes,
                retained_properties,
                translations_retained,
                generation=registration_generation,
                mode=registration_mode,
                conflicts=registration_conflicts,
            )
        else:
            _clear_registration_ownership_if_owner(
                state,
                owner_token,
                registration_generation,
            )


if __name__ == "__main__":
    register()

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)
