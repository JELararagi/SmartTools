# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Read-only inspection records and explicit references to their source data."""
import json
from uuid import uuid4
from .data_schema import InspectorItem, Entry, ContractError, MAX_ENTRIES, MAX_TEXT, SCHEMA, checked_record
from .channels import metadata, bucket_for


def reference(key, kind, name='', slot=-1):
    return json.dumps([key, kind, name, slot], ensure_ascii=False, separators=(',', ':'))


def decode_reference(item):
    try:
        parts = json.loads(item.uid)
    except (ValueError, TypeError):
        raise ContractError('stale_inspection') from None
    if not isinstance(parts, list) or len(parts) != 4:
        raise ContractError('stale_inspection')
    if not all(isinstance(value, str) for value in parts[:3]) or type(parts[3]) is not int:
        raise ContractError('stale_inspection')
    if parts[1] != item.item_type:
        raise ContractError('stale_inspection')
    return tuple(parts)


def _item(obj, kind, name='', slot=-1, **values):
    base = dict(uid=reference(obj.key, kind, name, slot), item_type=kind,
                owner_object=obj.name, owner_data=obj.mesh.name if obj.mesh else '',
                name=name, edit_name=name, slot_index=slot, safe_to_delete=not obj.readonly)
    base.update(values)
    return InspectorItem(**base)


def iter_items(state, keys=None):
    if hasattr(state,'inspector_meta'):
        from .inspector_view import rows
        yield from rows(state,state.scope(state.settings.inspector_scope) if keys is None else keys)
    else:
        yield from raw_items(state,keys)

def raw_items(state, keys=None):
    keys = state.scope(state.settings.inspector_scope) if keys is None else keys
    for key in keys:
        obj = state.objects.get(key)
        if obj is None:
            continue
        yield _item(obj, 'OBJECT_ID', name=obj.name, edit_name=obj.name,
                    id_number=obj.pass_index, color=tuple(obj.color), data_type=obj.kind,
                    details_message_id='value_pass_index', details_message_value=str(obj.pass_index))
        mesh_locked = obj.readonly or bool(obj.mesh and obj.mesh.readonly)
        for slot, name in enumerate(obj.slots):
            mat = state.materials.get(name)
            yield _item(obj, 'MATERIAL_ID', name=name or '', slot=slot,
                        material_name=name or '', id_number=mat.pass_index if mat else 0,
                        color=tuple(mat.color) if mat else (0.75, 0.75, 0.75, 1.0),
                        active=slot == obj.active_slot, safe_to_delete=not mesh_locked,
                        details_message_id='value_material_slot', details_message_value=str(slot))
        for name in obj.groups:
            yield _item(obj, 'WEIGHT_GROUP', name=name, active=name == obj.active_group,
                        safe_to_delete=not mesh_locked, data_type='WEIGHT')
        for name, members in state.collections.items():
            if key in members:
                yield _item(obj, 'SELECTION_SET', name=name, collection_name=name,
                            safe_to_delete=not obj.readonly and name not in state.collection_readonly)
        if obj.mesh is not None:
            mesh = obj.mesh
            mapping = metadata(mesh).get('map_channels', {})
            mapping = mapping if isinstance(mapping, dict) else {}
            for kind, bucket in (('UV_CHANNEL', mesh.uv), ('COLOR_ATTRIBUTE', mesh.colors),
                                 ('GEOMETRY_ATTRIBUTE', mesh.attributes)):
                for name, layer in bucket.items():
                    protected = layer.protected or name.startswith('.') or name == 'position'
                    values = dict(data_type=layer.data_type, domain=layer.domain,
                                  active=layer.active, render=layer.render,
                                  safe_to_delete=not mesh_locked and not protected)
                    yield _item(obj, kind, name=name, **values)
                    number = mapping.get(name)
                    if kind == 'UV_CHANNEL' and type(number) is int and 1 <= number <= 999:
                        yield _item(obj, 'MAP_CHANNEL', name=name, map_channel=number,
                                    id_number=number, **values)
            tile = metadata(mesh).get('udim_tile')
            if type(tile) is int and 1001 <= tile <= 9999:
                yield _item(obj, 'UDIM_TILE', id_number=tile, safe_to_delete=not mesh_locked,
                            details_message_id='value_udim_tile', details_message_value=str(tile))
        for name, value in metadata(obj).items():
            text = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
            number = value.get('number', 0) if isinstance(value, dict) else 0
            number = number if type(number) is int and 0 <= number <= 2147483647 else 0
            edit_name = value.get('name', name) if isinstance(value, dict) else name
            yield _item(obj, 'SMART_METADATA', name=name, edit_name=str(edit_name),
                        id_number=number, data_type='JSON', details=text[:MAX_TEXT],
                        details_message_id='value_metadata', details_message_value=name)


def current_item(state, item):
    key, kind, name, slot = decode_reference(item)
    obj = state.objects.get(key)
    if obj is None:
        raise ContractError('stale_inspection')
    fresh = next((row for row in iter_items(state, [key]) if row.uid == item.uid), None)
    if fresh is None:
        raise ContractError('stale_inspection')
    return obj, fresh


def refresh_inspector(state, limit=MAX_ENTRIES):
    if type(limit) is not int or not 1 <= limit <= MAX_ENTRIES:
        raise ContractError('invalid_field', field='inspection_limit')
    selected = {row.uid for row in state.inspector if row.selected}
    active = state.inspector[state.inspector_index].uid if 0 <= state.inspector_index < len(state.inspector) else ''
    rows = []
    total = 0
    for item in iter_items(state):
        total += 1
        if len(rows) < limit:
            item.selected = item.uid in selected
            rows.append(item)
    state.inspector = rows
    state.inspector_omitted = total - len(rows)
    state.inspector_index = next((i for i, row in enumerate(rows) if row.uid == active),
                                 min(max(state.inspector_index, 0), len(rows) - 1))
    state.inspector_anchor = -1
    return total


def visible_inspector_indices(state, localized_text=None):
    query = state.settings.inspector_search.casefold().strip()
    kind = state.settings.inspector_filter_type
    result = []
    for index, row in enumerate(state.inspector):
        if kind != 'ALL' and row.item_type != kind:
            continue
        values = [row.name, row.edit_name, row.owner_object, row.owner_data, row.item_type,
                  row.data_type, row.domain, row.value_text, row.details, str(row.id_number)]
        if localized_text is not None:
            values.append(localized_text(row))
        if not query or any(query in value.casefold() for value in values):
            result.append(index)
    return result


def active_item(state):
    if not 0 <= state.inspector_index < len(state.inspector):
        raise ContractError('no_inspector_item')
    return state.inspector[state.inspector_index]


def action_items(state):
    checked = [row for row in state.inspector if row.selected]
    return checked or ([active_item(state)] if 0 <= state.inspector_index < len(state.inspector) else [])


def entry_from_item(state, item, refresh=True):
    if refresh:
        obj, item = current_item(state, item)
    else:
        obj = state.objects[decode_reference(item)[0]]
    kind = item.item_type
    row = Entry(uid=uuid4().hex, type=kind if kind != 'SMART_METADATA' else 'CUSTOM_ID',
                name=item.name or obj.name, id_number=item.id_number, color=tuple(item.color))
    row.channel_name = item.name or obj.name
    if kind == 'OBJECT_ID':
        row.name = obj.name
    elif kind == 'MATERIAL_ID':
        if not item.material_name or item.material_name not in state.materials:
            raise ContractError('missing_active_data')
        row.material_name = item.material_name
    elif kind in ('UV_CHANNEL', 'MAP_CHANNEL'):
        row.uv_map = item.name
        if kind == 'MAP_CHANNEL':
            row.map_channel = item.map_channel
    elif kind == 'COLOR_ATTRIBUTE':
        row.color_attribute = item.name
        row.attribute_domain = item.domain if item.domain in ('POINT', 'CORNER') else 'CORNER'
    elif kind == 'GEOMETRY_ATTRIBUTE':
        if item.data_type not in SCHEMA['enums']['ATTRIBUTE_TYPE_ITEMS'] or item.domain not in SCHEMA['enums']['ATTRIBUTE_DOMAIN_ITEMS']:
            raise ContractError('unsupported_attribute', name=item.name)
        row.attribute_name = item.name
        row.attribute_type = item.data_type
        row.attribute_domain = item.domain
    elif kind in ('WEIGHT_GROUP', 'SELECTION_SET'):
        row.group_name = item.name
    elif kind == 'UDIM_TILE':
        row.udim_tile = item.id_number
    elif kind == 'SMART_METADATA':
        from .inspector_view import meta_owner,meta_key
        owner=meta_owner(state,obj,item) if hasattr(state,'inspector_meta') else obj
        key=meta_key(state,obj,item) if hasattr(state,'inspector_meta') else item.name
        value=metadata(owner).get(key)
        if not isinstance(value, dict) or value.get('type') not in SCHEMA['enums']['ID_TYPE_ITEMS']:
            raise ContractError('metadata_not_entry', name=item.name)
        row.type = value['type']
        row.id_number = value.get('number', 0)
        row.name = value.get('name') or obj.name
        row.channel_name = row.name
        row.export_tag = value.get('tag', '')
        row.color = tuple(obj.color)
    return checked_record(row)
