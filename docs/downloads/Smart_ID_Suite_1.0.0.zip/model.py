# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Blender-independent state used for planning and reproducible contract tests."""
from dataclasses import dataclass, field
from copy import deepcopy
from .data_schema import Settings


@dataclass
class Channel:
    name: str
    data_type: str = 'FLOAT'
    domain: str = 'POINT'
    active: bool = False
    render: bool = False
    protected: bool = False
    origin: str = ''
    fill: object = None


@dataclass
class Vertex:
    co: tuple = (0.0, 0.0, 0.0)
    selected: bool = False
    hidden: bool = False


@dataclass
class Face:
    vertices: tuple = ()
    material_index: int = 0
    selected: bool = False
    hidden: bool = False
    center: tuple = (0.0, 0.0, 0.0)


@dataclass
class Mesh:
    key: str
    name: str = ''
    readonly: bool = False
    uv: dict = field(default_factory=dict)
    colors: dict = field(default_factory=dict)
    attributes: dict = field(default_factory=dict)
    vertices: list = field(default_factory=list)
    faces: list = field(default_factory=list)
    metadata: dict = field(default_factory=dict)


@dataclass
class Material:
    name: str
    pass_index: int = 0
    color: tuple = (0.8, 0.8, 0.8, 1.0)
    metadata: dict = field(default_factory=dict)
    readonly: bool = False
    origin: str = ''


@dataclass
class Object:
    key: str
    name: str
    kind: str = 'MESH'
    mesh: object = None
    pass_index: int = 0
    color: tuple = (1.0, 1.0, 1.0, 1.0)
    selected: bool = False
    hidden: bool = False
    readonly: bool = False
    mode: str = 'OBJECT'
    slots: list = field(default_factory=list)
    active_slot: int = 0
    groups: dict = field(default_factory=dict)
    group_origins: dict = field(default_factory=dict)
    active_group: str = ''
    metadata: dict = field(default_factory=dict)
    box: tuple = ()
    world_matrix: tuple = ((1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1))


@dataclass
class State:
    entries: list = field(default_factory=list)
    settings: object = field(default_factory=Settings)
    active_index: int = -1
    anchor_index: int = -1
    objects: dict = field(default_factory=dict)
    scene_keys: list = field(default_factory=list)
    materials: dict = field(default_factory=dict)
    collections: dict = field(default_factory=dict)
    collection_readonly: set = field(default_factory=set)
    aovs: dict = field(default_factory=dict)
    active_object: str = ''
    inspector: list = field(default_factory=list)
    inspector_index: int = -1
    inspector_anchor: int = -1
    inspector_omitted: int = 0
    counts_signature: tuple = ()
    report_code: str = ''
    report_values: dict = field(default_factory=dict)
    validation: list = field(default_factory=list)
    ui_help: str = ''

    def clone(self):
        return deepcopy(self)

    def adopt(self, other):
        self.__dict__.clear()
        self.__dict__.update(other.__dict__)

    def scope(self, scope):
        if scope == 'ACTIVE':
            return [self.active_object] if self.active_object in self.objects else []
        keys = [key for key in self.scene_keys if key in self.objects]
        if scope == 'SELECTED':
            return [key for key in keys if self.objects[key].selected]
        if scope == 'SCENE':
            return keys
        if scope == 'ALL_MESHES':
            return [key for key, obj in self.objects.items() if obj.kind == 'MESH']
        from .data_schema import ContractError
        raise ContractError('invalid_field', field='scope')

    def selection_signature(self):
        return (self.settings.library_scope, self.active_object, tuple(sorted(self.scope('SELECTED'))))

    def report(self, code, **values):
        self.report_code = code
        self.report_values = values
