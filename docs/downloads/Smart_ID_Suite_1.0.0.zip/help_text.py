"""Original instructions for the nine panel sections."""
HELP={
"overview":("Create an entry, assign it, then select objects that use it.","項目を作成して割り当てると、その項目を使うものを選択できます。"),
"always_on":("Turn on automatic inspection to follow the current selection.","選択のたびに一覧を更新するには、調査の自動更新を有効にします。"),
"library":("Choose a type and press Add. Select a row to edit its name and number.","種類を選んで追加します。行を選ぶと、名前と番号を編集できます。"),
"entry_details":("Set the number, color or channel name for the selected library row.","一覧で選んだ項目の番号・色・チャンネル名を設定します。"),
"assignment":("Choose the target scope and which Blender data to update.","対象範囲と、書き換えるBlenderデータを指定します。"),
"selection_actions":("Select the target objects, choose a library row and press Apply Entry.","対象物と一覧の項目を選択し、「項目を割り当て」を押します。"),
"channel_tools":("Create or remove the channel named by the current entry.","現在の項目に設定した名前でチャンネルを作成・削除します。"),
"selection_inspector":("Refresh the list, select a row and apply changes to its owner.","調査を更新して行を選ぶと、所有物のデータを編集できます。"),
"visual_overlay":("Enable the overlay and choose which entries to outline in the viewport.","表示を有効にし、ビューポートに枠を描く対象を選びます。"),
"validation_io":("Use JSON to exchange a registry. Use CSV to review it as a table.","一覧の受け渡しにはJSONを、表での確認にはCSVを使います。")}
JA={"Active Entry":"現在の項目","Active Slot":"現在のスロット","Add Entry":"項目を追加","All":"すべて","All Meshes":"全メッシュ","All Slots":"全スロット","Boolean":"真偽値","Both":"両方","Corner":"面コーナー","Create Assign":"作成して割り当て","Custom":"カスタム","Duplicate Entry":"項目を複製","Edge":"辺","Entry Multi Select":"一覧行の複数選択","Face":"面","Float":"浮動小数","Float Color":"浮動小数カラー","Float Vector":"ベクトル","Inspector Items":"調査結果","Inspector Multi Select":"調査行の複数選択","Int":"整数","Last Library Autosync Signature":"一覧の更新記録","Last Report":"直前の結果","Last Report Language":"結果の言語","Manual":"手動","Move Entry":"項目を移動","Open Help":"ヘルプを開く","Point":"ポイント","Remove Entry":"項目を削除","Selected Faces":"選択面","Smart Metadata":"IDの付加情報","Sort Entries":"一覧を並べ替え","Sort Mode":"並べ替え順","Toggle Ui Section":"項目を開閉","Visible Entries":"表示中の項目","3Dsmax":"3ds Max","Zbrush":"ZBrush","Color Id":"カラーID"}

