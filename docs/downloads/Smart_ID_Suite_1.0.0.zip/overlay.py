# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Immutable, bounded overlay geometry. Building it never edits scene data."""
from dataclasses import dataclass
import math
from .data_schema import ContractError
from .library import active_entry, visible_indices, identity
from .inspection import visible_inspector_indices, entry_from_item, decode_reference
from .matching import matches, element_indices
from .colors import named_color

MAX_RECORDS = 240
MAX_MARKS = 1200
MAX_MARKS_PER_OBJECT = 80
MAX_LABELS = 80
MAX_LABEL_CHARS = 48
BOX_EDGES = ((0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),(0,4),(1,5),(2,6),(3,7))
CHANNEL_TYPES = {'MAP_CHANNEL', 'UV_CHANNEL', 'COLOR_ATTRIBUTE', 'GEOMETRY_ATTRIBUTE', 'UDIM_TILE', 'RENDER_AOV'}
GROUP_TYPES = {'SELECTION_SET', 'WEIGHT_GROUP'}


@dataclass(frozen=True)
class OverlayRecord:
    object_key: str
    kind: str
    name: str
    color: tuple
    segments: tuple
    marks: tuple
    mark_size: float


@dataclass(frozen=True)
class OverlayLabel:
    position: tuple
    text: str
    color: tuple


@dataclass(frozen=True)
class OverlaySnapshot:
    records: tuple = ()
    labels: tuple = ()
    mark_count: int = 0
    truncated: bool = False
    warnings: tuple = ()


def world_point(matrix, point):
    if len(matrix) != 4 or any(len(row) != 4 for row in matrix) or len(point) != 3:
        raise ContractError('invalid_geometry')
    vector = tuple(point) + (1.0,)
    transformed = tuple(sum(float(matrix[r][c]) * vector[c] for c in range(4)) for r in range(4))
    if not all(math.isfinite(value) for value in transformed) or abs(transformed[3]) < 1e-12:
        raise ContractError('invalid_geometry')
    return tuple(value / transformed[3] for value in transformed[:3])


def object_box(obj):
    points = tuple(obj.box) or (tuple(vertex.co for vertex in obj.mesh.vertices) if obj.mesh else ())
    if not points:
        return (), world_point(obj.world_matrix, (0, 0, 0)), 0.02
    if any(len(point) != 3 or not all(math.isfinite(float(value)) for value in point) for point in points):
        raise ContractError('invalid_geometry')
    low = tuple(min(point[axis] for point in points) for axis in range(3))
    high = tuple(max(point[axis] for point in points) for axis in range(3))
    corners = ((low[0],low[1],low[2]), (low[0],low[1],high[2]),
               (low[0],high[1],high[2]), (low[0],high[1],low[2]),
               (high[0],low[1],low[2]), (high[0],low[1],high[2]),
               (high[0],high[1],high[2]), (high[0],high[1],low[2]))
    world = tuple(world_point(obj.world_matrix, point) for point in corners)
    edges = tuple((world[a], world[b]) for a, b in BOX_EDGES)
    diagonal = math.sqrt(sum((world[0][axis] - world[6][axis]) ** 2 for axis in range(3)))
    return edges, world[6], max(0.001, diagonal * 0.006)


def _sources(state, localized_inspector_text, warnings):
    source = state.settings.overlay_source
    if source not in ('ACTIVE_ENTRY', 'VISIBLE_ENTRIES', 'INSPECTOR_ITEMS', 'BOTH'):
        raise ContractError('invalid_field', field='overlay_source')
    if source == 'ACTIVE_ENTRY':
        if 0 <= state.active_index < len(state.entries):
            yield active_entry(state), None
    if source in ('VISIBLE_ENTRIES', 'BOTH'):
        for index in visible_indices(state):
            yield state.entries[index], None
    if source in ('INSPECTOR_ITEMS', 'BOTH'):
        for index in visible_inspector_indices(state, localized_inspector_text):
            item = state.inspector[index]
            try:
                entry = entry_from_item(state, item)
                owner = decode_reference(item)[0]
            except ContractError as exc:
                warnings.add(exc.code)
                continue
            if entry.type not in ('OBJECT_ID', 'MATERIAL_ID', 'CUSTOM_ID', 'CRYPTOMATTE_ID'):
                entry.color = named_color(item.name)
            yield entry, owner


def build_overlay(state, label_for=None, localized_inspector_text=None):
    settings = state.settings
    if not settings.overlay_enabled:
        return OverlaySnapshot()
    records = []
    labels = []
    warnings = set()
    seen = set()
    marks_by_object = {}
    mark_total = 0
    truncated = False
    keys = state.scope(settings.library_scope)
    label_for = label_for or (lambda kind, name: kind + ': ' + name)
    boxes = {}
    for entry, owner in _sources(state, localized_inspector_text, warnings):
        if not entry.enabled:
            continue
        if entry.type in CHANNEL_TYPES:
            shown = settings.overlay_show_channels
        elif entry.type in GROUP_TYPES:
            shown = settings.overlay_show_groups
        else:
            shown = settings.overlay_show_ids
        if not shown:
            continue
        color = tuple(entry.color[:3]) + (entry.color[3] * settings.overlay_alpha,)
        for key in keys:
            obj = state.objects[key]
            if obj.hidden or (owner is not None and key != owner) or not matches(state, obj, entry):
                continue
            record_key = (key, identity(entry))
            if record_key in seen:
                continue
            if len(records) >= MAX_RECORDS:
                return OverlaySnapshot(tuple(records), tuple(labels), mark_total, True, tuple(sorted(warnings)))
            seen.add(record_key)
            try:
                if key not in boxes:
                    boxes[key] = object_box(obj)
                edges, anchor, mark_size = boxes[key]
                points = []
                if settings.overlay_element_marks and obj.mesh is not None:
                    kind, indices = element_indices(state, obj, entry)
                    indices = sorted(indices)
                    remaining = max(0, min(MAX_MARKS_PER_OBJECT - marks_by_object.get(key, 0), MAX_MARKS - mark_total))
                    truncated = truncated or len(indices) > remaining
                    for index in indices[:remaining]:
                        point = obj.mesh.faces[index].center if kind == 'FACE' else obj.mesh.vertices[index].co
                        points.append(world_point(obj.world_matrix, point))
                record = OverlayRecord(key, entry.type, entry.name, color,
                                       edges if settings.overlay_object_boxes else (), tuple(points), mark_size)
            except ContractError as exc:
                warnings.add(exc.code)
                continue
            records.append(record)
            marks_by_object[key] = marks_by_object.get(key, 0) + len(points)
            mark_total += len(points)
            if settings.overlay_show_labels:
                if len(labels) < MAX_LABELS:
                    text = label_for(entry.type, entry.name)
                    text = text if len(text) <= MAX_LABEL_CHARS else text[:MAX_LABEL_CHARS - 1] + '…'
                    labels.append(OverlayLabel(anchor, text, color))
                else:
                    truncated = True
    return OverlaySnapshot(tuple(records), tuple(labels), mark_total, truncated, tuple(sorted(warnings)))
