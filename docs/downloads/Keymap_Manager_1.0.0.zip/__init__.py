# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later

"""Keymap manager for Blender 5.1.

This add-on is designed for Blender 5.1.0 on Windows x64 and is also
exercised on Blender 5.1.1 Linux x64 during development.
"""

from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass, field
from typing import Optional

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup, UIList

bl_info = {
    "name": "キーマップマネージャー",
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "Preferences > Keymap > キーマップマネージャー",
    "description": "Manage Blender keymaps from a keyboard layout view and inspect priority conflicts.",
    "category": "Interface",
}

_TRANSLATIONS = {
    "ja_JP": {
        ("*", "キーマップマネージャー"): "キーマップマネージャー",
        ("*", "Keymap Manager"): "キーマップマネージャー",
        ("*", "Manage Blender keymaps from a keyboard layout view and inspect priority conflicts."): "キーボード配列表示からBlenderのキーマップを管理し、ショートカットの優先重複を検出します。",
        ("*", "Preferences > Keymap > キーマップマネージャー"): "プリファレンス > キーマップ > キーマップマネージャー",
        ("*", "Refresh"): "更新",
        ("*", "Display recovery"): "表示の復旧",
        ("*", "Recovered from a display error."): "表示エラーから復旧",
        ("*", "Keyboard Layout could not be drawn."): "配列を描画できません",
        ("*", "This section could not be drawn."): "描画できませんでした",
        ("*", "Keymap data unavailable. Refresh."): "取得できません。更新を押す",
        ("*", "Keyboard Layout"): "キーボード配列",
        ("*", "Mouse Operations"): "マウス操作",
        ("*", "Mouse Buttons"): "マウスボタン",
        ("*", "Wheel / Scroll"): "ホイール/スクロール",
        ("*", "Pointer / Trackpad"): "ポインター/トラックパッド",
        ("*", "3D Mouse / NDOF"): "3Dマウス/NDOF",
        ("*", "Key: {event}"): "キー: {event}",
        ("*", "Select this mouse operation and list matching keymap items. It uses the same registered keymap list and editing controls as the keyboard layout."): "このマウス操作を選択し、一致するキーマップ項目を一覧表示します。キーボード配列と同じ登録済みキーマップ一覧と編集操作を使用します。",
        ("*", "Registered Keymap Items"): "登録済みキーマップ項目",
        ("*", "Key"): "キー",
        ("*", "Input State"): "入力状態",
        ("*", "Key Modifier"): "Key Modifier",
        ("*", "Exact Modifiers"): "修飾キーを一致",
        ("*", "Exact Value"): "入力状態を一致",
        ("*", "Include Disabled"): "無効項目も表示",
        ("*", "Ctrl"): "Ctrl",
        ("*", "Alt"): "Alt",
        ("*", "Hyper"): "Hyper",
        ("*", "Any Modifiers"): "修飾キーを問わない",
        ("*", "No duplicate detected"): "重複なし",
        ("*", "Disabled"): "無効",
        ("*", "Blocked by previous item"): "同一キーマップ内の先行項目が優先",
        ("*", "Overlapped by higher priority"): "上位優先項目と重複",
        ("*", "Enable Target and Disable Higher Priority"): "このキーマップを有効化し上位優先を無効化",
        ("*", "Disable every higher-priority keymap item that currently receives this shortcut first, then enable this selected keymap item. Use this when the selected mode or context should take priority for the same shortcut."): "現在このショートカットを先に受け取っている上位優先キーマップをすべて無効化し、選択中のキーマップ項目を有効化します。同じショートカットで、選択中のモードやコンテキストを優先したい場合に使用します。",
        ("*", "Higher-priority keymaps were disabled ({count}) and this keymap was enabled."): "上位優先キーマップを {count} 件無効化し、このキーマップを有効化しました。",
        ("*", "Higher-priority keymap item was not found; this keymap was enabled only."): "上位優先キーマップ項目が見つからなかったため、このキーマップ項目だけを有効化しました。",
        ("*", "Higher-priority source"): "上位優先元",
        ("*", "Same priority duplicate"): "同順位重複",
        ("KeymapManager", "Context"): "コンテキスト",
        ("*", "Operator"): "オペレーター",
        ("*", "Modal Value"): "モーダル値",
        ("*", "Event"): "イベント",
        ("*", "No keymap item matches the filter."): "一致する項目なし",
        ("*", "Keymaps are not loaded."): "キーマップ未読み込み",
        ("*", "Load Blender Keymap Preset"): "Blenderキーマッププリセットを読み込み",
        ("*", "The Blender keymap preset could not be found."): "Blenderキーマッププリセットが見つかりませんでした。",
        ("*", "The Blender keymap preset was loaded."): "Blenderキーマッププリセットを読み込みました。",
        ("*", "This physical key is shown for the keyboard layout only. Blender 5.1 does not expose it as a keymap event, so no shortcut list can be queried from it."): "この物理キーはキーボード配列の表示用です。Blender 5.1ではキーマップイベントとして公開されていないため、このキーからショートカット一覧を取得できません。",
        ("*", "Select this key in the keyboard layout and list matching keymap items. Use the modifier filters above to narrow the list to modifier combinations."): "キーボード配列上でこのキーを選択し、一致するキーマップ項目を一覧表示します。上部の修飾キーフィルターを使うと、Ctrl、Shift、Alt、OSキー、Hyper、キー修飾の組み合わせまで絞り込めます。",
        ("*", "Re-read the current Blender keyconfig and update the visible keymap list. Use this after changing shortcuts from another Preferences panel."): "現在のBlenderキーマップ設定を再読み込みし、表示中のキーマップ一覧を更新します。別のプリファレンスパネルでショートカットを変更した後に使用します。",
        ("*", "Cycle this modifier between Off, On, and Any for the selected keymap item. Off means the modifier must not be pressed, On means it must be pressed, and Any means either state can match."): "このキーマップ項目の修飾キーを、オフ、オン、任意の順に切り替えます。オフは押されていない状態、オンは押されている状態、任意はどちらの状態でも一致することを意味します。",
        ("*", "Load Blender's default keymap preset into this runtime session. This is mainly useful in background test sessions where Blender has not populated the keymap database yet."): "Blenderの既定キーマッププリセットを現在の実行セッションへ読み込みます。主に、Blenderがキーマップデータベースをまだ生成していないバックグラウンドテストで使用します。",
        ("*", "Current selection: {event}"): "現在の選択: {event}",
        ("*", "Matches: {count}"): "一致数: {count}",
        ("*", "Modifier changed: {modifier} = {state}"): "修飾キーを変更: {modifier} = {state}",
        ("*", "Keymap item was not found."): "キーマップ項目が見つかりませんでした。",
        ("*", "Unsupported"): "未対応",
        ("*", "Unsupported by Blender"): "Blender未対応",
        ("*", "Unknown modifier filter"): "不明な修飾キーフィルター",
        ("*", "This item is disabled and will not run until it is enabled."): "この項目は無効化されているため、有効にするまで実行されません。",
        ("*", "A previous item in the same keymap uses the same event signature. The previous item is tried first; if it cannot run in the current situation, this item runs."): "同じキーマップ内の先行項目が同一のイベント条件を使用しています。先行項目が先に試され、その場面で実行できなければ、この項目が動きます。",
        ("*", "A more specific keymap context uses the same event signature. The actual result depends on the active editor, mode, modal operator, and region."): "より限定されたキーマップコンテキストが同一のイベント条件を使用しています。実際の結果は、現在のエディター、モード、モーダルオペレーター、リージョンに依存します。",
        ("*", "Another item with the same estimated priority uses the same event signature. Check the context before assuming either item will run."): "推定優先度が同じ別項目が同一のイベント条件を使用しています。どちらが実行されるか判断する前に、コンテキストを確認してください。",
        ("*", "No enabled item with the same event signature was found above this item in the scanned keymaps."): "走査したキーマップ内で、この項目より優先される同一イベント条件の有効項目は見つかりませんでした。",
        ("*", "Backspace"): "Backspace",
        ("*", "Insert"): "Insert",
        ("*", "Page Up"): "Page Up",
        ("*", "Page Down"): "Page Down",
        ("*", "Num Lock"): "Num Lock",
        ("*", "Scroll Lock"): "Scroll Lock",
        ("*", "Pause"): "Pause",
        ("*", "Print Screen"): "Print Screen",
        ("*", "Caps Lock"): "Caps Lock",
        ("*", "Select Key"): "キーを選択",
        ("*", "Cycle Modifier"): "修飾キーを切り替え",
        ("*", "Blender event type used as the base key. Choose from this list or click a key in the keyboard layout below."): "基準キーとして使うBlenderイベントタイプです。この一覧から選ぶか、下のキーボード配列でキーをクリックします。",
        ("*", "Input state to match when Exact Value is enabled. Press is the normal state for keyboard shortcuts; Release and Any are also used by some keymaps."): "入力状態を一致させる設定が有効な場合に照合する状態です。通常のキーボードショートカットでは「押下」を使いますが、一部のキーマップでは「リリース」や「全て」も使われます。",
        ("*", "When Exact Modifiers is enabled, list shortcuts that require Ctrl. Keymap items marked Any still match either state."): "修飾キー一致が有効な場合、Ctrlを必要とするショートカットを表示します。修飾キーが「任意」のキーマップ項目は、どちらの状態にも一致します。",
        ("*", "When Exact Modifiers is enabled, list shortcuts that require Shift. Keymap items marked Any still match either state."): "修飾キー一致が有効な場合、Shiftを必要とするショートカットを表示します。修飾キーが「任意」のキーマップ項目は、どちらの状態にも一致します。",
        ("*", "When Exact Modifiers is enabled, list shortcuts that require Alt. Keymap items marked Any still match either state."): "修飾キー一致が有効な場合、Altを必要とするショートカットを表示します。修飾キーが「任意」のキーマップ項目は、どちらの状態にも一致します。",
        ("*", "When Exact Modifiers is enabled, list shortcuts that require the operating-system key. On Windows this is commonly the Windows key."): "修飾キー一致が有効な場合、OSキーを必要とするショートカットを表示します。Windowsでは一般的にWindowsキーです。",
        ("*", "When Exact Modifiers is enabled, list shortcuts that require Hyper. Most standard Windows keyboards do not expose a dedicated Hyper key."): "修飾キー一致が有効な場合、Hyperを必要とするショートカットを表示します。標準的なWindowsキーボードの多くには、専用のHyperキーはありません。",
        ("*", "Optional secondary key modifier. When Exact Modifiers is enabled, shortcuts with a different key modifier are hidden."): "任意の二次キー修飾です。修飾キー一致が有効な場合、異なるキー修飾を持つショートカットは非表示になります。",
        ("*", "When enabled, only keymap items with the selected Ctrl, Shift, Alt, OS Key, Hyper, and key-modifier states are shown. When disabled, all modifier variants of the selected physical key are shown."): "有効にすると、選択したCtrl、Shift、Alt、OSキー、Hyper、キー修飾の状態に一致するキーマップ項目だけを表示します。無効にすると、選択した物理キーの全修飾バリアントを表示します。",
        ("*", "When enabled, only keymap items with the selected input state are shown. When disabled, Press, Release, Click, Drag, Any, and other value variants for the selected key are all shown."): "有効にすると、選択した入力状態に一致するキーマップ項目だけを表示します。無効にすると、選択したキーの押下、リリース、クリック、ドラッグ、全てなど、すべての入力状態を表示します。",
        ("*", "Show disabled keymap items as well as enabled ones. Disabled items are marked because they cannot run until their Active checkbox is enabled."): "有効なキーマップ項目だけでなく、無効な項目も表示します。無効な項目は詳細の「有効」を入れるまで実行されないため、一覧内で明示します。",
        ("*", "Enter an operator identifier such as wm.save_mainfile. When this field is not empty, the keyboard layout highlights keys assigned to that operator, and the registered item list shows those assignments together with keymaps that use the same shortcut event."): "wm.save_mainfile のようなオペレーター識別子を入力します。この欄が空でない場合、キーボード配列ではそのオペレーターに割り当てられているキーを強調表示し、登録済み項目一覧ではその割り当てと同じショートカット条件を使うキーマップを表示します。",
        ("*", "Assigned Keys"): "割り当てキー",
        ("*", "No assigned key found for this operator ID."): "このオペレーターIDに割り当てられているキーは見つかりません。",
        ("*", "Operator ID filter is active"): "オペレーターID検索中",
        ("*", "Assigned Operator"): "割り当てオペレーター",
        ("*", "Conflicting Operator"): "競合オペレーター",
        ("*", "Operator ID"): "オペレーターID",
        ("*", "Copy Operator ID"): "オペレーターIDをコピー",
        ("*", "Copy the operator identifier to the clipboard so it can be pasted into scripts, documentation, or search fields."): "オペレーター識別子をクリップボードへコピーし、スクリプト、資料、検索欄へ貼り付けられるようにします。",
        ("*", "Copied operator ID: {operator_id}"): "オペレーターIDをコピーしました: {operator_id}",
        ("*", "Operator ID is not available for this keymap item."): "このキーマップ項目ではオペレーターIDを取得できません。",

        ("*", "When active"): "有効条件",
        ("*", "Priority"): "優先度",
        ("*", "Enabled"): "有効",
        ("*", "Effective"): "有効",
        ("*", "Partly Shadowed"): "一部で上位優先",
        ("*", "None"): "なし",
        ("KeymapManager", "Earlier Item First"): "先行項目が優先",
        ("KeymapManager", "Duplicate"): "重複",
        ("*", "Event Signature"): "イベント条件",
        ("*", "Priority order"): "優先順",
        ("KeymapManager", "Status"): "状況",
        ("*", "Available when the active keymap context matches: {context}"): "有効なキーマップコンテキストが次に一致する場合に動作します: {context}",
        ("*", "Enabled Modes"): "有効モード",
        ("*", "No enabled mode found"): "有効モードなし",
        ("*", "Conflict Disabled Modes"): "競合で無効なモード",
        ("*", "Manually Disabled Modes"): "手動で無効なモード",
        ("*", "No conflict-disabled mode found"): "競合で無効なモードなし",
        ("*", "No manually disabled mode found"): "手動で無効なモードなし",
        ("*", "Priority Source"): "優先元",
        ("*", "Toggle Modifier Filter"): "修飾キーフィルター切替",
        ("*", "Toggle this modifier key for the keyboard layout search. Turn it on before or after choosing a normal key to search shortcuts such as Ctrl+S separately from S."): "キーボード配列検索用の修飾キーを切り替えます。通常キーを選ぶ前後に有効化すると、S と Ctrl+S のようなショートカットを別々に検索できます。",
        ("*", "Consolidate Duplicate Keymaps"): "重複キーマップを集約",
        ("*", "Show Conflicting Keymaps"): "競合キーマップを表示",
        ("*", "Show all keymap items that use the same shortcut inside the same registration location."): "同じ登録場所内で同じショートカットを使用しているキーマップ項目をすべて表示します。",
        ("*", "Show Unused Keymaps"): "未使用キーマップを表示",
        ("*", "Show parent categories and list shortcut candidates that are not used in the selected registration category."): "親カテゴリーを表示し、選択した登録カテゴリー内で未使用のショートカット候補を一覧表示します。",
        ("*", "Parent Categories"): "親カテゴリー",
        ("*", "Subcategories"): "サブカテゴリー",
        ("*", "Unused Shortcut Candidates"): "未使用ショートカット候補",
        ("*", "No unused shortcut candidate was found."): "未使用ショートカット候補は見つかりませんでした。",
        ("*", "Select Category"): "カテゴリーを選択",
        ("*", "Select Subcategory"): "サブカテゴリーを選択",
        ("*", "Conflict Group"): "競合グループ",
        ("*", "Base Key"): "基準キー",
        ("KeymapManager", "Back"): "戻る",
        ("*", "Preview duplicate keymap items when the same keymap location has the same operator ID, shortcut key and settings, then consolidate them after confirmation. The first item is kept and the others are removed."): "同じ登録場所でオペレーターID・ショートカットキー・設定のすべてが重複しているキーマップ項目を事前確認し、確認後に集約します。先頭の1項目だけを残し、他を削除します。",
        ("*", "Group"): "グループ",
        ("*", "Items"): "項目",
        ("*", "ID"): "ID",
        ("*", "Shortcut"): "キー",
        ("*", "Duplicate keymaps were consolidated: {count} removed."): "重複キーマップを集約しました: {count}件削除。",
        ("*", "Confirm Duplicate Keymap Consolidation"): "重複キーマップの集約確認",
        ("*", "Consolidate"): "集約",
        ("*", "Cancel"): "キャンセル",
        ("*", "Duplicate groups found: {groups}, items to remove: {count}"): "重複グループ: {groups}件 / 削除予定: {count}件",
        ("*", "The following duplicate keymap items will be removed. Choose Consolidate to keep only the first item in each duplicate group, or Cancel to make no changes."): "以下の重複キーマップ項目を削除予定です。集約を選ぶと各重複グループの先頭1件だけを残し、キャンセルを選ぶと変更しません。",
        ("*", "No duplicate keymap was found."): "集約対象の重複キーマップは見つかりませんでした。",
        ("KeymapManager", "Keep"): "残す",
        ("*", "Remove"): "削除",

        ("*", "Show Visual Overview"): "キーマップ可視化を表示",
        ("*", "Keymap Visual Overview"): "キーマップ可視化",
        ("*", "Switch the list to an overview of assigned keys, grouped by base key (the key without modifiers). Press again to return to the normal list."): "割り当て済みのキーを基準キー（修飾キーを除いたキー）ごとにまとめた一覧に切り替えます。もう一度押すとふつうの一覧に戻ります。",
        ("*", "Visualization Filters"): "可視化フィルター",
        ("*", "Editor Filter"): "エディターフィルター",
        ("*", "Mode Filter"): "モードフィルター",
        ("*", "Search Filter"): "検索フィルター",
        ("*", "All Editors"): "全エディター",
        ("*", "All Modes"): "全モード",
        ("*", "Narrow the visual overview to the keymaps of the selected editor."): "キーマップ可視化の一覧を、選んだエディターのキーマップに絞ります。",
        ("*", "Filter by keymap mode name, such as Object Mode, Mesh, Pose, or Sculpt."): "オブジェクトモード、メッシュ、ポーズ、スカルプトなどのキーマップモード名で絞り込みます。",
        ("*", "Filter visible bindings by operator ID, operator label, keymap location, or shortcut text."): "オペレーターID、機能名、登録場所、ショートカット文字列で表示中の割り当てを絞り込みます。",
        ("*", "No keymap binding for the filters."): "一致するキーマップなし",
        ("*", "Active Bindings"): "有効割り当て",
        ("*", "Inactive Bindings"): "無効割り当て",
        ("*", "Keymap Import / Export / Presets"): "キーマップ入出力 / プリセット",
        ("*", "Export Path"): "エクスポート先",
        ("*", "Import Path"): "インポート元",
        ("*", "Export Scope"): "エクスポート範囲",
        ("*", "Modified Only"): "変更済みのみ",
        ("*", "All Keymaps"): "全キーマップ",
        ("*", "Export Keymap"): "キーマップをエクスポート",
        ("*", "Import Keymap"): "キーマップをインポート",
        ("*", "Preset Name"): "プリセット名",
        ("*", "Preset"): "プリセット",
        ("*", "Save Preset"): "プリセットを保存",
        ("*", "Load Preset"): "プリセットを読み込み",
        ("*", "Delete Preset"): "プリセットを削除",
        ("*", "No Preset"): "プリセットなし",
        ("*", "Clear Visual Filters"): "可視化フィルターをクリア",
        ("*", "Export the current user keymap to a JELararagi keymap JSON file stored in the user configuration directory or the selected path."): "現在のユーザーキーマップを、ユーザー設定ディレクトリまたは指定パスに JELararagi キーマップJSONとしてエクスポートします。",
        ("*", "Import a JELararagi keymap JSON file and append the stored bindings to the user keymap. Existing bindings are not removed automatically."): "JELararagi キーマップJSONを読み込み、保存された割り当てをユーザーキーマップへ追加します。既存割り当ては自動削除されません。",
        ("*", "Save the current keymap as a named preset in Blender's user configuration directory. The add-on install directory is never modified."): "現在のキーマップを名前付きプリセットとして Blender のユーザー設定ディレクトリへ保存します。アドオンのインストール先は変更しません。",
        ("*", "Load the selected keymap preset and append its stored bindings to the user keymap."): "選択したキーマッププリセットを読み込み、保存された割り当てをユーザーキーマップへ追加します。",
        ("*", "Delete the selected keymap preset from the user configuration directory."): "選択したキーマッププリセットをユーザー設定ディレクトリから削除します。",
        ("*", "Keymap exported: {path}"): "キーマップをエクスポートしました: {path}",
        ("*", "Keymap imported: {count} bindings"): "キーマップをインポートしました: {count}件",
        ("*", "Keymap imported: {count} bindings, {skipped} could not be read completely"): "キーマップをインポートしました: {count}件（{skipped}件は読み込めない部分がありました）",
        ("*", "Preset saved: {name}"): "プリセットを保存しました: {name}",
        ("*", "Preset loaded: {name} / {count} bindings"): "プリセットを読み込みました: {name} / {count}件",
        ("*", "Preset loaded: {name} / {count} bindings, {skipped} could not be read completely"): "プリセットを読み込みました: {name} / {count}件（{skipped}件は読み込めない部分がありました）",
        ("*", "Preset deleted: {name}"): "プリセットを削除しました: {name}",
        ("*", "No preset is selected."): "プリセットが選択されていません。",
        ("*", "Preset name is empty."): "プリセット名が空です。",
        ("*", "Import file was not found."): "インポートファイルが見つかりません。",
        ("*", "Conflict view is active."): "競合キーマップ表示中",
        ("*", "Unused keymap view is active."): "未使用キーマップ表示中",
        ("*", "OS Key"): "OSキー",
        ("*", "Modal"): "モーダル",
        ("KeymapManager", "On"): "オン",
        ("KeymapManager", "Off"): "オフ",
        ("KeymapManager", "Any"): "任意",
        ("KeymapManager", "Numpad {key}"): "テンキー {key}",
        ("KeymapManager", "LMB"): "左ボタン",
        ("KeymapManager", "MMB"): "中ボタン",
        ("KeymapManager", "RMB"): "右ボタン",
        ("KeymapManager", "MB4"): "ボタン4",
        ("KeymapManager", "MB5"): "ボタン5",
        ("KeymapManager", "MB6"): "ボタン6",
        ("KeymapManager", "MB7"): "ボタン7",
        ("KeymapManager", "Wheel Up"): "ホイール上",
        ("KeymapManager", "Wheel Down"): "ホイール下",
        ("KeymapManager", "Wheel In"): "ホイールイン",
        ("KeymapManager", "Wheel Out"): "ホイールアウト",
        ("KeymapManager", "Wheel Left"): "ホイール左",
        ("KeymapManager", "Wheel Right"): "ホイール右",
        ("KeymapManager", "Mouse Move"): "マウス移動",
        ("KeymapManager", "In-between Move"): "中間移動",
        ("KeymapManager", "Trackpad Pan"): "パッドパン",
        ("KeymapManager", "Trackpad Zoom"): "パッドズーム",
        ("KeymapManager", "Mouse Rotate"): "マウス回転",
        ("KeymapManager", "Smart Zoom"): "スマートズーム",
        ("KeymapManager_Literal", "Key"): "キー",
        ("KeymapManager_Literal", "Input State"): "入力状態",
        ("KeymapManager_Literal", "Key Modifier"): "Key Modifier",
        ("KeymapManager_Literal", "Editor Filter"): "エディターフィルター",
        ("KeymapManager_Literal", "Mode Filter"): "モードフィルター",
        ("KeymapManager_Literal", "Preset"): "プリセット",
        ("KeymapManager_Literal", "Value"): "値",
        ("*", "Global"): "グローバル",
        ("*", "Dopesheet"): "ドープシート",
        ("*", "Movie Clip Editor"): "クリップエディター",
        ("*", "Tool Shelf"): "ツールシェルフ",
        ("*", "Keymap item could not be removed."): "キーマップ項目を削除できませんでした。",
        ("*", "The file could not be read."): "ファイルを読み込めませんでした。",
        ("*", "The file could not be written."): "ファイルを書き込めませんでした。",
        ("*", "The preset file could not be deleted."): "プリセットのファイルを削除できませんでした。",
        ("*", "Keymap Manager Help"): "キーマップマネージャーのヘルプ",
        ("*", "Show help for this section."): "この部分のヘルプを表示します。",
        ("*", "Choose Value"): "値を選択",
        ("*", "Choose a value for this keymap item."): "このキーマップ項目の値を選びます。",
        ("*", "Reset the visual overview editor, mode, and search filters."): "可視化のエディター、モード、検索のフィルターを元に戻します。",
        ("*", "Choose whether to export all user keymap items or only items that appear changed from the default keymap."): "ユーザーキーマップの全項目を書き出すか、既定のキーマップから変更された項目だけを書き出すかを選びます。",
        ("*", "Export only keymap items that differ from Blender's default keymap."): "Blenderの既定のキーマップと異なる項目だけを書き出します。",
        ("*", "Export every user keymap item."): "ユーザーキーマップの全項目を書き出します。",
        ("*", "Name used when saving the current keymap as a preset in Blender's user configuration directory."): "現在のキーマップをBlenderのユーザー設定ディレクトリへプリセットとして保存する時の名前です。",
        ("*", "Select a saved keymap preset to load or delete."): "読み込みまたは削除する保存済みプリセットを選びます。",
    }
}

# オペレーターの名前は専用の文脈で引く（本体の訳が混ざらないように）
for _key, _value in list(_TRANSLATIONS["ja_JP"].items()):
    if _key[0] == "*":
        _TRANSLATIONS["ja_JP"].setdefault(("KeymapManager", _key[1]), _value)
del _key, _value

# 本体に訳がある語でも訳させず、こちらで作った文字をそのまま出す列挙の文脈
_LITERAL_CONTEXT = "KeymapManager_Literal"


def _tr(message: str) -> str:
    # 日本語以外は全部英語にする（本体に別の言語の訳があっても使わない）
    if not _is_japanese_ui():
        return message
    translated = _TRANSLATIONS["ja_JP"].get(("*", message))
    if translated is not None:
        return translated
    return bpy.app.translations.pgettext_iface(message)


def _tr_ctx(message: str) -> str:
    # Blender 本体にも訳がある語は既定の文脈だと本体の訳が勝つので、専用の文脈で引く
    if not _is_japanese_ui():
        return message
    return bpy.app.translations.pgettext_iface(message, "KeymapManager")


def _rna_text(name: str, translation_context: str = "*") -> str:
    # 本体の RNA の名前：日本語では本体の訳、それ以外は英語のまま
    if not name or not _is_japanese_ui():
        return name
    own = _TRANSLATIONS["ja_JP"].get(("*", name))
    if own is not None:
        return own
    translated = bpy.app.translations.pgettext_iface(name, translation_context)
    if translated == name:
        translated = _tr(name)
    return translated


def _enum_items_from_rna(rna_type, prop_name: str):
    prop = rna_type.bl_rna.properties[prop_name]
    items = []
    for item in prop.enum_items:
        name = item.name if item.name else item.identifier.title()
        description = item.description if item.description else name
        items.append((item.identifier, name, description))
    return items


_EVENT_TYPE_ITEMS = _enum_items_from_rna(bpy.types.Event, "type")
_KMI_TYPE_ITEMS = _enum_items_from_rna(bpy.types.KeyMapItem, "type")
_KMI_VALUE_ITEMS = _enum_items_from_rna(bpy.types.KeyMapItem, "value")
_KEY_MODIFIER_ITEMS = _enum_items_from_rna(bpy.types.KeyMapItem, "key_modifier")
_LOCALIZED_ENUM_CACHE: dict[tuple, list] = {}


def _enum_item_number(items, identifier: str) -> int:
    for number, item in enumerate(items):
        if item[0] == identifier:
            return number
    return 0


def _localized_enum_items(cache_name: str, source, translation_context: str):
    # 表示名をこちらで決める列挙（項目の文字は Blender が持ち続けるので、一覧は残しておく）
    cache_key = (cache_name, bpy.app.translations.locale, _is_japanese_ui())
    items = _LOCALIZED_ENUM_CACHE.get(cache_key)
    if items is None:
        items = [
            (identifier, _rna_text(name, translation_context), description if description != name else "", number)
            for number, (identifier, name, description) in enumerate(source)
        ]
        _LOCALIZED_ENUM_CACHE[cache_key] = items
    return items


def _selected_type_items(_self, _context):
    return _localized_enum_items("type", _EVENT_TYPE_ITEMS, "UI_Events_KeyMaps")


def _selected_value_items(_self, _context):
    return _localized_enum_items("value", _KMI_VALUE_ITEMS, "*")


def _selected_key_modifier_items(_self, _context):
    return _localized_enum_items("key_modifier", _KEY_MODIFIER_ITEMS, "UI_Events_KeyMaps")


@dataclass(frozen=True)
class _KeySpec:
    event_type: Optional[str]
    label: str
    units: float = 3.0
    supported: bool = True
    modifier: Optional[str] = None


_MAIN_BLOCK_ROWS: tuple[tuple[_KeySpec, ...], ...] = (
    (
        _KeySpec("ESC", "Esc", 3.0), _KeySpec(None, "", 2.1, False),
        _KeySpec("F1", "F1", 3.0), _KeySpec("F2", "F2", 3.0), _KeySpec("F3", "F3", 3.0), _KeySpec("F4", "F4", 3.0),
        _KeySpec(None, "", 1.3, False),
        _KeySpec("F5", "F5", 3.0), _KeySpec("F6", "F6", 3.0), _KeySpec("F7", "F7", 3.0), _KeySpec("F8", "F8", 3.0),
        _KeySpec(None, "", 1.3, False),
        _KeySpec("F9", "F9", 3.0), _KeySpec("F10", "F10", 3.0), _KeySpec("F11", "F11", 3.0), _KeySpec("F12", "F12", 3.0),
    ),
    (
        _KeySpec("ACCENT_GRAVE", "`", 3.0), _KeySpec("ONE", "1", 3.0), _KeySpec("TWO", "2", 3.0), _KeySpec("THREE", "3", 3.0),
        _KeySpec("FOUR", "4", 3.0), _KeySpec("FIVE", "5", 3.0), _KeySpec("SIX", "6", 3.0), _KeySpec("SEVEN", "7", 3.0),
        _KeySpec("EIGHT", "8", 3.0), _KeySpec("NINE", "9", 3.0), _KeySpec("ZERO", "0", 3.0), _KeySpec("MINUS", "-", 3.0),
        _KeySpec("EQUAL", "=", 3.0), _KeySpec("BACK_SPACE", "Backspace", 5.9),
    ),
    (
        _KeySpec("TAB", "Tab", 4.45), _KeySpec("Q", "Q", 3.0), _KeySpec("W", "W", 3.0), _KeySpec("E", "E", 3.0),
        _KeySpec("R", "R", 3.0), _KeySpec("T", "T", 3.0), _KeySpec("Y", "Y", 3.0), _KeySpec("U", "U", 3.0),
        _KeySpec("I", "I", 3.0), _KeySpec("O", "O", 3.0), _KeySpec("P", "P", 3.0), _KeySpec("LEFT_BRACKET", "[", 3.0),
        _KeySpec("RIGHT_BRACKET", "]", 3.0), _KeySpec("BACK_SLASH", "\\", 4.45),
    ),
    (
        _KeySpec(None, "Caps Lock", 5.25, False), _KeySpec("A", "A", 3.0), _KeySpec("S", "S", 3.0), _KeySpec("D", "D", 3.0),
        _KeySpec("F", "F", 3.0), _KeySpec("G", "G", 3.0), _KeySpec("H", "H", 3.0), _KeySpec("J", "J", 3.0), _KeySpec("K", "K", 3.0),
        _KeySpec("L", "L", 3.0), _KeySpec("SEMI_COLON", ";", 3.0), _KeySpec("QUOTE", "'", 3.0), _KeySpec("RET", "Enter", 6.15),
    ),
    (
        _KeySpec("LEFT_SHIFT", "Shift", 6.75, True, "shift"), _KeySpec("Z", "Z", 3.0), _KeySpec("X", "X", 3.0), _KeySpec("C", "C", 3.0),
        _KeySpec("V", "V", 3.0), _KeySpec("B", "B", 3.0), _KeySpec("N", "N", 3.0), _KeySpec("M", "M", 3.0),
        _KeySpec("COMMA", ",", 3.0), _KeySpec("PERIOD", ".", 3.0), _KeySpec("SLASH", "/", 3.0), _KeySpec("RIGHT_SHIFT", "Shift", 7.8, True, "shift"),
    ),
    (
        _KeySpec("LEFT_CTRL", "Ctrl", 4.0, True, "ctrl"), _KeySpec(None, "OS", 3.8, True, "oskey"), _KeySpec("LEFT_ALT", "Alt", 4.0, True, "alt"),
        _KeySpec("SPACE", "Space", 13.9), _KeySpec("RIGHT_ALT", "Alt", 4.0, True, "alt"), _KeySpec(None, "OS", 3.8, True, "oskey"), _KeySpec("RIGHT_CTRL", "Ctrl", 4.0, True, "ctrl"),
    ),
)

_NAV_BLOCK_ROWS: tuple[tuple[_KeySpec, ...], ...] = (
    (_KeySpec(None, "PrtSc", 3.8, False), _KeySpec(None, "Scroll Lock", 3.8, False), _KeySpec("PAUSE", "Pause", 3.8)),
    (_KeySpec("INSERT", "Insert", 3.8), _KeySpec("HOME", "Home", 3.8), _KeySpec("PAGE_UP", "Page Up", 3.8)),
    (_KeySpec("DEL", "Delete", 3.8), _KeySpec("END", "End", 3.8), _KeySpec("PAGE_DOWN", "Page Down", 3.8)),
    (_KeySpec(None, "", 3.8, False), _KeySpec(None, "", 3.8, False), _KeySpec(None, "", 3.8, False)),
    (_KeySpec(None, "", 3.8, False), _KeySpec("UP_ARROW", "↑", 3.8), _KeySpec(None, "", 3.8, False)),
    (_KeySpec("LEFT_ARROW", "←", 3.8), _KeySpec("DOWN_ARROW", "↓", 3.8), _KeySpec("RIGHT_ARROW", "→", 3.8)),
)

_NUMPAD_TOP_SPACER = (_KeySpec(None, "", 3.3, False), _KeySpec(None, "", 3.3, False), _KeySpec(None, "", 3.3, False), _KeySpec(None, "", 3.3, False))
_NUMPAD_ROW_1 = (_KeySpec(None, "NumLk", 3.3, False), _KeySpec("NUMPAD_SLASH", "/", 3.3), _KeySpec("NUMPAD_ASTERIX", "*", 3.3), _KeySpec("NUMPAD_MINUS", "-", 3.3))
_NUMPAD_ROW_2 = (_KeySpec("NUMPAD_7", "7", 3.3), _KeySpec("NUMPAD_8", "8", 3.3), _KeySpec("NUMPAD_9", "9", 3.3))
_NUMPAD_ROW_3 = (_KeySpec("NUMPAD_4", "4", 3.3), _KeySpec("NUMPAD_5", "5", 3.3), _KeySpec("NUMPAD_6", "6", 3.3))
_NUMPAD_ROW_4 = (_KeySpec("NUMPAD_1", "1", 3.3), _KeySpec("NUMPAD_2", "2", 3.3), _KeySpec("NUMPAD_3", "3", 3.3))
_NUMPAD_ROW_5 = (_KeySpec("NUMPAD_0", "0", 6.6), _KeySpec("NUMPAD_PERIOD", ".", 3.3))

_MOUSE_BUTTON_ROWS: tuple[tuple[_KeySpec, ...], ...] = (
    (
        _KeySpec("BUTTON4MOUSE", "MB4", 3.6),
        _KeySpec("LEFTMOUSE", "LMB", 4.4),
        _KeySpec("MIDDLEMOUSE", "MMB", 4.4),
        _KeySpec("RIGHTMOUSE", "RMB", 4.4),
        _KeySpec("BUTTON5MOUSE", "MB5", 3.6),
    ),
    (
        _KeySpec("BUTTON6MOUSE", "MB6", 3.6),
        _KeySpec("BUTTON7MOUSE", "MB7", 3.6),
    ),
)

_MOUSE_WHEEL_ROWS: tuple[tuple[_KeySpec, ...], ...] = (
    (
        _KeySpec("WHEELUPMOUSE", "Wheel Up", 5.2),
        _KeySpec("WHEELDOWNMOUSE", "Wheel Down", 5.2),
    ),
    (
        _KeySpec("WHEELINMOUSE", "Wheel In", 5.2),
        _KeySpec("WHEELOUTMOUSE", "Wheel Out", 5.2),
    ),
    (
        _KeySpec("WHEELLEFTMOUSE", "Wheel Left", 5.2),
        _KeySpec("WHEELRIGHTMOUSE", "Wheel Right", 5.2),
    ),
)

_MOUSE_POINTER_ROWS: tuple[tuple[_KeySpec, ...], ...] = (
    (
        _KeySpec("MOUSEMOVE", "Mouse Move", 6.0),
        _KeySpec("INBETWEEN_MOUSEMOVE", "In-between Move", 6.0),
    ),
    (
        _KeySpec("TRACKPADPAN", "Trackpad Pan", 6.0),
        _KeySpec("TRACKPADZOOM", "Trackpad Zoom", 6.0),
    ),
    (
        _KeySpec("MOUSEROTATE", "Mouse Rotate", 6.0),
        _KeySpec("MOUSESMARTZOOM", "Smart Zoom", 6.0),
    ),
)

_NDOF_ROWS: tuple[tuple[_KeySpec, ...], ...] = (
    (
        _KeySpec("NDOF_MOTION", "NDOF Motion", 5.2),
        _KeySpec("NDOF_BUTTON_MENU", "Menu", 3.8),
        _KeySpec("NDOF_BUTTON_FIT", "Fit", 3.8),
    ),
    (
        _KeySpec("NDOF_BUTTON_TOP", "Top", 3.5),
        _KeySpec("NDOF_BUTTON_BOTTOM", "Bottom", 4.4),
        _KeySpec("NDOF_BUTTON_LEFT", "Left", 3.5),
        _KeySpec("NDOF_BUTTON_RIGHT", "Right", 3.8),
    ),
    (
        _KeySpec("NDOF_BUTTON_FRONT", "Front", 4.2),
        _KeySpec("NDOF_BUTTON_BACK", "Back", 4.2),
        _KeySpec("NDOF_BUTTON_ISO1", "Iso 1", 3.8),
        _KeySpec("NDOF_BUTTON_ISO2", "Iso 2", 3.8),
    ),
    (
        _KeySpec("NDOF_BUTTON_ROLL_CW", "Roll CW", 4.2),
        _KeySpec("NDOF_BUTTON_ROLL_CCW", "Roll CCW", 4.6),
        _KeySpec("NDOF_BUTTON_SPIN_CW", "Spin CW", 4.2),
        _KeySpec("NDOF_BUTTON_SPIN_CCW", "Spin CCW", 4.6),
    ),
    (
        _KeySpec("NDOF_BUTTON_TILT_CW", "Tilt CW", 4.2),
        _KeySpec("NDOF_BUTTON_TILT_CCW", "Tilt CCW", 4.6),
        _KeySpec("NDOF_BUTTON_ROTATE", "Rotate", 4.2),
        _KeySpec("NDOF_BUTTON_PANZOOM", "Pan/Zoom", 4.8),
    ),
    (
        _KeySpec("NDOF_BUTTON_DOMINANT", "Dominant", 5.0),
        _KeySpec("NDOF_BUTTON_PLUS", "Plus", 3.6),
        _KeySpec("NDOF_BUTTON_MINUS", "Minus", 3.8),
    ),
    (
        _KeySpec("NDOF_BUTTON_V1", "View 1", 3.8),
        _KeySpec("NDOF_BUTTON_V2", "View 2", 3.8),
        _KeySpec("NDOF_BUTTON_V3", "View 3", 3.8),
    ),
    (
        _KeySpec("NDOF_BUTTON_SAVE_V1", "Save V1", 4.2),
        _KeySpec("NDOF_BUTTON_SAVE_V2", "Save V2", 4.2),
        _KeySpec("NDOF_BUTTON_SAVE_V3", "Save V3", 4.2),
    ),
    (
        _KeySpec("NDOF_BUTTON_1", "NDOF 1", 3.6),
        _KeySpec("NDOF_BUTTON_2", "NDOF 2", 3.6),
        _KeySpec("NDOF_BUTTON_3", "NDOF 3", 3.6),
        _KeySpec("NDOF_BUTTON_4", "NDOF 4", 3.6),
    ),
    (
        _KeySpec("NDOF_BUTTON_5", "NDOF 5", 3.6),
        _KeySpec("NDOF_BUTTON_6", "NDOF 6", 3.6),
        _KeySpec("NDOF_BUTTON_7", "NDOF 7", 3.6),
        _KeySpec("NDOF_BUTTON_8", "NDOF 8", 3.6),
    ),
    (
        _KeySpec("NDOF_BUTTON_9", "NDOF 9", 3.6),
        _KeySpec("NDOF_BUTTON_10", "NDOF 10", 4.0),
        _KeySpec("NDOF_BUTTON_11", "NDOF 11", 4.0),
        _KeySpec("NDOF_BUTTON_12", "NDOF 12", 4.0),
    ),
)

_AVAILABLE_EVENT_IDENTIFIERS_CACHE: Optional[set[str]] = None
_HIERARCHY_CACHE: Optional[tuple[dict[tuple[str, str, str], int], dict[tuple[str, str, str], str], dict[tuple[str, str, str], int]]] = None
_HIERARCHY_TREE_CACHE: Optional[tuple] = None
_VIEW_CACHE_VISIBLE_INTERVAL = 0.75
_VIEW_CACHE: dict[str, object] = {
    "dirty": True,
    "all_signature": None,
    "state_signature": None,
    "visible_signature": None,
    "all_items": [],
    "matches": [],
    "operator_assignments": [],
    "last_structure_check": 0.0,
    "last_visible_check": 0.0,
}


def _available_event_identifiers() -> set[str]:
    global _AVAILABLE_EVENT_IDENTIFIERS_CACHE
    if _AVAILABLE_EVENT_IDENTIFIERS_CACHE is None:
        _AVAILABLE_EVENT_IDENTIFIERS_CACHE = {item.identifier for item in bpy.types.Event.bl_rna.properties["type"].enum_items}
    return _AVAILABLE_EVENT_IDENTIFIERS_CACHE


class KMM_ConsolidationPreviewRow(PropertyGroup):
    row_type: StringProperty(default="INFO")
    text: StringProperty(default="")
    detail: StringProperty(default="")
    group_index: IntProperty(default=0)
    keyconfig_name: StringProperty(default="")
    keymap_name: StringProperty(default="")
    space_type: StringProperty(default="EMPTY")
    region_type: StringProperty(default="WINDOW")
    is_modal: BoolProperty(default=False)
    kmi_id: IntProperty(default=-1)


_SPACE_TYPE_LABELS = {
    "ALL": "All Editors",
    "EMPTY": "Global",
    "VIEW_3D": "3D View",
    "IMAGE_EDITOR": "Image Editor",
    "NODE_EDITOR": "Node Editor",
    "TEXT_EDITOR": "Text Editor",
    "SEQUENCE_EDITOR": "Sequencer",
    "CLIP_EDITOR": "Movie Clip Editor",
    "DOPESHEET_EDITOR": "Dopesheet",
    "GRAPH_EDITOR": "Graph Editor",
    "NLA_EDITOR": "NLA Editor",
    "PROPERTIES": "Properties",
    "OUTLINER": "Outliner",
    "CONSOLE": "Console",
    "SPREADSHEET": "Spreadsheet",
    "FILE_BROWSER": "File Browser",
    "INFO": "Info",
}

_REGION_TYPE_LABELS = {
    "HEADER": "Header",
    "FOOTER": "Footer",
    "UI": "Sidebar",
    "TOOLS": "Toolbar",
    "TOOL_PROPS": "Tool Shelf",
    "CHANNELS": "Channels",
    "PREVIEW": "Preview",
    "NAVIGATION_BAR": "Navigation Bar",
}


_ENUM_ITEM_CACHE = {
    "editor_signature": None,
    "editor_items": [],
    "mode_signature": None,
    "mode_items": [],
    "preset_signature": None,
    "preset_items": [],
}

_PRESET_ENUM_ID_TO_NAME: dict[str, str] = {"NONE": ""}
_PRESET_ENUM_NAME_TO_ID: dict[str, str] = {}


def _current_language() -> str:
    try:
        return bpy.context.preferences.view.language or ""
    except Exception:
        return ""


def _safe_enum_identifier(prefix: str, text: str) -> str:
    # Blender enum identifiers are safest when they stay ASCII and stable.
    # The visible dropdown text is kept separately, so Japanese preset names
    # remain readable while the internal enum value cannot become mojibake.
    import hashlib
    raw = str(text)
    slug = re.sub(r"[^A-Za-z0-9_]+", "_", raw).strip("_")
    if not slug:
        slug = "item"
    slug = slug[:40]
    digest = hashlib.sha1(raw.encode("utf-8", "surrogatepass")).hexdigest()[:10]
    return f"{prefix}_{slug}_{digest}"


def _invalidate_preset_enum_cache() -> None:
    _ENUM_ITEM_CACHE["preset_signature"] = None
    _ENUM_ITEM_CACHE["preset_items"] = []


def _preset_identifier_for_name(name: str) -> str:
    if not name:
        return "NONE"
    identifier = _PRESET_ENUM_NAME_TO_ID.get(name)
    if identifier:
        return identifier
    _preset_items(None, None)
    return _PRESET_ENUM_NAME_TO_ID.get(name, _safe_enum_identifier("PRESET", name))


def _preset_name_from_identifier(identifier: str) -> str:
    if not identifier or identifier == "NONE":
        return ""
    name = _PRESET_ENUM_ID_TO_NAME.get(identifier)
    if name is not None:
        return name
    _preset_items(None, None)
    return _PRESET_ENUM_ID_TO_NAME.get(identifier, "")


def _safe_keyconfigs_for_items(context=None):
    try:
        wm = (context or bpy.context).window_manager
        keyconfig = wm.keyconfigs.user if wm.keyconfigs.user else wm.keyconfigs.active
        return keyconfig.keymaps if keyconfig else []
    except Exception:
        return []


def _space_label(space_type: str) -> str:
    return _tr(_SPACE_TYPE_LABELS.get(space_type, space_type.replace("_", " ").title()))


def _visual_editor_filter_items(_self, context):
    values = ["ALL"]
    seen = {"ALL"}
    for keymap in _safe_keyconfigs_for_items(context):
        space_type = keymap.space_type or "EMPTY"
        if space_type not in seen:
            seen.add(space_type)
            values.append(space_type)

    signature = (_current_language(), tuple(values))
    if _ENUM_ITEM_CACHE.get("editor_signature") == signature:
        return _ENUM_ITEM_CACHE["editor_items"]

    items = []
    for value in values:
        items.append((str(value), str(_space_label(value)), ""))
    _ENUM_ITEM_CACHE["editor_signature"] = signature
    _ENUM_ITEM_CACHE["editor_items"] = items
    return _ENUM_ITEM_CACHE["editor_items"]


_VISUAL_MODE_HINTS = (
    "Object Mode", "Mesh", "Curve", "Surface", "Metaball", "Text", "Armature", "Pose",
    "Sculpt", "Vertex Paint", "Weight Paint", "Texture Paint", "Grease Pencil", "Curves",
    "3D View", "Global",
)


def _visual_mode_filter_items(_self, context):
    values = ["ALL"]
    seen = {"ALL"}
    keymaps = list(_safe_keyconfigs_for_items(context))
    for hint in _VISUAL_MODE_HINTS:
        for keymap in keymaps:
            if hint in keymap.name and hint not in seen:
                seen.add(hint)
                values.append(hint)
                break
    for keymap in keymaps:
        name = keymap.name
        if name and name not in seen and len(values) < 96:
            seen.add(name)
            values.append(name)

    signature = (_current_language(), tuple(values))
    if _ENUM_ITEM_CACHE.get("mode_signature") == signature:
        return _ENUM_ITEM_CACHE["mode_items"]

    items = []
    for value in values:
        display_name = _tr("All Modes") if value == "ALL" else _friendly_keymap_name(value)
        items.append((str(value), str(display_name), ""))
    _ENUM_ITEM_CACHE["mode_signature"] = signature
    _ENUM_ITEM_CACHE["mode_items"] = items
    return _ENUM_ITEM_CACHE["mode_items"]


def _keymap_manager_user_config_dir(dirname: str) -> str:
    path = os.path.join(bpy.utils.user_resource("CONFIG"), dirname)
    os.makedirs(path, exist_ok=True)
    return path


def _preset_items(_self, _context):
    names = _list_keymap_presets()
    signature = (_current_language(), tuple(names))
    if _ENUM_ITEM_CACHE.get("preset_signature") == signature:
        return _ENUM_ITEM_CACHE["preset_items"]

    _PRESET_ENUM_ID_TO_NAME.clear()
    _PRESET_ENUM_ID_TO_NAME["NONE"] = ""
    _PRESET_ENUM_NAME_TO_ID.clear()

    items = [("NONE", str(_tr("No Preset")), "")]
    for name in names:
        identifier = _safe_enum_identifier("PRESET", name)
        _PRESET_ENUM_ID_TO_NAME[identifier] = name
        _PRESET_ENUM_NAME_TO_ID[name] = identifier
        items.append((identifier, str(name), str(name)))

    _ENUM_ITEM_CACHE["preset_signature"] = signature
    _ENUM_ITEM_CACHE["preset_items"] = items
    return _ENUM_ITEM_CACHE["preset_items"]


class KMM_State(PropertyGroup):
    selected_type: EnumProperty(
        name="Key",
        description="Blender event type used as the base key. Choose from this list or click a key in the keyboard layout below.",
        items=_selected_type_items,
        default=_enum_item_number(_EVENT_TYPE_ITEMS, "A"),
        translation_context=_LITERAL_CONTEXT,
    )
    selected_value: EnumProperty(
        name="Input State",
        description="Input state to match when Exact Value is enabled. Press is the normal state for keyboard shortcuts; Release and Any are also used by some keymaps.",
        items=_selected_value_items,
        default=_enum_item_number(_KMI_VALUE_ITEMS, "PRESS"),
        translation_context=_LITERAL_CONTEXT,
    )
    selected_ctrl: BoolProperty(
        name="Ctrl",
        description="When Exact Modifiers is enabled, list shortcuts that require Ctrl. Keymap items marked Any still match either state.",
        default=False,
    )
    selected_shift: BoolProperty(
        name="Shift",
        description="When Exact Modifiers is enabled, list shortcuts that require Shift. Keymap items marked Any still match either state.",
        default=False,
    )
    selected_alt: BoolProperty(
        name="Alt",
        description="When Exact Modifiers is enabled, list shortcuts that require Alt. Keymap items marked Any still match either state.",
        default=False,
    )
    selected_oskey: BoolProperty(
        name="OS Key",
        description="When Exact Modifiers is enabled, list shortcuts that require the operating-system key. On Windows this is commonly the Windows key.",
        default=False,
    )
    selected_hyper: BoolProperty(
        name="Hyper",
        description="When Exact Modifiers is enabled, list shortcuts that require Hyper. Most standard Windows keyboards do not expose a dedicated Hyper key.",
        default=False,
    )
    selected_key_modifier: EnumProperty(
        name="Key Modifier",
        description="Optional secondary key modifier. When Exact Modifiers is enabled, shortcuts with a different key modifier are hidden.",
        items=_selected_key_modifier_items,
        default=_enum_item_number(_KEY_MODIFIER_ITEMS, "NONE"),
        translation_context=_LITERAL_CONTEXT,
    )
    use_exact_modifiers: BoolProperty(
        name="Exact Modifiers",
        description="When enabled, only keymap items with the selected Ctrl, Shift, Alt, OS Key, Hyper, and key-modifier states are shown. When disabled, all modifier variants of the selected physical key are shown.",
        default=True,
    )
    use_exact_value: BoolProperty(
        name="Exact Value",
        description="When enabled, only keymap items with the selected input state are shown. When disabled, Press, Release, Click, Drag, Any, and other value variants for the selected key are all shown.",
        default=False,
    )
    include_disabled: BoolProperty(
        name="Include Disabled",
        description="Show disabled keymap items as well as enabled ones. Disabled items are marked because they cannot run until their Active checkbox is enabled.",
        default=True,
    )
    operator_id_query: StringProperty(
        name="Operator ID",
        description="Enter an operator identifier such as wm.save_mainfile. When this field is not empty, the keyboard layout highlights keys assigned to that operator, and the registered item list shows those assignments together with keymaps that use the same shortcut event.",
        default="",
    )
    view_mode: StringProperty(default="NORMAL")
    section_keyboard_open: BoolProperty(default=True)
    section_mouse_open: BoolProperty(default=False)
    section_ndof_open: BoolProperty(default=False)
    section_key_filter_open: BoolProperty(default=True)
    section_io_open: BoolProperty(default=False)
    section_registered_open: BoolProperty(default=True)
    unused_parent_key: StringProperty(default="")
    unused_child_key: StringProperty(default="")
    expanded_unused_parent_keys: StringProperty(default="")
    expanded_unused_base_keys: StringProperty(default="")
    expanded_item_keys: StringProperty(default="")
    consolidation_preview_rows: CollectionProperty(type=KMM_ConsolidationPreviewRow)
    consolidation_preview_index: IntProperty(default=0)

    visual_editor_filter: EnumProperty(
        name="Editor Filter",
        description="Narrow the visual overview to the keymaps of the selected editor.",
        items=_visual_editor_filter_items,
        translation_context=_LITERAL_CONTEXT,
    )
    visual_mode_filter: EnumProperty(
        name="Mode Filter",
        description="Filter by keymap mode name, such as Object Mode, Mesh, Pose, or Sculpt.",
        items=_visual_mode_filter_items,
        translation_context=_LITERAL_CONTEXT,
    )
    visual_search_text: StringProperty(
        name="Search Filter",
        description="Filter visible bindings by operator ID, operator label, keymap location, or shortcut text.",
        default="",
    )
    export_path: StringProperty(
        name="Export Path",
        description="Export the current user keymap to a JELararagi keymap JSON file stored in the user configuration directory or the selected path.",
        subtype="FILE_PATH",
        default="",
    )
    import_path: StringProperty(
        name="Import Path",
        description="Import a JELararagi keymap JSON file and append the stored bindings to the user keymap. Existing bindings are not removed automatically.",
        subtype="FILE_PATH",
        default="",
    )
    export_scope: EnumProperty(
        name="Export Scope",
        description="Choose whether to export all user keymap items or only items that appear changed from the default keymap.",
        items=[
            ("MODIFIED", "Modified Only", "Export only keymap items that differ from Blender's default keymap."),
            ("ALL", "All Keymaps", "Export every user keymap item."),
        ],
        default="MODIFIED",
    )
    preset_name: StringProperty(
        name="Preset Name",
        description="Name used when saving the current keymap as a preset in Blender's user configuration directory.",
        default="",
    )
    preset_select: EnumProperty(
        name="Preset",
        description="Select a saved keymap preset to load or delete.",
        items=_preset_items,
        translation_context=_LITERAL_CONTEXT,
    )
    expanded_visual_key_groups: StringProperty(default="")


@dataclass
class _Match:
    keyconfig_name: str
    keymap: bpy.types.KeyMap
    item: bpy.types.KeyMapItem
    index: int
    priority_score: int
    hierarchy_path: str
    hierarchy_order: int
    status: str = "No duplicate detected"
    blocker: Optional["_Match"] = None
    higher_blockers: list = field(default_factory=list)
    note: str = "No enabled item with the same event signature was found above this item in the scanned keymaps."


def _item_key(match: _Match) -> str:
    keymap = match.keymap
    return "|".join([
        match.keyconfig_name,
        keymap.name,
        keymap.space_type,
        keymap.region_type,
        "1" if keymap.is_modal else "0",
        str(match.item.id),
    ])


def _expanded_keys(state: KMM_State) -> set[str]:
    return {item for item in state.expanded_item_keys.split("\n") if item}


def _expanded_unused_parent_keys(state: KMM_State) -> set[str]:
    return {item for item in state.expanded_unused_parent_keys.split("\n") if item}


def _set_expanded_unused_parent_keys(state: KMM_State, values: set[str]) -> None:
    state.expanded_unused_parent_keys = "\n".join(sorted(values))


def _expanded_unused_base_keys(state: KMM_State) -> set[str]:
    return {item for item in state.expanded_unused_base_keys.split("\n") if item}



def _expanded_visual_key_groups(state: KMM_State) -> set[str]:
    return {item for item in state.expanded_visual_key_groups.split("\n") if item}


def _keyconfig_by_name(context, keyconfig_name: str):
    for keyconfig in context.window_manager.keyconfigs:
        if keyconfig.name == keyconfig_name:
            return keyconfig
    return None


def _keymap_matches_ref(keymap, keymap_name: str, space_type: str, region_type: str, is_modal: bool) -> bool:
    return (
        keymap.name == keymap_name and
        keymap.space_type == space_type and
        keymap.region_type == region_type and
        keymap.is_modal == is_modal
    )


def _find_keymap(context, keyconfig_name: str, keymap_name: str, space_type: str, region_type: str, is_modal: bool):
    keyconfig = _keyconfig_by_name(context, keyconfig_name)
    if keyconfig is None:
        return None
    for keymap in keyconfig.keymaps:
        if _keymap_matches_ref(keymap, keymap_name, space_type, region_type, is_modal):
            return keymap
    return None


def _find_keymap_item(context, keyconfig_name: str, keymap_name: str, space_type: str, region_type: str, is_modal: bool, kmi_id: int):
    keymap = _find_keymap(context, keyconfig_name, keymap_name, space_type, region_type, is_modal)
    if keymap is None:
        return None, None
    for item in keymap.keymap_items:
        if item.id == kmi_id:
            return keymap, item
    return keymap, None


def _keyconfig_total_items(keyconfig) -> int:
    if not keyconfig:
        return 0
    return sum(len(keymap.keymap_items) for keymap in keyconfig.keymaps)


def _editable_keymaps(context) -> list[tuple[str, bpy.types.KeyMap]]:
    wm = context.window_manager
    keymaps: list[tuple[str, bpy.types.KeyMap]] = []
    used: set[tuple[str, str, str, str, bool]] = set()

    # The user keyconfig is the editable effective keymap in Blender's Preferences editor.
    primary = wm.keyconfigs.user if _keyconfig_total_items(wm.keyconfigs.user) > 16 else wm.keyconfigs.active
    if primary:
        for keymap in primary.keymaps:
            active_keymap = keymap.active() if hasattr(keymap, "active") else keymap
            ident = (primary.name, active_keymap.name, active_keymap.space_type, active_keymap.region_type, active_keymap.is_modal)
            if ident not in used:
                used.add(ident)
                keymaps.append((primary.name, active_keymap))

    addon = wm.keyconfigs.addon
    if addon:
        for keymap in addon.keymaps:
            ident = (addon.name, keymap.name, keymap.space_type, keymap.region_type, keymap.is_modal)
            if ident not in used and len(keymap.keymap_items):
                used.add(ident)
                keymaps.append((addon.name, keymap))

    return keymaps


def _hierarchy_tree() -> tuple:
    global _HIERARCHY_TREE_CACHE
    if _HIERARCHY_TREE_CACHE is not None:
        return _HIERARCHY_TREE_CACHE
    try:
        from bl_keymap_utils import keymap_hierarchy
        hierarchy = tuple(keymap_hierarchy.generate())
    except Exception:
        hierarchy = tuple()
    _HIERARCHY_TREE_CACHE = hierarchy
    return _HIERARCHY_TREE_CACHE


def _hierarchy_scores() -> tuple[dict[tuple[str, str, str], int], dict[tuple[str, str, str], str], dict[tuple[str, str, str], int]]:
    global _HIERARCHY_CACHE
    if _HIERARCHY_CACHE is not None:
        return _HIERARCHY_CACHE

    scores: dict[tuple[str, str, str], int] = {}
    paths: dict[tuple[str, str, str], str] = {}
    orders: dict[tuple[str, str, str], int] = {}

    hierarchy = _hierarchy_tree()

    order_counter = 0

    def visit(entries, depth: int, path: tuple[str, ...]):
        nonlocal order_counter
        for name, space_type, region_type, children in entries:
            key = (name, space_type, region_type)
            new_path = (*path, name)
            if key not in orders:
                orders[key] = order_counter
                order_counter += 1
            if depth > scores.get(key, -1):
                scores[key] = depth
                paths[key] = " > ".join(new_path)
            visit(children, depth + 1, new_path)

    visit(hierarchy, 0, tuple())
    _HIERARCHY_CACHE = (scores, paths, orders)
    return _HIERARCHY_CACHE


def _keymap_priority_score(keymap, hierarchy_scores: dict[tuple[str, str, str], int]) -> int:
    key = (keymap.name, keymap.space_type, keymap.region_type)
    depth = hierarchy_scores.get(key, 0)
    specificity = 0
    if keymap.space_type != "EMPTY":
        specificity += 2
    if keymap.region_type != "WINDOW":
        specificity += 1
    return depth * 10 + specificity


def _keymap_path(keymap, hierarchy_paths: dict[tuple[str, str, str], str]) -> str:
    return hierarchy_paths.get((keymap.name, keymap.space_type, keymap.region_type), keymap.name)


def _bool_modifier_matches(kmi_value: int, selected: bool) -> bool:
    value = int(kmi_value)
    if value == -1:
        return True
    return bool(value) == bool(selected)


def _matches_selected(item, state: KMM_State) -> bool:
    if item.type != state.selected_type:
        return False
    if not state.include_disabled and not item.active:
        return False
    if state.use_exact_value and item.value not in {state.selected_value, "ANY"}:
        return False
    if state.use_exact_modifiers and not getattr(item, "any", False):
        if not _bool_modifier_matches(item.ctrl, state.selected_ctrl):
            return False
        if not _bool_modifier_matches(item.shift, state.selected_shift):
            return False
        if not _bool_modifier_matches(item.alt, state.selected_alt):
            return False
        if not _bool_modifier_matches(item.oskey, state.selected_oskey):
            return False
        if hasattr(item, "hyper") and not _bool_modifier_matches(item.hyper, state.selected_hyper):
            return False
        if item.key_modifier != state.selected_key_modifier:
            return False
    return True


def _items_compare(a, b) -> bool:
    try:
        return bool(a.compare(b))
    except Exception:
        return False


def _event_signature(item) -> tuple:
    hyper = int(item.hyper) if hasattr(item, "hyper") else 0
    return (
        item.type,
        item.value,
        item.key_modifier,
        bool(item.any),
        int(item.ctrl),
        int(item.shift),
        int(item.alt),
        int(item.oskey),
        hyper,
        item.direction if item.value == "CLICK_DRAG" else "ANY",
    )


def _same_event_signature(a, b) -> bool:
    return _event_signature(a) == _event_signature(b)


def _hierarchy_path_tuple(match: _Match) -> tuple[str, ...]:
    return tuple(part.strip() for part in match.hierarchy_path.split(" > ") if part.strip())


# どの画面でも最後に受け取るキーマップ。ほかのキーマップが先に受け取ると隠れる
_GLOBAL_KEYMAP_NAMES = {"Window", "Screen"}


def _can_shadow(other: "_Match", match: "_Match", other_path: tuple[str, ...], match_path: tuple[str, ...]) -> bool:
    # 同時に働くキーマップどうしの時だけ、先に受け取る側が隠す。
    # 別のエディターやモードのキーマップは、同じ場面で競合しない。
    if other.priority_score <= match.priority_score:
        return False
    if match.keymap.name in _GLOBAL_KEYMAP_NAMES:
        return True
    return len(other_path) > len(match_path) and other_path[:len(match_path)] == match_path


def _operator_query(state: KMM_State) -> str:
    return state.operator_id_query.strip()


def _operator_id_text(item) -> str:
    return item.idname if getattr(item, "idname", "") else str(getattr(item, "propvalue", ""))


def _keymap_location_key(match: _Match) -> tuple:
    keymap = match.keymap
    return (
        match.keyconfig_name,
        keymap.name,
        keymap.space_type,
        keymap.region_type,
        bool(keymap.is_modal),
    )


def _keymap_ref_key(match: _Match) -> str:
    return "|".join(str(part) for part in _keymap_location_key(match))


def _keymap_location_label(match: _Match) -> str:
    return f"{match.keyconfig_name} / {_context_label(match)}"


def _consolidation_group_key(match: _Match) -> Optional[tuple]:
    operator_id = _operator_id_text(match.item).strip().lower()
    if not operator_id:
        return None
    # 向きや設定が違う項目は別の割り当てなので、同じ組にしない
    return (
        *_keymap_location_key(match),
        operator_id,
        _event_signature(match.item),
        bool(match.item.active),
        json.dumps(_kmi_properties_dict(match.item), sort_keys=True),
    )


def _clear_consolidation_report(state: KMM_State) -> None:
    state.consolidation_preview_rows.clear()
    state.consolidation_preview_index = 0


def _set_consolidation_preview_ref(row: KMM_ConsolidationPreviewRow, match: _Match) -> None:
    row.keyconfig_name = match.keyconfig_name
    row.keymap_name = match.keymap.name
    row.space_type = match.keymap.space_type
    row.region_type = match.keymap.region_type
    row.is_modal = bool(match.keymap.is_modal)
    row.kmi_id = int(match.item.id)


def _collect_consolidation_duplicate_groups(context) -> list[list[_Match]]:
    all_items = _build_all_matches(context)
    grouped: dict[tuple, list[_Match]] = {}
    for match in all_items:
        key = _consolidation_group_key(match)
        if key is None:
            continue
        grouped.setdefault(key, []).append(match)

    groups: list[list[_Match]] = []
    for rows in grouped.values():
        if len(rows) <= 1:
            continue
        rows.sort(key=lambda match: match.index)
        groups.append(rows)

    groups.sort(key=lambda rows: (
        _keymap_location_label(rows[0]),
        _operator_id_text(rows[0].item).strip().lower(),
        _format_kmi_event(rows[0].item),
    ))
    return groups


def _user_items_at_consolidation_rows(context, rows) -> dict:
    """アドオン側の行を消す場所ごとに、ユーザー側の割り当てを控える。"""
    user_config = context.window_manager.keyconfigs.user
    snapshot: dict[tuple, dict[str, dict]] = {}
    for row in rows:
        location = (row.keymap_name, row.space_type, row.region_type)
        if location in snapshot:
            continue
        keymap = user_config.keymaps.find(row.keymap_name, space_type=row.space_type, region_type=row.region_type) if user_config else None
        if keymap is None:
            continue
        items = (_serialized_item_dict(item) for item in keymap.keymap_items)
        snapshot[location] = {json.dumps(data, sort_keys=True): data for data in items}
    return snapshot


def _restore_user_items(context, snapshot: dict) -> None:
    """控えにあって、今は同じ内容の行が 1 つも無い割り当てを戻す。"""
    user_config = context.window_manager.keyconfigs.user
    for (keymap_name, space_type, region_type), saved_items in snapshot.items():
        keymap = user_config.keymaps.find(keymap_name, space_type=space_type, region_type=region_type)
        if keymap is None:
            continue
        current = {json.dumps(_serialized_item_dict(item), sort_keys=True) for item in keymap.keymap_items}
        for key, data in saved_items.items():
            if key not in current:
                added, complete = _apply_serialized_item(keymap, data)
                if not (added and complete):
                    continue
            _restore_addon_active(context, keymap, data)


def _preview_row_icon(row_type: str) -> str:
    if row_type == "GROUP":
        return "DISCLOSURE_TRI_RIGHT"
    if row_type == "KEEP":
        return "CHECKMARK"
    return "X"


def _populate_consolidation_preview_rows(state: KMM_State, groups: list[list[_Match]]) -> None:
    state.consolidation_preview_rows.clear()
    state.consolidation_preview_index = 0
    for group_index, rows in enumerate(groups, start=1):
        header_match = rows[0]
        header = state.consolidation_preview_rows.add()
        header.row_type = "GROUP"
        header.group_index = group_index
        _set_consolidation_preview_ref(header, header_match)
        header.text = (
            f"{_tr('Group')} {group_index}: {_keymap_location_label(header_match)} | "
            f"{_tr('Operator ID')}: {_operator_id_text(header_match.item)} | "
            f"{_tr('Shortcut')}: {_format_kmi_event(header_match.item)}"
        )
        header.detail = f"{len(rows) - 1} {_tr('Remove')}"

        keep = state.consolidation_preview_rows.add()
        keep.row_type = "KEEP"
        keep.group_index = group_index
        _set_consolidation_preview_ref(keep, rows[0])
        keep.text = f"    {_tr_ctx('Keep')}: {_operator_label(rows[0].item, rows[0].keymap)}"
        keep.detail = _format_kmi_event(rows[0].item)

        for remove_match in rows[1:]:
            remove = state.consolidation_preview_rows.add()
            remove.row_type = "REMOVE"
            remove.group_index = group_index
            _set_consolidation_preview_ref(remove, remove_match)
            remove.text = f"    {_tr('Remove')}: {_operator_label(remove_match.item, remove_match.keymap)}"
            remove.detail = _format_kmi_event(remove_match.item)


def _consolidation_preview_visible_rows(context, state: KMM_State) -> int:
    total = len(state.consolidation_preview_rows)
    if total <= 0:
        return 6
    window_height = getattr(getattr(context, "window", None), "height", 0)
    if window_height:
        # Keep the dialog below the window height. Header text, buttons, and margins
        # need reserved space, so the scroll list itself is capped conservatively.
        height_limited = max(6, min(18, int((window_height - 300) / 24)))
    else:
        height_limited = 14
    return min(max(6, total), height_limited)


def _draw_consolidation_preview(layout, context, state: KMM_State) -> None:
    group_count = sum(1 for row in state.consolidation_preview_rows if row.row_type == "GROUP")
    remove_count = sum(1 for row in state.consolidation_preview_rows if row.row_type == "REMOVE")
    layout.label(text=_tr("The following duplicate keymap items will be removed. Choose Consolidate to keep only the first item in each duplicate group, or Cancel to make no changes."), translate=False)
    layout.label(text=_tr("Duplicate groups found: {groups}, items to remove: {count}").format(groups=group_count, count=remove_count), translate=False)
    rows = _consolidation_preview_visible_rows(context, state)
    layout.template_list(
        "KMM_UL_consolidation_preview",
        "",
        state,
        "consolidation_preview_rows",
        state,
        "consolidation_preview_index",
        rows=rows,
        maxrows=18,
    )


def _build_all_matches(context) -> list[_Match]:
    hierarchy_scores, hierarchy_paths, hierarchy_orders = _hierarchy_scores()
    all_items: list[_Match] = []

    for keyconfig_name, keymap in _editable_keymaps(context):
        score = _keymap_priority_score(keymap, hierarchy_scores)
        path = _keymap_path(keymap, hierarchy_paths)
        order = hierarchy_orders.get((keymap.name, keymap.space_type, keymap.region_type), 1000000 + len(all_items))
        for index, item in enumerate(keymap.keymap_items):
            all_items.append(_Match(keyconfig_name, keymap, item, index, score, path, order))

    return all_items


def _apply_conflict_status(matches: list[_Match], all_items: list[_Match]) -> None:
    same_location: dict[tuple, list[_Match]] = {}
    same_type: dict[str, list[_Match]] = {}
    for other in all_items:
        same_location.setdefault(_keymap_location_key(other), []).append(other)
        if not other.keymap.is_modal and other.item.active:
            same_type.setdefault(other.item.type, []).append(other)

    for match in matches:
        match.status = "No duplicate detected"
        match.blocker = None
        match.higher_blockers = []
        match.note = "No enabled item with the same event signature was found above this item in the scanned keymaps."

        item = match.item
        if not item.active:
            match.status = "Disabled"
            match.note = "This item is disabled and will not run until it is enabled."
            continue

        same_keymap_blocker = None
        for other in same_location.get(_keymap_location_key(match), ()):
            if other.index >= match.index:
                break
            if other.item.active and _items_compare(other.item, item):
                same_keymap_blocker = other
                break
        if same_keymap_blocker is not None:
            match.status = "Blocked by previous item"
            match.blocker = same_keymap_blocker
            match.note = "A previous item in the same keymap uses the same event signature. The previous item is tried first; if it cannot run in the current situation, this item runs."
            continue

        # モーダルのキーマップはその機能の実行中だけ働くので、ほかのキーマップとは競合しない
        if match.keymap.is_modal:
            continue

        higher_priority_blocker = None
        same_priority_duplicate = None
        match_path = _hierarchy_path_tuple(match)
        for other in same_type.get(item.type, ()):
            if other.item == item:
                continue
            if not _items_compare(other.item, item):
                continue
            other_path = _hierarchy_path_tuple(other)
            if _can_shadow(other, match, other_path, match_path):
                match.higher_blockers.append(other)
                if higher_priority_blocker is None or other.priority_score > higher_priority_blocker.priority_score:
                    higher_priority_blocker = other
            elif other.priority_score == match.priority_score and other.keymap != match.keymap and other_path == match_path:
                # アドオンの割り当てと、そのユーザー側の写しは同じ物なので重複に数えない
                if other.keyconfig_name != match.keyconfig_name and _operator_id_text(other.item) == _operator_id_text(match.item):
                    continue
                same_priority_duplicate = same_priority_duplicate or other

        if higher_priority_blocker is not None:
            match.status = "Overlapped by higher priority"
            match.blocker = higher_priority_blocker
            match.note = "A more specific keymap context uses the same event signature. The actual result depends on the active editor, mode, modal operator, and region."
        elif same_priority_duplicate is not None:
            match.status = "Same priority duplicate"
            match.blocker = same_priority_duplicate
            match.note = "Another item with the same estimated priority uses the same event signature. Check the context before assuming either item will run."


def _find_operator_assignments(all_items: list[_Match], operator_id: str) -> list[_Match]:
    query = operator_id.strip().lower()
    if not query:
        return []
    exact = [match for match in all_items if _operator_id_text(match.item).strip().lower() == query]
    if exact:
        exact.sort(key=_match_sort_key)
        return exact
    if len(query) < 3:
        return []
    partial = [match for match in all_items if query in _operator_id_text(match.item).strip().lower()]
    partial.sort(key=_match_sort_key)
    return partial


def _collect_matches_from_entries(
    all_items: list[_Match],
    state: KMM_State,
    operator_assignments: Optional[list[_Match]] = None,
) -> list[_Match]:
    if state.view_mode == "CONFLICTS":
        grouped: dict[tuple, list[_Match]] = {}
        for match in all_items:
            if not state.include_disabled and not match.item.active:
                continue
            grouped.setdefault((_keymap_location_key(match), _event_signature(match.item)), []).append(match)
        matches = []
        for rows in grouped.values():
            if len(rows) > 1:
                rows.sort(key=lambda match: match.index)
                matches.extend(rows)
        _apply_conflict_status(matches, all_items)
        matches.sort(key=lambda match: (match.hierarchy_order, _keymap_location_label(match), _format_kmi_event(match.item), match.index))
        return matches

    if state.view_mode in {"UNUSED", "VISUAL"}:
        return []

    operator_id = _operator_query(state)
    if operator_id:
        assignments = operator_assignments
        if assignments is None:
            assignments = _find_operator_assignments(all_items, operator_id)
        matches = []
        added: set[str] = set()
        for assignment in assignments:
            for match in all_items:
                if not state.include_disabled and not match.item.active:
                    continue
                # Include exact event-signature matches and Blender's own keymap comparison result.
                # This catches shortcuts with "Any" modifier states as well as literal duplicates.
                if (
                    _same_event_signature(match.item, assignment.item)
                    or _items_compare(match.item, assignment.item)
                    or _items_compare(assignment.item, match.item)
                ):
                    key = _item_key(match)
                    if key not in added:
                        added.add(key)
                        matches.append(match)
    else:
        matches = [match for match in all_items if _matches_selected(match.item, state)]
    _apply_conflict_status(matches, all_items)
    matches.sort(key=_match_sort_key)
    return matches


def _invalidate_view_cache() -> None:
    _VIEW_CACHE["dirty"] = True
    _VIEW_CACHE["all_signature"] = None
    _VIEW_CACHE["state_signature"] = None
    _VIEW_CACHE["visible_signature"] = None
    _VIEW_CACHE["all_items"] = []
    _VIEW_CACHE["matches"] = []
    _VIEW_CACHE["operator_assignments"] = []
    _VIEW_CACHE["last_structure_check"] = 0.0
    _VIEW_CACHE["last_visible_check"] = 0.0
    _VIEW_CACHE["visual_key"] = None
    _VIEW_CACHE["visual_matches"] = []


def _keyconfig_light_signature(context) -> tuple:
    parts = []
    for keyconfig_name, keymap in _editable_keymaps(context):
        parts.append((
            keyconfig_name,
            keymap.name,
            keymap.space_type,
            keymap.region_type,
            bool(keymap.is_modal),
            keymap.as_pointer(),
            tuple(item.as_pointer() for item in keymap.keymap_items),
        ))
    return tuple(parts)


def _state_filter_signature(state: KMM_State) -> tuple:
    return (
        state.view_mode,
        state.selected_type,
        state.selected_value,
        bool(state.selected_ctrl),
        bool(state.selected_shift),
        bool(state.selected_alt),
        bool(state.selected_oskey),
        bool(state.selected_hyper),
        state.selected_key_modifier,
        bool(state.use_exact_modifiers),
        bool(state.use_exact_value),
        bool(state.include_disabled),
        _operator_query(state).lower(),
        state.unused_parent_key,
        state.unused_child_key,
    )


def _visible_items_signature(matches: list[_Match]) -> tuple:
    signature = []
    for match in matches:
        item = match.item
        signature.append((
            _item_key(match),
            bool(item.active),
            _operator_id_text(item),
            item.type,
            item.value,
            item.key_modifier,
            bool(item.any),
            int(item.ctrl),
            int(item.shift),
            int(item.alt),
            int(item.oskey),
            int(getattr(item, "hyper", 0)),
        ))
    return tuple(signature)


def _get_cached_keymap_view(context, state: KMM_State) -> tuple[list[_Match], list[_Match], list[_Match]]:
    state_signature = _state_filter_signature(state)
    now = time.monotonic()

    need_rebuild = bool(_VIEW_CACHE.get("dirty")) or not _VIEW_CACHE.get("all_items")
    if not need_rebuild:
        keyconfig_signature = _keyconfig_light_signature(context)
        _VIEW_CACHE["last_structure_check"] = now
        need_rebuild = _VIEW_CACHE.get("all_signature") != keyconfig_signature
    else:
        keyconfig_signature = _keyconfig_light_signature(context)

    if need_rebuild:
        all_items = _build_all_matches(context)
        _VIEW_CACHE["all_items"] = all_items
        _VIEW_CACHE["visual_key"] = None
        _VIEW_CACHE["visual_matches"] = []
        _VIEW_CACHE["all_signature"] = keyconfig_signature
        _VIEW_CACHE["state_signature"] = None
        _VIEW_CACHE["visible_signature"] = None
        _VIEW_CACHE["dirty"] = False
        _VIEW_CACHE["last_structure_check"] = now

    if _VIEW_CACHE.get("state_signature") != state_signature:
        all_items = _VIEW_CACHE["all_items"]
        operator_assignments = _find_operator_assignments(all_items, _operator_query(state)) if state.view_mode == "NORMAL" else []
        matches = _collect_matches_from_entries(all_items, state, operator_assignments)
        _VIEW_CACHE["operator_assignments"] = operator_assignments
        _VIEW_CACHE["matches"] = matches
        _VIEW_CACHE["state_signature"] = state_signature
        _VIEW_CACHE["visible_signature"] = _visible_items_signature(matches)
        _VIEW_CACHE["last_visible_check"] = now
    elif now - float(_VIEW_CACHE.get("last_visible_check", 0.0)) >= _VIEW_CACHE_VISIBLE_INTERVAL:
        current_visible_signature = _visible_items_signature(_VIEW_CACHE["matches"])
        _VIEW_CACHE["last_visible_check"] = now
        if _VIEW_CACHE.get("visible_signature") != current_visible_signature:
            all_items = _VIEW_CACHE["all_items"]
            operator_assignments = _find_operator_assignments(all_items, _operator_query(state)) if state.view_mode == "NORMAL" else []
            matches = _collect_matches_from_entries(all_items, state, operator_assignments)
            _VIEW_CACHE["operator_assignments"] = operator_assignments
            _VIEW_CACHE["matches"] = matches
            _VIEW_CACHE["visible_signature"] = _visible_items_signature(matches)

    return (
        _VIEW_CACHE["all_items"],
        _VIEW_CACHE["operator_assignments"],
        _VIEW_CACHE["matches"],
    )


def _assigned_key_summary(assignments: list[_Match]) -> str:
    if not assignments:
        return _tr("No assigned key found for this operator ID.")
    values = []
    seen = set()
    for match in assignments:
        text = _format_kmi_event(match.item)
        if text not in seen:
            seen.add(text)
            values.append(text)
    return ", ".join(values)


def _match_sort_key(match: _Match):
    return (match.hierarchy_order, match.keymap.name, match.index)

def _enum_display_name(rna_type, prop_name: str, identifier: str) -> str:
    try:
        prop = rna_type.bl_rna.properties[prop_name]
        item = prop.enum_items.get(identifier)
        if item and item.name.strip():
            return _rna_text(item.name, prop.translation_context)
    except Exception:
        pass
    if identifier == "NONE":
        return _tr("None")
    return identifier


def _modifier_value_text(value: int) -> str:
    value = int(value)
    if value == -1:
        return _tr_ctx("Any")
    if value == 1:
        return _tr_ctx("On")
    return _tr_ctx("Off")


def _modifier_compact_text(name: str, value: int) -> str:
    return f"{name}: {_modifier_value_text(value)}"


def _format_event_from_values(event_type: str, value: str, ctrl: bool, shift: bool, alt: bool, oskey: bool, hyper: bool, key_modifier: str) -> str:
    parts = []
    if ctrl:
        parts.append("Ctrl")
    if shift:
        parts.append("Shift")
    if alt:
        parts.append("Alt")
    if oskey:
        parts.append(_tr("OS Key"))
    if hyper:
        parts.append("Hyper")
    if key_modifier != "NONE":
        parts.append(_enum_display_name(bpy.types.KeyMapItem, "key_modifier", key_modifier))
    parts.append(_enum_display_name(bpy.types.Event, "type", event_type))
    if value:
        parts.append(_enum_display_name(bpy.types.KeyMapItem, "value", value))
    return " + ".join(part for part in parts if part)


def _format_kmi_event(item) -> str:
    parts = []
    if int(item.ctrl) == 1:
        parts.append("Ctrl")
    elif int(item.ctrl) == -1:
        parts.append("Ctrl:*")
    if int(item.shift) == 1:
        parts.append("Shift")
    elif int(item.shift) == -1:
        parts.append("Shift:*")
    if int(item.alt) == 1:
        parts.append("Alt")
    elif int(item.alt) == -1:
        parts.append("Alt:*")
    if int(item.oskey) == 1:
        parts.append(_tr("OS Key"))
    elif int(item.oskey) == -1:
        parts.append(_tr("OS Key") + ":*")
    if hasattr(item, "hyper"):
        if int(item.hyper) == 1:
            parts.append("Hyper")
        elif int(item.hyper) == -1:
            parts.append("Hyper:*")
    if item.key_modifier != "NONE":
        parts.append(_enum_display_name(bpy.types.KeyMapItem, "key_modifier", item.key_modifier))
    parts.append(_enum_display_name(bpy.types.KeyMapItem, "type", item.type))
    parts.append(_enum_display_name(bpy.types.KeyMapItem, "value", item.value))
    if item.value == "CLICK_DRAG" and item.direction != "ANY":
        parts.append(_enum_display_name(bpy.types.KeyMapItem, "direction", item.direction))
    return " + ".join(part for part in parts if part)


def _format_selected_event(state: KMM_State) -> str:
    return _format_event_from_values(
        state.selected_type,
        state.selected_value,
        state.selected_ctrl,
        state.selected_shift,
        state.selected_alt,
        state.selected_oskey,
        state.selected_hyper,
        state.selected_key_modifier,
    )


_OPERATOR_ENGLISH_NAMES: dict[str, str] = {}


def _operator_english_name(idname: str) -> str:
    name = _OPERATOR_ENGLISH_NAMES.get(idname)
    if name is None:
        try:
            module, operator = idname.split(".", 1)
            name = getattr(getattr(bpy.ops, module), operator).get_rna_type().name or idname
        except Exception:
            name = idname
        _OPERATOR_ENGLISH_NAMES[idname] = name
    return name


def _operator_display_name(item) -> str:
    # KeyMapItem.name は本体の訳になるので、日本語以外では英語の名前を引く
    if not item.idname:
        return ""
    if _is_japanese_ui():
        return item.name if item.name else item.idname
    return _operator_english_name(item.idname)


def _modal_value_name(keymap, value: str) -> str:
    try:
        for entry in keymap.modal_event_values:
            if entry.identifier == value:
                if _is_japanese_ui() and entry.name in _JA_MODAL_VALUES:
                    return _JA_MODAL_VALUES[entry.name]
                return _rna_text(entry.name) or value
    except Exception:
        pass
    return value


def _operator_label(item, keymap) -> str:
    if item.idname:
        return f"{_operator_display_name(item)} ({item.idname})"
    propvalue = getattr(item, "propvalue", "")
    if propvalue:
        return f"{_tr('Modal Value')}: {_modal_value_name(keymap, propvalue)}"
    return _tr("Modal Value")


def _context_label(match: _Match) -> str:
    keymap = match.keymap
    pieces = [_friendly_keymap_name(keymap.name)]
    if keymap.space_type != "EMPTY":
        space = _space_label(keymap.space_type)
        if space not in pieces:
            pieces.append(space)
    if keymap.region_type != "WINDOW":
        region = keymap.region_type
        pieces.append(_tr(_REGION_TYPE_LABELS.get(region, region.replace("_", " ").title())))
    if keymap.is_modal:
        pieces.append(_tr("Modal"))
    return " / ".join(pieces)


def _friendly_path(path: str) -> str:
    return " > ".join(_friendly_keymap_name(part.strip()) for part in path.split(" > ") if part.strip())


def _operator_name(item, keymap) -> str:
    if item.idname:
        return _operator_display_name(item)
    propvalue = getattr(item, "propvalue", "")
    if propvalue:
        return _modal_value_name(keymap, propvalue)
    return _tr("Modal Value")


def _condition_label(match: _Match) -> str:
    return _tr("Available when the active keymap context matches: {context}").format(context=_context_label(match))


def _duplicate_label(match: _Match) -> str:
    if not match.item.active:
        return _tr("Disabled")
    if match.status == "No duplicate detected":
        return _tr("Effective")
    if match.status == "Blocked by previous item":
        return _tr_ctx("Earlier Item First")
    if match.status == "Overlapped by higher priority":
        return _tr("Partly Shadowed")
    if match.status == "Same priority duplicate":
        return _tr_ctx("Duplicate")
    return _tr(match.status)


def _duplicate_icon(match: _Match) -> str:
    if not match.item.active:
        return "CANCEL"
    if match.status == "No duplicate detected":
        return "CHECKMARK"
    if match.status == "Blocked by previous item":
        return "SORT_DESC"
    if match.status == "Overlapped by higher priority":
        return "TRIA_DOWN_BAR"
    if match.status == "Same priority duplicate":
        return "ERROR"
    return "NONE"


def _operator_mode_active(state: KMM_State) -> bool:
    return bool(_operator_query(state))


def _is_operator_assignment(match: _Match, state: KMM_State) -> bool:
    return bool(_operator_query(state) and _operator_id_text(match.item).strip().lower() == _operator_query(state).lower())


def _role_status_label(match: _Match, state: KMM_State) -> str:
    if not _operator_mode_active(state):
        return _duplicate_label(match)
    role = _tr("Assigned Operator") if _is_operator_assignment(match, state) else _tr("Conflicting Operator")
    return f"{role} / {_duplicate_label(match)}"


def _role_status_icon(match: _Match, state: KMM_State) -> str:
    if _operator_mode_active(state) and _is_operator_assignment(match, state):
        return "KEYTYPE_KEYFRAME_VEC"
    return _duplicate_icon(match)


def _clear_label(text: str) -> str:
    return text.replace("\n", " ").strip()


def _parent_child_label(match: _Match) -> str:
    parent = _friendly_path(match.hierarchy_path) if match.hierarchy_path else _context_label(match)
    return f"{parent} → {_clear_label(_operator_name(match.item, match.keymap))}"


def _hierarchy_display_path(match: _Match) -> str:
    path = match.hierarchy_path or _context_label(match)
    parts = [part.strip() for part in path.replace(" / ", " > ").split(" > ") if part.strip()]
    if not parts:
        return _context_label(match)
    return " → ".join(_bracket_label(part) for part in parts)


def _conflict_location_label(match: _Match) -> str:
    return _hierarchy_display_path(match)


def _conflict_group_key(match: _Match) -> tuple:
    return (_keymap_location_key(match), _event_signature(match.item))


def _conflict_group_label(match: _Match) -> str:
    return f"{_conflict_location_label(match)} | {_tr('Shortcut')}: {_format_kmi_event(match.item)}"


def _conflict_closed_label(match: _Match) -> str:
    return (
        f"{_conflict_location_label(match)} | "
        f"{_tr('Shortcut')}: {_format_kmi_event(match.item)} | "
        f"{_tr('Operator')}: {_clear_label(_operator_label(match.item, match.keymap))} | "
        f"{_tr_ctx('Status')}: {_duplicate_label(match)}"
    )


def _closed_item_label(match: _Match, state: KMM_State) -> str:
    if state.view_mode == "CONFLICTS":
        return _conflict_closed_label(match)
    return _parent_child_label(match)


def _status_list_label(match: _Match) -> str:
    return _duplicate_label(match)


def _mode_line(match: _Match) -> str:
    return f"[{_status_list_label(match)}] {_parent_child_label(match)}"


def _related_mode_groups(match: _Match, matches: list[_Match]) -> tuple[list[_Match], list[_Match], list[_Match]]:
    related = [other for other in matches if _same_event_signature(other.item, match.item) or _items_compare(other.item, match.item) or _items_compare(match.item, other.item)]
    if not related:
        related = [match]
    related.sort(key=_match_sort_key)
    enabled: list[_Match] = []
    conflicted: list[_Match] = []
    manually_disabled: list[_Match] = []
    for other in related:
        if not other.item.active:
            manually_disabled.append(other)
        elif other.status == "No duplicate detected":
            enabled.append(other)
        else:
            conflicted.append(other)
    return enabled, conflicted, manually_disabled


def _distinct_blockers(blockers: list[_Match]) -> list[_Match]:
    # アドオンの割り当てとユーザー側の写しは同じ物なので、1 件にまとめる
    distinct: dict[tuple, _Match] = {}
    for blocker in blockers:
        keymap = blocker.keymap
        distinct.setdefault((keymap.name, keymap.space_type, keymap.region_type, _operator_id_text(blocker.item).strip().lower()), blocker)
    return list(distinct.values())


def _draw_match_list(layout, empty_text: str, rows: list[_Match], include_blocker: bool = False) -> None:
    if not rows:
        layout.label(text="• " + _tr(empty_text), translate=False)
        return
    for other in rows:
        layout.label(text="• " + _mode_line(other), translate=False)
        if include_blocker and other.blocker:
            for blocker in _distinct_blockers(other.higher_blockers or [other.blocker]):
                layout.label(text="  " + _tr("Priority Source") + ": " + _parent_child_label(blocker), translate=False)


def _draw_mode_groups(layout, match: _Match, matches: list[_Match]) -> None:
    enabled, conflicted, manually_disabled = _related_mode_groups(match, matches)

    enabled_box = layout.box()
    enabled_box.label(text=_tr("Enabled Modes"), icon="CHECKMARK", translate=False)
    _draw_match_list(enabled_box, "No enabled mode found", enabled)

    conflict_box = layout.box()
    conflict_box.label(text=_tr("Conflict Disabled Modes"), icon="ERROR", translate=False)
    _draw_match_list(conflict_box, "No conflict-disabled mode found", conflicted, include_blocker=True)

    disabled_box = layout.box()
    disabled_box.label(text=_tr("Manually Disabled Modes"), icon="CANCEL", translate=False)
    _draw_match_list(disabled_box, "No manually disabled mode found", manually_disabled)


def _label_no_translate(layout, text: str, **kwargs):
    try:
        return layout.label(text=text, translate=False, **kwargs)
    except TypeError:
        return layout.label(text=text, **kwargs)


def _operator_no_translate(layout, operator_id: str, text: str = "", **kwargs):
    try:
        return layout.operator(operator_id, text=text, translate=False, **kwargs)
    except TypeError:
        return layout.operator(operator_id, text=text, **kwargs)


def _draw_modifier_button(layout, match: _Match, modifier: str, label: str):
    value = getattr(match.item, modifier)
    op = _operator_no_translate(layout, KMM_OT_cycle_modifier.bl_idname, text=_modifier_compact_text(label, value))
    op.keyconfig_name = match.keyconfig_name
    op.keymap_name = match.keymap.name
    op.space_type = match.keymap.space_type
    op.region_type = match.keymap.region_type
    op.is_modal = match.keymap.is_modal
    op.kmi_id = match.item.id
    op.modifier = modifier


def _uses_native_enum_widgets() -> bool:
    # 日本語と英語では本体の欄のままでよい。ほかの言語は本体の欄だと本体の訳が出る
    locale = bpy.app.translations.locale
    return (
        _is_japanese_ui()
        or not locale
        or locale.startswith("en")
        or not bpy.context.preferences.view.use_translate_interface
    )


def _draw_item_enum(layout, match: _Match, prop_name: str, label: str) -> None:
    item = match.item
    if _uses_native_enum_widgets() and not (prop_name == "propvalue" and _is_japanese_ui()):
        layout.prop(item, prop_name, text=label, translate=False)
        return
    value = getattr(item, prop_name)
    if prop_name == "propvalue":
        display = _modal_value_name(match.keymap, value)
    else:
        display = _enum_display_name(bpy.types.KeyMapItem, prop_name, value)
    op = _operator_no_translate(layout, KMM_OT_choose_item_value.bl_idname, text=f"{label}: {display}")
    op.keyconfig_name = match.keyconfig_name
    op.keymap_name = match.keymap.name
    op.space_type = match.keymap.space_type
    op.region_type = match.keymap.region_type
    op.is_modal = match.keymap.is_modal
    op.kmi_id = item.id
    op.prop_name = prop_name


def _open_close_panel(layout, group: str, key: str, opened: set[str]):
    # 標準の開閉。opened に入っている物を開いた状態で出す（開閉の状態は Blender がパネルごとに持つ）
    is_open = key in opened
    return layout.panel(f"kmm_{group}_{key}_{'open' if is_open else 'closed'}", default_closed=not is_open)


def _draw_keymap_item(layout, state: KMM_State, match: _Match, matches: list[_Match]):
    item = match.item
    box = layout.box()
    header, body = _open_close_panel(box, "item", _item_key(match), _expanded_keys(state))
    split = header.split(factor=0.82, align=True)
    left = split.row(align=True)
    left.label(text=_closed_item_label(match, state), icon="EVENT_K", translate=False)
    right = split.row(align=True)
    right.alignment = "RIGHT"
    right.label(text=_role_status_label(match, state), icon=_role_status_icon(match, state), translate=False)

    if body is None:
        return

    detail = body.column(align=True)
    detail.label(text=f"{_tr('Operator')}: {_operator_label(item, match.keymap)}", translate=False)
    id_row = detail.row(align=True)
    try:
        if item.idname:
            id_row.prop(item, "idname", text=_tr("Operator ID"), translate=False)
        else:
            _draw_item_enum(id_row, match, "propvalue", _tr("Modal Value"))
    except Exception:
        id_row.label(text=f"{_tr('Operator ID')}: {_operator_name(item, match.keymap)}", translate=False)
    if item.idname:
        copy_op = id_row.operator(KMM_OT_copy_operator_id.bl_idname, text=item.idname, icon="COPYDOWN", translate=False)
        copy_op.operator_id = item.idname
    detail.label(text=f"{_tr('When active')}: {_condition_label(match)}", translate=False)
    detail.label(text=f"{_tr('Priority')}: {match.priority_score} / {_tr('Priority order')}: {_friendly_path(match.hierarchy_path)}", translate=False)
    detail.label(text=f"{_tr('Event Signature')}: {_format_kmi_event(item)}", translate=False)
    detail.label(text=f"{_tr_ctx('Context')}: {_context_label(match)}", translate=False)

    if match.status == "Overlapped by higher priority" and match.blocker:
        fix_box = detail.box()
        for blocker in _distinct_blockers(match.higher_blockers):
            fix_box.label(text=f"{_tr('Higher-priority source')}: {_parent_child_label(blocker)}", icon="TRIA_DOWN_BAR", translate=False)
        for event_text in dict.fromkeys(_format_kmi_event(blocker.item) for blocker in match.higher_blockers):
            fix_box.label(text=f"{_tr('Event Signature')}: {event_text}", translate=False)
        fix_op = fix_box.operator(
            KMM_OT_activate_shadowed_keymap.bl_idname,
            text=_tr("Enable Target and Disable Higher Priority"),
            icon="CHECKMARK",
            translate=False,
        )
        fix_op.target_keyconfig_name = match.keyconfig_name
        fix_op.target_keymap_name = match.keymap.name
        fix_op.target_space_type = match.keymap.space_type
        fix_op.target_region_type = match.keymap.region_type
        fix_op.target_is_modal = match.keymap.is_modal
        fix_op.target_kmi_id = match.item.id

    edit = detail.row(align=True)
    edit.prop(item, "active", text=_tr("Enabled"), translate=False)
    _draw_item_enum(edit, match, "type", _tr("Key"))
    edit = detail.row(align=True)
    _draw_item_enum(edit, match, "value", _tr("Input State"))
    _draw_item_enum(edit, match, "key_modifier", "Key Modifier")

    modifiers = detail.row(align=True)
    modifiers.prop(item, "any", text=_tr("Any Modifiers"), translate=False)
    _draw_modifier_button(modifiers, match, "ctrl", "Ctrl")
    _draw_modifier_button(modifiers, match, "shift", "Shift")
    _draw_modifier_button(modifiers, match, "alt", "Alt")
    _draw_modifier_button(modifiers, match, "oskey", _tr("OS Key"))
    if hasattr(item, "hyper"):
        _draw_modifier_button(modifiers, match, "hyper", "Hyper")

    _draw_mode_groups(detail, match, matches)


class KMM_UL_consolidation_preview(UIList):
    bl_idname = "KMM_UL_consolidation_preview"

    def draw_item(self, _context, layout, _data, item, _icon, _active_data, _active_propname, _index):
        row = layout.row(align=True)
        split = row.split(factor=0.70, align=True)
        split.label(text=item.text, icon=_preview_row_icon(item.row_type), translate=False)
        split.label(text=item.detail, translate=False)


_HELP_TOPICS = {
    "overview": ("Keymap Manager", "キーマップマネージャー", (
        ("Look up shortcuts from a keyboard picture, find keys used twice, and fix them.",
         "キーボードの絵からショートカットを調べ、同じキーの重なりを見つけて直せます。"),
        ("1. Press a key and modifiers in Keyboard Layout. The assignments appear in Registered Keymap Items.",
         "1. 「キーボード配列」でキーと修飾キーを押します。割り当てが「登録済みキーマップ項目」に並びます。"),
        ("2. Check the status on the right of each row, and open a row with its triangle to see details.",
         "2. 各行の右の状況を見て、左の三角で詳細を開きます。"),
        ("3. Change values in the details. They rewrite Blender's keymap right away.",
         "3. 詳細で値を直します。変えるとその場で Blender のキーマップが書き換わります。"),
        ("Each part of this panel has its own ? button.",
         "パネルの各部分の見出しにも ? があります。"),
    )),
    "keyboard": ("Keyboard Layout", "キーボード配列", (
        ("Press a key to list the assignments of that key below. The picture has a US layout.",
         "キーを押すと、そのキーの割り当てが下に並びます。絵は英語（US）配列の形です。"),
        ("Ctrl, Shift, Alt and OS turn on and off each time you press them, so you can look up S and Ctrl+S separately.",
         "Ctrl・Shift・Alt・OS は押すたびに入・切が変わるので、S と Ctrl+S を分けて調べられます。"),
        ("Assignments whose modifier is Any are listed in both states.",
         "修飾キーが「任意」の割り当ては、入・切のどちらでも出ます。"),
        ("Gray keys cannot be used as shortcuts in Blender. They only complete the keyboard shape.",
         "灰色のキーは Blender のショートカットに使えません。形を合わせるための表示です。"),
        ("With an Operator ID, or in the visual overview, keys with matching assignments look pressed.",
         "オペレーターIDを入れている時と可視化の表示の間は、割り当てのあるキーが押された見た目になります。"),
        ("All keys are gray while the unused keymap view is showing.",
         "未使用キーマップの表示の間は、全部のキーが灰色になります。"),
    )),
    "mouse": ("Mouse Operations", "マウス操作", (
        ("Select mouse buttons, the wheel, and pointer or trackpad actions the same way as keys.",
         "マウスのボタン、ホイール、ポインターやトラックパッドの操作を、キーと同じように選んで調べます。"),
        ("The assignments appear in Registered Keymap Items, with the modifier keys you turned on.",
         "割り当ては「登録済みキーマップ項目」に並びます。入れている修飾キーも条件になります。"),
    )),
    "ndof": ("3D Mouse / NDOF", "3Dマウス/NDOF", (
        ("Select the buttons of a 3D mouse (NDOF, an input device for turning a view by hand) to list their assignments.",
         "3D マウス（NDOF。視点を手で動かす専用の入力機器）のボタンを選び、割り当てを調べます。"),
        ("Short names: R is roll, S is spin, T is tilt, CW is clockwise, CCW is counterclockwise.",
         "英語設定の短い名前は、R がロール、S がスピン、T がチルト、CW が右回り、CCW が左回りです。"),
    )),
    "key_filter": ("Key", "キー", (
        ("Choose the key and how to narrow the list. The heading shows the current key.",
         "調べるキーと一覧の絞り方を選びます。見出しに今のキーが出ます。"),
        ("Operator ID: enter an internal name such as wm.save_mainfile to show its keys on the keyboard, together with other assignments that use the same keys. Clear it to go back.",
         "オペレーターID：wm.save_mainfile のような内部名を入れると、その機能のキーを絵で示し、同じキーの割り当ても並べます。空にすると戻ります。"),
        ("Exact Value: when on, only assignments with the selected Input State are listed. Pressing a key on the keyboard turns it off.",
         "入力状態を一致：入れると選んだ入力状態の割り当てだけを出します。絵のキーを押すと切に戻ります。"),
        ("Show Visual Overview: groups assigned keys by base key (the key without modifiers). Open a group to see its assignments.",
         "キーマップ可視化を表示：割り当て済みのキーを基準キー（修飾キーを除いたキー）ごとにまとめます。三角で中を見ます。"),
        ("Show Conflicting Keymaps: lists assignments that share a shortcut inside the same registration location.",
         "競合キーマップを表示：同じ登録場所で同じキーを使う割り当てだけを並べます。"),
        ("Show Unused Keymaps: open a parent category, then a subcategory, to see free shortcuts. They are grouped by base key.",
         "未使用キーマップを表示：親カテゴリー、サブカテゴリーの順に開くと、空いているキーの候補が基準キーごとに出ます。"),
        ("Consolidate Duplicate Keymaps: finds items with the same place, operator, shortcut (including drag direction), on/off state and operator settings. Scroll through the confirmation before you accept; the first of each group stays and the rest are deleted.",
         "重複キーマップを集約：場所・機能・キー（ドラッグの向きを含む）・オンオフ・オペレーターの設定がすべて同じ項目を探します。確認画面をスクロールして見てから実行します。各グループの先頭だけ残し、他を削除します。"),
        ("If you edited only some user copies of an add-on's duplicates, the edited rows and the untouched assignment both stay.",
         "アドオンの重複の写しを一部だけ編集してあった時は、編集した行も、編集していない割り当ても残ります。"),
        ("Visualization Filters narrow the visual overview by editor, mode and text.",
         "可視化フィルターは、可視化の一覧をエディター・モード・文字で絞ります。"),
    )),
    "io": ("Keymap Import / Export / Presets", "キーマップ入出力 / プリセット", (
        ("Export writes a JSON file. With an empty path it goes to keymap_manager_exports in Blender's user configuration folder.",
         "エクスポートは JSON ファイルに書き出します。空なら Blender のユーザー設定フォルダーの keymap_manager_exports に保存します。"),
        ("Modified Only writes assignments that differ from Blender's defaults. All Keymaps writes everything.",
         "「変更済みのみ」は初期設定と違う割り当てだけ、「全キーマップ」は全部を書き出します。"),
        ("Import and Load Preset only add assignments; nothing is replaced. When the same data is loaded twice, Blender merges identical assignments; Consolidate Duplicate Keymaps cleans up any that remain.",
         "インポートとプリセットの読み込みは足すだけで置き換えません。同じデータを 2 回読むと、まったく同じ割り当ては Blender がまとめます。残った物は「重複キーマップを集約」で整理します。"),
        ("The file keeps modal assignments, drag directions and operator settings. If some could not be read, the finish message gives the count.",
         "ファイルにはモーダルの割り当て、ドラッグの向き、オペレーターの設定も入ります。読み込めない物があれば、完了の文に件数が出ます。"),
        ("Save Preset writes the whole keymap under that name and overwrites the same name.",
         "プリセットの保存は今のキーマップ全部をその名前で保存し、同じ名前は上書きします。"),
        ("Delete Preset removes the file without asking.",
         "プリセットの削除は確認なしでファイルを消します。"),
    )),
    "registered": ("Registered Keymap Items", "登録済みキーマップ項目", (
        ("Each row shows the place and the function on the left, and the status on the right. The triangle opens the details.",
         "各行は左に登録場所と機能、右に状況が出ます。三角で詳細を開きます。"),
        ("A shortcut added by an add-on appears on two rows: the add-on's item and its user copy. They are one assignment, so they are not counted as Duplicate.",
         "アドオンが足したキーは、アドオン側の項目とユーザー側の写しの 2 行で出ます。同じ割り当てなので「重複」には数えません。"),
        ("Effective: nothing found that receives this shortcut first.",
         "有効：このキーを先に受け取る割り当ては見つかりません。"),
        ("Partly Shadowed: another assignment receives this shortcut first in the screens or modes where both work. Everywhere else this one still works.",
         "一部で上位優先：両方が働く画面やモードでは、別の割り当てが先に受け取ります。それ以外の場面では動きます。"),
        ("Assignments in unrelated editors or modes are not counted, because they never work at the same time.",
         "別々のエディターやモードの割り当ては、同時に働かないので数えません。"),
        ("Modal keymaps (such as Bevel Modal Map) work only while their tool runs, so they do not conflict with normal shortcuts.",
         "モーダルのキーマップ（ベベルモーダルマップなど）は、その機能の実行中だけ働くので、ふつうのキーとは競合しません。"),
        ("Earlier Item First: an earlier item in the same keymap uses the same shortcut and is tried first. If it cannot run in that situation, this one runs. Duplicate: an item with the same priority does. Disabled: it is turned off.",
         "先行項目が優先：同じ場所の前の項目が同じキーを使っていて、先に試されます。その場面で前の項目が実行できなければ、この項目が動きます。重複：優先度が同じ項目が同じキーを使っています。無効：オフです。"),
        ("Enable Target and Disable Higher Priority turns off every assignment shown as a Higher-priority source and turns this one on. The sources then stop working in their own screens or modes too. Turn a source back on in its details to undo it.",
         "「このキーマップを有効化し上位優先を無効化」は、並んでいる上位優先元をすべてオフにして、この項目をオンにします。上位優先元は、それが働く画面やモードでも動かなくなります。戻すには上位優先元の詳細で「有効」を入れます。"),
        ("Modifier buttons cycle Off, On, Any. Changes in the details rewrite Blender's keymap right away.",
         "修飾キーのボタンは押すたびにオフ→オン→任意と変わります。詳細の変更はその場でキーマップに反映されます。"),
    )),
}


def _draw_help_popup(layout, topic: str) -> None:
    data = _HELP_TOPICS.get(topic) or _HELP_TOPICS["overview"]
    japanese = _is_japanese_ui()
    column = layout.column(align=True)
    for english, ja_text in data[2]:
        column.label(text=ja_text if japanese else english, translate=False)


class KMM_OT_show_help(Operator):
    bl_idname = "keymap_manager.show_help"
    bl_label = "Keymap Manager Help"
    bl_description = "Show help for this section."
    bl_options = {"INTERNAL"}

    topic: StringProperty(default="overview", options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Show help for this section.")

    def execute(self, context):
        topic = self.topic

        def draw(menu, _popup_context):
            _draw_help_popup(menu.layout, topic)

        data = _HELP_TOPICS.get(topic) or _HELP_TOPICS["overview"]
        context.window_manager.popup_menu(draw, title=data[1] if _is_japanese_ui() else data[0], icon="QUESTION")
        return {"FINISHED"}


def _choose_item_value_items(self, context):
    if self.prop_name == "type":
        return _KMI_TYPE_ITEMS
    if self.prop_name == "value":
        return _KMI_VALUE_ITEMS
    if self.prop_name == "key_modifier":
        return _KEY_MODIFIER_ITEMS
    cache_key = ("propvalue", self.keymap_name, _is_japanese_ui())
    items = _LOCALIZED_ENUM_CACHE.get(cache_key)
    if items is None:
        keymap = _find_keymap(context, self.keyconfig_name, self.keymap_name, self.space_type, self.region_type, self.is_modal)
        items = [(entry.identifier, _modal_value_name(keymap, entry.identifier), "") for entry in keymap.modal_event_values] if keymap else []
        _LOCALIZED_ENUM_CACHE[cache_key] = items
    return items


class KMM_OT_choose_item_value(Operator):
    bl_idname = "keymap_manager.choose_item_value"
    bl_label = "Choose Value"
    bl_description = "Choose a value for this keymap item."
    bl_options = {"INTERNAL", "UNDO"}
    bl_property = "choice"

    keyconfig_name: StringProperty(default="", options={"HIDDEN"})
    keymap_name: StringProperty(default="", options={"HIDDEN"})
    space_type: StringProperty(default="EMPTY", options={"HIDDEN"})
    region_type: StringProperty(default="WINDOW", options={"HIDDEN"})
    is_modal: BoolProperty(default=False, options={"HIDDEN"})
    kmi_id: IntProperty(default=-1, options={"HIDDEN"})
    prop_name: StringProperty(default="value", options={"HIDDEN"})
    choice: EnumProperty(name="Value", items=_choose_item_value_items, translation_context=_LITERAL_CONTEXT)

    def invoke(self, context, _event):
        context.window_manager.invoke_search_popup(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        _keymap, item = _find_keymap_item(
            context,
            self.keyconfig_name,
            self.keymap_name,
            self.space_type,
            self.region_type,
            self.is_modal,
            self.kmi_id,
        )
        if item is None or self.prop_name not in {"type", "value", "key_modifier", "propvalue"}:
            self.report({"ERROR"}, _tr("Keymap item was not found."))
            return {"CANCELLED"}
        setattr(item, self.prop_name, self.choice)
        _invalidate_view_cache()
        for area in context.screen.areas if context.screen else []:
            area.tag_redraw()
        return {"FINISHED"}


class KMM_OT_select_key(Operator):
    bl_idname = "keymap_manager.select_key"
    bl_label = "Select Key"
    bl_description = "Select this key in the keyboard layout and list matching keymap items. Use the modifier filters above to narrow the list to modifier combinations."
    bl_options = {"INTERNAL", "UNDO"}

    event_type: StringProperty(default="")
    label: StringProperty(default="")
    is_mouse_operation: BoolProperty(default=False)

    @classmethod
    def description(cls, _context, properties):
        if not properties.event_type:
            return _tr("This physical key is shown for the keyboard layout only. Blender 5.1 does not expose it as a keymap event, so no shortcut list can be queried from it.")
        if getattr(properties, "is_mouse_operation", False):
            return _tr("Select this mouse operation and list matching keymap items. It uses the same registered keymap list and editing controls as the keyboard layout.")
        return _tr("Select this key in the keyboard layout and list matching keymap items. Use the modifier filters above to narrow the list to modifier combinations.")

    def execute(self, context):
        if self.event_type not in _available_event_identifiers():
            self.report({"INFO"}, _tr("Unsupported by Blender"))
            return {"CANCELLED"}
        state = context.window_manager.keymap_manager_state
        state.operator_id_query = ""
        state.view_mode = "NORMAL"
        _clear_consolidation_report(state)
        _invalidate_view_cache()
        state.selected_type = self.event_type
        state.selected_value = "PRESS"
        state.use_exact_modifiers = True
        state.use_exact_value = False
        return {"FINISHED"}


class KMM_OT_refresh(Operator):
    bl_idname = "keymap_manager.refresh"
    bl_label = "Refresh"
    bl_description = "Re-read the current Blender keyconfig and update the visible keymap list. Use this after changing shortcuts from another Preferences panel."
    bl_options = {"INTERNAL", "UNDO"}

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Re-read the current Blender keyconfig and update the visible keymap list. Use this after changing shortcuts from another Preferences panel.")

    def execute(self, context):
        _invalidate_view_cache()
        for area in context.screen.areas if context.screen else []:
            area.tag_redraw()
        return {"FINISHED"}


class KMM_OT_toggle_conflict_view(Operator):
    bl_idname = "keymap_manager.toggle_conflict_view"
    bl_label = "Show Conflicting Keymaps"
    bl_description = "Show all keymap items that use the same shortcut inside the same registration location."
    bl_options = {"INTERNAL", "UNDO"}

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Show all keymap items that use the same shortcut inside the same registration location.")

    def execute(self, context):
        state = context.window_manager.keymap_manager_state
        state.view_mode = "NORMAL" if state.view_mode == "CONFLICTS" else "CONFLICTS"
        if state.view_mode == "CONFLICTS":
            state.operator_id_query = ""
            state.unused_parent_key = ""
            state.unused_child_key = ""
            state.expanded_unused_parent_keys = ""
            state.expanded_unused_base_keys = ""
        _clear_consolidation_report(state)
        _invalidate_view_cache()
        return {"FINISHED"}


class KMM_OT_toggle_unused_view(Operator):
    bl_idname = "keymap_manager.toggle_unused_view"
    bl_label = "Show Unused Keymaps"
    bl_description = "Show parent categories and list shortcut candidates that are not used in the selected registration category."
    bl_options = {"INTERNAL", "UNDO"}

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Show parent categories and list shortcut candidates that are not used in the selected registration category.")

    def execute(self, context):
        state = context.window_manager.keymap_manager_state
        if state.view_mode == "UNUSED":
            state.view_mode = "NORMAL"
        else:
            state.view_mode = "UNUSED"
            state.operator_id_query = ""
            state.unused_parent_key = ""
            state.unused_child_key = ""
            state.expanded_unused_parent_keys = ""
            state.expanded_unused_base_keys = ""
        _clear_consolidation_report(state)
        _invalidate_view_cache()
        return {"FINISHED"}


class KMM_OT_select_unused_parent(Operator):
    bl_idname = "keymap_manager.select_unused_parent"
    bl_label = "Select Category"
    bl_options = {"INTERNAL", "UNDO"}

    parent_key: StringProperty(default="")

    def execute(self, context):
        state = context.window_manager.keymap_manager_state
        state.unused_parent_key = self.parent_key
        state.unused_child_key = ""
        state.expanded_unused_base_keys = ""
        values = _expanded_unused_parent_keys(state)
        values.add(self.parent_key)
        _set_expanded_unused_parent_keys(state, values)
        state.view_mode = "UNUSED"
        return {"FINISHED"}


class KMM_OT_select_unused_child(Operator):
    bl_idname = "keymap_manager.select_unused_child"
    bl_label = "Select Subcategory"
    bl_options = {"INTERNAL", "UNDO"}

    parent_key: StringProperty(default="")
    child_key: StringProperty(default="")

    def execute(self, context):
        state = context.window_manager.keymap_manager_state
        if self.parent_key:
            state.unused_parent_key = self.parent_key
        state.unused_child_key = self.child_key
        state.expanded_unused_base_keys = ""
        state.view_mode = "UNUSED"
        return {"FINISHED"}


class KMM_OT_unused_back(Operator):
    bl_idname = "keymap_manager.unused_back"
    bl_label = "Back"
    bl_translation_context = "KeymapManager"
    bl_options = {"INTERNAL", "UNDO"}

    def execute(self, context):
        state = context.window_manager.keymap_manager_state
        if state.unused_child_key:
            state.unused_child_key = ""
            state.expanded_unused_base_keys = ""
        elif state.unused_parent_key:
            state.unused_parent_key = ""
        else:
            state.view_mode = "NORMAL"
        return {"FINISHED"}


class KMM_OT_consolidate_duplicate_keymaps(Operator):
    bl_idname = "keymap_manager.consolidate_duplicate_keymaps"
    bl_label = "Consolidate Duplicate Keymaps"
    bl_description = "Preview duplicate keymap items when the same keymap location has the same operator ID, shortcut key and settings, then consolidate them after confirmation. The first item is kept and the others are removed."
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Preview duplicate keymap items when the same keymap location has the same operator ID, shortcut key and settings, then consolidate them after confirmation. The first item is kept and the others are removed.")

    def invoke(self, context, _event):
        state = context.window_manager.keymap_manager_state
        _clear_consolidation_report(state)
        groups = _collect_consolidation_duplicate_groups(context)
        if not groups:
            self.report({"INFO"}, _tr("No duplicate keymap was found."))
            return {"CANCELLED"}
        _populate_consolidation_preview_rows(state, groups)
        try:
            return context.window_manager.invoke_props_dialog(
                self,
                width=980,
                title=_tr("Confirm Duplicate Keymap Consolidation"),
                confirm_text=_tr("Consolidate"),
            )
        except TypeError:
            return context.window_manager.invoke_props_dialog(self, width=980)

    def draw(self, context):
        state = context.window_manager.keymap_manager_state
        _draw_consolidation_preview(self.layout, context, state)

    def execute(self, context):
        state = context.window_manager.keymap_manager_state
        if not any(row.row_type == "REMOVE" for row in state.consolidation_preview_rows):
            groups = _collect_consolidation_duplicate_groups(context)
            if not groups:
                _clear_consolidation_report(state)
                self.report({"INFO"}, _tr("No duplicate keymap was found."))
                return {"CANCELLED"}
            _populate_consolidation_preview_rows(state, groups)

        # ユーザー側の項目のうちアドオンの写しは、アドオン側を消して更新すると一緒に減る。
        # 写しまで消すと更新の時に残した分の写しも消えて、キーが働かなくなる。
        # 写しの一部を編集してあると、Blender が編集を残った項目へ当て直して編集していない行が消えるので、
        # 集約の後で控えと比べて戻す。
        keyconfigs = context.window_manager.keyconfigs
        addon_name = keyconfigs.addon.name if keyconfigs.addon else ""
        removed_count = 0
        user_items = _user_items_at_consolidation_rows(
            context,
            [row for row in state.consolidation_preview_rows if row.row_type == "REMOVE" and row.keyconfig_name == addon_name],
        )
        for row in reversed(state.consolidation_preview_rows):
            if row.row_type != "REMOVE" or row.keyconfig_name != addon_name:
                continue
            keymap, item = _find_keymap_item(
                context,
                row.keyconfig_name,
                row.keymap_name,
                row.space_type,
                row.region_type,
                bool(row.is_modal),
                int(row.kmi_id),
            )
            if keymap is None or item is None:
                self.report({"WARNING"}, f"{_tr('Remove')}: {row.text} | {_tr('Keymap item was not found.')}")
                continue
            try:
                keymap.keymap_items.remove(item)
                removed_count += 1
            except Exception:
                self.report({"WARNING"}, f"{row.text.strip()} | {_tr('Keymap item could not be removed.')}")
        keyconfigs.update()

        for rows in _collect_consolidation_duplicate_groups(context):
            for match in reversed(rows[1:]):
                try:
                    match.keymap.keymap_items.remove(match.item)
                    removed_count += 1
                except Exception:
                    self.report({"WARNING"}, f"{_operator_label(match.item, match.keymap)} | {_tr('Keymap item could not be removed.')}")
        keyconfigs.update()

        _restore_user_items(context, user_items)
        keyconfigs.update()

        _clear_consolidation_report(state)
        _invalidate_view_cache()
        self.report({"INFO"}, _tr("Duplicate keymaps were consolidated: {count} removed.").format(count=removed_count))
        for area in context.screen.areas if context.screen else []:
            area.tag_redraw()
        return {"FINISHED"}

    def cancel(self, context):
        state = context.window_manager.keymap_manager_state
        _clear_consolidation_report(state)


class KMM_OT_activate_shadowed_keymap(Operator):
    bl_idname = "keymap_manager.activate_shadowed_keymap"
    bl_label = "Enable Target and Disable Higher Priority"
    bl_description = "Disable every higher-priority keymap item that currently receives this shortcut first, then enable this selected keymap item. Use this when the selected mode or context should take priority for the same shortcut."
    bl_options = {"UNDO", "INTERNAL"}

    target_keyconfig_name: StringProperty(default="")
    target_keymap_name: StringProperty(default="")
    target_space_type: StringProperty(default="EMPTY")
    target_region_type: StringProperty(default="WINDOW")
    target_is_modal: BoolProperty(default=False)
    target_kmi_id: IntProperty(default=-1)

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Disable every higher-priority keymap item that currently receives this shortcut first, then enable this selected keymap item. Use this when the selected mode or context should take priority for the same shortcut.")

    def execute(self, context):
        _target_keymap, target_item = _find_keymap_item(
            context,
            self.target_keyconfig_name,
            self.target_keymap_name,
            self.target_space_type,
            self.target_region_type,
            self.target_is_modal,
            self.target_kmi_id,
        )
        if target_item is None:
            self.report({"ERROR"}, _tr("Keymap item was not found."))
            return {"CANCELLED"}

        target_item.active = True
        all_items = _build_all_matches(context)
        target_match = next((match for match in all_items if match.item == target_item), None)
        blockers = []
        if target_match is not None:
            _apply_conflict_status([target_match], all_items)
            blockers = target_match.higher_blockers
        if blockers:
            for blocker in blockers:
                blocker.item.active = False
            message = _tr("Higher-priority keymaps were disabled ({count}) and this keymap was enabled.").format(count=len(_distinct_blockers(blockers)))
        else:
            message = _tr("Higher-priority keymap item was not found; this keymap was enabled only.")

        _invalidate_view_cache()
        self.report({"INFO"}, message)
        for area in context.screen.areas if context.screen else []:
            area.tag_redraw()
        return {"FINISHED"}



class KMM_OT_cycle_modifier(Operator):
    bl_idname = "keymap_manager.cycle_modifier"
    bl_label = "Cycle Modifier"
    bl_description = "Cycle this modifier between Off, On, and Any for the selected keymap item. Off means the modifier must not be pressed, On means it must be pressed, and Any means either state can match."
    bl_options = {"UNDO", "INTERNAL"}

    keyconfig_name: StringProperty(default="")
    keymap_name: StringProperty(default="")
    space_type: StringProperty(default="EMPTY")
    region_type: StringProperty(default="WINDOW")
    is_modal: BoolProperty(default=False)
    kmi_id: IntProperty(default=-1)
    modifier: StringProperty(default="ctrl")

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Cycle this modifier between Off, On, and Any for the selected keymap item. Off means the modifier must not be pressed, On means it must be pressed, and Any means either state can match.")

    def execute(self, context):
        _keymap, item = _find_keymap_item(
            context,
            self.keyconfig_name,
            self.keymap_name,
            self.space_type,
            self.region_type,
            self.is_modal,
            self.kmi_id,
        )
        if item is None or not hasattr(item, self.modifier):
            self.report({"ERROR"}, _tr("Keymap item was not found."))
            return {"CANCELLED"}

        current = int(getattr(item, self.modifier))
        next_value = 1 if current == 0 else (-1 if current == 1 else 0)
        setattr(item, self.modifier, next_value)
        _invalidate_view_cache()
        self.report({"INFO"}, _tr("Modifier changed: {modifier} = {state}").format(
            modifier=(_tr("OS Key") if self.modifier == "oskey" else self.modifier.capitalize()),
            state=_modifier_value_text(next_value),
        ))
        return {"FINISHED"}


class KMM_OT_copy_operator_id(Operator):
    bl_idname = "keymap_manager.copy_operator_id"
    bl_label = "Copy Operator ID"
    bl_description = "Copy the operator identifier to the clipboard so it can be pasted into scripts, documentation, or search fields."
    bl_options = {"INTERNAL", "UNDO"}

    operator_id: StringProperty(default="")

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Copy the operator identifier to the clipboard so it can be pasted into scripts, documentation, or search fields.")

    def execute(self, context):
        if not self.operator_id:
            self.report({"WARNING"}, _tr("Operator ID is not available for this keymap item."))
            return {"CANCELLED"}
        context.window_manager.clipboard = self.operator_id
        self.report({"INFO"}, _tr("Copied operator ID: {operator_id}").format(operator_id=self.operator_id))
        return {"FINISHED"}


class KMM_OT_toggle_filter_modifier(Operator):
    bl_idname = "keymap_manager.toggle_filter_modifier"
    bl_label = "Toggle Modifier Filter"
    bl_description = "Toggle this modifier key for the keyboard layout search. Turn it on before or after choosing a normal key to search shortcuts such as Ctrl+S separately from S."
    bl_options = {"INTERNAL", "UNDO"}

    modifier: StringProperty(default="ctrl")

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Toggle this modifier key for the keyboard layout search. Turn it on before or after choosing a normal key to search shortcuts such as Ctrl+S separately from S.")

    def execute(self, context):
        if self.modifier not in {"ctrl", "shift", "alt", "oskey"}:
            self.report({"INFO"}, _tr("Unknown modifier filter"))
            return {"CANCELLED"}
        state = context.window_manager.keymap_manager_state
        prop_name = "selected_" + self.modifier
        state.operator_id_query = ""
        state.view_mode = "NORMAL"
        _clear_consolidation_report(state)
        _invalidate_view_cache()
        setattr(state, prop_name, not bool(getattr(state, prop_name)))
        state.use_exact_modifiers = True
        return {"FINISHED"}


class KMM_OT_toggle_visual_view(Operator):
    bl_idname = "keymap_manager.toggle_visual_view"
    bl_label = "Show Visual Overview"
    bl_description = "Switch the list to an overview of assigned keys, grouped by base key (the key without modifiers). Press again to return to the normal list."
    bl_options = {"INTERNAL", "UNDO"}

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Switch the list to an overview of assigned keys, grouped by base key (the key without modifiers). Press again to return to the normal list.")

    def execute(self, context):
        state = context.window_manager.keymap_manager_state
        state.view_mode = "NORMAL" if state.view_mode == "VISUAL" else "VISUAL"
        state.operator_id_query = ""
        _clear_consolidation_report(state)
        _invalidate_view_cache()
        return {"FINISHED"}


class KMM_OT_clear_visual_filters(Operator):
    bl_idname = "keymap_manager.clear_visual_filters"
    bl_label = "Clear Visual Filters"
    bl_description = "Reset the visual overview editor, mode, and search filters."
    bl_options = {"INTERNAL", "UNDO"}

    def execute(self, context):
        state = context.window_manager.keymap_manager_state
        state.visual_editor_filter = "ALL"
        state.visual_mode_filter = "ALL"
        state.visual_search_text = ""
        state.expanded_visual_key_groups = ""
        _invalidate_view_cache()
        return {"FINISHED"}


class KMM_OT_export_keymap(Operator):
    bl_idname = "keymap_manager.export_keymap"
    bl_label = "Export Keymap"
    bl_description = "Export the current user keymap to a JELararagi keymap JSON file stored in the user configuration directory or the selected path."
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Export the current user keymap to a JELararagi keymap JSON file stored in the user configuration directory or the selected path.")

    def execute(self, context):
        state = context.window_manager.keymap_manager_state
        data = _generate_keymap_json_data(context, state.export_scope)
        try:
            path = _write_keymap_json(state.export_path, data)
        except (OSError, ValueError):
            self.report({"ERROR"}, _tr("The file could not be written."))
            return {"CANCELLED"}
        state.export_path = path
        self.report({"INFO"}, _tr("Keymap exported: {path}").format(path=path))
        return {"FINISHED"}


class KMM_OT_import_keymap(Operator):
    bl_idname = "keymap_manager.import_keymap"
    bl_label = "Import Keymap"
    bl_description = "Import a JELararagi keymap JSON file and append the stored bindings to the user keymap. Existing bindings are not removed automatically."
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Import a JELararagi keymap JSON file and append the stored bindings to the user keymap. Existing bindings are not removed automatically.")

    def execute(self, context):
        state = context.window_manager.keymap_manager_state
        if not state.import_path or not os.path.isfile(bpy.path.abspath(state.import_path)):
            self.report({"ERROR"}, _tr("Import file was not found."))
            return {"CANCELLED"}
        try:
            data = _read_keymap_json(state.import_path)
        except (OSError, ValueError):
            self.report({"ERROR"}, _tr("The file could not be read."))
            return {"CANCELLED"}
        count, skipped = _apply_keymap_json_data(context, data)
        if skipped:
            self.report({"WARNING"}, _tr("Keymap imported: {count} bindings, {skipped} could not be read completely").format(count=count, skipped=skipped))
        else:
            self.report({"INFO"}, _tr("Keymap imported: {count} bindings").format(count=count))
        return {"FINISHED"}


class KMM_OT_save_keymap_preset(Operator):
    bl_idname = "keymap_manager.save_keymap_preset"
    bl_label = "Save Preset"
    bl_description = "Save the current keymap as a named preset in Blender's user configuration directory. The add-on install directory is never modified."
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Save the current keymap as a named preset in Blender's user configuration directory. The add-on install directory is never modified.")

    def execute(self, context):
        state = context.window_manager.keymap_manager_state
        name = state.preset_name.strip()
        if not name:
            self.report({"ERROR"}, _tr("Preset name is empty."))
            return {"CANCELLED"}
        data = _generate_keymap_json_data(context, "ALL")
        try:
            _write_keymap_json(_preset_filepath(name), data)
        except (OSError, ValueError):
            self.report({"ERROR"}, _tr("The file could not be written."))
            return {"CANCELLED"}
        _invalidate_preset_enum_cache()
        _preset_items(state, context)
        try:
            state.preset_select = _preset_identifier_for_name(name)
        except TypeError:
            state.preset_select = "NONE"
        self.report({"INFO"}, _tr("Preset saved: {name}").format(name=name))
        return {"FINISHED"}


class KMM_OT_load_keymap_preset(Operator):
    bl_idname = "keymap_manager.load_keymap_preset"
    bl_label = "Load Preset"
    bl_description = "Load the selected keymap preset and append its stored bindings to the user keymap."
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Load the selected keymap preset and append its stored bindings to the user keymap.")

    def execute(self, context):
        state = context.window_manager.keymap_manager_state
        name = _preset_name_from_identifier(state.preset_select)
        if not name:
            self.report({"ERROR"}, _tr("No preset is selected."))
            return {"CANCELLED"}
        try:
            data = _read_keymap_json(_preset_filepath(name))
        except (OSError, ValueError):
            self.report({"ERROR"}, _tr("The file could not be read."))
            return {"CANCELLED"}
        count, skipped = _apply_keymap_json_data(context, data)
        if skipped:
            self.report({"WARNING"}, _tr("Preset loaded: {name} / {count} bindings, {skipped} could not be read completely").format(name=name, count=count, skipped=skipped))
        else:
            self.report({"INFO"}, _tr("Preset loaded: {name} / {count} bindings").format(name=name, count=count))
        return {"FINISHED"}


class KMM_OT_delete_keymap_preset(Operator):
    bl_idname = "keymap_manager.delete_keymap_preset"
    bl_label = "Delete Preset"
    bl_description = "Delete the selected keymap preset from the user configuration directory."
    bl_options = {"UNDO"}

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Delete the selected keymap preset from the user configuration directory.")

    def execute(self, context):
        state = context.window_manager.keymap_manager_state
        name = _preset_name_from_identifier(state.preset_select)
        if not name:
            self.report({"ERROR"}, _tr("No preset is selected."))
            return {"CANCELLED"}
        filepath = _preset_filepath(name)
        if os.path.exists(filepath):
            try:
                os.remove(filepath)
            except OSError:
                self.report({"ERROR"}, _tr("The preset file could not be deleted."))
                return {"CANCELLED"}
        _invalidate_preset_enum_cache()
        state.preset_select = "NONE"
        self.report({"INFO"}, _tr("Preset deleted: {name}").format(name=name))
        return {"FINISHED"}




class KMM_OT_load_blender_keymap_preset(Operator):
    bl_idname = "keymap_manager.load_blender_keymap_preset"
    bl_label = "Load Blender Keymap Preset"
    bl_description = "Load Blender's default keymap preset into this runtime session. This is mainly useful in background test sessions where Blender has not populated the keymap database yet."
    bl_options = {"INTERNAL", "UNDO"}

    @classmethod
    def description(cls, _context, _properties):
        return _tr("Load Blender's default keymap preset into this runtime session. This is mainly useful in background test sessions where Blender has not populated the keymap database yet.")

    def execute(self, _context):
        filepath = os.path.join(bpy.utils.resource_path("LOCAL"), "scripts", "presets", "keyconfig", "Blender.py")
        if not os.path.exists(filepath):
            self.report({"ERROR"}, _tr("The Blender keymap preset could not be found."))
            return {"CANCELLED"}
        bpy.ops.preferences.keyconfig_activate(filepath=filepath)
        _invalidate_view_cache()
        self.report({"INFO"}, _tr("The Blender keymap preset was loaded."))
        return {"FINISHED"}


_KEY_BUTTON_HEIGHT = 1.45
_DOUBLE_KEY_BUTTON_HEIGHT = 3.05


def _set_layout_units(layout, units: float) -> None:
    try:
        layout.ui_units_x = units
    except Exception:
        layout.scale_x = max(0.2, units / 3.0)


def _draw_spacer(layout, units: float) -> None:
    sub = layout.row(align=False)
    _set_layout_units(sub, units)
    sub.label(text="", translate=False)


def _assignment_modifier_set(assignments: list[_Match]) -> set[str]:
    modifiers: set[str] = set()
    for match in assignments:
        item = match.item
        for modifier in ("ctrl", "shift", "alt", "oskey", "hyper"):
            if hasattr(item, modifier) and int(getattr(item, modifier)) == 1:
                modifiers.add(modifier)
    return modifiers


def _draw_key_button(
    layout,
    spec: _KeySpec,
    available: set[str],
    state: KMM_State,
    operator_mode: bool,
    assigned_types: set[str],
    assigned_modifiers: set[str],
    height: float = 1.0,
) -> None:
    sub = layout.row(align=False)
    _set_layout_units(sub, spec.units)
    sub.scale_y = height
    if not spec.label and spec.event_type is None:
        sub.label(text="", translate=False)
        return

    visual_mode = state.view_mode == "VISUAL"

    if spec.modifier:
        depress = (spec.modifier in assigned_modifiers) if (operator_mode or visual_mode) else bool(getattr(state, "selected_" + spec.modifier, False))
        op = _operator_no_translate(
            sub,
            KMM_OT_toggle_filter_modifier.bl_idname,
            text=spec.label,
            depress=depress,
        )
        op.modifier = spec.modifier
        return

    is_supported = bool(spec.event_type and spec.event_type in available and spec.supported)
    if is_supported:
        depress = (spec.event_type in assigned_types) if (operator_mode or visual_mode) else (spec.event_type == state.selected_type)
        op = _operator_no_translate(sub, KMM_OT_select_key.bl_idname, text=spec.label, depress=depress)
        op.event_type = spec.event_type
        op.label = spec.label
    else:
        disabled = sub.row(align=False)
        disabled.enabled = False
        op = _operator_no_translate(disabled, KMM_OT_select_key.bl_idname, text=spec.label)
        op.event_type = ""
        op.label = spec.label


def _draw_spec_row(
    layout,
    specs: tuple[_KeySpec, ...],
    available: set[str],
    state: KMM_State,
    operator_mode: bool,
    assigned_types: set[str],
    assigned_modifiers: set[str],
    height: float = 1.0,
) -> None:
    row = layout.row(align=False)
    for spec in specs:
        _draw_key_button(row, spec, available, state, operator_mode, assigned_types, assigned_modifiers, height)


def _draw_key_block(
    layout,
    rows: tuple[tuple[_KeySpec, ...], ...],
    available: set[str],
    state: KMM_State,
    operator_mode: bool,
    assigned_types: set[str],
    assigned_modifiers: set[str],
) -> None:
    block = layout.column(align=False)
    for row_specs in rows:
        _draw_spec_row(block, row_specs, available, state, operator_mode, assigned_types, assigned_modifiers, height=_KEY_BUTTON_HEIGHT)


def _draw_numpad_block(
    layout,
    available: set[str],
    state: KMM_State,
    operator_mode: bool,
    assigned_types: set[str],
    assigned_modifiers: set[str],
) -> None:
    block = layout.column(align=False)
    _draw_spec_row(block, _NUMPAD_TOP_SPACER, available, state, operator_mode, assigned_types, assigned_modifiers, height=_KEY_BUTTON_HEIGHT)
    _draw_spec_row(block, _NUMPAD_ROW_1, available, state, operator_mode, assigned_types, assigned_modifiers, height=_KEY_BUTTON_HEIGHT)

    plus_group = block.row(align=False)
    left_grid = plus_group.column(align=False)
    _draw_spec_row(left_grid, _NUMPAD_ROW_2, available, state, operator_mode, assigned_types, assigned_modifiers, height=_KEY_BUTTON_HEIGHT)
    _draw_spec_row(left_grid, _NUMPAD_ROW_3, available, state, operator_mode, assigned_types, assigned_modifiers, height=_KEY_BUTTON_HEIGHT)
    _draw_key_button(plus_group, _KeySpec("NUMPAD_PLUS", "+", 3.3), available, state, operator_mode, assigned_types, assigned_modifiers, height=_DOUBLE_KEY_BUTTON_HEIGHT)

    enter_group = block.row(align=False)
    left_grid = enter_group.column(align=False)
    _draw_spec_row(left_grid, _NUMPAD_ROW_4, available, state, operator_mode, assigned_types, assigned_modifiers, height=_KEY_BUTTON_HEIGHT)
    _draw_spec_row(left_grid, _NUMPAD_ROW_5, available, state, operator_mode, assigned_types, assigned_modifiers, height=_KEY_BUTTON_HEIGHT)
    _draw_key_button(enter_group, _KeySpec("NUMPAD_ENTER", "Enter", 3.3), available, state, operator_mode, assigned_types, assigned_modifiers, height=_DOUBLE_KEY_BUTTON_HEIGHT)



_SECTION_STATE_PROPERTIES = {
    "keyboard": "section_keyboard_open",
    "mouse": "section_mouse_open",
    "ndof": "section_ndof_open",
    "key_filter": "section_key_filter_open",
    "io": "section_io_open",
    "registered": "section_registered_open",
}


def _draw_help_button(layout, topic: str) -> None:
    op = layout.operator(KMM_OT_show_help.bl_idname, text="", icon="QUESTION")
    op.topic = topic


def _draw_collapsible_section(layout, state: KMM_State, section_id: str, title: str, icon: str = "NONE"):
    header, body = layout.panel_prop(state, _SECTION_STATE_PROPERTIES[section_id])
    header.label(text=title, icon=icon, translate=False)
    right = header.row(align=True)
    right.alignment = "RIGHT"
    _draw_help_button(right, section_id)
    return body


_NDOF_JA_LABELS = {
    "Motion": "モーション",
    "Menu": "メニュー",
    "Fit": "フィット",
    "Top": "上",
    "Bottom": "下",
    "Left": "左",
    "Right": "右",
    "Front": "前",
    "Back": "後",
    "Iso1": "等角1",
    "Iso2": "等角2",
    "R CW": "ロール右",
    "R CCW": "ロール左",
    "S CW": "スピン右",
    "S CCW": "スピン左",
    "T CW": "チルト右",
    "T CCW": "チルト左",
    "Rotate": "回転",
    "P/Zoom": "パン/ズーム",
    "Dom": "主軸",
    "View 1": "ビュー1",
    "View 2": "ビュー2",
    "View 3": "ビュー3",
    "Save1": "保存1",
    "Save2": "保存2",
    "Save3": "保存3",
}

_NDOF_COMPACT_LABELS = {
    "NDOF_MOTION": "Motion",
    "NDOF_BUTTON_MENU": "Menu",
    "NDOF_BUTTON_FIT": "Fit",
    "NDOF_BUTTON_TOP": "Top",
    "NDOF_BUTTON_BOTTOM": "Bottom",
    "NDOF_BUTTON_LEFT": "Left",
    "NDOF_BUTTON_RIGHT": "Right",
    "NDOF_BUTTON_FRONT": "Front",
    "NDOF_BUTTON_BACK": "Back",
    "NDOF_BUTTON_ISO1": "Iso1",
    "NDOF_BUTTON_ISO2": "Iso2",
    "NDOF_BUTTON_ROLL_CW": "R CW",
    "NDOF_BUTTON_ROLL_CCW": "R CCW",
    "NDOF_BUTTON_SPIN_CW": "S CW",
    "NDOF_BUTTON_SPIN_CCW": "S CCW",
    "NDOF_BUTTON_TILT_CW": "T CW",
    "NDOF_BUTTON_TILT_CCW": "T CCW",
    "NDOF_BUTTON_ROTATE": "Rotate",
    "NDOF_BUTTON_PANZOOM": "P/Zoom",
    "NDOF_BUTTON_DOMINANT": "Dom",
    "NDOF_BUTTON_PLUS": "+",
    "NDOF_BUTTON_MINUS": "-",
    "NDOF_BUTTON_SAVE_V1": "Save1",
    "NDOF_BUTTON_SAVE_V2": "Save2",
    "NDOF_BUTTON_SAVE_V3": "Save3",
}


def _ndof_compact_spec(spec: _KeySpec) -> _KeySpec:
    label = _NDOF_COMPACT_LABELS.get(spec.event_type or "", spec.label)
    if spec.event_type and spec.event_type.startswith("NDOF_BUTTON_") and spec.label.startswith("NDOF "):
        label = "N" + spec.label.split(" ", 1)[1]
    if _is_japanese_ui():
        label = _NDOF_JA_LABELS.get(label, label)
    width = sum(2 if ord(char) > 127 else 1 for char in label)
    units = 2.6 if width <= 4 else (3.2 if width <= 6 else 4.0)
    return _KeySpec(spec.event_type, label, units, spec.supported, spec.modifier)


def _chunked_specs(specs: list[_KeySpec], size: int) -> list[tuple[_KeySpec, ...]]:
    return [tuple(specs[index:index + size]) for index in range(0, len(specs), size)]



def _draw_mouse_operation_button(
    layout,
    spec: _KeySpec,
    available: set[str],
    state: KMM_State,
    operator_mode: bool,
    assigned_types: set[str],
    height: float = 1.0,
) -> None:
    sub = layout.row(align=False)
    _set_layout_units(sub, spec.units)
    sub.scale_y = height
    if not spec.label and spec.event_type is None:
        sub.label(text="", translate=False)
        return

    visual_mode = state.view_mode == "VISUAL"
    is_supported = bool(spec.event_type and spec.event_type in available and spec.supported)
    if is_supported:
        depress = (spec.event_type in assigned_types) if (operator_mode or visual_mode) else (spec.event_type == state.selected_type)
        op = _operator_no_translate(sub, KMM_OT_select_key.bl_idname, text=_tr_ctx(spec.label), depress=depress)
        op.event_type = spec.event_type
        op.label = spec.label
        op.is_mouse_operation = True
    else:
        disabled = sub.row(align=False)
        disabled.enabled = False
        op = _operator_no_translate(disabled, KMM_OT_select_key.bl_idname, text=_tr_ctx(spec.label))
        op.event_type = ""
        op.label = spec.label
        op.is_mouse_operation = True


def _draw_mouse_spec_row(
    layout,
    specs: tuple[_KeySpec, ...],
    available: set[str],
    state: KMM_State,
    operator_mode: bool,
    assigned_types: set[str],
    height: float = 1.0,
) -> None:
    row = layout.row(align=False)
    for spec in specs:
        _draw_mouse_operation_button(row, spec, available, state, operator_mode, assigned_types, height)


def _draw_mouse_block(
    layout,
    title: str,
    rows: tuple[tuple[_KeySpec, ...], ...],
    available: set[str],
    state: KMM_State,
    operator_mode: bool,
    assigned_types: set[str],
    height: float = 1.12,
) -> None:
    block = layout.box()
    block.label(text=_tr(title), translate=False)
    for row_specs in rows:
        _draw_mouse_spec_row(block, row_specs, available, state, operator_mode, assigned_types, height=height)


def _draw_mouse_operations(
    layout,
    available: set[str],
    state: KMM_State,
    operator_mode: bool,
    assigned_types: set[str],
    enabled: bool = True,
) -> None:
    layout.enabled = enabled
    top = layout.row(align=False)
    buttons = top.column(align=False)
    wheel = top.column(align=False)
    pointer = top.column(align=False)
    _draw_mouse_block(buttons, "Mouse Buttons", _MOUSE_BUTTON_ROWS, available, state, operator_mode, assigned_types, height=1.08)
    _draw_mouse_block(wheel, "Wheel / Scroll", _MOUSE_WHEEL_ROWS, available, state, operator_mode, assigned_types, height=1.08)
    _draw_mouse_block(pointer, "Pointer / Trackpad", _MOUSE_POINTER_ROWS, available, state, operator_mode, assigned_types, height=1.08)


def _draw_ndof_operations(
    layout,
    available: set[str],
    state: KMM_State,
    operator_mode: bool,
    assigned_types: set[str],
    enabled: bool = True,
) -> None:
    layout.enabled = enabled
    compact_specs = [_ndof_compact_spec(spec) for row_specs in _NDOF_ROWS for spec in row_specs]
    for row_specs in _chunked_specs(compact_specs, 7):
        _draw_mouse_spec_row(layout, row_specs, available, state, operator_mode, assigned_types, height=1.02)

def _draw_keyboard(layout, state: KMM_State, assignments: list[_Match], enabled: bool = True):
    available = _available_event_identifiers()
    operator_query = _operator_query(state)
    operator_mode = bool(operator_query)
    visual_mode = state.view_mode == "VISUAL"
    assigned_types = {match.item.type for match in assignments} if (operator_mode or visual_mode) else set()
    assigned_modifiers = _assignment_modifier_set(assignments) if (operator_mode or visual_mode) else set()

    keyboard = _draw_collapsible_section(layout, state, "keyboard", _tr("Keyboard Layout"), icon="EVENT_K")
    if keyboard:
        keyboard.enabled = enabled
        if operator_query:
            keyboard.label(text=f"{_tr('Operator ID filter is active')}: {operator_query}", icon="VIEWZOOM", translate=False)
            _label_no_translate(keyboard, f"{_tr('Assigned Keys')}: {_assigned_key_summary(assignments)}")
        clusters = keyboard.row(align=False)

        main = clusters.column(align=False)
        gap_1 = clusters.column(align=False)
        nav = clusters.column(align=False)
        gap_2 = clusters.column(align=False)
        num = clusters.column(align=False)

        _draw_key_block(main, _MAIN_BLOCK_ROWS, available, state, operator_mode, assigned_types, assigned_modifiers)
        _draw_spacer(gap_1, 1.2)
        _draw_key_block(nav, _NAV_BLOCK_ROWS, available, state, operator_mode, assigned_types, assigned_modifiers)
        _draw_spacer(gap_2, 1.2)
        _draw_numpad_block(num, available, state, operator_mode, assigned_types, assigned_modifiers)

    mouse = _draw_collapsible_section(layout, state, "mouse", _tr("Mouse Operations"), icon="EVENT_K")
    if mouse:
        _draw_mouse_operations(mouse, available, state, operator_mode, assigned_types, enabled=enabled)

    ndof = _draw_collapsible_section(layout, state, "ndof", _tr("3D Mouse / NDOF"), icon="EVENT_K")
    if ndof:
        _draw_ndof_operations(ndof, available, state, operator_mode, assigned_types, enabled=enabled)


_MAJOR_PARENT_NAMES = {
    "Window", "Screen", "3D View", "Image", "UV Editor", "Node Editor", "Graph Editor", "Dopesheet",
    "NLA Editor", "Sequencer", "Text", "Console", "Outliner", "Properties", "File Browser",
    "Info", "Spreadsheet", "Clip Editor", "Animation", "Frames",
}

_JA_KEYMAP_NAMES = {
    "Window": "ウィンドウ",
    "Screen": "スクリーン",
    "3D View": "3Dビュー",
    "3D View (Global)": "3Dビュー（グローバル）",
    "Image": "画像",
    "UV Editor": "UVエディター",
    "Node Editor": "ノードエディター",
    "Graph Editor": "グラフエディター",
    "Dopesheet": "ドープシート",
    "NLA Editor": "NLAエディター",
    "Sequencer": "シーケンサー",
    "Text": "テキスト",
    "Console": "コンソール",
    "Outliner": "アウトライナー",
    "Properties": "プロパティ",
    "File Browser": "ファイルブラウザー",
    "Info": "情報",
    "Spreadsheet": "スプレッドシート",
    "Clip Editor": "クリップエディター",
    "Object Mode": "オブジェクトモード",
    "Mesh": "メッシュ",
    "Curve": "カーブ",
    "Armature": "アーマチュア",
    "Pose": "ポーズ",
    "Sculpt": "スカルプト",
    "Grease Pencil": "グリースペンシル",
    "Interpolate Tool Modal Map": "補間ツールモーダルマップ",
    "Node Link Modal Map": "ノードリンクモーダルマップ",
    "Node Resize Modal Map": "ノードリサイズモーダルマップ",
    "Slip Modal": "スリップモーダル",
    "Time Scrub": "タイムスクラブ",
    "Clip Time Scrub": "クリップのタイムスクラブ",
    "Gesture Lasso": "投げ縄ジェスチャー",
    "Gesture Polyline": "ポリラインジェスチャー",
    "Grease Pencil Selection": "グリースペンシルの選択",
    "Sequencer Channels": "シーケンサーのチャンネル",
    "Toolbar Popup": "ツールバーのポップアップ",
    "Preferences_nav": "プリファレンスのナビゲーション",
    "3D View Tool: Bend": "3Dビューツール：ベンド",
    "3D View Tool: Edit Curves, Draw": "3Dビューツール：カーブ編集，ドロー",
    "3D View Tool: Edit Curves, Pen": "3Dビューツール：カーブ編集，ペン",
    "3D View Tool: Edit Grease Pencil, Gradient": "3Dビューツール：グリースペンシル編集，グラデーション",
    "3D View Tool: Edit Grease Pencil, Interpolate": "3Dビューツール：グリースペンシル編集，補間",
    "3D View Tool: Edit Grease Pencil, Pen": "3Dビューツール：グリースペンシル編集，ペン",
    "3D View Tool: Edit Mesh, Spin Duplicates": "3Dビューツール：メッシュ編集，スピン複製",
    "3D View Tool: Paint Grease Pencil, Arc": "3Dビューツール：グリースペンシルペイント，弧",
    "3D View Tool: Paint Grease Pencil, Box": "3Dビューツール：グリースペンシルペイント，ボックス",
    "3D View Tool: Paint Grease Pencil, Circle": "3Dビューツール：グリースペンシルペイント，円",
    "3D View Tool: Paint Grease Pencil, Curve": "3Dビューツール：グリースペンシルペイント，カーブ",
    "3D View Tool: Paint Grease Pencil, Eyedropper": "3Dビューツール：グリースペンシルペイント，スポイト",
    "3D View Tool: Paint Grease Pencil, Interpolate": "3Dビューツール：グリースペンシルペイント，補間",
    "3D View Tool: Paint Grease Pencil, Line": "3Dビューツール：グリースペンシルペイント，ライン",
    "3D View Tool: Paint Grease Pencil, Polyline": "3Dビューツール：グリースペンシルペイント，ポリライン",
    "3D View Tool: Paint Grease Pencil, Trim": "3Dビューツール：グリースペンシルペイント，トリム",
    "Image Editor Tool: Mask, Box": "画像エディターツール：マスク，ボックス",
    "Image Editor Tool: Mask, Circle": "画像エディターツール：マスク，円",
    "Image Editor Tool: Mask, Cursor": "画像エディターツール：マスク，カーソル",
    "Image Editor Tool: Mask, Move": "画像エディターツール：マスク，移動",
    "Image Editor Tool: Mask, Rotate": "画像エディターツール：マスク，回転",
    "Image Editor Tool: Mask, Scale": "画像エディターツール：マスク，スケール",
    "Image Editor Tool: Mask, Select Box": "画像エディターツール：マスク，ボックス選択",
    "Image Editor Tool: Mask, Select Box (fallback)": "画像エディターツール：マスク，ボックス選択（予備）",
    "Image Editor Tool: Mask, Select Circle": "画像エディターツール：マスク，サークル選択",
    "Image Editor Tool: Mask, Select Circle (fallback)": "画像エディターツール：マスク，サークル選択（予備）",
    "Image Editor Tool: Mask, Select Lasso": "画像エディターツール：マスク，投げ縄選択",
    "Image Editor Tool: Mask, Select Lasso (fallback)": "画像エディターツール：マスク，投げ縄選択（予備）",
    "Image Editor Tool: Mask, Transform": "画像エディターツール：マスク，トランスフォーム",
    "Image Editor Tool: Mask, Tweak": "画像エディターツール：マスク，長押し",
    "Image Editor Tool: Mask, Tweak (fallback)": "画像エディターツール：マスク，長押し（予備）",
    "Node Tool: Add Reroute": "ノードツール：リルートを追加",
    "Node Tool: Links Cut": "ノードツール：リンクをカット",
    "Node Tool: Mute Links": "ノードツール：リンクをミュート",
}

# 本体に訳が無いモーダル値の名前
_JA_MODAL_VALUES = {
    "Enable Precision": "精度を有効化",
    "Disable Precision": "精度を無効化",
    "Enable Snap": "スナップを有効化",
    "Disable Snap": "スナップを無効化",
    "No Operation": "何もしない",
    "Begin": "開始",
    "Snap On": "スナップ オン",
    "Snap Off": "スナップ オフ",
    "Increase Subdivision": "細分化を増やす",
    "Decrease Subdivision": "細分化を減らす",
    "Change Radius": "半径を変更",
    "Change Opacity": "不透明度を変更",
    "Toggle Extension Mode": "延長モードを切り替え",
    "Lengthen Extensions": "延長線を長くする",
    "Shorten Extensions": "延長線を短くする",
    "Drag Extensions": "延長線をドラッグ",
    "Collide Extensions": "延長線を衝突させる",
    "Increase": "増やす",
    "Decrease": "減らす",
    "Snap to Midpoints On": "中点へのスナップ オン",
    "Snap to Midpoints Off": "中点へのスナップ オフ",
    "Ignore Snapping On": "スナップを無視 オン",
    "Ignore Snapping Off": "スナップを無視 オフ",
    "Toggle Angle Snapping": "角度スナップを切り替え",
    "Cycle Angle Snapping Relative Edge": "角度スナップの基準の辺を順に切り替え",
    "Toggle Cut Through": "貫通カットを切り替え",
    "Toggle Distance and Angle Measurements": "距離と角度の表示を切り替え",
    "Toggle Depth Testing": "深度テストを切り替え",
    "End Current Cut": "今のカットを終了",
    "Add Cut": "カットを追加",
    "Add Cut Closed": "閉じたカットを追加",
    "X Axis Locking": "X軸に固定",
    "Y Axis Locking": "Y軸に固定",
    "Z Axis Locking": "Z軸に固定",
    "Use Mouse": "マウスを使う",
    "Set and Use 3D Cursor": "3Dカーソルを設定して使う",
    "Select and Use Mesh Item": "メッシュの要素を選択して使う",
    "Change Offset": "オフセットを変更",
    "Change Profile": "断面を変更",
    "Change Segments": "セグメント数を変更",
    "Increase Segments": "セグメントを増やす",
    "Decrease Segments": "セグメントを減らす",
    "Change Offset Mode": "オフセットのモードを変更",
    "Toggle Clamp Overlap": "重なりの制限を切り替え",
    "Change Affect Type": "対象の種類を変更",
    "Toggle Harden Normals": "法線の硬化を切り替え",
    "Toggle Mark Seam": "シームのマークを切り替え",
    "Toggle Mark Sharp": "シャープのマークを切り替え",
    "Change Outer Miter": "外側のマイターを変更",
    "Change Inner Miter": "内側のマイターを変更",
    "Cycle through profile types": "断面の種類を順に切り替え",
    "Change Intersection Method": "交差の方法を変更",
    "Snap (OFF)": "スナップ（オフ）",
    "Precision (OFF)": "精度（オフ）",
    "Free-Align Toggle": "自由・整列を切り替え",
    "Move Adjacent Handle": "隣のハンドルを移動",
    "Link Handles": "ハンドルを連動",
    "Lock Angle": "角度を固定",
    "Toggle Preserve State": "状態の保持を切り替え",
    "Toggle Gradient": "グラデーションを切り替え",
    "Geodesic recursion step": "測地線の再帰ステップ",
    "Topology recursion Step": "トポロジーの再帰ステップ",
    "Move Origin": "原点を移動",
    "Geodesic Falloff": "測地線の減衰",
    "Topology Falloff": "トポロジーの減衰",
    "Diagonals Falloff": "対角線の減衰",
    "Snap expand to Face Sets": "拡張を面セットにスナップ",
    "Loop Count Increase": "ループ数を増やす",
    "Loop Count Decrease": "ループ数を減らす",
    "Toggle Brush Gradient": "ブラシのグラデーションを切り替え",
    "Texture Distortion Increase": "テクスチャの歪みを増やす",
    "Texture Distortion Decrease": "テクスチャの歪みを減らす",
    "Confirm Sampling": "採取を確定",
    "Start Sampling": "採取を開始",
    "Reset Sampling": "採取をリセット",
    "Sample a Point": "1点を採取",
    "Set Snap Base (Off)": "スナップの基準を設定（オフ）",
    "Snap Invert (Off)": "スナップの反転（オフ）",
    "Snap Toggle": "スナップを切り替え",
    "Add Snap Point": "スナップ点を追加",
    "Remove Last Snap Point": "最後のスナップ点を削除",
    "Numinput Increment Up": "数値入力の増分を上げる",
    "Numinput Increment Down": "数値入力の増分を下げる",
    "Increase Proportional Influence": "プロポーショナルの影響範囲を広げる",
    "Decrease Proportional Influence": "プロポーショナルの影響範囲を狭める",
    "Adjust Proportional Influence": "プロポーショナルの影響範囲を調整",
    "Increase Max AutoIK Chain Length": "自動IKのチェーンの長さを増やす",
    "Decrease Max AutoIK Chain Length": "自動IKのチェーンの長さを減らす",
    "Toggle Direction for Node Auto-Offset": "ノードの自動オフセットの向きを切り替え",
    "Node Attachment": "ノードの接続",
    "Node Attachment (Off)": "ノードの接続（オフ）",
    "Vert/Edge Slide": "頂点・辺スライド",
    "Rotate Normals": "法線を回転",
    "Automatic Constraint": "自動の軸制限",
    "Automatic Constraint Plane": "自動の面制限",
    "Attach/Detach Frame": "フレームへの接続・解除",
    "Clamp Strips": "ストリップを制限",
    "Backward": "後退",
    "Pan (Off)": "パン（オフ）",
    "Accelerate": "加速",
    "Decelerate": "減速",
    "X Axis Correction": "X軸の補正",
    "Precision (Off)": "精度（オフ）",
    "Rotation (Off)": "回転（オフ）",
    "Local Up": "ローカルの上へ",
    "Local Down": "ローカルの下へ",
    "Stop Move Forward": "前進を止める",
    "Stop Move Backward": "後退を止める",
    "Stop Move Left": "左への移動を止める",
    "Stop Move Right": "右への移動を止める",
    "Stop Move Global Up": "グローバルの上への移動を止める",
    "Stop Move Global Down": "グローバルの下への移動を止める",
    "Stop Move Local Up": "ローカルの上への移動を止める",
    "Stop Move Local Down": "ローカルの下への移動を止める",
    "Fast (Off)": "高速（オフ）",
    "Slow (Off)": "低速（オフ）",
    "Jump (Off)": "ジャンプ（オフ）",
    "Toggle Gravity": "重力を切り替え",
    "Increase Jump Height": "ジャンプの高さを増やす",
    "Decrease Jump Height": "ジャンプの高さを減らす",
    "Axis Snap": "軸スナップ",
    "Axis Snap (Off)": "軸スナップ（オフ）",
    "Switch to Zoom": "ズームに切り替え",
    "Switch to Move": "移動に切り替え",
    "Switch to Rotate": "回転に切り替え",
    "Fixed Aspect On": "縦横比の固定 オン",
    "Fixed Aspect Off": "縦横比の固定 オフ",
    "Center Pivot On": "中心をピボットに オン",
    "Center Pivot Off": "中心をピボットに オフ",
    "Drag Node-link": "ノードのリンクをドラッグ",
    "Confirm Link": "リンクを確定",
    "Resize Node": "ノードのサイズを変更",
    "Precision Enable": "精度を有効化",
    "Precision Disable": "精度を無効化",
    "Clamp Toggle": "制限を切り替え",
}

_ALPHA_TYPES = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
_NUMBER_TYPES = {"ZERO", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "NUMPAD_0", "NUMPAD_1", "NUMPAD_2", "NUMPAD_3", "NUMPAD_4", "NUMPAD_5", "NUMPAD_6", "NUMPAD_7", "NUMPAD_8", "NUMPAD_9"}
_SYMBOL_TYPES = {"ACCENT_GRAVE", "MINUS", "EQUAL", "LEFT_BRACKET", "RIGHT_BRACKET", "BACK_SLASH", "SEMI_COLON", "QUOTE", "COMMA", "PERIOD", "SLASH", "NUMPAD_SLASH", "NUMPAD_ASTERIX", "NUMPAD_MINUS", "NUMPAD_PLUS", "NUMPAD_PERIOD"}


def _is_japanese_ui() -> bool:
    return bpy.app.translations.locale.startswith("ja") and bpy.context.preferences.view.use_translate_interface


def _friendly_keymap_name(name: str) -> str:
    if _is_japanese_ui():
        try:
            translations = bpy.app.translations
            translated = translations.pgettext_iface(name, translations.contexts.id_windowmanager)
            if translated == name:
                translated = translations.pgettext_iface(name)
        except Exception:
            translated = name
        if translated and translated != name:
            return translated
        return _JA_KEYMAP_NAMES.get(name, name)
    return name


def _bracket_label(name: str) -> str:
    return f"【{_friendly_keymap_name(name)}】"


def _hierarchy_keymap_entries() -> list[dict]:
    entries: list[dict] = []

    def visit(nodes, depth: int, parent_name: str, parent_order: int, path: tuple[str, ...]) -> None:
        for name, space_type, region_type, children in nodes:
            current_path = (*path, name)
            if depth == 0:
                top_name = name
                top_order = len(entries)
            else:
                top_name = parent_name
                top_order = parent_order
            entries.append({
                "name": name,
                "space_type": space_type,
                "region_type": region_type,
                "depth": depth,
                "top_name": top_name,
                "top_order": top_order,
                "order": len(entries),
                "path": " > ".join(current_path),
                "has_children": bool(children),
            })
            visit(children, depth + 1, top_name, top_order, current_path)

    visit(_hierarchy_tree(), 0, "", 0, tuple())
    return entries


def _global_child_label(parent_name: str) -> str:
    parent_label = _friendly_keymap_name(parent_name)
    if _is_japanese_ui():
        return f"{parent_label}（グローバル）"
    return f"{parent_label} (Global)"


def _unused_category_data(all_items: list[_Match]) -> dict[str, dict]:
    actual_by_key: dict[tuple[str, str, str], list[_Match]] = {}
    for match in all_items:
        actual_by_key.setdefault((match.keymap.name, match.keymap.space_type, match.keymap.region_type), []).append(match)

    data: dict[str, dict] = {}
    seen_refs: set[str] = set()

    for entry in _hierarchy_keymap_entries():
        key = (entry["name"], entry["space_type"], entry["region_type"])
        matches = actual_by_key.get(key)
        if not matches:
            continue
        ref_key = _keymap_ref_key(matches[0])
        if ref_key in seen_refs:
            continue
        seen_refs.add(ref_key)

        parent_key = entry["top_name"]
        parent_entry = data.setdefault(parent_key, {
            "label": _bracket_label(parent_key),
            "order": entry["top_order"],
            "children": {},
        })

        if entry["depth"] == 0:
            child_display = _global_child_label(parent_key) if entry["has_children"] else parent_key
            child_order = 0
        else:
            path_parts = [part for part in entry["path"].split(" > ")[1:] if part]
            child_display = " → ".join(_friendly_keymap_name(part) for part in path_parts) if path_parts else _friendly_keymap_name(entry["name"])
            child_order = entry["order"]

        child_key = entry["path"]
        child_entry = parent_entry["children"].setdefault(child_key, {
            "label": _bracket_label(child_display),
            "order": child_order,
            "matches": [],
        })
        child_entry["matches"].extend(matches)

    return dict(sorted(data.items(), key=lambda kv: kv[1]["order"]))


def _all_key_specs() -> list[_KeySpec]:
    specs: list[_KeySpec] = []
    for rows in (_MAIN_BLOCK_ROWS, _NAV_BLOCK_ROWS):
        for row in rows:
            specs.extend(row)
    for row in (_NUMPAD_ROW_1, _NUMPAD_ROW_2, _NUMPAD_ROW_3, _NUMPAD_ROW_4, _NUMPAD_ROW_5):
        specs.extend(row)
    seen = set()
    result = []
    available = _available_event_identifiers()
    for spec in specs:
        if spec.event_type and spec.event_type in available and spec.supported and not spec.modifier and spec.event_type not in seen:
            seen.add(spec.event_type)
            result.append(spec)
    return result


def _modifier_combinations_for_unused() -> list[tuple[str, ...]]:
    modifiers = ("ctrl", "shift", "alt", "oskey", "hyper")
    combos: list[tuple[str, ...]] = [tuple()]
    for mask in range(1, 1 << len(modifiers)):
        combos.append(tuple(modifiers[i] for i in range(len(modifiers)) if mask & (1 << i)))
    return combos


def _candidate_signature(event_type: str, modifiers: tuple[str, ...]) -> tuple:
    return (
        event_type,
        "PRESS",
        "NONE",
        False,
        1 if "ctrl" in modifiers else 0,
        1 if "shift" in modifiers else 0,
        1 if "alt" in modifiers else 0,
        1 if "oskey" in modifiers else 0,
        1 if "hyper" in modifiers else 0,
        "ANY",
    )


def _format_candidate_event(event_type: str, modifiers: tuple[str, ...]) -> str:
    return _format_event_from_values(
        event_type,
        "PRESS",
        "ctrl" in modifiers,
        "shift" in modifiers,
        "alt" in modifiers,
        "oskey" in modifiers,
        "hyper" in modifiers,
        "NONE",
    )


def _key_sort_group(spec: _KeySpec) -> str:
    if spec.event_type in _ALPHA_TYPES:
        return "alpha"
    if spec.event_type and spec.event_type.startswith("NUMPAD_"):
        return "other"
    if spec.event_type in _NUMBER_TYPES:
        return "number"
    if spec.event_type and spec.event_type.startswith("F") and spec.event_type[1:].isdigit():
        return "function"
    if spec.event_type in _SYMBOL_TYPES:
        return "symbol"
    return "other"


def _unused_sort_key(label: str, modifiers: tuple[str, ...], spec: _KeySpec) -> tuple:
    group = _key_sort_group(spec)
    group_order = {"alpha": 0, "number": 1, "function": 2, "symbol": 3, "other": 4}.get(group, 4)
    if group == "number":
        base = spec.label.zfill(3)
    elif group == "function":
        digits = "".join(ch for ch in spec.label if ch.isdigit())
        base = digits.zfill(3)
    else:
        base = spec.label
    return (group_order, base, len(modifiers), modifiers, label)


def _unused_base_key_label(spec: _KeySpec) -> str:
    if spec.event_type and spec.event_type.startswith("NUMPAD_"):
        return _tr_ctx("Numpad {key}").format(key=spec.label)
    return spec.label


def _unused_candidates_grouped_for_keymaps(keymap_matches: list[_Match]) -> list[tuple[str, list[str]]]:
    used = set()
    for match in keymap_matches:
        for item in match.keymap.keymap_items:
            used.add(_event_signature(item))

    grouped: dict[str, tuple[str, tuple, list[tuple[tuple, str]]]] = {}
    for spec in _all_key_specs():
        labels: list[tuple[tuple, str]] = []
        for modifiers in _modifier_combinations_for_unused():
            signature = _candidate_signature(spec.event_type, modifiers)
            if signature not in used:
                label = _format_candidate_event(spec.event_type, modifiers)
                labels.append(((len(modifiers), modifiers, label), label))
        if labels:
            group_sort = _unused_sort_key(_unused_base_key_label(spec), tuple(), spec)
            labels.sort(key=lambda item: item[0])
            grouped[spec.event_type] = (_unused_base_key_label(spec), group_sort, labels)

    rows = sorted(grouped.values(), key=lambda item: item[1])
    return [(base_label, [label for _sort, label in labels]) for base_label, _group_sort, labels in rows]


def _draw_unused_candidates(layout, state: KMM_State, child_key: str, child_entry: dict) -> None:
    grouped_candidates = _unused_candidates_grouped_for_keymaps(child_entry["matches"])
    candidate_count = sum(len(labels) for _base_key, labels in grouped_candidates)
    layout.label(text=f"{_tr('Unused Shortcut Candidates')} / {_tr('Matches: {count}').format(count=candidate_count)}", translate=False)
    if not grouped_candidates:
        layout.label(text=_tr("No unused shortcut candidate was found."), translate=False)
        return

    expanded_base_keys = _expanded_unused_base_keys(state)
    for base_key, labels in grouped_candidates:
        group_key = child_key + "|" + base_key
        group_box = layout.box()
        header, body = _open_close_panel(group_box, "base", group_key, expanded_base_keys)
        _label_no_translate(header, f"{_tr('Base Key')}: {base_key} / {_tr('Matches: {count}').format(count=len(labels))}", icon="EVENT_K")
        if body is None:
            continue
        for label in labels:
            _label_no_translate(body, "• " + label)


def _draw_unused_view(layout, state: KMM_State, all_items: list[_Match]) -> None:
    categories = _unused_category_data(all_items)
    box = layout.box()
    box.label(text=_tr("Unused keymap view is active."), translate=False)

    if not categories:
        box.label(text=_tr("No unused shortcut candidate was found."), translate=False)
        return

    expanded = _expanded_unused_parent_keys(state)
    box.label(text=_tr("Parent Categories"), translate=False)
    for parent_key, entry in categories.items():
        children = entry["children"]
        header, body = _open_close_panel(box, "parent", parent_key, expanded)
        _label_no_translate(header, entry["label"], icon="FILE_FOLDER")

        if body is None:
            continue

        if len(children) == 1:
            child_key, child_entry = next(iter(children.items()))
            child_box = body.box()
            _label_no_translate(child_box, child_entry["label"], icon="KEYINGSET")
            _draw_unused_candidates(child_box, state, child_key, child_entry)
            continue

        body.label(text=_tr("Subcategories"), translate=False)
        for child_key, child_entry in sorted(children.items(), key=lambda kv: kv[1]["order"]):
            child_row = body.row(align=True)
            depress = state.unused_parent_key == parent_key and state.unused_child_key == child_key
            op = _operator_no_translate(
                child_row,
                KMM_OT_select_unused_child.bl_idname,
                text=child_entry["label"],
                icon="KEYINGSET",
                depress=depress,
            )
            op.parent_key = parent_key
            op.child_key = child_key
            if depress:
                candidate_box = body.box()
                _draw_unused_candidates(candidate_box, state, child_key, child_entry)


# ---------------------------------------------------------------------------
# Integrated visual overview, import/export, and preset helpers
# ---------------------------------------------------------------------------

def _visual_filter_match(match: _Match, state: KMM_State) -> bool:
    item = match.item
    if not state.include_disabled and not item.active:
        return False
    editor_filter = getattr(state, "visual_editor_filter", "ALL")
    if editor_filter != "ALL":
        if match.keymap.space_type != editor_filter:
            return False
    mode_filter = getattr(state, "visual_mode_filter", "ALL")
    if mode_filter != "ALL":
        if mode_filter not in match.keymap.name and mode_filter not in match.hierarchy_path:
            return False
    text = getattr(state, "visual_search_text", "").strip().lower()
    if text:
        haystack = " ".join((
            _operator_label(item, match.keymap),
            _operator_id_text(item),
            _format_kmi_event(item),
            _context_label(match),
            match.hierarchy_path,
        )).lower()
        if text not in haystack:
            return False
    return bool(item.type and item.type != "NONE")


def _collect_visual_matches(all_items: list[_Match], state: KMM_State) -> list[_Match]:
    key = (
        bool(state.include_disabled),
        state.visual_editor_filter,
        state.visual_mode_filter,
        state.visual_search_text,
        bpy.app.translations.locale,
    )
    now = time.monotonic()
    if _VIEW_CACHE.get("visual_key") == key:
        cached = _VIEW_CACHE["visual_matches"]
        if now - _VIEW_CACHE["visual_check"] < _VIEW_CACHE_VISIBLE_INTERVAL:
            return cached
        _VIEW_CACHE["visual_check"] = now
        if _visible_items_signature(cached) == _VIEW_CACHE["visual_signature"]:
            return cached
    matches = [match for match in all_items if _visual_filter_match(match, state)]
    _apply_conflict_status(matches, all_items)
    matches.sort(key=lambda match: (_visual_key_sort_key(match.item.type), _format_kmi_event(match.item), match.hierarchy_order, match.index))
    _VIEW_CACHE["visual_key"] = key
    _VIEW_CACHE["visual_matches"] = matches
    _VIEW_CACHE["visual_signature"] = _visible_items_signature(matches)
    _VIEW_CACHE["visual_check"] = now
    return matches


def _visual_key_sort_key(event_type: str) -> tuple:
    fake_spec = None
    for spec in _all_key_specs():
        if spec.event_type == event_type:
            fake_spec = spec
            break
    if fake_spec is not None:
        return _unused_sort_key(_unused_base_key_label(fake_spec), tuple(), fake_spec)
    if event_type in _ALPHA_TYPES:
        return (0, event_type, 0, tuple(), event_type)
    if event_type in _NUMBER_TYPES:
        return (1, event_type, 0, tuple(), event_type)
    if event_type.startswith("F") and event_type[1:].isdigit():
        return (2, event_type[1:].zfill(3), 0, tuple(), event_type)
    if event_type in _SYMBOL_TYPES:
        return (3, event_type, 0, tuple(), event_type)
    return (4, event_type, 0, tuple(), event_type)


def _visual_key_label(event_type: str) -> str:
    for spec in _all_key_specs():
        if spec.event_type == event_type:
            return _unused_base_key_label(spec)
    return _enum_display_name(bpy.types.KeyMapItem, "type", event_type)


def _draw_visual_overview(layout, state: KMM_State, all_items: list[_Match]) -> list[_Match]:
    visual_matches = _collect_visual_matches(all_items, state)
    layout.label(text=f"{_tr('Keymap Visual Overview')} / {_tr('Matches: {count}').format(count=len(visual_matches))}", translate=False)
    if not visual_matches:
        layout.label(text=_tr("No keymap binding for the filters."), translate=False)
        return visual_matches

    grouped: dict[str, list[_Match]] = {}
    for match in visual_matches:
        grouped.setdefault(match.item.type, []).append(match)

    expanded = _expanded_visual_key_groups(state)
    for event_type in sorted(grouped, key=_visual_key_sort_key):
        rows = grouped[event_type]
        active_count = sum(1 for row in rows if row.item.active)
        inactive_count = len(rows) - active_count
        box = layout.box()
        header, body = _open_close_panel(box, "visual", event_type, expanded)
        _label_no_translate(
            header,
            f"{_tr('Base Key')}: {_visual_key_label(event_type)} / "
            f"{_tr('Active Bindings')}: {active_count} / {_tr('Inactive Bindings')}: {inactive_count}",
            icon="EVENT_K",
        )
        if body is None:
            continue
        for match in rows:
            row = body.row(align=True)
            row.label(text=_duplicate_label(match), icon=_duplicate_icon(match), translate=False)
            _label_no_translate(row, _format_kmi_event(match.item))
            row.label(text=_operator_label(match.item, match.keymap), translate=False)
            row.label(text=_keymap_location_label(match), translate=False)
    return visual_matches


def _jsonable_value(value):
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, (set, frozenset)):
        return sorted(str(item) for item in value)
    if isinstance(value, bpy.types.bpy_struct):
        return _rna_properties_dict(value)
    try:
        return [_jsonable_value(item) for item in value]
    except TypeError:
        return str(value)


def _rna_properties_dict(struct) -> dict:
    # 設定された値だけを持つ。未設定の値まで設定すると、シーンの設定に従う機能の動きが変わる
    result = {}
    for prop in struct.bl_rna.properties:
        name = prop.identifier
        if name == "rna_type":
            continue
        try:
            if not struct.is_property_set(name):
                continue
            value = _jsonable_value(getattr(struct, name))
        except Exception:
            continue
        if value == {} or value == []:
            continue
        result[name] = value
    return result


def _kmi_properties_dict(item) -> dict:
    try:
        return _rna_properties_dict(item.properties)
    except Exception:
        return {}


def _serialized_item_dict(item) -> dict:
    return {
        "idname": getattr(item, "idname", ""),
        "propvalue": getattr(item, "propvalue", ""),
        "type": item.type,
        "value": item.value,
        "direction": item.direction,
        "any": bool(getattr(item, "any", False)),
        "ctrl": int(item.ctrl),
        "shift": int(item.shift),
        "alt": int(item.alt),
        "oskey": int(item.oskey),
        "hyper": int(getattr(item, "hyper", 0)),
        "key_modifier": item.key_modifier,
        "active": bool(item.active),
        "repeat": bool(getattr(item, "repeat", False)),
        "properties": _kmi_properties_dict(item),
    }


def _kmi_modified_from_default(context, keymap, item) -> bool:
    try:
        keyconfigs = context.window_manager.keyconfigs
        if not keyconfigs.default:
            return True
        for config in (keyconfigs.default, keyconfigs.addon):
            for base_keymap in config.keymaps if config else ():
                if not (
                    base_keymap.name == keymap.name
                    and base_keymap.space_type == keymap.space_type
                    and base_keymap.region_type == keymap.region_type
                    and base_keymap.is_modal == keymap.is_modal
                ):
                    continue
                for base_item in base_keymap.keymap_items:
                    if (
                        _operator_id_text(base_item) == _operator_id_text(item)
                        and _same_event_signature(base_item, item)
                        and base_item.active == item.active
                        and bool(getattr(base_item, "repeat", False)) == bool(getattr(item, "repeat", False))
                        and _kmi_properties_dict(base_item) == _kmi_properties_dict(item)
                    ):
                        return False
        return True
    except Exception:
        return True


def _generate_keymap_json_data(context, scope: str = "MODIFIED") -> dict:
    keymaps = []
    keyconfigs = context.window_manager.keyconfigs
    addon_name = keyconfigs.addon.name if keyconfigs.addon and _keyconfig_total_items(keyconfigs.user) > 16 else None
    for keyconfig_name, keymap in _editable_keymaps(context):
        if keyconfig_name == addon_name:
            continue
        items = []
        for item in keymap.keymap_items:
            if scope == "MODIFIED" and not _kmi_modified_from_default(context, keymap, item):
                continue
            items.append(_serialized_item_dict(item))
        if items:
            keymaps.append({
                "keyconfig": keyconfig_name,
                "name": keymap.name,
                "space_type": keymap.space_type,
                "region_type": keymap.region_type,
                "is_modal": bool(keymap.is_modal),
                "items": items,
            })
    return {
        "schema": "JELararagi.KeymapManager.KeymapData",
        "version": 1,
        "created": time.strftime("%Y-%m-%d %H:%M:%S"),
        "keymaps": keymaps,
    }


def _default_export_path() -> str:
    directory = _keymap_manager_user_config_dir("keymap_manager_exports")
    return os.path.join(directory, f"keymap_export_{time.strftime('%Y%m%d_%H%M%S')}.json")


def _write_keymap_json(filepath: str, data: dict) -> str:
    path = bpy.path.abspath(filepath) if filepath else _default_export_path()
    directory = os.path.dirname(path)
    if directory:
        os.makedirs(directory, exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
    return path


def _read_keymap_json(filepath: str) -> dict:
    path = bpy.path.abspath(filepath)
    with open(path, "r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict) or not isinstance(data.get("keymaps"), list):
        raise ValueError("no keymap data")
    for keymap_data in data["keymaps"]:
        if not isinstance(keymap_data, dict) or not isinstance(keymap_data.get("items", []), list):
            raise ValueError("no keymap data")
        if not all(isinstance(item_data, dict) for item_data in keymap_data.get("items", [])):
            raise ValueError("no keymap data")
    return data


def _find_or_create_user_keymap(context, name: str, space_type: str, region_type: str, is_modal: bool):
    keyconfig = context.window_manager.keyconfigs.user
    for keymap in keyconfig.keymaps:
        if _keymap_matches_ref(keymap, name, space_type, region_type, is_modal):
            return keymap
    return keyconfig.keymaps.new(name=name, space_type=space_type, region_type=region_type, modal=is_modal)


def _apply_rna_values(struct, values: dict) -> bool:
    complete = True
    for name, value in values.items():
        try:
            prop = struct.bl_rna.properties[name]
            if prop.type == "POINTER":
                complete = _apply_rna_values(getattr(struct, name), value) and complete
            elif prop.type == "COLLECTION":
                collection = getattr(struct, name)
                for element in value:
                    complete = _apply_rna_values(collection.add(), element) and complete
            elif prop.type == "ENUM" and prop.is_enum_flag:
                setattr(struct, name, set(value))
            else:
                setattr(struct, name, value)
        except (AttributeError, KeyError, RuntimeError, TypeError, ValueError):
            complete = False
    return complete


def _apply_serialized_item(keymap, item_data: dict) -> tuple[bool, bool]:
    """(足せたか, 設定まで全部戻せたか) を返す。"""
    event_type = item_data.get("type")
    value = item_data.get("value") or "PRESS"
    if not event_type:
        return False, False
    try:
        arguments = {
            "any": bool(item_data.get("any", False)),
            "ctrl": int(item_data.get("ctrl", 0)),
            "shift": int(item_data.get("shift", 0)),
            "alt": int(item_data.get("alt", 0)),
            "oskey": int(item_data.get("oskey", 0)),
            "hyper": int(item_data.get("hyper", 0)),
            "key_modifier": item_data.get("key_modifier", "NONE"),
            "direction": item_data.get("direction", "ANY"),
            "repeat": bool(item_data.get("repeat", False)),
        }
        if keymap.is_modal:
            propvalue = item_data.get("propvalue") or ""
            if not propvalue:
                return False, False
            item = keymap.keymap_items.new_modal(propvalue, event_type, value, **arguments)
        else:
            idname = item_data.get("idname") or ""
            if not idname:
                return False, False
            item = keymap.keymap_items.new(idname, event_type, value, **arguments)
        item.active = bool(item_data.get("active", True))
    except Exception:
        return False, False
    properties = item_data.get("properties")
    if not isinstance(properties, dict) or not properties:
        return True, True
    try:
        return True, _apply_rna_values(item.properties, properties)
    except Exception:
        return True, False


def _restore_addon_active(context, keymap, item_data: dict) -> None:
    """Restore the exact source binding as well as its saved user copy."""
    addon = context.window_manager.keyconfigs.addon
    if addon is None:
        return
    expected = dict(item_data)
    enabled = bool(expected.pop("active", True))
    for source in addon.keymaps:
        if (source.name, source.space_type, source.region_type, source.is_modal) != (
            keymap.name, keymap.space_type, keymap.region_type, keymap.is_modal
        ):
            continue
        for item in source.keymap_items:
            actual = _serialized_item_dict(item)
            actual.pop("active", None)
            if actual == expected:
                item.active = enabled


def _apply_keymap_json_data(context, data: dict) -> tuple[int, int]:
    """(足した件数, 全部または一部を読み込めなかった件数) を返す。"""
    count = 0
    skipped = 0
    for keymap_data in data.get("keymaps", []):
        items = keymap_data.get("items", [])
        try:
            keymap = _find_or_create_user_keymap(
                context,
                keymap_data.get("name", "Window"),
                keymap_data.get("space_type", "EMPTY"),
                keymap_data.get("region_type", "WINDOW"),
                bool(keymap_data.get("is_modal", False)),
            )
        except (TypeError, ValueError, RuntimeError):
            skipped += len(items)
            continue
        for item_data in items:
            added, complete = _apply_serialized_item(keymap, item_data)
            if added:
                count += 1
            if added and complete:
                _restore_addon_active(context, keymap, item_data)
            if not (added and complete):
                skipped += 1
    _invalidate_view_cache()
    return count, skipped


def _keymap_presets_dir() -> str:
    return _keymap_manager_user_config_dir("keymap_manager_presets")


def _list_keymap_presets() -> list[str]:
    directory = _keymap_presets_dir()
    names = []
    try:
        for filename in sorted(os.listdir(directory)):
            if filename.endswith(".json"):
                names.append(os.path.splitext(filename)[0])
    except Exception:
        pass
    return names


def _preset_filepath(name: str) -> str:
    # Preserve readable Unicode preset names in the dropdown and on disk.
    # Only characters that are invalid or dangerous for Windows paths are replaced.
    safe = re.sub(r'[\\/:*?"<>|]+', "_", name.strip())
    safe = safe.strip().strip(".")
    if not safe:
        safe = "preset"
    return os.path.join(_keymap_presets_dir(), safe + ".json")




def _safe_error_message(exc: Exception) -> str:
    text = f"{type(exc).__name__}: {exc}"
    return text.replace("\n", " ").strip()


def _draw_panel_recovery_box(layout) -> None:
    box = layout.box()
    box.label(text=_tr("Display recovery"), icon="ERROR", translate=False)
    box.label(text=_tr("Recovered from a display error."), translate=False)
    try:
        box.operator(KMM_OT_refresh.bl_idname, text=_tr("Refresh"), translate=False)
    except Exception:
        pass


def _safe_get_keymap_view(context, state: KMM_State) -> tuple[list[_Match], list[_Match], list[_Match], str]:
    try:
        all_items, operator_assignments, matches = _get_cached_keymap_view(context, state)
        return all_items, operator_assignments, matches, ""
    except Exception as exc:
        first_error = _safe_error_message(exc)
        _invalidate_view_cache()

    try:
        all_items, operator_assignments, matches = _get_cached_keymap_view(context, state)
        return all_items, operator_assignments, matches, first_error
    except Exception as exc:
        _invalidate_view_cache()
        return [], [], [], first_error or _safe_error_message(exc)


def _safe_draw_keyboard(layout, state: KMM_State, operator_assignments: list[_Match]) -> str:
    try:
        _draw_keyboard(layout, state, operator_assignments, enabled=(state.view_mode != "UNUSED"))
        return ""
    except Exception as exc:
        error = _safe_error_message(exc)
        _invalidate_view_cache()
        box = layout.box()
        _label_no_translate(box, _tr("Keyboard Layout"))
        box.label(text=_tr("Keyboard Layout could not be drawn."), icon="ERROR", translate=False)
        box.operator(KMM_OT_refresh.bl_idname, text=_tr("Refresh"), translate=False)
        return error


def _safe_draw_keymap_item(layout, state: KMM_State, match: _Match, matches: list[_Match]) -> str:
    try:
        _draw_keymap_item(layout, state, match, matches)
        return ""
    except Exception as exc:
        error = _safe_error_message(exc)
        box = layout.box()
        box.label(text=_tr("This section could not be drawn."), icon="ERROR", translate=False)
        try:
            box.label(text=_parent_child_label(match), translate=False)
        except Exception:
            pass
        return error


def _safe_draw_unused_view(layout, state: KMM_State, all_items: list[_Match]) -> str:
    try:
        _draw_unused_view(layout, state, all_items)
        return ""
    except Exception as exc:
        error = _safe_error_message(exc)
        _invalidate_view_cache()
        box = layout.box()
        box.label(text=_tr("This section could not be drawn."), icon="ERROR", translate=False)
        box.operator(KMM_OT_refresh.bl_idname, text=_tr("Refresh"), translate=False)
        return error


class KMM_PT_manager(Panel):
    bl_label = "Keymap Manager"
    bl_space_type = "PREFERENCES"
    bl_region_type = "WINDOW"
    bl_context = "keymap"
    bl_parent_id = "USERPREF_PT_keymap"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        try:
            if context.area is None or context.area.type != "PREFERENCES":
                return False
            if getattr(context, "space_data", None) is None or context.space_data.type != "PREFERENCES":
                return False
            wm = getattr(context, "window_manager", None)
            return wm is not None
        except Exception:
            return False

    def draw_header_preset(self, _context):
        _draw_help_button(self.layout, "overview")

    def draw(self, context):
        layout = self.layout

        state = getattr(context.window_manager, "keymap_manager_state", None)
        if state is None:
            _draw_panel_recovery_box(layout)
            return

        all_items, operator_assignments, matches, cache_error = _safe_get_keymap_view(context, state)

        draw_errors = []
        keyboard_assignments = operator_assignments
        if state.view_mode == "VISUAL":
            try:
                keyboard_assignments = _collect_visual_matches(all_items, state)
            except Exception as exc:
                keyboard_assignments = []
                draw_errors.append(_safe_error_message(exc))
        keyboard_error = _safe_draw_keyboard(layout, state, keyboard_assignments)
        if keyboard_error:
            draw_errors.append(keyboard_error)

        total_items = len(all_items)
        if total_items <= 16:
            warning = layout.box()
            warning.label(text=_tr("Keymaps are not loaded."), translate=False)
            warning.operator(KMM_OT_load_blender_keymap_preset.bl_idname, text=_tr("Load Blender Keymap Preset"), translate=False)

        key_section = _draw_collapsible_section(
            layout,
            state,
            "key_filter",
            _tr("Key: {event}").format(event=_format_selected_event(state)),
            icon="VIEWZOOM",
        )
        if key_section:
            try:
                event_row = key_section.row(align=True)
                event_row.prop(state, "selected_type", text=_tr("Key"), translate=False)
                event_row.prop(state, "selected_value", text=_tr("Input State"), translate=False)
                event_row = key_section.row(align=True)
                event_row.prop(state, "selected_key_modifier", text="Key Modifier", translate=False)
                event_row.prop(state, "operator_id_query", text=_tr("Operator ID"), translate=False)

                if state.view_mode == "NORMAL" and not _operator_query(state):
                    key_section.label(text=_tr("Current selection: {event}").format(event=_format_selected_event(state)), translate=False)

                top_buttons = key_section.row(align=True)
                top_buttons.prop(state, "use_exact_value", text=_tr("Exact Value"), toggle=True, translate=False)
                top_buttons.prop(state, "include_disabled", text=_tr("Include Disabled"), toggle=True, translate=False)
                top_buttons.operator(KMM_OT_refresh.bl_idname, text=_tr("Refresh"), translate=False)

                bottom_buttons = key_section.row(align=True)
                bottom_buttons.operator(KMM_OT_toggle_visual_view.bl_idname, text=_tr("Show Visual Overview"), depress=(state.view_mode == "VISUAL"), translate=False)
                bottom_buttons.operator(KMM_OT_toggle_conflict_view.bl_idname, text=_tr("Show Conflicting Keymaps"), depress=(state.view_mode == "CONFLICTS"), translate=False)
                bottom_buttons = key_section.row(align=True)
                bottom_buttons.operator(KMM_OT_toggle_unused_view.bl_idname, text=_tr("Show Unused Keymaps"), depress=(state.view_mode == "UNUSED"), translate=False)
                bottom_buttons.operator(KMM_OT_consolidate_duplicate_keymaps.bl_idname, text=_tr("Consolidate Duplicate Keymaps"), translate=False)

                visual_box = key_section.box()
                visual_box.label(text=_tr("Visualization Filters"), translate=False)
                filter_row = visual_box.row(align=True)
                filter_row.prop(state, "visual_editor_filter", text=_tr("Editor Filter"), translate=False)
                filter_row.prop(state, "visual_mode_filter", text=_tr("Mode Filter"), translate=False)
                filter_row = visual_box.row(align=True)
                filter_row.prop(state, "visual_search_text", text=_tr("Search Filter"), translate=False)
                filter_row.operator(KMM_OT_clear_visual_filters.bl_idname, text=_tr("Clear Visual Filters"), translate=False)
            except Exception as exc:
                draw_errors.append(_safe_error_message(exc))
                _draw_panel_recovery_box(layout)

        io_section = _draw_collapsible_section(
            layout,
            state,
            "io",
            _tr("Keymap Import / Export / Presets"),
            icon="PRESET",
        )
        if io_section:
            try:
                export_row = io_section.row(align=True)
                export_row.prop(state, "export_path", text=_tr("Export Path"), translate=False)
                export_row = io_section.row(align=True)
                export_row.prop(state, "export_scope", text=_tr("Export Scope"), translate=False)
                export_row.operator(KMM_OT_export_keymap.bl_idname, text=_tr("Export Keymap"), translate=False)
                import_row = io_section.row(align=True)
                import_row.prop(state, "import_path", text=_tr("Import Path"), translate=False)
                import_row.operator(KMM_OT_import_keymap.bl_idname, text=_tr("Import Keymap"), translate=False)
                preset_row = io_section.row(align=True)
                preset_row.prop(state, "preset_name", text=_tr("Preset Name"), translate=False)
                preset_row.operator(KMM_OT_save_keymap_preset.bl_idname, text=_tr("Save Preset"), translate=False)
                preset_row = io_section.row(align=True)
                preset_row.prop(state, "preset_select", text=_tr("Preset"), translate=False)
                preset_row.operator(KMM_OT_load_keymap_preset.bl_idname, text=_tr("Load Preset"), translate=False)
                preset_row.operator(KMM_OT_delete_keymap_preset.bl_idname, text=_tr("Delete Preset"), translate=False)
            except Exception as exc:
                draw_errors.append(_safe_error_message(exc))
                _draw_panel_recovery_box(layout)

        if cache_error:
            draw_errors.append(cache_error)
            _draw_panel_recovery_box(layout)

        result_title = _tr("Registered Keymap Items")
        if state.view_mode not in {"UNUSED", "VISUAL"}:
            result_title = f"{result_title} / {_tr('Matches: {count}').format(count=len(matches))}"
        results = _draw_collapsible_section(
            layout,
            state,
            "registered",
            result_title,
            icon="EVENT_K",
        )
        if not results:
            return

        if cache_error and not all_items:
            results.label(text=_tr("Keymap data unavailable. Refresh."), icon="ERROR", translate=False)
            results.operator(KMM_OT_refresh.bl_idname, text=_tr("Refresh"), translate=False)
            return

        if state.view_mode == "UNUSED":
            error = _safe_draw_unused_view(results, state, all_items)
            if error:
                draw_errors.append(error)
                _draw_panel_recovery_box(layout)
            return

        if state.view_mode == "VISUAL":
            try:
                _draw_visual_overview(results, state, all_items)
            except Exception as exc:
                error = _safe_error_message(exc)
                draw_errors.append(error)
                _draw_panel_recovery_box(results)
            return

        if state.view_mode == "CONFLICTS":
            results.label(text=_tr("Conflict view is active."), translate=False)
        if not matches:
            results.label(text=_tr("No keymap item matches the filter."), translate=False)
            return

        if state.view_mode == "CONFLICTS":
            current_group = None
            group_layout = results
            for match in matches:
                try:
                    group_key = _conflict_group_key(match)
                    if group_key != current_group:
                        current_group = group_key
                        group_layout = results.box()
                        group_layout.label(text=f"{_tr('Conflict Group')}: {_conflict_group_label(match)}", icon="ERROR", translate=False)
                    error = _safe_draw_keymap_item(group_layout, state, match, matches)
                    if error:
                        draw_errors.append(error)
                except Exception as exc:
                    error = _safe_error_message(exc)
                    draw_errors.append(error)
                    _draw_panel_recovery_box(results)
        else:
            for match in matches:
                error = _safe_draw_keymap_item(results, state, match, matches)
                if error:
                    draw_errors.append(error)


_CLASSES = (
    KMM_ConsolidationPreviewRow,
    KMM_State,
    KMM_UL_consolidation_preview,
    KMM_OT_show_help,
    KMM_OT_choose_item_value,
    KMM_OT_select_key,
    KMM_OT_refresh,
    KMM_OT_toggle_visual_view,
    KMM_OT_clear_visual_filters,
    KMM_OT_toggle_conflict_view,
    KMM_OT_toggle_unused_view,
    KMM_OT_select_unused_parent,
    KMM_OT_select_unused_child,
    KMM_OT_unused_back,
    KMM_OT_consolidate_duplicate_keymaps,
    KMM_OT_activate_shadowed_keymap,
    KMM_OT_cycle_modifier,
    KMM_OT_copy_operator_id,
    KMM_OT_toggle_filter_modifier,
    KMM_OT_export_keymap,
    KMM_OT_import_keymap,
    KMM_OT_save_keymap_preset,
    KMM_OT_load_keymap_preset,
    KMM_OT_delete_keymap_preset,
    KMM_OT_load_blender_keymap_preset,
    KMM_PT_manager,
)


def register():
    bpy.app.translations.register(__name__, _TRANSLATIONS)
    for cls in _CLASSES:
        if issubclass(cls, Operator):
            cls.bl_translation_context = "KeymapManager"
        bpy.utils.register_class(cls)
    if hasattr(bpy.types.WindowManager, "keymap_manager_state"):
        del bpy.types.WindowManager.keymap_manager_state
    bpy.types.WindowManager.keymap_manager_state = PointerProperty(type=KMM_State)


def unregister():
    _invalidate_view_cache()
    _OPERATOR_ENGLISH_NAMES.clear()
    _LOCALIZED_ENUM_CACHE.clear()
    if hasattr(bpy.types.WindowManager, "keymap_manager_state"):
        del bpy.types.WindowManager.keymap_manager_state
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    try:
        bpy.app.translations.unregister(__name__)
    except RuntimeError:
        pass


if __name__ == "__main__":
    register()

