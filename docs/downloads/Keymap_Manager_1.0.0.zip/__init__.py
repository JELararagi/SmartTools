# SPDX-License-Identifier: GPL-3.0-or-later
"""Keymap Manager's integrated Blender entry point."""
from pathlib import Path
import bpy
from . import backend
from .ui import adapter_contract, blender_ui

bl_info = {
    "name": "Keymap Manager",
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "category": "Interface",
}
_runtime = None


def register():
    global _runtime
    if _runtime is not None:
        return
    config = Path(bpy.utils.user_resource("CONFIG"))
    preset_root = Path(bpy.utils.resource_path("LOCAL")) / "scripts" / "presets" / "keyconfig"
    instance = backend.create_runtime(
        bpy, adapter_contract, wm_state_name="keymap_manager_state",
        storage_root=config / "KeymapManager", allow_external_files=True,
        standard_preset_path=preset_root / "Blender.py", trusted_preset_root=preset_root,
    )
    classes = blender_ui.bind_adapter(instance.adapter)
    try:
        instance.register(classes)
    except Exception:
        try:
            instance.unregister()
        finally:
            blender_ui.release_adapter()
        raise
    _runtime = instance


def unregister():
    global _runtime
    if _runtime is None:
        return
    _runtime.unregister()
    blender_ui.release_adapter()
    _runtime = None
