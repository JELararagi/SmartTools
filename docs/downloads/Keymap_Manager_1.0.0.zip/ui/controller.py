# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Validate UI intent and route it. No shortcut calculations or data I/O."""
from types import MappingProxyType
from .adapter_contract import Snapshot, RowRef, Request, StateChange, ItemChange, Outcome
from .public_api import OPERATIONS, STATE_PROPERTIES
from .localization import LABELS

MODIFIERS = ('ctrl', 'shift', 'alt', 'oskey', 'hyper')
EDITABLE_STATE = frozenset(('selected_type', 'selected_value', 'selected_key_modifier', 'use_exact_modifiers', 'use_exact_value', 'include_disabled', 'operator_id_query', 'visual_editor_filter', 'visual_mode_filter', 'visual_search_text', 'export_path', 'import_path', 'export_scope', 'preset_name', 'preset_select') + tuple('selected_' + m for m in MODIFIERS))
DEFAULT_OPEN = frozenset(('section_keyboard', 'section_filter', 'section_registered'))

class UIError(Exception):
    def __init__(self, key):
        super().__init__(key)
        self.key = key

    def localized(self, language):
        return LABELS[self.key].in_language(language)

def normalize(operation_id, supplied):
    if operation_id not in OPERATIONS or not isinstance(supplied, dict):
        raise UIError('invalid')
    properties = OPERATIONS[operation_id]['properties']
    if set(supplied) - {p['identifier'] for p in properties}:
        raise UIError('invalid')
    result = {}
    for p in properties:
        name = p['identifier']
        value = supplied.get(name, p.get('default'))
        expected = {'StringProperty': str, 'EnumProperty': str, 'BoolProperty': bool, 'IntProperty': int}[p['type']]
        if type(value) is not expected:
            raise UIError('invalid')
        result[name] = value
    return result

class Controller:
    def __init__(self, adapter):
        self.adapter = adapter
        self._folds = {}

    def language(self, context):
        return 'ja' if self.adapter.language(context) == 'ja' else 'en'

    def snapshot(self, context):
        try:
            snapshot = self.adapter.snapshot(context)
        except Exception as exc:
            raise UIError('adapter_error') from exc
        if not isinstance(snapshot, Snapshot) or not isinstance(snapshot.revision, str) or not snapshot.revision:
            raise UIError('snapshot_error')
        if snapshot.view_mode not in ('NORMAL', 'CONFLICT', 'UNUSED', 'VISUAL'):
            raise UIError('snapshot_error')
        if type(snapshot.match_count) is not int or snapshot.match_count < 0:
            raise UIError('snapshot_error')
        if len({r.ref for r in snapshot.rows}) != len(snapshot.rows):
            raise UIError('snapshot_error')
        if len({f.name for f in snapshot.fields}) != len(snapshot.fields):
            raise UIError('snapshot_error')
        return snapshot

    @staticmethod
    def row(snapshot, ref, writable=False):
        rows = [row for row in snapshot.rows if row.ref == ref]
        if len(rows) != 1:
            raise UIError('missing')
        if writable and not rows[0].editable:
            raise UIError('state_error')
        return rows[0]

    @staticmethod
    def field(snapshot, name, row=None):
        fields = [f for f in (snapshot.fields if row is None else row.fields) if f.name == name]
        if len(fields) != 1 or not fields[0].enabled:
            raise UIError('state_error')
        return fields[0]

    @staticmethod
    def validate_value(field, value):
        if field.kind == 'BOOL':
            valid = type(value) is bool
        elif field.kind == 'TEXT':
            valid = type(value) is str
        elif field.kind == 'ENUM':
            valid = type(value) is str and value in {c.key for c in field.choices}
        else:
            valid = False
        if not valid:
            raise UIError('invalid')

    @staticmethod
    def require_revision(snapshot, expected):
        if expected is not None and snapshot.revision != expected:
            raise UIError('stale')

    @staticmethod
    def preview_valid(snapshot):
        preview = snapshot.preview
        if preview is None or not preview.token or preview.revision != snapshot.revision:
            return False
        if type(preview.delete_count) is not int or preview.delete_count < 1 or not preview.groups:
            return False
        all_refs = {r.ref for r in snapshot.rows}
        keep = [ref for g in preview.groups for ref in g.keep]
        remove = [ref for g in preview.groups for ref in g.remove]
        return bool(keep and remove and set(keep + remove) <= all_refs and not set(keep).intersection(remove) and len(set(remove)) == len(remove))

    def prepare(self, context, operation_id, supplied, expected_revision=None, phase='execute', preview_token=''):
        args = normalize(operation_id, supplied)
        snapshot = self.snapshot(context)
        self.require_revision(snapshot, expected_revision)
        short = operation_id.rsplit('.', 1)[-1]
        if short == 'consolidate_duplicate_keymaps':
            if phase not in ('preview', 'commit', 'cancel'):
                raise UIError('no_preview')
            if phase in ('commit', 'cancel'):
                if not self.preview_valid(snapshot) or snapshot.preview.token != preview_token:
                    raise UIError('no_preview')
        elif phase != 'execute' or preview_token:
            raise UIError('invalid')
        if short in ('choose_item_value', 'cycle_modifier', 'activate_shadowed_keymap'):
            prefix = 'target_' if short == 'activate_shadowed_keymap' else ''
            try:
                ref = RowRef.from_arguments(args, prefix)
            except (KeyError, TypeError, ValueError) as exc:
                raise UIError('missing') from exc
            row = self.row(snapshot, ref, writable=True)
            if short == 'choose_item_value':
                field = self.field(snapshot, args['prop_name'], row)
                if field.kind != 'ENUM':
                    raise UIError('invalid')
                self.validate_value(field, args['choice'])
            elif short == 'cycle_modifier':
                if args['modifier'] not in MODIFIERS or args['modifier'] not in dict(row.modifiers):
                    raise UIError('invalid')
            else:
                if row.status != 'SHADOWED' or not row.higher_sources:
                    raise UIError('state_error')
                for source in row.higher_sources:
                    if not self.row(snapshot, source, writable=True).active:
                        raise UIError('stale')
        elif short == 'select_key':
            choices = [e for e in snapshot.events if e.token == args['event_type'] and e.enabled and (e.kind == 'mouse') == args['is_mouse_operation']]
            if snapshot.view_mode == 'UNUSED' or not args['event_type'] or not choices:
                raise UIError('invalid')
        elif short == 'toggle_filter_modifier':
            if args['modifier'] not in MODIFIERS or snapshot.view_mode == 'UNUSED':
                raise UIError('invalid')
            field = self.field(snapshot, 'selected_' + args['modifier'])
            self.validate_value(field, True)
        elif short == 'select_unused_parent':
            if snapshot.view_mode != 'UNUSED' or args['parent_key'] not in {c.key for c in snapshot.categories}:
                raise UIError('invalid')
        elif short == 'select_unused_child':
            parents = [c for c in snapshot.categories if c.key == args['parent_key']]
            if snapshot.view_mode != 'UNUSED' or len(parents) != 1 or args['child_key'] not in {c.key for c in parents[0].children}:
                raise UIError('invalid')
        elif short == 'unused_back':
            if snapshot.view_mode != 'UNUSED' or not snapshot.can_back:
                raise UIError('invalid')
        elif short == 'show_help':
            if args['topic'] not in {'overview', *dict(snapshot.help_topics).values()}:
                raise UIError('invalid')
        elif short == 'copy_operator_id':
            if not args['operator_id'] or not any(r.operator_id == args['operator_id'] and not r.ref.is_modal for r in snapshot.rows):
                raise UIError('missing')
        elif short in ('load_keymap_preset', 'delete_keymap_preset'):
            field = self.field(snapshot, 'preset_select')
            self.validate_value(field, field.value)
            if not field.value:
                raise UIError('invalid')
        elif short == 'save_keymap_preset':
            field = self.field(snapshot, 'preset_name')
            if field.kind != 'TEXT' or not isinstance(field.value, str) or not field.value.strip():
                raise UIError('invalid')
        elif short == 'import_keymap':
            field = self.field(snapshot, 'import_path')
            if field.kind != 'TEXT' or not isinstance(field.value, str) or not field.value.strip():
                raise UIError('invalid')
        elif short == 'export_keymap':
            field = self.field(snapshot, 'export_scope')
            self.validate_value(field, field.value)
            if field.value not in ('ALL', 'MODIFIED'):
                raise UIError('invalid')
        elif short == 'load_blender_keymap_preset' and not snapshot.needs_initial_keymap:
            raise UIError('state_error')
        return Request(operation_id, MappingProxyType(args), snapshot.revision, phase, preview_token)

    def call(self, context, operation_id, supplied, expected_revision=None, phase='execute', preview_token=''):
        # Build a fresh snapshot on the first user action when the panel has no session yet.
        if operation_id != 'keymap_manager.refresh' and expected_revision in (None, 'initial-refresh'):
            current = self.snapshot(context)
            if current.revision == 'initial-refresh':
                refresh = self.prepare(context, 'keymap_manager.refresh', {}, current.revision)
                result = self.check_outcome(self.adapter.dispatch(context, refresh))
                if result.status not in ('OK', 'NO_CHANGE'):
                    return result
                expected_revision = self.snapshot(context).revision
        request = self.prepare(context, operation_id, supplied, expected_revision, phase, preview_token)
        outcome = self.adapter.dispatch(context, request)
        return self.check_outcome(outcome)

    @staticmethod
    def check_outcome(outcome):
        if not isinstance(outcome, Outcome) or outcome.status not in ('OK', 'NO_CHANGE', 'CANCELLED', 'ERROR', 'STALE'):
            raise UIError('response_error')
        return outcome

    def edit_state(self, context, name, value, expected_revision):
        snapshot = self.snapshot(context)
        self.require_revision(snapshot, expected_revision)
        if name not in EDITABLE_STATE or name not in STATE_PROPERTIES:
            raise UIError('state_error')
        field = self.field(snapshot, name)
        self.validate_value(field, value)
        if snapshot.view_mode == 'UNUSED' and name.startswith('selected_'):
            raise UIError('state_error')
        return self.check_outcome(self.adapter.set_state(context, StateChange(name, value, snapshot.revision)))

    def edit_item(self, context, ref, name, value, expected_revision):
        snapshot = self.snapshot(context)
        self.require_revision(snapshot, expected_revision)
        row = self.row(snapshot, ref, writable=True)
        field = self.field(snapshot, name, row)
        if field.kind == 'ENUM':
            raise UIError('invalid')
        self.validate_value(field, value)
        return self.check_outcome(self.adapter.set_item(context, ItemChange(ref, name, value, snapshot.revision)))

    def can_call(self, context, operation_id, supplied, phase='execute'):
        try:
            self.prepare(context, operation_id, supplied, phase=phase)
            return True
        except UIError:
            return False

    def opened(self, context, key):
        return key in self._folds.get(self.adapter.session_key(context), DEFAULT_OPEN)

    def toggle_fold(self, context, key):
        if not isinstance(key, str) or not key:
            raise UIError('invalid')
        session = self.adapter.session_key(context)
        current = self._folds.get(session, DEFAULT_OPEN)
        self._folds[session] = current.symmetric_difference((key,))

    def clear(self):
        self._folds.clear()


def outcome_message(outcome, language, operation_id, phase='execute'):
    if outcome.status == 'STALE':
        return 'WARNING', LABELS['stale'].in_language(language)
    if outcome.status in ('ERROR', 'CANCELLED'):
        return 'WARNING', outcome.message.in_language(language) or LABELS['response_error'].in_language(language)
    if operation_id == 'keymap_manager.consolidate_duplicate_keymaps' and phase == 'commit':
        count = outcome.deleted_count
        if type(count) is not int or count < 0:
            return 'WARNING', LABELS['count_unknown'].in_language(language)
        return 'INFO', LABELS['deleted'].in_language(language).format(count=count)
    return 'INFO', outcome.message.in_language(language)

