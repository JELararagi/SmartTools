# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Draw through native UILayout; never write to a keymap or call the adapter dispatcher."""
from .controller import UIError, MODIFIERS
from .localization import LABELS, label, operation_text
from .keyboard_layout import MAIN_ROWS, NAV_ROWS, NUMPAD_ROWS, MODIFIER_SLOTS, CAPTIONS, ALL_SLOTS

PREFIX = 'keymap_manager.'

def row_key(ref):
    return 'row:' + repr(ref)

def button(layout, operation, language, args=None, text=None, enabled=True, depressed=False):
    cell = layout.row(align=True)
    cell.enabled = bool(enabled)
    cell.operator_context = 'INVOKE_DEFAULT'
    target = PREFIX + operation
    props = cell.operator(target, text=operation_text(target, language) if text is None else text, translate=False, depress=bool(depressed))
    for name, value in (args or {}).items():
        setattr(props, name, value)
    return props

def fold(layout, controller, context, key, title):
    opened = controller.opened(context, key)
    props = layout.operator('keymap_manager_ui.toggle_fold', text=title, translate=False, icon='TRIA_DOWN' if opened else 'TRIA_RIGHT', emboss=False)
    props.key = key
    return opened

def section(layout, controller, context, snapshot, key, language):
    box = layout.box()
    header = box.row(align=True)
    opened = fold(header, controller, context, 'section_' + key, label(key, language))
    topic = dict(snapshot.help_topics).get(key, 'overview')
    button(header, 'show_help', language, {'topic': topic})
    return box.column(align=True) if opened else None

def field_value(field, language):
    if field.kind == 'BOOL':
        return label('enabled' if field.value else 'disabled', language)
    if field.kind == 'ENUM':
        return next((c.label.in_language(language) for c in field.choices if c.key == field.value), label('unavailable', language))
    return str(field.value)

def draw_field(layout, field, language, ref=None, writable=True):
    cell = layout.row(align=True)
    valid_enum = field.kind != 'ENUM' or any(c.key == field.value for c in field.choices)
    cell.enabled = bool(field.enabled and writable and valid_enum)
    cell.operator_context = 'INVOKE_DEFAULT'
    title = field.label.in_language(language) + ': ' + field_value(field, language)
    if ref is not None and field.kind == 'ENUM':
        args = dict(ref.arguments(), prop_name=field.name)
        if valid_enum:
            args['choice'] = field.value
        button(cell, 'choose_item_value', language, args, title, enabled=cell.enabled)
        return
    op_id = 'keymap_manager_ui.edit_state' if ref is None else 'keymap_manager_ui.edit_item'
    props = cell.operator(op_id, text=title, translate=False, depress=field.kind == 'BOOL' and bool(field.value))
    props.field_name = field.name
    if ref is not None:
        for name, value in ref.arguments().items():
            setattr(props, name, value)

def draw_keyboard(layout, controller, context, snapshot, language):
    events = {e.slot: e for e in snapshot.events if e.kind == 'keyboard'}
    fields = {f.name: f for f in snapshot.fields}
    allowed = snapshot.view_mode != 'UNUSED'
    columns = layout.row(align=True)
    for rows in (MAIN_ROWS, NAV_ROWS, NUMPAD_ROWS):
        column = columns.column(align=True)
        for slots in rows:
            row = column.row(align=True)
            for slot in slots:
                if not slot:
                    row.separator()
                    continue
                cell = row.row(align=True)
                if slot == 'Space':
                    cell.scale_x = 3.5
                elif slot in ('Backspace', 'Tab', 'CapsLock', 'Enter', 'ShiftLeft', 'ShiftRight'):
                    cell.scale_x = 1.4
                if slot in MODIFIER_SLOTS:
                    modifier = MODIFIER_SLOTS[slot]
                    field = fields.get('selected_' + modifier)
                    button(cell, 'toggle_filter_modifier', language, {'modifier': modifier}, label(modifier, language), enabled=allowed and field is not None and field.enabled, depressed=field is not None and bool(field.value))
                else:
                    event = events.get(slot)
                    args = {'event_type': event.token if event else '', 'label': event.label.in_language(language) if event else CAPTIONS.get(slot, slot), 'is_mouse_operation': False}
                    button(cell, 'select_key', language, args, args['label'], enabled=allowed and event is not None and event.enabled, depressed=event is not None and event.selected)
    extra = tuple(e for e in snapshot.events if e.kind == 'keyboard' and e.slot not in ALL_SLOTS)
    draw_events(layout, extra, snapshot, language)
    if 'selected_hyper' in fields:
        button(layout, 'toggle_filter_modifier', language, {'modifier': 'hyper'}, label('hyper', language), enabled=allowed and fields['selected_hyper'].enabled, depressed=bool(fields['selected_hyper'].value))

def draw_events(layout, events, snapshot, language):
    for start in range(0, len(events), 6):
        row = layout.row(align=True)
        for event in events[start:start + 6]:
            button(row, 'select_key', language, {'event_type': event.token, 'label': event.label.in_language(language), 'is_mouse_operation': event.kind == 'mouse'}, event.label.in_language(language), enabled=snapshot.view_mode != 'UNUSED' and event.enabled, depressed=event.selected)

def draw_binding(layout, controller, context, snapshot, ref, language):
    try:
        item = controller.row(snapshot, ref)
    except UIError:
        layout.label(text=label('missing', language), translate=False)
        return
    box = layout.box()
    header = box.row(align=True)
    title = item.registration.in_language(language) + ' → ' + item.label.in_language(language)
    opened = fold(header, controller, context, row_key(ref), title)
    header.label(text=label(item.status if item.status in LABELS else 'unavailable', language), translate=False)
    if not opened:
        return
    box.label(text=item.shortcut.in_language(language), translate=False)
    for detail in item.details:
        box.label(text=detail.in_language(language), translate=False)
    if not ref.is_modal and item.operator_id:
        button(box, 'copy_operator_id', language, {'operator_id': item.operator_id}, item.operator_id)
    if item.higher_sources:
        box.label(text=label('higher', language), translate=False)
        valid = item.editable and item.status == 'SHADOWED'
        for higher_ref in item.higher_sources:
            try:
                higher = controller.row(snapshot, higher_ref)
                box.label(text=higher.registration.in_language(language) + ' → ' + higher.label.in_language(language), translate=False)
                valid = valid and higher.editable and higher.active
            except UIError:
                box.label(text=label('missing', language), translate=False)
                valid = False
        button(box, 'activate_shadowed_keymap', language, ref.arguments('target_'), enabled=valid)
    for field in item.fields:
        draw_field(box, field, language, ref, item.editable)
    modifiers = box.row(align=True)
    for name, value in item.modifiers:
        if name in MODIFIERS:
            title = label(name, language) + ': ' + label(value if value in ('OFF', 'ON', 'ANY') else 'unavailable', language)
            button(modifiers, 'cycle_modifier', language, dict(ref.arguments(), modifier=name), title, enabled=item.editable, depressed=value == 'ON')

def draw_unused(layout, controller, context, snapshot, language):
    layout.label(text=label('unused_scope', language), translate=False)
    button(layout, 'unused_back', language, enabled=snapshot.can_back)
    layout.label(text=label('parent', language), translate=False)
    for category in snapshot.categories:
        button(layout, 'select_unused_parent', language, {'parent_key': category.key}, category.label.in_language(language), depressed=category.key == snapshot.selected_parent)
        if category.key == snapshot.selected_parent and category.children:
            child_box = layout.box()
            child_box.label(text=label('child', language), translate=False)
            for child in category.children:
                button(child_box, 'select_unused_child', language, {'parent_key': category.key, 'child_key': child.key}, child.label.in_language(language), depressed=child.key == snapshot.selected_child)
    for group in snapshot.unused_groups:
        box = layout.box()
        title = group.label.in_language(language) + ' / ' + label('candidates', language, count=group.count)
        if fold(box, controller, context, 'unused:' + group.key, title):
            for candidate in group.candidates:
                box.label(text=candidate.in_language(language), translate=False)


def draw_preview(layout, controller, snapshot, language):
    layout.label(text=label('preview', language), translate=False)
    if not controller.preview_valid(snapshot):
        layout.label(text=label('no_preview', language), translate=False)
        return
    preview = snapshot.preview
    layout.label(text=label('planned', language, count=preview.delete_count), translate=False)
    for group in preview.groups:
        box = layout.box()
        box.label(text=group.label.in_language(language), translate=False)
        for role, refs in (('keep', group.keep), ('remove', group.remove)):
            for ref in refs:
                item = controller.row(snapshot, ref)
                title = label(role, language) + ': ' + item.registration.in_language(language) + ' → ' + item.label.in_language(language) + ' | ' + item.shortcut.in_language(language)
                box.label(text=title, translate=False)


def draw_panel(layout, controller, context):
    language = controller.language(context)
    try:
        snapshot = controller.snapshot(context)
    except UIError as exc:
        layout.label(text=exc.localized(language), translate=False)
        button(layout, 'refresh', language)
        return
    fields = {f.name: f for f in snapshot.fields}
    for message in snapshot.messages:
        layout.label(text=message.in_language(language), translate=False)
    if snapshot.needs_initial_keymap:
        button(layout, 'load_blender_keymap_preset', language)
    keyboard = section(layout, controller, context, snapshot, 'keyboard', language)
    if keyboard is not None:
        draw_keyboard(keyboard, controller, context, snapshot, language)
    for kind in ('mouse', 'ndof'):
        area = section(layout, controller, context, snapshot, kind, language)
        if area is not None:
            events = tuple(e for e in snapshot.events if e.kind == kind)
            if events:
                draw_events(area, events, snapshot, language)
            else:
                area.label(text=label('unavailable', language), translate=False)
    filters = section(layout, controller, context, snapshot, 'filter', language)
    if filters is not None:
        for name in ('selected_type', 'selected_value', 'selected_key_modifier', 'operator_id_query', 'use_exact_modifiers', 'use_exact_value', 'include_disabled'):
            if name in fields:
                draw_field(filters, fields[name], language, writable=not (snapshot.view_mode == 'UNUSED' and name.startswith('selected_')))
        button(filters, 'refresh', language)
        for short, mode in (('toggle_visual_view', 'VISUAL'), ('toggle_conflict_view', 'CONFLICT'), ('toggle_unused_view', 'UNUSED')):
            button(filters, short, language, depressed=snapshot.view_mode == mode)
        button(filters, 'consolidate_duplicate_keymaps', language)
        visual = filters.box()
        visual.label(text=label('visual_filters', language), translate=False)
        for name in ('visual_editor_filter', 'visual_mode_filter', 'visual_search_text'):
            if name in fields:
                draw_field(visual, fields[name], language)
        button(visual, 'clear_visual_filters', language)
    io = section(layout, controller, context, snapshot, 'io', language)
    if io is not None:
        for name in ('export_path', 'export_scope'):
            if name in fields:
                draw_field(io, fields[name], language)
        button(io, 'export_keymap', language, enabled='export_scope' in fields and fields['export_scope'].enabled)
        if 'import_path' in fields:
            draw_field(io, fields['import_path'], language)
        button(io, 'import_keymap', language, enabled='import_path' in fields and fields['import_path'].enabled and bool(str(fields['import_path'].value).strip()))
        if 'preset_name' in fields:
            draw_field(io, fields['preset_name'], language)
        button(io, 'save_keymap_preset', language, enabled='preset_name' in fields and fields['preset_name'].enabled and bool(str(fields['preset_name'].value).strip()))
        preset = fields.get('preset_select')
        if preset is not None:
            draw_field(io, preset, language)
        selected = preset is not None and preset.enabled and bool(preset.value) and any(c.key == preset.value for c in preset.choices)
        button(io, 'load_keymap_preset', language, enabled=selected)
        button(io, 'delete_keymap_preset', language, enabled=selected)
    registered = section(layout, controller, context, snapshot, 'registered', language)
    if registered is not None:
        registered.label(text=label('matches', language, count=snapshot.match_count), translate=False)
        if snapshot.view_mode == 'UNUSED':
            draw_unused(registered, controller, context, snapshot, language)
        elif snapshot.view_mode in ('VISUAL', 'CONFLICT'):
            for group in snapshot.groups:
                box = registered.box()
                opened = fold(box, controller, context, 'group:' + group.key, group.label.in_language(language))
                if snapshot.view_mode == 'VISUAL':
                    box.label(text=label('group_counts', language, active=group.active_count, disabled=group.disabled_count), translate=False)
                if opened:
                    for ref in group.rows:
                        draw_binding(box, controller, context, snapshot, ref, language)
            if not snapshot.groups:
                registered.label(text=label('empty', language), translate=False)
        else:
            if snapshot.no_selection:
                registered.label(text=label('select_first', language), translate=False)
            elif not snapshot.visible_rows:
                registered.label(text=label('empty', language), translate=False)
            for ref in snapshot.visible_rows:
                draw_binding(registered, controller, context, snapshot, ref, language)
        registered.label(text=label('status_note', language), translate=False)
    if snapshot.preview is not None:
        draw_preview(layout.box(), controller, snapshot, language)

