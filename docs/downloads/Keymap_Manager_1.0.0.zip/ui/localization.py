# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
from .adapter_contract import Text

LABELS = {
    'manager': Text('Keymap Manager', 'キーマップマネージャー'),
    'keyboard': Text('Keyboard Layout', 'キーボード配列'),
    'mouse': Text('Mouse Operations', 'マウス操作'),
    'ndof': Text('3D Mouse / NDOF', '3Dマウス/NDOF'),
    'filter': Text('Key and Filters', 'キーと絞り込み'),
    'io': Text('Keymap I/O / Presets', 'キーマップ入出力 / プリセット'),
    'registered': Text('Registered Keymap Items', '登録済みキーマップ項目'),
    'visual_filters': Text('Visual Filters', '可視化フィルター'),
    'matches': Text('Matches: {count}', '一致数: {count}'),
    'empty': Text('No matching assignments. Check the key and filters.', '一致する割り当てはありません。キーと絞り込みを確認してください。'),
    'select_first': Text('Select a key or enter an operator ID to begin.', 'キーを選ぶか、オペレーターIDを入力してください。'),
    'missing': Text('This item is no longer available. Refresh the list.', 'この項目は見つかりません。一覧を更新してください。'),
    'unavailable': Text('Not available', '利用できません'),
    'unused_scope': Text('Candidates apply only to this category. Check other categories before assigning a key.', '候補は選んだ分類内だけの結果です。使う前にほかの分類も確認してください。'),
    'parent': Text('Parent Categories', '親カテゴリー'),
    'child': Text('Subcategories', 'サブカテゴリー'),
    'candidates': Text('Unused Shortcut Candidates: {count}', '未使用ショートカット候補: {count}'),
    'group_counts': Text('Enabled: {active} / Disabled: {disabled}', '有効割り当て: {active} / 無効割り当て: {disabled}'),
    'higher': Text('Higher-priority Sources', '上位優先元'),
    'operator_id': Text('Operator ID', 'オペレーターID'),
    'preview': Text('Consolidation Preview', '集約の確認画面'),
    'planned': Text('Planned deletions: {count}', '削除予定: {count}件'),
    'keep': Text('Keep', '残す'),
    'remove': Text('Delete', '削除'),
    'confirm': Text('Consolidate', '集約'),
    'cancel': Text('Cancel', 'キャンセル'),
    'deleted': Text('Deleted {count} assignments. Check the remaining rows.', '{count}件の割り当てを削除しました。残った行を確認してください。'),
    'count_unknown': Text('The completed deletion count was not supplied. Refresh and inspect the remaining rows; do not repeat consolidation.', '実削除数を確認できません。一覧を更新して残った行を確認し、集約を繰り返さないでください。'),
    'edit': Text('Edit Value', '値を変更'),
    'fold': Text('Expand or Collapse', '開く・閉じる'),
    'value': Text('Value', '値'),
    'enabled': Text('On', '入'),
    'disabled': Text('Off', '切'),
    'OFF': Text('Off', 'オフ'),
    'ON': Text('On', 'オン'),
    'ANY': Text('Any', '任意'),
    'ACTIVE': Text('Active', '有効'),
    'SHADOWED': Text('Partially Shadowed', '一部で上位優先'),
    'PRECEDING': Text('Earlier Item Has Priority', '先行項目が優先'),
    'DUPLICATE': Text('Duplicate', '重複'),
    'DISABLED': Text('Disabled', '無効'),
    'ctrl': Text('Ctrl', 'Ctrl'), 'shift': Text('Shift', 'Shift'),
    'alt': Text('Alt', 'Alt'), 'oskey': Text('OS Key', 'OSキー'), 'hyper': Text('Hyper', 'Hyper'),
    'state_error': Text('The requested setting is unavailable. Refresh the list.', 'この設定を利用できません。一覧を更新してください。'),
    'stale': Text('The list changed while this dialog was open. Refresh and choose the item again.', '画面を開いている間に一覧が変わりました。更新して項目を選び直してください。'),
    'invalid': Text('The input is not an available choice. Review the value and try again.', '利用できる値ではありません。入力内容と選択肢を確認してください。'),
    'adapter_error': Text('The keymap data could not be obtained. Refresh the list.', 'キーマップの情報を取得できません。一覧を更新してください。'),
    'response_error': Text('The result could not be confirmed. Refresh before repeating the operation.', '結果を確認できません。同じ操作を繰り返す前に一覧を更新してください。'),
    'snapshot_error': Text('The list contains inconsistent data. Refresh before editing.', '一覧の情報に不整合があります。編集前に更新してください。'),
    'no_preview': Text('Open a current consolidation preview before confirming.', '集約する前に、現在の確認画面を開いてください。'),
    'status_note': Text('Status is an estimate. Actual behavior depends on the editor and mode.', '状況は推定です。実際の動作はエディターとモードによって変わります。'),
}

OPERATIONS = {
    'show_help': (Text('?', '？'), Text('Open the short help for this section. Read the meaning of its controls and status labels before changing assignments.', 'この部分の短いヘルプを開きます。操作する前に、ボタンの働きと状況表示の意味を確認できます。')),
    'choose_item_value': (Text('Choose Value', '値を選択'), Text('Choose an available key, input state or modal value for this exact assignment. Confirm the dialog to change it; cancel to leave it unchanged.', 'この割り当てのキー・入力状態・モーダル値などを候補から選びます。確定すると変更し、キャンセルすると元のままです。')),
    'select_key': (Text('Select Key', 'キーを選択'), Text('Select this key or device action and inspect its assignments below. This searches the keymap; it does not perform the shortcut.', 'このキーや入力機器の操作を選び、下の割り当て一覧を調べます。ショートカットそのものを実行する操作ではありません。')),
    'refresh': (Text('Refresh', '更新'), Text('Read the latest keymap information again. Use this after changing shortcuts elsewhere or if a listed item has disappeared.', '最新のキーマップ情報を読み直します。別の場所でキーを変えた後や、項目が見つからなくなった時に押してください。')),
    'toggle_conflict_view': (Text('Show Conflicting Keymaps', '競合キーマップを表示'), Text('Group assignments sharing a shortcut in the same registration location. Press again to return to the normal list; no assignments are deleted.', '同じ登録場所で同じショートカットを使う割り当てをまとめて表示します。もう一度押すと通常の一覧に戻ります。割り当ては削除しません。')),
    'toggle_unused_view': (Text('Show Unused Keymaps', '未使用キーマップを表示'), Text('Choose a category to inspect unused candidates there. Device buttons are unavailable in this view. Press again to return and check other categories.', '分類を選び、その分類で空いている候補を調べます。この表示中は入力機器のボタンを押せません。もう一度押して戻り、ほかの分類も確認してください。')),
    'select_unused_parent': (Text('Select Category', '親カテゴリーを選択'), Text('Open this registration category. Select a subcategory if several are available, then inspect the unused shortcut candidates.', 'この登録先の分類を開きます。中の分類が複数ある場合はサブカテゴリーを選び、未使用の候補を確認してください。')),
    'select_unused_child': (Text('Select Subcategory', 'サブカテゴリーを選択'), Text('Display unused candidates for this subcategory only. A candidate may still be used in another mode or editor.', 'このサブカテゴリー内だけの未使用候補を表示します。別のモードやエディターでは使われている場合があります。')),
    'unused_back': (Text('Back', '戻る'), Text('Return to the previous category view when a previous view is available. This does not change any assignments.', '戻れる分類がある時に、前の分類表示へ戻ります。割り当ては変更しません。')),
    'consolidate_duplicate_keymaps': (Text('Consolidate Duplicate Keymaps', '重複キーマップを集約'), Text('Preview assignments whose location, function, key and settings are identical. Review every Keep and Delete row before confirming. Cancel to retain all assignments.', '場所・機能・キー・設定がすべて同じ割り当ての確認画面を開きます。「残す」と「削除」を確認してから集約してください。キャンセルなら割り当てを残します。')),
    'activate_shadowed_keymap': (Text('Enable Target and Disable Higher Priority', 'このキーマップを有効化し上位優先を無効化'), Text('Enable this assignment and disable every listed higher-priority source. Those sources also stop working in their own contexts. Re-enable their Active fields to restore them.', 'この割り当てを有効にし、表示された上位優先元をすべて無効にします。無効にした項目は本来の画面でも動かなくなります。戻すには各項目の「有効」を入れてください。')),
    'cycle_modifier': (Text('Cycle Modifier', '修飾キーを切り替え'), Text('Cycle this assignment through Off, On and Any. Off requires the modifier to be released, On requires it pressed, and Any accepts either state.', 'この割り当ての条件をオフ、オン、任意の順で切り替えます。オフは押さない時、オンは押した時、任意はどちらでも一致します。')),
    'copy_operator_id': (Text('Copy Operator ID', 'オペレーターIDをコピー'), Text('Copy this function identifier so you can paste it into the Operator ID search field. The assignment itself stays unchanged.', 'この機能の内部名をコピーします。「オペレーターID」の検索欄などへ貼り付けられます。割り当て自体は変えません。')),
    'toggle_filter_modifier': (Text('Toggle Modifier Filter', '修飾キーで絞り込み'), Text('Turn this search modifier on or off to distinguish combinations such as S and Ctrl+S. Assignments with Any may match both states.', '検索する修飾キーの入・切を変え、SとCtrl+Sなどを分けて調べます。「任意」の割り当ては入・切のどちらにも一致する場合があります。')),
    'toggle_visual_view': (Text('Show Visual Overview', 'キーマップ可視化を表示'), Text('Group assigned shortcuts by their base key. Use the editor, mode and text filters to narrow the view. Press again to return to the normal list.', '割り当てを修飾キー以外の基準キーごとにまとめます。エディター・モード・文字で絞り込めます。もう一度押すと通常の一覧に戻ります。')),
    'clear_visual_filters': (Text('Clear Visual Filters', '可視化フィルターをクリア'), Text('Reset the editor, mode and text filters for the visual overview. This changes the display only, not the stored shortcuts.', '可視化のエディター・モード・文字の絞り込みを元に戻します。表示だけを変え、保存された割り当ては変更しません。')),
    'export_keymap': (Text('Export Keymap', 'キーマップをエクスポート'), Text('Write the selected export scope to JSON. Set Export Path and choose Modified Only or All Keymaps first; the completed path is shown after export.', '選んだ範囲をJSONへ書き出します。「エクスポート先」と「変更済みのみ」か「全キーマップ」を先に確認してください。完了後に保存先が表示されます。')),
    'import_keymap': (Text('Import Keymap', 'キーマップをインポート'), Text('Read the JSON selected in Import Path and add its assignments. Existing assignments are not replaced. Inspect any reported skipped items.', '「インポート元」のJSONを読み込み、割り当てを追加します。現在の割り当ては置き換えません。読み込めなかった件数も確認してください。')),
    'save_keymap_preset': (Text('Save Preset', 'プリセットを保存'), Text('Save all current assignments under Preset Name. Saving an existing name overwrites that preset; export scope does not limit this save.', '現在の割り当て全体を「プリセット名」で保存します。同じ名前は上書きされます。「エクスポート範囲」による絞り込みは使いません。')),
    'load_keymap_preset': (Text('Load Preset', 'プリセットを読み込み'), Text('Add assignments from the selected preset to the current keymap. Existing assignments remain; this is not a replacement or an undo action.', '選んだプリセットの割り当てを現在のキーマップに追加します。既存の割り当ては残ります。置き換えや取り消しの操作ではありません。')),
    'delete_keymap_preset': (Text('Delete Preset', 'プリセットを削除'), Text('Delete the selected preset file immediately without another confirmation. Check the selected name first. Current keymap assignments are not the preset file.', '選んだプリセットのファイルを確認なしで削除します。先に選択した名前を確かめてください。現在のキーマップとは別の保存ファイルです。')),
    'load_blender_keymap_preset': (Text('Load Blender Keymap Preset', 'Blenderキーマッププリセットを読み込み'), Text('Load Blender default keymaps when this session has not populated them. This recovery action is mainly intended for background test sessions.', 'このセッションでキーマップが読み込まれていない時にBlenderの初期設定を読み込みます。主にバックグラウンド試験向けの復旧操作です。')),
}

FOLD_HELP = Text('Open or close these details. This only changes the display and does not edit a shortcut.', 'この部分の詳細を開いたり閉じたりします。表示だけを変え、ショートカットは変更しません。')
EDIT_HELP = Text('Edit this value in the dialog. Confirm to apply it, or cancel to leave it unchanged.', 'ダイアログで値を変更します。確定すると反映し、キャンセルなら元のままです。')

def label(key, language, **values):
    return LABELS[key].in_language(language).format(**values)

def operation_text(operation_id, language, help=False):
    return OPERATIONS[operation_id.rsplit('.', 1)[-1]][1 if help else 0].in_language(language)
