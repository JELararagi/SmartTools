# SPDX-License-Identifier: GPL-3.0-or-later
"""Expose the same Blender identifiers to the panel and shortcut engine."""
import json
from pathlib import Path

schema_path = Path(__file__).resolve().parent.parent / "backend" / "public_declarations.json"
classes = json.loads(schema_path.read_text(encoding="utf-8"))["declarations"]
OPERATIONS = {entry["bl_idname"]: entry for entry in classes if entry.get("bl_idname", "").startswith("keymap_manager.")}
state = next(entry for entry in classes if entry["public_class"] == "KMM_State")
STATE_PROPERTIES = {prop["identifier"]: prop for prop in state["properties"]}
PANEL_DECLARATION = next(entry for entry in classes if entry["public_class"] == "KMM_PT_manager")
