# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Register the native Preferences UI against one explicit backend adapter."""
import bpy
from .adapter_contract import RowRef
from .controller import Controller, UIError, outcome_message
from .localization import label, operation_text
from .presentation import draw_panel, draw_preview
from .public_api import OPERATIONS, PANEL_DECLARATION

_controller = None
_registered = []
_enum_strings = {}
_CHOOSE = 'keymap_manager.choose_item_value'
_MERGE = 'keymap_manager.consolidate_duplicate_keymaps'


def _report(operator, context, outcome, phase='execute'):
    level, text = outcome_message(outcome, _controller.language(context), operator.operation_id, phase)
    if text:
        operator.report({level}, text)
    if outcome.status not in ('OK', 'NO_CHANGE'):
        return {'CANCELLED'}
    if context.area:
        context.area.tag_redraw()
    return {'FINISHED'}


def _error(operator, context, exc):
    operator.report({'WARNING'}, exc.localized(_controller.language(context)))
    return {'CANCELLED'}


def _args(operator):
    return {p['identifier']: getattr(operator, p['identifier'])
            for p in OPERATIONS[operator.operation_id]['properties']}


def _row(operator):
    return RowRef.from_arguments({k: getattr(operator, k) for k in RowRef.__dataclass_fields__})


def _field(operator, snap, identity=None):
    identity = identity or operator.operation_id
    if identity == 'keymap_manager_ui.edit_state':
        return _controller.field(snap, operator.field_name)
    try:
        ref = _row(operator)
    except (ValueError, TypeError, KeyError) as exc:
        raise UIError('missing') from exc
    row = _controller.row(snap, ref, writable=True)
    key = operator.prop_name if identity == _CHOOSE else operator.field_name
    return _controller.field(snap, key, row)


def _enum_callback(identity):
    # Blender passes OperatorProperties to dynamic enums, without the operator's Python class attributes.
    def items_for_properties(operator, context):
        if _controller is None or context is None:
            return []
        try:
            field = _field(operator, _controller.snapshot(context), identity)
        except UIError:
            return []
        language = _controller.language(context)
        items = tuple((c.key, c.label.in_language(language), c.help.in_language(language))
                      for c in field.choices)
        # RNA retains the strings returned by a dynamic enum until its class is removed.
        return _enum_strings.setdefault(items, items)
    return items_for_properties


def _invoke(operator, context, event):
    try:
        snap = _controller.snapshot(context)
        operator._revision = snap.revision
        if operator.operation_id == _MERGE:
            result = _controller.call(context, _MERGE, _args(operator), snap.revision, phase='preview')
            if _report(operator, context, result, 'preview') == {'CANCELLED'}:
                return {'CANCELLED'}
            if result.status == 'NO_CHANGE':
                return {'FINISHED'}
            snap = _controller.snapshot(context)
            if not _controller.preview_valid(snap):
                raise UIError('no_preview')
            operator._revision, operator._token = snap.revision, snap.preview.token
            return context.window_manager.invoke_props_dialog(operator, width=530)
        if operator.operation_id == _CHOOSE:
            field = _field(operator, snap)
            if not any(c.key == field.value for c in field.choices):
                raise UIError('invalid')
            operator.choice = field.value
            return context.window_manager.invoke_props_dialog(operator)
        return _execute(operator, context)
    except UIError as exc:
        return _error(operator, context, exc)


def _execute(operator, context):
    try:
        if operator.operation_id == _MERGE and not getattr(operator, '_token', ''):
            raise UIError('no_preview')
        phase = 'commit' if operator.operation_id == _MERGE else 'execute'
        result = _controller.call(context, operator.operation_id, _args(operator),
                                  getattr(operator, '_revision', None), phase, getattr(operator, '_token', ''))
        return _report(operator, context, result, phase)
    except UIError as exc:
        return _error(operator, context, exc)


def _cancel(operator, context):
    if operator.operation_id == _MERGE and getattr(operator, '_token', ''):
        try:
            _controller.call(context, _MERGE, _args(operator), operator._revision, 'cancel', operator._token)
        except UIError as exc:
            _error(operator, context, exc)


def _draw_dialog(operator, context):
    if operator.operation_id == _MERGE:
        try:
            snap = _controller.snapshot(context)
            _controller.require_revision(snap, operator._revision)
            draw_preview(operator.layout, _controller, snap, _controller.language(context))
        except UIError as exc:
            operator.layout.label(text=exc.localized(_controller.language(context)))
    elif operator.operation_id == _CHOOSE:
        operator.layout.prop(operator, 'choice', text=label('value', _controller.language(context)))


def _description(cls, context, properties):
    return operation_text(cls.operation_id, _controller.language(context), help=True)


def _props(spec):
    props = {}
    for prop in spec:
        options = {k: prop[k] for k in ('name', 'description', 'default') if k in prop}
        if prop['type'] == 'EnumProperty':
            options['items'] = _enum_callback(_CHOOSE)
        props[prop['identifier']] = getattr(bpy.props, prop['type'])(**options)
    return props


def _public_class(identifier, spec):
    return type(spec['public_class'], (bpy.types.Operator,), {
        '__module__': __name__, '__annotations__': _props(spec['properties']),
        'bl_idname': identifier, 'operation_id': identifier, 'bl_label': spec['bl_label'], 'bl_description': spec.get('bl_description') or operation_text(identifier, 'en', help=True),
        'execute': _execute, 'invoke': _invoke, 'draw': _draw_dialog, 'cancel': _cancel,
        'description': classmethod(_description)})


class KMMUI_OT_fold(bpy.types.Operator):
    bl_idname = 'keymap_manager_ui.toggle_fold'
    bl_label = 'Expand or collapse'
    bl_options = {'INTERNAL'}
    key: bpy.props.StringProperty()

    def execute(self, context):
        try:
            _controller.toggle_fold(context, self.key)
        except UIError as exc:
            return _error(self, context, exc)
        if context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


def _invoke_edit(operator, context, event):
    try:
        snap = _controller.snapshot(context)
        field = _field(operator, snap)
        operator._revision, operator._kind = snap.revision, field.kind
        if field.kind == 'BOOL':
            operator._value = not field.value
            return _execute_edit(operator, context)
        if field.kind == 'ENUM':
            if not any(c.key == field.value for c in field.choices):
                raise UIError('invalid')
            operator.enum_value = field.value
        elif field.kind == 'TEXT':
            operator.text_value = field.value
        else:
            raise UIError('invalid')
        return context.window_manager.invoke_props_dialog(operator)
    except UIError as exc:
        return _error(operator, context, exc)


def _draw_edit(operator, context):
    try:
        snap = _controller.snapshot(context)
        _controller.require_revision(snap, operator._revision)
        field = _field(operator, snap)
    except UIError as exc:
        operator.layout.label(text=exc.localized(_controller.language(context)))
        return
    prop = 'enum_value' if operator._kind == 'ENUM' else 'text_value'
    operator.layout.prop(operator, prop, text=field.label.in_language(_controller.language(context)),
                         translate=False)


def _execute_edit(operator, context):
    try:
        if not getattr(operator, '_revision', ''):
            raise UIError('stale')
        if operator._kind == 'BOOL':
            value = operator._value
        elif operator._kind == 'ENUM':
            value = operator.enum_value
        else:
            value = operator.text_value
        if operator.operation_id == 'keymap_manager_ui.edit_item':
            outcome = _controller.edit_item(context, _row(operator), operator.field_name, value, operator._revision)
        else:
            outcome = _controller.edit_state(context, operator.field_name, value, operator._revision)
        return _report(operator, context, outcome)
    except UIError as exc:
        return _error(operator, context, exc)


def _edit_class(item):
    kind = 'item' if item else 'state'
    props = {'field_name': bpy.props.StringProperty(), 'text_value': bpy.props.StringProperty(),
             'enum_value': bpy.props.EnumProperty(items=_enum_callback('keymap_manager_ui.edit_' + kind))}
    if item:
        props.update(_props([p for p in OPERATIONS[_CHOOSE]['properties']
                             if p['identifier'] in RowRef.__dataclass_fields__]))
    return type('KMMUI_OT_edit_' + kind, (bpy.types.Operator,), {
        '__module__': __name__, '__annotations__': props,
        'bl_idname': 'keymap_manager_ui.edit_' + kind, 'operation_id': 'keymap_manager_ui.edit_' + kind, 'bl_label': 'Edit', 'bl_options': {'INTERNAL'},
        'invoke': _invoke_edit, 'draw': _draw_edit, 'execute': _execute_edit})


class KMM_PT_manager(bpy.types.Panel):
    bl_label = PANEL_DECLARATION['bl_label']
    bl_space_type = PANEL_DECLARATION['bl_space_type']
    bl_region_type = PANEL_DECLARATION['bl_region_type']
    bl_context = PANEL_DECLARATION['bl_context']

    def draw_header(self, context):
        help_button = self.layout.operator("keymap_manager.show_help", text="", icon="QUESTION", emboss=False)
        help_button.topic = "overview"

    def draw(self, context):
        draw_panel(self.layout, _controller, context)



def bind_adapter(adapter):
    global _controller
    _controller = Controller(adapter)
    classes = [_public_class(identifier, spec) for identifier, spec in OPERATIONS.items()]
    classes.extend([KMMUI_OT_fold, _edit_class(False), _edit_class(True), KMM_PT_manager])
    return classes


def release_adapter():
    global _controller
    if _controller is not None:
        _controller.clear()
    _controller = None
    _enum_strings.clear()
