# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Physical US-key positions only. These are NOT Blender event identifiers."""
MAIN_ROWS = (
    ('Esc', 'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12'),
    ('Backquote', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'Minus', 'Equal', 'Backspace'),
    ('Tab', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', 'LeftBracket', 'RightBracket', 'Backslash'),
    ('CapsLock', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Semicolon', 'Quote', 'Enter'),
    ('ShiftLeft', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', 'Comma', 'Period', 'Slash', 'ShiftRight'),
    ('CtrlLeft', 'OSLeft', 'AltLeft', 'Space', 'AltRight', 'OSRight', 'CtrlRight'),
)
NAV_ROWS = (('PrintScreen', 'ScrollLock', 'Pause'), ('Insert', 'Home', 'PageUp'), ('Delete', 'End', 'PageDown'), ('', 'Up', ''), ('Left', 'Down', 'Right'))
NUMPAD_ROWS = (('NumLock', 'NumpadDivide', 'NumpadMultiply', 'NumpadSubtract'), ('Numpad7', 'Numpad8', 'Numpad9', 'NumpadAdd'), ('Numpad4', 'Numpad5', 'Numpad6', ''), ('Numpad1', 'Numpad2', 'Numpad3', 'NumpadEnter'), ('Numpad0', 'NumpadDecimal', '', ''))
MODIFIER_SLOTS = {'CtrlLeft': 'ctrl', 'CtrlRight': 'ctrl', 'ShiftLeft': 'shift', 'ShiftRight': 'shift', 'AltLeft': 'alt', 'AltRight': 'alt', 'OSLeft': 'oskey', 'OSRight': 'oskey'}
CAPTIONS = {'Backquote': '`', 'Minus': '-', 'Equal': '=', 'LeftBracket': '[', 'RightBracket': ']', 'Backslash': '\\', 'Semicolon': ';', 'Quote': "'", 'Comma': ',', 'Period': '.', 'Slash': '/', 'PrintScreen': 'PrtSc', 'ScrollLock': 'ScrLk', 'CapsLock': 'Caps', 'PageUp': 'PgUp', 'PageDown': 'PgDn', 'NumpadDivide': '/', 'NumpadMultiply': '*', 'NumpadSubtract': '-', 'NumpadAdd': '+', 'NumpadEnter': 'Enter', 'NumpadDecimal': '.', 'Up': '↑', 'Down': '↓', 'Left': '←', 'Right': '→'}
CAPTIONS.update({'Numpad' + str(i): str(i) for i in range(10)})
ALL_SLOTS = frozenset(slot for rows in (MAIN_ROWS, NAV_ROWS, NUMPAD_ROWS) for row in rows for slot in row if slot)
