# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Immutable presentation data. Root owns every keymap calculation and side effect."""
from dataclasses import dataclass
from typing import Mapping, Protocol

Scalar = str | bool | int

@dataclass(frozen=True)
class Text:
    en: str
    ja: str

    def in_language(self, language: str) -> str:
        return self.ja if language == 'ja' else self.en

@dataclass(frozen=True)
class RowRef:
    keyconfig_name: str
    keymap_name: str
    space_type: str
    region_type: str
    is_modal: bool
    kmi_id: int

    def __post_init__(self):
        for name in ('keyconfig_name', 'keymap_name', 'space_type', 'region_type'):
            if not isinstance(getattr(self, name), str) or not getattr(self, name):
                raise ValueError('Incomplete row locator: ' + name)
        if type(self.is_modal) is not bool or type(self.kmi_id) is not int or self.kmi_id < 0:
            raise ValueError('Invalid modal flag or row identifier')

    def arguments(self, prefix='') -> dict:
        return {prefix + name: getattr(self, name) for name in self.__dataclass_fields__}

    @classmethod
    def from_arguments(cls, values, prefix=''):
        return cls(**{name: values[prefix + name] for name in cls.__dataclass_fields__})

@dataclass(frozen=True)
class Choice:
    key: str
    label: Text
    help: Text

@dataclass(frozen=True)
class Field:
    name: str
    kind: str
    value: Scalar
    label: Text
    help: Text
    choices: tuple[Choice, ...] = ()
    enabled: bool = True

@dataclass(frozen=True)
class Binding:
    ref: RowRef
    label: Text
    registration: Text
    shortcut: Text
    status: str
    active: bool
    operator_id: str = ''
    fields: tuple[Field, ...] = ()
    modifiers: tuple[tuple[str, str], ...] = ()
    higher_sources: tuple[RowRef, ...] = ()
    details: tuple[Text, ...] = ()
    editable: bool = True

@dataclass(frozen=True)
class Event:
    slot: str
    token: str
    label: Text
    help: Text
    kind: str = 'keyboard'
    enabled: bool = True
    selected: bool = False

@dataclass(frozen=True)
class Category:
    key: str
    label: Text
    help: Text
    children: tuple[Choice, ...] = ()

@dataclass(frozen=True)
class Group:
    key: str
    label: Text
    rows: tuple[RowRef, ...]
    active_count: int = 0
    disabled_count: int = 0

@dataclass(frozen=True)
class UnusedGroup:
    key: str
    label: Text
    candidates: tuple[Text, ...]
    count: int

@dataclass(frozen=True)
class PreviewGroup:
    label: Text
    keep: tuple[RowRef, ...]
    remove: tuple[RowRef, ...]

@dataclass(frozen=True)
class Preview:
    token: str
    revision: str
    groups: tuple[PreviewGroup, ...]
    delete_count: int

@dataclass(frozen=True)
class Snapshot:
    revision: str
    fields: tuple[Field, ...] = ()
    rows: tuple[Binding, ...] = ()
    visible_rows: tuple[RowRef, ...] = ()
    match_count: int = 0
    view_mode: str = 'NORMAL'
    events: tuple[Event, ...] = ()
    groups: tuple[Group, ...] = ()
    categories: tuple[Category, ...] = ()
    unused_groups: tuple[UnusedGroup, ...] = ()
    selected_parent: str = ''
    selected_child: str = ''
    can_back: bool = False
    preview: Preview | None = None
    help_topics: tuple[tuple[str, str], ...] = ()
    messages: tuple[Text, ...] = ()
    no_selection: bool = True
    needs_initial_keymap: bool = False

@dataclass(frozen=True)
class Request:
    operation_id: str
    arguments: Mapping[str, Scalar]
    expected_revision: str
    phase: str = 'execute'
    preview_token: str = ''

@dataclass(frozen=True)
class StateChange:
    field_name: str
    value: Scalar
    expected_revision: str

@dataclass(frozen=True)
class ItemChange:
    target: RowRef
    field_name: str
    value: Scalar
    expected_revision: str

@dataclass(frozen=True)
class Outcome:
    status: str
    message: Text = Text('', '')
    deleted_count: int | None = None

class Adapter(Protocol):
    """Root must atomically recheck revision and complete row locators before writes.

    snapshot is a cached read, with no Blender writes or recomputation in draw.
    Dynamic event/enum/topic/category identifiers must come from the real runtime.
    dispatch handles all computation, I/O and clipboard operations.
    preview/cancel cannot delete bindings; commit requires its original token.
    language returns ja/en from Blender's active interface-language settings.
    session_key identifies a window/session without changing user settings.
    """
    def snapshot(self, context) -> Snapshot: ...
    def dispatch(self, context, request: Request) -> Outcome: ...
    def set_state(self, context, change: StateChange) -> Outcome: ...
    def set_item(self, context, change: ItemChange) -> Outcome: ...
    def language(self, context) -> str: ...
    def session_key(self, context) -> str: ...
