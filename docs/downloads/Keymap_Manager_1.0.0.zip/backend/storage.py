# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit JSON and preset I/O. Construction and enumeration never create files."""
import json
import os
from pathlib import Path, PureWindowsPath
import tempfile

from .model import BackendError, MAX_INPUT_BYTES, plain_json


def decode_document(payload):
    if type(payload) is bytes:
        if len(payload) > MAX_INPUT_BYTES:
            raise BackendError('RESOURCE_LIMIT', resource='json_bytes')
        try:
            payload = payload.decode('utf-8-sig')
        except UnicodeError as exc:
            raise BackendError('INVALID_JSON', reason='encoding') from exc
    if type(payload) is not str or len(payload.encode('utf-8')) > MAX_INPUT_BYTES:
        raise BackendError('INVALID_JSON')

    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise BackendError('INVALID_JSON', reason='duplicate_object_key', key=key)
            result[key] = value
        return result

    def invalid_number(value):
        raise BackendError('INVALID_JSON', reason='nonfinite_number')

    try:
        value = json.loads(payload.lstrip('\ufeff'), object_pairs_hook=unique_object,
                           parse_constant=invalid_number)
        return plain_json(value)
    except BackendError:
        raise
    except (ValueError, TypeError, RecursionError, UnicodeError) as exc:
        raise BackendError('INVALID_JSON') from exc


def encode_document(value):
    try:
        text = json.dumps(plain_json(value), ensure_ascii=False, allow_nan=False, indent=2) + '\n'
        payload = text.encode('utf-8')
    except BackendError:
        raise
    except (ValueError, TypeError, UnicodeError, RecursionError) as exc:
        raise BackendError('INVALID_JSON') from exc
    if len(payload) > MAX_INPUT_BYTES:
        raise BackendError('RESOURCE_LIMIT', resource='json_bytes')
    return payload


def preset_name(value):
    if type(value) is not str or not value or len(value) > 128:
        raise BackendError('INVALID_NAME')
    if value != value.strip() or value.endswith('.') or value in ('.', '..'):
        raise BackendError('INVALID_NAME')
    if any(ord(char) < 32 or char in '<>:"/\\|?*' for char in value):
        raise BackendError('INVALID_NAME')
    stem = value.split('.', 1)[0].upper()
    reserved = {'CON', 'PRN', 'AUX', 'NUL'} | {'COM'+str(n) for n in range(1, 10)} | {'LPT'+str(n) for n in range(1, 10)}
    if stem in reserved:
        raise BackendError('INVALID_NAME')
    return value


class FileStore:
    """A caller-selected configuration root; external exports require opt-in.

    Tests supply a dedicated directory beneath keymap_backend and leave
    allow_external=False. No environment or Blender configuration is changed.
    """
    def __init__(self, root, *, allow_external=False):
        self.root = Path(root).resolve()
        self.allow_external = bool(allow_external)

    def _inside(self, path):
        try:
            path.relative_to(self.root)
            return True
        except ValueError:
            return False

    def resolve(self, name='', *, preset=False):
        if type(name) is not str or '\x00' in name:
            raise BackendError('INVALID_PATH')
        if preset:
            candidate = self.root / 'presets' / (preset_name(name) + '.json')
        else:
            if not name:
                candidate = self.root / 'keymap.json'
            else:
                if os.name != 'nt' and PureWindowsPath(name).drive:
                    raise BackendError('INVALID_PATH', reason='foreign_drive')
                raw = Path(name)
                candidate = raw if raw.is_absolute() else self.root / raw
        try:
            if candidate.is_symlink():
                raise BackendError('INVALID_PATH', reason='symbolic_link_target')
            resolved = candidate.resolve()
            if (preset or not self.allow_external) and not self._inside(resolved):
                raise BackendError('INVALID_PATH', reason='outside_storage_root')
            if resolved.suffix.lower() != '.json' or resolved.is_dir():
                raise BackendError('INVALID_PATH', reason='not_json_file')
            return resolved
        except BackendError:
            raise
        except (OSError, ValueError, RuntimeError) as exc:
            raise BackendError('INVALID_PATH', reason=type(exc).__name__) from exc

    def read(self, name, *, preset=False):
        target = self.resolve(name, preset=preset)
        try:
            with target.open('rb') as stream:
                payload = stream.read(MAX_INPUT_BYTES + 1)
        except FileNotFoundError as exc:
            raise BackendError('PRESET_NOT_FOUND' if preset else 'FILE_NOT_FOUND') from exc
        except (OSError, ValueError) as exc:
            raise BackendError('FILE_READ_ERROR', reason=type(exc).__name__) from exc
        return decode_document(payload)

    def write(self, name, value, *, preset=False):
        payload = encode_document(value)
        target = self.resolve(name, preset=preset)
        temporary = None
        descriptor = None
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            descriptor, temporary = tempfile.mkstemp(prefix='.kmm-', suffix='.tmp', dir=target.parent)
            with os.fdopen(descriptor, 'wb') as stream:
                descriptor = None
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, target)
            temporary = None
        except (OSError, ValueError) as exc:
            raise BackendError('FILE_WRITE_ERROR', reason=type(exc).__name__) from exc
        finally:
            if descriptor is not None:
                os.close(descriptor)
            if temporary is not None:
                try:
                    Path(temporary).unlink(missing_ok=True)
                except OSError as exc:
                    raise BackendError('TEMP_CLEANUP_FAILED', path=temporary) from exc
        return str(target)

    def names(self):
        directory = self.root / 'presets'
        try:
            resolved = directory.resolve()
            if not self._inside(resolved) or directory.is_symlink():
                raise BackendError('INVALID_PATH', reason='preset_directory')
            if not directory.exists():
                return ()
            result = []
            for entry in directory.iterdir():
                if entry.suffix.lower() != '.json' or not entry.is_file() or entry.is_symlink():
                    continue
                try:
                    preset_name(entry.stem)
                except BackendError:
                    continue
                result.append(entry.stem)
            return tuple(sorted(result, key=lambda name: (name.casefold(), name)))
        except BackendError:
            raise
        except OSError as exc:
            raise BackendError('FILE_READ_ERROR', reason=type(exc).__name__) from exc

    def delete_preset(self, name):
        target = self.resolve(name, preset=True)
        try:
            target.unlink()
        except FileNotFoundError as exc:
            raise BackendError('PRESET_NOT_FOUND') from exc
        except OSError as exc:
            raise BackendError('FILE_DELETE_ERROR', reason=type(exc).__name__) from exc
        return str(target)
