# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Candidate help topics, supplied to the UI as runtime identifiers.

Only overview was named by the published declaration. The other identifiers
are explicit candidate choices, not claims about an older implementation.
"""
HELP_TOPICS = {
    'overview': (
        'Choose a key or enter an operator identifier to inspect assignments. Editor, mode, input state and modifiers distinguish bindings. Refresh after edits made elsewhere. Status and priority are estimates; an operator may also depend on its current context.',
        'キーを選ぶかオペレーター識別子を入力すると、割り当てを調べられます。エディター、モード、入力状態、修飾キーが違う割り当ては区別されます。別の場所で編集した後は更新してください。有効状態や優先関係の表示は推定で、実際の実行には現在の状況も影響します。'),
    'keyboard': (
        'Select a physical key, then use the modifier filters to distinguish combinations such as S and Ctrl+S. Selecting a key clears the operator search and returns to the normal list. Key selection is unavailable in the unused-key view.',
        'キーボードのキーを選び、修飾キーの絞り込みでSとCtrl+Sなどを区別します。キーを選ぶとオペレーター検索を空にして通常の一覧へ戻ります。未使用キーの表示中はキーを選択できません。'),
    'mouse': (
        'Select a mouse event to inspect its bindings. Press, release, click and drag are different input states. Drag direction is retained as part of a binding.',
        'マウスの操作を選ぶと、その割り当てを調べられます。押す、放す、クリック、ドラッグは別の入力状態です。ドラッグ方向も割り当ての条件として保持されます。'),
    'ndof': (
        'This section lists event types exposed by the running Blender for a 3D mouse. A listed event does not prove that a device is connected or that its driver is configured.',
        '実行中のBlenderが公開する3Dマウスの入力種類を表示します。項目が表示されても、機器の接続やドライバーの設定が確認されたことにはなりません。'),
    'filters': (
        'Exact Modifiers checks the selected modifier states and secondary key. An Any modifier accepts either pressed or released. Exact Value restricts the input state. Include Disabled also shows assignments whose Active setting is off.',
        '修飾キーの完全一致では、選択した修飾キーと補助キーの条件を照合します。任意の修飾キー条件は、押している場合と押していない場合の両方に一致します。入力状態の完全一致で押す・放すなどを絞れます。無効項目を含めると、有効の設定がオフの割り当ても表示します。'),
    'registered': (
        'Each row identifies its configuration layer and complete registration location. Editing a row changes that assignment immediately. Modifier cycling follows Off, On, Any, then Off. Modal values come from the selected modal keymap.',
        '各行には設定層と登録場所が示されます。行の編集はその割り当てを直ちに変更します。修飾キーはオフ、オン、任意、オフの順で切り替わります。モーダルの選択肢は、対象のモーダルキーマップから取得します。'),
    'duplicates': (
        'Preview shows the first binding to keep and the exact duplicates to remove. Configuration layer, location, operation, event, active state and operator properties must agree. Confirm the current preview to remove its listed duplicates. Cancel leaves bindings unchanged. The result reports the actual number removed.',
        '確認画面には残す先頭の割り当てと削除対象が表示されます。設定層、登録場所、操作、入力条件、有効状態、オペレーター設定が一致するものを完全重複として扱います。現在の確認画面で集約を確定すると、その対象を削除します。キャンセルでは割り当てを変更しません。結果には実際に削除できた数を表示します。'),
    'shadowed': (
        'The listed higher-priority sources are estimates with an explicit scope. Enabling the target disables every listed source, including in the original contexts where those sources were used. Different editors and modal bindings are not treated as blockers merely because their physical keys match.',
        '上位優先元の一覧は、対象範囲を明示した推定です。対象を有効にすると、表示された上位優先元をすべて無効にするため、それらの元の画面でも動かなくなります。物理キーが同じという理由だけで、別エディターやモーダルの割り当てを上位優先元にはしません。'),
    'conflicts': (
        'Conflict view groups active registrations with the same configuration layer, location and complete event settings. It does not certify which operator will run. Press the view button again to return to the normal list.',
        '競合表示では、設定層、登録場所、入力条件が同じ有効な割り当てをまとめます。実際にどのオペレーターが動くかを保証する表示ではありません。同じ表示ボタンをもう一度押すと通常の一覧に戻ります。'),
    'unused': (
        'Choose a registration category and, when needed, a subcategory. Candidates are checked only within that location. Disabled assignments still reserve their events, and wildcard conditions reserve overlapping candidates. The candidate set is finite and does not certify that a shortcut is free in every Blender context.',
        '登録先の分類を選び、必要に応じて下位の分類を選びます。候補は選択した登録場所の中で調べます。無効な割り当ても予約済みとして扱い、任意条件と重なる候補も使用済みとします。候補の範囲は有限で、Blenderのすべての状況で空いていることを保証するものではありません。'),
    'visual': (
        'The overview groups assignments by base key. Filter by editor, keymap name or text. Include Disabled controls whether inactive assignments contribute to the displayed groups. Clearing filters keeps the assignments themselves unchanged.',
        '可視化では基準キーごとに割り当てをまとめます。エディター、キーマップ名、文字列で絞り込めます。無効項目を含める設定により、無効な割り当てを集計するかが変わります。絞り込みを解除しても割り当て自体は変更しません。'),
    'io': (
        'Export writes the selected USER scope to JSON. Import appends valid bindings and reports invalid rows separately; existing bindings are not removed. Exact repeated imports are counted as duplicates. Operator properties and modal values must be supported by the running Blender.',
        '書き出しでは、選択した範囲のユーザー設定をJSONに保存します。読み込みでは有効な割り当てを追加し、不正な行は別に件数を報告します。既存の割り当ては削除しません。完全一致する再読込は重複として数えます。オペレーター設定やモーダル値は、実行中のBlenderが対応するものに限られます。'),
    'presets': (
        'Saving a named preset includes all USER bindings, regardless of the export scope. Saving the same name replaces that preset. Loading appends bindings. Deleting removes only the selected preset file and has no extra confirmation dialog.',
        '名前付きプリセットの保存には、書き出し範囲の設定にかかわらず、すべてのユーザー割り当てを含めます。同じ名前で保存すると、そのプリセットを上書きします。読み込みは追加方式です。削除は選択したプリセットのファイルだけを対象とし、追加の確認画面は出ません。'),
}
