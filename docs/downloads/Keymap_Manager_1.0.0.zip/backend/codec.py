# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Candidate v1 container with the authorized Root portable row fields.

The group layout and required version below are explicitly defined by this
candidate. They are not evidence of an uninspected historical ZIP's format.
No Blender calls, file access or fixture-format conversion occur here.
"""
from dataclasses import dataclass

from .model import (BackendError, EventData, MAX_ROWS, canonical, plain_json,
                    require_text)

SCHEMA = 'JELararagi.KeymapManager.KeymapData'
VERSION = 1
MAX_GROUPS = 20000


@dataclass(frozen=True)
class GroupAddress:
    name: str
    space_type: str
    region_type: str
    is_modal: bool
    is_tool: bool = False

    def __post_init__(self):
        for name in ('name', 'space_type', 'region_type'):
            require_text(getattr(self, name), name)
        if type(self.is_modal) is not bool or type(self.is_tool) is not bool:
            raise BackendError('INVALID_GROUP', reason='flag_type')

    @property
    def location(self):
        return (self.name, self.space_type, self.region_type, self.is_modal)

    def as_dict(self):
        return dict(name=self.name, space_type=self.space_type,
                    region_type=self.region_type, is_modal=self.is_modal,
                    is_tool=self.is_tool)


@dataclass(frozen=True)
class ImportItem:
    group_index: int
    row_index: int
    group: GroupAddress
    idname: str
    propvalue: str
    active: bool
    event: EventData
    properties_text: str

    def content_key(self, *, include_active=True):
        identity = self.propvalue if self.group.is_modal else self.idname.strip().lower()
        return (self.group.location, identity, self.event.signature(),
                self.active if include_active else None, self.properties_text)

    @property
    def properties(self):
        import json
        return json.loads(self.properties_text)


@dataclass(frozen=True)
class Problem:
    group_index: int
    row_index: int | None
    code: str
    details_text: str = '{}'

    def as_dict(self):
        import json
        return dict(group_index=self.group_index, row_index=self.row_index,
                    code=self.code, details=json.loads(self.details_text))


@dataclass(frozen=True)
class Decoded:
    outcomes: tuple[ImportItem | Problem, ...]
    group_problems: tuple[Problem, ...]
    known_row_count: int

    @property
    def valid_count(self):
        return sum(isinstance(row, ImportItem) for row in self.outcomes)

    @property
    def failed_count(self):
        return sum(isinstance(row, Problem) for row in self.outcomes)


def _item(group, row, group_index, row_index):
    if type(row) is not dict:
        raise BackendError('INVALID_BINDING', reason='not_object')
    active = row.get('active', True)
    if type(active) is not bool:
        raise BackendError('INVALID_BINDING', field='active')
    idname = row.get('idname', '')
    propvalue = row.get('propvalue', '')
    require_text(idname, 'idname', allow_empty=group.is_modal)
    require_text(propvalue, 'propvalue', allow_empty=not group.is_modal)
    values = row.get('properties', {})
    if type(values) is not dict:
        raise BackendError('INVALID_PROPERTY', reason='not_object')
    event = EventData.from_mapping(row)
    return ImportItem(group_index, row_index, group, idname, propvalue,
                      active, event, canonical(values))


def decode_document(value):
    """Reject invalid document scope first, then retain every row outcome."""
    if type(value) is not dict or value.get('schema') != SCHEMA:
        raise BackendError('INVALID_SCHEMA')
    if type(value.get('version')) is not int or value['version'] != VERSION:
        raise BackendError('UNSUPPORTED_VERSION')
    groups = value.get('keymaps')
    if type(groups) is not list:
        raise BackendError('INVALID_SCHEMA', field='keymaps')
    if len(groups) > MAX_GROUPS:
        raise BackendError('RESOURCE_LIMIT', resource='keymap_groups')
    plain_json(value)
    known = sum(len(group['items']) for group in groups
                if type(group) is dict and type(group.get('items')) is list)
    if known > MAX_ROWS:
        raise BackendError('RESOURCE_LIMIT', resource='keymap_items')
    outcomes = []
    group_problems = []
    for group_index, source in enumerate(groups):
        rows = source.get('items') if type(source) is dict else None
        try:
            if type(source) is not dict or type(rows) is not list:
                raise BackendError('INVALID_GROUP', reason='items_not_list')
            required = ('name', 'space_type', 'region_type', 'is_modal')
            if any(name not in source for name in required):
                raise BackendError('INVALID_GROUP', reason='incomplete_location')
            group = GroupAddress(*(source[name] for name in required),
                                 is_tool=source.get('is_tool', False))
        except BackendError as exc:
            problem = Problem(group_index, None, 'INVALID_GROUP',
                              canonical(dict(cause=exc.code, **exc.details)))
            group_problems.append(problem)
            if type(rows) is list:
                outcomes.extend(Problem(group_index, index, 'INVALID_GROUP',
                                        problem.details_text) for index in range(len(rows)))
            continue
        for row_index, row in enumerate(rows):
            try:
                outcomes.append(_item(group, row, group_index, row_index))
            except BackendError as exc:
                outcomes.append(Problem(group_index, row_index, exc.code,
                                        canonical(exc.details)))
    return Decoded(tuple(outcomes), tuple(group_problems), known)


def describe_record(record):
    if not record.portable:
        raise BackendError('UNSUPPORTED_PROPERTIES', target=record.key.values(), issues=list(record.property_issues))
    values = record.event.as_dict()
    properties = record.properties
    if type(properties) is not dict or canonical(properties) != record.properties_text:
        raise BackendError('INVALID_PROPERTY')
    values.update(idname=record.idname, propvalue=record.propvalue,
                  active=record.active, properties=properties)
    return values


def encode_records(records, keymaps=()):
    """Keep input order and duplicates; never merge different configuration layers.

    Consecutive runs become groups. Repeated group locations are permitted, so
    serialization does not reorder the supplied records. Empty USER maps are
    retained after the records when their location is unambiguous.
    """
    records = tuple(records)
    keymaps = tuple(km for km in keymaps if km.role == 'USER')
    if len(records) > MAX_ROWS:
        raise BackendError('RESOURCE_LIMIT', resource='keymap_items')
    if any(row.role != 'USER' for row in records):
        raise BackendError('INVALID_EXPORT_LAYER')
    configurations = {row.key.keyconfig_name for row in records}
    configurations.update(km.keyconfig_name for km in keymaps)
    if len(configurations) > 1:
        raise BackendError('AMBIGUOUS_EXPORT_CONFIGURATION')
    map_table = {}
    for km in keymaps:
        if km.location in map_table:
            raise BackendError('AMBIGUOUS_TARGET', reason='duplicate_keymap_location')
        map_table[km.location] = km
    groups = []
    seen_locations = set()
    previous = None
    for row in records:
        location = row.key.location
        km = map_table.get(location)
        tool = km.is_tool if km is not None else False
        group_key = location + (tool,)
        if previous != group_key:
            address = GroupAddress(row.key.keymap_name, row.key.space_type,
                                   row.key.region_type, row.key.is_modal, tool)
            groups.append(dict(address.as_dict(), items=[]))
            previous = group_key
        groups[-1]['items'].append(describe_record(row))
        seen_locations.add(location)
    for km in keymaps:
        if km.location not in seen_locations:
            address = GroupAddress(km.name, km.space_type, km.region_type,
                                   km.is_modal, km.is_tool)
            groups.append(dict(address.as_dict(), items=[]))
    result = dict(schema=SCHEMA, version=VERSION, keymaps=groups)
    decoded = decode_document(result)
    if decoded.failed_count or decoded.group_problems or decoded.known_row_count != len(records):
        raise BackendError('INVALID_EXPORT_DATA')
    return result
