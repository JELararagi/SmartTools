# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""The sole bpy registrar for backend state and explicitly supplied UI classes."""
from pathlib import Path
import re
import threading
import uuid

from .adapter import BackendAdapter, interface_language
from .blender_port import BpyPort, pointer, rna_fields
from .engine import Engine
from .model import BackendError, digest
from . import presentation
from .state import STATE_DECLARATIONS, PREVIEW_DECLARATIONS, INFERRED_ENUM_DEFAULTS, OPERATIONS
from .storage import FileStore


class EnumRegistry:
    """Retain enum strings and numeric identities for the registration lifetime.

    Callback reads use this cache only. No keyconfig or file scan occurs here.
    Removed choices remain identifiable to avoid corrupting already-stored enum
    numbers; the Engine accepts only its current choices for a new request.
    """
    def __init__(self, bpy_module, contract, language):
        self.bpy, self.contract, self.language = bpy_module, contract, language
        self._numbers = {}
        self._seen = {}
        self._cache = {}
        self._history = []
        self._callbacks = {}
        for field, default in INFERRED_ENUM_DEFAULTS.items():
            self._numbers[field] = {default: 0}
            self.put(None, field, (presentation.enum_choice(contract, default),))
        for field, event_field in (('selected_type', 'type'), ('selected_value', 'value'), ('selected_key_modifier', 'key_modifier')):
            choices = tuple(presentation.enum_choice(contract, item.key, item)
                            for item in BpyPort._type_options(self.bpy.types.KeyMapItem, event_field))
            if INFERRED_ENUM_DEFAULTS[field] not in {choice.key for choice in choices}:
                raise BackendError('MISSING_DEFAULT_ENUM', field=field)
            self.put(None, field, choices)

    def put(self, owner_key, field, choices):
        identity = (owner_key, field)
        seen = dict(self._seen.get(identity, {}))
        for choice in choices:
            seen[choice.key] = choice
        if seen == self._seen.get(identity):
            return
        numbers = self._numbers.setdefault(field, {})
        occupied = set(numbers.values())
        for key in seen:
            if key not in numbers:
                number = int(digest((field, key))[:7], 16) + 1
                while number in occupied:
                    number += 1
                numbers[key] = number
                occupied.add(number)
        for language in ('en', 'ja'):
            items = tuple((choice.key, choice.label.in_language(language), choice.help.in_language(language), 0, numbers[choice.key])
                          for choice in seen.values())
            self._cache[(owner_key, field, language)] = items
            self._history.append(items)
        self._seen[identity] = seen

    def callback(self, field):
        if field not in self._callbacks:
            def items(owner, context):
                owner_key = None
                try:
                    wm = getattr(owner, 'id_data', None) or getattr(context, 'window_manager', None)
                    if wm is not None:
                        owner_key = pointer(wm)
                except (BackendError, AttributeError, ReferenceError, RuntimeError):
                    owner_key = None
                language = self.language(context)
                return self._cache.get((owner_key, field, language), self._cache[(None, field, language)])
            self._callbacks[field] = items
        return self._callbacks[field]

    def prime(self, context, scan, store):
        key = pointer(context.window_manager)
        c = self.contract
        self.put(key, 'visual_editor_filter', tuple(presentation.enum_choice(c, value) for value in ('ALL',) + tuple(dict.fromkeys(km.space_type for km in scan.keymaps))))
        self.put(key, 'visual_mode_filter', tuple(presentation.enum_choice(c, value) for value in ('ALL',) + tuple(dict.fromkeys(km.name for km in scan.keymaps))))
        self.preset_choices(key, store.names())

    def preset_choices(self, key, names):
        c = self.contract
        self.put(key, 'preset_select', (presentation.enum_choice(c, 'NONE'),) + tuple(presentation.enum_choice(c, 'preset:' + name, label_en=name, label_ja=name) for name in names))

    def publish(self, context, engine):
        key = pointer(context.window_manager)
        for declaration in STATE_DECLARATIONS:
            if declaration['type'] == 'EnumProperty' and declaration['identifier'] != 'export_scope':
                self.put(key, declaration['identifier'], presentation.state_choices(self.contract, engine, declaration))


class BackendRuntime:
    """Create first; give adapter to the UI class factory; register its classes once.

    The public declarations do not disclose a legacy WindowManager pointer name
    or a legacy preset directory. Root therefore supplies both explicitly.
    """
    def __init__(self, bpy_module, contract, *, wm_state_name, storage_root,
                 allow_external_files=False, priority_policy=None,
                 standard_preset_path=None, trusted_preset_root=None):
        if type(wm_state_name) is not str or not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*', wm_state_name):
            raise BackendError('INVALID_STATE_POINTER_NAME')
        self.bpy = bpy_module
        self.contract = contract
        self.wm_state_name = wm_state_name
        self.storage_root = Path(storage_root)
        self.store = FileStore(self.storage_root, allow_external=allow_external_files)
        self.priority_policy = priority_policy
        self.standard_preset_path = standard_preset_path
        self.trusted_preset_root = trusted_preset_root
        self._thread = threading.get_ident()
        self._ui_owned = []
        self._groups_owned = []
        self._pointer_owned = False
        self._translations_owned = False
        self._registered = False
        self._ports = []
        self._translation_key = __name__ + '.' + uuid.uuid4().hex
        self._translations = {}
        self.adapter = BackendAdapter(contract, self._engine_factory,
                                      language_resolver=self.language, on_publish=self._publish)
        self.enums = EnumRegistry(bpy_module, contract, self.language)
        self.preview_class, self.state_class = self._make_groups()

    def language(self, context):
        language = interface_language(context)
        view = getattr(getattr(context, 'preferences', None), 'view', None)
        if view is not None and getattr(view, 'use_translate_interface', True) and getattr(view, 'language', '') == 'DEFAULT':
            locale = getattr(getattr(self.bpy.app, 'translations', None), 'locale', '')
            language = 'ja' if isinstance(locale, str) and locale.lower().startswith('ja') else 'en'
        return language

    def _translated(self, english, japanese):
        if english and japanese:
            self._translations[('*', english)] = japanese
        return english

    def _make_groups(self):
        bpy = self.bpy
        preview_annotations = {}
        for declaration in PREVIEW_DECLARATIONS:
            name = declaration['identifier']
            kwargs = {key: declaration[key] for key in ('default', 'subtype') if key in declaration}
            kwargs['name'] = self._translated(name.replace('_', ' ').title(), '確認行の' + name)
            kwargs['description'] = self._translated('Stored information for the duplicate preview row. Reviewing a row does not delete a binding.', '重複整理の確認行に保存された情報です。行を確認するだけでは割り当てを削除しません。')
            preview_annotations[name] = getattr(bpy.props, declaration['type'])(**kwargs)
        preview = type('KMM_ConsolidationPreviewRow', (bpy.types.PropertyGroup,),
                       {'__module__': __name__, '__annotations__': preview_annotations})
        annotations = {}
        for declaration in STATE_DECLARATIONS:
            name, kind = declaration['identifier'], declaration['type']
            label, help_value = presentation.state_text(self.contract, declaration)
            kwargs = {'name': self._translated(label.en, label.ja),
                      'description': self._translated(help_value.en, help_value.ja)}
            if 'subtype' in declaration:
                kwargs['subtype'] = declaration['subtype']
            if kind == 'CollectionProperty':
                kwargs['type'] = preview
            elif kind == 'EnumProperty':
                if name == 'export_scope':
                    kwargs['items'] = tuple(tuple(item) for item in declaration['items'])
                    kwargs['default'] = declaration['default']
                    for key, label_en, help_en in declaration['items']:
                        self._translated(label_en, '変更済みのみ' if key == 'MODIFIED' else '全キーマップ')
                        self._translated(help_en, 'Blenderの初期値から変更されたユーザーの割り当てを保存します。' if key == 'MODIFIED' else 'ユーザーのすべての割り当てを保存します。')
                else:
                    kwargs['items'] = self.enums.callback(name)
                    # A callback EnumProperty must not receive a string default.
                    kwargs['default'] = 0
            elif 'default' in declaration:
                kwargs['default'] = declaration['default']
            annotations[name] = getattr(bpy.props, kind)(**kwargs)
        state = type('KMM_State', (bpy.types.PropertyGroup,),
                     {'__module__': __name__, '__annotations__': annotations})
        return preview, state

    def _engine_factory(self, context):
        if not self._registered or not self._pointer_owned:
            raise BackendError('BACKEND_NOT_REGISTERED')
        owner = getattr(context.window_manager, self.wm_state_name)
        port = BpyPort(self.bpy, context, priority_policy=self.priority_policy,
                       standard_preset_path=self.standard_preset_path, trusted_preset_root=self.trusted_preset_root)
        self.enums.prime(context, port.scan(), self.store)
        owner_key = pointer(context.window_manager)
        engine = Engine(port, owner, self.store,
                        on_preset_choices=lambda names: self.enums.preset_choices(owner_key, names))
        self._ports.append(port)
        return engine

    def _publish(self, context, engine):
        self.enums.publish(context, engine)
        owner = getattr(context.window_manager, self.wm_state_name)
        rows = owner.consolidation_preview_rows
        wanted = []
        language = self.language(context)
        if engine.preview is not None:
            for index, group in enumerate(engine.preview.groups):
                for position, record in enumerate(group):
                    values = record.key.ui_arguments()
                    values.update(row_type='KEEP' if position == 0 else 'REMOVE', group_index=index,
                                  text=record.label_ja if language == 'ja' and record.label_ja else record.label_en or record.identity,
                                  detail=record.key.keymap_name + ': ' + presentation.queries.shortcut(record.event, language))
                    wanted.append(values)
        names = tuple(declaration['identifier'] for declaration in PREVIEW_DECLARATIONS)
        actual = [{name: getattr(row, name) for name in names} for row in rows]
        if actual == wanted:
            return
        rows.clear()
        try:
            for values in wanted:
                row = rows.add()
                for name, value in values.items():
                    setattr(row, name, value)
        except Exception:
            rows.clear()
            raise

    def _base_type(self, cls):
        for name in ('Operator', 'Panel', 'UIList', 'Menu', 'PropertyGroup'):
            base = getattr(self.bpy.types, name, None)
            if base is not None and issubclass(cls, base):
                return base
        raise BackendError('UNSUPPORTED_UI_CLASS', name=cls.__name__)

    def _registered_class(self, cls):
        """Return an identified class or proven absence; uncertainty is an error.

        Operator enumeration is read-only. An exception from get_rna_type is never
        interpreted as absence. Runtime acceptance must verify these public lookup
        paths on the target Blender version.
        """
        base = self._base_type(cls)
        identifier = getattr(cls, 'bl_idname', '') or cls.__name__
        try:
            if issubclass(cls, self.bpy.types.Operator):
                module, operation = identifier.split('.', 1)
                if not module or not operation or '.' in operation:
                    raise BackendError('REGISTRATION_LOOKUP_FAILED', name=cls.__name__, reason='invalid_operator_id')
                namespace = getattr(self.bpy.ops, module) if module in dir(self.bpy.ops) else None
                absent = namespace is None or operation not in dir(namespace)
                if absent:
                    # An independently visible class contradicts an empty operator slot.
                    rna = getattr(self.bpy.types, cls.__name__, None)
                    current = base.bl_rna_get_subclass_py(cls.__name__, None)
                    if rna is not None or current is not None:
                        raise BackendError('REGISTRATION_LOOKUP_FAILED', name=cls.__name__, reason='inconsistent_operator_registry')
                    return None
                rna = getattr(namespace, operation).get_rna_type()
                identifier = getattr(rna, 'identifier', None)
                if type(identifier) is not str or not identifier:
                    raise BackendError('REGISTRATION_LOOKUP_FAILED', name=cls.__name__, reason='missing_rna_identifier')
                current = base.bl_rna_get_subclass_py(identifier, None)
                if current is None:
                    raise BackendError('REGISTRATION_LOOKUP_FAILED', name=cls.__name__, reason='rna_without_python_class')
                return current
            current = base.bl_rna_get_subclass_py(identifier, None)
            exposed = getattr(self.bpy.types, identifier, None)
            if exposed is not None and exposed is not current:
                raise BackendError('REGISTRATION_LOOKUP_FAILED', name=identifier, reason='inconsistent_python_class')
            return current
        except BackendError:
            raise
        except Exception as exc:
            raise BackendError('REGISTRATION_LOOKUP_FAILED', name=cls.__name__, exception_type=type(exc).__name__) from exc

    def _pointer_class(self):
        field = rna_fields(self.bpy.types.WindowManager).get(self.wm_state_name)
        if field is None:
            return None
        fixed = getattr(field, 'fixed_type', None)
        if fixed is None:
            return 'unrecognized'
        return self.bpy.types.PropertyGroup.bl_rna_get_subclass_py(fixed.identifier, None) or 'unrecognized'

    def _register_one(self, cls, ledger):
        if self._registered_class(cls) is not None:
            raise BackendError('CLASS_ALREADY_REGISTERED', name=cls.__name__)
        # Keep attempted ownership before the call: an API may mutate and then fail.
        # A failed readback must retain this entry and its dependencies for retry.
        ledger.append(cls)
        self.bpy.utils.register_class(cls)
        if self._registered_class(cls) is not cls:
            raise BackendError('REGISTRATION_NOT_CONFIRMED', name=cls.__name__)

    def register(self, ui_classes):
        if threading.get_ident() != self._thread:
            raise BackendError('WRONG_THREAD')
        if self._registered or self._ui_owned or self._groups_owned or self._pointer_owned or self._translations_owned:
            raise BackendError('REGISTRATION_ALREADY_OWNED')
        ui_classes = tuple(ui_classes)
        if len(set(ui_classes)) != len(ui_classes):
            raise BackendError('DUPLICATE_UI_CLASS')
        all_classes = (self.preview_class, self.state_class) + ui_classes
        if len({cls.__name__ for cls in all_classes}) != len(all_classes):
            raise BackendError('DUPLICATE_CLASS_NAME')
        operations = [cls.bl_idname for cls in ui_classes if issubclass(cls, self.bpy.types.Operator)]
        if len(operations) != len(set(operations)) or not set(OPERATIONS).issubset(operations):
            raise BackendError('UI_OPERATOR_COVERAGE_MISMATCH')
        if self.wm_state_name in rna_fields(self.bpy.types.WindowManager) or hasattr(self.bpy.types.WindowManager, self.wm_state_name):
            raise BackendError('STATE_POINTER_ALREADY_EXISTS')
        for cls in all_classes:
            if self._registered_class(cls) is not None:
                raise BackendError('CLASS_ALREADY_REGISTERED', name=cls.__name__)
        try:
            self._translations_owned = True
            self.bpy.app.translations.register(self._translation_key, {'ja_JP': dict(self._translations), 'ja': dict(self._translations)})
            self._register_one(self.preview_class, self._groups_owned)
            self._register_one(self.state_class, self._groups_owned)
            if self.wm_state_name in rna_fields(self.bpy.types.WindowManager) or hasattr(self.bpy.types.WindowManager, self.wm_state_name):
                raise BackendError('STATE_POINTER_ALREADY_EXISTS')
            # This is a pending ownership record until readback confirms creation.
            self._pointer_owned = True
            setattr(self.bpy.types.WindowManager, self.wm_state_name,
                    self.bpy.props.PointerProperty(type=self.state_class))
            if self._pointer_class() is not self.state_class:
                raise BackendError('STATE_POINTER_NOT_CONFIRMED')
            for cls in ui_classes:
                self._register_one(cls, self._ui_owned)
            self.adapter.reopen()
            self._registered = True
        except Exception as exc:
            cleanup = None
            try:
                self.unregister()
            except Exception as failure:
                cleanup = getattr(failure, 'code', type(failure).__name__)
            raise BackendError('REGISTER_FAILED', cause=getattr(exc, 'code', type(exc).__name__),
                               cleanup_error=cleanup, remaining=self.owned_summary()) from exc
        return self.owned_summary()

    def _unregister_ledger(self, ledger):
        while ledger:
            cls = ledger[-1]
            current = self._registered_class(cls)
            if current is None:
                ledger.pop()
                continue
            if current is not cls:
                raise BackendError('REGISTRATION_OWNERSHIP_CHANGED', name=cls.__name__)
            try:
                self.bpy.utils.unregister_class(cls)
            except Exception as exc:
                if self._registered_class(cls) is None:
                    ledger.pop()
                    continue
                raise BackendError('UNREGISTER_FAILED', name=cls.__name__) from exc
            if self._registered_class(cls) is not None:
                raise BackendError('UNREGISTER_NOT_APPLIED', name=cls.__name__)
            ledger.pop()

    def unregister(self):
        if threading.get_ident() != self._thread:
            raise BackendError('WRONG_THREAD')
        self._registered = False
        self.adapter.close()
        # A remaining UI class cannot dispatch edits, but keeps its dependencies for retry.
        self._unregister_ledger(self._ui_owned)
        for port in self._ports:
            if not port._closed:
                port.close()
        self._ports.clear()
        if not self._pointer_owned and self.state_class in self._groups_owned:
            if self.wm_state_name in rna_fields(self.bpy.types.WindowManager) or hasattr(self.bpy.types.WindowManager, self.wm_state_name):
                # Another owner attached a pointer while our groups were registering.
                # Preserve that pointer and its possible dependencies for retry.
                raise BackendError('STATE_POINTER_OWNERSHIP_CHANGED')
        if self._pointer_owned:
            current = self._pointer_class()
            if current is not None and current is not self.state_class:
                raise BackendError('STATE_POINTER_OWNERSHIP_CHANGED')
            if current is self.state_class:
                delattr(self.bpy.types.WindowManager, self.wm_state_name)
                if self._pointer_class() is not None:
                    raise BackendError('STATE_POINTER_REMOVE_FAILED')
            self._pointer_owned = False
        self._unregister_ledger(self._groups_owned)
        if self._translations_owned:
            self.bpy.app.translations.unregister(self._translation_key)
            self._translations_owned = False
        return self.owned_summary()

    def owned_summary(self):
        return dict(registered=self._registered, ui_classes=[cls.__name__ for cls in self._ui_owned],
                    property_groups=[cls.__name__ for cls in self._groups_owned],
                    state_pointer=self.wm_state_name if self._pointer_owned else None,
                    translation_key=self._translation_key if self._translations_owned else None,
                    ports=len(self._ports))
