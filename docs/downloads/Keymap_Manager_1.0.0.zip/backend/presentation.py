# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Build immutable UI-contract values outside Blender draw callbacks."""
from collections import OrderedDict
import json
from pathlib import Path

from . import queries
from .model import MODIFIERS, canonical, digest

_DECLARATIONS = json.loads(Path(__file__).with_name('public_declarations.json').read_text(encoding='utf-8'))['declarations']
_STATE = tuple(next(item['properties'] for item in _DECLARATIONS if item['public_class'] == 'KMM_State'))

_JA = {
    'selected_type': ('キー', '調べたいキーや入力機器の操作を選びます。修飾キーの条件と組み合わせて、登録済みの割り当てを絞り込みます。'),
    'selected_value': ('入力状態', '押す、離す、クリック、ドラッグなどを選びます。「入力状態を一致」が有効なときに検索条件として使います。'),
    'selected_key_modifier': ('追加のキー修飾', '通常の修飾キーとは別に、同時に押すキーを選びます。「修飾キーを一致」が有効なときに照合します。'),
    'use_exact_modifiers': ('修飾キーを一致', '有効にすると修飾キーと追加のキー修飾を照合します。「任意」の条件を持つ割り当ては、押す場合と押さない場合の両方に一致します。'),
    'use_exact_value': ('入力状態を一致', '有効にすると選択した入力状態で絞り込みます。無効にすると同じキーの押下、解放、クリック、ドラッグなどをまとめて表示します。'),
    'include_disabled': ('無効な割り当ても表示', '無効にされた割り当ても一覧に含めます。無効な割り当ては、有効に戻すまで実行されません。'),
    'operator_id_query': ('オペレーター識別子', 'wm.save_mainfile のような内部名を入力します。その機能の割り当てと、同じショートカット条件を持つ割り当てを調べられます。'),
    'view_mode': ('表示方法', '通常、競合、未使用、キー別の表示を切り替えます。表示方法の変更だけでは割り当てを変更しません。'),
    'unused_parent_key': ('未使用キーの親カテゴリー', '空いている候補を探す登録先の大分類です。表示されたカテゴリーから選択してください。'),
    'unused_child_key': ('未使用キーの子カテゴリー', '親カテゴリーに属する具体的な登録先です。この登録先に条件が重なる割り当てがない候補を表示します。'),
    'consolidation_preview_index': ('重複整理の選択行', '確認中の一覧で選択している行です。行を選ぶだけでは割り当てを削除しません。'),
    'visual_editor_filter': ('エディターの絞り込み', 'キー別の表示を、選択したエディターの登録先に絞り込みます。すべてを選ぶと絞り込みを解除します。'),
    'visual_mode_filter': ('モードの絞り込み', 'キー別の表示を、選択したキーマップ名に絞り込みます。実行時に存在する登録先から選びます。'),
    'visual_search_text': ('検索文字', 'キー別の表示で、機能の内部名、表示名、登録場所、ショートカット表記を検索します。空にすると文字による絞り込みを解除します。'),
    'export_path': ('書き出し先', 'ユーザーのキー設定を保存するJSONファイルを指定します。空の場合は、統合時に指定された保存領域の既定ファイルを使用します。'),
    'import_path': ('読み込み元', '追加したいキー設定のJSONファイルを指定します。読み込みは追加方式で、既存の割り当てを一括削除しません。'),
    'export_scope': ('書き出す範囲', '変更済みだけを保存するか、ユーザーの全割り当てを保存するか選びます。名前付きプリセットの保存では全件を使用します。'),
    'preset_name': ('プリセット名', '現在のユーザー設定一式を保存する名前です。同名の保存済みプリセットがある場合は上書きします。フォルダー区切り文字は使用できません。'),
    'preset_select': ('プリセット', '読み込みまたは削除する名前付きプリセットを選びます。削除すると選択したファイルが削除されますが、現在の割り当ては残ります。'),
}
_SECTIONS = {
    'keyboard': ('Keyboard', 'キーボード'), 'mouse': ('Mouse', 'マウス'),
    'ndof': ('3D Mouse', '3Dマウス'), 'key_filter': ('Key Filters', 'キーの絞り込み'),
    'io': ('Import and Export', '読み込みと書き出し'), 'registered': ('Registered Bindings', '登録済みの割り当て'),
}
_EXPANDED = {
    'expanded_unused_parent_keys': ('Expanded Unused Categories', '開いている未使用カテゴリー'),
    'expanded_unused_base_keys': ('Expanded Unused Keys', '開いている未使用キー'),
    'expanded_item_keys': ('Expanded Binding Details', '開いている割り当ての詳細'),
    'expanded_visual_key_groups': ('Expanded Visual Key Groups', '開いているキー別グループ'),
}
_VALUE_JA = {'NONE': '未選択', 'ALL': 'すべて', 'MODIFIED': '変更済みのみ',
             'PRESS': '押す', 'RELEASE': '離す', 'CLICK': 'クリック', 'DOUBLE_CLICK': 'ダブルクリック',
             'CLICK_DRAG': 'ドラッグ', 'ANY': '任意', 'NOTHING': 'なし',
             'NORMAL': '通常', 'CONFLICT': '競合', 'UNUSED': '未使用', 'VISUAL': 'キー別',
             'NORTH': '上', 'SOUTH': '下', 'EAST': '右', 'WEST': '左',
             'NORTH_EAST': '右上', 'NORTH_WEST': '左上', 'SOUTH_EAST': '右下', 'SOUTH_WEST': '左下'}
_ITEM = {
    'active': ('Active', '有効', 'Enable this binding. Turning it off preserves the binding but prevents it from running.', 'この割り当てを有効にします。無効にしても登録は残りますが、実行されなくなります。'),
    'type': ('Key', 'キー', 'Choose the physical key or input event for this binding.', 'この割り当てで使用するキーや入力機器の操作を選びます。'),
    'value': ('Input State', '入力状態', 'Choose whether this binding responds to a press, release, click, or another supported event value.', '押す、離す、クリックなど、この割り当てが反応する入力状態を選びます。'),
    'direction': ('Drag Direction', 'ドラッグ方向', 'Choose the direction used by directional drag events. Any accepts every direction.', '方向を持つドラッグ入力の条件を選びます。任意では方向を限定しません。'),
    'key_modifier': ('Additional Key Modifier', '追加のキー修飾', 'Choose a secondary key that must be held together with the main key, or None.', '主キーと同時に押す追加のキーを選びます。追加キーが不要な場合は未選択にします。'),
    'any': ('Any Modifier Combination', 'すべての修飾キー条件を任意', 'Accept modifier combinations without requiring a particular Ctrl, Shift, Alt, OS Key, or Hyper state.', 'Ctrl、Shift、Alt、OSキー、Hyperを押すかどうかにかかわらず受け付ける条件にします。'),
    'repeat': ('Repeat', 'キーリピート', 'Allow repeated key-press events while the key remains held, when supported by the event.', '対応する入力で、キーを押し続けたときの繰り返し入力を受け付けます。'),
    'propvalue': ('Modal Action', 'モーダル中の操作', 'Choose an action declared by this existing modal keymap. The choices belong to this particular keymap.', 'このモーダルキーマップで定義された操作を選びます。選択肢は対象の登録先から取得します。'),
}
_ERRORS = {
    'STALE_REVISION': ('The bindings or settings changed. Refresh the list and review the current values.', '割り当てまたは設定が変わりました。一覧を更新し、現在の内容を確認してください。'),
    'STALE_PREVIEW': ('The duplicate preview is out of date. Open a new preview before consolidating.', '重複整理の確認内容が古くなりました。改めて確認画面を開いてください。'),
    'CONFIRMATION_REQUIRED': ('Open the duplicate preview and confirm its original token before deleting bindings.', '重複整理の確認画面を開き、その確認内容に対して実行してください。'),
    'TARGET_NOT_FOUND': ('The selected binding is no longer present. Refresh the list.', '選択した割り当てが見つかりません。一覧を更新してください。'),
    'NO_HIGHER': ('No supported higher-priority source was found for this binding.', 'この割り当てについて、切り替え可能な上位優先元は見つかりませんでした。'),
    'REFRESH_REQUIRED': ('Refresh this window before editing bindings or settings.', '割り当てや設定を編集する前に、このウィンドウの一覧を更新してください。'),
    'READBACK_FAILED': ('The current state could not be read after the operation. Refresh before making another change.', '操作後の現在状態を読み取れませんでした。次の変更を行う前に更新してください。'),
    'REENTRANT_CALL': ('Another operation is already in progress in this adapter.', 'この接続部では別の操作を処理中です。'),
    'WRONG_THREAD': ('Run this operation on Blender\'s main thread.', 'この操作はBlenderのメインスレッドで実行してください。'),
    'INVALID_REQUEST': ('The request does not match the UI data contract.', '操作要求がUIのデータ契約に一致していません。'),
    'SNAPSHOT_FAILED': ('The operation result could not be prepared for display. Refresh before continuing.', '操作結果を表示用に準備できませんでした。続ける前に更新してください。'),
}


def text(c, en, ja=None):
    return c.Text(str(en), str(en if ja is None else ja))


def state_text(c, declaration):
    name = declaration['identifier']
    label_en = declaration.get('name') or name.replace('_', ' ').title()
    help_en = declaration.get('description') or 'Change this display setting. This setting does not edit a keymap binding.'
    if name in _JA:
        label_ja, help_ja = _JA[name]
    elif name.startswith('selected_') and name[9:] in MODIFIERS:
        modifier = {'oskey': 'OSキー', 'hyper': 'Hyper'}.get(name[9:], name[9:].title())
        label_ja = modifier
        help_ja = modifier + 'を押す条件で検索します。「修飾キーを一致」が有効な場合に照合し、任意条件の割り当ては両方の状態に一致します。'
    elif name.startswith('section_') and name.endswith('_open'):
        label_en, label_ja = _SECTIONS[name[8:-5]]
        help_en = 'Open or close the ' + label_en + ' section. This changes only the display.'
        help_ja = label_ja + 'の説明と操作欄を開閉します。開閉だけでは割り当てを変更しません。'
    elif name in _EXPANDED:
        label_en, label_ja = _EXPANDED[name]
        help_en = 'Remember which groups are expanded in this session. Use the group disclosure buttons to change this value.'
        help_ja = 'このセッションで開いている項目を記憶します。各グループの展開ボタンから変更します。'
    else:
        label_ja, help_ja = name, 'この表示設定の値です。割り当てそのものを変更する操作とは区別して扱います。'
    return text(c, label_en, label_ja), text(c, help_en, help_ja)


def enum_choice(c, key, option=None, *, label_en=None, label_ja=None, help_en=None, help_ja=None):
    en = label_en or (option.label_en if option else '') or key
    ja = label_ja or (option.label_ja if option else '') or _VALUE_JA.get(key, key)
    en_help = help_en or (option.help_en if option else '') or ('Choose ' + en + '.')
    ja_help = help_ja or (option.help_ja if option else '') or (ja + 'を選択します。')
    return c.Choice(key, text(c, en, ja), text(c, en_help, ja_help))


def state_choices(c, engine, declaration):
    name = declaration['identifier']
    option_name = {'selected_type': 'type', 'selected_value': 'value', 'selected_key_modifier': 'key_modifier'}.get(name)
    options = {option.key: option for option in engine.scan.options(option_name)} if option_name else {}
    declared = {row[0]: row for row in declaration.get('items', ())}
    choices = []
    for key in engine.choices(name):
        label = key[7:] if name == 'preset_select' and key.startswith('preset:') else None
        row = declared.get(key)
        choices.append(enum_choice(c, key, options.get(key), label_en=label or (row[1] if row else None),
                                   label_ja=label, help_en=row[2] if row else None))
    return tuple(choices)


def item_fields(c, engine, row, enabled):
    fields = []
    for name in ('active', 'type', 'value', 'direction', 'key_modifier', 'any', 'repeat') + (('propvalue',) if row.key.is_modal else ()):
        en, ja, en_help, ja_help = _ITEM[name]
        value = row.active if name == 'active' else row.propvalue if name == 'propvalue' else getattr(row.event, name)
        kind = 'BOOL' if type(value) is bool else 'ENUM'
        choices = tuple(enum_choice(c, option.key, option) for option in engine.scan.options(name, row.key.location)) if kind == 'ENUM' else ()
        fields.append(c.Field(name, kind, value, text(c, en, ja), text(c, en_help, ja_help), choices, enabled and (kind != 'ENUM' or bool(choices))))
    for name, value in row.properties.items():
        if type(value) not in (str, bool, int, float):
            continue
        kind = 'BOOL' if type(value) is bool else 'INT' if type(value) is int else 'STRING'
        shown = repr(value) if type(value) is float else value
        hint_en = 'Edit the explicitly stored operator setting named ' + name + '. The backend validates the value against the current operator before writing.'
        hint_ja = '明示的に保存されているオペレーター設定「' + name + '」を編集します。書き込む前に、現在のオペレーターの型と値の条件を確認します。'
        fields.append(c.Field('properties.' + name, kind, shown, text(c, name), text(c, hint_en, hint_ja), (), enabled))
    return tuple(fields)


def outcome(c, action, help_topics=None):
    data = action.data
    code = action.code
    if data.get('help_topic') in (help_topics or {}):
        en, ja = help_topics[data['help_topic']]
    elif action.deleted_count is not None:
        count = action.deleted_count
        if action.status in ('ERROR', 'PARTIAL'):
            en, ja = ('Deletion stopped. Confirmed removed bindings: ' + str(count) + '. (' + code + ')',
                      '削除処理を停止しました。削除を確認できた割り当ては' + str(count) + '件です。(' + code + ')')
        elif action.status == 'PREVIEW':
            en, ja = ('Review the bindings to keep and remove before confirming.', '残す割り当てと削除する割り当てを確認してから実行してください。')
        elif action.status == 'CANCELLED':
            en, ja = ('The duplicate preview was cancelled. No binding was deleted.', '重複整理をキャンセルしました。割り当ては削除していません。')
        elif code == 'NO_DUPLICATES':
            en, ja = ('No duplicate keymaps were found to consolidate.', '集約対象の重複キーマップは見つかりませんでした。')
        else:
            en, ja = ('Removed ' + str(count) + ' bindings.', str(count) + '件の割り当てを削除しました。')
    elif 'imported' in data:
        imported, failed, duplicates = data.get('imported', 0), data.get('failed', 0), data.get('duplicates', 0)
        en = f'Added {imported}; already present {duplicates}; failed {failed}.'
        ja = f'追加{imported}件、既存と一致{duplicates}件、読み込めなかった割り当て{failed}件です。'
        if data.get('invalid_groups'):
            en += ' Invalid keymap groups: ' + str(data['invalid_groups']) + '.'
            ja += ' 不正な登録先グループは' + str(data['invalid_groups']) + '件です。'
    elif 'exported' in data or 'saved' in data:
        count = data.get('exported', data.get('saved', 0))
        en, ja = (f'Saved {count} user bindings.', f'ユーザーの割り当てを{count}件保存しました。')
    elif code in _ERRORS:
        en, ja = _ERRORS[code]
    elif action.status in ('ERROR', 'PARTIAL'):
        en, ja = ('The operation could not be completed. (' + code + ')', '操作を完了できませんでした。(' + code + ')')
    elif action.status == 'PREVIEW':
        en, ja = ('Review the duplicate bindings before confirming.', '重複する割り当ての確認内容を確認してから実行してください。')
    elif action.status == 'CANCELLED':
        en, ja = ('The operation was cancelled.', '操作をキャンセルしました。')
    elif action.status == 'NO_CHANGE':
        en, ja = ('There was no change.', '変更はありません。')
    elif code == 'READY':
        en, ja = ('The current bindings are ready to inspect.', '現在の割り当てを確認できます。')
    else:
        en, ja = ('The operation completed.', '操作を完了しました。')
    # Keep operation-specific detail in the message while exposing the UI contract's statuses.
    status = {"PREVIEW": "OK", "NO_DUPLICATES": "NO_CHANGE", "PARTIAL": "ERROR"}.get(action.status, action.status)
    return c.Outcome(status, text(c, en, ja), action.deleted_count)


def cold_snapshot(c, revision='initial-refresh', code='REFRESH_REQUIRED'):
    en, ja = _ERRORS.get(code, _ERRORS['REFRESH_REQUIRED'])
    return c.Snapshot(revision=revision, messages=(text(c, en, ja),))


def render(c, engine, *, revision, language='en'):
    values, scan = engine.values, engine.scan
    usable = not engine._invalid
    state_fields = []
    for declaration in _STATE:
        name = declaration['identifier']
        if declaration['type'] == 'CollectionProperty':
            continue
        label, help_value = state_text(c, declaration)
        kind = {'BoolProperty': 'BOOL', 'IntProperty': 'INT', 'StringProperty': 'TEXT', 'EnumProperty': 'ENUM'}[declaration['type']]
        choices = state_choices(c, engine, declaration) if kind == 'ENUM' else ()
        enabled = usable and not (values['view_mode'] == 'UNUSED' and name in ('selected_type', 'selected_value'))
        state_fields.append(c.Field(name, kind, values[name], label, help_value, choices, enabled))
    records = tuple(row for row in scan.records if row.role in ('USER', 'ADDON'))
    refs = {row.key: c.RowRef(**row.key.ui_arguments()) for row in records}
    bindings = []
    for row in records:
        higher = tuple(refs[source.key] for source in queries.higher_sources(scan, row) if source.key in refs)
        details = []
        role = engine.roles.get(row.key)
        if role == 'assigned':
            details.append(text(c, 'Assigned to the searched operator.', '検索したオペレーターに割り当てられています。'))
        elif role == 'same_event':
            details.append(text(c, 'Uses the same event as a binding assigned to the searched operator.', '検索したオペレーターの割り当てと同じ入力条件を使用しています。'))
        for name, value in row.properties.items():
            if type(value) not in (str, bool, int, float):
                details.append(text(c, name + ': ' + canonical(value)))
        for issue in getattr(row, 'property_issues', ()):
            details.append(text(c, 'Property preservation requires review: ' + issue, 'プロパティの保存には確認が必要です: ' + issue))
        editable = usable and row.editable and getattr(row, 'portable', True)
        registration = ' / '.join((row.key.keyconfig_name, row.key.keymap_name, row.key.space_type, row.key.region_type))
        bindings.append(c.Binding(ref=refs[row.key], label=text(c, row.label_en or row.identity, row.label_ja or row.label_en or row.identity),
                                  registration=text(c, registration), shortcut=text(c, queries.shortcut(row.event, 'en'), queries.shortcut(row.event, 'ja')),
                                  status=queries.binding_status(scan, row), active=row.active,
                                  operator_id='' if row.key.is_modal else row.idname, fields=item_fields(c, engine, row, editable),
                                  modifiers=tuple((name, 'ANY' if row.event.any or getattr(row.event, name) == -1 else 'ON' if getattr(row.event, name) else 'OFF') for name in MODIFIERS),
                                  higher_sources=higher, details=tuple(details), editable=editable))
    groups = []
    if values['view_mode'] == 'VISUAL':
        grouped = OrderedDict()
        for row in engine.visible:
            grouped.setdefault(row.event.type, []).append(row)
        for key, rows in grouped.items():
            groups.append(c.Group(key, text(c, key), tuple(refs[row.key] for row in rows), sum(row.active for row in rows), sum(not row.active for row in rows)))
    elif values['view_mode'] == 'CONFLICT':
        for rows in queries.conflict_groups(scan.records):
            visible = [row for row in rows if row.key in refs]
            if len(visible) > 1:
                first = visible[0]
                label = first.key.keymap_name + ': '
                groups.append(c.Group('conflict:' + digest([row.key.values() for row in visible]),
                                      text(c, label + queries.shortcut(first.event, 'en'), label + queries.shortcut(first.event, 'ja')),
                                      tuple(refs[row.key] for row in visible), len(visible), 0))
    selected_types = {row.event.type for row in engine.visible} if values['view_mode'] == 'VISUAL' or values['operator_id_query'].strip() else {values['selected_type']}
    events = []
    for option in scan.options('type'):
        if option.key == 'NONE':
            continue
        kind = 'ndof' if option.key.startswith('NDOF_') else 'mouse' if 'MOUSE' in option.key or option.key.startswith('WHEEL') else 'keyboard'
        choice = enum_choice(c, option.key, option)
        events.append(c.Event(option.key, option.key, choice.label, choice.help, kind, usable and values['view_mode'] != 'UNUSED', option.key in selected_types))
    categories = tuple(c.Category(parent.key, text(c, parent.label_en, parent.label_ja),
                                  text(c, 'Select a registration category to inspect unused candidates.', '未使用候補を調べる登録先のカテゴリーを選びます。'),
                                  tuple(c.Choice(child.key, text(c, child.label_en, child.label_ja),
                                                 text(c, 'Inspect candidates within this keymap location.', 'この登録場所の中で未使用の候補を調べます。')) for child in parent.children)) for parent in engine.categories)
    unused = OrderedDict()
    for event in engine.unused:
        unused.setdefault(event.type, []).append(text(c, queries.shortcut(event, 'en'), queries.shortcut(event, 'ja')))
    unused_groups = tuple(c.UnusedGroup(key, text(c, key), tuple(candidates), len(candidates)) for key, candidates in unused.items())
    preview = None
    if engine.preview is not None:
        preview_groups = tuple(c.PreviewGroup(text(c, group[0].key.keymap_name), (refs[group[0].key],), tuple(refs[row.key] for row in group[1:])) for group in engine.preview.groups)
        preview = c.Preview(engine.preview.token, revision, preview_groups, len(engine.preview.remove))
    messages = []
    if engine.last_result.code != 'READY':
        messages.append(outcome(c, engine.last_result, engine.help_topics).message)
    if any(binding.higher_sources for binding in bindings):
        messages.append(text(c, 'Priority status is an estimate based on the supplied registration relationships. It does not guarantee operator poll or event handling in every context.',
                             '優先状態は、確認できた登録先の関係に基づく推定です。すべての状況での実行可否や入力処理を保証する表示ではありません。'))
    topics = tuple((key, pair[1] if language == 'ja' else pair[0]) for key, pair in engine.help_topics.items())
    return c.Snapshot(revision=revision, fields=tuple(state_fields), rows=tuple(bindings),
                      visible_rows=tuple(refs[row.key] for row in engine.visible), match_count=len(engine.visible),
                      view_mode=values['view_mode'], events=tuple(events), groups=tuple(groups), categories=categories,
                      unused_groups=unused_groups, selected_parent=values['unused_parent_key'], selected_child=values['unused_child_key'],
                      can_back=bool(values['unused_parent_key'] or values['unused_child_key']), preview=preview,
                      help_topics=topics, messages=tuple(messages),
                      no_selection=values['view_mode'] == 'NORMAL' and values['selected_type'] == 'NONE' and not values['operator_id_query'].strip(),
                      needs_initial_keymap=scan.needs_initial_keymap)
