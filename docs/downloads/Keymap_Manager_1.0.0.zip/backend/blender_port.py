# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Public-RNA connection for Blender 5.1, with no import-time Blender access.

Instantiate with the real bpy module only at Root's integration/acceptance stage.
The verification suite injects ordinary Python stand-ins. No preset is executed
unless its explicit, Root-approved path and containing directory are supplied.
"""
from collections import defaultdict
from dataclasses import replace
from pathlib import Path
import re
import threading

from .model import (BackendError, EnumOption, EventData, MapInfo, MODIFIERS,
                    Record, RowKey, Scan, canonical, digest, events_overlap)
from .rna_properties import PropertyAccess

_EVENT_NAMES = tuple(EventData.__dataclass_fields__)
_OPERATOR = re.compile(r'^[a-zA-Z_][a-zA-Z_0-9]*\.[a-zA-Z_][a-zA-Z_0-9]*$')
_JA_ENUM = {'NONE': '未選択', 'PRESS': '押す', 'RELEASE': '離す', 'CLICK': 'クリック',
            'DOUBLE_CLICK': 'ダブルクリック', 'CLICK_DRAG': 'ドラッグ', 'ANY': '任意',
            'NOTHING': 'なし', 'LEFTMOUSE': 'マウス左ボタン', 'MIDDLEMOUSE': 'マウス中央ボタン',
            'RIGHTMOUSE': 'マウス右ボタン', 'WHEELUPMOUSE': 'ホイール上', 'WHEELDOWNMOUSE': 'ホイール下',
            'NORTH': '上', 'SOUTH': '下', 'EAST': '右', 'WEST': '左',
            'NORTH_EAST': '右上', 'NORTH_WEST': '左上', 'SOUTH_EAST': '右下', 'SOUTH_WEST': '左下'}


def pointer(value):
    method = getattr(value, 'as_pointer', None)
    if not callable(method):
        raise BackendError('MISSING_RNA_CAPABILITY', name='as_pointer')
    result = method()
    if type(result) is not int or result <= 0:
        raise BackendError('STALE_RNA_REFERENCE')
    return result


def rna_fields(owner):
    try:
        return {field.identifier: field for field in owner.bl_rna.properties}
    except (AttributeError, ReferenceError, RuntimeError, TypeError) as exc:
        raise BackendError('MISSING_RNA_CAPABILITY', name='bl_rna.properties') from exc


def options_from_items(items):
    result = []
    seen = set()
    for item in items:
        key = item.identifier
        if not key or key in seen:
            continue
        seen.add(key)
        label = item.name or key
        help_en = item.description or ('Choose ' + label + '.')
        result.append(EnumOption(key, label, help_en, _JA_ENUM.get(key, key),
                                 _JA_ENUM.get(key, key) + 'を選択します。実行時にこの登録先が提供する入力条件です。'))
    return tuple(result)


class BpyPort:
    def __init__(self, bpy_module, context, *, priority_policy=None,
                 standard_preset_path=None, trusted_preset_root=None):
        self.bpy = bpy_module
        self.context = context
        self.wm = getattr(context, 'window_manager', None)
        if self.wm is None:
            raise BackendError('INVALID_CONTEXT')
        self._thread = threading.get_ident()
        self._priority_policy = priority_policy
        self._standard_path = Path(standard_preset_path) if standard_preset_path is not None else None
        self._standard_root = Path(trusted_preset_root) if trusted_preset_root is not None else None
        self._standard_loaded = False
        self._closed = False
        self.properties = PropertyAccess(self.bpy.types.OperatorProperties)
        fields = rna_fields(self.bpy.types.KeyMapItem)
        required = set(_EVENT_NAMES) | {'id', 'idname', 'propvalue', 'active', 'properties', 'is_user_defined', 'is_user_modified'}
        missing = sorted(required - set(fields))
        if missing:
            raise BackendError('MISSING_RNA_CAPABILITY', names=missing)
        self._event_enums = tuple((name, self._type_options(self.bpy.types.KeyMapItem, name))
                                 for name in ('type', 'value', 'direction', 'key_modifier'))

    def _guard(self):
        if self._closed:
            raise BackendError('PORT_CLOSED')
        if threading.get_ident() != self._thread:
            raise BackendError('WRONG_THREAD')
        pointer(self.wm)

    @staticmethod
    def _type_options(owner, name):
        field = rna_fields(owner).get(name)
        if field is None or field.type != 'ENUM':
            raise BackendError('MISSING_RNA_CAPABILITY', name=name)
        return options_from_items(field.enum_items)

    def _configs(self):
        configs = self.wm.keyconfigs
        rows, seen, names = [], set(), {}
        for role, attribute in (('USER', 'user'), ('ADDON', 'addon'), ('DEFAULT', 'default'), ('ACTIVE', 'active')):
            config = getattr(configs, attribute, None)
            if config is None:
                continue
            identity = pointer(config)
            if identity in seen:
                continue
            name = config.name
            if name in names and names[name] != identity:
                raise BackendError('AMBIGUOUS_KEYCONFIG', name=name)
            names[name] = identity
            seen.add(identity)
            rows.append((role, config))
        return tuple(rows)

    def _user(self):
        rows = [config for role, config in self._configs() if role == 'USER']
        if len(rows) != 1:
            raise BackendError('USER_KEYCONFIG_UNAVAILABLE')
        return rows[0]

    @staticmethod
    def _map_location(km):
        return (km.name, km.space_type, km.region_type, km.is_modal)

    @staticmethod
    def _tool_flag(km):
        # The public runtime metadata, rather than a guessed attribute, decides availability.
        return bool(getattr(km, 'is_tool')) if 'is_tool' in rna_fields(km) else False

    def _record(self, role, config, km, item, order):
        key = RowKey(config.name, km.name, km.space_type, km.region_type, km.is_modal, item.id)
        identity = digest((pointer(config), pointer(km), pointer(item)))
        event = EventData.from_mapping({name: getattr(item, name) for name in _EVENT_NAMES})
        values, property_issues = self.properties.capture(item.properties)
        issues = list(property_issues)
        if not (item.propvalue if km.is_modal else item.idname):
            issues.append('binding: UNASSIGNED_IDENTITY')
        portable = not issues
        label = item.name if 'name' in rna_fields(item) else item.propvalue if km.is_modal else item.idname
        editable = role in ('USER', 'ADDON') and portable and not item.is_property_readonly('active')
        view = getattr(getattr(self.context, 'preferences', None), 'view', None)
        locale = getattr(view, 'language', 'en_US')
        if locale == 'DEFAULT':
            locale = getattr(getattr(self.bpy.app, 'translations', None), 'locale', '')
        source_language = 'en' if not getattr(view, 'use_translate_interface', True) else str(locale).lower()
        neutral_label = item.propvalue if km.is_modal else item.idname
        label_en = label if source_language.startswith('en') else neutral_label
        label_ja = label if source_language.startswith('ja') else neutral_label
        return Record(key=key, role=role, order=order, identity_token=identity,
                      idname=item.idname, propvalue=item.propvalue, active=item.active, event=event,
                      properties_text=canonical(values), label_en=label_en, label_ja=label_ja,
                      editable=editable, modified=bool(item.is_user_defined or item.is_user_modified),
                      portable=portable, property_issues=tuple(issues))

    def _priority(self, rows, maps):
        if self._priority_policy is not None:
            contexts, relations = self._priority_policy(tuple(rows), tuple(maps))
            keys = {row.key for row in rows}
            if any(key not in keys for key in contexts) or any(key not in keys for key in relations):
                raise BackendError('INVALID_PRIORITY_POLICY')
            normalized = []
            for target, sources in relations.items():
                values = tuple(sources)
                if len(values) > len(rows) or any(source not in keys or source == target for source in values):
                    raise BackendError('INVALID_PRIORITY_POLICY')
                normalized.append((target, values))
            records = tuple(replace(row, contexts=tuple(contexts.get(row.key, ()))) for row in rows)
            return records, tuple(normalized)
        # Conservative candidate estimate: earlier rows in the same exact map only.
        # This does not reproduce operator poll, cross-editor handlers, or modal dispatch.
        grouped = defaultdict(list)
        records, relations, comparisons = [], [], 0
        for row in rows:
            context = canonical(row.key.location)
            current = replace(row, contexts=(context,) if not row.key.is_modal else ())
            records.append(current)
            if row.role not in ('USER', 'ADDON') or row.key.is_modal:
                continue
            group = grouped[(row.key.location, row.event.type)]
            higher = []
            for previous in group:
                comparisons += 1
                if comparisons > 200000:
                    raise BackendError('PRIORITY_RESOURCE_LIMIT')
                if previous.active and events_overlap(previous.event, row.event):
                    higher.append(previous.key)
            if higher:
                relations.append((row.key, tuple(higher)))
            group.append(current)
        return tuple(records), tuple(relations)

    def scan(self):
        self._guard()
        rows, maps, modal, locations = [], [], [], set()
        for role, config in self._configs():
            for km in config.keymaps:
                info = MapInfo(config.name, role, km.name, km.space_type, km.region_type, km.is_modal, self._tool_flag(km))
                if info.location in locations:
                    raise BackendError('AMBIGUOUS_KEYMAP', location=list(info.location))
                locations.add(info.location)
                maps.append(info)
                if km.is_modal:
                    modal.append((info.location, options_from_items(km.modal_event_values)))
                for item in km.keymap_items:
                    rows.append(self._record(role, config, km, item, len(rows)))
                    if len(rows) > 100000:
                        raise BackendError('ROW_LIMIT')
        records, higher = self._priority(rows, maps)
        populated = any(row.role in ('USER', 'ADDON', 'DEFAULT') for row in records)
        return Scan(records, tuple(maps), self._event_enums, tuple(modal), higher, not populated)

    def _locate(self, expected):
        self._guard()
        found = []
        for role, config in self._configs():
            if config.name != expected.key.keyconfig_name:
                continue
            for km in config.keymaps:
                if self._map_location(km) != expected.key.map_location:
                    continue
                for item in km.keymap_items:
                    if item.id == expected.key.kmi_id:
                        found.append((role, config, km, item))
        if len(found) != 1:
            raise BackendError('TARGET_NOT_FOUND' if not found else 'AMBIGUOUS_TARGET')
        role, config, km, item = found[0]
        current = self._record(role, config, km, item, expected.order)
        if current.identity_token != expected.identity_token:
            raise BackendError('TARGET_REPLACED')
        if current.content_key() != expected.content_key():
            raise BackendError('TARGET_CHANGED')
        return role, config, km, item, current

    def _item_options(self, name, km):
        if name == 'propvalue':
            return options_from_items(km.modal_event_values) if km.is_modal else ()
        return dict(self._event_enums).get(name, ())

    def validate_fields(self, expected, patch):
        role, config, km, item, current = self._locate(expected)
        if not current.editable or role not in ('USER', 'ADDON'):
            raise BackendError('READ_ONLY_TARGET')
        normalized = {}
        for name, value in patch.items():
            if name.startswith('properties.'):
                property_name = name[len('properties.'):]
                if property_name not in current.properties or '.' in property_name:
                    raise BackendError('UNKNOWN_PROPERTY', field=property_name)
                normalized[name] = self.properties.normalize(item.properties, property_name, value, ui=True)
                continue
            if name not in _EVENT_NAMES and name not in ('active', 'propvalue'):
                raise BackendError('INVALID_ITEM_FIELD', field=name)
            if item.is_property_readonly(name):
                raise BackendError('READ_ONLY_PROPERTY', field=name)
            if name == 'active' or name in ('any', 'repeat'):
                if type(value) is not bool:
                    raise BackendError('INVALID_ITEM_VALUE', field=name)
            elif name in MODIFIERS:
                if type(value) is not int or value not in (-1, 0, 1):
                    raise BackendError('INVALID_MODIFIER', field=name)
            else:
                if type(value) is not str or value not in {choice.key for choice in self._item_options(name, km)}:
                    raise BackendError('INVALID_CHOICE', field=name)
            normalized[name] = value
        proposed = current.event.as_dict()
        proposed.update({name: value for name, value in normalized.items() if name in _EVENT_NAMES})
        EventData.from_mapping(proposed)
        return normalized

    def _set(self, item, patch):
        # Any is written before individual modifiers because the RNA setters may couple them.
        order = ('type', 'value', 'direction', 'key_modifier', 'any', *MODIFIERS, 'repeat', 'propvalue', 'active')
        for name in order:
            if name in patch:
                setattr(item, name, patch[name])
        for name, value in patch.items():
            if name.startswith('properties.'):
                self.properties.apply(item.properties, {name[len('properties.'):]: value})

    def set_fields(self, expected, patch):
        normalized = self.validate_fields(expected, patch)
        _, _, _, item, _ = self._locate(expected)
        self._set(item, normalized)

    def capture_fields(self, expected, patch):
        _, _, _, item, current = self._locate(expected)
        values = current.event.as_dict() if set(patch).intersection(_EVENT_NAMES) else {}
        for name in ('active', 'propvalue'):
            if name in patch:
                values[name] = getattr(current, name)
        properties = tuple(self.properties.field_checkpoint(item.properties, name[len('properties.'):])
                           for name in patch if name.startswith('properties.'))
        return dict(fields=values, properties=properties)

    def restore_fields(self, current, checkpoint):
        _, _, _, item, _ = self._locate(current)
        self._set(item, checkpoint['fields'])
        for property_checkpoint in checkpoint['properties']:
            self.properties.restore_checkpoint(item.properties, property_checkpoint)

    def preflight_remove(self, expected):
        role, _, _, _, current = self._locate(expected)
        if role not in ('USER', 'ADDON') or not current.editable:
            raise BackendError('READ_ONLY_TARGET')

    def remove(self, expected):
        self.preflight_remove(expected)
        _, _, km, item, _ = self._locate(expected)
        km.keymap_items.remove(item)

    def _target_map(self, config, group):
        maps = [km for km in config.keymaps if self._map_location(km) == group.location]
        if len(maps) > 1:
            raise BackendError('AMBIGUOUS_KEYMAP')
        return maps[0] if maps else None

    def _operator_rna(self, identifier):
        if not _OPERATOR.fullmatch(identifier):
            raise BackendError('INVALID_OPERATOR')
        module, operation = identifier.split('.', 1)
        try:
            operator = getattr(getattr(self.bpy.ops, module), operation)
            reader = getattr(operator, 'get_rna_type', None)
            if not callable(reader):
                raise BackendError('MISSING_RNA_CAPABILITY', name='operator.get_rna_type')
            return reader()
        except BackendError:
            raise
        except (AttributeError, RuntimeError, KeyError) as exc:
            raise BackendError('UNKNOWN_OPERATOR', operator=identifier) from exc

    def validate_import(self, item):
        self._guard()
        config = self._user()
        for name in ('type', 'value', 'direction', 'key_modifier'):
            if getattr(item.event, name) not in {choice.key for choice in dict(self._event_enums)[name]}:
                raise BackendError('INVALID_EVENT', field=name)
        for name, value in (('space_type', item.group.space_type), ('region_type', item.group.region_type)):
            if value not in {choice.key for choice in self._type_options(self.bpy.types.KeyMap, name)}:
                raise BackendError('INVALID_KEYMAP_LOCATION', field=name)
        km = self._target_map(config, item.group)
        if km is not None and self._tool_flag(km) != item.group.is_tool:
            raise BackendError('KEYMAP_TOOL_FLAG_MISMATCH')
        if item.group.is_modal:
            if km is None:
                raise BackendError('MODAL_KEYMAP_NOT_FOUND')
            if item.propvalue not in {choice.key for choice in options_from_items(km.modal_event_values)}:
                raise BackendError('INVALID_MODAL_VALUE')
        else:
            self._operator_rna(item.idname)

    def append(self, incoming):
        self.validate_import(incoming)
        config = self._user()
        map_before = {pointer(km) for km in config.keymaps}
        km = self._target_map(config, incoming.group)
        owned_map = None
        owned_item = None
        item_before = {pointer(item) for item in km.keymap_items} if km is not None else set()
        try:
            if km is None:
                km = config.keymaps.new(incoming.group.name, space_type=incoming.group.space_type,
                                        region_type=incoming.group.region_type, modal=False, tool=incoming.group.is_tool)
                if pointer(km) not in map_before:
                    owned_map = pointer(km)
                if self._map_location(km) != incoming.group.location or self._tool_flag(km) != incoming.group.is_tool:
                    raise BackendError('KEYMAP_LOCATION_NOT_APPLIED')
                item_before = {pointer(item) for item in km.keymap_items}
            options = incoming.event.as_dict()
            event_type = options.pop('type')
            value = options.pop('value')
            create = km.keymap_items.new_modal if km.is_modal else km.keymap_items.new
            item = create(incoming.propvalue if km.is_modal else incoming.idname, event_type, value, **options)
            item_pointer = pointer(item)
            if item_pointer in item_before:
                raise BackendError('APPEND_REUSED_EXISTING_ITEM')
            owned_item = item_pointer
            item.active = incoming.active
            self.properties.apply(item.properties, incoming.properties)
            current = self._record('USER', config, km, item, 0)
            if not current.portable or current.content_key(include_layer=False) != incoming.content_key():
                raise BackendError('APPEND_VALUE_NOT_APPLIED')
            return current
        except Exception as exc:
            cleanup_errors = []
            if owned_item is not None and km is not None:
                try:
                    current = [item for item in km.keymap_items if pointer(item) == owned_item]
                    if len(current) > 1:
                        raise BackendError('AMBIGUOUS_OWNED_ITEM')
                    if current:
                        km.keymap_items.remove(current[0])
                except Exception as cleanup:
                    cleanup_errors.append(getattr(cleanup, 'code', type(cleanup).__name__))
            if owned_map is not None:
                try:
                    current = [candidate for candidate in config.keymaps if pointer(candidate) == owned_map]
                    if len(current) > 1:
                        raise BackendError('AMBIGUOUS_OWNED_MAP')
                    if current and not tuple(current[0].keymap_items):
                        config.keymaps.remove(current[0])
                except Exception as cleanup:
                    cleanup_errors.append(getattr(cleanup, 'code', type(cleanup).__name__))
            try:
                map_after = {pointer(candidate) for candidate in config.keymaps}
                extra_maps = sorted(map_after - map_before)
                remaining_items = []
                for candidate in config.keymaps:
                    if self._map_location(candidate) == incoming.group.location:
                        remaining_items.extend(pointer(item) for item in candidate.keymap_items if pointer(item) not in item_before)
                if extra_maps or remaining_items:
                    cleanup_errors.append('UNRESOLVED_NEW_RUNTIME_OBJECTS')
            except Exception as cleanup:
                cleanup_errors.append(type(cleanup).__name__)
            if cleanup_errors:
                raise BackendError('APPEND_CLEANUP_FAILED', cause=getattr(exc, 'code', type(exc).__name__),
                                   cleanup_errors=cleanup_errors) from exc
            if isinstance(exc, BackendError):
                raise
            raise BackendError('APPEND_FAILED', cause=type(exc).__name__) from exc

    def clipboard_get(self):
        self._guard()
        return self.wm.clipboard

    def clipboard_set(self, value):
        self._guard()
        if type(value) is not str:
            raise BackendError('INVALID_CLIPBOARD_VALUE')
        self.wm.clipboard = value

    def load_standard(self):
        self._guard()
        before = self.scan()
        if not before.needs_initial_keymap:
            return dict(imported=0, duplicates=0, runtime_loaded=self._standard_loaded, already_populated=True)
        if self._standard_path is None or self._standard_root is None:
            raise BackendError('STANDARD_PRESET_PATH_REQUIRED')
        path = self._standard_path.resolve(strict=True)
        root = self._standard_root.resolve(strict=True)
        if self._standard_path.is_symlink() or not path.is_file() or path.suffix != '.py' or root not in path.parents:
            raise BackendError('UNTRUSTED_STANDARD_PRESET')
        setter = getattr(self.bpy.utils, 'keyconfig_set', None)
        if not callable(setter):
            raise BackendError('MISSING_RNA_CAPABILITY', name='bpy.utils.keyconfig_set')
        setter(str(path))
        self.wm.keyconfigs.update()
        after = self.scan()
        if after.needs_initial_keymap:
            raise BackendError('STANDARD_PRESET_EMPTY')
        self._standard_loaded = True
        previous = {(row.key, row.identity_token) for row in before.records}
        added = [row for row in after.records if row.role == 'USER' and (row.key, row.identity_token) not in previous]
        return dict(imported=len(added), duplicates=0, runtime_loaded=True)

    def close(self):
        self._guard()
        self._closed = True
