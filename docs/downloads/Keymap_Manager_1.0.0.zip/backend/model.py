# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Value objects shared by the engine and its explicitly supplied runtime port."""
from dataclasses import dataclass, fields
from functools import cached_property
import hashlib
import json
import math

MODIFIERS = ('ctrl', 'shift', 'alt', 'oskey', 'hyper')
MAX_INPUT_BYTES = 16 * 1024 * 1024
MAX_ROWS = 100000
MAX_PROPERTY_NODES = 100000


class BackendError(ValueError):
    def __init__(self, code, **details):
        self.code = str(code)
        self.details = details
        super().__init__(self.code)


def plain_json(value):
    """Copy JSON values without coercing invalid types or nonfinite numbers."""
    remaining = [MAX_PROPERTY_NODES]

    def visit(item, depth):
        remaining[0] -= 1
        if remaining[0] < 0 or depth > 32:
            raise BackendError('RESOURCE_LIMIT', resource='property_tree')
        if item is None or type(item) in (bool, int, str):
            return item
        if type(item) is float:
            if not math.isfinite(item):
                raise BackendError('INVALID_PROPERTY', reason='nonfinite_number')
            return item
        if type(item) in (list, tuple):
            return [visit(child, depth + 1) for child in item]
        if type(item) is dict:
            if any(type(key) is not str for key in item):
                raise BackendError('INVALID_PROPERTY', reason='nonstring_key')
            return {key: visit(child, depth + 1) for key, child in item.items()}
        raise BackendError('INVALID_PROPERTY', value_type=type(item).__name__)

    return visit(value, 0)


def canonical(value):
    return json.dumps(plain_json(value), sort_keys=True, ensure_ascii=False,
                      allow_nan=False, separators=(',', ':'))


def digest(value):
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


def require_text(value, field, *, allow_empty=False):
    if type(value) is not str or '\x00' in value or (not value and not allow_empty):
        raise BackendError('INVALID_FIELD', field=field)
    return value


@dataclass(frozen=True)
class RowKey:
    """Actual RNA address. The signed RNA id is retained without modification."""
    keyconfig_name: str
    keymap_name: str
    space_type: str
    region_type: str
    is_modal: bool
    kmi_id: int

    def __post_init__(self):
        for name in ('keyconfig_name', 'keymap_name', 'space_type', 'region_type'):
            require_text(getattr(self, name), name)
        if type(self.is_modal) is not bool or type(self.kmi_id) is not int:
            raise BackendError('INVALID_TARGET')
        if not -32768 <= self.kmi_id <= 32767:
            raise BackendError('INVALID_TARGET', reason='outside_public_rna_id_range')

    @property
    def location(self):
        return (self.keyconfig_name, self.keymap_name, self.space_type,
                self.region_type, self.is_modal)

    @property
    def map_location(self):
        return self.location[1:]

    def values(self):
        return self.location + (self.kmi_id,)

    def ui_arguments(self):
        # UI RowRef requires a nonnegative token. Positive RNA ids are preserved;
        # negative ids occupy a disjoint range. Resolution still requires the
        # current snapshot, its revision and the complete location.
        token = self.kmi_id if self.kmi_id >= 0 else 32767 - self.kmi_id
        result = {field.name: getattr(self, field.name) for field in fields(self)}
        result['kmi_id'] = token
        return result


@dataclass(frozen=True)
class EventData:
    type: str
    value: str = 'PRESS'
    direction: str = 'ANY'
    any: bool = False
    ctrl: int = 0
    shift: int = 0
    alt: int = 0
    oskey: int = 0
    hyper: int = 0
    key_modifier: str = 'NONE'
    repeat: bool = False

    def __post_init__(self):
        for name in ('type', 'value', 'direction', 'key_modifier'):
            require_text(getattr(self, name), name)
        for name in ('any', 'repeat'):
            if type(getattr(self, name)) is not bool:
                raise BackendError('INVALID_EVENT', field=name)
        for name in MODIFIERS:
            value = getattr(self, name)
            if type(value) is not int or value not in (-1, 0, 1):
                raise BackendError('INVALID_EVENT', field=name)

    def as_dict(self):
        return {field.name: getattr(self, field.name) for field in fields(self)}

    @classmethod
    def from_mapping(cls, values):
        if type(values) is not dict or 'type' not in values:
            raise BackendError('INVALID_EVENT')
        result = {field.name: values[field.name] for field in fields(cls)
                  if field.name in values}
        # Earlier JSON writers may encode the two definite modifier states as
        # booleans. No strings, floats or truthiness coercions are accepted.
        for name in MODIFIERS:
            if name in result and type(result[name]) is bool:
                result[name] = int(result[name])
        return cls(**result)

    def signature(self):
        return tuple(getattr(self, field.name) for field in fields(self))


def event_matches(stored, selected, *, exact_value=True, exact_modifiers=True):
    if stored.type != selected.type:
        return False
    if exact_value and stored.value not in (selected.value, 'ANY'):
        return False
    if exact_modifiers:
        if stored.key_modifier != selected.key_modifier:
            return False
        if not stored.any:
            return all(getattr(stored, name) in (-1, getattr(selected, name))
                       for name in MODIFIERS)
    return True


def events_overlap(left, right):
    """Event-level possibility only; this does not evaluate operator poll."""
    if left.type != right.type or left.key_modifier != right.key_modifier:
        return False
    if left.value != right.value and 'ANY' not in (left.value, right.value):
        return False
    if left.direction != right.direction and 'ANY' not in (left.direction, right.direction):
        return False
    if left.any or right.any:
        return True
    return all(getattr(left, name) == getattr(right, name)
               or -1 in (getattr(left, name), getattr(right, name))
               for name in MODIFIERS)


@dataclass(frozen=True)
class Record:
    key: RowKey
    role: str
    order: int
    identity_token: str
    idname: str
    propvalue: str
    active: bool
    event: EventData
    properties_text: str = '{}'
    label_en: str = ''
    label_ja: str = ''
    editable: bool = True
    modified: bool = False
    contexts: tuple[str, ...] = ()
    portable: bool = True
    property_issues: tuple[str, ...] = ()

    def __post_init__(self):
        if self.role not in ('USER', 'ADDON', 'DEFAULT', 'ACTIVE'):
            raise BackendError('INVALID_RECORD', field='role')
        for name in ('active', 'editable', 'modified', 'portable'):
            if type(getattr(self, name)) is not bool:
                raise BackendError('INVALID_RECORD', field=name)
        if type(self.order) is not int or self.order < 0:
            raise BackendError('INVALID_RECORD', field='order')
        if type(self.contexts) is not tuple or any(type(value) is not str for value in self.contexts):
            raise BackendError('INVALID_RECORD', field='contexts')
        if type(self.property_issues) is not tuple or any(type(value) is not str for value in self.property_issues):
            raise BackendError('INVALID_RECORD', field='property_issues')
        if self.property_issues and self.portable:
            raise BackendError('INVALID_RECORD', field='portable')
        require_text(self.identity_token, 'identity_token')
        require_text(self.idname, 'idname', allow_empty=self.key.is_modal or not self.portable)
        require_text(self.propvalue, 'propvalue', allow_empty=not self.key.is_modal or not self.portable)
        try:
            value = json.loads(self.properties_text)
        except (TypeError, ValueError) as exc:
            raise BackendError('INVALID_PROPERTY') from exc
        if type(value) is not dict or canonical(value) != self.properties_text:
            raise BackendError('INVALID_PROPERTY', reason='not_canonical_object')

    @property
    def properties(self):
        return json.loads(self.properties_text)

    @property
    def identity(self):
        return self.propvalue if self.key.is_modal else self.idname

    def content_key(self, *, include_layer=True, include_active=True):
        location = self.key.location if include_layer else self.key.map_location
        identity = self.propvalue if self.key.is_modal else self.idname.strip().lower()
        value = (location, identity, self.event.signature(),
                 self.active if include_active else None, self.properties_text)
        # Incomplete property capture must never make different rows identical.
        return value if self.portable else value + ('INCOMPLETE_PROPERTIES', self.identity_token, self.key.values())

    def fingerprint(self):
        return (self.key.values(), self.role, self.order, self.identity_token,
                self.idname, self.propvalue, self.active, self.event.signature(),
                self.properties_text, self.editable, self.modified, self.contexts,
                self.portable, self.property_issues)


@dataclass(frozen=True)
class EnumOption:
    key: str
    label_en: str
    help_en: str = ''
    label_ja: str = ''
    help_ja: str = ''


@dataclass(frozen=True)
class MapInfo:
    keyconfig_name: str
    role: str
    name: str
    space_type: str
    region_type: str
    is_modal: bool
    is_tool: bool = False

    @property
    def location(self):
        return (self.keyconfig_name, self.name, self.space_type,
                self.region_type, self.is_modal)

    @property
    def map_location(self):
        return self.location[1:]


@dataclass(frozen=True)
class Scan:
    records: tuple[Record, ...]
    keymaps: tuple[MapInfo, ...] = ()
    enums: tuple[tuple[str, tuple[EnumOption, ...]], ...] = ()
    modal_enums: tuple[tuple[tuple, tuple[EnumOption, ...]], ...] = ()
    higher_sources: tuple[tuple[RowKey, tuple[RowKey, ...]], ...] = ()
    needs_initial_keymap: bool = False

    def __post_init__(self):
        if len(self.records) > MAX_ROWS:
            raise BackendError('RESOURCE_LIMIT', resource='keymap_items')
        keys = [row.key for row in self.records]
        if len(keys) != len(set(keys)):
            raise BackendError('AMBIGUOUS_TARGET', reason='duplicate_complete_locator')

    @cached_property
    def revision(self):
        # All rows have passed their own RNA and per-property checks.
        # This aggregate contains native tuples, booleans, finite numbers and strings.
        payload = {
            'records': [row.fingerprint() for row in self.records],
            'maps': [(km.location, km.role, km.is_tool) for km in self.keymaps],
            'enums': [(name, [item.key for item in options]) for name, options in self.enums],
            'modal': [(location, [item.key for item in options]) for location, options in self.modal_enums],
            'higher': [(key.values(), [source.values() for source in sources])
                       for key, sources in self.higher_sources],
            'needs_initial_keymap': self.needs_initial_keymap,
        }
        canonical_scan = json.dumps(payload, sort_keys=True, ensure_ascii=False,
                                    allow_nan=False, separators=(',', ':'))
        return hashlib.sha256(canonical_scan.encode('utf-8')).hexdigest()

    @cached_property
    def records_by_key(self):
        return {row.key: row for row in self.records}

    @cached_property
    def priority_by_key(self):
        return dict(self.higher_sources)

    def options(self, name, location=None):
        if name == 'propvalue':
            return dict(self.modal_enums).get(location, ())
        return dict(self.enums).get(name, ())

    def find(self, key):
        for row in self.records:
            if row.key == key:
                return row
        raise BackendError('TARGET_NOT_FOUND')
