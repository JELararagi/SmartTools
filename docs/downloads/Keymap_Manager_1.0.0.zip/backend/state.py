# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Published properties and typed, narrowly scoped state updates."""
from pathlib import Path
from types import SimpleNamespace
import json

from .model import BackendError, canonical

with Path(__file__).with_name('public_declarations.json').open(encoding='utf-8') as stream:
    _declared = json.load(stream)['declarations']

STATE_DECLARATIONS = tuple(next(row for row in _declared
                                if row['public_class'] == 'KMM_State')['properties'])
PREVIEW_DECLARATIONS = tuple(next(row for row in _declared
                                  if row['public_class'] == 'KMM_ConsolidationPreviewRow')['properties'])
OPERATIONS = {row['bl_idname']: row for row in _declared
              if row.get('bl_idname', '').startswith('keymap_manager.')}

# These enum defaults were not specified by the published declaration.
# They are explicit candidate choices, checked against runtime enum values.
INFERRED_ENUM_DEFAULTS = {
    'selected_type': 'NONE', 'selected_value': 'PRESS',
    'selected_key_modifier': 'NONE', 'visual_editor_filter': 'ALL',
    'visual_mode_filter': 'ALL', 'preset_select': 'NONE',
}


def defaults():
    result = {}
    for field in STATE_DECLARATIONS:
        if field['type'] == 'CollectionProperty':
            continue
        name = field['identifier']
        if 'default' in field:
            result[name] = field['default']
        elif name in INFERRED_ENUM_DEFAULTS:
            result[name] = INFERRED_ENUM_DEFAULTS[name]
        else:
            raise BackendError('UNDECLARED_DEFAULT', field=name)
    return result


def memory_state(**values):
    data = defaults()
    if any(name not in data for name in values):
        raise BackendError('INVALID_STATE_FIELD')
    data.update(values)
    return SimpleNamespace(**data)


def state_definition(name):
    for field in STATE_DECLARATIONS:
        if field['identifier'] == name and field['type'] != 'CollectionProperty':
            return field
    raise BackendError('INVALID_STATE_FIELD', field=name)


def validate_state(name, value, choices=()):
    field = state_definition(name)
    kind = field['type']
    expected = {'BoolProperty': bool, 'IntProperty': int,
                'StringProperty': str, 'EnumProperty': str}.get(kind)
    if expected is None or type(value) is not expected:
        raise BackendError('INVALID_STATE_VALUE', field=name)
    if type(value) is str and ('\x00' in value or len(value) > 65536):
        raise BackendError('INVALID_STATE_VALUE', field=name)
    if name == 'consolidation_preview_index' and value < 0:
        raise BackendError('INVALID_STATE_VALUE', field=name)
    if name == 'view_mode' and value not in ('NORMAL', 'CONFLICT', 'UNUSED', 'VISUAL'):
        raise BackendError('INVALID_STATE_VALUE', field=name)
    if kind == 'EnumProperty':
        allowed = tuple(choices) or tuple(row[0] for row in field.get('items', ()))
        if value not in allowed:
            raise BackendError('INVALID_CHOICE', field=name, choice=value)
    return value


def operation_arguments(operation_id, arguments):
    declaration = OPERATIONS.get(operation_id)
    if declaration is None:
        raise BackendError('UNKNOWN_OPERATION')
    try:
        provided = dict(arguments)
    except (TypeError, ValueError) as exc:
        raise BackendError('INVALID_ARGUMENTS') from exc
    definitions = {field['identifier']: field for field in declaration['properties']}
    if any(type(name) is not str or name not in definitions for name in provided):
        raise BackendError('INVALID_ARGUMENTS', reason='undeclared_argument')
    result = {}
    for name, field in definitions.items():
        value = provided.get(name, field.get('default', ''))
        required = {'BoolProperty': bool, 'IntProperty': int,
                    'StringProperty': str, 'EnumProperty': str}[field['type']]
        if type(value) is not required:
            raise BackendError('INVALID_ARGUMENTS', field=name)
        if type(value) is str and ('\x00' in value or len(value) > 65536):
            raise BackendError('INVALID_ARGUMENTS', field=name)
        result[name] = value
    return result


class StateFacade:
    """No initialization writes. A failed update restores only attempted fields."""
    def __init__(self, owner):
        self.owner = owner

    def _get(self, name, default):
        if isinstance(self.owner, dict):
            return self.owner.get(name, default)
        return getattr(self.owner, name, default)

    def _set(self, name, value):
        if isinstance(self.owner, dict):
            self.owner[name] = value
        else:
            setattr(self.owner, name, value)

    def read(self):
        try:
            return {name: self._get(name, value) for name, value in defaults().items()}
        except (AttributeError, TypeError, ValueError, RuntimeError) as exc:
            raise BackendError('STATE_READ_ERROR') from exc

    def apply(self, patch):
        before = self.read()
        if any(name not in before for name in patch):
            raise BackendError('INVALID_STATE_FIELD')
        attempted = []
        try:
            for name, value in patch.items():
                if canonical(value) == canonical(before[name]):
                    continue
                attempted.append(name)
                self._set(name, value)
                if canonical(self._get(name, None)) != canonical(value):
                    raise BackendError('STATE_VALUE_NOT_APPLIED', field=name)
        except (AttributeError, TypeError, ValueError, RuntimeError) as exc:
            failed = []
            for name in reversed(attempted):
                try:
                    self._set(name, before[name])
                    if canonical(self._get(name, None)) != canonical(before[name]):
                        failed.append(name)
                except (AttributeError, TypeError, ValueError, RuntimeError):
                    failed.append(name)
            raise BackendError('STATE_WRITE_ERROR', rollback_failed=failed,
                               cause=getattr(exc, 'code', type(exc).__name__)) from exc
        return self.read()
