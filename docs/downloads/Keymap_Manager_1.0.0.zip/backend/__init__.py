# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent Keymap Manager backend; no import-time bpy registration."""
from .engine import Engine
from .model import BackendError

BACKEND_CONTRACT_VERSION = 1


def create_runtime(bpy_module, ui_contract, *, wm_state_name, storage_root, **options):
    """Root supplies the existing UI contract, state pointer name and storage path.

    Give the returned adapter to the UI class factory, then call runtime.register
    with those exact classes. Do not also call the UI module's register function.
    """
    from .lifecycle import BackendRuntime
    return BackendRuntime(bpy_module, ui_contract, wm_state_name=wm_state_name,
                          storage_root=storage_root, **options)
