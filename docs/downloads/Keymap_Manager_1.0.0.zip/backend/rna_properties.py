# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Strict operator-property access through public RNA, with injected bpy types.

No bpy import or instance is created here. Unsupported values are reported and
must not be used as an incomplete duplicate identity or a successful export.
"""
import math

from .model import BackendError, MAX_PROPERTY_NODES, canonical, plain_json


def runtime_plain(value, depth=0):
    if depth > 32:
        raise BackendError('PROPERTY_DEPTH_LIMIT')
    if value is None or type(value) in (str, bool, int):
        return value
    if type(value) is float:
        if not math.isfinite(value):
            raise BackendError('NON_FINITE_PROPERTY')
        return value
    if type(value) is set:
        if any(type(item) is not str for item in value):
            raise BackendError('UNSUPPORTED_PROPERTY_SET')
        return sorted(value)
    if hasattr(value, 'bl_rna') or type(value) in (dict, bytes, bytearray):
        raise BackendError('UNSUPPORTED_PROPERTY_VALUE')
    try:
        length = len(value)
    except (TypeError, AttributeError) as exc:
        raise BackendError('UNSUPPORTED_PROPERTY_VALUE') from exc
    if length > MAX_PROPERTY_NODES:
        raise BackendError('PROPERTY_SIZE_LIMIT')
    return [runtime_plain(item, depth + 1) for item in value]


class PropertyAccess:
    def __init__(self, operator_properties_type):
        if not isinstance(operator_properties_type, type):
            raise BackendError('MISSING_RNA_CAPABILITY', name='OperatorProperties')
        self.operator_properties_type = operator_properties_type

    @staticmethod
    def fields(owner):
        try:
            return {field.identifier: field for field in owner.bl_rna.properties if field.identifier != 'rna_type'}
        except (AttributeError, ReferenceError, RuntimeError, TypeError) as exc:
            raise BackendError('PROPERTY_RNA_UNAVAILABLE') from exc

    def capture(self, owner, *, prefix='', depth=0):
        if owner is None:
            return {}, ()
        if depth > 32:
            return {}, (prefix + ': PROPERTY_DEPTH_LIMIT',)
        result, issues = {}, []
        try:
            fields = self.fields(owner)
        except BackendError as exc:
            return {}, (prefix + ': ' + exc.code,)
        for name, field in fields.items():
            path = prefix + name
            try:
                is_set = owner.is_property_set(name)
                if type(is_set) is not bool:
                    raise BackendError('PROPERTY_SETTING_STATE_UNKNOWN')
                if field.type == 'POINTER':
                    child = getattr(owner, name)
                    if isinstance(child, self.operator_properties_type):
                        nested, nested_issues = self.capture(child, prefix=path + '.', depth=depth + 1)
                        issues.extend(nested_issues)
                        if nested or is_set:
                            result[name] = nested
                    elif is_set or child is not None:
                        issues.append(path + ': UNSUPPORTED_POINTER')
                elif field.type == 'COLLECTION':
                    if is_set or len(getattr(owner, name)):
                        issues.append(path + ': UNSUPPORTED_COLLECTION')
                elif is_set:
                    if field.is_readonly or owner.is_property_readonly(name):
                        issues.append(path + ': READ_ONLY_PROPERTY')
                    else:
                        result[name] = runtime_plain(getattr(owner, name), depth + 1)
            except Exception as exc:
                issues.append(path + ': ' + getattr(exc, 'code', type(exc).__name__))
        keys = getattr(owner, 'keys', None)
        if callable(keys):
            try:
                for name in keys():
                    if name not in fields and name != 'rna_type':
                        issues.append(prefix + str(name) + ': UNKNOWN_STORED_PROPERTY')
            except Exception as exc:
                issues.append(prefix + ': ' + type(exc).__name__)
        try:
            result = plain_json(result)
        except BackendError as exc:
            return {}, tuple(issues + [prefix + ': ' + exc.code])
        return result, tuple(dict.fromkeys(issues))

    @staticmethod
    def _number(kind, value, *, ui=False):
        if kind == 'BOOLEAN':
            if type(value) is not bool:
                raise BackendError('INVALID_PROPERTY_TYPE')
            return value
        if kind == 'INT':
            if type(value) is not int:
                raise BackendError('INVALID_PROPERTY_TYPE')
            return value
        if ui and type(value) is str:
            try:
                value = float(value)
            except ValueError as exc:
                raise BackendError('INVALID_PROPERTY_TYPE') from exc
        if type(value) not in (int, float) or not math.isfinite(value):
            raise BackendError('INVALID_PROPERTY_TYPE')
        return float(value)

    def normalize(self, owner, name, value, *, ui=False):
        field = self.fields(owner).get(name)
        if field is None:
            raise BackendError('UNKNOWN_PROPERTY', field=name)
        if field.type == 'POINTER':
            child = getattr(owner, name)
            if type(value) is not dict or not isinstance(child, self.operator_properties_type):
                raise BackendError('UNSUPPORTED_POINTER', field=name)
            return self.validate(child, value)
        if field.is_readonly or owner.is_property_readonly(name):
            raise BackendError('READ_ONLY_PROPERTY', field=name)
        if field.type == 'COLLECTION':
            raise BackendError('UNSUPPORTED_COLLECTION', field=name)
        if field.type == 'STRING':
            if type(value) is not str or '\x00' in value:
                raise BackendError('INVALID_PROPERTY_TYPE', field=name)
            return value
        if field.type == 'ENUM':
            choices = {item.identifier for item in field.enum_items if item.identifier}
            if field.is_enum_flag:
                if type(value) not in (list, tuple) or any(type(item) is not str for item in value):
                    raise BackendError('INVALID_PROPERTY_TYPE', field=name)
                if len(set(value)) != len(value) or not set(value).issubset(choices):
                    raise BackendError('INVALID_PROPERTY_ENUM', field=name)
                return sorted(value)
            if type(value) is not str or value not in choices:
                raise BackendError('INVALID_PROPERTY_ENUM', field=name)
            return value
        if field.type in ('BOOLEAN', 'INT', 'FLOAT'):
            current = getattr(owner, name)
            if type(current) in (bool, int, float):
                normalized = self._number(field.type, value, ui=ui)
                # Bounds are checked only when the runtime exposes their metadata.
                lower, upper = getattr(field, 'hard_min', None), getattr(field, 'hard_max', None)
                if lower is not None and normalized < lower or upper is not None and normalized > upper:
                    raise BackendError('PROPERTY_OUT_OF_RANGE', field=name)
                return normalized
            if type(value) not in (list, tuple) or len(value) != len(current):
                raise BackendError('INVALID_PROPERTY_ARRAY', field=name)
            return [self._number(field.type, item) for item in value]
        raise BackendError('UNSUPPORTED_PROPERTY_TYPE', field=name, kind=str(field.type))

    def validate(self, owner, data):
        if type(data) is not dict:
            raise BackendError('INVALID_PROPERTY')
        plain_json(data)
        return {name: self.normalize(owner, name, value) for name, value in data.items()}

    def apply(self, owner, data):
        normalized = self.validate(owner, data)
        fields = self.fields(owner)
        for name, value in normalized.items():
            field = fields[name]
            if field.type == 'POINTER':
                self.apply(getattr(owner, name), value)
            else:
                setattr(owner, name, set(value) if field.type == 'ENUM' and field.is_enum_flag else value)
                if canonical(runtime_plain(getattr(owner, name))) != canonical(value):
                    raise BackendError('PROPERTY_VALUE_NOT_APPLIED', field=name)
        return normalized

    def field_checkpoint(self, owner, name):
        field = self.fields(owner).get(name)
        if field is None or field.type in ('POINTER', 'COLLECTION'):
            raise BackendError('UNSUPPORTED_PROPERTY_CHECKPOINT', field=name)
        return dict(name=name, is_set=owner.is_property_set(name), value=runtime_plain(getattr(owner, name)))

    def restore_checkpoint(self, owner, checkpoint):
        name = checkpoint['name']
        if checkpoint['is_set']:
            self.apply(owner, {name: checkpoint['value']})
        else:
            owner.property_unset(name)
        if (owner.is_property_set(name) != checkpoint['is_set']
                or canonical(runtime_plain(getattr(owner, name))) != canonical(checkpoint['value'])):
            raise BackendError('PROPERTY_ROLLBACK_MISMATCH', field=name)
