# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Pure queries. Runtime dispatch calls these; UI draw never does."""
from dataclasses import dataclass
from itertools import product

from .model import BackendError, EventData, MODIFIERS, canonical, event_matches, events_overlap


@dataclass(frozen=True)
class ChildCategory:
    key: str
    label_en: str
    label_ja: str
    location: tuple


@dataclass(frozen=True)
class ParentCategory:
    key: str
    label_en: str
    label_ja: str
    children: tuple[ChildCategory, ...]


def duplicate_groups(records):
    groups = {}
    for row in records:
        if row.role not in ('USER', 'ADDON'):
            continue
        groups.setdefault(row.content_key(), []).append(row)
    return tuple(tuple(group) for group in groups.values() if len(group) > 1)


def conflict_groups(records):
    groups = {}
    for row in records:
        if row.active and row.role in ('USER', 'ADDON'):
            groups.setdefault((row.key.location, row.event.signature()), []).append(row)
    return tuple(tuple(group) for group in groups.values() if len(group) > 1)


def higher_sources(scan, target):
    requested = scan.priority_by_key.get(target.key, ())
    if not requested:
        return ()
    by_key = scan.records_by_key
    found = []
    for key in requested:
        source = by_key.get(key)
        if source is None or source.key == target.key or not source.active:
            continue
        if source.key.is_modal or target.key.is_modal:
            continue
        if source.key.keyconfig_name != target.key.keyconfig_name:
            continue
        if not events_overlap(source.event, target.event):
            continue
        if source.key.location != target.key.location:
            # Cross-map relationships require supplied context evidence; a
            # matching physical key in a different editor is not sufficient.
            if not set(source.contexts).intersection(target.contexts):
                continue
        if source.key not in {row.key for row in found}:
            found.append(source)
    return tuple(found)


def binding_status(scan, row):
    if not row.active:
        return 'DISABLED'
    if row.key.is_modal:
        return 'MODAL'
    sources = higher_sources(scan, row)
    if not sources:
        return 'ACTIVE'
    covered = set().union(*(set(source.contexts) for source in sources))
    if row.contexts and not set(row.contexts).issubset(covered):
        return 'PARTIAL_SHADOWED'
    return 'SHADOWED'


def shortcut(event, language='en'):
    names = {'ctrl': 'Ctrl', 'shift': 'Shift', 'alt': 'Alt', 'oskey': 'OS', 'hyper': 'Hyper'}
    values = []
    if event.any:
        values.append('任意の修飾キー' if language == 'ja' else 'Any modifiers')
    else:
        for name in MODIFIERS:
            value = getattr(event, name)
            if value == 1:
                values.append(names[name])
            elif value == -1:
                values.append(names[name] + ('任意' if language == 'ja' else '?'))
    if event.key_modifier != 'NONE':
        values.append(event.key_modifier)
    values.append(event.type)
    suffix = event.value
    if language == 'ja':
        suffix = {'PRESS': '押す', 'RELEASE': '放す', 'CLICK': 'クリック',
                  'DOUBLE_CLICK': 'ダブルクリック', 'CLICK_DRAG': 'ドラッグ',
                  'ANY': '任意の入力状態', 'NOTHING': '入力なし'}.get(suffix, suffix)
    if event.direction != 'ANY':
        direction = event.direction
        if language == 'ja':
            direction = {'NORTH': '上', 'SOUTH': '下', 'EAST': '右', 'WEST': '左',
                         'NORTH_EAST': '右上', 'NORTH_WEST': '左上',
                         'SOUTH_EAST': '右下', 'SOUTH_WEST': '左下'}.get(direction, direction)
        suffix += ', ' + direction
    return ' + '.join(values) + ' (' + suffix + ')'


def visible_records(scan, state):
    eligible = tuple(row for row in scan.records if row.role in ('USER', 'ADDON')
                     and (row.active or state['include_disabled']))
    view = state['view_mode']
    if view == 'UNUSED':
        return (), {}
    if view == 'CONFLICT':
        keys = {row.key for group in conflict_groups(scan.records) for row in group}
        return tuple(row for row in eligible if row.key in keys), {}
    if view == 'VISUAL':
        text = state['visual_search_text'].strip().casefold()
        result = []
        for row in eligible:
            if state['visual_editor_filter'] not in ('ALL', row.key.space_type):
                continue
            if state['visual_mode_filter'] not in ('ALL', row.key.keymap_name):
                continue
            searchable = ' '.join((row.idname, row.propvalue, row.label_en,
                                   row.label_ja, row.key.keymap_name,
                                   row.key.space_type, row.key.region_type,
                                   shortcut(row.event), shortcut(row.event, 'ja'))).casefold()
            if not text or text in searchable:
                result.append(row)
        return tuple(result), {}
    query = state['operator_id_query'].strip().casefold()
    if query:
        assigned = tuple(row for row in eligible if not row.key.is_modal
                         and row.idname.strip().casefold() == query)
        events = {row.event.signature() for row in assigned}
        result = tuple(row for row in eligible if row.event.signature() in events)
        assigned_keys = {row.key for row in assigned}
        return result, {row.key: ('assigned' if row.key in assigned_keys else 'same_event')
                        for row in result}
    if state['selected_type'] == 'NONE':
        return (), {}
    selected = EventData(state['selected_type'], state['selected_value'],
                         key_modifier=state['selected_key_modifier'],
                         **{name: int(state['selected_' + name]) for name in MODIFIERS})
    return tuple(row for row in eligible
                 if event_matches(row.event, selected,
                                  exact_value=state['use_exact_value'],
                                  exact_modifiers=state['use_exact_modifiers'])), {}


def runtime_categories(scan):
    parents = {}
    seen = set()
    for km in scan.keymaps:
        if km.role not in ('USER', 'ADDON') or km.map_location in seen:
            continue
        seen.add(km.map_location)
        child = ChildCategory(canonical(km.map_location), km.name, km.name, km.map_location)
        parents.setdefault(km.space_type, []).append(child)
    return tuple(ParentCategory(space, space, space, tuple(children))
                 for space, children in parents.items())


def event_kind(token):
    if token.startswith('NDOF_'):
        return 'ndof'
    if any(part in token for part in ('MOUSE', 'WHEEL', 'TRACKPAD')) or token in ('PEN', 'ERASER'):
        return 'mouse'
    return 'keyboard'


def runtime_candidates(scan):
    """Finite PRESS candidates from runtime enums, with five binary modifiers."""
    if 'PRESS' not in {item.key for item in scan.options('value')}:
        return ()
    internal = {'NONE', 'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'WINDOW_DEACTIVATE',
                'TEXTINPUT', 'NDOF_MOTION'}
    result = []
    for item in scan.options('type'):
        token = item.key
        if not token or token in internal or token.startswith('TIMER'):
            continue
        for combination in product((0, 1), repeat=len(MODIFIERS)):
            if len(result) >= 20000:
                raise BackendError('RESOURCE_LIMIT', resource='unused_candidates')
            result.append(EventData(token, **dict(zip(MODIFIERS, combination))))
    return tuple(result)


def unused_candidates(scan, location, candidates):
    reserved = tuple(row.event for row in scan.records
                     if row.role in ('USER', 'ADDON') and row.key.map_location == location)
    # Disabled registrations reserve their event as well. Wildcards reserve
    # every overlapping candidate, so they cannot be presented as free keys.
    by_type = {}
    for event in reserved:
        by_type.setdefault(event.type, []).append(event)
    return tuple(candidate for candidate in candidates
                 if not any(events_overlap(event, candidate)
                            for event in by_type.get(candidate.type, ())))
