# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""UI protocol adapter. Snapshot reads never scan or mutate Blender data."""
from collections.abc import Mapping
from dataclasses import dataclass, fields, is_dataclass
import threading
import uuid

from .engine import result
from .model import BackendError, digest
from . import presentation

_REQUIRED = {
    'Text': ('en', 'ja'),
    'RowRef': ('keyconfig_name', 'keymap_name', 'space_type', 'region_type', 'is_modal', 'kmi_id'),
    'Choice': ('key', 'label', 'help'),
    'Field': ('name', 'kind', 'value', 'label', 'help', 'choices', 'enabled'),
    'Binding': ('ref', 'label', 'registration', 'shortcut', 'status', 'active', 'operator_id', 'fields', 'modifiers', 'higher_sources', 'details', 'editable'),
    'Event': ('slot', 'token', 'label', 'help', 'kind', 'enabled', 'selected'),
    'Category': ('key', 'label', 'help', 'children'),
    'Group': ('key', 'label', 'rows', 'active_count', 'disabled_count'),
    'UnusedGroup': ('key', 'label', 'candidates', 'count'),
    'PreviewGroup': ('label', 'keep', 'remove'),
    'Preview': ('token', 'revision', 'groups', 'delete_count'),
    'Snapshot': ('revision', 'fields', 'rows', 'visible_rows', 'match_count', 'view_mode', 'events', 'groups', 'categories', 'unused_groups', 'selected_parent', 'selected_child', 'can_back', 'preview', 'help_topics', 'messages', 'no_selection', 'needs_initial_keymap'),
    'Request': ('operation_id', 'arguments', 'expected_revision', 'phase', 'preview_token'),
    'StateChange': ('field_name', 'value', 'expected_revision'),
    'ItemChange': ('target', 'field_name', 'value', 'expected_revision'),
    'Outcome': ('status', 'message', 'deleted_count'),
}


def validate_contract(module):
    for name, expected in _REQUIRED.items():
        cls = getattr(module, name, None)
        if cls is None or not is_dataclass(cls) or tuple(field.name for field in fields(cls)) != expected:
            raise BackendError('UI_CONTRACT_MISMATCH', type_name=name)
        if not cls.__dataclass_params__.frozen:
            raise BackendError('UI_CONTRACT_MUTABLE', type_name=name)
    return module


def _identity(owner):
    if owner is None:
        return 'none'
    pointer = getattr(owner, 'as_pointer', None)
    if callable(pointer):
        value = pointer()
        if type(value) is not int or value <= 0:
            raise BackendError('INVALID_CONTEXT')
        return 'rna:' + str(value)
    # Ordinary Python objects are supported only for dependency-injected tests.
    return 'python:' + str(id(owner))


def interface_language(context):
    preferences = getattr(context, 'preferences', None)
    view = getattr(preferences, 'view', None)
    if view is None or not bool(getattr(view, 'use_translate_interface', True)):
        return 'en'
    language = getattr(view, 'language', 'en_US')
    return 'ja' if isinstance(language, str) and language.lower().startswith('ja') else 'en'


@dataclass
class _Session:
    engine: object
    generation: str
    owner: object
    window: object
    snapshots: dict
    invalid: bool = False


class BackendAdapter:
    """Pass the UI's actual adapter_contract module and an explicit Engine factory.

    The factory is called only by initialize() or an explicit refresh request.
    on_publish may update owned UI caches/preview rows, never keymap bindings.
    Root must release closed sessions and call close() during unregistration.
    """
    def __init__(self, contract, engine_factory, *, language_resolver=None, on_publish=None):
        self.contract = validate_contract(contract)
        if not callable(engine_factory):
            raise BackendError('INVALID_FACTORY')
        self._factory = engine_factory
        self._language_resolver = language_resolver or interface_language
        self._on_publish = on_publish
        self._sessions = {}
        self._namespace = uuid.uuid4().hex
        self._thread = threading.get_ident()
        self._lock = threading.RLock()
        self._busy = False
        self._closed = False
        self._cold = presentation.cold_snapshot(self.contract)

    def language(self, context):
        try:
            value = self._language_resolver(context)
            return 'ja' if value == 'ja' else 'en'
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            return 'en'

    def session_key(self, context):
        owner = getattr(context, 'window_manager', None)
        if owner is None:
            raise BackendError('INVALID_CONTEXT')
        return self._namespace + ':' + _identity(owner) + ':' + _identity(getattr(context, 'window', None))

    def _session(self, context):
        key = self.session_key(context)
        session = self._sessions.get(key)
        if session is not None:
            try:
                valid = (_identity(session.owner) == _identity(context.window_manager)
                         and _identity(session.window) == _identity(getattr(context, 'window', None)))
            except (ReferenceError, RuntimeError, BackendError):
                valid = False
            if not valid:
                self._sessions.pop(key, None)
                session = None
        return key, session

    def snapshot(self, context):
        if self._closed:
            return self._cold
        try:
            _, session = self._session(context)
        except (BackendError, AttributeError, ReferenceError, RuntimeError):
            return self._cold
        return self._cold if session is None else session.snapshots[self.language(context)]

    def _revision(self, key, session):
        return digest((key, session.generation, session.engine.revision))

    def _publish(self, context, key, session):
        if self._on_publish is not None:
            self._on_publish(context, session.engine)
        revision = self._revision(key, session)
        snapshots = {language: presentation.render(self.contract, session.engine, revision=revision, language=language)
                     for language in ('en', 'ja')}
        session.snapshots = snapshots
        session.invalid = bool(session.engine._invalid)

    def _make_session(self, context, key):
        engine = self._factory(context)
        session = _Session(engine, uuid.uuid4().hex, context.window_manager, getattr(context, 'window', None), {})
        self._publish(context, key, session)
        self._sessions[key] = session
        return session

    def _outcome(self, action, session=None):
        return presentation.outcome(self.contract, action, session.engine.help_topics if session else None)

    def _guard(self, action):
        if threading.get_ident() != self._thread:
            return self._outcome(result('ERROR', 'WRONG_THREAD'))
        with self._lock:
            if self._busy:
                return self._outcome(result('ERROR', 'REENTRANT_CALL'))
            if self._closed:
                return self._outcome(result('ERROR', 'ADAPTER_CLOSED'))
            self._busy = True
            try:
                return action()
            except BackendError as exc:
                return self._outcome(result('ERROR', exc.code, **exc.details))
            except Exception as exc:
                return self._outcome(result('ERROR', 'ADAPTER_ERROR', exception_type=type(exc).__name__))
            finally:
                self._busy = False

    def initialize(self, context):
        def action():
            key = self.session_key(context)
            session = self._make_session(context, key)
            return self._outcome(result(code='READY'), session)
        return self._guard(action)

    def _expected(self, key, session, expected):
        if type(expected) is not str:
            raise BackendError('INVALID_REQUEST', field='expected_revision')
        if session is None or session.invalid:
            raise BackendError('REFRESH_REQUIRED')
        if expected != self._revision(key, session):
            raise BackendError('STALE_REVISION')
        return session.engine.revision

    def _finish(self, context, key, session, action):
        try:
            self._publish(context, key, session)
        except Exception as exc:
            session.invalid = True
            revision = digest((key, session.generation, 'snapshot-unavailable', uuid.uuid4().hex))
            unavailable = presentation.cold_snapshot(self.contract, revision, 'SNAPSHOT_FAILED')
            session.snapshots = {'en': unavailable, 'ja': unavailable}
            action = result('ERROR', 'SNAPSHOT_FAILED', deleted_count=action.deleted_count,
                            prior_status=action.status, prior_code=action.code,
                            exception_type=type(exc).__name__)
        return self._outcome(action, session)

    def dispatch(self, context, request):
        def action():
            if not isinstance(request, self.contract.Request):
                raise BackendError('INVALID_REQUEST', field='request_type')
            if (type(request.operation_id) is not str or type(request.expected_revision) is not str
                    or type(request.phase) is not str or type(request.preview_token) is not str
                    or not isinstance(request.arguments, Mapping)):
                raise BackendError('INVALID_REQUEST')
            arguments = dict(request.arguments)
            if any(type(key) is not str or type(value) not in (str, bool, int) for key, value in arguments.items()):
                raise BackendError('INVALID_REQUEST', field='arguments')
            key, session = self._session(context)
            is_refresh = request.operation_id == 'keymap_manager.refresh' and request.phase == 'execute'
            if session is None:
                if not is_refresh:
                    raise BackendError('REFRESH_REQUIRED')
                session = self._make_session(context, key)
            expected = session.engine.revision if is_refresh else self._expected(key, session, request.expected_revision)
            response = session.engine.execute(request.operation_id, arguments, expected,
                                              phase=request.phase, preview_token=request.preview_token)
            return self._finish(context, key, session, response)
        return self._guard(action)

    def set_state(self, context, change):
        def action():
            if not isinstance(change, self.contract.StateChange) or type(change.field_name) is not str or type(change.value) not in (str, bool, int):
                raise BackendError('INVALID_REQUEST')
            key, session = self._session(context)
            expected = self._expected(key, session, change.expected_revision)
            response = session.engine.set_state(change.field_name, change.value, expected)
            return self._finish(context, key, session, response)
        return self._guard(action)

    def set_item(self, context, change):
        def action():
            if (not isinstance(change, self.contract.ItemChange) or not isinstance(change.target, self.contract.RowRef)
                    or type(change.field_name) is not str or type(change.value) not in (str, bool, int)):
                raise BackendError('INVALID_REQUEST')
            key, session = self._session(context)
            expected = self._expected(key, session, change.expected_revision)
            response = session.engine.set_item(dict(change.target.arguments()), change.field_name, change.value, expected)
            return self._finish(context, key, session, response)
        return self._guard(action)

    def release_session(self, context):
        def action():
            key = self.session_key(context)
            self._sessions.pop(key, None)
            return self._outcome(result(code='SESSION_RELEASED'))
        return self._guard(action)

    def reopen(self):
        if threading.get_ident() != self._thread or self._busy:
            raise BackendError('ADAPTER_BUSY')
        with self._lock:
            self._sessions.clear()
            self._namespace = uuid.uuid4().hex
            self._closed = False

    def close(self):
        if threading.get_ident() != self._thread or self._busy:
            raise BackendError('ADAPTER_BUSY')
        with self._lock:
            self._sessions.clear()
            self._closed = True
