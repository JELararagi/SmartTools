# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Bodies of all 22 published operations, independent of bpy and UI classes.

A port supplies live snapshots and narrowly scoped mutations. The engine owns
revision checks, confirmation tokens, dispatch and operation-level accounting.
The port must clean up its own failed item creation or report a fatal cleanup
failure. It must never substitute a partial locator for a complete address.
"""
from dataclasses import dataclass
import json
import re
import secrets
import threading

from . import codec, queries
from .help_text import HELP_TOPICS
from .model import BackendError, EventData, MODIFIERS, canonical, digest
from .state import OPERATIONS, StateFacade, operation_arguments, validate_state

_EVENT_FIELDS = frozenset(EventData.__dataclass_fields__)
_REF_FIELDS = ('keyconfig_name', 'keymap_name', 'space_type', 'region_type', 'is_modal', 'kmi_id')
_OPERATOR_ID = re.compile(r'[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*\Z')


@dataclass(frozen=True)
class ActionResult:
    status: str
    code: str
    data_text: str = '{}'
    deleted_count: int | None = None

    @property
    def data(self):
        return json.loads(self.data_text)


def result(status='OK', code='', *, deleted_count=None, **values):
    return ActionResult(status, code, canonical(values), deleted_count)


@dataclass(frozen=True)
class PreviewPlan:
    token: str
    scan_revision: str
    groups: tuple

    @property
    def remove(self):
        return tuple(row for group in self.groups for row in group[1:])


def record_value(row, name):
    if name == 'active':
        return row.active
    if name == 'propvalue':
        return row.propvalue
    if name in _EVENT_FIELDS:
        return getattr(row.event, name)
    if name.startswith('properties.'):
        key = name[len('properties.'):]
        if key in row.properties:
            return row.properties[key]
    raise BackendError('INVALID_ITEM_FIELD', field=name)


class Engine:
    def __init__(self, port, state, store, *, categories=None, candidates=None,
                 help_topics=None, on_preset_choices=None):
        self._on_preset_choices = on_preset_choices
        self.port = port
        self.state = state if isinstance(state, StateFacade) else StateFacade(state)
        self.store = store
        self._category_provider = categories
        self._candidate_provider = candidates
        self.help_topics = dict(HELP_TOPICS if help_topics is None else help_topics)
        self._lock = threading.RLock()
        self._thread = threading.get_ident()
        self._busy = False
        self._invalid = False
        self._base = ''
        self._epoch = 0
        self.preview = None
        self.last_result = result(code='READY')
        self._refresh()
        self._handlers = {
            'show_help': self._help,
            'choose_item_value': self._choose_value,
            'select_key': self._select_key,
            'refresh': self._refresh_operation,
            'toggle_conflict_view': self._toggle_conflict,
            'toggle_unused_view': self._toggle_unused,
            'select_unused_parent': self._select_parent,
            'select_unused_child': self._select_child,
            'unused_back': self._unused_back,
            'consolidate_duplicate_keymaps': self._consolidate,
            'activate_shadowed_keymap': self._activate,
            'cycle_modifier': self._cycle,
            'copy_operator_id': self._copy,
            'toggle_filter_modifier': self._toggle_modifier,
            'toggle_visual_view': self._toggle_visual,
            'clear_visual_filters': self._clear_visual,
            'export_keymap': self._export,
            'import_keymap': self._import,
            'save_keymap_preset': self._save_preset,
            'load_keymap_preset': self._load_preset,
            'delete_keymap_preset': self._delete_preset,
            'load_blender_keymap_preset': self._load_standard,
        }
        if {'keymap_manager.' + name for name in self._handlers} != set(OPERATIONS):
            raise BackendError('OPERATION_CONTRACT_MISMATCH')

    def _base_value(self, scan, state, names):
        return digest(dict(scan=scan.revision, state=state, presets=names))

    def _refresh(self, scan=None, state=None, names=None):
        scan = self.port.scan() if scan is None else scan
        state = self.state.read() if state is None else state
        names = tuple(self.store.names()) if names is None else tuple(names)
        base = self._base_value(scan, state, names)
        if base != self._base:
            self._epoch += 1
        if self.preview is not None and self.preview.scan_revision != scan.revision:
            self.preview = None
        self.scan = scan
        self.values = state
        self.preset_names = names
        provider = self._category_provider
        self.categories = tuple(provider(scan) if callable(provider) else
                                queries.runtime_categories(scan) if provider is None else provider)
        self.visible, self.roles = queries.visible_records(scan, state)
        self.unused = ()
        if state['view_mode'] == 'UNUSED' and state['unused_child_key']:
            child = self._selected_child(state['unused_parent_key'], state['unused_child_key'], strict=False)
            if child is not None:
                provider = self._candidate_provider
                candidates = tuple(provider(scan) if callable(provider) else
                                   queries.runtime_candidates(scan) if provider is None else provider)
                self.unused = queries.unused_candidates(scan, child.location, candidates)
        self._base = base
        self.revision = digest(dict(base=base, epoch=self._epoch,
                                    preview=self.preview.token if self.preview else ''))
        self._invalid = False

    def _check(self, expected_revision, *, stale_code='STALE_REVISION'):
        if self._invalid:
            raise BackendError('REFRESH_REQUIRED')
        if type(expected_revision) is not str or expected_revision != self.revision:
            raise BackendError(stale_code)
        scan = self.port.scan()
        state = self.state.read()
        names = tuple(self.store.names())
        if self._base_value(scan, state, names) != self._base:
            self.preview = None
            self._refresh(scan, state, names)
            raise BackendError(stale_code)

    def _perform(self, action, expected_revision, *, check=True, stale_code='STALE_REVISION'):
        if threading.get_ident() != self._thread:
            return result('ERROR', 'WRONG_THREAD')
        with self._lock:
            if self._busy:
                return result('ERROR', 'REENTRANT_CALL')
            self._busy = True
            try:
                if check:
                    self._check(expected_revision, stale_code=stale_code)
                outcome = action()
            except BackendError as exc:
                outcome = result('ERROR', exc.code, **exc.details)
            except Exception as exc:
                outcome = result('ERROR', 'PORT_ERROR', exception_type=type(exc).__name__)
            finally:
                self._busy = False
            # Keep the guard during readback: a port callback must not dispatch
            # another operation while the first result is being published.
            self._busy = True
            try:
                self._refresh()
            except Exception as exc:
                self._invalid = True
                outcome = result('ERROR', 'READBACK_FAILED',
                                 operation_status=outcome.status,
                                 operation_code=outcome.code,
                                 operation_data=outcome.data,
                                 exception_type=type(exc).__name__,
                                 deleted_count=outcome.deleted_count)
            finally:
                self._busy = False
            self.last_result = outcome
            return outcome

    def execute(self, operation_id, arguments, expected_revision, *, phase='execute', preview_token=''):
        def action():
            if type(operation_id) is not str or operation_id not in OPERATIONS:
                raise BackendError('UNKNOWN_OPERATION')
            if phase not in ('execute', 'preview', 'commit', 'cancel'):
                raise BackendError('INVALID_PHASE')
            if type(preview_token) is not str:
                raise BackendError('INVALID_PREVIEW_TOKEN')
            args = operation_arguments(operation_id, arguments)
            short = operation_id.split('.', 1)[1]
            if short != 'consolidate_duplicate_keymaps':
                if short == 'choose_item_value' and phase == 'cancel':
                    return result('CANCELLED', 'CANCELLED')
                if phase != 'execute':
                    raise BackendError('INVALID_PHASE')
            return self._handlers[short](args, phase, preview_token)
        committing = operation_id == 'keymap_manager.consolidate_duplicate_keymaps' and phase == 'commit'
        return self._perform(action, expected_revision,
                             check=operation_id != 'keymap_manager.refresh',
                             stale_code='STALE_PREVIEW' if committing else 'STALE_REVISION')

    def choices(self, field):
        if field == 'selected_type':
            return tuple(item.key for item in self.scan.options('type'))
        if field == 'selected_value':
            return tuple(item.key for item in self.scan.options('value'))
        if field == 'selected_key_modifier':
            return tuple(item.key for item in self.scan.options('key_modifier'))
        if field == 'visual_editor_filter':
            return ('ALL',) + tuple(dict.fromkeys(km.space_type for km in self.scan.keymaps))
        if field == 'visual_mode_filter':
            return ('ALL',) + tuple(dict.fromkeys(km.name for km in self.scan.keymaps))
        if field == 'preset_select':
            return ('NONE',) + tuple(self.preset_token(name) for name in self.preset_names)
        if field == 'export_scope':
            return ('MODIFIED', 'ALL')
        return ()

    @staticmethod
    def preset_token(name):
        return 'preset:' + name

    def _selected_preset(self):
        token = self.values['preset_select']
        if not token.startswith('preset:') or token[7:] not in self.preset_names:
            raise BackendError('PRESET_NOT_FOUND')
        return token[7:]

    def set_state(self, name, value, expected_revision):
        def action():
            validate_state(name, value, self.choices(name))
            if name == 'unused_parent_key' and value:
                return self._select_parent({'parent_key': value}, 'execute', '')
            if name == 'unused_child_key' and value:
                return self._select_child({'parent_key': self.values['unused_parent_key'],
                                           'child_key': value}, 'execute', '')
            if name != 'consolidation_preview_index' and not name.startswith('expanded_'):
                self.preview = None
            self.state.apply({name: value})
            return result(code='STATE_CHANGED', field=name)
        return self._perform(action, expected_revision)

    def resolve_ui(self, arguments, prefix=''):
        try:
            locator = {name: arguments[prefix + name] for name in _REF_FIELDS}
        except (KeyError, TypeError) as exc:
            raise BackendError('INVALID_TARGET') from exc
        for name in _REF_FIELDS[:4]:
            if type(locator[name]) is not str or not locator[name]:
                raise BackendError('TARGET_NOT_FOUND')
        if type(locator['is_modal']) is not bool or type(locator['kmi_id']) is not int or locator['kmi_id'] < 0:
            raise BackendError('INVALID_TARGET')
        matches = tuple(row for row in self.scan.records if row.key.ui_arguments() == locator)
        if not matches:
            raise BackendError('TARGET_NOT_FOUND')
        if len(matches) != 1:
            raise BackendError('AMBIGUOUS_TARGET')
        return matches[0]

    def set_item(self, arguments, field_name, value, expected_revision):
        def action():
            row = self.resolve_ui(arguments)
            self._edit(row, {field_name: value})
            return result(code='ITEM_CHANGED', target=row.key.values(), field=field_name)
        return self._perform(action, expected_revision)

    def _edit(self, row, patch):
        self._change_many(((row, patch),))

    def _change_many(self, changes):
        prepared = []
        for row, patch in changes:
            if not row.editable or row.role not in ('USER', 'ADDON'):
                raise BackendError('READ_ONLY_TARGET')
            if any(name not in _EVENT_FIELDS and name not in ('active', 'propvalue')
                   and not name.startswith('properties.') for name in patch):
                raise BackendError('INVALID_ITEM_FIELD')
            normalized = dict(self.port.validate_fields(row, dict(patch)))
            if set(normalized) != set(patch):
                raise BackendError('PORT_CONTRACT_ERROR', reason='changed_patch_scope')
            capture = getattr(self.port, 'capture_fields', None)
            restore = getattr(self.port, 'restore_fields', None)
            if callable(capture) != callable(restore):
                raise BackendError('PORT_CONTRACT_ERROR', reason='incomplete_checkpoint_interface')
            checkpoint = capture(row, normalized) if callable(capture) else None
            prepared.append((row, normalized, checkpoint))
        attempted = []
        try:
            for row, patch, checkpoint in prepared:
                attempted.append((row, patch, checkpoint))
                self.port.set_fields(row, patch)
                current = self.port.scan().find(row.key)
                if current.identity_token != row.identity_token:
                    raise BackendError('TARGET_REPLACED')
                for name, value in patch.items():
                    if canonical(record_value(current, name)) != canonical(value):
                        raise BackendError('ITEM_VALUE_NOT_APPLIED', field=name)
        except Exception as exc:
            rollback_failed = []
            for old, patch, checkpoint in reversed(attempted):
                try:
                    current = self.port.scan().find(old.key)
                    if current.identity_token != old.identity_token:
                        raise BackendError('TARGET_REPLACED')
                    names = set(patch)
                    if names.intersection(_EVENT_FIELDS):
                        names.update(_EVENT_FIELDS)
                    inverse = {name: record_value(old, name) for name in names
                               if canonical(record_value(current, name)) != canonical(record_value(old, name))}
                    if checkpoint is not None:
                        self.port.restore_fields(current, checkpoint)
                    elif inverse:
                        self.port.set_fields(current, inverse)
                    restored = self.port.scan().find(old.key)
                    if any(canonical(record_value(restored, name)) != canonical(record_value(old, name)) for name in names):
                        raise BackendError('ROLLBACK_VALUE_MISMATCH')
                except Exception as cleanup:
                    rollback_failed.append(dict(target=old.key.values(),
                                                code=getattr(cleanup, 'code', type(cleanup).__name__)))
            self.preview = None
            raise BackendError('MUTATION_FAILED', cause=getattr(exc, 'code', type(exc).__name__),
                               rollback_failed=rollback_failed,
                               attempted=[row.key.values() for row, patch, checkpoint in attempted]) from exc
        self.preview = None

    def _refresh_operation(self, args, phase, token):
        return result(code='REFRESHED')

    def _help(self, args, phase, token):
        topic = args['topic']
        if topic not in self.help_topics:
            raise BackendError('UNKNOWN_TOPIC')
        en, ja = self.help_topics[topic]
        return result(code='HELP', help_topic=topic, text_en=en, text_ja=ja)

    def _select_key(self, args, phase, token):
        if self.values['view_mode'] == 'UNUSED':
            raise BackendError('VIEW_DISABLED')
        event_type = args['event_type']
        if event_type not in self.choices('selected_type') or event_type == 'NONE':
            raise BackendError('INVALID_EVENT')
        self.preview = None
        self.state.apply(dict(selected_type=event_type, operator_id_query='',
                              view_mode='NORMAL', use_exact_value=False))
        return result(code='KEY_SELECTED')

    def _toggle_view(self, name):
        view = 'NORMAL' if self.values['view_mode'] == name else name
        self.preview = None
        patch = {'view_mode': view}
        if name == 'UNUSED':
            patch.update(unused_parent_key='', unused_child_key='', expanded_unused_base_keys='')
        self.state.apply(patch)
        return result(code='VIEW_CHANGED', view=view)

    def _toggle_conflict(self, args, phase, token):
        return self._toggle_view('CONFLICT')

    def _toggle_unused(self, args, phase, token):
        return self._toggle_view('UNUSED')

    def _toggle_visual(self, args, phase, token):
        return self._toggle_view('VISUAL')

    def _selected_child(self, parent_key, child_key, *, strict=True):
        for parent in self.categories:
            if parent.key == parent_key:
                for child in parent.children:
                    if child.key == child_key:
                        return child
        if strict:
            raise BackendError('INVALID_CATEGORY')
        return None

    def _select_parent(self, args, phase, token):
        if self.values['view_mode'] != 'UNUSED':
            raise BackendError('VIEW_DISABLED')
        parent = next((parent for parent in self.categories if parent.key == args['parent_key']), None)
        if parent is None:
            raise BackendError('INVALID_CATEGORY')
        child = parent.children[0].key if len(parent.children) == 1 else ''
        self.state.apply(dict(unused_parent_key=parent.key, unused_child_key=child,
                              expanded_unused_base_keys=''))
        return result(code='CATEGORY_SELECTED')

    def _select_child(self, args, phase, token):
        if self.values['view_mode'] != 'UNUSED':
            raise BackendError('VIEW_DISABLED')
        if args['parent_key'] != self.values['unused_parent_key']:
            raise BackendError('INVALID_CATEGORY')
        self._selected_child(args['parent_key'], args['child_key'])
        self.state.apply(dict(unused_child_key=args['child_key'], expanded_unused_base_keys=''))
        return result(code='CATEGORY_SELECTED')

    def _unused_back(self, args, phase, token):
        if self.values['view_mode'] != 'UNUSED':
            raise BackendError('VIEW_DISABLED')
        if self.values['unused_child_key']:
            self.state.apply(dict(unused_child_key='', expanded_unused_base_keys=''))
        elif self.values['unused_parent_key']:
            self.state.apply(dict(unused_parent_key='', unused_child_key=''))
        else:
            return result('NO_CHANGE', 'NO_CHANGE')
        return result(code='CATEGORY_SELECTED')

    def _consolidate(self, args, phase, token):
        if phase == 'cancel':
            if self.preview is not None and token != self.preview.token:
                raise BackendError('STALE_PREVIEW')
            self.preview = None
            return result('CANCELLED', 'CANCELLED', deleted_count=0)
        if phase in ('execute', 'preview'):
            groups = queries.duplicate_groups(self.scan.records)
            if not groups:
                self.preview = None
                return result('NO_DUPLICATES', 'NO_DUPLICATES', deleted_count=0)
            if any(not row.editable for group in groups for row in group):
                raise BackendError('READ_ONLY_TARGET')
            self.preview = PreviewPlan(secrets.token_hex(24), self.scan.revision, groups)
            return result('PREVIEW', 'DUPLICATE_PREVIEW', planned_delete=len(self.preview.remove))
        if self.preview is None:
            raise BackendError('CONFIRMATION_REQUIRED')
        preview = self.preview
        if token != preview.token or preview.scan_revision != self.scan.revision:
            raise BackendError('STALE_PREVIEW')
        current_groups = queries.duplicate_groups(self.scan.records)
        if tuple(tuple(row.fingerprint() for row in group) for group in current_groups) != tuple(tuple(row.fingerprint() for row in group) for group in preview.groups):
            raise BackendError('STALE_PREVIEW')
        for row in preview.remove:
            self.port.preflight_remove(row)
        if self.port.scan().revision != preview.scan_revision:
            raise BackendError('STALE_PREVIEW')
        failure = None
        for row in preview.remove:
            try:
                self.port.remove(row)
                after = self.port.scan()
                if any(item.key == row.key and item.identity_token == row.identity_token for item in after.records):
                    raise BackendError('DELETE_NOT_APPLIED')
            except Exception as exc:
                failure = getattr(exc, 'code', type(exc).__name__)
                break
        self.preview = None
        after = self.port.scan()
        live = {(row.key, row.identity_token) for row in after.records}
        removed = tuple(row for row in preview.remove if (row.key, row.identity_token) not in live)
        if failure:
            return result('PARTIAL' if removed else 'ERROR', 'DELETE_FAILED',
                          deleted_count=len(removed), removed=[row.key.values() for row in removed],
                          cause=failure, planned_count=len(preview.remove))
        return result(code='DUPLICATES_REMOVED', deleted_count=len(removed),
                      removed=[row.key.values() for row in removed])

    def _activate(self, args, phase, token):
        target = self.resolve_ui(args, 'target_')
        sources = queries.higher_sources(self.scan, target)
        if not sources:
            raise BackendError('NO_HIGHER')
        changes = [(source, {'active': False}) for source in sources]
        if not target.active:
            changes.append((target, {'active': True}))
        self._change_many(tuple(changes))
        return result(code='TARGET_ACTIVATED', disabled=[row.key.values() for row in sources],
                      target=target.key.values())

    def _cycle(self, args, phase, token):
        modifier = args['modifier']
        if modifier not in MODIFIERS:
            raise BackendError('INVALID_MODIFIER')
        row = self.resolve_ui(args)
        if row.event.any:
            patch = {name: -1 for name in MODIFIERS}
            patch.update({'any': False, modifier: 0})
        else:
            patch = {modifier: {0: 1, 1: -1, -1: 0}[getattr(row.event, modifier)]}
        self._edit(row, patch)
        return result(code='ITEM_CHANGED', target=row.key.values(), field=modifier)

    def _choose_value(self, args, phase, token):
        row = self.resolve_ui(args)
        field = 'propvalue' if args['prop_name'] == 'modal_value' else args['prop_name']
        if field not in ('type', 'value', 'direction', 'key_modifier', 'propvalue'):
            raise BackendError('INVALID_ITEM_FIELD')
        if field == 'propvalue' and not row.key.is_modal:
            raise BackendError('INVALID_ITEM_FIELD')
        choices = {item.key for item in self.scan.options(field, row.key.location)}
        if args['choice'] not in choices:
            raise BackendError('INVALID_CHOICE')
        self._edit(row, {field: args['choice']})
        return result(code='ITEM_CHANGED', target=row.key.values(), field=field)

    def _copy(self, args, phase, token):
        value = args['operator_id']
        if not _OPERATOR_ID.fullmatch(value):
            raise BackendError('INVALID_OPERATOR')
        try:
            before = self.port.clipboard_get()
        except Exception as exc:
            raise BackendError('CLIPBOARD_READ_FAILED') from exc
        try:
            self.port.clipboard_set(value)
            if self.port.clipboard_get() != value:
                raise BackendError('CLIPBOARD_VALUE_NOT_APPLIED')
        except Exception as exc:
            failed = False
            try:
                if self.port.clipboard_get() != before:
                    self.port.clipboard_set(before)
                failed = self.port.clipboard_get() != before
            except Exception:
                failed = True
            raise BackendError('CLIPBOARD_WRITE_FAILED', rollback_failed=failed) from exc
        return result(code='OPERATOR_COPIED', operator_id=value)

    def _toggle_modifier(self, args, phase, token):
        name = args['modifier']
        if name not in MODIFIERS:
            raise BackendError('INVALID_MODIFIER')
        self.preview = None
        self.state.apply({'selected_' + name: not self.values['selected_' + name],
                          'use_exact_modifiers': True})
        return result(code='FILTER_CHANGED')

    def _clear_visual(self, args, phase, token):
        self.preview = None
        self.state.apply(dict(visual_editor_filter='ALL', visual_mode_filter='ALL',
                              visual_search_text=''))
        return result(code='FILTER_CHANGED')

    def _export(self, args, phase, token):
        scope = self.values['export_scope']
        if scope not in ('ALL', 'MODIFIED'):
            raise BackendError('INVALID_SCOPE')
        rows = tuple(row for row in self.scan.records if row.role == 'USER'
                     and (scope == 'ALL' or row.modified))
        maps = self.scan.keymaps if scope == 'ALL' else ()
        document = codec.encode_records(rows, maps)
        path = self.store.write(self.values['export_path'], document)
        try:
            self.state.apply({'export_path': path})
        except BackendError as exc:
            raise BackendError('FILE_SAVED_STATE_FAILED', path=path, exported=len(rows),
                               cause=exc.code) from exc
        return result(code='EXPORTED', exported=len(rows), path=path,
                      exported_keys=[row.key.values() for row in rows])

    def _append_document(self, document):
        decoded = codec.decode_document(document)
        problems = []
        imported = []
        duplicates = 0
        restored_addon = []
        fatal = False
        for outcome in decoded.outcomes:
            if isinstance(outcome, codec.Problem):
                problems.append(outcome.as_dict())
                continue
            item = outcome
            before = self.port.scan()
            users = tuple(row for row in before.records if row.role == 'USER'
                          and row.content_key(include_layer=False) == item.content_key())
            addons = tuple(row for row in before.records if row.role == 'ADDON'
                           and row.content_key(include_layer=False, include_active=False)
                           == item.content_key(include_active=False))
            if len(addons) > 1:
                problems.append(dict(group_index=item.group_index, row_index=item.row_index,
                                     code='AMBIGUOUS_ADDON_MATCH'))
                continue
            created = None
            try:
                if not users:
                    self.port.validate_import(item)
                    created = self.port.append(item)
                    if created.role != 'USER' or created.content_key(include_layer=False) != item.content_key():
                        raise BackendError('APPEND_VALUE_MISMATCH')
                if addons and addons[0].active != item.active:
                    self._change_many(((addons[0], {'active': item.active}),))
                    restored_addon.append(addons[0].key.values())
            except Exception as exc:
                cleanup_failed = False
                if created is not None:
                    try:
                        current = self.port.scan().find(created.key)
                        if current.identity_token != created.identity_token:
                            raise BackendError('TARGET_REPLACED')
                        self.port.remove(current)
                    except Exception:
                        cleanup_failed = True
                after = self.port.scan()
                before_keys = {(row.key, row.identity_token) for row in before.records}
                remaining = [row.key.values() for row in after.records
                             if (row.key, row.identity_token) not in before_keys]
                cause = getattr(exc, 'code', type(exc).__name__)
                detail = dict(group_index=item.group_index, row_index=item.row_index,
                              code=cause, cleanup_failed=cleanup_failed, remaining_new=remaining)
                problems.append(detail)
                if cleanup_failed or remaining or cause == 'APPEND_CLEANUP_FAILED' or getattr(exc, 'details', {}).get('rollback_failed'):
                    fatal = True
                    break
                continue
            if created is None:
                duplicates += 1
            else:
                imported.append(created.key.values())
        invalid_groups = [problem.as_dict() for problem in decoded.group_problems]
        return result('PARTIAL' if problems or invalid_groups else 'OK',
                      'IMPORT_ABORTED' if fatal else 'IMPORTED',
                      imported=len(imported), imported_keys=imported, duplicates=duplicates,
                      failed=len(problems), problems=problems,
                      invalid_groups=len(invalid_groups), group_problems=invalid_groups,
                      input_rows=decoded.known_row_count, fatal=fatal,
                      restored_addon=restored_addon)

    def _import(self, args, phase, token):
        return self._append_document(self.store.read(self.values['import_path']))

    def _save_preset(self, args, phase, token):
        rows = tuple(row for row in self.scan.records if row.role == 'USER')
        document = codec.encode_records(rows, self.scan.keymaps)
        name = self.values['preset_name']
        path = self.store.write(name, document, preset=True)
        self.preset_names = tuple(self.store.names())
        try:
            if self._on_preset_choices is not None:
                self._on_preset_choices(self.preset_names)
            self.state.apply({'preset_select': self.preset_token(name)})
        except BackendError as exc:
            raise BackendError('FILE_SAVED_STATE_FAILED', path=path, saved=len(rows),
                               cause=exc.code) from exc
        return result(code='PRESET_SAVED', saved=len(rows), name=name, path=path)

    def _load_preset(self, args, phase, token):
        return self._append_document(self.store.read(self._selected_preset(), preset=True))

    def _delete_preset(self, args, phase, token):
        name = self._selected_preset()
        path = self.store.delete_preset(name)
        self.preset_names = tuple(self.store.names())
        try:
            self.state.apply({'preset_select': 'NONE'})
        except BackendError as exc:
            raise BackendError('FILE_DELETED_STATE_FAILED', path=path, cause=exc.code) from exc
        return result(code='PRESET_DELETED', name=name, path=path)

    def _load_standard(self, args, phase, token):
        before = self.port.scan()
        try:
            details = dict(self.port.load_standard())
        except Exception as exc:
            after = self.port.scan()
            raise BackendError('STANDARD_PRESET_FAILED',
                               cause=getattr(exc, 'code', type(exc).__name__),
                               runtime_changed=after.revision != before.revision,
                               before_count=len(before.records), after_count=len(after.records)) from exc
        return result(code='STANDARD_PRESET_LOADED', **details)
