# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import bpy

from .. import lifecycle
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, PointerProperty, StringProperty


def _qr_is_japanese_locale(context=None) -> bool:
    candidates = []
    try:
        candidates.append(str(getattr(getattr(getattr(context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(getattr(bpy.context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or ''))
    except Exception:
        pass
    joined = ' '.join(candidates).upper()
    return any(token in joined for token in ('JA', 'JA_JP', 'JAPANESE', 'JP'))


def _qr_ui_text(en: str, ja: str, context=None) -> str:
    # Static RNA labels/descriptions are registered without a UI context. Keep
    # the canonical English source for Blender's translation dictionary, while
    # draw/report code with context switches immediately to the active language.
    if context is None:
        return str(en)
    return str(ja if _qr_is_japanese_locale(context) else en)


def _shortcut_items(_self=None, context=None):
    # Keep registration-time enum items as canonical English source strings.
    # Blender's translation table supplies the Japanese display text.
    ctx = context
    return [
        (
            key,
            key,
            _qr_ui_text(
                'Use the %(key)s key for the manual Quick Rigid shortcut.',
                '手動で登録する Quick Rigid ショートカットに %(key)s キーを使います。',
                ctx,
            ) % {'key': key},
        )
        for key in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    ]


_SHORTCUT_ITEMS = _shortcut_items(None, None)




def _update_npanel_persist(_self=None, context=None):
    try:
        from .. import runtime as _suite_runtime
        persist = getattr(_suite_runtime, '_persist_npanel_runtime_state', None)
        if callable(persist):
            persist(context, force=False)
    except Exception:
        pass

class QuickRigidSettings(bpy.types.PropertyGroup):
    """Properties to store UI state for QuickRigid addon"""

    show_add_section: BoolProperty(
        name=_qr_ui_text('Show Add Rigid Body Section', '剛体追加セクションを表示'),
        description=_qr_ui_text(
            'Expand the section that adds Active or Passive rigid bodies to the selected mesh objects. Use this when preparing objects for rigid-body simulation.',
            '選択メッシュへ アクティブ / パッシブ剛体を追加するセクションを展開します。剛体シミュレーションの準備時に使います。',
        ),
        default=True,
            update=_update_npanel_persist,
)
    show_main_settings: BoolProperty(
        name=_qr_ui_text('Show Main Settings', 'メイン設定を表示'),
        description=_qr_ui_text(
            'Expand the section that exposes the active rigid body type and animated-state controls. Use it to confirm whether the object is Active or Passive and to switch animation control.',
            'アクティブ剛体のタイプ表示とアニメーション状態を調整するセクションを展開します。アクティブ / パッシブ の確認やアニメーション制御の切り替えに使います。',
        ),
        default=True,
            update=_update_npanel_persist,
)
    show_mass: BoolProperty(
        name=_qr_ui_text('Show Mass Settings', '質量設定を表示'),
        description=_qr_ui_text(
            'Expand the mass section for editing rigid-body mass values and mass-related setup tools. Open this when tuning how heavy each object should behave in simulation.',
            '剛体の質量値や質量調整用ツールを扱うセクションを展開します。各オブジェクトをどの程度の重さで振る舞わせるか調整するときに使います。',
        ),
        default=True,
            update=_update_npanel_persist,
)
    show_surface: BoolProperty(
        name=_qr_ui_text('Show Surface Response', '表面応答を表示'),
        description=_qr_ui_text(
            'Expand the friction and restitution controls. Use this when tuning sliding resistance and bounce for the active rigid body.',
            '摩擦と反発を調整するセクションを展開します。アクティブ剛体の滑りやすさや跳ね返りを調整するときに使います。',
        ),
        default=True,
            update=_update_npanel_persist,
)
    show_simulation: BoolProperty(
        name=_qr_ui_text('Show Simulation Settings', 'シミュレーション設定を表示'),
        description=_qr_ui_text(
            'Expand the scene-level rigid-body world controls such as gravity and time scale. Use this when adjusting the overall behavior of the rigid-body simulation.',
            '重力やタイムスケールなど、シーン全体の剛体ワールド設定を展開します。剛体シミュレーション全体の挙動を調整するときに使います。',
        ),
        default=True,
            update=_update_npanel_persist,
)
    show_presets: BoolProperty(
        name=_qr_ui_text('Show Presets', 'プリセットを表示'),
        description=_qr_ui_text(
            'Expand the preset section for saving, applying, and deleting reusable rigid-body settings. Use presets when you want consistent setups across multiple objects.',
            '再利用できる剛体設定の保存・適用・削除を行うプリセットセクションを展開します。複数オブジェクトへ同じ設定を使い回したいときに使います。',
        ),
        default=False,
            update=_update_npanel_persist,
)
    show_bake: BoolProperty(
        name=_qr_ui_text('Show Bake Settings', 'ベイク設定を表示'),
        description=_qr_ui_text(
            'Expand the bake and cache section for rigid-body simulation. Use it to bake dynamics, preview cache progress, or clear baked data.',
            '剛体シミュレーションのベイクとキャッシュ管理セクションを展開します。ダイナミクスのベイク、進行状況確認、ベイク削除に使います。',
        ),
        default=False,
            update=_update_npanel_persist,
)
    show_timeline: BoolProperty(
        name=_qr_ui_text('Show Timeline Settings', 'タイムライン設定を表示'),
        description=_qr_ui_text(
            'Expand the cache frame-range controls. Use this when changing the bake start frame, end frame, or cache step.',
            'キャッシュのフレーム範囲設定を展開します。ベイク開始フレーム、終了フレーム、キャッシュステップを変えるときに使います。',
        ),
        default=True,
            update=_update_npanel_persist,
)
    show_sim_settings: BoolProperty(
        name=_qr_ui_text('Show Advanced Simulation Settings', '詳細シミュレーション設定を表示'),
        description=_qr_ui_text(
            'Expand advanced rigid-body world solver options such as solver iterations and split impulse. Use this when stabilizing difficult simulations.',
            'ソルバー反復回数やインパルス分割など、剛体ワールドの詳細設定を展開します。難しいシミュレーションを安定させたいときに使います。',
        ),
        default=True,
            update=_update_npanel_persist,
)
    show_cache_status: BoolProperty(
        name=_qr_ui_text('Show Cache Status', 'キャッシュ状態を表示'),
        description=_qr_ui_text(
            'Expand the cache status section to check whether the rigid-body cache is baked, baking, or still empty. It also exposes disk-cache options when available.',
            '剛体キャッシュがベイク済みか、ベイク中か、未作成かを確認するセクションを展開します。利用可能な場合はディスクキャッシュ設定も表示します。',
        ),
        default=True,
            update=_update_npanel_persist,
)
    show_settings: BoolProperty(
        name=_qr_ui_text('Show Addon Settings', 'アドオン設定を表示'),
        description=_qr_ui_text(
            'Expand the package-level Quick Rigid settings, manual shortcut setup help, and support links. Use this when configuring how Quick Rigid behaves in the standard 3D View Sidebar N-panel.',
            'Quick Rigid のパッケージ設定、手動ショートカット設定、連絡先リンクを展開します。通常の3DビューサイドバーNパネル内の Quick Rigid を調整するときに使います。',
        ),
        default=False,
            update=_update_npanel_persist,
)

    enable_floating_menu: BoolProperty(
        name=_qr_ui_text('Enable Floating Menu', 'フローティングメニューを有効化'),
        description=_qr_ui_text(
            'Show the manual shortcut setup for the Quick Rigid floating menu. This package never edits Blender keymaps automatically; copy the registration info shown below and register it yourself in Preferences > Keymap when needed.',
            'Quick Rigid フローティングメニューの手動ショートカット設定欄を表示します。このパッケージは Blender のキーマップを自動変更しないため、下に表示される登録情報を必要なときだけコピーし、プリファレンス > キーマップ から手動登録してください。',
        ),
        default=False,
        update=lambda self, context: self.update_floating_menu_state(context),
    )

    shortcut_key: EnumProperty(
        name=_qr_ui_text('Key', 'キー'),
        description=_qr_ui_text(
            'Choose the keyboard key used for the manual Quick Rigid shortcut registration. Combine it with Ctrl, Alt, and Shift below as needed.',
            '手動で登録する Quick Rigid ショートカットに使うキーを選びます。必要に応じて下の Ctrl / Alt / Shift と組み合わせてください。',
        ),
        # Blender does not allow a string default when EnumProperty items is a callback.
        # Use a static item list so the default identifier remains valid and registration
        # cannot fail with: default can only be an integer when items is a function.
        items=_SHORTCUT_ITEMS,
        default='U',
            update=_update_npanel_persist,
)

    use_ctrl: BoolProperty(
        name='Ctrl',
        description=_qr_ui_text(
            'Include Ctrl in the manual Quick Rigid shortcut combination.',
            '手動で登録する Quick Rigid ショートカットに Ctrl を含めます。',
        ),
        default=False,
            update=_update_npanel_persist,
)

    use_alt: BoolProperty(
        name='Alt',
        description=_qr_ui_text(
            'Include Alt in the manual Quick Rigid shortcut combination.',
            '手動で登録する Quick Rigid ショートカットに Alt を含めます。',
        ),
        default=False,
            update=_update_npanel_persist,
)

    use_shift: BoolProperty(
        name='Shift',
        description=_qr_ui_text(
            'Include Shift in the manual Quick Rigid shortcut combination.',
            '手動で登録する Quick Rigid ショートカットに Shift を含めます。',
        ),
        default=False,
            update=_update_npanel_persist,
)

    def update_floating_menu_state(self, context=None):
        """Compatibility hook. Smart Cloth never edits Blender keymaps automatically."""
        _update_npanel_persist(self, context)
        return None


class RigidBodyPresetItem(bpy.types.PropertyGroup):
    """Property group to store rigid body presets in scene data"""

    name: StringProperty(
        name=_qr_ui_text('Preset Name', 'プリセット名'),
        description=_qr_ui_text(
            'Name of the rigid body preset. Choose a label that makes the simulation purpose easy to identify later.',
            '剛体プリセットの名前です。あとで目的を判別しやすい名前を付けてください。',
        ),
        default=_qr_ui_text('New Preset', '新規プリセット'),
    )
    settings_json: StringProperty(
        name=_qr_ui_text('Preset Settings', 'プリセット設定'),
        description=_qr_ui_text(
            'JSON representation of the rigid body settings stored in this preset. This is internal data and normally does not need to be edited manually.',
            'このプリセットに保存される剛体設定の JSON 文字列です。内部管理用データなので、通常は手動編集不要です。',
        ),
        default='{}',
    )

    def get_settings(self):
        """Convert JSON string to Python dict"""
        try:
            import json
            return json.loads(self.settings_json)
        except Exception:
            return {}

    def set_settings(self, settings_dict):
        """Convert Python dict to JSON string"""
        import json
        self.settings_json = json.dumps(settings_dict)



def _safe_register_class(cls):
    return lifecycle.register_class(cls, scope='quick.properties.classes')


def _safe_unregister_class(cls):
    del cls
    lifecycle.release_scope('quick.properties.classes')

classes = [
    QuickRigidSettings,
    RigidBodyPresetItem,
]


def register():
    mark = lifecycle.checkpoint()
    try:
        for cls in classes:
            lifecycle.register_class(cls, scope='quick.properties.classes')
        lifecycle.register_rna(
            bpy.types.Scene,
            'quick_rigid_settings',
            PointerProperty(
                name='Quick Rigid Settings',
                description='Stores Quick Rigid settings edited from the Smart Cloth N-panel for this scene.',
                type=QuickRigidSettings,
            ),
            scope='quick.properties.rna',
        )
        lifecycle.register_rna(
            bpy.types.Scene,
            'rigid_body_presets',
            CollectionProperty(
                name='Quick Rigid Presets',
                description='Stores Quick Rigid rigid-body preset rows edited from the Smart Cloth N-panel.',
                type=RigidBodyPresetItem,
            ),
            scope='quick.properties.rna',
        )
    except Exception:
        lifecycle.rollback_to(mark)
        raise


def unregister():
    lifecycle.release_scope('quick.properties.rna')
    lifecycle.release_scope('quick.properties.classes')
