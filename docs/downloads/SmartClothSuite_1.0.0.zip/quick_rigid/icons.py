# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

# Custom preview-image loading is intentionally disabled. Blender calls panel
# draw/header callbacks frequently, and loading or freeing preview images from
# UI refresh paths can destabilize Blender 5.x on some systems. Keep these
# compatibility functions as no-ops for any older internal imports.
icons_collection = None


def load_icons():
    return None


def unload_icons():
    global icons_collection
    icons_collection = None
    return None


def get_icon_id(icon_name):
    del icon_name
    return 0
