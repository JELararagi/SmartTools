# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import bpy

from .. import lifecycle

try:
    from .. import ui_icons as _suite_ui_icons
except Exception:
    _suite_ui_icons = None


def _qr_is_japanese_locale(context=None) -> bool:
    candidates = []
    try:
        candidates.append(str(getattr(getattr(getattr(context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(getattr(bpy.context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or ''))
    except Exception:
        pass
    joined = ' '.join(candidates).upper()
    return any(token in joined for token in ('JA', 'JA_JP', 'JAPANESE', 'JP'))


def _qr_ui_text(en: str, ja: str, context=None) -> str:
    return str(ja if _qr_is_japanese_locale(context) else en)



def _qr_custom_icon_id(icon_name: str) -> int:
    try:
        getter = getattr(_suite_ui_icons, 'get_icon_id', None)
        return int(getter(str(icon_name)) if callable(getter) else 0)
    except Exception:
        return 0


def _qr_operator_with_custom_icon(layout, operator_id: str, *, text: str, custom_icon: str = '', fallback_icon: str = 'NONE', **props):
    icon_value = _qr_custom_icon_id(custom_icon) if custom_icon else 0
    try:
        if icon_value:
            op = layout.operator(operator_id, text=text, icon_value=icon_value)
        else:
            op = layout.operator(operator_id, text=text, icon=fallback_icon)
    except TypeError:
        if icon_value:
            op = layout.operator(operator_id, text=text, icon_value=icon_value)
        else:
            op = layout.operator(operator_id, text=text, icon=fallback_icon)
    for key, value in props.items():
        try:
            setattr(op, key, value)
        except Exception:
            pass
    return op


def _qr_body_type_text(rigid_body, context):
    if rigid_body.type == 'PASSIVE':
        return _qr_ui_text('Passive', 'パッシブ', context)
    return _qr_ui_text('Active', 'アクティブ', context)

class VIEW3D_MT_quick_rigid_collision_submenu(bpy.types.Menu):
    """Collision shape settings submenu"""
    bl_label = "Collision Shape"
    bl_idname = "VIEW3D_MT_quick_rigid_collision_submenu"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        
        if obj and obj.rigid_body:
            layout.prop_enum(obj.rigid_body, "collision_shape", 'BOX', icon='MESH_CUBE')
            layout.prop_enum(obj.rigid_body, "collision_shape", 'SPHERE', icon='MESH_UVSPHERE')
            layout.prop_enum(obj.rigid_body, "collision_shape", 'CAPSULE', icon='MESH_CAPSULE')
            layout.prop_enum(obj.rigid_body, "collision_shape", 'CYLINDER', icon='MESH_CYLINDER')
            layout.prop_enum(obj.rigid_body, "collision_shape", 'CONE', icon='MESH_CONE')
            layout.prop_enum(obj.rigid_body, "collision_shape", 'CONVEX_HULL', icon='MOD_MESHDEFORM')
            layout.prop_enum(obj.rigid_body, "collision_shape", 'MESH', icon='MESH_MONKEY')
            
            layout.separator()
            layout.prop(obj.rigid_body, "use_margin", text=_qr_ui_text('Use Collision Margin', '衝突マージンを使用', context))
            if obj.rigid_body.use_margin:
                layout.prop(obj.rigid_body, "collision_margin", text=_qr_ui_text('Margin', 'マージン', context))

class VIEW3D_MT_quick_rigid_main_submenu(bpy.types.Menu):
    """Main rigid body settings submenu"""
    bl_label = "Main Settings"
    bl_idname = "VIEW3D_MT_quick_rigid_main_submenu"
    
    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        
        if obj and obj.rigid_body:
            # Type indicator
            layout.label(text=_qr_ui_text("Type: %(type)s", "タイプ: %(type)s", context) % {'type': _qr_body_type_text(obj.rigid_body, context)}, icon='PHYSICS')
            
            # Animation settings
            layout.separator()
            layout.prop(obj.rigid_body, "kinematic", text=_qr_ui_text('Animated', 'アニメーション', context), icon='RENDER_ANIMATION', toggle=True)
            layout.operator("rigid_body.toggle_animated", text=_qr_ui_text('Toggle Animated State', 'アニメーション状態を切替', context), icon='ACTION')

class VIEW3D_MT_quick_rigid_physics_submenu(bpy.types.Menu):
    """Physical properties submenu"""
    bl_label = "Physical Properties"
    bl_idname = "VIEW3D_MT_quick_rigid_physics_submenu"
    
    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        
        if obj and obj.rigid_body:
            # Mass settings section
            layout.label(text=_qr_ui_text('Mass Settings:', '質量設定:', context), icon='PHYSICS')
            layout.operator("rigidbody.mass_calculate", text=_qr_ui_text('Calculate Mass', '質量を計算', context), icon='FILE_REFRESH')
            layout.prop(obj.rigid_body, "mass", text=_qr_ui_text('Mass', '質量', context), slider=True)
            
            layout.separator()
            
            # Surface properties
            layout.label(text=_qr_ui_text('Surface Properties:', '表面特性:', context), icon='MOD_PHYSICS')
            layout.prop(obj.rigid_body, "friction", text=_qr_ui_text('Friction', '摩擦', context), slider=True)
            layout.prop(obj.rigid_body, "restitution", text=_qr_ui_text('Bounciness', '反発', context), slider=True)

class VIEW3D_MT_quick_rigid_sim_submenu(bpy.types.Menu):
    """Simulation settings submenu"""
    bl_label = "Simulation Settings"
    bl_idname = "VIEW3D_MT_quick_rigid_sim_submenu"
    
    def draw(self, context):
        layout = self.layout
        
        # Gravity settings
        layout.label(text=_qr_ui_text('Gravity:', '重力:', context), icon='FORCE_FORCE')
        layout.prop(context.scene, "use_gravity", text=_qr_ui_text('Use Gravity', '重力を使用', context))
        
        if context.scene.use_gravity:
            col = layout.column(align=True)
            col.prop(context.scene, "gravity", text=_qr_ui_text('X', 'X', context), index=0)
            col.prop(context.scene, "gravity", text=_qr_ui_text('Y', 'Y', context), index=1)
            col.prop(context.scene, "gravity", text=_qr_ui_text('Z', 'Z', context), index=2)
        
        layout.separator()
        
        # Simulation settings
        if context.scene.rigidbody_world:
            layout.label(text=_qr_ui_text('Simulation:', 'シミュレーション:', context), icon='PLAY')
            layout.prop(context.scene.rigidbody_world, "time_scale", text=_qr_ui_text('Sim Speed', 'シム速度', context), slider=True)
            layout.prop(context.scene.rigidbody_world, "solver_iterations", text=_qr_ui_text('Solver Iterations', 'ソルバー反復回数', context))
            layout.prop(context.scene.rigidbody_world, "use_split_impulse", text=_qr_ui_text('Split Impulse', 'スプリットインパルス', context))

class VIEW3D_MT_quick_rigid_presets_submenu(bpy.types.Menu):
    """Presets submenu"""
    bl_label = "Presets"
    bl_idname = "VIEW3D_MT_quick_rigid_presets_submenu"
    
    def draw(self, context):
        layout = self.layout
        
        # Check if we have any presets
        has_presets = False
        if hasattr(context.scene, "rigid_body_presets") and len(context.scene.rigid_body_presets) > 0:
            has_presets = True
        
        # If no presets exist, show info message
        if not has_presets:
            layout.label(text=_qr_ui_text('No presets available', '利用可能なプリセットはありません', context))
            layout.label(text=_qr_ui_text('Click Add New Preset below', '下の「新規プリセットを追加」を押してください', context))
            layout.separator()
        else:
            # User presets
            if hasattr(context.scene, "rigid_body_presets"):
                has_user_presets = False
                
                for preset in context.scene.rigid_body_presets:
                    if not preset.name.strip():
                        continue
                    if not has_user_presets:
                        layout.separator()
                        layout.label(text=_qr_ui_text('User Presets:', 'ユーザープリセット:', context))
                        has_user_presets = True
                    
                    preset_op = layout.operator("object.apply_rigid_body_preset", text=preset.name, translate=False, icon='FILE_NEW')
                    preset_op.preset_name = preset.name
        
        layout.separator()
        layout.operator("object.add_rigid_body_preset", text=_qr_ui_text('Add New Preset', '新規プリセットを追加', context), icon='ADD')

class VIEW3D_MT_quick_rigid_bake_submenu(bpy.types.Menu):
    """Baking submenu"""
    bl_label = "Bake Options"
    bl_idname = "VIEW3D_MT_quick_rigid_bake_submenu"
    
    def draw(self, context):
        layout = self.layout
        
        if context.scene.rigidbody_world:
            # Bake options
            layout.operator("rigidbody.bake_to_keyframes", text=_qr_ui_text('Bake to Keyframes', 'キーフレームへベイク', context), icon='KEY_HLT')
            layout.operator("ptcache.bake_all", text=_qr_ui_text('Bake All Dynamics', '全ダイナミクスをベイク', context), icon='PHYSICS').bake=True
            layout.operator("ptcache.bake", text=_qr_ui_text('Calculate to Frame', '現在フレームまで計算', context), icon='PREVIEW_RANGE')
            
            cache_op = layout.operator("ptcache.bake", text=_qr_ui_text('Current Cache to Bake', '現在キャッシュをベイク化', context), icon='FILE_TICK')
            cache_op.bake = True
            
            layout.separator()
            _qr_operator_with_custom_icon(layout, 'ptcache.free_bake_all', text=_qr_ui_text('Delete All Bakes', 'すべてのベイクを削除', context), custom_icon='', fallback_icon='TRASH')

class VIEW3D_MT_quick_rigid(bpy.types.Menu):
    """Quick access to rigid body tools"""
    bl_label = "Quick Rigid"
    bl_idname = "VIEW3D_MT_quick_rigid"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_DEFAULT'
        
        obj = context.active_object
        has_rigidbody = obj and obj.rigid_body

        # Add/Remove section - keep original layout
        layout.operator("object.add_active_rigid_body", text=_qr_ui_text('Add Active Rigid Body', 'アクティブ剛体を追加', context), icon='MESH_MONKEY')
        layout.operator("object.add_passive_rigid_body", text=_qr_ui_text('Add Passive Rigid Body', 'パッシブ剛体を追加', context), icon='MESH_CUBE')
        
        if has_rigidbody:
            layout.separator()
            layout.operator("rigidbody.object_remove", text=_qr_ui_text('Remove Rigid Body', '剛体を削除', context), icon='X')
            
            layout.separator()
            
            # Type indicator
            layout.label(text=_qr_ui_text("Type: %(type)s", "タイプ: %(type)s", context) % {'type': _qr_body_type_text(obj.rigid_body, context)}, icon='PHYSICS')
            
            # Animation
            layout.prop(obj.rigid_body, "kinematic", text=_qr_ui_text('Animated', 'アニメーション', context), icon='RENDER_ANIMATION', toggle=True)
            
            layout.separator()
            
            # Collision Shape submenu
            layout.menu("VIEW3D_MT_quick_rigid_collision_submenu", text=_qr_ui_text('Collision Shape', '衝突形状', context), icon='MESH_ICOSPHERE')
            
            # Physics properties - Keep these but remove Calculate Mass
            layout.prop(obj.rigid_body, "mass", text=_qr_ui_text('Mass', '質量', context), slider=True)
            layout.prop(obj.rigid_body, "friction", text=_qr_ui_text('Friction', '摩擦', context), slider=True)
            layout.prop(obj.rigid_body, "restitution", text=_qr_ui_text('Bounciness', '反発', context), slider=True)
            
            layout.separator()
            
            # Copy/Paste
            layout.operator("rigidbody.object_settings_copy", text=_qr_ui_text('Copy Settings', '設定をコピー', context), icon='COPYDOWN')


def _safe_register_class(cls):
    return lifecycle.register_class(cls, scope='quick.menus.classes')


def _safe_unregister_class(cls):
    del cls
    lifecycle.release_scope('quick.menus.classes')

# List of classes to register
classes = [
    VIEW3D_MT_quick_rigid_collision_submenu,
    VIEW3D_MT_quick_rigid_main_submenu,
    VIEW3D_MT_quick_rigid_physics_submenu,
    VIEW3D_MT_quick_rigid_sim_submenu,
    VIEW3D_MT_quick_rigid_presets_submenu,
    VIEW3D_MT_quick_rigid_bake_submenu,
    VIEW3D_MT_quick_rigid
]

def register():
    mark = lifecycle.checkpoint()
    try:
        for cls in classes:
            lifecycle.register_class(cls, scope='quick.menus.classes')
    except Exception:
        lifecycle.rollback_to(mark)
        raise


def unregister():
    lifecycle.release_scope('quick.menus.classes')


# Manual shortcut registration helper
_QR_KEYMAP_NAME = '3D View'
_QR_MENU_OPERATOR_ID = 'wm.call_menu'
_QR_MENU_NAME = 'VIEW3D_MT_quick_rigid'


def _settings_from_context(context=None):
    scene = getattr(context, 'scene', None)
    if scene is None:
        scene = getattr(getattr(bpy, 'context', None), 'scene', None)
    return getattr(scene, 'quick_rigid_settings', None)


def _shortcut_combo_text(settings) -> str:
    parts = []
    if settings is not None and bool(getattr(settings, 'use_ctrl', False)):
        parts.append('Ctrl')
    if settings is not None and bool(getattr(settings, 'use_alt', False)):
        parts.append('Alt')
    if settings is not None and bool(getattr(settings, 'use_shift', False)):
        parts.append('Shift')
    key = str(getattr(settings, 'shortcut_key', 'U') if settings is not None else 'U' or 'U')
    parts.append(key)
    return '+'.join(parts)


def build_manual_shortcut_info(context=None) -> dict:
    settings = _settings_from_context(context)
    combo = _shortcut_combo_text(settings)
    return {
        'display_keymap_name': _qr_ui_text('3D View', '3Dビュー', context),
        'internal_keymap_name': _QR_KEYMAP_NAME,
        'operator_id': _QR_MENU_OPERATOR_ID,
        'menu_name': _QR_MENU_NAME,
        'additional_properties': 'name="VIEW3D_MT_quick_rigid"',
        'shortcut_combo': combo,
        'copy_text': '\n'.join((
            'Keymap: 3D View',
            'Operator ID: wm.call_menu',
            'Property: name="VIEW3D_MT_quick_rigid"',
            f'Shortcut: {combo}',
            'Event: PRESS',
        )),
    }


def register_keymaps(context=None):
    """Compatibility shim. Smart Cloth never edits Blender keymaps automatically."""
    return False


def unregister_keymaps():
    """Compatibility shim. Smart Cloth never edits Blender keymaps automatically."""
    return 0
