# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""One garment, two ways to move it, switchable in either order.

A skirt on a rigged character is the one garment worth simulating: it is wide, it
hangs free below the waist, and the poses that matter for it -- sitting, walking,
turning -- are the ones skinning handles worst. But a simulation is not always
what is wanted. It has to be cached before it looks right, it does not scrub
backwards, and it cannot be exported as a pose.

So the garment keeps BOTH, and neither is destroyed by using the other:

* the skin weights are never touched, so bone mode is always live and always
  exports;
* the cloth modifier is added AFTER the armature modifiers and BEFORE any
  generative one, so the simulation starts from the posed garment and then gets
  subdivided rather than simulating four times the vertices;
* the waistband is pinned through a vertex group with a soft edge, so only the
  free part swings;
* switching is a flag on the modifier, never an apply. Nothing is baked down and
  nothing has to be rebuilt to go back.

Design notes that are requirements, not preferences:

* **The profile lives in an ID custom property, not in RNA.** It has to survive
  this add-on being disabled, Simply Cloth Studio being disabled, a save and
  reload, and an append into another file. RNA properties registered by an
  add-on vanish with it; ``obj["key"]`` does not.
* **Bone mode must work with Simply Cloth Studio absent.** Nothing in the switch
  path calls an external operator. Cloth mode uses Blender's own cloth, which is
  what Simply Cloth Studio drives anyway -- its sliders write into the same
  ``ClothSettings`` -- so an installed Simply Cloth Studio can pick this modifier
  up and keep working on it.
* **Nothing here is named ``Simply*``.** Simply Cloth Studio's own cleanup
  deletes modifiers and groups by that substring.
* **No handler, no timer, no modal.** Every operation is a plain execute.
"""

from __future__ import annotations

import bpy
import hashlib
import json
import math
import uuid
from dataclasses import dataclass

PROFILE_KEY = '_smart_cloth_suite_skirt_profile_v1'
CLOTH_MODIFIER = 'SC_SkirtCloth'
PIN_GROUP = 'SC_SkirtPin'
COLLISION_MODIFIER = 'SC_SkirtCollision'
CORRECTION_MODIFIER = 'SC_SkirtOutside'
MODE_BONE = 'BONE'
MODE_CLOTH = 'CLOTH'


def read_profile(obj) -> dict:
    """The stored profile, or an empty dict. Never raises."""
    if obj is None:
        return {}
    stored = obj.get(PROFILE_KEY)
    if stored is None:
        return {}
    if isinstance(stored, str):
        # A file prepared by a script may hold the profile as a JSON string.
        try:
            parsed = json.loads(stored)
            return {str(k): v for k, v in parsed.items()} if isinstance(parsed, dict) else {}
        except ValueError:
            return {}
    try:
        return {str(k): stored[k] for k in stored.keys()}
    except Exception:
        return {}


def write_profile(obj, **fields) -> dict:
    profile = read_profile(obj)
    profile.update({str(k): v for k, v in fields.items() if v is not None})
    if PROFILE_KEY in obj.keys() and isinstance(obj.get(PROFILE_KEY), str):
        del obj[PROFILE_KEY]
    obj[PROFILE_KEY] = profile
    return profile


def profile_schema(profile: dict) -> int:
    """The profile schema as an int; a missing or non-numeric value is 0."""
    try:
        return int(profile.get('schema', 0) or 0)
    except (TypeError, ValueError):
        return 0


def clear_profile(obj) -> None:
    if obj is not None and PROFILE_KEY in obj.keys():
        del obj[PROFILE_KEY]


def _deform_bones(obj) -> set:
    """Deform bones of EVERY armature modifier on this mesh, not just one.

    A garment on an additive rig carries two armature modifiers, and the bend
    chain deforms only through the additive one. Reading the first modifier alone
    reported 12 correctly-weighted vertices as unweighted here, which is the same
    mistake this project has already had to fix twice elsewhere.
    """
    names = set()
    for modifier in getattr(obj, 'modifiers', ()):
        if modifier.type != 'ARMATURE' or modifier.object is None:
            continue
        names |= {b.name for b in modifier.object.data.bones if b.use_deform}
    return names


def _armature_of(obj):
    for modifier in getattr(obj, 'modifiers', ()):
        if modifier.type == 'ARMATURE' and modifier.object is not None:
            return modifier.object
    parent = getattr(obj, 'parent', None)
    if parent is not None and parent.type == 'ARMATURE':
        return parent
    return None


def pin_waistband(obj, band_ratio: float = 0.28, hard_ratio: float = 0.08,
                  name: str = PIN_GROUP) -> tuple[dict | None, str]:
    """Pin the top of the garment with a soft edge. ``(report, error)``.

    A hard pin line creases on the first frame: the row above it cannot move and
    the row below is free. The weight therefore falls from 1.0 to 0.0 with a
    smoothstep across the band, measured as a fraction of the garment's own
    height so it does not need tuning per character.

    The defaults are the measured ones. A band of 0.14 held only 171 vertices
    fully on this skirt and the hem fell 773mm in twelve frames while the
    waistband itself drifted 131mm; 0.28 holds the waistband and lets the free
    part swing.
    """
    if obj is None or obj.type != 'MESH':
        return None, 'Select a mesh'
    vertices = obj.data.vertices
    if not len(vertices):
        return None, '%s has no vertices' % obj.name
    matrix = obj.matrix_world
    heights = [(matrix @ v.co).z for v in vertices]
    top = max(heights)
    bottom = min(heights)
    span = top - bottom
    if span <= 1.0e-9:
        return None, '%s is flat, so it has no waistband' % obj.name
    band = max(span * float(band_ratio), 1.0e-6)
    hard = min(span * float(hard_ratio), band * 0.9)
    group = obj.vertex_groups.get(name)
    if group is None:
        group = obj.vertex_groups.new(name=name)
    else:
        group.remove(list(range(len(vertices))))
    pinned = faded = 0
    for index, height in enumerate(heights):
        depth = top - height
        if depth <= hard:
            group.add([index], 1.0, 'REPLACE')
            pinned += 1
        elif depth < band:
            share = 1.0 - (depth - hard) / (band - hard)
            group.add([index], max(0.0, min(1.0, share * share * (3.0 - 2.0 * share))),
                      'REPLACE')
            faded += 1
    return {'group': name, 'pinned': pinned, 'faded': faded,
            'span_mm': round(span * 1000.0, 2),
            'band_mm': round(band * 1000.0, 2)}, ''


def add_collider(obj, thickness: float = 0.008, damping: float = 0.1
                 ) -> tuple[dict | None, str]:
    """Let cloth collide with this mesh. Inert unless a simulation runs."""
    if obj is None or obj.type != 'MESH':
        return None, 'Select a mesh'
    # Blender allows exactly ONE Collision modifier per object, so a second
    # modifiers.new() returns None rather than raising. Reuse whatever is already
    # there, whoever named it.
    modifier = obj.modifiers.get(COLLISION_MODIFIER)
    if modifier is None:
        for existing in obj.modifiers:
            if existing.type == 'COLLISION':
                modifier = existing
                break
    if modifier is None:
        modifier = obj.modifiers.new(name=COLLISION_MODIFIER, type='COLLISION')
    if modifier is None:
        return None, ('%s would not take a collision modifier' % obj.name)
    settings = getattr(obj, 'collision', None)
    if settings is not None:
        settings.thickness_outer = max(0.001, float(thickness))
        settings.damping = float(damping)
    return {'object': obj.name, 'modifier': modifier.name}, ''


def _place_after_armature(obj, modifier) -> int:
    """Put the cloth after every armature and before any generative modifier."""
    names = [m.name for m in obj.modifiers]
    index = names.index(modifier.name)
    last_armature = -1
    first_generative = len(names)
    for position, existing in enumerate(obj.modifiers):
        if existing.name == modifier.name:
            continue
        if existing.type == 'ARMATURE':
            last_armature = max(last_armature, position)
        elif existing.type in ('SUBSURF', 'MULTIRES') and position < first_generative:
            first_generative = position
    wanted = max(last_armature + 1, 0)
    if first_generative < wanted:
        wanted = first_generative
    wanted = min(wanted, len(names) - 1)
    if wanted != index:
        obj.modifiers.move(index, wanted)
    return list(m.name for m in obj.modifiers).index(modifier.name)


def ensure_cloth(obj, pin_group: str = PIN_GROUP, quality: int = 5,
                 mass: float = 0.3, stiffness: float = 15.0,
                 bending: float = 0.5, distance: float = 0.005
                 ) -> tuple[dict | None, str]:
    """Create or update the cloth modifier and put it in the right place."""
    if obj is None or obj.type != 'MESH':
        return None, 'Select a mesh'
    modifier = obj.modifiers.get(CLOTH_MODIFIER)
    created = modifier is None
    if modifier is None:
        modifier = obj.modifiers.new(name=CLOTH_MODIFIER, type='CLOTH')
    index = _place_after_armature(obj, modifier)
    settings = modifier.settings
    settings.quality = int(quality)
    settings.mass = float(mass)
    settings.tension_stiffness = float(stiffness)
    settings.compression_stiffness = float(stiffness)
    settings.shear_stiffness = float(stiffness)
    settings.bending_stiffness = float(bending)
    if obj.vertex_groups.get(pin_group) is not None:
        settings.vertex_group_mass = pin_group
    collision = modifier.collision_settings
    collision.distance_min = max(0.001, float(distance))
    collision.use_self_collision = True
    return {'modifier': modifier.name, 'created': created, 'index': index,
            'stack': [m.name for m in obj.modifiers],
            'pin_group': settings.vertex_group_mass}, ''


def current_mode(obj) -> str:
    """Which way the garment is being driven right now."""
    profile = read_profile(obj)
    modifier_name = str(profile.get('cloth_modifier', CLOTH_MODIFIER))
    modifier = None if obj is None else obj.modifiers.get(modifier_name)
    if modifier is None:
        return MODE_BONE
    return MODE_CLOTH if modifier.show_viewport else MODE_BONE


def set_mode(obj, mode: str) -> tuple[dict | None, str]:
    """Switch the garment. ``(report, error)``.

    Bone mode never needs Simply Cloth Studio and never needs the cloth modifier
    to exist, so a garment that has never been set up still answers this.
    """
    wanted = MODE_CLOTH if str(mode).upper() == MODE_CLOTH else MODE_BONE
    if obj is None:
        return None, 'Select a mesh'
    modifier = obj.modifiers.get(CLOTH_MODIFIER)
    if modifier is None:
        if wanted == MODE_CLOTH:
            return None, ('%s has no cloth set up yet -- run Set Up Skirt Cloth '
                          'first' % obj.name)
        write_profile(obj, mode=MODE_BONE)
        return {'object': obj.name, 'mode': MODE_BONE, 'modifier': ''}, ''
    on = wanted == MODE_CLOTH
    modifier.show_viewport = on
    modifier.show_render = on
    write_profile(obj, mode=wanted)
    return {'object': obj.name, 'mode': wanted, 'modifier': modifier.name,
            'viewport': modifier.show_viewport,
            'render': modifier.show_render}, ''


def audit(obj) -> tuple[dict | None, str]:
    """Whether the two halves are actually coherent. ``(report, error)``."""
    if obj is None or obj.type != 'MESH':
        return None, 'Select a mesh'
    modifier = obj.modifiers.get(CLOTH_MODIFIER)
    group = obj.vertex_groups.get(PIN_GROUP)
    armature = _armature_of(obj)
    names = [m.name for m in obj.modifiers]
    issues = []
    weighted = 0
    if armature is None:
        issues.append('no armature modifier, so bone mode has nothing to drive it')
    else:
        deform = _deform_bones(obj)
        for vertex in obj.data.vertices:
            for entry in vertex.groups:
                if obj.vertex_groups[entry.group].name in deform and entry.weight > 0.0:
                    weighted += 1
                    break
        if weighted < len(obj.data.vertices):
            issues.append('%d of %d vertices carry no deform weight'
                          % (len(obj.data.vertices) - weighted,
                             len(obj.data.vertices)))
    if modifier is None:
        issues.append('no cloth modifier, so only bone mode is available')
    else:
        index = names.index(modifier.name)
        armatures = [i for i, m in enumerate(obj.modifiers) if m.type == 'ARMATURE']
        if armatures and index < max(armatures):
            issues.append('the cloth runs before the armature, so it simulates '
                          'the rest pose and is then dragged by the skin')
        if group is None:
            issues.append('no pin group, so the whole garment falls')
        elif modifier.settings.vertex_group_mass != PIN_GROUP:
            issues.append('the cloth is not reading the pin group')
    return {'object': obj.name, 'mode': current_mode(obj),
            'stack': names, 'armature': armature.name if armature else '',
            'weighted': weighted, 'vertices': len(obj.data.vertices),
            'pin_group': group.name if group else '',
            'profile': read_profile(obj), 'issues': issues,
            'ok': not issues}, ''


def setup(obj, colliders=(), band_ratio: float = 0.28, quality: int = 5
          ) -> tuple[dict | None, str]:
    """Everything a garment needs to be switchable, in one call."""
    if obj is None or obj.type != 'MESH':
        return None, 'Select a mesh'
    armature = _armature_of(obj)
    pin, error = pin_waistband(obj, band_ratio=band_ratio)
    if error:
        return None, error
    for collider in colliders or ():
        add_collider(collider)
    cloth, error = ensure_cloth(obj, quality=quality)
    if error:
        return None, error
    set_mode(obj, MODE_BONE)
    write_profile(obj, mode=MODE_BONE, pin_group=PIN_GROUP,
                  cloth_modifier=CLOTH_MODIFIER,
                  armature=armature.name if armature else '',
                  colliders=[c.name for c in colliders or () if c is not None])
    return {'pin': pin, 'cloth': cloth, 'profile': read_profile(obj)}, ''


# The v2 mapping path is deliberately separate from the pre-existing active
# selection commands above. It never guesses a character-specific name.
def _names(value: str) -> tuple[str, ...]:
    result = []
    for part in str(value or '').replace('\n', ',').split(','):
        name = part.strip()
        if name and name not in result:
            result.append(name)
    return tuple(result)


def _constraint_name(skirt_bone: str, leg_bone: str) -> str:
    digest = hashlib.sha256((skirt_bone + '\0' + leg_bone).encode('utf-8')).hexdigest()[:16]
    return 'SC_SkirtAvoid_' + digest


def resolve_mapping(settings, context=None) -> dict:
    garment = getattr(settings, 'skirt_garment', None)
    if garment is None:
        garment = getattr(context, 'active_object', None)
    armature = getattr(settings, 'skirt_armature', None)
    if armature is None and garment is not None:
        armature = _armature_of(garment)
    collection = getattr(settings, 'skirt_collider_collection', None)
    colliders = []
    if collection is not None:
        colliders.extend(obj for obj in collection.objects if getattr(obj, 'type', '') == 'MESH')
    body = getattr(settings, 'body_object', None)
    if body is not None and body not in colliders:
        colliders.append(body)
    return {
        'garment': garment, 'armature': armature,
        'skirt_bones': _names(getattr(settings, 'skirt_bones', '')),
        'leg_bones': _names(getattr(settings, 'skirt_leg_bones', '')),
        'colliders': tuple(obj for obj in colliders if obj is not garment),
        'clearance': float(getattr(settings, 'skirt_clearance', 0.06)),
        'route': str(getattr(settings, 'skirt_setup_route', 'OWNED')),
    }


def preview_mapping(settings, context=None) -> tuple[dict, list[str]]:
    mapping = resolve_mapping(settings, context)
    garment = mapping['garment']
    armature = mapping['armature']
    issues = []
    if garment is None or getattr(garment, 'type', '') != 'MESH':
        issues.append('Select a mesh garment')
    elif not len(getattr(getattr(garment, 'data', None), 'vertices', ())):
        issues.append('The garment has no vertices')
    if armature is None or getattr(armature, 'type', '') != 'ARMATURE':
        issues.append('Select an armature')
    elif garment is not None and not (any(mod.type == 'ARMATURE' and mod.object is armature
                                         for mod in garment.modifiers)
                                  or getattr(garment, 'parent', None) is armature):
        issues.append('The garment is not driven by the mapped armature')
    pose_bones = getattr(getattr(armature, 'pose', None), 'bones', None)
    deform_bones = _deform_bones(garment) if getattr(garment, 'type', '') == 'MESH' else set()
    for name in mapping['skirt_bones']:
        if pose_bones is None or pose_bones.get(name) is None:
            issues.append('Skirt bone is missing: ' + name)
        elif name not in deform_bones or garment.vertex_groups.get(name) is None:
            issues.append('Skirt bone has no garment deform group: ' + name)
    for name in mapping['leg_bones']:
        if pose_bones is None or pose_bones.get(name) is None:
            issues.append('Leg collision bone is missing: ' + name)
    if not mapping['skirt_bones']:
        issues.append('Map at least one skirt bone')
    if not mapping['leg_bones']:
        issues.append('Map at least one leg collision bone')
    if set(mapping['skirt_bones']) & set(mapping['leg_bones']):
        issues.append('Skirt and leg bone mappings overlap')
    if not mapping['colliders']:
        issues.append('Map a body mesh or collider collection')
    for collider in mapping['colliders']:
        if getattr(collider, 'type', '') != 'MESH':
            issues.append('Collider is not a mesh: ' + collider.name)
    if not 0.005 <= mapping['clearance'] <= 0.5:
        issues.append('Legacy bone distance is outside the supported range')
    if mapping['route'] not in ('OWNED', 'SIMPLY'):
        issues.append('Unsupported cloth setup route')
    elif mapping['route'] == 'SIMPLY':
        from . import integration
        if not integration.operator_available('object.create_cloth'):
            issues.append('Simply Cloth Studio public Create Cloth operator is unavailable')
    return mapping, issues


def mapping_summary(mapping: dict, issues=()) -> dict:
    return {
        'garment': getattr(mapping['garment'], 'name', ''),
        'armature': getattr(mapping['armature'], 'name', ''),
        'skirt_bones': list(mapping['skirt_bones']),
        'leg_bones': list(mapping['leg_bones']),
        'colliders': [obj.name for obj in mapping['colliders']],
        'clearance': mapping['clearance'], 'route': mapping['route'],
        'issues': list(issues), 'ok': not issues,
    }


def _profile_matches(mapping: dict, profile: dict) -> bool:
    if profile_schema(profile) not in (2, 3):
        return False
    return (str(profile.get('armature', '')) == mapping['armature'].name
            and tuple(profile.get('skirt_bones', ())) == mapping['skirt_bones']
            and tuple(profile.get('leg_bones', ())) == mapping['leg_bones']
            and tuple(profile.get('colliders', ())) == tuple(obj.name for obj in mapping['colliders']))


def _mapped_constraints(mapping: dict):
    armature = mapping['armature']
    for skirt_name in mapping['skirt_bones']:
        if skirt_name in shared_deform_bones(mapping):
            continue
        bone = armature.pose.bones.get(skirt_name)
        for leg_name in mapping['leg_bones']:
            yield bone, leg_name, _constraint_name(skirt_name, leg_name)


def shared_deform_bones(mapping: dict) -> tuple[str, ...]:
    """A constraint on these bones moves both meshes, not just the garment."""
    armature = mapping['armature']
    if armature is None:
        return ()
    result = []
    for name in mapping['skirt_bones']:
        for body in mapping['colliders']:
            driven = (getattr(body, 'parent', None) is armature or any(
                mod.type == 'ARMATURE' and mod.object is armature
                for mod in getattr(body, 'modifiers', ())))
            if driven and body.vertex_groups.get(name) is not None:
                result.append(name)
                break
    return tuple(result)


def _modifier_snapshot(garment, exclude=()) -> str:
    rows = [{'name': mod.name, 'type': mod.type,
             'show_viewport': bool(mod.show_viewport),
             'show_render': bool(mod.show_render)}
            for mod in garment.modifiers if mod.name not in exclude]
    return json.dumps(rows, ensure_ascii=False, separators=(',', ':'))


def _original_rows(profile: dict) -> list[dict] | None:
    try:
        rows = json.loads(str(profile.get('original_stack_json', '[]')))
        if not isinstance(rows, list) or any(
                not isinstance(row, dict)
                or not {'name', 'type', 'show_viewport', 'show_render'} <= set(row)
                for row in rows):
            return None
        return rows
    except (TypeError, ValueError):
        return None


def _restore_original_stack(garment, profile: dict) -> str:
    rows = _original_rows(profile)
    if 'original_stack_json' not in profile or rows is None:
        return 'Original modifier stack snapshot is missing'
    for row in rows:
        mod = garment.modifiers.get(row['name'])
        if mod is None or mod.type != row['type']:
            return 'Original modifier is missing or changed: ' + row['name']
    # Owned supplemental modifiers remain, but every original modifier returns
    # to its original index, order and visibility. No user modifier is deleted.
    for index, row in enumerate(rows):
        mod = garment.modifiers.get(row['name'])
        current = list(garment.modifiers).index(mod)
        if current != index:
            garment.modifiers.move(current, index)
        mod.show_viewport = row['show_viewport']
        mod.show_render = row['show_render']
    return ''


def _old_shared_constraints(mapping: dict, profile: dict) -> tuple[list, str]:
    """Migrate only provably owned 2.9.1 constraints; foreign rows are untouched."""
    if profile_schema(profile) != 2:
        return [], ''
    owned = set(profile.get('avoid_constraints', ()))
    found = []
    for skirt_name in shared_deform_bones(mapping):
        bone = mapping['armature'].pose.bones.get(skirt_name)
        for leg_name in mapping['leg_bones']:
            name = _constraint_name(skirt_name, leg_name)
            constraint = bone.constraints.get(name)
            if constraint is None:
                continue
            if (name not in owned or constraint.type != 'LIMIT_DISTANCE'
                    or constraint.target is not mapping['armature']
                    or constraint.subtarget != leg_name):
                return [], 'Shared-bone constraint cannot be safely migrated: ' + name
            found.append((bone, constraint))
    return found, ''


def _check_resource_conflicts(mapping: dict, profile: dict) -> list[str]:
    garment = mapping['garment']
    issues = []
    owns_existing = _profile_matches(mapping, profile)
    existing_cloth = [mod for mod in garment.modifiers if mod.type == 'CLOTH']
    if existing_cloth and not (owns_existing and len(existing_cloth) == 1
                               and existing_cloth[0].name == profile.get('cloth_modifier')):
        issues.append('An existing cloth modifier would be duplicated')
    cloth = garment.modifiers.get(CLOTH_MODIFIER)
    if cloth is not None and (cloth.type != 'CLOTH' or not owns_existing):
        issues.append('A cloth modifier occupies the Smart Cloth skirt name')
    group = garment.vertex_groups.get(PIN_GROUP)
    if group is not None and not owns_existing:
        issues.append('A vertex group occupies the Smart Cloth skirt pin name')
    for bone, leg_name, name in _mapped_constraints(mapping):
        existing = bone.constraints.get(name)
        if existing is not None and (not owns_existing or existing.type != 'LIMIT_DISTANCE'
                                     or existing.target is not mapping['armature']
                                     or existing.subtarget != leg_name):
            issues.append('A constraint occupies the skirt avoidance name: ' + name)
    return issues


def _external_cloth(mapping: dict, context) -> tuple[object | None, str]:
    from . import integration
    if not integration.operator_available('object.create_cloth'):
        return None, 'Simply Cloth Studio public Create Cloth operator is unavailable'
    garment = mapping['garment']
    before = {mod.name for mod in garment.modifiers}
    # Selection remains unchanged: the temporary context affects only this call.
    try:
        with bpy.context.temp_override(object=garment, active_object=garment,
                                       selected_objects=[garment], selected_editable_objects=[garment]):
            result = integration.call_external_operator('object.create_cloth', context,
                mode='CREATECLOTH', modifiers_handling='DO_NOTHING')
    except Exception as exc:
        return None, 'Simply Cloth Studio Create Cloth failed: ' + str(exc)
    if 'FINISHED' not in result:
        return None, 'Simply Cloth Studio Create Cloth did not finish'
    created = [mod for mod in garment.modifiers if mod.name not in before and mod.type == 'CLOTH']
    if len(created) != 1:
        return None, 'Simply Cloth Studio did not create exactly one cloth modifier on the mapped garment'
    return created[0], ''


def _ensure_mapping_collision(obj) -> tuple[str, bool]:
    existing = next((mod for mod in obj.modifiers if mod.type == 'COLLISION'), None)
    if existing is not None:
        return existing.name, False
    mod = obj.modifiers.new(name=COLLISION_MODIFIER, type='COLLISION')
    if mod is None:
        raise RuntimeError('Could not add collision to ' + obj.name)
    return mod.name, True


def apply_mapping(settings, context=None, *, band_ratio: float = 0.28,
                  quality: int = 5) -> tuple[dict | None, str]:
    mapping, issues = preview_mapping(settings, context)
    if issues:
        return None, '; '.join(issues)
    garment = mapping['garment']
    profile = read_profile(garment)
    issues = _check_resource_conflicts(mapping, profile)
    if issues:
        return None, '; '.join(issues)
    old_shared, error = _old_shared_constraints(mapping, profile)
    if error:
        return None, error
    shared = shared_deform_bones(mapping)
    prior_schema = profile_schema(profile)
    if prior_schema == 3 and _profile_matches(mapping, profile):
        original_stack_json = str(profile.get('original_stack_json', ''))
        migration = str(profile.get('migration', 'native_292'))
    else:
        excluded = (str(profile.get('cloth_modifier', '')),) if prior_schema == 2 else ()
        original_stack_json = _modifier_snapshot(garment, excluded)
        migration = 'post_291_inferred' if prior_schema == 2 else 'native_292'
    before_external = {mod.name for mod in garment.modifiers}
    existing_external = garment.modifiers.get(str(profile.get('cloth_modifier', '')))
    if mapping['route'] == 'SIMPLY' and not (existing_external is not None and _profile_matches(mapping, profile)):
        if any(mod.type == 'CLOTH' for mod in garment.modifiers):
            return None, 'A cloth modifier already exists; external setup would duplicate it'
        external, error = _external_cloth(mapping, context)
        if error:
            return None, error
        external_name = external.name
    else:
        external_name = str(profile.get('cloth_modifier', CLOTH_MODIFIER))
    external_added_json = (str(profile.get('external_added_json', '[]'))
                           if prior_schema == 3 else _modifier_snapshot(
                               garment, before_external))
    # All referenced objects and bones were checked before the first owned edit.
    created_collisions = []
    created_constraints = []
    created_pin = garment.vertex_groups.get(PIN_GROUP) is None
    created_cloth = garment.modifiers.get(CLOTH_MODIFIER) is None and mapping['route'] == 'OWNED'
    try:
        pin, error = pin_waistband(garment, band_ratio=band_ratio)
        if error:
            return None, error
        if mapping['route'] == 'SIMPLY':
            cloth = garment.modifiers.get(external_name)
            if cloth is None or cloth.type != 'CLOTH':
                return None, 'External cloth result is unavailable'
            _place_after_armature(garment, cloth)
            cloth.settings.vertex_group_mass = PIN_GROUP
            cloth_result = {'modifier': cloth.name, 'created': False,
                            'index': list(garment.modifiers).index(cloth)}
        else:
            cloth_result, error = ensure_cloth(garment, quality=quality)
            if error:
                return None, error
            cloth = garment.modifiers.get(cloth_result['modifier'])
        collision_rows = []
        for collider in mapping['colliders']:
            modifier_name, created = _ensure_mapping_collision(collider)
            if created:
                created_collisions.append((collider, modifier_name))
            collision_rows.append({'object': collider.name, 'modifier': modifier_name, 'created': created})
        constraint_rows = []
        for bone, leg_name, name in _mapped_constraints(mapping):
            constraint = bone.constraints.get(name)
            if constraint is None:
                constraint = bone.constraints.new('LIMIT_DISTANCE')
                constraint.name = name
                created_constraints.append((bone, name))
            constraint.target = mapping['armature']
            constraint.subtarget = leg_name
            constraint.distance = mapping['clearance']
            constraint.limit_mode = 'LIMITDIST_OUTSIDE'
            constraint.owner_space = 'WORLD'
            constraint.target_space = 'WORLD'
            constraint_rows.append({'skirt_bone': bone.name, 'leg_bone': leg_name,
                                    'constraint': constraint.name})
        for bone, constraint in old_shared:
            bone.constraints.remove(constraint)
        write_profile(garment, schema=3, armature=mapping['armature'].name,
            skirt_bones=list(mapping['skirt_bones']), leg_bones=list(mapping['leg_bones']),
            colliders=[obj.name for obj in mapping['colliders']],
            clearance=mapping['clearance'], route=mapping['route'],
            cloth_modifier=cloth.name, pin_group=PIN_GROUP,
            collision_modifiers=[row['modifier'] for row in collision_rows],
            avoid_constraints=[row['constraint'] for row in constraint_rows],
            shared_bones=list(shared), original_stack_json=original_stack_json,
            external_added_json=external_added_json, migration=migration,
            correction_enabled=bool(profile.get('correction_enabled', False)),
            mode=MODE_BONE)
        switched, error = switch_mapping_mode(garment, MODE_BONE, mapping['armature'])
        if error:
            return None, error
        return {'mapping': mapping_summary(mapping), 'pin': pin, 'cloth': cloth_result,
                'collisions': collision_rows, 'avoidance': constraint_rows,
                'mode': switched['mode'], 'shared_bones_rejected': list(shared),
                'migration': migration,
                'interop': {'route': mapping['route'],
                            'operator': 'object.create_cloth' if mapping['route'] == 'SIMPLY' else '',
                            'result_modifier': cloth.name,
                            'fallback': mapping['route'] == 'OWNED'}}, ''
    except Exception as exc:
        for bone, name in reversed(created_constraints):
            constraint = bone.constraints.get(name)
            if constraint is not None:
                bone.constraints.remove(constraint)
        for collider, name in reversed(created_collisions):
            modifier = collider.modifiers.get(name)
            if modifier is not None:
                collider.modifiers.remove(modifier)
        if created_cloth:
            modifier = garment.modifiers.get(CLOTH_MODIFIER)
            if modifier is not None:
                garment.modifiers.remove(modifier)
        if created_pin:
            group = garment.vertex_groups.get(PIN_GROUP)
            if group is not None:
                garment.vertex_groups.remove(group)
        return None, 'Skirt setup failed; use Undo before retrying: ' + str(exc)


def switch_mapping_mode(garment, mode: str, armature=None) -> tuple[dict | None, str]:
    if garment is None or garment.type != 'MESH':
        return None, 'Select a mapped mesh garment'
    wanted = str(mode or '').upper()
    if wanted not in (MODE_BONE, MODE_CLOTH):
        return None, 'Unsupported skirt mode'
    profile = read_profile(garment)
    if profile_schema(profile) != 3:
        return None, 'Reapply the skirt mapping to migrate the older profile first'
    cloth = garment.modifiers.get(str(profile.get('cloth_modifier', '')))
    if cloth is None or cloth.type != 'CLOTH':
        return None, 'Mapped cloth modifier is missing'
    armature = armature or _armature_of(garment)
    if armature is None or armature.name != profile.get('armature'):
        return None, 'Mapped armature is unavailable'
    constraints = []
    for skirt_name in profile.get('skirt_bones', ()):
        bone = armature.pose.bones.get(str(skirt_name))
        if bone is None:
            return None, 'Mapped skirt bone is missing: ' + str(skirt_name)
        if skirt_name in profile.get('shared_bones', ()):
            continue
        for leg_name in profile.get('leg_bones', ()):
            name = _constraint_name(str(skirt_name), str(leg_name))
            constraint = bone.constraints.get(name)
            if (constraint is None or constraint.type != 'LIMIT_DISTANCE'
                    or constraint.target is not armature or constraint.subtarget != leg_name):
                return None, 'Mapped leg avoidance constraint is missing: ' + name
            constraints.append(constraint)
    if wanted == MODE_CLOTH and not cloth.show_viewport:
        cache = getattr(cloth, 'point_cache', None)
        if bool(getattr(cache, 'is_baked', False)):
            return None, 'Cloth cache is baked; free or rebake it before switching to cloth'
    correction = garment.modifiers.get(CORRECTION_MODIFIER)
    if correction is not None and (correction.type != 'SHRINKWRAP'
                                   or str(profile.get('correction_modifier', '')) != CORRECTION_MODIFIER):
        return None, 'Outside correction name is occupied by an unowned modifier'
    try:
        external_rows = json.loads(str(profile.get('external_added_json', '[]')))
        if not isinstance(external_rows, list) or any(
                not isinstance(row, dict)
                or not {'name', 'type', 'show_viewport', 'show_render'} <= set(row)
                for row in external_rows):
            return None, 'External modifier snapshot is invalid'
    except (TypeError, ValueError):
        return None, 'External modifier snapshot is invalid'
    if wanted == MODE_BONE:
        error = _restore_original_stack(garment, profile)
        if error:
            return None, error
    else:
        _place_after_armature(garment, cloth)
    on = wanted == MODE_CLOTH
    for constraint in constraints:
        constraint.mute = on
    cloth.show_viewport = on
    cloth.show_render = on
    if correction is not None:
        correction.show_viewport = correction.show_render = (
            not on and bool(profile.get('correction_enabled', False)))
    for row in external_rows:
        modifier = garment.modifiers.get(row['name'])
        if modifier is not None and modifier.type == row['type']:
            modifier.show_viewport = bool(row['show_viewport']) if on else False
            modifier.show_render = bool(row['show_render']) if on else False
    write_profile(garment, mode=wanted)
    return {'object': garment.name, 'mode': wanted, 'cloth': cloth.name,
            'avoidance_count': len(constraints), 'cloth_viewport': on,
            'bone_avoidance_enabled': not on and bool(constraints),
            'shared_bones_rejected': list(profile.get('shared_bones', ())),
            'outside_correction_enabled': bool(correction and correction.show_viewport)}, ''


def set_outside_correction(settings, context=None, enabled=None) -> tuple[dict | None, str]:
    """Optional garment-only correction; never mutates body, bones or weights."""
    mapping, issues = preview_mapping(settings, context)
    if issues:
        return None, '; '.join(issues)
    garment = mapping['garment']
    profile = read_profile(garment)
    if profile_schema(profile) != 3 or not _profile_matches(mapping, profile):
        return None, 'Reapply the skirt mapping to migrate the older profile first'
    target = getattr(settings, 'body_object', None)
    if target not in mapping['colliders']:
        target = mapping['colliders'][0] if mapping['colliders'] else None
    if target is None or target is garment or target.type != 'MESH':
        return None, 'Map a separate mesh body for outside correction'
    offset = float(getattr(settings, 'skirt_outside_offset', 0.003))
    if not 0.0 <= offset <= 0.05:
        return None, 'Outside correction offset is outside the supported range'
    existing = garment.modifiers.get(CORRECTION_MODIFIER)
    if existing is not None and (existing.type != 'SHRINKWRAP'
                                 or profile.get('correction_modifier') != CORRECTION_MODIFIER):
        return None, 'Outside correction name is occupied by an unowned modifier'
    wanted = not bool(profile.get('correction_enabled', False)) if enabled is None else bool(enabled)
    if existing is None and wanted:
        existing = garment.modifiers.new(name=CORRECTION_MODIFIER, type='SHRINKWRAP')
        if existing is None:
            return None, 'Could not create garment-only outside correction'
    if existing is not None:
        existing.target = target
        existing.wrap_method = 'NEAREST_SURFACEPOINT'
        existing.wrap_mode = 'OUTSIDE'
        existing.offset = offset
        visible = wanted and profile.get('mode') == MODE_BONE
        existing.show_viewport = visible
        existing.show_render = visible
    write_profile(garment, correction_modifier=CORRECTION_MODIFIER if existing else '',
                  correction_target=target.name, correction_offset=offset,
                  correction_enabled=wanted)
    return {'garment': garment.name, 'target': target.name, 'enabled': wanted,
            'method': 'NEAREST_SURFACEPOINT', 'mode': 'OUTSIDE',
            'offset': offset, 'warning': 'Residual surface intersections may remain'}, ''


def validate_mapping(settings, context=None) -> tuple[dict | None, str]:
    mapping, issues = preview_mapping(settings, context)
    summary = mapping_summary(mapping, issues)
    garment = mapping['garment']
    if garment is None or getattr(garment, 'type', '') != 'MESH':
        return summary, ''
    profile = read_profile(garment)
    warnings = []
    if profile_schema(profile) == 2:
        issues.append('Reapply the skirt mapping to migrate the older profile first')
    if profile.get('migration') == 'post_291_inferred':
        warnings.append('Original stack was inferred from an older setup; verify the earlier appearance manually')
    if not issues and not _profile_matches(mapping, profile):
        issues.append('Saved mapping differs from the selected mapping')
    cloth = garment.modifiers.get(str(profile.get('cloth_modifier', '')))
    if cloth is None or cloth.type != 'CLOTH':
        issues.append('Mapped cloth modifier is missing')
    elif len([mod for mod in garment.modifiers if mod.type == 'CLOTH']) != 1:
        issues.append('The garment has duplicate cloth modifiers')
    elif cloth.settings.vertex_group_mass != str(profile.get('pin_group', PIN_GROUP) or PIN_GROUP):
        issues.append('Cloth does not use the mapped waistband pin')
    elif bool(cloth.show_viewport) != (profile.get('mode') == MODE_CLOTH):
        issues.append('Cloth viewport state disagrees with saved mode')
    if cloth is not None and cloth.type == 'CLOTH':
        stack = list(garment.modifiers)
        if any(mod.type == 'ARMATURE' and stack.index(mod) > stack.index(cloth)
               for mod in stack):
            issues.append('Cloth modifier runs before an armature modifier')
    if garment.vertex_groups.get(str(profile.get('pin_group', PIN_GROUP) or PIN_GROUP)) is None:
        issues.append('Mapped waistband pin group is missing')
    if mapping['armature'] is not None and getattr(mapping['armature'], 'type', '') == 'ARMATURE':
        observed_distance = []
        for bone, leg_name, name in _mapped_constraints(mapping):
            constraint = bone.constraints.get(name) if bone is not None else None
            if constraint is None or constraint.type != 'LIMIT_DISTANCE':
                issues.append('Leg collision avoidance is missing: ' + name)
            elif (constraint.target is not mapping['armature'] or constraint.subtarget != leg_name
                  or bool(constraint.mute) != (profile.get('mode') == MODE_CLOTH)):
                issues.append('Leg collision avoidance state is invalid: ' + name)
            if profile.get('mode') == MODE_BONE and bone is not None:
                leg = mapping['armature'].pose.bones.get(leg_name)
                if leg is not None:
                    distance = ((mapping['armature'].matrix_world @ bone.head)
                                - (mapping['armature'].matrix_world @ leg.head)).length
                    observed_distance.append({'skirt_bone': bone.name, 'leg_bone': leg_name,
                                               'distance': round(float(distance), 6)})
        summary['observed_bone_head_distance_configuration_only'] = observed_distance
        for name in shared_deform_bones(mapping):
            bone = mapping['armature'].pose.bones.get(name)
            for leg_name in mapping['leg_bones']:
                if bone.constraints.get(_constraint_name(name, leg_name)) is not None:
                    issues.append('Shared deformation bone has an avoidance constraint: ' + name)
        if shared_deform_bones(mapping):
            warnings.append('Shared deformation bones cannot provide garment-only avoidance')
    for collider in mapping['colliders']:
        if not any(mod.type == 'COLLISION' for mod in collider.modifiers):
            issues.append('Collider has no Collision modifier: ' + collider.name)
    correction = garment.modifiers.get(CORRECTION_MODIFIER)
    if correction is not None:
        target = next((obj for obj in mapping['colliders']
                       if obj.name == profile.get('correction_target')), None)
        if (correction.type != 'SHRINKWRAP' or correction.target is not target
                or correction.wrap_method != 'NEAREST_SURFACEPOINT'
                or correction.wrap_mode != 'OUTSIDE'
                or abs(correction.offset - float(profile.get('correction_offset', 0.003))) > 1e-7):
            issues.append('Outside correction configuration is inconsistent')
        if bool(correction.show_viewport) != (bool(profile.get('correction_enabled', False))
                                              and profile.get('mode') == MODE_BONE):
            issues.append('Outside correction visibility is inconsistent')
    elif profile.get('correction_enabled', False):
        issues.append('Outside correction modifier is missing')
    if profile.get('correction_enabled', False):
        warnings.append('Residual surface intersections may remain; inspect deformed geometry')
    if profile.get('mode') == MODE_BONE and profile_schema(profile) == 3:
        rows = _original_rows(profile)
        if rows is None:
            issues.append('Original modifier stack snapshot is missing')
            rows = []
        for index, row in enumerate(rows):
            mod = garment.modifiers.get(row['name'])
            if (mod is None or mod.type != row['type']
                    or list(garment.modifiers).index(mod) != index
                    or bool(mod.show_viewport) != row['show_viewport']
                    or bool(mod.show_render) != row['show_render']):
                issues.append('Original modifier stack or visibility is not restored')
                break
    summary['issues'] = issues
    summary['warnings'] = warnings
    summary['ok'] = not issues
    summary['mode'] = str(profile.get('mode', ''))
    summary['cloth_modifier'] = str(profile.get('cloth_modifier', ''))
    return summary, ''


def save_mapping(settings, context=None) -> tuple[dict | None, str]:
    report, error = validate_mapping(settings, context)
    if error or not report['ok']:
        return None, error or '; '.join(report['issues'])
    # The object ID property is serialized by Blender with the scene. Saving a
    # profile never writes an external file or touches a different garment.
    garment = resolve_mapping(settings, context)['garment']
    write_profile(garment, saved=True)
    return report, ''


# 2.9.3 fabric-component workflow. The source garment and its mesh datablock are
# never edited. Both split objects are owned copies; unsupported source states
# stop before the first object is linked.
COMPONENT_PROFILE_KEY = '_smart_cloth_suite_component_v1'
COMPONENT_OWNER_KEY = '_smart_cloth_suite_component_owner_v1'
COMPONENT_ACTION_OWNER_KEY = '_smart_cloth_suite_component_action_owner_v1'
COMPONENT_BACKUP_ID_KEY = '_smart_cloth_suite_component_backup_id_v1'


def _action_identity(action) -> int:
    pointer = getattr(action, 'as_pointer', None)
    return int(pointer()) if callable(pointer) else id(action)


def _helper_action(helper):
    animation = getattr(helper, 'animation_data', None)
    return getattr(animation, 'action', None)


def _isolate_component_action(garment, helper, token: str):
    """Copy the active Action before SCS can insert keys on this helper.

    Preserve the exact source slot identity, not merely a compatible OBJECT
    slot: layered Actions can contain several compatible slots with different
    motion. NLA references remain read-only and untouched.
    """
    source_anim = getattr(garment, 'animation_data', None)
    source_action = getattr(source_anim, 'action', None)
    if source_action is None:
        return None
    helper_anim = getattr(helper, 'animation_data', None)
    if helper_anim is None:
        raise RuntimeError('Copied fabric helper has no animation data')
    source_slot = getattr(source_anim, 'action_slot', None)
    slot_key = ((str(source_slot.identifier), str(source_slot.target_id_type))
                if source_slot is not None else None)
    isolated = source_action.copy()
    isolated[COMPONENT_ACTION_OWNER_KEY] = token
    try:
        helper_anim.action = isolated
        if slot_key is not None:
            matches = [slot for slot in isolated.slots
                       if (str(slot.identifier), str(slot.target_id_type)) == slot_key]
            if len(matches) != 1:
                raise RuntimeError('Copied Action lacks the exact source slot')
            helper_anim.action_slot = matches[0]
            selected = getattr(helper_anim, 'action_slot', None)
            if selected is None or (str(selected.identifier), str(selected.target_id_type)) != slot_key:
                raise RuntimeError('Fabric helper did not retain the source Action slot')
        else:
            # A source with no assigned slot has no direct slot-driven motion.
            # Never guess among several compatible slots on its Action copy.
            helper_anim.action_slot = None
        if (_action_identity(helper_anim.action) != _action_identity(isolated)
                or _action_identity(source_anim.action) != _action_identity(source_action)):
            raise RuntimeError('Action isolation changed the source or helper binding')
        return isolated
    except Exception:
        helper_anim.action = None
        if isolated.users == 0 and isolated.get(COMPONENT_ACTION_OWNER_KEY) == token:
            bpy.data.actions.remove(isolated)
        raise


def _claim_new_helper_action(helper, token: str, before_ids: set[int], source_action):
    action = _helper_action(helper)
    if action is None:
        return None
    if source_action is not None and _action_identity(action) == _action_identity(source_action):
        raise RuntimeError('External cloth rebound the source Action')
    if _action_identity(action) not in before_ids:
        owner = action.get(COMPONENT_ACTION_OWNER_KEY)
        if owner not in (None, token):
            raise RuntimeError('External cloth Action has a foreign owner')
        action[COMPONENT_ACTION_OWNER_KEY] = token
    elif action.get(COMPONENT_ACTION_OWNER_KEY) != token:
        raise RuntimeError('External cloth rebound an unrelated existing Action')
    return action


def _remove_zero_user_owned_actions(token: str) -> int:
    removed = 0
    actions = getattr(bpy.data, 'actions', ())
    for action in tuple(actions):
        if action.get(COMPONENT_ACTION_OWNER_KEY) == token and action.users == 0:
            bpy.data.actions.remove(action)
            removed += 1
    return removed


def _object_identity(obj) -> int:
    pointer = getattr(obj, 'as_pointer', None)
    return int(pointer()) if callable(pointer) else id(obj)


def _claim_external_backup(fabric, token: str, before_ids: set[int],
                           before_mesh_ids: set[int]):
    """Claim only the unique mesh newly created by this SCS invocation.

    The name is a corroborating SCS signature, never the lookup key for
    ownership: pre-existing same-name objects are excluded by pointer delta.
    """
    delta = [obj for obj in bpy.data.objects if _object_identity(obj) not in before_ids]
    prefix = fabric.name + '_SC_Backup'
    matches = [obj for obj in delta if getattr(obj, 'type', None) == 'MESH'
               and (obj.name == prefix or
                    (obj.name.startswith(prefix + '.') and
                     obj.name[len(prefix) + 1:].isdigit()))]
    if len(delta) != 1 or len(matches) != 1:
        raise RuntimeError('External cloth backup object delta is ambiguous')
    backup = matches[0]
    if backup.get(COMPONENT_OWNER_KEY) not in (None, token):
        raise RuntimeError('External cloth backup has a foreign owner')
    backup_id = uuid.uuid4().hex
    backup[COMPONENT_OWNER_KEY] = token
    backup[COMPONENT_BACKUP_ID_KEY] = backup_id
    data = getattr(backup, 'data', None)
    if (data is not None and _object_identity(data) not in before_mesh_ids
            and data.get(COMPONENT_OWNER_KEY) is None):
        data[COMPONENT_OWNER_KEY] = token
    return backup, backup_id


def _owned_backup(profile):
    name, token, backup_id = (profile.get('external_backup'), profile.get('token'),
                              profile.get('external_backup_id'))
    if not all((name, token, backup_id)):
        return None
    backup = bpy.data.objects.get(name)
    if (backup is None or backup.get(COMPONENT_OWNER_KEY) != token
            or backup.get(COMPONENT_BACKUP_ID_KEY) != backup_id):
        return None
    return backup


def _remove_owned_backup(backup, token: str, backup_id: str) -> bool:
    if (backup is None or backup.get(COMPONENT_OWNER_KEY) != token
            or backup.get(COMPONENT_BACKUP_ID_KEY) != backup_id):
        return False
    data = getattr(backup, 'data', None)
    bpy.data.objects.remove(backup, do_unlink=True)
    if data is not None and data.users == 0 and data.get(COMPONENT_OWNER_KEY) == token:
        bpy.data.meshes.remove(data)
    return True
COMPONENT_HOOK_MODIFIER = 'SC_ComponentSupport'


def _component_profile(garment) -> dict:
    if garment is None:
        return {}
    try:
        value = garment.get(COMPONENT_PROFILE_KEY, '')
        result = json.loads(value) if value else {}
        return result if isinstance(result, dict) else {}
    except (TypeError, ValueError):
        return {}


def _weight(obj, group, index: int) -> float:
    if group is None:
        return 0.0
    return max((float(item.weight) for item in obj.data.vertices[index].groups
                if item.group == group.index), default=0.0)


def plan_fabric_component(settings, context=None) -> tuple[dict | None, list[str]]:
    """Read-only, topology-independent selection and ownership preflight."""
    garment = getattr(settings, 'skirt_garment', None)
    if garment is None:
        garment = getattr(context, 'active_object', None)
    issues = []
    if garment is None or getattr(garment, 'type', '') != 'MESH':
        return None, ['Select a mesh garment']
    if _component_profile(garment):
        issues.append('A fabric component setup already exists; reuse or remove its owned helpers first')
    mesh = garment.data
    if getattr(mesh, 'shape_keys', None) is not None:
        issues.append('Shape keys are unsupported for component splitting; source was not changed')
    unsupported = [mod.name for mod in garment.modifiers
                   if mod.type not in ('ARMATURE', 'SUBSURF')]
    if any(mod.type == 'CLOTH' for mod in garment.modifiers):
        issues.append('Existing garment Cloth is not migrated automatically')
    elif unsupported:
        issues.append('Unsupported original modifiers: ' + ', '.join(name.replace(';', ',') for name in unsupported))
    armature = getattr(settings, 'component_support_armature', None)
    bone_name = str(getattr(settings, 'component_support_bone', '') or '').strip()
    if armature is None or getattr(armature, 'type', '') != 'ARMATURE':
        issues.append('Select a support armature')
    elif not any(mod.type == 'ARMATURE' and mod.object is armature
                 for mod in garment.modifiers):
        issues.append('The support armature does not drive the garment')
    if not bone_name or armature is None or getattr(getattr(armature, 'pose', None), 'bones', None) is None \
            or armature.pose.bones.get(bone_name) is None:
        issues.append('Select an existing support bone')
    source = str(getattr(settings, 'component_source', 'MATERIAL'))
    slot = int(getattr(settings, 'component_material_slot', 0))
    group_name = str(getattr(settings, 'component_fabric_group', '') or '').strip()
    threshold = float(getattr(settings, 'component_group_threshold', 0.5))
    group = garment.vertex_groups.get(group_name) if source == 'VERTEX_GROUP' else None
    if source == 'MATERIAL':
        if slot < 0 or slot >= len(mesh.materials) or mesh.materials[slot] is None:
            issues.append('Select an existing fabric material slot')
    elif source == 'VERTEX_GROUP':
        if group is None or not 0.001 <= threshold <= 1.0:
            issues.append('Select an existing fabric vertex group and valid threshold')
    else:
        issues.append('Unsupported fabric selection method')
    polygons = tuple(getattr(mesh, 'polygons', ()))
    if not polygons:
        issues.append('Garment has no faces')
    fabric_faces = []
    if not issues:
        for face in polygons:
            if source == 'MATERIAL':
                chosen = face.material_index == slot
            else:
                chosen = all(_weight(garment, group, i) >= threshold
                             for i in face.vertices)
            if chosen:
                fabric_faces.append(face.index)
    fabric_vertices = sorted({int(i) for face in polygons if face.index in fabric_faces
                              for i in face.vertices})
    trim_faces = sorted(face.index for face in polygons if face.index not in fabric_faces)
    if not fabric_faces or not trim_faces:
        issues.append('Selection must leave both fabric and retained trim faces')
    support_group = garment.vertex_groups.get(bone_name)
    if support_group is None or not any(_weight(garment, support_group, i) > 0
                                        for i in fabric_vertices):
        issues.append('Selected fabric has no weights for the support bone')
    pin_name = str(getattr(settings, 'component_pin_group', '') or '').strip()
    pin_group = garment.vertex_groups.get(pin_name) if pin_name else None
    if pin_name and (pin_group is None or not any(_weight(garment, pin_group, i) > 0
                                                   for i in fabric_vertices)):
        issues.append('Selected fabric has no weights in the chosen pin group')
    pin_band = float(getattr(settings, 'component_pin_band', 0.18))
    if not pin_name and not 0.01 <= pin_band <= 0.6:
        issues.append('Pin height fraction is outside the supported range')
    if pin_name:
        pin_candidates = sum(_weight(garment, pin_group, i) > 0 for i in fabric_vertices)
    elif fabric_vertices:
        heights = [(garment.matrix_world @ mesh.vertices[i].co).z for i in fabric_vertices]
        span = max(heights) - min(heights)
        pin_candidates = sum(value >= max(heights) - span * pin_band for value in heights)
        if span <= 1.0e-9:
            issues.append('Selected fabric has no usable height for a top pin')
    else:
        pin_candidates = 0
    total_mass = float(getattr(settings, 'component_total_mass_kg', 0.5))
    if total_mass <= 0 or not 0 <= float(getattr(settings, 'component_tension', 15.0)) <= 1000 \
            or not 0 <= float(getattr(settings, 'component_bending', 0.5)) <= 1000:
        issues.append('Fabric mass or stiffness is outside the supported range')
    from . import integration
    if not integration.operator_available('object.create_cloth'):
        issues.append('Simply Cloth Studio public Create Cloth operator is unavailable')
    plan = {'garment': garment, 'armature': armature, 'support_bone': bone_name,
            'fabric_faces': tuple(sorted(fabric_faces)), 'trim_faces': tuple(trim_faces),
            'fabric_vertices': tuple(fabric_vertices), 'pin_group': pin_name,
            'pin_band': pin_band, 'pin_candidates': pin_candidates,
            'total_mass_kg': total_mass,
            'tension': float(getattr(settings, 'component_tension', 15.0)),
            'bending': float(getattr(settings, 'component_bending', 0.5)),
            'selection': {'source': source, 'material_slot': slot,
                          'group': group_name, 'threshold': threshold}}
    return plan, issues


def component_preview(settings, context=None) -> dict:
    plan, issues = plan_fabric_component(settings, context)
    if plan is None:
        return {'ok': False, 'issues': issues}
    return {'ok': not issues, 'issues': issues,
            'garment': plan['garment'].name, 'support_armature': getattr(plan['armature'], 'name', ''),
            'support_bone': plan['support_bone'],
            'fabric_faces': len(plan['fabric_faces']),
            'fabric_vertices': len(plan['fabric_vertices']),
            'trim_faces': len(plan['trim_faces']),
            'pin_candidates': plan['pin_candidates'],
            'selection': plan['selection'], 'total_mass_kg': plan['total_mass_kg']}


def _split_copy(garment, keep_faces: set[int], name: str, token: str, collection):
    import bmesh
    helper = garment.copy()
    helper.data = garment.data.copy()
    helper.name = name
    # Object.copy retains a read-only reference to any source Action so the
    # helper follows object animation; no keyframes or Action data are edited.
    helper[COMPONENT_OWNER_KEY] = token
    helper.data[COMPONENT_OWNER_KEY] = token
    for key in (PROFILE_KEY, COMPONENT_PROFILE_KEY):
        if key in helper.keys():
            del helper[key]
    collection.objects.link(helper)
    bm = None
    try:
        bm = bmesh.new()
        bm.from_mesh(helper.data)
        bm.faces.ensure_lookup_table()
        bm.faces.index_update()
        bmesh.ops.delete(bm, geom=[face for face in bm.faces if face.index not in keep_faces],
                         context='FACES')
        bmesh.ops.delete(bm, geom=[vert for vert in bm.verts if not vert.link_faces],
                         context='VERTS')
        bm.to_mesh(helper.data)
        helper.data.update()
    except Exception:
        data = helper.data
        bpy.data.objects.remove(helper, do_unlink=True)
        if data.users == 0 and data.get(COMPONENT_OWNER_KEY) == token:
            bpy.data.meshes.remove(data)
        raise
    finally:
        if bm is not None:
            bm.free()
    return helper


def _component_pin_group(fabric, plan: dict, token: str) -> tuple[str, list[int]]:
    """Create an owned pin mask without reusing a deform-bone group."""
    name = 'SC_ComponentPin_' + token[:8]
    existing = fabric.vertex_groups.get(name)
    if existing is not None:
        fabric.vertex_groups.remove(existing)
    pin = fabric.vertex_groups.new(name=name)
    weights = {}
    if plan['pin_group']:
        source = fabric.vertex_groups.get(plan['pin_group'])
        if source is None:
            raise RuntimeError('Copied pin weights are missing on the fabric helper')
        for vertex in fabric.data.vertices:
            weight = _weight(fabric, source, vertex.index)
            if weight > 0:
                weights[vertex.index] = weight
    else:
        heights = [(fabric.matrix_world @ vertex.co).z for vertex in fabric.data.vertices]
        if not heights:
            raise RuntimeError('Split fabric helper has no vertices')
        low, high = min(heights), max(heights)
        span = high - low
        if span <= 1.0e-9:
            raise RuntimeError('Selected fabric has no usable height for a top pin')
        band = max(span * plan['pin_band'], 1.0e-9)
        start = high - band
        for vertex, height in zip(fabric.data.vertices, heights):
            if height >= start:
                weights[vertex.index] = min(1.0, max(0.0, (height - start) / band))
    if not weights:
        raise RuntimeError('Copied pin weights are missing on the fabric helper')
    for index, weight in weights.items():
        pin.add([index], weight, 'REPLACE')
    return pin.name, sorted(weights)


def _bind_component_support(fabric, plan: dict, pin_name: str, pin_vertices: list[int]):
    """Replace copied armature influence on pins with one pose-preserving bone Hook."""
    generative = [(modifier, bool(modifier.show_viewport)) for modifier in fabric.modifiers
                  if modifier.type in ('SUBSURF', 'MULTIRES')]
    try:
        for modifier, _ in generative:
            modifier.show_viewport = False
        bpy.context.view_layer.update()
        evaluated = fabric.evaluated_get(bpy.context.evaluated_depsgraph_get())
        mesh = evaluated.to_mesh()
        try:
            if len(mesh.vertices) != len(fabric.data.vertices):
                raise RuntimeError('Support bind requires unchanged helper vertex count')
            bind_world = {index: evaluated.matrix_world @ mesh.vertices[index].co.copy()
                          for index in pin_vertices}
        finally:
            evaluated.to_mesh_clear()
    finally:
        for modifier, visible in generative:
            modifier.show_viewport = visible
    bone_groups = set()
    for modifier in fabric.modifiers:
        armature = modifier.object if modifier.type == 'ARMATURE' else None
        if armature is not None and getattr(armature, 'type', '') == 'ARMATURE':
            bone_groups.update(bone.name for bone in armature.data.bones)
    for group_name in bone_groups:
        group = fabric.vertex_groups.get(group_name)
        if group is not None:
            group.remove(pin_vertices)
    inverse_world = fabric.matrix_world.inverted_safe()
    for index, world_co in bind_world.items():
        fabric.data.vertices[index].co = inverse_world @ world_co
    fabric.data.update()
    hook = fabric.modifiers.new(name=COMPONENT_HOOK_MODIFIER, type='HOOK')
    hook.object = plan['armature']
    hook.subtarget = plan['support_bone']
    hook.vertex_group = pin_name
    hook.strength = 1.0
    hook.falloff_type = 'NONE'
    target_matrix = plan['armature'].matrix_world @ plan['armature'].pose.bones[plan['support_bone']].matrix
    hook.matrix_inverse = target_matrix.inverted_safe() @ fabric.matrix_world
    _place_after_armature(fabric, hook)
    return hook


def _source_snapshot(garment) -> dict:
    return {'hide_viewport': bool(garment.hide_viewport),
            'hide_render': bool(garment.hide_render),
            'modifiers': [{'name': mod.name, 'type': mod.type,
                           'show_viewport': bool(mod.show_viewport),
                           'show_render': bool(mod.show_render)}
                          for mod in garment.modifiers]}


def _source_matches(garment, snapshot: dict) -> bool:
    if not isinstance(snapshot, dict) or not isinstance(snapshot.get('modifiers'), list):
        return False
    return [{'name': mod.name, 'type': mod.type,
             'show_viewport': bool(mod.show_viewport),
             'show_render': bool(mod.show_render)} for mod in garment.modifiers] == snapshot['modifiers']


def _owned_helpers(garment, profile: dict):
    token = profile.get('token', '')
    fabric = bpy.data.objects.get(profile.get('fabric_helper', ''))
    trim = bpy.data.objects.get(profile.get('trim_helper', ''))
    if (not token or fabric is None or trim is None or fabric is trim
            or fabric.get(COMPONENT_OWNER_KEY) != token
            or trim.get(COMPONENT_OWNER_KEY) != token):
        return None, None
    return fabric, trim


def component_mode(garment, mode: str) -> tuple[dict | None, str]:
    profile = _component_profile(garment)
    if not profile:
        return None, 'No fabric component setup is saved'
    fabric, trim = _owned_helpers(garment, profile)
    if fabric is None:
        return None, 'Owned fabric or trim helper is missing or changed'
    snapshot = profile.get('original', {})
    if not _source_matches(garment, snapshot):
        return None, 'Original garment modifier stack or visibility changed'
    cloth = fabric.modifiers.get(profile.get('cloth_modifier', ''))
    if cloth is None or cloth.type != 'CLOTH' or any(mod.type == 'CLOTH' for mod in trim.modifiers):
        return None, 'Fabric-only Cloth configuration is missing or changed'
    wanted = str(mode).upper()
    if wanted not in (MODE_BONE, MODE_CLOTH):
        return None, 'Unsupported skirt mode'
    if wanted == MODE_CLOTH and bool(getattr(getattr(cloth, 'point_cache', None), 'is_baked', False)):
        return None, 'Cloth cache is baked; free or rebake it before switching to cloth'
    on = wanted == MODE_CLOTH
    garment.hide_viewport = True if on else bool(snapshot['hide_viewport'])
    garment.hide_render = True if on else bool(snapshot['hide_render'])
    fabric.hide_viewport = fabric.hide_render = not on
    trim.hide_viewport = trim.hide_render = not on
    cloth.show_viewport = cloth.show_render = on
    profile['mode'] = wanted
    garment[COMPONENT_PROFILE_KEY] = json.dumps(profile, ensure_ascii=False)
    return {'mode': wanted, 'fabric': fabric.name, 'trim': trim.name,
            'source_visible': not garment.hide_viewport}, ''


def component_apply(settings, context=None) -> tuple[dict | None, str]:
    plan, issues = plan_fabric_component(settings, context)
    if plan is None or issues:
        return None, '; '.join(issues)
    garment = plan['garment']
    if not getattr(garment, 'users_collection', ()):
        return None, 'Garment is not linked to a collection'
    token = uuid.uuid4().hex
    collection = garment.users_collection[0]
    created = []
    backup = None
    backup_id = ''
    snapshot = _source_snapshot(garment)
    try:
        fabric = _split_copy(garment, set(plan['fabric_faces']),
                             garment.name + '_SC_Fabric', token, collection)
        created.append(fabric)
        source_action = getattr(getattr(garment, 'animation_data', None), 'action', None)
        _isolate_component_action(garment, fabric, token)
        trim = _split_copy(garment, set(plan['trim_faces']),
                           garment.name + '_SC_Trim', token, collection)
        created.append(trim)
        if not fabric.data.vertices or not trim.data.vertices:
            raise RuntimeError('Split helpers contain no vertices')
        pin_name, pin_vertices = _component_pin_group(fabric, plan, token)
        hook = _bind_component_support(fabric, plan, pin_name, pin_vertices)
        modifiers_before_external = {modifier.name for modifier in fabric.modifiers}
        actions_before_external = {_action_identity(action) for action in bpy.data.actions}
        objects_before_external = {_object_identity(obj) for obj in bpy.data.objects}
        meshes_before_external = {_object_identity(mesh) for mesh in bpy.data.meshes}
        try:
            cloth, error = _external_cloth({'garment': fabric}, context)
        finally:
            try:
                backup, backup_id = _claim_external_backup(
                    fabric, token, objects_before_external, meshes_before_external)
            finally:
                _claim_new_helper_action(fabric, token, actions_before_external, source_action)
        if error:
            raise RuntimeError(error)
        external_aux = []
        for modifier in fabric.modifiers:
            if modifier.name in modifiers_before_external or modifier.type == 'CLOTH':
                continue
            # SCS adds optional presentation modifiers as part of Create Cloth.
            # Keep them for SCS interoperability, but do not let them alter the
            # source silhouette merely because this component was created.
            modifier.show_viewport = False
            modifier.show_render = False
            external_aux.append(modifier.name)
        _place_after_armature(fabric, cloth)
        hook_index = list(fabric.modifiers).index(hook)
        cloth_index = list(fabric.modifiers).index(cloth)
        if hook_index > cloth_index:
            fabric.modifiers.move(hook_index, cloth_index)
        cloth.settings.vertex_group_mass = pin_name
        count = len(fabric.data.vertices)
        cloth.settings.mass = plan['total_mass_kg'] / count
        cloth.settings.tension_stiffness = plan['tension']
        cloth.settings.compression_stiffness = plan['tension']
        cloth.settings.shear_stiffness = plan['tension']
        cloth.settings.bending_stiffness = plan['bending']
        profile = {'schema': 2, 'token': token, 'fabric_helper': fabric.name,
                   'trim_helper': trim.name, 'cloth_modifier': cloth.name,
                   'pin_group': pin_name, 'pin_vertices': len(pin_vertices),
                   'external_backup': backup.name, 'external_backup_id': backup_id,
                     'external_aux_modifiers': external_aux,
                   'support_hook': hook.name,
                   'support_armature': plan['armature'].name,
                   'support_bone': plan['support_bone'], 'selection': plan['selection'],
                   'fabric_faces': len(plan['fabric_faces']), 'trim_faces': len(plan['trim_faces']),
                   'simulated_vertices': count, 'total_mass_kg': plan['total_mass_kg'],
                   'mass_per_vertex_kg': cloth.settings.mass,
                   'owned_actions': [action.name for action in getattr(bpy.data, 'actions', ())
                                     if action.get(COMPONENT_ACTION_OWNER_KEY) == token],
                   'source_material_slots': [mat.name if mat else '' for mat in garment.data.materials],
                   'source_uv_layers': [layer.name for layer in garment.data.uv_layers],
                   'original': snapshot, 'mode': MODE_BONE}
        garment[COMPONENT_PROFILE_KEY] = json.dumps(profile, ensure_ascii=False)
        result, error = component_mode(garment, MODE_BONE)
        if error:
            raise RuntimeError(error)
        return {'profile': profile, 'mode': result['mode'], 'created': True}, ''
    except Exception as exc:
        if COMPONENT_PROFILE_KEY in garment.keys():
            del garment[COMPONENT_PROFILE_KEY]
        _remove_owned_backup(backup, token, backup_id)
        for helper in reversed(created):
            data = helper.data
            bpy.data.objects.remove(helper, do_unlink=True)
            if data.users == 0 and data.get(COMPONENT_OWNER_KEY) == token:
                bpy.data.meshes.remove(data)
        _remove_zero_user_owned_actions(token)
        garment.hide_viewport = snapshot['hide_viewport']
        garment.hide_render = snapshot['hide_render']
        return None, 'Fabric component setup failed without changing the source: ' + str(exc)


def component_validate(garment) -> dict:
    """Configuration consistency only; intersection/motion is a separate gate."""
    profile = _component_profile(garment)
    issues = []
    if not profile:
        return {'ok': False, 'issues': ['No fabric component setup is saved'],
                'geometry': 'UNVERIFIED'}
    fabric, trim = _owned_helpers(garment, profile)
    if fabric is None:
        return {'ok': False, 'issues': ['Owned fabric or trim helper is missing or changed'],
                'geometry': 'UNVERIFIED'}
    if not _source_matches(garment, profile.get('original', {})):
        issues.append('Original garment modifier stack or visibility changed')
    if int(profile.get('schema', 1)) >= 2 and _owned_backup(profile) is None:
        issues.append('Owned external cloth backup is missing or changed')
    source_action = _helper_action(garment)
    fabric_action = _helper_action(fabric)
    if (source_action is not None and fabric_action is not None
            and _action_identity(fabric_action) == _action_identity(source_action)):
        issues.append('Fabric helper still shares the source Action')
    if (fabric_action is not None and
            fabric_action.get(COMPONENT_ACTION_OWNER_KEY) != profile.get('token')):
        issues.append('Fabric helper Action is not owned by this setup')
    materials = [mat.name if mat else '' for mat in garment.data.materials]
    uvs = [layer.name for layer in garment.data.uv_layers]
    if materials != profile.get('source_material_slots') or uvs != profile.get('source_uv_layers'):
        issues.append('Original garment materials or UV layer structure changed')
    for helper in (fabric, trim):
        if ([mat.name if mat else '' for mat in helper.data.materials] != materials
                or [layer.name for layer in helper.data.uv_layers] != uvs):
            issues.append('Helper materials or UV layer structure differs from source')
    if (len(fabric.data.polygons) != profile.get('fabric_faces')
            or len(trim.data.polygons) != profile.get('trim_faces')):
        issues.append('Helper face counts differ from the saved selection')
    if any(mod.type == 'CLOTH' for mod in trim.modifiers):
        issues.append('Retained trim has an unexpected Cloth modifier')
    cloth = fabric.modifiers.get(profile.get('cloth_modifier', ''))
    hook = fabric.modifiers.get(profile.get('support_hook', ''))
    count = len(fabric.data.vertices)
    if (cloth is None or cloth.type != 'CLOTH'
            or count != profile.get('simulated_vertices')
            or not count or abs(cloth.settings.mass * count - profile.get('total_mass_kg', 0)) > 1e-5
            or cloth.settings.vertex_group_mass != profile.get('pin_group')):
        issues.append('Fabric Cloth, pin or total-mass conversion is inconsistent')
    if (hook is None or hook.type != 'HOOK'
            or hook.object is None or hook.object.name != profile.get('support_armature')
            or hook.subtarget != profile.get('support_bone')
            or hook.vertex_group != profile.get('pin_group')
            or cloth is not None and list(fabric.modifiers).index(hook) > list(fabric.modifiers).index(cloth)):
        issues.append('Selected support armature or bone binding is missing or changed')
    if cloth is not None and cloth.type == 'CLOTH':
        on = profile.get('mode') == MODE_CLOTH
        if bool(cloth.show_viewport) != on or bool(fabric.hide_viewport) == on \
                or bool(trim.hide_viewport) == on:
            issues.append('Fabric component mode visibility is inconsistent')
    return {'ok': not issues, 'issues': issues, 'geometry': 'UNVERIFIED',
            'warnings': ['Motion, trim contact and surface penetration require separate native review'],
            'fabric_vertices': count, 'fabric_faces': len(fabric.data.polygons),
            'trim_faces': len(trim.data.polygons), 'mode': profile.get('mode', '')}


def component_cleanup(garment) -> tuple[dict | None, str]:
    profile = _component_profile(garment)
    if not profile:
        return {'removed_owned_helpers': 0, 'mode': MODE_BONE}, ''
    fabric, trim = _owned_helpers(garment, profile)
    if fabric is None:
        return None, 'Owned fabric or trim helper is missing or changed'
    requires_backup = int(profile.get('schema', 1)) >= 2
    backup = _owned_backup(profile) if requires_backup else None
    if requires_backup and backup is None:
        return None, 'Owned external cloth backup is missing or changed'
    state, error = component_mode(garment, MODE_BONE)
    if error:
        return None, error
    token = profile['token']
    if backup is not None:
        _remove_owned_backup(backup, token, profile['external_backup_id'])
    for helper in (fabric, trim):
        data = helper.data
        bpy.data.objects.remove(helper, do_unlink=True)
        if data.users == 0 and data.get(COMPONENT_OWNER_KEY) == token:
            bpy.data.meshes.remove(data)
    removed_actions = _remove_zero_user_owned_actions(token)
    del garment[COMPONENT_PROFILE_KEY]
    return {'removed_owned_helpers': 2, 'removed_owned_backups': int(backup is not None),
            'removed_owned_actions': removed_actions,
            'mode': MODE_BONE}, ''


# The bridge never keys the user's armature. The cloth is sampled completely
# before a separate, unparented helper armature and any output constraints exist.
BRIDGE_PROFILE_KEY = '_smart_cloth_suite_bone_bridge_v1'
BRIDGE_OWNER_KEY = '_smart_cloth_suite_bone_bridge_owner_v1'


@dataclass(frozen=True, slots=True)
class BridgeStatusV1:
    """Read-only public observation. Consumers ignore unknown future fields.

    This value does not expose or promise the private stored profile schema.
    One source garment per armature is supported; connected deform children
    remain outside this bridge's supported target set.
    """
    contract_version: int
    state: str
    armature_name: str
    source_name: str
    driven_bones: tuple[str, ...]
    reason: str


def bridge_status(armature, garment=None) -> BridgeStatusV1:
    """Observe an explicit armature; never change mode, data or constraints.

    ABSENT means no bridge or recognizable owned residue. INVALID means the
    identity/structure cannot be trusted. MIXED means exact owned constraints
    exist but mute state and saved mode disagree. Unknown future fields are
    ignored, while unknown mode values fail closed as INVALID.
    """
    def result(state, reason='', source='', bones=()):
        return BridgeStatusV1(1, state, getattr(armature, 'name', ''), source,
                              tuple(bones), reason)

    if armature is None or getattr(armature, 'type', None) != 'ARMATURE':
        return result('INVALID', 'explicit_armature_required')
    try:
        raw = armature.get(BRIDGE_PROFILE_KEY)
        if raw is None:
            for bone in armature.pose.bones:
                for constraint in bone.constraints:
                    target = getattr(constraint, 'target', None)
                    if (constraint.type == 'COPY_TRANSFORMS'
                            and constraint.name.startswith('SCB_')
                            and target is not None
                            and target.get(BRIDGE_OWNER_KEY)):
                        return result('INVALID', 'orphan_owned_output')
            return result('ABSENT')
        if not isinstance(raw, str) or not raw:
            return result('INVALID', 'invalid_saved_profile')
        profile = json.loads(raw)
        if not isinstance(profile, dict):
            return result('INVALID', 'invalid_saved_profile')
        source_name = profile.get('source')
        if not isinstance(source_name, str) or not source_name:
            return result('INVALID', 'invalid_source')
        source = bpy.data.objects.get(source_name)
        if source is None or source.type != 'MESH':
            return result('INVALID', 'missing_source', source_name)
        if garment is not None and (getattr(garment, 'type', None) != 'MESH'
                                    or _object_identity(garment) != _object_identity(source)):
            return result('INVALID', 'source_mismatch', source_name)
        if profile.get('armature') != armature.name:
            return result('INVALID', 'armature_mismatch', source_name)
        if profile.get('mode') not in ('STANDARD', 'CLOTH_BAKED'):
            return result('INVALID', 'unknown_saved_mode', source_name)
        rows = profile.get('constraints')
        if (not isinstance(rows, list) or not rows
                or any(not isinstance(row, dict) for row in rows)):
            return result('INVALID', 'invalid_output_rows', source_name)
        keys = [(row.get('bone'), row.get('name')) for row in rows]
        if len(set(keys)) != len(keys) or any(not all(key) for key in keys):
            return result('INVALID', 'duplicate_or_invalid_output', source_name)
        helper, constraints = _bridge_owned_resources(armature, profile)
        helper_bones = helper.data.bones
        if any(helper_bones.get(row['helper_bone']) is None for row in rows):
            return result('INVALID', 'missing_helper_bone', source_name)
        recorded = set(keys)
        for bone in armature.pose.bones:
            for constraint in bone.constraints:
                target = getattr(constraint, 'target', None)
                if (constraint.type == 'COPY_TRANSFORMS' and target is not None
                        and _object_identity(target) == _object_identity(helper)
                        and constraint.name.startswith('SCB_')
                        and (bone.name, constraint.name) not in recorded):
                    return result('INVALID', 'unrecorded_owned_output', source_name)
        muted = [bool(constraint.mute) for _, constraint in constraints]
        bones = [bone.name for bone, _ in constraints]
        influences = [getattr(constraint, 'influence', None) for _, constraint in constraints]
        if any(type(value) not in (int, float) or not math.isfinite(value)
               for value in influences):
            return result('INVALID', 'missing_or_nonfinite_owned_influence', source_name, bones)
        if any(value != 1.0 for value in influences):
            return result('MIXED', 'owned_output_influence_not_full', source_name, bones)
        if profile['mode'] == 'STANDARD' and all(muted):
            return result('STANDARD', source=source_name, bones=bones)
        if profile['mode'] == 'CLOTH_BAKED' and not any(muted):
            return result('CLOTH_BAKED', source=source_name, bones=bones)
        return result('MIXED', 'saved_mode_output_disagree', source_name, bones)
    except (AttributeError, KeyError, TypeError, ValueError, RuntimeError, ReferenceError):
        return result('INVALID', 'inconsistent_owned_output')


def _bridge_profile(armature) -> dict:
    if armature is None:
        return {}
    try:
        value = armature.get(BRIDGE_PROFILE_KEY, '')
        profile = json.loads(value) if value else {}
        return profile if isinstance(profile, dict) else {}
    except (TypeError, ValueError):
        return {}


_BRIDGE_ERRORS_JA = {
    'Choose a cloth mesh and its target armature': 'クロスメッシュと対象アーマチュアを指定してください',
    'Clear the existing cloth-to-bone output before sampling again': '再採取する前に既存のボーン焼付けを解除してください',
    'Bake the source Cloth point cache before bone sampling': 'ボーン採取前にクロスのポイントキャッシュをベイクしてください',
    'Choose a finite frame range inside the baked Cloth cache': 'ベイク済みキャッシュ内の有限フレーム範囲を指定してください',
    'Selected baked range exceeds bounded sampling budget': '選択した焼付け範囲は採取処理の上限を超えています',
    'Select garment-only target bones in the armature Pose Mode': 'ポーズモードで衣装専用の対象骨を選択してください',
    'Select 2 to 64 target pose bones': '対象ポーズ骨を2～64本選択してください',
    'At least one selected child bone must be cloth driven': 'クロスで駆動する子骨を1本以上選択してください',
    'Cloth topology is empty or exceeds the finite limit': 'クロスのトポロジーが空か上限を超えています',
    'Cloth topology has invalid vertex indices': 'クロスの頂点参照が不正です',
    'No nondegenerate cloth triangle is available': '有効なクロス三角面がありません',
    'Cloth head/tail samples are degenerate': 'クロスの頭・尾の採取点が重なっています',
    'Cloth transverse sample is degenerate': 'クロスの横方向の採取点が不正です',
    'Evaluated Cloth topology changed during the frame range': 'フレーム範囲内でクロスのトポロジーが変わりました',
    'Intended Cloth is not active in evaluated source': '評価済みの採取元で対象クロスが有効ではありません',
    'Helper Action was not created': '出力用アクションを作成できませんでした',
    'Cloth-bone output name is occupied': 'ボーン焼付け出力名が使用されています',
    'Owned cloth-bone helper is missing or changed': '所有するボーン焼付け補助物が見つからないか変更されています',
    'Owned cloth-bone output is missing, reordered or changed': '所有するボーン焼付け出力がないか順序・内容が変更されています',
    'No owned cloth-bone output exists': '所有するボーン焼付け出力がありません',
    'Unsupported cloth-bone mode': '対応しないボーン焼付け方式です',
    'Scene frame rate differs from the baked Cloth output': 'シーンのフレームレートが焼付け時と異なります',
}


def bridge_localize(error: str, japanese: bool) -> str:
    if not japanese:
        return error
    for english, translated in _BRIDGE_ERRORS_JA.items():
        if error.startswith(english):
            return translated + error[len(english):]
    for english, translated in (
        ('A selected target is not a weighted garment deform bone: ', '衣装ウェイトを持つ変形骨ではありません: '),
        ('Active target constraint conflicts with cloth output: ', '対象骨の有効な制約がクロス出力と競合します: '),
        ('Cloth surface is too far from target bone: ', 'クロス面が対象骨から遠すぎます: '),
        ('Cloth target transform is nonfinite: ', 'クロス変換に無効な数値があります: '),
        ('Keyed helper target is unreachable: ', 'キー化した補助物の対象姿勢に到達できません: '),
        ('Constrained Kilt target is unreachable: ', '制約下の対象骨に到達できません: '),
    ):
        if error.startswith(english):
            return translated + error[len(english):]
    return 'ボーン焼付けに失敗しました。詳細: ' + error


def _bridge_mesh_frame(source, cloth, depsgraph, view_layer):
    import math
    # Check the same evaluated object that supplies geometry. A driver can
    # override our temporary show_viewport assignment during frame_set.
    cache = getattr(cloth, 'point_cache', None)
    if cache is None or not bool(cache.is_baked):
        raise RuntimeError('Bake the source Cloth point cache before bone sampling')
    if (source.hide_viewport or not source.visible_get(view_layer=view_layer)
            or not cloth.show_viewport):
        raise RuntimeError('Intended Cloth is not active in evaluated source')
    evaluated = source.evaluated_get(depsgraph)
    if (not evaluated.is_evaluated
            or _object_identity(evaluated.original) != _object_identity(source)):
        raise RuntimeError('Intended Cloth is not active in evaluated source')
    matches = [modifier for modifier in evaluated.modifiers
               if modifier.name == cloth.name and modifier.type == 'CLOTH']
    if len(matches) != 1 or not matches[0].show_viewport:
        raise RuntimeError('Intended Cloth is not active in evaluated source')
    mesh = evaluated.to_mesh()
    try:
        if hasattr(mesh, 'calc_loop_triangles'):
            mesh.calc_loop_triangles()
        triangles = [tuple(int(i) for i in tri.vertices) for tri in mesh.loop_triangles]
        if not triangles or len(triangles) > 100000:
            raise RuntimeError('Cloth topology is empty or exceeds the finite limit')
        points = [source.matrix_world @ vertex.co for vertex in mesh.vertices]
        if (not points or len(points) > 200000
                or any(max(tri) >= len(points) for tri in triangles)
                or any(not all(math.isfinite(v) for v in point) for point in points)):
            raise RuntimeError('Cloth topology has invalid vertex indices')
        signature = hashlib.sha256(json.dumps(
            [len(points), triangles], separators=(',', ':')).encode('utf-8')).hexdigest()
        return points, triangles, signature
    finally:
        evaluated.to_mesh_clear()


def _bridge_anchor(point, points, triangles):
    from mathutils.geometry import closest_point_on_tri
    nearest = None
    for index, tri in enumerate(triangles):
        a, b, c = (points[i] for i in tri)
        v0, v1 = b - a, c - a
        d00, d01, d11 = v0.dot(v0), v0.dot(v1), v1.dot(v1)
        denominator = d00 * d11 - d01 * d01
        if denominator <= 1e-16:
            continue
        hit = closest_point_on_tri(point, a, b, c)
        v2 = hit - a
        d20, d21 = v2.dot(v0), v2.dot(v1)
        v = (d11 * d20 - d01 * d21) / denominator
        w = (d00 * d21 - d01 * d20) / denominator
        weights = (1.0 - v - w, v, w)
        distance = (point - hit).length_squared
        if nearest is None or distance < nearest[0]:
            nearest = (distance, index, weights)
    if nearest is None:
        raise RuntimeError('No nondegenerate cloth triangle is available')
    return (nearest[1], nearest[2]), nearest[0] ** 0.5


def _bridge_point(anchor, points, triangles):
    index, weights = anchor
    tri = triangles[index]
    return sum((points[tri[i]] * weights[i] for i in range(3)), points[tri[0]] * 0.0)


def _bridge_frame(head, tail, transverse):
    from mathutils import Matrix
    y = tail - head
    if y.length < 1e-5:
        raise RuntimeError('Cloth head/tail samples are degenerate')
    y.normalize()
    x = transverse - head
    x -= y * x.dot(y)
    if x.length < 1e-5:
        raise RuntimeError('Cloth transverse sample is degenerate')
    x.normalize()
    z = x.cross(y).normalized()
    x = y.cross(z).normalized()
    return Matrix(((x.x, y.x, z.x, head.x),
                   (x.y, y.y, z.y, head.y),
                   (x.z, y.z, z.z, head.z),
                   (0.0, 0.0, 0.0, 1.0)))


def _bridge_plan(settings, context):
    source = getattr(settings, 'bridge_source_mesh', None)
    armature = getattr(settings, 'bridge_target_armature', None)
    if source is None or source.type != 'MESH' or armature is None or armature.type != 'ARMATURE':
        raise RuntimeError('Choose a cloth mesh and its target armature')
    if _bridge_profile(armature):
        raise RuntimeError('Clear the existing cloth-to-bone output before sampling again')
    cloth = next((mod for mod in source.modifiers if mod.type == 'CLOTH'), None)
    cache = getattr(cloth, 'point_cache', None) if cloth is not None else None
    if cache is None or not bool(cache.is_baked):
        raise RuntimeError('Bake the source Cloth point cache before bone sampling')
    start, end = int(settings.bridge_frame_start), int(settings.bridge_frame_end)
    if (end < start or start < int(cache.frame_start)
            or end > int(cache.frame_end)):
        raise RuntimeError('Choose a finite frame range inside the baked Cloth cache')
    if context.object is not armature or context.mode != 'POSE':
        raise RuntimeError('Select garment-only target bones in the armature Pose Mode')
    selected = list(getattr(context, 'selected_pose_bones', ()) or ())
    if len(selected) < 2 or len(selected) > 64:
        raise RuntimeError('Select 2 to 64 target pose bones')
    names = {bone.name for bone in selected}
    def depth(bone):
        count = 0
        while bone.parent is not None:
            bone, count = bone.parent, count + 1
        return count
    ordered = sorted(selected, key=lambda bone: (depth(bone), bone.name))
    roots = [bone.name for bone in ordered if bone.parent is None or bone.parent.name not in names]
    driven = [bone for bone in ordered if bone.name not in roots]
    if not driven:
        raise RuntimeError('At least one selected child bone must be cloth driven')
    # A work estimate bounds memory/CPU without rejecting long but finite
    # clips by an arbitrary frame-count constant. The per-frame floor covers
    # depsgraph/cache seeks, while vertices and output bones cover payload.
    frame_count = end - start + 1
    work_units = frame_count * (10000 + len(source.data.vertices) + 100 * len(driven))
    if work_units > 100_000_000:
        raise RuntimeError('Selected baked range exceeds bounded sampling budget')
    weighted_groups = {row.group for vertex in source.data.vertices for row in vertex.groups
                       if row.weight > 1e-8}
    for bone in driven:
        group = source.vertex_groups.get(bone.name)
        if not bone.bone.use_deform or group is None or group.index not in weighted_groups:
            raise RuntimeError('A selected target is not a weighted garment deform bone: ' + bone.name)
        for constraint in bone.constraints:
            if constraint.mute or constraint.influence == 0:
                continue
            arp_master = (constraint.type == 'COPY_TRANSFORMS'
                          and constraint.target is not None
                          and _object_identity(constraint.target) == _object_identity(armature)
                          and constraint.mix_mode == 'BEFORE'
                          and constraint.owner_space == 'CUSTOM'
                          and constraint.name.startswith(('CopyTransforms_master', 'Copy Transforms_row_')))
            if not arp_master:
                raise RuntimeError('Active target constraint conflicts with cloth output: ' + bone.name)
    return source, armature, cloth, start, end, ordered, roots, driven


def _bridge_reference(source, armature, driven, cloth, depsgraph, view_layer):
    from mathutils import Vector
    points, triangles, signature = _bridge_mesh_frame(source, cloth, depsgraph, view_layer)
    anchors = {}
    for bone in driven:
        world = armature.matrix_world @ bone.matrix
        head = armature.matrix_world @ bone.head
        tail = armature.matrix_world @ bone.tail
        transverse = head + (world.to_3x3() @ Vector((1.0, 0.0, 0.0))).normalized() * max(bone.length * 0.25, 0.01)
        rows = [_bridge_anchor(point, points, triangles) for point in (head, tail, transverse)]
        if any(distance > max(bone.length * 2.0, 0.05) for _, distance in rows):
            raise RuntimeError('Cloth surface is too far from target bone: ' + bone.name)
        anchors[bone.name] = [anchor for anchor, _ in rows]
        sampled = [_bridge_point(anchor, points, triangles) for anchor in anchors[bone.name]]
        _bridge_frame(*sampled)  # Reject a degenerate reference before writing.
    return anchors, signature


def bridge_preview(settings, context) -> tuple[dict | None, str]:
    try:
        source, armature, cloth, start, end, ordered, roots, driven = _bridge_plan(settings, context)
        scene = context.scene
        frame = scene.frame_current
        subframe = scene.frame_subframe
        visible, cloth_visible = source.hide_viewport, cloth.show_viewport
        try:
            source.hide_viewport = False
            cloth.show_viewport = True
            scene.frame_set(start)
            context.view_layer.update()
            anchors, signature = _bridge_reference(source, armature, driven, cloth,
                                                    context.evaluated_depsgraph_get(),
                                                    context.view_layer)
        finally:
            source.hide_viewport, cloth.show_viewport = visible, cloth_visible
            scene.frame_set(frame, subframe=subframe)
        return {'source': source.name, 'armature': armature.name,
                'ordered_bones': [bone.name for bone in ordered], 'fixed_roots': roots,
                'driven_bones': list(anchors), 'frame_start': start, 'frame_end': end,
                'topology_sha256': signature, 'mode': 'PREVIEW_ONLY'}, ''
    except Exception as exc:
        return None, str(exc)


def bridge_bake(settings, context) -> tuple[dict | None, str]:
    """Finite sampling pass, then a separate owned output pass. Never live-bind cloth."""
    import math
    from mathutils import Matrix
    helper = helper_data = action = None
    output_started = False
    added = []
    token = uuid.uuid4().hex
    scene = context.scene
    old_frame = scene.frame_current
    old_subframe = scene.frame_subframe
    old_active = context.view_layer.objects.active
    old_mode = context.mode
    old_selected = tuple(context.selected_objects)
    source = cloth = armature = None
    old_visible = old_cloth_visible = None
    try:
        source, armature, cloth, start, end, ordered, roots, driven = _bridge_plan(settings, context)
        old_visible, old_cloth_visible = source.hide_viewport, cloth.show_viewport
        source.hide_viewport = False
        cloth.show_viewport = True
        scene.frame_set(start)
        context.view_layer.update()
        depsgraph = context.evaluated_depsgraph_get()
        anchors, topology = _bridge_reference(source, armature, driven, cloth,
                                              depsgraph, context.view_layer)
        reference_points, reference_triangles, _ = _bridge_mesh_frame(
            source, cloth, depsgraph, context.view_layer)
        reference_frames = {}
        reference_bones = {}
        for bone in driven:
            points = [_bridge_point(row, reference_points, reference_triangles)
                      for row in anchors[bone.name]]
            reference_frames[bone.name] = _bridge_frame(*points)
            reference_bones[bone.name] = armature.matrix_world @ bone.matrix.copy()
        samples = []
        for frame in range(start, end + 1):
            scene.frame_set(frame)
            context.view_layer.update()
            vertices, triangles, observed = _bridge_mesh_frame(
                source, cloth, context.evaluated_depsgraph_get(), context.view_layer)
            if observed != topology:
                raise RuntimeError('Evaluated Cloth topology changed during the frame range')
            row = {}
            for bone in driven:
                points = [_bridge_point(anchor, vertices, triangles)
                          for anchor in anchors[bone.name]]
                cloth_world = _bridge_frame(*points)
                target = cloth_world @ reference_frames[bone.name].inverted() @ reference_bones[bone.name]
                if not all(math.isfinite(value) for vector in target for value in vector):
                    raise RuntimeError('Cloth target transform is nonfinite: ' + bone.name)
                row[bone.name] = target
            samples.append((frame, row))
        # End sampling before any output can feed back into its source.
        source.hide_viewport, cloth.show_viewport = old_visible, old_cloth_visible
        scene.frame_set(old_frame, subframe=old_subframe)
        output_started = True
        bpy.ops.object.mode_set(mode='OBJECT')
        helper_data = bpy.data.armatures.new('SC_BoneBridge_' + token[:8])
        helper = bpy.data.objects.new('SC_BoneBridge_' + token[:8], helper_data)
        helper[BRIDGE_OWNER_KEY] = token
        helper_data[BRIDGE_OWNER_KEY] = token
        helper_id = uuid.uuid4().hex
        helper['sc_bridge_id'] = helper_id
        source.users_collection[0].objects.link(helper)
        helper.matrix_world = armature.matrix_world.copy()
        for obj in old_selected:
            obj.select_set(False)
        helper.select_set(True)
        context.view_layer.objects.active = helper
        bpy.ops.object.mode_set(mode='EDIT')
        helper_names = {}
        for index, bone in enumerate(driven):
            name = 'SCB_%03d' % index
            copied = helper_data.edit_bones.new(name)
            original = armature.data.bones[bone.name]
            copied.matrix = original.matrix_local.copy()
            copied.length = original.length
            copied.use_deform = False
            helper_names[bone.name] = name
        bpy.ops.object.mode_set(mode='POSE')
        previous_quaternions = {}
        for frame, row in samples:
            scene.frame_set(frame)
            for name, target_world in row.items():
                bone = helper.pose.bones[helper_names[name]]
                bone.rotation_mode = 'QUATERNION'
                # The helper is deliberately unparented and unconstrained.
                # Solve its rest-to-pose basis explicitly before keying the
                # channels; the constrained c_kilt basis is never edited.
                desired_local = helper.matrix_world.inverted() @ target_world
                bone.matrix_basis = bone.bone.matrix_local.inverted() @ desired_local
                context.view_layer.update()
                quaternion = bone.rotation_quaternion.copy()
                previous = previous_quaternions.get(name)
                if previous is not None and previous.dot(quaternion) < 0.0:
                    bone.rotation_quaternion = -quaternion
                    quaternion = -quaternion
                previous_quaternions[name] = quaternion
                for path in ('location', 'rotation_quaternion', 'scale'):
                    bone.keyframe_insert(data_path=path, frame=frame, group=name)
                if action is None:
                    action = _helper_action(helper)
                    if action is not None:
                        action[BRIDGE_OWNER_KEY] = token
        bpy.ops.object.mode_set(mode='OBJECT')
        action = _helper_action(helper)
        if action is None:
            raise RuntimeError('Helper Action was not created')
        action[BRIDGE_OWNER_KEY] = token
        context.view_layer.update()
        constraint_rows = []
        for index, bone in enumerate(driven):
            pose_bone = armature.pose.bones[bone.name]
            name = 'SCB_%s_%03d' % (token[:8], index)
            if pose_bone.constraints.get(name) is not None:
                raise RuntimeError('Cloth-bone output name is occupied')
            constraint = pose_bone.constraints.new('COPY_TRANSFORMS')
            added.append((pose_bone, constraint))
            constraint.name = name
            constraint.target = helper
            constraint.subtarget = helper_names[bone.name]
            constraint.target_space = 'WORLD'
            constraint.owner_space = 'WORLD'
            constraint.mix_mode = 'REPLACE'
            constraint.influence = 1.0
            constraint_rows.append({'bone': bone.name, 'name': name,
                                    'helper_bone': helper_names[bone.name]})
        # Verify both the keyed helper and the constrained ARP target against
        # the original cloth-world goal; comparing target only to helper would
        # conceal a bad helper Action/slot or rest-space conversion.
        for frame, row in samples:
            scene.frame_set(frame)
            context.view_layer.update()
            for name, target_world in row.items():
                helper_bone = helper.pose.bones[helper_names[name]]
                helper_world = helper.matrix_world @ helper_bone.matrix
                helper_error = max(abs(helper_world[i][j] - target_world[i][j])
                                   for i in range(4) for j in range(4))
                if helper_error > 1e-4:
                    raise RuntimeError('Keyed helper target is unreachable: ' + name)
                observed = armature.matrix_world @ armature.pose.bones[name].matrix
                error = max(abs(observed[i][j] - target_world[i][j])
                            for i in range(4) for j in range(4))
                if error > 1e-4:
                    raise RuntimeError('Constrained Kilt target is unreachable: ' + name)
        profile = {'schema': 1, 'token': token, 'helper': helper.name,
                   'helper_id': helper_id, 'source': source.name, 'armature': armature.name,
                   'frame_start': start, 'frame_end': end, 'fps': scene.render.fps,
                   'fps_base': scene.render.fps_base, 'topology_sha256': topology,
                   'fixed_roots': roots, 'constraints': constraint_rows,
                   'mode': 'CLOTH_BAKED'}
        armature[BRIDGE_PROFILE_KEY] = json.dumps(profile, ensure_ascii=False)
        return {'mode': 'CLOTH_BAKED', 'sampled_frames': len(samples),
                'fixed_roots': roots, 'driven_bones': len(driven)}, ''
    except Exception as exc:
        if output_started and context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        for bone, constraint in reversed(added):
            bone.constraints.remove(constraint)
        if action is None and helper is not None:
            action = _helper_action(helper)
            if action is not None:
                action[BRIDGE_OWNER_KEY] = token
        if helper is not None:
            bpy.data.objects.remove(helper, do_unlink=True)
        if helper_data is not None and helper_data.users == 0 and helper_data.get(BRIDGE_OWNER_KEY) == token:
            bpy.data.armatures.remove(helper_data)
        if action is not None and action.users == 0 and action.get(BRIDGE_OWNER_KEY) == token:
            bpy.data.actions.remove(action)
        return None, str(exc)
    finally:
        if source is not None and old_visible is not None:
            source.hide_viewport, cloth.show_viewport = old_visible, old_cloth_visible
        scene.frame_set(old_frame, subframe=old_subframe)
        if output_started:
            if context.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            for obj in context.selected_objects:
                obj.select_set(False)
            for obj in old_selected:
                if obj.name in bpy.data.objects:
                    obj.select_set(True)
            restored_active = (old_active if old_active is not None
                               and old_active.name in bpy.data.objects else None)
            context.view_layer.objects.active = restored_active
            if old_mode == 'POSE' and restored_active is not None and restored_active.type == 'ARMATURE':
                bpy.ops.object.mode_set(mode='POSE')


def _bridge_owned_resources(armature, profile):
    token = profile.get('token')
    helper = bpy.data.objects.get(profile.get('helper', ''))
    if (not token or helper is None or helper.type != 'ARMATURE'
            or helper.get(BRIDGE_OWNER_KEY) != token
            or helper.get('sc_bridge_id') != profile.get('helper_id')
            or helper.data.get(BRIDGE_OWNER_KEY) != token
            or _helper_action(helper) is None
            or _helper_action(helper).get(BRIDGE_OWNER_KEY) != token):
        raise RuntimeError('Owned cloth-bone helper is missing or changed')
    constraints = []
    for row in profile.get('constraints', []):
        bone = armature.pose.bones.get(row['bone'])
        constraint = bone.constraints.get(row['name']) if bone is not None else None
        if (constraint is None or constraint.type != 'COPY_TRANSFORMS'
                or constraint.target is None
                or _object_identity(constraint.target) != _object_identity(helper)
                or constraint.subtarget != row['helper_bone']
                or constraint.target_space != 'WORLD' or constraint.owner_space != 'WORLD'
                or constraint.mix_mode != 'REPLACE'
                or _object_identity(bone.constraints[-1]) != _object_identity(constraint)):
            raise RuntimeError('Owned cloth-bone output is missing, reordered or changed')
        constraints.append((bone, constraint))
    if not constraints:
        raise RuntimeError('No owned cloth-bone output exists')
    return helper, constraints


def bridge_mode(armature, mode: str, scene=None) -> tuple[dict | None, str]:
    try:
        profile = _bridge_profile(armature)
        helper, constraints = _bridge_owned_resources(armature, profile)
        if mode not in ('STANDARD', 'CLOTH_BAKED'):
            raise RuntimeError('Unsupported cloth-bone mode')
        if (mode == 'CLOTH_BAKED' and scene is not None
                and (scene.render.fps != profile.get('fps')
                     or scene.render.fps_base != profile.get('fps_base'))):
            raise RuntimeError('Scene frame rate differs from the baked Cloth output')
        for _, constraint in constraints:
            constraint.mute = mode == 'STANDARD'
        profile['mode'] = mode
        armature[BRIDGE_PROFILE_KEY] = json.dumps(profile, ensure_ascii=False)
        return {'mode': mode, 'driven_bones': len(constraints)}, ''
    except Exception as exc:
        return None, str(exc)


def bridge_clear(armature) -> tuple[dict | None, str]:
    try:
        profile = _bridge_profile(armature)
        if not profile:
            return {'removed_constraints': 0, 'removed_helpers': 0}, ''
        helper, constraints = _bridge_owned_resources(armature, profile)
        token = profile['token']
        for bone, constraint in constraints:
            bone.constraints.remove(constraint)
        action = _helper_action(helper)
        data = helper.data
        bpy.data.objects.remove(helper, do_unlink=True)
        if data.users == 0 and data.get(BRIDGE_OWNER_KEY) == token:
            bpy.data.armatures.remove(data)
        if action is not None and action.users == 0 and action.get(BRIDGE_OWNER_KEY) == token:
            bpy.data.actions.remove(action)
        del armature[BRIDGE_PROFILE_KEY]
        return {'removed_constraints': len(constraints), 'removed_helpers': 1}, ''
    except Exception as exc:
        return None, str(exc)


_ISSUE_JA = {
    'Reapply the skirt mapping to migrate the older profile first': '先にスカート割当てを再適用し、古い設定を移行してください',
    'Map a separate mesh body for outside correction': '外側補正には衣装と別のボディメッシュを指定してください',
    'Outside correction offset is outside the supported range': '外側補正距離が対応範囲外です',
    'Outside correction name is occupied by an unowned modifier': '外側補正の名前を所有外モディファイアが使用しています',
    'Could not create garment-only outside correction': '衣装だけの外側補正を作成できませんでした',
    'Original modifier stack snapshot is missing': '元のモディファイア順序の記録がありません',
    'External modifier snapshot is invalid': '外部モディファイアの記録が不正です',
    'Original modifier is missing or changed: ': '元のモディファイアがないか変更されています: ',
    'Shared-bone constraint cannot be safely migrated: ': '共有変形骨の制約を安全に移行できません: ',
    'Shared deformation bone has an avoidance constraint: ': '共有変形骨に回避制約が残っています: ',
    'Outside correction configuration is inconsistent': '外側補正の設定が一致しません',
    'Outside correction visibility is inconsistent': '外側補正の表示状態が一致しません',
    'Outside correction modifier is missing': '外側補正モディファイアがありません',
    'Original modifier stack or visibility is not restored': '元のモディファイア順序または表示状態が復元されていません',
    'Select a mesh garment': '衣装メッシュを指定してください',
    'The garment has no vertices': '衣装メッシュに頂点がありません',
    'Select an armature': 'アーマチュアを指定してください',
    'The garment is not driven by the mapped armature': '衣装は指定したアーマチュアで駆動されていません',
    'Skirt bone is missing: ': 'スカート骨がありません: ',
    'Skirt bone has no garment deform group: ': 'スカート骨に対応する衣装の変形グループがありません: ',
    'Leg collision bone is missing: ': '脚の衝突回避骨がありません: ',
    'Map at least one skirt bone': 'スカート骨を1本以上指定してください',
    'Map at least one leg collision bone': '脚の衝突回避骨を1本以上指定してください',
    'Skirt and leg bone mappings overlap': 'スカート骨と脚骨の割当てが重複しています',
    'Map a body mesh or collider collection': 'ボディメッシュまたは衝突対象コレクションを指定してください',
    'Collider is not a mesh: ': '衝突対象がメッシュではありません: ',
    'Legacy bone distance is outside the supported range': '旧ボーン距離の設定値が範囲外です',
    'Unsupported cloth setup route': '未対応のクロス設定経路です',
    'Saved mapping differs from the selected mapping': '保存済みの割当てと現在の選択が異なります',
    'Mapped cloth modifier is missing': '割り当てたクロスモディファイアがありません',
    'Mapped waistband pin group is missing': '腰の固定グループがありません',
    'Cloth does not use the mapped waistband pin': 'クロスが腰の固定グループを使用していません',
    'Cloth viewport state disagrees with saved mode': 'クロス表示状態が保存した方式と一致しません',
    'Cloth modifier runs before an armature modifier': 'クロスモディファイアがアーマチュアより前にあります',
    'Leg collision avoidance is missing: ': '脚の衝突回避制約がありません: ',
    'Leg collision avoidance state is invalid: ': '脚の衝突回避制約が不正です: ',
    'Leg clearance is below the mapped minimum: ': '脚との間隔が指定した最小距離を下回っています: ',
    'Collider has no Collision modifier: ': '衝突対象に 衝突モディファイアがありません: ',
    'A cloth modifier occupies the Smart Cloth skirt name': 'スカート用の名前を既存クロスモディファイアが使用しています',
    'An existing cloth modifier would be duplicated': '既存クロスモディファイアと重複します',
    'The garment has duplicate cloth modifiers': '衣装にクロスモディファイアが重複しています',
    'A vertex group occupies the Smart Cloth skirt pin name': 'スカート用の名前を既存頂点グループが使用しています',
    'Simply Cloth Studio public Create Cloth operator is unavailable': 'Simply Cloth Studio の公開クロス作成操作を利用できません',
    'Apply and save the skirt mapping first': '先にスカートの割当てを適用して保存してください',
    'Cloth cache is baked; free or rebake it before switching to cloth': 'クロスキャッシュはベイク済みです。クロス方式へ切り替える前に解除または再ベイクしてください',
    'Selected support armature or bone binding is missing or changed': '選択した支持アーマチュアまたは支持ボーンへの固定が失われたか変更されています',
}


def _issue_match(text: str):
    # Longest key wins, so 'Select a mesh garment' is not read as 'Select a mesh'.
    return max((source for source in _ISSUE_JA if text.startswith(source)), key=len, default=None)


def _failure_detail(detail, japanese: bool) -> str:
    # Text after a failure wrapper is an exception. An operator's own report may
    # be shown; Python internals may not. Empty means there is nothing to add.
    text = str(detail or '').strip()
    if text.startswith('Error: '):
        text = text[len('Error: '):].strip()
    text = text.split('\n', 1)[0].strip()
    if 'bpy.ops.' in text or 'poll()' in text:
        return '選択とモードを確かめてください。' if japanese else 'Check the selection and mode.'
    if not text or text.startswith(('Python:', 'Traceback')):
        return ''
    if japanese:
        if _issue_match(text):
            return localize_issues(text, True)
        return text if any(ord(ch) >= 0x3040 for ch in text) else ''
    return text


def localize_issues(message: str, japanese: bool) -> str:
    text = str(message or '')
    if not japanese:
        wrapper = next((source for source in _ISSUE_WRAPPERS_JA if text.startswith(source)), None)
        if wrapper is None:
            return _failure_detail(text, False) or 'The command could not be completed.'
        detail = _failure_detail(text[len(wrapper):], False)
        return wrapper + detail if detail else wrapper.rstrip(': ') + '.'
    parts = []
    while text:
        wrapper = next((source for source in _ISSUE_WRAPPERS_JA if text.startswith(source)), None)
        if wrapper is not None:
            detail = _failure_detail(text[len(wrapper):], True)
            parts.append(_ISSUE_WRAPPERS_JA[wrapper] + detail if detail else _ISSUE_WRAPPERS_JA[wrapper].rstrip(': ') + '。')
            break
        # Keys may hold '; ' themselves, so match before splitting the joined list.
        source = _issue_match(text)
        rest = text[len(source):] if source else text
        item, _separator, text = rest.partition('; ')
        parts.append(_ISSUE_JA[source] + item if source else '処理を確認してください')
    return '；'.join(parts)


# ---------------------------------------------------------------------------
# 2.10.4 -- adopt an EXISTING cloth into a Simply Cloth Studio stack.
#
# A rig built elsewhere (SmartRig, a hand-made file) already carries one Cloth
# modifier with tuned values, a pin group, a collider collection and usually a
# driver that switches it from a rig custom property. Rebuilding that by hand
# for every character is what this replaces: the existing Cloth is recorded in
# full on the garment, removed, and Simply Cloth Studio's public Create Cloth
# builds its stack; the recorded values are then written back through SCS's own
# sliders and read back. Nothing is applied, the mesh is not edited, and the
# record is enough to put the original Cloth (and its drivers) back.
#
# Rules carried over from the design law: public operators and public
# properties only, every SCS Object property is written with the garment
# active and then read back, nothing created here is named ``Simply*``, and
# there is no handler, timer or modal.
# ---------------------------------------------------------------------------
REPLACED_CLOTH_KEY = 'smart_cloth_suite_replaced_cloth_v1'
BAKE_CHECK_KEY = '_smart_cloth_suite_bake_check_v1'
SIMPLY_CLOTH = 'SimplyCloth'
SIMPLY_PIN = 'SimplyPin'
SIMPLY_PIN_LAYER = 'SC_SkirtPinLayer'
SIMPLY_BACKUP_SUFFIX = '_SC_Backup'
SIMPLY_FRONT = ('SimplySub', 'SimplyDeform', SIMPLY_CLOTH)
SIMPLY_HIDDEN = ('SimplySub', 'SimplyDeform', 'SimplyEdgeSplit', 'SimplyWeld',
                 'SimplySmooth', 'SimplySolidify', 'SimplySubsurf', 'SimplyShrink')
ROUTE_ADOPTED = 'SIMPLY_ADOPTED'
_SCALAR_TYPES = {'BOOLEAN', 'INT', 'FLOAT', 'ENUM', 'STRING'}
_ID_COLLECTIONS = {'OBJECT': 'objects', 'MESH': 'meshes', 'ARMATURE': 'armatures',
                   'SCENE': 'scenes', 'MATERIAL': 'materials', 'KEY': 'shape_keys',
                   'COLLECTION': 'collections', 'WORLD': 'worlds', 'TEXT': 'texts'}


def _rna_values(struct) -> dict:
    """Every writable scalar/array/enum value of an RNA struct, JSON-safe."""
    values = {}
    if struct is None:
        return values
    for prop in struct.bl_rna.properties:
        if prop.identifier == 'rna_type' or prop.is_readonly or prop.type not in _SCALAR_TYPES:
            continue
        try:
            value = getattr(struct, prop.identifier)
        except Exception:
            continue
        if isinstance(value, (set, frozenset)):
            value = sorted(value)
        elif not isinstance(value, (str, bool, int, float)):
            try:
                value = [v for v in value]
            except TypeError:
                continue
        values[prop.identifier] = value
    return values


def _apply_rna_values(struct, values: dict) -> list[str]:
    """Write recorded values back; returns the names that could not be written."""
    failed = []
    if struct is None:
        return list(values)
    for name, value in values.items():
        prop = struct.bl_rna.properties.get(name)
        if prop is None or prop.is_readonly:
            failed.append(name)
            continue
        try:
            if prop.type == 'ENUM' and getattr(prop, 'is_enum_flag', False):
                value = set(value)
            elif isinstance(value, list):
                value = tuple(value)
            if getattr(struct, name) != value:
                setattr(struct, name, value)
        except Exception:
            failed.append(name)
    return failed


_CACHE_FIELDS = ('use_disk_cache', 'name', 'filepath', 'use_external', 'use_library_path',
                 'frame_step', 'index')


def _cache_values(cache) -> dict:
    values = {}
    for name in _CACHE_FIELDS:
        try:
            values[name] = getattr(cache, name)
        except Exception:
            pass
    return values


def _driver_rows(obj, prefix: str) -> list[dict]:
    """Serialize every driver whose path starts with ``prefix``."""
    rows = []
    ad = getattr(obj, 'animation_data', None)
    if ad is None:
        return rows
    for fcurve in ad.drivers:
        if not fcurve.data_path.startswith(prefix):
            continue
        driver = fcurve.driver
        variables = []
        for var in driver.variables:
            targets = []
            for target in var.targets:
                targets.append({
                    'id_type': str(target.id_type),
                    'id': target.id.name if target.id is not None else '',
                    'data_path': str(target.data_path),
                    'bone_target': str(target.bone_target),
                    'transform_type': str(target.transform_type),
                    'transform_space': str(target.transform_space),
                    'rotation_mode': str(target.rotation_mode),
                })
            variables.append({'name': var.name, 'type': str(var.type), 'targets': targets})
        rows.append({'suffix': fcurve.data_path[len(prefix):], 'index': int(fcurve.array_index),
                     'type': str(driver.type), 'expression': str(driver.expression),
                     'use_self': bool(driver.use_self), 'variables': variables})
    return rows


def _id_from(id_type: str, name: str):
    if not name:
        return None
    data = getattr(bpy.data, _ID_COLLECTIONS.get(str(id_type), ''), None)
    return data.get(name) if data is not None else None


def _build_drivers(obj, modifier, rows) -> int:
    made = 0
    for row in rows:
        path = 'modifiers["%s"]%s' % (modifier.name, row['suffix'])
        # The recorded index is passed for an array property: without it
        # driver_add returns a list of F-curves (one per element). A non-array
        # property refuses an explicit index, so it takes the plain form.
        index = int(row.get('index', 0))
        try:
            fcurve = obj.driver_add(path, index)
        except Exception:
            try:
                fcurve = obj.driver_add(path)
            except Exception:
                continue
        if isinstance(fcurve, (list, tuple)):
            if not 0 <= index < len(fcurve):
                continue
            fcurve = fcurve[index]
        driver = fcurve.driver
        driver.type = row['type']
        while driver.variables:
            driver.variables.remove(driver.variables[0])
        for spec in row['variables']:
            var = driver.variables.new()
            var.name = spec['name']
            var.type = spec['type']
            for target, tspec in zip(var.targets, spec['targets']):
                if spec['type'] == 'SINGLE_PROP':
                    try:
                        target.id_type = tspec['id_type']
                    except Exception:
                        pass
                ident = _id_from(tspec['id_type'] if spec['type'] == 'SINGLE_PROP' else 'OBJECT',
                                 tspec['id'])
                if ident is not None:
                    target.id = ident
                for key in ('data_path', 'bone_target', 'transform_type',
                            'transform_space', 'rotation_mode'):
                    try:
                        if getattr(target, key) != tspec[key]:
                            setattr(target, key, tspec[key])
                    except Exception:
                        pass
        driver.expression = row['expression']
        driver.use_self = bool(row.get('use_self', False))
        made += 1
    return made


def _remove_drivers(obj, prefix: str) -> int:
    ad = getattr(obj, 'animation_data', None)
    if ad is None:
        return 0
    removed = 0
    for fcurve in list(ad.drivers):
        if fcurve.data_path.startswith(prefix):
            ad.drivers.remove(fcurve)
            removed += 1
    return removed


def _switch_from_rows(rows) -> dict:
    """A show_viewport driver reading one custom property is a mode switch."""
    for row in rows:
        if row['suffix'] != '.show_viewport' or len(row['variables']) != 1:
            continue
        spec = row['variables'][0]
        if spec['type'] != 'SINGLE_PROP' or not spec['targets']:
            continue
        target = spec['targets'][0]
        path = target['data_path']
        if not (path.startswith('["') and path.endswith('"]')):
            continue
        owner = _id_from(target['id_type'], target['id'])
        if owner is None:
            continue
        return {'object': owner.name, 'id_type': target['id_type'], 'property': path[2:-2]}
    return {}


def _remove_scs_keys(obj, had_action: bool) -> list[str]:
    """Remove the keys Simply Cloth Studio puts on its own modifiers.

    Create Cloth keys effector gravity -0.5 -> 1.0 over frames 0..6 on
    SimplyCloth and, when a SimplyCollision exists in the scene, SimplyShrink
    show_viewport True -> False over frames 1..2. Left in place, the first
    would float the cloth for six frames and the second would re-show the
    hidden SimplyShrink on every frame change. Every F-curve on a
    ``modifiers["Simply...`` path is removed; when the garment had no Action of
    its own before, the Action SCS created is unassigned once it is empty.
    """
    ad = getattr(obj, 'animation_data', None)
    action = getattr(ad, 'action', None) if ad is not None else None
    if action is None:
        return []
    from bpy_extras import anim_utils
    bag = anim_utils.action_get_channelbag_for_slot(action, ad.action_slot)
    removed = []
    if bag is not None:
        for fcurve in list(bag.fcurves):
            if fcurve.data_path.startswith('modifiers["Simply'):
                removed.append('%s[%d]' % (fcurve.data_path, fcurve.array_index))
                bag.fcurves.remove(fcurve)
    if not had_action and (bag is None or not len(bag.fcurves)):
        ad.action = None
        if action.users == 0:
            bpy.data.actions.remove(action)
    return removed


def adoption_target(settings, context):
    garment = getattr(settings, 'skirt_garment', None) if settings is not None else None
    if garment is None:
        garment = getattr(context, 'active_object', None)
    return garment if getattr(garment, 'type', '') == 'MESH' else None


def _cloths(garment) -> list:
    return [m for m in garment.modifiers if m.type == 'CLOTH']


def adoption_state(garment) -> dict:
    """Read-only state for the panel: who drives the cloth and which switch."""
    if garment is None or getattr(garment, 'type', '') != 'MESH':
        return {'kind': 'NONE', 'switch': '', 'adopted': False, 'object': ''}
    simply = garment.modifiers.get(SIMPLY_CLOTH)
    cloths = _cloths(garment)
    if simply is not None and simply.type == 'CLOTH':
        kind, cloth = 'SIMPLY', simply
    elif cloths:
        kind, cloth = 'OWN', cloths[0]
    else:
        kind, cloth = 'NONE', None
    profile = read_profile(garment)
    switch = ''
    if profile.get('switch_property'):
        switch = '%s["%s"]' % (profile.get('switch_object', ''), profile.get('switch_property', ''))
    elif cloth is not None:
        found = _switch_from_rows(_driver_rows(garment, 'modifiers["%s"]' % cloth.name))
        if found:
            switch = '%s["%s"]' % (found['object'], found['property'])
    return {'kind': kind, 'switch': switch, 'object': garment.name,
            'adopted': REPLACED_CLOTH_KEY in garment.keys()}


def _activate(context, obj):
    view_layer = context.view_layer
    try:
        hidden = bool(obj.hide_get())
    except Exception:
        hidden = False
    state = (view_layer.objects.active, [o for o in view_layer.objects if o.select_get()],
             obj, hidden)
    for other in state[1]:
        other.select_set(False)
    if hidden:
        try:
            obj.hide_set(False)
        except Exception:
            pass
    obj.select_set(True)
    view_layer.objects.active = obj
    return state


def _restore_active(context, state) -> None:
    view_layer = context.view_layer
    for other in view_layer.objects:
        try:
            wanted = other in state[1]
            if other.select_get() != wanted:
                other.select_set(wanted)
        except Exception:
            pass
    view_layer.objects.active = state[0]
    obj, hidden = state[2], state[3]
    if hidden:
        try:
            obj.hide_set(True)
        except Exception:
            pass


def _probe_cloth_value(context, garment, modifier, switch: dict) -> tuple:
    """Find which property value turns the copied driver ON; restore the value."""
    owner = _id_from(switch['id_type'], switch['object'])
    key = switch['property']
    if owner is None or key not in owner.keys():
        return None, None
    original = owner[key]
    cloth_value = None
    candidates = [original] + [v for v in (0, 1, 2, 3, 4) if v != original]
    try:
        for value in candidates:
            owner[key] = value
            owner.update_tag()
            garment.update_tag()
            context.view_layer.update()
            if bool(modifier.show_viewport):
                cloth_value = value
                break
    finally:
        owner[key] = original
        owner.update_tag()
        garment.update_tag()
        context.view_layer.update()
    if cloth_value is None:
        return None, None
    bone_value = original if original != cloth_value else (0 if cloth_value != 0 else 1)
    return cloth_value, bone_value


def _same(got, want) -> bool:
    if isinstance(want, (bool, str)) or want is None:
        return got == want
    return abs(float(got) - float(want)) <= 1.0e-4 * max(1.0, abs(float(want)))


def _write_sliders(context, garment, cloth, wanted: dict) -> tuple[dict, list, list]:
    """Write through SCS's public sliders with the garment active; read back."""
    sliders = (
        ('weight_slider', 'mass', wanted['mass']),
        ('stiffness_slider', 'tension', wanted['tension'] / 0.45),
        ('wrinkle_slider', 'bending', abs(wanted['bending'] - 10.0) / 9.99 * 100.0),
        ('quality_steps_slider', 'quality', int(wanted['quality'])),
        ('collision_quality_slider', 'collision_quality', int(wanted['collision_quality'])),
        ('objectCollisionDistance_slider', 'distance_min', wanted['distance_min']),
        ('self_collision', 'self', bool(wanted['self'])),
    )
    written, missing = {}, []
    state = _activate(context, garment)
    try:
        with context.temp_override(object=garment, active_object=garment,
                                   selected_objects=[garment], selected_editable_objects=[garment]):
            for name, _key, value in sliders:
                if not hasattr(garment, name):
                    missing.append(name)
                    continue
                try:
                    setattr(garment, name, value)
                    written[name] = getattr(garment, name)
                except Exception:
                    missing.append(name)
    finally:
        _restore_active(context, state)
    s, c = cloth.settings, cloth.collision_settings
    direct = []
    # A value outside a slider's range (or a slider this SCS build lacks) is
    # written straight into the modifier and reported, so the physics matches
    # the original even where SCS's display cannot show it.
    for key, attr, owner in (('mass', 'mass', s), ('tension', 'tension_stiffness', s),
                             ('bending', 'bending_stiffness', s), ('quality', 'quality', s),
                             ('collision_quality', 'collision_quality', c),
                             ('distance_min', 'distance_min', c),
                             ('self', 'use_self_collision', c)):
        want = wanted[key]
        if not _same(getattr(owner, attr), want):
            setattr(owner, attr, type(getattr(owner, attr))(want))
            direct.append(key)
    return written, missing, direct


# Values Create Cloth or the stiffness slider change and no slider can set back:
# the slider writes tension, compression AND shear to one value, Create Cloth
# turns sewing on and halves the time scale.
_RESTORE_SETTINGS = ('compression_stiffness', 'shear_stiffness', 'time_scale', 'air_damping',
                     'pin_stiffness', 'use_sewing_springs', 'sewing_force_max', 'bending_model',
                     'use_internal_springs', 'use_pressure', 'shrink_min', 'use_dynamic_mesh',
                     'tension_damping', 'compression_damping', 'shear_damping', 'bending_damping',
                     'gravity', 'vertex_group_bending', 'vertex_group_shrink')
_RESTORE_COLLISION = ('self_distance_min', 'self_friction', 'friction', 'impulse_clamp',
                      'self_impulse_clamp', 'distance_repel', 'use_collision',
                      'vertex_group_self_collisions', 'vertex_group_object_collisions')


def adopt_switch_to_simply(garment, context) -> tuple[dict | None, str]:
    """Replace the garment's existing Cloth with a Simply Cloth Studio stack.

    ``(report, error)``. A second call changes nothing. Without Simply Cloth
    Studio, or without exactly one existing Cloth, nothing is changed.
    """
    from . import integration
    if garment is None or getattr(garment, 'type', '') != 'MESH':
        return None, 'Select a mesh garment'
    if not integration.operator_available('object.create_cloth'):
        return None, 'Simply Cloth Studio public Create Cloth operator is unavailable'
    simply = garment.modifiers.get(SIMPLY_CLOTH)
    if simply is not None and simply.type == 'CLOTH':
        return {'already': True, 'object': garment.name, 'changed': False}, ''
    cloths = _cloths(garment)
    if not cloths:
        return None, 'The garment has no Cloth modifier to adopt'
    if len(cloths) > 1:
        return None, 'The garment has duplicate cloth modifiers'
    if garment.mode != 'OBJECT':
        return None, 'Switch the garment to Object Mode first'
    if garment.data.users > 1:
        return None, 'The garment mesh is shared by other objects'
    if bool(cloths[0].point_cache.is_baked):
        return None, 'The existing cloth cache is baked; free the bake before moving the cloth'
    scene = context.scene
    old = cloths[0]
    s, c = old.settings, old.collision_settings
    prefix = 'modifiers["%s"]' % old.name
    drivers = _driver_rows(garment, prefix)
    record = {
        'schema': 1, 'name': old.name, 'index': list(garment.modifiers).index(old),
        'show_viewport': bool(old.show_viewport), 'show_render': bool(old.show_render),
        'settings': _rna_values(s), 'collision': _rna_values(c),
        'effector': _rna_values(s.effector_weights),
        'effector_collection': s.effector_weights.collection.name if s.effector_weights.collection else '',
        'collection': c.collection.name if c.collection else '',
        'shape_target': s.rest_shape_key.name if getattr(s, 'rest_shape_key', None) else '',
        'frame_start': int(old.point_cache.frame_start), 'frame_end': int(old.point_cache.frame_end),
        'point_cache': _cache_values(old.point_cache),
        'drivers': drivers,
        'profile_before': json.dumps(read_profile(garment), ensure_ascii=False, default=str),
    }
    switch = _switch_from_rows(drivers)
    pin_name = str(s.vertex_group_mass or '')
    before_groups = {g.name for g in garment.vertex_groups}
    before_mods = {m.name for m in garment.modifiers}
    before_objects = {o.as_pointer() for o in bpy.data.objects}
    before_slider = [v.get('name', '') for v in getattr(garment, 'vertex_slider', ())]
    smooth = [p.use_smooth for p in garment.data.polygons]
    frame = scene.frame_current
    frame_range = (scene.frame_start, scene.frame_end)
    had_action = bool(garment.animation_data and garment.animation_data.action)

    def undo_partial(message):
        _rebuild_from_record(garment, record,
                             [m.name for m in garment.modifiers if m.name not in before_mods],
                             [g.name for g in garment.vertex_groups if g.name not in before_groups])
        for other in list(bpy.data.objects):
            if other.as_pointer() not in before_objects and other.name.endswith(SIMPLY_BACKUP_SUFFIX):
                bpy.data.objects.remove(other)
        if REPLACED_CLOTH_KEY in garment.keys():
            del garment[REPLACED_CLOTH_KEY]
        scene.frame_start, scene.frame_end = frame_range
        scene.frame_set(frame)
        return None, message

    # 1. take the old Cloth out (its full record stays on the garment)
    _remove_drivers(garment, prefix)
    garment.modifiers.remove(old)
    garment[REPLACED_CLOTH_KEY] = json.dumps(record, ensure_ascii=False)
    state = _activate(context, garment)
    try:
        with context.temp_override(object=garment, active_object=garment,
                                   selected_objects=[garment], selected_editable_objects=[garment]):
            result = integration.call_external_operator(
                'object.create_cloth', context, mode='CREATECLOTH', modifiers_handling='DO_NOTHING')
            if garment.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
    except Exception as exc:
        _restore_active(context, state)
        return undo_partial('Simply Cloth Studio Create Cloth failed: ' + str(exc))
    _restore_active(context, state)
    if 'FINISHED' not in result:
        return undo_partial('Simply Cloth Studio Create Cloth did not finish')
    cloth = garment.modifiers.get(SIMPLY_CLOTH)
    if cloth is None or cloth.type != 'CLOTH':
        return undo_partial('Simply Cloth Studio did not create exactly one cloth modifier on the mapped garment')
    report = {'object': garment.name, 'replaced': record['name'], 'already': False, 'changed': True}
    # 2. undo the side effects SCS leaves behind: hidden backup copy, smooth
    #    shading of the source mesh, scene frame range, gravity keys
    removed_backup = []
    for other in list(bpy.data.objects):
        if other.as_pointer() in before_objects or not other.name.endswith(SIMPLY_BACKUP_SUFFIX):
            continue
        mesh = other.data
        removed_backup.append(other.name)
        bpy.data.objects.remove(other)
        if mesh is not None and mesh.users == 0:
            bpy.data.meshes.remove(mesh)
    if [p.use_smooth for p in garment.data.polygons] != smooth:
        garment.data.polygons.foreach_set('use_smooth', smooth)
        garment.data.update()
    scene.frame_start, scene.frame_end = frame_range
    report['removed_backup'] = removed_backup
    removed_keys = _remove_scs_keys(garment, had_action)
    report['scs_keys_removed'] = removed_keys
    report['gravity_keys_removed'] = sum(1 for k in removed_keys if 'gravity' in k)
    # 3. order: SimplySub / SimplyDeform / SimplyCloth right after the last armature
    armatures = [i for i, m in enumerate(garment.modifiers) if m.type == 'ARMATURE']
    position = (max(armatures) + 1) if armatures else int(record['index'])
    for name in SIMPLY_FRONT:
        mod = garment.modifiers.get(name)
        if mod is None:
            continue
        current = list(garment.modifiers).index(mod)
        target = min(position, len(garment.modifiers) - 1)
        if current != target:
            garment.modifiers.move(current, target)
        position = list(garment.modifiers).index(mod) + 1
    for name in SIMPLY_HIDDEN:
        mod = garment.modifiers.get(name)
        if mod is not None:
            mod.show_viewport = mod.show_render = False
    # 4. physics: SCS sliders first, then the values no slider owns
    old_s, old_c = record['settings'], record['collision']
    wanted = {'mass': old_s.get('mass', 0.3), 'tension': old_s.get('tension_stiffness', 15.0),
              'bending': old_s.get('bending_stiffness', 0.5), 'quality': old_s.get('quality', 5),
              'collision_quality': old_c.get('collision_quality', 2),
              'distance_min': old_c.get('distance_min', 0.015),
              'self': bool(old_c.get('use_self_collision', False))}
    written, missing, direct = _write_sliders(context, garment, cloth, wanted)
    ns, nc = cloth.settings, cloth.collision_settings
    not_restored = _apply_rna_values(ns, {k: old_s[k] for k in _RESTORE_SETTINGS if k in old_s})
    not_restored += _apply_rna_values(nc, {k: old_c[k] for k in _RESTORE_COLLISION if k in old_c})
    not_restored += _apply_rna_values(ns.effector_weights, record['effector'])
    nc.collection = bpy.data.collections.get(record['collection']) if record['collection'] else None
    cloth.point_cache.frame_start = record['frame_start']
    cloth.point_cache.frame_end = record['frame_end']
    # 5. pins: the old pin weights go into SimplyPin, held as one SCS pin layer
    pin = _adopt_pin(context, garment, pin_name)
    if garment.vertex_groups.get(SIMPLY_PIN) is not None and pin['vertices']:
        ns.vertex_group_mass = SIMPLY_PIN
    elif pin_name and garment.vertex_groups.get(pin_name) is not None:
        ns.vertex_group_mass = pin_name
    # 6. the switch: copy the drivers; without any, set_adopted_mode() owns it
    switch_report = {}
    show_rows = [row for row in drivers if row['suffix'] in ('.show_viewport', '.show_render')]
    if show_rows:
        _build_drivers(garment, cloth, show_rows)
    else:
        cloth.show_viewport = record['show_viewport']
        cloth.show_render = record['show_render']
    if switch:
        cloth_value, bone_value = _probe_cloth_value(context, garment, cloth, switch)
        switch_report = dict(switch, cloth_value=cloth_value, bone_value=bone_value)
    # 7. read every value back against the record
    back = {'mass': ns.mass, 'tension': ns.tension_stiffness,
            'compression': ns.compression_stiffness, 'shear': ns.shear_stiffness,
            'bending': ns.bending_stiffness, 'quality': ns.quality, 'time_scale': ns.time_scale,
            'air_damping': ns.air_damping, 'pin_stiffness': ns.pin_stiffness,
            'sewing': bool(ns.use_sewing_springs), 'gravity': ns.effector_weights.gravity,
            'collision_quality': nc.collision_quality, 'distance_min': nc.distance_min,
            'self': bool(nc.use_self_collision), 'pin_group': ns.vertex_group_mass,
            'collection': nc.collection.name if nc.collection else ''}
    expect = {'mass': old_s.get('mass'), 'tension': old_s.get('tension_stiffness'),
              'compression': old_s.get('compression_stiffness'), 'shear': old_s.get('shear_stiffness'),
              'bending': old_s.get('bending_stiffness'), 'quality': old_s.get('quality'),
              'time_scale': old_s.get('time_scale'), 'air_damping': old_s.get('air_damping'),
              'pin_stiffness': old_s.get('pin_stiffness'),
              'sewing': bool(old_s.get('use_sewing_springs', False)),
              'gravity': record['effector'].get('gravity', 1.0),
              'collision_quality': old_c.get('collision_quality'),
              'distance_min': old_c.get('distance_min'),
              'self': bool(old_c.get('use_self_collision', False)),
              'collection': record['collection']}
    drift = [[key, want, back[key]] for key, want in expect.items()
             if want is not None and not _same(back[key], want)]
    # 8. what this adoption created, so revert removes exactly that
    record['created_modifiers'] = [m.name for m in garment.modifiers if m.name not in before_mods]
    record['created_groups'] = [g.name for g in garment.vertex_groups if g.name not in before_groups]
    record['created_slider'] = [v.get('name', '') for v in getattr(garment, 'vertex_slider', ())
                                if v.get('name', '') not in before_slider]
    record['had_action'] = had_action
    record['scs_keys_removed'] = removed_keys
    garment[REPLACED_CLOTH_KEY] = json.dumps(record, ensure_ascii=False)
    armature = _armature_of(garment)
    profile = read_profile(garment)
    fields = {'route': 'SIMPLY', 'adopted': ROUTE_ADOPTED, 'cloth_modifier': cloth.name,
              'pin_group': ns.vertex_group_mass,
              'armature': armature.name if armature else str(profile.get('armature', '')),
              'colliders_collection': record['collection'], 'replaced': record['name']}
    if switch_report.get('cloth_value') is not None:
        fields.update(switch_object=switch_report['object'], switch_id_type=switch_report['id_type'],
                      switch_property=switch_report['property'],
                      switch_cloth_value=switch_report['cloth_value'],
                      switch_bone_value=switch_report['bone_value'])
        fields['mode'] = adopted_mode_from(switch_report)
    else:
        fields['mode'] = MODE_CLOTH if cloth.show_viewport else MODE_BONE
    if profile_schema(profile) == 3:
        fields['external_added_json'] = json.dumps(
            [{'name': n, 'type': garment.modifiers[n].type,
              'show_viewport': bool(garment.modifiers[n].show_viewport),
              'show_render': bool(garment.modifiers[n].show_render)}
             for n in record['created_modifiers'] if n != cloth.name and n in garment.modifiers],
            ensure_ascii=False)
    write_profile(garment, **fields)
    scene.frame_set(frame)
    report.update({
        'stack': [[m.name, m.type, bool(m.show_viewport), bool(m.show_render)] for m in garment.modifiers],
        'sliders_written': written, 'sliders_missing': missing, 'direct_writes': direct,
        'not_restored': not_restored, 'readback': back, 'readback_drift': drift,
        'pin': pin, 'switch': switch_report, 'drivers_copied': len(show_rows),
        'collision_collection': back['collection'], 'frame_restored': scene.frame_current,
    })
    return report, ''


def adopted_mode_from(switch: dict) -> str:
    owner = _id_from(switch.get('id_type', 'OBJECT'), switch.get('object', ''))
    try:
        return MODE_CLOTH if owner[switch['property']] == switch['cloth_value'] else MODE_BONE
    except Exception:
        return MODE_BONE


def _adopt_pin(context, garment, source_name: str) -> dict:
    """Copy the old pin weights into SimplyPin and hold them as an SCS pin layer.

    The layer is SCS's own ``Object.vertex_slider`` entry backed by a vertex
    group named ``SC_SkirtPinLayer`` (never ``Simply*``). SCS's public
    ``object.create_pin_layers(mode='MERGEWEIGHTS')`` then recomputes
    SimplyPin from the layers, and the result is read back.
    """
    from . import integration
    out = {'source': source_name, 'vertices': 0, 'layer': '', 'layer_reason': ''}
    src = garment.vertex_groups.get(source_name) if source_name else None
    dst = garment.vertex_groups.get(SIMPLY_PIN)
    if dst is None:
        out['layer_reason'] = 'SimplyPin was not created'
        return out
    weights = {}
    if src is not None:
        gi = src.index
        for vertex in garment.data.vertices:
            for entry in vertex.groups:
                if entry.group == gi and entry.weight > 0.0:
                    weights[vertex.index] = entry.weight
    dst.remove([v.index for v in garment.data.vertices])
    for index, weight in weights.items():
        dst.add([index], weight, 'REPLACE')
    out['vertices'] = len(weights)
    if not weights:
        out['layer_reason'] = 'the original cloth had no weighted pin group'
        return out
    if not hasattr(garment, 'vertex_slider'):
        out['layer_reason'] = 'this Simply Cloth Studio build has no Object.vertex_slider'
        return out
    if not integration.operator_available('object.create_pin_layers'):
        out['layer_reason'] = 'object.create_pin_layers is unavailable'
        return out
    layer = garment.vertex_groups.get(SIMPLY_PIN_LAYER) or garment.vertex_groups.new(name=SIMPLY_PIN_LAYER)
    layer.remove([v.index for v in garment.data.vertices])
    for index, weight in weights.items():
        layer.add([index], weight, 'REPLACE')
    state = _activate(context, garment)
    try:
        with context.temp_override(object=garment, active_object=garment,
                                   selected_objects=[garment], selected_editable_objects=[garment]):
            entry = next((v for v in garment.vertex_slider
                          if v.get('name') == SIMPLY_PIN_LAYER), None)
            if entry is None:
                entry = garment.vertex_slider.add()
                # SCS's name getter raises on a fresh entry (its storage key is
                # still unset) and its setter reads the getter first, so the
                # storage key the getter reads is written directly. The vertex
                # group already carries this name, which is all the setter adds.
                entry['name'] = SIMPLY_PIN_LAYER
            entry.hide = False
            entry.slider_value = 1.0
            integration.call_external_operator('object.create_pin_layers', context,
                                               mode='MERGEWEIGHTS', name=SIMPLY_PIN_LAYER)
    except Exception as exc:
        out['layer_reason'] = 'pin layer merge failed: %s' % exc
    finally:
        _restore_active(context, state)
    gi = dst.index
    seen = {}
    for vertex in garment.data.vertices:
        for entry in vertex.groups:
            if entry.group == gi:
                seen[vertex.index] = entry.weight
    worst = max((abs(seen.get(i, 0.0) - w) for i, w in weights.items()), default=0.0)
    extra = sum(1 for i, w in seen.items() if i not in weights and w > 0.0)
    out['merge_max_error'] = round(float(worst), 6)
    out['merge_extra_vertices'] = extra
    if not out['layer_reason']:
        out['layer'] = SIMPLY_PIN_LAYER
        if worst > 1.0e-5 or extra:
            out['layer_reason'] = 'merged SimplyPin differs from the source weights'
    return out


def _rebuild_from_record(garment, record: dict, created_mods=(), created_groups=()):
    for name in list(created_mods):
        _remove_drivers(garment, 'modifiers["%s"]' % name)
        mod = garment.modifiers.get(name)
        if mod is not None:
            garment.modifiers.remove(mod)
    for name in list(created_groups):
        group = garment.vertex_groups.get(name)
        if group is not None:
            garment.vertex_groups.remove(group)
    cloth = garment.modifiers.new(record['name'], 'CLOTH')
    target = min(int(record['index']), len(garment.modifiers) - 1)
    if list(garment.modifiers).index(cloth) != target:
        garment.modifiers.move(list(garment.modifiers).index(cloth), target)
    _apply_rna_values(cloth.settings, record['settings'])
    _apply_rna_values(cloth.collision_settings, record['collision'])
    _apply_rna_values(cloth.settings.effector_weights, record['effector'])
    if record.get('effector_collection'):
        cloth.settings.effector_weights.collection = bpy.data.collections.get(record['effector_collection'])
    cloth.collision_settings.collection = (bpy.data.collections.get(record['collection'])
                                           if record['collection'] else None)
    if record.get('shape_target') and garment.data.shape_keys:
        cloth.settings.rest_shape_key = garment.data.shape_keys.key_blocks.get(record['shape_target'])
    cloth.point_cache.frame_start = int(record['frame_start'])
    cloth.point_cache.frame_end = int(record['frame_end'])
    _apply_rna_values(cloth.point_cache, dict(record.get('point_cache') or {}))
    cloth.show_viewport = bool(record.get('show_viewport', True))
    cloth.show_render = bool(record.get('show_render', True))
    _build_drivers(garment, cloth, record.get('drivers', ()))
    return cloth


def revert_simply_adoption(garment, context=None) -> tuple[dict | None, str]:
    """Put the recorded original Cloth back and remove what adoption created."""
    if garment is None or getattr(garment, 'type', '') != 'MESH':
        return None, 'Select a mesh garment'
    raw = garment.get(REPLACED_CLOTH_KEY)
    if raw is None:
        return {'already': True, 'object': garment.name, 'changed': False}, ''
    try:
        record = json.loads(str(raw))
        if int(record.get('schema', 0)) != 1 or 'settings' not in record:
            raise ValueError
    except (TypeError, ValueError):
        return None, 'The saved original cloth record is invalid'
    if garment.mode != 'OBJECT':
        return None, 'Switch the garment to Object Mode first'
    created_mods = [n for n in record.get('created_modifiers', ()) if n.startswith('Simply')]
    if SIMPLY_CLOTH not in created_mods:
        created_mods.append(SIMPLY_CLOTH)
    created_groups = list(record.get('created_groups', ()))
    created_slider = set(record.get('created_slider', ()))
    slider = getattr(garment, 'vertex_slider', None)
    if slider is not None:
        for name in created_slider:
            for index, entry in enumerate(slider):
                if entry.get('name', '') == name:
                    slider.remove(index)
                    break
    elif created_slider and 'vertex_slider' in garment.keys():
        # Simply Cloth Studio is not loaded: its pin layers survive only as ID
        # properties, so the entries this adoption added are dropped there.
        kept = [entry.to_dict() for entry in garment['vertex_slider']
                if entry.get('name', '') not in created_slider]
        if kept:
            garment['vertex_slider'] = kept
        else:
            del garment['vertex_slider']
    keys_removed = _remove_scs_keys(garment, bool(record.get('had_action', True)))
    if getattr(garment, 'is_SimplyCloth', False):
        garment.is_SimplyCloth = False
    cloth = _rebuild_from_record(garment, record, created_mods, created_groups)
    try:
        before = json.loads(record.get('profile_before', '{}') or '{}')
    except ValueError:
        before = {}
    clear_profile(garment)
    if before:
        garment[PROFILE_KEY] = before
    del garment[REPLACED_CLOTH_KEY]
    if BAKE_CHECK_KEY in garment.keys():
        del garment[BAKE_CHECK_KEY]
    return {'object': garment.name, 'restored': cloth.name, 'changed': True,
            'removed_modifiers': created_mods, 'removed_groups': created_groups,
            'drivers': len(record.get('drivers', ())), 'scs_keys_removed': keys_removed,
            'stack': [m.name for m in garment.modifiers]}, ''


def _switch_owner(profile: dict):
    if not profile.get('switch_property'):
        return None
    return _id_from(str(profile.get('switch_id_type', 'OBJECT')), str(profile.get('switch_object', '')))


def adopted_mode(garment) -> str:
    profile = read_profile(garment)
    if _switch_owner(profile) is not None:
        return adopted_mode_from({'id_type': profile.get('switch_id_type', 'OBJECT'),
                                  'object': profile.get('switch_object', ''),
                                  'property': profile.get('switch_property', ''),
                                  'cloth_value': profile.get('switch_cloth_value')})
    return current_mode(garment)


def set_adopted_mode(garment, mode: str, context=None) -> tuple[dict | None, str]:
    """Switch an adopted garment: through its rig property, else the modifier."""
    if garment is None or getattr(garment, 'type', '') != 'MESH':
        return None, 'Select a mesh garment'
    profile = read_profile(garment)
    if profile.get('adopted') != ROUTE_ADOPTED:
        return None, 'The garment has not been adopted into Simply Cloth Studio'
    wanted = MODE_CLOTH if str(mode).upper() == MODE_CLOTH else MODE_BONE
    owner = _switch_owner(profile)
    if owner is not None:
        key = str(profile['switch_property'])
        owner[key] = profile['switch_cloth_value'] if wanted == MODE_CLOTH else profile['switch_bone_value']
        owner.update_tag()
        garment.update_tag()
        if context is not None:
            context.view_layer.update()
        write_profile(garment, mode=wanted)
        return {'object': garment.name, 'mode': wanted,
                'switch': '%s["%s"]' % (owner.name, key), 'value': owner[key]}, ''
    cloth = garment.modifiers.get(str(profile.get('cloth_modifier', SIMPLY_CLOTH)))
    if cloth is None or cloth.type != 'CLOTH':
        return None, 'Mapped cloth modifier is missing'
    on = wanted == MODE_CLOTH
    cloth.show_viewport = cloth.show_render = on
    write_profile(garment, mode=wanted)
    return {'object': garment.name, 'mode': wanted, 'switch': '', 'value': on}, ''


def _mesh_world(obj_eval):
    mesh = obj_eval.to_mesh()
    try:
        matrix = obj_eval.matrix_world.copy()
        return [matrix @ v.co for v in mesh.vertices]
    finally:
        obj_eval.to_mesh_clear()


def bake_and_check(garment, context, keep_bake: bool = True, samples: int = 48
                   ) -> tuple[dict | None, str]:
    """Bake the garment's cloth and count vertices inside its colliders.

    Baking goes through ``ptcache.bake('EXEC_DEFAULT')`` under a
    ``temp_override(point_cache=...)``; SCS's INVOKE-only animation manager is
    not used. The garment is switched to cloth for the bake and back to the
    mode it was in afterwards; the frame is restored.
    """
    from mathutils.bvhtree import BVHTree
    if garment is None or getattr(garment, 'type', '') != 'MESH':
        return None, 'Select a mesh garment'
    profile = read_profile(garment)
    cloth = garment.modifiers.get(str(profile.get('cloth_modifier', '') or SIMPLY_CLOTH))
    if cloth is None or cloth.type != 'CLOTH':
        cloths = _cloths(garment)
        cloth = cloths[0] if len(cloths) == 1 else None
    if cloth is None:
        return None, 'Mapped cloth modifier is missing'
    scene = context.scene
    frame = scene.frame_current
    adopted = profile.get('adopted') == ROUTE_ADOPTED
    mode_before = adopted_mode(garment) if adopted else ''
    vis_before = (bool(cloth.show_viewport), bool(cloth.show_render))
    driven = None
    if adopted:
        set_adopted_mode(garment, MODE_CLOTH, context)
    else:
        # A Cloth switched by a driver from a custom property (as SmartRig
        # builds it) is turned on through that property, then put back.
        found = _switch_from_rows(_driver_rows(garment, 'modifiers["%s"]' % cloth.name))
        if found:
            cloth_value, _bone = _probe_cloth_value(context, garment, cloth, found)
            owner = _id_from(found['id_type'], found['object'])
            if cloth_value is not None and owner is not None:
                driven = (owner, found['property'], owner[found['property']])
                owner[found['property']] = cloth_value
                owner.update_tag()
                garment.update_tag()
                context.view_layer.update()
    if not cloth.show_viewport:
        cloth.show_viewport = cloth.show_render = True
    cache = cloth.point_cache
    collection = cloth.collision_settings.collection
    if collection is not None:
        colliders = [o for o in collection.all_objects if o.type == 'MESH' and o is not garment]
    else:
        colliders = [o for o in scene.objects if o.type == 'MESH' and o is not garment
                     and any(m.type == 'COLLISION' for m in o.modifiers)]
    result = {'object': garment.name, 'cloth': cloth.name,
              'frames': [int(cache.frame_start), int(cache.frame_end)],
              'colliders': [o.name for o in colliders]}
    try:
        with context.temp_override(scene=scene, point_cache=cache):
            if cache.is_baked:
                bpy.ops.ptcache.free_bake('EXEC_DEFAULT')
            baked = bpy.ops.ptcache.bake('EXEC_DEFAULT', bake=True)
        result['baked'] = 'FINISHED' in baked and bool(cache.is_baked)
        start, end = int(cache.frame_start), int(cache.frame_end)
        step = max(1, (end - start) // max(1, int(samples) - 1))
        frames = list(range(start, end + 1, step))
        if frames[-1] != end:
            frames.append(end)
        worst = (0, start)
        lowest = None
        nan = 0
        rows = []
        for f in frames:
            scene.frame_set(f)
            depsgraph = context.evaluated_depsgraph_get()
            points = _mesh_world(garment.evaluated_get(depsgraph))
            nan += sum(1 for p in points if not all(math.isfinite(x) for x in p))
            if points:
                low = min(p.z for p in points)
                lowest = low if lowest is None else min(lowest, low)
            inside = 0
            for collider in colliders:
                ev = collider.evaluated_get(depsgraph)
                tree = BVHTree.FromObject(ev, depsgraph)
                inverse = ev.matrix_world.inverted()
                for p in points:
                    local = inverse @ p
                    hit = tree.find_nearest(local, 0.1)
                    if hit[0] is not None and (local - hit[0]).dot(hit[1]) < -1.0e-5:
                        inside += 1
            rows.append([f, inside])
            if inside > worst[0]:
                worst = (inside, f)
        result.update({'samples': rows, 'max_inside': worst[0], 'max_inside_frame': worst[1],
                       'lowest_z': round(float(lowest or 0.0), 6), 'nan': nan,
                       'vertices': len(garment.data.vertices)})
        if not keep_bake:
            with context.temp_override(scene=scene, point_cache=cache):
                bpy.ops.ptcache.free_bake('EXEC_DEFAULT')
        result['bake_kept'] = bool(cache.is_baked)
    except Exception as exc:
        return None, 'Bake failed: ' + str(exc)
    finally:
        if adopted:
            set_adopted_mode(garment, mode_before, context)
        if driven is not None:
            owner, key, value = driven
            owner[key] = value
            owner.update_tag()
            garment.update_tag()
            context.view_layer.update()
        if not _driver_rows(garment, 'modifiers["%s"].show' % cloth.name):
            cloth.show_viewport, cloth.show_render = vis_before
        scene.frame_set(frame)
    garment[BAKE_CHECK_KEY] = json.dumps(result, ensure_ascii=False)
    return result, ''


_ISSUE_JA.update({
    'Could not add collision to ': 'コリジョンを追加できませんでした: ',
    'Copied fabric helper has no animation data': '複製した布の補助物にアニメーションデータがありません',
    'Copied Action lacks the exact source slot': '複製したアクションに元のスロットがありません',
    'Fabric helper did not retain the source Action slot': '布の補助物が元のアクションのスロットを保てませんでした',
    'Action isolation changed the source or helper binding': 'アクションの切り離しで元または補助物の割り当てが変わりました',
    'External cloth rebound the source Action': '外部クロスが元のアクションを割り当て直しました',
    'External cloth Action has a foreign owner': '外部クロスのアクションを別の処理が管理しています',
    'External cloth rebound an unrelated existing Action': '外部クロスが無関係のアクションを割り当て直しました',
    'External cloth backup object delta is ambiguous': '外部クロスのバックアップのオブジェクトを特定できません',
    'External cloth backup has a foreign owner': '外部クロスのバックアップを別の処理が管理しています',
    'Copied pin weights are missing on the fabric helper': '布の補助物に複製したピンのウェイトがありません',
    'Split fabric helper has no vertices': '分けた布の補助物に頂点がありません',
    'Selected fabric has no usable height for a top pin': '選んだ布に上端のピンを作れるだけの高さがありません',
    'Split helpers contain no vertices': '分けた補助物に頂点がありません',
    'Support bind requires unchanged helper vertex count': '支えのバインドには補助物の頂点数が変わっていないことが必要です',
    'The garment has no Cloth modifier to adopt': '載せ替えるクロスモディファイアが衣装にありません',
    'Switch the garment to Object Mode first': '先に衣装をオブジェクトモードにしてください',
    'The garment mesh is shared by other objects': '衣装のメッシュを他のオブジェクトと共有しています',
    'Simply Cloth Studio did not create exactly one cloth modifier on the mapped garment':
        'Simply Cloth Studio のクロスが作られなかったため元に戻しました',
    'The saved original cloth record is invalid': '保存した元のクロスの記録が壊れています',
    'The garment has not been adopted into Simply Cloth Studio': '衣装はまだ Simply Cloth Studio に載せ替えていません',
    'The existing cloth cache is baked; free the bake before moving the cloth':
        '既存のクロスのキャッシュは焼き済みです。載せ替える前に焼きを解除してください',
    'Select a mesh': 'メッシュを指定してください',
    'A constraint occupies the skirt avoidance name: ': 'スカート回避用の名前を既存の制約が使用しています: ',
    'Simply Cloth Studio Create Cloth did not finish': 'Simply Cloth Studio のクロス作成が完了しませんでした',
    'A cloth modifier already exists; external setup would duplicate it':
        'クロスモディファイアが既にあります。外部セットアップを行うと重複します',
    'External cloth result is unavailable': '外部クロスの結果を取得できません',
    'Select a mapped mesh garment': '割当て済みの衣装メッシュを指定してください',
    'Unsupported skirt mode': '未対応のスカート方式です',
    'Mapped armature is unavailable': '割り当てたアーマチュアを使用できません',
    'Mapped skirt bone is missing: ': '割り当てたスカート骨がありません: ',
    'Mapped leg avoidance constraint is missing: ': '割り当てた脚の回避制約がありません: ',
    'Residual surface intersections may remain; inspect deformed geometry':
        '表面の交差が残っている可能性があります。変形後の形を確かめてください',
    'Residual surface intersections may remain': '表面の交差が残っている可能性があります',
    'Original stack was inferred from an older setup; verify the earlier appearance manually':
        '元のモディファイア順序は古い設定から推定したものです。以前の見た目を手で確かめてください',
    'Shared deformation bones cannot provide garment-only avoidance':
        '共有の変形骨では、衣装だけの回避はできません',
    'A fabric component setup already exists; reuse or remove its owned helpers first':
        '布部分の設定が既にあります。先にその補助物を使うか削除してください',
    'Shape keys are unsupported for component splitting; source was not changed':
        'シェイプキーのある衣装は布部分に分けられません。元の衣装は変えていません',
    'Existing garment Cloth is not migrated automatically':
        '衣装に既にあるクロスは自動で移行しません',
    'Unsupported original modifiers: ': '対応していないモディファイアが衣装にあります: ',
    'Select a support armature': '支持アーマチュアを指定してください',
    'The support armature does not drive the garment': '支持アーマチュアがこの衣装を駆動していません',
    'Select an existing support bone': '存在する支持ボーンを指定してください',
    'Select an existing fabric material slot': '存在する布の材質スロットを指定してください',
    'Select an existing fabric vertex group and valid threshold':
        '存在する布の頂点グループと、有効なしきい値を指定してください',
    'Unsupported fabric selection method': '未対応の布の選択方法です',
    'Garment has no faces': '衣装に面がありません',
    'Selection must leave both fabric and retained trim faces':
        '選択は、布の面と、保持する帯・装飾の面の両方が残るようにしてください',
    'Selected fabric has no weights for the support bone': '選んだ布に支持ボーンのウェイトがありません',
    'Selected fabric has no weights in the chosen pin group': '選んだ布に、指定したピングループのウェイトがありません',
    'Pin height fraction is outside the supported range': 'ピンの高さの割合が対応範囲外です',
    'Fabric mass or stiffness is outside the supported range': '布の重量または剛性が対応範囲外です',
    'No fabric component setup is saved': '布部分の設定が保存されていません',
    'Owned fabric or trim helper is missing or changed': '布または帯・装飾の補助物がないか変更されています',
    'Original garment modifier stack or visibility changed': '元の衣装のモディファイア順序または表示状態が変わっています',
    'Fabric-only Cloth configuration is missing or changed': '布部分のクロス設定がないか変更されています',
    'Garment is not linked to a collection': '衣装がコレクションに入っていません',
    'Owned external cloth backup is missing or changed': '外部クロスのバックアップがないか変更されています',
    'Fabric helper still shares the source Action': '布の補助物が元のアクションを共有したままです',
    'Fabric helper Action is not owned by this setup': '布の補助物のアクションはこの設定で作られた物ではありません',
    'Original garment materials or UV layer structure changed': '元の衣装の材質または UV レイヤーの構成が変わっています',
    'Helper materials or UV layer structure differs from source': '補助物の材質または UV レイヤーの構成が元の衣装と違います',
    'Helper face counts differ from the saved selection': '補助物の面の数が保存した選択と違います',
    'Retained trim has an unexpected Cloth modifier': '保持する帯・装飾に想定外のクロスモディファイアがあります',
    'Fabric Cloth, pin or total-mass conversion is inconsistent': '布のクロス、ピン、総重量の換算が一致しません',
    'Fabric component mode visibility is inconsistent': '布部分の方式と表示状態が一致しません',
    'SimplyPin was not created': 'SimplyPin が作られませんでした',
    'Motion, trim contact and surface penetration require separate native review':
        '動き、帯・装飾との接触、表面の貫通は別に確かめる必要があります',
})

# Failure wrappers: the text after them is the exception that caused the failure.
_ISSUE_WRAPPERS_JA = {
    'Simply Cloth Studio Create Cloth failed: ':
        'Simply Cloth Studio のクロス作成に失敗したため元に戻しました: ',
    'Bake failed: ':
        'ベイクに失敗しました: ',
    'Fabric component setup failed without changing the source: ':
        '布部分の設定に失敗しました（元の衣装は変えていません）: ',
    'Skirt setup failed; use Undo before retrying: ':
        'スカート設定に失敗しました。元に戻す（Undo）をしてからやり直してください: ',
}
