# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

from .. import lifecycle
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty

from .constants import QUALITY_PROFILE_ITEMS, REPORT_FORMAT_ITEMS, TARGET_SCOPE_ITEMS

_REPORT_FORMAT_TRANSLATION_CONTEXT = 'SmartCloth.ReportFormat'

_REGISTERED = False


def _persist_update(self, context) -> None:
    """Persist companion settings according to N-panel State Save policy."""
    try:
        package = (__package__ or '').rsplit('.', 1)[0]
        runtime = __import__(package + '.runtime', fromlist=['_persist_npanel_runtime_state'])
        if bool(getattr(runtime, '_APPLYING_EXTERNAL_NPANEL_STATE', False)):
            return
        persist = getattr(runtime, '_persist_npanel_runtime_state', None)
        if callable(persist):
            persist(context, force=False)
    except Exception:
        pass


class SMARTCLOTHSUITE_PG_companion_settings(bpy.types.PropertyGroup):
    quality_profile: EnumProperty(
        name='Quality Profile',
        description='Choose solver and collision quality values applied after external cloth creation or by batch profile commands.',
        items=QUALITY_PROFILE_ITEMS,
        default='PRODUCTION',
        update=_persist_update,
    )
    target_scope: EnumProperty(
        name='Target Scope',
        description='Choose whether companion commands process the active cloth, selected cloth objects, or all cloth objects in the scene.',
        items=TARGET_SCOPE_ITEMS,
        default='SELECTED',
        update=_persist_update,
    )
    body_object: PointerProperty(
        name='Body Collider',
        description='Body mesh used for collision proximity analysis, garment layer ordering, and optional external collision setup.',
        type=bpy.types.Object,
        update=_persist_update,
    )
    collider_collection: PointerProperty(
        name='Collider Collection',
        description='Optional collection whose mesh objects receive external collision setup during Smart Setup or Apply Colliders.',
        type=bpy.types.Collection,
        update=_persist_update,
    )
    skirt_garment: PointerProperty(
        name='Skirt Garment', description='Mesh garment to configure for the reversible skirt workflow.',
        type=bpy.types.Object, update=_persist_update,
    )
    skirt_armature: PointerProperty(
        name='Skirt Armature', description='Armature driving the garment and the mapped skirt and leg bones.',
        type=bpy.types.Object, update=_persist_update,
    )
    skirt_bones: StringProperty(
        name='Skirt Bones', description='Comma-separated deform bone names that drive the skirt.',
        default='', update=_persist_update,
    )
    skirt_leg_bones: StringProperty(
        name='Leg Bones', description='Comma-separated leg bone names used for mapping consistency only; bone-head distance does not prove surface clearance.',
        default='', update=_persist_update,
    )
    skirt_collider_collection: PointerProperty(
        name='Skirt Collider Collection', description='Collection of body or leg meshes used for cloth collision.',
        type=bpy.types.Collection, update=_persist_update,
    )
    skirt_clearance: FloatProperty(
        name='Legacy Bone Distance', description='Saved value from an older mapping; configuration evidence only, not surface clearance.',
        default=0.06, min=0.005, max=0.5, subtype='DISTANCE', update=_persist_update,
    )
    skirt_outside_offset: FloatProperty(
        name='Outside Offset', description='Garment-only outside correction offset; residual intersections still require visual inspection.',
        default=0.003, min=0.0, max=0.05, subtype='DISTANCE', update=_persist_update,
    )
    skirt_setup_route: EnumProperty(
        name='Cloth Setup Route',
        description='Use Blender-owned cloth or explicitly call a compatible Simply Cloth Studio public operator.',
        items=(('OWNED', 'Smart Cloth', 'Prepare Blender cloth without Simply Cloth Studio.'),
               ('SIMPLY', 'Simply Cloth Studio', 'Call the external public Create Cloth operator and verify its resulting modifier.')),
        default='OWNED', update=_persist_update,
    )
    ui_skirt_mapping: BoolProperty(default=True, update=_persist_update)
    component_source: EnumProperty(
        name='Fabric Selection', description='Select cloth faces by material slot or by a vertex group on the original garment.',
        items=(('MATERIAL', 'Material Slot', 'Use faces assigned to the chosen material slot.'),
               ('VERTEX_GROUP', 'Vertex Group', 'Use faces whose every vertex meets the group weight threshold.')),
        default='MATERIAL', update=_persist_update,
    )
    component_material_slot: IntProperty(
        name='Fabric Material Slot', description='Zero-based material slot used to select cloth faces; no material name is assumed.',
        default=0, min=0, update=_persist_update,
    )
    component_fabric_group: StringProperty(
        name='Fabric Vertex Group', description='Existing vertex group selecting all vertices of each cloth face.',
        default='', update=_persist_update,
    )
    component_group_threshold: FloatProperty(
        name='Selection Weight', description='Minimum weight required on every vertex of a selected cloth face.',
        default=0.5, min=0.001, max=1.0, update=_persist_update,
    )
    component_pin_group: StringProperty(
        name='Pin Vertex Group', description='Optional existing group copied from the garment; empty uses height within the selected fabric bounds.',
        default='', update=_persist_update,
    )
    component_pin_band: FloatProperty(
        name='Pin Height Fraction', description='Top fraction of selected fabric height used when no pin group is supplied.',
        default=0.18, min=0.01, max=0.6, update=_persist_update,
    )
    component_support_armature: PointerProperty(
        name='Support Armature', description='Existing armature driving the garment and the selected support bone; no bone constraint is added.',
        type=bpy.types.Object, update=_persist_update,
    )
    component_support_bone: StringProperty(
        name='Support Bone', description='Existing support bone whose copied garment weights anchor the selected pin area.',
        default='', update=_persist_update,
    )
    component_total_mass_kg: FloatProperty(
        name='Simulated Fabric Mass (kg)', description='Total selected fabric mass divided by the actual helper vertex count for Cloth vertex mass.',
        default=0.5, min=0.001, max=100.0, update=_persist_update,
    )
    component_tension: FloatProperty(
        name='Fabric Tension', description='Cloth tension stiffness on the owned fabric helper.',
        default=15.0, min=0.0, max=1000.0, update=_persist_update,
    )
    component_bending: FloatProperty(
        name='Fabric Bending', description='Cloth bending stiffness on the owned fabric helper.',
        default=0.5, min=0.0, max=1000.0, update=_persist_update,
    )
    ui_skirt_component: BoolProperty(default=False, update=_persist_update)
    ui_cloth_bone_bridge: BoolProperty(default=False, update=_persist_update)
    bridge_source_mesh: PointerProperty(
        name='Baked Cloth Mesh', description='Mesh with a baked Cloth point cache to sample before bone output is created.',
        type=bpy.types.Object, update=_persist_update,
    )
    bridge_target_armature: PointerProperty(
        name='Target Armature', description='Armature containing the selected garment-only pose bones.',
        type=bpy.types.Object, update=_persist_update,
    )
    bridge_frame_start: IntProperty(
        name='First Frame', description='First frame of the finite Cloth-to-bone sample range.',
        default=1, min=-100000, max=100000, update=_persist_update,
    )
    bridge_frame_end: IntProperty(
        name='Last Frame', description='Last frame within the baked Cloth cache and bounded sampling budget.',
        default=120, min=-100000, max=100000, update=_persist_update,
    )
    external_modifiers_handling: EnumProperty(
        name='Existing Modifiers',
        description='Choose how the external Create Cloth command handles existing non-cloth modifiers.',
        items=(
            ('DO_NOTHING', 'Keep', 'Keep existing modifiers when the external cloth setup runs.'),
            ('APPLY', 'Apply', 'Ask the external cloth setup to apply compatible existing modifiers.'),
            ('REMOVE', 'Remove', 'Ask the external cloth setup to remove existing non-cloth modifiers.'),
        ),
        default='DO_NOTHING',
        update=_persist_update,
    )
    apply_profile_after_setup: BoolProperty(
        name='Apply Quality Profile',
        description='Apply the selected Smart Cloth Suite quality profile immediately after external cloth creation.',
        default=True,
        update=_persist_update,
    )
    auto_collision_after_setup: BoolProperty(
        name='Auto Collision Distance',
        description='Estimate collision and self-collision distances from world-space mesh edge length after setup.',
        default=True,
        update=_persist_update,
    )
    apply_colliders_after_setup: BoolProperty(
        name='Apply Collider Setup',
        description='Apply the external collision operator to the configured body and collider collection during Smart Setup.',
        default=True,
        update=_persist_update,
    )
    auto_pin_top: BoolProperty(
        name='Create Top Pin When Missing',
        description='Create a SimplyPin top-band weight only when the cloth has no existing weighted pin group.',
        default=True,
        update=_persist_update,
    )
    preserve_existing_pin: BoolProperty(
        name='Preserve Existing Pin Weights',
        description='Never overwrite an existing SimplyPin group that already contains non-zero weights.',
        default=True,
        update=_persist_update,
    )
    pin_band_ratio: FloatProperty(
        name='Top Pin Band',
        description='Fraction of the world-space garment height used for automatic top pin generation.',
        default=0.08,
        min=0.01,
        max=0.50,
        subtype='FACTOR',
        update=_persist_update,
    )
    enable_self_collision: BoolProperty(
        name='Self Collision',
        description='Enable self collision when applying Smart Cloth Suite quality and collision settings.',
        default=True,
        update=_persist_update,
    )
    collision_distance_factor: FloatProperty(
        name='Edge Distance Factor',
        description='Multiply average world-space edge length by this factor to estimate cloth collision distance.',
        default=0.10,
        min=0.001,
        max=2.0,
        precision=4,
        update=_persist_update,
    )
    min_collision_distance: FloatProperty(
        name='Minimum Collision Distance',
        description='Lower clamp for automatically calculated cloth collision distance.',
        default=0.001,
        min=0.00001,
        max=1.0,
        subtype='DISTANCE',
        precision=5,
        update=_persist_update,
    )
    max_collision_distance: FloatProperty(
        name='Maximum Collision Distance',
        description='Upper clamp for automatically calculated cloth collision distance and temporal guard padding.',
        default=0.03,
        min=0.0001,
        max=2.0,
        subtype='DISTANCE',
        precision=5,
        update=_persist_update,
    )
    layer_gap: FloatProperty(
        name='Layer Gap',
        description='Additional collision clearance added for each garment layer farther from the body.',
        default=0.0015,
        min=0.0,
        max=0.1,
        subtype='DISTANCE',
        precision=5,
        update=_persist_update,
    )
    motion_sample_frames: IntProperty(
        name='Motion Sample Frames',
        description='Number of future frames sampled by the manual Temporal Guard command.',
        default=2,
        min=1,
        max=20,
        update=_persist_update,
    )
    temporal_guard_multiplier: FloatProperty(
        name='Temporal Guard Multiplier',
        description='Multiply measured frame-to-frame vertex motion to calculate temporary collision padding.',
        default=1.25,
        min=0.1,
        max=10.0,
        precision=3,
        update=_persist_update,
    )
    analysis_proximity_distance: FloatProperty(
        name='Proximity Analysis Distance',
        description='Body distance that maps to zero weight in the collision proximity analysis group.',
        default=0.05,
        min=0.0001,
        max=10.0,
        subtype='DISTANCE',
        precision=4,
        update=_persist_update,
    )
    preview_hide_heavy_modifiers: BoolProperty(
        name='Hide Heavy Modifiers',
        description='Temporarily hide subdivision, geometry-nodes, solidify, and smoothing modifiers during batch preview mode.',
        default=True,
        update=_persist_update,
    )
    preview_quality: IntProperty(
        name='Preview Solver Quality',
        description='Temporary Cloth solver quality used by Apply Batch Preview.',
        default=3,
        min=1,
        max=20,
        update=_persist_update,
    )
    report_format: EnumProperty(
        name='Report Format',
        translation_context=_REPORT_FORMAT_TRANSLATION_CONTEXT,
        description='Choose the file format used by preflight and safe output reports.',
        items=REPORT_FORMAT_ITEMS,
        default='JSON',
        update=_persist_update,
    )
    stop_on_preflight_error: BoolProperty(
        name='Stop on Preflight Error',
        description='Prevent external bake or finish commands when preflight detects a blocking error.',
        default=True,
        update=_persist_update,
    )
    repair_remove_loose: BoolProperty(
        name='Remove Isolated Vertices',
        description='Delete only vertices with no connected edges during safe topology repair. Sewing and boundary edges are preserved.',
        default=False,
        update=_persist_update,
    )
    repair_merge_factor: FloatProperty(
        name='Merge Distance Factor',
        description='Multiply average edge length by this small factor when merging nearly coincident vertices during safe repair.',
        default=0.0005,
        min=0.0,
        max=0.05,
        precision=6,
        update=_persist_update,
    )

    ui_external_details: BoolProperty(default=False, update=_persist_update)
    ui_workflow_options: BoolProperty(default=True, update=_persist_update)
    ui_performance_options: BoolProperty(default=False, update=_persist_update)
    ui_precision_options: BoolProperty(default=True, update=_persist_update)
    ui_analysis_options: BoolProperty(default=False, update=_persist_update)
    ui_output_options: BoolProperty(default=True, update=_persist_update)

    last_report_path: StringProperty(
        name='Last Report',
        description='Path of the most recently generated Smart Cloth Suite report.',
        default='',
        options={'SKIP_SAVE'},
    )
    last_status: StringProperty(
        name='Last Status',
        description='Summary of the most recent companion command.',
        default='',
        options={'SKIP_SAVE'},
    )


CLASSES = (SMARTCLOTHSUITE_PG_companion_settings,)


def register() -> None:
    global _REGISTERED
    if _REGISTERED:
        return
    mark = lifecycle.checkpoint()
    try:
        for cls in CLASSES:
            lifecycle.register_class(cls, scope='core.properties.classes')
        lifecycle.register_rna(
            bpy.types.Scene,
            'smart_cloth_suite_companion',
            PointerProperty(type=SMARTCLOTHSUITE_PG_companion_settings),
            scope='core.properties.rna',
        )
    except Exception:
        lifecycle.rollback_to(mark)
        raise
    _REGISTERED = True


def unregister() -> None:
    global _REGISTERED
    lifecycle.release_scope('core.properties.rna')
    lifecycle.release_scope('core.properties.classes')
    _REGISTERED = False
