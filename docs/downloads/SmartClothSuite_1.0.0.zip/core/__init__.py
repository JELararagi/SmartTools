# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Smart Cloth Suite companion workflow for external Simply Cloth Studio.

No Simply Cloth Studio implementation or assets are bundled here. The companion
uses public Blender operators exposed by a separately installed extension and
adds batch setup, precision, diagnostics, analysis, and safe-output workflows.
"""

from __future__ import annotations

import bpy

from .. import lifecycle
from . import integration, operators, properties, ui

bl_info = {
    'name': 'Smart Cloth Suite Companion Core',
    'author': 'JELararagi',
    'version': (2, 10, 6),
    'blender': (5, 1, 0),
    'location': 'Smart Cloth N-panel',
    'description': 'Companion workflow that extends an externally installed Simply Cloth Studio without bundling it.',
    'category': 'Physics',
}

_REGISTERED = False


def register(include_ui: bool = False) -> None:
    global _REGISTERED
    del include_ui
    if _REGISTERED:
        return
    mark = lifecycle.checkpoint()
    try:
        properties.register()
        for cls in operators.CLASSES:
            lifecycle.register_class(cls, scope='core.operators')
        # Populate the immutable UI snapshot outside Panel.draw. Failure leaves
        # the finite UNKNOWN snapshot and does not abort Suite registration.
        try:
            integration.external_status(force=True)
        except Exception:
            integration.invalidate_status_cache()
    except Exception:
        lifecycle.rollback_to(mark)
        raise
    _REGISTERED = True


def unregister() -> None:
    global _REGISTERED
    operators.cancel_active_safe_output_transaction()
    lifecycle.release_scope('core.operators')
    properties.unregister()
    operators.clear_simulation_runtime_cache()
    integration.invalidate_status_cache()
    _REGISTERED = False


def draw_smart_cloth_suite(layout, context) -> None:
    ui.draw_all(layout, context)


def draw_smart_cloth_suite_section(layout, context, section_key: str) -> None:
    ui.draw_section(layout, context, section_key)
