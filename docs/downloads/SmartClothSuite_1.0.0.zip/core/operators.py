# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

from collections import defaultdict
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
import json
import math
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Iterable

import bpy

from .. import lifecycle
from bpy.props import EnumProperty

if TYPE_CHECKING:
    from mathutils import Vector

from . import integration
from . import skirt
from .constants import (
    ANALYSIS_GROUP_CURVATURE,
    ANALYSIS_GROUP_PIN,
    ANALYSIS_GROUP_PROXIMITY,
    EXTERNAL_CLOTH_MODIFIER,
    EXTERNAL_COLLISION_MODIFIER,
    EXTERNAL_PIN_GROUP,
    LAYER_ORDER_KEY,
    PREVIEW_STATE_KEY,
    QUALITY_PROFILE_VALUES,
)


def _simulation_api() -> tuple[object, object]:
    """Import geometry preparation APIs only inside an executing operator.

    Python's module loader owns its normal import cache; the Suite deliberately
    keeps no additional simulation API cache while idle or disabled.
    """
    import bmesh as bmesh_module
    from mathutils.bvhtree import BVHTree as bvh_type
    return bmesh_module, bvh_type


def clear_simulation_runtime_cache() -> None:
    """Compatibility no-op: the Suite owns no persistent simulation API cache."""
    return None


# -----------------------------------------------------------------------------
# Shared helpers


def _is_japanese(context=None) -> bool:
    try:
        view = getattr(getattr(context or bpy.context, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        return (locale or language).lower().startswith('ja')
    except Exception:
        return False


def _t(en: str, ja: str, context=None) -> str:
    return str(ja if _is_japanese(context) else en)


def _error_detail(exc, context=None) -> str:
    # A failed bpy.ops call carries the operator's own report behind "Error: ",
    # already in the UI language. Anything else is not shown as it is.
    if isinstance(exc, OSError):
        return _t('Check that the location exists and can be written to.', 'フォルダーの場所と書き込みの権限を確かめてください。', context)
    text = str(exc).strip()
    if text.startswith('Error: '):
        text = text[len('Error: '):].strip()
    text = text.split('\n', 1)[0].strip()
    if 'bpy.ops.' in text or 'poll()' in text:
        return _t('Check the selection and mode.', '選択とモードを確かめてください。', context)
    if isinstance(exc, RuntimeError) and text and not text.startswith(('Python:', 'Traceback')):
        if not _is_japanese(context):
            return text
        if skirt._issue_match(text):
            return skirt.localize_issues(text, True)
        if any(ord(ch) >= 0x3040 for ch in text):
            return text
    return _t('The command could not be completed.', '処理を完了できませんでした。', context)


def _mode_text(mode, context=None) -> str:
    return _t('Cloth', 'クロス', context) if mode == skirt.MODE_CLOTH else _t('Bones', 'ボーン', context)


def _settings(context=None):
    scene = getattr(context or bpy.context, 'scene', None)
    return getattr(scene, 'smart_cloth_suite_companion', None) if scene is not None else None


def _cloth_modifier(obj):
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return None
    try:
        mod = obj.modifiers.get(EXTERNAL_CLOTH_MODIFIER)
        if mod is not None and mod.type == 'CLOTH':
            return mod
    except Exception:
        pass
    try:
        return next((mod for mod in obj.modifiers if mod.type == 'CLOTH'), None)
    except Exception:
        return None


def _has_cloth(obj) -> bool:
    return _cloth_modifier(obj) is not None


def _mesh_objects(values: Iterable[object]) -> list[bpy.types.Object]:
    result: list[bpy.types.Object] = []
    seen: set[int] = set()
    for obj in values or ():
        if obj is None or getattr(obj, 'type', None) != 'MESH':
            continue
        try:
            pointer = int(obj.as_pointer())
        except Exception:
            pointer = id(obj)
        if pointer in seen:
            continue
        seen.add(pointer)
        result.append(obj)
    return result


def _target_objects(context, *, require_cloth: bool = True, scope: str | None = None) -> list[bpy.types.Object]:
    settings = _settings(context)
    scope = str(scope or getattr(settings, 'target_scope', 'SELECTED') or 'SELECTED')
    if scope == 'ACTIVE':
        values = [getattr(context, 'active_object', None)]
    elif scope == 'ALL':
        values = list(getattr(getattr(context, 'scene', None), 'objects', ()) or ())
    else:
        values = list(getattr(context, 'selected_objects', ()) or ())
        if not values:
            values = [getattr(context, 'active_object', None)]
    objects = _mesh_objects(values)
    body = getattr(settings, 'body_object', None) if settings is not None else None
    objects = [obj for obj in objects if obj != body]
    if require_cloth:
        objects = [obj for obj in objects if _has_cloth(obj)]
    return objects


@dataclass
class _SelectionState:
    selected_objects: tuple[object, ...]
    active_object: object | None
    active_mode: str
    frame: int


def _capture_selection(context) -> _SelectionState:
    active = getattr(context, 'active_object', None)
    return _SelectionState(
        selected_objects=tuple(getattr(context, 'selected_objects', ()) or ()),
        active_object=active,
        active_mode=str(getattr(active, 'mode', getattr(context, 'mode', 'OBJECT')) or 'OBJECT'),
        frame=int(getattr(getattr(context, 'scene', None), 'frame_current', 1) or 1),
    )


def _mode_token(mode: str) -> str:
    return {
        'EDIT_MESH': 'EDIT',
        'EDIT_CURVE': 'EDIT',
        'EDIT_ARMATURE': 'EDIT',
        'PAINT_WEIGHT': 'WEIGHT_PAINT',
        'PAINT_VERTEX': 'VERTEX_PAINT',
        'PAINT_TEXTURE': 'TEXTURE_PAINT',
        'SCULPT': 'SCULPT',
        'POSE': 'POSE',
    }.get(str(mode or ''), 'OBJECT')


def _ensure_object_mode(context) -> None:
    active = getattr(context, 'active_object', None)
    if active is None or getattr(active, 'mode', 'OBJECT') == 'OBJECT':
        return
    try:
        with integration.view3d_override(context):
            bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:
        pass


@contextmanager
def _object_mode_for_mesh_writes(context):
    """Run a mesh data write outside Edit Mode, then return to the user's mode.

    In Edit Mode ``obj.data`` lacks the unflushed edits and refuses
    ``BMesh.to_mesh`` and ``VertexGroup.add``.
    """
    active = getattr(context, 'active_object', None)
    mode = getattr(active, 'mode', 'OBJECT') if active is not None else 'OBJECT'
    if mode != 'EDIT':
        yield
        return
    _ensure_object_mode(context)
    try:
        yield
    finally:
        with integration.view3d_override(context):
            bpy.ops.object.mode_set(mode=mode)


def _activate_only(context, obj, selected: Iterable[bpy.types.Object] | None = None) -> None:
    _ensure_object_mode(context)
    scene = getattr(context, 'scene', None)
    try:
        for item in tuple(getattr(scene, 'objects', ()) or ()):
            try:
                item.select_set(False)
            except Exception:
                pass
    except Exception:
        pass
    chosen = _mesh_objects(selected or [obj])
    for item in chosen:
        try:
            item.hide_set(False)
        except Exception:
            pass
        try:
            item.select_set(True)
        except Exception:
            pass
    try:
        context.view_layer.objects.active = obj
    except Exception:
        try:
            bpy.context.view_layer.objects.active = obj
        except Exception:
            pass


def _restore_selection(context, state: _SelectionState) -> None:
    _ensure_object_mode(context)
    scene = getattr(context, 'scene', None)
    scene_objects = tuple(getattr(scene, 'objects', ()) or ()) if scene is not None else ()
    scene_ids = {id(obj) for obj in scene_objects}
    for obj in scene_objects:
        try:
            obj.select_set(False)
        except Exception:
            pass
    for obj in tuple(state.selected_objects or ()):
        if id(obj) not in scene_ids:
            continue
        try:
            obj.select_set(True)
        except Exception:
            pass
    active = state.active_object if id(state.active_object) in scene_ids else None
    try:
        # Restore the exact active identity, including an originally empty
        # active slot. Leaving the last transaction target active would violate
        # cancellation/exception rollback when the user started with no active
        # object.
        context.view_layer.objects.active = active
    except Exception:
        pass
    if active is not None:
        token = _mode_token(state.active_mode)
        if token != 'OBJECT':
            try:
                with integration.view3d_override(context):
                    bpy.ops.object.mode_set(mode=token)
            except Exception:
                pass
    try:
        context.scene.frame_set(state.frame)
    except Exception:
        pass


def _average_world_edge_length(obj, *, max_samples: int = 12000) -> float:
    mesh = getattr(obj, 'data', None)
    edges = tuple(getattr(mesh, 'edges', ()) or ()) if mesh is not None else ()
    vertices = getattr(mesh, 'vertices', ()) if mesh is not None else ()
    if not edges or not vertices:
        return 0.0
    step = max(1, int(math.ceil(len(edges) / max(1, int(max_samples)))))
    matrix = obj.matrix_world
    total = 0.0
    count = 0
    for index in range(0, len(edges), step):
        edge = edges[index]
        try:
            a, b = edge.vertices
            total += ((matrix @ vertices[a].co) - (matrix @ vertices[b].co)).length
            count += 1
        except Exception:
            continue
    return total / count if count else 0.0


def _auto_distance(obj, settings) -> float:
    edge = _average_world_edge_length(obj)
    minimum = float(getattr(settings, 'min_collision_distance', 0.001) or 0.001)
    maximum = max(minimum, float(getattr(settings, 'max_collision_distance', 0.03) or 0.03))
    factor = float(getattr(settings, 'collision_distance_factor', 0.10) or 0.10)
    value = edge * factor if edge > 0.0 else minimum
    return max(minimum, min(maximum, value))



# Simply Cloth Studio's property names ARE its API surface, and they have already
# drifted once: the two collision-distance properties are registered with a
# ``_slider`` suffix, so writing the bare names silently reached nothing, for
# every user, forever. Each mirror therefore carries a list of candidate names,
# and a mirror that matches none of them is COLLECTED AND REPORTED rather than
# swallowed -- the old code wrapped every write in ``except: pass``, which is why
# this went unnoticed.
SCS_MIRRORS = {
    'quality': ('quality_steps_slider', 'quality_steps'),
    'collision_quality': ('collision_quality_slider', 'collision_quality'),
    'self_collision': ('self_collision',),
    'object_distance': ('objectCollisionDistance_slider',
                        'objectCollisionDistance'),
    'self_distance': ('selfCollisionDistance_slider', 'selfCollisionDistance'),
}
_MIRROR_FAILURES: list[str] = []


def mirror_failures() -> list[str]:
    """Mirrors that could not be written since the last apply."""
    return list(_MIRROR_FAILURES)


def _mirror(obj, key: str, value) -> bool:
    # Simply Cloth registers its sliders on all Objects. Their callbacks
    # look up SimplyCloth on the context's active object.
    mod = obj.modifiers.get(EXTERNAL_CLOTH_MODIFIER)
    if mod is None or mod.type != 'CLOTH':
        return False
    candidates = SCS_MIRRORS.get(key, ())
    for name in candidates:
        if not hasattr(obj, name):
            continue
        try:
            with bpy.context.temp_override(active_object=obj, object=obj):
                setattr(obj, name, value)
            return True
        except Exception as exc:
            _MIRROR_FAILURES.append('%s.%s: %s' % (obj.name, name, exc))
            return False
    _MIRROR_FAILURES.append('%s: none of %s exists on this Simply Cloth build'
                            % (obj.name, ', '.join(candidates)))
    return False


def _apply_quality(obj, settings) -> bool:
    mod = _cloth_modifier(obj)
    if mod is None:
        return False
    profile = str(getattr(settings, 'quality_profile', 'PRODUCTION') or 'PRODUCTION')
    values = QUALITY_PROFILE_VALUES.get(profile, QUALITY_PROFILE_VALUES['PRODUCTION'])
    try:
        mod.settings.quality = int(values['quality'])
    except Exception:
        pass
    try:
        mod.settings.time_scale = float(values['time_scale'])
    except Exception:
        pass
    try:
        collision = mod.collision_settings
        collision.collision_quality = int(values['collision_quality'])
        collision.use_self_collision = bool(getattr(settings, 'enable_self_collision', True))
    except Exception:
        pass
    # Mirror values into public Simply Cloth UI properties when present so both
    # add-ons display the same result without importing external implementation.
    del _MIRROR_FAILURES[:]
    _mirror(obj, 'quality', int(values['quality']))
    _mirror(obj, 'collision_quality', int(values['collision_quality']))
    _mirror(obj, 'self_collision',
            bool(getattr(settings, 'enable_self_collision', True)))
    return True


def _apply_distance(obj, settings, value: float | None = None) -> bool:
    mod = _cloth_modifier(obj)
    if mod is None:
        return False
    distance = float(value if value is not None else _auto_distance(obj, settings))
    try:
        collision = mod.collision_settings
        collision.distance_min = distance
        collision.self_distance_min = max(distance, min(float(getattr(settings, 'max_collision_distance', 0.03)), distance * 1.25))
        collision.use_self_collision = bool(getattr(settings, 'enable_self_collision', True))
    except Exception:
        return False
    del _MIRROR_FAILURES[:]
    _mirror(obj, 'object_distance', collision.distance_min)
    _mirror(obj, 'self_distance', collision.self_distance_min)
    return True


def _group_has_weight(obj, group_name: str) -> bool:
    group = getattr(obj, 'vertex_groups', None)
    group = group.get(group_name) if group is not None else None
    if group is None:
        return False
    index = int(group.index)
    try:
        for vertex in obj.data.vertices:
            for membership in vertex.groups:
                if membership.group == index and membership.weight > 1.0e-6:
                    return True
    except Exception:
        return False
    return False


def _create_top_pin(obj, settings) -> bool:
    if bool(getattr(settings, 'preserve_existing_pin', True)) and _group_has_weight(obj, EXTERNAL_PIN_GROUP):
        return False
    vertices = tuple(getattr(getattr(obj, 'data', None), 'vertices', ()) or ())
    if not vertices:
        return False
    matrix = obj.matrix_world
    heights = [float((matrix @ vertex.co).z) for vertex in vertices]
    low, high = min(heights), max(heights)
    ratio = float(getattr(settings, 'pin_band_ratio', 0.08) or 0.08)
    threshold = high - max(1.0e-8, high - low) * ratio
    indices = [i for i, height in enumerate(heights) if height >= threshold]
    if not indices:
        return False
    group = obj.vertex_groups.get(EXTERNAL_PIN_GROUP) or obj.vertex_groups.new(name=EXTERNAL_PIN_GROUP)
    group.add(indices, 1.0, 'REPLACE')
    mod = _cloth_modifier(obj)
    if mod is not None:
        try:
            mod.settings.vertex_group_mass = EXTERNAL_PIN_GROUP
        except Exception:
            pass
    return True


def _collider_objects(context, settings, *, exclude: Iterable[bpy.types.Object] = ()) -> list[bpy.types.Object]:
    excluded = {int(obj.as_pointer()) for obj in exclude if obj is not None}
    candidates = []
    body = getattr(settings, 'body_object', None)
    if body is not None:
        candidates.append(body)
    collection = getattr(settings, 'collider_collection', None)
    if collection is not None:
        candidates.extend(list(getattr(collection, 'all_objects', ()) or getattr(collection, 'objects', ()) or ()))
    return [obj for obj in _mesh_objects(candidates) if int(obj.as_pointer()) not in excluded]


def _apply_external_colliders(context, settings, *, exclude: Iterable[bpy.types.Object] = ()) -> tuple[int, int]:
    objects = _collider_objects(context, settings, exclude=exclude)
    pending = []
    for obj in objects:
        try:
            has_collision = any(mod.type == 'COLLISION' for mod in obj.modifiers)
        except Exception:
            has_collision = False
        if not has_collision:
            pending.append(obj)
    if not pending:
        return len(objects), 0
    names = {int(obj.as_pointer()): str(obj.name) for obj in pending}
    _activate_only(context, pending[0], pending)
    integration.call_external_operator('object.simply_collision_manager', context, mode='ADDNEW')
    # The external operator may rename collision meshes. Restore user names; the
    # collision modifier is the intended change, not an object-name rewrite.
    for obj in pending:
        name = names.get(int(obj.as_pointer()))
        if name:
            try:
                obj.name = name
            except Exception:
                pass
    return len(objects), len(pending)


def _external_ready(operator, context) -> bool:
    # Execution must see the current external extension state even when the
    # passive N-panel status snapshot was cached earlier.
    status = integration.external_status(force=True)
    if status.ready:
        return True
    missing = (_t('%(count)s required commands', '必須の操作 %(count)s 個', context) % {'count': len(status.missing_required)}
               if status.missing_required else _t('not enabled', '有効化されていません', context))
    operator.report({'WARNING'}, _t(
        'Simply Cloth Studio is not ready. Missing: %(missing)s',
        'Simply Cloth Studio を使用できません。未検出: %(missing)s',
        context,
    ) % {'missing': missing})
    return False


def _reports_dir() -> Path:
    try:
        from .. import storage
        return storage.smart_suite_config_dir('reports', create=True)
    except Exception:
        path = Path.home() / 'Smart_Cloth_Suite' / 'reports'
        path.mkdir(parents=True, exist_ok=True)
        return path


def _set_last_status(settings, text: str, report_path: str = '') -> None:
    if settings is None:
        return
    try:
        settings.last_status = str(text or '')
    except Exception:
        pass
    if report_path:
        try:
            settings.last_report_path = str(report_path)
        except Exception:
            pass


def _write_report(report: dict, settings, prefix: str = 'preflight') -> Path:
    reports = _reports_dir()
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    format_name = str(getattr(settings, 'report_format', 'JSON') or 'JSON')
    if format_name == 'TEXT':
        path = reports / f'{prefix}_{stamp}.txt'
        summary = report.get('summary', {})
        lines = [
            _t('Smart Cloth Suite Report', 'Smart Cloth Suite レポート'),
            f"{_t('Generated', '作成日時')}: {report.get('generated_at', '')}",
            _t('Summary: %(objects)s objects, %(errors)s errors, %(warnings)s warnings, average score %(score)s',
               '概要: 対象 %(objects)s 個、エラー %(errors)s 件、警告 %(warnings)s 件、平均スコア %(score)s') % {
                'objects': summary.get('objects', 0), 'errors': summary.get('errors', 0),
                'warnings': summary.get('warnings', 0), 'score': summary.get('average_score', 0)},
            '',
        ]
        for item in report.get('objects', ()):
            lines.append(f"[{item.get('name', 'Object')}] {_t('score', 'スコア')}={item.get('score', 0)}")
            for error in item.get('errors', ()):
                lines.append(f"{_t('ERROR', 'エラー')}: {error}")
            for warning in item.get('warnings', ()):
                lines.append(f"{_t('WARNING', '警告')}: {warning}")
            for info in item.get('info', ()):
                lines.append(f"{_t('INFO', '情報')}: {info}")
            lines.append('')
        path.write_text('\n'.join(lines), encoding='utf-8')
    else:
        path = reports / f'{prefix}_{stamp}.json'
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True), encoding='utf-8')
    return path


def _preflight_object(obj) -> dict:
    errors: list[str] = []
    warnings: list[str] = []
    info: list[str] = []
    mesh = getattr(obj, 'data', None)
    if mesh is None or len(mesh.vertices) == 0 or len(mesh.polygons) == 0:
        errors.append(_t('Mesh has no usable faces.', 'メッシュに使える面がありません。'))
        return {'name': obj.name, 'errors': errors, 'warnings': warnings, 'info': info, 'score': 0}
    cloth = _cloth_modifier(obj)
    if cloth is None:
        errors.append(_t('Cloth modifier is missing.', 'クロスモディファイアがありません。'))
    else:
        try:
            info.append(f"{_t('Solver quality', 'ソルバー品質')}: {int(cloth.settings.quality)}")
            info.append(f"{_t('Collision quality', '衝突品質')}: {int(cloth.collision_settings.collision_quality)}")
            if bool(cloth.point_cache.is_baked):
                info.append(_t('Point cache is baked.', 'ポイントキャッシュはベイク済みです。'))
        except Exception:
            pass
    cloth_count = sum(1 for mod in obj.modifiers if mod.type == 'CLOTH')
    if cloth_count > 1:
        warnings.append(f"{_t('Multiple Cloth modifiers found', '複数のクロスモディファイアがあります')}: {cloth_count}")
    scale = tuple(float(abs(v)) for v in obj.scale)
    if obj.matrix_world.to_3x3().determinant() < 0.0:
        errors.append(_t('Object has negative transform scale.', 'オブジェクトのスケールが負の値です。'))
    if max(scale) - min(scale) > 1.0e-4:
        warnings.append(_t('Object has non-uniform scale.', 'オブジェクトのスケールが軸ごとに違います。'))
    if not _group_has_weight(obj, EXTERNAL_PIN_GROUP):
        warnings.append(_t('SimplyPin has no non-zero weights.', 'SimplyPin に 0 より大きいウェイトがありません。'))

    bmesh_module, _bvh_type = _simulation_api()
    bm = bmesh_module.new()
    try:
        bm.from_mesh(mesh)
        loose_vertices = sum(1 for vert in bm.verts if not vert.link_edges)
        loose_edges = sum(1 for edge in bm.edges if not edge.link_faces)
        non_manifold = sum(1 for edge in bm.edges if len(edge.link_faces) > 2)
        zero_faces = sum(1 for face in bm.faces if face.calc_area() <= 1.0e-12)
        if loose_vertices:
            warnings.append(f"{_t('Isolated vertices', '孤立した頂点')}: {loose_vertices}")
        if loose_edges:
            warnings.append(f"{_t('Wire edges without faces', '面のない辺')}: {loose_edges}")
        if non_manifold:
            errors.append(f"{_t('Edges shared by more than two faces', '3 つ以上の面が共有する辺')}: {non_manifold}")
        if zero_faces:
            errors.append(f"{_t('Zero-area faces', '面積 0 の面')}: {zero_faces}")
    finally:
        bm.free()
    score = max(0, 100 - len(errors) * 25 - len(warnings) * 6)
    return {
        'name': obj.name,
        'vertices': len(mesh.vertices),
        'edges': len(mesh.edges),
        'faces': len(mesh.polygons),
        'errors': errors,
        'warnings': warnings,
        'info': info,
        'score': score,
    }


def _preflight_report(context, objects: list[bpy.types.Object]) -> dict:
    items = [_preflight_object(obj) for obj in objects]
    error_count = sum(len(item['errors']) for item in items)
    warning_count = sum(len(item['warnings']) for item in items)
    external_status = integration.external_status(force=True)
    return {
        'schema': 1,
        'generated_at': datetime.now().isoformat(timespec='seconds'),
        'blender_version': '.'.join(str(v) for v in bpy.app.version[:3]),
        'external_tool': {
            'name': 'Simply Cloth Studio',
            'version': external_status.version,
            'ready': external_status.ready,
        },
        'summary': {
            'objects': len(items),
            'errors': error_count,
            'warnings': warning_count,
            'average_score': round(sum(item['score'] for item in items) / len(items), 2) if items else 0.0,
        },
        'objects': items,
    }


def _evaluated_world_vertices(obj, depsgraph, *, max_samples: int = 1024) -> list['Vector']:
    evaluated = obj.evaluated_get(depsgraph)
    mesh = None
    try:
        mesh = evaluated.to_mesh()
        vertices = tuple(mesh.vertices)
        if not vertices:
            return []
        step = max(1, int(math.ceil(len(vertices) / max(1, max_samples))))
        matrix = evaluated.matrix_world
        return [matrix @ vertices[index].co.copy() for index in range(0, len(vertices), step)]
    finally:
        if mesh is not None:
            try:
                evaluated.to_mesh_clear()
            except Exception:
                pass


def _world_bvh(obj, depsgraph):
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return None
    evaluated = obj.evaluated_get(depsgraph)
    mesh = None
    try:
        mesh = evaluated.to_mesh()
        matrix = evaluated.matrix_world
        vertices = [matrix @ vert.co for vert in mesh.vertices]
        polygons = [tuple(poly.vertices) for poly in mesh.polygons]
        if not vertices or not polygons:
            return None
        _bmesh_module, bvh_type = _simulation_api()
        return bvh_type.FromPolygons(vertices, polygons, all_triangles=False)
    finally:
        if mesh is not None:
            try:
                evaluated.to_mesh_clear()
            except Exception:
                pass


def _nearest_distance(bvh, point: 'Vector') -> float | None:
    if bvh is None:
        return None
    try:
        result = bvh.find_nearest(point)
        if result is None:
            return None
        return float(result[3])
    except Exception:
        return None


def _write_vertex_weights(obj, name: str, weights: list[float]) -> None:
    group = obj.vertex_groups.get(name) or obj.vertex_groups.new(name=name)
    buckets: dict[int, list[int]] = defaultdict(list)
    for index, weight in enumerate(weights):
        bucket = max(0, min(255, int(round(float(weight) * 255.0))))
        buckets[bucket].append(index)
    for bucket, indices in buckets.items():
        if indices:
            group.add(indices, bucket / 255.0, 'REPLACE')


# -----------------------------------------------------------------------------
# Operators


class SMARTCLOTHSUITE_OT_refresh_external_status(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.refresh_external_status'
    bl_label = 'Refresh External Tool Status'
    bl_description = 'Refresh installation, enabled-state, version, and required-operator detection for the external Simply Cloth Studio extension.'
    bl_options = {'INTERNAL'}

    def execute(self, context):
        integration.invalidate_status_cache()
        status = integration.external_status(force=True)
        message = _t(
            'Simply Cloth Studio is ready.' if status.ready else 'Simply Cloth Studio is not ready.',
            'Simply Cloth Studio を使用できます。' if status.ready else 'Simply Cloth Studio を使用できません。',
            context,
        )
        self.report({'INFO'} if status.ready else {'WARNING'}, message)
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_open_external_preferences(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.open_external_preferences'
    bl_label = 'Open External Add-on Settings'
    bl_description = 'Open Blender Preferences so Simply Cloth Studio can be installed, enabled, or configured as a separate external extension.'
    bl_options = {'INTERNAL'}

    def execute(self, context):
        try:
            bpy.ops.screen.userpref_show('INVOKE_DEFAULT')
            try:
                context.preferences.active_section = 'ADDONS'
            except Exception:
                try:
                    context.preferences.active_section = 'EXTENSIONS'
                except Exception:
                    pass
            return {'FINISHED'}
        except Exception as exc:
            self.report({'WARNING'}, _t('Could not open the add-on settings.', 'アドオン設定を開けませんでした。', context))
            return {'CANCELLED'}


class SMARTCLOTHSUITE_OT_skirt_preview(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.skirt_preview'
    bl_label = 'Preview Skirt Mapping'
    bl_description = 'Inspect the mapped garment, armature, skirt bones, leg bones and colliders without changing any data.'
    bl_options = set()

    def execute(self, context):
        settings = _settings(context)
        if settings is None:
            self.report({'WARNING'}, _t('Skirt settings are unavailable.', 'スカート設定を取得できません。', context))
            return {'CANCELLED'}
        mapping, issues = skirt.preview_mapping(settings, context)
        summary = skirt.mapping_summary(mapping, issues)
        message = _t('Garment: %(garment)s; armature: %(armature)s; skirt bones: %(skirt)d; leg bones: %(legs)d; colliders: %(colliders)d; issues: %(issues)d.',
                     '衣装: %(garment)s、リグ: %(armature)s、スカート骨: %(skirt)d、脚骨: %(legs)d、衝突対象: %(colliders)d、問題: %(issues)d件。', context) % {
            'garment': summary['garment'] or '-', 'armature': summary['armature'] or '-',
            'skirt': len(summary['skirt_bones']), 'legs': len(summary['leg_bones']),
            'colliders': len(summary['colliders']), 'issues': len(issues)}
        self.report({'INFO'} if not issues else {'WARNING'}, message)
        if not issues and skirt.shared_deform_bones(mapping):
            self.report({'WARNING'}, _t('Shared deformation bones cannot move only the garment; no avoidance constraint will be added.',
                                         '共有変形骨では衣装だけを動かせないため、回避制約は追加しません。', context))
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_skirt_setup(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.skirt_setup'
    bl_label = 'Apply Skirt Mapping'
    bl_description = 'Check the mapping, refuse ineffective constraints on shared deformation bones, and prepare reversible cloth setup. The initial mode is Bones.'
    bl_options = {'UNDO'}

    band_ratio: bpy.props.FloatProperty(
        name='Pinned Band',
        description='How far down from the top the pin fades out, as a fraction of the garment height. A hard pin line creases on the first frame',
        default=0.28, min=0.01, max=0.6,
    )
    quality: bpy.props.IntProperty(name='Quality', default=5, min=1, max=20)

    @classmethod
    def poll(cls, context):
        return _settings(context) is not None

    def execute(self, context):
        settings = _settings(context)
        mapping = skirt.resolve_mapping(settings, context)
        obj = mapping['garment']
        report, error = skirt.apply_mapping(settings, context,
                                            band_ratio=self.band_ratio,
                                            quality=self.quality)
        if error:
            self.report({'WARNING'}, _t('Skirt setup could not be applied; check the mapping and console detail: %(detail)s',
                                         'スカート設定を適用できません。割当てを確認してください: %(detail)s', context) % {'detail': skirt.localize_issues(error, _is_japanese(context))})
            return {'CANCELLED'}
        message = _t('%(name)s can now be switched: %(pinned)s vertices pinned at the waist, cloth at slot %(index)s. It ships in bone mode.', '%(name)s を切り替え可能にしました。腰で %(pinned)s 頂点を固定、クロスはスロット %(index)s。既定はボーン方式です。', context) % {
            'name': obj.name, 'pinned': report['pin']['pinned'],
            'index': report['cloth']['index']}
        self.report({'WARNING'} if report['shared_bones_rejected'] else {'INFO'}, message)
        if report['shared_bones_rejected']:
            self.report({'WARNING'}, _t('Shared deformation bones were excluded from avoidance constraints. Outside Correction is optional; surface intersections may remain.',
                                         '共有変形骨への回避制約は拒否しました。外側補正は任意で、表面交差は残る可能性があります。', context))
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_skirt_mode(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.skirt_mode'
    bl_label = 'Switch Bones / Cloth'
    bl_description = 'Switch the mapped garment between its original bone appearance and verified cloth without changing skin weights.'
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        name='Mode',
        items=(('TOGGLE', 'Toggle', 'Switch to the other mode'),
               ('BONE', 'Bones', 'Drive the garment with the rig'),
               ('CLOTH', 'Cloth', 'Drive the garment with the simulation')),
        default='TOGGLE',
    )

    @classmethod
    def poll(cls, context):
        return _settings(context) is not None

    def execute(self, context):
        mapping = skirt.resolve_mapping(_settings(context), context)
        obj = mapping['garment']
        profile = skirt.read_profile(obj)
        adopted = profile.get('adopted') == skirt.ROUTE_ADOPTED
        wanted = self.mode
        if wanted == 'TOGGLE':
            now = skirt.adopted_mode(obj) if adopted else skirt.current_mode(obj)
            wanted = skirt.MODE_BONE if now == skirt.MODE_CLOTH else skirt.MODE_CLOTH
        if adopted and skirt.profile_schema(profile) != 3:
            report, error = skirt.set_adopted_mode(obj, wanted, context)
        else:
            report, error = skirt.switch_mapping_mode(obj, wanted, mapping['armature'])
            if not error and adopted:
                skirt.set_adopted_mode(obj, wanted, context)
        if error:
            self.report({'WARNING'}, _t('Skirt mode could not be changed: %(detail)s', 'スカート方式を切り替えられません: %(detail)s', context) % {'detail': skirt.localize_issues(error, _is_japanese(context))})
            return {'CANCELLED'}
        message = _t('%(name)s is now driven by %(mode)s.', '%(name)s は %(mode)s 駆動になりました。', context) % {
            'name': obj.name,
            'mode': (_t('the cloth simulation', 'クロスシミュレーション', context)
                     if report['mode'] == skirt.MODE_CLOTH
                     else _t('the bone rig', 'ボーンリグ', context))}
        self.report({'INFO'}, message)
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_skirt_audit(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.skirt_audit'
    bl_label = 'Configuration Consistency'
    bl_description = 'Check mapping and modifier configuration only; bone-head distance does not prove garment/body surface clearance.'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return _settings(context) is not None

    def execute(self, context):
        report, error = skirt.validate_mapping(_settings(context), context)
        if error:
            self.report({'WARNING'}, skirt.localize_issues(error, _is_japanese(context)))
            return {'CANCELLED'}
        if report['ok']:
            level = {'WARNING'} if report.get('warnings') else {'INFO'}
            self.report(level, _t('Configuration is consistent in %(mode)s mode; surface intersections are not ruled out.', '設定は %(mode)s 方式で整合しています。衣装と体の交差がない証明ではありません。', context) % {'mode': _mode_text(report['mode'], context)})
        else:
            self.report({'WARNING'}, _t('Skirt setup has %(count)d issue(s): %(detail)s', 'スカート設定に %(count)d 件の問題があります: %(detail)s', context) % {'count': len(report['issues']), 'detail': skirt.localize_issues('; '.join(report['issues']), _is_japanese(context))})
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_skirt_outside(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.skirt_outside'
    bl_label = 'Outside Correction'
    bl_description = 'Toggle garment-only outside Shrinkwrap correction; residual intersections may remain.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        if settings is None:
            return {'CANCELLED'}
        report, error = skirt.set_outside_correction(settings, context)
        if error:
            self.report({'WARNING'}, skirt.localize_issues(error, _is_japanese(context)))
            return {'CANCELLED'}
        self.report({'WARNING'}, _t('Outside correction %(state)s; residual surface intersections may remain.',
                                    '外側補正を%(state)sにしました。表面の交差は残る可能性があります。', context) % {
            'state': (_t('on', 'オン', context) if report['enabled'] else _t('off', 'オフ', context))})
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_component_preview(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.component_preview'
    bl_label = 'Preview Fabric Component'
    bl_description = 'Count selected fabric and retained trim faces without changing mesh or animation data.'
    bl_options = set()

    def execute(self, context):
        report = skirt.component_preview(_settings(context), context)
        if not report['ok']:
            self.report({'WARNING'}, _t('Fabric selection is not ready; inspect the mapping and existing Cloth.',
                                         '布部分の選択が未確定です。割当てと既存クロスを確認してください。', context))
            return {'CANCELLED'}
        self.report({'INFO'}, _t('Fabric: %(fabric)d faces / %(vertices)d vertices; retained trim: %(trim)d faces; pin candidates: %(pin)d.',
                                 '布: %(fabric)d面 / %(vertices)d頂点、保持する帯・装飾: %(trim)d面、固定候補: %(pin)d頂点。', context) % {
            'fabric': report['fabric_faces'], 'vertices': report['fabric_vertices'],
            'trim': report['trim_faces'], 'pin': report['pin_candidates']})
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_component_apply(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.component_apply'
    bl_label = 'Create Fabric Component'
    bl_description = 'Create owned fabric and retained-trim helpers; call the actual Simply Cloth Studio Create Cloth operation on fabric only.'
    bl_options = {'UNDO'}

    def execute(self, context):
        result, error = skirt.component_apply(_settings(context), context)
        if error:
            self.report({'WARNING'}, skirt.localize_issues(error, _is_japanese(context)))
            return {'CANCELLED'}
        profile = result['profile']
        self.report({'INFO'}, _t('Fabric helper ready: %(vertices)d simulated vertices, %(mass).6f kg per vertex; original garment remains in Bones.',
                                 '布補助物を作成: 実シミュレーション%(vertices)d頂点、1頂点あたり%(mass).6f kg。元の衣装はボーン表示のままです。', context) % {
            'vertices': profile['simulated_vertices'],
            'mass': profile['mass_per_vertex_kg']})
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_component_mode(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.component_mode'
    bl_label = 'Switch Fabric Component'
    bl_description = 'Switch between exact original garment appearance and fabric-only Cloth plus retained trim.'
    bl_options = {'UNDO'}
    mode: bpy.props.EnumProperty(items=(('BONE', 'Bones', ''), ('CLOTH', 'Cloth', '')),
                                 default='BONE')

    def execute(self, context):
        garment = getattr(_settings(context), 'skirt_garment', None)
        result, error = skirt.component_mode(garment, self.mode)
        if error:
            self.report({'WARNING'}, skirt.localize_issues(error, _is_japanese(context)))
            return {'CANCELLED'}
        self.report({'INFO'}, _t('Fabric component mode: %(mode)s.', '布部分の方式: %(mode)s。', context) % {
            'mode': _mode_text(result['mode'], context)})
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_component_cleanup(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.component_cleanup'
    bl_label = 'Remove Owned Fabric Helpers'
    bl_description = 'Restore Bones and remove only this setup’s tagged fabric and trim helpers; repeated cleanup is harmless.'
    bl_options = {'UNDO'}

    def execute(self, context):
        garment = getattr(_settings(context), 'skirt_garment', None)
        if garment is None:
            return {'CANCELLED'}
        result, error = skirt.component_cleanup(garment)
        if error:
            self.report({'WARNING'}, skirt.localize_issues(error, _is_japanese(context)))
            return {'CANCELLED'}
        self.report({'INFO'}, _t('Removed %(count)d owned fabric helpers; original garment restored.',
                                 '所有する布補助物を%(count)d件削除し、元の衣装を復元しました。', context) % {
            'count': result['removed_owned_helpers']})
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_component_audit(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.component_audit'
    bl_label = 'Fabric Configuration Consistency'
    bl_description = 'Check helper ownership, material/UV structure, mode, pin and mass only; geometry and penetration remain unverified.'
    bl_options = set()

    def execute(self, context):
        garment = getattr(_settings(context), 'skirt_garment', None)
        report = skirt.component_validate(garment)
        if not report['ok']:
            self.report({'WARNING'}, _t('Fabric configuration has %(count)d issue(s); no geometry pass is claimed.',
                                         '布設定に%(count)d件の問題があります。形状合格は主張しません。', context) % {
                'count': len(report['issues'])})
            return {'FINISHED'}
        self.report({'WARNING'}, _t('Fabric configuration is consistent; motion and penetration are unverified.',
                                     '布設定は整合しています。動作と貫通は未検証です。', context))
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_bridge_preview(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.bridge_preview'
    bl_label = 'Preview Cloth-to-Bone Sampling'
    bl_description = 'Inspect selected garment bone columns and topology-bound cloth anchors without creating output.'
    bl_options = set()

    def execute(self, context):
        result, error = skirt.bridge_preview(_settings(context), context)
        if error:
            self.report({'WARNING'}, skirt.bridge_localize(error, _is_japanese(context)))
            return {'CANCELLED'}
        self.report({'INFO'}, _t('Ready: %(count)d driven bones, %(roots)d fixed roots, frames %(start)d–%(end)d.',
                                 '準備完了: 駆動骨%(count)d本、固定根元%(roots)d本、フレーム%(start)d～%(end)d。', context) % {
            'count': len(result['driven_bones']), 'roots': len(result['fixed_roots']),
            'start': result['frame_start'], 'end': result['frame_end']})
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_bridge_bake(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.bridge_bake'
    bl_label = 'Bake Cloth to Garment Bones'
    bl_description = 'Sample the complete baked Cloth range first, then create only owned helper animation and terminal world-space bone constraints.'
    bl_options = {'UNDO'}

    def execute(self, context):
        result, error = skirt.bridge_bake(_settings(context), context)
        if error:
            self.report({'WARNING'}, skirt.bridge_localize(error, _is_japanese(context)))
            return {'CANCELLED'}
        self.report({'INFO'}, _t('Cloth baked to %(bones)d bones across %(frames)d frames; original animation retained.',
                                 '%(frames)dフレームのクロスを%(bones)d本の骨へ焼付けました。元のアニメーションは保持しています。', context) % {
            'bones': result['driven_bones'], 'frames': result['sampled_frames']})
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_bridge_mode(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.bridge_mode'
    bl_label = 'Switch Cloth-Bone Output'
    bl_description = 'Switch only the owned cloth-bone constraints; keep original Actions, slots, NLA, drivers and third-party constraints.'
    bl_options = {'UNDO'}
    mode: bpy.props.EnumProperty(items=(('STANDARD', 'Standard', ''),
                                       ('CLOTH_BAKED', 'Cloth Baked', '')), default='STANDARD')

    def execute(self, context):
        armature = getattr(_settings(context), 'bridge_target_armature', None)
        result, error = skirt.bridge_mode(armature, self.mode, context.scene)
        if error:
            self.report({'WARNING'}, skirt.bridge_localize(error, _is_japanese(context)))
            return {'CANCELLED'}
        self.report({'INFO'}, _t('Bone output mode: %(mode)s.', 'ボーン出力方式: %(mode)s。', context) % {
            'mode': (_t('Standard', '標準', context) if result['mode'] == 'STANDARD'
                     else _t('Cloth Baked', 'クロス焼付け', context))})
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_bridge_clear(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.bridge_clear'
    bl_label = 'Clear Owned Cloth-Bone Bake'
    bl_description = 'Remove only owned output constraints, helper rig and zero-user owned Action; retain the original animation and rest bones.'
    bl_options = {'UNDO'}

    def execute(self, context):
        armature = getattr(_settings(context), 'bridge_target_armature', None)
        result, error = skirt.bridge_clear(armature)
        if error:
            self.report({'WARNING'}, skirt.bridge_localize(error, _is_japanese(context)))
            return {'CANCELLED'}
        self.report({'INFO'}, _t('Removed %(count)d owned cloth-bone outputs.',
                                 '所有するボーン焼付け出力を%(count)d件解除しました。', context) % {
            'count': result['removed_constraints']})
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_skirt_save(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.skirt_save'
    bl_label = 'Save Skirt Setup'
    bl_description = 'Validate and store the reusable mapping on the mapped garment for Blender save/reload.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        if settings is None:
            return {'CANCELLED'}
        report, error = skirt.save_mapping(settings, context)
        if error:
            self.report({'WARNING'}, _t('Skirt setup cannot be saved: %(detail)s', 'スカート設定を保存できません: %(detail)s', context) % {'detail': skirt.localize_issues(error, _is_japanese(context))})
            return {'CANCELLED'}
        self.report({'INFO'}, _t('Saved the reusable skirt setup for %(name)s.', '%(name)s の再利用可能なスカート設定を保存しました。', context) % {'name': report['garment']})
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_skirt_adopt_simply(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.skirt_adopt_simply'
    bl_label = 'Move Cloth to Simply Cloth Studio'
    bl_description = 'Replace the existing Cloth of the garment with a Simply Cloth Studio stack, keeping its values, pins, colliders and switch. The original is recorded so it can be restored.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        garment = skirt.adoption_target(_settings(context), context)
        return garment is not None and garment.mode == 'OBJECT'

    def execute(self, context):
        garment = skirt.adoption_target(_settings(context), context)
        report, error = skirt.adopt_switch_to_simply(garment, context)
        if error:
            self.report({'WARNING'}, _t('The cloth was not moved; nothing was changed: %(detail)s',
                                         'クロスを載せ替えませんでした（何も変えていません）: %(detail)s', context)
                        % {'detail': skirt.localize_issues(error, _is_japanese(context))})
            return {'CANCELLED'}
        if report.get('already'):
            self.report({'INFO'}, _t('%(name)s already uses Simply Cloth Studio; nothing was changed.',
                                      '%(name)s は既に Simply Cloth Studio を使っています。何も変えていません。', context)
                        % {'name': report['object']})
            return {'FINISHED'}
        switch = report.get('switch') or {}
        message = _t('%(name)s now uses Simply Cloth Studio. Pinned vertices: %(pins)d. Switch: %(switch)s.',
                     '%(name)s を Simply Cloth Studio に載せ替えました。固定頂点: %(pins)d。切替: %(switch)s。', context) % {
            'name': report['object'], 'pins': report['pin'].get('vertices', 0),
            'switch': ('%s["%s"]' % (switch['object'], switch['property'])) if switch.get('property')
            else _t('Bones / Cloth buttons', 'ボーン／クロスのボタン', context)}
        problems = (len(report['readback_drift']) + len(report['sliders_missing'])
                    + len(report['direct_writes']) + len(report['not_restored']))
        self.report({'WARNING'} if problems else {'INFO'}, message)
        if report['readback_drift'] or report['sliders_missing']:
            names = [row[0] for row in report['readback_drift']] + list(report['sliders_missing'])
            self.report({'WARNING'}, _t('%(count)d value(s) differ from the original cloth after read-back: %(names)s',
                                         '読み返しで元のクロスと違う値が %(count)d 件あります: %(names)s', context)
                        % {'count': len(names), 'names': ', '.join(names)})
        if report['direct_writes']:
            self.report({'WARNING'}, _t('Written directly because a Simply slider could not hold the value (%(count)d): %(names)s',
                                         'Simply のスライダーで表せないため直接書いた値（%(count)d 件）: %(names)s', context)
                        % {'count': len(report['direct_writes']), 'names': ', '.join(report['direct_writes'])})
        if report['not_restored']:
            self.report({'WARNING'}, _t('Could not restore from the original cloth (%(count)d): %(names)s',
                                         '元のクロスから戻せなかった値（%(count)d 件）: %(names)s', context)
                        % {'count': len(report['not_restored']), 'names': ', '.join(report['not_restored'])})
        if report['pin'].get('vertices') and not report['pin'].get('layer'):
            self.report({'WARNING'}, _t('The pin is in SimplyPin but not held as a pin layer: %(why)s',
                                         '固定は SimplyPin に入れましたが、ピンの層にはできませんでした: %(why)s', context)
                        % {'why': report['pin'].get('layer_reason', '')})
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_skirt_adopt_simply_revert(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.skirt_adopt_simply_revert'
    bl_label = 'Restore Original Cloth'
    bl_description = 'Remove the Simply Cloth Studio stack added by Move Cloth and rebuild the recorded original Cloth with its values and drivers.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        garment = skirt.adoption_target(_settings(context), context)
        return (garment is not None and garment.mode == 'OBJECT'
                and skirt.REPLACED_CLOTH_KEY in garment.keys())

    def execute(self, context):
        garment = skirt.adoption_target(_settings(context), context)
        report, error = skirt.revert_simply_adoption(garment, context)
        if error:
            self.report({'WARNING'}, _t('The original cloth could not be restored: %(detail)s',
                                         '元のクロスに戻せませんでした: %(detail)s', context)
                        % {'detail': skirt.localize_issues(error, _is_japanese(context))})
            return {'CANCELLED'}
        if report.get('already'):
            self.report({'INFO'}, _t('Nothing to restore.', '戻す物はありません。', context))
            return {'FINISHED'}
        self.report({'INFO'}, _t('%(name)s uses its original cloth "%(cloth)s" again.',
                                  '%(name)s を元のクロス「%(cloth)s」に戻しました。', context)
                    % {'name': report['object'], 'cloth': report['restored']})
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_skirt_bake_check(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.skirt_bake_check'
    bl_label = 'Bake and Check Intersections'
    bl_description = 'Bake the garment cloth over its cache range and count garment vertices inside its colliders on sampled frames. The mode and frame are restored afterwards.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        garment = skirt.adoption_target(_settings(context), context)
        return garment is not None and garment.mode == 'OBJECT' and any(
            m.type == 'CLOTH' for m in garment.modifiers)

    def execute(self, context):
        garment = skirt.adoption_target(_settings(context), context)
        report, error = skirt.bake_and_check(garment, context)
        if error:
            self.report({'WARNING'}, _t('Bake and check failed: %(detail)s', 'ベイクと交差の確認に失敗しました: %(detail)s', context)
                        % {'detail': skirt.localize_issues(error, _is_japanese(context))})
            return {'CANCELLED'}
        level = {'WARNING'} if (report['max_inside'] or report['nan'] or not report['baked']) else {'INFO'}
        self.report(level, _t('Baked frames %(start)d-%(end)d. Most vertices inside colliders: %(inside)d (frame %(frame)d). Lowest point Z: %(low).3f m. Invalid positions: %(nan)d.',
                              'フレーム %(start)d〜%(end)d をベイクしました。体の内側に入った頂点の最大: %(inside)d（フレーム %(frame)d）。最も低い点の高さ: %(low).3f m。不正な位置: %(nan)d。', context) % {
            'start': report['frames'][0], 'end': report['frames'][1], 'inside': report['max_inside'],
            'frame': report['max_inside_frame'], 'low': report['lowest_z'], 'nan': report['nan']})
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_apply_colliders(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.apply_colliders'
    bl_label = 'Apply External Collider Setup'
    bl_description = 'Apply Simply Cloth Studio collision setup to the configured body and collider collection while preserving user object names and selection.'
    bl_options = {'UNDO'}

    def execute(self, context):
        if not _external_ready(self, context):
            return {'CANCELLED'}
        settings = _settings(context)
        state = _capture_selection(context)
        try:
            total, added = _apply_external_colliders(context, settings)
        except Exception as exc:
            self.report({'ERROR'}, _t('Colliders could not be applied: %(error)s', 'コライダーを適用できませんでした: %(error)s', context) % {'error': _error_detail(exc, context)})
            return {'CANCELLED'}
        finally:
            _restore_selection(context, state)
        message = _t('Collider setup added to %(added)s of %(total)s objects.', '%(total)s個中%(added)s個へコライダー設定を追加しました。', context) % {'added': added, 'total': total}
        _set_last_status(settings, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_smart_setup(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.smart_setup'
    bl_label = 'Smart Setup'
    bl_description = 'Run external cloth creation on target meshes, then apply Smart Cloth Suite quality, adaptive collision distances, optional top pins, and configured colliders as one undoable user operation.'
    bl_options = {'UNDO'}

    def execute(self, context):
        if not _external_ready(self, context):
            return {'CANCELLED'}
        settings = _settings(context)
        targets = _target_objects(context, require_cloth=False)
        if not targets:
            self.report({'WARNING'}, _t('Select at least one garment mesh.', 'ガーメントメッシュを1つ以上選択してください。', context))
            return {'CANCELLED'}
        state = _capture_selection(context)
        created = 0
        tuned = 0
        pinned = 0
        failures: list[str] = []
        try:
            for obj in targets:
                try:
                    _activate_only(context, obj)
                    if not _has_cloth(obj):
                        integration.call_external_operator(
                            'object.create_cloth',
                            context,
                            mode='CREATECLOTH',
                            modifiers_handling=str(getattr(settings, 'external_modifiers_handling', 'DO_NOTHING')),
                        )
                        created += 1
                    if _cloth_modifier(obj) is None:
                        raise RuntimeError(_t('External cloth modifier was not created.', '外部クロスのモディファイアを作成できませんでした。', context))
                    if bool(getattr(settings, 'apply_profile_after_setup', True)):
                        _apply_quality(obj, settings)
                    if bool(getattr(settings, 'auto_collision_after_setup', True)):
                        _apply_distance(obj, settings)
                    if bool(getattr(settings, 'auto_pin_top', True)) and _create_top_pin(obj, settings):
                        pinned += 1
                    tuned += 1
                except Exception as exc:
                    failures.append(f'{obj.name}: {_error_detail(exc, context)}')
            if bool(getattr(settings, 'apply_colliders_after_setup', True)):
                try:
                    _apply_external_colliders(context, settings, exclude=targets)
                except Exception as exc:
                    failures.append(_t('Colliders: %(error)s', 'コライダー: %(error)s', context) % {'error': _error_detail(exc, context)})
        finally:
            _restore_selection(context, state)
        message = _t(
            'Smart Setup completed: %(created)s created, %(tuned)s tuned, %(pinned)s pin groups.',
            'スマートセットアップ完了: 作成%(created)s、調整%(tuned)s、ピングループ%(pinned)s。',
            context,
        ) % {'created': created, 'tuned': tuned, 'pinned': pinned}
        _set_last_status(settings, message)
        if failures:
            self.report({'WARNING'}, message + ' ' + '; '.join(failures[:3]))
        else:
            self.report({'INFO'}, message)
        return {'FINISHED'} if tuned else {'CANCELLED'}


class SMARTCLOTHSUITE_OT_apply_quality_profile(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.apply_quality_profile'
    bl_label = 'Apply Quality Profile'
    bl_description = 'Apply the selected Smart Cloth Suite solver, collision, time-scale, and self-collision profile without replacing external fabric material settings.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        targets = _target_objects(context, require_cloth=True)
        if not targets:
            self.report({'WARNING'}, _t('No target cloth objects were found.', '対象クロスオブジェクトがありません。', context))
            return {'CANCELLED'}
        count = sum(1 for obj in targets if _apply_quality(obj, settings))
        message = _t('Quality profile applied to %(count)s cloth objects.', '%(count)s個のクロスへ品質プロファイルを適用しました。', context) % {'count': count}
        _set_last_status(settings, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_batch_preview(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.batch_preview'
    bl_label = 'Batch Preview State'
    bl_description = 'Apply or restore a reversible low-cost preview state for Cloth quality and heavy viewport modifiers.'
    bl_options = {'UNDO'}

    action: EnumProperty(
        items=(
            ('APPLY', 'Apply Preview', 'Save current states and apply fast preview values.'),
            ('RESTORE', 'Restore', 'Restore the exact states saved by Apply Preview.'),
        ),
        default='APPLY',
    )

    def execute(self, context):
        settings = _settings(context)
        targets = _target_objects(context, require_cloth=True)
        if not targets:
            self.report({'WARNING'}, _t('No target cloth objects were found.', '対象クロスオブジェクトがありません。', context))
            return {'CANCELLED'}
        changed = 0
        for obj in targets:
            cloth = _cloth_modifier(obj)
            if cloth is None:
                continue
            if self.action == 'RESTORE':
                raw = obj.get(PREVIEW_STATE_KEY)
                if not isinstance(raw, str):
                    continue
                try:
                    state = json.loads(raw)
                    cloth.settings.quality = int(state.get('quality', cloth.settings.quality))
                    cloth.collision_settings.collision_quality = int(state.get('collision_quality', cloth.collision_settings.collision_quality))
                    cloth.collision_settings.use_self_collision = bool(state.get('self_collision', cloth.collision_settings.use_self_collision))
                    for name, visible in dict(state.get('modifiers', {})).items():
                        mod = obj.modifiers.get(name)
                        if mod is not None:
                            mod.show_viewport = bool(visible)
                    del obj[PREVIEW_STATE_KEY]
                    changed += 1
                except Exception:
                    continue
            else:
                if PREVIEW_STATE_KEY in obj:
                    continue
                modifier_state = {}
                if bool(getattr(settings, 'preview_hide_heavy_modifiers', True)):
                    for mod in obj.modifiers:
                        if mod == cloth:
                            continue
                        if mod.type in {'SUBSURF', 'NODES', 'SOLIDIFY', 'CORRECTIVE_SMOOTH', 'SMOOTH', 'MULTIRES'}:
                            modifier_state[mod.name] = bool(mod.show_viewport)
                            mod.show_viewport = False
                state = {
                    'quality': int(cloth.settings.quality),
                    'collision_quality': int(cloth.collision_settings.collision_quality),
                    'self_collision': bool(cloth.collision_settings.use_self_collision),
                    'modifiers': modifier_state,
                }
                obj[PREVIEW_STATE_KEY] = json.dumps(state, ensure_ascii=False, sort_keys=True)
                cloth.settings.quality = int(getattr(settings, 'preview_quality', 3))
                cloth.collision_settings.collision_quality = 1
                cloth.collision_settings.use_self_collision = False
                changed += 1
        state = _t('restored', '復元', context) if self.action == 'RESTORE' else _t('applied', '適用', context)
        message = _t(
            'Preview state %(state)s for %(count)s cloth objects.',
            '%(count)s個のクロスでプレビュー状態を%(state)sしました。',
            context,
        ) % {'state': state, 'count': changed}
        _set_last_status(settings, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_auto_collision_distance(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.auto_collision_distance'
    bl_label = 'Auto Collision Distance'
    bl_description = 'Calculate cloth collision and self-collision distances from average world-space mesh edge length and configured clamps.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        targets = _target_objects(context, require_cloth=True)
        if not targets:
            self.report({'WARNING'}, _t('No target cloth objects were found.', '対象クロスオブジェクトがありません。', context))
            return {'CANCELLED'}
        count = sum(1 for obj in targets if _apply_distance(obj, settings))
        message = _t('Collision distance updated for %(count)s cloth objects.', '%(count)s個のクロスで衝突距離を更新しました。', context) % {'count': count}
        _set_last_status(settings, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_temporal_guard(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.temporal_guard'
    bl_label = 'Apply Temporal Guard'
    bl_description = 'Manually sample future evaluated cloth motion, restore the original frame, and increase collision padding only as much as measured motion requires.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        targets = _target_objects(context, require_cloth=True)
        if not targets:
            self.report({'WARNING'}, _t('No target cloth objects were found.', '対象クロスオブジェクトがありません。', context))
            return {'CANCELLED'}
        scene = context.scene
        original_frame = int(scene.frame_current)
        future = min(int(scene.frame_end), original_frame + int(getattr(settings, 'motion_sample_frames', 2)))
        if future == original_frame:
            self.report({'WARNING'}, _t('No future frame is available for sampling.', 'サンプリング可能な未来フレームがありません。', context))
            return {'CANCELLED'}
        depsgraph = context.evaluated_depsgraph_get()
        initial = {obj.name: _evaluated_world_vertices(obj, depsgraph) for obj in targets}
        try:
            scene.frame_set(future)
            try:
                context.view_layer.update()
            except Exception:
                pass
            depsgraph = context.evaluated_depsgraph_get()
            changed = 0
            for obj in targets:
                before = initial.get(obj.name, [])
                after = _evaluated_world_vertices(obj, depsgraph)
                distance = max((a - b).length for a, b in zip(after, before)) if before and after else 0.0
                base = _auto_distance(obj, settings)
                padded = max(base, distance * float(getattr(settings, 'temporal_guard_multiplier', 1.25)))
                padded = min(float(getattr(settings, 'max_collision_distance', 0.03)), padded)
                if _apply_distance(obj, settings, padded):
                    changed += 1
        finally:
            scene.frame_set(original_frame)
            try:
                context.view_layer.update()
            except Exception:
                pass
        message = _t('Temporal Guard updated %(count)s cloth objects.', '%(count)s個のクロスへ時間方向ガードを適用しました。', context) % {'count': changed}
        _set_last_status(settings, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_layer_clearance(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.layer_clearance'
    bl_label = 'Apply Layer Clearance'
    bl_description = 'Sort target garments by body proximity and add a controlled collision-distance gap for each outer garment layer.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        targets = _target_objects(context, require_cloth=True)
        if len(targets) < 1:
            self.report({'WARNING'}, _t('No target cloth objects were found.', '対象クロスオブジェクトがありません。', context))
            return {'CANCELLED'}
        body = getattr(settings, 'body_object', None)
        depsgraph = context.evaluated_depsgraph_get()
        bvh = _world_bvh(body, depsgraph) if body is not None else None
        order_values = []
        for obj in targets:
            points = _evaluated_world_vertices(obj, depsgraph, max_samples=256)
            distances = [d for d in (_nearest_distance(bvh, point) for point in points) if d is not None]
            value = sum(distances) / len(distances) if distances else float(obj.matrix_world.translation.z)
            order_values.append((value, obj))
        order_values.sort(key=lambda item: (item[0], item[1].name))
        gap = float(getattr(settings, 'layer_gap', 0.0015))
        for index, (_value, obj) in enumerate(order_values):
            base = _auto_distance(obj, settings)
            _apply_distance(obj, settings, min(float(getattr(settings, 'max_collision_distance', 0.03)), base + index * gap))
            obj[LAYER_ORDER_KEY] = int(index)
        message = _t('Layer clearance applied to %(count)s cloth objects.', '%(count)s個のクロスへレイヤークリアランスを適用しました。', context) % {'count': len(order_values)}
        _set_last_status(settings, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_build_analysis_maps(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.build_analysis_maps'
    bl_label = 'Build Analysis Maps'
    bl_description = 'Generate curvature risk, top-boundary pin suggestion, and body collision-proximity vertex groups without changing mesh topology.'
    bl_options = {'UNDO'}

    def execute(self, context):
        with _object_mode_for_mesh_writes(context):
            return self._build(context)

    def _build(self, context):
        settings = _settings(context)
        targets = _target_objects(context, require_cloth=False)
        if not targets:
            self.report({'WARNING'}, _t('No target mesh objects were found.', '対象メッシュオブジェクトがありません。', context))
            return {'CANCELLED'}
        body = getattr(settings, 'body_object', None)
        depsgraph = context.evaluated_depsgraph_get()
        bvh = _world_bvh(body, depsgraph) if body is not None else None
        proximity_limit = max(1.0e-8, float(getattr(settings, 'analysis_proximity_distance', 0.05)))
        built = 0
        for obj in targets:
            mesh = obj.data
            try:
                mesh.update()
            except Exception:
                pass
            count = len(mesh.vertices)
            if not count:
                continue
            adjacency = [[] for _ in range(count)]
            edge_face_counts = [0] * len(mesh.edges)
            for edge_index, edge in enumerate(mesh.edges):
                a, b = edge.vertices
                adjacency[a].append(b)
                adjacency[b].append(a)
            # Fast boundary detection using polygon edge keys.
            edge_lookup = {tuple(sorted(edge.vertices)): edge.index for edge in mesh.edges}
            for poly in mesh.polygons:
                vertices = list(poly.vertices)
                for i, a in enumerate(vertices):
                    b = vertices[(i + 1) % len(vertices)]
                    index = edge_lookup.get(tuple(sorted((a, b))))
                    if index is not None:
                        edge_face_counts[index] += 1
            boundary = set()
            for edge, faces in zip(mesh.edges, edge_face_counts):
                if faces == 1:
                    boundary.update(edge.vertices)

            normal_matrix = obj.matrix_world.to_3x3().inverted_safe().transposed()
            world_normals = []
            for vertex in mesh.vertices:
                normal = normal_matrix @ vertex.normal
                if normal.length_squared:
                    normal.normalize()
                world_normals.append(normal)
            curvature = [0.0] * count
            for index, neighbors in enumerate(adjacency):
                if not neighbors:
                    continue
                normal = world_normals[index]
                curvature[index] = min(1.0, sum(max(0.0, 1.0 - normal.dot(world_normals[other])) * 0.5 for other in neighbors) / len(neighbors))

            world_points = [obj.matrix_world @ vertex.co for vertex in mesh.vertices]
            heights = [point.z for point in world_points]
            low, high = min(heights), max(heights)
            span = max(1.0e-8, high - low)
            pin = [max(0.0, min(1.0, (height - (high - span * 0.20)) / (span * 0.20))) if index in boundary else 0.0 for index, height in enumerate(heights)]
            proximity = []
            for point in world_points:
                distance = _nearest_distance(bvh, point)
                proximity.append(max(0.0, 1.0 - distance / proximity_limit) if distance is not None else 0.0)
            _write_vertex_weights(obj, ANALYSIS_GROUP_CURVATURE, curvature)
            _write_vertex_weights(obj, ANALYSIS_GROUP_PIN, pin)
            _write_vertex_weights(obj, ANALYSIS_GROUP_PROXIMITY, proximity)
            built += 1
        message = _t('Analysis maps built for %(count)s mesh objects.', '%(count)s個のメッシュへ解析マップを作成しました。', context) % {'count': built}
        _set_last_status(settings, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_preflight(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.preflight'
    bl_label = 'Run Preflight'
    bl_description = 'Inspect cloth modifiers, topology, transforms, pins, cache state, and quality, then write a detailed report to the Smart Cloth Suite reports folder.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        objects = _target_objects(context, require_cloth=False)
        if not objects:
            self.report({'WARNING'}, _t('No target mesh objects were found.', '対象メッシュオブジェクトがありません。', context))
            return {'CANCELLED'}
        report = _preflight_report(context, objects)
        try:
            path = _write_report(report, settings, 'preflight')
        except Exception as exc:
            self.report({'ERROR'}, _t('Could not write the report: %(error)s', '報告を書き出せませんでした: %(error)s', context) % {'error': _error_detail(exc, context)})
            return {'CANCELLED'}
        summary = report['summary']
        message = _t(
            'Preflight: %(errors)s errors, %(warnings)s warnings.',
            'プリフライト: エラー%(errors)s件、警告%(warnings)s件。',
            context,
        ) % {'errors': summary['errors'], 'warnings': summary['warnings']}
        _set_last_status(settings, message, str(path))
        self.report({'WARNING'} if summary['errors'] else {'INFO'}, message)
        return {'FINISHED'}


class SMARTCLOTHSUITE_OT_repair_topology(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.repair_topology'
    bl_label = 'Safe Topology Repair'
    bl_description = 'Recalculate normals, merge only extremely close vertices, and optionally remove isolated vertices while preserving boundaries, sewing edges, and shape-key meshes.'
    bl_options = {'UNDO'}

    def execute(self, context):
        with _object_mode_for_mesh_writes(context):
            return self._repair(context)

    def _repair(self, context):
        settings = _settings(context)
        objects = _target_objects(context, require_cloth=False)
        repaired = 0
        skipped = []
        for obj in objects:
            mesh = obj.data
            if getattr(mesh, 'shape_keys', None) is not None:
                skipped.append(obj.name)
                continue
            merge_distance = _average_world_edge_length(obj) * float(getattr(settings, 'repair_merge_factor', 0.0005))
            # Convert world-scale distance back to a conservative local value.
            scale = max(1.0e-8, max(abs(float(v)) for v in obj.scale))
            merge_distance /= scale
            bmesh_module, _bvh_type = _simulation_api()
            bm = bmesh_module.new()
            try:
                bm.from_mesh(mesh)
                if merge_distance > 0.0:
                    bmesh_module.ops.remove_doubles(bm, verts=list(bm.verts), dist=merge_distance)
                if bool(getattr(settings, 'repair_remove_loose', False)):
                    isolated = [vert for vert in bm.verts if not vert.link_edges]
                    if isolated:
                        bmesh_module.ops.delete(bm, geom=isolated, context='VERTS')
                if bm.faces:
                    bmesh_module.ops.recalc_face_normals(bm, faces=list(bm.faces))
                bm.to_mesh(mesh)
                mesh.update()
                repaired += 1
            finally:
                bm.free()
        message = _t('Repaired %(repaired)s meshes. Skipped shape-key meshes: %(skipped)s.', '%(repaired)s個のメッシュを補正しました。シェイプキーメッシュのスキップ: %(skipped)s。', context) % {'repaired': repaired, 'skipped': len(skipped)}
        _set_last_status(settings, message)
        self.report({'INFO'}, message)
        return {'FINISHED'} if repaired else {'CANCELLED'}


@dataclass
class _SafeOutputObjectState:
    obj: object
    selected: bool
    hidden: bool
    hide_viewport: bool
    hide_render: bool
    data: object
    cloth_modifier: object | None
    cloth_name: str
    cloth_index: int
    cloth_values: dict[str, dict[str, object]]


@dataclass
class _SafeOutputCacheState:
    obj: object
    modifier: object
    point_cache: object
    was_baked: bool


def _writable_rna_snapshot(owner) -> dict[str, object]:
    """Capture in-memory writable RNA values without coercion or name lookup."""
    result: dict[str, object] = {}
    rna = getattr(owner, 'bl_rna', None)
    for prop in getattr(rna, 'properties', ()) if rna is not None else ():
        name = str(getattr(prop, 'identifier', '') or '')
        if not name or name == 'rna_type' or bool(getattr(prop, 'is_readonly', False)):
            continue
        kind = str(getattr(prop, 'type', '') or '').upper()
        if kind not in {'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM', 'POINTER'}:
            continue
        try:
            value = getattr(owner, name)
        except Exception:
            continue
        if kind == 'POINTER':
            result[name] = value
        elif type(value) in {bool, int, float, str}:
            result[name] = value
        elif isinstance(value, set):
            result[name] = set(value)
        else:
            try:
                result[name] = tuple(value)
            except Exception:
                continue
    return result


def _restore_writable_rna(owner, values: dict[str, object]) -> None:
    for name, value in dict(values or {}).items():
        try:
            # Rewriting an unchanged value can reset state; use_disk_cache drops a baked cache.
            current = getattr(owner, str(name))
            if current == value or (isinstance(value, tuple) and tuple(current) == value):
                continue
            setattr(owner, str(name), value)
        except Exception:
            pass


def _capture_cloth_rna(modifier) -> dict[str, dict[str, object]]:
    if modifier is None:
        return {}
    result = {'modifier': _writable_rna_snapshot(modifier)}
    for name in ('settings', 'collision_settings', 'point_cache', 'effector_weights'):
        nested = getattr(modifier, name, None)
        if nested is not None:
            result[name] = _writable_rna_snapshot(nested)
    return result


def _restore_cloth_rna(modifier, values: dict[str, dict[str, object]]) -> None:
    if modifier is None:
        return
    payload = dict(values or {})
    _restore_writable_rna(modifier, payload.get('modifier', {}))
    for name in ('settings', 'collision_settings', 'point_cache', 'effector_weights'):
        nested = getattr(modifier, name, None)
        if nested is not None:
            _restore_writable_rna(nested, payload.get(name, {}))


_ACTIVE_SAFE_OUTPUT = None
_NON_SHAPING_MODIFIER_TYPES = frozenset({'COLLISION', 'SURFACE', 'PARTICLE_SYSTEM'})


def cancel_active_safe_output_transaction() -> bool:
    """Cancel only the exact active Safe Output operator transaction."""
    operator = _ACTIVE_SAFE_OUTPUT
    if operator is None:
        return False
    try:
        operator._finish_modal(getattr(bpy, 'context', None), success=False)
    except Exception:
        return False
    return True


class SMARTCLOTHSUITE_OT_safe_output(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.safe_output'
    bl_label = 'Safe Bake / Finish'
    bl_description = 'Run preflight, then process one target per event. Esc or an exception restores cache and UI state.'
    bl_options = {'UNDO'}

    action: EnumProperty(
        items=(
            ('BAKE', 'Bake', 'Bake only the selected target Cloth point caches.'),
            ('FINISH', 'Finish', 'Finish staged target copies and commit only after all targets succeed.'),
            ('FREE_BAKE', 'Free Bake', 'Free only target Cloth point caches with transactional rebake on cancellation.'),
        ),
        default='BAKE',
    )

    @classmethod
    def poll(cls, context):
        return getattr(context, 'scene', None) is not None

    def _tag_owned(self, data, kind: str):
        if data is None:
            raise RuntimeError(_t('Cannot own missing %(kind)s resource', '存在しない %(kind)s データは管理できません', None) % {'kind': kind})
        data['_scs_owner'] = lifecycle.OWNER_ID
        data['_scs_owner_uuid'] = self._transaction_token
        data['_scs_generation'] = self._generation
        if not self._owns_marker(data):
            raise RuntimeError(_t('Could not verify %(kind)s ownership marker', '%(kind)s データの管理の印を確かめられません', None) % {'kind': kind})
        self._owned_resources[id(data)] = (data, str(kind))
        return data

    def _owns_marker(self, data) -> bool:
        try:
            return bool(
                data is not None
                and data.get('_scs_owner') == lifecycle.OWNER_ID
                and data.get('_scs_owner_uuid') == self._transaction_token
                and int(data.get('_scs_generation', -1)) == self._generation
            )
        except Exception:
            return False

    def _owns(self, data) -> bool:
        entry = self._owned_resources.get(id(data))
        return bool(entry is not None and entry[0] is data and self._owns_marker(data))

    def _forget_owned(self, data, *, clear_marker: bool) -> None:
        entry = self._owned_resources.get(id(data))
        if entry is None or entry[0] is not data:
            return
        if clear_marker and self._owns_marker(data):
            for key in ('_scs_generation', '_scs_owner_uuid', '_scs_owner'):
                try:
                    del data[key]
                except Exception:
                    pass
        self._owned_resources.pop(id(data), None)

    def _capture(self, context, targets):
        scene = context.scene
        active = getattr(context, 'active_object', None)
        self._selection_state = _capture_selection(context)
        self._active_identity = active
        self._object_states = []
        self._cache_states = []
        target_ids = {id(obj) for obj in tuple(targets or ())}
        for obj in tuple(getattr(scene, 'objects', ()) or ()):
            try:
                hidden = bool(obj.hide_get())
            except Exception:
                hidden = False
            cloth = _cloth_modifier(obj)
            cloth_values = _capture_cloth_rna(cloth) if cloth is not None else {}
            cloth_index = -1
            if cloth is not None:
                try:
                    cloth_index = tuple(getattr(obj, 'modifiers', ()) or ()).index(cloth)
                except Exception:
                    cloth_index = -1
            self._object_states.append(_SafeOutputObjectState(
                obj=obj,
                selected=bool(obj.select_get()) if hasattr(obj, 'select_get') else False,
                hidden=hidden,
                hide_viewport=bool(getattr(obj, 'hide_viewport', False)),
                hide_render=bool(getattr(obj, 'hide_render', False)),
                data=getattr(obj, 'data', None),
                cloth_modifier=cloth,
                cloth_name=str(getattr(cloth, 'name', '') or ''),
                cloth_index=cloth_index,
                cloth_values=cloth_values,
            ))
            if cloth is not None and id(obj) in target_ids:
                cache = getattr(cloth, 'point_cache', None)
                if cache is not None:
                    self._cache_states.append(_SafeOutputCacheState(
                        obj=obj,
                        modifier=cloth,
                        point_cache=cache,
                        was_baked=bool(getattr(cache, 'is_baked', False)),
                    ))
        self._targets = list(targets)

    def _restore_ui(self, context) -> bool:
        ok = True
        for state in getattr(self, '_object_states', ()):
            obj = state.obj
            try:
                obj.hide_viewport = state.hide_viewport
                obj.hide_render = state.hide_render
                obj.hide_set(state.hidden)
                obj.select_set(state.selected)
            except Exception:
                ok = False
        try:
            _restore_selection(context, self._selection_state)
        except Exception:
            ok = False
        return ok

    def _cache_operator(self, context, cache, *, bake: bool):
        with bpy.context.temp_override(scene=context.scene, point_cache=cache):
            if bake:
                return bpy.ops.ptcache.bake('EXEC_DEFAULT', bake=True)
            return bpy.ops.ptcache.free_bake('EXEC_DEFAULT')

    def _restore_caches(self, context) -> bool:
        """Restore only exact target cache identities, including partial bakes."""
        ok = True
        for state in getattr(self, '_cache_states', ()):
            cache = state.point_cache
            try:
                current = bool(getattr(cache, 'is_baked', False))
                if state.was_baked:
                    if not current:
                        # Clear any partial files first, then rebuild the cache
                        # that existed before the transaction.
                        try:
                            self._cache_operator(context, cache, bake=False)
                        except Exception:
                            pass
                        result = self._cache_operator(context, cache, bake=True)
                        if 'CANCELLED' in set(result or ()):
                            ok = False
                else:
                    # Free is attempted even when is_baked is false because an
                    # interrupted bake may leave partial target-cache data.
                    try:
                        result = self._cache_operator(context, cache, bake=False)
                        if 'CANCELLED' in set(result or ()):
                            ok = False
                    except Exception:
                        ok = False
            except Exception:
                ok = False
        return ok

    def _discard_owned_record(self, data) -> None:
        entry = self._owned_resources.get(id(data))
        if entry is not None and entry[0] is data:
            self._owned_resources.pop(id(data), None)

    def _remove_owned_object(self, obj) -> bool:
        if not self._owns(obj):
            return True
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            return False
        self._discard_owned_record(obj)
        return True

    def _remove_owned_mesh(self, mesh) -> bool:
        if not self._owns(mesh):
            return True
        try:
            if int(getattr(mesh, 'users', 0)) != 0:
                return False
            bpy.data.meshes.remove(mesh)
        except Exception:
            return False
        self._discard_owned_record(mesh)
        return True

    def _remove_owned_collection(self, collection) -> bool:
        if not self._owns(collection):
            return True
        parent = getattr(self, '_stage_parent', None)
        try:
            if parent is not None and collection in tuple(getattr(parent, 'children', ()) or ()):
                parent.children.unlink(collection)
        except Exception:
            return False
        try:
            if len(getattr(collection, 'objects', ()) or ()) != 0:
                return False
            bpy.data.collections.remove(collection)
        except Exception:
            return False
        self._discard_owned_record(collection)
        return True

    def _cleanup_staging(self) -> bool:
        """Remove only exact UUID/generation-owned temporary resources."""
        ok = True
        records = list(getattr(self, '_owned_resources', {}).values())
        for data, kind in reversed(records):
            if kind == 'OBJECT':
                ok = self._remove_owned_object(data) and ok
        records = list(getattr(self, '_owned_resources', {}).values())
        for data, kind in reversed(records):
            if kind == 'MESH':
                ok = self._remove_owned_mesh(data) and ok
        collection = getattr(self, '_stage_collection', None)
        if collection is not None:
            ok = self._remove_owned_collection(collection) and ok
        # Sweep any exact temporary collection that was created before the
        # ordinary staging list could be updated. No bpy.data/name scan occurs.
        records = list(getattr(self, '_owned_resources', {}).values())
        for data, kind in reversed(records):
            if kind == 'COLLECTION':
                ok = self._remove_owned_collection(data) and ok
        self._staged = []
        self._stage_collection = None
        self._stage_parent = None
        remaining_temporary = [
            (data, kind)
            for data, kind in getattr(self, '_owned_resources', {}).values()
            if kind in {'OBJECT', 'MESH', 'COLLECTION'} and self._owns(data)
        ]
        return bool(ok and not remaining_temporary)

    def _rollback_commit(self) -> bool:
        """Restore exact pre-transaction object data and Cloth RNA snapshots."""
        ok = True
        state_by_object = {id(state.obj): state for state in getattr(self, '_object_states', ())}
        for original, committed_data in reversed(tuple(getattr(self, '_committed_data', ()) or ())):
            state = state_by_object.get(id(original))
            if state is not None:
                try:
                    if state.data is not None:
                        original.data = state.data
                except Exception:
                    ok = False
                modifiers = tuple(getattr(original, 'modifiers', ()) or ())
                captured_present = state.cloth_modifier is not None and any(modifier == state.cloth_modifier for modifier in modifiers)
                if state.cloth_modifier is not None and not captured_present:
                    try:
                        modifier = original.modifiers.new(name=state.cloth_name or EXTERNAL_CLOTH_MODIFIER, type='CLOTH')
                        _restore_cloth_rna(modifier, state.cloth_values)
                        for cache_state in getattr(self, '_cache_states', ()):
                            if cache_state.obj == original:
                                cache_state.modifier = modifier
                                cache_state.point_cache = modifier.point_cache
                        try:
                            current_index = tuple(original.modifiers).index(modifier)
                            target_index = max(0, min(int(state.cloth_index), len(original.modifiers) - 1))
                            if state.cloth_index >= 0 and current_index != target_index:
                                original.modifiers.move(current_index, target_index)
                        except Exception:
                            ok = False
                    except Exception:
                        ok = False
                elif captured_present:
                    _restore_cloth_rna(state.cloth_modifier, state.cloth_values)
            if self._owns(committed_data):
                try:
                    if int(getattr(committed_data, 'users', 0)) == 0:
                        bpy.data.meshes.remove(committed_data)
                        self._discard_owned_record(committed_data)
                    else:
                        ok = False
                except Exception:
                    ok = False
        self._committed_data = []
        return ok

    def _finalize_commit(self) -> int:
        """Retire exact captured target Cloth modifiers, then release result ownership."""
        target_ids = {id(obj) for obj in tuple(getattr(self, '_targets', ()) or ())}
        states = [state for state in getattr(self, '_object_states', ()) if id(state.obj) in target_ids]
        for state in states:
            captured = state.cloth_modifier
            if captured is None:
                continue
            modifiers = tuple(getattr(state.obj, 'modifiers', ()) or ())
            if not any(modifier == captured for modifier in modifiers):
                raise RuntimeError(_t('Captured Cloth modifier identity changed before commit: %(name)s', '確定の前にクロスのモディファイアが別の物に変わりました: %(name)s', None) % {'name': getattr(state.obj, "name", "<object>")})
        # Only the modifiers still on the finished copy stay; the rest are in the mesh.
        for state in states:
            kept = self._kept_modifiers.get(id(state.obj), ())
            for modifier in tuple(state.obj.modifiers):
                if modifier.name not in kept:
                    state.obj.modifiers.remove(modifier)
        count = len(tuple(getattr(self, '_committed_data', ()) or ()))
        for _original, committed_data in tuple(getattr(self, '_committed_data', ()) or ()):
            if not self._owns(committed_data):
                raise RuntimeError(_t('Committed mesh ownership changed before finalization', '仕上げの途中で確定したメッシュの管理の印が変わりました', None))
            self._forget_owned(committed_data, clear_marker=True)
        self._committed_data = []
        return count

    def _begin_undo_group(self, context) -> None:
        self._undo_group_open = False
        wm = getattr(context, 'window_manager', None) if context is not None else None
        begin = getattr(wm, 'undo_group_begin', None) if wm is not None else None
        if callable(begin):
            try:
                begin()
                self._undo_group_open = True
            except Exception:
                self._undo_group_open = False

    def _end_undo_group(self, context) -> None:
        if not bool(getattr(self, '_undo_group_open', False)):
            return
        self._undo_group_open = False
        wm = getattr(context, 'window_manager', None) if context is not None else None
        end = getattr(wm, 'undo_group_end', None) if wm is not None else None
        if callable(end):
            try:
                end()
            except Exception:
                pass

    def _finish_modal(self, context, *, success: bool, message: str = ''):
        global _ACTIVE_SAFE_OUTPUT
        if bool(getattr(self, '_transaction_finished', False)):
            return {'FINISHED'} if bool(getattr(self, '_transaction_succeeded', False)) else {'CANCELLED'}
        self._transaction_finished = True
        ctx = context or getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        timer = getattr(self, '_event_timer', None)
        if wm is not None and timer is not None:
            try:
                wm.event_timer_remove(timer)
            except Exception:
                pass
        self._event_timer = None
        try:
            if wm is not None:
                wm.progress_end()
        except Exception:
            pass

        final_success = bool(success)
        final_message = str(message or '')
        try:
            if not final_success:
                rollback_ok = self._rollback_commit()
                cache_ok = self._restore_caches(ctx) if ctx is not None else False
                cleanup_ok = self._cleanup_staging()
                final_success = False
                if not rollback_ok or not cache_ok or not cleanup_ok:
                    final_message = _t(
                        'Safe output was cancelled; one or more exact owned resources could not be fully restored.',
                        '安全な出力をキャンセルしましたが、一部の自己所有リソースを完全に復元できませんでした。',
                        ctx,
                    )
            else:
                cleanup_ok = self._cleanup_staging()
                if not cleanup_ok:
                    final_success = False
                    self._rollback_commit()
                    if ctx is not None:
                        self._restore_caches(ctx)
                    self._cleanup_staging()
                    final_message = _t(
                        'Safe output could not commit because temporary owned resources could not be released; state was restored.',
                        '自己所有の一時リソースを解放できなかったため安全な出力を確定せず、状態を復元しました。',
                        ctx,
                    )
                elif self.action == 'FINISH':
                    try:
                        self._completed = self._finalize_commit()
                    except Exception:
                        final_success = False
                        self._rollback_commit()
                        if ctx is not None:
                            self._restore_caches(ctx)
                        self._cleanup_staging()
                        final_message = _t(
                            'Safe Finish could not finalize exact target resources; state was restored.',
                            '安全な仕上げで対象リソースを確定できなかったため、状態を復元しました。',
                            ctx,
                        )
        except Exception:
            final_success = False
            try:
                self._rollback_commit()
            except Exception:
                pass
            if ctx is not None:
                try:
                    self._restore_caches(ctx)
                except Exception:
                    pass
            try:
                self._cleanup_staging()
            except Exception:
                pass
            final_message = _t(
                'Safe output failed during finalization and attempted an exact rollback.',
                '安全な出力の確定中に失敗し、自己所有対象の厳密なロールバックを実行しました。',
                ctx,
            )
        finally:
            # Selection, active object, mode, visibility, and frame are restored
            # last so rollback/cache operators cannot disturb final UI state.
            if ctx is not None:
                try:
                    if not self._restore_ui(ctx):
                        final_success = False
                except Exception:
                    final_success = False
                try:
                    self._end_undo_group(ctx)
                except Exception:
                    final_success = False
            if _ACTIVE_SAFE_OUTPUT is self:
                _ACTIVE_SAFE_OUTPUT = None

        self._transaction_succeeded = bool(final_success)
        settings = _settings(ctx) if ctx is not None else None
        if final_message:
            _set_last_status(settings, final_message, str(getattr(self, '_report_path', '') or ''))
            self.report({'INFO'} if final_success else {'WARNING'}, final_message)
        return {'FINISHED'} if final_success else {'CANCELLED'}

    def _frozen_cloth_mesh(self, context, original):
        """Return a mesh of the Cloth result shown at this frame, without later modifiers."""
        _activate_only(context, original)
        cloth = _cloth_modifier(original)
        name = getattr(original, 'name', '<object>')
        if not bool(cloth.show_viewport):
            raise RuntimeError(_t('Cloth modifier is disabled in the viewport: %(name)s', 'クロス モディファイアがビューポートで無効です: %(name)s', context) % {'name': name})
        cache = cloth.point_cache
        baked_here = not bool(cache.is_baked)
        if baked_here:
            result = self._cache_operator(context, cache, bake=True)
            if 'CANCELLED' in set(result or ()):
                raise RuntimeError(_t('Bake cancelled: %(name)s', 'ベイクを取り消しました: %(name)s', context) % {'name': name})
        modifiers = tuple(original.modifiers)
        later = [modifier for modifier in modifiers[modifiers.index(cloth) + 1:] if modifier.show_viewport]
        try:
            for modifier in later:
                modifier.show_viewport = False
            depsgraph = context.evaluated_depsgraph_get()
            evaluated = original.evaluated_get(depsgraph)
            if not bool(evaluated.is_evaluated):
                raise RuntimeError(_t('Cloth result is not available: %(name)s', 'クロスの結果を取得できません: %(name)s', context) % {'name': name})
            return bpy.data.meshes.new_from_object(evaluated, preserve_all_data_layers=True, depsgraph=depsgraph)
        finally:
            for modifier in later:
                modifier.show_viewport = True
            if baked_here:
                self._cache_operator(context, cache, bake=False)

    def _prepare_staged_finish(self, context, original):
        if getattr(self, '_stage_collection', None) is None:
            collection = bpy.data.collections.new(f'SCS Finish Stage {self._transaction_token[:8]}')
            self._tag_owned(collection, 'COLLECTION')
            parent = context.scene.collection
            parent.children.link(collection)
            self._stage_collection = collection
            self._stage_parent = parent
        staged = original.copy()
        self._tag_owned(staged, 'OBJECT')
        frozen = self._frozen_cloth_mesh(context, original)
        self._tag_owned(frozen, 'MESH')
        frozen.name = original.data.name
        # The frozen mesh already holds the Cloth and every modifier before it.
        # The copy never simulates, so its Cloth cannot touch the source cache.
        modifiers = tuple(staged.modifiers)
        cloth_index = modifiers.index(_cloth_modifier(staged))
        for modifier in modifiers[:cloth_index + 1]:
            if modifier.type == 'CLOTH' or (modifier.show_viewport and modifier.type not in _NON_SHAPING_MODIFIER_TYPES):
                staged.modifiers.remove(modifier)
        staged.data = frozen
        self._stage_collection.objects.link(staged)
        self._staged.append((original, staged))
        _activate_only(context, staged)
        result = integration.call_external_operator('object.finish_cloth', context, mode='APPLYCLOTH', apply_all_modifiers=False)
        if 'CANCELLED' in set(result or ()):
            raise RuntimeError(_t('External finish was cancelled', '外部クロスの仕上げがキャンセルされました', context))

    def _commit_staged_finish(self) -> int:
        """Assign exact staged mesh copies; final modifier retirement happens later."""
        prepared: list[tuple[object, object]] = []
        for original, staged in tuple(self._staged):
            result_data = getattr(staged, 'data', None)
            if result_data is None:
                raise RuntimeError(_t('No staged mesh result for %(name)s', '仕上げたメッシュの結果がありません: %(name)s', None) % {'name': getattr(original, "name", "<object>")})
            committed_data = result_data.copy()
            self._tag_owned(committed_data, 'COMMITTED_MESH')
            prepared.append((original, committed_data))
            self._kept_modifiers[id(original)] = {modifier.name for modifier in staged.modifiers}
        try:
            for original, committed_data in prepared:
                original.data = committed_data
                self._committed_data.append((original, committed_data))
        except Exception:
            self._rollback_commit()
            for _original, committed_data in prepared:
                if self._owns(committed_data):
                    try:
                        if int(getattr(committed_data, 'users', 0)) == 0:
                            bpy.data.meshes.remove(committed_data)
                            self._discard_owned_record(committed_data)
                    except Exception:
                        pass
            raise
        return len(self._committed_data)

    def _process_one(self, context):
        if self._index >= len(self._targets):
            if self.action == 'FINISH':
                self._completed = self._commit_staged_finish()
            label = {'BAKE': ('Bake', 'ベイク'), 'FINISH': ('Finish', '仕上げ'), 'FREE_BAKE': ('Free Bake', 'ベイク解除')}[self.action]
            message = _t('%(action)s completed for %(count)s cloth objects.', '%(count)s個のクロスで%(action)sを完了しました。', context) % {'action': _t(label[0], label[1], context), 'count': self._completed}
            return self._finish_modal(context, success=True, message=message)
        obj = self._targets[self._index]
        self._index += 1
        if self.action == 'FINISH':
            self._prepare_staged_finish(context, obj)
            self._completed += 1
        else:
            cloth = _cloth_modifier(obj)
            cache = getattr(cloth, 'point_cache', None) if cloth is not None else None
            if cache is not None:
                _activate_only(context, obj)
                is_baked = bool(getattr(cache, 'is_baked', False))
                if self.action == 'BAKE' and not is_baked:
                    result = self._cache_operator(context, cache, bake=True)
                    if 'CANCELLED' in set(result or ()):
                        raise RuntimeError(_t('Bake cancelled: %(name)s', 'ベイクを取り消しました: %(name)s', context) % {'name': obj.name})
                elif self.action == 'FREE_BAKE' and is_baked:
                    result = self._cache_operator(context, cache, bake=False)
                    if 'CANCELLED' in set(result or ()):
                        raise RuntimeError(_t('Free bake cancelled: %(name)s', 'ベイク解除を取り消しました: %(name)s', context) % {'name': obj.name})
                self._completed += 1
        try:
            context.window_manager.progress_update(self._index)
        except Exception:
            pass
        return {'RUNNING_MODAL'}

    def _begin(self, context):
        global _ACTIVE_SAFE_OUTPUT
        if _ACTIVE_SAFE_OUTPUT not in (None, self):
            self.report({'ERROR'}, _t('Another Safe Output transaction is already running.', '別の安全な出力トランザクションが実行中です。', context))
            return {'CANCELLED'}
        settings = _settings(context)
        targets = _target_objects(context, require_cloth=True)
        if not targets:
            self.report({'WARNING'}, _t('No target cloth objects were found.', '対象クロスオブジェクトがありません。', context))
            return {'CANCELLED'}
        try:
            report = _preflight_report(context, targets)
            self._report_path = _write_report(report, settings, 'output_preflight')
        except Exception as exc:
            self.report({'ERROR'}, _t('Could not write the report: %(error)s', '報告を書き出せませんでした: %(error)s', context) % {'error': _error_detail(exc, context)})
            return {'CANCELLED'}
        errors = int(report['summary']['errors'])
        if self.action != 'FREE_BAKE' and errors and bool(getattr(settings, 'stop_on_preflight_error', True)):
            message = _t('Output stopped: preflight found %(errors)s errors.', '出力を停止しました。プリフライトで%(errors)s件のエラーを検出しました。', context) % {'errors': errors}
            _set_last_status(settings, message, str(self._report_path))
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        if self.action == 'FINISH' and not _external_ready(self, context):
            return {'CANCELLED'}
        self._transaction_token = uuid.uuid4().hex
        lease = lifecycle.current_lease(require_current=False)
        self._generation = int(getattr(lease, 'generation', 0) or 0)
        if self._generation <= 0:
            self.report({'ERROR'}, _t('Safe output has no active Suite generation.', '安全な出力に有効なSuite世代がありません。', context))
            return {'CANCELLED'}
        self._owned_resources = {}
        self._staged = []
        self._committed_data = []
        self._kept_modifiers = {}
        self._stage_collection = None
        self._stage_parent = None
        self._index = 0
        self._completed = 0
        self._event_timer = None
        self._transaction_finished = False
        self._transaction_succeeded = False
        self._undo_group_open = False
        self._capture(context, targets)
        self._begin_undo_group(context)
        _ACTIVE_SAFE_OUTPUT = self
        wm = getattr(context, 'window_manager', None)
        window = getattr(context, 'window', None)
        if wm is None or window is None:
            try:
                while True:
                    result = self._process_one(context)
                    if result != {'RUNNING_MODAL'}:
                        return result
            except Exception as exc:
                return self._finish_modal(context, success=False, message=_t('Safe output failed and was restored: %(error)s', '安全な出力に失敗し、状態を復元しました: %(error)s', context) % {'error': _error_detail(exc, context)})
        try:
            wm.progress_begin(0, max(1, len(targets)))
            self._event_timer = wm.event_timer_add(0.01, window=window)
            wm.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        except Exception:
            return self._finish_modal(context, success=False, message=_t('Safe output could not start.', '安全な出力を開始できませんでした。', context))

    def invoke(self, context, event):
        del event
        return self._begin(context)

    def execute(self, context):
        return self._begin(context)

    def modal(self, context, event):
        if bool(getattr(self, '_transaction_finished', False)):
            return self._finish_modal(context, success=False)
        if event.type in {'ESC', 'RIGHTMOUSE'}:
            return self._finish_modal(context, success=False, message=_t('Safe output was cancelled and restored.', '安全な出力をキャンセルし、状態を復元しました。', context))
        if event.type != 'TIMER':
            return {'RUNNING_MODAL'}
        try:
            return self._process_one(context)
        except Exception as exc:
            return self._finish_modal(context, success=False, message=_t('Safe output failed and was restored: %(error)s', '安全な出力に失敗し、状態を復元しました: %(error)s', context) % {'error': _error_detail(exc, context)})

    def cancel(self, context):
        self._finish_modal(context, success=False)



class SMARTCLOTHSUITE_OT_open_data_folder(bpy.types.Operator):
    bl_idname = 'smart_cloth_suite.open_data_folder'
    bl_label = 'Open Smart Cloth Suite Folder'
    bl_description = 'Open Blender config/Smart_Cloth_Suite containing persistent settings and generated reports.'
    bl_options = {'INTERNAL'}

    def execute(self, context):
        try:
            from .. import storage
            path = storage.smart_suite_config_dir(create=True)
            bpy.ops.wm.path_open(filepath=str(path))
            return {'FINISHED'}
        except Exception:
            self.report({'WARNING'}, _t('Could not open the folder.', 'フォルダーを開けませんでした。', context))
            return {'CANCELLED'}


CLASSES = (
    SMARTCLOTHSUITE_OT_refresh_external_status,
    SMARTCLOTHSUITE_OT_open_external_preferences,
    SMARTCLOTHSUITE_OT_apply_colliders,
    SMARTCLOTHSUITE_OT_skirt_preview,
    SMARTCLOTHSUITE_OT_skirt_setup,
    SMARTCLOTHSUITE_OT_skirt_mode,
    SMARTCLOTHSUITE_OT_skirt_audit,
    SMARTCLOTHSUITE_OT_skirt_outside,
    SMARTCLOTHSUITE_OT_component_preview,
    SMARTCLOTHSUITE_OT_component_apply,
    SMARTCLOTHSUITE_OT_component_mode,
    SMARTCLOTHSUITE_OT_component_cleanup,
    SMARTCLOTHSUITE_OT_component_audit,
    SMARTCLOTHSUITE_OT_bridge_preview,
    SMARTCLOTHSUITE_OT_bridge_bake,
    SMARTCLOTHSUITE_OT_bridge_mode,
    SMARTCLOTHSUITE_OT_bridge_clear,
    SMARTCLOTHSUITE_OT_skirt_save,
    SMARTCLOTHSUITE_OT_skirt_adopt_simply,
    SMARTCLOTHSUITE_OT_skirt_adopt_simply_revert,
    SMARTCLOTHSUITE_OT_skirt_bake_check,
    SMARTCLOTHSUITE_OT_smart_setup,
    SMARTCLOTHSUITE_OT_apply_quality_profile,
    SMARTCLOTHSUITE_OT_batch_preview,
    SMARTCLOTHSUITE_OT_auto_collision_distance,
    SMARTCLOTHSUITE_OT_temporal_guard,
    SMARTCLOTHSUITE_OT_layer_clearance,
    SMARTCLOTHSUITE_OT_build_analysis_maps,
    SMARTCLOTHSUITE_OT_preflight,
    SMARTCLOTHSUITE_OT_repair_topology,
    SMARTCLOTHSUITE_OT_safe_output,
    SMARTCLOTHSUITE_OT_open_data_folder,
)
