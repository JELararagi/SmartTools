# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Compact compatibility help catalog.

The primary section help is rendered by :mod:`help`.  This catalog keeps the
legacy common help API grounded in the current external-companion architecture.
"""

from __future__ import annotations

_GROUPS = {
    'overview': {
        'title_en': 'Smart Cloth Suite',
        'title_ja': 'Smart Cloth Suite',
        'overview_en': ['Companion workflow for a separately installed Simply Cloth Studio. Smart Cloth Suite adds batch setup, performance controls, adaptive collision spacing, analysis, diagnostics, and guarded output without bundling the external implementation.'],
        'overview_ja': ['別途インストールされた Simply Cloth Studio と併用し、外部実装を内包せずに、一括セットアップ、軽量化、自動衝突間隔、解析、診断、安全確認付き出力を追加する連携ワークフローです。'],
        'usage_en': ['Enable Simply Cloth Studio separately, confirm External Tool Integration is ready, configure targets, then run Smart Setup or the individual extension commands.'],
        'usage_ja': ['Simply Cloth Studio を別途有効化し、「外部ツール連携」の使用可能状態を確認して対象を設定後、スマートセットアップまたは個別の拡張コマンドを実行します。'],
        'settings': [],
        'operators': [],
    },
    'always_on': {
        'title_en': 'Always-on Toggles',
        'title_ja': '常時機能切り替え',
        'overview_en': ['Controls N-panel persistence and optional Jiggle runtime callbacks/overlays.'],
        'overview_ja': ['Nパネル設定保存と、任意のJiggleランタイムコールバック / オーバーレイを制御します。'],
        'usage_en': ['Keep only the runtime items required for the current task enabled.'],
        'usage_ja': ['現在の作業に必要なランタイム項目だけを有効にします。'],
        'settings': [],
        'operators': [],
    },
}


def get_group(topic: str):
    key = str(topic or 'overview').strip().lower()
    return dict(_GROUPS.get(key, _GROUPS['overview']))


def all_topics():
    return tuple(_GROUPS.keys())
