# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import importlib
from pathlib import Path

import bpy
from bpy.props import BoolProperty, EnumProperty, PointerProperty, StringProperty

from . import lifecycle, registry, settings_io, storage
from .core.constants import STORAGE_MODE_ITEMS, UTILITY_COLLECTION_RESULTS


_STORAGE_DEFAULTS = {
    'storage_mode': 'USER_DEFAULT',
    'custom_storage_dir': '',
    'result_collection_name': UTILITY_COLLECTION_RESULTS,
    'auto_create_result_collection': True,
}

_UI_SECTION_DEFAULTS = {
    'ui_open_scs_external': False,
    'ui_open_scs_workflow': False,
    'ui_open_scs_performance': False,
    'ui_open_scs_precision': False,
    'ui_open_scs_analysis': False,
    'ui_open_scs_output': False,
    'ui_open_tool_quick_rigid': False,
    'ui_open_tool_jiggle_physics': False,
    'ui_open_quick_rigid_all_commands': False,
    'ui_open_jiggle_all_commands': False,
    'ui_open_quick_rigid_menu': False,
    'ui_open_quick_rigid_setup': False,
    'ui_open_quick_rigid_active_body': False,
    'ui_open_quick_rigid_presets': False,
    'ui_open_jiggle_scene': False,
    'ui_open_jiggle_utilities': False,
    'ui_open_jiggle_armature': False,
    'ui_open_jiggle_bone': False,
}

_UI_SECTION_LABELS = {
    'ui_open_scs_external': ('External Tool Integration', '外部ツール連携'),
    'ui_open_scs_workflow': ('Smart Workflow', 'スマートワークフロー'),
    'ui_open_scs_performance': ('Batch / Performance', '一括処理 / パフォーマンス'),
    'ui_open_scs_precision': ('Precision / Collision', '精度 / 衝突'),
    'ui_open_scs_analysis': ('Analysis / Diagnostics', '解析 / 診断'),
    'ui_open_scs_output': ('Bake / Output', 'ベイク / 出力'),
    'ui_open_tool_quick_rigid': ('Quick Rigid', 'Quick Rigid'),
    'ui_open_tool_jiggle_physics': ('Jiggle Physics', 'Jiggle Physics'),
    'ui_open_quick_rigid_all_commands': ('All Quick Rigid Commands', 'Quick Rigid 全コマンド'),
    'ui_open_jiggle_all_commands': ('All Jiggle Commands', 'Jiggle 全コマンド'),
    'ui_open_quick_rigid_menu': ('Quick Menu', 'クイックメニュー'),
    'ui_open_quick_rigid_setup': ('Rigid Body Setup', '剛体セットアップ'),
    'ui_open_quick_rigid_active_body': ('Active Rigid Body', 'アクティブ剛体'),
    'ui_open_quick_rigid_presets': ('Presets / Bake', 'プリセット / ベイク'),
    'ui_open_jiggle_scene': ('Scene Settings', 'シーン設定'),
    'ui_open_jiggle_utilities': ('Utilities / Bake / Presets', '補助 / ベイク / プリセット'),
    'ui_open_jiggle_armature': ('Armature', 'アーマチュア'),
    'ui_open_jiggle_bone': ('Active Bone', 'アクティブボーン'),
}

_RUNTIME_DEFAULTS = {
    'show_tool_controls': True,
    'show_always_on_toggles': False,
    'show_displayed_tool_modules': False,
    'show_quick_rigid_tools': True,
    'show_jiggle_physics_tools': True,
    'always_suite_npanel_persistence': True,
    'always_jiggle_runtime_callbacks': False,
    'always_jiggle_overlay_rest_pose': False,
    'always_jiggle_overlay_simulation': False,
    **_STORAGE_DEFAULTS,
    **_UI_SECTION_DEFAULTS,
    'legacy_storage_migrated': False,
}

_RUNTIME_SETTINGS_POINTER = 'smart_tools_runtime_preferences_v420'
_RUNTIME_SETTINGS_FILE = 'Smart_Cloth_Suite.json'
_LOADING_RUNTIME_SETTINGS = False
_RUNTIME_SETTINGS_INITIALIZED = False
_LAST_NPANEL_STATE_SAVE_POLICY = None
_LAST_RUNTIME_SETTINGS_FINGERPRINT = ''
_RUNTIME_SETTINGS_LOAD_STATUS = 'UNINITIALIZED'


def _root_addon_id() -> str:
    text = str(__package__ or '').strip()
    if text:
        return text
    name = str(__name__ or '').strip()
    if '.' in name:
        return name.rsplit('.', 1)[0]
    return name or 'smart_tools'


def _root_module():
    try:
        return importlib.import_module(_root_addon_id())
    except Exception:
        return None


def _driver_namespace() -> dict | None:
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
    except Exception:
        namespace = None
    return namespace if isinstance(namespace, dict) else None


def _settings_owner(context=None):
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    if wm is None:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    return wm


def _runtime_settings(context=None):
    owner = _settings_owner(context)
    if owner is None:
        return None
    return getattr(owner, _RUNTIME_SETTINGS_POINTER, None)


def _config_root() -> Path:
    getter = getattr(storage, 'blender_config_dir', None)
    if callable(getter):
        return getter(create=False)
    return storage.user_data_dir('smart_suite', 'settings', create=False)


def _settings_path() -> Path:
    getter = getattr(storage, 'smart_suite_config_file', None)
    if callable(getter):
        return getter(create_parent=False)
    return _config_root() / _RUNTIME_SETTINGS_FILE


def _legacy_config_settings_path() -> Path:
    getter = getattr(storage, 'legacy_smart_suite_config_file', None)
    if callable(getter):
        return getter(create_parent=False)
    getter = getattr(storage, 'blender_config_dir', None)
    if callable(getter):
        return getter(create=False) / _RUNTIME_SETTINGS_FILE
    return _config_root() / _RUNTIME_SETTINGS_FILE


def _legacy_settings_path() -> Path:
    return storage.user_data_dir('smart_suite', 'settings', create=False) / 'smart_suite_preferences_v420.json'


def _read_json_dict(path: Path, *, legacy: bool = False) -> dict[str, object] | None:
    result = settings_io.read_legacy_document(path) if legacy else settings_io.read_document(path, recover=True)
    if result.status == 'CORRUPT':
        return None
    return dict(result.document or {})


def _runtime_payload_from_config(raw: dict[str, object]) -> dict[str, object]:
    if not isinstance(raw, dict):
        return {}
    nested = raw.get('runtime_preferences')
    if isinstance(nested, dict):
        return dict(nested)
    nested = raw.get('runtime')
    if isinstance(nested, dict):
        return dict(nested)
    return dict(raw)


def _persisted_runtime_bool(name: str, default: bool = False) -> bool:
    name = str(name or '').strip()
    if not name:
        return bool(default)
    candidates = (
        (_settings_path(), False),
        (_legacy_config_settings_path(), True),
        (_legacy_settings_path(), True),
    )
    for path, legacy in candidates:
        result = settings_io.read_legacy_document(path) if legacy else settings_io.read_document(path, recover=True)
        if result.status == 'MISSING':
            continue
        if result.status == 'CORRUPT' or result.document is None:
            return bool(default)
        payload = _runtime_payload_from_config(dict(result.document))
        value = payload.get(name, default)
        if type(value) is bool:
            return value
        if name in payload:
            return bool(default)
    return bool(default)


def _n_panel_state_save_enabled(context=None, settings=None) -> bool:
    settings = settings or _runtime_settings(context)
    if settings is not None and hasattr(settings, 'always_suite_npanel_persistence'):
        try:
            return bool(getattr(settings, 'always_suite_npanel_persistence'))
        except Exception:
            pass
    return _persisted_runtime_bool('always_suite_npanel_persistence', True)


def _split_runtime_payload(payload: dict[str, object]) -> dict[str, dict[str, object]]:
    def strict_value(name, default):
        value = payload.get(name, default)
        if isinstance(default, bool):
            return value if type(value) is bool else default
        return value if isinstance(value, str) else str(default)
    ui_sections = {name: strict_value(name, default) for name, default in _UI_SECTION_DEFAULTS.items()}
    always_on = {name: strict_value(name, default) for name, default in _RUNTIME_DEFAULTS.items() if name.startswith('always_')}
    tool_visibility = {name: strict_value(name, default) for name, default in _RUNTIME_DEFAULTS.items() if name.startswith('show_')}
    storage_settings = {name: strict_value(name, default) for name, default in _STORAGE_DEFAULTS.items()}
    return {'ui_sections': ui_sections, 'always_on_toggles': always_on, 'tool_visibility': tool_visibility, 'storage_settings': storage_settings}


def _runtime_settings_to_dict(settings) -> dict[str, object]:
    data: dict[str, object] = {}
    for name, default in _RUNTIME_DEFAULTS.items():
        try:
            value = getattr(settings, name)
        except Exception:
            value = default
        if isinstance(default, bool):
            data[name] = bool(value)
        else:
            data[name] = str(value if value is not None else default)
    return data


def _strict_runtime_payload(raw: dict[str, object]) -> dict[str, object]:
    payload = _runtime_payload_from_config(raw or {})
    data: dict[str, object] = {}
    for name, default in _RUNTIME_DEFAULTS.items():
        if name not in payload:
            continue
        value = payload.get(name)
        if isinstance(default, bool):
            if type(value) is bool:
                data[name] = value
        elif isinstance(value, str):
            data[name] = value
    return data


def _load_persisted_settings() -> tuple[str, dict[str, object]]:
    current = settings_io.read_document(_settings_path(), recover=True)
    if current.status == 'CORRUPT':
        # Corruption is an explicit state. It is never collapsed to an empty
        # document and therefore cannot trigger a default-value overwrite.
        return 'CORRUPT', {}
    if current.document is not None:
        return current.status, _strict_runtime_payload(dict(current.document))

    for legacy_path in (_legacy_config_settings_path(), _legacy_settings_path()):
        legacy = settings_io.read_legacy_document(legacy_path)
        if legacy.status == 'CORRUPT':
            continue
        if legacy.document:
            return 'LEGACY', _strict_runtime_payload(dict(legacy.document))
    return 'MISSING', {}


def _save_persisted_settings(context=None) -> bool:
    global _LAST_RUNTIME_SETTINGS_FINGERPRINT
    settings = _runtime_settings(context)
    if settings is None:
        settings_io.mark_dirty()
        return False
    payload = _runtime_settings_to_dict(settings)
    def mutate(config):
        result = dict(config or {})
        result['version'] = 283
        result['file'] = 'Smart_Cloth_Suite.json'
        result['runtime_preferences'] = payload
        result.update(_split_runtime_payload(payload))
        return result
    if not settings_io.update_document(_settings_path(), mutate, allow_create=True):
        return False
    result = settings_io.read_document(_settings_path(), recover=False)
    if result.document is None:
        settings_io.mark_dirty()
        return False
    try:
        _LAST_RUNTIME_SETTINGS_FINGERPRINT = settings_io.serialize_document(result.document).decode('utf-8')
    except Exception:
        _LAST_RUNTIME_SETTINGS_FINGERPRINT = ''
    return True


def save_root_preferences(context=None) -> bool:
    """Persist Smart Cloth N-panel/runtime settings to Smart_Cloth_Suite.json."""
    if bool(_LOADING_RUNTIME_SETTINGS):
        return False
    return _save_persisted_settings(context)


def _read_legacy_root_preferences(context=None) -> dict[str, object]:
    # The current build stores settings only through the N-panel runtime group.
    # Older preference data is ignored so registration stays panel-only.
    return {}


def _legacy_storage_preferences(context=None):
    return None


def _apply_runtime_settings(values: dict[str, object] | None, *, context=None) -> None:
    global _LOADING_RUNTIME_SETTINGS, _LAST_NPANEL_STATE_SAVE_POLICY
    settings = _runtime_settings(context)
    if settings is None:
        return
    values = dict(values or {})
    previous = bool(_LOADING_RUNTIME_SETTINGS)
    _LOADING_RUNTIME_SETTINGS = True
    try:
        for name, default in _RUNTIME_DEFAULTS.items():
            value = values.get(name, default)
            if isinstance(default, bool):
                value = value if type(value) is bool else default
            else:
                value = value if isinstance(value, str) else str(default)
            try:
                setattr(settings, name, value)
            except Exception:
                continue
    finally:
        _LOADING_RUNTIME_SETTINGS = previous
        try:
            current = getattr(settings, 'always_suite_npanel_persistence', True)
            _LAST_NPANEL_STATE_SAVE_POLICY = current if type(current) is bool else True
        except Exception:
            _LAST_NPANEL_STATE_SAVE_POLICY = None


def _ensure_runtime_settings_loaded(context=None):
    global _RUNTIME_SETTINGS_INITIALIZED, _RUNTIME_SETTINGS_LOAD_STATUS
    settings = _runtime_settings(context)
    if settings is None:
        return None
    if _RUNTIME_SETTINGS_INITIALIZED:
        return settings

    status, persisted = _load_persisted_settings()
    _RUNTIME_SETTINGS_LOAD_STATUS = status
    if status == 'CORRUPT':
        # Leave Blender's current RNA values untouched and retain dirty state.
        # Registration remains finite and subsequent draw calls do not re-read.
        settings_io.mark_dirty()
        _RUNTIME_SETTINGS_INITIALIZED = True
        return settings

    data = dict(persisted)
    if status == 'MISSING':
        data = _read_legacy_root_preferences(context)
        legacy = _legacy_storage_preferences(context)
        if legacy is not None:
            for name, default in _STORAGE_DEFAULTS.items():
                if name in data and data.get(name) != default:
                    continue
                try:
                    legacy_value = getattr(legacy, name)
                except Exception:
                    legacy_value = default
                if legacy_value != default:
                    data[name] = legacy_value
    if status == 'LEGACY' and data and 'legacy_storage_migrated' not in data:
        data['legacy_storage_migrated'] = True
    _apply_runtime_settings(data, context=context)
    _RUNTIME_SETTINGS_INITIALIZED = True
    return settings


def peek_root_preferences(context=None):
    return _runtime_settings(context)


def get_root_preferences(context=None):
    return _ensure_runtime_settings_loaded(context)


def reload_runtime_settings(context=None):
    """Reload Smart Cloth runtime/N-panel settings from Smart_Cloth_Suite.json.

    Blender can recreate WindowManager pointer-property storage when a .blend is
    opened. The module-level initialization flag must therefore be reset on
    load_post so the new pointer data receives the external JSON values again.
    """
    global _RUNTIME_SETTINGS_INITIALIZED, _RUNTIME_SETTINGS_LOAD_STATUS
    _RUNTIME_SETTINGS_INITIALIZED = False
    _RUNTIME_SETTINGS_LOAD_STATUS = 'UNINITIALIZED'
    return _ensure_runtime_settings_loaded(context)


def save_runtime_settings(context=None) -> bool:
    return _save_persisted_settings(context)


def get_runtime_bool(name: str, default: bool = False, context=None) -> bool:
    settings = get_root_preferences(context)
    if settings is None:
        return bool(default)
    try:
        return bool(getattr(settings, str(name), bool(default)))
    except Exception:
        return bool(default)


def set_runtime_bool(name: str, value: bool, context=None) -> bool:
    settings = get_root_preferences(context)
    if settings is None:
        return False
    name = str(name or '').strip()
    if not name or not hasattr(settings, name):
        return False
    try:
        setattr(settings, name, bool(value))
        # Immediate writes are controlled by N-panel State Save.  The policy
        # switch itself is always written so disabling immediate saving survives
        # the next Blender start.
        if name == 'always_suite_npanel_persistence' or _n_panel_state_save_enabled(context, settings=settings):
            _save_persisted_settings(context)
        return True
    except Exception:
        return False


def _integrated_runtime_active() -> bool:
    try:
        from . import runtime
        return bool(getattr(runtime, '_INTEGRATED_RUNTIME_STATE', {}).get('module') is not None)
    except Exception:
        return False


def _refresh_runtime_from_preferences(_self=None, context=None) -> None:
    global _LAST_NPANEL_STATE_SAVE_POLICY
    if bool(_LOADING_RUNTIME_SETTINGS):
        return
    registry.clear_cache()
    settings = _self or _runtime_settings(context)
    enabled = _n_panel_state_save_enabled(context, settings=settings)
    if _LAST_NPANEL_STATE_SAVE_POLICY is None:
        _LAST_NPANEL_STATE_SAVE_POLICY = _persisted_runtime_bool('always_suite_npanel_persistence', bool(enabled))
    policy_changed = bool(_LAST_NPANEL_STATE_SAVE_POLICY) != bool(enabled)
    # Save immediately while N-panel State Save is enabled.  When it is disabled,
    # save only the policy transition itself; ordinary setting edits are deferred
    # until scene/file close, preference save, or add-on disable checkpoints.
    if bool(enabled) or policy_changed:
        if _save_persisted_settings(context):
            _LAST_NPANEL_STATE_SAVE_POLICY = bool(enabled)
    # BoolProperty toggle buttons in the N-panel own Blender's active/blue state.
    # Their update callback must also apply the runtime side-effect immediately,
    # otherwise a saved toggle would look enabled but the handler/draw callback
    # would not be installed until another operator runs.
    try:
        from . import runtime as _runtime
        sync = getattr(_runtime, 'sync_always_on_from_preferences', None)
        if callable(sync):
            sync(context)
    except Exception:
        pass
    # Do not force VIEW_3D redraws from preference update callbacks. The panels
    # refresh naturally, and forced toolbar redraws can expose Blender's blank
    # active-tool state during add-on installation.
    return None


def _is_japanese_locale(context=None) -> bool:
    candidates = []
    try:
        candidates.append(str(getattr(getattr(getattr(context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(getattr(bpy.context, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or ''))
    except Exception:
        pass
    joined = ' '.join(candidates).upper()
    return any(token in joined for token in ('JA', 'JA_JP', 'JAPANESE', 'JP'))


def _ui_text(en: str, ja: str, context=None) -> str:
    # When Blender registers class labels, RNA property names, or property
    # descriptions, no draw context is available. Keep the canonical English
    # source string there and let Blender's translation dictionary display the
    # active UI language. Draw/report code passes context and remains dynamic.
    if context is None:
        return str(en)
    return str(ja if _is_japanese_locale(context) else en)


class SMARTCLOTHSUITE_OT_copy_text(bpy.types.Operator):
    bl_idname = 'smart_core.copy_text'
    bl_label = _ui_text('Copy Text', 'テキストをコピー')
    bl_description = _ui_text(
        'Copy the displayed registration text to the clipboard so it can be pasted where needed.',
        '表示中の登録文字列をクリップボードへコピーし、必要な場所へ貼り付けられるようにします。',
    )
    bl_options = {'INTERNAL'}

    text: StringProperty(
        name=_ui_text('Text to Copy', 'コピーするテキスト'),
        description=_ui_text('Internal text payload copied to the clipboard by this operator.', 'このオペレーターがクリップボードへコピーする内部テキストです。'),
        options={'SKIP_SAVE', 'HIDDEN'},
    )
    report_label: StringProperty(
        name=_ui_text('Report Label', 'レポート表示名'),
        description=_ui_text('Short label shown in the status report after copying text.', 'テキストコピー後のステータスレポートに表示する短い名前です。'),
        options={'SKIP_SAVE', 'HIDDEN'},
    )

    def execute(self, context):
        wm = getattr(context, 'window_manager', None)
        if wm is None:
            self.report({'ERROR'}, _ui_text('Clipboard is not available.', 'クリップボードが利用できません。', context))
            return {'CANCELLED'}
        try:
            wm.clipboard = str(self.text or '')
        except Exception:
            self.report({'ERROR'}, _ui_text('Copy failed.', 'コピーに失敗しました。', context))
            return {'CANCELLED'}
        label = str(self.report_label or self.text or '').strip()
        self.report({'INFO'}, _ui_text('Copied: %(label)s', 'コピーしました: %(label)s', context) % {'label': label})
        return {'FINISHED'}


class SMARTCLOTHSUITE_PG_RuntimePreferences(bpy.types.PropertyGroup):
    show_tool_controls: BoolProperty(
        name=_ui_text('Show Tool Controls', 'ツール設定を表示'),
        description=_ui_text(
            'Show the overview and usage notes for Smart Cloth Suite companion, Quick Rigid, and Jiggle Physics.',
            'Smart Cloth Suite 連携機能、Quick Rigid、Jiggle Physics の概要と使い方を表示します。',
        ),
        default=True,
        update=_refresh_runtime_from_preferences,
    )

    show_always_on_toggles: BoolProperty(
        name=_ui_text('Always-on Toggles', '常時機能切り替え'),
        description=_ui_text(
            "Open or close the clock-marked always-on toggle group at the top of the N-panel. The group uses direct checkbox properties so the enabled state keeps Blender's blue active overlay reliably.",
            'Nパネル最上部の時計アイコン付き常時機能切り替えグループを開閉します。直接チェックボックスプロパティで描画するため、有効時の青いアクティブ表示を安定して維持します。',
        ),
        default=False,
        update=_refresh_runtime_from_preferences,
    )
    show_displayed_tool_modules: BoolProperty(
        name=_ui_text('Displayed Tool Sections', '表示するツールセクション'),
        description=_ui_text(
            'Open or close the tool-section visibility group. These settings only affect which sections are displayed inside the single Smart Cloth N-panel.',
            'ツールセクション表示グループを開閉します。この設定は単一の Smart Cloth Nパネル内セクションの表示 / 非表示だけを変更します。',
        ),
        default=False,
        update=_refresh_runtime_from_preferences,
    )
    show_quick_rigid_tools: BoolProperty(
        name=_ui_text('Quick Rigid Tools', 'Quick Rigid ツール'),
        description=_ui_text(
            'Show the lightweight Quick Rigid section inside the single Smart Cloth N-panel. Commands load the tool code only when executed.',
            '単一の Smart Cloth Nパネル内に軽量な Quick Rigid セクションを表示します。コマンド実行時だけツールコードを読み込みます。',
        ),
        default=True,
        update=_refresh_runtime_from_preferences,
    )
    show_jiggle_physics_tools: BoolProperty(
        name=_ui_text('Jiggle Physics Tools', 'Jiggle Physics ツール'),
        description=_ui_text(
            'Show the lightweight Jiggle Physics section inside the single Smart Cloth N-panel. Runtime handlers remain off unless enabled from Always-on Toggles.',
            '単一の Smart Cloth Nパネル内に軽量な Jiggle Physics セクションを表示します。ランタイムハンドラは常時機能切り替えで有効化するまでOFFです。',
        ),
        default=True,
        update=_refresh_runtime_from_preferences,
    )
    always_suite_npanel_persistence: BoolProperty(
        name=_ui_text('N-panel State Save', 'Nパネル状態保存'),
        description=_ui_text(
            'Function: when enabled, every Smart Cloth N-panel setting change is saved immediately to Smart_Cloth_Suite.json in Blender 5.1 config/Smart_Cloth_Suite. When disabled, changes are saved only when the current scene is closed/switched or when preferences are saved. How to use: keep enabled to preserve all changes as soon as they are made; disable it when you want deferred saving.',
            '機能: 有効時は Smart Cloth のNパネル内で行った全設定変更を、Blender 5.1 config/Smart_Cloth_Suite 内の Smart_Cloth_Suite.json へ即時保存します。無効時は現在のシーンを閉じる / 切り替えるタイミング、またはプリファレンス保存時だけ保存します。使い方: 変更した時点で確実に維持したい場合は有効、保存タイミングを遅らせたい場合は無効にします。',
        ),
        default=True,
        options={'HIDDEN'},
        update=_refresh_runtime_from_preferences,
    )
    always_jiggle_runtime_callbacks: BoolProperty(
        name=_ui_text('Jiggle Runtime Callback State', 'Jiggle 実行コールバック状態'),
        description=_ui_text('Stores whether Jiggle frame, playback, render, and overlay runtime callbacks are enabled.', 'Jiggle のフレーム、再生、レンダー、オーバーレイ用ランタイムコールバックが有効かを保存します。'),
        default=False,
        options={'HIDDEN'},
        update=_refresh_runtime_from_preferences,
    )
    always_jiggle_overlay_rest_pose: BoolProperty(
        name=_ui_text('Jiggle Rest Pose Overlay State', 'Jiggle レスト姿勢オーバーレイ状態'),
        description=_ui_text('Stores whether the Jiggle rest-pose overlay is shown in the 3D View.', '3Dビューで Jiggle レスト姿勢オーバーレイを表示するかを保存します。'),
        default=False,
        options={'HIDDEN'},
        update=_refresh_runtime_from_preferences,
    )
    always_jiggle_overlay_simulation: BoolProperty(
        name=_ui_text('Jiggle Simulation Overlay State', 'Jiggle シミュレーションオーバーレイ状態'),
        description=_ui_text('Stores whether the Jiggle simulation overlay is shown in the 3D View.', '3Dビューで Jiggle シミュレーションオーバーレイを表示するかを保存します。'),
        default=False,
        options={'HIDDEN'},
        update=_refresh_runtime_from_preferences,
    )

    storage_mode: EnumProperty(
        name=_ui_text('Storage Mode', '保存モード'),
        items=STORAGE_MODE_ITEMS,
        default=_STORAGE_DEFAULTS['storage_mode'],
        description=_ui_text(
            'Choose the storage policy. Automatic package data stays inside extensions/user_default; only custom uses the manually selected folder.',
            '保存方針を選びます。自動生成されるパッケージデータは extensions/user_default 内に保存し、カスタムの場合だけ手動指定フォルダーを使います。',
        ),
        update=_refresh_runtime_from_preferences,
    )
    custom_storage_dir: StringProperty(
        name=_ui_text('Custom Storage Directory', 'カスタム保存フォルダー'),
        subtype='DIR_PATH',
        description=_ui_text(
            'Folder used when Storage Mode is set to custom. You can use a local folder or a studio-managed shared path.',
            '保存モードを custom にした時に使うフォルダーです。ローカルフォルダーにも共有パスにもできます。',
        ),
        default=_STORAGE_DEFAULTS['custom_storage_dir'],
        update=_refresh_runtime_from_preferences,
    )
    result_collection_name: StringProperty(
        name=_ui_text('Result Collection Name', '結果コレクション名'),
        default=_STORAGE_DEFAULTS['result_collection_name'],
        description=_ui_text(
            'Collection name used for duplicated editable or repaired result meshes. Keeping results separate makes cleanup easier.',
            '複製した編集用メッシュや補正結果メッシュを入れるコレクション名です。分けておくと整理しやすくなります。',
        ),
        update=_refresh_runtime_from_preferences,
    )
    auto_create_result_collection: BoolProperty(
        name=_ui_text('Create Result Collection Automatically', '結果コレクションを自動作成'),
        default=_STORAGE_DEFAULTS['auto_create_result_collection'],
        description=_ui_text(
            'Automatically create the result collection if it does not exist yet.',
            '結果コレクションがまだ無い場合は自動で作成します。',
        ),
        update=_refresh_runtime_from_preferences,
    )
    legacy_storage_migrated: BoolProperty(
        name=_ui_text('Legacy Storage Migration Flag', '旧保存設定移行フラグ'),
        description=_ui_text('Internal flag indicating whether older storage settings were already migrated to the N-panel runtime settings file.', '旧保存設定をNパネルのランタイム設定ファイルへ移行済みかを示す内部フラグです。'),
        default=False,
        options={'HIDDEN'},
    )


def draw_preferences_contents(layout, context, *, prefs=None) -> bool:
    prefs = prefs or get_root_preferences(context)
    if prefs is None:
        return False

    settings_box = layout.box()
    settings_box.use_property_split = False
    settings_box.use_property_decorate = False
    settings_box.label(text=_ui_text('Smart Cloth Suite Settings', 'Smart Cloth Suite 設定', context), icon='SETTINGS')

    storage_box = settings_box.box()
    storage_box.use_property_split = True
    storage_box.use_property_decorate = False
    storage_box.label(text=_ui_text('Persistent Storage / Results', '保存先 / 結果設定', context), icon='FILE_FOLDER')
    storage_box.prop(prefs, 'storage_mode')
    if str(getattr(prefs, 'storage_mode', '')) == 'CUSTOM':
        storage_box.prop(prefs, 'custom_storage_dir')
    storage_box.prop(prefs, 'result_collection_name')
    storage_box.prop(prefs, 'auto_create_result_collection')
    try:
        storage_path = str(storage.smart_suite_config_dir(create=True))
    except Exception:
        storage_path = ''
    if storage_path:
        storage_box.label(text=storage_path, icon='FILE_FOLDER', translate=False)
    try:
        storage_box.operator('smart_cloth_suite.open_data_folder', icon='FILE_FOLDER')
    except Exception:
        pass
    return True


def _remove_save_userpref_hooks() -> None:
    # No preference-panel hooks are installed. N-panel values are written to
    # Blender config/Smart_Cloth_Suite/Smart_Cloth_Suite.json according to the
    # N-panel State Save policy.
    return None



def _safe_register_class(cls):
    lifecycle.register_class(cls, scope='preferences.classes')


def _safe_unregister_class(cls):
    del cls
    lifecycle.release_scope('preferences.classes')

def _add_ui_section_runtime_properties() -> None:
    annotations = getattr(SMARTCLOTHSUITE_PG_RuntimePreferences, '__annotations__', None)
    if annotations is None:
        annotations = {}
    for name, default in _UI_SECTION_DEFAULTS.items():
        if name in annotations:
            continue
        label_en, label_ja = _UI_SECTION_LABELS.get(name, (name.replace('_', ' ').title(), name.replace('_', ' ').title()))
        annotations[name] = BoolProperty(
            name=_ui_text(label_en, label_ja),
            description=_ui_text(
                'Open or close the %(section)s section in the Smart Cloth N-panel. This affects only the UI fold state and does not execute tools or change scene data.',
                'Smart Cloth Nパネル内の「%(section)s」セクションを開閉します。UIの折りたたみ状態だけを変更し、ツール実行やシーンデータ変更は行いません。',
            ) % {'section': _ui_text(label_en, label_ja)},
            default=bool(default),
            update=_refresh_runtime_from_preferences,
        )
    SMARTCLOTHSUITE_PG_RuntimePreferences.__annotations__ = annotations


_add_ui_section_runtime_properties()


classes = (
    SMARTCLOTHSUITE_OT_copy_text,
    SMARTCLOTHSUITE_PG_RuntimePreferences,
)


def register() -> None:
    global _RUNTIME_SETTINGS_INITIALIZED, _LAST_NPANEL_STATE_SAVE_POLICY, _LAST_RUNTIME_SETTINGS_FINGERPRINT, _RUNTIME_SETTINGS_LOAD_STATUS
    mark = lifecycle.checkpoint()
    try:
        for cls in classes:
            lifecycle.register_class(cls, scope='preferences.classes')
        lifecycle.register_rna(
            bpy.types.WindowManager,
            _RUNTIME_SETTINGS_POINTER,
            PointerProperty(
                name='Smart Cloth Suite',
                description='Stores Smart Cloth Suite N-panel runtime settings in the Window Manager.',
                type=SMARTCLOTHSUITE_PG_RuntimePreferences,
            ),
            scope='preferences.rna',
        )
    except Exception:
        lifecycle.rollback_to(mark)
        raise
    _RUNTIME_SETTINGS_INITIALIZED = False
    _LAST_NPANEL_STATE_SAVE_POLICY = None
    _LAST_RUNTIME_SETTINGS_FINGERPRINT = ''
    _RUNTIME_SETTINGS_LOAD_STATUS = 'UNINITIALIZED'
    _ensure_runtime_settings_loaded(getattr(bpy, 'context', None))


def unregister(*, persist: bool = True) -> None:
    global _RUNTIME_SETTINGS_INITIALIZED, _LAST_NPANEL_STATE_SAVE_POLICY, _LAST_RUNTIME_SETTINGS_FINGERPRINT, _RUNTIME_SETTINGS_LOAD_STATUS
    if persist:
        try:
            _save_persisted_settings(getattr(bpy, 'context', None))
        except Exception:
            settings_io.mark_dirty()
    _remove_save_userpref_hooks()
    lifecycle.release_scope('preferences.rna')
    lifecycle.release_scope('preferences.classes')
    _RUNTIME_SETTINGS_INITIALIZED = False
    _LAST_NPANEL_STATE_SAVE_POLICY = None
    _LAST_RUNTIME_SETTINGS_FINGERPRINT = ''
    _RUNTIME_SETTINGS_LOAD_STATUS = 'UNINITIALIZED'
