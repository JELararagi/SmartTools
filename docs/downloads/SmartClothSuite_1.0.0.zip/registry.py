# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Static commercial-package metadata for the Smart Cloth N-panel.

The companion does not scan bundled add-on folders at runtime.  Keeping this
catalog static avoids filesystem work during preference/N-panel redraws and
makes it explicit that Simply Cloth Studio remains an external extension.
"""

from __future__ import annotations

from typing import Any

_TOOL_ENTRIES: tuple[dict[str, Any], ...] = (
    {
        'alias': 'core',
        'display_name': 'Smart Cloth Suite',
        'icon': 'MOD_CLOTH',
        'source_name': 'Smart Cloth Suite',
        'enabled': True,
        'visible': True,
        'overview_en': 'Companion workflow for a separately installed Simply Cloth Studio. It adds one-click setup, batch quality profiles, reversible preview optimization, adaptive collision spacing, analysis maps, preflight diagnostics, and guarded bake/finish operations without bundling the external implementation.',
        'overview_ja': '別途インストールされた Simply Cloth Studio と併用する連携ワークフローです。外部実装を内包せず、ワンクリックセットアップ、一括品質プロファイル、復元可能な軽量プレビュー、自動衝突間隔、解析マップ、プリフライト診断、安全確認付きベイク / 仕上げを追加します。',
        'usage_en': 'Install and enable Simply Cloth Studio separately. In the Smart Cloth N-panel, confirm External Tool Integration is ready, configure target scope/body/colliders, then run Smart Setup or the individual extension commands.',
        'usage_ja': 'Simply Cloth Studio を別途インストールして有効化します。Smart Cloth Nパネルの「外部ツール連携」で使用可能状態を確認し、対象範囲、ボディ、コライダーを設定してからスマートセットアップまたは個別の拡張コマンドを実行します。',
    },
    {
        'alias': 'quick_rigid',
        'display_name': 'Quick Rigid',
        'icon': 'PHYSICS',
        'source_name': 'Quick Rigid',
        'enabled': True,
        'visible': True,
        'overview_en': 'Rigid-body setup, physical properties, presets, and cache/bake controls in the unified Smart Cloth N-panel.',
        'overview_ja': '統合Smart Cloth Nパネルで剛体セットアップ、物理特性、プリセット、キャッシュ / ベイクを操作します。',
        'usage_en': 'Select mesh objects, open Quick Rigid, add Active or Passive rigid bodies, then adjust settings or run preset and bake commands.',
        'usage_ja': 'メッシュを選択してQuick Rigidを開き、アクティブまたはパッシブ剛体を追加してから、設定調整、プリセット、ベイクを実行します。',
    },
    {
        'alias': 'jiggle_physics',
        'display_name': 'Jiggle Physics',
        'icon': 'ARMATURE_DATA',
        'source_name': 'Jiggle Physics',
        'enabled': True,
        'visible': True,
        'overview_en': 'Bone-based secondary motion with optional runtime callbacks, overlays, wind, utilities, presets, and bake tools.',
        'overview_ja': '任意のランタイムコールバック、オーバーレイ、風、補助、プリセット、ベイクを備えたボーン二次揺れ機能です。',
        'usage_en': 'Select an armature and pose bone, configure scene/armature/bone values, and enable only the always-on callbacks or overlays that are actually needed.',
        'usage_ja': 'アーマチュアとポーズボーンを選択し、シーン / アーマチュア / ボーン値を設定して、必要な常時起動コールバックまたはオーバーレイだけを有効にします。',
    },
)


def clear_cache() -> None:
    """Compatibility no-op; metadata is immutable and requires no cache."""
    return None


def preference_tool_entries() -> list[dict[str, Any]]:
    return [dict(entry) for entry in _TOOL_ENTRIES]
