# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import json
import os
import re
from pathlib import Path

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, StringProperty

try:
    from . import lifecycle, storage as _suite_storage
except Exception:  # pragma: no cover
    lifecycle = None
    _suite_storage = None

PACKAGE_ID = 'smart_cloth_suite'
ADDON_NAME = 'Smart Cloth Suite'
TOOL_LABEL_EN = 'Smart Cloth'
TOOL_LABEL_JA = 'スマートクロス'
PANEL_CATEGORY = TOOL_LABEL_EN
_ALWAYS_ON_PROP = PACKAGE_ID + '_always_on_enabled'
_STORAGE_DIRNAME = 'user_data'

_PREVIEW_COLLECTION = None
_REGISTERED_CLASSES = []
_PATCHED_PANELS = []
_PATCHED_PREFERENCES = []
_PATCHED_POLLS = []
_ORIGINAL_REGISTER_CLASS = None
_REGISTER_PATCH_DEPTH = 0
_AUTOSAVE_FINGERPRINT = ''
_LOADED_SETTINGS = {}

_TRANSLATIONS = {
    ('*', 'Help'): 'ヘルプ',
    ('*', 'Open Help'): 'ヘルプを開く',
    ('*', 'Feature Overview'): '機能概要',
    ('*', 'Usage'): '使用方法',
    ('*', 'Settings'): '設定項目',
    ('*', 'Commands'): 'コマンド',
    ('*', 'Always-on Toggles'): '常時起動切り替え',
    ('*', 'Enabled'): '有効',
    ('*', 'Disabled'): '無効',
    ('*', 'Save Preferences'): 'プリファレンスを保存',
    ('*', 'Settings are managed in the N-panel.'): '設定はNパネルで管理します。',
    ('*', 'Open the 3D View Sidebar and use this tool tab.'): '3Dビューのサイドバーを開き、このツールのタブを使用してください。',
    ('*', 'Open the detailed help popup for this tool group.'): 'このツールグループの詳細ヘルプポップアップを開きます。',
    ('*', 'Set an always-on feature to enabled or disabled and save it according to the N-panel State Save policy.'): '常時起動機能の有効 / 無効を設定し、Nパネル状態保存の方針に従って保存します。',
    ('*', 'Save current N-panel settings to Smart_Cloth_Suite/Smart_Cloth_Suite.json in Blender config and request Blender to save user preferences.'): '現在のNパネル設定を Blender config の Smart_Cloth_Suite/Smart_Cloth_Suite.json へ保存し、Blender にユーザープリファレンスの保存を要求します。',
    ('*', 'Always-on'): '常時起動',
    ('*', 'Enable persistent helper behavior only when it is required.'): '必要な場合だけ常駐ヘルパー動作を有効にします。',
    ('*', TOOL_LABEL_EN): TOOL_LABEL_JA,
}


def _ui_is_japanese(context=None):
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja')
    except Exception:
        return False


def text(en, ja=None, context=None):
    return str(ja if (ja is not None and _ui_is_japanese(context)) else en)


def package_root():
    return Path(__file__).resolve().parent


def storage_root(create=True):
    # Generated files are routed through the shared storage helper so they stay
    # below Blender's versioned extensions/user_default repository.
    if _suite_storage is not None:
        try:
            return _suite_storage.user_data_dir(create=bool(create))
        except Exception:
            pass
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None)
        version_text = f'{int(version[0])}.{int(version[1])}' if version and len(version) >= 2 else '5.1'
    except Exception:
        version_text = '5.1'
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        root = Path(roaming) / 'Blender Foundation' / 'Blender' / version_text / 'extensions' / 'user_default' / PACKAGE_ID / _STORAGE_DIRNAME
    else:
        root = Path.home() / '.config' / 'blender' / version_text / 'extensions' / 'user_default' / PACKAGE_ID / _STORAGE_DIRNAME
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


def storage_path(*parts, create_parent=True):
    clean_parts = []
    for part in parts:
        value = str(part or '').replace('\\', '/').strip('/')
        if not value or value in {'.', '..'}:
            continue
        for piece in value.split('/'):
            if piece and piece not in {'.', '..'}:
                clean_parts.append(piece)
    path = storage_root(True).joinpath(*clean_parts)
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def settings_path():
    if _suite_storage is not None:
        try:
            getter = getattr(_suite_storage, 'smart_suite_config_file', None)
            if callable(getter):
                return getter(create_parent=True)
        except Exception:
            pass
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None)
        version_text = f'{int(version[0])}.{int(version[1])}' if version and len(version) >= 2 else '5.1'
    except Exception:
        version_text = '5.1'
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        return Path(roaming) / 'Blender Foundation' / 'Blender' / version_text / 'config' / 'Smart_Cloth_Suite' / 'Smart_Cloth_Suite.json'
    return Path.home() / '.config' / 'blender' / version_text / 'config' / 'Smart_Cloth_Suite' / 'Smart_Cloth_Suite.json'


def _npanel_state_save_enabled(context=None) -> bool:
    try:
        from . import preferences as _suite_preferences
        getter = getattr(_suite_preferences, 'get_runtime_bool', None)
        if callable(getter):
            return bool(getter('always_suite_npanel_persistence', True, context))
    except Exception:
        pass
    try:
        path = settings_path()
        if path.exists():
            raw = json.loads(path.read_text(encoding='utf-8'))
            payload = raw.get('runtime_preferences') if isinstance(raw, dict) else {}
            if isinstance(payload, dict) and 'always_suite_npanel_persistence' in payload:
                return bool(payload.get('always_suite_npanel_persistence'))
    except Exception:
        pass
    return True


def _force_runtime_npanel_persist(context=None) -> None:
    try:
        from . import runtime as _suite_runtime
        persist = getattr(_suite_runtime, '_persist_npanel_runtime_state', None)
        if callable(persist):
            persist(context, force=True)
    except Exception:
        pass


def _load_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is not None:
        return _PREVIEW_COLLECTION
    try:
        import bpy.utils.previews
        pcoll = bpy.utils.previews.new()
        icon_files = {}
        for name, filename in icon_files.items():
            pass
        _PREVIEW_COLLECTION = pcoll
    except Exception:
        _PREVIEW_COLLECTION = None
    return _PREVIEW_COLLECTION


def icon_value(name, fallback=0):
    pcoll = _load_previews()
    try:
        item = pcoll.get(str(name)) if pcoll is not None else None
        return int(getattr(item, 'icon_id', fallback) or fallback)
    except Exception:
        return fallback


def _remove_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is None:
        return
    try:
        import bpy.utils.previews
        bpy.utils.previews.remove(_PREVIEW_COLLECTION)
    except Exception:
        pass
    _PREVIEW_COLLECTION = None


def _translation_payload():
    return {'ja_JP': dict(_TRANSLATIONS)}


def _wrap_lines(value, width_px):
    import textwrap
    text_value = str(value or '').replace('\r\n', '\n').replace('\r', '\n')
    # Approximate Blender UI label width.  This wraps only when the line would
    # exceed the popup width rather than at a fixed text width.
    chars = max(26, min(160, int(max(260, width_px) / 7)))
    lines = []
    for para in text_value.split('\n'):
        raw = para.strip()
        if not raw:
            lines.append('')
            continue
        wrapped = textwrap.wrap(raw, width=chars, break_long_words=False, break_on_hyphens=False)
        lines.extend(wrapped or [raw])
    return lines


def _draw_wrapped(layout, context, value, icon='NONE'):
    try:
        width = int(getattr(getattr(context, 'region', None), 'width', 620) or 620)
    except Exception:
        width = 620
    first = True
    for line in _wrap_lines(value, width):
        if not line:
            layout.separator(factor=0.35)
        elif first and icon != 'NONE':
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)
            first = False


def _group_text_list(group, key_en, key_ja, context=None, is_japanese=None):
    if is_japanese is None:
        is_japanese = _ui_is_japanese(context)
    values = group.get(key_ja if is_japanese else key_en) or []
    if isinstance(values, str):
        return [values]
    if isinstance(values, (list, tuple)):
        return [str(v) for v in values]
    return []


class SMART_CLOTH_OT_open_help(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.open_help'
    bl_label = 'Open Help'
    bl_description = 'Open the detailed help popup for this tool group.'
    bl_options = {'INTERNAL'}

    topic: StringProperty(default='overview', options={'SKIP_SAVE'})

    def invoke(self, context, event):
        try:
            return context.window_manager.invoke_popup(self, width=680)
        except Exception:
            return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        topic = str(getattr(self, 'topic', '') or 'overview')
        is_japanese = _ui_is_japanese(context)

        def draw_text(en, ja=None):
            return str(ja if ja is not None and is_japanese else en)

        try:
            from . import guide
            group = guide.get_group(topic)
        except Exception:
            group = {
                'title_en': TOOL_LABEL_EN + ' Help',
                'title_ja': TOOL_LABEL_JA + ' ヘルプ',
                'overview_en': ['The help catalog could not be loaded.'],
                'overview_ja': ['ヘルプカタログを読み込めませんでした。'],
                'usage_en': [],
                'usage_ja': [],
                'settings': [],
                'operators': [],
            }
        title = group.get('title_ja' if is_japanese else 'title_en') or TOOL_LABEL_EN
        row = layout.row(align=True)
        row.label(text=str(title), icon='QUESTION')
        layout.separator()
        box = layout.box()
        box.label(text=draw_text('Feature Overview', '機能概要'))
        for item in _group_text_list(group, 'overview_en', 'overview_ja', context, is_japanese):
            _draw_wrapped(box, context, item)
        box = layout.box()
        box.label(text=draw_text('Usage', '使用方法'), icon='PLAY')
        for item in _group_text_list(group, 'usage_en', 'usage_ja', context, is_japanese):
            _draw_wrapped(box, context, item)
        settings = group.get('settings') or []
        ops = group.get('operators') or []
        box = layout.box()
        box.label(text=draw_text('Settings', '設定項目'), icon='PREFERENCES')
        if not settings and not ops:
            _draw_wrapped(box, context, draw_text(
                'No individual settings were detected for this group. Use the visible controls and their tooltips for short descriptions.',
                'このグループ専用の設定項目は検出されませんでした。表示されている各コントロールとツールチップを確認してください。',
            ))
        for item in settings[:240]:
            name = item.get('name_ja' if is_japanese else 'name_en') or item.get('key') or ''
            desc = item.get('description_ja' if is_japanese else 'description_en') or ''
            _draw_wrapped(box, context, '• ' + str(name) + ': ' + str(desc))
        if ops:
            cmd_box = layout.box()
            cmd_box.label(text=draw_text('Commands', 'コマンド'), icon='TOOL_SETTINGS')
            for item in ops[:240]:
                name = item.get('name_ja' if is_japanese else 'name_en') or item.get('key') or ''
                desc = item.get('description_ja' if is_japanese else 'description_en') or ''
                _draw_wrapped(cmd_box, context, '• ' + str(name) + ': ' + str(desc))


class SMART_CLOTH_OT_set_always_on(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.set_always_on'
    bl_label = 'Always-on Toggles'
    bl_description = 'Set an always-on feature to enabled or disabled and save it according to the N-panel State Save policy.'
    bl_options = {'UNDO'}

    alias: StringProperty(default='', options={'SKIP_SAVE'})
    feature_key: StringProperty(default='', options={'SKIP_SAVE'})
    enabled: BoolProperty(default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        try:
            setattr(context.window_manager, _ALWAYS_ON_PROP, bool(self.enabled))
        except Exception:
            self.report({'WARNING'}, text('The setting could not be changed.', '設定を変更できませんでした。', context))
            return {'CANCELLED'}
        try:
            save_persistent_settings(context, force=False)
        except Exception:
            pass
        return {'FINISHED'}


class SMART_CLOTH_OT_save_preferences(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.save_preferences'
    bl_label = 'Save Preferences'
    bl_description = 'Save current N-panel settings to Smart_Cloth_Suite/Smart_Cloth_Suite.json in Blender config and request Blender to save user preferences.'
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        save_persistent_settings(context, force=True)
        _force_runtime_npanel_persist(context)
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        _force_runtime_npanel_persist(context)
        self.report({'INFO'}, text('Preferences saved.', 'プリファレンスを保存しました。', context))
        return {'FINISHED'}


class SMART_CLOTH_PT_always_on(bpy.types.Panel):
    bl_idname = 'SMART_CLOTH_PT_always_on'
    bl_label = 'Always-on Toggles'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        self.layout.label(text='', icon='TIME')

    def draw(self, context):
        draw_always_on_panel(self.layout, context)


def _feature_entries():
    # The integrated runtime owns the actual always-on feature list. The legacy
    # common helper intentionally returns no dynamic entries instead of importing
    # a removed legacy optional module.
    return []


def _entry_text(entry, key_en, key_ja, fallback='', context=None):
    if _ui_is_japanese(context):
        value = entry.get(key_ja) or entry.get(key_en) or fallback
    else:
        value = entry.get(key_en) or entry.get(key_ja) or fallback
    return str(value or '').strip()


def draw_always_on_panel(layout, context):
    col = layout.column(align=True)
    entries = _feature_entries()
    if entries:
        for item in entries:
            alias = str(item.get('alias') or '')
            feature_key = str(item.get('key') or item.get('feature_key') or '')
            label = _entry_text(item, 'label_en', 'label_ja', feature_key or TOOL_LABEL_EN, context)
            enabled = bool(item.get('enabled'))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = True
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = False
        return
    enabled = bool(getattr(context.window_manager, _ALWAYS_ON_PROP, False))
    row = col.row(align=True)
    row.label(text=TOOL_LABEL_EN)
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
    op.enabled = True
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
    op.enabled = False


def _module_prefix():
    package = str(__package__ or '').strip()
    return package or PACKAGE_ID


def _same_package_class(cls):
    module_name = str(getattr(cls, '__module__', '') or '')
    prefix = _module_prefix()
    return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))


def _clean_label(label):
    raw = str(label or '').strip()
    if not raw:
        return raw
    for token in (' Suite', '_Suite', ' Toolset'):
        raw = raw.replace(token, '')
    if raw == ADDON_NAME or raw.replace('_', ' ') == ADDON_NAME.replace('_', ' '):
        return TOOL_LABEL_EN
    return raw


def _old_generated_name(name):
    text_value = str(name or '')
    upper = text_value.upper()
    return (
        '_SUITE_OT_OPEN_HELP' in upper or
        '_SUITE_OT_SET_ALWAYS_ON' in upper or
        '_SUITE_PT_ROOT' in upper or
        '_SUITE_PT_ALWAYS_ON' in upper
    )


def _materialize_annotations(cls):
    if not isinstance(cls, type):
        return cls
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
    except Exception:
        annotations = {}
    namespace = dict(globals())
    namespace.setdefault('bpy', bpy)
    prop_names = (
        'BoolProperty', 'BoolVectorProperty', 'CollectionProperty', 'EnumProperty',
        'FloatProperty', 'FloatVectorProperty', 'IntProperty', 'IntVectorProperty',
        'PointerProperty', 'StringProperty',
    )
    for prop_name in prop_names:
        try:
            namespace[prop_name] = getattr(bpy.props, prop_name)
        except Exception:
            pass
    changed = False
    for name, value in list(annotations.items()):
        if isinstance(value, str) and 'Property' in value and '(' in value:
            expr = value.strip().replace('bpy.props.', '')
            try:
                annotations[name] = eval(expr, namespace, namespace)
                changed = True
            except Exception:
                pass
    try:
        is_operator = issubclass(cls, bpy.types.Operator)
    except Exception:
        is_operator = False
    if is_operator:
        # Blender UI code frequently assigns these operator properties from
        # buttons. If a legacy class forgot to declare them, adding harmless
        # saved-skipped string properties prevents "property not found" warnings.
        for prop_name in ('mode', 'action', 'topic'):
            if prop_name not in annotations:
                try:
                    annotations[prop_name] = bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
                    changed = True
                except Exception:
                    pass
    if changed:
        try:
            setattr(cls, '__annotations__', annotations)
        except Exception:
            pass
    return cls


def _safe_unregister_class(cls):
    del cls
    if lifecycle is not None:
        lifecycle.release_scope('common.classes')
    return True


def _flatten_npanel_parent_before_register(cls):
    # Panel class definitions are immutable after import.
    return cls


def _register_class_wrapper(cls):
    _materialize_annotations(cls)
    if lifecycle is None:
        raise RuntimeError('Smart Cloth lifecycle is unavailable')
    return lifecycle.register_class(cls, scope='common.classes')


def begin_register():
    return None


def end_register():
    return None


def _iter_relevant_panels():
    return iter(())


def _is_always_panel(cls):
    value = ' '.join((
        str(getattr(cls, '__name__', '') or ''),
        str(getattr(cls, 'bl_idname', '') or ''),
        str(getattr(cls, 'bl_label', '') or ''),
    )).lower()
    return ('always' in value or '常時' in value or 'persistent' in value) and 'catalog' not in value


def _patch_panel_headers():
    return None


def _unpatch_panel_headers():
    _PATCHED_PANELS.clear()
    _PATCHED_POLLS.clear()


def _iter_relevant_addon_preferences():
    # Add-on preference UI is intentionally unused; all user-facing settings are
    # handled from the N-panel runtime preference group.
    return iter(())

def _patch_addon_preferences():
    return None

def _unpatch_addon_preferences():
    _PATCHED_PREFERENCES.clear()

def _simple_rna_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return None


def _iter_setting_roots(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return []
    roots = []
    # Legacy common persistence is intentionally limited to WindowManager
    # UI toggles.  Scene/Object values are owned by the .blend file and must
    # never be replayed from user_default after file load.
    for attr in ('window_manager',):
        root = getattr(ctx, attr, None)
        if root is not None:
            roots.append((attr, root))
    return roots


def _prop_relevant(name, value, owner=None):
    lower = str(name or '').lower()
    if lower == _ALWAYS_ON_PROP.lower() or lower.startswith(PACKAGE_ID.lower()):
        return True
    prefixes = ('smart_', 'ui_', 'enable_', 'show_', 'use_', 'auto_', 'sfs_', 'sf_', 'sas_', 'scsmart_', 'scs_', 'sgn_', 'sms_', 'smod_', 'sps_', 'srs_', 'srig_', 'ssel_', 'suv_', 'uv_', 'sw_', 'st_', 'sk_', 'sss_')
    if any(lower.startswith(prefix) for prefix in prefixes):
        return True
    try:
        module_name = str(getattr(type(value), '__module__', '') or '').lower()
        prefix = _module_prefix().lower()
        if prefix and module_name.startswith(prefix):
            return True
    except Exception:
        pass
    return False


def _serialize_group(obj, depth=0):
    if depth > 2 or obj is None:
        return {}
    data = {}
    try:
        props = getattr(getattr(obj, 'rna_type', None), 'properties', [])
    except Exception:
        props = []
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not identifier or identifier == 'rna_type' or getattr(prop, 'is_readonly', False):
                continue
            value = getattr(obj, identifier)
            simple = _simple_rna_value(value)
            if simple is not None:
                if _prop_relevant(identifier, value, obj):
                    data[identifier] = simple
            elif _prop_relevant(identifier, value, obj):
                nested = _serialize_group(value, depth + 1)
                if nested:
                    data[identifier] = nested
        except Exception:
            continue
    return data


def collect_persistent_settings(context=None):
    payload = {}
    for root_name, root in _iter_setting_roots(context):
        data = _serialize_group(root, 0)
        if data:
            payload[root_name] = data
    return payload


def _apply_group(obj, data, depth=0):
    if depth > 2 or not isinstance(data, dict):
        return
    for key, value in data.items():
        try:
            if isinstance(value, dict):
                child = getattr(obj, key, None)
                if child is not None:
                    _apply_group(child, value, depth + 1)
            elif hasattr(obj, key):
                setattr(obj, key, value)
        except Exception:
            pass


def apply_persistent_settings(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return
    data = _LOADED_SETTINGS or load_settings_file()
    for root_name, root in _iter_setting_roots(ctx):
        if root_name in data:
            _apply_group(root, data[root_name], 0)


def load_settings_file():
    global _LOADED_SETTINGS
    path = settings_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(raw, dict):
                common = raw.get('legacy_common_settings')
                if isinstance(common, dict):
                    _LOADED_SETTINGS = common
                    return common
                if 'runtime_preferences' not in raw and 'scene_settings' not in raw:
                    _LOADED_SETTINGS = raw
                    return raw
    except Exception:
        pass
    _LOADED_SETTINGS = {}
    return {}


def save_persistent_settings(context=None, force=False):
    global _AUTOSAVE_FINGERPRINT
    if not bool(force) and not _npanel_state_save_enabled(context):
        return
    data = collect_persistent_settings(context)
    try:
        raw = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2)
    except Exception:
        return
    if not force and raw == _AUTOSAVE_FINGERPRINT:
        return
    _AUTOSAVE_FINGERPRINT = raw
    try:
        path = settings_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            existing = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
        except Exception:
            existing = {}
        payload = dict(existing) if isinstance(existing, dict) else {}
        payload['version'] = max(int(payload.get('version', 0) or 0), 258)
        payload['file'] = 'Smart_Cloth_Suite.json'
        payload['legacy_common_settings'] = data
        writer = getattr(_suite_storage, 'atomic_write_json', None) if _suite_storage is not None else None
        if callable(writer):
            writer(path, payload, ensure_ascii=False, indent=2, sort_keys=True)
        else:
            path.write_text(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2), encoding='utf-8')
    except Exception:
        pass


def _autosave_timer():
    return None


@persistent
def _load_post_handler(dummy=None):
    try:
        # Load the file for legacy UI toggles only.  Do not apply scene-level
        # saved values after opening a .blend; the file's own scene/object data
        # must remain authoritative.
        load_settings_file()
    except Exception:
        pass


def _append_handler_once(collection, handler):
    del collection, handler
    return None


def _remove_handler(collection, handler):
    del collection, handler
    return None


def register():
    if lifecycle is None:
        raise RuntimeError('Smart Cloth lifecycle is unavailable')
    mark = lifecycle.checkpoint()
    try:
        lifecycle.register_translation(PACKAGE_ID, _translation_payload(), scope='common.translation')
        lifecycle.register_rna(
            bpy.types.WindowManager,
            _ALWAYS_ON_PROP,
            BoolProperty(
                name='Always-on',
                description='Enable persistent helper behavior only when it is required.',
                default=False,
            ),
            scope='common.rna',
        )
        for cls in (SMART_CLOTH_OT_open_help, SMART_CLOTH_OT_set_always_on, SMART_CLOTH_OT_save_preferences):
            _materialize_annotations(cls)
            lifecycle.register_class(cls, scope='common.classes')
            _REGISTERED_CLASSES.append(cls)
    except Exception:
        lifecycle.rollback_to(mark)
        _REGISTERED_CLASSES.clear()
        raise


def unregister():
    try:
        save_persistent_settings(bpy.context, force=True)
    except Exception:
        pass
    if lifecycle is not None:
        lifecycle.release_scope('common.rna')
        lifecycle.release_scope('common.classes')
        lifecycle.release_scope('common.translation')
    _REGISTERED_CLASSES.clear()
    _remove_previews()
