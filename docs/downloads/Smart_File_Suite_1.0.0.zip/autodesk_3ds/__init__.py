# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

__author__ = "JELararagi"
__version__ = "3.0.1"
__date__ = "24 Sep 2020"

bl_info = {
    "name": "Autodesk 3D Studio (.3ds)",
    "author": "JELararagi",
    "version": (3, 0, 1),
    "blender": (5, 1, 0),
    "location": "File > Import / Export",
    "description": "Import and export Autodesk 3D Studio (.3ds) files",
    "category": "Import-Export",
}


import bpy
from . import import_3ds
from . import export_3ds
from bpy_extras.io_utils import (
    ImportHelper,
    ExportHelper,
    orientation_helper,
    axis_conversion,
    poll_file_object_drop,
)
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    StringProperty,
    CollectionProperty,
)
from bpy.types import (
    Operator,
    FileHandler,
)


if "bpy" in locals():
    import importlib
    if "import_3ds" in locals():
        importlib.reload(import_3ds)
    if "export_3ds" in locals():
        importlib.reload(export_3ds)


@orientation_helper(axis_forward='Y', axis_up='Z')
class SFS_OT_3ds_import(Operator, ImportHelper):
    """Import from 3DS file format (.3ds)"""
    bl_idname = 'import_scene.sfs_3ds_import'
    bl_label = 'Import'
    bl_options = {'PRESET', 'UNDO'}

    filename_ext = ".3ds"
    filter_glob: StringProperty(default="*.3ds", options={'HIDDEN'})
    files: CollectionProperty(type=bpy.types.OperatorFileListElement, options={'HIDDEN', 'SKIP_SAVE'})
    directory: StringProperty(subtype='DIR_PATH')

    constrain_size: FloatProperty(
        name="Constrain Size",
        description="Scale the model by 10 until it reaches the "
        "size constraint (0 to disable)",
        min=0.0, max=1000.0,
        soft_min=0.0, soft_max=1000.0,
        default=10.0,
    )
    use_scene_unit: BoolProperty(
        name="Scene Units",
        description="Convert to scene unit length settings",
        default=False,
    )
    use_image_search: BoolProperty(
        name="Image Search",
        description="Search subdirectories for any associated images "
        "(Warning, may be slow)",
        default=True,
    )
    object_filter: EnumProperty(
        name="Object Filter", options={'ENUM_FLAG'},
        items=(('WORLD', "World".rjust(11), "", 'WORLD_DATA', 0x1),
               ('MESH', "Mesh".rjust(11), "", 'MESH_DATA', 0x2),
               ('LIGHT', "Light".rjust(12), "", 'LIGHT_DATA', 0x4),
               ('CAMERA', "Camera".rjust(11), "", 'CAMERA_DATA', 0x8),
               ('EMPTY', "Empty".rjust(11), "", 'EMPTY_AXIS', 0x10),
               ),
        description="Object types to import",
        default={'WORLD', 'MESH', 'LIGHT', 'CAMERA', 'EMPTY'},
    )
    use_apply_transform: BoolProperty(
        name="Apply Transform",
        description="Workaround for object transformations "
        "importing incorrectly",
        default=True,
    )
    use_keyframes: BoolProperty(
        name="Animation",
        description="Read the keyframe data",
        default=True,
    )
    use_collection: BoolProperty(
        name="Collection",
        description="Create a new collection",
        default=False,
    )
    use_cursor: BoolProperty(
        name="Cursor Origin",
        description="Read the 3D cursor location",
        default=False,
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        import_include(layout, self)
        import_transform(layout, self)

    def execute(self, context):
        keywords = self.as_keywords(ignore=("axis_forward",
                                            "axis_up",
                                            "filter_glob",
                                            ))
        global_matrix = axis_conversion(from_forward=self.axis_forward,
                                        from_up=self.axis_up,
                                        ).to_4x4()
        keywords["global_matrix"] = global_matrix

        return import_3ds.load(self, context, **keywords)

    def invoke(self, context, event):
        return self.invoke_popup(context)


def import_include(layout, operator):
    header, body = layout.panel("MAX3DS_import_include", default_closed=False)
    header.label(text="Include")
    if body:
        line = body.row(align=True)
        line.prop(operator, "use_image_search")
        line.label(text="", icon='OUTLINER_OB_IMAGE' if operator.use_image_search else 'IMAGE_DATA')
        line = body.row(align=True)
        line.prop(operator, "use_collection")
        line.label(text="", icon='OUTLINER_COLLECTION' if operator.use_collection else 'GROUP')
        body.column().prop(operator, "object_filter")
        line = body.row(align=True)
        line.prop(operator, "use_keyframes")
        line.label(text="", icon='ANIM' if operator.use_keyframes else 'DECORATE_DRIVER')
        line = body.row(align=True)
        line.prop(operator, "use_cursor")
        line.label(text="", icon='PIVOT_CURSOR' if operator.use_cursor else 'CURSOR')


def import_transform(layout, operator):
    header, body = layout.panel("MAX3DS_import_transform", default_closed=False)
    header.label(text="Transform")
    if body:
        body.prop(operator, "constrain_size")
        line = body.row(align=True)
        line.prop(operator, "use_scene_unit")
        line.label(text="", icon='EMPTY_ARROWS' if operator.use_scene_unit else 'EMPTY_DATA')
        line = body.row(align=True)
        line.prop(operator, "use_apply_transform")
        line.label(text="", icon='MESH_CUBE' if operator.use_apply_transform else 'MOD_SOLIDIFY')
        body.prop(operator, "axis_forward")
        body.prop(operator, "axis_up")


@orientation_helper(axis_forward='Y', axis_up='Z')
class SFS_OT_3ds_export(Operator, ExportHelper):
    """Export to 3DS file format (.3ds)"""
    bl_idname = 'export_scene.sfs_3ds_export'
    bl_label = 'Export'
    bl_options = {'PRESET', 'UNDO'}

    filename_ext = ".3ds"
    filter_glob: StringProperty(default="*.3ds", options={'HIDDEN'})

    collection: StringProperty(
        name="Source Collection",
        description="Export objects from this collection",
        default="",
    )
    scale_factor: FloatProperty(
        name="Scale Factor",
        description="Master scale factor for all objects",
        min=0.0, max=100000.0,
        soft_min=0.0, soft_max=100000.0,
        default=1.0,
    )
    use_scene_unit: BoolProperty(
        name="Scene Units",
        description="Take the scene unit length settings into account",
        default=False,
    )
    use_images: BoolProperty(
        name="Images",
        description="Export all associated images from the scene",
        default=True,
    )
    use_selection: BoolProperty(
        name="Selection",
        description="Export selected objects only",
        default=False,
    )
    object_filter: EnumProperty(
        name="Object Filter", options={'ENUM_FLAG'},
        items=(('WORLD', "World".rjust(11), "", 'WORLD_DATA',0x1),
               ('MESH', "Mesh".rjust(11), "", 'MESH_DATA', 0x2),
               ('LIGHT', "Light".rjust(12), "", 'LIGHT_DATA',0x4),
               ('CAMERA', "Camera".rjust(11), "", 'CAMERA_DATA',0x8),
               ('EMPTY', "Empty".rjust(11), "", 'EMPTY_AXIS',0x10),
               ('OTHER', "Other".rjust(12), "", 'MATSHADERBALL', 0x20),
               ),
        description="Object types to export",
        default={'WORLD', 'MESH', 'LIGHT', 'CAMERA', 'EMPTY', 'OTHER'},
    )
    use_apply_transform: BoolProperty(
        name="Apply Transform",
        description="Apply matrix transform before export",
        default=True,
    )
    use_invisible: BoolProperty(
        name="Invisible",
        description="Export invisible objects",
        default=False,
    )
    use_keyframes: BoolProperty(
        name="Animation",
        description="Write the keyframe data",
        default=True,
    )
    use_hierarchy: BoolProperty(
        name="Hierarchy",
        description="Export hierarchy chunks",
        default=False,
    )
    use_collection: BoolProperty(
        name="Collection",
        description="Export active collection only",
        default=False,
    )
    use_cursor: BoolProperty(
        name="Cursor Origin",
        description="Save the 3D cursor location",
        default=False,
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        browser = context.space_data.type == 'FILE_BROWSER'

        export_include(layout, self, browser)
        export_transform(layout, self)

    def execute(self, context):
        keywords = self.as_keywords(ignore=("axis_forward",
                                            "axis_up",
                                            "filter_glob",
                                            "check_existing",
                                            ))
        global_matrix = axis_conversion(to_forward=self.axis_forward,
                                        to_up=self.axis_up,
                                        ).to_4x4()
        keywords["global_matrix"] = global_matrix

        return export_3ds.save(self, context, **keywords)


def export_include(layout, operator, browser):
    header, body = layout.panel("MAX3DS_export_include", default_closed=False)
    header.label(text="Include")
    if body:
        line = body.row(align=True)
        line.prop(operator, "use_images")
        line.label(text="", icon='OUTLINER_OB_IMAGE' if operator.use_images else 'IMAGE_DATA')
        line = body.row(align=True)
        line.prop(operator, "use_invisible")
        line.label(text="", icon='HIDE_OFF' if operator.use_invisible else 'HIDE_ON')
        line = body.row(align=True)
        line.prop(operator, "use_selection")
        line.label(text="", icon='RESTRICT_SELECT_OFF' if operator.use_selection else 'RESTRICT_SELECT_ON')
        if browser:
            line = body.row(align=True)
            line.prop(operator, "use_collection")
            line.label(text="", icon='OUTLINER_COLLECTION' if operator.use_collection else 'GROUP')
        body.column().prop(operator, "object_filter")
        line = body.row(align=True)
        line.prop(operator, "use_keyframes")
        line.label(text="", icon='ANIM' if operator.use_keyframes else 'DECORATE_DRIVER')
        line = body.row(align=True)
        line.prop(operator, "use_hierarchy")
        line.label(text="", icon='OUTLINER' if operator.use_hierarchy else 'CON_CHILDOF')
        line = body.row(align=True)
        line.prop(operator, "use_cursor")
        line.label(text="", icon='PIVOT_CURSOR' if operator.use_cursor else 'CURSOR')


def export_transform(layout, operator):
    header, body = layout.panel("MAX3DS_export_transform", default_closed=False)
    header.label(text="Transform")
    if body:
        body.prop(operator, "scale_factor")
        line = body.row(align=True)
        line.prop(operator, "use_scene_unit")
        line.label(text="", icon='EMPTY_ARROWS' if operator.use_scene_unit else 'EMPTY_DATA')
        line = body.row(align=True)
        line.prop(operator, "use_apply_transform")
        line.label(text="", icon='MESH_CUBE' if operator.use_apply_transform else 'MOD_SOLIDIFY')
        body.prop(operator, "axis_forward")
        body.prop(operator, "axis_up")


class IO_FH_3ds_3ds_file_handler(FileHandler):
    bl_idname = 'IO_FH_3ds_3ds_file_handler'
    bl_label = '3DS File Handler'
    bl_import_operator = "import_scene.sfs_3ds_import"
    bl_export_operator = "export_scene.sfs_3ds_export"
    bl_file_extensions = ".3ds;.3DS"

    @classmethod
    def poll_drop(cls, context):
        return poll_file_object_drop(context)


# Add to a menu
def menu_func_export(self, context):
    self.layout.operator(SFS_OT_3ds_export.bl_idname, text='Export')


def menu_func_import(self, context):
    self.layout.operator(SFS_OT_3ds_import.bl_idname, text='Import')


def register():
    bpy.utils.register_class(SFS_OT_3ds_import)
    bpy.utils.register_class(SFS_OT_3ds_export)
    bpy.utils.register_class(IO_FH_3ds_3ds_file_handler)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
    bpy.utils.unregister_class(SFS_OT_3ds_import)
    bpy.utils.unregister_class(SFS_OT_3ds_export)
    bpy.utils.unregister_class(IO_FH_3ds_3ds_file_handler)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)


if __name__ == "__main__":
    register()
