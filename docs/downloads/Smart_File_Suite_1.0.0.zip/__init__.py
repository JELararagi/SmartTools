# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

# Add-on bootstrap: Smart File
# Format policy: metadata, ownership guard, runtime registration, runtime unregistration.

from __future__ import annotations

# Blender Extension policy: keep this package inside Blender's extension namespace.
# Do not register a top-level ``smart_file_suite`` module alias; Blender flags
# extension files imported through top-level module names as a policy violation.
import sys as _sys

# A live ``importlib.reload`` executes in the existing module dictionary.  Tear
# down the prior generation now, while its exact class/callback identities are
# still reachable, before this file replaces those globals with new objects.
_sfs_prior_reload_warning = ""
_sfs_prior_cancel_repair = globals().get("_sfs_cancel_registration_repair")
_sfs_prior_reverse_generation = globals().get("_sfs_reverse_root_generation")
try:
    if callable(_sfs_prior_cancel_repair):
        _sfs_prior_cancel_repair(reset_attempts=False)
    if callable(_sfs_prior_reverse_generation):
        _sfs_prior_reverse_generation()
except Exception as _sfs_prior_reload_exc:
    _sfs_prior_reload_warning = (
        f"{type(_sfs_prior_reload_exc).__name__}: {_sfs_prior_reload_exc}"
    )[:512]
if _sfs_prior_reload_warning:
    try:
        print(
            "[Smart File Suite][LIVE_RELOAD_CLEANUP] WARNING: "
            + _sfs_prior_reload_warning
        )
    except Exception:
        pass
if __name__ != 'smart_file_suite':
    try:
        _legacy_module = _sys.modules.get('smart_file_suite')
        _current_module = _sys.modules.get(__name__)
        if _legacy_module is _current_module or getattr(_legacy_module, '__file__', None) == __file__:
            _sys.modules.pop('smart_file_suite', None)
    except Exception:
        pass


import importlib
sys = _sys
import traceback

import bpy

from .operator_policy import prepare_operator_class as _sfs_prepare_operator_class

# Existing core registration helpers resolve this package-local hook from their
# own module globals immediately before registering a known Smart File class.
# It is not installed on bpy.utils and never receives foreign classes.
_jel_status_instrument_class_v2 = _sfs_prepare_operator_class

# Cold-start policy: package import performs no mutable-data migration, preview
# allocation, atexit registration, directory traversal, or package-local cleanup.
# Command-specific modules remain lazy until their explicit command path uses them.
_sfs_preview_cleanup = None

# Compatibility guards are an explicit Always-on Toggles feature.  Import-time
# global patching made every subsequently loaded Extension pay Smart File's
# compatibility cost and could stall Blender before its first window appeared.
_sfs_compatibility_early_sanitize = None


bl_info = {
    "name": 'Smart File',
    "author": 'JELararagi',
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "Sidebar > Smart File",
    "description": "Smart File is shown as a standard multi-editor Sidebar N-panel category named Smart File, with File Pipeline visual command deck controls.",
    "category": 'Smart File',
}


# Blender can remove public metadata before calling register.
_SFS_RELEASE_VERSION = bl_info["version"]
__version__ = ".".join(map(str, _SFS_RELEASE_VERSION))


_SFS_OWNER_KEY = "SMART_FILE_SUITE_OWNER"
_SFS_CORE_BOOTSTRAPPED = False
_SFS_CORE_REGISTER = None
_SFS_CORE_UNREGISTER = None
_SFS_CORE_REGISTERED = False
_SFS_TOOL_RUNTIME_REGISTERED = False


_SFS_FALLBACK_REGISTERED = False
_SFS_FALLBACK_ACTIVE = False
_SFS_FALLBACK_ERROR = ""
_SFS_ANCHOR_REGISTERED = False



def _sfs_current_owner_name() -> str:
    return (__package__ or __name__ or "smart_file_suite").strip()


def _sfs_is_japanese_ui() -> bool:
    try:
        view = getattr(getattr(bpy.context, "preferences", None), "view", None)
        if view is not None and not bool(getattr(view, "use_translate_interface", True)):
            return False
        locale = str(getattr(getattr(bpy.app, "translations", None), "locale", "") or "")
        if not locale:
            locale = str(getattr(view, "language", "") or "")
        return locale.lower().startswith("ja")
    except Exception:
        return False


def _sfs_lang(en: str, ja: str) -> str:
    return ja if _sfs_is_japanese_ui() else en


def _sfs_tag_redraw_view3d() -> None:
    try:
        wm = getattr(getattr(bpy, "context", None), "window_manager", None)
        supported = {"VIEW_3D", "IMAGE_EDITOR", "NODE_EDITOR", "SEQUENCE_EDITOR", "CLIP_EDITOR", "DOPESHEET_EDITOR", "GRAPH_EDITOR", "NLA_EDITOR", "TEXT_EDITOR", "FILE_BROWSER", "SPREADSHEET"}
        for window in getattr(wm, "windows", ()) if wm is not None else ():
            screen = getattr(window, "screen", None)
            for area in getattr(screen, "areas", ()) if screen is not None else ():
                if str(getattr(area, "type", "") or "") in supported:
                    area.tag_redraw()
    except Exception:
        pass


def _sfs_rna_base_types() -> tuple[type, ...]:
    bases = []
    for name in (
        "Panel",
        "Operator",
        "Menu",
        "UIList",
        "PropertyGroup",
        "AddonPreferences",
        "Header",
        "FileHandler",
        "AssetShelf",
    ):
        try:
            base = getattr(bpy.types, name, None)
        except Exception:
            base = None
        if isinstance(base, type):
            bases.append(base)
    return tuple(bases)


def _sfs_lookup_registered_class(identifier_or_cls, *, bases: tuple[type, ...] | None = None):
    """Lookup a registered RNA class without Blender's recursive subclass API.

    The `bases` argument is kept for older call sites but is intentionally
    unused. On Blender 5.1, recursive RNA subclass lookup from a
    msgbus-triggered add-on load can crash the host process.
    """
    identifiers = []

    def _add(value):
        value = str(value or "").strip()
        if value and value not in identifiers:
            identifiers.append(value)

    def _rna_identifier_from_bl_idname(value: str) -> str:
        value = str(value or "").strip()
        if "." not in value:
            return ""
        prefix, suffix = value.split(".", 1)
        prefix = prefix.strip().upper()
        suffix = suffix.strip()
        if not prefix or not suffix:
            return ""
        return f"{prefix}_OT_{suffix}"

    if isinstance(identifier_or_cls, type):
        _add(getattr(identifier_or_cls, "__name__", ""))
        bl_idname = getattr(identifier_or_cls, "bl_idname", "")
        _add(bl_idname)
        _add(_rna_identifier_from_bl_idname(bl_idname))
        try:
            _add(getattr(getattr(identifier_or_cls, "bl_rna", None), "identifier", ""))
        except Exception:
            pass
    else:
        value = str(identifier_or_cls or "").strip()
        _add(value)
        _add(_rna_identifier_from_bl_idname(value))

    for identifier in identifiers:
        try:
            existing = getattr(bpy.types, identifier, None)
        except Exception:
            existing = None
        if isinstance(existing, type):
            return existing
    return None

def _sfs_class_has_bl_rna(cls) -> bool:
    try:
        if not isinstance(cls, type):
            return False
        rna = vars(cls).get("bl_rna")
        return bool(rna is not None and str(getattr(rna, "identifier", "") or "").strip())
    except Exception:
        return False


def _sfs_safe_register_class(cls) -> None:
    if not isinstance(cls, type):
        return
    if _sfs_class_has_bl_rna(cls):
        return
    instrument = globals().get('_jel_status_instrument_class_v2')
    if callable(instrument):
        instrument(cls)
    try:
        bpy.utils.register_class(cls)
    except Exception as ex:
        msg = str(ex).lower()
        if "already registered" not in msg and "registered as a subclass" not in msg:
            raise
        if _sfs_class_has_bl_rna(cls):
            return
        raise RuntimeError(
            f"Smart File RNA identity is registered by another generation: "
            f"{getattr(cls, '__name__', cls)!r}."
        ) from ex
    if not _sfs_class_has_bl_rna(cls):
        raise RuntimeError(f"Smart File could not register RNA for {getattr(cls, '__name__', cls)!r}.")


def _sfs_safe_unregister_class(cls) -> None:
    try:
        if isinstance(cls, type) and _sfs_class_has_bl_rna(cls):
            bpy.utils.unregister_class(cls)
    except Exception:
        pass


def _sfs_core_panel_registered() -> bool:
    try:
        cls = globals().get("SF_PT_reference_manager_reference_manager_workspace")
        if not isinstance(cls, type) or not _sfs_class_has_bl_rna(cls):
            return False
        panel_ok = (
            str(getattr(cls, "bl_space_type", "") or "") == "VIEW_3D"
            and str(getattr(cls, "bl_region_type", "") or "") == "UI"
            and str(getattr(cls, "bl_category", "") or "") == "Smart File"
            and callable(getattr(cls, "draw", None))
            and bool(getattr(cls, "_sfs_standard_npanel_anchor", False))
        )
        if not panel_ok:
            return False
        # A registered Panel alone is not enough. If the N-panel WindowManager
        # properties are missing, the main panel draw path has no page selector
        # or settings to display and the tab appears blank. Treat that as an
        # incomplete registration so the anchor/recovery UI remains visible.
        wm_type = getattr(bpy.types, "WindowManager", None)
        wm = getattr(getattr(bpy, "context", None), "window_manager", None)
        return bool(
            (wm is not None and hasattr(wm, "sf_workspace_page"))
            or (wm_type is not None and hasattr(wm_type, "sf_workspace_page"))
        )
    except Exception:
        return False


def _sfs_repair_core_npanel_if_needed() -> bool:
    if _sfs_core_panel_registered():
        return True
    repair = globals().get("_sf_repair_workspace_props")
    if callable(repair):
        try:
            repair(getattr(bpy, "context", None))
        except Exception:
            pass
    return _sfs_core_panel_registered()


class SMARTFILESUITE_OT_system_retry_runtime(bpy.types.Operator):
    bl_idname = 'smart_file_suite.sfs_system_retry_runtime'
    bl_label = 'Retry Runtime'
    bl_description = "Retry loading the Smart File runtime after a startup registration error."

    bl_options = {'UNDO'}
    @classmethod
    def description(cls, context, properties):
        return _sfs_lang(
            "Retry loading the Smart File runtime after a startup registration error.",
            "起動時の登録エラー後に、Smart File ランタイムの読み込みを再試行します。",
        )

    def execute(self, context):
        global _SFS_FALLBACK_ACTIVE, _SFS_FALLBACK_ERROR
        try:
            _sf_ensure_full_runtime_loaded()
            _SFS_FALLBACK_ACTIVE = False
            _SFS_FALLBACK_ERROR = ""
            _sfs_tag_redraw_view3d()
            return {'FINISHED'}
        except Exception:
            _sf_unload_full_runtime()
            _SFS_FALLBACK_ERROR = traceback.format_exc()
            _SFS_FALLBACK_ACTIVE = True
            try:
                _sfs_register_fallback_panel(_SFS_FALLBACK_ERROR)
            except Exception:
                pass
            _sfs_tag_redraw_view3d()
            try:
                self.report({'WARNING'}, _sfs_lang("Smart File runtime could not be loaded.", "Smart File ランタイムを読み込めませんでした。"))
            except Exception:
                pass
            return {'CANCELLED'}


class SMARTFILESUITE_PT_system_file_suite(bpy.types.Panel):
    bl_label = 'File Suite'
    bl_idname = 'SMARTFILESUITE_PT_system_file_suite'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart File'
    bl_parent_id = 'SF_PT_reference_manager_reference_manager_workspace'
    bl_order = 0

    @classmethod
    def poll(cls, context):
        if not _SFS_FALLBACK_ACTIVE:
            return False
        area = getattr(context, "area", None)
        return area is None or str(getattr(area, "type", "") or "") == "VIEW_3D"

    def draw_header_preset(self, context):
        op = self.layout.operator('smart_file_suite.open_help', text='', icon='QUESTION')
        op.topic = 'recovery'

    def draw(self, context):
        layout = self.layout
        layout.label(text=_sfs_lang("Startup recovery mode", "起動復旧モード"), icon='ERROR')
        layout.label(text=_sfs_lang("The Smart File N-panel category is available, but the full runtime failed to load.", "Smart File のNパネル分類は表示されていますが、フルランタイムの読み込みに失敗しました。"), icon='BLANK1')
        layout.operator(SMARTFILESUITE_OT_system_retry_runtime.bl_idname, text=_sfs_lang("Retry Runtime Load", "ランタイム読み込みを再試行"), icon='FILE_REFRESH')
        err = str(_SFS_FALLBACK_ERROR or "").strip()
        if err:
            box = layout.box()
            box.label(text=_sfs_lang("Last error", "最後のエラー"), icon='CONSOLE')
            tail = err.splitlines()[-8:]
            for line in tail:
                line = str(line or "").strip()
                if not line:
                    continue
                box.label(text=line[:120])


class SMARTFILESUITE_OT_system_load_ui(bpy.types.Operator):
    bl_idname = 'smart_file_suite.sfs_system_load_ui'
    bl_label = 'Load UI'
    bl_description = "Load or repair the full Smart File N-panel UI."

    bl_options = {'UNDO'}
    @classmethod
    def description(cls, context, properties):
        return _sfs_lang(
            "Load or repair the full Smart File N-panel UI. This does not change Blender theme, transparency, or workspace tool settings.",
            "Smart File の完全なNパネルUIを読み込み、または修復します。Blenderテーマ、透明度、ワークスペースツール設定は変更しません。",
        )

    def execute(self, context):
        global _SFS_FALLBACK_ACTIVE, _SFS_FALLBACK_ERROR, _SFS_CORE_REGISTERED, _SFS_TOOL_RUNTIME_REGISTERED
        try:
            # First try the lightweight property repair path. If the Panel RNA is
            # already registered and only its WindowManager settings are missing,
            # this avoids a full unregister/register cycle and prevents a blank
            # N-panel from persisting.
            if not _sfs_repair_core_npanel_if_needed():
                _SFS_CORE_REGISTERED = False
                _SFS_TOOL_RUNTIME_REGISTERED = False
            if not _sf_ensure_full_runtime_loaded() or not _sfs_repair_core_npanel_if_needed():
                raise RuntimeError("Smart File N-panel could not be registered.")
            _SFS_FALLBACK_ACTIVE = False
            _SFS_FALLBACK_ERROR = ""
            _sfs_tag_redraw_view3d()
            return {'FINISHED'}
        except Exception:
            _SFS_FALLBACK_ERROR = traceback.format_exc()
            _SFS_FALLBACK_ACTIVE = True
            _sfs_tag_redraw_view3d()
            try:
                self.report({'WARNING'}, _sfs_lang("Smart File UI could not be loaded.", "Smart File UIを読み込めませんでした。"))
            except Exception:
                pass
            return {'CANCELLED'}


class SMARTFILESUITE_PT_system_file_suite_2(bpy.types.Panel):
    bl_label = 'File Suite'
    bl_idname = 'SMARTFILESUITE_PT_system_file_suite_2'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart File'
    bl_parent_id = 'SF_PT_reference_manager_reference_manager_workspace'
    bl_order = -1000

    @classmethod
    def poll(cls, context):
        area = getattr(context, "area", None)
        if area is not None and str(getattr(area, "type", "") or "") != "VIEW_3D":
            return False
        return bool(_SFS_FALLBACK_ACTIVE or not _sfs_core_panel_registered())

    def draw_header_preset(self, context):
        op = self.layout.operator('smart_file_suite.open_help', text='', icon='QUESTION')
        op.topic = 'recovery'

    def draw(self, context):
        layout = self.layout
        layout.label(text=_sfs_lang("Smart File", "Smart File"), icon='ASSET_MANAGER')
        if _sfs_core_panel_registered() and not _SFS_FALLBACK_ACTIVE:
            layout.label(text=_sfs_lang("The full N-panel UI is already registered.", "完全なNパネルUIは登録済みです。"), icon='CHECKMARK')
            return
        layout.label(text=_sfs_lang("The standard Smart File N-panel is not fully loaded.", "標準Smart File Nパネルが完全には読み込まれていません。"))
        layout.operator(SMARTFILESUITE_OT_system_load_ui.bl_idname, text=_sfs_lang("Load Smart File UI", "Smart File UIを読み込む"), icon='FILE_REFRESH')
        err = str(_SFS_FALLBACK_ERROR or "").strip()
        if err:
            box = layout.box()
            box.label(text=_sfs_lang("Last registration error", "最後の登録エラー"), icon='CONSOLE')
            for line in err.splitlines()[-6:]:
                line = str(line or "").strip()
                if line:
                    box.label(text=line[:120])


def _sfs_ensure_canonical_root_for_children():
    """Register the canonical Smart File root before any child Panel RNA."""
    root_cls = globals().get("SF_PT_reference_manager_reference_manager_workspace")
    if not isinstance(root_cls, type):
        bootstrap = globals().get("_sf_bootstrap_core_namespace")
        if not callable(bootstrap) or not bool(bootstrap()):
            raise RuntimeError("Smart File canonical root class is unavailable")
        root_cls = globals().get("SF_PT_reference_manager_reference_manager_workspace")
    if not isinstance(root_cls, type):
        raise RuntimeError("Smart File canonical root class was not defined")
    _sfs_safe_register_class(root_cls)
    if not _sfs_class_has_bl_rna(root_cls):
        raise RuntimeError("Smart File canonical root RNA validation failed")
    return root_cls


def _sfs_register_anchor_panel() -> None:
    global _SFS_ANCHOR_REGISTERED
    _sfs_ensure_canonical_root_for_children()
    classes = (
        _sfs_get_common_runtime().SMART_FILE_OT_system_open_help,
        SMARTFILESUITE_OT_system_load_ui,
        SMARTFILESUITE_PT_system_file_suite_2,
    )
    if _SFS_ANCHOR_REGISTERED and all(_sfs_class_has_bl_rna(cls) for cls in classes):
        return
    _SFS_ANCHOR_REGISTERED = False
    acquired = []
    try:
        for cls in classes:
            was_ready = _sfs_class_has_bl_rna(cls)
            _sfs_safe_register_class(cls)
            if not _sfs_class_has_bl_rna(cls):
                raise RuntimeError(f"anchor class RNA validation failed: {cls.__name__}")
            if not was_ready:
                acquired.append(cls)
        _SFS_ANCHOR_REGISTERED = True
    except Exception:
        for cls in reversed(acquired):
            _sfs_safe_unregister_class(cls)
        raise


def _sfs_unregister_anchor_panel() -> None:
    global _SFS_ANCHOR_REGISTERED
    for cls in reversed((
        SMARTFILESUITE_OT_system_load_ui,
        SMARTFILESUITE_PT_system_file_suite_2,
    )):
        _sfs_safe_unregister_class(cls)
    if _SMART_COMMON is not None:
        _sfs_safe_unregister_class(_SMART_COMMON.SMART_FILE_OT_system_open_help)
    _SFS_ANCHOR_REGISTERED = False


def _sfs_register_fallback_panel(error: str = "") -> None:
    global _SFS_FALLBACK_REGISTERED, _SFS_FALLBACK_ACTIVE, _SFS_FALLBACK_ERROR
    try:
        _sfs_register_anchor_panel()
    except Exception:
        pass
    _SFS_FALLBACK_ERROR = str(error or _SFS_FALLBACK_ERROR or "")
    _SFS_FALLBACK_ACTIVE = True
    classes = (
        SMARTFILESUITE_OT_system_retry_runtime,
        SMARTFILESUITE_PT_system_file_suite,
    )
    if not (_SFS_FALLBACK_REGISTERED and all(_sfs_class_has_bl_rna(cls) for cls in classes)):
        _SFS_FALLBACK_REGISTERED = False
        acquired = []
        try:
            for cls in classes:
                was_ready = _sfs_class_has_bl_rna(cls)
                _sfs_safe_register_class(cls)
                if not _sfs_class_has_bl_rna(cls):
                    raise RuntimeError(f"fallback class RNA validation failed: {cls.__name__}")
                if not was_ready:
                    acquired.append(cls)
            _SFS_FALLBACK_REGISTERED = True
        except Exception:
            for cls in reversed(acquired):
                _sfs_safe_unregister_class(cls)
            raise
    _sfs_tag_redraw_view3d()


def _sfs_hide_fallback_panel() -> None:
    global _SFS_FALLBACK_ACTIVE, _SFS_FALLBACK_ERROR
    _SFS_FALLBACK_ACTIVE = False
    _SFS_FALLBACK_ERROR = ""
    _sfs_tag_redraw_view3d()


def _sfs_unregister_fallback_panel() -> None:
    global _SFS_FALLBACK_REGISTERED, _SFS_FALLBACK_ACTIVE, _SFS_FALLBACK_ERROR
    for cls in reversed((
        SMARTFILESUITE_OT_system_retry_runtime,
        SMARTFILESUITE_PT_system_file_suite,
    )):
        _sfs_safe_unregister_class(cls)
    _SFS_FALLBACK_REGISTERED = False
    _SFS_FALLBACK_ACTIVE = False
    _SFS_FALLBACK_ERROR = ""



def _sfs_i18n_install() -> None:
    # GUI and background use the same registration path. Blender 5.1 stability:
    # never monkey-patch bpy.types.UILayout or mutate process-global UI state.
    # process-global UI state. Localization uses package translation tables only.
    try:
        from . import ui_language_runtime as _ui_language_runtime
        _ui_language_runtime.uninstall_runtime_text_hooks()
    except Exception:
        pass


def _sfs_i18n_uninstall() -> None:
    try:
        from . import ui_language_runtime as _ui_language_runtime
        _ui_language_runtime.uninstall_runtime_text_hooks()
    except Exception:
        pass


def _sfs_tool_guard_register() -> None:
    # Smart File is a standard N-panel add-on.  It must not change the
    # active VIEW_3D workspace tool while registering or drawing panels.
    return None


def _sfs_tool_guard_unregister() -> None:
    try:
        from . import state_guard as _state_guard
        _state_guard.unregister()
    except Exception:
        pass


def _sfs_tool_guard_schedule_check() -> None:
    # Compatibility no-op retained for older internal call sites.
    return None


def _sfs_enforce_single_npanel(context=None) -> int:
    try:
        from . import npanel_singleton as _sfs_npanel_singleton
        return int(_sfs_npanel_singleton.enforce(context) or 0)
    except Exception:
        return 0


def _sfs_restore_single_npanel_guard() -> None:
    try:
        from . import npanel_singleton as _sfs_npanel_singleton
        _sfs_npanel_singleton.restore_hidden()
    except Exception:
        pass



def _sfs_compatibility_guards_register() -> bool:
    try:
        from . import compatibility_guards as _sfs_compatibility_guards
        return _sfs_compatibility_guards.register() is True
    except Exception:
        return False


def _sfs_compatibility_guards_unregister() -> None:
    # Teardown only an already-loaded package module.  Importing the optional
    # guard just to disable it would add cold-start work and could create the
    # resources this call is intended to keep absent.
    try:
        module_name = f"{_sf_package_name()}.compatibility_guards"
        module = sys.modules.get(module_name)
        unregister_fn = getattr(module, "unregister", None) if module is not None else None
        if callable(unregister_fn):
            unregister_fn()
    except Exception:
        pass


def _sfs_multi_editor_panels_register() -> bool:
    from . import multi_editor_panels as _sfs_multi_editor_panels
    if _sfs_multi_editor_panels.register() is not True:
        return False
    status = _sfs_multi_editor_panels.runtime_status()
    expected_clones = int(status.get("expected_clone_count", 0) or 0)
    return bool(
        status.get("registered")
        and status.get("source_exact")
        and int(status.get("clone_count", 0) or 0) == expected_clones
        and int(status.get("physical_root_count", 0) or 0) == expected_clones + 1
        and int(status.get("authoritative_native_roots", 0) or 0) == expected_clones + 1
        and status.get("ids_within_limit")
    )


def _sfs_multi_editor_panels_unregister() -> None:
    try:
        from . import multi_editor_panels as _sfs_multi_editor_panels
        _sfs_multi_editor_panels.unregister()
    except Exception:
        pass


def _sfs_get_owner():
    try:
        return bpy.app.driver_namespace.get(_SFS_OWNER_KEY)
    except Exception:
        return None


def _sfs_set_owner(owner):
    try:
        bpy.app.driver_namespace[_SFS_OWNER_KEY] = owner
    except Exception:
        pass


def _sfs_clear_owner(owner):
    try:
        ns = bpy.app.driver_namespace
        if ns.get(_SFS_OWNER_KEY) == owner:
            ns.pop(_SFS_OWNER_KEY, None)
    except Exception:
        pass


def _sfs_can_register() -> bool:
    """Acquire the owner after exact reachable prior-generation teardown."""
    current_owner = _sfs_current_owner_name()
    owner = _sfs_get_owner()
    if owner and owner != current_owner:
        try:
            old_module = sys.modules.get(str(owner))
            if old_module is not None and old_module is not sys.modules.get(__name__):
                cleanup = getattr(old_module, "_sfs_reverse_root_generation", None)
                if not callable(cleanup):
                    cleanup = getattr(old_module, "unregister", None)
                if callable(cleanup):
                    cleanup()
        except Exception as exc:
            _sfs_warn_registration_once(
                "STALE_OWNER_CLEANUP",
                f"{type(exc).__name__}: {exc}",
            )
        try:
            bpy.app.driver_namespace.pop(_SFS_OWNER_KEY, None)
        except Exception:
            pass
    _sfs_set_owner(current_owner)
    return True



def _sf_package_name() -> str:
    return (__package__ or __name__ or "").strip()


def _sf_import_package_module(module_suffix: str):
    package = _sf_package_name()
    module_name = f"{package}.{module_suffix}" if package else module_suffix
    module = sys.modules.get(module_name)
    if module is None:
        module = importlib.import_module(module_name)
    return module


def _sf_load_bootstrap_module():
    package = _sf_package_name()
    module_name = f"{package}.bootstrap_stable" if package else "bootstrap_stable"
    module = sys.modules.get(module_name)
    if module is None:
        module = importlib.import_module(module_name)
    return module


def _sf_bootstrap_core_namespace() -> bool:
    global _SFS_CORE_BOOTSTRAPPED, _SFS_CORE_REGISTER, _SFS_CORE_UNREGISTER
    if _SFS_CORE_BOOTSTRAPPED and callable(_SFS_CORE_REGISTER):
        return True

    current_register = globals().get("register")
    current_unregister = globals().get("unregister")

    bootstrap_module = _sf_load_bootstrap_module()
    bootstrap_module.run_bootstrap(globals(), __file__)
    bl_info["version"] = _SFS_RELEASE_VERSION

    _SFS_CORE_REGISTER = globals().get("register")
    _SFS_CORE_UNREGISTER = globals().get("unregister")
    globals()["register"] = current_register
    globals()["unregister"] = current_unregister

    _SFS_CORE_BOOTSTRAPPED = callable(_SFS_CORE_REGISTER)
    return bool(_SFS_CORE_BOOTSTRAPPED)


def _sf_tag_redraw_view3d() -> None:
    try:
        wm = getattr(getattr(bpy, "context", None), "window_manager", None)
    except Exception:
        wm = None
    supported = {"VIEW_3D", "IMAGE_EDITOR", "NODE_EDITOR", "SEQUENCE_EDITOR", "CLIP_EDITOR", "DOPESHEET_EDITOR", "GRAPH_EDITOR", "NLA_EDITOR", "TEXT_EDITOR", "FILE_BROWSER", "SPREADSHEET"}
    for window in getattr(wm, "windows", ()) if wm is not None else ():
        screen = getattr(window, "screen", None)
        for area in getattr(screen, "areas", ()) if screen is not None else ():
            try:
                if str(getattr(area, "type", "") or "") in supported:
                    area.tag_redraw()
            except Exception:
                pass


def _sf_ensure_full_runtime_loaded() -> bool:
    global _SFS_CORE_REGISTERED, _SFS_TOOL_RUNTIME_REGISTERED
    if _SFS_CORE_REGISTERED and not _sfs_core_panel_registered():
        # A previous interrupted install/update can leave the internal flag set
        # even though Blender no longer has the VIEW_3D/UI panel class.  Tear
        # down child Panels before the canonical root, then rebuild root-first.
        _sf_unload_full_runtime()
        _sfs_register_anchor_panel()
    if _SFS_CORE_REGISTERED and _SFS_TOOL_RUNTIME_REGISTERED and _sfs_core_panel_registered():
        return True
    if not _sf_bootstrap_core_namespace():
        return False

    core_loaded_now = False
    try:
        if not _SFS_CORE_REGISTERED and callable(_SFS_CORE_REGISTER):
            core_result = _SFS_CORE_REGISTER()
            if core_result is False:
                core_globals = getattr(_SFS_CORE_REGISTER, '__globals__', {})
                core_errors = core_globals.get('_SF_LAST_REGISTRATION_ERRORS') if isinstance(core_globals, dict) else None
                details = [str(item) for item in tuple(core_errors or ()) if str(item).strip()]
                suffix = f": {'; '.join(details[-6:])}" if details else ""
                raise RuntimeError(f"Smart File core registration returned False{suffix}")
            # The core transaction now owns resources even if a later root-panel
            # verification fails. Mark that ownership immediately so this scope
            # can reverse it instead of leaving addon_utils with a partial load.
            core_loaded_now = True
            if not _sfs_core_panel_registered():
                try:
                    _sfs_repair_core_npanel_if_needed()
                except Exception:
                    pass
            if not _sfs_core_panel_registered():
                panel_cls = globals().get("SF_PT_reference_manager_reference_manager_workspace")
                if isinstance(panel_cls, type):
                    try:
                        _sfs_safe_register_class(panel_cls)
                    except Exception:
                        pass
                try:
                    _sfs_repair_core_npanel_if_needed()
                except Exception:
                    pass
            if not _sfs_core_panel_registered():
                raise RuntimeError("Smart File registered without a complete VIEW_3D/UI N-panel and WindowManager settings.")
            _SFS_CORE_REGISTERED = True
    except Exception:
        try:
            if core_loaded_now and callable(_SFS_CORE_UNREGISTER):
                _sfs_unregister_fallback_panel()
                _sfs_unregister_anchor_panel()
                _SFS_CORE_UNREGISTER()
        except Exception:
            pass
        _SFS_CORE_REGISTERED = False
        raise

    if not _SFS_TOOL_RUNTIME_REGISTERED:
        runtime = None
        try:
            runtime = _sf_import_package_module("runtime")
            register_fn = getattr(runtime, "register", None)
            if not callable(register_fn) or register_fn() is not True:
                raise RuntimeError("Integrated Smart File runtime exact registration failed")
            _SFS_TOOL_RUNTIME_REGISTERED = True
        except Exception as exc:
            try:
                unregister_fn = getattr(runtime, "unregister", None) if runtime is not None else None
                if callable(unregister_fn):
                    unregister_fn()
            except Exception:
                pass
            _SFS_TOOL_RUNTIME_REGISTERED = False
            if core_loaded_now:
                try:
                    _sfs_unregister_fallback_panel()
                    _sfs_unregister_anchor_panel()
                    if callable(_SFS_CORE_UNREGISTER):
                        _SFS_CORE_UNREGISTER()
                except Exception:
                    pass
                _SFS_CORE_REGISTERED = False
            raise RuntimeError(
                f"Integrated Smart File runtime registration failed: {type(exc).__name__}: {exc}"
            ) from exc

    # Native physical roots are owned once by the outer package transaction.
    # Keeping them out of this core/runtime loader avoids a register/unregister
    # clone cycle during every cold enable and reload repair.
    return bool(_SFS_CORE_REGISTERED)


def _sf_unload_full_runtime() -> None:
    global _SFS_CORE_REGISTERED, _SFS_TOOL_RUNTIME_REGISTERED
    # Blender requires child Panel RNA to be removed before its parent root.
    try:
        _sfs_unregister_fallback_panel()
    except Exception:
        pass
    try:
        _sfs_unregister_anchor_panel()
    except Exception:
        pass
    # Packaged feature files execute into this package namespace. Root Watch's
    # bounded status cache must therefore be released by this actual owner.
    try:
        invalidate_status_cache = globals().get("_sf_watch_invalidate_status_cache")
        if callable(invalidate_status_cache):
            invalidate_status_cache()
    except Exception:
        pass
    if _SFS_TOOL_RUNTIME_REGISTERED:
        try:
            runtime = sys.modules.get(f"{_sf_package_name()}.runtime") or _sf_import_package_module("runtime")
            unregister_fn = getattr(runtime, "unregister", None)
            if callable(unregister_fn):
                unregister_fn()
        except Exception as exc:
            globals()["_SFS_FALLBACK_ERROR"] = (
                f"Integrated runtime unregister failed: {type(exc).__name__}: {exc}"
            )[:1024]
        finally:
            _SFS_TOOL_RUNTIME_REGISTERED = False

    if _SFS_CORE_REGISTERED:
        try:
            if callable(_SFS_CORE_UNREGISTER):
                _SFS_CORE_UNREGISTER()
        except Exception as exc:
            globals()["_SFS_FALLBACK_ERROR"] = (
                f"Core runtime unregister failed: {type(exc).__name__}: {exc}"
            )[:1024]
        finally:
            _SFS_CORE_REGISTERED = False

    # If core registration never acquired the preregistered root, release that
    # exact current-generation class after all child Panels are gone.
    try:
        root_cls = globals().get("SF_PT_reference_manager_reference_manager_workspace")
        if isinstance(root_cls, type):
            _sfs_safe_unregister_class(root_cls)
    except Exception:
        pass

    _sf_tag_redraw_view3d()


def ensure_runtime_initialized(context=None, *args, force: bool = False, **kwargs):
    del context, args, kwargs, force
    try:
        return bool(_sf_ensure_full_runtime_loaded())
    except Exception:
        return False


def register():
    if not _sfs_can_register():
        return
    _sfs_i18n_install()
    _sfs_tool_guard_register()
    # Start from an unhooked zero-idle state; core registration restores the
    # saved toggle and explicitly enables the guard only when requested.
    _sfs_compatibility_guards_unregister()
    try:
        _sfs_register_anchor_panel()
        _sfs_unregister_fallback_panel()
        if not _sf_ensure_full_runtime_loaded() or not _sfs_repair_core_npanel_if_needed():
            raise RuntimeError("Smart File N-panel registration did not complete.")
        _sfs_hide_fallback_panel()
        _sfs_enforce_single_npanel(getattr(bpy, 'context', None))
    except Exception:
        err = traceback.format_exc()
        _sf_unload_full_runtime()
        _sfs_register_fallback_panel(err)


def unregister():
    _sfs_multi_editor_panels_unregister()
    current_owner = _sfs_current_owner_name()
    if _sfs_get_owner() not in (None, current_owner):
        return
    try:
        _sf_unload_full_runtime()
    finally:
        _sfs_unregister_fallback_panel()
        _sfs_unregister_anchor_panel()
        _sfs_compatibility_guards_unregister()
        _sfs_tool_guard_unregister()
        _sfs_i18n_uninstall()
        _sfs_restore_single_npanel_guard()
        _sfs_clear_owner(current_owner)


if __name__ == "__main__":
    register()

# --- Smart common extension patch START ---
# Load the common operators lazily. The anchor owns Help so it is available
# even when the rest of the common runtime cannot register.
_SMART_COMMON = None


def _sfs_get_common_runtime():
    global _SMART_COMMON
    if _SMART_COMMON is None:
        _SMART_COMMON = _sf_import_package_module("common")
    return _SMART_COMMON

_SMART_ORIGINAL_REGISTER = globals().get('register')
_SMART_ORIGINAL_UNREGISTER = globals().get('unregister')
_SFS_HISTORY_AUTOSAVE_RUNTIME_REGISTERED = False
_SFS_STARTUP_RESTORE_LEDGER_KEY = "JELararagi.smart_file.startup_restore.v57540"
_SFS_STARTUP_RESTORE_LEGACY_KEYS = (
    "JELararagi.smart_file.startup_restore.v57539",
    "JELararagi.smart_file.startup_restore.v57536",
    "JELararagi.smart_file.startup_restore.v57532",
    "JELararagi.smart_file.startup_restore.v57531",
)
_SFS_STARTUP_RESTORE_GENERATION = 0
_SFS_STARTUP_RESTORE_SYNCED_GENERATION = -1
_SFS_STARTUP_RESTORE_TOKEN = None
_SFS_STARTUP_RESTORE_TIMER_CALLBACK = None
_SFS_STARTUP_RESTORE_LAST_OK = False
_SFS_HISTORY_UHM_MIGRATION_REQUIRED = False
_SFS_HISTORY_PREFS_CHANGED_LAST = False
_SFS_HISTORY_PREFS_DEFERRED = False
_SFS_STARTUP_RESTORE_ATTEMPT = 0
# Finite context-availability retries.  Each callback is a fresh non-persistent
# one-shot owned by the exact generation ledger; no callback returns an interval.
_SFS_STARTUP_RESTORE_DELAYS = (0.1, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0)
_SFS_HISTORY_PREF_KEYS = (
    "enable_history_listener",
    "enable_restore_snapshots",
    "history_restore_point_manual_primary_migrated",
    "restore_snapshot_interval_minutes",
    "restore_snapshot_max_files",
    "enable_autosave",
    "autosave_interval_minutes",
    "autosave_max_files",
    "autosave_retention_scope",
    "autosave_skip_unchanged",
    "history_directory",
    "compress_snapshots",
    "double_click_restore",
    "create_safety_snapshot_before_restore",
    "timer_interval_seconds",
)


def _sfs_apply_history_pref_values(owner, values) -> bool:
    if owner is None or not isinstance(values, dict):
        return False
    ok = True
    for name in _SFS_HISTORY_PREF_KEYS:
        if name not in values or not hasattr(owner, name):
            continue
        try:
            setattr(owner, name, values.get(name))
        except Exception:
            ok = False
    return ok

def _sfs_extract_history_pref_values(values) -> dict:
    """Read legacy flat values and current owner-state ``scalars``."""
    if not isinstance(values, dict):
        return {}
    result = {}
    scalars = values.get("scalars")
    if isinstance(scalars, dict):
        for name in _SFS_HISTORY_PREF_KEYS:
            if name in scalars:
                result[name] = scalars.get(name)
    for name in _SFS_HISTORY_PREF_KEYS:
        if name in values:
            result[name] = values.get(name)
    return result


def _sfs_extract_history_owner_values(owner) -> dict:
    result = {}
    if owner is None:
        return result
    for name in _SFS_HISTORY_PREF_KEYS:
        try:
            if hasattr(owner, name):
                result[name] = getattr(owner, name)
        except Exception:
            continue
    return result

def _sfs_apply_saved_history_autosave_preferences(context=None) -> bool:
    """Restore canonical History values into ``sf_addon_settings`` only.

    A restricted startup context may not yet expose a WindowManager instance.
    That is not a registration failure when the exact RNA descriptor already
    exists.  In that case restoration is marked deferred and a finite exact
    one-shot is armed; the runtime is synchronized once after an instance exists.
    """
    global _SFS_HISTORY_UHM_MIGRATION_REQUIRED, _SFS_HISTORY_PREFS_CHANGED_LAST
    global _SFS_HISTORY_PREFS_DEFERRED
    _SFS_HISTORY_PREFS_CHANGED_LAST = False
    _SFS_HISTORY_PREFS_DEFERRED = False
    try:
        ctx = context or getattr(bpy, "context", None)
        wm = getattr(ctx, "window_manager", None)
        sf_target = getattr(wm, "sf_addon_settings", None) if wm is not None else None
        if sf_target is None:
            wm_type = getattr(getattr(bpy, "types", None), "WindowManager", None)
            try:
                descriptor = vars(wm_type).get("sf_addon_settings") if wm_type is not None else None
            except Exception:
                descriptor = None
            if descriptor is None:
                return False
            _SFS_HISTORY_PREFS_DEFERRED = True
            return True
        settings = _sf_import_package_module("settings")
        load_data = getattr(settings, "load_data", None)
        if not callable(load_data):
            return False
        data = load_data()
        if not isinstance(data, dict):
            data = {}
        pointer_values = data.get("window_manager_pointers")
        canonical = _sfs_extract_history_pref_values(data.get("preferences"))
        if not canonical and isinstance(pointer_values, dict):
            canonical = _sfs_extract_history_pref_values(
                pointer_values.get("sf_addon_settings")
            )

        migration_done_fn = getattr(settings, "history_uhm_migration_done", None)
        migration_done = bool(callable(migration_done_fn) and migration_done_fn(data))
        legacy = {}
        if not migration_done and isinstance(pointer_values, dict):
            if "uhm_addon_settings" in pointer_values:
                legacy.update(
                    _sfs_extract_history_pref_values(
                        pointer_values.get("uhm_addon_settings")
                    )
                )
            for name, value in legacy.items():
                canonical.setdefault(name, value)
        _SFS_HISTORY_UHM_MIGRATION_REQUIRED = bool(not migration_done and legacy)

        before = _sfs_extract_history_owner_values(sf_target)
        applied = _sfs_apply_history_pref_values(sf_target, canonical)
        after = _sfs_extract_history_owner_values(sf_target)
        _SFS_HISTORY_PREFS_CHANGED_LAST = bool(before != after)
        return bool(applied or not canonical)
    except Exception:
        _SFS_HISTORY_PREFS_CHANGED_LAST = False
        _SFS_HISTORY_PREFS_DEFERRED = False
        return False


def _sfs_ensure_history_autosave_runtime(context=None) -> bool:
    """Accept only a fully exact ACTIVE runtime or an exact zero-resource OFF state."""
    global _SFS_HISTORY_AUTOSAVE_RUNTIME_REGISTERED, _SFS_FALLBACK_ERROR
    try:
        ctx = context or getattr(bpy, "context", None)
        status_fn = globals().get("_sf_history_status")
        if not callable(status_fn):
            raise RuntimeError("History lifecycle owner status API is unavailable")
        owner_status = status_fn(ctx)
        runtime = _sf_import_package_module("history_auto_save.core.runtime")
        status = runtime.get_runtime_status(ctx)
        exact = bool(owner_status.get("registered") and status.get("registered"))
        if not exact:
            raise RuntimeError(
                owner_status.get("last_runtime_error")
                or owner_status.get("last_save_error")
                or status.get("last_runtime_error")
                or status.get("last_save_error")
                or "History lifecycle/runtime exact validation failed"
            )
        if status.get("requested_enabled"):
            valid = bool(
                status.get("phase") == "ACTIVE"
                and status.get("watching")
                and status.get("handlers_ok")
                and status.get("timer_ok")
                and int(status.get("handler_count", 0) or 0)
                    == int(status.get("required_handler_count", 0) or 0)
                and status.get("timer_registered")
            )
        else:
            valid = bool(
                status.get("phase") == "DISABLED"
                and not status.get("watching")
                and not status.get("timer_registered")
                and int(status.get("handler_count", 0) or 0) == 0
            )
        if not valid:
            raise RuntimeError(
                status.get("last_runtime_error")
                or status.get("last_save_error")
                or "History runtime is not in an exact operational state"
            )
        _SFS_HISTORY_AUTOSAVE_RUNTIME_REGISTERED = True
        _SFS_FALLBACK_ERROR = ""
        return True
    except Exception:
        _SFS_HISTORY_AUTOSAVE_RUNTIME_REGISTERED = False
        _SFS_FALLBACK_ERROR = traceback.format_exc()
        return False

def _sfs_unregister_history_autosave_runtime() -> None:
    """Clear bootstrap bookkeeping; core history_integration owns teardown."""
    global _SFS_HISTORY_AUTOSAVE_RUNTIME_REGISTERED
    _SFS_HISTORY_AUTOSAVE_RUNTIME_REGISTERED = False

def _sfs_startup_restore_cleanup(token=None, generation=None) -> bool:
    """Remove only the exact startup callback owned by the supplied ledger."""
    global _SFS_STARTUP_RESTORE_TIMER_CALLBACK
    namespace = _sfs_registration_namespace() if "_sfs_registration_namespace" in globals() else None
    ledger = namespace.get(_SFS_STARTUP_RESTORE_LEDGER_KEY) if namespace is not None else None
    expected_token = _SFS_STARTUP_RESTORE_TOKEN if token is None else token
    expected_generation = (
        _SFS_STARTUP_RESTORE_GENERATION if generation is None else int(generation)
    )
    if isinstance(ledger, dict):
        if ledger.get("token") is not expected_token:
            return False
        if int(ledger.get("generation", -1)) != int(expected_generation):
            return False
        callback = ledger.get("callback")
    else:
        callback = (
            _SFS_STARTUP_RESTORE_TIMER_CALLBACK
            if expected_token is _SFS_STARTUP_RESTORE_TOKEN
            and int(expected_generation) == int(_SFS_STARTUP_RESTORE_GENERATION)
            else None
        )
    ok = True
    if callback is not None:
        try:
            timers = getattr(getattr(bpy, "app", None), "timers", None)
            checker = getattr(timers, "is_registered", None) if timers is not None else None
            if timers is not None and (not callable(checker) or checker(callback)):
                timers.unregister(callback)
        except Exception:
            try:
                if callable(checker) and checker(callback):
                    ok = False
            except Exception:
                ok = False
    if namespace is not None and isinstance(ledger, dict):
        latest = namespace.get(_SFS_STARTUP_RESTORE_LEDGER_KEY)
        if latest is ledger:
            namespace.pop(_SFS_STARTUP_RESTORE_LEDGER_KEY, None)
    if callback is _SFS_STARTUP_RESTORE_TIMER_CALLBACK:
        _SFS_STARTUP_RESTORE_TIMER_CALLBACK = None
    return bool(ok)


def _sfs_cleanup_external_startup_restore(owner) -> bool:
    """Invoke an older generation's exact cleanup receipt, never a global scan."""
    if not isinstance(owner, dict):
        return False
    cleanup = owner.get("cleanup")
    if callable(cleanup):
        try:
            try:
                return bool(cleanup(owner.get("token"), owner.get("generation")))
            except TypeError:
                return bool(cleanup())
        except Exception:
            return False
    # Compatibility for pre-receipt 5.75.x ledgers: their callback identity is
    # still explicit in the ledger, so removing that one object is exact.
    callback = owner.get("callback")
    if callback is None:
        return True
    try:
        timers = getattr(getattr(bpy, "app", None), "timers", None)
        checker = getattr(timers, "is_registered", None) if timers is not None else None
        if timers is not None and (not callable(checker) or checker(callback)):
            timers.unregister(callback)
        return not callable(checker) or not checker(callback)
    except Exception:
        return False


def _sfs_prepare_startup_restore_owner() -> bool:
    namespace = _sfs_registration_namespace() if "_sfs_registration_namespace" in globals() else None
    if namespace is None:
        return True
    for key in _SFS_STARTUP_RESTORE_LEGACY_KEYS:
        prior = namespace.get(key)
        if prior is None:
            continue
        if not _sfs_cleanup_external_startup_restore(prior):
            return False
        namespace.pop(key, None)
    prior = namespace.get(_SFS_STARTUP_RESTORE_LEDGER_KEY)
    if isinstance(prior, dict) and not (
        prior.get("token") is _SFS_STARTUP_RESTORE_TOKEN
        and int(prior.get("generation", -1))
        == int(_SFS_STARTUP_RESTORE_GENERATION)
    ):
        if not _sfs_cleanup_external_startup_restore(prior):
            return False
        namespace.pop(_SFS_STARTUP_RESTORE_LEDGER_KEY, None)
    return True


def _sfs_finalize_post_register_restore(generation=None, token=None, *, allow_without_ledger=False) -> bool:
    """Restore settings and synchronize History once an RNA instance exists."""
    global _SFS_STARTUP_RESTORE_SYNCED_GENERATION
    global _SFS_STARTUP_RESTORE_TIMER_CALLBACK, _SFS_FALLBACK_ERROR
    global _SFS_STARTUP_RESTORE_LAST_OK, _SFS_HISTORY_UHM_MIGRATION_REQUIRED
    global _SFS_HISTORY_AUTOSAVE_RUNTIME_REGISTERED

    current_generation = _SFS_STARTUP_RESTORE_GENERATION
    generation = current_generation if generation is None else int(generation)
    token = _SFS_STARTUP_RESTORE_TOKEN if token is None else token
    namespace = getattr(getattr(bpy, "app", None), "driver_namespace", None)
    ledger = namespace.get(_SFS_STARTUP_RESTORE_LEDGER_KEY) if isinstance(namespace, dict) else None
    identity_matches = bool(
        generation == current_generation
        and token is not None
        and token is _SFS_STARTUP_RESTORE_TOKEN
    )
    ledger_matches = bool(
        isinstance(ledger, dict)
        and ledger.get("generation") == generation
        and ledger.get("token") is token
    )
    if not identity_matches:
        return False

    # A synchronous restore may complete before its earlier finite one-shot is
    # dispatched.  That obsolete callback must never replay saved values over
    # newer same-scene edits.  Deferred context restores do not set the synced
    # generation and therefore remain eligible; later file loads use the
    # settings owner's load_post path and are unaffected by this startup gate.
    if _SFS_STARTUP_RESTORE_SYNCED_GENERATION == generation:
        if isinstance(namespace, dict):
            latest = namespace.get(_SFS_STARTUP_RESTORE_LEDGER_KEY)
            if isinstance(latest, dict) and latest.get("token") is token:
                namespace.pop(_SFS_STARTUP_RESTORE_LEDGER_KEY, None)
        _SFS_STARTUP_RESTORE_TIMER_CALLBACK = None
        _SFS_STARTUP_RESTORE_LAST_OK = True
        return True

    _SFS_STARTUP_RESTORE_LAST_OK = False
    context = getattr(bpy, "context", None)
    settings = None
    errors = []
    if not (ledger_matches or allow_without_ledger):
        errors.append("startup restore ledger ownership was not retained")
    try:
        settings = _sf_import_package_module("settings")
        if not _sfs_apply_saved_history_autosave_preferences(context):
            raise RuntimeError("History settings final restore failed")
    except Exception as exc:
        errors.append(f"startup restore: {type(exc).__name__}: {exc}")
    finally:
        if settings is None:
            try:
                settings = _sf_import_package_module("settings")
            except Exception as exc:
                errors.append(f"settings import: {type(exc).__name__}: {exc}")
                settings = None
        if settings is not None:
            try:
                settings._STARTUP_RESTORE_PENDING = False
            except Exception as exc:
                errors.append(f"pending guard release: {type(exc).__name__}: {exc}")

        if (
            settings is not None
            and _SFS_HISTORY_UHM_MIGRATION_REQUIRED
            and not _SFS_HISTORY_PREFS_DEFERRED
            and bool(getattr(settings, '_keeper_enabled', lambda _ctx=None: False)(context))
        ):
            try:
                saver = getattr(settings, "save_now", None)
                if not callable(saver) or saver(
                    context, force=True, allow_disabled=True
                ) is not True:
                    raise RuntimeError("canonical settings write was not verified")
                marker = getattr(settings, "mark_history_uhm_migration_done", None)
                if not callable(marker) or marker() is not True:
                    raise RuntimeError("legacy History migration marker write failed")
                _SFS_HISTORY_UHM_MIGRATION_REQUIRED = False
            except Exception as exc:
                errors.append(f"settings commit: {type(exc).__name__}: {exc}")

        if _SFS_HISTORY_PREFS_DEFERRED:
            # A missing WindowManager instance is a transient restricted-context
            # condition, not a failed add-on registration.  Do not falsely mark
            # the persisted settings as synchronized; a finite one-shot will retry.
            try:
                owner_status_fn = globals().get("_sf_history_status")
                owner_status = owner_status_fn(context) if callable(owner_status_fn) else {}
                runtime = _sf_import_package_module("history_auto_save.core.runtime")
                runtime_status = runtime.get_runtime_status(context)
                _SFS_HISTORY_AUTOSAVE_RUNTIME_REGISTERED = bool(
                    owner_status.get("registered") and runtime_status.get("registered")
                )
            except Exception:
                _SFS_HISTORY_AUTOSAVE_RUNTIME_REGISTERED = False
            _sfs_warn_registration_once(
                "REGISTER_CONTEXT_DEFERRED",
                "WindowManager settings instance is not available yet; "
                "History restore remains generation-owned and will retry finitely.",
            )
        elif _SFS_STARTUP_RESTORE_SYNCED_GENERATION != generation:
            try:
                exact_before = _sfs_ensure_history_autosave_runtime(context)
                if _SFS_HISTORY_PREFS_CHANGED_LAST or not exact_before:
                    repair = globals().get("_sf_history_request_repair")
                    if not callable(repair) or repair("startup_restore_complete") is not True:
                        raise RuntimeError("History lifecycle final synchronization failed")
                if not _sfs_ensure_history_autosave_runtime(context):
                    raise RuntimeError(
                        _SFS_FALLBACK_ERROR
                        or "History runtime final validation is not exact and operational"
                    )
                owner_status_fn = globals().get("_sf_history_status")
                owner_status = owner_status_fn(context) if callable(owner_status_fn) else {}
                if owner_status.get("repair_timer_registered"):
                    raise RuntimeError("History repair timer remained after exact final sync")
                _SFS_HISTORY_AUTOSAVE_RUNTIME_REGISTERED = True
                _SFS_STARTUP_RESTORE_SYNCED_GENERATION = generation
                core_errors = globals().get("_SF_LAST_REGISTRATION_ERRORS")
                if isinstance(core_errors, list):
                    core_errors.clear()
                _SFS_FALLBACK_ERROR = ""
            except Exception as exc:
                _SFS_HISTORY_AUTOSAVE_RUNTIME_REGISTERED = False
                errors.append(f"runtime sync: {type(exc).__name__}: {exc}")

        if isinstance(namespace, dict):
            latest = namespace.get(_SFS_STARTUP_RESTORE_LEDGER_KEY)
            if isinstance(latest, dict) and latest.get("token") is token:
                namespace.pop(_SFS_STARTUP_RESTORE_LEDGER_KEY, None)
        _SFS_STARTUP_RESTORE_TIMER_CALLBACK = None

    if errors:
        _SFS_FALLBACK_ERROR = "\n".join(errors)
        _SFS_STARTUP_RESTORE_LAST_OK = False
    else:
        _SFS_STARTUP_RESTORE_LAST_OK = True
    return bool(_SFS_STARTUP_RESTORE_LAST_OK)



def _sfs_post_register_restore_timer(generation=None, token=None, *, allow_without_ledger=False):
    """Run one exact restore attempt and terminate this callback."""
    ok = _sfs_finalize_post_register_restore(
        generation, token, allow_without_ledger=allow_without_ledger
    )
    if (
        (not ok or _SFS_HISTORY_PREFS_DEFERRED)
        and token is _SFS_STARTUP_RESTORE_TOKEN
        and int(generation if generation is not None else -1)
        == int(_SFS_STARTUP_RESTORE_GENERATION)
    ):
        if not _sfs_schedule_post_register_restore(synchronous=False):
            _sfs_handle_registration_failure(
                RuntimeError("startup settings restore retry could not be re-armed")
            )
    return None


def _sfs_schedule_post_register_restore(*, synchronous=False) -> bool:
    """Run immediately or arm one finite generation-owned context retry."""
    global _SFS_STARTUP_RESTORE_TIMER_CALLBACK, _SFS_STARTUP_RESTORE_ATTEMPT
    generation = _SFS_STARTUP_RESTORE_GENERATION
    token = _SFS_STARTUP_RESTORE_TOKEN
    if token is None:
        return False
    if synchronous:
        return _sfs_finalize_post_register_restore(
            generation, token, allow_without_ledger=True
        )
    if not _sfs_prepare_startup_restore_owner():
        _sfs_warn_registration_once(
            "STARTUP_RESTORE_OWNER",
            "A prior startup-restore callback could not be released by exact identity.",
        )
        return False
    if _SFS_STARTUP_RESTORE_ATTEMPT >= len(_SFS_STARTUP_RESTORE_DELAYS):
        _sfs_warn_registration_once(
            "STARTUP_CONTEXT_UNAVAILABLE",
            "Finite startup context retries were exhausted; no periodic timer remains.",
        )
        return False

    namespace = _sfs_registration_namespace()
    timers = getattr(getattr(bpy, "app", None), "timers", None)
    register_timer = getattr(timers, "register", None) if timers is not None else None
    if namespace is None or not callable(register_timer):
        _sfs_warn_registration_once(
            "STARTUP_RESTORE_TIMER_UNAVAILABLE",
            "No exact timer ledger is available; startup restore retry cannot be armed.",
        )
        return False

    _sfs_startup_restore_cleanup()
    attempt = _SFS_STARTUP_RESTORE_ATTEMPT + 1
    delay = float(_SFS_STARTUP_RESTORE_DELAYS[attempt - 1])

    def _startup_restore_callback():
        return _sfs_post_register_restore_timer(generation, token)

    _startup_restore_callback.__name__ = f"_sfs_startup_restore_{generation}_{attempt}"
    _startup_restore_callback._sfs_generation = generation
    ledger = {
        "schema": 2,
        "generation": generation,
        "token": token,
        "attempt": attempt,
        "callback": _startup_restore_callback,
        "one_shot": True,
        "cleanup": _sfs_startup_restore_cleanup,
    }
    namespace[_SFS_STARTUP_RESTORE_LEDGER_KEY] = ledger
    try:
        register_timer(
            _startup_restore_callback,
            first_interval=delay,
            persistent=False,
        )
        checker = getattr(timers, "is_registered", None)
        if callable(checker) and not checker(_startup_restore_callback):
            raise RuntimeError("startup restore timer exact identity was not retained")
        _SFS_STARTUP_RESTORE_TIMER_CALLBACK = _startup_restore_callback
        _SFS_STARTUP_RESTORE_ATTEMPT = attempt
        return True
    except Exception as exc:
        namespace.pop(_SFS_STARTUP_RESTORE_LEDGER_KEY, None)
        _SFS_STARTUP_RESTORE_TIMER_CALLBACK = None
        _sfs_warn_registration_once(
            "STARTUP_RESTORE_TIMER_FAILED",
            f"{type(exc).__name__}: {exc}",
        )
        return False



def _sfs_cancel_startup_restore() -> None:
    """Release the exact current/legacy callback and always clear save guard."""
    global _SFS_STARTUP_RESTORE_TIMER_CALLBACK, _SFS_STARTUP_RESTORE_ATTEMPT
    namespace = _sfs_registration_namespace()
    if namespace is not None:
        for legacy_key in _SFS_STARTUP_RESTORE_LEGACY_KEYS:
            legacy = namespace.get(legacy_key)
            if legacy is not None:
                _sfs_cleanup_external_startup_restore(legacy)
            namespace.pop(legacy_key, None)
    _sfs_startup_restore_cleanup()
    _SFS_STARTUP_RESTORE_TIMER_CALLBACK = None
    _SFS_STARTUP_RESTORE_ATTEMPT = 0
    try:
        _sf_import_package_module("settings")._STARTUP_RESTORE_PENDING = False
    except Exception:
        pass


_SFS_REGISTER_REPAIR_LEDGER_KEY = "JELararagi.smart_file.registration_repair.v57540"
_SFS_REGISTER_REPAIR_LEGACY_KEYS = (
    "JELararagi.smart_file.registration_repair.v57539",
    "JELararagi.smart_file.registration_repair.v57538",
    "JELararagi.smart_file.registration_repair.v57537",
    "JELararagi.smart_file.registration_repair.v57536",
)
_SFS_REGISTER_REPAIR_GENERATION = 0
_SFS_REGISTER_REPAIR_TOKEN = None
_SFS_REGISTER_REPAIR_CALLBACK = None
_SFS_REGISTER_REPAIR_ATTEMPT = 0
_SFS_REGISTER_REPAIR_DELAYS = (0.5, 1.0, 2.0, 4.0, 8.0, 16.0)
_SFS_REGISTER_REPAIR_LAST_ERROR = ""
_SFS_REGISTER_IN_PROGRESS = False
_SFS_REGISTER_WARNING_KEYS = set()


def _sfs_registration_namespace():
    try:
        value = getattr(getattr(bpy, "app", None), "driver_namespace", None)
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _sfs_warn_registration_once(tag: str, message: str) -> None:
    """Emit one bounded tagged warning for a degraded registration signature."""
    key = (str(tag or "REGISTER"), str(message or "")[:512])
    if key in _SFS_REGISTER_WARNING_KEYS:
        return
    if len(_SFS_REGISTER_WARNING_KEYS) >= 32:
        _SFS_REGISTER_WARNING_KEYS.clear()
    _SFS_REGISTER_WARNING_KEYS.add(key)
    try:
        print(f"[Smart File Suite][{key[0]}] WARNING: {key[1]}")
    except Exception:
        pass


def _sfs_registration_repair_cleanup(token=None, generation=None) -> bool:
    """Remove only the exact one-shot repair callback owned by this module."""
    global _SFS_REGISTER_REPAIR_CALLBACK
    if token is not None and token is not _SFS_REGISTER_REPAIR_TOKEN:
        return False
    if generation is not None and int(generation) != int(_SFS_REGISTER_REPAIR_GENERATION):
        return False
    callback = _SFS_REGISTER_REPAIR_CALLBACK
    ok = True
    if callback is not None:
        try:
            timers = getattr(getattr(bpy, "app", None), "timers", None)
            checker = getattr(timers, "is_registered", None) if timers is not None else None
            if timers is not None and (not callable(checker) or checker(callback)):
                timers.unregister(callback)
        except Exception:
            try:
                if callable(checker) and checker(callback):
                    ok = False
            except Exception:
                ok = False
    _SFS_REGISTER_REPAIR_CALLBACK = None
    namespace = _sfs_registration_namespace()
    if namespace is not None:
        owner = namespace.get(_SFS_REGISTER_REPAIR_LEDGER_KEY)
        if (
            isinstance(owner, dict)
            and owner.get("token") is _SFS_REGISTER_REPAIR_TOKEN
            and int(owner.get("generation", -1)) == int(_SFS_REGISTER_REPAIR_GENERATION)
        ):
            namespace.pop(_SFS_REGISTER_REPAIR_LEDGER_KEY, None)
    return ok


def _sfs_cleanup_external_registration_repair(owner) -> bool:
    cleanup = owner.get("cleanup") if isinstance(owner, dict) else None
    if not callable(cleanup):
        return False
    try:
        try:
            return bool(cleanup(owner.get("token"), owner.get("generation")))
        except TypeError:
            return bool(cleanup())
    except Exception:
        return False


def _sfs_prepare_registration_repair_owner() -> bool:
    namespace = _sfs_registration_namespace()
    if namespace is None:
        return False
    for key in _SFS_REGISTER_REPAIR_LEGACY_KEYS:
        prior = namespace.get(key)
        if prior is not None:
            if not _sfs_cleanup_external_registration_repair(prior):
                return False
            namespace.pop(key, None)
    prior = namespace.get(_SFS_REGISTER_REPAIR_LEDGER_KEY)
    if isinstance(prior, dict) and not (
        prior.get("token") is _SFS_REGISTER_REPAIR_TOKEN
        and int(prior.get("generation", -1)) == int(_SFS_REGISTER_REPAIR_GENERATION)
    ):
        if not _sfs_cleanup_external_registration_repair(prior):
            return False
        namespace.pop(_SFS_REGISTER_REPAIR_LEDGER_KEY, None)
    return True


def _sfs_cancel_registration_repair(*, reset_attempts: bool = False) -> bool:
    global _SFS_REGISTER_REPAIR_ATTEMPT, _SFS_REGISTER_REPAIR_LAST_ERROR
    ok = _sfs_registration_repair_cleanup()
    if reset_attempts:
        _SFS_REGISTER_REPAIR_ATTEMPT = 0
        _SFS_REGISTER_REPAIR_LAST_ERROR = ""
    return ok


def _sfs_reverse_root_generation() -> None:
    """Best-effort exact reverse teardown for the current Smart File owner."""
    _sfs_cancel_startup_restore()
    try:
        _sfs_multi_editor_panels_unregister()
    except Exception:
        pass
    try:
        if _SMART_COMMON is not None:
            _SMART_COMMON.unregister()
    except Exception:
        pass
    try:
        _sf_unload_full_runtime()
    except Exception:
        pass
    # Preview collections remain valid until every Smart File panel/operator
    # that can reference their icon ids has been unregistered.  Release them
    # only after the full runtime teardown, and only through the exact owner
    # ledger recorded by preview_cleanup.
    try:
        _preview_name = f"{_sf_package_name()}.preview_cleanup"
        _preview_runtime = sys.modules.get(_preview_name)
        _preview_unregister = getattr(_preview_runtime, 'unregister', None) if _preview_runtime is not None else None
        if callable(_preview_unregister):
            _preview_unregister()
    except Exception:
        pass
    try:
        _sfs_unregister_history_autosave_runtime()
    except Exception:
        pass
    try:
        _sfs_unregister_fallback_panel()
    except Exception:
        pass
    try:
        _sfs_unregister_anchor_panel()
    except Exception:
        pass
    try:
        _sfs_compatibility_guards_unregister()
    except Exception:
        pass
    try:
        _sfs_tool_guard_unregister()
    except Exception:
        pass
    try:
        _sfs_i18n_uninstall()
    except Exception:
        pass
    try:
        _sfs_restore_single_npanel_guard()
    except Exception:
        pass
    _sfs_clear_owner(_sfs_current_owner_name())


def _sfs_registration_transaction() -> bool:
    """Run the mandatory registration graph; internal failures abort locally."""
    global _SFS_REGISTER_IN_PROGRESS, _SFS_REGISTER_REPAIR_LAST_ERROR
    if _SFS_REGISTER_IN_PROGRESS:
        return False
    _SFS_REGISTER_IN_PROGRESS = True
    try:
        if not _sfs_can_register():
            raise RuntimeError("registration owner could not be acquired")
        _sfs_i18n_install()
        _sfs_tool_guard_register()
        # Optional compatibility classes never patch process-global Blender APIs.
        _sfs_compatibility_guards_unregister()
        _sfs_register_anchor_panel()
        _sfs_unregister_fallback_panel()
        if not _sf_ensure_full_runtime_loaded() or not _sfs_repair_core_npanel_if_needed():
            raise RuntimeError("Smart File N-panel registration did not complete")
        common_runtime = _sfs_get_common_runtime()
        if common_runtime is None or common_runtime.register() is not True:
            raise RuntimeError("Smart File common runtime validation failed")
        if not _sfs_multi_editor_panels_register():
            raise RuntimeError("Smart File multi-editor panel validation failed")
        settings = _sf_import_package_module("settings")
        settings._STARTUP_RESTORE_PENDING = True
        if not _sfs_schedule_post_register_restore(synchronous=True):
            raise RuntimeError("startup settings restore/runtime finalization failed")
        if _SFS_HISTORY_PREFS_DEFERRED:
            if not _sfs_schedule_post_register_restore(synchronous=False):
                raise RuntimeError("startup settings restore retry could not be armed")
        _sfs_hide_fallback_panel()
        _sf_tag_redraw_view3d()
        _SFS_REGISTER_REPAIR_LAST_ERROR = ""
        _sfs_cancel_registration_repair(reset_attempts=True)
        return True
    finally:
        _SFS_REGISTER_IN_PROGRESS = False


def _sfs_handle_registration_failure(exc, *, schedule_repair: bool = True) -> bool:
    global _SFS_REGISTER_REPAIR_LAST_ERROR, _SFS_FALLBACK_ERROR
    error = f"{type(exc).__name__}: {exc}" if exc is not None else "registration validation failed"
    _SFS_REGISTER_REPAIR_LAST_ERROR = error[:2048]
    _SFS_FALLBACK_ERROR = _SFS_REGISTER_REPAIR_LAST_ERROR
    _sfs_reverse_root_generation()
    # The degraded UI is package-owned and does not claim ACTIVE runtime state.
    try:
        _sfs_set_owner(_sfs_current_owner_name())
        _sfs_register_fallback_panel(_SFS_REGISTER_REPAIR_LAST_ERROR)
    except Exception as fallback_exc:
        _SFS_FALLBACK_ERROR = (
            f"{_SFS_REGISTER_REPAIR_LAST_ERROR}; fallback: "
            f"{type(fallback_exc).__name__}: {fallback_exc}"
        )[:2048]
    _sfs_warn_registration_once("REGISTER_DEGRADED", _SFS_FALLBACK_ERROR)
    if schedule_repair:
        _sfs_schedule_registration_repair(_SFS_FALLBACK_ERROR)
    return False


def _sfs_schedule_registration_repair(reason: str = "") -> bool:
    """Schedule a bounded generation-owned repair; never an idle poll."""
    global _SFS_REGISTER_REPAIR_CALLBACK, _SFS_REGISTER_REPAIR_ATTEMPT
    global _SFS_REGISTER_REPAIR_LAST_ERROR
    if _SFS_REGISTER_REPAIR_ATTEMPT >= len(_SFS_REGISTER_REPAIR_DELAYS):
        return False
    if not _sfs_prepare_registration_repair_owner():
        _SFS_REGISTER_REPAIR_LAST_ERROR = (
            str(reason or _SFS_REGISTER_REPAIR_LAST_ERROR)
            + "; repair owner ledger unavailable"
        )[:2048]
        return False
    if _SFS_REGISTER_REPAIR_CALLBACK is not None:
        try:
            checker = getattr(getattr(getattr(bpy, "app", None), "timers", None), "is_registered", None)
            if callable(checker) and checker(_SFS_REGISTER_REPAIR_CALLBACK):
                return True
        except Exception:
            pass
        _SFS_REGISTER_REPAIR_CALLBACK = None
    token = _SFS_REGISTER_REPAIR_TOKEN
    generation = _SFS_REGISTER_REPAIR_GENERATION
    attempt = _SFS_REGISTER_REPAIR_ATTEMPT + 1
    delay = float(_SFS_REGISTER_REPAIR_DELAYS[attempt - 1])

    def _repair_once():
        global _SFS_REGISTER_REPAIR_CALLBACK
        namespace = _sfs_registration_namespace()
        ledger = namespace.get(_SFS_REGISTER_REPAIR_LEDGER_KEY) if namespace is not None else None
        if not (
            token is _SFS_REGISTER_REPAIR_TOKEN
            and int(generation) == int(_SFS_REGISTER_REPAIR_GENERATION)
            and isinstance(ledger, dict)
            and ledger.get("token") is token
            and int(ledger.get("generation", -1)) == int(generation)
            and ledger.get("callback") is _repair_once
        ):
            return None
        _SFS_REGISTER_REPAIR_CALLBACK = None
        if namespace is not None:
            namespace.pop(_SFS_REGISTER_REPAIR_LEDGER_KEY, None)
        try:
            ok = bool(_sfs_registration_transaction())
        except Exception as repair_exc:
            ok = _sfs_handle_registration_failure(repair_exc, schedule_repair=False)
        if ok:
            publisher = globals().get("_sfs_publish_registration_receipt")
            if callable(publisher):
                publisher(active=True, total_seconds=0.0)
        else:
            _sfs_schedule_registration_repair(_SFS_REGISTER_REPAIR_LAST_ERROR)
        return None

    _repair_once.__name__ = f"_sfs_registration_repair_{generation}_{attempt}"
    timers = getattr(getattr(bpy, "app", None), "timers", None)
    register_timer = getattr(timers, "register", None) if timers is not None else None
    if not callable(register_timer):
        _SFS_REGISTER_REPAIR_LAST_ERROR = "timer service unavailable for registration repair"
        return False
    try:
        register_timer(_repair_once, first_interval=delay, persistent=False)
        checker = getattr(timers, "is_registered", None)
        if callable(checker) and not checker(_repair_once):
            raise RuntimeError("registration repair timer exact identity was not retained")
        _SFS_REGISTER_REPAIR_CALLBACK = _repair_once
        _SFS_REGISTER_REPAIR_ATTEMPT = attempt
        namespace = _sfs_registration_namespace()
        if namespace is not None:
            namespace[_SFS_REGISTER_REPAIR_LEDGER_KEY] = {
                "schema": 1,
                "token": token,
                "generation": generation,
                "attempt": attempt,
                "callback": _repair_once,
                "one_shot": True,
                "cleanup": _sfs_registration_repair_cleanup,
            }
        return True
    except Exception as timer_exc:
        _SFS_REGISTER_REPAIR_CALLBACK = None
        _SFS_REGISTER_REPAIR_LAST_ERROR = (
            f"registration repair timer failed: {type(timer_exc).__name__}: {timer_exc}"
        )[:2048]
        _sfs_warn_registration_once("REGISTER_RETRY_UNAVAILABLE", _SFS_REGISTER_REPAIR_LAST_ERROR)
        return False


def register():
    """Blender public register boundary: complete or bounded degraded, never raise."""
    global _SFS_STARTUP_RESTORE_GENERATION, _SFS_STARTUP_RESTORE_TOKEN
    global _SFS_STARTUP_RESTORE_SYNCED_GENERATION
    global _SFS_REGISTER_REPAIR_GENERATION, _SFS_REGISTER_REPAIR_TOKEN
    global _SFS_REGISTER_REPAIR_ATTEMPT
    _sfs_prepare_registration_repair_owner()
    _sfs_prepare_startup_restore_owner()
    _sfs_cancel_registration_repair(reset_attempts=True)
    _sfs_cancel_startup_restore()
    _SFS_REGISTER_REPAIR_GENERATION += 1
    _SFS_REGISTER_REPAIR_TOKEN = object()
    _SFS_REGISTER_REPAIR_ATTEMPT = 0
    _SFS_STARTUP_RESTORE_GENERATION += 1
    _SFS_STARTUP_RESTORE_TOKEN = object()
    _SFS_STARTUP_RESTORE_SYNCED_GENERATION = -1
    globals()["_SFS_STARTUP_RESTORE_ATTEMPT"] = 0
    globals()["_SFS_HISTORY_PREFS_DEFERRED"] = False
    try:
        return bool(_sfs_registration_transaction())
    except Exception as exc:
        return _sfs_handle_registration_failure(exc, schedule_repair=True)


def unregister():
    """Remove only current-generation resources and never raise to Blender."""
    global _SFS_STARTUP_RESTORE_TOKEN, _SFS_REGISTER_REPAIR_TOKEN
    try:
        _sfs_cancel_registration_repair(reset_attempts=True)
        _SFS_REGISTER_REPAIR_TOKEN = None
        _sfs_cancel_startup_restore()
        _SFS_STARTUP_RESTORE_TOKEN = None
        try:
            _sfs_multi_editor_panels_unregister()
        except Exception:
            pass
        if _SMART_COMMON is not None:
            try:
                _SMART_COMMON.unregister()
            except Exception:
                pass
        if callable(_SMART_ORIGINAL_UNREGISTER):
            try:
                _SMART_ORIGINAL_UNREGISTER()
            except Exception:
                pass
        try:
            _sfs_unregister_history_autosave_runtime()
        except Exception:
            pass
        _sfs_restore_single_npanel_guard()
        try:
            module_name = f"{_sf_package_name()}.preview_cleanup"
            preview_cleanup = sys.modules.get(module_name)
            cleanup_fn = getattr(preview_cleanup, "cleanup_preview_collections", None) if preview_cleanup is not None else None
            unregister_fn = getattr(preview_cleanup, "unregister_atexit", None) if preview_cleanup is not None else None
            if callable(cleanup_fn):
                cleanup_fn()
            if callable(unregister_fn):
                unregister_fn()
        except Exception:
            pass
    finally:
        try:
            _sfs_unregister_fallback_panel()
        except Exception:
            pass
        try:
            _sfs_unregister_anchor_panel()
        except Exception:
            pass
        _sfs_clear_owner(_sfs_current_owner_name())
    return True
# --- Smart common extension patch END ---


# --- Smart File explicit registration receipt wrapper ---
_SFS_RECEIPT_ORIGINAL_REGISTER = register
_SFS_RECEIPT_ORIGINAL_UNREGISTER = unregister


def _sfs_publish_registration_receipt(*, active: bool, total_seconds: float = 0.0) -> None:
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if not isinstance(namespace, dict):
            return
        for legacy_key in (
            'JELararagi.smart_file.registration_receipt.v57553',
            'JELararagi.smart_file.registration_receipt.v57552',
            'JELararagi.smart_file.registration_receipt.v57551',
            'JELararagi.smart_file.registration_receipt.v57550',
            'JELararagi.smart_file.registration_receipt.v57549',
            'JELararagi.smart_file.registration_receipt.v57548',
            'JELararagi.smart_file.registration_receipt.v57547',
            'JELararagi.smart_file.registration_receipt.v57546',
            'JELararagi.smart_file.registration_receipt.v57545',
            'JELararagi.smart_file.registration_receipt.v57544',
            'JELararagi.smart_file.registration_receipt.v57543',
            'JELararagi.smart_file.registration_receipt.v57542',
            'JELararagi.smart_file.registration_receipt.v57541',
            'JELararagi.smart_file.registration_receipt.v57540',
            'JELararagi.smart_file.registration_receipt.v57539',
            'JELararagi.smart_file.registration_receipt.v57538',
            'JELararagi.smart_file.registration_receipt.v57537',
            'JELararagi.smart_file.registration_receipt.v57536',
        ):
            namespace.pop(legacy_key, None)
        key = 'JELararagi.smart_file.registration_receipt.v57554'
        if not active:
            namespace.pop(key, None)
            return
        bootstrap_profile = dict(globals().get('_SFS_BOOTSTRAP_PROFILE') or {})
        core_profile = dict(globals().get('_SF_REGISTER_PROFILE') or {})
        runtime_profile = dict(globals().get('_SFS_RUNTIME_PROFILE') or {})
        phases = {}
        for prefix, profile in (
            ('bootstrap', bootstrap_profile),
            ('core', core_profile),
            ('runtime', runtime_profile),
        ):
            for phase_name, value in profile.items():
                if isinstance(value, (int, float)):
                    phases[f'{prefix}.{phase_name}'] = float(value)
        exclusive = sorted(
            ((phase_name, value) for phase_name, value in phases.items() if phase_name.rsplit('.', 1)[-1] != 'total'),
            key=lambda item: item[1], reverse=True,
        )
        namespace[key] = {
            'schema': 2,
            'version': '5.75.97',
            'module': __name__,
            'active': True,
            'degraded': False,
            'total_seconds': float(total_seconds),
            'phases': phases,
            'top_exclusive_costs': tuple(exclusive[:12]),
            'core_registered': bool(globals().get('_SFS_CORE_REGISTERED')),
            'tool_runtime_registered': bool(globals().get('_SFS_TOOL_RUNTIME_REGISTERED')),
            'history_runtime_registered': bool(globals().get('_SFS_HISTORY_AUTOSAVE_RUNTIME_REGISTERED')),
            'registration_repair_timer': False,
        }
    except Exception:
        pass


def register():
    import time as _sfs_time
    started = _sfs_time.perf_counter()
    try:
        result = bool(_SFS_RECEIPT_ORIGINAL_REGISTER())
    except Exception as exc:
        result = _sfs_handle_registration_failure(exc, schedule_repair=True)
    _sfs_publish_registration_receipt(
        active=result,
        total_seconds=_sfs_time.perf_counter() - started,
    )
    return result


def unregister():
    try:
        try:
            return bool(_SFS_RECEIPT_ORIGINAL_UNREGISTER())
        except Exception:
            return False
    finally:
        _sfs_publish_registration_receipt(active=False)
# --- Smart File explicit registration receipt wrapper ---


from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)


