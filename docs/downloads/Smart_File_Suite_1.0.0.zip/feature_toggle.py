# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
import os
import re
import uuid
from contextlib import AbstractContextManager
from pathlib import Path
from typing import Any, Callable

import bpy

from .storage_paths import user_default_dir

# Registration and validation use the same path in background and GUI mode.
# The helper itself already tolerates a missing Window/Preferences context, so a
# background-only branch would create an avoidable lifecycle divergence.
try:
    from .ui_language_runtime import is_japanese_locale as _ui_is_japanese_locale, ui_text as _ui_text
except Exception:  # pragma: no cover
    _ui_is_japanese_locale = None
    _ui_text = None

_SUITE_KEY = ''
_SUITE_LABEL = ''
_CATEGORY = ''
_OPERATOR_ID = ''
_REGISTERED_CLASSES: list[type] = []
_UI_OWNER_KEY = 'JELararagi.smart_file.feature_toggle.lifecycle.v57540'
_UI_LEGACY_OWNER_KEYS = (
    'JELararagi.smart_file.feature_toggle.lifecycle.v57539',
    'JELararagi.smart_file.feature_toggle.lifecycle.v57536',
    'JELararagi.smart_file.feature_toggle.lifecycle.v57535',
    'JELararagi.smart_file.feature_toggle.lifecycle.v57534',
)
_UI_OWNER_TOKEN = object()
_UI_GENERATION = uuid.uuid4().hex
_UI_CLASS_RECORDS: list[dict[str, Any]] = []
_DYNAMIC_WM_RECORDS: dict[str, dict[str, Any]] = {}
_FEATURES: dict[str, dict[str, dict[str, Any]]] = {}
_STATE_CACHE: dict[str, dict[str, bool]] | None = None
_DYNAMIC_WM_PROPS: set[str] = set()
_UPDATING_DYNAMIC_PROP = False
_CAPTURE_STACK: list['_RuntimeCapture'] = []
_CONFIG_DIR_NAME = 'Smart_File_Suite'
_SETTINGS_FILE_NAME = 'Smart_File_Suite.json'
_DUMMY_COUNTER = 0
_MAX_ACTIONS_PER_FEATURE = 8192
_LAST_RESOURCE_ERROR = ''

_KIND_ORDER = ('handlers', 'timers', 'msgbus', 'keymaps', 'draw_handlers')
_KIND_INFO = {
    'handlers': {
        'label_en': 'Application Handlers',
        'label_ja': 'アプリケーションハンドラー',
        'description_en': 'Enables handler functions that Blender runs automatically on file loading, saving, frame changes, dependency-graph updates, undo, redo, or rendering events. Use this only when this feature must react in the background. The state follows N-panel State Save behavior and is preserved in Smart_File_Suite/Smart_File_Suite.json.',
        'description_ja': 'ファイル読込・保存、フレーム変更、依存グラフ更新、Undo / Redo、レンダー関連イベントなどで Blender が自動実行するハンドラーを有効化します。この機能をバックグラウンドで自動反応させたい場合だけ有効にしてください。状態はNパネル状態保存の動作に従い、Smart_File_Suite/Smart_File_Suite.jsonに維持されます。',
    },
    'timers': {
        'label_en': 'Background Timers',
        'label_ja': 'バックグラウンドタイマー',
        'description_en': 'Enables timer callbacks that run after a delay or repeatedly without pressing a button. Use this only when this feature must keep checking or updating data automatically. The state follows N-panel State Save behavior and is preserved in Smart_File_Suite/Smart_File_Suite.json.',
        'description_ja': 'ボタン操作なしで、一定時間後または一定間隔で実行されるタイマー処理を有効化します。この機能で自動チェックや自動更新が必要な場合だけ有効にしてください。状態はNパネル状態保存の動作に従い、Smart_File_Suite/Smart_File_Suite.jsonに維持されます。',
    },
    'msgbus': {
        'label_en': 'RNA Message Bus Watchers',
        'label_ja': 'RNAメッセージバス監視',
        'description_en': 'Enables msgbus subscriptions that watch Blender data and run callbacks automatically when watched properties change. Use this only when this feature must monitor Blender data in real time. The state follows N-panel State Save behavior and is preserved in Smart_File_Suite/Smart_File_Suite.json.',
        'description_ja': 'Blender データの変更を監視し、監視対象プロパティが変わった時に自動でコールバックを実行する msgbus 購読を有効化します。この機能でリアルタイム監視が必要な場合だけ有効にしてください。状態はNパネル状態保存の動作に従い、Smart_File_Suite/Smart_File_Suite.jsonに維持されます。',
    },
    'keymaps': {
        'label_en': 'Hotkeys',
        'label_ja': 'ホットキー',
        'description_en': 'Enables keymap items and shortcuts for this feature. Use this when you want the feature to respond to keyboard or mouse shortcuts. The state follows N-panel State Save behavior and is preserved in Smart_File_Suite/Smart_File_Suite.json.',
        'description_ja': 'この機能用のキーマップ項目・ショートカットを有効化します。キーボードやマウスのショートカットで機能を操作したい場合に有効にしてください。状態はNパネル状態保存の動作に従い、Smart_File_Suite/Smart_File_Suite.jsonに維持されます。',
    },
    'draw_handlers': {
        'label_en': 'Viewport / Editor Draw',
        'label_ja': 'ビューポート / エディター描画',
        'description_en': 'Enables draw handlers that keep drawing overlays or helper graphics in the viewport or editors. Use this only when this feature must show live guides or overlays automatically. The state follows N-panel State Save behavior and is preserved in Smart_File_Suite/Smart_File_Suite.json.',
        'description_ja': 'ビューポートや各エディターにオーバーレイ・補助表示を描き続ける描画ハンドラーを有効化します。この機能のライブガイドやオーバーレイ表示が必要な場合だけ有効にしてください。状態はNパネル状態保存の動作に従い、Smart_File_Suite/Smart_File_Suite.jsonに維持されます。',
    },
}

_SPACE_CLASS_NAMES = (
    'SpaceView3D', 'SpaceImageEditor', 'SpaceNodeEditor', 'SpaceSequenceEditor',
    'SpaceClipEditor', 'SpaceDopeSheetEditor', 'SpaceGraphEditor', 'SpaceNLA',
    'SpaceTextEditor', 'SpaceConsole', 'SpaceInfo',
    'SpaceFileBrowser', 'SpaceSpreadsheet', 'SpaceOutliner', 'SpacePreferences',
)

# Fixed Blender handler lists supported by this package.  Do not enumerate the
# process-global handler namespace: resource capture is limited to these known
# lists and records every callback by exact Python identity.
_KNOWN_HANDLER_LISTS = (
    'load_pre', 'load_post', 'save_pre', 'save_post', 'save_post_fail',
    'undo_pre', 'undo_post', 'redo_pre', 'redo_post',
    'depsgraph_update_pre', 'depsgraph_update_post',
    'frame_change_pre', 'frame_change_post',
    'render_pre', 'render_init', 'render_post', 'render_complete',
    'render_cancel', 'render_write', 'animation_playback_pre',
    'animation_playback_post', 'exit_pre',
)



def _ui_namespace():
    try:
        value = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _ui_class_owned_rna(cls: type) -> bool:
    try:
        rna = vars(cls).get('bl_rna')
        return bool(rna is not None and str(getattr(rna, 'identifier', '') or '').strip())
    except Exception:
        return False


def _ui_property_descriptor(owner, name):
    try:
        direct = vars(owner).get(str(name))
        if direct is not None:
            return direct
    except Exception:
        pass
    try:
        return getattr(owner, str(name))
    except Exception:
        return None


def _ui_cleanup_generation(token=None, generation=None) -> bool:
    if token is not None and token is not _UI_OWNER_TOKEN:
        return False
    if generation is not None and str(generation) != _UI_GENERATION:
        return False
    ok = True
    # Remove only exact package-owned resources recorded by this generation.
    for feature_map in reversed(tuple(_FEATURES.values())):
        for feature in reversed(tuple(feature_map.values())):
            for action in reversed(tuple(feature.get('actions') or ())):
                if action.get('token') is not _UI_OWNER_TOKEN or action.get('generation') != _UI_GENERATION:
                    ok = False
                    continue
                if not _remove_action(action):
                    ok = False
    _FEATURES.clear()
    _CAPTURE_STACK.clear()
    wm_type = getattr(getattr(bpy, 'types', None), 'WindowManager', None)
    for record in reversed(tuple(_DYNAMIC_WM_RECORDS.values())):
        if not bool(record.get('acquired')) or wm_type is None:
            continue
        if _ui_property_descriptor(wm_type, record.get('name')) is not record.get('descriptor'):
            ok = False
            continue
        try:
            delattr(wm_type, record.get('name'))
        except Exception:
            ok = False
    _DYNAMIC_WM_RECORDS.clear()
    _DYNAMIC_WM_PROPS.clear()
    for record in reversed(tuple(_UI_CLASS_RECORDS)):
        cls = record.get('class')
        if not bool(record.get('acquired')) or not isinstance(cls, type):
            continue
        if vars(cls).get('bl_rna') is not record.get('rna'):
            ok = False
            continue
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            ok = False
    _UI_CLASS_RECORDS.clear()
    _REGISTERED_CLASSES.clear()
    namespace = _ui_namespace()
    if namespace is not None:
        ledger = namespace.get(_UI_OWNER_KEY)
        if isinstance(ledger, dict) and ledger.get('token') is _UI_OWNER_TOKEN:
            namespace.pop(_UI_OWNER_KEY, None)
    return bool(ok)


def _ui_prepare_owner() -> bool:
    namespace = _ui_namespace()
    if namespace is None:
        return False
    for legacy_key in _UI_LEGACY_OWNER_KEYS:
        previous_legacy = namespace.get(legacy_key)
        if previous_legacy is None:
            continue
        cleanup = previous_legacy.get('cleanup') if isinstance(previous_legacy, dict) else None
        if not callable(cleanup):
            return False
        try:
            if cleanup(previous_legacy.get('token'), previous_legacy.get('generation')) is False:
                return False
        except Exception:
            return False
        namespace.pop(legacy_key, None)
    previous = namespace.get(_UI_OWNER_KEY)
    if isinstance(previous, dict) and previous.get('token') is _UI_OWNER_TOKEN and previous.get('generation') == _UI_GENERATION:
        return True
    if previous is not None:
        cleanup = previous.get('cleanup') if isinstance(previous, dict) else None
        if not callable(cleanup) or cleanup(previous.get('token'), previous.get('generation')) is False:
            return False
        namespace.pop(_UI_OWNER_KEY, None)
    namespace[_UI_OWNER_KEY] = {
        'token': _UI_OWNER_TOKEN,
        'generation': _UI_GENERATION,
        'classes': _UI_CLASS_RECORDS,
        'properties': _DYNAMIC_WM_RECORDS,
        'resources': _FEATURES,
        'cleanup': _ui_cleanup_generation,
    }
    return True


def _clean_identifier(value: str, fallback: str = 'smart_file_suite') -> str:
    text = str(value or '').strip().split('.')[-1]
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    return text or fallback


def _dynamic_prop_name(alias: str, feature_key: str) -> str:
    return f"{_SUITE_KEY}_always_on_{_clean_identifier(alias, 'tool')}_{_clean_identifier(feature_key, 'feature')}"[:63]


def _make_dynamic_update(alias: str, feature_key: str):
    def _update(self=None, context=None):
        global _UPDATING_DYNAMIC_PROP
        if _UPDATING_DYNAMIC_PROP:
            return
        try:
            value = bool(getattr(self, _dynamic_prop_name(alias, feature_key))) if self is not None else False
        except Exception:
            value = False
        _UPDATING_DYNAMIC_PROP = True
        try:
            set_feature_enabled(alias, feature_key, value)
        finally:
            _UPDATING_DYNAMIC_PROP = False
    return _update


def _ensure_dynamic_wm_property(alias: str, feature_key: str) -> str:
    configure()
    prop_name = _dynamic_prop_name(alias, feature_key)
    if prop_name in _DYNAMIC_WM_PROPS:
        return prop_name
    try:
        wm_type = getattr(bpy.types, 'WindowManager', None)
        if not _ui_prepare_owner():
            raise RuntimeError('feature-toggle owner ledger is unavailable')
        current = _ui_property_descriptor(wm_type, prop_name) if wm_type is not None else None
        record = _DYNAMIC_WM_RECORDS.get(prop_name)
        if current is not None:
            if not isinstance(record, dict) or record.get('descriptor') is not current:
                raise RuntimeError(f'foreign WindowManager property exists: {prop_name}')
        elif wm_type is not None:
            setattr(wm_type, prop_name, bpy.props.BoolProperty(
                name='Always-on Feature State',
                description='Saved on/off state for a captured Smart File always-on runtime hook.',
                default=is_feature_enabled(alias, feature_key),
                update=_make_dynamic_update(alias, feature_key),
            ))
            current = _ui_property_descriptor(wm_type, prop_name)
            if current is None:
                raise RuntimeError(f'failed to register WindowManager.{prop_name}')
            _DYNAMIC_WM_RECORDS[prop_name] = {
                'name': prop_name,
                'descriptor': current,
                'acquired': True,
                'token': _UI_OWNER_TOKEN,
                'generation': _UI_GENERATION,
            }
        _DYNAMIC_WM_PROPS.add(prop_name)
    except Exception:
        pass
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        if wm is not None and hasattr(wm, prop_name):
            global _UPDATING_DYNAMIC_PROP
            old_flag = _UPDATING_DYNAMIC_PROP
            _UPDATING_DYNAMIC_PROP = True
            try:
                setattr(wm, prop_name, bool(is_feature_enabled(alias, feature_key)))
            finally:
                _UPDATING_DYNAMIC_PROP = old_flag
    except Exception:
        pass
    return prop_name


def _title_from_key(value: str) -> str:
    text = str(value or '').strip().split('.')[-1]
    text = text.replace('_suite', '').replace('_', ' ').strip()
    if not text:
        return 'Smart File'
    return ' '.join(part[:1].upper() + part[1:] for part in text.split())


def _infer_suite_key() -> str:
    package = str(__package__ or '').strip('.')
    if package:
        parts = [p for p in package.split('.') if p]
        if len(parts) >= 3 and parts[0] == 'bl_ext':
            return _clean_identifier(parts[2])
        if 'user_default' in parts:
            idx = parts.index('user_default')
            if idx + 1 < len(parts):
                return _clean_identifier(parts[idx + 1])
        if parts:
            return _clean_identifier(parts[0])
    return 'smart_file_suite'


def _infer_category(suite_key: str) -> str:
    title = _title_from_key(suite_key)
    return title if title.lower().startswith('smart ') else f'Smart {title}'


def configure(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    global _SUITE_KEY, _SUITE_LABEL, _CATEGORY, _OPERATOR_ID
    if not _SUITE_KEY:
        _SUITE_KEY = _clean_identifier(suite_key or _infer_suite_key())
    if suite_key:
        _SUITE_KEY = _clean_identifier(suite_key)
    if suite_label:
        _SUITE_LABEL = str(suite_label).strip()
    if not _SUITE_LABEL:
        _SUITE_LABEL = _title_from_key(_SUITE_KEY)
    if category:
        _CATEGORY = str(category).strip()
    if not _CATEGORY:
        _CATEGORY = _infer_category(_SUITE_KEY)
    _OPERATOR_ID = f'{_SUITE_KEY}.toggle_persistent_feature'


def _is_ja(context=None) -> bool:
    if callable(_ui_is_japanese_locale):
        try:
            return bool(_ui_is_japanese_locale(context))
        except Exception:
            pass
    try:
        prefs = getattr(getattr(context, 'preferences', None), 'view', None) if context is not None else getattr(getattr(bpy.context, 'preferences', None), 'view', None)
        if prefs is not None and hasattr(prefs, 'use_translate_interface') and not bool(getattr(prefs, 'use_translate_interface', False)):
            return False
        lang = str(getattr(prefs, 'language', '') or '').lower()
    except Exception:
        lang = ''
    try:
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').lower()
    except Exception:
        locale = ''
    return lang.startswith('ja') or locale.startswith('ja') or 'japanese' in lang


def _t(context, en: str, ja: str) -> str:
    if callable(_ui_text):
        try:
            return _ui_text(en, ja, context=context)
        except Exception:
            pass
    return str(ja if _is_ja(context) else en)


def _static_t(en: str, ja: str) -> str:
    if callable(_ui_text):
        try:
            return _ui_text(en, ja)
        except Exception:
            pass
    return str(ja if _is_ja(None) else en)


def _version_string() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None)
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def _write_json_atomic(path: Path, data: Any) -> bool:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
        tmp = path.with_name(path.name + '.tmp')
        tmp.write_text(payload, encoding='utf-8')
        tmp.replace(path)
        return True
    except Exception:
        try:
            tmp.unlink()
        except Exception:
            pass
        return False


def _settings_path() -> Path | None:
    configure()
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            try:
                root = Path(user_resource('CONFIG', path='', create=True))
            except TypeError:
                root = Path(user_resource('CONFIG', create=True))
            root = root / _CONFIG_DIR_NAME
            root.mkdir(parents=True, exist_ok=True)
            return root / _SETTINGS_FILE_NAME
    except Exception:
        pass
    try:
        version = _version_string()
        if os.name == 'nt':
            root = Path(os.environ.get('APPDATA', str(Path.home() / 'AppData' / 'Roaming'))) / 'Blender Foundation' / 'Blender' / version / 'config' / _CONFIG_DIR_NAME
        else:
            root = Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'blender' / version / 'config' / _CONFIG_DIR_NAME
        root.mkdir(parents=True, exist_ok=True)
        return root / _SETTINGS_FILE_NAME
    except Exception:
        return None


def _legacy_settings_paths() -> tuple[Path, ...]:
    paths: list[Path] = []
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            try:
                root = Path(user_resource('CONFIG', path='', create=False))
            except TypeError:
                root = Path(user_resource('CONFIG', create=False))
            paths.append(root / _SETTINGS_FILE_NAME)
    except Exception:
        pass
    try:
        version = _version_string()
        if os.name == 'nt':
            root = Path(os.environ.get('APPDATA', str(Path.home() / 'AppData' / 'Roaming'))) / 'Blender Foundation' / 'Blender' / version / 'config'
        else:
            root = Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'blender' / version / 'config'
        paths.append(root / _SETTINGS_FILE_NAME)
    except Exception:
        pass
    try:
        paths.append(Path(user_default_dir('settings', create=False)) / _SETTINGS_FILE_NAME)
        paths.append(Path(user_default_dir('settings', create=False)) / 'persistent_feature_toggles.json')
    except Exception:
        pass
    unique: list[Path] = []
    seen: set[str] = set()
    current = _settings_path()
    for path in paths:
        try:
            key = str(path.resolve())
            cur_key = str(current.resolve()) if current is not None else ''
        except Exception:
            key = str(path)
            cur_key = str(current) if current is not None else ''
        if key == cur_key:
            continue
        if key not in seen:
            seen.add(key)
            unique.append(path)
    return tuple(unique)


def _load_state() -> dict[str, dict[str, bool]]:
    global _STATE_CACHE
    if _STATE_CACHE is not None:
        return _STATE_CACHE
    data: dict[str, dict[str, bool]] = {}
    path = _settings_path()
    raw: dict[str, Any] = {}
    candidate_paths = []
    if path is not None:
        candidate_paths.append(path)
    candidate_paths.extend(_legacy_settings_paths())
    for candidate in candidate_paths:
        if candidate is None or not candidate.exists():
            continue
        try:
            loaded = json.loads(candidate.read_text(encoding='utf-8'))
            if isinstance(loaded, dict):
                raw = loaded
                if path is not None and candidate != path and not path.exists():
                    try:
                        path.parent.mkdir(parents=True, exist_ok=True)
                        path.write_text(json.dumps(raw, ensure_ascii=False, indent=2, sort_keys=True), encoding='utf-8')
                    except Exception:
                        pass
                break
        except Exception:
            raw = {}
    feature_payload = raw.get('feature_toggles') if isinstance(raw.get('feature_toggles'), dict) else raw
    if isinstance(feature_payload, dict):
        for alias, values in feature_payload.items():
            if alias in {'version', 'window_manager', 'window_manager_pointers', 'preferences', 'preferences_collections', 'scene_defaults', 'scene_pointers', 'ui_section_state', 'meta', 'common_settings'}:
                continue
            if isinstance(values, dict):
                data[str(alias)] = {str(k): bool(v) for k, v in values.items()}
    _STATE_CACHE = data
    return _STATE_CACHE


def export_state_for_config() -> dict[str, dict[str, bool]]:
    data = _load_state()
    out: dict[str, dict[str, bool]] = {}
    try:
        for alias, values in data.items():
            if isinstance(values, dict):
                out[str(alias)] = {str(k): bool(v) for k, v in values.items()}
    except Exception:
        pass
    return out


def import_state_for_config(state: Any, *, apply_runtime: bool = True) -> dict[str, dict[str, bool]]:
    """Replace the in-memory always-on state with data loaded from Smart_File_Suite/Smart_File_Suite.json.

    This is called on Blender/file load so the Always-on Toggles section does not
    depend on stale module globals from the previous scene.  It deliberately does
    not write the file; the central settings writer controls persistence timing.
    """
    global _STATE_CACHE, _UPDATING_DYNAMIC_PROP
    sanitized: dict[str, dict[str, bool]] = {}
    if isinstance(state, dict):
        for alias, values in state.items():
            if isinstance(values, dict):
                key = str(alias or '').strip()
                if key:
                    sanitized[key] = {str(k): bool(v) for k, v in values.items() if str(k or '').strip()}
    _STATE_CACHE = sanitized

    old_flag = _UPDATING_DYNAMIC_PROP
    _UPDATING_DYNAMIC_PROP = True
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        if wm is not None:
            for alias, values in sanitized.items():
                for feature_key, enabled in values.items():
                    try:
                        prop_name = _ensure_dynamic_wm_property(alias, feature_key)
                        if hasattr(wm, prop_name):
                            setattr(wm, prop_name, bool(enabled))
                    except Exception:
                        pass
    finally:
        _UPDATING_DYNAMIC_PROP = old_flag

    if apply_runtime:
        for alias, features in list(_FEATURES.items()):
            states = sanitized.get(alias, {})
            for feature_key, feature in list(features.items()):
                try:
                    _set_feature_active(feature, bool(states.get(feature_key, False)))
                except Exception:
                    pass
    _tag_redraw()
    return export_state_for_config()


def reload_state_from_config(*, apply_runtime: bool = True) -> dict[str, dict[str, bool]]:
    """Reload always-on states from Smart_File_Suite/Smart_File_Suite.json and apply loaded runtimes."""
    global _STATE_CACHE
    _STATE_CACHE = None
    return import_state_for_config(export_state_for_config(), apply_runtime=apply_runtime)



def _save_state() -> None:
    # Keep the updated cache in memory. The central Smart_File_Suite.json writer
    # owns disk persistence so N-panel State Save can decide whether this change
    # is written immediately or deferred until file close / Save Preferences.
    try:
        from . import settings as _sf_settings
        if hasattr(_sf_settings, 'schedule_save'):
            _sf_settings.schedule_save(getattr(bpy, 'context', None))
            return
    except Exception:
        pass

    # No lower writer is allowed.  If the canonical service is unavailable,
    # keep the state in memory and expose the service failure; a later real UI
    # change after recovery will schedule the canonical atomic transaction.
    return




def is_feature_enabled(alias: str, feature_key: str) -> bool:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    return bool(_load_state().get(alias, {}).get(feature_key, False))


def set_feature_enabled(alias: str, feature_key: str, enabled: bool) -> bool:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    if not alias or not feature_key:
        return False
    _load_state().setdefault(alias, {})[feature_key] = bool(enabled)
    _save_state()
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature is not None:
        _set_feature_active(feature, bool(enabled))
    try:
        prop_name = _ensure_dynamic_wm_property(alias, feature_key)
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        if wm is not None and hasattr(wm, prop_name):
            global _UPDATING_DYNAMIC_PROP
            old_flag = _UPDATING_DYNAMIC_PROP
            _UPDATING_DYNAMIC_PROP = True
            try:
                setattr(wm, prop_name, bool(enabled))
            finally:
                _UPDATING_DYNAMIC_PROP = old_flag
    except Exception:
        pass
    _tag_redraw()
    return True


def _feature_record(alias: str, tool_label: str, feature_key: str) -> dict[str, Any]:
    alias = str(alias or '').strip()
    tool_label = str(tool_label or alias or 'Integrated Tool').strip()
    feature_key = str(feature_key or '').strip()
    info = _KIND_INFO.get(feature_key, {})
    features = _FEATURES.setdefault(alias, {})
    feature = features.get(feature_key)
    if feature is None:
        feature = {
            'alias': alias,
            'tool_label': tool_label,
            'key': feature_key,
            'label_en': str(info.get('label_en') or feature_key),
            'label_ja': str(info.get('label_ja') or feature_key),
            'description_en': str(info.get('description_en') or ''),
            'description_ja': str(info.get('description_ja') or ''),
            'actions': [],
        }
        features[feature_key] = feature
    else:
        feature['tool_label'] = tool_label
    try:
        feature['wm_prop_name'] = _ensure_dynamic_wm_property(alias, feature_key)
    except Exception:
        pass
    return feature


def _add_action(alias: str, tool_label: str, feature_key: str, action: dict[str, Any]) -> bool:
    global _LAST_RESOURCE_ERROR
    if not _ui_prepare_owner():
        _LAST_RESOURCE_ERROR = 'feature-toggle resource owner ledger is unavailable'
        return False
    action['token'] = _UI_OWNER_TOKEN
    action['generation'] = _UI_GENERATION
    feature = _feature_record(alias, tool_label, feature_key)
    actions = feature.setdefault('actions', [])
    if len(actions) >= _MAX_ACTIONS_PER_FEATURE:
        _LAST_RESOURCE_ERROR = f'resource action limit reached: {alias}/{feature_key}'
        return False
    actions.append(action)
    _LAST_RESOURCE_ERROR = ''
    return True


def feature_entries(alias: str | None = None) -> list[dict[str, Any]]:
    aliases = [str(alias).strip()] if alias else sorted(_FEATURES.keys())
    out: list[dict[str, Any]] = []
    for alias_key in aliases:
        feature_map = _FEATURES.get(alias_key, {})
        for key in _KIND_ORDER:
            feature = feature_map.get(key)
            if not feature or not feature.get('actions'):
                continue
            item = dict(feature)
            item['enabled'] = is_feature_enabled(alias_key, key)
            item['action_count'] = len(feature.get('actions') or [])
            out.append(item)
    return out


def all_feature_aliases() -> tuple[str, ...]:
    return tuple(sorted(alias for alias, items in _FEATURES.items() if any((f.get('actions') for f in items.values()))))



def enabled_state_aliases() -> tuple[str, ...]:
    """Aliases that have at least one saved always-on feature enabled."""
    try:
        state = _load_state()
        return tuple(sorted(str(alias) for alias, values in state.items() if isinstance(values, dict) and any(bool(v) for v in values.values())))
    except Exception:
        return tuple()

def _snapshot_handlers() -> dict[str, set[int]]:
    """Deprecated compatibility hook; explicit AST receipts replaced scans."""
    return {}


def _collect_new_handlers(before: dict[str, set[int]]) -> list[dict[str, Any]]:
    del before
    return []



def _enum_identifiers_from_rna(rna_owner, prop_name: str) -> set[str]:
    try:
        properties = getattr(getattr(rna_owner, 'bl_rna', None), 'properties', None)
        prop = None
        try:
            prop = properties.get(prop_name) if properties is not None else None
        except Exception:
            try:
                prop = properties[prop_name]
            except Exception:
                prop = None
        return {str(item.identifier) for item in getattr(prop, 'enum_items', ()) if str(getattr(item, 'identifier', '') or '')}
    except Exception:
        return set()


def _keymap_event_identifiers(prop_name: str) -> set[str]:
    try:
        kc = getattr(getattr(bpy.context, 'window_manager', None), 'keyconfigs', None)
        addon = getattr(kc, 'addon', None) if kc is not None else None
        if addon is not None:
            sample_km = addon.keymaps.get('Window') or addon.keymaps.get('3D View')
            sample = None
            try:
                for item in sample_km.keymap_items:
                    sample = item
                    break
            except Exception:
                sample = None
            if sample is not None:
                identifiers = _enum_identifiers_from_rna(sample, prop_name)
                if identifiers:
                    return identifiers
    except Exception:
        pass
    fallback = {
        'type': {'NONE', 'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE', 'BUTTON4MOUSE', 'BUTTON5MOUSE', 'BUTTON6MOUSE', 'BUTTON7MOUSE', 'PEN', 'ERASER', 'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE', 'MOUSESMARTZOOM', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'ZERO', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE', 'LEFT_CTRL', 'LEFT_ALT', 'LEFT_SHIFT', 'RIGHT_ALT', 'RIGHT_CTRL', 'RIGHT_SHIFT', 'OSKEY', 'APP', 'ESC', 'TAB', 'RET', 'SPACE', 'LINE_FEED', 'BACK_SPACE', 'DEL', 'SEMI_COLON', 'PERIOD', 'COMMA', 'QUOTE', 'ACCENT_GRAVE', 'MINUS', 'PLUS', 'SLASH', 'BACK_SLASH', 'EQUAL', 'LEFT_BRACKET', 'RIGHT_BRACKET', 'LEFT_ARROW', 'DOWN_ARROW', 'RIGHT_ARROW', 'UP_ARROW', 'NUMPAD_0', 'NUMPAD_1', 'NUMPAD_2', 'NUMPAD_3', 'NUMPAD_4', 'NUMPAD_5', 'NUMPAD_6', 'NUMPAD_7', 'NUMPAD_8', 'NUMPAD_9', 'NUMPAD_PERIOD', 'NUMPAD_SLASH', 'NUMPAD_ASTERIX', 'NUMPAD_MINUS', 'NUMPAD_ENTER', 'NUMPAD_PLUS', 'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12', 'F13', 'F14', 'F15', 'F16', 'F17', 'F18', 'F19', 'F20', 'F21', 'F22', 'F23', 'F24', 'PAUSE', 'INSERT', 'HOME', 'PAGE_UP', 'PAGE_DOWN', 'END', 'MEDIA_PLAY', 'MEDIA_STOP', 'MEDIA_FIRST', 'MEDIA_LAST'},
        'value': {'ANY', 'PRESS', 'RELEASE', 'CLICK', 'DOUBLE_CLICK', 'CLICK_DRAG', 'NOTHING'},
        'key_modifier': {'NONE', 'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE', 'LEFT_CTRL', 'LEFT_ALT', 'LEFT_SHIFT', 'RIGHT_ALT', 'RIGHT_CTRL', 'RIGHT_SHIFT', 'OSKEY', 'APP', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'},
        'direction': {'ANY', 'NORTH', 'NORTH_EAST', 'EAST', 'SOUTH_EAST', 'SOUTH', 'SOUTH_WEST', 'WEST', 'NORTH_WEST'},
    }
    return set(fallback.get(prop_name, set()))


def _safe_event_identifier(value: object, prop_name: str, default: str) -> str:
    text = str(value or '').strip().upper()
    if not text or text.isdigit() or text.startswith('-'):
        return ''
    identifiers = _keymap_event_identifiers(prop_name)
    if identifiers and text not in identifiers:
        return ''
    return text or default

def _snapshot_keymaps() -> set[int]:
    """Deprecated compatibility hook; exact KeyMapItems receipts are used."""
    return set()



def _copy_keymap_properties(kmi) -> dict[str, Any]:
    props_out: dict[str, Any] = {}
    try:
        props = getattr(kmi, 'properties', None)
        bl_rna = getattr(props, 'bl_rna', None)
        for prop in getattr(bl_rna, 'properties', ()) or ():
            ident = str(getattr(prop, 'identifier', '') or '')
            if not ident or ident == 'rna_type':
                continue
            try:
                value = getattr(props, ident)
            except Exception:
                continue
            if isinstance(value, (str, int, float, bool)):
                props_out[ident] = value
    except Exception:
        pass
    return props_out


def _describe_keymap_item(km, kmi) -> dict[str, Any] | None:
    def _get(obj, name: str, default=None):
        try:
            return getattr(obj, name)
        except Exception:
            return default
    idname = str(_get(kmi, 'idname', '') or '')
    props = _copy_keymap_properties(kmi)
    event_type = _safe_event_identifier(_get(kmi, 'type', 'NONE'), 'type', 'NONE')
    event_value = _safe_event_identifier(_get(kmi, 'value', 'PRESS'), 'value', 'PRESS')
    key_modifier = _safe_event_identifier(_get(kmi, 'key_modifier', 'NONE'), 'key_modifier', 'NONE') or 'NONE'
    direction = _safe_event_identifier(_get(kmi, 'direction', 'ANY'), 'direction', 'ANY') or 'ANY'
    if not event_type or not event_value:
        return None
    # Do not capture/replay an empty Blender tool switch. A blank
    # wm.tool_set_by_id name produces Blender's "Tool '' not found for
    # space 'VIEW_3D'" message.
    if idname == 'wm.tool_set_by_id' and not str(props.get('name') or '').strip():
        return None
    return {
        'kind': 'keymaps',
        'km_name': str(_get(km, 'name', '') or ''),
        'space_type': str(_get(km, 'space_type', 'EMPTY') or 'EMPTY'),
        'region_type': str(_get(km, 'region_type', 'WINDOW') or 'WINDOW'),
        'modal': bool(_get(km, 'is_modal', False)),
        'idname': idname,
        'type': event_type,
        'value': event_value,
        'any': bool(_get(kmi, 'any', False)),
        'shift': bool(_get(kmi, 'shift', False)),
        'ctrl': bool(_get(kmi, 'ctrl', False)),
        'alt': bool(_get(kmi, 'alt', False)),
        'oskey': bool(_get(kmi, 'oskey', False)),
        'key_modifier': key_modifier,
        'direction': direction,
        'repeat': bool(_get(kmi, 'repeat', False)),
        'properties': props,
        'km': km,
        'kmi': kmi,
        'active': True,
        'acquired': False,
    }


def _collect_new_keymaps(before: set[int]) -> list[dict[str, Any]]:
    del before
    return []



def _action_owned(action: dict[str, Any]) -> bool:
    return bool(
        isinstance(action, dict)
        and action.get('token') is _UI_OWNER_TOKEN
        and action.get('generation') == _UI_GENERATION
    )


def _keymap_contains_exact(km, kmi) -> bool:
    try:
        return any(item is kmi for item in tuple(km.keymap_items))
    except Exception:
        return False



def _remove_action(action: dict[str, Any]) -> bool:
    """Remove only the exact resource acquired by this generation."""
    if not _action_owned(action):
        return False
    if not bool(action.get('active', False)):
        return True
    # A matching resource may have existed before capture.  It is usable while
    # enabled, but it is not ours and must never be absorbed or removed.
    if not bool(action.get('acquired', False)):
        action['active'] = False
        action['last_error'] = ''
        return True
    kind = str(action.get('kind') or '')
    ok = False
    try:
        if kind == 'handlers':
            seq = action.get('handler_list')
            if seq is None:
                handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
                seq = getattr(handlers, str(action.get('list_name') or ''), None) if handlers is not None else None
            fn = action.get('fn')
            if seq is None or not callable(fn):
                return False
            matches = [item for item in tuple(seq) if item is fn]
            if len(matches) == 1:
                seq.remove(fn)
            elif len(matches) > 1:
                # Never guess which duplicate belongs to another owner.
                action['last_error'] = 'exact handler identity is duplicated; refusing broad removal'
                return False
            ok = not any(item is fn for item in tuple(seq))
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is None or not callable(fn):
                return False
            checker = getattr(timers, 'is_registered', None)
            registered = bool(checker(fn)) if callable(checker) else True
            if registered:
                timers.unregister(fn)
            ok = not bool(checker(fn)) if callable(checker) else True
        elif kind == 'msgbus':
            owner = action.get('owner')
            clear = getattr(getattr(bpy, 'msgbus', None), 'clear_by_owner', None)
            if owner is None or not callable(clear):
                return False
            clear(owner)
            ok = True
        elif kind == 'draw_handlers':
            handle = action.get('handle')
            space_cls = action.get('space_cls')
            region_type = action.get('region_type')
            remove = getattr(space_cls, 'draw_handler_remove', None) if space_cls is not None else None
            if handle is None:
                ok = True
            elif callable(remove):
                remove(handle, region_type)
                ok = True
            action['handle'] = None
        elif kind == 'keymaps':
            keymap_items = action.get('keymap_items')
            kmi = action.get('active_kmi') or action.get('kmi')
            km = action.get('active_km') or action.get('km')
            if keymap_items is not None:
                contains = any(item is kmi for item in tuple(keymap_items)) if kmi is not None else False
                if contains:
                    keymap_items.remove(kmi)
                ok = not any(item is kmi for item in tuple(keymap_items)) if kmi is not None else True
            elif km is None or kmi is None:
                ok = True
            elif _keymap_contains_exact(km, kmi):
                km.keymap_items.remove(kmi)
                ok = not _keymap_contains_exact(km, kmi)
            else:
                ok = True
            if ok:
                action['active_km'] = None
                action['active_kmi'] = None
                action['kmi'] = None
        else:
            ok = False
    except Exception as exc:
        action['last_error'] = f'{type(exc).__name__}: {exc}'
        ok = False
    if ok:
        action['active'] = False
        action['acquired'] = False
        action['last_error'] = ''
    return bool(ok)


def _apply_keymap_action(action: dict[str, Any]) -> None:
    if bool(action.get('active', False)):
        return
    try:
        keymap_items = action.get('keymap_items')
        if keymap_items is not None and action.get('args') is not None:
            kmi = keymap_items.new(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
            action['kmi'] = kmi
            action['active_kmi'] = kmi
            action['active'] = True
            action['acquired'] = True
            return
        kc = bpy.context.window_manager.keyconfigs.addon
        km_name = str(action.get('km_name') or '')
        idname = str(action.get('idname') or '')
        if not km_name or not idname:
            return
        if idname == 'wm.tool_set_by_id' and not str((action.get('properties') or {}).get('name') or '').strip():
            return
        try:
            km = kc.keymaps.get(km_name)
        except Exception:
            km = None
        if km is None:
            try:
                km = kc.keymaps.new(name=km_name, space_type=str(action.get('space_type') or 'EMPTY'), region_type=str(action.get('region_type') or 'WINDOW'), modal=bool(action.get('modal', False)))
            except TypeError:
                km = kc.keymaps.new(name=km_name, space_type=str(action.get('space_type') or 'EMPTY'), region_type=str(action.get('region_type') or 'WINDOW'))
        event_type = _safe_event_identifier(action.get('type'), 'type', 'NONE')
        event_value = _safe_event_identifier(action.get('value'), 'value', 'PRESS')
        key_modifier = _safe_event_identifier(action.get('key_modifier'), 'key_modifier', 'NONE') or 'NONE'
        direction = _safe_event_identifier(action.get('direction'), 'direction', 'ANY') or 'ANY'
        if not event_type or not event_value:
            return
        kwargs = {
            'type': event_type,
            'value': event_value,
            'any': bool(action.get('any', False)),
            'shift': bool(action.get('shift', False)),
            'ctrl': bool(action.get('ctrl', False)),
            'alt': bool(action.get('alt', False)),
            'oskey': bool(action.get('oskey', False)),
            'key_modifier': key_modifier,
            'direction': direction,
            'repeat': bool(action.get('repeat', False)),
        }
        try:
            kmi = km.keymap_items.new(idname, **kwargs)
        except TypeError:
            kwargs.pop('repeat', None)
            try:
                kmi = km.keymap_items.new(idname, **kwargs)
            except TypeError:
                kwargs.pop('direction', None)
                kmi = km.keymap_items.new(idname, **kwargs)
        for prop_name, value in (action.get('properties') or {}).items():
            try:
                _safe_safe_set_kmi_property_v60(kmi, prop_name, value)
            except Exception:
                pass
        action['active_km'] = km
        action['active_kmi'] = kmi
        action['active'] = True
        action['acquired'] = True
    except Exception as exc:
        action['active'] = False
        action['acquired'] = False
        action['last_error'] = f'{type(exc).__name__}: {exc}'


def _apply_action(action: dict[str, Any]) -> None:
    if not _action_owned(action):
        action['active'] = False
        action['acquired'] = False
        action['last_error'] = 'resource generation ownership mismatch'
        return
    if bool(action.get('active', False)):
        return
    kind = str(action.get('kind') or '')
    try:
        if kind == 'handlers':
            seq = action.get('handler_list')
            if seq is None:
                handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
                seq = getattr(handlers, str(action.get('list_name') or ''), None) if handlers is not None else None
            fn = action.get('fn')
            if seq is not None and callable(fn):
                count = sum(1 for item in tuple(seq) if item is fn)
                if count == 0:
                    seq.append(fn)
                    action['acquired'] = True
                    count = sum(1 for item in tuple(seq) if item is fn)
                else:
                    action['acquired'] = False
                action['active'] = count >= 1
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is not None and callable(fn):
                checker = getattr(timers, 'is_registered', None)
                registered = bool(checker(fn)) if callable(checker) else False
                if registered:
                    action['active'] = True
                    action['acquired'] = False
                else:
                    timers.register(fn, *tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                    action['active'] = bool(checker(fn)) if callable(checker) else True
                    action['acquired'] = bool(action['active'])
        elif kind == 'msgbus':
            subscribe = getattr(bpy.msgbus, 'subscribe_rna', None)
            if callable(subscribe):
                subscribe(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
                action['acquired'] = True
        elif kind == 'draw_handlers':
            space_cls = action.get('space_cls')
            add = getattr(space_cls, 'draw_handler_add', None)
            if callable(add):
                action['handle'] = add(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
                action['acquired'] = True
        elif kind == 'keymaps':
            _apply_keymap_action(action)
        action['last_error'] = '' if bool(action.get('active')) else str(action.get('last_error') or '')
    except Exception as exc:
        action['active'] = False
        action['acquired'] = False
        action['last_error'] = f'{type(exc).__name__}: {exc}'

def _set_feature_active(feature: dict[str, Any], enabled: bool) -> None:
    actions = list(feature.get('actions') or [])
    if enabled:
        for action in actions:
            _apply_action(action)
    else:
        for action in reversed(actions):
            _remove_action(action)


def deactivate_alias(alias: str) -> None:
    for feature in list(_FEATURES.get(str(alias or '').strip(), {}).values()):
        _set_feature_active(feature, False)


def clear_alias(alias: str) -> None:
    alias = str(alias or '').strip()
    deactivate_alias(alias)
    _FEATURES.pop(alias, None)


def _current_capture() -> '_RuntimeCapture | None':
    return _CAPTURE_STACK[-1] if _CAPTURE_STACK else None


class _DummyDrawHandle:
    def __init__(self, label: str):
        self.label = label


def _next_dummy_handle() -> _DummyDrawHandle:
    global _DUMMY_COUNTER
    _DUMMY_COUNTER += 1
    return _DummyDrawHandle(f'disabled_draw_handler_{_DUMMY_COUNTER}')



def _timer_register_proxy(function, *args, **kwargs):
    """Register one package callback without absorbing a pre-existing timer."""
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    register = getattr(timers, 'register', None) if timers is not None else None
    if not callable(register):
        global _LAST_RESOURCE_ERROR
        _LAST_RESOURCE_ERROR = 'bpy.app.timers.register is unavailable'
        return None
    cap = _current_capture()
    if cap is None:
        return register(function, *args, **kwargs)
    checker = getattr(timers, 'is_registered', None)
    preexisting = bool(checker(function)) if callable(checker) else False
    action = {
        'kind': 'timers', 'fn': function, 'args': tuple(args),
        'kwargs': dict(kwargs), 'active': False, 'acquired': False,
    }
    if not cap.record_action('timers', action):
        return None
    if cap.kind_enabled('timers'):
        if preexisting:
            action['active'] = True
            action['acquired'] = False
            return None
        result = register(function, *args, **kwargs)
        action['active'] = bool(checker(function)) if callable(checker) else True
        action['acquired'] = bool(action['active'])
        return result
    return None

def _timer_unregister_proxy(function):
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    unregister = getattr(timers, 'unregister', None) if timers is not None else None
    cap = _current_capture()
    if cap is not None:
        for feature in list(_FEATURES.get(cap.alias, {}).values()):
            for action in list(feature.get('actions') or ()):
                if action.get('kind') == 'timers' and action.get('fn') is function:
                    _remove_action(action)
                    return None
    if callable(unregister):
        try:
            checker = getattr(timers, 'is_registered', None)
            if not callable(checker) or checker(function):
                return unregister(function)
        except Exception:
            return None
    return None



def _msgbus_subscribe_proxy(*args, **kwargs):
    """Subscribe with a unique generation-owned owner identity."""
    subscribe = getattr(getattr(bpy, 'msgbus', None), 'subscribe_rna', None)
    if not callable(subscribe):
        global _LAST_RESOURCE_ERROR
        _LAST_RESOURCE_ERROR = 'bpy.msgbus.subscribe_rna is unavailable'
        return None
    cap = _current_capture()
    if cap is None:
        return subscribe(*args, **kwargs)
    original_args = tuple(args)
    original_kwargs = dict(kwargs)
    requested_owner = original_kwargs.get('owner')
    if requested_owner is None and len(original_args) >= 2:
        requested_owner = original_args[1]
    owned_owner = object()
    owned_args = list(original_args)
    owned_kwargs = dict(original_kwargs)
    if 'owner' in owned_kwargs or len(owned_args) < 2:
        owned_kwargs['owner'] = owned_owner
    else:
        owned_args[1] = owned_owner
    action = {
        'kind': 'msgbus',
        'args': tuple(owned_args),
        'kwargs': owned_kwargs,
        'owner': owned_owner,
        'requested_owner': requested_owner,
        'active': False,
        'acquired': False,
    }
    if not cap.record_action('msgbus', action):
        return None
    if cap.kind_enabled('msgbus'):
        result = subscribe(*tuple(owned_args), **owned_kwargs)
        action['active'] = True
        action['acquired'] = True
        return result
    return None


def _msgbus_clear_proxy(owner):
    cap = _current_capture()
    if cap is not None:
        matched = False
        for feature in list(_FEATURES.get(cap.alias, {}).values()):
            for action in list(feature.get('actions') or ()):
                if action.get('kind') == 'msgbus' and action.get('requested_owner') is owner:
                    matched = True
                    _remove_action(action)
        if matched:
            return None
        # During capture, never clear an unowned caller-supplied owner.
        return None
    clear = getattr(getattr(bpy, 'msgbus', None), 'clear_by_owner', None)
    if callable(clear):
        return clear(owner)
    return None


def _draw_handler_add_proxy(space_cls, *args, **kwargs):
    """Register one exact package-owned draw handle without class patching."""
    original_add = getattr(space_cls, 'draw_handler_add', None)
    if not callable(original_add):
        global _LAST_RESOURCE_ERROR
        _LAST_RESOURCE_ERROR = 'draw_handler_add is unavailable'
        return _next_dummy_handle()
    cap = _current_capture()
    if cap is None:
        return original_add(*args, **kwargs)
    region_type = args[2] if len(args) >= 3 else kwargs.get('region_type')
    dummy = _next_dummy_handle()
    action = {
        'kind': 'draw_handlers',
        'space_name': str(getattr(space_cls, '__name__', '') or ''),
        'space_cls': space_cls,
        'args': tuple(args),
        'kwargs': dict(kwargs),
        'region_type': region_type,
        'handle': None,
        'disabled_handle': dummy,
        'active': False,
        'acquired': False,
    }
    if not cap.record_action('draw_handlers', action):
        return dummy
    if cap.kind_enabled('draw_handlers'):
        action['handle'] = original_add(*args, **kwargs)
        action['active'] = True
        action['acquired'] = True
        return action['handle']
    return dummy


def _draw_handler_remove_proxy(space_cls, handle, region_type):
    cap = _current_capture()
    if cap is not None:
        for feature in list(_FEATURES.get(cap.alias, {}).values()):
            for action in list(feature.get('actions') or ()):
                if action.get('kind') == 'draw_handlers' and (
                    action.get('handle') is handle or action.get('disabled_handle') is handle
                ):
                    _remove_action(action)
                    return None
        # Unknown handles are not owned by this capture.
        return None
    if isinstance(handle, _DummyDrawHandle):
        return None
    remove = getattr(space_cls, 'draw_handler_remove', None)
    if callable(remove):
        return remove(handle, region_type)
    return None


def _handler_append_proxy(handler_list, function):
    """Append one exact callback without claiming a pre-existing identity."""
    cap = _current_capture()
    if cap is None:
        handler_list.append(function)
        return None
    preexisting = any(item is function for item in tuple(handler_list))
    action = {
        'kind': 'handlers',
        'handler_list': handler_list,
        'list_name': '',
        'fn': function,
        'active': False,
        'acquired': False,
    }
    if not cap.record_action('handlers', action):
        return None
    if cap.kind_enabled('handlers'):
        if preexisting:
            action['active'] = True
            action['acquired'] = False
        else:
            handler_list.append(function)
            action['active'] = any(item is function for item in tuple(handler_list))
            action['acquired'] = bool(action['active'])
    return None

def _handler_remove_proxy(handler_list, function):
    cap = _current_capture()
    if cap is not None:
        for feature in tuple(_FEATURES.get(cap.alias, {}).values()):
            for action in tuple(feature.get('actions') or ()):
                if action.get('kind') == 'handlers' and action.get('handler_list') is handler_list and action.get('fn') is function:
                    _remove_action(action)
                    return None
    try:
        while any(item is function for item in tuple(handler_list)):
            handler_list.remove(function)
    except Exception:
        pass
    return None



def _keymap_new_proxy(keymap_items, *args, **kwargs):
    cap = _current_capture()
    if cap is None:
        return keymap_items.new(*args, **kwargs)
    action = {
        'kind': 'keymaps',
        'keymap_items': keymap_items,
        'args': tuple(args),
        'kwargs': dict(kwargs),
        'kmi': None,
        'active': False,
        'acquired': False,
    }
    if not cap.record_action('keymaps', action):
        return None
    if cap.kind_enabled('keymaps'):
        kmi = keymap_items.new(*args, **kwargs)
        action['kmi'] = kmi
        action['active_kmi'] = kmi
        action['active'] = True
        action['acquired'] = True
        return kmi
    return None

def _keymap_remove_proxy(keymap_items, kmi):
    cap = _current_capture()
    if cap is not None:
        for feature in tuple(_FEATURES.get(cap.alias, {}).values()):
            for action in tuple(feature.get('actions') or ()):
                if action.get('kind') == 'keymaps' and action.get('keymap_items') is keymap_items and (action.get('kmi') is kmi or action.get('active_kmi') is kmi):
                    _remove_action(action)
                    return None
    try:
        if any(item is kmi for item in tuple(keymap_items)):
            keymap_items.remove(kmi)
    except Exception:
        pass
    return None


def _install_patches() -> None:
    # Retained API compatibility only. All package resources are routed by the
    # loader's AST transform to explicit local helpers; no process-global API is
    # ever replaced, even transiently.
    return None


def _uninstall_patches() -> None:
    return None


explicit_timer_register = _timer_register_proxy
explicit_timer_unregister = _timer_unregister_proxy
explicit_msgbus_subscribe = _msgbus_subscribe_proxy
explicit_msgbus_clear = _msgbus_clear_proxy
explicit_draw_handler_add = _draw_handler_add_proxy
explicit_draw_handler_remove = _draw_handler_remove_proxy
explicit_handler_append = _handler_append_proxy
explicit_handler_remove = _handler_remove_proxy
explicit_keymap_new = _keymap_new_proxy
explicit_keymap_remove = _keymap_remove_proxy


class _RuntimeCapture(AbstractContextManager):
    def __init__(self, alias: str, tool_label: str | None = None):
        configure()
        self.alias = str(alias or '').strip()
        self.tool_label = str(tool_label or self.alias or 'Integrated Tool').strip()
        self._before_handlers: dict[str, set[int]] = {}
        self._before_keymaps: set[int] = set()

    def __enter__(self):
        # Every supported resource call is redirected explicitly by loader.py.
        # No process-global handler/keymap snapshot is taken.
        self._before_handlers = {}
        self._before_keymaps = set()
        _CAPTURE_STACK.append(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        if self in _CAPTURE_STACK:
            _CAPTURE_STACK.remove(self)
        _tag_redraw()
        return False

    def kind_enabled(self, feature_key: str) -> bool:
        return is_feature_enabled(self.alias, feature_key)

    def record_action(self, feature_key: str, action: dict[str, Any]) -> bool:
        if self.alias and feature_key:
            return bool(_add_action(self.alias, self.tool_label, feature_key, action))
        return False


def capture_runtime(alias: str, tool_label: str | None = None) -> _RuntimeCapture:
    return _RuntimeCapture(alias, tool_label)


def capture_call(alias: str, tool_label: str | None, callback: Callable[[], Any]) -> Any:
    with capture_runtime(alias, tool_label):
        return callback()


def _tag_redraw() -> None:
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def _operator_description(context, properties) -> str:
    alias = str(getattr(properties, 'alias', '') or '')
    feature_key = str(getattr(properties, 'feature_key', '') or '')
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature:
        label = _t(context, feature.get('label_en', ''), feature.get('label_ja', ''))
        desc = _t(context, feature.get('description_en', ''), feature.get('description_ja', ''))
        state = _t(context, 'Click to switch this feature between enabled and disabled.', 'クリックすると、この機能の有効・無効を切り替えます。')
        return f'{label}: {desc} {state}'
    return _t(context, 'Toggle an always-on Smart File feature. With N-panel State Save enabled, rapid changes are combined into one quiet-period save. With it disabled, no automatic save callback remains and Save Preferences performs the explicit save.', 'Smart File の常時起動機能を切り替えます。Nパネル状態保存が有効な場合は連続変更をまとめて一度保存します。無効時は自動保存コールバックを残さず、設定保存で明示的に保存します。')


def _operator_id_owned_elsewhere(operator_id: str) -> bool:
    namespace, name = operator_id.split('.', 1)
    try:
        rna = getattr(getattr(bpy.ops, namespace), name).get_rna_type()
    except (KeyError, RuntimeError):
        return False
    owner = bpy.types.Operator.bl_rna_get_subclass_py(rna.identifier)
    return owner is None or getattr(owner, '__module__', '') != __name__


def register_ui(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> bool:
    global _LAST_RESOURCE_ERROR
    configure(suite_key=suite_key, suite_label=suite_label, category=category)
    if _REGISTERED_CLASSES:
        return bool(
            len(_REGISTERED_CLASSES) == 1
            and len(_UI_CLASS_RECORDS) == 1
            and _UI_CLASS_RECORDS[0].get('class') is _REGISTERED_CLASSES[0]
            and _UI_CLASS_RECORDS[0].get('token') is _UI_OWNER_TOKEN
            and _UI_CLASS_RECORDS[0].get('generation') == _UI_GENERATION
            and _ui_class_owned_rna(_REGISTERED_CLASSES[0])
        )
    operator_id = _OPERATOR_ID
    if _operator_id_owned_elsewhere(operator_id):
        _LAST_RESOURCE_ERROR = f'foreign operator owner: {operator_id}'
        return False

    class SMARTTOOLS_OT_always_on_toggle_feature(bpy.types.Operator):
        bl_label = 'Toggle Always-on Feature'
        bl_idname = operator_id
        bl_label = 'Toggle Always-on Feature'
        bl_description = 'Switch an always-on feature on or off and persist it through N-panel State Save.'

        alias: bpy.props.StringProperty(default='')
        feature_key: bpy.props.StringProperty(default='')
        enabled: bpy.props.BoolProperty(default=True)

        bl_options = {'INTERNAL'}
        _sms_no_undo = True
        @classmethod
        def description(cls, context, properties):
            return _operator_description(context, properties)

        def execute(self, context):
            alias = str(getattr(self, 'alias', '') or '')
            feature_key = str(getattr(self, 'feature_key', '') or '')
            desired = bool(getattr(self, 'enabled', True))
            if not set_feature_enabled(alias, feature_key, desired):
                self.report({'WARNING'}, _t(context, 'The selected feature could not be changed.', '選択した機能を変更できませんでした。'))
                return {'CANCELLED'}
            self.report({'INFO'}, _t(context, 'Feature setting saved.', '機能設定を保存しました。'))
            return {'FINISHED'}

    SMARTTOOLS_OT_always_on_toggle_feature.__name__ = f"SMARTTOOLS_OT_{_SUITE_KEY.upper()}_TOGGLE_PERSISTENT_FEATURE"
    SMARTTOOLS_OT_always_on_toggle_feature.__qualname__ = SMARTTOOLS_OT_always_on_toggle_feature.__name__
    SMARTTOOLS_OT_always_on_toggle_feature.__module__ = __name__
    if not _ui_prepare_owner():
        _LAST_RESOURCE_ERROR = 'feature-toggle owner ledger is unavailable'
        return False
    try:
        bpy.utils.register_class(SMARTTOOLS_OT_always_on_toggle_feature)
    except Exception as exc:
        _LAST_RESOURCE_ERROR = f'{type(exc).__name__}: {exc}'[:1024]
        return False
    if not _ui_class_owned_rna(SMARTTOOLS_OT_always_on_toggle_feature):
        try:
            bpy.utils.unregister_class(SMARTTOOLS_OT_always_on_toggle_feature)
        except Exception:
            pass
        _LAST_RESOURCE_ERROR = 'feature-toggle Operator class-owned RNA validation failed'
        return False
    rna = vars(SMARTTOOLS_OT_always_on_toggle_feature).get('bl_rna')
    _REGISTERED_CLASSES.append(SMARTTOOLS_OT_always_on_toggle_feature)
    _UI_CLASS_RECORDS.append({
        'class': SMARTTOOLS_OT_always_on_toggle_feature,
        'rna': rna,
        'acquired': True,
        'token': _UI_OWNER_TOKEN,
        'generation': _UI_GENERATION,
    })
    _LAST_RESOURCE_ERROR = ''
    return True


def _draw_feature_toggle_rows(layout, context, entries: list[dict[str, Any]], *, compact: bool = True, include_tool_label: bool = False) -> bool:
    try:
        col = layout.column(align=True)
        for item in entries:
            enabled = bool(item.get('enabled'))
            feature_key = str(item.get('key') or '')
            label = _t(context, str(item.get('label_en') or feature_key), str(item.get('label_ja') or feature_key))
            if include_tool_label:
                tool_label = str(item.get('tool_label') or item.get('alias') or '').strip()
                if tool_label:
                    label = f'{tool_label}: {label}'
            row = col.row(align=True)
            try:
                row.scale_y = 0.95
            except Exception:
                pass
            split = row.split(factor=0.72, align=True)
            left = split.row(align=True)
            try:
                left.alignment = 'LEFT'
            except Exception:
                pass
            left.label(text=label)
            right = split.row(align=True)
            try:
                right.alignment = 'RIGHT'
                right.use_property_split = False
                right.use_property_decorate = False
            except Exception:
                pass
            op = right.row(align=True).operator(
                _OPERATOR_ID,
                text=_t(context, 'On', '有効') if enabled else _t(context, 'Off', '無効'),
                icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
                depress=enabled,
                emboss=True,
            )
            op.alias = str(item.get('alias') or '')
            op.feature_key = feature_key
            try:
                op.enabled = not enabled
            except Exception:
                pass
            if not compact:
                desc = _t(context, str(item.get('description_en') or ''), str(item.get('description_ja') or ''))
                if desc:
                    col.label(text=desc[:240])
        return True
    except Exception:
        return False


def draw_inline_toggles(layout, context, alias: str, *, compact: bool = True) -> bool:
    """Draw feature toggles using the standardized Smart toolset layout."""
    alias = str(alias or '').strip()
    entries = feature_entries(alias)
    if not entries:
        return False
    return _draw_feature_toggle_rows(layout, context, entries, compact=compact, include_tool_label=False)


def draw_all_toggles(layout, context, *, compact: bool = True, show_empty: bool = False) -> bool:
    """Draw all captured always-on runtime hooks in the main Always-on group."""
    entries: list[dict[str, Any]] = []
    try:
        for alias in all_feature_aliases():
            entries.extend(feature_entries(alias))
    except Exception:
        entries = []
    if not entries:
        if show_empty:
            try:
                row = layout.row(align=True)
                row.enabled = False
                row.label(text=_t(context, 'No captured runtime-hook feature is currently available.', '現在利用できる実行時フック機能はありません。'))
            except Exception:
                pass
        return False
    entries.sort(key=lambda item: (str(item.get('tool_label') or ''), str(item.get('key') or '')))
    return _draw_feature_toggle_rows(layout, context, entries, compact=compact, include_tool_label=True)


def runtime_status() -> dict[str, Any]:
    active_actions = 0
    total_actions = 0
    for feature_map in _FEATURES.values():
        for feature in feature_map.values():
            for action in feature.get('actions') or ():
                total_actions += 1
                if bool(action.get('active')):
                    active_actions += 1
    ledger = _ui_namespace().get(_UI_OWNER_KEY) if _ui_namespace() is not None else None
    return {
        'owner_exact': bool(isinstance(ledger, dict) and ledger.get('token') is _UI_OWNER_TOKEN and ledger.get('generation') == _UI_GENERATION),
        'action_count': total_actions,
        'active_action_count': active_actions,
        'max_actions_per_feature': _MAX_ACTIONS_PER_FEATURE,
        'global_snapshot_capture': False,
        'process_global_monkeypatch': False,
        'last_error': _LAST_RESOURCE_ERROR,
    }


def unregister_ui() -> None:
    _ui_cleanup_generation(_UI_OWNER_TOKEN, _UI_GENERATION)


def unregister_all() -> None:
    for alias in list(_FEATURES.keys()):
        deactivate_alias(alias)
    unregister_ui()
    _FEATURES.clear()


def _safe_safe_set_kmi_property_v60(kmi, prop_name, value) -> bool:
    try:
        props = getattr(kmi, 'properties', None)
        rna = getattr(props, 'bl_rna', None)
        prop_map = getattr(rna, 'properties', None)
        has_prop = False
        try:
            has_prop = str(prop_name) in set(prop_map.keys())
        except Exception:
            try:
                has_prop = prop_map.get(str(prop_name)) is not None
            except Exception:
                has_prop = hasattr(props, str(prop_name))
        if not has_prop:
            return False
        setattr(props, str(prop_name), value)
        return True
    except Exception:
        return False
