# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Exact-identity compatibility fallbacks for Smart File Suite 5.75.54.

This module deliberately does *not* monkey-patch process-global Blender APIs,
Python import machinery, foreign classes, keymaps, handlers, draw functions, or
poll functions.  It owns only the three known fallback Operator classes below.
Every acquired RNA class is recorded by exact Python identity and generation and
is removed only by the generation that acquired it.
"""
from __future__ import annotations

import uuid
from typing import Any, Mapping

import bpy

from .operator_policy import prepare_operator_class as _prepare_operator_class

_OWNER_KEY = "JELararagi.smart_file.compatibility_guards.lifecycle.v57540"
_LEGACY_OWNER_KEYS = (
    "JELararagi.smart_file.compatibility_guards.lifecycle.v57539",
    "JELararagi.smart_file.compatibility_guards.lifecycle.v57536",
    "JELararagi.smart_file.compatibility_guards.lifecycle.v57535",
    "JELararagi.smart_file.compatibility_guards.lifecycle.v57534",
    "JELararagi.smart_file.compatibility_guards.lifecycle.v57533",
)
_OWNER_TOKEN = object()
_OWNER_GENERATION = uuid.uuid4().hex
_CLASS_RECORDS: list[dict[str, Any]] = []
_COMPAT_ACTIVE = False
_LAST_ERROR = ""


def _namespace() -> dict | None:
    try:
        value = getattr(getattr(bpy, "app", None), "driver_namespace", None)
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _class_owned_rna(cls: type) -> bool:
    """Require RNA attached to this class itself, never an inherited base RNA."""
    try:
        if not isinstance(cls, type):
            return False
        rna = vars(cls).get("bl_rna")
        return bool(rna is not None and str(getattr(rna, "identifier", "") or "").strip())
    except Exception:
        return False


def _is_japanese_ui() -> bool:
    try:
        prefs = getattr(getattr(bpy.context, "preferences", None), "view", None)
        if prefs is not None and not bool(getattr(prefs, "use_translate_interface", True)):
            return False
        locale = str(getattr(getattr(bpy.app, "translations", None), "locale", "") or "")
        if not locale and prefs is not None:
            locale = str(getattr(prefs, "language", "") or "")
        return locale.lower().startswith("ja")
    except Exception:
        return False


def _ui_text(en: str, ja: str) -> str:
    return ja if _is_japanese_ui() else en


def _operator_exists(bl_idname: str) -> bool:
    text = str(bl_idname or "").strip()
    if "." not in text:
        return False
    prefix, suffix = text.split(".", 1)
    try:
        # bpy.ops.<prefix>.<name> は未登録でも呼び出し可能な物を返すので、RNA 型を引いて判定する
        namespace = getattr(bpy.ops, prefix, None)
        if namespace is None:
            return False
        getattr(namespace, suffix).get_rna_type()
        return True
    except Exception:
        return False


class UV_OT_compatibility_texel_density_tools(bpy.types.Operator):
    bl_idname = 'uv.sfs_compatibility_texel_density_tools'
    bl_label = 'Texel Density Tools'
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return _ui_text(
            "Compatibility fallback used when Smart UV asks for its texel density operator before the real tool has registered. It prevents repeated unknown-operator console warnings; install or enable the texel density module to use the real operation.",
            "Smart UV が実体のテクセル密度オペレーター登録前に呼び出した場合の互換フォールバックです。unknown operator 警告の連続表示を防ぎます。実際の処理を使うにはテクセル密度モジュールをインストールまたは有効化してください。",
        )

    def execute(self, context):
        try:
            self.report({'INFO'}, _ui_text(
                "Texel Density Tools are not available in the current Smart UV registration.",
                "現在の Smart UV 登録状態では、テクセル密度ツールを使用できません。",
            ))
        except Exception:
            pass
        return {'CANCELLED'}


class EXTENSIONS_OT_compatibility_install_extension_dependency(bpy.types.Operator):
    bl_idname = 'extensions.sfs_compatibility_install_extension_dependency'
    bl_label = 'Install Extension Dependency'
    bl_options = {'UNDO'}

    pkg_id: bpy.props.StringProperty(name="Package ID", default="")
    repo_index: bpy.props.IntProperty(name="Repository Index", default=0)

    @classmethod
    def description(cls, context, properties):
        return _ui_text(
            "Compatibility fallback used when Universal Multi Importer shows an extension install button but Blender has no matching extension-install operator registered. It prevents unknown-operator UI warnings and reports the missing dependency safely.",
            "Universal Multi Importer が拡張機能インストールボタンを表示している一方で、Blender側に対応オペレーターが登録されていない場合の互換フォールバックです。unknown operator 警告を防ぎ、不足依存関係を安全に通知します。",
        )

    def execute(self, context):
        try:
            self.report({'INFO'}, _ui_text(
                "The requested extension dependency cannot be installed automatically in the current Blender extension state.",
                "現在のBlender拡張機能の状態では、要求された依存拡張機能を自動インストールできません。",
            ))
        except Exception:
            pass
        return {'CANCELLED'}


class EXTENSIONS_OT_compatibility_allow_online_access(bpy.types.Operator):
    bl_idname = 'extensions.sfs_compatibility_allow_online_access'
    bl_label = 'Allow Online Access'
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return _ui_text(
            "Compatibility fallback used when Blender's extension online-access operator is unavailable. It prevents unknown-operator UI warnings; enable online access from Blender Preferences if required.",
            "Blender側のオンラインアクセス許可オペレーターが未登録の場合の互換フォールバックです。unknown operator 警告を防ぎます。必要な場合はBlenderプリファレンスからオンラインアクセスを有効にしてください。",
        )

    def execute(self, context):
        try:
            prefs = getattr(getattr(context, 'preferences', None), 'system', None)
            if prefs is not None and hasattr(prefs, 'use_online_access'):
                setattr(prefs, 'use_online_access', True)
                self.report({'INFO'}, _ui_text("Online access was enabled.", "オンラインアクセスを有効にしました。"))
                return {'FINISHED'}
        except Exception:
            pass
        try:
            self.report({'INFO'}, _ui_text(
                "Open Blender Preferences and enable online access manually if extension downloads are required.",
                "拡張機能のダウンロードが必要な場合は、Blenderプリファレンスでオンラインアクセスを手動で有効にしてください。",
            ))
        except Exception:
            pass
        return {'CANCELLED'}


class _SFSPanelDrawProxy:
    """Compatibility-only data proxy retained for internal API stability."""
    def __init__(self, source, layout):
        self._sfs_source = source
        self.layout = layout

    def __getattr__(self, name):
        return getattr(self._sfs_source, name)


def _record_class(cls: type, *, acquired: bool) -> None:
    if any(record.get("class") is cls for record in _CLASS_RECORDS):
        return
    _CLASS_RECORDS.append({
        "class": cls,
        "acquired": bool(acquired),
        "token": _OWNER_TOKEN,
        "generation": _OWNER_GENERATION,
        "rna_identifier": str(getattr(vars(cls).get("bl_rna"), "identifier", "") or ""),
    })


def _register_owned_class(cls: type) -> bool:
    cls = _prepare_operator_class(cls)
    if _class_owned_rna(cls):
        _record_class(cls, acquired=False)
        return True
    bpy.utils.register_class(cls)
    if not _class_owned_rna(cls):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        raise RuntimeError(f"class-owned RNA validation failed: {cls.__name__}")
    _record_class(cls, acquired=True)
    return True


def _unregister_record(record: Mapping[str, Any]) -> bool:
    cls = record.get("class")
    if not isinstance(cls, type) or not bool(record.get("acquired")):
        return True
    if record.get("token") is not _OWNER_TOKEN or record.get("generation") != _OWNER_GENERATION:
        return False
    if not _class_owned_rna(cls):
        return True
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        return False
    return not _class_owned_rna(cls)


def _cleanup_generation() -> bool:
    global _COMPAT_ACTIVE
    ok = True
    for record in reversed(tuple(_CLASS_RECORDS)):
        if not _unregister_record(record):
            ok = False
    _CLASS_RECORDS.clear()
    _COMPAT_ACTIVE = False
    return ok


def _cleanup_external_owner(owner: Mapping[str, Any]) -> bool:
    cleanup = owner.get("cleanup") if isinstance(owner, Mapping) else None
    if not callable(cleanup):
        return False
    try:
        return bool(cleanup())
    except Exception:
        return False


def _install_owner() -> bool:
    namespace = _namespace()
    if namespace is None:
        return False
    for key in _LEGACY_OWNER_KEYS:
        legacy = namespace.get(key)
        if isinstance(legacy, Mapping):
            _cleanup_external_owner(legacy)
        namespace.pop(key, None)
    existing = namespace.get(_OWNER_KEY)
    if isinstance(existing, Mapping) and not (
        existing.get("token") is _OWNER_TOKEN
        and existing.get("generation") == _OWNER_GENERATION
    ):
        if not _cleanup_external_owner(existing):
            return False
    namespace[_OWNER_KEY] = {
        "schema": 1,
        "token": _OWNER_TOKEN,
        "generation": _OWNER_GENERATION,
        "classes": _CLASS_RECORDS,
        "cleanup": _cleanup_generation,
    }
    return True


def patch_loaded_modules() -> int:
    """Compatibility no-op: foreign modules and classes are never modified."""
    return 0


def early_sanitize_environment() -> None:
    return None


def register() -> bool:
    global _COMPAT_ACTIVE, _LAST_ERROR
    if _COMPAT_ACTIVE and runtime_status().get("exact"):
        return True
    _LAST_ERROR = ""
    if not _install_owner():
        _LAST_ERROR = "compatibility owner ledger unavailable"
        return False
    try:
        for cls, bl_idname in (
            (UV_OT_compatibility_texel_density_tools, "uv.sfs_compatibility_texel_density_tools"),
            (EXTENSIONS_OT_compatibility_install_extension_dependency, "extensions.sfs_compatibility_install_extension_dependency"),
            (EXTENSIONS_OT_compatibility_allow_online_access, "extensions.sfs_compatibility_allow_online_access"),
        ):
            if not _operator_exists(bl_idname):
                _register_owned_class(cls)
        _COMPAT_ACTIVE = True
        if not runtime_status().get("exact"):
            raise RuntimeError("compatibility exact-identity validation failed")
        return True
    except Exception as exc:
        _LAST_ERROR = f"{type(exc).__name__}: {exc}"
        _cleanup_generation()
        return False


def unregister() -> bool:
    global _LAST_ERROR
    ok = _cleanup_generation()
    namespace = _namespace()
    if namespace is not None:
        owner = namespace.get(_OWNER_KEY)
        if isinstance(owner, Mapping) and owner.get("token") is _OWNER_TOKEN:
            namespace.pop(_OWNER_KEY, None)
    if not ok:
        _LAST_ERROR = "one or more owned compatibility classes could not be removed"
    return ok


def runtime_status() -> dict[str, Any]:
    namespace = _namespace()
    owner = namespace.get(_OWNER_KEY) if namespace is not None else None
    owner_exact = bool(
        isinstance(owner, Mapping)
        and owner.get("token") is _OWNER_TOKEN
        and owner.get("generation") == _OWNER_GENERATION
        and owner.get("classes") is _CLASS_RECORDS
    )
    class_records_exact = all(
        record.get("class") in (
            UV_OT_compatibility_texel_density_tools,
            EXTENSIONS_OT_compatibility_install_extension_dependency,
            EXTENSIONS_OT_compatibility_allow_online_access,
        )
        and record.get("token") is _OWNER_TOKEN
        and record.get("generation") == _OWNER_GENERATION
        and (not record.get("acquired") or _class_owned_rna(record.get("class")))
        for record in _CLASS_RECORDS
    )
    exact = bool(_COMPAT_ACTIVE and owner_exact and class_records_exact and not _LAST_ERROR)
    return {
        "active": bool(_COMPAT_ACTIVE),
        "exact": exact,
        "generation": _OWNER_GENERATION,
        "owner_exact": owner_exact,
        "class_record_count": len(_CLASS_RECORDS),
        "handler_count": 0,
        "timer_count": 0,
        "msgbus_count": 0,
        "worker_count": 0,
        "foreign_mutation_count": 0,
        "last_error": _LAST_ERROR,
    }
