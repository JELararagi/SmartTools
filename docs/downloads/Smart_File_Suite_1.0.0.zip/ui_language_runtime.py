# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import re
import sys
from functools import lru_cache
from typing import Iterable

try:
    import bpy
except Exception:  # pragma: no cover - Blender provides bpy at runtime.
    bpy = None

try:
    from .translation_exact import _SF_EXACT_LABEL_TRANSLATIONS as _EXACT_TRANSLATIONS
except Exception:  # pragma: no cover
    _EXACT_TRANSLATIONS = {}

try:
    from .translation_phrases import _SF_PHRASE_TRANSLATIONS as _PHRASE_TRANSLATIONS
except Exception:  # pragma: no cover
    _PHRASE_TRANSLATIONS = ()

# Explicit reviewed do-not-translate allowlist (PR-FILE-03).  Workflow Spec
# v3.11.2 SS21.2 permits product names, file extensions and API identifiers to
# stay unchanged "only through one explicit reviewed allowlist"; this is that
# list for Smart File.  Sources are compared case-insensitively, so one entry
# covers "max", "Max" and "MAX".  Add a token here rather than only deleting a
# phrase pair: _strip_protected_phrase_pairs() runs after every phrase-table
# merge below, so a later localization pass cannot reintroduce a translation.
DO_NOT_TRANSLATE_TOKENS = frozenset({
    'max',  # 3ds Max import context and the .max format token, never '最大'.
})


def _strip_protected_phrase_pairs(pairs):
    """Drop phrase pairs whose source is an allowlisted do-not-translate token."""
    try:
        return tuple(
            pair for pair in (pairs or ())
            if str(pair[0] or '').strip().casefold() not in DO_NOT_TRANSLATE_TOKENS
        )
    except Exception:
        return tuple(pairs or ())

_JA_RE = re.compile(r'[ぁ-んァ-ン一-龯々ー]')
_ASCII_RE = re.compile(r'[A-Za-z]')
# A word-by-word phrase replacement that leaves English words behind reads worse
# than the plain source text, so to_japanese() keeps the source in that case.
_ENGLISH_WORD_RE = re.compile(r'(?<![A-Za-z0-9_.])[A-Za-z]?[a-z]{2,}(?![A-Za-z0-9_])')
_SPACE_RE = re.compile(r'\s+')
_TRANSLATION_CONTEXTS = ('*', 'Operator', 'Property', 'UI', 'Tooltip', 'Addon', 'Panel', 'Menu')

_EXTRA_EXACT_TRANSLATIONS = {
    'Autodesk 3D Studio (.3ds)': 'Autodesk 3D Studio（.3ds）',
    'Import and export Autodesk 3D Studio (.3ds) files': 'Autodesk 3D Studio（.3ds）ファイルをインポート・エクスポートします',
    'Bulk Asset Tools': '一括アセットツール',
    'A set of tools for managing multiple assets at the same time': '複数のアセットを同時に管理するためのツール群です',
    'Decentraland Tools': 'Decentraland ツール',
    'Collection of tools for Decentraland asset creation and optimization (Blender 2.80 - 5.0+)': 'Decentraland アセットの作成と最適化を行うツール群です（Blender 2.80 - 5.0+）',
    'Export AutoCAD DXF Format (.dxf)': 'AutoCAD DXF 形式（.dxf）を書き出し',
    'Export AutoCAD DXF (.dxf) files': 'AutoCAD DXF（.dxf）ファイルを書き出します',
    'Import AutoCAD DXF Format (.dxf)': 'AutoCAD DXF 形式（.dxf）を読み込み',
    'Import AutoCAD DXF (.dxf) files': 'AutoCAD DXF（.dxf）ファイルを読み込みます',
    'History Snapshot Protection': '履歴スナップショット保護',
    'Modern history logging, timed restore snapshots, confirm-before-restore, selection-first restore, snapshot-only list, and rolling autosave for Blender 5.x': 'Blender 5.x 向けの履歴ログ、定時復元スナップショット、復元前確認、選択優先復元、スナップショット専用一覧、世代管理自動保存を提供します',
    'IKEA Browser': 'IKEA ブラウザー',
    'Browse IKEA products, preview thumbnails, and import supported models into the current scene': 'IKEA 製品を閲覧し、サムネイルを確認して、対応モデルを現在のシーンへ読み込みます',
    'Import Autodesk MAX (.max)': 'Autodesk MAX（.max）を読み込み',
    'Import Autodesk MAX (.max) files': 'Autodesk MAX（.max）ファイルを読み込みます',
    'Import MAX (.max)': 'MAX（.max）をインポート',
    'MAX (.max)': 'MAX（.max）',
    'max': 'max',  # 3ds Max/.max format token; never translate to 最大.
    'MAX': 'MAX',  # 3ds Max format acronym; never translate to 最大.
    '.max': '.max',  # 3ds Max filename extension; never translate to .最大.
    '*.max': '*.max',  # 3ds Max file filter token; never translate to *.最大.
    'Object Reporter': 'オブジェクトレポーター',
    'Set Origin': '原点を設定',
    'Add Prop': 'プロップを追加',
    'Import Product': '製品をインポート',
    'Search Products': '製品を検索',
    'Import (Legacy)': 'インポート（レガシー）',
    'Export (Legacy)': 'エクスポート（レガシー）',
    'Install Extension': '拡張機能をインストール',
    'Import All': 'すべて読み込み',
    'Import Blend': 'Blend を読み込み',
    'Check MD5': 'MD5 を確認',
    'Remove Library': 'ライブラリを削除',
    'Select File': 'ファイルを選択',
    'Toggle Group': 'グループを切り替え',
    'Select Node': 'ノードを選択',
    'Clear Marking': 'マークをクリア',
    'Remove Specular': 'スペキュラーを削除',
    'Export Scene': 'シーンをエクスポート',
    'Add _collider Suffix': 'コライダーの接尾辞を追加',
    'Add Summary Field': '集計フィールドを追加',
    'Add Preset Field': 'プリセットにフィールドを追加',
    'Remove Condition': '条件を削除',
    'Remove Summary Field': '集計フィールドを削除',
    'Remove Preset Field': 'プリセットからフィールドを削除',
    'Select Matching': '一致する物を選択',
    'Select Listed Object': '一覧のオブジェクトを選択',
    'Pick Condition Value': '条件の値を選択',
    'Pick Property Value': 'プロパティの値を選択',
    'Pick Preset Value': 'プリセットの値を選択',
    'Field Name': 'フィールド名',
    'Default Value': '既定値',
    'Preset Name': 'プリセット名',
    'Property': 'プロパティ',
    'Match': '一致',
    'Value': '値',
    'Logic': '論理',
    'Field': 'フィールド',
    'Show': '表示',
    'Sum': '合計',
    'Sigma: sum numeric values in grouped rows; non-numeric shows unanimous value or (multiple)': 'Σ：グループ化した行の数値を合計します。数値でない物は、共通の値か (multiple) を出します',
    'Visible Only': '表示中のみ',
    'Selected Only': '選択中のみ',
    'Tagged Only': 'タグ付きのみ',
    'Only include objects that have at least one custom property': 'カスタムプロパティを 1 つ以上持つオブジェクトだけを含めます',
    'Internal Props': '内部プロパティ',
    'Object Name': 'オブジェクト名',
    'Dimensions': '寸法',
    'Face Area': '面積',
    'Volume': '体積',
    'Area per Material': 'マテリアル別面積',
    'Sum face area across grouped rows': 'グループ化した行の面積を合計します',
    'Sum volume across grouped rows': 'グループ化した行の体積を合計します',
    'Precision': '精度',
    'Number of decimal places used in all numeric outputs': 'すべての数値の出力で使う小数の桁数です',
    'Group Rows': '行をグループ化',
    'Group by': 'グループの基準',
    'Show All / Any': 'すべて・いずれか',
    'Font Size': '文字の大きさ',
    'Offset X': 'オフセット X',
    'Offset Y': 'オフセット Y',
    'Export Path': '書き出し先',
    'Use Grouping': 'グループ化を使う',
    '(none)': '（なし）',
    'contains': '含む',
    'is empty': '空',
    'is not empty': '空でない',
    'Add Condition': '条件を追加',
    'Clear All': 'すべてクリア',
    'Deselect all, then select matching objects': 'すべての選択を解除してから、条件に一致するオブジェクトを選択します',
    'Add to Selection': '選択に追加',
    'Add matching objects to current selection': '条件に一致するオブジェクトを今の選択に足します',
    'Isolate': '隔離表示',
    'Isolate Matches': '隔離表示',
    'Hide non-matching objects and select matches': '一致しないオブジェクトを隠し、一致する物を選択します',
    'Show All': 'すべて表示',
    'Pick Property': 'プロパティを選択',
    'Show All Objects': 'すべてのオブジェクトを表示',
    '(set property first)': '（先にプロパティを選んでください）',
    'IF': '条件',
    'Precision:': '精度:',
    'Computed geometry:': '計算するジオメトリ:',
    'Custom properties:': 'カスタムプロパティ:',
    'Pick Field': 'フィールドを選択',
    'Recompute the summary table (evaluates geometry if needed)': '集計表を計算し直します（必要ならジオメトリを評価します）',
    'Export CSV': 'CSV を書き出し',
    'Group by:': 'グループの基準:',
    'Choose field…': 'フィールドを選択…',
    'Refresh  ●  data changed': '更新  ●  データが変わりました',
    'Press Refresh to load.': '「更新」を押すと読み込みます。',
    'Count': '数',
    'Σ Face Area': 'Σ 面積',
    'Σ Volume': 'Σ 体積',
    'Total': '合計',
    'Press Refresh to update view.': '「更新」を押すと表示を更新します。',
    'Enable Grouping panel first': '先にグループ化を有効にしてください',
    'Mat. Area': 'マテリアル面積',
    'Set Property': 'プロパティを設定',
    'Remove Property': 'プロパティを削除',
    'Add Preset': 'プリセットを追加',
    'Remove Preset': 'プリセットを削除',
    'Apply (keep existing)': '既存値を保持して適用',
    'Apply & Overwrite': '適用して上書き',
    'Add as Filter': 'フィルターとして追加',
    'Add to Fields': 'フィールドに追加',
    'Apply to Selected Objects:': '選択オブジェクトに適用:',
    'No presets.': 'プリセットはありません。',
    'No mesh objects selected.': 'メッシュオブジェクトが選択されていません。',
    '(set field name first)': '（先にフィールド名を入れてください）',
    'No custom properties found.': 'カスタムプロパティは見つかりませんでした。',
    'No shared properties. Switch to Any.': '共通のプロパティはありません。「いずれか」に切り替えてください。',
    'Add Color Preset': 'カラープリセットを追加',
    'Edit Preset': 'プリセットを編集',
    'Import Dropped Files': 'ドロップしたファイルを読み込み',
    'Load Preset List': 'プリセット一覧を読み込み',
    'Metadata presets, select by properties, viewport labels, summary table, CSV export': 'メタデータプリセット、プロパティ選択、ビューポートラベル、集計表、CSV 書き出しを行います',
    'STL format (legacy)': 'STL 形式（レガシー）',
    'Import-Export STL files': 'STL ファイルをインポート・エクスポートします',
    'Texture File Path Editor': 'テクスチャファイルパスエディター',
    'Manage, relink, gather and inspect all texture paths in one panel': 'すべてのテクスチャパスを 1 つのパネルで管理、再リンク、収集、確認します',
    'Universal Multi Importer': 'ユニバーサル複数インポーター',
    'Batch Import many file formats at once, Batch process them': '多数のファイル形式を一括インポートし、まとめて処理します',
    'VAT': 'VAT',
    'A tool for storing per frame vertex data for use in a vertex shader.': '頂点シェーダーで使うフレームごとの頂点データを保存するツールです。',
    'Quick Note / Checkpoint Name': 'クイックメモ / チェックポイント名',
    'Append or Link Blend file': 'Blendファイルをアペンドまたはリンクします',
    'Coordinates are assumed to be in meters; deviation must be indicated here': '座標はメートル単位として扱われます。ずれがある場合はここで指定してください',
    'Edit current preset': '現在のプリセットを編集します',
    'Engine used for thumbnail rendering': 'サムネイルのレンダリングに使用するエンジンです',
    'First frame of the emote clip': 'エモートクリップの最初のフレームです',
    'Indication for spherical or euclidean coordinates': '球面座標またはユークリッド座標の指定です',
    'Insert keyframes for deform bones on first/last emote frames to avoid overrides': '上書きを避けるため、エモートの最初/最後のフレームに変形ボーンのキーフレームを挿入します',
    'Number of decimal places used in all numeric outputs': 'すべての数値出力で使用する小数点以下の桁数です',
    'Number of parcels in X direction': 'X方向の区画数です',
    'Number of parcels in Y direction': 'Y方向の区画数です',
    'Project coordinates to a given coordinate system or reference point': '指定した座標系または参照点へ座標を投影します',
}
try:
    if isinstance(_EXACT_TRANSLATIONS, dict):
        _EXACT_TRANSLATIONS = dict(_EXACT_TRANSLATIONS)
        _EXACT_TRANSLATIONS.update(_EXTRA_EXACT_TRANSLATIONS)
except Exception:
    pass

_MORE_EXACT_TRANSLATIONS = {'User Interface': 'ユーザーインターフェイス',
 'Smart File': 'Smart File',
 'Menu': 'メニュー',
 'Items': '項目',
 'Higher priority roots win when merging catalogs (larger number = higher priority)': 'カタログをマージするときは優先度が高いルートが採用されます（数値が大きいほど優先度が高くなります）',
 'Alias': '別名',
 'Environment Variable': '環境変数',
 'Kind': '種類',
 'Optional external-file category this root should specialize in.': 'このルートを特定の外部ファイルカテゴリに優先的に使いたい場合に指定します。',
 'Higher values win when multiple roots can resolve the same suffix.': '同じ接尾辞を複数のルートで解決できる場合、値が大きいルートが優先されます。',
 'Notes': 'メモ',
 'Entry Identity': '項目識別子',
 'Draft Category': '下書きカテゴリ',
 'Node Key': 'ノードキー',
 'Parent Key': '親キー',
 'Has Meta Option': 'メタ情報オプションあり',
 'Has Category Option': 'カテゴリオプションあり',
 'Has Tags Option': 'タグオプションあり',
 'Pinned': '固定',
 'Home density': 'ホーム密度',
 'Control whether launcher, cockpit, and goal-home popups prioritize readability or information density': 'ランチャー、コックピット、ゴールホームのポップアップで、読みやすさと情報量のどちらを優先するかを設定します',
 'Active Profile': 'アクティブプロファイル',
 'Creates real .blend restore points at a fixed minute interval. These files are the safest rollback points when you want to return to an older stable state after risky work.': '指定した分間隔で実際の '
                                                                                                                                                                                 '.blend '
                                                                                                                                                                                 '復元ポイントを作成します。リスクのある作業後に以前の安定状態へ戻したい場合の安全なロールバック地点になります。',
 'Restore Snapshot Interval (Minutes)': '復元スナップショット間隔（分）',
 'Enable Optional Timed Restore Points': '任意の定期復元ポイントを有効化',
 'Enable Optional Timed Restore': '任意の定期復元を有効化',
 'Optional Timed Restore Points': '任意の定期復元ポイント',
 'Timed Restore Point Interval (Minutes)': '定期復元ポイント間隔（分）',
 'Timed Restore Point Max Files': '復元ポイント最大保持数',
 'Skip Unchanged Autosaves': '未変更の自動保存をスキップ',
 'Maximum number of restore-point files kept for the current project. When the limit is exceeded, the oldest restore-point files are deleted first.': '現在のプロジェクトで保持する復元ポイントファイルの最大数です。上限を超えると、古い復元ポイントから削除されます。',
 'Restore On Double Click': 'ダブルクリックで復元',
 'Background Poll Interval (Seconds)': 'バックグラウンド確認間隔（秒）',
 'How often the automatic history runtime checks for new changes. Smaller numbers feel more responsive, while larger numbers slightly reduce background overhead. One second is a good default in most cases.': '履歴バックグラウンド処理が変更を確認する頻度です。小さい値ほど反応が速くなり、大きい値ほど負荷が少し下がります。通常は1秒が扱いやすい初期値です。',
 'Infer metadata sidecars': 'メタデータサイドカーを推定',
 'Preset scope': 'プリセット範囲',
 'Thumbnail render resolution in pixels': 'サムネイルのレンダリング解像度をピクセル単位で指定します',
 'Default Publish Subfolder': '既定の公開サブフォルダ',
 'External Files': '外部ファイル',
 'External Files Subfolder': '外部ファイル用サブフォルダ',
 'Default Category': '既定カテゴリ',
 'Default category used for catalog entries': 'カタログ項目に使用する既定カテゴリです',
 'Asset ID Scheme': 'アセットID方式',
 'Asset ID Prefix': 'アセットIDプレフィックス',
 'Optional project key/prefix used by some Asset ID schemes (e.g. PRJ001)': '一部のアセットID方式で使用する任意のプロジェクトキーまたはプレフィックスです（例: PRJ001）',
 'Reference mtime cache': '参照更新日時キャッシュ',
 'Internal cache for linked library file modification times (JSON)': 'リンクライブラリファイルの更新日時を保存する内部キャッシュです（JSON）',
 'Popup on updates': '更新時にポップアップ',
 'Candidate priority': '候補優先度',
 'Scoring preset': 'スコアリングプリセット',
 'Quick preset for candidate scoring weights and strategy': '候補スコアの重みと戦略をすばやく切り替えるプリセットです',
 'Weight: Exists': '重み: 存在確認',
 'Scoring weight for whether the candidate file exists': '候補ファイルが存在するかどうかに対するスコア重みです',
 'Weight: Source': '重み: ソース',
 'Weight: Root priority': '重み: ルート優先度',
 'Scoring weight for catalog root priority (higher-priority roots score higher)': 'カタログルート優先度に対するスコア重みです（優先度が高いルートほど高得点になります）',
 'Catalog conflict overrides': 'カタログ競合オーバーライド',
 'Internal per-asset preferred source catalog mapping (JSON)': 'アセットごとの優先ソースカタログ対応を保存する内部データです（JSON）',
 'Internal developer helper for translation diagnostics': '翻訳診断用の内部開発者向け補助機能です',
 'Sort alphabetically': 'アルファベット順に並べ替え',
 'Library Diagnostics': 'ライブラリ診断',
 'Newer': '新しい',
 'Abs Paths': '絶対パス',
 'Thumb': 'サムネイル',
 'Group Key': 'グループキー',
 'Candidates JSON': '候補JSON',
 'Preferred Catalog': '優先カタログ',
 'Entries JSON': '項目JSON',
 'Published': '公開済み',
 'List Limit': '一覧上限',
 'Sort by priority': '優先度順に並べ替え',
 'Analyze File': 'ファイルを分析',
 'Reload Catalog': 'カタログを再読み込み',
 'Reload the active catalog.json file and rebuild the catalog-based asset list': '現在の catalog.json ファイルを再読み込みし、カタログベースのアセット一覧を再構築します',
 'Remember which source entry should be preferred for the active catalog asset when multiple versions exist': '複数バージョンがある場合に、現在のカタログアセットで優先するソース項目を記憶します',
 'List untranslated UI strings in the system console so localization gaps can be fixed': '未翻訳のUI文字列をシステムコンソールに一覧表示し、ローカライズ漏れを修正しやすくします',
 'Smart File': 'Smart File',
 'Store the current linked-library timestamps so already reviewed updates stop showing as new': '現在のリンクライブラリ更新日時を保存し、確認済みの更新が新規として表示され続けないようにします',
 'Reload every linked library in the current file from disk': '現在のファイル内のすべてのリンクライブラリをディスクから再読み込みします',
 'Rebuild the current review plan so it reflects the latest candidate analysis and selections': '最新の候補分析と選択状態を反映するように、現在のレビュープランを再構築します',
 'Resync Overrides': 'オーバーライドを再同期',
 'Make one saved override preset the active preset for previewing, editing, or applying': '保存済みオーバーライドプリセットの1つを、プレビュー、編集、適用に使うアクティブプリセットにします',
 'Write the saved override preset library to disk so it can be backed up or shared': '保存済みオーバーライドプリセットライブラリをディスクへ書き出し、バックアップや共有に使えるようにします',
 'Make one saved routing rule the active route for editing or applying': '保存済みルーティングルールの1つを、編集または適用に使うアクティブルートにします',
 'Recent Sources': '最近のソース',
 'Favorite Sources': 'お気に入りソース',
 'Seed Default Profiles': '既定プロファイルを作成',
 'Duplicate profile': 'プロファイルを複製',
 'Action result': '実行結果',
 'Edit profile': 'プロファイルを編集',
 'Write saved workspace profiles to a JSON file so they can be backed up or shared across projects': '保存済みワークスペースプロファイルをJSONファイルへ書き出し、バックアップやプロジェクト間共有に使えるようにします',
 'Sort Roots': 'ルートを並べ替え',
 'Quick Root Bootstrap': 'ルートのクイック初期設定',
 'Fill missing metadata': '不足メタデータを補完',
 'Allow asset key renames': 'アセットキー名変更を許可',
 'Direction': '方向',
 'Bootstrap Source': '初期設定ソース',
 'Pin profile': 'プロファイルを固定',
 'Root Source': 'ルートソース',
 'Workflow Preset': 'ワークフロープリセット',
 'Quick Sources': 'クイックソース',
 'Linked Edit Return': 'リンク編集から戻る',
 'Latest Result': '最新結果',
 'Verify Bundle...': 'バンドルを検証...',
 'Bundle Project...': 'プロジェクトをバンドル...',
 'Bundle Root': 'バンドルルート',
 'Remap Paths': 'パスを再マップ',
 'Ticket': 'チケット',
 'Materialize Linked References': 'リンク参照を実体化',
 'Convert overrides too': 'オーバーライドも変換',
 'Write the exported library as a compressed .blend file.': '書き出すライブラリを圧縮 .blend ファイルとして保存します。',
 'Mark fake users': 'フェイクユーザーを付与',
 'Ask Blender to mark written datablocks with fake users where supported so they are harder to purge accidentally later.': '対応しているデータブロックへフェイクユーザーを付与し、後で誤って削除されにくくします。',
 'Comma-separated helper tags stored in the manifest, such as hero, proxy, review, city, or crowd.': 'hero、proxy、review、city、crowd '
                                                                                                     'など、マニフェストに保存する補助タグをカンマ区切りで入力します。',
 'How external file paths should be written when a payload .blend is generated.': 'ペイロード .blend 生成時に外部ファイルパスを書き込む方法を指定します。',
 'Write the payload .blend as a compressed blend file.': 'ペイロード .blend を圧縮Blendファイルとして保存します。',
 'Ask Blender to tag written datablocks with fake users where supported so they survive later purges more easily.': '対応するデータブロックにフェイクユーザーを付与し、後のパージで消えにくくします。',
 'Optional short notes saved inside the container manifest for beginners, handoff comments, or review reminders.': '初心者向けメモ、引き継ぎコメント、レビュー確認用として、コンテナマニフェスト内へ保存する任意の短いメモです。',
 'Prefer payload .blend': 'ペイロード .blend を優先',
 'Prefer a payload .blend stored beside the manifest when it exists, then fall back to copied or original source files.': 'マニフェスト横にペイロード .blend '
                                                                                                                          'があれば優先し、なければコピー済みまたは元のソースファイルを使用します。',
 'Store Representation Snapshot': '表現スナップショットを保存',
 'Restore Representation Snapshot': '表現スナップショットを復元',
 'Release Cooperative Lock': '共同作業ロックを解除',
 'Recursive': '再帰的',
 'Limit': '上限',
 'Entries': '項目',
 'Overwrite': '上書き',
 'Replace markers': 'マーカーを置換',
 'Store rollback snapshot': 'ロールバックスナップショットを保存',
 'Replace existing': '既存項目を置換',
 'Store Current Shot': '現在のショットを保存',
 'Shot Queue Preflight': 'ショットキュー事前確認',
 'View Layer': 'ビューレイヤー',
 'Start': '開始',
 'Payload JSON': 'ペイロードJSON',
 'Updated At': '更新日時',
 'Append New': '新規追加',
 'Dependency Policy': '依存関係ポリシー',
 'Abort on duplicate outputs': '出力重複時は中止',
 'Restore original state': '元の状態を復元',
 'Preflight': '事前確認',
 'Store Assembly Snapshot': 'アセンブリスナップショットを保存',
 'Restore Assembly Snapshot': 'アセンブリスナップショットを復元',
 'Keywords': 'キーワード',
 'Also repath linked .blend library paths when the chosen scope reaches them.': '選択した対象範囲に含まれる場合、リンク .blend ライブラリのパスも再設定します。',
 'Optionally specialize this root so it is preferred for one external-file category.': 'このルートを特定の外部ファイルカテゴリで優先して使う場合に指定します。',
 'Replace Existing': '既存項目を置換',
 'Also try root paths embedded inside the manifest when those folders exist on this machine.': 'このマシン上に存在する場合、マニフェスト内に埋め込まれたルートパスも試します。',
 'Publish Asset...': 'アセットを公開...',
 'Versioning': 'バージョン管理',
 'Optional release notes written into metadata and changelog outputs': 'メタデータと変更履歴出力に書き込む任意のリリースノートです',
 'Write a sidecar JSON metadata file next to the published .blend': '公開した .blend の横にサイドカーJSONメタデータファイルを書き出します',
 'Append to changelog': '変更履歴へ追記',
 'Optional category written into the catalog and metadata so the asset is easier to organize later': '後で整理しやすくするため、カタログとメタデータへ書き込む任意カテゴリです',
 'Comma-separated tags written into metadata/catalog': 'メタデータとカタログへ書き込むカンマ区切りタグです',
 'Write Metadata': 'メタデータを書き出し',
 'Append Changelog': '変更履歴へ追記',
 'Subfolder': 'サブフォルダ',
 'Strict Loader (wm.append/link)': '厳格ローダー（wm.append/link）',
 'Grid Spacing': 'グリッド間隔',
 'Number of columns used when Grid placement arranges imported items.': 'グリッド配置で読み込んだ項目を並べるときに使用する列数です。',
 'Frame in View (3D View only)': 'ビュー内にフレーム表示（3Dビューのみ）',
 'Last Quick Action Title': '最後のクイックアクション名',
 'Latest quick-action title captured during this Blender session': 'このBlenderセッション中に記録された最新クイックアクションのタイトルです',
 'Last Quick Action Details': '最後のクイックアクション詳細',
 'Detailed quick-action notes captured during this Blender session': 'このBlenderセッション中に記録されたクイックアクションの詳細メモです',
 'Last Quick Action Follow-up': '最後のクイックアクション補足',
 'Suggested follow-up notes for the latest quick action': '最新クイックアクションに対する推奨フォローアップメモです',
 'Last Quick Action Icon': '最後のクイックアクションアイコン',
 'Icon used by the latest quick-action result popup': '最新クイックアクション結果ポップアップで使用するアイコンです',
 'Recent Smart File activity captured during this Blender session': 'このBlenderセッション中に記録された最近のSmart Fileアクティビティです',
 'Workspace Page': 'ワークスペースページ',
 'Internal asset identifier passed between tools': 'ツール間で受け渡す内部アセット識別子です',
 'Dependency Tree': '依存関係ツリー',
 'Tag Cloud JSON': 'タグクラウドJSON',
 'Categories JSON': 'カテゴリJSON',
 'Catalog Raw JSON': 'カタログ生JSON',
 'Preferred Source': '優先ソース',
 'Active linked library row': '現在選択中のリンクライブラリ行です',
 'Active review-plan row': '現在選択中のレビュープラン行です',
 'Representation Snapshot JSON': '表現スナップショットJSON',
 'Session snapshot used by the Representation Toolkit to restore previous display and visibility states': 'Representation Toolkit '
                                                                                                          'が以前の表示状態と可視状態を復元するために使うセッションスナップショットです',
 'Assembly Snapshot JSON': 'アセンブリスナップショットJSON',
 'Assembly Controller Keywords': 'アセンブリ制御キーワード',
 'Active Smart File shot-state preset row': '現在選択中のSmart Fileショット状態プリセット行です',
 'Active shot queue row': '現在選択中のショットキュー行です',
 'Attached File': '添付ファイル',
 'Restorable': '復元可能',
 'History Entries': '履歴項目',
 'Active Entry': 'アクティブ項目',
 'Project Key': 'プロジェクトキー',
 'Additional explanation stored for this row. It can contain context such as why the snapshot was created, whether it was manual or automatic, and what happened around that time.': 'この行に保存する補足説明です。スナップショットを作成した理由、手動か自動か、その前後で起きた内容などの文脈を記録できます。',
 'Maximum number of restore-point files kept for the current project. When the limit is exceeded, the oldest restore-point files are deleted first. This keeps rollback history useful without endless disk growth.': '現在のプロジェクトで保持する復元ポイントファイルの最大数です。上限を超えると古い復元ポイントから削除されるため、ディスクを無制限に増やさず有用なロールバック履歴を維持できます。',
 'Store one history row for restore points, autosaves, and recovery notes so you can review and reopen earlier file states': '復元ポイント、自動保存、復旧メモを1行の履歴として保存し、以前のファイル状態を確認して再度開けるようにします',
 'History Row Click': '履歴行クリック',
 'History Browser': '履歴ブラウザー',
 'Storage & Behavior': '保存と動作',
 'Tips': 'ヒント'}
try:
    if isinstance(_EXACT_TRANSLATIONS, dict):
        _EXACT_TRANSLATIONS.update(_MORE_EXACT_TRANSLATIONS)
    _EXTRA_EXACT_TRANSLATIONS.update(_MORE_EXACT_TRANSLATIONS)
except Exception:
    pass

_SUITE_COMPLETE_I18N_EXACT_V70 = {
    '⚠️ No objects selected': '⚠️ オブジェクトが選択されていません',
    '⚠️ IMPORTANT: Apply scale to particle instance objects': '⚠️ 重要: パーティクルインスタンスオブジェクトにスケールを適用してください',
    '• Camera: ON': '• カメラ: オン',
    '• Shadow: OFF': '• シャドウ: オフ',
    '• Light Probe Volume: ON': '• ライトプローブボリューム: オン',
    '• Shape A: Male avatar base (fully editable)': '• シェイプA: 男性アバターベース（完全に編集可能）',
    '• Shape B: Female avatar base (fully editable)': '• シェイプB: 女性アバターベース（完全に編集可能）',
    '• Both: Import both avatar shapes (fully editable)': '• 両方: 両方のアバターシェイプを読み込み（完全に編集可能）',
    'No objects selected': 'オブジェクトが選択されていません',
    'No textures needed renaming': '名前変更が必要なテクスチャはありません',
    'This tool will analyze all materials and rename textures based on their usage:': 'このツールはすべてのマテリアルを解析し、用途に基づいてテクスチャ名を変更します:',
    'Base Color → MaterialName_baseColor.png/jpg': 'ベースカラー → MaterialName_baseColor.png/jpg',
    'Roughness/Metallic → MaterialName_hrm.png/jpg': '粗さ/メタリック → MaterialName_hrm.png/jpg',
    'Normal → MaterialName_normal.png/jpg': 'ノーマル → MaterialName_normal.png/jpg',
    'Emissive → MaterialName_emissive.png/jpg': '発光 → MaterialName_emissive.png/jpg',
    'This tool imports and creates editable avatar collections:': 'このツールは編集可能なアバターコレクションを読み込み、作成します:',
    'Shape A: Male avatar base (fully editable)': 'シェイプA: 男性アバターベース（完全に編集可能）',
    'Shape B: Female avatar base (fully editable)': 'シェイプB: 女性アバターベース（完全に編集可能）',
    'Both: Import both avatar shapes (fully editable)': '両方: 両方のアバターシェイプを読み込み（完全に編集可能）',
    'Avatars will be immediately ready for posing and manipulation!': 'アバターはすぐにポーズ付けと操作ができる状態になります。',
    'Select objects with particle systems to convert': '変換するパーティクルシステム付きオブジェクトを選択します',
    'Creates armature with animated bones for each particle': '各パーティクル用のアニメーションボーンを持つアーマチュアを作成します',
    'IMPORTANT: Apply scale to particle instance objects': '重要: パーティクルインスタンスオブジェクトにスケールを適用してください',
    'before running this converter to prevent scaling issues': 'スケール問題を防ぐため、この変換ツールを実行する前に行ってください',
    'Select a mesh object': 'メッシュオブジェクトを選択してください',
    'Object To Encode': 'エンコード対象オブジェクト',
    'Vertex Count': '頂点数',
    'Frame Count': 'フレーム数',
    'Frame Start': '開始フレーム',
    'Position Mode': '位置モード',
    'Normalize (useful for png)': '正規化（PNGに有用）',
    'Wrap Mode': 'ラップモード',
    'Output Size': '出力サイズ',
    'Y Used': 'Y使用量',
    'Num Wraps': 'ラップ数',
    'Process Anim Meshes': 'アニメーションメッシュを処理',
    'Vertex Animation': '頂点アニメーション',
    'Camera: ON': 'カメラ: オン',
    'Shadow: OFF': 'シャドウ: オフ',
    'Light Probe Volume: ON': 'ライトプローブボリューム: オン',
    'Aggressive (resize 1024→512)': '強力（1024→512 にリサイズ）',
    'Moderate (resize 2048→1024)': '中程度（2048→1024 にリサイズ）',
    'Conservative (keep original size)': '控えめ（元サイズを維持）',
    'Only selected objects are counted': '選択したオブジェクトのみを集計します',
    'AvatarSkin_MAT material is not counted toward material limit': 'AvatarSkin_MAT マテリアルはマテリアル制限に含めません',
    'All textures must be square and 72 pixel/inch resolution': 'すべてのテクスチャは正方形で 72 pixel/inch の解像度が必要です',
    'Hand accessories that hide base hand get 1.5K triangle budget': 'ベースの手を隠す手アクセサリには 1.5K 三角形の上限が適用されます',
    'Skin wearables get 5K triangle and 5 texture budget': 'スキンウェアラブルには 5K 三角形と 5 テクスチャの上限が適用されます',
    'WARNINGS': '警告',
    'TRIANGLES': '三角形数',
    'MATERIALS': 'マテリアル数',
    'TEXTURES': 'テクスチャ数',
    'Resolution': '解像度',
    'Successfully renamed textures based on their usage': '用途に基づいてテクスチャ名を変更しました',
}
try:
    if isinstance(_EXACT_TRANSLATIONS, dict):
        _EXACT_TRANSLATIONS.update(_SUITE_COMPLETE_I18N_EXACT_V70)
    _EXTRA_EXACT_TRANSLATIONS.update(_SUITE_COMPLETE_I18N_EXACT_V70)
except Exception:
    pass

_EXTRA_PHRASE_TRANSLATIONS = (
    ('Universal Multi Importer', 'ユニバーサル複数インポーター'),
    ('Texture File Path Editor', 'テクスチャファイルパスエディター'),
    ('Texture Manager', 'テクスチャマネージャー'),
    ('Object Reporter', 'オブジェクトレポーター'),
    ('Bulk Asset Tools', '一括アセットツール'),
    ('Decentraland Tools', 'Decentraland ツール'),
    ('IKEA Browser', 'IKEA ブラウザー'),
    ('Avatar Limitations Calculator', 'アバター制限計算'),
    ('Scene Limitations Calculator', 'シーン制限計算'),
    ('Scene Validator', 'シーン検証'),
    ('Asset Guidelines', 'アセットガイドライン'),
    ('Backface Culling', '背面カリング'),
    ('Particle System to Armature', 'パーティクルをアーマチュアへ変換'),
    ('Atlas Optimizer', 'アトラス最適化'),
    ('Quick Export glTF', 'glTF クイック書き出し'),
    ('Export Composite', 'コンポジットを書き出し'),
    ('Import Composite', 'コンポジットを読み込み'),
    ('Export Emote GLB', 'エモート GLB を書き出し'),
    ('Validate Emote', 'エモートを検証'),
    ('Validate Textures', 'テクスチャを検証'),
    ('Generate LODs', 'LOD を生成'),
    ('Create Parcels', '区画を作成'),
    ('Create Emote Action', 'エモートアクションを作成'),
    ('Create LOD Collection', 'LOD コレクションを作成'),
    ('Enable Backface Culling', '背面カリングを有効化'),
    ('Import DCL Rig', 'DCL リグを読み込み'),
    ('Import a product', '製品を読み込み'),
    ('Factory startup', 'ファクトリースタートアップ'),
    ('Run Background Processes', 'バックグラウンド処理を実行'),
    ('Use Factory Startup', 'ファクトリースタートアップを使用'),
    ('Max Threads', '最大スレッド数'),
    ('Change Author', '作成者を変更'),
    ('Change Copyright', '著作権を変更'),
    ('Change Description', '説明を変更'),
    ('Change License', 'ライセンスを変更'),
    ('Clear Asset Marking', 'アセットマークをクリア'),
    ('Asset Mover', 'アセット移動'),
    ('Destination Catalog', '移動先カタログ'),
    ('New Author', '新しい作成者'),
    ('New Copyright', '新しい著作権'),
    ('New Description', '新しい説明'),
    ('New License', '新しいライセンス'),
    ('Tag to Add', '追加するタグ'),
    ('Tag to Copy', 'コピーするタグ'),
    ('Tag to Remove', '削除するタグ'),
    ('Add Tag', 'タグを追加'),
    ('Copy Tag', 'タグをコピー'),
    ('Remove Tag', 'タグを削除'),
    ('Open Preferences', '設定を開く'),
    ('Open Website', 'Webサイトを開く'),
    ('Open Documentation', 'ドキュメントを開く'),
    ('Open Log File', 'ログファイルを開く'),
    ('Report Issue', '問題を報告'),
    ('Download Manually', '手動でダウンロード'),
    ('Update Universal Multi Importer', 'ユニバーサル複数インポーターを更新'),
    ('Check Addon Dependency', 'アドオン依存関係を確認'),
    ('All Addon Dependencies Enabled', 'すべてのアドオン依存関係が有効'),
    ('All Addon Dependencies Installed', 'すべてのアドオン依存関係がインストール済み'),
    ('Supported Version', '対応バージョン'),
    ('Installed version', 'インストール済みバージョン'),
    ('Local Version', 'ローカルバージョン'),
    ('Remote Version', 'リモートバージョン'),
    ('Need Reboot', '再起動が必要'),
    ('Restart Blender to finish loading', '読み込みを完了するには Blender を再起動してください'),
    ('Import settings registered', '読み込み設定を登録しました'),
    ('Settings imported', '設定を読み込みました'),
    ('Settings applied', '設定を適用しました'),
    ('Current Format Settings Imported', '現在の形式設定を読み込みました'),
    ('Current Format Settings cancelled', '現在の形式設定をキャンセルしました'),
    ('File Operations', 'ファイル操作'),
    ('File Selection', 'ファイル選択'),
    ('File Selected', '選択ファイル'),
    ('File Count', 'ファイル数'),
    ('File Format', 'ファイル形式'),
    ('File Limits', 'ファイル制限'),
    ('Export Folder', '書き出しフォルダー'),
    ('Import Folder', '読み込みフォルダー'),
    ('Import Directory', '読み込みディレクトリ'),
    ('Import Format', '読み込み形式'),
    ('Import Module', '読み込みモジュール'),
    ('Import Mode', '読み込みモード'),
    ('Import Options', '読み込みオプション'),
    ('Import Settings', '読み込み設定'),
    ('Import Setting Name', '読み込み設定名'),
    ('Ready to Import', '読み込み準備完了'),
    ('Selected extension items', '選択中の拡張子項目'),
    ('Selected format items', '選択中の形式項目'),
    ('Installed Formats', 'インストール済み形式'),
    ('External Addon', '外部アドオン'),
    ('Addon Name', 'アドオン名'),
    ('Package URL', 'パッケージ URL'),
    ('Package Index', 'パッケージインデックス'),
    ('Preset ID', 'プリセット ID'),
    ('Preset Name', 'プリセット名'),
    ('SFS_OT_universal_multi_importer_import_all Presets', 'SFS_OT_universal_multi_importer_import_all プリセット'),
    ('Add SFS_OT_universal_multi_importer_import_all preset', 'SFS_OT_universal_multi_importer_import_all プリセットを追加'),
    ('Load Preset', 'プリセットを読み込み'),
    ('Save Preset', 'プリセットを保存'),
    ('Add Preset', 'プリセットを追加'),
    ('Remove Preset', 'プリセットを削除'),
    ('Move Preset', 'プリセットを移動'),
    ('Duplicate Selected Preset', '選択プリセットを複製'),
    ('Clear All Presets', 'すべてのプリセットをクリア'),
    ('Add Operator', 'オペレーターを追加'),
    ('Remove Selected Operator', '選択オペレーターを削除'),
    ('Duplicate Selected Operator', '選択オペレーターを複製'),
    ('Move Operator', 'オペレーターを移動'),
    ('Edit Operator', 'オペレーターを編集'),
    ('Clear All Operators', 'すべてのオペレーターをクリア'),
    ('Operator Command', 'オペレーターコマンド'),
    ('Operator ID', 'オペレーター ID'),
    ('Command Batcher', 'コマンドバッチャー'),
    ('Execute Pre process commands', '前処理コマンドを実行'),
    ('Execute Post process commands', '後処理コマンドを実行'),
    ('Execute Each process commands', '各処理コマンドを実行'),
    ('Ignore Command Batcher Errors', 'コマンドバッチャーのエラーを無視'),
    ('Refresh Viewport After Each Imported Files', '各読み込みファイル後にビューポートを更新'),
    ('Refresh Viewport After Each Processed Command', '各処理コマンド後にビューポートを更新'),
    ('Refresh Viewport After time', '指定時間後にビューポートを更新'),
    ('Auto Hide Log When Finished', '完了時にログを自動で隠す'),
    ('Wait Before Hiding', '隠すまでの待機時間'),
    ('Display Debug Log', 'デバッグログを表示'),
    ('Debug Logging', 'デバッグログ'),
    ('Debug FilePath', 'デバッグファイルパス'),
    ('Debug Position', 'デバッグ位置'),
    ('Show Debug Report', 'デバッグレポートを表示'),
    ('Show Log on 3D View', '3Dビューにログを表示'),
    ('Log Display', 'ログ表示'),
    ('Info Color', '情報色'),
    ('Warning Color', '警告色'),
    ('Error Color', 'エラー色'),
    ('Command Color', 'コマンド色'),
    ('Command Warning Color', 'コマンド警告色'),
    ('Success Color', '成功色'),
    ('Cancelled Color', 'キャンセル色'),
    ('Window Width', 'ウィンドウ幅'),
    ('Dialog Width', 'ダイアログ幅'),
    ('Bottom Left', '左下'),
    ('Camera Controls', 'カメラ操作'),
    ('Lighting Controls', 'ライティング操作'),
    ('Thumbnail Camera', 'サムネイルカメラ'),
    ('Thumbnail Lighting', 'サムネイル照明'),
    ('Add Thumbnail Camera', 'サムネイルカメラを追加'),
    ('Add Thumbnail Lighting', 'サムネイル照明を追加'),
    ('Render Thumbnail', 'サムネイルをレンダー'),
    ('Overwrite scene.json', 'scene.json を上書き'),
    ('Scene Directory', 'シーンディレクトリ'),
    ('Scene Title', 'シーンタイトル'),
    ('Scene Limits Guide', 'シーン制限ガイド'),
    ('Scene Unit', 'シーン単位'),
    ('Scene Units', 'シーン単位'),
    ('Unit Scale', '単位スケール'),
    ('Geo Referencing', '地理参照'),
    ('Geo Reference', '地理参照'),
    ('Geo-Reference Latitude', '地理参照 緯度'),
    ('Geo-Reference Longitude', '地理参照 経度'),
    ('EPSG-Code', 'EPSG コード'),
    ('DXF coordinate type', 'DXF 座標タイプ'),
    ('DXF File', 'DXF ファイル'),
    ('DXF SRID', 'DXF SRID'),
    ('Scn SRID', 'シーン SRID'),
    ('Line Styes', '線種'),
    ('Line thickness and width', '線の太さと幅'),
    ('Represent line thickness/width', '線の太さ/幅を表現'),
    ('Combine LINE entities to polygons', 'LINE エンティティをポリゴンへ結合'),
    ('Merge by attributes', '属性で結合'),
    ('Blocks As', 'ブロックの扱い'),
    ('Parent Blocks to Bounding Boxes', 'ブロックをバウンディングボックスへ親子付け'),
    ('Export ACIS Entities', 'ACIS エンティティを書き出し'),
    ('Export Mesh As', 'メッシュの書き出し形式'),
    ('Facet Normals', '面法線'),
    ('Global Space', 'グローバル空間'),
    ('Entity Color', 'エンティティ色'),
    ('Entity Layer', 'エンティティレイヤー'),
    ('Entity Linetype', 'エンティティ線種'),
    ('Limit Area Reference', '範囲参照を制限'),
    ('Backup Original', '元をバックアップ'),
    ('Backup Step', 'バックアップ間隔'),
    ('Backup file during import', '読み込み中にファイルをバックアップ'),
    ('Make Absolute', '絶対パス化'),
    ('Make Relative', '相対パス化'),
    ('Copy Path', 'パスをコピー'),
    ('Relink', '再リンク'),
    ('Collect', '収集'),
    ('Delete Missing/Unused', '欠損/未使用を削除'),
    ('Delete Missing & Unused', '欠損と未使用を削除'),
    ('Rename Image', '画像名を変更'),
    ('Resize Textures', 'テクスチャをリサイズ'),
    ('Rename Textures by Usage', '用途でテクスチャ名を変更'),
    ('Remove Specular Tint Textures', 'スペキュラーティントテクスチャを削除'),
    ('Set Specular to 0', 'スペキュラーを 0 に設定'),
    ('Force JPEG When No Alpha', 'アルファなしは JPEG を強制'),
    ('JPEG Quality', 'JPEG 品質'),
    ('Max Size', '最大サイズ'),
    ('Compress Images', '画像を圧縮'),
    ('Checker Map', 'チェッカーマップ'),
    ('Cleanup All Checker Maps', 'すべてのチェッカーマップを整理'),
    ('Cleanup Colliders', 'コライダーを整理'),
    ('Simplify Colliders', 'コライダーを簡略化'),
    ('Strip Materials from Colliders', 'コライダーからマテリアルを削除'),
    ('Remove UVs from Colliders', 'コライダーから UV を削除'),
    ('Add _collider Suffix', '_collider 接尾辞を追加'),
    ('Select collider objects to simplify', '簡略化するコライダーオブジェクトを選択'),
    ('Remove Empty Meshes', '空メッシュを削除'),
    ('Remove Empty Objects', '空オブジェクトを削除'),
    ('Remove Empty Types', '空タイプを削除'),
    ('Remove Meshes Without Materials', 'マテリアルなしメッシュを削除'),
    ('Replace Materials', 'マテリアルを置換'),
    ('Replace Materials Add', '置換マテリアルを追加'),
    ('Replace Materials Remove', '置換マテリアルを削除'),
    ('Source Material', '置換元マテリアル'),
    ('Target Material', '置換先マテリアル'),
    ('Source Materials', '置換元マテリアル'),
    ('Target Material (replacement)', '置換先マテリアル'),
    ('Add Source Material', '置換元マテリアルを追加'),
    ('Remove Source Material', '置換元マテリアルを削除'),
    ('Material Name', 'マテリアル名'),
    ('Texture Requirements', 'テクスチャ要件'),
    ('All Textures', 'すべてのテクスチャ'),
    ('All Materials', 'すべてのマテリアル'),
    ('Materials: All assigned', 'マテリアル: すべて割り当て済み'),
    ('Textures: All power-of-two', 'テクスチャ: すべて2の累乗'),
    ('Transforms: All applied', 'トランスフォーム: すべて適用済み'),
    ('Format: Square, 72 pixel/inch', '形式: 正方形、72 pixel/inch'),
    ('DCL Limits', 'DCL 制限'),
    ('Current Usage vs Limits', '現在の使用量と制限'),
    ('File Limits', 'ファイル制限'),
    ('Optional Objects', '任意オブジェクト'),
    ('Wearable Type', 'ウェアラブルタイプ'),
    ('Select Wearable Type', 'ウェアラブルタイプを選択'),
    ('Avatar Shape', 'アバター形状'),
    ('Avatar Shapes', 'アバター形状'),
    ('Emote Name', 'エモート名'),
    ('Emote Settings', 'エモート設定'),
    ('Start Frame', '開始フレーム'),
    ('End Frame', '終了フレーム'),
    ('Sampling Rate', 'サンプリングレート'),
    ('Strict Validation', '厳密な検証'),
    ('LOD Levels', 'LOD レベル数'),
    ('LOD 1 Ratio', 'LOD 1 比率'),
    ('LOD 2 Ratio', 'LOD 2 比率'),
    ('LOD 3 Ratio', 'LOD 3 比率'),
    ('LOD 4 Ratio', 'LOD 4 比率'),
    ('Decimation Ratio', 'デシメーション比率'),
    ('Merge Distance', '結合距離'),
    ('Merge Options', '結合オプション'),
    ('Merged Objects', '結合済みオブジェクト'),
    ('Output Collection', '出力コレクション'),
    ('Output Size', '出力サイズ'),
    ('Output Path', '出力パス'),
    ('Export Path', '書き出しパス'),
    ('Grouping', 'グループ化'),
    ('Group Rows', '行をグループ化'),
    ('Group by', 'グループ基準'),
    ('Summary Table', '集計表'),
    ('Viewport Labels', 'ビューポートラベル'),
    ('Show Viewport Labels', 'ビューポートラベルを表示'),
    ('Visible Only', '表示中のみ'),
    ('Selected Only', '選択のみ'),
    ('Only Selected Objects', '選択オブジェクトのみ'),
    ('Only Mesh Objects', 'メッシュオブジェクトのみ'),
    ('Tagged Only', 'タグ付きのみ'),
    ('Internal Props', '内部プロパティ'),
    ('Custom properties', 'カスタムプロパティ'),
    ('Computed geometry', '計算ジオメトリ'),
    ('Object Name', 'オブジェクト名'),
    ('Face Area', '面積'),
    ('Area per Material', 'マテリアル別面積'),
    ('Mat. Area', 'マテリアル面積'),
    ('Volume', '体積'),
    ('Dimensions', '寸法'),
    ('Precision', '精度'),
    ('Field Name', 'フィールド名'),
    ('Default Value', 'デフォルト値'),
    ('Add Field', 'フィールドを追加'),
    ('Remove Field', 'フィールドを削除'),
    ('Pick Field', 'フィールドを選択'),
    ('Pick Property', 'プロパティを選択'),
    ('Pick Value', '値を選択'),
    ('Add Condition', '条件を追加'),
    ('Add to Selection', '選択に追加'),
    ('Add to Fields', 'フィールドへ追加'),
    ('Show All Objects', 'すべてのオブジェクトを表示'),
    ('Deselect All', 'すべて選択解除'),
    ('Isolate', '分離表示'),
    ('Set Property', 'プロパティを設定'),
    ('Tag Selected', '選択項目にタグ付け'),
    ('Set Boundary Keys', '境界キーを設定'),
    ('Choose field', 'フィールドを選択'),
    ('Enable Grouping panel first', '先にグループ化パネルを有効にしてください'),
    ('Press Refresh to load', '読み込むには更新を押してください'),
    ('Press Refresh to update view', '表示を更新するには更新を押してください'),
    ('Refresh data changed', '変更データを更新'),
    ('No custom properties found', 'カスタムプロパティは見つかりませんでした'),
    ('No materials added yet', 'マテリアルはまだ追加されていません'),
    ('No mesh objects selected', 'メッシュオブジェクトが選択されていません'),
    ('No textures found in the scene', 'シーン内にテクスチャは見つかりませんでした'),
    ('No shared properties. Switch to Any.', '共有プロパティがありません。Any に切り替えてください。'),
    ('No images in this file.', 'このファイルに画像はありません。'),
    ('Product info missing', '製品情報がありません'),
    ('Enable online access to see more details', '詳細を表示するにはオンラインアクセスを有効にしてください'),
    ('Blender is set to offline mode', 'Blender はオフラインモードに設定されています'),
    ('To use IKEA Browser, enable online access', 'IKEA ブラウザーを使うにはオンラインアクセスを有効にしてください'),
    ('Item No', '商品番号'),
    ('Country', '国'), ('Language', '言語'), ('Price', '価格'), ('Style', 'スタイル'),
    ('Value', '値'), ('Text', 'テキスト'), ('Field', 'フィールド'), ('Property', 'プロパティ'),
    ('Properties', 'プロパティ'), ('Operator', 'オペレーター'), ('Actions', 'アクション'),
    ('Settings', '設定'), ('Options', 'オプション'), ('Help', 'ヘルプ'), ('Search', '検索'),
    ('Filter', 'フィルター'), ('Format', '形式'), ('Formats', '形式'), ('Extension', '拡張子'),
    ('Directory', 'ディレクトリ'), ('Filepath', 'ファイルパス'), ('File Path', 'ファイルパス'),
    ('Path', 'パス'), ('Folder', 'フォルダー'), ('Scene', 'シーン'), ('Collection', 'コレクション'),
    ('Collections', 'コレクション'), ('Object', 'オブジェクト'), ('Objects', 'オブジェクト'),
    ('Mesh Objects', 'メッシュオブジェクト'), ('Meshes', 'メッシュ'), ('Mesh', 'メッシュ'),
    ('Materials', 'マテリアル'), ('Material', 'マテリアル'), ('Textures', 'テクスチャ'),
    ('Texture', 'テクスチャ'), ('Images', '画像'), ('Image', '画像'), ('Cameras', 'カメラ'),
    ('Camera', 'カメラ'), ('Lights', 'ライト'), ('Light', 'ライト'), ('Armatures', 'アーマチュア'),
    ('Curves', 'カーブ'), ('Fonts', 'フォント'), ('Lattices', 'ラティス'), ('Metaballs', 'メタボール'),
    ('Node Groups', 'ノードグループ'), ('Node Graph', 'ノードグラフ'), ('Worlds', 'ワールド'),
    ('Workspaces', 'ワークスペース'), ('Scenes', 'シーン'), ('Brushes', 'ブラシ'),
    ('Palettes', 'パレット'), ('Sounds', 'サウンド'), ('Volumes', 'ボリューム'), ('Geometry', 'ジオメトリ'),
    ('Transform', 'トランスフォーム'), ('Scale Factor', 'スケール係数'), ('Scale', 'スケール'),
    ('Rotation', '回転'), ('Rotate', '回転'), ('Location', '位置'), ('Origin Point', '原点'),
    ('Origin', '原点'), ('Cursor Origin', 'カーソル原点'), ('Hierarchy', '階層'),
    ('Animation', 'アニメーション'), ('Selection Only', '選択のみ'), ('Selection', '選択'),
    ('Selected Objects Only', '選択オブジェクトのみ'), ('Selected', '選択済み'), ('Invisible', '非表示'),
    ('Visible', '表示'), ('Include Hidden', '非表示も含める'), ('Include Folder', 'フォルダーを含める'),
    ('Include', '含める'), ('Apply Modifiers', 'モディファイアーを適用'),
    ('Apply Transform', 'トランスフォームを適用'), ('Apply Matrix', '行列を適用'),
    ('Image Search', '画像検索'), ('Object Filter', 'オブジェクトフィルター'),
    ('Object Types', 'オブジェクトタイプ'), ('Source Collection', 'ソースコレクション'),
    ('Constrain Size', 'サイズ制限'), ('Status', '状態'), ('Stats', '統計'),
    ('Warnings', '警告'), ('Errors', 'エラー'), ('Check', '確認'), ('Compare', '比較'),
    ('Clean All', 'すべて整理'), ('Clean Selected', '選択項目を整理'), ('Cleanup', '整理'),
    ('Clean', '整理'), ('Add', '追加'), ('Remove', '削除'), ('Clear All', 'すべてクリア'),
    ('Clear', 'クリア'), ('Copy', 'コピー'), ('Move', '移動'), ('Rename', '名前変更'),
    ('Change', '変更'), ('Select', '選択'), ('Deselect', '選択解除'), ('Import', 'インポート'),
    ('Export', 'エクスポート'), ('Update', '更新'), ('Refresh', '更新'), ('Generate', '生成'),
    ('Validate', '検証'), ('Open', '開く'), ('Show', '表示'), ('Enable', '有効化'),
    ('Disable', '無効化'), ('Toggle', '切り替え'), ('Apply', '適用'), ('Load', '読み込み'),
    ('Save', '保存'), ('Run', '実行'), ('Execute', '実行'), ('Create', '作成'),
    ('Delete', '削除'), ('Set', '設定'), ('Use', '使用'), ('Skip', 'スキップ'), ('Force', '強制'),
    ('Normalize', '正規化'), ('Merge', '結合'), ('Decimate', 'デシメート'),
    ('Simplify', '簡略化'), ('Compress', '圧縮'), ('Resize', 'リサイズ'), ('Pack', 'パック'),
    ('Unpack', 'アンパック'), ('Collect', '収集'), ('Browse', 'ブラウズ'), ('Preview', 'プレビュー'),
    ('Summary', '要約'), ('Report', 'レポート'), ('Count', '数'), ('Total', '合計'),
    ('Index', 'インデックス'), ('Mode', 'モード'), ('Method', '方式'), ('Range', '範囲'),
    ('Size', 'サイズ'), ('Width', '幅'), ('Height', '高さ'), ('Distance', '距離'),
    ('Strength', '強度'), ('Step', 'ステップ'), ('Quality', '品質'), ('Version', 'バージョン'),
    ('Verbose', '詳細表示'), ('Enabled', '有効'), ('Installed', 'インストール済み'),
    ('Outdated', '古い'), ('Experimental Features', '実験的機能'),
    ('Allow Online Access', 'オンラインアクセスを許可'), ('Debug', 'デバッグ'),
    ('Warning', '警告'), ('Error', 'エラー'),
)
_EXTRA_PHRASE_TRANSLATIONS += (
    ('Author', '作成者'),
    ('Copyright', '著作権'),
    ('License', 'ライセンス'),
    ('Description', '説明'),
    ('Usage', '使用量'),
    ('Limits', '制限'),
    ('mesh objects', 'メッシュオブジェクト'),
    ('data changed', 'データ変更'),
    ('actual image data', '実際の画像データ'),
    ('This modifies the actual image data', '実際の画像データを変更します'),
    ('load', '読み込み'),
    ('web browser', 'Webブラウザー'),
    ('online access', 'オンラインアクセス'),
    ('default web browser', '標準Webブラウザー'),
    ('Note', '備考'),
    ('vs', 'と'),
    ('Already in list', '既にリストにあります'),
    ('Adding Datatype', 'データ型を追加中'),
    ('Additional Checks', '追加確認'),
    ('Align', '整列'),
    ('optimize performance', 'パフォーマンスを最適化'),
    ('Applies to', '適用先'),
    ('Ascii', 'ASCII'),
    ('AUTO', '自動'),
    ('opaque', '不透明'),
    ('transparent', '透明'),
    ('Backup', 'バックアップ'),
    ('backup', 'バックアップ'),
    ('converter', '変換ツール'),
    ('scaling issues', 'スケール問題'),
    ('Cache files', 'キャッシュファイル'),
    ('Case Sensitive', '大文字小文字を区別'),
    ('Color Presets', 'カラープリセット'),
    ('Color', 'カラー'),
    ('Command', 'コマンド'),
    ('Commands', 'コマンド'),
    ('Compression', '圧縮'),
    ('Creates armature', 'アーマチュアを作成'),
    ('animated bones', 'アニメーションボーン'),
    ('each particle', '各パーティクル'),
    ('Culled', 'カリング済み'),
    ('Data Type', 'データ型'),
    ('Datatype Name', 'データ型名'),
    ('Data', 'データ'),
    ('Display Groups in Outliner', 'アウトライナーにグループを表示'),
    ('Documentation', 'ドキュメント'),
    ('Duplicates', '重複'),
    ('not valid', '無効'),
    ('End', '終了'),
    ('Fields', 'フィールド'),
    ('3DView', '3Dビュー'),
    ('Outliner', 'アウトライナー'),
    ('file(s)', 'ファイル'),
    ('File Name', 'ファイル名'),
    ('FileSize', 'ファイルサイズ'),
    ('Flip Y', 'Y反転'),
    ('Frame Start', '開始フレーム'),
    ('From List', 'リストから'),
    ('Grease Penil', 'グリースペンシル'),
    ('ImageEmpty', '空画像'),
    ('Inject Variable', '変数を挿入'),
    ('input file', '入力ファイル'),
    ('Batcher Processing', 'バッチャー処理'),
    ('Last Setting to get', '取得する最後の設定'),
    ('Latitude', '緯度'),
    ('Longitude', '経度'),
    ('Lat', '緯度'),
    ('Lon', '経度'),
    ('Layer Name', 'レイヤー名'),
    ('Library Name', 'ライブラリ名'),
    ('LOD1 Ratio', 'LOD1 比率'),
    ('LOD2 Ratio', 'LOD2 比率'),
    ('LOD3 Ratio', 'LOD3 比率'),
    ('LOD4 Ratio', 'LOD4 比率'),
    ('Logic', '論理'),
    ('Loop Sequence', 'ループシーケンス'),
    ('Loop', 'ループ'),
    ('Make Imported Rig Active', '読み込んだリグをアクティブにする'),
    ('Masks', 'マスク'),
    ('Match', '一致'),
    ('Max Offset', '最大オフセット'),
    ('Min Offset', '最小オフセット'),
    ('Max Simultaneously Files', '同時最大ファイル数'),
    ('Minimize batch number', 'バッチ数を最小化'),
    ('Movie Clips', 'ムービークリップ'),
    ('normals', '法線'),
    ('Offset X', 'オフセット X'),
    ('Offset Y', 'オフセット Y'),
    ('Paint Cures', 'ペイントカーブ'),
    ('Parcels X', '区画 X'),
    ('Parcels Y', '区画 Y'),
    ('Particles', 'パーティクル'),
    ('Point Clouds', 'ポイントクラウド'),
    ('positions', '位置'),
    ('Presets', 'プリセット'),
    ('Projection', '投影'),
    ('Put in Background', 'バックグラウンドへ送る'),
    ('Recursion Depth', '再帰深度'),
    ('Remap Duplicates', '重複を再マップ'),
    ('Remap Dupes', '重複を再マップ'),
    ('Side', '側面'),
    ('Speakers', 'スピーカー'),
    ('Sum', '合計'),
    ('Tabs', 'タブ'),
    ('Tab', 'タブ'),
    ('Texts', 'テキスト'),
    ('sequence', 'シーケンス'),
    ('detected automatically', '自動検出されます'),
    ('Theme', 'テーマ'),
    ('These operators', 'これらのオペレーター'),
    ('will be executed', '実行されます'),
    ('after all elements are imported/processed', 'すべての要素の読み込み/処理後'),
    ('unused', '未使用'),
    ('Up/Down', '上/下'),
    ('Updating Batcher Variable', 'バッチャー変数を更新中'),
    ('Valid Datatypes', '有効なデータ型'),
    ('Zoom', 'ズーム'),
    ('Shadow', 'シャドウ'),
    ('Male avatar base', '男性アバターベース'),
    ('Female avatar base', '女性アバターベース'),
    ('fully editable', '完全に編集可能'),
    ('Avatars will be immediately ready for posing and manipulation', 'アバターはすぐにポーズ付け・操作できる状態になります'),
    ('BORDER', '境界'),
    ('CENTER', '中央'),
    ('DASHDOT', '一点鎖線'),
    ('DASHED', '破線'),
    ('DIVIDE', '分割'),
    ('DOT', '点線'),
    ('HIDDEN', '非表示'),
    ('IF', '条件'),
    ('IKEA Product', 'IKEA 製品'),
    ('Metrics', '指標'),
    ('Stl (.stl) (legacy)', 'STL（.stl）レガシー'),
    ('UVMap', 'UVマップ'),
    ('name', '名前'),
    ('ext', '拡張子'),
    ('Ext', '拡張子'),
    # ('max', '最大') deliberately removed: 'max' is the 3ds Max import
    # context and the .max format token, not the word "maximum".  It is
    # declared in DO_NOT_TRANSLATE_TOKENS above and stripped structurally
    # after every phrase-table merge below.
    ('min', '最小'),
)
_EXTRA_PHRASE_TRANSLATIONS += (('more', '件追加'),
 ('total', '合計'),
 ('missing', '欠落'),
 ('packed', 'パック済み'),
 ('preview', 'プレビュー'),
 ('meta', 'メタ情報'),
 ('category', 'カテゴリ'),
 ('tags', 'タグ'),
 ('rename', '名前変更'),
 ('root', 'ルート'),
 ('cat', 'カテゴリ'),
 ('Yes', 'はい'),
 ('No', 'いいえ'),
 ('Region', '地域'),
 ('Language', '言語'),
 ('Fields in', '内の項目'),
 ('object(s) selected', '個のオブジェクトを選択中'),
 ('mesh object(s) selected', '個のメッシュオブジェクトを選択中'),
 ('Total', '合計'),
 ('Connected', '接続済み'),
 ('Missing', '欠落'),
 ('Packed', 'パック済み'),
 ('Unused', '未使用'),
 ('Disk size', 'ディスクサイズ'),
 ('Object To Encode', 'エンコード対象オブジェクト'),
 ('Vertex Count', '頂点数'),
 ('Frame Count', 'フレーム数'),
 ('Min Offset', '最小オフセット'),
 ('Max Offset', '最大オフセット'),
 ('Num Wraps', 'ラップ数'),
 ('Output Size', '出力サイズ'),
 ('Y Used', 'Y使用量'),
 ('Addon dependency status have to be refreshed', 'アドオン依存関係の状態を更新する必要があります'),
 ('All formats are installed/enabled/updated properly', 'すべての形式が正しくインストール、有効化、更新されています'),
 ('All formats are installed/enabled/updated properly, but before it fully works, you will have to', 'すべての形式は正しくインストール、有効化、更新されていますが、完全に動作させるには次の操作が必要です'),
 ('Disable Universal Multi Importer Addon', 'Universal Multi Importer アドオンを無効化'),
 ('Restart Blender', 'Blender を再起動'),
 ('Enable Universal Multi Importer Addon again', 'Universal Multi Importer アドオンを再度有効化'),
 ('Some formats are currently not installed/enabled/updated. If you want to use them with this addon, you will have to',
  '一部の形式がインストール、有効化、更新されていません。このアドオンで使用するには次の操作が必要です'),
 ('Install/Enable/Update the formats by clicking on the install/enable/update button below', '下のインストール/有効化/更新ボタンを押して形式をインストール、有効化、更新します'),
 ('addon is not installed, you can fix dependencies with the button bellow', 'アドオンがインストールされていません。下のボタンで依存関係を修正できます'),
 ('Installed version', 'インストール済みバージョン'),
 ('supported version', '対応バージョン'),
 ('Please check the installed version of the addon', 'アドオンのインストール済みバージョンを確認してください'),
 ('Please update the', '更新してください'),
 ('Update addon', 'アドオンを更新'),
 ('is disable, please enable it before moving forward', '無効です。続行する前に有効化してください'),
 ('Enable addon', 'アドオンを有効化'),
 ('Selected Objects', '選択オブジェクト'),
 ('Triangles', '三角形数'),
 ('Materials', 'マテリアル'),
 ('Textures', 'テクスチャ'),
 ('Resolution', '解像度'),
 ('Total size', '合計サイズ'),
 ('Output', '出力'),
 ('Rig version', 'リグバージョン'),
 ('material(s) to replace', '置換対象マテリアル'),
 ('File Size', 'ファイルサイズ'),
 ('Files', 'ファイル'),
 ('FPS', 'FPS'),
 ('Frame Length', 'フレーム長'),
 ('Active Action', 'アクティブアクション'),
 ('Max Horizontal Offset', '最大水平オフセット'),
 ('Max Vertical Offset', '最大垂直オフセット'),
 ('Non-applied transforms', '未適用トランスフォーム'),
 ('Missing materials', '欠落マテリアル'),
 ('Non-power-of-two textures', '2の累乗ではないテクスチャ'),
 ('texture(s) with errors', 'エラーのあるテクスチャ'),
 ('texture(s) with warnings', '警告のあるテクスチャ'),
 ('texture(s) OK', '正常なテクスチャ'))
try:
    _PHRASE_TRANSLATIONS = tuple(_PHRASE_TRANSLATIONS or ()) + tuple(_EXTRA_PHRASE_TRANSLATIONS)
    _PHRASE_TRANSLATIONS = _strip_protected_phrase_pairs(_PHRASE_TRANSLATIONS)
except Exception:
    pass


def _clean(text: object) -> str:
    return _SPACE_RE.sub(' ', str(text or '').strip())


def _has_japanese(text: object) -> bool:
    return bool(_JA_RE.search(str(text or '')))


def _has_ascii(text: object) -> bool:
    return bool(_ASCII_RE.search(str(text or '')))


def _ascii_count(text: object) -> int:
    return len(_ASCII_RE.findall(str(text or '')))


class _ResolvedText(str):
    """Text whose language is already decided; later text filters return it unchanged."""

    __slots__ = ()


_PATH_LIKE_RE = re.compile(r'[A-Za-z]:[\\/]|^[\\/~]|[\\/]{2}|\\|\.[A-Za-z0-9]{1,5}(?:[\s)）]|$)')


def _is_value_like(text: str) -> bool:
    """A number, symbol run or path shown after a heading, never a language half."""
    return not _ASCII_RE.search(text) or bool(_PATH_LIKE_RE.search(text))


def _candidate_pair(left: str, right: str):
    left = _clean(left)
    right = _clean(right)
    if not left or not right:
        return None
    if not _has_japanese(left) and _is_value_like(left):
        return None
    if not _has_japanese(right) and _is_value_like(right):
        return None
    left_ja = _has_japanese(left)
    right_ja = _has_japanese(right)
    if right_ja and not left_ja:
        # Avoid treating Japanese sentences that contain short English UI terms
        # such as "Undo / Redo、..." or "Go / No-Go 判断" as bilingual
        # pairs.  A genuine bilingual pair may contain an ASCII placeholder on
        # the Japanese side, but then the English side is normally a longer
        # phrase, not a single technical token.
        if _ascii_count(right) and (len(left) < 8 or len(left.split()) < 2):
            return None
        return left, right
    if left_ja and not right_ja:
        if _ascii_count(left) and (len(right) < 8 or len(right.split()) < 2):
            return None
        return right, left
    return None


def _score_pair(en: str, ja: str, index: int) -> tuple[int, int, int, int]:
    # Prefer the split where the Japanese side is clean Japanese text.  This
    # avoids splitting English labels that themselves contain slashes, such as
    # "History / Restore Tools / 履歴/復元機能".
    return (
        1 if _has_japanese(ja) and not _has_japanese(en) else 0,
        -_ascii_count(ja),
        len(en),
        index,
    )


def _split_by_separators(text: str):
    candidates: list[tuple[tuple[int, int, int, int], str, str]] = []
    separators = (' / ', ' ｜ ', ' | ', '：', ' : ')
    for sep in separators:
        start = 0
        while True:
            idx = text.find(sep, start)
            if idx < 0:
                break
            start = idx + len(sep)
            # "見出し：値" is a heading and its value.  Only "English：日本語" can be a pair.
            if sep in ('：', ' : ') and _has_japanese(text[:idx]):
                continue
            pair = _candidate_pair(text[:idx], text[idx + len(sep):])
            if pair:
                candidates.append((_score_pair(pair[0], pair[1], idx), pair[0], pair[1]))

    # Compact "English/日本語" or "日本語/English" forms.  This is kept as a
    # fallback because paths, technical identifiers, and Japanese-only category
    # names may also contain slash characters.
    if '/' in text and not candidates and not _PATH_LIKE_RE.search(text):
        for idx, char in enumerate(text):
            if char != '/':
                continue
            pair = _candidate_pair(text[:idx], text[idx + 1:])
            if pair:
                candidates.append((_score_pair(pair[0], pair[1], idx), pair[0], pair[1]))

    if candidates:
        candidates.sort(key=lambda item: item[0], reverse=True)
        return candidates[0][1], candidates[0][2]
    return None


def _split_wrapped(text: str):
    patterns = (
        r'^\s*(.+?)\s*[（(]\s*(.+?)\s*[）)]\s*$',
        r'^\s*(.+?)\s*\[\s*(.+?)\s*\]\s*$',
    )
    for pattern in patterns:
        match = re.match(pattern, text)
        if not match:
            continue
        pair = _candidate_pair(match.group(1), match.group(2))
        if pair:
            return pair
    return None


def split_bilingual(text: object):
    if not isinstance(text, str):
        return None
    text = text.strip()
    if not text:
        return None
    return _split_by_separators(text) or _split_wrapped(text)


def is_japanese_locale(context=None) -> bool:
    try:
        prefs = getattr(context, 'preferences', None) if context is not None else None
    except Exception:
        prefs = None
    if prefs is None and bpy is not None:
        try:
            prefs = getattr(getattr(bpy, 'context', None), 'preferences', None)
        except Exception:
            prefs = None

    view = getattr(prefs, 'view', None) if prefs is not None else None
    try:
        if view is not None and hasattr(view, 'use_translate_interface'):
            if not bool(getattr(view, 'use_translate_interface', False)):
                return False
    except Exception:
        pass

    try:
        language = str(getattr(view, 'language', '') or '')
    except Exception:
        language = ''
    lowered = language.lower()
    if lowered and lowered not in {'default', 'auto'}:
        if lowered.startswith('ja') or 'japanese' in lowered or '日本' in language:
            return True
        return False

    if bpy is not None:
        try:
            locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').lower()
        except Exception:
            locale = ''
        if locale:
            return locale.startswith('ja') or 'japanese' in locale
    return False


def _root_translation_dict() -> dict:
    package = str(__package__ or '').strip()
    candidates = []
    if package:
        candidates.append(package)
        if '.' in package:
            candidates.append(package.rsplit('.', 1)[0])
    for name in candidates:
        module = sys.modules.get(name)
        value = getattr(module, 'translation_dict', None) if module is not None else None
        if isinstance(value, dict):
            return value
    return {}


def _dynamic_ja_lookup(text: str) -> str:
    table = _root_translation_dict().get('ja_JP', {})
    if not isinstance(table, dict):
        return ''
    for ctx in _TRANSLATION_CONTEXTS:
        value = table.get((ctx, text))
        if isinstance(value, str) and value:
            return value
    return ''


def _dynamic_en_lookup(text: str) -> str:
    table = _root_translation_dict().get('ja_JP', {})
    if not isinstance(table, dict):
        return ''
    for key, value in table.items():
        if value != text:
            continue
        if isinstance(key, tuple) and len(key) >= 2 and isinstance(key[1], str) and key[1]:
            return key[1]
    return ''


def _translate_with_blender(text: str, *, kind: str) -> str:
    if bpy is None or not text:
        return text
    try:
        translations = getattr(bpy.app, 'translations', None)
        if translations is None:
            return text
        if kind == 'tip':
            translated = translations.pgettext_tip(text)
        elif kind == 'data':
            translated = translations.pgettext(text)
        else:
            translated = translations.pgettext_iface(text)
        return translated or text
    except Exception:
        return text


@lru_cache(maxsize=32)
def _ordered_immutable_phrase_pairs(pairs: tuple[tuple[str, str], ...]) -> tuple[tuple[str, str], ...]:
    """Sort an immutable phrase table once while preserving longest-match semantics."""
    return tuple(sorted(pairs, key=lambda item: len(str(item[0])), reverse=True))


def _phrase_replace(text: str, pairs: Iterable[tuple[str, str]]) -> str:
    out = str(text or '')
    try:
        if isinstance(pairs, tuple):
            ordered = _ordered_immutable_phrase_pairs(pairs)
        else:
            # Mutable/custom iterables retain the original per-call behavior.
            ordered = sorted(pairs, key=lambda item: len(str(item[0])), reverse=True)
    except Exception:
        ordered = list(pairs or ())
    for src, dst in ordered:
        src = str(src or '')
        dst = str(dst or '')
        if not src or not dst:
            continue
        # Short ASCII phrases must be replaced on word boundaries only.  This
        # prevents entries such as "No" from corrupting words like "Note".
        if _has_ascii(src):
            if src.lower() not in out.lower():
                continue
            pattern = r'(?<![A-Za-z0-9_])' + re.escape(src) + r'(?![A-Za-z0-9_])'
            out = re.sub(pattern, dst, out, flags=re.IGNORECASE)
        else:
            if src not in out:
                continue
            out = out.replace(src, dst)
    return out


_REVERSE_EXACT_TRANSLATIONS = {
    dst: src
    for src, dst in dict(_EXACT_TRANSLATIONS or {}).items()
    if isinstance(src, str) and isinstance(dst, str) and src and dst and src != dst
}
_REVERSE_PHRASE_TRANSLATIONS = tuple(
    (dst, src)
    for src, dst in tuple(_PHRASE_TRANSLATIONS or ())
    if isinstance(src, str) and isinstance(dst, str) and src and dst and src != dst
)


@lru_cache(maxsize=4096)
def _phrase_replace_forward(text: str) -> str:
    """Cache immutable forward phrase translation results by source text."""
    return _phrase_replace(text, tuple(_PHRASE_TRANSLATIONS or ()))


@lru_cache(maxsize=4096)
def _phrase_replace_reverse(text: str) -> str:
    """Cache immutable reverse phrase translation results by source text."""
    return _phrase_replace(text, _REVERSE_PHRASE_TRANSLATIONS)


def _strip_ui_punctuation(text: str) -> tuple[str, str, str]:
    value = str(text or '').strip()
    prefix = ''
    suffix = ''
    while value and value[0] in {'•', '⚠'}:
        prefix += value[0]
        value = value[1:].strip()
    while value and value[-1] in {'.', ':', '…'}:
        suffix = value[-1] + suffix
        value = value[:-1].strip()
    return prefix, value, suffix


def _term_to_japanese(text: object) -> str:
    raw = _clean(text)
    if not raw:
        return raw
    if _has_japanese(raw):
        return raw
    if raw in _EXACT_TRANSLATIONS:
        direct = _EXACT_TRANSLATIONS.get(raw, '')
        if isinstance(direct, str) and direct:
            return direct
    direct = _dynamic_ja_lookup(raw)
    if direct and direct != raw:
        return direct
    translated = _phrase_replace_forward(raw.replace('_', ' '))
    return translated


def _pattern_to_japanese(text: str) -> str:
    raw = _clean(text)
    if not raw or _has_japanese(raw):
        return raw
    exact = {'—': '—', '_____': '_____'}.get(raw)
    if exact is not None:
        return exact
    prefix, body, suffix = _strip_ui_punctuation(raw)
    body = body.strip()
    if not body:
        return raw

    status_patterns = (
        (r'^\.\.\. and (.+) more$', lambda m: f'... さらに {_term_to_japanese(m.group(1))} 件'),
        (r'^\+ ?(.+) more$', lambda m: f'+ {_term_to_japanese(m.group(1))} 件'),
        (r'^No (.+) selected$', lambda m: f'{_term_to_japanese(m.group(1))}が選択されていません'),
        (r'^No (.+) found$', lambda m: f'{_term_to_japanese(m.group(1))}は見つかりませんでした'),
        (r'^No (.+) yet$', lambda m: f'{_term_to_japanese(m.group(1))}はまだありません'),
        (r'^No (.+)$', lambda m: f'{_term_to_japanese(m.group(1))}はありません'),
        (r'^(.+) missing$', lambda m: f'{_term_to_japanese(m.group(1))}がありません'),
        (r'^(.+) unavailable$', lambda m: f'{_term_to_japanese(m.group(1))}を利用できません'),
        (r'^(.+) failed$', lambda m: f'{_term_to_japanese(m.group(1))}に失敗しました'),
        (r'^(.+) cancelled$', lambda m: f'{_term_to_japanese(m.group(1))}をキャンセルしました'),
        (r'^(.+) registered$', lambda m: f'{_term_to_japanese(m.group(1))}を登録しました'),
        (r'^(.+) imported$', lambda m: f'{_term_to_japanese(m.group(1))}を読み込みました'),
        (r'^(.+) exported$', lambda m: f'{_term_to_japanese(m.group(1))}を書き出しました'),
        (r'^(.+) applied$', lambda m: f'{_term_to_japanese(m.group(1))}を適用しました'),
        (r'^(.+) updated$', lambda m: f'{_term_to_japanese(m.group(1))}を更新しました'),
        (r'^(.+) complete$', lambda m: f'{_term_to_japanese(m.group(1))}が完了しました'),
        (r'^Ready to (.+)$', lambda m: f'{_term_to_japanese(m.group(1))}の準備完了'),
        (r'^Ready for (.+)$', lambda m: f'{_term_to_japanese(m.group(1))}の準備完了'),
        (r'^Need (.+)$', lambda m: f'{_term_to_japanese(m.group(1))}が必要'),
    )
    for pattern, builder in status_patterns:
        match = re.match(pattern, body, flags=re.IGNORECASE)
        if match:
            try:
                return f'{prefix}{builder(match)}{suffix if suffix != ":" else ""}'.strip()
            except Exception:
                pass

    verb_patterns = (
        ('Open', 'を開く'), ('Show', 'を表示'), ('Hide', 'を隠す'),
        ('Enable', 'を有効化'), ('Disable', 'を無効化'), ('Toggle', 'を切り替え'),
        ('Add', 'を追加'), ('Remove', 'を削除'), ('Delete', 'を削除'), ('Clear', 'をクリア'),
        ('Copy', 'をコピー'), ('Move', 'を移動'), ('Rename', 'の名前を変更'), ('Change', 'を変更'),
        ('Select', 'を選択'), ('Deselect', 'の選択を解除'), ('Import', 'をインポート'), ('Export', 'をエクスポート'),
        ('Update', 'を更新'), ('Refresh', 'を更新'), ('Generate', 'を生成'), ('Create', 'を作成'),
        ('Validate', 'を検証'), ('Check', 'を確認'), ('Compare', 'を比較'), ('Apply', 'を適用'),
        ('Load', 'を読み込み'), ('Save', 'を保存'), ('Run', 'を実行'), ('Execute', 'を実行'),
        ('Set', 'を設定'), ('Use', 'を使用'), ('Skip', 'をスキップ'), ('Force', 'を強制'),
        ('Normalize', 'を正規化'), ('Merge', 'を結合'), ('Decimate', 'をデシメート'),
        ('Simplify', 'を簡略化'), ('Compress', 'を圧縮'), ('Resize', 'をリサイズ'),
        ('Pack', 'をパック'), ('Unpack', 'をアンパック'), ('Collect', 'を収集'), ('Render', 'をレンダー'),
    )
    for verb, jp_suffix in verb_patterns:
        if body == verb:
            return f'{prefix}{_term_to_japanese(body)}{suffix}'.strip()
        if body.lower().startswith(verb.lower() + ' '):
            target = body[len(verb):].strip()
            translated_target = _term_to_japanese(target)
            return f'{prefix}{translated_target}{jp_suffix}{suffix if suffix not in {":"} else ""}'.strip()

    sentence_patterns = (
        (r'^Press (.+) to (.+)$', lambda m: f'{_term_to_japanese(m.group(2))}するには {_term_to_japanese(m.group(1))} を押してください'),
        (r'^Please (.+)$', lambda m: f'{_term_to_japanese(m.group(1))}してください'),
        (r'^This tool will (.+)$', lambda m: f'このツールは{_term_to_japanese(m.group(1))}します'),
        (r'^This tool (.+)$', lambda m: f'このツールは{_term_to_japanese(m.group(1))}'),
        (r'^This will (.+)$', lambda m: f'これは{_term_to_japanese(m.group(1))}します'),
        (r'^Use (.+) to (.+)$', lambda m: f'{_term_to_japanese(m.group(2))}するには {_term_to_japanese(m.group(1))} を使用します'),
        (r'^Only (.+)$', lambda m: f'{_term_to_japanese(m.group(1))}のみ'),
        (r'^All (.+)$', lambda m: f'すべての{_term_to_japanese(m.group(1))}'),
        (r'^Each (.+)$', lambda m: f'各{_term_to_japanese(m.group(1))}'),
        (r'^Selected (.+)$', lambda m: f'選択中の{_term_to_japanese(m.group(1))}'),
        (r'^Current (.+)$', lambda m: f'現在の{_term_to_japanese(m.group(1))}'),
        (r'^New (.+)$', lambda m: f'新しい{_term_to_japanese(m.group(1))}'),
        (r'^Source (.+)$', lambda m: f'ソース{_term_to_japanese(m.group(1))}'),
        (r'^Target (.+)$', lambda m: f'ターゲット{_term_to_japanese(m.group(1))}'),
    )
    for pattern, builder in sentence_patterns:
        match = re.match(pattern, body, flags=re.IGNORECASE)
        if match:
            try:
                return f'{prefix}{builder(match)}{suffix}'.strip()
            except Exception:
                pass

    phrased = _term_to_japanese(body)
    if phrased != body:
        return f'{prefix}{phrased}{suffix}'.strip()
    return raw




# --- Toolset complete UI language filter v70 START ---
_MIXED_TEXT_EXTRA_PAIRS = (
    ('Smart File', 'Smart File'),
    ('Smart Fix', 'Smart Fix'),
    ('Launcher', 'ランチャー'),
    ('Goal Home', 'ゴールホーム'),
    ('Source Check', 'ソース確認'),
    ('Action Palette', 'アクションパレット'),
    ('Final Review', '最終レビュー'),
    ('Release Gate', 'リリース判定'),
    ('Workspace Report', 'ワークスペースレポート'),
    ('Handoff Report', '引き継ぎレポート'),
    ('Release Report', 'リリースレポート'),
    ('Session Bundle', 'セッションバンドル'),
    ('Root priority', 'ルート優先度'),
    ('Highest version', '最新バージョン優先'),
    ('Text Editor', 'テキストエディター'),
    ('File Browser', 'ファイルブラウザー'),
    ('Header', 'ヘッダー'),
    ('View', '表示'),
    ('Select', '選択'),
    ('Add', '追加'),
    ('Object', 'オブジェクト'),
    ('Objects', 'オブジェクト'),
    ('Collections', 'コレクション'),
    ('Collection', 'コレクション'),
    ('Append', 'アペンド'),
    ('append', 'アペンド'),
    ('Link', 'リンク'),
    ('link', 'リンク'),
    ('Import', 'インポート'),
    ('Maintain', '保守'),
    ('Publish', '公開'),
    ('Explore', '探索'),
    ('Recover', '復旧'),
    ('Preview', 'プレビュー'),
    ('History', '履歴'),
    ('Restore', '復元'),
    ('Settings', '設定'),
    ('Preferences', 'プリファレンス'),
    ('Add-on Preferences', 'アドオン設定'),
    ('Add-on', 'アドオン'),
    ('N-panel', 'Nパネル'),
    ('Properties', 'プロパティ'),
    ('Scene', 'シーン'),
    ('Home', 'ホーム'),
    ('Category', 'カテゴリ'),
    ('Categories', 'カテゴリ'),
    ('Functional Categories', '機能カテゴリ'),
    ('Advanced Controls', '詳細コントロール'),
    ('Integrated Tool', '統合ツール'),
    ('Integrated Tools', '統合ツール'),
    ('Current Source', '現在のソース'),
    ('Source', 'ソース'),
    ('Root', 'ルート'),
    ('Roots', 'ルート'),
    ('Library', 'ライブラリ'),
    ('Libraries', 'ライブラリ'),
    ('Asset', 'アセット'),
    ('Assets', 'アセット'),
    ('Entry', '項目'),
    ('Entries', '項目'),
    ('Candidate', '候補'),
    ('Candidates', '候補'),
    ('Version', 'バージョン'),
    ('Score', 'スコア'),
    ('Reason', '理由'),
    ('Change', '変更'),
    ('Matrix', 'マトリクス'),
    ('Profile', 'プロファイル'),
    ('Profiles', 'プロファイル'),
    ('Report', 'レポート'),
    ('Details', '詳細'),
    ('Quick Read', 'クイック確認'),
    ('Review', 'レビュー'),
    ('Run', '実行'),
    ('Open', '開く'),
    ('Save', '保存'),
    ('Cancel', 'キャンセル'),
    ('OK', 'OK'),
    ('ON', 'オン'),
    ('OFF', 'オフ'),
    ('Go / No-Go', '実行可否'),
    ('Go/No-Go', '実行可否'),
    ('Undo / Redo', '元に戻す/やり直し'),
    ('Undo/Redo', '元に戻す/やり直し'),
    ('root / asset / entry', 'ルート / アセット / 項目'),
    ('preview / meta / category / tags', 'プレビュー / メタ情報 / カテゴリ / タグ'),
    ('Catalog / Same folder / Roots', 'カタログ / 同一フォルダー / ルート'),
    ('ID', 'ID'),
    ('JSON', 'JSON'),
    ('OS', 'OS'),
    ('UI', 'UI'),
    ('3D View', '3Dビュー'),
    ('3D View Header', '3Dビューヘッダー'),
)
try:
    _PHRASE_TRANSLATIONS = tuple(_PHRASE_TRANSLATIONS or ()) + tuple(_MIXED_TEXT_EXTRA_PAIRS)
    _PHRASE_TRANSLATIONS = _strip_protected_phrase_pairs(_PHRASE_TRANSLATIONS)
    _phrase_replace_forward.cache_clear()
except Exception:
    pass
_REVERSE_MIXED_TEXT_EXTRA_PAIRS = tuple((ja, en) for en, ja in _MIXED_TEXT_EXTRA_PAIRS if en and ja and en != ja)
_PROTECTED_MIXED_TERMS = (
    'Smart File', 'Blender', 'catalog.json', 'scene.json', '.blend', 'JSON', 'UID', 'MD5',
    'DCL', 'DXF', 'STL', 'glTF', 'VAT', 'IKEA', 'AutoCAD', 'Autodesk',
    '3DS', 'MAX', 'FBX',
)

_JA_TO_EN_EXTRA_PHRASES = (
    ('Smart File Nパネルを開くと本体を読み込み、ツールセットの各パネルを表示します。', 'Open the Smart File N-panel to load the main tools and show each suite panel.'),
    ('Smart Fileを開く', 'Open Smart File'),
    ('Smart Fix レポートを書き出し', 'Export Smart Fix Report'),
    ('Smart Fix レポートを書き出しました', 'Exported Smart Fix Report'),
    ('Smart Fix レポート', 'Smart Fix Report'),
    ('Smart Fix 詳細を開く', 'Open Smart Fix Details'),
    ('Smart Fix 詳細を開きました', 'Opened Smart Fix Details'),
    ('Smart Fix プレビュー', 'Smart Fix Preview'),
    ('Smart Fix All を実行', 'Run Smart Fix All'),
    ('UIで開く順番', 'Order to open in the UI'),
    ('Product Readiness は商品向けの簡潔な確認、Handoff は引き継ぎ、Release は最終的な Go / No-Go 判断に使います。', 'Use Product Readiness for concise product checks, Handoff for handoff, and Release for final Go / No-Go decisions.'),
    ('3Dビュー上部の View / Select / Add / Object の横に Smart File ボタンを表示し、素早くアクセスできるようにします', 'Show the Smart File button next to View / Select / Add / Object at the top of the 3D View for quick access'),
    ('クリックすると、この機能の有効 / 無効を切り替えます。', 'Click to switch this feature between enabled and disabled.'),
    ('常時起動機能の有効 / 無効を切り替え、設定を即時保存します。', 'Switch an always-on feature on or off and save the setting immediately.'),
    ('Smart File の常時起動機能を切り替えます。設定は即時保存されます。', 'Toggle an always-on Smart File feature. The setting is saved immediately.'),
    ('Smart File を必要時に読み込み、Smart File Nパネルを開きます。', 'Load Smart File on demand and open the Smart File N-panel.'),

    ('現在の Smart File ブラウザー設定', 'current Smart File browser settings'),
    ('現在の Smart File 作業', 'current Smart File task'),
    ('Smart File のメイン画面', 'Smart File main screen'),
    ('Smart File の設定', 'Smart File settings'),
    ('Smart File を必要時に読み込み', 'load Smart File on demand'),
    ('Smart File は必要時に読み込まれます。', 'Smart File is loaded on demand.'),
    ('Smart Fileを開く', 'Open Smart File'),
    ('機能カテゴリ', 'functional categories'),
    ('カテゴリ機能', 'category tools'),
    ('カテゴリハブ', 'category hub'),
    ('カテゴリ表示', 'category view'),
    ('詳細コントロール', 'advanced controls'),
    ('統合リンクツール', 'integrated link tools'),
    ('統合アペンドツール', 'integrated append tools'),
    ('統合インポートツール', 'integrated import tools'),
    ('統合エクスポートツール', 'integrated export tools'),
    ('統合プレビューツール', 'integrated preview tools'),
    ('統合履歴/復元ツール', 'integrated history/restore tools'),
    ('統合その他ツール', 'integrated other tools'),
    ('履歴/復元', 'History/Restore'),
    ('履歴・復元', 'History/Restore'),
    ('リンク機能', 'link tools'),
    ('アペンド機能', 'append tools'),
    ('インポート機能', 'import tools'),
    ('エクスポート機能', 'export tools'),
    ('プレビュー機能', 'preview tools'),
    ('その他の機能', 'other tools'),
    ('現在のソース', 'Current Source'),
    ('ソースが選択されていません', 'No source selected'),
    ('公開準備が整っています', 'Publish-ready source'),
    ('ソース / ルート / プロファイル マトリクス', 'Source / Root / Profile Matrix'),
    ('バージョン / 公開日', 'Version / Published Date'),
    ('アセット / タイプ', 'Asset / Type'),
    ('ライブラリ / リンク中ID', 'Library / Linked IDs'),
    ('候補 / スコア / バージョン / ソース', 'Candidate / Score / Version / Source'),
    ('変更 / 理由', 'Change / Reason'),
    ('下書き / マージオプション', 'Draft / Merge Options'),
    ('ドラフト / マージ設定', 'Draft / Merge Settings'),
    ('オブジェクト / コレクション時のみ', 'Objects / Collections only'),
    ('オブジェクト/コレクションのみ', 'objects/collections only'),
    ('グループとして3Dカーソルへ', 'group to 3D cursor'),
    ('ビューにフィット', 'frame view'),
    ('3Dビューのみ', '3D View only'),
    ('3Dビュー上部', 'top of the 3D View'),
    ('3Dビューヘッダー', '3D View header'),
    ('UIで開く順番', 'order to open in the UI'),
    ('UI 上', 'in the UI'),
    ('ヘッダー', 'header'),
    ('ランチャー', 'launcher'),
    ('ゴールホーム', 'goal home'),
    ('ソース確認', 'source check'),
    ('最終レビュー', 'final review'),
    ('リリース判定', 'release gate'),
    ('実行可否', 'Go / No-Go'),
    ('作業開始', 'start work'),
    ('商品向け', 'product readiness'),
    ('引き継ぎ', 'handoff'),
    ('納品', 'delivery'),
    ('公開', 'publish'),
    ('保守', 'maintenance'),
    ('復旧', 'recovery'),
    ('探索', 'explore'),
    ('プレビュー', 'preview'),
    ('レポート', 'report'),
    ('詳細', 'details'),
    ('推奨アクション', 'recommended action'),
    ('最初の', 'first'),
    ('次の', 'next'),
    ('直前の', 'previous'),
    ('最新', 'latest'),
    ('現在', 'current'),
    ('選択中', 'selected'),
    ('選択した', 'selected'),
    ('選択', 'select'),
    ('追加', 'add'),
    ('削除', 'remove'),
    ('保存', 'save'),
    ('開く', 'open'),
    ('閉じる', 'close'),
    ('確認', 'check'),
    ('比較', 'compare'),
    ('実行', 'run'),
    ('適用', 'apply'),
    ('生成', 'generate'),
    ('読み込み', 'import'),
    ('書き出し', 'export'),
    ('設定', 'settings'),
    ('プリファレンス', 'preferences'),
    ('アドオン設定', 'Add-on Preferences'),
    ('オン・オフ', 'on/off'),
    ('オン/オフ', 'on/off'),
    ('オン', 'on'),
    ('オフ', 'off'),
    ('ルート', 'root'),
    ('アセット', 'asset'),
    ('項目', 'entry'),
    ('候補', 'candidate'),
    ('ソース', 'source'),
    ('ライブラリ', 'library'),
    ('プロファイル', 'profile'),
    ('カテゴリ', 'category'),
    ('メタデータ', 'metadata'),
    ('メタ情報', 'metadata'),
    ('タグ', 'tags'),
    ('フォルダー', 'folder'),
    ('ファイル', 'file'),
    ('ブラウザー', 'browser'),
    ('テキストエディター', 'Text Editor'),
    ('表示', 'view'),
    ('種類', 'type'),
    ('理由', 'reason'),
    ('変更', 'change'),
    ('概要', 'summary'),
    ('状態', 'status'),
    ('問題', 'issue'),
    ('欠損', 'missing'),
    ('無効', 'invalid'),
    ('有効', 'enabled'),
    ('無効化', 'disable'),
    ('有効化', 'enable'),
    ('リンク中ID', 'linked IDs'),
    ('下書き', 'draft'),
    ('マージ', 'merge'),
    ('履歴', 'history'),
    ('復元', 'restore'),
)

def _replace_pairs_case_sensitive(text: str, pairs: Iterable[tuple[str, str]]) -> str:
    out = str(text or '')
    try:
        ordered = sorted(tuple(pairs or ()), key=lambda item: len(str(item[0] or '')), reverse=True)
    except Exception:
        ordered = tuple(pairs or ())
    for src, dst in ordered:
        src = str(src or '')
        dst = str(dst or '')
        if not src or not dst or src == dst or src not in out:
            continue
        # An ASCII term never matches inside a longer word ("ON" in "CONFIG").
        pattern = re.escape(src)
        if src[0].isascii() and src[0].isalnum():
            pattern = r'(?<![A-Za-z0-9_])' + pattern
        if src[-1].isascii() and src[-1].isalnum():
            pattern = pattern + r'(?![A-Za-z0-9_])'
        out = re.sub(pattern, lambda _match, _dst=dst: _dst, out)
    return out


def _protect_mixed_terms(text: str) -> tuple[str, dict[str, str]]:
    out = str(text or '')
    restore: dict[str, str] = {}
    for index, term in enumerate(_PROTECTED_MIXED_TERMS):
        if not term or term not in out:
            continue
        token = f'\uE000SFS{index}\uE001'
        restore[token] = term
        out = out.replace(term, token)
    return out, restore


def _restore_mixed_terms(text: str, restore: dict[str, str]) -> str:
    out = str(text or '')
    for token, term in restore.items():
        out = out.replace(token, term)
    return out


def _cleanup_mixed_japanese(text: str) -> str:
    out = str(text or '')
    pair = split_bilingual(out)
    if pair:
        return pair[1]
    out, restore = _protect_mixed_terms(out)
    # Only phrases: a single word in a Japanese sentence may be a user's name.
    out = _replace_pairs_case_sensitive(out, tuple(pair for pair in _MIXED_TEXT_EXTRA_PAIRS if ' ' in pair[0]))
    out = _phrase_replace(out, tuple(pair for pair in tuple(_PHRASE_TRANSLATIONS or ()) if ' ' in str(pair[0])))
    out = out.replace('ON/OFF', 'オン/オフ').replace('on/off', 'オン/オフ')
    out = out.replace('root / asset / entry', 'ルート / アセット / 項目')
    out = out.replace('preview / meta / category / tags', 'プレビュー / メタ情報 / カテゴリ / タグ')
    out = _restore_mixed_terms(out, restore)
    out = _SPACE_RE.sub(' ', out).strip()
    # Remove spaces introduced by English-to-Japanese term replacement before
    # Japanese particles and a few compound labels.
    out = re.sub(r'([ぁ-んァ-ン一-龯々ー])\s+(を|は|が|に|へ|で|と|の|も)', r'\1\2', out)
    out = out.replace('スマート修正 レポート', 'スマート修正レポート')
    out = out.replace('スマート修正 プレビュー', 'スマート修正プレビュー')
    return out


def _cleanup_mixed_english(text: str) -> str:
    source = str(text or '')
    out = source
    pair = split_bilingual(out)
    if pair:
        return pair[0]
    exact_phrase = _replace_pairs_case_sensitive(out, _JA_TO_EN_EXTRA_PHRASES)
    if exact_phrase != out and not _has_japanese(exact_phrase):
        return exact_phrase
    direct = _dynamic_en_lookup(out) or _REVERSE_EXACT_TRANSLATIONS.get(out, '')
    if direct and not _has_japanese(direct):
        return direct
    # Prefer longer Japanese/mixed exact phrases first.  This avoids partial
    # replacements such as "レポート" -> "Report" before a complete Smart File
    # sentence can be converted into English.
    out = _replace_pairs_case_sensitive(out, _JA_TO_EN_EXTRA_PHRASES)
    out = _replace_pairs_case_sensitive(out, _REVERSE_MIXED_TEXT_EXTRA_PAIRS)
    out = _phrase_replace_reverse(out)
    out = _replace_pairs_case_sensitive(out, _JA_TO_EN_EXTRA_PHRASES)
    out = out.replace(' / ', ' / ')
    out = _SPACE_RE.sub(' ', out).strip()
    # Clean common Japanese punctuation that remains after phrase replacement.
    out = out.replace('、', ', ').replace('。', '.').replace('（', '(').replace('）', ')')
    out = out.replace('・', '/').replace('「', '"').replace('」', '"').replace('［', '[').replace('］', ']')
    out = _SPACE_RE.sub(' ', out).strip()
    # A partial conversion would rewrite user names and leave broken half-sentences.
    return source if _has_japanese(out) else out
# --- Toolset complete UI language filter v70 END ---

@lru_cache(maxsize=1)
def _reviewed_translations() -> dict:
    """Hand-reviewed table; it wins over the older generated tables."""
    try:
        from .language_extra import EXTRA_TRANSLATIONS
        return EXTRA_TRANSLATIONS if isinstance(EXTRA_TRANSLATIONS, dict) else {}
    except Exception:  # pragma: no cover
        return {}


def to_japanese(text: object, *, kind: str = 'iface', context=None) -> str:
    if isinstance(text, _ResolvedText):
        return text
    raw = _clean(text)
    if not raw:
        return raw
    pair = split_bilingual(raw)
    if pair:
        return pair[1]
    if _has_japanese(raw):
        cleaned = _cleanup_mixed_japanese(raw)
        return cleaned or raw
    reviewed = _reviewed_translations().get(('*', raw))
    if isinstance(reviewed, str) and reviewed:
        return reviewed
    if raw in _EXACT_TRANSLATIONS:
        direct = _EXACT_TRANSLATIONS.get(raw, '')
        if isinstance(direct, str) and direct:
            return direct
    direct = _dynamic_ja_lookup(raw)
    if direct and direct != raw:
        return direct
    translated = _translate_with_blender(raw, kind=kind)
    if translated and translated != raw and _has_japanese(translated):
        return translated
    patterned = _pattern_to_japanese(raw)
    if patterned and patterned != raw and not _ENGLISH_WORD_RE.search(patterned):
        return patterned
    phrased = _phrase_replace_forward(raw)
    if phrased != raw and not _ENGLISH_WORD_RE.search(phrased):
        return phrased
    return raw


def to_english(text: object, *, context=None) -> str:
    if isinstance(text, _ResolvedText):
        return text
    raw = _clean(text)
    if not raw:
        return raw
    pair = split_bilingual(raw)
    if pair:
        return pair[0]
    if _has_japanese(raw):
        # Prefer complete Japanese/mixed phrase conversions before shorter
        # runtime dictionary fragments.  This prevents English UI mode from
        # showing hybrids such as "Reportをexport".
        phrased = _cleanup_mixed_english(raw)
        if phrased and phrased != raw:
            return phrased
        direct = _dynamic_en_lookup(raw) or _REVERSE_EXACT_TRANSLATIONS.get(raw, '')
        if direct:
            cleaned_direct = _cleanup_mixed_english(direct)
            return cleaned_direct or direct
        return raw
    direct = _dynamic_en_lookup(raw) or _REVERSE_EXACT_TRANSLATIONS.get(raw, '')
    if direct and not _has_japanese(direct):
        return direct
    return raw


def ui_text(text_or_en: object, ja: object | None = None, *, context=None, kind: str = 'iface') -> str:
    if ja is not None:
        # The caller wrote both languages, and either may hold names or values.
        en_text = str(text_or_en or '').strip()
        if not is_japanese_locale(context):
            return _ResolvedText(en_text)
        ja_text = str(ja or '').strip()
        if ja_text:
            return _ResolvedText(ja_text)
        return to_japanese(en_text, kind=kind, context=context)

    if isinstance(text_or_en, _ResolvedText):
        return text_or_en
    raw = _clean(text_or_en)
    if not raw:
        return raw
    return to_japanese(raw, kind=kind, context=context) if is_japanese_locale(context) else to_english(raw, context=context)


def error_text(exc: object, *, context=None) -> str:
    """Report text for a caught exception in the interface language."""
    raw = _clean(exc)
    if not is_japanese_locale(context) or not raw or _has_japanese(raw):
        return _ResolvedText(raw)
    translated = to_japanese(raw, kind='tip', context=context)
    if translated != raw and _has_japanese(translated):
        return _ResolvedText(translated)
    return _ResolvedText(f'処理に失敗しました（詳細：{raw}）')


def iface(text_or_en: object, ja: object | None = None, *, context=None) -> str:
    return ui_text(text_or_en, ja, context=context, kind='iface')


def tip(text_or_en: object, ja: object | None = None, *, context=None) -> str:
    return ui_text(text_or_en, ja, context=context, kind='tip')


def data(text_or_en: object, ja: object | None = None, *, context=None) -> str:
    return ui_text(text_or_en, ja, context=context, kind='data')


def entry_text(entry: dict, base_key: str, *, context=None, fallback: str = '') -> str:
    ja = str(entry.get(f'{base_key}_ja') or '').strip() if isinstance(entry, dict) else ''
    en = ''
    if isinstance(entry, dict):
        en = str(entry.get(f'{base_key}_en') or entry.get(base_key) or '').strip()
    if not en:
        en = str(fallback or '').strip()
    return ui_text(en, ja, context=context)


# --- Toolset Smart File runtime UI text hook v70 START ---
# Blender 5.1 stability note:
# Global monkey-patching of bpy.types.UILayout methods can invalidate Blender's
# internal UI call path during panel drawing.  Keep these compatibility symbols
# as no-ops and use explicit ui_text()/iface()/tip() calls or local layout
# proxies instead.
_TEXT_HOOK_DEPTH = 0
_LAYOUT_TEXT_HOOKS_INSTALLED = False
_LAYOUT_TEXT_ORIGINALS = {}
_LAYOUT_TEXT_METHODS = ()
_LAYOUT_TEXT_KEYS = ()
_LEGACY_LAYOUT_TEXT_METHODS = (
    'label', 'operator', 'operator_menu_enum', 'operator_enum', 'menu',
    'menu_contents', 'popover', 'popover_group', 'prop', 'props_enum',
    'prop_enum', 'prop_menu_enum', 'prop_search', 'template_ID',
    'template_ID_preview', 'template_any_ID', 'template_search', 'separator',
)

class runtime_text_context:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


def _runtime_text_active() -> bool:
    return False


def _localize_layout_value(value: object, *, kind: str = 'iface') -> object:
    return ui_text(value, kind=kind) if isinstance(value, str) else value


def _localize_layout_call(method_name: str, args: tuple, kwargs: dict) -> tuple[tuple, dict]:
    return args, kwargs


def install_runtime_text_hooks() -> bool:
    return False


def uninstall_runtime_text_hooks() -> None:
    global _TEXT_HOOK_DEPTH, _LAYOUT_TEXT_HOOKS_INSTALLED
    _TEXT_HOOK_DEPTH = 0
    try:
        layout_type = getattr(getattr(bpy, 'types', None), 'UILayout', None) if bpy is not None else None
    except Exception:
        layout_type = None
    if layout_type is not None:
        method_names = set(_LAYOUT_TEXT_ORIGINALS.keys()) | set(_LEGACY_LAYOUT_TEXT_METHODS)
        for method_name in method_names:
            try:
                current = getattr(layout_type, method_name, None)
                original = _LAYOUT_TEXT_ORIGINALS.get(method_name) or getattr(current, '_sfs_i18n_original', None)
                if original is not None and getattr(current, '_sfs_i18n_layout_wrapped', False):
                    setattr(layout_type, method_name, original)
            except Exception:
                pass
    _LAYOUT_TEXT_HOOKS_INSTALLED = False
    _LAYOUT_TEXT_ORIGINALS.clear()
# --- Toolset Smart File runtime UI text hook v70 END ---


__all__ = [
    'data',
    'entry_text',
    'iface',
    'install_runtime_text_hooks',
    'is_japanese_locale',
    'runtime_text_context',
    'split_bilingual',
    'tip',
    'to_english',
    'to_japanese',
    'ui_text',
    'uninstall_runtime_text_hooks',
]
