# SPDX-License-Identifier: GPL-3.0-or-later
"""Naming helpers for collision-free imports."""
