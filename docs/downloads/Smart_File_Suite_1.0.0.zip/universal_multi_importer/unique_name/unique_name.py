# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Allocate names while bringing Blender library objects into the active file."""
import re
from uuid import uuid4

import bpy

_NUMBERED_NAME = re.compile(r"\.[0-9]{3}$")


def unique_name_clean_func(name):
    suffix = _NUMBERED_NAME.search(name)
    if suffix is None:
        return name, False
    return name[:suffix.start()], True


class UniqueName:
    def __init__(self):
        self.element_correspondance = {}

    @property
    def uuid(self):
        return uuid4().hex

    def get_name_collisions_from_file(self, filepath, local_names):
        occupied = set(local_names)
        with bpy.data.libraries.load(filepath, link=False) as (library, _):
            return {name: self.get_unique_name(name) for name in library.objects if name in occupied}

    def get_next_valid_name(self, name):
        return self.unique_name(-11, name, self.element_correspondance,
                                clean_func=unique_name_clean_func, register=False)

    def get_unique_name(self, name):
        return f"{name}_{self.uuid}"

    def register_element_correspondance(self, elem):
        self.element_correspondance.setdefault(elem, elem.name)

    def unique_name(self, key, name, name_dict, name_max=-1, clean_func=None, sep=".", register=True):
        previous = name_dict.get(key)
        if previous is not None:
            return previous
        occupied = set(name_dict.values())
        base = clean_func(name)[0] if clean_func else name
        proposed = base if name_max < 0 else base[:name_max]
        index = 1
        while proposed in occupied:
            suffix = f"{sep}{index:03d}"
            if name_max >= 0:
                if len(suffix) > name_max:
                    raise ValueError("The name limit cannot fit a unique suffix")
                proposed = base[:name_max - len(suffix)] + suffix
            else:
                proposed = base + suffix
            index += 1
        if register:
            name_dict[key] = proposed
        return proposed
