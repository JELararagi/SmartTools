# SPDX-License-Identifier: GPL-3.0-or-later
"""Connect this section to the Blender add-on lifecycle."""

from .._entrypoints import lifecycle
from . import blend_format, import_as_geometry_node, import_reference

modules = (blend_format, import_as_geometry_node, import_reference,)
register, unregister = lifecycle(modules)
