# SPDX-License-Identifier: GPL-3.0-or-later
"""Extension package identity helpers."""
