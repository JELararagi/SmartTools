# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Find the registered importer's module name across extension namespaces."""

import addon_utils
from pathlib import Path


class ModuleName:
    def __init__(self):
        self._module_name = None

    @property
    def module_name(self):
        if self._module_name is None:
            self._module_name = self._get_module_name()
        return self._module_name

    @staticmethod
    def _get_module_name():
        package = __package__.rsplit(".", 1)[0]
        for addon in addon_utils.modules():
            info = getattr(addon, "bl_info", {})
            if info.get("name") == "Universal Multi Importer":
                directory = Path(addon.__file__).parent.name
                prefix, separator, _ = __package__.partition(directory)
                return prefix + directory if separator else __package__ + directory
        return package
