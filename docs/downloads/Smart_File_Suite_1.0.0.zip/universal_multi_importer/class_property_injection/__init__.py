# SPDX-License-Identifier: GPL-3.0-or-later
"""Expose the package's public interfaces."""

from .class_property_injection import ClassPropertyInjection as ClassPropertyInjection


def register(classes: tuple, property_list: tuple[dict]):
    ClassPropertyInjection(classes, property_list).register()


def unregister(classes: tuple, property_list: tuple[dict]):
    ClassPropertyInjection(classes, property_list).unregister()
