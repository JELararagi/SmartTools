from __future__ import annotations

import inspect

import bpy


def _update_callback_arg_count(callback):
    try:
        sig = inspect.signature(callback)
    except Exception:
        return None
    count = 0
    for param in sig.parameters.values():
        if param.kind in (param.POSITIONAL_ONLY, param.POSITIONAL_OR_KEYWORD):
            count += 1
        elif param.kind == param.VAR_POSITIONAL:
            return 2
    return count


def _make_update_callback_compatible(callback):
    if not callable(callback) or getattr(callback, '_sfs_update_callback_compatible', False):
        return callback
    argc = _update_callback_arg_count(callback)
    def update_callback(self, context):
        if argc is None or argc >= 2:
            try:
                return callback(self, context)
            except TypeError:
                pass
        if argc == 1:
            try:
                return callback(self)
            except TypeError:
                pass
        if argc == 0:
            try:
                return callback()
            except TypeError:
                pass
        for call_args in ((self, context), (self,), ()):
            try:
                return callback(*call_args)
            except TypeError:
                continue
        return None
    try:
        update_callback.__name__ = getattr(callback, '__name__', 'update_callback')
        update_callback.__qualname__ = getattr(callback, '__qualname__', update_callback.__name__)
        update_callback.__module__ = getattr(callback, '__module__', __name__)
        update_callback._sfs_update_callback_compatible = True
    except Exception:
        pass
    return update_callback


_FACTORY_BY_TYPE = {
    "BOOLEAN": bpy.props.BoolProperty,
    "BOOL": bpy.props.BoolProperty,
    "STRING": bpy.props.StringProperty,
    "ENUM": bpy.props.EnumProperty,
    "INT": bpy.props.IntProperty,
    "INTEGER": bpy.props.IntProperty,
    "FLOAT": bpy.props.FloatProperty,
}


def _property_kwargs(definition: dict) -> dict:
    kwargs = {}
    for src, dst in (
        ("name", "name"),
        ("description", "description"),
        ("default", "default"),
        ("items", "items"),
        ("min", "min"),
        ("max", "max"),
        ("soft_min", "soft_min"),
        ("soft_max", "soft_max"),
        ("subtype", "subtype"),
        ("options", "options"),
        ("set", "set"),
        ("get", "get"),
        ("update", "update"),
        ("search", "search"),
    ):
        if src in definition and definition[src] is not None:
            value = definition[src]
            if dst == "update" and callable(value):
                value = _make_update_callback_compatible(value)
            kwargs[dst] = value
    option = definition.get("option")
    if option and "options" not in kwargs:
        kwargs["options"] = option
    return kwargs


class ClassPropertyInjection:
    """Inject bpy.props definitions into operator/property classes before registration."""

    def __init__(self, classes: tuple[type, ...], property_list: tuple[dict, ...]):
        self.classes = tuple(cls for cls in classes or () if isinstance(cls, type))
        self.property_list = tuple(item for item in property_list or () if isinstance(item, dict))

    def _make_property(self, definition: dict):
        prop_type = str(definition.get("type") or "STRING").upper()
        factory = _FACTORY_BY_TYPE.get(prop_type)
        if factory is None:
            factory = bpy.props.StringProperty
        return factory(**_property_kwargs(definition))

    def register(self):
        for cls in self.classes:
            annotations = getattr(cls, "__annotations__", None)
            if annotations is None:
                annotations = {}
                setattr(cls, "__annotations__", annotations)
            for definition in self.property_list:
                name = str(definition.get("property") or "").strip()
                if not name:
                    continue
                prop = self._make_property(definition)
                annotations[name] = prop
                try:
                    if getattr(cls, "bl_rna", None) is not None:
                        setattr(cls, name, prop)
                except Exception:
                    pass

    def unregister(self):
        for cls in self.classes:
            annotations = getattr(cls, "__annotations__", None)
            for definition in self.property_list:
                name = str(definition.get("property") or "").strip()
                if not name:
                    continue
                if isinstance(annotations, dict):
                    annotations.pop(name, None)
                try:
                    if hasattr(cls, name):
                        delattr(cls, name)
                except Exception:
                    pass
