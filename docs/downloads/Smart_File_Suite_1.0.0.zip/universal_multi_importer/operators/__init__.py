# SPDX-License-Identifier: GPL-3.0-or-later
"""Connect this section to the Blender add-on lifecycle."""

from .._entrypoints import lifecycle
from . import op_command_batcher, op_import, ui

modules = (ui, op_command_batcher, op_import,)
register, unregister = lifecycle(modules)
