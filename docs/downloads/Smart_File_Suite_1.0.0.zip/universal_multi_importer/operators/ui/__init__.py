from . import op_ul_operators, op_ul_preset, op_ul_file_selection

modules = (op_ul_operators, op_ul_preset, op_ul_file_selection)

def register():
    for m in modules:
        m.register()

def unregister():
    for m in reversed(modules):
        m.unregister()
