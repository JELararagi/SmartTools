# SPDX-License-Identifier: GPL-3.0-or-later
"""Connect this section to the Blender add-on lifecycle."""

from ..._entrypoints import lifecycle
from . import op_ul_operators, op_ul_preset, op_ul_file_selection

modules = (op_ul_operators, op_ul_preset, op_ul_file_selection,)
register, unregister = lifecycle(modules)
