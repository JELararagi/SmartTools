import bpy
import os
from ....storage_paths import user_default_dir

PRESET_FOLDER = user_default_dir('universal_multi_importer', 'presets', create=True)
COMMAND_BATCHER_PRESET_FOLDER = os.path.join(PRESET_FOLDER, 'umi','command_batcher')
UMIPRESET_EXTENSION = '.umipreset'
UMIPRESET_SPLITTER = '²@²'
