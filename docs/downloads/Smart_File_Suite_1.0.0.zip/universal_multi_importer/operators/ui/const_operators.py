# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Locations and file markers used to read and save user-owned import presets."""
from pathlib import Path
from ....storage_paths import user_default_dir

_PRESET_HOME = Path(user_default_dir("universal_multi_importer", "presets", create=True))
PRESET_FOLDER = str(_PRESET_HOME)
COMMAND_BATCHER_PRESET_FOLDER = str(_PRESET_HOME / "umi" / "command_batcher")
UMIPRESET_EXTENSION = ".umipreset"
UMIPRESET_SPLITTER = "\N{SUPERSCRIPT TWO}@\N{SUPERSCRIPT TWO}"
