# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Color and severity values consumed by the import log."""
from ...umi_const import get_umi_colors

default_color = (0.1, 0.5, 0.6)
SCROLL_OFFSET_INCREMENT = 50


def _choose(key):
    palette = get_umi_colors()
    return getattr(palette, "umi_" + key + "_color", default_color)


class LoggerColors:
    @staticmethod
    def DEFAULT_COLOR():
        return _choose("info")

    @staticmethod
    def SUCCESS_COLOR():
        return _choose("success")

    @staticmethod
    def CANCELLED_COLOR():
        return _choose("cancelled")

    @staticmethod
    def WARNING_COLOR():
        return _choose("warning")

    @staticmethod
    def ERROR_COLOR():
        return _choose("error")

    @staticmethod
    def COMMAND_COLOR():
        return _choose("command")

    @staticmethod
    def COMMAND_WARNING_COLOR():
        return _choose("command_warning")

    @staticmethod
    def IMPORT_COLOR():
        return _choose("import")


class MessageType:
    MESSAGE = "Message"
    SUCCESS = "Success"
    WARNING = "Warning"
    ERROR = "Error"
