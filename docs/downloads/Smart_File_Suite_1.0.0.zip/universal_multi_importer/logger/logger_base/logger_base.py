# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Disk and in-viewport logging for a Smart File import session."""
from dataclasses import dataclass, field
from datetime import date
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from mathutils import Color

from ....storage_paths import user_default_dir
from .logger_const import LoggerColors, MessageType


def get_log_file():
    logs = Path(user_default_dir("universal_multi_importer", "logs", create=True))
    return str(logs / f"UMI_{date.today():%Y%m%d}.log")


@dataclass
class Message:
    message: str = ""
    color: Color = field(default_factory=lambda: Color((1.0, 1.0, 1.0)))


class MessageColored:
    def __init__(self):
        self.messages = []
        self.count = 0

    def append(self, message, color=None):
        rgb = Color((1.0, 1.0, 1.0) if color is None else color)
        for start in range(0, len(message), 150):
            self.messages.append(Message(message[start:start + 150], rgb.copy()))
        self.count += 1

    def __len__(self):
        return len(self.messages)

    def __getitem__(self, index):
        return self.messages[index]


class Logger:
    def __init__(self, log_name="ROOT"):
        self.log_name = log_name
        self.logger = logging.getLogger(log_name)
        self.logger.setLevel(logging.DEBUG)
        self.log_file = get_log_file()
        self.timeformat = "%m/%d/%Y %I:%M:%S %p"
        self.set_basic_config()
        self.fontsize = 12
        self.display_debug = False
        self.color = Color(LoggerColors.DEFAULT_COLOR())
        self.clear_all()

    def set_basic_config(self):
        self.format = logging.Formatter("%(asctime)s - %(levelname)s :    %(message)s")
        destination = Path(self.log_file).resolve()
        for existing in self.logger.handlers:
            if isinstance(existing, RotatingFileHandler) and Path(existing.baseFilename) == destination:
                return
        handler = RotatingFileHandler(destination, maxBytes=500000, backupCount=3, encoding="utf-8")
        handler.setLevel(logging.DEBUG)
        handler.setFormatter(self.format)
        self.logger.addHandler(handler)

    def revert_parameters(self):
        self.clear_all()

    def _publish(self, message, label, *, raw, rgb, severity, display=True, persist=True):
        line = str(message) if raw else f"{self.log_name} : {label} - {message}"
        if display:
            self.messages.append(line, rgb)
        if persist:
            self.logger.log(severity, line)

    def info(self, message, skip_prefix=False, color=None):
        self.color = Color(LoggerColors.DEFAULT_COLOR())
        self._publish(message, "INFO", raw=skip_prefix,
                      rgb=self.color if color is None else color, severity=logging.INFO)

    def success(self, message, skip_prefix=False, show_message=True):
        self._publish(message, "SUCCESS", raw=skip_prefix,
                      rgb=LoggerColors.SUCCESS_COLOR(), severity=logging.INFO, persist=show_message)

    def debug(self, message, skip_prefix=False):
        self._publish(message, "DEBUG", raw=skip_prefix, rgb=self.color * 0.6,
                      severity=logging.DEBUG, display=self.display_debug)

    def warning(self, message, skip_prefix=False):
        self._publish(message, "WARNING", raw=skip_prefix,
                      rgb=LoggerColors.WARNING_COLOR(), severity=logging.WARNING)

    def error(self, message, skip_prefix=False):
        self._publish(message, "ERROR", raw=skip_prefix,
                      rgb=LoggerColors.ERROR_COLOR(), severity=logging.ERROR)

    def store_success(self, value):
        self.successes.append(str(value))
        self.message_types.append(MessageType.SUCCESS)

    def store_warning(self, value):
        self.warnings.append(str(value))
        self.message_types.append(MessageType.WARNING)

    def store_failure(self, value):
        self.failures.append(str(value))
        self.message_types.append(MessageType.ERROR)

    def clear_message(self):
        self.messages = MessageColored()

    def clear_success(self):
        self.successes = []

    def clear_warning(self):
        self.warnings = []

    def clear_failure(self):
        self.failures = []

    def clear_message_types(self):
        self.message_types = []

    def clear_all(self):
        self.clear_message()
        self.clear_success()
        self.clear_warning()
        self.clear_failure()
        self.clear_message_types()

    def pretty(self, text):
        return "-" * (21 + len(text))

    def separator(self):
        for line in ("", "-" * 58, ""):
            self.info(line, True)
