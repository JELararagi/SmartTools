# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Display Smart File import progress within the viewport servicing the operator."""
import blf
from .logger_base import Logger, SCROLL_OFFSET_INCREMENT


class LoggerProgress(Logger):
    def __init__(self, log_name="ROOT"):
        super().__init__(log_name)
        self.esc_message = "[Esc] to Cancel"
        self.message_offset = 15
        self.scroll_offset = 0
        self.completed = False
        self.show_log = True
        self.view3d = None

    def revert_parameters(self):
        super().revert_parameters()
        self.scroll_offset = 0
        self.completed = False

    def scroll(self, up=True, multiplier=1.0):
        direction = -1 if up else 1
        self.scroll_offset += SCROLL_OFFSET_INCREMENT * multiplier * direction

    def draw_callback_px(self, context):
        if not self.show_log and not self.completed:
            return
        blf.size(0, self.fontsize)
        spacing = self.fontsize + 3

        def draw(line, x, y, color, opacity):
            blf.color(0, color.r, color.g, color.b, opacity)
            blf.position(0, x, y, 0)
            blf.draw(0, line)

        for index, item in enumerate(reversed(self.messages)):
            draw(item.message, self.fontsize, 30 + self.scroll_offset + index * spacing, item.color, 0.8)

        area = getattr(context, "area", None)
        self.view3d = area if getattr(area, "type", "") == "VIEW_3D" else None
        if self.view3d is None:
            screen = getattr(context, "screen", None)
            self.view3d = next((item for item in getattr(screen, "areas", ()) if item.type == "VIEW_3D"), None)
        right_edge = self.view3d.width - 85 if self.view3d else 1500
        draw(self.esc_message, right_edge - self.message_offset, self.fontsize, self.color, 0.5)
        if self.completed:
            instructions = (
                ("[CTRL] + [SHIFT] + [SCROLL_WHEEL] to parse Log Faster", 250),
                ("[CTRL] + [SCROLL_WHEEL] to parse Log", 155),
            )
            for row, (hint, width) in enumerate(instructions, start=1):
                draw(hint, right_edge - width, self.fontsize + row * spacing, self.color, 0.5)

    def init_progress_importer(self, file_name):
        rule = "-" * (79 + len(file_name))
        for line in (rule, f'----------------------------- Importing File "{file_name}" -----------------------------', rule):
            self.info(line)

    def complete_progress_importer(self, duration=0, show_successes=True, size=0, batch_count=0):
        self.separator()
        self.info(f"Completed with {len(self.successes)} success(es) and {len(self.failures)} failure(s)")
        stats = [f"{duration}s"]
        if size:
            stats.append(f"{round(size, 2)}MB")
        if batch_count:
            stats.append(f"{batch_count} batche(s)")
        self.info(" | ".join(stats))
        if show_successes:
            for item in self.successes:
                self.success(item)
        for item in self.warnings:
            self.warning(item)
        for item in self.failures:
            self.error(item)
