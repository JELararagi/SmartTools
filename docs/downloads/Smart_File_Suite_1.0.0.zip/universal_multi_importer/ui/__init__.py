# SPDX-License-Identifier: GPL-3.0-or-later
"""Interface components for the batch importer."""
