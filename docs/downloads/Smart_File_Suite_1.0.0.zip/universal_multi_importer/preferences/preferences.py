import bpy
from ..bversion import BVERSION
from ..bversion.version.version import Version
from ..logger import LOG
from ..preferences.formats.properties.properties import PG_UMISettings
from ..preferences.colors.presets import color_preset
from ..preferences.colors.colors import PG_UMIColors
from ..umi_const import ADDON_PACKAGE, get_prefs
from ...ui_language_runtime import ui_text as _ui_text

PREFERENCE_TABS = [("FORMATS", "Formats", ""), ("COLORS", "Colors", ""), ("GENERAL", "General", "")]


def update_log_drawing(self, context):
    LOG.show_log = self.umi_settings.umi_global_import_settings.show_log_on_3d_view


def update_addon_dependency(self, context):
    if self.tabs == "FORMATS":
        bpy.ops.preferences.sfs_umi_check_addon_dependency()


def grid_layout(layout, alignment, size):
    row = layout.row()
    row.alignment = alignment
    row.ui_units_x = size
    return row


def draw_addon_formats(context, layout, addon_dependencies, umi_settings):
    col = layout.row(align=True)
    col.label(text="Installed Formats", icon="DOCUMENTS")
    col.ui_units_x = 4

    bbox = layout.box()
    bbox.operator("preferences.sfs_umi_check_addon_dependency", icon="FILE_REFRESH")
    if not len(addon_dependencies):
        bbox.alert = True
        bbox.label(text=_ui_text(f"Addon dependency status have to be refreshed", f"アドオンの依存関係の状態を更新してください"), icon="FILE_REFRESH")
    elif (
        umi_settings.umi_all_addon_dependencies_installed
        and umi_settings.umi_all_addon_dependencies_enabled
        and not umi_settings.umi_addon_dependency_need_reboot
    ):
        bbox.label(text=_ui_text(f"All formats are installed/enabled/updated properly", f"すべての形式が正しく入り、有効で最新です"), icon="CHECKMARK")
    elif (
        umi_settings.umi_all_addon_dependencies_installed
        and umi_settings.umi_all_addon_dependencies_enabled
        and umi_settings.umi_addon_dependency_need_reboot
    ):
        bbox.label(
            text=_ui_text(f"All formats are installed/enabled/updated properly, but before it fully works, you will have to :", f"すべての形式が正しく入り、有効で最新ですが、完全に動かすには次の操作が必要です："),
            icon="ERROR",
        )
        col = bbox.column(align=True)
        col.alert = True
        col.label(text=_ui_text(f"Disable Universal Multi Importer Addon", f"Universal Multi Importer アドオンを無効にする"), icon="RADIOBUT_ON")
        col.label(text=_ui_text(f"Restart Blender", f"Blender を再起動する"), icon="RADIOBUT_ON")
        col.label(text=_ui_text(f"Enable Universal Multi Importer Addon again", f"Universal Multi Importer アドオンをもう一度有効にする"), icon="RADIOBUT_ON")
    else:
        bbox.label(
            text=_ui_text(f"Some formats are currently not installed/enabled/updated. If you want to use them with this addon, you will have to :", f"一部の形式が入っていないか、無効か、古くなっています。このアドオンで使うには次の操作が必要です："),
            icon="ERROR",
        )
        col = bbox.column(align=True)
        col.alert = True
        col.label(
            text=_ui_text(f"Install/Enable/Update the formats by clicking on the install/enable/update button below", f"下のボタンで形式を入れる・有効にする・更新する"),
            icon="RADIOBUT_ON",
        )
        col.label(text=_ui_text(f"Disable Universal Multi Importer Addon", f"Universal Multi Importer アドオンを無効にする"), icon="RADIOBUT_ON")
        col.label(text=_ui_text(f"Restart Blender", f"Blender を再起動する"), icon="RADIOBUT_ON")
        col.label(text=_ui_text(f"Enable Universal Multi Importer Addon again", f"Universal Multi Importer アドオンをもう一度有効にする"), icon="RADIOBUT_ON")

    main_box = layout.box()
    has_external_addon = False

    col1 = main_box.column(align=True)
    col2 = main_box.column(align=True)
    col3 = main_box.column(align=True)
    col4 = main_box.column(align=True)

    row1 = col1.row()
    row2 = col2.row()

    grid_layout(row1, alignment="CENTER", size=4).label(text="File Format")
    grid_layout(row1, alignment="CENTER", size=6).label(text="Addon")
    grid_layout(row1, alignment="CENTER", size=6).label(text="Version")
    grid_layout(row1, alignment="CENTER", size=4).label(text="Installed")
    grid_layout(row1, alignment="CENTER", size=4).label(text="Enable")

    grid_layout(row2, alignment="CENTER", size=4).label(text="_____")
    grid_layout(row2, alignment="CENTER", size=6).label(text="_____")
    grid_layout(row2, alignment="CENTER", size=6).label(text="_____")
    grid_layout(row2, alignment="CENTER", size=4).label(text="_____")
    grid_layout(row2, alignment="CENTER", size=4).label(text="_____")

    for ad in addon_dependencies.values():
        name = ad.format_name
        addon_name = ad.addon_name if len(ad.addon_name) else f"Built-in {ad.module_name}"
        supported_version = Version(ad.supported_version)
        local_version = Version(ad.local_version)

        need_update = ad.is_outdated and local_version < supported_version

        if not ad.is_installed and len(ad.addon_name) > 0:
            if ad.external_addon:
                version = "-----"
            else:
                version = f"{ad.remote_version} available"
        elif need_update:
            version = _ui_text(f"{ad.local_version} (outdated {ad.remote_version})", f'{ad.local_version}（新しい版 {ad.remote_version}）')
        else:
            version = f"{ad.local_version}" if ad.local_version != "0.0.0" else "-----"

        addon_diplay_name = addon_name.split(".")[2] if ad.is_extension else addon_name
        row = col3.row()

        grid_layout(row, alignment="CENTER", size=4).label(text=name, translate=False)
        grid_layout(row, alignment="CENTER", size=6).label(text=addon_diplay_name, translate=False)

        if not ad.is_installed and len(ad.addon_name) > 0:
            grid_layout(row, alignment="CENTER", size=6).label(text=version)
        elif need_update:
            if not context.preferences.system.use_online_access:
                grid_layout(row, alignment="CENTER", size=6).operator(
                    "extensions.userpref_allow_online", text=version, icon="INTERNET_OFFLINE"
                )
            else:
                op = grid_layout(row, alignment="CENTER", size=6).operator(
                    "extensions.sfs_universal_multi_importer_install_extension", text=version, icon="FILE_REFRESH"
                )
                op.pkg_id = ad.pkg_id
                op.repo_index = 0

        else:
            grid_layout(row, alignment="CENTER", size=6).label(text=version)

        if len(ad.addon_name) == 0:
            grid_layout(row, alignment="CENTER", size=4).label(text="", icon="CHECKMARK")

        # installed
        elif ad.is_installed:
            grid_layout(row, alignment="CENTER", size=4).label(text="", icon="CHECKMARK")
        else:
            if BVERSION < 4.2:
                op = grid_layout(row, alignment="CENTER", size=4).operator("wm.url_open", text=_ui_text(f"Open {name} url", f"{name} の URL を開く"))
                op.url = ad.pkg_url
                grid_layout(row, alignment="CENTER", size=4).label(text="", icon="X")
                continue

            if not context.preferences.system.use_online_access and not ad.external_addon:
                grid_layout(row, alignment="CENTER", size=4).operator(
                    "extensions.userpref_allow_online", text="Allow Online Access"
                )

            elif ad.is_extension:
                op = grid_layout(row, alignment="CENTER", size=4).operator(
                    "extensions.sfs_universal_multi_importer_install_extension", text=_ui_text(f"Install {name}", f"{name} を入れる")
                )
                op.pkg_id = ad.pkg_id
                op.repo_index = 0

            elif ad.external_addon:
                has_external_addon = True
                op = grid_layout(row, alignment="CENTER", size=4).operator("wm.url_open", text="Download Manually*")
                op.url = ad.pkg_url
                grid_layout(row, alignment="CENTER", size=4).label(text="", icon="X")
                continue

            grid_layout(row, alignment="CENTER", size=4).label(text="", icon="X")

        # Enabled
        if ad.is_installed and ad.is_enabled or len(ad.addon_name) == 0:
            grid_layout(row, alignment="CENTER", size=4).label(text="", icon="CHECKMARK")

        elif ad.is_installed and not ad.is_enabled:
            op = grid_layout(row, alignment="CENTER", size=4).operator(
                "preferences.sfs_universal_multi_importer_enable_addon", text=_ui_text(f"Enable {addon_name}", f"{addon_name} を有効にする")
            )
            op.module = addon_name

    if has_external_addon:
        row = main_box.row()
        row.alert = True
        row.label(
            text="*This add-on is not a Blender Extension. Download and install it manually so Universal Multi Importer can use it."
        )




class PreferencesProxy(bpy.types.PropertyGroup):
    umi_settings: bpy.props.PointerProperty(type=PG_UMISettings)
    umi_colors: bpy.props.PointerProperty(type=PG_UMIColors)
    tabs: bpy.props.EnumProperty(name='Tabs', items=PREFERENCE_TABS, default='FORMATS', update=update_addon_dependency)


def get_integrated_preferences_proxy(context=None, pref_cls=None, record=None):
    try:
        return get_prefs(context=context)
    except Exception:
        return None

class UMI_PG_preferences_view(bpy.types.AddonPreferences):
    bl_label = 'Universal Multi Importer Preferences'
    bl_idname = ADDON_PACKAGE

    umi_settings: bpy.props.PointerProperty(type=PG_UMISettings)

    umi_colors: bpy.props.PointerProperty(type=PG_UMIColors)

    tabs: bpy.props.EnumProperty(name="Tabs", items=PREFERENCE_TABS, default="FORMATS", update=update_addon_dependency)

    def grid_layout(self, layout, alignment, size):
        row = layout.row()
        row.alignment = alignment
        row.ui_units_x = size
        return row

    def draw(self, context):
        layout = UMI_PG_preferences_view.layout
        column = layout.column(align=True)
        row = column.row()
        row.prop(self, "tabs", expand=True)

        addon_dependencies = self.umi_settings.umi_addon_dependencies

        box = column.box()
        box.use_property_split = True
        box.use_property_decorate = False
        if self.tabs == "FORMATS":
            draw_addon_formats(context, box, addon_dependencies, self.umi_settings)

        elif self.tabs == "COLORS":
            col = box.row(align=True)
            col.label(text="Theme", icon="IMAGE_BACKGROUND")
            color_preset.panel_func(col)
            box.prop(self.umi_colors, "umi_info_color")
            box.prop(self.umi_colors, "umi_success_color")
            box.prop(self.umi_colors, "umi_cancelled_color")
            box.prop(self.umi_colors, "umi_warning_color")
            box.prop(self.umi_colors, "umi_error_color")
            box.prop(self.umi_colors, "umi_command_color")
            box.prop(self.umi_colors, "umi_command_warning_color")
            box.prop(self.umi_colors, "umi_import_color")

        elif self.tabs == "GENERAL":
            box.prop(self.umi_settings, "umi_window_width")


def _umi_class_has_bl_rna(cls):
    """Return True only for classes Blender has fully registered.

    Blender 5.1/Python 3.13 may expose an inherited placeholder ``bl_rna`` on
    unregistered PropertyGroup subclasses.  PointerProperty rejects that state
    with a missing-bl_rna error, so the class also has to be present in
    ``bpy.types`` under its RNA class name.
    """
    if not isinstance(cls, type):
        return False
    try:
        bl_rna = getattr(cls, "bl_rna", None)
        identifier = str(getattr(bl_rna, "identifier", "") or "").strip()
    except Exception:
        return False
    if not identifier or identifier in {"PropertyGroup", "Operator", "Panel", "Menu", "AddonPreferences"}:
        return False
    try:
        if bool(getattr(cls, "is_registered", False)):
            return True
        return getattr(bpy.types, identifier, None) is cls
    except Exception:
        return False


def _umi_safe_register_class(cls):
    if not isinstance(cls, type) or _umi_class_has_bl_rna(cls):
        return
    try:
        bpy.utils.register_class(cls)
    except Exception:
        try:
            bpy.utils.unregister_class(cls)
            bpy.utils.register_class(cls)
        except Exception:
            pass


def _umi_safe_unregister_class(cls):
    if not isinstance(cls, type):
        return
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


classes = (PreferencesProxy, UMI_PG_preferences_view)


def register():
    for cls in classes:
        _umi_safe_register_class(cls)


def unregister():
    for cls in reversed(classes):
        _umi_safe_unregister_class(cls)


if __name__ == "__main__":
    register()
