# SPDX-License-Identifier: GPL-3.0-or-later
"""Connect this section to the Blender add-on lifecycle."""

from ..._entrypoints import lifecycle
from . import log_file

try:
    from . import check_addon_dependencies
except Exception:
    check_addon_dependencies = None

modules = (log_file,) + ((check_addon_dependencies,) if check_addon_dependencies is not None else ())
register, unregister = lifecycle(modules)
