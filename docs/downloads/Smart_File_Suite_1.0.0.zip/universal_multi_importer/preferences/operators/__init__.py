from . import log_file

try:
    from . import check_addon_dependencies
except Exception:
    check_addon_dependencies = None

modules = tuple(m for m in (log_file, check_addon_dependencies) if m is not None)


def register():
    for m in modules:
        m.register()


def unregister():
    for m in reversed(modules):
        m.unregister()
