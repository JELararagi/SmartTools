import bpy
import os
from ....storage_paths import user_default_dir


def get_latest_log_file():
    logdir = user_default_dir('universal_multi_importer', 'logs', create=True)
    try:
        logfiles = [f for f in os.listdir(logdir) if os.path.basename(f).startswith("UMI_")]
    except Exception:
        logfiles = []
    if not logfiles:
        return ""
    logfiles = sorted(logfiles, reverse=True)
    return os.path.join(logdir, logfiles[0])


class SFS_OT_universal_multi_importer_open_log_file(bpy.types.Operator):
    bl_idname = 'wm.sfs_universal_multi_importer_open_log_file'
    bl_label = 'Open Log File'
    bl_options = {'UNDO'}
    bl_description = "Open Last Log File"

    def execute(self, context):
        log_file = get_latest_log_file()
        if not os.path.exists(log_file):
            self.report({"ERROR"}, "Universal Multi Importer: No valid log file found")
            return {"CANCELLED"}

        filename = os.path.basename(log_file)
        if filename in bpy.data.texts:
            bpy.data.texts.remove(bpy.data.texts[filename])

        bpy.data.texts.load(log_file)

        text = bpy.data.texts[filename]

        bpy.ops.wm.window_new()
        log_win = context.window_manager.windows[-1]
        log_ed = log_win.screen.areas[0]
        log_ed.type = "TEXT_EDITOR"
        log_ed.spaces[0].text = text
        log_ed.spaces[0].show_line_numbers = False
        log_ed.spaces[0].show_syntax_highlight = False
        bpy.ops.text.move(type="FILE_TOP")

        return {"FINISHED"}


classes = (SFS_OT_universal_multi_importer_open_log_file,)


def register():
    from bpy.utils import register_class

    for cls in classes:
        register_class(cls)


def unregister():
    from bpy.utils import unregister_class

    for cls in reversed(classes):
        unregister_class(cls)
