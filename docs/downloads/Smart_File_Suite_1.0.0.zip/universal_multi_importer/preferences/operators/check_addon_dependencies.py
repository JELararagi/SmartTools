# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy
import addon_utils
from bpy.props import IntProperty, StringProperty

from ...bversion.version.version import Version
from ...umi_const import get_prefs
from ....ui_language_runtime import ui_text as _ui_text
from ....ui_language_runtime import error_text as _sf_error_text


def _version_to_text(value) -> str:
    try:
        return str(value)
    except Exception:
        return "0.0.0"


def _addon_module(addon_name: str):
    if not addon_name:
        return None
    try:
        for module in addon_utils.modules():
            if getattr(module, "__name__", "") == addon_name:
                return module
    except Exception:
        pass
    return None


def _addon_local_version(addon_name: str) -> str:
    module = _addon_module(addon_name)
    try:
        info = getattr(module, "bl_info", {}) if module is not None else {}
        version = info.get("version", (0, 0, 0)) if isinstance(info, dict) else (0, 0, 0)
        return _version_to_text(Version(version))
    except Exception:
        return "0.0.0"


def _addon_enabled(addon_name: str) -> bool:
    if not addon_name:
        return True
    try:
        return addon_name in bpy.context.preferences.addons
    except Exception:
        return False




def _operator_exists(bl_idname: str) -> bool:
    try:
        prefix, suffix = str(bl_idname or '').split('.', 1)
    except ValueError:
        return False
    try:
        return isinstance(getattr(bpy.types, f"{prefix.upper()}_OT_{suffix}", None), type)
    except Exception:
        return False

def _addon_installed(addon_name: str) -> bool:
    if not addon_name:
        return True
    return _addon_enabled(addon_name) or _addon_module(addon_name) is not None


def _refresh_dependency_state(context=None) -> tuple[int, int, int]:
    prefs = get_prefs(context=context)
    settings = getattr(prefs, "umi_settings", None)
    if settings is None:
        raise RuntimeError("Universal Multi Importer N-panel settings are not ready")

    from ..formats import COMPATIBLE_FORMATS

    collection = settings.umi_addon_dependencies
    collection.clear()

    missing = 0
    disabled = 0
    outdated = 0

    for fmt in getattr(COMPATIBLE_FORMATS, "formats", ()) or ():
        operators = getattr(getattr(fmt, "operators", None), "operators", {}) or {}
        for module_name, operator in operators.items():
            addon_name = str(getattr(operator, "addon_name", "") or "")
            supported_version = _version_to_text(getattr(operator, "supported_version", "0.0.0") or "0.0.0")
            local_version = "0.0.0" if not addon_name else _addon_local_version(addon_name)
            installed = _addon_installed(addon_name)
            enabled = _addon_enabled(addon_name)
            try:
                is_outdated = bool(installed and addon_name and Version(local_version) < Version(supported_version))
            except Exception:
                is_outdated = False

            item = collection.add()
            item.name = f"{getattr(fmt, 'name', '')}:{module_name}"
            item.format_name = str(getattr(fmt, "name", "") or "")
            item.module_name = str(module_name or "")
            item.addon_name = addon_name
            item.pkg_id = str(getattr(operator, "pkg_id", "") or "")
            item.pkg_url = str(getattr(operator, "pkg_url", "") or "")
            item.external_addon = bool(getattr(operator, "external_addon", False))
            item.local_version = local_version
            item.remote_version = "0.0.0"
            item.supported_version = supported_version
            item.is_extension = addon_name.startswith("bl_ext.") or bool(getattr(operator, "pkg_id", ""))
            item.is_installed = installed
            item.is_enabled = enabled
            item.is_outdated = is_outdated

            if not installed:
                missing += 1
            if installed and not enabled:
                disabled += 1
            if is_outdated:
                outdated += 1

    settings.umi_all_addon_dependencies_installed = missing == 0
    settings.umi_all_addon_dependencies_enabled = disabled == 0
    try:
        settings.umi_addon_dependency_need_reboot = bool(getattr(COMPATIBLE_FORMATS, "need_reboot", False))
    except Exception:
        settings.umi_addon_dependency_need_reboot = False
    return missing, disabled, outdated


class SFS_OT_universal_multi_importer_check_addon_dependency(bpy.types.Operator):
    bl_idname = 'preferences.sfs_umi_check_addon_dependency'
    bl_label = 'Check Addon Dependency'
    bl_description = "Refresh Universal Multi Importer dependency status in the Smart File N-panel settings. It checks which importer add-ons are installed, enabled, or below the supported version."

    bl_options = set()
    _sms_no_undo = True
    def execute(self, context):
        try:
            missing, disabled, outdated = _refresh_dependency_state(context)
        except Exception as exc:
            self.report({"WARNING"}, _sf_error_text(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, _ui_text(f"Universal Multi Importer dependencies refreshed: missing {missing}, disabled {disabled}, outdated {outdated}", f"依存関係を更新しました：なし {missing}、無効 {disabled}、古い {outdated}"))
        return {"FINISHED"}


class SFS_OT_universal_multi_importer_open_addon_dependency_status(bpy.types.Operator):
    bl_idname = 'preferences.sfs_umi_open_dependency_status'
    bl_label = 'Open Addon Dependency Status'
    bl_description = "Refresh dependency status and switch the integrated Universal Multi Importer settings to the Formats tab in the Smart File N-panel."

    bl_options = set()
    _sms_no_undo = True
    def execute(self, context):
        result = bpy.ops.preferences.sfs_umi_check_addon_dependency()
        try:
            prefs = get_prefs(context=context)
            prefs.tabs = "FORMATS"
        except Exception:
            pass
        return result


class SFS_OT_universal_multi_importer_enable_addon(bpy.types.Operator):
    bl_idname = 'preferences.sfs_universal_multi_importer_enable_addon'
    bl_label = 'Enable Addon'
    bl_description = "Enable the selected importer add-on and refresh Universal Multi Importer dependency status."

    module: StringProperty(name="Module", default="")

    bl_options = {'UNDO'}
    def execute(self, context):
        module = str(getattr(self, "module", "") or "").strip()
        if not module:
            self.report({"WARNING"}, "No add-on module was specified")
            return {"CANCELLED"}
        try:
            addon_utils.enable(module, default_set=True, persistent=True)
        except Exception as exc:
            self.report({"WARNING"}, _ui_text(f"Could not enable {module}: {exc}", f"{module} を有効にできませんでした：{exc}"))
            return {"CANCELLED"}
        try:
            _refresh_dependency_state(context)
        except Exception:
            pass
        self.report({"INFO"}, _ui_text(f"Enabled {module}", f"{module} を有効にしました"))
        return {"FINISHED"}


class SFS_OT_universal_multi_importer_install_extension(bpy.types.Operator):
    bl_idname = 'extensions.sfs_universal_multi_importer_install_extension'
    bl_label = 'Install Extension'
    bl_description = "Open or refresh Blender extension installation flow for this dependency. If Blender cannot install it automatically, use the listed extension URL and refresh dependencies after installation."

    pkg_id: StringProperty(name="Package ID", default="")
    repo_index: IntProperty(name="Repository Index", default=0)

    bl_options = set()
    _sms_no_undo = True
    def execute(self, context):
        try:
            if _operator_exists("extensions.repo_sync_all"):
                bpy.ops.extensions.repo_sync_all()
        except Exception:
            pass
        try:
            _refresh_dependency_state(context)
        except Exception:
            pass
        pkg_id = str(getattr(self, "pkg_id", "") or "").strip()
        if pkg_id:
            self.report({"INFO"}, _ui_text(f"Refresh complete. Install or update extension package '{pkg_id}' from Blender Extensions, then check dependencies again.", f"更新の確認が終わりました。Blender Extensions から拡張機能のパッケージ「{pkg_id}」を入れるか更新し、依存関係をもう一度確かめてください。"))
        else:
            self.report({"INFO"}, "Refresh complete. Install or update the required extension from Blender Extensions, then check dependencies again.")
        return {"FINISHED"}


classes = (
    SFS_OT_universal_multi_importer_check_addon_dependency,
    SFS_OT_universal_multi_importer_open_addon_dependency_status,
    SFS_OT_universal_multi_importer_enable_addon,
    SFS_OT_universal_multi_importer_install_extension,
)


def register():
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except ValueError:
            pass


def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
