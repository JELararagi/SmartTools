import bpy
from ...preferences.formats import panels


from ...preferences.formats.format_definition import FormatDefinition

FORMATS = [f for f in dir(FormatDefinition) if not f.startswith("_")]

from ...preferences.formats.format_compatible import CompatibleFormats

COMPATIBLE_FORMATS = CompatibleFormats()

from ...preferences.formats.properties import properties
from ...preferences.formats.format_class_creator import FormatClassCreator, ClassFactory


def _umi_class_has_bl_rna(cls):
    """Return True only for classes Blender has fully registered.

    Blender 5.1/Python 3.13 may expose an inherited placeholder ``bl_rna`` on
    unregistered PropertyGroup subclasses.  PointerProperty rejects that state
    with a missing-bl_rna error, so the class also has to be present in
    ``bpy.types`` under its RNA class name.
    """
    if not isinstance(cls, type):
        return False
    try:
        bl_rna = getattr(cls, "bl_rna", None)
        identifier = str(getattr(bl_rna, "identifier", "") or "").strip()
    except Exception:
        return False
    if not identifier or identifier in {"PropertyGroup", "Operator", "Panel", "Menu", "AddonPreferences"}:
        return False
    try:
        if bool(getattr(cls, "is_registered", False)):
            return True
        return getattr(bpy.types, identifier, None) is cls
    except Exception:
        return False


def _umi_lookup_registered_class(cls):
    if not isinstance(cls, type):
        return None
    identifiers = [
        str(getattr(cls, "__name__", "") or "").strip(),
        str(getattr(cls, "bl_idname", "") or "").strip(),
    ]
    try:
        bl_idname = str(getattr(cls, "bl_idname", "") or "").strip()
        if "." in bl_idname:
            prefix, suffix = bl_idname.split(".", 1)
            identifiers.append(f"{prefix.upper()}_OT_{suffix}")
    except Exception:
        pass
    seen = set()
    for identifier in [value for value in identifiers if value and not (value in seen or seen.add(value))]:
        try:
            existing = getattr(bpy.types, identifier, None)
            if isinstance(existing, type):
                return existing
        except Exception:
            pass
    return None

def _umi_ensure_pointer_target(cls) -> bool:
    if _umi_class_has_bl_rna(cls):
        return True
    if not isinstance(cls, type):
        return False
    existing = _umi_lookup_registered_class(cls)
    if existing is cls and _umi_class_has_bl_rna(existing):
        return True
    for candidate in (existing, cls if existing is cls else None):
        if not isinstance(candidate, type):
            continue
        try:
            bpy.utils.unregister_class(candidate)
        except Exception:
            pass
    try:
        bpy.utils.register_class(cls)
    except Exception:
        try:
            existing = _umi_lookup_registered_class(cls)
            for candidate in (existing, cls if existing is cls else None):
                if not isinstance(candidate, type):
                    continue
                try:
                    bpy.utils.unregister_class(candidate)
                except Exception:
                    pass
            bpy.utils.register_class(cls)
        except Exception:
            return False
    return _umi_class_has_bl_rna(cls)



# function to register dynamically generated classes for each compatible formats
def register_import_setting_class():
    for f in COMPATIBLE_FORMATS.formats:
        if f"{f.name}_module" not in modules:
            continue

        cl = modules[f"{f.name}_module"]
        if not _umi_ensure_pointer_target(cl):
            continue
        properties.PG_ImportSettings.__annotations__[f"{f.name}_import_module"] = bpy.props.PointerProperty(type=cl)
        for name in f.operators.operators.keys():
            if f"{f.name}_{name}_settings" not in modules:
                continue

            cl = modules[f"{f.name}_{name}_settings"]
            if not _umi_ensure_pointer_target(cl):
                continue
            properties.PG_ImportSettings.__annotations__[f"{f.name}_{name}_import_settings"] = (
                bpy.props.PointerProperty(type=cl)
            )

    properties.PG_ImportSettings.umi_import_settings_registered = True


def register():
    class_parser = FormatClassCreator()
    class_parser.register_compatible_formats()
    register_import_setting_class()
    panels.register()
    properties.register()


def unregister():
    properties.unregister()
    panels.unregister()
    class_parser = FormatClassCreator()
    class_parser.unregister_compatible_formats()


def get_import_modules():
    modules = {}
    for f in COMPATIBLE_FORMATS.formats:
        module_items = [
            (m.upper(), m.title().replace("_", " "), f.operators.operators[m].description)
            for m in f.operators.operators.keys()
        ]
        c = ClassFactory(f"UMI_{f.name}_module", None, bpy.types.PropertyGroup)
        c.__annotations__["name"] = bpy.props.EnumProperty(items=module_items, name="Import Module")
        modules[f"{f.name}_module"] = c

        for name in f.operators.operators.keys():
            c = ClassFactory(f"UMI_{f.name}_{name}_settings", None, bpy.types.PropertyGroup)
            c.__annotations__["name"] = bpy.props.StringProperty(name="Import Setting Name", default=f"{f.name}_{name}")
            modules[f"{f.name}_{name}_settings"] = c

    return modules


modules = get_import_modules()
