from ._format_layout import FormatSettings


class IMPORT_SCENE_ABCSettings(FormatSettings):
    groups = (
        ("ABCSettings_transform", "Manual Transform", "OBJECT_DATA",
         ('scale',)),
        ("ABCSettings_options", "Options", "OPTIONS",
         ('relative_path', 'set_frame_range', 'is_sequence', 'validate_meshes', 'always_add_cache_reader')),
    )
