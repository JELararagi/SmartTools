from ._format_layout import FormatSettings


class IMPORT_SCENE_SOUNDSettings(FormatSettings):
    groups = (
        ("AUDIOSettings_options", "Options", "OPTIONS",
         ('relative_path', 'cache', 'mono')),
    )
