from ._format_layout import FormatSettings


class IMPORT_SCENE_VDBSettings(FormatSettings):
    geometry_node_group = "VDBGNSettings"
    default_provider_only = True
    groups = (
        ("VDBSettings_transform", "Options", "OPTIONS",
         ('relative_path', 'use_sequence_detection', 'align', 'location', 'rotation')),
    )
