# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Settings shown for Blender's built-in OBJ importer."""

from ....ui.panel import draw_import_as_geometry_node_settings, draw_panel, draw_version_warning


_SETTINGS = (
    ("Transform", "OBJECT_DATA", ("global_scale", "clamp_size", "forward_axis", "up_axis")),
    ("Options", "OPTIONS", ("use_split_objects", "use_split_groups",
                             "import_vertex_groups", "validate_meshes", "collection_separator")),
    ("Materials", "MATERIAL", ("mtl_name_collision_mode",)),
)


class IMPORT_SCENE_OBJSettings:
    @draw_version_warning
    def draw(self, operator, module_name, layout):
        layout.use_property_split = True
        layout.use_property_decorate = False
        if module_name == "geometry_node":
            draw_import_as_geometry_node_settings(layout, operator, "OBJGNSettings")
        elif module_name == "default":
            for section, icon, properties in _SETTINGS:
                draw_panel(layout, [(operator, key) for key in properties],
                           f"OBJSettings_{section}", section, icon=icon)
