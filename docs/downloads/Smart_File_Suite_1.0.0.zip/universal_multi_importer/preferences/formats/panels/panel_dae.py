from ._format_layout import FormatSettings
from ....bversion import BVERSION


class IMPORT_SCENE_DAESettings(FormatSettings):
    groups = (
        ("DAESettings_Options", "Import Data Options", "MESH_DATA",
         ('import_units', 'custom_normals')),
        ("DAESettings_Armature", "Armature", "ARMATURE_DATA",
         ('fix_orientation', 'find_chains', 'auto_connect', 'min_chain_length')),
        ("DAESettings_Misc", "Miscandelous", "PRESET",
         ('keep_bind_info',)),
    )

    def draw_format_settings(self, layout, options, provider):
        groups = self.groups
        if BVERSION < 3.4:
            key, title, icon, _ = groups[0]
            groups = ((key, title, icon, ("import_units",)), *groups[1:])
        self.draw_groups(layout, options, groups)
