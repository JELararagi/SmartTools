# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Settings for the DXF importer on the supported Blender version."""

from ....ui.panel import draw_panel, draw_version_warning


def _section(layout, options, identifier, label, icon, *fields, **state):
    return draw_panel(
        layout, [(options, name) for name in fields],
        f"DXFSettings_{identifier}", label, icon=icon, **state,
    )[1]


def _linked_fields(layout, options, enabled, *fields):
    group = layout.column()
    group.enabled = enabled
    for name in fields:
        group.prop(options, name)


class IMPORT_SCENE_DXFSettings:
    @draw_version_warning
    def draw(self, operator, module_name, layout):
        layout.use_property_split = True
        layout.use_property_decorate = False

        _section(layout, operator, "Import", "Import Options", "IMPORT",
                 "scene_options", "collection_options")

        merge = _section(layout, operator, "MergeOptions", "Merge Options", "AUTOMERGE_ON",
                         "block_options", "do_bbox", "merge")
        if merge is not None:
            _linked_fields(merge, operator, operator.merge, "merge_options")
            merge.prop(operator, "merge_lines")

        width = _section(layout, operator, "Thickness", "Line Thickness and Width", "MOD_OUTLINE",
                         "represent_thickness_and_width")
        if width is not None:
            thickness = operator.represent_thickness_and_width
            _linked_fields(width, operator, not thickness, "import_atts")
            # This setting is serialized by the importer when switching modes.
            if thickness or not operator.merge:
                operator.import_atts = operator.merge

        _section(layout, operator, "OptionalObjects", "Optional Objects", "IMPORT",
                 "import_text", "import_light", "export_acis")
        _section(layout, operator, "ViewOptions", "View Options", "RESTRICT_VIEW_OFF",
                 "outliner_groups", "recenter")

        geo = _section(layout, operator, "GeoReferencing", "Geo Referencing", "PROPERTIES",
                       "dxf_indi", "dxf_scale", set_header_boolean=True,
                       header_bool=[operator, "use_georeferencing"])
        if geo is not None:
            _linked_fields(geo, operator, operator.dxf_indi == "SPHERICAL",
                           "merc_scene_lat", "merc_scene_lon")
