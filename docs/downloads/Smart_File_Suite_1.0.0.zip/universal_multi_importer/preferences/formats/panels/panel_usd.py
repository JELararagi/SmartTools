# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Present the built-in USD importer's scene, mesh and texture settings."""

from ....ui.panel import draw_panel, draw_version_warning


def _section(layout, settings, name, label, icon, properties, collapsed=False):
    _, body = draw_panel(layout, [(settings, key) for key in properties],
                         f"USDSettings_{name}", label, icon=icon, default_closed=collapsed)
    return body


class IMPORT_SCENE_USDSettings:
    @draw_version_warning
    def draw(self, operator, module_name, layout):
        layout.use_property_split = True
        layout.use_property_decorate = False
        _section(layout, operator, "General", "General", "IMPORT",
                 ("prim_path_mask", "import_visible_only", "import_defined_only", "set_frame_range",
                  "create_collection", "relative_path", "scale", "light_intensity_scale", "property_import_mode"))
        heading, object_types = layout.panel(idname="USDSettings_ObjectTypes")
        heading.label(text="Object Types", icon="IMPORT")
        if object_types:
            columns = object_types.row(align=True)
            for names in (("import_cameras", "import_curves", "import_lights",
                           "create_world_material", "import_materials"),
                          ("import_meshes", "import_volumes", "import_points", "import_shapes")):
                group = columns.column(align=True)
                for key in names:
                    group.prop(operator, key)
        _section(layout, operator, "DisplayPurpose", "Display Purpose", "RESTRICT_VIEW_OFF",
                 ("import_render", "import_proxy", "import_guide", "mtl_purpose"))
        _section(layout, operator, "Geometry", "Geometry", "MESH_DATA",
                 ("read_mesh_uvs", "read_mesh_colors", "read_mesh_attributes", "import_subdivision",
                  "validate_meshes", "merge_parent_xform"), collapsed=True)
        _section(layout, operator, "Rigging", "Rigging", "BONE_DATA",
                 ("import_blendshapes", "import_skeletons"), collapsed=True)
        _section(layout, operator, "Materials", "Materials", "MATERIAL",
                 ("import_all_materials", "import_usd_preview", "set_material_blend",
                  "mtl_name_collision_mode"), collapsed=True)
        textures = _section(layout, operator, "Textures", "Textures", "TEXTURE",
                            ("import_textures_mode",), collapsed=True)
        if textures:
            destination = textures.column()
            destination.enabled = operator.import_textures_mode == "IMPORT_COPY"
            destination.prop(operator, "import_textures_dir")
            destination.prop(operator, "tex_name_collision_mode")
        _section(layout, operator, "ParticlesAndInstancing", "Particles and Instancing",
                 "MOD_PARTICLE_INSTANCE", ("support_scene_instancing",), collapsed=True)
