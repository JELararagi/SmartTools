"""Compose format option panels using the existing provider compatibility checks."""

from ....ui.panel import draw_import_as_geometry_node_settings, draw_panel, draw_version_warning


class FormatSettings:
    configure_layout = True
    lead_property = None
    geometry_node_group = None
    default_provider_only = False

    @draw_version_warning
    def draw(self, operator, module_name, layout):
        if self.configure_layout:
            self.use_settings_columns(layout)
        if self.geometry_node_group and module_name == "geometry_node":
            draw_import_as_geometry_node_settings(layout, operator, self.geometry_node_group)
            return
        self.draw_format_settings(layout, operator, module_name)

    @staticmethod
    def use_settings_columns(layout):
        layout.use_property_split = True
        layout.use_property_decorate = False

    @staticmethod
    def draw_groups(layout, options, groups):
        for key, heading, icon, properties in groups:
            fields = [(options, property_name) for property_name in properties]
            draw_panel(layout, fields, key, heading, icon=icon)

    def draw_format_settings(self, layout, options, provider):
        if self.default_provider_only and provider != "default":
            return
        if self.lead_property:
            layout.prop(options, self.lead_property)
        self.draw_groups(layout, options, self.groups)
