# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Choose the datablock types included in a Blend library import."""

from ....ui.panel import draw_version_warning


_TYPES = (
    ("actions", "Actions", "ACTION"),
    ("armatures", "Armatures", "OUTLINER_OB_ARMATURE"),
    ("brushes", "Brushes", "BRUSH_DATA"),
    ("cameras", "Cameras", "CAMERA_DATA"),
    ("cache_files", "Cache Files", "FILE_CACHE"),
    ("curves", "Curves", "OUTLINER_OB_CURVE"),
    ("hair_curves", "Hair Curves", "OUTLINER_OB_CURVES"),
    ("fonts", "Fonts", "OUTLINER_OB_FONT"),
    ("grease_pencils", "Grease Pencils", "OUTLINER_OB_GREASEPENCIL"),
    ("collections", "Collections", "OUTLINER_COLLECTION"),
    ("images", "Images", "IMAGE_DATA"),
    ("lights", "Lights", "LIGHT"),
    ("linestyles", "Line Styles", "LINE_DATA"),
    ("lattices", "Lattices", "LATTICE_DATA"),
    ("masks", "Masks", "MOD_MASK"),
    ("materials", "Materials", "MATERIAL"),
    ("metaballs", "Metaballs", "OUTLINER_OB_META"),
    ("meshes", "Meshes", "MESH_DATA"),
    ("movieclips", "Movie Clips", "FILE_MOVIE"),
    ("node_groups", "Node Groups", "NODETREE"),
    ("objects", "Objects", "OBJECT_DATA"),
    ("paint_curves", "Paint Curves", "CURVE_BEZCURVE"),
    ("palettes", "Palettes", "RESTRICT_COLOR_ON"),
    ("particles", "Particles", "PARTICLE_DATA"),
    ("pointclouds", "Point Clouds", "OUTLINER_OB_POINTCLOUD"),
    ("lightprobes", "Light Probes", "LIGHTPROBE_SPHERE"),
    ("scenes", "Scenes", "SCENE_DATA"),
    ("sounds", "Sounds", "PLAY_SOUND"),
    ("speakers", "Speakers", "SPEAKER"),
    ("texts", "Texts", "FILE_TEXT"),
    ("textures", "Textures", "TEXTURE"),
    ("volumes", "Volumes", "VOLUME_DATA"),
    ("worlds", "Worlds", "WORLD"),
    ("workspaces", "Workspaces", "WORKSPACE"),
)


class IMPORT_SCENE_BLENDSettings:
    @draw_version_warning
    def draw(self, operator, module_name, layout):
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.row(align=True).prop(operator, "import_module", expand=True)
        layout.separator()

        header, options = layout.panel("BLENDSettings_ImportData")
        header.label(text="Import Data", icon="IMPORT")
        if options is None:
            return

        columns = options.row()
        columns.alignment = "EXPAND"
        split_at = len(_TYPES) // 2
        for types in (_TYPES[:split_at], _TYPES[split_at:]):
            column = columns.column(align=True)
            for key, label, icon in types:
                column.prop(operator, f"import_{key}", text=label, icon=icon)
