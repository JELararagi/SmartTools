# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Image import settings for the supported Blender release."""

from ....ui.panel import draw_panel, draw_version_warning


_PLANE_CONTROLS = (
    ("Options", "Import Options", "IMPORT", ("relative", "force_reload", "image_sequence")),
    ("MaterialSettings", "Material Settings", "MATERIAL",
     ("shader", "render_method", "show_transparent_back", "use_backface_culling", "overwrite_material")),
    ("TextureSettings", "Texture Settings", "TEXTURE",
     ("interpolation", "extension", "use_transparency", "use_auto_refresh")),
    ("Transform", "Transform", "OBJECT_DATA",
     ("size_mode", "height", "align_axis", "align_track", "offset", "offset_axis", "offset_amount")),
)
_IMAGE_CONTROLS = {
    "plane": _PLANE_CONTROLS,
    "data": (("Options", "Import Options", "OPTIONS",
              ("relative_path", "use_sequence_detection", "use_udim_detecting")),),
    "ref": (("Options", "Options", "OPTIONS", ("align",)),),
    "background": (("Options", "Options", "OPTIONS", ("align",)),),
    "empty": (("Options", "Options", "OPTIONS", ("align", "location", "rotation", "background")),),
}


class IMPORT_SCENE_IMAGESettings:
    @draw_version_warning
    def draw(self, operator, module_name, layout):
        layout.use_property_split = True
        layout.use_property_decorate = False
        for key, title, icon, fields in _IMAGE_CONTROLS.get(module_name, ()):
            draw_panel(
                layout,
                [(operator, field) for field in fields],
                f"IMAGESettings_{key}",
                title,
                icon=icon,
                default_closed=key == "Transform",
            )
