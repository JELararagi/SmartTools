# SPDX-License-Identifier: GPL-3.0-or-later
"""Draw settings that the selected X3D provider makes available."""

from ....bversion import BVERSION
from ....ui.panel import AddonVersion, draw_panel, draw_version_warning


_METER_FACTORS = {
    "M": 1.0,
    "DM": 0.1,
    "CM": 0.01,
    "MM": 0.001,
    "IN": 0.0254,
}


class IMPORT_SCENE_X3DSettings:
    @draw_version_warning
    def draw(self, operator, module_name, layout):
        layout.use_property_split = True
        layout.use_property_decorate = False
        axes = [(operator, "axis_forward"), (operator, "axis_up")]

        if BVERSION < 4.2:
            draw_panel(layout, axes, "X3DSettings_Transform", "Transform", icon="OBJECT_DATA")
            return

        if AddonVersion(operator.addon_name).version.as_float >= 2.5:
            draw_panel(
                layout, [(operator, "as_collection")],
                "X3DSettings_General", "General", icon="OPTIONS",
            )

        title, transform = layout.panel(idname="X3DSettings_Transform")
        title.label(text="Transform", icon="OBJECT_DATA")
        if transform is not None:
            transform.prop(operator, "file_unit")
            scale = transform.column()
            scale.enabled = operator.file_unit == "CUSTOM"
            scale.prop(operator, "global_scale")
            if operator.file_unit in _METER_FACTORS:
                operator.global_scale = _METER_FACTORS[operator.file_unit]
            draw_panel(
                layout, axes, "X3DSettings_Transform", "Transform",
                icon="OBJECT_DATA", panel=transform, header=title,
            )

        draw_panel(
            layout, [(operator, "solidify_value")], "X3DSettings_Mesh",
            "Solidify", icon="MOD_SOLIDIFY", set_header_boolean=True,
            header_bool=(operator, "solidify"),
        )
