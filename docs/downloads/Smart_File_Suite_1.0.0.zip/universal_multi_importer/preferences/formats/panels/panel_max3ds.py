# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""SmartFile settings for the separately installed Autodesk 3DS importer."""

from ....ui.panel import draw_panel, draw_version_warning


_CONTENT = ("use_image_search", "object_filter", "use_keyframes", "use_collection", "use_cursor")
_PLACEMENT = ("constrain_size", "use_scene_unit", "use_apply_transform", "axis_forward", "axis_up")


class IMPORT_SCENE_MAX3DSSettings:
    @draw_version_warning
    def draw(self, operator, module_name, layout):
        layout.use_property_split = True
        layout.use_property_decorate = False
        draw_panel(layout, [(operator, prop) for prop in _CONTENT],
                   "MAX3DSSettings_Include", "Include", icon="IMPORT")
        draw_panel(layout, [(operator, prop) for prop in _PLACEMENT],
                   "MAX3DSSettings_Transform", "Transform", icon="OBJECT_DATA")
