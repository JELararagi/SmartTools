from ._format_layout import FormatSettings


class IMPORT_SCENE_SKPSettings(FormatSettings):
    groups = (
        ("SKPSettings_primary", "Primary", "OPTIONS",
         ('scenes_as_camera', 'import_camera', 'reuse_material', 'dedub_only', 'reuse_existing_groups')),
        ("SKPSettings_instance", "Instantiate Components", "MOD_PARTICLE_INSTANCE",
         ('max_instance', 'dedub_type', 'import_scene')),
    )
