from ._format_layout import FormatSettings


class IMPORT_SCENE_BVHSettings(FormatSettings):
    lead_property = "target"
    groups = (
        ("BVHSettings_Transform", "Transform", "OBJECT_DATA",
         ('global_scale', 'rotate_mode', 'axis_forward', 'axis_up')),
        ("BVHSettings_Animation", "Animation", "ARMATURE_DATA",
         ('frame_start', 'use_fps_scale', 'use_cyclic', 'update_scene_fps', 'update_scene_duration')),
    )
