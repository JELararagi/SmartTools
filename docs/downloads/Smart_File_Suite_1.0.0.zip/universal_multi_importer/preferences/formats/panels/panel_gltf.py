# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Present Blender's glTF options in the batch-import dialog."""

from ....ui.panel import draw_panel, draw_version_warning


_GROUPS = {
    "Options": ("Options", "OPTIONS", ("import_shading", "export_import_convert_lighting_mode")),
    "Mesh": ("Mesh", "OBJECT_DATA", ("merge_vertices", "import_merge_material_slots")),
    "Texture": ("Texture", "TEXTURE", ("import_pack_images", "import_webp_texture", "import_unused_materials")),
    "BonesNSkin": ("Bone & Skin", "BONE_DATA", ("bone_heuristic", "guess_original_bind_pose",
                                               "disable_bone_shape", "bone_shape_scale_factor")),
    "Pipeline": ("Pipeline", "SYSTEM", ("import_scene_as_collection", "import_select_created_objects",
                                        "import_scene_extras")),
}


class IMPORT_SCENE_GLTFSettings:
    @draw_version_warning
    def draw(self, operator, module_name, layout):
        layout.use_property_split = True
        layout.use_property_decorate = False
        for key, (title, icon, names) in _GROUPS.items():
            draw_panel(layout, [(operator, name) for name in names],
                       f"GLTFSettings_{key}", title, icon=icon)
