from ._format_layout import FormatSettings


class IMPORT_SCENE_MAXSettings(FormatSettings):
    groups = (
        ("MAXSettings_Include", "Include", "IMPORT",
         ('use_image_search', 'object_filter', 'use_collection')),
        ("MAXSettings_Transform", "Transform", "OBJECT_DATA",
         ('scale_objects', 'use_apply_matrix', 'axis_forward', 'axis_up')),
    )
