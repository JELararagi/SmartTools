"""Resolve import options by the format identifier used by the import dialog."""

from importlib import import_module
from pathlib import Path

from . import presets


_FILENAME_PREFIX = "panel_"
panel_path = sorted(
    source.stem.removeprefix(_FILENAME_PREFIX)
    for source in Path(__file__).parent.glob("panel_*.py")
    if source.is_file()
)
modules = (presets,)


def get_panels(name):
    if name not in panel_path:
        return None
    panel_module = import_module(f".{_FILENAME_PREFIX}{name}", package=__name__)
    return getattr(panel_module, f"IMPORT_SCENE_{name.upper()}Settings")


def register():
    for panel_module in modules:
        panel_module.register()


def unregister():
    for panel_module in reversed(modules):
        panel_module.unregister()
