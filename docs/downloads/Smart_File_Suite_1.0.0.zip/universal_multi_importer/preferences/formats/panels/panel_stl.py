from ._format_layout import FormatSettings
from ....bversion import BVERSION


class IMPORT_SCENE_STLSettings(FormatSettings):
    geometry_node_group = "STLGNSettings"
    groups = (
        ("STLSettings_General", "General", "OBJECT_DATA",
         ('global_scale', 'use_scene_unit', 'forward_axis', 'up_axis')),
        ("STLSettings_Options", "Options", "OPTIONS",
         ('use_facet_normal', 'use_mesh_validate')),
    )

    def draw_format_settings(self, layout, options, provider):
        if provider != "default":
            return
        groups = self.groups if BVERSION >= 3.6 else (
            ("STLSettings_Options", "Options", "OPTIONS",
             ("global_scale", "use_scene_unit", "use_facet_normal", "axis_forward", "axis_up")),
        )
        self.draw_groups(layout, options, groups)
