from __future__ import annotations


class _ImportPresetPanel:
    """Compatibility stub for migrated SFS_OT_universal_multi_importer_import_all import presets."""

    def panel_func(self, layout):
        return None


class _FormatPresetPanel:
    """Compatibility stub for migrated SFS_OT_universal_multi_importer_import_all format presets."""

    def panel_func(self, *args, **kwargs):
        return None


import_preset = _ImportPresetPanel()
format_preset = _FormatPresetPanel()


def register():
    return None


def unregister():
    return None
