# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Compatibility hooks for callers predating the current preset menu."""

from types import SimpleNamespace


def draw_migrated_preset(*args, **kwargs):
    """The preset selector is drawn by the importer itself."""


import_preset = SimpleNamespace(panel_func=draw_migrated_preset)
format_preset = SimpleNamespace(panel_func=draw_migrated_preset)


def register():
    """No additional Blender classes are needed."""


def unregister():
    """No additional Blender classes were registered."""
