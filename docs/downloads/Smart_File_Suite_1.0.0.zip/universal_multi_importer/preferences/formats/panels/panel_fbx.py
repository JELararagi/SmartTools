# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Organize the Blender 5.1 FBX importer controls."""

from ....ui.panel import draw_panel, draw_version_warning


def _group(layout, settings, name, icon, *properties):
    _, content = draw_panel(layout, [(settings, key) for key in properties],
                            f"FBXSettings_{name}", name, icon=icon)
    return content


class IMPORT_SCENE_FBXSettings:
    @draw_version_warning
    def draw(self, operator, module_name, layout):
        layout.use_property_split = True
        layout.use_property_decorate = False
        general = _group(layout, operator, "General", "OPTIONS", "global_scale", "use_custom_props")
        if general:
            enum_style = general.row()
            enum_style.enabled = operator.use_custom_props
            enum_style.prop(operator, "use_custom_props_enum_as_string")
        _group(layout, operator, "Geometry", "OBJECT_DATA",
               "use_custom_normals", "import_subdivision", "import_colors", "validate_meshes")
        _group(layout, operator, "Materials", "MATERIAL", "mtl_name_collision_mode")
        draw_panel(layout, [(operator, "anim_offset")], "FBXSettings_Animation", "Animation",
                   set_header_boolean=True, header_bool=[operator, "use_anim"])
        _group(layout, operator, "Armature", "ARMATURE_DATA", "ignore_leaf_bones")
