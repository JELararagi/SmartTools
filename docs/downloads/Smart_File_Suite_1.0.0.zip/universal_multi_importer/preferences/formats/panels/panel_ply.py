from ._format_layout import FormatSettings
from ....bversion import BVERSION
from ....ui.panel import draw_no_settings


class IMPORT_SCENE_PLYSettings(FormatSettings):
    geometry_node_group = "PLYGNSettings"
    groups = (
        ("PLYSettings_General", "General", "OBJECT_DATA",
         ('global_scale', 'use_scene_unit', 'forward_axis', 'up_axis')),
        ("PLYSettings_Options", "Options", "OPTIONS",
         ('merge_verts', 'import_colors')),
    )

    def draw_format_settings(self, layout, options, provider):
        if provider == "default":
            if BVERSION >= 3.4:
                self.draw_groups(layout, options, self.groups)
            else:
                draw_no_settings(layout)
