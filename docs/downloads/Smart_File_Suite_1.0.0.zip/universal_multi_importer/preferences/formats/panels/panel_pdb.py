# SPDX-License-Identifier: GPL-3.0-or-later
"""PDB atom and bond options for the active importer."""

from ....ui.panel import draw_panel, draw_version_warning


class IMPORT_SCENE_PDBSettings:
    @draw_version_warning
    def draw(self, operator, module_name, layout):
        layout.use_property_split = True
        layout.use_property_decorate = False

        draw_panel(
            layout, [(operator, key) for key in ("use_camera", "use_light", "use_center")],
            "PDBSettings_General", "General", icon="OPTIONS",
        )
        header, atoms = draw_panel(
            layout, [(operator, "ball")], "PDBSettings_BallsAtoms",
            "Balls / Atoms", icon="NODE_MATERIAL",
        )
        if atoms is not None:
            resolution = atoms.column()
            resolution.enabled = operator.ball == "1"
            resolution.prop(operator, "mesh_azimuth")
            resolution.prop(operator, "mesh_zenith")
            draw_panel(
                layout, [(operator, key) for key in
                         ("scale_ballradius", "scale_distances", "atomradius")],
                "PDBSettings_BallsAtoms", "Balls / Atoms",
                icon="NODE_MATERIAL", panel=atoms, header=header,
            )

        _, bonds = draw_panel(
            layout, [(operator, "use_sticks_type")], "PDBSettings_Frames",
            "Frames", icon="SHADING_BBOX", set_header_boolean=True,
            header_bool=(operator, "use_sticks"),
        )
        if bonds is not None:
            self.draw_bonds(operator, bonds)

    @staticmethod
    def draw_bonds(operator, bonds):
        style = operator.use_sticks_type
        if style == "1":
            for key in ("sticks_radius", "sticks_subdiv_view",
                        "sticks_subdiv_render", "use_sticks_bonds"):
                bonds.prop(operator, key)
            return
        if style not in {"0", "2"}:
            return

        for key in ("sticks_sectors", "sticks_radius"):
            bonds.prop(operator, key)
        if style == "0":
            for key in ("sticks_unit_length", "use_sticks_color"):
                bonds.prop(operator, key)

        for key in ("use_sticks_smooth", "use_sticks_bonds"):
            bonds.prop(operator, key)
        spacing = bonds.column()
        spacing.enabled = operator.use_sticks_bonds
        spacing.prop(operator, "sticks_dist")
        if style == "2":
            bonds.prop(operator, "use_sticks_one_object")
