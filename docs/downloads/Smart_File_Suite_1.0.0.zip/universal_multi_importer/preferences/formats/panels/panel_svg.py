from ._format_layout import FormatSettings
from ....ui.panel import draw_no_settings


class IMPORT_SCENE_SVGSettings(FormatSettings):
    configure_layout = False
    groups = (
        ("SVGSettings_options", "Options", "OPTIONS",
         ('resolution', 'scale')),
    )

    def draw_format_settings(self, layout, options, provider):
        if provider == "grease_pencil":
            self.use_settings_columns(layout)
            self.draw_groups(layout, options, self.groups)
        elif provider == "default":
            draw_no_settings(layout)
