from ._format_layout import FormatSettings


class IMPORT_SCENE_PESSettings(FormatSettings):
    groups = (
        ("PESSettings_Import", "Import", "IMPORT",
         ('show_jump_wires', 'do_create_material')),
        ("PESSettings_Thickness", "Thickness", "MOD_OUTLINE",
         ('line_depth', 'thread_thickness')),
    )
