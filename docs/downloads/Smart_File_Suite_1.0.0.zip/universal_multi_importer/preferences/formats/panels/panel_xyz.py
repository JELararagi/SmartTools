# SPDX-License-Identifier: GPL-3.0-or-later
"""XYZ options for the currently selected importer."""

from ....ui.panel import draw_panel, draw_version_warning


class IMPORT_SCENE_XYZSettings:
    @draw_version_warning
    def draw(self, operator, module_name, layout):
        layout.use_property_split = True
        layout.use_property_decorate = False

        draw_panel(
            layout, [(operator, key) for key in
                     ("use_camera", "use_lamp", "use_center", "use_center_all")],
            "XYZSettings_General", "General", icon="OPTIONS",
        )
        header, atoms = draw_panel(
            layout, [(operator, "ball")], "XYZSettings_BallsAtoms",
            "Balls / Atoms", icon="NODE_MATERIAL",
        )
        if atoms is not None:
            resolution = atoms.column()
            resolution.enabled = operator.ball == "1"
            for key in ("mesh_azimuth", "mesh_zenith"):
                resolution.prop(operator, key)
            draw_panel(
                layout, [(operator, key) for key in
                         ("scale_ballradius", "scale_distances", "atomradius")],
                "XYZSettings_BallsAtoms", "Balls / Atoms",
                icon="NODE_MATERIAL", panel=atoms, header=header,
            )

        draw_panel(
            layout, [(operator, "skip_frames", "Skip Frames"), (operator, "images_per_key", "Frames/key")],
            "XYZSettings_Frames", "Frames", icon="SHADING_BBOX",
            set_header_boolean=True, header_bool=(operator, "use_frames"),
        )
