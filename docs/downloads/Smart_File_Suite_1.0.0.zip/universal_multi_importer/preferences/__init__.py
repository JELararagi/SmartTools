# SPDX-License-Identifier: GPL-3.0-or-later
"""Connect this section to the Blender add-on lifecycle."""

from .._entrypoints import lifecycle
from . import formats, preferences, colors, operators

modules = (formats, colors, preferences, operators,)
register, unregister = lifecycle(modules)
