# SPDX-License-Identifier: GPL-3.0-or-later
"""Connect this section to the Blender add-on lifecycle."""

from ..._entrypoints import lifecycle
from . import presets, colors

modules = (presets, colors,)
register, unregister = lifecycle(modules)
