import bpy


class PG_UMIColors(bpy.types.PropertyGroup):
    umi_info_color: bpy.props.FloatVectorProperty(name="Info Color", subtype="COLOR_GAMMA", default=[0.62, 0.86, 0.92])
    umi_success_color: bpy.props.FloatVectorProperty(
        name="Success Color", subtype="COLOR_GAMMA", default=[0.1, 1.0, 0.1]
    )
    umi_cancelled_color: bpy.props.FloatVectorProperty(
        name="Cancelled Color", subtype="COLOR_GAMMA", default=[1.0, 0.4, 0.1]
    )
    umi_warning_color: bpy.props.FloatVectorProperty(
        name="Warning Color", subtype="COLOR_GAMMA", default=[1.0, 0.4, 0.1]
    )
    umi_error_color: bpy.props.FloatVectorProperty(name="Error Color", subtype="COLOR_GAMMA", default=[1.0, 0.1, 0.1])
    umi_command_color: bpy.props.FloatVectorProperty(
        name="Command Color", subtype="COLOR_GAMMA", default=[0.95, 0.91, 0.10]
    )
    umi_command_warning_color: bpy.props.FloatVectorProperty(
        name="Command Warning Color", subtype="COLOR_GAMMA", default=[0.95, 0.61, 0.10]
    )
    umi_import_color: bpy.props.FloatVectorProperty(
        name="Import Color", subtype="COLOR_GAMMA", default=[0.13, 0.69, 0.72]
    )


def _umi_class_has_bl_rna(cls):
    """Return True only for classes Blender has fully registered.

    Blender 5.1/Python 3.13 may expose an inherited placeholder ``bl_rna`` on
    unregistered PropertyGroup subclasses.  PointerProperty rejects that state
    with a missing-bl_rna error, so the class also has to be present in
    ``bpy.types`` under its RNA class name.
    """
    if not isinstance(cls, type):
        return False
    try:
        bl_rna = getattr(cls, "bl_rna", None)
        identifier = str(getattr(bl_rna, "identifier", "") or "").strip()
    except Exception:
        return False
    if not identifier or identifier in {"PropertyGroup", "Operator", "Panel", "Menu", "AddonPreferences"}:
        return False
    try:
        if bool(getattr(cls, "is_registered", False)):
            return True
        return getattr(bpy.types, identifier, None) is cls
    except Exception:
        return False


def _umi_safe_register_class(cls):
    if not isinstance(cls, type) or _umi_class_has_bl_rna(cls):
        return
    try:
        bpy.utils.register_class(cls)
    except Exception:
        try:
            bpy.utils.unregister_class(cls)
            bpy.utils.register_class(cls)
        except Exception:
            pass


def _umi_safe_unregister_class(cls):
    if not isinstance(cls, type):
        return
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


classes = (PG_UMIColors,)


def register():
    for cls in classes:
        _umi_safe_register_class(cls)


def unregister():
    for cls in reversed(classes):
        _umi_safe_unregister_class(cls)
