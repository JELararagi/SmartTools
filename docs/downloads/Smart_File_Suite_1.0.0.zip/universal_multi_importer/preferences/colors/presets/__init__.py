# SPDX-License-Identifier: GPL-3.0-or-later
"""Connect this section to the Blender add-on lifecycle."""

from ...._entrypoints import lifecycle
from . import color_preset

modules = (color_preset,)
register, unregister = lifecycle(modules)
