import bpy
from pathlib import Path
from ....umi_const import get_umi_colors
from .....storage_paths import user_default_dir
from bl_ui.utils import PresetPanel
from bpy.types import Menu, Operator, Panel

from bl_operators.presets import AddPresetBase
from .....ui_language_runtime import ui_text as _ui_text


_PRESET_FILES_CACHE: tuple[Path, ...] = ()


def _preset_directory(*, create: bool = False) -> Path:
    return Path(user_default_dir("universal_multi_importer", "color_presets", create=create))


def _preset_files() -> list[Path]:
    return list(_PRESET_FILES_CACHE)


def _refresh_preset_files() -> list[Path]:
    global _PRESET_FILES_CACHE
    try:
        directory = _preset_directory(create=False)
        _PRESET_FILES_CACHE = tuple(sorted(
            (path for path in directory.glob("*.py") if path.is_file()),
            key=lambda path: path.stem.casefold(),
        )) if directory.is_dir() else ()
    except OSError:
        _PRESET_FILES_CACHE = ()
    return list(_PRESET_FILES_CACHE)


def _draw_preset_entries(layout) -> None:
    files = _preset_files()
    layout.operator('umi.sfs_refresh_color_presets', text='Refresh Presets', icon='FILE_REFRESH')
    if not files:
        layout.label(text="No saved color presets")
        return
    for filepath in files:
        operator = layout.operator(
            "script.execute_preset",
            text=bpy.path.display_name(filepath.name, title_case=False), translate=False
        )
        operator.filepath = str(filepath)
        operator.menu_idname = UMI_MT_color_presets.__name__


class UMI_PT_color_presets(PresetPanel, Panel):
    bl_label = 'Universal Multi Importer Presets'
    preset_add_operator = "umi.add_import_preset"

    def draw(self, _context):
        _draw_preset_entries(self.layout)


#  From https://sinestesia.co/blog/tutorials/using-blenders-presets-in-python/
class UMI_MT_color_presets(Menu):
    bl_label = 'Universal Multi Importer Color Presets'

    def draw(self, _context):
        _draw_preset_entries(self.layout)


class SFS_OT_universal_multi_importer_add_preset_2(AddPresetBase, Operator):
    bl_idname = 'umi.sfs_universal_multi_importer_add_preset'
    bl_label = 'Add Color Preset'
    preset_menu = "UMI_MT_color_presets"

    preset_defines = [
        'import bpy',
        "umi_colors = bpy.context.window_manager.umi_preferences_proxy.umi_colors",
    ]

    skip_prop = ["name", "settings_imported", "bl_rna", "addon_name", "supported_version"]

    bl_options = {'UNDO'}
    @property
    def preset_values(self):
        properties_blacklist = Operator.bl_rna.properties.keys()
        umi_settings = get_umi_colors()

        ret = []
        for s in dir(umi_settings):
            if s.startswith("__"):
                continue
            if s in self.skip_prop:
                continue
            if s not in properties_blacklist:
                ret.append(f"umi_colors.{s}")

        return ret

    @staticmethod
    def operator_path():
        return user_default_dir("universal_multi_importer", "color_presets", create=True)

    def execute(self, _context):
        menu_cls = getattr(bpy.types, self.preset_menu, None)
        directory = _preset_directory(create=True)

        if self.remove_active or self.remove_name:
            requested = str(self.name if self.remove_name else getattr(menu_cls, "bl_label", "") or "").strip()
            filepath = next(
                (
                    path
                    for path in _preset_files()
                    if path.stem == requested
                    or bpy.path.display_name(path.name, title_case=False) == requested
                ),
                None,
            )
            if filepath is None:
                self.report({'WARNING'}, "Select a saved color preset to remove")
                return {'CANCELLED'}
            try:
                filepath.unlink()
            except OSError as exc:
                self.report({'ERROR'}, _ui_text(f"Unable to remove color preset: {exc}", f"色プリセットを削除できませんでした：{exc}"))
                return {'CANCELLED'}
            if menu_cls is not None:
                menu_cls.bl_label = 'Universal Multi Importer Color Presets'
            _refresh_preset_files()
            return {'FINISHED'}

        name = str(self.name or "").strip()
        if not name:
            return {'FINISHED'}
        filename = self.as_filename(name)
        if not filename:
            self.report({'WARNING'}, "Enter a valid preset name")
            return {'CANCELLED'}
        filepath = directory / f"{filename}.py"
        if filepath.exists():
            self.report({'WARNING'}, _ui_text(f'Color preset "{name}" already exists', f"色プリセット「{name}」はすでにあります"))
            return {'CANCELLED'}

        colors = get_umi_colors()
        if colors is None:
            self.report({'WARNING'}, "Universal Multi Importer colors are not available yet")
            return {'CANCELLED'}

        lines = [
            "import bpy",
            "umi_colors = bpy.context.window_manager.umi_preferences_proxy.umi_colors",
            "",
        ]
        properties = getattr(getattr(colors, "bl_rna", None), "properties", ())
        for prop in properties:
            identifier = str(getattr(prop, "identifier", "") or "")
            if not identifier or identifier in self.skip_prop or identifier == "rna_type":
                continue
            try:
                value = getattr(colors, identifier)
                if hasattr(value, "to_tuple"):
                    value = tuple(value)
                elif not isinstance(value, (str, bytes, int, float, bool, tuple, list, dict, set, type(None))):
                    value = tuple(value)
            except Exception:
                continue
            lines.append(f"umi_colors.{identifier} = {value!r}")

        try:
            filepath.write_text("\n".join(lines) + "\n", encoding="utf-8")
        except OSError as exc:
            self.report({'ERROR'}, _ui_text(f"Unable to save color preset: {exc}", f"色プリセットを保存できませんでした：{exc}"))
            return {'CANCELLED'}
        if menu_cls is not None:
            menu_cls.bl_label = bpy.path.display_name(filepath.name, title_case=False)
        _refresh_preset_files()
        return {'FINISHED'}


class SFS_OT_universal_multi_importer_refresh_color_presets(Operator):
    bl_idname = 'umi.sfs_refresh_color_presets'
    bl_label = 'Refresh Color Presets'
    bl_description = 'Refresh the cached Universal Multi Importer color-preset list'

    def execute(self, _context):
        _refresh_preset_files()
        return {'FINISHED'}


def panel_func(layout):
    row = layout.row(align=True)
    row.menu(UMI_MT_color_presets.__name__, text=UMI_MT_color_presets.bl_label)
    row.operator(SFS_OT_universal_multi_importer_refresh_color_presets.bl_idname, text="", icon="FILE_REFRESH", emboss=True)
    row.operator(SFS_OT_universal_multi_importer_add_preset_2.bl_idname, text="", icon="ADD", emboss=True)
    row.operator(SFS_OT_universal_multi_importer_add_preset_2.bl_idname, text="", icon="REMOVE", emboss=True).remove_active = True


def _umi_class_has_bl_rna(cls):
    """Return True only for classes Blender has fully registered.

    Blender 5.1/Python 3.13 may expose an inherited placeholder ``bl_rna`` on
    unregistered PropertyGroup subclasses.  PointerProperty rejects that state
    with a missing-bl_rna error, so the class also has to be present in
    ``bpy.types`` under its RNA class name.
    """
    if not isinstance(cls, type):
        return False
    try:
        bl_rna = getattr(cls, "bl_rna", None)
        identifier = str(getattr(bl_rna, "identifier", "") or "").strip()
    except Exception:
        return False
    if not identifier or identifier in {"PropertyGroup", "Operator", "Panel", "Menu", "AddonPreferences"}:
        return False
    try:
        if bool(getattr(cls, "is_registered", False)):
            return True
        return getattr(bpy.types, identifier, None) is cls
    except Exception:
        return False


def _umi_safe_register_class(cls):
    if not isinstance(cls, type) or _umi_class_has_bl_rna(cls):
        return
    try:
        bpy.utils.register_class(cls)
    except Exception:
        try:
            bpy.utils.unregister_class(cls)
            bpy.utils.register_class(cls)
        except Exception:
            pass


def _umi_safe_unregister_class(cls):
    if not isinstance(cls, type):
        return
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


classes = (
    UMI_MT_color_presets,
    SFS_OT_universal_multi_importer_add_preset_2,
    SFS_OT_universal_multi_importer_refresh_color_presets,
    UMI_PT_color_presets,
)


def register():
    for cls in classes:
        _umi_safe_register_class(cls)


def unregister():
    for cls in reversed(classes):
        _umi_safe_unregister_class(cls)
