# SPDX-License-Identifier: GPL-3.0-or-later
"""Expose the package's public interfaces."""

from .version import Version as Version
