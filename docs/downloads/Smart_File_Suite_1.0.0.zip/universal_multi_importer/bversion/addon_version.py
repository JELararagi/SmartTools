# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Read local and cached remote Blender addon versions."""
import addon_utils
import bpy

from . import BVERSION
from .version.version import Version


class AddonVersion:
    def __init__(self, addon_name, repo_id=0, is_addon_external: bool = False):
        self.addon_name = addon_name
        self.repo_if = repo_id
        self.is_addon_external = is_addon_external
        self.local_pkg = {}
        self.remote_pkg = {}
        if BVERSION >= 4.2 and self.is_extension:
            self.local_pkg, self.remote_pkg = self.get_packages(repo_id)

    def get_packages(self, repo_id=0):
        from bl_pkg import repo_cache_store_ensure

        cache = repo_cache_store_ensure()
        pairs = zip(cache.pkg_manifest_from_local_ensure(error_fn=print),
                    cache.pkg_manifest_from_remote_ensure(error_fn=print))
        for index, (local, remote) in enumerate(pairs):
            if index == repo_id:
                return local or {}, remote or {}
        return {}, {}

    @property
    def is_extension(self):
        return bool(self.addon_name and self.addon_name.startswith("bl_ext"))

    @property
    def pkg_name(self):
        return self.addon_name.rsplit(".", 1)[-1] if self.is_extension else self.addon_name

    @property
    def module(self):
        return next((module for module in addon_utils.modules()
                     if module.__name__ == self.addon_name), None)

    @property
    def version(self):
        return Version(getattr(self.module, "bl_info", {}).get("version", (0, 0, 0)))

    @property
    def local_version(self):
        if not self.is_extension:
            return self.version
        return Version(getattr(self.local_pkg.get(self.pkg_name), "version", (0, 0, 0)))

    @property
    def remote_version(self):
        return Version(getattr(self.remote_pkg.get(self.pkg_name), "version", (0, 0, 0)))

    @property
    def is_outdated(self):
        return self.local_version < self.remote_version

    @property
    def is_newer(self):
        return self.remote_version < self.local_version

    @property
    def is_matching(self):
        return self.local_version == self.remote_version

    @property
    def is_enable(self):
        return not self.addon_name or self.addon_name in bpy.context.preferences.addons

    @property
    def is_installed(self):
        return self.is_enable or self.module is not None

    def __str__(self):
        return str(self.local_version)
