# SPDX-License-Identifier: GPL-3.0-or-later
"""Expose the package's public interfaces."""

from .blender_version import BVERSION as BVERSION
from .addon_version import AddonVersion as AddonVersion
