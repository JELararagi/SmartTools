# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Expose Blender's runtime version in the importer's version format."""

import bpy

from .version import Version

blender_version = bpy.app.version


def get_bversion():
    return Version(tuple(blender_version))


BVERSION = get_bversion()
