# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Expose the extension-version helper through the historical module path."""
from .addon_version import AddonVersion as AddonVersion
