# SPDX-License-Identifier: GPL-3.0-or-later
"""Enable child packages in dependency order and release them in reverse."""


def lifecycle(children):
    def register():
        for child in children:
            child.register()

    def unregister():
        for child in reversed(children):
            child.unregister()

    return register, unregister
