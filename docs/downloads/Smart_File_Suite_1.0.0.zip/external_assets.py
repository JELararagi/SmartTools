# -----------------------------------------------------------------------------
#  External Asset Audit / Bundle / Recovery Tools
# -----------------------------------------------------------------------------

import glob
import shutil
import subprocess
import time
import zipfile


_SF_EXT_KIND_INFO = {
    'IMAGE': {'label': 'Images', 'subdir': 'images'},
    'MOVIECLIP': {'label': 'Movie Clips', 'subdir': 'movies'},
    'SOUND': {'label': 'Sounds', 'subdir': 'sounds'},
    'VECTORFONT': {'label': 'Fonts', 'subdir': 'fonts'},
    'VOLUME': {'label': 'Volumes', 'subdir': 'volumes'},
    'CACHEFILE': {'label': 'Cache Files', 'subdir': 'caches'},
    'LIBRARY': {'label': 'Linked Libraries', 'subdir': 'libraries'},
    'TEXT': {'label': 'Texts', 'subdir': 'texts'},
    'UNKNOWN': {'label': 'Other File References', 'subdir': 'external'},
}


_SF_LINK_EDIT_TICKET_FILE = 'smart_file_suite_link_edit_tickets.json'
_SF_LINK_EDIT_MAX_TICKETS = 24
_SF_LINK_EDIT_MAX_AGE_DAYS = 21
# Immutable strings/scalars only.  UI draw reads this snapshot and never owns RNA.
_SF_LINK_EDIT_TICKET_CACHE: tuple[tuple[tuple[str, object], ...], ...] = ()


def _sf_link_edit_ticket_cache_store(rows) -> list[dict]:
    global _SF_LINK_EDIT_TICKET_CACHE
    cleaned = list(rows or [])[:_SF_LINK_EDIT_MAX_TICKETS]
    frozen = []
    for row in cleaned:
        if not isinstance(row, dict):
            continue
        scalar_row = {
            str(key): value
            for key, value in row.items()
            if isinstance(value, (str, int, float, bool, type(None)))
        }
        frozen.append(tuple(sorted(scalar_row.items(), key=lambda item: item[0])))
    _SF_LINK_EDIT_TICKET_CACHE = tuple(frozen)
    return [dict(items) for items in _SF_LINK_EDIT_TICKET_CACHE]


def _sf_link_edit_ticket_cache_read() -> list[dict]:
    return [dict(items) for items in _SF_LINK_EDIT_TICKET_CACHE]


def _sf_link_edit_ticket_store_path() -> str:
    return _sf_user_default_file(_SF_LINK_EDIT_TICKET_FILE, 'runtime')


def _sf_link_edit_ticket_age_seconds(row: dict) -> float:
    created_at = str((row or {}).get('created_at', '') or '').strip()
    if not created_at:
        return 0.0
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S'):
        try:
            created = datetime.datetime.strptime(created_at, fmt)
            return max(0.0, (datetime.datetime.now() - created).total_seconds())
        except Exception:
            continue
    return 0.0


def _sf_link_edit_cleanup_tickets(rows, *, max_items: int = _SF_LINK_EDIT_MAX_TICKETS, max_age_days: int = _SF_LINK_EDIT_MAX_AGE_DAYS):
    valid = []
    seen = set()
    max_age_seconds = float(max(1, int(max_age_days or _SF_LINK_EDIT_MAX_AGE_DAYS))) * 86400.0
    for row in list(rows or []):
        if not isinstance(row, dict):
            continue
        parent = _norm_path(str(row.get('parent_blend', '') or ''))
        child = _norm_path(str(row.get('child_blend', '') or ''))
        if not parent or not child:
            continue
        ticket_id = str(row.get('ticket_id', '') or '').strip() or f"{parent}|{child}"
        if ticket_id in seen:
            continue
        seen.add(ticket_id)
        age_seconds = _sf_link_edit_ticket_age_seconds(row)
        if age_seconds > max_age_seconds and (not os.path.isfile(parent)) and (not os.path.isfile(child)):
            continue
        cleaned = dict(row)
        cleaned['ticket_id'] = ticket_id
        cleaned['parent_blend'] = parent
        cleaned['child_blend'] = child
        cleaned['parent_name'] = os.path.basename(parent)
        cleaned['child_name'] = os.path.basename(child)
        valid.append(cleaned)
    valid.sort(key=lambda item: str(item.get('created_at', '') or ''), reverse=True)
    return valid[:max(1, int(max_items or _SF_LINK_EDIT_MAX_TICKETS))]


def _sf_link_edit_load_tickets() -> list[dict]:
    """Explicit command-side disk load; never called from Panel.draw."""
    store_path = _sf_link_edit_ticket_store_path()
    if not os.path.isfile(store_path):
        return _sf_link_edit_ticket_cache_store(())
    try:
        with open(store_path, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
    except Exception:
        return _sf_link_edit_ticket_cache_store(())
    if isinstance(payload, dict):
        rows = list(payload.get('tickets', []) or [])
    elif isinstance(payload, list):
        rows = list(payload or [])
    else:
        rows = []
    return _sf_link_edit_ticket_cache_store(_sf_link_edit_cleanup_tickets(rows))


def _sf_link_edit_save_tickets(rows) -> bool:
    store_path = _sf_link_edit_ticket_store_path()
    cleaned = _sf_link_edit_cleanup_tickets(rows)
    payload = {
        'kind': 'linked_edit_roundtrip',
        'saved_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'tickets': cleaned,
    }
    try:
        with open(store_path, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
        _sf_link_edit_ticket_cache_store(cleaned)
        return True
    except Exception:
        return False


def _sf_link_edit_store_ticket(parent_blend: str, child_blend: str, *, label: str = '') -> dict:
    parent_blend = _norm_path(parent_blend or '')
    child_blend = _norm_path(child_blend or '')
    if not parent_blend or not child_blend or parent_blend == child_blend:
        return {}
    created_at = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    ticket = {
        'ticket_id': f"{int(time.time() * 1000)}_{os.path.basename(child_blend) or 'ticket'}",
        'created_at': created_at,
        'parent_blend': parent_blend,
        'child_blend': child_blend,
        'parent_name': os.path.basename(parent_blend),
        'child_name': os.path.basename(child_blend),
        'label': str(label or '').strip(),
    }
    existing = [row for row in _sf_link_edit_load_tickets() if _norm_path(str(row.get('parent_blend', '') or '')) != parent_blend or _norm_path(str(row.get('child_blend', '') or '')) != child_blend]
    existing.insert(0, ticket)
    _sf_link_edit_save_tickets(existing)
    return ticket


def _sf_link_edit_ticket_matches_current(ticket: dict, filepath: str = '') -> bool:
    current_path = _norm_path(filepath or bpy.data.filepath or '') if (filepath or bpy.data.filepath) else ''
    if not current_path:
        return False
    child_path = _norm_path(str((ticket or {}).get('child_blend', '') or ''))
    if child_path and child_path == current_path:
        return True
    child_name = os.path.basename(child_path).lower() if child_path else ''
    current_name = os.path.basename(current_path).lower() if current_path else ''
    return bool(child_name and current_name and child_name == current_name)


def _sf_link_edit_ticket_from_rows(rows, filepath: str = '') -> dict:
    current_path = _norm_path(filepath or bpy.data.filepath or '') if (filepath or bpy.data.filepath) else ''
    rows = list(rows or [])
    if not rows:
        return {}
    if current_path:
        exact = next((row for row in rows if _norm_path(str(row.get('child_blend', '') or '')) == current_path), None)
        if exact:
            return dict(exact)
        same_name = next((row for row in rows if _sf_link_edit_ticket_matches_current(row, current_path)), None)
        if same_name:
            return dict(same_name)
    return dict(rows[0])


def _sf_link_edit_current_ticket_cached(context=None) -> dict:
    """Draw-safe immutable snapshot lookup with no filesystem access."""
    current_path = _norm_path(bpy.data.filepath or '') if bpy.data.filepath else ''
    return _sf_link_edit_ticket_from_rows(_sf_link_edit_ticket_cache_read(), current_path)


def _sf_link_edit_current_ticket(context=None) -> dict:
    """Authoritative command-side lookup that refreshes the bounded cache."""
    current_path = _norm_path(bpy.data.filepath or '') if bpy.data.filepath else ''
    return _sf_link_edit_ticket_from_rows(_sf_link_edit_load_tickets(), current_path)


def _sf_link_edit_target_ticket(context, ticket_id: str = '') -> dict:
    wanted = str(ticket_id or '').strip()
    rows = _sf_link_edit_load_tickets()
    if wanted:
        match = next((row for row in rows if str(row.get('ticket_id', '') or '') == wanted), None)
        if match:
            return match
    return _sf_link_edit_current_ticket(context)


def _sf_ext_kind_key_from_datablock(id_):
    cname = str(getattr(getattr(id_, '__class__', None), '__name__', '') or type(id_).__name__ or '').strip()
    if not cname:
        return 'UNKNOWN'
    return cname.upper()


def _sf_ext_kind_info(id_):
    return _SF_EXT_KIND_INFO.get(_sf_ext_kind_key_from_datablock(id_), _SF_EXT_KIND_INFO['UNKNOWN'])


def _sf_ext_safe_display_name(id_):
    try:
        return str(getattr(id_, 'name', '') or '')
    except Exception:
        return ''


def _sf_ext_raw_path(id_):
    try:
        raw = getattr(id_, 'filepath', '') or ''
    except Exception:
        raw = ''
    return str(raw or '').strip()


def _sf_ext_is_packed(id_):
    try:
        if getattr(id_, 'packed_file', None):
            return True
    except Exception:
        pass
    try:
        packed_files = getattr(id_, 'packed_files', None)
        if packed_files and len(packed_files):
            return True
    except Exception:
        pass
    return False


def _sf_ext_uses_env(raw_path: str) -> bool:
    text = str(raw_path or '')
    if not text:
        return False
    return bool(re.search(r'(\$\{[^}]+\}|\$[A-Za-z_][A-Za-z0-9_]*|%[A-Za-z_][A-Za-z0-9_]*%)', text))


def _sf_ext_primary_abs_path(raw_path: str, *, library=None) -> str:
    raw_path = str(raw_path or '').strip()
    if not raw_path:
        return ''
    resolved = raw_path
    try:
        resolved = bpy.path.abspath(raw_path, library=library)
    except Exception:
        pass
    try:
        resolved = os.path.expandvars(os.path.expanduser(str(resolved or '')))
    except Exception:
        resolved = str(resolved or '')
    return _norm_path(resolved)


_SF_EXT_TOKENIZED_SEQUENCE_KINDS = {'UDIM', 'UVTILE', 'HASH', 'PRINTF', 'HOUDINI_FRAME'}

_SF_EXT_RELINK_EXTENSION_FAMILIES = {
    'IMAGE': {'.bmp', '.dds', '.exr', '.hdr', '.jpeg', '.jpg', '.png', '.psd', '.tga', '.tif', '.tiff', '.tx', '.webp'},
    'VIDEO': {'.avi', '.mkv', '.mov', '.mp4', '.mxf', '.webm'},
    'AUDIO': {'.aif', '.aiff', '.flac', '.mp3', '.ogg', '.opus', '.wav'},
    'CACHE': {'.abc', '.usd', '.usda', '.usdc', '.usdz', '.vdb'},
    'FONT': {'.otf', '.ttc', '.ttf', '.woff', '.woff2'},
    'TEXT': {'.csv', '.glsl', '.json', '.osl', '.py', '.txt', '.xml', '.yaml', '.yml'},
}
_SF_EXT_RELINK_EXT_TO_FAMILY = {
    ext: family
    for family, exts in _SF_EXT_RELINK_EXTENSION_FAMILIES.items()
    for ext in exts
}


def _sf_ext_extension_family(ext: str) -> str:
    ext = str(ext or '').strip().lower()
    if not ext:
        return ''
    if not ext.startswith('.'):
        ext = '.' + ext
    return str(_SF_EXT_RELINK_EXT_TO_FAMILY.get(ext, '') or '')


def _sf_ext_expand_allowed_suffixes(suffixes) -> set[str]:
    expanded = set()
    for suffix in list(suffixes or []):
        suffix = str(suffix or '').strip().lower()
        if not suffix:
            continue
        if not suffix.startswith('.'):
            suffix = '.' + suffix
        family = _sf_ext_extension_family(suffix)
        if family:
            expanded.update(set(_SF_EXT_RELINK_EXTENSION_FAMILIES.get(family, set()) or set()))
        else:
            expanded.add(suffix)
    return {str(ext).lower() for ext in expanded if str(ext).strip()}


def _sf_ext_index_keys_for_filename(filename: str) -> list[str]:
    filename = os.path.basename(str(filename or ''))
    if not filename:
        return []
    lower = filename.lower()
    stem, ext = os.path.splitext(lower)
    out = [lower]
    if stem:
        out.append(f'@stem:{stem}')
        family = _sf_ext_extension_family(ext)
        if family:
            out.append(f'@family:{family}:{stem}')
    return list(dict.fromkeys(out))


def _sf_ext_rows_require_saved_blend(rows, path_mode: str) -> bool:
    mode = str(path_mode or '').upper()
    if mode == 'RELATIVE':
        return True
    if mode != 'PRESERVE':
        return False
    for row in list(rows or []):
        raw_path = str(row.get('raw_path') or '')
        abs_path = str(row.get('abs_path') or row.get('absolute_path') or '')
        if _sf_ext_path_style(raw_path, abs_path) == 'RELATIVE':
            return True
    return False


def _sf_ext_token_pattern(raw_name: str) -> tuple[str, str]:
    raw_name = str(raw_name or '')
    upper = raw_name.upper()
    if '<UDIM>' in upper:
        return 'UDIM', '<UDIM>' if '<UDIM>' in raw_name else '<udim>'
    if '<UVTILE>' in upper:
        return 'UVTILE', '<UVTILE>' if '<UVTILE>' in raw_name else '<uvtile>'
    m = re.search(r'(%0?\d*d)', raw_name, re.IGNORECASE)
    if m:
        return 'PRINTF', m.group(1)
    m = re.search(r'(\$F\d*)', raw_name, re.IGNORECASE)
    if m:
        return 'HOUDINI_FRAME', m.group(1)
    m = re.search(r'(#+)', raw_name)
    if m:
        return 'HASH', m.group(1)
    return '', ''



def _sf_ext_sequence_glob_and_regex(raw_name: str, seq_kind: str, token: str) -> tuple[str, object]:
    raw_name = str(raw_name or '')
    seq_kind = str(seq_kind or '').upper()
    token = str(token or '')
    if not raw_name or not seq_kind or not token:
        return raw_name, None

    glob_name = raw_name.replace(token, '*', 1)
    repl = r'\d+'
    if seq_kind == 'UDIM':
        repl = r'\d{4}'
    elif seq_kind == 'UVTILE':
        repl = r'u\d+_v\d+'
    elif seq_kind == 'HASH':
        repl = (r'\d+' if len(token) <= 1 else rf'\d{{{len(token)}}}')
    elif seq_kind in {'PRINTF', 'HOUDINI_FRAME'}:
        width = 0
        try:
            width = int(re.sub(r'[^0-9]', '', token) or 0)
        except Exception:
            width = 0
        repl = (rf'\d{{{width}}}' if width > 0 else r'\d+')
    rx = re.compile('^' + re.escape(raw_name).replace(re.escape(token), repl, 1) + '$', re.IGNORECASE)
    return glob_name, rx



def _sf_ext_sequence_paths(id_, raw_path: str, abs_path: str) -> tuple[str, list[str]]:
    raw_path = str(raw_path or '')
    abs_path = str(abs_path or '')
    raw_name = os.path.basename(raw_path or abs_path)
    abs_name = os.path.basename(abs_path or raw_path)
    seq_kind, token = _sf_ext_token_pattern(raw_name)

    if seq_kind:
        base_dir = os.path.dirname(abs_path or raw_path)
        if not base_dir:
            return seq_kind, []
        glob_name, rx = _sf_ext_sequence_glob_and_regex(raw_name, seq_kind, token)
        glob_path = os.path.join(base_dir, glob_name)
        candidates = sorted(glob.glob(glob_path))
        if not candidates:
            return seq_kind, []
        if rx is None:
            return seq_kind, [_norm_path(p) for p in candidates]
        return seq_kind, [_norm_path(p) for p in candidates if rx.match(os.path.basename(p))]

    source = str(getattr(id_, 'source', '') or '').upper()
    if source == 'SEQUENCE':
        anchor = abs_name or raw_name
        base_dir = os.path.dirname(abs_path or raw_path)
        m = re.match(r'^(.*?)(\d+)(\.[^.]+)$', anchor)
        if not base_dir or not m:
            return 'SEQUENCE', [_norm_path(abs_path)] if abs_path else []
        prefix, _digits, ext = m.groups()
        glob_path = os.path.join(base_dir, f"{prefix}*{ext}")
        candidates = []
        for p in sorted(glob.glob(glob_path)):
            bn = os.path.basename(p)
            if bn.startswith(prefix) and bn.endswith(ext):
                mid = bn[len(prefix):-len(ext)] if len(ext) else bn[len(prefix):]
                if mid.isdigit():
                    candidates.append(_norm_path(p))
        if candidates:
            return 'SEQUENCE', candidates
        return 'SEQUENCE', [_norm_path(abs_path)] if abs_path else []

    return 'FILE', [_norm_path(abs_path)] if abs_path else []



def _sf_ext_tokenized_sequence_path(rec: dict, candidate_abs: str) -> str:
    candidate_abs = _norm_path(candidate_abs or '')
    raw_name = os.path.basename(str(rec.get('raw_path') or ''))
    seq_kind, _token = _sf_ext_token_pattern(raw_name)
    if seq_kind in _SF_EXT_TOKENIZED_SEQUENCE_KINDS and raw_name:
        return _norm_path(os.path.join(os.path.dirname(candidate_abs), raw_name))
    return candidate_abs



def _sf_ext_sequence_index_candidates(rec: dict, index: dict[str, list[str]]) -> list[str]:
    index = dict(index or {})
    raw_name = os.path.basename(str(rec.get('raw_path') or rec.get('abs_path') or ''))
    abs_name = os.path.basename(str(rec.get('abs_path') or rec.get('raw_path') or ''))
    base = raw_name or abs_name
    if not base:
        return []
    base_lower = base.lower()
    stem, ext = os.path.splitext(base_lower)
    out = list(index.get(base_lower, []) or [])

    if stem:
        family = _sf_ext_extension_family(ext)
        if family:
            out.extend(list(index.get(f'@family:{family}:{stem}', []) or []))
        out.extend(list(index.get(f'@stem:{stem}', []) or []))

    seq_kind, token = _sf_ext_token_pattern(raw_name)
    if seq_kind:
        _glob_name, rx = _sf_ext_sequence_glob_and_regex(raw_name, seq_kind, token)
        if rx is not None:
            for key, values in index.items():
                key = str(key or '')
                if key.startswith('@'):
                    continue
                if rx.match(key):
                    out.extend(list(values or []))

    return _sf_ref_dedup_paths(out)


def _sf_ext_record_key(rec: dict) -> str:
    return '::'.join([
        str(rec.get('kind_key', '') or ''),
        str(rec.get('name', '') or ''),
        str(rec.get('raw_path', '') or ''),
    ])


def _sf_ext_path_style(raw_path: str, abs_path: str) -> str:
    raw_path = str(raw_path or '')
    abs_path = str(abs_path or '')
    if raw_path.startswith('//'):
        return 'RELATIVE'
    if _sf_ext_uses_env(raw_path):
        return 'ENV'
    if os.path.isabs(abs_path or raw_path):
        return 'ABSOLUTE'
    return 'OTHER'


def _sf_ext_make_record(id_, *, include_missing: bool = True):
    raw_path = _sf_ext_raw_path(id_)
    if not raw_path:
        return None
    library = None
    try:
        library = getattr(id_, 'library', None)
    except Exception:
        library = None
    abs_path = _sf_ext_primary_abs_path(raw_path, library=library)
    sequence_mode, resolved_paths = _sf_ext_sequence_paths(id_, raw_path, abs_path)
    packed = _sf_ext_is_packed(id_)
    existing_paths = []
    for p in list(resolved_paths or []):
        if p and os.path.exists(p):
            existing_paths.append(_norm_path(p))
    exists = bool(existing_paths)
    if (not include_missing) and (not packed) and (not exists):
        return None
    kind_info = _sf_ext_kind_info(id_)
    rec = {
        'id_ref': id_,
        'name': _sf_ext_safe_display_name(id_),
        'kind_key': _sf_ext_kind_key_from_datablock(id_),
        'kind_label': kind_info['label'],
        'kind_subdir': kind_info['subdir'],
        'raw_path': raw_path,
        'abs_path': abs_path,
        'packed': packed,
        'exists': exists,
        'path_style': _sf_ext_path_style(raw_path, abs_path),
        'uses_env': _sf_ext_uses_env(raw_path),
        'sequence_mode': sequence_mode,
        'resolved_paths': existing_paths if existing_paths else [p for p in resolved_paths if p],
    }
    return rec


def _sf_ext_iter_data_specs(*, include_libraries: bool = True, include_texts: bool = False):
    specs = [
        'images',
        'movieclips',
        'sounds',
        'fonts',
        'volumes',
        'cache_files',
    ]
    if include_libraries:
        specs.append('libraries')
    if include_texts:
        specs.append('texts')
    return specs


def _sf_ext_collect_current_file_records(*, include_libraries: bool = True, include_texts: bool = False, include_missing: bool = True) -> list[dict]:
    records = []
    seen = set()
    for coll_name in _sf_ext_iter_data_specs(include_libraries=include_libraries, include_texts=include_texts):
        try:
            coll = getattr(bpy.data, coll_name, None)
        except Exception:
            coll = None
        if coll is None:
            continue
        try:
            items = list(coll)
        except Exception:
            items = []
        for id_ in items:
            rec = _sf_ext_make_record(id_, include_missing=include_missing)
            if not rec:
                continue
            key = _sf_ext_record_key(rec)
            if key in seen:
                continue
            seen.add(key)
            records.append(rec)
    records.sort(key=lambda it: (str(it.get('kind_label') or ''), str(it.get('name') or ''), str(it.get('raw_path') or '')))
    return records


def _sf_ext_visit_driver_targets(ad, visit):
    if not ad:
        return
    try:
        for drv in getattr(ad, 'drivers', []) or []:
            try:
                for var in drv.driver.variables:
                    for tgt in var.targets:
                        visit(getattr(tgt, 'id', None))
            except Exception:
                pass
    except Exception:
        pass


def _sf_ext_collect_from_root_ids(root_ids, *, include_libraries: bool = False, include_texts: bool = False, include_missing: bool = True) -> list[dict]:
    records: list[dict] = []
    seen_recs = set()
    visited = set()

    def add_rec(id_):
        rec = _sf_ext_make_record(id_, include_missing=include_missing)
        if not rec:
            return
        key = _sf_ext_record_key(rec)
        if key in seen_recs:
            return
        seen_recs.add(key)
        records.append(rec)

    def visit(id_):
        if id_ is None:
            return
        try:
            token = int(id_.as_pointer())
        except Exception:
            token = id(id_)
        if token in visited:
            return
        visited.add(token)

        if include_libraries:
            try:
                lib = getattr(id_, 'library', None)
            except Exception:
                lib = None
            if lib is not None:
                add_rec(lib)

        add_rec(id_)

        try:
            if isinstance(id_, bpy.types.Collection):
                for ch in getattr(id_, 'children', []) or []:
                    visit(ch)
                for ob in getattr(id_, 'objects', []) or []:
                    visit(ob)
                return
        except Exception:
            pass

        try:
            if isinstance(id_, bpy.types.Object):
                visit(getattr(id_, 'parent', None))
                visit(getattr(id_, 'data', None))
                for slot in getattr(id_, 'material_slots', []) or []:
                    visit(getattr(slot, 'material', None))
                for con in getattr(id_, 'constraints', []) or []:
                    visit(getattr(con, 'target', None))
                for mod in getattr(id_, 'modifiers', []) or []:
                    for attr in (
                        'object', 'target', 'mirror_object', 'offset_object',
                        'start_cap', 'end_cap', 'cache_file', 'node_group',
                        'texture', 'texture_coords_object', 'curve',
                    ):
                        try:
                            visit(getattr(mod, attr, None))
                        except Exception:
                            pass
                if str(getattr(id_, 'type', '') or '').upper() == 'SPEAKER':
                    visit(getattr(getattr(id_, 'data', None), 'sound', None))
                if str(getattr(id_, 'type', '') or '').upper() == 'FONT':
                    curve = getattr(id_, 'data', None)
                    for attr in ('font', 'font_bold', 'font_italic', 'font_bold_italic'):
                        try:
                            visit(getattr(curve, attr, None))
                        except Exception:
                            pass
                ad = getattr(id_, 'animation_data', None)
                visit(getattr(ad, 'action', None))
                _sf_ext_visit_driver_targets(ad, visit)
                return
        except Exception:
            pass

        try:
            if isinstance(id_, bpy.types.Mesh):
                for mat in getattr(id_, 'materials', []) or []:
                    visit(mat)
                return
        except Exception:
            pass

        try:
            if isinstance(id_, bpy.types.Material):
                if getattr(id_, 'use_nodes', False):
                    visit(getattr(id_, 'node_tree', None))
                return
        except Exception:
            pass

        try:
            if isinstance(id_, bpy.types.World):
                if getattr(id_, 'use_nodes', False):
                    visit(getattr(id_, 'node_tree', None))
                return
        except Exception:
            pass

        try:
            if isinstance(id_, bpy.types.NodeTree):
                for node in getattr(id_, 'nodes', []) or []:
                    visit(getattr(node, 'node_tree', None))
                    for attr in ('image', 'movie_clip', 'object', 'collection', 'material', 'texture', 'cache_file', 'sound'):
                        try:
                            visit(getattr(node, attr, None))
                        except Exception:
                            pass
                return
        except Exception:
            pass

        # Text datablocks are intentionally only included when requested from current-file scans.
        if include_texts:
            add_rec(id_)

    for root in list(root_ids or []):
        visit(root)

    records.sort(key=lambda it: (str(it.get('kind_label') or ''), str(it.get('name') or ''), str(it.get('raw_path') or '')))
    return records


def _sf_ext_summary(records: list[dict]) -> dict:
    summary = {
        'total_records': len(records or []),
        'missing_records': 0,
        'packed_records': 0,
        'absolute_records': 0,
        'relative_records': 0,
        'env_records': 0,
        'sequence_records': 0,
        'kinds': {},
        'duplicates': {},
    }
    base_map = {}
    for rec in list(records or []):
        kind = str(rec.get('kind_key', 'UNKNOWN') or 'UNKNOWN')
        row = summary['kinds'].setdefault(kind, {
            'label': str(rec.get('kind_label', kind) or kind),
            'count': 0,
            'missing': 0,
            'packed': 0,
        })
        row['count'] += 1
        if bool(rec.get('packed')):
            summary['packed_records'] += 1
            row['packed'] += 1
        if not bool(rec.get('exists')) and not bool(rec.get('packed')):
            summary['missing_records'] += 1
            row['missing'] += 1
        style = str(rec.get('path_style', '') or '')
        if style == 'ABSOLUTE':
            summary['absolute_records'] += 1
        elif style == 'RELATIVE':
            summary['relative_records'] += 1
        elif style == 'ENV':
            summary['env_records'] += 1
        if str(rec.get('sequence_mode', 'FILE') or 'FILE') != 'FILE':
            summary['sequence_records'] += 1
        base = os.path.basename(str(rec.get('raw_path') or rec.get('abs_path') or ''))
        if base:
            base_map.setdefault(base.lower(), []).append(rec)
    summary['duplicates'] = {k: v for k, v in base_map.items() if len(v) > 1}
    return summary


def _sf_ext_popup_payload(*, include_libraries: bool = True, include_texts: bool = False) -> dict:
    records = _sf_ext_collect_current_file_records(include_libraries=include_libraries, include_texts=include_texts, include_missing=True)
    summary = _sf_ext_summary(records)
    payload = {
        'summary': summary,
        'current_blend': _norm_path(bpy.data.filepath or ''),
        'missing_preview': [
            {
                'kind': str(rec.get('kind_label') or ''),
                'name': str(rec.get('name') or ''),
                'raw_path': str(rec.get('raw_path') or ''),
                'abs_path': str(rec.get('abs_path') or ''),
            }
            for rec in records if (not rec.get('exists')) and (not rec.get('packed'))
        ][:8],
        'kinds': [summary['kinds'][k] for k in sorted(summary['kinds'].keys())],
    }
    return payload


def _sf_ext_report_lines(records: list[dict], *, title: str = 'External Asset Audit') -> list[str]:
    summary = _sf_ext_summary(records)
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    current_blend = _norm_path(bpy.data.filepath or '') or _t('Unsaved current file')
    lines = [
        f"Smart File | {title} | {now}",
        '',
        f"- {_t('Current File')}: {current_blend}",
        f"- {_t('Total')}: {summary.get('total_records', 0)}",
        f"- {_t('Missing')}: {summary.get('missing_records', 0)}",
        f"- {_t('Packed')}: {summary.get('packed_records', 0)}",
        f"- {_t('Absolute')}: {summary.get('absolute_records', 0)}",
        f"- {_t('Relative')}: {summary.get('relative_records', 0)}",
        f"- {_t('Environment Variables')}: {summary.get('env_records', 0)}",
        f"- {_t('Sequences')}: {summary.get('sequence_records', 0)}",
        '',
        'BY TYPE',
    ]
    for kind in sorted(summary.get('kinds', {}).keys()):
        row = summary['kinds'][kind]
        lines.append(f"- {row.get('label', kind)}: total={row.get('count', 0)} | missing={row.get('missing', 0)} | packed={row.get('packed', 0)}")

    missing = [rec for rec in records if (not rec.get('exists')) and (not rec.get('packed'))]
    if missing:
        lines.extend(['', 'MISSING REFERENCES'])
        for rec in missing:
            lines.append(
                f"- [{rec.get('kind_label','')}] {rec.get('name','')} | raw={rec.get('raw_path','')} | abs={rec.get('abs_path','')}"
            )

    abs_rows = [rec for rec in records if str(rec.get('path_style', '')) == 'ABSOLUTE']
    if abs_rows:
        lines.extend(['', 'ABSOLUTE PATHS'])
        for rec in abs_rows[:200]:
            lines.append(f"- [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('abs_path','')}")

    env_rows = [rec for rec in records if bool(rec.get('uses_env'))]
    if env_rows:
        lines.extend(['', 'ENVIRONMENT-VARIABLE PATHS'])
        for rec in env_rows[:200]:
            lines.append(f"- [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('raw_path','')}")

    dupes = summary.get('duplicates', {}) or {}
    if dupes:
        lines.extend(['', 'DUPLICATE BASENAMES'])
        for basename, items in sorted(dupes.items()):
            lines.append(f"- {basename}")
            for rec in items:
                lines.append(f"  - [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('abs_path','')}")

    lines.extend(['', 'DETAILS'])
    for rec in records:
        tag_bits = []
        if rec.get('packed'):
            tag_bits.append('PACKED')
        if rec.get('exists'):
            tag_bits.append('OK')
        else:
            tag_bits.append('MISSING')
        seq_mode = str(rec.get('sequence_mode', 'FILE') or 'FILE')
        if seq_mode != 'FILE':
            tag_bits.append(seq_mode)
        lines.append(
            f"- [{'|'.join(tag_bits)}] [{rec.get('kind_label','')}] {rec.get('name','')} | style={rec.get('path_style','')} | raw={rec.get('raw_path','')} | abs={rec.get('abs_path','')}"
        )
    return lines



def _sf_ext_bundle_manifest_candidates(bundle_path: str) -> tuple[str, list[str], str]:
    bundle_path = _norm_path(bundle_path or '')
    if not bundle_path:
        return '', [], ''
    if os.path.isdir(bundle_path):
        candidates = []
        try:
            for fn in sorted(os.listdir(bundle_path)):
                if fn.lower().endswith('.manifest.json'):
                    candidates.append(_norm_path(os.path.join(bundle_path, fn)))
        except Exception:
            candidates = []
        if candidates:
            return 'FOLDER', candidates, _norm_path(bundle_path)
        return 'FOLDER', [], _norm_path(bundle_path)
    if os.path.isfile(bundle_path) and bundle_path.lower().endswith('.manifest.json'):
        return 'FOLDER', [bundle_path], _norm_path(os.path.dirname(bundle_path))
    if os.path.isfile(bundle_path) and bundle_path.lower().endswith('.zip'):
        members = []
        try:
            with zipfile.ZipFile(bundle_path, 'r') as zf:
                members = [name for name in zf.namelist() if name.lower().endswith('.manifest.json')]
        except Exception:
            members = []
        return 'ZIP', members, _norm_path(bundle_path)
    return '', [], ''



def _sf_ext_bundle_sequence_match_count(folder_path: str, raw_name: str) -> int:
    folder_path = _norm_path(folder_path or '')
    raw_name = str(raw_name or '')
    if (not folder_path) or (not raw_name) or (not os.path.isdir(folder_path)):
        return 0
    seq_kind, token = _sf_ext_token_pattern(raw_name)
    if not seq_kind:
        return 0
    _glob_name, rx = _sf_ext_sequence_glob_and_regex(raw_name, seq_kind, token)
    count = 0
    try:
        for fn in os.listdir(folder_path):
            try:
                if rx.match(fn):
                    count += 1
            except Exception:
                pass
    except Exception:
        return 0
    return count



def _sf_ext_zip_sequence_match_count(member_names: list[str], parent_rel: str, raw_name: str) -> int:
    raw_name = str(raw_name or '')
    seq_kind, token = _sf_ext_token_pattern(raw_name)
    if not seq_kind:
        return 0
    _glob_name, rx = _sf_ext_sequence_glob_and_regex(raw_name, seq_kind, token)
    parent_rel = str(parent_rel or '').strip('/\\')
    count = 0
    for member in list(member_names or []):
        member = str(member or '').replace('\\', '/')
        bn = os.path.basename(member)
        parent = os.path.dirname(member).strip('/\\')
        if parent_rel and parent != parent_rel:
            continue
        try:
            if rx.match(bn):
                count += 1
        except Exception:
            pass
    return count



def _sf_ext_verify_bundle_folder(bundle_dir: str, manifest_path: str = '') -> dict:
    bundle_dir = _norm_path(bundle_dir or '')
    payload = {
        'mode': 'FOLDER',
        'bundle_path': bundle_dir,
        'manifest_path': _norm_path(manifest_path or ''),
        'manifest_found': False,
        'bundle_blend_ok': False,
        'external_root_ok': False,
        'copied_expected': 0,
        'copied_verified': 0,
        'copied_missing': 0,
        'missing_preview': [],
        'manifest_missing_records': 0,
        'packed_records': 0,
        'warnings': [],
    }
    if not bundle_dir or not os.path.isdir(bundle_dir):
        payload['warnings'].append(_t('Bundle folder is missing'))
        return payload
    if (not manifest_path) or (not os.path.isfile(manifest_path)):
        kind, candidates, resolved_root = _sf_ext_bundle_manifest_candidates(bundle_dir)
        if kind == 'FOLDER' and candidates:
            manifest_path = candidates[0]
            bundle_dir = resolved_root or bundle_dir
            payload['bundle_path'] = bundle_dir
    manifest = {}
    if manifest_path and os.path.isfile(manifest_path):
        try:
            with open(manifest_path, 'r', encoding='utf-8') as handle:
                manifest = json.load(handle) or {}
            payload['manifest_found'] = True
            payload['manifest_path'] = _norm_path(manifest_path)
        except Exception as ex:
            payload['warnings'].append(f"{_t('Could not read manifest')}: {ex}")
            manifest = {}
    else:
        payload['warnings'].append(_t('Bundle manifest was not found'))

    all_files = []
    basename_map = {}
    try:
        for dirpath, _dirnames, filenames in os.walk(bundle_dir):
            for fn in filenames:
                abs_fp = _norm_path(os.path.join(dirpath, fn))
                all_files.append(abs_fp)
                basename_map.setdefault(fn.lower(), []).append(abs_fp)
    except Exception:
        pass
    payload['external_root_ok'] = os.path.isdir(os.path.join(bundle_dir, 'external'))

    bundle_blend = str((manifest or {}).get('bundle_blend', '') or '')
    if bundle_blend:
        bb = _norm_path(bundle_blend)
        if os.path.isfile(bb):
            payload['bundle_blend_ok'] = True
        else:
            fallback = _norm_path(os.path.join(bundle_dir, os.path.basename(bb)))
            payload['bundle_blend_ok'] = os.path.isfile(fallback)
    else:
        payload['bundle_blend_ok'] = bool(glob.glob(os.path.join(bundle_dir, '*.blend')))

    items = list((manifest or {}).get('items', []) or [])
    payload['manifest_missing_records'] = sum(1 for row in items if str(row.get('status', '')).upper() == 'MISSING')
    payload['packed_records'] = sum(1 for row in items if str(row.get('status', '')).upper() == 'PACKED')
    preview = []
    for row in items:
        status = str(row.get('status', '') or '').upper()
        if status != 'COPIED':
            continue
        payload['copied_expected'] += 1
        new_path = str(row.get('new_path', '') or '')
        file_count = max(1, int(row.get('file_count', 0) or 0))
        ok = False
        if new_path.startswith('//'):
            rel = new_path[2:].replace('/', os.sep)
            cand = _norm_path(os.path.join(bundle_dir, rel))
        elif new_path:
            cand = _norm_path(new_path)
            if os.path.isabs(cand) and (not os.path.exists(cand)):
                fallback = basename_map.get(os.path.basename(cand).lower(), [])
                cand = fallback[0] if len(fallback) == 1 else cand
        else:
            cand = ''
        if cand and os.path.isfile(cand):
            ok = True
        elif cand:
            seq_count = _sf_ext_bundle_sequence_match_count(os.path.dirname(cand), os.path.basename(cand))
            if seq_count >= file_count:
                ok = True
            elif os.path.isdir(os.path.dirname(cand)):
                try:
                    ok = len([fn for fn in os.listdir(os.path.dirname(cand)) if os.path.isfile(os.path.join(os.path.dirname(cand), fn))]) >= file_count
                except Exception:
                    ok = False
        if ok:
            payload['copied_verified'] += 1
        else:
            payload['copied_missing'] += 1
            if len(preview) < 12:
                preview.append(f"[{row.get('kind','')}] {row.get('name','')} | {new_path or row.get('raw_path','')}")
    payload['missing_preview'] = preview
    if payload['copied_expected'] == 0 and payload['manifest_found']:
        payload['warnings'].append(_t('Manifest contains no copied records'))
    if (not payload['external_root_ok']) and payload['copied_expected']:
        payload['warnings'].append(_t('External bundle folder is missing'))
    if (not payload['bundle_blend_ok']) and str((manifest or {}).get('bundle_blend', '') or ''):
        payload['warnings'].append(_t('Bundled blend copy is missing'))
    return payload



def _sf_ext_verify_bundle_zip(zip_path: str) -> dict:
    zip_path = _norm_path(zip_path or '')
    payload = {
        'mode': 'ZIP',
        'bundle_path': zip_path,
        'manifest_path': '',
        'manifest_found': False,
        'bundle_blend_ok': False,
        'external_root_ok': False,
        'copied_expected': 0,
        'copied_verified': 0,
        'copied_missing': 0,
        'missing_preview': [],
        'manifest_missing_records': 0,
        'packed_records': 0,
        'warnings': [],
    }
    if not zip_path or not os.path.isfile(zip_path):
        payload['warnings'].append(_t('Bundle ZIP is missing'))
        return payload
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            members = [name for name in zf.namelist() if not name.endswith('/')]
            manifest_members = [name for name in members if name.lower().endswith('.manifest.json')]
            if not manifest_members:
                payload['warnings'].append(_t('Bundle manifest was not found'))
                return payload
            manifest_member = manifest_members[0]
            payload['manifest_path'] = manifest_member
            payload['manifest_found'] = True
            try:
                manifest = json.loads(zf.read(manifest_member).decode('utf-8')) or {}
            except Exception as ex:
                payload['warnings'].append(f"{_t('Could not read manifest')}: {ex}")
                return payload
            bundle_root = os.path.dirname(manifest_member).strip('/\\')
            payload['external_root_ok'] = any(str(name).replace('\\', '/').startswith((bundle_root + '/external/').strip('/')) for name in members)
            bundle_blend = str((manifest or {}).get('bundle_blend', '') or '')
            if bundle_blend:
                target_name = os.path.basename(bundle_blend)
                payload['bundle_blend_ok'] = any(os.path.basename(name) == target_name and ((not bundle_root) or str(name).replace('\\', '/').startswith(bundle_root + '/')) for name in members)
            else:
                payload['bundle_blend_ok'] = any(name.lower().endswith('.blend') and ((not bundle_root) or str(name).replace('\\', '/').startswith(bundle_root + '/')) for name in members)

            items = list((manifest or {}).get('items', []) or [])
            payload['manifest_missing_records'] = sum(1 for row in items if str(row.get('status', '')).upper() == 'MISSING')
            payload['packed_records'] = sum(1 for row in items if str(row.get('status', '')).upper() == 'PACKED')
            preview = []
            basename_map = {}
            for name in members:
                basename_map.setdefault(os.path.basename(name).lower(), []).append(name)
            for row in items:
                status = str(row.get('status', '') or '').upper()
                if status != 'COPIED':
                    continue
                payload['copied_expected'] += 1
                new_path = str(row.get('new_path', '') or '')
                file_count = max(1, int(row.get('file_count', 0) or 0))
                ok = False
                if new_path.startswith('//'):
                    rel = new_path[2:].replace('\\', '/').strip('/')
                    member = f"{bundle_root}/{rel}".strip('/') if bundle_root else rel
                    if member in members:
                        ok = True
                    else:
                        seq_count = _sf_ext_zip_sequence_match_count(members, os.path.dirname(member).strip('/\\'), os.path.basename(member))
                        if seq_count >= file_count:
                            ok = True
                elif new_path:
                    target_name = os.path.basename(new_path)
                    hits = [name for name in basename_map.get(target_name.lower(), []) if (not bundle_root) or str(name).replace('\\', '/').startswith(bundle_root + '/')]
                    if len(hits) == 1:
                        ok = True
                if ok:
                    payload['copied_verified'] += 1
                else:
                    payload['copied_missing'] += 1
                    if len(preview) < 12:
                        preview.append(f"[{row.get('kind','')}] {row.get('name','')} | {new_path or row.get('raw_path','')}")
            payload['missing_preview'] = preview
    except Exception as ex:
        payload['warnings'].append(f"{_t('Could not read ZIP')}: {ex}")
    return payload



def _sf_ext_verify_bundle_target(bundle_path: str) -> dict:
    mode, candidates, resolved = _sf_ext_bundle_manifest_candidates(bundle_path)
    if mode == 'ZIP':
        return _sf_ext_verify_bundle_zip(resolved or bundle_path)
    if mode == 'FOLDER':
        manifest_path = candidates[0] if candidates else (bundle_path if str(bundle_path).lower().endswith('.manifest.json') else '')
        bundle_root = resolved or _norm_path(os.path.dirname(bundle_path)) if str(bundle_path).lower().endswith('.manifest.json') else (resolved or bundle_path)
        return _sf_ext_verify_bundle_folder(bundle_root, manifest_path=manifest_path)
    payload = {
        'mode': '', 'bundle_path': _norm_path(bundle_path or ''), 'manifest_path': '', 'manifest_found': False,
        'bundle_blend_ok': False, 'external_root_ok': False, 'copied_expected': 0, 'copied_verified': 0,
        'copied_missing': 0, 'missing_preview': [], 'manifest_missing_records': 0, 'packed_records': 0,
        'warnings': [_t('Select a bundle folder, manifest, or ZIP file')],
    }
    return payload



def _sf_ext_verify_bundle_report_lines(title: str, payload: dict) -> list[str]:
    bundle_path = _norm_path(str((payload or {}).get('bundle_path', '') or ''))
    manifest_path = str((payload or {}).get('manifest_path', '') or '')
    lines = [
        f"Smart File | {title} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        '',
        f"- {_t('Bundle')}: {bundle_path or _t('Not set')}",
        f"- {_t('Mode')}: {str((payload or {}).get('mode', '') or '')}",
        f"- {_t('Manifest')}: {manifest_path or _t('Not found')}",
        f"- {_t('Bundle Blend')}: {_t('OK') if bool((payload or {}).get('bundle_blend_ok')) else _t('Missing')}",
        f"- {_t('External Folder')}: {_t('OK') if bool((payload or {}).get('external_root_ok')) else _t('Missing')}",
        f"- {_t('Copied Records')}: {int((payload or {}).get('copied_verified', 0) or 0)} / {int((payload or {}).get('copied_expected', 0) or 0)}",
        f"- {_t('Missing')}: {int((payload or {}).get('copied_missing', 0) or 0)}",
        f"- {_t('Manifest Missing')}: {int((payload or {}).get('manifest_missing_records', 0) or 0)}",
        f"- {_t('Packed')}: {int((payload or {}).get('packed_records', 0) or 0)}",
    ]
    warnings = list((payload or {}).get('warnings') or [])
    if warnings:
        lines.extend(['', 'WARNINGS'])
        for row in warnings:
            lines.append(f"- {row}")
    preview = list((payload or {}).get('missing_preview') or [])
    if preview:
        lines.extend(['', 'MISSING PREVIEW'])
        for row in preview:
            lines.append(f"- {row}")
    return lines


def _sf_ext_unique_folder_name(parent_dir: str, token: str, used: set[str]) -> str:
    token = _safe_filename(token) or 'item'
    candidate = token
    idx = 1
    while candidate.lower() in used or os.path.exists(os.path.join(parent_dir, candidate)):
        candidate = f"{token}_{idx:03d}"
        idx += 1
    used.add(candidate.lower())
    return candidate


def _sf_ext_copy_records(records: list[dict], target_dir: str, *, subdir: str = 'external', remap_mode: str = 'RELATIVE', flat_images_when_possible: bool = False) -> dict:
    target_dir = _norm_path(target_dir)
    os.makedirs(target_dir, exist_ok=True)
    remap_mode = str(remap_mode or 'RELATIVE').upper()
    subdir = (_safe_filename(subdir) or 'external').strip('/\\') or 'external'

    kinds_present = {str(rec.get('kind_key') or '') for rec in records if rec.get('resolved_paths') and (not rec.get('packed'))}
    flatten_images = bool(flat_images_when_possible and kinds_present == {'IMAGE'})

    copied_files = []
    remap = {}
    source_to_dest = {}
    used_folder_names = {}
    used_file_names = {}
    manifest_rows = []
    stats = {
        'copied_records': 0,
        'copied_files': 0,
        'missing_records': 0,
        'packed_records': 0,
        'skipped_records': 0,
        'kinds': {},
    }

    for rec in records:
        kind_key = str(rec.get('kind_key', 'UNKNOWN') or 'UNKNOWN')
        kind_label = str(rec.get('kind_label', kind_key) or kind_key)
        row = stats['kinds'].setdefault(kind_key, {'label': kind_label, 'records': 0, 'copied_files': 0})
        row['records'] += 1

        key = _sf_ext_record_key(rec)
        resolved_paths = [p for p in list(rec.get('resolved_paths') or []) if p and os.path.exists(p)]

        if rec.get('packed'):
            stats['packed_records'] += 1
            manifest_rows.append({
                'key': key,
                'kind': kind_label,
                'name': rec.get('name', ''),
                'status': 'PACKED',
                'raw_path': rec.get('raw_path', ''),
            })
            continue

        if not resolved_paths:
            stats['missing_records'] += 1
            manifest_rows.append({
                'key': key,
                'kind': kind_label,
                'name': rec.get('name', ''),
                'status': 'MISSING',
                'raw_path': rec.get('raw_path', ''),
                'abs_path': rec.get('abs_path', ''),
            })
            continue

        kind_subdir = str(rec.get('kind_subdir') or 'external')
        if flatten_images and kind_key == 'IMAGE':
            kind_rel_dir = subdir
        else:
            kind_rel_dir = os.path.join(subdir, kind_subdir)
        kind_abs_dir = os.path.join(target_dir, kind_rel_dir)
        os.makedirs(kind_abs_dir, exist_ok=True)

        seq_mode = str(rec.get('sequence_mode', 'FILE') or 'FILE')
        multi_file = len(resolved_paths) > 1 or seq_mode != 'FILE'

        record_rel_dir = kind_rel_dir
        record_abs_dir = kind_abs_dir

        if multi_file:
            used = used_folder_names.setdefault(kind_abs_dir, set())
            token = _sf_ext_unique_folder_name(kind_abs_dir, f"{kind_key.lower()}_{rec.get('name') or os.path.splitext(os.path.basename(rec.get('raw_path') or rec.get('abs_path') or 'item'))[0]}", used)
            record_abs_dir = os.path.join(kind_abs_dir, token)
            record_rel_dir = os.path.join(kind_rel_dir, token)
            os.makedirs(record_abs_dir, exist_ok=True)

        copied_for_record = []
        for src in resolved_paths:
            src = _norm_path(src)
            if src in source_to_dest:
                dst = source_to_dest[src]
            else:
                base_name = os.path.basename(src)
                if multi_file:
                    dst = os.path.join(record_abs_dir, base_name)
                else:
                    used_names = used_file_names.setdefault(record_abs_dir, set())
                    safe_stem, safe_ext = os.path.splitext(_safe_filename(os.path.splitext(base_name)[0]) or os.path.splitext(base_name)[0] or 'file')
                    safe_ext = os.path.splitext(base_name)[1] or safe_ext or ''
                    cand = f"{safe_stem}{safe_ext}"
                    n = 1
                    while cand.lower() in used_names or os.path.exists(os.path.join(record_abs_dir, cand)):
                        cand = f"{safe_stem}_{n:03d}{safe_ext}"
                        n += 1
                    used_names.add(cand.lower())
                    dst = os.path.join(record_abs_dir, cand)
                shutil.copy2(src, dst)
                source_to_dest[src] = dst
                copied_files.append(dst)
                stats['copied_files'] += 1
                row['copied_files'] += 1
            copied_for_record.append(source_to_dest[src])

        stats['copied_records'] += 1

        if remap_mode == 'KEEP':
            new_path = str(rec.get('raw_path') or rec.get('abs_path') or '')
        elif remap_mode == 'ABSOLUTE':
            if seq_mode in _SF_EXT_TOKENIZED_SEQUENCE_KINDS:
                token_name = os.path.basename(str(rec.get('raw_path') or '')) or os.path.basename(str(rec.get('abs_path') or ''))
                new_path = _norm_path(os.path.join(record_abs_dir, token_name))
            else:
                anchor_src = _norm_path(str(rec.get('abs_path') or ''))
                anchor_dst = source_to_dest.get(anchor_src) if anchor_src else ''
                if not anchor_dst:
                    anchor_dst = copied_for_record[0] if copied_for_record else ''
                new_path = _norm_path(anchor_dst)
        else:
            if seq_mode in _SF_EXT_TOKENIZED_SEQUENCE_KINDS:
                token_name = os.path.basename(str(rec.get('raw_path') or '')) or os.path.basename(str(rec.get('abs_path') or ''))
                rel_token = os.path.join(record_rel_dir, token_name).replace(os.sep, '/')
                new_path = f"//{rel_token}"
            else:
                anchor_src = _norm_path(str(rec.get('abs_path') or ''))
                anchor_dst = source_to_dest.get(anchor_src) if anchor_src else ''
                if not anchor_dst:
                    anchor_dst = copied_for_record[0] if copied_for_record else ''
                rel_anchor = os.path.relpath(anchor_dst, target_dir).replace(os.sep, '/') if anchor_dst else ''
                new_path = f"//{rel_anchor}" if rel_anchor else ''

        remap[key] = new_path
        manifest_rows.append({
            'key': key,
            'kind': kind_label,
            'name': rec.get('name', ''),
            'status': 'COPIED',
            'raw_path': rec.get('raw_path', ''),
            'abs_path': rec.get('abs_path', ''),
            'new_path': new_path,
            'file_count': len(copied_for_record),
        })

    return {
        'copied_files': [_norm_path(p) for p in copied_files],
        'remap': remap,
        'stats': stats,
        'manifest_rows': manifest_rows,
    }


def _sf_ext_apply_remap(records: list[dict], remap_table: dict) -> list[tuple[object, str]]:
    original = []
    for rec in records:
        id_ = rec.get('id_ref')
        if id_ is None:
            continue
        key = _sf_ext_record_key(rec)
        new_path = str((remap_table or {}).get(key, '') or '').strip()
        if not new_path:
            continue
        try:
            old_path = getattr(id_, 'filepath', '') or ''
        except Exception:
            continue
        try:
            if old_path == new_path:
                continue
            setattr(id_, 'filepath', new_path)
            original.append((id_, old_path))
        except Exception:
            pass
    return original


def _sf_ext_restore_paths(original_rows: list[tuple[object, str]]):
    for id_, old_path in list(original_rows or []):
        try:
            setattr(id_, 'filepath', old_path)
        except Exception:
            pass


def _sf_ext_find_search_roots(context, search_dir: str = '', *, include_current_file_dir: bool = True, include_library_roots: bool = True, include_context_roots: bool = True) -> list[str]:
    roots = []
    if search_dir:
        roots.append(_norm_path(search_dir))
    if include_current_file_dir:
        current_dir = _norm_path(os.path.dirname(bpy.data.filepath or '')) if bpy.data.filepath else ''
        if current_dir:
            roots.append(current_dir)
    if include_library_roots:
        prefs = _addon_prefs(context)
        if prefs:
            for root in list(getattr(prefs, 'library_roots', []) or []):
                if not bool(getattr(root, 'enabled', True)):
                    continue
                path = _norm_path(getattr(root, 'path', '') or '')
                if path:
                    roots.append(path)
    if include_context_roots:
        try:
            for row in _sf_ctx_root_rows(context, kind_key='ANY', existing_only=True, include_library_roots=False):
                path = _norm_path(row.get('path') or '')
                if path:
                    roots.append(path)
        except Exception:
            pass
    dedup = []
    seen = set()
    for root in roots:
        if not root or root in seen or (not os.path.isdir(root)):
            continue
        seen.add(root)
        dedup.append(root)
    return dedup


def _sf_ext_build_basename_index(search_roots: list[str], allowed_suffixes: set[str] | None = None) -> dict[str, list[str]]:
    index = {}
    allowed_suffixes = _sf_ext_expand_allowed_suffixes(allowed_suffixes)
    seen_roots = set()
    hidden_dirs = {'__pycache__', '.git', '.hg', '.svn'}
    for root in list(search_roots or []):
        root = _norm_path(root)
        if not root or root in seen_roots or not os.path.isdir(root):
            continue
        seen_roots.add(root)
        for dirpath, dirnames, filenames in os.walk(root):
            try:
                dirnames[:] = [d for d in dirnames if d and not d.startswith('.') and d.lower() not in hidden_dirs]
            except Exception:
                pass
            for fn in filenames:
                ext = os.path.splitext(fn)[1].lower()
                if allowed_suffixes and ext not in allowed_suffixes:
                    continue
                full_path = _norm_path(os.path.join(dirpath, fn))
                for key in _sf_ext_index_keys_for_filename(fn):
                    index.setdefault(key, []).append(full_path)
    for key, values in list(index.items()):
        index[key] = _sf_ref_dedup_paths(values)
    return index


def _sf_ext_pick_best_candidate(rec: dict, candidates: list[str]) -> str:
    if not candidates:
        return ''
    target_path = str(rec.get('abs_path') or rec.get('raw_path') or '')
    target_dir_n = _norm_path(os.path.dirname(target_path))
    target_name = os.path.basename(target_path).lower()
    target_stem, target_ext = os.path.splitext(target_name)
    target_family = _sf_ext_extension_family(target_ext)

    def score(path: str):
        path = _norm_path(path)
        cand_name = os.path.basename(path).lower()
        cand_stem, cand_ext = os.path.splitext(cand_name)
        cand_family = _sf_ext_extension_family(cand_ext)
        same_name = 1 if cand_name == target_name and cand_name else 0
        same_stem = 1 if cand_stem == target_stem and cand_stem else 0
        same_ext = 1 if cand_ext == target_ext and cand_ext else 0
        same_family = 1 if target_family and cand_family == target_family else 0
        same_dir = 1 if target_dir_n and os.path.dirname(path) == target_dir_n else 0
        tail_match = _sf_ctx_tail_match_count(target_path, path) if target_path else 0
        common = 0
        try:
            if target_dir_n:
                common = len(os.path.commonpath([target_dir_n, os.path.dirname(path)]))
        except Exception:
            common = 0
        return (same_name, same_stem, same_ext, same_family, same_dir, tail_match, common, -len(path))

    return sorted(candidates, key=score, reverse=True)[0]



def _sf_ext_conflict_payload(context, *, search_dir: str = '', include_current_file_dir: bool = True, include_library_roots: bool = True, include_context_roots: bool = True, include_libraries: bool = True, include_texts: bool = False, only_missing: bool = True) -> dict:
    records = _sf_ext_collect_current_file_records(include_libraries=include_libraries, include_texts=include_texts, include_missing=True)
    summary = _sf_ext_summary(records)
    targets = []
    for rec in list(records or []):
        if rec.get('packed'):
            continue
        if only_missing and rec.get('exists'):
            continue
        targets.append(rec)

    basename_rows: dict[str, list[dict]] = {}
    for rec in list(records or []):
        base = os.path.basename(str(rec.get('raw_path') or rec.get('abs_path') or '')).lower()
        if not base:
            continue
        basename_rows.setdefault(base, []).append(rec)
    current_conflicts = []
    for base, rows in sorted(basename_rows.items()):
        unique_paths = []
        seen_paths = set()
        for rec in rows:
            path = _norm_path(str(rec.get('abs_path') or rec.get('raw_path') or ''))
            if path and path not in seen_paths:
                seen_paths.add(path)
                unique_paths.append(path)
        if len(unique_paths) > 1:
            current_conflicts.append({
                'basename': base,
                'paths': unique_paths,
                'count': len(unique_paths),
                'rows': [
                    {
                        'kind': str(rec.get('kind_label') or ''),
                        'name': str(rec.get('name') or ''),
                        'path': _norm_path(str(rec.get('abs_path') or rec.get('raw_path') or '')),
                    }
                    for rec in rows[:12]
                ],
            })

    roots = _sf_ext_find_search_roots(
        context,
        search_dir,
        include_current_file_dir=include_current_file_dir,
        include_library_roots=include_library_roots,
        include_context_roots=include_context_roots,
    )
    allowed_suffixes = set()
    for rec in list(targets or []):
        filename = os.path.basename(str(rec.get('raw_path') or rec.get('abs_path') or ''))
        ext = os.path.splitext(filename)[1].lower()
        if ext:
            family = _sf_ext_extension_family(ext)
            if family:
                allowed_suffixes.update(set(_SF_EXT_RELINK_EXTENSION_FAMILIES.get(family, set()) or set()))
            else:
                allowed_suffixes.add(ext)
    search_index = _sf_ext_build_basename_index(roots, allowed_suffixes=allowed_suffixes or None) if roots else {}
    ambiguous_targets = []
    for rec in list(targets or []):
        candidates = _sf_ref_dedup_paths(_sf_ext_sequence_index_candidates(rec, search_index)) if search_index else []
        if len(candidates) <= 1:
            continue
        ambiguous_targets.append({
            'kind': str(rec.get('kind_label') or ''),
            'name': str(rec.get('name') or ''),
            'raw_path': str(rec.get('raw_path') or ''),
            'candidate_count': len(candidates),
            'candidates': list(candidates[:12]),
            'recommended': _sf_ext_pick_best_candidate(rec, candidates),
        })

    root_library_conflicts = []
    if roots:
        blend_index = _sf_ext_build_basename_index(roots, allowed_suffixes={'.blend'})
        for key, values in sorted((blend_index or {}).items()):
            if str(key).startswith('@'):
                continue
            values = _sf_ref_dedup_paths(values)
            if len(values) > 1:
                root_library_conflicts.append({
                    'basename': key,
                    'count': len(values),
                    'paths': list(values[:12]),
                })

    warnings = []
    if ambiguous_targets:
        warnings.append(_t('More than one relink candidate matches at least one missing reference'))
    if current_conflicts:
        warnings.append(_t('Current file already contains duplicate basenames that point to different paths'))
    if root_library_conflicts:
        warnings.append(_t('Configured roots contain duplicate .blend names that can make relink or load decisions ambiguous'))
    if not roots:
        warnings.append(_t('No search roots were available for conflict scanning'))

    return {
        'current_blend': _norm_path(bpy.data.filepath or ''),
        'summary': summary,
        'target_count': len(list(targets or [])),
        'search_roots': list(roots or []),
        'search_root_count': len(list(roots or [])),
        'current_conflicts': current_conflicts,
        'ambiguous_targets': ambiguous_targets,
        'root_library_conflicts': root_library_conflicts,
        'warnings': warnings,
        'only_missing': bool(only_missing),
    }



def _sf_ext_conflict_report_lines(title: str, payload: dict) -> list[str]:
    summary = dict((payload or {}).get('summary') or {})
    current_conflicts = list((payload or {}).get('current_conflicts') or [])
    ambiguous_targets = list((payload or {}).get('ambiguous_targets') or [])
    root_library_conflicts = list((payload or {}).get('root_library_conflicts') or [])
    lines = [
        f"Smart File | {title} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        '',
        f"- {_t('Current File')}: {_norm_path(str((payload or {}).get('current_blend', '') or '')) or _t('Unsaved current file')}",
        f"- {_t('Search Roots')}: {int((payload or {}).get('search_root_count', 0) or 0)}",
        f"- {_t('Targets')}: {int((payload or {}).get('target_count', 0) or 0)}",
        f"- {_t('Current Basename Conflicts')}: {len(current_conflicts)}",
        f"- {_t('Ambiguous Relink Targets')}: {len(ambiguous_targets)}",
        f"- {_t('Root Library Name Conflicts')}: {len(root_library_conflicts)}",
        f"- {_t('Missing')}: {int(summary.get('missing_records', 0) or 0)}",
        f"- {_t('Absolute')}: {int(summary.get('absolute_records', 0) or 0)}",
        f"- {_t('Environment Variables')}: {int(summary.get('env_records', 0) or 0)}",
    ]
    warnings = list((payload or {}).get('warnings') or [])
    if warnings:
        lines.extend(['', 'WARNINGS'])
        for row in warnings:
            lines.append(f"- {row}")
    roots = list((payload or {}).get('search_roots') or [])
    if roots:
        lines.extend(['', 'SEARCH ROOTS'])
        for root in roots[:24]:
            lines.append(f"- {root}")
    if current_conflicts:
        lines.extend(['', 'CURRENT BASENAME CONFLICTS'])
        for row in current_conflicts[:24]:
            lines.append(f"- {row.get('basename','')} | {int(row.get('count', 0) or 0)}")
            for sub in list(row.get('rows') or [])[:8]:
                lines.append(f"  - [{sub.get('kind','')}] {sub.get('name','')} | {sub.get('path','')}")
    if ambiguous_targets:
        lines.extend(['', 'AMBIGUOUS RELINK TARGETS'])
        for row in ambiguous_targets[:24]:
            lines.append(f"- [{row.get('kind','')}] {row.get('name','')} | candidates={int(row.get('candidate_count', 0) or 0)} | raw={row.get('raw_path','')}")
            if row.get('recommended'):
                lines.append(f"  - recommended={row.get('recommended','')}")
            for cand in list(row.get('candidates') or [])[:8]:
                lines.append(f"  - {cand}")
    if root_library_conflicts:
        lines.extend(['', 'ROOT LIBRARY NAME CONFLICTS'])
        for row in root_library_conflicts[:24]:
            lines.append(f"- {row.get('basename','')} | {int(row.get('count', 0) or 0)}")
            for cand in list(row.get('paths') or [])[:8]:
                lines.append(f"  - {cand}")
    if not current_conflicts and not ambiguous_targets and not root_library_conflicts:
        lines.extend(['', f"- {_t('No basename or relink-candidate conflicts were detected in the scanned scope')}"])
    return lines


class SF_OT_external_assets_conflict_audit(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_external_assets_conflict_audit'
    bl_label = 'Conflict Audit'
    bl_description = 'Audit basename collisions inside the current file and ambiguous relink candidates inside the configured search roots before you relink, load, or bundle.'
    bl_options = {'UNDO'}

    search_dir: StringProperty(name='Search Folder', subtype='DIR_PATH', default='')
    include_current_file_dir: BoolProperty(name='Include current file folder', default=True)
    include_library_roots: BoolProperty(name='Include library roots', default=True)
    include_context_roots: BoolProperty(name='Include Context Roots', default=True)
    include_libraries: BoolProperty(name='Include linked libraries', default=True)
    include_texts: BoolProperty(name='Include text datablocks', default=False)
    only_missing: BoolProperty(name='Only missing references', default=True, description='Limit ambiguous-candidate scanning to missing references. Disable this when you also want to review risky duplicates for already resolved assets.')
    open_text: BoolProperty(name='Open report', default=True)

    def invoke(self, context, event):
        if not self.search_dir:
            self.search_dir = _norm_path(os.path.dirname(bpy.data.filepath or '')) if bpy.data.filepath else ''
        return context.window_manager.invoke_props_dialog(self, width=640)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'search_dir')
        layout.prop(self, 'include_current_file_dir')
        layout.prop(self, 'include_library_roots')
        layout.prop(self, 'include_context_roots')
        layout.prop(self, 'include_libraries')
        layout.prop(self, 'include_texts')
        layout.prop(self, 'only_missing')
        layout.prop(self, 'open_text')

    def execute(self, context):
        payload = _sf_ext_conflict_payload(
            context,
            search_dir=self.search_dir,
            include_current_file_dir=self.include_current_file_dir,
            include_library_roots=self.include_library_roots,
            include_context_roots=self.include_context_roots,
            include_libraries=self.include_libraries,
            include_texts=self.include_texts,
            only_missing=self.only_missing,
        )
        title = _t('External Conflict Audit')
        text_name = _sf_report_export(
            context,
            title,
            _sf_ext_conflict_report_lines(title, payload),
            open_text=self.open_text,
            activity_title=_t('Exported external conflict audit'),
        )
        warnings = list(payload.get('warnings') or [])
        if warnings:
            self.report({'WARNING'}, f"{_t('Conflict audit exported')}: {text_name}")
        else:
            self.report({'INFO'}, f"{_t('Conflict audit exported')}: {text_name}")
        return {'FINISHED'}


class SF_OT_external_assets_audit(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = 'import_scene.sfs_external_assets_audit'
    bl_label = 'Audit'
    bl_description = 'Scan the current open .blend for images, sounds, fonts, movie clips, volumes, cache files, linked libraries, and other file-based references, then summarize missing files, absolute paths, packed data, and portability risks.'
    bl_options = {'INTERNAL'}

    include_libraries: BoolProperty(name='Include linked libraries', default=True, options={'HIDDEN'})
    include_texts: BoolProperty(name='Include text datablocks', default=False, options={'HIDDEN'})
    popup_width: IntProperty(default=540, min=360, max=860, options={'HIDDEN'})
    payload_json: StringProperty(default="", options={'HIDDEN'})

    def invoke(self, context, event):
        payload = _sf_ext_popup_payload(include_libraries=self.include_libraries, include_texts=self.include_texts)
        try:
            self.payload_json = json.dumps(payload, ensure_ascii=False)
        except Exception:
            self.payload_json = "{}"
        _sf_append_activity(context, _t('Opened external asset audit'), _norm_path(bpy.data.filepath or ''), 'FILE_FOLDER')
        return context.window_manager.invoke_popup(self, width=self.popup_width)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        try:
            payload = json.loads(self.payload_json or '{}') or {}
        except Exception:
            payload = {}
        summary = payload.get('summary') or {}
        current_blend = str(payload.get('current_blend') or '')
        missing_preview = list(payload.get('missing_preview') or [])
        kinds = list(payload.get('kinds') or [])

        hero = layout.box()
        hero.label(text=_t('External Asset Audit...'), icon='FILE_FOLDER')
        hero.label(text=_sf_short_path_display(current_blend or _t('Unsaved current file'), 68), icon='FILE_BLEND')

        grid = layout.grid_flow(columns=3, row_major=True, even_columns=True, even_rows=False, align=True)
        badges = [
            (_t('Total'), int(summary.get('total_records', 0)), 'FILE'),
            (_t('Missing'), int(summary.get('missing_records', 0)), 'ERROR'),
            (_t('Packed'), int(summary.get('packed_records', 0)), 'PACKAGE'),
            (_t('Absolute'), int(summary.get('absolute_records', 0)), 'FILE_FOLDER'),
            (_t('Relative'), int(summary.get('relative_records', 0)), 'FILE_PARENT'),
            (_t('Environment Variables'), int(summary.get('env_records', 0)), 'PREFERENCES'),
        ]
        for title, value, icon in badges:
            box = grid.box()
            box.label(text=title, icon=icon)
            box.label(text=str(value), icon='BLANK1')

        if kinds:
            kinds_box = layout.box()
            kinds_box.label(text=_t('By Type'), icon='ALIGN_JUSTIFY')
            for row in kinds:
                kinds_box.label(text=f"{row.get('label','')}: {_t('total')} {row.get('count',0)} | {_t('missing')} {row.get('missing',0)} | {_t('packed')} {row.get('packed',0)}", icon='BLANK1')

        if missing_preview:
            miss_box = layout.box()
            miss_box.label(text=_t('Missing Preview'), icon='ERROR')
            for row in missing_preview:
                miss_box.label(text=f"[{row.get('kind','')}] {row.get('name','')}", icon='BLANK1')
                miss_box.label(text=_sf_short_path_display(str(row.get('raw_path') or row.get('abs_path') or ''), 72), icon='BLANK1')

        ticket = _sf_link_edit_current_ticket(context)
        if ticket and _sf_link_edit_ticket_matches_current(ticket, bpy.data.filepath or ''):
            roundtrip_box = layout.box()
            roundtrip_box.label(text=_t('Linked Edit Return'), icon='LOOP_BACK')
            _sf_draw_state_line(roundtrip_box, 'Parent Scene', 'READY', detail=os.path.basename(str(ticket.get('parent_blend', '') or '')) or _t('Unknown'))
            _sf_draw_state_line(roundtrip_box, 'Linked Child', 'READY', detail=os.path.basename(str(ticket.get('child_blend', '') or '')) or _t('Unknown'))
            if str(ticket.get('label', '') or '').strip():
                roundtrip_box.label(text=_sf_short_path_display(str(ticket.get('label', '') or ''), 72), icon='BLANK1')
            row = roundtrip_box.row(align=True)
            row.operator('import_scene.sfs_external_assets_return_to_parent_scene', text=_t('Return to Parent Scene'), icon='LOOP_BACK')
            row.operator('import_scene.sfs_workspace_command_launcher', text=_t('Launcher'), icon='MENU_PANEL')

        actions = layout.box()
        actions.label(text=_t('Actions'), icon='TOOL_SETTINGS')
        row = actions.row(align=True)
        op = row.operator(SF_OT_external_assets_export_report.bl_idname, text=_t('Export Report'), icon='TEXT')
        op.include_libraries = self.include_libraries
        op.include_texts = self.include_texts
        op = row.operator(SF_OT_external_assets_relink_missing.bl_idname, text=_t('Relink Missing'), icon='LINKED')
        op.include_libraries = False
        op.include_texts = self.include_texts
        op = row.operator(SF_OT_external_assets_bundle_project.bl_idname, text=_t('Bundle Project'), icon='EXPORT')
        op.include_libraries = self.include_libraries
        op.include_texts = self.include_texts
        verify = actions.row(align=True)
        verify.operator('import_scene.sfs_external_assets_verify_bundle', text=_t('Verify Bundle'), icon='CHECKMARK')
        verify.operator('import_scene.sfs_external_assets_conflict_audit', text=_t('Conflict Audit'), icon='SORTALPHA')
        verify.operator('import_scene.sfs_override_manager_audit', text=_t('Audit'), icon='CHECKMARK')
        saved = actions.row(align=True)
        saved.operator('import_scene.sfs_root_repath_apply_saved_plan', text=_t('Apply Saved Plan'), icon='CHECKMARK')
        saved.operator('import_scene.sfs_root_repath_restore_saved_plan', text=_t('Restore Saved Plan'), icon='LOOP_BACK')
        upgrade = actions.row(align=True)
        upgrade.operator('import_scene.sfs_rm_prepare_upgrade_plan', text=_t('Prepare Saved Upgrade Plan'), icon='FILE_TICK')
        upgrade.operator('import_scene.sfs_reference_manager_apply_saved_upgrade_plan', text=_t('Apply Saved Upgrade Plan'), icon='CHECKMARK')
        upgrade.operator('import_scene.sfs_rm_restore_upgrade_plan', text=_t('Restore Saved Upgrade Plan'), icon='LOOP_BACK')
        extra = actions.row(align=True)
        extra.operator('import_scene.sfs_dependency_cockpit_open', text='Open', icon='FILE_TICK')
        extra.operator('import_scene.sfs_context_roots_open', text='Open', icon='FILE_PARENT')
        extra.operator('import_scene.sfs_root_watch_open', text='Open', icon='FILE_REFRESH')


class SF_OT_external_assets_export_report(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_external_assets_export_report'
    bl_label = 'Export Report'
    bl_description = 'Generate a text report for the current file that lists external references, missing files, absolute paths, duplicates, and portability warnings.'
    bl_options = {'UNDO', 'INTERNAL'}

    include_libraries: BoolProperty(name='Include linked libraries', default=True, options={'HIDDEN'})
    include_texts: BoolProperty(name='Include text datablocks', default=False, options={'HIDDEN'})
    open_text: BoolProperty(name='Open report after export', default=True, options={'HIDDEN'})

    def execute(self, context):
        records = _sf_ext_collect_current_file_records(include_libraries=self.include_libraries, include_texts=self.include_texts, include_missing=True)
        lines = _sf_ext_report_lines(records, title=_t('External Asset Report'))
        text_name = _sf_report_export(
            context,
            _t('External Asset Report'),
            lines,
            open_text=self.open_text,
            activity_title=_t('Exported external asset report'),
        )
        self.report({'INFO'}, f"{_t('External asset report exported')}: {text_name}")
        return {'FINISHED'}


class SF_OT_external_assets_relink_missing(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_external_assets_relink_missing'
    bl_label = 'Relink Missing'
    bl_description = 'Search the current file for missing external assets and try to reconnect them using the current file folder, configured library roots, or a search folder you choose.'
    bl_options = {'UNDO'}

    search_dir: StringProperty(name='Search Folder', subtype='DIR_PATH', default="", description='Optional extra folder to scan before or alongside the current file folder and configured library roots.')
    include_current_file_dir: BoolProperty(name='Include current file folder', default=True, description='Search the folder that contains the current .blend file.')
    include_library_roots: BoolProperty(name='Include library roots', default=True, description='Also search enabled library roots from the Smart File N-panel settings.')
    include_context_roots: BoolProperty(name='Include Context Roots', default=True, description='Also search enabled named Context Roots used by root-map, drift-watch, and handoff workflows.')
    include_libraries: BoolProperty(name='Include linked libraries', default=False, description='Also relink missing linked .blend libraries. In many cases the dedicated Reference Manager is still the safer choice.')
    include_texts: BoolProperty(name='Include text datablocks', default=False, description='Include external text datablocks in the missing-file scan.')
    path_mode: EnumProperty(
        name='Path Mode',
        items=[
            ('PRESERVE', 'Preserve Style', 'Keep each relinked path in the same style it already used when possible. Relative paths stay relative and absolute paths stay absolute.'),
            ('RELATIVE', 'Relative', 'Write resolved paths relative to the current .blend file when possible.'),
            ('ABSOLUTE', 'Absolute', 'Write resolved paths as absolute disk paths.'),
        ],
        default='PRESERVE',
        description='Choose whether resolved file paths keep their old style, become relative, or become absolute.',
    )
    open_report: BoolProperty(name='Open report', default=True, description="Open the relink report in Blender's Text Editor after the scan completes.")

    def invoke(self, context, event):
        if not self.search_dir:
            self.search_dir = _norm_path(os.path.dirname(bpy.data.filepath or '')) if bpy.data.filepath else ''
        return context.window_manager.invoke_props_dialog(self, width=620)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'search_dir')
        layout.prop(self, 'include_current_file_dir')
        layout.prop(self, 'include_library_roots')
        layout.prop(self, 'include_context_roots')
        layout.prop(self, 'include_libraries')
        layout.prop(self, 'include_texts')
        layout.prop(self, 'path_mode')
        layout.prop(self, 'open_report')

    def execute(self, context):
        records = _sf_ext_collect_current_file_records(include_libraries=self.include_libraries, include_texts=self.include_texts, include_missing=True)
        targets = [rec for rec in records if (not rec.get('exists')) and (not rec.get('packed'))]
        if not targets:
            self.report({'INFO'}, _t('No missing external assets were found'))
            return {'FINISHED'}
        if (not bpy.data.filepath) and _sf_ext_rows_require_saved_blend(targets, self.path_mode):
            self.report({'ERROR'}, _t('Save the current file before writing relative paths'))
            return {'CANCELLED'}

        roots = _sf_ext_find_search_roots(
            context,
            self.search_dir,
            include_current_file_dir=self.include_current_file_dir,
            include_library_roots=self.include_library_roots,
            include_context_roots=self.include_context_roots,
        )
        if not roots:
            self.report({'ERROR'}, _t('No valid search roots'))
            return {'CANCELLED'}

        allowed_suffixes = set()
        for rec in targets:
            ext = os.path.splitext(str(rec.get('abs_path') or rec.get('raw_path') or ''))[1].lower()
            if ext:
                allowed_suffixes.add(ext)
        index = _sf_ext_build_basename_index(roots, allowed_suffixes=allowed_suffixes)

        restored = []
        unresolved = []
        report_lines = [
            f"Smart File | {_t('Missing External Asset Relink')} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            '',
            f"- {_t('Search Roots')}: {len(roots)}",
            f"- {_t('Targets')}: {len(targets)}",
            '',
            'ROOTS',
        ]
        for root in roots:
            report_lines.append(f"- {root}")

        report_lines.extend(['', 'RESULTS'])
        for rec in targets:
            best = ''
            try:
                best = _sf_ctx_find_best_record_candidate(context, rec, extra_roots=roots, basename_index=index)
            except Exception:
                best = ''
            if not best:
                candidates = _sf_ext_sequence_index_candidates(rec, index)
                best = _sf_ext_pick_best_candidate(rec, candidates)
            if not best:
                unresolved.append(rec)
                report_lines.append(f"- [MISS] [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('raw_path','')}")
                continue
            try:
                old_path = getattr(rec.get('id_ref'), 'filepath', '') or ''
                remap_target = _sf_ext_tokenized_sequence_path(rec, best)
                if self.path_mode == 'RELATIVE':
                    new_path = _sf_ref_abs_to_path_mode(remap_target, 'RELATIVE')
                elif self.path_mode == 'ABSOLUTE':
                    new_path = _sf_ref_abs_to_path_mode(remap_target, 'ABSOLUTE')
                else:
                    new_path = _sf_ref_preserve_path_style(old_path, remap_target)
                setattr(rec.get('id_ref'), 'filepath', new_path)
                restored.append((rec, new_path, old_path))
                report_lines.append(f"- [OK] [{rec.get('kind_label','')}] {rec.get('name','')} | {old_path} -> {new_path}")
            except Exception as ex:
                unresolved.append(rec)
                report_lines.append(f"- [FAIL] [{rec.get('kind_label','')}] {rec.get('name','')} | {ex}")

        if unresolved:
            report_lines.extend(['', 'UNRESOLVED'])
            for rec in unresolved:
                report_lines.append(f"- [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('raw_path','')}")

        text_name = _sf_report_export(
            context,
            _t('Missing External Asset Relink'),
            report_lines,
            open_text=self.open_report,
            activity_title=_t('Ran missing external asset relink'),
        )
        self.report({'INFO'}, f"{_t('Relinked')}: {len(restored)} | {_t('Unresolved')}: {len(unresolved)} | {text_name}")
        return {'FINISHED'}




class SF_OT_external_assets_verify_bundle(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_external_assets_verify_bundle'
    bl_label = 'Verify Bundle'
    bl_description = 'Open an existing bundle folder, manifest, or ZIP and verify that the manifest, bundled blend copy, external folder, and copied records still look portable and complete.'
    bl_options = {'UNDO', 'INTERNAL'}

    bundle_path: StringProperty(name='Bundle Path', subtype='FILE_PATH', default='', description='Choose a bundle folder, its .manifest.json file, or a ZIP archive created by Smart File.')
    open_text: BoolProperty(name='Open report', default=True)

    def invoke(self, context, event):
        if not self.bundle_path:
            base_dir = _norm_path(os.path.dirname(bpy.data.filepath or '')) if bpy.data.filepath else _sf_user_default_dir('bundles')
            self.bundle_path = base_dir
        return context.window_manager.invoke_props_dialog(self, width=660)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'bundle_path')
        layout.prop(self, 'open_text')

    def execute(self, context):
        payload = _sf_ext_verify_bundle_target(self.bundle_path)
        warnings = list(payload.get('warnings') or [])
        title = _t('Bundle Verification')
        text_name = _sf_report_export(
            context,
            title,
            _sf_ext_verify_bundle_report_lines(title, payload),
            open_text=self.open_text,
            activity_title=_t('Verified project bundle'),
        )
        missing = int(payload.get('copied_missing', 0) or 0)
        verified = int(payload.get('copied_verified', 0) or 0)
        expected = int(payload.get('copied_expected', 0) or 0)
        level = {'WARNING'} if (missing or warnings or (not payload.get('manifest_found'))) else {'INFO'}
        self.report(level, f"{_t('Verified')}: {text_name} | {verified}/{expected} | {_t('Missing')}: {missing}")
        return {'FINISHED'}


class SF_OT_external_assets_bundle_project(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_external_assets_bundle_project'
    bl_label = 'Bundle Project'
    bl_description = "Copy the current file's external assets into one portable folder, optionally save a remapped .blend copy, write a manifest, and create a ZIP archive."
    bl_options = set()
    _sms_no_undo = True

    target_dir: StringProperty(name='Bundle Root', subtype='DIR_PATH', default="", description='Folder where the portable bundle folder will be created.')
    bundle_name: StringProperty(name='Bundle Name', default="", description='Base name used for the bundle folder, manifest, ZIP, and optional .blend copy.')
    include_libraries: BoolProperty(name='Include linked libraries', default=True, description='Copy first-order linked .blend libraries too. Their own nested dependencies stay portable only when those libraries already use healthy relative paths or bundled neighbors.')
    include_texts: BoolProperty(name='Include text datablocks', default=False, description='Copy external text datablocks too.')
    remap_mode: EnumProperty(
        name='Remap Paths',
        items=[
            ('RELATIVE', 'Relative', 'Write copied asset paths into the bundled .blend as relative paths.'),
            ('ABSOLUTE', 'Absolute', 'Write copied asset paths into the bundled .blend as absolute paths.'),
            ('KEEP', 'Keep originals', 'Do not rewrite file paths in the bundled .blend copy.'),
        ],
        default='RELATIVE',
        description='Choose how copied paths are written into the optional bundled .blend copy.',
    )
    write_blend_copy: BoolProperty(name='Write bundled .blend copy', default=True, description='Save a copy of the current file into the bundle folder.')
    zip_result: BoolProperty(name='Create ZIP archive', default=False, description='Also create a ZIP archive of the finished bundle folder.')
    verify_after_export: BoolProperty(name='Verify after export', default=True, description='Run a manifest-based bundle verification pass after export so missing packaged files are easier to catch before handoff.')
    open_folder_after: BoolProperty(name='Open folder after export', default=False, description='Open the bundle folder in the operating system file browser after it is created.')

    def invoke(self, context, event):
        if not self.target_dir:
            self.target_dir = _norm_path(os.path.dirname(bpy.data.filepath or '')) if bpy.data.filepath else _sf_user_default_dir('bundles')
        if not self.bundle_name:
            source = os.path.splitext(os.path.basename(bpy.data.filepath or ''))[0] if bpy.data.filepath else 'unsaved_current_file'
            self.bundle_name = f"{_safe_filename(source)}_bundle"
        return context.window_manager.invoke_props_dialog(self, width=680)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'target_dir')
        layout.prop(self, 'bundle_name')
        layout.prop(self, 'include_libraries')
        layout.prop(self, 'include_texts')
        layout.prop(self, 'remap_mode')
        layout.prop(self, 'write_blend_copy')
        layout.prop(self, 'zip_result')
        layout.prop(self, 'verify_after_export')
        layout.prop(self, 'open_folder_after')

    def execute(self, context):
        out_root = _norm_path(self.target_dir or '')
        if not out_root:
            self.report({'ERROR'}, _t('Bundle root is required'))
            return {'CANCELLED'}
        os.makedirs(out_root, exist_ok=True)

        bundle_name = _safe_filename(self.bundle_name) or 'bundle'
        bundle_dir = os.path.join(out_root, bundle_name)
        if os.path.exists(bundle_dir):
            stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            bundle_dir = os.path.join(out_root, f"{bundle_name}_{stamp}")
        os.makedirs(bundle_dir, exist_ok=True)

        records = _sf_ext_collect_current_file_records(include_libraries=self.include_libraries, include_texts=self.include_texts, include_missing=True)
        copy_result = _sf_ext_copy_records(records, bundle_dir, subdir='external', remap_mode=str(self.remap_mode or 'RELATIVE').upper(), flat_images_when_possible=False)

        bundle_blend = ''
        original_rows = []
        if self.write_blend_copy:
            bundle_blend = os.path.join(bundle_dir, f"{os.path.basename(bundle_dir)}.blend")
            try:
                if self.remap_mode != 'KEEP':
                    original_rows = _sf_ext_apply_remap(records, copy_result.get('remap', {}))
                bpy.ops.wm.save_as_mainfile(filepath=bundle_blend, copy=True)
            finally:
                _sf_ext_restore_paths(original_rows)

        manifest_path = os.path.join(bundle_dir, f"{os.path.basename(bundle_dir)}.manifest.json")
        manifest = {
            'bundle_name': os.path.basename(bundle_dir),
            'created_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'source_blend': _norm_path(bpy.data.filepath or ''),
            'bundle_blend': _norm_path(bundle_blend) if bundle_blend else '',
            'include_libraries': bool(self.include_libraries),
            'include_texts': bool(self.include_texts),
            'remap_mode': str(self.remap_mode or 'RELATIVE'),
            'copy_stats': copy_result.get('stats', {}),
            'items': copy_result.get('manifest_rows', []),
        }
        _write_meta_json(manifest_path, manifest)

        zip_path = ''
        if self.zip_result:
            zip_path = os.path.join(out_root, f"{os.path.basename(bundle_dir)}.zip")
            with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
                for dirpath, _dirnames, filenames in os.walk(bundle_dir):
                    for fn in filenames:
                        abs_fp = os.path.join(dirpath, fn)
                        rel_fp = os.path.relpath(abs_fp, bundle_dir)
                        zf.write(abs_fp, arcname=os.path.join(os.path.basename(bundle_dir), rel_fp))

        verify_payload = {}
        if self.verify_after_export:
            try:
                verify_payload = _sf_ext_verify_bundle_target(zip_path or bundle_dir)
            except Exception as ex:
                verify_payload = {'warnings': [str(ex)], 'copied_verified': 0, 'copied_expected': 0, 'copied_missing': 0}

        report_lines = [
            f"Smart File | {_t('Project Bundle')} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            '',
            f"- {_t('Bundle Folder')}: {_norm_path(bundle_dir)}",
            f"- {_t('Bundle Blend')}: {_norm_path(bundle_blend) if bundle_blend else _t('Not written')}",
            f"- {_t('Manifest')}: {_norm_path(manifest_path)}",
            f"- {_t('ZIP')}: {_norm_path(zip_path) if zip_path else _t('Not written')}",
            f"- {_t('Copied Records')}: {int((copy_result.get('stats', {}) or {}).get('copied_records', 0) or 0)}",
            f"- {_t('Copied Files')}: {int((copy_result.get('stats', {}) or {}).get('copied_files', 0) or 0)}",
            f"- {_t('Missing')}: {int((copy_result.get('stats', {}) or {}).get('missing_records', 0) or 0)}",
            f"- {_t('Packed')}: {int((copy_result.get('stats', {}) or {}).get('packed_records', 0) or 0)}",
        ]
        if verify_payload:
            report_lines.extend([
                '',
                f"- {_t('Bundle Verification')}: {int(verify_payload.get('copied_verified', 0) or 0)} / {int(verify_payload.get('copied_expected', 0) or 0)}",
                f"- {_t('Missing')}: {int(verify_payload.get('copied_missing', 0) or 0)}",
            ])
            for row in list(verify_payload.get('warnings') or [])[:6]:
                report_lines.append(f"- {_t('Warning')}: {row}")

        _sf_report_export(
            context,
            _t('Project Bundle'),
            report_lines,
            open_text=False,
            activity_title=_t('Created project bundle'),
        )

        if self.open_folder_after:
            try:
                bpy.ops.wm.path_open(filepath=bundle_dir)
            except Exception:
                pass

        self.report({'INFO'}, f"{_t('Bundle created')}: {_norm_path(bundle_dir)}")
        return {'FINISHED'}


class SF_OT_external_assets_edit_selected_library(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_external_assets_edit_selected_library'
    bl_label = 'Edit Selected Library'
    bl_description = 'Open the active linked library in a new Blender instance so you can edit it without abandoning the current scene. Smart File also stores a roundtrip ticket so the linked file can later jump back to the parent scene. If launching Blender is unavailable, the file or its folder is opened in the operating system instead.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def execute(self, context):
        wm = context.window_manager
        items = list(getattr(wm, 'sf_rm_items', []) or [])
        if not items:
            self.report({'WARNING'}, _t('No linked libraries found'))
            return {'CANCELLED'}
        idx = int(getattr(wm, 'sf_rm_active_index', 0) or 0)
        idx = max(0, min(idx, len(items) - 1))
        it = items[idx]
        fp = _norm_path(getattr(it, 'filepath', '') or '')
        if not fp or not os.path.isfile(fp):
            self.report({'ERROR'}, _t('Linked library file is missing'))
            return {'CANCELLED'}
        current_blend = _norm_path(bpy.data.filepath or '') if bpy.data.filepath else ''
        ticket = {}
        if current_blend and current_blend != fp:
            try:
                ticket = _sf_link_edit_store_ticket(current_blend, fp, label=str(getattr(it, 'name', '') or ''))
            except Exception:
                ticket = {}
        launched = False
        try:
            binary = _norm_path(getattr(bpy.app, 'binary_path', '') or '')
            if binary and os.path.isfile(binary):
                subprocess.Popen([binary, fp])
                launched = True
        except Exception:
            launched = False
        if not launched:
            try:
                bpy.ops.wm.path_open(filepath=fp)
                launched = True
            except Exception:
                try:
                    bpy.ops.wm.path_open(filepath=os.path.dirname(fp))
                    launched = True
                except Exception:
                    launched = False
        if launched:
            try:
                _sf_append_activity(context, _t('Opened linked library'), os.path.basename(fp), 'OUTLINER_OB_GROUP_INSTANCE')
            except Exception:
                pass
            message = f"{_t('Opened linked library')}: {os.path.basename(fp)}"
            if ticket:
                message += f" | {_t('Return to Parent Scene')}"
            self.report({'INFO'}, message)
            return {'FINISHED'}
        self.report({'ERROR'}, _t('Could not open linked library'))
        return {'CANCELLED'}


class SF_OT_external_assets_return_to_parent_scene(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_external_assets_return_to_parent_scene'
    bl_label = 'Return to Parent Scene'
    bl_description = 'Reopen the parent .blend that previously launched this linked library edit. This gives Blender a roundtrip flow similar to Edit Linked Libraries, while still letting you finish and save changes in the child file first.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    ticket_id: StringProperty(name='Ticket', default='', options={'HIDDEN'})

    def execute(self, context):
        ticket = _sf_link_edit_target_ticket(context, self.ticket_id)
        if not ticket:
            self.report({'ERROR'}, _t('No linked edit roundtrip ticket was found'))
            return {'CANCELLED'}
        parent_blend = _norm_path(str(ticket.get('parent_blend', '') or ''))
        if not parent_blend or not os.path.isfile(parent_blend):
            self.report({'ERROR'}, _t('Parent scene file is missing'))
            return {'CANCELLED'}
        try:
            _sf_append_activity(context, _t('Returned to parent scene'), os.path.basename(parent_blend), 'LOOP_BACK')
        except Exception:
            pass
        try:
            if bool(getattr(bpy.data, 'is_dirty', False)):
                bpy.ops.wm.open_mainfile('INVOKE_DEFAULT', filepath=parent_blend)
            else:
                bpy.ops.wm.open_mainfile(filepath=parent_blend)
        except Exception as ex:
            self.report({'ERROR'}, f"{_t('Could not open parent scene')}: {ex}")
            return {'CANCELLED'}
        return {'FINISHED'}
