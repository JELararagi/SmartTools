"""Machine-readable SmartTools unified N-panel contract (constants only)."""

CONTRACT_VERSION = 1
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
EXTENSION_ID = "smart_file_suite"
CONFIG_FOLDER = "Smart_File_Suite"
CONFIG_FILE = "Smart_File_Suite.json"
STATE_SAVE_PATH = "window_manager.sf_addon_settings.enable_npanel_settings_keeper"
SECTION_PANEL_ID = "SMART_FILE_PT_system_file_suite_always_on_toggle"
RUNTIME_TOGGLE_PATHS = (
    "window_manager.sf_addon_settings.enable_compatibility_guards",
    "window_manager.sf_addon_settings.enable_automatic_proxy_cleanup",
    "window_manager.sf_addon_settings.enable_restore_snapshots",
    "window_manager.sf_addon_settings.enable_autosave",
    "window_manager.sf_addon_settings.rm_auto_check_on_load",
    "window_manager.sf_addon_settings.rm_auto_periodic",
)
ROOT_PANEL_IDS = ("SF_PT_reference_manager_reference_manager_workspace",)
PERSISTENCE_ROOTS = (
    "window_manager.sf_addon_settings",
    "window_manager.sf_*",
    "window_manager.uhm_addon_settings",
    "scene.uhm_settings",
    # Explicit materialized row roots are required because Blender marks the
    # CollectionProperty container itself read-only even though these row
    # values are edited and persisted by the N-panel.  Numeric row selectors
    # describe the first live schema sample; release/runtime inventories
    # canonicalize them to ``[*]`` for every row.
    "scene.reporter_settings.shared_fields[0]",
    "scene.reporter_settings.presets[0]",
    "scene.reporter_settings.presets[0].properties[0]",
)
# Integrated tool PropertyGroups are loaded only when their N-panel lane or
# always-on feature is requested. They are subscribed and persisted immediately
# on load, but are intentionally absent from a zero-idle factory registration.
PERSISTED_DYNAMIC_RNA_PATTERNS = (
    "window_manager.umi_preferences_proxy",
    "window_manager.ikea_settings_proxy",
    "window_manager.bulk_asset_tools_preferences_proxy",
    "window_manager.ikea_search",
    "scene.texmgr_settings",
    "scene.reporter_settings",
    "scene.dcl_tools",
    "scene.vat_settings",
    "scene.texmgr_filter",
    "scene.texmgr_directory",
)
DYNAMIC_RUNTIME_TOGGLE_PATHS = (
    "scene.texmgr_settings.auto_refresh_on_file_load",
    "scene.reporter_settings.labels_enabled",
)
EXCLUDED_TRANSIENT_PATHS = (
    "window_manager.sf_last_*",
    "window_manager.sf_ar_dep_*",
    "window_manager.sf_ar_cat_raw_*",
    "window_manager.sf_ar_cat_tag_cloud_*",
    "window_manager.sf_activity_log",
    # Exact runtime projections.  Broad ``sf_*items*`` suppression hid future
    # editable settings from contract review, so every derived list/cursor is
    # named explicitly.
    "window_manager.sf_items",
    "window_manager.sf_active_index",
    "window_manager.sf_ar_items",
    "window_manager.sf_ar_active_index",
    "window_manager.sf_ar_cat_assets",
    "window_manager.sf_ar_cat_active_index",
    "window_manager.sf_ar_cat_versions",
    "window_manager.sf_ar_cat_ver_active_index",
    "window_manager.sf_ar_catalog_assets",
    "window_manager.sf_ar_catalog_versions",
    "window_manager.sf_rm_items",
    "window_manager.sf_rm_active_index",
    "window_manager.sf_rm_candidates",
    "window_manager.sf_rm_candidate_active_index",
    "window_manager.sf_rm_plan",
    "window_manager.sf_rm_plan_items",
    "window_manager.sf_rm_plan_active_index",
    "window_manager.sf_workspace_profiles",
    "window_manager.sf_cm_review_items",
    "window_manager.sf_library_roots",
    "window_manager.sf_context_roots",
    "window_manager.sf_shot_slots",
    "window_manager.sf_shot_active_index",
    "window_manager.sf_*snapshot_json",
    "window_manager.sf_project_guard_scene_state_json",
    "scene.dcl_tools.thumbnail_camera_name",
    "scene.dcl_tools.thumbnail_target_name",
    "window_manager.sf_addon_settings.name",
    "window_manager.uhm_addon_settings.name",
    "scene.uhm_settings.name",
    # Inherited PropertyGroup identity fields are not editable N-panel values.
    "window_manager.umi_preferences_proxy.name",
    "window_manager.ikea_settings_proxy.name",
    "window_manager.bulk_asset_tools_preferences_proxy.name",
    "scene.texmgr_settings.name",
    "scene.reporter_settings.name",
    "scene.dcl_tools.name",
    "scene.vat_settings.name",
    # Texture Manager rebuilds these rows and their active cursor from the
    # images in the current .blend.  They are scan output, not portable user
    # preferences, and must not be restored into a different scene.
    "scene.texmgr_list",
    "scene.texmgr_list_index",
    # UMI preset/file rows are projections of external preset files and the
    # current import dialog.  Pre/each/post command rows remain portable.
    "window_manager.umi_preferences_proxy.umi_settings.umi_presets",
    "window_manager.umi_preferences_proxy.umi_settings.umi_preset_idx",
    "window_manager.umi_preferences_proxy.umi_settings.umi_file_selection",
    "window_manager.umi_preferences_proxy.umi_settings.umi_file_selection_idx",
)

BLEND_OWNED_NPANEL_PATHS = (
    # Shot-state rows mirror Text datablocks stored in the current .blend.
    "window_manager.sf_shot_presets",
    "window_manager.sf_shot_preset_active_index",
    # VAT exposes Blender's native scene frame range.  It is document content
    # already stored by the .blend and must not be copied between projects via
    # Smart_File_Suite.json.
    "scene.frame_start",
    "scene.frame_end",
    "scene.frame_step",
)
