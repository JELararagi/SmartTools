# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Compatibility access to the versioned Smart File configuration directory."""

from pathlib import Path, PureWindowsPath
import os
import sys

import tomllib

try:
    import bpy
except ImportError:
    bpy = None


_SUITE_ID = "smart_file_suite"
_FOLDER_NAME = "Smart_File_Suite"


def extension_id(default: str = _SUITE_ID) -> str:
    for directory in Path(__file__).resolve().parents:
        manifest = directory / "blender_manifest.toml"
        if manifest.is_file():
            try:
                with manifest.open("rb") as source:
                    identifier = tomllib.load(source).get("id")
            except (OSError, ValueError):
                identifier = None
            if isinstance(identifier, str) and identifier.strip():
                return identifier.strip()
            break
    name = str(default or _SUITE_ID).strip()
    if name.startswith("bl_ext.") or ".user_default." in name:
        name = name.split(".")[-1]
    return name.partition(".")[0] or _SUITE_ID


def _version_string() -> str:
    version = getattr(getattr(bpy, "app", None), "version", ())
    try:
        return f"{int(version[0])}.{int(version[1])}"
    except (IndexError, OverflowError, TypeError, ValueError):
        return "5.1"


def _appdata_root() -> Path:
    if os.name == "nt":
        value = os.getenv("APPDATA")
        roaming = Path(value) if value else Path.home() / "AppData" / "Roaming"
        return roaming / "Blender Foundation" / "Blender"
    value = os.getenv("XDG_CONFIG_HOME")
    config = Path(value) if value else Path.home() / ".config"
    return config / "blender"


def _blender_config(create: bool) -> Path:
    query = getattr(getattr(bpy, "utils", None), "user_resource", None)
    if callable(query):
        for options in ({"path": "", "create": create}, {"create": create}, {}):
            try:
                result = query("CONFIG", **options)
            except (TypeError, OSError, RuntimeError, ValueError):
                continue
            if result:
                return Path(result)
    return _appdata_root() / _version_string() / "config"


def user_default_root(*parts: str, create: bool = True, package_id: str | None = None) -> Path:
    """Return the shared storage location. The old package_id argument is retained."""
    chunks = tuple(str(part).strip("/\\") for part in parts if str(part or "").strip())
    for chunk in chunks:
        tail = PureWindowsPath(chunk)
        if tail.drive or ".." in tail.parts or ":" in chunk:
            raise ValueError(f"Invalid Smart File configuration path: {chunk!r}")

    peer_name = f"{__package__}.storage" if __package__ else "storage"
    peer_root = getattr(sys.modules.get(peer_name), "mutable_root", None)
    if callable(peer_root):
        try:
            return peer_root(*parts, create=create)
        except (OSError, RuntimeError, TypeError, ValueError):
            pass

    root = _blender_config(bool(create)) / _FOLDER_NAME
    result = root.joinpath(*chunks)
    if not result.resolve().is_relative_to(root.resolve()):
        raise ValueError("Smart File configuration path escapes the configuration directory")
    if create:
        result.mkdir(parents=True, exist_ok=True)
    return result


def user_default_dir(*parts: str, create: bool = True) -> str:
    return str(user_default_root(*parts, create=create))


def user_default_file(filename: str, *parts: str, create_parent: bool = True) -> str:
    name = PureWindowsPath(str(filename or "").strip()).name
    name = name or "untitled"
    if name in (".", "..") or ":" in name:
        raise ValueError("Invalid Smart File configuration filename")
    return str(user_default_root(*parts, create=create_parent) / name)
