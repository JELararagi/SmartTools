# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Shared path helpers for Smart File runtime-generated data.

All automatic caches, presets, logs, settings and support files are placed under
Blender's versioned CONFIG repository:

    .../Blender/<version>/config/Smart_File_Suite

Manual export/import destinations selected by the user are not redirected.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

try:
    import bpy
except Exception:  # pragma: no cover - Blender supplies bpy at runtime.
    bpy = None


_EXTENSION_ID = "smart_file_suite"
_CONFIG_DIRNAME = "Smart_File_Suite"


def extension_id(default: str = _EXTENSION_ID) -> str:
    current = Path(__file__).resolve().parent
    for folder in (current, *current.parents):
        manifest = folder / "blender_manifest.toml"
        if not manifest.is_file():
            continue
        try:
            for raw in manifest.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = raw.strip()
                if not line.startswith("id"):
                    continue
                _, _, value = line.partition("=")
                value = value.strip().strip('"').strip("'")
                if value:
                    return value
        except Exception:
            pass
        break
    value = str(default or _EXTENSION_ID).strip()
    if ".user_default." in value or value.startswith("bl_ext."):
        value = value.rsplit(".", 1)[-1]
    if "." in value:
        value = value.split(".", 1)[0]
    return value or _EXTENSION_ID


def _version_string() -> str:
    try:
        version = getattr(getattr(bpy, "app", None), "version", None)
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return "5.1"


def _appdata_root() -> Path:
    if os.name == "nt":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "Blender Foundation" / "Blender"
        return Path.home() / "AppData" / "Roaming" / "Blender Foundation" / "Blender"
    if sys_platform := os.environ.get("XDG_CONFIG_HOME"):
        return Path(sys_platform) / "blender"
    return Path.home() / ".config" / "blender"


def user_default_root(*parts: str, create: bool = True, package_id: str | None = None) -> Path:
    """Compatibility API returning CONFIG/Smart_File_Suite.

    ``package_id`` is retained for callers from older bundled modules, but it
    must never redirect mutable data into the installed Extension package.
    """
    del package_id
    try:
        module_name = f"{__package__}.storage" if __package__ else "storage"
        _storage = sys.modules.get(module_name)
        mutable_root = getattr(_storage, "mutable_root", None) if _storage is not None else None
        if callable(mutable_root):
            return mutable_root(*parts, create=create)
    except Exception:
        pass

    base = None
    utils = getattr(bpy, "utils", None) if bpy is not None else None
    user_resource = getattr(utils, "user_resource", None) if utils is not None else None
    if callable(user_resource):
        for args, kwargs in (
            (("CONFIG",), {"path": "", "create": bool(create)}),
            (("CONFIG",), {"create": bool(create)}),
            (("CONFIG",), {}),
        ):
            try:
                value = user_resource(*args, **kwargs)
            except TypeError:
                continue
            except Exception:
                value = ""
            if value:
                base = Path(value)
                break
    if base is None:
        base = _appdata_root() / _version_string() / "config"
    path = base / _CONFIG_DIRNAME
    path = path.joinpath(*(str(p).strip("/\\") for p in parts if str(p or "").strip()))
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def user_default_dir(*parts: str, create: bool = True) -> str:
    return str(user_default_root(*parts, create=create))


def user_default_file(filename: str, *parts: str, create_parent: bool = True) -> str:
    safe_name = os.path.basename(str(filename or "").strip()) or "untitled"
    directory = user_default_root(*parts, create=create_parent)
    path = directory / safe_name
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    return str(path)
