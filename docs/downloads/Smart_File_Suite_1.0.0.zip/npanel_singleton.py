# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Read-only Smart File N-panel singleton compatibility service.

Canonical physical roots are created and owned exclusively by
``multi_editor_panels``.  This module intentionally does not scan, unregister,
or rewrite any Panel ``draw``/``poll`` callback.  The functions remain for API
compatibility with older Smart File modules.
"""
from __future__ import annotations

from typing import Any

import bpy

_CATEGORY = "Smart File"
_MAIN_PANEL_ID = "SF_PT_reference_manager_reference_manager_workspace"


def _multi_editor_status() -> dict[str, Any]:
    try:
        from . import multi_editor_panels
        value = multi_editor_panels.runtime_status()
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _main_panel_registered() -> bool:
    status = _multi_editor_status()
    if status:
        return bool(status.get("registered") and status.get("source_exact"))
    try:
        cls = getattr(bpy.types, _MAIN_PANEL_ID, None)
        rna = vars(cls).get("bl_rna") if isinstance(cls, type) else None
        return bool(rna is not None and str(getattr(rna, "identifier", "") or "").strip())
    except Exception:
        return False


def enforce(context=None, *, aggressive: bool = False) -> int:
    """Validate-only compatibility call; never mutates classes or user data."""
    del context, aggressive
    return 0


def restore_hidden() -> int:
    return 0


def visible_smart_file_panel_count(context=None) -> int:
    del context
    status = _multi_editor_status()
    if status.get("registered"):
        return int(status.get("physical_root_count", 0) or 0)
    return 1 if _main_panel_registered() else 0
