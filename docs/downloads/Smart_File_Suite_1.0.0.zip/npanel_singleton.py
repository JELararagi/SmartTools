# SPDX-License-Identifier: GPL-3.0-or-later
"""Compatibility queries for the editor roots owned by Smart File."""

import bpy


def enforce(context=None, *, aggressive=False):
    return 0


def restore_hidden():
    return 0


def visible_smart_file_panel_count(context=None):
    try:
        from . import multi_editor_panels
        state = multi_editor_panels.runtime_status()
    except (AttributeError, ImportError, RuntimeError):
        state = None
    if isinstance(state, dict) and state.get("registered"):
        return int(state.get("physical_root_count") or 0)
    panel = getattr(bpy.types, "SF_PT_reference_manager_reference_manager_workspace", None)
    rna = getattr(panel, "bl_rna", None)
    return int(bool(getattr(rna, "identifier", "")))

