# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import hashlib
import importlib
import textwrap
import uuid
from typing import Any, Mapping

import bpy

from . import loader as loader, registry as registry

# Keep one import/registration surface in foreground and background Blender.
# These helpers are pure text functions and do not require a Window or Screen.
from .ui_language_runtime import iface as _iface, tip as _tip, ui_text as _ui_text

_REGISTERED_CLASSES: list[type] = []
_CLASS_RECORDS: list[dict[str, Any]] = []
_RECORDS_BY_ALIAS: dict[str, dict[str, Any]] = {}
_SUITE_RECORDS: dict[str, list[dict[str, Any]]] = {}
_NAV_MODULE_CACHE: dict[str, object] = {}
_SUITE_ROOT_PANEL_IDS: dict[str, str] = {}
_ADDON_PANEL_IDS: dict[str, str] = {}
_REBUILD_SCHEDULED = False
_REBUILD_TIMER_CALLBACK = None
_OWNER_KEY = "JELararagi.smart_file.ui_runtime.lifecycle.v57540"
_LEGACY_OWNER_KEYS = (
    "JELararagi.smart_file.ui_runtime.lifecycle.v57539",
    "JELararagi.smart_file.ui_runtime.lifecycle.v57536",

    "JELararagi.smart_file.ui_runtime.lifecycle.v57535",
    "JELararagi.smart_file.ui_runtime.lifecycle.v57534",
    "JELararagi.smart_file.ui_runtime.lifecycle.v57533",
)
_OWNER_TOKEN = object()
_OWNER_GENERATION = uuid.uuid4().hex
_LAST_RUNTIME_ERROR = ""


class _IdFactory:
    @staticmethod
    def token(*parts: object, size: int = 10) -> str:
        source = '||'.join(str(part or '') for part in parts)
        return hashlib.md5(source.encode('utf-8')).hexdigest()[: max(6, int(size))].upper()

    @staticmethod
    def panel(prefix: str, *parts: object) -> tuple[str, str]:
        token = _IdFactory.token(prefix, *parts)
        class_name = f'SMARTFILESUITE_PT_{prefix}_{token}'
        return class_name, class_name


ID_FACTORY = _IdFactory()


def _namespace() -> dict | None:
    try:
        value = getattr(getattr(bpy, "app", None), "driver_namespace", None)
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _class_owned_rna(cls: type) -> bool:
    try:
        if not isinstance(cls, type):
            return False
        rna = vars(cls).get("bl_rna")
        return bool(rna is not None and str(getattr(rna, "identifier", "") or "").strip())
    except Exception:
        return False


def _timer_registered(callback) -> bool:
    if callback is None:
        return False
    try:
        checker = getattr(bpy.app.timers, "is_registered", None)
        return bool(checker(callback)) if callable(checker) else True
    except Exception:
        return False


def _cancel_rebuild_timer() -> bool:
    global _REBUILD_TIMER_CALLBACK, _REBUILD_SCHEDULED
    callback = _REBUILD_TIMER_CALLBACK
    ok = True
    if callback is not None:
        try:
            if _timer_registered(callback):
                bpy.app.timers.unregister(callback)
        except Exception:
            ok = not _timer_registered(callback)
    _REBUILD_TIMER_CALLBACK = None
    _REBUILD_SCHEDULED = False
    owner = (_namespace() or {}).get(_OWNER_KEY)
    if isinstance(owner, dict) and owner.get("token") is _OWNER_TOKEN:
        owner["timer"] = None
    return ok


def _unregister_record(record: Mapping[str, Any]) -> bool:
    cls = record.get("class")
    if not isinstance(cls, type) or not bool(record.get("acquired")):
        return True
    if record.get("token") is not _OWNER_TOKEN or record.get("generation") != _OWNER_GENERATION:
        return False
    if not _class_owned_rna(cls):
        return True
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        return False
    return not _class_owned_rna(cls)


def _clear_ui_records() -> None:
    _SUITE_ROOT_PANEL_IDS.clear()
    _ADDON_PANEL_IDS.clear()
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()


def _cleanup_generation(token=None, generation=None) -> bool:
    if token is not None and token is not _OWNER_TOKEN:
        return True
    if generation is not None and str(generation) != _OWNER_GENERATION:
        return True
    ok = _cancel_rebuild_timer()
    for record in reversed(tuple(_CLASS_RECORDS)):
        if not _unregister_record(record):
            ok = False
    _CLASS_RECORDS.clear()
    _REGISTERED_CLASSES.clear()
    _clear_ui_records()
    return ok


def _cleanup_external_owner(owner: Mapping[str, Any]) -> bool:
    cleanup = owner.get("cleanup") if isinstance(owner, Mapping) else None
    if not callable(cleanup):
        return False
    try:
        try:
            return bool(cleanup(owner.get("token"), owner.get("generation")))
        except TypeError:
            return bool(cleanup())
    except Exception:
        return False


def _install_owner() -> bool:
    namespace = _namespace()
    if namespace is None:
        return False
    for key in _LEGACY_OWNER_KEYS:
        prior = namespace.get(key)
        if isinstance(prior, Mapping) and not _cleanup_external_owner(prior):
            return False
        namespace.pop(key, None)
    current = namespace.get(_OWNER_KEY)
    if isinstance(current, Mapping) and not (
        current.get("token") is _OWNER_TOKEN
        and current.get("generation") == _OWNER_GENERATION
    ):
        if not _cleanup_external_owner(current):
            return False
    namespace[_OWNER_KEY] = {
        "schema": 1,
        "token": _OWNER_TOKEN,
        "generation": _OWNER_GENERATION,
        "classes": _CLASS_RECORDS,
        "timer": None,
        "cleanup": _cleanup_generation,
    }
    return True


def _safe_register_class(cls: type) -> None:
    if not isinstance(cls, type):
        raise TypeError(f"UI runtime class is not a type: {cls!r}")
    if _class_owned_rna(cls):
        if not any(record.get("class") is cls for record in _CLASS_RECORDS):
            _CLASS_RECORDS.append({
                "class": cls, "acquired": False,
                "token": _OWNER_TOKEN, "generation": _OWNER_GENERATION,
            })
        if cls not in _REGISTERED_CLASSES:
            _REGISTERED_CLASSES.append(cls)
        return
    bpy.utils.register_class(cls)
    if not _class_owned_rna(cls):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        raise RuntimeError(f"UI runtime RNA validation failed: {cls.__name__}")
    _CLASS_RECORDS.append({
        "class": cls, "acquired": True,
        "token": _OWNER_TOKEN, "generation": _OWNER_GENERATION,
    })
    _REGISTERED_CLASSES.append(cls)


def _safe_unregister_registered_classes() -> bool:
    return _cleanup_generation()

def _import_nav_module(module_name: str):
    cached = _NAV_MODULE_CACHE.get(module_name)
    if cached is not None:
        return cached
    mod = importlib.import_module(f'.{module_name}', __package__)
    _NAV_MODULE_CACHE[module_name] = mod
    return mod


def suite_is_active(context, suite_key: str) -> bool:
    suite_key = str(suite_key or '').strip()
    module_name = registry.SUITE_META.get(suite_key, ('', ''))[1]
    if not module_name:
        return False
    try:
        nav = _import_nav_module(module_name)
        fn = getattr(nav, 'is_active', None)
        if callable(fn):
            return bool(fn(context, suite_key))
    except Exception:
        pass
    return False


def suite_panel_context(suite_key: str) -> str:
    suite_key = str(suite_key or '').strip()
    module_name = registry.SUITE_META.get(suite_key, ('', ''))[1]
    if not module_name:
        return 'render'
    try:
        nav = _import_nav_module(module_name)
        value = getattr(nav, '_SMART_TOOLS_CONTEXT', 'RENDER')
        return str(value or 'RENDER').lower()
    except Exception:
        return 'render'


def refresh_all_suites(context=None) -> None:
    if context is None:
        context = getattr(bpy, 'context', None)
    for suite_key, (_suite_name, module_name) in registry.SUITE_META.items():
        try:
            nav = _import_nav_module(module_name)
            force_fn = getattr(nav, 'force_runtime_refresh', None)
            if callable(force_fn):
                force_fn()
        except Exception:
            pass
        try:
            nav = _import_nav_module(module_name)
            refresh_fn = getattr(nav, 'refresh_ui_runtime', None)
            if callable(refresh_fn):
                refresh_fn(context=context, addon_key=suite_key, activate_if_properties=False)
        except Exception:
            pass




def _deferred_rebuild_ui_runtime():
    global _REBUILD_SCHEDULED, _REBUILD_TIMER_CALLBACK
    callback = _REBUILD_TIMER_CALLBACK
    owner = (_namespace() or {}).get(_OWNER_KEY)
    if not (
        isinstance(owner, dict)
        and owner.get("token") is _OWNER_TOKEN
        and owner.get("generation") == _OWNER_GENERATION
        and isinstance(owner.get("timer"), dict)
        and owner["timer"].get("callback") is callback
    ):
        return None
    owner["timer"] = None
    _REBUILD_TIMER_CALLBACK = None
    _REBUILD_SCHEDULED = False
    try:
        register()
        refresh_all_suites(getattr(bpy, "context", None))
    except Exception:
        pass
    return None



def _schedule_rebuild_ui_runtime() -> None:
    global _REBUILD_SCHEDULED, _REBUILD_TIMER_CALLBACK
    if _REBUILD_SCHEDULED and _timer_registered(_REBUILD_TIMER_CALLBACK):
        return
    if not _install_owner():
        return
    _cancel_rebuild_timer()
    token = _OWNER_TOKEN
    generation = _OWNER_GENERATION

    def callback():
        if token is not _OWNER_TOKEN or generation != _OWNER_GENERATION:
            return None
        return _deferred_rebuild_ui_runtime()

    _REBUILD_TIMER_CALLBACK = callback
    _REBUILD_SCHEDULED = True
    owner = (_namespace() or {}).get(_OWNER_KEY)
    if isinstance(owner, dict):
        owner["timer"] = {
            "callback": callback, "token": token, "generation": generation,
            "one_shot": True, "remover": _cancel_rebuild_timer,
        }
    try:
        bpy.app.timers.register(callback, first_interval=0.0, persistent=False)
        if not _timer_registered(callback):
            raise RuntimeError("UI rebuild timer was not retained")
    except Exception:
        _cancel_rebuild_timer()



def _wrap_lines(layout, text: str, width: int = 78, icon: str = 'NONE') -> None:
    text = str(text or '').strip()
    if not text:
        return
    lines = textwrap.wrap(text, width=max(24, int(width))) or [text]
    first = True
    for line in lines:
        if first:
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)


def _status_text(record: dict, context=None) -> str:
    status = str(record.get('status') or '')
    if status == 'loaded':
        return _ui_text('Loaded', '読み込み済み', context=context)
    if status == 'ready':
        return _ui_text('UI only until used', '使用するまでUIのみ', context=context)
    if status == 'unsupported_platform':
        return _ui_text('Unsupported platform', '現在の OS・CPU では無効', context=context)
    if status == 'failed':
        return _ui_text('Load failed', '読み込み失敗', context=context)
    if status == 'disabled':
        return _ui_text('Superseded or deduplicated', '上位互換または重複のため統合対象外', context=context)
    return _ui_text(status or 'Unknown', status or '不明', context=context)


def _addon_help_en(spec: dict) -> str:
    desc = str(spec.get('description') or spec.get('display_name') or '').strip()
    if desc:
        return (
            f'Function: {desc}. How to use: open the migrated child panels and settings, or use the direct buttons below. '
            f'Supported original panels are mirrored inside the Smart File N-panel, while dialog-only controls stay in their native operator dialogs.'
        )
    return (
        'Function: This add-on has been migrated into Smart File. How to use: open the migrated child panels and settings, '
        'or use the direct buttons below. Dialog-only controls stay in their native operator dialogs.'
    )


def _addon_help_ja(spec: dict) -> str:
    name = _iface(str(spec.get('display_name') or 'Integrated Add-on').strip())
    desc = _iface(str(spec.get('description') or '').strip())
    if desc:
        return (
            f'機能: {name} の元機能を Smart File 内へ統合しています。内容: {desc}。使い方: 下のクイックボタン、'
            f'または移植済みの子パネルと設定パネルを開いて必要な機能を使ってください。ダイアログ専用の設定は対応するオペレーター実行後に元のダイアログ内で表示されます。'
        )
    return (
        f'機能: {name} の元機能を Smart File 内へ統合しています。使い方: 下のクイックボタン、または移植済みの子パネルと設定パネルを開いて'
        f'必要な機能を使ってください。ダイアログ専用の設定は対応するオペレーター実行後に元のダイアログ内で表示されます。'
    )


def _addon_help(spec: dict, *, context=None) -> str:
    return _ui_text(_addon_help_en(spec), _addon_help_ja(spec), context=context)


def _target_help_en(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    label = str(label or '').strip() or 'Integrated Tool'
    desc = str(desc or '').strip()
    if kind == 'menu':
        menu_kind = 'pie menu' if is_pie else 'menu'
        return (
            f'Function: opens the migrated {label} {menu_kind} inside the Smart File N-panel. '
            f'How to use: click this button, then choose a command from the opened menu.'
        )
    body = desc or label
    return (
        f'Function: {body}. How to use: click this button to run the migrated command inside the Smart File N-panel. '
        f'Some tools may open additional dialogs or require a valid selection or mode.'
    )


def _target_help_ja(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    label = str(label or '').strip() or '統合ツール'
    desc = str(desc or '').strip()
    if kind == 'menu':
        menu_kind = 'パイメニュー' if is_pie else 'メニュー'
        return (
            f'機能: Smart File Nパネル内で移植済みの {label} {menu_kind} を開きます。'
            f'使い方: このボタンを押して、表示されたメニューから目的の機能を選んでください。'
        )
    body = desc or label
    return (
        f'機能: {body}。使い方: このボタンを押すと Smart File 内の移植コマンドを実行します。'
        f'機能によっては追加ダイアログが開く場合や、選択状態・モードが必要な場合があります。'
    )


def _target_help(kind: str, label: str, desc: str, *, is_pie: bool = False, context=None) -> str:
    return _ui_text(_target_help_en(kind, label, desc, is_pie=is_pie), _target_help_ja(kind, label, desc, is_pie=is_pie), context=context)


def _trace_excerpt(text: str) -> str:
    for line in reversed(str(text or '').splitlines()):
        line = line.strip()
        if line:
            return line[:240]
    return ''




def _looks_like_layout(value: object) -> bool:
    if value is None:
        return False
    return any(hasattr(value, name) for name in ('label', 'operator', 'prop', 'row', 'column', 'box'))


class _LocalizedUILayoutProxy:
    """Translate text arguments for migrated child panels drawn inside Smart File.

    This proxy is intentionally local to the integrated Smart File drawing path.
    It does not patch Blender's global UILayout type, so UI outside the Smart
    File panels keeps Blender's normal behavior.
    """

    _TEXT_KEYS = {'text', 'heading'}

    def __init__(self, layout, context=None):
        object.__setattr__(self, '_layout', layout)
        object.__setattr__(self, '_context', context)

    def __getattr__(self, name):
        attr = getattr(object.__getattribute__(self, '_layout'), name)
        if not callable(attr):
            return attr

        def wrapper(*args, **kwargs):
            kwargs = dict(kwargs or {})
            context = object.__getattribute__(self, '_context')
            for key in (() if kwargs.get('translate') is False else self._TEXT_KEYS):
                if key in kwargs and isinstance(kwargs[key], str):
                    kwargs[key] = _ui_text(kwargs[key], context=context)
            result = attr(*args, **kwargs)
            if _looks_like_layout(result):
                return _LocalizedUILayoutProxy(result, context)
            return result

        try:
            wrapper.__name__ = getattr(attr, '__name__', name)
        except Exception:
            pass
        return wrapper

    def __setattr__(self, name, value):
        if name in {'_layout', '_context'}:
            object.__setattr__(self, name, value)
            return
        setattr(object.__getattribute__(self, '_layout'), name, value)

    def __bool__(self):
        return bool(object.__getattribute__(self, '_layout'))


def _localized_layout(layout, context=None):
    if isinstance(layout, _LocalizedUILayoutProxy):
        return layout
    if _looks_like_layout(layout):
        return _LocalizedUILayoutProxy(layout, context)
    return layout



def _native_panel_context_paused(context) -> bool:
    """Return True while migrated native panels are unsafe to redraw.

    The Smart File shell itself can draw in any 3D View state, but migrated child
    panels from external tools frequently assume Object Mode and a stable active
    object/RNA pointer. During Blender mode transitions (notably Sculpt/Edit
    after selection changes), drawing those original panel bodies can push invalid
    RNA/UI state into Blender's C-side panel handler.
    """
    try:
        area = getattr(context, 'area', None)
        if area is not None and str(getattr(area, 'type', '') or '') != 'VIEW_3D':
            return False
        mode = str(getattr(context, 'mode', '') or '').upper()
        if getattr(context, 'object', None) is None and getattr(context, 'active_object', None) is None:
            return True
        if not mode or mode == 'OBJECT':
            return False
        return mode in {
            'EDIT_MESH', 'EDIT_CURVE', 'EDIT_SURFACE', 'EDIT_TEXT',
            'EDIT_ARMATURE', 'EDIT_METABALL', 'EDIT_LATTICE', 'POSE',
            'SCULPT', 'PAINT_TEXTURE', 'PAINT_VERTEX', 'PAINT_WEIGHT',
            'PARTICLE', 'GPENCIL_EDIT', 'GPENCIL_SCULPT', 'GPENCIL_PAINT',
            'GPENCIL_WEIGHT', 'CURVES_SCULPT',
        }
    except Exception:
        return True


def _draw_native_panel_paused(layout, context=None) -> None:
    try:
        mode = str(getattr(context, 'mode', '') or '').strip() or 'Unknown'
    except Exception:
        mode = 'Unknown'
    _wrap_lines(
        layout,
        _ui_text(
            f'Migrated child-panel drawing is paused during {mode} mode to avoid unsafe redraw while Blender is switching object/edit/sculpt context. Return to Object Mode or use the original modal dialog for mode-specific controls.',
            f'Blender がオブジェクト/編集/スカルプトのコンテキストを切り替えている間の危険な再描画を避けるため、{mode} モード中は移植済み子パネルの描画を一時停止しています。Object Mode に戻すか、モード専用操作は元のダイアログを使用してください。',
            context=context,
        ),
        width=76,
    )


def _panel_poll_allows(panel_cls: type, context) -> bool:
    original_poll = _panel_custom_poll(panel_cls)
    if not callable(original_poll):
        return True
    try:
        return bool(original_poll(context))
    except TypeError:
        try:
            return bool(original_poll(panel_cls, context))
        except Exception:
            return False
    except Exception:
        return False


def _draw_inline_settings(layout, record: dict, context=None) -> bool:
    prefs_classes = _preference_entries(record)
    if not prefs_classes:
        return False

    section = layout.box()
    section.label(text=_ui_text('Settings', '設定', context=context), icon='PREFERENCES')

    for pref_cls in prefs_classes:
        title = _ui_text(str(getattr(pref_cls, 'bl_label', '') or '').strip() or 'Settings', context=context)
        box = section.box()
        box.label(text=title, icon='PREFERENCES')
        prefs_instance = _preference_instance(record, pref_cls, context)
        target = box.column(align=False)
        if prefs_instance is None:
            warn = target.box()
            warn.alert = True
            _wrap_lines(
                warn,
                _ui_text(
                    f'Settings instance is unavailable for {title}.',
                    f'{title} の設定インスタンスを取得できませんでした。',
                    context=context,
                ),
                width=74,
                icon='ERROR',
            )
            continue
        draw_fn = getattr(pref_cls, 'draw', None)
        if not callable(draw_fn):
            target.label(
                text=_ui_text('Preference draw function is missing.', '設定の draw 関数がありません。', context=context),
            )
            continue
        try:
            _call_preferences_draw(draw_fn, pref_cls, prefs_instance, target, context)
        except Exception as exc:
            fail = target.box()
            fail.alert = True
            fail.label(text=_ui_text(f'Preferences draw failed: {exc}', f'設定描画に失敗しました: {exc}', context=context), icon='ERROR')
    return True


def _draw_inline_foldout(layout, context, key: str, title: str, icon: str, *, default_closed: bool, addon_alias: str = ''):
    if getattr(context, 'region_popup', None) is not None:
        # Popup blocks do not own native Panel runtime storage.
        core = importlib.import_module(__package__)
        _header, body, _expanded = core._sf_draw_group_section_header(
            layout, context, section_key=key, title=title, icon=icon,
            default_open=not default_closed,
            help_key='integrated_addon' if addon_alias else 'section', addon_alias=addon_alias,
        )
        return body
    header, body = layout.panel(key, default_closed=default_closed)
    header.label(text=title, icon=icon)
    if addon_alias:
        help_area = header.row(align=True)
        help_area.alignment = 'RIGHT'
        core = importlib.import_module(__package__)
        core._sf_draw_help_button(help_area, help_key='integrated_addon', addon_alias=addon_alias, title=title)
    return body


def _draw_inline_proxy_panel(layout, panel_cls: type, context=None, *, default_closed: bool = True, addon_alias: str = '') -> None:
    original_label = _ui_text(str(getattr(panel_cls, 'bl_label', '') or getattr(panel_cls, '__name__', '') or 'Panel'), context=context)
    original_draw = getattr(panel_cls, 'draw', None)
    box = _draw_inline_foldout(layout, context, f"sfs_integrated_{getattr(panel_cls, '__name__', 'panel')}", original_label, 'MENU_PANEL', default_closed=default_closed, addon_alias=addon_alias)
    if box is None:
        return

    if _native_panel_context_paused(context):
        _draw_native_panel_paused(box, context=context)
        return

    # Blender 5.1 can keep panel header handlers alive for one event after a
    # mode/selection transition. Do not proxy original draw_header callbacks;
    # body draw is enough for integrated panels and is wrapped below.

    if not _panel_poll_allows(panel_cls, context):
        _wrap_lines(
            box,
            _ui_text(
                'This panel becomes available when the required Blender context is active inside the Smart File N-panel.',
                'このパネルは、必要な Blender コンテキストが有効な状態で Smart File 内から利用できます。',
                context=context,
            ),
            width=76,
        )
        return

    if not callable(original_draw):
        box.label(text=_ui_text('Original panel has no draw function.', '元パネルに draw 関数がありません。', context=context))
        return

    body = box.column(align=False)
    try:
        _call_draw(original_draw, panel_cls, body, context)
    except Exception as exc:
        fail = body.box()
        fail.alert = True
        fail.label(text=_ui_text(f'Panel draw failed: {exc}', f'パネル描画に失敗しました: {exc}', context=context), icon='ERROR')


def _draw_inline_proxy_panels(layout, record: dict, context=None) -> bool:
    proxy_panels = list(record.get('proxy_panels', ()) or ())
    if not proxy_panels:
        return False

    alias = str((record.get('spec') or {}).get('alias') or '')
    for panel_cls in proxy_panels:
        _draw_inline_proxy_panel(layout, panel_cls, context=context, default_closed=len(proxy_panels) > 1, addon_alias=alias)
    return True


def _draw_inline_deferred_panels(layout, record: dict, context=None) -> bool:
    labels = _deferred_panel_labels(record)
    if not labels:
        return False

    section = layout.box()
    section.label(text=_ui_text('Dialog-backed Controls', 'ダイアログ制御', context=context), icon='WINDOW')
    col = section.column(align=True)
    for label in labels:
        col.label(text=label, icon='DOT')
    return True


def draw_integrated_record_contents(layout, record: dict, context=None, *, search_text: str = '', show_title: bool = True) -> None:
    if not isinstance(record, dict):
        layout.label(text=_ui_text('Integrated tool record is unavailable.', '統合ツール情報を取得できませんでした。', context=context))
        return

    spec = dict(record.get('spec') or {})
    alias = str(spec.get('alias') or '')
    title = str(spec.get('display_name') or alias or 'Integrated Tool')
    loaded = str(record.get('status') or '') == 'loaded'
    status_value = str(record.get('status') or '')

    header = layout.row(align=True)
    if show_title:
        header.label(text=_ui_text(title, context=context), icon='PLUGIN')
    header.label(text=_status_text(record, context=context))

    if status_value == 'failed':
        error_box = layout.box()
        error_box.alert = True
        excerpt = _trace_excerpt(record.get('error', ''))
        _wrap_lines(error_box, _ui_text(f'Load error: {excerpt}', f'読み込みエラー: {excerpt}', context=context), width=84, icon='ERROR')

    if status_value in {'unsupported_platform', 'disabled', 'failed'}:
        return

    tools_section = _draw_inline_foldout(layout, context, f'sfs_integrated_tools_{alias}', _ui_text('Tools', 'ツール', context=context), 'TOOL_SETTINGS', default_closed=bool(record.get('proxy_panels')))
    if tools_section is not None:
        _draw_tool_list(tools_section, record, context=context, compact=True)
    if not loaded:
        return

    _draw_inline_settings(layout, record, context=context)
    _draw_inline_proxy_panels(layout, record, context=context)
    _draw_inline_deferred_panels(layout, record, context=context)


def _call_panel_fn(callable_obj, panel_cls, layout, context) -> None:
    shim_name = f'_SMARTTOOLS_INT_PANEL_SHIM_{ID_FACTORY.token(getattr(panel_cls, "__name__", ""), size=12)}'
    attrs = {}
    for name, value in getattr(panel_cls, '__dict__', {}).items():
        if name.startswith('__'):
            continue
        attrs[name] = value
    shim_cls = type(shim_name, (), attrs)
    shim = shim_cls()
    localized_layout = _localized_layout(layout, context)
    try:
        shim.layout = localized_layout
    except Exception:
        pass
    for name in ('bl_idname', 'bl_label', 'bl_space_type', 'bl_region_type', 'bl_context', 'bl_parent_id', 'bl_options', 'bl_order'):
        try:
            setattr(shim, name, getattr(panel_cls, name))
        except Exception:
            pass
    try:
        shim.is_popover = False
    except Exception:
        pass
    callable_obj(shim, context)


def _call_draw(draw_fn, panel_cls, layout, context) -> None:
    _call_panel_fn(draw_fn, panel_cls, layout, context)


def _call_draw_header(draw_header_fn, panel_cls, layout, context) -> None:
    _call_panel_fn(draw_header_fn, panel_cls, layout, context)


def _call_draw_header_preset(draw_header_preset_fn, panel_cls, layout, context) -> None:
    _call_panel_fn(draw_header_preset_fn, panel_cls, layout, context)


def _panel_custom_poll(panel_cls: type):
    # The single-N-panel guard hides every bundled original panel after the
    # loader records it.  Integrated Controls must evaluate the poll descriptor
    # saved by that guard, not the replacement poll(False), otherwise every
    # migrated panel body is permanently replaced by an unavailable message.
    try:
        from . import npanel_singleton as _singleton
        if bool(getattr(panel_cls, getattr(_singleton, '_GUARDED_ATTR', ''), False)):
            raw = getattr(
                panel_cls,
                getattr(_singleton, '_ORIGINAL_POLL_ATTR', ''),
                getattr(_singleton, '_MISSING', None),
            )
            if raw is getattr(_singleton, '_MISSING', None) or raw is None:
                return None
            if isinstance(raw, classmethod):
                return raw.__get__(None, panel_cls)
            return raw
    except Exception:
        pass
    if panel_cls in loader._HIDDEN_PANEL_POLLS:
        raw = loader._HIDDEN_PANEL_POLLS.get(panel_cls)
        if raw is loader._MISSING_POLL:
            return None
        return raw
    raw = panel_cls.__dict__.get('poll', None)
    if raw is None:
        return None
    try:
        return getattr(panel_cls, 'poll', None)
    except Exception:
        return None


def _panel_source_id(panel_cls: type) -> str:
    return str(getattr(panel_cls, 'bl_idname', '') or getattr(panel_cls, '__name__', '') or '')



def _draw_inline_feature_toggles(layout, context, alias: str) -> bool:
    # Always-on switches are centralized at the very top of the Smart File
    # N-panel.  Legacy proxy panels must not draw their own duplicate toggles.
    del layout, context, alias
    return False


def _proxy_panel_identifiers(record: dict, original_panel_cls: type, order_index: int) -> tuple[str, str]:
    spec = record['spec']
    suite_key = str(spec['suite'])
    alias = str(spec['alias'])
    return ID_FACTORY.panel('INTPROXY', suite_key, alias, getattr(original_panel_cls, '__name__', ''), order_index)


def _preference_entries(record: dict) -> list[type]:
    prefs = []
    seen = set()
    for cls in record.get('preferences', ()) or ():
        if cls in seen:
            continue
        seen.add(cls)
        prefs.append(cls)
    prefs.sort(key=lambda cls: str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or ''))
    return prefs


def _preference_candidate_keys(record: dict, pref_cls: type) -> list[str]:
    keys: list[str] = []
    for value in (
        getattr(pref_cls, 'bl_idname', ''),
        getattr(record.get('module'), '__name__', ''),
        record.get('spec', {}).get('original_module_name', ''),
    ):
        key = str(value or '').strip()
        if key and key not in keys:
            keys.append(key)
    return keys


def _preference_instance(record: dict, pref_cls: type, context):
    prefs_root = getattr(getattr(context, 'preferences', None), 'addons', None)
    if prefs_root is not None:
        for key in _preference_candidate_keys(record, pref_cls):
            addon = None
            try:
                addon = prefs_root.get(key)
            except Exception:
                addon = None
            if addon is None:
                try:
                    addon = prefs_root[key]
                except Exception:
                    addon = None
            prefs = getattr(addon, 'preferences', None) if addon is not None else None
            if prefs is not None:
                return prefs

    hook_names = (
        'get_integrated_preferences_proxy',
        'integrated_preferences_proxy',
    )
    for mod in loader._iter_family_modules(record.get('spec') or {}, record.get('module')):
        for hook_name in hook_names:
            hook = getattr(mod, hook_name, None)
            if not callable(hook):
                continue
            for kwargs in (
                {'context': context, 'pref_cls': pref_cls, 'record': record},
                {'context': context},
                {},
            ):
                try:
                    prefs = hook(**kwargs)
                except TypeError:
                    try:
                        prefs = hook(context)
                    except TypeError:
                        try:
                            prefs = hook()
                        except Exception:
                            prefs = None
                    except Exception:
                        prefs = None
                except Exception:
                    prefs = None
                if prefs is not None:
                    return prefs
    return None


def _call_preferences_draw(draw_fn, pref_cls: type, pref_instance, layout, context) -> None:
    sentinel = object()
    localized_layout = _localized_layout(layout, context)
    previous_cls_layout = getattr(pref_cls, 'layout', sentinel)
    previous_inst_layout = getattr(pref_instance, 'layout', sentinel)
    try:
        setattr(pref_cls, 'layout', localized_layout)
        try:
            setattr(pref_instance, 'layout', localized_layout)
        except Exception:
            pass
        draw_fn(pref_instance, context)
    finally:
        try:
            if previous_cls_layout is sentinel:
                delattr(pref_cls, 'layout')
            else:
                setattr(pref_cls, 'layout', previous_cls_layout)
        except Exception:
            pass
        try:
            if previous_inst_layout is sentinel:
                delattr(pref_instance, 'layout')
            else:
                setattr(pref_instance, 'layout', previous_inst_layout)
        except Exception:
            pass


def _deferred_panel_labels(record: dict) -> list[str]:
    labels: list[str] = []
    seen = set()
    for cls in record.get('deferred_panels', ()) or ():
        label = _iface(str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or '').strip())
        if not label or label in seen:
            continue
        seen.add(label)
        labels.append(label)
    labels.sort(key=str.lower)
    return labels



def _static_ui_entries(record: dict, key: str) -> list[dict[str, str]]:
    try:
        static_ui = (record.get('spec') or {}).get('static_ui') or {}
        entries = static_ui.get(str(key or '')) or []
        return [dict(item) for item in entries if isinstance(item, dict)]
    except Exception:
        return []

def _menu_entries(record: dict) -> list[tuple[str, str, bool]]:
    items: list[tuple[str, str, bool]] = []
    seen: set[str] = set()
    for cls in record.get('menus', ()) or ():
        menu_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not menu_id or menu_id in seen:
            continue
        seen.add(menu_id)
        label = _iface(str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or menu_id).strip())
        upper = f'{menu_id} {label} {getattr(cls, "__name__", "")}'.upper()
        items.append((menu_id, label or menu_id, 'PIE' in upper))
    for entry in _static_ui_entries(record, 'menus'):
        menu_id = str(entry.get('idname') or '').strip()
        if not menu_id or menu_id in seen:
            continue
        seen.add(menu_id)
        label = _iface(str(entry.get('label') or menu_id).strip())
        upper = f'{menu_id} {label} {entry.get("class_name", "")}'.upper()
        items.append((menu_id, label or menu_id, 'PIE' in upper))
    items.sort(key=lambda item: item[1].lower())
    return items


def _operator_entries(record: dict) -> list[tuple[str, str, str]]:
    items: list[tuple[str, str, str]] = []
    seen: set[str] = set()
    for cls in record.get('operators', ()) or ():
        op_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not op_id or op_id in seen:
            continue
        seen.add(op_id)
        label = _iface(str(getattr(cls, 'bl_label', '') or '').strip() or op_id)
        desc = _tip(str(getattr(cls, 'bl_description', '') or '').strip())
        items.append((op_id, label, desc))
    for entry in _static_ui_entries(record, 'operators'):
        op_id = str(entry.get('idname') or '').strip()
        if not op_id or op_id in seen:
            continue
        seen.add(op_id)
        label = _iface(str(entry.get('label') or op_id).strip())
        desc = _tip(str(entry.get('description') or '').strip())
        items.append((op_id, label or op_id, desc))
    items.sort(key=lambda item: (item[1].lower(), item[0].lower()))
    return items


def _quick_entries(record: dict, limit: int = 6) -> list[tuple[str, str, str, str, bool]]:
    quick: list[tuple[str, str, str, str, bool]] = []
    menu_limit = max(1, int(limit) // 2) if limit else 0
    for menu_id, label, is_pie in _menu_entries(record)[:menu_limit]:
        quick.append(('menu', menu_id, label, '', is_pie))
    remaining = max(0, int(limit) - len(quick))
    for op_id, label, desc in _operator_entries(record)[:remaining]:
        quick.append(('operator', op_id, label, desc, False))
    return quick


def _invoke_operator(layout, *, addon_alias: str, target_kind: str, target_id: str, label: str, desc: str = '', is_pie: bool = False, context=None) -> None:
    icon = 'PRESET' if target_kind == 'menu' and is_pie else ('DOWNARROW_HLT' if target_kind == 'menu' else 'TOOL_SETTINGS')
    try:
        op = layout.operator(SMARTFILESUITE_OT_integrated_tools_open.bl_idname, text=_iface(label, context=context), icon=icon)
        op.addon_alias = addon_alias
        op.target_kind = target_kind
        op.target_id = target_id
        op.target_label = label
        op.target_desc = desc
        op.is_pie_menu = bool(is_pie)
    except Exception:
        layout.label(text=_iface(label, context=context))


def _draw_tool_list(layout, record: dict, context=None, compact: bool = False) -> None:
    alias = str(record.get('spec', {}).get('alias') or '')
    menus = _menu_entries(record)
    operators = _operator_entries(record)
    if not menus and not operators:
        layout.label(
            text=_ui_text('No direct operator or menu entry was found.', '直接呼び出せるオペレーターやメニューが見つかりませんでした。', context=context),
        )
        return

    if menus:
        box = layout.box()
        box.label(text=_ui_text('Menus', 'メニュー', context=context), icon='MENU_PANEL')
        col = box.column(align=True)
        for menu_id, label, is_pie in menus:
            _invoke_operator(col, addon_alias=alias, target_kind='menu', target_id=menu_id, label=label, is_pie=is_pie, context=context)

    if operators:
        box = layout.box()
        box.label(text=_ui_text('Operators', 'オペレーター', context=context), icon='TOOL_SETTINGS')
        flow = box.grid_flow(row_major=True, columns=1 if compact else 2, even_columns=True, even_rows=False, align=True)
        for op_id, label, desc in operators:
            _invoke_operator(flow, addon_alias=alias, target_kind='operator', target_id=op_id, label=label, desc=desc, context=context)


def _resolve_operator_callable(op_id: str):
    op_id = str(op_id or '').strip()
    if '.' not in op_id:
        return None
    head, tail = op_id.split('.', 1)
    group = getattr(bpy.ops, head, None)
    if group is None:
        return None
    return getattr(group, tail, None)


class SMARTFILESUITE_OT_integrated_tools_add_on_info(bpy.types.Operator):
    bl_label = 'Add-on Info'
    bl_idname = 'smart_file_suite.sfs_integrated_tools_add_on_info'
    bl_label = 'Add-on Info'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        alias = str(getattr(properties, 'addon_alias', '') or '')
        record = _RECORDS_BY_ALIAS.get(alias, {})
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = _status_text(record, context=context) if isinstance(record, dict) else _ui_text('Unknown', '不明', context=context)
        note = str(spec.get('note') or '').strip()
        lines = [
            f"{spec.get('display_name', alias)}",
            _addon_help(spec, context=context),
            _ui_text(f'Status: {status}', f'状態: {status}', context=context),
        ]
        if note:
            lines.append(_ui_text(f'Note: {note}', f'備考: {note}', context=context))
        return ' '.join(str(line) for line in lines if line)

    def execute(self, context):
        alias = str(self.addon_alias or '')
        record = _RECORDS_BY_ALIAS.get(alias, {})
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = _status_text(record, context=context) if isinstance(record, dict) else _ui_text('Unknown', '不明', context=context)
        self.report({'INFO'}, _ui_text(f"{_ui_text(spec.get('display_name', alias), context=context)} - {status}", f"{_ui_text(spec.get('display_name', alias), context=context)} - {status}", context=context))
        return {'FINISHED'}


class SMARTFILESUITE_OT_integrated_tools_open_controls(bpy.types.Operator):
    bl_label = 'Open Controls'
    _sms_no_undo = True
    bl_idname = 'smart_file_suite.sfs_integrated_tools_open_controls'
    bl_label = 'Open Controls'
    bl_options = {'INTERNAL'}

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})
    category: bpy.props.StringProperty(options={'SKIP_SAVE'})
    popup_width: bpy.props.IntProperty(default=700, min=420, max=1100, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        alias = str(getattr(properties, 'addon_alias', '') or '')
        record = _RECORDS_BY_ALIAS.get(alias, {})
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        label = _iface(str(spec.get('display_name') or alias or 'Integrated tool'), context=context)
        return _ui_text(
            f'Function: opens the full migrated controls for {label} inside the current Smart File category. How to use: click this when the compact category buttons are not enough, then run the original panels, settings, or direct tools from the popup.',
            f'機能: {label} の移植済み詳細コントロールを現在の Smart File カテゴリ内で開きます。使い方: カテゴリ内の簡易ボタンだけでは足りない場合に押し、表示されたポップアップから元パネル、設定、直接実行ツールを使ってください。',
            context=context,
        )

    def invoke(self, context, event):
        alias = str(self.addon_alias or '').strip()
        record = _RECORDS_BY_ALIAS.get(alias, {})
        if alias and str(record.get('status') or '') != 'loaded':
            record = loader.load_alias(alias) or {}
            _schedule_rebuild_ui_runtime()
        return context.window_manager.invoke_popup(self, width=int(self.popup_width or 700))

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        alias = str(self.addon_alias or '').strip()
        record = _RECORDS_BY_ALIAS.get(alias, {})
        if not record:
            self.layout.label(text=_ui_text('Integrated tool information is unavailable.', '統合ツール情報を取得できませんでした。', context=context))
            return
        draw_integrated_record_contents(self.layout, record, context=context, search_text='', show_title=True)


class SMARTFILESUITE_OT_integrated_tools_open(bpy.types.Operator):
    bl_label = 'Open'
    bl_idname = 'smart_file_suite.sfs_integrated_tools_open'
    bl_label = 'Open'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_kind: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_id: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_label: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_desc: bpy.props.StringProperty(options={'SKIP_SAVE'})
    is_pie_menu: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        kind = str(getattr(properties, 'target_kind', '') or '')
        label = str(getattr(properties, 'target_label', '') or '')
        desc = str(getattr(properties, 'target_desc', '') or '')
        is_pie = bool(getattr(properties, 'is_pie_menu', False))
        return _target_help(kind, label, desc, is_pie=is_pie, context=context)

    def execute(self, context):
        alias = str(self.addon_alias or '').strip()
        record = _RECORDS_BY_ALIAS.get(alias, {})
        if alias and str(record.get('status') or '') != 'loaded':
            record = loader.load_alias(alias) or {}
            _schedule_rebuild_ui_runtime()
            if str(record.get('status') or '') != 'loaded':
                excerpt = _trace_excerpt(record.get('error', ''))
                self.report({'ERROR'}, _ui_text(f'Load failed: {excerpt or alias}', f'読み込みに失敗しました: {excerpt or alias}', context=context))
                return {'CANCELLED'}

        kind = str(self.target_kind or '').strip()
        target_id = str(self.target_id or '').strip()
        if kind == 'menu':
            try:
                if self.is_pie_menu:
                    return bpy.ops.wm.call_menu_pie(name=target_id)
                return bpy.ops.wm.call_menu(name=target_id)
            except Exception as exc:
                self.report({'ERROR'}, _ui_text(f'Menu invoke failed: {target_id} ({exc})', f'メニュー呼び出しに失敗しました: {target_id} ({exc})', context=context))
                return {'CANCELLED'}

        op_callable = _resolve_operator_callable(target_id)
        if not callable(op_callable):
            self.report({'ERROR'}, _ui_text(f'Operator not found: {target_id}', f'オペレーターが見つかりません: {target_id}', context=context))
            return {'CANCELLED'}

        last_error = None
        for args in (('INVOKE_DEFAULT',), tuple()):
            try:
                result = op_callable(*args)
                if isinstance(result, set):
                    return result
                return {'FINISHED'}
            except Exception as exc:
                last_error = exc
        self.report({'ERROR'}, _ui_text(f'Operator invoke failed: {target_id} ({last_error})', f'オペレーターの実行に失敗しました: {target_id} ({last_error})', context=context))
        return {'CANCELLED'}


def _addon_panel_class(record: dict):
    spec = record['spec']
    suite_key = str(spec['suite'])
    alias = str(spec['alias'])
    class_name, panel_id = ID_FACTORY.panel('INTADDON', suite_key, alias)
    parent_id = _SUITE_ROOT_PANEL_IDS[suite_key]
    panel_context = suite_panel_context(suite_key)

    @classmethod
    def poll(cls, context):
        area = getattr(context, 'area', None)
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            return False
        return suite_is_active(context, suite_key)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        # The panel header already shows the add-on name in the Smart File N-panel.
        # Avoid repeating the same title again inside the panel body.
        draw_integrated_record_contents(layout, record, context=context, search_text='', show_title=False)

    attrs = {
        '__module__': __name__,
        'bl_idname': panel_id,
        'bl_label': _ui_text(str(spec.get('display_name') or alias)),
        'bl_space_type': 'VIEW_3D',
        'bl_region_type': 'UI',
        'bl_category': 'Smart File',
        'bl_parent_id': parent_id,
        'bl_options': {'DEFAULT_CLOSED'},
        'poll': poll,
        'draw': draw,
        '_smart_suite_host_panel': True,
    }
    cls = type(class_name, (bpy.types.Panel,), attrs)
    _ADDON_PANEL_IDS[alias] = panel_id
    return cls


def _proxy_panel_class(record: dict, original_panel_cls: type, order_index: int, parent_id: str):
    spec = record['spec']
    suite_key = str(spec['suite'])
    alias = str(spec['alias'])
    class_name, panel_id = _proxy_panel_identifiers(record, original_panel_cls, order_index)
    panel_context = suite_panel_context(suite_key)
    original_label = _ui_text(str(getattr(original_panel_cls, 'bl_label', '') or getattr(original_panel_cls, '__name__', '') or panel_id))
    original_draw = getattr(original_panel_cls, 'draw', None)
    original_draw_header = getattr(original_panel_cls, 'draw_header', None)
    original_draw_header_preset = getattr(original_panel_cls, 'draw_header_preset', None)
    original_poll = _panel_custom_poll(original_panel_cls)
    original_bl_options = set(getattr(original_panel_cls, 'bl_options', set()) or set())
    proxy_options = {'DEFAULT_CLOSED'} | original_bl_options

    @classmethod
    def poll(cls, context):
        area = getattr(context, 'area', None)
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            return False
        if _native_panel_context_paused(context):
            return False
        if not suite_is_active(context, suite_key):
            return False
        if callable(original_poll):
            try:
                return bool(original_poll(context))
            except TypeError:
                try:
                    return bool(original_poll(original_panel_cls, context))
                except Exception:
                    return True
            except Exception:
                return True
        return True

    def draw(self, context):
        layout = self.layout
        _draw_inline_feature_toggles(layout, context, alias)
        if _native_panel_context_paused(context):
            _draw_native_panel_paused(layout, context=context)
            return
        if not callable(original_draw):
            layout.label(text=_ui_text('Original panel has no draw function.', '元パネルに draw 関数がありません。', context=context))
            return
        try:
            _call_draw(original_draw, original_panel_cls, layout, context)
        except Exception as exc:
            layout.label(text=f"{_ui_text('Proxy draw failed', 'プロキシ描画に失敗しました', context=context)}: {exc}", icon='ERROR')

    attrs = {
        '__module__': __name__,
        'bl_idname': panel_id,
        'bl_label': original_label,
        'bl_space_type': 'VIEW_3D',
        'bl_region_type': 'UI',
        'bl_category': 'Smart File',
        'bl_parent_id': parent_id,
        'bl_options': proxy_options,
        'poll': poll,
        'draw': draw,
        '_smart_suite_host_panel': True,
    }
    if hasattr(original_panel_cls, 'bl_order'):
        try:
            attrs['bl_order'] = getattr(original_panel_cls, 'bl_order')
        except Exception:
            pass

    # Do not copy original header draw callbacks into generated proxy panels.
    # They often assume a live original panel instance and are a common source of
    # stale UI callback access during Blender 5.1 panel event teardown.
    return type(class_name, (bpy.types.Panel,), attrs)


def _settings_panel_class(record: dict):
    spec = record['spec']
    suite_key = str(spec['suite'])
    alias = str(spec['alias'])
    parent_id = _ADDON_PANEL_IDS[alias]
    class_name, panel_id = ID_FACTORY.panel('INTPREF', suite_key, alias)
    panel_context = suite_panel_context(suite_key)

    @classmethod
    def poll(cls, context):
        area = getattr(context, 'area', None)
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            return False
        return suite_is_active(context, suite_key)

    def draw(self, context):
        layout = self.layout
        prefs_classes = _preference_entries(record)
        if not prefs_classes:
            layout.label(text=_ui_text('No settings panel was found.', '設定パネルは見つかりませんでした。', context=context))
            return
        for index, pref_cls in enumerate(prefs_classes, start=1):
            prefs_instance = _preference_instance(record, pref_cls, context)
            title = _ui_text(str(getattr(pref_cls, 'bl_label', '') or '').strip() or 'Settings', context=context)
            if len(prefs_classes) > 1:
                box = layout.box()
                box.label(text=title, icon='PREFERENCES')
                target = box.column(align=False)
            else:
                target = layout.column(align=False)
            if prefs_instance is None:
                warn = target.box()
                warn.alert = True
                _wrap_lines(warn, _ui_text(f'Settings instance is unavailable for {title}.', f'{title} の設定インスタンスを取得できませんでした。', context=context), width=70, icon='ERROR')
                continue
            draw_fn = getattr(pref_cls, 'draw', None)
            if not callable(draw_fn):
                target.label(text=_ui_text('Preference draw function is missing.', '設定の draw 関数がありません。', context=context))
                continue
            try:
                _call_preferences_draw(draw_fn, pref_cls, prefs_instance, target, context)
            except Exception as exc:
                fail = target.box()
                fail.alert = True
                fail.label(text=f"{_ui_text('Preferences draw failed', '設定描画に失敗しました', context=context)}: {exc}", icon='ERROR')

    attrs = {
        '__module__': __name__,
        'bl_idname': panel_id,
        'bl_label': _ui_text('Settings', '設定'),
        'bl_space_type': 'VIEW_3D',
        'bl_region_type': 'UI',
        'bl_category': 'Smart File',
        'bl_parent_id': parent_id,
        'bl_options': {'DEFAULT_CLOSED'},
        'poll': poll,
        'draw': draw,
        '_smart_suite_host_panel': True,
    }
    return type(class_name, (bpy.types.Panel,), attrs)


def _tool_panel_class(record: dict):
    spec = record['spec']
    suite_key = str(spec['suite'])
    alias = str(spec['alias'])
    parent_id = _ADDON_PANEL_IDS[alias]
    class_name, panel_id = ID_FACTORY.panel('INTTOOLS', suite_key, alias)
    panel_context = suite_panel_context(suite_key)

    @classmethod
    def poll(cls, context):
        area = getattr(context, 'area', None)
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            return False
        return suite_is_active(context, suite_key)

    def draw(self, context):
        _draw_tool_list(self.layout, record, context=context, compact=True)

    attrs = {
        '__module__': __name__,
        'bl_idname': panel_id,
        'bl_label': _ui_text('Tools', 'ツール'),
        'bl_space_type': 'VIEW_3D',
        'bl_region_type': 'UI',
        'bl_category': 'Smart File',
        'bl_parent_id': parent_id,
        'bl_options': {'DEFAULT_CLOSED'},
        'poll': poll,
        'draw': draw,
        '_smart_suite_host_panel': True,
    }
    return type(class_name, (bpy.types.Panel,), attrs)


def _collect_records() -> None:
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()
    for record in loader.get_records():
        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '')
        suite_key = str(spec.get('suite') or '')
        if alias:
            _RECORDS_BY_ALIAS[alias] = record
        if suite_key:
            _SUITE_RECORDS.setdefault(suite_key, []).append(record)


def register() -> bool:
    global _LAST_RUNTIME_ERROR
    _LAST_RUNTIME_ERROR = ""
    if not _safe_unregister_registered_classes():
        _LAST_RUNTIME_ERROR = "previous UI runtime generation cleanup failed"
        return False
    if not _install_owner():
        _LAST_RUNTIME_ERROR = "UI runtime owner ledger unavailable"
        return False
    try:
        _collect_records()
        _safe_register_class(SMARTFILESUITE_OT_integrated_tools_add_on_info)
        _safe_register_class(SMARTFILESUITE_OT_integrated_tools_open_controls)
        _safe_register_class(SMARTFILESUITE_OT_integrated_tools_open)
        exact = all(_class_owned_rna(cls) for cls in _REGISTERED_CLASSES)
        if not exact or len(_REGISTERED_CLASSES) != 3:
            raise RuntimeError("UI runtime exact class validation failed")
        return True
    except Exception as exc:
        _LAST_RUNTIME_ERROR = f"{type(exc).__name__}: {exc}"
        _cleanup_generation()
        return False

    # Bundled legacy add-ons are exposed through the Smart File functional
    # category hubs rather than as separate add-on panels.  This keeps importers,
    # exporters, previews, history, and support tools grouped with the native
    # Smart File buttons instead of creating another individual-tool tree.
    # Startup stays light: Smart File suite runtime is refreshed on demand by
    # the Smart File core wrapper or later tool-load operations.


def unregister() -> bool:
    ok = _cleanup_generation()
    namespace = _namespace()
    if namespace is not None:
        owner = namespace.get(_OWNER_KEY)
        if isinstance(owner, dict) and owner.get("token") is _OWNER_TOKEN:
            namespace.pop(_OWNER_KEY, None)
    return ok
