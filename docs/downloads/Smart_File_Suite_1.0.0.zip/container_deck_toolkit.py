# -----------------------------------------------------------------------------
#  Container Deck / Revision Update / Representation Switch
# -----------------------------------------------------------------------------

import os


def _sf_pipe_container_reference(context):
    state = _sf_pipe_runtime_container_state(context)
    manifest_path = _norm_path(str((state or {}).get('manifest_path', '') or ''))
    manifest = {}
    if manifest_path and os.path.isfile(manifest_path):
        try:
            manifest = _sf_pipe_json_read(manifest_path)
        except Exception:
            manifest = {}
    return state if isinstance(state, dict) else {}, manifest if isinstance(manifest, dict) else {}, manifest_path


def _sf_pipe_container_board_payload(context, *, recursive: bool = False) -> dict:
    state, manifest, manifest_path = _sf_pipe_container_reference(context)
    ready = bool(manifest and manifest_path)
    if not ready:
        return {
            'ready': False,
            'state': state,
            'manifest': manifest,
            'manifest_path': manifest_path,
            'related_rows': [],
            'alternate_rows': [],
            'latest_same_rep': {},
            'search_root': _norm_path(os.path.dirname(manifest_path or '')),
        }
    search_root = _norm_path(os.path.dirname(manifest_path or ''))
    related_rows = _sf_pipe_related_container_rows(manifest, manifest_path, search_root=search_root, recursive=recursive)
    current_rep = _sf_pipe_manifest_representation(manifest)
    latest_same_rep = _sf_pipe_pick_latest_related(manifest, manifest_path, search_root=search_root, recursive=recursive, representation=current_rep)
    by_rep = {}
    current_rep_lower = str(current_rep or '').strip().lower()
    for row in list(related_rows or []):
        rep = str(row.get('representation', '') or 'main')
        rep_lower = rep.lower()
        if rep_lower == current_rep_lower:
            continue
        best = by_rep.get(rep_lower)
        if best is None or int(row.get('revision', 0) or 0) >= int(best.get('revision', 0) or 0):
            by_rep[rep_lower] = row
    alternate_rows = sorted(by_rep.values(), key=lambda row: (str(row.get('representation', '')).lower(), -int(row.get('revision', 0) or 0)))
    return {
        'ready': True,
        'state': state,
        'manifest': manifest,
        'manifest_path': manifest_path,
        'search_root': search_root,
        'related_rows': related_rows,
        'alternate_rows': alternate_rows,
        'latest_same_rep': latest_same_rep,
    }


def _sf_pipe_representation_switch_items(self, context):
    _state, manifest, manifest_path = _sf_pipe_container_reference(context)
    if not manifest or not manifest_path:
        return _sf_stable_enum_items([('NONE', 'No container state', 'Load or publish a container first.')])
    recursive = bool(getattr(self, 'recursive_scan', False))
    rows = _sf_pipe_related_container_rows(manifest, manifest_path, search_root=os.path.dirname(manifest_path), recursive=recursive)
    current_rep_lower = str(_sf_pipe_manifest_representation(manifest) or '').strip().lower()
    items = []
    seen = set()
    for row in sorted(rows, key=lambda it: (str(it.get('representation', '')).lower(), -int(it.get('revision', 0) or 0))):
        rep = str(row.get('representation', '') or 'main').strip()
        rep_lower = rep.lower()
        if not rep or rep_lower == current_rep_lower or rep_lower in seen:
            continue
        seen.add(rep_lower)
        latest = _sf_pipe_pick_latest_related(manifest, manifest_path, search_root=os.path.dirname(manifest_path), recursive=recursive, representation=rep)
        latest_rev = int((latest or {}).get('revision', row.get('revision', 1)) or 1)
        items.append((rep, rep, _t(f'Load the latest {rep} representation, revision {latest_rev}.')))
    return _sf_stable_enum_items(items or [('NONE', 'No alternate representations', 'No alternate representations were found beside the current container.')])


def _sf_pipe_representation_switch_items_enum(self, context):
    return _sf_pipe_representation_switch_items(self, context)


def _sf_pipe_container_revision_rows(self, context):
    _state, manifest, manifest_path = _sf_pipe_container_reference(context)
    if not manifest or not manifest_path:
        return []
    recursive = bool(getattr(self, 'recursive_scan', False))
    rows = _sf_pipe_related_container_rows(
        manifest,
        manifest_path,
        search_root=os.path.dirname(manifest_path),
        recursive=recursive,
    )
    current_norm = _norm_path(manifest_path)
    ordered = []
    seen = set()
    for row in sorted(
        rows,
        key=lambda it: (
            str(it.get('representation', '') or 'main').lower(),
            -int(it.get('revision', 0) or 0),
            _norm_path(str(it.get('path') or '')),
        ),
    ):
        path_norm = _norm_path(str(row.get('path') or ''))
        if not path_norm or path_norm in seen:
            continue
        seen.add(path_norm)
        entry = dict(row or {})
        entry['path'] = path_norm
        entry['is_current'] = path_norm == current_norm
        ordered.append(entry)
    return ordered


def _sf_pipe_container_revision_items(self, context):
    rows = _sf_pipe_container_revision_rows(self, context)
    if not rows:
        return _sf_stable_enum_items([('NONE', 'No related revisions', 'Load or publish a container first.')])
    items = []
    for row in rows:
        rep = str(row.get('representation', '') or 'main')
        revision = int(row.get('revision', 1) or 1)
        status = str(row.get('status', '') or '')
        stem = os.path.basename(str(row.get('path') or ''))
        label = f"{rep} | r{revision}"
        if status:
            label += f" | {status}"
        if row.get('is_current'):
            label += '| CURRENT'
        desc = f"Load {rep} revision {revision}"
        if status:
            desc += f" ({status})"
        desc += f'. Source: {stem}. Representation {rep}, revision {revision}'
        if status:
            desc += f"（{status}）"
        desc += f" を読み込みます。元ファイル: {stem}"
        if row.get('is_current'):
            desc += "。現在アクティブなコンテナです。"
        items.append((str(row.get('path') or ''), label, desc))
    return _sf_stable_enum_items(items or [('NONE', 'No related revisions', 'No related container manifests were found.')])


def _sf_pipe_container_revision_items_enum(self, context):
    return _sf_pipe_container_revision_items(self, context)


class SF_OT_container_deck_open(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = 'import_scene.sfs_container_deck_open'
    bl_label = 'Open'
    bl_description = 'Open a compact pipeline container board that shows the most recent loaded or published container, the latest matching revision, and alternate representations so versioned handoff stays easy to inspect.'
    bl_options = {'INTERNAL'}

    popup_width: IntProperty(default=700, min=520, max=920, options={'HIDDEN'})
    recursive_scan: BoolProperty(name='Recursive scan', default=False, description='Also scan subfolders below the current container folder when looking for related manifests.')

    def invoke(self, context, event):
        try:
            _sf_append_activity(context, _t('Opened Container Deck'), '', 'PACKAGE')
        except Exception:
            pass
        return context.window_manager.invoke_popup(self, width=self.popup_width)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        payload = _sf_pipe_container_board_payload(context, recursive=bool(self.recursive_scan))
        layout.prop(self, 'recursive_scan')
        _sf_draw_dialog_header(
            layout,
            'Container Deck',
            'Review the latest loaded or published container first, then switch revisions or representations without leaving the main Smart File workflow.',
            'PACKAGE',
        )

        if not payload.get('ready'):
            _sf_draw_empty_state(layout, 'No container state yet', 'Load or publish a container first so the deck can compare revisions and alternate representations.', 'NONE')
            actions = layout.box()
            _sf_draw_section_intro(actions, 'Quick Start', 'Use Publish Container to create a reusable manifest, or Load Container to restore one and make it the current comparison target.', 'CHECKMARK')
            row = actions.row(align=True)
            row.operator('export_scene.sfs_pipeline_publish_container', text=_t('Publish Container'), icon='EXPORT')
            row.operator('import_scene.sfs_pipeline_load_container', text=_t('Load Container'), icon='IMPORT')
            row = actions.row(align=True)
            row.operator('import_scene.sfs_dependency_cockpit_open', text=_t('Open'), icon='NETWORK_DRIVE')
            row.operator('import_scene.sfs_project_guard_open', text=_t('Open'), icon='LOCKVIEW_ON')
            return

        manifest = dict(payload.get('manifest') or {})
        manifest_path = str(payload.get('manifest_path') or '')
        latest = dict(payload.get('latest_same_rep') or {})
        current_revision = int(_sf_pipe_manifest_revision(manifest, manifest_path) or 1)
        latest_revision = int(latest.get('revision', current_revision) or current_revision)

        current_box = layout.box()
        _sf_draw_section_intro(current_box, 'Current Container', 'Use this summary to confirm which container family, representation, and revision are currently active in the session.', 'PACKAGE')
        _sf_draw_state_line(current_box, 'Container Name', 'READY', detail=str(manifest.get('container_name', '') or ''))
        _sf_draw_state_line(current_box, 'Family', 'READY', detail=_sf_pipe_manifest_family(manifest))
        _sf_draw_state_line(current_box, 'Representation', 'READY', detail=_sf_pipe_manifest_representation(manifest))
        _sf_draw_state_line(current_box, 'Revision', 'READY', detail=str(current_revision))
        _sf_draw_state_line(current_box, 'Status', 'READY', detail=_sf_pipe_manifest_status(manifest))
        _sf_draw_state_line(current_box, 'Search Root', 'READY' if payload.get('search_root') else 'NOT SET', detail=_sf_short_path_display(str(payload.get('search_root') or ''), 72))
        current_box.label(text=_sf_short_path_display(manifest_path, 92), icon='FILE')

        rev_box = layout.box()
        _sf_draw_section_intro(rev_box, 'Latest Revision', 'Check here before reloading so you can see whether the current representation already points at the newest available revision.', 'FILE_REFRESH')
        is_latest = bool(latest) and _norm_path(str(latest.get('path') or '')) == _norm_path(manifest_path)
        latest_label = f"r{latest_revision}"
        if latest:
            latest_label += f" | {os.path.basename(str(latest.get('path') or ''))}"
        _sf_draw_state_line(rev_box, 'Latest Revision', 'READY' if latest else 'NOT SET', detail=latest_label)
        _sf_draw_state_line(rev_box, 'Current vs Latest', 'OK' if is_latest else 'REVIEW', detail=_t('Current container is already the latest revision') if is_latest else f"r{current_revision} -> r{latest_revision}")

        related_rows = list(payload.get('related_rows') or [])
        alt_rows = list(payload.get('alternate_rows') or [])
        rev_box2 = layout.box()
        _sf_draw_section_intro(
            rev_box2,
            'Available Revisions',
            'Read this list when you need more than just latest-or-switch behavior. It shows nearby revisions across representations so you can deliberately reopen an older publish, compare a status change, or move to a non-latest handoff.',
            'FILEBROWSER',
        )
        if not related_rows:
            rev_box2.label(text=_t('No related revisions were found'))
        else:
            current_norm = _norm_path(manifest_path)
            for row in related_rows[:8]:
                row_path = _norm_path(str(row.get('path') or ''))
                rep = str(row.get('representation', '') or 'main')
                revision = int(row.get('revision', 1) or 1)
                status = str(row.get('status', '') or '')
                label = f"{rep} | r{revision}"
                if status:
                    label += f" | {status}"
                icon = 'CHECKMARK' if row_path == current_norm else 'BLANK1'
                rev_box2.label(text=label, icon=icon)
            if len(related_rows) > 8:
                rev_box2.label(text=f"+ {len(related_rows) - 8} {_t('more')}", icon='DOT')

        alt_box = layout.box()
        _sf_draw_section_intro(alt_box, 'Alternate Representations', 'Use representation switching when one container has multiple publish flavors such as main, proxy, render, layout, or anim.', 'ASSET_MANAGER')
        if not alt_rows:
            alt_box.label(text=_t('No alternate representations were found'))
        else:
            for row in alt_rows[:8]:
                alt_box.label(text=f"{row.get('representation','')} | r{int(row.get('revision', 1) or 1)} | {row.get('status','')}", icon='BLANK1')
            if len(alt_rows) > 8:
                alt_box.label(text=f"+ {len(alt_rows) - 8} {_t('more')}", icon='DOT')

        quick = layout.box()
        _sf_draw_section_intro(quick, 'Quick Actions', 'Stay inside one compact board while you publish, reload the newest revision, or jump to a different representation.', 'CHECKMARK')
        row = quick.row(align=True)
        row.operator('export_scene.sfs_pipeline_publish_container', text=_t('Publish Container'), icon='EXPORT')
        op = row.operator('import_scene.sfs_container_deck_load_latest', text=_t('Load Latest'), icon='FILE_REFRESH')
        op.recursive_scan = bool(self.recursive_scan)
        op = row.operator('import_scene.sfs_container_deck_switch_representation', text=_t('Switch Representation'), icon='ASSET_MANAGER')
        op.recursive_scan = bool(self.recursive_scan)

        row = quick.row(align=True)
        op = row.operator('import_scene.sfs_container_deck_load_revision', text=_t('Load Revision'), icon='FILEBROWSER')
        op.recursive_scan = bool(self.recursive_scan)
        row.operator('import_scene.sfs_pipeline_load_container', text=_t('Load Container'), icon='IMPORT')
        row.operator('import_scene.sfs_pipeline_linked_overview', text=_t('Linked Overview'), icon='LINKED')

        row = quick.row(align=True)
        row.operator('import_scene.sfs_dependency_cockpit_open', text=_t('Open'), icon='NETWORK_DRIVE')
        row.operator('import_scene.sfs_project_guard_open', text=_t('Open'), icon='LOCKVIEW_ON')


class SF_OT_container_deck_load_latest(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_container_deck_load_latest'
    bl_label = 'Load Latest'
    bl_description = 'Find the latest revision of the current container representation beside the last loaded or published manifest, then load it through the standard container loader.'
    bl_options = {'UNDO'}

    recursive_scan: BoolProperty(name='Recursive scan', default=False, description='Also search subfolders beneath the current container folder.')
    prefer_payload_blend: BoolProperty(name='Prefer payload .blend', default=True)
    preserve_existing_settings: BoolProperty(name='Preserve existing settings', default=False)
    open_import_dialog: BoolProperty(name='Open import dialog', default=True)
    run_import_now: BoolProperty(name='Run import now', default=False)

    def execute(self, context):
        _state, manifest, manifest_path = _sf_pipe_container_reference(context)
        if not manifest or not manifest_path:
            self.report({'ERROR'}, _t('Load or publish a container first'))
            return {'CANCELLED'}
        representation = _sf_pipe_manifest_representation(manifest)
        latest = _sf_pipe_pick_latest_related(manifest, manifest_path, search_root=os.path.dirname(manifest_path), recursive=bool(self.recursive_scan), representation=representation)
        if not latest:
            self.report({'ERROR'}, _t('No related container manifests were found'))
            return {'CANCELLED'}
        target_path = _norm_path(str(latest.get('path') or ''))
        if target_path == _norm_path(manifest_path):
            self.report({'INFO'}, _t('Current container is already the latest revision'))
            return {'FINISHED'}
        try:
            bpy.ops.import_scene.sfs_pipeline_load_container(
                'EXEC_DEFAULT',
                filepath=target_path,
                prefer_payload_blend=bool(self.prefer_payload_blend),
                preserve_existing_settings=bool(self.preserve_existing_settings),
                open_import_dialog=bool(self.open_import_dialog),
                run_import_now=bool(self.run_import_now),
            )
        except Exception as ex:
            self.report({'ERROR'}, f"{_t('Container load failed')}: {ex}")
            return {'CANCELLED'}
        _sf_report_export(
            context,
            _t('Load Latest Container'),
            _sf_pipe_report_lines(_t('Load Latest Container'), {
                'Current Manifest': manifest_path,
                'Latest Manifest': target_path,
                'Family': _sf_pipe_manifest_family(manifest),
                'Representation': representation,
                'From Revision': _sf_pipe_manifest_revision(manifest, manifest_path),
                'To Revision': latest.get('revision', 1),
            }),
            open_text=False,
            activity_title=_t('Loaded latest pipeline container'),
        )
        self.report({'INFO'}, f"{_t('Load Latest Container')}: {os.path.basename(target_path)}")
        return {'FINISHED'}


class SF_OT_container_deck_load_revision(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_container_deck_load_revision'
    bl_label = 'Load Revision'
    bl_description = 'Choose any related container revision from the same family'
    bl_options = {'UNDO'}

    recursive_scan: BoolProperty(name='Recursive scan', default=False, description='Also search subfolders beneath the current container folder.')
    target_manifest: EnumProperty(name='Revision', items=_sf_pipe_container_revision_items_enum)
    prefer_payload_blend: BoolProperty(name='Prefer payload .blend', default=True)
    preserve_existing_settings: BoolProperty(name='Preserve existing settings', default=False)
    open_import_dialog: BoolProperty(name='Open import dialog', default=True)
    run_import_now: BoolProperty(name='Run import now', default=False)

    def invoke(self, context, event):
        rows = _sf_pipe_container_revision_rows(self, context)
        if not rows:
            self.report({'ERROR'}, _t('No related container manifests were found'))
            return {'CANCELLED'}
        if not str(getattr(self, 'target_manifest', '') or '').strip() or str(self.target_manifest) == 'NONE':
            current = next((row for row in rows if not row.get('is_current')), None)
            self.target_manifest = str((current or rows[0]).get('path') or '')
        return context.window_manager.invoke_props_dialog(self, width=620)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'target_manifest')
        layout.prop(self, 'recursive_scan')
        layout.prop(self, 'prefer_payload_blend')
        layout.prop(self, 'preserve_existing_settings')
        layout.prop(self, 'open_import_dialog')
        layout.prop(self, 'run_import_now')

    def execute(self, context):
        target_path = _norm_path(str(self.target_manifest or ''))
        if not target_path or target_path == 'NONE':
            self.report({'ERROR'}, _t('No related container manifests were found'))
            return {'CANCELLED'}
        _state, manifest, manifest_path = _sf_pipe_container_reference(context)
        if not manifest or not manifest_path:
            self.report({'ERROR'}, _t('Load or publish a container first'))
            return {'CANCELLED'}
        if target_path == _norm_path(manifest_path):
            self.report({'INFO'}, _t('Selected revision is already active'))
            return {'FINISHED'}
        rows = _sf_pipe_container_revision_rows(self, context)
        target_row = next((row for row in rows if _norm_path(str(row.get('path') or '')) == target_path), None)
        if target_row is None:
            self.report({'ERROR'}, _t('Selected revision was not found in the related container set'))
            return {'CANCELLED'}
        try:
            bpy.ops.import_scene.sfs_pipeline_load_container(
                'EXEC_DEFAULT',
                filepath=target_path,
                prefer_payload_blend=bool(self.prefer_payload_blend),
                preserve_existing_settings=bool(self.preserve_existing_settings),
                open_import_dialog=bool(self.open_import_dialog),
                run_import_now=bool(self.run_import_now),
            )
        except Exception as ex:
            self.report({'ERROR'}, f"{_t('Container load failed')}: {ex}")
            return {'CANCELLED'}
        _sf_report_export(
            context,
            _t('Load Any Revision'),
            _sf_pipe_report_lines(_t('Load Any Revision'), {
                'Current Manifest': manifest_path,
                'Target Manifest': target_path,
                'Family': _sf_pipe_manifest_family(manifest),
                'From Representation': _sf_pipe_manifest_representation(manifest),
                'To Representation': target_row.get('representation', ''),
                'From Revision': _sf_pipe_manifest_revision(manifest, manifest_path),
                'To Revision': target_row.get('revision', 1),
                'Target Status': target_row.get('status', ''),
            }),
            open_text=False,
            activity_title=_t('Loaded specific container revision'),
        )
        self.report({'INFO'}, f"{_t('Load Any Revision')}: {os.path.basename(target_path)}")
        return {'FINISHED'}


class SF_OT_container_deck_switch_representation(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_container_deck_switch_representation'
    bl_label = 'Switch Representation'
    bl_description = 'Switch from the current container to the newest available revision of another representation that shares the same family and container name.'
    bl_options = {'UNDO'}

    recursive_scan: BoolProperty(name='Recursive scan', default=False, description='Also search subfolders beneath the current container folder.')
    representation_name: EnumProperty(name='Representation', items=_sf_pipe_representation_switch_items_enum)
    prefer_payload_blend: BoolProperty(name='Prefer payload .blend', default=True)
    preserve_existing_settings: BoolProperty(name='Preserve existing settings', default=False)
    open_import_dialog: BoolProperty(name='Open import dialog', default=True)
    run_import_now: BoolProperty(name='Run import now', default=False)

    def invoke(self, context, event):
        items = _sf_pipe_representation_switch_items(self, context)
        if not items or items[0][0] == 'NONE':
            self.report({'ERROR'}, _t('No alternate representations were found'))
            return {'CANCELLED'}
        if not str(getattr(self, 'representation_name', '') or '').strip() or str(self.representation_name) == 'NONE':
            self.representation_name = items[0][0]
        return context.window_manager.invoke_props_dialog(self, width=560)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'representation_name')
        layout.prop(self, 'recursive_scan')
        layout.prop(self, 'prefer_payload_blend')
        layout.prop(self, 'preserve_existing_settings')
        layout.prop(self, 'open_import_dialog')
        layout.prop(self, 'run_import_now')

    def execute(self, context):
        if str(self.representation_name or '') == 'NONE':
            self.report({'ERROR'}, _t('No alternate representations were found'))
            return {'CANCELLED'}
        _state, manifest, manifest_path = _sf_pipe_container_reference(context)
        if not manifest or not manifest_path:
            self.report({'ERROR'}, _t('Load or publish a container first'))
            return {'CANCELLED'}
        target = _sf_pipe_pick_latest_related(
            manifest,
            manifest_path,
            search_root=os.path.dirname(manifest_path),
            recursive=bool(self.recursive_scan),
            representation=self.representation_name,
        )
        if not target:
            self.report({'ERROR'}, _t('No alternate representations were found'))
            return {'CANCELLED'}
        target_path = _norm_path(str(target.get('path') or ''))
        try:
            bpy.ops.import_scene.sfs_pipeline_load_container(
                'EXEC_DEFAULT',
                filepath=target_path,
                prefer_payload_blend=bool(self.prefer_payload_blend),
                preserve_existing_settings=bool(self.preserve_existing_settings),
                open_import_dialog=bool(self.open_import_dialog),
                run_import_now=bool(self.run_import_now),
            )
        except Exception as ex:
            self.report({'ERROR'}, f"{_t('Container load failed')}: {ex}")
            return {'CANCELLED'}
        _sf_report_export(
            context,
            _t('Switch Container Representation'),
            _sf_pipe_report_lines(_t('Switch Container Representation'), {
                'Current Manifest': manifest_path,
                'Target Manifest': target_path,
                'Family': _sf_pipe_manifest_family(manifest),
                'From Representation': _sf_pipe_manifest_representation(manifest),
                'To Representation': self.representation_name,
                'Target Revision': target.get('revision', 1),
            }),
            open_text=False,
            activity_title=_t('Switched container representation'),
        )
        self.report({'INFO'}, f"{_t('Switch Container Representation')}: {os.path.basename(target_path)}")
        return {'FINISHED'}
