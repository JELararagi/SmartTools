# ------------------------------------------------------------------------------
# Copyright (C) 2026 JELararagi
#
# License:
# - Copyright (C) 2026 JELararagi.
# - Licensed under the GNU General Public License v3.0 or later (GPL-3.0-or-later).
# ------------------------------------------------------------------------------

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, IntProperty, StringProperty
from bpy.types import PropertyGroup

from .translation import iface as _iface

# Property RNA and its text surface must be identical in foreground and
# background Blender; the helper is context-safe.
from ..ui_language_runtime import ui_text as _ui_text


class UHM_HistoryEntry(PropertyGroup):
    bl_description = "Store one history row for restore points, autosaves, and recovery notes so you can review and reopen earlier file states"

    uid: StringProperty(
        name="UID",
        description="Internal identifier used by the add-on to distinguish one history row from another. This is mainly technical data and usually does not need to be edited manually.",
    )
    label: StringProperty(
        name="Label",
        description="Main title shown in the history list. Good labels help you understand at a glance what kind of restore point or autosave this row represents.",
    )
    detail: StringProperty(
        name="Details",
        description="Additional explanation stored for this row. It can contain context such as why the snapshot was created, whether it was manual or automatic, and what happened around that time.",
    )
    entry_type: StringProperty(
        name="Type",
        description="The row category. In this add-on the visible list is mainly made of Restore Point rows and Autosave rows.",
    )
    timestamp: StringProperty(
        name="Time",
        description="Date and time when this history row was recorded. Use this to understand the order of saved states during a work session.",
    )
    active_object: StringProperty(
        name="Object",
        description="Name of the active object when this row was recorded. This helps you remember what you were working on when the snapshot or autosave was created.",
    )
    mode: StringProperty(
        name="Mode",
        description="The Blender interaction mode that was active when this row was recorded, such as Object Mode or Edit Mode.",
    )
    scene_name: StringProperty(
        name="Scene",
        description="Scene name at the moment this row was stored. This is useful when one blend file contains multiple scenes.",
    )
    frame: IntProperty(
        name="Frame",
        default=0,
        description="Current frame number when the row was recorded. This is especially helpful in animation or timeline-based workflows.",
    )
    selected_count: IntProperty(
        name="Selected Count",
        default=0,
        description="Number of selected objects when this row was recorded. This can help you understand the editing context for that saved point.",
    )
    file_path: StringProperty(
        name="Attached File",
        subtype='FILE_PATH',
        description="Full path to the actual .blend file linked to this row. Restoring the row opens this file or uses it as the nearest valid fallback.",
    )
    restorable: BoolProperty(
        name="Restorable",
        default=False,
        description="Shows whether this row has a directly usable file that can be opened for restore. If this is off, the add-on may use the nearest earlier restore point instead.",
    )
    nearest_restore_index: IntProperty(
        name="Nearest Restore Index",
        default=-1,
        description="Internal fallback link to the nearest earlier restore point. This is used when a row itself does not have a directly restorable file.",
    )


class SFS_PG_history_crash_recovery_candidate(PropertyGroup):
    bl_description = "Store one crash-recovery candidate found by the Smart File History & Restore recovery scanner"

    scene_name: StringProperty(name='Scene', default="", options={'SKIP_SAVE'})
    path: StringProperty(name='Candidate File', subtype='FILE_PATH', default="", options={'SKIP_SAVE'})
    label: StringProperty(name='Kind', default="", options={'SKIP_SAVE'})
    kind: StringProperty(name="Kind Key", default="", options={'SKIP_SAVE'})
    source_pid: IntProperty(name='Source PID', default=0, min=0, options={'SKIP_SAVE'})
    crash_signal: StringProperty(name='Crash Signal', default="", options={'SKIP_SAVE'})
    mtime_text: StringProperty(name='Modified', default="", options={'SKIP_SAVE'})
    size: IntProperty(name='Size', default=0, min=0, options={'SKIP_SAVE'})
    recommended: BoolProperty(name='Recommended', default=False, options={'SKIP_SAVE'})
    suspect_small: BoolProperty(name='Suspicious Size', default=False, options={'SKIP_SAVE'})
    valid_blend_header: BoolProperty(name='Readable Blend Header', default=False, options={'SKIP_SAVE'})


def _uhm_scene_setting_update(self, context):
    try:
        from .. import settings as _sfs_settings
        _sfs_settings.schedule_save(context or getattr(bpy, 'context', None))
    except Exception:
        pass


class UHM_SceneSettings(PropertyGroup):
    bl_description = "Store scene-specific history settings and cached rows used by the integrated restore and autosave workflow"

    entries: CollectionProperty(
        type=UHM_HistoryEntry,
        name="History Entries",
        description="All history rows tracked for the current scene during this session, including restore points and autosaves shown in the browser.",
    )
    active_index: IntProperty(
        name="Active Entry",
        default=-1,
        update=_uhm_scene_setting_update,
        description="Currently selected history row in the browser. The Restore Selected button works on this row.",
    )
    project_key: StringProperty(
        name="Project Key",
        default="",
        update=_uhm_scene_setting_update,
        description="Internal project identifier used to keep the current blend file linked to the correct restore-point and autosave folders.",
    )
    checkpoint_name: StringProperty(
        name='Quick Note',
        default="",
        update=_uhm_scene_setting_update,
        description=(
            "Name used for the next manual restore point. Choose clear beginner-friendly names such as 'Before UV cleanup', 'Before Boolean test', or 'Before rig export' so older saved states stay easy to recognize later."
        ),
    )
    filter_text: StringProperty(
        name="Search History",
        default="",
        update=_uhm_scene_setting_update,
        description=(
            "Filters the history browser by text. The search checks labels, details, timestamps, object names, scenes, and row types, which makes it easier to find one important moment in a long session."
        ),
    )
    show_only_restorable: BoolProperty(
        name="Only Restorable Rows",
        default=True,
        update=_uhm_scene_setting_update,
        description=(
            "Shows only rows that are meant for restore workflows. In the current design, the visible list is focused on Restore Point and Autosave rows so the browser stays easier to understand."
        ),
    )
    show_details: BoolProperty(
        name="Show Detailed Info",
        default=False,
        update=_uhm_scene_setting_update,
        description=(
            "Shows extra information for the selected row, including object, mode, frame, scene, and file path. Turn this off if you prefer a more compact interface."
        ),
    )
    crash_recovery_candidates: CollectionProperty(
        type=SFS_PG_history_crash_recovery_candidate,
        name='Crash Recovery Candidates',
        description="Crash-recovery candidates found by Smart File quick scan.",
        options={'SKIP_SAVE'},
    )
    crash_recovery_active_index: IntProperty(
        name='Active Recovery Candidate',
        default=-1,
        update=_uhm_scene_setting_update,
        options={'SKIP_SAVE'},
    )
    crash_recovery_scan_root: StringProperty(
        name='Additional Scan Root',
        subtype='DIR_PATH',
        default="",
        update=_uhm_scene_setting_update,
        description="Optional folder or file to include in the crash-recovery quick scan.",
        options={'SKIP_SAVE'},
    )
    crash_recovery_destination_dir: StringProperty(
        name='Recovery Output Folder',
        subtype='DIR_PATH',
        default="",
        update=_uhm_scene_setting_update,
        description="Optional folder for recovered files. Leave blank to use a local unsynced SmartTools recovery folder.",
        options={'SKIP_SAVE'},
    )
    crash_recovery_destination: StringProperty(
        name='Recovery Output File',
        subtype='FILE_PATH',
        default="",
        update=_uhm_scene_setting_update,
        description="Optional exact output .blend path. Existing files are never overwritten.",
        options={'SKIP_SAVE'},
    )
    crash_recovery_deep_source: StringProperty(
        name='Deep Recovery Source',
        subtype='FILE_PATH',
        default="",
        update=_uhm_scene_setting_update,
        description="Existing dump or bounded recovery fixture selected for deep recovery. The current Blender process is never scanned automatically.",
        options={'SKIP_SAVE'},
    )
    crash_recovery_live_pid: IntProperty(
        name='Other Blender PID',
        default=0,
        min=0,
        update=_uhm_scene_setting_update,
        description="Explicit other Blender process ID for live deep recovery. The current Blender process is always excluded. Use 0 when recovering from an existing dump or fixture.",
        options={'SKIP_SAVE'},
    )
    crash_recovery_step_index: IntProperty(
        name='Recovery Step Index',
        default=-1,
        min=-1,
        update=_uhm_scene_setting_update,
        description="Optional analyzed undo-step index to extract. Use -1 to let Smart File select the recommended step.",
        options={'SKIP_SAVE'},
    )
    crash_recovery_status: StringProperty(
        name='Crash Recovery Status',
        default="Ready",
        update=_uhm_scene_setting_update,
        options={'SKIP_SAVE'},
    )
    crash_recovery_progress: IntProperty(
        name='Crash Recovery Progress',
        default=0,
        min=0,
        max=100,
        update=_uhm_scene_setting_update,
        options={'SKIP_SAVE'},
    )
    crash_recovery_last_report: StringProperty(
        name='Last Recovery Report',
        subtype='FILE_PATH',
        default="",
        update=_uhm_scene_setting_update,
        options={'SKIP_SAVE'},
    )
    crash_recovery_last_error: StringProperty(
        name='Last Recovery Error',
        default="",
        update=_uhm_scene_setting_update,
        options={'SKIP_SAVE'},
    )
    crash_recovery_last_destination: StringProperty(
        name='Last Recovered File',
        subtype='FILE_PATH',
        default="",
        update=_uhm_scene_setting_update,
        options={'SKIP_SAVE'},
    )




def _uhm_setting_update(self, context):
    try:
        from .. import settings as _sfs_settings
        if hasattr(_sfs_settings, 'schedule_save'):
            _sfs_settings.schedule_save(context or getattr(bpy, 'context', None))
    except Exception:
        pass


def _uhm_history_listener_toggle_update(self, context):
    # uhm_addon_settings is a one-time migration source only.  It must never
    # control or resynchronize the live runtime after 5.75.31.
    _uhm_setting_update(self, context)


class SFS_PG_history_history_preferences(PropertyGroup):
    bl_label = 'History Preferences'
    bl_idname = (__package__.split(".props", 1)[0] if __package__ else "history_auto_save")
    bl_description = "Configure history monitoring, restore-point timing, autosave timing, storage location, and recovery safety behavior for the integrated history tools"

    enable_history_listener: BoolProperty(
        name="Legacy History Background Runtime",
        default=False,
        update=_uhm_history_listener_toggle_update,
        options={'HIDDEN'},
        description=(
            "Legacy compatibility value. Smart File now starts history background work only while Rolling Autosave or Optional Timed Restore Points require automatic timed work."
        ),
    )
    enable_restore_snapshots: BoolProperty(
        name="Enable Optional Timed Restore Points",
        default=False,
        update=_uhm_history_listener_toggle_update,
        description=(
            "Optional helper that creates restore points at a fixed minute interval. Leave this off when you want Restore Point to stay a deliberate manual checkpoint tool. Manual Restore Point creation remains available even when this timed helper is disabled."
        ),
    )
    history_restore_point_manual_primary_migrated: BoolProperty(
        name="Restore Point Manual Primary Migration Done",
        default=False,
        options={'HIDDEN'},
        update=_uhm_setting_update,
        description=(
            "Internal migration flag used once to switch older saved settings from automatic timed restore points to the new manual-restore-point-primary workflow. This is hidden and normally does not need manual editing."
        ),
    )

    history_uhm_migrated_v57531: BoolProperty(
        name="Legacy History Settings Migration Done",
        default=False,
        options={'HIDDEN'},
        update=_uhm_setting_update,
        description=(
            "Internal one-time marker. After legacy uhm_addon_settings values are copied into sf_addon_settings, Smart File never reads or synchronizes the legacy owner again."
        ),
    )

    restore_snapshot_interval_minutes: IntProperty(
        name="Timed Restore Point Interval (Minutes)",
        min=1,
        max=999,
        default=15,
        update=_uhm_history_listener_toggle_update,
        description=(
            "Time between optional timed restore points, measured in minutes. This setting is only used when Enable Optional Timed Restore Points is on, and it creates a file only after a new change has happened since the previous restore point."
        ),
    )
    restore_snapshot_max_files: IntProperty(
        name="Timed Restore Point Max Files",
        min=1,
        max=999,
        default=50,
        update=_uhm_setting_update,
        description=(
            "Maximum number of optional timed restore-point files kept for the current project. Manual restore points also use this same retention limit so important rollback files do not grow without control. This keeps rollback history useful without endless disk growth."
        ),
    )
    enable_autosave: BoolProperty(
        name="Enable Rolling Autosave",
        default=False,
        update=_uhm_history_listener_toggle_update,
        description=(
            "Creates extra timed autosave copies in a separate autosave folder. These are safety backups independent from Blender's built-in autosave. Autosaves do not replace restore points, but they are valuable emergency backups."
        ),
    )
    autosave_interval_minutes: IntProperty(
        name="Autosave Interval (Minutes)",
        min=1,
        max=999,
        default=5,
        update=_uhm_history_listener_toggle_update,
        description=(
            "Time between automatic autosave files, measured in minutes. Example: 5 means one autosave about every 5 minutes, but only after a new change has happened since the last autosave."
        ),
    )
    autosave_max_files: IntProperty(
        name="Autosave Max Files",
        min=1,
        max=999,
        default=50,
        update=_uhm_setting_update,
        description=(
            "Maximum number of autosave files kept for the current project. When the limit is exceeded, the oldest autosave files are deleted first. This is useful for controlling storage usage on large projects."
        ),
    )
    autosave_retention_scope: EnumProperty(
        name="Autosave Retention Scope",
        items=[
            ('SCENE', "Same Scene Name", "Apply Autosave Max Files only to autosaves that share the current scene or blend-file name."),
            ('GLOBAL', "All Scenes", "Apply Autosave Max Files to all Smart File autosaves in the selected history storage root."),
        ],
        default='SCENE',
        update=_uhm_setting_update,
        description=(
            "Choose whether Autosave Max Files limits only autosaves for the current scene name or the total autosave files across all scene names in the history storage folder."
        ),
    )
    autosave_skip_unchanged: BoolProperty(
        name="Skip Unchanged Autosaves",
        default=True,
        update=_uhm_history_listener_toggle_update,
        description=(
            "When enabled, Rolling Autosave does not write another .blend copy if no operation or scene update has happened since the previous autosave. Keep this on to avoid saving the same data repeatedly while the file is idle. Turn it off only when you intentionally want interval-based copies even during idle time."
        ),
    )
    history_directory: StringProperty(
        name="History Storage Folder",
        subtype='DIR_PATH',
        default="",
        update=_uhm_setting_update,
        description=(
            "Root folder where this add-on stores restore points, autosaves, safety backups, and exported JSON logs. Leave it empty to use the Smart File CONFIG storage folder."
        ),
    )
    compress_snapshots: BoolProperty(
        name="Compress Snapshot Files",
        default=False,
        update=_uhm_setting_update,
        description=(
            "Uses Blender's compressed save option when writing restore points and autosaves. This usually reduces disk space, but saving can take slightly longer."
        ),
    )
    double_click_restore: BoolProperty(
        name="Restore On Double Click",
        default=False,
        update=_uhm_setting_update,
        description=(
            "Reserved for a future input workflow. The current stable workflow is: select a row first, then press Restore Selected to open the confirmation popup."
        ),
    )
    create_safety_snapshot_before_restore: BoolProperty(
        name="Create Safety Snapshot Before Restore",
        default=True,
        update=_uhm_setting_update,
        description=(
            "Before opening an older restore point, the add-on first saves the current state as a safety backup. This is strongly recommended because it gives you a way back if you restore the wrong point."
        ),
    )
    timer_interval_seconds: IntProperty(
        name="Background Poll Interval (Seconds)",
        min=1,
        max=10,
        default=1,
        update=_uhm_history_listener_toggle_update,
        description=(
            "How often the automatic history runtime checks for new changes. Smaller numbers feel more responsive, while larger numbers slightly reduce background overhead. One second is a good default in most cases."
        ),
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        card = layout.box()
        card.label(text=_iface("Automatic Protection"), icon='TIME')
        col = card.column(align=True)
        col.label(text=_iface("Manual Restore Point is the primary rollback workflow. Optional timed restore points are a helper, not the main control."), icon='BLANK1')
        sub = col.column(align=True)
        sub.label(text=_iface("Optional Timed Restore Points"), icon='PRESET')
        sub.prop(self, "enable_restore_snapshots")
        timed = sub.column(align=True)
        timed.enabled = self.enable_restore_snapshots
        timed.prop(self, "restore_snapshot_interval_minutes")
        timed.prop(self, "restore_snapshot_max_files")
        col.separator()
        sub = col.column(align=True)
        sub.label(text=_iface("Autosaves"), icon='FILE_TICK')
        sub.prop(self, "enable_autosave")
        autosave = sub.column(align=True)
        autosave.enabled = self.enable_autosave
        autosave.prop(self, "autosave_interval_minutes")
        autosave.prop(self, "autosave_max_files")
        autosave.prop(self, "autosave_skip_unchanged")

        card = layout.box()
        card.label(text=_iface("Storage & Behavior"), icon='PREFERENCES')
        col = card.column(align=True)
        col.prop(self, "history_directory")
        col.prop(self, "compress_snapshots")
        col.prop(self, "create_safety_snapshot_before_restore")
        col.prop(self, "double_click_restore")
        col.prop(self, "timer_interval_seconds")


CLASSES = (
    UHM_HistoryEntry,
    SFS_PG_history_crash_recovery_candidate,
    UHM_SceneSettings,
    SFS_PG_history_history_preferences,
)

__all__ = ["UHM_HistoryEntry", "SFS_PG_history_crash_recovery_candidate", "UHM_SceneSettings", "SFS_PG_history_history_preferences", "CLASSES"]
