# ------------------------------------------------------------------------------
# Copyright (C) 2026 JELararagi
# ------------------------------------------------------------------------------

"""Translation seed data for integrated History Auto Save."""

BASE_PAIRS = [('History Auto Save', '履歴自動保存'),
 ('Automatic Protection', '自動保護'),
 ('Storage & Behavior', '保存先と動作'),
 ('History List', 'ヒストリー一覧'),
 ('History Summary', '履歴概要'),
 ('Quick Actions', 'クイック操作'),
 ('Selected Row', '選択中の行'),
 ('Tips', 'ヒント'),
 ('Legacy History Background Runtime', 'ヒストリー監視を有効化'),
 ('Enable Timed Restore Snapshots', '定期復元スナップショットを有効化'),
 ('Restore Snapshot Interval (Minutes)', '復元スナップショット間隔（分）'),
 ('Restore Snapshot Max Files', '復元スナップショット最大保存数'),
 ('Timed Restore Point Max Files', '復元ポイント最大保存数'),
 ('Enable Rolling Autosave', 'ローリング自動保存を有効化'),
 ('Autosave Interval (Minutes)', '自動保存間隔（分）'),
 ('Autosave Max Files', '自動保存最大保存数'),
 ('History Storage Folder', 'ヒストリー保存フォルダー'),
 ('Compress Snapshot Files', 'スナップショットを圧縮'),
 ('Restore On Double Click', 'ダブルクリックで復元'),
 ('Create Safety Snapshot Before Restore', '復元前に安全スナップショットを作成'),
 ('Background Poll Interval (Seconds)', 'バックグラウンド監視間隔（秒）'),
 ('Quick Note / Checkpoint Name', 'クイックメモ / チェックポイント名'),
 ('Search History', 'ヒストリー検索'),
 ('Only Restorable Rows', '復元可能な行のみ'),
 ('Show Detailed Info', '詳細情報を表示'),
 ('History Entries', 'ヒストリー項目'),
 ('Active Entry', '選択中の項目'),
 ('Project Key', 'プロジェクトキー'),
 ('UID', 'UID'),
 ('Label', 'ラベル'),
 ('Details', '詳細'),
 ('Type', '種類'),
 ('Time', '日時'),
 ('Object', 'オブジェクト'),
 ('Mode', 'モード'),
 ('Scene', 'シーン'),
 ('Frame', 'フレーム'),
 ('Selected Count', '選択数'),
 ('Attached File', '関連ファイル'),
 ('Restorable', '復元可能'),
 ('Nearest Restore Index', '最寄り復元インデックス'),
 ('Storage Folder', '保存フォルダー'),
 ('Restore Target', '復元先'),
 ('Restore From', '復元元'),
 ('Actual File Used', '実際に開くファイル'),
 ('Direct snapshot', 'この行のスナップショット'),
 ('Ready', '準備完了'),
 ('No history yet', 'まだヒストリーがありません'),
 ('No restore points or autosaves yet', 'まだ復元ポイントまたは自動保存がありません'),
 ('Listen', '監視'),
 ('Restore', '復元'),
 ('Autosave', '自動保存'),
 ('Point', 'ポイント'),
 ('Save', '保存'),
 ('Folder', 'フォルダー'),
 ('Scroll the list to browse older snapshots.', '古いスナップショットを見るには一覧をスクロールしてください。'),
 ('Only restore points and autosaves are listed.', '一覧には復元ポイントと自動保存のみが表示されます。'),
 ('Click a row to select it, then use Restore Selected.', '行をクリックして選択し、そのあと『選択中の行へ復元』を使ってください。'),
 ('Restore always asks for confirmation before opening an older file.', '古いファイルを開く前には、必ず確認ポップアップが表示されます。'),
 ('Watching changes', '変更監視中'),
 ('Watching user edits', 'ユーザー操作による変更を監視中'),
 ('Watching user edits; unchanged autosave skipped', 'ユーザー操作による変更を監視中です。未変更のため自動保存をスキップしました。'),
 ('Automatic history backup is disabled', '自動の履歴保存は無効です'),
 ('Restore Point', '復元ポイント'),
 ('Manual Restore Point', '手動復元ポイント'),
 ('Quick autosave', 'クイック自動保存'),
 ('Create Restore Point Now', '今すぐ復元ポイントを作成'),
 ('Create Autosave Now', '今すぐ自動保存を作成'),
 ('Restore Selected Row', '選択中の行へ復元'),
 ('History Row Click', 'ヒストリー行を選択'),
 ('Delete Selected Row', '選択中の行を削除'),
 ('Delete Attached File Too', '関連ファイルも削除'),
 ('Clear All History', 'ヒストリーをすべて削除'),
 ('Delete Stored Files Too', '保存済みファイルも削除'),
 ('Open Storage Folder', '保存フォルダーを開く'),
 ('Export History Log', 'ヒストリーログを書き出し'),
 ('Internal identifier used by the add-on to distinguish one history row from another. This is mainly technical data '
  'and usually does not need to be edited manually.',
  'アドオンが各ヒストリー行を区別するために使う内部識別子です。主に技術的な管理用データで、通常は手動で編集する必要はありません。'),
 ('Main title shown in the history list. Good labels help you understand at a glance what kind of restore point or '
  'autosave this row represents.',
  'ヒストリー一覧に表示される主なタイトルです。分かりやすい名前を付けると、その行がどんな復元ポイントや自動保存なのかを一目で把握しやすくなります。'),
 ('Additional explanation stored for this row. It can contain context such as why the snapshot was created, whether it '
  'was manual or automatic, and what happened around that time.',
  'その行に付随する補足説明です。なぜこのスナップショットが作られたか、手動か自動か、その時に何をしていたかなどの文脈を記録できます。'),
 ('The row category. In this add-on the visible list is mainly made of Restore Point rows and Autosave rows.',
  '行の種類です。このアドオンでは、主に『復元ポイント』と『自動保存』の行が一覧に表示されます。'),
 ('Date and time when this history row was recorded. Use this to understand the order of saved states during a work '
  'session.',
  'このヒストリー行が記録された日時です。作業中にどの順番で状態が保存されたかを把握するのに役立ちます。'),
 ('Name of the active object when this row was recorded. This helps you remember what you were working on when the '
  'snapshot or autosave was created.',
  'この行が記録された時点でアクティブだったオブジェクト名です。どの対象を作業していた時に保存されたのかを思い出しやすくなります。'),
 ('The Blender interaction mode that was active when this row was recorded, such as Object Mode or Edit Mode.',
  'この行が記録された時点の Blender の作業モードです。オブジェクトモードや編集モードなど、どの状態で保存されたかが分かります。'),
 ('Scene name at the moment this row was stored. This is useful when one blend file contains multiple scenes.',
  'この行が保存された時点のシーン名です。1つの blend ファイルに複数のシーンがある場合に特に役立ちます。'),
 ('Current frame number when the row was recorded. This is especially helpful in animation or timeline-based '
  'workflows.',
  'この行が記録された時点のフレーム番号です。アニメーションやタイムラインを使う作業で特に有効です。'),
 ('Number of selected objects when this row was recorded. This can help you understand the editing context for that '
  'saved point.',
  'この行が記録された時点の選択オブジェクト数です。その保存地点でどんな編集状況だったかを把握しやすくなります。'),
 ('Full path to the actual .blend file linked to this row. Restoring the row opens this file or uses it as the nearest '
  'valid fallback.',
  'この行に対応する実際の .blend ファイルのフルパスです。復元時にはこのファイルを開くか、近い有効な代替ファイルとして利用します。'),
 ('Shows whether this row has a directly usable file that can be opened for restore. If this is off, the add-on may '
  'use the nearest earlier restore point instead.',
  'この行に直接復元できるファイルがあるかを示します。OFF の場合は、この行の代わりにそれ以前の最も近い復元ポイントを使うことがあります。'),
 ('Internal fallback link to the nearest earlier restore point. This is used when a row itself does not have a '
  'directly restorable file.',
  'その行より前にある最も近い復元ポイントへの内部リンクです。行自体に直接復元できるファイルがない場合に使われます。'),
 ('All history rows tracked for the current scene during this session, including restore points and autosaves shown in '
  'the browser.',
  '現在のセッション中にこのシーンで追跡しているヒストリー行すべてです。ブラウザーに表示される復元ポイントや自動保存も含まれます。'),
 ('Currently selected history row in the browser. The Restore Selected button works on this row.',
  'ヒストリーブラウザーで現在選択されている行です。『選択中の行へ復元』ボタンはこの行に対して動作します。'),
 ('Internal project identifier used to keep the current blend file linked to the correct restore-point and autosave '
  'folders.',
  '現在の blend ファイルを正しい復元ポイントフォルダーや自動保存フォルダーに結び付けるための内部プロジェクト識別子です。'),
 ("Name used for the next manual restore point. Choose clear beginner-friendly names such as 'Before UV cleanup', "
  "'Before Boolean test', or 'Before rig export' so older saved states stay easy to recognize later.",
  '次に作る手動復元ポイントの名前です。『UV整理前』『ブーリアンテスト前』『リグ書き出し前』など、初心者でも分かりやすい名前にしておくと、あとから古い状態を見分けやすくなります。'),
 ('Filters the history browser by text. The search checks labels, details, timestamps, object names, scenes, and row '
  'types, which makes it easier to find one important moment in a long session.',
  '文字列でヒストリーブラウザーを絞り込みます。ラベル、詳細、日時、オブジェクト名、シーン名、行の種類を検索するため、長い作業履歴の中から必要な地点を見つけやすくなります。'),
 ('Shows only rows that are meant for restore workflows. In the current design, the visible list is focused on Restore '
  'Point and Autosave rows so the browser stays easier to understand.',
  '復元に使うための行だけを表示します。現在の設計では、一覧が分かりやすいように『復元ポイント』と『自動保存』を中心に表示します。'),
 ('Shows extra information for the selected row, including object, mode, frame, scene, and file path. Turn this off if '
  'you prefer a more compact interface.',
  '選択中の行について、オブジェクト、モード、フレーム、シーン、ファイルパスなどの追加情報を表示します。よりコンパクトな表示がよい場合は OFF にしてください。'),
 ('Turns on the automatic history runtime that watches the current Blender file and updates the history system. It watches '
  'selection changes, mode changes, undo or redo activity, and scene data updates. Keep this enabled for normal use.',
  '現在の Blender ファイルを監視してヒストリーシステムを更新するバックグラウンド監視を有効にします。選択変更、モード変更、Undo/Redo、シーンデータ更新を監視します。通常は ON のまま使ってください。'),
 ('Creates real .blend restore points at a fixed minute interval. These files are the main rollback points used when '
  'you want to return to an older safe state. This is the safest restore method, but it writes extra files to disk.',
  '指定した分間隔で実体のある .blend 復元ポイントを作成します。過去の安全な状態へ戻りたいときに使う主要な巻き戻し地点です。最も安全な方法ですが、追加ファイルをディスクへ保存します。'),
 ('Time between automatic restore snapshots, measured in minutes. Example: 5 means the add-on creates one new restore '
  'point about every 5 minutes, but only after there has been a new change since the last restore point.',
  '自動復元スナップショットを作る間隔を分単位で指定します。たとえば 5 の場合、前回の復元ポイント以降に新しい変更があったときだけ、約 5 分ごとに新しい復元ポイントを作成します。'),
 ('Maximum number of restore-point files kept for the current project. When the limit is exceeded, the oldest '
  'restore-point files are deleted first. This keeps rollback history useful without endless disk growth.',
  '現在のプロジェクトで保持する復元ポイントファイルの最大数です。上限を超えると古い復元ポイントから順に削除されます。履歴を保ちながらディスク容量の増えすぎを防げます。'),
 ('Creates extra timed autosave copies in a separate autosave folder. These are safety backups independent from '
  "Blender's built-in autosave. Autosaves do not replace restore points, but they are valuable emergency backups.",
  '専用の autosave フォルダーに、追加の自動保存コピーを定期的に作成します。これは Blender 標準の自動保存とは別の安全バックアップです。復元ポイントの代わりではありませんが、緊急用の退避として役立ちます。'),
 ('Time between automatic autosave files, measured in minutes. Example: 5 means one autosave about every 5 minutes, '
  'but only after a new change has happened since the last autosave.',
  '自動保存ファイルを作る間隔を分単位で指定します。たとえば 5 の場合、前回の自動保存以降に新しい変更があったときだけ、約 5 分ごとに 1 本作成します。'),
 ('Maximum number of autosave files kept for the current project. When the limit is exceeded, the oldest autosave '
  'files are deleted first. This is useful for controlling storage usage on large projects.',
  '現在のプロジェクトで保持する自動保存ファイルの最大数です。上限を超えると古い自動保存から順に削除されます。大きなプロジェクトでも保存容量を管理しやすくなります。'),
 ('Root folder where this add-on stores restore points, autosaves, safety backups, and exported JSON logs. Leave it '
  "empty to use the default folder inside Blender's user configuration directory.",
  'このアドオンが復元ポイント、自動保存、安全バックアップ、JSON ログを保存するルートフォルダーです。空欄にすると Blender ユーザー設定フォルダー内の既定場所を使用します。'),
 ("Uses Blender's compressed save option when writing restore points and autosaves. This usually reduces disk space, "
  'but saving can take slightly longer.',
  '復元ポイントや自動保存を書き出すときに Blender の圧縮保存を使います。通常は容量を減らせますが、保存時間は少し長くなることがあります。'),
 ('Reserved for a future input workflow. The current stable workflow is: select a row first, then press Restore '
  'Selected to open the confirmation popup.',
  '将来の入力操作向けに予約されている項目です。現在の安定した使い方は、先に行を選択し、そのあと『選択中の行へ復元』を押して確認ポップアップを開く方法です。'),
 ('Before opening an older restore point, the add-on first saves the current state as a safety backup. This is '
  'strongly recommended because it gives you a way back if you restore the wrong point.',
  '古い復元ポイントを開く前に、現在の状態を安全バックアップとして先に保存します。間違った地点へ復元してしまっても戻りやすくなるため、強く推奨されます。'),
 ('How often the automatic history runtime checks for new changes. Smaller numbers feel more responsive, while larger '
  'numbers slightly reduce background overhead. One second is a good default in most cases.',
  'バックグラウンド監視が新しい変更を確認する頻度です。数値が小さいほど反応は速くなり、大きいほど背景負荷は少し下がります。多くの場面では 1 秒が良い初期値です。'),
 ('Immediately saves a manual restore snapshot using the current checkpoint name. Use this before risky edits, large '
  'imports, destructive modifiers, or big cleanup operations when you want a guaranteed return point.',
  '現在のチェックポイント名を使って、手動の復元スナップショットをただちに保存します。危険な編集、大きな読み込み、破壊的モディファイア、広範囲の整理作業の前に、確実な戻り先を作りたいときに使ってください。'),
 ('Immediately writes one autosave file to the rolling autosave set. This is useful when you want an extra safety '
  'backup right now without waiting for the next timer.',
  'ローリング自動保存セットへ、自動保存ファイルを今すぐ 1 本書き出します。次のタイマーを待たずに、追加の安全バックアップをすぐ作りたいときに便利です。'),
 ('Opens a confirmation popup before restoring with the selected row. If that row has no direct restore file, the '
  'add-on automatically falls back to the nearest earlier restore point that still exists.',
  '選択中の行で復元する前に確認ポップアップを開きます。その行に直接の復元ファイルがない場合は、存在している最も近い以前の復元ポイントへ自動でフォールバックします。'),
 ('Selects the clicked row without restoring. Use this when you only want to inspect the row details before deciding '
  'whether to restore.',
  '復元はせず、クリックした行を選択だけします。復元するか決める前に、その行の詳細を確認したいときに使います。'),
 ('Deletes the selected history row. You can also choose to delete its attached restore or autosave file from disk '
  'when that file exists.',
  '選択中のヒストリー行を削除します。必要に応じて、その行に関連付いた復元ファイルや自動保存ファイルもディスクから削除できます。'),
 ('If enabled, deleting the selected row also tries to delete the restore or autosave file attached to that row from '
  'disk. Use this when you want to clean storage as well as the visible list.',
  'ON にすると、選択中の行を削除する際に、その行に関連付いた復元ファイルや自動保存ファイルもディスクから削除しようとします。一覧だけでなく保存領域も整理したいときに使います。'),
 ('Removes all rows from the current scene history. You can also choose to delete the stored restore, autosave, and '
  'safety files created by this add-on for the current project.',
  '現在のシーンのヒストリー行をすべて削除します。必要に応じて、このアドオンが現在のプロジェクト用に作った復元ポイント、自動保存、安全バックアップもまとめて削除できます。'),
 ('If enabled, clearing history also deletes the restore-point files, autosave files, safety backups, and exported '
  'logs created by this add-on for the current project folder.',
  'ON にすると、ヒストリーを消去する際に、このアドオンが現在のプロジェクトフォルダー内に作成した復元ポイント、自動保存、安全バックアップ、書き出しログも一緒に削除します。'),
 ('Opens the project storage folder used by this add-on for restore points, autosaves, safety backups, and exported '
  'logs.',
  'このアドオンが復元ポイント、自動保存、安全バックアップ、書き出しログの保存に使っているプロジェクト用フォルダーを開きます。'),
 ('Exports the current scene history as a JSON file. This is useful for reviewing your work timeline, debugging, '
  'sharing reports, or keeping an external archive of important sessions.',
  '現在のシーンのヒストリーを JSON ファイルとして書き出します。作業履歴の確認、デバッグ、レポート共有、重要セッションの外部保管に便利です。'),
 ('No selected history row.', '選択中のヒストリー行がありません。'),
 ('The current file state may be replaced by an older snapshot.', '現在のファイル状態は、古いスナップショットに置き換わる可能性があります。'),
 ('Created restore point.', '復元ポイントを作成しました。'),
 ('Restore point could not be created right now.', '現在は復元ポイントを作成できませんでした。'),
 ('Created autosave.', '自動保存を作成しました。'),
 ('Autosave could not be created right now.', '現在は自動保存を作成できませんでした。'),
 ('History row was deleted.', 'ヒストリー行を削除しました。'),
 ('History was cleared.', 'ヒストリーを消去しました。'),
 ('Opened storage folder.', '保存フォルダーを開きました。'),
 ('Restorable row', '復元可能な行'),
 ('Log only row', 'ログのみの行'),
 ('(unnamed)', '（名称未設定）'),
 ('History exported', '履歴を書き出しました'),
 ('Manual restore point created.', '手動復元ポイントを作成しました。'),
 ('Manual autosave created immediately.', '手動自動保存をただちに作成しました。'),
 ('N-panel State Save', 'Nパネル状態保存'),
 ('Max Files Scope', '最大ファイル数の対象'),
 ('Same Scene Name', '同じシーン名'),
 ('All Scenes', '全シーン総合'),
 ('Register History Folder', '履歴フォルダーを登録'),
 ('History folder registered.', '履歴フォルダーを登録しました。'),
 ('Autosave Retention Scope', '自動保存保持対象'),
]

EXTRA_UI_TRANSLATIONS = {('*', 'Smart File'): 'Smart File',
 ('*', 'History Snapshot Protection'): '履歴スナップショット保護',
 ('*', 'History Browser'): '履歴ブラウザー',
 ('*', 'History'): '履歴',
 ('*', 'History Popup'): '履歴ポップアップ',
 ('*', 'Selected Snapshot'): '選択中のスナップショット',
 ('*', 'Protect work with timed restore points, rolling autosaves, and safety backups before restoring older files.'): '定期復元ポイント、ローリング自動保存、復元前の安全バックアップで作業を保護します。',
 ('*', 'Use manual restore points before destructive edits, exports, imports, or large cleanup passes. Autosave adds extra safety between those checkpoints.'): '破壊的な編集、書き出し、読み込み、大規模な整理の前には手動復元ポイントを使ってください。自動保存はそのチェックポイントの間を追加で保護します。',
 ('*', 'Newest snapshots are shown first so the latest safe return point is easier to find.'): '最新のスナップショットを先頭に表示し、直近の安全な戻り先を見つけやすくしています。',
 ('*', 'Name the next manual restore point clearly so later rollback choices stay easy to understand.'): 'あとで戻り先を選びやすいよう、次の手動復元ポイントには分かりやすい名前を付けてください。',
 ('*', 'Checkpoint'): 'チェックポイント',
 ('*', 'Create Restore Point'): '復元ポイントを作成',
 ('*', 'Create Autosave'): '自動保存を作成',
 ('*', 'Open Project Storage Folder'): 'プロジェクト保存フォルダーを開く',
 ('*', 'Direct snapshot'): '直接のスナップショット',
 ('*', 'Nearest earlier restore point'): '最も近い以前の復元ポイント',
 ('*', 'Timed Restore Snapshots'): '定期復元スナップショット',
 ('*', 'Rolling Autosave'): 'ローリング自動保存',
 ('*', 'Interval'): '間隔',
 ('*', 'Max Files'): '最大ファイル数',
 ('*', 'Project Storage Folder'): 'プロジェクト保存フォルダー',
 ('*', 'Only restore points and autosaves are listed so the browser stays easy to read.'): '一覧を見やすく保つため、復元ポイントと自動保存のみを表示します。',
 ('*', 'Select a row first, review its details, then use Restore Selected when you are confident.'): 'まず行を選択し、詳細を確認してから、問題なければ『選択中の行へ復元』を使ってください。',
 ('*', 'Restore always asks for confirmation before opening an older file, and it can create a safety backup first.'): '古いファイルを開く前には必ず確認が入り、必要に応じて先に安全バックアップも作成できます。',
 ('*', 'Restorable Only'): '復元可能のみ',
 ('*', 'Visible'): '表示数',
 ('*', 'Listen'): '監視',
 ('*', 'Restore'): '復元',
 ('*', 'Autosave'): '自動保存',
 ('*', 'Preferences unavailable'): '設定を取得できません。',
 ('*', 'Time'): '時刻',
 ('*', 'Type'): '種類',
 ('*', 'Object'): 'オブジェクト',
 ('*', 'Mode'): 'モード',
 ('*', 'Frame'): 'フレーム',
 ('*', 'Scene'): 'シーン',
 ('*', 'Restore Target'): '復元先',
 ('*', 'Attached File'): '関連ファイル',
 ('*', 'Ready'): '準備完了',
 ('*', 'No history yet'): 'まだ履歴がありません。',
 ('*', 'No restore points or autosaves yet.'): 'まだ復元ポイントまたは自動保存がありません。',
 ('*', 'History tools and restore controls for the current project, including restore points, autosaves, and storage actions.'): '現在のプロジェクトに対する履歴ツールと復元操作です。復元ポイント、自動保存、保存先操作を含みます。',
 ('*', 'Review restore points and autosaves in time order, then choose the safest point to go back to when something breaks.'): '復元ポイントと自動保存を時系列で確認し、問題が起きたときに戻る最も安全な地点を選びます。',
 ('*', 'Create new restore points or autosaves before risky changes so you always have a clear place to return to.'): '危険な変更の前に新しい復元ポイントや自動保存を作成し、いつでも明確な戻り先を持てるようにします。',
 ('*', 'Inspect the currently selected snapshot in detail before restoring, including object, mode, frame, and file path information.'): '現在選択中のスナップショットを復元前に詳しく確認します。オブジェクト、モード、フレーム、ファイルパス情報を含みます。',
 ('*', 'Adjust automatic restore-point and autosave timing so the add-on matches the speed and risk level of your workflow.'): '自動復元ポイントと自動保存の間隔を調整し、作業速度やリスクに合った保護設定にします。',
 ('*', 'Configure where history files are stored and how restore safety options behave for the current project.'): '履歴ファイルの保存場所と、現在のプロジェクトでの復元安全オプションの動作を設定します。',
 ('*', 'Read short beginner-friendly tips about how to use restore points, autosaves, and safe recovery workflows.'): '復元ポイント、自動保存、安全な復旧ワークフローの使い方を初心者向けに短く確認します。',
 ('*', 'Configure launcher behavior, library roots, workspace profiles, history protection, and other Smart File defaults used across the add-on'): 'ランチャーの動作、ライブラリルート、ワークスペースプロファイル、履歴保護など、アドオン全体で使う '
                                                                                                                                                          'Smart '
                                                                                                                                                          'File '
                                                                                                                                                          'Toolset '
                                                                                                                                                          'の基本設定を調整します。',
 ('*', 'Review the latest automatic relink notice, missing libraries, and quick recovery actions from one compact menu'): '最新の自動再リンク通知、不足ライブラリ、素早い復旧操作を1つのコンパクトなメニューで確認します。',
 ('*', 'Show recently used source .blend files so you can reopen a known source without browsing folders again'): '最近使ったソース '
                                                                                                                  '.blend '
                                                                                                                  'を表示し、フォルダーを探し直さずに既知のソースを再オープンできるようにします。',
 ('*', 'Show favorite source .blend files that you want to reuse often across importing, relinking, and publishing tasks'): '読み込み、再リンク、公開でよく再利用するお気に入りのソース '
                                                                                                                            '.blend '
                                                                                                                            'を表示します。',
 ('*', 'Open the compact Smart File launcher from the 3D View header and jump to import, library, relink, publish, thumbnail, or history tools'): '3Dビューのヘッダーからコンパクトな '
                                                                                                                                                        'Smart '
                                                                                                                                                        'File '
                                                                                                                                                        'Toolset '
                                                                                                                                                        'ランチャーを開き、読み込み・ライブラリ・再リンク・公開・サムネイル・履歴ツールへ移動します。',
 ('*', "Open the main Smart File menu from Blender's File menu when you want a compact list of the major tools"): '主要ツールをコンパクトに並べた一覧が欲しいときに、Blender '
                                                                                                                        'のファイルメニューから '
                                                                                                                        'Smart '
                                                                                                                        'File '
                                                                                                                        'Toolset '
                                                                                                                        'のメインメニューを開きます。'}


EXTRA_UI_TRANSLATIONS.update({
    ('*', 'Refresh'): '更新',
    ('*', 'Listener'): 'リスナー',
    ('*', 'Restore Points'): '復元ポイント',
    ('*', 'Autosaves'): '自動保存',
    ('*', 'Startup / Monitoring'): '起動 / 監視',
    ('*', 'Legacy History Background Runtime'): '履歴バックグラウンド処理を有効化',
    ('*', 'Enable Timed Restore Snapshots'): '定期復元ポイントを有効化',
    ('*', 'Enable Rolling Autosave'): 'ローリング自動保存を有効化',
    ('*', 'When enabled, the history system starts with Blender and watches file, undo, redo, selection, and scene update events.'): 'ON にすると、履歴システムが Blender と一緒に起動し、ファイル、取り消し、やり直し、選択、シーン更新の変化を監視します。',
    ('*', 'Storage Folder'): '保存フォルダー',
    ('*', 'Manual Storage Folder'): '手動保存フォルダー',
    ('*', 'Leave the folder blank to store generated history files inside the Smart File CONFIG storage folder.'): '空欄のままにすると、生成される履歴ファイルは Smart File の CONFIG 保存領域内に保存されます。',
    ('*', 'Use Default Folder'): '既定フォルダーを使用',
    ('*', 'Current Project Storage'): '現在のプロジェクト保存先',
    ('*', 'Restore Safety'): '復元安全設定',
    ('*', 'Save Preferences'): 'プリファレンスを保存',
    ('*', 'Refresh History Runtime'): '履歴ランタイムを更新',
    ('*', 'Use Default Storage Folder'): '既定の保存フォルダーを使用',
    ('*', 'Using default storage folder.'): '既定の保存フォルダーを使用します。',
    ('*', 'Automatic history backup is disabled'): '自動の履歴保存は無効です。',
    ('*', 'Preparing the first restore point for this opened file'): '開いたファイル用の最初の復元ポイントを準備しています。',
    ('*', 'Watching changes'): '変更を監視中です。',

    ('*', 'History Summary'): '履歴概要',
    ('*', 'Saved Plans'): '保存済み計画',
    ('*', 'Project Safety'): 'プロジェクト安全確認',
    ('*', 'Run Fix'): '修正を実行',
    ('*', 'Shot States'): 'ショット状態',
    ('*', 'Watching user edits'): 'ユーザー操作による変更を監視中です。',
    ('*', 'Watching user edits; unchanged autosave skipped'): 'ユーザー操作による変更を監視中です。未変更のため自動保存をスキップしました。',
    ('*', 'Refreshes automatic history backup state, reapplies the current N-panel startup setting, and checks existing restore files on disk. Use this after changing Autosave, Optional Timed Restore Points, or the storage folder.'): '履歴バックグラウンド処理を更新し、現在の N パネルの起動設定を再適用して、ディスク上の既存復元ファイルを確認します。自動保存、任意の定期復元ポイント、または保存フォルダーを変更した後に使います。',
    ('*', 'Clears the manual history storage folder so generated restore points, autosaves, safety backups, and logs are stored inside the Smart File CONFIG storage folder again.'): '手動指定した履歴保存フォルダーを解除し、生成される復元ポイント、自動保存、安全バックアップ、ログを Smart File の CONFIG 保存領域内に戻します。',
})

EXTRA_UI_TRANSLATIONS.update({
    ('*', 'Enable Optional Timed Restore Points'): '任意の定期復元ポイントを有効化',
    ('*', 'Timed Restore Point Interval (Minutes)'): '定期復元ポイント間隔（分）',
    ('*', 'Timed Restore Point Max Files'): '復元ポイント最大保存数',
    ('*', 'Skip Unchanged Autosaves'): '未変更の自動保存をスキップ',
    ('*', 'Manual Restore Point is the primary rollback workflow. Optional timed restore points are a helper, not the main control.'): '手動復元ポイントを主な戻り先作成ワークフローとして使います。定期復元ポイントは補助機能です。',
    ('*', 'Manual Restore Point is the primary rollback workflow; Autosave remains the rolling safety net.'): '手動復元ポイントを主な戻り先として使い、自動保存は世代管理の安全網として残します。',
    ('*', 'Create a restore point by hand before risky edits. Autosave protects the gaps and can skip idle intervals when nothing changed.'): '危険な編集の前には手動で復元ポイントを作成してください。自動保存はその間を保護し、未変更の待機時間はスキップできます。',
    ('*', 'Create Manual Restore Point'): '手動復元ポイントを作成',
    ('*', 'Manual Restore Point'): '手動復元ポイント',
    ('*', 'Autosave Utility'): '自動保存ユーティリティ',
    ('*', 'Autosave normally runs in the background. Use this only when you want an extra rolling backup immediately.'): '自動保存は通常バックグラウンドで動作します。追加の世代管理バックアップを今すぐ作りたい場合だけ使います。',
    ('*', 'Rolling Autosave can stay automatic; timed Restore Points are optional because manual checkpoints are the recommended primary workflow.'): '履歴バックグラウンド処理と自動保存は自動のまま使えます。復元ポイントは手動チェックポイントを主役にするため、定期作成は任意です。',
    ('*', 'Optional Timed Restore Points'): '任意の定期復元ポイント',
    ('*', 'Enable Optional Timed Restore'): '任意の定期復元を有効化',
    ('*', 'Manual Restore Point is the main rollback checkpoint. Create one before destructive work.'): '手動復元ポイントが主な戻り先チェックポイントです。破壊的な作業の前に作成してください。',
    ('*', 'Autosave is the rolling safety net. With Skip Unchanged Autosaves enabled, idle intervals do not create duplicate files.'): '自動保存は世代管理の安全網です。未変更の自動保存をスキップすると、待機中に重複ファイルを作成しません。',
    ('*', 'Watching changes; unchanged autosave skipped'): '変更監視中です。未変更のため自動保存をスキップしました。',
    ('*', 'Manual Restore Point is the primary rollback workflow; Autosave remains the rolling safety net.'): '手動復元ポイントを主な戻り先として使い、自動保存は世代管理の安全網として残します。',
    ('*', 'Create a manual Restore Point before destructive edits, exports, imports, or large cleanup passes.'): '破壊的な編集、書き出し、読み込み、大規模な整理の前には手動復元ポイントを作成してください。',
    ('*', 'Autosave keeps emergency backups between manual checkpoints and can skip idle intervals so unchanged data is not saved repeatedly.'): '自動保存は手動チェックポイントの間を緊急バックアップで補完し、待機中は未変更データの重複保存をスキップできます。',
})

# Proposal-aligned history labels.
BASE_PAIRS.extend(
[('Refresh Runtime', 'ランタイムを更新'),
 ('Use Default Storage Folder', '既定保存フォルダーを使用'),
 ('Create Restore Point Now', '復元ポイントを今すぐ作成'),
 ('Create Autosave Now', '自動保存を今すぐ作成'),
 ('Restore Selected Row', '選択行を復元'),
 ('Row Click', '行を選択'),
 ('Delete Selected Row', '選択行を削除'),
 ('Clear All', 'すべてクリア'),
 ('Open Storage Folder', '保存フォルダーを開く'),
 ('Export Log', 'ログを書き出し'),
 ('History Preferences', 'ヒストリー設定'),
 ('History Snapshot Protection', '履歴スナップショット保護'),
 ('History Browser', '履歴ブラウザー'),
 ('History Quick Actions', '履歴 クイック操作'),
 ('History Selected Snapshot', '履歴 選択中のスナップショット'),
 ('History Automatic Protection', '履歴 自動保護'),
 ('History Storage & Behavior', '履歴 保存と動作'),
 ('History Tips', '履歴 ヒント'),
 ('Open', '開く')]
)

BASE_PAIRS.extend([
 ('Watching file changes', 'ファイルの変更を監視中です'),
 ('runtime is not active', 'ランタイムは動作していません'),
])

EXTRA_UI_TRANSLATIONS.update({
    ('*', "Creates extra timed autosave copies in a separate autosave folder. These are safety backups independent from Blender's built-in autosave. Autosaves do not replace restore points, but they are valuable emergency backups."): '一定時間ごとに追加の .blend コピーを専用の自動保存フォルダーへ作成します。Blender 標準の自動保存とは独立した安全バックアップです。復元ポイントの代わりにはなりませんが、緊急時の復旧に役立ちます。',
    ('*', 'Time between automatic autosave files, measured in minutes. Example: 5 means one autosave about every 5 minutes, but only after a new change has happened since the last autosave.'): '自動保存ファイルを作成する間隔を分単位で指定します。たとえば5なら約5分ごとですが、前回の自動保存後に新しい変更があった場合だけ保存します。',
    ('*', 'Maximum number of autosave files kept for the current project. When the limit is exceeded, the oldest autosave files are deleted first. This is useful for controlling storage usage on large projects.'): '現在のプロジェクトで保持する自動保存ファイルの最大数です。上限を超えると古い自動保存から削除されるため、大規模プロジェクトの保存容量を管理できます。',
    ('*', 'Choose whether Autosave Max Files limits only autosaves for the current scene name or the total autosave files across all scene names in the history storage folder.'): '自動保存の最大保持数を、現在のシーン名と同じ自動保存だけに適用するか、履歴保存フォルダー内の全シーン名へ適用するかを選びます。',
    ('*', 'Apply Autosave Max Files only to autosaves that share the current scene or blend-file name.'): '現在のシーン名または .blend ファイル名を共有する自動保存だけに最大保持数を適用します。',
    ('*', 'Apply Autosave Max Files to all Smart File autosaves in the selected history storage root.'): '選択した履歴保存ルート内にある Smart File の全自動保存へ最大保持数を適用します。',
    ('*', 'When enabled, Rolling Autosave does not write another .blend copy if no operation or scene update has happened since the previous autosave. Keep this on to avoid saving the same data repeatedly while the file is idle. Turn it off only when you intentionally want interval-based copies even during idle time.'): 'ON にすると、前回の自動保存後に操作やシーン更新がなければ新しい .blend コピーを作りません。待機中に同じデータを繰り返し保存しないため、通常はONのまま使用してください。変更がなくても一定間隔でコピーしたい場合だけOFFにします。',
    ('*', 'Autosave runs automatically only while Rolling Autosave or Optional Timed Restore Points require it; manual Restore Point remains the primary rollback workflow.'): 'ローリング自動保存または任意の定期復元ポイントが必要な間だけ、自動処理が動作します。主な戻り先は手動復元ポイントです。',
    ('*', 'Immediately writes one autosave file to the rolling autosave set. This is useful when you want an extra safety backup right now without waiting for the next timer.'): '次のタイマーを待たず、世代管理される自動保存へ1つのファイルを直ちに追加します。今すぐ追加の安全バックアップが必要な場合に使用します。',
    ('*', 'Rolling Autosave starts disabled on a fresh installation. When N-panel State Save is enabled, an explicit OFF or ON choice is restored when Blender starts again.'): '新規インストールではローリング自動保存はOFFで開始します。Nパネル状態保存が有効な場合、明示的に選んだOFFまたはONはBlenderの次回起動時に復元されます。',
    ('*', 'If an autosave write fails, Smart File keeps the unsaved change pending and retries naturally after the storage path becomes writable again.'): '自動保存の書き込みに失敗した場合、Smart File は未保存の変更を保留したまま維持し、保存先が再び書き込み可能になると自然に再試行します。',
})

EXTRA_UI_TRANSLATIONS.update({
    ('*', 'Refresh Blender List'): 'Blender の一覧を更新',
    ('*', 'List the other Blender windows running on this computer, including crashed ones'): 'このコンピューターで動いているほかの Blender（クラッシュしたものを含む）を一覧にします',
    ('*', 'Recover Selected Target'): '選んだ対象を復旧',
    ('*', 'Recover the selected Blender or file into a new .blend and open it in this Blender'): '選んだ Blender またはファイルを新しい .blend へ復旧し、この Blender で開きます',
    ('*', 'Find Recovery Points'): '復旧ポイントを探す',
    ('*', 'Read the memory of the selected Blender and list the states it can be recovered to'): '選んだ Blender のメモリを読み、復旧できる状態を一覧にします',
    ('*', 'Recover This Point'): 'このポイントを復旧',
    ('*', 'Recover this state into a new .blend and open it in this Blender'): 'この状態を新しい .blend へ復旧し、この Blender で開きます',
    ('*', 'Find Saved Files'): '保存済みファイルを探す',
    ('*', 'List the autosaves, backup files and quit.blend files that can be recovered'): '復旧に使える自動保存・バックアップ・quit.blend を一覧にします',
    ('*', 'Read Dump File'): 'ダンプファイルを読む',
    ('*', 'Read an existing Blender memory dump file and list the states it can be recovered to'): '既存の Blender のメモリダンプファイルを読み、復旧できる状態を一覧にします',
    ('*', 'Cancel Crash Recovery'): 'クラッシュ復旧を中止',
    ('*', 'Stop the running crash recovery'): '動いているクラッシュ復旧を止めます',
    ('*', 'Clear Crash Recovery Results'): 'クラッシュ復旧の結果を消去',
    ('*', 'Clear the target list, recovery points and status. No files are deleted'): '対象の一覧・復旧ポイント・状態を消去します。ファイルは削除しません',
    ('*', 'Dump File'): 'ダンプファイル',
    ('*', 'Existing Blender memory dump file to read recovery points from.'): '復旧ポイントを読み取る既存の Blender のメモリダンプファイルです。',
    ('*', 'Scene File'): 'シーンのファイル',
    ('*', 'Scene Folder'): 'シーンのフォルダー',
    ('*', 'Size (MB)'): 'サイズ（MB）',
    ('*', 'Source PID'): '対象PID',
    ('*', 'Crash Signal'): 'クラッシュ検出根拠',
})
