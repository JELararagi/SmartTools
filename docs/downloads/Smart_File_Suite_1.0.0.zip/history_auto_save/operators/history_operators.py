# ------------------------------------------------------------------------------
# Copyright (C) 2026 JELararagi
#
# License:
# - Copyright belongs to JELararagi.
# - Licensed under the GNU General Public License v3.0 or later (GPL-3.0-or-later).
# ------------------------------------------------------------------------------

import bpy
from bpy.props import BoolProperty, IntProperty, StringProperty
from bpy.types import Operator

from ..core.context_utils import addon_prefs, project_root, scene_settings
from ..core import crash_recovery
from ..core.runtime import (
    log_autosave,
    log_restore_point,
    recompute_restore_links,
    restore_by_index,
    runtime_status,
    sync_listener_runtime,
)
from ..core.storage import clear_known_project_files, delete_path, export_history_json
from ..translation import iface as _iface, mode_label as _mode_label
from ...ui_language_runtime import error_text as _sf_error_text


def _restore_preview(st, index: int):
    if st is None or index < 0 or index >= len(st.entries):
        return None, None
    item = st.entries[index]
    target_index = index
    if not item.restorable and item.nearest_restore_index >= 0:
        target_index = item.nearest_restore_index
    target = st.entries[target_index] if 0 <= target_index < len(st.entries) else None
    return item, target


class UHM_OT_history_user_activity_monitor(Operator):
    bl_idname = 'uhm.sfs_history_user_activity_monitor'
    bl_label = 'History User Activity Monitor'
    bl_description = (
        'Compatibility command that performs one immediate validation and repair of the event-driven History Auto Save runtime. It does not install a modal input monitor and does not treat mouse or keyboard input as a file change.'
    )

    def invoke(self, context, event):
        del event
        return self.execute(context)

    def execute(self, context):
        ok = bool(sync_listener_runtime(context=context, reason='compatibility operator'))
        if ok:
            self.report({'INFO'}, _iface(runtime_status(context)))
            return {'FINISHED'}
        self.report({'WARNING'}, _iface(runtime_status(context)))
        return {'CANCELLED'}


class UHM_OT_history_refresh_runtime(Operator):
    bl_idname = 'uhm.sfs_history_refresh_runtime'
    bl_label = 'Refresh Runtime'
    bl_description = (
        "Refreshes automatic history backup state, reapplies the current N-panel startup setting, and checks existing restore files on disk. Use this after changing Autosave, Optional Timed Restore Points, or the storage folder."
    )

    bl_options = {'UNDO'}
    def execute(self, context):
        try:
            ok = bool(sync_listener_runtime(context=context, reason='manual refresh'))
            recompute_restore_links(context)
            message = _iface(runtime_status(context))
            self.report({'INFO'} if ok else {'WARNING'}, message)
            return {'FINISHED'} if ok else {'CANCELLED'}
        except Exception as exc:
            self.report({'WARNING'}, _sf_error_text(exc))
            return {'CANCELLED'}


class UHM_OT_history_use_default_storage_folder(Operator):
    bl_idname = 'uhm.sfs_history_use_default_storage_folder'
    bl_label = 'Use Default Storage Folder'
    bl_description = (
        "Clears the manual history storage folder so generated restore points, autosaves, safety backups, and logs are stored inside the Smart File CONFIG storage folder again."
    )

    bl_options = {'UNDO'}
    def execute(self, context):
        prefs = addon_prefs(context)
        if prefs is None:
            self.report({'WARNING'}, _iface("Preferences unavailable"))
            return {'CANCELLED'}
        try:
            prefs.history_directory = ""
            try:
                from ... import settings as _sfs_settings
                if hasattr(_sfs_settings, 'save_now'):
                    _sfs_settings.save_now(context, force=True, allow_disabled=True)
            except Exception:
                pass
            recompute_restore_links(context)
            self.report({'INFO'}, _iface("Using default storage folder."))
            return {'FINISHED'}
        except Exception as exc:
            self.report({'WARNING'}, _sf_error_text(exc))
            return {'CANCELLED'}



class UHM_OT_history_register_storage_folder(Operator):
    bl_idname = 'uhm.sfs_history_register_storage_folder'
    bl_label = 'Register History Folder'
    bl_description = (
        "Registers the currently entered history folder, creates it if needed, saves the setting to Smart_File_Suite/Smart_File_Suite.json, and refreshes restore/autosave links. Leave the field blank to use the default Smart File history folder."
    )

    bl_options = {'UNDO'}
    def execute(self, context):
        prefs = addon_prefs(context)
        if prefs is None:
            self.report({'WARNING'}, _iface("Preferences unavailable"))
            return {'CANCELLED'}
        try:
            import os
            raw = str(getattr(prefs, 'history_directory', '') or '').strip()
            if raw:
                folder = bpy.path.abspath(raw)
                os.makedirs(folder, exist_ok=True)
            try:
                from ... import settings as _sfs_settings
                if hasattr(_sfs_settings, 'save_now'):
                    _sfs_settings.save_now(context, force=True, allow_disabled=True)
            except Exception:
                pass
            recompute_restore_links(context)
            self.report({'INFO'}, _iface("History folder registered."))
            return {'FINISHED'}
        except Exception as exc:
            self.report({'WARNING'}, _sf_error_text(exc))
            return {'CANCELLED'}



class UHM_OT_history_create_restore_point_now(Operator):
    bl_idname = 'uhm.sfs_history_create_restore_point_now'
    bl_label = 'Create Restore Point Now'
    bl_description = (
        "Immediately saves a deliberately named manual restore point using the current checkpoint name. This is the primary rollback workflow: use it before risky edits, large imports, destructive modifiers, exports, or big cleanup operations when you want a guaranteed return point."
    )

    bl_options = {'UNDO'}
    def execute(self, context):
        st = scene_settings(context)
        name = st.checkpoint_name.strip() if st else ""
        if not name or name == "Manual Restore Point":
            name = _iface("Manual Restore Point")
        entry = log_restore_point(name, _iface("Manual restore point created."), context=context)
        if entry:
            self.report({'INFO'}, _iface("Created restore point."))
            return {'FINISHED'}
        self.report({'WARNING'}, _iface("Restore point could not be created right now."))
        return {'CANCELLED'}


class UHM_OT_history_create_autosave_now(Operator):
    bl_idname = 'uhm.sfs_history_create_autosave_now'
    bl_label = 'Create Autosave Now'
    bl_description = (
        "Immediately writes one autosave file to the rolling autosave set. This is useful when you want an extra safety backup right now without waiting for the next timer."
    )

    bl_options = {'UNDO'}
    def execute(self, context):
        entry = log_autosave("Quick autosave", _iface("Manual autosave created immediately."), context=context)
        if entry:
            self.report({'INFO'}, _iface("Created autosave."))
            return {'FINISHED'}
        self.report({'WARNING'}, _iface("Autosave could not be created right now."))
        return {'CANCELLED'}


class UHM_OT_history_restore_selected_row(Operator):
    bl_idname = 'uhm.sfs_history_restore_selected_row'
    bl_label = 'Restore Selected Row'
    bl_description = (
        "Opens a confirmation popup before restoring with the selected row. If that row has no direct restore file, the add-on automatically falls back to the nearest earlier restore point that still exists."
    )

    bl_options = {'UNDO'}
    def draw(self, context):
        layout = self.layout
        st = scene_settings(context)
        item, target = _restore_preview(st, getattr(st, "active_index", -1))
        if item is None:
            layout.label(text=_iface("No selected history row."))
            return
        row = layout.row(align=True)
        row.label(text=_iface("Restore From"))
        row.label(text=item.label or _iface("(unnamed)"), translate=False)
        if target is not None and target != item:
            row = layout.row(align=True)
            row.label(text=_iface("Actual File Used"))
            row.label(text=target.label or _iface("(unnamed)"))
        layout.label(text=_iface("The current file state may be replaced by an older snapshot."))

    def invoke(self, context, event):
        st = scene_settings(context)
        if st is None or st.active_index < 0:
            self.report({'WARNING'}, _iface("No selected history row."))
            return {'CANCELLED'}
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        st = scene_settings(context)
        if st is None or st.active_index < 0:
            self.report({'WARNING'}, _iface("No selected history row."))
            return {'CANCELLED'}
        ok, msg = restore_by_index(st.active_index, context=context)
        if ok:
            return {'FINISHED'}
        self.report({'WARNING'}, msg)
        return {'CANCELLED'}


class UHM_OT_history_row_click(Operator):
    bl_idname = 'uhm.sfs_history_row_click'
    bl_label = 'Row Click'
    bl_description = (
        "Selects the clicked row without restoring. Use this when you only want to inspect the row details before deciding whether to restore."
    )

    index: IntProperty(
        description="Row index used internally to remember which history entry you clicked before reviewing or restoring it."
    )

    bl_options = {'UNDO'}
    @classmethod
    def description(cls, context, properties):
        st = scene_settings(context)
        if st is None or properties.index < 0 or properties.index >= len(st.entries):
            return cls.bl_description
        item = st.entries[properties.index]
        restore_hint = _iface("Restorable row") if (item.restorable or item.nearest_restore_index >= 0) else _iface("Log only row")
        return (
            f"{item.label}\n"
            f"{_iface('Type')}: {_iface(item.entry_type) if item.entry_type else '-'}\n"
            f"{_iface('Time')}: {item.timestamp}\n"
            f"{_iface('Object')}: {item.active_object or '-'}\n"
            f"{_iface('Mode')}: {_mode_label(item.mode)}\n"
            f"{_iface('Scene')}: {item.scene_name or '-'}\n"
            f"{_iface('Details')}: {item.detail or '-'}\n"
            f"{restore_hint}"
        )

    def invoke(self, context, event):
        st = scene_settings(context)
        if st is None:
            return {'CANCELLED'}
        st.active_index = self.index
        return {'FINISHED'}


class UHM_OT_history_delete_selected_row(Operator):
    bl_idname = 'uhm.sfs_history_delete_selected_row'
    bl_label = 'Delete Selected Row'
    bl_description = (
        "Deletes the selected history row. You can also choose to delete its attached restore or autosave file from disk when that file exists."
    )

    delete_file_too: BoolProperty(
        name="Delete Attached File Too",
        default=False,
        description=(
            "If enabled, deleting the selected row also tries to delete the restore or autosave file attached to that row from disk. Use this when you want to clean storage as well as the visible list."
        ),
    )

    bl_options = {'UNDO'}
    def execute(self, context):
        st = scene_settings(context)
        if st is None or st.active_index < 0 or st.active_index >= len(st.entries):
            self.report({'WARNING'}, _iface("No selected history row."))
            return {'CANCELLED'}
        item = st.entries[st.active_index]
        if self.delete_file_too and item.file_path:
            delete_path(item.file_path)
        st.entries.remove(st.active_index)
        st.active_index = min(max(0, st.active_index - 1), len(st.entries) - 1) if len(st.entries) else -1
        recompute_restore_links(context)
        self.report({'INFO'}, _iface("History row was deleted."))
        return {'FINISHED'}

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self)


class UHM_OT_history_clear_all(Operator):
    bl_idname = 'uhm.sfs_history_clear_all'
    bl_label = 'Clear All'
    bl_description = (
        "Removes all rows from the current scene history. You can also choose to delete the stored restore, autosave, and safety files created by this add-on for the current project."
    )

    delete_files_too: BoolProperty(
        name="Delete Stored Files Too",
        default=False,
        description=(
            "If enabled, clearing history also deletes the restore-point files, autosave files, safety backups, and exported logs created by this add-on for the current project folder."
        ),
    )

    bl_options = {'UNDO'}
    def execute(self, context):
        st = scene_settings(context)
        if st is None:
            return {'CANCELLED'}
        st.entries.clear()
        st.active_index = -1
        if self.delete_files_too:
            clear_known_project_files(context)
        self.report({'INFO'}, _iface("History was cleared."))
        return {'FINISHED'}

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self)


class UHM_OT_history_open_storage_folder(Operator):
    bl_idname = 'uhm.sfs_history_open_storage_folder'
    bl_label = 'Open Storage Folder'
    bl_description = "Opens the project storage folder used by this add-on for restore points, autosaves, safety backups, and exported logs."

    bl_options = set()
    _sms_no_undo = True
    def execute(self, context):
        path = project_root(context)
        try:
            bpy.ops.wm.path_open(filepath=path)
            self.report({'INFO'}, _iface("Opened storage folder."))
            return {'FINISHED'}
        except Exception:
            return {'CANCELLED'}


class UHM_OT_history_export_log(Operator):
    bl_idname = 'uhm.sfs_history_export_log'
    bl_label = 'Export Log'
    bl_description = (
        "Exports the current scene history as a JSON file. This is useful for reviewing your work timeline, debugging, sharing reports, or keeping an external archive of important sessions."
    )

    bl_options = {'UNDO'}
    def execute(self, context):
        path = export_history_json(context)
        if path:
            self.report({'INFO'}, f"{_iface('History exported')}: {path}")
            return {'FINISHED'}
        return {'CANCELLED'}


class UHM_OT_history_crash_recovery_quick_scan(Operator):
    bl_idname = 'uhm.sfs_history_crash_recovery_quick_scan'
    bl_label = 'Refresh External Crash Targets'
    bl_description = (
        'Finds only other Blender processes that show a strict external crash signal. The current Blender process, background helpers, and healthy Blender processes are excluded.'
    )

    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        ok, message = crash_recovery.start_scan(context)
        self.report({'INFO'} if ok else {'WARNING'}, _iface(message))
        return {'FINISHED'} if ok else {'CANCELLED'}


class UHM_OT_history_crash_recovery_copy_selected(Operator):
    bl_idname = 'uhm.sfs_history_crash_recovery_copy_selected'
    bl_label = 'Recover Latest State'
    bl_description = (
        'Reads the selected external crash target or recovery candidate without modifying it, writes a new .blend through an atomic part file, and opens the recovered file in this Blender after confirmation.'
    )

    bl_options = set()
    _sms_no_undo = True

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        ok, message = crash_recovery.start_copy_selected(context)
        self.report({'INFO'} if ok else {'WARNING'}, _iface(message))
        return {'FINISHED'} if ok else {'CANCELLED'}


class UHM_OT_history_crash_recovery_analyze_selected(Operator):
    bl_idname = 'uhm.sfs_history_crash_recovery_analyze_selected'
    bl_label = 'Find Memory Recovery Points'
    bl_description = 'Creates one owned read-only full dump of the selected crashed Blender process and analyzes its undo recovery points.'
    bl_options = set()
    _sms_no_undo = True

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        ok, message = crash_recovery.start_analyze_selected(context)
        self.report({'INFO'} if ok else {'WARNING'}, _iface(message))
        return {'FINISHED'} if ok else {'CANCELLED'}


class UHM_OT_history_crash_recovery_point(Operator):
    bl_idname = 'uhm.sfs_history_crash_recovery_point'
    bl_label = 'Recover This Memory Point'
    bl_description = 'Materializes the selected analyzed undo point, validates it through Blender, creates a new compressed blend, and opens it here.'
    bl_options = set()
    _sms_no_undo = True
    step_index: IntProperty(default=-1, options={'SKIP_SAVE'})

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        ok, message = crash_recovery.start_recovery_point(context, int(self.step_index))
        self.report({'INFO'} if ok else {'WARNING'}, _iface(message))
        return {'FINISHED'} if ok else {'CANCELLED'}


class UHM_OT_history_crash_recovery_disk_points(Operator):
    bl_idname = 'uhm.sfs_history_crash_recovery_disk_points'
    bl_label = 'Refresh Saved Recovery Points'
    bl_description = 'Finds disk autosaves, Blender backup files, restore points, and quit recovery files without scanning process memory.'
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        ok, message = crash_recovery.start_recovery_points_scan(context)
        self.report({'INFO'} if ok else {'WARNING'}, _iface(message))
        return {'FINISHED'} if ok else {'CANCELLED'}


class UHM_OT_history_crash_recovery_deep_fixture(Operator):
    bl_idname = 'uhm.sfs_history_crash_recovery_deep_fixture'
    bl_label = 'Deep Recovery From Fixture'
    bl_description = (
        'Runs bounded deep recovery against an explicitly selected dump/fixture or an explicit other Blender PID in a worker process. The current Blender process is excluded.'
    )

    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        ok, message = crash_recovery.start_deep_fixture(context)
        self.report({'INFO'} if ok else {'WARNING'}, _iface(message))
        return {'FINISHED'} if ok else {'CANCELLED'}


class UHM_OT_history_crash_recovery_cancel(Operator):
    bl_idname = 'uhm.sfs_history_crash_recovery_cancel'
    bl_label = 'Cancel Crash Recovery'
    bl_description = 'Cancels only the Smart File-owned crash-recovery worker process, if one is running.'

    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        stopped = crash_recovery.cancel_worker()
        st = scene_settings(context)
        if st is not None:
            st.crash_recovery_status = 'Crash recovery cancelled.' if stopped else 'No crash recovery worker was running.'
            st.crash_recovery_progress = 0
        self.report({'INFO'}, _iface(st.crash_recovery_status) if st is not None else _iface('Crash recovery cancelled.'))
        return {'FINISHED'}


class UHM_OT_history_crash_recovery_clear(Operator):
    bl_idname = 'uhm.sfs_history_crash_recovery_clear'
    bl_label = 'Clear Crash Recovery Results'
    bl_description = 'Clears the visible crash-recovery candidates and status fields without deleting any .blend files.'

    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        st = scene_settings(context)
        if st is None:
            return {'CANCELLED'}
        crash_recovery.clear_recovery_points()
        st.crash_recovery_candidates.clear()
        st.crash_recovery_active_index = -1
        st.crash_recovery_status = 'Ready'
        st.crash_recovery_progress = 0
        st.crash_recovery_last_error = ''
        self.report({'INFO'}, _iface('Crash recovery results cleared.'))
        return {'FINISHED'}


CLASSES = (
    UHM_OT_history_user_activity_monitor,
    UHM_OT_history_refresh_runtime,
    UHM_OT_history_use_default_storage_folder,
    UHM_OT_history_register_storage_folder,
    UHM_OT_history_create_restore_point_now,
    UHM_OT_history_create_autosave_now,
    UHM_OT_history_restore_selected_row,
    UHM_OT_history_row_click,
    UHM_OT_history_delete_selected_row,
    UHM_OT_history_clear_all,
    UHM_OT_history_open_storage_folder,
    UHM_OT_history_export_log,
    UHM_OT_history_crash_recovery_quick_scan,
    UHM_OT_history_crash_recovery_copy_selected,
    UHM_OT_history_crash_recovery_analyze_selected,
    UHM_OT_history_crash_recovery_point,
    UHM_OT_history_crash_recovery_disk_points,
    UHM_OT_history_crash_recovery_deep_fixture,
    UHM_OT_history_crash_recovery_cancel,
    UHM_OT_history_crash_recovery_clear,
)
