# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Connect history labels to the Smart File language runtime."""

from contextlib import suppress
import re

from bpy.app import translations

from .. import ui_language_runtime as suite_text
from ..language_extra import has_leftover_english
from .translation_data import BASE_PAIRS, EXTRA_UI_TRANSLATIONS

_I18N_KEY = __name__
_LATIN = re.compile(r"[A-Za-z]")
_JAPANESE = re.compile(r"[ぁ-んァ-ン一-龯]")
_MODES = {
    "OBJECT": "Object Mode", "POSE": "Pose Mode", "SCULPT": "Sculpt Mode",
    "SCULPT_CURVES": "Hair Curves Sculpt Mode", "PAINT_WEIGHT": "Weight Paint Mode",
    "PAINT_VERTEX": "Vertex Paint Mode", "PAINT_TEXTURE": "Texture Paint Mode",
    "PARTICLE": "Particle Edit Mode",
}
_EDITABLE = {
    "MESH": "Mesh", "CURVE": "Curve", "CURVES": "Hair Curves", "SURFACE": "Surface",
    "TEXT": "Text", "ARMATURE": "Armature", "METABALL": "Metaball", "LATTICE": "Lattice",
    "POINTCLOUD": "Point Cloud",
}
_MODES.update({f"EDIT_{kind}": f"{title} Edit Mode" for kind, title in _EDITABLE.items()})
for _pencil in ("GREASE_PENCIL", "GPENCIL"):
    for _mode, _title in (
        ("EDIT", "Edit"), ("SCULPT", "Sculpt"), ("PAINT", "Draw"),
        ("WEIGHT", "Weight Paint"), ("VERTEX", "Vertex Paint"),
    ):
        _MODES[f"{_mode}_{_pencil}"] = f"Grease Pencil {_title} Mode"


def _t(source, translation):
    return ("*", source), translation


def _has_ascii(text):
    return bool(_LATIN.search(text or ""))


def _has_japanese(text):
    return bool(_JAPANESE.search(text or ""))


def _split_bilingual(msgid):
    if not isinstance(msgid, str):
        return None
    pair = suite_text.split_bilingual(msgid)
    if pair:
        return pair
    choices = []
    for delimiter in re.finditer(r" / | ｜ | \| |：| : ", msgid):
        before, after = msgid[:delimiter.start()].strip(), msgid[delimiter.end():].strip()
        if before and after and _has_japanese(before) != _has_japanese(after):
            english, japanese = (after, before) if _has_japanese(before) else (before, after)
            choices.append((len(_LATIN.findall(japanese)), -delimiter.start(), english, japanese))
    if not choices:
        return None
    _, _, english, japanese = min(choices)
    return english, japanese


def _clean_msgid(message):
    if not isinstance(message, str):
        return message
    pair = _split_bilingual(message)
    return pair[0] if pair else message.strip()


def _label(message, main_lookup, native_lookup):
    try:
        return main_lookup(message)
    except Exception:
        key = _clean_msgid(message)
        with suppress(Exception):
            return native_lookup(key) or key
        return key


def iface(msgid):
    return _label(msgid, suite_text.iface, translations.pgettext_iface)


def tip(msgid):
    return _label(msgid, suite_text.tip, translations.pgettext_tip)


def data(msgid):
    return _label(msgid, suite_text.data, translations.pgettext)


def mode_label(mode):
    name = _MODES.get(mode or "")
    return iface(name) if name else "-"


_pairs = dict(_t(source, translation) for source, translation in BASE_PAIRS)
_pairs.update(EXTRA_UI_TRANSLATIONS)
TRANSLATIONS = {"ja_JP": {key: value for key, value in _pairs.items()
                          if not has_leftover_english(value)}}


def register():
    unregister()
    translations.register(_I18N_KEY, TRANSLATIONS)


def unregister():
    with suppress(Exception):
        translations.unregister(_I18N_KEY)
