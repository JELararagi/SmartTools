# ------------------------------------------------------------------------------
# Copyright (C) 2026 JELararagi
#
# License:
# - Copyright (C) 2026 JELararagi.
# - Licensed under the GNU General Public License v3.0 or later (GPL-3.0-or-later).
# ------------------------------------------------------------------------------

import bpy
import os
import re
import sys
import time

ROOT_ID = "history_auto_save"
# Compatibility alias used by runtime cleanup code and older package revisions.
ROOT_PACKAGE = ROOT_ID


def addon_module_candidates():
    candidates = []
    pkg = __package__ or ""
    if pkg:
        if ".history_auto_save" in pkg:
            candidates.append(pkg.split(".history_auto_save", 1)[0])
        if pkg.endswith(".core"):
            candidates.append(pkg[:-5])
        candidates.append(pkg)
    candidates.append(ROOT_ID)
    # Deduplicate while preserving order.
    seen = set()
    out = []
    for item in candidates:
        if item and item not in seen:
            seen.add(item)
            out.append(item)
    return out


def root_package_name():
    cands = addon_module_candidates()
    return cands[0] if cands else ROOT_ID


def safe_context(context=None):
    return context or getattr(bpy, "context", None)


def has_real_ui_context(context=None):
    ctx = safe_context(context)
    return bool(ctx and getattr(ctx, "scene", None) and getattr(ctx, "view_layer", None))


def addon_prefs(context=None):
    """Return the single authoritative Smart File settings owner.

    ``WindowManager.uhm_addon_settings`` is retained only as a one-time legacy
    migration source by ``history_integration``.  Runtime reads and persistent
    writes must never fall back to it.
    """
    ctx = safe_context(context)
    try:
        wm = getattr(ctx, "window_manager", None)
        settings = getattr(wm, "sf_addon_settings", None) if wm is not None else None
        if settings is not None and hasattr(settings, "enable_history_listener"):
            return settings
    except Exception:
        pass
    return None


def scene_settings(context=None):
    ctx = safe_context(context)
    scene = getattr(ctx, "scene", None)
    if scene is None:
        return None
    return getattr(scene, "uhm_settings", None)


def safe_name(name: str) -> str:
    name = name or "Untitled"
    name = re.sub(r"[^A-Za-z0-9._ -]+", "_", name)
    return name.strip(" ._") or "Untitled"


def now_str() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def now_stamp() -> str:
    t = time.time()
    base = time.strftime("%Y%m%d_%H%M%S", time.localtime(t))
    ms = int((t - int(t)) * 1000)
    return f"{base}_{ms:03d}"


def active_object_name(context=None) -> str:
    ctx = safe_context(context)
    try:
        obj = ctx.view_layer.objects.active
        return obj.name_full if obj else ""
    except Exception:
        return ""


def mode_name(context=None) -> str:
    ctx = safe_context(context)
    return getattr(ctx, "mode", "") or ""


def scene_name(context=None) -> str:
    ctx = safe_context(context)
    scene = getattr(ctx, "scene", None)
    return getattr(scene, "name", "") or ""


def frame_current(context=None) -> int:
    ctx = safe_context(context)
    scene = getattr(ctx, "scene", None)
    return int(getattr(scene, "frame_current", 0) or 0)


def selected_names(context=None):
    ctx = safe_context(context)
    try:
        names = [obj.name_full for obj in getattr(ctx, "selected_objects", [])]
    except Exception:
        names = []
    names.sort()
    return names


def selected_count(context=None) -> int:
    return len(selected_names(context))


def selection_signature(context=None) -> str:
    return "|".join([mode_name(context), active_object_name(context), *selected_names(context), str(frame_current(context))])


def safe_collection_len(attr_name: str) -> int:
    try:
        collection = getattr(bpy.data, attr_name, None)
        return len(collection) if collection is not None else 0
    except Exception:
        return 0


def current_blend_filepath() -> str:
    try:
        return getattr(bpy.data, "filepath", "") or ""
    except Exception:
        return ""


def project_display_name() -> str:
    filepath = current_blend_filepath()
    if filepath:
        return os.path.splitext(os.path.basename(filepath))[0]
    return "Unsaved_Project"


def current_filename_stem() -> str:
    filepath = current_blend_filepath()
    if filepath:
        stem = os.path.splitext(os.path.basename(filepath))[0]
        match = re.match(r'^(?P<base>.+)_Autosave_\d{3,}(?:_\d{3})?$', stem, re.IGNORECASE)
        if match:
            return safe_name(match.group('base'))
        return stem
    return "Unsaved_Project"


def _managed_snapshot_project_key(context=None) -> str:
    """Return the owning namespace only for files inside this add-on's history root."""
    filepath = current_blend_filepath()
    if not filepath:
        return ""
    try:
        history_root = storage_root(context, create=False)
        resolved_file = os.path.realpath(os.path.abspath(os.path.expanduser(filepath)))
        resolved_root = os.path.realpath(os.path.abspath(os.path.expanduser(history_root)))
        normalized_file = os.path.normcase(resolved_file)
        normalized_root = os.path.normcase(resolved_root)
        if os.path.commonpath((normalized_file, normalized_root)) != normalized_root:
            return ""
        relative = os.path.relpath(resolved_file, resolved_root)
        parts = [part for part in relative.replace('\\', '/').split('/') if part]
        if len(parts) < 3 or parts[-2].lower() not in {
            'restore_points', 'autosaves', 'safety_backups'
        }:
            return ""
        return safe_name(parts[-3])
    except (OSError, ValueError):
        return ""


def infer_project_key(context=None) -> str:
    filepath = current_blend_filepath()
    if not filepath:
        # An unsaved file has no durable project identity. In particular, never
        # trust a scene value left by a previous load/settings replay here.
        return "Unsaved_Project"
    base = project_display_name()
    managed_key = _managed_snapshot_project_key(context)
    if managed_key:
        # A managed filename may carry a more specific origin than its parent
        # directory.  This matters for legacy mixed artifacts such as
        # history/MIK_033/autosaves/Unsaved_Project_Autosave_003.blend: opening
        # one must not graft the unsaved session onto MIK_033's lineage.
        match = re.match(r'^(?P<base>.+)_Autosave_\d{3,}(?:_\d{3})?$', base, re.IGNORECASE)
        if match:
            encoded_key = safe_name(match.group('base'))
            return managed_key if encoded_key.casefold() == managed_key.casefold() else encoded_key
        for marker in ("__restore_points__", "__autosaves__", "__safety_backups__"):
            if marker in base:
                encoded_key = safe_name(base.split(marker, 1)[0])
                return managed_key if encoded_key.casefold() == managed_key.casefold() else encoded_key
        return managed_key

    # For a normal saved file, the current filepath is authoritative. This
    # prevents a stale embedded project_key from mixing two file identities.
    # Snapshot-looking filenames outside the configured history root are normal
    # user projects and must not inherit managed-snapshot behavior.
    return safe_name(base)


def is_managed_snapshot_file(context=None) -> bool:
    return bool(_managed_snapshot_project_key(context))


def _sf_blender_version_string() -> str:
    """Return Blender's major.minor CONFIG version folder."""
    try:
        version = getattr(getattr(bpy, "app", None), "version", None)
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return "5.1"


def extension_user_dir(*parts: str, create: bool = True) -> str:
    # Draw/status callers must not trigger an import.  The shared module is on
    # the startup path; if unavailable, compute the same CONFIG path locally.
    try:
        package = str(__package__ or "")
        root = package.split(".history_auto_save", 1)[0] if ".history_auto_save" in package else package
        storage_paths = sys.modules.get(f"{root}.storage_paths") if root else None
        user_default_dir = getattr(storage_paths, "user_default_dir", None) if storage_paths is not None else None
        if callable(user_default_dir):
            return os.path.normpath(user_default_dir(*parts, create=create))
    except Exception:
        pass
    cleaned = [str(part or '').strip().strip('/\\') for part in parts if str(part or '').strip()]
    try:
        base = bpy.utils.user_resource('CONFIG', create=False) or ''
    except Exception:
        base = ''
    if not base:
        if os.name == 'nt':
            root = os.environ.get('APPDATA') or os.path.join(os.path.expanduser('~'), 'AppData', 'Roaming')
            base = os.path.join(root, 'Blender Foundation', 'Blender', _sf_blender_version_string(), 'config')
        else:
            base = os.path.join(os.environ.get('XDG_CONFIG_HOME', os.path.join(os.path.expanduser('~'), '.config')), 'blender', _sf_blender_version_string(), 'config')
    path = os.path.normpath(os.path.join(base, 'Smart_File_Suite', *cleaned))
    if create:
        os.makedirs(path, exist_ok=True)
    return path


def storage_root(context=None, *, create: bool = True) -> str:
    prefs = addon_prefs(context)
    raw = ""
    if prefs:
        raw = (prefs.history_directory or "").strip()
    if raw:
        root = bpy.path.abspath(raw)
    else:
        root = extension_user_dir('history', create=create)
    if create:
        os.makedirs(root, exist_ok=True)
    return root


def project_root(context=None, *, create: bool = True) -> str:
    """Return the project path; only explicit storage operations create it."""
    root = storage_root(context, create=create)
    project = infer_project_key(context)
    path = os.path.join(root, project)
    if create:
        os.makedirs(path, exist_ok=True)
    return path


def category_dir(category: str, context=None, *, create: bool = True) -> str:
    path = os.path.join(project_root(context, create=create), category)
    if create:
        os.makedirs(path, exist_ok=True)
    return path
