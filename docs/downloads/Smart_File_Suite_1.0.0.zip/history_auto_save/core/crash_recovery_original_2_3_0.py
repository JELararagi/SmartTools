"""JEL Blender Crash Rescue - recovery engine (Blender 5.1.2 / Windows x64).

Reconstructs a fully loadable .blend from a crashed Blender process by reading
its global-undo MemFile out of a full process memory dump.

Why this engine and not an in-process rescue call: the official Windows build
ships a blender.pdb that carries no function symbols at all (DbgHelp reports
SymType=None, zero publics), so `write_crash_blend()` cannot be located, and
calling into a crashed process is unsafe anyway.  Everything here runs offline
against the dump file.

Pipeline
    1. scan     - locate every MemFileChunk chain (one per undo step)
    2. rebuild  - concatenate each chain into a raw .blend byte stream
    3. inline   - resolve implicit-sharing pointers the undo writer left dangling
                  (attribute arrays, face offsets, packed files, vertex weights)
                  by fetching the real bytes from the dump
    4. rank     - identify the newest step
    5. finalize - Blender re-saves it as a clean compressed .blend

Stdlib only.  Runs on Blender's bundled Python 3.13 or any CPython 3.9+.
"""

import bisect
import collections
import hashlib
import json
import mmap
import os
import re
import struct
import sys
import time

VERSION = "2.3.0"
BLEND_HDR = b"BLENDER17-01v0501"      # Blender 5.x, 64-bit, little endian
BHEAD = 32                            # this header variant uses a 32-byte BHead
PTR = 8

# Blender attribute element sizes, calibrated against the real 5.1.2 build.
# Do not guess these: a wrong size makes the reader abort with
# "Corrupt .blend file, unexpected data size".
ATTR_ELEM = {
    0: 1,     # BOOLEAN
    1: 1,     # INT8
    2: 4,     # INT16_2D
    3: 4,     # INT
    4: 8,     # INT32_2D
    5: 4,     # FLOAT
    6: 8,     # FLOAT2
    7: 12,    # FLOAT_VECTOR
    8: 64,    # FLOAT4X4
    9: 4,     # BYTE_COLOR
    10: 16,   # FLOAT_COLOR
    11: 16,   # QUATERNION
    12: 256,  # STRING
}
CD_MDEFORMVERT = 2
SHARED_TAG = 0x8000                   # implicit-sharing pointers carry this in bits 48-63
MASK48 = (1 << 48) - 1


def log(msg):
    _pipe = sys.stdout   # controller pipe of the recovery subprocess
    _pipe.write(msg + "\n")
    _pipe.flush()


def progress(stage, pct, msg=""):
    """Machine-readable line the GUI parses for its progress bar."""
    _pipe = sys.stdout   # controller pipe of the recovery subprocess
    _pipe.write("@@PROGRESS %s %d %s\n" % (stage, pct, msg))
    _pipe.flush()


# --------------------------------------------------------------------- dump

class Dump:
    """Read-only view of a Windows full-memory minidump, addressed by VA."""

    def __init__(self, path):
        self.f = open(path, "rb")
        self.mm = mmap.mmap(self.f.fileno(), 0, access=mmap.ACCESS_READ)
        mm = self.mm
        if mm[:4] != b"MDMP":
            raise ValueError("not a minidump file (missing MDMP signature): %s" % path)
        nstreams, dirrva = struct.unpack_from("<II", mm, 8)
        raw = []
        for i in range(nstreams):
            st, _dsize, rva = struct.unpack_from("<III", mm, dirrva + i * 12)
            if st == 9:                                   # Memory64ListStream
                nranges, baserva = struct.unpack_from("<QQ", mm, rva)
                off, p = baserva, rva + 16
                for _ in range(nranges):
                    start, dsz = struct.unpack_from("<QQ", mm, p)
                    p += 16
                    raw.append([start, dsz, off])
                    off += dsz
        if not raw:
            raise ValueError("dump has no full-memory stream; it was not taken with "
                             "MiniDumpWithFullMemory")
        raw.sort()
        merged = []
        for r in raw:
            if (merged and merged[-1][0] + merged[-1][1] == r[0]
                    and merged[-1][2] + merged[-1][1] == r[2]):
                merged[-1][1] += r[1]
            else:
                merged.append(list(r))
        self.ranges = merged
        self.starts = [r[0] for r in merged]
        self.total = sum(r[1] for r in merged)

    def read(self, va, n):
        if n <= 0 or n > (1 << 31):
            return None
        i = bisect.bisect_right(self.starts, va) - 1
        if i < 0:
            return None
        start, size, base = self.ranges[i]
        if not (start <= va and va + n <= start + size):
            return None
        o = base + (va - start)
        return self.mm[o:o + n]

    def u64(self, va):
        d = self.read(va, 8)
        return None if d is None else struct.unpack("<Q", d)[0]

    def off_to_va(self, off):
        for start, size, base in self.ranges:
            if base <= off < base + size:
                return start + (off - base)
        return None

    def find_all(self, needle, limit=100000):
        out, i = [], 0
        mm = self.mm
        while len(out) < limit:
            j = mm.find(needle, i)
            if j < 0:
                break
            out.append(j)
            i = j + 1
        return out

    def find_all_multi(self, needles, limit_each=100000):
        """{needle: [file offsets]}.

        Deliberately one mmap.find per needle.  A single-pass version that
        copies 64 MB windows into Python and searches each needle inside them
        was written and MEASURED against this 20.71 GB dump with 14 needles:
        470 s single-pass vs 456 s per-needle.  mmap.find scans the mapping
        natively and the pages stay cached between sweeps, so the window copies
        cost more than the extra sweeps save.  The live source still overrides
        this, because there every sweep is real ReadProcessMemory traffic.
        """
        return {n: self.find_all(n, limit_each) for n in needles}

    def close(self):
        try:
            self.mm.close()
        finally:
            self.f.close()


class LiveProcess:
    """Same surface as Dump, but reading a live process instead of a .dmp.

    Writing a 13-20 GB dump and then reading it back is by far the slowest part
    of a rescue, and it is only needed as evidence.  For the one-button route the
    crashed process is sitting at its dialog with all of memory intact, so the
    undo chains can be read straight out of it.

    find_all() returns virtual addresses directly and off_to_va() is the
    identity, which is what find_undo_chains() expects of either source.
    """

    PROCESS_QUERY_INFORMATION = 0x0400
    PROCESS_VM_READ = 0x0010
    MEM_COMMIT = 0x1000
    MEM_PRIVATE = 0x20000
    PAGE_GUARD = 0x100
    PAGE_NOACCESS = 0x01
    READABLE = (0x02 | 0x04 | 0x20 | 0x40 | 0x80)   # R, RW, RX, RWX, WCOPY

    def __init__(self, pid, chunk=(8 << 20)):
        import ctypes
        from ctypes import wintypes
        self.ctypes = ctypes
        self.chunk = chunk
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self.k32 = k32
        k32.OpenProcess.restype = wintypes.HANDLE
        k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.h = k32.OpenProcess(self.PROCESS_QUERY_INFORMATION | self.PROCESS_VM_READ,
                                 False, int(pid))
        if not self.h:
            err = ctypes.get_last_error()
            raise OSError("OpenProcess(%d) failed (Win32 error %d)%s"
                          % (pid, err, "  -- 管理者として実行してください。" if err == 5 else ""))

        class MBI(ctypes.Structure):
            _fields_ = [("BaseAddress", ctypes.c_void_p),
                        ("AllocationBase", ctypes.c_void_p),
                        ("AllocationProtect", wintypes.DWORD),
                        ("__align", wintypes.DWORD),
                        ("RegionSize", ctypes.c_size_t),
                        ("State", wintypes.DWORD),
                        ("Protect", wintypes.DWORD),
                        ("Type", wintypes.DWORD),
                        ("__align2", wintypes.DWORD)]

        self._MBI = MBI
        k32.VirtualQueryEx.argtypes = [wintypes.HANDLE, ctypes.c_void_p,
                                       ctypes.POINTER(MBI), ctypes.c_size_t]
        k32.VirtualQueryEx.restype = ctypes.c_size_t
        k32.ReadProcessMemory.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p,
                                          ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
        k32.ReadProcessMemory.restype = wintypes.BOOL

        ranges = []
        addr = 0
        mbi = MBI()
        while addr < (1 << 47):
            got = k32.VirtualQueryEx(self.h, ctypes.c_void_p(addr), ctypes.byref(mbi),
                                     ctypes.sizeof(mbi))
            if not got:
                break
            base = mbi.BaseAddress or 0
            size = int(mbi.RegionSize or 0)
            if size <= 0:
                break
            prot = int(mbi.Protect)
            # Undo chunks and their buffers are heap allocations, so only
            # MEM_PRIVATE is worth walking.  Skipping MEM_IMAGE and MEM_MAPPED
            # drops the mapped DLLs and file views, which on a loaded Blender is
            # a large share of the address space and none of the answer.
            if (int(mbi.State) == self.MEM_COMMIT and (prot & self.READABLE)
                    and int(mbi.Type) == self.MEM_PRIVATE
                    and not (prot & self.PAGE_GUARD) and not (prot & self.PAGE_NOACCESS)):
                ranges.append([int(base), size])
            addr = int(base) + size
        ranges.sort()
        merged = []
        for r in ranges:
            if merged and merged[-1][0] + merged[-1][1] == r[0]:
                merged[-1][1] += r[1]
            else:
                merged.append(list(r))
        self.ranges = [(b, s, 0) for b, s in merged]
        self.starts = [b for b, _s, _o in self.ranges]
        self.total = sum(s for _b, s, _o in self.ranges)

    def read(self, va, n):
        if n <= 0 or n > (1 << 31):
            return None
        ctypes = self.ctypes
        buf = ctypes.create_string_buffer(n)
        got = ctypes.c_size_t(0)
        ok = self.k32.ReadProcessMemory(self.h, ctypes.c_void_p(int(va)), buf, n,
                                        ctypes.byref(got))
        if not ok or got.value != n:
            return None
        return buf.raw

    def u64(self, va):
        d = self.read(va, 8)
        return None if d is None else struct.unpack("<Q", d)[0]

    def off_to_va(self, off):
        return off                       # find_all already hands back addresses

    def find_all(self, needle, limit=100000):
        out = []
        overlap = len(needle) - 1
        for base, size, _o in self.ranges:
            pos = 0
            while pos < size and len(out) < limit:
                want = min(self.chunk, size - pos)
                data = self.read(base + pos, want)
                if data is None:
                    # a region can go unreadable mid-walk; skip just that slice
                    pos += want
                    continue
                i = 0
                while True:
                    j = data.find(needle, i)
                    if j < 0:
                        break
                    out.append(base + pos + j)
                    if len(out) >= limit:
                        break
                    i = j + 1
                if want < self.chunk:
                    break
                pos += want - overlap
        return out

    def find_all_multi(self, needles, limit_each=100000):
        """Search for several byte patterns in a SINGLE pass over memory.

        find_undo_chains looks for the stream header, then for pointers to each
        header it found.  Done naively that is one full walk per header, which a
        memory-mapped dump absorbs through the page cache but a live process does
        not: every pass is another 20 GB of ReadProcessMemory.  One pass, many
        finds, is the difference between seconds and many minutes.
        """
        needles = list(needles)
        out = dict((n, []) for n in needles)
        if not needles:
            return out
        overlap = max(len(n) for n in needles) - 1
        for base, size, _o in self.ranges:
            pos = 0
            while pos < size:
                want = min(self.chunk, size - pos)
                data = self.read(base + pos, want)
                if data is None:
                    pos += want
                    continue
                for n in needles:
                    acc = out[n]
                    if len(acc) >= limit_each:
                        continue
                    i = 0
                    while True:
                        j = data.find(n, i)
                        if j < 0:
                            break
                        acc.append(base + pos + j)
                        if len(acc) >= limit_each:
                            break
                        i = j + 1
                if want < self.chunk:
                    break
                pos += want - overlap
        return out

    def close(self):
        try:
            self.k32.CloseHandle(self.h)
        except Exception:
            pass


def open_source(spec):
    """`spec` is either a .dmp path or "pid:<n>"."""
    s = str(spec)
    if s.lower().startswith("pid:"):
        pid = int(s.split(":", 1)[1])
        src = LiveProcess(pid)
        log("live process %d: %d readable ranges (%.2f GB)"
            % (pid, len(src.ranges), src.total / (1 << 30)))
        return src
    src = Dump(s)
    log("dump: %s (%.2f GB)" % (s, os.path.getsize(s) / (1 << 30)))
    log("  mapped memory ranges: %d (%.2f GB)" % (len(src.ranges), src.total / (1 << 30)))
    return src


# ---------------------------------------------------------------- DNA / blocks

class SDNA:
    def __init__(self, buf):
        if buf[:4] != b"SDNA":
            raise ValueError("bad SDNA block")
        p = 4
        assert buf[p:p + 4] == b"NAME"
        p += 4
        n = struct.unpack_from("<I", buf, p)[0]
        p += 4
        self.names = []
        for _ in range(n):
            e = buf.index(b"\0", p)
            self.names.append(buf[p:e].decode("ascii"))
            p = e + 1
        p = (p + 3) & ~3
        assert buf[p:p + 4] == b"TYPE"
        p += 4
        n = struct.unpack_from("<I", buf, p)[0]
        p += 4
        self.types = []
        for _ in range(n):
            e = buf.index(b"\0", p)
            self.types.append(buf[p:e].decode("ascii"))
            p = e + 1
        p = (p + 3) & ~3
        assert buf[p:p + 4] == b"TLEN"
        p += 4
        self.tlens = list(struct.unpack_from("<%dH" % len(self.types), buf, p))
        p += 2 * len(self.types)
        p = (p + 3) & ~3
        assert buf[p:p + 4] == b"STRC"
        p += 4
        nstr = struct.unpack_from("<I", buf, p)[0]
        p += 4
        self.structs = []
        for _ in range(nstr):
            tidx, nf = struct.unpack_from("<HH", buf, p)
            p += 4
            fields = []
            for _ in range(nf):
                ft, fn = struct.unpack_from("<HH", buf, p)
                p += 4
                fields.append((ft, fn))
            self.structs.append((tidx, fields))
        self.by_name = {}
        for si, (tidx, _f) in enumerate(self.structs):
            self.by_name[self.types[tidx]] = si
        self._cache = {}

    def _fsize(self, ft, nm):
        base = PTR if nm.startswith("*") else self.tlens[ft]
        for m in re.findall(r"\[(\d+)\]", nm):
            base *= int(m)
        return base

    def layout(self, sname):
        if sname in self._cache:
            return self._cache[sname]
        si = self.by_name[sname]
        off, lay = 0, {}
        for ft, fn in self.structs[si][1]:
            nm = self.names[fn]
            key = nm.lstrip("*").split("[")[0]
            size = self._fsize(ft, nm)
            if key not in lay:
                lay[key] = (off, size, self.types[ft])
            off += size
        self._cache[sname] = lay
        return lay

    def struct_size(self, sname):
        return self.tlens[self.structs[self.by_name[sname]][0]]

    def name_of(self, si):
        if 0 <= si < len(self.structs):
            return self.types[self.structs[si][0]]
        return "?"


def parse_blocks(data):
    """Return [(code, old, len, sdna_index, nr, f28, data_offset), ...].

    In this header variant the SDNA struct index lives at BHead+4 (verified
    against ME/OB blocks), the payload length is a 64-bit field at +16.
    """
    p = len(BLEND_HDR)
    blocks = []
    n = len(data)
    while p + BHEAD <= n:
        code = data[p:p + 4]
        sdna_i = struct.unpack_from("<I", data, p + 4)[0]
        old = struct.unpack_from("<Q", data, p + 8)[0]
        blen = struct.unpack_from("<Q", data, p + 16)[0]
        nr = struct.unpack_from("<I", data, p + 24)[0]
        f28 = struct.unpack_from("<I", data, p + 28)[0]
        blocks.append((code, old, blen, sdna_i, nr, f28, p + BHEAD))
        if code == b"ENDB" or blen > (1 << 32):
            break
        p += BHEAD + blen
    return blocks


# ------------------------------------------------------------- chain recovery

def _plausible_ptr(v):
    return v and 0x10000 < v < 0x7FFFFFFFFFFF and (v & 7) == 0


def find_undo_chains(dm, max_steps=200):
    """Every global-undo step keeps its serialized .blend as a MemFileChunk list.

        MemFileChunk { next; prev; buf; size; ... }   (+0 +8 +16 +24)

    Steps share unchanged chunk buffers, so we start from each occurrence of the
    .blend stream header, find the MemFileChunk that points at it, and walk.
    """
    progress("scan", 5, "スキャン中")
    heads = dm.find_all(BLEND_HDR)
    log("  blend-stream headers in dump: %d" % len(heads))

    # Pointers to every header are collected in ONE walk.  Scanning once per
    # header is what made a live process take many minutes: a dump re-reads from
    # the page cache, a process does not.
    header_vas = []
    for h in heads:
        va = dm.off_to_va(h)
        if va is not None:
            header_vas.append(va)
    needles = [struct.pack("<Q", va) for va in header_vas]
    progress("scan", 20, "参照を探索中 (%d 件)" % len(needles))
    hits = dm.find_all_multi(needles)
    cands = []
    for n in needles:
        for hit in hits.get(n, ()):
            hva = dm.off_to_va(hit)
            if hva is not None:
                cands.append(hva - 16)          # MemFileChunk.buf sits at +16
    log("  candidate chunk heads: %d" % len(cands))

    seen = {}
    for i, base in enumerate(cands):
        if len(seen) >= max_steps:
            break
        if i % 64 == 0:
            progress("scan", 5 + int(35.0 * i / max(1, len(cands))), "チェーン解析中")
        nxt, prv, size = dm.u64(base), dm.u64(base + 8), dm.u64(base + 24)
        if size is None or not (0 < size <= (1 << 24)):
            continue
        if not (_plausible_ptr(nxt) or nxt == 0):
            continue
        if prv:                                  # walk from the list head only
            continue
        # Hash while walking but keep only the chunk list, never the bytes.
        #
        # Holding every step's assembled blob is what made a 200-step stack
        # unusable: 200 x ~150 MB is about 30 GB resident, which on a machine
        # already hosting the crashed 20 GB Blender pushed the whole thing into
        # the pagefile.  Summarising 200 steps then measured 75 minutes even
        # though one summary of a real blob takes 0.85 s.  A step is now a
        # recipe; materialize_step() rebuilds the few that are actually read.
        digest = hashlib.blake2b(digest_size=16)
        plan, bufs, total, n, cur, guard = [], [], 0, 0, base, set()
        ok = True
        while cur and cur not in guard:
            guard.add(cur)
            buf, sz, nx = dm.u64(cur + 16), dm.u64(cur + 24), dm.u64(cur)
            if buf is None or sz is None or not (0 < sz <= (1 << 24)):
                ok = False
                break
            d = dm.read(buf, sz)
            if d is None:
                ok = False
                break
            digest.update(d)
            plan.append((buf, sz))
            bufs.append(buf)
            total += sz
            n += 1
            if not nx:
                break
            cur = nx
        if not ok or total < (1 << 20):
            continue
        key = digest.hexdigest()
        if key not in seen:
            seen[key] = {"plan": plan, "chunks": n, "bytes": total, "head": base,
                         "bufs": set(bufs)}
    steps = sorted(seen.values(), key=lambda s: s["head"])

    # How many chunk buffers does each step hold that no other step holds?
    #
    # When Blender encodes an undo step it reuses the previous step's buffer for
    # every chunk that did not change, and allocates a fresh buffer for the ones
    # that did.  Those fresh buffers then get reused by every later step, so a
    # step's changed buffers stay unique to it only while nothing comes after.
    # The step with the most unique buffers is therefore the newest one.
    owners = collections.Counter()
    for s in steps:
        for b in s["bufs"]:
            owners[b] += 1
    for s in steps:
        s["unique_bufs"] = sum(1 for b in s["bufs"] if owners[b] == 1)
        del s["bufs"]
    log("  distinct undo steps: %d" % len(steps))
    return steps


# ----------------------------------------------------------------- inlining

def inline_shared(blob, dm, stats=None):
    """Fill in the arrays the undo writer stored only as a tagged pointer.

    Blender's implicit sharing means the memfile records `0x8000<48-bit VA>` in
    place of the bytes.  The real bytes are still in the dump, so for every such
    site we append a plain DATA block whose `old` equals the tagged value - which
    is exactly the key the normal file reader looks the pointer up by.
    """
    stats = stats if stats is not None else collections.Counter()
    blocks = parse_blocks(blob)
    dna = None
    for b in blocks:
        if b[0] == b"DNA1":
            dna = b
            break
    if dna is None:
        raise ValueError("undo blob has no DNA1 block")
    sdna = SDNA(blob[dna[6]:dna[6] + dna[2]])

    me_lay = sdna.layout("Mesh")
    as_lay = sdna.layout("AttributeStorage")
    at_lay = sdna.layout("Attribute")
    aa_lay = sdna.layout("AttributeArray")
    cdl_lay = sdna.layout("CustomDataLayer")
    pf_lay = sdna.layout("PackedFile")
    AT = sdna.struct_size("Attribute")
    CDL = sdna.struct_size("CustomDataLayer")
    AS = me_lay["attribute_storage"][0]

    u64 = lambda b, o: struct.unpack_from("<Q", b, o)[0]
    i64 = lambda b, o: struct.unpack_from("<q", b, o)[0]
    i32 = lambda b, o: struct.unpack_from("<i", b, o)[0]
    i16 = lambda b, o: struct.unpack_from("<h", b, o)[0]
    i8 = lambda b, o: struct.unpack_from("<b", b, o)[0]

    def tagged(v):
        return (v >> 48) == SHARED_TAG and (1 << 32) < (v & MASK48) < 0x7FFFFFFFFFFF

    inserts = collections.defaultdict(list)

    def add(after, old_val, payload):
        inserts[after[6] + after[2]].append((old_val, payload))

    def fetch(ptr, nbytes):
        return dm.read(ptr & MASK48, nbytes)

    idx = 0
    nid = 0
    while idx < len(blocks):
        b = blocks[idx]
        code = b[0].rstrip(b"\x00")
        if not (len(code) == 2 and code.isalpha()):
            idx += 1
            continue
        nid += 1
        scope = []
        j = idx + 1
        while j < len(blocks) and blocks[j][0] == b"DATA":
            scope.append(blocks[j])
            j += 1
        smap = collections.defaultdict(list)
        for t in scope:
            smap[t[1]].append(t)

        def sblk(ptr, want=None):
            for t in smap.get(ptr, ()):
                if want is None or t[2] == want:
                    return t
            return None

        d = b[6]

        def do_attr_table(tb, count):
            for i in range(count):
                o = tb[6] + i * AT
                dtype = i16(blob, o + at_lay["data_type"][0])
                stor = i8(blob, o + at_lay["storage_type"][0])
                st = sblk(u64(blob, o + at_lay["data"][0]), 32 if stor == 0 else 16)
                if st is None:
                    continue
                aptr = u64(blob, st[6])
                if not tagged(aptr):
                    continue
                n = i64(blob, st[6] + aa_lay["size"][0]) if stor == 0 else 1
                elem = ATTR_ELEM.get(dtype)
                if elem is None:
                    stats["FAIL unknown attr type %d" % dtype] += 1
                    continue
                raw = fetch(aptr, n * elem)
                if raw is None:
                    stats["FAIL attr array unreachable"] += 1
                    continue
                add(st, aptr, raw)
                stats["attribute arrays"] += 1

        totvert = 0
        if code == b"ME":
            totvert = i32(blob, d + me_lay["totvert"][0])
            na = i32(blob, d + AS + as_lay["dna_attributes_num"][0])
            tb = sblk(u64(blob, d + AS + as_lay["dna_attributes"][0]), na * AT)
            if tb is not None:
                do_attr_table(tb, na)
            po = u64(blob, d + me_lay["poly_offset_indices"][0])
            tp = i32(blob, d + me_lay["totpoly"][0])
            if tagged(po) and tp:
                raw = fetch(po, (tp + 1) * 4)
                if raw is None:
                    stats["FAIL face offsets unreachable"] += 1
                else:
                    add(b, po, raw)
                    stats["face offset arrays"] += 1
        else:
            for t in scope:
                if sdna.name_of(t[3]) == "Attribute" and AT and t[2] % AT == 0:
                    do_attr_table(t, t[2] // AT)

        for t in scope:
            sn = sdna.name_of(t[3])
            if sn == "CustomDataLayer":
                for i in range(t[2] // CDL):
                    o = t[6] + i * CDL
                    ctype = i32(blob, o + cdl_lay["type"][0])
                    ptr = u64(blob, o + cdl_lay["data"][0])
                    if not tagged(ptr):
                        continue
                    if ctype == CD_MDEFORMVERT and totvert:
                        raw = fetch(ptr, totvert * 16)
                        if raw is None:
                            stats["FAIL dvert layer unreachable"] += 1
                            continue
                        add(t, ptr, raw)
                        stats["vertex-weight layers"] += 1
                        for v in range(totvert):
                            dwp = u64(raw, v * 16)
                            tw = i32(raw, v * 16 + 8)
                            if dwp and tw > 0:
                                dw = fetch(dwp, tw * 8)
                                if dw is None:
                                    stats["FAIL weight array unreachable"] += 1
                                    continue
                                add(t, dwp, dw)
                                stats["weight arrays"] += 1
                    else:
                        stats["FAIL CD layer type %d unhandled" % ctype] += 1
            elif sn == "PackedFile":
                o = t[6]
                size = i32(blob, o + pf_lay["size"][0])
                ptr = u64(blob, o + pf_lay["data"][0])
                if tagged(ptr):
                    raw = fetch(ptr, size)
                    if raw is None:
                        stats["FAIL packed file unreachable"] += 1
                    else:
                        add(t, ptr, raw)
                        stats["packed files"] += 1
        idx = j

    out = bytearray()
    pos = 0
    for cut in sorted(inserts.keys()):
        out += blob[pos:cut]
        for old_val, payload in inserts[cut]:
            out += struct.pack("<4sIQQII", b"DATA", 0, old_val, len(payload), 1, 0)
            out += payload
        pos = cut
    out += blob[pos:]
    return bytes(out), stats


# ------------------------------------------------------------------ ranking

def summarize_step(blob):
    """Cheap identity of a step: ID counts plus the active object's state.

    The active object's material-slot count and active index are what the last
    operations in a crash log usually touch, which makes them a good tie-breaker
    for 'which step is newest'.
    """
    info = {"objects": 0, "meshes": 0, "materials": 0, "images": 0, "actions": 0,
            "collections": 0, "active": "", "actcol": 0, "totcol": 0,
            "totvert": 0, "totpoly": 0, "blend_path": ""}
    try:
        blocks = parse_blocks(blob)
        dna = next(b for b in blocks if b[0] == b"DNA1")
        sdna = SDNA(blob[dna[6]:dna[6] + dna[2]])
    except Exception:
        return info

    counts = collections.Counter()
    me_lay = sdna.layout("Mesh")
    ob_lay = sdna.layout("Object")
    id_lay = sdna.layout("ID")
    no, nl = id_lay["name"][0], id_lay["name"][1]

    by_old = {}
    obj_by_ptr, mesh_by_ptr = {}, {}
    tv = tp = 0
    for b in blocks:
        c = b[0].rstrip(b"\x00")
        by_old.setdefault(b[1], b)
        if len(c) == 2 and c.isalpha():
            counts[c.decode()] += 1
            if c == b"OB":
                obj_by_ptr[b[1]] = b
            elif c == b"ME":
                mesh_by_ptr[b[1]] = b
                tv += struct.unpack_from("<i", blob, b[6] + me_lay["totvert"][0])[0]
                tp += struct.unpack_from("<i", blob, b[6] + me_lay["totpoly"][0])[0]
    info.update(objects=counts.get("OB", 0), meshes=counts.get("ME", 0),
                materials=counts.get("MA", 0), images=counts.get("IM", 0),
                actions=counts.get("AC", 0), collections=counts.get("GR", 0),
                totvert=tv, totpoly=tp)

    # the file path Blender had open, straight out of the GLOB block
    # (the field is FileGlobal.filename in this DNA, not "filepath")
    try:
        fg_lay = sdna.layout("FileGlobal")
        key = "filename" if "filename" in fg_lay else "filepath"
        off, size, _t = fg_lay[key]
        for b in blocks:
            if sdna.name_of(b[3]) == "FileGlobal":
                raw = blob[b[6] + off: b[6] + off + size]
                info["blend_path"] = raw.split(b"\x00")[0].decode("utf-8", "replace")
                break
    except Exception:
        pass

    try:
        vl_lay = sdna.layout("ViewLayer")
        base_lay = sdna.layout("Base")
        for b in blocks:
            if sdna.name_of(b[3]) != "ViewLayer":
                continue
            basact = struct.unpack_from("<Q", blob, b[6] + vl_lay["basact"][0])[0]
            bb = by_old.get(basact)
            if bb is None:
                continue
            optr = struct.unpack_from("<Q", blob, bb[6] + base_lay["object"][0])[0]
            ob = obj_by_ptr.get(optr)
            if ob is None:
                continue
            od = ob[6]
            info["active"] = blob[od + no:od + no + nl].split(b"\x00")[0].decode(
                "utf-8", "replace")[2:]
            info["actcol"] = struct.unpack_from("<h", blob, od + ob_lay["actcol"][0])[0]
            dptr = struct.unpack_from("<Q", blob, od + ob_lay["data"][0])[0]
            me = mesh_by_ptr.get(dptr)
            if me is not None:
                info["totcol"] = struct.unpack_from(
                    "<h", blob, me[6] + me_lay["totcol"][0])[0]
            break
    except Exception:
        pass
    return info


# ------------------------------------------------- quick (disk-only) recovery

_SELF_PATH_RE = re.compile(rb"[A-Za-z]:[\\/][^\x00\r\n]{0,700}?\.blend\b")
_ZSTD_MAGIC = b"\x28\xb5\x2f\xfd"


def _read_blend_head(path, want=1 << 18):
    """First `want` decompressed bytes of a .blend, or b'' if unreadable.

    Only the head is needed: the GLOB block that carries the file's own path
    sits within the first few KB, so this stays fast even on a 230 MB scene.
    """
    try:
        with open(path, "rb") as f:
            raw = f.read(want)
    except Exception:
        return b""
    if raw[:4] != _ZSTD_MAGIC:
        return raw
    try:
        import io as _io
        import zstandard
        dctx = zstandard.ZstdDecompressor()
        out = []
        got = 0
        with dctx.stream_reader(_io.BytesIO(raw)) as r:
            while got < want:
                try:
                    chunk = r.read(min(65536, want - got))
                except Exception:
                    break            # truncated frame: keep what we already have
                if not chunk:
                    break
                out.append(chunk)
                got += len(chunk)
        return b"".join(out)
    except Exception:
        return b""


def blend_self_path(path):
    """The path this .blend believes it is -- read out of its own GLOB block.

    Identity cannot come from the filename: autosaves, restore points and
    quit.blend are all named after something else.  The DNA needed to resolve
    FileGlobal's field offsets lives at the END of the file, so instead the GLOB
    payload is searched directly for the embedded absolute path.
    """
    head = _read_blend_head(path)
    if not head.startswith(b"BLENDER"):
        return ""
    p = len(BLEND_HDR)
    n = len(head)
    while p + BHEAD <= n:
        code = head[p:p + 4]
        try:
            blen = struct.unpack_from("<Q", head, p + 16)[0]
        except Exception:
            break
        data = p + BHEAD
        if code == b"GLOB":
            seg = head[data:data + min(int(blen), 8192)]
            m = _SELF_PATH_RE.search(seg)
            return m.group(0).decode("utf-8", "replace") if m else ""
        if code == b"ENDB" or blen > (1 << 32):
            break
        p = data + int(blen)
    return ""


_RE_ADDON_AUTOSAVE = re.compile(r"^(?P<stem>.+?)_Autosave_\d+$", re.I)
_RE_ADDON_RESTORE = re.compile(r"^(?P<stem>.+?)__restore_points__.*$", re.I)
_RE_BLENDER_AUTOSAVE = re.compile(r"^(?P<stem>.+?)_\d+_autosave$", re.I)
_RE_RECOVERED = re.compile(r"^(?P<stem>.+?)_recovered(?:[_.].*)?$", re.I)
_RE_HISTORY_DIR = re.compile(r"[\\/]Smart_File_Suite[\\/]history[\\/](?P<proj>[^\\/]+)[\\/]", re.I)


def scene_stem_of(path):
    """Which scene does this file belong to?  Returns (stem, needs_head_read).

    Identity cannot come from the embedded path for most files: Blender only
    stamps FileGlobal with an absolute path when the file lives somewhere other
    than where it belongs (quit.blend, crash writes).  A normally saved .blend
    leaves it empty, because its own location is the answer.  So the cheap and
    reliable source is the naming//directory convention, and only the handful of
    relocated files actually need their header parsed.
    """
    norm = path.replace("/", "\\")
    name = os.path.basename(path)
    low = name.lower()
    stem = os.path.splitext(name)[0]

    m = _RE_HISTORY_DIR.search(norm)
    if m:
        return m.group("proj"), False
    if low.endswith((".blend1", ".blend2")):
        return os.path.splitext(name)[0], False        # "x.blend1" -> stem "x"
    if low == "quit.blend" or low.endswith(".crash.blend"):
        return "", True                                # must read the header
    for rx in (_RE_ADDON_AUTOSAVE, _RE_ADDON_RESTORE, _RE_BLENDER_AUTOSAVE, _RE_RECOVERED):
        mm = rx.match(stem)
        if mm:
            return mm.group("stem"), False
    return stem, False


def _is_compressed(path):
    """Zstd-compressed .blend?  Needed so a 44 MB compressed file is not
    mistaken for a 218 MB uncompressed one that lost its packed textures."""
    try:
        with open(path, "rb") as f:
            return f.read(4) == _ZSTD_MAGIC
    except Exception:
        return False


def _candidate_kind(path, base_dir, scene_stem):
    low = path.lower()
    name = os.path.basename(path)
    if _RE_RECOVERED.match(os.path.splitext(name)[0]):
        return "recovered", "復旧済みファイル"
    if low.endswith(".blend1"):
        return "backup", "直前保存 (.blend1)"
    if low.endswith(".blend2"):
        return "backup", "2つ前の保存 (.blend2)"
    if "restore_points" in low.replace("\\", "/"):
        return "restore", "復元ポイント"
    if "autosaves" in low.replace("\\", "/"):
        return "autosave", "自動保存 (アドオン)"
    if name.lower().endswith("_autosave.blend"):
        return "autosave", "自動保存 (Blender)"
    if name.lower() == "quit.blend":
        return "quit", "終了時の状態"
    if low.endswith(".crash.blend"):
        return "crash", "クラッシュ書き出し"
    if os.path.normcase(os.path.dirname(path)) == os.path.normcase(base_dir) and \
            os.path.splitext(name)[0].lower() == scene_stem.lower():
        return "self", "保存済み本体"
    return "other", "関連ファイル"


def _iter_candidate_files(roots):
    seen = set()

    def add(p):
        try:
            rp = os.path.abspath(p)
        except Exception:
            return
        k = os.path.normcase(rp)
        if k in seen:
            return
        if not os.path.isfile(rp):
            return
        seen.add(k)
        yield_list.append(rp)

    yield_list = []
    appdata = os.environ.get("APPDATA", "")
    temp = os.environ.get("TEMP", "")

    scene_dirs = set()
    # scenes Blender itself remembers
    for rf in (
        os.path.join(appdata, "Blender Foundation", "Blender", "5.1", "config", "recent-files.txt"),
        os.path.join(appdata, "Blender Foundation", "Blender", "5.1", "config",
                     "Smart_File_Suite", "recent-files.txt"),
    ):
        try:
            with open(rf, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if line.lower().endswith(".blend"):
                        add(line)
                        scene_dirs.add(os.path.dirname(line))
        except Exception:
            pass

    for r in roots or ():
        if os.path.isdir(r):
            scene_dirs.add(r)
        elif os.path.isfile(r):
            add(r)
            scene_dirs.add(os.path.dirname(r))

    # siblings of every known scene: the file itself plus .blend1/.blend2
    for d in list(scene_dirs):
        try:
            for nm in os.listdir(d):
                lw = nm.lower()
                if lw.endswith((".blend", ".blend1", ".blend2")):
                    add(os.path.join(d, nm))
        except Exception:
            pass

    # add-on history: autosaves and restore points
    hist = os.path.join(appdata, "Blender Foundation", "Blender", "5.1", "config",
                        "Smart_File_Suite", "history")
    try:
        for proj in os.listdir(hist):
            for sub in ("autosaves", "restore_points"):
                d = os.path.join(hist, proj, sub)
                try:
                    for nm in os.listdir(d):
                        if nm.lower().endswith(".blend"):
                            add(os.path.join(d, nm))
                except Exception:
                    pass
    except Exception:
        pass

    # Blender's own temp dir: autosave, quit.blend, crash writes
    try:
        for nm in os.listdir(temp):
            lw = nm.lower()
            if lw.endswith(".blend") and (
                    lw.endswith("_autosave.blend") or lw == "quit.blend"
                    or lw.endswith(".crash.blend")):
                add(os.path.join(temp, nm))
    except Exception:
        pass

    return yield_list


def cmd_scan(out_json, roots=()):
    """Group every on-disk recovery candidate by the scene it belongs to.

    No dump, no process, no Blender launch -- just file metadata plus each
    file's own embedded path, which is what makes an autosave attributable to
    the right scene.
    """
    progress("scan", 2, "候補ファイルを収集しています")
    files = _iter_candidate_files(roots)
    progress("scan", 15, "%d 件の候補を確認しています" % len(files))

    scenes = {}
    home_dir = {}                      # stem -> directory of the real saved scene
    total = max(1, len(files))
    for i, p in enumerate(files):
        if i % 25 == 0:
            progress("scan", 15 + int(70.0 * i / total), "")
        try:
            st = os.stat(p)
        except Exception:
            continue
        stem, needs_head = scene_stem_of(p)
        self_path = ""
        if needs_head:
            self_path = blend_self_path(p)
            if self_path:
                stem = os.path.splitext(os.path.basename(self_path))[0]
            else:
                stem = os.path.splitext(os.path.basename(p))[0]
        key = stem.lower()
        sc = scenes.setdefault(key, {
            "scene_name": stem + ".blend",
            "scene_path": "",
            "candidates": [],
        })
        low = p.lower()
        if low.endswith(".blend") and os.path.splitext(os.path.basename(p))[0].lower() == key:
            sc["scene_path"] = p                       # the saved scene itself
            home_dir[key] = os.path.dirname(p)
        elif self_path and not sc["scene_path"]:
            sc["scene_path"] = self_path
        sc["candidates"].append({
            "path": p,
            "mtime": st.st_mtime,
            "mtime_text": time.strftime("%Y/%m/%d %H:%M:%S", time.localtime(st.st_mtime)),
            "size": st.st_size,
            "self_path": self_path,
        })

    out = []
    for key, sc in scenes.items():
        if not sc["scene_path"]:
            sc["scene_path"] = sc["candidates"][0]["path"]
        base_dir = home_dir.get(key) or os.path.dirname(sc["scene_path"])
        sc["home_dir"] = base_dir
        stem = os.path.splitext(sc["scene_name"])[0]
        for c in sc["candidates"]:
            kind, label = _candidate_kind(c["path"], base_dir, stem)
            c["kind"] = kind
            c["label"] = label
            c["compressed"] = _is_compressed(c["path"])
        # A candidate much smaller than its peers has usually lost packed data
        # (images, sounds).  Compare only within the same compression class:
        # a compressed 44 MB file and an uncompressed 218 MB one can hold exactly
        # the same scene, and flagging that as damage would be a false alarm.
        for comp in (True, False):
            grp = [c for c in sc["candidates"] if c["compressed"] is comp]
            biggest = max((c["size"] for c in grp), default=0)
            for c in grp:
                c["suspect_small"] = bool(biggest and c["size"] < biggest * 0.6)

        sc["candidates"].sort(key=lambda c: c["mtime"], reverse=True)
        # What "one button" picks: the newest healthy snapshot Blender itself
        # produced.  Files this tool previously wrote are ranked last so a
        # recovery is never silently based on an earlier recovery.
        prio = {"autosave": 0, "restore": 0, "quit": 1, "crash": 1,
                "self": 2, "backup": 2, "recovered": 8, "other": 9}
        ranked = sorted(
            sc["candidates"],
            key=lambda c: (1 if c["suspect_small"] else 0,
                           prio.get(c["kind"], 9),
                           -c["mtime"]))
        best = ranked[0] if ranked else None
        for c in sc["candidates"]:
            c["recommended"] = bool(best is not None and c["path"] == best["path"])
        newest = sc["candidates"][0]
        sc["newest_mtime"] = newest["mtime"]
        sc["newest_mtime_text"] = newest["mtime_text"]
        sc["candidate_count"] = len(sc["candidates"])
        sc["recommended_path"] = best["path"] if best else ""
        sc["recommended_mtime_text"] = best["mtime_text"] if best else ""
        out.append(sc)

    out.sort(key=lambda s: s["newest_mtime"], reverse=True)
    progress("scan", 95, "")
    payload = {"schema": "jel_rescue/scan/1", "engine": VERSION,
               "generated": time.strftime("%Y-%m-%d %H:%M:%S"),
               "scanned_files": len(files), "scenes": out}
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=1)
    progress("scan", 100, "%d シーンを検出しました" % len(out))
    log("scan wrote %s (%d scenes from %d files)" % (out_json, len(out), len(files)))
    return 0


def read_crash_log(blend_path):
    """Blender writes <basename>.crash.txt next to the temp dir with the operator
    history.  Its tail describes the state the session died in, which is the best
    independent confirmation of which undo step is the newest."""
    if not blend_path:
        return None
    base = os.path.splitext(os.path.basename(blend_path))[0]
    for d in (os.environ.get("TEMP", ""), os.environ.get("TMP", ""),
              os.path.dirname(blend_path)):
        if not d:
            continue
        p = os.path.join(d, base + ".crash.txt")
        if os.path.isfile(p):
            try:
                with open(p, "r", encoding="utf-8", errors="replace") as f:
                    return {"path": p, "text": f.read()}
            except Exception:
                return None
    return None


def crash_log_expectations(text):
    """Pull the final, checkable facts out of a crash log's operator history."""
    exp = {}
    if not text:
        return exp
    m = None
    for m2 in re.finditer(r"active_material_index\s*=\s*(\d+)", text):
        m = m2
    if m:
        exp["actcol"] = int(m.group(1)) + 1        # RNA index is 0-based
    ops = re.findall(r"^bpy\.ops\.([a-z_]+\.[a-z_]+)", text, re.M)
    exp["last_ops"] = ops[-8:]
    return exp


def materialize_step(step, dm):
    """Assemble one step's .blend byte stream from its chunk list, on demand."""
    if step.get("blob") is not None:
        return step["blob"]
    parts = []
    for buf, sz in step["plan"]:
        d = dm.read(buf, sz)
        if d is None:
            return None
        parts.append(d)
    return b"".join(parts)


def rank_steps(steps, expectations=None):
    """Order steps newest-first.

    Primary signal is structural: `unique_bufs` counts chunk buffers that belong
    to this step and no other.  Blender reuses a buffer for every chunk that did
    not change since the previous step, so a step's freshly written buffers stay
    unique to it only until a later step reuses them -- which makes the newest
    step the one that keeps the most.

    When a crash log is available its final `active_material_index` gives an
    independent check, and steps that disagree with it are pushed down.
    """
    exp = expectations or {}
    for s in steps:
        i = s["info"]
        agree = 0
        if "actcol" in exp and i.get("actcol"):
            agree = 1 if i["actcol"] == exp["actcol"] else -1
        s["log_agree"] = agree
        s["score"] = s.get("unique_bufs", 0)
    order = sorted(range(len(steps)),
                   key=lambda k: (-steps[k]["log_agree"], -steps[k]["score"],
                                  -steps[k]["bytes"]))
    for rank, k in enumerate(order):
        steps[k]["rank"] = rank
    return order


# -------------------------------------------------------------------- driver

def cmd_analyze(dump_path, out_json):
    t0 = time.time()
    log("JEL Blender Crash Rescue engine %s" % VERSION)
    dm = open_source(dump_path)

    steps = find_undo_chains(dm)
    if not steps:
        progress("done", 100, "Undoデータなし")
        result = {"version": VERSION, "dump": dump_path, "steps": [], "error":
                  "このダンプにUndo memfileチェーンが見つかりませんでした。"}
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=1)
        return 3

    for i, s in enumerate(steps):
        progress("summary", 40 + int(50.0 * i / len(steps)), "内容を読み取り中")
        s["info"] = summarize_step(materialize_step(s, dm) or b"")

    blend_path = ""
    for s in steps:
        if s["info"].get("blend_path"):
            blend_path = s["info"]["blend_path"]
            break
    crash = read_crash_log(blend_path)
    exp = crash_log_expectations(crash["text"] if crash else "")
    if crash:
        log("  crash log: %s" % crash["path"])
    if "actcol" in exp:
        log("  crash log expects active material slot = %d" % exp["actcol"])
    rank_steps(steps, exp)

    out = []
    for i, s in enumerate(steps):
        e = dict(s["info"])
        e["index"] = i
        e["rank"] = s["rank"]
        e["chunks"] = s["chunks"]
        e["bytes"] = s["bytes"]
        e["unique_bufs"] = s.get("unique_bufs", 0)
        e["log_agree"] = s.get("log_agree", 0)
        e["head"] = "0x%X" % s["head"]
        out.append(e)
    out.sort(key=lambda e: e["rank"])

    result = {"version": VERSION, "dump": dump_path,
              "blend_path": blend_path,
              "crash_log": crash["path"] if crash else "",
              "expectations": exp,
              "elapsed_sec": round(time.time() - t0, 1), "steps": out}
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=1)
    progress("done", 100, "解析完了")
    log("analysis written: %s (%d steps, %.1fs)"
        % (out_json, len(out), time.time() - t0))
    dm.close()
    return 0


def cmd_extract(dump_path, index, out_blend):
    t0 = time.time()
    log("JEL Blender Crash Rescue engine %s" % VERSION)
    dm = open_source(dump_path)
    steps = find_undo_chains(dm)
    if index < 0 or index >= len(steps):
        log("ERROR: step index %d out of range (0..%d)" % (index, len(steps) - 1))
        return 4
    s = steps[index]
    log("  step %d: %d chunks, %.1f MB raw" % (index, s["chunks"], s["bytes"] / 1048576))

    progress("inline", 60, "共有データを復元中")
    raw = materialize_step(s, dm)
    if raw is None:
        log("ERROR: could not reassemble step %d" % index)
        return 6
    blob, stats = inline_shared(raw, dm)
    for k, v in sorted(stats.items()):
        log("    %-32s %d" % (k, v))
    failures = sum(v for k, v in stats.items() if k.startswith("FAIL"))

    progress("write", 90, "書き出し中")
    tmp = out_blend + ".part"
    with open(tmp, "wb") as f:
        f.write(blob)
    if os.path.exists(out_blend):
        os.remove(out_blend)
    os.rename(tmp, out_blend)
    size = os.path.getsize(out_blend)
    log("WROTE %s  %.1f MB (raw was %.1f MB)"
        % (out_blend, size / 1048576, s["bytes"] / 1048576))
    log("unresolved-reference failures: %d" % failures)
    progress("done", 100, "抽出完了 (%.1f MB)" % (size / 1048576))
    dm.close()
    return 0 if failures == 0 else 5


def cmd_rescue(source, out_blend, out_json=""):
    """One shot: find the undo chains, pick the newest, write it out.

    This is the one-button route.  Doing it in a single process is what makes it
    the fast one: `analyze` followed by `extract` walks all of memory twice and
    summarizes every step, and only one step is ever used.
    """
    t0 = time.time()
    log("JEL Blender Crash Rescue engine %s" % VERSION)
    src = open_source(source)

    steps = find_undo_chains(src)
    if not steps:
        progress("done", 100, "Undoデータなし")
        log("ERROR: no undo memfile chain found")
        return 3
    log("  undo steps found: %d" % len(steps))

    # Summarising a step means parsing its whole ~150 MB blob, so doing it for
    # every step does not scale: a 200-step stack cost 75 minutes of the first
    # real run, against 15 seconds for the actual reconstruction.
    #
    # `unique_bufs` already ranks steps and comes free from the chain walk, so
    # only the strongest few are summarised -- enough to cross-check the crash
    # log's final active_material_index, which is what identifies the true newest
    # step when several look alike.
    SUMMARY_BUDGET = 8
    for s in steps:
        s["info"] = {}
    order = sorted(range(len(steps)), key=lambda k: (-steps[k].get("unique_bufs", 0),
                                                     -steps[k]["bytes"]))
    short = order[:SUMMARY_BUDGET]
    log("  summarising the %d strongest of %d steps" % (len(short), len(steps)))
    for n, k in enumerate(short):
        progress("summary", 45 + int(35.0 * n / max(1, len(short))), "内容を読み取り中")
        steps[k]["info"] = summarize_step(materialize_step(steps[k], src) or b"")

    blend_path = ""
    for k in short:
        if steps[k]["info"].get("blend_path"):
            blend_path = steps[k]["info"]["blend_path"]
            break
    crash = read_crash_log(blend_path)
    exp = crash_log_expectations(crash["text"] if crash else "")
    if crash:
        log("  crash log: %s" % crash["path"])
    rank_steps(steps, exp)

    best = min(steps, key=lambda s: s["rank"])
    log("  newest step: %d chunks, %.1f MB raw, objects=%s meshes=%s"
        % (best["chunks"], best["bytes"] / 1048576,
           best["info"].get("objects"), best["info"].get("meshes")))

    progress("inline", 82, "共有データを復元中")
    raw = materialize_step(best, src)
    if raw is None:
        log("ERROR: could not reassemble the newest step")
        return 6
    blob, stats = inline_shared(raw, src)
    for k, v in sorted(stats.items()):
        log("    %-32s %d" % (k, v))
    failures = sum(v for k, v in stats.items() if k.startswith("FAIL"))

    progress("write", 94, "書き出し中")
    tmp = out_blend + ".part"
    with open(tmp, "wb") as f:
        f.write(blob)
    if os.path.exists(out_blend):
        os.remove(out_blend)
    os.rename(tmp, out_blend)
    log("WROTE %s  %.1f MB" % (out_blend, os.path.getsize(out_blend) / 1048576))

    if out_json:
        out = []
        for i, s in enumerate(steps):
            e = dict(s["info"])
            e.update(index=i, rank=s["rank"], chunks=s["chunks"], bytes=s["bytes"],
                     unique_bufs=s.get("unique_bufs", 0), log_agree=s.get("log_agree", 0),
                     head="0x%X" % s["head"])
            out.append(e)
        out.sort(key=lambda e: e["rank"])
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump({"version": VERSION, "source": str(source), "blend_path": blend_path,
                       "crash_log": crash["path"] if crash else "",
                       "elapsed_sec": round(time.time() - t0, 1), "steps": out},
                      f, ensure_ascii=False, indent=1)

    progress("done", 100, "復元完了 (%.0f 秒)" % (time.time() - t0))
    src.close()
    return 0 if failures == 0 else 5


def main(argv):
    if len(argv) < 2:
        log(__doc__)
        return 2
    cmd = argv[1]
    if cmd == "analyze" and len(argv) >= 4:
        return cmd_analyze(argv[2], argv[3])
    if cmd == "extract" and len(argv) >= 5:
        return cmd_extract(argv[2], int(argv[3]), argv[4])
    if cmd == "scan" and len(argv) >= 3:
        return cmd_scan(argv[2], argv[3:])
    if cmd == "rescue" and len(argv) >= 4:
        return cmd_rescue(argv[2], argv[3], argv[4] if len(argv) >= 5 else "")
    if cmd == "version":
        log(VERSION)
        return 0
    log("usage:\n  engine analyze <dump> <out.json>\n"
        "  engine extract <dump|pid:N> <step-index> <out.blend>\n"
        "  engine scan <out.json> [root ...]\n"
        "  engine rescue <dump|pid:N> <out.blend> [steps.json]\n"
        "  engine version")
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
