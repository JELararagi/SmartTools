# Copyright (C) 2026 JELararagi
"""Pure History Auto Save state machine for Smart File Suite 1.0.0.

The module has no Blender dependency.  It preserves dirty/deadline/boundary
state across extension reloads, separates load-restoration baselines from the
first real edit, and provides bounded failure backoff with one state-change
wake-up per blocked epoch.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from enum import Enum
from typing import Any, Mapping, Optional, Tuple


class DeadlineDecision(str, Enum):
    NOT_DUE = "NOT_DUE"
    SAVE = "SAVE"
    SKIP_UNCHANGED = "SKIP_UNCHANGED"
    DEFER = "DEFER"


class RuntimePhase(str, Enum):
    DISABLED = "DISABLED"
    RESTORING = "RESTORING"
    STARTING = "STARTING"
    ACTIVE = "ACTIVE"
    RETRYING = "RETRYING"
    ERROR = "ERROR"


class FailureKind(str, Enum):
    NONE = "NONE"
    SAVE_IN_PROGRESS = "SAVE_IN_PROGRESS"
    INTERFACE_LOCK = "INTERFACE_LOCK"
    RENDER = "RENDER"
    PLAYBACK = "PLAYBACK"
    MODAL = "MODAL"
    CONTEXT = "CONTEXT"
    STORAGE_PATH = "STORAGE_PATH"
    SAVE_CANCELLED = "SAVE_CANCELLED"
    SAVE_EXCEPTION = "SAVE_EXCEPTION"
    OUTPUT_MISSING = "OUTPUT_MISSING"
    OUTPUT_EMPTY = "OUTPUT_EMPTY"
    OUTPUT_STALE = "OUTPUT_STALE"
    OUTPUT_CORRUPT = "OUTPUT_CORRUPT"
    REGISTRATION = "REGISTRATION"
    TIMER = "TIMER"
    HANDLER = "HANDLER"
    SETTINGS_OWNER = "SETTINGS_OWNER"
    BOUNDARY = "BOUNDARY"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class ChangeSnapshot:
    event_serial: int
    data_is_dirty: bool
    external_counter: Tuple[int, ...] = ()
    file_identity: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_serial": int(self.event_serial),
            "data_is_dirty": bool(self.data_is_dirty),
            "external_counter": [int(value) for value in self.external_counter],
            "file_identity": str(self.file_identity or ""),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any] | None) -> "ChangeSnapshot":
        source = data if isinstance(data, Mapping) else {}
        raw_counter = source.get("external_counter", ())
        try:
            counter = tuple(int(value) for value in (raw_counter or ()))
        except Exception:
            counter = ()
        return cls(
            event_serial=int(source.get("event_serial", 0) or 0),
            data_is_dirty=bool(source.get("data_is_dirty", False)),
            external_counter=counter,
            file_identity=str(source.get("file_identity", "") or ""),
        )


@dataclass(frozen=True)
class BoundaryFailure:
    reason: str
    error: str
    attempted_monotonic: float
    saved_baseline: ChangeSnapshot
    observed_snapshot: ChangeSnapshot
    dirty_pending: bool
    orphaned_by_file_switch: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "reason": str(self.reason),
            "error": str(self.error),
            "attempted_monotonic": float(self.attempted_monotonic),
            "saved_baseline": self.saved_baseline.to_dict(),
            "observed_snapshot": self.observed_snapshot.to_dict(),
            "dirty_pending": bool(self.dirty_pending),
            "orphaned_by_file_switch": bool(self.orphaned_by_file_switch),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any] | None) -> Optional["BoundaryFailure"]:
        if not isinstance(data, Mapping):
            return None
        return cls(
            reason=str(data.get("reason", "") or ""),
            error=str(data.get("error", "") or ""),
            attempted_monotonic=float(data.get("attempted_monotonic", 0.0) or 0.0),
            saved_baseline=ChangeSnapshot.from_dict(data.get("saved_baseline")),
            observed_snapshot=ChangeSnapshot.from_dict(data.get("observed_snapshot")),
            dirty_pending=bool(data.get("dirty_pending", True)),
            orphaned_by_file_switch=bool(data.get("orphaned_by_file_switch", False)),
        )


class AutoSaveStateMachine:
    """Transaction state independent of Blender callbacks and RNA objects."""

    _BACKOFF = {
        FailureKind.SAVE_IN_PROGRESS: (2.0, 4.0, 8.0, 16.0, 32.0),
        FailureKind.INTERFACE_LOCK: (2.0, 4.0, 8.0, 16.0, 32.0),
        FailureKind.RENDER: (2.0, 4.0, 8.0, 16.0, 32.0),
        FailureKind.PLAYBACK: (2.0, 4.0, 8.0, 16.0, 32.0),
        FailureKind.MODAL: (2.0, 4.0, 8.0, 16.0, 32.0),
        FailureKind.CONTEXT: (2.0, 4.0, 8.0, 16.0, 32.0),
        FailureKind.STORAGE_PATH: (5.0, 15.0, 30.0, 60.0),
        FailureKind.SAVE_CANCELLED: (5.0, 15.0, 30.0, 60.0),
        FailureKind.SAVE_EXCEPTION: (5.0, 15.0, 30.0, 60.0),
        FailureKind.OUTPUT_MISSING: (5.0, 15.0, 30.0, 60.0),
        FailureKind.OUTPUT_EMPTY: (5.0, 15.0, 30.0, 60.0),
        FailureKind.OUTPUT_STALE: (5.0, 15.0, 30.0, 60.0),
        FailureKind.OUTPUT_CORRUPT: (5.0, 15.0, 30.0, 60.0),
        FailureKind.REGISTRATION: (2.0, 5.0, 15.0, 30.0, 60.0),
        FailureKind.TIMER: (2.0, 5.0, 15.0, 30.0, 60.0),
        FailureKind.HANDLER: (2.0, 5.0, 15.0, 30.0, 60.0),
        FailureKind.SETTINGS_OWNER: (2.0, 5.0, 15.0, 30.0, 60.0),
        FailureKind.BOUNDARY: (5.0, 15.0, 30.0, 60.0),
        FailureKind.UNKNOWN: (5.0, 15.0, 30.0, 60.0),
    }

    def __init__(self, generation: str):
        self.generation = str(generation)
        self.phase = RuntimePhase.DISABLED
        self.enabled = False
        self.watching = False
        self.interval_seconds = 300.0
        self.health_seconds = 900.0
        self.next_deadline: Optional[float] = None
        self.event_serial = 0

        initial = ChangeSnapshot(0, False, (), "")
        self.saved_snapshot = initial
        self.active_saved_snapshot = initial
        self.dirty_pending = False
        self.active_dirty_pending = False

        self.load_restore_pending = False
        self.load_restore_baseline: Optional[ChangeSnapshot] = None

        self.boundary_save_pending = False
        self.boundary_failure: Optional[BoundaryFailure] = None
        self.last_boundary_attempt_error = ""

        self.failure_kind = FailureKind.NONE
        self.retry_reason = ""
        self.next_retry_condition = ""
        self.consecutive_failures = 0
        self.last_blocker_signature = ""
        self.retry_epoch_signature = ""
        self.state_change_retry_used = False

        self.last_runtime_error = ""
        self.last_save_error = ""
        self.last_save_monotonic: Optional[float] = None
        self.last_success_file = ""

    def configure(self, *, interval_seconds: float, health_seconds: float = 900.0) -> None:
        self.interval_seconds = max(1.0, float(interval_seconds))
        self.health_seconds = max(900.0, float(health_seconds))

    def current_snapshot(
        self,
        *,
        data_is_dirty: bool,
        external_counter: Tuple[int, ...] = (),
        file_identity: str = "",
    ) -> ChangeSnapshot:
        return ChangeSnapshot(
            int(self.event_serial),
            bool(data_is_dirty),
            tuple(int(value) for value in external_counter),
            str(file_identity or ""),
        )

    @staticmethod
    def _same_file(left: ChangeSnapshot, right: ChangeSnapshot) -> bool:
        if not left.file_identity or not right.file_identity:
            return True
        return left.file_identity == right.file_identity

    @staticmethod
    def _snapshot_changed(baseline: ChangeSnapshot, current: ChangeSnapshot) -> bool:
        return bool(
            current.event_serial != baseline.event_serial
            or current.external_counter != baseline.external_counter
            # Copy-save does not clear bpy.data.is_dirty.  Only the clean->dirty
            # edge is evidence by itself; explicit event/counters carry later edits.
            or (current.data_is_dirty and not baseline.data_is_dirty)
        )

    def has_unsaved_change(self, current: ChangeSnapshot) -> bool:
        baseline = self.active_saved_snapshot
        if not self._same_file(baseline, current):
            return bool(self.active_dirty_pending)
        return bool(self.active_dirty_pending or self._snapshot_changed(baseline, current))

    def activate(self, now: float, initial: ChangeSnapshot, *, preserve: bool = True) -> None:
        self.enabled = True
        self.watching = False
        # A generation change may revalidate resources, but it must never erase a
        # pending save/blocker epoch.  Preserve RETRYING until the same transaction
        # succeeds or the blocking state changes.
        if preserve and (
            self.phase is RuntimePhase.RETRYING
            or self.boundary_save_pending
            or bool(self.last_runtime_error)
            or bool(self.last_save_error)
        ):
            self.phase = RuntimePhase.RETRYING
        else:
            self.phase = RuntimePhase.STARTING
        self.event_serial = max(self.event_serial, int(initial.event_serial))
        pristine = (
            self.next_deadline is None
            and not self.dirty_pending
            and not self.boundary_save_pending
            and self.last_save_monotonic is None
            and self.saved_snapshot == ChangeSnapshot(0, False, (), "")
        )
        if not preserve or pristine:
            self.saved_snapshot = initial
            self.active_saved_snapshot = initial
            self.active_dirty_pending = bool(initial.data_is_dirty)
            self.dirty_pending = bool(initial.data_is_dirty)
            self.next_deadline = float(now) + self.interval_seconds
        elif self.next_deadline is None:
            anchor = self.last_save_monotonic if self.last_save_monotonic is not None else float(now)
            self.next_deadline = float(anchor) + self.interval_seconds

    def deactivate(self, *, preserve_deadline: bool = True) -> None:
        self.enabled = False
        self.watching = False
        self.phase = RuntimePhase.DISABLED
        if not preserve_deadline:
            self.next_deadline = None

    def set_active(self) -> None:
        self.phase = RuntimePhase.ACTIVE
        self.watching = True
        self.last_runtime_error = ""
        if not self.last_save_error:
            self.failure_kind = FailureKind.NONE
            self.retry_reason = ""
            self.next_retry_condition = ""
            self.consecutive_failures = 0
            self.last_blocker_signature = ""
            self.retry_epoch_signature = ""
            self.state_change_retry_used = False

    def mark_event(self, now: float) -> None:
        self.event_serial += 1
        self.active_dirty_pending = True
        self.dirty_pending = True
        if self.next_deadline is None:
            self.next_deadline = float(now) + self.interval_seconds
        elif self.next_deadline < float(now):
            self.next_deadline = float(now)

    def note_dirty_probe(self, current: ChangeSnapshot) -> None:
        if self._snapshot_changed(self.active_saved_snapshot, current):
            self.active_dirty_pending = True
            self.dirty_pending = True

    def begin_load_restore(self, baseline: ChangeSnapshot) -> None:
        self.load_restore_pending = True
        self.load_restore_baseline = baseline
        if self.enabled:
            self.phase = RuntimePhase.RESTORING
            self.watching = False

    def finish_load_restore(self, current: ChangeSnapshot, now: float) -> bool:
        baseline = self.load_restore_baseline or self.active_saved_snapshot
        changed = bool(
            not self._same_file(baseline, current)
            or self._snapshot_changed(baseline, current)
        )
        if changed:
            self.active_dirty_pending = True
            self.dirty_pending = True
            # Critical invariant: never replace the saved checkpoint with the
            # edited current snapshot.  The first post-load edit remains pending.
            if self.next_deadline is None:
                self.next_deadline = float(now) + self.interval_seconds
        else:
            if self.boundary_save_pending and self.boundary_failure is not None:
                # Restore finalization is not a verified save. Keep the failed
                # boundary's old checkpoint and dirty epoch intact.
                self.active_saved_snapshot = self.boundary_failure.saved_baseline
                self.active_dirty_pending = True
                self.dirty_pending = True
            else:
                self.active_saved_snapshot = current
                self.active_dirty_pending = False
                self.saved_snapshot = current
                self.dirty_pending = False
        self.load_restore_pending = False
        self.load_restore_baseline = None
        if self.enabled:
            if self.boundary_save_pending or self.last_save_error or self.last_runtime_error:
                self.phase = RuntimePhase.RETRYING
                self.watching = False
            else:
                self.phase = RuntimePhase.STARTING
        return changed

    def on_file_loaded(self, current: ChangeSnapshot, now: float) -> None:
        failure = self.boundary_failure
        if (
            self.boundary_save_pending
            and failure is not None
            and failure.reason == "file_switch"
            and not self._same_file(failure.observed_snapshot, current)
        ):
            if not failure.orphaned_by_file_switch:
                self.boundary_failure = replace(failure, orphaned_by_file_switch=True)
            # Preserve old-file evidence.  The new file gets its own baseline.
            self.active_saved_snapshot = current
            self.active_dirty_pending = False
            self.dirty_pending = True
        elif self.boundary_save_pending and failure is not None:
            # A failed boundary for the still-open file is unresolved evidence.
            # Loading/reloading must not relabel the observed dirty snapshot as a
            # successful checkpoint. Keep the old saved baseline and dirty epoch.
            self.active_saved_snapshot = failure.saved_baseline
            self.active_dirty_pending = True
            self.dirty_pending = True
        else:
            self.saved_snapshot = current
            self.active_saved_snapshot = current
            self.active_dirty_pending = False
            self.dirty_pending = False
        self.event_serial = max(self.event_serial, int(current.event_serial))
        self.load_restore_pending = False
        self.load_restore_baseline = None
        # A load is not a successful autosave.  Preserve the original deadline.
        if self.next_deadline is None:
            anchor = self.last_save_monotonic if self.last_save_monotonic is not None else float(now)
            self.next_deadline = float(anchor) + self.interval_seconds

    def due(self, now: float) -> bool:
        return bool(self.enabled and self.next_deadline is not None and float(now) >= self.next_deadline)

    def decide(
        self,
        *,
        now: float,
        current: ChangeSnapshot,
        skip_unchanged: bool,
        blocker: FailureKind = FailureKind.NONE,
    ) -> DeadlineDecision:
        if not self.due(now):
            return DeadlineDecision.NOT_DUE
        self.note_dirty_probe(current)
        if blocker is not FailureKind.NONE:
            return DeadlineDecision.DEFER
        if skip_unchanged and not self.has_unsaved_change(current):
            self.advance_regular_deadline(now)
            return DeadlineDecision.SKIP_UNCHANGED
        return DeadlineDecision.SAVE

    def advance_regular_deadline(self, now: float) -> None:
        self.next_deadline = float(now) + self.interval_seconds
        self.consecutive_failures = 0
        self.failure_kind = FailureKind.NONE
        self.retry_reason = ""
        self.next_retry_condition = ""
        self.last_blocker_signature = ""
        self.retry_epoch_signature = ""
        self.state_change_retry_used = False

    def _backoff_delay(self, kind: FailureKind) -> float:
        schedule = self._BACKOFF.get(kind, self._BACKOFF[FailureKind.UNKNOWN])
        index = min(max(self.consecutive_failures - 1, 0), len(schedule) - 1)
        delay = float(schedule[index])
        if self.consecutive_failures > len(schedule):
            delay = max(delay, self.health_seconds)
        return max(1.0, delay)

    def record_retry(
        self,
        *,
        now: float,
        kind: FailureKind,
        reason: str,
        next_condition: str,
        blocker_signature: str = "",
        save_error: bool = False,
    ) -> float:
        if kind is FailureKind.NONE:
            kind = FailureKind.UNKNOWN
        epoch_signature = f"{kind.value}:{str(reason or kind.value)}"
        same_epoch = kind == self.failure_kind and epoch_signature == self.retry_epoch_signature
        if not same_epoch:
            self.consecutive_failures = 0
            self.state_change_retry_used = False
        self.consecutive_failures += 1
        self.failure_kind = kind
        self.retry_reason = str(reason or kind.value)
        self.next_retry_condition = str(next_condition or "health deadline")
        self.retry_epoch_signature = epoch_signature
        self.last_blocker_signature = str(blocker_signature or "")
        self.last_runtime_error = self.retry_reason
        if save_error:
            self.last_save_error = self.retry_reason
            self.active_dirty_pending = True
            self.dirty_pending = True
        self.phase = RuntimePhase.RETRYING
        self.watching = False
        delay = self._backoff_delay(kind)
        self.next_deadline = float(now) + delay
        return delay

    def notify_state_change(self, *, now: float, blocker_signature: str) -> bool:
        """Allow one immediate retry when the blocking state actually changes."""
        signature = str(blocker_signature or "")
        if self.phase is not RuntimePhase.RETRYING:
            return False
        if signature == self.last_blocker_signature or self.state_change_retry_used:
            return False
        self.last_blocker_signature = signature
        self.state_change_retry_used = True
        self.next_deadline = float(now)
        return True

    def record_save_success(self, *, now: float, current: ChangeSnapshot, filepath: str = "") -> None:
        """Commit a verified save without erasing an older boundary failure.

        A file-switch failure belongs to the file that was active at the failed
        boundary.  Once a different file is loaded, a successful save of the new
        file may establish that file's active checkpoint, but it must not replace
        the old saved baseline, clear ``boundary_save_pending``, or report ACTIVE.
        """
        failure = self.boundary_failure if self.boundary_save_pending else None
        orphaned_other_file = bool(
            failure is not None
            and failure.orphaned_by_file_switch
            and not self._same_file(failure.observed_snapshot, current)
        )
        if orphaned_other_file:
            self.active_saved_snapshot = current
            self.active_dirty_pending = False
            self.dirty_pending = True
            self.last_save_monotonic = float(now)
            self.last_success_file = str(filepath or self.last_success_file)
            # Preserve the original failure as the authoritative unresolved state.
            self.last_boundary_attempt_error = str(failure.error)
            self.last_save_error = str(failure.error)
            self.last_runtime_error = str(failure.error)
            self.failure_kind = FailureKind.BOUNDARY
            self.retry_reason = str(failure.error)
            self.next_retry_condition = (
                "old file is no longer available; diagnostic retained until an "
                "explicit same-file boundary can be verified"
            )
            self.phase = RuntimePhase.RETRYING
            self.watching = False
            self.next_deadline = float(now) + self.interval_seconds
            return

        # A generic save result never resolves a boundary transaction by
        # implication. Callers performing the explicit catch-up transaction use
        # record_boundary_success(), which validates file identity before clear.
        if failure is not None:
            self.active_saved_snapshot = current
            self.active_dirty_pending = False
            self.dirty_pending = True
            self.last_save_monotonic = float(now)
            self.last_success_file = str(filepath or self.last_success_file)
            self.last_boundary_attempt_error = str(failure.error)
            self.last_save_error = str(failure.error)
            self.last_runtime_error = str(failure.error)
            self.failure_kind = FailureKind.BOUNDARY
            self.retry_reason = str(failure.error)
            self.next_retry_condition = "explicit boundary catch-up verification"
            self.phase = RuntimePhase.RETRYING
            self.watching = False
            return

        self.active_saved_snapshot = current
        self.active_dirty_pending = False
        self.saved_snapshot = current
        self.dirty_pending = False
        self.last_save_monotonic = float(now)
        self.last_success_file = str(filepath or self.last_success_file)
        self.last_save_error = ""
        self.last_runtime_error = ""
        self.set_active()
        self.advance_regular_deadline(now)

    def record_save_failure(
        self,
        *,
        now: float,
        error: str,
        kind: FailureKind = FailureKind.SAVE_EXCEPTION,
    ) -> float:
        return self.record_retry(
            now=now,
            kind=kind,
            reason=str(error),
            next_condition="save backoff deadline or storage-state change",
            blocker_signature=f"{kind.value}:{error}",
            save_error=True,
        )

    def _orphan_pending(self) -> bool:
        return bool(
            self.boundary_save_pending
            and self.boundary_failure is not None
            and self.boundary_failure.orphaned_by_file_switch
        )

    def record_boundary_failure(
        self,
        *,
        reason: str,
        error: str,
        now: float,
        current: ChangeSnapshot,
        kind: FailureKind = FailureKind.BOUNDARY,
    ) -> None:
        self.last_boundary_attempt_error = str(error)
        self.last_save_error = str(error)
        self.last_runtime_error = str(error)
        self.active_dirty_pending = True
        self.dirty_pending = True
        if not (self.boundary_failure is not None and self.boundary_failure.orphaned_by_file_switch):
            self.boundary_failure = BoundaryFailure(
                reason=str(reason),
                error=str(error),
                attempted_monotonic=float(now),
                saved_baseline=self.saved_snapshot,
                observed_snapshot=current,
                dirty_pending=True,
                orphaned_by_file_switch=False,
            )
        self.boundary_save_pending = True
        # Boundary failures participate in the same bounded backoff as regular
        # save failures.  Without a new state-change event, repeated callbacks
        # eventually fall back to the 15-minute health deadline.
        self.record_retry(
            now=float(now),
            kind=kind,
            reason=str(error),
            next_condition="next explicit safe boundary, state change, or health deadline",
            blocker_signature=f"{kind.value}:{reason}:{error}",
            save_error=True,
        )

    def pending_boundary_applies_to(self, current: ChangeSnapshot) -> bool:
        failure = self.boundary_failure
        return bool(
            self.boundary_save_pending
            and failure is not None
            and not failure.orphaned_by_file_switch
            and self._same_file(failure.observed_snapshot, current)
        )

    def record_boundary_success(self, *, now: float, current: ChangeSnapshot, filepath: str = "") -> bool:
        failure = self.boundary_failure
        if failure is None or not self.boundary_save_pending:
            self.record_save_success(now=now, current=current, filepath=filepath)
            return True
        if failure.orphaned_by_file_switch and not self._same_file(failure.observed_snapshot, current):
            self.record_save_success(now=now, current=current, filepath=filepath)
            self.last_boundary_attempt_error = failure.error
            self.last_save_error = failure.error
            self.last_runtime_error = failure.error
            self.failure_kind = FailureKind.BOUNDARY
            self.retry_reason = failure.error
            self.next_retry_condition = "old file is no longer available; diagnostic retained"
            self.phase = RuntimePhase.RETRYING
            self.watching = False
            return False
        self.boundary_save_pending = False
        self.boundary_failure = None
        self.last_boundary_attempt_error = ""
        self.record_save_success(now=now, current=current, filepath=filepath)
        return True

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": 2,
            "generation": self.generation,
            "phase": self.phase.value,
            "enabled": bool(self.enabled),
            "watching": bool(self.watching),
            "interval_seconds": float(self.interval_seconds),
            "health_seconds": float(self.health_seconds),
            "next_deadline": self.next_deadline,
            "event_serial": int(self.event_serial),
            "saved_snapshot": self.saved_snapshot.to_dict(),
            "active_saved_snapshot": self.active_saved_snapshot.to_dict(),
            "dirty_pending": bool(self.dirty_pending),
            "active_dirty_pending": bool(self.active_dirty_pending),
            "load_restore_pending": bool(self.load_restore_pending),
            "load_restore_baseline": self.load_restore_baseline.to_dict() if self.load_restore_baseline else None,
            "boundary_save_pending": bool(self.boundary_save_pending),
            "boundary_failure": self.boundary_failure.to_dict() if self.boundary_failure else None,
            "last_boundary_attempt_error": self.last_boundary_attempt_error,
            "failure_kind": self.failure_kind.value,
            "retry_reason": self.retry_reason,
            "next_retry_condition": self.next_retry_condition,
            "consecutive_failures": int(self.consecutive_failures),
            "last_blocker_signature": self.last_blocker_signature,
            "retry_epoch_signature": self.retry_epoch_signature,
            "state_change_retry_used": bool(self.state_change_retry_used),
            "last_runtime_error": self.last_runtime_error,
            "last_save_error": self.last_save_error,
            "last_save_monotonic": self.last_save_monotonic,
            "last_success_file": self.last_success_file,
        }

    @classmethod
    def from_dict(cls, generation: str, data: Mapping[str, Any] | None) -> "AutoSaveStateMachine":
        state = cls(generation)
        source = data if isinstance(data, Mapping) else {}
        try:
            state.phase = RuntimePhase(str(source.get("phase", RuntimePhase.DISABLED.value)))
        except Exception:
            state.phase = RuntimePhase.DISABLED
        state.enabled = bool(source.get("enabled", False))
        state.watching = False  # resources must be revalidated in the new generation
        state.interval_seconds = max(1.0, float(source.get("interval_seconds", 300.0) or 300.0))
        state.health_seconds = max(900.0, float(source.get("health_seconds", 900.0) or 900.0))
        raw_deadline = source.get("next_deadline")
        state.next_deadline = float(raw_deadline) if raw_deadline is not None else None
        state.event_serial = int(source.get("event_serial", 0) or 0)
        state.saved_snapshot = ChangeSnapshot.from_dict(source.get("saved_snapshot"))
        state.active_saved_snapshot = ChangeSnapshot.from_dict(source.get("active_saved_snapshot"))
        state.dirty_pending = bool(source.get("dirty_pending", False))
        state.active_dirty_pending = bool(source.get("active_dirty_pending", False))
        state.load_restore_pending = bool(source.get("load_restore_pending", False))
        baseline = source.get("load_restore_baseline")
        state.load_restore_baseline = ChangeSnapshot.from_dict(baseline) if isinstance(baseline, Mapping) else None
        state.boundary_save_pending = bool(source.get("boundary_save_pending", False))
        state.boundary_failure = BoundaryFailure.from_dict(source.get("boundary_failure"))
        state.last_boundary_attempt_error = str(source.get("last_boundary_attempt_error", "") or "")
        try:
            state.failure_kind = FailureKind(str(source.get("failure_kind", FailureKind.NONE.value)))
        except Exception:
            state.failure_kind = FailureKind.UNKNOWN
        state.retry_reason = str(source.get("retry_reason", "") or "")
        state.next_retry_condition = str(source.get("next_retry_condition", "") or "")
        state.consecutive_failures = max(0, int(source.get("consecutive_failures", 0) or 0))
        state.last_blocker_signature = str(source.get("last_blocker_signature", "") or "")
        state.retry_epoch_signature = str(source.get("retry_epoch_signature", "") or "")
        state.state_change_retry_used = bool(source.get("state_change_retry_used", False))
        state.last_runtime_error = str(source.get("last_runtime_error", "") or "")
        state.last_save_error = str(source.get("last_save_error", "") or "")
        raw_last_save = source.get("last_save_monotonic")
        state.last_save_monotonic = float(raw_last_save) if raw_last_save is not None else None
        state.last_success_file = str(source.get("last_success_file", "") or "")
        return state

    def status(
        self,
        *,
        generation_matches: bool,
        handlers_ok: bool,
        timer_ok: bool,
        settings_owner_ok: bool,
        lifecycle_owner_ok: bool,
        registered: bool,
        requested_enabled: bool,
    ) -> dict[str, Any]:
        active = bool(
            requested_enabled
            and registered
            and generation_matches
            and handlers_ok
            and timer_ok
            and settings_owner_ok
            and lifecycle_owner_ok
            and self.phase is RuntimePhase.ACTIVE
            and self.enabled
            and self.watching
            and not self.boundary_save_pending
            and not self.last_runtime_error
            and not self.last_save_error
        )
        phase = RuntimePhase.ACTIVE.value if active else self.phase.value
        if not requested_enabled:
            # Feature resources may be OFF while a failed final boundary remains
            # diagnostically RETRYING.  Do not hide that failure as DISABLED.
            phase = (
                RuntimePhase.RETRYING.value
                if self.boundary_save_pending or self.last_save_error or self.last_runtime_error
                else RuntimePhase.DISABLED.value
            )
        return {
            "generation": self.generation,
            "phase": phase,
            "requested_enabled": bool(requested_enabled),
            "enabled": active,
            "watching": active,
            "registered": bool(registered),
            "generation_matches": bool(generation_matches),
            "handlers_ok": bool(handlers_ok),
            "timer_ok": bool(timer_ok),
            "settings_owner_ok": bool(settings_owner_ok),
            "lifecycle_owner_ok": bool(lifecycle_owner_ok),
            "dirty_pending": bool(self.dirty_pending or self.active_dirty_pending),
            "boundary_save_pending": bool(self.boundary_save_pending),
            "boundary_failure": self.boundary_failure.to_dict() if self.boundary_failure else None,
            "last_boundary_attempt_error": self.last_boundary_attempt_error,
            "last_runtime_error": self.last_runtime_error,
            "last_save_error": self.last_save_error,
            "retrying_reason": self.retry_reason,
            "failure_kind": self.failure_kind.value,
            "next_retry_condition": self.next_retry_condition,
            "next_deadline": self.next_deadline,
            "last_save_monotonic": self.last_save_monotonic,
            "last_success_file": self.last_success_file,
        }


