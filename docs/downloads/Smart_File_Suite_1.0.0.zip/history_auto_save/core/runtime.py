# ------------------------------------------------------------------------------
# Copyright (C) 2026 JELararagi
#
# License:
# - Copyright (C) 2026 JELararagi.
# - Licensed under the GNU General Public License v3.0 or later (GPL-3.0-or-later).
# ------------------------------------------------------------------------------
"""Generation-owned History Auto Save runtime for Smart File Suite 1.0.0.

The runtime is event-driven.  While enabled it owns one logical deadline
scheduler and one exact set of Blender handlers.  GUI sessions also keep one
low-frequency WindowManager event-timer watchdog for the same scheduler because
Blender 5.1 can report a persistent ``bpy.app.timers`` callback as registered
after file-load boundaries while never dispatching it.  There is no all-input
polling and no status-runtime handler instrumentation.  Dirty checkpoints and
deadlines live in ``driver_namespace`` so in-process extension reloads do not
baseline away unsaved work.
"""
from __future__ import annotations

from ...ui_language_runtime import ui_text as _ui_text
import atexit
import os
import sys
import time
import uuid
from contextlib import contextmanager
from collections.abc import Mapping
from typing import Any, Callable, Iterable, Optional

import bpy
from bpy.app.handlers import persistent

from .context_utils import (
    active_object_name,
    addon_prefs,
    frame_current,
    infer_project_key,
    is_managed_snapshot_file,
    mode_name,
    now_str,
    scene_name,
    scene_settings,
    selected_count,
    selection_signature,
)
from .state_machine_v57536 import (
    AutoSaveStateMachine,
    ChangeSnapshot,
    DeadlineDecision,
    FailureKind,
    RuntimePhase,
)
from .storage import (
    get_last_verified_write_result,
    save_snapshot_copy,
    sync_entries_with_disk,
    trim_old_files,
)


# Compatibility diagnostics retained for existing callers/tests.  These values
# advance only after verified transactions.
_RUNTIME = {
    "change_counter": 0,
    "last_restore_snapshot_time": 0.0,
    "last_autosave_time": 0.0,
    "last_restore_change_counter": 0,
    "last_autosave_change_counter": 0,
    "last_runtime_error": "",
    "last_save_error": "",
    "snapshot_save_depth": 0,
    "internal_depsgraph_suppressed": 0,
    "suspend_restore": False,
    "file_open_restore_last_error": "",
}

_SF_VERSION = "1.0.0"
_SF_FAILURE_KIND_TIMER = FailureKind.TIMER
_SF_MODAL_TIMER_RECURSION_REASON = "modal autosave scheduler timer setup recursion: RecursionError"
_SF_MODAL_TIMER_RECURSION_NEXT_CONDITION = "WindowManager modal timer availability or app timer dispatch"
_SF_MODAL_TIMER_RECURSION_EPOCH_SIGNATURE = "timer:modal autosave scheduler timer setup recursion: RecursionError"
_SF_MODAL_TIMER_RECURSION_BLOCKER_SIGNATURE = "modal_scheduler_timer_recursion"
_SF_MODAL_TIMER_RECURSION_RETRY_DELAY = 2.0

_HISTORY_ENTRY_HARD_LIMIT = 2048
_SAFETY_BACKUP_HARD_LIMIT = 200
_SF_RUNTIME_LEDGER_KEY = "JELararagi.smart_file.history_auto_save.runtime.v57540"
_SF_RUNTIME_LEGACY_LEDGER_KEYS = (
    "JELararagi.smart_file.history_auto_save.runtime.v57539",
    "JELararagi.smart_file.history_auto_save.runtime.v57536",
    "JELararagi.smart_file.history_auto_save.runtime.v57535",
    "JELararagi.smart_file.history_auto_save.runtime.v57534",
    "JELararagi.smart_file.history_auto_save.runtime.v57533",
    "JELararagi.smart_file.history_auto_save.runtime.v57532",
    "JELararagi.smart_file.history_auto_save.runtime.v57531",
    "JELararagi.smart_file.history_auto_save.runtime.v57530",
)
_SF_RUNTIME_STATE_KEY = "JELararagi.smart_file.history_auto_save.state.v2"
_SF_RUNTIME_DIAGNOSTIC_KEY = "JELararagi.smart_file.history_auto_save.diagnostic.v2"
_SF_RUNTIME_TOKEN = object()
_SF_RUNTIME_GENERATION = uuid.uuid4().hex
_SF_STATE = AutoSaveStateMachine(_SF_RUNTIME_GENERATION)
_SF_STATE_ADOPTED = False
_SF_CLOCK = {
    "autosave_deadline": None,
    "restore_deadline": None,
    "load_finalize_at": None,
    # File-open restore copies are deferred until the already-owned recurring
    # callback next wakes.  Load baseline finalization itself is synchronous and
    # never depends on unregister/register from inside load_post.
    "file_open_restore_pending_since": None,
    "file_open_restore_pending_identity": None,
    "file_open_restore_retry_at": None,
    "file_open_restore_failures": 0.0,
    "last_autosave_monotonic": None,
    "last_restore_monotonic": None,
    # Last canonical autosave configuration applied to the feature clock. These
    # values distinguish a real enable/interval change from ordinary lifecycle
    # validation without discarding dirty state.
    "configured_autosave_enabled": None,
    "configured_autosave_interval": None,
    # Actual Blender timer wake. Feature deadlines remain separate so reloads
    # cannot baseline or postpone unsaved work.
    "timer_wake_at": None,
    # After Blender file-load/save boundaries we may need to rotate to a fresh
    # same-generation native callback.  Blender 5.1 can still report the new
    # callback as registered while it later stops dispatching once it returns a
    # long feature-deadline sleep.  Keep a short health wake until the next
    # autosave deadline is actually processed; a clean health wake performs no
    # file I/O and is cleared by autosave success/skip.
    "timer_liveness_until": None,
}

_SF_LEDGER_INSTALLED = False
_SF_REGISTERED = False
_SF_HANDLER_RECORDS: list[dict[str, Any]] = []
_SF_TIMER_CALLBACK = None
_SF_TIMER_EXECUTING_CALLBACK = None
_SF_TIMER_KIND = ""
_SF_ATEXIT_REGISTERED = False
_SF_AUTOSAVE_LATCHED = False
_SF_SAVE_DEPTH = 0
_SF_INTERNAL_MUTATION_DEPTH = 0
_SF_INTERNAL_SCENE_UPDATE_ACKS: dict[tuple[int, str], dict[str, Any]] = {}
_SF_INTERNAL_SCENE_ACK_FLUSH_DEPTH = 0
_SF_INTERNAL_SCENE_ACK_FLUSH_DIRTY = False
_SF_INTERNAL_SCENE_ACK_CALLBACK_COUNT = 0
_SF_INTERNAL_SCENE_ACK_REENTRANT = False
_SF_INTERNAL_SCENE_ACK_EPOCH = 0
_SF_INTERNAL_HISTORY_REVISION = 0
_SF_INTERNAL_SCENE_ACK_TTL_SECONDS = 5.0
_SF_INTERNAL_SCENE_ACK_MAX_CHANNELS = 16
_SF_BOUNDARY_ATTEMPTS: set[str] = set()
_SF_LAST_BOUNDARY_RESULT: dict[str, Any] = {}
_SF_LIFECYCLE_TOKEN = None
_SF_LIFECYCLE_GENERATION = ""
_SF_LIFECYCLE_VALIDATOR: Optional[Callable[[], bool]] = None
_SF_LAST_BLOCKER_SIGNATURE = ""
_SF_LOAD_POST_DEPTH = 0
_SF_LOAD_POST_REPAIR_PENDING = False
_SF_SAVE_POST_REPAIR_PENDING = False
_SF_MODAL_PUMP_CLASS_REGISTERED = False
_SF_MODAL_PUMP_INSTANCE = None
_SF_MODAL_EVENT_TIMER = None
_SF_MODAL_OWNER_TOKEN = None
_SF_MODAL_OWNER_GENERATION = ""
_SF_MODAL_WAKE_AT = None
_SF_MODAL_KIND = ""
_SF_MODAL_STARTING = False
_SF_MODAL_PUMP_EXECUTING = False
_SF_MODAL_UNREGISTER_CLASS_PENDING = False
_SF_MODAL_UNREGISTER_CLASS_DEADLINE = None


class _HistoryAckOutcome:
    """Private three-way result while preserving the five-value save tuple."""

    __slots__ = (
        "status",
        "reason",
        "matched_callbacks",
        "untouched_channels",
        "callback_count",
        "proof_kind",
    )

    def __init__(
        self,
        status: str,
        reason: str = "",
        *,
        matched_callbacks: int = 0,
        untouched_channels: int = 0,
        callback_count: int = 0,
        proof_kind: str = "",
    ) -> None:
        self.status = str(status or "DIRTY_REARM")
        self.reason = str(reason or "")
        self.matched_callbacks = int(matched_callbacks or 0)
        self.untouched_channels = int(untouched_channels or 0)
        self.callback_count = int(callback_count or 0)
        self.proof_kind = str(proof_kind or "")

    def __bool__(self) -> bool:
        return self.status == "CLEAN"


def _history_ack_outcome(
    status: str,
    reason: str = "",
    *,
    matched_callbacks: int = 0,
    untouched_channels: int = 0,
    callback_count: int = 0,
    proof_kind: str = "",
) -> _HistoryAckOutcome:
    return _HistoryAckOutcome(
        status,
        reason,
        matched_callbacks=matched_callbacks,
        untouched_channels=untouched_channels,
        callback_count=callback_count,
        proof_kind=proof_kind,
    )


def _history_ack_aborted(value: Any) -> bool:
    return _normalize_history_ack(value).status == "ABORT_WORLD_CHANGED"


def _normalize_history_ack(value: Any) -> _HistoryAckOutcome:
    """Normalize legacy bool fixtures without confusing dirty and world abort."""
    if isinstance(value, _HistoryAckOutcome):
        return value
    if bool(value):
        return _history_ack_outcome("CLEAN", "legacy truthy History ACK")
    return _history_ack_outcome(
        "DIRTY_REARM", "legacy falsy History ACK conservatively re-armed"
    )


def _namespace() -> Optional[dict]:
    try:
        value = getattr(getattr(bpy, "app", None), "driver_namespace", None)
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _ledger() -> Optional[dict]:
    namespace = _namespace()
    value = namespace.get(_SF_RUNTIME_LEDGER_KEY) if namespace is not None else None
    return value if isinstance(value, dict) else None


def _is_current_generation() -> bool:
    ledger = _ledger()
    return bool(
        ledger
        and ledger.get("token") is _SF_RUNTIME_TOKEN
        and ledger.get("generation") == _SF_RUNTIME_GENERATION
    )


def _error_text(exc: BaseException | str) -> str:
    if isinstance(exc, BaseException):
        return f"{type(exc).__name__}: {exc}"
    return str(exc or "")


def _settings_apply_suspended() -> bool:
    try:
        from ... import settings as suite_settings

        return bool(
            getattr(suite_settings, "_STARTUP_RESTORE_PENDING", False)
            or getattr(suite_settings, "_APPLYING", False)
        )
    except Exception:
        return False


def bind_lifecycle_owner(token, generation: str, validator: Callable[[], bool]) -> bool:
    """Bind the sole History lifecycle owner before runtime registration."""
    global _SF_LIFECYCLE_TOKEN, _SF_LIFECYCLE_GENERATION, _SF_LIFECYCLE_VALIDATOR
    if token is None or not str(generation or "") or not callable(validator):
        _SF_STATE.last_runtime_error = "invalid History lifecycle owner binding"
        return False
    _SF_LIFECYCLE_TOKEN = token
    _SF_LIFECYCLE_GENERATION = str(generation)
    _SF_LIFECYCLE_VALIDATOR = validator
    return True


def unbind_lifecycle_owner(token=None, generation: str | None = None) -> bool:
    global _SF_LIFECYCLE_TOKEN, _SF_LIFECYCLE_GENERATION, _SF_LIFECYCLE_VALIDATOR
    if token is not None and token is not _SF_LIFECYCLE_TOKEN:
        return False
    if generation is not None and str(generation) != _SF_LIFECYCLE_GENERATION:
        return False
    _SF_LIFECYCLE_TOKEN = None
    _SF_LIFECYCLE_GENERATION = ""
    _SF_LIFECYCLE_VALIDATOR = None
    return True


def _lifecycle_owner_ok() -> bool:
    if _SF_LIFECYCLE_TOKEN is None or not _SF_LIFECYCLE_GENERATION:
        return False
    validator = _SF_LIFECYCLE_VALIDATOR
    if not callable(validator):
        return False
    try:
        return bool(validator())
    except Exception:
        return False


def _settings_owner_status() -> dict[str, Any]:
    """Read the already-loaded canonical settings owner without importing."""
    try:
        package = str(__package__ or "")
        root = package.split(".history_auto_save", 1)[0] if ".history_auto_save" in package else package
        suite_settings = sys.modules.get(f"{root}.settings") if root else None
        status_fn = getattr(suite_settings, "runtime_status", None) if suite_settings is not None else None
        if callable(status_fn):
            result = status_fn()
            return result if isinstance(result, dict) else {"registered": False}
    except Exception as exc:
        return {"registered": False, "last_error": _error_text(exc)}
    return {"registered": False, "last_error": "settings runtime status unavailable"}


def _settings_owner_ok() -> bool:
    status = _settings_owner_status()
    return bool(
        status.get("registered")
        and status.get("owner_ok")
        and status.get("handlers_ok")
        and status.get("subscriptions_ok")
        and status.get("subscription_owner_exact")
    )


def _persist_state() -> bool:
    namespace = _namespace()
    if namespace is None:
        return False
    try:
        namespace[_SF_RUNTIME_STATE_KEY] = {
            "schema": 2,
            "suite_version": _SF_VERSION,
            "state": _SF_STATE.to_dict(),
            "clock": dict(_SF_CLOCK),
            "compat_runtime": {
                key: _RUNTIME.get(key)
                for key in (
                    "change_counter",
                    "last_restore_snapshot_time",
                    "last_autosave_time",
                    "last_restore_change_counter",
                    "last_autosave_change_counter",
                    "last_runtime_error",
                    "last_save_error",
                    "file_open_restore_last_error",
                )
            },
        }
        return True
    except Exception:
        return False


def _adopt_persistent_state() -> None:
    global _SF_STATE, _SF_STATE_ADOPTED
    if _SF_STATE_ADOPTED:
        return
    _SF_STATE_ADOPTED = True
    namespace = _namespace()
    payload = namespace.get(_SF_RUNTIME_STATE_KEY) if namespace is not None else None
    if not isinstance(payload, Mapping):
        return
    try:
        _SF_STATE = AutoSaveStateMachine.from_dict(
            _SF_RUNTIME_GENERATION, payload.get("state")
        )
        legacy_load_pending = bool(
            _SF_STATE.load_restore_pending
            or _SF_STATE.load_restore_baseline is not None
        )
        clock = payload.get("clock")
        if isinstance(clock, Mapping):
            for key in tuple(_SF_CLOCK):
                if key == "load_finalize_at":
                    # Pre-1.0.0 development builds persisted an overdue load wake that
                    # could re-enter the proven false-live timer replacement
                    # path after hot reload. Load finalization is synchronous now;
                    # the legacy clock is migration-only and must never survive.
                    _SF_CLOCK[key] = None
                    continue
                value = clock.get(key)
                if key == "file_open_restore_pending_identity":
                    _SF_CLOCK[key] = str(value) if value else None
                else:
                    _SF_CLOCK[key] = float(value) if value is not None else None
            if (
                _SF_CLOCK.get("file_open_restore_pending_since") is not None
                and not _SF_CLOCK.get("file_open_restore_pending_identity")
            ):
                # A legacy timestamp has no safe project provenance. Dropping the
                # optional restore request is safer than writing it into whatever
                # file namespace happens to be active after reload.
                _SF_CLOCK["file_open_restore_pending_since"] = None
                _SF_CLOCK["file_open_restore_retry_at"] = None
                _SF_CLOCK["file_open_restore_failures"] = 0.0
        compat = payload.get("compat_runtime")
        if isinstance(compat, Mapping):
            for key in compat:
                if key in _RUNTIME:
                    _RUNTIME[key] = compat.get(key)
        if legacy_load_pending:
            # Earlier generations could persist RESTORING forever behind an
            # overdue load timer. The current loaded image is the only safe new
            # file baseline, but the unresolved epoch remains dirty fail-open so
            # one later verified autosave is required before it can become clean.
            current = _safe_snapshot(getattr(bpy, "context", None))
            _SF_STATE.load_restore_pending = False
            _SF_STATE.load_restore_baseline = None
            _SF_STATE.active_saved_snapshot = current
            _SF_STATE.active_dirty_pending = True
            _SF_STATE.dirty_pending = True
            if _SF_STATE.phase is RuntimePhase.RESTORING:
                _SF_STATE.phase = RuntimePhase.STARTING
                _SF_STATE.watching = False
    except Exception as exc:
        _SF_STATE = AutoSaveStateMachine(_SF_RUNTIME_GENERATION)
        _SF_STATE.last_runtime_error = f"persistent runtime state rejected: {_error_text(exc)}"


def _prefs(context=None):
    try:
        return addon_prefs(context)
    except Exception:
        return None


def _autosave_enabled(prefs=None) -> bool:
    prefs = prefs or _prefs()
    return bool(prefs is not None and getattr(prefs, "enable_autosave", False))


def _restore_enabled(prefs=None) -> bool:
    prefs = prefs or _prefs()
    return bool(prefs is not None and getattr(prefs, "enable_restore_snapshots", False))


def _runtime_requested(prefs=None) -> bool:
    prefs = prefs or _prefs()
    return bool(prefs is not None and (_autosave_enabled(prefs) or _restore_enabled(prefs)))


def _runtime_recovery_requested(
    prefs=None,
    *,
    allow_missing_timer: bool = False,
) -> bool:
    """Keep recovery alive only while the canonical preference is unreadable.

    A readable OFF is authoritative and must never be overridden by a stale
    enabled state.  The gap fallback is intentionally the same exact owned
    generation predicate used by event capture.
    """
    prefs = prefs if prefs is not None else _prefs()
    if prefs is not None:
        return bool(_runtime_requested(prefs))
    return _runtime_gap_recovery_allowed(
        allow_missing_timer=allow_missing_timer,
    )


def _runtime_gap_recovery_allowed(*, allow_missing_timer: bool = False) -> bool:
    timer_owned = bool(
        _timer_is_registered() or _SF_TIMER_EXECUTING_CALLBACK is not None
    )
    if not timer_owned and allow_missing_timer:
        timer_owned = bool(
            _SF_STATE.phase is RuntimePhase.RETRYING
            and _SF_STATE.failure_kind in {
                FailureKind.SETTINGS_OWNER,
                FailureKind.REGISTRATION,
                FailureKind.TIMER,
            }
        )
    return bool(
        _SF_LEDGER_INSTALLED
        and _is_current_generation()
        and _SF_AUTOSAVE_LATCHED
        and _SF_STATE.enabled
        and _handlers_ok()
        and timer_owned
    )


def _runtime_events_active(context=None) -> bool:
    """Gate events without losing edits during a transient settings-owner gap.

    An explicit readable OFF always wins.  Recovery is permitted only for the
    same exact generation that was already latched ON and still owns its full
    handler/timer/lifecycle graph; stale, partially registered, or unregistered
    callbacks remain inert.
    """
    try:
        if not (_SF_LEDGER_INSTALLED and _is_current_generation()):
            return False
        prefs = _prefs(context)
        if prefs is not None:
            if not _runtime_requested(prefs):
                return False
            if _SF_REGISTERED:
                return True
            if not _autosave_enabled(prefs):
                return False
        if not _runtime_gap_recovery_allowed():
            return False
        return True
    except Exception:
        return False


def _minutes(value, default: int) -> float:
    try:
        return float(max(1, int(value or default))) * 60.0
    except Exception:
        return float(default) * 60.0


def _autosave_interval(prefs=None) -> float:
    prefs = prefs or _prefs()
    return _minutes(getattr(prefs, "autosave_interval_minutes", 5) if prefs else 5, 5)


def _restore_interval(prefs=None) -> float:
    prefs = prefs or _prefs()
    return _minutes(
        getattr(prefs, "restore_snapshot_interval_minutes", 15) if prefs else 15,
        15,
    )


def _skip_unchanged(prefs=None) -> bool:
    prefs = prefs or _prefs()
    return bool(prefs is None or getattr(prefs, "autosave_skip_unchanged", True))


def _data_is_dirty() -> bool:
    try:
        return bool(getattr(getattr(bpy, "data", None), "is_dirty", False))
    except Exception:
        return False


def _file_identity() -> str:
    try:
        filepath = str(getattr(getattr(bpy, "data", None), "filepath", "") or "")
        if filepath:
            return os.path.normcase(os.path.abspath(filepath))
    except Exception:
        pass
    try:
        scene = getattr(getattr(bpy, "context", None), "scene", None)
        pointer = int(scene.as_pointer()) if scene is not None and hasattr(scene, "as_pointer") else id(scene)
        return f"UNSAVED:{pointer}"
    except Exception:
        return "UNSAVED"


def _external_counter(context=None) -> tuple[int, ...]:
    """Bounded primitive change evidence; no RNA is retained."""
    try:
        ctx = context or getattr(bpy, "context", None)
        scene = getattr(ctx, "scene", None)
        frame = int(getattr(scene, "frame_current", 0) or 0)
        signature = str(selection_signature(ctx) or "")
        # Stable bounded integer digest. Python hash is session-local, which is
        # sufficient because persistent state survives only this Blender process.
        return (frame, hash(signature[:2048]))
    except Exception:
        return ()


def _snapshot(context=None) -> ChangeSnapshot:
    return _SF_STATE.current_snapshot(
        data_is_dirty=_data_is_dirty(),
        external_counter=_external_counter(context),
        file_identity=_file_identity(),
    )


def _safe_snapshot(context=None) -> ChangeSnapshot:
    """Return conservative primitive evidence without allowing handler traceback.

    Boundary/error paths must preserve pending work even when context or an RNA
    accessor is temporarily invalid.  The fallback therefore keeps the current
    event serial/file identity and marks the snapshot dirty rather than
    baselining the failure away.
    """
    try:
        return _snapshot(context)
    except Exception:
        try:
            baseline = _SF_STATE.active_saved_snapshot
        except Exception:
            baseline = ChangeSnapshot(0, False, (), "")
        try:
            serial = max(int(getattr(_SF_STATE, "event_serial", 0) or 0), int(baseline.event_serial))
        except Exception:
            serial = 0
        try:
            counter = tuple(int(value) for value in (baseline.external_counter or ()))
        except Exception:
            counter = ()
        try:
            identity = str(_file_identity() or baseline.file_identity or "UNSAVED")
        except Exception:
            identity = str(getattr(baseline, "file_identity", "") or "UNSAVED")
        return ChangeSnapshot(serial, True, counter, identity)


@contextmanager
def _internal_mutation():
    global _SF_INTERNAL_MUTATION_DEPTH
    _SF_INTERNAL_MUTATION_DEPTH += 1
    try:
        yield
    finally:
        _SF_INTERNAL_MUTATION_DEPTH = max(0, _SF_INTERNAL_MUTATION_DEPTH - 1)


def _internal_change_active() -> bool:
    return bool(_SF_INTERNAL_MUTATION_DEPTH > 0 or _SF_SAVE_DEPTH > 0)


def _plain_scene_identity(scene) -> tuple[int, str]:
    """Return a non-RNA scene identity that cannot retain a stale proxy."""
    try:
        session_uid = int(getattr(scene, "session_uid", 0) or 0)
        if session_uid <= 0:
            return ()
        name = str(getattr(scene, "name_full", "") or getattr(scene, "name", "") or "")
        return (session_uid, name)
    except Exception:
        return ()


def _history_entry_fingerprint(scene) -> Optional[tuple[Any, ...]]:
    """Re-read the final Scene History row using primitive values only."""
    try:
        settings = getattr(scene, "uhm_settings", None)
        entries = getattr(settings, "entries", None)
        count = len(entries)
        active_index = int(getattr(settings, "active_index", -1) or 0)
        if count <= 0:
            return (0, active_index, "", "", "", "", "", False)
        item = entries[count - 1]
        return (
            int(count),
            active_index,
            str(getattr(item, "uid", "") or ""),
            str(getattr(item, "timestamp", "") or ""),
            str(getattr(item, "entry_type", "") or ""),
            str(getattr(item, "label", "") or ""),
            str(getattr(item, "file_path", "") or ""),
            bool(getattr(item, "restorable", False)),
        )
    except Exception:
        return None


def _history_content_fingerprint(scene) -> Optional[tuple[Any, ...]]:
    """Return every bounded History row as primitive values in list order."""
    try:
        settings = getattr(scene, "uhm_settings", None)
        entries = getattr(settings, "entries", None)
        count = len(entries)
        if count < 0 or count > _HISTORY_ENTRY_HARD_LIMIT:
            return None
        rows = []
        for item in entries:
            rows.append(
                (
                    str(getattr(item, "uid", "") or ""),
                    str(getattr(item, "label", "") or ""),
                    str(getattr(item, "detail", "") or ""),
                    str(getattr(item, "entry_type", "") or ""),
                    str(getattr(item, "timestamp", "") or ""),
                    str(getattr(item, "active_object", "") or ""),
                    str(getattr(item, "mode", "") or ""),
                    str(getattr(item, "scene_name", "") or ""),
                    int(getattr(item, "frame", 0) or 0),
                    int(getattr(item, "selected_count", 0) or 0),
                    str(getattr(item, "file_path", "") or ""),
                    bool(getattr(item, "restorable", False)),
                    int(getattr(item, "nearest_restore_index", -1)),
                )
            )
        return (int(count), tuple(rows))
    except Exception:
        return None


def _scene_edit_guard_fingerprint(scene) -> Optional[tuple[Any, ...]]:
    """Bounded guard for genuine Scene-only edits during the owned flush.

    Ordering in the synchronous flush bracket is the primary discriminator.
    These high-value scalar/custom-property fields add a conservative guard for
    callbacks that mutate the Scene while Blender evaluates that bracket.
    """
    try:
        render = getattr(scene, "render", None)
        custom = []
        keys = sorted(str(key) for key in tuple(getattr(scene, "keys", lambda: ())() or ()))
        for key in keys[:64]:
            if key == "_RNA_UI":
                continue
            value = getattr(scene, "get", lambda *_args: None)(key)
            if isinstance(value, (type(None), bool, int, float, str)):
                encoded = value
            elif isinstance(value, (tuple, list)) and len(value) <= 16 and all(
                isinstance(part, (type(None), bool, int, float, str)) for part in value
            ):
                encoded = tuple(value)
            else:
                encoded = (type(value).__name__, repr(value)[:128])
            custom.append((key, encoded))
        return (
            int(getattr(scene, "frame_current", 0) or 0),
            float(getattr(scene, "frame_subframe", 0.0) or 0.0),
            int(getattr(scene, "frame_start", 0) or 0),
            int(getattr(scene, "frame_end", 0) or 0),
            str(getattr(render, "engine", "") or ""),
            int(getattr(render, "resolution_x", 0) or 0),
            int(getattr(render, "resolution_y", 0) or 0),
            int(getattr(render, "resolution_percentage", 0) or 0),
            int(getattr(render, "fps", 0) or 0),
            float(getattr(render, "fps_base", 0.0) or 0.0),
            tuple(custom),
        )
    except Exception:
        return None


def _owned_save_witness(context=None) -> Optional[dict[str, Any]]:
    """Capture primitive evidence before save handlers can run."""
    try:
        ctx = context or getattr(bpy, "context", None)
        scene = getattr(ctx, "scene", None)
        scene_identity = _plain_scene_identity(scene)
        history_fingerprint = _history_entry_fingerprint(scene)
        history_content = _history_content_fingerprint(scene)
        scene_edit_guard = _scene_edit_guard_fingerprint(scene)
        if (
            not scene_identity
            or history_fingerprint is None
            or history_content is None
            or scene_edit_guard is None
        ):
            return None
        return {
            "generation": str(_SF_RUNTIME_GENERATION),
            "ack_epoch": int(_SF_INTERNAL_SCENE_ACK_EPOCH),
            "scene_identity": tuple(scene_identity),
            "file_identity": str(_file_identity()),
            "event_serial": int(getattr(_SF_STATE, "event_serial", 0) or 0),
            "change_counter": int(_RUNTIME.get("change_counter", 0) or 0),
            "external_counter": tuple(_external_counter(ctx)),
            "history_revision": int(_SF_INTERNAL_HISTORY_REVISION),
            "history_fingerprint": tuple(history_fingerprint),
            "history_content_fingerprint": tuple(history_content),
            "scene_edit_guard": tuple(scene_edit_guard),
        }
    except Exception:
        return None


def _owned_save_witness_status(witness, context=None) -> str:
    """Return CLEAN, DIRTY_REARM, or ABORT_WORLD_CHANGED after a save."""
    if not isinstance(witness, Mapping):
        return "DIRTY_REARM"
    try:
        ctx = context or getattr(bpy, "context", None)
        scene = getattr(ctx, "scene", None)
        if (
            str(witness.get("generation") or "") != str(_SF_RUNTIME_GENERATION)
            or int(witness.get("ack_epoch", -1)) != int(_SF_INTERNAL_SCENE_ACK_EPOCH)
            or tuple(witness.get("scene_identity") or ()) != _plain_scene_identity(scene)
            or str(witness.get("file_identity") or "") != str(_file_identity())
        ):
            return "ABORT_WORLD_CHANGED"
        if (
            int(witness.get("event_serial", -1))
            != int(getattr(_SF_STATE, "event_serial", 0) or 0)
            or int(witness.get("change_counter", -1))
            != int(_RUNTIME.get("change_counter", 0) or 0)
            or tuple(witness.get("external_counter") or ()) != tuple(_external_counter(ctx))
            or int(witness.get("history_revision", -1))
            != int(_SF_INTERNAL_HISTORY_REVISION)
            or tuple(witness.get("history_fingerprint") or ())
            != _history_entry_fingerprint(scene)
            or tuple(witness.get("history_content_fingerprint") or ())
            != _history_content_fingerprint(scene)
            or tuple(witness.get("scene_edit_guard") or ())
            != _scene_edit_guard_fingerprint(scene)
        ):
            return "DIRTY_REARM"
        return "CLEAN"
    except Exception:
        return "DIRTY_REARM"


def _owned_no_callback_save_proof(
    witness, verified_result, context=None
) -> Optional[dict[str, Any]]:
    """Seal the external save window before the owned History row is appended.

    Blender may legitimately evaluate selection/dependency state while the later
    owned History row is flushed.  That evaluation must not rewrite the evidence
    that was already proven unchanged across the verified copy.  The proof keeps
    only primitive values and is valid for one short synchronous transaction.
    """
    if _owned_save_witness_status(witness, context) != "CLEAN":
        return None
    try:
        filepath = str(getattr(verified_result, "filepath", "") or "")
        sequence = int(getattr(verified_result, "sequence", 0) or 0)
        if not (
            bool(getattr(verified_result, "success", False))
            and bool(getattr(verified_result, "committed", False))
            and filepath
            and sequence > 0
        ):
            return None
        now = time.monotonic()
        return {
            "generation": str(witness.get("generation") or ""),
            "ack_epoch": int(witness.get("ack_epoch", -1)),
            "scene_identity": tuple(witness.get("scene_identity") or ()),
            "file_identity": str(witness.get("file_identity") or ""),
            "event_serial": int(witness.get("event_serial", -1)),
            "change_counter": int(witness.get("change_counter", -1)),
            # This counter seals the completed save window.  It is also read at
            # t1 so a future synchronous selection hook fails open even though
            # user input cannot normally interleave this main-thread stack.
            "external_counter": tuple(witness.get("external_counter") or ()),
            "scene_edit_guard": tuple(witness.get("scene_edit_guard") or ()),
            "history_revision_before": int(witness.get("history_revision", -1)),
            "history_fingerprint_before": tuple(
                witness.get("history_fingerprint") or ()
            ),
            "history_content_before": tuple(
                witness.get("history_content_fingerprint") or ()
            ),
            "verified_sequence": sequence,
            "verified_filepath": filepath,
            "external_window_clean": True,
            "sealed_at": float(now),
            "expires_at": float(now) + _SF_INTERNAL_SCENE_ACK_TTL_SECONDS,
        }
    except Exception:
        return None


def _owned_no_callback_proof_seal(proof) -> tuple[Any, ...]:
    if not isinstance(proof, Mapping):
        return ()
    return tuple(
        proof.get(key)
        for key in (
            "generation",
            "ack_epoch",
            "scene_identity",
            "file_identity",
            "event_serial",
            "change_counter",
            "external_counter",
            "scene_edit_guard",
            "history_revision_before",
            "history_fingerprint_before",
            "history_content_before",
            "verified_sequence",
            "verified_filepath",
            "external_window_clean",
            "sealed_at",
            "expires_at",
        )
    )


def _history_path_identity(value: Any) -> str:
    try:
        path = os.path.expanduser(str(value or ""))
        return os.path.normcase(os.path.realpath(os.path.abspath(path))) if path else ""
    except Exception:
        return ""


def _owned_no_callback_invariants_hold(
    scene,
    records,
    seals,
    remaining,
    proof,
    proof_seal,
    context=None,
) -> tuple[bool, int, str]:
    """Prove one verified Autosave History delta with zero observed callbacks."""
    try:
        if not isinstance(proof, Mapping) or not proof_seal:
            return False, 0, "verified-save proof unavailable"
        if _owned_no_callback_proof_seal(proof) != proof_seal:
            return False, 0, "verified-save proof seal changed"
        now = time.monotonic()
        if (
            now < float(proof.get("sealed_at", now))
            or now > float(proof.get("expires_at", 0.0))
            or not bool(proof.get("external_window_clean"))
        ):
            return False, 0, "verified-save proof expired or was not clean"
        identity = _plain_scene_identity(scene)
        if (
            str(proof.get("generation") or "") != str(_SF_RUNTIME_GENERATION)
            or int(proof.get("ack_epoch", -1)) != int(_SF_INTERNAL_SCENE_ACK_EPOCH)
            or tuple(proof.get("scene_identity") or ()) != tuple(identity)
            or str(proof.get("file_identity") or "") != str(_file_identity())
        ):
            return False, 0, "verified-save world identity changed"

        history_before = tuple(proof.get("history_fingerprint_before") or ())
        history_content_before = tuple(proof.get("history_content_before") or ())
        history_after = _history_entry_fingerprint(scene)
        history_content_after = _history_content_fingerprint(scene)
        scene_guard = _scene_edit_guard_fingerprint(scene)
        event_serial = int(getattr(_SF_STATE, "event_serial", 0) or 0)
        change_counter = int(_RUNTIME.get("change_counter", 0) or 0)
        history_count_before = int(history_before[0]) if len(history_before) == 8 else -1
        expected_history_count = min(
            history_count_before + 1, _HISTORY_ENTRY_HARD_LIMIT
        )
        if (
            len(history_before) != 8
            or history_after is None
            or len(history_after) != 8
            or int(_SF_INTERNAL_HISTORY_REVISION)
            != int(proof.get("history_revision_before", -1)) + 1
            or int(history_after[0]) != expected_history_count
            or int(history_after[1]) != int(history_after[0]) - 1
            or not str(history_after[2] or "")
            or str(history_after[2] or "") == str(history_before[2] or "")
            or str(history_after[4] or "") != "Autosave"
            or str(history_after[5] or "") != "Rolling autosave"
            or _history_path_identity(history_after[6])
            != _history_path_identity(proof.get("verified_filepath"))
            or not bool(history_after[7])
        ):
            return False, 0, "owned Autosave History delta was not exact"
        content_count_before = (
            int(history_content_before[0])
            if len(history_content_before) == 2
            else -1
        )
        content_rows_before = (
            tuple(history_content_before[1])
            if len(history_content_before) == 2
            else ()
        )
        expected_content_count = min(
            content_count_before + 1, _HISTORY_ENTRY_HARD_LIMIT
        )
        expected_content_prefix = (
            content_rows_before[1:]
            if content_count_before == _HISTORY_ENTRY_HARD_LIMIT
            else content_rows_before
        )
        if (
            len(history_content_before) != 2
            or history_content_after is None
            or len(history_content_after) != 2
            or int(history_content_after[0]) != expected_content_count
            or tuple(history_content_after[1][:-1])
            != expected_content_prefix
            or not history_content_after[1]
            or tuple(history_content_after[1][-1])
            != (
                str(history_after[2] or ""),
                str(history_after[5] or ""),
                str(getattr(scene.uhm_settings.entries[-1], "detail", "") or ""),
                str(history_after[4] or ""),
                str(history_after[3] or ""),
                str(getattr(scene.uhm_settings.entries[-1], "active_object", "") or ""),
                str(getattr(scene.uhm_settings.entries[-1], "mode", "") or ""),
                str(getattr(scene.uhm_settings.entries[-1], "scene_name", "") or ""),
                int(getattr(scene.uhm_settings.entries[-1], "frame", 0) or 0),
                int(getattr(scene.uhm_settings.entries[-1], "selected_count", 0) or 0),
                str(history_after[6] or ""),
                bool(history_after[7]),
                int(
                    getattr(
                        scene.uhm_settings.entries[-1], "nearest_restore_index", -1
                    )
                ),
            )
        ):
            return False, 0, "owned Autosave full History content delta was not exact"
        if (
            int(proof.get("event_serial", -1)) != event_serial
            or int(proof.get("change_counter", -1)) != change_counter
            # Free future-proofing: the selection/frame proxy is read again at
            # t1 even though no other Python can interleave this main-thread
            # stack.  Any synchronous hook added later therefore fails open.
            or tuple(proof.get("external_counter") or ())
            != tuple(_external_counter(context))
            or tuple(proof.get("scene_edit_guard") or ()) != scene_guard
        ):
            return False, 0, "external dirty evidence changed after save"

        latest = get_last_verified_write_result()
        if (
            int(getattr(latest, "sequence", 0) or 0)
            != int(proof.get("verified_sequence", -1))
            or not bool(getattr(latest, "success", False))
            or not bool(getattr(latest, "committed", False))
            or _history_path_identity(getattr(latest, "filepath", ""))
            != _history_path_identity(proof.get("verified_filepath"))
        ):
            return False, 0, "verified storage witness changed"

        untouched_keys = set()
        for channel_key, record in records.items():
            if _owned_history_ack_seal(record) != seals.get(channel_key):
                return False, 0, "owned channel seal changed"
            if (
                now < float(record.get("armed_at", now))
                or now > float(record.get("expires_at", 0.0))
                or str(record.get("generation") or "") != str(_SF_RUNTIME_GENERATION)
                or int(record.get("ack_epoch", -1))
                != int(_SF_INTERNAL_SCENE_ACK_EPOCH)
                or tuple(record.get("scene_identity") or ()) != tuple(identity)
                or str(record.get("file_identity") or "") != str(_file_identity())
                or int(record.get("history_revision", -1))
                != int(_SF_INTERNAL_HISTORY_REVISION)
                or tuple(record.get("history_fingerprint") or ()) != history_after
                or tuple(record.get("scene_edit_guard") or ()) != scene_guard
                or int(record.get("event_serial", -1)) != event_serial
                or int(record.get("change_counter", -1)) != change_counter
                or record.get("callback_seen")
                or record.get("matched")
                or record.get("retired")
                or record.get("handler_completed")
                or remaining.get(channel_key) is not record
            ):
                return False, 0, "zero-callback owned channel changed"
            untouched_keys.add(channel_key)
        if (
            set(remaining) != untouched_keys
            or int(_SF_INTERNAL_SCENE_ACK_CALLBACK_COUNT) != 0
        ):
            return False, 0, "a callback was observed during zero-callback proof"
        return True, len(untouched_keys), "sealed verified-save zero-callback proof"
    except Exception:
        return False, 0, "zero-callback proof raised"


def _clear_owned_history_ack(*, reset_revision: bool = False) -> None:
    global _SF_INTERNAL_SCENE_ACK_EPOCH
    global _SF_INTERNAL_HISTORY_REVISION
    _purge_owned_history_ack_transaction()
    _SF_INTERNAL_SCENE_ACK_EPOCH += 1
    if reset_revision:
        _SF_INTERNAL_HISTORY_REVISION = 0


def _purge_owned_history_ack_transaction() -> None:
    """Fail-safe reset: no partial cleanup may leave callbacks inside a flush."""
    global _SF_INTERNAL_SCENE_UPDATE_ACKS, _SF_INTERNAL_SCENE_ACK_FLUSH_DEPTH
    global _SF_INTERNAL_SCENE_ACK_FLUSH_DIRTY, _SF_INTERNAL_SCENE_ACK_CALLBACK_COUNT
    global _SF_INTERNAL_SCENE_ACK_REENTRANT
    try:
        _SF_INTERNAL_SCENE_UPDATE_ACKS = {}
    except Exception:
        pass
    try:
        _SF_INTERNAL_SCENE_ACK_FLUSH_DEPTH = 0
    except Exception:
        pass
    try:
        _SF_INTERNAL_SCENE_ACK_FLUSH_DIRTY = False
    except Exception:
        pass
    try:
        _SF_INTERNAL_SCENE_ACK_CALLBACK_COUNT = 0
    except Exception:
        pass
    try:
        _SF_INTERNAL_SCENE_ACK_REENTRANT = False
    except Exception:
        pass


def _owned_history_scene(entry, context=None):
    try:
        owner = getattr(entry, "id_data", None)
        if owner is not None and getattr(owner, "uhm_settings", None) is not None:
            return owner
    except Exception:
        pass
    try:
        ctx = context or getattr(bpy, "context", None)
        return getattr(ctx, "scene", None)
    except Exception:
        return None


def _owned_history_view_layers(scene, context=None) -> tuple[Any, ...]:
    result = []
    seen = set()
    scene_identity = _plain_scene_identity(scene)

    def add(view_layer, owner_scene=None):
        if view_layer is None or len(result) >= _SF_INTERNAL_SCENE_ACK_MAX_CHANNELS:
            return
        if owner_scene is not None and _plain_scene_identity(owner_scene) != scene_identity:
            return
        layer_name = str(getattr(view_layer, "name", "") or "")
        if not scene_identity or not layer_name:
            return
        key = (int(scene_identity[0]), layer_name)
        if key not in seen:
            seen.add(key)
            result.append((key, view_layer))

    try:
        ctx = context or getattr(bpy, "context", None)
        add(getattr(ctx, "view_layer", None), getattr(ctx, "scene", None))
    except Exception:
        pass
    try:
        live = getattr(bpy, "context", None)
        add(getattr(live, "view_layer", None), getattr(live, "scene", None))
        wm = getattr(live, "window_manager", None)
        for window in tuple(getattr(wm, "windows", ()) or ()):
            add(getattr(window, "view_layer", None), getattr(window, "scene", None))
    except Exception:
        pass
    if not result:
        try:
            layers = tuple(getattr(scene, "view_layers", ()) or ())
            add(layers[0] if layers else None, scene)
        except Exception:
            pass
    return tuple(result)


def _owned_history_ack_record(
    scene, channel_key: tuple[int, str], context=None
) -> Optional[dict[str, Any]]:
    identity = _plain_scene_identity(scene)
    history_fingerprint = _history_entry_fingerprint(scene)
    edit_guard = _scene_edit_guard_fingerprint(scene)
    if not identity or history_fingerprint is None or edit_guard is None:
        return None
    now = time.monotonic()
    return {
        "generation": str(_SF_RUNTIME_GENERATION),
        "ack_epoch": int(_SF_INTERNAL_SCENE_ACK_EPOCH),
        "scene_identity": tuple(identity),
        "channel_key": tuple(channel_key),
        "history_revision": int(_SF_INTERNAL_HISTORY_REVISION),
        "history_fingerprint": tuple(history_fingerprint),
        "scene_edit_guard": tuple(edit_guard),
        "file_identity": str(_file_identity()),
        "event_serial": int(getattr(_SF_STATE, "event_serial", 0) or 0),
        "change_counter": int(_RUNTIME.get("change_counter", 0) or 0),
        "external_counter": tuple(_external_counter(context)),
        "armed_at": float(now),
        "expires_at": float(now) + _SF_INTERNAL_SCENE_ACK_TTL_SECONDS,
        "callback_seen": False,
        "matched": False,
        "retired": False,
        "handler_completed": False,
    }


def _owned_history_ack_seal(record) -> tuple[Any, ...]:
    return tuple(
        record.get(key)
        for key in (
            "generation",
            "ack_epoch",
            "scene_identity",
            "channel_key",
            "history_revision",
            "history_fingerprint",
            "scene_edit_guard",
            "file_identity",
            "event_serial",
            "change_counter",
            "external_counter",
            "armed_at",
            "expires_at",
        )
    )


def _owned_history_ack_world_matches(scene, records) -> bool:
    try:
        identity = _plain_scene_identity(scene)
        file_identity = str(_file_identity())
        return bool(
            identity
            and all(
                str(record.get("generation") or "") == str(_SF_RUNTIME_GENERATION)
                and int(record.get("ack_epoch", -1))
                == int(_SF_INTERNAL_SCENE_ACK_EPOCH)
                and tuple(record.get("scene_identity") or ()) == tuple(identity)
                and str(record.get("file_identity") or "") == file_identity
                for record in records.values()
            )
        )
    except Exception:
        return False


def _owned_history_ack_invariants_hold(
    scene, records, seals, remaining, context=None
) -> tuple[bool, int, int]:
    """Prove exact matched callbacks or untouched no-callback channels."""
    try:
        now = time.monotonic()
        history_fingerprint = _history_entry_fingerprint(scene)
        edit_guard = _scene_edit_guard_fingerprint(scene)
        event_serial = int(getattr(_SF_STATE, "event_serial", 0) or 0)
        change_counter = int(_RUNTIME.get("change_counter", 0) or 0)
        external_counter = tuple(_external_counter(context))
        matched_count = 0
        untouched_count = 0
        untouched_keys = set()
        for channel_key, record in records.items():
            if _owned_history_ack_seal(record) != seals.get(channel_key):
                return False, 0, 0
            if (
                now < float(record.get("armed_at", now))
                or now > float(record.get("expires_at", 0.0))
                or int(record.get("history_revision", -1))
                != int(_SF_INTERNAL_HISTORY_REVISION)
                or tuple(record.get("history_fingerprint") or ())
                != history_fingerprint
                or tuple(record.get("scene_edit_guard") or ()) != edit_guard
                or int(record.get("event_serial", -1)) != event_serial
                or int(record.get("change_counter", -1)) != change_counter
                or tuple(record.get("external_counter") or ()) != external_counter
            ):
                return False, 0, 0
            matched = bool(
                record.get("callback_seen")
                and record.get("matched")
                and record.get("retired")
                and record.get("handler_completed")
                and channel_key not in remaining
            )
            untouched = bool(
                not record.get("callback_seen")
                and not record.get("matched")
                and not record.get("retired")
                and not record.get("handler_completed")
                and remaining.get(channel_key) is record
            )
            if matched:
                matched_count += 1
            elif untouched:
                untouched_count += 1
                untouched_keys.add(channel_key)
            else:
                return False, 0, 0
        if set(remaining) != untouched_keys:
            return False, 0, 0
        if int(_SF_INTERNAL_SCENE_ACK_CALLBACK_COUNT) != matched_count:
            return False, 0, 0
        return True, matched_count, untouched_count
    except Exception:
        return False, 0, 0


def _flush_owned_history_update(
    entry,
    context=None,
    *,
    force_dirty: bool = False,
    no_callback_proof=None,
) -> _HistoryAckOutcome:
    """Classify one same-stack owned History update without lingering suppression.

    Observed callbacks use the exact Scene-only callback oracle.  A truly silent
    verified Autosave uses a separate sealed save-window proof plus an exact
    one-row History delta.  Silence alone is never success.  Any unmatched
    callback or same-world ambiguity is dirty fail-open.  File/load/generation
    changes abort the stale world without dirtying the new one.  No record or
    proof survives this synchronous main-thread stack.
    """
    global _SF_INTERNAL_SCENE_UPDATE_ACKS, _SF_INTERNAL_SCENE_ACK_FLUSH_DEPTH
    global _SF_INTERNAL_SCENE_ACK_FLUSH_DIRTY, _SF_INTERNAL_SCENE_ACK_CALLBACK_COUNT
    global _SF_INTERNAL_SCENE_ACK_REENTRANT
    scene = _owned_history_scene(entry, context)
    layers = _owned_history_view_layers(scene, context) if scene is not None else ()
    if _SF_INTERNAL_SCENE_ACK_FLUSH_DEPTH:
        _SF_INTERNAL_SCENE_ACK_REENTRANT = True
        mark_change_pending(context=context, source="history_ack_reentrant")
        return _history_ack_outcome("DIRTY_REARM", "nested History ACK flush")
    if scene is None or not layers:
        mark_change_pending(context=context, source="history_ack_unavailable")
        return _history_ack_outcome("DIRTY_REARM", "History ACK context unavailable")

    records = {}
    for channel_key, _view_layer in layers:
        record = _owned_history_ack_record(scene, channel_key, context)
        if record is None:
            break
        records[channel_key] = record
    if len(records) != len(layers):
        mark_change_pending(context=context, source="history_ack_record_unavailable")
        return _history_ack_outcome("DIRTY_REARM", "History ACK record unavailable")

    seals = {key: _owned_history_ack_seal(record) for key, record in records.items()}
    no_callback_proof_seal = _owned_no_callback_proof_seal(no_callback_proof)
    _SF_INTERNAL_SCENE_UPDATE_ACKS = dict(records)
    _SF_INTERNAL_SCENE_ACK_FLUSH_DIRTY = False
    _SF_INTERNAL_SCENE_ACK_CALLBACK_COUNT = 0
    _SF_INTERNAL_SCENE_ACK_REENTRANT = False
    _SF_INTERNAL_SCENE_ACK_FLUSH_DEPTH += 1
    update_exception = False
    outcome = _history_ack_outcome("DIRTY_REARM", "History ACK classification failed")
    try:
        for _channel_key, view_layer in layers:
            view_layer.update()
    except Exception:
        update_exception = True
        _SF_INTERNAL_SCENE_ACK_FLUSH_DIRTY = True
    finally:
        remaining = dict(_SF_INTERNAL_SCENE_UPDATE_ACKS)
        world_matches = _owned_history_ack_world_matches(scene, records)
        callback_count = int(_SF_INTERNAL_SCENE_ACK_CALLBACK_COUNT)
        proof_kind = ""
        proof_reason = "History ACK invariants failed"
        if world_matches and callback_count == 0:
            invariants_ok, untouched_count, proof_reason = (
                _owned_no_callback_invariants_hold(
                    scene,
                    records,
                    seals,
                    remaining,
                    no_callback_proof,
                    no_callback_proof_seal,
                    context,
                )
            )
            matched_count = 0
            if invariants_ok:
                proof_kind = "VERIFIED_SAVE_ZERO_CALLBACK"
        elif world_matches:
            invariants_ok, matched_count, untouched_count = (
                _owned_history_ack_invariants_hold(
                    scene, records, seals, remaining, context
                )
            )
            proof_reason = "strict exact-callback proof"
            if invariants_ok:
                proof_kind = "EXACT_CALLBACK"
        else:
            invariants_ok, matched_count, untouched_count = False, 0, 0
        if not world_matches:
            outcome = _history_ack_outcome(
                "ABORT_WORLD_CHANGED",
                "History ACK world identity changed",
                callback_count=callback_count,
            )
        elif (
            not force_dirty
            and not update_exception
            and not _SF_INTERNAL_SCENE_ACK_FLUSH_DIRTY
            and not _SF_INTERNAL_SCENE_ACK_REENTRANT
            and _SF_INTERNAL_SCENE_ACK_FLUSH_DEPTH == 1
            and invariants_ok
        ):
            outcome = _history_ack_outcome(
                "CLEAN",
                proof_reason,
                matched_callbacks=matched_count,
                untouched_channels=untouched_count,
                callback_count=callback_count,
                proof_kind=proof_kind,
            )
        else:
            outcome = _history_ack_outcome(
                "DIRTY_REARM",
                proof_reason or "History ACK observed ambiguity or save-window drift",
                matched_callbacks=matched_count,
                untouched_channels=untouched_count,
                callback_count=callback_count,
                proof_kind=proof_kind,
            )
        _purge_owned_history_ack_transaction()

    if outcome.status == "DIRTY_REARM":
        mark_change_pending(context=context, source="history_ack_fail_open")
    return outcome



def _prune_history_entries(context=None) -> int:
    """Bound scene history rows without changing configured file retention."""
    st = scene_settings(context)
    if st is None:
        return 0
    removed = 0
    try:
        with _internal_mutation():
            while len(st.entries) > _HISTORY_ENTRY_HARD_LIMIT:
                st.entries.remove(0)
                removed += 1
            if len(st.entries) == 0:
                st.active_index = -1
            else:
                st.active_index = min(
                    max(int(getattr(st, 'active_index', 0) or 0), 0),
                    len(st.entries) - 1,
                )
    except Exception:
        pass
    return removed


def recompute_restore_links(context=None):
    with _internal_mutation():
        try:
            sync_entries_with_disk(context)
        except Exception:
            pass
        _prune_history_entries(context)
        st = scene_settings(context)
        if st is None:
            return
        last_restorable = -1
        for index, item in enumerate(st.entries):
            try:
                if item.restorable and item.file_path and os.path.exists(item.file_path):
                    last_restorable = index
                item.nearest_restore_index = last_restorable
            except Exception:
                continue


def _append_entry(
    label: str,
    detail: str,
    entry_type: str,
    *,
    file_path: str = "",
    restorable: bool = False,
    context=None,
):
    global _SF_INTERNAL_HISTORY_REVISION
    st = scene_settings(context)
    if st is None:
        return None
    before = len(st.entries)
    try:
        with _internal_mutation():
            entry = st.entries.add()
            entry.uid = f"{time.time():.6f}"
            entry.label = str(label or "")
            entry.detail = str(detail or "")
            entry.entry_type = str(entry_type or "Event")
            entry.timestamp = now_str()
            entry.active_object = active_object_name(context)
            entry.mode = mode_name(context)
            entry.scene_name = scene_name(context)
            entry.frame = frame_current(context)
            entry.selected_count = selected_count(context)
            entry.file_path = str(file_path or "")
            entry.restorable = bool(restorable and file_path)
            st.active_index = len(st.entries) - 1
            recompute_restore_links(context)
        # The caller finishes any follow-up restore-link mutation, then opens a
        # synchronous owned-ACK flush.  Keeping only a primitive revision here
        # prevents an RNA proxy from surviving file load, undo, or reload.
        _SF_INTERNAL_HISTORY_REVISION += 1
        return entry
    except Exception:
        try:
            while len(st.entries) > before:
                st.entries.remove(len(st.entries) - 1)
            st.active_index = min(int(getattr(st, "active_index", -1)), len(st.entries) - 1)
        except Exception:
            pass
        return None


def log_event(
    label: str,
    detail: str = "",
    entry_type: str = "Event",
    *,
    context=None,
    count_as_change: bool = True,
):
    entry = _append_entry(label, detail, entry_type, context=context)
    if entry is not None:
        _flush_owned_history_update(entry, context)
    if entry is not None and count_as_change:
        mark_change_pending(context=context, source="history_event")
    return entry


def _save_snapshot_guarded(category: str, label: str, context=None) -> str:
    global _SF_SAVE_DEPTH
    _SF_SAVE_DEPTH += 1
    _RUNTIME["snapshot_save_depth"] = _SF_SAVE_DEPTH
    try:
        return save_snapshot_copy(category, label, context)
    finally:
        _SF_SAVE_DEPTH = max(0, _SF_SAVE_DEPTH - 1)
        _RUNTIME["snapshot_save_depth"] = _SF_SAVE_DEPTH


def log_restore_point(label: str, detail: str = "", *, context=None):
    prefs = _prefs(context)
    path = _save_snapshot_guarded("restore_points", label, context)
    if not path:
        return None
    entry = _append_entry(
        label,
        detail,
        "Restore Point",
        file_path=path,
        restorable=True,
        context=context,
    )
    if entry is None:
        return None
    try:
        if prefs is not None:
            trim_old_files(
                "restore_points",
                int(getattr(prefs, "restore_snapshot_max_files", 50) or 50),
                context,
            )
        recompute_restore_links(context)
    except Exception:
        pass
    _flush_owned_history_update(entry, context)
    now = time.monotonic()
    _RUNTIME["last_restore_snapshot_time"] = now
    _RUNTIME["last_restore_change_counter"] = int(_RUNTIME["change_counter"])
    return entry


def _log_autosave_with_ack(label: str, detail: str = "", *, context=None):
    prefs = _prefs(context)
    save_witness = _owned_save_witness(context)
    path = _save_snapshot_guarded("autosaves", label, context)
    result = get_last_verified_write_result()
    if not path or not result.success or not result.committed:
        _RUNTIME["last_save_error"] = result.error or "Autosave snapshot copy failed"
        return None
    save_witness_status = _owned_save_witness_status(save_witness, context)
    if save_witness_status == "ABORT_WORLD_CHANGED":
        # The verified copy belongs to the old world.  Never append its row to,
        # baseline, or dirty the newly loaded/re-registered world.
        return None, _history_ack_outcome(
            "ABORT_WORLD_CHANGED", "world changed while autosave handlers ran"
        )
    no_callback_proof = _owned_no_callback_save_proof(
        save_witness, result, context
    ) if save_witness_status == "CLEAN" else None
    entry = _append_entry(
        label,
        detail,
        "Autosave",
        file_path=path,
        restorable=True,
        context=context,
    )
    if entry is None:
        _RUNTIME["last_save_error"] = "Autosave history entry could not be committed"
        return None
    try:
        if prefs is not None:
            trim_old_files(
                "autosaves",
                int(getattr(prefs, "autosave_max_files", 50) or 50),
                context,
            )
        recompute_restore_links(context)
    except Exception:
        pass
    history_ack = _flush_owned_history_update(
        entry,
        context,
        force_dirty=save_witness_status != "CLEAN" or no_callback_proof is None,
        no_callback_proof=no_callback_proof,
    )
    now = time.monotonic()
    _RUNTIME["last_autosave_time"] = now
    _RUNTIME["last_autosave_change_counter"] = int(_RUNTIME["change_counter"])
    _RUNTIME["last_save_error"] = ""
    return entry, history_ack


def log_autosave(label: str, detail: str = "", *, context=None):
    result = _log_autosave_with_ack(label, detail, context=context)
    return result[0] if result is not None else None


def create_safety_backup(context=None):
    path = _save_snapshot_guarded(
        "safety_backups", "Safety backup before restore", context
    )
    if path:
        try:
            trim_old_files("safety_backups", _SAFETY_BACKUP_HARD_LIMIT, context)
        except Exception:
            pass
    return path


def restore_by_index(index: int, context=None):
    st = scene_settings(context)
    prefs = _prefs(context)
    recompute_restore_links(context)
    if st is None or index < 0 or index >= len(st.entries):
        return False, "No selected history row."
    item = st.entries[index]
    restore_index = index if (item.restorable and item.file_path) else item.nearest_restore_index
    if restore_index < 0 or restore_index >= len(st.entries):
        return False, "No restorable point was found at or before this row."
    restore_item = st.entries[restore_index]
    path = str(restore_item.file_path or "")
    if not path or not os.path.exists(path):
        return False, "The selected restore file does not exist anymore."
    if prefs and getattr(prefs, "create_safety_snapshot_before_restore", True):
        if not create_safety_backup(context):
            return False, "Safety backup could not be created."
    _RUNTIME["suspend_restore"] = True
    try:
        result = bpy.ops.wm.open_mainfile(filepath=path)
        return bool(isinstance(result, (set, frozenset)) and "FINISHED" in result), path
    except Exception as exc:
        return False, _error_text(exc)
    finally:
        _RUNTIME["suspend_restore"] = False


def history_counts(context=None):
    st = scene_settings(context)
    if st is None:
        return 0, 0, 0
    restore_count = 0
    autosave_count = 0
    for item in st.entries:
        if item.entry_type == "Restore Point":
            restore_count += 1
        elif item.entry_type == "Autosave":
            autosave_count += 1
    return restore_count + autosave_count, restore_count, autosave_count


def _ensure_feature_deadlines(now: float, prefs=None) -> None:
    prefs = prefs or _prefs()
    if _autosave_enabled(prefs):
        if _SF_CLOCK["autosave_deadline"] is None:
            anchor = _SF_CLOCK["last_autosave_monotonic"]
            _SF_CLOCK["autosave_deadline"] = float(anchor if anchor is not None else now) + _autosave_interval(prefs)
    else:
        _SF_CLOCK["autosave_deadline"] = None
    if _restore_enabled(prefs):
        if _SF_CLOCK["restore_deadline"] is None:
            anchor = _SF_CLOCK["last_restore_monotonic"]
            _SF_CLOCK["restore_deadline"] = float(anchor if anchor is not None else now) + _restore_interval(prefs)
    else:
        _SF_CLOCK["restore_deadline"] = None


def _synchronize_autosave_schedule(now: float, prefs=None) -> bool:
    """Apply autosave enable/interval changes to the live feature deadline.

    The pre-repair runtime could remain ACTIVE while retaining an obsolete
    deadline.  This changes only the autosave clock, preserves dirty evidence,
    and never postpones an earlier pending save.
    """
    prefs = prefs or _prefs()
    enabled = _autosave_enabled(prefs)
    interval = _autosave_interval(prefs)
    raw_enabled = _SF_CLOCK.get("configured_autosave_enabled")
    raw_interval = _SF_CLOCK.get("configured_autosave_interval")
    previous_enabled = None
    previous_interval = None
    if raw_enabled is not None:
        try:
            previous_enabled = bool(float(raw_enabled) >= 0.5)
        except Exception:
            previous_enabled = None
    if raw_interval is not None:
        try:
            previous_interval = max(1.0, float(raw_interval))
        except Exception:
            previous_interval = None
    existing = _SF_CLOCK.get("autosave_deadline")
    if previous_enabled is None and existing is not None:
        previous_enabled = True
    if previous_interval is None:
        try:
            previous_interval = max(1.0, float(_SF_STATE.interval_seconds))
        except Exception:
            previous_interval = None

    changed = False
    if not enabled:
        changed = bool(existing is not None or previous_enabled is not False)
        _SF_CLOCK["autosave_deadline"] = None
        _SF_CLOCK["timer_liveness_until"] = None
    else:
        interval_changed = bool(
            previous_interval is not None
            and abs(float(previous_interval) - float(interval)) > 0.001
        )
        newly_enabled = previous_enabled is False
        missing_deadline = existing is None
        if interval_changed or newly_enabled or missing_deadline:
            candidate = float(now) + float(interval)
            pending_change = bool(
                _SF_STATE.boundary_save_pending
                or _SF_STATE.dirty_pending
                or _SF_STATE.active_dirty_pending
                or _data_is_dirty()
            )
            keep_earlier = bool(
                existing is not None
                and pending_change
                and float(existing) <= candidate
            )
            new_deadline = float(existing) if keep_earlier else candidate
            changed = bool(
                existing is None
                or abs(float(existing) - float(new_deadline)) > 0.001
                or newly_enabled
                or interval_changed
            )
            _SF_CLOCK["autosave_deadline"] = new_deadline
            if _SF_CLOCK.get("timer_liveness_until") is not None:
                _SF_CLOCK["timer_liveness_until"] = new_deadline

    _SF_CLOCK["configured_autosave_enabled"] = 1.0 if enabled else 0.0
    _SF_CLOCK["configured_autosave_interval"] = float(interval)
    return changed


def _pending_change_for_schedule(context=None) -> bool:
    """Probe only primitive dirty evidence; never perform file I/O here."""
    try:
        current = _snapshot(context)
        _SF_STATE.note_dirty_probe(current)
        return bool(
            _SF_STATE.load_restore_pending
            or _SF_STATE.boundary_save_pending
            or _SF_STATE.dirty_pending
            or _SF_STATE.active_dirty_pending
            or current.data_is_dirty
            or _SF_STATE.has_unsaved_change(current)
        )
    except Exception:
        # Unknown context is not proof of a clean file. Keep the health wake.
        return bool(
            _SF_STATE.load_restore_pending
            or _SF_STATE.boundary_save_pending
            or _SF_STATE.dirty_pending
            or _SF_STATE.active_dirty_pending
        )


def _regular_wake_at(now: float, prefs=None) -> Optional[float]:
    """Return the next feature deadline, plus a dirty-only liveness wake.

    The deadline callback is also the missed-event safety probe: it checks both
    explicit event serials and ``bpy.data.is_dirty`` at the configured deadline.
    A quiet clean session therefore sleeps until the next real feature deadline.
    Once transactional dirty evidence exists, however, Blender must not be trusted
    to keep a long native sleep alive across file-load/native-timer edge cases.
    The dirty-only health wake performs no file I/O before the feature deadline;
    it only keeps the owned callback provably alive until the actual autosave due
    time is reached.
    """
    prefs = prefs or _prefs()
    _ensure_feature_deadlines(now, prefs)
    values: list[float] = []
    autosave_at = _SF_CLOCK.get("autosave_deadline")
    if autosave_at is not None:
        autosave_at_float = float(autosave_at)
        values.append(autosave_at_float)
        liveness_until = _SF_CLOCK.get("timer_liveness_until")
        if liveness_until is not None and float(now) < float(liveness_until):
            values.append(
                min(
                    autosave_at_float,
                    float(liveness_until),
                    float(now) + 5.0,
                )
            )
        dirty_waiting = bool(
            autosave_at_float > float(now)
            and (
                _SF_STATE.load_restore_pending
                or _SF_STATE.boundary_save_pending
                or _SF_STATE.dirty_pending
                or _SF_STATE.active_dirty_pending
                or _SF_STATE.last_save_error
            )
        )
        if dirty_waiting:
            values.append(min(autosave_at_float, float(now) + 5.0))
    pending_file_open_restore = bool(
        _SF_CLOCK.get("file_open_restore_pending_since") is not None
    )
    retry_at = _SF_CLOCK.get("file_open_restore_retry_at")
    # Before its first attempt, the existing periodic restore deadline supplies
    # the ordinary wake. After a failure, the dedicated bounded retry owns this
    # restore channel; retaining an already-past periodic deadline would force a
    # one-second callback loop until the retry deadline.
    if not pending_file_open_restore or retry_at is None:
        restore_at = _SF_CLOCK.get("restore_deadline")
        if restore_at is not None:
            values.append(float(restore_at))
    if pending_file_open_restore and retry_at is not None:
        values.append(float(retry_at))
    return min(values) if values else None


def _next_wake_at(now: float, prefs=None) -> Optional[float]:
    if _SF_STATE.phase is RuntimePhase.RETRYING and _SF_STATE.next_deadline is not None:
        return float(_SF_STATE.next_deadline)
    return _regular_wake_at(now, prefs)


def _handler_lists() -> dict[str, Any]:
    handlers = getattr(getattr(bpy, "app", None), "handlers", None)
    if handlers is None:
        return {}
    names = (
        "load_pre",
        "load_post",
        "save_post",
        "undo_post",
        "redo_post",
        "depsgraph_update_post",
        "render_pre",
        "render_complete",
        "render_cancel",
        "animation_playback_pre",
        "animation_playback_post",
        "exit_pre",
    )
    result = {}
    try:
        from ... import lifecycle_hub as _hub
        hub = _hub.handlers
    except Exception:
        hub = None
    for name in names:
        value = getattr(hub, name, None) if hub is not None and name in ("load_pre", "load_post", "save_post", "exit_pre") else None
        if value is None:
            value = getattr(handlers, name, None)
        if value is not None:
            result[name] = value
    return result

def _handler_specs() -> tuple[tuple[str, Callable], ...]:
    lists = _handler_lists()
    candidates = (
        ("load_pre", _on_load_pre),
        ("load_post", _on_load_post),
        ("save_post", _on_save_post),
        ("undo_post", _on_undo_post),
        ("redo_post", _on_redo_post),
        ("depsgraph_update_post", _on_depsgraph_update_post),
        ("render_pre", _on_render_state_change),
        ("render_complete", _on_render_state_change),
        ("render_cancel", _on_render_state_change),
        ("animation_playback_pre", _on_playback_state_change),
        ("animation_playback_post", _on_playback_state_change),
        ("exit_pre", _on_exit_pre),
    )
    return tuple((name, callback) for name, callback in candidates if name in lists)

def _remove_exact_handler(handler_list, callback) -> bool:
    ok = True
    try:
        while callback in handler_list:
            handler_list.remove(callback)
    except Exception:
        ok = False
    return ok


def _handlers_ok() -> bool:
    specs = _handler_specs()
    spec_map = dict(specs)
    lists = _handler_lists()
    if len(_SF_HANDLER_RECORDS) != len(specs):
        return False
    ledger = _ledger()
    ledger_records = tuple(ledger.get("handlers", ()) or ()) if isinstance(ledger, Mapping) else ()
    if len(ledger_records) != len(_SF_HANDLER_RECORDS):
        return False
    for index, record in enumerate(_SF_HANDLER_RECORDS):
        name = str(record.get("name") or "")
        callback = record.get("callback")
        handler_list = lists.get(name)
        if callback is not spec_map.get(name) or record.get("handler_list") is not handler_list:
            return False
        if (
            record.get("token") is not _SF_RUNTIME_TOKEN
            or record.get("generation") != _SF_RUNTIME_GENERATION
        ):
            return False
        if ledger_records[index] is not record:
            return False
        try:
            if handler_list is None or sum(1 for item in handler_list if item is callback) != 1:
                return False
        except Exception:
            return False
    return True

def _register_handlers() -> bool:
    global _SF_HANDLER_RECORDS
    lists = _handler_lists()
    records: list[dict[str, Any]] = []
    try:
        for name, callback in _handler_specs():
            handler_list = lists.get(name)
            if handler_list is None:
                raise RuntimeError(f"handler list unavailable: {name}")
            _remove_exact_handler(handler_list, callback)
            handler_list.append(callback)
            if sum(1 for item in handler_list if item is callback) != 1:
                raise RuntimeError(f"handler exact-count validation failed: {name}")
            records.append(
                {
                    "name": name,
                    "handler_list": handler_list,
                    "callback": callback,
                    "token": _SF_RUNTIME_TOKEN,
                    "generation": _SF_RUNTIME_GENERATION,
                    "remover": lambda hl=handler_list, cb=callback: _remove_exact_handler(hl, cb),
                }
            )
        _SF_HANDLER_RECORDS = records
        ledger = _ledger()
        if ledger is not None:
            ledger["handlers"] = tuple(records)
        return _handlers_ok()
    except Exception as exc:
        for record in reversed(records):
            try:
                record["remover"]()
            except Exception:
                pass
        _SF_HANDLER_RECORDS = []
        _SF_STATE.record_retry(
            now=time.monotonic(),
            kind=FailureKind.HANDLER,
            reason=f"History handler registration failed: {_error_text(exc)}",
            next_condition="handler registry becomes writable or manual refresh",
            blocker_signature="handler_registration",
        )
        _persist_state()
        return False


def _unregister_handlers() -> bool:
    global _SF_HANDLER_RECORDS
    ok = True
    for record in reversed(tuple(_SF_HANDLER_RECORDS)):
        remover = record.get("remover")
        try:
            if callable(remover) and remover() is False:
                ok = False
        except Exception:
            ok = False
    _SF_HANDLER_RECORDS = []
    ledger = _ledger()
    if ledger is not None:
        ledger["handlers"] = ()
    return ok


def _timers_api():
    return getattr(getattr(bpy, "app", None), "timers", None)


def _native_timer_state(timers, callback) -> Optional[bool]:
    """Return Blender's exact timer state without collapsing readback failure.

    ``None`` is deliberately distinct from ``False``.  A transient exception in
    ``is_registered`` is not authority to clear an exact generation ledger, and
    it is not authority to register a possible duplicate either.
    """
    if timers is None or callback is None:
        return False
    checker = getattr(timers, "is_registered", None)
    if not callable(checker):
        return None
    try:
        return bool(checker(callback))
    except Exception:
        return None


def _timer_is_registered() -> bool:
    callback = _SF_TIMER_CALLBACK
    timers = _timers_api()
    ledger = _ledger()
    timer_record = ledger.get("timer") if isinstance(ledger, Mapping) else None
    if callback is None or timers is None or not isinstance(timer_record, Mapping):
        return False
    if not (
        timer_record.get("callback") is callback
        and timer_record.get("token") is _SF_RUNTIME_TOKEN
        and timer_record.get("generation") == _SF_RUNTIME_GENERATION
    ):
        return False
    # Blender may report a callback as no longer registered while it is being
    # executed.  The generation ledger still owns that exact recurring callback
    # until it returns ``None`` or explicit cleanup removes it.
    if _SF_TIMER_EXECUTING_CALLBACK is callback:
        return True
    native_state = _native_timer_state(timers, callback)
    # An exact ledger was installed only after a successful native registration.
    # Preserve it across a transient readback exception; a later scheduling or
    # lifecycle pass performs the tri-state reconciliation.
    return native_state is not False or _modal_scheduler_is_active()

def _unregister_timer() -> bool:
    global _SF_TIMER_CALLBACK, _SF_TIMER_KIND
    ok = _unregister_modal_scheduler()
    callback = _SF_TIMER_CALLBACK
    timers = _timers_api()
    if callback is not None and timers is not None and _SF_TIMER_EXECUTING_CALLBACK is not callback:
        try:
            checker = getattr(timers, "is_registered", None)
            if not callable(checker) or checker(callback):
                timers.unregister(callback)
        except Exception:
            try:
                checker = getattr(timers, "is_registered", None)
                if callable(checker) and checker(callback):
                    ok = False
            except Exception:
                ok = False
    _SF_TIMER_CALLBACK = None
    _SF_TIMER_KIND = ""
    _SF_CLOCK["timer_wake_at"] = None
    ledger = _ledger()
    if ledger is not None:
        ledger["timer"] = None
    return ok

def _timer_delay(wake_at: float, now: float) -> float:
    return max(1.0, float(wake_at) - float(now))


class WM_OT_smart_file_autosave_modal_pump(bpy.types.Operator):
    """Low-frequency GUI watchdog for Blender timer false-live states."""

    bl_idname = "wm.smart_file_autosave_modal_pump"
    bl_label = "Smart File Autosave Scheduler"
    bl_options = {"INTERNAL"}

    def invoke(self, context, _event):
        return _modal_pump_execute(self, context)

    def execute(self, context):
        return _modal_pump_execute(self, context)

    def modal(self, context, event):
        return _modal_pump_modal(self, context, event)

    def cancel(self, context):
        _modal_pump_cancel(self, context)


def _modal_context_parts(context=None):
    if bool(getattr(getattr(bpy, "app", None), "background", False)):
        return None, None, None
    try:
        ctx = context or getattr(bpy, "context", None)
        wm = getattr(ctx, "window_manager", None)
        window = getattr(ctx, "window", None)
        if window is None and wm is not None:
            windows = tuple(getattr(wm, "windows", ()) or ())
            window = windows[0] if windows else None
        if wm is None or window is None:
            return None, None, None
        return ctx, wm, window
    except RecursionError:
        return None, None, None
    if wm is None or window is None:
        return None, None, None
    return ctx, wm, window


def _modal_scheduler_requested(prefs=None) -> bool:
    prefs = _prefs() if prefs is None else prefs
    if prefs is not None:
        return _runtime_requested(prefs)
    return _runtime_recovery_requested(None, allow_missing_timer=True)


def _modal_scheduler_wake_at(now: float, prefs=None) -> float:
    wake_at = None
    try:
        wake_at = _next_wake_at(now, prefs)
    except Exception:
        wake_at = None
    for candidate in (
        wake_at,
        _SF_STATE.next_deadline,
        _SF_CLOCK.get("timer_wake_at"),
    ):
        try:
            if candidate is not None:
                return max(float(now) + 1.0, float(candidate))
        except Exception:
            pass
    return float(now) + 2.0


def _modal_record(instance=None):
    ledger = _ledger()
    record = (
        ledger.get("modal_scheduler")
        if isinstance(ledger, Mapping)
        else None
    )
    if not isinstance(record, Mapping):
        return None
    if instance is not None and record.get("instance") is not instance:
        return None
    if (
        record.get("token") is not _SF_RUNTIME_TOKEN
        or record.get("generation") != _SF_RUNTIME_GENERATION
    ):
        return None
    return record


def _modal_scheduler_is_active() -> bool:
    instance = _SF_MODAL_PUMP_INSTANCE
    if instance is None:
        return False
    record = _modal_record(instance)
    return bool(
        instance is not None
        and record is not None
        and record.get("event_timer") is _SF_MODAL_EVENT_TIMER
        and _SF_MODAL_OWNER_TOKEN is _SF_RUNTIME_TOKEN
        and _SF_MODAL_OWNER_GENERATION == _SF_RUNTIME_GENERATION
    )


def _modal_pump_instance_present(instance=None) -> bool:
    target = _SF_MODAL_PUMP_INSTANCE if instance is None else instance
    if target is None:
        return False
    try:
        ctx = getattr(bpy, "context", None)
        windows = []
        window = getattr(ctx, "window", None)
        if window is not None:
            windows.append(window)
        wm = getattr(ctx, "window_manager", None)
        for candidate in tuple(getattr(wm, "windows", ()) or ()) if wm is not None else ():
            if candidate not in windows:
                windows.append(candidate)
        for candidate in windows:
            if any(operator is target for operator in tuple(getattr(candidate, "modal_operators", ()) or ())):
                return True
        if any(operator is target for operator in tuple(getattr(ctx, "modal_operators", ()) or ())) if ctx is not None else False:
            return True
        return False
    except Exception:
        return True


def _publish_modal_record(instance, event_timer, wake_at: float, kind: str) -> None:
    ledger = _ledger()
    if isinstance(ledger, dict):
        ledger["modal_scheduler"] = {
            "instance": instance,
            "event_timer": event_timer,
            "wake_at": float(wake_at),
            "kind": str(kind or "deadline"),
            "token": _SF_RUNTIME_TOKEN,
            "generation": _SF_RUNTIME_GENERATION,
            "remover": _unregister_modal_scheduler,
        }


def _modal_pump_set_timer(instance, context=None, *, wake_at=None, kind: str = "") -> bool:
    global _SF_MODAL_EVENT_TIMER, _SF_MODAL_WAKE_AT, _SF_MODAL_KIND
    _ctx, wm, window = _modal_context_parts(context)
    if wm is None or window is None:
        return False
    now = time.monotonic()
    target_wake = _modal_scheduler_wake_at(now, _prefs(context)) if wake_at is None else float(wake_at)
    old_timer = getattr(instance, "_sf_event_timer", None)
    if old_timer is not None:
        try:
            wm.event_timer_remove(old_timer)
        except Exception:
            return False
    try:
        event_timer = wm.event_timer_add(_timer_delay(target_wake, now), window=window)
    except Exception:
        return False
    try:
        instance._sf_event_timer = event_timer
    except Exception:
        pass
    _SF_MODAL_EVENT_TIMER = event_timer
    _SF_MODAL_WAKE_AT = float(target_wake)
    _SF_MODAL_KIND = str(kind or _SF_MODAL_KIND or _SF_TIMER_KIND or "deadline")
    _publish_modal_record(instance, event_timer, float(target_wake), _SF_MODAL_KIND)
    return True


def _register_modal_pump_class() -> bool:
    global _SF_MODAL_PUMP_CLASS_REGISTERED
    if _SF_MODAL_PUMP_CLASS_REGISTERED:
        return True
    try:
        bpy.utils.register_class(WM_OT_smart_file_autosave_modal_pump)
        _SF_MODAL_PUMP_CLASS_REGISTERED = True
        return True
    except ValueError:
        _SF_MODAL_PUMP_CLASS_REGISTERED = True
        return True
    except Exception as exc:
        _SF_STATE.record_retry(
            now=time.monotonic(),
            kind=FailureKind.TIMER,
            reason=f"modal autosave scheduler class registration failed: {_error_text(exc)}",
            next_condition="WindowManager event timer availability or app timer dispatch",
            blocker_signature="modal_scheduler_class",
        )
        _persist_state()
        return False


def _modal_pump_execute(instance, context):
    global _SF_MODAL_PUMP_EXECUTING
    if _SF_MODAL_PUMP_EXECUTING:
        try:
            setattr(instance, "_sf_cancel_requested", True)
        except Exception:
            pass
        return {"CANCELLED"}
    _SF_MODAL_PUMP_EXECUTING = True
    try:
        return _modal_pump_execute_owned(instance, context)
    finally:
        _SF_MODAL_PUMP_EXECUTING = False


def _modal_pump_execute_owned(instance, context):
    global _SF_MODAL_PUMP_INSTANCE, _SF_MODAL_OWNER_TOKEN, _SF_MODAL_OWNER_GENERATION
    if not _SF_MODAL_STARTING and not _modal_scheduler_requested(_prefs(context)):
        return {"CANCELLED"}
    if (
        _SF_MODAL_STARTING
        and (
            _SF_MODAL_OWNER_TOKEN is not _SF_RUNTIME_TOKEN
            or _SF_MODAL_OWNER_GENERATION != _SF_RUNTIME_GENERATION
        )
    ):
        return {"CANCELLED"}
    if _SF_MODAL_PUMP_INSTANCE is not None and _SF_MODAL_PUMP_INSTANCE is not instance:
        try:
            setattr(_SF_MODAL_PUMP_INSTANCE, "_sf_cancel_requested", True)
        except Exception:
            pass
    _SF_MODAL_PUMP_INSTANCE = instance
    _SF_MODAL_OWNER_TOKEN = _SF_RUNTIME_TOKEN
    _SF_MODAL_OWNER_GENERATION = _SF_RUNTIME_GENERATION
    retry_deadline = time.monotonic() + _SF_MODAL_TIMER_RECURSION_RETRY_DELAY
    try:
        timer_ok = _modal_pump_set_timer(
            instance,
            context,
            wake_at=_SF_MODAL_WAKE_AT,
            kind=_SF_MODAL_KIND or _SF_TIMER_KIND or "deadline",
        )
    except RecursionError:
        consecutive_failures = _SF_STATE.consecutive_failures or 0
        if consecutive_failures < 0:
            consecutive_failures = 0
        _SF_STATE.consecutive_failures = consecutive_failures + 1
        _SF_STATE.failure_kind = _SF_FAILURE_KIND_TIMER
        _SF_STATE.retry_reason = _SF_MODAL_TIMER_RECURSION_REASON
        _SF_STATE.next_retry_condition = _SF_MODAL_TIMER_RECURSION_NEXT_CONDITION
        _SF_STATE.retry_epoch_signature = _SF_MODAL_TIMER_RECURSION_EPOCH_SIGNATURE
        _SF_STATE.last_blocker_signature = _SF_MODAL_TIMER_RECURSION_BLOCKER_SIGNATURE
        _SF_STATE.last_runtime_error = _SF_MODAL_TIMER_RECURSION_REASON
        _SF_STATE.phase = RuntimePhase.RETRYING
        _SF_STATE.watching = False
        _SF_STATE.next_deadline = retry_deadline
        timer_ok = False
    if not timer_ok:
        _SF_MODAL_PUMP_INSTANCE = None
        return {"CANCELLED"}
    try:
        context.window_manager.modal_handler_add(instance)
    except Exception as exc:
        _modal_pump_cancel(instance, context)
        _SF_STATE.record_retry(
            now=time.monotonic(),
            kind=FailureKind.TIMER,
            reason=f"modal autosave scheduler handler registration failed: {_error_text(exc)}",
            next_condition="WindowManager modal handler availability or app timer dispatch",
            blocker_signature="modal_scheduler_handler",
        )
        _persist_state()
        return {"CANCELLED"}
    _persist_state()
    return {"RUNNING_MODAL"}


def _modal_pump_cancel(instance, context=None) -> bool:
    global _SF_MODAL_PUMP_INSTANCE, _SF_MODAL_EVENT_TIMER
    global _SF_MODAL_OWNER_TOKEN, _SF_MODAL_OWNER_GENERATION, _SF_MODAL_WAKE_AT, _SF_MODAL_KIND
    ok = True
    _ctx, wm, _window = _modal_context_parts(context)
    event_timer = getattr(instance, "_sf_event_timer", None)
    if event_timer is not None and wm is not None:
        try:
            wm.event_timer_remove(event_timer)
        except Exception:
            ok = False
    try:
        instance._sf_event_timer = None
    except Exception:
        pass
    if _SF_MODAL_PUMP_INSTANCE is instance:
        _SF_MODAL_PUMP_INSTANCE = None
    if _SF_MODAL_EVENT_TIMER is event_timer:
        _SF_MODAL_EVENT_TIMER = None
    _SF_MODAL_OWNER_TOKEN = None
    _SF_MODAL_OWNER_GENERATION = ""
    _SF_MODAL_WAKE_AT = None
    _SF_MODAL_KIND = ""
    ledger = _ledger()
    if isinstance(ledger, dict):
        record = ledger.get("modal_scheduler")
        if not isinstance(record, Mapping) or record.get("instance") is instance:
            ledger["modal_scheduler"] = None
    return bool(ok)


def _modal_pump_detach_reference(instance) -> None:
    """Drop the module-owned modal instance reference without stealing Blender's cancel event.

    ``unregister_runtime()`` cannot synchronously remove a modal operator from
    Blender.  It first arms a short event timer so the modal callback can return
    ``CANCELLED``.  During full add-on disable the module must nevertheless stop
    advertising an owned modal resource immediately; the modal callback still
    owns its instance-local event timer and will remove it when Blender delivers
    the cancel event.
    """
    global _SF_MODAL_PUMP_INSTANCE, _SF_MODAL_OWNER_TOKEN, _SF_MODAL_OWNER_GENERATION
    if _SF_MODAL_PUMP_INSTANCE is instance:
        _SF_MODAL_PUMP_INSTANCE = None
    _SF_MODAL_OWNER_TOKEN = None
    _SF_MODAL_OWNER_GENERATION = ""
    ledger = _ledger()
    if isinstance(ledger, dict):
        record = ledger.get("modal_scheduler")
        if not isinstance(record, Mapping) or record.get("instance") is instance:
            ledger["modal_scheduler"] = None


def _modal_pump_request_stop(instance, context=None) -> bool:
    """Ask Blender's modal handler to cancel on its own next event.

    A modal operator cannot be synchronously removed from ``window.modal_operators``.
    Removing its event timer before the modal callback observes a cancel request
    leaves an inert operator residue.  Keep one short owned event timer so the
    callback can return ``CANCELLED`` and run the normal cancel cleanup.
    """
    global _SF_MODAL_EVENT_TIMER, _SF_MODAL_WAKE_AT, _SF_MODAL_KIND
    ok = True
    try:
        setattr(instance, "_sf_cancel_requested", True)
    except Exception:
        ok = False
    _ctx, wm, window = _modal_context_parts(context)
    if wm is None or window is None:
        return bool(_modal_pump_cancel(instance, context) and ok)
    old_timer = getattr(instance, "_sf_event_timer", None)
    event_timer = None
    try:
        event_timer = wm.event_timer_add(0.05, window=window)
    except Exception:
        event_timer = None
    if event_timer is None:
        if old_timer is None:
            return False
        event_timer = old_timer
        ok = False
    elif old_timer is not None:
        try:
            wm.event_timer_remove(old_timer)
        except Exception:
            ok = False
    try:
        instance._sf_event_timer = event_timer
    except Exception:
        pass
    _SF_MODAL_EVENT_TIMER = event_timer
    _SF_MODAL_WAKE_AT = time.monotonic()
    _SF_MODAL_KIND = "cancel"
    _publish_modal_record(instance, event_timer, float(_SF_MODAL_WAKE_AT), "cancel")
    return bool(ok)


def _modal_unregister_class_now() -> bool:
    global _SF_MODAL_PUMP_CLASS_REGISTERED
    if not _SF_MODAL_PUMP_CLASS_REGISTERED:
        return True
    try:
        bpy.utils.unregister_class(WM_OT_smart_file_autosave_modal_pump)
        _SF_MODAL_PUMP_CLASS_REGISTERED = False
        return True
    except Exception:
        return False


def _modal_unregister_class_retry():
    global _SF_MODAL_UNREGISTER_CLASS_PENDING, _SF_MODAL_UNREGISTER_CLASS_DEADLINE
    if not _SF_MODAL_UNREGISTER_CLASS_PENDING:
        return None
    now = time.monotonic()
    if _SF_MODAL_PUMP_INSTANCE is not None:
        if not _modal_scheduler_is_active() and not _modal_pump_instance_present(_SF_MODAL_PUMP_INSTANCE):
            _modal_pump_cancel(_SF_MODAL_PUMP_INSTANCE, getattr(bpy, "context", None))
    if _SF_MODAL_PUMP_INSTANCE is not None:
        if (
            _SF_MODAL_UNREGISTER_CLASS_DEADLINE is not None
            and now > float(_SF_MODAL_UNREGISTER_CLASS_DEADLINE)
        ):
            _SF_MODAL_UNREGISTER_CLASS_PENDING = False
            _SF_MODAL_UNREGISTER_CLASS_DEADLINE = None
            return None
        return 0.1
    if _modal_unregister_class_now():
        _SF_MODAL_UNREGISTER_CLASS_PENDING = False
        _SF_MODAL_UNREGISTER_CLASS_DEADLINE = None
        return None
    if (
        _SF_MODAL_UNREGISTER_CLASS_DEADLINE is not None
        and now <= float(_SF_MODAL_UNREGISTER_CLASS_DEADLINE)
    ):
        return 0.25
    _SF_MODAL_UNREGISTER_CLASS_PENDING = False
    _SF_MODAL_UNREGISTER_CLASS_DEADLINE = None
    return None


def _schedule_modal_class_unregister_retry() -> bool:
    global _SF_MODAL_UNREGISTER_CLASS_PENDING, _SF_MODAL_UNREGISTER_CLASS_DEADLINE
    timers = _timers_api()
    if timers is None:
        return False
    _SF_MODAL_UNREGISTER_CLASS_PENDING = True
    _SF_MODAL_UNREGISTER_CLASS_DEADLINE = time.monotonic() + 5.0
    try:
        if not timers.is_registered(_modal_unregister_class_retry):
            timers.register(_modal_unregister_class_retry, first_interval=0.1)
        return True
    except Exception:
        return False


def _modal_pump_modal(instance, context, event):
    if (
        getattr(instance, "_sf_cancel_requested", False)
        or not _modal_scheduler_is_active()
        or not _modal_scheduler_requested(_prefs(context))
    ):
        _modal_pump_cancel(instance, context)
        return {"CANCELLED"}
    if str(getattr(event, "type", "") or "") != "TIMER":
        return {"PASS_THROUGH"}
    event_timer = getattr(event, "timer", None)
    owned_timer = getattr(instance, "_sf_event_timer", None)
    if event_timer is not None and owned_timer is not None and event_timer is not owned_timer:
        return {"PASS_THROUGH"}
    now = time.monotonic()
    try:
        wake_at = _deadline_tick()
    except Exception as exc:
        _SF_STATE.record_retry(
            now=now,
            kind=FailureKind.UNKNOWN,
            reason=f"modal autosave scheduler tick failed: {_error_text(exc)}",
            next_condition="bounded retry on the same WindowManager event timer",
            blocker_signature="modal_scheduler_exception",
        )
        wake_at = _SF_STATE.next_deadline or (now + 2.0)
        _persist_state()
    if wake_at is None:
        wake_at = _modal_scheduler_wake_at(time.monotonic(), _prefs(context))
    if not _modal_pump_set_timer(instance, context, wake_at=float(wake_at), kind=_SF_TIMER_KIND or "deadline"):
        _SF_STATE.record_retry(
            now=time.monotonic(),
            kind=FailureKind.TIMER,
            reason="modal autosave scheduler event timer rearm failed",
            next_condition="WindowManager event timer availability or app timer dispatch",
            blocker_signature="modal_scheduler_rearm",
        )
        _persist_state()
        return {"RUNNING_MODAL"}
    return {"RUNNING_MODAL"}


def _ensure_modal_scheduler(context=None, *, wake_at=None, kind: str = "") -> bool:
    global _SF_MODAL_PUMP_CLASS_REGISTERED, _SF_MODAL_STARTING
    global _SF_MODAL_OWNER_TOKEN, _SF_MODAL_OWNER_GENERATION, _SF_MODAL_WAKE_AT, _SF_MODAL_KIND
    if bool(getattr(getattr(bpy, "app", None), "background", False)):
        return False
    if not _modal_scheduler_requested(_prefs(context)):
        return False
    _ctx, wm, window = _modal_context_parts(context)
    if wm is None or window is None:
        return False
    if not _register_modal_pump_class():
        return False
    instance = _SF_MODAL_PUMP_INSTANCE
    if _modal_scheduler_is_active() and instance is not None:
        return _modal_pump_set_timer(
            instance,
            context,
            wake_at=wake_at,
            kind=str(kind or _SF_TIMER_KIND or "deadline"),
        )
    try:
        op = getattr(getattr(bpy.ops, "wm", None), "smart_file_autosave_modal_pump", None)
        if not callable(op):
            _SF_MODAL_PUMP_CLASS_REGISTERED = False
            if not _register_modal_pump_class():
                return False
            op = getattr(getattr(bpy.ops, "wm", None), "smart_file_autosave_modal_pump", None)
        if not callable(op):
            return False
        now = time.monotonic()
        target_wake = _modal_scheduler_wake_at(now, _prefs(context)) if wake_at is None else float(wake_at)
        _SF_MODAL_OWNER_TOKEN = _SF_RUNTIME_TOKEN
        _SF_MODAL_OWNER_GENERATION = _SF_RUNTIME_GENERATION
        _SF_MODAL_WAKE_AT = float(target_wake)
        _SF_MODAL_KIND = str(kind or _SF_TIMER_KIND or "deadline")
        _SF_MODAL_STARTING = True
        try:
            with bpy.context.temp_override(window=window):
                result = op("INVOKE_DEFAULT")
        finally:
            _SF_MODAL_STARTING = False
        return "RUNNING_MODAL" in set(result or ())
    except Exception as exc:
        _SF_STATE.record_retry(
            now=time.monotonic(),
            kind=FailureKind.TIMER,
            reason=f"modal autosave scheduler start failed: {_error_text(exc)}",
            next_condition="WindowManager operator availability or app timer dispatch",
            blocker_signature="modal_scheduler_start",
        )
        _persist_state()
        return False


def _unregister_modal_scheduler(*, unregister_class: bool = False) -> bool:
    global _SF_MODAL_PUMP_CLASS_REGISTERED
    ok = True
    instance = _SF_MODAL_PUMP_INSTANCE
    if instance is not None:
        if _modal_pump_request_stop(instance, getattr(bpy, "context", None)):
            if unregister_class:
                _modal_pump_detach_reference(instance)
        else:
            ok = False
    ledger = _ledger()
    if isinstance(ledger, dict) and instance is None:
        ledger["modal_scheduler"] = None
    if unregister_class and instance is not None:
        if not _schedule_modal_class_unregister_retry():
            ok = False
    elif unregister_class and _SF_MODAL_PUMP_CLASS_REGISTERED:
        if not _modal_unregister_class_now():
            ok = False
    return bool(ok)


def _pull_registered_timer_earlier(
    wake_at: float,
    now: float,
    *,
    kind: str,
    force_successor: bool = False,
) -> bool:
    """Move the recurring service earlier through one exact-owner handoff.

    Blender does not expose an API for changing a registered timer's next wake.
    Ordinary autosave cycles therefore keep returning a delay from the same
    callback.  An explicit retry deadline can be materially earlier than the
    native deadline already queued by Blender, so the native timer is first
    retired and the single module-level persistent callback is registered again
    with the earlier wake.  The callback identity is deliberately stable; only
    native registration ownership is replaced.

    The handoff publishes the successor only after native registration returns
    or reads back positively.  Unknown ownership never authorizes a second
    callback, and dirty/deadline state is never cleared here.
    """
    global _SF_TIMER_CALLBACK, _SF_TIMER_KIND
    callback = _SF_TIMER_CALLBACK
    timers = _timers_api()
    ledger = _ledger()
    record = ledger.get("timer") if isinstance(ledger, Mapping) else None
    if (
        callback is None
        or timers is None
        or _SF_TIMER_EXECUTING_CALLBACK is callback
        or not isinstance(record, dict)
        or record.get("callback") is not callback
        or record.get("token") is not _SF_RUNTIME_TOKEN
        or record.get("generation") != _SF_RUNTIME_GENERATION
    ):
        return False
    try:
        old_wake = float(record.get("wake_at") or _SF_CLOCK.get("timer_wake_at") or wake_at)
    except Exception:
        old_wake = float(wake_at)

    def retain_unknown(reason: str, exc: Exception) -> bool:
        """Preserve ambiguous ownership and hand repair to the outer caller.

        Registering into an unknown state could duplicate a still-live callback;
        clearing it could orphan one.  Returning ``False`` makes the caller use
        the separate lifecycle repair owner after this rearm stack has unwound.
        """
        _SF_STATE.record_retry(
            now=float(now),
            kind=FailureKind.TIMER,
            reason=f"{reason}: {_error_text(exc)}",
            next_condition="bounded lifecycle timer ownership reconciliation",
            blocker_signature="timer_early_rearm_unknown",
        )
        _SF_TIMER_KIND = str(kind or _SF_TIMER_KIND or "deadline")
        _SF_CLOCK["timer_wake_at"] = float(old_wake)
        record["wake_at"] = float(old_wake)
        record["provisional"] = True
        _persist_state()
        return False
    target_wake = min(float(wake_at), float(old_wake))
    if force_successor:
        # A post-load successor created from a Blender handler must prove it can
        # dispatch promptly.  The first callback is only a liveness checkpoint:
        # _deadline_tick observes that the real feature deadline is still in the
        # future and returns the ordinary delay without creating a duplicate save.
        target_wake = min(target_wake, float(now) + 1.0)

    # Sub-second drift is not worth a native unregister/register transaction
    # unless a safe post-load repair is replacing a callback that still reads
    # native-registered but no longer dispatches.
    if not force_successor and float(wake_at) >= old_wake - 0.25:
        return True

    native_before = _native_timer_state(timers, callback)
    if native_before is None:
        return retain_unknown(
            "recurring timer early rearm preflight was not readable",
            RuntimeError("native timer state is unknown"),
        )
    unregister_error = None
    try:
        if native_before is True:
            timers.unregister(callback)
        # A definitively missing callback skips unregister and proceeds to
        # exact-callable registration below.
    except Exception as exc:
        unregister_error = exc
        native_after_error = _native_timer_state(timers, callback)
        if native_after_error is not False:
            return retain_unknown(
                "recurring timer early unregister was not confirmed", exc
            )
        # Some registries remove the callback and only then report an error.
        # Definitive absence is safe to repair with the exact same callable.
    else:
        if native_before is True:
            native_after = _native_timer_state(timers, callback)
            if native_after is not False:
                return retain_unknown(
                    "recurring timer retirement was not confirmed",
                    RuntimeError("native timer state is not definitively absent"),
                )

    # Native absence is now confirmed (or a normal unregister return is positive
    # retirement evidence).  Clear only the exact ledger record and re-register
    # the same module-level persistent callback.  Calling the fresh registration
    # helper here is bounded to one level and cannot re-enter this pull branch.
    if _SF_TIMER_CALLBACK is callback:
        _SF_TIMER_CALLBACK = None
        _SF_TIMER_KIND = ""
    _SF_CLOCK["timer_wake_at"] = None
    if isinstance(ledger, dict) and ledger.get("timer") is record:
        ledger["timer"] = None

    successor_registered = bool(
        _register_fresh_deadline_timer(
            float(target_wake), float(now), kind=str(kind or "deadline")
        )
    )
    successor = _SF_TIMER_CALLBACK
    successor_ledger = _ledger()
    successor_record = (
        successor_ledger.get("timer")
        if isinstance(successor_ledger, Mapping)
        else None
    )
    successor_exact = bool(
        successor_registered
        and successor is not None
        and successor is callback
        and isinstance(successor_record, Mapping)
        and successor_record.get("callback") is successor
        and successor_record.get("token") is _SF_RUNTIME_TOKEN
        and successor_record.get("generation") == _SF_RUNTIME_GENERATION
    )
    if not successor_exact:
        _SF_STATE.record_retry(
            now=float(now),
            kind=FailureKind.TIMER,
            reason="recurring timer successor registration failed",
            next_condition="lifecycle owner repair or timer registry recovery",
            blocker_signature="timer_early_successor_registration",
        )
        _persist_state()
        return False

    if unregister_error is not None:
        _SF_STATE.record_retry(
            now=float(now),
            kind=FailureKind.TIMER,
            reason=f"recurring timer handoff recovered after: {_error_text(unregister_error)}",
            next_condition="bounded retry on the exact successor callback",
            blocker_signature="timer_early_successor_recovered",
        )
    _persist_state()
    return True


def _deadline_timer_exact_owner(candidate, callback) -> bool:
    record = candidate.get("timer") if isinstance(candidate, Mapping) else None
    return bool(
        isinstance(candidate, Mapping)
        and candidate.get("token") is _SF_RUNTIME_TOKEN
        and candidate.get("generation") == _SF_RUNTIME_GENERATION
        and isinstance(record, Mapping)
        and record.get("callback") is callback
        and record.get("token") is _SF_RUNTIME_TOKEN
        and record.get("generation") == _SF_RUNTIME_GENERATION
    )


@persistent
def _deadline_timer_callback():
    """Single module-level persistent timer callback for the current generation."""
    global _SF_TIMER_CALLBACK, _SF_TIMER_EXECUTING_CALLBACK, _SF_TIMER_KIND
    callback = _deadline_timer_callback
    incumbent = _SF_TIMER_EXECUTING_CALLBACK
    if incumbent is not None and incumbent is not callback:
        # Blender callbacks are serialized, but fail closed if a foreign
        # generation is observed executing in this module instance.
        return 2.0
    _SF_TIMER_EXECUTING_CALLBACK = callback
    try:
        ledger = _ledger()
        if not _deadline_timer_exact_owner(ledger, callback):
            # File loads can transiently clear driver_namespace while
            # persistent handlers/timers from this exact module generation are
            # still alive. Keep this callback alive when the module global still
            # identifies it as the owned timer, even before the ledger is
            # reattached.
            recoverable_gap = bool(
                ledger is None
                and _SF_STATE.enabled
                and _SF_TIMER_CALLBACK is callback
            )
            if recoverable_gap:
                _request_lifecycle_repair(
                    "recurring autosave timer recovered a missing generation ledger"
                )
                ledger = _ledger()
            if not _deadline_timer_exact_owner(ledger, callback):
                if recoverable_gap and _SF_TIMER_CALLBACK is callback:
                    retry_at = time.monotonic() + 2.0
                    _SF_CLOCK["timer_wake_at"] = retry_at
                    return _timer_delay(retry_at, time.monotonic())
                return None

        timer_record = ledger.get("timer") if isinstance(ledger, Mapping) else None
        if isinstance(timer_record, dict) and timer_record.get("provisional"):
            # Actual dispatch is positive native ownership evidence.
            timer_record["provisional"] = False

        wake_at_inner = None
        try:
            wake_at_inner = _deadline_tick()
        except Exception as exc:
            now_inner = time.monotonic()
            _SF_STATE.record_retry(
                now=now_inner,
                kind=FailureKind.UNKNOWN,
                reason=f"deadline callback failed: {_error_text(exc)}",
                next_condition="bounded retry deadline or state-change wake",
                blocker_signature="deadline_exception",
            )
            wake_at_inner = _SF_STATE.next_deadline
            _persist_state()

        current_ledger = _ledger()
        if (
            not _deadline_timer_exact_owner(current_ledger, callback)
            or _SF_TIMER_CALLBACK is not callback
        ):
            return None

        try:
            current_prefs = _prefs()
            if current_prefs is not None:
                if not _runtime_requested(current_prefs):
                    # Readable OFF is authoritative.  Retire the exact record
                    # and let Blender unregister this callback from its None.
                    _SF_TIMER_CALLBACK = None
                    _SF_TIMER_KIND = ""
                    _SF_CLOCK["timer_wake_at"] = None
                    current_ledger["timer"] = None
                    _persist_state()
                    return None
            elif not _runtime_recovery_requested(
                current_prefs, allow_missing_timer=False
            ):
                return None

            now_after = time.monotonic()
            if wake_at_inner is None:
                wake_at_inner = _next_wake_at(now_after, current_prefs)
            if wake_at_inner is None:
                _SF_STATE.record_retry(
                    now=now_after,
                    kind=FailureKind.TIMER,
                    reason="automatic history recurring timer has no deadline",
                    next_condition="settings or lifecycle recovery",
                    blocker_signature="recurring_no_deadline",
                )
                wake_at_inner = _SF_STATE.next_deadline or (now_after + 2.0)
            wake_at_inner = max(now_after + 1.0, float(wake_at_inner))
            _SF_CLOCK["timer_wake_at"] = wake_at_inner
            timer_record = current_ledger.get("timer")
            if isinstance(timer_record, dict):
                timer_record["wake_at"] = wake_at_inner
            _ensure_modal_scheduler(
                None,
                wake_at=float(wake_at_inner),
                kind=_SF_TIMER_KIND or "deadline",
            )
            _persist_state()
            return _timer_delay(wake_at_inner, now_after)
        except Exception as exc:
            # Never let a live exact generation disappear because post-tick
            # bookkeeping raised. Preserve dirty state and ask Blender to invoke
            # this same callback after the bounded retry delay.
            now_after = time.monotonic()
            try:
                _SF_STATE.record_retry(
                    now=now_after,
                    kind=FailureKind.UNKNOWN,
                    reason=f"recurring deadline bookkeeping failed: {_error_text(exc)}",
                    next_condition="bounded retry on the same timer identity",
                    blocker_signature="recurring_bookkeeping_exception",
                )
                retry_at = _SF_STATE.next_deadline or (now_after + 2.0)
                _SF_CLOCK["timer_wake_at"] = retry_at
                timer_record = current_ledger.get("timer")
                if isinstance(timer_record, dict):
                    timer_record["wake_at"] = retry_at
                _ensure_modal_scheduler(
                    None,
                    wake_at=float(retry_at),
                    kind=_SF_TIMER_KIND or "deadline_exception",
                )
                _persist_state()
                return _timer_delay(retry_at, now_after)
            except Exception:
                # The exact callback remains registered; use a finite native
                # retry even when diagnostic persistence itself is unavailable.
                return 2.0
    finally:
        if _SF_TIMER_EXECUTING_CALLBACK is callback:
            _SF_TIMER_EXECUTING_CALLBACK = None


def _register_fresh_deadline_timer(
    wake_at: float,
    now: float,
    *,
    kind: str,
) -> bool:
    """Create and publish one fresh recurring callback for this generation.

    This helper never removes an incumbent and never requests lifecycle repair.
    Callers must first establish that no exact native callback is registered.
    A raised registration with unknown readback is retained as one provisional
    owner, never as permission to create a second callback.
    """
    global _SF_TIMER_CALLBACK, _SF_TIMER_EXECUTING_CALLBACK, _SF_TIMER_KIND
    token = _SF_RUNTIME_TOKEN
    generation = _SF_RUNTIME_GENERATION
    _deadline_callback = _deadline_timer_callback
    timers = _timers_api()
    if timers is None:
        _SF_STATE.record_retry(
            now=now,
            kind=FailureKind.TIMER,
            reason="bpy.app.timers is unavailable",
            next_condition="timer service becomes available or manual refresh",
            blocker_signature="timers_unavailable",
        )
        _persist_state()
        return False

    register_returned = False
    registration_error = None
    try:
        timers.register(
            _deadline_callback,
            first_interval=_timer_delay(float(wake_at), now),
            persistent=True,
        )
        register_returned = True
    except Exception as exc:
        registration_error = exc

    native_after_register = _native_timer_state(timers, _deadline_callback)
    confirmed = bool(
        native_after_register is not False
        and (register_returned or native_after_register is True)
    )
    provisional = bool(
        not confirmed
        and registration_error is not None
        and native_after_register is None
    )
    if confirmed or provisional:
        _SF_TIMER_CALLBACK = _deadline_callback
        _SF_TIMER_KIND = str(kind)
        _SF_CLOCK["timer_wake_at"] = float(wake_at)
        ledger = _ledger()
        if ledger is not None:
            ledger["timer"] = {
                "callback": _deadline_callback,
                "generation": generation,
                "token": token,
                "wake_at": float(wake_at),
                "one_shot": False,
                "self_rescheduling": True,
                "persistent": True,
                "provisional": bool(provisional),
                "remover": _unregister_timer,
            }
        _ensure_modal_scheduler(
            None,
            wake_at=float(wake_at),
            kind=str(kind or "deadline"),
        )
        if provisional:
            _SF_STATE.record_retry(
                now=now,
                kind=FailureKind.TIMER,
                reason=f"deadline timer registration ownership is unknown: {_error_text(registration_error)}",
                next_condition="native timer readback or lifecycle reconciliation",
                blocker_signature="timer_registration_provisional",
            )
        elif registration_error is not None:
            _SF_STATE.record_retry(
                now=now,
                kind=FailureKind.TIMER,
                reason=f"deadline timer registration recovered after: {_error_text(registration_error)}",
                next_condition="bounded execution on the exact callback",
                blocker_signature="timer_registration_recovered",
            )
        _persist_state()
        return not provisional

    _SF_TIMER_CALLBACK = None
    _SF_TIMER_KIND = ""
    _SF_CLOCK["timer_wake_at"] = None
    ledger = _ledger()
    if isinstance(ledger, dict):
        ledger["timer"] = None
    _SF_STATE.record_retry(
        now=now,
        kind=FailureKind.TIMER,
        reason=(
            "deadline timer registration was not confirmed"
            if registration_error is None
            else f"deadline timer registration failed: {_error_text(registration_error)}"
        ),
        next_condition="bounded lifecycle timer registry recovery",
        blocker_signature="timer_registration",
    )
    _persist_state()
    return False


def _prepare_timer_for_file_load(now: float) -> bool:
    """Pull the exact native timer to a near post-load liveness checkpoint."""
    callback = _SF_TIMER_CALLBACK
    timers = _timers_api()
    if callback is None or timers is None or _SF_TIMER_EXECUTING_CALLBACK is callback:
        return False
    ledger = _ledger()
    record = ledger.get("timer") if isinstance(ledger, Mapping) else None
    if (
        not isinstance(record, Mapping)
        or record.get("callback") is not callback
        or record.get("token") is not _SF_RUNTIME_TOKEN
        or record.get("generation") != _SF_RUNTIME_GENERATION
    ):
        return False
    if _native_timer_state(timers, callback) is not True:
        return False
    return bool(
        _pull_registered_timer_earlier(
            float(now) + 1.0,
            float(now),
            kind="load_pre_liveness",
            force_successor=True,
        )
    )


def _schedule_timer(
    *,
    force: bool = False,
    kind: str = "deadline",
    allow_recovery: bool = False,
    allow_earlier_pull: bool = True,
) -> bool:
    global _SF_TIMER_CALLBACK, _SF_TIMER_KIND, _SF_LOAD_POST_REPAIR_PENDING
    if not _SF_LEDGER_INSTALLED or not _is_current_generation():
        return False
    if _SF_LOAD_POST_DEPTH > 0 or not allow_earlier_pull:
        # No native timer operation is legal while Blender is dispatching a
        # file-load handler. ``allow_earlier_pull=False`` carries this contract
        # across the separate settings.load_post handler, where this module's
        # own depth is necessarily zero. Check exact ownership before even
        # reading prefs: a transient missing/explicit-OFF preference must not
        # reach the normal unregister path from either handler stack.
        ledger = _ledger()
        record = ledger.get("timer") if isinstance(ledger, Mapping) else None
        exact_incumbent = bool(
            _SF_TIMER_CALLBACK is not None
            and isinstance(record, Mapping)
            and record.get("callback") is _SF_TIMER_CALLBACK
            and record.get("token") is _SF_RUNTIME_TOKEN
            and record.get("generation") == _SF_RUNTIME_GENERATION
        )
        if exact_incumbent:
            native_state = _native_timer_state(_timers_api(), _SF_TIMER_CALLBACK)
            if native_state is False:
                _arm_timer_liveness_until_autosave()
                _SF_LOAD_POST_REPAIR_PENDING = True
                _SF_STATE.record_retry(
                    now=time.monotonic(),
                    kind=FailureKind.TIMER,
                    reason="deadline timer expired during file load; repair deferred until load_post returns",
                    next_condition="post-load lifecycle repair",
                    blocker_signature="load_post_timer_expired",
                )
                _persist_state()
                return False
            _SF_TIMER_KIND = str(kind or _SF_TIMER_KIND or "load_post")
            _ensure_modal_scheduler(
                None,
                wake_at=_SF_CLOCK.get("timer_wake_at"),
                kind=_SF_TIMER_KIND,
            )
            _persist_state()
            return True
        _SF_STATE.record_retry(
            now=time.monotonic(),
            kind=FailureKind.TIMER,
            reason="native timer repair deferred until load_post returns",
            next_condition="post-load lifecycle repair",
            blocker_signature="load_post_timer_mutation_forbidden",
        )
        _persist_state()
        return False
    prefs = _prefs()
    requested = (
        _runtime_recovery_requested(prefs, allow_missing_timer=True)
        if allow_recovery
        else _runtime_requested(prefs)
    )
    if not requested:
        _unregister_timer()
        return True
    now = time.monotonic()
    wake_at = _next_wake_at(now, prefs)
    if wake_at is None:
        _SF_STATE.record_retry(
            now=now,
            kind=FailureKind.TIMER,
            reason="automatic history has no deadline",
            next_condition="settings change or manual refresh",
            blocker_signature="no_deadline",
        )
        _persist_state()
        return False
    post_load_owner_recovery = bool(
        _SF_LOAD_POST_REPAIR_PENDING
        and not _SF_STATE.boundary_save_pending
        and not _SF_STATE.last_save_error
        and _SF_STATE.failure_kind in {
            FailureKind.REGISTRATION,
            FailureKind.TIMER,
            FailureKind.HANDLER,
            FailureKind.SETTINGS_OWNER,
            FailureKind.CONTEXT,
            FailureKind.UNKNOWN,
        }
    )
    if _timer_is_registered():
        # A live generation owns one self-rescheduling native callback. Ordinary
        # cycles never rotate that identity. A new explicit retry deadline can be
        # materially earlier than Blender's already-scheduled wake, so pull the
        # same callable forward through one guarded synchronous rearm.
        ledger = _ledger()
        timer_record = ledger.get("timer") if isinstance(ledger, Mapping) else None
        if (
            post_load_owner_recovery
            and isinstance(timer_record, Mapping)
            and timer_record.get("callback") is _SF_TIMER_CALLBACK
            and timer_record.get("token") is _SF_RUNTIME_TOKEN
            and timer_record.get("generation") == _SF_RUNTIME_GENERATION
        ):
            # A file-load handler stack must not turn its short logical retry
            # into a native unregister/register handoff.  With the autosave
            # scheduler registered as persistent, a positively native-live exact
            # incumbent is the safest owner: replacing it after load/save
            # boundaries has produced registered-but-never-dispatched successors.
            _SF_TIMER_KIND = str(kind or _SF_TIMER_KIND or "post_load_repair")
            native_state = _native_timer_state(_timers_api(), _SF_TIMER_CALLBACK)
            if native_state is True:
                _ensure_modal_scheduler(
                    None,
                    wake_at=wake_at,
                    kind=_SF_TIMER_KIND,
                )
                _persist_state()
                return True
            if native_state is None:
                _SF_STATE.record_retry(
                    now=now,
                    kind=FailureKind.TIMER,
                    reason="post-load timer state is unreadable; retaining exact owner without duplicate registration",
                    next_condition="next native timer readback or autosave deadline",
                    blocker_signature="post_load_timer_state_unknown",
                )
                _persist_state()
                return False
            _persist_state()
            return True
        _SF_TIMER_KIND = str(kind or _SF_TIMER_KIND or "deadline")
        wake_candidates = []
        for candidate_wake in (
            _SF_CLOCK.get("timer_wake_at"),
            timer_record.get("wake_at") if isinstance(timer_record, Mapping) else None,
        ):
            try:
                if candidate_wake is not None:
                    wake_candidates.append(float(candidate_wake))
            except Exception:
                pass
        current_wake = min(wake_candidates) if wake_candidates else None
        try:
            earlier = bool(
                current_wake is not None
                and float(wake_at) < float(current_wake) - 0.25
            )
        except Exception:
            earlier = False
        if earlier and _SF_TIMER_EXECUTING_CALLBACK is not _SF_TIMER_CALLBACK:
            if not allow_earlier_pull:
                # load_post runs inside Blender's file-load handler dispatch.
                # Replacing even a positively registered timer from this stack was
                # observed to create a native false-live callback. Keep the exact
                # incumbent and let its already-owned wake service retained work.
                _ensure_modal_scheduler(
                    None,
                    wake_at=wake_at,
                    kind=_SF_TIMER_KIND,
                )
                _persist_state()
                return True
            return _pull_registered_timer_earlier(
                float(wake_at), float(now), kind=str(kind or "deadline")
            )
        _ensure_modal_scheduler(
            None,
            wake_at=wake_at,
            kind=_SF_TIMER_KIND,
        )
        _persist_state()
        return True
    _unregister_timer()
    if post_load_owner_recovery:
        # If Blender has definitively removed the pre-load timer, replace it
        # only at the already-owned feature wake.  Short post-load liveness
        # successors registered from handler repair have been observed to report
        # native-live while never dispatching, which is worse than sleeping until
        # the real autosave deadline.
        regular_wake = _regular_wake_at(now, prefs)
        if regular_wake is not None:
            wake_at = float(regular_wake)
    return _register_fresh_deadline_timer(
        float(wake_at), float(now), kind=str(kind or "deadline")
    )


def _refresh_timer_after_external_save(now: float, prefs=None) -> bool:
    """Keep autosave alive after an external/manual Blender save boundary.

    A save handler is a native boundary where replacing the Python timer has
    repeatedly produced a registered-but-never-dispatched successor.  Once the
    timer is persistent and Blender still reports the exact owned callback as
    native-live, do not unregister/register it.  Arm a short dirty-only liveness
    wake and preserve the current callback.  Register a fresh callback only when
    native readback definitively says the owned one is gone.
    """
    if _SF_LOAD_POST_DEPTH > 0:
        return False
    prefs = prefs or _prefs()
    if not _runtime_requested(prefs):
        return False
    wake_at = _regular_wake_at(now, prefs)
    if wake_at is None:
        wake_at = float(now) + 5.0
    _arm_timer_liveness_until_autosave()
    if _SF_TIMER_CALLBACK is not None:
        timers = _timers_api()
        native_state = _native_timer_state(timers, _SF_TIMER_CALLBACK)
        if native_state is True and _timer_is_registered():
            _SF_TIMER_KIND = "save_post_boundary"
            _ensure_modal_scheduler(
                None,
                wake_at=wake_at,
                kind=_SF_TIMER_KIND,
            )
            _persist_state()
            return True
        if native_state is None:
            _SF_STATE.record_retry(
                now=now,
                kind=FailureKind.TIMER,
                reason="manual save timer state is unreadable; retaining exact owner without duplicate registration",
                next_condition="next native timer readback or autosave deadline",
                blocker_signature="save_post_timer_state_unknown",
            )
            _persist_state()
            return False
    wake_at = min(float(wake_at), float(now) + 1.0)
    return _register_fresh_deadline_timer(
        float(wake_at),
        float(now),
        kind="save_post_boundary",
    )

def _reschedule_timer(
    *,
    allow_postpone: bool = False,
    kind: str = "event",
    allow_recovery: bool = False,
) -> bool:
    scheduled = _schedule_timer(
        force=bool(allow_postpone),
        kind=kind,
        allow_recovery=bool(allow_recovery),
    )
    if (
        not scheduled
        and _SF_LEDGER_INSTALLED
        and _runtime_recovery_requested(_prefs(), allow_missing_timer=True)
    ):
        # The scheduling transaction has fully unwound here, so lifecycle repair
        # cannot recursively re-enter an in-progress native rearm.
        _request_lifecycle_repair(
            f"automatic history timer reschedule failed ({str(kind or 'event')})"
        )
    return bool(scheduled)

# ---- resident-modal discrimination (autosave permanence fix) -----------------
# A modal operator that merely RESIDES for the whole session (hover daemons,
# gizmo watchers, selection guards, screencast overlays) must not defer
# autosave forever: Blender saves fine while they run -- manual Ctrl+S has
# always worked with every one of them active.  Real interactions (drags,
# gestures) still defer the save briefly, exactly as before.
#
# Two layers:
#   1. a static exemption list of the in-house daemons measured on 2026-08-19
#      (each present continuously for whole sessions while autosave starved);
#   2. continuous-presence learning: any identifier that stays in the modal
#      stack for _SF_MODAL_RESIDENT_GRACE_SECONDS without a break is classified
#      resident for the rest of the session.  A genuine drag never lasts that
#      long; if the identifier ever leaves the stack, its clock resets.
_SF_MODAL_EXEMPT_STATIC = frozenset(
    form
    for dotted in (
        "view3d.sos_mouse_tracker",            # SmartOverlay mouse tracker
        "sos.uv_hover_daemon",                 # SmartOverlay UV hover daemon
        "view3d.csdt_smart_gizmo_watch",       # SmartTransform gizmo watcher
        "view3d.csdt_native_release_watch",    # SmartTransform release watcher
        "wm.sts_crossing_select_watch",        # SmartTransform crossing watcher
        "wm.smart_uv_crossing_watch",          # SmartUV crossing watcher
        "view3d.select_guard_modal",           # SmartTransform select guard
        "view3d.svo_plus_navigation_guard",    # SmartWorkspace navigation guard
        "wm.sk_screencast_keys",               # screencast keys overlay
        "none.poly_quilt_daemon",              # PolyQuilt daemon (SmartModeling)
        "smart_paint_bridge.paint_observer",   # SmartPaint bridge observer
        "mesh.smart_vert_slide_constraint_monitor",
        "smart_uv_suite.instant_select_modal_session",
    )
    for form in (
        dotted,
        "%s_OT_%s" % (dotted.split(".", 1)[0].upper(), dotted.split(".", 1)[1]),
    )
)
_SF_MODAL_RESIDENT_GRACE_SECONDS = 90.0
_SF_MODAL_FIRST_SEEN: dict = {}
_SF_MODAL_RESIDENT_LEARNED: set = set()


def _filter_blocking_modal_identifiers(identifiers):
    """Return only the identifiers that should genuinely defer an autosave."""
    now = time.monotonic()
    present = set(identifiers)
    for known in tuple(_SF_MODAL_FIRST_SEEN):
        if known not in present:
            # its continuous run ended: it was a real interaction, reset the clock
            _SF_MODAL_FIRST_SEEN.pop(known, None)
    blocking = []
    for identifier in identifiers:
        if identifier in _SF_MODAL_EXEMPT_STATIC or identifier in _SF_MODAL_RESIDENT_LEARNED:
            continue
        first = _SF_MODAL_FIRST_SEEN.setdefault(identifier, now)
        if (now - first) >= _SF_MODAL_RESIDENT_GRACE_SECONDS:
            _SF_MODAL_RESIDENT_LEARNED.add(identifier)
            continue
        blocking.append(identifier)
    return blocking


def _blocker(context=None) -> tuple[FailureKind, str, str]:
    ctx = context or getattr(bpy, "context", None)
    if _SF_SAVE_DEPTH > 0:
        return (
            FailureKind.SAVE_IN_PROGRESS,
            "Smart File snapshot save is already in progress",
            "current snapshot save completion",
        )
    try:
        wm = getattr(ctx, "window_manager", None)
        if wm is not None and bool(getattr(wm, "is_interface_locked", False)):
            return FailureKind.INTERFACE_LOCK, "Blender interface is locked", "interface unlock"
    except Exception:
        pass
    try:
        is_job_running = getattr(getattr(bpy, "app", None), "is_job_running", None)
        if callable(is_job_running) and bool(is_job_running("RENDER")):
            return FailureKind.RENDER, "render job is active", "render job completion"
    except Exception:
        pass
    try:
        screen = getattr(ctx, "screen", None)
        if screen is not None and bool(getattr(screen, "is_animation_playing", False)):
            return FailureKind.PLAYBACK, "animation playback is active", "playback stop"
    except Exception:
        pass
    try:
        # ``WindowManager.operators`` also contains completed operator history and
        # must not be treated as modal activity.  Only the live modal collections
        # exposed by windows/context are consulted.
        modal_operators = []
        seen_modal = set()
        windows = []
        window = getattr(ctx, "window", None)
        if window is not None:
            windows.append(window)
        wm = getattr(ctx, "window_manager", None)
        for candidate in tuple(getattr(wm, "windows", ()) or ()) if wm is not None else ():
            if candidate not in windows:
                windows.append(candidate)
        for candidate in windows:
            for operator in tuple(getattr(candidate, "modal_operators", ()) or ()):
                marker = id(operator)
                if marker not in seen_modal:
                    seen_modal.add(marker)
                    modal_operators.append(operator)
        for operator in tuple(getattr(ctx, "modal_operators", ()) or ()):
            marker = id(operator)
            if marker not in seen_modal:
                seen_modal.add(marker)
                modal_operators.append(operator)
        identifiers = []
        for operator in modal_operators[-16:]:
            identifier = str(
                getattr(operator, "bl_idname", "")
                or getattr(getattr(operator, "bl_rna", None), "identifier", "")
                or type(operator).__name__
            )
            if identifier not in {
                "UHM_OT_history_refresh_runtime",
                "UHM_OT_history_create_autosave_now",
                "UHM_OT_history_create_restore_point_now",
                "WM_OT_smart_file_autosave_modal_pump",
                "wm.smart_file_autosave_modal_pump",
            }:
                identifiers.append(identifier)
        identifiers = _filter_blocking_modal_identifiers(identifiers)
        if identifiers:
            return FailureKind.MODAL, f"modal operator is active: {identifiers[-1]}", "modal operator completion"
    except Exception:
        pass
    try:
        data = getattr(bpy, "data", None)
        if data is None:
            return FailureKind.CONTEXT, "Blender data context is unavailable", "data context availability"
        # Registration and validation never branch on bpy.app.background.
        # A windowless context is valid when Blender data already owns a scene;
        # otherwise wait for the normal scene/window availability event.
        scene = getattr(ctx, "scene", None)
        if scene is None and not tuple(getattr(data, "scenes", ()) or ()):
            return FailureKind.CONTEXT, "no scene context is available", "scene/window availability"
    except Exception:
        return FailureKind.CONTEXT, "context inspection failed", "context recovery"
    return FailureKind.NONE, "", ""


def _blocker_signature(kind: FailureKind, reason: str) -> str:
    return f"{kind.value}:{reason}"


def notify_runtime_state_change(context=None, reason: str = "state change") -> bool:
    """Wake one catch-up attempt only when a RETRYING blocker changed."""
    global _SF_LAST_BLOCKER_SIGNATURE
    if not _is_current_generation() or not _SF_LEDGER_INSTALLED:
        return False
    kind, blocker_reason, _condition = _blocker(context)
    signature = _blocker_signature(kind, blocker_reason)
    if (
        kind is FailureKind.NONE
        and _SF_STATE.phase is RuntimePhase.RETRYING
        and _SF_STATE.failure_kind in {
            FailureKind.STORAGE_PATH,
            FailureKind.SAVE_CANCELLED,
            FailureKind.SAVE_EXCEPTION,
            FailureKind.OUTPUT_MISSING,
            FailureKind.OUTPUT_EMPTY,
            FailureKind.OUTPUT_STALE,
            FailureKind.OUTPUT_CORRUPT,
            FailureKind.BOUNDARY,
        }
    ):
        signature = f"EVENT:{str(reason or 'state change')}"
    changed = signature != _SF_LAST_BLOCKER_SIGNATURE
    _SF_LAST_BLOCKER_SIGNATURE = signature
    woke = False
    if changed:
        woke = _SF_STATE.notify_state_change(
            now=time.monotonic(), blocker_signature=signature
        )
    if woke:
        prefs = _prefs(context)
        allow_recovery = bool(
            prefs is None and _runtime_gap_recovery_allowed()
        )
        _persist_state()
        _reschedule_timer(allow_recovery=allow_recovery)
    return woke


def mark_change_pending(context=None, source: str = "event") -> bool:
    if _internal_change_active() or not _is_current_generation():
        return False
    now = time.monotonic()
    _SF_STATE.mark_event(now)
    _RUNTIME["change_counter"] = int(_RUNTIME.get("change_counter", 0) or 0) + 1
    if _SF_STATE.phase is RuntimePhase.RETRYING:
        notify_runtime_state_change(context, source)
    # Keep the one configured feature deadline. Repeated events are coalesced
    # when an equal or earlier exact-generation timer already exists.
    if _SF_LEDGER_INSTALLED and _runtime_requested(_prefs(context)):
        _reschedule_timer(allow_postpone=False, kind="change_event")
    _persist_state()
    return True

def mark_user_activity(event_type: str = "", event_value: str = "") -> bool:
    # Compatibility only. Physical input is deliberately not used as dirty
    # evidence; real Blender dirty state and data/undo events drive autosave.
    del event_type, event_value
    return False


def user_activity_monitor_started() -> int:
    return 0


def user_activity_monitor_stopped(generation=None) -> None:
    del generation


def user_activity_monitor_ping() -> None:
    return None


def user_activity_monitor_should_continue(context=None, generation=None) -> bool:
    del context, generation
    return False


def _context_overrides(context=None) -> list[dict[str, Any]]:
    ctx = context or getattr(bpy, "context", None)
    result: list[dict[str, Any]] = []
    seen: set[tuple[int, int, int]] = set()

    def add(window=None, scene=None, view_layer=None):
        key = (id(window), id(scene), id(view_layer))
        if key in seen:
            return
        seen.add(key)
        override = {}
        if window is not None:
            override["window"] = window
        if scene is not None:
            override["scene"] = scene
        if view_layer is not None:
            override["view_layer"] = view_layer
        result.append(override)

    try:
        add(
            getattr(ctx, "window", None),
            getattr(ctx, "scene", None),
            getattr(ctx, "view_layer", None),
        )
    except Exception:
        pass
    try:
        wm = getattr(ctx, "window_manager", None)
        for window in tuple(getattr(wm, "windows", ()) or ()):
            scene = getattr(window, "scene", None)
            view_layer = getattr(window, "view_layer", None)
            add(window, scene, view_layer)
    except Exception:
        pass
    try:
        data = getattr(bpy, "data", None)
        for scene in tuple(getattr(data, "scenes", ()) or ())[:8]:
            view_layers = tuple(getattr(scene, "view_layers", ()) or ())
            add(None, scene, view_layers[0] if view_layers else None)
    except Exception:
        pass
    add()
    return result


def _operator_poll(override: dict[str, Any]) -> bool:
    try:
        operator = bpy.ops.wm.save_as_mainfile
        poll = getattr(operator, "poll", None)
        if not callable(poll):
            return True
        ctx = getattr(bpy, "context", None)
        temp_override = getattr(ctx, "temp_override", None)
        if override and callable(temp_override):
            with temp_override(**override):
                return bool(poll())
        return bool(poll())
    except Exception:
        return False


def _call_with_override(callback: Callable, context=None):
    """Try valid window/scene/view-layer overrides without repeated storage I/O.

    A failure before the verified transaction starts may use the next context.
    A verified CANCELLED result may also try the next context once.  Every path,
    capacity, readback, corruption, stale-output, or operator exception stops
    immediately so a single fault cannot issue repeated save transactions.
    """
    ctx = context or getattr(bpy, "context", None)
    pollable = [override for override in _context_overrides(ctx) if _operator_poll(override)]
    if not pollable:
        raise RuntimeError("save_as_mainfile has no valid context override")
    last_exception = None
    for index, override in enumerate(pollable):
        before = get_last_verified_write_result()
        try:
            temp_override = getattr(ctx, "temp_override", None)
            if override and callable(temp_override):
                with temp_override(**override):
                    result = callback()
            else:
                result = callback()
        except Exception as exc:
            last_exception = exc
            after = get_last_verified_write_result()
            transaction_started = after.sequence > before.sequence
            cancelled = transaction_started and str(after.failure_kind or "") == "SAVE_CANCELLED"
            if index + 1 < len(pollable) and (not transaction_started or cancelled):
                continue
            raise
        after = get_last_verified_write_result()
        if result is not None:
            return result
        transaction_started = after.sequence > before.sequence
        if not transaction_started and index + 1 < len(pollable):
            continue
        if (
            transaction_started
            and str(after.failure_kind or "") == "SAVE_CANCELLED"
            and index + 1 < len(pollable)
        ):
            continue
        return result
    if last_exception is not None:
        raise last_exception
    return None

def _failure_kind_from_storage(value: str) -> FailureKind:
    mapping = {
        "INTERFACE_LOCK": FailureKind.INTERFACE_LOCK,
        "SAVE_CANCELLED": FailureKind.SAVE_CANCELLED,
        "SAVE_EXCEPTION": FailureKind.SAVE_EXCEPTION,
        "OUTPUT_MISSING": FailureKind.OUTPUT_MISSING,
        "OUTPUT_EMPTY": FailureKind.OUTPUT_EMPTY,
        "OUTPUT_STALE": FailureKind.OUTPUT_STALE,
        "OUTPUT_CORRUPT": FailureKind.OUTPUT_CORRUPT,
        "INVALID_PATH": FailureKind.STORAGE_PATH,
        "ACCESS_DENIED": FailureKind.STORAGE_PATH,
        "DISK_FULL": FailureKind.STORAGE_PATH,
        "DRIVE_UNAVAILABLE": FailureKind.STORAGE_PATH,
        "PATH_UNAVAILABLE": FailureKind.STORAGE_PATH,
        "STORAGE_PATH": FailureKind.STORAGE_PATH,
        "OUTPUT_EXISTS": FailureKind.STORAGE_PATH,
    }
    return mapping.get(str(value or ""), FailureKind.SAVE_EXCEPTION)


def _attempt_history_save(
    feature: str, reason: str, context=None
) -> tuple[bool, str, str, FailureKind, Any]:
    before = get_last_verified_write_result()
    try:
        if feature == "autosave":
            callback = lambda: _log_autosave_with_ack(
                "Rolling autosave",
                _ui_text(f"Automatic save ({reason})", f'自動保存（{reason}）'),
                context=context,
            )
        else:
            callback = lambda: log_restore_point(
                "Timed restore point",
                _ui_text(f"Automatic restore point ({reason})", f'自動の復元ポイント（{reason}）'),
                context=context,
            )
        result = _call_with_override(callback, context)
    except Exception as exc:
        after = get_last_verified_write_result()
        if after.sequence > before.sequence:
            error = after.error or _error_text(exc)
            return False, "", str(error), _failure_kind_from_storage(after.failure_kind), False
        return False, "", _error_text(exc), FailureKind.CONTEXT, False
    after = get_last_verified_write_result()
    if feature == "autosave" and isinstance(result, tuple) and len(result) == 2:
        entry, ack_result = result
    else:
        entry, ack_result = result, True
    if (
        (entry is not None or _history_ack_aborted(ack_result))
        and after.sequence > before.sequence
        and after.success
        and after.committed
        and after.filepath
        and os.path.exists(after.filepath)
    ):
        return True, after.filepath, "", FailureKind.NONE, ack_result
    error = after.error or _RUNTIME.get("last_save_error") or f"{feature} transaction failed"
    kind = _failure_kind_from_storage(after.failure_kind)
    return False, "", str(error), kind, False


def _feature_due(name: str, now: float) -> bool:
    value = _SF_CLOCK.get(f"{name}_deadline")
    return bool(value is not None and float(now) >= float(value))


def _arm_timer_liveness_until_autosave() -> None:
    autosave_at = _SF_CLOCK.get("autosave_deadline")
    if autosave_at is not None:
        _SF_CLOCK["timer_liveness_until"] = float(autosave_at)


def _advance_feature(name: str, now: float, prefs=None) -> None:
    prefs = prefs or _prefs()
    interval = _autosave_interval(prefs) if name == "autosave" else _restore_interval(prefs)
    _SF_CLOCK[f"last_{name}_monotonic"] = float(now)
    _SF_CLOCK[f"{name}_deadline"] = float(now) + interval
    if name == "autosave":
        _SF_CLOCK["timer_liveness_until"] = None
        _RUNTIME["last_autosave_time"] = float(now)
    else:
        _RUNTIME["last_restore_snapshot_time"] = float(now)


def _clear_deferred_file_open_restore() -> None:
    _SF_CLOCK["file_open_restore_pending_since"] = None
    _SF_CLOCK["file_open_restore_pending_identity"] = None
    _SF_CLOCK["file_open_restore_retry_at"] = None
    _SF_CLOCK["file_open_restore_failures"] = 0.0
    _RUNTIME["file_open_restore_last_error"] = ""


def _queue_deferred_file_open_restore(now: float, current: ChangeSnapshot) -> None:
    _SF_CLOCK["file_open_restore_pending_since"] = float(now)
    _SF_CLOCK["file_open_restore_pending_identity"] = str(
        current.file_identity or _file_identity()
    )
    _SF_CLOCK["file_open_restore_retry_at"] = None
    _SF_CLOCK["file_open_restore_failures"] = 0.0
    _RUNTIME["file_open_restore_last_error"] = ""


def _record_deferred_file_open_restore_failure(now: float, error: str) -> None:
    """Retain optional restore work without poisoning the autosave checkpoint."""
    failures = max(0, int(_SF_CLOCK.get("file_open_restore_failures") or 0)) + 1
    delays = (5.0, 15.0, 30.0, 60.0, 300.0, 900.0)
    delay = delays[min(failures - 1, len(delays) - 1)]
    _SF_CLOCK["file_open_restore_failures"] = float(failures)
    _SF_CLOCK["file_open_restore_retry_at"] = float(now) + float(delay)
    _RUNTIME["file_open_restore_last_error"] = str(
        error or "file-open restore copy failed"
    )


def _finish_load_restore(
    now: float, context=None, *, defer_restore: bool = False
) -> bool:
    """Synchronously baseline the loaded file without touching the native timer."""
    if not _SF_STATE.load_restore_pending:
        _SF_CLOCK["load_finalize_at"] = None
        return True
    current = _snapshot(context)
    loaded_dirty = bool(current.data_is_dirty)
    _SF_STATE.finish_load_restore(current, now)
    _SF_CLOCK["load_finalize_at"] = None
    prefs = _prefs(context)
    wants_restore = bool(
        _restore_enabled(prefs) and not is_managed_snapshot_file(context)
    )
    if wants_restore:
        # Blender can report a timer as registered from load_post while never
        # dispatching it. Baseline now, retain the exact incumbent callback, and
        # let that callback create the optional restore copy at an ordinary wake.
        _queue_deferred_file_open_restore(now, current)
    else:
        _clear_deferred_file_open_restore()
    if loaded_dirty:
        # Other load_post handlers may edit before this callback. A dirty loaded
        # snapshot is evidence, not a baseline to clean away; retain exactly one
        # autosave epoch even if no later depsgraph callback arrives.
        _SF_STATE.active_dirty_pending = True
        _SF_STATE.dirty_pending = True
    _persist_state()
    return True


def _process_deferred_file_open_restore(now: float, context=None, prefs=None) -> bool:
    """Attempt the optional load restore independently of mandatory autosave."""
    if _SF_CLOCK.get("file_open_restore_pending_since") is None:
        return True
    pending_identity = str(
        _SF_CLOCK.get("file_open_restore_pending_identity") or ""
    )
    current_identity = str(_file_identity() or "")
    if not pending_identity or current_identity != pending_identity:
        # Save As/file switch establishes a different source. Never write an old
        # load event into the new project's history namespace.
        _clear_deferred_file_open_restore()
        _persist_state()
        return True
    prefs = prefs or _prefs(context)
    if not _restore_enabled(prefs) or is_managed_snapshot_file(context):
        _clear_deferred_file_open_restore()
        _persist_state()
        return True
    retry_at = _SF_CLOCK.get("file_open_restore_retry_at")
    if retry_at is not None and float(now) < float(retry_at):
        return True
    kind, reason, _condition = _blocker(context)
    if kind is not FailureKind.NONE:
        _record_deferred_file_open_restore_failure(now, reason)
        _persist_state()
        return False
    ok, _filepath, error, _failure_kind, _history_ack_ok = _attempt_history_save(
        "restore", "file opened", context
    )
    if not ok:
        _record_deferred_file_open_restore_failure(now, error)
        _persist_state()
        return False
    _advance_feature("restore", now, prefs)
    _clear_deferred_file_open_restore()
    _persist_state()
    return True


def _deadline_tick() -> Optional[float]:
    global _SF_REGISTERED
    if not _is_current_generation() or not _SF_LEDGER_INSTALLED:
        return None
    prefs = _prefs()
    if prefs is None:
        if not _runtime_gap_recovery_allowed():
            return None
        now = time.monotonic()
        _SF_REGISTERED = False
        _SF_STATE.record_retry(
            now=now,
            kind=FailureKind.SETTINGS_OWNER,
            reason="canonical Smart File preferences are temporarily unavailable",
            next_condition="canonical preferences owner recovery",
            blocker_signature="runtime_owner:preferences_unavailable",
        )
        _persist_state()
        return _SF_STATE.next_deadline
    if not _runtime_requested(prefs):
        return None
    now = time.monotonic()

    if not _lifecycle_owner_ok() or not _settings_owner_ok():
        _SF_REGISTERED = False
        missing = "lifecycle owner" if not _lifecycle_owner_ok() else "settings owner/subscriptions"
        _SF_STATE.record_retry(
            now=now,
            kind=FailureKind.REGISTRATION if "lifecycle" in missing else FailureKind.SETTINGS_OWNER,
            reason=f"History {missing} validation failed",
            next_condition=f"{missing} repair or manual refresh",
            blocker_signature=f"runtime_owner:{missing}",
        )
        _persist_state()
        return _SF_STATE.next_deadline

    if not _handlers_ok():
        if not _register_handlers():
            _SF_REGISTERED = False
            _SF_STATE.record_retry(
                now=now,
                kind=FailureKind.HANDLER,
                reason=_SF_STATE.last_runtime_error or "History handler self-repair failed",
                next_condition="handler registry availability or manual refresh",
                blocker_signature="handler_self_repair",
            )
            _persist_state()
            return _SF_STATE.next_deadline

    _SF_REGISTERED = bool(
        _handlers_ok()
        and _timer_is_registered()
        and _settings_owner_ok()
        and _lifecycle_owner_ok()
        and _atexit_identity_ok()
        and _is_current_generation()
    )
    if not _SF_REGISTERED:
        _SF_STATE.record_retry(
            now=now,
            kind=FailureKind.REGISTRATION,
            reason="runtime exact-identity validation failed during deadline processing",
            next_condition="single-owner repair synchronization",
            blocker_signature="deadline_exact_identity",
        )
        _persist_state()
        return _SF_STATE.next_deadline

    kind, reason, condition = _blocker(getattr(bpy, "context", None))
    global _SF_LAST_BLOCKER_SIGNATURE
    signature = _blocker_signature(kind, reason)
    _SF_LAST_BLOCKER_SIGNATURE = signature
    retry_due = bool(
        _SF_STATE.phase is RuntimePhase.RETRYING
        and _SF_STATE.next_deadline is not None
        and now >= float(_SF_STATE.next_deadline)
    )
    due_any = _feature_due("autosave", now) or _feature_due("restore", now) or retry_due
    if due_any and kind is not FailureKind.NONE:
        _SF_STATE.record_retry(
            now=now,
            kind=kind,
            reason=reason,
            next_condition=condition,
            blocker_signature=signature,
        )
        _RUNTIME["last_runtime_error"] = reason
        _persist_state()
        return _SF_STATE.next_deadline

    current = _snapshot(getattr(bpy, "context", None))
    _SF_STATE.note_dirty_probe(current)

    # A bounded retry deadline is authoritative even when it precedes the next
    # regular feature deadline. This is the one catch-up transaction after a
    # blocker/save failure; it never becomes sub-second polling.
    if retry_due:
        pending = bool(
            _SF_STATE.boundary_save_pending
            or _SF_STATE.has_unsaved_change(current)
        )
        if pending and _autosave_enabled(prefs):
            ok, filepath, error, failure_kind, history_ack_ok = _attempt_history_save(
                "autosave", "retry catch-up", getattr(bpy, "context", None)
            )
            if not ok:
                _SF_STATE.record_save_failure(now=now, error=error, kind=failure_kind)
                _RUNTIME["last_save_error"] = error
                _persist_state()
                return _SF_STATE.next_deadline
            history_ack_ok = _normalize_history_ack(history_ack_ok)
            if _history_ack_aborted(history_ack_ok):
                wake_at = _SF_STATE.next_deadline or _regular_wake_at(now, prefs)
                _SF_CLOCK["timer_wake_at"] = wake_at
                _persist_state()
                return wake_at
            after_snapshot = _snapshot(getattr(bpy, "context", None))
            if _SF_STATE.pending_boundary_applies_to(after_snapshot):
                _SF_STATE.record_boundary_success(
                    now=now, current=after_snapshot, filepath=filepath
                )
            else:
                _SF_STATE.record_save_success(
                    now=now, current=after_snapshot, filepath=filepath
                )
            if not history_ack_ok:
                mark_change_pending(
                    getattr(bpy, "context", None), source="history_ack_fail_open_after_save"
                )
            _advance_feature("autosave", now, prefs)
            _RUNTIME["last_autosave_change_counter"] = int(
                _RUNTIME.get("change_counter", 0) or 0
            )
            current = after_snapshot
        elif not pending and _SF_STATE.failure_kind in {
            FailureKind.SAVE_IN_PROGRESS, FailureKind.INTERFACE_LOCK,
            FailureKind.RENDER, FailureKind.PLAYBACK,
            FailureKind.MODAL, FailureKind.CONTEXT, FailureKind.REGISTRATION,
            FailureKind.TIMER, FailureKind.HANDLER, FailureKind.SETTINGS_OWNER,
            FailureKind.STORAGE_PATH, FailureKind.SAVE_CANCELLED,
            FailureKind.SAVE_EXCEPTION, FailureKind.OUTPUT_MISSING,
            FailureKind.OUTPUT_EMPTY, FailureKind.OUTPUT_STALE,
            FailureKind.OUTPUT_CORRUPT,
        }:
            _SF_STATE.last_runtime_error = ""
            _SF_STATE.last_save_error = ""
            _SF_STATE.set_active()
            _SF_STATE.advance_regular_deadline(now)

    # Mandatory autosave is always evaluated before either periodic or file-open
    # restore work. An optional restore path failure must never hold a dirty
    # checkpoint hostage when the autosave destination itself remains writable.
    if _feature_due("autosave", now):
        if _skip_unchanged(prefs) and not _SF_STATE.has_unsaved_change(current):
            _advance_feature("autosave", now, prefs)
        else:
            ok, filepath, error, failure_kind, history_ack_ok = _attempt_history_save(
                "autosave", "deadline", getattr(bpy, "context", None)
            )
            if not ok:
                _SF_STATE.record_save_failure(now=now, error=error, kind=failure_kind)
                _RUNTIME["last_save_error"] = error
                _persist_state()
                return _SF_STATE.next_deadline
            history_ack_ok = _normalize_history_ack(history_ack_ok)
            if _history_ack_aborted(history_ack_ok):
                wake_at = _SF_STATE.next_deadline or _regular_wake_at(now, prefs)
                _SF_CLOCK["timer_wake_at"] = wake_at
                _persist_state()
                return wake_at
            _advance_feature("autosave", now, prefs)
            after_snapshot = _snapshot(getattr(bpy, "context", None))
            if _SF_STATE.pending_boundary_applies_to(after_snapshot):
                _SF_STATE.record_boundary_success(
                    now=now, current=after_snapshot, filepath=filepath
                )
            else:
                _SF_STATE.record_save_success(
                    now=now, current=after_snapshot, filepath=filepath
                )
            if not history_ack_ok:
                mark_change_pending(
                    getattr(bpy, "context", None), source="history_ack_fail_open_after_save"
                )
            _RUNTIME["last_autosave_change_counter"] = int(
                _RUNTIME.get("change_counter", 0) or 0
            )

    had_deferred_file_open_restore = bool(
        _SF_CLOCK.get("file_open_restore_pending_since") is not None
    )
    _process_deferred_file_open_restore(
        now, getattr(bpy, "context", None), prefs
    )

    if not had_deferred_file_open_restore and _feature_due("restore", now):
        current = _snapshot(getattr(bpy, "context", None))
        _SF_STATE.note_dirty_probe(current)
        if _SF_STATE.has_unsaved_change(current):
            ok, filepath, error, failure_kind, _history_ack_ok = _attempt_history_save(
                "restore", "deadline", getattr(bpy, "context", None)
            )
            if not ok:
                _SF_STATE.record_save_failure(now=now, error=error, kind=failure_kind)
                _RUNTIME["last_save_error"] = error
                _persist_state()
                return _SF_STATE.next_deadline
            _advance_feature("restore", now, prefs)
        else:
            _advance_feature("restore", now, prefs)

    if _SF_STATE.phase is not RuntimePhase.RETRYING:
        _SF_STATE.set_active()
    wake_at = _regular_wake_at(now, prefs)
    if _SF_STATE.phase is not RuntimePhase.RETRYING:
        # ``next_deadline`` is part of the public runtime diagnosis. Keep it
        # coherent with the feature clock after a clean Skip-Unchanged tick as
        # well as after a verified save; a stale past state deadline must never
        # make a live sleeping scheduler look stopped.
        _SF_STATE.next_deadline = wake_at
    _SF_CLOCK["timer_wake_at"] = wake_at
    _RUNTIME["last_runtime_error"] = _SF_STATE.last_runtime_error
    _RUNTIME["last_save_error"] = _SF_STATE.last_save_error
    _persist_state()
    return wake_at


def _mark_boundary_ack_dirty_fail_open(context=None) -> bool:
    """Retain an ambiguous boundary epoch even through an exact owner gap."""
    if mark_change_pending(
        context, source="history_ack_fail_open_after_boundary"
    ):
        return True
    # The only supported generation-missing caller is an exact surviving
    # load_pre/exit_pre handler proven by _recoverable_post_load_handler_gap.
    # Its verified copy may have cleaned the checkpoint immediately before an
    # ambiguous History callback. Never let the generic generation event gate
    # erase that fail-open evidence.
    _SF_STATE.mark_event(time.monotonic())
    _RUNTIME["change_counter"] = int(
        _RUNTIME.get("change_counter", 0) or 0
    ) + 1
    return True


def _boundary_save(reason: str, context=None) -> bool:
    """One synchronous boundary transaction; never loops or clears on failure."""
    global _SF_LAST_BOUNDARY_RESULT
    now = time.monotonic()
    current = _snapshot(context)
    # A verified copy-save intentionally leaves ``bpy.data.is_dirty`` true.
    # Treating that raw level as a fresh boundary epoch creates an unedited extra
    # autosave on load/OFF/unregister.  The state machine already records the
    # clean->dirty edge plus every depsgraph/undo/redo event and bounded external
    # counter, so only transactional change evidence (or a retained failed
    # boundary) may start a boundary write.
    _SF_STATE.note_dirty_probe(current)
    if not (_SF_STATE.has_unsaved_change(current) or _SF_STATE.boundary_save_pending):
        _SF_LAST_BOUNDARY_RESULT = {
            "reason": str(reason),
            "attempted": False,
            "success": True,
            "detail": "no pending change",
        }
        _persist_state()
        return True
    kind, blocker_reason, condition = _blocker(context)
    if kind is not FailureKind.NONE:
        error = f"boundary save deferred: {blocker_reason}"
        _SF_STATE.record_boundary_failure(
            reason=reason, error=error, now=now, current=current, kind=kind
        )
        _SF_LAST_BOUNDARY_RESULT = {
            "reason": str(reason),
            "attempted": True,
            "success": False,
            "error": error,
            "next_condition": condition,
        }
        _persist_state()
        return False
    ok, filepath, error, failure_kind, history_ack_ok = _attempt_history_save(
        "autosave", f"boundary:{reason}", context
    )
    if not ok:
        _SF_STATE.record_boundary_failure(
            reason=reason,
            error=error,
            now=now,
            current=current,
            kind=failure_kind,
        )
        _SF_LAST_BOUNDARY_RESULT = {
            "reason": str(reason),
            "attempted": True,
            "success": False,
            "error": error,
            "failure_kind": failure_kind.value,
        }
        _persist_state()
        return False
    history_ack_ok = _normalize_history_ack(history_ack_ok)
    if _history_ack_aborted(history_ack_ok):
        _SF_LAST_BOUNDARY_RESULT = {
            "reason": str(reason),
            "attempted": True,
            "success": True,
            "aborted_world_changed": True,
        }
        _persist_state()
        return True
    after = _snapshot(context)
    cleared = _SF_STATE.record_boundary_success(
        now=now, current=after, filepath=filepath
    )
    if not history_ack_ok:
        _mark_boundary_ack_dirty_fail_open(context)
    _advance_feature("autosave", now, _prefs(context))
    _SF_LAST_BOUNDARY_RESULT = {
        "reason": str(reason),
        "attempted": True,
        "success": bool(cleared),
        "filepath": filepath,
        "orphaned_failure_retained": not bool(cleared),
    }
    _persist_state()
    return bool(cleared)


@contextmanager
def _defer_lifecycle_repair_during_gap_boundary(enabled: bool):
    """Keep exact post-load gap boundaries free of native timer mutation."""
    global _SF_LOAD_POST_DEPTH
    if not enabled:
        yield
        return
    _SF_LOAD_POST_DEPTH += 1
    try:
        yield
    finally:
        _SF_LOAD_POST_DEPTH = max(0, int(_SF_LOAD_POST_DEPTH) - 1)


@persistent
def _on_load_pre(_dummy=None):
    _clear_owned_history_ack()
    generation_current = _is_current_generation()
    recoverable_gap = bool(
        not generation_current
        and _recoverable_post_load_handler_gap("load_pre", _on_load_pre)
    )
    if not generation_current and not recoverable_gap:
        return
    with _defer_lifecycle_repair_during_gap_boundary(recoverable_gap):
        try:
            _SF_BOUNDARY_ATTEMPTS.add("file_switch")
            _boundary_save("file_switch", getattr(bpy, "context", None))
        except Exception as exc:
            current = _safe_snapshot(getattr(bpy, "context", None))
            _SF_STATE.record_boundary_failure(
                reason="file_switch",
                error=_error_text(exc),
                now=time.monotonic(),
                current=current,
            )
            _persist_state()
        try:
            _prepare_timer_for_file_load(time.monotonic())
        except Exception as exc:
            _SF_STATE.record_retry(
                now=time.monotonic(),
                kind=FailureKind.TIMER,
                reason=f"load_pre timer liveness preparation failed: {_error_text(exc)}",
                next_condition="post-load lifecycle repair or timer registry recovery",
                blocker_signature="load_pre_timer_liveness",
            )
            _persist_state()


@persistent
def _on_load_post(_dummy=None):
    global _SF_LOAD_POST_DEPTH, _SF_LOAD_POST_REPAIR_PENDING
    _SF_LOAD_POST_DEPTH += 1
    try:
        _clear_owned_history_ack(reset_revision=True)
        if not _is_current_generation():
            _SF_LOAD_POST_REPAIR_PENDING = True
            _SF_STATE.record_retry(
                now=time.monotonic(),
                kind=FailureKind.REGISTRATION,
                reason='load_post deferred missing generation owner repair',
                next_condition='post-load lifecycle repair',
                blocker_signature='load_post_owner_recovery',
            )
            _persist_state()
            _reattach_load_survivor_ledger()
        now = time.monotonic()
        current = _snapshot(getattr(bpy, "context", None))
        _SF_STATE.on_file_loaded(current, now)
        _SF_STATE.begin_load_restore(current)
        if not _finish_load_restore(
            now, getattr(bpy, "context", None), defer_restore=True
        ):
            raise RuntimeError("load baseline finalization returned false")
        _SF_BOUNDARY_ATTEMPTS.discard("file_switch")
        _persist_state()
        synchronized = sync_listener_runtime(
            getattr(bpy, "context", None), reason="load_post", preserve_state=True
        )
        if not synchronized:
            _SF_LOAD_POST_REPAIR_PENDING = True
        else:
            _SF_LOAD_POST_REPAIR_PENDING = False
    except Exception as exc:
        _SF_STATE.record_retry(
            now=time.monotonic(),
            kind=FailureKind.CONTEXT,
            reason=f"load_post runtime synchronization failed: {_error_text(exc)}",
            next_condition="load context availability or manual refresh",
            blocker_signature="load_post_failure",
        )
        _persist_state()
        _SF_LOAD_POST_REPAIR_PENDING = True
    finally:
        _SF_LOAD_POST_DEPTH = max(0, int(_SF_LOAD_POST_DEPTH) - 1)
        if _SF_LOAD_POST_DEPTH == 0:
            try:
                if _modal_scheduler_requested(_prefs()):
                    now = time.monotonic()
                    _ensure_modal_scheduler(
                        None,
                        wake_at=_modal_scheduler_wake_at(now, _prefs()),
                        kind=_SF_TIMER_KIND or "load_post_watchdog",
                    )
            except Exception:
                pass


def _recoverable_post_load_handler_gap(name: str, callback) -> bool:
    """Prove this exact handler survived only a transient namespace gap."""
    if not (
        _SF_LOAD_POST_REPAIR_PENDING
        and _SF_LOAD_POST_DEPTH == 0
        and _SF_LEDGER_INSTALLED
        and _ledger() is None
    ):
        return False
    handler_list = _handler_lists().get(str(name or ""))
    records = tuple(
        record
        for record in _SF_HANDLER_RECORDS
        if str(record.get("name") or "") == str(name or "")
        and record.get("callback") is callback
    )
    if len(records) != 1 or handler_list is None:
        return False
    record = records[0]
    if not (
        record.get("handler_list") is handler_list
        and record.get("token") is _SF_RUNTIME_TOKEN
        and record.get("generation") == _SF_RUNTIME_GENERATION
    ):
        return False
    try:
        return sum(1 for item in handler_list if item is callback) == 1
    except Exception:
        return False


@persistent
def _on_save_post(_dummy=None):
    global _SF_LOAD_POST_REPAIR_PENDING, _SF_SAVE_POST_REPAIR_PENDING
    if _SF_SAVE_DEPTH > 0:
        return
    generation_current = _is_current_generation()
    recoverable_gap = bool(
        not generation_current
        and _recoverable_post_load_handler_gap("save_post", _on_save_post)
    )
    if not generation_current and not recoverable_gap:
        return
    try:
        current = _snapshot(getattr(bpy, "context", None))
        # A successful user save/save-as is already the stronger checkpoint for
        # the load event. Cancel its optional deferred copy so the old file event
        # can never be written under the new project's history namespace.
        _clear_deferred_file_open_restore()
        orphan_pending = bool(
            _SF_STATE.boundary_save_pending
            and _SF_STATE.boundary_failure is not None
            and _SF_STATE.boundary_failure.orphaned_by_file_switch
        )
        if _SF_STATE.pending_boundary_applies_to(current):
            _SF_STATE.boundary_save_pending = False
            _SF_STATE.boundary_failure = None
            _SF_STATE.last_boundary_attempt_error = ""
            _SF_STATE.last_save_error = ""
            _SF_STATE.last_runtime_error = ""
        _SF_STATE.active_saved_snapshot = current
        _SF_STATE.active_dirty_pending = False
        if not orphan_pending:
            _SF_STATE.saved_snapshot = current
            _SF_STATE.dirty_pending = False
        else:
            _SF_STATE.dirty_pending = True
        st = scene_settings(getattr(bpy, "context", None))
        filepath = str(getattr(getattr(bpy, "data", None), "filepath", "") or "")
        if st is not None and filepath:
            real_project = os.path.splitext(os.path.basename(filepath))[0]
            if real_project and str(getattr(st, "project_key", "") or "") in {"", "Unsaved_Project"}:
                with _internal_mutation():
                    st.project_key = real_project
        if not orphan_pending and not _SF_STATE.last_save_error:
            _SF_STATE.set_active()
        # A normal verified Blender save is a clean checkpoint, but Blender can
        # invalidate an already-registered Python timer across save_mainfile
        # while still reporting it as registered.  Do not mutate Blender's
        # native timer queue from inside save_post; defer the exact successor
        # refresh to the next non-save dependency-graph event.
        if generation_current and _runtime_requested(_prefs()):
            _SF_SAVE_POST_REPAIR_PENDING = True
            _arm_timer_liveness_until_autosave()
        elif recoverable_gap:
            _SF_LOAD_POST_REPAIR_PENDING = True
        _persist_state()
    except Exception as exc:
        _SF_STATE.last_runtime_error = f"save_post checkpoint failed: {_error_text(exc)}"
        _persist_state()

@persistent
def _on_undo_post(_dummy=None):
    if _runtime_events_active():
        mark_change_pending(getattr(bpy, "context", None), source="undo")


@persistent
def _on_redo_post(_dummy=None):
    if _runtime_events_active():
        mark_change_pending(getattr(bpy, "context", None), source="redo")


def _depsgraph_channel_key(args) -> tuple[int, str]:
    try:
        context = getattr(bpy, "context", None)
        context_scene = getattr(context, "scene", None)
        depsgraph = args[-1] if args and hasattr(args[-1], "updates") else None
        handler_scene = args[0] if len(args) > 1 else context_scene
        identity = _plain_scene_identity(handler_scene or context_scene)
        view_layer = getattr(depsgraph, "view_layer", None) or getattr(
            context, "view_layer", None
        )
        layer_name = str(getattr(view_layer, "name", "") or "")
        if not identity or not layer_name:
            return ()
        return (int(identity[0]), layer_name)
    except Exception:
        return ()


def _depsgraph_update_is_scene_only(args, record=None) -> bool:
    """Match one owned History echo only inside its synchronous flush."""
    try:
        if not isinstance(record, Mapping):
            return False
        if _SF_INTERNAL_SCENE_ACK_FLUSH_DEPTH <= 0:
            return False
        if str(record.get("generation") or "") != str(_SF_RUNTIME_GENERATION):
            return False
        if int(record.get("ack_epoch", -1)) != int(_SF_INTERNAL_SCENE_ACK_EPOCH):
            return False
        if int(record.get("history_revision", -1)) != int(_SF_INTERNAL_HISTORY_REVISION):
            return False
        if tuple(record.get("channel_key") or ()) != _depsgraph_channel_key(args):
            return False
        now = time.monotonic()
        if now < float(record.get("armed_at", now)) or now > float(record.get("expires_at", 0.0)):
            return False
        context_scene = getattr(getattr(bpy, "context", None), "scene", None)
        depsgraph = args[-1] if args and hasattr(args[-1], "updates") else None
        handler_scene = args[0] if len(args) > 1 else context_scene
        updates = tuple(getattr(depsgraph, "updates", ()) or ())
        if not updates:
            return False
        scene = handler_scene or context_scene
        if scene is None:
            return False
        scene_identity = _plain_scene_identity(scene)
        if not scene_identity or tuple(scene_identity) != tuple(record.get("scene_identity") or ()):
            return False
        if _history_entry_fingerprint(scene) != tuple(record.get("history_fingerprint") or ()):
            return False
        if _scene_edit_guard_fingerprint(scene) != tuple(record.get("scene_edit_guard") or ()):
            return False
        if str(_file_identity()) != str(record.get("file_identity") or ""):
            return False
        for update in updates:
            identifier = getattr(update, "id", None)
            original = getattr(identifier, "original", identifier)
            identities = (
                _plain_scene_identity(identifier),
                _plain_scene_identity(original),
            )
            if tuple(scene_identity) not in identities:
                return False
        # Blender 5.1 reports the add-on-owned Scene collection write with
        # geometry/transform flags set.  Those flags are ignored only inside
        # this same-stack bracket, after every identity/fingerprint guard above.
        return True
    except Exception:
        return False


@persistent
def _on_depsgraph_update_post(*_args):
    global _SF_INTERNAL_SCENE_UPDATE_ACKS, _SF_INTERNAL_SCENE_ACK_FLUSH_DIRTY
    global _SF_INTERNAL_SCENE_ACK_CALLBACK_COUNT
    global _SF_SAVE_POST_REPAIR_PENDING
    if _SF_LOAD_POST_REPAIR_PENDING and _SF_LOAD_POST_DEPTH == 0:
        _request_lifecycle_repair("deferred post-load lifecycle repair")
    if _SF_SAVE_POST_REPAIR_PENDING and _SF_LOAD_POST_DEPTH == 0 and _SF_SAVE_DEPTH == 0:
        prefs = _prefs()
        if _runtime_requested(prefs):
            if _refresh_timer_after_external_save(time.monotonic(), prefs):
                _SF_SAVE_POST_REPAIR_PENDING = False
        else:
            _SF_SAVE_POST_REPAIR_PENDING = False
    if (
        _SF_LOAD_POST_DEPTH == 0
        and _SF_SAVE_DEPTH == 0
        and not _SF_MODAL_STARTING
        and not _modal_scheduler_is_active()
        and _modal_scheduler_requested(_prefs())
    ):
        try:
            now = time.monotonic()
            _ensure_modal_scheduler(
                None,
                wake_at=_modal_scheduler_wake_at(now, _prefs()),
                kind=_SF_TIMER_KIND or "event_watchdog",
            )
        except Exception:
            pass
    # This handler can be called for every dependency-graph update.  OFF and
    # stale-generation paths return before reading context or calculating a
    # snapshot.  A clean depsgraph event is not a reason to wake/reschedule.
    owned_flush = _SF_INTERNAL_SCENE_ACK_FLUSH_DEPTH > 0
    if owned_flush:
        # Count before every early return.  A supposedly no-callback channel is
        # clean only when no process-global dirty source was observed at all.
        _SF_INTERNAL_SCENE_ACK_CALLBACK_COUNT += 1
    # A feature-OFF transition can perform one synchronous boundary copy before
    # removing its resources.  At that point the user request is already OFF,
    # but the exact owned History callback still has to be classified so the
    # verified boundary checkpoint is not re-armed dirty.  Only the same-stack
    # owned transaction bypasses the generic active gate; its record classifier
    # still fails open for mixed, foreign, expired or mismatched callbacks.
    if (not owned_flush and not _runtime_events_active()) or _internal_change_active():
        return
    # During the synchronous owned History flush, Blender can report the exact
    # Scene collection callback after the verified copy has already left
    # ``bpy.data.is_dirty`` false.  Classify that callback against the sealed
    # owned record before applying the generic idle fast-path; otherwise it is
    # counted but discarded and the successful checkpoint is re-armed dirty.
    # Outside this narrow transaction, clean depsgraph callbacks remain free.
    if not owned_flush and not _data_is_dirty():
        return
    channel_key = _depsgraph_channel_key(_args)
    record = _SF_INTERNAL_SCENE_UPDATE_ACKS.pop(channel_key, None)
    if record is not None:
        # Pop before all validation.  Exceptions and mismatches cannot leave an
        # armed record that swallows the next genuine Scene-only edit.
        try:
            record["callback_seen"] = True
            record["retired"] = True
            matched = bool(_depsgraph_update_is_scene_only(_args, record))
            record["matched"] = matched
        except Exception:
            matched = False
        if matched:
            _RUNTIME["internal_depsgraph_suppressed"] = int(
                _RUNTIME.get("internal_depsgraph_suppressed", 0) or 0
            ) + 1
            record["handler_completed"] = True
            return
        if _SF_INTERNAL_SCENE_ACK_FLUSH_DEPTH > 0:
            _SF_INTERNAL_SCENE_ACK_FLUSH_DIRTY = True
    elif _SF_INTERNAL_SCENE_ACK_FLUSH_DEPTH > 0:
        # A second callback in one flush is not owned by the exact-one record.
        _SF_INTERNAL_SCENE_ACK_FLUSH_DIRTY = True
    mark_change_pending(getattr(bpy, "context", None), source="depsgraph")


@persistent
def _on_render_state_change(*_args):
    if _runtime_events_active():
        notify_runtime_state_change(getattr(bpy, "context", None), "render state changed")


@persistent
def _on_playback_state_change(*_args):
    if _runtime_events_active():
        notify_runtime_state_change(getattr(bpy, "context", None), "playback state changed")


@persistent
def _on_exit_pre(_dummy=None):
    generation_current = _is_current_generation()
    recoverable_gap = bool(
        not generation_current
        and _recoverable_post_load_handler_gap("exit_pre", _on_exit_pre)
    )
    if (
        (not generation_current and not recoverable_gap)
        or "quit" in _SF_BOUNDARY_ATTEMPTS
    ):
        return
    _SF_BOUNDARY_ATTEMPTS.add("quit")
    with _defer_lifecycle_repair_during_gap_boundary(recoverable_gap):
        try:
            _boundary_save("quit", getattr(bpy, "context", None))
        except Exception as exc:
            _SF_STATE.record_boundary_failure(
                reason="quit",
                error=_error_text(exc),
                now=time.monotonic(),
                current=_safe_snapshot(getattr(bpy, "context", None)),
            )
            _persist_state()


def _atexit_boundary():
    if not _is_current_generation() or "quit" in _SF_BOUNDARY_ATTEMPTS:
        return
    _SF_BOUNDARY_ATTEMPTS.add("quit")
    try:
        _boundary_save("quit", getattr(bpy, "context", None))
    except Exception as exc:
        try:
            _SF_STATE.record_boundary_failure(
                reason="quit",
                error=_error_text(exc),
                now=time.monotonic(),
                current=_safe_snapshot(getattr(bpy, "context", None)),
            )
            _persist_state()
        except Exception:
            pass


def _register_atexit_boundary() -> bool:
    global _SF_ATEXIT_REGISTERED
    if _SF_ATEXIT_REGISTERED:
        return True
    try:
        atexit.register(_atexit_boundary)
        _SF_ATEXIT_REGISTERED = True
        ledger = _ledger()
        if isinstance(ledger, dict):
            ledger["atexit"] = {
                "callback": _atexit_boundary,
                "token": _SF_RUNTIME_TOKEN,
                "generation": _SF_RUNTIME_GENERATION,
                "remover": _unregister_atexit_boundary,
            }
        return True
    except Exception as exc:
        _SF_ATEXIT_REGISTERED = False
        _SF_STATE.last_runtime_error = f"atexit registration failed: {_error_text(exc)}"
        return False


def _unregister_atexit_boundary() -> bool:
    global _SF_ATEXIT_REGISTERED
    ok = True
    if _SF_ATEXIT_REGISTERED:
        try:
            atexit.unregister(_atexit_boundary)
        except Exception:
            ok = False
    _SF_ATEXIT_REGISTERED = False
    ledger = _ledger()
    if isinstance(ledger, dict):
        record = ledger.get("atexit")
        if not isinstance(record, Mapping) or record.get("callback") is _atexit_boundary:
            ledger["atexit"] = None
    return ok


def _atexit_identity_ok() -> bool:
    ledger = _ledger()
    record = ledger.get("atexit") if isinstance(ledger, Mapping) else None
    return bool(
        _SF_ATEXIT_REGISTERED
        and isinstance(record, Mapping)
        and record.get("callback") is _atexit_boundary
        and record.get("token") is _SF_RUNTIME_TOKEN
        and record.get("generation") == _SF_RUNTIME_GENERATION
    )


def _request_lifecycle_repair(reason: str) -> bool:
    """Ask the bound History owner to rebuild ledgers after a file load."""
    global _SF_LOAD_POST_REPAIR_PENDING
    if _SF_LOAD_POST_DEPTH > 0:
        # Lifecycle repair can reach register_runtime -> sync -> native timer
        # replacement. Blender 5.1 can report that replacement live while never
        # dispatching it when the call is nested in load_post. Defer the exact
        # same repair until the handler stack has unwound.
        _SF_LOAD_POST_REPAIR_PENDING = True
        return False
    try:
        import sys

        validator = _SF_LIFECYCLE_VALIDATOR
        owner_module = sys.modules.get(str(getattr(validator, '__module__', '') or ''))
        repair = getattr(owner_module, '_sf_history_request_repair', None)
        if callable(repair):
            repaired = bool(repair(str(reason or 'runtime lifecycle repair')))
            if repaired:
                _SF_LOAD_POST_REPAIR_PENDING = False
            return repaired
        package_name = str(__package__ or '').split('.history_auto_save', 1)[0]
        root = sys.modules.get(package_name)
        repair = getattr(root, '_sf_history_request_repair', None)
        repaired = bool(
            callable(repair) and repair(str(reason or 'runtime lifecycle repair'))
        )
        if repaired:
            _SF_LOAD_POST_REPAIR_PENDING = False
        return repaired
    except Exception:
        return False


def _remove_old_ledger(ledger: Mapping[str, Any]) -> bool:
    cleanup = ledger.get("cleanup") if isinstance(ledger, Mapping) else None
    if not callable(cleanup):
        return False
    try:
        return bool(cleanup(save_pending=False, reason="reload"))
    except TypeError:
        try:
            return bool(cleanup())
        except Exception:
            return False
    except Exception:
        return False


def _cleanup_generation(*, save_pending: bool = False, reason: str = "reload") -> bool:
    global _SF_LEDGER_INSTALLED, _SF_REGISTERED, _SF_ATEXIT_REGISTERED, _SF_AUTOSAVE_LATCHED
    global _SF_LOAD_POST_REPAIR_PENDING, _SF_SAVE_POST_REPAIR_PENDING
    ok = True
    if save_pending and (_SF_AUTOSAVE_LATCHED or _autosave_enabled(_prefs())):
        try:
            if not _boundary_save(reason, getattr(bpy, "context", None)):
                ok = False
        except Exception as exc:
            _SF_STATE.record_boundary_failure(
                reason=reason,
                error=_error_text(exc),
                now=time.monotonic(),
                current=_safe_snapshot(getattr(bpy, "context", None)),
            )
            ok = False
    if not _unregister_timer():
        ok = False
    if not _unregister_handlers():
        ok = False
    if not _unregister_atexit_boundary():
        ok = False
    _SF_STATE.deactivate(preserve_deadline=True)
    if str(reason or "reload") != "reload":
        _clear_deferred_file_open_restore()
        _SF_LOAD_POST_REPAIR_PENDING = False
        _SF_SAVE_POST_REPAIR_PENDING = False
    _SF_AUTOSAVE_LATCHED = False
    _clear_owned_history_ack(reset_revision=True)
    _SF_REGISTERED = False
    _SF_LEDGER_INSTALLED = False
    _persist_state()
    return ok


def _adopted_timer_liveness(callback) -> tuple[bool, bool]:
    """Return ``(alive_or_unknown, provisional)`` for ledger reconstruction."""
    if callback is None:
        return False, False
    if callback is _SF_TIMER_EXECUTING_CALLBACK:
        # Actual dispatch is stronger evidence than a transient registry readback.
        return True, False
    native_state = _native_timer_state(_timers_api(), callback)
    if native_state is False:
        return False, False
    # A driver_namespace/file-load gap must not erase ownership uncertainty.  An
    # unknown native readback remains a single provisional owner and can never be
    # promoted to ACTIVE until a positive readback or actual callback dispatch.
    return True, native_state is None


def _current_generation_ledger_record() -> dict[str, Any]:
    """Build one ledger from surviving Python owners without native mutation."""
    timer_record = None
    callback = _SF_TIMER_CALLBACK
    if callback is not None:
        timer_alive, timer_provisional = _adopted_timer_liveness(callback)
        if timer_alive:
            timer_record = {
                "callback": callback,
                "generation": _SF_RUNTIME_GENERATION,
                "token": _SF_RUNTIME_TOKEN,
                "wake_at": _SF_CLOCK.get("timer_wake_at"),
                "one_shot": False,
                "self_rescheduling": True,
                "persistent": True,
                "provisional": bool(timer_provisional),
                "remover": _unregister_timer,
            }
    atexit_record = None
    if _SF_ATEXIT_REGISTERED:
        atexit_record = {
            "callback": _atexit_boundary,
            "token": _SF_RUNTIME_TOKEN,
            "generation": _SF_RUNTIME_GENERATION,
            "remover": _unregister_atexit_boundary,
        }
    return {
        "schema": 2,
        "suite_version": _SF_VERSION,
        "token": _SF_RUNTIME_TOKEN,
        "generation": _SF_RUNTIME_GENERATION,
        "lifecycle_token": _SF_LIFECYCLE_TOKEN,
        "lifecycle_generation": _SF_LIFECYCLE_GENERATION,
        "handlers": tuple(_SF_HANDLER_RECORDS),
        "timer": timer_record,
        "atexit": atexit_record,
        "cleanup": _cleanup_generation,
    }


def _reattach_load_survivor_ledger() -> bool:
    """Restore only the missing current ledger during load_post.

    File loading can clear ``driver_namespace`` while the Python generation
    record is still authoritative enough to prove which callback is allowed to
    recover. This transaction never registers, unregisters, pulls or repairs a
    native resource; it only publishes the exact surviving owner record so
    normal structural validation can finish synchronously.
    """
    global _SF_LEDGER_INSTALLED
    namespace = _namespace()
    if namespace is None:
        return False
    previous = namespace.get(_SF_RUNTIME_LEDGER_KEY)
    if isinstance(previous, Mapping):
        return bool(
            previous.get("token") is _SF_RUNTIME_TOKEN
            and previous.get("generation") == _SF_RUNTIME_GENERATION
        )
    if previous is not None:
        return False
    namespace[_SF_RUNTIME_LEDGER_KEY] = _current_generation_ledger_record()
    _SF_LEDGER_INSTALLED = True
    return True


def _reattach_lifecycle_survivor_ledger() -> bool:
    """Ask the lifecycle owner to restore only its namespace ledger after load."""
    try:
        validator = _SF_LIFECYCLE_VALIDATOR
        owner_module = sys.modules.get(str(getattr(validator, "__module__", "") or ""))
        reattach = getattr(owner_module, "_sf_history_reattach_load_survivor_ledger", None)
        return bool(callable(reattach) and reattach())
    except Exception:
        return False


def register_runtime() -> bool:
    """Install the generation ledger, then validate exact operational state."""
    global _SF_LEDGER_INSTALLED, _SF_REGISTERED
    _adopt_persistent_state()
    if not _lifecycle_owner_ok():
        _SF_STATE.phase = RuntimePhase.ERROR
        _SF_STATE.last_runtime_error = "History lifecycle owner is not exact"
        _persist_state()
        return False
    namespace = _namespace()
    if namespace is None:
        _SF_STATE.phase = RuntimePhase.ERROR
        _SF_STATE.last_runtime_error = "bpy.app.driver_namespace is unavailable"
        return False
    # Remove exact resources from every known prior generation before the new
    # owner key is installed.  Old callbacks also self-terminate because their
    # token/generation cannot match the new ledger.
    for legacy_key in _SF_RUNTIME_LEGACY_LEDGER_KEYS:
        legacy = namespace.get(legacy_key)
        if legacy is None:
            continue
        if not _remove_old_ledger(legacy):
            _SF_STATE.phase = RuntimePhase.ERROR
            _SF_STATE.last_runtime_error = f"previous autosave generation cleanup failed: {legacy_key}"
            _persist_state()
            return False
        namespace.pop(legacy_key, None)

    previous = namespace.get(_SF_RUNTIME_LEDGER_KEY)
    if (
        _SF_LEDGER_INSTALLED
        and isinstance(previous, Mapping)
        and previous.get("token") is _SF_RUNTIME_TOKEN
        and previous.get("generation") == _SF_RUNTIME_GENERATION
    ):
        return sync_listener_runtime(reason="register", preserve_state=True)
    if isinstance(previous, Mapping) and previous.get("token") is not _SF_RUNTIME_TOKEN:
        if not _remove_old_ledger(previous):
            _SF_STATE.phase = RuntimePhase.ERROR
            _SF_STATE.last_runtime_error = "previous autosave generation cleanup failed"
            _persist_state()
            return False
    namespace[_SF_RUNTIME_LEDGER_KEY] = _current_generation_ledger_record()
    _SF_LEDGER_INSTALLED = True
    _SF_REGISTERED = False
    if _settings_apply_suspended():
        _SF_STATE.phase = RuntimePhase.RESTORING
        _SF_STATE.watching = False
        _SF_REGISTERED = False
        _persist_state()
        return False
    return sync_listener_runtime(reason="register", preserve_state=True)


def sync_listener_runtime(context=None, reason: str = "sync", *, preserve_state: bool = True) -> bool:
    """Repair exact resources; return structural registration, never UI optimism."""
    global _SF_AUTOSAVE_LATCHED, _SF_REGISTERED
    global _SF_LOAD_POST_REPAIR_PENDING
    load_post_sync = str(reason or "") == "load_post"
    load_handler_sync = bool(load_post_sync or _SF_LOAD_POST_DEPTH > 0)
    timer_kind = "load_post" if load_post_sync else "deadline"
    _adopt_persistent_state()
    if _SF_LEDGER_INSTALLED and not _is_current_generation():
        _reattach_load_survivor_ledger()
    if not _SF_LEDGER_INSTALLED or not _is_current_generation():
        _SF_REGISTERED = False
        _SF_STATE.phase = RuntimePhase.ERROR
        _SF_STATE.last_runtime_error = "runtime generation ledger is not installed"
        _persist_state()
        return False
    if not _lifecycle_owner_ok():
        _reattach_lifecycle_survivor_ledger()
    if not _lifecycle_owner_ok():
        _SF_STATE.record_retry(
            now=time.monotonic(),
            kind=FailureKind.REGISTRATION,
            reason="History lifecycle owner validation failed",
            next_condition="lifecycle owner repair",
            blocker_signature="lifecycle_owner",
        )
        _SF_REGISTERED = False
        if load_handler_sync:
            _SF_LOAD_POST_REPAIR_PENDING = True
        elif _runtime_recovery_requested(_prefs(context)):
            _schedule_timer(
                force=False,
                kind="lifecycle_owner_retry",
                allow_recovery=True,
                allow_earlier_pull=True,
            )
        else:
            _unregister_timer()
            _unregister_handlers()
            _unregister_atexit_boundary()
        _persist_state()
        return False
    if not _settings_owner_ok():
        status = _settings_owner_status()
        error = str(status.get("last_error") or "settings owner validation failed")
        _SF_STATE.record_retry(
            now=time.monotonic(),
            kind=FailureKind.SETTINGS_OWNER,
            reason=error,
            next_condition="settings owner/subscription repair",
            blocker_signature="settings_owner",
        )
        _SF_REGISTERED = False
        if load_handler_sync:
            _SF_LOAD_POST_REPAIR_PENDING = True
        elif _runtime_recovery_requested(_prefs(context)):
            _schedule_timer(
                force=False,
                kind="settings_owner_retry",
                allow_recovery=True,
                allow_earlier_pull=True,
            )
        else:
            _unregister_timer()
            _unregister_handlers()
            _unregister_atexit_boundary()
        _persist_state()
        return False
    prefs = _prefs(context)
    if prefs is None and _runtime_recovery_requested(None):
        _SF_STATE.record_retry(
            now=time.monotonic(),
            kind=FailureKind.SETTINGS_OWNER,
            reason="canonical autosave preferences are temporarily unavailable",
            next_condition="canonical preference owner availability",
            blocker_signature="preferences_unavailable",
        )
        _SF_REGISTERED = False
        if load_handler_sync:
            _SF_LOAD_POST_REPAIR_PENDING = True
        else:
            _schedule_timer(
                force=False,
                kind="preferences_owner_retry",
                allow_recovery=True,
                allow_earlier_pull=True,
            )
        _persist_state()
        return False
    requested = _runtime_requested(prefs)
    if not requested:
        if load_handler_sync:
            # A proven zero-resource OFF generation remains exact across file
            # load. Do not misclassify a verified manual disable as a failure.
            exact_disabled = bool(
                _is_current_generation()
                and _settings_owner_ok()
                and _lifecycle_owner_ok()
                and not _SF_HANDLER_RECORDS
                and not _timer_is_registered()
                and not _SF_ATEXIT_REGISTERED
            )
            if exact_disabled:
                _SF_AUTOSAVE_LATCHED = False
                _SF_LOAD_POST_REPAIR_PENDING = False
                _SF_STATE.deactivate(preserve_deadline=True)
                _SF_REGISTERED = True
                _persist_state()
                return True
            # A transient OFF observation with still-live resources must never
            # mutate Blender's native lists while load_post is dispatching them.
            _SF_REGISTERED = False
            _SF_LOAD_POST_REPAIR_PENDING = True
            _persist_state()
            return False
        boundary_ok = True
        if _SF_AUTOSAVE_LATCHED or _autosave_enabled(prefs):
            boundary_ok = _boundary_save("disable", context)
        _SF_AUTOSAVE_LATCHED = False
        _unregister_timer()
        _unregister_handlers()
        _unregister_atexit_boundary()
        _clear_deferred_file_open_restore()
        _SF_LOAD_POST_REPAIR_PENDING = False
        if boundary_ok:
            _SF_STATE.deactivate(preserve_deadline=True)
        else:
            _SF_STATE.enabled = False
            _SF_STATE.watching = False
            _SF_STATE.phase = RuntimePhase.RETRYING
        _SF_REGISTERED = bool(
            _is_current_generation()
            and _settings_owner_ok()
            and _lifecycle_owner_ok()
            and not _SF_HANDLER_RECORDS
            and not _timer_is_registered()
            and not _SF_ATEXIT_REGISTERED
        )
        _persist_state()
        return bool(_SF_REGISTERED)
    now = time.monotonic()
    autosave_schedule_changed = _synchronize_autosave_schedule(now, prefs)
    _ensure_feature_deadlines(now, prefs)
    intervals = []
    if _autosave_enabled(prefs):
        intervals.append(_autosave_interval(prefs))
    if _restore_enabled(prefs):
        intervals.append(_restore_interval(prefs))
    _SF_STATE.configure(interval_seconds=min(intervals or (300.0,)), health_seconds=900.0)
    post_load_owner_recovery = bool(
        _SF_LOAD_POST_REPAIR_PENDING
        and not _SF_STATE.boundary_save_pending
        and not _SF_STATE.last_save_error
        and _SF_STATE.failure_kind in {
            FailureKind.REGISTRATION,
            FailureKind.TIMER,
            FailureKind.HANDLER,
            FailureKind.SETTINGS_OWNER,
            FailureKind.CONTEXT,
            FailureKind.UNKNOWN,
        }
    )
    _SF_STATE.activate(now, _snapshot(context), preserve=preserve_state)
    if autosave_schedule_changed and _SF_STATE.phase is not RuntimePhase.RETRYING:
        regular_wake = _regular_wake_at(now, prefs)
        _SF_STATE.next_deadline = regular_wake
        _SF_CLOCK["timer_wake_at"] = regular_wake
    if post_load_owner_recovery:
        regular_wake = _regular_wake_at(now, prefs)
        if regular_wake is not None:
            # The owner gap is not a save failure. Preserve dirty evidence, but
            # restore the logical wake to the already-owned feature deadline.
            _SF_STATE.next_deadline = float(regular_wake)
    if load_handler_sync and not _atexit_identity_ok():
        _SF_REGISTERED = False
        _SF_LOAD_POST_REPAIR_PENDING = True
        _SF_STATE.record_retry(
            now=now,
            kind=FailureKind.REGISTRATION,
            reason="atexit repair deferred until load_post returns",
            next_condition="post-load lifecycle repair",
            blocker_signature="load_post_atexit_mutation_forbidden",
        )
        _persist_state()
        return False
    if not load_handler_sync and not _register_atexit_boundary():
        _SF_REGISTERED = False
        _SF_STATE.record_retry(
            now=now,
            kind=FailureKind.REGISTRATION,
            reason=_SF_STATE.last_runtime_error or "atexit boundary registration failed",
            next_condition="runtime repair synchronization",
            blocker_signature="atexit_registration",
        )
        _persist_state()
        return False
    # File loads clear driver_namespace but preserve @persistent callbacks. Once
    # their exact records are reattached, do not mutate Blender's handler list
    # while load_post is iterating it.
    if not _handlers_ok():
        if load_handler_sync:
            _SF_REGISTERED = False
            _SF_STATE.record_retry(
                now=now,
                kind=FailureKind.HANDLER,
                reason="handler repair deferred until load_post returns",
                next_condition="post-load lifecycle repair",
                blocker_signature="load_post_handler_mutation_forbidden",
            )
            _persist_state()
            return False
        if not _register_handlers():
            _SF_REGISTERED = False
            _unregister_timer()
            _unregister_atexit_boundary()
            _persist_state()
            return False
    timer_scheduled = _schedule_timer(
        force=True,
        kind=timer_kind,
        allow_earlier_pull=not load_post_sync,
    )
    if not timer_scheduled:
        _SF_REGISTERED = False
        _SF_STATE.watching = False
        provisional_ledger = _ledger()
        provisional_record = (
            provisional_ledger.get("timer")
            if isinstance(provisional_ledger, Mapping)
            else None
        )
        provisional_owner = bool(
            isinstance(provisional_record, Mapping)
            and provisional_record.get("callback") is _SF_TIMER_CALLBACK
            and provisional_record.get("provisional") is True
        )
        # An ambiguous register-after-raise owns at most one provisional callback.
        # Keep its handlers/atexit intact while the outer lifecycle owner performs
        # readback reconciliation; clearing it here could create an orphan and a
        # duplicate successor.
        if not provisional_owner and not load_handler_sync:
            _unregister_handlers()
            _unregister_atexit_boundary()
        _persist_state()
        return False
    structural = bool(
        _handlers_ok()
        and _timer_is_registered()
        and _settings_owner_ok()
        and _lifecycle_owner_ok()
        and _atexit_identity_ok()
        and _is_current_generation()
    )
    if not structural:
        _SF_REGISTERED = False
        _SF_STATE.record_retry(
            now=now,
            kind=FailureKind.REGISTRATION,
            reason="runtime exact-identity validation failed",
            next_condition="single-owner repair synchronization",
            blocker_signature="exact_identity",
        )
        if not load_handler_sync:
            _unregister_timer()
            _unregister_handlers()
            _unregister_atexit_boundary()
        _persist_state()
        return False
    _SF_REGISTERED = True
    _SF_AUTOSAVE_LATCHED = _autosave_enabled(prefs)
    active_ledger = _ledger()
    active_timer_record = (
        active_ledger.get("timer")
        if isinstance(active_ledger, Mapping)
        else None
    )
    timer_provisional = bool(
        isinstance(active_timer_record, Mapping)
        and active_timer_record.get("callback") is _SF_TIMER_CALLBACK
        and active_timer_record.get("provisional") is True
    )
    if (
        not timer_provisional
        and
        not _SF_STATE.boundary_save_pending
        and not _SF_STATE.last_save_error
        and _SF_STATE.failure_kind in {
            FailureKind.NONE, FailureKind.REGISTRATION, FailureKind.TIMER,
            FailureKind.HANDLER, FailureKind.SETTINGS_OWNER, FailureKind.UNKNOWN,
        }
    ):
        _SF_STATE.last_runtime_error = ""
        _SF_STATE.set_active()
    _persist_state()
    return bool(get_runtime_status(context).get("registered"))

def get_runtime_status(context=None) -> dict[str, Any]:
    """Return a read-only runtime snapshot suitable for Panel.draw."""
    requested = _runtime_requested(_prefs(context))
    settings_status = _settings_owner_status()
    generation_ok = _is_current_generation()
    handlers_ok = _handlers_ok() if requested else not bool(_SF_HANDLER_RECORDS)
    timer_ok = _timer_is_registered() if requested else not _timer_is_registered()
    settings_ok = bool(
        settings_status.get("registered")
        and settings_status.get("owner_ok")
        and settings_status.get("handlers_ok")
        and settings_status.get("subscriptions_ok")
        and settings_status.get("subscription_owner_exact")
    )
    lifecycle_ok = _lifecycle_owner_ok()
    atexit_ok = _atexit_identity_ok() if requested else not _SF_ATEXIT_REGISTERED
    structural_registered = bool(
        _SF_LEDGER_INSTALLED
        and _SF_REGISTERED
        and generation_ok
        and handlers_ok
        and timer_ok
        and settings_ok
        and lifecycle_ok
        and atexit_ok
    )
    # Status inspection is read-only.  A later explicit sync/repair operation
    # owns any transition of the private registration flag.
    result = _SF_STATE.status(
        generation_matches=generation_ok,
        handlers_ok=handlers_ok,
        timer_ok=timer_ok,
        settings_owner_ok=settings_ok,
        lifecycle_owner_ok=lifecycle_ok,
        registered=structural_registered,
        requested_enabled=requested,
    )
    result.update(
        {
            "owner_module": __name__,
            "suite_version": _SF_VERSION,
            "runtime_generation": _SF_RUNTIME_GENERATION,
            "lifecycle_generation": _SF_LIFECYCLE_GENERATION,
            "handler_count": len(_SF_HANDLER_RECORDS),
            "required_handler_count": len(_handler_specs()),
            "timer_registered": _timer_is_registered(),
            "timer_kind": _SF_TIMER_KIND,
            "timer_wake_at": _SF_CLOCK.get("timer_wake_at"),
            "app_timer_registered": (
                _native_timer_state(_timers_api(), _SF_TIMER_CALLBACK) is not False
                if _SF_TIMER_CALLBACK is not None else False
            ),
            "modal_scheduler_registered": _modal_scheduler_is_active(),
            "modal_scheduler_wake_at": _SF_MODAL_WAKE_AT,
            "modal_scheduler_kind": _SF_MODAL_KIND,
            "file_open_restore_pending_since": _SF_CLOCK.get(
                "file_open_restore_pending_since"
            ),
            "file_open_restore_pending_identity": _SF_CLOCK.get(
                "file_open_restore_pending_identity"
            ),
            "file_open_restore_retry_at": _SF_CLOCK.get(
                "file_open_restore_retry_at"
            ),
            "file_open_restore_failures": int(
                _SF_CLOCK.get("file_open_restore_failures") or 0
            ),
            "file_open_restore_last_error": str(
                _RUNTIME.get("file_open_restore_last_error") or ""
            ),
            "settings_status": settings_status,
            "last_boundary_result": dict(_SF_LAST_BOUNDARY_RESULT),
            "autosave_enabled": _autosave_enabled(_prefs(context)),
            "restore_enabled": _restore_enabled(_prefs(context)),
            "lifecycle_ok": lifecycle_ok,
            "structural_registered": structural_registered,
            "ledger_installed": bool(_SF_LEDGER_INSTALLED),
            "handler_identities_exact": bool(handlers_ok),
            "timer_identity_exact": bool(timer_ok),
            "atexit_registered": bool(_SF_ATEXIT_REGISTERED),
            "atexit_identity_exact": bool(atexit_ok),
            "timer_one_shot": bool(
                isinstance((_ledger() or {}).get("timer"), Mapping)
                and (_ledger() or {}).get("timer", {}).get("one_shot") is True
            ) if requested else True,
            "timer_self_rescheduling": bool(
                isinstance((_ledger() or {}).get("timer"), Mapping)
                and (_ledger() or {}).get("timer", {}).get("self_rescheduling") is True
            ) if requested else True,
            "timer_persistent": bool(
                isinstance((_ledger() or {}).get("timer"), Mapping)
                and (_ledger() or {}).get("timer", {}).get("persistent") is True
            ) if requested else True,
        }
    )
    # Watching is a strict ACTIVE assertion, never a synonym for an ON checkbox.
    if result.get("phase") != RuntimePhase.ACTIVE.value or not structural_registered:
        result["enabled"] = False
        result["watching"] = False
    return result

def runtime_status(context=None):
    status = get_runtime_status(context)
    if not status.get("requested_enabled") and status.get("phase") == RuntimePhase.DISABLED.value:
        return "Automatic history backup is disabled"
    if status.get("watching") and status.get("phase") == RuntimePhase.ACTIVE.value:
        return "Watching file changes"
    reason = (
        status.get("retrying_reason")
        or status.get("last_save_error")
        or status.get("last_runtime_error")
        or "runtime is not active"
    )
    condition = status.get("next_retry_condition") or "manual runtime refresh"
    return f"{status.get('phase', 'ERROR')}: {reason} (next: {condition})"


def unregister_runtime(*, save_pending: bool = True, reason: str = "unregister") -> bool:
    global _SF_LEDGER_INSTALLED, _SF_REGISTERED
    ok = _cleanup_generation(save_pending=bool(save_pending), reason=str(reason))
    if not _unregister_modal_scheduler(unregister_class=True):
        ok = False
    namespace = _namespace()
    if namespace is not None:
        ledger = namespace.get(_SF_RUNTIME_LEDGER_KEY)
        if isinstance(ledger, Mapping) and ledger.get("token") is _SF_RUNTIME_TOKEN:
            namespace.pop(_SF_RUNTIME_LEDGER_KEY, None)
        namespace.pop(_SF_RUNTIME_STATE_KEY, None)
        namespace.pop(_SF_RUNTIME_DIAGNOSTIC_KEY, None)
    _SF_REGISTERED = False
    _SF_LEDGER_INSTALLED = False
    return bool(ok)


def is_runtime_watching() -> bool:
    return bool(get_runtime_status().get("watching"))


def reset_runtime():
    """Compatibility reset; transactional checkpoints deliberately survive."""
    _RUNTIME["last_runtime_error"] = ""
    return None


register = register_runtime
unregister = unregister_runtime
sync_runtime = sync_listener_runtime


