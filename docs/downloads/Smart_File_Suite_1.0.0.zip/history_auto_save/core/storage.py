# ------------------------------------------------------------------------------
# Copyright (C) 2026 JELararagi
#
# License:
# - Copyright belongs to JELararagi.
# - Licensed under the GNU General Public License v3.0 or later (GPL-3.0-or-later).
# ------------------------------------------------------------------------------

from __future__ import annotations

import errno
import gzip
import json
import os
import re
import shutil
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

import bpy

from .context_utils import (
    addon_prefs,
    category_dir,
    current_blend_filepath,
    current_filename_stem,
    infer_project_key,
    now_stamp,
    safe_name,
    scene_settings,
    storage_root,
)


KNOWN_CATEGORIES = ("restore_points", "autosaves", "safety_backups", "logs")
_MTIME_TOLERANCE_NS = 2_000_000_000
_MAX_EXPORT_HISTORY_ROWS = 2048
_MAX_LOG_FILES = 200
_MAX_AUTOSAVE_COMMIT_COLLISIONS = 8
_AUTOSAVE_COMMIT_RE = re.compile(
    r'^(?P<base>.+)_Autosave_(?P<version>\d{3,})(?:_\d{3})?\.blend$',
    re.IGNORECASE,
)


@dataclass(frozen=True)
class VerifiedWriteResult:
    """Immutable evidence for the most recent snapshot transaction."""

    sequence: int
    attempted_monotonic: float
    success: bool
    filepath: str
    size_bytes: int = 0
    mtime_ns: int = 0
    operator_result: tuple[str, ...] = ()
    failure_kind: str = ""
    error: str = ""
    staging_filepath: str = ""
    committed: bool = False


class VerifiedSaveError(RuntimeError):
    def __init__(self, message: str, failure_kind: str = "SAVE_EXCEPTION"):
        super().__init__(message)
        self.failure_kind = str(failure_kind or "SAVE_EXCEPTION")


_LAST_VERIFIED_WRITE_RESULT = VerifiedWriteResult(
    sequence=0,
    attempted_monotonic=0.0,
    success=False,
    filepath="",
    failure_kind="NOT_ATTEMPTED",
    error="not attempted",
)
_LAST_SUCCESSFUL_WRITE_RESULT = _LAST_VERIFIED_WRITE_RESULT


def get_last_verified_write_result() -> VerifiedWriteResult:
    return _LAST_VERIFIED_WRITE_RESULT


def get_last_successful_write_result() -> VerifiedWriteResult:
    return _LAST_SUCCESSFUL_WRITE_RESULT


def _record_verified_result(
    *,
    success: bool,
    filepath: str,
    attempted_monotonic: float,
    size_bytes: int = 0,
    mtime_ns: int = 0,
    operator_result=(),
    failure_kind: str = "",
    error: str = "",
    staging_filepath: str = "",
    committed: bool = False,
) -> VerifiedWriteResult:
    global _LAST_VERIFIED_WRITE_RESULT, _LAST_SUCCESSFUL_WRITE_RESULT
    result = VerifiedWriteResult(
        sequence=int(_LAST_VERIFIED_WRITE_RESULT.sequence) + 1,
        attempted_monotonic=float(attempted_monotonic),
        success=bool(success),
        filepath=str(filepath or ""),
        size_bytes=max(0, int(size_bytes or 0)),
        mtime_ns=max(0, int(mtime_ns or 0)),
        operator_result=tuple(sorted(str(item) for item in (operator_result or ()))),
        failure_kind=str(failure_kind or ""),
        error=str(error or ""),
        staging_filepath=str(staging_filepath or ""),
        committed=bool(committed),
    )
    _LAST_VERIFIED_WRITE_RESULT = result
    if result.success and result.committed:
        _LAST_SUCCESSFUL_WRITE_RESULT = result
    return result


def _classify_exception(exc: BaseException) -> str:
    if isinstance(exc, VerifiedSaveError):
        return exc.failure_kind
    if isinstance(exc, PermissionError):
        return "ACCESS_DENIED"
    if isinstance(exc, FileNotFoundError):
        return "PATH_UNAVAILABLE"
    if isinstance(exc, OSError):
        code = getattr(exc, "errno", None)
        if code in {errno.ENOSPC, getattr(errno, "EDQUOT", -1)}:
            return "DISK_FULL"
        if code in {errno.ENAMETOOLONG, errno.EINVAL}:
            return "INVALID_PATH"
        if code in {errno.EROFS, errno.EACCES, errno.EPERM}:
            return "ACCESS_DENIED"
        if code in {errno.ENODEV, errno.ENXIO, errno.ENOTCONN, errno.ESTALE}:
            return "DRIVE_UNAVAILABLE"
        return "STORAGE_PATH"
    return "SAVE_EXCEPTION"


def _verified_output_path(kwargs) -> Path:
    raw = kwargs.get("filepath") or getattr(getattr(bpy, "data", None), "filepath", "")
    if not str(raw or "").strip():
        raise VerifiedSaveError("save_as_mainfile has no output filepath", "INVALID_PATH")
    try:
        return Path(os.path.abspath(os.path.expanduser(str(raw))))
    except Exception as exc:
        raise VerifiedSaveError(f"invalid output path: {exc}", "INVALID_PATH") from exc


def _readback_blender_header(path: Path) -> None:
    try:
        with path.open("rb") as stream:
            head = stream.read(16)
    except Exception as exc:
        raise VerifiedSaveError(f"saved file readback failed: {exc}", "OUTPUT_CORRUPT") from exc
    if head.startswith(b"BLENDER"):
        return
    if head.startswith(b"\x1f\x8b"):
        try:
            with gzip.open(path, "rb") as compressed:
                if compressed.read(7) == b"BLENDER":
                    return
        except Exception as exc:
            raise VerifiedSaveError(
                f"compressed save readback failed: {exc}", "OUTPUT_CORRUPT"
            ) from exc
    raise VerifiedSaveError("saved file readback has no BLENDER header", "OUTPUT_CORRUPT")


def _verify_saved_file(
    path: Path,
    expected_size: int | None = None,
    expected_mtime_ns: int | None = None,
    minimum_mtime_ns: int | None = None,
) -> tuple[int, int]:
    if not path.exists() or not path.is_file():
        raise VerifiedSaveError("save_as_mainfile output does not exist", "OUTPUT_MISSING")
    stat = path.stat()
    size_bytes = int(stat.st_size)
    mtime_ns = int(stat.st_mtime_ns)
    if size_bytes <= 0:
        raise VerifiedSaveError("save_as_mainfile output is empty", "OUTPUT_EMPTY")
    if mtime_ns <= 0:
        raise VerifiedSaveError("save_as_mainfile output has no valid mtime", "OUTPUT_STALE")
    if minimum_mtime_ns is not None and mtime_ns + _MTIME_TOLERANCE_NS < int(minimum_mtime_ns):
        raise VerifiedSaveError("save_as_mainfile output mtime was not updated", "OUTPUT_STALE")
    if expected_size is not None and size_bytes != int(expected_size):
        raise VerifiedSaveError("saved file size changed before readback", "OUTPUT_CORRUPT")
    if expected_mtime_ns is not None and mtime_ns != int(expected_mtime_ns):
        raise VerifiedSaveError("saved file mtime changed before readback", "OUTPUT_STALE")
    _readback_blender_header(path)
    try:
        with path.open("rb") as stream:
            head = stream.read(min(65536, size_bytes))
            if not head:
                raise VerifiedSaveError("saved file readback returned no bytes", "OUTPUT_CORRUPT")
            if size_bytes > len(head):
                stream.seek(max(0, size_bytes - 65536))
                if not stream.read(65536):
                    raise VerifiedSaveError("saved file tail readback returned no bytes", "OUTPUT_CORRUPT")
            stream.seek(0, os.SEEK_END)
            if int(stream.tell()) != size_bytes:
                raise VerifiedSaveError("saved file size changed during readback", "OUTPUT_CORRUPT")
            descriptor_stat = os.fstat(stream.fileno())
            if int(descriptor_stat.st_size) != size_bytes:
                raise VerifiedSaveError("saved file descriptor size is inconsistent", "OUTPUT_CORRUPT")
            if int(descriptor_stat.st_mtime_ns) != mtime_ns:
                raise VerifiedSaveError("saved file descriptor mtime is inconsistent", "OUTPUT_STALE")
    except VerifiedSaveError:
        raise
    except Exception as exc:
        raise VerifiedSaveError(f"saved file readback failed: {exc}", "OUTPUT_CORRUPT") from exc
    after = path.stat()
    if int(after.st_size) != size_bytes:
        raise VerifiedSaveError("saved file size changed after readback", "OUTPUT_CORRUPT")
    if int(after.st_mtime_ns) != mtime_ns:
        raise VerifiedSaveError("saved file mtime changed during readback", "OUTPUT_STALE")
    return size_bytes, mtime_ns


def _safe_remove_owned_stage(path: Path | None) -> None:
    if path is None:
        return
    try:
        if ".sfstage-" in path.name and path.exists() and path.is_file():
            path.unlink()
    except Exception:
        pass


def _commit_stage_no_overwrite(stage_path: Path, final_path: Path) -> None:
    """Commit a verified stage without ever replacing an existing good file."""
    if final_path.exists():
        raise VerifiedSaveError(
            "final snapshot appeared during transaction; refusing overwrite",
            "OUTPUT_EXISTS",
        )
    try:
        # Same-directory hard-link commit is atomic and fails if the destination
        # already exists.  Removing the private stage leaves the committed inode.
        os.link(stage_path, final_path)
        stage_path.unlink()
        return
    except FileExistsError as exc:
        raise VerifiedSaveError("final snapshot already exists", "OUTPUT_EXISTS") from exc
    except OSError as exc:
        unsupported = {
            getattr(errno, "EPERM", -1),
            getattr(errno, "EACCES", -1),
            getattr(errno, "EOPNOTSUPP", -1),
            getattr(errno, "ENOTSUP", -1),
            getattr(errno, "EXDEV", -1),
        }
        if getattr(exc, "errno", None) not in unsupported:
            raise

    # Filesystems without hard-link support use exclusive-create copy. This path
    # can only remove the file it created; a pre-existing destination is untouched.
    created_final = False
    fd = None
    try:
        fd = os.open(str(final_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        created_final = True
        stage_stat = stage_path.stat()
        with stage_path.open("rb") as source, os.fdopen(fd, "wb", closefd=True) as target:
            fd = None
            shutil.copyfileobj(source, target, length=1024 * 1024)
            target.flush()
            os.fsync(target.fileno())
        os.utime(
            final_path,
            ns=(int(stage_stat.st_atime_ns), int(stage_stat.st_mtime_ns)),
        )
        stage_path.unlink()
    except FileExistsError as exc:
        raise VerifiedSaveError("final snapshot already exists", "OUTPUT_EXISTS") from exc
    except Exception:
        if fd is not None:
            try:
                os.close(fd)
            except Exception:
                pass
        if created_final:
            try:
                final_path.unlink()
            except Exception:
                pass
        raise


def _next_autosave_commit_path(final_path: Path) -> Path | None:
    """Return the next numbered autosave path after an atomic commit race."""
    match = _AUTOSAVE_COMMIT_RE.match(final_path.name)
    if not match:
        return None
    version = int(match.group('version')) + 1
    if version > 999999:
        return None
    return final_path.with_name(
        f"{match.group('base')}_Autosave_{version:03d}.blend"
    )


def _verified_save_as_mainfile(*args, **kwargs):
    """Run Blender copy-save as a staged, readback-verified transaction.

    The requested final path must not exist. Blender writes a UUID-owned staging
    file in the same directory. Only a FINISHED result plus stable BLENDER
    readback is committed. Existing files are never removed or overwritten.
    """
    attempted = time.monotonic()
    attempted_wall_ns = time.time_ns()
    final_path: Path | None = None
    stage_path: Path | None = None
    final_created_by_transaction = False
    operator_result: tuple[str, ...] = ()
    try:
        final_path = _verified_output_path(kwargs)
        final_path.parent.mkdir(parents=True, exist_ok=True)
        if final_path.exists():
            raise VerifiedSaveError(
                "refusing to overwrite an existing snapshot file", "OUTPUT_EXISTS"
            )
        stage_path = final_path.with_name(
            f".sfstage-{uuid.uuid4().hex}.blend"
        )
        if stage_path.exists():
            raise VerifiedSaveError("staging path already exists", "OUTPUT_EXISTS")

        operator_kwargs = dict(kwargs)
        operator_kwargs["filepath"] = str(stage_path)
        # The UUID-owned stage is a validation copy, not a user Save As.  Do not
        # remap linked/asset paths relative to the temporary hidden stage name.
        # Blender 5.1 otherwise reports harmless but real path-remap warnings for
        # bundled essentials assets.  This override is intentionally scoped to
        # this copy-stage operator call; the final non-overwrite commit and normal
        # user saves retain their existing behavior.
        operator_kwargs["relative_remap"] = False
        raw_result = bpy.ops.wm.save_as_mainfile(*args, **operator_kwargs)
        if not isinstance(raw_result, (set, frozenset)):
            raise VerifiedSaveError(
                f"save_as_mainfile returned non-set result {raw_result!r}",
                "SAVE_CANCELLED",
            )
        operator_result = tuple(str(item) for item in raw_result)
        if "CANCELLED" in raw_result or "FINISHED" not in raw_result:
            raise VerifiedSaveError(
                f"save_as_mainfile returned {raw_result!r}", "SAVE_CANCELLED"
            )

        stage_size, stage_mtime = _verify_saved_file(
            stage_path, minimum_mtime_ns=attempted_wall_ns
        )
        # Another Blender process can claim the selected sequence after our
        # listdir scan but before the exclusive commit. Keep the already
        # verified private stage and try only a bounded number of later names;
        # never invoke Blender's save operator again and never overwrite the
        # winner.
        commit_collisions = 0
        while True:
            try:
                _commit_stage_no_overwrite(stage_path, final_path)
                break
            except VerifiedSaveError as exc:
                if exc.failure_kind != "OUTPUT_EXISTS":
                    raise
                commit_collisions += 1
                if commit_collisions > _MAX_AUTOSAVE_COMMIT_COLLISIONS:
                    raise VerifiedSaveError(
                        "autosave sequence remained busy after bounded commit retries",
                        "OUTPUT_EXISTS",
                    ) from exc
                next_path = _next_autosave_commit_path(final_path)
                if next_path is None:
                    raise
                final_path = next_path
        final_created_by_transaction = True
        stage_path = None
        final_size, final_mtime = _verify_saved_file(
            final_path,
            expected_size=stage_size,
            expected_mtime_ns=stage_mtime,
            minimum_mtime_ns=attempted_wall_ns,
        )
        result = _record_verified_result(
            success=True,
            filepath=str(final_path),
            attempted_monotonic=attempted,
            size_bytes=final_size,
            mtime_ns=final_mtime,
            operator_result=operator_result,
            committed=True,
        )
        return raw_result
    except Exception as exc:
        failure_kind = _classify_exception(exc)
        _safe_remove_owned_stage(stage_path)
        if final_created_by_transaction and final_path is not None:
            try:
                if final_path.exists() and final_path.is_file():
                    final_path.unlink()
            except Exception:
                pass
        _record_verified_result(
            success=False,
            filepath=str(final_path or ""),
            attempted_monotonic=attempted,
            operator_result=operator_result,
            failure_kind=failure_kind,
            error=f"{type(exc).__name__}: {exc}",
            staging_filepath=str(stage_path or ""),
            committed=False,
        )
        if isinstance(exc, VerifiedSaveError):
            raise
        raise VerifiedSaveError(str(exc), failure_kind) from exc


def _can_save(context=None):
    try:
        ctx = context or getattr(bpy, "context", None)
        wm = getattr(ctx, "window_manager", None)
        return not bool(wm and getattr(wm, "is_interface_locked", False))
    except Exception:
        return False


_AUTOSAVE_VERSION_RE = re.compile(r'^(?P<base>.+)_Autosave_(?P<version>\d{3,})(?:_\d{3})?\.blend$', re.IGNORECASE)


def _autosave_scene_base(context=None) -> str:
    if current_blend_filepath():
        raw_base = current_filename_stem() or infer_project_key(context) or 'Unsaved_Project'
    else:
        # An unsaved file has no stable project identity. Scene names are user
        # content and may change independently, so they never become the autosave
        # namespace before the first verified main-file save.
        raw_base = 'Unsaved_Project'
    base = safe_name(raw_base)
    match = _AUTOSAVE_VERSION_RE.match(base + '.blend')
    if match:
        base = safe_name(match.group('base'))
    for marker in ('__autosaves__', '__restore_points__', '__safety_backups__'):
        if marker in base:
            base = safe_name(base.split(marker, 1)[0])
    return base or 'Unsaved_Project'


def _snapshot_filename(category: str, label: str, context=None) -> str:
    if str(category or '').lower() == 'autosaves':
        return f"{_autosave_scene_base(context)}_Autosave_001.blend"
    base = safe_name(infer_project_key(context))
    cat = safe_name(category)
    note = safe_name(label)[:48]
    return f"{base}__{cat}__{now_stamp()}__{note}.blend"


def _autosave_version_from_name(name: str, base: str | None = None) -> int:
    match = _AUTOSAVE_VERSION_RE.match(str(name or ''))
    if not match:
        return 0
    if base is not None and safe_name(match.group('base')) != safe_name(base):
        return 0
    try:
        return int(match.group('version'))
    except Exception:
        return 0


def _next_autosave_filepath(directory: str, context=None) -> str:
    base = _autosave_scene_base(context)
    max_version = 0
    try:
        for name in os.listdir(directory):
            path = os.path.join(directory, name)
            if os.path.isfile(path):
                max_version = max(max_version, _autosave_version_from_name(name, base))
    except Exception:
        pass
    current = os.path.normcase(os.path.abspath(current_blend_filepath() or ''))
    version = max(1, max_version + 1)
    while version <= 999:
        filename = f"{base}_Autosave_{version:03d}.blend"
        filepath = os.path.join(directory, filename)
        candidate = os.path.normcase(os.path.abspath(filepath))
        if candidate != current and not os.path.exists(filepath):
            return filepath
        version += 1
    return _unique_filepath(os.path.join(directory, f"{base}_Autosave_{now_stamp()}.blend"))


def _unique_filepath(filepath: str) -> str:
    current = os.path.normcase(os.path.abspath(current_blend_filepath() or ""))
    candidate = os.path.normcase(os.path.abspath(filepath))
    root, ext = os.path.splitext(filepath)
    index = 1
    while candidate == current or os.path.exists(filepath):
        filepath = f"{root}_{index:03d}{ext}"
        candidate = os.path.normcase(os.path.abspath(filepath))
        index += 1
    return filepath


def save_snapshot_copy(category: str, label: str, context=None) -> str:
    """Create one verified snapshot without overwriting any existing file.

    Path creation, disconnected drives, invalid/overlong paths, permissions and
    capacity errors are contained inside this transaction.  The caller receives
    an empty string and can retain its pending dirty checkpoint.
    """
    attempted = time.monotonic()
    before_sequence = int(get_last_verified_write_result().sequence)
    try:
        prefs = addon_prefs(context)
        if not _can_save(context):
            _record_verified_result(
                success=False,
                filepath="",
                attempted_monotonic=attempted,
                failure_kind="INTERFACE_LOCK",
                error="Blender interface is locked; snapshot cannot be saved",
            )
            return ""
        directory = category_dir(category, context)
        filepath = (
            _next_autosave_filepath(directory, context)
            if str(category or '').lower() == 'autosaves'
            else _unique_filepath(os.path.join(directory, _snapshot_filename(category, label, context)))
        )
        _verified_save_as_mainfile(
            filepath=filepath,
            copy=True,
            check_existing=False,
            compress=bool(getattr(prefs, "compress_snapshots", False)) if prefs else False,
        )
        result = get_last_verified_write_result()
        return str(result.filepath) if result.success and result.committed else ""
    except Exception as exc:
        latest = get_last_verified_write_result()
        # Path construction can fail before _verified_save_as_mainfile starts.
        if int(latest.sequence) <= before_sequence:
            _record_verified_result(
                success=False,
                filepath="",
                attempted_monotonic=attempted,
                failure_kind=_classify_exception(exc),
                error=f"{type(exc).__name__}: {exc}",
            )
        return ""

def list_category_files(category: str, context=None):
    directory = category_dir(category, context)
    if not os.path.isdir(directory):
        return []
    return [os.path.join(directory, name) for name in sorted(os.listdir(directory)) if os.path.isfile(os.path.join(directory, name))]


def _file_sort_key(path: str):
    try:
        return (os.path.getmtime(path), os.path.basename(path))
    except Exception:
        return (0, os.path.basename(path))


def _all_autosave_files(context=None) -> list[str]:
    root = storage_root(context)
    files: list[str] = []
    try:
        for dirpath, _dirnames, filenames in os.walk(root):
            if os.path.basename(dirpath).lower() != 'autosaves':
                continue
            for name in filenames:
                lowered = name.lower()
                if lowered.endswith('.blend') and ('_autosave_' in lowered or '__autosaves__' in lowered):
                    files.append(os.path.join(dirpath, name))
    except Exception:
        pass
    return sorted(files, key=_file_sort_key)


def _scene_autosave_files(context=None) -> list[str]:
    directory = category_dir('autosaves', context)
    base = _autosave_scene_base(context)
    files: list[str] = []
    try:
        for name in os.listdir(directory):
            path = os.path.join(directory, name)
            if not os.path.isfile(path):
                continue
            lowered = name.lower()
            if _autosave_version_from_name(name, base) > 0:
                files.append(path)
            elif lowered.endswith('.blend') and f"{base.lower()}__autosaves__" in lowered:
                files.append(path)
    except Exception:
        pass
    return sorted(files, key=_file_sort_key)


def trim_old_files(category: str, max_count: int, context=None):
    max_count = max(1, min(999, int(max_count)))
    if str(category or '').lower() == 'autosaves':
        prefs = addon_prefs(context)
        scope = str(getattr(prefs, 'autosave_retention_scope', 'SCENE') or 'SCENE').upper() if prefs else 'SCENE'
        files = _all_autosave_files(context) if scope == 'GLOBAL' else _scene_autosave_files(context)
    else:
        files = list_category_files(category, context)
    while len(files) > max_count:
        path = files.pop(0)
        try:
            os.remove(path)
        except Exception:
            break


def delete_path(path: str):
    if not path:
        return
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def clear_known_project_files(context=None):
    for category in KNOWN_CATEGORIES:
        directory = category_dir(category, context)
        if not os.path.isdir(directory):
            continue
        for name in os.listdir(directory):
            path = os.path.join(directory, name)
            if os.path.isfile(path):
                delete_path(path)


def sync_entries_with_disk(context=None):
    st = scene_settings(context)
    if st is None:
        return
    remove_indices = []
    for index, item in enumerate(st.entries):
        if item.entry_type not in {"Restore Point", "Autosave"}:
            remove_indices.append(index)
            continue
        if item.file_path and not os.path.exists(item.file_path):
            item.file_path = ""
            item.restorable = False
        if not item.file_path or not item.restorable:
            remove_indices.append(index)
    for index in reversed(remove_indices):
        st.entries.remove(index)
    if len(st.entries) == 0:
        st.active_index = -1
    elif st.active_index >= len(st.entries):
        st.active_index = len(st.entries) - 1


def export_history_json(context=None) -> str:
    st = scene_settings(context)
    if st is None:
        return ""
    try:
        export_dir = category_dir("logs", context)
        filepath = _unique_filepath(os.path.join(export_dir, f"history_log__{now_stamp()}.json"))
        rows = tuple(st.entries)
        if len(rows) > _MAX_EXPORT_HISTORY_ROWS:
            rows = rows[-_MAX_EXPORT_HISTORY_ROWS:]
        payload = []
        for item in rows:
            payload.append({
                "label": item.label,
                "detail": item.detail,
                "entry_type": item.entry_type,
                "timestamp": item.timestamp,
                "active_object": item.active_object,
                "mode": item.mode,
                "scene_name": item.scene_name,
                "frame": item.frame,
                "selected_count": item.selected_count,
                "file_path": item.file_path,
                "restorable": bool(item.restorable),
                "nearest_restore_index": int(item.nearest_restore_index),
            })
        temp_path = filepath + f".tmp-{uuid.uuid4().hex}"
        with open(temp_path, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, filepath)
        trim_old_files("logs", _MAX_LOG_FILES, context)
        return filepath
    except Exception:
        try:
            if 'temp_path' in locals() and os.path.exists(temp_path):
                os.remove(temp_path)
        except Exception:
            pass
        return ""
