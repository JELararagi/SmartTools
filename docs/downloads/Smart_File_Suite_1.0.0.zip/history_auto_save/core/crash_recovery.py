from __future__ import annotations

if __package__:
    from ...ui_language_runtime import ui_text as _ui_text
else:
    # ワーカーとして単独で起動された時はパッケージが無いので、文は英語のまま書く
    def _ui_text(en, ja):
        return en
import hashlib
import ctypes
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any, Iterable

try:
    from bpy.app.handlers import persistent  # type: ignore
except Exception:
    def persistent(func):
        return func


SCHEMA_SCAN = "smart_file_crash_recovery/scan/1"
SCHEMA_COPY = "smart_file_crash_recovery/copy/1"
SCHEMA_ORIGINAL_CHAIN = "smart_file_crash_recovery/original_chain/1"
STATE_KEY = "smart_file_crash_recovery_state_v1"
TIMER_KEY = "smart_file_crash_recovery_timer_v1"
HANDLERS_KEY = "smart_file_crash_recovery_handlers_v1"
BLENDER_HEADER = b"BLENDER"
ZSTD_MAGIC = b"\x28\xb5\x2f\xfd"
EXTERNAL_CRASH_KIND = "external_crash_process"
EXTERNAL_PROCESS_KIND = "external_blender_process"
# Same rules as the original 2.3.0 process list: a Blender whose process owns a
# visible standard dialog window (#32770, any title) is the crashed one; the
# main window title carries "[<path>.blend]" and a leading "*" for unsaved work.
_DIALOG_CLASS = "#32770"
_TITLE_BLEND_RE = re.compile(r"\[(.+?\.blend)\]", re.I)
_TITLE_NAME_RE = re.compile(r"^\*?\s*(.+?)\s*(?:\[[^\]]*\]\s*)?-\s*Blender\b", re.I)
PROGRESS_PREFIX = "@@PROGRESS "
LEASE_SCHEMA = "smart_file_crash_recovery/lease/1"
LEASE_TTL_SECONDS = 15 * 60
_OWNED_HANDLER_NAMES = frozenset({
    "_save_pre_reset_runtime",
    "_load_post_reset_runtime",
})
_THIS_CODE_FILENAME = os.path.normcase(str(Path(__file__).resolve()))
_THIS_CODE_BASENAME = Path(_THIS_CODE_FILENAME).name
# Stage names printed by the original engine; their percentages cover the whole engine run.
_ENGINE_STAGES = frozenset({"scan", "summary", "inline", "write", "done"})
# Overall progress per worker mode: each phase maps its own 0-100 onto this span.
_PROGRESS_RANGES = {
    "dump_rescue": {"dump": (1, 25), "engine": (25, 85), "finalize": (85, 99)},
    "dump_analyze": {"dump": (1, 30), "engine": (30, 99)},
    "dump_extract": {"engine": (1, 85), "finalize": (85, 99)},
    "dump_file_analyze": {"engine": (1, 99)},
    "copy": {"copy": (0, 99)},
    "points_scan": {"files": (0, 99)},
}
_STAGE_TEXT = {
    "files": ("Looking for saved files...", "保存済みファイルを探しています…"),
    "copy": ("Copying the file...", "ファイルを写しています…"),
    "dump": ("Reading the memory of the other Blender...", "ほかの Blender のメモリーを読み取っています…"),
    "scan": ("Searching the Undo history...", "Undo の履歴を探しています…"),
    "summary": ("Reading each Undo step...", "Undo の各段を読み取っています…"),
    "inline": ("Restoring shared data...", "共有データを戻しています…"),
    "write": ("Writing the .blend file...", ".blend を書き出しています…"),
    "finalize": ("Saving the recovered file...", "復旧したファイルを保存しています…"),
    "done": ("Finishing...", "仕上げています…"),
}
_START_TEXT = {
    "dump_rescue": ("Recovering the latest state...", "最新の状態を復旧しています…"),
    "dump_analyze": ("Looking for recovery points...", "復旧ポイントを探しています…"),
    "dump_extract": ("Recovering the chosen point...", "選んだ時点を復旧しています…"),
    "dump_file_analyze": ("Reading the dump file...", "ダンプファイルを読んでいます…"),
    "copy": ("Copying the chosen file...", "選んだファイルを写しています…"),
    "points_scan": ("Looking for saved files...", "保存済みファイルを探しています…"),
}
_LABEL_JA = {
    "Recovered file": "復旧済みファイル",
    "Previous save (.blend1)": "直前の保存 (.blend1)",
    "Earlier save (.blend2)": "2 つ前の保存 (.blend2)",
    "Restore point": "復元ポイント",
    "Smart File autosave": "自動保存 (Smart File)",
    "Blender autosave": "自動保存 (Blender)",
    "Quit recovery file": "終了時の状態 (quit.blend)",
    "Crash-written blend": "クラッシュ時の書き出し",
    "Saved file": "保存済みの本体",
    "Related blend": "関連ファイル",
    "Crashed": "クラッシュ",
    "Not responding": "応答なし",
    "Unsaved changes": "未保存の変更あり",
    "Running": "実行中",
}
_ERROR_TEXT = {
    "ACCESS": ("Access was denied. Start this Blender with the same user rights as the other one.",
               "アクセスが拒否されました。この Blender を、相手の Blender と同じ権限で起動してください。"),
    "GONE": ("The selected Blender is no longer running. Refresh the Blender list.",
             "選んだ Blender はもう動いていません。Blender の一覧を更新してください。"),
    "DISK": ("There is not enough free disk space for the memory dump.",
             "メモリーダンプを書くための空き容量が足りません。"),
    "EXISTS": ("A file with the same name already exists.", "同じ名前のファイルがすでにあります。"),
    "NO_UNDO": ("No Undo history was found in the memory. Try the saved files instead.",
                "メモリーに Undo の履歴が見つかりませんでした。保存済みファイルを試してください。"),
    "ERROR": ("Crash recovery failed.", "クラッシュ復旧に失敗しました。"),
}


class _PMCEX(ctypes.Structure):
    """PROCESS_MEMORY_COUNTERS_EX."""
    _fields_ = [("cb", ctypes.c_uint32), ("PageFaultCount", ctypes.c_uint32),
                ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t),
                ("PrivateUsage", ctypes.c_size_t)]


def _progress(stage: str, pct: float, msg: str = "") -> None:
    """Same machine-readable line as the original engine, read back by the controller."""
    try:
        _pipe = sys.stdout   # controller pipe of the recovery subprocess
        _pipe.write("%s%s %d %s\n" % (PROGRESS_PREFIX, stage, int(pct), msg))
        _pipe.flush()
    except Exception:
        pass


def _now_text() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _stamp() -> str:
    return time.strftime("%Y%m%d_%H%M%S")


def _file_stem(value: str) -> str:
    """Keep the scene name as typed (any language); drop only characters Windows forbids."""
    text = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", str(value or "")).strip(" .")
    return text or "untitled"


def _safe_name(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9._ -]+", "_", str(value or "Recovered")).strip(" ._")
    return text or "Recovered"


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def _read_head(path: Path, want: int = 1 << 18) -> bytes:
    try:
        with path.open("rb") as handle:
            # zstd の .blend は圧縮後の先頭 want バイトでは展開できないので、多めに読む
            raw = handle.read(max(want, 1 << 18))
    except Exception:
        return b""
    if raw[:4] != ZSTD_MAGIC:
        return raw[:want]
    try:
        import io
        import zstandard

        out: list[bytes] = []
        got = 0
        with zstandard.ZstdDecompressor().stream_reader(io.BytesIO(raw)) as reader:
            while got < want:
                chunk = reader.read(min(65536, want - got))
                if not chunk:
                    break
                out.append(chunk)
                got += len(chunk)
        return b"".join(out)
    except Exception:
        return b""


def is_readable_blend_header(path: str | os.PathLike[str]) -> bool:
    try:
        p = Path(path)
        return p.is_file() and p.stat().st_size > 12 and _read_head(p, 16).startswith(BLENDER_HEADER)
    except Exception:
        return False


_PATH_RE = re.compile(rb"[A-Za-z]:[\\/][^\x00\r\n]{0,700}?\.blend\b")
_HISTORY_RE = re.compile(r"[\\/]Smart_File_Suite[\\/]history[\\/](?P<project>[^\\/]+)[\\/]", re.I)
_AUTOSAVE_RE = re.compile(r"^(?P<stem>.+?)_Autosave_\d+$", re.I)
_RESTORE_RE = re.compile(r"^(?P<stem>.+?)__restore_points__.*$", re.I)
_BLENDER_AUTOSAVE_RE = re.compile(r"^(?P<stem>.+?)_\d+_autosave$", re.I)
_RECOVERED_RE = re.compile(r"^(?P<stem>.+?)_recovered(?:[_.].*)?$", re.I)


def blend_self_path(path: str | os.PathLike[str]) -> str:
    head = _read_head(Path(path))
    if not head.startswith(BLENDER_HEADER):
        return ""
    pos = 12
    size = len(head)
    while pos + 24 <= size:
        code = head[pos:pos + 4]
        try:
            block_len = int.from_bytes(head[pos + 16:pos + 24], "little", signed=False)
        except Exception:
            break
        data_pos = pos + 24
        if code == b"GLOB":
            match = _PATH_RE.search(head[data_pos:data_pos + min(block_len, 8192)])
            return match.group(0).decode("utf-8", "replace") if match else ""
        if code == b"ENDB" or block_len > (1 << 32):
            break
        pos = data_pos + block_len
    return ""


def scene_key_for(path: Path, history_root: str | os.PathLike[str] | None = None) -> tuple[str, bool]:
    name = path.name
    stem = path.stem
    low_name = name.lower()
    if history_root:
        # Smart File history: <root>/<project>/(autosaves|restore_points)/...
        try:
            rel = path.resolve().relative_to(Path(history_root).resolve())
            if len(rel.parts) >= 2:
                return rel.parts[0], False
        except Exception:
            pass
    norm = str(path).replace("/", "\\")
    match = _HISTORY_RE.search(norm)
    if match:
        return match.group("project"), False
    if low_name.endswith((".blend1", ".blend2")):
        return Path(name).stem, False
    if low_name == "quit.blend" or low_name.endswith(".crash.blend"):
        return "", True
    for rx in (_AUTOSAVE_RE, _RESTORE_RE, _BLENDER_AUTOSAVE_RE, _RECOVERED_RE):
        found = rx.match(stem)
        if found:
            return found.group("stem"), False
    return stem, False


def candidate_kind(path: Path, home_dir: Path | None, scene_stem: str) -> tuple[str, str]:
    low = str(path).lower().replace("\\", "/")
    stem = path.stem
    if _RECOVERED_RE.match(stem):
        return "recovered", "Recovered file"
    if low.endswith(".blend1"):
        return "backup", "Previous save (.blend1)"
    if low.endswith(".blend2"):
        return "backup", "Earlier save (.blend2)"
    if "restore_points" in low:
        return "restore", "Restore point"
    if "autosaves" in low:
        return "autosave", "Smart File autosave"
    if path.name.lower().endswith("_autosave.blend"):
        return "autosave", "Blender autosave"
    if path.name.lower() == "quit.blend":
        return "quit", "Quit recovery file"
    if low.endswith(".crash.blend"):
        return "crash", "Crash-written blend"
    if home_dir is not None and path.parent.resolve() == home_dir.resolve() and stem.lower() == scene_stem.lower():
        return "self", "Saved file"
    return "other", "Related blend"


_MAIN_WINDOW_CLASS = "GHOST_WindowClass"
_STATE_LABELS = {
    "crashed": "Crashed",
    "hung": "Not responding",
    "unsaved": "Unsaved changes",
    "running": "Running",
}


def _win32() -> dict[str, Any] | None:
    """Private user32/kernel32 handles with full prototypes (never the shared ctypes.windll)."""
    if os.name != "nt":
        return None
    try:
        from ctypes import wintypes
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        enum_proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        user32.EnumWindows.argtypes = (enum_proc, wintypes.LPARAM)
        user32.EnumWindows.restype = wintypes.BOOL
        user32.IsWindowVisible.argtypes = (wintypes.HWND,)
        user32.IsWindowVisible.restype = wintypes.BOOL
        user32.GetWindowTextLengthW.argtypes = (wintypes.HWND,)
        user32.GetWindowTextLengthW.restype = ctypes.c_int
        user32.GetWindowTextW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
        user32.GetWindowTextW.restype = ctypes.c_int
        user32.GetClassNameW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
        user32.GetClassNameW.restype = ctypes.c_int
        user32.GetWindowThreadProcessId.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.DWORD))
        user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        user32.IsHungAppWindow.argtypes = (wintypes.HWND,)
        user32.IsHungAppWindow.restype = wintypes.BOOL
        user32.GetWindow.argtypes = (wintypes.HWND, ctypes.c_uint)
        user32.GetWindow.restype = wintypes.HWND
        kernel32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
        kernel32.CloseHandle.restype = wintypes.BOOL
        kernel32.QueryFullProcessImageNameW.argtypes = (wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR,
                                                        ctypes.POINTER(wintypes.DWORD))
        kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL
        kernel32.GetProcessTimes.argtypes = (wintypes.HANDLE,) + (ctypes.POINTER(wintypes.FILETIME),) * 4
        kernel32.GetProcessTimes.restype = wintypes.BOOL
        kernel32.GetExitCodeProcess.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
        kernel32.GetExitCodeProcess.restype = wintypes.BOOL
        kernel32.K32GetProcessMemoryInfo.argtypes = (wintypes.HANDLE, ctypes.POINTER(_PMCEX), wintypes.DWORD)
        kernel32.K32GetProcessMemoryInfo.restype = wintypes.BOOL
        return {"user32": user32, "kernel32": kernel32, "enum_proc": enum_proc, "wintypes": wintypes}
    except Exception:
        return None


def _collect_window_rows(api: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    api = api or _win32()
    if not api:
        return []
    user32 = api["user32"]
    wintypes = api["wintypes"]
    rows: list[dict[str, Any]] = []

    def _visit(hwnd, _lparam):
        try:
            if not user32.IsWindowVisible(hwnd):
                return True
            pid = wintypes.DWORD(0)
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            length = max(0, int(user32.GetWindowTextLengthW(hwnd)))
            title = ctypes.create_unicode_buffer(length + 2)
            user32.GetWindowTextW(hwnd, title, length + 2)
            klass = ctypes.create_unicode_buffer(256)
            user32.GetClassNameW(hwnd, klass, 256)
            rows.append({"pid": int(pid.value), "title": title.value, "class_name": klass.value,
                         "hung": bool(user32.IsHungAppWindow(hwnd)), "owned": bool(user32.GetWindow(hwnd, 4))})
        except Exception:
            pass
        return True

    callback = api["enum_proc"](_visit)
    try:
        user32.EnumWindows(callback, 0)
    except Exception:
        pass
    return rows


def _process_details(api: dict[str, Any] | None, pid: int) -> dict[str, Any]:
    info: dict[str, Any] = {"exe": "", "started": 0.0, "private_bytes": 0, "working_set": 0}
    if not api:
        return info
    kernel32 = api["kernel32"]
    wintypes = api["wintypes"]
    # QUERY_LIMITED_INFORMATION | VM_READ (memory counters), then QUERY_LIMITED_INFORMATION only.
    handle = kernel32.OpenProcess(0x1010, False, int(pid)) or kernel32.OpenProcess(0x1000, False, int(pid))
    if not handle:
        return info
    try:
        size = wintypes.DWORD(1024)
        buf = ctypes.create_unicode_buffer(1024)
        if kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            info["exe"] = buf.value
        times = [wintypes.FILETIME() for _ in range(4)]
        if kernel32.GetProcessTimes(handle, *[ctypes.byref(item) for item in times]):
            ticks = (int(times[0].dwHighDateTime) << 32) | int(times[0].dwLowDateTime)
            if ticks:
                info["started"] = ticks / 1e7 - 11644473600.0
        counters = _PMCEX()
        counters.cb = ctypes.sizeof(counters)
        if kernel32.K32GetProcessMemoryInfo(handle, ctypes.byref(counters), counters.cb):
            info["private_bytes"] = int(counters.PrivateUsage)
            info["working_set"] = int(counters.WorkingSetSize)
    except Exception:
        pass
    finally:
        kernel32.CloseHandle(handle)
    return info


def discover_blender_processes(*, current_pid: int | None = None, window_rows=None, detail_lookup=None) -> list[dict[str, Any]]:
    """Every other running Blender, with the original process-list rules (crashed ones first)."""
    api = None
    if window_rows is None or detail_lookup is None:
        api = _win32()
    if window_rows is None:
        window_rows = _collect_window_rows(api)
    if detail_lookup is None:
        def detail_lookup(pid, _api=api):
            return _process_details(_api, pid)
    me = int(os.getpid() if current_pid is None else current_pid)
    by_pid: dict[int, list[dict[str, Any]]] = {}
    for row in window_rows or ():
        try:
            pid = int(row.get("pid", 0) or 0)
        except Exception:
            continue
        if pid <= 0 or pid == me:
            continue
        by_pid.setdefault(pid, []).append(row)
    found: list[dict[str, Any]] = []
    for pid, rows in by_pid.items():
        details = dict(detail_lookup(pid) or {})
        exe = str(details.get("exe", "") or "")
        mains = [r for r in rows if str(r.get("class_name", "")) == _MAIN_WINDOW_CLASS]
        if exe:
            if Path(exe).name.lower() != "blender.exe":
                continue
        elif not mains:
            continue
        titled = [r for r in mains if _TITLE_BLEND_RE.search(str(r.get("title", "") or ""))
                  or _TITLE_NAME_RE.match(str(r.get("title", "") or ""))]
        main = (titled or mains or [{}])[0]
        title = str(main.get("title", "") or "")
        if any(str(r.get("class_name", "")) == _DIALOG_CLASS for r in rows):
            state = "crashed"
        elif any(bool(r.get("hung")) for r in mains):
            state = "hung"
        elif title.startswith("*"):
            state = "unsaved"
        else:
            state = "running"
        blend_match = _TITLE_BLEND_RE.search(title)
        blend_path = blend_match.group(1) if blend_match else ""
        name_match = _TITLE_NAME_RE.match(title)
        home_dir = ""
        if blend_path:
            try:
                parent = Path(blend_path).parent
                home_dir = str(parent) if parent.is_dir() else ""
            except Exception:
                home_dir = ""
        started = float(details.get("started", 0.0) or 0.0)
        found.append({
            "path": f"pid:{pid}",
            "pid": pid,
            "kind": EXTERNAL_CRASH_KIND if state == "crashed" else EXTERNAL_PROCESS_KIND,
            "state": state,
            "label": _STATE_LABELS[state],
            "scene_name": Path(blend_path).name if blend_path else "",
            "title_name": name_match.group(1).strip() if name_match else "",
            "blend_path": blend_path,
            "home_dir": home_dir,
            "size": int(details.get("private_bytes", 0) or 0),
            "mtime": started,
            "mtime_text": time.strftime("%Y/%m/%d %H:%M:%S", time.localtime(started)) if started > 0 else "",
            "crash_signal": "dialog" if state == "crashed" else "",
            "executable_path": exe,
            "title": title,
            "valid_blend_header": False,
            "suspect_small": False,
            "recommended": False,
        })
    found.sort(key=lambda item: (0 if item["state"] == "crashed" else 1, -float(item.get("mtime", 0) or 0)))
    if found and found[0]["state"] == "crashed":
        found[0]["recommended"] = True
    return found


def _add_file(path: Path, seen: set[str], out: list[Path]) -> None:
    try:
        resolved = path.resolve()
        key = os.path.normcase(str(resolved))
        if key in seen or not resolved.is_file():
            return
        if not resolved.name.lower().endswith((".blend", ".blend1", ".blend2")):
            return
        seen.add(key)
        out.append(resolved)
    except Exception:
        return


_SCAN_PRIORITY = {"autosave": 0, "restore": 0, "quit": 1, "crash": 1, "self": 2, "backup": 2, "recovered": 8, "other": 9}
_BLEND_SUFFIXES = (".blend", ".blend1", ".blend2")


def iter_candidate_files(roots: Iterable[str] = (), *, config_dirs: Iterable[str] = (), history_root: str = "",
                         temp_dirs: Iterable[str] = ()) -> list[Path]:
    """Saved .blend files, collected with the original quick-recovery rules."""
    seen: set[str] = set()
    out: list[Path] = []
    scene_dirs: list[Path] = []
    dir_keys: set[str] = set()

    def _remember_dir(path: Path) -> None:
        try:
            resolved = path.resolve()
            key = os.path.normcase(str(resolved))
            if key not in dir_keys and resolved.is_dir():
                dir_keys.add(key)
                scene_dirs.append(resolved)
        except Exception:
            return

    for raw in config_dirs or ():
        if not raw:
            continue
        base = Path(raw)
        for recent in (base / "recent-files.txt", base / "Smart_File_Suite" / "recent-files.txt"):
            try:
                lines = recent.read_text(encoding="utf-8", errors="replace").splitlines()
            except Exception:
                continue
            for line in lines:
                text = line.strip()
                if not text.lower().endswith(".blend"):
                    continue
                path = Path(text)
                _add_file(path, seen, out)
                _remember_dir(path.parent)
    for raw in roots or ():
        if not raw:
            continue
        p = Path(raw)
        if p.is_dir():
            _remember_dir(p)
        elif p.is_file():
            _add_file(p, seen, out)
            _remember_dir(p.parent)
    for d in list(scene_dirs):
        try:
            for p in d.iterdir():
                if p.name.lower().endswith(_BLEND_SUFFIXES):
                    _add_file(p, seen, out)
        except Exception:
            pass
    if history_root:
        try:
            projects = [p for p in Path(history_root).iterdir() if p.is_dir()]
        except Exception:
            projects = []
        for project in projects:
            for category in ("autosaves", "restore_points"):
                folder = project / category
                try:
                    if folder.is_dir():
                        for p in folder.rglob("*.blend"):
                            _add_file(p, seen, out)
                except Exception:
                    pass
    for raw in temp_dirs or ():
        if not raw:
            continue
        try:
            for p in Path(raw).iterdir():
                low = p.name.lower()
                if low.endswith("_autosave.blend") or low == "quit.blend" or low.endswith(".crash.blend"):
                    _add_file(p, seen, out)
        except Exception:
            pass
    return out


def _head_kind(path: Path) -> tuple[bool, bool]:
    """(looks like a .blend, compressed) from the first 12 bytes only."""
    try:
        with path.open("rb") as handle:
            head = handle.read(12)
    except Exception:
        return False, False
    if head.startswith(BLENDER_HEADER):
        return True, False
    if head[:4] == ZSTD_MAGIC or head[:2] == b"\x1f\x8b":
        return True, True
    return False, False


def scan_to_payload(roots: Iterable[str] = (), *, config_dirs: Iterable[str] = (), history_root: str = "",
                    temp_dirs: Iterable[str] = ()) -> dict[str, Any]:
    _progress("files", 2)
    files = iter_candidate_files(roots, config_dirs=config_dirs, history_root=history_root, temp_dirs=temp_dirs)
    _progress("files", 15)
    scenes: dict[str, dict[str, Any]] = {}
    total = max(1, len(files))
    for index, path in enumerate(files):
        if index % 16 == 0:
            _progress("files", 15 + int(80.0 * index / total))
        try:
            st = path.stat()
        except Exception:
            continue
        stem, needs_head = scene_key_for(path, history_root or None)
        self_path = blend_self_path(path) if needs_head else ""
        if self_path:
            stem = Path(self_path).stem
        if not stem:
            stem = path.stem
        key = stem.lower()
        valid, compressed = _head_kind(path)
        scene = scenes.setdefault(key, {"scene_name": stem + ".blend", "scene_path": "", "home_dir": "", "candidates": []})
        if path.suffix.lower() == ".blend" and path.stem.lower() == key:
            # the scene's own saved file decides where it lives
            scene["scene_path"] = str(path)
            scene["home_dir"] = str(path.parent)
        elif self_path and not scene["home_dir"]:
            try:
                parent = Path(self_path).parent
                if parent.is_dir():
                    scene["home_dir"] = str(parent)
                    if not scene["scene_path"]:
                        scene["scene_path"] = self_path
            except Exception:
                pass
        scene["candidates"].append({
            "path": str(path),
            "mtime": st.st_mtime,
            "mtime_text": time.strftime("%Y/%m/%d %H:%M:%S", time.localtime(st.st_mtime)),
            "size": int(st.st_size),
            "self_path": self_path,
            "compressed": compressed,
            "valid_blend_header": valid,
        })
    out: list[dict[str, Any]] = []
    for scene in scenes.values():
        cands = scene["candidates"]
        home = Path(scene["home_dir"]) if scene["home_dir"] else None
        stem = Path(scene["scene_name"]).stem
        for c in cands:
            kind, label = candidate_kind(Path(c["path"]), home, stem)
            c.update({"kind": kind, "label": label, "scene_name": scene["scene_name"],
                      "scene_path": scene["scene_path"], "blend_path": scene["scene_path"],
                      "home_dir": scene["home_dir"]})
        # compressed and uncompressed saves are compared only with their own kind
        for packed in (True, False):
            biggest = max((int(c["size"]) for c in cands if c["valid_blend_header"] and bool(c["compressed"]) == packed),
                          default=0)
            for c in cands:
                if bool(c["compressed"]) == packed:
                    c["suspect_small"] = bool(biggest and c["valid_blend_header"] and int(c["size"]) < biggest * 0.6)
        ranked = sorted(cands, key=lambda c: (0 if c["valid_blend_header"] else 1, 1 if c.get("suspect_small") else 0,
                                              _SCAN_PRIORITY.get(str(c.get("kind")), 9), -float(c.get("mtime", 0) or 0)))
        best = ranked[0]["path"] if ranked else ""
        for c in cands:
            c["recommended"] = c["path"] == best
        cands.sort(key=lambda c: float(c.get("mtime", 0) or 0), reverse=True)
        scene["candidate_count"] = len(cands)
        scene["recommended_path"] = best
        scene["newest_mtime"] = float(cands[0].get("mtime", 0) or 0) if cands else 0.0
        out.append(scene)
    out.sort(key=lambda item: float(item.get("newest_mtime", 0) or 0), reverse=True)
    _progress("files", 100)
    return {"schema": SCHEMA_SCAN, "status": "PASS", "generated": _now_text(), "scanned_files": len(files), "scenes": out}


def command_scan(out_json: str, roots: list[str], *, config_dirs: Iterable[str] = (), history_root: str = "",
                 temp_dirs: Iterable[str] = ()) -> int:
    payload = scan_to_payload(roots, config_dirs=config_dirs, history_root=history_root, temp_dirs=temp_dirs)
    Path(out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(out_json).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0


def _atomic_copy_blend(source: Path, destination: Path) -> dict[str, Any]:
    source = source.resolve()
    destination = destination.resolve()
    before = source.stat()
    if destination.exists():
        raise FileExistsError(_ui_text(f"Destination already exists: {destination}", f'保存先がすでにあります：{destination}'))
    if not is_readable_blend_header(source):
        raise ValueError(_ui_text(f"Source is not a readable .blend header: {source}", f'読める .blend ではありません：{source}'))
    destination.parent.mkdir(parents=True, exist_ok=True)
    part = destination.with_name(destination.name + ".part")
    if part.exists():
        part.unlink()
    with source.open("rb") as src, part.open("wb") as dst:
        shutil.copyfileobj(src, dst, 1024 * 1024)
        dst.flush()
        try:
            os.fsync(dst.fileno())
        except Exception:
            pass
    os.replace(str(part), str(destination))
    after = source.stat()
    if before.st_size != after.st_size or int(before.st_mtime_ns) != int(after.st_mtime_ns):
        raise RuntimeError("Source metadata changed during recovery copy; destination was written but source integrity is not proven")
    return {
        "source": str(source),
        "destination": str(destination),
        "source_size": before.st_size,
        "destination_size": destination.stat().st_size,
        "source_sha256": _sha256(source),
        "destination_sha256": _sha256(destination),
        "source_mtime_ns_before": int(before.st_mtime_ns),
        "source_mtime_ns_after": int(after.st_mtime_ns),
        "destination_valid_blend_header": is_readable_blend_header(destination),
    }


def command_copy(source: str, destination: str, out_json: str) -> int:
    payload = {"schema": SCHEMA_COPY, "generated": _now_text(), "status": "FAIL", "error": ""}
    try:
        result = _atomic_copy_blend(Path(source), Path(destination))
        payload.update(result)
        payload["byte_identical"] = result["source_sha256"] == result["destination_sha256"]
        payload["status"] = "PASS" if payload["byte_identical"] and result["destination_valid_blend_header"] else "FAIL"
    except Exception as exc:
        payload["error"] = f"{type(exc).__name__}: {exc}"
    Path(out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(out_json).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0 if payload["status"] == "PASS" else 3


def _same_path(a: str, b: str) -> bool:
    if not a or not b:
        return False
    try:
        return os.path.normcase(os.path.abspath(str(a))) == os.path.normcase(os.path.abspath(str(b)))
    except Exception:
        return False


def _open_recovered_mainfile(context, path: str) -> dict[str, Any]:
    """Open the recovered .blend in this Blender; Blender asks about unsaved changes itself."""
    payload: dict[str, Any] = {"requested_path": path, "status": "NOT_RUN", "filepath_after": ""}
    if not path:
        payload["status"] = "NO_PATH"
        return payload
    if not Path(path).is_file():
        payload["status"] = "MISSING_PATH"
        return payload
    try:
        bpy = _bpy()
        if bool(getattr(getattr(bpy, "app", None), "background", False)):
            result = bpy.ops.wm.open_mainfile('EXEC_DEFAULT', filepath=str(path), load_ui=False)
        else:
            window = getattr(context, "window", None) if context is not None else None
            wm = getattr(bpy.context, "window_manager", None)
            if window is None and wm is not None and len(wm.windows):
                window = wm.windows[0]
            if window is None:
                raise RuntimeError("no Blender window is available to open the recovered file")
            with bpy.context.temp_override(window=window, screen=window.screen):
                result = bpy.ops.wm.open_mainfile('INVOKE_DEFAULT', filepath=str(path), load_ui=False,
                                                  display_file_selector=False)
        result_set = set(result) if isinstance(result, set) else set()
        filepath_after = str(getattr(getattr(bpy, "data", None), "filepath", "") or "")
        payload.update({"operator_result": sorted(result_set), "filepath_after": filepath_after})
        if _same_path(filepath_after, path):
            payload["status"] = "PASS"
        elif "CANCELLED" in result_set:
            payload["status"] = "FAIL"
            payload["error"] = "open_mainfile was cancelled"
        else:
            # Blender is showing its own save/discard prompt for the current file
            payload["status"] = "PENDING_CONFIRMATION"
    except Exception as exc:
        payload["status"] = "FAIL"
        payload["error"] = f"{type(exc).__name__}: {exc}"
    return payload


def _write_full_memory_dump(pid: int, destination: Path) -> dict[str, Any]:
    """Create one read-only, owned full minidump of an explicit other PID."""
    if os.name != "nt":
        raise RuntimeError("full process dumps are supported only on Windows")
    if int(pid) <= 0 or int(pid) == os.getpid():
        raise ValueError("an explicit other process PID is required")
    destination = destination.resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise FileExistsError(f"dump destination already exists: {destination}")
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    dbghelp = ctypes.WinDLL("dbghelp", use_last_error=True)
    psapi = ctypes.WinDLL("psapi", use_last_error=True)
    kernel32.OpenProcess.argtypes = (ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32)
    kernel32.OpenProcess.restype = ctypes.c_void_p
    kernel32.CloseHandle.argtypes = (ctypes.c_void_p,)
    kernel32.CloseHandle.restype = ctypes.c_int
    dbghelp.MiniDumpWriteDump.argtypes = (ctypes.c_void_p, ctypes.c_uint32, ctypes.c_void_p, ctypes.c_uint32,
                                          ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p)
    dbghelp.MiniDumpWriteDump.restype = ctypes.c_int
    handle = kernel32.OpenProcess(0x0450, False, int(pid))  # QUERY_INFORMATION | VM_READ | DUP_HANDLE
    if not handle:
        raise PermissionError(f"OpenProcess failed for PID {pid}: {ctypes.get_last_error()}")
    psapi.GetProcessMemoryInfo.argtypes = (ctypes.c_void_p, ctypes.POINTER(_PMCEX), ctypes.c_uint32)
    psapi.GetProcessMemoryInfo.restype = ctypes.c_int
    counters = _PMCEX(); counters.cb = ctypes.sizeof(counters)
    private_usage = 0
    if psapi.GetProcessMemoryInfo(handle, ctypes.byref(counters), counters.cb):
        private_usage = int(counters.PrivateUsage)
    try:
        free_bytes = int(shutil.disk_usage(destination.parent).free)
    except Exception:
        kernel32.CloseHandle(handle)
        raise
    required_bytes = private_usage + (512 << 20)
    if private_usage and free_bytes < required_bytes:
        kernel32.CloseHandle(handle)
        raise OSError(f"insufficient dump storage: required={required_bytes} free={free_bytes}")
    fd = -1; part = destination.with_name(destination.name + ".part")
    try:
        fd = os.open(str(part), os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
        import msvcrt
        file_handle = msvcrt.get_osfhandle(fd)
        flags = 0x00000002 | 0x00000004 | 0x00000800 | 0x00001000 | 0x00020000
        ok = dbghelp.MiniDumpWriteDump(handle, int(pid), file_handle, flags, None, None, None)
        if not ok:
            raise OSError(f"MiniDumpWriteDump failed: {ctypes.get_last_error()}")
        os.close(fd); fd = -1
        os.replace(part, destination)
    except Exception:
        part.unlink(missing_ok=True)
        raise
    finally:
        if fd >= 0:
            os.close(fd)
        kernel32.CloseHandle(handle)
    if not destination.is_file() or destination.stat().st_size <= 0:
        destination.unlink(missing_ok=True)
        raise RuntimeError("full memory dump is empty")
    return {"path": str(destination), "size": destination.stat().st_size,
            "private_usage": private_usage, "required_free_bytes": required_bytes, "free_bytes_before": free_bytes,
            "dump_flags": "FullMemory|HandleData|FullMemoryInfo|ThreadInfo|IgnoreInaccessibleMemory"}


def _finalize_raw_blend(raw_path: Path, destination: Path) -> dict[str, Any]:
    """Load engine output in Blender, compressed-save, then create-only promote."""
    raw_path = raw_path.resolve(); destination = destination.resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise FileExistsError(f"destination already exists: {destination}")
    if not raw_path.is_file() or raw_path.stat().st_size <= 0:
        raise RuntimeError("raw reconstruction is missing or empty")
    _progress("finalize", 5)
    bpy = _bpy()
    opened = bpy.ops.wm.open_mainfile('EXEC_DEFAULT', filepath=str(raw_path), load_ui=False)
    if 'FINISHED' not in set(opened):
        raise RuntimeError(f"Blender rejected reconstructed raw file: {opened}")
    if os.path.normcase(os.path.abspath(str(bpy.data.filepath))) != os.path.normcase(os.path.abspath(str(raw_path))):
        raise RuntimeError("Blender opened a different path than the reconstructed raw file")
    counts = {name: len(getattr(bpy.data, name, ())) for name in
              ("objects", "meshes", "materials", "images", "actions", "collections")}
    attribute_mismatches = 0
    for mesh in bpy.data.meshes:
        domains = {"POINT": len(mesh.vertices), "EDGE": len(mesh.edges),
                   "FACE": len(mesh.polygons), "CORNER": len(mesh.loops)}
        for uv in mesh.uv_layers:
            if len(uv.uv) != len(mesh.loops):
                attribute_mismatches += 1
        for attribute in mesh.attributes:
            expected = domains.get(attribute.domain)
            if expected is not None and len(attribute.data) != expected:
                attribute_mismatches += 1
    packed = [image for image in bpy.data.images if image.packed_file]
    integrity = {"counts": counts, "attribute_mismatches": attribute_mismatches,
                 "packed_images": len(packed),
                 "nonempty_packed_images": sum(1 for image in packed if image.packed_file.size > 0),
                 "total_vertices": sum(len(mesh.vertices) for mesh in bpy.data.meshes),
                 "total_polygons": sum(len(mesh.polygons) for mesh in bpy.data.meshes),
                 "edit_mode_objects": [obj.name for obj in bpy.data.objects if obj.mode != "OBJECT"]}
    _progress("finalize", 60)
    stage = destination.with_name(f".sfstage-{uuid.uuid4().hex}.blend")
    try:
        # relative_remap=False keeps every path exactly as the crashed session had it
        saved = bpy.ops.wm.save_as_mainfile('EXEC_DEFAULT', filepath=str(stage), compress=True, copy=True,
                                            relative_remap=False)
        if 'FINISHED' not in set(saved) or not stage.is_file() or stage.stat().st_size <= 0:
            raise RuntimeError(f"Blender finalization failed: {saved}")
        if destination.exists():
            raise FileExistsError(f"destination appeared during finalization: {destination}")
        try:
            os.link(stage, destination)
        except FileExistsError:
            raise
        except OSError:
            # some synced or network folders refuse hard links; the destination is re-checked first
            if destination.exists():
                raise FileExistsError(f"destination appeared during finalization: {destination}")
            os.replace(stage, destination)
    finally:
        stage.unlink(missing_ok=True)
    _progress("finalize", 100)
    return {"destination": str(destination), "destination_size": destination.stat().st_size,
            "destination_sha256": _sha256(destination), "blender_opened_raw": True,
            "blender_compressed_save": True, "create_only_promotion": True,
            "integrity": integrity}


def _new_owned_session() -> Path:
    session = local_work_root() / f"session-{_stamp()}-{uuid.uuid4().hex}"
    session.mkdir(parents=True, exist_ok=False)
    record: dict[str, Any] = {"schema": "smart_file_crash_recovery/session/1", "worker_pid": os.getpid()}
    try:
        # the Blender that started this worker: if it crashes or is killed, the next Blender removes the dump
        controller = int(os.environ.get("SFS_CRASH_CONTROLLER_PID", "0") or 0)
        if controller > 0:
            record["controller_pid"] = controller
            record["controller_started"] = float(os.environ.get("SFS_CRASH_CONTROLLER_STARTED", "0") or 0.0)
            record["worker_started"] = float(_process_details(_win32(), os.getpid()).get("started", 0.0) or 0.0)
    except Exception:
        pass
    (session / ".smart-file-owned-session.json").write_text(json.dumps(record) + "\n", encoding="utf-8")
    return session


def _remove_owned_session(session: str | Path) -> bool:
    path = Path(session).resolve(); root = local_work_root().resolve()
    marker = path / ".smart-file-owned-session.json"
    if path.parent != root or not path.name.startswith("session-") or not marker.is_file():
        return False
    shutil.rmtree(path)
    return True


def _remove_sessions_for_worker(worker_pid: int) -> int:
    if int(worker_pid or 0) <= 0:
        return 0
    root = local_work_root().resolve(); removed = 0
    for path in root.glob("session-*"):
        marker = path / ".smart-file-owned-session.json"
        try:
            record = json.loads(marker.read_text(encoding="utf-8"))
            if record.get("schema") == "smart_file_crash_recovery/session/1" and int(record.get("worker_pid", 0)) == int(worker_pid):
                removed += int(_remove_owned_session(path))
        except Exception:
            continue
    return removed


def _process_alive(pid: int, started: float = 0.0) -> bool:
    """Whether a session's owner still runs. A reused PID is not the owner; an unknown answer keeps the session."""
    pid = int(pid or 0)
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    if os.name != "nt":
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        except Exception:
            pass
        return True
    api = _win32()
    if not api:
        return True
    kernel32 = api["kernel32"]
    wintypes = api["wintypes"]
    handle = kernel32.OpenProcess(0x1000, False, pid)  # QUERY_LIMITED_INFORMATION
    if not handle:
        return ctypes.get_last_error() != 87  # 87: no such process
    try:
        code = wintypes.DWORD(0)
        if kernel32.GetExitCodeProcess(handle, ctypes.byref(code)) and int(code.value) != 259:  # STILL_ACTIVE
            return False
        if float(started or 0.0) > 0.0:
            times = [wintypes.FILETIME() for _ in range(4)]
            if kernel32.GetProcessTimes(handle, *[ctypes.byref(item) for item in times]):
                ticks = (int(times[0].dwHighDateTime) << 32) | int(times[0].dwLowDateTime)
                if ticks and abs((ticks / 1e7 - 11644473600.0) - float(started)) > 2.0:
                    return False
        return True
    finally:
        kernel32.CloseHandle(handle)


def _remove_orphaned_sessions() -> int:
    """Remove dump sessions whose Blender crashed or was killed before it could clean up (never creates folders)."""
    base = os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()
    root = Path(base) / "SmartTools" / "SmartFile" / "CrashRecovery"
    if not root.is_dir():
        return 0
    removed = 0
    for path in root.glob("session-*"):
        try:
            record = json.loads((path / ".smart-file-owned-session.json").read_text(encoding="utf-8"))
            controller = int(record.get("controller_pid", 0) or 0)
            # sessions of this Blender are tracked by its own state; a session without an owner record is kept
            if record.get("schema") != "smart_file_crash_recovery/session/1" or controller <= 0 or controller == os.getpid():
                continue
            if _process_alive(controller, float(record.get("controller_started", 0.0) or 0.0)):
                continue
            if _process_alive(int(record.get("worker_pid", 0) or 0), float(record.get("worker_started", 0.0) or 0.0)):
                continue
            removed += int(_remove_owned_session(path))
        except Exception:
            continue
    return removed


def _record_session_removal(payload: dict[str, Any], session: str | Path) -> None:
    try:
        payload["owned_session_removed"] = _remove_owned_session(session)
    except Exception as exc:
        payload["owned_session_removed"] = False
        payload["cleanup_error"] = f"{type(exc).__name__}: {exc}"
        payload["status"] = "FAIL"


def _owned_chain_paths(destination: Path) -> tuple[Path, Path, Path, Path]:
    del destination
    session = _new_owned_session()
    return session, session / "process.full.dmp", session / "recovered_raw.blend", session / "steps.json"


def _error_code(exc: BaseException) -> str:
    text = str(exc)
    if isinstance(exc, PermissionError):
        # OpenProcess error 87: the process is gone
        return "GONE" if text.rstrip().endswith(": 87") else "ACCESS"
    if "insufficient dump storage" in text:
        return "DISK"
    if isinstance(exc, FileExistsError):
        return "EXISTS"
    if "returned 3" in text:
        return "NO_UNDO"
    return "ERROR"


def _engine_summary(result: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in (result or {}).items() if key not in {"steps", "original_report"}}


def _write_report(out_json: str, payload: dict[str, Any]) -> None:
    path = Path(out_json)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _record_failure(payload: dict[str, Any], exc: BaseException) -> None:
    payload["status"] = "FAIL"
    payload["error"] = f"{type(exc).__name__}: {exc}"
    payload["error_code"] = _error_code(exc)


def _best_blend_path(steps: list[dict[str, Any]]) -> str:
    if not steps:
        return ""
    best = min(steps, key=lambda item: int(item.get("rank", 0) or 0))
    return str(best.get("blend_path", "") or "")


def _remove_session_keep_pass(payload: dict[str, Any], session) -> None:
    """Removing scratch never turns a saved recovery into a failure."""
    was_pass = payload.get("status") == "PASS"
    _record_session_removal(payload, session)
    if was_pass:
        payload["status"] = "PASS"


def command_dump_analyze(pid: int, out_json: str) -> int:
    payload: dict[str, Any] = {"schema": SCHEMA_ORIGINAL_CHAIN, "operation": "analyze", "status": "FAIL", "error": ""}
    session = None
    try:
        session, dump, _raw, steps = _owned_chain_paths(Path(out_json))
        _progress("dump", 0)
        payload["dump"] = _write_full_memory_dump(pid, dump)
        _progress("dump", 100)
        result = _engine_module().analyze_dump(str(dump), str(steps))
        found = list(result.get("steps") or [])
        payload.update({"engine": _engine_summary(result), "steps": found, "dump_path": str(dump),
                        "session_path": str(session), "blend_path": _best_blend_path(found)})
        if found:
            payload["status"] = "PASS"
        else:
            payload["error"] = "no undo memfile chain found"
            payload["error_code"] = "NO_UNDO"
    except Exception as exc:
        _record_failure(payload, exc)
    if session is not None and payload.get("status") != "PASS":
        _record_session_removal(payload, session)
    _write_report(out_json, payload)
    return 0 if payload["status"] == "PASS" else 3


def command_dump_rescue(pid: int, destination: str, out_json: str) -> int:
    payload: dict[str, Any] = {"schema": SCHEMA_ORIGINAL_CHAIN, "operation": "latest", "status": "FAIL", "error": ""}
    session = None
    try:
        final = Path(destination).resolve()
        session, dump, raw, steps = _owned_chain_paths(final)
        _progress("dump", 0)
        payload["dump"] = _write_full_memory_dump(pid, dump)
        _progress("dump", 100)
        engine = _engine_module().rescue_raw(str(dump), str(raw), str(steps))
        finalized = _finalize_raw_blend(raw, final)
        payload.update({"engine": _engine_summary(engine), "steps": list(engine.get("steps") or []),
                        "dump_path": str(dump), "raw_path": str(raw), **finalized, "status": "PASS",
                        "warning_unresolved_references": bool(engine.get("warning"))})
    except Exception as exc:
        _record_failure(payload, exc)
    finally:
        if session is not None:
            _remove_session_keep_pass(payload, session)
    _write_report(out_json, payload)
    return 0 if payload["status"] == "PASS" else 3


def command_dump_extract(dump_path: str, step_index: int, destination: str, out_json: str) -> int:
    payload: dict[str, Any] = {"schema": SCHEMA_ORIGINAL_CHAIN, "operation": "point", "status": "FAIL", "error": ""}
    session = None
    try:
        final = Path(destination).resolve()
        session = _new_owned_session()
        raw = session / "recovered_raw.blend"
        engine = _engine_module().extract_raw(dump_path, int(step_index), str(raw))
        finalized = _finalize_raw_blend(raw, final)
        payload.update({"engine": _engine_summary(engine), "selected_step_index": int(step_index),
                        "dump_path": str(dump_path), "raw_path": str(raw), **finalized, "status": "PASS",
                        "warning_unresolved_references": bool(engine.get("warning"))})
    except Exception as exc:
        _record_failure(payload, exc)
    finally:
        if session is not None:
            _remove_session_keep_pass(payload, session)
    _write_report(out_json, payload)
    return 0 if payload["status"] == "PASS" else 3


def command_dump_file_analyze(dump_path: str, out_json: str) -> int:
    """Analyze an existing dump file chosen by the user; the dump itself is never moved or deleted."""
    payload: dict[str, Any] = {"schema": SCHEMA_ORIGINAL_CHAIN, "operation": "analyze_file", "status": "FAIL", "error": ""}
    session = None
    try:
        source = Path(dump_path).resolve()
        if not source.is_file():
            raise FileNotFoundError(f"dump file not found: {source}")
        session = _new_owned_session()
        steps_json = session / "steps.json"
        result = _engine_module().analyze_dump(str(source), str(steps_json))
        found = list(result.get("steps") or [])
        payload.update({"engine": _engine_summary(result), "steps": found, "dump_path": str(source),
                        "session_path": str(session), "blend_path": _best_blend_path(found)})
        if found:
            payload["status"] = "PASS"
        else:
            payload["error"] = "no undo memfile chain found"
            payload["error_code"] = "NO_UNDO"
    except Exception as exc:
        _record_failure(payload, exc)
    if session is not None and payload.get("status") != "PASS":
        _record_session_removal(payload, session)
    _write_report(out_json, payload)
    return 0 if payload["status"] == "PASS" else 3


def _engine_module():
    name = "smart_file_crash_recovery_engine_runtime"
    path = Path(__file__).with_name("crash_recovery_original_adapter.py")
    mod = sys.modules.get(name)
    if mod is not None:
        return mod
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Smart File deep recovery engine could not be loaded")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def local_work_root() -> Path:
    base = os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()
    root = Path(base) / "SmartTools" / "SmartFile" / "CrashRecovery"
    root.mkdir(parents=True, exist_ok=True)
    return root


def cleanup_abandoned_scratch(*, max_age_seconds: int = 6 * 60 * 60) -> dict[str, Any]:
    state: dict[str, Any] = {}
    try:
        bpy = _bpy()
        raw_state = bpy.app.driver_namespace.get(STATE_KEY)
        if not isinstance(raw_state, dict):
            raw_state = _STATE_SURVIVOR.get("state")
        if isinstance(raw_state, dict):
            state = raw_state
    except Exception:
        state = {}
    proc = state.get("process") if isinstance(state, dict) else None
    try:
        if proc is not None and proc.poll() is None:
            return {"status": "SKIP_ACTIVE_WORKER", "removed": 0, "bytes": 0}
    except Exception:
        return {"status": "SKIP_UNKNOWN_WORKER", "removed": 0, "bytes": 0}
    root = local_work_root().resolve()
    now = time.time()
    removed = 0
    bytes_removed = 0
    active_parts = _active_lease_part_paths(root, now)
    for path in root.rglob("*.part"):
        try:
            resolved = path.resolve()
            if root not in resolved.parents:
                continue
            if os.path.normcase(str(resolved)) in active_parts:
                continue
            if now - resolved.stat().st_mtime < int(max_age_seconds):
                continue
            size = resolved.stat().st_size
            resolved.unlink()
            removed += 1
            bytes_removed += int(size)
        except Exception:
            pass
    return {"status": "PASS", "removed": removed, "bytes": bytes_removed, "root": str(root)}


def _worker_token() -> str:
    return hashlib.sha256(f"{os.getpid()}:{time.time_ns()}:{id(object())}".encode("ascii")).hexdigest().upper()


def _lease_path_for(report: Path) -> Path:
    return report.with_suffix(report.suffix + ".lease.json")


def _write_worker_lease(path: Path, *, token: str, part_path: str = "", worker_pid: int = 0) -> None:
    payload = {
        "schema": LEASE_SCHEMA,
        "owner": "SmartFile",
        "pid": int(worker_pid or os.getpid()),
        "controller_pid": os.getpid(),
        "token": token,
        "updated": time.time(),
        "part_path": part_path,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, path)


def _refresh_worker_lease(state: dict[str, Any]) -> bool:
    lease_text = str(state.get("lease", "") or "")
    token = str(state.get("token", "") or "")
    if not lease_text or not token:
        return False
    part_path = str(state.get("part_path", "") or "")
    worker_pid = int(state.get("worker_pid", 0) or 0)
    controller_pid = int(state.get("controller_pid", 0) or 0)
    if worker_pid <= 0:
        proc = state.get("process")
        worker_pid = int(getattr(proc, "pid", 0) or 0)
    if controller_pid <= 0:
        controller_pid = os.getpid()
    payload = {
        "schema": LEASE_SCHEMA,
        "owner": "SmartFile",
        "pid": worker_pid,
        "controller_pid": controller_pid,
        "token": token,
        "updated": time.time(),
        "part_path": part_path,
    }
    path = Path(lease_text)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, path)
    return True


def _clear_worker_lease(state: dict[str, Any]) -> bool:
    lease_text = str(state.get("lease", "") or "")
    if not lease_text:
        return False
    path = Path(lease_text)
    try:
        if path.exists():
            path.unlink()
        return True
    except Exception:
        return False


def _active_lease_part_paths(root: Path, now: float | None = None) -> set[str]:
    clock = time.time() if now is None else float(now)
    active: set[str] = set()
    for lease in root.rglob("*.lease.json"):
        try:
            data = json.loads(lease.read_text(encoding="utf-8"))
            if data.get("schema") != LEASE_SCHEMA:
                continue
            if str(data.get("owner", "") or "") != "SmartFile":
                continue
            if int(data.get("pid", 0) or 0) <= 0 or int(data.get("controller_pid", 0) or 0) <= 0:
                continue
            if not str(data.get("token", "") or ""):
                continue
            updated = float(data.get("updated", 0) or 0)
            if clock - updated > LEASE_TTL_SECONDS:
                continue
            part = str(data.get("part_path", "") or "")
            if not part:
                continue
            resolved = Path(part).resolve()
            if root not in resolved.parents:
                continue
            active.add(os.path.normcase(str(resolved)))
        except Exception:
            pass
    return active


def recovered_path_for(seed_path: str = "", scene_name: str = "", home_dir: str = "") -> str:
    """<original folder>/<scene>_recovered_<stamp>.blend, as the original tool names it."""
    folder: Path | None = None
    seed = str(seed_path or "")
    options = [str(home_dir or "")]
    if seed.lower().endswith(".blend"):
        options.append(str(Path(seed).parent))
    for raw in options:
        if not raw:
            continue
        try:
            path = Path(raw)
            if path.is_dir():
                folder = path
                break
        except Exception:
            continue
    if folder is None:
        folder = local_work_root() / "Recovered"
    stem = Path(scene_name).stem if scene_name else (Path(seed).stem if seed else "")
    base = f"{_file_stem(stem)}_recovered_{_stamp()}"
    candidate = folder / f"{base}.blend"
    counter = 2
    while candidate.exists():
        candidate = folder / f"{base}_{counter}.blend"
        counter += 1
    return str(candidate)


def _bpy():
    import bpy  # type: ignore
    return bpy


# Opening a file clears bpy.app.driver_namespace. The running worker, the dump session and the recovery points
# must outlive that (the recovered file is opened right here), so this module keeps the same dict and re-publishes it.
_STATE_SURVIVOR: dict[str, Any] = {}


def _state() -> dict[str, Any]:
    bpy = _bpy()
    ns = bpy.app.driver_namespace
    state = ns.get(STATE_KEY)
    if not isinstance(state, dict):
        state = _STATE_SURVIVOR.get("state")
        if not isinstance(state, dict):
            state = {"process": None, "owner": "SmartFile", "mode": "", "report": "", "started": 0.0, "stdout": "", "stderr": ""}
        ns[STATE_KEY] = state
    _STATE_SURVIVOR["state"] = state
    return state


def _scene_settings(context=None):
    from .context_utils import scene_settings
    return scene_settings(context)


def _iter_scene_settings() -> list[Any]:
    try:
        bpy = _bpy()
        scenes = getattr(getattr(bpy, "data", None), "scenes", None)
        if scenes is None:
            return []
        out: list[Any] = []
        for scene in scenes:
            settings = getattr(scene, "uhm_settings", None)
            if settings is not None:
                out.append(settings)
        return out
    except Exception:
        return []


def _reset_scene_runtime_state(st) -> bool:
    if st is None:
        return False
    try:
        candidates = getattr(st, "crash_recovery_candidates", None)
        if hasattr(candidates, "clear"):
            candidates.clear()
        st.crash_recovery_active_index = -1
        st.crash_recovery_dump_file = ""
        st.crash_recovery_status = "Ready"
        st.crash_recovery_progress = 0
        st.crash_recovery_last_report = ""
        st.crash_recovery_last_error = ""
        st.crash_recovery_last_destination = ""
        return True
    except Exception:
        return False


def _reset_all_scene_runtime_state() -> bool:
    ok = True
    for settings in _iter_scene_settings():
        if not _reset_scene_runtime_state(settings):
            ok = False
    return ok


def _handler_records() -> list[dict[str, Any]]:
    bpy = _bpy()
    namespace = getattr(getattr(bpy, "app", None), "driver_namespace", None)
    if not isinstance(namespace, dict):
        raise RuntimeError("bpy.app.driver_namespace is unavailable")
    records = namespace.get(HANDLERS_KEY)
    if not isinstance(records, list):
        records = []
        namespace[HANDLERS_KEY] = records
    return records


def _remove_exact_handler(collection, callback) -> bool:
    removed = False
    try:
        while any(item is callback for item in tuple(collection or ())):
            collection.remove(callback)
            removed = True
    except Exception:
        return False
    return removed or not any(item is callback for item in tuple(collection or ()))


def _owned_handler_match(callback, expected_name: str) -> bool:
    if not callable(callback):
        return False
    if str(getattr(callback, "__name__", "") or "") != str(expected_name or ""):
        return False
    module_name = str(getattr(callback, "__module__", "") or "")
    if module_name not in {__name__, ""} and not module_name.endswith(".crash_recovery"):
        return False
    code = getattr(callback, "__code__", None)
    filename = str(getattr(code, "co_filename", "") or "")
    if not filename:
        return False
    try:
        normalized = os.path.normcase(str(Path(filename).resolve()))
    except Exception:
        normalized = os.path.normcase(filename)
    return Path(normalized).name == _THIS_CODE_BASENAME


def _remove_owned_handler_fallback(collection, expected_name: str) -> bool:
    removed = False
    try:
        for callback in tuple(collection or ()):
            if _owned_handler_match(callback, expected_name):
                collection.remove(callback)
                removed = True
    except Exception:
        return False
    return removed or not any(
        _owned_handler_match(callback, expected_name)
        for callback in tuple(collection or ())
    )


def _remove_stale_owned_handlers(handlers) -> bool:
    ok = True
    save_pre = getattr(handlers, "save_pre", None)
    load_post = getattr(handlers, "load_post", None)
    if save_pre is not None:
        ok = _remove_owned_handler_fallback(save_pre, "_save_pre_reset_runtime") and ok
    if load_post is not None:
        ok = _remove_owned_handler_fallback(load_post, "_load_post_reset_runtime") and ok
    return ok


def _append_exact_handler(collection, callback, role: str) -> bool:
    records = _handler_records()
    if any(item is callback for item in tuple(collection or ())):
        if not any(record.get("callback") is callback for record in records):
            records.append({"collection": collection, "callback": callback, "role": role})
        return True
    collection.append(callback)
    if not any(item is callback for item in tuple(collection or ())):
        return False
    records.append({"collection": collection, "callback": callback, "role": role})
    return True


@persistent
def _save_pre_reset_runtime(_dummy=None):
    try:
        _reset_all_scene_runtime_state()
    except Exception:
        return


@persistent
def _load_post_reset_runtime(_dummy=None):
    try:
        _reset_all_scene_runtime_state()
    except Exception:
        return


def register_owned_resources(context=None) -> bool:
    del context
    try:
        bpy = _bpy()
        handlers = getattr(getattr(bpy, "app", None), "handlers", None)
        if handlers is None:
            raise RuntimeError("bpy.app.handlers is unavailable")
        if not _remove_stale_owned_handlers(handlers):
            raise RuntimeError("crash recovery stale handler cleanup failed")
        if not _append_exact_handler(getattr(handlers, "save_pre", None), _save_pre_reset_runtime, "save_pre"):
            raise RuntimeError("crash recovery save_pre handler registration failed")
        if not _append_exact_handler(getattr(handlers, "load_post", None), _load_post_reset_runtime, "load_post"):
            raise RuntimeError("crash recovery load_post handler registration failed")
        try:
            _remove_orphaned_sessions()
        except Exception:
            pass
        return True
    except Exception:
        return False


def _python_or_blender_command(*, require_blender: bool = False) -> list[str]:
    try:
        bpy = _bpy()
        blender = str(getattr(getattr(bpy, "app", None), "binary_path", "") or "")
    except Exception:
        blender = ""
    if not blender and str(sys.executable or "").lower().endswith("blender.exe"):
        blender = str(sys.executable)
    blender_command = [blender, "--background", "--factory-startup", "--disable-autoexec", "-noaudio",
                       "--python", __file__, "--"]
    if require_blender:
        if not blender or not Path(blender).is_file():
            raise RuntimeError("Blender executable is required for recovery finalization")
        return blender_command
    exe = str(sys.executable or "")
    if exe and Path(exe).is_file() and "blender" not in Path(exe).name.lower():
        # Blender's bundled Python, isolated from user site-packages and PYTHON* variables
        return [exe, "-I", "-X", "utf8", "-B", __file__]
    if blender and Path(blender).is_file():
        return blender_command
    raise RuntimeError("no Python or Blender executable is available for the recovery worker")


def _register_poll_timer() -> None:
    bpy = _bpy()
    ns = bpy.app.driver_namespace
    timer = ns.get(TIMER_KEY)
    try:
        if timer is not None and bpy.app.timers.is_registered(timer):
            return
        if bpy.app.timers.is_registered(_poll_timer):
            # opening a file cleared the key, but the persistent timer itself is still running
            ns[TIMER_KEY] = _poll_timer
            return
    except Exception:
        pass
    ns[TIMER_KEY] = _poll_timer
    bpy.app.timers.register(_poll_timer, first_interval=0.25, persistent=True)


def _load_report(path: str) -> dict[str, Any]:
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception as exc:
        return {"status": "FAIL", "error": f"{type(exc).__name__}: {exc}"}


def _size_text(size: int) -> str:
    value = float(max(0, int(size or 0)))
    if value < 1024.0:
        return f"{value:.0f} B"
    for unit in ("KB", "MB", "GB"):
        value /= 1024.0
        if value < 1024.0 or unit == "GB":
            return f"{value:.1f} {unit}"
    return f"{value:.1f} GB"


def _label_text(label: str) -> str:
    return _ui_text(label, _LABEL_JA.get(label, label))


def _candidate_title(row: dict[str, Any]) -> str:
    label = _label_text(str(row.get("label", "") or ""))
    path = str(row.get("path", "") or "")
    if path.lower().startswith("pid:"):
        name = str(row.get("scene_name", "") or row.get("title_name", "") or "") or _ui_text("Untitled", "無題")
        head = f"{label}: {name} (PID {int(row.get('pid', 0) or 0)})"
    else:
        head = f"{label}: {Path(path).name}"
    parts = [("★ " if row.get("recommended") else "") + head]
    if row.get("mtime_text"):
        parts.append(str(row.get("mtime_text")))
    if int(row.get("size", 0) or 0) > 0:
        parts.append(_size_text(int(row.get("size", 0) or 0)))
    text = "  ".join(parts)
    if row.get("suspect_small"):
        text += "  (!)"
    return text


def _set_candidates(context, rows: list[dict[str, Any]]) -> int:
    st = _scene_settings(context)
    if st is None:
        return 0
    st.crash_recovery_candidates.clear()
    active = -1
    for row in rows:
        item = st.crash_recovery_candidates.add()
        item.name = _candidate_title(row)
        item.scene_name = str(row.get("scene_name", "") or "")
        item.path = str(row.get("path", "") or "")
        item.label = str(row.get("label", "") or "")
        item.kind = str(row.get("kind", "") or "")
        item.source_pid = max(0, int(row.get("pid", 0) or 0))
        item.crash_signal = str(row.get("crash_signal", "") or "")
        item.mtime_text = str(row.get("mtime_text", "") or "")
        size = max(0, int(row.get("size", 0) or 0))
        item.size = min(size, 2 ** 31 - 1)
        item.size_mb = size / 1048576.0
        item.recommended = bool(row.get("recommended", False))
        item.suspect_small = bool(row.get("suspect_small", False))
        item.valid_blend_header = bool(row.get("valid_blend_header", False))
        item.blend_path = str(row.get("blend_path", "") or "")
        item.home_dir = str(row.get("home_dir", "") or "")
        if item.recommended and active < 0:
            active = len(st.crash_recovery_candidates) - 1
    if active < 0 and len(st.crash_recovery_candidates):
        active = 0
    st.crash_recovery_active_index = active
    return len(st.crash_recovery_candidates)


def _fill_candidates(context, report: dict[str, Any]) -> tuple[int, str]:
    rows: list[dict[str, Any]] = []
    scenes = report.get("scenes") if isinstance(report, dict) else None
    for scene in scenes if isinstance(scenes, list) else []:
        for candidate in scene.get("candidates") or []:
            row = dict(candidate)
            row.setdefault("scene_name", str(scene.get("scene_name", "") or ""))
            row.setdefault("home_dir", str(scene.get("home_dir", "") or ""))
            row.setdefault("blend_path", str(scene.get("scene_path", "") or ""))
            rows.append(row)
    count = _set_candidates(context, rows)
    if count:
        text = _ui_text(f"{count} saved files found. The one marked with a star is recommended.",
                        f"保存済みファイルが {count} 件見つかりました。★ がおすすめです。")
    else:
        text = _ui_text("No saved files were found.", "保存済みファイルは見つかりませんでした。")
    return count, text


def _cleanup_worker_runtime(state: dict[str, Any]) -> None:
    value = str(state.pop("runtime_root", "") or "")
    if not value:
        return
    path = Path(value).resolve(); root = local_work_root().resolve()
    if path.parent == root and path.name.startswith("runtime-"):
        shutil.rmtree(path, ignore_errors=True)


def _set_if_changed(owner, name: str, value) -> None:
    try:
        if getattr(owner, name) != value:
            setattr(owner, name, value)
    except Exception:
        pass


def _settings_for_status(context=None):
    st = None
    try:
        st = _scene_settings(context)
    except Exception:
        st = None
    if st is None:
        try:
            st = _scene_settings(_bpy().context)
        except Exception:
            st = None
    return st


def _redraw() -> None:
    try:
        for window in _bpy().context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
    except Exception:
        pass


def _apply_status(context=None, *, text: str | None = None, progress: int | None = None, error: str | None = None,
                  destination: str | None = None, report: str | None = None) -> None:
    """Write the status fields; after a file load the current scene is looked up again."""
    st = _settings_for_status(context)
    if st is None:
        return
    if text is not None:
        _set_if_changed(st, "crash_recovery_status", str(text))
    if progress is not None:
        _set_if_changed(st, "crash_recovery_progress", max(0, min(100, int(progress))))
    if error is not None:
        _set_if_changed(st, "crash_recovery_last_error", str(error))
    if destination is not None:
        _set_if_changed(st, "crash_recovery_last_destination", str(destination))
    if report is not None:
        _set_if_changed(st, "crash_recovery_last_report", str(report))
    _redraw()


def _write_json(path: str, payload: dict[str, Any]) -> None:
    if not path:
        return
    try:
        Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    except Exception:
        pass


def _error_message(report: dict[str, Any]) -> str:
    code = str(report.get("error_code", "") or "")
    if not code:
        error = str(report.get("error", "") or "")
        if error.startswith("FileExistsError"):
            code = "EXISTS"
        elif error.startswith("PermissionError"):
            code = "ACCESS"
        else:
            code = "ERROR"
    en, ja = _ERROR_TEXT.get(code, _ERROR_TEXT["ERROR"])
    return _ui_text(en, ja)


def _done_text(warning: bool, opened: bool) -> str:
    if opened and warning:
        return _ui_text("Recovered and opened. Some references could not be restored; check the scene.",
                        "復旧して開きました。一部の参照は戻せなかったので、シーンを確かめてください。")
    if opened:
        return _ui_text("Recovered and opened.", "復旧して開きました。")
    return _ui_text("Recovered.", "復旧しました。")


def _remove_worker_logs(state: dict[str, Any]) -> None:
    for key in ("stdout", "stderr"):
        value = str(state.get(key, "") or "")
        if not value:
            continue
        try:
            Path(value).unlink(missing_ok=True)
        except Exception:
            pass


def _finish_state(context=None) -> None:
    state = _state()
    report_path = str(state.get("report", "") or "")
    report = _load_report(report_path)
    status = str(report.get("status", "FAIL") or "FAIL")
    operation = str(report.get("operation", "") or "")
    target = dict(state.get("target") or {})
    open_after = bool(state.get("open_after_success"))
    state["process"] = None
    state["mode"] = ""
    state["open_after_success"] = False
    _cleanup_worker_runtime(state)
    if status == "PASS":
        _remove_worker_logs(state)
    if str(report.get("schema", "")) == SCHEMA_SCAN:
        _count, text = _fill_candidates(context, report)
        _apply_status(context, text=text, progress=100, error="", report=report_path)
        return
    if operation in {"analyze", "analyze_file"}:
        if status == "PASS":
            old_session = str(state.get("recovery_session_path", "") or "")
            if old_session and old_session != str(report.get("session_path", "")):
                try:
                    _remove_owned_session(old_session)
                except Exception:
                    pass
            points = list(report.get("steps") or [])
            state["recovery_points"] = points
            state["recovery_dump_path"] = str(report.get("dump_path", ""))
            state["recovery_session_path"] = str(report.get("session_path", ""))
            if not target.get("blend_path") and report.get("blend_path"):
                target["blend_path"] = str(report.get("blend_path"))
            state["recovery_target"] = target
            text = _ui_text(f"{len(points)} recovery points found. The newest is at the top.",
                            f"復旧ポイントが {len(points)} 件見つかりました。いちばん上が最新です。")
            _apply_status(context, text=text, progress=100, error="", report=report_path)
        else:
            _apply_status(context, text=_error_message(report), progress=0,
                          error=str(report.get("error", "") or ""), report=report_path)
        return
    if status != "PASS":
        _apply_status(context, text=_error_message(report), progress=0,
                      error=str(report.get("error", "") or ""), report=report_path)
        return
    destination = str(report.get("destination", "") or "")
    warning = bool(report.get("warning_unresolved_references"))
    if not (open_after and destination):
        _apply_status(context, text=_done_text(warning, False), progress=100, error="", destination=destination,
                      report=report_path)
        return
    open_payload = _open_recovered_mainfile(context, destination)
    report["open_mainfile"] = open_payload
    open_status = str(open_payload.get("status", "FAIL"))
    if open_status == "PENDING_CONFIRMATION":
        report["status"] = "OPEN_PENDING_CONFIRMATION"
        state["pending_open_path"] = destination
        state["pending_open_report"] = report_path
        state["pending_open_started"] = time.time()
        state["pending_open_warning"] = warning
        _write_json(report_path, report)
        _apply_status(None, text=_ui_text("The recovered file is saved. Answer Blender's prompt to open it.",
                                          "復旧したファイルを保存しました。Blender の確認に答えると開きます。"),
                      progress=100, error="", destination=destination, report=report_path)
        return
    _write_json(report_path, report)
    # the scene may have been replaced by the recovered file: look the settings up again
    if open_status == "PASS":
        _apply_status(None, text=_done_text(warning, True), progress=100, error="", destination=destination,
                      report=report_path)
    else:
        _apply_status(None, text=_ui_text("The recovered file is saved but could not be opened here. Open it from its folder.",
                                          "復旧したファイルは保存しましたが、ここでは開けませんでした。フォルダーから開いてください。"),
                      progress=100, error=str(open_payload.get("error", "") or ""), destination=destination,
                      report=report_path)


def _poll_pending_open(state: dict[str, Any]) -> float | None:
    path = str(state.get("pending_open_path", "") or "")
    if not path:
        return None
    report_path = str(state.get("pending_open_report", "") or "")
    warning = bool(state.get("pending_open_warning", False))
    try:
        actual = str(getattr(getattr(_bpy(), "data", None), "filepath", "") or "")
    except Exception:
        actual = ""
    matched = _same_path(actual, path)
    try:
        elapsed = time.time() - float(state.get("pending_open_started", 0.0) or 0.0)
    except Exception:
        elapsed = 0.0
    if not matched and elapsed < 120.0:
        return 0.5
    for key in ("pending_open_path", "pending_open_report", "pending_open_started", "pending_open_warning"):
        state.pop(key, None)
    report = _load_report(report_path)
    if matched:
        report["status"] = "PASS"
        report["open_mainfile"] = {"status": "PASS", "requested_path": path, "filepath_after": actual,
                                   "confirmation": "BLENDER_BUILTIN_CONFIRMED"}
        _apply_status(None, text=_done_text(warning, True), progress=100, error="", destination=path,
                      report=report_path)
    else:
        report["status"] = "OPEN_NOT_CONFIRMED"
        report["open_mainfile"] = {"status": "CANCELLED_OR_TIMEOUT", "requested_path": path, "filepath_after": actual}
        _apply_status(None, text=_ui_text("The recovered file is saved but was not opened. Open it from its folder.",
                                          "復旧したファイルは保存しましたが、開いていません。フォルダーから開いてください。"),
                      progress=100, error="", destination=path, report=report_path)
    _write_json(report_path, report)
    return None


def _read_progress(path: str) -> tuple[str, int] | None:
    """Last progress line in the worker's stdout (only its final 8 KB are read)."""
    if not path:
        return None
    try:
        with open(path, "rb") as handle:
            handle.seek(0, os.SEEK_END)
            size = handle.tell()
            handle.seek(max(0, size - 8192))
            tail = handle.read().decode("utf-8", "replace")
    except Exception:
        return None
    for line in reversed(tail.splitlines()):
        if not line.startswith(PROGRESS_PREFIX):
            continue
        parts = line[len(PROGRESS_PREFIX):].split(" ", 2)
        if len(parts) < 2:
            continue
        try:
            return parts[0], int(float(parts[1]))
        except ValueError:
            continue
    return None


def _overall_progress(mode: str, stage: str, pct: int) -> int | None:
    phase = "engine" if stage in _ENGINE_STAGES else stage
    span = _PROGRESS_RANGES.get(mode, {}).get(phase)
    if span is None:
        return None
    low, high = span
    return int(low + (high - low) * max(0, min(100, int(pct))) / 100.0)


def _update_running_status(state: dict[str, Any]) -> None:
    found = _read_progress(str(state.get("stdout", "") or ""))
    if not found:
        return
    stage, pct = found
    overall = _overall_progress(str(state.get("mode", "") or ""), stage, pct)
    if overall is None:
        return
    overall = max(int(state.get("progress", 0) or 0), overall)
    state["progress"] = overall
    en, ja = _STAGE_TEXT.get(stage, _STAGE_TEXT["scan"])
    _apply_status(None, text=_ui_text(en, ja), progress=overall)


def _poll_timer():
    try:
        state = _state()
        proc = state.get("process")
        if proc is None:
            return _poll_pending_open(state)
        code = proc.poll()
        if code is None:
            try:
                _refresh_worker_lease(state)
            except Exception:
                pass
            try:
                _update_running_status(state)
            except Exception:
                pass
            return 0.5
        state["returncode"] = int(code)
        try:
            _clear_worker_lease(state)
        except Exception:
            pass
        _finish_state(getattr(_bpy(), "context", None))
        return 0.5 if state.get("pending_open_path") else None
    except Exception:
        return None


def _existing_dirs(values: Iterable[Any]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = str(value or "").strip()
        if not text:
            continue
        try:
            path = Path(text)
            if not path.is_dir():
                continue
            key = os.path.normcase(str(path.resolve()))
        except Exception:
            continue
        if key in seen:
            continue
        seen.add(key)
        out.append(str(path))
    return out


def _blender_temp_dirs() -> list[str]:
    """Where Blender writes autosaves, quit.blend and <name>.crash.txt."""
    values: list[Any] = []
    try:
        bpy = _bpy()
        tempdir = str(getattr(bpy.app, "tempdir", "") or "").rstrip("\\/")
        if tempdir:
            values.append(Path(tempdir).parent)
        prefs = getattr(bpy.context, "preferences", None)
        values.append(getattr(getattr(prefs, "filepaths", None), "temporary_directory", ""))
    except Exception:
        pass
    values.extend(os.environ.get(name, "") for name in ("TEMP", "TMP"))
    try:
        values.append(tempfile.gettempdir())
    except Exception:
        pass
    return _existing_dirs(values)


def _config_dirs() -> list[str]:
    values: list[Any] = []
    version = ""
    try:
        bpy = _bpy()
        values.append(bpy.utils.user_resource('CONFIG'))
        version = "%d.%d" % tuple(bpy.app.version[:2])
    except Exception:
        pass
    appdata = os.environ.get("APPDATA", "")
    if appdata and version:
        values.append(Path(appdata) / "Blender Foundation" / "Blender" / version / "config")
    return _existing_dirs(values)


def _history_root(context=None) -> str:
    try:
        from .context_utils import storage_root
        root = str(storage_root(context, create=False) or "")
        return root if root and Path(root).is_dir() else ""
    except Exception:
        return ""


def worker_running() -> bool:
    try:
        proc = _state().get("process")
        return proc is not None and proc.poll() is None
    except Exception:
        return False


def _busy_message() -> str:
    return _ui_text("Wait until the running recovery finishes.", "動いている復旧が終わるまで待ってください。")


def _start_worker(context, mode: str, args: list[str], report_name: str, *, open_after_success: bool = False,
                  target: dict[str, Any] | None = None) -> tuple[bool, str]:
    state = _state()
    proc = state.get("process")
    if proc is not None and proc.poll() is None:
        return False, _busy_message()
    # a new run replaces an unanswered open prompt instead of being refused
    for key in ("pending_open_path", "pending_open_report", "pending_open_started", "pending_open_warning"):
        state.pop(key, None)
    work = local_work_root()
    report = work / report_name
    stdout = work / (report.stem + ".stdout.log")
    stderr = work / (report.stem + ".stderr.log")
    token = _worker_token()
    destination = str(args[-1]) if mode in {"copy", "dump_rescue", "dump_extract"} and len(args) >= 3 else ""
    lease = _lease_path_for(report)
    part_path = (destination + ".part") if destination else ""
    require_blender = mode in {"dump_rescue", "dump_extract"}
    runtime_root = work / f"runtime-{token}"
    try:
        command = _python_or_blender_command(require_blender=require_blender) + list(args) + [str(report)]
        child_env = os.environ.copy()
        child_env.update({"PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1",
                          "SFS_CRASH_LOG_DIRS": os.pathsep.join(_blender_temp_dirs())})
        try:
            _remove_orphaned_sessions()
        except Exception:
            pass
        child_env.update({"SFS_CRASH_CONTROLLER_PID": str(os.getpid()),
                          "SFS_CRASH_CONTROLLER_STARTED": repr(float(_process_details(_win32(), os.getpid()).get("started", 0.0) or 0.0))})
        if require_blender:
            for name in ("config", "scripts", "datafiles", "temp"):
                (runtime_root / name).mkdir(parents=True, exist_ok=True)
            child_env.update({"BLENDER_USER_CONFIG": str(runtime_root / "config"),
                              "BLENDER_USER_SCRIPTS": str(runtime_root / "scripts"),
                              "BLENDER_USER_DATAFILES": str(runtime_root / "datafiles"),
                              "TMP": str(runtime_root / "temp"), "TEMP": str(runtime_root / "temp")})
        creationflags = int(getattr(subprocess, "CREATE_NO_WINDOW", 0)) if os.name == "nt" else 0
        with stdout.open("w", encoding="utf-8") as out, stderr.open("w", encoding="utf-8") as err:
            proc = subprocess.Popen(command, stdout=out, stderr=err, stdin=subprocess.DEVNULL, cwd=str(work),
                                    env=child_env, creationflags=creationflags)
    except Exception as exc:
        shutil.rmtree(runtime_root, ignore_errors=True)
        detail = f"{type(exc).__name__}: {exc}"
        message = _ui_text(f"Crash recovery could not start: {detail}", f"クラッシュ復旧を始められませんでした：{detail}")
        _apply_status(context, text=message, progress=0, error=detail)
        return False, message
    state.update({"process": proc, "mode": mode, "report": str(report), "stdout": str(stdout), "stderr": str(stderr),
                  "started": time.time(), "command": command, "open_after_success": bool(open_after_success),
                  "lease": str(lease), "token": token, "worker_pid": int(getattr(proc, "pid", 0) or 0),
                  "controller_pid": os.getpid(), "part_path": part_path, "progress": 0,
                  "target": dict(target or {}), "runtime_root": str(runtime_root) if require_blender else ""})
    try:
        _refresh_worker_lease(state)
    except Exception:
        pass
    en, ja = _START_TEXT.get(mode, _START_TEXT["copy"])
    _apply_status(context, text=_ui_text(en, ja), progress=1, error="", report=str(report))
    _register_poll_timer()
    return True, _ui_text(en, ja)


def refresh_process_targets(context=None) -> tuple[bool, str]:
    """List every other running Blender right away (no worker is needed)."""
    if worker_running():
        return False, _busy_message()
    clear_recovery_points()
    rows = discover_blender_processes()
    count = _set_candidates(context, rows)
    crashed = sum(1 for row in rows if row.get("state") == "crashed")
    if count:
        text = _ui_text(f"{count} other Blender found ({crashed} crashed).",
                        f"ほかの Blender が {count} 件見つかりました（クラッシュ {crashed} 件）。")
    else:
        text = _ui_text("No other Blender was found. Autosaves and backups are under Saved Files.",
                        "ほかの Blender は見つかりませんでした。自動保存やバックアップは「保存済みファイル」で探せます。")
    _apply_status(context, text=text, progress=0, error="")
    return True, text


def start_recovery_points_scan(context=None) -> tuple[bool, str]:
    """Original quick-recovery tab: autosaves, backups and quit.blend on disk."""
    if worker_running():
        return False, _busy_message()
    clear_recovery_points()
    args = ["scan"]
    history = _history_root(context)
    if history:
        args += ["--history", history]
    for item in _config_dirs():
        args += ["--config", item]
    for item in _blender_temp_dirs():
        args += ["--temp", item]
    return _start_worker(context, "points_scan", args, f"points_scan_{_stamp()}.json")


def _selected_candidate(context=None):
    st = _scene_settings(context)
    if st is None:
        return None
    index = int(st.crash_recovery_active_index)
    if index < 0 or index >= len(st.crash_recovery_candidates):
        return None
    return st.crash_recovery_candidates[index]


def _target_of(item) -> dict[str, Any]:
    return {"source": str(getattr(item, "path", "") or ""), "blend_path": str(getattr(item, "blend_path", "") or ""),
            "scene_name": str(getattr(item, "scene_name", "") or ""), "home_dir": str(getattr(item, "home_dir", "") or "")}


def _pid_of(source: str) -> int:
    try:
        return int(str(source).split(":", 1)[1]) if str(source).lower().startswith("pid:") else 0
    except (IndexError, ValueError):
        return 0


def start_copy_selected(context=None) -> tuple[bool, str]:
    item = _selected_candidate(context)
    if item is None or not str(item.path or ""):
        return False, _ui_text("Select a target in the list first.", "先に一覧から対象を選んでください。")
    if worker_running():
        return False, _busy_message()
    target = _target_of(item)
    source = target["source"]
    destination = recovered_path_for(target["blend_path"], target["scene_name"], target["home_dir"])
    if source.lower().startswith("pid:"):
        pid = _pid_of(source)
        if pid <= 0:
            return False, _ui_text("Select a target in the list first.", "先に一覧から対象を選んでください。")
        return _start_worker(context, "dump_rescue", ["dump_rescue", str(pid), destination], f"dump_rescue_{_stamp()}.json",
                             open_after_success=True, target=target)
    return _start_worker(context, "copy", ["copy", source, destination], f"copy_{_stamp()}.json",
                         open_after_success=True, target=target)


def start_analyze_selected(context=None) -> tuple[bool, str]:
    item = _selected_candidate(context)
    pid = _pid_of(str(getattr(item, "path", "") or "")) if item is not None else 0
    if pid <= 0:
        return False, _ui_text("Select a Blender in the list first.", "先に一覧から Blender を選んでください。")
    if worker_running():
        return False, _busy_message()
    clear_recovery_points()
    return _start_worker(context, "dump_analyze", ["dump_analyze", str(pid)], f"dump_analyze_{_stamp()}.json",
                         target=_target_of(item))


def recovery_points() -> list[dict[str, Any]]:
    values = _state().get("recovery_points", [])
    if not isinstance(values, list):
        return []
    rows = [dict(item) for item in values if isinstance(item, dict)]
    rows.sort(key=lambda item: int(item.get("rank", 0) or 0))
    for position, row in enumerate(rows):
        row["position"] = position
        row["source_label"] = _ui_text("Latest", "最新") if position == 0 else _ui_text(f"{position} back", f"{position} 手前")
    return rows


def clear_recovery_points() -> None:
    state = _state()
    try:
        _remove_owned_session(str(state.get("recovery_session_path", "") or ""))
    except Exception:
        pass
    for key in ("recovery_session_path", "recovery_dump_path", "recovery_points", "recovery_target"):
        state.pop(key, None)


def start_recovery_point(context, position: int) -> tuple[bool, str]:
    state = _state()
    dump_path = str(state.get("recovery_dump_path", "") or "")
    points = recovery_points()
    if not dump_path or not Path(dump_path).is_file():
        return False, _ui_text("Find recovery points first.", "先に復旧ポイントを探してください。")
    if int(position) < 0 or int(position) >= len(points):
        return False, _ui_text("This recovery point is no longer available.", "この復旧ポイントはもうありません。")
    if worker_running():
        return False, _busy_message()
    point = points[int(position)]
    step_index = int(point.get("index", position) or 0)
    target = dict(state.get("recovery_target") or {})
    seed = str(point.get("blend_path", "") or target.get("blend_path", "") or "")
    scene_name = str(target.get("scene_name", "") or (Path(seed).name if seed else ""))
    destination = recovered_path_for(seed, scene_name, str(target.get("home_dir", "") or ""))
    return _start_worker(context, "dump_extract", ["dump_extract", dump_path, str(step_index), destination],
                         f"dump_extract_{_stamp()}.json", open_after_success=True, target=target)


def _abspath(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    try:
        text = _bpy().path.abspath(text)
    except Exception:
        pass
    return os.path.abspath(text)


def start_dump_file_analyze(context=None) -> tuple[bool, str]:
    st = _scene_settings(context)
    dump_path = _abspath(str(getattr(st, "crash_recovery_dump_file", "") or "")) if st is not None else ""
    if not dump_path or not Path(dump_path).is_file():
        return False, _ui_text("Choose a dump file first.", "先にダンプファイルを指定してください。")
    if worker_running():
        return False, _busy_message()
    clear_recovery_points()
    target = {"source": dump_path, "blend_path": "", "scene_name": "", "home_dir": ""}
    return _start_worker(context, "dump_file_analyze", ["dump_file_analyze", dump_path],
                         f"dump_file_analyze_{_stamp()}.json", target=target)


def cancel_worker() -> bool:
    state = _state()
    proc = state.get("process")
    if proc is None or proc.poll() is not None:
        worker_pid = int(state.get("worker_pid", 0) or 0)
        state["process"] = None
        _clear_worker_lease(state)
        _cleanup_worker_runtime(state)
        _remove_sessions_for_worker(worker_pid)
        return False
    worker_pid = int(state.get("worker_pid", 0) or 0)
    try:
        proc.terminate()
        try:
            proc.wait(timeout=3.0)
        except Exception:
            proc.kill()
        return True
    finally:
        state["process"] = None
        _clear_worker_lease(state)
        _cleanup_worker_runtime(state)
        _remove_sessions_for_worker(worker_pid)


def cleanup_owned_resources() -> None:
    cancel_worker()
    try:
        state = _state()
        _remove_owned_session(str(state.get("recovery_session_path", "") or ""))
        state.pop("recovery_session_path", None); state.pop("recovery_dump_path", None); state.pop("recovery_points", None)
    except Exception:
        pass
    try:
        bpy = _bpy()
        _reset_all_scene_runtime_state()
        handlers = getattr(getattr(bpy, "app", None), "handlers", None)
        try:
            records = list(_handler_records())
        except Exception:
            records = []
        for record in reversed(records):
            _remove_exact_handler(record.get("collection"), record.get("callback"))
        if handlers is not None:
            _remove_stale_owned_handlers(handlers)
        ns = bpy.app.driver_namespace
        timer = ns.get(TIMER_KEY)
        if timer is not None and bpy.app.timers.is_registered(timer):
            bpy.app.timers.unregister(timer)
        if bpy.app.timers.is_registered(_poll_timer):
            bpy.app.timers.unregister(_poll_timer)
        ns.pop(TIMER_KEY, None)
        ns.pop(STATE_KEY, None)
        ns.pop(HANDLERS_KEY, None)
    except Exception:
        pass
    _STATE_SURVIVOR.clear()
    try:
        cleanup_abandoned_scratch()
    except Exception:
        pass


def main(argv: list[str]) -> int:
    args = list(argv)
    if "--" in args:
        args = args[args.index("--") + 1:]
    if not args:
        return 2
    command = args[0]
    try:
        if command == "scan" and len(args) >= 2:
            rest = args[1:-1]
            history = ""
            config_dirs: list[str] = []
            temp_dirs: list[str] = []
            roots: list[str] = []
            i = 0
            while i < len(rest):
                item = rest[i]
                if item in {"--history", "--config", "--temp"} and i + 1 < len(rest):
                    if item == "--history":
                        history = rest[i + 1]
                    elif item == "--config":
                        config_dirs.append(rest[i + 1])
                    else:
                        temp_dirs.append(rest[i + 1])
                    i += 2
                    continue
                roots.append(item)
                i += 1
            return command_scan(args[-1], roots, config_dirs=config_dirs, history_root=history, temp_dirs=temp_dirs)
        if command == "copy" and len(args) == 4:
            _progress("copy", 10)
            return command_copy(args[1], args[2], args[3])
        if command == "dump_analyze" and len(args) == 3:
            return command_dump_analyze(int(args[1]), args[2])
        if command == "dump_rescue" and len(args) == 4:
            return command_dump_rescue(int(args[1]), args[2], args[3])
        if command == "dump_extract" and len(args) == 5:
            return command_dump_extract(args[1], int(args[2]), args[3], args[4])
        if command == "dump_file_analyze" and len(args) == 3:
            return command_dump_file_analyze(args[1], args[2])
    except Exception as exc:
        if args:
            try:
                out = Path(args[-1])
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_text(json.dumps({"status": "FAIL", "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            except Exception:
                pass
        return 9
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
