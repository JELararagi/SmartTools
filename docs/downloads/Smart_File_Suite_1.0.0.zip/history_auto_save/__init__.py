# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Compatibility entry for Smart File's centrally managed history feature."""

import sys

from . import properties as props, translation as i18n
from .core import runtime
from .operators import history_operators as history_ops
from .ui import panels

__all__ = ["CLASSES", "register", "unregister", "runtime", "props", "history_ops", "panels"]
SMART_FILE_SUITE_VERSION = (1, 0, 0)
bl_info = {
    "name": "History Snapshot Protection",
    "author": "JELararagi",
    "version": SMART_FILE_SUITE_VERSION,
    "blender": (5, 1, 0),
    "location": "Smart File > Recover",
    "description": "Keep Blender history, create restore points, and recover from rolling autosaves.",
    "category": "System",
}

CLASSES = (*props.CLASSES, *history_ops.CLASSES)


def _uhm_class_has_bl_rna(cls):
    if not isinstance(cls, type):
        return False
    return bool(str(getattr(cls.__dict__.get("bl_rna"), "identifier", "") or "").strip())


def _uhm_lookup_registered_class(cls):
    return cls if _uhm_class_has_bl_rna(cls) else None


def _uhm_safe_register_class(cls):
    return False


def _uhm_registered_pg_type(cls):
    registered = _uhm_lookup_registered_class(cls)
    if registered is None:
        raise RuntimeError(f"History PropertyGroup RNA is not ready: {getattr(cls, '__name__', cls)!r}")
    return registered


def _apply_suite_settings_after_pointer_registration(context=None):
    try:
        from .. import settings
        apply = getattr(settings, "apply_all", None)
        if callable(apply):
            apply(context)
    except Exception:
        return False
    return True


def register():
    """Read the existing owner's status without starting a second history session."""
    suite_name = __package__.rsplit(".", 1)[0]
    owner_status = getattr(sys.modules.get(suite_name), "_sf_history_status", None)
    if not callable(owner_status):
        return False
    try:
        return bool(owner_status().get("registered"))
    except Exception:
        return False


def unregister():
    return True
