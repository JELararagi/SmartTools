# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Legacy startup entry points for the sidebar registered by Smart File."""


def register():
    pass


unregister = register


def ensure_runtime_initialized(*args, **kwargs):
    return False
