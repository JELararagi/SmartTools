# -----------------------------------------------------------------------------
#  Assembly Guard Toolkit / Controller Focus / Proxy-Safe Selection
# -----------------------------------------------------------------------------

import json
import time


_SF_ASM_SCOPE_ITEMS = [
    ('LINKED', 'Linked', 'Only affect linked scene objects so referenced assemblies can be protected without touching local work objects.'),
    ('OVERRIDES', 'Overrides', 'Only affect library override objects so editable local layers can be protected separately from the linked source.'),
    ('LINKED_AND_OVERRIDES', 'Linked + Overrides', 'Affect both linked data and override layers together. Use this when a whole referenced assembly should switch into a controller-safe mode in one step.'),
    ('SELECTED', 'Selected + Children', 'Only affect the current selection and its child hierarchy. This is useful when you want to protect one imported assembly without touching the rest of the scene.'),
]

_SF_ASM_ACTION_ITEMS = [
    ('CONTROLLERS_ONLY', 'Controllers Only', 'Keep armatures, empties, cameras, and controller-like objects selectable, while making the rest of the target assembly harder to click by mistake.'),
    ('PROXY_CONTROLLERS', 'Proxy + Controllers', 'In addition to controller-only selection, switch non-controller geometry to bounds display so heavy referenced rigs become lighter and safer to navigate.'),
    ('LOCK_ALL', 'Lock All', 'Disable viewport selection for every target object. Use this before layout, lighting, or review work when the assembly should stay visually present but not be edited accidentally.'),
    ('UNLOCK_ALL', 'Unlock All', 'Re-enable viewport selection for every target object. Use this when the protected assembly needs to become editable again.'),
    ('SELECT_CONTROLLERS', 'Select Controllers', 'Find controller-like objects inside the chosen scope and select them for quick rig access.'),
]

_SF_ASM_DEFAULT_KEYWORDS = 'ctrl,ctl,control,rig,root,master,main,gimbal,handle,cam,camera'


def _sf_asm_keywords(context) -> list[str]:
    wm = getattr(context, 'window_manager', None)
    raw = ''
    try:
        raw = str(getattr(wm, 'sf_assembly_controller_keywords', '') or '') if wm is not None else ''
    except Exception:
        raw = ''
    raw = raw or _SF_ASM_DEFAULT_KEYWORDS
    out = []
    seen = set()
    for part in raw.replace(';', ',').split(','):
        token = str(part or '').strip().lower()
        if not token or token in seen:
            continue
        seen.add(token)
        out.append(token)
    return out or [token for token in _SF_ASM_DEFAULT_KEYWORDS.split(',') if token]


def _sf_asm_add_with_children(ob, out: list[object], seen: set[str]):
    if ob is None:
        return
    name = str(getattr(ob, 'name', '') or '')
    if not name or name in seen:
        return
    seen.add(name)
    out.append(ob)
    try:
        children = list(getattr(ob, 'children', []) or [])
    except Exception:
        children = []
    for child in children:
        _sf_asm_add_with_children(child, out, seen)


def _sf_asm_target_objects(context, scope: str = 'LINKED_AND_OVERRIDES') -> list[object]:
    scope = str(scope or 'LINKED_AND_OVERRIDES').upper()
    if scope == 'SELECTED':
        out = []
        seen = set()
        base = []
        try:
            base = list(_sf_rep_selected_objects(context) or [])
        except Exception:
            try:
                base = list(getattr(context, 'selected_objects', []) or [])
            except Exception:
                base = []
        active = getattr(context, 'active_object', None)
        if not base and active is not None:
            base = [active]
        for ob in base:
            _sf_asm_add_with_children(ob, out, seen)
        return out
    try:
        return list(_sf_rep_target_objects(context, scope) or [])
    except Exception:
        scene = getattr(context, 'scene', None)
        try:
            return list(getattr(scene, 'objects', []) or [])
        except Exception:
            return []


def _sf_asm_target_summary_objects(context) -> list[object]:
    return _sf_asm_target_objects(context, 'LINKED_AND_OVERRIDES')


def _sf_asm_object_library(ob):
    lib = getattr(ob, 'library', None)
    if lib is not None:
        return lib
    override = getattr(ob, 'override_library', None)
    if override is not None:
        try:
            ref = getattr(override, 'reference', None)
            if ref is not None:
                return ref
        except Exception:
            pass
    return None


def _sf_asm_library_path(ob) -> str:
    lib = _sf_asm_object_library(ob)
    raw = ''
    try:
        raw = str(getattr(lib, 'filepath', '') or '') if lib is not None else ''
    except Exception:
        raw = ''
    if not raw:
        return ''
    try:
        return _norm_path(bpy.path.abspath(raw, library=getattr(lib, 'parent', None)) or raw)
    except Exception:
        return _norm_path(raw)


def _sf_asm_root_object(ob):
    current = ob
    seen = set()
    while current is not None:
        name = str(getattr(current, 'name', '') or '')
        if not name or name in seen:
            break
        seen.add(name)
        parent = getattr(current, 'parent', None)
        if parent is None:
            break
        current = parent
    return current or ob


def _sf_asm_group_key(ob) -> str:
    root = _sf_asm_root_object(ob)
    root_name = str(getattr(root, 'name', '') or '')
    lib_path = _sf_asm_library_path(ob)
    if lib_path:
        return f'{lib_path}::{root_name}'
    return root_name or str(getattr(ob, 'name', '') or '')


def _sf_asm_is_controller(ob, keywords: list[str]) -> bool:
    if ob is None:
        return False
    try:
        if bool(ob.get('sf_controller_hint', False)):
            return True
    except Exception:
        pass
    ob_type = str(getattr(ob, 'type', '') or '').upper()
    if ob_type in {'ARMATURE', 'EMPTY', 'CAMERA', 'LIGHT', 'LIGHT_PROBE', 'SPEAKER'}:
        return True
    name = str(getattr(ob, 'name', '') or '').lower()
    if not name:
        return False
    for token in (keywords or []):
        if token and token in name:
            return True
    return False


def _sf_asm_controller_candidates(objects: list[object], keywords: list[str]) -> list[object]:
    out = []
    seen = set()
    for ob in objects:
        if not _sf_asm_is_controller(ob, keywords):
            continue
        name = str(getattr(ob, 'name', '') or '')
        if not name or name in seen:
            continue
        seen.add(name)
        out.append(ob)
    return out


def _sf_asm_focus_group_keys(context, objects: list[object]) -> set[str]:
    keys = set()
    seeds = []
    try:
        seeds = list(getattr(context, 'selected_objects', []) or [])
    except Exception:
        seeds = []
    active = getattr(context, 'active_object', None)
    if active is not None:
        seeds.append(active)
    known = {str(getattr(ob, 'name', '') or ''): ob for ob in objects if ob is not None}
    for ob in seeds:
        name = str(getattr(ob, 'name', '') or '')
        if name and name in known:
            keys.add(_sf_asm_group_key(known[name]))
    return keys


def _sf_asm_pick_controllers_for_selection(context, objects: list[object], keywords: list[str]) -> list[object]:
    controllers = _sf_asm_controller_candidates(objects, keywords)
    if not controllers:
        return []
    focus_keys = _sf_asm_focus_group_keys(context, objects)
    if focus_keys:
        focused = [ob for ob in controllers if _sf_asm_group_key(ob) in focus_keys]
        if focused:
            return focused
    return controllers


def _sf_asm_capture_entry(ob) -> dict:
    data = {
        'name': str(getattr(ob, 'name', '') or ''),
        'library': getattr(getattr(ob, 'library', None), 'filepath', None),
        'hide_select': bool(getattr(ob, 'hide_select', False)),
    }
    try:
        data['display_type'] = str(getattr(ob, 'display_type', '') or '')
    except Exception:
        pass
    return data


def _sf_asm_store_snapshot(context, scope: str = 'LINKED_AND_OVERRIDES') -> dict:
    objects = _sf_asm_target_objects(context, scope)
    payload = {
        'scope': str(scope or 'LINKED_AND_OVERRIDES').upper(),
        'created_at': int(time.time()),
        'entries': [_sf_asm_capture_entry(ob) for ob in objects],
        'selected_names': [str(getattr(ob, 'name', '') or '') for ob in list(getattr(context, 'selected_objects', []) or []) if ob is not None],
        'active_name': str(getattr(getattr(context, 'active_object', None), 'name', '') or ''),
    }
    wm = getattr(context, 'window_manager', None)
    # An empty scope is reported as a failure by the caller, so it must not
    # replace the snapshot the user can still restore.
    if wm is not None and payload['entries']:
        try:
            wm.sf_assembly_snapshot_json = json.dumps(payload, ensure_ascii=False)
        except Exception:
            pass
    return payload


def _sf_asm_select_objects(context, objects: list[object]) -> int:
    count = 0
    try:
        for ob in list(getattr(context, 'selected_objects', []) or []):
            try:
                ob.select_set(False)
            except Exception:
                pass
    except Exception:
        pass
    first = None
    for ob in objects:
        try:
            if bool(getattr(ob, 'hide_select', False)):
                continue
            ob.select_set(True)
            count += 1
            if first is None:
                first = ob
        except Exception:
            pass
    if first is not None:
        try:
            context.view_layer.objects.active = first
        except Exception:
            pass
    return count


def _sf_asm_restore_snapshot(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    if wm is None:
        return {'restored': 0, 'missing': 0, 'failed': 0, 'selected': 0, 'entries': 0}
    raw = str(getattr(wm, 'sf_assembly_snapshot_json', '') or '')
    if not raw.strip():
        return {'restored': 0, 'missing': 0, 'failed': 0, 'selected': 0, 'entries': 0}
    try:
        payload = json.loads(raw)
    except Exception:
        return {'restored': 0, 'missing': 0, 'failed': 1, 'selected': 0, 'entries': 0}
    entries = list((payload or {}).get('entries', []) or [])
    restored = 0
    missing = 0
    failed = 0
    for entry in entries:
        name = str(entry.get('name', '') or '')
        if not name:
            continue
        try:
            # リンク元とオーバーライドは同じ名前なので、ライブラリまで指定して引く
            ob = bpy.data.objects.get((name, entry.get('library')))
        except Exception:
            ob = None
        if ob is None:
            missing += 1
            continue
        try:
            if 'hide_select' in entry and hasattr(ob, 'hide_select'):
                ob.hide_select = bool(entry.get('hide_select', False))
            if 'display_type' in entry and hasattr(ob, 'display_type'):
                display_type = str(entry.get('display_type', '') or '')
                if display_type:
                    ob.display_type = display_type
            restored += 1
        except Exception:
            failed += 1
    selected_names = [str(name or '') for name in list((payload or {}).get('selected_names', []) or []) if str(name or '').strip()]
    selected_count = 0
    if selected_names:
        try:
            for ob in list(getattr(context, 'selected_objects', []) or []):
                try:
                    ob.select_set(False)
                except Exception:
                    pass
        except Exception:
            pass
        first = None
        for name in selected_names:
            try:
                ob = bpy.data.objects.get(name)
            except Exception:
                ob = None
            if ob is None:
                continue
            try:
                if bool(getattr(ob, 'hide_select', False)):
                    continue
                ob.select_set(True)
                selected_count += 1
                if first is None:
                    first = ob
            except Exception:
                pass
        active_name = str((payload or {}).get('active_name', '') or '')
        try:
            active = bpy.data.objects.get(active_name) if active_name else first
        except Exception:
            active = first
        if active is not None:
            try:
                context.view_layer.objects.active = active
            except Exception:
                pass
    return {'restored': restored, 'missing': missing, 'failed': failed, 'selected': selected_count, 'entries': len(entries)}


def _sf_asm_summary(context) -> dict:
    objects = _sf_asm_target_summary_objects(context)
    keywords = _sf_asm_keywords(context)
    controllers = _sf_asm_controller_candidates(objects, keywords)
    protected = 0
    bounds = 0
    for ob in objects:
        try:
            if bool(getattr(ob, 'hide_select', False)):
                protected += 1
        except Exception:
            pass
        try:
            if str(getattr(ob, 'display_type', '') or '') == 'BOUNDS':
                bounds += 1
        except Exception:
            pass
    snapshot_entries = 0
    wm = getattr(context, 'window_manager', None)
    if wm is not None:
        try:
            payload = json.loads(str(getattr(wm, 'sf_assembly_snapshot_json', '') or ''))
            snapshot_entries = len(list((payload or {}).get('entries', []) or []))
        except Exception:
            snapshot_entries = 0
    return {
        'target_count': len(objects),
        'controller_count': len(controllers),
        'protected_count': int(protected or 0),
        'bounds_count': int(bounds or 0),
        'snapshot_entries': int(snapshot_entries or 0),
    }


def _sf_asm_apply_action(context, scope: str = 'LINKED_AND_OVERRIDES', action: str = 'CONTROLLERS_ONLY', redirect_selection: bool = True) -> dict:
    scope = str(scope or 'LINKED_AND_OVERRIDES').upper()
    action = str(action or 'CONTROLLERS_ONLY').upper()
    objects = _sf_asm_target_objects(context, scope)
    keywords = _sf_asm_keywords(context)
    controllers = _sf_asm_controller_candidates(objects, keywords)
    changed = 0
    failed = 0
    selected = 0
    supported = action in {'CONTROLLERS_ONLY', 'PROXY_CONTROLLERS', 'LOCK_ALL', 'UNLOCK_ALL', 'SELECT_CONTROLLERS'}
    if not supported:
        return {
            'scope': scope,
            'action': action,
            'object_count': len(objects),
            'controller_count': len(controllers),
            'changed': 0,
            'failed': 0,
            'selected': 0,
            'supported': False,
        }
    if action != 'SELECT_CONTROLLERS':
        for ob in objects:
            is_controller = _sf_asm_is_controller(ob, keywords)
            try:
                if action == 'CONTROLLERS_ONLY':
                    desired = not is_controller
                    if bool(getattr(ob, 'hide_select', False)) != desired:
                        ob.hide_select = desired
                        changed += 1
                elif action == 'PROXY_CONTROLLERS':
                    desired = not is_controller
                    if bool(getattr(ob, 'hide_select', False)) != desired:
                        ob.hide_select = desired
                        changed += 1
                    desired_display = 'SOLID' if is_controller else 'BOUNDS'
                    if hasattr(ob, 'display_type') and str(getattr(ob, 'display_type', '') or '') != desired_display:
                        ob.display_type = desired_display
                        changed += 1
                elif action == 'LOCK_ALL':
                    if not bool(getattr(ob, 'hide_select', False)):
                        ob.hide_select = True
                        changed += 1
                elif action == 'UNLOCK_ALL':
                    if bool(getattr(ob, 'hide_select', False)):
                        ob.hide_select = False
                        changed += 1
            except Exception:
                failed += 1
    if redirect_selection or action == 'SELECT_CONTROLLERS':
        selected = _sf_asm_select_objects(context, _sf_asm_pick_controllers_for_selection(context, objects, keywords))
    return {
        'scope': scope,
        'action': action,
        'object_count': len(objects),
        'controller_count': len(controllers),
        'changed': int(changed or 0),
        'failed': int(failed or 0),
        'selected': int(selected or 0),
        'supported': True,
    }


class SF_OT_assembly_guard_apply(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_assembly_guard_apply'
    bl_label = 'Apply'
    bl_description = 'Protect a referenced assembly by limiting selection to controllers, switching heavy geometry to bounds proxy mode, or unlocking it again when editing should resume.'
    bl_options = {'UNDO'}

    scope: EnumProperty(name='Scope', items=_SF_ASM_SCOPE_ITEMS, default='LINKED_AND_OVERRIDES')
    action: EnumProperty(name='Action', items=_SF_ASM_ACTION_ITEMS, default='CONTROLLERS_ONLY')
    redirect_selection: BoolProperty(name='Redirect selection to controllers', default=True, description='After protecting the assembly, try to select controller-like objects so you can continue animating or placing the rig without hunting for controls manually.')

    def execute(self, context):
        result = _sf_asm_apply_action(context, self.scope, self.action, redirect_selection=bool(self.redirect_selection))
        if not bool(result.get('supported', False)):
            self.report({'WARNING'}, _t('Unsupported assembly action'))
            return {'CANCELLED'}
        changed = int(result.get('changed', 0) or 0)
        failed = int(result.get('failed', 0) or 0)
        selected = int(result.get('selected', 0) or 0)
        try:
            _sf_append_activity(context, _t('Applied assembly guard'), f"{result.get('action')} / {result.get('scope')}", 'RESTRICT_SELECT_OFF')
        except Exception:
            pass
        if changed == 0 and failed == 0 and selected == 0:
            self.report({'WARNING'}, _t('No matching assembly targets were changed'))
            return {'CANCELLED'}
        level = {'WARNING'} if failed else {'INFO'}
        self.report(level, f"{_t('Changed')}: {changed} | {_t('Controllers')}: {int(result.get('controller_count', 0) or 0)} | {_t('Selected')}: {selected} | {_t('Failed')}: {failed}")
        return {'FINISHED'}


class SF_OT_assembly_guard_store_snapshot(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_assembly_guard_store_snapshot'
    bl_label = 'Store Snapshot'
    bl_description = 'Capture the current selection-lock and display state of a referenced assembly before you switch into a safer controller-only or proxy mode.'
    bl_options = {'UNDO'}

    scope: EnumProperty(name='Scope', items=_SF_ASM_SCOPE_ITEMS, default='LINKED_AND_OVERRIDES')

    def execute(self, context):
        payload = _sf_asm_store_snapshot(context, self.scope)
        count = len(list(payload.get('entries', []) or []))
        try:
            _sf_append_activity(context, _t('Stored assembly snapshot'), str(count), 'FILE_TICK')
        except Exception:
            pass
        if count == 0:
            self.report({'WARNING'}, _t('No assembly targets were available for the requested snapshot scope'))
            return {'CANCELLED'}
        self.report({'INFO'}, f"{_t('Stored')}: {count}")
        return {'FINISHED'}


class SF_OT_assembly_guard_restore_snapshot(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_assembly_guard_restore_snapshot'
    bl_label = 'Restore Snapshot'
    bl_description = 'Restore the most recent assembly selection-lock and display snapshot so the referenced scene can return to its previous editable or review state.'
    bl_options = {'UNDO'}

    def execute(self, context):
        result = _sf_asm_restore_snapshot(context)
        restored = int(result.get('restored', 0) or 0)
        missing = int(result.get('missing', 0) or 0)
        failed = int(result.get('failed', 0) or 0)
        selected = int(result.get('selected', 0) or 0)
        try:
            _sf_append_activity(context, _t('Restored assembly snapshot'), str(restored), 'RECOVER_LAST')
        except Exception:
            pass
        if restored == 0 and missing == 0 and failed == 0:
            self.report({'WARNING'}, _t('No saved assembly snapshot was found'))
            return {'CANCELLED'}
        level = {'WARNING'} if (missing or failed) else {'INFO'}
        self.report(level, f"{_t('Restored')}: {restored} | {_t('Selected')}: {selected} | {_t('Missing')}: {missing} | {_t('Failed')}: {failed}")
        return {'FINISHED'}


class SF_OT_assembly_guard_open(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_assembly_guard_open'
    bl_label = 'Open'
    bl_description = 'Open a compact visual board for controller-first selection safety, proxy-friendly display switching, and snapshot restore for linked or override assemblies. This bridges practical ideas from scene assembly, XRef safety, and controller-only workflows into one Blender-first UI.'
    bl_options = set()
    _sms_no_undo = True

    popup_width: IntProperty(default=660, min=480, max=900, options={'HIDDEN'})

    def invoke(self, context, event):
        try:
            _sf_append_activity(context, _t('Opened Assembly Guard'), '', 'RESTRICT_SELECT_OFF')
        except Exception:
            pass
        return context.window_manager.invoke_popup(self, width=self.popup_width)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        wm = getattr(context, 'window_manager', None)
        payload = _sf_asm_summary(context)
        _sf_draw_dialog_header(
            layout,
            'Assembly Guard',
            'Protect linked assemblies by keeping controllers easy to grab, while heavy geometry becomes harder to click by mistake.',
            'RESTRICT_SELECT_OFF',
        )

        summary = layout.box()
        _sf_draw_section_intro(
            summary,
            'Assembly Snapshot',
            'Check how many referenced objects are already protected or in proxy display before you apply another safety pass.',
            'NONE',
        )
        _sf_draw_state_line(summary, 'Referenced Targets', 'READY' if int(payload.get('target_count', 0) or 0) else 'NOT SET', detail=str(int(payload.get('target_count', 0) or 0)))
        _sf_draw_state_line(summary, 'Controllers', 'READY' if int(payload.get('controller_count', 0) or 0) else 'NOT SET', detail=str(int(payload.get('controller_count', 0) or 0)))
        _sf_draw_state_line(summary, 'Selection Protected', 'READY' if int(payload.get('protected_count', 0) or 0) else 'NOT SET', detail=str(int(payload.get('protected_count', 0) or 0)))
        _sf_draw_state_line(summary, 'Bounds Proxies', 'READY' if int(payload.get('bounds_count', 0) or 0) else 'NOT SET', detail=str(int(payload.get('bounds_count', 0) or 0)))
        _sf_draw_state_line(summary, 'Stored Snapshot', 'READY' if int(payload.get('snapshot_entries', 0) or 0) else 'NOT SET', detail=str(int(payload.get('snapshot_entries', 0) or 0)))

        settings = layout.box()
        _sf_draw_section_intro(
            settings,
            'Controller Detection',
            'Edit the comma-separated keywords if your rigs use custom controller naming such as ctr, anim, or guide. Armatures, empties, and cameras are always treated as controller-like objects.',
            'PREFERENCES',
        )
        if wm is not None:
            settings.prop(wm, 'sf_assembly_controller_keywords', text='Keywords')

        actions = layout.box()
        _sf_draw_section_intro(
            actions,
            'Quick Safety Passes',
            'Store a snapshot first, then switch the referenced assembly into a safer selection mode for layout, animation, lighting, or review work.',
            'TOOL_SETTINGS',
        )
        row = actions.row(align=True)
        op = row.operator('import_scene.sfs_assembly_guard_store_snapshot', text=_t('Store Snapshot'), icon='FILE_TICK')
        op.scope = 'LINKED_AND_OVERRIDES'
        row.operator('import_scene.sfs_assembly_guard_restore_snapshot', text=_t('Restore Snapshot'), icon='RECOVER_LAST')

        main = actions.column(align=True)
        row = main.row(align=True)
        op = row.operator('import_scene.sfs_assembly_guard_apply', text=_t('Apply'), icon='RESTRICT_SELECT_OFF')
        op.scope = 'LINKED_AND_OVERRIDES'
        op.action = 'CONTROLLERS_ONLY'
        op.redirect_selection = True
        op = row.operator('import_scene.sfs_assembly_guard_apply', text=_t('Apply'), icon='CUBE')
        op.scope = 'LINKED_AND_OVERRIDES'
        op.action = 'PROXY_CONTROLLERS'
        op.redirect_selection = True

        row = main.row(align=True)
        op = row.operator('import_scene.sfs_assembly_guard_apply', text=_t('Apply'), icon='LOCKED')
        op.scope = 'LINKED_AND_OVERRIDES'
        op.action = 'LOCK_ALL'
        op.redirect_selection = False
        op = row.operator('import_scene.sfs_assembly_guard_apply', text=_t('Apply'), icon='UNLOCKED')
        op.scope = 'LINKED_AND_OVERRIDES'
        op.action = 'UNLOCK_ALL'
        op.redirect_selection = False

        row = main.row(align=True)
        op = row.operator('import_scene.sfs_assembly_guard_apply', text=_t('Apply'), icon='RESTRICT_SELECT_OFF')
        op.scope = 'SELECTED'
        op.action = 'CONTROLLERS_ONLY'
        op.redirect_selection = True
        op = row.operator('import_scene.sfs_assembly_guard_apply', text=_t('Apply'), icon='ARMATURE_DATA')
        op.scope = 'LINKED_AND_OVERRIDES'
        op.action = 'SELECT_CONTROLLERS'
        op.redirect_selection = True

        support = layout.box()
        _sf_draw_section_intro(
            support,
            'Related Tools',
            'Use display, relink, and rollback tools together when the assembly also needs missing-file repair, bounds previews, or scene-state recovery.',
            'MODIFIER',
        )
        _sf_draw_action_block(
            support,
            primary_actions=[
                ('import_scene.sfs_representation_open', 'Representations', 'MOD_WIREFRAME', {}),
                ('import_scene.sfs_project_guard_open', 'Project Guard', 'LOCKVIEW_ON', {}),
                ('import_scene.sfs_reference_manager_open', 'Relink', 'LINKED', {}),
            ],
            secondary_actions=[
                ('import_scene.sfs_reference_toolkit_open', 'Toolkit', 'ASSET_MANAGER', {}),
                ('import_scene.sfs_shot_state_open', 'Shot States', 'CAMERA_DATA', {}),
                ('import_scene.sfs_shot_queue_open', 'Shot Queue', 'RENDER_STILL', {}),
            ],
        )
