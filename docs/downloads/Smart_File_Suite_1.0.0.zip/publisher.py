# -----------------------------------------------------------------------------
#  Publisher (Phase 3)
# -----------------------------------------------------------------------------

def _safe_filename(name: str) -> str:
    name = (name or "").strip()
    if not name:
        return "Asset"
    # Replace forbidden characters on Windows/macOS/Linux
    name = re.sub(r'[\\/:*?"<>|]+', "_", name)
    name = re.sub(r'\s+', '', name).strip()
    return name


def _get_first_enabled_root(prefs):
    if not prefs:
        return ""
    for r in getattr(prefs, "library_roots", []):
        if getattr(r, "enabled", True) and getattr(r, "path", "").strip():
            return _norm_path(r.path)
    return ""


def _choose_eevee_engine() -> str:
    # Prefer EEVEE Next when available
    try:
        items = bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items
        keys = [it.identifier for it in items]
        if "BLENDER_EEVEE_NEXT" in keys:
            return "BLENDER_EEVEE_NEXT"
        if "BLENDER_EEVEE" in keys:
            return "BLENDER_EEVEE"
    except Exception:
        pass
    return ""


def _bbox_world_for_objects(objs):
    """Return (min_vec, max_vec) in world space for given objects."""
    import mathutils
    if not objs:
        return None
    min_v = mathutils.Vector((1e20, 1e20, 1e20))
    max_v = mathutils.Vector((-1e20, -1e20, -1e20))
    has = False
    for o in objs:
        if o.type not in {'MESH', 'CURVE', 'SURFACE', 'FONT', 'META'}:
            continue
        try:
            for co in o.bound_box:
                v = o.matrix_world @ mathutils.Vector(co)
                min_v.x = min(min_v.x, v.x); min_v.y = min(min_v.y, v.y); min_v.z = min(min_v.z, v.z)
                max_v.x = max(max_v.x, v.x); max_v.y = max(max_v.y, v.y); max_v.z = max(max_v.z, v.z)
                has = True
        except Exception:
            pass
    if not has:
        return None
    return min_v, max_v


def _gather_objects_in_collection(coll):
    objs = set()
    if not coll:
        return []
    def walk(c):
        for o in c.objects:
            objs.add(o)
        for cc in c.children:
            walk(cc)
    walk(coll)
    return list(objs)


def _collect_image_risks_for_ids(root_ids):
    """Return (missing_count, abs_count, details_list) for images referenced by given IDs (best-effort)."""
    missing = 0
    abs_paths = 0
    details = []
    images = set()

    def add_img(img):
        if not img or img in images:
            return
        images.add(img)

    def walk_nodetree(nt):
        if not nt:
            return
        for n in nt.nodes:
            if n.type == 'TEX_IMAGE':
                try:
                    add_img(n.image)
                except Exception:
                    pass
            if hasattr(n, "node_tree"):
                walk_nodetree(getattr(n, "node_tree", None))

    for id_ in root_ids:
        if isinstance(id_, bpy.types.Object):
            # materials
            try:
                for ms in getattr(id_.data, "materials", []) or []:
                    if ms and getattr(ms, "use_nodes", False):
                        walk_nodetree(ms.node_tree)
            except Exception:
                pass
        if isinstance(id_, bpy.types.Collection):
            for o in _gather_objects_in_collection(id_):
                try:
                    for ms in getattr(o.data, "materials", []) or []:
                        if ms and getattr(ms, "use_nodes", False):
                            walk_nodetree(ms.node_tree)
                except Exception:
                    pass
        if isinstance(id_, bpy.types.Material):
            if getattr(id_, "use_nodes", False):
                walk_nodetree(id_.node_tree)
        if isinstance(id_, bpy.types.World):
            if getattr(id_, "use_nodes", False):
                walk_nodetree(id_.node_tree)

    for img in images:
        try:
            fp = bpy.path.abspath(getattr(img, "filepath", "") or "")
            if fp:
                is_abs = os.path.isabs(fp)
                exists = os.path.exists(fp)
                if not exists:
                    missing += 1
                if is_abs:
                    abs_paths += 1
                if (not exists) or is_abs:
                    details.append({"name": img.name, "filepath": fp, "missing": not exists, "absolute": is_abs})
        except Exception:
            pass

    return missing, abs_paths, details



def _collect_images_for_ids(root_ids):
    """Return a set of bpy.types.Image referenced by the given IDs (best-effort)."""
    images = set()

    def add_img(img):
        if img:
            images.add(img)

    def walk_nodetree(nt):
        if not nt:
            return
        for n in nt.nodes:
            if n.type == 'TEX_IMAGE':
                try:
                    add_img(n.image)
                except Exception:
                    pass
            if hasattr(n, "node_tree"):
                try:
                    walk_nodetree(getattr(n, "node_tree", None))
                except Exception:
                    pass

    for id_ in root_ids:
        if isinstance(id_, bpy.types.Object):
            try:
                for ms in getattr(id_.data, "materials", []) or []:
                    if ms and getattr(ms, "use_nodes", False):
                        walk_nodetree(ms.node_tree)
            except Exception:
                pass
        if isinstance(id_, bpy.types.Collection):
            for o in _gather_objects_in_collection(id_):
                try:
                    for ms in getattr(o.data, "materials", []) or []:
                        if ms and getattr(ms, "use_nodes", False):
                            walk_nodetree(ms.node_tree)
                except Exception:
                    pass
        if isinstance(id_, bpy.types.Material):
            if getattr(id_, "use_nodes", False):
                walk_nodetree(id_.node_tree)
        if isinstance(id_, bpy.types.World):
            if getattr(id_, "use_nodes", False):
                walk_nodetree(id_.node_tree)

    return images


def _copy_external_images(images, target_dir: str, subdir: str = "textures"):
    'Copy external image files into target_dir/subdir and return remap table.\n\n    Returns (copied_files, remap_table, stats)\n      copied_files: list of absolute paths copied to disk\n      remap_table: dict[image.name] -> new_relative_path (//subdir/filename)\n      stats: dict with counts for missing/packed/copied'
    copied = []
    remap = {}
    stats = {"missing": 0, "packed": 0, "copied": 0}

    if not subdir:
        subdir = "textures"
    out_folder = os.path.join(target_dir, subdir)
    os.makedirs(out_folder, exist_ok=True)

    used = set()

    for img in images:
        try:
            if getattr(img, "packed_file", None):
                stats["packed"] += 1
                continue

            raw = getattr(img, "filepath", "") or ""
            if not raw:
                stats["missing"] += 1
                continue

            abs_path = bpy.path.abspath(raw)
            if not abs_path or not os.path.exists(abs_path):
                stats["missing"] += 1
                continue

            base = os.path.basename(abs_path)
            name, ext = os.path.splitext(base)
            if not ext:
                ext = ".png"

            safe_base = _safe_filename(name) or _safe_filename(img.name) or "image"
            cand = safe_base + ext
            n = 1
            while cand.lower() in used or os.path.exists(os.path.join(out_folder, cand)):
                cand = f"{safe_base}_{n:03d}{ext}"
                n += 1
            used.add(cand.lower())

            dst = os.path.join(out_folder, cand)
            try:
                import shutil
                shutil.copy2(abs_path, dst)
                copied.append(dst)
                stats["copied"] += 1
                rel = f"//{subdir}/{cand}"
                remap[img.name] = rel
            except Exception:
                stats["missing"] += 1
                continue
        except Exception:
            continue

    return copied, remap, stats


def _apply_image_remap(remap_table: dict):
    """Apply filepath remap to images in the current file. Returns original path table for restore."""
    original = {}
    if not remap_table:
        return original
    for img_name, new_fp in remap_table.items():
        try:
            img = bpy.data.images.get(img_name)
            if not img:
                continue
            original[img_name] = getattr(img, "filepath", "")
            img.filepath = new_fp
        except Exception:
            pass
    return original


def _restore_image_paths(original_table: dict):
    for img_name, old_fp in (original_table or {}).items():
        try:
            img = bpy.data.images.get(img_name)
            if img:
                img.filepath = old_fp
        except Exception:
            pass


def _update_catalog_json(catalog_path: str, entry: dict, asset_key: str):
    """Update a simple catalog json at catalog_path with the new entry."""
    try:
        os.makedirs(os.path.dirname(catalog_path), exist_ok=True)
    except Exception:
        pass

    cat = {"assets": {}}
    try:
        if os.path.exists(catalog_path):
            with open(catalog_path, "r", encoding="utf-8") as f:
                cat = json.load(f) or cat
    except Exception:
        cat = {"assets": {}}

    assets = cat.setdefault("assets", {})
    a = assets.setdefault(asset_key, {"latest": 0, "entries": []})

    # Preserve stable asset_id across versions
    try:
        if isinstance(entry, dict) and entry.get("asset_id"):
            if not (isinstance(a, dict) and a.get("asset_id")):
                a["asset_id"] = str(entry.get("asset_id"))
    except Exception:
        pass

    a.setdefault("entries", []).append(entry)

    try:
        v = int(entry.get("version", 0))
        if v > int(a.get("latest", 0) or 0):
            a["latest"] = v
    except Exception:
        pass

    try:
        a["entries"].sort(key=lambda e: (int(e.get("version", 0) or 0), e.get("published_at", "")))
    except Exception:
        pass

    try:
        with open(catalog_path, "w", encoding="utf-8") as f:
            json.dump(cat, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def _write_pack_helper_script(script_path: str, blend_path: str):
    """Write a helper script that packs all external files in the given .blend when run inside Blender."""
    try:
        bp = repr(blend_path)
        script = (
            '# Pack all external files for a published asset'
            '# How to use:'
            '# 1) Open Blender'
            '# 2) Run this script (Text Editor > Open > Run Script)'
            '# It will open the published .blend, pack external files, save.'
            'import bpy'
            f"target = {bp}\n"
            'bpy.ops.wm.open_mainfile(filepath=target)'
            'try:'
            'bpy.ops.file.pack_all()'
            'except Exception:'
            'for img in bpy.data.images:'
            'try:'
            'if not img.packed_file and img.filepath:'
            'img.pack()'
            'except Exception:'
            'pass'
            'bpy.ops.wm.save_mainfile()'
        )
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(script)
        return True
    except Exception:
        return False


def _write_meta_json(meta_path: str, payload: dict):
    try:
        os.makedirs(os.path.dirname(meta_path), exist_ok=True)
        with open(meta_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def _append_changelog(log_path: str, line: str):
    try:
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(line.rstrip('\n') + '\n')
        return True
    except Exception:
        return False


def _render_preview_png(output_png: str, collection: bpy.types.Collection, resolution: int = 512) -> bool:
    """Render a simple preview in a temporary scene using Eevee, then clean up."""
    try:
        import mathutils
        window = bpy.context.window
        orig_scene = window.scene

        scene = bpy.data.scenes.new("SF_PUBLISH_PREVIEW")
        # Link collection (non-destructive)
        try:
            scene.collection.children.link(collection)
        except Exception:
            # If already linked somewhere, Blender may still allow; ignore
            pass

        # Choose Eevee engine
        eng = _choose_eevee_engine()
        if eng:
            scene.render.engine = eng

        # Render settings
        scene.render.filepath = output_png
        scene.render.image_settings.file_format = 'PNG'
        scene.render.resolution_x = int(resolution)
        scene.render.resolution_y = int(resolution)
        scene.render.resolution_percentage = 100

        # Low samples when available
        if hasattr(scene, "eevee") and hasattr(scene.eevee, "taa_render_samples"):
            scene.eevee.taa_render_samples = 16
        if hasattr(scene, "cycles"):
            scene.cycles.samples = 16

        # Camera
        cam_data = bpy.data.cameras.new("SF_Publish_Cam")
        cam_obj = bpy.data.objects.new("SF_Publish_Cam", cam_data)
        scene.collection.objects.link(cam_obj)
        scene.camera = cam_obj

        # Light
        light_data = bpy.data.lights.new(name='SF_Publish_Light', type='SUN')
        light_obj = bpy.data.objects.new(name='SF_Publish_Light', object_data=light_data)
        scene.collection.objects.link(light_obj)
        light_obj.rotation_euler = (0.9, 0.2, 0.5)

        # Frame camera to bbox
        objs = _gather_objects_in_collection(collection)
        bb = _bbox_world_for_objects(objs)
        if bb:
            mn, mx = bb
            center = (mn + mx) * 0.5
            size = (mx - mn)
            radius = max(size.x, size.y, size.z) * 0.7
            if radius < 0.1:
                radius = 1.0
            # place camera on -Y axis, slightly above
            cam_loc = center + mathutils.Vector((0.0, -(radius * 3.0), radius * 1.2))
            cam_obj.location = cam_loc
            # look at center
            direction = center - cam_obj.location
            rot = direction.to_track_quat('-Z', 'Y').to_euler()
            cam_obj.rotation_euler = rot
            cam_data.lens = 50
            cam_data.clip_start = 0.01
            cam_data.clip_end = 10000.0
        else:
            cam_obj.location = (0, -5, 3)
            cam_obj.rotation_euler = (1.1, 0.0, 0.0)

        # Switch scene for render
        window.scene = scene
        bpy.ops.render.render(write_still=True)

        # restore
        window.scene = orig_scene

        # cleanup
        try:
            bpy.data.objects.remove(cam_obj, do_unlink=True)
        except Exception:
            pass
        try:
            bpy.data.cameras.remove(cam_data, do_unlink=True)
        except Exception:
            pass
        try:
            bpy.data.objects.remove(light_obj, do_unlink=True)
        except Exception:
            pass
        try:
            bpy.data.lights.remove(light_data, do_unlink=True)
        except Exception:
            pass
        try:
            bpy.data.scenes.remove(scene, do_unlink=True)
        except Exception:
            pass

        return os.path.exists(output_png)
    except Exception:
        return False


def _pub_generate_asset_id(prefs, asset_name: str) -> str:
    'Generate a new asset_id according to preferences.\n\n    Existing asset_id should be preserved by the caller (this is for new assets only).'
    scheme = getattr(prefs, "pub_asset_id_scheme", "UUID4") if prefs else "UUID4"
    prefix = (getattr(prefs, "pub_asset_id_prefix", "") if prefs else "") or ""
    prefix = re.sub(r"[^A-Za-z0-9_\-]", "_", prefix.strip())

    try:
        if scheme == 'UUID5':
            base = f"{prefix}:{asset_name}" if prefix else asset_name
            return str(uuid.uuid5(uuid.NAMESPACE_URL, base))
        if scheme == 'PREFIX_UUID4':
            uid = str(uuid.uuid4())
            return f"{prefix}-{uid}" if prefix else uid
        if scheme == 'PREFIX_UUID5':
            base = f"{prefix}:{asset_name}" if prefix else asset_name
            uid = str(uuid.uuid5(uuid.NAMESPACE_URL, base))
            return f"{prefix}-{uid}" if prefix else uid
        return str(uuid.uuid4())
    except Exception:
        try:
            return str(uuid.uuid4())
        except Exception:
            return ""


class SF_OT_publisher_publish_asset(bpy.types.Operator):
    bl_idname = 'export_scene.sfs_publisher_publish_asset'
    bl_label = 'Publish Asset'
    bl_description = 'Publish selected content as a versioned .blend asset, with preview, metadata, catalog updates, and portable external-asset handling for images, sounds, fonts, movie clips, volumes, and cache files'
    bl_options = {'UNDO'}

    target_dir: StringProperty(
        name='Target Folder',
        subtype='DIR_PATH',
        default="",
        description='Folder where the published .blend, preview, metadata, and optional catalog files will be written',
    )
    asset_name: StringProperty(
        name='Asset Name',
        default="",
        description='Base asset name used for the published file name, metadata entry, and versioned output',
    )
    source: EnumProperty(
        name='Source',
        items=[
            ('ACTIVE_COLLECTION', "Active Collection", ""),
            ('SELECTED_OBJECTS', "Selected Objects", ""),
        ],
        default='ACTIVE_COLLECTION',
        description='Choose whether the published asset is built from the active collection or from the current object selection',
    )
    versioning: EnumProperty(
        name='Versioning',
        items=[
            ('AUTO', "Auto Next", ""),
            ('MANUAL', "Manual", ""),
        ],
        default='AUTO',
        description='Auto Next finds the next available version number. Manual lets you choose it yourself',
    )
    version: IntProperty(
        name='Version',
        default=1,
        min=1,
        max=999999,
        description='Manual version number to publish when Versioning is set to Manual',
    )
    notes: StringProperty(
        name='Notes',
        default="",
        description='Optional release notes written into metadata and changelog outputs',
    )
    create_meta: BoolProperty(
        name='Create metadata (.json)',
        default=True,
        description='Write a sidecar JSON metadata file next to the published .blend',
    )
    append_changelog: BoolProperty(
        name='Append to changelog',
        default=True,
        description='Append this publish operation to the asset changelog text file',
    )
    generate_preview: BoolProperty(
        name='Generate preview (.png)',
        default=True,
        description='Render a preview image for the published asset after the .blend is written',
    )
    preview_mode: EnumProperty(
        name='Preview Mode',
        items=[
            ('NONE', "None", ""),
            ('EEVEE', "Fast Render (Eevee)", ""),
        ],
        default='EEVEE',
        description='How the preview image should be generated for this publish run',
    )
    path_remap: EnumProperty(
        name='Path Remap',
        items=[
            ('RELATIVE', "Relative", ""),
            ('ABSOLUTE', "Absolute", ""),
            ('NONE', "No Remap", ""),
        ],
        default='RELATIVE',
        description='How file paths inside the published .blend should be rewritten when it is exported',
    )
    open_folder_after: BoolProperty(
        name='Open folder after publish',
        default=False,
        description='Open the publish destination folder in the operating system file browser after completion',
    )


    external_files_mode: EnumProperty(
        name='External Files',
        items=[
            ('NONE', "None", ""),
            ('COPY', "Copy external files", ""),
            ('COPY_PACK_SCRIPT', "Copy + Pack script", ""),
        ],
        default='COPY',
        description='Copy external asset files used by this asset into the publish folder and remap paths for better portability',
    )
    external_files_subdir: StringProperty(
        name='External Files Subfolder',
        default="textures",
        description='Subfolder used to store copied external asset files inside the publish folder',
    )
    catalog_filename: StringProperty(
        name='Catalog File Name',
        default="catalog.json",
        description='Catalog file name to create or update in the publish folder',
    )
    update_catalog: BoolProperty(
        name='Update catalog',
        default=True,
        description='Create or update catalog.json with this asset entry after publishing',
    )
    category: StringProperty(
        name='Category',
        default="",
        description='Optional category written into the catalog and metadata so the asset is easier to organize later',
    )
    tags: StringProperty(
        name='Tags',
        default="",
        description='Comma-separated tags written into metadata/catalog',
    )

    def invoke(self, context, _event):
        prefs = _addon_prefs(context)

        # Defaults
        if not self.target_dir:
            root = _get_first_enabled_root(prefs) or os.path.dirname(_norm_path(bpy.data.filepath or "")) or ""
            if root:
                sub = getattr(prefs, "pub_default_subdir", "Published") if prefs else "Published"
                self.target_dir = os.path.join(root, sub)

        if not self.asset_name:
            if self.source == 'ACTIVE_COLLECTION':
                try:
                    self.asset_name = context.collection.name
                except Exception:
                    self.asset_name = ""
            if not self.asset_name:
                sel = list(context.selected_objects)
                if sel:
                    self.asset_name = sel[0].name

        if prefs:
            try:
                self.preview_mode = getattr(prefs, "pub_preview_default", "EEVEE")
                self.open_folder_after = bool(getattr(prefs, "pub_open_folder", False))
                self.external_files_mode = getattr(prefs, "pub_ext_files_mode", "COPY")
                self.external_files_subdir = getattr(prefs, "pub_ext_files_subdir", "textures")
                self.catalog_filename = getattr(prefs, "pub_catalog_filename", "catalog.json")
                self.update_catalog = bool(getattr(prefs, "pub_update_catalog", True))
                self.category = getattr(prefs, "pub_default_category", "")
            except Exception:
                pass

        return context.window_manager.invoke_props_dialog(self, width=700)

    def draw(self, context):
        prefs = _addon_prefs(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        asset = _safe_filename(self.asset_name)
        tdir = _norm_path(self.target_dir) if self.target_dir else ""
        pad = int(getattr(prefs, "pub_version_padding", 3) or 3) if prefs else 3
        next_v = self.version
        if self.versioning == 'AUTO' and tdir and os.path.isdir(tdir):
            try:
                rgx = re.compile(rf"^{re.escape(asset)}_v(\d+)\.blend$", re.IGNORECASE)
                maxv = 0
                for fn in os.listdir(tdir):
                    m = rgx.match(fn)
                    if m:
                        maxv = max(maxv, int(m.group(1)))
                next_v = maxv + 1 if maxv > 0 else 1
            except Exception:
                pass
        if self.versioning == 'MANUAL':
            next_v = self.version
        out_name = f"{asset}_v{int(next_v):0{pad}d}.blend" if asset else ""

        top = layout.box()
        top.prop(self, 'target_dir')
        top.prop(self, 'asset_name')
        row = top.row(align=True)
        row.prop(self, 'source', text='Source')
        row.prop(self, 'versioning', text='Version')
        if self.versioning == 'MANUAL':
            top.prop(self, 'version')
        if out_name:
            top.label(text=f"{_t('Output')}: {out_name}", icon='FILE_BLEND')

        split = layout.split(factor=0.5)
        left = split.column(align=True)
        right = split.column(align=True)

        out_box = left.box()
        out_box.label(text=_t('Files'), icon='EXPORT')
        out_box.prop(self, 'path_remap', text='Path Remap')
        out_box.prop(self, 'external_files_mode', text='External Files')
        if self.external_files_mode in {'COPY', 'COPY_PACK_SCRIPT'}:
            out_box.prop(self, 'external_files_subdir', text='Subfolder')
        out_box.prop(self, 'open_folder_after', text='Open Folder After')

        meta_box = left.box()
        meta_box.label(text=_t('Metadata'), icon='FILE_TEXT')
        meta_box.prop(self, 'category')
        meta_box.prop(self, 'tags')
        meta_box.prop(self, 'notes')
        meta_box.prop(self, 'create_meta', text='Write Metadata')
        meta_box.prop(self, 'append_changelog', text='Append Changelog')

        helper_box = right.box()
        helper_box.label(text=_t('Preview'), icon='RENDER_STILL')
        helper_box.prop(self, 'generate_preview', text='Generate Preview')
        sub = helper_box.column(align=True)
        sub.enabled = bool(self.generate_preview)
        sub.prop(self, 'preview_mode', text='Mode')

        cat_box = right.box()
        cat_box.label(text=_t('Catalog'), icon='BOOKMARKS')
        cat_box.prop(self, 'update_catalog', text='Update Catalog')
        sub = cat_box.column(align=True)
        sub.enabled = bool(self.update_catalog)
        sub.prop(self, 'catalog_filename', text='File Name')

    def execute(self, context):
        prefs = _addon_prefs(context)
        tdir = _norm_path(self.target_dir) if self.target_dir else ""
        if not tdir:
            self.report({'ERROR'}, _t('Target Folder'))
            return {'CANCELLED'}

        os.makedirs(tdir, exist_ok=True)

        asset = _safe_filename(self.asset_name)
        pad = int(getattr(prefs, "pub_version_padding", 3) or 3) if prefs else 3

        # Determine version number
        ver = int(self.version)
        if self.versioning == 'AUTO':
            try:
                rgx = re.compile(rf"^{re.escape(asset)}_v(\d+)\.blend$", re.IGNORECASE)
                maxv = 0
                for fn in os.listdir(tdir):
                    m = rgx.match(fn)
                    if m:
                        maxv = max(maxv, int(m.group(1)))
                ver = maxv + 1 if maxv > 0 else 1
            except Exception:
                ver = 1

        vstr = f"v{ver:0{pad}d}"
        out_base = f"{asset}_{vstr}"
        out_blend = os.path.join(tdir, out_base + ".blend")
        out_png = os.path.join(tdir, out_base + ".png")
        out_meta = os.path.join(tdir, out_base + ".meta.json")
        out_log = os.path.join(tdir, f"{asset}.changelog.txt")


        # Stable Asset ID (UUID)
        asset_id = ""
        try:
            cat_path_guess = os.path.join(tdir, getattr(prefs, "pub_catalog_filename", "catalog.json")) if prefs else os.path.join(tdir, "catalog.json")
            if os.path.exists(cat_path_guess):
                with open(cat_path_guess, "r", encoding="utf-8") as _f:
                    _cat = json.load(_f) or {}
                _a = ((_cat.get("assets") or {}).get(asset) or {})
                asset_id = str(_a.get("asset_id") or "")
        except Exception:
            asset_id = ""
        if not asset_id:
            asset_id = _pub_generate_asset_id(prefs, asset)

        # Collect root IDs
        root_ids = set()
        tmp_coll = None

        if self.source == 'ACTIVE_COLLECTION':
            coll = getattr(context, "collection", None)
            if not coll:
                self.report({'ERROR'}, _t('Nothing to publish'))
                return {'CANCELLED'}
            root_ids.add(coll)
            publish_coll = coll
        else:
            sel = list(context.selected_objects)
            if not sel:
                self.report({'ERROR'}, _t('Nothing to publish'))
                return {'CANCELLED'}
            tmp_coll = bpy.data.collections.new(f"SF_PUBLISH__{out_base}")
            for o in sel:
                try:
                    tmp_coll.objects.link(o)
                except Exception:
                    pass
            root_ids.add(tmp_coll)
            publish_coll = tmp_coll

        # External asset risks (best-effort)
        ext_records = _sf_ext_collect_from_root_ids(list(root_ids), include_libraries=False, include_texts=False, include_missing=True)
        ext_summary = _sf_ext_summary(ext_records)
        img_details = [
            {
                "name": str(rec.get('name') or ''),
                "filepath": str(rec.get('abs_path') or rec.get('raw_path') or ''),
                "missing": bool((not rec.get('exists')) and (not rec.get('packed'))),
                "absolute": str(rec.get('path_style') or '') == 'ABSOLUTE',
            }
            for rec in ext_records
            if str(rec.get('kind_key') or '') == 'IMAGE' and (
                (not rec.get('exists') and not rec.get('packed')) or str(rec.get('path_style') or '') == 'ABSOLUTE'
            )
        ][:200]
        miss = sum(1 for rec in ext_records if str(rec.get('kind_key') or '') == 'IMAGE' and (not rec.get('exists')) and (not rec.get('packed')))
        abs_paths = sum(1 for rec in ext_records if str(rec.get('kind_key') or '') == 'IMAGE' and str(rec.get('path_style') or '') == 'ABSOLUTE')

        # External files (images + movies + sounds + fonts + volumes + caches)
        ext_mode = getattr(self, "external_files_mode", "NONE")
        ext_subdir = getattr(self, "external_files_subdir", "") or (getattr(prefs, "pub_ext_files_subdir", "textures") if prefs else "textures")
        copy_result = {"copied_files": [], "remap": {}, "stats": {"missing_records": 0, "packed_records": 0, "copied_records": 0, "copied_files": 0}, "manifest_rows": []}
        copied_files = []
        orig_ext_paths = []
        pack_script = ""

        if ext_mode in {'COPY', 'COPY_PACK_SCRIPT'} and ext_records:
            try:
                copy_result = _sf_ext_copy_records(
                    ext_records,
                    tdir,
                    subdir=ext_subdir,
                    remap_mode='ABSOLUTE' if self.path_remap == 'ABSOLUTE' else 'RELATIVE',
                    flat_images_when_possible=True,
                )
                copied_files = list(copy_result.get('copied_files', []) or [])
                orig_ext_paths = _sf_ext_apply_remap(ext_records, copy_result.get('remap', {}))
            except Exception:
                copy_result = {"copied_files": [], "remap": {}, "stats": {"missing_records": 0, "packed_records": 0, "copied_records": 0, "copied_files": 0}, "manifest_rows": []}
                copied_files = []
                orig_ext_paths = []

        # Write library .blend
        try:
            remap = self.path_remap
            if remap == 'NONE':
                remap = 'NONE'
            bpy.data.libraries.write(out_blend, root_ids, path_remap=remap)
        except Exception as e:
            # Cleanup tmp
            if tmp_coll:
                try:
                    bpy.data.collections.remove(tmp_coll, do_unlink=True)
                except Exception:
                    pass
            # Restore external file paths if we remapped them
            try:
                _sf_ext_restore_paths(orig_ext_paths)
            except Exception:
                pass
            self.report({'ERROR'}, _t('Publish failed') + f": {e}")
            return {'CANCELLED'}
        finally:
            try:
                _sf_ext_restore_paths(orig_ext_paths)
            except Exception:
                pass

        # Preview render
        preview_ok = False
        if self.generate_preview and self.preview_mode == 'EEVEE':
            preview_ok = _render_preview_png(out_png, publish_coll, resolution=int(getattr(prefs, "thumb_resolution", 256) or 256) if prefs else 256)

        # Cleanup tmp
        if tmp_coll:
            try:
                bpy.data.collections.remove(tmp_coll, do_unlink=True)
            except Exception:
                pass

        # Metadata / changelog
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        exported_roots = []
        try:
            for rid in root_ids:
                if isinstance(rid, bpy.types.Collection):
                    exported_roots.append({"type": "COLLECTION", "name": rid.name})
                elif isinstance(rid, bpy.types.Object):
                    exported_roots.append({"type": "OBJECT", "name": rid.name})
                else:
                    exported_roots.append({"type": rid.__class__.__name__.upper(), "name": getattr(rid, "name", "")})
        except Exception:
            pass

        tags_list = []
        try:
            tags_list = [t.strip() for t in (self.tags or "").split(",") if t.strip()]
        except Exception:
            tags_list = []

        # Optional pack helper script
        if ext_mode == 'COPY_PACK_SCRIPT':
            try:
                pack_script = os.path.join(tdir, out_base + "_PACK.py")
                _write_pack_helper_script(pack_script, out_blend)
            except Exception:
                pack_script = ""
        meta = {
            "asset": asset,
            "asset_id": asset_id,
            "version": ver,
            "version_str": vstr,
            "published_at": now,
            "source_blend": _norm_path(bpy.data.filepath or ""),
            "source_mode": self.source,
            "output_blend": _norm_path(out_blend),
            "output_preview": _norm_path(out_png) if preview_ok else "",
            "notes": self.notes or "",
            "category": self.category or "",
            "tags": tags_list,
            "exported_roots": exported_roots,
            "external_files": {
                "mode": ext_mode,
                "subdir": ext_subdir if ext_mode in {'COPY', 'COPY_PACK_SCRIPT'} else "",
                "copied_records": int(((copy_result.get("stats", {}) or {}).get("copied_records", 0)) or 0),
                "copied_files_count": int(((copy_result.get("stats", {}) or {}).get("copied_files", 0)) or 0),
                "packed_records": int(((copy_result.get("stats", {}) or {}).get("packed_records", 0)) or 0),
                "missing_records": int(((copy_result.get("stats", {}) or {}).get("missing_records", 0)) or 0),
                "copied_files": [_norm_path(p) for p in copied_files[:500]],
                "manifest_rows": list(copy_result.get("manifest_rows", []) or [])[:500],
                "pack_helper_script": _norm_path(pack_script) if pack_script else "",
            },
            "path_remap": self.path_remap,
            "external_risk": {
                "total_records": int(ext_summary.get("total_records", 0) or 0),
                "missing_records": int(ext_summary.get("missing_records", 0) or 0),
                "absolute_records": int(ext_summary.get("absolute_records", 0) or 0),
                "relative_records": int(ext_summary.get("relative_records", 0) or 0),
                "env_records": int(ext_summary.get("env_records", 0) or 0),
                "packed_records": int(ext_summary.get("packed_records", 0) or 0),
                "sequence_records": int(ext_summary.get("sequence_records", 0) or 0),
                "kinds": ext_summary.get("kinds", {}),
                "details": [
                    {
                        "kind": str(rec.get("kind_label") or ""),
                        "name": str(rec.get("name") or ""),
                        "raw_path": str(rec.get("raw_path") or ""),
                        "abs_path": str(rec.get("abs_path") or ""),
                        "packed": bool(rec.get("packed")),
                        "exists": bool(rec.get("exists")),
                        "path_style": str(rec.get("path_style") or ""),
                        "sequence_mode": str(rec.get("sequence_mode") or "FILE"),
                    }
                    for rec in ext_records
                    if bool(rec.get("packed")) or (not bool(rec.get("exists"))) or str(rec.get("path_style") or "") in {'ABSOLUTE', 'ENV'}
                ][:200],
            },
            "image_risk": {
                "missing_textures": miss,
                "absolute_paths": abs_paths,
                "details": img_details[:200],
            },
        }

        if self.create_meta:
            _write_meta_json(out_meta, meta)

        if self.append_changelog:
            line = f"[{now}] {out_base} | missing_ext={int(ext_summary.get('missing_records', 0) or 0)} abs_ext={int(ext_summary.get('absolute_records', 0) or 0)} packed_ext={int(ext_summary.get('packed_records', 0) or 0)} | {self.notes or ''}"
            _append_changelog(out_log, line)

        # Update catalog (optional)
        if getattr(self, "update_catalog", True):
            try:
                cat_name = _safe_filename(self.catalog_filename) or (getattr(prefs, "pub_catalog_filename", "catalog.json") if prefs else "catalog.json")
                cat_path = os.path.join(tdir, cat_name)
                entry = {
                    "asset": asset,
                    "version": ver,
                    "asset_id": asset_id,
                    "version": ver,
                    "version_str": vstr,
                    "blend": os.path.basename(out_blend),
                    "preview": os.path.basename(out_png) if preview_ok else "",
                    "meta": os.path.basename(out_meta) if self.create_meta else "",
                    "published_at": now,
                    "category": self.category or "",
                    "tags": tags_list,
                }
                _update_catalog_json(cat_path, entry, asset_key=asset)
            except Exception:
                pass

        if self.open_folder_after:
            try:
                bpy.ops.wm.path_open(filepath=tdir)
            except Exception:
                pass

        self.report({'INFO'}, _t('Publish successful') + f": {out_blend}")
        return {'FINISHED'}
