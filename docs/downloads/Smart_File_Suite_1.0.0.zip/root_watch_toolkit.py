# -----------------------------------------------------------------------------
#  Root Watch Toolkit / Watch Folders / Drift Detection / Snapshot Compare
# -----------------------------------------------------------------------------

import datetime
import json
import os
import time


_SF_WATCH_SCHEMA = 1
_SF_WATCH_DIRNAME = "root_watch"
_SF_WATCH_SNAPSHOT_FILENAME = "root_watch_snapshot_v1.json"
_SF_WATCH_STATUS_FILENAME = "root_watch_status_v1.json"
_SF_WATCH_STATUS_CACHE_PATH = ""
_SF_WATCH_STATUS_CACHE_SIGNATURE = None
_SF_WATCH_STATUS_CACHE_DATA = None

_SF_WATCH_KIND_SUFFIXES = [
    ('.blend', 'LIBRARY'),
    ('.bgeo.sc', 'CACHEFILE'),
    ('.abc', 'CACHEFILE'),
    ('.usd', 'CACHEFILE'),
    ('.usda', 'CACHEFILE'),
    ('.usdc', 'CACHEFILE'),
    ('.usdz', 'CACHEFILE'),
    ('.fbx', 'CACHEFILE'),
    ('.obj', 'CACHEFILE'),
    ('.ply', 'CACHEFILE'),
    ('.stl', 'CACHEFILE'),
    ('.pc2', 'CACHEFILE'),
    ('.mdd', 'CACHEFILE'),
    ('.vdb', 'VOLUME'),
    ('.exr', 'IMAGE'),
    ('.hdr', 'IMAGE'),
    ('.hdri', 'IMAGE'),
    ('.png', 'IMAGE'),
    ('.jpg', 'IMAGE'),
    ('.jpeg', 'IMAGE'),
    ('.tif', 'IMAGE'),
    ('.tiff', 'IMAGE'),
    ('.tga', 'IMAGE'),
    ('.bmp', 'IMAGE'),
    ('.gif', 'IMAGE'),
    ('.webp', 'IMAGE'),
    ('.dds', 'IMAGE'),
    ('.tx', 'IMAGE'),
    ('.ktx2', 'IMAGE'),
    ('.mov', 'MOVIECLIP'),
    ('.mp4', 'MOVIECLIP'),
    ('.m4v', 'MOVIECLIP'),
    ('.avi', 'MOVIECLIP'),
    ('.mkv', 'MOVIECLIP'),
    ('.wmv', 'MOVIECLIP'),
    ('.webm', 'MOVIECLIP'),
    ('.mxf', 'MOVIECLIP'),
    ('.wav', 'SOUND'),
    ('.mp3', 'SOUND'),
    ('.ogg', 'SOUND'),
    ('.flac', 'SOUND'),
    ('.aif', 'SOUND'),
    ('.aiff', 'SOUND'),
    ('.m4a', 'SOUND'),
    ('.ttf', 'VECTORFONT'),
    ('.otf', 'VECTORFONT'),
    ('.woff', 'VECTORFONT'),
    ('.woff2', 'VECTORFONT'),
    ('.txt', 'TEXT'),
    ('.json', 'TEXT'),
    ('.csv', 'TEXT'),
    ('.xml', 'TEXT'),
    ('.yaml', 'TEXT'),
    ('.yml', 'TEXT'),
    ('.py', 'TEXT'),
]
_SF_WATCH_KIND_SUFFIXES.sort(key=lambda item: len(item[0]), reverse=True)


def _sf_watch_cache_dir() -> str:
    path = os.path.join(_addon_cache_dir(), _SF_WATCH_DIRNAME)
    os.makedirs(path, exist_ok=True)
    return path



def _sf_watch_snapshot_path() -> str:
    return os.path.join(_sf_watch_cache_dir(), _SF_WATCH_SNAPSHOT_FILENAME)



def _sf_watch_status_path() -> str:
    return os.path.join(_sf_watch_cache_dir(), _SF_WATCH_STATUS_FILENAME)


def _sf_watch_file_signature(path: str):
    path = _norm_path(path or '')
    try:
        st = os.stat(path)
        return (path, int(getattr(st, 'st_mtime_ns', int(st.st_mtime * 1000000000))), int(st.st_size))
    except Exception:
        return (path, -1, -1)


def _sf_watch_invalidate_status_cache() -> None:
    global _SF_WATCH_STATUS_CACHE_PATH, _SF_WATCH_STATUS_CACHE_SIGNATURE, _SF_WATCH_STATUS_CACHE_DATA
    _SF_WATCH_STATUS_CACHE_PATH = ''
    _SF_WATCH_STATUS_CACHE_SIGNATURE = None
    _SF_WATCH_STATUS_CACHE_DATA = None



def _sf_watch_read_json(path: str, default=None):
    path = _norm_path(path or '')
    if not path or not os.path.exists(path):
        return default
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except Exception:
        return default



def _sf_watch_write_json(path: str, payload: dict) -> bool:
    path = _norm_path(path or '')
    if not path:
        return False
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False



def _sf_watch_kind_from_path(filepath: str, scan_mode: str = 'KNOWN_PORTABLE') -> str:
    low = str(filepath or '').lower()
    if not low:
        return 'UNKNOWN'
    if str(scan_mode or 'KNOWN_PORTABLE').upper() == 'BLENDS_ONLY':
        return 'LIBRARY' if low.endswith('.blend') else ''
    for suffix, kind in _SF_WATCH_KIND_SUFFIXES:
        if low.endswith(suffix):
            return kind
    if str(scan_mode or 'KNOWN_PORTABLE').upper() == 'ALL_FILES':
        return 'UNKNOWN'
    return ''



def _sf_watch_kind_label(kind_key: str) -> str:
    kind_key = str(kind_key or 'UNKNOWN').upper()
    info = _SF_EXT_KIND_INFO.get(kind_key, _SF_EXT_KIND_INFO.get('UNKNOWN', {}))
    return str(info.get('label') or kind_key.title())



def _sf_watch_kind_filters_label(kind_filters) -> str:
    filters = [str(item or '').upper() for item in list(kind_filters or []) if str(item or '').strip()]
    if not filters or 'ANY' in filters:
        return _t('All supported kinds')
    return ','.join(_sf_watch_kind_label(kind) for kind in filters)



def _sf_watch_source_labels(sources) -> str:
    mapping = {
        'context': 'Context Root',
        'library_root': 'Library Root',
        'manifest': 'Manifest',
        'search_root': 'Search Root',
    }
    labels = []
    seen = set()
    for source in list(sources or []):
        key = str(source or '').strip().lower()
        if not key:
            continue
        label = mapping.get(key, key.replace('_', '').title())
        if not label or label in seen:
            continue
        seen.add(label)
        labels.append(_t(label))
    return ','.join(labels)



def _sf_watch_root_alias_score(row: dict) -> tuple[int, int, int, int, int]:
    row = dict(row or {})
    alias = str(row.get('alias') or '').strip()
    path = _norm_path(str(row.get('path') or ''))
    auto_alias = _sf_ctx_guess_alias(path or 'ROOT') if path else ''
    sources = {str(item).strip() for item in list(row.get('sources') or []) if str(item).strip()}
    if row.get('source'):
        sources.add(str(row.get('source') or '').strip())
    return (
        1 if alias else 0,
        1 if alias and alias != auto_alias else 0,
        1 if 'context' in sources else 0,
        int(row.get('priority', 0) or 0),
        len(alias),
    )



def _sf_watch_merge_root_row(existing: dict | None, incoming: dict) -> dict:
    incoming = dict(incoming or {})
    incoming_filters = {str(item or '').upper() for item in list(incoming.get('kind_filters') or []) if str(item or '').strip()}
    if not incoming_filters:
        incoming_filters = {str(incoming.get('kind') or 'ANY').upper()}
    incoming['kind_filters'] = ['ANY'] if 'ANY' in incoming_filters else sorted(incoming_filters)
    if not existing:
        row = dict(incoming)
        sources = {str(item).strip() for item in list(row.get('sources') or []) if str(item).strip()}
        if row.get('source'):
            sources.add(str(row.get('source') or '').strip())
        row['sources'] = sorted(sources)
        row['notes'] = str(row.get('notes') or '').strip()
        if not row.get('alias'):
            row['alias'] = _sf_ctx_guess_alias(str(row.get('path') or 'ROOT'))
        return row

    merged = dict(existing or {})
    merged_sources = {str(item).strip() for item in list(merged.get('sources') or []) if str(item).strip()}
    if merged.get('source'):
        merged_sources.add(str(merged.get('source') or '').strip())
    if incoming.get('source'):
        merged_sources.add(str(incoming.get('source') or '').strip())
    for item in list(incoming.get('sources') or []):
        clean = str(item).strip()
        if clean:
            merged_sources.add(clean)
    merged['sources'] = sorted(merged_sources)
    merged['source'] = 'context' if 'context' in merged_sources else (merged['sources'][0] if merged['sources'] else str(incoming.get('source') or merged.get('source') or 'context'))

    merged_filters = {str(item).strip().upper() for item in list(merged.get('kind_filters') or []) if str(item).strip()}
    merged_filters.update({str(item).strip().upper() for item in list(incoming.get('kind_filters') or []) if str(item).strip()})
    merged['kind_filters'] = ['ANY'] if ('ANY' in merged_filters or not merged_filters) else sorted(merged_filters)
    merged['priority'] = max(int(merged.get('priority', 0) or 0), int(incoming.get('priority', 0) or 0))
    merged['enabled'] = bool(merged.get('enabled', True) or incoming.get('enabled', True))
    merged['notes'] = _sf_ctx_notes_merge(str(merged.get('notes') or ''), str(incoming.get('notes') or ''))
    if _sf_watch_root_alias_score(incoming) > _sf_watch_root_alias_score(merged):
        merged['alias'] = str(incoming.get('alias') or _sf_ctx_guess_alias(str(incoming.get('path') or 'ROOT')))
    return merged



def _sf_watch_collect_root_rows(context) -> list[dict]:
    raw_rows = []
    try:
        raw_rows.extend(_sf_ctx_root_rows(context, kind_key='ANY', existing_only=False, include_library_roots=True))
    except Exception:
        raw_rows = []

    if not raw_rows:
        prefs = _addon_prefs(context)
        for idx, item in enumerate(list(getattr(prefs, 'library_roots', []) or []) if prefs else []):
            if not bool(getattr(item, 'enabled', True)):
                continue
            path = _norm_path(str(getattr(item, 'path', '') or ''))
            if not path:
                continue
            raw_rows.append({
                'alias': _sf_slugify(os.path.basename(path) or f'root_{idx + 1}') or f'root_{idx + 1}',
                'path': path,
                'priority': int(getattr(item, 'priority', 0) or 0),
                'enabled': True,
                'kind': 'LIBRARY',
                'source': 'library_root',
                'notes': '',
            })

    rows_by_path = {}
    for idx, row in enumerate(list(raw_rows or [])):
        path = _norm_path(str((row or {}).get('path') or ''))
        if not path:
            continue
        alias = str((row or {}).get('alias') or '').strip() or (_sf_slugify(os.path.basename(path) or f'root_{idx + 1}') or f'root_{idx + 1}')
        entry = {
            'alias': alias,
            'path': path,
            'priority': int((row or {}).get('priority', 0) or 0),
            'enabled': bool((row or {}).get('enabled', True)),
            'kind_filters': [str((row or {}).get('kind') or 'ANY').upper()],
            'notes': str((row or {}).get('notes') or ''),
            'source': str((row or {}).get('source') or 'context'),
            'sources': list((row or {}).get('sources') or []),
        }
        rows_by_path[path] = _sf_watch_merge_root_row(rows_by_path.get(path), entry)

    rows = list(rows_by_path.values())
    rows.sort(
        key=lambda row: (
            int(row.get('priority', 0) or 0),
            len(str(row.get('path', '') or '')),
            _sf_watch_root_alias_score(row),
        ),
        reverse=True,
    )
    return rows



def _sf_watch_kind_allowed(root_row: dict | None, file_kind: str) -> bool:
    filters = [str(item or '').upper() for item in list((root_row or {}).get('kind_filters') or []) if str(item or '').strip()]
    if not filters or 'ANY' in filters:
        return True
    return str(file_kind or '').upper() in set(filters)



def _sf_watch_iter_root_files(root_path: str, scan_mode: str = 'KNOWN_PORTABLE', *, root_row: dict | None = None):
    root_path = _norm_path(root_path or '')
    if not root_path or not os.path.isdir(root_path):
        return
    for dirpath, dirnames, filenames in os.walk(root_path):
        dirnames[:] = [
            d for d in list(dirnames)
            if d and (not d.startswith('.')) and d.lower() not in {'__pycache__'}
        ]
        for filename in list(filenames):
            if not filename or filename.startswith('.'):
                continue
            abs_path = _norm_path(os.path.join(dirpath, filename))
            kind = _sf_watch_kind_from_path(abs_path, scan_mode=scan_mode)
            if not kind or not _sf_watch_kind_allowed(root_row, kind):
                continue
            yield abs_path, kind



def _sf_watch_payload_summary(files_map: dict) -> dict:
    summary = {
        'total_files': 0,
        'kinds': {},
        'roots': {},
    }
    for row in list((files_map or {}).values()):
        kind_key = str(row.get('kind', 'UNKNOWN') or 'UNKNOWN').upper()
        root_key = str(row.get('root_path', '') or '')
        summary['total_files'] += 1
        kind_row = summary['kinds'].setdefault(kind_key, {'label': _sf_watch_kind_label(kind_key), 'count': 0})
        kind_row['count'] += 1
        root_row = summary['roots'].setdefault(root_key, {'count': 0})
        root_row['count'] += 1
    summary['kinds_rows'] = [summary['kinds'][key] | {'kind': key} for key in sorted(summary['kinds'].keys())]
    return summary



def _sf_watch_build_snapshot_payload(context, *, scan_mode: str = 'KNOWN_PORTABLE') -> dict:
    rows = _sf_watch_collect_root_rows(context)
    files = {}
    for root in rows:
        root_path = _norm_path(root.get('path') or '')
        if not root_path or not os.path.isdir(root_path):
            continue
        for abs_path, kind in _sf_watch_iter_root_files(root_path, scan_mode=scan_mode, root_row=root):
            try:
                rel_path = os.path.relpath(abs_path, root_path)
            except Exception:
                rel_path = abs_path[len(root_path):].lstrip('/\\')
            rel_path = str(rel_path or '').replace('\\', '/')
            key = f"{root_path}::{rel_path}"
            try:
                st = os.stat(abs_path)
                mtime = int(st.st_mtime)
                size = int(st.st_size)
            except Exception:
                mtime = 0
                size = 0
            files[key] = {
                'root_alias': str(root.get('alias') or ''),
                'root_path': root_path,
                'root_kind_filters': list(root.get('kind_filters') or ['ANY']),
                'root_sources': list(root.get('sources') or []),
                'rel_path': rel_path,
                'kind': str(kind or 'UNKNOWN').upper(),
                'kind_label': _sf_watch_kind_label(kind),
                'mtime': mtime,
                'size': size,
            }
    payload = {
        'schema': _SF_WATCH_SCHEMA,
        'created': time.time(),
        'created_label': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'scan_mode': str(scan_mode or 'KNOWN_PORTABLE').upper(),
        'roots': rows,
        'files': files,
    }
    payload['summary'] = _sf_watch_payload_summary(files)
    return payload



def _sf_watch_diff_payload(previous: dict | None, current: dict | None) -> dict:
    prev_files = dict((previous or {}).get('files') or {})
    curr_files = dict((current or {}).get('files') or {})
    prev_keys = set(prev_files.keys())
    curr_keys = set(curr_files.keys())

    added_keys = sorted(curr_keys - prev_keys)
    removed_keys = sorted(prev_keys - curr_keys)
    common_keys = sorted(prev_keys & curr_keys)
    changed_keys = []
    unchanged = 0

    for key in common_keys:
        prev_row = dict(prev_files.get(key) or {})
        curr_row = dict(curr_files.get(key) or {})
        if (
            int(prev_row.get('mtime', 0) or 0) != int(curr_row.get('mtime', 0) or 0)
            or int(prev_row.get('size', 0) or 0) != int(curr_row.get('size', 0) or 0)
            or str(prev_row.get('kind', '') or '') != str(curr_row.get('kind', '') or '')
        ):
            changed_keys.append(key)
        else:
            unchanged += 1

    def preview_from(keys: list[str], source: dict, other: dict | None = None, *, changed: bool = False):
        out = []
        for key in list(keys)[:8]:
            row = dict(source.get(key) or {})
            if not row:
                continue
            label = f"{row.get('root_alias','root')}://{row.get('rel_path','')}"
            entry = {
                'kind': str(row.get('kind_label') or _sf_watch_kind_label(row.get('kind') or 'UNKNOWN')),
                'label': label,
                'size': int(row.get('size', 0) or 0),
                'mtime': int(row.get('mtime', 0) or 0),
            }
            if changed and other is not None:
                prev_row = dict(other.get(key) or {})
                entry['prev_size'] = int(prev_row.get('size', 0) or 0)
                entry['prev_mtime'] = int(prev_row.get('mtime', 0) or 0)
            out.append(entry)
        return out

    return {
        'added': len(added_keys),
        'removed': len(removed_keys),
        'changed': len(changed_keys),
        'unchanged': int(unchanged),
        'preview_added': preview_from(added_keys, curr_files),
        'preview_removed': preview_from(removed_keys, prev_files),
        'preview_changed': preview_from(changed_keys, curr_files, other=prev_files, changed=True),
    }



def _sf_watch_status_payload(context, *, current: dict | None = None, previous: dict | None = None) -> dict:
    if current is None:
        current = _sf_watch_build_snapshot_payload(context)
    if previous is None:
        previous = _sf_watch_read_json(_sf_watch_snapshot_path(), default={}) or {}
    diff = _sf_watch_diff_payload(previous, current) if previous else {
        'added': 0,
        'removed': 0,
        'changed': 0,
        'unchanged': int(dict((current or {}).get('summary') or {}).get('total_files', 0) or 0),
        'preview_added': [],
        'preview_removed': [],
        'preview_changed': [],
    }
    previous_created = float((previous or {}).get('created', 0.0) or 0.0)
    age_seconds = int(max(0.0, time.time() - previous_created)) if previous_created else 0
    return {
        'schema': _SF_WATCH_SCHEMA,
        'generated': time.time(),
        'generated_label': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'snapshot_exists': bool(previous),
        'snapshot_created': previous_created,
        'snapshot_created_label': str((previous or {}).get('created_label') or ''),
        'snapshot_age_seconds': age_seconds,
        'scan_mode': str((current or {}).get('scan_mode') or 'KNOWN_PORTABLE'),
        'roots_count': len(list((current or {}).get('roots') or [])),
        'current_summary': dict((current or {}).get('summary') or {}),
        'diff_summary': diff,
    }



def _sf_watch_load_status() -> dict:
    global _SF_WATCH_STATUS_CACHE_PATH, _SF_WATCH_STATUS_CACHE_SIGNATURE, _SF_WATCH_STATUS_CACHE_DATA
    path = _sf_watch_status_path()
    signature = _sf_watch_file_signature(path)
    if (
        _SF_WATCH_STATUS_CACHE_PATH == signature[0]
        and _SF_WATCH_STATUS_CACHE_SIGNATURE == signature
        and isinstance(_SF_WATCH_STATUS_CACHE_DATA, dict)
    ):
        return _SF_WATCH_STATUS_CACHE_DATA
    data = _sf_watch_read_json(path, default={}) or {}
    if int(data.get('schema', 0) or 0) != _SF_WATCH_SCHEMA:
        data = {}
    _SF_WATCH_STATUS_CACHE_PATH = signature[0]
    _SF_WATCH_STATUS_CACHE_SIGNATURE = signature
    _SF_WATCH_STATUS_CACHE_DATA = data
    return data



def _sf_watch_next_action(status: dict) -> str:
    if not status:
        return _t('Capture Snapshot')
    if not bool(status.get('snapshot_exists')):
        return _t('Capture Snapshot')
    diff = dict(status.get('diff_summary') or {})
    if int(diff.get('added', 0) or 0) > 0 or int(diff.get('removed', 0) or 0) > 0 or int(diff.get('changed', 0) or 0) > 0:
        return _t('Export Drift Report')
    return _t('Roots look stable')



def _sf_watch_write_status(context, *, current: dict | None = None, previous: dict | None = None) -> dict:
    payload = _sf_watch_status_payload(context, current=current, previous=previous)
    _sf_watch_write_json(_sf_watch_status_path(), payload)
    _sf_watch_invalidate_status_cache()
    return payload



def _sf_watch_report_lines(context, title: str, status: dict, current: dict | None = None, previous: dict | None = None) -> list[str]:
    current = dict(current or {})
    previous = dict(previous or {})
    status = dict(status or {})
    diff = dict(status.get('diff_summary') or {})
    summary = dict(status.get('current_summary') or {})
    data = _sf_collect_report_context(context)
    lines = _sf_report_lines_header(title, data)
    lines.extend([
        f"- {_t('Scan Mode')}: {status.get('scan_mode') or ''}",
        f"- {_t('Enabled Roots')}: {int(status.get('roots_count', 0) or 0)}",
        f"- {_t('Snapshot')}: {status.get('snapshot_created_label') or _t('Not set')}",
        f"- {_t('Total Files')}: {int(summary.get('total_files', 0) or 0)}",
        f"- {_t('Added')}: {int(diff.get('added', 0) or 0)}",
        f"- {_t('Removed')}: {int(diff.get('removed', 0) or 0)}",
        f"- {_t('Changed')}: {int(diff.get('changed', 0) or 0)}",
        f"- {_t('Unchanged')}: {int(diff.get('unchanged', 0) or 0)}",
    ])
    roots = list((current or {}).get('roots') or [])
    if roots:
        lines.extend(['', 'WATCH ROOTS'])
        for row in roots[:12]:
            source_label = _sf_watch_source_labels(list(row.get('sources') or [row.get('source') or 'context']))
            lines.append(
                f"- {row.get('alias','root')} | {_sf_watch_kind_filters_label(row.get('kind_filters') or [])} | {source_label} | {row.get('path','')}"
            )

    lines.extend(['', 'KINDS'])
    for row in list(summary.get('kinds_rows') or []):
        lines.append(f"- {row.get('label','')}: {int(row.get('count', 0) or 0)}")

    if diff.get('preview_added'):
        lines.extend(['', 'ADDED'])
        for row in list(diff.get('preview_added') or []):
            lines.append(f"- [{row.get('kind','')}] {row.get('label','')} | size={int(row.get('size', 0) or 0)}")
    if diff.get('preview_removed'):
        lines.extend(['', 'REMOVED'])
        for row in list(diff.get('preview_removed') or []):
            lines.append(f"- [{row.get('kind','')}] {row.get('label','')}")
    if diff.get('preview_changed'):
        lines.extend(['', 'CHANGED'])
        for row in list(diff.get('preview_changed') or []):
            lines.append(
                f"- [{row.get('kind','')}] {row.get('label','')} | size {int(row.get('prev_size', 0) or 0)} -> {int(row.get('size', 0) or 0)}"
            )
    lines.extend(['', *(_sf_report_export_notes_lines(title, data) or [])])
    return lines



class SF_OT_root_watch_open(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = 'import_scene.sfs_root_watch_open'
    bl_label = 'Open'
    bl_description = 'Open a compact watch-folder board for effective watch roots so you can snapshot a stable project state, detect added or removed files, and export a drift report before relink, publish, or farm handoff work. It covers Library Roots and named Context Roots together.'
    bl_options = {'INTERNAL'}

    popup_width: IntProperty(default=680, min=560, max=920, options={'HIDDEN'})

    def invoke(self, context, event):
        _sf_append_activity(context, _t('Opened Root Watch'), _norm_path(bpy.data.filepath or ''), 'FILE_REFRESH')
        return context.window_manager.invoke_popup(self, width=self.popup_width)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        prefs = _addon_prefs(context)
        wm = getattr(context, 'window_manager', None)
        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '') if wm is not None else ''
        has_source = bool(filepath and os.path.isfile(filepath))
        watch_rows = _sf_watch_collect_root_rows(context)
        roots_ready = bool(watch_rows)
        try:
            index = _load_index()
        except Exception:
            index = {}
        index_ready = bool(len((index or {}).get('files', {}) or {}))
        source_info = _sf_get_source_insights(prefs, filepath, index)
        health_score, _label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)
        actions = _sf_build_recommended_actions(context, prefs, filepath, source_info, roots_ready, index_ready, health_score)
        status = _sf_watch_load_status()
        diff = dict(status.get('diff_summary') or {})
        summary = dict(status.get('current_summary') or {})
        next_action = _sf_watch_next_action(status)
        scoped_roots = [row for row in watch_rows if 'ANY' not in list(row.get('kind_filters') or ['ANY'])]
        context_backed_roots = [
            row for row in watch_rows
            if 'context' in {str(item).strip() for item in list(row.get('sources') or [row.get('source') or 'context']) if str(item).strip()}
        ]

        _sf_draw_dialog_header(
            layout,
            'Root Watch',
            'Snapshot the effective watch roots, then compare later to catch added, removed, or changed files before a wider relink, publish, queue, or handoff run.',
            'FILE_REFRESH',
        )
        _sf_draw_source_root_profile_matrix(layout, context, prefs, filepath, source_info, roots_ready, index_ready, actions, compact=False)

        state = layout.box()
        _sf_draw_section_intro(
            state,
            'Watch Snapshot',
            'Use this like a watch-folder or drift sentinel for the effective watch roots. It now understands both Library Roots and named Context Roots, and it respects per-root kind scopes when they are configured.',
            'FILE_REFRESH',
        )
        _sf_draw_state_line(state, 'Enabled Roots', 'READY' if watch_rows else 'NOT SET', detail=str(len(watch_rows)))
        _sf_draw_state_line(state, 'Context-backed Roots', 'READY' if context_backed_roots else 'NOT SET', detail=str(len(context_backed_roots)))
        _sf_draw_state_line(state, 'Scoped Roots', 'READY' if scoped_roots else 'NOT SET', detail=str(len(scoped_roots)))
        _sf_draw_state_line(state, 'Snapshot', 'READY' if bool(status.get('snapshot_exists')) else 'NOT SET', detail=(status.get('snapshot_created_label') or _t('Not set')))
        _sf_draw_state_line(state, 'Total Files', 'READY' if int(summary.get('total_files', 0) or 0) > 0 else 'NOT SET', detail=str(int(summary.get('total_files', 0) or 0)))
        _sf_draw_state_line(state, 'Added', 'OK' if int(diff.get('added', 0) or 0) == 0 else 'REVIEW', detail=str(int(diff.get('added', 0) or 0)))
        _sf_draw_state_line(state, 'Removed', 'OK' if int(diff.get('removed', 0) or 0) == 0 else 'NEEDS ATTENTION', detail=str(int(diff.get('removed', 0) or 0)))
        _sf_draw_state_line(state, 'Changed', 'OK' if int(diff.get('changed', 0) or 0) == 0 else 'REVIEW', detail=str(int(diff.get('changed', 0) or 0)))
        _sf_draw_state_line(state, 'Next Action', 'READY' if next_action == _t('Roots look stable') else 'REVIEW', detail=next_action)

        if watch_rows:
            roots_box = state.box()
            roots_box.label(text=_t('Watched Roots'), icon='FILE_FOLDER')
            for row in watch_rows[:6]:
                head = roots_box.row(align=True)
                head.label(text=f"{row.get('alias','ROOT')} [{_sf_watch_kind_filters_label(row.get('kind_filters') or [])}]", icon='FILE_PARENT')
                source_label = _sf_watch_source_labels(list(row.get('sources') or [row.get('source') or 'context']))
                head.label(text=source_label, icon='BLANK1')
                path_row = roots_box.row(align=True)
                path_row.label(text=_sf_short_path_display(_norm_path(row.get('path') or ''), 92), icon='BLANK1', translate=False)
                if not os.path.isdir(_norm_path(row.get('path') or '')):
                    path_row.label(text=_t('Missing on disk'), icon='ERROR')

        kinds = list(summary.get('kinds_rows') or [])
        if kinds:
            kinds_box = state.box()
            kinds_box.label(text=_t('Kinds'), icon='FILE_FOLDER')
            for row in kinds[:6]:
                kinds_box.label(text=f"{row.get('label','')}: {int(row.get('count', 0) or 0)}", icon='BLANK1')

        for section_title, key, icon in (
            ('Added Preview', 'preview_added', 'ADD'),
            ('Removed Preview', 'preview_removed', 'REMOVE'),
            ('Changed Preview', 'preview_changed', 'FILE_REFRESH'),
        ):
            rows = list(diff.get(key) or [])
            if not rows:
                continue
            box = state.box()
            box.label(text=_t(section_title), icon=icon)
            for row in rows[:5]:
                box.label(text=f"[{row.get('kind','')}] {row.get('label','')}", icon='BLANK1')

        quick = layout.box()
        _sf_draw_section_intro(
            quick,
            'Quick Actions',
            'Capture one stable baseline first, then refresh the watch state or export the drift report whenever the effective watch roots may have changed.',
            'CHECKMARK',
        )
        _sf_draw_action_block(
            quick,
            primary_actions=[
                ('import_scene.sfs_root_watch_capture_snapshot', 'Capture Snapshot', 'FILE_TICK', {}),
                ('import_scene.sfs_root_watch_refresh', 'Refresh Status', 'FILE_REFRESH', {}),
                ('export_scene.sfs_root_watch_export_drift_report', 'Export Drift Report', 'FILE_TEXT', {}),
                ('import_scene.sfs_asset_library_rebuild_index', 'Rebuild Index', 'FILE_REFRESH', {}),
            ],
            secondary_actions=[
                ('import_scene.sfs_context_roots_open', 'Context Roots', 'FILE_PARENT', {}),
                ('import_scene.sfs_dependency_cockpit_open', 'Dependencies', 'NETWORK_DRIVE', {}),
                ('import_scene.sfs_reference_toolkit_open', 'Toolkit', 'ASSET_MANAGER', {}),
                ('import_scene.sfs_external_assets_bundle_project', 'Bundle', 'EXPORT', {}),
            ],
        )


class SF_OT_root_watch_capture_snapshot(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_root_watch_capture_snapshot'
    bl_label = 'Capture Snapshot'
    bl_description = 'Scan the enabled watch roots and store a stable watch snapshot that later comparisons can use to detect drift, missing files, or unexpected project changes. The effective watch roots can include both Library Roots and named Context Roots.'
    bl_options = {'UNDO'}

    scan_mode: EnumProperty(
        name='Scan Mode',
        items=[
            ('KNOWN_PORTABLE', 'Known Portable Types', 'Track .blend files plus common textures, caches, volumes, clips, sounds, fonts, and helper text files.'),
            ('BLENDS_ONLY', 'Blend Files Only', 'Track only .blend libraries for a lighter watch snapshot.'),
            ('ALL_FILES', 'All Visible Files', 'Track every non-hidden file under enabled roots. Use this for strict handoff or archive checks.'),
        ],
        default='KNOWN_PORTABLE',
    )
    rebuild_index: BoolProperty(name='Rebuild index first', default=False, description='Refresh the library index for enabled roots before capturing the snapshot.')
    open_report: BoolProperty(name='Open report', default=False, description='Write a short text report after the snapshot is captured.')

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=620)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'scan_mode')
        layout.prop(self, 'rebuild_index')
        layout.prop(self, 'open_report')

    def execute(self, context):
        roots = [row.get('path') for row in _sf_watch_collect_root_rows(context)]
        if not roots:
            self.report({'ERROR'}, _t('No enabled watch roots'))
            return {'CANCELLED'}
        if self.rebuild_index:
            try:
                _rebuild_index_for_roots(context, roots, full_rebuild=False)
            except Exception:
                pass
        current = _sf_watch_build_snapshot_payload(context, scan_mode=self.scan_mode)
        if int(dict(current.get('summary') or {}).get('total_files', 0) or 0) <= 0:
            self.report({'WARNING'}, _t('No watchable files were found under the enabled watch roots'))
        if not _sf_watch_write_json(_sf_watch_snapshot_path(), current):
            self.report({'ERROR'}, _t('Failed to write root watch snapshot'))
            return {'CANCELLED'}
        status = _sf_watch_write_status(context, current=current, previous=current)
        text_name = ''
        if self.open_report:
            title = _t('Root Watch Snapshot')
            text_name = _sf_report_export(
                context,
                title,
                _sf_watch_report_lines(context, title, status, current=current, previous=current),
                open_text=True,
                activity_title=_t('Captured root snapshot'),
            )
        else:
            _sf_append_activity(context, _t('Captured root snapshot'), str(int(dict(current.get('summary') or {}).get('total_files', 0) or 0)), 'FILE_TICK')
        self.report({'INFO'}, f"{_t('Snapshot stored')}: {int(dict(current.get('summary') or {}).get('total_files', 0) or 0)}" + (f" | {text_name}" if text_name else ''))
        return {'FINISHED'}


class SF_OT_root_watch_refresh(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_root_watch_refresh'
    bl_label = 'Refresh'
    bl_description = 'Rescan the enabled watch roots, compare them to the stored watch snapshot, and refresh the compact drift summary used by the Root Watch popup.'
    bl_options = {'UNDO'}

    scan_mode: EnumProperty(
        name='Scan Mode',
        items=[
            ('KNOWN_PORTABLE', 'Known Portable Types', ''),
            ('BLENDS_ONLY', 'Blend Files Only', ''),
            ('ALL_FILES', 'All Visible Files', ''),
        ],
        default='KNOWN_PORTABLE',
    )
    rebuild_index: BoolProperty(name='Rebuild index first', default=False)

    def execute(self, context):
        roots = [row.get('path') for row in _sf_watch_collect_root_rows(context)]
        if not roots:
            self.report({'ERROR'}, _t('No enabled watch roots'))
            return {'CANCELLED'}
        if self.rebuild_index:
            try:
                _rebuild_index_for_roots(context, roots, full_rebuild=False)
            except Exception:
                pass
        previous = _sf_watch_read_json(_sf_watch_snapshot_path(), default={}) or {}
        current = _sf_watch_build_snapshot_payload(context, scan_mode=self.scan_mode)
        status = _sf_watch_write_status(context, current=current, previous=previous)
        diff = dict(status.get('diff_summary') or {})
        _sf_append_activity(
            context,
            _t('Refreshed root watch'),
            f"+{int(diff.get('added', 0) or 0)} / -{int(diff.get('removed', 0) or 0)} / Δ{int(diff.get('changed', 0) or 0)}",
            'FILE_REFRESH',
        )
        self.report({'INFO'}, f"{_t('Added')}: {int(diff.get('added', 0) or 0)} | {_t('Removed')}: {int(diff.get('removed', 0) or 0)} | {_t('Changed')}: {int(diff.get('changed', 0) or 0)}")
        return {'FINISHED'}


class SF_OT_root_watch_export_drift_report(bpy.types.Operator):
    bl_idname = 'export_scene.sfs_root_watch_export_drift_report'
    bl_label = 'Export Drift Report'
    bl_description = 'Compare the current enabled watch roots against the stored watch snapshot and write a drift report that lists added, removed, and changed files for handoff or troubleshooting.'
    bl_options = {'UNDO', 'INTERNAL'}

    scan_mode: EnumProperty(
        name='Scan Mode',
        items=[
            ('KNOWN_PORTABLE', 'Known Portable Types', ''),
            ('BLENDS_ONLY', 'Blend Files Only', ''),
            ('ALL_FILES', 'All Visible Files', ''),
        ],
        default='KNOWN_PORTABLE',
    )
    rebuild_index: BoolProperty(name='Rebuild index first', default=False)
    open_text: BoolProperty(name='Open report', default=True)

    def execute(self, context):
        roots = [row.get('path') for row in _sf_watch_collect_root_rows(context)]
        if not roots:
            self.report({'ERROR'}, _t('No enabled watch roots'))
            return {'CANCELLED'}
        if self.rebuild_index:
            try:
                _rebuild_index_for_roots(context, roots, full_rebuild=False)
            except Exception:
                pass
        previous = _sf_watch_read_json(_sf_watch_snapshot_path(), default={}) or {}
        current = _sf_watch_build_snapshot_payload(context, scan_mode=self.scan_mode)
        status = _sf_watch_write_status(context, current=current, previous=previous)
        title = _t('Root Drift Report')
        text_name = _sf_report_export(
            context,
            title,
            _sf_watch_report_lines(context, title, status, current=current, previous=previous),
            open_text=self.open_text,
            activity_title=_t('Exported root drift report'),
        )
        diff = dict(status.get('diff_summary') or {})
        self.report({'INFO'}, f"{_t('Added')}: {int(diff.get('added', 0) or 0)} | {_t('Removed')}: {int(diff.get('removed', 0) or 0)} | {_t('Changed')}: {int(diff.get('changed', 0) or 0)} | {text_name}")
        return {'FINISHED'}
