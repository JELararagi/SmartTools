# SPDX-License-Identifier: GPL-3.0-or-later
"""Delete scene objects that match the user's empty-object criteria."""

import bpy
from ._collider_scope import dialog, done, enter_object_mode


class OBJECT_OT_decentraland_remove_empty_objects(bpy.types.Operator):
    bl_idname = "object.sfs_decentraland_remove_empty_objects"
    bl_label = "Remove Empty Objects"
    bl_description = "Remove Empties or meshes without geometry or materials, as selected below"
    bl_options = {"UNDO"}

    remove_empties: bpy.props.BoolProperty(name="Remove Empty Types", default=True)
    remove_mesh_without_data: bpy.props.BoolProperty(name="Remove Empty Meshes", default=True)
    remove_mesh_without_materials: bpy.props.BoolProperty(name="Remove Meshes Without Materials", default=False)
    scope_selected: bpy.props.BoolProperty(name="Only Selected", default=True)

    def invoke(self, context, _event):
        return dialog(self, context)

    def draw(self, _context):
        column = self.layout.column()
        for field in ("remove_empties", "remove_mesh_without_data", "remove_mesh_without_materials", "scope_selected"):
            column.prop(self, field)

    def execute(self, context):
        if not enter_object_mode(context):
            return {"CANCELLED"}
        chosen = list(context.selected_objects if self.scope_selected else bpy.data.objects)
        if self.scope_selected and not chosen:
            self.report({"WARNING"}, "No objects selected")
            return {"CANCELLED"}
        eligible = [
            obj for obj in chosen
            if (obj.type == "EMPTY" and self.remove_empties)
            or (obj.type == "MESH" and (
                (self.remove_mesh_without_data and not obj.data.vertices)
                or (self.remove_mesh_without_materials and not obj.data.materials)
            ))
        ]
        for obj in eligible:
            bpy.data.objects.remove(obj, do_unlink=True)
        return done(self, f"Removed {len(eligible)} empty objects", f"空のオブジェクトを {len(eligible)} 個削除しました")
