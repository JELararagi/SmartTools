import bpy

from ..avatar_libraries import draw_paths, load_collections
from ...ui_language_runtime import ui_text as _ui_text

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _has_child_collection(parent_collection, child_name):
    return any(coll.name == child_name for coll in parent_collection.children)


def _find_selectable_armature(context, collection):
    selectable = set(context.selectable_objects)
    return next((obj for obj in collection.all_objects
                 if obj.type == 'ARMATURE' and obj in selectable), None)


def _set_avatar_visibility(context, avatar):
    """Only change visibility inside the avatar we actually imported."""
    def walk(layer, inside=False):
        inside = inside or layer.collection == avatar
        if inside:
            name = layer.collection.name
            base, dot, suffix = name.rpartition(".")
            if dot and suffix.isdigit():
                name = base
            if name in {"Avatar_ShapeA", "Avatar_ShapeB"}:
                layer.exclude = name == "Avatar_ShapeB"
        for child in layer.children:
            walk(child, inside)
    walk(context.view_layer.layer_collection)


def _import_collection_from_rig(context, collection_name, operator):
    try:
        return load_collections(context, [("rig", collection_name)])[0]
    except (ValueError, OSError, RuntimeError) as exc:
        operator.report({"ERROR"}, str(exc))
        return None


# ---------------------------------------------------------------------------
# Import DCL Rig (Avatar collection)
# ---------------------------------------------------------------------------


class OBJECT_OT_decentraland_import_dcl_rig(bpy.types.Operator):
    bl_idname = 'object.sfs_decentraland_import_dcl_rig'
    bl_label = 'Import DCL Rig'
    bl_description = _ui_text('Append the Avatar collection from your rig library', '指定したリグ素材から Avatar コレクションを追加します')
    bl_options = {'UNDO'}

    make_active: bpy.props.BoolProperty(
        name="Make Imported Rig Active",
        description="Select the imported armature and make it active after import",
        default=True,
    )

    def execute(self, context):
        coll = _import_collection_from_rig(context, "Avatar", self)
        if coll is None:
            return {"CANCELLED"}

        # DCL animation defaults.
        context.scene.render.fps = 30
        context.scene.frame_start = 1
        context.scene.frame_end = 300
        context.scene.frame_set(context.scene.frame_start)

        # --- Clean outliner presentation ---
        # Hide Avatar_ShapeB by default; keep only Avatar_ShapeA visible.
        _set_avatar_visibility(context, coll)

        context.view_layer.update()
        active_armature = _find_selectable_armature(context, coll) if self.make_active else None
        if active_armature:
            for obj in context.selected_objects:
                obj.select_set(False)
            active_armature.select_set(True)
            context.view_layer.objects.active = active_armature

        self.report({"INFO"}, "DCL rig imported. Scene set to 30 fps / 1-300 frames.")
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "make_active")
        layout.separator()
        draw_paths(layout, context.scene.dcl_tools, ("rig",))

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=420)


# ---------------------------------------------------------------------------
# Add Prop (Prop collection with Armature_Prop)
# ---------------------------------------------------------------------------


class OBJECT_OT_decentraland_add_prop(bpy.types.Operator):
    bl_idname = 'object.sfs_decentraland_add_prop'
    bl_label = 'Add Prop'
    bl_description = _ui_text('Append the Prop collection from your rig library', '指定したリグ素材から Prop コレクションを追加します')
    bl_options = {'UNDO'}

    def draw(self, context):
        draw_paths(self.layout, context.scene.dcl_tools, ("rig",))

    def invoke(self, context, event):
        if context.scene.dcl_tools.rig_library_file:
            return self.execute(context)
        return context.window_manager.invoke_props_dialog(self, width=440)

    def execute(self, context):
        coll = _import_collection_from_rig(context, "Prop", self)
        if coll is None:
            return {"CANCELLED"}

        # Select the prop armature for convenience.
        prop_arm = _find_selectable_armature(context, coll)
        if prop_arm:
            for obj in context.selected_objects:
                obj.select_set(False)
            prop_arm.select_set(True)
            context.view_layer.objects.active = prop_arm

        self.report({"INFO"}, "Prop collection imported (Armature_Prop).")
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Limit Area Reference (Animation_Area_Reference collection)
# ---------------------------------------------------------------------------


class OBJECT_OT_decentraland_limit_area_reference(bpy.types.Operator):
    bl_idname = 'object.sfs_decentraland_limit_area_reference'
    bl_label = 'Limit Area Reference'
    bl_description = _ui_text('Append the Animation_Area_Reference collection from your rig library', '指定したリグ素材から Animation_Area_Reference コレクションを追加します')
    bl_options = {'UNDO'}

    def draw(self, context):
        draw_paths(self.layout, context.scene.dcl_tools, ("rig",))

    def invoke(self, context, event):
        if context.scene.dcl_tools.rig_library_file:
            return self.execute(context)
        return context.window_manager.invoke_props_dialog(self, width=440)

    def execute(self, context):
        coll = _import_collection_from_rig(context, "Animation_Area_Reference", self)
        if coll is None:
            return {"CANCELLED"}

        self.report({"INFO"}, "Animation Area Reference imported (ground + boundary guides).")
        return {"FINISHED"}
