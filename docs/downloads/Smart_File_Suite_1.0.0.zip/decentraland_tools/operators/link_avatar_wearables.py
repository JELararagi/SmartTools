"""Append editable avatar shapes from libraries explicitly selected by the user."""
import bpy
from ..avatar_libraries import draw_paths, load_collections
from ...ui_language_runtime import ui_text


class OBJECT_OT_decentraland_avatar_shapes(bpy.types.Operator):
    bl_idname = "object.sfs_decentraland_avatar_shapes"
    bl_label = "Avatar Shapes"
    bl_description = "Import and create editable Decentraland avatar collections for wearable development (Shape A and B)"
    bl_options = {'UNDO'}

    avatar_shape: bpy.props.EnumProperty(
        name="Avatar Shape",
        items=[("A", "Shape A", ""), ("B", "Shape B", ""), ("BOTH", "Both Shapes", "")],
        default="A",
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and hasattr(context.scene, "dcl_tools")

    def kinds(self):
        return ("A", "B") if self.avatar_shape == "BOTH" else (self.avatar_shape,)

    def draw(self, context):
        self.layout.prop(self, "avatar_shape", expand=True)
        draw_paths(self.layout, context.scene.dcl_tools, self.kinds())

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=440)

    def execute(self, context):
        requests = [(kind, "DCLAvatar_Shape" + kind) for kind in self.kinds()]
        try:
            collections = load_collections(context, requests, editable=True)
        except (ValueError, OSError, RuntimeError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        names = ", ".join(c.name for c in collections)
        self.report({'INFO'}, ui_text(f"Added editable shapes: {names}", f"編集用の体型を追加しました：{names}"))
        return {'FINISHED'}
