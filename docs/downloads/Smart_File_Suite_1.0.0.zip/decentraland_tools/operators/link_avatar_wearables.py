import os

import bpy

from ...storage_paths import user_default_dir

from .. import dcl_rig_metadata
from ...ui_language_runtime import ui_text as _ui_text


def safe_deselect_all():
    """Deselect all objects without using bpy.ops (context-safe)."""
    for obj in bpy.data.objects:
        try:
            obj.select_set(False)
        except RuntimeError:
            pass


def safe_ensure_object_mode():
    """Ensure we are in object mode, handling context issues."""
    try:
        if bpy.context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
    except (RuntimeError, Exception):
        pass


class OBJECT_OT_decentraland_avatar_shapes(bpy.types.Operator):
    bl_idname = 'object.sfs_decentraland_avatar_shapes'
    bl_label = 'Avatar Shapes'
    bl_description = (
        "Import and create editable Decentraland avatar collections for wearable development (Shape A and B)"
    )
    bl_options = {'UNDO'}

    avatar_shape: bpy.props.EnumProperty(
        name="Avatar Shape",
        description="Choose the avatar shape to import for wearable development",
        items=[
            ("A", "Shape A", "Import DCLAvatar_ShapeA collection from AvatarShape_A.blend"),
            ("B", "Shape B", "Import DCLAvatar_ShapeB collection from AvatarShape_B.blend"),
            ("BOTH", "Both Shapes", "Import both Shape A and Shape B collections"),
        ],
        default="A",
    )

    def execute(self, context):
        assets_dir = dcl_rig_metadata.get_assets_dir()
        if not os.path.isdir(assets_dir):
            self.report({"ERROR"}, "Could not find assets directory in add-on")
            return {"CANCELLED"}

        # Create temp directory for extracted avatars if it doesn't exist
        temp_dir = user_default_dir("decentraland_tools", "avatars", create=True)
        os.makedirs(temp_dir, exist_ok=True)

        if not self._extract_avatar_files(assets_dir, temp_dir):
            self.report({"ERROR"}, "Failed to extract avatar files")
            return {"CANCELLED"}

        current_selection = list(context.selected_objects)
        current_active = context.active_object

        imported_collections = []

        try:
            if self.avatar_shape in ["A", "BOTH"]:
                # Import Shape A
                blend_file_a = os.path.join(temp_dir, "avatar_shape_a.blend")
                collection_name_a = "DCLAvatar_ShapeA"

                if os.path.exists(blend_file_a):
                    with bpy.data.libraries.load(blend_file_a, link=True) as (data_from, data_to):
                        if collection_name_a in data_from.collections:
                            data_to.collections = [collection_name_a]
                        else:
                            self.report({"WARNING"}, _ui_text(f"Collection '{collection_name_a}' not found in {blend_file_a}", f"{blend_file_a} にコレクション「{collection_name_a}」が見つかりません"))

                    if collection_name_a in bpy.data.collections:
                        collection_a = bpy.data.collections[collection_name_a]
                        if collection_a.name not in context.scene.collection.children:
                            context.scene.collection.children.link(collection_a)
                        imported_collections.append(collection_name_a)
                    else:
                        self.report({"ERROR"}, _ui_text(f"Failed to link collection '{collection_name_a}'", f"コレクション「{collection_name_a}」をリンクできませんでした"))
                else:
                    self.report({"WARNING"}, _ui_text(f"Blend file not found: {blend_file_a}", f"Blend ファイルが見つかりません：{blend_file_a}"))

            if self.avatar_shape in ["B", "BOTH"]:
                # Import Shape B
                blend_file_b = os.path.join(temp_dir, "avatar_shape_b.blend")
                collection_name_b = "DCLAvatar_ShapeB"

                if os.path.exists(blend_file_b):
                    with bpy.data.libraries.load(blend_file_b, link=True) as (data_from, data_to):
                        if collection_name_b in data_from.collections:
                            data_to.collections = [collection_name_b]
                        else:
                            self.report({"WARNING"}, _ui_text(f"Collection '{collection_name_b}' not found in {blend_file_b}", f"{blend_file_b} にコレクション「{collection_name_b}」が見つかりません"))

                    if collection_name_b in bpy.data.collections:
                        collection_b = bpy.data.collections[collection_name_b]
                        if collection_b.name not in context.scene.collection.children:
                            context.scene.collection.children.link(collection_b)
                        imported_collections.append(collection_name_b)
                    else:
                        self.report({"ERROR"}, _ui_text(f"Failed to link collection '{collection_name_b}'", f"コレクション「{collection_name_b}」をリンクできませんでした"))
                else:
                    self.report({"WARNING"}, _ui_text(f"Blend file not found: {blend_file_b}", f"Blend ファイルが見つかりません：{blend_file_b}"))

            if imported_collections:
                # Duplicate collections to make them editable
                editable_collections = []
                for collection_name in imported_collections:
                    if collection_name in bpy.data.collections:
                        original_collection = bpy.data.collections[collection_name]

                        # Create a new editable collection
                        editable_name = f"{collection_name}_Editable"
                        if editable_name in bpy.data.collections:
                            # Remove existing editable collection
                            bpy.data.collections.remove(bpy.data.collections[editable_name])

                        editable_collection = bpy.data.collections.new(editable_name)
                        context.scene.collection.children.link(editable_collection)

                        # Store original scales before duplication
                        original_scales = {}
                        for obj in original_collection.objects:
                            original_scales[obj.name] = obj.scale.copy()

                        # Store original parenting relationships
                        original_parents = {}
                        for obj in original_collection.objects:
                            if obj.parent:
                                original_parents[obj.name] = obj.parent.name

                        # NEW APPROACH: Process objects individually to avoid transform_apply on armatures
                        safe_deselect_all()

                        # Create mapping of original names to new objects
                        name_mapping = {}

                        # Process each object individually
                        for obj in original_collection.objects:
                            # Select only this object
                            obj.select_set(True)
                            bpy.context.view_layer.objects.active = obj

                            # Duplicate this single object
                            bpy.ops.object.duplicate(linked=False)

                            # Get the duplicated object
                            duplicated_obj = context.active_object

                            # Store the name mapping
                            name_mapping[obj.name] = duplicated_obj

                            # Unlink from current collections
                            for collection in duplicated_obj.users_collection:
                                collection.objects.unlink(duplicated_obj)

                            # Link to our editable collection
                            editable_collection.objects.link(duplicated_obj)

                            # Make sure it's local (not linked)
                            duplicated_obj.make_local()

                            # Make all materials single-user (unlinked) so they can be edited
                            if duplicated_obj.type == "MESH" and duplicated_obj.data.materials:
                                for slot in duplicated_obj.material_slots:
                                    if slot.material:
                                        slot.material.make_local()

                            # Only apply transforms to MESH objects, skip ARMATURE
                            if duplicated_obj.type == "MESH":
                                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

                            # Deselect for next iteration
                            duplicated_obj.select_set(False)

                        # Restore parenting relationships using proper Blender commands
                        for child_name, parent_name in original_parents.items():
                            if child_name in name_mapping and parent_name in name_mapping:
                                child_obj = name_mapping[child_name]
                                parent_obj = name_mapping[parent_name]

                                # Use proper Blender parenting commands for armature deformation
                                if parent_obj.type == "ARMATURE" and child_obj.type == "MESH":
                                    # Select the mesh object and set armature as active
                                    safe_deselect_all()
                                    child_obj.select_set(True)
                                    bpy.context.view_layer.objects.active = parent_obj

                                    # First parent with keep_transform to preserve positioning
                                    bpy.ops.object.parent_set(type="OBJECT", keep_transform=True)

                                    # Then parent with armature deformation
                                    bpy.ops.object.parent_set(type="ARMATURE")
                                else:
                                    # For non-armature parenting, use direct assignment
                                    child_obj.parent = parent_obj

                        # The built-in duplication should preserve all armature weighting and modifiers
                        # No need for complex manual copying

                        # Remove the original linked collection
                        try:
                            # Unlink from scene collection first
                            if original_collection.name in context.scene.collection.children:
                                context.scene.collection.children.unlink(original_collection)

                            # Remove the collection
                            bpy.data.collections.remove(original_collection)
                            self.report({"INFO"}, _ui_text(f"Removed original linked collection '{collection_name}'", f"リンクされた元のコレクション「{collection_name}」を取り除きました"))

                        except Exception as e:
                            self.report({"WARNING"}, _ui_text(f"Could not remove original collection: {str(e)}", f"元のコレクションを取り除けませんでした：{str(e)}"))

                        editable_collections.append(editable_name)

                # Select and view the editable collections
                safe_deselect_all()

                for collection_name in editable_collections:
                    if collection_name in bpy.data.collections:
                        collection = bpy.data.collections[collection_name]

                        # Select all objects in the collection
                        for obj in collection.objects:
                            obj.select_set(True)
                            # Set armature as active if available
                            if obj.type == "ARMATURE":
                                context.view_layer.objects.active = obj

                # View the selected objects
                if context.selected_objects:
                    bpy.ops.view3d.view_selected()

                self.report(
                    {"INFO"}, _ui_text(f"Successfully created editable avatar collections: {', '.join(editable_collections)}", f"編集できるアバターのコレクションを作りました：{', '.join(editable_collections)}")
                )
                self.report({"INFO"}, "Avatars are now fully editable and ready for manipulation!")
                return {"FINISHED"}
            else:
                self.report({"ERROR"}, "No avatar collections were imported")
                return {"CANCELLED"}

        except Exception as e:
            self.report({"ERROR"}, _ui_text(f"Error importing avatar collections: {str(e)}", f"アバターのコレクションの読み込みでエラーが起きました：{str(e)}"))
            return {"CANCELLED"}
        finally:
            # Restore selection
            safe_deselect_all()
            for obj in current_selection:
                try:
                    if obj and obj.name in bpy.data.objects:
                        bpy.data.objects[obj.name].select_set(True)
                except (ReferenceError, RuntimeError):
                    pass
            if current_active:
                try:
                    if current_active.name in bpy.data.objects:
                        context.view_layer.objects.active = bpy.data.objects[current_active.name]
                except (ReferenceError, RuntimeError):
                    pass

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "avatar_shape", expand=True)
        layout.separator()
        layout.separator()

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def _extract_avatar_files(self, assets_dir, temp_dir):
        """Extract avatar blend files from addon package to temp directory."""
        import shutil

        avatar_files = ["avatar_shape_a.blend", "avatar_shape_b.blend"]

        for avatar_file in avatar_files:
            source_path = os.path.join(assets_dir, avatar_file)
            dest_path = os.path.join(temp_dir, avatar_file)

            if os.path.exists(dest_path):
                continue

            if os.path.exists(source_path):
                try:
                    shutil.copy2(source_path, dest_path)
                    self.report({"INFO"}, _ui_text(f"Extracted {avatar_file}", f"{avatar_file} を展開しました"))
                except Exception as e:
                    self.report({"WARNING"}, _ui_text(f"Could not extract {avatar_file}: {str(e)}", f"{avatar_file} を展開できませんでした：{str(e)}"))
            else:
                self.report({"ERROR"}, _ui_text(f"Avatar file not found in addon: {avatar_file}", f"アドオンの中にアバターのファイルが見つかりません：{avatar_file}"))
                return False

        return True
