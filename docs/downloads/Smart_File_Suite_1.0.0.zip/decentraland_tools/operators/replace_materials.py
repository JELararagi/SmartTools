import bpy
from ...ui_language_runtime import ui_text as _ui_text


_active_dialogs = {}


class MaterialListItem(bpy.types.PropertyGroup):
    """Property group for material list items"""

    material_name: bpy.props.StringProperty(
        name="Material Name",
        description="Name of the material to replace",
        default="",
    )


class OBJECT_OT_decentraland_replace_materials(bpy.types.Operator):
    bl_idname = 'object.sfs_decentraland_replace_materials'
    bl_label = 'Replace Materials'
    bl_description = "Replace one or more materials with another across all objects or selected objects"
    bl_options = {'UNDO'}

    scope_selected: bpy.props.BoolProperty(
        name="Only Selected Objects",
        description="Replace materials only on selected objects",
        default=False,
    )

    source_material_temp: bpy.props.StringProperty(
        name="Source Material",
        description="Material to add to replacement list",
        default="",
    )

    target_material: bpy.props.StringProperty(
        name="Target Material",
        description="Material to replace with",
        default="",
    )

    source_materials: bpy.props.CollectionProperty(type=MaterialListItem)
    source_material_index: bpy.props.IntProperty(default=0)

    def execute(self, context):
        self._forget_dialog()
        if bpy.context.mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass

        # Get target material
        target_mat_name = self.target_material

        if not target_mat_name:
            self.report({"ERROR"}, "Please select a target material")
            return {"CANCELLED"}

        # Get source materials from collection
        source_mat_names = [item.material_name for item in self.source_materials if item.material_name]

        if not source_mat_names:
            self.report({"ERROR"}, "Please add at least one source material to replace")
            return {"CANCELLED"}

        # Validate target material
        if target_mat_name not in bpy.data.materials:
            self.report({"ERROR"}, _ui_text(f"Target material '{target_mat_name}' not found", f"置き換え先のマテリアル「{target_mat_name}」が見つかりません"))
            return {"CANCELLED"}

        target_material = bpy.data.materials[target_mat_name]

        # Validate and get source materials
        source_materials = []
        for mat_name in source_mat_names:
            if mat_name == target_mat_name:
                self.report({"WARNING"}, _ui_text(f"Skipping '{mat_name}' - source and target cannot be the same", f"「{mat_name}」を飛ばします（元と置き換え先を同じにはできません）"))
                continue
            if mat_name not in bpy.data.materials:
                self.report({"WARNING"}, _ui_text(f"Source material '{mat_name}' not found, skipping", f"元マテリアル「{mat_name}」が見つからないので飛ばします"))
                continue
            source_materials.append(bpy.data.materials[mat_name])

        if not source_materials:
            self.report({"ERROR"}, "No valid source materials to replace")
            return {"CANCELLED"}

        # Get objects to process
        objects = context.selected_objects if self.scope_selected else bpy.data.objects
        affected_objects = 0
        replaced_slots = 0

        for obj in objects:
            if obj.type != "MESH":
                continue

            obj_affected = False
            # Check each material slot
            for slot in obj.material_slots:
                # リンクされたオブジェクトやメッシュの枠は書き換えられない
                owner = obj if slot.link == "OBJECT" else obj.data
                if owner.library:
                    continue
                if slot.material in source_materials:
                    slot.material = target_material
                    replaced_slots += 1
                    obj_affected = True

            if obj_affected:
                affected_objects += 1

        source_list = ", ".join([mat.name for mat in source_materials])
        self.report(
            {"INFO"},
            _ui_text(f"Replaced {len(source_materials)} material(s) ({source_list}) with '{target_mat_name}' on {affected_objects} objects ({replaced_slots} slots)", f"マテリアル {len(source_materials)} 個（{source_list}）を、オブジェクト {affected_objects} 個（スロット {replaced_slots} 個）で「{target_mat_name}」へ置き換えました"),
        )
        return {"FINISHED"}

    def _consume_material_list_requests(self, context):
        """Apply explicit child-operator requests outside Panel/Operator draw."""
        changed = False
        wm = context.window_manager
        if hasattr(bpy.types.WindowManager, "replace_materials_add") and hasattr(wm, "replace_materials_add"):
            mat_name = str(getattr(wm, "replace_materials_add", "") or "")
            if mat_name:
                if mat_name in bpy.data.materials and not any(item.material_name == mat_name for item in self.source_materials):
                    item = self.source_materials.add()
                    item.material_name = mat_name
                    changed = True
                wm.replace_materials_add = ""
        if hasattr(bpy.types.WindowManager, "replace_materials_remove") and hasattr(wm, "replace_materials_remove"):
            idx = int(getattr(wm, "replace_materials_remove", -1))
            if idx >= 0:
                if 0 <= idx < len(self.source_materials):
                    self.source_materials.remove(idx)
                    changed = True
                wm.replace_materials_remove = -1
        return changed

    def check(self, context):
        return bool(self._consume_material_list_requests(context))

    def draw(self, context):
        layout = self.layout

        # Draw is read-only. Child operators update the active dialog operator
        # directly, with check() as the request fallback.

        # Source materials list
        col = layout.column()
        col.label(text="Source Materials (to replace):")

        # Search box to add materials
        row = col.row()
        row.prop_search(self, "source_material_temp", bpy.data, "materials", text="", icon="MATERIAL")

        # Add button
        if self.source_material_temp and self.source_material_temp in bpy.data.materials:
            mat_name = self.source_material_temp
            if not any(item.material_name == mat_name for item in self.source_materials):
                add_op = row.operator("object.sfs_decentraland_add_source_material", text='Add Source Material', icon="ADD")
                add_op.material_name = mat_name
            else:
                row.label(text="(Already in list)")
        else:
            row.label(text="(Select a material)")

        # List of selected source materials
        if len(self.source_materials) > 0:
            box = col.box()
            box.label(text=_ui_text(f"{len(self.source_materials)} material(s) to replace:", f"置き換えるマテリアル {len(self.source_materials)} 個："), icon="MATERIAL_DATA")
            for idx, item in enumerate(self.source_materials):
                if item.material_name:
                    row = box.row()
                    row.label(text=item.material_name, icon="MATERIAL", translate=False)
                    # Remove button
                    remove_op = row.operator("object.sfs_decentraland_remove_source_material", text="", icon="X", emboss=True)
                    remove_op.item_index = idx
        else:
            col.label(text="No materials added yet")

        layout.separator()

        # Target material selector with search
        col = layout.column()
        col.label(text="Target Material (replacement):")
        col.prop_search(self, "target_material", bpy.data, "materials", text="", icon="MATERIAL")

        layout.separator()

        # Scope option
        layout.prop(self, "scope_selected")

    def invoke(self, context, event):
        # Reset material selections
        self.source_material_temp = ""
        self.target_material = ""
        self.source_materials.clear()

        # Initialize window manager properties (they should be registered, but check anyway)
        wm = context.window_manager
        if hasattr(bpy.types.WindowManager, "replace_materials_add"):
            wm.replace_materials_add = ""
        if hasattr(bpy.types.WindowManager, "replace_materials_remove"):
            wm.replace_materials_remove = -1

        self._dialog_window = context.window.as_pointer()
        result = context.window_manager.invoke_props_dialog(self, width=450)
        if "RUNNING_MODAL" in result:
            _active_dialogs[self._dialog_window] = self
        return result

    def _forget_dialog(self):
        key = getattr(self, "_dialog_window", None)
        if _active_dialogs.get(key) is self:
            del _active_dialogs[key]

    def cancel(self, context):
        self._forget_dialog()


def _active_replace_materials_operator(context):
    window = context.window
    return _active_dialogs.get(window.as_pointer()) if window else None


class OBJECT_OT_decentraland_add_source_material(bpy.types.Operator):
    """Add a material to the source materials list"""

    bl_idname = 'object.sfs_decentraland_add_source_material'
    bl_label = 'Add Source Material'
    bl_options = {'UNDO', 'INTERNAL'}

    material_name: bpy.props.StringProperty()

    def execute(self, context):
        mat_name = self.material_name
        if not mat_name or mat_name not in bpy.data.materials:
            return {"CANCELLED"}

        parent = _active_replace_materials_operator(context)
        if parent is not None:
            if not any(item.material_name == mat_name for item in parent.source_materials):
                item = parent.source_materials.add()
                item.material_name = mat_name
            parent.source_material_temp = ""
            return {"FINISHED"}
        wm = context.window_manager
        if hasattr(bpy.types.WindowManager, "replace_materials_add"):
            wm.replace_materials_add = mat_name
        return {"FINISHED"}


class OBJECT_OT_decentraland_remove_source_material(bpy.types.Operator):
    """Remove a material from the source materials list"""

    bl_idname = 'object.sfs_decentraland_remove_source_material'
    bl_label = 'Remove Source Material'
    bl_options = {'UNDO', 'INTERNAL'}

    item_index: bpy.props.IntProperty()

    def execute(self, context):
        parent = _active_replace_materials_operator(context)
        index = int(self.item_index)
        if parent is not None:
            if 0 <= index < len(parent.source_materials):
                parent.source_materials.remove(index)
                parent.source_material_index = min(max(0, index - 1), max(0, len(parent.source_materials) - 1))
            return {"FINISHED"}
        wm = context.window_manager
        if hasattr(bpy.types.WindowManager, "replace_materials_remove"):
            wm.replace_materials_remove = index
        return {"FINISHED"}
