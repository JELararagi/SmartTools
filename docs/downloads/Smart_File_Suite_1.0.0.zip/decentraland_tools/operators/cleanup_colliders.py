# SPDX-License-Identifier: GPL-3.0-or-later
"""Weld nearby collider vertices and dissolve degenerate mesh elements."""

import bmesh
import bpy
from ._collider_scope import collider_meshes, dialog, done, enter_object_mode


def _weld_centroids(geometry, distance):
    targets = bmesh.ops.find_doubles(geometry, verts=list(geometry.verts), dist=distance)["targetmap"]
    totals = {}
    for vertex, target in targets.items():
        total, count = totals.get(target, (target.co.copy(), 1))
        totals[target] = total + vertex.co, count + 1
    for target, (total, count) in totals.items():
        target.co = total / count
    bmesh.ops.weld_verts(geometry, targetmap=targets)


class OBJECT_OT_decentraland_cleanup_colliders(bpy.types.Operator):
    bl_idname = "object.sfs_decentraland_cleanup_colliders"
    bl_label = "Cleanup Colliders"
    bl_description = "Weld nearby vertices and dissolve degenerate elements in collider meshes"
    bl_options = {"UNDO"}

    merge_distance: bpy.props.FloatProperty(name="Merge Distance", default=0.001, min=0.0001, max=1.0)
    scope_selected: bpy.props.BoolProperty(name="Only Selected", default=False)

    def invoke(self, context, _event):
        return dialog(self, context)

    def draw(self, _context):
        self.layout.prop(self, "merge_distance")
        self.layout.prop(self, "scope_selected")

    def execute(self, context):
        if not enter_object_mode(context):
            return {"CANCELLED"}
        count = 0
        for obj in collider_meshes(context, self.scope_selected):
            geometry = bmesh.new()
            try:
                geometry.from_mesh(obj.data)
                _weld_centroids(geometry, self.merge_distance)
                bmesh.ops.dissolve_degenerate(geometry, edges=list(geometry.edges), dist=0.0001)
                geometry.to_mesh(obj.data)
                obj.data.update()
            finally:
                geometry.free()
            count += 1
        return done(self, f"Cleaned {count} collider meshes", f"コライダーのメッシュを {count} 個整理しました")
