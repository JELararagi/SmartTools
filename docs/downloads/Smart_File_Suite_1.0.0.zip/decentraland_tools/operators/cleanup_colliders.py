import bpy
from ...ui_language_runtime import ui_text as _ui_text


def _mesh_operator_exists(suffix: str) -> bool:
    try:
        getattr(bpy.ops.mesh, str(suffix)).get_rna_type()
        return True
    except Exception:
        return False


def _merge_vertices_by_distance(threshold: float) -> bool:
    """Merge selected edit-mesh vertices on Blender 5.1.

    Blender 5.1 exposes the UI command "Merge by Distance" through the RNA
    id ``mesh.remove_doubles``.  The add-on targets Blender 5.1, so do not keep
    a dead call to the unregistered ``mesh.merge_by_distance`` operator: such
    references make feature-integrity audits report a missing command and can
    only fail at runtime on the supported version.
    """
    if not _mesh_operator_exists('remove_doubles'):
        return False
    return 'FINISHED' in set(
        bpy.ops.mesh.remove_doubles(threshold=float(threshold)) or set()
    )


class OBJECT_OT_decentraland_cleanup_colliders(bpy.types.Operator):
    bl_idname = 'object.sfs_decentraland_cleanup_colliders'
    bl_label = 'Cleanup Colliders'
    bl_description = "Merge close vertices by distance, dissolve degenerate faces, and optimize collider meshes"
    bl_options = {'UNDO'}

    merge_distance: bpy.props.FloatProperty(
        name="Merge Distance",
        description="Distance for merging vertices",
        default=0.001,
        min=0.0001,
        max=1.0,
    )

    scope_selected: bpy.props.BoolProperty(
        name="Only Selected",
        description="Affect only selected objects",
        default=False,
    )

    def execute(self, context):
        if bpy.context.mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass

        objects = context.selected_objects if self.scope_selected else bpy.data.objects
        affected = 0

        for obj in objects:
            if obj.type != "MESH":
                continue

            # Check if object name contains "_collider" (handles .001, .002 suffixes)
            # OR if it's a child of a collider object
            is_collider = False

            # Direct collider check
            if "_collider" in obj.name:
                is_collider = True
            else:
                # Check if parent is a collider
                parent = obj.parent
                while parent:
                    if "_collider" in parent.name:
                        is_collider = True
                        break
                    parent = parent.parent

            if not is_collider:
                continue

            # Select and make active
            bpy.ops.object.select_all(action="DESELECT")
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj

            # Enter edit mode
            bpy.ops.object.mode_set(mode="EDIT")

            # Select all vertices
            bpy.ops.mesh.select_all(action="SELECT")

            # Merge duplicate vertices by distance.
            if not _merge_vertices_by_distance(float(self.merge_distance)):
                bpy.ops.object.mode_set(mode="OBJECT")
                self.report({"WARNING"}, "Merge by Distance is unavailable in this Blender build")
                continue

            # Dissolve degenerate faces
            bpy.ops.mesh.dissolve_degenerate()

            # Return to object mode
            bpy.ops.object.mode_set(mode="OBJECT")

            affected += 1

        self.report({"INFO"}, _ui_text(f"Cleaned up {affected} collider objects", f"コライダー {affected} 個を整理しました"))
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "merge_distance")
        layout.prop(self, "scope_selected")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
