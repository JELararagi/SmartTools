# SPDX-License-Identifier: GPL-3.0-or-later
"""Scene scope shared by the Decentraland collider commands."""

import bpy
from ...ui_language_runtime import ui_text


def enter_object_mode(context):
    return context.mode == "OBJECT" or bpy.ops.object.mode_set(mode="OBJECT") == {"FINISHED"}


def collider_meshes(context, selected_only):
    objects = context.selected_objects if selected_only else bpy.data.objects
    for mesh in objects:
        if mesh.type != "MESH":
            continue
        ancestor = mesh
        while ancestor is not None:
            if "_collider" in ancestor.name:
                yield mesh
                break
            ancestor = ancestor.parent


def dialog(operator, context):
    return context.window_manager.invoke_props_dialog(operator)


def done(operator, english, japanese):
    operator.report({"INFO"}, ui_text(english, japanese))
    return {"FINISHED"}
