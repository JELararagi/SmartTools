# SPDX-License-Identifier: GPL-3.0-or-later
"""Enable camera backface culling on materials prepared for Decentraland."""

import bpy
from ._collider_scope import dialog, done


class OBJECT_OT_decentraland_enable_backface_culling(bpy.types.Operator):
    bl_idname = "object.sfs_decentraland_enable_backface_culling"
    bl_label = "Enable Backface Culling"
    bl_description = "Enable backface culling for node materials"
    bl_options = {"UNDO"}

    def invoke(self, context, _event):
        return dialog(self, context)

    def draw(self, _context):
        self.layout.label(text="Enable camera backface culling on node materials")

    def execute(self, _context):
        materials = [material for material in bpy.data.materials if material.use_nodes]
        for material in materials:
            material.use_backface_culling = True
        return done(self, f"Enabled backface culling on {len(materials)} materials", f"マテリアル {len(materials)} 個で背面カリングを有効にしました")
