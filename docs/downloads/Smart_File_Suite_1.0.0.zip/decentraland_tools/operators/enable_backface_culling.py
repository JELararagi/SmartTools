import bpy
from ...ui_language_runtime import ui_text as _ui_text


class OBJECT_OT_decentraland_enable_backface_culling(bpy.types.Operator):
    bl_idname = 'object.sfs_decentraland_enable_backface_culling'
    bl_label = 'Enable Backface Culling'
    bl_description = "Enable backface culling for all materials in the scene"
    bl_options = {'UNDO'}

    def execute(self, context):
        materials_updated = 0

        # Process all materials in the scene
        for material in bpy.data.materials:
            if material.use_nodes:
                # Enable backface culling
                material.use_backface_culling = True
                materials_updated += 1

        if materials_updated > 0:
            self.report({"INFO"}, _ui_text(f"Enabled backface culling for {materials_updated} materials", f"マテリアル {materials_updated} 個で背面カリングを有効にしました"))
        else:
            self.report({"INFO"}, "No materials found to update")

        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.separator()
        layout.label(text="Settings applied:")
        layout.label(text="• Camera: ON")
        layout.label(text="• Shadow: OFF")
        layout.label(text="• Light Probe Volume: ON")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
