# SPDX-License-Identifier: GPL-3.0-or-later
"""Apply Blender decimation to the selected collision meshes."""

import bpy
from ._collider_scope import collider_meshes, dialog, done, enter_object_mode


class OBJECT_OT_decentraland_simplify_colliders(bpy.types.Operator):
    bl_idname = "object.sfs_decentraland_simplify_colliders"
    bl_label = "Simplify Colliders"
    bl_description = "Reduce the polygon count of selected collision meshes"
    bl_options = {"UNDO"}

    ratio: bpy.props.FloatProperty(name="Decimation Ratio", default=0.5, min=0.01, max=1.0)

    def invoke(self, context, _event):
        return dialog(self, context)

    def draw(self, _context):
        self.layout.prop(self, "ratio")

    def execute(self, context):
        if not enter_object_mode(context):
            return {"CANCELLED"}
        if not context.selected_objects:
            self.report({"WARNING"}, "Select at least one collider mesh")
            return {"CANCELLED"}

        simplified = 0
        for obj in list(collider_meshes(context, True)):
            modifier = obj.modifiers.new("Decimate", "DECIMATE")
            modifier.ratio = self.ratio
            modifier.use_collapse_triangulate = True
            name = modifier.name
            with context.temp_override(object=obj, active_object=obj, selected_editable_objects=[obj]):
                try:
                    applied = bpy.ops.object.modifier_apply(modifier=name)
                except RuntimeError:
                    applied = {"CANCELLED"}
            if applied == {"FINISHED"}:
                simplified += 1
            else:
                pending = obj.modifiers.get(name)
                if pending is not None:
                    obj.modifiers.remove(pending)
                self.report({"WARNING"}, f"The collider {obj.name} could not be simplified")
        return done(self, f"Simplified {simplified} collider meshes", f"コライダーのメッシュを {simplified} 個簡略化しました")
