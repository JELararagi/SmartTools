import os
import shutil

import bpy

from ...storage_paths import user_default_dir
from ...ui_language_runtime import ui_text as _ui_text


def _has_alpha_channel(image):
    """Check if image actually uses its alpha channel (has non-opaque pixels)."""
    try:
        if not image or not image.pixels:
            return False
        if len(image.pixels) % 4 != 0:
            return False

        pixels = image.pixels[:]
        alpha_values = pixels[3::4]

        sample_step = max(1, len(alpha_values) // 1000)
        for i in range(0, len(alpha_values), sample_step):
            if alpha_values[i] < 0.98:
                return True
        return False
    except Exception:
        return False


def _safe_temp_image_path(image, extension):
    safe_name = "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in str(getattr(image, "name", "") or "image"))
    safe_name = safe_name.strip("._") or "image"
    return os.path.join(user_default_dir("decentraland_tools", "temp", create=True), f"dcl_compress_{safe_name}.{extension}")


class OBJECT_OT_decentraland_compress_images(bpy.types.Operator):
    bl_idname = 'object.sfs_decentraland_compress_images'
    bl_label = 'Compress Images'
    bl_description = (
        "Compress textures to JPEG or PNG to reduce file size. "
        "Optionally force JPEG for images without alpha transparency"
    )
    bl_options = {'UNDO'}

    texture_format: bpy.props.EnumProperty(
        name="Format",
        description="Output compression format",
        items=[
            ("AUTO", "Auto", "JPEG for opaque images, PNG for images with alpha"),
            ("JPEG", "JPEG", "Convert all textures to JPEG (discards alpha)"),
            ("PNG", "PNG", "Keep all textures as PNG"),
        ],
        default="AUTO",
    )

    jpeg_quality: bpy.props.IntProperty(
        name="JPEG Quality",
        description="JPEG compression quality (lower = smaller file, worse quality)",
        default=80,
        min=1,
        max=100,
    )

    force_jpeg_no_alpha: bpy.props.BoolProperty(
        name="Force JPEG When No Alpha",
        description=(
            "Convert PNG textures to JPEG when they don't use transparency. "
            "Significantly reduces file size for opaque textures"
        ),
        default=True,
    )

    scope_all_textures: bpy.props.BoolProperty(
        name="All Textures",
        description="Compress all textures in the scene",
        default=False,
    )

    scope_selected_objects: bpy.props.BoolProperty(
        name="Selected Objects Only",
        description="Compress only textures used by selected objects",
        default=True,
    )

    def _collect_textures(self, context):
        """Gather the set of images to process based on scope settings."""
        images = []

        if self.scope_all_textures:
            for img in bpy.data.images:
                if img.name.startswith("Render Result") or img.name.startswith("Viewer Node"):
                    continue
                # リンクされた画像はこのファイルから書き換えられない
                if img.library:
                    continue
                if img.size[0] == 0 or img.size[1] == 0:
                    continue
                images.append(img)

        elif self.scope_selected_objects and context.selected_objects:
            seen = set()
            for obj in context.selected_objects:
                if obj.type != "MESH" or not obj.data.materials:
                    continue
                for mat in obj.data.materials:
                    if not mat or not mat.use_nodes:
                        continue
                    for node in mat.node_tree.nodes:
                        if node.type == "TEX_IMAGE" and node.image and not node.image.library and node.image.name not in seen:
                            seen.add(node.image.name)
                            images.append(node.image)

        return images

    def _choose_format(self, image):
        """Decide whether to output JPEG or PNG for a given image."""
        if self.texture_format == "JPEG":
            return "JPEG"
        if self.texture_format == "PNG":
            return "PNG"

        # AUTO mode
        if self.force_jpeg_no_alpha:
            if _has_alpha_channel(image):
                return "PNG"
            return "JPEG"

        # AUTO without force: keep original format
        if image.file_format in ("JPEG", "JPG"):
            return "JPEG"
        return "PNG"

    def _adopt_encoded_file(self, image, temp_path, target_format, was_packed):
        """Point the image at the re-encoded data so it survives removal of the temp file."""
        raw_path = image.filepath
        original = bpy.path.abspath(raw_path) if raw_path else ""
        on_disk = not was_packed and image.source == "FILE" and original and os.path.isfile(original)
        if on_disk:
            # ファイルで持つ画像は元の場所に書き直す（JPEG は同じ名前の .jpg を隣に作る）
            extension = ".jpg" if target_format == "JPEG" else ".png"
            destination = os.path.splitext(original)[0] + extension
            shutil.copyfile(temp_path, destination)
            image.filepath = bpy.path.relpath(destination) if raw_path.startswith("//") else destination
            image.file_format = target_format
            image.reload()
            return
        # ファイルを持たない画像は .blend の中に持つ
        # 古い埋め込みを残すと reload がそれを読み、再エンコードが捨てられる
        if was_packed:
            image.unpack(method="REMOVE")
        image.filepath = temp_path
        image.file_format = target_format
        image.source = "FILE"
        image.reload()
        image.pack()

    def _compress_image(self, image, target_format):
        """Apply compression by re-encoding the image data in-place."""
        was_packed = image.packed_file is not None
        original_format = image.file_format

        if target_format == "JPEG":
            temp_path = _safe_temp_image_path(image, "jpg")

            saved_quality = bpy.context.scene.render.image_settings.quality
            saved_format = bpy.context.scene.render.image_settings.file_format

            try:
                bpy.context.scene.render.image_settings.file_format = "JPEG"
                bpy.context.scene.render.image_settings.quality = self.jpeg_quality
                image.save_render(temp_path)
                self._adopt_encoded_file(image, temp_path, "JPEG", was_packed)
            finally:
                bpy.context.scene.render.image_settings.quality = saved_quality
                bpy.context.scene.render.image_settings.file_format = saved_format
                try:
                    os.remove(temp_path)
                except OSError:
                    pass

        elif target_format == "PNG":
            if original_format == "PNG" and was_packed:
                return

            temp_path = _safe_temp_image_path(image, "png")

            saved_format = bpy.context.scene.render.image_settings.file_format
            saved_compression = bpy.context.scene.render.image_settings.compression

            try:
                bpy.context.scene.render.image_settings.file_format = "PNG"
                bpy.context.scene.render.image_settings.compression = 90
                image.save_render(temp_path)
                self._adopt_encoded_file(image, temp_path, "PNG", was_packed)
            finally:
                bpy.context.scene.render.image_settings.file_format = saved_format
                bpy.context.scene.render.image_settings.compression = saved_compression
                try:
                    os.remove(temp_path)
                except OSError:
                    pass

        image.update()

    def execute(self, context):
        images = self._collect_textures(context)
        if not images:
            self.report({"WARNING"}, "No textures found. Select objects or enable 'All Textures'")
            return {"CANCELLED"}

        compressed = 0
        jpeg_count = 0
        png_count = 0

        for image in images:
            try:
                fmt = self._choose_format(image)
                self._compress_image(image, fmt)
                compressed += 1
                if fmt == "JPEG":
                    jpeg_count += 1
                else:
                    png_count += 1
            except Exception as e:
                self.report({"ERROR"}, _ui_text(f"Failed to compress '{image.name}': {e}", f"「{image.name}」を圧縮できませんでした：{e}"))

        parts = []
        if jpeg_count:
            parts.append(_ui_text(f"{jpeg_count} as JPEG", f'JPEG で {jpeg_count} 枚'))
        if png_count:
            parts.append(_ui_text(f"{png_count} as PNG", f'PNG で {png_count} 枚'))
        detail = ", ".join(parts)

        self.report({"INFO"}, _ui_text(f"Compressed {compressed} texture(s) ({detail})", f"テクスチャ {compressed} 枚を圧縮しました（{detail}）"))
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout

        layout.prop(self, "texture_format")

        col = layout.column()
        col.enabled = self.texture_format in ("AUTO", "JPEG")
        col.prop(self, "jpeg_quality", slider=True)

        col = layout.column()
        col.enabled = self.texture_format == "AUTO"
        col.prop(self, "force_jpeg_no_alpha")

        layout.separator()
        layout.prop(self, "scope_all_textures")
        layout.prop(self, "scope_selected_objects")

        layout.separator()

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=380)
