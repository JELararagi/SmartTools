# SPDX-License-Identifier: GPL-3.0-or-later
"""Remove material slots attached to Decentraland collider meshes."""

import bpy
from ._collider_scope import collider_meshes, dialog, done, enter_object_mode


class OBJECT_OT_decentraland_strip_materials_from_colliders(bpy.types.Operator):
    bl_idname = "object.sfs_decentraland_strip_materials_from_colliders"
    bl_label = "Strip Materials from Colliders"
    bl_description = "Clear material slots on collider meshes and meshes parented to them"
    bl_options = {"UNDO"}

    scope_selected: bpy.props.BoolProperty(name="Only Selected", default=False)

    def invoke(self, context, _event):
        return dialog(self, context)

    def draw(self, _context):
        self.layout.prop(self, "scope_selected")

    def execute(self, context):
        if not enter_object_mode(context):
            return {"CANCELLED"}
        cleared = 0
        for obj in collider_meshes(context, self.scope_selected):
            cleared += len(obj.material_slots)
            obj.data.materials.clear()
        return done(self, f"Cleared {cleared} collider material slots", f"コライダーからマテリアルスロットを {cleared} 個削除しました")
