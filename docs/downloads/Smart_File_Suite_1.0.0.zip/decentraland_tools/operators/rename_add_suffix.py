import bpy
from ...ui_language_runtime import ui_text as _ui_text


class OBJECT_OT_decentraland_add_collider_suffix(bpy.types.Operator):
    bl_idname = 'object.sfs_decentraland_add_collider_suffix'
    bl_label = 'Add _collider Suffix'
    bl_description = "Add '_collider' suffix to selected objects"
    bl_options = {'UNDO'}

    only_meshes: bpy.props.BoolProperty(
        name="Only Mesh Objects",
        description="Only rename mesh objects",
        default=True,
    )

    def execute(self, context):
        renamed = 0
        for obj in context.selected_objects:
            if self.only_meshes and obj.type != "MESH":
                continue
            if not obj.name.endswith("_collider"):
                obj.name = f"{obj.name}_collider"
                renamed += 1
        self.report({"INFO"}, _ui_text(f"Renamed {renamed} objects", f"オブジェクト {renamed} 個の名前を変えました"))
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "only_meshes")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
