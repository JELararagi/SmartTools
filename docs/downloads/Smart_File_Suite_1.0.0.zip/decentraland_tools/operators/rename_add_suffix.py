"""SmartFile collider naming operator for the slot 4 replacement review."""

import bpy

from ...ui_language_runtime import ui_text


_SUFFIX = "_collider"


class OBJECT_OT_decentraland_add_collider_suffix(bpy.types.Operator):
    bl_idname = "object.sfs_decentraland_add_collider_suffix"
    bl_label = "Add _collider Suffix"
    bl_description = "Add '_collider' suffix to selected objects"
    bl_options = {"UNDO"}

    only_meshes: bpy.props.BoolProperty(
        name="Only Mesh Objects",
        description="Only rename mesh objects",
        default=True,
    )

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, _context):
        self.layout.prop(self, "only_meshes")

    def execute(self, context):
        targets = [
            obj
            for obj in context.selected_objects
            if (obj.type == "MESH" or not self.only_meshes)
            and not obj.name.endswith(_SUFFIX)
        ]
        for obj in targets:
            obj.name += _SUFFIX

        count = len(targets)
        message = ui_text(
            f"Renamed {count} objects",
            f"オブジェクト {count} 個の名前を変えました",
        )
        self.report({"INFO"}, message)
        return {"FINISHED"}
