# SPDX-License-Identifier: GPL-3.0-or-later
"""Clear UV layers from collider meshes used for Decentraland exports."""

import bpy
from ._collider_scope import collider_meshes, dialog, done, enter_object_mode


class OBJECT_OT_decentraland_remove_uvs_from_colliders(bpy.types.Operator):
    bl_idname = "object.sfs_decentraland_remove_uvs_from_colliders"
    bl_label = "Remove UVs from Colliders"
    bl_description = "Remove UV layers from collision meshes without changing visible meshes"
    bl_options = {"UNDO"}

    scope_selected: bpy.props.BoolProperty(name="Only Selected", default=False)

    def invoke(self, context, _event):
        return dialog(self, context)

    def draw(self, _context):
        self.layout.prop(self, "scope_selected")

    def execute(self, context):
        if not enter_object_mode(context):
            return {"CANCELLED"}
        removed = 0
        for obj in collider_meshes(context, self.scope_selected):
            for slot in reversed(tuple(obj.data.uv_layers)):
                obj.data.uv_layers.remove(slot)
                removed += 1
        return done(self, f"Removed {removed} collider UV layers", f"コライダーからUVレイヤーを {removed} 個削除しました")
