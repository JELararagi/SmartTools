"""Read only the avatar libraries the user selected in the current scene."""
import os
from pathlib import Path

import bpy
from ..ui_language_runtime import ui_text


FIELDS = {
    "rig": ("rig_library_file", "Rig library (.blend)", "リグ素材（.blend）"),
    "A": ("shape_a_library_file", "Shape A library (.blend)", "体型Aの素材（.blend）"),
    "B": ("shape_b_library_file", "Shape B library (.blend)", "体型Bの素材（.blend）"),
}


def draw_paths(layout, props, kinds):
    for kind in kinds:
        field, en, ja = FIELDS[kind]
        layout.prop(props, field, text=ui_text(en, ja))


def library_path(context, kind):
    field, en, ja = FIELDS[kind]
    label = ui_text(en, ja)
    raw = getattr(context.scene.dcl_tools, field)
    if not raw:
        raise ValueError(ui_text(f"Choose a file for {label}.", f"「{label}」のファイルを選んでください。"))
    if raw.startswith("//") and not bpy.data.filepath:
        raise ValueError(ui_text("Use an absolute path in an unsaved scene.", "未保存のシーンでは絶対パスを指定してください。"))
    path = Path(bpy.path.abspath(raw, library=context.scene.library)).resolve()
    if path.suffix.lower() != ".blend" or not path.is_file():
        raise ValueError(ui_text(f"Blend library unavailable: {path}", f"素材の .blend を開けません：{path}"))
    if bpy.data.filepath and os.path.samefile(path, bpy.data.filepath):
        raise ValueError(ui_text("Choose a library other than the current file.", "現在開いているファイル以外を選んでください。"))
    return str(path)


def load_collections(context, requests, *, editable=False):
    """Preflight every requested collection before linking anything to the scene."""
    plan = []
    for kind, name in requests:
        path = library_path(context, kind)
        with bpy.data.libraries.load(path, link=False) as (available, _unused):
            if name not in available.collections:
                raise ValueError(ui_text(f"{name} is missing in {Path(path).name}.", f"{Path(path).name} に「{name}」がありません。"))
        plan.append((path, name))
    original_ids = set(bpy.data.user_map())
    linked_here = []
    loaded = []
    try:
        for path, name in plan:
            collection = None
            if not editable:
                source_key = os.path.normcase(path)
                collection = next((c for c in context.scene.collection.children_recursive
                                   if c.library is None and c.get("sfs_rig_source") == source_key
                                   and c.get("sfs_rig_collection") == name), None)
            if collection is None:
                with bpy.data.libraries.load(path, link=False) as (_available, selected):
                    selected.collections = [name]
                collection = selected.collections[0]
                if collection is None or collection.library:
                    raise ValueError(ui_text(f"Cannot append {name}.", f"「{name}」を追加できません。"))
                if editable:
                    collection.name = name + "_Editable"
                else:
                    collection["sfs_rig_source"] = os.path.normcase(path)
                    collection["sfs_rig_collection"] = name
                context.scene.collection.children.link(collection)
                linked_here.append(collection)
            loaded.append(collection)
        context.view_layer.update()
        if editable:
            for collection in loaded:
                for obj in collection.all_objects:
                    if obj.type != 'MESH':
                        continue
                    with context.temp_override(active_object=obj, object=obj,
                                               selected_objects=[obj], selected_editable_objects=[obj]):
                        result = bpy.ops.object.transform_apply(location=True, rotation=True, scale=True, isolate_users=True)
                    if 'FINISHED' not in result:
                        raise ValueError(ui_text(f"Could not prepare {obj.name}.", f"「{obj.name}」の変換を適用できません。"))
        return loaded
    except Exception:
        for collection in linked_here:
            context.scene.collection.children.unlink(collection)
        # This synchronous import owns only IDs which did not exist before it.
        added_ids = set(bpy.data.user_map()) - original_ids
        if added_ids:
            bpy.data.batch_remove(ids=added_ids)
        raise
