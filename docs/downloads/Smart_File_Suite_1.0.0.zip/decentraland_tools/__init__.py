# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Decentraland Tools",
    "author": "JELararagi",
    "version": (1, 9, 0),
    "blender": (5, 1, 0),
    "location": "3D Viewport > Sidebar (N) > Decentraland Tools",
    "description": "Collection of tools for Decentraland asset creation and optimization (Blender 2.80 - 5.0+)",
    "category": "Object",
}

import bpy
from bpy.utils import register_class, unregister_class

from . import icon_loader
from .operators.avatar_limitations import OBJECT_OT_decentraland_avatar_limitations_calculator
from .operators.cleanup_colliders import OBJECT_OT_decentraland_cleanup_colliders
from .operators.compress_textures import OBJECT_OT_decentraland_compress_images
from .operators.create_parcels import (
    OBJECT_OT_decentraland_checker_map,
    OBJECT_OT_decentraland_cleanup_all_checker_maps,
    OBJECT_OT_decentraland_create_parcels,
    OBJECT_OT_decentraland_set_origin,
)
from .operators.documentation import OBJECT_OT_decentraland_asset_guidelines, OBJECT_OT_decentraland_open_documentation, OBJECT_OT_decentraland_scene_limits_guide
from .operators.emote_actions import OBJECT_OT_decentraland_create_emote_action, OBJECT_OT_decentraland_set_boundary_keys
from .operators.enable_backface_culling import OBJECT_OT_decentraland_enable_backface_culling
from .operators.export_composite import OBJECT_OT_decentraland_export_composite
from .operators.export_emote_glb import OBJECT_OT_decentraland_export_emote_glb
from .operators.export_lights import OBJECT_OT_decentraland_export_lights
from .operators.generate_lod import OBJECT_OT_decentraland_generate_lods, draw_lod_panel
from .operators.generate_thumbnail import (
    OBJECT_OT_decentraland_add_thumbnail_camera,
    OBJECT_OT_decentraland_add_thumbnail_lighting,
    OBJECT_OT_decentraland_render_thumbnail,
    _on_thumbnail_camera_property_update,
    _on_thumbnail_lighting_property_update,
    _on_thumbnail_resolution_update,
)
from .operators.import_composite import OBJECT_OT_decentraland_import_composite
from .operators.import_dcl_rig import OBJECT_OT_decentraland_limit_area_reference, OBJECT_OT_decentraland_add_prop, OBJECT_OT_decentraland_import_dcl_rig
from .operators.link_avatar_wearables import OBJECT_OT_decentraland_avatar_shapes
from .operators.particle_to_armature import OBJECT_OT_decentraland_particle_system_to_armature
from .operators.quick_export_gltf import OBJECT_OT_decentraland_export_scene, OBJECT_OT_decentraland_quick_export_gltf, OBJECT_OT_decentraland_update_all_exported_objects
from .operators.remove_empty_objects import OBJECT_OT_decentraland_remove_empty_objects
from .operators.remove_specular import OBJECT_OT_decentraland_remove_specular
from .operators.remove_uvs import OBJECT_OT_decentraland_remove_uvs_from_colliders
from .operators.rename_add_suffix import OBJECT_OT_decentraland_add_collider_suffix
from .operators.rename_textures import OBJECT_OT_decentraland_rename_textures_by_usage
from .operators.replace_materials import (
    MaterialListItem,
    OBJECT_OT_decentraland_add_source_material,
    OBJECT_OT_decentraland_remove_source_material,
    OBJECT_OT_decentraland_replace_materials,
)
from .operators.resize_textures import OBJECT_OT_decentraland_resize_textures
from .operators.scene_limitations import OBJECT_OT_decentraland_scene_limitations_calculator
from .operators.simplify_colliders import OBJECT_OT_decentraland_simplify_colliders
from .operators.strip_materials import OBJECT_OT_decentraland_strip_materials_from_colliders
from .operators.validate_emote import OBJECT_OT_decentraland_validate_emote
from .operators.validate_scene import OBJECT_OT_decentraland_scene_validator
from .operators.validate_textures import OBJECT_OT_decentraland_validate_textures

# Tab constants
TAB_ALL = "ALL"
TAB_SCENES = "SCENES"
TAB_WEARABLES = "WEARABLES"

# ---------------------------------------------------------------------------
# PropertyGroup: all Scene-level properties in one group
# ---------------------------------------------------------------------------


class DCLToolsSceneProperties(bpy.types.PropertyGroup):
    """All Decentraland Tools scene-level properties."""

    # Tab selection
    active_tab: bpy.props.EnumProperty(
        name="Tab",
        items=[
            (TAB_ALL, "All Tools", "Show all tools"),
            (TAB_SCENES, "Scenes", "Show scene tools"),
            (TAB_WEARABLES, "Wearables", "Show wearable and emote tools"),
        ],
        default=TAB_ALL,
    )

    # Experimental features toggle
    show_experimental: bpy.props.BoolProperty(
        name="Experimental Features",
        description="Show experimental features (LOD Generator, Other)",
        default=False,
    )


    # Emote workflow
    emote_start_frame: bpy.props.IntProperty(
        name="Start Frame",
        description="First frame of the emote clip",
        default=1,
        min=1,
        max=300,
    )
    emote_end_frame: bpy.props.IntProperty(
        name="End Frame",
        description="Last frame of the emote clip (max 300)",
        default=300,
        min=1,
        max=300,
    )
    emote_sampling_rate: bpy.props.IntProperty(
        name="Sampling Rate",
        description="Export bake step. 1 = full fidelity, 2 recommended, 3 for extra size reduction",
        default=1,
        min=1,
        max=6,
    )
    emote_strict_validation: bpy.props.BoolProperty(
        name="Strict Validation",
        description="Treat warnings as blocking errors for export",
        default=False,
    )

    # LOD Generator
    lod_levels: bpy.props.IntProperty(
        name="LOD Levels",
        description="Number of LOD levels to generate",
        default=3,
        min=1,
        max=4,
    )
    lod1_ratio: bpy.props.FloatProperty(
        name="LOD 1 Ratio",
        description="Decimation ratio for LOD 1 (e.g. 0.5 = keep 50%)",
        default=0.50,
        min=0.01,
        max=0.99,
        subtype="FACTOR",
    )
    lod2_ratio: bpy.props.FloatProperty(
        name="LOD 2 Ratio",
        description="Decimation ratio for LOD 2",
        default=0.15,
        min=0.01,
        max=0.99,
        subtype="FACTOR",
    )
    lod3_ratio: bpy.props.FloatProperty(
        name="LOD 3 Ratio",
        description="Decimation ratio for LOD 3",
        default=0.05,
        min=0.01,
        max=0.99,
        subtype="FACTOR",
    )
    lod4_ratio: bpy.props.FloatProperty(
        name="LOD 4 Ratio",
        description="Decimation ratio for LOD 4",
        default=0.02,
        min=0.01,
        max=0.99,
        subtype="FACTOR",
    )
    lod_create_collection: bpy.props.BoolProperty(
        name="Create LOD Collection",
        description="Place generated LODs in a dedicated collection",
        default=True,
    )

    # Particle System Converter
    ps_converter_out_collection: bpy.props.StringProperty(
        name="Output Collection",
        description="Collection name for converted armature and objects",
        default="ParticleArmature_Output",
    )
    ps_converter_start_frame: bpy.props.IntProperty(
        name="Start Frame", description="Start frame for animation conversion", default=1, min=1
    )
    ps_converter_end_frame: bpy.props.IntProperty(
        name="End Frame", description="End frame for animation conversion", default=250, min=1
    )

    # Thumbnail generation
    thumbnail_camera_name: bpy.props.StringProperty(default="")
    thumbnail_target_name: bpy.props.StringProperty(default="")
    thumbnail_camera_base_distance: bpy.props.FloatProperty(default=2.5, min=0.2)
    thumbnail_camera_zoom: bpy.props.FloatProperty(
        name="Zoom",
        description="Zoom camera in/out (lower = closer)",
        default=1.0,
        min=0.05,
        max=4.0,
        update=_on_thumbnail_camera_property_update,
    )
    thumbnail_camera_side: bpy.props.FloatProperty(
        name="Side",
        description="Move camera left or right",
        default=0.0,
        min=-20.0,
        max=20.0,
        update=_on_thumbnail_camera_property_update,
    )
    thumbnail_camera_up: bpy.props.FloatProperty(
        name="Up/Down",
        description="Move camera up or down",
        default=0.0,
        min=-20.0,
        max=20.0,
        update=_on_thumbnail_camera_property_update,
    )
    thumbnail_camera_rotate: bpy.props.FloatProperty(
        name="Rotate",
        description="Orbit camera around the active target in degrees",
        default=35.0,
        min=-180.0,
        max=180.0,
        update=_on_thumbnail_camera_property_update,
    )

    thumbnail_light_count: bpy.props.IntProperty(
        name="Lights",
        description="Number of thumbnail lights",
        default=3,
        min=1,
        max=8,
        update=_on_thumbnail_lighting_property_update,
    )
    thumbnail_light_height: bpy.props.FloatProperty(
        name="Height",
        description="Height of thumbnail lights around target",
        default=1.0,
        min=-10.0,
        max=30.0,
        update=_on_thumbnail_lighting_property_update,
    )
    thumbnail_light_distance: bpy.props.FloatProperty(
        name="Distance",
        description="Distance of thumbnail lights from target",
        default=2.2,
        min=0.2,
        max=30.0,
        update=_on_thumbnail_lighting_property_update,
    )
    thumbnail_light_strength: bpy.props.FloatProperty(
        name="Strength",
        description="Area light energy",
        default=60.0,
        min=0.0,
        max=300.0,
        update=_on_thumbnail_lighting_property_update,
    )
    thumbnail_render_engine: bpy.props.EnumProperty(
        name="Render Engine",
        description="Engine used for thumbnail rendering",
        items=[
            ("EEVEE", "Eevee", "Use Eevee render engine"),
            ("CYCLES", "Cycles", "Use Cycles render engine"),
        ],
        default="EEVEE",
    )
    thumbnail_resolution_preset: bpy.props.EnumProperty(
        name="Output Size",
        description="Square render size presets or custom size",
        items=[
            ("512", "512 x 512", "Render 512 square"),
            ("1024", "1024 x 1024", "Render 1024 square"),
            ("2048", "2048 x 2048", "Render 2048 square"),
            ("CUSTOM", "Custom", "Use custom width and height"),
        ],
        default="1024",
        update=_on_thumbnail_resolution_update,
    )
    thumbnail_resolution_x: bpy.props.IntProperty(
        name="Width",
        description="Custom output width in pixels",
        default=1024,
        min=16,
        max=16384,
        update=_on_thumbnail_resolution_update,
    )
    thumbnail_resolution_y: bpy.props.IntProperty(
        name="Height",
        description="Custom output height in pixels",
        default=1024,
        min=16,
        max=16384,
        update=_on_thumbnail_resolution_update,
    )
    thumbnail_png_compression: bpy.props.IntProperty(
        name="Compression",
        description="PNG compression amount (0 = fastest, 100 = smallest)",
        default=85,
        min=0,
        max=100,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _dcl_scene_props(context):
    scene = getattr(context, "scene", None)
    return getattr(scene, "dcl_tools", None) if scene is not None else None


def _dcl_section_visible(context, tabs, *, experimental=False):
    props = _dcl_scene_props(context)
    if props is None:
        return False
    tab = str(getattr(props, "active_tab", TAB_ALL) or TAB_ALL)
    if tab not in set(tabs):
        return False
    return bool(getattr(props, "show_experimental", False)) if experimental else True


def _dcl_draw_native_header_help(layout, section_label):
    """Append help to Blender's native Panel header without drawing a custom foldout."""
    try:
        row = layout.row(align=True)
        row.alignment = 'RIGHT'
        row.scale_x = 0.82
        row.scale_y = 1.0
        op = row.operator('import_scene.sfs_system_open_help', text='', icon='QUESTION', emboss=True)
        op.help_key = 'decentraland_section'
        op.lane = 'OTHER'
        op.section = str(section_label)
        op.display_title = str(section_label)
    except Exception:
        pass


def _op(target, bl_idname, text, icon_name, fallback_icon):
    """Draw an operator button with Blender's built-in icon when it clearly matches the function."""
    target.operator(bl_idname, text=text, icon=fallback_icon or 'NONE')


# ---------------------------------------------------------------------------
# Section drawing functions
# ---------------------------------------------------------------------------


def _draw_scene_creation(layout, props):
    col = layout.column(align=True)
    col.scale_y = 1.2
    _op(col, OBJECT_OT_decentraland_create_parcels.bl_idname, "Create Parcels", "GRID_DOTS", "MESH_PLANE")
    row = col.row(align=True)
    _op(row, OBJECT_OT_decentraland_scene_limitations_calculator.bl_idname, "Scene Limitations", "RULER", 'NONE')
    _op(row, OBJECT_OT_decentraland_scene_validator.bl_idname, "Scene Validator", "SHIELD_CHECK", "SEQUENCE")
    row = col.row(align=True)
    _op(row, OBJECT_OT_decentraland_checker_map.bl_idname, "Checker Map", "GRID_DOTS", "TEXTURE")
    _op(row, OBJECT_OT_decentraland_cleanup_all_checker_maps.bl_idname, "Cleanup All Checker Maps", "TRASH_X", "CANCEL")


def _draw_avatars(layout, props):
    col = layout.column(align=True)
    col.scale_y = 1.2
    row = col.row(align=True)
    _op(row, OBJECT_OT_decentraland_avatar_shapes.bl_idname, "Avatar Shapes", "FRIENDS", "ARMATURE_DATA")
    _op(row, OBJECT_OT_decentraland_avatar_limitations_calculator.bl_idname, "Wearable Limits", "SHIRT_SPORT", 'NONE')


def _draw_emotes(layout, props):
    col = layout.column(align=True)
    col.scale_y = 1.2
    _op(col, OBJECT_OT_decentraland_import_dcl_rig.bl_idname, "Import DCL Rig", "ASSET", "ARMATURE_DATA")
    row = col.row(align=True)
    _op(row, OBJECT_OT_decentraland_add_prop.bl_idname, "Add Prop", "EMOTE_PROPS", "OBJECT_DATA")
    _op(row, OBJECT_OT_decentraland_limit_area_reference.bl_idname, "Limit Area Reference", "DIMENSIONS", "MESH_GRID")
    col.separator(factor=0.3)
    row = col.row(align=True)
    _op(row, OBJECT_OT_decentraland_create_emote_action.bl_idname, "Create Emote Action", "EDIT", "ACTION")
    _op(row, OBJECT_OT_decentraland_set_boundary_keys.bl_idname, "Set Boundary Keys", "PROGRESS_CHECK", "KEYTYPE_JITTER_VEC")
    col.separator(factor=0.3)
    _op(col, OBJECT_OT_decentraland_validate_emote.bl_idname, "Validate Emote", "PROGRESS_CHECK", "CHECKMARK")
    col.separator(factor=0.3)
    settings = col.box()
    settings.label(text="Emote Settings")
    settings.prop(props, "emote_start_frame")
    settings.prop(props, "emote_end_frame")
    settings.prop(props, "emote_sampling_rate")
    settings.prop(props, "emote_strict_validation")


def _draw_materials(layout, props):
    col = layout.column(align=True)
    col.scale_y = 1.2
    row = col.row(align=True)
    _op(row, OBJECT_OT_decentraland_replace_materials.bl_idname, "Replace Materials", "REPLACE", "MATERIAL_DATA")
    _op(row, OBJECT_OT_decentraland_resize_textures.bl_idname, "Resize Textures", "IMAGE_IN_PICTURE", "IMAGE_DATA")
    col.separator(factor=0.3)
    row = col.row(align=True)
    _op(row, OBJECT_OT_decentraland_validate_textures.bl_idname, "Validate Textures", "PHOTO_CHECK", "TEXTURE")
    _op(row, OBJECT_OT_decentraland_enable_backface_culling.bl_idname, "Enable Backface Culling", "FLIP_VERTICAL", "NORMALS_FACE")
    col.separator(factor=0.3)
    row = col.row(align=True)
    _op(row, OBJECT_OT_decentraland_remove_specular.bl_idname, "Remove Specular", "SPHERE_OFF", "SHADING_RENDERED")
    _op(row, OBJECT_OT_decentraland_compress_images.bl_idname, "Compress Images", "PACKAGE_EXPORT", "IMAGE_DATA")


def _draw_lod(layout, props, context):
    del props
    draw_lod_panel(layout, context)


def _draw_cleanup(layout, props):
    col = layout.column(align=True)
    col.scale_y = 1.2
    row = col.row(align=True)
    _op(row, OBJECT_OT_decentraland_remove_empty_objects.bl_idname, "Remove Empty Objects", "TRASH_X", "X")
    _op(row, OBJECT_OT_decentraland_rename_textures_by_usage.bl_idname, "Rename Textures", "PHOTO_EDIT", "TEXTURE")


def _draw_colliders(layout, props):
    col = layout.column(align=True)
    col.scale_y = 1.2
    row = col.row(align=True)
    _op(row, OBJECT_OT_decentraland_add_collider_suffix.bl_idname, "Add Suffix", "TAG", "OUTLINER_OB_MESH")
    _op(row, OBJECT_OT_decentraland_remove_uvs_from_colliders.bl_idname, "Remove UVs", "MAP_OFF", "UV")
    row = col.row(align=True)
    _op(row, OBJECT_OT_decentraland_strip_materials_from_colliders.bl_idname, "Strip Materials", "SPHERE_OFF", "MATERIAL")
    _op(row, OBJECT_OT_decentraland_simplify_colliders.bl_idname, "Simplify", "POLYGON", "MOD_DECIM")
    _op(col, OBJECT_OT_decentraland_cleanup_colliders.bl_idname, "Clean Up Colliders", "ERASER", "BRUSH_DATA")


def _draw_thumbnail_camera(layout, props):
    col = layout.column(align=True)
    col.scale_y = 1.15
    _op(col, OBJECT_OT_decentraland_add_thumbnail_camera.bl_idname, "Add Camera", "CAMERA", "CAMERA_DATA")
    col.prop(props, "thumbnail_camera_zoom", slider=True)
    col.prop(props, "thumbnail_camera_side", slider=True)
    col.prop(props, "thumbnail_camera_up", slider=True)
    col.prop(props, "thumbnail_camera_rotate", slider=True)


def _draw_thumbnail_lighting(layout, props):
    col = layout.column(align=True)
    col.scale_y = 1.15
    _op(col, OBJECT_OT_decentraland_add_thumbnail_lighting.bl_idname, "Add Lighting", "BULB", "LIGHT_AREA")
    col.prop(props, "thumbnail_light_count")
    col.prop(props, "thumbnail_light_height", slider=True)
    col.prop(props, "thumbnail_light_distance", slider=True)
    col.prop(props, "thumbnail_light_strength", slider=True)


def _draw_thumbnail_output(layout, props):
    col = layout.column(align=True)
    col.scale_y = 1.15
    col.prop(props, "thumbnail_render_engine", text="Render Engine")
    col.prop(props, "thumbnail_resolution_preset", text="Output Size")
    if props.thumbnail_resolution_preset == "CUSTOM":
        size_row = col.row(align=True)
        size_row.prop(props, "thumbnail_resolution_x")
        size_row.prop(props, "thumbnail_resolution_y")
    col.prop(props, "thumbnail_png_compression", slider=True)
    _op(col, OBJECT_OT_decentraland_render_thumbnail.bl_idname, "Render Image", "PACKAGE_EXPORT", "RENDER_STILL")


def _draw_other(layout, props):
    col = layout.column(align=True)
    col.scale_y = 1.2
    row = col.row(align=True)
    _op(row, OBJECT_OT_decentraland_export_lights.bl_idname, "Export Lights", "BULB", "LIGHT_DATA")
    _op(row, OBJECT_OT_decentraland_particle_system_to_armature.bl_idname, "Particle2Armat...", "BONE", "PARTICLES")


# ---------------------------------------------------------------------------
# Panel
# ---------------------------------------------------------------------------


class VIEW3D_PT_decentraland_decentraland_tools(bpy.types.Panel):
    bl_label = 'Decentraland Tools'
    bl_idname = 'VIEW3D_PT_decentraland_decentraland_tools'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart File'
    bl_parent_id = 'SF_PT_reference_manager_reference_manager_workspace'
    bl_options = set()

    def draw(self, context):
        layout = self.layout
        props = context.scene.dcl_tools
        row = layout.row(align=True)
        row.prop(props, "active_tab", expand=True)
        layout.prop(props, "show_experimental")
        return None


class _DCL_PT_native_section:
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart File'
    bl_parent_id = 'VIEW3D_PT_decentraland_decentraland_tools'
    bl_options = set()
    _dcl_tabs = (TAB_ALL,)
    _dcl_experimental = False

    @classmethod
    def poll(cls, context):
        return _dcl_section_visible(context, cls._dcl_tabs, experimental=cls._dcl_experimental)

    def draw_header(self, context):
        del context
        _dcl_draw_native_header_help(self.layout, self.bl_label)
        return None


class VIEW3D_PT_decentraland_scene_creation(_DCL_PT_native_section, bpy.types.Panel):
    bl_label = 'Scene Creation'
    bl_idname = 'VIEW3D_PT_decentraland_scene_creation'
    bl_order = 0
    _dcl_tabs = (TAB_ALL, TAB_SCENES)

    def draw(self, context):
        _draw_scene_creation(self.layout, context.scene.dcl_tools)
        return None


class VIEW3D_PT_decentraland_avatars(_DCL_PT_native_section, bpy.types.Panel):
    bl_label = 'Avatars'
    bl_idname = 'VIEW3D_PT_decentraland_avatars'
    bl_order = 10
    _dcl_tabs = (TAB_ALL, TAB_WEARABLES)

    def draw(self, context):
        _draw_avatars(self.layout, context.scene.dcl_tools)
        return None


class VIEW3D_PT_decentraland_emotes(_DCL_PT_native_section, bpy.types.Panel):
    bl_label = 'Emotes'
    bl_idname = 'VIEW3D_PT_decentraland_emotes'
    bl_order = 20
    _dcl_tabs = (TAB_ALL, TAB_WEARABLES)

    def draw(self, context):
        _draw_emotes(self.layout, context.scene.dcl_tools)
        return None


class VIEW3D_PT_decentraland_materials(_DCL_PT_native_section, bpy.types.Panel):
    bl_label = 'Materials & Textures'
    bl_idname = 'VIEW3D_PT_decentraland_materials'
    bl_order = 30
    _dcl_tabs = (TAB_ALL, TAB_SCENES, TAB_WEARABLES)

    def draw(self, context):
        _draw_materials(self.layout, context.scene.dcl_tools)
        return None


class VIEW3D_PT_decentraland_lod(_DCL_PT_native_section, bpy.types.Panel):
    bl_label = 'LOD Generator'
    bl_idname = 'VIEW3D_PT_decentraland_lod'
    bl_order = 40
    _dcl_tabs = (TAB_ALL, TAB_SCENES)
    _dcl_experimental = True

    def draw(self, context):
        _draw_lod(self.layout, context.scene.dcl_tools, context)
        return None


class VIEW3D_PT_decentraland_cleanup(_DCL_PT_native_section, bpy.types.Panel):
    bl_label = 'CleanUp'
    bl_idname = 'VIEW3D_PT_decentraland_cleanup'
    bl_order = 50
    _dcl_tabs = (TAB_ALL, TAB_SCENES)

    def draw(self, context):
        _draw_cleanup(self.layout, context.scene.dcl_tools)
        return None


class VIEW3D_PT_decentraland_colliders(_DCL_PT_native_section, bpy.types.Panel):
    bl_label = 'Collider Management'
    bl_idname = 'VIEW3D_PT_decentraland_colliders'
    bl_order = 60
    _dcl_tabs = (TAB_ALL, TAB_SCENES)

    def draw(self, context):
        _draw_colliders(self.layout, context.scene.dcl_tools)
        return None


class VIEW3D_PT_decentraland_thumbnail(_DCL_PT_native_section, bpy.types.Panel):
    bl_label = 'Generate Thumbnail'
    bl_idname = 'VIEW3D_PT_decentraland_thumbnail'
    bl_order = 70
    _dcl_tabs = (TAB_ALL, TAB_SCENES, TAB_WEARABLES)

    def draw(self, context):
        del context
        return None


class _DCL_PT_thumbnail_child(_DCL_PT_native_section):
    bl_parent_id = 'VIEW3D_PT_decentraland_thumbnail'
    _dcl_tabs = (TAB_ALL, TAB_SCENES, TAB_WEARABLES)


class VIEW3D_PT_decentraland_thumbnail_camera(_DCL_PT_thumbnail_child, bpy.types.Panel):
    bl_label = 'Camera Controls'
    bl_idname = 'VIEW3D_PT_decentraland_thumbnail_camera'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 0

    def draw(self, context):
        _draw_thumbnail_camera(self.layout, context.scene.dcl_tools)
        return None


class VIEW3D_PT_decentraland_thumbnail_lighting(_DCL_PT_thumbnail_child, bpy.types.Panel):
    bl_label = 'Lighting Controls'
    bl_idname = 'VIEW3D_PT_decentraland_thumbnail_lighting'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 10

    def draw(self, context):
        _draw_thumbnail_lighting(self.layout, context.scene.dcl_tools)
        return None


class VIEW3D_PT_decentraland_thumbnail_output(_DCL_PT_thumbnail_child, bpy.types.Panel):
    bl_label = 'Thumbnail Output'
    bl_idname = 'VIEW3D_PT_decentraland_thumbnail_output'
    bl_order = 20

    def draw(self, context):
        _draw_thumbnail_output(self.layout, context.scene.dcl_tools)
        return None


class VIEW3D_PT_decentraland_other(_DCL_PT_native_section, bpy.types.Panel):
    bl_label = 'Other'
    bl_idname = 'VIEW3D_PT_decentraland_other'
    bl_order = 80
    _dcl_tabs = (TAB_ALL, TAB_SCENES, TAB_WEARABLES)
    _dcl_experimental = True

    def draw(self, context):
        _draw_other(self.layout, context.scene.dcl_tools)
        return None


class VIEW3D_PT_decentraland_decentraland_export(bpy.types.Panel):
    bl_label = 'Decentraland Export'
    bl_idname = 'VIEW3D_PT_decentraland_decentraland_export'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart File'
    bl_parent_id = 'VIEW3D_PT_decentraland_decentraland_tools'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 90

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.scale_y = 1.2
        _op(col, OBJECT_OT_decentraland_export_scene.bl_idname, "Export Scene", "DCL_LOGO", "SCENE_DATA")
        _op(col, OBJECT_OT_decentraland_update_all_exported_objects.bl_idname, "Update All Exported Objects", "REFRESH", "FILE_REFRESH")
        row = col.row(align=True)
        _op(row, OBJECT_OT_decentraland_quick_export_gltf.bl_idname, "Export glTF", "PACKAGE_EXPORT", "EXPORT")
        _op(row, OBJECT_OT_decentraland_export_emote_glb.bl_idname, "Export Emote GLB", "EMOTE_EXPORT", "EXPORT")
        col.separator(factor=0.5)
        row = col.row(align=True)
        _op(row, OBJECT_OT_decentraland_export_composite.bl_idname, "Export Composite", "COMPOSITE_EXPORT", "EXPORT")
        _op(row, OBJECT_OT_decentraland_import_composite.bl_idname, "Import Composite", "COMPOSITE_IMPORT", "IMPORT")
        return None


class VIEW3D_PT_decentraland_decentraland_help(bpy.types.Panel):
    bl_label = 'Decentraland Help'
    bl_idname = 'VIEW3D_PT_decentraland_decentraland_help'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart File'
    bl_parent_id = 'VIEW3D_PT_decentraland_decentraland_tools'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 100

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.scale_y = 1.2
        _op(col, OBJECT_OT_decentraland_open_documentation.bl_idname, "Creator Docs", "BOOK", "HELP")
        _op(col, OBJECT_OT_decentraland_scene_limits_guide.bl_idname, "Limits Guide", "BOOK_2", 'NONE')
        _op(col, OBJECT_OT_decentraland_asset_guidelines.bl_idname, "Assets Guide", "FILE_DESC", "FILE_TEXT")
        return None


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    DCLToolsSceneProperties,
    MaterialListItem,
    OBJECT_OT_decentraland_remove_uvs_from_colliders,
    OBJECT_OT_decentraland_strip_materials_from_colliders,
    OBJECT_OT_decentraland_add_collider_suffix,
    OBJECT_OT_decentraland_simplify_colliders,
    OBJECT_OT_decentraland_cleanup_colliders,
    OBJECT_OT_decentraland_remove_empty_objects,
    OBJECT_OT_decentraland_export_lights,
    OBJECT_OT_decentraland_import_dcl_rig,
    OBJECT_OT_decentraland_add_prop,
    OBJECT_OT_decentraland_limit_area_reference,
    OBJECT_OT_decentraland_validate_emote,
    OBJECT_OT_decentraland_export_emote_glb,
    OBJECT_OT_decentraland_create_emote_action,
    OBJECT_OT_decentraland_set_boundary_keys,
    OBJECT_OT_decentraland_create_parcels,
    OBJECT_OT_decentraland_set_origin,
    OBJECT_OT_decentraland_checker_map,
    OBJECT_OT_decentraland_cleanup_all_checker_maps,
    OBJECT_OT_decentraland_rename_textures_by_usage,
    OBJECT_OT_decentraland_resize_textures,
    OBJECT_OT_decentraland_compress_images,
    OBJECT_OT_decentraland_remove_specular,
    OBJECT_OT_decentraland_enable_backface_culling,
    OBJECT_OT_decentraland_avatar_shapes,
    OBJECT_OT_decentraland_particle_system_to_armature,
    OBJECT_OT_decentraland_scene_limitations_calculator,
    OBJECT_OT_decentraland_avatar_limitations_calculator,
    OBJECT_OT_decentraland_replace_materials,
    OBJECT_OT_decentraland_add_source_material,
    OBJECT_OT_decentraland_remove_source_material,
    OBJECT_OT_decentraland_validate_textures,
    OBJECT_OT_decentraland_scene_validator,
    OBJECT_OT_decentraland_generate_lods,
    OBJECT_OT_decentraland_add_thumbnail_camera,
    OBJECT_OT_decentraland_add_thumbnail_lighting,
    OBJECT_OT_decentraland_render_thumbnail,
    OBJECT_OT_decentraland_quick_export_gltf,
    OBJECT_OT_decentraland_export_scene,
    OBJECT_OT_decentraland_update_all_exported_objects,
    OBJECT_OT_decentraland_export_composite,
    OBJECT_OT_decentraland_import_composite,
    OBJECT_OT_decentraland_open_documentation,
    OBJECT_OT_decentraland_scene_limits_guide,
    OBJECT_OT_decentraland_asset_guidelines,
    VIEW3D_PT_decentraland_decentraland_tools,
    VIEW3D_PT_decentraland_scene_creation,
    VIEW3D_PT_decentraland_avatars,
    VIEW3D_PT_decentraland_emotes,
    VIEW3D_PT_decentraland_materials,
    VIEW3D_PT_decentraland_lod,
    VIEW3D_PT_decentraland_cleanup,
    VIEW3D_PT_decentraland_colliders,
    VIEW3D_PT_decentraland_thumbnail,
    VIEW3D_PT_decentraland_thumbnail_camera,
    VIEW3D_PT_decentraland_thumbnail_lighting,
    VIEW3D_PT_decentraland_thumbnail_output,
    VIEW3D_PT_decentraland_other,
    VIEW3D_PT_decentraland_decentraland_export,
    VIEW3D_PT_decentraland_decentraland_help,
)



def _apply_suite_settings_after_pointer_registration(context=None) -> None:
    try:
        from .. import settings as _sfs_settings
        if hasattr(_sfs_settings, 'apply_all'):
            _sfs_settings.apply_all(context or getattr(bpy, 'context', None))
    except Exception:
        pass

def register():
    # Load custom icons first
    icon_loader.register()

    for cls in classes:
        register_class(cls)

    # Register the single PropertyGroup pointer on Scene
    bpy.types.Scene.dcl_tools = bpy.props.PointerProperty(type=DCLToolsSceneProperties)
    _apply_suite_settings_after_pointer_registration(getattr(bpy, 'context', None))

    # Replace Materials operator properties (on WindowManager)
    bpy.types.WindowManager.replace_materials_add = bpy.props.StringProperty(
        name="Replace Materials Add",
        description="Temporary property for adding materials to replacement list",
        default="",
    )
    bpy.types.WindowManager.replace_materials_remove = bpy.props.IntProperty(
        name="Replace Materials Remove",
        description="Temporary property for removing materials from replacement list",
        default=-1,
    )


def unregister():
    for cls in reversed(classes):
        unregister_class(cls)

    # Unregister PropertyGroup pointer
    del bpy.types.Scene.dcl_tools

    # Unregister Replace Materials properties
    if hasattr(bpy.types.WindowManager, "replace_materials_add"):
        del bpy.types.WindowManager.replace_materials_add
    if hasattr(bpy.types.WindowManager, "replace_materials_remove"):
        del bpy.types.WindowManager.replace_materials_remove

    # Unload custom icons last
    icon_loader.unregister()


if __name__ == "__main__":
    register()
