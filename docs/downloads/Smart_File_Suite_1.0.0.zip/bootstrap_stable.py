# Copyright (C) 2026 JELararagi
"""Stable bootstrap for Smart File.

The heavy source preprocessing step is performed ahead of time in the shipped
package, so startup can load the already-normalized feature sources directly.
This bootstrap therefore keeps only the lightweight helper wiring and class
translation collection that are still needed at runtime.
"""

from __future__ import annotations

import hashlib
import importlib
import marshal
import os
import sys
import zlib
from pathlib import Path as _Path


def _load_legacy_boot():
    """Load one identical translation-support path in GUI and background mode."""
    package = __package__ or __name__.rpartition('.')[0]
    module_name = f"{package}.translation_tooltip_support"
    module = sys.modules.get(module_name)
    if module is None:
        module = importlib.import_module(module_name)
    return module


_legacy_boot = _load_legacy_boot()


def _inject_runtime_helpers(namespace: dict) -> None:
    namespace['_sf_collect_runtime_class_translations'] = _legacy_boot._sf_collect_runtime_class_translations
    namespace['_sf_flush_pending_translations'] = _legacy_boot._sf_flush_pending_translations
    namespace['_sf_restore_registration_compatible_methods'] = _legacy_boot._sf_restore_registration_compatible_methods


def _register_bl_info_translations(namespace: dict) -> None:
    try:
        bl_info = namespace.get('bl_info')
        if not isinstance(bl_info, dict):
            return
        name = str(bl_info.get('name', '') or '').strip()
        location = str(bl_info.get('location', '') or '').strip()
        description = str(bl_info.get('description', '') or '').strip()
        if name:
            name_jp = _legacy_boot._sf_guess_label_japanese(name)
            if name_jp and name_jp != name:
                _legacy_boot._sf_register_pending_translation(name, name_jp)
        if location:
            location_jp = _legacy_boot._sf_guess_label_japanese(location)
            if location_jp and location_jp != location:
                _legacy_boot._sf_register_pending_translation(location, location_jp)
        if description:
            desc_jp = _legacy_boot._sf_guess_label_japanese(description)
            if desc_jp and desc_jp != description:
                _legacy_boot._sf_register_pending_translation(description, desc_jp)
    except Exception:
        pass


# --- Toolset complete i18n bootstrap v70 START ---
_PROP_FACTORY_NAMES = (
    'StringProperty', 'BoolProperty', 'BoolVectorProperty', 'IntProperty',
    'IntVectorProperty', 'FloatProperty', 'FloatVectorProperty',
    'EnumProperty', 'CollectionProperty', 'PointerProperty',
)

class _patched_prop_factories:
    """No-op compatibility context; never replaces process-global bpy.props."""
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


def _preprocess_source_for_i18n(source: str) -> str:
    text = str(source or '')
    if str(os.environ.get('SFS_RUNTIME_I18N_PREPROCESS', '') or '').strip() not in {'1', 'true', 'TRUE', 'yes', 'YES'}:
        return text
    try:
        text = _legacy_boot._sf_preprocess_bilingual_token_strings(text)
    except Exception:
        pass
    try:
        text = _legacy_boot._sf_preprocess_feature_source(text)
    except Exception:
        pass
    return text
# --- Toolset complete i18n bootstrap v70 END ---


_BOOTSTRAP_CACHE_SCHEMA = 5
_BOOTSTRAP_CACHE_PREFIX = "bootstrap_features_v5_"
_PACKAGED_CACHE_NAME = "bootstrap_features_precompiled_v4.marshal.zlib"
# Exact source order compiled into the release cache.  Keeping this tuple fixed
# avoids a package-directory glob merely from enabling the add-on.
_PACKAGED_FEATURE_FILES = (
    "core.py", "main_append.py", "asset_reader.py", "catalog_tools.py",
    "reference_manager.py", "external_assets.py", "reference_toolkit.py",
    "pipeline_bridge.py", "representation_toolkit.py", "project_guard.py",
    "shot_state_toolkit.py", "shot_queue_toolkit.py", "root_repath_toolkit.py",
    "assembly_guard_toolkit.py", "dependency_cockpit_toolkit.py",
    "container_deck_toolkit.py", "context_root_toolkit.py",
    "root_watch_toolkit.py", "batch_preview.py", "publisher.py",
    "history_integration.py", "file_pipeline.py", "register.py",
    "sf_import_max_native.py",
)
_LAST_BOOTSTRAP_CACHE_SOURCE = ""
_LAST_BOOTSTRAP_PHASES: dict[str, float] = {}


def _runtime_cache_dir() -> _Path | None:
    """Return the CONFIG-side cache directory without writing to the Extension."""
    try:
        bpy = getattr(_legacy_boot, '_bpy', None)
        if bpy is None:
            import bpy as _bpy
            bpy = _bpy
        base = str(bpy.utils.user_resource('CONFIG') or '').strip()
        if not base:
            return None
        path = _Path(base) / 'Smart_File_Suite' / 'cache'
        path.mkdir(parents=True, exist_ok=True)
        return path
    except Exception:
        return None


def _cache_identity(pkg_dir: _Path, feature_files: tuple[str, ...]) -> tuple[str, tuple[tuple[str, str], ...]]:
    """Hash every source that can affect the compiled feature code.

    Reading the files costs only a few milliseconds and is kept even on a cache
    hit so a same-name/same-size source update cannot reuse stale bytecode.  The
    expensive part is Python compilation, which this cache avoids.
    """
    digest = hashlib.sha256()
    digest.update(f'schema={_BOOTSTRAP_CACHE_SCHEMA}'.encode('ascii'))
    digest.update(str(getattr(sys.implementation, 'cache_tag', '') or '').encode('utf-8'))
    digest.update(str(tuple(sys.version_info[:3])).encode('ascii'))
    # Keep the identity independent of the installation path so the verified
    # cache shipped with the Extension can be reused after installation. Source
    # hashes, Python ABI, schema, and preprocessing mode still invalidate stale
    # bytecode deterministically.
    digest.update(str(os.environ.get('SFS_RUNTIME_I18N_PREPROCESS', '') or '').encode('utf-8'))
    records: list[tuple[str, str]] = []
    support_files = (
        'bootstrap_stable.py',
        'translation_exact.py',
        'translation_phrases.py',
        'translation_tooltip_support.py',
    )
    ordered = tuple(dict.fromkeys(tuple(feature_files) + support_files))
    for relative in ordered:
        path = pkg_dir / relative
        try:
            data = path.read_bytes()
        except Exception:
            data = b''
        file_hash = hashlib.sha256(data).hexdigest()
        records.append((relative, file_hash))
        digest.update(relative.encode('utf-8', 'surrogatepass'))
        digest.update(b'\0')
        digest.update(bytes.fromhex(file_hash))
    return digest.hexdigest(), tuple(records)


def _cache_path(pkg_dir: _Path, feature_files: tuple[str, ...]) -> tuple[_Path | None, dict]:
    identity, records = _cache_identity(pkg_dir, feature_files)
    cache_dir = _runtime_cache_dir()
    meta = {
        'schema': _BOOTSTRAP_CACHE_SCHEMA,
        'identity': identity,
        'cache_tag': str(getattr(sys.implementation, 'cache_tag', '') or ''),
        'python_version': tuple(sys.version_info[:3]),
        'feature_files': tuple(feature_files),
        'records': records,
    }
    if cache_dir is None:
        return None, meta
    return cache_dir / f'{_BOOTSTRAP_CACHE_PREFIX}{identity}.marshal', meta


def _validate_compiled_payload(payload: object, expected: dict) -> tuple[object, ...] | None:
    if not isinstance(payload, dict):
        return None
    for key in ('schema', 'identity', 'cache_tag', 'python_version', 'feature_files', 'records'):
        if payload.get(key) != expected.get(key):
            return None
    codes = payload.get('codes')
    if not isinstance(codes, tuple) or len(codes) != len(expected['feature_files']):
        return None
    if not all(hasattr(code, 'co_code') for code in codes):
        return None
    return codes


def _load_compiled_features(cache_path: _Path | None, expected: dict) -> tuple[object, ...] | None:
    if cache_path is None or not cache_path.is_file():
        return None
    try:
        with cache_path.open('rb') as fh:
            payload = marshal.load(fh)
        return _validate_compiled_payload(payload, expected)
    except Exception:
        try:
            cache_path.unlink(missing_ok=True)
        except Exception:
            pass
        return None


def _load_packaged_compiled_features_fast(
    pkg_dir: _Path,
    feature_files: tuple[str, ...],
) -> tuple[object, ...] | None:
    """Load the release cache before any source hashing or CONFIG access.

    The package is immutable at runtime and the build regenerates this cache
    whenever a source changes.  ABI/schema/file-order checks are sufficient on
    the normal installed path; source hashing remains the fallback path when the
    release cache is missing or incompatible.
    """
    if str(os.environ.get('SFS_DISABLE_PACKAGED_BOOTSTRAP_CACHE', '') or '').strip().lower() in {'1', 'true', 'yes'}:
        return None
    path = pkg_dir / _PACKAGED_CACHE_NAME
    try:
        payload = marshal.loads(zlib.decompress(path.read_bytes()))
    except Exception:
        return None
    if not isinstance(payload, dict):
        return None
    if payload.get('schema') != _BOOTSTRAP_CACHE_SCHEMA:
        return None
    if tuple(payload.get('feature_files') or ()) != tuple(feature_files):
        return None
    cache_tag = str(payload.get('cache_tag') or '')
    if cache_tag != str(getattr(sys.implementation, 'cache_tag', '') or ''):
        return None
    version = tuple(payload.get('python_version') or ())
    current = tuple(sys.version_info[:3])
    if version[:2] != current[:2]:
        return None
    codes = payload.get('codes')
    if not isinstance(codes, tuple) or len(codes) != len(feature_files):
        return None
    if not all(hasattr(code, 'co_code') for code in codes):
        return None
    return codes


def _load_packaged_compiled_features(pkg_dir: _Path, expected: dict) -> tuple[object, ...] | None:
    """Load the release-generated cache without writing to the Extension.

    The cache is an optimization only. ABI, source, schema, or payload mismatch
    returns ``None`` and the normal source compilation path remains authoritative.
    """
    if str(os.environ.get('SFS_DISABLE_PACKAGED_BOOTSTRAP_CACHE', '') or '').strip().lower() in {'1', 'true', 'yes'}:
        return None
    path = pkg_dir / _PACKAGED_CACHE_NAME
    if not path.is_file():
        return None
    try:
        payload = marshal.loads(zlib.decompress(path.read_bytes()))
        return _validate_compiled_payload(payload, expected)
    except Exception:
        # Never delete package data at runtime. A damaged or incompatible cache
        # simply falls back to source compilation and the CONFIG-side cache.
        return None


def _write_compiled_features(cache_path: _Path | None, metadata: dict, codes: tuple[object, ...]) -> None:
    if cache_path is None:
        return
    payload = dict(metadata)
    payload['codes'] = tuple(codes)
    temp = cache_path.with_name(cache_path.name + f'.tmp-{os.getpid()}')
    try:
        with temp.open('wb') as fh:
            marshal.dump(payload, fh)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except Exception:
                pass
        os.replace(temp, cache_path)
        # Keep only the current schema/identity.  Old release caches are safe to
        # delete because they are derived data and never contain user settings.
        for old in cache_path.parent.glob(f'{_BOOTSTRAP_CACHE_PREFIX}*.marshal'):
            if old != cache_path:
                try:
                    old.unlink()
                except Exception:
                    pass
    except Exception:
        try:
            temp.unlink(missing_ok=True)
        except Exception:
            pass


def _compile_or_load_features(pkg_dir: _Path, feature_files: tuple[str, ...]) -> tuple[object, ...]:
    global _LAST_BOOTSTRAP_CACHE_SOURCE
    packaged_fast = _load_packaged_compiled_features_fast(pkg_dir, feature_files)
    if packaged_fast is not None:
        _LAST_BOOTSTRAP_CACHE_SOURCE = 'packaged-fast'
        return packaged_fast

    # Development/ABI fallback only: hash sources and use the derived CONFIG
    # cache.  The normal release path above performs no source walk and creates
    # no cache directory merely from enabling Smart File.
    cache_path, metadata = _cache_path(pkg_dir, feature_files)
    cached = _load_compiled_features(cache_path, metadata)
    if cached is not None:
        _LAST_BOOTSTRAP_CACHE_SOURCE = 'runtime'
        return cached
    packaged = _load_packaged_compiled_features(pkg_dir, metadata)
    if packaged is not None:
        _LAST_BOOTSTRAP_CACHE_SOURCE = 'packaged-verified'
        return packaged
    codes: list[object] = []
    for feature_file in feature_files:
        feature_path = pkg_dir / feature_file
        with feature_path.open('r', encoding='utf-8') as fh:
            source = fh.read()
        source = _preprocess_source_for_i18n(source)
        # A stable package-relative filename keeps tracebacks useful without
        # binding the shipped cache to the developer's build directory.
        virtual_filename = str(_Path('smart_file_suite') / feature_file)
        codes.append(compile(source, virtual_filename, 'exec', dont_inherit=True))
    result = tuple(codes)
    _LAST_BOOTSTRAP_CACHE_SOURCE = 'compiled'
    _write_compiled_features(cache_path, metadata, result)
    return result


def run_bootstrap(namespace: dict, package_file: str) -> None:
    import time as _time

    global _LAST_BOOTSTRAP_PHASES
    phases: dict[str, float] = {}
    started = _time.perf_counter()
    pkg_dir = _Path(package_file).resolve().parent

    _legacy_boot._PKG_DIR = pkg_dir
    _legacy_boot._NAMESPACE = namespace
    _legacy_boot._SF_PENDING_TRANSLATIONS = {'ja_JP': {}}
    _legacy_boot._SF_DYNAMIC_FORWARD_TRANSLATIONS.clear()
    _legacy_boot._SF_DYNAMIC_REVERSE_TRANSLATIONS.clear()

    _inject_runtime_helpers(namespace)

    if str(os.environ.get('SFS_RUNTIME_SOURCE_I18N_SCAN', '') or '').strip() in {'1', 'true', 'TRUE', 'yes', 'YES'}:
        scan_started = _time.perf_counter()
        try:
            _legacy_boot._sf_collect_source_keyword_translations()
        except Exception:
            pass
        phases['optional_source_i18n_scan'] = _time.perf_counter() - scan_started

    # Foreground and background Blender execute the same feature declaration,
    # validation, and registration preparation path.  No context-dependent
    # branch is permitted at bootstrap.
    feature_files = _PACKAGED_FEATURE_FILES
    cache_started = _time.perf_counter()
    compiled_features = _compile_or_load_features(pkg_dir, feature_files)
    phases['compiled_feature_load'] = _time.perf_counter() - cache_started

    exec_started = _time.perf_counter()
    with _patched_prop_factories():
        for code in compiled_features:
            exec(code, namespace, namespace)
    phases['feature_namespace_exec'] = _time.perf_counter() - exec_started

    _inject_runtime_helpers(namespace)

    restore_started = _time.perf_counter()
    # Runtime method wrappers are created only by the opt-in source-i18n debug
    # pipeline.  The release cache contains original methods, so a 500-class
    # compatibility scan is unnecessary on every normal enable.
    if str(os.environ.get('SFS_RUNTIME_I18N_PREPROCESS', '') or '').strip().lower() in {'1', 'true', 'yes'}:
        try:
            _legacy_boot._sf_restore_registration_compatible_methods(namespace.get('classes'))
        except Exception:
            pass
    phases['registration_method_restore'] = _time.perf_counter() - restore_started

    translation_started = _time.perf_counter()
    try:
        _legacy_boot._sf_collect_runtime_class_translations(namespace.get('classes'))
    except Exception:
        pass
    _register_bl_info_translations(namespace)
    try:
        _legacy_boot._sf_flush_pending_translations()
    except Exception:
        pass
    phases['runtime_translation_catalog'] = _time.perf_counter() - translation_started

    phases['total'] = _time.perf_counter() - started
    _LAST_BOOTSTRAP_PHASES = phases
    namespace['_SFS_BOOTSTRAP_PROFILE'] = dict(phases)
    namespace['_SFS_BOOTSTRAP_CACHE_SOURCE'] = _LAST_BOOTSTRAP_CACHE_SOURCE


__all__ = ['run_bootstrap']
