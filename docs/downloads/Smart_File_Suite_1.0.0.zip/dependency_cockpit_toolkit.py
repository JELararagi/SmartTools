# -----------------------------------------------------------------------------
#  Dependency Cockpit / Selected-Hierarchy Relink / Selected Report
# -----------------------------------------------------------------------------

import datetime
import os


def _sf_dep_selected_objects(context):
    selected = list(getattr(context, 'selected_objects', []) or [])
    active = getattr(context, 'active_object', None)
    if not selected and active is not None:
        selected = [active]
    return selected



def _sf_dep_has_selection(context) -> bool:
    return bool(_sf_dep_selected_objects(context))



def _sf_dep_collect_selected_records(context, *, include_libraries: bool = True, include_texts: bool = False, include_missing: bool = True) -> list[dict]:
    if not _sf_dep_has_selection(context):
        return []
    return _sf_ref_collect_scope_records(
        context,
        scope='SELECTED_HIERARCHY',
        include_libraries=include_libraries,
        include_texts=include_texts,
        include_missing=include_missing,
    )



def _sf_dep_selected_payload(context, *, include_libraries: bool = True, include_texts: bool = False) -> dict:
    records = _sf_dep_collect_selected_records(context, include_libraries=include_libraries, include_texts=include_texts, include_missing=True)
    summary = _sf_ext_summary(records)
    active = getattr(context, 'active_object', None)
    selected = _sf_dep_selected_objects(context)
    missing_preview = [
        {
            'kind': str(rec.get('kind_label') or ''),
            'name': str(rec.get('name') or ''),
            'raw_path': str(rec.get('raw_path') or ''),
            'abs_path': str(rec.get('abs_path') or ''),
        }
        for rec in records if (not rec.get('exists')) and (not rec.get('packed'))
    ][:6]
    return {
        'records': records,
        'summary': summary,
        'kinds': [summary['kinds'][key] for key in sorted(summary.get('kinds', {}).keys())],
        'missing_preview': missing_preview,
        'selected_count': len(selected),
        'selected_label': ','.join(str(getattr(ob, 'name', '') or '') for ob in selected[:4]),
        'selected_overflow': max(0, len(selected) - 4),
        'active_name': str(getattr(active, 'name', '') or ''),
    }



def _sf_dep_next_action(summary: dict, *, has_selection: bool) -> str:
    if not has_selection:
        return _t('Select linked objects or an active object first')
    total = int(summary.get('total_records', 0) or 0)
    if total <= 0:
        return _t('No external dependencies were found in the current selection')
    if int(summary.get('missing_records', 0) or 0) > 0:
        return _t('Relink Selected')
    if int(summary.get('absolute_records', 0) or 0) > 0:
        return _t('Normalize Paths')
    if int(summary.get('env_records', 0) or 0) > 0:
        return _t('Review Environment Paths')
    return _t('Selected dependencies look portable')



def _sf_dep_source_context(context):
    prefs = _addon_prefs(context)
    wm = getattr(context, 'window_manager', None)
    filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '') if wm is not None else ''
    has_source = bool(filepath and os.path.isfile(filepath))
    roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []
    roots_ready = any(bool(getattr(root, 'enabled', True)) for root in roots)
    try:
        index = _load_index()
    except Exception:
        index = {}
    index_ready = bool(len((index or {}).get('files', {}) or {}))
    source_info = _sf_get_source_insights(prefs, filepath, index)
    health_score, _health_label = _sf_health_score_label(has_source, source_info, roots_ready, index_ready)
    actions = _sf_build_recommended_actions(context, prefs, filepath, source_info, roots_ready, index_ready, health_score)
    return prefs, filepath, has_source, roots_ready, index_ready, source_info, health_score, actions



def _sf_dep_report_lines(context, title: str, payload: dict) -> list[str]:
    data = _sf_collect_report_context(context)
    summary = dict(payload.get('summary') or {})
    lines = _sf_report_lines_header(title, data)
    lines.extend([
        f"- {_t('Selected Objects')}: {int(payload.get('selected_count', 0) or 0)}",
        f"- {_t('Active Object')}: {payload.get('active_name') or _t('Not set')}",
        f"- {_t('External Records')}: {int(summary.get('total_records', 0) or 0)}",
        f"- {_t('Missing')}: {int(summary.get('missing_records', 0) or 0)}",
        f"- {_t('Absolute')}: {int(summary.get('absolute_records', 0) or 0)}",
        f"- {_t('Environment Variables')}: {int(summary.get('env_records', 0) or 0)}",
        f"- {_t('Sequences')}: {int(summary.get('sequence_records', 0) or 0)}",
        '',
        'KINDS',
    ])
    for row in list(payload.get('kinds') or []):
        lines.append(f"- {row.get('label','')}: total={int(row.get('count', 0) or 0)} | missing={int(row.get('missing', 0) or 0)} | packed={int(row.get('packed', 0) or 0)}")
    if payload.get('missing_preview'):
        lines.extend(['', 'MISSING PREVIEW'])
        for row in list(payload.get('missing_preview') or []):
            lines.append(f"- [{row.get('kind','')}] {row.get('name','')} | {row.get('raw_path','')}")
    lines.extend(['', *(_sf_report_export_notes_lines(title, data) or [])])
    return lines


class SF_OT_dependency_cockpit_open(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = 'import_scene.sfs_dependency_cockpit_open'
    bl_label = 'Open'
    bl_description = 'Open one compact dependency board that keeps source readiness, selected-hierarchy diagnostics, relink, reporting, repath, and packaging in one place.'
    bl_options = {'INTERNAL'}

    popup_width: IntProperty(default=680, min=560, max=900, options={'HIDDEN'})

    def invoke(self, context, event):
        _sf_append_activity(context, _t('Opened Dependency Cockpit'), _norm_path(bpy.data.filepath or ''), 'NETWORK_DRIVE')
        return context.window_manager.invoke_popup(self, width=self.popup_width)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        prefs, filepath, _has_source, roots_ready, index_ready, source_info, _health_score, actions = _sf_dep_source_context(context)
        payload = _sf_dep_selected_payload(context, include_libraries=True, include_texts=False)
        summary = dict(payload.get('summary') or {})
        has_selection = _sf_dep_has_selection(context)
        next_action = _sf_dep_next_action(summary, has_selection=has_selection)

        _sf_draw_dialog_header(
            layout,
            'Dependency Cockpit',
            'Read the current source first, then diagnose only the selected hierarchy before you repair, repath, or package a subset.',
            'NETWORK_DRIVE',
        )

        _sf_draw_source_root_profile_matrix(layout, context, prefs, filepath, source_info, roots_ready, index_ready, actions, compact=False)

        sel_box = layout.box()
        _sf_draw_section_intro(
            sel_box,
            'Selected Hierarchy Snapshot',
            'This view behaves like a focused dependency finder for the current selection so you can repair only the linked subset you are touching right now.',
            'OUTLINER_OB_GROUP_INSTANCE',
        )
        _sf_draw_state_line(sel_box, 'Selected Scope', 'READY' if has_selection else 'NOT SET', detail=(payload.get('selected_label') or _t('Select linked objects or an active object first')))
        if payload.get('selected_overflow'):
            sel_box.label(text=f"+{int(payload.get('selected_overflow', 0) or 0)} {_t('more')}", icon='BLANK1')
        _sf_draw_state_line(sel_box, 'External Records', 'READY' if int(summary.get('total_records', 0) or 0) else 'NOT SET', detail=str(int(summary.get('total_records', 0) or 0)))
        _sf_draw_state_line(sel_box, 'Missing', 'OK' if int(summary.get('missing_records', 0) or 0) == 0 else 'NEEDS ATTENTION', detail=str(int(summary.get('missing_records', 0) or 0)))
        _sf_draw_state_line(sel_box, 'Absolute', 'OK' if int(summary.get('absolute_records', 0) or 0) == 0 else 'REVIEW', detail=str(int(summary.get('absolute_records', 0) or 0)))
        _sf_draw_state_line(sel_box, 'Sequences', 'READY' if int(summary.get('sequence_records', 0) or 0) else 'NOT SET', detail=str(int(summary.get('sequence_records', 0) or 0)))
        _sf_draw_state_line(sel_box, 'Next Action', 'READY' if next_action == _t('Selected dependencies look portable') else 'REVIEW', detail=next_action)

        kinds = list(payload.get('kinds') or [])
        if kinds:
            kinds_box = sel_box.box()
            kinds_box.label(text=_t('Kinds'), icon='FILE_FOLDER')
            for row in kinds[:5]:
                kinds_box.label(text=f"{row.get('label','')}: {_t('total')} {int(row.get('count', 0) or 0)} | {_t('missing')} {int(row.get('missing', 0) or 0)} | {_t('packed')} {int(row.get('packed', 0) or 0)}", icon='BLANK1')

        missing_preview = list(payload.get('missing_preview') or [])
        if missing_preview:
            miss_box = sel_box.box()
            miss_box.label(text=_t('Missing Preview'), icon='ERROR')
            for row in missing_preview:
                miss_box.label(text=f"[{row.get('kind','')}] {row.get('name','')}", icon='BLANK1')
                miss_box.label(text=_sf_short_path_display(row.get('raw_path',''), 66), icon='BLANK1')

        quick = layout.box()
        _sf_draw_section_intro(
            quick,
            'Quick Actions',
            'Use Audit or Source Check for the broad picture, then use the selected-only relink and report when you want the smallest safe repair scope.',
            'CHECKMARK',
        )
        _sf_draw_action_block(
            quick,
            primary_actions=[
                ('import_scene.sfs_dep_cockpit_relink_hierarchy', 'Relink Selected', 'VIEWZOOM', {}),
                ('export_scene.sfs_dep_cockpit_selection_report', 'Selection Report', 'FILE_TEXT', {}),
                ('import_scene.sfs_external_assets_audit', 'Audit Current', 'CHECKMARK', {}),
                ('import_scene.sfs_reference_manager_source_check', 'Source Check', 'CHECKMARK', {}),
            ],
            secondary_actions=[
                ('import_scene.sfs_root_repath_repath', 'Repath Roots', 'FILE_PARENT', {}),
                ('import_scene.sfs_root_repath_apply_saved_plan', 'Apply Saved Plan', 'CHECKMARK', {}),
                ('import_scene.sfs_root_repath_restore_saved_plan', 'Restore Saved Plan', 'LOOP_BACK', {}),
                ('import_scene.sfs_rm_prepare_upgrade_plan', 'Prepare Saved Upgrade', 'FILE_TICK', {}),
                ('import_scene.sfs_reference_manager_apply_saved_upgrade_plan', 'Apply Saved Upgrade', 'CHECKMARK', {}),
                ('import_scene.sfs_rm_restore_upgrade_plan', 'Restore Saved Upgrade', 'LOOP_BACK', {}),
                ('import_scene.sfs_reference_toolkit_open', 'Toolkit', 'ASSET_MANAGER', {}),
                ('import_scene.sfs_context_roots_open', 'Context Roots', 'FILE_PARENT', {}),
                ('import_scene.sfs_root_watch_open', 'Watch Roots', 'FILE_REFRESH', {}),
                ('import_scene.sfs_project_guard_open', 'Project Guard', 'LOCKVIEW_ON', {}),
                ('import_scene.sfs_project_guard_handoff_audit', 'Handoff Audit...', 'TEXT', {}),
                ('import_scene.sfs_external_assets_bundle_project', 'Bundle', 'EXPORT', {}),
                ('import_scene.sfs_external_assets_verify_bundle', 'Verify Bundle...', 'CHECKMARK', {}),
                ('import_scene.sfs_external_assets_conflict_audit', 'Conflict Audit...', 'SORTALPHA', {}),
                ('import_scene.sfs_override_manager_audit', 'Override Audit...', 'CHECKMARK', {}),
            ],
        )


class SF_OT_dependency_cockpit_selection_dependency_report(bpy.types.Operator):
    bl_idname = 'export_scene.sfs_dep_cockpit_selection_report'
    bl_label = 'Selection Dependency Report'
    bl_description = 'Write a compact report for only the currently selected hierarchy so you can hand off, review, or troubleshoot a small linked subset without exporting the whole scene.'
    bl_options = {'UNDO', 'INTERNAL'}

    open_text: BoolProperty(name='Open report', default=True)
    include_libraries: BoolProperty(name='Include linked libraries', default=True)

    def execute(self, context):
        payload = _sf_dep_selected_payload(context, include_libraries=self.include_libraries, include_texts=False)
        summary = dict(payload.get('summary') or {})
        if int(payload.get('selected_count', 0) or 0) <= 0:
            self.report({'ERROR'}, _t('Select linked objects or an active object first'))
            return {'CANCELLED'}
        if int(summary.get('total_records', 0) or 0) <= 0:
            self.report({'INFO'}, _t('No external dependencies were found in the current selection'))
            return {'CANCELLED'}
        title = _t('Selection Dependency Report')
        text_name = _sf_report_export(
            context,
            title,
            _sf_dep_report_lines(context, title, payload),
            open_text=self.open_text,
            activity_title=_t('Exported selection dependency report'),
        )
        self.report({'INFO'}, f"{_t('Exported')}: {text_name}")
        return {'FINISHED'}


class SF_OT_dependency_cockpit_relink_selected_hierarchy(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_dep_cockpit_relink_hierarchy'
    bl_label = 'Relink Selected Hierarchy'
    bl_description = 'Search only the missing dependencies used by the selected hierarchy and try to reconnect them from the current file folder, configured roots, or an extra search folder.'
    bl_options = {'UNDO'}

    search_dir: StringProperty(name='Search Folder', subtype='DIR_PATH', default='')
    include_current_file_dir: BoolProperty(name='Include current file folder', default=True)
    include_library_roots: BoolProperty(name='Include library roots', default=True)
    include_context_roots: BoolProperty(name='Include Context Roots', default=True, description='Also search enabled named Context Roots used by root-map, watch-folder, and handoff workflows.')
    include_libraries: BoolProperty(name='Include linked libraries', default=True)
    include_texts: BoolProperty(name='Include text datablocks', default=False)
    path_mode: EnumProperty(
        name='Path Mode',
        items=[
            ('PRESERVE', 'Preserve Style', 'Keep each relinked path in the same style it already used when possible. Relative paths stay relative and absolute paths stay absolute.'),
            ('RELATIVE', 'Relative', 'Write resolved paths relative to the current .blend file when possible.'),
            ('ABSOLUTE', 'Absolute', 'Write resolved paths as absolute disk paths.'),
        ],
        default='PRESERVE',
    )
    open_report: BoolProperty(name='Open report', default=True)

    def invoke(self, context, event):
        if not self.search_dir:
            self.search_dir = _norm_path(os.path.dirname(bpy.data.filepath or '')) if bpy.data.filepath else ''
        return context.window_manager.invoke_props_dialog(self, width=620)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'search_dir')
        layout.prop(self, 'include_current_file_dir')
        layout.prop(self, 'include_library_roots')
        layout.prop(self, 'include_context_roots')
        layout.prop(self, 'include_libraries')
        layout.prop(self, 'include_texts')
        layout.prop(self, 'path_mode')
        layout.prop(self, 'open_report')

    def execute(self, context):
        if not _sf_dep_has_selection(context):
            self.report({'ERROR'}, _t('Select linked objects or an active object first'))
            return {'CANCELLED'}

        records = _sf_dep_collect_selected_records(context, include_libraries=self.include_libraries, include_texts=self.include_texts, include_missing=True)
        targets = [rec for rec in records if (not rec.get('exists')) and (not rec.get('packed'))]
        if not targets:
            self.report({'INFO'}, _t('Selection contains no missing dependencies'))
            return {'FINISHED'}
        if (not bpy.data.filepath) and _sf_ext_rows_require_saved_blend(targets, self.path_mode):
            self.report({'ERROR'}, _t('Save the current file before writing relative paths'))
            return {'CANCELLED'}

        roots = _sf_ext_find_search_roots(
            context,
            self.search_dir,
            include_current_file_dir=self.include_current_file_dir,
            include_library_roots=self.include_library_roots,
            include_context_roots=self.include_context_roots,
        )
        if not roots:
            self.report({'ERROR'}, _t('No valid search roots'))
            return {'CANCELLED'}

        allowed_suffixes = set()
        for rec in targets:
            ext = os.path.splitext(str(rec.get('abs_path') or rec.get('raw_path') or ''))[1].lower()
            if ext:
                allowed_suffixes.add(ext)
        index = _sf_ext_build_basename_index(roots, allowed_suffixes=allowed_suffixes)

        report_title = _t('Selected Dependency Relink')
        data = _sf_collect_report_context(context)
        report_lines = _sf_report_lines_header(report_title, data)
        report_lines.extend([
            f"- {_t('Search Roots')}: {len(roots)}",
            f"- {_t('Targets')}: {len(targets)}",
            f"- {_t('Selected Objects')}: {len(_sf_dep_selected_objects(context))}",
            '',
            'ROOTS',
        ])
        for root in roots:
            report_lines.append(f'- {root}')
        report_lines.extend(['', 'RESULTS'])

        restored = []
        unresolved = []
        for rec in targets:
            old_path = getattr(rec.get('id_ref'), 'filepath', '') or ''
            best = ''
            try:
                best = _sf_ctx_find_best_record_candidate(context, rec, extra_roots=roots, basename_index=index)
            except Exception:
                best = ''
            if not best:
                candidates = _sf_ext_sequence_index_candidates(rec, index)
                best = _sf_ext_pick_best_candidate(rec, candidates)
            if not best:
                unresolved.append(rec)
                report_lines.append(f"- [MISS] [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('raw_path','')}")
                continue
            try:
                remap_target = _sf_ext_tokenized_sequence_path(rec, best)
                if self.path_mode == 'RELATIVE':
                    new_path = _sf_ref_abs_to_path_mode(remap_target, 'RELATIVE')
                elif self.path_mode == 'ABSOLUTE':
                    new_path = _sf_ref_abs_to_path_mode(remap_target, 'ABSOLUTE')
                else:
                    new_path = _sf_ref_preserve_path_style(old_path, remap_target)
                setattr(rec.get('id_ref'), 'filepath', new_path)
                restored.append((rec, new_path, old_path))
                report_lines.append(f"- [OK] [{rec.get('kind_label','')}] {rec.get('name','')} | {old_path} -> {new_path}")
            except Exception as ex:
                unresolved.append(rec)
                report_lines.append(f"- [FAIL] [{rec.get('kind_label','')}] {rec.get('name','')} | {ex}")

        if unresolved:
            report_lines.extend(['', 'UNRESOLVED'])
            for rec in unresolved:
                report_lines.append(f"- [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('raw_path','')}")

        text_name = _sf_report_export(
            context,
            report_title,
            report_lines,
            open_text=self.open_report,
            activity_title=_t('Ran selected dependency relink'),
        )
        self.report({'INFO'}, f"{_t('Relinked')}: {len(restored)} | {_t('Unresolved')}: {len(unresolved)} | {text_name}")
        return {'FINISHED'}
