# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import ast
import json
import re
from pathlib import Path
from typing import Any

SUITE_META = {
    'smart_file_suite': ('Smart File', 'navigation_properties'),
}

SUITE_ORDER: tuple[str, ...] = tuple(SUITE_META.keys())

_REPORT_LINE_RE = re.compile(
    r'^- \*\*(?P<display>.+?)\*\* \(`(?P<outer>.+?)`\) → `(?P<suite>.+?)` / (?P<status>load|skip)\s*$'
)

_CACHE: list[dict[str, Any]] | None = None


def package_root() -> Path:
    return Path(__file__).resolve().parent


def report_path() -> Path:
    return package_root() / 'TOOLS_REPORT.md'


def clear_cache() -> None:
    global _CACHE
    _CACHE = None


def _load_generated_specs(root: Path) -> list[dict[str, Any]]:
    """Load packaged discovery metadata without reparsing bundled sources."""
    path = root / 'registry_generated.json'
    try:
        payload = json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return []
    raw_specs = payload.get('specs') if isinstance(payload, dict) else None
    if not isinstance(raw_specs, list):
        return []
    specs: list[dict[str, Any]] = []
    prefix = '__PACKAGE_ROOT__/'
    for raw in raw_specs:
        if not isinstance(raw, dict):
            return []
        spec = dict(raw)
        for key in ('package_dir', 'vendor_dir'):
            value = str(spec.get(key) or '')
            if value.startswith(prefix):
                value = str(root / value[len(prefix):])
                spec[key] = value
        # The signed Extension archive is immutable after installation.  Do not
        # stat every bundled command directory merely to enable Smart File; the
        # explicit command loader validates its own target immediately before use.
        specs.append(spec)
    return specs


def sanitize_alias(filename: str) -> str:
    text = str(filename or '').strip()
    if text.lower().endswith('.zip'):
        text = text[:-4]
    text = text.replace(' ', '_')
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    if not text:
        text = 'tool'
    if not re.match(r'[A-Za-z_]', text):
        text = '_' + text
    return text


def _parse_report() -> list[dict[str, Any]]:
    path = report_path()
    if not path.exists():
        return []

    specs: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    for raw_line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        line = raw_line.rstrip('\n')
        match = _REPORT_LINE_RE.match(line.strip())
        if match:
            alias = sanitize_alias(match.group('outer'))
            current = {
                'alias': alias,
                'outer_zip': match.group('outer').strip(),
                'display_name': match.group('display').strip(),
                'suite': 'smart_file_suite',
                'suite_name': 'Smart File',
                'load': match.group('status').strip() == 'load',
                'note': '',
                'duplicate_of': '',
                'superseded_by': '',
                'spaces': [],
            }
            specs.append(current)
            continue
        if current is None:
            continue
        stripped = line.strip()
        if stripped.startswith('- note:'):
            current['note'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- duplicate_of:'):
            current['duplicate_of'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- superseded_by:'):
            current['superseded_by'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- ui_strategy:'):
            _, _, rest = stripped.partition('spaces:')
            text = rest.strip()
            current['spaces'] = [] if not text or text == '-' else [item.strip() for item in text.split(',') if item.strip()]
    return specs


def _read_bl_info_name_and_description(py_path: Path) -> tuple[str, str]:
    try:
        text = py_path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return '', ''

    # Prefer AST parsing so both single-quoted and double-quoted bundled add-ons
    # are discovered correctly.  The regex fallback keeps malformed but readable
    # legacy headers usable.
    try:
        tree = ast.parse(text)
        for node in getattr(tree, 'body', ()):  # type: ignore[attr-defined]
            if not isinstance(node, ast.Assign):
                continue
            if not any(isinstance(target, ast.Name) and target.id == 'bl_info' for target in node.targets):
                continue
            value = ast.literal_eval(node.value)
            if isinstance(value, dict):
                name = str(value.get('name') or '').strip()
                description = str(value.get('description') or '').strip()
                return name, description
    except Exception:
        pass

    name_match = re.search(r'[\"\']name[\"\']\s*:\s*[\"\']([^\"\']+)[\"\']', text)
    desc_match = re.search(r'[\"\']description[\"\']\s*:\s*[\"\']([^\"\']+)[\"\']', text)
    return (name_match.group(1).strip() if name_match else '', desc_match.group(1).strip() if desc_match else '')


def _find_init_file(package_dir: Path) -> tuple[str, str, str, str]:
    direct_init = package_dir / '__init__.py'
    if direct_init.exists():
        return '__init__.py', '', '', 'root_package'

    init_files = [path for path in package_dir.rglob('__init__.py') if '__pycache__' not in path.parts]
    if not init_files:
        return '', '', '', ''

    scored: list[tuple[tuple[int, int, int, str], Path]] = []
    for path in init_files:
        rel = path.relative_to(package_dir).as_posix()
        depth = len(path.relative_to(package_dir).parts)
        text = ''
        try:
            text = path.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            text = ''
        has_bl_info = 'bl_info' in text
        has_register = 'def register' in text
        score = (
            0 if has_bl_info else 1,
            0 if has_register else 1,
            depth,
            rel,
        )
        scored.append((score, path))
    scored.sort(key=lambda item: item[0])
    chosen = scored[0][1]
    init_relpath = chosen.relative_to(package_dir).as_posix()
    parts = init_relpath.split('/')
    if len(parts) == 1:
        source_root = ''
        original_module_name = ''
        import_mode = 'root_package'
    else:
        source_root = '/'.join(parts[:-1])
        original_module_name = parts[0]
        import_mode = 'package'
    return init_relpath, source_root, original_module_name, import_mode


_AUTO_DISCOVERY_EXCLUDED_DIRS = {
    '__pycache__',
    'history_auto_save',  # already registered by the Smart File History / Restore category.
    'import_max',  # migrated as a native Smart File import feature, not a separately discovered bundled add-on.
}


def _looks_like_bundled_addon(addon_dir: Path) -> bool:
    if not addon_dir.is_dir() or addon_dir.name in _AUTO_DISCOVERY_EXCLUDED_DIRS:
        return False
    init_file = addon_dir / '__init__.py'
    if not init_file.exists():
        return False
    try:
        text = init_file.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return False
    return 'bl_info' in text and 'def register' in text



def _literal_or_empty(node: ast.AST) -> str:
    try:
        value = ast.literal_eval(node)
    except Exception:
        return ''
    if isinstance(value, (str, int, float, bool)):
        return str(value)
    return ''


def _base_names(node: ast.ClassDef) -> str:
    names: list[str] = []
    for base in getattr(node, 'bases', ()):
        try:
            names.append(ast.unparse(base))
        except Exception:
            try:
                names.append(getattr(base, 'id', '') or getattr(getattr(base, 'attr', None), 'id', ''))
            except Exception:
                pass
    return ' '.join(str(item) for item in names if item)


def _class_static_attrs(node: ast.ClassDef) -> dict[str, str]:
    attrs: dict[str, str] = {}
    for stmt in getattr(node, 'body', ()):
        targets = []
        value = None
        if isinstance(stmt, ast.Assign):
            targets = list(getattr(stmt, 'targets', ()) or ())
            value = stmt.value
        elif isinstance(stmt, ast.AnnAssign):
            targets = [stmt.target]
            value = stmt.value
        if value is None:
            continue
        for target in targets:
            if isinstance(target, ast.Name) and target.id.startswith('bl_'):
                attrs[target.id] = _literal_or_empty(value)
    return attrs


def _static_kind_for_class(node: ast.ClassDef, bases: str, attrs: dict[str, str]) -> str:
    upper = f'{node.name} {bases}'.upper()
    bl_idname = str(attrs.get('bl_idname') or '')
    if 'OPERATOR' in upper or '_OT_' in node.name:
        return 'operators' if '.' in bl_idname else ''
    if 'MENU' in upper or '_MT_' in node.name:
        return 'menus' if bl_idname else ''
    if 'PANEL' in upper or '_PT_' in node.name:
        return 'panels'
    if 'FILEHANDLER' in upper or 'FILE_HANDLER' in upper:
        return 'file_handlers'
    return ''


def _scan_static_ui_entries(addon_dir: Path) -> dict[str, list[dict[str, str]]]:
    """Read bundled add-on UI metadata without importing or registering it."""
    result: dict[str, list[dict[str, str]]] = {
        'operators': [],
        'menus': [],
        'panels': [],
        'file_handlers': [],
    }
    seen: set[tuple[str, str]] = set()
    try:
        py_files = [path for path in addon_dir.rglob('*.py') if '__pycache__' not in path.parts]
    except Exception:
        py_files = []
    for path in sorted(py_files, key=lambda item: item.as_posix().lower()):
        try:
            source = path.read_text(encoding='utf-8', errors='ignore')
            tree = ast.parse(source)
        except Exception:
            continue
        for node in ast.walk(tree):
            if not isinstance(node, ast.ClassDef):
                continue
            attrs = _class_static_attrs(node)
            bases = _base_names(node)
            kind = _static_kind_for_class(node, bases, attrs)
            if not kind:
                continue
            idname = str(attrs.get('bl_idname') or node.name).strip()
            label = str(attrs.get('bl_label') or node.name).strip()
            desc = str(attrs.get('bl_description') or '').strip()
            key = (kind, idname)
            if key in seen:
                continue
            seen.add(key)
            result.setdefault(kind, []).append({
                'class_name': node.name,
                'idname': idname,
                'label': label,
                'description': desc,
                'space_type': str(attrs.get('bl_space_type') or '').strip(),
                'region_type': str(attrs.get('bl_region_type') or '').strip(),
                'category': str(attrs.get('bl_category') or '').strip(),
                'source': path.relative_to(addon_dir).as_posix(),
            })
    for entries in result.values():
        entries.sort(key=lambda item: (str(item.get('label') or '').lower(), str(item.get('idname') or '').lower()))
    return result

def _auto_discover_specs(root: Path) -> list[dict[str, Any]]:
    specs: list[dict[str, Any]] = []
    for addon_dir in sorted(root.iterdir(), key=lambda item: item.name.lower()):
        if not _looks_like_bundled_addon(addon_dir):
            continue
        alias = sanitize_alias(addon_dir.name)
        init_relpath, source_root, original_module_name, import_mode = _find_init_file(addon_dir)
        if not init_relpath:
            continue
        name, description = _read_bl_info_name_and_description(addon_dir / init_relpath)
        display_name = name or alias.replace('_', ' ').title()
        static_ui = _scan_static_ui_entries(addon_dir)
        specs.append({
            'alias': alias,
            'outer_zip': addon_dir.name,
            'display_name': display_name,
            'suite': 'smart_file_suite',
            'suite_name': SUITE_META.get('smart_file_suite', ('Smart File', ''))[0],
            'load': True,
            'note': 'Auto-discovered bundled add-on integrated into Smart File functional categories. Its code stays unloaded until one of its controls is used.',
            'duplicate_of': '',
            'superseded_by': '',
            'spaces': [],
            'package_dir': str(addon_dir),
            'source_root': source_root,
            'original_module_name': original_module_name,
            'import_mode': import_mode,
            'init_relpath': init_relpath,
            'search_root': source_root,
            'vendor_dir': str(addon_dir),
            'description': description or display_name,
            'static_ui': static_ui,
        })
    return specs


def build_specs(force: bool = False) -> list[dict[str, Any]]:
    global _CACHE
    if _CACHE is not None and not force:
        return list(_CACHE)

    root = package_root()
    generated_specs = _load_generated_specs(root)
    if generated_specs:
        _CACHE = list(generated_specs)
        return list(generated_specs)

    # Discovery is a development/build fallback only.  Installed startup must
    # never walk the Extension tree because registry_generated.json is required.
    if not force:
        _CACHE = []
        return []

    report_specs = _parse_report()
    if not report_specs:
        results = _auto_discover_specs(root) if root.exists() else []
        _CACHE = list(results)
        return list(results)

    results: list[dict[str, Any]] = []

    if not root.exists():
        _CACHE = []
        return []

    for spec_from_report in report_specs:
        alias = str(spec_from_report.get('alias') or '').strip()
        if not alias:
            continue
        addon_dir = root / alias
        if not addon_dir.exists() or not addon_dir.is_dir():
            continue

        spec = dict(spec_from_report)
        init_relpath, source_root, original_module_name, import_mode = _find_init_file(addon_dir)
        if not init_relpath:
            continue

        spec['package_dir'] = str(addon_dir)
        spec['source_root'] = source_root
        spec['original_module_name'] = original_module_name
        spec['import_mode'] = import_mode
        spec['init_relpath'] = init_relpath
        spec['search_root'] = source_root
        spec['vendor_dir'] = str(addon_dir)
        spec['suite_name'] = spec.get('suite_name') or SUITE_META.get(spec['suite'], ('Unknown', ''))[0]

        init_path = addon_dir / init_relpath
        name, description = _read_bl_info_name_and_description(init_path)
        if name and not spec.get('display_name'):
            spec['display_name'] = name
        spec['description'] = description or str(spec.get('display_name') or alias)
        results.append(spec)

    _CACHE = list(results)
    return list(results)
