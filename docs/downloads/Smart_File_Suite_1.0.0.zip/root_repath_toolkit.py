# -----------------------------------------------------------------------------
#  Root Repath Toolkit / Prefix Rewrite / Path Migration
# -----------------------------------------------------------------------------

import os
import json
from .ui_language_runtime import error_text as _sf_error_text


def _sf_ref_path_under_root(abs_path: str, root_path: str) -> bool:
    abs_path = _norm_path(abs_path or '')
    root_path = _norm_path(root_path or '')
    if not abs_path or not root_path:
        return False
    try:
        return os.path.commonpath([abs_path, root_path]) == root_path
    except Exception:
        return abs_path == root_path or abs_path.startswith(root_path.rstrip('/\\') + os.sep)


def _sf_ref_root_suffix(abs_path: str, root_path: str) -> str:
    abs_path = _norm_path(abs_path or '')
    root_path = _norm_path(root_path or '')
    if not _sf_ref_path_under_root(abs_path, root_path):
        return ''
    try:
        rel = os.path.relpath(abs_path, root_path)
    except Exception:
        rel = abs_path[len(root_path):].lstrip('/\\')
    return rel.replace('\\', '/')


def _sf_ref_repath_candidate_abs(rec: dict, old_root: str, new_root: str) -> str:
    abs_path = _norm_path(str(rec.get('abs_path') or ''))
    if not abs_path:
        return ''
    suffix = _sf_ref_root_suffix(abs_path, old_root)
    if not suffix:
        return ''
    candidate = _norm_path(os.path.join(new_root, suffix))
    return _sf_ext_tokenized_sequence_path(rec, candidate)


def _sf_ref_candidate_exists(rec: dict, candidate_abs: str) -> bool:
    candidate_abs = _norm_path(candidate_abs or '')
    if not candidate_abs:
        return False
    raw_name = os.path.basename(str(rec.get('raw_path') or candidate_abs))
    seq_kind, _token = _sf_ext_token_pattern(raw_name)
    if seq_kind:
        seq_mode, seq_paths = _sf_ext_sequence_paths(rec.get('id_ref'), candidate_abs, candidate_abs)
        if seq_mode != 'FILE':
            return bool([p for p in seq_paths if os.path.exists(p)])
    return os.path.exists(candidate_abs)


_SF_REPATH_PLAN_TEXT = '.SFS_RootRepath__last_plan'


def _sf_repath_plan_find_text():
    try:
        return bpy.data.texts.get(_SF_REPATH_PLAN_TEXT)
    except Exception:
        return None


def _sf_repath_plan_read_payload() -> dict:
    text_block = _sf_repath_plan_find_text()
    if text_block is None:
        return {}
    try:
        raw = text_block.as_string()
    except Exception:
        raw = ''
    try:
        payload = json.loads(raw or '{}')
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


def _sf_repath_plan_write_payload(payload: dict) -> str:
    text_block = _sf_repath_plan_find_text()
    if text_block is None:
        text_block = bpy.data.texts.new(name=_SF_REPATH_PLAN_TEXT)
    raw = json.dumps(dict(payload or {}), ensure_ascii=False, indent=2)
    try:
        text_block.clear()
    except Exception:
        pass
    text_block.write(raw)
    try:
        text_block.use_fake_user = True
    except Exception:
        pass
    try:
        text_block.use_module = False
    except Exception:
        pass
    return str(getattr(text_block, 'name', '') or _SF_REPATH_PLAN_TEXT)


def _sf_repath_plan_entries_for_targets(targets: list[dict], *, old_root: str, new_root: str, write_mode: str, require_existing: bool) -> tuple[list[dict], list[dict]]:
    actionable = []
    unresolved = []
    for rec in list(targets or []):
        candidate_abs = _sf_ref_repath_candidate_abs(rec, old_root, new_root)
        if not candidate_abs:
            unresolved.append(dict(rec or {}))
            continue
        if require_existing and not _sf_ref_candidate_exists(rec, candidate_abs):
            row = dict(rec or {})
            row['candidate_abs'] = candidate_abs
            unresolved.append(row)
            continue
        try:
            id_ = rec.get('id_ref')
            old_path = getattr(id_, 'filepath', '') or ''
            if write_mode == 'KEEP_STYLE':
                new_path = _sf_ref_preserve_path_style(old_path, candidate_abs)
            else:
                new_path = _sf_ref_abs_to_path_mode(candidate_abs, write_mode)
        except Exception:
            unresolved.append(dict(rec or {}))
            continue
        actionable.append({
            'kind': str(rec.get('kind', '') or ''),
            'kind_label': str(rec.get('kind_label', '') or ''),
            'name': str(rec.get('name', '') or ''),
            'raw_path': str(rec.get('raw_path', '') or ''),
            'old_path': str(old_path or ''),
            'new_path': str(new_path or ''),
            'old_abs_path': str(rec.get('abs_path', '') or ''),
            'candidate_abs_path': str(candidate_abs or ''),
        })
    return actionable, unresolved


def _sf_repath_plan_collect_matches(records: list[dict], entry: dict, expected_path: str) -> list[dict]:
    kind = str(entry.get('kind', '') or '')
    name = str(entry.get('name', '') or '')
    raw_path = str(entry.get('raw_path', '') or '')
    old_abs = _norm_path(str(entry.get('old_abs_path', '') or ''))
    candidate_abs = _norm_path(str(entry.get('candidate_abs_path', '') or ''))
    matches = []
    for rec in list(records or []):
        id_ = rec.get('id_ref')
        if id_ is None:
            continue
        try:
            current = getattr(id_, 'filepath', '') or ''
        except Exception:
            current = ''
        if current != expected_path:
            continue
        if kind and str(rec.get('kind', '') or '') != kind:
            continue
        if name and str(rec.get('name', '') or '') != name:
            continue
        rec_raw = str(rec.get('raw_path', '') or '')
        rec_abs = _norm_path(str(rec.get('abs_path', '') or ''))
        if raw_path and rec_raw and rec_raw == raw_path:
            matches.append(rec)
            continue
        if old_abs and rec_abs and rec_abs == old_abs:
            matches.append(rec)
            continue
        if candidate_abs and rec_abs and rec_abs == candidate_abs:
            matches.append(rec)
            continue
        if not raw_path and not old_abs and not candidate_abs:
            matches.append(rec)
            continue
        if rec_raw == raw_path:
            matches.append(rec)
    return matches


def _sf_repath_execute_saved_plan(context, *, direction: str = 'FORWARD', open_report: bool = True) -> tuple[dict, str]:
    payload = _sf_repath_plan_read_payload()
    entries = list(payload.get('entries') or [])
    if not entries:
        raise RuntimeError(_t('No saved repath plan was found'))

    direction = str(direction or 'FORWARD').upper()
    expected_key = 'old_path' if direction != 'RESTORE' else 'new_path'
    target_key = 'new_path' if direction != 'RESTORE' else 'old_path'
    source_blend = _norm_path(str(payload.get('source_blend', '') or ''))
    current_blend = _norm_path(str(bpy.data.filepath or ''))
    records = _sf_ref_collect_scope_records(
        context,
        scope='CURRENT_FILE',
        include_libraries=True,
        include_texts=True,
        include_missing=True,
    )
    changed = 0
    drifted = 0
    failed = 0
    skipped = 0
    applied_tokens = set()
    report_lines = [
        f"Smart File | {_t('Saved Root Repath Plan')} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        '',
        f"- {_t('Direction')}: {direction}",
        f"- {_t('Source Blend')}: {source_blend or _t('Unsaved')}",
        f"- {_t('Current Blend')}: {current_blend or _t('Unsaved')}",
        f"- {_t('Entries')}: {len(entries)}",
        '',
        'RESULTS',
    ]
    if source_blend and current_blend and source_blend != current_blend:
        report_lines.append(f"- [WARN] {_t('Plan was created from a different .blend file')}: {source_blend}")

    for entry in entries:
        expected_path = str(entry.get(expected_key, '') or '')
        target_path = str(entry.get(target_key, '') or '')
        label = f"[{entry.get('kind_label', entry.get('kind', ''))}] {entry.get('name', '')}"
        if not expected_path or not target_path:
            skipped += 1
            report_lines.append(f"- [SKIP] {label} | {_t('Missing path information in saved plan')}")
            continue
        matches = _sf_repath_plan_collect_matches(records, entry, expected_path)
        if not matches:
            drifted += 1
            report_lines.append(f"- [DRIFT] {label} | {expected_path}")
            continue
        matched_this_entry = 0
        for rec in matches:
            id_ = rec.get('id_ref')
            token = _sf_ref_target_token(id_)
            if token in applied_tokens:
                continue
            try:
                current = getattr(id_, 'filepath', '') or ''
            except Exception:
                current = ''
            if current != expected_path:
                drifted += 1
                report_lines.append(f"- [DRIFT] {label} | {current}")
                continue
            try:
                setattr(id_, 'filepath', target_path)
                applied_tokens.add(token)
                matched_this_entry += 1
                changed += 1
                report_lines.append(f"- [OK] {label} | {expected_path} -> {target_path}")
            except Exception as ex:
                failed += 1
                report_lines.append(f"- [FAIL] {label} | {ex}")
        if matched_this_entry <= 0:
            skipped += 1

    text_name = _sf_report_export(
        context,
        _t('Apply Saved Root Repath Plan') if direction != 'RESTORE' else _t('Restore Saved Root Repath Plan'),
        report_lines,
        open_text=open_report,
        activity_title=_t('Applied saved root repath plan') if direction != 'RESTORE' else _t('Restored saved root repath plan'),
    )
    summary = {
        'changed': changed,
        'drifted': drifted,
        'failed': failed,
        'skipped': skipped,
        'entries': len(entries),
    }
    return summary, text_name



class SF_OT_root_repath_repath(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_root_repath_repath'
    bl_label = 'Repath'
    bl_description = 'Rewrite supported external file paths from one root folder to another while preserving the relative suffix below that root. This is the Blender-side equivalent of bulk repath utilities such as refrepath, FilePathFinder, and XRef root migration tools.'
    bl_options = {'UNDO'}

    scope: EnumProperty(
        name='Scope',
        items=[
            ('CURRENT_FILE', 'Current File', 'Process supported external records from the current file.'),
            ('SELECTED_HIERARCHY', 'Selected Hierarchy', 'Only process records reachable from the current selection and nearby collections.'),
        ],
        default='CURRENT_FILE',
        description='Choose whether to repath the whole file or only the current selection scope.',
    )
    include_libraries: BoolProperty(name='Include linked libraries', default=True, description='Also repath linked .blend library paths when the chosen scope reaches them.')
    include_texts: BoolProperty(name='Include text datablocks', default=False, description='Also include external text datablocks.')
    old_root: StringProperty(name='Old Root', subtype='DIR_PATH', default='', description='Only paths that currently sit under this root folder will be rewritten. This root may be missing on disk if the old storage location is gone.')
    new_root: StringProperty(name='New Root', subtype='DIR_PATH', default='', description='New target root folder that should receive the same relative suffix used below the old root.')
    write_mode: EnumProperty(
        name='Write Mode',
        items=[
            ('KEEP_STYLE', 'Keep existing style', 'Preserve whether each path was relative or absolute when possible.'),
            ('RELATIVE', 'Relative', 'Write successful replacements as relative paths to the current .blend file.'),
            ('ABSOLUTE', 'Absolute', 'Write successful replacements as absolute disk paths.'),
        ],
        default='KEEP_STYLE',
        description='Choose how successful replacements are written back into Blender.',
    )
    require_existing: BoolProperty(name='Require existing targets', default=True, description='Only rewrite a path when the candidate under the new root already resolves to a real file or a valid sequence on disk. Turn this off only when you are preparing a migration before the files arrive.')
    preview_only: BoolProperty(name='Preview only', default=False, description='Build the report without changing Blender paths so you can inspect the migration result first.')
    open_report: BoolProperty(name='Open report', default=True, description="Open the root-repath report in Blender's Text Editor after the run.")

    def invoke(self, context, event):
        if not self.old_root and bpy.data.filepath:
            self.old_root = _norm_path(os.path.dirname(bpy.data.filepath or ''))
        if not self.new_root and bpy.data.filepath:
            self.new_root = _norm_path(os.path.dirname(bpy.data.filepath or ''))
        return context.window_manager.invoke_props_dialog(self, width=720)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'scope')
        layout.prop(self, 'include_libraries')
        layout.prop(self, 'include_texts')
        layout.prop(self, 'old_root')
        layout.prop(self, 'new_root')
        layout.prop(self, 'write_mode')
        layout.prop(self, 'require_existing')
        layout.prop(self, 'preview_only')
        layout.prop(self, 'open_report')

    def execute(self, context):
        old_root = _norm_path(self.old_root or '')
        new_root = _norm_path(self.new_root or '')
        if not old_root or not new_root:
            self.report({'ERROR'}, _t('Both roots are required'))
            return {'CANCELLED'}
        if self.write_mode == 'RELATIVE' and not bpy.data.filepath:
            self.report({'ERROR'}, _t('Save the current file before writing relative paths'))
            return {'CANCELLED'}
        if self.require_existing and not os.path.isdir(new_root):
            self.report({'ERROR'}, _t('New root folder does not exist'))
            return {'CANCELLED'}

        records = _sf_ref_collect_scope_records(
            context,
            scope=self.scope,
            include_libraries=self.include_libraries,
            include_texts=self.include_texts,
            include_missing=True,
        )
        targets = []
        for rec in list(records or []):
            if rec.get('packed'):
                continue
            abs_path = _norm_path(str(rec.get('abs_path') or ''))
            if abs_path and _sf_ref_path_under_root(abs_path, old_root):
                targets.append(rec)
        if not targets:
            self.report({'INFO'}, _t('No matching records were found under the old root'))
            return {'CANCELLED'}

        changed = 0
        previewed = 0
        unresolved = []
        failed = []
        plan_entries, pre_unresolved = _sf_repath_plan_entries_for_targets(
            targets,
            old_root=old_root,
            new_root=new_root,
            write_mode=self.write_mode,
            require_existing=self.require_existing,
        )
        unresolved.extend(list(pre_unresolved or []))
        report_lines = [
            f"Smart File | {_t('Repath Roots')} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            '',
            f"- {_t('Scope')}: {self.scope}",
            f"- {_t('Old Root')}: {old_root}",
            f"- {_t('New Root')}: {new_root}",
            f"- {_t('Matched')}: {len(targets)}",
            f"- {_t('Write Mode')}: {self.write_mode}",
            f"- {_t('Require existing targets')}: {self.require_existing}",
            f"- {_t('Preview Only')}: {self.preview_only}",
            f"- {_t('Actionable')}: {len(plan_entries)}",
            '',
            'RESULTS',
        ]

        unresolved_seen = {
            (str(rec.get('kind', '') or ''), str(rec.get('name', '') or ''), str(rec.get('raw_path', '') or ''), str(rec.get('candidate_abs', '') or ''))
            for rec in list(unresolved or [])
        }
        for rec in targets:
            try:
                id_ = rec.get('id_ref')
                old_path = getattr(id_, 'filepath', '') or ''
            except Exception:
                old_path = ''
            candidate_abs = _sf_ref_repath_candidate_abs(rec, old_root, new_root)
            if not candidate_abs:
                key = (str(rec.get('kind', '') or ''), str(rec.get('name', '') or ''), str(rec.get('raw_path', '') or ''), '')
                if key not in unresolved_seen:
                    unresolved.append(rec)
                    unresolved_seen.add(key)
                report_lines.append(f"- [MISS] [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('raw_path','')}")
                continue
            if self.require_existing and not _sf_ref_candidate_exists(rec, candidate_abs):
                key = (str(rec.get('kind', '') or ''), str(rec.get('name', '') or ''), str(rec.get('raw_path', '') or ''), str(candidate_abs or ''))
                if key not in unresolved_seen:
                    row = dict(rec or {})
                    row['candidate_abs'] = candidate_abs
                    unresolved.append(row)
                    unresolved_seen.add(key)
                report_lines.append(f"- [MISS] [{rec.get('kind_label','')}] {rec.get('name','')} | {candidate_abs}")
                continue
            try:
                if self.write_mode == 'KEEP_STYLE':
                    new_path = _sf_ref_preserve_path_style(old_path, candidate_abs)
                else:
                    new_path = _sf_ref_abs_to_path_mode(candidate_abs, self.write_mode)
                if self.preview_only:
                    previewed += 1
                    report_lines.append(f"- [PREVIEW] [{rec.get('kind_label','')}] {rec.get('name','')} | {old_path} -> {new_path}")
                    continue
                if old_path == new_path:
                    report_lines.append(f"- [KEEP] [{rec.get('kind_label','')}] {rec.get('name','')} | {old_path}")
                    continue
                setattr(id_, 'filepath', new_path)
                changed += 1
                report_lines.append(f"- [OK] [{rec.get('kind_label','')}] {rec.get('name','')} | {old_path} -> {new_path}")
            except Exception as ex:
                failed.append(rec)
                report_lines.append(f"- [FAIL] [{rec.get('kind_label','')}] {rec.get('name','')} | {ex}")

        plan_payload = {
            'tool': 'Smart File',
            'kind': 'root_repath_plan',
            'version': _sf_pipe_version_text(),
            'created_at': _sf_guard_now_text(),
            'source_blend': str(bpy.data.filepath or ''),
            'scope': str(self.scope or ''),
            'old_root': old_root,
            'new_root': new_root,
            'write_mode': str(self.write_mode or ''),
            'require_existing': bool(self.require_existing),
            'preview_only': bool(self.preview_only),
            'matched': len(targets),
            'actionable': len(plan_entries),
            'entries': list(plan_entries or []),
        }
        plan_text_name = _sf_repath_plan_write_payload(plan_payload)
        report_lines.extend(['', 'PLAN'])
        report_lines.append(f"- {_t('Saved Plan')}: {plan_text_name}")
        report_lines.append(f"- {_t('Apply Saved Plan')}: {_t('Use Apply Saved Plan to execute the stored preview later without rebuilding the migration list')}")
        report_lines.append(f"- {_t('Restore Saved Plan')}: {_t('Use Restore Saved Plan to roll back the latest applied root migration when the current file still matches the saved target paths')}")

        if unresolved:
            report_lines.extend(['', 'UNRESOLVED'])
            for rec in unresolved:
                report_lines.append(f"- [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('raw_path','')}")
        if failed:
            report_lines.extend(['', 'FAILED'])
            for rec in failed:
                report_lines.append(f"- [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('raw_path','')}")

        text_name = _sf_report_export(
            context,
            _t('Repath Roots'),
            report_lines,
            open_text=self.open_report,
            activity_title=_t('Repathed roots') if not self.preview_only else _t('Previewed root repath'),
        )
        self.report({'INFO'}, f"{_t('Changed')}: {changed} | {_t('Previewed')}: {previewed} | {_t('Unresolved')}: {len(unresolved)} | {_t('Failed')}: {len(failed)} | {text_name}")
        return {'FINISHED'}



class SF_OT_root_repath_apply_saved_plan(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_root_repath_apply_saved_plan'
    bl_label = 'Apply Saved Plan'
    bl_description = 'Apply the last saved root-repath plan again. This is designed for the common workflow where you preview the migration first, inspect the report, and only then execute the exact same path rewrite.'
    bl_options = {'UNDO'}

    open_report: BoolProperty(name='Open report', default=True)

    def execute(self, context):
        try:
            summary, text_name = _sf_repath_execute_saved_plan(context, direction='FORWARD', open_report=self.open_report)
        except Exception as ex:
            self.report({'ERROR'}, _sf_error_text(ex))
            return {'CANCELLED'}
        self.report({'INFO'}, f"{_t('Changed')}: {summary.get('changed', 0)} | {_t('Drifted')}: {summary.get('drifted', 0)} | {_t('Failed')}: {summary.get('failed', 0)} | {text_name}")
        return {'FINISHED'}


class SF_OT_root_repath_restore_saved_plan(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_root_repath_restore_saved_plan'
    bl_label = 'Restore Saved Plan'
    bl_description = 'Roll back the latest saved root-repath plan by restoring the previous paths recorded in the saved plan. Only records that still match the saved target paths are changed back, so drifted edits stay protected.'
    bl_options = {'UNDO'}

    open_report: BoolProperty(name='Open report', default=True)

    def execute(self, context):
        try:
            summary, text_name = _sf_repath_execute_saved_plan(context, direction='RESTORE', open_report=self.open_report)
        except Exception as ex:
            self.report({'ERROR'}, _sf_error_text(ex))
            return {'CANCELLED'}
        self.report({'INFO'}, f"{_t('Changed')}: {summary.get('changed', 0)} | {_t('Drifted')}: {summary.get('drifted', 0)} | {_t('Failed')}: {summary.get('failed', 0)} | {text_name}")
        return {'FINISHED'}
