# -----------------------------------------------------------------------------
#  Register
# -----------------------------------------------------------------------------


classes = (
    # PropertyGroup classes must be registered before any class that references
    # them through Pointer/CollectionProperty (especially the N-panel settings PropertyGroup).
    SF_PathItem,
    SF_Item,
    SF_LibraryRoot,
    SF_ContextRoot,
    SF_CM_ReviewItem,
    SF_CM_OverridePreset,
    SF_CM_OverrideRoute,
    SF_WorkspaceProfile,
    UHM_HistoryEntry,
    UHM_SceneSettings,
    SFS_PG_history_history_preferences,

    SFS_PG_system_file_suite_preferences,
    SF_OT_system_save_preferences,
    SF_OT_system_open_detailed_settings,
    SF_UL_items,
    SF_UL_cm_review_items,
    SF_OT_source_browser_use,
    SF_OT_source_browser_remove,
    SF_OT_source_browser_add_current_file_to_favorites,
    SF_OT_source_browser_toggle_favorite,
    SF_OT_source_browser_copy_path,
    SF_OT_source_browser_cleanup_saved_paths,
    SF_OT_source_browser_import,
    SF_OT_source_browser_open_folder,
    SF_OT_source_browser_clear_saved_paths,
    SF_OT_source_browser_select_all,
    SF_OT_source_browser_scene_select,
    SF_OT_source_browser_open_folder_2,
    SF_OT_source_browser_import_2,
    SF_AR_Item,
    SF_UL_asset_library_asset_library_item_list,
    SF_AR_CatalogAsset,
    SF_AR_CatalogVersion,
    SF_UL_asset_library_asset_library_catalog_asset_list,
    SF_UL_asset_library_asset_library_catalog_version_list,
    SF_OT_asset_library_diagnostics,
    SF_OT_asset_library_repair_roots,
    SF_OT_asset_library_generate_catalog_draft,
    SF_OT_catalog_merge_review_merge_preview,
    SF_OT_catalog_merge_build_merge_review,
    SF_OT_catalog_merge_toggle_selection_item,
    SF_OT_override_manager_set_preset_active,
    SF_OT_override_manager_set_route_active,
    SF_OT_override_manager_save_preset,
    SF_OT_override_manager_update_preset,
    SF_OT_override_manager_remove_preset,
    SF_OT_override_manager_save_route,
    SF_OT_override_manager_update_route,
    SF_OT_override_manager_remove_route,
    SF_OT_override_manager_apply_routes,
    SF_OT_override_manager_apply_preset,
    SF_OT_override_manager_export_presets,
    SF_OT_override_manager_import_presets,
    SF_OT_catalog_merge_set_selection,
    SF_OT_catalog_merge_clear_merge_selection,
    SF_OT_catalog_merge_apply_selected_merge,
    SF_OT_catalog_merge_apply_filtered_merge,
    SF_OT_catalog_merge_apply_full_merge,
    SF_OT_reference_manager_run_library_workflow,
    SF_OT_asset_library_add_root,
    SF_OT_asset_library_remove_root,
    SF_OT_asset_library_rebuild_index,
    SF_OT_asset_reader_open,
    SF_OT_asset_reader_refresh,
    SF_OT_asset_reader_select_all,
    SF_OT_asset_reader_analyze_file,
    SF_OT_asset_reader_analyze_selection,
    SF_OT_asset_reader_show_dependency_tree,
    SF_OT_asset_reader_copy_tree,
    SF_OT_asset_reader_generate_thumbnails,
    SF_OT_asset_reader_auto_detect_catalog,
    SF_OT_asset_reader_reload_catalog,
    SF_OT_asset_reader_apply_catalog_filters,
    SF_OT_asset_reader_toggle_tag,
    SF_OT_asset_reader_clear_tags,
    SF_OT_asset_reader_set_preferred_source,
    SF_OT_asset_reader_clear_preferred_source,
    SF_OT_asset_reader_build_versions,
    SF_OT_asset_reader_import_latest,
    SF_OT_asset_reader_import_version,
    SF_OT_asset_reader_open_folder,
    SF_OT_asset_reader_import_checked,
    # Reference Manager (Phase 2)
    SF_RM_LibraryItem,
    SF_RM_CandidateItem,
    SF_RM_PlanItem,
    SF_UL_rm_libraries,
    SF_UL_rm_candidates,
    SF_UL_rm_plan,
    SF_MT_reference_manager_reference_manager_notice,
    SF_OT_reference_manager_open,
    SF_OT_reference_manager_refresh,
    SF_OT_reference_manager_check_updates,
    SF_OT_reference_manager_mark_seen,
    SF_OT_reference_manager_reload_selected,
    SF_OT_reference_manager_reload_all,
    SF_OT_reference_manager_apply_selected_relink,
    SF_OT_reference_manager_review_suggested_relink,
    SF_OT_reference_manager_review_auto_relink,
    SF_OT_library_roots_resolve_using_roots,
    SF_OT_reference_manager_switch_to_latest,
    SF_OT_reference_manager_prepare_saved_upgrade_plan,
    SF_OT_reference_manager_apply_saved_upgrade_plan,
    SF_OT_reference_manager_restore_saved_upgrade_plan,
    SF_OT_reference_manager_apply_preset,
    SF_OT_reference_manager_review_update_plan,
    SF_OT_reference_manager_review_select_all,
    SF_OT_reference_manager_refresh_2,
    SF_OT_override_manager_make_overrides_for_selected_linked,
    SF_OT_override_manager_resync_overrides,
    SF_OT_override_manager_audit,
    SF_OT_external_assets_edit_selected_library,
    SF_OT_external_assets_return_to_parent_scene,
    SF_OT_reference_toolkit_open,
    SF_OT_reference_toolkit_materialize_linked_references,
    SF_OT_reference_toolkit_export_selection_as_library,
    SF_OT_reference_toolkit_normalize_external_paths,
    SF_OT_reference_toolkit_swap_external_extensions,
    SF_OT_root_repath_repath,
    SF_OT_root_repath_apply_saved_plan,
    SF_OT_root_repath_restore_saved_plan,
    SF_OT_pipeline_publish_container,
    SF_OT_pipeline_load_container,
    SF_OT_container_deck_open,
    SF_OT_container_deck_load_latest,
    SF_OT_container_deck_load_revision,
    SF_OT_container_deck_switch_representation,
    SF_OT_context_roots_open,
    SF_OT_context_roots_add_root,
    SF_OT_context_roots_remove_root,
    SF_OT_context_roots_import_library_roots,
    SF_OT_context_roots_export_root_config,
    SF_OT_context_roots_import_root_config,
    SF_OT_context_roots_export_manifest,
    SF_OT_context_roots_preview_manifest,
    SF_OT_context_roots_apply_manifest,
    SF_OT_context_roots_environment_audit,
    SF_OT_root_watch_open,
    SF_OT_root_watch_capture_snapshot,
    SF_OT_root_watch_refresh,
    SF_OT_root_watch_export_drift_report,
    SF_OT_pipeline_shot_manifest,
    SF_OT_pipeline_select_by_reference_state,
    SF_OT_pipeline_linked_overview,
    SF_OT_representation_apply,
    SF_OT_representation_store_snapshot,
    SF_OT_representation_restore_snapshot,
    SF_OT_representation_open,
    SF_OT_project_guard_store_scene_state,
    SF_OT_project_guard_restore_scene_state,
    SF_OT_project_guard_export_scene_state,
    SF_OT_project_guard_import_scene_state,
    SF_OT_project_guard_create_cooperative_lock,
    SF_OT_project_guard_refresh_cooperative_locks,
    SF_OT_project_guard_release_cooperative_lock,
    SF_OT_project_guard_cleanup_stale_locks,
    SF_OT_project_guard_export_report,
    SF_OT_project_guard_handoff_audit,
    SF_OT_project_guard_open,
    SF_ShotPresetItem,
    SF_UL_shot_state_shot_state_preset_list,
    SF_OT_shot_state_refresh_presets,
    SF_OT_shot_state_open,
    SF_OT_shot_state_save_current_as_preset,
    SF_OT_shot_state_apply_selected_preset,
    SF_OT_shot_state_remove_selected_preset,
    SF_OT_shot_state_export_book,
    SF_OT_shot_state_import_book,
    SF_ShotSlotItem,
    SF_UL_shot_queue_shot_queue_slot_list,
    SF_OT_shot_queue_open,
    SF_OT_shot_queue_store_current,
    SF_OT_shot_queue_capture_from_camera_markers,
    SF_OT_shot_queue_capture_from_cameras,
    SF_OT_shot_queue_apply_active,
    SF_OT_shot_queue_remove_active,
    SF_OT_shot_queue_move_active,
    SF_OT_shot_queue_export_queue,
    SF_OT_shot_queue_import_queue,
    SF_OT_shot_queue_preflight,
    SF_OT_shot_queue_run_queue,
    SF_OT_assembly_guard_apply,
    SF_OT_assembly_guard_store_snapshot,
    SF_OT_assembly_guard_restore_snapshot,
    SF_OT_assembly_guard_open,
    SF_OT_dependency_cockpit_open,
    SF_OT_dependency_cockpit_selection_dependency_report,
    SF_OT_dependency_cockpit_relink_selected_hierarchy,
    SF_OT_external_assets_audit,
    SF_OT_external_assets_export_report,
    SF_OT_external_assets_relink_missing,
    SF_OT_external_assets_conflict_audit,
    SF_OT_external_assets_verify_bundle,
    SF_OT_external_assets_bundle_project,

    # Publisher (Phase 3)
    SF_OT_publisher_publish_asset,
    # Batch Preview (Phase 3.2)
    SF_OT_asset_preview_batch_preview,

    # File Pipeline cross-DCC reference and pipeline hub
    *_SFSMART_CLASSES,

    SF_OT_asset_reader_translation_check,
    SF_OT_reference_manager_apply_recommended_setup,
    SF_OT_workspace_profile_save_current_setup,
    SF_OT_workspace_profile_apply_profile,
    SF_OT_workspace_profile_apply_and_open,
    SF_OT_workspace_profile_remove_profile,
    SF_OT_workspace_profile_seed_default_profiles,
    SF_OT_workspace_profile_duplicate_profile,
    SF_OT_workspace_profile_pin,
    SF_OT_workspace_command_set_goal,
    SF_OT_workspace_command_open_goal,
    SF_OT_workspace_command_run_goal_starter_pack,
    SF_OT_workspace_command_run_top_recommendation,
    SF_OT_reference_manager_run_repair_pack,
    SF_OT_workspace_command_fix_preview,
    SF_OT_workspace_command_fix_all,
    SF_OT_reference_manager_view_action_result,
    SF_OT_workspace_command_fix_details,
    SF_OT_workspace_command_fix_report,
    SF_OT_reference_manager_clear_activity_log,
    SF_OT_reference_manager_export_activity_log,
    SF_OT_workspace_profile_edit_profile,
    SF_OT_workspace_profile_clear_filter,
    SF_OT_workspace_profile_move_profile,
    SF_OT_workspace_profile_export_workspace_profiles,
    SF_OT_workspace_profile_import_workspace_profiles,
    SF_OT_library_roots_add_source_folder_as_root,
    SF_OT_library_roots_clean_roots,
    SF_OT_library_roots_enable_all_roots,
    SF_OT_library_roots_disable_missing_roots,
    SF_OT_library_roots_sort_roots,
    SF_OT_library_roots_quick_root_bootstrap,
    SF_OT_reference_manager_workspace_report,
    SF_OT_workspace_command_session_bundle,
    SF_OT_workspace_command_goal_roadmap,
    SF_OT_workspace_command_save_goal_snapshot,
    SF_OT_reference_manager_apply_setup_and_open,
    SF_OT_reference_manager_source_check,
    SF_OT_workspace_command_session_cockpit,
    SF_OT_workspace_command_goal_home,
    SF_OT_reference_manager_product_readiness_report,
    SF_OT_workspace_command_release_report,
    SF_OT_workspace_command_handoff_report,
    SF_OT_workspace_command_release_gate,
    SF_OT_reference_manager_final_review,
    SF_OT_workspace_command_action_palette,
    SF_OT_library_roots_root_coverage_matrix,
    SF_OT_system_rebuild_n_panel_ui,
    SF_OT_refresh_compact_launcher_context,
    SF_OT_workspace_command_show_page,
    SF_OT_system_toggle_always_on_setting,
    SF_OT_system_toggle_ui_section,
    SF_OT_system_open_help,
    SF_OT_workspace_command_category_tools,
    SF_OT_workspace_command_open_category_hub,
    SF_OT_system_measure_undo_speed,
    SF_OT_system_purge_orphan_data,
    SF_OT_history_open,
    SF_OT_workspace_command_launcher,
    SF_PT_workspace_command_workspace_launcher,
    SF_PT_reference_manager_reference_manager_workspace,
    SF_MT_reference_manager_reference_manager_recent_sources,
    SF_MT_reference_manager_reference_manager_favorite_sources,
    SF_MT_reference_manager_reference_manager,

    # Integrated History Auto Save
    *_SFS_HISTORY_OP_CLASSES,
    *_SFS_HISTORY_PANEL_CLASSES,
)

# Register the Smart File workspace as a normal 3D View Sidebar N-panel.
# History panels are still hosted by the integrated History / Restore category to avoid duplicate UI.
# The legacy launcher panel is kept in source for compatibility references but is not registered;
# visible Smart File UI is centralized in the N-panel.
# History Auto Save has one lifecycle owner: history_integration.  The core
# register sequence must not acquire these exact RNA identities first and then
# ask the integration owner to register them a second time.
_SFS_HISTORY_INTEGRATION_OWNED_CLASSES = (
    UHM_HistoryEntry,
    UHM_SceneSettings,
    SFS_PG_history_history_preferences,
) + tuple(_SFS_HISTORY_OP_CLASSES) + tuple(_SFS_HISTORY_PANEL_CLASSES)

classes = tuple(
    cls for cls in classes
    if cls not in _SFS_HISTORY_INTEGRATION_OWNED_CLASSES
    and cls is not SF_PT_workspace_command_workspace_launcher
)


# -----------------------------------------------------------------------------
# Exact generation ownership for core RNA classes and WindowManager properties.
# -----------------------------------------------------------------------------
import uuid as _sf_lifecycle_uuid

_SF_CORE_OWNER_KEY = "JELararagi.smart_file.core.lifecycle.v57540"
_SF_CORE_LEGACY_OWNER_KEYS = (
    "JELararagi.smart_file.core.lifecycle.v57539",
    "JELararagi.smart_file.core.lifecycle.v57536",

    "JELararagi.smart_file.core.lifecycle.v57535",
    "JELararagi.smart_file.core.lifecycle.v57534",
    "JELararagi.smart_file.core.lifecycle.v57533",
)
_SF_CORE_OWNER_TOKEN = object()
_SF_CORE_GENERATION = _sf_lifecycle_uuid.uuid4().hex
_SF_CLASS_RECORDS = []
_SF_PROPERTY_RECORDS = []
_SF_PROPERTY_MISSING = object()
_SF_CORE_ACTIVE = False


def _sf_core_namespace():
    try:
        value = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _sf_core_ledger():
    namespace = _sf_core_namespace()
    value = namespace.get(_SF_CORE_OWNER_KEY) if namespace is not None else None
    return value if isinstance(value, dict) else None


def _sf_property_descriptor(owner_type, name):
    try:
        direct = vars(owner_type).get(str(name), _SF_PROPERTY_MISSING)
    except Exception:
        direct = _SF_PROPERTY_MISSING
    if direct is not _SF_PROPERTY_MISSING:
        return direct
    try:
        return getattr(owner_type, str(name))
    except Exception:
        return _SF_PROPERTY_MISSING


def _sf_pointer_expected_type(descriptor):
    try:
        fixed = getattr(descriptor, 'fixed_type', None)
        if fixed is not None:
            return fixed
    except Exception:
        pass
    try:
        keywords = getattr(descriptor, 'keywords', None)
        if isinstance(keywords, dict):
            return keywords.get('type')
    except Exception:
        pass
    return None


def _sf_property_record(name):
    for record in reversed(tuple(_SF_PROPERTY_RECORDS)):
        if record.get('name') == str(name):
            return record
    return None


def _sf_property_records_exact():
    ledger = _sf_core_ledger()
    ledger_records = tuple(ledger.get('properties', ()) or ()) if isinstance(ledger, dict) else ()
    if len(ledger_records) != len(_SF_PROPERTY_RECORDS):
        return False
    for index, record in enumerate(tuple(_SF_PROPERTY_RECORDS)):
        if ledger_records[index] is not record:
            return False
        owner = record.get('owner')
        name = record.get('name')
        descriptor = record.get('descriptor')
        if owner is None or not name or _sf_property_descriptor(owner, name) is not descriptor:
            return False
    return True


def _sf_record_property(owner_type, name, descriptor, *, acquired, shared=False):
    record = {
        'owner': owner_type,
        'name': str(name),
        'descriptor': descriptor,
        'acquired': bool(acquired),
        'shared': bool(shared),
        'token': _SF_CORE_OWNER_TOKEN,
        'generation': _SF_CORE_GENERATION,
    }
    _SF_PROPERTY_RECORDS.append(record)
    ledger = _sf_core_ledger()
    if isinstance(ledger, dict):
        ledger['properties'] = tuple(_SF_PROPERTY_RECORDS)
    return record


def _sf_assign_owned_property(owner_type, name, definition):
    name = str(name)
    existing = _sf_property_descriptor(owner_type, name)
    prior = _sf_property_record(name)
    if existing is not _SF_PROPERTY_MISSING:
        if isinstance(prior, dict) and prior.get('owner') is owner_type and prior.get('descriptor') is existing:
            return existing
        # sf_addon_settings is shared with the sole History/settings lifecycle.
        # Accept only the exact canonical type; never replace a foreign descriptor.
        if name == 'sf_addon_settings':
            expected = _sf_pointer_expected_type(definition)
            current = _sf_pointer_expected_type(existing)
            if expected is not None and current is expected:
                _sf_record_property(owner_type, name, existing, acquired=False, shared=True)
                return existing
        raise RuntimeError(f'WindowManager.{name} already exists without this generation ownership')
    setattr(owner_type, name, definition)
    descriptor = _sf_property_descriptor(owner_type, name)
    if descriptor is _SF_PROPERTY_MISSING:
        raise RuntimeError(f'WindowManager.{name} property registration produced no descriptor')
    _sf_record_property(owner_type, name, descriptor, acquired=True)
    return descriptor


class _SFPropertyOwnerProxy:
    __slots__ = ('_owner',)

    def __init__(self, owner_type):
        object.__setattr__(self, '_owner', owner_type)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, '_owner'), name)

    def __setattr__(self, name, value):
        if name == '_owner':
            object.__setattr__(self, name, value)
            return
        _sf_assign_owned_property(object.__getattribute__(self, '_owner'), name, value)


def _sf_unregister_owned_properties():
    global _SF_PROPERTY_RECORDS
    ok = True
    for record in reversed(tuple(_SF_PROPERTY_RECORDS)):
        if not bool(record.get('acquired')):
            continue
        owner = record.get('owner')
        name = record.get('name')
        descriptor = record.get('descriptor')
        if owner is None or not name:
            ok = False
            continue
        current = _sf_property_descriptor(owner, name)
        if current is not descriptor:
            # Never delete an unknown replacement.
            ok = False
            continue
        try:
            delattr(owner, name)
        except Exception:
            ok = False
    _SF_PROPERTY_RECORDS = []
    ledger = _sf_core_ledger()
    if isinstance(ledger, dict):
        ledger['properties'] = ()
    return ok


def _sf_cleanup_ledger_exact_records(ledger, class_records, property_records):
    """Retire only exact resources captured by an older Smart File ledger."""
    if not isinstance(ledger, dict):
        return False
    if int(ledger.get('schema', -1) or -1) != 1:
        return False
    if not str(ledger.get('suite_version', '') or '').startswith(('1.', '5.75.')):  # this release family and pre-1.0.0 ledgers being upgraded
        return False
    class_records = tuple(class_records or ())
    property_records = tuple(property_records or ())
    ok = True
    regular = []
    property_groups = []
    property_group_base = getattr(bpy.types, 'PropertyGroup', None)
    for record in class_records:
        if not isinstance(record, dict) or not bool(record.get('acquired')):
            continue
        cls = record.get('class')
        rna = record.get('rna')
        if not isinstance(cls, type) or rna is None:
            ok = False
            continue
        try:
            is_property_group = bool(property_group_base is not None and issubclass(cls, property_group_base))
        except Exception:
            is_property_group = False
        (property_groups if is_property_group else regular).append((cls, rna))

    def retire_class(cls, rna):
        try:
            current = vars(cls).get('bl_rna')
        except Exception:
            current = None
        if current is None:
            return True
        if current is not rna:
            return False
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            return False
        try:
            return vars(cls).get('bl_rna') is None
        except Exception:
            return True

    for cls, rna in reversed(regular):
        if not retire_class(cls, rna):
            ok = False
    for record in reversed(property_records):
        if not isinstance(record, dict) or not bool(record.get('acquired')):
            continue
        owner = record.get('owner')
        name = str(record.get('name', '') or '')
        descriptor = record.get('descriptor')
        if owner is None or not name or descriptor is None:
            ok = False
            continue
        current = _sf_property_descriptor(owner, name)
        if current is _SF_PROPERTY_MISSING:
            continue
        if current is not descriptor:
            ok = False
            continue
        try:
            delattr(owner, name)
        except Exception:
            ok = False
    for cls, rna in reversed(property_groups):
        if not retire_class(cls, rna):
            ok = False
    return bool(ok)


def _sf_cleanup_previous_core_owner(ledger):
    if not isinstance(ledger, dict):
        return True
    class_records = tuple(ledger.get('classes', ()) or ())
    property_records = tuple(ledger.get('properties', ()) or ())
    cleanup = ledger.get('cleanup')
    if callable(cleanup):
        try:
            if bool(cleanup(ledger.get('token'), ledger.get('generation'))):
                return True
        except Exception:
            pass
    # In-place module replacement can leave the old cleanup callable bound to
    # mutable globals that now describe the new generation. The immutable class
    # and property receipts captured above remain authoritative.
    return _sf_cleanup_ledger_exact_records(ledger, class_records, property_records)


def _sf_acquire_core_owner():
    namespace = _sf_core_namespace()
    if namespace is None:
        raise RuntimeError('driver_namespace is unavailable for Smart File core ownership')
    for key in _SF_CORE_LEGACY_OWNER_KEYS:
        previous = namespace.get(key)
        if previous is None:
            continue
        if not _sf_cleanup_previous_core_owner(previous):
            raise RuntimeError(f'could not clean previous Smart File core owner: {key}')
        namespace.pop(key, None)
    previous = namespace.get(_SF_CORE_OWNER_KEY)
    if isinstance(previous, dict) and previous.get('token') is _SF_CORE_OWNER_TOKEN and previous.get('generation') == _SF_CORE_GENERATION:
        if bool(previous.get('active')) and _SF_CORE_ACTIVE:
            return True
        if not _sf_cleanup_previous_core_owner(previous):
            raise RuntimeError('could not clean partial Smart File core generation')
        namespace.pop(_SF_CORE_OWNER_KEY, None)
        previous = None
    if previous is not None:
        if not _sf_cleanup_previous_core_owner(previous):
            raise RuntimeError('could not clean previous Smart File core generation')
        namespace.pop(_SF_CORE_OWNER_KEY, None)
    namespace[_SF_CORE_OWNER_KEY] = {
        'schema': 1,
        'suite_version': '1.0.0',
        'token': _SF_CORE_OWNER_TOKEN,
        'generation': _SF_CORE_GENERATION,
        'classes': tuple(_SF_CLASS_RECORDS),
        'properties': tuple(_SF_PROPERTY_RECORDS),
        'active': False,
        'cleanup': _sf_cleanup_core_generation,
    }
    return True


def _sf_release_core_owner():
    namespace = _sf_core_namespace()
    if namespace is None:
        return False
    ledger = namespace.get(_SF_CORE_OWNER_KEY)
    if isinstance(ledger, dict) and ledger.get('token') is _SF_CORE_OWNER_TOKEN and ledger.get('generation') == _SF_CORE_GENERATION:
        namespace.pop(_SF_CORE_OWNER_KEY, None)
        return True
    return False


def _sf_settings_runtime_module():
    """Return the already-loaded canonical settings service without re-import."""
    package = str(__package__ or __name__ or '').strip()
    module = _sys.modules.get(f'{package}.settings') if package else None
    if module is not None:
        return module
    importer = globals().get('_sf_import_package_module')
    if callable(importer):
        try:
            return importer('settings')
        except Exception:
            return None
    return None


def _sf_schedule_persistence_update(context=None) -> bool:
    module = _sf_settings_runtime_module()
    schedule = getattr(module, 'schedule_save', None) if module is not None else None
    if not callable(schedule):
        return False
    return bool(schedule(context or getattr(bpy, 'context', None)))


def _sf_make_persistence_update(previous=None):
    """Compose one RNA callback with trailing-edge settings persistence."""
    def _update(self, context):
        try:
            if callable(previous):
                previous(self, context)
        finally:
            try:
                _sf_schedule_persistence_update(context)
            except Exception:
                pass
    return _update


def _sf_persisting_factory(factory):
    def _factory(*args, **kwargs):
        options = dict(kwargs)
        options['update'] = _sf_make_persistence_update(options.get('update'))
        return factory(*args, **options)
    return _factory


_SF_PERSISTENT_PROPERTY_GROUP_CLASSES = tuple(
    cls for cls in (
        SF_RM_LibraryItem,
        SF_RM_CandidateItem,
        SF_RM_PlanItem,
        SF_ShotSlotItem,
        SF_PathItem,
        SF_Item,
        SF_LibraryRoot,
        SF_ContextRoot,
        SF_CM_ReviewItem,
        SF_CM_OverridePreset,
        SF_CM_OverrideRoute,
        SF_WorkspaceProfile,
        SFS_PG_system_file_suite_preferences,
        SF_AR_Item,
        SF_AR_CatalogAsset,
        SF_AR_CatalogVersion,
        SF_ShotPresetItem,
    )
    if isinstance(cls, type)
)


def _sf_install_property_group_persistence() -> None:
    """Rebuild known Smart File scalar PropertyGroup callbacks exactly once."""
    scalar_factories = {
        'BoolProperty', 'IntProperty', 'FloatProperty', 'FloatVectorProperty',
        'StringProperty', 'EnumProperty',
    }
    for cls in _SF_PERSISTENT_PROPERTY_GROUP_CLASSES:
        annotations = getattr(cls, '__annotations__', {}) or {}
        for name, prop_def in tuple(annotations.items()):
            factory = getattr(prop_def, 'function', None)
            keywords = getattr(prop_def, 'keywords', None)
            if (not callable(factory) or not isinstance(keywords, dict)
                    or str(getattr(factory, '__name__', '')) not in scalar_factories):
                continue
            options = dict(keywords)
            options['update'] = _sf_make_persistence_update(options.get('update'))
            annotations[name] = factory(**options)


_sf_install_property_group_persistence()


def _register_props_impl():
    wm = _SFPropertyOwnerProxy(bpy.types.WindowManager)

    wm.sf_addon_settings = PointerProperty(type=_sf_registered_property_group_type(SFS_PG_system_file_suite_preferences), description='Persistent Smart File N-panel settings stored in Blender config/Smart_File_Suite/Smart_File_Suite.json')

    wm.sf_filepath = StringProperty(name='File', description='Current source .blend scene path used by the import browser. You can paste or type a path here directly, then use Scene Select to scan that file or Open Folder to browse to another file.')
    wm.sf_mode = EnumProperty(
        name='Mode',
        items=[
            ('OBJECTS', "Objects", 'Browse Object datablocks and optionally bring in related helper objects such as parents, constraint targets, and modifier drivers.'),
            ('COLLECTIONS', "Collections", 'Browse whole collections when you want grouped scene content to come in together.'),
            ('MATERIALS', "Materials", 'Browse materials only. Useful when you want shaders without importing scene objects.'),
            ('NODE_GROUPS', "Node Groups", 'Browse reusable node groups from the source file.'),
            ('ACTIONS', "Actions", 'Browse animation Action datablocks for rigs, poses, and motion libraries.'),
            ('WORLDS', "Worlds", 'Browse World datablocks such as environment setups and lighting backdrops.'),
        ],
        default='OBJECTS',
        update=_update_mode,
        description='Choose which kind of datablock to show from the selected .blend file, such as Objects, Collections, Materials, Node Groups, Actions, or Worlds. Switch this when you want to narrow the browser to only the data you actually plan to bring in.',
    )
    wm.sf_filter = StringProperty(name='Search', default="", description='Filter the listed datablocks by name so you can narrow long source files quickly.')
    wm.sf_sort = EnumProperty(
        name='Sort',
        items=[
            ('NAME_ASC', "A-Z", 'Sort names in ascending alphabetical order so it is easier to scan from the beginning.'),
            ('NAME_DESC', "Z-A", 'Sort names in descending alphabetical order so later names appear first.'),
        ],
        default='NAME_ASC',
        description='Choose how the current datablock list is ordered so large libraries are easier to scan.',
    )

    wm.sf_items = CollectionProperty(type=_sf_registered_property_group_type(SF_Item), description='Runtime list of datablocks found in the selected source file and shown in the import browser.')
    wm.sf_active_index = IntProperty(default=0, description='Currently active row in the import list.')

    wm.sf_import_mode = EnumProperty(
        name='Import Mode',
        items=[
            ('APPEND', "Append (Make Local)", 'Import a local editable copy into the current file. This is the safest default when you plan to edit the result here.'),
            ('LINK', "Link (Reference)", 'Reference the source file without copying the datablock locally. Good for shared libraries you want to keep synchronized.'),
            ('LINK_OVERRIDE', "Link + Library Override", 'Link first, then create editable overrides where Blender supports them. Useful when you need controlled local edits on top of shared assets.'),
        ],
        default='APPEND',
        description='Choose whether the selected datablocks are appended as local editable data, linked as references, or linked with overrides. Pick the mode that matches how much editing freedom and library synchronization you need.',
    )

    wm.sf_strict_loader = BoolProperty(
        name='Strict Loader (wm.append/link)',
        default=False,
        description="Use Blender's built-in append or link operator for stricter loading behavior. This can be safer in difficult cases, but it may be slower and less flexible than the default Smart File loading path.",
    )

    wm.sf_include_dependencies = BoolProperty(
        name='Include related objects (parents / constraint targets / modifier objects) if possible',
        default=True,
        description='When importing Objects, also try to bring in related helper objects such as parents, constraint targets, and modifier helper objects when they are needed.',
    )
    wm.sf_bake_world = BoolProperty(
        name='Bake world transform (optionally clear parent/constraints) after import',
        default=False,
        description='After import, keep the objects at the same world-space position even if parent links or constraints are later removed. This helps when you want a stable final placement instead of source rig relationships.',
    )
    wm.sf_clear_parent = BoolProperty(name='Clear parent', default=True, description='After baking the world transform, remove the parent relationship so the imported object becomes independent.')
    wm.sf_clear_constraints = BoolProperty(name='Clear constraints', default=False, description='After baking the world transform, remove constraints from the imported objects. Turn this on only when you no longer need source-driven motion or attachment rules.')

    wm.sf_prefix = StringProperty(name='Namespace Prefix', default="", description='Optional text added to imported names so you can avoid name collisions and keep batches from different libraries easy to identify. Example: CHR_, ENV_, or PROP_.')
    wm.sf_collision = EnumProperty(
        name='Name Collision',
        items=[
            ('DUPLICATE', "Duplicate (keep both)", 'Keep existing data and import the new one beside it, usually by renaming the incoming data.'),
            ('REUSE', "Reuse existing", 'Use data that already exists in the current file when the names match.'),
            ('REPLACE', "Replace existing", 'Replace matching existing data with the incoming data when supported by the current workflow.'),
        ],
        default='DUPLICATE',
        description='Choose what should happen when the current file already contains data with the same name as the incoming datablock. Use Duplicate to keep both, Reuse to keep the current one, or Replace when you intentionally want the incoming data to take over.',
    )
    wm.sf_apply_prefix_to_linked = BoolProperty(
        name='Apply prefix to linked items',
        default=False,
        description='Apply the namespace prefix even to linked items for this import only. This temporarily overrides the add-on preference so you can keep linked results easier to identify in the Outliner.',
    )

    wm.sf_put_in_collection = BoolProperty(
        name='Put imported objects into a new collection',
        default=True,
        description='Put imported scene items into a destination collection so they stay grouped, easier to hide, move, organize, or remove later.',
    )
    wm.sf_collection_name_mode = EnumProperty(
        name='Collection Name',
        items=[
            ('FILE', "Use file name", 'Name the destination collection after the source file so imported groups stay easy to trace later.'),
            ('CUSTOM', "Custom", 'Use your own collection name. Helpful when you want a cleaner scene structure than the file name.'),
        ],
        default='FILE',
        description='Choose how the destination collection is named when imported scene items are grouped into a collection.',
    )
    wm.sf_collection_name = StringProperty(name='Collection Name', default="", description='Type the destination collection name used when Collection Name is set to Custom.')

    wm.sf_placement = EnumProperty(
        name='Placement',
        items=[
            ('ORIGINAL', "Keep original coordinates", 'Preserve the imported scene items at the coordinates stored in the source file.'),
            ('CURSOR', "Place as a group at 3D Cursor", 'Move the imported scene items together so their group origin lands at the 3D Cursor.'),
            ('ACTIVE', "Place as a group at Active Object", 'Move the imported scene items together so they appear around the active object.'),
            ('FLOOR', "Drop group to floor (Z=0)", "Move the imported scene items so the group's lowest point rests on world Z=0."),
            ('GRID', "Arrange in a grid", 'Lay out imported scene items in a preview-style grid so many assets can be inspected quickly.'),
        ],
        default='ORIGINAL',
        description='Choose where imported scene items should appear after loading. Keep their original coordinates, move them to the 3D Cursor or Active Object, drop them to the floor, or arrange them in a grid for quick review.',
    )
    wm.sf_offset = FloatVectorProperty(
        name='Offset',
        size=3,
        default=(0.0, 0.0, 0.0),
        subtype='TRANSLATION',
        description='Additional X, Y, and Z offset applied after the main placement rule. Use this for small spacing adjustments without changing the main placement mode.',
    )
    wm.sf_grid_spacing = FloatVectorProperty(
        name='Grid Spacing',
        size=3,
        default=(2.0, 2.0, 0.0),
        subtype='TRANSLATION',
        description='Distance between imported items when Placement is set to Grid. Increase this when assets overlap, or reduce it when you want denser review sheets.',
    )
    wm.sf_grid_columns = IntProperty(name='Columns', default=5, min=1, max=100, description='Number of columns used when Grid placement arranges imported items.')

    wm.sf_select_imported = BoolProperty(name='Select imported items', default=True, description='Select imported scene items automatically after the import finishes so you can inspect or move them right away.')
    wm.sf_frame_view = BoolProperty(name='Frame in View (3D View only)', default=False, description='After the import finishes, frame the imported scene items in the active 3D View so they come into view immediately.')
    wm.sf_last_fix_summary = StringProperty(name='Last Smart Fix Summary', default="", options={'HIDDEN'}, description='Most recent Smart Fix summary captured during this Blender session')
    wm.sf_last_fix_details = StringProperty(name='Last Smart Fix Details', default="", options={'HIDDEN'}, description='Detailed Smart Fix notes captured during this Blender session')
    wm.sf_last_action_title = StringProperty(name='Last Quick Action Title', default="", options={'HIDDEN'}, description='Latest quick-action title captured during this Blender session')
    wm.sf_last_action_summary = StringProperty(name='Last Quick Action Summary', default="", options={'HIDDEN'}, description='Latest quick-action summary captured during this Blender session')
    wm.sf_last_action_details = StringProperty(name='Last Quick Action Details', default="", options={'HIDDEN'}, description='Detailed quick-action notes captured during this Blender session')
    wm.sf_last_action_followup = StringProperty(name='Last Quick Action Follow-up', default="", options={'HIDDEN'}, description='Suggested follow-up notes for the latest quick action')
    wm.sf_last_action_icon = StringProperty(name='Last Quick Action Icon', default="CHECKMARK", options={'HIDDEN'}, description='Icon used by the latest quick-action result popup')
    wm.sf_activity_log = StringProperty(name='Activity Log', default='[]', options={'HIDDEN'}, description='Recent Smart File activity captured during this Blender session')
    wm.sf_session_goal = EnumProperty(
        name='Goal',
        items=[
            ('EXPLORE', "Explore", "Focus the UI on browsing, reading, and catalog discovery before you commit to an import or publish action"),
            ('IMPORT', "Import", "Focus the UI on source selection, safer local import setups, and datablock browsing"),
            ('MAINTAIN', "Maintain", "Focus the UI on library roots, indexing, relink review, diagnostics, and maintenance tasks"),
            ('PUBLISH', "Publish", "Focus the UI on previews, metadata, versioning, and catalog or publish preparation"),
            ('RECOVER', "Recover", "Focus the UI on fixing broken roots, source coverage, and setup blockers before normal work continues"),
        ],
        default='IMPORT',
        description='Choose the current task focus so Goal Home, Launcher, Source Check, and profile suggestions stay aligned with what you are doing right now',
    )

    sfsmart_register_props(wm)

    wm.sf_workspace_page = EnumProperty(
        name='Workspace Page',
        items=_SF_NPANEL_PAGE_ITEMS,
        default='HOME',
        update=_sf_update_workspace_page,
        description='Current Smart File page shown inside the Smart File N-panel',
    )
    # Current asset context (for Asset Reader Catalog -> import tagging)
    wm.sf_current_asset_id = StringProperty(name='Current Asset ID', default="", options={'HIDDEN'}, description='Internal asset identifier passed between tools')


    # Asset Reader (Phase 1)
    wm.sf_ar_root_filter = EnumProperty(name='Roots', items=_ar_root_items, description='Limit the Asset Reader list to a specific configured library root')
    wm.sf_ar_type_filter = EnumProperty(name='Type', items=_AR_TYPE_ITEMS, default='ALL', description='Filter Asset Reader results by datablock type')
    wm.sf_ar_search = StringProperty(name='Search', default="", description='Search text used in the Asset Reader list')
    wm.sf_ar_sort = EnumProperty(
        name='Sort',
        items=[
            ('NAME_ASC', "A-Z", ""),
            ('NAME_DESC', "Z-A", ""),
            ('FILE_ASC', "File A-Z", 'Sort results by source file name in ascending order.'),
            ('FILE_DESC', "File Z-A", 'Sort results by source file name in descending order.'),
        ],
        default='NAME_ASC',
        description='Sort order for Asset Reader results',
    )
    wm.sf_ar_items = CollectionProperty(type=_sf_registered_property_group_type(SF_AR_Item), description='Runtime Asset Reader result rows')
    wm.sf_ar_active_index = IntProperty(default=0, description='Active Asset Reader row')
    wm.sf_ar_dep_summary = StringProperty(name='Dependency Summary', default="", description='Short dependency summary for the active Asset Reader item')
    wm.sf_ar_dep_tree = StringProperty(name='Dependency Tree', default="", description='Dependency tree text for the active Asset Reader item')

    # Asset Reader Catalog (Phase 3.2)
    wm.sf_ar_view_mode = EnumProperty(name='View', items=[('INDEX', 'Index', 'Browse raw indexed .blend contents directly. Good for diagnostics and deep inspection.'), ('CATALOG', 'Catalog', 'Browse merged catalog entries prepared for shared asset-library workflows.')], default='INDEX', description='Switch between raw library index browsing and catalog-driven browsing.')
    wm.sf_ar_catalog_file = StringProperty(name='Catalog File', subtype='FILE_PATH', default='', description='Optional explicit catalog.json file to load for catalog browsing')
    wm.sf_ar_cat_merge_roots = BoolProperty(name='Merge Roots', default=True, description='Merge catalog assets from all enabled roots into one combined catalog view')
    wm.sf_ar_cat_tag_cloud_json = StringProperty(name='Tag Cloud JSON', default='[]', options={'HIDDEN'}, description='Internal cached tag cloud data for the Asset Reader catalog view')
    wm.sf_ar_cat_category = EnumProperty(name='Category', items=_ar_cat_category_items, description='Filter the catalog view by category')
    wm.sf_ar_cat_tag_filter = StringProperty(name='Tags', default='', description='Tag filter for the catalog view')
    wm.sf_ar_cat_categories_json = StringProperty(name='Categories JSON', default='[]', options={'HIDDEN'})
    wm.sf_ar_cat_raw_json = StringProperty(name='Catalog Raw JSON', default='', options={'HIDDEN'})
    wm.sf_ar_cat_assets = CollectionProperty(type=_sf_registered_property_group_type(SF_AR_CatalogAsset))
    wm.sf_ar_cat_active_index = IntProperty(default=0)
    wm.sf_ar_cat_versions = CollectionProperty(type=_sf_registered_property_group_type(SF_AR_CatalogVersion))
    wm.sf_ar_cat_ver_active_index = IntProperty(default=0)


    wm.sf_ar_cat_pref_source = EnumProperty(
        name='Preferred Source',
        items=_ar_cat_pref_source_items,
        description='When multiple catalog sources exist for the same asset, choose a preferred source to resolve conflicts',
    )

    # Reference Manager (Phase 2)
    wm.sf_rm_items = CollectionProperty(type=_sf_registered_property_group_type(SF_RM_LibraryItem), description='Runtime list of linked libraries used by the Reference Manager')
    wm.sf_rm_active_index = IntProperty(default=0, description='Active linked library row')

    wm.sf_rm_candidates = CollectionProperty(type=_sf_registered_property_group_type(SF_RM_CandidateItem), description='Suggested relink candidates for the active linked library')
    wm.sf_rm_candidate_active_index = IntProperty(default=0, description='Active relink candidate row')

    wm.sf_rm_plan_items = CollectionProperty(type=_sf_registered_property_group_type(SF_RM_PlanItem), description='Planned Reference Manager actions that can be reviewed before applying')
    wm.sf_rm_plan_active_index = IntProperty(default=0, description='Active review-plan row')

    wm.sf_rm_review_show_score_detail = BoolProperty(name='Show score details', default=False, description='Show the detailed scoring breakdown for relink candidate ranking')

    wm.sf_rep_snapshot_json = StringProperty(name='Representation Snapshot JSON', default='', options={'HIDDEN'}, description='Session snapshot used by the Representation Toolkit to restore previous display and visibility states')
    wm.sf_assembly_snapshot_json = StringProperty(name='Assembly Snapshot JSON', default='', options={'HIDDEN'}, description='Session snapshot used by Assembly Guard to restore selection safety and proxy display states')
    wm.sf_assembly_controller_keywords = StringProperty(name='Assembly Controller Keywords', default='ctrl,ctl,control,rig,root,master,main,gimbal,handle,cam,camera', description='Comma-separated keywords used by Assembly Guard to guess which referenced objects should stay easy to select as controllers')
    wm.sf_project_guard_scene_state_json = StringProperty(name='Project Guard Scene State JSON', default='', options={'HIDDEN'}, description='Session snapshot used by Project Guard to store camera, frame range, render, and visibility state for shot-style recovery')
    wm.sf_shot_presets = CollectionProperty(type=_sf_registered_property_group_type(SF_ShotPresetItem), description='Runtime list of stored Smart File shot-state presets discovered in Blender text datablocks')
    wm.sf_shot_preset_active_index = IntProperty(default=0, description='Active Smart File shot-state preset row')
    wm.sf_shot_slots = CollectionProperty(type=_sf_registered_property_group_type(SF_ShotSlotItem), description='Runtime shot queue used by the Shot Queue Toolkit for per-shot camera and render batches')
    wm.sf_shot_active_index = IntProperty(default=0, description='Active shot queue row')


def _register_props():
    """Register direct WindowManager settings with same-event persistence."""
    global StringProperty, BoolProperty, IntProperty, EnumProperty, FloatProperty, FloatVectorProperty
    names = (
        'StringProperty', 'BoolProperty', 'IntProperty',
        'EnumProperty', 'FloatProperty', 'FloatVectorProperty',
    )
    originals = {name: globals()[name] for name in names}
    try:
        for name, factory in originals.items():
            globals()[name] = _sf_persisting_factory(factory)
        _register_props_impl()
    finally:
        for name, factory in originals.items():
            globals()[name] = factory




def _sf_register_minimal_workspace_props():
    """Register only lightweight N-panel settings if a full runtime property rebuild fails.

    This keeps the Smart File Sidebar visible and prevents recovery-mode panels from
    recursively trying to rebuild CollectionProperty definitions during draw.
    """
    wm = _SFPropertyOwnerProxy(bpy.types.WindowManager)
    if not hasattr(wm, 'sf_addon_settings'):
        wm.sf_addon_settings = PointerProperty(
            type=_sf_registered_property_group_type(SFS_PG_system_file_suite_preferences),
            description='Persistent Smart File N-panel settings stored in Blender config/Smart_File_Suite/Smart_File_Suite.json',
        )
    if not hasattr(wm, 'sf_workspace_page'):
        wm.sf_workspace_page = EnumProperty(
            name='Smart File Page',
            items=[
                ('HOME', 'Home', 'Show the Smart File home workspace.'),
                ('LINK', 'Link', 'Show link-oriented tools.'),
                ('APPEND', 'Append', 'Show append-oriented tools.'),
                ('IMPORT', 'Import', 'Show import-oriented tools.'),
                ('EXPORT', 'Export', 'Show export-oriented tools.'),
                ('PREVIEW', 'Preview', 'Show preview and inspection tools.'),
                ('HISTORY', 'History / Restore', 'Show history and restore tools.'),
                ('OTHER', 'Other', 'Show auxiliary tools and settings.'),
            ],
            default='HOME',
            description='Choose which Smart File category is shown in the N-panel.',
        )
    if not hasattr(wm, 'sf_filepath'):
        wm.sf_filepath = StringProperty(
            name='File',
            description='Current source .blend scene path used by Smart File.',
        )
    if not hasattr(wm, 'sf_session_goal'):
        wm.sf_session_goal = EnumProperty(
            name='Goal',
            items=[
                ('EXPLORE', 'Explore', ''),
                ('IMPORT', 'Import', ''),
                ('MAINTAIN', 'Maintain', ''),
                ('PUBLISH', 'Publish', ''),
                ('RECOVER', 'Recover', ''),
            ],
            default='IMPORT',
            description='Current Smart File session goal used by the launcher and category cards.',
        )
    # Runtime status fields used by the compact N-panel. They are cheap scalar
    # properties and safe even when collection-backed browsers are not ready yet.
    for attr, factory, kwargs in (
        ('sf_filter', StringProperty, {'name': 'Search', 'default': '', 'description': 'Filter text for Smart File lists.'}),
        ('sf_last_fix_summary', StringProperty, {'name': 'Last Fix Summary', 'default': '', 'options': {'HIDDEN'}}),
        ('sf_last_fix_details', StringProperty, {'name': 'Last Fix Details', 'default': '', 'options': {'HIDDEN'}}),
        ('sf_last_action_title', StringProperty, {'name': 'Last Action Title', 'default': '', 'options': {'HIDDEN'}}),
        ('sf_last_action_summary', StringProperty, {'name': 'Last Action Summary', 'default': '', 'options': {'HIDDEN'}}),
        ('sf_last_action_details', StringProperty, {'name': 'Last Action Details', 'default': '', 'options': {'HIDDEN'}}),
        ('sf_last_action_followup', StringProperty, {'name': 'Last Action Follow-up', 'default': '', 'options': {'HIDDEN'}}),
        ('sf_last_action_icon', StringProperty, {'name': 'Last Action Icon', 'default': 'CHECKMARK', 'options': {'HIDDEN'}}),
        ('sf_activity_log', StringProperty, {'name': 'Activity Log', 'default': '', 'options': {'HIDDEN'}}),
    ):
        if not hasattr(wm, attr):
            try:
                setattr(wm, attr, factory(**kwargs))
            except Exception:
                pass


def _unregister_props():
    """Remove only exact WindowManager descriptors acquired by this generation."""
    return _sf_unregister_owned_properties()


# -----------------------------------------------------------------------------
#  Class registration helpers
# -----------------------------------------------------------------------------

def _sf_rna_base_types():
    bases = []
    for name in (
        'Panel', 'Operator', 'Menu', 'UIList', 'PropertyGroup',
        'AddonPreferences', 'Header', 'FileHandler', 'AssetShelf',
    ):
        try:
            base = getattr(bpy.types, name, None)
        except Exception:
            base = None
        if isinstance(base, type):
            bases.append(base)
    return tuple(bases)


def _sf_lookup_registered_class(candidate):
    """Return an already registered RNA class without recursive RNA lookup.

    Blender 5.1 can crash inside recursive RNA subclass search during
    msgbus-driven hot loads.  This helper therefore uses only public bpy.types
    attributes. Missing classes are handled by bpy.utils.register_class() below.
    """
    identifiers = []

    def _add(value):
        value = str(value or '').strip()
        if value and value not in identifiers:
            identifiers.append(value)

    def _rna_identifier_from_bl_idname(value: str) -> str:
        value = str(value or '').strip()
        if '.' not in value:
            return ''
        prefix, suffix = value.split('.', 1)
        prefix = prefix.strip().upper()
        suffix = suffix.strip()
        if not prefix or not suffix:
            return ''
        return f"{prefix}_OT_{suffix}"

    if isinstance(candidate, type):
        _add(getattr(candidate, '__name__', ''))
        bl_idname = getattr(candidate, 'bl_idname', '')
        _add(bl_idname)
        _add(_rna_identifier_from_bl_idname(bl_idname))
        try:
            _add(getattr(getattr(candidate, 'bl_rna', None), 'identifier', ''))
        except Exception:
            pass
    else:
        value = str(candidate or '').strip()
        _add(value)
        _add(_rna_identifier_from_bl_idname(value))

    for identifier in identifiers:
        try:
            existing = getattr(bpy.types, identifier, None)
        except Exception:
            existing = None
        if isinstance(existing, type):
            return existing
    return None

def _sf_class_has_bl_rna(cls) -> bool:
    """Return True only when Blender has completed RNA registration for cls.

    During extension hot reloads Blender can leave a Python class object with the
    right name but without a valid bl_rna block.  CollectionProperty and
    PointerProperty reject that half-registered state, so class-name lookup alone
    is not enough.
    """
    try:
        if not isinstance(cls, type):
            return False
        rna = vars(cls).get('bl_rna')
        return bool(rna is not None and str(getattr(rna, 'identifier', '') or '').strip())
    except Exception:
        return False


def _sf_registered_class_is_ready(cls) -> bool:
    # Blender Extension RNA classes need not be exposed on bpy.types by their
    # Python name.  The exact class-owned RNA descriptor is authoritative.
    return _sf_class_has_bl_rna(cls)



def _sf_registered_property_group_type(cls):
    # Return a PropertyGroup class object accepted by Blender Pointer/CollectionProperty.
    if _sf_class_has_bl_rna(cls):
        return cls
    _sf_safe_register_class(cls)
    if _sf_class_has_bl_rna(cls):
        return cls
    raise RuntimeError(f"Smart File PropertyGroup RNA is not ready: {getattr(cls, '__name__', cls)!r}.")

def _sf_class_record(cls):
    for record in reversed(tuple(_SF_CLASS_RECORDS)):
        if record.get('class') is cls:
            return record
    return None


def _sf_record_class(cls, *, acquired):
    rna = vars(cls).get('bl_rna') if isinstance(cls, type) else None
    record = {
        'class': cls,
        'rna': rna,
        'identifier': str(getattr(rna, 'identifier', '') or ''),
        'acquired': bool(acquired),
        'token': _SF_CORE_OWNER_TOKEN,
        'generation': _SF_CORE_GENERATION,
    }
    _SF_CLASS_RECORDS.append(record)
    ledger = _sf_core_ledger()
    if isinstance(ledger, dict):
        ledger['classes'] = tuple(_SF_CLASS_RECORDS)
    return record


def _sf_class_records_exact():
    ledger = _sf_core_ledger()
    ledger_records = tuple(ledger.get('classes', ()) or ()) if isinstance(ledger, dict) else ()
    if len(ledger_records) != len(_SF_CLASS_RECORDS):
        return False
    if len(_SF_CLASS_RECORDS) != len(_SF_REGISTERED_CLASSES):
        return False
    for index, record in enumerate(tuple(_SF_CLASS_RECORDS)):
        cls = record.get('class')
        if ledger_records[index] is not record or cls is not _SF_REGISTERED_CLASSES[index]:
            return False
        if not isinstance(cls, type) or not _sf_class_has_bl_rna(cls):
            return False
        if vars(cls).get('bl_rna') is not record.get('rna'):
            return False
        if str(getattr(record.get('rna'), 'identifier', '') or '') != record.get('identifier'):
            return False
    return True


def _sf_safe_register_class(cls):
    """Register one known class and return whether this call acquired its RNA."""
    if not isinstance(cls, type):
        raise TypeError('Smart File class registration requires a Python type')
    if _sf_class_has_bl_rna(cls):
        return False
    instrument = globals().get('_jel_status_instrument_class_v2')
    if callable(instrument):
        instrument(cls)
    try:
        bpy.utils.register_class(cls)
    except Exception as ex:
        # Do not use bpy.types name lookup and do not unregister another class.
        # Only this exact class-owned RNA can make an already-registered result
        # acceptable.
        if _sf_class_has_bl_rna(cls):
            return False
        raise RuntimeError(
            f"Smart File could not acquire exact RNA for "
            f"{getattr(cls, '__name__', cls)!r}: {ex}"
        ) from ex
    if not _sf_class_has_bl_rna(cls):
        raise RuntimeError(f"Smart File could not register RNA for {getattr(cls, '__name__', cls)!r}.")
    return True


def _sf_ensure_property_group_classes_ready():
    order = globals().get('_SF_CLASS_REGISTER_ORDER', ())
    for pg_cls in order:
        _sf_safe_register_class(pg_cls)
        if not _sf_class_has_bl_rna(pg_cls):
            raise RuntimeError(f"Smart File PropertyGroup RNA is not ready: {getattr(pg_cls, '__name__', pg_cls)!r}.")


def _sf_safe_unregister_class(cls):
    """Unregister only an exact class acquired by this core generation."""
    record = _sf_class_record(cls)
    if not isinstance(record, dict) or not bool(record.get('acquired')):
        return True
    if record.get('token') is not _SF_CORE_OWNER_TOKEN or record.get('generation') != _SF_CORE_GENERATION:
        return False
    if vars(cls).get('bl_rna') is not record.get('rna'):
        return False
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        return False
    if _sf_class_has_bl_rna(cls):
        return False
    record['acquired'] = False
    return True


_LEGACY_SMARTTOOLS_RNA_NAMES = {
    'SF_PT_workspace_command_workspace_launcher',
    'SF_PT_properties_workspace',
    'SF_PT_smarttools_workspace',
    'SF_PT_smart_tools_workspace',
    'SF_PT_smart_file_properties',
    'SF_PT_properties_launcher',
}


def _sf_unregister_legacy_smarttools_rna_classes():
    # Legacy name-based bpy.types scans could unregister foreign classes. Stale
    # generations are recovered only through their exact owner ledger.
    return 0


def _sf_reregister_runtime_props():
    """Complete the exact WindowManager property transaction without replacement."""
    _sf_ensure_property_group_classes_ready()
    _register_props()
    required = (
        'sf_addon_settings',
        'sf_workspace_page',
        'sf_items',
    )
    missing = tuple(
        name for name in required
        if _sf_property_descriptor(bpy.types.WindowManager, name) is _SF_PROPERTY_MISSING
    )
    if missing:
        raise RuntimeError(
            'Smart File runtime property transaction is incomplete: ' + ', '.join(missing)
        )
    if not _sf_property_records_exact():
        raise RuntimeError('Smart File runtime property exact-identity validation failed')


def _sf_seed_dynamic_enum_defaults():
    defaults = (
        ('sf_ar_root_filter', 'ALL'),
        ('sf_ar_cat_category', 'ALL'),
        ('sf_ar_cat_pref_source', 'AUTO'),
    )
    try:
        window_managers = list(getattr(bpy.data, 'window_managers', []) or [])
    except Exception:
        window_managers = []
    for wm in window_managers:
        for attr, value in defaults:
            try:
                current = str(getattr(wm, attr, '') or '')
                if not current:
                    setattr(wm, attr, value)
            except Exception:
                pass



def _sf_apply_runtime_ui_metadata():
    """Apply late UI metadata before Blender registers the classes."""
    desc_map = {
        SF_OT_source_browser_open_folder_2: "Choose a source .blend file first so Launcher, Goal Home, Source Check, and the browser can guide the next step from a real file",
        SF_OT_source_browser_import_2: "Open the detailed browser view for picking datablocks and importing them with dependency, naming, organization, and placement options",
        SF_OT_source_browser_add_current_file_to_favorites: "Add the currently selected source file to Favorites so it stays one click away from the header and launcher",
        SF_OT_source_browser_select_all: "Change the selection state for the datablocks listed in the detailed browser",
        SF_OT_asset_reader_open: "Browse library roots or catalog data, inspect dependencies, check versions, and import checked assets from an advanced library view",
        SF_OT_asset_library_diagnostics: "Open an advanced root-check tool that scans library roots for missing folders, duplicates, orphan blends, and other setup issues",
        SF_OT_asset_library_repair_roots: "Open an advanced root-repair tool that normalizes, deduplicates, disables missing roots, and can rebuild the library index",
        SF_OT_asset_library_generate_catalog_draft: "Draft catalog.json entries from discovered .blend files before writing them to disk",
        SF_OT_catalog_merge_review_merge_preview: "Compare discovered assets against existing catalog.json files and review merge actions before applying them",
        SF_OT_catalog_merge_build_merge_review: "Build a row-by-row merge selection list so you can enable only the catalog actions you want",
        SF_OT_catalog_merge_apply_selected_merge: "Apply the currently enabled merge selection rows to the target catalog files",
        SF_OT_catalog_merge_apply_filtered_merge: "Create a draft that merges only the blends you explicitly selected instead of processing everything",
        SF_OT_catalog_merge_apply_full_merge: "Merge generated draft entries into catalog.json files, with optional backup and preview text output",
        SF_OT_reference_manager_run_library_workflow: "Run the recommended library maintenance flow in sequence so diagnostics, repair, draft, and merge steps stay consistent",
        SF_OT_reference_manager_open: "Inspect linked libraries in the current file, check for updates or missing paths, and build a relink or reload plan",
        SF_OT_external_assets_return_to_parent_scene: "Return from a linked-library editing roundtrip back to the stored parent scene without hunting for the original file manually",
        SF_OT_publisher_publish_asset: "Publish the active collection or selected objects as a reusable asset package with preview, metadata, and catalog support",
        SF_OT_project_guard_open: "Open a compact board for missing references, scene-state snapshots, and cooperative project locks before relink, publish, or handoff work",
        SF_OT_container_deck_open: "Open a compact pipeline container board that compares the current container, latest matching revision, alternate representations, and nearby revision history",
        SF_OT_container_deck_load_latest: "Load the latest matching revision of the current container representation using the standard container loader",
        SF_OT_container_deck_load_revision: "Pick and load any related container revision from the same family/name group, including older revisions",
        SF_OT_container_deck_switch_representation: "Switch the current container to the newest available revision of another representation with the same family and name",
        SF_OT_context_roots_open: "Open a compact board for named project roots, handoff manifests, and suffix-aware relink helpers",
        SF_OT_context_roots_preview_manifest: "Read a saved Context Manifest and preview how many tokenized references can be resolved on this workstation",
        SF_OT_context_roots_apply_manifest: "Read a saved Context Manifest and relink matching current-file references using Context Roots and optional manifest-embedded roots",
        SF_OT_root_watch_open: "Open a watch-folder style board that snapshots enabled roots and compares later drift before relink or handoff work",
        SF_OT_project_guard_store_scene_state: "Store camera, render, frame range, and visibility state so temporary review or troubleshooting changes can be restored later",
        SF_OT_project_guard_restore_scene_state: "Restore the last stored or imported scene-state snapshot for the current shot or layout",
        SF_OT_project_guard_export_scene_state: "Write the current scene-state snapshot to JSON for handoff or later reuse",
        SF_OT_project_guard_import_scene_state: "Read a scene-state snapshot JSON file and optionally apply it immediately",
        SF_OT_project_guard_create_cooperative_lock: "Create lightweight cooperative check-out locks for the current file or linked libraries",
        SF_OT_project_guard_release_cooperative_lock: "Release cooperative check-out locks created by Smart File",
        SF_OT_project_guard_cleanup_stale_locks: "Remove only stale cooperative locks while keeping active locks owned by others intact",
        SF_OT_project_guard_export_report: "Write a compact report about missing externals, absolute paths, scene-state readiness, and cooperative lock status",
        SF_OT_project_guard_handoff_audit: "Write one integrated handoff audit that combines external health, relink ambiguity, Context Root env checks, override health, and lock status",
        SF_OT_shot_state_open: "Open a compact board for reusable shot-state presets stored inside the current Blender file",
        SF_OT_shot_state_save_current_as_preset: "Capture the current camera, frame range, render settings, markers, and visibility state into a reusable preset stored in Blender texts",
        SF_OT_shot_state_apply_selected_preset: "Apply the selected shot-state preset and store the current scene state first for safer rollback",
        SF_OT_shot_state_remove_selected_preset: "Remove the selected internal shot-state preset from Blender texts",
        SF_OT_shot_state_export_book: "Write every stored shot-state preset into one portable JSON book for handoff or backup",
        SF_OT_shot_state_import_book: "Read a JSON shot-state book and rebuild the internal presets in the current Blender file",
        SF_OT_shot_queue_open: "Open a compact shot queue board for storing, applying, importing, exporting, and batch-running per-shot camera states",
        SF_OT_shot_queue_store_current: "Capture the current camera, frame range, render settings, and visibility state into a reusable shot queue row",
        SF_OT_shot_queue_capture_from_camera_markers: "Build shot queue rows from camera timeline markers so marker-driven scenes can be batch-run quickly",
        SF_OT_shot_queue_apply_active: "Apply the active shot queue row back to the current scene",
        SF_OT_shot_queue_remove_active: "Remove the active shot queue row without deleting cameras or scenes",
        SF_OT_shot_queue_move_active: "Move the active shot queue row up or down to control batch order",
        SF_OT_shot_queue_export_queue: "Write the current shot queue to a JSON file for handoff or reuse",
        SF_OT_shot_queue_import_queue: "Read a Smart File shot queue JSON file and rebuild the current queue",
        SF_OT_shot_queue_preflight: "Scan the selected queue scope for missing scenes, missing cameras, duplicate outputs, and dependency issues before rendering",
        SF_OT_shot_queue_run_queue: "Run the stored shot queue as apply-only, still-image, or animation batch work",
        SF_OT_asset_preview_batch_preview: "Generate preview images for many library assets at once and optionally update their catalog entries",
        SF_OT_reference_manager_apply_recommended_setup: "Apply a safer default browser setup for the chosen workflow lane before you continue into import, maintenance, or publishing",
        SF_OT_reference_manager_export_activity_log: "Write the Smart File activity timeline to a Blender text datablock for troubleshooting or handoff notes",
        SF_OT_reference_manager_clear_activity_log: "Clear the Smart File activity timeline captured in this Blender session",
        SF_OT_workspace_profile_clear_filter: "Reset workspace profile search text and filter mode so every profile becomes visible again",
        SF_OT_workspace_command_launcher: "Open the lightweight start screen with the main daily actions, source status, safe fixes, recent files, and favorites so newer users can start from a clear home view",
        SF_OT_history_open: "Open the integrated history popup and the fully migrated Smart File history controls so restore points, autosaves, and safety actions stay available inside the Smart File N-panel without using the sidebar",
        SF_OT_workspace_command_goal_home: "Open a goal-focused home view that keeps blockers, roadmap, matching profiles, and the next action centered on one workflow goal instead of showing every advanced tool at once",
        SF_OT_reference_manager_source_check: "Open a focused Source Check view for the current .blend so you can review status, safe fixes, reports, and the next action without opening multiple dense comparison boards",
        SF_OT_workspace_command_fix_preview: "Preview Smart Fix changes first so you can see what would be cleaned, added, or reordered before running Smart Fix All",
        SF_OT_workspace_command_fix_all: "Run a safe Smart Fix pass that cleans roots and improves source coverage when there is something meaningful to repair",
        SF_OT_reference_manager_run_repair_pack: "Run a bundled repair pack that performs the relevant maintenance steps for roots, coverage, recovery review, or publish preparation",
        SF_OT_reference_manager_workspace_report: "Write the everyday workspace report that summarizes current source status, root coverage, profile signals, and the next recommended actions in one easy handoff-style text block",
        SF_OT_workspace_command_handoff_report: "Write a focused handoff report for the current source when you need to pass work to someone else",
        SF_OT_workspace_command_release_report: "Write the release report used for final readiness checks after the current source is sufficiently prepared",
    }
    for cls, desc in desc_map.items():
        current = str(getattr(cls, "bl_description", "") or "").strip()
        if current:
            continue
        setattr(cls, "bl_description", desc)

# PropertyGroup classes must be registered before any class that references
# them through PointerProperty/CollectionProperty, especially the N-panel settings PropertyGroup.
_SF_CLASS_REGISTER_ORDER = (
    SF_PathItem,
    SF_Item,
    SF_LibraryRoot,
    SF_ContextRoot,
    SF_CM_ReviewItem,
    SF_CM_OverridePreset,
    SF_CM_OverrideRoute,
    SF_WorkspaceProfile,
    SFS_PG_system_file_suite_preferences,
    SF_AR_Item,
    SF_AR_CatalogAsset,
    SF_AR_CatalogVersion,
    SF_RM_LibraryItem,
    SF_RM_CandidateItem,
    SF_RM_PlanItem,
    SF_ShotPresetItem,
    SF_ShotSlotItem,
)

# Actual registration order used in the current Blender session.
# This is rebuilt on every register() call and lets unregister() mirror the
# exact reverse order even when some classes are registered ahead of their
# original position for dependency reasons.
_SF_REGISTERED_CLASSES = []
_SF_REGISTERED_KEYMAPS = []
_SF_EMPTY_UI_KEYMAPS_CLEANED = False
_SF_EMPTY_UI_KEYMAPS_SESSION_KEY = '_SMART_FILE_SUITE_EMPTY_UI_KEYMAPS_CLEANED'



def _sf_empty_ui_keymaps_already_cleaned() -> bool:
    return True



def _sf_mark_empty_ui_keymaps_cleaned() -> None:
    return None



def _sf_remove_keymap_direct(km) -> bool:
    del km
    return False


def _sf_find_keymap(keymaps, name: str, space_type: str = 'EMPTY', region_type: str = 'WINDOW'):
    del keymaps, name, space_type, region_type
    return None


def _sf_cleanup_empty_user_interface_keymaps_once() -> int:
    return 0


def _sf_clear_registered_keymaps():
    global _SF_REGISTERED_KEYMAPS
    _SF_REGISTERED_KEYMAPS = []


def _sf_prune_empty_addon_keymaps(allowed_names=('User Interface',)):
    del allowed_names
    return 0



def _sf_is_property_group_class(cls) -> bool:
    base = getattr(bpy.types, 'PropertyGroup', None)
    try:
        return bool(isinstance(cls, type) and base is not None and issubclass(cls, base))
    except Exception:
        return False



def _sf_partition_registered_classes(class_items):
    regular = []
    property_groups = []
    for cls in class_items or ():
        if _sf_is_property_group_class(cls):
            property_groups.append(cls)
        else:
            regular.append(cls)
    return regular, property_groups



def _sf_unregister_class_sequence(class_items):
    regular, property_groups = _sf_partition_registered_classes(class_items)
    for cls in reversed(regular):
        _sf_safe_unregister_class(cls)
    return property_groups



def _sf_cleanup_registered_state(class_items, *, release_owner=True):
    global _SF_REGISTERED_CLASSES, _SF_CLASS_RECORDS, _SF_CORE_ACTIVE
    ok = True
    try:
        clear_lane_cache = globals().get('_sf_clear_lane_tool_sections_cache')
        if callable(clear_lane_cache):
            clear_lane_cache()
    except Exception:
        ok = False
    property_groups = _sf_unregister_class_sequence(class_items)
    try:
        release_history = globals().get('_sf_history_release_owned')
        if callable(release_history):
            if release_history(
                remove_ledger=True,
                include_runtime=True,
                runtime_save_pending=False,
                runtime_reason='registration_rollback',
            ) is False:
                ok = False
    except Exception:
        ok = False
    try:
        if _unregister_props() is False:
            ok = False
    except Exception:
        ok = False
    for cls in reversed(property_groups):
        if _sf_safe_unregister_class(cls) is False:
            ok = False
    _SF_REGISTERED_CLASSES = []
    _SF_CLASS_RECORDS = []
    _SF_CORE_ACTIVE = False
    ledger = _sf_core_ledger()
    if isinstance(ledger, dict):
        ledger['classes'] = ()
        ledger['properties'] = ()
        ledger['active'] = False
    if release_owner:
        _sf_release_core_owner()
    return bool(ok)


def _sf_cleanup_core_generation(token=None, generation=None):
    if token is not None and token is not _SF_CORE_OWNER_TOKEN:
        return False
    if generation is not None and str(generation) != _SF_CORE_GENERATION:
        return False
    ok = _sf_cleanup_registered_state(list(_SF_REGISTERED_CLASSES), release_owner=False)
    try:
        settings_module = _sf_integrated_import_module('settings')
        if settings_module is not None and hasattr(settings_module, 'unregister'):
            if settings_module.unregister() is False:
                ok = False
    except Exception:
        ok = False
    _sf_release_core_owner()
    return bool(ok)



_SF_LAST_REGISTRATION_ERRORS = []


def _sf_registration_error_text(cls, exc) -> str:
    try:
        name = str(getattr(cls, '__name__', '') or getattr(cls, 'bl_idname', '') or cls)
    except Exception:
        name = str(cls)
    return f'{name}: {exc}'


def _sf_register_class_recorded(cls, registered_classes: list, *, critical: bool = False) -> bool:
    """Acquire and record one known RNA class by exact Python identity."""
    global _SF_REGISTERED_CLASSES, _SF_LAST_REGISTRATION_ERRORS
    if not isinstance(cls, type):
        return False
    if cls in registered_classes:
        return True
    try:
        already_owned = _sf_class_has_bl_rna(cls)
        acquired_now = _sf_safe_register_class(cls)
        if not _sf_class_has_bl_rna(cls):
            raise RuntimeError('class-owned RNA validation failed')
        # The exact class object is part of this package's known class sequence.
        # If it was already RNA-ready in the same module generation, treat it as
        # recoverable self-owned state and include it in reverse rollback.
        _sf_record_class(cls, acquired=bool(acquired_now or already_owned))
        registered_classes.append(cls)
        _SF_REGISTERED_CLASSES = list(registered_classes)
        return True
    except Exception as exc:
        try:
            _SF_LAST_REGISTRATION_ERRORS.append(_sf_registration_error_text(cls, exc))
        except Exception:
            pass
        if critical:
            raise
        return False



def _sf_apply_group_panel_header_options() -> None:
    """Keep Smart File child Panels on Blender's native visible-header contract."""
    try:
        panel_base = getattr(bpy.types, 'Panel', None)
    except Exception:
        panel_base = None
    if not isinstance(panel_base, type):
        return
    for cls in tuple(classes or ()):  # classes is already filtered above.
        try:
            if not isinstance(cls, type) or not issubclass(cls, panel_base):
                continue
            if str(getattr(cls, 'bl_category', '') or '') != 'Smart File':
                continue
            if not str(getattr(cls, 'bl_parent_id', '') or ''):
                continue
            opts = set(getattr(cls, 'bl_options', set()) or set())
            opts.discard('HIDE_HEADER')
            cls.bl_options = opts
        except Exception:
            pass

def _sf_critical_npanel_classes() -> tuple:
    """Classes required for every functional category to remain visible."""
    names = (
        'SF_OT_system_rebuild_n_panel_ui',
        'SF_OT_refresh_compact_launcher_context',
        'SF_OT_system_toggle_always_on_setting',
        'SF_OT_system_toggle_ui_section',
        'SF_OT_system_open_help',
        'SF_OT_source_browser_open_folder_2',
        'SF_OT_source_browser_import',
        'SF_OT_reference_manager_source_check',
        'SF_OT_workspace_command_action_palette',
        'SF_OT_workspace_command_goal_home',
        'SF_OT_workspace_command_run_top_recommendation',
        'SF_OT_workspace_command_fix_preview',
        'SF_OT_workspace_command_fix_all',
        'SF_OT_workspace_command_category_tools',
        'SF_OT_workspace_command_open_category_hub',
        'SF_OT_workspace_command_show_page',
        'SF_OT_history_open',
        'SF_OT_workspace_command_launcher',
        'SF_MT_reference_manager_reference_manager_recent_sources',
        'SF_MT_reference_manager_reference_manager_favorite_sources',
        'SF_MT_reference_manager_reference_manager',
        'SF_PT_reference_manager_reference_manager_workspace',
    )
    result = []
    for name in names:
        cls = globals().get(name)
        if isinstance(cls, type):
            result.append(cls)
    return tuple(result)



def _sf_core_resources_exact():
    ledger = _sf_core_ledger()
    return bool(
        isinstance(ledger, dict)
        and ledger.get('token') is _SF_CORE_OWNER_TOKEN
        and ledger.get('generation') == _SF_CORE_GENERATION
        and bool(ledger.get('active'))
        and _SF_CORE_ACTIVE
        and _sf_class_records_exact()
        and _sf_property_records_exact()
    )


def _sf_revalidate_active_core(context=None):
    """Idempotent register path and missing-runtime repair for this generation."""
    if not _sf_core_resources_exact():
        return False
    settings_module = _sf_integrated_import_module('settings')
    register_settings = getattr(settings_module, 'register', None) if settings_module is not None else None
    if not callable(register_settings) or not bool(register_settings(context, apply_saved=False)):
        return False
    if not bool(_sf_history_register()):
        return False
    settings_status_fn = getattr(settings_module, 'get_registration_status', None)
    settings_status = settings_status_fn(context) if callable(settings_status_fn) else {}
    history_status = _sf_history_status(context)
    if not bool(settings_status.get('registered')) or not bool(history_status.get('registered')):
        return False
    if history_status.get('requested_enabled'):
        return bool(
            history_status.get('phase') == 'ACTIVE'
            and history_status.get('watching')
            and history_status.get('handlers_ok')
            and history_status.get('timer_ok')
        )
    return bool(
        not history_status.get('watching')
        and not history_status.get('timer_registered')
        and int(history_status.get('handler_count', 0) or 0) == 0
    )


def _sf_register_impl():
    import time as _sf_register_time
    global _SF_REGISTERED_CLASSES, _SF_CLASS_RECORDS, _SF_PROPERTY_RECORDS, _SF_CORE_ACTIVE, _RM_AUTO_SCHEDULED, _RM_TIMER_ACTIVE, _SF_LAST_REGISTRATION_ERRORS, _SF_REGISTER_PROFILE
    _SF_LAST_REGISTRATION_ERRORS = []
    _SF_REGISTER_PROFILE = {}
    _sf_phase_started = _sf_register_time.perf_counter()

    def _sf_mark_phase(name):
        nonlocal _sf_phase_started
        now = _sf_register_time.perf_counter()
        _SF_REGISTER_PROFILE[str(name)] = max(0.0, now - _sf_phase_started)
        _sf_phase_started = now

    _sf_apply_ui_text_polish()
    _sf_mark_phase('ui_text_polish')

    if _sf_revalidate_active_core(getattr(bpy, 'context', None)):
        _SF_LAST_REGISTRATION_ERRORS.clear()
        return True

    try:
        _sf_unregister_legacy_smarttools_rna_classes()
    except Exception:
        pass

    # GUI and background registration use one identical RNA/lifecycle path.
    # Optional visual assets are still prepared explicitly here rather than from
    # Panel.draw, so redraw never performs file I/O or class mutation.
    _sf_apply_runtime_ui_metadata()
    try:
        _sf_restore_registration_compatible_methods(classes)
    except Exception:
        pass
    try:
        _sf_apply_group_panel_header_options()
    except Exception:
        pass
    try:
        _sf_enable_standard_npanel_popups(classes)
    except Exception:
        pass
    try:
        from .language_extra import EXTRA_TRANSLATIONS as _sf_extra_translations, has_leftover_english as _sf_has_leftover
        _sf_ja_table = translation_dict.setdefault('ja_JP', {})
        _sf_ja_table.update(_sf_extra_translations)
        # Operator buttons look their label up in the "Operator" context.
        for _sf_key, _sf_value in tuple(_sf_ja_table.items()):
            if _sf_key[0] == '*':
                if _sf_key in _sf_extra_translations:
                    _sf_ja_table[('Operator', _sf_key[1])] = _sf_value
                else:
                    _sf_ja_table.setdefault(('Operator', _sf_key[1]), _sf_value)
        for _sf_key in [k for k, v in _sf_ja_table.items() if _sf_has_leftover(v)]:
            del _sf_ja_table[_sf_key]
    except Exception:
        pass
    try:
        bpy.app.translations.register(__name__, translation_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        try:
            bpy.app.translations.register(__name__, translation_dict)
        except Exception:
            pass
    except Exception:
        pass
    try:
        _sfsmart_loader = globals().get('_sfsmart_load_icons')
        if callable(_sfsmart_loader):
            _sfsmart_loader(force=True)
        _brand_prime = globals().get('_sf_prime_brand_icon')
        if callable(_brand_prime):
            _brand_prime(getattr(bpy, 'context', None))
    except Exception as exc:
        _SF_LAST_REGISTRATION_ERRORS.append(f'preview_prepare: {exc}')

    # Remove only the two known Smart File menu callbacks. No package-wide
    # or process-global registration scan is performed.
    try:
        bpy.types.TOPBAR_MT_file.remove(menu_func_append)
    except Exception:
        pass
    try:
        bpy.types.VIEW3D_MT_editor_menus.remove(view3d_header_menu_func)
    except Exception:
        pass
    _sf_mark_phase('visible_ui_prepare')
    # Reference Manager resources are cleaned through their generation ledger
    # when its current owner is acquired below. Never scan or remove callbacks by
    # function name from the process-global handler/timer registries.

    # Acquire one generation owner before touching any RNA. Existing foreign
    # descriptors/classes are never replaced; a previous Smart File generation
    # can be cleaned only through its exact ledger callback.
    _sf_acquire_core_owner()
    _sf_mark_phase('core_owner_acquire')

    _SF_CLASS_RECORDS = []
    _SF_PROPERTY_RECORDS = []
    registered_classes = []
    _SF_REGISTERED_CLASSES = registered_classes
    _SF_CORE_ACTIVE = False
    ledger = _sf_core_ledger()
    if isinstance(ledger, dict):
        ledger['classes'] = ()
        ledger['properties'] = ()
        ledger['active'] = False

    # 1) Register core PropertyGroups in dependency order.  The History owner
    #    acquires its three dependency PropertyGroups immediately before the
    #    canonical Smart File preferences class is registered.
    for cls in _SF_CLASS_REGISTER_ORDER:
        if cls is SFS_PG_system_file_suite_preferences:
            prepare_history = globals().get('_sf_history_prepare_dependencies')
            if not callable(prepare_history) or prepare_history() is not True:
                status_fn = globals().get('_sf_history_status')
                status = status_fn(getattr(bpy, 'context', None)) if callable(status_fn) else {}
                raise RuntimeError(
                    status.get('last_runtime_error')
                    or 'History PropertyGroup dependency transaction failed'
                )
        _sf_register_class_recorded(cls, registered_classes, critical=True)
    _sf_mark_phase('dependency_propertygroups')

    # 2) Minimal N-panel state before Panel RNA registration.  The canonical
    #    settings PointerProperty is mandatory; a partial fallback is not a
    #    successful add-on registration.
    _sf_register_minimal_workspace_props()
    if not hasattr(bpy.types.WindowManager, 'sf_addon_settings'):
        raise RuntimeError('WindowManager.sf_addon_settings was not registered')
    _sf_mark_phase('minimal_runtime_properties')

    # 3) Core visible UI.  These are critical: without them Blender cannot show
    #    the Smart File N-panel and category controls correctly.
    for cls in _sf_critical_npanel_classes():
        _sf_register_class_recorded(cls, registered_classes, critical=True)
    _sf_mark_phase('critical_npanel_rna')

    # 4) Register all remaining public classes.  A partial class surface would
    #    violate the Extension contract, so failures roll back the transaction.
    for cls in classes:
        if cls in registered_classes:
            continue
        _sf_register_class_recorded(cls, registered_classes, critical=True)
    _sf_mark_phase('remaining_public_rna')

    # 5) Full runtime properties are mandatory.  Do not report the Extension as
    # loaded with only a recovery/fallback subset.
    _sf_reregister_runtime_props()
    _sf_mark_phase('full_runtime_properties')

    try:
        _sf_seed_dynamic_enum_defaults()
    except Exception as exc:
        _SF_LAST_REGISTRATION_ERRORS.append(f'_sf_seed_dynamic_enum_defaults: {exc}')
    _sf_mark_phase('dynamic_enum_seed')

    # Canonical settings service is the sole settings owner and must be exact
    # before History classes/pointers/runtime can become ACTIVE.
    _sf_settings = None
    settings_ok = False
    try:
        _sf_settings = _sf_integrated_import_module('settings')
        register_settings = getattr(_sf_settings, 'register', None) if _sf_settings is not None else None
        settings_ok = bool(callable(register_settings) and register_settings(
            getattr(bpy, 'context', None), apply_saved=True
        ))
        status_fn = getattr(_sf_settings, 'get_registration_status', None) if _sf_settings is not None else None
        settings_status = status_fn(getattr(bpy, 'context', None)) if callable(status_fn) else {}
        if not settings_ok or not settings_status.get('registered'):
            raise RuntimeError(
                settings_status.get('last_error')
                or 'canonical settings owner exact registration failed'
            )
    except Exception as exc:
        settings_ok = False
        _SF_LAST_REGISTRATION_ERRORS.append(f'settings.register: {exc}')
        raise RuntimeError(f'Canonical settings registration failed: {exc}') from exc
    _sf_mark_phase('settings_owner')

    history_ok = False
    try:
        # Always create the sole History owner; it repairs a failed settings owner itself.
        history_ok = bool(_sf_history_register())
        if not history_ok:
            status = _sf_history_status(getattr(bpy, 'context', None))
            reason = str(
                status.get('last_runtime_error')
                or status.get('last_save_error')
                or 'History lifecycle registration returned False'
            )
            _SF_LAST_REGISTRATION_ERRORS.append(f'_sf_history_register: {reason}')
            raise RuntimeError(reason)
    except Exception as exc:
        _SF_LAST_REGISTRATION_ERRORS.append(f'_sf_history_register: {exc}')
        raise RuntimeError(f'History lifecycle registration failed: {exc}') from exc
    _sf_mark_phase('history_autosave_owner')

    try:
        sync_builtin = globals().get('_sf_sync_builtin_always_on_runtime')
        if callable(sync_builtin):
            sync_builtin(getattr(bpy, 'context', None))
    except Exception as exc:
        _SF_LAST_REGISTRATION_ERRORS.append(f'_sf_sync_builtin_always_on_runtime_after_register: {exc}')
    _sf_mark_phase('optional_enabled_runtimes')

    # Build the complete immutable N-panel tool catalog once, outside every
    # Panel.draw boundary. A failure is non-fatal because the draw path can
    # construct the same full body transiently without mutating runtime state.
    try:
        prime_lane_cache = globals().get('_sf_prime_lane_tool_sections_cache')
        if callable(prime_lane_cache):
            prime_lane_cache(getattr(bpy, 'context', None))
    except Exception as exc:
        _SF_LAST_REGISTRATION_ERRORS.append(f'_sf_prime_lane_tool_sections_cache: {exc}')
    _sf_mark_phase('npanel_catalog_prime')

    _SF_REGISTERED_CLASSES = list(registered_classes)

    # Smart File UI is intentionally centralized in its native N-panel roots.
    # Reference Manager runtime synchronization is owned by the optional-runtime
    # pass above and is never duplicated here.
    settings_status = _sf_settings.get_registration_status(getattr(bpy, 'context', None))
    history_status = _sf_history_status(getattr(bpy, 'context', None))
    if not settings_status.get('registered'):
        raise RuntimeError(settings_status.get('last_error') or 'settings exact validation failed')
    if not history_status.get('registered'):
        raise RuntimeError(
            history_status.get('last_runtime_error')
            or history_status.get('last_save_error')
            or 'History exact validation failed'
        )
    if history_status.get('requested_enabled'):
        if not (
            history_status.get('phase') == 'ACTIVE'
            and history_status.get('watching')
            and history_status.get('handlers_ok')
            and history_status.get('timer_ok')
        ):
            raise RuntimeError('History autosave was requested but is not ACTIVE')
    else:
        if history_status.get('watching') or history_status.get('timer_registered') or int(history_status.get('handler_count', 0) or 0):
            raise RuntimeError('History autosave is OFF but runtime resources remain')

    # Temporary registration errors are not session diagnostics after the full
    # exact transaction succeeds.
    if not _sf_property_records_exact() or not _sf_class_records_exact():
        raise RuntimeError('Smart File core exact ownership validation failed')
    _SF_CORE_ACTIVE = True
    ledger = _sf_core_ledger()
    if isinstance(ledger, dict):
        ledger['active'] = True
        ledger['classes'] = tuple(_SF_CLASS_RECORDS)
        ledger['properties'] = tuple(_SF_PROPERTY_RECORDS)
    _SF_LAST_REGISTRATION_ERRORS.clear()
    _sf_mark_phase('exact_postconditions')
    return True


def register():
    """Register the core transaction without leaking failures to Blender.

    Internal helpers deliberately raise to abort a partial transaction.  This
    public boundary catches those failures, reverses only receipts owned by the
    current generation, and returns ``False`` so the package root can enter its
    bounded degraded-repair path.  A failed attempt is never reported ACTIVE.
    """
    import time as _sf_register_time
    global _SF_REGISTERED_CLASSES, _SF_REGISTER_PROFILE, _SF_CORE_ACTIVE
    global _SF_LAST_REGISTRATION_ERRORS
    _sf_total_started = _sf_register_time.perf_counter()
    try:
        return bool(_sf_register_impl())
    except Exception as exc:
        error_text = f'core.register: {type(exc).__name__}: {exc}'
        if error_text not in _SF_LAST_REGISTRATION_ERRORS:
            _SF_LAST_REGISTRATION_ERRORS.append(error_text)
        _SF_CORE_ACTIVE = False
        try:
            _sf_cleanup_registered_state(list(_SF_REGISTERED_CLASSES))
        except Exception as cleanup_exc:
            cleanup_text = f'core.rollback: {type(cleanup_exc).__name__}: {cleanup_exc}'
            if cleanup_text not in _SF_LAST_REGISTRATION_ERRORS:
                _SF_LAST_REGISTRATION_ERRORS.append(cleanup_text)
        try:
            settings_module = _sf_integrated_import_module('settings')
            if settings_module is not None and hasattr(settings_module, 'unregister'):
                settings_module.unregister()
        except Exception as settings_exc:
            settings_text = f'settings.rollback: {type(settings_exc).__name__}: {settings_exc}'
            if settings_text not in _SF_LAST_REGISTRATION_ERRORS:
                _SF_LAST_REGISTRATION_ERRORS.append(settings_text)
        return False
    finally:
        profile = dict(globals().get('_SF_REGISTER_PROFILE') or {})
        profile['total'] = max(0.0, _sf_register_time.perf_counter() - _sf_total_started)
        _SF_REGISTER_PROFILE = profile


def unregister():
    global _SF_REGISTERED_CLASSES, _RM_AUTO_SCHEDULED, _RM_TIMER_ACTIVE

    try:
        clear_lane_cache = globals().get('_sf_clear_lane_tool_sections_cache')
        if callable(clear_lane_cache):
            clear_lane_cache()
    except Exception:
        pass
    try:
        clear_undo_diagnostic = globals().get('_sf_undo_diagnostic_clear_cache')
        if callable(clear_undo_diagnostic):
            clear_undo_diagnostic()
    except Exception:
        pass

    try:
        bpy.types.TOPBAR_MT_file.remove(menu_func_append)
    except Exception:
        pass
    try:
        bpy.types.VIEW3D_MT_editor_menus.remove(view3d_header_menu_func)
    except Exception:
        pass


    # Reference Manager exact-generation teardown.
    try:
        cleanup_reference = globals().get('_rm_cleanup_generation')
        if callable(cleanup_reference):
            cleanup_reference()
    except Exception:
        pass
    _RM_AUTO_SCHEDULED = False
    _RM_TIMER_ACTIVE = False

    # The final dirty boundary must run while Scene/Window/settings context is
    # still available. It performs exactly one synchronous transaction and
    # retains pending state on failure.
    try:
        if _sf_history_pre_unregister() is False:
            _SF_LAST_REGISTRATION_ERRORS.append(
                'History boundary/runtime shutdown failed; pending dirty state retained in runtime diagnostics'
            )
    except Exception as exc:
        _SF_LAST_REGISTRATION_ERRORS.append(f'_sf_history_pre_unregister: {exc}')

    # Teardown only a previously loaded explicit proxy-cleanup generation.
    try:
        _scene_cleanup_name = f"{__package__}.scene_proxy_cleanup"
        _sfs_scene_proxy_cleanup = sys.modules.get(_scene_cleanup_name)
        _scene_cleanup_unregister = getattr(_sfs_scene_proxy_cleanup, 'unregister', None) if _sfs_scene_proxy_cleanup is not None else None
        if callable(_scene_cleanup_unregister):
            _scene_cleanup_unregister()
    except Exception:
        pass

    try:
        _sf_settings = _sf_integrated_import_module('settings')
        if _sf_settings is not None and hasattr(_sf_settings, 'unregister'):
            _sf_settings.unregister()
    except Exception:
        pass

    unreg_classes = list(_SF_REGISTERED_CLASSES) if _SF_REGISTERED_CLASSES else list(classes)
    _sf_cleanup_registered_state(unreg_classes)


    try:
        _sfsmart_unload_icons()
    except Exception:
        pass

    # cleanup preview icons
    global _PREVIEW_COLLECTION
    # Keep preview collections alive for the Blender session. The N-panel may
    # still receive one final UI event after unregister/reload, and freeing the
    # collection can leave icon_value pointers stale in Blender's panel handler.
    _PREVIEW_COLLECTION = None

    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass


if __name__ == "__main__":
    register()


