
# -----------------------------------------------------------------------------
#  Pipeline Bridge / Container / Shot Manifest / Linked Overview
# -----------------------------------------------------------------------------

import datetime as _dt
import json
import os
import re
import shutil


_SF_PIPE_ALLOWED_MODES = {'OBJECTS', 'COLLECTIONS', 'MATERIALS', 'NODE_GROUPS', 'ACTIONS', 'WORLDS'}


def _sf_pipe_now_text() -> str:
    return _dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def _sf_pipe_version_text() -> str:
    try:
        ver = tuple(globals().get('bl_info', {}).get('version', ()))
        if ver:
            return '.'.join(str(int(v)) for v in ver)
    except Exception:
        pass
    return 'unknown'


def _sf_pipe_safe_name(text: str, fallback: str = 'container') -> str:
    value = _safe_filename(str(text or '').strip())
    return value or fallback


def _sf_pipe_manifest_store_path(abs_path: str, manifest_dir: str, *, prefer_relative: bool = True) -> str:
    abs_path = _norm_path(abs_path or '')
    manifest_dir = _norm_path(manifest_dir or '')
    if not abs_path:
        return ''
    if prefer_relative and manifest_dir:
        try:
            rel = os.path.relpath(abs_path, manifest_dir)
            return rel.replace('\\', '/')
        except Exception:
            pass
    return abs_path


def _sf_pipe_manifest_resolve_path(value: str, manifest_dir: str) -> str:
    raw = str(value or '').strip()
    if not raw:
        return ''
    if os.path.isabs(raw):
        return _norm_path(raw)
    return _norm_path(os.path.join(manifest_dir, raw))


def _sf_pipe_json_write(filepath: str, data: dict):
    out_dir = os.path.dirname(_norm_path(filepath))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def _sf_pipe_json_read(filepath: str) -> dict:
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return data if isinstance(data, dict) else {}


_SF_PIPE_RUNTIME_STATE_KEY = 'sf_pipeline_last_container_json'


def _sf_pipe_manifest_family(manifest: dict) -> str:
    value = str((manifest or {}).get('container_family', '') or '').strip()
    if value:
        return value
    mode = str((manifest or {}).get('mode', '') or '').strip().lower()
    if mode in {'objects', 'collections'}:
        return 'asset'
    if mode in {'actions'}:
        return 'animation'
    if mode in {'worlds'}:
        return 'lookdev'
    return 'container'


def _sf_pipe_manifest_representation(manifest: dict) -> str:
    value = str((manifest or {}).get('representation', '') or '').strip()
    return value or 'main'


def _sf_pipe_manifest_status(manifest: dict) -> str:
    value = str((manifest or {}).get('status', '') or '').strip()
    return value or 'PUBLISHED'


def _sf_pipe_manifest_revision(manifest: dict, filepath: str = '') -> int:
    try:
        rev = int((manifest or {}).get('revision', 0) or 0)
        if rev > 0:
            return rev
    except Exception:
        pass
    raw = os.path.basename(str(filepath or ''))
    match = re.search(r'(?i)(?:[_\-.](?:r|rev|v))(\d{1,6})(?=\D|$)', raw)
    if match:
        try:
            return max(1, int(match.group(1)))
        except Exception:
            pass
    return 1


def _sf_pipe_manifest_identity(manifest: dict) -> tuple[str, str]:
    family = _sf_pipe_manifest_family(manifest).strip().lower()
    name = str((manifest or {}).get('container_name', '') or '').strip().lower()
    return family, name


def _sf_pipe_manifest_tags(manifest: dict) -> list[str]:
    out = []
    seen = set()
    for token in list((manifest or {}).get('tags', []) or []):
        value = str(token or '').strip()
        lower = value.lower()
        if not value or lower in seen:
            continue
        seen.add(lower)
        out.append(value)
    return out


def _sf_pipe_report_lines(title: str, rows: dict) -> list[str]:
    try:
        data = _sf_collect_report_context(bpy.context)
    except Exception:
        data = {}
    lines = _sf_report_lines_header(title, data)
    for key, value in list((rows or {}).items()):
        if isinstance(value, (list, tuple, set)):
            seq = [str(v) for v in list(value) if str(v or '').strip()]
            if not seq:
                lines.append(f"- {key}: []")
            elif len(seq) <= 4:
                lines.append(f"- {key}: {','.join(seq)}")
            else:
                lines.append(f"- {key}: {len(seq)}")
                for item in seq[:8]:
                    lines.append(f"  - {item}")
                if len(seq) > 8:
                    lines.append(f"  - +{len(seq) - 8} more")
        else:
            lines.append(f"- {key}: {value}")
    try:
        lines.extend(['', *(_sf_report_export_notes_lines(title, data) or [])])
    except Exception:
        pass
    return lines


def _sf_pipe_store_runtime_container_state(context, manifest: dict, filepath: str, *, source: str = '') -> dict:
    wm = getattr(context, 'window_manager', None)
    payload = {
        'manifest_path': _norm_path(filepath or ''),
        'source': str(source or ''),
        'container_name': str((manifest or {}).get('container_name', '') or ''),
        'container_family': _sf_pipe_manifest_family(manifest),
        'representation': _sf_pipe_manifest_representation(manifest),
        'revision': int(_sf_pipe_manifest_revision(manifest, filepath)),
        'status': _sf_pipe_manifest_status(manifest),
        'mode': str((manifest or {}).get('mode', '') or ''),
        'updated_at': _sf_pipe_now_text(),
    }
    if wm is not None:
        try:
            wm[_SF_PIPE_RUNTIME_STATE_KEY] = json.dumps(payload, ensure_ascii=False)
        except Exception:
            pass
    return payload


def _sf_pipe_runtime_container_state(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    if wm is None:
        return {}
    raw = ''
    try:
        raw = wm.get(_SF_PIPE_RUNTIME_STATE_KEY, '')
    except Exception:
        try:
            raw = getattr(wm, _SF_PIPE_RUNTIME_STATE_KEY, '')
        except Exception:
            raw = ''
    try:
        data = json.loads(str(raw or ''))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _sf_pipe_scan_container_manifests(search_root: str, *, recursive: bool = True, max_items: int = 400) -> list[dict]:
    root = _norm_path(search_root or '')
    if not root or not os.path.isdir(root):
        return []
    rows = []
    def _iter_paths():
        if recursive:
            for dirpath, _dirnames, filenames in os.walk(root):
                for fn in filenames:
                    lower = fn.lower()
                    if lower.endswith('.sf_container.json') or lower.endswith('.json'):
                        yield _norm_path(os.path.join(dirpath, fn))
        else:
            for fn in os.listdir(root):
                lower = fn.lower()
                if lower.endswith('.sf_container.json') or lower.endswith('.json'):
                    yield _norm_path(os.path.join(root, fn))
    for path_item in _iter_paths():
        if len(rows) >= int(max_items or 0):
            break
        if not os.path.isfile(path_item):
            continue
        try:
            manifest = _sf_pipe_json_read(path_item)
        except Exception:
            continue
        if str((manifest or {}).get('kind', '') or '') != 'pipeline_container':
            continue
        family, name = _sf_pipe_manifest_identity(manifest)
        if not name:
            continue
        rep = _sf_pipe_manifest_representation(manifest)
        rev = _sf_pipe_manifest_revision(manifest, path_item)
        status = _sf_pipe_manifest_status(manifest)
        rows.append({
            'path': path_item,
            'manifest': manifest,
            'family': family,
            'container_name': str((manifest or {}).get('container_name', '') or ''),
            'representation': rep,
            'revision': int(rev),
            'status': status,
            'mtime': float(os.path.getmtime(path_item) if os.path.exists(path_item) else 0.0),
            'tags': _sf_pipe_manifest_tags(manifest),
        })
    rows.sort(key=lambda row: (str(row.get('container_name', '')).lower(), str(row.get('representation', '')).lower(), int(row.get('revision', 0) or 0), float(row.get('mtime', 0.0) or 0.0)))
    return rows


def _sf_pipe_related_container_rows(reference_manifest: dict, reference_path: str, *, search_root: str = '', recursive: bool = False) -> list[dict]:
    search_root = _norm_path(search_root or os.path.dirname(_norm_path(reference_path or '')))
    rows = _sf_pipe_scan_container_manifests(search_root, recursive=recursive)
    family, name = _sf_pipe_manifest_identity(reference_manifest)
    return [row for row in rows if row.get('family') == family and str(row.get('container_name', '')).strip().lower() == name]


def _sf_pipe_pick_latest_related(reference_manifest: dict, reference_path: str, *, search_root: str = '', recursive: bool = False, representation: str = '') -> dict:
    rows = _sf_pipe_related_container_rows(reference_manifest, reference_path, search_root=search_root, recursive=recursive)
    if representation:
        target_rep = str(representation or '').strip().lower()
        rows = [row for row in rows if str(row.get('representation', '')).strip().lower() == target_rep]
    if not rows:
        return {}
    rows.sort(key=lambda row: (int(row.get('revision', 0) or 0), float(row.get('mtime', 0.0) or 0.0), str(row.get('path', ''))))
    return rows[-1]


def _sf_pipe_guess_next_revision(search_root: str, container_name: str, family: str, representation: str) -> int:
    rows = _sf_pipe_scan_container_manifests(search_root, recursive=False, max_items=200)
    want_name = str(container_name or '').strip().lower()
    want_family = str(family or '').strip().lower()
    want_rep = str(representation or '').strip().lower()
    revisions = [
        int(row.get('revision', 0) or 0)
        for row in rows
        if str(row.get('container_name', '')).strip().lower() == want_name
        and str(row.get('family', '')).strip().lower() == want_family
        and str(row.get('representation', '')).strip().lower() == want_rep
    ]
    return (max(revisions) + 1) if revisions else 1



def _sf_pipe_browser_targets(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    if wm is None:
        return {}
    source_path = _norm_path(getattr(wm, 'sf_filepath', '') or '')
    mode = str(getattr(wm, 'sf_mode', 'OBJECTS') or 'OBJECTS').upper()
    if mode not in _SF_PIPE_ALLOWED_MODES:
        mode = 'OBJECTS'
    names = [str(getattr(it, 'name', '') or '') for it in getattr(wm, 'sf_items', []) or [] if bool(getattr(it, 'is_selected', False))]
    if not names:
        try:
            idx = int(getattr(wm, 'sf_active_index', 0) or 0)
            items = getattr(wm, 'sf_items', []) or []
            if 0 <= idx < len(items):
                nm = str(getattr(items[idx], 'name', '') or '')
                if nm:
                    names = [nm]
        except Exception:
            pass
    names = [n for n in names if n]
    return {
        'source_path': source_path,
        'mode': mode,
        'names': list(dict.fromkeys(names)),
        'ready': bool(source_path and os.path.isfile(source_path) and names),
    }


def _sf_pipe_scene_targets(context) -> dict:
    selected_objects = list(getattr(context, 'selected_objects', []) or [])
    active = getattr(context, 'active_object', None)
    if not selected_objects and active is not None:
        selected_objects = [active]
    if selected_objects:
        roots = _sf_ref_selected_root_ids(context, include_user_collections=True)
        return {
            'mode': 'OBJECTS',
            'names': list(dict.fromkeys([str(getattr(ob, 'name', '') or '') for ob in selected_objects if ob is not None])),
            'roots': roots,
            'ready': bool(roots),
        }
    coll = getattr(context, 'collection', None)
    if coll is not None:
        roots = _sf_ref_selected_root_ids(context, include_user_collections=True)
        return {
            'mode': 'COLLECTIONS',
            'names': [str(getattr(coll, 'name', '') or '')],
            'roots': roots,
            'ready': bool(roots),
        }
    return {'mode': 'OBJECTS', 'names': [], 'roots': [], 'ready': False}


def _sf_pipe_external_snapshot() -> dict:
    try:
        records = _sf_ext_collect_current_file_records(include_libraries=True, include_texts=False, include_missing=True)
        summary = dict(_sf_ext_summary(records) or {})
        summary['records_sample'] = [
            {
                'kind': str(rec.get('kind_label') or rec.get('kind_key') or ''),
                'name': str(rec.get('name') or ''),
                'exists': bool(rec.get('exists')),
                'raw_path': str(rec.get('raw_path') or ''),
            }
            for rec in records[:20]
        ]
        return summary
    except Exception:
        return {}


def _sf_pipe_pick_preferred_blend(manifest: dict, manifest_dir: str, *, prefer_payload: bool = True) -> tuple[str, str]:
    payload = _sf_pipe_manifest_resolve_path(manifest.get('payload_blend', ''), manifest_dir)
    copied = _sf_pipe_manifest_resolve_path(manifest.get('copied_source_blend', ''), manifest_dir)
    source = _sf_pipe_manifest_resolve_path(manifest.get('source_blend', ''), manifest_dir)
    order = []
    if prefer_payload:
        order.extend([('payload_blend', payload), ('copied_source_blend', copied), ('source_blend', source)])
    else:
        order.extend([('copied_source_blend', copied), ('source_blend', source), ('payload_blend', payload)])
    seen = set()
    for key, path in order:
        norm = _norm_path(path or '')
        if not norm or norm in seen:
            continue
        seen.add(norm)
        if os.path.isfile(norm):
            return norm, key
    return '', ''


def _sf_pipe_apply_browser_selection(context, source_path: str, mode: str, target_names: list[str], *, import_defaults: dict | None = None, preserve_existing_settings: bool = False) -> int:
    wm = getattr(context, 'window_manager', None)
    if wm is None:
        return 0
    if mode not in _SF_PIPE_ALLOWED_MODES:
        mode = 'OBJECTS'
    try:
        wm.sf_filepath = source_path
    except Exception:
        pass
    try:
        wm.sf_mode = mode
    except Exception:
        pass
    _reload_items(context)

    wanted = {str(n or '') for n in (target_names or []) if str(n or '').strip()}
    selected_count = 0
    try:
        items = getattr(wm, 'sf_items', []) or []
        for item in items:
            is_on = str(getattr(item, 'name', '') or '') in wanted if wanted else False
            item.is_selected = bool(is_on)
            if is_on:
                selected_count += 1
    except Exception:
        pass

    if not preserve_existing_settings:
        defaults = dict(import_defaults or {})
        for key in (
            'sf_import_mode',
            'sf_strict_loader',
            'sf_include_dependencies',
            'sf_bake_world',
            'sf_clear_parent',
            'sf_clear_constraints',
            'sf_put_in_collection',
            'sf_collection_name_mode',
            'sf_collection_name',
            'sf_select_imported',
            'sf_frame_view',
            'sf_apply_prefix_to_linked',
        ):
            if key in defaults and hasattr(wm, key):
                try:
                    setattr(wm, key, defaults.get(key))
                except Exception:
                    pass
    return selected_count


def _sf_pipe_linked_payload(context) -> dict:
    scene = getattr(context, 'scene', None)
    try:
        scene_objects = list(getattr(scene, 'objects', []) or [])
    except Exception:
        scene_objects = []
    libraries = []
    for lib in getattr(bpy.data, 'libraries', []) or []:
        try:
            path = _norm_path(bpy.path.abspath(getattr(lib, 'filepath', '') or ''))
        except Exception:
            path = _norm_path(getattr(lib, 'filepath', '') or '')
        if path:
            libraries.append(path)
    linked_objects = [ob for ob in scene_objects if getattr(ob, 'library', None)]
    override_objects = [ob for ob in scene_objects if getattr(ob, 'override_library', None)]
    local_objects = [ob for ob in scene_objects if not getattr(ob, 'library', None)]
    linked_collections = [coll for coll in getattr(bpy.data, 'collections', []) or [] if getattr(coll, 'library', None)]
    return {
        'libraries': list(dict.fromkeys(libraries)),
        'scene_object_count': len(scene_objects),
        'linked_object_count': len(linked_objects),
        'override_object_count': len(override_objects),
        'local_object_count': len(local_objects),
        'linked_collection_count': len(linked_collections),
        'linked_object_names': [str(getattr(ob, 'name', '') or '') for ob in linked_objects[:16]],
    }


class SF_OT_pipeline_publish_container(bpy.types.Operator, ExportHelper):
    bl_idname = 'export_scene.sfs_pipeline_publish_container'
    bl_label = 'Publish Container'
    bl_description = 'Create a reusable container manifest for the current selection or current Smart File browser picks. The container stores target names, import defaults, and an optional payload or copied source .blend so publish and load workflows stay compact and recoverable.'
    bl_options = set()
    _sms_no_undo = True

    filename_ext = '.sf_container.json'
    filter_glob: StringProperty(default='*.sf_container.json;*.json', options={'HIDDEN'})

    container_name: StringProperty(name='Container Name', default='', description='Name used for the manifest file, optional payload .blend, and user-facing report titles.')
    container_family: StringProperty(name='Family', default='asset', description='Pipeline family used to group related container manifests such as asset, shot, animation, or lookdev. Containers with the same family and name can share revision and representation switching.')
    representation: StringProperty(name='Representation', default='main', description='Representation label stored in the manifest, such as main, proxy, render, layout, or anim. Use this when one container has multiple publish flavors.')
    revision: IntProperty(name='Revision', default=1, min=1, max=999999, description='Revision number stored in the container manifest. The publish dialog proposes the next available revision from the target folder when possible.')
    status: EnumProperty(
        name='Status',
        items=[
            ('WIP', 'WIP', 'Container is still in work and may change often.'),
            ('REVIEW', 'Review', 'Container is ready for review or handoff checking.'),
            ('PUBLISHED', 'Published', 'Container is published for wider reuse.'),
            ('APPROVED', 'Approved', 'Container is approved as a trusted stable publish.'),
            ('ARCHIVE', 'Archive', 'Container is kept for history and older rollback purposes.'),
        ],
        default='PUBLISHED',
        description='Production status stored in the manifest for quick review.',
    )
    tags_csv: StringProperty(name='Tags', default='', description='Comma-separated helper tags stored in the manifest, such as hero, proxy, review, city, or crowd.')
    publish_mode: EnumProperty(
        name='Publish Mode',
        items=[
            ('CURRENT_SELECTION', 'Current Selection', 'Build the container from the currently selected scene objects or the active collection context.'),
            ('SMART_FILE_SELECTION', 'Smart File Selection', 'Build the container from the selected datablock names in the current Smart File source browser.'),
        ],
        default='CURRENT_SELECTION',
        description='Choose whether the container should be built from the scene selection or from the current Smart File source list.',
    )
    write_payload_blend: BoolProperty(name='Write payload .blend', default=True, description='When publishing from the current scene selection, also write a reusable payload .blend beside the manifest so the container remains loadable even if the scene file moves later.')
    copy_source_blend: BoolProperty(name='Copy source .blend', default=False, description='When publishing from the Smart File browser, copy the current source .blend beside the manifest for a more self-contained handoff.')
    path_remap: EnumProperty(
        name='Path Remap',
        items=[
            ('NONE', 'Keep', 'Do not rewrite external file paths in the payload .blend.'),
            ('RELATIVE', 'Relative Existing', 'Only keep already-relative paths relative when the payload is written.'),
            ('RELATIVE_ALL', 'Relative All', 'Rewrite supported payload paths to be relative to the payload .blend.'),
            ('ABSOLUTE', 'Absolute', 'Rewrite supported payload paths to absolute paths.'),
        ],
        default='RELATIVE_ALL',
        description='How external file paths should be written when a payload .blend is generated.',
    )
    compress: BoolProperty(name='Compress payload', default=True, description='Write the payload .blend as a compressed blend file.')
    fake_user: BoolProperty(name='Mark fake users', default=False, description='Ask Blender to tag written datablocks with fake users where supported so they survive later purges more easily.')
    import_mode: EnumProperty(
        name='Load Default',
        items=[
            ('APPEND', 'Append', 'Load the container targets as appended local data by default.'),
            ('LINK', 'Link', 'Load the container targets as linked references by default.'),
            ('LINK_OVERRIDE', 'Link + Override', 'Load the container targets as linked references with overrides by default.'),
        ],
        default='APPEND',
        description='Default import behavior stored in the container for later loads.',
    )
    strict_loader: BoolProperty(name='Strict Loader', default=True, description='Store the strict-loader preference in the container so future loads stay predictable and less likely to pull in extra data by accident.')
    include_dependencies: BoolProperty(name='Include dependencies', default=False, description='Store the dependency preference used by the standard Smart File import dialog for later container loads.')
    open_report: BoolProperty(name='Open report', default=True, description='Open a text report inside Blender after the container is written.')
    open_folder: BoolProperty(name='Open folder', default=False, description='Open the container folder after export finishes.')
    notes: StringProperty(name='Notes', default='', description='Optional short notes saved inside the container manifest for beginners, handoff comments, or review reminders.')

    def invoke(self, context, event):
        scene_target = _sf_pipe_scene_targets(context)
        browser_target = _sf_pipe_browser_targets(context)
        if browser_target.get('ready') and not scene_target.get('ready'):
            self.publish_mode = 'SMART_FILE_SELECTION'
        elif scene_target.get('ready'):
            self.publish_mode = 'CURRENT_SELECTION'
        seed = ''
        if scene_target.get('ready'):
            seed = scene_target.get('names', [''])[0]
        elif browser_target.get('ready'):
            seed = os.path.splitext(os.path.basename(browser_target.get('source_path', '') or ''))[0]
        elif bpy.data.filepath:
            seed = os.path.splitext(os.path.basename(bpy.data.filepath))[0]
        seed = _sf_pipe_safe_name(seed or 'container')
        if not self.container_name:
            self.container_name = seed
        if not str(self.container_family or '').strip():
            self.container_family = 'asset' if self.publish_mode == 'CURRENT_SELECTION' else 'container'
        if not str(self.representation or '').strip():
            self.representation = 'main'
        start_dir = _sf_ref_rel_base_dir() or _sf_user_default_dir('handoff')
        if not self.filepath:
            self.filepath = os.path.join(start_dir, f"{seed}.sf_container.json")
        target_dir = os.path.dirname(_norm_path(self.filepath or '')) or start_dir
        try:
            self.revision = max(1, int(_sf_pipe_guess_next_revision(target_dir, self.container_name or seed, self.container_family, self.representation)))
        except Exception:
            self.revision = max(1, int(self.revision or 1))
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'container_name')
        layout.prop(self, 'container_family')
        layout.prop(self, 'representation')
        layout.prop(self, 'revision')
        layout.prop(self, 'status')
        layout.prop(self, 'tags_csv')
        layout.prop(self, 'publish_mode')
        layout.prop(self, 'write_payload_blend')
        layout.prop(self, 'copy_source_blend')
        layout.prop(self, 'path_remap')
        layout.prop(self, 'compress')
        layout.prop(self, 'fake_user')
        layout.prop(self, 'import_mode')
        layout.prop(self, 'strict_loader')
        layout.prop(self, 'include_dependencies')
        layout.prop(self, 'open_report')
        layout.prop(self, 'open_folder')
        layout.prop(self, 'notes')

    def execute(self, context):
        filepath = _norm_path(self.filepath or '')
        if not filepath:
            self.report({'ERROR'}, _t('Output path is required'))
            return {'CANCELLED'}
        if not filepath.lower().endswith('.sf_container.json'):
            filepath += '.sf_container.json'
        manifest_dir = os.path.dirname(filepath)
        if manifest_dir:
            os.makedirs(manifest_dir, exist_ok=True)
        base_name = _sf_pipe_safe_name(os.path.splitext(os.path.splitext(os.path.basename(filepath))[0])[0], 'container')
        browser = _sf_pipe_browser_targets(context)
        scene = _sf_pipe_scene_targets(context)
        wm = getattr(context, 'window_manager', None)

        manifest = {
            'tool': 'Smart File',
            'kind': 'pipeline_container',
            'schema': 'sf_container_v2',
            'version': _sf_pipe_version_text(),
            'created_at': _sf_pipe_now_text(),
            'container_name': str(self.container_name or base_name),
            'container_family': _sf_pipe_safe_name(self.container_family or ('asset' if self.publish_mode == 'CURRENT_SELECTION' else 'container'), 'container'),
            'representation': _sf_pipe_safe_name(self.representation or 'main', 'main'),
            'revision': max(1, int(self.revision or 1)),
            'status': str(self.status or 'PUBLISHED'),
            'tags': [token.strip() for token in str(self.tags_csv or '').split(',') if token.strip()],
            'publish_mode': self.publish_mode,
            'mode': 'OBJECTS',
            'target_names': [],
            'payload_blend': '',
            'copied_source_blend': '',
            'source_blend': '',
            'notes': str(self.notes or ''),
            'external_summary': _sf_pipe_external_snapshot(),
            'import_defaults': {
                'sf_mode': 'OBJECTS',
                'sf_import_mode': str(self.import_mode or 'APPEND'),
                'sf_strict_loader': bool(self.strict_loader),
                'sf_include_dependencies': bool(self.include_dependencies),
            },
        }
        for key in ('sf_bake_world', 'sf_clear_parent', 'sf_clear_constraints', 'sf_put_in_collection', 'sf_collection_name_mode', 'sf_collection_name', 'sf_select_imported', 'sf_frame_view', 'sf_apply_prefix_to_linked'):
            if wm is not None and hasattr(wm, key):
                try:
                    manifest['import_defaults'][key] = getattr(wm, key)
                except Exception:
                    pass
        manifest['container_id'] = f"{manifest.get('container_family', 'container')}::{_sf_pipe_safe_name(manifest.get('container_name', ''), 'container')}"

        report_data = {
            'Manifest': filepath,
            'Publish Mode': self.publish_mode,
        }

        if self.publish_mode == 'CURRENT_SELECTION':
            if not scene.get('ready'):
                self.report({'ERROR'}, _t('No valid targets were found for the chosen publish mode'))
                return {'CANCELLED'}
            if (not self.write_payload_blend) and (not bpy.data.filepath):
                self.report({'ERROR'}, _t('Save the current file or write a payload blend first'))
                return {'CANCELLED'}
            manifest['mode'] = str(scene.get('mode') or 'OBJECTS')
            manifest['target_names'] = list(scene.get('names') or [])
            manifest['import_defaults']['sf_mode'] = manifest['mode']
            manifest['source_blend'] = _sf_pipe_manifest_store_path(bpy.data.filepath or '', manifest_dir, prefer_relative=True) if bpy.data.filepath else ''
            manifest['selection_roots'] = [
                {'name': str(getattr(id_, 'name', '') or ''), 'type': str(type(id_).__name__ or '')}
                for id_ in list(scene.get('roots') or [])[:60]
            ]
            if self.write_payload_blend:
                payload_path = os.path.join(manifest_dir, f"{base_name}_payload.blend")
                try:
                    bpy.data.libraries.write(
                        payload_path,
                        set(scene.get('roots') or []),
                        path_remap=self.path_remap,
                        fake_user=self.fake_user,
                        compress=self.compress,
                    )
                except Exception as ex:
                    self.report({'ERROR'}, f"{_t('Library export failed')}: {ex}")
                    return {'CANCELLED'}
                manifest['payload_blend'] = os.path.basename(payload_path)
                report_data['Payload Blend'] = payload_path
        else:
            if not browser.get('ready'):
                self.report({'ERROR'}, _t('No valid targets were found for the chosen publish mode'))
                return {'CANCELLED'}
            manifest['mode'] = str(browser.get('mode') or 'OBJECTS')
            manifest['target_names'] = list(browser.get('names') or [])
            manifest['import_defaults']['sf_mode'] = manifest['mode']
            manifest['source_blend'] = _sf_pipe_manifest_store_path(browser.get('source_path') or '', manifest_dir, prefer_relative=True)
            if self.copy_source_blend:
                copied_path = os.path.join(manifest_dir, f"{base_name}_source.blend")
                try:
                    shutil.copy2(browser.get('source_path') or '', copied_path)
                except Exception as ex:
                    self.report({'ERROR'}, f"{_t('Could not copy source file')}: {ex}")
                    return {'CANCELLED'}
                manifest['copied_source_blend'] = os.path.basename(copied_path)
                report_data['Copied Source Blend'] = copied_path

        _sf_pipe_json_write(filepath, manifest)
        _sf_pipe_store_runtime_container_state(context, manifest, filepath, source='PUBLISHED')
        report_data.update({
            'Container Name': manifest.get('container_name', ''),
            'Family': manifest.get('container_family', ''),
            'Representation': manifest.get('representation', ''),
            'Revision': manifest.get('revision', 1),
            'Status': manifest.get('status', ''),
            'Mode': manifest.get('mode', ''),
            'Targets': len(manifest.get('target_names') or []),
            'Source Blend': manifest.get('source_blend', ''),
            'Tags': manifest.get('tags', []) or [],
            'Target Names': manifest.get('target_names') or [],
        })
        _sf_report_export(
            context,
            _t('Pipeline Container'),
            _sf_pipe_report_lines(_t('Pipeline Container'), report_data),
            open_text=bool(self.open_report),
            activity_title=_t('Published pipeline container'),
        )
        if self.open_folder:
            try:
                bpy.ops.wm.path_open(filepath=manifest_dir or filepath)
            except Exception:
                pass
        self.report({'INFO'}, f"{_t('Pipeline Container')}: {os.path.basename(filepath)}")
        return {'FINISHED'}


class SF_OT_pipeline_load_container(bpy.types.Operator, ImportHelper):
    bl_idname = 'import_scene.sfs_pipeline_load_container'
    bl_label = 'Load Container'
    bl_description = 'Read a previously published Smart File container manifest, restore the stored source path and default target selection, then optionally open the standard import dialog.'
    bl_options = {'UNDO'}

    filename_ext = '.sf_container.json'
    filter_glob: StringProperty(default='*.sf_container.json;*.json', options={'HIDDEN'})

    prefer_payload_blend: BoolProperty(name='Prefer payload .blend', default=True, description='Prefer a payload .blend stored beside the manifest when it exists, then fall back to copied or original source files.')
    preserve_existing_settings: BoolProperty(name='Preserve existing settings', default=False, description='Keep the current browser import settings instead of applying the defaults saved in the container.')
    open_import_dialog: BoolProperty(name='Open import dialog', default=True, description='Open the standard Smart File import dialog after the container restores the source path and selections.')
    run_import_now: BoolProperty(name='Run import now', default=False, description='Immediately execute the standard Smart File import operator after the container restores its selection. Leave this off if you want to review the dialog first.')

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'prefer_payload_blend')
        layout.prop(self, 'preserve_existing_settings')
        layout.prop(self, 'open_import_dialog')
        layout.prop(self, 'run_import_now')

    def execute(self, context):
        filepath = _norm_path(self.filepath or '')
        if not filepath or not os.path.isfile(filepath):
            self.report({'ERROR'}, _t('The file does not exist'))
            return {'CANCELLED'}
        try:
            manifest = _sf_pipe_json_read(filepath)
        except Exception as ex:
            self.report({'ERROR'}, f"{_t('Container manifest is invalid')}: {ex}")
            return {'CANCELLED'}
        if str(manifest.get('kind') or '') != 'pipeline_container':
            self.report({'ERROR'}, _t('Container manifest is invalid'))
            return {'CANCELLED'}

        manifest_dir = os.path.dirname(filepath)
        source_path, source_key = _sf_pipe_pick_preferred_blend(manifest, manifest_dir, prefer_payload=bool(self.prefer_payload_blend))
        if not source_path:
            self.report({'ERROR'}, _t('Container source is unavailable'))
            return {'CANCELLED'}

        mode = str(manifest.get('mode') or (manifest.get('import_defaults') or {}).get('sf_mode') or 'OBJECTS').upper()
        target_names = list(manifest.get('target_names') or [])
        selected_count = _sf_pipe_apply_browser_selection(
            context,
            source_path,
            mode,
            target_names,
            import_defaults=dict(manifest.get('import_defaults') or {}),
            preserve_existing_settings=bool(self.preserve_existing_settings),
        )
        _sf_pipe_store_runtime_container_state(context, manifest, filepath, source='LOADED')
        _sf_report_export(
            context,
            _t('Pipeline Container Load'),
            _sf_pipe_report_lines(_t('Pipeline Container Load'), {
                'Manifest': filepath,
                'Resolved Source': source_path,
                'Source Kind': source_key,
                'Family': _sf_pipe_manifest_family(manifest),
                'Representation': _sf_pipe_manifest_representation(manifest),
                'Revision': _sf_pipe_manifest_revision(manifest, filepath),
                'Status': _sf_pipe_manifest_status(manifest),
                'Mode': mode,
                'Targets': len(target_names),
                'Selected in Browser': selected_count,
            }),
            open_text=False,
            activity_title=_t('Loaded pipeline container'),
        )
        if self.run_import_now and selected_count:
            try:
                bpy.ops.import_scene.sfs_source_browser_import_2('EXEC_DEFAULT')
            except Exception:
                pass
        elif self.open_import_dialog:
            try:
                bpy.ops.import_scene.sfs_source_browser_import_2('INVOKE_DEFAULT')
            except Exception:
                pass
        self.report({'INFO'}, f"{_t('Pipeline Container Load')}: {os.path.basename(filepath)}")
        return {'FINISHED'}


class SF_OT_pipeline_shot_manifest(bpy.types.Operator, ExportHelper):
    bl_idname = 'export_scene.sfs_pipeline_shot_manifest'
    bl_label = 'Shot Manifest'
    bl_description = 'Export a compact JSON manifest for the active scene with frame range, render settings, camera information, linked-library summary, and optional external-file diagnostics.'
    bl_options = set()
    _sms_no_undo = True

    filename_ext = '.shot_manifest.json'
    filter_glob: StringProperty(default='*.shot_manifest.json;*.json', options={'HIDDEN'})

    include_markers: BoolProperty(name='Include markers', default=True, description='Store timeline markers and bound cameras so shot handoff is easier to review later.')
    include_external_summary: BoolProperty(name='Include external summary', default=True, description='Include a compact summary of external files and linked libraries in the shot manifest.')
    include_object_names: BoolProperty(name='Include object names', default=False, description='Include the scene object names in the JSON for lightweight review and validation.')
    open_report: BoolProperty(name='Open report', default=True, description='Open a text report inside Blender after the shot manifest is written.')
    open_folder: BoolProperty(name='Open folder', default=False, description='Open the folder that contains the written shot manifest.')

    def invoke(self, context, event):
        scene = getattr(context, 'scene', None)
        seed = _sf_pipe_safe_name(getattr(scene, 'name', '') or os.path.splitext(os.path.basename(bpy.data.filepath or 'shot'))[0], 'shot')
        if not self.filepath:
            start_dir = _sf_ref_rel_base_dir() or _sf_user_default_dir('handoff')
            self.filepath = os.path.join(start_dir, f"{seed}.shot_manifest.json")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'include_markers')
        layout.prop(self, 'include_external_summary')
        layout.prop(self, 'include_object_names')
        layout.prop(self, 'open_report')
        layout.prop(self, 'open_folder')

    def execute(self, context):
        filepath = _norm_path(self.filepath or '')
        if not filepath:
            self.report({'ERROR'}, _t('Output path is required'))
            return {'CANCELLED'}
        if not filepath.lower().endswith('.shot_manifest.json'):
            filepath += '.shot_manifest.json'
        scene = getattr(context, 'scene', None)
        if scene is None:
            self.report({'ERROR'}, _t('No active scene'))
            return {'CANCELLED'}
        render = getattr(scene, 'render', None)
        fps = float(getattr(render, 'fps', 24) or 24)
        fps_base = float(getattr(render, 'fps_base', 1.0) or 1.0)
        effective_fps = fps / fps_base if fps_base else fps
        libraries = []
        for lib in getattr(bpy.data, 'libraries', []) or []:
            try:
                libraries.append(_norm_path(bpy.path.abspath(getattr(lib, 'filepath', '') or '')))
            except Exception:
                libraries.append(_norm_path(getattr(lib, 'filepath', '') or ''))
        data = {
            'tool': 'Smart File',
            'kind': 'shot_manifest',
            'version': _sf_pipe_version_text(),
            'created_at': _sf_pipe_now_text(),
            'file': _norm_path(bpy.data.filepath or ''),
            'scene': {
                'name': str(getattr(scene, 'name', '') or ''),
                'camera': str(getattr(getattr(scene, 'camera', None), 'name', '') or ''),
                'world': str(getattr(getattr(scene, 'world', None), 'name', '') or ''),
                'frame_start': int(getattr(scene, 'frame_start', 1) or 1),
                'frame_end': int(getattr(scene, 'frame_end', 250) or 250),
                'frame_current': int(getattr(scene, 'frame_current', 1) or 1),
            },
            'render': {
                'engine': str(getattr(render, 'engine', '') or ''),
                'resolution_x': int(getattr(render, 'resolution_x', 0) or 0),
                'resolution_y': int(getattr(render, 'resolution_y', 0) or 0),
                'resolution_percentage': int(getattr(render, 'resolution_percentage', 100) or 100),
                'fps': effective_fps,
                'output_path': str(getattr(render, 'filepath', '') or ''),
                'file_format': str(getattr(getattr(render, 'image_settings', None), 'file_format', '') or ''),
            },
            'counts': {
                'scene_objects': len(list(getattr(scene, 'objects', []) or [])),
                'collections': len(getattr(bpy.data, 'collections', []) or []),
                'materials': len(getattr(bpy.data, 'materials', []) or []),
                'linked_libraries': len(list(dict.fromkeys([p for p in libraries if p]))),
            },
            'linked_libraries': list(dict.fromkeys([p for p in libraries if p])),
        }
        if self.include_markers:
            data['markers'] = [
                {
                    'name': str(getattr(marker, 'name', '') or ''),
                    'frame': int(getattr(marker, 'frame', 0) or 0),
                    'camera': str(getattr(getattr(marker, 'camera', None), 'name', '') or ''),
                }
                for marker in getattr(scene, 'timeline_markers', []) or []
            ]
        if self.include_object_names:
            data['object_names'] = [str(getattr(ob, 'name', '') or '') for ob in getattr(scene, 'objects', []) or []]
        if self.include_external_summary:
            data['external'] = _sf_pipe_external_snapshot()
        _sf_pipe_json_write(filepath, data)
        _sf_report_export(
            context,
            _t('Shot Manifest'),
            _sf_pipe_report_lines(_t('Shot Manifest'), {
                'Manifest': filepath,
                'Scene': data['scene']['name'],
                'Camera': data['scene']['camera'],
                'Frame Range': f"{data['scene']['frame_start']} - {data['scene']['frame_end']}",
                'Libraries': data['counts']['linked_libraries'],
                'Objects': data['counts']['scene_objects'],
            }),
            open_text=bool(self.open_report),
            activity_title=_t('Exported shot manifest'),
        )
        if self.open_folder:
            try:
                bpy.ops.wm.path_open(filepath=os.path.dirname(filepath) or filepath)
            except Exception:
                pass
        self.report({'INFO'}, f"{_t('Shot Manifest')}: {os.path.basename(filepath)}")
        return {'FINISHED'}


class SF_OT_pipeline_select_by_reference_state(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_pipeline_select_by_reference_state'
    bl_label = 'Select by Reference State'
    bl_description = 'Select only linked, only local, or only override scene objects so it is easier to inspect what is editable before you run relink or publish actions.'
    bl_options = {'UNDO'}

    mode: EnumProperty(
        name='Mode',
        items=[
            ('ONLY_LINKED', 'Linked Only', 'Select only scene objects coming directly from linked libraries.'),
            ('ONLY_LOCAL', 'Local Only', 'Select only local scene objects that are not linked.'),
            ('ONLY_OVERRIDES', 'Overrides Only', 'Select only scene objects that use library overrides.'),
        ],
        default='ONLY_LINKED',
    )

    def execute(self, context):
        scene = getattr(context, 'scene', None)
        if scene is None:
            self.report({'ERROR'}, _t('No active scene'))
            return {'CANCELLED'}
        selected = []
        active = None
        for ob in getattr(scene, 'objects', []) or []:
            keep = False
            if self.mode == 'ONLY_LINKED':
                keep = bool(getattr(ob, 'library', None))
            elif self.mode == 'ONLY_OVERRIDES':
                keep = bool(getattr(ob, 'override_library', None))
            else:
                keep = not bool(getattr(ob, 'library', None))
            try:
                ob.select_set(bool(keep))
            except Exception:
                pass
            if keep:
                selected.append(str(getattr(ob, 'name', '') or ''))
                if active is None:
                    active = ob
        if active is not None:
            try:
                context.view_layer.objects.active = active
            except Exception:
                pass
        self.report({'INFO'}, f"{_t('Selected')}: {len(selected)}")
        return {'FINISHED'}


class SF_OT_pipeline_linked_overview(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = 'import_scene.sfs_pipeline_linked_overview'
    bl_label = 'Linked Overview'
    bl_description = 'Open a compact overview of linked libraries, override counts, and scene editability so both beginners and advanced users can see what is referenced before changing paths or publishing.'
    bl_options = set()

    popup_width: IntProperty(default=620, min=420, max=860, options={'HIDDEN'})

    def invoke(self, context, event):
        try:
            _sf_append_activity(context, _t('Opened linked overview'), '', 'LINKED')
        except Exception:
            pass
        return context.window_manager.invoke_popup(self, width=self.popup_width)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        payload = _sf_pipe_linked_payload(context)
        _sf_draw_dialog_header(
            layout,
            'Linked Overview',
            'Review linked libraries, overrides, and editable scene objects before repair, relink, or publish work.',
            'LINKED',
        )
        status = layout.box()
        _sf_draw_section_intro(
            status,
            'Reference Summary',
            'Use this summary first to see whether the current scene is mostly local, mostly linked, or override-heavy.',
            'NONE',
        )
        _sf_draw_state_line(status, 'Libraries', 'READY' if payload.get('libraries') else 'NOT SET', detail=str(len(payload.get('libraries') or [])))
        _sf_draw_state_line(status, 'Linked Scene Objects', 'READY' if int(payload.get('linked_object_count', 0) or 0) else 'NOT SET', detail=str(int(payload.get('linked_object_count', 0) or 0)))
        _sf_draw_state_line(status, 'Override Scene Objects', 'READY' if int(payload.get('override_object_count', 0) or 0) else 'NOT SET', detail=str(int(payload.get('override_object_count', 0) or 0)))
        _sf_draw_state_line(status, 'Local Scene Objects', 'READY' if int(payload.get('local_object_count', 0) or 0) else 'NOT SET', detail=str(int(payload.get('local_object_count', 0) or 0)))
        _sf_draw_state_line(status, 'Linked Collections', 'READY' if int(payload.get('linked_collection_count', 0) or 0) else 'NOT SET', detail=str(int(payload.get('linked_collection_count', 0) or 0)))

        actions = layout.box()
        _sf_draw_section_intro(
            actions,
            'Selection Helpers',
            'These filters do not change data. They only help you see which objects are linked, local, or override-based before the next step.',
            'RESTRICT_SELECT_OFF',
        )
        _sf_draw_action_block(
            actions,
            primary_actions=[
                ('import_scene.sfs_pipeline_select_by_reference_state', 'Linked Only', 'LINKED', {'mode': 'ONLY_LINKED'}),
                ('import_scene.sfs_pipeline_select_by_reference_state', 'Local Only', 'OBJECT_DATA', {'mode': 'ONLY_LOCAL'}),
                ('import_scene.sfs_pipeline_select_by_reference_state', 'Overrides Only', 'LIBRARY_DATA_OVERRIDE', {'mode': 'ONLY_OVERRIDES'}),
            ],
            secondary_actions=[
                ('import_scene.sfs_reference_manager_open', 'Relink', 'LINKED', {}),
                ('import_scene.sfs_reference_toolkit_open', 'Toolkit', 'ASSET_MANAGER', {}),
                ('import_scene.sfs_representation_open', 'Representations', 'MOD_WIREFRAME', {}),
                ('import_scene.sfs_project_guard_open', 'Project Guard', 'LOCKVIEW_ON', {}),
            ],
        )

        rep = _sf_rep_scene_summary(context)
        rep_box = layout.box()
        _sf_draw_section_intro(
            rep_box,
            'Representation Snapshot',
            'Check lightweight display and hide-state counts here before you switch large linked scenes into bounds, hidden, or restored modes.',
            'MOD_WIREFRAME',
        )
        _sf_draw_state_line(rep_box, 'Linked Bounds', 'READY' if int(rep.get('linked_bounds_count', 0) or 0) else 'NOT SET', detail=str(int(rep.get('linked_bounds_count', 0) or 0)))
        _sf_draw_state_line(rep_box, 'Override Bounds', 'READY' if int(rep.get('override_bounds_count', 0) or 0) else 'NOT SET', detail=str(int(rep.get('override_bounds_count', 0) or 0)))
        _sf_draw_state_line(rep_box, 'Linked Hidden Viewport', 'READY' if int(rep.get('linked_hidden_viewport_count', 0) or 0) else 'NOT SET', detail=str(int(rep.get('linked_hidden_viewport_count', 0) or 0)))
        _sf_draw_state_line(rep_box, 'Linked Hidden Render', 'READY' if int(rep.get('linked_hidden_render_count', 0) or 0) else 'NOT SET', detail=str(int(rep.get('linked_hidden_render_count', 0) or 0)))
        _sf_draw_state_line(rep_box, 'Representation Snapshot', 'READY' if int(rep.get('snapshot_entries', 0) or 0) else 'NOT SET', detail=str(int(rep.get('snapshot_entries', 0) or 0)))

        libs_box = layout.box()
        _sf_draw_section_intro(
            libs_box,
            'Linked Library Paths',
            'Check the first few library file paths here when you need a quick sanity check before opening the full Reference Manager.',
            'FILE_FOLDER',
        )
        libraries = list(payload.get('libraries') or [])
        if not libraries:
            libs_box.label(text=_t('No linked libraries found'))
        else:
            for path in libraries[:10]:
                libs_box.label(text=path, icon='BLANK1', translate=False)
            if len(libraries) > 10:
                libs_box.label(text=f"+ {len(libraries) - 10} {_t('more')}", icon='DOT')
