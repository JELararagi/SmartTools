# -----------------------------------------------------------------------------
# Copyright (C) 2026 JELararagi
# Integrated History Auto Save / Restore — single exact lifecycle owner
# -----------------------------------------------------------------------------

from __future__ import annotations

import time
import uuid
from typing import Any, Callable, Optional

import bpy

from .history_auto_save import translation as _sfs_hist_i18n
from .history_auto_save.properties import (
    SFS_PG_history_history_preferences,
    SFS_PG_history_crash_recovery_candidate,
    UHM_HistoryEntry,
    UHM_SceneSettings,
)
from .history_auto_save.operators.history_operators import CLASSES as _SFS_HISTORY_OP_CLASSES
from .history_auto_save.ui.panels import draw_history_popup_ui

# History UI is rendered only inside the canonical Smart File History & Restore
# section. Keep this exact empty tuple in the owner module as well, so a live
# reload cannot re-register stale standalone History Panel wrappers retained by
# an older child-module object in ``sys.modules``.
_SFS_HISTORY_PANEL_CLASSES = ()
from .history_auto_save.core import runtime as _sfs_hist_runtime

SMART_FILE_SUITE_VERSION = (1, 0, 0)

_SFS_HISTORY_DEPENDENCY_CLASSES = (
    UHM_HistoryEntry,
    SFS_PG_history_crash_recovery_candidate,
    UHM_SceneSettings,
    SFS_PG_history_history_preferences,
)
_SFS_HISTORY_RUNTIME_CLASSES = tuple(_SFS_HISTORY_OP_CLASSES) + tuple(_SFS_HISTORY_PANEL_CLASSES)
_SFS_HISTORY_CLASSES = _SFS_HISTORY_DEPENDENCY_CLASSES + _SFS_HISTORY_RUNTIME_CLASSES

_SFS_HISTORY_OWNER_KEY = "JELararagi.smart_file.history.lifecycle.v57540"
_SFS_HISTORY_LEGACY_OWNER_KEYS = (
    "JELararagi.smart_file.history.lifecycle.v57539",
    "JELararagi.smart_file.history.lifecycle.v57536",
    "JELararagi.smart_file.history.lifecycle.v57535",
    "JELararagi.smart_file.history.lifecycle.v57534",
    "JELararagi.smart_file.history.lifecycle.v57533",
    "JELararagi.smart_file.history.lifecycle.v57532",
    "JELararagi.smart_file.history.lifecycle.v57531",
)
_SFS_HISTORY_OWNER_TOKEN = object()
_SFS_HISTORY_GENERATION = uuid.uuid4().hex
_SFS_HISTORY_CLASS_RECORDS: list[dict[str, Any]] = []
_SFS_HISTORY_POINTER_RECORDS: list[dict[str, Any]] = []
_SFS_HISTORY_I18N_REGISTERED = False
_SFS_HISTORY_PHASE = "IDLE"
_SFS_HISTORY_LAST_ERROR = ""
_SFS_HISTORY_REPAIR_CALLBACK: Optional[Callable[[], Optional[float]]] = None
_SFS_HISTORY_REPAIR_DUE: Optional[float] = None
_SFS_HISTORY_REPAIR_FAILURES = 0
_SFS_HISTORY_REPAIR_RUNNING = False
_SFS_HISTORY_REPAIR_BACKOFF = (2.0, 4.0, 8.0, 16.0, 32.0, 60.0)
_SFS_HISTORY_REPAIR_MAX_ATTEMPTS = len(_SFS_HISTORY_REPAIR_BACKOFF)


def _sf_history_namespace():
    namespace = getattr(getattr(bpy, "app", None), "driver_namespace", None)
    return namespace if isinstance(namespace, dict) else None


def _sf_history_ledger():
    namespace = _sf_history_namespace()
    return namespace.get(_SFS_HISTORY_OWNER_KEY) if namespace is not None else None


def _sf_history_is_current_owner() -> bool:
    ledger = _sf_history_ledger()
    return bool(
        isinstance(ledger, dict)
        and ledger.get("token") is _SFS_HISTORY_OWNER_TOKEN
        and ledger.get("generation") == _SFS_HISTORY_GENERATION
        and ledger.get("owner_module") == __name__
    )


def _sf_history_error(exc: Any) -> str:
    if isinstance(exc, BaseException):
        return f"{type(exc).__name__}: {exc}"[:1024]
    return str(exc or "")[:1024]


def _sf_history_class_ready(cls) -> bool:
    """Return whether *this exact Python class* owns a valid RNA descriptor.

    ``getattr(cls, "bl_rna")`` is not sufficient for PropertyGroup subclasses:
    before registration Blender exposes the base ``PropertyGroup.bl_rna`` via
    inheritance.  Treating that inherited descriptor as readiness makes a
    subsequent PointerProperty reference fail with ``missing bl_rna``.  Blender
    Extension classes are also not guaranteed to be published as
    ``bpy.types.<PythonName>``, so class ownership is the authoritative check.
    """
    try:
        if not isinstance(cls, type):
            return False
        rna = vars(cls).get("bl_rna")
        identifier = str(getattr(rna, "identifier", "") or "").strip()
        return bool(rna is not None and identifier)
    except Exception:
        return False


def _sf_history_register_class_exact(cls) -> tuple[bool, bool]:
    """Register one exact class and report whether this generation acquired it."""
    if not isinstance(cls, type):
        raise TypeError(f"History RNA class is not a type: {cls!r}")
    if _sf_history_class_ready(cls):
        return True, False
    instrument = globals().get("_jel_status_instrument_class_v2")
    if callable(instrument):
        instrument(cls)
    try:
        bpy.utils.register_class(cls)
    except Exception as exc:
        raise RuntimeError(
            f"History class registration failed: {getattr(cls, '__name__', cls)!r}: "
            f"{type(exc).__name__}: {exc}"
        ) from exc
    if not _sf_history_class_ready(cls):
        # The class call returned but Blender did not attach an RNA descriptor to
        # this exact class.  Roll back only the class just acquired.
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        raise RuntimeError(
            f"History class has no class-owned RNA after registration: "
            f"{getattr(cls, '__name__', cls)!r}"
        )
    return True, True


def _sf_history_unregister_class_exact(record: dict[str, Any]) -> bool:
    cls = record.get("class")
    if not record.get("acquired"):
        return True
    if record.get("token") is not _SFS_HISTORY_OWNER_TOKEN or record.get("generation") != _SFS_HISTORY_GENERATION:
        return False
    try:
        if _sf_history_class_ready(cls):
            bpy.utils.unregister_class(cls)
        return not _sf_history_class_ready(cls)
    except Exception:
        return False


def _sf_history_pointer_descriptor(owner_type, name: str):
    try:
        return getattr(owner_type, name) if hasattr(owner_type, name) else None
    except Exception:
        return None


def _sf_history_pointer_type_matches(descriptor, expected_type) -> bool:
    if descriptor is None or expected_type is None:
        return False
    try:
        fixed = getattr(descriptor, "fixed_type", None)
        expected_rna = vars(expected_type).get("bl_rna") if isinstance(expected_type, type) else None
        if fixed is expected_type or (expected_rna is not None and fixed is expected_rna):
            return True
        # Blender 5.1 may retain dynamically assigned PointerProperty values as
        # _PropertyDeferred after assignment.  In that state fixed_type is None,
        # but the original property factory arguments remain available and must
        # match the exact expected Python class identity.
        keywords = getattr(descriptor, "keywords", None)
        return bool(isinstance(keywords, dict) and keywords.get("type") is expected_type)
    except Exception:
        return False


def _sf_history_assign_pointer(
    owner_type,
    name: str,
    property_value,
    *,
    role: str,
    expected_type=None,
) -> dict[str, Any]:
    existing = _sf_history_pointer_descriptor(owner_type, name)
    acquired = False
    if existing is None:
        setattr(owner_type, name, property_value)
        acquired = True
        existing = _sf_history_pointer_descriptor(owner_type, name)
    if existing is None:
        raise RuntimeError(f"{owner_type.__name__}.{name} registration failed")
    if expected_type is not None and not _sf_history_pointer_type_matches(existing, expected_type):
        raise RuntimeError(f"{owner_type.__name__}.{name} has a foreign PointerProperty type")
    return {
        "owner_type": owner_type,
        "name": name,
        "descriptor": existing,
        "expected_type": expected_type,
        "acquired": acquired,
        "role": role,
        "token": _SFS_HISTORY_OWNER_TOKEN,
        "generation": _SFS_HISTORY_GENERATION,
    }


def _sf_history_delete_owned_pointer(record: dict[str, Any]) -> bool:
    if not record.get("acquired"):
        return True
    if record.get("token") is not _SFS_HISTORY_OWNER_TOKEN or record.get("generation") != _SFS_HISTORY_GENERATION:
        return False
    owner_type = record.get("owner_type")
    name = str(record.get("name") or "")
    descriptor = record.get("descriptor")
    try:
        if owner_type is None or not name or not hasattr(owner_type, name):
            return True
        if getattr(owner_type, name) is not descriptor:
            return False
        delattr(owner_type, name)
        return not hasattr(owner_type, name)
    except Exception:
        return False


def _sf_history_canonical_settings_record() -> dict[str, Any]:
    expected_type = globals().get("SFS_PG_system_file_suite_preferences")
    if not _sf_history_class_ready(expected_type):
        raise RuntimeError("SFS_PG_system_file_suite_preferences RNA is unavailable")
    descriptor = _sf_history_pointer_descriptor(
        bpy.types.WindowManager, "sf_addon_settings"
    )
    if descriptor is None:
        raise RuntimeError("WindowManager.sf_addon_settings is unavailable")
    context = getattr(bpy, "context", None)
    wm = getattr(context, "window_manager", None) if context is not None else None
    if wm is not None and getattr(wm, "sf_addon_settings", None) is None:
        raise RuntimeError("Canonical sf_addon_settings instance is unavailable")
    if not _sf_history_pointer_type_matches(descriptor, expected_type):
        raise RuntimeError("WindowManager.sf_addon_settings has a foreign PointerProperty type")
    return {
        "owner_type": bpy.types.WindowManager,
        "name": "sf_addon_settings",
        "descriptor": descriptor,
        "expected_type": expected_type,
        "acquired": False,
        "role": "canonical_settings_authority",
        "token": _SFS_HISTORY_OWNER_TOKEN,
        "generation": _SFS_HISTORY_GENERATION,
    }


def _sf_history_settings_registration_ok() -> bool:
    try:
        from . import settings as _sfs_settings

        status_fn = getattr(_sfs_settings, "get_registration_status", None)
        if not callable(status_fn):
            status_fn = getattr(_sfs_settings, "runtime_status", None)
        if not callable(status_fn):
            return False
        status = status_fn()
        return bool(
            status.get("registered")
            and status.get("owner_ok")
            and status.get("handlers_ok")
            and (status.get("subscriptions_ok") or status.get("msgbus_owner_ok"))
            and status.get("subscription_owner_exact")
        )
    except Exception:
        return False


def _sf_history_surviving_class_records_ok() -> bool:
    """Validate this live Python/RNA generation without its namespace ledger."""
    if len(_SFS_HISTORY_CLASS_RECORDS) != len(_SFS_HISTORY_CLASSES):
        return False
    return all(
        isinstance(record, dict)
        and record.get("class") is cls
        and record.get("token") is _SFS_HISTORY_OWNER_TOKEN
        and record.get("generation") == _SFS_HISTORY_GENERATION
        and _sf_history_class_ready(cls)
        for record, cls in zip(_SFS_HISTORY_CLASS_RECORDS, _SFS_HISTORY_CLASSES)
    )


def _sf_history_class_records_ok() -> bool:
    if not _sf_history_surviving_class_records_ok():
        return False
    ledger = _sf_history_ledger()
    ledger_records = tuple(ledger.get("classes", ()) or ()) if isinstance(ledger, dict) else ()
    if len(ledger_records) != len(_SFS_HISTORY_CLASS_RECORDS):
        return False
    return all(
        ledger_records[index] is record
        for index, record in enumerate(_SFS_HISTORY_CLASS_RECORDS)
    )


def _sf_history_dependency_records_ok() -> bool:
    """Validate the dependency prefix without requiring runtime UI classes."""
    if len(_SFS_HISTORY_CLASS_RECORDS) < len(_SFS_HISTORY_DEPENDENCY_CLASSES):
        return False
    for index, cls in enumerate(_SFS_HISTORY_DEPENDENCY_CLASSES):
        record = _SFS_HISTORY_CLASS_RECORDS[index]
        if (
            record.get("class") is not cls
            or record.get("token") is not _SFS_HISTORY_OWNER_TOKEN
            or record.get("generation") != _SFS_HISTORY_GENERATION
            or not _sf_history_class_ready(cls)
        ):
            return False
    ledger = _sf_history_ledger()
    ledger_records = tuple(ledger.get("classes", ()) or ()) if isinstance(ledger, dict) else ()
    if len(ledger_records) < len(_SFS_HISTORY_DEPENDENCY_CLASSES):
        return False
    return all(
        ledger_records[index] is _SFS_HISTORY_CLASS_RECORDS[index]
        for index in range(len(_SFS_HISTORY_DEPENDENCY_CLASSES))
    )


def _sf_history_main_preferences_ready() -> bool:
    return _sf_history_class_ready(globals().get("SFS_PG_system_file_suite_preferences"))

def _sf_history_surviving_pointer_records_ok() -> bool:
    """Validate exact live pointer ownership without its namespace ledger."""
    required = {
        (bpy.types.Scene, "uhm_settings"),
        (bpy.types.WindowManager, "uhm_addon_settings"),
        (bpy.types.WindowManager, "sf_addon_settings"),
    }
    if len(_SFS_HISTORY_POINTER_RECORDS) != len(required):
        return False
    found = set()
    for record in _SFS_HISTORY_POINTER_RECORDS:
        if not isinstance(record, dict):
            return False
        owner_type = record.get("owner_type")
        name = str(record.get("name") or "")
        descriptor = record.get("descriptor")
        expected_type = record.get("expected_type")
        if record.get("token") is not _SFS_HISTORY_OWNER_TOKEN or record.get("generation") != _SFS_HISTORY_GENERATION:
            return False
        if _sf_history_pointer_descriptor(owner_type, name) is not descriptor:
            return False
        if expected_type is not None and not _sf_history_pointer_type_matches(descriptor, expected_type):
            return False
        found.add((owner_type, name))
    return found == required and len(found) == len(_SFS_HISTORY_POINTER_RECORDS)


def _sf_history_pointer_records_ok() -> bool:
    if not _sf_history_surviving_pointer_records_ok():
        return False
    ledger = _sf_history_ledger()
    ledger_records = tuple(ledger.get("pointers", ()) or ()) if isinstance(ledger, dict) else ()
    if len(ledger_records) != len(_SFS_HISTORY_POINTER_RECORDS):
        return False
    return all(
        ledger_records[index] is record
        for index, record in enumerate(_SFS_HISTORY_POINTER_RECORDS)
    )

def _sf_history_lifecycle_validator() -> bool:
    return bool(
        _sf_history_is_current_owner()
        and _sf_history_main_preferences_ready()
        and _sf_history_class_records_ok()
        and _sf_history_pointer_records_ok()
        and _sf_history_settings_registration_ok()
    )


def _sf_history_cancel_repair_timer() -> bool:
    global _SFS_HISTORY_REPAIR_CALLBACK, _SFS_HISTORY_REPAIR_DUE
    callback = _SFS_HISTORY_REPAIR_CALLBACK
    ledger = _sf_history_ledger()
    record = ledger.get("repair_timer") if isinstance(ledger, dict) else None
    if callback is None:
        _SFS_HISTORY_REPAIR_DUE = None
        if isinstance(ledger, dict):
            ledger["repair_timer"] = None
            ledger["repair_due"] = None
        return True
    if not (
        isinstance(record, dict)
        and record.get("callback") is callback
        and record.get("token") is _SFS_HISTORY_OWNER_TOKEN
        and record.get("generation") == _SFS_HISTORY_GENERATION
    ):
        return False
    # A one-shot callback consumes itself by clearing the ledger and returning
    # None.  Do not call the native unregister path while it is executing.
    if _SFS_HISTORY_REPAIR_RUNNING:
        _SFS_HISTORY_REPAIR_CALLBACK = None
        _SFS_HISTORY_REPAIR_DUE = None
        ledger["repair_timer"] = None
        ledger["repair_due"] = None
        return True
    timers = getattr(getattr(bpy, "app", None), "timers", None)
    checker = getattr(timers, "is_registered", None) if timers is not None else None
    try:
        if timers is not None and (not callable(checker) or checker(callback)):
            timers.unregister(callback)
    except Exception:
        pass
    try:
        if callable(checker) and checker(callback):
            return False
    except Exception:
        return False
    _SFS_HISTORY_REPAIR_CALLBACK = None
    _SFS_HISTORY_REPAIR_DUE = None
    ledger["repair_timer"] = None
    ledger["repair_due"] = None
    return True

def _sf_history_repair_delay() -> float:
    index = min(
        max(0, int(_SFS_HISTORY_REPAIR_FAILURES) - 1),
        len(_SFS_HISTORY_REPAIR_BACKOFF) - 1,
    )
    return float(_SFS_HISTORY_REPAIR_BACKOFF[index])


def _sf_history_schedule_repair(reason: str) -> bool:
    global _SFS_HISTORY_REPAIR_CALLBACK, _SFS_HISTORY_REPAIR_DUE
    global _SFS_HISTORY_PHASE, _SFS_HISTORY_LAST_ERROR
    _SFS_HISTORY_PHASE = "RETRYING"
    _SFS_HISTORY_LAST_ERROR = str(reason or "History lifecycle repair required")[:1024]
    ledger = _sf_history_ledger()
    if not isinstance(ledger, dict) or not _sf_history_is_current_owner():
        return False
    ledger["phase"] = _SFS_HISTORY_PHASE
    ledger["last_error"] = _SFS_HISTORY_LAST_ERROR

    # Repair is a bounded series of generation-owned one-shots, never an
    # indefinite health poll.  A settings/lifecycle state-change event can call
    # _sf_history_request_repair() to begin a fresh bounded series.
    if (
        _SFS_HISTORY_REPAIR_CALLBACK is None
        and _SFS_HISTORY_REPAIR_FAILURES >= _SFS_HISTORY_REPAIR_MAX_ATTEMPTS
    ):
        _SFS_HISTORY_PHASE = "ERROR"
        ledger["phase"] = _SFS_HISTORY_PHASE
        ledger["repair_timer"] = None
        ledger["repair_due"] = None
        return False

    callback = _SFS_HISTORY_REPAIR_CALLBACK
    record = ledger.get("repair_timer")
    try:
        checker = getattr(bpy.app.timers, "is_registered", None)
        if (
            callback is not None
            and isinstance(record, dict)
            and record.get("callback") is callback
            and record.get("token") is _SFS_HISTORY_OWNER_TOKEN
            and record.get("generation") == _SFS_HISTORY_GENERATION
            and callable(checker)
            and checker(callback)
        ):
            return True
    except Exception:
        pass
    if callback is not None and not _sf_history_cancel_repair_timer():
        return False

    token = _SFS_HISTORY_OWNER_TOKEN
    generation = _SFS_HISTORY_GENERATION
    delay = max(2.0, _sf_history_repair_delay())

    def repair_callback():
        global _SFS_HISTORY_REPAIR_FAILURES, _SFS_HISTORY_REPAIR_DUE
        global _SFS_HISTORY_REPAIR_CALLBACK, _SFS_HISTORY_REPAIR_RUNNING
        current = _sf_history_ledger()
        current_record = current.get("repair_timer") if isinstance(current, dict) else None
        if not (
            isinstance(current, dict)
            and current.get("token") is token
            and current.get("generation") == generation
            and isinstance(current_record, dict)
            and current_record.get("callback") is repair_callback
            and current_record.get("token") is token
            and current_record.get("generation") == generation
        ):
            if _SFS_HISTORY_REPAIR_CALLBACK is repair_callback:
                _SFS_HISTORY_REPAIR_CALLBACK = None
                _SFS_HISTORY_REPAIR_DUE = None
            return None
        # Consume this exact timer identity before doing repair work. Failure is
        # re-armed as a fresh generation-owned one-shot callback.
        _SFS_HISTORY_REPAIR_CALLBACK = None
        _SFS_HISTORY_REPAIR_DUE = None
        current["repair_timer"] = None
        current["repair_due"] = None
        _SFS_HISTORY_REPAIR_RUNNING = True
        try:
            if _sf_history_repair_once():
                return None
            _SFS_HISTORY_REPAIR_FAILURES += 1
            _sf_history_schedule_repair(_SFS_HISTORY_LAST_ERROR or "History lifecycle repair retry")
            return None
        finally:
            _SFS_HISTORY_REPAIR_RUNNING = False

    _SFS_HISTORY_REPAIR_CALLBACK = repair_callback
    last_error = ""
    for _attempt in range(2):
        try:
            bpy.app.timers.register(
                repair_callback,
                first_interval=delay,
                persistent=False,
            )
            checker = getattr(bpy.app.timers, "is_registered", None)
            if callable(checker) and not checker(repair_callback):
                raise RuntimeError("History repair timer registration was not retained")
            _SFS_HISTORY_REPAIR_DUE = time.monotonic() + delay
            ledger["repair_timer"] = {
                "callback": repair_callback,
                "token": token,
                "generation": generation,
                "due": _SFS_HISTORY_REPAIR_DUE,
                "one_shot": True,
                "remover": _sf_history_cancel_repair_timer,
            }
            ledger["repair_due"] = _SFS_HISTORY_REPAIR_DUE
            return True
        except Exception as exc:
            last_error = _sf_history_error(exc)
    _SFS_HISTORY_LAST_ERROR = (
        f"{_SFS_HISTORY_LAST_ERROR}; repair timer: {last_error}"
    )[:1024]
    ledger["last_error"] = _SFS_HISTORY_LAST_ERROR
    ledger["repair_timer"] = None
    ledger["repair_due"] = None
    _SFS_HISTORY_REPAIR_CALLBACK = None
    _SFS_HISTORY_REPAIR_DUE = None
    return False

def _sf_history_release_owned(
    *,
    remove_ledger: bool,
    include_runtime: bool,
    runtime_save_pending: bool = False,
    runtime_reason: str = "lifecycle_repair",
) -> bool:
    global _SFS_HISTORY_CLASS_RECORDS, _SFS_HISTORY_POINTER_RECORDS
    global _SFS_HISTORY_I18N_REGISTERED, _SFS_HISTORY_PHASE
    ok = True
    if include_runtime:
        try:
            from .history_auto_save.core import crash_recovery as _sfs_crash_recovery
            _sfs_crash_recovery.cleanup_owned_resources()
        except Exception:
            ok = False
        try:
            if _sfs_hist_runtime.unregister_runtime(
                save_pending=bool(runtime_save_pending),
                reason=str(runtime_reason),
            ) is False:
                ok = False
        except Exception:
            ok = False
        try:
            if _sfs_hist_runtime.unbind_lifecycle_owner(
                _SFS_HISTORY_OWNER_TOKEN, _SFS_HISTORY_GENERATION
            ) is False:
                ok = False
        except Exception:
            ok = False
    for record in reversed(tuple(_SFS_HISTORY_POINTER_RECORDS)):
        if record.get("role") == "canonical_settings_authority":
            continue
        if not _sf_history_delete_owned_pointer(record):
            ok = False
    _SFS_HISTORY_POINTER_RECORDS = []
    for record in reversed(tuple(_SFS_HISTORY_CLASS_RECORDS)):
        if not _sf_history_unregister_class_exact(record):
            ok = False
    _SFS_HISTORY_CLASS_RECORDS = []
    if _SFS_HISTORY_I18N_REGISTERED:
        try:
            _sfs_hist_i18n.unregister()
        except Exception:
            ok = False
        _SFS_HISTORY_I18N_REGISTERED = False
    if remove_ledger:
        _sf_history_cancel_repair_timer()
        namespace = _sf_history_namespace()
        if namespace is not None:
            ledger = namespace.get(_SFS_HISTORY_OWNER_KEY)
            if isinstance(ledger, dict) and ledger.get("token") is _SFS_HISTORY_OWNER_TOKEN:
                namespace.pop(_SFS_HISTORY_OWNER_KEY, None)
        _SFS_HISTORY_PHASE = "IDLE"
    return ok

def _sf_history_cleanup_previous_owner(ledger) -> bool:
    if not isinstance(ledger, dict):
        return True
    cleanup = ledger.get("cleanup")
    if not callable(cleanup):
        return False
    try:
        try:
            return bool(cleanup(ledger.get("token"), ledger.get("generation")))
        except TypeError:
            return bool(cleanup())
    except Exception:
        return False


def _sf_history_cleanup_generation(token=None, generation=None) -> bool:
    if token is not None and token is not _SFS_HISTORY_OWNER_TOKEN:
        return True
    if generation is not None and generation != _SFS_HISTORY_GENERATION:
        return True
    return _sf_history_release_owned(remove_ledger=True, include_runtime=True, runtime_save_pending=False, runtime_reason="reload")


def _sf_history_acquire_owner_ledger() -> bool:
    """Acquire the generation ledger after cleaning only prior owned resources."""
    global _SFS_HISTORY_PHASE, _SFS_HISTORY_LAST_ERROR
    namespace = _sf_history_namespace()
    if namespace is None:
        _SFS_HISTORY_PHASE = "ERROR"
        _SFS_HISTORY_LAST_ERROR = "bpy.app.driver_namespace is unavailable"
        return False

    for key in _SFS_HISTORY_LEGACY_OWNER_KEYS:
        previous = namespace.get(key)
        if previous is None:
            continue
        if not _sf_history_cleanup_previous_owner(previous):
            _SFS_HISTORY_PHASE = "RETRYING"
            _SFS_HISTORY_LAST_ERROR = f"Legacy History owner cleanup failed: {key}"
            return False
        namespace.pop(key, None)

    previous = namespace.get(_SFS_HISTORY_OWNER_KEY)
    if isinstance(previous, dict) and previous.get("token") is not _SFS_HISTORY_OWNER_TOKEN:
        if not _sf_history_cleanup_previous_owner(previous):
            _SFS_HISTORY_PHASE = "RETRYING"
            _SFS_HISTORY_LAST_ERROR = "Previous History generation cleanup failed"
            return False
        namespace.pop(_SFS_HISTORY_OWNER_KEY, None)

    if not _sf_history_is_current_owner():
        namespace[_SFS_HISTORY_OWNER_KEY] = {
            "schema": 3,
            "generation": _SFS_HISTORY_GENERATION,
            "token": _SFS_HISTORY_OWNER_TOKEN,
            "owner_module": __name__,
            "phase": "REGISTERING",
            "last_error": "",
            # Blender clears driver_namespace while loading a file, but the
            # registered RNA identities and these immutable ownership records
            # remain live. Reattach them instead of trying to register a second
            # Python class generation.
            "classes": tuple(_SFS_HISTORY_CLASS_RECORDS),
            "pointers": tuple(_SFS_HISTORY_POINTER_RECORDS),
            "repair_timer": None,
            "repair_due": None,
            "cleanup": _sf_history_cleanup_generation,
        }
    return _sf_history_is_current_owner()


def _sf_history_reattach_load_survivor_ledger() -> bool:
    """Recreate only this generation's ledger after Blender clears namespace."""
    namespace = _sf_history_namespace()
    if namespace is None:
        return False
    previous = namespace.get(_SFS_HISTORY_OWNER_KEY)
    if isinstance(previous, dict):
        return bool(
            previous.get("token") is _SFS_HISTORY_OWNER_TOKEN
            and previous.get("generation") == _SFS_HISTORY_GENERATION
            and previous.get("owner_module") == __name__
        )
    if previous is not None:
        return False
    if not (
        _sf_history_main_preferences_ready()
        and _sf_history_surviving_class_records_ok()
        and _sf_history_surviving_pointer_records_ok()
    ):
        return False
    namespace[_SFS_HISTORY_OWNER_KEY] = {
        "schema": 3,
        "generation": _SFS_HISTORY_GENERATION,
        "token": _SFS_HISTORY_OWNER_TOKEN,
        "owner_module": __name__,
        "phase": _SFS_HISTORY_PHASE or "LOAD_REATTACHED",
        "last_error": _SFS_HISTORY_LAST_ERROR,
        "classes": tuple(_SFS_HISTORY_CLASS_RECORDS),
        "pointers": tuple(_SFS_HISTORY_POINTER_RECORDS),
        "repair_timer": None,
        "repair_due": None,
        "cleanup": _sf_history_cleanup_generation,
    }
    valid = bool(
        _sf_history_is_current_owner()
        and _sf_history_class_records_ok()
        and _sf_history_pointer_records_ok()
    )
    if not valid:
        current = namespace.get(_SFS_HISTORY_OWNER_KEY)
        if isinstance(current, dict) and current.get("token") is _SFS_HISTORY_OWNER_TOKEN:
            namespace.pop(_SFS_HISTORY_OWNER_KEY, None)
    return valid


def _sf_history_prepare_dependencies() -> bool:
    """Register History PropertyGroups before the canonical settings class.

    Required order:
    UHM_HistoryEntry -> UHM_SceneSettings ->
    SFS_PG_history_history_preferences ->
    SFS_PG_system_file_suite_preferences (registered by core) -> pointers.
    """
    global _SFS_HISTORY_CLASS_RECORDS, _SFS_HISTORY_I18N_REGISTERED
    global _SFS_HISTORY_PHASE, _SFS_HISTORY_LAST_ERROR
    if not _sf_history_acquire_owner_ledger():
        return False
    if _sf_history_dependency_records_ok():
        return True

    # A partial record set can only belong to this generation.  Release exactly
    # what this owner acquired before retrying the dependency transaction.
    if _SFS_HISTORY_CLASS_RECORDS or _SFS_HISTORY_POINTER_RECORDS:
        _sf_history_release_owned(
            remove_ledger=False,
            include_runtime=True,
            runtime_save_pending=False,
            runtime_reason="dependency_repair",
        )

    acquired_i18n = False
    local_records: list[dict[str, Any]] = []
    try:
        if not _SFS_HISTORY_I18N_REGISTERED:
            _sfs_hist_i18n.register()
            _SFS_HISTORY_I18N_REGISTERED = True
            acquired_i18n = True
        for cls in _SFS_HISTORY_DEPENDENCY_CLASSES:
            _ok, acquired = _sf_history_register_class_exact(cls)
            local_records.append({
                "class": cls,
                "acquired": acquired,
                "role": "dependency",
                "token": _SFS_HISTORY_OWNER_TOKEN,
                "generation": _SFS_HISTORY_GENERATION,
            })
        _SFS_HISTORY_CLASS_RECORDS = local_records
        ledger = _sf_history_ledger()
        if isinstance(ledger, dict):
            ledger["classes"] = tuple(_SFS_HISTORY_CLASS_RECORDS)
            ledger["phase"] = "DEPENDENCIES_READY"
            ledger["last_error"] = ""
        if not _sf_history_dependency_records_ok():
            raise RuntimeError("History dependency exact-identity validation failed")
        _SFS_HISTORY_PHASE = "DEPENDENCIES_READY"
        _SFS_HISTORY_LAST_ERROR = ""
        return True
    except Exception as exc:
        for record in reversed(local_records):
            _sf_history_unregister_class_exact(record)
        _SFS_HISTORY_CLASS_RECORDS = []
        if acquired_i18n:
            try:
                _sfs_hist_i18n.unregister()
            except Exception:
                pass
            _SFS_HISTORY_I18N_REGISTERED = False
        _SFS_HISTORY_PHASE = "ERROR"
        _SFS_HISTORY_LAST_ERROR = _sf_history_error(exc)
        ledger = _sf_history_ledger()
        if isinstance(ledger, dict):
            ledger["classes"] = ()
            ledger["phase"] = _SFS_HISTORY_PHASE
            ledger["last_error"] = _SFS_HISTORY_LAST_ERROR
        return False


def _sf_history_install_owned_resources() -> None:
    global _SFS_HISTORY_CLASS_RECORDS, _SFS_HISTORY_POINTER_RECORDS
    global _SFS_HISTORY_I18N_REGISTERED
    if not _sf_history_prepare_dependencies():
        raise RuntimeError(_SFS_HISTORY_LAST_ERROR or "History dependency registration failed")
    if not _sf_history_main_preferences_ready():
        raise RuntimeError("Canonical Smart File preferences class is not RNA-ready")

    if len(_SFS_HISTORY_CLASS_RECORDS) > len(_SFS_HISTORY_DEPENDENCY_CLASSES):
        if not _sf_history_class_records_ok():
            raise RuntimeError("History runtime class records are partially registered")
    else:
        new_class_records: list[dict[str, Any]] = []
        try:
            for cls in _SFS_HISTORY_RUNTIME_CLASSES:
                _ok, acquired = _sf_history_register_class_exact(cls)
                record = {
                    "class": cls,
                    "acquired": acquired,
                    "role": "runtime_ui",
                    "token": _SFS_HISTORY_OWNER_TOKEN,
                    "generation": _SFS_HISTORY_GENERATION,
                }
                _SFS_HISTORY_CLASS_RECORDS.append(record)
                new_class_records.append(record)
        except Exception:
            for record in reversed(new_class_records):
                _sf_history_unregister_class_exact(record)
                if record in _SFS_HISTORY_CLASS_RECORDS:
                    _SFS_HISTORY_CLASS_RECORDS.remove(record)
            raise

    if _SFS_HISTORY_POINTER_RECORDS and _sf_history_pointer_records_ok():
        ledger = _sf_history_ledger()
        if isinstance(ledger, dict):
            ledger["classes"] = tuple(_SFS_HISTORY_CLASS_RECORDS)
            ledger["pointers"] = tuple(_SFS_HISTORY_POINTER_RECORDS)
        return

    local_pointers: list[dict[str, Any]] = []
    try:
        local_pointers.append(_sf_history_assign_pointer(
            bpy.types.Scene,
            "uhm_settings",
            bpy.props.PointerProperty(
                type=UHM_SceneSettings,
                name="History Settings",
                description=(
                    "Scene-level settings for Smart File history protection, "
                    "restore points, and autosave behavior."
                ),
            ),
            role="scene_history",
            expected_type=UHM_SceneSettings,
        ))
        local_pointers.append(_sf_history_assign_pointer(
            bpy.types.WindowManager,
            "uhm_addon_settings",
            bpy.props.PointerProperty(
                type=SFS_PG_history_history_preferences,
                name="History Legacy Migration Settings",
                description=(
                    "One-time legacy migration source. The live runtime and "
                    "persistence use sf_addon_settings exclusively."
                ),
            ),
            role="legacy_migration_source",
            expected_type=SFS_PG_history_history_preferences,
        ))
        local_pointers.append(_sf_history_canonical_settings_record())
        _SFS_HISTORY_POINTER_RECORDS = local_pointers
        ledger = _sf_history_ledger()
        if isinstance(ledger, dict):
            ledger["classes"] = tuple(_SFS_HISTORY_CLASS_RECORDS)
            ledger["pointers"] = tuple(_SFS_HISTORY_POINTER_RECORDS)
        if not (_sf_history_class_records_ok() and _sf_history_pointer_records_ok()):
            raise RuntimeError("History class/pointer exact-identity validation failed")
    except Exception:
        for record in reversed(local_pointers):
            if record.get("role") != "canonical_settings_authority":
                _sf_history_delete_owned_pointer(record)
        _SFS_HISTORY_POINTER_RECORDS = []
        raise


def _sf_history_runtime_exact_ok(context=None) -> bool:
    """Validate exact runtime resources without misreporting RETRYING as ACTIVE."""
    try:
        status = _sfs_hist_runtime.get_runtime_status(context)
    except Exception:
        return False
    if not status.get("registered"):
        return False
    if status.get("requested_enabled"):
        return bool(
            str(status.get("phase") or "") == "ACTIVE"
            and status.get("watching")
            and status.get("handlers_ok")
            and status.get("timer_ok")
            and status.get("settings_owner_ok")
            and status.get("lifecycle_owner_ok", status.get("lifecycle_ok"))
            and int(status.get("handler_count", 0) or 0)
                == int(status.get("required_handler_count", 0) or 0)
            and status.get("timer_registered")
        )
    return bool(
        str(status.get("phase") or "") == "DISABLED"
        and not status.get("timer_registered")
        and int(status.get("handler_count", 0) or 0) == 0
        and not status.get("watching")
    )


def _sf_history_repair_once(context=None) -> bool:
    global _SFS_HISTORY_PHASE, _SFS_HISTORY_LAST_ERROR, _SFS_HISTORY_REPAIR_FAILURES
    if not _sf_history_is_current_owner():
        return False
    try:
        if not _sf_history_settings_registration_ok():
            from . import settings as _sfs_settings
            ensure = getattr(_sfs_settings, "ensure_runtime", None)
            if not callable(ensure) or not ensure(context, apply_saved=False):
                status_fn = getattr(_sfs_settings, "runtime_status", None)
                status = status_fn(context) if callable(status_fn) else {}
                raise RuntimeError(status.get("last_error") or "canonical settings owner repair failed")
        if not (_sf_history_class_records_ok() and _sf_history_pointer_records_ok()):
            _sf_history_release_owned(remove_ledger=False, include_runtime=True, runtime_save_pending=False, runtime_reason="lifecycle_repair")
            _sf_history_install_owned_resources()
            ledger = _sf_history_ledger()
            if isinstance(ledger, dict):
                ledger["classes"] = tuple(_SFS_HISTORY_CLASS_RECORDS)
                ledger["pointers"] = tuple(_SFS_HISTORY_POINTER_RECORDS)
        if not _sfs_hist_runtime.bind_lifecycle_owner(
            _SFS_HISTORY_OWNER_TOKEN,
            _SFS_HISTORY_GENERATION,
            _sf_history_lifecycle_validator,
        ):
            raise RuntimeError("History runtime lifecycle owner binding failed")
        if not _sfs_hist_runtime.register_runtime():
            status = _sfs_hist_runtime.get_runtime_status(context)
            raise RuntimeError(
                status.get("last_runtime_error")
                or status.get("last_save_error")
                or "History runtime synchronization failed"
            )
        if not _sf_history_runtime_exact_ok(context):
            status = _sfs_hist_runtime.get_runtime_status(context)
            raise RuntimeError(
                status.get("last_runtime_error")
                or status.get("last_save_error")
                or "History runtime exact-resource verification failed"
            )
        from .history_auto_save.core import crash_recovery as _sfs_crash_recovery
        if not bool(_sfs_crash_recovery.register_owned_resources(context)):
            raise RuntimeError("Crash recovery transient scene hygiene registration failed")
        runtime_status = _sfs_hist_runtime.get_runtime_status(context)
        runtime_phase = str(runtime_status.get("phase") or "ERROR")
        _SFS_HISTORY_PHASE = runtime_phase
        _SFS_HISTORY_LAST_ERROR = str(
            runtime_status.get("last_runtime_error")
            or runtime_status.get("last_save_error")
            or ""
        )
        _SFS_HISTORY_REPAIR_FAILURES = 0
        ledger = _sf_history_ledger()
        if isinstance(ledger, dict):
            ledger["phase"] = _SFS_HISTORY_PHASE
            ledger["last_error"] = _SFS_HISTORY_LAST_ERROR
        # Structural resources are exact. Runtime-owned deadline/backoff handles
        # save/blocker RETRYING; an integration repair timer would be duplicate.
        _sf_history_cancel_repair_timer()
        return True
    except Exception as exc:
        _SFS_HISTORY_LAST_ERROR = _sf_history_error(exc)
        if not _SFS_HISTORY_REPAIR_RUNNING:
            _sf_history_schedule_repair(_SFS_HISTORY_LAST_ERROR)
        return False


def _sf_history_register() -> bool:
    """Sole registration entry for History classes, pointers and runtime."""
    global _SFS_HISTORY_PHASE, _SFS_HISTORY_LAST_ERROR
    if not _sf_history_prepare_dependencies():
        return False
    try:
        _sf_history_install_owned_resources()
    except Exception as exc:
        _SFS_HISTORY_LAST_ERROR = _sf_history_error(exc)
        _SFS_HISTORY_PHASE = "RETRYING"
        _sf_history_release_owned(
            remove_ledger=False,
            include_runtime=True,
            runtime_save_pending=False,
            runtime_reason="lifecycle_repair",
        )
        _sf_history_schedule_repair(_SFS_HISTORY_LAST_ERROR)
        return False
    return _sf_history_repair_once(getattr(bpy, "context", None))


def _sf_history_request_repair(reason: str = "runtime synchronization failed") -> bool:
    global _SFS_HISTORY_REPAIR_FAILURES
    # This entry point is called by an explicit settings/lifecycle event.  It is
    # therefore allowed to re-arm one fresh bounded repair sequence after the
    # previous sequence stopped; no timer re-arms itself indefinitely.
    if _SFS_HISTORY_REPAIR_CALLBACK is None and _SFS_HISTORY_REPAIR_FAILURES >= _SFS_HISTORY_REPAIR_MAX_ATTEMPTS:
        _SFS_HISTORY_REPAIR_FAILURES = 0
    if not _sf_history_is_current_owner():
        if _sf_history_register():
            return True
        if not _sf_history_is_current_owner():
            return False
    if _sf_history_repair_once(getattr(bpy, "context", None)):
        return True
    return _sf_history_schedule_repair(reason or _SFS_HISTORY_LAST_ERROR)

def _sf_history_pre_unregister() -> bool:
    if not _sf_history_is_current_owner():
        return True
    try:
        return bool(
            _sfs_hist_runtime.unregister_runtime(
                save_pending=True,
                reason="unregister",
            )
        )
    except Exception as exc:
        global _SFS_HISTORY_LAST_ERROR, _SFS_HISTORY_PHASE
        _SFS_HISTORY_LAST_ERROR = _sf_history_error(exc)
        _SFS_HISTORY_PHASE = "ERROR"
        return False


def _sf_history_post_unregister() -> bool:
    if not _sf_history_is_current_owner():
        return True
    try:
        from .history_auto_save.core import crash_recovery as _sfs_crash_recovery
        _sfs_crash_recovery.cleanup_owned_resources()
    except Exception:
        return False
    return _sf_history_release_owned(remove_ledger=True, include_runtime=False)


def _sf_history_unregister() -> bool:
    pre_ok = _sf_history_pre_unregister()
    post_ok = _sf_history_post_unregister()
    return bool(pre_ok and post_ok)


def _sf_history_repair_timer_exact() -> bool:
    callback = _SFS_HISTORY_REPAIR_CALLBACK
    ledger = _sf_history_ledger()
    record = ledger.get("repair_timer") if isinstance(ledger, dict) else None
    if not (
        callback is not None
        and isinstance(record, dict)
        and record.get("callback") is callback
        and record.get("token") is _SFS_HISTORY_OWNER_TOKEN
        and record.get("generation") == _SFS_HISTORY_GENERATION
        and record.get("one_shot") is True
    ):
        return False
    try:
        checker = getattr(bpy.app.timers, "is_registered", None)
        return bool(checker(callback)) if callable(checker) else True
    except Exception:
        return False


def _sf_history_status(context=None) -> dict[str, Any]:
    owner_ok = _sf_history_is_current_owner()
    classes_ok = _sf_history_class_records_ok() if owner_ok else False
    pointers_ok = _sf_history_pointer_records_ok() if owner_ok else False
    settings_ok = _sf_history_settings_registration_ok() if owner_ok else False
    try:
        runtime = _sfs_hist_runtime.get_runtime_status(context)
    except Exception as exc:
        runtime = {
            "registered": False,
            "phase": "ERROR",
            "requested_enabled": False,
            "enabled": False,
            "watching": False,
            "last_runtime_error": _sf_history_error(exc),
            "last_save_error": "",
        }
    structural_runtime = _sf_history_runtime_exact_ok(context) if owner_ok else False
    exact = bool(owner_ok and classes_ok and pointers_ok and settings_ok and structural_runtime)
    phase = str(runtime.get("phase") or ( _sf_history_ledger() or {}).get("phase") or _SFS_HISTORY_PHASE or "ERROR")
    active = bool(exact and phase == "ACTIVE" and runtime.get("watching"))
    ledger = _sf_history_ledger()
    return {
        "registered": exact,
        "phase": phase,
        "active": active,
        "retrying": bool(
            owner_ok
            and phase in {"RETRYING", "RESTORING", "STARTING", "ERROR"}
            and (structural_runtime or _SFS_HISTORY_REPAIR_CALLBACK is not None)
        ),
        "owner_generation": _SFS_HISTORY_GENERATION,
        "owner_ok": owner_ok,
        "class_identities_ok": classes_ok,
        "class_count": len(_SFS_HISTORY_CLASS_RECORDS),
        "expected_class_count": len(_SFS_HISTORY_CLASSES),
        "pointer_identities_ok": pointers_ok,
        "pointer_count": len(_SFS_HISTORY_POINTER_RECORDS),
        "settings_registration_ok": settings_ok,
        "runtime_registered": bool(runtime.get("registered")),
        "requested_enabled": bool(runtime.get("requested_enabled")),
        "enabled": active,
        "watching": active,
        "handlers_ok": bool(runtime.get("handlers_ok")),
        "timer_ok": bool(runtime.get("timer_ok")),
        "settings_owner_ok": bool(runtime.get("settings_owner_ok")),
        "lifecycle_ok": bool(runtime.get("lifecycle_owner_ok", runtime.get("lifecycle_ok"))),
        "last_runtime_error": str(
            _SFS_HISTORY_LAST_ERROR or runtime.get("last_runtime_error") or ""
        ),
        "last_save_error": str(runtime.get("last_save_error") or ""),
        "retrying_reason": str(
            _SFS_HISTORY_LAST_ERROR or runtime.get("retrying_reason") or ""
        ),
        "next_retry_condition": str(runtime.get("next_retry_condition") or ""),
        "repair_timer_registered": _sf_history_repair_timer_exact(),
        "repair_timer_one_shot": bool(
            isinstance((ledger or {}).get("repair_timer"), dict)
            and (ledger or {}).get("repair_timer", {}).get("one_shot") is True
        ) if _SFS_HISTORY_REPAIR_CALLBACK is not None else True,
        "repair_due": _SFS_HISTORY_REPAIR_DUE,
        "repair_attempts": int(_SFS_HISTORY_REPAIR_FAILURES),
        "repair_max_attempts": int(_SFS_HISTORY_REPAIR_MAX_ATTEMPTS),
        "repair_bounded": True,
    }


__all__ = [
    "SMART_FILE_SUITE_VERSION",
    "draw_history_popup_ui",
    "_sf_history_prepare_dependencies",
    "_sf_history_register",
    "_sf_history_pre_unregister",
    "_sf_history_post_unregister",
    "_sf_history_unregister",
    "_sf_history_request_repair",
    "_sf_history_status",
]


