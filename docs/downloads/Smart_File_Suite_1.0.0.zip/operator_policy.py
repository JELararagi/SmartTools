# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Smart File Operator registration policy.

Only exact Smart File package classes passed by Smart File's own registration
helpers are inspected.  Blender APIs and foreign classes are never patched or
scanned.
"""
from __future__ import annotations

from collections.abc import Iterable

import bpy


def _is_suite_owned_class(cls: type) -> bool:
    package_name = str(__package__ or "").strip()
    module_name = str(getattr(cls, "__module__", "") or "").strip()
    return bool(
        package_name
        and module_name
        and (module_name == package_name or module_name.startswith(package_name + "."))
    )


def prepare_operator_class(cls: type):
    """Remove only ``REGISTER`` from Suite-owned undoable Operators.

    ``UNDO`` and every other option remain unchanged, so undo behavior, modal
    execution, property dialogs, presets, and internal flags keep their existing
    contracts while Blender's Adjust Last Operation panel is suppressed.
    """
    if not isinstance(cls, type) or not _is_suite_owned_class(cls):
        return cls
    try:
        operator_base = getattr(bpy.types, "Operator", None)
        if not isinstance(operator_base, type) or not issubclass(cls, operator_base):
            return cls
        options = set(getattr(cls, "bl_options", set()) or set())
        if "REGISTER" in options and "UNDO" in options:
            options.discard("REGISTER")
            cls.bl_options = options
    except Exception:
        # Registration remains authoritative; unsupported/foreign class objects
        # pass through unchanged instead of affecting another Blender owner.
        return cls
    return cls


def prepare_operator_classes(classes: Iterable[type] | None) -> tuple[type, ...]:
    prepared = []
    for cls in tuple(classes or ()):
        prepared.append(prepare_operator_class(cls))
    return tuple(prepared)


__all__ = ["prepare_operator_class", "prepare_operator_classes"]
