# SPDX-License-Identifier: GPL-3.0-or-later
"""Adjust Smart File operator options before Blender registration."""

import bpy

__all__ = ["prepare_operator_class", "prepare_operator_classes"]


def prepare_operator_class(cls):
    if not isinstance(cls, type) or not issubclass(cls, bpy.types.Operator):
        return cls
    owner = cls.__module__
    if owner != __package__ and not owner.startswith(__package__ + "."):
        return cls
    options = getattr(cls, "bl_options", ())
    if {"UNDO", "REGISTER"}.issubset(options):
        cls.bl_options = set(options).difference({"REGISTER"})
    return cls


def prepare_operator_classes(classes):
    if classes is None:
        return ()
    return tuple(prepare_operator_class(operator) for operator in classes)
