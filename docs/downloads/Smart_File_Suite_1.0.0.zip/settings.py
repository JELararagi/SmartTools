# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import copy
import json
import os
import shutil
import time
import uuid
from pathlib import Path
from typing import Any

import bpy

from .storage_paths import user_default_dir

try:
    from bpy.app.handlers import persistent
except Exception:  # pragma: no cover
    def persistent(fn):
        return fn

_CONFIG_DIR_NAME = 'Smart_File_Suite'
_CONFIG_FILE_NAME = 'Smart_File_Suite.json'
_AUTOSAVE_CONTROL_FILE_NAME = 'Smart_File_Autosave_Control.json'
_CONFIG_TEXT_FILE_NAMES = ('bookmarks.txt', 'recent-files.txt')
_LAST_SIGNATURE = ''
_APPLYING = False
_STARTUP_RESTORE_PENDING = False
_HANDLER_ACTIVE = False
_SAVE_HANDLER_ACTIVE = False
_LOAD_PRE_HANDLER_ACTIVE = False
_LAST_SCENE_ID = ''
_APPLY_GUARD_KEY = 'smart_file_suite_settings_apply_suspended'
_GROUP_UI_STATE_KEY = 'smart_file_suite_group_ui_state_v1'
_CORE_DATA_KEYS = {
    'version',
    'window_manager',
    'window_manager_pointers',
    'preferences',
    'preferences_collections',
    'scene_defaults',
    'scene_pointers',
    'ui_section_state',
    'feature_toggles',
    'window_manager_direct',
    'scene_direct',
}

# Scene-level pointers are stored by Blender inside each .blend already. The
# user_default settings keeper must not globally replay runtime object links from
# a previous file.  In particular, Decentraland thumbnail object names can point
# at cameras/empties/lights; replaying them during load can fire update callbacks
# and move those objects back to an old computed transform.
_SCENE_RUNTIME_EXCLUDE_NAMES_BY_POINTER = {
    # History project identity and row state belong to the .blend that owns
    # them. Replaying these values from the process-global JSON settings file
    # can route a newly loaded/unsaved file into the previous project's
    # autosave namespace and expose foreign restore rows.
    'uhm_settings': {
        'project_key',
        'active_index',
        'entries',
    },
    'dcl_tools': {
        'thumbnail_camera_name',
        'thumbnail_target_name',
    },
}

_WM_INCLUDE_PREFIXES = ('sf_', 'smart_file_suite_')
_WM_EXCLUDE_PREFIXES = (
    'sf_last_',
    'sf_ar_dep_',
    'sf_ar_cat_raw_',
    'sf_ar_cat_tag_cloud_',
    'sf_activity_log',
)
_WM_EXCLUDE_NAMES = {
    'sf_addon_settings',
    'sf_items', 'sf_ar_items', 'sf_ar_cat_assets', 'sf_ar_cat_versions',
    'sf_ar_catalog_assets', 'sf_ar_catalog_versions',
    'sf_rm_items', 'sf_rm_candidates', 'sf_rm_plan', 'sf_rm_plan_items',
    'sf_workspace_profiles', 'sf_cm_review_items', 'sf_library_roots',
    'sf_context_roots', 'sf_shot_presets', 'sf_shot_slots',
    'sf_rep_snapshot_json', 'sf_assembly_snapshot_json',
    'sf_project_guard_scene_state_json',
}
_WM_DIRECT_SETTING_NAMES = ('ikea_search',)
_SCENE_DIRECT_SETTING_NAMES = ('texmgr_filter', 'texmgr_directory')
_PREF_EXCLUDE_PREFIXES = ('rna_', 'bl_', '_')
_PREF_EXCLUDE_NAMES = {
    'layout', 'preferences', 'rna_type',
    'recent_paths', 'favorite_paths',
    'cm_override_presets', 'cm_override_routes',
    'workspace_profiles', 'library_roots', 'context_roots',
}
_PREF_COLLECTION_NAMES = (
    'recent_paths',
    'favorite_paths',
    'workspace_profiles',
    'library_roots',
    'context_roots',
    'cm_override_presets',
    'cm_override_routes',
)
_WM_POINTER_SETTING_NAMES = (
    # sf_addon_settings is persisted exclusively by the canonical
    # 'preferences' branch.  It must never be duplicated as a WM pointer.
    'umi_preferences_proxy',
    'ikea_settings_proxy',
    'bulk_asset_tools_preferences_proxy',
)
_SCENE_SETTING_NAMES = ('uhm_settings', 'texmgr_settings', 'reporter_settings', 'dcl_tools', 'vat_settings')
_SCENE_EXCLUDE_NAMES = {'name', 'rna_type', 'layout'}
_STATE_EXCLUDE_PREFIXES = ('rna_', 'bl_', '_')
_STATE_EXCLUDE_NAMES = {'rna_type', 'layout', 'name_full'}
_SETTINGS_OWNER_KEY = 'JELararagi.smart_file.settings.lifecycle.v57540'
_SETTINGS_LEGACY_OWNER_KEYS = (
    'JELararagi.smart_file.settings.lifecycle.v57539',
    'JELararagi.smart_file.settings.lifecycle.v57536',

    'JELararagi.smart_file.settings.lifecycle.v57535',
    'JELararagi.smart_file.settings.lifecycle.v57534',
    'JELararagi.smart_file.settings.lifecycle.v57533',
    'JELararagi.smart_file.settings.lifecycle.v57532',
    'JELararagi.smart_file.settings.lifecycle.v57531',
)
_SETTINGS_OWNER_TOKEN = object()
_SETTINGS_GENERATION = uuid.uuid4().hex
_MSGBUS_OWNER = _SETTINGS_OWNER_TOKEN
_SETTINGS_REGISTERED = False
_SETTINGS_HANDLER_RECORDS = []
_SETTINGS_SUBSCRIPTION_COUNT = 0
_SETTINGS_SUBSCRIPTION_ERRORS = []
_SETTINGS_LAST_ERROR = ''
_SETTINGS_SAVE_DELAY = 0.25
_SETTINGS_SAVE_RETRY_DELAY = 2.0
_SETTINGS_SAVE_TIMER_ACTIVE = False
_SETTINGS_SAVE_DEADLINE = 0.0
_SETTINGS_SAVE_PENDING = False
_KEEPER_OFF_SELF_COMMIT_TOKEN = object()
_KEEPER_OFF_SELF_COMMIT_ACTIVE = False
_LAST_VALID_JSON_BY_PATH: dict[str, dict[str, Any]] = {}
_JSON_READ_ERRORS: dict[str, str] = {}
_AUTOSAVE_SUITE_VERSION = '5.75.96'
_AUTOSAVE_INSTALL_EPOCH = 'smart-file-autosave-default-on-v3:5.75.67'
_AUTOSAVE_CHOICE_SCHEMA = 3
_AUTOSAVE_CHOICE_PENDING: bool | None = None
_AUTOSAVE_CHOICE_TIMER_ACTIVE = False
_AUTOSAVE_CHOICE_RETRY_ATTEMPTS = 0
_AUTOSAVE_CHOICE_RETRY_MAX = 3
_AUTOSAVE_CHOICE_RETRY_DELAY = 2.0


def _version_string() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None)
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def _config_root(create: bool = True) -> Path:
    """Return Blender's versioned config folder."""
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            try:
                value = user_resource('CONFIG', path='', create=create)
            except TypeError:
                value = user_resource('CONFIG', create=create)
            if value:
                path = Path(value)
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
    except Exception:
        pass
    version = _version_string()
    if os.name == 'nt':
        base = Path(os.environ.get('APPDATA', str(Path.home() / 'AppData' / 'Roaming'))) / 'Blender Foundation' / 'Blender' / version / 'config'
    else:
        base = Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'blender' / version / 'config'
    if create:
        try:
            base.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return base

def _config_dir(create: bool = True) -> Path:
    """Return the Smart File Suite settings folder inside Blender config."""
    path = _config_root(create) / _CONFIG_DIR_NAME
    if create:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path

def _config_path() -> Path:
    # Path discovery is read-only.  The authoritative lower writer creates the
    # parent only after restore/OFF authorization has succeeded.
    return _config_dir(False) / _CONFIG_FILE_NAME


def _autosave_control_path() -> Path:
    """Return the keeper-independent explicit autosave choice path."""
    return _config_dir(False) / _AUTOSAVE_CONTROL_FILE_NAME


def _safe_mtime(path: Path) -> float:
    try:
        return float(path.stat().st_mtime)
    except Exception:
        return -1.0


def _copy_text_file_if_needed(src: Path, dst: Path) -> bool:
    tmp: Path | None = None
    try:
        if not src.exists() or not src.is_file():
            return False
        payload = src.read_bytes()
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists() and dst.is_file() and dst.read_bytes() == payload:
            return False
        tmp = dst.with_name(f".{dst.name}.tmp-{os.getpid()}-{uuid.uuid4().hex}")
        with tmp.open('xb') as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        if tmp.read_bytes() != payload:
            raise OSError('text staging readback mismatch')
        os.replace(tmp, dst)
        return dst.read_bytes() == payload
    except Exception:
        if tmp is not None:
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass
        return False


def sync_blender_config_text_files(*, prefer_suite: bool = False) -> bool:
    """Keep Blender file-browser bookmarks/recent lists in Smart_File_Suite config.

    Blender itself still expects these text files at the versioned config root.
    Smart File mirrors them into config/Smart_File_Suite so all Smart File
    runtime settings and related file-browser state stay in one commercial
    package folder without breaking Blender's own file-browser behavior.
    """
    changed = False
    try:
        root = _config_root(True)
        suite = _config_dir(True)
    except Exception:
        return False
    for filename in _CONFIG_TEXT_FILE_NAMES:
        root_file = root / filename
        suite_file = suite / filename
        try:
            if prefer_suite and suite_file.exists() and (not root_file.exists() or _safe_mtime(suite_file) > _safe_mtime(root_file)):
                changed = _copy_text_file_if_needed(suite_file, root_file) or changed
            elif root_file.exists() and (not suite_file.exists() or _safe_mtime(root_file) >= _safe_mtime(suite_file)):
                changed = _copy_text_file_if_needed(root_file, suite_file) or changed
            elif suite_file.exists() and not root_file.exists():
                changed = _copy_text_file_if_needed(suite_file, root_file) or changed
            elif not suite_file.exists():
                try:
                    suite_file.parent.mkdir(parents=True, exist_ok=True)
                    suite_file.touch(exist_ok=True)
                    changed = True
                except Exception:
                    pass
        except Exception:
            pass
    return changed


def _legacy_config_paths() -> tuple[Path, ...]:
    """Older settings locations kept as read-only migration candidates."""
    paths: list[Path] = []

    # Previous direct location requested in earlier builds:
    # <Blender config>/Smart_File_Suite.json
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            try:
                value = user_resource('CONFIG', path='', create=False)
            except TypeError:
                value = user_resource('CONFIG', create=False)
            if value:
                paths.append(Path(value) / _CONFIG_FILE_NAME)
    except Exception:
        pass
    try:
        version = _version_string()
        if os.name == 'nt':
            config_root = Path(os.environ.get('APPDATA', str(Path.home() / 'AppData' / 'Roaming'))) / 'Blender Foundation' / 'Blender' / version / 'config'
        else:
            config_root = Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'blender' / version / 'config'
        paths.append(config_root / _CONFIG_FILE_NAME)
    except Exception:
        pass

    # Older user_default / extension settings paths.
    try:
        paths.append(Path(user_default_dir('settings', create=False)) / 'smart_file_suite_npanel_settings.json')
    except Exception:
        pass
    try:
        paths.append(Path(user_default_dir('settings', create=False)) / _CONFIG_FILE_NAME)
    except Exception:
        pass
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            try:
                old_root = Path(user_resource('CONFIG', path='', create=False))
            except TypeError:
                old_root = Path(user_resource('CONFIG', create=False))
            paths.append(old_root / _CONFIG_FILE_NAME)
    except Exception:
        pass
    try:
        version = _version_string()
        if os.name == 'nt':
            old_root = Path(os.environ.get('APPDATA', str(Path.home() / 'AppData' / 'Roaming'))) / 'Blender Foundation' / 'Blender' / version / 'config'
        else:
            old_root = Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'blender' / version / 'config'
        paths.append(old_root / _CONFIG_FILE_NAME)
    except Exception:
        pass
    try:
        version = _version_string()
        if os.name == 'nt':
            base = Path(os.environ.get('APPDATA', str(Path.home() / 'AppData' / 'Roaming'))) / 'Blender Foundation' / 'Blender' / version / 'extensions' / 'user_default' / 'smart_file_suite' / 'settings'
        else:
            base = Path(os.environ.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'blender' / version / 'extensions' / 'user_default' / 'smart_file_suite' / 'settings'
        paths.append(base / 'smart_file_suite_npanel_settings.json')
        paths.append(base / _CONFIG_FILE_NAME)
    except Exception:
        pass

    unique: list[Path] = []
    seen: set[str] = set()
    new_path = _config_path()
    for path in paths:
        try:
            key = str(path.resolve())
            new_key = str(new_path.resolve())
        except Exception:
            key = str(path)
            new_key = str(new_path)
        if key == new_key:
            continue
        if key not in seen:
            seen.add(key)
            unique.append(path)
    return tuple(unique)

def _json_path_key(path: Path) -> str:
    try:
        return str(path.resolve())
    except Exception:
        return str(path)


def _json_read_failed(path: Path) -> bool:
    return _json_path_key(path) in _JSON_READ_ERRORS


def _settings_write_allowed(*, context=None, off_transition_token=None) -> bool:
    """Authorize a settings write before any lazy RNA, path, or file access."""
    global _SETTINGS_LAST_ERROR
    if _APPLYING or _STARTUP_RESTORE_PENDING:
        _SETTINGS_LAST_ERROR = 'settings write rejected while saved state is being applied'
        return False
    if bool(
        _KEEPER_OFF_SELF_COMMIT_ACTIVE
        and off_transition_token is _KEEPER_OFF_SELF_COMMIT_TOKEN
    ):
        return True
    if not _keeper_enabled(context):
        return False
    return True


def _read_json_file(path: Path) -> dict[str, Any]:
    """Read one JSON object without discarding the last verified value.

    Missing files are a normal fresh-install state.  Malformed, unreadable, or
    non-object files are observable failures: callers receive the most recent
    verified value for that exact path while ``runtime_status`` exposes the
    error.  No read failure is allowed to manufacture an empty replacement
    that a later writer could commit over valid user settings.
    """
    global _SETTINGS_LAST_ERROR
    key = _json_path_key(path)
    try:
        if not path.exists():
            _JSON_READ_ERRORS.pop(key, None)
            return {}
        raw = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(raw, dict):
            raise ValueError('settings JSON root must be an object')
        verified = copy.deepcopy(raw)
        _LAST_VALID_JSON_BY_PATH[key] = verified
        _JSON_READ_ERRORS.pop(key, None)
        return copy.deepcopy(verified)
    except Exception as exc:
        error = f'settings read: {type(exc).__name__}: {exc}'
        _JSON_READ_ERRORS[key] = error
        _SETTINGS_LAST_ERROR = error
        last_valid = _LAST_VALID_JSON_BY_PATH.get(key)
        if isinstance(last_valid, dict):
            return copy.deepcopy(last_valid)
    return {}


def _json_dump_text(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)


def _write_json_atomic(
    path: Path,
    data: Any,
    *,
    context=None,
    off_transition_token=None,
) -> bool:
    """Write one strict UTF-8 JSON transaction without touching user data on failure."""
    global _SETTINGS_LAST_ERROR
    if not _settings_write_allowed(
        context=context,
        off_transition_token=off_transition_token,
    ):
        return False
    tmp: Path | None = None
    try:
        # Existing malformed, non-object, or unreadable settings are never an
        # empty base.  Refuse before mkdir/staging so the original bytes and
        # failure status survive cold process startup as well as warm cache.
        if path.exists():
            _read_json_file(path)
            if _json_read_failed(path):
                return False
        payload = _json_dump_text(data)
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            if path.exists() and path.read_text(encoding='utf-8') == payload:
                return True
        except Exception:
            pass

        tmp = path.with_name(
            f".{path.name}.tmp-{os.getpid()}-{uuid.uuid4().hex}"
        )
        with tmp.open('x', encoding='utf-8', newline='') as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        if tmp.read_text(encoding='utf-8') != payload:
            raise OSError('settings staging readback mismatch')
        os.replace(tmp, path)
        if path.read_text(encoding='utf-8') != payload:
            raise OSError('settings commit readback mismatch')
        key = _json_path_key(path)
        _LAST_VALID_JSON_BY_PATH[key] = copy.deepcopy(data) if isinstance(data, dict) else {}
        _JSON_READ_ERRORS.pop(key, None)
        try:
            directory_fd = os.open(str(path.parent), getattr(os, 'O_RDONLY', 0))
        except Exception:
            directory_fd = None
        if directory_fd is not None:
            try:
                os.fsync(directory_fd)
            except OSError:
                pass
            finally:
                os.close(directory_fd)
        return True
    except Exception as exc:
        _SETTINGS_LAST_ERROR = f'settings atomic write: {type(exc).__name__}: {exc}'
        if tmp is not None:
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass
        return False


def _read_explicit_autosave_choice() -> bool | None:
    """Return only a verified manual choice from the repaired policy epoch.

    Schema-2 records could be produced by non-user property replay and therefore
    cannot prove that the user deliberately disabled autosave.  Schema 3 trusts
    only a current-epoch record explicitly marked as a manual UI/API choice.
    """
    data = _read_json_file(_autosave_control_path())
    if not (
        data.get('schema') == _AUTOSAVE_CHOICE_SCHEMA
        and data.get('explicit_user_choice') is True
        and data.get('manual_user_choice') is True
        and isinstance(data.get('enable_autosave'), bool)
        and data.get('install_epoch') == _AUTOSAVE_INSTALL_EPOCH
        and str(data.get('choice_source') or '') in {'user_ui', 'user_api'}
    ):
        return None
    return bool(data['enable_autosave'])


def _write_explicit_autosave_choice(enabled: bool, *, source: str = 'user_api') -> bool:
    if not _settings_write_allowed():
        return False
    source = str(source or 'user_api')
    if source not in {'user_ui', 'user_api'}:
        source = 'user_api'
    return bool(_write_json_atomic(
        _autosave_control_path(),
        {
            'schema': _AUTOSAVE_CHOICE_SCHEMA,
            'explicit_user_choice': True,
            'manual_user_choice': True,
            'enable_autosave': bool(enabled),
            'suite_version': _AUTOSAVE_SUITE_VERSION,
            'install_epoch': _AUTOSAVE_INSTALL_EPOCH,
            'choice_source': source,
            'choice_recorded_at': time.time(),
        },
    ))


def _commit_autosave_choice_pair(enabled: bool, *, source: str) -> bool:
    """Commit sidecar authority and canonical JSON as one reported transaction.

    The canonical file is validated before the sidecar is touched.  A malformed
    or unreadable canonical file therefore preserves every original byte and
    keeps an explicit failed status even in a cold process with no valid cache.
    """
    if not _settings_write_allowed():
        return False
    canonical = _config_path()
    _read_json_file(canonical)
    if _json_read_failed(canonical):
        return False
    if not _write_explicit_autosave_choice(bool(enabled), source=source):
        return False
    return bool(_materialize_resolved_autosave_choice(
        bool(enabled),
        source='current_epoch_manual_choice',
    ))


def _ensure_default_autosave_policy_record() -> bool:
    """Validate an existing explicit record without writing on enable.

    Fresh-install defaults live in RNA and the canonical main JSON is created
    only by an actual user change.  Existing manual sidecar choices remain
    readable for backward compatibility; old non-manual install-default rows
    never override the new default-OFF contract.
    """
    _read_explicit_autosave_choice()
    return True


def _materialize_resolved_autosave_choice(enabled: bool, *, source: str) -> bool:
    """Keep the canonical JSON aligned with the independent autosave authority."""
    if _APPLYING or _STARTUP_RESTORE_PENDING:
        return True
    if not _keeper_enabled(getattr(bpy, 'context', None)) and not _KEEPER_OFF_SELF_COMMIT_ACTIVE:
        return True
    path = _config_path()
    data = _read_json_file(path)
    data = dict(data) if isinstance(data, dict) else {}
    preferences = data.get('preferences')
    preferences = dict(preferences) if isinstance(preferences, dict) else {}
    meta = data.get('meta')
    meta = dict(meta) if isinstance(meta, dict) else {}
    expected = bool(enabled)
    changed = bool(
        preferences.get('enable_autosave') is not expected
        or meta.get('autosave_choice_schema') != _AUTOSAVE_CHOICE_SCHEMA
        or meta.get('autosave_suite_version') != _AUTOSAVE_SUITE_VERSION
        or meta.get('autosave_install_epoch') != _AUTOSAVE_INSTALL_EPOCH
        or meta.get('autosave_choice_source') != str(source or '')
    )
    if not changed and path.is_file():
        return True
    preferences['enable_autosave'] = expected
    meta['autosave_choice_schema'] = _AUTOSAVE_CHOICE_SCHEMA
    meta['autosave_suite_version'] = _AUTOSAVE_SUITE_VERSION
    meta['autosave_install_epoch'] = _AUTOSAVE_INSTALL_EPOCH
    meta['autosave_choice_source'] = str(source or '')
    meta['autosave_choice_authority'] = _AUTOSAVE_CONTROL_FILE_NAME
    data['preferences'] = preferences
    data['meta'] = meta
    return bool(_write_json_atomic(path, data))


def _autosave_choice_ui_context(context=None) -> bool:
    """Return True only for a visible Smart File property edit surface."""
    try:
        if bool(getattr(getattr(bpy, 'app', None), 'background', False)):
            return False
        context = context or getattr(bpy, 'context', None)
        window = getattr(context, 'window', None)
        area = getattr(context, 'area', None)
        region = getattr(context, 'region', None)
        if window is None or area is None or region is None:
            return False
        area_type = str(getattr(area, 'type', '') or '')
        region_type = str(getattr(region, 'type', '') or '')
        return bool(
            region_type == 'UI'
            or (area_type == 'PREFERENCES' and region_type == 'WINDOW')
        )
    except Exception:
        return False


def handle_autosave_property_update(owner, context=None) -> bool:
    """Accept UI choices; reject non-user attempts to alter autosave authority.

    Configuration replay runs under the existing apply guards.  Outside those
    guards, only a visible N-panel UI edit may create a new manual choice.  Any
    addon/background assignment that conflicts with the current authority is
    immediately restored without changing UI layout or public properties.
    """
    global _APPLYING
    try:
        current = bool(getattr(owner, 'enable_autosave', False))
    except Exception:
        current = False
    if _APPLYING or _STARTUP_RESTORE_PENDING:
        return current
    if not _keeper_enabled(context):
        # Session-only while N-panel State Save is OFF.  The runtime still
        # follows the live value, but no ordinary/direct writer may persist it.
        return current
    if _autosave_choice_ui_context(context):
        if persist_autosave_user_choice(context, current, source='user_ui'):
            return current
    explicit = _read_explicit_autosave_choice()
    data = _read_config_with_legacy()
    preferences = data.get('preferences') if isinstance(data, dict) else None
    stored = preferences.get('enable_autosave') if isinstance(preferences, dict) else None
    expected = bool(explicit) if explicit is not None else (stored if type(stored) is bool else False)
    if current != expected and owner is not None:
        already_applying = bool(_APPLYING)
        if not already_applying:
            _APPLYING = True
            _set_apply_guard(True)
        try:
            setattr(owner, 'enable_autosave', expected)
        except Exception:
            pass
        finally:
            if not already_applying:
                _set_apply_guard(False)
                _APPLYING = False
    _materialize_resolved_autosave_choice(
        expected,
        source='current_epoch_manual_choice' if explicit is not None else 'install_default',
    )
    return expected


def _overlay_autosave_choice(data: Any) -> dict[str, Any]:
    """Resolve autosave from explicit old/current state, otherwise default OFF.

    Legacy/main JSON and schema-1 sidecars had insufficient provenance for
    ``False``.  They are intentionally not trusted as OFF.  A user action in
    this version writes the atomic schema-3 sidecar and is the only OFF
    authority that survives restart.
    """
    result = dict(data) if isinstance(data, dict) else {}
    preferences = result.get('preferences')
    preferences = dict(preferences) if isinstance(preferences, dict) else {}
    explicit = _read_explicit_autosave_choice()
    control_present = False
    try:
        control_present = _autosave_control_path().is_file()
    except Exception:
        control_present = False
    meta = result.get('meta')
    stored = preferences.get('enable_autosave')
    if explicit is not None:
        resolved = bool(explicit)
    elif type(stored) is bool:
        resolved = bool(stored)
    else:
        resolved = False
    preferences['enable_autosave'] = resolved
    meta = dict(meta) if isinstance(meta, dict) else {}
    meta['autosave_choice_schema'] = _AUTOSAVE_CHOICE_SCHEMA
    meta['autosave_suite_version'] = _AUTOSAVE_SUITE_VERSION
    meta['autosave_install_epoch'] = _AUTOSAVE_INSTALL_EPOCH
    meta['autosave_choice_source'] = (
        'current_epoch_sidecar' if explicit is not None
        else ('canonical_existing_value' if type(stored) is bool else 'fresh_install_default_off')
    )
    result['preferences'] = preferences
    result['meta'] = meta
    return result


def _read_config_with_legacy() -> dict[str, Any]:
    # Enabling Smart File must not mirror or rewrite Blender's bookmarks/recent
    # text files.  The canonical JSON is read directly; text-file mirroring is
    # reserved for an explicit settings save.
    path = _config_path()
    data = _read_json_file(path)
    if data:
        return data
    for legacy_path in _legacy_config_paths():
        data = _read_json_file(legacy_path)
        if data:
            # Migration is read-through only.  The canonical file is written
            # by the next authorized user change, never merely by enable/load.
            return data
    return {}


def _ui_section_state() -> dict[str, bool]:
    try:
        state = bpy.app.driver_namespace.get(_GROUP_UI_STATE_KEY)
        if isinstance(state, dict):
            return {str(k): bool(v) for k, v in state.items() if str(k or '').strip()}
    except Exception:
        pass
    return {}


def _apply_ui_section_state(data: Any) -> None:
    if not isinstance(data, dict):
        return
    try:
        bpy.app.driver_namespace[_GROUP_UI_STATE_KEY] = {str(k): bool(v) for k, v in data.items() if str(k or '').strip()}
    except Exception:
        pass


def _set_apply_guard(enabled: bool) -> None:
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if not isinstance(ns, dict):
            return
        if enabled:
            ns[_APPLY_GUARD_KEY] = True
        else:
            ns.pop(_APPLY_GUARD_KEY, None)
    except Exception:
        pass


def _scene_runtime_exclude_names(pointer_name: str) -> set[str]:
    try:
        return set(_SCENE_RUNTIME_EXCLUDE_NAMES_BY_POINTER.get(str(pointer_name or ''), set()))
    except Exception:
        return set()


def _filter_scene_scalar_values(pointer_name: str, values: Any) -> Any:
    if not isinstance(values, dict):
        return values
    excluded = _scene_runtime_exclude_names(pointer_name)
    if not excluded:
        return values
    return {name: value for name, value in values.items() if str(name or '') not in excluded}


def _filter_scene_owner_state(pointer_name: str, state: Any) -> Any:
    if not isinstance(state, dict):
        return state
    excluded = _scene_runtime_exclude_names(pointer_name)
    if not excluded:
        return state
    # Copy shallow containers so callers do not mutate the decoded JSON payload in-place.
    filtered = dict(state)
    scalars = dict(filtered.get('scalars') or {})
    collections = dict(filtered.get('collections') or {})
    for name in excluded:
        scalars.pop(name, None)
        collections.pop(name, None)
    filtered['scalars'] = scalars
    filtered['collections'] = collections
    return filtered


def _json_scalar(value: Any) -> Any:
    if isinstance(value, bool):
        return bool(value)
    if isinstance(value, int) and not isinstance(value, bool):
        return int(value)
    if isinstance(value, float):
        return float(value)
    if isinstance(value, str):
        return str(value)
    try:
        if hasattr(value, 'to_tuple'):
            value = value.to_tuple()
    except Exception:
        pass
    if isinstance(value, (list, tuple)):
        converted = []
        for item in value:
            scalar = _json_scalar(item)
            if scalar is None or isinstance(scalar, (list, dict)):
                return None
            converted.append(scalar)
        return converted
    if not isinstance(value, (str, bytes, bytearray, dict)):
        try:
            seq = list(value)
        except Exception:
            seq = None
        if seq is not None and len(seq) <= 32:
            converted = []
            for item in seq:
                scalar = _json_scalar(item)
                if scalar is None or isinstance(scalar, (list, dict)):
                    return None
                converted.append(scalar)
            return converted
    return None


def _iter_rna_prop_names(owner: Any):
    try:
        props = getattr(getattr(owner, 'bl_rna', None), 'properties', None)
        if props is not None:
            for prop in props:
                ident = str(getattr(prop, 'identifier', '') or '')
                if ident and ident != 'rna_type':
                    yield ident
            return
    except Exception:
        pass
    for name in dir(owner):
        if name.startswith('__'):
            continue
        yield name


def _owner_scalars(owner: Any, *, include_prefixes: tuple[str, ...] = (), exclude_prefixes: tuple[str, ...] = (), exclude_names: set[str] | None = None) -> dict[str, Any]:
    result: dict[str, Any] = {}
    if owner is None:
        return result
    exclude_names = set(exclude_names or ())
    for name in _iter_rna_prop_names(owner):
        if name in exclude_names:
            continue
        if include_prefixes and not name.startswith(include_prefixes):
            continue
        if exclude_prefixes and name.startswith(exclude_prefixes):
            continue
        try:
            value = getattr(owner, name)
        except Exception:
            continue
        scalar = _json_scalar(value)
        if scalar is None:
            continue
        result[name] = scalar
    return result


def _collection_item_scalars(item: Any) -> dict[str, Any]:
    values: dict[str, Any] = {}
    if item is None:
        return values
    for name in _iter_rna_prop_names(item):
        if name in {'rna_type', 'layout'} or name.startswith(('rna_', 'bl_', '_')):
            continue
        try:
            value = getattr(item, name)
        except Exception:
            continue
        scalar = _json_scalar(value)
        if scalar is not None:
            values[name] = scalar
    return values


def _owner_collections(owner: Any, names: tuple[str, ...]) -> dict[str, list[dict[str, Any]]]:
    result: dict[str, list[dict[str, Any]]] = {}
    if owner is None:
        return result
    for name in names:
        try:
            collection = getattr(owner, name, None)
        except Exception:
            collection = None
        if collection is None:
            continue
        rows: list[dict[str, Any]] = []
        try:
            iterator = list(collection)
        except Exception:
            iterator = []
        for item in iterator:
            values = _collection_item_scalars(item)
            if values:
                rows.append(values)
        result[name] = rows
    return result


def _apply_collection(owner: Any, name: str, rows: Any) -> None:
    if owner is None or not isinstance(name, str) or not isinstance(rows, list):
        return
    try:
        collection = getattr(owner, name, None)
    except Exception:
        collection = None
    if collection is None:
        return
    try:
        collection.clear()
    except Exception:
        return
    for row in rows:
        if not isinstance(row, dict):
            continue
        try:
            item = collection.add()
        except Exception:
            break
        for prop_name, value in row.items():
            if not isinstance(prop_name, str) or prop_name == 'rna_type':
                continue
            try:
                if hasattr(item, prop_name) and _json_scalar(value) is not None:
                    setattr(item, prop_name, value)
            except Exception:
                pass


def _apply_collections(owner: Any, collections: Any) -> None:
    if owner is None or not isinstance(collections, dict):
        return
    for name, rows in collections.items():
        _apply_collection(owner, name, rows)


def _rna_property_map(owner: Any) -> dict[str, Any]:
    try:
        props = getattr(getattr(owner, 'bl_rna', None), 'properties', None)
        if props is None:
            return {}
        result = {}
        for prop in props:
            ident = str(getattr(prop, 'identifier', '') or '')
            if ident:
                result[ident] = prop
        return result
    except Exception:
        return {}


def _prop_kind(prop: Any) -> str:
    try:
        value = str(getattr(prop, 'type', '') or '').upper()
        if value:
            return value
    except Exception:
        pass
    return ''


def _owner_state(owner: Any, *, max_depth: int = 2) -> dict[str, Any]:
    state: dict[str, Any] = {'scalars': {}, 'collections': {}, 'pointers': {}}
    if owner is None:
        return state
    prop_map = _rna_property_map(owner)
    for name in _iter_rna_prop_names(owner):
        if name in _STATE_EXCLUDE_NAMES or name.startswith(_STATE_EXCLUDE_PREFIXES):
            continue
        prop = prop_map.get(name)
        kind = _prop_kind(prop)
        try:
            value = getattr(owner, name)
        except Exception:
            continue
        if kind == 'POINTER':
            if max_depth <= 0 or value is None:
                continue
            nested = _owner_state(value, max_depth=max_depth - 1)
            if nested.get('scalars') or nested.get('collections') or nested.get('pointers'):
                state['pointers'][name] = nested
            continue
        if kind == 'COLLECTION':
            if max_depth <= 0 or value is None:
                continue
            rows = []
            try:
                iterator = list(value)
            except Exception:
                iterator = []
            for item in iterator:
                row_state = _owner_state(item, max_depth=max_depth - 1)
                if row_state.get('scalars') or row_state.get('collections') or row_state.get('pointers'):
                    rows.append(row_state)
            state['collections'][name] = rows
            continue
        scalar = _json_scalar(value)
        if scalar is not None:
            state['scalars'][name] = scalar
    return state


def _owner_pointer_states(owner: Any, names: tuple[str, ...], *, max_depth: int = 2) -> dict[str, Any]:
    result: dict[str, Any] = {}
    if owner is None:
        return result
    for name in names:
        try:
            pointer = getattr(owner, name, None)
        except Exception:
            pointer = None
        if pointer is None:
            continue
        state = _owner_state(pointer, max_depth=max_depth)
        state = _filter_scene_owner_state(name, state)
        if state.get('scalars') or state.get('collections') or state.get('pointers'):
            result[name] = state
    return result


def _apply_owner_state(owner: Any, state: Any) -> None:
    if owner is None or not isinstance(state, dict):
        return
    _apply_to_owner(owner, state.get('scalars'))
    collections = state.get('collections')
    if isinstance(collections, dict):
        for name, rows in collections.items():
            if not isinstance(name, str) or not isinstance(rows, list):
                continue
            try:
                collection = getattr(owner, name, None)
            except Exception:
                collection = None
            if collection is None:
                continue
            try:
                collection.clear()
            except Exception:
                continue
            for row_state in rows:
                try:
                    item = collection.add()
                except Exception:
                    break
                _apply_owner_state(item, row_state)
    pointers = state.get('pointers')
    if isinstance(pointers, dict):
        for name, nested_state in pointers.items():
            if not isinstance(name, str):
                continue
            try:
                nested_owner = getattr(owner, name, None)
            except Exception:
                nested_owner = None
            _apply_owner_state(nested_owner, nested_state)


def _apply_pointer_states(owner: Any, states: Any) -> None:
    if owner is None or not isinstance(states, dict):
        return
    for name, state in states.items():
        if not isinstance(name, str) or name in {'uhm_addon_settings', 'sf_addon_settings'}:
            # Legacy History values are migrated exactly once by
            # history_integration.  The canonical sf_addon_settings owner is
            # restored only through the top-level 'preferences' branch.
            continue
        try:
            pointer = getattr(owner, name, None)
        except Exception:
            pointer = None
        _apply_owner_state(pointer, _filter_scene_owner_state(name, state))


def _scene_identity(context=None) -> str:
    scene = getattr(context or getattr(bpy, 'context', None), 'scene', None)
    if scene is None:
        return ''
    try:
        ptr = getattr(scene, 'as_pointer', None)
        if callable(ptr):
            value = ptr()
            if value:
                return str(value)
    except Exception:
        pass
    try:
        return str(getattr(scene, 'name_full', None) or getattr(scene, 'name', '') or id(scene))
    except Exception:
        return str(id(scene))


def _apply_scene_state(context, data: Any) -> None:
    scene = getattr(context or getattr(bpy, 'context', None), 'scene', None)
    if scene is None or not isinstance(data, dict):
        return
    scene_defaults = data.get('scene_defaults')
    if isinstance(scene_defaults, dict):
        for pointer_name, values in scene_defaults.items():
            try:
                _apply_to_owner(getattr(scene, pointer_name, None), _filter_scene_scalar_values(pointer_name, values))
            except Exception:
                pass
    _apply_pointer_states(scene, data.get('scene_pointers'))


def _addon_prefs(context=None):
    context = context or getattr(bpy, 'context', None)
    try:
        wm = getattr(context, 'window_manager', None)
        settings = getattr(wm, 'sf_addon_settings', None) if wm is not None else None
        if settings is not None:
            return settings
    except Exception:
        pass
    return None


def _scene_settings(context=None) -> dict[str, Any]:
    scene = getattr(context or getattr(bpy, 'context', None), 'scene', None)
    result: dict[str, Any] = {}
    if scene is None:
        return result
    for pointer_name in _SCENE_SETTING_NAMES:
        try:
            owner = getattr(scene, pointer_name, None)
        except Exception:
            owner = None
        values = _owner_scalars(owner, exclude_names=_SCENE_EXCLUDE_NAMES, exclude_prefixes=_PREF_EXCLUDE_PREFIXES)
        values = _filter_scene_scalar_values(pointer_name, values)
        if values:
            result[pointer_name] = values
    return result



def _feature_toggle_state() -> dict[str, Any]:
    """Return pending always-on feature toggle states for Smart_File_Suite.json."""
    try:
        from . import feature_toggle as _sf_feature_toggle
        export_fn = getattr(_sf_feature_toggle, 'export_state_for_config', None)
        if callable(export_fn):
            data = export_fn()
            return data if isinstance(data, dict) else {}
    except Exception:
        pass
    return {}


def _named_scalars(owner: Any, names: tuple[str, ...]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    if owner is None:
        return result
    for name in names:
        if not hasattr(owner, name):
            continue
        try:
            value = _json_scalar(getattr(owner, name))
        except Exception:
            continue
        if value is not None:
            result[name] = value
    return result


def collect(context=None) -> dict[str, Any]:
    context = context or getattr(bpy, 'context', None)
    wm = getattr(context, 'window_manager', None)
    prefs = _addon_prefs(context)
    scene = getattr(context, 'scene', None)
    return {
        'version': 3,
        'window_manager': _owner_scalars(wm, include_prefixes=_WM_INCLUDE_PREFIXES, exclude_prefixes=_WM_EXCLUDE_PREFIXES, exclude_names=_WM_EXCLUDE_NAMES),
        'window_manager_pointers': _owner_pointer_states(wm, _WM_POINTER_SETTING_NAMES, max_depth=3),
        'preferences': _owner_scalars(prefs, exclude_prefixes=_PREF_EXCLUDE_PREFIXES, exclude_names=_PREF_EXCLUDE_NAMES),
        'preferences_collections': _owner_collections(prefs, _PREF_COLLECTION_NAMES),
        'scene_defaults': _scene_settings(context),
        'scene_pointers': _owner_pointer_states(scene, _SCENE_SETTING_NAMES, max_depth=2),
        'ui_section_state': _ui_section_state(),
        'feature_toggles': _feature_toggle_state(),
        'window_manager_direct': _named_scalars(wm, _WM_DIRECT_SETTING_NAMES),
        'scene_direct': _named_scalars(scene, _SCENE_DIRECT_SETTING_NAMES),
    }


def _merge_unknown_nested(existing: Any, current: Any) -> Any:
    """Overlay owned values while preserving unrecognized nested fields."""
    if not isinstance(existing, dict) or not isinstance(current, dict):
        return copy.deepcopy(current)
    merged = copy.deepcopy(existing)
    for key, value in current.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _merge_unknown_nested(merged[key], value)
        else:
            merged[key] = copy.deepcopy(value)
    return merged


def _merge_settings_payload(existing: Any, current: dict[str, Any]) -> dict[str, Any]:
    """Merge one collected snapshot without resurrecting removed collection rows.

    Unknown top-level and nested fields survive upgrades.  Collection names not
    owned by this version survive, while every currently owned collection is
    replaced as a whole so a user deletion is not replayed from stale JSON.
    """
    merged = copy.deepcopy(existing) if isinstance(existing, dict) else {}
    for key, value in current.items():
        if key == 'preferences_collections' and isinstance(value, dict):
            branch = merged.get(key)
            branch = copy.deepcopy(branch) if isinstance(branch, dict) else {}
            for collection_name, rows in value.items():
                branch[collection_name] = copy.deepcopy(rows)
            merged[key] = branch
        elif isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _merge_unknown_nested(merged[key], value)
        else:
            merged[key] = copy.deepcopy(value)
    return merged


def _signature(data: dict[str, Any]) -> str:
    try:
        return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    except Exception:
        return ''


def load_data() -> dict[str, Any]:
    return _overlay_autosave_choice(_read_config_with_legacy())


_HISTORY_UHM_MIGRATION_META_KEY = 'history_uhm_migrated_to_sf_v1'


def history_uhm_migration_done(data=None) -> bool:
    """Return the persisted one-way migration marker.

    Legacy ``uhm_addon_settings`` values are read only when this marker is
    absent.  They are never used as a runtime fallback or a persistence target.
    """
    source = data if isinstance(data, dict) else load_data()
    meta = source.get('meta') if isinstance(source, dict) else None
    return bool(isinstance(meta, dict) and meta.get(_HISTORY_UHM_MIGRATION_META_KEY) is True)


def mark_history_uhm_migration_done() -> bool:
    """Persist the migration marker with the settings service's atomic writer."""
    if _APPLYING or _STARTUP_RESTORE_PENDING:
        return False
    if not _keeper_enabled(getattr(bpy, 'context', None)):
        return False
    path = _config_path()
    try:
        data = _read_json_file(path)
        if not isinstance(data, dict):
            data = {}
        meta = data.get('meta')
        if not isinstance(meta, dict):
            meta = {}
            data['meta'] = meta
        if meta.get(_HISTORY_UHM_MIGRATION_META_KEY) is True:
            return True
        meta[_HISTORY_UHM_MIGRATION_META_KEY] = True
        meta.setdefault('storage', 'Blender config/Smart_File_Suite/Smart_File_Suite.json')
        meta.setdefault('schema', 'Smart File Suite N-panel settings')
        return bool(_write_json_atomic(path, data))
    except Exception:
        return False


def _apply_to_owner(owner: Any, values: Any) -> None:
    if owner is None or not isinstance(values, dict):
        return
    for name, value in values.items():
        if not isinstance(name, str) or name == 'rna_type':
            continue
        if not hasattr(owner, name):
            continue
        try:
            current = getattr(owner, name)
        except Exception:
            continue
        current_scalar = _json_scalar(current)
        value_scalar = _json_scalar(value)
        if current_scalar is None or value_scalar is None:
            continue
        if current_scalar == value_scalar:
            continue
        try:
            setattr(owner, name, value)
        except Exception:
            pass


def _apply_autosave_choice_only(context=None) -> bool:
    """Restore only Rolling Autosave when the general N-panel keeper is OFF."""
    global _APPLYING
    context = context or getattr(bpy, 'context', None)
    owner = _addon_prefs(context)
    if owner is None or not hasattr(owner, 'enable_autosave'):
        return False
    data = load_data()
    preferences = data.get('preferences') if isinstance(data, dict) else None
    enabled = (
        preferences.get('enable_autosave', False)
        if isinstance(preferences, dict)
        else False
    )
    if type(enabled) is not bool:
        enabled = False
    already_applying = bool(_APPLYING)
    if not already_applying:
        _APPLYING = True
        _set_apply_guard(True)
    try:
        setattr(owner, 'enable_autosave', bool(enabled))
        applied = bool(getattr(owner, 'enable_autosave')) == bool(enabled)
        if applied:
            explicit = _read_explicit_autosave_choice()
            _materialize_resolved_autosave_choice(
                bool(enabled),
                source=(
                    'current_epoch_manual_choice'
                    if explicit is not None
                    else 'install_default'
                ),
            )
        return applied
    except Exception:
        return False
    finally:
        if not already_applying:
            _set_apply_guard(False)
            _APPLYING = False


def apply_all(context=None) -> None:
    global _APPLYING, _LAST_SIGNATURE, _LAST_SCENE_ID
    if _APPLYING:
        return
    # A bundled tool's register() runs under the feature-toggle capture, which
    # would swallow the hooks its restored switches start. The loader applies
    # again right after the capture ends, so the switches take effect there.
    from . import feature_toggle as _sf_capture_owner
    if _sf_capture_owner._current_capture() is not None:
        return
    data = load_data()
    if not data:
        return
    context = context or getattr(bpy, 'context', None)
    _APPLYING = True
    _set_apply_guard(True)
    try:
        wm = getattr(context, 'window_manager', None)
        _apply_to_owner(wm, data.get('window_manager'))
        _apply_to_owner(wm, data.get('window_manager_direct'))
        _apply_pointer_states(wm, data.get('window_manager_pointers'))
        prefs_owner = _addon_prefs(context)
        _apply_to_owner(prefs_owner, data.get('preferences'))
        _apply_collections(prefs_owner, data.get('preferences_collections'))
        _apply_scene_state(context, data)
        _apply_to_owner(getattr(context, 'scene', None), data.get('scene_direct'))
        _apply_ui_section_state(data.get('ui_section_state'))
        try:
            from . import feature_toggle as _sf_feature_toggle
            importer = getattr(_sf_feature_toggle, 'import_state_for_config', None)
            if callable(importer):
                importer(data.get('feature_toggles'), apply_runtime=False)
        except Exception:
            pass
        _LAST_SCENE_ID = _scene_identity(context)
        _LAST_SIGNATURE = _signature(collect(context))
    finally:
        _set_apply_guard(False)
        _APPLYING = False


def commit_keeper_transition(owner, context=None) -> bool:
    """Persist the keeper switch with one exact OFF boundary transaction.

    The restore barrier is checked before context or RNA access.  Turning OFF
    receives one private-token commit containing ``False``; after that token is
    released, ordinary, direct, forced, fallback, load, exit, and teardown
    writers all remain blocked.  Turning ON is snapshotted by the caller after
    the persistence owner has been re-armed.
    """
    global _KEEPER_OFF_SELF_COMMIT_ACTIVE
    if _APPLYING or _STARTUP_RESTORE_PENDING:
        return True
    try:
        enabled = bool(getattr(owner, 'enable_npanel_settings_keeper'))
    except Exception:
        return False
    if enabled:
        return True
    _KEEPER_OFF_SELF_COMMIT_ACTIVE = True
    try:
        return bool(save_now(
            context,
            force=True,
            off_transition_token=_KEEPER_OFF_SELF_COMMIT_TOKEN,
        ))
    finally:
        _KEEPER_OFF_SELF_COMMIT_ACTIVE = False
        _cancel_scheduled_save(preserve_pending=False)


def save_now(
    context=None,
    *,
    force: bool = False,
    allow_disabled: bool = False,
    off_transition_token=None,
) -> bool:
    global _LAST_SIGNATURE, _SETTINGS_SAVE_PENDING, _SETTINGS_LAST_ERROR
    if _APPLYING or _STARTUP_RESTORE_PENDING:
        _SETTINGS_LAST_ERROR = 'settings save deferred while saved state is being applied'
        return False
    if force:
        _cancel_scheduled_save(preserve_pending=True)
    context = context or getattr(bpy, 'context', None)
    del allow_disabled  # Compatibility argument; it never bypasses user OFF.
    keeper_enabled = _keeper_enabled(context)
    off_self_commit = bool(
        _KEEPER_OFF_SELF_COMMIT_ACTIVE
        and off_transition_token is _KEEPER_OFF_SELF_COMMIT_TOKEN
    )
    if not keeper_enabled and not off_self_commit:
        _SETTINGS_SAVE_PENDING = False
        return False
    # Blender can invoke exit_pre after the WindowManager (and therefore the
    # canonical sf_addon_settings owner) has already become unavailable.  A
    # collect() in that restricted context contains an empty preferences map;
    # replacing the persisted core schema with it would silently reset every
    # autosave setting at the next cold start.  Fail closed and preserve the
    # last verified file until a real owner is available again.
    prefs_owner = _addon_prefs(context)
    if prefs_owner is None or not all(
        hasattr(prefs_owner, name)
        for name in (
            'enable_npanel_settings_keeper',
            'enable_autosave',
            'autosave_interval_minutes',
            'history_directory',
        )
    ):
        _SETTINGS_SAVE_PENDING = False
        _SETTINGS_LAST_ERROR = (
            'settings save skipped: canonical WindowManager settings owner is unavailable'
        )
        return False
    data = collect(context)
    persisted_preferences = data.get('preferences')
    if not isinstance(persisted_preferences, dict) or not all(
        name in persisted_preferences
        for name in ('enable_autosave', 'autosave_interval_minutes', 'history_directory')
    ):
        _SETTINGS_SAVE_PENDING = False
        _SETTINGS_LAST_ERROR = (
            'settings save skipped: canonical autosave settings could not be collected'
        )
        return False
    sig = _signature(data)
    path = _config_path()
    existing = _read_json_file(path)
    if _json_read_failed(path):
        _SETTINGS_SAVE_PENDING = True
        return False
    # A forced flush is used when N-panel State Save is re-enabled.  Runtime
    # registration refreshes the in-memory signature before this call, so a
    # normal dedup check would otherwise suppress the deferred disk write.
    if not force and sig and sig == _LAST_SIGNATURE and _config_path().exists():
        _SETTINGS_SAVE_PENDING = False
        _SETTINGS_LAST_ERROR = ''
        return False
    try:
        merged = _merge_settings_payload(existing, data)
        merged.setdefault('meta', {})
        try:
            merged['meta']['storage'] = 'Blender config/Smart_File_Suite/Smart_File_Suite.json'
            merged['meta']['schema'] = 'Smart File Suite N-panel settings'
            merged['meta']['autosave_choice_schema'] = _AUTOSAVE_CHOICE_SCHEMA
            merged['meta']['autosave_suite_version'] = _AUTOSAVE_SUITE_VERSION
            merged['meta']['autosave_install_epoch'] = _AUTOSAVE_INSTALL_EPOCH
            merged['meta']['autosave_choice_authority'] = _AUTOSAVE_CONTROL_FILE_NAME
        except Exception:
            pass
        if not _write_json_atomic(
            path,
            merged,
            context=context,
            off_transition_token=(
                off_transition_token if off_self_commit else None
            ),
        ):
            _SETTINGS_SAVE_PENDING = True
            _SETTINGS_LAST_ERROR = f'atomic settings write failed: {path}'
            return False
        sync_blender_config_text_files(prefer_suite=False)
        _LAST_SIGNATURE = sig
        _SETTINGS_SAVE_PENDING = False
        _SETTINGS_LAST_ERROR = ''
        return True
    except Exception as exc:
        _SETTINGS_SAVE_PENDING = True
        _SETTINGS_LAST_ERROR = f'settings save: {type(exc).__name__}: {exc}'
        return False


def _publish_autosave_choice_status() -> None:
    ledger = globals().get('_settings_ledger', lambda: None)()
    if isinstance(ledger, dict) and ledger.get('token') is _SETTINGS_OWNER_TOKEN:
        ledger['autosave_choice_timer_active'] = bool(_AUTOSAVE_CHOICE_TIMER_ACTIVE)
        ledger['autosave_choice_pending'] = _AUTOSAVE_CHOICE_PENDING
        ledger['autosave_choice_retry_attempts'] = int(_AUTOSAVE_CHOICE_RETRY_ATTEMPTS)


def _cancel_autosave_choice_retry(*, preserve_pending: bool = True) -> bool:
    """Remove the exact bounded control retry without touching autosave runtime."""
    global _AUTOSAVE_CHOICE_TIMER_ACTIVE, _AUTOSAVE_CHOICE_RETRY_ATTEMPTS
    global _AUTOSAVE_CHOICE_PENDING
    ok = True
    try:
        if bpy.app.timers.is_registered(_scheduled_autosave_choice_once):
            bpy.app.timers.unregister(_scheduled_autosave_choice_once)
        ok = not bpy.app.timers.is_registered(_scheduled_autosave_choice_once)
    except Exception:
        ok = False
    _AUTOSAVE_CHOICE_TIMER_ACTIVE = False
    if not preserve_pending:
        _AUTOSAVE_CHOICE_PENDING = None
        _AUTOSAVE_CHOICE_RETRY_ATTEMPTS = 0
    _publish_autosave_choice_status()
    return bool(ok)


def _scheduled_autosave_choice_once():
    """Retry a failed explicit choice a finite number of times, then stop."""
    global _AUTOSAVE_CHOICE_TIMER_ACTIVE, _AUTOSAVE_CHOICE_RETRY_ATTEMPTS
    global _AUTOSAVE_CHOICE_PENDING, _SETTINGS_LAST_ERROR
    pending = _AUTOSAVE_CHOICE_PENDING
    if pending is None:
        _AUTOSAVE_CHOICE_TIMER_ACTIVE = False
        _AUTOSAVE_CHOICE_RETRY_ATTEMPTS = 0
        _publish_autosave_choice_status()
        return None
    if _APPLYING or _STARTUP_RESTORE_PENDING or not _keeper_enabled(getattr(bpy, 'context', None)):
        _AUTOSAVE_CHOICE_PENDING = None
        _AUTOSAVE_CHOICE_TIMER_ACTIVE = False
        _AUTOSAVE_CHOICE_RETRY_ATTEMPTS = 0
        _publish_autosave_choice_status()
        return None
    if _commit_autosave_choice_pair(bool(pending), source='user_api'):
        _AUTOSAVE_CHOICE_PENDING = None
        _AUTOSAVE_CHOICE_TIMER_ACTIVE = False
        _AUTOSAVE_CHOICE_RETRY_ATTEMPTS = 0
        _SETTINGS_LAST_ERROR = ''
        _publish_autosave_choice_status()
        return None
    _AUTOSAVE_CHOICE_RETRY_ATTEMPTS += 1
    _SETTINGS_LAST_ERROR = (
        f'atomic autosave choice write failed: {_autosave_control_path()} '
        f'(attempt {_AUTOSAVE_CHOICE_RETRY_ATTEMPTS}/{_AUTOSAVE_CHOICE_RETRY_MAX})'
    )
    if _AUTOSAVE_CHOICE_RETRY_ATTEMPTS >= _AUTOSAVE_CHOICE_RETRY_MAX:
        _AUTOSAVE_CHOICE_TIMER_ACTIVE = False
        _publish_autosave_choice_status()
        return None
    _AUTOSAVE_CHOICE_TIMER_ACTIVE = True
    _publish_autosave_choice_status()
    return _AUTOSAVE_CHOICE_RETRY_DELAY


def _arm_autosave_choice_retry() -> bool:
    global _AUTOSAVE_CHOICE_TIMER_ACTIVE, _SETTINGS_LAST_ERROR
    if _AUTOSAVE_CHOICE_PENDING is None:
        return False
    try:
        if bpy.app.timers.is_registered(_scheduled_autosave_choice_once):
            _AUTOSAVE_CHOICE_TIMER_ACTIVE = True
            _publish_autosave_choice_status()
            return True
        bpy.app.timers.register(
            _scheduled_autosave_choice_once,
            first_interval=_AUTOSAVE_CHOICE_RETRY_DELAY,
            persistent=False,
        )
        _AUTOSAVE_CHOICE_TIMER_ACTIVE = bool(
            bpy.app.timers.is_registered(_scheduled_autosave_choice_once)
        )
    except Exception as exc:
        _AUTOSAVE_CHOICE_TIMER_ACTIVE = False
        _SETTINGS_LAST_ERROR = f'autosave choice retry: {type(exc).__name__}: {exc}'
    _publish_autosave_choice_status()
    return bool(_AUTOSAVE_CHOICE_TIMER_ACTIVE)


def persist_autosave_user_choice(
    context=None,
    enabled: bool = True,
    *,
    source: str = 'user_api',
) -> bool:
    """Persist a verified manual OFF/ON while N-panel State Save is enabled.

    Startup/config replay calls run under ``_APPLYING`` or
    ``_STARTUP_RESTORE_PENDING`` and therefore never manufacture provenance.
    The normal path is one tiny synchronous atomic transaction; only a real
    failure owns one bounded, non-persistent retry callback.
    """
    global _AUTOSAVE_CHOICE_PENDING, _AUTOSAVE_CHOICE_RETRY_ATTEMPTS
    global _SETTINGS_LAST_ERROR
    if _APPLYING or _STARTUP_RESTORE_PENDING:
        return True
    context = context or getattr(bpy, 'context', None)
    if not _keeper_enabled(context):
        _cancel_autosave_choice_retry(preserve_pending=False)
        return False
    _AUTOSAVE_CHOICE_PENDING = bool(enabled)
    _AUTOSAVE_CHOICE_RETRY_ATTEMPTS = 0
    if _commit_autosave_choice_pair(bool(enabled), source=source):
        _cancel_autosave_choice_retry(preserve_pending=False)
        _SETTINGS_LAST_ERROR = ''
        return True
    _SETTINGS_LAST_ERROR = f'atomic autosave choice write failed: {_autosave_control_path()}'
    _arm_autosave_choice_retry()
    return False


def flush_pending_autosave_choice() -> bool:
    """Make one finite safe-boundary attempt for an uncommitted explicit choice."""
    global _AUTOSAVE_CHOICE_PENDING, _AUTOSAVE_CHOICE_RETRY_ATTEMPTS
    global _SETTINGS_LAST_ERROR
    pending = _AUTOSAVE_CHOICE_PENDING
    if pending is None:
        return True
    if _APPLYING or _STARTUP_RESTORE_PENDING or not _keeper_enabled(getattr(bpy, 'context', None)):
        _cancel_autosave_choice_retry(preserve_pending=False)
        return True
    if not _commit_autosave_choice_pair(bool(pending), source='user_api'):
        _SETTINGS_LAST_ERROR = f'atomic autosave choice boundary write failed: {_autosave_control_path()}'
        _publish_autosave_choice_status()
        return False
    _AUTOSAVE_CHOICE_PENDING = None
    _AUTOSAVE_CHOICE_RETRY_ATTEMPTS = 0
    _cancel_autosave_choice_retry(preserve_pending=False)
    _SETTINGS_LAST_ERROR = ''
    return True


def _cancel_scheduled_save(*, preserve_pending: bool = False) -> bool:
    """Remove the exact pending one-shot save callback."""
    global _SETTINGS_SAVE_TIMER_ACTIVE, _SETTINGS_SAVE_DEADLINE, _SETTINGS_SAVE_PENDING
    callback = globals().get('_scheduled_save_once')
    ok = True
    if callable(callback):
        try:
            if bpy.app.timers.is_registered(callback):
                bpy.app.timers.unregister(callback)
            ok = not bpy.app.timers.is_registered(callback)
        except Exception:
            ok = False
    _SETTINGS_SAVE_TIMER_ACTIVE = False
    _SETTINGS_SAVE_DEADLINE = 0.0
    if not preserve_pending:
        _SETTINGS_SAVE_PENDING = False
    ledger = globals().get('_settings_ledger', lambda: None)()
    if isinstance(ledger, dict) and ledger.get('token') is _SETTINGS_OWNER_TOKEN:
        ledger['save_timer_active'] = False
        ledger['save_pending'] = bool(_SETTINGS_SAVE_PENDING)
    return bool(ok)


def _scheduled_save_once():
    """Commit one quiet-period batch, then return with zero idle timers."""
    global _SETTINGS_SAVE_TIMER_ACTIVE, _SETTINGS_SAVE_DEADLINE
    global _SETTINGS_SAVE_PENDING, _SETTINGS_LAST_ERROR
    wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    if bool(getattr(wm, 'is_interface_locked', False)):
        return 0.2
    remaining = float(_SETTINGS_SAVE_DEADLINE or 0.0) - time.monotonic()
    if remaining > 0.0:
        return max(0.01, remaining)
    if not _SETTINGS_REGISTERED or not _keeper_enabled(getattr(bpy, 'context', None)):
        _SETTINGS_SAVE_TIMER_ACTIVE = False
        _SETTINGS_SAVE_DEADLINE = 0.0
        ledger = globals().get('_settings_ledger', lambda: None)()
        if isinstance(ledger, dict) and ledger.get('token') is _SETTINGS_OWNER_TOKEN:
            ledger['save_timer_active'] = False
        return None
    try:
        save_now(getattr(bpy, 'context', None), force=False, allow_disabled=False)
    except Exception as exc:
        _SETTINGS_SAVE_PENDING = True
        _SETTINGS_LAST_ERROR = f"deferred save: {type(exc).__name__}: {exc}"
    ledger = globals().get('_settings_ledger', lambda: None)()
    if _SETTINGS_SAVE_PENDING:
        # A real write failure remains an active transaction. Retry slowly only
        # while the keeper is enabled; this is not an idle poll and disappears
        # immediately after success, unchanged data, or user disable.
        _SETTINGS_SAVE_TIMER_ACTIVE = True
        _SETTINGS_SAVE_DEADLINE = time.monotonic() + _SETTINGS_SAVE_RETRY_DELAY
        if isinstance(ledger, dict) and ledger.get('token') is _SETTINGS_OWNER_TOKEN:
            ledger['save_timer_active'] = True
            ledger['save_pending'] = True
        return _SETTINGS_SAVE_RETRY_DELAY
    _SETTINGS_SAVE_TIMER_ACTIVE = False
    _SETTINGS_SAVE_DEADLINE = 0.0
    if isinstance(ledger, dict) and ledger.get('token') is _SETTINGS_OWNER_TOKEN:
        ledger['save_timer_active'] = False
        ledger['save_pending'] = False
    return None


def schedule_save(context=None, *, delay: float = _SETTINGS_SAVE_DELAY) -> bool:
    """Keep one trailing-edge callback for rapid UI/property changes."""
    global _SETTINGS_SAVE_TIMER_ACTIVE, _SETTINGS_SAVE_DEADLINE
    global _SETTINGS_SAVE_PENDING, _SETTINGS_LAST_ERROR
    if _APPLYING or _STARTUP_RESTORE_PENDING:
        return True
    context = context or getattr(bpy, 'context', None)
    if not _SETTINGS_REGISTERED:
        return False
    if not _keeper_enabled(context):
        _cancel_scheduled_save()
        return False
    interval = max(0.05, float(delay))
    _SETTINGS_SAVE_PENDING = True
    _SETTINGS_SAVE_DEADLINE = time.monotonic() + interval
    try:
        if bpy.app.timers.is_registered(_scheduled_save_once):
            _SETTINGS_SAVE_TIMER_ACTIVE = True
            return True
        bpy.app.timers.register(
            _scheduled_save_once,
            first_interval=interval,
            persistent=False,
        )
        _SETTINGS_SAVE_TIMER_ACTIVE = bool(
            bpy.app.timers.is_registered(_scheduled_save_once)
        )
    except Exception as exc:
        _SETTINGS_SAVE_TIMER_ACTIVE = False
        _SETTINGS_LAST_ERROR = f"save scheduling: {type(exc).__name__}: {exc}"
    ledger = globals().get('_settings_ledger', lambda: None)()
    if isinstance(ledger, dict) and ledger.get('token') is _SETTINGS_OWNER_TOKEN:
        ledger['save_timer_active'] = bool(_SETTINGS_SAVE_TIMER_ACTIVE)
        ledger['save_pending'] = bool(_SETTINGS_SAVE_PENDING)
    if _SETTINGS_SAVE_TIMER_ACTIVE:
        return True
    # Background/restricted contexts may reject timers. Keep persistence
    # reliable by falling back to the existing synchronous transaction.
    return bool(save_now(context, force=False, allow_disabled=False))


def _subscription_property_names(owner, *, include_prefixes=(), include_names=(), exclude_prefixes=(), exclude_names=()) -> tuple[str, ...]:
    """Return scalar RNA property names without rebuilding owner metadata per item."""
    result: list[str] = []
    excluded = set(exclude_names or ())
    included = set(include_names or ())
    include_prefix_tuple = tuple(include_prefixes or ())
    exclude_prefix_tuple = tuple(exclude_prefixes or ())
    prop_map = _rna_property_map(owner)
    has_include_filter = bool(include_prefix_tuple or included)

    for name in _iter_rna_prop_names(owner):
        if name in excluded or (exclude_prefix_tuple and name.startswith(exclude_prefix_tuple)):
            continue
        if has_include_filter:
            if name not in included and not (include_prefix_tuple and name.startswith(include_prefix_tuple)):
                continue
        prop = prop_map.get(name)
        if _prop_kind(prop) in {'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM'}:
            result.append(name)
    return tuple(sorted(set(result)))


def _subscribe_key(key, notify) -> bool:
    global _SETTINGS_SUBSCRIPTION_COUNT, _SETTINGS_SUBSCRIPTION_ERRORS
    try:
        bpy.msgbus.subscribe_rna(
            key=key,
            owner=_MSGBUS_OWNER,
            args=(),
            notify=notify,
        )
        _SETTINGS_SUBSCRIPTION_COUNT += 1
        return True
    except Exception as exc:
        _SETTINGS_SUBSCRIPTION_ERRORS.append(
            f"{type(exc).__name__}: {exc}"
        )
        return False


def _subscribe_owner(owner, names: tuple[str, ...]) -> bool:
    if owner is None:
        return True
    return _subscribe_rna_type(type(owner), names)


def _subscribe_rna_type(owner_type, names: tuple[str, ...]) -> bool:
    if owner_type is None:
        return True
    ok = True
    for name in names:
        if not _subscribe_key((owner_type, name), _on_setting_changed):
            ok = False
    return ok


def _property_fixed_python_type(prop):
    try:
        fixed = getattr(prop, 'fixed_type', None)
        identifier = str(getattr(fixed, 'identifier', '') or '')
        if not identifier:
            return None
        cls = getattr(bpy.types, identifier, None)
        if isinstance(cls, type):
            return cls
        lookup = getattr(bpy.types.PropertyGroup, 'bl_rna_get_subclass_py', None)
        return lookup(identifier, None) if callable(lookup) else None
    except Exception:
        return None


def _subscribe_nested_rna_types(owner, *, depth: int = 3, seen=None) -> None:
    """Subscribe scalar row fields inside Pointer/Collection settings trees."""
    if owner is None or depth < 0:
        return
    seen = set() if seen is None else seen
    try:
        owner_type = owner if isinstance(owner, type) else type(owner)
    except Exception:
        return
    marker = getattr(owner_type, '__name__', repr(owner_type))
    if marker in seen:
        return
    seen.add(marker)
    prop_map = _rna_property_map(owner)
    container_names = []
    for name, prop in prop_map.items():
        if name in _STATE_EXCLUDE_NAMES or name.startswith(_STATE_EXCLUDE_PREFIXES):
            continue
        kind = _prop_kind(prop)
        if kind not in {'POINTER', 'COLLECTION'}:
            continue
        fixed_type = _property_fixed_python_type(prop)
        if fixed_type is None:
            continue
        container_names.append(name)
        scalar_names = _subscription_property_names(
            fixed_type,
            exclude_prefixes=_STATE_EXCLUDE_PREFIXES,
            exclude_names=_STATE_EXCLUDE_NAMES,
        )
        _subscribe_rna_type(fixed_type, scalar_names)
        if depth > 0:
            _subscribe_nested_rna_types(fixed_type, depth=depth - 1, seen=seen)
    # Collection add/remove/reorder notifications, where Blender exposes them,
    # are also observed on the owning RNA container property.
    _subscribe_rna_type(owner_type, tuple(container_names))


def _subscribe_pointer_tree(owner, pointer_names: tuple[str, ...], *, depth: int = 2) -> None:
    if owner is None or depth < 0:
        return
    for pointer_name in pointer_names:
        try:
            pointer = getattr(owner, pointer_name, None)
        except Exception:
            pointer = None
        if pointer is None:
            continue
        names = _subscription_property_names(
            pointer,
            exclude_prefixes=_STATE_EXCLUDE_PREFIXES,
            exclude_names=_STATE_EXCLUDE_NAMES,
        )
        _subscribe_owner(pointer, names)
        _subscribe_nested_rna_types(pointer, depth=max(0, depth))
        if depth <= 0:
            continue
        prop_map = _rna_property_map(pointer)
        nested_names = tuple(
            name for name, prop in prop_map.items()
            if _prop_kind(prop) == 'POINTER' and name not in _STATE_EXCLUDE_NAMES
        )
        _subscribe_pointer_tree(pointer, nested_names, depth=depth - 1)


def _notify_history_settings_changed(
    context=None,
    *,
    reason: str = 'settings changed',
    allow_notify: bool = True,
    allow_repair: bool = True,
) -> bool:
    """Synchronize History once and route every failure to the sole owner repair."""
    global _SETTINGS_LAST_ERROR
    ctx = context or getattr(bpy, 'context', None)
    try:
        from .history_auto_save.core import runtime as history_runtime

        notify = getattr(history_runtime, 'notify_runtime_state_change', None)
        if allow_notify and callable(notify):
            notify(ctx, str(reason or 'settings changed'))
        sync = getattr(history_runtime, 'sync_listener_runtime', None)
        ok = bool(callable(sync) and sync(
            ctx, reason=str(reason or 'settings changed'), preserve_state=True
        ))
        if ok:
            return True
        status_fn = getattr(history_runtime, 'get_runtime_status', None)
        status = status_fn(ctx) if callable(status_fn) else {}
        reason = str(
            status.get('last_runtime_error')
            or status.get('last_save_error')
            or 'History runtime synchronization returned False'
        )
        if not allow_repair:
            _SETTINGS_LAST_ERROR = reason
            return False
        if _request_suite_history_repair(reason):
            _SETTINGS_LAST_ERROR = ''
            return True
        _SETTINGS_LAST_ERROR = reason
        return False
    except Exception as exc:
        reason = f"History runtime synchronization: {type(exc).__name__}: {exc}"
        _SETTINGS_LAST_ERROR = reason
        if not allow_repair:
            return False
        if _request_suite_history_repair(reason):
            _SETTINGS_LAST_ERROR = ''
            return True
        return False


def _request_suite_history_repair(reason: str) -> bool:
    """Call the lifecycle owner exported by this exact extension package."""
    try:
        import sys

        # settings.py lives directly in the Smart File package.  Removing one
        # dotted component points at ``bl_ext.user_default`` and silently loses
        # the repair entry point after a .blend load.
        root = sys.modules.get(str(__package__ or '').strip())
        repair = getattr(root, '_sf_history_request_repair', None)
        return bool(callable(repair) and repair(str(reason or 'settings repair')))
    except Exception:
        return False


def _on_setting_changed() -> None:
    if _APPLYING:
        return
    context = getattr(bpy, 'context', None)
    _sync_scene_change(context)
    schedule_save(context)


def _schedule_history_runtime_refresh(context=None) -> bool:
    """Queue one History runtime refresh without doing work in msgbus callbacks."""
    try:
        from . import core as _sf_core
        schedule = getattr(_sf_core, '_sf_schedule_history_runtime_sync', None)
        if not callable(schedule):
            return False
        schedule(context)
        return True
    except Exception:
        return False


def _on_scene_switched() -> None:
    global _SETTINGS_LAST_ERROR
    if _APPLYING:
        return
    context = getattr(bpy, 'context', None)
    _sync_scene_change(context)
    subscriptions_ok = _register_setting_subscriptions(context)
    _schedule_history_runtime_refresh(context)
    if not subscriptions_ok:
        _SETTINGS_LAST_ERROR = _SETTINGS_LAST_ERROR or 'settings subscription refresh failed'
        _request_suite_history_repair(_SETTINGS_LAST_ERROR)
    return None


def _register_setting_subscriptions(context=None) -> bool:
    global _SETTINGS_SUBSCRIPTION_COUNT, _SETTINGS_SUBSCRIPTION_ERRORS, _SETTINGS_LAST_ERROR
    context = context or getattr(bpy, 'context', None)
    _SETTINGS_SUBSCRIPTION_COUNT = 0
    _SETTINGS_SUBSCRIPTION_ERRORS = []
    clear_ok = True
    try:
        bpy.msgbus.clear_by_owner(_MSGBUS_OWNER)
    except Exception as exc:
        clear_ok = False
        _SETTINGS_SUBSCRIPTION_ERRORS.append(f"clear_by_owner: {type(exc).__name__}: {exc}")

    keeper_enabled = _keeper_enabled(context)
    if keeper_enabled:
        # Event-only coverage: direct update callbacks and these RNA
        # subscriptions converge on the same trailing-edge one-shot writer.
        # There is no periodic full-settings scanner.
        _subscribe_key((bpy.types.Window, 'scene'), _on_scene_switched)
        wm = getattr(context, 'window_manager', None)
        scene = getattr(context, 'scene', None)
        prefs = _addon_prefs(context)
        _subscribe_owner(prefs, _subscription_property_names(
            prefs,
            exclude_prefixes=_PREF_EXCLUDE_PREFIXES,
            exclude_names=_PREF_EXCLUDE_NAMES,
        ))
        _subscribe_owner(wm, _subscription_property_names(
            wm,
            include_prefixes=_WM_INCLUDE_PREFIXES,
            include_names=_WM_DIRECT_SETTING_NAMES,
            exclude_prefixes=_WM_EXCLUDE_PREFIXES,
            exclude_names=_WM_EXCLUDE_NAMES,
        ))
        _subscribe_pointer_tree(wm, _WM_POINTER_SETTING_NAMES, depth=3)
        _subscribe_owner(scene, _subscription_property_names(
            scene,
            include_names=_SCENE_DIRECT_SETTING_NAMES,
            exclude_prefixes=_STATE_EXCLUDE_PREFIXES,
            exclude_names=_SCENE_EXCLUDE_NAMES,
        ))
        _subscribe_pointer_tree(scene, _SCENE_SETTING_NAMES, depth=3)

    expected_count_ok = (
        _SETTINGS_SUBSCRIPTION_COUNT >= 1
        if keeper_enabled
        else _SETTINGS_SUBSCRIPTION_COUNT == 0
    )
    ok = bool(clear_ok and expected_count_ok and not _SETTINGS_SUBSCRIPTION_ERRORS)
    _SETTINGS_LAST_ERROR = '' if ok else '; '.join(_SETTINGS_SUBSCRIPTION_ERRORS) or 'settings subscription state mismatch'
    ledger = _settings_ledger()
    if isinstance(ledger, dict) and ledger.get('token') is _SETTINGS_OWNER_TOKEN:
        ledger['subscription_count'] = int(_SETTINGS_SUBSCRIPTION_COUNT)
        ledger['subscription_owner'] = _MSGBUS_OWNER
    return ok


def refresh_subscriptions(context=None, *, save: bool = True) -> bool:
    context = context or getattr(bpy, 'context', None)
    ok = _register_setting_subscriptions(context)
    if save and _keeper_enabled(context):
        save_now(context, force=True, allow_disabled=False)
    return bool(ok)



def enabled_scene_tool_aliases() -> tuple[str, ...]:
    """Bundled scene-level tools that must be loaded because their saved always-on switch is enabled."""
    aliases: list[str] = []
    try:
        scene_defaults = load_data().get('scene_defaults')
        if isinstance(scene_defaults, dict):
            tex = scene_defaults.get('texmgr_settings')
            if isinstance(tex, dict) and bool(tex.get('auto_refresh_on_file_load')):
                aliases.append('texture_manager')
            reporter = scene_defaults.get('reporter_settings')
            if isinstance(reporter, dict) and bool(reporter.get('labels_enabled')):
                aliases.append('object_reporter')
    except Exception:
        pass
    return tuple(dict.fromkeys(aliases))

def _sync_scene_change(context=None) -> None:
    global _APPLYING, _LAST_SIGNATURE, _LAST_SCENE_ID
    context = context or getattr(bpy, 'context', None)
    scene_id = _scene_identity(context)
    if not scene_id or scene_id == _LAST_SCENE_ID or _APPLYING:
        return
    data = load_data()
    if not data:
        _LAST_SCENE_ID = scene_id
        return
    _APPLYING = True
    _set_apply_guard(True)
    try:
        _apply_scene_state(context, data)
        _apply_to_owner(getattr(context, 'scene', None), data.get('scene_direct'))
        _LAST_SCENE_ID = scene_id
        _LAST_SIGNATURE = _signature(collect(context))
    finally:
        _set_apply_guard(False)
        _APPLYING = False


def restore_enabled_always_on_tools(context=None) -> bool:
    """Load only the bundled tools whose saved always-on switch is enabled."""
    context = context or getattr(bpy, 'context', None)
    if not _keeper_enabled(context):
        return False
    from . import loader as _sf_loader
    _sf_loader.sync_enabled_always_on_tools()
    return True


def _always_on_restore_once():
    global _SETTINGS_LAST_ERROR
    if _SETTINGS_REGISTERED:
        try:
            restore_enabled_always_on_tools()
        except Exception as exc:
            _SETTINGS_LAST_ERROR = f"always-on restore: {type(exc).__name__}: {exc}"
    return None


def _schedule_always_on_restore() -> None:
    # register() can run in a restricted context without a scene, so the startup
    # restore waits for the main loop. File loads use _on_load_post instead.
    timers = bpy.app.timers
    if not timers.is_registered(_always_on_restore_once):
        timers.register(_always_on_restore_once, first_interval=0.1, persistent=False)


def _cancel_always_on_restore() -> None:
    timers = bpy.app.timers
    if timers.is_registered(_always_on_restore_once):
        timers.unregister(_always_on_restore_once)


@persistent
def _on_load_post(_dummy=None):
    global _SETTINGS_LAST_ERROR
    context = getattr(bpy, 'context', None)
    try:
        if not _rehydrate_settings_owner_after_load():
            raise RuntimeError('settings owner could not be restored after file load')
        if not _apply_autosave_choice_only(context):
            raise RuntimeError('autosave choice could not be restored after file load')
        if _keeper_enabled(context):
            apply_all(context)
        if not _register_setting_subscriptions(context):
            raise RuntimeError(_SETTINGS_LAST_ERROR or 'settings subscription repair failed')
        synchronized = _notify_history_settings_changed(
            context,
            reason='load_post',
            allow_notify=False,
            allow_repair=False,
        )
        queued = _schedule_history_runtime_refresh(context)
        if not synchronized and not queued:
            raise RuntimeError(_SETTINGS_LAST_ERROR or 'History runtime repair failed')
    except Exception as exc:
        _SETTINGS_LAST_ERROR = f"load_post: {type(exc).__name__}: {exc}"
    try:
        restore_enabled_always_on_tools(context)
        from . import loader as _sf_loader
        _sf_loader.sync_loaded_tool_runtimes()
    except Exception as exc:
        _SETTINGS_LAST_ERROR = f"always-on restore: {type(exc).__name__}: {exc}"


@persistent
def _on_save_pre(_dummy=None):
    global _SETTINGS_LAST_ERROR
    context = getattr(bpy, 'context', None)
    try:
        flush_pending_autosave_choice()
        _cancel_scheduled_save()
        if _keeper_enabled(context):
            save_now(context, force=True, allow_disabled=False)
    except Exception as exc:
        _SETTINGS_LAST_ERROR = f"save_pre: {type(exc).__name__}: {exc}"


@persistent
def _on_exit_pre(_dummy=None):
    global _SETTINGS_LAST_ERROR
    context = getattr(bpy, 'context', None)
    try:
        choice_ok = flush_pending_autosave_choice()
        _cancel_scheduled_save(preserve_pending=True)
        settings_ok = (
            save_now(context, force=True, allow_disabled=False)
            if _keeper_enabled(context)
            else True
        )
        if not choice_ok or not settings_ok:
            _SETTINGS_LAST_ERROR = (
                'exit_pre autosave choice/settings flush failed'
                if not choice_ok else 'exit_pre settings flush failed'
            )
    except Exception as exc:
        _SETTINGS_LAST_ERROR = f"exit_pre: {type(exc).__name__}: {exc}"


@persistent
def _on_load_pre(_dummy=None):
    global _SETTINGS_LAST_ERROR
    context = getattr(bpy, 'context', None)
    try:
        flush_pending_autosave_choice()
        _cancel_scheduled_save()
        # This is the final safe settings boundary for the file being closed.
        if _keeper_enabled(context):
            save_now(context, force=True, allow_disabled=True)
    except Exception as exc:
        _SETTINGS_LAST_ERROR = f"load_pre: {type(exc).__name__}: {exc}"


def _keeper_enabled(context=None) -> bool:
    try:
        context = context or getattr(bpy, 'context', None)
        wm = getattr(context, 'window_manager', None)
        prefs = getattr(wm, 'sf_addon_settings', None) if wm is not None else None
        if prefs is not None and hasattr(prefs, 'enable_npanel_settings_keeper'):
            return bool(getattr(prefs, 'enable_npanel_settings_keeper'))
    except Exception:
        pass
    # An unavailable owner is never authority to write.  Fresh-install True is
    # supplied by the RNA default once the canonical owner exists.
    return False


def _settings_namespace():
    try:
        value = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _settings_ledger():
    namespace = _settings_namespace()
    value = namespace.get(_SETTINGS_OWNER_KEY) if namespace is not None else None
    return value if isinstance(value, dict) else None


def _settings_owner_ok() -> bool:
    ledger = _settings_ledger()
    return bool(
        ledger
        and ledger.get('token') is _SETTINGS_OWNER_TOKEN
        and ledger.get('generation') == _SETTINGS_GENERATION
        and ledger.get('subscription_owner') is _MSGBUS_OWNER
    )


def _rehydrate_settings_owner_after_load() -> bool:
    """Republish this live generation after Blender clears driver_namespace."""
    global _SETTINGS_SAVE_TIMER_ACTIVE, _SETTINGS_SAVE_DEADLINE
    if _settings_owner_ok():
        return True
    namespace = _settings_namespace()
    if namespace is None:
        return False
    previous = namespace.get(_SETTINGS_OWNER_KEY)
    if isinstance(previous, dict) and previous.get('token') is not _SETTINGS_OWNER_TOKEN:
        return False

    timer_active = False
    if _SETTINGS_SAVE_TIMER_ACTIVE:
        try:
            timer_active = bool(bpy.app.timers.is_registered(_scheduled_save_once))
        except Exception:
            timer_active = False
    if not timer_active:
        _SETTINGS_SAVE_TIMER_ACTIVE = False
        _SETTINGS_SAVE_DEADLINE = 0.0

    namespace[_SETTINGS_OWNER_KEY] = {
        'schema': 1,
        'token': _SETTINGS_OWNER_TOKEN,
        'generation': _SETTINGS_GENERATION,
        'handlers': tuple(_SETTINGS_HANDLER_RECORDS),
        'subscription_owner': _MSGBUS_OWNER,
        'subscription_count': int(_SETTINGS_SUBSCRIPTION_COUNT),
        'save_timer_active': bool(timer_active),
        'save_pending': bool(_SETTINGS_SAVE_PENDING),
        'save_timer_callback': _scheduled_save_once,
        'keeper_enabled': bool(_keeper_enabled(getattr(bpy, 'context', None))),
        'autosave_choice_timer_active': bool(_AUTOSAVE_CHOICE_TIMER_ACTIVE),
        'autosave_choice_pending': _AUTOSAVE_CHOICE_PENDING,
        'autosave_choice_retry_attempts': int(_AUTOSAVE_CHOICE_RETRY_ATTEMPTS),
        'autosave_choice_timer_callback': _scheduled_autosave_choice_once,
        'cleanup': _cleanup_settings_generation,
    }
    return _settings_owner_ok()


def _remove_handler_exact(handler_list, callback) -> bool:
    try:
        while callback in handler_list:
            handler_list.remove(callback)
        return True
    except Exception:
        return False


def _expected_setting_handlers(context=None):
    if not _keeper_enabled(context):
        return ()
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return ()
    result = (
        ('load_post', getattr(handlers, 'load_post', None), _on_load_post),
        ('load_pre', getattr(handlers, 'load_pre', None), _on_load_pre),
        ('save_pre', getattr(handlers, 'save_pre', None), _on_save_pre),
        ('exit_pre', getattr(handlers, 'exit_pre', None), _on_exit_pre),
    )
    return tuple(item for item in result if item[1] is not None)


def _setting_handlers_ok(context=None) -> bool:
    expected = _expected_setting_handlers(context)
    if len(_SETTINGS_HANDLER_RECORDS) != len(expected):
        return False
    ledger = _settings_ledger()
    ledger_records = tuple(ledger.get('handlers', ()) or ()) if isinstance(ledger, dict) else ()
    if len(ledger_records) != len(_SETTINGS_HANDLER_RECORDS):
        return False
    expected_map = {name: (handler_list, callback) for name, handler_list, callback in expected}
    for index, record in enumerate(_SETTINGS_HANDLER_RECORDS):
        name = str(record.get('name') or '')
        pair = expected_map.get(name)
        if pair is None:
            return False
        handler_list, callback = pair
        if record.get('handler_list') is not handler_list or record.get('callback') is not callback:
            return False
        if record.get('token') is not _SETTINGS_OWNER_TOKEN or record.get('generation') != _SETTINGS_GENERATION:
            return False
        if ledger_records[index] is not record:
            return False
        try:
            if sum(1 for item in handler_list if item is callback) != 1:
                return False
        except Exception:
            return False
    return True

def _register_setting_handlers(context=None) -> bool:
    global _SETTINGS_HANDLER_RECORDS, _SETTINGS_LAST_ERROR
    records = []
    try:
        # Remove all exact callbacks first so enabled/disabled transitions cannot
        # leave a duplicate save_pre behind.
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        for list_name, callback in (
            ('load_post', _on_load_post),
            ('load_pre', _on_load_pre),
            ('save_pre', _on_save_pre),
            ('exit_pre', _on_exit_pre),
        ):
            handler_list = getattr(handlers, list_name, None) if handlers is not None else None
            if handler_list is not None:
                _remove_handler_exact(handler_list, callback)
        for name, handler_list, callback in _expected_setting_handlers(context):
            handler_list.append(callback)
            if sum(1 for item in handler_list if item is callback) != 1:
                raise RuntimeError(f'exact handler count failed: {name}')
            records.append({
                'name': name,
                'handler_list': handler_list,
                'callback': callback,
                'token': _SETTINGS_OWNER_TOKEN,
                'generation': _SETTINGS_GENERATION,
                'remover': lambda hl=handler_list, cb=callback: _remove_handler_exact(hl, cb),
            })
        _SETTINGS_HANDLER_RECORDS = records
        ledger = _settings_ledger()
        if ledger is not None:
            ledger['handlers'] = tuple(records)
        return _setting_handlers_ok(context)
    except Exception as exc:
        for record in reversed(records):
            try:
                record['remover']()
            except Exception:
                pass
        _SETTINGS_HANDLER_RECORDS = []
        _SETTINGS_LAST_ERROR = f"handler registration: {type(exc).__name__}: {exc}"
        return False


def _unregister_setting_handlers() -> bool:
    global _SETTINGS_HANDLER_RECORDS
    ok = True
    for record in reversed(tuple(_SETTINGS_HANDLER_RECORDS)):
        try:
            remover = record.get('remover')
            if callable(remover) and remover() is False:
                ok = False
        except Exception:
            ok = False
    _SETTINGS_HANDLER_RECORDS = []
    ledger = _settings_ledger()
    if isinstance(ledger, dict):
        ledger['handlers'] = ()
    return ok


def _cleanup_settings_generation(*, force_cleanup: bool = False) -> bool:
    global _SETTINGS_REGISTERED, _SETTINGS_SUBSCRIPTION_COUNT, _SETTINGS_SUBSCRIPTION_ERRORS
    global _SETTINGS_LAST_ERROR
    _cancel_always_on_restore()
    pending = bool(_SETTINGS_SAVE_PENDING or _SETTINGS_SAVE_TIMER_ACTIVE)
    context = getattr(bpy, 'context', None)
    if not pending and _keeper_enabled(context):
        try:
            pending = bool(
                not _config_path().exists()
                or _signature(collect(context)) != _LAST_SIGNATURE
            )
        except Exception:
            # Teardown is a finite persistence boundary.  If change detection
            # itself fails, attempt the verified write and preserve ownership
            # on failure instead of silently discarding settings.
            pending = True
    # Normal generation replacement preserves the current owner after a failed
    # settings flush. Explicit add-on disable must still retire every native
    # callback and msgbus owner, while reporting the persistence failure.
    flush_ok = True
    if pending and _keeper_enabled(context):
        try:
            flush_ok = bool(save_now(
                context,
                force=True,
                allow_disabled=True,
            ))
            if not flush_ok:
                _SETTINGS_LAST_ERROR = 'pending settings save could not be flushed during teardown'
        except Exception as exc:
            flush_ok = False
            _SETTINGS_LAST_ERROR = f"teardown save: {type(exc).__name__}: {exc}"
        if not flush_ok and not force_cleanup:
            return False
    choice_ok = flush_pending_autosave_choice()
    ok = _cancel_scheduled_save(preserve_pending=not flush_ok)
    ok = bool(_cancel_autosave_choice_retry(preserve_pending=True) and ok and choice_ok)
    try:
        from . import core as _sf_core
        cancel_runtime_sync = getattr(_sf_core, '_sf_cancel_history_runtime_sync', None)
        if callable(cancel_runtime_sync):
            cancel_runtime_sync()
    except Exception:
        pass
    ok = bool(_unregister_setting_handlers() and ok)
    try:
        bpy.msgbus.clear_by_owner(_MSGBUS_OWNER)
    except Exception:
        ok = False
    _SETTINGS_SUBSCRIPTION_COUNT = 0
    _SETTINGS_SUBSCRIPTION_ERRORS = []
    namespace = _settings_namespace()
    if namespace is not None:
        ledger = namespace.get(_SETTINGS_OWNER_KEY)
        if isinstance(ledger, dict) and ledger.get('token') is _SETTINGS_OWNER_TOKEN:
            namespace.pop(_SETTINGS_OWNER_KEY, None)
    _SETTINGS_REGISTERED = False
    return bool(ok and flush_ok)


def _cleanup_previous_settings_owner(ledger) -> bool:
    global _SETTINGS_LAST_ERROR
    if not isinstance(ledger, dict):
        return True
    # A module reload reuses the module globals dictionary, so an old cleanup
    # function can no longer see its old records or msgbus owner. Retire the
    # exact immutable resources stored in the previous driver-namespace ledger.
    has_exact_resources = bool(
        ledger.get('handlers')
        or ledger.get('subscription_owner') is not None
        or ledger.get('save_timer_callback') is not None
        or ledger.get('autosave_choice_timer_callback') is not None
    )
    if has_exact_resources:
        ok = True
        if bool(ledger.get('save_pending') or ledger.get('save_timer_active')) and bool(
            ledger.get('keeper_enabled', _keeper_enabled(getattr(bpy, 'context', None)))
        ):
            try:
                flushed = bool(save_now(
                    getattr(bpy, 'context', None),
                    force=True,
                    allow_disabled=True,
                ))
                if not flushed:
                    _SETTINGS_LAST_ERROR = 'previous-generation pending settings save could not be flushed'
                    return False
            except Exception as exc:
                _SETTINGS_LAST_ERROR = f"previous-generation save: {type(exc).__name__}: {exc}"
                return False
        prior_choice = ledger.get('autosave_choice_pending')
        if (
            isinstance(prior_choice, bool)
            and bool(ledger.get('keeper_enabled', _keeper_enabled(getattr(bpy, 'context', None))))
            and not _commit_autosave_choice_pair(prior_choice, source='user_api')
        ):
            _SETTINGS_LAST_ERROR = 'previous-generation explicit autosave choice could not be flushed'
            return False
        callback = ledger.get('save_timer_callback')
        if callable(callback):
            try:
                if bpy.app.timers.is_registered(callback):
                    bpy.app.timers.unregister(callback)
                ok = bool(not bpy.app.timers.is_registered(callback) and ok)
            except Exception:
                ok = False
        choice_callback = ledger.get('autosave_choice_timer_callback')
        if callable(choice_callback):
            try:
                if bpy.app.timers.is_registered(choice_callback):
                    bpy.app.timers.unregister(choice_callback)
                ok = bool(not bpy.app.timers.is_registered(choice_callback) and ok)
            except Exception:
                ok = False
        for record in reversed(tuple(ledger.get('handlers', ()) or ())):
            try:
                handler_list = record.get('handler_list')
                handler = record.get('callback')
                if handler_list is None or handler is None:
                    ok = False
                    continue
                while handler in handler_list:
                    handler_list.remove(handler)
                ok = bool(not any(item is handler for item in tuple(handler_list)) and ok)
            except Exception:
                ok = False
        owner = ledger.get('subscription_owner')
        if owner is not None:
            try:
                bpy.msgbus.clear_by_owner(owner)
            except Exception:
                ok = False
        return bool(ok)
    cleanup = ledger.get('cleanup')
    if not callable(cleanup):
        return False
    try:
        return bool(cleanup())
    except Exception:
        return False


def runtime_status(context=None) -> dict[str, Any]:
    owner_ok = _settings_owner_ok()
    handlers_ok = _setting_handlers_ok(context) if owner_ok else False
    keeper_enabled = _keeper_enabled(context)
    expected_subscription_state = (
        _SETTINGS_SUBSCRIPTION_COUNT >= 1
        if keeper_enabled
        else _SETTINGS_SUBSCRIPTION_COUNT == 0
    )
    subscriptions_ok = bool(
        owner_ok
        and expected_subscription_state
        and not _SETTINGS_SUBSCRIPTION_ERRORS
        and _settings_ledger().get('subscription_count') == _SETTINGS_SUBSCRIPTION_COUNT
    )
    registered = bool(_SETTINGS_REGISTERED and owner_ok and handlers_ok and subscriptions_ok)
    return {
        'registered': registered,
        'owner_ok': owner_ok,
        'generation': _SETTINGS_GENERATION,
        'handlers_ok': handlers_ok,
        'handler_count': len(_SETTINGS_HANDLER_RECORDS),
        'expected_handler_count': len(_expected_setting_handlers(context)),
        'subscriptions_ok': subscriptions_ok,
        'subscription_count': int(_SETTINGS_SUBSCRIPTION_COUNT),
        'subscriptions_required': bool(keeper_enabled),
        'save_timer_active': bool(_SETTINGS_SAVE_TIMER_ACTIVE),
        'save_pending': bool(_SETTINGS_SAVE_PENDING),
        'autosave_choice_timer_active': bool(_AUTOSAVE_CHOICE_TIMER_ACTIVE),
        'autosave_choice_pending': _AUTOSAVE_CHOICE_PENDING,
        'autosave_choice_retry_attempts': int(_AUTOSAVE_CHOICE_RETRY_ATTEMPTS),
        'autosave_choice_explicit': _read_explicit_autosave_choice(),
        'autosave_choice_schema': _AUTOSAVE_CHOICE_SCHEMA,
        'autosave_install_epoch': _AUTOSAVE_INSTALL_EPOCH,
        'autosave_suite_version': _AUTOSAVE_SUITE_VERSION,
        'subscription_owner_exact': bool(owner_ok and _settings_ledger().get('subscription_owner') is _MSGBUS_OWNER),
        'json_read_errors': dict(_JSON_READ_ERRORS),
        'last_error': str(_SETTINGS_LAST_ERROR or ''),
    }


def get_registration_status(context=None) -> dict[str, Any]:
    """Exact identity status used by the sole History lifecycle owner."""
    status = runtime_status(context)
    status['msgbus_owner_ok'] = bool(
        status.get('subscriptions_ok') and status.get('subscription_owner_exact')
    )
    return status


def register(context=None, *, apply_saved: bool = True) -> bool:
    global _SETTINGS_REGISTERED, _SETTINGS_LAST_ERROR, _LAST_SIGNATURE
    context = context or getattr(bpy, 'context', None)
    _ensure_default_autosave_policy_record()
    if not _apply_autosave_choice_only(context):
        _SETTINGS_LAST_ERROR = 'autosave choice could not be applied to live settings'
        return False
    if runtime_status(context).get('registered'):
        return True
    namespace = _settings_namespace()
    if namespace is None:
        _SETTINGS_LAST_ERROR = 'bpy.app.driver_namespace is unavailable'
        return False
    for legacy_key in _SETTINGS_LEGACY_OWNER_KEYS:
        previous = namespace.get(legacy_key)
        if previous is None:
            continue
        if not _cleanup_previous_settings_owner(previous):
            _SETTINGS_LAST_ERROR = f'previous settings owner cleanup failed: {legacy_key}'
            return False
        namespace.pop(legacy_key, None)
    previous = namespace.get(_SETTINGS_OWNER_KEY)
    if isinstance(previous, dict) and previous.get('token') is not _SETTINGS_OWNER_TOKEN:
        if not _cleanup_previous_settings_owner(previous):
            _SETTINGS_LAST_ERROR = 'previous settings owner cleanup failed'
            return False
        namespace.pop(_SETTINGS_OWNER_KEY, None)
    current = namespace.get(_SETTINGS_OWNER_KEY)
    has_current_generation = bool(
        (isinstance(current, dict) and current.get('token') is _SETTINGS_OWNER_TOKEN)
        or _SETTINGS_REGISTERED
        or _SETTINGS_HANDLER_RECORDS
        or _SETTINGS_SUBSCRIPTION_COUNT
    )
    if has_current_generation and not _cleanup_settings_generation():
        _SETTINGS_LAST_ERROR = _SETTINGS_LAST_ERROR or 'current settings owner cleanup failed'
        return False
    namespace[_SETTINGS_OWNER_KEY] = {
        'schema': 1,
        'token': _SETTINGS_OWNER_TOKEN,
        'generation': _SETTINGS_GENERATION,
        'handlers': (),
        'subscription_owner': _MSGBUS_OWNER,
        'subscription_count': 0,
        'save_timer_active': False,
        'save_pending': False,
        'save_timer_callback': _scheduled_save_once,
        'keeper_enabled': bool(_keeper_enabled(context)),
        'autosave_choice_timer_active': bool(_AUTOSAVE_CHOICE_TIMER_ACTIVE),
        'autosave_choice_pending': _AUTOSAVE_CHOICE_PENDING,
        'autosave_choice_retry_attempts': int(_AUTOSAVE_CHOICE_RETRY_ATTEMPTS),
        'autosave_choice_timer_callback': _scheduled_autosave_choice_once,
        'cleanup': _cleanup_settings_generation,
    }
    try:
        if apply_saved and _keeper_enabled(context):
            apply_all(context)
        _LAST_SIGNATURE = _signature(collect(context))
        if not _register_setting_handlers(context):
            raise RuntimeError(_SETTINGS_LAST_ERROR or 'settings handler registration failed')
        if not _register_setting_subscriptions(context):
            raise RuntimeError(_SETTINGS_LAST_ERROR or 'settings subscription registration failed')
        _SETTINGS_REGISTERED = True
        status = runtime_status(context)
        if not status.get('registered'):
            raise RuntimeError('settings exact-owner validation failed')
        _SETTINGS_LAST_ERROR = ''
        _schedule_always_on_restore()
        return True
    except Exception as exc:
        _SETTINGS_LAST_ERROR = f"{type(exc).__name__}: {exc}"
        _cleanup_settings_generation()
        return False


def ensure_runtime(context=None, *, apply_saved: bool = False) -> bool:
    if runtime_status(context).get('registered'):
        return True
    if _rehydrate_settings_owner_after_load() and runtime_status(context).get('registered'):
        return True
    return bool(register(context, apply_saved=apply_saved))


def unregister() -> bool:
    return _cleanup_settings_generation(force_cleanup=True)


