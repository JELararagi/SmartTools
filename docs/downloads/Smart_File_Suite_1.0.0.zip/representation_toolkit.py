# -----------------------------------------------------------------------------
#  Representation Toolkit / Lightweight Display / Snapshot Restore
# -----------------------------------------------------------------------------

import json
import time


_SF_REP_SCOPE_ITEMS = [
    ('LINKED', 'Linked', 'Only affect linked scene objects and linked collections so heavy referenced scenes can be previewed or hidden safely.'),
    ('OVERRIDES', 'Overrides', 'Only affect library override objects and override collections so local editable layers can be previewed separately from the linked source.'),
    ('LINKED_AND_OVERRIDES', 'Linked + Overrides', 'Affect both linked data and override layers together. Use this when the whole referenced assembly should change display state in one step.'),
    ('SELECTED', 'Selected', 'Only affect the current selection, or the active object when nothing is selected.'),
]

_SF_REP_ACTION_ITEMS = [
    ('LAYOUT_PROXY', 'Layout Proxy', 'Use bounds display while keeping the target visible in both viewport and render. This is the safest lightweight scene-assembly style mode for layout, blocking, and scene navigation.'),
    ('ANIMATION_PROXY', 'Animation Proxy', 'Use wire display while keeping the target visible. This is lighter than full draw but keeps silhouettes readable for timing and camera checks.'),
    ('LOOKDEV_FULL', 'LookDev Full', 'Use textured display and enable both viewport and render visibility. This is the closest one-click full representation mode for shading review.'),
    ('BOUNDS', 'Bounds', 'Change supported target objects to bounds display so heavy referenced scenes become lighter and safer to navigate.'),
    ('WIRE', 'Wire', 'Change supported target objects to wire display so the shape stays readable while draw cost stays lighter than textured review.'),
    ('SOLID', 'Solid', 'Return supported target objects to normal solid display.'),
    ('TEXTURED', 'Textured', 'Switch supported target objects to textured display for lookdev and final preview checks.'),
    ('RENDER_ONLY', 'Render Only', 'Hide the target in the viewport but keep it enabled for render. Use this like an offloaded render representation.'),
    ('VIEWPORT_ONLY', 'Viewport Only', 'Show the target in the viewport but exclude it from render. Use this for guides, stand-ins, or temporary layout helpers.'),
    ('HIDE_VIEWPORT', 'Hide in Viewport', 'Hide the target objects and collections in the viewport only.'),
    ('SHOW_VIEWPORT', 'Show in Viewport', 'Show the target objects and collections in the viewport again.'),
    ('HIDE_RENDER', 'Hide in Render', 'Exclude the target objects and collections from rendering only.'),
    ('SHOW_RENDER', 'Show in Render', 'Include the target objects and collections in rendering again.'),
    ('DISABLE_BOTH', 'Disable Both', 'Hide the target objects and collections in both viewport and render. This behaves like a lightweight disable switch without deleting any data.'),
    ('ENABLE_BOTH', 'Enable Both', 'Restore the target objects and collections in both viewport and render.'),
]


def _sf_rep_selected_objects(context) -> list[object]:
    selected = list(getattr(context, 'selected_objects', []) or [])
    active = getattr(context, 'active_object', None)
    if not selected and active is not None:
        selected = [active]
    out = []
    seen = set()
    for ob in selected:
        if ob is None:
            continue
        name = str(getattr(ob, 'name', '') or '')
        if not name or name in seen:
            continue
        seen.add(name)
        out.append(ob)
    return out


def _sf_rep_object_matches_scope(ob, scope: str) -> bool:
    scope = str(scope or 'LINKED').upper()
    if ob is None:
        return False
    if scope == 'SELECTED':
        return True
    if scope == 'OVERRIDES':
        return bool(getattr(ob, 'override_library', None))
    if scope == 'LINKED_AND_OVERRIDES':
        return bool(getattr(ob, 'library', None) or getattr(ob, 'override_library', None))
    return bool(getattr(ob, 'library', None))


def _sf_rep_collection_matches_scope(coll, scope: str) -> bool:
    scope = str(scope or 'LINKED').upper()
    if coll is None:
        return False
    if scope == 'SELECTED':
        return True
    if scope == 'OVERRIDES':
        return bool(getattr(coll, 'override_library', None))
    if scope == 'LINKED_AND_OVERRIDES':
        return bool(getattr(coll, 'library', None) or getattr(coll, 'override_library', None))
    return bool(getattr(coll, 'library', None))


def _sf_rep_target_objects(context, scope: str = 'LINKED') -> list[object]:
    scope = str(scope or 'LINKED').upper()
    if scope == 'SELECTED':
        return _sf_rep_selected_objects(context)
    scene = getattr(context, 'scene', None)
    try:
        candidates = list(getattr(scene, 'objects', []) or [])
    except Exception:
        candidates = []
    out = []
    seen = set()
    for ob in candidates:
        if not _sf_rep_object_matches_scope(ob, scope):
            continue
        name = str(getattr(ob, 'name', '') or '')
        if not name or name in seen:
            continue
        seen.add(name)
        out.append(ob)
    return out


def _sf_rep_target_collections(context, scope: str = 'LINKED') -> list[object]:
    scope = str(scope or 'LINKED').upper()
    if scope == 'SELECTED':
        out = []
        seen = set()
        for ob in _sf_rep_selected_objects(context):
            try:
                cols = list(getattr(ob, 'users_collection', []) or [])
            except Exception:
                cols = []
            for coll in cols:
                name = str(getattr(coll, 'name', '') or '')
                if not name or name in seen:
                    continue
                seen.add(name)
                out.append(coll)
        return out
    out = []
    seen = set()
    for coll in getattr(bpy.data, 'collections', []) or []:
        if not _sf_rep_collection_matches_scope(coll, scope):
            continue
        name = str(getattr(coll, 'name', '') or '')
        if not name or name in seen:
            continue
        seen.add(name)
        out.append(coll)
    return out


def _sf_rep_capture_entry(target, kind: str) -> dict:
    data = {
        'kind': str(kind or ''),
        'name': str(getattr(target, 'name', '') or ''),
        'library': getattr(getattr(target, 'library', None), 'filepath', None),
    }
    for attr in ('hide_viewport', 'hide_render', 'display_type'):
        try:
            data[attr] = getattr(target, attr)
        except Exception:
            pass
    return data



def _sf_rep_count_display(items, wanted: str) -> int:
    wanted = str(wanted or '').upper()
    total = 0
    for item in list(items or []):
        try:
            if str(getattr(item, 'display_type', '') or '').upper() == wanted:
                total += 1
        except Exception:
            pass
    return total



def _sf_rep_count_flag(items, attr: str) -> int:
    total = 0
    for item in list(items or []):
        try:
            if bool(getattr(item, attr, False)):
                total += 1
        except Exception:
            pass
    return total



def _sf_rep_count_visibility_mode(items, *, hide_viewport: bool | None = None, hide_render: bool | None = None) -> int:
    total = 0
    for item in list(items or []):
        try:
            if hide_viewport is not None and bool(getattr(item, 'hide_viewport', False)) != bool(hide_viewport):
                continue
            if hide_render is not None and bool(getattr(item, 'hide_render', False)) != bool(hide_render):
                continue
            total += 1
        except Exception:
            pass
    return total



def _sf_rep_set_display_type(target, display_type: str) -> tuple[bool, bool]:
    display_type = str(display_type or '').upper()
    if not display_type or not hasattr(target, 'display_type'):
        return False, False
    try:
        current = str(getattr(target, 'display_type', '') or '').upper()
    except Exception:
        current = ''
    if current == display_type:
        return False, True
    try:
        setattr(target, 'display_type', display_type)
        return True, True
    except Exception:
        fallback_map = {
            'TEXTURED': 'SOLID',
            'WIRE': 'BOUNDS',
        }
        fallback = str(fallback_map.get(display_type) or '').upper()
        if fallback and current != fallback:
            try:
                setattr(target, 'display_type', fallback)
                return True, True
            except Exception:
                pass
    return False, False



def _sf_rep_apply_visibility(target, *, hide_viewport: bool | None = None, hide_render: bool | None = None) -> bool:
    changed = False
    if hide_viewport is not None and hasattr(target, 'hide_viewport'):
        want = bool(hide_viewport)
        try:
            if bool(getattr(target, 'hide_viewport', False)) != want:
                target.hide_viewport = want
                changed = True
        except Exception:
            pass
        try:
            if hasattr(target, 'hide_set'):
                target.hide_set(want)
        except Exception:
            pass
    if hide_render is not None and hasattr(target, 'hide_render'):
        want = bool(hide_render)
        try:
            if bool(getattr(target, 'hide_render', False)) != want:
                target.hide_render = want
                changed = True
        except Exception:
            pass
    return changed



def _sf_rep_scene_summary(context) -> dict:
    linked_objects = _sf_rep_target_objects(context, 'LINKED')
    override_objects = _sf_rep_target_objects(context, 'OVERRIDES')
    linked_collections = _sf_rep_target_collections(context, 'LINKED')
    override_collections = _sf_rep_target_collections(context, 'OVERRIDES')
    wm = getattr(context, 'window_manager', None)
    snapshot_entries = 0
    if wm is not None:
        try:
            snap = json.loads(str(getattr(wm, 'sf_rep_snapshot_json', '') or ''))
            snapshot_entries = len(list((snap or {}).get('entries', []) or []))
        except Exception:
            snapshot_entries = 0

    return {
        'linked_object_count': len(linked_objects),
        'override_object_count': len(override_objects),
        'linked_collection_count': len(linked_collections),
        'override_collection_count': len(override_collections),
        'linked_bounds_count': _sf_rep_count_display(linked_objects, 'BOUNDS'),
        'override_bounds_count': _sf_rep_count_display(override_objects, 'BOUNDS'),
        'linked_wire_count': _sf_rep_count_display(linked_objects, 'WIRE'),
        'override_wire_count': _sf_rep_count_display(override_objects, 'WIRE'),
        'linked_textured_count': _sf_rep_count_display(linked_objects, 'TEXTURED'),
        'override_textured_count': _sf_rep_count_display(override_objects, 'TEXTURED'),
        'linked_hidden_viewport_count': _sf_rep_count_flag(linked_objects, 'hide_viewport'),
        'linked_hidden_render_count': _sf_rep_count_flag(linked_objects, 'hide_render'),
        'override_hidden_viewport_count': _sf_rep_count_flag(override_objects, 'hide_viewport'),
        'override_hidden_render_count': _sf_rep_count_flag(override_objects, 'hide_render'),
        'linked_render_only_count': _sf_rep_count_visibility_mode(linked_objects, hide_viewport=True, hide_render=False),
        'override_render_only_count': _sf_rep_count_visibility_mode(override_objects, hide_viewport=True, hide_render=False),
        'linked_viewport_only_count': _sf_rep_count_visibility_mode(linked_objects, hide_viewport=False, hide_render=True),
        'override_viewport_only_count': _sf_rep_count_visibility_mode(override_objects, hide_viewport=False, hide_render=True),
        'linked_hidden_collection_count': _sf_rep_count_flag(linked_collections, 'hide_viewport'),
        'override_hidden_collection_count': _sf_rep_count_flag(override_collections, 'hide_viewport'),
        'snapshot_entries': int(snapshot_entries or 0),
    }



def _sf_rep_store_snapshot(context, scope: str = 'LINKED_AND_OVERRIDES') -> dict:
    entries = []
    for ob in _sf_rep_target_objects(context, scope):
        entries.append(_sf_rep_capture_entry(ob, 'OBJECT'))
    for coll in _sf_rep_target_collections(context, scope):
        entries.append(_sf_rep_capture_entry(coll, 'COLLECTION'))
    payload = {
        'scope': str(scope or 'LINKED_AND_OVERRIDES').upper(),
        'created_at': int(time.time()),
        'entries': entries,
    }
    wm = getattr(context, 'window_manager', None)
    # An empty scope is reported as a failure by the caller, so it must not
    # replace the snapshot the user can still restore.
    if wm is not None and entries:
        try:
            wm.sf_rep_snapshot_json = json.dumps(payload, ensure_ascii=False)
        except Exception:
            pass
    return payload


def _sf_rep_restore_snapshot(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    if wm is None:
        return {'restored': 0, 'missing': 0, 'failed': 0, 'entries': 0}
    raw = str(getattr(wm, 'sf_rep_snapshot_json', '') or '')
    if not raw.strip():
        return {'restored': 0, 'missing': 0, 'failed': 0, 'entries': 0}
    try:
        payload = json.loads(raw)
    except Exception:
        return {'restored': 0, 'missing': 0, 'failed': 1, 'entries': 0}
    entries = list((payload or {}).get('entries', []) or [])
    restored = 0
    missing = 0
    failed = 0
    for entry in entries:
        kind = str(entry.get('kind', '') or '').upper()
        name = str(entry.get('name', '') or '')
        if not name:
            continue
        target = None
        try:
            if kind == 'COLLECTION':
                # リンク元とオーバーライドは同じ名前なので、ライブラリまで指定して引く
                target = bpy.data.collections.get((name, entry.get('library')))
            else:
                target = bpy.data.objects.get((name, entry.get('library')))
        except Exception:
            target = None
        if target is None:
            missing += 1
            continue
        try:
            if 'display_type' in entry and hasattr(target, 'display_type'):
                setattr(target, 'display_type', entry.get('display_type'))
        except Exception:
            failed += 1
        try:
            if 'hide_viewport' in entry and hasattr(target, 'hide_viewport'):
                setattr(target, 'hide_viewport', bool(entry.get('hide_viewport')))
        except Exception:
            failed += 1
        try:
            if kind != 'COLLECTION':
                target.hide_set(bool(entry.get('hide_viewport', False)))
        except Exception:
            pass
        try:
            if 'hide_render' in entry and hasattr(target, 'hide_render'):
                setattr(target, 'hide_render', bool(entry.get('hide_render')))
        except Exception:
            failed += 1
        restored += 1
    return {'restored': restored, 'missing': missing, 'failed': failed, 'entries': len(entries)}


def _sf_rep_apply_object_action(ob, action: str) -> tuple[bool, bool]:
    action = str(action or '').upper()
    changed = False
    supported = True
    try:
        if action == 'LAYOUT_PROXY':
            disp_changed, _disp_supported = _sf_rep_set_display_type(ob, 'BOUNDS')
            changed = disp_changed or changed
            changed = _sf_rep_apply_visibility(ob, hide_viewport=False, hide_render=False) or changed
        elif action == 'ANIMATION_PROXY':
            disp_changed, _disp_supported = _sf_rep_set_display_type(ob, 'WIRE')
            changed = disp_changed or changed
            changed = _sf_rep_apply_visibility(ob, hide_viewport=False, hide_render=False) or changed
        elif action == 'LOOKDEV_FULL':
            disp_changed, _disp_supported = _sf_rep_set_display_type(ob, 'TEXTURED')
            changed = disp_changed or changed
            changed = _sf_rep_apply_visibility(ob, hide_viewport=False, hide_render=False) or changed
        elif action == 'BOUNDS':
            changed, supported = _sf_rep_set_display_type(ob, 'BOUNDS')
        elif action == 'WIRE':
            changed, supported = _sf_rep_set_display_type(ob, 'WIRE')
        elif action == 'SOLID':
            changed, supported = _sf_rep_set_display_type(ob, 'SOLID')
        elif action == 'TEXTURED':
            changed, supported = _sf_rep_set_display_type(ob, 'TEXTURED')
        elif action == 'RENDER_ONLY':
            changed = _sf_rep_apply_visibility(ob, hide_viewport=True, hide_render=False)
        elif action == 'VIEWPORT_ONLY':
            changed = _sf_rep_apply_visibility(ob, hide_viewport=False, hide_render=True)
        elif action == 'HIDE_VIEWPORT':
            changed = _sf_rep_apply_visibility(ob, hide_viewport=True)
        elif action == 'SHOW_VIEWPORT':
            changed = _sf_rep_apply_visibility(ob, hide_viewport=False)
        elif action == 'HIDE_RENDER':
            changed = _sf_rep_apply_visibility(ob, hide_render=True)
        elif action == 'SHOW_RENDER':
            changed = _sf_rep_apply_visibility(ob, hide_render=False)
        elif action == 'DISABLE_BOTH':
            changed = _sf_rep_apply_visibility(ob, hide_viewport=True, hide_render=True)
        elif action == 'ENABLE_BOTH':
            changed = _sf_rep_apply_visibility(ob, hide_viewport=False, hide_render=False)
        else:
            supported = False
    except Exception:
        raise
    return changed, supported



def _sf_rep_apply_collection_action(coll, action: str) -> tuple[bool, bool]:
    action = str(action or '').upper()
    changed = False
    supported = True
    try:
        if action in {'LAYOUT_PROXY', 'ANIMATION_PROXY', 'LOOKDEV_FULL', 'ENABLE_BOTH'}:
            changed = _sf_rep_apply_visibility(coll, hide_viewport=False, hide_render=False)
        elif action == 'RENDER_ONLY':
            changed = _sf_rep_apply_visibility(coll, hide_viewport=True, hide_render=False)
        elif action == 'VIEWPORT_ONLY':
            changed = _sf_rep_apply_visibility(coll, hide_viewport=False, hide_render=True)
        elif action == 'HIDE_VIEWPORT':
            changed = _sf_rep_apply_visibility(coll, hide_viewport=True)
        elif action == 'SHOW_VIEWPORT':
            changed = _sf_rep_apply_visibility(coll, hide_viewport=False)
        elif action == 'HIDE_RENDER':
            changed = _sf_rep_apply_visibility(coll, hide_render=True)
        elif action == 'SHOW_RENDER':
            changed = _sf_rep_apply_visibility(coll, hide_render=False)
        elif action == 'DISABLE_BOTH':
            changed = _sf_rep_apply_visibility(coll, hide_viewport=True, hide_render=True)
        else:
            supported = False
    except Exception:
        raise
    return changed, supported



def _sf_rep_apply_action(context, scope: str = 'LINKED', action: str = 'BOUNDS', include_collections: bool = True) -> dict:
    objects = _sf_rep_target_objects(context, scope)
    collections = _sf_rep_target_collections(context, scope) if include_collections else []
    changed = 0
    skipped = 0
    failed = 0
    for ob in objects:
        try:
            item_changed, supported = _sf_rep_apply_object_action(ob, action)
            if not supported:
                skipped += 1
            elif item_changed:
                changed += 1
        except Exception:
            failed += 1
    for coll in collections:
        try:
            item_changed, supported = _sf_rep_apply_collection_action(coll, action)
            if not supported:
                skipped += 1
            elif item_changed:
                changed += 1
        except Exception:
            failed += 1
    return {
        'scope': str(scope or 'LINKED').upper(),
        'action': str(action or '').upper(),
        'object_count': len(objects),
        'collection_count': len(collections),
        'changed': int(changed or 0),
        'skipped': int(skipped or 0),
        'failed': int(failed or 0),
    }


class SF_OT_representation_apply(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_representation_apply'
    bl_label = 'Apply'
    bl_description = 'Apply a lightweight display or visibility mode to linked assets, overrides, or the current selection. Use this to preview heavy referenced scenes safely without changing library paths or deleting data.'
    bl_options = {'UNDO'}

    scope: EnumProperty(name='Scope', items=_SF_REP_SCOPE_ITEMS, default='LINKED')
    action: EnumProperty(name='Action', items=_SF_REP_ACTION_ITEMS, default='BOUNDS')
    include_collections: BoolProperty(name='Include collections', default=True, options={'HIDDEN'}, description='Also apply collection visibility changes where the chosen action supports it.')

    def execute(self, context):
        result = _sf_rep_apply_action(context, self.scope, self.action, include_collections=bool(self.include_collections))
        try:
            _sf_append_activity(
                context,
                _t('Applied representation mode'),
                f"{result.get('action')} / {result.get('scope')}",
                'MOD_WIREFRAME',
            )
        except Exception:
            pass
        changed = int(result.get('changed', 0) or 0)
        failed = int(result.get('failed', 0) or 0)
        if changed == 0 and failed == 0:
            self.report({'WARNING'}, _t('No matching targets were changed'))
            return {'CANCELLED'}
        level = {'WARNING'} if failed else {'INFO'}
        self.report(level, f"{_t('Changed')}: {changed} | {_t('Failed')}: {failed}")
        return {'FINISHED'}


class SF_OT_representation_store_snapshot(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_representation_store_snapshot'
    bl_label = 'Store Snapshot'
    bl_description = 'Capture the current display and visibility state of linked assets, overrides, or the current selection so you can switch to lighter preview modes now and restore the previous state later.'
    bl_options = {'UNDO'}

    scope: EnumProperty(name='Scope', items=_SF_REP_SCOPE_ITEMS, default='LINKED_AND_OVERRIDES')

    def execute(self, context):
        payload = _sf_rep_store_snapshot(context, self.scope)
        count = len(list(payload.get('entries', []) or []))
        try:
            _sf_append_activity(context, _t('Stored representation snapshot'), str(count), 'FILE_TICK')
        except Exception:
            pass
        if count == 0:
            self.report({'WARNING'}, _t('No targets were available for the requested snapshot scope'))
            return {'CANCELLED'}
        self.report({'INFO'}, f"{_t('Stored')}: {count}")
        return {'FINISHED'}


class SF_OT_representation_restore_snapshot(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_representation_restore_snapshot'
    bl_label = 'Restore Snapshot'
    bl_description = 'Restore the last stored display and visibility snapshot for linked assets, overrides, and related collections. Use this after temporary bounds or hide modes when you want to return to the previous scene state.'
    bl_options = {'UNDO'}

    def execute(self, context):
        result = _sf_rep_restore_snapshot(context)
        restored = int(result.get('restored', 0) or 0)
        missing = int(result.get('missing', 0) or 0)
        failed = int(result.get('failed', 0) or 0)
        try:
            _sf_append_activity(context, _t('Restored representation snapshot'), str(restored), 'RECOVER_LAST')
        except Exception:
            pass
        if restored == 0 and missing == 0 and failed == 0:
            self.report({'WARNING'}, _t('No saved representation snapshot was found'))
            return {'CANCELLED'}
        level = {'WARNING'} if (missing or failed) else {'INFO'}
        self.report(level, f"{_t('Restored')}: {restored} | {_t('Missing')}: {missing} | {_t('Failed')}: {failed}")
        return {'FINISHED'}


class SF_OT_representation_open(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = 'import_scene.sfs_representation_open'
    bl_label = 'Open'
    bl_description = 'Open a compact board for switching linked scenes between bounds, visible, hidden, and restore-ready states. This gives beginners safe preview controls and gives advanced users a quick scene-assembly style representation layer.'
    bl_options = set()

    popup_width: IntProperty(default=620, min=440, max=860, options={'HIDDEN'})

    def invoke(self, context, event):
        try:
            _sf_append_activity(context, _t('Opened representation toolkit'), '', 'MOD_WIREFRAME')
        except Exception:
            pass
        return context.window_manager.invoke_popup(self, width=self.popup_width)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        payload = _sf_rep_scene_summary(context)
        _sf_draw_dialog_header(
            layout,
            'Representation Toolkit',
            'Switch linked scenes between layout proxy, animation proxy, lookdev full, render-only, hidden, and restored states without changing file paths or deleting any data.',
            'MOD_WIREFRAME',
        )

        summary = layout.box()
        _sf_draw_section_intro(
            summary,
            'Representation Snapshot',
            'Read this first to see whether the current linked layers are already in proxy, review, or render-only states before you apply another pass.',
            'NONE',
        )
        _sf_draw_state_line(summary, 'Linked Scene Objects', 'READY' if int(payload.get('linked_object_count', 0) or 0) else 'NOT SET', detail=str(int(payload.get('linked_object_count', 0) or 0)))
        _sf_draw_state_line(summary, 'Override Scene Objects', 'READY' if int(payload.get('override_object_count', 0) or 0) else 'NOT SET', detail=str(int(payload.get('override_object_count', 0) or 0)))
        _sf_draw_state_line(summary, 'Layout Proxies', 'READY' if (int(payload.get('linked_bounds_count', 0) or 0) or int(payload.get('override_bounds_count', 0) or 0)) else 'NOT SET', detail=f"L {int(payload.get('linked_bounds_count', 0) or 0)} / O {int(payload.get('override_bounds_count', 0) or 0)}")
        _sf_draw_state_line(summary, 'Animation Proxies', 'READY' if (int(payload.get('linked_wire_count', 0) or 0) or int(payload.get('override_wire_count', 0) or 0)) else 'NOT SET', detail=f"L {int(payload.get('linked_wire_count', 0) or 0)} / O {int(payload.get('override_wire_count', 0) or 0)}")
        _sf_draw_state_line(summary, 'LookDev Full', 'READY' if (int(payload.get('linked_textured_count', 0) or 0) or int(payload.get('override_textured_count', 0) or 0)) else 'NOT SET', detail=f"L {int(payload.get('linked_textured_count', 0) or 0)} / O {int(payload.get('override_textured_count', 0) or 0)}")
        _sf_draw_state_line(summary, 'Render Only', 'READY' if (int(payload.get('linked_render_only_count', 0) or 0) or int(payload.get('override_render_only_count', 0) or 0)) else 'NOT SET', detail=f"L {int(payload.get('linked_render_only_count', 0) or 0)} / O {int(payload.get('override_render_only_count', 0) or 0)}")
        _sf_draw_state_line(summary, 'Viewport Only', 'READY' if (int(payload.get('linked_viewport_only_count', 0) or 0) or int(payload.get('override_viewport_only_count', 0) or 0)) else 'NOT SET', detail=f"L {int(payload.get('linked_viewport_only_count', 0) or 0)} / O {int(payload.get('override_viewport_only_count', 0) or 0)}")
        _sf_draw_state_line(summary, 'Representation Snapshot', 'READY' if int(payload.get('snapshot_entries', 0) or 0) else 'NOT SET', detail=str(int(payload.get('snapshot_entries', 0) or 0)))

        presets = layout.box()
        _sf_draw_section_intro(
            presets,
            'Assembly Presets',
            'Use these as higher-level representations inspired by scene assembly tools: layout proxy keeps bounds visible, animation proxy keeps wire silhouettes, and lookdev full restores textured review.',
            'MOD_WIREFRAME',
        )
        _sf_draw_action_block(
            presets,
            primary_actions=[
                ('import_scene.sfs_representation_apply', 'Linked Layout Proxy', 'MOD_WIREFRAME', {'scope': 'LINKED', 'action': 'LAYOUT_PROXY'}),
                ('import_scene.sfs_representation_apply', 'Linked Animation Proxy', 'SHADING_WIRE', {'scope': 'LINKED', 'action': 'ANIMATION_PROXY'}),
                ('import_scene.sfs_representation_apply', 'Linked LookDev Full', 'SHADING_TEXTURE', {'scope': 'LINKED', 'action': 'LOOKDEV_FULL'}),
                ('import_scene.sfs_representation_apply', 'Linked Solid', 'SHADING_SOLID', {'scope': 'LINKED', 'action': 'SOLID'}),
            ],
            secondary_actions=[
                ('import_scene.sfs_representation_apply', 'Overrides Layout Proxy', 'MOD_WIREFRAME', {'scope': 'OVERRIDES', 'action': 'LAYOUT_PROXY'}),
                ('import_scene.sfs_representation_apply', 'Overrides Animation Proxy', 'SHADING_WIRE', {'scope': 'OVERRIDES', 'action': 'ANIMATION_PROXY'}),
                ('import_scene.sfs_representation_apply', 'Overrides LookDev Full', 'SHADING_TEXTURE', {'scope': 'OVERRIDES', 'action': 'LOOKDEV_FULL'}),
                ('import_scene.sfs_representation_apply', 'Overrides Solid', 'SHADING_SOLID', {'scope': 'OVERRIDES', 'action': 'SOLID'}),
            ],
        )

        selected_box = layout.box()
        _sf_draw_section_intro(
            selected_box,
            'Selected Helpers',
            'Use the selected-scope buttons when you want to test a representation on only the current pick before you roll it out to all linked layers.',
            'RESTRICT_SELECT_OFF',
        )
        _sf_draw_action_block(
            selected_box,
            primary_actions=[
                ('import_scene.sfs_representation_apply', 'Selected Layout Proxy', 'MOD_WIREFRAME', {'scope': 'SELECTED', 'action': 'LAYOUT_PROXY'}),
                ('import_scene.sfs_representation_apply', 'Selected Animation Proxy', 'SHADING_WIRE', {'scope': 'SELECTED', 'action': 'ANIMATION_PROXY'}),
                ('import_scene.sfs_representation_apply', 'Selected LookDev Full', 'SHADING_TEXTURE', {'scope': 'SELECTED', 'action': 'LOOKDEV_FULL'}),
                ('import_scene.sfs_representation_apply', 'Selected Solid', 'SHADING_SOLID', {'scope': 'SELECTED', 'action': 'SOLID'}),
            ],
            secondary_actions=[
                ('import_scene.sfs_representation_apply', 'Selected Bounds', 'MOD_WIREFRAME', {'scope': 'SELECTED', 'action': 'BOUNDS'}),
                ('import_scene.sfs_representation_apply', 'Selected Wire', 'SHADING_WIRE', {'scope': 'SELECTED', 'action': 'WIRE'}),
                ('import_scene.sfs_representation_apply', 'Selected Textured', 'SHADING_TEXTURE', {'scope': 'SELECTED', 'action': 'TEXTURED'}),
                ('import_scene.sfs_representation_apply', 'Selected Render Only', 'RESTRICT_VIEW_ON', {'scope': 'SELECTED', 'action': 'RENDER_ONLY'}),
            ],
        )

        vis = layout.box()
        _sf_draw_section_intro(
            vis,
            'Visibility Lanes',
            'Use these like lightweight assembly visibility representations: render-only keeps heavy assets off the viewport, viewport-only keeps guides out of final frames, and disable/show behaves like a safe mute switch.',
            'HIDE_OFF',
        )
        _sf_draw_action_block(
            vis,
            primary_actions=[
                ('import_scene.sfs_representation_apply', 'Linked Render Only', 'RESTRICT_VIEW_ON', {'scope': 'LINKED', 'action': 'RENDER_ONLY'}),
                ('import_scene.sfs_representation_apply', 'Linked Viewport Only', 'RESTRICT_RENDER_OFF', {'scope': 'LINKED', 'action': 'VIEWPORT_ONLY'}),
                ('import_scene.sfs_representation_apply', 'Hide Linked', 'HIDE_ON', {'scope': 'LINKED', 'action': 'DISABLE_BOTH'}),
                ('import_scene.sfs_representation_apply', 'Show Linked', 'HIDE_OFF', {'scope': 'LINKED', 'action': 'ENABLE_BOTH'}),
            ],
            secondary_actions=[
                ('import_scene.sfs_representation_apply', 'Overrides Render Only', 'RESTRICT_VIEW_ON', {'scope': 'OVERRIDES', 'action': 'RENDER_ONLY'}),
                ('import_scene.sfs_representation_apply', 'Overrides Viewport Only', 'RESTRICT_RENDER_OFF', {'scope': 'OVERRIDES', 'action': 'VIEWPORT_ONLY'}),
                ('import_scene.sfs_representation_apply', 'Hide Overrides', 'HIDE_ON', {'scope': 'OVERRIDES', 'action': 'DISABLE_BOTH'}),
                ('import_scene.sfs_representation_apply', 'Show Overrides', 'HIDE_OFF', {'scope': 'OVERRIDES', 'action': 'ENABLE_BOTH'}),
            ],
        )

        restore = layout.box()
        _sf_draw_section_intro(
            restore,
            'Snapshot & Recovery',
            'Store the current state before aggressive preview changes, then restore it later when review or final publish needs the intended full scene again.',
            'RECOVER_LAST',
        )
        _sf_draw_action_block(
            restore,
            primary_actions=[
                ('import_scene.sfs_representation_store_snapshot', 'Store Snapshot', 'FILE_TICK', {'scope': 'LINKED_AND_OVERRIDES'}),
                ('import_scene.sfs_representation_restore_snapshot', 'Restore Snapshot', 'RECOVER_LAST', {}),
                ('import_scene.sfs_pipeline_linked_overview', 'Linked Overview', 'LINKED', {}),
                ('import_scene.sfs_reference_manager_open', 'Relink', 'LINKED', {}),
            ],
        )

        tip = layout.box()
        _sf_draw_section_intro(
            tip,
            'Best Practice',
            'Store a snapshot before switching to proxy or render-only lanes. Restore after layout or troubleshooting so final publish, lookdev review, and renders run with the intended visibility again.',
            'LIGHT',
        )
