# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Bring local history forward without replacing existing snapshots."""

from pathlib import Path
from shutil import copyfileobj, copystat

import bpy


def history_root(create=True):
    directory = Path(bpy.utils.user_resource("CONFIG")).joinpath("Smart_File_Suite", "history")
    if create:
        directory.mkdir(exist_ok=True, parents=True)
    return directory


def _import_snapshot(source, target):
    try:
        target.parent.mkdir(exist_ok=True, parents=True)
        with source.open("rb") as previous, target.open("xb") as snapshot:
            try:
                copyfileobj(previous, snapshot)
                snapshot.flush()
            except OSError:
                snapshot.close()
                target.unlink(missing_ok=True)
                raise
        copystat(source, target)
    except OSError:
        # A transient share error must not prevent access to other snapshots.
        pass


def migrate_legacy():
    current = history_root()
    extensions = bpy.utils.user_resource("EXTENSIONS")
    if not extensions:
        return current
    root = Path(extensions).joinpath("user_default")
    for module in ("smart_file_suite", "Smart_File_Suite"):
        legacy = root.joinpath(module, "history")
        if not legacy.is_dir() or legacy.resolve() == current.resolve():
            continue
        for snapshot in legacy.rglob("*"):
            if snapshot.is_file():
                _import_snapshot(snapshot, current / snapshot.relative_to(legacy))
    return current
