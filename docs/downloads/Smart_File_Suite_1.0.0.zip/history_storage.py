# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) JELararagi
from __future__ import annotations
from pathlib import Path
import os
import shutil
import bpy

def history_root(create=True):
    root=Path(bpy.utils.user_resource("CONFIG"))/"Smart_File_Suite"/"history"
    if create:root.mkdir(parents=True,exist_ok=True)
    return root

def migrate_legacy():
    dst=history_root(True)
    candidates=[]
    ext=Path(bpy.utils.user_resource("EXTENSIONS")) if bpy.utils.user_resource("EXTENSIONS") else None
    if ext:
        candidates += [ext/"user_default"/"smart_file_suite"/"history", ext/"user_default"/"Smart_File_Suite"/"history"]
    for src in candidates:
        if not src.exists() or src.resolve()==dst.resolve():continue
        for p in src.rglob("*"):
            if not p.is_file():continue
            rel=p.relative_to(src);target=dst/rel;target.parent.mkdir(parents=True,exist_ok=True)
            if not target.exists():
                try:shutil.copy2(p,target)
                except OSError:pass
    return dst
