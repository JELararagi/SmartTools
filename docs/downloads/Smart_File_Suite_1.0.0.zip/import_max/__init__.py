# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""The MAX reader interface used by Smart File's native import operator."""

from . import import_max as _reader

__all__ = ("load", "is_maxfile", "ImportMaxFile")
load = _reader.load
is_maxfile = _reader.is_maxfile
ImportMaxFile = _reader.ImportMaxFile
