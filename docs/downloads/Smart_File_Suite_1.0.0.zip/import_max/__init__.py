# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Internal Autodesk MAX importer backend for Smart File.

This package only exposes the transplanted MAX parser/runtime.
UI registration lives in ``sf_import_max_native.py`` so the importer behaves as
one native Smart File function rather than as a separately discovered bundled
add-on.
"""

from __future__ import annotations

from .import_max import load, is_maxfile, ImportMaxFile

__all__ = ["load", "is_maxfile", "ImportMaxFile"]
