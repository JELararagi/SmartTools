# Third-party notices / 第三者のソフトウェアの表示

This add-on is licensed under GPL-3.0-or-later. Parts of it are derived from the software listed below; their copyright holders and licenses are kept here.
このアドオンは GPL-3.0-or-later です。一部は次のソフトウェアに由来します。元の著作権者とライセンスをここに残します。

## blender org (vrm)
- Origin / 出どころ: extensions.blender.org: vrm — https://vrm-addon-for-blender.info
- Copyright / 著作権者: Isamu Mogi <dyob@lunaport.net>
- License / ライセンス: MIT
- Derived files in this add-on / 由来の部品:
  - decentraland_tools/operators/enable_backface_culling.py
  - decentraland_tools/operators/remove_specular.py

## bl_pkg
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/bl_pkg)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - universal_multi_importer/bversion/addon_version.py
  - universal_multi_importer/bversion/version.py

## cycles
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/cycles)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - universal_multi_importer/preferences/formats/properties/__init__.py

## io_anim_bvh
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/io_anim_bvh)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - stl_legacy/__init__.py
  - universal_multi_importer/preferences/formats/panels/panel_bvh.py

## io_scene_fbx
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/io_scene_fbx)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - autodesk_3ds/__init__.py
  - sf_import_max_native.py
  - universal_multi_importer/preferences/formats/panels/panel_fbx.py

## io_scene_gltf2
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/io_scene_gltf2)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - universal_multi_importer/logger/logger_base/logger_base.py

## node_wrangler
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/node_wrangler)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - bulk_asset_tools/tag_add.py
  - universal_multi_importer/__init__.py

## rigify
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/rigify)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - dxf_import/dxfgrabber/color.py

## viewport_vr_preview
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/viewport_vr_preview)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - universal_multi_importer/bversion/blender_version.py

## bl_operators
- Origin / 出どころ: Blender 5.1 bundled startup scripts (scripts/startup/bl_operators)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - bulk_asset_tools/base_operator_class.py
  - decentraland_tools/operators/emote_utils.py
  - decentraland_tools/operators/remove_empty_objects.py
  - dxf_export/__init__.py
  - dxf_export/model/model.py
  - universal_multi_importer/operators/ui/op_ul_file_selection.py
  - universal_multi_importer/preferences/colors/presets/color_preset.py

## bl_ui
- Origin / 出どころ: Blender 5.1 bundled startup scripts (scripts/startup/bl_ui)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - object_reporter/panels.py
  - universal_multi_importer/preferences/formats/panels/panel_abc.py
  - universal_multi_importer/preferences/formats/panels/panel_dae.py
  - universal_multi_importer/preferences/formats/panels/panel_max.py
  - universal_multi_importer/preferences/formats/panels/panel_max3ds.py
  - universal_multi_importer/preferences/formats/panels/panel_pes.py
  - universal_multi_importer/preferences/formats/panels/panel_ply.py
  - universal_multi_importer/preferences/formats/panels/panel_skp.py
  - universal_multi_importer/preferences/formats/panels/panel_stl.py
  - universal_multi_importer/preferences/formats/panels/panel_vdb.py
  - universal_multi_importer/preferences/formats/panels/panel_xyz.py
  - universal_multi_importer/preferences/operators/log_file.py

## screencast (src)
- Origin / 出どころ: screencast (public upstream source) — https://github.com/nutti/Screencast-Keys
- Copyright / 著作権者: nutti, Paulo Gomes, Bart Crouch, John E. Herrenyo
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - universal_multi_importer/preferences/__init__.py

## storytools (storytools_3_3_2_evidence)
- Origin / 出どころ: storytools (public upstream source) — https://github.com/Pullusb/storytools
- Copyright / 著作権者: Samuel Bernou <bernou.samuel@gmail.com>
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - decentraland_tools/operators/resize_textures.py

## STL format (legacy) / io_mesh_stl (stl_legacy)
- Origin / 出どころ: https://projects.blender.org/blender/blender-addons (io_mesh_stl/)
- Copyright / 著作権者: Guillaume Bouchard; Blender Foundation
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - stl_legacy/blender_utils.py

## Universal Multi Importer (universal_multi_importer)
- Origin / 出どころ: https://github.com/Tilapiatsu/blender-Universal_Multi_Importer
- Copyright / 著作権者: Tilapiatsu
- License / ライセンス: GPL-3.0-only
- Derived files in this add-on / 由来の部品:
  - universal_multi_importer/import_module/import_reference.py
  - universal_multi_importer/logger/logger.py
  - universal_multi_importer/ui/panel.py
