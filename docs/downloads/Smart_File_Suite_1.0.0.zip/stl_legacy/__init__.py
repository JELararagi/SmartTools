# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart File STL import and export. No separately installed STL add-on is required."""
import itertools
import os
from pathlib import Path
from shutil import copy2
from tempfile import TemporaryDirectory

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, FloatVectorProperty, StringProperty
from bpy.types import Operator, OperatorFileListElement
from bpy_extras.io_utils import ExportHelper, ImportHelper, axis_conversion, orientation_helper
from mathutils import Matrix
from . import blender_utils, stl_utils

bl_info = {
    "name": "Smart File STL",
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "category": "Import-Export",
    "location": "File > Import / Export",
    "description": "Read or write triangle meshes in binary or ASCII STL",
}


def scene_factor(operator, context):
    units = context.scene.unit_settings
    return units.scale_length if operator.use_scene_unit and units.system != 'NONE' else 1.0


@orientation_helper(axis_forward='Y', axis_up='Z')
class SFS_OT_stl_import(Operator, ImportHelper):
    bl_idname = "import_mesh.sfs_stl_import"
    bl_label = "Import (Legacy)"
    bl_options = {'UNDO', 'PRESET'}
    filename_ext = ".stl"
    filter_glob: StringProperty(default="*.stl", options={'HIDDEN'})
    files: CollectionProperty(name="File Path", type=OperatorFileListElement)
    directory: StringProperty(subtype='DIR_PATH')
    global_scale: FloatProperty(name="Scale", min=0.000001, max=1000000, soft_min=0.001, soft_max=1000, default=1)
    use_scene_unit: BoolProperty(name="Scene Unit", description="Convert file dimensions to scene units")
    use_facet_normal: BoolProperty(name="Facet Normals", description="Keep the normals stored for individual triangles")

    def execute(self, context):
        paths = ([Path(self.directory)/f.name for f in self.files] if self.files
                 else [Path(self.filepath)])
        created = []
        try:
            basis = axis_conversion(from_forward=self.axis_forward, from_up=self.axis_up).to_4x4()
            matrix = basis @ Matrix.Scale(self.global_scale/scene_factor(self,context), 4)
            for path in paths:
                faces,normals,vertices = stl_utils.read_stl(path)
                obj = blender_utils.create_and_link_mesh(bpy.path.display_name_from_filepath(str(path)), faces,
                         normals if self.use_facet_normal else [],vertices,matrix,context=context)
                created.append(obj)
        except (OSError, ValueError, OverflowError, RuntimeError) as error:
            for obj in reversed(created):
                mesh = obj.data
                bpy.data.objects.remove(obj, do_unlink=True)
                bpy.data.meshes.remove(mesh)
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        if context.mode != 'OBJECT' and bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode='OBJECT')
        for obj in context.selected_objects:
            obj.select_set(False)
        for obj in created:
            obj.select_set(True)
        context.view_layer.objects.active = created[-1]
        return {'FINISHED'}

    def draw(self, context):
        pass


def write_batch(targets, matrix, operator, context):
    """Build all outputs first. Restore prior outputs if committing a later file fails."""
    if not targets:
        return
    with TemporaryDirectory(prefix='.smart-file-stl-', dir=targets[0][0].parent) as directory:
        stage = Path(directory)
        pending, committed = [], []
        for index,(target,objects) in enumerate(targets):
            if target.exists() and not target.is_file():
                raise ValueError(f"Expected a file at {target}")
            triangles = itertools.chain.from_iterable(
                blender_utils.faces_from_mesh(obj,matrix,operator.use_mesh_modifiers,context=context)
                for obj in objects)
            payload = stage / f"mesh-{index}"
            stl_utils.write_stl(payload, triangles, operator.ascii)
            backup = None
            if target.is_file():
                backup = stage / f"original-{index}"
                copy2(target, backup)
            pending.append((target,payload,backup))
        try:
            for target,payload,backup in pending:
                os.replace(payload,target)
                committed.append((target,backup))
        except OSError:
            for target,backup in reversed(committed):
                if backup is None:
                    target.unlink(missing_ok=True)
                else:
                    os.replace(backup,target)
            raise


@orientation_helper(axis_forward='Y', axis_up='Z')
class SFS_OT_stl_export(Operator, ExportHelper):
    bl_idname = "export_mesh.sfs_stl_export"
    bl_label = "Export (Legacy)"
    bl_options = {'PRESET'}
    filename_ext = ".stl"
    filter_glob: StringProperty(default="*.stl", options={'HIDDEN'})
    use_selection: BoolProperty(name="Selection Only")
    global_scale: FloatProperty(name="Scale",min=0.01,max=1000,default=1)
    use_scene_unit: BoolProperty(name="Scene Unit",description="Apply the scene unit scale to exported dimensions")
    ascii: BoolProperty(name="Ascii",description="Write a human-readable STL")
    use_mesh_modifiers: BoolProperty(name="Apply Modifiers",default=True)
    batch_mode: EnumProperty(name="Batch Mode",items=(('OFF','Off','One STL file'),('OBJECT','Object','Write a file for each object')))
    global_space: FloatVectorProperty(name="Global Space",subtype='MATRIX',size=(4,4))

    @property
    def check_extension(self):
        return self.batch_mode == 'OFF'

    def execute(self, context):
        try:
            basis = axis_conversion(to_forward=self.axis_forward,to_up=self.axis_up).to_4x4()
            matrix = basis @ Matrix.Scale(self.global_scale*scene_factor(self,context),4)
            if self.properties.is_property_set("global_space"):
                matrix = matrix @ self.global_space.inverted()
            path = Path(self.filepath)
            objects = list(context.selected_objects if self.use_selection else context.scene.objects)
            if self.batch_mode == 'OBJECT':
                prefix = path.with_suffix('').name
                targets = [(path.with_name(prefix+bpy.path.clean_name(obj.name)+'.stl'),[obj]) for obj in objects]
                if len({os.path.normcase(str(target)) for target,_ in targets}) != len(targets):
                    raise ValueError("Multiple objects resolve to the same STL filename")
                write_batch(targets,matrix,self,context)
            else:
                triangles = itertools.chain.from_iterable(
                    blender_utils.faces_from_mesh(obj,matrix,self.use_mesh_modifiers,context=context)
                    for obj in objects)
                stl_utils.write_stl(path,triangles,self.ascii)
        except (OSError, ValueError, OverflowError, RuntimeError) as error:
            self.report({'ERROR'},str(error))
            return {'CANCELLED'}
        return {'FINISHED'}

    def draw(self, context):
        pass


class _Settings:
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOL_PROPS'
    bl_parent_id = 'FILE_PT_operator'

    @classmethod
    def poll(cls,context):
        return getattr(getattr(context.space_data,'active_operator',None),'bl_idname','') == cls.operator_id

    def draw(self,context):
        column = self.layout.column()
        column.use_property_split = True
        for field in self.fields:
            column.prop(context.space_data.active_operator,field)


def panel(name,title,operator,fields):
    return type(name,(_Settings,bpy.types.Panel),{'__module__':__name__,'bl_label':title,
                                                 'operator_id':operator,'fields':fields})


def menu_import(self, context):
    self.layout.operator(SFS_OT_stl_import.bl_idname,text="STL (.stl) — Smart File")


def menu_export(self, context):
    self.layout.operator(SFS_OT_stl_export.bl_idname,text="STL (.stl) — Smart File")


classes = [SFS_OT_stl_import,SFS_OT_stl_export]
for suffix,label,fields in (
    ('import_transform','STL Import Transform',('global_scale','use_scene_unit','axis_forward','axis_up')),
    ('import_geometry','STL Import Geometry',('use_facet_normal',)),
    ('export','STL Export',('ascii','batch_mode')),
    ('export_include','STL Export Include',('use_selection',)),
    ('export_transform','STL Export Transform',('global_scale','use_scene_unit','axis_forward','axis_up')),
    ('export_geometry','STL Export Geometry',('use_mesh_modifiers',)),
):
    operator = 'IMPORT_MESH_OT_sfs_stl_import' if suffix.startswith('import') else 'EXPORT_MESH_OT_sfs_stl_export'
    identifier = 'STL_PT_stl_stl_'+suffix
    cls = panel(identifier,label,operator,fields)
    globals()[identifier] = cls
    classes.append(cls)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_export)


def unregister():
    bpy.types.TOPBAR_MT_file_export.remove(menu_export)
    bpy.types.TOPBAR_MT_file_import.remove(menu_import)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
