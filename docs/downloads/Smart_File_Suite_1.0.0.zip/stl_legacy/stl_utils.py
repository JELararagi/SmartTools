"""Triangle mesh interchange in the ASCII and little-endian binary STL formats.

SPDX-License-Identifier: GPL-3.0-or-later
"""
import math
import os
import struct
from pathlib import Path
from tempfile import NamedTemporaryFile


_COUNT = struct.Struct("<I")
_TRIANGLE = struct.Struct("<12fH")


def _vector(values):
    xyz = tuple(map(float, values))
    if len(xyz) != 3 or not all(map(math.isfinite, xyz)):
        raise ValueError("STL coordinates must contain three finite numbers")
    return xyz


def _ascii_records(stream):
    phase = "solid"
    saw_end = False
    for number, raw in enumerate(stream, 1):
        words = raw.split()
        if not words:
            continue
        tag = words[0].lower()
        if phase == "solid" and tag == b"solid":
            phase = "facet"
        elif phase == "facet" and tag == b"endsolid":
            saw_end = True
            phase = "solid"
        elif phase == "facet" and tag == b"facet" and len(words) == 5 and words[1].lower() == b"normal":
            normal = _vector(words[2:])
            vertices = []
            phase = "outer"
        elif phase == "outer" and [w.lower() for w in words] == [b"outer", b"loop"]:
            phase = "vertex"
        elif phase == "vertex" and tag == b"vertex":
            vertices.append(_vector(words[1:]))
            if len(vertices) == 3:
                phase = "endloop"
        elif phase == "endloop" and len(words) == 1 and tag == b"endloop":
            phase = "endfacet"
        elif phase == "endfacet" and len(words) == 1 and tag == b"endfacet":
            yield normal, vertices
            phase = "facet"
        else:
            raise ValueError(f"Unexpected STL record at line {number} (expected {phase})")
    if phase != "solid" or not saw_end:
        raise ValueError("Incomplete ASCII STL solid")


def _binary_records(stream, count):
    for _ in range(count):
        record = stream.read(_TRIANGLE.size)
        if len(record) != _TRIANGLE.size:
            raise ValueError("Incomplete binary STL triangle")
        values = _TRIANGLE.unpack(record)
        yield _vector(values[:3]), [_vector(values[i:i+3]) for i in (3, 6, 9)]


def read_stl(filepath):
    ids, triangles, normals = {}, [], []
    with open(filepath, "rb") as stream:
        length = os.fstat(stream.fileno()).st_size
        header = stream.read(84)
        count = _COUNT.unpack_from(header, 80)[0] if len(header) == 84 else 0
        if len(header) == 84 and length == 84 + count * _TRIANGLE.size:
            records = _binary_records(stream, count)
        elif header.lstrip().lower().startswith(b"solid"):
            stream.seek(0)
            records = _ascii_records(stream)
        else:
            raise ValueError("Unrecognized or incomplete STL file")
        for normal, vertices in records:
            triangles.append(tuple(ids.setdefault(v, len(ids)) for v in vertices))
            normals.append(normal)
    return triangles, normals, list(ids)


def _unit_normal(a, b, c):
    u = [y-x for x, y in zip(a, b)]
    v = [y-x for x, y in zip(a, c)]
    n = tuple(u[(j+1)%3]*v[(j+2)%3] - u[(j+2)%3]*v[(j+1)%3] for j in range(3))
    length = math.hypot(*n)
    return tuple(x/length for x in n) if length else (0., 0., 0.)


def write_stl(filepath="", faces=(), ascii=False):
    dest = Path(filepath)
    # Stream the triangles once. Publish only after the count and footer are final.
    tmp = NamedTemporaryFile(mode="w+b", dir=dest.parent, prefix=".smart-stl-", delete=False)
    try:
        with tmp:
            tmp.write(b"solid SmartTools\n" if ascii else bytes(84))
            count = 0
            for face in faces:
                a, b, c = map(_vector, face)
                normal = _unit_normal(a, b, c)
                if ascii:
                    def coords(xyz):
                        return " ".join(format(x, ".17g") for x in xyz)
                    lines = [f"facet normal {coords(normal)}", "outer loop",
                             *(f"vertex {coords(p)}" for p in (a,b,c)), "endloop", "endfacet"]
                    tmp.write(("\n".join(lines)+"\n").encode("ascii"))
                else:
                    tmp.write(_TRIANGLE.pack(*normal, *a, *b, *c, 0))
                count += 1
            if ascii:
                tmp.write(b"endsolid SmartTools\n")
            else:
                tmp.seek(80)
                tmp.write(_COUNT.pack(count))
        os.replace(tmp.name, dest)
    finally:
        Path(tmp.name).unlink(missing_ok=True)
