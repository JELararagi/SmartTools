# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender mesh conversion for Smart File's triangle interchange."""
import bpy
from mathutils import Vector


def create_and_link_mesh(name, faces, face_nors, points, global_matrix, *, context=None):
    ctx = context or bpy.context
    mesh = bpy.data.meshes.new(name)
    obj = None
    try:
        mesh.from_pydata([global_matrix @ Vector(p) for p in points], [], faces)
        mesh.update()
        if face_nors and mesh.loops:
            transform = global_matrix.to_3x3().inverted().transposed()
            normals = [(transform @ Vector(n)).normalized() for n in face_nors]
            corners = [normals[face.index] for face in mesh.polygons for _ in face.loop_indices]
            mesh.normals_split_custom_set(corners)
        obj = bpy.data.objects.new(name, mesh)
        ctx.collection.objects.link(obj)
        return obj
    except Exception:
        if obj is not None:
            bpy.data.objects.remove(obj, do_unlink=True)
        bpy.data.meshes.remove(mesh)
        raise


def faces_from_mesh(ob, global_matrix, use_mesh_modifiers=False, *, context=None):
    """Yield triangles in export space without changing the scene's mesh."""
    if ob.type not in {'MESH','CURVE','SURFACE','FONT','META'}:
        return
    ctx = context or bpy.context
    if ob.mode == 'EDIT':
        ob.update_from_editmode()
    owner = ob.evaluated_get(ctx.evaluated_depsgraph_get()) if use_mesh_modifiers else ob
    mesh = owner.to_mesh()
    if mesh is None:
        return
    try:
        world = global_matrix @ owner.matrix_world
        reverse = world.to_3x3().determinant() < 0
        mesh.calc_loop_triangles()
        for tri in mesh.loop_triangles:
            indices = tuple(tri.vertices)
            if reverse:
                indices = tuple(reversed(indices))
            yield tuple(tuple(world @ mesh.vertices[i].co) for i in indices)
    finally:
        owner.to_mesh_clear()
