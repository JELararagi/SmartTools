# -----------------------------------------------------------------------------
#  Shot State Toolkit / Named Presets / Shot Book
# -----------------------------------------------------------------------------

import json
import os
import time
from .ui_language_runtime import error_text as _sf_error_text


_SF_SHOT_TEXT_PREFIX = '.SFS_ShotState__'


def _sf_shot_default_name(context):
    scene = getattr(context, 'scene', None)
    scene_name = str(getattr(scene, 'name', '') or '').strip() if scene is not None else ''
    cam_name = str(getattr(getattr(scene, 'camera', None), 'name', '') or '').strip() if scene is not None else ''
    parts = []
    if scene_name:
        parts.append(scene_name)
    if cam_name and cam_name not in parts:
        parts.append(cam_name)
    return '|'.join(parts) if parts else 'Shot State'


def _sf_shot_text_block_name(preset_name):
    safe = _safe_filename(str(preset_name or '').strip()) or 'shot_state'
    return f"{_SF_SHOT_TEXT_PREFIX}{safe}"


def _sf_shot_runtime_item_name(text_name):
    text_name = str(text_name or '')
    if text_name.startswith(_SF_SHOT_TEXT_PREFIX):
        text_name = text_name[len(_SF_SHOT_TEXT_PREFIX):]
    return text_name.replace('_', '').strip() or '(unnamed)'


def _sf_shot_find_text(text_name):
    try:
        return bpy.data.texts.get(str(text_name or ''))
    except Exception:
        return None


def _sf_shot_iter_texts():
    try:
        texts = list(getattr(bpy.data, 'texts', []) or [])
    except Exception:
        texts = []
    texts = [txt for txt in texts if str(getattr(txt, 'name', '') or '').startswith(_SF_SHOT_TEXT_PREFIX)]
    return sorted(texts, key=lambda txt: str(getattr(txt, 'name', '') or '').lower())


def _sf_shot_parse_text_block(text_block):
    name = str(getattr(text_block, 'name', '') or '')
    raw = ''
    try:
        raw = text_block.as_string()
    except Exception:
        raw = ''
    try:
        payload = json.loads(raw or '{}')
        if not isinstance(payload, dict):
            raise ValueError('payload is not a dictionary')
    except Exception:
        return {
            'tool': 'Smart File',
            'kind': 'shot_state_preset',
            'name': _sf_shot_runtime_item_name(name),
            'notes': '',
            'scene_state': {},
            '__text_name__': name,
            '__broken__': True,
        }
    payload['__text_name__'] = name
    return payload


def _sf_shot_summary_from_payload(payload, text_name=''):
    data = dict(payload or {})
    scene_state = {}
    kind = str(data.get('kind', '') or '')
    if kind == 'shot_state_preset':
        scene_state = dict(data.get('scene_state') or {})
    elif kind == 'scene_state_snapshot':
        scene_state = dict(data)
    name = str(data.get('name', '') or '')
    if not name:
        name = _sf_shot_runtime_item_name(text_name or data.get('__text_name__', ''))
    scene_info = dict(scene_state.get('scene') or {})
    markers = list(scene_state.get('markers') or [])
    objects = list(scene_state.get('object_states') or [])
    collections = list(scene_state.get('collection_states') or [])
    broken = bool(data.get('__broken__')) or bool(scene_state == {} and kind not in {'scene_state_snapshot'})
    return {
        'name': name,
        'text_name': str(text_name or data.get('__text_name__', '') or ''),
        'scene_name': str(scene_info.get('name', '') or ''),
        'camera_name': str(scene_info.get('camera', '') or ''),
        'frame_start': int(scene_info.get('frame_start', 0) or 0),
        'frame_end': int(scene_info.get('frame_end', 0) or 0),
        'frame_current': int(scene_info.get('frame_current', 0) or 0),
        'marker_count': len(markers),
        'entry_count': len(objects) + len(collections) + len(markers),
        'updated_at': str(data.get('updated_at', '') or data.get('created_at', '') or ''),
        'notes': str(data.get('notes', '') or ''),
        'status': 'BROKEN' if broken else 'READY',
    }


def _sf_shot_active_item(context):
    wm = getattr(context, 'window_manager', None)
    items = list(getattr(wm, 'sf_shot_presets', []) or []) if wm is not None else []
    if not items:
        return None
    idx = int(getattr(wm, 'sf_shot_preset_active_index', 0) or 0)
    idx = max(0, min(idx, len(items) - 1))
    return items[idx]


def _sf_shot_active_payload(context, text_name=''):
    target_name = str(text_name or '')
    if not target_name:
        item = _sf_shot_active_item(context)
        target_name = str(getattr(item, 'text_name', '') or '') if item is not None else ''
    if not target_name:
        return {}
    text_block = _sf_shot_find_text(target_name)
    if text_block is None:
        return {}
    return _sf_shot_parse_text_block(text_block)


def _sf_shot_refresh_runtime_list(context, activate_text_name=''):
    wm = getattr(context, 'window_manager', None)
    if wm is None:
        return []
    previous_name = str(activate_text_name or '')
    if not previous_name:
        active = _sf_shot_active_item(context)
        previous_name = str(getattr(active, 'text_name', '') or '') if active is not None else ''
    try:
        wm.sf_shot_presets.clear()
    except Exception:
        pass
    rows = []
    active_index = 0
    for text_block in _sf_shot_iter_texts():
        payload = _sf_shot_parse_text_block(text_block)
        row = _sf_shot_summary_from_payload(payload, getattr(text_block, 'name', ''))
        item = wm.sf_shot_presets.add()
        item.name = row['name']
        item.text_name = row['text_name']
        item.scene_name = row['scene_name']
        item.camera_name = row['camera_name']
        item.frame_start = int(row['frame_start'])
        item.frame_end = int(row['frame_end'])
        item.frame_current = int(row['frame_current'])
        item.marker_count = int(row['marker_count'])
        item.entry_count = int(row['entry_count'])
        item.updated_at = row['updated_at']
        item.notes = row['notes']
        item.status = row['status']
        if previous_name and item.text_name == previous_name:
            active_index = len(rows)
        rows.append(row)
    try:
        wm.sf_shot_preset_active_index = max(0, min(active_index, len(rows) - 1)) if rows else 0
    except Exception:
        pass
    return rows


def _sf_shot_unique_text_name(base_name):
    candidate = str(base_name or '') or f'{_SF_SHOT_TEXT_PREFIX}shot_state'
    if _sf_shot_find_text(candidate) is None:
        return candidate
    stem = candidate
    for idx in range(2, 1000):
        trial = f"{stem}_{idx:02d}"
        if _sf_shot_find_text(trial) is None:
            return trial
    return f"{stem}_{int(time.time())}"


def _sf_shot_write_text(text_block, payload):
    raw = json.dumps(payload, ensure_ascii=False, indent=2)
    try:
        text_block.clear()
    except Exception:
        pass
    text_block.write(raw)
    try:
        text_block.use_fake_user = True
    except Exception:
        pass
    try:
        text_block.use_module = False
    except Exception:
        pass


def _sf_shot_upsert_preset(preset_name, scene_state_payload, *, notes='', overwrite=True, preferred_text_name=''):
    preset_name = str(preset_name or '').strip() or _sf_shot_default_name(bpy.context)
    target_name = str(preferred_text_name or '').strip()
    text_block = _sf_shot_find_text(target_name) if target_name else None
    if text_block is None and overwrite:
        direct_name = _sf_shot_text_block_name(preset_name)
        text_block = _sf_shot_find_text(direct_name)
        target_name = direct_name if text_block is not None else target_name
    if text_block is None and overwrite:
        for candidate in _sf_shot_iter_texts():
            payload = _sf_shot_parse_text_block(candidate)
            if str(payload.get('name', '') or '') == preset_name:
                text_block = candidate
                target_name = str(getattr(candidate, 'name', '') or '')
                break
    if text_block is None:
        target_name = _sf_shot_text_block_name(preset_name)
        if not overwrite:
            target_name = _sf_shot_unique_text_name(target_name)
        text_block = bpy.data.texts.new(name=target_name)
    existing = _sf_shot_parse_text_block(text_block)
    created_at = str(existing.get('created_at', '') or _sf_guard_now_text())
    payload = {
        'tool': 'Smart File',
        'kind': 'shot_state_preset',
        'version': _sf_pipe_version_text(),
        'name': preset_name,
        'notes': str(notes or ''),
        'created_at': created_at,
        'updated_at': _sf_guard_now_text(),
        'scene_state': dict(scene_state_payload or {}),
    }
    _sf_shot_write_text(text_block, payload)
    payload['__text_name__'] = str(getattr(text_block, 'name', '') or '')
    return text_block, payload


def _sf_shot_book_lines(title, rows, extra=None):
    lines = [f"Smart File | {title}", '']
    if extra:
        for key, value in extra.items():
            lines.append(f"- {key}: {value}")
        lines.append('')
    for row in rows:
        lines.append(f"- {row.get('name','')} | {row.get('camera_name','')} | {row.get('frame_start',0)}-{row.get('frame_end',0)} | markers={row.get('marker_count',0)} | status={row.get('status','')}")
    if not rows:
        lines.append(f"- {_t('No stored shot-state presets were found')}")
    lines.extend(['', '- Internal shot-state presets are stored as Blender text datablocks so the current file can keep reusable shot memories without extra folders.', '- 内部ショット状態プリセットは Blender のテキストデータブロックとして保存され、追加フォルダーを増やさずに現在ファイルへ再利用可能なショット状態を保持できます。'])
    return lines


class SF_ShotPresetItem(bpy.types.PropertyGroup):
    bl_description = 'Store one reusable shot-state preset row so artists can browse saved cameras, frame ranges, and restore targets before applying them.'

    name: StringProperty(name='Name')
    text_name: StringProperty(name='Text Name', options={'HIDDEN'})
    scene_name: StringProperty(name='Scene')
    camera_name: StringProperty(name='Camera')
    frame_start: IntProperty(name='Frame Start', default=0)
    frame_end: IntProperty(name='Frame End', default=0)
    frame_current: IntProperty(name='Current Frame', default=0)
    marker_count: IntProperty(name='Markers', default=0)
    entry_count: IntProperty(name='Entries', default=0)
    updated_at: StringProperty(name='Updated')
    notes: StringProperty(name='Notes')
    status: StringProperty(name='Status', default='READY')


class SF_UL_shot_state_shot_state_preset_list(bpy.types.UIList):
    bl_label = 'Shot State Preset List'
    bl_idname = 'SF_UL_shot_state_shot_state_preset_list'

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0, flt_flag=0):
        if self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text='', icon='CAMERA_DATA' if str(getattr(item, 'status', 'READY') or '') != 'BROKEN' else 'ERROR')
            return
        row = layout.row(align=True)
        row.label(text=str(getattr(item, 'name', '') or '(unnamed)'), icon='CAMERA_DATA' if str(getattr(item, 'status', 'READY') or '') != 'BROKEN' else 'ERROR', translate=False)
        sub = row.row(align=True)
        if getattr(item, 'camera_name', ''):
            sub.label(text=str(getattr(item, 'camera_name', '') or ''), icon='VIEW_CAMERA', translate=False)
        frames = ''
        try:
            start = int(getattr(item, 'frame_start', 0) or 0)
            end = int(getattr(item, 'frame_end', 0) or 0)
            if start or end:
                frames = f"{start}-{end}"
        except Exception:
            frames = ''
        if frames:
            sub.label(text=frames, icon='PREVIEW_RANGE')


class SF_OT_shot_state_refresh_presets(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_shot_state_refresh_presets'
    bl_label = 'Refresh Presets'
    bl_description = 'Refresh the internal shot-state preset list by rescanning Smart File text datablocks in the current Blender file.'
    bl_options = {'UNDO'}

    def execute(self, context):
        rows = _sf_shot_refresh_runtime_list(context)
        self.report({'INFO'}, f"{_t('Found')}: {len(rows)}")
        return {'FINISHED'}


class SF_OT_shot_state_open(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = 'import_scene.sfs_shot_state_open'
    bl_label = 'Open'
    bl_description = 'Open a compact board for reusable shot-state presets, quick restore, and portable shot books. It builds on the current scene-state snapshot system but organizes multiple named shots in a beginner-friendly way.'
    bl_options = set()

    popup_width: IntProperty(default=720, min=520, max=980, options={'HIDDEN'})

    def invoke(self, context, event):
        _sf_shot_refresh_runtime_list(context)
        try:
            _sf_append_activity(context, _t('Opened Shot State Toolkit'), '', 'CAMERA_DATA')
        except Exception:
            pass
        return context.window_manager.invoke_popup(self, width=self.popup_width)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        scene = getattr(context, 'scene', None)
        wm = getattr(context, 'window_manager', None)
        rows = list(getattr(wm, 'sf_shot_presets', []) or []) if wm is not None else []
        active = _sf_shot_active_item(context)
        marker_count = len(getattr(scene, 'timeline_markers', []) or []) if scene is not None else 0
        camera_name = str(getattr(getattr(scene, 'camera', None), 'name', '') or '') if scene is not None else ''
        _sf_draw_dialog_header(
            layout,
            'Shot State Toolkit',
            'Capture reusable named shot states, restore them safely, and exchange them as one compact JSON book when handoff work spans multiple cameras or layouts.',
            'CAMERA_DATA',
        )

        summary = layout.box()
        _sf_draw_section_intro(summary, 'Current Shot Summary', 'This panel compares the current scene with the stored presets so you can see whether the active shot setup is already captured.', 'NONE')
        _sf_draw_state_line(summary, 'Current Camera', 'READY' if camera_name else 'NOT SET', detail=camera_name or _t('Not set'))
        _sf_draw_state_line(summary, 'Markers in Scene', 'READY' if marker_count else 'NOT SET', detail=str(int(marker_count or 0)))
        _sf_draw_state_line(summary, 'Presets Stored', 'READY' if rows else 'NOT SET', detail=str(len(rows)))
        _sf_draw_state_line(summary, 'Active Preset', 'READY' if active is not None else 'NOT SET', detail=str(getattr(active, 'name', '') or _t('Not set')))

        presets = layout.box()
        _sf_draw_section_intro(presets, 'Stored Presets', 'These presets are stored inside hidden Blender Text datablocks so the current file keeps named shot states without requiring extra sidecar files during daily work.', 'FILE_TEXT')
        presets.template_list('SF_UL_shot_state_shot_state_preset_list', '', wm, 'sf_shot_presets', wm, 'sf_shot_preset_active_index', rows=6)
        row = presets.row(align=True)
        row.operator('import_scene.sfs_shot_state_refresh_presets', text=_t('Refresh Presets'), icon='FILE_REFRESH')
        row.operator('import_scene.sfs_shot_state_save_current_as_preset', text=_t('Save Current as Preset'), icon='FILE_TICK')
        sub = row.row(align=True)
        sub.enabled = active is not None
        sub.operator('import_scene.sfs_shot_state_apply_selected_preset', text=_t('Apply Selected Preset'), icon='IMPORT')
        sub.operator('import_scene.sfs_shot_state_remove_selected_preset', text=_t('Remove Selected Preset'), icon='TRASH')
        row2 = presets.row(align=True)
        row2.operator('export_scene.sfs_shot_state_export_book', text=_t('Export Book'), icon='EXPORT')
        row2.operator('import_scene.sfs_shot_state_import_book', text=_t('Import Book'), icon='IMPORT')
        row2.operator('import_scene.sfs_project_guard_open', text=_t('Open'), icon='LOCKVIEW_ON')
        row2.operator('import_scene.sfs_assembly_guard_open', text=_t('Open'), icon='RESTRICT_SELECT_OFF')
        row2.operator('import_scene.sfs_shot_queue_open', text=_t('Open'), icon='RENDER_STILL')
        row2.operator('export_scene.sfs_pipeline_shot_manifest', text=_t('Shot Manifest'), icon='FILE_TEXT')

        details = layout.box()
        _sf_draw_section_intro(details, 'Shot Presets', 'Use named presets when multiple shots share the same linked asset assembly but need different camera, frame, or visibility states. Applying a preset stores the current scene state first for rollback.', 'CAMERA_STEREO')
        if active is None:
            details.label(text=_t('No stored shot-state presets were found'))
        else:
            _sf_draw_state_line(details, 'Ready Preset' if str(getattr(active, 'status', 'READY') or '') != 'BROKEN' else 'Broken Preset', 'READY' if str(getattr(active, 'status', 'READY') or '') != 'BROKEN' else 'ATTENTION NEEDED', detail=str(getattr(active, 'name', '') or ''))
            _sf_draw_state_line(details, 'Current Camera', 'READY' if getattr(active, 'camera_name', '') else 'NOT SET', detail=str(getattr(active, 'camera_name', '') or _t('Not set')))
            _sf_draw_state_line(details, 'Markers', 'READY' if int(getattr(active, 'marker_count', 0) or 0) else 'NOT SET', detail=str(int(getattr(active, 'marker_count', 0) or 0)))
            _sf_draw_state_line(details, 'Entry Count', 'READY' if int(getattr(active, 'entry_count', 0) or 0) else 'NOT SET', detail=str(int(getattr(active, 'entry_count', 0) or 0)))
            _sf_draw_state_line(details, 'Updated', 'READY' if getattr(active, 'updated_at', '') else 'NOT SET', detail=str(getattr(active, 'updated_at', '') or ''))
            notes = str(getattr(active, 'notes', '') or '').strip()
            if notes:
                note_box = details.box()
                note_box.label(text=_t('Notes'), icon='TEXT')
                for line in notes.splitlines()[:4]:
                    note_box.label(text=line[:140], icon='BLANK1')


class SF_OT_shot_state_save_current_as_preset(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_shot_state_save_current_as_preset'
    bl_label = 'Save Current as Preset'
    bl_description = 'Capture the current camera, preview range, render settings, markers, and visibility state into an internal reusable preset stored in Blender Text data. This is a compact in-file alternative to external shot-state sidecars.'
    bl_options = {'UNDO'}

    preset_name: StringProperty(name='Preset Name', default='')
    notes: StringProperty(name='Notes', default='')
    overwrite: BoolProperty(name='Overwrite', default=True, description='When a preset with the same name already exists, update that preset instead of creating another one.')
    include_objects: BoolProperty(name='Include objects', default=True, description='Store object visibility and display state.')
    include_collections: BoolProperty(name='Include collections', default=True, description='Store collection visibility state.')

    def invoke(self, context, event):
        if not str(self.preset_name or '').strip():
            self.preset_name = _sf_shot_default_name(context)
        return context.window_manager.invoke_props_dialog(self, width=520)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'preset_name')
        layout.prop(self, 'notes')
        layout.prop(self, 'overwrite')
        layout.prop(self, 'include_objects')
        layout.prop(self, 'include_collections')

    def execute(self, context):
        scene_state = _sf_guard_capture_scene_state(context, include_objects=bool(self.include_objects), include_collections=bool(self.include_collections))
        if not scene_state:
            self.report({'ERROR'}, _t('No active scene'))
            return {'CANCELLED'}
        text_block, payload = _sf_shot_upsert_preset(
            self.preset_name,
            scene_state,
            notes=self.notes,
            overwrite=bool(self.overwrite),
        )
        rows = _sf_shot_refresh_runtime_list(context, activate_text_name=str(getattr(text_block, 'name', '') or ''))
        try:
            _sf_append_activity(context, _t('Saved shot preset'), str(self.preset_name or ''), 'FILE_TICK')
        except Exception:
            pass
        self.report({'INFO'}, f"{_t('Saved')}: {len(rows)} | {os.path.basename(str(getattr(text_block, 'name', '') or ''))}")
        return {'FINISHED'}


class SF_OT_shot_state_apply_selected_preset(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_shot_state_apply_selected_preset'
    bl_label = 'Apply Selected Preset'
    bl_description = 'Apply the selected named shot-state preset. The current scene state is stored to Project Guard first so you can roll back if the shot needs to return to the previous layout.'
    bl_options = {'UNDO'}

    text_name: StringProperty(name='Text Name', default='', options={'HIDDEN'})
    apply_markers: BoolProperty(name='Apply markers', default=True, description='Merge markers from the preset into the current scene. Existing markers with the same name are updated.')
    replace_markers: BoolProperty(name='Replace markers', default=False, description='Remove current markers first, then add markers from the preset.')
    store_rollback: BoolProperty(name='Store rollback snapshot', default=True, description='Store the current scene state into Project Guard before the preset is applied.')

    def execute(self, context):
        payload = _sf_shot_active_payload(context, self.text_name)
        if not payload:
            self.report({'WARNING'}, _t('No stored shot-state presets were found'))
            return {'CANCELLED'}
        if bool(payload.get('__broken__')):
            self.report({'ERROR'}, _t('Broken Preset'))
            return {'CANCELLED'}
        scene_state = dict(payload.get('scene_state') or {}) if str(payload.get('kind', '') or '') == 'shot_state_preset' else dict(payload)
        if not scene_state:
            self.report({'ERROR'}, _t('Broken Preset'))
            return {'CANCELLED'}
        if self.store_rollback:
            try:
                _sf_guard_store_scene_state(context)
            except Exception:
                pass
        result = _sf_guard_restore_scene_state_from_payload(
            context,
            scene_state,
            apply_markers=bool(self.apply_markers),
            replace_markers=bool(self.replace_markers),
        )
        try:
            _sf_append_activity(context, _t('Applied shot preset'), str(payload.get('name', '') or ''), 'IMPORT')
        except Exception:
            pass
        self.report(
            {'WARNING'} if (int(result.get('missing', 0) or 0) or int(result.get('failed', 0) or 0)) else {'INFO'},
            f"{_t('Restored')}: {int(result.get('restored', 0) or 0)} | {_t('Missing')}: {int(result.get('missing', 0) or 0)} | {_t('Failed')}: {int(result.get('failed', 0) or 0)} | {_t('Markers')}: +{int(result.get('markers_added', 0) or 0)}/~{int(result.get('markers_updated', 0) or 0)}",
        )
        return {'FINISHED'}


class SF_OT_shot_state_remove_selected_preset(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_shot_state_remove_selected_preset'
    bl_label = 'Remove Selected Preset'
    bl_description = 'Remove the selected internal shot-state preset text datablock from the current Blender file.'
    bl_options = {'UNDO'}

    text_name: StringProperty(name='Text Name', default='', options={'HIDDEN'})

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        payload = _sf_shot_active_payload(context, self.text_name)
        text_name = str(self.text_name or payload.get('__text_name__', '') or '')
        text_block = _sf_shot_find_text(text_name)
        if text_block is None:
            self.report({'WARNING'}, _t('No stored shot-state presets were found'))
            return {'CANCELLED'}
        preset_name = str(payload.get('name', '') or getattr(text_block, 'name', '') or '')
        try:
            bpy.data.texts.remove(text_block)
        except Exception as ex:
            self.report({'ERROR'}, _sf_error_text(ex))
            return {'CANCELLED'}
        _sf_shot_refresh_runtime_list(context)
        try:
            _sf_append_activity(context, _t('Removed shot preset'), preset_name, 'TRASH')
        except Exception:
            pass
        self.report({'INFO'}, f"{_t('Removed')}: {preset_name}")
        return {'FINISHED'}


class SF_OT_shot_state_export_book(bpy.types.Operator, ExportHelper):
    bl_idname = 'export_scene.sfs_shot_state_export_book'
    bl_label = 'Export Book'
    bl_description = 'Export every internal shot-state preset into one portable JSON shot book. This is useful for handoff, backup, or rebuilding presets in another file.'
    bl_options = set()
    _sms_no_undo = True

    filename_ext = '.sf_shot_book.json'
    filter_glob: StringProperty(default='*.sf_shot_book.json;*.json', options={'HIDDEN'})
    open_report: BoolProperty(name='Open report', default=True, description='Open a compact report inside Blender after export.')
    open_folder: BoolProperty(name='Open folder', default=False, description='Open the destination folder after export.')

    def invoke(self, context, event):
        base_dir = _sf_ref_rel_base_dir() or _sf_user_default_dir('handoff')
        scene_name = _sf_pipe_safe_name(_sf_shot_default_name(context), 'shot_book')
        if not self.filepath:
            self.filepath = os.path.join(base_dir, f'{scene_name}.sf_shot_book.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'open_report')
        layout.prop(self, 'open_folder')

    def execute(self, context):
        filepath = _norm_path(self.filepath or '')
        if not filepath:
            self.report({'ERROR'}, _t('No export path'))
            return {'CANCELLED'}
        if not filepath.lower().endswith('.sf_shot_book.json'):
            filepath += '.sf_shot_book.json'
        entries = []
        rows = []
        for text_block in _sf_shot_iter_texts():
            payload = _sf_shot_parse_text_block(text_block)
            if bool(payload.get('__broken__')):
                continue
            entries.append({k: v for k, v in payload.items() if not str(k).startswith('__')})
            rows.append(_sf_shot_summary_from_payload(payload, getattr(text_block, 'name', '')))
        book = {
            'tool': 'Smart File',
            'kind': 'shot_state_book',
            'version': _sf_pipe_version_text(),
            'created_at': _sf_guard_now_text(),
            'file': _sf_guard_current_file_path(),
            'entries': entries,
        }
        _sf_guard_write_json(filepath, book)
        if self.open_report:
            _sf_report_export(
                context,
                'Shot Book',
                _sf_shot_book_lines('Shot Book', rows, {'File': filepath, 'Entries': len(entries)}),
                open_text=True,
                activity_title=_t('Exported Shot Book'),
            )
        else:
            try:
                _sf_append_activity(context, _t('Exported Shot Book'), os.path.basename(filepath), 'EXPORT')
            except Exception:
                pass
        if self.open_folder:
            try:
                bpy.ops.wm.path_open(filepath=os.path.dirname(filepath) or filepath)
            except Exception:
                pass
        self.report({'INFO'}, f"{_t('Export')}: {os.path.basename(filepath)}")
        return {'FINISHED'}


class SF_OT_shot_state_import_book(bpy.types.Operator, ImportHelper):
    bl_idname = 'import_scene.sfs_shot_state_import_book'
    bl_label = 'Import Book'
    bl_description = 'Import a portable JSON shot book and rebuild the internal shot-state presets inside the current Blender file. Scene-state snapshot JSON files can also be imported directly as a single preset.'
    bl_options = {'UNDO'}

    filter_glob: StringProperty(default='*.sf_shot_book.json;*.sf_scene_state.json;*.json', options={'HIDDEN'})
    replace_existing: BoolProperty(name='Replace existing', default=True, description='Overwrite presets with the same name when they already exist.')
    open_report: BoolProperty(name='Open report', default=True, description='Open a compact report after import.')

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'replace_existing')
        layout.prop(self, 'open_report')

    def execute(self, context):
        filepath = _norm_path(self.filepath or '')
        if not filepath or not os.path.isfile(filepath):
            self.report({'ERROR'}, _t('Invalid file'))
            return {'CANCELLED'}
        payload = _sf_guard_read_json(filepath)
        kind = str(payload.get('kind', '') or '')
        entries = []
        if kind == 'shot_state_book':
            entries = list(payload.get('entries') or [])
        elif kind == 'shot_state_preset':
            entries = [payload]
        elif kind == 'scene_state_snapshot':
            entries = [{
                'tool': 'Smart File',
                'kind': 'shot_state_preset',
                'version': _sf_pipe_version_text(),
                'name': str(dict(payload.get('scene') or {}).get('name', '') or os.path.splitext(os.path.basename(filepath))[0]),
                'notes': '',
                'created_at': _sf_guard_now_text(),
                'updated_at': _sf_guard_now_text(),
                'scene_state': dict(payload),
            }]
        else:
            self.report({'ERROR'}, _t('Invalid file'))
            return {'CANCELLED'}
        imported_rows = []
        imported_count = 0
        for entry in entries:
            entry = dict(entry or {})
            preset_name = str(entry.get('name', '') or '').strip() or os.path.splitext(os.path.basename(filepath))[0]
            scene_state = dict(entry.get('scene_state') or {}) if str(entry.get('kind', '') or '') == 'shot_state_preset' else dict(entry)
            if not scene_state:
                continue
            text_block, preset_payload = _sf_shot_upsert_preset(
                preset_name,
                scene_state,
                notes=str(entry.get('notes', '') or ''),
                overwrite=bool(self.replace_existing),
            )
            imported_rows.append(_sf_shot_summary_from_payload(preset_payload, getattr(text_block, 'name', '')))
            imported_count += 1
        _sf_shot_refresh_runtime_list(context, activate_text_name=str(imported_rows[0].get('text_name', '')) if imported_rows else '')
        if self.open_report:
            _sf_report_export(
                context,
                'Shot Book Import',
                _sf_shot_book_lines('Shot Book Import', imported_rows, {'File': filepath, 'Imported': imported_count}),
                open_text=True,
                activity_title=_t('Imported Shot Book'),
            )
        else:
            try:
                _sf_append_activity(context, _t('Imported Shot Book'), os.path.basename(filepath), 'IMPORT')
            except Exception:
                pass
        self.report({'INFO'}, f"{_t('Import')}: {imported_count}")
        return {'FINISHED'}
