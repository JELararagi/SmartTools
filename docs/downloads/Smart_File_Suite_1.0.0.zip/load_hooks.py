# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""The single load_post handler of Smart File Suite.

Parts of the suite that need to run after a file is opened add their function
to ``LOAD_POST_HOOKS`` (a list).  One handler is kept in
``bpy.app.handlers.load_post`` for as long as the list is not empty and is
removed when the list becomes empty.
"""

from __future__ import annotations

import bpy
from bpy.app.handlers import persistent

_DISPATCH_NAME = "_sfs_load_post_dispatch"


@persistent
def _sfs_load_post_dispatch(*args):
    for hook in tuple(LOAD_POST_HOOKS):
        try:
            hook(*args)
        except Exception:
            continue


class _HookList(list):
    """List of hooks that keeps the one load_post handler in step with its content."""

    def _sync(self):
        try:
            handlers = bpy.app.handlers.load_post
        except Exception:
            return
        for fn in [f for f in tuple(handlers) if getattr(f, "__name__", "") == _DISPATCH_NAME and f is not _sfs_load_post_dispatch]:
            try:
                handlers.remove(fn)   # a handler left by an earlier load of this module
            except Exception:
                pass
        present = any(f is _sfs_load_post_dispatch for f in tuple(handlers))
        if len(self) and not present:
            handlers.append(_sfs_load_post_dispatch)
        elif not len(self) and present:
            handlers.remove(_sfs_load_post_dispatch)

    def append(self, item):
        list.append(self, item)
        self._sync()

    def remove(self, item):
        list.remove(self, item)
        self._sync()

    def pop(self, index=-1):
        item = list.pop(self, index)
        self._sync()
        return item


LOAD_POST_HOOKS = _HookList()
