# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
from __future__ import annotations

import ast
import importlib.abc
import importlib.machinery
import importlib.util
import io
import platform
import sys
import tokenize
import traceback
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import bpy
from . import feature_toggle as _feature_toggle
from . import settings as _settings
from .operator_policy import prepare_operator_class as _prepare_operator_class

_i18n_boot = None
from . import registry as registry

_RECORDS: list[dict[str, Any]] = []
_HIDDEN_PANEL_POLLS: dict[type, object] = {}
_MISSING_POLL = object()
_ACTIVE_CAPTURE_STACK: list[object] = []
_CAPTURE_BY_PREFIX: dict[str, object] = {}


_PROP_FACTORY_NAMES = (
    'BoolProperty',
    'BoolVectorProperty',
    'CollectionProperty',
    'EnumProperty',
    'FloatProperty',
    'FloatVectorProperty',
    'IntProperty',
    'IntVectorProperty',
    'PointerProperty',
    'StringProperty',
)


def _tool_module_prefixes(spec: dict[str, Any]) -> tuple[str, ...]:
    prefixes: list[str] = []
    try:
        prefixes.append(_module_name_for_spec(spec))
    except Exception:
        pass
    ordered: list[str] = []
    seen: set[str] = set()
    for value in prefixes:
        value = str(value or '').strip()
        if not value or value in seen:
            continue
        seen.add(value)
        ordered.append(value)
    return tuple(ordered)


def _preprocess_tool_source(source: str) -> str:
    """Load source-i18n support only on the first explicit bundled command."""
    global _i18n_boot
    text = str(source or '')
    if _i18n_boot is None:
        from . import translation_tooltip_support as _loaded_i18n_boot
        _i18n_boot = _loaded_i18n_boot
    try:
        text = _i18n_boot._sf_preprocess_bilingual_token_strings(text)
    except Exception:
        pass
    try:
        text = _i18n_boot._sf_preprocess_feature_source(text)
    except Exception:
        pass
    return text


class _RegistrationRedirectTransformer(ast.NodeTransformer):
    """Redirect package-owned registration calls without touching global bpy APIs."""

    def __init__(self, tree: ast.AST) -> None:
        self.register_names = {'__sfs_loader_register_class__'}
        self.unregister_names = {'__sfs_loader_unregister_class__'}
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module == 'bpy.utils':
                for alias in node.names:
                    if alias.name == 'register_class':
                        self.register_names.add(alias.asname or alias.name)
                    elif alias.name == 'unregister_class':
                        self.unregister_names.add(alias.asname or alias.name)

    @staticmethod
    def _attribute_path(node: ast.AST) -> tuple[str, ...]:
        values: list[str] = []
        current = node
        while isinstance(current, ast.Attribute):
            values.append(current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            values.append(current.id)
        return tuple(reversed(values))

    def visit_ImportFrom(self, node: ast.ImportFrom):
        if node.module != 'bpy.utils':
            return self.generic_visit(node)
        kept = [alias for alias in node.names if alias.name not in {'register_class', 'unregister_class'}]
        if not kept:
            return None
        node.names = kept
        return self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        node = self.generic_visit(node)
        path = self._attribute_path(node.func)
        if path == ('bpy', 'utils', 'register_class'):
            node.func = ast.copy_location(ast.Name('__sfs_loader_register_class__', ast.Load()), node.func)
        elif path == ('bpy', 'utils', 'unregister_class'):
            node.func = ast.copy_location(ast.Name('__sfs_loader_unregister_class__', ast.Load()), node.func)
        elif path == ('bpy', 'app', 'timers', 'register'):
            node.func = ast.copy_location(ast.Name('__sfs_loader_timer_register__', ast.Load()), node.func)
        elif path == ('bpy', 'app', 'timers', 'unregister'):
            node.func = ast.copy_location(ast.Name('__sfs_loader_timer_unregister__', ast.Load()), node.func)
        elif path == ('bpy', 'msgbus', 'subscribe_rna'):
            node.func = ast.copy_location(ast.Name('__sfs_loader_msgbus_subscribe__', ast.Load()), node.func)
        elif path == ('bpy', 'msgbus', 'clear_by_owner'):
            node.func = ast.copy_location(ast.Name('__sfs_loader_msgbus_clear__', ast.Load()), node.func)
        elif len(path) == 5 and path[:3] == ('bpy', 'app', 'handlers') and path[-1] in {'append', 'remove'}:
            # Route the exact known handler list + callback through the feature
            # ledger. No process-global before/after scan is required.
            handler_list = node.func.value
            helper = '__sfs_loader_handler_append__' if path[-1] == 'append' else '__sfs_loader_handler_remove__'
            node.func = ast.copy_location(ast.Name(helper, ast.Load()), node.func)
            node.args.insert(0, handler_list)
        elif (
            isinstance(node.func, ast.Attribute)
            and node.func.attr in {'new', 'remove'}
            and isinstance(node.func.value, ast.Attribute)
            and node.func.value.attr == 'keymap_items'
        ):
            # Track only the exact KeyMapItems collection and returned KMI from
            # this package-owned call; never diff every add-on keymap.
            keymap_items = node.func.value
            helper = '__sfs_loader_keymap_new__' if node.func.attr == 'new' else '__sfs_loader_keymap_remove__'
            node.func = ast.copy_location(ast.Name(helper, ast.Load()), node.func)
            node.args.insert(0, keymap_items)
        elif isinstance(node.func, ast.Attribute) and node.func.attr == 'draw_handler_add':
            owner = node.func.value
            node.func = ast.copy_location(ast.Name('__sfs_loader_draw_handler_add__', ast.Load()), node.func)
            node.args.insert(0, owner)
        elif isinstance(node.func, ast.Attribute) and node.func.attr == 'draw_handler_remove':
            owner = node.func.value
            node.func = ast.copy_location(ast.Name('__sfs_loader_draw_handler_remove__', ast.Load()), node.func)
            node.args.insert(0, owner)
        elif isinstance(node.func, ast.Name) and node.func.id in self.register_names:
            node.func = ast.copy_location(ast.Name('__sfs_loader_register_class__', ast.Load()), node.func)
        elif isinstance(node.func, ast.Name) and node.func.id in self.unregister_names:
            node.func = ast.copy_location(ast.Name('__sfs_loader_unregister_class__', ast.Load()), node.func)
        return node


def _compile_tool_source(source: str, origin: str):
    tree = ast.parse(_preprocess_tool_source(source), filename=str(origin), mode='exec')
    tree = _RegistrationRedirectTransformer(tree).visit(tree)
    ast.fix_missing_locations(tree)
    return compile(tree, str(origin), 'exec', dont_inherit=True)


def _capture_for_module(fullname: str):
    fullname = str(fullname or '')
    for prefix, capture in tuple(_CAPTURE_BY_PREFIX.items()):
        if fullname == prefix or fullname.startswith(prefix + '.'):
            return capture
    return _ACTIVE_CAPTURE_STACK[-1] if _ACTIVE_CAPTURE_STACK else None


def _direct_register_class(cls: type):
    return bpy.utils.register_class(_prepare_operator_class(cls))


def _inject_local_resource_helpers(namespace: dict[str, Any], capture=None) -> None:
    """Install package-local helpers used by the AST transform."""
    namespace['__sfs_loader_register_class__'] = capture.register_class if capture is not None else _direct_register_class
    namespace['__sfs_loader_unregister_class__'] = capture.unregister_class if capture is not None else bpy.utils.unregister_class
    namespace['__sfs_loader_timer_register__'] = _feature_toggle.explicit_timer_register
    namespace['__sfs_loader_timer_unregister__'] = _feature_toggle.explicit_timer_unregister
    namespace['__sfs_loader_msgbus_subscribe__'] = _feature_toggle.explicit_msgbus_subscribe
    namespace['__sfs_loader_msgbus_clear__'] = _feature_toggle.explicit_msgbus_clear
    namespace['__sfs_loader_draw_handler_add__'] = _feature_toggle.explicit_draw_handler_add
    namespace['__sfs_loader_draw_handler_remove__'] = _feature_toggle.explicit_draw_handler_remove
    namespace['__sfs_loader_handler_append__'] = _feature_toggle.explicit_handler_append
    namespace['__sfs_loader_handler_remove__'] = _feature_toggle.explicit_handler_remove
    namespace['__sfs_loader_keymap_new__'] = _feature_toggle.explicit_keymap_new
    namespace['__sfs_loader_keymap_remove__'] = _feature_toggle.explicit_keymap_remove


class _ToolSourcePreprocessLoader(importlib.abc.Loader):
    def __init__(self, fullname: str, origin: str, is_package: bool) -> None:
        self.fullname = str(fullname or '')
        self.origin = str(origin or '')
        self.is_package = bool(is_package)

    def create_module(self, spec):
        return None

    def exec_module(self, module) -> None:
        origin = Path(self.origin)
        with tokenize.open(str(origin)) as handle:
            source = handle.read()
        code = _compile_tool_source(source, str(origin))
        module.__file__ = str(origin)
        module.__loader__ = self
        module.__package__ = self.fullname if self.is_package else self.fullname.rpartition('.')[0]
        if self.is_package:
            module.__path__ = [str(origin.parent)]
        capture = _capture_for_module(self.fullname)
        _inject_local_resource_helpers(module.__dict__, capture)
        exec(code, module.__dict__)


class _ToolSourcePreprocessFinder(importlib.abc.MetaPathFinder):
    def __init__(self, prefixes: tuple[str, ...], package_dir: Path) -> None:
        self.prefixes = tuple(prefixes or ())
        self.package_dir = Path(package_dir).resolve()

    def find_spec(self, fullname, path=None, target=None):
        fullname = str(fullname or '').strip()
        if not fullname or not any(fullname == prefix or fullname.startswith(prefix + '.') for prefix in self.prefixes):
            return None
        try:
            base_spec = importlib.machinery.PathFinder.find_spec(fullname, path)
        except Exception:
            return None
        if base_spec is None:
            return None
        origin = str(getattr(base_spec, 'origin', '') or '').strip()
        if not origin or not origin.endswith('.py'):
            return None
        try:
            origin_path = Path(origin).resolve()
            origin_path.relative_to(self.package_dir)
        except Exception:
            return None
        is_package = bool(getattr(base_spec, 'submodule_search_locations', None) is not None)
        return importlib.util.spec_from_file_location(
            fullname,
            str(origin_path),
            loader=_ToolSourcePreprocessLoader(fullname, str(origin_path), is_package),
            submodule_search_locations=[str(origin_path.parent)] if is_package else None,
        )


@contextmanager
def _preprocessed_tool_imports(spec: dict[str, Any]):
    prefixes = _tool_module_prefixes(spec)
    package_dir = Path(str(spec.get('package_dir') or '')).resolve()
    if not prefixes or not package_dir.exists():
        yield
        return
    finder = _ToolSourcePreprocessFinder(prefixes, package_dir)
    sys.meta_path.insert(0, finder)
    try:
        yield
    finally:
        try:
            sys.meta_path.remove(finder)
        except Exception:
            pass


@contextmanager
def _patched_prop_factories():
    # Property text is normalized in the package-owned source compiler.  Never
    # replace process-global bpy.props factories.
    yield


def _collect_loaded_class_translations(spec: dict[str, Any], module: object | None) -> None:
    classes: list[type] = []
    seen: set[type] = set()
    for mod in _iter_family_modules(spec, module):
        for value in vars(mod).values():
            if not isinstance(value, type) or value in seen:
                continue
            seen.add(value)
            classes.append(value)
    if not classes:
        return
    try:
        _i18n_boot._sf_collect_runtime_class_translations(classes)
    except Exception:
        pass
    try:
        _i18n_boot._sf_flush_pending_translations()
    except Exception:
        pass


def clear_records() -> None:
    _RECORDS.clear()


def get_records() -> list[dict[str, Any]]:
    return list(_RECORDS)


def get_record(alias: str) -> dict[str, Any] | None:
    alias = str(alias or '').strip()
    if not alias:
        return None
    for record in _RECORDS:
        spec = record.get('spec') or {}
        if str(spec.get('alias') or '').strip() == alias:
            return record
    return None


def _enforce_single_smart_file_npanel(context=None) -> None:
    # Canonical roots are owned by multi_editor_panels; the loader never scans
    # or mutates foreign panel classes.
    del context
    return None


def _root_module_prefix() -> str:
    package = str(__package__ or '').strip()
    if package:
        return package
    return 'smart_file_suite'


def _platform_supported(outer_zip: str) -> bool:
    text = str(outer_zip or '').lower()
    system = platform.system().lower()
    machine = platform.machine().lower()
    if 'windows-x64' in text:
        return system == 'windows' and machine in {'amd64', 'x86_64'}
    if 'linux-x64' in text:
        return system == 'linux' and machine in {'amd64', 'x86_64'}
    if 'macos-arm64' in text:
        return system == 'darwin' and machine in {'arm64', 'aarch64'}
    if 'macos-x64' in text:
        return system == 'darwin' and machine in {'amd64', 'x86_64'}
    return True


def _module_name_for_spec(spec: dict[str, Any]) -> str:
    prefix = _root_module_prefix()
    alias = str(spec.get('alias') or 'tool').strip()
    return f'{prefix}.{alias}'


def _spec_import_paths(spec: dict[str, Any]) -> tuple[str, str, Path]:
    package_dir = Path(str(spec.get('package_dir') or ''))
    init_relpath = Path(str(spec.get('init_relpath') or ''))
    init_path = (package_dir / init_relpath).resolve() if package_dir and init_relpath else Path()
    module_name = _module_name_for_spec(spec)
    module_package_dir = init_path.parent if init_path.name == '__init__.py' else package_dir
    return module_name, str(init_path), module_package_dir


class _RegistrationCapture:
    def __init__(self) -> None:
        self.owner_token = object()
        self.generation = uuid.uuid4().hex
        self.captured: list[type] = []
        self.actually_registered: list[type] = []
        self.skipped_sidebar_panels: list[type] = []
        self.records: list[dict[str, Any]] = []
        self._registered_seen: set[type] = set()
        self._captured_seen: set[type] = set()
        self._skipped_seen: set[type] = set()
        self._panel_base = getattr(bpy.types, 'Panel', None)
        self._prefs_base = getattr(bpy.types, 'AddonPreferences', None)

    @staticmethod
    def _class_owned_rna(cls: type) -> bool:
        try:
            rna = vars(cls).get('bl_rna') if isinstance(cls, type) else None
            return bool(rna is not None and str(getattr(rna, 'identifier', '') or '').strip())
        except Exception:
            return False

    def _is_view3d_sidebar_panel(self, cls: type) -> bool:
        try:
            if self._panel_base is None or not isinstance(cls, type) or not issubclass(cls, self._panel_base):
                return False
        except Exception:
            return False
        return (
            str(getattr(cls, 'bl_space_type', '') or '').upper() == 'VIEW_3D'
            and str(getattr(cls, 'bl_region_type', '') or '').upper() == 'UI'
        )

    def _is_addon_preferences(self, cls: type) -> bool:
        try:
            return self._prefs_base is not None and isinstance(cls, type) and issubclass(cls, self._prefs_base)
        except Exception:
            return False

    def _capture(self, cls: type) -> None:
        if cls not in self._captured_seen:
            self._captured_seen.add(cls)
            self.captured.append(cls)

    def _record(self, cls: type, acquired: bool) -> None:
        if any(record.get('class') is cls for record in self.records):
            return
        self.records.append({
            'class': cls,
            'acquired': bool(acquired),
            'rna_identifier': str(getattr(vars(cls).get('bl_rna'), 'identifier', '') or ''),
            'token': self.owner_token,
            'generation': self.generation,
        })

    def register_class(self, cls: type):
        cls = _prepare_operator_class(cls)
        self._capture(cls)
        if self._is_addon_preferences(cls):
            return cls
        if self._is_view3d_sidebar_panel(cls):
            if cls not in self._skipped_seen:
                self._skipped_seen.add(cls)
                self.skipped_sidebar_panels.append(cls)
            return cls
        if self._class_owned_rna(cls):
            self._record(cls, acquired=False)
            return cls
        bpy.utils.register_class(cls)
        if not self._class_owned_rna(cls):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
            raise RuntimeError(f'class-owned RNA validation failed: {getattr(cls, "__name__", cls)!s}')
        if cls not in self._registered_seen:
            self._registered_seen.add(cls)
            self.actually_registered.append(cls)
        self._record(cls, acquired=True)
        return cls

    def unregister_class(self, cls: type):
        if cls in self._skipped_seen:
            return cls
        record = next((item for item in self.records if item.get('class') is cls), None)
        if not isinstance(record, dict) or not bool(record.get('acquired')):
            return cls
        if record.get('token') is not self.owner_token or record.get('generation') != self.generation:
            raise RuntimeError('registration capture owner identity mismatch')
        if not self._class_owned_rna(cls):
            return cls
        bpy.utils.unregister_class(cls)
        if self._class_owned_rna(cls):
            raise RuntimeError(f'class-owned RNA remained after unregister: {getattr(cls, "__name__", cls)!s}')
        record['acquired'] = False
        return cls

    def cleanup(self) -> bool:
        ok = True
        for record in reversed(tuple(self.records)):
            cls = record.get('class')
            if not isinstance(cls, type) or not bool(record.get('acquired')):
                continue
            try:
                self.unregister_class(cls)
            except Exception:
                ok = False
        return ok


@contextmanager
def _patched_bpy_utils(capture: _RegistrationCapture):
    # Package-owned source calls are redirected by AST to this capture.  The
    # global bpy.utils API is never replaced.
    _ACTIVE_CAPTURE_STACK.append(capture)
    try:
        yield
    finally:
        if _ACTIVE_CAPTURE_STACK and _ACTIVE_CAPTURE_STACK[-1] is capture:
            _ACTIVE_CAPTURE_STACK.pop()
        else:
            try:
                _ACTIVE_CAPTURE_STACK.remove(capture)
            except ValueError:
                pass


def _load_module_from_spec(spec: dict[str, Any], capture: _RegistrationCapture):
    module_name, init_path_str, package_dir = _spec_import_paths(spec)
    if not init_path_str:
        raise FileNotFoundError('init_relpath is empty')
    init_path = Path(init_path_str)
    if not init_path.exists():
        raise FileNotFoundError(f'Missing init file: {init_path}')

    sys.modules.pop(module_name, None)
    spec_obj = importlib.util.spec_from_file_location(
        module_name,
        str(init_path),
        submodule_search_locations=[str(package_dir)],
    )
    if spec_obj is None or spec_obj.loader is None:
        raise ImportError(f'Failed to create module spec for {init_path}')

    module = importlib.util.module_from_spec(spec_obj)
    _inject_local_resource_helpers(module.__dict__, capture)
    sys.modules[module_name] = module
    _CAPTURE_BY_PREFIX[module_name] = capture

    try:
        with tokenize.open(str(init_path)) as handle:
            source = handle.read()
        code = _compile_tool_source(source, str(init_path))
        module.__file__ = str(init_path)
        module.__loader__ = spec_obj.loader
        module.__package__ = module_name
        module.__path__ = [str(package_dir)]
        with _preprocessed_tool_imports(spec):
            with _patched_bpy_utils(capture):
                exec(code, module.__dict__)
        return module
    except Exception:
        _CAPTURE_BY_PREFIX.pop(module_name, None)
        sys.modules.pop(module_name, None)
        raise


def _class_category(cls: type) -> str | None:
    panel_base = getattr(bpy.types, 'Panel', None)
    operator_base = getattr(bpy.types, 'Operator', None)
    menu_base = getattr(bpy.types, 'Menu', None)
    prefs_base = getattr(bpy.types, 'AddonPreferences', None)
    property_group_base = getattr(bpy.types, 'PropertyGroup', None)
    ui_list_base = getattr(bpy.types, 'UIList', None)
    file_handler_base = getattr(bpy.types, 'FileHandler', None)

    try:
        if panel_base is not None and isinstance(cls, type) and issubclass(cls, panel_base):
            return 'panel'
    except Exception:
        pass
    try:
        if operator_base is not None and isinstance(cls, type) and issubclass(cls, operator_base):
            return 'operator'
    except Exception:
        pass
    try:
        if menu_base is not None and isinstance(cls, type) and issubclass(cls, menu_base):
            return 'menu'
    except Exception:
        pass
    try:
        if prefs_base is not None and isinstance(cls, type) and issubclass(cls, prefs_base):
            return 'preferences'
    except Exception:
        pass
    try:
        if property_group_base is not None and isinstance(cls, type) and issubclass(cls, property_group_base):
            return 'property_group'
    except Exception:
        pass
    try:
        if ui_list_base is not None and isinstance(cls, type) and issubclass(cls, ui_list_base):
            return 'ui_list'
    except Exception:
        pass
    try:
        if file_handler_base is not None and isinstance(cls, type) and issubclass(cls, file_handler_base):
            return 'file_handler'
    except Exception:
        pass
    return None


def _categorize_classes(classes: list[type]) -> tuple[list[type], list[type], list[type], list[type]]:
    panels: list[type] = []
    operators: list[type] = []
    menus: list[type] = []
    prefs: list[type] = []

    for cls in classes:
        category = _class_category(cls)
        if category == 'panel':
            panels.append(cls)
        elif category == 'operator':
            operators.append(cls)
        elif category == 'menu':
            menus.append(cls)
        elif category == 'preferences':
            prefs.append(cls)

    return panels, operators, menus, prefs


def _module_family_prefixes(spec: dict[str, Any], module: object | None = None) -> tuple[str, ...]:
    values: list[str] = []
    try:
        values.append(_module_name_for_spec(spec))
    except Exception:
        pass
    if module is not None:
        try:
            values.append(str(getattr(module, '__name__', '') or '').strip())
        except Exception:
            pass

    ordered: list[str] = []
    seen: set[str] = set()
    for value in values:
        if not value or value in seen:
            continue
        seen.add(value)
        ordered.append(value)
    return tuple(ordered)


def _iter_family_modules(spec: dict[str, Any], module: object | None = None) -> list[object]:
    prefixes = _module_family_prefixes(spec, module)
    results: list[object] = []
    seen: set[int] = set()
    for key, value in list(sys.modules.items()):
        if value is None:
            continue
        if not any(key == prefix or key.startswith(prefix + '.') for prefix in prefixes):
            continue
        ident = id(value)
        if ident in seen:
            continue
        seen.add(ident)
        results.append(value)
    return results


def _is_runtime_registerable_class(cls: type) -> bool:
    category = _class_category(cls)
    if category is None:
        return False

    if category == 'operator':
        bl_idname = str(getattr(cls, 'bl_idname', '') or '').strip()
        return bool(bl_idname and '.' in bl_idname)

    if category == 'panel':
        bl_space_type = str(getattr(cls, 'bl_space_type', '') or '').strip()
        bl_region_type = str(getattr(cls, 'bl_region_type', '') or '').strip()
        return bool(bl_space_type and bl_region_type)

    if category == 'menu':
        bl_idname = str(getattr(cls, 'bl_idname', '') or '').strip()
        return bool(bl_idname)

    if category == 'preferences':
        return False

    if category in {'property_group', 'ui_list'}:
        return True

    if category == 'file_handler':
        bl_idname = str(getattr(cls, 'bl_idname', '') or '').strip()
        return bool(bl_idname)

    return False


def _class_registration_sort_key(cls: type) -> tuple[int, int, str]:
    category = _class_category(cls) or ''
    priorities = {
        'property_group': 0,
        'ui_list': 1,
        'preferences': 2,
        'operator': 3,
        'menu': 4,
        'panel': 5,
        'file_handler': 6,
    }
    parent_penalty = 1 if category == 'panel' and str(getattr(cls, 'bl_parent_id', '') or '').strip() else 0
    return (priorities.get(category, 99), parent_penalty, str(getattr(cls, '__name__', '') or ''))


def _register_orphan_blender_classes(spec: dict[str, Any], module: object | None, capture: _RegistrationCapture) -> list[type]:
    prefixes = _module_family_prefixes(spec, module)
    candidates: list[type] = []
    seen: set[type] = set(capture.captured)

    for mod in _iter_family_modules(spec, module):
        for value in vars(mod).values():
            if not isinstance(value, type):
                continue
            if value in seen:
                continue
            module_name = str(getattr(value, '__module__', '') or '').strip()
            if not module_name or not any(module_name == prefix or module_name.startswith(prefix + '.') for prefix in prefixes):
                continue
            if not _is_runtime_registerable_class(value):
                continue
            seen.add(value)
            # Do not auto-register legacy panels discovered in bundled submodules.
            # They are captured for Smart File proxy/deferred UI metadata only.
            # This prevents panel-tree mutation from legacy VIEW_3D/UI classes
            # while Blender is drawing the Smart File N-panel.
            if _class_category(value) == 'panel':
                try:
                    if value not in capture._captured_seen:
                        capture._captured_seen.add(value)
                        capture.captured.append(value)
                    if capture._is_view3d_sidebar_panel(value) and value not in capture._skipped_seen:
                        capture._skipped_seen.add(value)
                        capture.skipped_sidebar_panels.append(value)
                except Exception:
                    pass
                continue
            candidates.append(value)

    registered: list[type] = []
    for cls in sorted(candidates, key=_class_registration_sort_key):
        try:
            capture.register_class(cls)
            registered.append(cls)
        except Exception:
            continue
    return registered


def _panel_is_proxy_safe(cls: type) -> bool:
    if _class_category(cls) != 'panel':
        return False
    space = str(getattr(cls, 'bl_space_type', '') or '').upper()
    region = str(getattr(cls, 'bl_region_type', '') or '').upper()
    if space == 'FILE_BROWSER':
        return False
    if region in {'UI', 'WINDOW'}:
        return True
    return False


def _hide_original_panels(panels: list[type]) -> None:
    # VIEW_3D sidebar panels are skipped before registration by the explicit
    # package-local class helper; never mutate Panel.poll.
    del panels


def _restore_panels(panels: list[type]) -> None:
    del panels


def _restore_hidden_panels() -> None:
    _restore_panels(list(_HIDDEN_PANEL_POLLS.keys()))


def _new_record(spec: dict[str, Any]) -> dict[str, Any]:
    load_flag = bool(spec.get('load', True))
    if not load_flag:
        status = 'disabled'
    elif not _platform_supported(str(spec.get('outer_zip') or '')):
        status = 'unsupported_platform'
    else:
        status = 'ready'
    return {
        'spec': spec,
        'status': status,
        'module': None,
        'capture': None,
        'registered_classes': [],
        'proxy_panels': [],
        'deferred_panels': [],
        'panels': [],
        'operators': [],
        'menus': [],
        'preferences': [],
        'auto_registered_classes': [],
        'owned_class_records': [],
        'hidden_panels': [],
        'error': '',
    }


def _purge_module_namespace(record: dict[str, Any]) -> None:
    names: set[str] = set()
    spec = record.get('spec') or {}
    try:
        names.add(_module_name_for_spec(spec))
    except Exception:
        pass

    module = record.get('module')
    module_name = str(getattr(module, '__name__', '') or '').strip()
    if module_name:
        names.add(module_name)

    for base in [name for name in names if name]:
        for key in [item for item in list(sys.modules.keys()) if item == base or item.startswith(base + '.')]:
            try:
                sys.modules.pop(key, None)
            except Exception:
                pass


def _reset_record_runtime(record: dict[str, Any], *, status: str | None = None, error: str | None = None) -> dict[str, Any]:
    record['module'] = None
    record['capture'] = None
    record['registered_classes'] = []
    record['proxy_panels'] = []
    record['deferred_panels'] = []
    record['panels'] = []
    record['operators'] = []
    record['menus'] = []
    record['preferences'] = []
    record['auto_registered_classes'] = []
    record['owned_class_records'] = []
    record['hidden_panels'] = []
    if status is not None:
        record['status'] = status
    if error is not None:
        record['error'] = error
    return record


def _base_status_for_record(record: dict[str, Any]) -> str:
    spec = record.get('spec') or {}
    if not bool(spec.get('load', True)):
        return 'disabled'
    if not _platform_supported(str(spec.get('outer_zip') or '')):
        return 'unsupported_platform'
    return 'ready'


def _load_record(record: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(record, dict):
        return {}
    status = str(record.get('status') or '')
    if status in {'loaded', 'disabled', 'unsupported_platform'}:
        return record

    _unload_record(record, restore_status=False)
    spec = record.get('spec') or {}

    try:
        capture = _RegistrationCapture()
        module = _load_module_from_spec(spec, capture)
        record['module'] = module
        record['capture'] = capture
        _collect_loaded_class_translations(spec, module)

        register_fn = getattr(module, 'register', None)
        _ft_alias = str((spec.get('alias') if isinstance(spec, dict) else '') or globals().get('alias', '') or 'integrated_tool').strip()
        _ft_label = str((spec.get('display_name') if isinstance(spec, dict) else '') or _ft_alias or 'Integrated Tool').strip()
        register_result = None
        with _feature_toggle.capture_runtime(_ft_alias, _ft_label):
            if callable(register_fn):
                with _preprocessed_tool_imports(spec):
                    with _patched_prop_factories():
                        with _patched_bpy_utils(capture):
                            register_result = register_fn()
        if register_result is False:
            detail = str(getattr(module, '_LAST_REGISTER_ERROR', '') or '').strip()
            raise RuntimeError(detail or f'{_ft_label}: register() returned False')
        _collect_loaded_class_translations(spec, module)

        auto_registered = _register_orphan_blender_classes(spec, module, capture)
        _collect_loaded_class_translations(spec, module)

        captured = list(capture.captured)
        panels, operators, menus, prefs = _categorize_classes(captured)
        proxy_panels = [cls for cls in panels if _panel_is_proxy_safe(cls)]
        deferred_panels = [cls for cls in panels if cls not in proxy_panels]

        record['registered_classes'] = captured
        record['proxy_panels'] = proxy_panels
        record['deferred_panels'] = deferred_panels
        record['panels'] = panels
        record['operators'] = operators
        record['menus'] = menus
        record['preferences'] = prefs
        record['auto_registered_classes'] = auto_registered
        record['owned_class_records'] = list(capture.records)
        hidden_panels = [cls for cls in proxy_panels if cls in set(capture.actually_registered)]
        _hide_original_panels(hidden_panels)
        record['hidden_panels'] = hidden_panels

        record['status'] = 'loaded'
        record['error'] = ''
        _enforce_single_smart_file_npanel(getattr(bpy, 'context', None))
        try:
            _settings.apply_all(getattr(bpy, 'context', None))
        except Exception:
            pass
        _sync_record_runtime(record)
        _enforce_single_smart_file_npanel(getattr(bpy, 'context', None))
    except Exception as exc:
        try:
            _unload_record(record, restore_status=False)
        except Exception:
            _restore_panels(list(record.get('hidden_panels') or []))
            _purge_module_namespace(record)
        _reset_record_runtime(record, status='failed', error=str(exc) + '\n' + traceback.format_exc())
    return record


def load_alias(alias: str) -> dict[str, Any] | None:
    record = get_record(alias)
    if record is None:
        return None
    return _load_record(record)


def _unload_record(record: dict[str, Any], *, restore_status: bool = True) -> dict[str, Any]:
    if not isinstance(record, dict):
        return {}
    module = record.get('module')
    capture = record.get('capture')
    if module is not None:
        try:
            unregister_fn = getattr(module, 'unregister', None)
            if callable(unregister_fn):
                if isinstance(capture, _RegistrationCapture):
                    with _patched_bpy_utils(capture):
                        unregister_fn()
                else:
                    unregister_fn()
        except Exception:
            pass

    if isinstance(capture, _RegistrationCapture):
        capture.cleanup()
    _restore_panels(list(record.get('hidden_panels') or []))
    try:
        _CAPTURE_BY_PREFIX.pop(_module_name_for_spec(record.get('spec') or {}), None)
    except Exception:
        pass
    _purge_module_namespace(record)

    status = _base_status_for_record(record) if restore_status else str(record.get('status') or '')
    error = '' if restore_status else str(record.get('error') or '')
    return _reset_record_runtime(record, status=status, error=error)


def unload_alias(alias: str) -> dict[str, Any] | None:
    record = get_record(alias)
    if record is None:
        return None
    if str(record.get('status') or '') != 'loaded':
        return record
    return _unload_record(record, restore_status=True)

def _enabled_always_on_aliases() -> set[str]:
    aliases_to_load: set[str] = set()
    try:
        aliases_to_load.update(str(alias) for alias in _settings.enabled_scene_tool_aliases())
    except Exception:
        pass
    try:
        enabled_aliases = getattr(_feature_toggle, 'enabled_state_aliases', None)
        if callable(enabled_aliases):
            aliases_to_load.update(str(alias) for alias in enabled_aliases())
    except Exception:
        pass
    return {alias for alias in aliases_to_load if str(alias or '').strip()}


def _sync_record_runtime(record: dict[str, Any]) -> None:
    # A restored switch that already holds its saved value fires no update
    # callback; the tool starts its hooks from here, outside the capture.
    sync = getattr(record.get('module'), 'sync_runtime_after_settings', None)
    if callable(sync):
        try:
            sync()
        except Exception:
            pass


def sync_loaded_tool_runtimes() -> None:
    """Match the hooks of every loaded tool to the scene that was just opened."""
    for record in _RECORDS:
        if str(record.get('status') or '') == 'loaded':
            _sync_record_runtime(record)


def sync_enabled_always_on_tools() -> list[dict[str, Any]]:
    """Load only records that have saved runtime hooks enabled.

    Called after Smart_File_Suite/Smart_File_Suite.json is read on startup and file load so
    always-on states are restored without importing every bundled tool.
    """
    loaded: list[dict[str, Any]] = []
    for alias in sorted(_enabled_always_on_aliases()):
        record = get_record(alias)
        if record is None:
            continue
        if str(record.get('status') or '') in {'ready', 'available', 'standby', 'unloaded'}:
            try:
                loaded.append(_load_record(record))
            except Exception:
                pass
    return loaded


def register_all() -> list[dict[str, Any]]:
    # UI failure is reported through feature_toggle.runtime_status(); metadata
    # registration still completes so core settings/autosave remain available.
    _feature_toggle.register_ui()
    # Startup-safe lazy mode: build lightweight metadata records only.  Bundled
    # add-on modules, operators, handlers, timers, draw handlers, and panels are
    # imported/registered only when a user invokes that tool from Smart File.
    clear_records()
    specs = registry.build_specs(force=False)
    for spec in specs:
        _RECORDS.append(_new_record(spec))

    # Command-specific bundled modules remain metadata-only on cold enable.
    # Modules with a saved always-on switch are loaded later by
    # settings.restore_enabled_always_on_tools(), once a real context exists;
    # autosave safety is owned separately and is never deferred by this loader.
    _enforce_single_smart_file_npanel(getattr(bpy, 'context', None))
    return get_records()


def unregister_all() -> None:
    try:
        _feature_toggle.unregister_all()
    except Exception:
        pass
    for record in reversed(_RECORDS):
        try:
            _unload_record(record, restore_status=False)
        except Exception:
            pass
    _restore_hidden_panels()
    try:
        from . import npanel_singleton as _sfs_npanel_singleton
        _sfs_npanel_singleton.restore_hidden()
    except Exception:
        pass
    clear_records()
    registry.clear_cache()
