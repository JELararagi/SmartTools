# SPDX-License-Identifier: GPL-3.0-or-later
"""Catalog and library location helpers for the asset browser."""
import os
from pathlib import Path
import re
import subprocess

import bpy

from .settings import get_bulk_asset_tools_prefs


def header_menu_func(self, context):
    layout = self.layout
    layout.operator_context = "INVOKE_DEFAULT"
    layout.separator()


def tag_callback(self, context):
    entries = context.selected_assets or ()
    names = dict.fromkeys(tag.name for entry in entries for tag in entry.metadata.tags)
    return [(name, name, "", number) for number, name in enumerate(names)]


def item_callback(self, context):
    if context.space_data.params.asset_library_reference == "ALL":
        return [("", "Select a catalog other than 'All'", "", 0)]

    entries = [
        ("", "Catalog", "", 0),
        ("00000000-0000-0000-0000-000000000000", "Unassigned", "", 0),
    ]
    folder = get_catalog_directory(context)
    if not folder:
        return entries
    catalog = Path(folder) / "blender_assets.cats.txt"
    if not catalog.is_file():
        return entries

    for row in catalog.read_text(encoding="utf-8-sig").splitlines():
        if not row.strip() or row.startswith(("#", "VERSION")):
            continue
        identifier, separator, remainder = row.partition(":")
        label, _, _ = remainder.partition(":")
        if separator and identifier and label:
            entries.append((identifier, label, "", len(entries) - 1))
    return entries


def get_catalog_directory(context):
    parameters = context.space_data.params
    reference = parameters.asset_library_reference
    if reference == "LOCAL":
        return os.path.dirname(bpy.data.filepath)
    library = context.preferences.filepaths.asset_libraries.get(reference)
    return bpy.path.abspath(library.path) if library else os.fsdecode(parameters.directory)


_BLEND_FILE = re.compile(r"\.blend(?=[\\/]|$)", re.IGNORECASE)


def get_file_path(relative_path, directory):
    match = _BLEND_FILE.search(relative_path)
    if match is None:
        raise ValueError("The asset location does not contain a .blend file")
    return os.path.join(directory, relative_path[:match.end()])


_TYPES = {
    "MESH": "meshes",
    "NODETREE": "node_groups",
    "GPENCIL": "grease_pencils",
    "GREASEPENCIL": "grease_pencils_v3",
    "HAIR": "hair_curves",
    "POINTCLOUD": "pointclouds",
    "MOVIECLIP": "movieclips",
    "LIGHT_PROBE": "lightprobes",
}


def id_type_to_type_name(id_type):
    return _TYPES.get(id_type, id_type.lower() + "s")


def run_command(path, commands):
    """Run the internal metadata commands on one library file."""
    preferences = get_bulk_asset_tools_prefs()
    executable = [bpy.app.binary_path]
    if preferences.background:
        executable.append("-b")
    script = "\n".join(("import bpy", *commands, "bpy.ops.wm.save_mainfile()", "bpy.ops.wm.quit_blender()"))
    try:
        subprocess.run([*executable, os.fspath(path), "--python-expr", script], check=True)
    except (OSError, subprocess.CalledProcessError) as error:
        print(f"Could not update asset metadata: {error}")
