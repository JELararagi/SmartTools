# SPDX-License-Identifier: GPL-3.0-or-later
from bpy import props
from .base_operator_class import BaseBulkOperator
from ._metadata import apply_change, draw_operation


class ASSET_OT_bulk_assets_change_copyright(BaseBulkOperator):
    bl_idname = 'asset.sfs_bulk_assets_change_copyright'
    bl_label = 'Change Copyright'
    copyright: props.StringProperty(name='New Copyright')

    def main(self, context):
        apply_change(self, context, 'metadata', 'copyright', self.copyright)


def ASSET_MT_copyright_menu_func(self, context):
    draw_operation(self, ASSET_OT_bulk_assets_change_copyright)
