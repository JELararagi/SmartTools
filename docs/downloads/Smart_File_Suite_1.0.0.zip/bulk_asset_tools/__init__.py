# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy
import bpy.types

from .tag_copy import *
from .rename import *
from .tag_add import *
from .tag_remove import *
from .move import *
from .author import *
from .description import *
from .clear import *
from .copyright import *
from .usage_terms_tool import *
from .utilities import header_menu_func
from .settings import *

bl_info = {
    'name': 'Bulk Asset Tools',
    'author': 'JELararagi',
    'location': 'Asset Browser > Context Menu',
    'version': (1, 7, 3),
    'blender': (5, 1, 0),
    'description': 'A set of tools for managing multiple assets at the same time',
    'doc_url': '',
    'category': 'Assets',
}

classes = (
    BulkAssetToolsPreferencesProxy,
    ASSET_OT_bulk_assets_move_asset,
    ASSET_OT_bulk_assets_change_author,
    ASSET_OT_bulk_assets_change_description,
    ASSET_OT_bulk_assets_add_tag,
    ASSET_OT_bulk_assets_copy_tag,
    ASSET_OT_bulk_assets_remove_tag,
    ASSET_OT_bulk_assets_rename,
    ASSET_OT_bulk_assets_clear_marking,
    ASSET_OT_bulk_assets_change_license,
    ASSET_OT_bulk_assets_change_copyright,
)

menus = (
    ASSET_MT_move_menu_func,
    ASSET_MT_author_menu_func,
    ASSET_MT_license_menu_func,
    ASSET_MT_copyright_menu_func,
    ASSET_MT_description_menu_func,
    ASSET_MT_tag_add_menu_func,
    ASSET_MT_tag_copy_menu_func,
    ASSET_MT_tag_remove_menu_func,
    ASSET_MT_rename_menu_func,
    ASSET_MT_clear_menu_func,
)



def _apply_suite_settings_after_pointer_registration(context=None) -> None:
    try:
        from .. import settings as _sfs_settings
        if hasattr(_sfs_settings, 'apply_all'):
            _sfs_settings.apply_all(context or getattr(bpy, 'context', None))
    except Exception:
        pass

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.WindowManager.bulk_asset_tools_preferences_proxy = bpy.props.PointerProperty(type=BulkAssetToolsPreferencesProxy)
    _apply_suite_settings_after_pointer_registration(getattr(bpy, 'context', None))

    bpy.types.ASSETBROWSER_MT_context_menu.append(header_menu_func)
    if hasattr(bpy.types, 'ASSETBROWSER_MT_asset'):
        bpy.types.ASSETBROWSER_MT_asset.append(header_menu_func)
    elif hasattr(bpy.types, 'ASSETBROWSER_MT_edit'):
        bpy.types.ASSETBROWSER_MT_edit.append(header_menu_func)

    for menu in menus:
        if hasattr(bpy.types, 'ASSETBROWSER_MT_asset'):
            bpy.types.ASSETBROWSER_MT_asset.append(menu)
        elif hasattr(bpy.types, 'ASSETBROWSER_MT_edit'):
            bpy.types.ASSETBROWSER_MT_edit.append(menu)
        bpy.types.ASSETBROWSER_MT_context_menu.append(menu)


def unregister():
    bpy.types.ASSETBROWSER_MT_context_menu.remove(header_menu_func)

    if hasattr(bpy.types, 'ASSETBROWSER_MT_asset'):
        bpy.types.ASSETBROWSER_MT_asset.remove(header_menu_func)
    elif hasattr(bpy.types, 'ASSETBROWSER_MT_edit'):
        bpy.types.ASSETBROWSER_MT_edit.remove(header_menu_func)

    for menu in menus:
        if hasattr(bpy.types, 'ASSETBROWSER_MT_asset'):
            bpy.types.ASSETBROWSER_MT_asset.remove(menu)
        elif hasattr(bpy.types, 'ASSETBROWSER_MT_edit'):
            bpy.types.ASSETBROWSER_MT_edit.remove(menu)
        bpy.types.ASSETBROWSER_MT_context_menu.remove(menu)

    if hasattr(bpy.types.WindowManager, 'bulk_asset_tools_preferences_proxy'):
        del bpy.types.WindowManager.bulk_asset_tools_preferences_proxy

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == '__main__':
    register()
