# SPDX-License-Identifier: GPL-3.0-or-later
from bpy import props
from .base_operator_class import BaseBulkOperator
from ._metadata import apply_change, draw_operation
from .utilities import tag_callback


class ASSET_OT_bulk_assets_remove_tag(BaseBulkOperator):
    bl_idname = 'asset.sfs_bulk_assets_remove_tag'
    bl_label = 'Remove Tag'
    tag: props.EnumProperty(name='Tag to Remove', items=tag_callback)

    def main(self, context):
        if self.tag.strip():
            apply_change(self, context, 'delete', self.tag)


def ASSET_MT_tag_remove_menu_func(self, context):
    draw_operation(self, ASSET_OT_bulk_assets_remove_tag)
