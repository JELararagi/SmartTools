# SPDX-License-Identifier: GPL-3.0-or-later
from bpy import props
from .base_operator_class import BaseBulkOperator
from ._metadata import apply_change, draw_operation


class ASSET_OT_bulk_assets_change_license(BaseBulkOperator):
    bl_idname = 'asset.sfs_bulk_assets_change_license'
    bl_label = 'Change License'
    license: props.StringProperty(name='New License')

    def main(self, context):
        apply_change(self, context, 'metadata', 'license', self.license)


def ASSET_MT_license_menu_func(self, context):
    draw_operation(self, ASSET_OT_bulk_assets_change_license)
