# SPDX-License-Identifier: GPL-3.0-or-later
from bpy import props
from .base_operator_class import BaseBulkOperator
from ._metadata import apply_change, draw_operation


class ASSET_OT_bulk_assets_change_description(BaseBulkOperator):
    bl_idname = 'asset.sfs_bulk_assets_change_description'
    bl_label = 'Change Description'
    description: props.StringProperty(name='New Description')

    def main(self, context):
        apply_change(self, context, 'metadata', 'description', self.description)


def ASSET_MT_description_menu_func(self, context):
    draw_operation(self, ASSET_OT_bulk_assets_change_description)
