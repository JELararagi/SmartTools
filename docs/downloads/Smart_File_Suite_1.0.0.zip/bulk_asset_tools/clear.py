# SPDX-License-Identifier: GPL-3.0-or-later
from .base_operator_class import BaseBulkOperator
from ._metadata import apply_change, draw_operation


class ASSET_OT_bulk_assets_clear_marking(BaseBulkOperator):
    bl_idname = 'asset.sfs_bulk_assets_clear_marking'
    bl_label = 'Clear Marking'

    def draw(self, context):
        count = len(context.selected_assets)
        self.layout.label(icon="ERROR", text=f"This will clear {count} assets with NO UNDO. ")
        self.layout.label(text="Press ESC to cancel")

    def main(self, context):
        apply_change(self, context, 'clear')


def ASSET_MT_clear_menu_func(self, context):
    draw_operation(self, ASSET_OT_bulk_assets_clear_marking)
