# SPDX-License-Identifier: GPL-3.0-or-later
"""Asset Browser action for assigning selected assets to a catalog."""
import bpy

from ._metadata import apply_change, draw_operation
from .base_operator_class import BaseBulkOperator
from .utilities import item_callback


class ASSET_OT_bulk_assets_move_asset(BaseBulkOperator):
    """Move the selected assets to the chosen catalog"""

    bl_idname = "asset.sfs_bulk_assets_move_asset"
    bl_label = "Move Asset"

    catalog: bpy.props.EnumProperty(name="Destination Catalog", items=item_callback)

    def main(self, context):
        apply_change(self, context, "metadata", "catalog_id", self.catalog)


def ASSET_MT_move_menu_func(self, context):
    draw_operation(self, ASSET_OT_bulk_assets_move_asset)
