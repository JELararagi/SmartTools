# SPDX-License-Identifier: GPL-3.0-or-later
"""Prepare one metadata edit for the Asset Browser's selected datablocks."""

from .utilities import get_catalog_directory, get_file_path, id_type_to_type_name


def apply_change(owner, context, operation, *values):
    entries = tuple(context.selected_assets or ())
    remote = [entry for entry in entries if entry.local_id is None]
    library = get_catalog_directory(context) if remote else None
    for entry in entries:
        if entry.local_id is not None:
            change(entry.local_id, operation, *values)
            continue

        path = get_file_path(entry.full_path, library)
        collection = id_type_to_type_name(entry.id_type)
        target = f"getattr(bpy.data, {collection!r})[{entry.name!r}]"
        command = expression(target, operation, *values)
        owner.commands.setdefault(path, []).append(command)


def change(target, operation, *values):
    if operation == "rename":
        target.name = renamed(target.name, *values)
    elif operation == "clear":
        target.asset_clear()
    elif operation == "insert":
        target.asset_data.tags.new(values[0], skip_if_exists=True)
    elif operation == "delete":
        tags = target.asset_data.tags
        tag = tags.get(values[0])
        if tag is not None:
            tags.remove(tag)
    else:
        field, content = values
        setattr(target.asset_data, field, content)


def renamed(current, mode, value):
    if mode == "PREFIX":
        return value + current
    if mode == "SUFFIX":
        return current + value
    return value


def expression(target, operation, *values):
    # Target is built only from escaped datastore and ID names, never raw code.
    if operation == "rename":
        mode, value = values
        name_expr = f"{target}.name"
        if mode == "PREFIX":
            value_expr = f"{value!r} + {name_expr}"
        elif mode == "SUFFIX":
            value_expr = f"{name_expr} + {value!r}"
        else:
            value_expr = repr(value)
        return f"{name_expr} = {value_expr}; "
    if operation == "clear":
        return f"{target}.asset_clear(); "
    if operation == "insert":
        return f"{target}.asset_data.tags.new({values[0]!r}, skip_if_exists=True); "
    if operation == "delete":
        tags = f"{target}.asset_data.tags"
        name = repr(values[0])
        return f"{name} in {tags} and {tags}.remove({tags}[{name}]); "
    field, content = values
    return f"setattr({target}.asset_data, {field!r}, {content!r}); "


def draw_operation(menu, operator_type):
    layout = menu.layout
    layout.operator_context = "INVOKE_DEFAULT"
    layout.operator(operator_type.bl_idname, text=operator_type.bl_label)
