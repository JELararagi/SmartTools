# SPDX-License-Identifier: GPL-3.0-or-later
from bpy import props
from .base_operator_class import BaseBulkOperator
from ._metadata import apply_change, draw_operation


class ASSET_OT_bulk_assets_change_author(BaseBulkOperator):
    bl_idname = 'asset.sfs_bulk_assets_change_author'
    bl_label = 'Change Author'
    author: props.StringProperty(name='New Author')

    def main(self, context):
        apply_change(self, context, 'metadata', 'author', self.author)


def ASSET_MT_author_menu_func(self, context):
    draw_operation(self, ASSET_OT_bulk_assets_change_author)
