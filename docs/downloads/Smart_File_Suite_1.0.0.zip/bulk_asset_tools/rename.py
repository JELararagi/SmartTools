# SPDX-License-Identifier: GPL-3.0-or-later
from bpy import props
from .base_operator_class import BaseBulkOperator
from ._metadata import apply_change, draw_operation


class ASSET_OT_bulk_assets_rename(BaseBulkOperator):
    bl_idname = 'asset.sfs_bulk_assets_rename'
    bl_label = 'Rename'
    text: props.StringProperty(name='Text')
    mode: props.EnumProperty(items=(
        ('PREFIX', 'Prefix', 'Add a Prefix', 0),
        ('SUFFIX', 'Suffix', 'Add a Suffix', 1),
        ('RENAME', 'Rename', 'Rename', 2),
    ), default='RENAME')

    def main(self, context):
        apply_change(self, context, 'rename', self.mode, self.text)


def ASSET_MT_rename_menu_func(self, context):
    draw_operation(self, ASSET_OT_bulk_assets_rename)
