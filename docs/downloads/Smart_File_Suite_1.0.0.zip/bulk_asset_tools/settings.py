# SPDX-License-Identifier: GPL-3.0-or-later
"""Preferences shared by the bulk metadata operators."""
from types import SimpleNamespace

import bpy


_DEFAULTS = SimpleNamespace(max_threads=10, background=True, factory_default=True)


def get_bulk_asset_tools_prefs(context=None):
    wm = getattr(context if context is not None else bpy.context, "window_manager", None)
    proxy = getattr(wm, "bulk_asset_tools_preferences_proxy", None)
    return _DEFAULTS if proxy is None else proxy


def get_integrated_preferences_proxy(context=None, pref_cls=None, record=None):
    return get_bulk_asset_tools_prefs(context)


def _fields():
    return {
        "max_threads": bpy.props.IntProperty(
            name="Max Threads", default=10, min=1,
            description="Maximum number of Blender processes editing assets at once",
        ),
        "background": bpy.props.BoolProperty(
            name="Run Background Processes", default=True,
            description="Process each asset file without opening a Blender window",
        ),
        "factory_default": bpy.props.BoolProperty(
            name="Use Factory Startup", default=True,
            description="Leave local startup settings out of child processes",
        ),
    }


class BulkAssetToolsPreferencesProxy(bpy.types.PropertyGroup):
    __annotations__ = _fields()


class SFS_PG_bulk_assets_bulk_assets_preferences(bpy.types.PropertyGroup):
    bl_label = "Bulk Assets Preferences"
    bl_idname = __package__
    __annotations__ = _fields()

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.label(text="Bulk Asset Tools")
        for field in ("max_threads", "background", "factory_default"):
            layout.prop(self, field)
