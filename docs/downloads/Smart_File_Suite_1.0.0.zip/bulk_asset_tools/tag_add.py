# SPDX-License-Identifier: GPL-3.0-or-later
from bpy import props
from .base_operator_class import BaseBulkOperator
from ._metadata import apply_change, draw_operation


class ASSET_OT_bulk_assets_add_tag(BaseBulkOperator):
    bl_idname = 'asset.sfs_bulk_assets_add_tag'
    bl_label = 'Add Tag'
    tag: props.StringProperty(name='Tag to Add')

    def main(self, context):
        if self.tag.strip():
            apply_change(self, context, 'insert', self.tag)


def ASSET_MT_tag_add_menu_func(self, context):
    draw_operation(self, ASSET_OT_bulk_assets_add_tag)
