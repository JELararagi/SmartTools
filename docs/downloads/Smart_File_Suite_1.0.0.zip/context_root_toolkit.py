# -----------------------------------------------------------------------------
#  Context Root Toolkit / Named Root Maps / Handoff Manifest
# -----------------------------------------------------------------------------

import datetime
import json
import os
import re


_SF_CTX_KIND_ITEMS = [
    ('ANY', 'Any', 'Use this root for every supported external file kind.'),
    ('LIBRARY', 'Libraries', 'Prefer this root when resolving linked .blend libraries.'),
    ('IMAGE', 'Images', 'Prefer this root when resolving textures and other image files.'),
    ('CACHEFILE', 'Caches', 'Prefer this root when resolving Alembic, USD, and other cache-style files.'),
    ('VOLUME', 'Volumes', 'Prefer this root when resolving VDB and other volume files.'),
    ('MOVIECLIP', 'Movie Clips', 'Prefer this root when resolving tracked movie clips and video sequences.'),
    ('SOUND', 'Sounds', 'Prefer this root when resolving external audio files.'),
    ('VECTORFONT', 'Fonts', 'Prefer this root when resolving external vector font files.'),
    ('TEXT', 'Texts', 'Prefer this root when resolving external text datablocks.'),
    ('UNKNOWN', 'Other', 'Use this root for unsupported or uncategorized file references.'),
]

_SF_CTX_KIND_TO_EXT_KINDS = {
    'ANY': {'ANY'},
    'LIBRARY': {'LIBRARY'},
    'IMAGE': {'IMAGE'},
    'CACHEFILE': {'CACHEFILE'},
    'VOLUME': {'VOLUME'},
    'MOVIECLIP': {'MOVIECLIP'},
    'SOUND': {'SOUND'},
    'VECTORFONT': {'VECTORFONT'},
    'TEXT': {'TEXT'},
    'UNKNOWN': {'UNKNOWN'},
}


def _sf_ctx_guess_alias(path: str, fallback: str = 'ROOT') -> str:
    base = os.path.basename(_norm_path(path or '')) or str(fallback or 'ROOT')
    alias = re.sub(r'[^A-Za-z0-9]+', '_', str(base or '').strip()).strip('_').upper()
    if not alias:
        alias = str(fallback or 'ROOT').upper()
    if alias[:1].isdigit():
        alias = f"ROOT_{alias}"
    return alias[:32]



def _sf_ctx_unique_alias(prefs, desired: str) -> str:
    desired = _sf_ctx_guess_alias(desired or 'ROOT')
    existing = {str(getattr(item, 'alias', '') or '').strip().upper() for item in list(getattr(prefs, 'context_roots', []) or [])}
    if desired not in existing:
        return desired
    idx = 2
    while True:
        cand = f"{desired}_{idx:02d}"
        if cand not in existing:
            return cand
        idx += 1



def _sf_ctx_kind_matches(root_kind: str, record_kind: str) -> bool:
    root_kind = str(root_kind or 'ANY').upper()
    record_kind = str(record_kind or 'UNKNOWN').upper()
    if record_kind == 'ANY':
        return True
    if root_kind == 'ANY':
        return True
    return record_kind in _SF_CTX_KIND_TO_EXT_KINDS.get(root_kind, {root_kind})



def _sf_ctx_kind_specificity(root_kind: str, want_kind: str = 'ANY') -> int:
    root_kind = str(root_kind or 'ANY').upper()
    want_kind = str(want_kind or 'ANY').upper()
    if want_kind == 'ANY':
        return 1 if root_kind != 'ANY' else 0
    if root_kind == want_kind:
        return 2
    if root_kind == 'ANY':
        return 1
    return 0



def _sf_ctx_root_alias_score(row: dict) -> tuple[int, int, int, int, int]:
    row = dict(row or {})
    alias = str(row.get('alias') or '').strip()
    path = _norm_path(str(row.get('path') or ''))
    auto_alias = _sf_ctx_guess_alias(path or 'ROOT')
    return (
        1 if alias else 0,
        1 if alias and alias != auto_alias else 0,
        1 if str(row.get('source') or '') == 'context' else 0,
        int(row.get('priority', 0) or 0),
        len(alias),
    )



def _sf_ctx_notes_merge(existing_notes: str, incoming_notes: str) -> str:
    parts = []
    seen = set()
    for note in (existing_notes, incoming_notes):
        clean = str(note or '').strip()
        key = clean.lower()
        if not clean or key in seen:
            continue
        seen.add(key)
        parts.append(clean)
    return '|'.join(parts)



def _sf_ctx_env_var_name(value: str) -> str:
    token = str(value or '').strip()
    token = token.strip('%').strip()
    return token.upper()


def _sf_ctx_env_var_value(env_var: str) -> str:
    key = _sf_ctx_env_var_name(env_var)
    if not key:
        return ''
    try:
        value = os.environ.get(key, '')
    except Exception:
        value = ''
    return _norm_path(value) if value else ''


def _sf_ctx_expand_root_path(path: str, env_var: str = '') -> str:
    raw_path = str(path or '').strip()
    env_value = _sf_ctx_env_var_value(env_var)
    if env_value:
        if raw_path and not os.path.isabs(raw_path) and '://' not in raw_path:
            return _norm_path(os.path.join(env_value, raw_path))
        if not raw_path:
            return env_value
    return _norm_path(raw_path)


def _sf_ctx_env_status(path: str, env_var: str = '') -> tuple[str, str]:
    env_key = _sf_ctx_env_var_name(env_var)
    if not env_key:
        return 'DIRECT', _t('Direct path')
    env_value = _sf_ctx_env_var_value(env_key)
    if not env_value:
        return 'MISSING_ENV', f"{_t('Missing environment variable')}: {env_key}"
    resolved = _sf_ctx_expand_root_path(path, env_key)
    if not resolved:
        return 'MISSING_PATH', f"{env_key} -> {_t('Missing path')}"
    if not os.path.isdir(resolved):
        return 'MISSING_PATH', f"{env_key} -> {_t('Missing on disk')}"
    return 'READY', f"{env_key} -> {resolved}"


def _sf_ctx_merge_root_row(existing: dict | None, incoming: dict) -> dict:
    incoming = dict(incoming or {})
    if not existing:
        row = dict(incoming)
        sources = list(row.get('sources') or [])
        source = str(row.get('source') or '').strip()
        if source:
            sources.append(source)
        row['sources'] = sorted({str(item).strip() for item in sources if str(item).strip()})
        if not row.get('alias'):
            row['alias'] = _sf_ctx_guess_alias(str(row.get('path') or 'ROOT'))
        row['notes'] = str(row.get('notes') or '').strip()
        return row

    merged = dict(existing or {})
    incoming_sources = list(incoming.get('sources') or [])
    if incoming.get('source'):
        incoming_sources.append(str(incoming.get('source') or ''))
    existing_sources = list(merged.get('sources') or [])
    if merged.get('source'):
        existing_sources.append(str(merged.get('source') or ''))
    merged_sources = sorted({str(item).strip() for item in (existing_sources + incoming_sources) if str(item).strip()})
    merged['sources'] = merged_sources
    merged['source'] = 'context' if 'context' in merged_sources else (merged_sources[0] if merged_sources else str(incoming.get('source') or merged.get('source') or 'context'))
    if _sf_ctx_root_alias_score(incoming) > _sf_ctx_root_alias_score(merged):
        merged['alias'] = str(incoming.get('alias') or _sf_ctx_guess_alias(str(incoming.get('path') or 'ROOT')))
    merged['enabled'] = bool(merged.get('enabled', True) or incoming.get('enabled', True))
    merged['priority'] = max(int(merged.get('priority', 0) or 0), int(incoming.get('priority', 0) or 0))
    merged['notes'] = _sf_ctx_notes_merge(str(merged.get('notes') or ''), str(incoming.get('notes') or ''))
    return merged



def _sf_ctx_root_rows(context, *, kind_key: str = 'ANY', existing_only: bool = False, include_library_roots: bool = True) -> list[dict]:
    prefs = _addon_prefs(context)
    rows_by_key = {}
    kind_key = str(kind_key or 'ANY').upper()

    def add_row(alias: str, path: str, *, env_var: str = '', kind: str = 'ANY', enabled: bool = True, priority: int = 0, notes: str = '', source: str = 'context'):
        norm = _sf_ctx_expand_root_path(path or '', env_var)
        kind_up = str(kind or 'ANY').upper()
        env_key = _sf_ctx_env_var_name(env_var)
        if not norm:
            return
        if existing_only and (not os.path.isdir(norm)):
            return
        if not _sf_ctx_kind_matches(kind_up, kind_key):
            return
        row = {
            'alias': str(alias or _sf_ctx_guess_alias(norm)),
            'path': norm,
            'raw_path': str(path or ''),
            'env_var': env_key,
            'kind': kind_up,
            'enabled': bool(enabled),
            'priority': int(priority or 0),
            'notes': str(notes or ''),
            'source': str(source or 'context'),
            'env_status': _sf_ctx_env_status(path or '', env_key)[0],
            'env_detail': _sf_ctx_env_status(path or '', env_key)[1],
        }
        key = (norm, kind_up)
        rows_by_key[key] = _sf_ctx_merge_root_row(rows_by_key.get(key), row)

    if prefs:
        for item in list(getattr(prefs, 'context_roots', []) or []):
            if not bool(getattr(item, 'enabled', True)):
                continue
            add_row(
                str(getattr(item, 'alias', '') or ''),
                str(getattr(item, 'path', '') or ''),
                env_var=str(getattr(item, 'env_var', '') or ''),
                kind=str(getattr(item, 'kind', 'ANY') or 'ANY'),
                enabled=bool(getattr(item, 'enabled', True)),
                priority=int(getattr(item, 'priority', 0) or 0),
                notes=str(getattr(item, 'notes', '') or ''),
                source='context',
            )
        if include_library_roots:
            for idx, item in enumerate(list(getattr(prefs, 'library_roots', []) or [])):
                if not bool(getattr(item, 'enabled', True)):
                    continue
                path = str(getattr(item, 'path', '') or '')
                alias = _sf_ctx_guess_alias(path or f'LIBROOT_{idx + 1}', fallback=f'LIBROOT_{idx + 1}')
                add_row(
                    alias,
                    path,
                    env_var='',
                    kind='LIBRARY',
                    enabled=bool(getattr(item, 'enabled', True)),
                    priority=int(getattr(item, 'priority', 0) or 0),
                    notes='Imported from Library Roots',
                    source='library_root',
                )

    rows = list(rows_by_key.values())
    rows.sort(
        key=lambda row: (
            _sf_ctx_kind_specificity(str(row.get('kind') or 'ANY'), kind_key),
            int(row.get('priority', 0) or 0),
            len(str(row.get('path', '') or '')),
            _sf_ctx_root_alias_score(row),
        ),
        reverse=True,
    )
    return rows



def _sf_ctx_tail_parts(path: str) -> list[str]:
    norm = _norm_path(path or '')
    if not norm:
        return []
    parts = [p for p in norm.replace('\\', '/').split('/') if p]
    if parts and re.match(r'^[A-Za-z]:$', parts[0]):
        parts = parts[1:]
    return parts



def _sf_ctx_suffix_variants(path: str, max_parts: int = 6) -> list[str]:
    parts = _sf_ctx_tail_parts(path)
    if not parts:
        return []
    tail = parts[-max_parts:] if max_parts > 0 else parts
    variants = []
    for size in range(len(tail), 0, -1):
        variants.append('/'.join(tail[-size:]))
    dedup = []
    seen = set()
    for suffix in variants:
        if suffix and suffix not in seen:
            seen.add(suffix)
            dedup.append(suffix)
    return dedup



def _sf_ctx_tail_match_count(path_a: str, path_b: str) -> int:
    a = _sf_ctx_tail_parts(path_a)
    b = _sf_ctx_tail_parts(path_b)
    count = 0
    while a and b and a[-1].lower() == b[-1].lower():
        count += 1
        a = a[:-1]
        b = b[:-1]
    return count



def _sf_ctx_tokenize_path(abs_path: str, context, *, kind_key: str = 'UNKNOWN') -> str:
    abs_path = _norm_path(abs_path or '')
    if not abs_path:
        return ''
    best = None
    kind_key = str(kind_key or 'UNKNOWN').upper()
    for row in _sf_ctx_root_rows(context, kind_key=kind_key, existing_only=False, include_library_roots=True):
        root_path = _norm_path(row.get('path') or '')
        if not root_path or not _sf_ref_path_under_root(abs_path, root_path):
            continue
        suffix = _sf_ref_root_suffix(abs_path, root_path)
        score = (
            len(root_path),
            _sf_ctx_kind_specificity(str(row.get('kind') or 'ANY'), kind_key),
            int(row.get('priority', 0) or 0),
            _sf_ctx_root_alias_score(row),
        )
        if best is None or score > best[0]:
            best = (score, row, suffix)
    if best is None:
        return ''
    _score, row, suffix = best
    alias = str(row.get('alias') or _sf_ctx_guess_alias(row.get('path') or 'ROOT'))
    return f"{alias}://{str(suffix or '').replace(os.sep, '/')}" if suffix else f"{alias}://"



def _sf_ctx_record_root_candidates(context, rec: dict, *, extra_roots=None) -> list[dict]:
    rec = dict(rec or {})
    kind_key = str(rec.get('kind_key') or 'UNKNOWN').upper()
    rows = list(_sf_ctx_root_rows(context, kind_key=kind_key, existing_only=True, include_library_roots=True))
    seen = {str(row.get('path') or '') for row in rows}
    for idx, root in enumerate(list(extra_roots or [])):
        norm = _norm_path(root or '')
        if not norm or norm in seen or (not os.path.isdir(norm)):
            continue
        seen.add(norm)
        rows.append({
            'alias': _sf_ctx_guess_alias(norm or f'ROOT_{idx + 1}', fallback=f'ROOT_{idx + 1}'),
            'path': norm,
            'kind': 'ANY',
            'enabled': True,
            'priority': -100,
            'notes': 'Temporary search root',
            'source': 'search_root',
        })
    rows.sort(key=lambda row: (int(row.get('priority', 0) or 0), len(str(row.get('path', '') or ''))), reverse=True)
    return rows



def _sf_ctx_find_best_record_candidate(context, rec: dict, *, extra_roots=None, basename_index=None) -> str:
    rec = dict(rec or {})
    roots = _sf_ctx_record_root_candidates(context, rec, extra_roots=extra_roots)
    source_path = _norm_path(str(rec.get('abs_path') or rec.get('raw_path') or ''))
    suffixes = _sf_ctx_suffix_variants(source_path, max_parts=8)
    found = []
    for row in roots:
        root_path = _norm_path(row.get('path') or '')
        if not root_path:
            continue
        for suffix in suffixes:
            candidate = _norm_path(os.path.join(root_path, *[p for p in str(suffix or '').split('/') if p]))
            candidate = _sf_ext_tokenized_sequence_path(rec, candidate)
            if _sf_ref_candidate_exists(rec, candidate):
                found.append((
                    len([p for p in str(suffix).split('/') if p]),
                    _sf_ctx_kind_specificity(str(row.get('kind') or 'ANY'), str(rec.get('kind_key') or 'UNKNOWN')),
                    int(row.get('priority', 0) or 0),
                    _sf_ctx_tail_match_count(source_path, candidate),
                    -len(candidate),
                    candidate,
                ))
    if found:
        found.sort(reverse=True)
        return str(found[0][-1] or '')

    if basename_index:
        candidates = _sf_ext_sequence_index_candidates(rec, basename_index)
        if candidates:
            def score(path: str):
                path = _norm_path(path)
                root_hit = 0
                prio = -9999
                for row in roots:
                    if _sf_ref_path_under_root(path, row.get('path') or ''):
                        root_hit = 1
                        prio = max(prio, int(row.get('priority', 0) or 0))
                return (
                    _sf_ctx_tail_match_count(source_path, path),
                    root_hit,
                    prio,
                    -len(path),
                )
            return sorted(candidates, key=score, reverse=True)[0]
    return ''



def _sf_ctx_find_best_library_replacement(context, original_path: str, *, index_data=None) -> str:
    original_path = _norm_path(original_path or '')
    if not original_path:
        return ''
    roots = _sf_ctx_root_rows(context, kind_key='LIBRARY', existing_only=True, include_library_roots=True)
    suffixes = _sf_ctx_suffix_variants(original_path, max_parts=8)
    found = []
    for row in roots:
        root_path = _norm_path(row.get('path') or '')
        if not root_path:
            continue
        for suffix in suffixes:
            candidate = _norm_path(os.path.join(root_path, *[p for p in str(suffix or '').split('/') if p]))
            if os.path.isfile(candidate):
                found.append((
                    len([p for p in str(suffix).split('/') if p]),
                    int(row.get('priority', 0) or 0),
                    _sf_ctx_tail_match_count(original_path, candidate),
                    -len(candidate),
                    candidate,
                ))
    if found:
        found.sort(reverse=True)
        return str(found[0][-1] or '')

    files = (index_data.get('files', {}) or {}) if isinstance(index_data, dict) else {}
    want = os.path.basename(original_path)
    candidates = [
        _norm_path(fp)
        for fp in files.keys()
        if os.path.basename(str(fp or '')) == want and os.path.isfile(str(fp or ''))
    ]
    if candidates:
        return sorted(candidates, key=lambda path: (_sf_ctx_tail_match_count(original_path, path), -len(path)), reverse=True)[0]
    return ''



def _sf_ctx_config_payload(context) -> dict:
    prefs = _addon_prefs(context)
    rows = []
    if prefs:
        for item in list(getattr(prefs, 'context_roots', []) or []):
            rows.append({
                'alias': str(getattr(item, 'alias', '') or ''),
                'path': str(getattr(item, 'path', '') or ''),
                'resolved_path': _sf_ctx_expand_root_path(str(getattr(item, 'path', '') or ''), str(getattr(item, 'env_var', '') or '')),
                'env_var': _sf_ctx_env_var_name(str(getattr(item, 'env_var', '') or '')),
                'kind': str(getattr(item, 'kind', 'ANY') or 'ANY'),
                'enabled': bool(getattr(item, 'enabled', True)),
                'priority': int(getattr(item, 'priority', 0) or 0),
                'notes': str(getattr(item, 'notes', '') or ''),
            })
    return {
        'schema': 'smart_file_suite.context_roots.v2',
        'generated_at': datetime.datetime.now().isoformat(timespec='seconds'),
        'blend_file': _norm_path(bpy.data.filepath or ''),
        'context_roots': rows,
    }



def _sf_ctx_manifest_payload(context, *, include_libraries: bool = True, include_texts: bool = True, include_missing: bool = True) -> dict:
    records = _sf_ext_collect_current_file_records(include_libraries=include_libraries, include_texts=include_texts, include_missing=include_missing)
    manifest_rows = []
    for rec in list(records or []):
        abs_path = _norm_path(str(rec.get('abs_path') or ''))
        token_path = _sf_ctx_tokenize_path(abs_path, context, kind_key=str(rec.get('kind_key') or 'UNKNOWN')) if abs_path else ''
        manifest_rows.append({
            'kind_key': str(rec.get('kind_key') or ''),
            'kind': str(rec.get('kind_label') or ''),
            'name': str(rec.get('name') or ''),
            'raw_path': str(rec.get('raw_path') or ''),
            'absolute_path': abs_path,
            'context_path': token_path,
            'path_style': str(rec.get('path_style') or ''),
            'sequence_mode': str(rec.get('sequence_mode') or 'FILE'),
            'packed': bool(rec.get('packed')),
            'exists': bool(rec.get('exists')),
            'search_suffixes': _sf_ctx_suffix_variants(abs_path or str(rec.get('raw_path') or ''), max_parts=5),
        })
    return {
        'schema': 'smart_file_suite.context_manifest.v1',
        'generated_at': datetime.datetime.now().isoformat(timespec='seconds'),
        'blend_file': _norm_path(bpy.data.filepath or ''),
        'context_roots': _sf_ctx_config_payload(context).get('context_roots', []),
        'records': manifest_rows,
    }


def _sf_ctx_manifest_read(filepath: str) -> dict:
    filepath = _norm_path(filepath or '')
    if not filepath or not os.path.isfile(filepath):
        return {}
    try:
        with open(filepath, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


def _sf_ctx_manifest_root_rows(payload: dict) -> list[dict]:
    rows_by_key = {}
    for row in list((payload or {}).get('context_roots', []) or []):
        raw_path = str((row or {}).get('path') or '')
        env_var = _sf_ctx_env_var_name(str((row or {}).get('env_var') or ''))
        path = _sf_ctx_expand_root_path(raw_path, env_var)
        alias = str((row or {}).get('alias') or '').strip()
        kind = str((row or {}).get('kind') or 'ANY').upper()
        if not path or not alias or (not os.path.isdir(path)):
            continue
        entry = {
            'alias': alias,
            'path': path,
            'raw_path': raw_path,
            'env_var': env_var,
            'kind': kind,
            'enabled': bool((row or {}).get('enabled', True)),
            'priority': int((row or {}).get('priority', 0) or 0),
            'notes': str((row or {}).get('notes') or ''),
            'source': 'manifest',
            'env_status': _sf_ctx_env_status(raw_path, env_var)[0],
            'env_detail': _sf_ctx_env_status(raw_path, env_var)[1],
        }
        key = (path, kind)
        rows_by_key[key] = _sf_ctx_merge_root_row(rows_by_key.get(key), entry)
    rows = list(rows_by_key.values())
    rows.sort(
        key=lambda row: (
            1 if str(row.get('kind') or 'ANY').upper() != 'ANY' else 0,
            int(row.get('priority', 0) or 0),
            len(str(row.get('path', '') or '')),
            _sf_ctx_root_alias_score(row),
        ),
        reverse=True,
    )
    return rows


def _sf_ctx_manifest_record_token(rec: dict):
    ref = (rec or {}).get('id_ref')
    if ref is None:
        return None
    try:
        return int(ref.as_pointer())
    except Exception:
        return id(ref)


def _sf_ctx_manifest_match_key(row: dict) -> tuple[str, str, str, str]:
    kind_key = str((row or {}).get('kind_key') or 'UNKNOWN').upper()
    name = str((row or {}).get('name') or '').strip().lower()
    abs_path = _norm_path(str((row or {}).get('absolute_path') or (row or {}).get('abs_path') or ''))
    raw_path = str((row or {}).get('raw_path') or '')
    basename = os.path.basename(abs_path or raw_path).lower()
    sequence_mode = str((row or {}).get('sequence_mode') or 'FILE').upper()
    return kind_key, name, basename, sequence_mode


def _sf_ctx_manifest_find_target(records: list[dict], row: dict, used_tokens: set) -> tuple[dict | None, str]:
    want_raw = str((row or {}).get('raw_path') or '').strip().lower()
    want_abs = _norm_path(str((row or {}).get('absolute_path') or '')).lower()
    want_key = _sf_ctx_manifest_match_key(row)

    exact_raw = []
    exact_abs = []
    key_rows = []
    for rec in list(records or []):
        token = _sf_ctx_manifest_record_token(rec)
        if token is not None and token in used_tokens:
            continue
        rec_raw = str((rec or {}).get('raw_path') or '').strip().lower()
        rec_abs = _norm_path(str((rec or {}).get('abs_path') or '')).lower()
        if want_raw and rec_raw == want_raw:
            exact_raw.append(rec)
            continue
        if want_abs and rec_abs == want_abs:
            exact_abs.append(rec)
            continue
        if _sf_ctx_manifest_match_key(rec) == want_key:
            key_rows.append(rec)

    if len(exact_raw) == 1:
        return exact_raw[0], 'RAW'
    if len(exact_abs) == 1:
        return exact_abs[0], 'ABS'
    if len(key_rows) == 1:
        return key_rows[0], 'KEY'
    if len(exact_raw) > 1 or len(exact_abs) > 1 or len(key_rows) > 1:
        return None, 'AMBIGUOUS'
    return None, 'NO_MATCH'


def _sf_ctx_resolve_context_path(context, token_path: str, *, kind_key: str = 'UNKNOWN', extra_rows=None) -> str:
    token_path = str(token_path or '').strip()
    if '://' not in token_path:
        return ''
    alias, suffix = token_path.split('://', 1)
    alias = str(alias or '').strip().upper()
    suffix = str(suffix or '').strip().replace('\\', '/').strip('/')
    if not alias:
        return ''
    rows = []
    try:
        rows.extend(_sf_ctx_root_rows(context, kind_key=str(kind_key or 'UNKNOWN').upper(), existing_only=True, include_library_roots=True))
    except Exception:
        pass
    for row in list(extra_rows or []):
        rows.append(dict(row or {}))
    rows = [row for row in rows if str(row.get('alias') or '').strip().upper() == alias]
    if not rows:
        return ''
    rows.sort(key=lambda row: (int(row.get('priority', 0) or 0), len(str(row.get('path', '') or ''))), reverse=True)
    for row in rows:
        root_path = _norm_path(row.get('path') or '')
        if not root_path:
            continue
        candidate = _norm_path(os.path.join(root_path, *[p for p in suffix.split('/') if p])) if suffix else root_path
        if suffix:
            if os.path.exists(candidate):
                return candidate
        elif os.path.isdir(candidate):
            return candidate
    return ''


def _sf_ctx_manifest_search_roots(context, payload: dict, *, include_manifest_roots: bool = True) -> list[str]:
    roots = []
    try:
        roots.extend(_sf_ext_find_search_roots(context, '', include_current_file_dir=True, include_library_roots=True, include_context_roots=True))
    except Exception:
        pass
    if include_manifest_roots:
        for row in _sf_ctx_manifest_root_rows(payload):
            path = _norm_path(row.get('path') or '')
            if path:
                roots.append(path)
    dedup = []
    seen = set()
    for root in roots:
        if not root or root in seen or (not os.path.isdir(root)):
            continue
        seen.add(root)
        dedup.append(root)
    return dedup


def _sf_ctx_manifest_resolve_row(context, row: dict, *, payload: dict | None = None, basename_index=None, include_manifest_roots: bool = True) -> tuple[str, str]:
    payload = dict(payload or {})
    row = dict(row or {})
    kind_key = str(row.get('kind_key') or 'UNKNOWN').upper()
    extra_rows = _sf_ctx_manifest_root_rows(payload) if include_manifest_roots else []

    token_path = str(row.get('context_path') or '').strip()
    if token_path:
        candidate = _sf_ctx_resolve_context_path(context, token_path, kind_key=kind_key, extra_rows=extra_rows)
        pseudo = {
            'kind_key': kind_key,
            'raw_path': str(row.get('raw_path') or ''),
            'abs_path': str(row.get('absolute_path') or ''),
            'sequence_mode': str(row.get('sequence_mode') or 'FILE'),
        }
        if candidate and _sf_ref_candidate_exists(pseudo, candidate):
            return candidate, 'TOKEN'

    pseudo = {
        'kind_key': kind_key,
        'raw_path': str(row.get('raw_path') or ''),
        'abs_path': str(row.get('absolute_path') or ''),
        'sequence_mode': str(row.get('sequence_mode') or 'FILE'),
        'search_suffixes': list(row.get('search_suffixes') or []),
    }
    roots = _sf_ctx_manifest_search_roots(context, payload, include_manifest_roots=include_manifest_roots)
    candidate = _sf_ctx_find_best_record_candidate(context, pseudo, extra_roots=roots, basename_index=basename_index)
    if candidate:
        return candidate, 'SEARCH'
    return '', 'NONE'


def _sf_ctx_manifest_preview_summary(context, payload: dict, *, include_manifest_roots: bool = True) -> dict:
    rows = list((payload or {}).get('records', []) or [])
    roots = _sf_ctx_manifest_search_roots(context, payload, include_manifest_roots=include_manifest_roots)
    allowed_suffixes = set()
    for row in rows:
        ext = os.path.splitext(str(row.get('absolute_path') or row.get('raw_path') or ''))[1].lower()
        if ext:
            allowed_suffixes.add(ext)
    basename_index = _sf_ext_build_basename_index(roots, allowed_suffixes=allowed_suffixes) if roots else {}
    preview = []
    resolvable = 0
    token_hits = 0
    search_hits = 0
    for row in rows:
        resolved, mode = _sf_ctx_manifest_resolve_row(context, row, payload=payload, basename_index=basename_index, include_manifest_roots=include_manifest_roots)
        if resolved:
            resolvable += 1
            if mode == 'TOKEN':
                token_hits += 1
            elif mode == 'SEARCH':
                search_hits += 1
        if len(preview) < 10:
            preview.append({
                'kind': str(row.get('kind') or row.get('kind_key') or ''),
                'name': str(row.get('name') or ''),
                'context_path': str(row.get('context_path') or ''),
                'resolved': resolved,
                'mode': mode,
            })
    return {
        'rows': rows,
        'roots': roots,
        'resolvable': int(resolvable),
        'unresolved': max(0, len(rows) - int(resolvable)),
        'token_hits': int(token_hits),
        'search_hits': int(search_hits),
        'preview': preview,
        'manifest_root_rows': _sf_ctx_manifest_root_rows(payload),
    }


class SF_OT_context_roots_add_root(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_context_roots_add_root'
    bl_label = 'Add Root'
    bl_description = 'Register a named root folder that Smart File can use for suffix-aware relink, root migration, and handoff manifests. Context Roots are inspired by project-context systems such as AYON Context, Prism publish roots, watch folders, and XRef root maps.'
    bl_options = {'UNDO'}

    alias: StringProperty(name='Alias', default='', description='Short stable token used in exported manifests such as SHOW_ASSETS or CACHE.')
    path: StringProperty(name='Root Folder', subtype='DIR_PATH', default='', description='Base folder that should act as a named project root. It can be absolute, relative to the current project, or relative to the environment variable below.')
    env_var: StringProperty(name='Environment Variable', default='', description='Optional variable name such as SHOW_ROOT or ASSET_ROOT. When filled, the stored folder can stay portable across workstations.')
    kind: EnumProperty(name='Kind', items=_SF_CTX_KIND_ITEMS, default='ANY', description='Optionally specialize this root so it is preferred for one external-file category.')
    priority: IntProperty(name='Priority', default=0, min=-999, max=999, description='Higher values win when multiple roots can resolve the same suffix.')
    enabled: BoolProperty(name='Enabled', default=True, description='Allow this Context Root to participate in relink and manifest operations.')
    notes: StringProperty(name='Notes', default='', description='Optional note explaining when this root should be used.')

    def invoke(self, context, event):
        if not self.path:
            guess = _norm_path(os.path.dirname(bpy.data.filepath or '')) if bpy.data.filepath else ''
            if not guess:
                try:
                    guess = _norm_path(os.path.dirname(getattr(context.window_manager, 'sf_filepath', '') or ''))
                except Exception:
                    guess = ''
            self.path = guess
        if not self.alias:
            self.alias = _sf_ctx_guess_alias(self.path or 'ROOT')
        return context.window_manager.invoke_props_dialog(self, width=640)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'alias')
        layout.prop(self, 'path')
        layout.prop(self, 'env_var')
        layout.prop(self, 'kind')
        layout.prop(self, 'priority')
        layout.prop(self, 'enabled')
        layout.prop(self, 'notes')

    def execute(self, context):
        prefs = _addon_prefs(context)
        if not prefs:
            return {'CANCELLED'}
        path = _norm_path(self.path or '')
        if not path:
            self.report({'ERROR'}, _t('Root folder is required'))
            return {'CANCELLED'}
        if not os.path.isdir(path):
            self.report({'ERROR'}, _t('Root folder does not exist'))
            return {'CANCELLED'}
        alias = str(self.alias or _sf_ctx_guess_alias(path or 'ROOT')).strip()
        existing = None
        for item in list(getattr(prefs, 'context_roots', []) or []):
            if _norm_path(getattr(item, 'path', '') or '') == path:
                existing = item
                break
        if existing is None:
            item = prefs.context_roots.add()
            item.alias = _sf_ctx_unique_alias(prefs, alias)
        else:
            item = existing
            current_alias = str(getattr(item, 'alias', '') or '')
            item.alias = current_alias or _sf_ctx_unique_alias(prefs, alias)
        item.path = path
        item.env_var = _sf_ctx_env_var_name(self.env_var or '')
        item.kind = str(self.kind or 'ANY')
        item.priority = int(self.priority or 0)
        item.enabled = bool(self.enabled)
        item.notes = str(self.notes or '')
        _sf_append_activity(context, _t('Updated Context Root') if existing else _t('Added Context Root'), path, 'FILE_PARENT')
        self.report({'INFO'}, f"{_t('Saved')}: {path}")
        return {'FINISHED'}


class SF_OT_context_roots_remove_root(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_context_roots_remove_root'
    bl_label = 'Remove Root'
    bl_description = 'Remove one named Context Root from the saved list.'
    bl_options = {'UNDO'}

    index: IntProperty(default=-1, options={'HIDDEN'})

    def execute(self, context):
        prefs = _addon_prefs(context)
        if not prefs:
            return {'CANCELLED'}
        roots = getattr(prefs, 'context_roots', None)
        if roots is None or self.index < 0 or self.index >= len(roots):
            return {'CANCELLED'}
        path = _norm_path(getattr(roots[self.index], 'path', '') or '')
        roots.remove(self.index)
        _sf_append_activity(context, _t('Removed Context Root'), path, 'TRASH')
        self.report({'INFO'}, _t('Removed'))
        return {'FINISHED'}


class SF_OT_context_roots_import_library_roots(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_context_roots_import_library_roots'
    bl_label = 'Import Library Roots'
    bl_description = 'Copy enabled Library Roots into the named Context Root list so root-based relink and handoff manifests can use the same trusted paths.'
    bl_options = {'UNDO'}

    def execute(self, context):
        prefs = _addon_prefs(context)
        if not prefs:
            return {'CANCELLED'}
        created = 0
        existing_paths = {_norm_path(getattr(item, 'path', '') or '') for item in list(getattr(prefs, 'context_roots', []) or [])}
        for idx, root in enumerate(list(getattr(prefs, 'library_roots', []) or [])):
            if not bool(getattr(root, 'enabled', True)):
                continue
            path = _norm_path(getattr(root, 'path', '') or '')
            if not path or not os.path.isdir(path) or path in existing_paths:
                continue
            item = prefs.context_roots.add()
            item.alias = _sf_ctx_unique_alias(prefs, _sf_ctx_guess_alias(path or f'LIBROOT_{idx + 1}', fallback=f'LIBROOT_{idx + 1}'))
            item.path = path
            item.env_var = ''
            item.kind = 'LIBRARY'
            item.enabled = True
            item.priority = int(getattr(root, 'priority', 0) or 0)
            item.notes = 'Imported from Library Roots'
            existing_paths.add(path)
            created += 1
        _sf_append_activity(context, _t('Imported Library Roots into Context Roots'), str(created), 'FILE_PARENT')
        self.report({'INFO'}, f"{_t('Imported')}: {created}")
        return {'FINISHED'}


class SF_OT_context_roots_export_root_config(bpy.types.Operator):
    bl_idname = 'export_scene.sfs_context_roots_export_root_config'
    bl_label = 'Export Root Config'
    bl_description = 'Write the saved Context Root list to JSON so another workstation can reuse the same root aliases and priorities.'
    bl_options = {'UNDO'}

    filepath: StringProperty(name='Filepath', subtype='FILE_PATH', default='')
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        if not self.filepath:
            base_dir = _norm_path(os.path.dirname(bpy.data.filepath or '')) if bpy.data.filepath else _sf_user_default_dir('handoff')
            self.filepath = os.path.join(base_dir, 'smart_file_suite_context_roots.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        filepath = _norm_path(self.filepath or '')
        if not filepath:
            return {'CANCELLED'}
        payload = _sf_ctx_config_payload(context)
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
        _sf_append_activity(context, _t('Exported Context Root Config'), os.path.basename(filepath), 'EXPORT')
        self.report({'INFO'}, f"{_t('Export')}: {os.path.basename(filepath)}")
        return {'FINISHED'}


class SF_OT_context_roots_import_root_config(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_context_roots_import_root_config'
    bl_label = 'Import Root Config'
    bl_description = 'Read Context Roots from JSON and merge or replace the current saved list.'
    bl_options = {'UNDO'}

    filepath: StringProperty(name='Filepath', subtype='FILE_PATH', default='')
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})
    replace_existing: BoolProperty(name='Replace Existing', default=False, description='Clear the current Context Root list before importing the JSON file.')

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        prefs = _addon_prefs(context)
        if not prefs:
            return {'CANCELLED'}
        filepath = _norm_path(self.filepath or '')
        if not filepath or not os.path.isfile(filepath):
            self.report({'ERROR'}, _t('JSON file not found'))
            return {'CANCELLED'}
        with open(filepath, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        rows = list((payload or {}).get('context_roots', []) or [])
        if self.replace_existing:
            try:
                prefs.context_roots.clear()
            except Exception:
                pass
        created = 0
        updated = 0
        for row in rows:
            path = _norm_path(str(row.get('path') or ''))
            if not path:
                continue
            item = None
            for existing in list(getattr(prefs, 'context_roots', []) or []):
                if _norm_path(getattr(existing, 'path', '') or '') == path:
                    item = existing
                    break
            if item is None:
                item = prefs.context_roots.add()
                item.alias = _sf_ctx_unique_alias(prefs, str(row.get('alias') or _sf_ctx_guess_alias(path)))
                created += 1
            else:
                updated += 1
            item.path = str(row.get('path') or '')
            item.env_var = _sf_ctx_env_var_name(str(row.get('env_var') or ''))
            item.kind = str(row.get('kind') or 'ANY')
            item.enabled = bool(row.get('enabled', True))
            item.priority = int(row.get('priority', 0) or 0)
            item.notes = str(row.get('notes') or '')
        _sf_append_activity(context, _t('Imported Context Root Config'), os.path.basename(filepath), 'IMPORT')
        self.report({'INFO'}, f"{_t('Imported')}: {created} | {_t('Updated')}: {updated}")
        return {'FINISHED'}


class SF_OT_context_roots_export_manifest(bpy.types.Operator):
    bl_idname = 'export_scene.sfs_context_roots_export_manifest'
    bl_label = 'Export Manifest'
    bl_description = 'Write a JSON handoff manifest that lists current external references together with tokenized Context Root paths and suffix hints. This bridges Blender projects with root-map workflows inspired by Prism, AYON, VAMS, and XRef handoff systems.'
    bl_options = {'UNDO'}

    filepath: StringProperty(name='Filepath', subtype='FILE_PATH', default='')
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})
    include_libraries: BoolProperty(name='Include linked libraries', default=True, description='Include linked .blend libraries in the exported manifest.')
    include_texts: BoolProperty(name='Include text datablocks', default=True, description='Include external text datablocks in the exported manifest.')
    include_missing: BoolProperty(name='Include missing references', default=True, description='Keep unresolved references in the manifest so another machine can still attempt to restore them.')

    def invoke(self, context, event):
        if not self.filepath:
            base_dir = _norm_path(os.path.dirname(bpy.data.filepath or '')) if bpy.data.filepath else _sf_user_default_dir('handoff')
            blend_stem = os.path.splitext(os.path.basename(bpy.data.filepath))[0] if bpy.data.filepath else 'unsaved'
            self.filepath = os.path.join(base_dir, f"{blend_stem}_context_manifest.json")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        filepath = _norm_path(self.filepath or '')
        if not filepath:
            return {'CANCELLED'}
        payload = _sf_ctx_manifest_payload(
            context,
            include_libraries=bool(self.include_libraries),
            include_texts=bool(self.include_texts),
            include_missing=bool(self.include_missing),
        )
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
        _sf_append_activity(context, _t('Exported Context Manifest'), os.path.basename(filepath), 'FILE_TEXT')
        self.report({'INFO'}, f"{_t('Export')}: {os.path.basename(filepath)}")
        return {'FINISHED'}


class SF_OT_context_roots_preview_manifest(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_context_roots_preview_manifest'
    bl_label = 'Preview Manifest'
    bl_description = 'Read an exported Context Manifest, test how many tokenized records can be resolved with the current Context Roots and manifest-embedded roots, and export a recovery preview report without changing the scene.'
    bl_options = set()
    _sms_no_undo = True

    filepath: StringProperty(name='Filepath', subtype='FILE_PATH', default='')
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})
    include_manifest_roots: BoolProperty(name='Use manifest roots when available', default=True, description='Also try root paths embedded inside the manifest when those folders exist on this machine.')
    open_text: BoolProperty(name='Open report', default=True)

    def invoke(self, context, event):
        if not self.filepath:
            base_dir = _norm_path(os.path.dirname(bpy.data.filepath or '')) if bpy.data.filepath else _sf_user_default_dir('handoff')
            self.filepath = os.path.join(base_dir, 'smart_file_suite_context_manifest.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        filepath = _norm_path(self.filepath or '')
        payload = _sf_ctx_manifest_read(filepath)
        if not payload:
            self.report({'ERROR'}, _t('JSON file not found'))
            return {'CANCELLED'}
        summary = _sf_ctx_manifest_preview_summary(context, payload, include_manifest_roots=self.include_manifest_roots)
        title = _t('Context Manifest Preview')
        lines = _sf_report_lines_header(title, _sf_collect_report_context(context))
        lines.extend([
            f"- {_t('Manifest')}: {os.path.basename(filepath)}",
            f"- {_t('Records')}: {len(list((payload or {}).get('records', []) or []))}",
            f"- {_t('Resolvable')}: {int(summary.get('resolvable', 0) or 0)}",
            f"- {_t('Unresolved')}: {int(summary.get('unresolved', 0) or 0)}",
            f"- {_t('Token Hits')}: {int(summary.get('token_hits', 0) or 0)}",
            f"- {_t('Search Hits')}: {int(summary.get('search_hits', 0) or 0)}",
            f"- {_t('Search Roots')}: {len(list(summary.get('roots') or []))}",
            '',
            'PREVIEW',
        ])
        for row in list(summary.get('preview') or []):
            lines.append(f"- [{row.get('kind','')}] {row.get('name','')} | {row.get('mode','')} | {row.get('context_path','')}")
            if row.get('resolved'):
                lines.append(f"  -> {row.get('resolved')}")
        text_name = _sf_report_export(
            context,
            title,
            lines,
            open_text=self.open_text,
            activity_title=_t('Previewed Context Manifest'),
        )
        self.report({'INFO'}, f"{_t('Exported')}: {text_name}")
        return {'FINISHED'}


class SF_OT_context_roots_apply_manifest(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_context_roots_apply_manifest'
    bl_label = 'Apply Manifest'
    bl_description = 'Read an exported Context Manifest, match its records to the current file, and relink matching external references using the current Context Roots plus optional manifest-embedded roots.'
    bl_options = {'UNDO'}

    filepath: StringProperty(name='Filepath', subtype='FILE_PATH', default='')
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})
    include_manifest_roots: BoolProperty(name='Use manifest roots when available', default=True, description='Also try root paths embedded inside the manifest when those folders exist on this machine.')
    apply_missing_only: BoolProperty(name='Only apply to missing references', default=True, description='Keep healthy references untouched and only repair file-based records that are currently missing.')
    include_libraries: BoolProperty(name='Include linked libraries', default=True)
    include_texts: BoolProperty(name='Include text datablocks', default=False)
    path_mode: EnumProperty(
        name='Path Mode',
        items=[
            ('PRESERVE', 'Preserve Style', 'Keep each relinked path in the same style it already used when possible. Relative paths stay relative and absolute paths stay absolute.'),
            ('RELATIVE', 'Relative', 'Write resolved paths relative to the current .blend file.'),
            ('ABSOLUTE', 'Absolute', 'Write resolved paths as absolute disk paths.'),
        ],
        default='PRESERVE',
    )
    open_report: BoolProperty(name='Open report', default=True)

    def invoke(self, context, event):
        if not self.filepath:
            base_dir = _norm_path(os.path.dirname(bpy.data.filepath or '')) if bpy.data.filepath else _sf_user_default_dir('handoff')
            self.filepath = os.path.join(base_dir, 'smart_file_suite_context_manifest.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'include_manifest_roots')
        layout.prop(self, 'apply_missing_only')
        layout.prop(self, 'include_libraries')
        layout.prop(self, 'include_texts')
        layout.prop(self, 'path_mode')
        layout.prop(self, 'open_report')

    def execute(self, context):
        filepath = _norm_path(self.filepath or '')
        payload = _sf_ctx_manifest_read(filepath)
        if not payload:
            self.report({'ERROR'}, _t('JSON file not found'))
            return {'CANCELLED'}
        current_records = _sf_ext_collect_current_file_records(include_libraries=self.include_libraries, include_texts=self.include_texts, include_missing=True)
        manifest_rows = list((payload or {}).get('records', []) or [])
        if not manifest_rows:
            self.report({'WARNING'}, _t('No records found'))
            return {'CANCELLED'}
        if (not bpy.data.filepath) and _sf_ext_rows_require_saved_blend(manifest_rows, self.path_mode):
            self.report({'ERROR'}, _t('Save the current file before writing relative paths'))
            return {'CANCELLED'}

        roots = _sf_ctx_manifest_search_roots(context, payload, include_manifest_roots=self.include_manifest_roots)
        allowed_suffixes = set()
        for row in manifest_rows:
            ext = os.path.splitext(str(row.get('absolute_path') or row.get('raw_path') or ''))[1].lower()
            if ext:
                allowed_suffixes.add(ext)
        basename_index = _sf_ext_build_basename_index(roots, allowed_suffixes=allowed_suffixes) if roots else {}

        used_tokens = set()
        applied = 0
        skipped = 0
        unresolved = 0
        matched = 0
        report_lines = _sf_report_lines_header(_t('Context Manifest Recovery Report'), _sf_collect_report_context(context))
        report_lines.extend([
            f"- {_t('Manifest')}: {os.path.basename(filepath)}",
            f"- {_t('Records')}: {len(manifest_rows)}",
            f"- {_t('Search Roots')}: {len(roots)}",
            f"- {_t('Path Mode')}: {self.path_mode}",
            '',
            'RESULTS',
        ])

        for row in manifest_rows:
            target, match_mode = _sf_ctx_manifest_find_target(current_records, row, used_tokens)
            if target is None:
                skipped += 1
                report_lines.append(f"- [SKIP:{match_mode}] [{row.get('kind','')}] {row.get('name','')} | {row.get('raw_path','')}")
                continue
            matched += 1
            token = _sf_ctx_manifest_record_token(target)
            if self.apply_missing_only and (bool(target.get('exists')) or bool(target.get('packed'))):
                skipped += 1
                report_lines.append(f"- [KEEP] [{row.get('kind','')}] {row.get('name','')} | matched={match_mode}")
                if token is not None:
                    used_tokens.add(token)
                continue

            resolved, resolve_mode = _sf_ctx_manifest_resolve_row(context, row, payload=payload, basename_index=basename_index, include_manifest_roots=self.include_manifest_roots)
            if not resolved:
                unresolved += 1
                report_lines.append(f"- [MISS] [{row.get('kind','')}] {row.get('name','')} | matched={match_mode} | {row.get('context_path','') or row.get('raw_path','')}")
                continue
            try:
                old_path = getattr(target.get('id_ref'), 'filepath', '') or ''
                remap_target = _sf_ext_tokenized_sequence_path(target, resolved)
                if self.path_mode == 'RELATIVE':
                    new_path = _sf_ref_abs_to_path_mode(remap_target, 'RELATIVE')
                elif self.path_mode == 'ABSOLUTE':
                    new_path = _sf_ref_abs_to_path_mode(remap_target, 'ABSOLUTE')
                else:
                    new_path = _sf_ref_preserve_path_style(old_path, remap_target)
                setattr(target.get('id_ref'), 'filepath', new_path)
                applied += 1
                if token is not None:
                    used_tokens.add(token)
                report_lines.append(f"- [OK:{resolve_mode}] [{row.get('kind','')}] {row.get('name','')} | matched={match_mode} | {old_path} -> {new_path}")
            except Exception as ex:
                unresolved += 1
                report_lines.append(f"- [FAIL] [{row.get('kind','')}] {row.get('name','')} | {ex}")

        text_name = _sf_report_export(
            context,
            _t('Context Manifest Recovery Report'),
            report_lines,
            open_text=self.open_report,
            activity_title=_t('Applied Context Manifest'),
        )
        self.report({'INFO'}, f"{_t('Applied')}: {applied} | {_t('Matched')}: {matched} | {_t('Unresolved')}: {unresolved} | {text_name}")
        return {'FINISHED'}




def _sf_ctx_env_audit_payload(context) -> dict:
    prefs = _addon_prefs(context)
    rows = []
    summary = {'total': 0, 'env_backed': 0, 'ready': 0, 'missing_env': 0, 'missing_path': 0, 'direct': 0}
    for idx, item in enumerate(list(getattr(prefs, 'context_roots', []) or []) if prefs else []):
        alias = str(getattr(item, 'alias', '') or '').strip()
        raw_path = str(getattr(item, 'path', '') or '')
        env_var = _sf_ctx_env_var_name(str(getattr(item, 'env_var', '') or ''))
        resolved = _sf_ctx_expand_root_path(raw_path, env_var)
        status, detail = _sf_ctx_env_status(raw_path, env_var)
        summary['total'] += 1
        if env_var:
            summary['env_backed'] += 1
        if status == 'READY':
            summary['ready'] += 1
        elif status == 'MISSING_ENV':
            summary['missing_env'] += 1
        elif status == 'MISSING_PATH':
            summary['missing_path'] += 1
        else:
            summary['direct'] += 1
        rows.append({
            'index': idx,
            'alias': alias,
            'raw_path': raw_path,
            'env_var': env_var,
            'resolved_path': resolved,
            'status': status,
            'detail': detail,
            'kind': str(getattr(item, 'kind', 'ANY') or 'ANY'),
            'enabled': bool(getattr(item, 'enabled', True)),
        })
    rows.sort(key=lambda row: ({'MISSING_ENV': 0, 'MISSING_PATH': 1, 'READY': 2, 'DIRECT': 3}.get(str(row.get('status') or 'DIRECT'), 9), str(row.get('alias') or '')))
    return {
        'current_blend': _norm_path(bpy.data.filepath or ''),
        'summary': summary,
        'rows': rows,
    }


def _sf_ctx_env_audit_report_lines(title: str, payload: dict) -> list[str]:
    summary = dict((payload or {}).get('summary') or {})
    rows = list((payload or {}).get('rows') or [])
    lines = [
        f"Smart File | {title} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        '',
        f"- {_t('Current File')}: {_norm_path(str((payload or {}).get('current_blend', '') or '')) or _t('Unsaved current file')}",
        f"- {_t('Configured Roots')}: {int(summary.get('total', 0) or 0)}",
        f"- {_t('Environment-backed Roots')}: {int(summary.get('env_backed', 0) or 0)}",
        f"- {_t('Ready')}: {int(summary.get('ready', 0) or 0)}",
        f"- {_t('Missing environment variable')}: {int(summary.get('missing_env', 0) or 0)}",
        f"- {_t('Missing path')}: {int(summary.get('missing_path', 0) or 0)}",
        f"- {_t('Direct path')}: {int(summary.get('direct', 0) or 0)}",
    ]
    if rows:
        lines.extend(['', 'ROOT DETAILS'])
        for row in rows[:200]:
            lines.append(f"- [{row.get('status','DIRECT')}] {row.get('alias','')} | {row.get('kind','ANY')}")
            if row.get('env_var'):
                lines.append(f"  - {_t('Environment Variable')}: {row.get('env_var','')}")
            lines.append(f"  - {_t('Stored Path')}: {row.get('raw_path','')}")
            lines.append(f"  - {_t('Resolved Path')}: {row.get('resolved_path','')}")
            lines.append(f"  - {_t('Detail')}: {row.get('detail','')}")
    return lines


class SF_OT_context_roots_environment_audit(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_context_roots_environment_audit'
    bl_label = 'Environment Audit'
    bl_description = 'Review Context Roots that depend on environment variables, show their resolved folders, and flag missing variables or missing disk paths before relink or manifest handoff.'
    bl_options = {'UNDO'}

    open_text: BoolProperty(name='Open report', default=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=520)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'open_text')

    def execute(self, context):
        payload = _sf_ctx_env_audit_payload(context)
        title = _t('Context Root Env Audit')
        text_name = _sf_report_export(
            context,
            title,
            _sf_ctx_env_audit_report_lines(title, payload),
            open_text=self.open_text,
            activity_title=_t('Exported context-root env audit'),
        )
        summary = dict(payload.get('summary') or {})
        if int(summary.get('missing_env', 0) or 0) or int(summary.get('missing_path', 0) or 0):
            self.report({'WARNING'}, f"{_t('Context-root env audit exported')}: {text_name}")
        else:
            self.report({'INFO'}, f"{_t('Context-root env audit exported')}: {text_name}")
        return {'FINISHED'}


class SF_OT_context_roots_open(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_context_roots_open'
    bl_label = 'Open'
    bl_description = 'Open a compact board for named root aliases, suffix-aware relink support, root-map handoff manifests, and project-context maintenance.'
    bl_options = {'UNDO', 'INTERNAL'}

    popup_width: IntProperty(default=760, min=520, max=980, options={'HIDDEN'})

    def invoke(self, context, event):
        _sf_append_activity(context, _t('Opened Context Roots'), _norm_path(bpy.data.filepath or ''), 'FILE_PARENT')
        return context.window_manager.invoke_popup(self, width=self.popup_width)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        prefs = _addon_prefs(context)
        layout = self.layout
        rows = _sf_ctx_root_rows(context, kind_key='ANY', existing_only=False, include_library_roots=False)
        existing_rows = [row for row in rows if os.path.isdir(str(row.get('path') or ''))]
        manifest = _sf_ctx_manifest_payload(context, include_libraries=True, include_texts=False, include_missing=True)
        tokenized = [row for row in list(manifest.get('records', []) or []) if str(row.get('context_path') or '').strip()]

        _sf_draw_dialog_header(
            layout,
            'Context Roots',
            'Name trusted project roots, improve suffix-aware relink, and export handoff manifests without hard-coding every absolute path.',
            'FILE_PARENT',
        )

        summary = layout.box()
        _sf_draw_section_intro(
            summary,
            'Current Snapshot',
            'Context Roots add named root aliases on top of ordinary Library Roots so moved projects can be restored with fewer manual guesses.',
            'NONE',
        )
        _sf_draw_state_line(summary, 'Configured Roots', 'READY' if rows else 'NOT SET', detail=str(len(rows)))
        _sf_draw_state_line(summary, 'Existing on Disk', 'READY' if existing_rows else 'NEEDS ATTENTION', detail=str(len(existing_rows)))
        _sf_draw_state_line(summary, 'Tokenized References', 'READY' if tokenized else 'NOT SET', detail=str(len(tokenized)))
        _sf_draw_state_line(summary, 'Linked Libraries', 'READY' if any(str(r.get('kind') or '') == 'LIBRARY' for r in rows) else 'NOT SET', detail=str(len([r for r in rows if str(r.get('kind') or '') == 'LIBRARY'])))
        env_rows = [r for r in rows if str(r.get('env_var') or '').strip()]
        env_ready = [r for r in env_rows if str(r.get('env_status') or '') == 'READY']
        _sf_draw_state_line(summary, 'Environment-backed Roots', 'READY' if env_ready else ('NEEDS ATTENTION' if env_rows else 'NOT SET'), detail=f"{len(env_ready)} / {len(env_rows)}")
        _sf_draw_state_line(summary, 'Roundtrip Ready', 'READY' if tokenized else 'NOT SET', detail=_t('Export + Preview + Apply'))

        quick = layout.box()
        _sf_draw_section_intro(
            quick,
            'Quick Actions',
            'Add a named root, import existing Library Roots, then export a Context Manifest for handoff or use relink tools that can now search these roots too.',
            'CHECKMARK',
        )
        _sf_draw_action_block(
            quick,
            primary_actions=[
                ('import_scene.sfs_context_roots_add_root', 'Add Root', 'ADD', {}),
                ('import_scene.sfs_context_roots_import_library_roots', 'Import Library Roots', 'IMPORT', {}),
                ('export_scene.sfs_context_roots_export_root_config', 'Export Config', 'EXPORT', {}),
                ('import_scene.sfs_context_roots_import_root_config', 'Import Config', 'IMPORT', {}),
            ],
            secondary_actions=[
                ('export_scene.sfs_context_roots_export_manifest', 'Context Manifest', 'FILE_TEXT', {}),
                ('import_scene.sfs_context_roots_preview_manifest', 'Preview Manifest', 'FILE_TEXT', {}),
                ('import_scene.sfs_context_roots_apply_manifest', 'Apply Manifest', 'IMPORT', {}),
                ('import_scene.sfs_context_roots_environment_audit', 'Env Audit', 'VIEWZOOM', {}),
                ('import_scene.sfs_external_assets_relink_missing', 'Relink Missing', 'VIEWZOOM', {}),
                ('import_scene.sfs_root_repath_repath', 'Repath Roots', 'FILE_PARENT', {}),
                ('import_scene.sfs_reference_toolkit_open', 'Reference Toolkit', 'ASSET_MANAGER', {}),
            ],
        )

        roots_box = layout.box()
        _sf_draw_section_intro(
            roots_box,
            'Named Roots',
            'Each row can be edited directly. Use short stable aliases, keep the folder trusted, and raise priority only when this root should win against others.',
            'FILE_FOLDER',
        )
        if not prefs or not getattr(prefs, 'context_roots', None):
            roots_box.label(text=_t('No Context Roots configured yet'))
        else:
            for idx, item in enumerate(list(getattr(prefs, 'context_roots', []) or [])):
                item_box = roots_box.box()
                head = item_box.row(align=True)
                head.prop(item, 'enabled', text='')
                head.prop(item, 'alias', text=_t('Alias'))
                head.prop(item, 'kind', text='')
                head.prop(item, 'priority', text=_t('Priority'))
                op = head.operator('import_scene.sfs_context_roots_remove_root', text='', icon='TRASH', emboss=True)
                op.index = idx
                item_box.prop(item, 'path', text=_t('Root'))
                item_box.prop(item, 'env_var', text=_t('Environment Variable'))
                item_box.prop(item, 'notes', text=_t('Notes'))
                resolved_path = _sf_ctx_expand_root_path(getattr(item, 'path', '') or '', getattr(item, 'env_var', '') or '')
                env_status, env_detail = _sf_ctx_env_status(getattr(item, 'path', '') or '', getattr(item, 'env_var', '') or '')
                hint = item_box.row(align=True)
                hint.label(text=_sf_short_path_display(resolved_path, 90), icon='FILE_PARENT')
                if str(getattr(item, 'env_var', '') or '').strip():
                    hint.label(text=_sf_short_path_display(env_detail, 52), icon='SETTINGS')
                if env_status in {'MISSING_ENV', 'MISSING_PATH'}:
                    hint.label(text=_t('Missing on disk') if env_status == 'MISSING_PATH' else _t('Missing environment variable'), icon='ERROR')
                elif not os.path.isdir(resolved_path):
                    hint.label(text=_t('Missing on disk'), icon='ERROR')

        manifest_box = layout.box()
        _sf_draw_section_intro(
            manifest_box,
            'Manifest Preview',
            'These are examples of tokenized logical paths that the exported Context Manifest can carry to another workstation or storage root.',
            'FILE_TEXT',
        )
        preview_rows = list(tokenized)[:8]
        if not preview_rows:
            manifest_box.label(text=_t('No tokenized references yet'))
        for row in preview_rows:
            rr = manifest_box.row(align=True)
            rr.label(text=f"[{row.get('kind')}] {row.get('name')}", icon='LINKED')
            rr.label(text=str(row.get('context_path') or ''), icon='BLANK1')
