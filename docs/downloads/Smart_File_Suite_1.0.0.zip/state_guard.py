# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

_FALLBACK_VIEW3D_TOOL_ID = 'builtin.select_box'
_REGISTERED = False


def _iter_view3d_area_contexts(context=None):
    """Yield context dictionaries for visible 3D View areas only."""
    base_context = context or getattr(bpy, 'context', None)
    wm = getattr(base_context, 'window_manager', None) if base_context is not None else None
    windows = getattr(wm, 'windows', ()) if wm is not None else ()
    for window in windows:
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        for area in getattr(screen, 'areas', ()) or ():
            if str(getattr(area, 'type', '') or '') != 'VIEW_3D':
                continue
            space = None
            for candidate in getattr(area, 'spaces', ()) or ():
                if str(getattr(candidate, 'type', '') or '') == 'VIEW_3D':
                    space = candidate
                    break
            if space is None:
                continue
            region = None
            for candidate in getattr(area, 'regions', ()) or ():
                if str(getattr(candidate, 'type', '') or '') == 'WINDOW':
                    region = candidate
                    break
            yield {
                'window': window,
                'screen': screen,
                'area': area,
                'region': region,
                'space_data': space,
            }


def _current_view3d_mode(context) -> str:
    mode = str(getattr(context, 'mode', '') or '').strip()
    return mode or 'OBJECT'


def _active_view3d_tool_id(context) -> str:
    workspace = getattr(context, 'workspace', None)
    tools = getattr(workspace, 'tools', None) if workspace is not None else None
    if tools is None:
        return ''
    mode = _current_view3d_mode(context)
    try:
        tool = tools.from_space_view3d_mode(mode, create=False)
    except TypeError:
        try:
            tool = tools.from_space_view3d_mode(mode)
        except Exception:
            return ''
    except Exception:
        return ''
    return str(getattr(tool, 'idname', '') or '').strip()


def _view3d_tool_exists(context, tool_id: str) -> bool:
    tool_id = str(tool_id or '').strip()
    if not tool_id:
        return False
    try:
        from bl_ui.space_toolsystem_toolbar import VIEW3D_PT_tools_active
        item, _index = VIEW3D_PT_tools_active._tool_get_by_id(context, tool_id)
        return item is not None
    except Exception:
        return True


def _set_view3d_fallback_tool(context, override: dict) -> bool:
    if not override:
        return False
    kwargs = {key: value for key, value in override.items() if value is not None}
    try:
        if hasattr(context, 'temp_override'):
            with context.temp_override(**kwargs):
                try:
                    bpy.ops.wm.tool_set_by_id(name=_FALLBACK_VIEW3D_TOOL_ID, space_type='VIEW_3D')
                except TypeError:
                    bpy.ops.wm.tool_set_by_id(name=_FALLBACK_VIEW3D_TOOL_ID)
        else:
            legacy_override = context.copy()
            legacy_override.update(kwargs)
            try:
                bpy.ops.wm.tool_set_by_id(legacy_override, name=_FALLBACK_VIEW3D_TOOL_ID, space_type='VIEW_3D')
            except TypeError:
                bpy.ops.wm.tool_set_by_id(legacy_override, name=_FALLBACK_VIEW3D_TOOL_ID)
        return True
    except Exception:
        return False


def ensure_view3d_active_tool_is_valid(context=None) -> bool:
    """Repair only missing/invalid VIEW_3D active-tool IDs.

    Smart File is a standard N-panel add-on and does not register a
    custom workspace tool. This guard does not change a valid user-selected
    tool. It only repairs a missing or stale VIEW_3D tool id, which otherwise
    makes Blender print: Tool "..." not found for space "VIEW_3D".
    """
    base_context = context or getattr(bpy, 'context', None)
    if base_context is None:
        return False
    repaired = False
    for override in _iter_view3d_area_contexts(base_context):
        try:
            with base_context.temp_override(**{k: v for k, v in override.items() if v is not None}):
                tool_id = _active_view3d_tool_id(bpy.context)
                if tool_id and _view3d_tool_exists(bpy.context, tool_id):
                    continue
                repaired = _set_view3d_fallback_tool(bpy.context, override) or repaired
        except Exception:
            tool_id = _active_view3d_tool_id(base_context)
            if not tool_id or not _view3d_tool_exists(base_context, tool_id):
                repaired = _set_view3d_fallback_tool(base_context, override) or repaired
    return repaired


def _timer_repair_once():
    try:
        ensure_view3d_active_tool_is_valid(getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def schedule_view3d_active_tool_check() -> None:
    return None


def register() -> None:
    global _REGISTERED
    _REGISTERED = True
    return None


def unregister() -> None:
    global _REGISTERED
    _REGISTERED = False
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_timer_repair_once):
            timers.unregister(_timer_repair_once)
    except Exception:
        pass
