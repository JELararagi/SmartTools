#  Copyright (C) 2026 JELararagi
#  Official Contact:
#  Video Tutorials:
#
#  【ライセンス】
#  - 著作権: 本ソフトウェアの権利は「JELararagi」に帰属します。
#  - ライセンス: GNU General Public License v3.0 以降（GPL-3.0-or-later）で配布します。

"""Smart File bootstrap helpers.

This module now hosts the heavy i18n and tooltip support logic so the package
entry files stay small and easier to maintain.

The bootstrap performs four jobs before the feature modules are executed:

1. Strip bilingual source strings down to English msgids so Blender's
   translation system can render a single clean language in the UI.
2. Wrap Blender property factories so missing tooltips receive beginner-friendly
   descriptions and every property can register a Japanese translation.
3. Normalize both static Enum items and callback-driven Enum items so their
   labels and descriptions are translated consistently.
4. Collect translation hints early, then merge them into both Smart File
   and integrated History translations before register() runs.
"""

from __future__ import annotations

from pathlib import Path as _Path
from functools import lru_cache as _lru_cache
import ast as _ast
import io as _io
import inspect as _inspect
import re as _re
import tokenize as _tokenize
import textwrap as _textwrap

try:
    import bpy as _bpy
except Exception:  # pragma: no cover - Blender provides bpy at runtime.
    _bpy = None

try:
    from .ui_language_runtime import (
        split_bilingual as _sf_shared_split_bilingual,
        to_japanese as _sf_shared_to_japanese,
        to_english as _sf_shared_to_english,
        _EXTRA_EXACT_TRANSLATIONS as _SF_EXTRA_EXACT_TRANSLATIONS,
        _EXTRA_PHRASE_TRANSLATIONS as _SF_EXTRA_PHRASE_TRANSLATIONS,
    )
except Exception:  # pragma: no cover
    _sf_shared_split_bilingual = None
    _sf_shared_to_japanese = None
    _sf_shared_to_english = None
    _SF_EXTRA_EXACT_TRANSLATIONS = {}
    _SF_EXTRA_PHRASE_TRANSLATIONS = ()

_FEATURE_FILES = (
    "core.py",
    "main_append.py",
    "asset_reader.py",
    "catalog_tools.py",
    "reference_manager.py",
    "external_assets.py",
    "reference_toolkit.py",
    "pipeline_bridge.py",
    "representation_toolkit.py",
    "project_guard.py",
    "shot_state_toolkit.py",
    "shot_queue_toolkit.py",
    "root_repath_toolkit.py",
    "assembly_guard_toolkit.py",
    "dependency_cockpit_toolkit.py",
    "container_deck_toolkit.py",
    "context_root_toolkit.py",
    "root_watch_toolkit.py",
    "batch_preview.py",
    "publisher.py",
    "history_integration.py",
    "file_pipeline.py",
    "register.py",
)

_PKG_DIR = None
_NAMESPACE = None

_SF_PENDING_TRANSLATIONS: dict[str, dict[tuple[str, str], str]] = {"ja_JP": {}}
_SF_TRANSLATION_CONTEXTS = (
    "*",
    "Operator",
    "Property",
    "UI",
    "Tooltip",
    "Addon",
    "Panel",
    "Menu",
)

from .translation_exact import _SF_EXACT_LABEL_TRANSLATIONS
from .translation_phrases import _SF_PHRASE_TRANSLATIONS
from .language_extra import EXTRA_TRANSLATIONS as _SF_REVIEWED_TRANSLATIONS, has_leftover_english as _sf_has_leftover_english

try:
    _SF_EXACT_LABEL_TRANSLATIONS = dict(_SF_EXACT_LABEL_TRANSLATIONS or {})
    _SF_EXACT_LABEL_TRANSLATIONS.update(dict(_SF_EXTRA_EXACT_TRANSLATIONS or {}))
except Exception:
    pass
try:
    _SF_PHRASE_TRANSLATIONS = tuple(_SF_PHRASE_TRANSLATIONS or ()) + tuple(_SF_EXTRA_PHRASE_TRANSLATIONS or ())
except Exception:
    pass

try:
    from .translation_generated import SF_GENERATED_TRANSLATIONS as _SF_GENERATED_TRANSLATIONS
except Exception:
    _SF_GENERATED_TRANSLATIONS = {}
try:
    for _sf_src, _sf_dst in dict(_SF_GENERATED_TRANSLATIONS or {}).items():
        if isinstance(_sf_src, str) and isinstance(_sf_dst, str) and _sf_src and _sf_dst:
            _SF_EXACT_LABEL_TRANSLATIONS.setdefault(_sf_src, _sf_dst)
except Exception:
    pass


_SF_DYNAMIC_FORWARD_TRANSLATIONS: dict[str, str] = {}
_SF_DYNAMIC_REVERSE_TRANSLATIONS: dict[str, str] = {}
_SF_ENABLE_RUNTIME_SAFETY_WRAPPERS = False
_SF_ENABLE_PROPERTY_FACTORY_WRAPPERS = True
_SF_REVERSE_EXACT_LABEL_TRANSLATIONS = {
    dst: src
    for src, dst in _SF_EXACT_LABEL_TRANSLATIONS.items()
    if isinstance(dst, str) and dst and dst != src
}
_SF_REVERSE_PHRASE_TRANSLATIONS = [
    (dst, src)
    for src, dst in _SF_PHRASE_TRANSLATIONS
    if isinstance(dst, str) and dst and dst != src
]
_SF_REVERSE_PHRASE_TRANSLATIONS.sort(key=lambda item: len(item[0]), reverse=True)
_SF_MANUAL_REVERSE_EXACT_TRANSLATIONS = {
    "履歴": "History",
    "インポート": "Import",
    "素材置き場": "Asset Reader",
    "リンク修復": "Repair Links",
    "公開整理": "Publish Organizer",
    "サムネイル": "Thumbnails",
    "作業保護": "Work Protection",
    "シーンを選択": "Scene Select",
    "フォルダーを開く": "Open Folder",
    "オープンソースフォルダー": "Open Source Folder",
    "お気に入り": "Favorites",
    "読み込み": "Import",
    "履歴ログ": "History Log",
    "保存先と動作": "Storage & Behavior",
    "自動保護": "Automatic Protection",
    "ヒストリー一覧": "History List",
    "クイック操作": "Quick Actions",
}
for _jp, _en in _SF_MANUAL_REVERSE_EXACT_TRANSLATIONS.items():
    _SF_REVERSE_EXACT_LABEL_TRANSLATIONS.setdefault(_jp, _en)

# These tables are immutable after bootstrap assembly.  Sorting them inside
# every unique label translation was measurable during registration (hundreds
# of repeated sorts over the same data).  Precompute the exact same order once
# without changing any translation output.
_SF_PHRASE_TRANSLATIONS_SORTED = tuple(
    sorted(_SF_PHRASE_TRANSLATIONS, key=lambda item: len(item[0]), reverse=True)
)
_SF_EXACT_LABEL_TRANSLATIONS_SORTED = tuple(
    sorted(_SF_EXACT_LABEL_TRANSLATIONS.items(), key=lambda item: len(item[0]), reverse=True)
)


_SF_ASCII_RE = _re.compile(r"[A-Za-z]")
_SF_JAPANESE_RE = _re.compile(r"[ぁ-んァ-ン一-龯]")


def _sf_has_ascii(text: str) -> bool:
    return bool(_SF_ASCII_RE.search(text or ""))

def _sf_has_japanese(text: str) -> bool:
    return bool(_SF_JAPANESE_RE.search(text or ""))


def _sf_split_bilingual(text: object):
    if callable(_sf_shared_split_bilingual):
        try:
            return _sf_shared_split_bilingual(text)
        except Exception:
            pass
    if not isinstance(text, str):
        return None
    text = text.strip()
    if not text:
        return None

    def _candidate(left, right):
        left = str(left or '').strip()
        right = str(right or '').strip()
        if not left or not right:
            return None
        if _sf_has_japanese(right) and not _sf_has_japanese(left):
            if _sf_has_ascii(right) and (len(left) < 8 or len(left.split()) < 2):
                return None
            return left, right
        if _sf_has_japanese(left) and not _sf_has_japanese(right):
            if _sf_has_ascii(left) and (len(right) < 8 or len(right.split()) < 2):
                return None
            return right, left
        return None

    candidates = []
    for sep in (' / ', ' ｜ ', ' | ', '：', ' : '):
        cursor = 0
        while True:
            idx = text.find(sep, cursor)
            if idx < 0:
                break
            pair = _candidate(text[:idx], text[idx + len(sep):])
            if pair:
                jp_ascii = len(_re.findall(r'[A-Za-z]', pair[1] or ''))
                candidates.append(((-jp_ascii, len(pair[0]), idx), pair))
            cursor = idx + len(sep)
    if '/' in text and not candidates:
        for idx, char in enumerate(text):
            if char != '/':
                continue
            pair = _candidate(text[:idx], text[idx + 1:])
            if pair:
                jp_ascii = len(_re.findall(r'[A-Za-z]', pair[1] or ''))
                candidates.append(((-jp_ascii, len(pair[0]), idx), pair))
    for pattern in (
        r'^\s*(.+?)\s*[（(]\s*(.+?)\s*[）)]\s*$',
        r'^\s*(.+?)\s*\[\s*(.+?)\s*\]\s*$',
    ):
        match = _re.match(pattern, text)
        if not match:
            continue
        pair = _candidate(match.group(1), match.group(2))
        if pair:
            candidates.append(((0, len(pair[0]), 10**9), pair))
    if candidates:
        candidates.sort(key=lambda item: item[0], reverse=True)
        return candidates[0][1]
    return None


def _sf_register_pending_translation(src: object, jp: object):
    if not isinstance(src, str) or not isinstance(jp, str):
        return
    src = src.strip()
    jp = jp.strip()
    if not src or not jp:
        return
    jp = _SF_REVIEWED_TRANSLATIONS.get(("*", src), jp)
    if _sf_has_leftover_english(jp):
        return
    ja = _SF_PENDING_TRANSLATIONS.setdefault("ja_JP", {})
    for ctx in _SF_TRANSLATION_CONTEXTS:
        ja.setdefault((ctx, src), jp)
    if src != jp:
        _SF_DYNAMIC_FORWARD_TRANSLATIONS.setdefault(src, jp)
        _SF_DYNAMIC_REVERSE_TRANSLATIONS.setdefault(jp, src)


def _sf_clean_ui_text(text: object) -> object:
    if not isinstance(text, str):
        return text
    text = text.strip()
    if not text:
        return text
    pair = _sf_split_bilingual(text)
    if pair:
        eng, jp = pair
        _sf_register_pending_translation(text, jp)
        _sf_register_pending_translation(eng, jp)
        return eng
    return text


# Compiled once: these sentence templates are immutable and were previously
# rebuilt for every unique label encountered during registration.
_SF_LABEL_SENTENCE_PATTERNS = (
    (_re.compile(r"^No (.+) yet\.?$"), lambda m: f"まだ{_sf_guess_label_japanese(m.group(1)) or m.group(1)}はありません。"),
    (_re.compile(r"^No (.+) found\.?$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}は見つかりませんでした。"),
    (_re.compile(r"^No (.+) selected\.?$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}が選択されていません。"),
    (_re.compile(r"^Nothing to (.+)$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}するものがありません。"),
    (_re.compile(r"^Ready for (.+)$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}の準備ができています"),
    (_re.compile(r"^Needs (.+)$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}が必要です"),
    (_re.compile(r"^(.+) complete$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}が完了しました"),
    (_re.compile(r"^(.+) exported$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}を書き出しました"),
    (_re.compile(r"^(.+) saved$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}を保存しました"),
    (_re.compile(r"^(.+) removed$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}を削除しました"),
    (_re.compile(r"^(.+) updated$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}を更新しました"),
    (_re.compile(r"^(.+) failed$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}に失敗しました"),
    (_re.compile(r"^Open (.+)$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}を開く"),
    (_re.compile(r"^Inspect (.+)\.$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}を確認します。"),
    (_re.compile(r"^Compare (.+)\.$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}を比較します。"),
    (_re.compile(r"^Prepare (.+)\.$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}を準備します。"),
    (_re.compile(r"^Protect (.+)\.$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}を保護します。"),
    (_re.compile(r"^Read (.+)\.$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}を確認してください。"),
    (_re.compile(r"^See (.+)\.$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}を確認します。"),
    (_re.compile(r"^Set up (.+)$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}を設定します"),
    (_re.compile(r"^Track (.+)\.$"), lambda m: f"{_sf_guess_label_japanese(m.group(1)) or m.group(1)}を追跡します。"),
)


@_lru_cache(maxsize=None)
def _sf_guess_label_japanese(text: object) -> str:
    if not isinstance(text, str):
        return ""
    text = str(_sf_clean_ui_text(text)).strip()
    if not text:
        return ""
    exact = _SF_EXACT_LABEL_TRANSLATIONS.get(text)
    if exact and exact != text:
        return exact
    if callable(_sf_shared_to_japanese):
        try:
            shared = str(_sf_shared_to_japanese(text) or '').strip()
        except Exception:
            shared = ''
        if shared and shared != text and _sf_has_japanese(shared):
            return shared

    # Frequently repeated sentence-level patterns used across reports, cards, and hints.
    for pattern, builder in _SF_LABEL_SENTENCE_PATTERNS:
        match = pattern.match(text)
        if match:
            try:
                return builder(match)
            except Exception:
                pass

    return text


def _sf_guess_label_english(text: object, allow_partial: bool = False) -> str:
    if not isinstance(text, str):
        return ""
    text = str(_sf_clean_ui_text(text)).strip()
    if not text:
        return ""
    if not _sf_has_japanese(text):
        return text
    exact = _SF_DYNAMIC_REVERSE_TRANSLATIONS.get(text) or _SF_REVERSE_EXACT_LABEL_TRANSLATIONS.get(text)
    if exact:
        return exact
    if callable(_sf_shared_to_english):
        try:
            shared = str(_sf_shared_to_english(text) or '').strip()
        except Exception:
            shared = ''
        if shared and shared != text and (allow_partial or not _sf_has_japanese(shared)):
            return shared
    out = text
    for src, dst in _SF_REVERSE_PHRASE_TRANSLATIONS:
        out = out.replace(src, dst)
    for src, dst in sorted(_SF_DYNAMIC_REVERSE_TRANSLATIONS.items(), key=lambda item: len(item[0]), reverse=True):
        out = out.replace(src, dst)
    if out != text:
        if allow_partial or not _sf_has_japanese(out):
            return out
    return ""


def _sf_normalize_msgid(text: object, role: str = "label") -> object:
    if not isinstance(text, str):
        return text
    text = text.strip()
    if not text:
        return text
    pair = _sf_split_bilingual(text)
    if pair:
        eng, jp = pair
        _sf_register_pending_translation(eng, jp)
        _sf_register_pending_translation(text, jp)
        return eng
    if _sf_has_japanese(text):
        allow_partial = role in {"description", "tooltip", "report"}
        eng = _sf_guess_label_english(text, allow_partial=allow_partial)
        if eng and eng != text:
            _sf_register_pending_translation(eng, text)
            return eng
        return text
    jp = _sf_guess_label_japanese(text)
    if jp and jp != text:
        _sf_register_pending_translation(text, jp)
    return text



def _sf_operator_tooltip_pair(label: str, desc: str):
    label_en = (label or "This action").strip() or "This action"
    label_jp = _sf_guess_label_japanese(label_en) or "この操作"
    if not _sf_has_japanese(label_jp):
        label_jp = "この操作"
    key = f"{label_en} {desc}".lower()
    if any(token in key for token in ("open", "show", "view", "popup", "board", "palette", "home", "matrix", "launcher")):
        return (
            f"Open {label_en} so you can read the current status first, then move to the most relevant next tool without hunting through several panels or menus. Beginners can use this as a safe entry point before making changes.",
            f"{label_jp}を開きます。まず現在の状態を確認し、そのあと複数のパネルやメニューを探し回らずに次の適切なツールへ進めます。初心者は、変更を加える前の安全な入口として使えます。",
        )
    if any(token in key for token in ("import", "append", "link", "bring in", "use saved", "use current", "select file", "scene select", "browse")):
        return (
            f"Use {label_en} to choose a source .blend file, inspect its contents, and bring in only the datablocks you actually need. A simple way to use it is: select a source file, choose a type such as Objects or Collections, check the items you want, then run the import.",
            f"{label_jp}は、読み込み元の .blend ファイルを選び、その中身を確認して、本当に必要なデータブロックだけを取り込むための操作です。基本的な使い方は、ソースファイルを選ぶ → Objects や Collections など種類を選ぶ → 必要な項目をチェックする → インポートを実行する、の順です。",
        )
    if any(token in key for token in ("publish", "export", "report", "bundle", "handoff", "release", "thumbnail")):
        return (
            f"Use {label_en} when you want to write files out for review, sharing, delivery, or library publication. Check the destination path and summary first, then run it after you are satisfied with the settings.",
            f"{label_jp}は、確認用・共有用・納品用・ライブラリ公開用のファイルを書き出したいときに使います。まず保存先や要約を確認し、設定に問題がないことを確かめてから実行してください。",
        )
    if any(token in key for token in ("check", "scan", "analyze", "diagnostic", "validate", "refresh", "reload", "rebuild")):
        return (
            f"Run {label_en} to inspect the current state again and refresh the information used by Smart File. This is a good first step when something looks outdated, missing, or incorrect.",
            f"{label_jp}を実行すると、現在の状態を再確認し、Smart File が使う情報を更新できます。表示が古い、足りない、正しくないと感じたときの最初の確認手順として向いています。",
        )
    if any(token in key for token in ("container", "revision", "representation", "manifest")):
        return (
            f"Use {label_en} when you want to compare versioned handoff packages, switch between lightweight and full representations, or reopen a specific published revision. A safe workflow is: check the current container summary, compare revision and representation, then load the target you actually want.",
            f"{label_jp}は、バージョン管理された引き継ぎパッケージを比べたいとき、軽量表現と完全表現を切り替えたいとき、あるいは特定の公開リビジョンを開きたいときに使います。安全な手順は、現在のコンテナ概要を確認する → リビジョンと表現を比べる → 本当に必要な対象を読み込む、の順です。",
        )
    if any(token in key for token in ("lock", "unlock", "checkout", "stale")):
        return (
            f"Use {label_en} to manage cooperative reservation files that help teams avoid stepping on the same scene or linked references at the same time. Prefer normal lock and unlock first, and only clean up stale rows after confirming the previous owner is no longer working on them.",
            f"{label_jp}は、同じシーンやリンク参照を同時に触ってしまう事故を減らすための、協調予約ファイルを管理する操作です。まず通常のロックと解除を使い、古いロックの整理は、前の所有者がもう作業していないと確認できた場合だけ行ってください。",
        )
    if any(token in key for token in ("root", "watch", "manifest", "coverage")):
        return (
            f"Use {label_en} to review or adjust the project roots that Smart File relies on for relink, drift watch, path recovery, and handoff files. When in doubt, confirm the active source first, then open the root tool and make small changes one step at a time.",
            f"{label_jp}は、再リンク、差分監視、パス復旧、引き継ぎファイルで Smart File が頼りにするプロジェクトルートを確認・調整するための操作です。迷う場合は、まず現在のソースを確認し、そのあとルート系ツールを開いて、一度に少しずつ変更してください。",
        )
    if any(token in key for token in ("repair", "fix", "cleanup", "clear", "remove", "delete", "relink")):
        return (
            f"Use {label_en} to repair, relink, clean, or remove data safely. A safe beginner workflow is to review the target first, confirm the result preview, and only then apply the change.",
            f"{label_jp}は、データの修復・再リンク・整理・削除を安全に行うための操作です。初心者は、まず対象を確認する → 結果プレビューを見る → 問題なければ適用する、の順で進めると安全です。",
        )
    if any(token in key for token in ("history", "restore", "snapshot", "autosave")):
        return (
            f"Use {label_en} to protect your work with restore points, autosaves, and history review. Create a restore point before risky edits, then use the history list later if you need to step back.",
            f"{label_jp}は、復元ポイント、自動保存、履歴確認で作業内容を守るための操作です。危険な編集の前に復元ポイントを作成し、あとで戻りたくなったら履歴一覧から使ってください。",
        )
    if any(token in key for token in ("profile", "preset", "goal", "session")):
        return (
            f"Use {label_en} to switch the workspace setup, saved workflow state, or task goal. This is useful when you want to quickly move between import, maintenance, publish, and recovery work without rebuilding the setup by hand.",
            f"{label_jp}は、ワークスペース設定、保存済みワークフロー状態、作業ゴールを切り替えるための操作です。インポート、メンテナンス、公開、復旧などの作業を、毎回手動で組み直さずに素早く切り替えたいときに便利です。",
        )
    return (
        f"Run {label_en} to perform this Smart File step with the current selection and settings. Read the surrounding options first, then use this when you are ready to continue the workflow.",
        f"{label_jp}を実行すると、現在の選択と設定で Smart File のこの手順を進められます。周辺の設定や説明を確認したうえで、次の作業へ進む準備ができたときに使ってください。",
    )


@_lru_cache(maxsize=None)
def _sf_property_tooltip_pair(name: object, factory_name: str):
    label_en = str(_sf_clean_ui_text(name or "")).strip()
    label_jp = _sf_guess_label_japanese(label_en) if label_en else "この項目"
    if not _sf_has_japanese(label_jp):
        label_jp = "この項目"
    key = label_en.lower()
    if not label_en:
        return (
            "Internal Smart File state used to keep lists, review rows, and workflow steps working correctly. You normally do not need to edit this directly unless a tool explicitly asks for it.",
            "Smart File の一覧、レビュー行、ワークフロー手順を正しく動かすための内部状態です。通常は直接変更する必要はなく、ツールから明示的に求められたときだけ扱ってください。",
        )
    if factory_name == "CollectionProperty":
        return (
            f"{label_en} stores a list used by Smart File, such as search results, review rows, saved paths, profiles, or history entries. In normal use you read or choose rows from this list through the UI instead of editing the data structure directly.",
            f"{label_jp}は、検索結果、レビュー行、保存済みパス、プロファイル、履歴項目など、Smart File が使う一覧データです。通常は内部データを直接編集せず、UI 上で行を確認したり選択したりして使います。",
        )
    if factory_name == "PointerProperty":
        return (
            f"{label_en} links this part of the add-on to another settings block or data object. You usually adjust the visible fields inside that linked block rather than replacing the link itself.",
            f"{label_jp}は、この部分のアドオンを別の設定ブロックやデータオブジェクトに結び付ける参照です。通常は参照そのものを置き換えるのではなく、その中に見えている設定項目を調整して使います。",
        )
    if any(token in key for token in ("path", "file", "folder", "root", "source", "blend")):
        return (
            f"Set the {label_en} used by this step. Choose the correct file or folder first, then continue with scan, import, diagnostics, relink, or publishing. If you are unsure, start by selecting the exact .blend file you want to read from.",
            f"この手順で使う{label_jp}を指定します。まず正しいファイルやフォルダーを選び、そのあと走査・インポート・診断・再リンク・公開へ進んでください。迷ったときは、まず読み込み元にしたい .blend ファイルを正確に選ぶのが安全です。",
        )
    if any(token in key for token in ("container", "revision", "representation", "manifest")):
        return (
            f"{label_en} controls which published container, revision, or representation the next step will use. Review the nearby family, status, and revision information before changing it so you do not accidentally load the wrong handoff package.",
            f"{label_jp}は、次の処理でどの公開コンテナ・リビジョン・表現を使うかを決める項目です。誤って別の引き継ぎパッケージを読み込まないよう、変更前に近くの family、status、revision 情報も一緒に確認してください。",
        )
    if any(token in key for token in ("lock", "unlock", "owner", "stale", "checkout")):
        return (
            f"{label_en} is part of the cooperative lock workflow. Use it to describe who owns a lock, whether it is still active, or whether it can be cleaned safely. Do not force or clean stale rows until you verify the other artist is finished.",
            f"{label_jp}は、協調ロックの運用に関する項目です。誰がロックを持っているか、まだ有効か、安全に整理できるかを判断するために使います。相手の作業終了を確認するまで、強制操作や古いロック整理は行わないでください。",
        )
    if any(token in key for token in ("shot", "camera", "marker", "queue", "render")):
        return (
            f"{label_en} affects shot-style scene review, camera handoff, or queued output settings. Beginners should save or snapshot the current scene state first, then change these values so it is easy to return to the earlier setup.",
            f"{label_jp}は、ショット風のシーン確認、カメラ引き継ぎ、またはキュー出力設定に関わる項目です。初心者は、まず現在のシーン状態を保存またはスナップショットしてから変更すると、元の設定へ戻しやすくなります。",
        )
    if any(token in key for token in ("search", "filter", "tag", "category")):
        return (
            f"Use {label_en} to narrow the visible results. Start without a filter, then type here only when the list is too large and you want to find the right item faster.",
            f"{label_jp}は表示結果を絞り込むための項目です。最初は空欄のまま使い、候補が多すぎるときだけ入力すると、目的の項目を早く見つけやすくなります。",
        )
    if any(token in key for token in ("preview", "thumb", "thumbnail", "image")):
        return (
            f"{label_en} stores or shows preview imagery used to help you visually confirm the asset, source file, or publish result before you continue. Beginners should compare the preview with the file name so they do not import the wrong item by accident.",
            f"{label_jp}は、アセット、ソースファイル、公開結果を見た目で確認するためのプレビュー画像に関する項目です。初心者は、誤って別の項目を読み込まないよう、画像とファイル名を一緒に確認してください。",
        )
    if any(token in key for token in ("history", "restore", "autosave", "snapshot", "log")):
        return (
            f"{label_en} is part of the work-protection system. It helps Smart File remember older states, restore points, autosaves, or exported logs so you can review what happened and recover safely when needed.",
            f"{label_jp}は作業保護システムに関する項目です。過去の状態、復元ポイント、自動保存、書き出しログを Smart File が覚えておき、必要なときに安全に見直したり戻したりできるようにします。",
        )
    if any(token in key for token in ("catalog", "candidate", "group", "version", "latest", "published", "preferred", "lane", "score", "diagnostic")):
        return (
            f"{label_en} helps compare catalog entries, relink candidates, or published versions. Review this together with nearby source, file, and preview fields before deciding which result to import, relink, or publish. ",
            f"{label_jp}は、カタログ項目、再リンク候補、公開バージョンの比較に使う項目です。どれを読み込むか、再リンクするか、公開するかを決める前に、近くのソース、ファイル、プレビュー情報と一緒に確認してください。",
        )
    if any(token in key for token in ("json", "uid", "identity", "cache", "raw", "state", "fingerprint", "signature")):
        return (
            f"{label_en} is internal support data used by Smart File to cache results, preserve identity, or pass technical state between tools. Most users should leave this unchanged unless a specific troubleshooting step tells you otherwise.",
            f"{label_jp}は、結果のキャッシュ、識別情報の保持、ツール間の技術的な状態受け渡しに使う内部補助データです。通常は変更せず、特定のトラブルシュート手順で指示があった場合だけ扱ってください。",
        )
    if any(token in key for token in ("mode", "type", "scope", "sort", "collision", "preset")):
        return (
            f"Choose the {label_en} for this tool. Read the option names first, then pick the one that best matches what you want to inspect, import, repair, publish, or organize next.",
            f"このツールで使う{label_jp}を選びます。まず選択肢名を確認し、そのあと次に確認・インポート・修復・公開・整理したい内容に最も近いものを選んでください。",
        )
    if any(token in key for token in ("name", "label", "note", "prefix", "id", "key")):
        return (
            f"Enter the {label_en} text used to identify this item. Use short, clear wording so the next step stays easy to understand later. Good labels make saved history, profiles, and reports much easier to read.",
            f"この項目を識別するための{label_jp}を入力します。あとで見返したときにも分かりやすいよう、短くはっきりした言葉を使ってください。名前やメモが分かりやすいほど、履歴、プロファイル、レポートを読みやすくなります。",
        )
    if factory_name == "BoolProperty" or any(token in key for token in ("use", "enable", "include", "select", "favorite", "preview", "meta", "allow", "checked")):
        return (
            f"Turn {label_en} on or off for the current step. Enable it when you want this behavior included, or disable it when you want a simpler, safer, or easier-to-review result first.",
            f"現在の手順で{label_jp}をオン・オフします。この動作を含めたいならオン、まずはより単純・安全・確認しやすい結果を優先したいならオフにしてください。",
        )
    if factory_name in {"IntProperty", "FloatProperty", "FloatVectorProperty"} or any(token in key for token in ("count", "index", "version", "priority", "depth", "offset", "spacing", "columns", "interval", "max", "threshold", "weight", "minutes", "seconds")):
        return (
            f"Adjust the numeric value for {label_en}. Increase it when you need a larger or stronger result, or lower it for a smaller, denser, lighter, or safer one. Change it in small steps if you are unsure.",
            f"{label_jp}の数値を調整します。より大きい・強い結果が欲しいときは上げ、より小さい・密な・軽い・安全な結果を優先したいときは下げてください。迷う場合は少しずつ変更するのが安全です。",
        )
    return (
        f"Set {label_en} for the current Smart File task. This option changes how the next step behaves with the current data and selection, so review nearby settings first if you are not sure.",
        f"現在の Smart File 作業で使う{label_jp}を設定します。この項目は、次の処理が今のデータや選択に対してどう動くかを変えます。迷う場合は、周囲の設定も確認してから調整してください。",
    )


@_lru_cache(maxsize=None)
def _sf_enum_item_tooltip_pair(identifier: object, label: object):
    label_en = str(_sf_clean_ui_text(label or identifier or "Option")).strip() or "Option"
    label_jp = _sf_guess_label_japanese(label_en) or "この選択肢"
    if not _sf_has_japanese(label_jp):
        label_jp = "この選択肢"
    key = f"{identifier} {label_en}".lower()
    if any(token in key for token in ("append", "link", "override")):
        return (
            f"Choose {label_en} when this import behavior best matches how editable or shareable you want the result to be.",
            f"読み込み後にどこまで編集したいか、共有ライブラリとして保ちたいかに合わせて {label_jp} を選んでください。",
        )
    if any(token in key for token in ("object", "collection", "material", "action", "world", "node")):
        return (
            f"Use {label_en} when this is the type of datablock you want to browse or bring into the current file.",
            f"現在のファイルへ確認・読み込みしたいデータの種類が {label_jp} のときに選びます。",
        )
    if any(token in key for token in ("latest", "newest", "reuse", "replace", "duplicate")):
        return (
            f"Choose {label_en} to control how Smart File handles existing data or version choices in this step.",
            f"この手順で既存データやバージョン選択をどう扱うかを決めるために {label_jp} を選びます。",
        )
    return (
        f"Choose {label_en} for this setting when it best matches the result you want from the current step.",
        f"現在の手順で得たい結果に最も近い場合に {label_jp} を選んでください。",
    )



def _sf_process_enum_items(items):
    cleaned_items = []
    for item in items:
        if not isinstance(item, (list, tuple)) or len(item) < 2:
            cleaned_items.append(item)
            continue
        item = list(item)
        identifier = item[0]
        label = _sf_clean_ui_text(item[1])
        item[1] = label
        desc = item[2] if len(item) >= 3 else ""
        desc = _sf_clean_ui_text(desc) if isinstance(desc, str) else desc
        if len(item) >= 3:
            if not desc:
                desc_en_item, desc_jp_item = _sf_enum_item_tooltip_pair(identifier, label)
                item[2] = desc_en_item
                _sf_register_pending_translation(desc_en_item, desc_jp_item)
            else:
                pair = _sf_split_bilingual(desc)
                if pair:
                    item[2] = pair[0]
                    _sf_register_pending_translation(pair[0], pair[1])
                elif isinstance(desc, str):
                    desc_jp_item = _sf_guess_label_japanese(desc)
                    if desc_jp_item and desc_jp_item != desc:
                        _sf_register_pending_translation(desc, desc_jp_item)
        label_jp = _sf_guess_label_japanese(label)
        if label_jp and label_jp != label:
            _sf_register_pending_translation(str(label), label_jp)
        cleaned_items.append(tuple(item))
    return cleaned_items


def _sf_wrap_enum_items_callback(callback):
    if not callable(callback):
        return callback
    if getattr(callback, "_sf_wrapped_enum_items", False):
        return callback

    try:
        sig = _inspect.signature(callback)
        params = list(sig.parameters.values())
        positional = [
            p for p in params
            if p.kind in {_inspect.Parameter.POSITIONAL_ONLY, _inspect.Parameter.POSITIONAL_OR_KEYWORD}
        ]
        has_varargs = any(p.kind == _inspect.Parameter.VAR_POSITIONAL for p in params)
        positional_count = len(positional)
    except Exception:
        positional_count = 2
        has_varargs = False

    last_good_items: list = []

    def _process(result):
        if result is None:
            return list(last_good_items)
        if isinstance(result, (list, tuple)):
            seq = list(result)
        else:
            try:
                seq = list(result)
            except Exception:
                return list(last_good_items)
        try:
            seq = list(_sf_process_enum_items(seq))
        except Exception:
            pass
        last_good_items[:] = list(seq)
        return seq

    def _call_with_adapted_signature(self, context):
        if has_varargs or positional_count >= 2:
            return callback(self, context)
        if positional_count == 1:
            return callback(context)
        return callback()

    def wrapped(self, context):
        try:
            return _process(_call_with_adapted_signature(self, context))
        except Exception:
            return list(last_good_items)

    try:
        wrapped.__name__ = getattr(callback, "__name__", "wrapped_enum_items")
        wrapped.__qualname__ = getattr(callback, "__qualname__", wrapped.__name__)
        wrapped.__module__ = getattr(callback, "__module__", __name__)
        wrapped.__doc__ = getattr(callback, "__doc__", None)
        wrapped.__signature__ = _inspect.Signature(parameters=[
            _inspect.Parameter("self", _inspect.Parameter.POSITIONAL_OR_KEYWORD),
            _inspect.Parameter("context", _inspect.Parameter.POSITIONAL_OR_KEYWORD),
        ])
        wrapped._sf_wrapped_enum_items = True
        wrapped._sf_wrapped_source = callback
    except Exception:
        pass
    return wrapped

def _sf_wrap_runtime_callback(callback, *, fallback=None):
    if not callable(callback):
        return callback
    if getattr(callback, "_sf_wrapped_runtime_callback", False):
        return callback

    try:
        sig = _inspect.signature(callback)
        params = list(sig.parameters.values())
        positional = [
            p for p in params
            if p.kind in {_inspect.Parameter.POSITIONAL_ONLY, _inspect.Parameter.POSITIONAL_OR_KEYWORD}
        ]
        has_varargs = any(p.kind == _inspect.Parameter.VAR_POSITIONAL for p in params)
        positional_count = len(positional)
        first_name = str(positional[0].name).lower() if positional else ""
    except Exception:
        positional_count = 2
        has_varargs = True
        first_name = ""

    def wrapped(self, context):
        try:
            if has_varargs or positional_count >= 2:
                return callback(self, context)
            if positional_count == 1:
                if first_name in {"context", "ctx", "value", "obj", "object"}:
                    return callback(context)
                return callback(self)
            return callback()
        except Exception:
            return fallback

    try:
        wrapped.__name__ = getattr(callback, "__name__", "wrapped_runtime_callback")
        wrapped.__qualname__ = getattr(callback, "__qualname__", wrapped.__name__)
        wrapped.__module__ = getattr(callback, "__module__", __name__)
        wrapped.__doc__ = getattr(callback, "__doc__", None)
        wrapped.__signature__ = _inspect.Signature(parameters=[
            _inspect.Parameter("self", _inspect.Parameter.POSITIONAL_OR_KEYWORD),
            _inspect.Parameter("context", _inspect.Parameter.POSITIONAL_OR_KEYWORD),
        ])
        wrapped._sf_wrapped_runtime_callback = True
        wrapped._sf_wrapped_source = callback
    except Exception:
        pass
    return wrapped


def _sf_runtime_translate(text: object) -> str:
    if not isinstance(text, str):
        return str(text or '')
    fn = (_NAMESPACE or {}).get('_t')
    if callable(fn):
        try:
            return str(fn(text))
        except Exception:
            pass
    return text


def _sf_runtime_compact_exception(ex: Exception) -> str:
    text = str(ex or '').strip() or ex.__class__.__name__
    text = text.replace('\r', ' ').replace('\n', ' | ')
    return text[:220]


def _sf_runtime_append_activity(context, title: str, detail: str = '', icon: str = 'ERROR'):
    fn = (_NAMESPACE or {}).get('_sf_append_activity')
    if callable(fn):
        try:
            fn(context, _sf_runtime_translate(title), detail, icon)
        except Exception:
            pass


def _sf_runtime_draw_error(layout, title: str, detail: str = ''):
    if layout is None:
        return
    try:
        box = layout.box()
        box.alert = True
        box.label(text=_sf_runtime_translate(title), icon='ERROR')
        for line in _textwrap.wrap(str(detail or '').strip(), width=84)[:4]:
            box.label(text=line, icon='BLANK1')
    except Exception:
        pass


def _sf_runtime_call_positional_compat(func, args):
    try:
        sig = _inspect.signature(func)
    except Exception:
        return func(*args)
    params = list(sig.parameters.values())
    if any(p.kind == _inspect.Parameter.VAR_POSITIONAL for p in params):
        return func(*args)
    positional_count = sum(
        1
        for p in params
        if p.kind in (_inspect.Parameter.POSITIONAL_ONLY, _inspect.Parameter.POSITIONAL_OR_KEYWORD)
    )
    return func(*args[:positional_count])



def _sf_runtime_wrap_method(cls, method_name: str, mode: str):
    raw_attr = getattr(cls, '__dict__', {}).get(method_name)
    if raw_attr is None:
        return

    is_classmethod = isinstance(raw_attr, classmethod)
    is_staticmethod = isinstance(raw_attr, staticmethod)
    original = raw_attr.__func__ if (is_classmethod or is_staticmethod) else raw_attr
    if not callable(original) or getattr(original, '_sf_runtime_guard', False):
        return

    def _finalize_wrapped(func):
        try:
            func.__name__ = getattr(original, '__name__', method_name)
            func.__qualname__ = getattr(original, '__qualname__', func.__name__)
            func.__module__ = getattr(original, '__module__', __name__)
            func.__doc__ = getattr(original, '__doc__', None)
            func._sf_runtime_guard = True
            func._sf_runtime_source = original
        except Exception:
            pass
        if is_classmethod:
            return classmethod(func)
        if is_staticmethod:
            return staticmethod(func)
        return func

    if mode == 'POLL':
        def wrapped(owner, context):
            try:
                return bool(_sf_runtime_call_positional_compat(original, (owner, context)))
            except Exception:
                return False
    elif mode == 'CHECK':
        def wrapped(self, context):
            try:
                return bool(original(self, context))
            except Exception:
                return False
    elif mode == 'DRAW':
        if method_name == 'draw_filter':
            def wrapped(self, context, layout):
                try:
                    return original(self, context, layout)
                except Exception as ex:
                    detail = _sf_runtime_compact_exception(ex)
                    _sf_runtime_append_activity(context, 'Recovered from an internal UI error', f"{getattr(cls, 'bl_label', cls.__name__)} | {detail}", 'ERROR')
                    _sf_runtime_draw_error(layout, 'Smart File recovered from an internal UI error', detail)
                    return None
        else:
            def wrapped(self, context):
                try:
                    return original(self, context)
                except Exception as ex:
                    detail = _sf_runtime_compact_exception(ex)
                    _sf_runtime_append_activity(context, 'Recovered from an internal UI error', f"{getattr(cls, 'bl_label', cls.__name__)} | {detail}", 'ERROR')
                    _sf_runtime_draw_error(
                        getattr(self, 'layout', None),
                        'Smart File recovered from an internal UI error',
                        detail,
                    )
                    return None
    elif mode == 'DRAW_ITEM':
        def wrapped(self, context, layout, data, item, icon, active_data, active_propname, index=0, flt_flag=0):
            try:
                return _sf_runtime_call_positional_compat(
                    original,
                    (self, context, layout, data, item, icon, active_data, active_propname, index, flt_flag),
                )
            except Exception as ex:
                detail = _sf_runtime_compact_exception(ex)
                _sf_runtime_append_activity(context, 'Recovered from an internal list drawing error', f"{getattr(cls, 'bl_label', cls.__name__)} | {detail}", 'ERROR')
                _sf_runtime_draw_error(layout, 'Smart File recovered from an internal UI error', detail)
                return None
    elif mode == 'DESCRIPTION':
        def wrapped(owner, context, properties):
            try:
                return _sf_runtime_call_positional_compat(original, (owner, context, properties))
            except Exception:
                return getattr(cls, 'bl_description', '') or getattr(cls, 'bl_label', '') or cls.__name__
    else:
        if method_name == 'invoke':
            def wrapped(self, context, event):
                try:
                    return original(self, context, event)
                except Exception as ex:
                    detail = _sf_runtime_compact_exception(ex)
                    label = getattr(cls, 'bl_label', '') or cls.__name__
                    _sf_runtime_append_activity(context, 'Recovered from an internal tool error', f"{label} | {detail}", 'ERROR')
                    try:
                        self.report({'ERROR'}, f"{_sf_runtime_translate(label)}: {detail}")
                    except Exception:
                        pass
                    return {'CANCELLED'}
        else:
            def wrapped(self, context):
                try:
                    return original(self, context)
                except Exception as ex:
                    detail = _sf_runtime_compact_exception(ex)
                    label = getattr(cls, 'bl_label', '') or cls.__name__
                    _sf_runtime_append_activity(context, 'Recovered from an internal tool error', f"{label} | {detail}", 'ERROR')
                    try:
                        self.report({'ERROR'}, f"{_sf_runtime_translate(label)}: {detail}")
                    except Exception:
                        pass
                    return {'CANCELLED'}

    setattr(cls, method_name, _finalize_wrapped(wrapped))


def _sf_apply_runtime_safety_wrappers(class_iterable=None):
    if _bpy is None or not _SF_ENABLE_RUNTIME_SAFETY_WRAPPERS:
        return
    iterable = list(class_iterable or (_NAMESPACE or {}).values())
    operator_base = getattr(_bpy.types, 'Operator', None)
    panel_base = getattr(_bpy.types, 'Panel', None)
    menu_base = getattr(_bpy.types, 'Menu', None)
    header_base = getattr(_bpy.types, 'Header', None)
    uilist_base = getattr(_bpy.types, 'UIList', None)

    for obj in iterable:
        if not isinstance(obj, type):
            continue
        try:
            if operator_base is not None and issubclass(obj, operator_base):
                _sf_runtime_wrap_method(obj, 'poll', 'POLL')
                _sf_runtime_wrap_method(obj, 'check', 'CHECK')
                _sf_runtime_wrap_method(obj, 'description', 'DESCRIPTION')
                _sf_runtime_wrap_method(obj, 'invoke', 'EXECUTE')
                _sf_runtime_wrap_method(obj, 'execute', 'EXECUTE')
                _sf_runtime_wrap_method(obj, 'draw', 'DRAW')
                continue
            if uilist_base is not None and issubclass(obj, uilist_base):
                _sf_runtime_wrap_method(obj, 'draw_item', 'DRAW_ITEM')
                _sf_runtime_wrap_method(obj, 'draw_filter', 'DRAW')
                continue
            if any(base is not None and issubclass(obj, base) for base in (panel_base, menu_base, header_base)):
                _sf_runtime_wrap_method(obj, 'poll', 'POLL')
                _sf_runtime_wrap_method(obj, 'draw', 'DRAW')
        except Exception:
            continue


def _sf_code_positional_count(func):
    code = getattr(func, "__code__", None)
    if code is None:
        return None
    try:
        return int(getattr(code, "co_argcount", 0) or 0)
    except Exception:
        return None


def _sf_restore_runtime_method_if_needed(cls, method_name: str, *, min_args=None, max_args=None):
    raw_attr = getattr(cls, '__dict__', {}).get(method_name)
    if raw_attr is None:
        return

    is_classmethod = isinstance(raw_attr, classmethod)
    is_staticmethod = isinstance(raw_attr, staticmethod)
    current = raw_attr.__func__ if (is_classmethod or is_staticmethod) else raw_attr
    original = getattr(current, '_sf_runtime_source', None)
    if original is None:
        return

    argc = _sf_code_positional_count(current)
    if argc is None:
        return
    if min_args is not None and argc < min_args:
        setattr(cls, method_name, raw_attr.__class__(original) if (is_classmethod or is_staticmethod) else original)
        return
    if max_args is not None and argc > max_args:
        setattr(cls, method_name, raw_attr.__class__(original) if (is_classmethod or is_staticmethod) else original)


def _sf_restore_registration_compatible_methods(class_iterable=None):
    if _bpy is None:
        return

    iterable = list(class_iterable or (_NAMESPACE or {}).values())
    operator_base = getattr(_bpy.types, 'Operator', None)
    panel_base = getattr(_bpy.types, 'Panel', None)
    menu_base = getattr(_bpy.types, 'Menu', None)
    header_base = getattr(_bpy.types, 'Header', None)
    uilist_base = getattr(_bpy.types, 'UIList', None)

    for obj in iterable:
        if not isinstance(obj, type):
            continue
        try:
            if operator_base is not None and issubclass(obj, operator_base):
                _sf_restore_runtime_method_if_needed(obj, 'poll', min_args=2, max_args=3)
                _sf_restore_runtime_method_if_needed(obj, 'check', min_args=2, max_args=3)
                _sf_restore_runtime_method_if_needed(obj, 'description', min_args=3, max_args=4)
                _sf_restore_runtime_method_if_needed(obj, 'invoke', min_args=3, max_args=4)
                _sf_restore_runtime_method_if_needed(obj, 'execute', min_args=2, max_args=3)
                _sf_restore_runtime_method_if_needed(obj, 'draw', min_args=2, max_args=4)
                continue
            if uilist_base is not None and issubclass(obj, uilist_base):
                _sf_restore_runtime_method_if_needed(obj, 'draw_item', min_args=7, max_args=10)
                _sf_restore_runtime_method_if_needed(obj, 'draw_filter', min_args=3, max_args=4)
                continue
            if any(base is not None and issubclass(obj, base) for base in (panel_base, menu_base, header_base)):
                _sf_restore_runtime_method_if_needed(obj, 'poll', min_args=2, max_args=3)
                _sf_restore_runtime_method_if_needed(obj, 'draw', min_args=2, max_args=4)
        except Exception:
            continue



def _sf_update_callback_positional_count(callback):
    try:
        signature = _inspect.signature(callback)
    except Exception:
        return None
    count = 0
    for parameter in signature.parameters.values():
        if parameter.kind in (parameter.POSITIONAL_ONLY, parameter.POSITIONAL_OR_KEYWORD):
            count += 1
        elif parameter.kind == parameter.VAR_POSITIONAL:
            return 2
    return count


def _sf_make_update_callback_compatible(callback):
    """Return an update callback that Blender 5.1 always sees as (self, context).

    Some bundled legacy tools use zero-argument or one-argument update callbacks.
    Blender 5.1 validates the Python callable signature while creating RNA
    properties and prints ``update keyword: expected a function taking 2
    arguments`` before registration can continue.  A small two-argument wrapper
    keeps normal callbacks working and safely adapts legacy callbacks.
    """
    if not callable(callback):
        return callback
    if getattr(callback, "_sfs_update_callback_compatible", False):
        return callback
    argc = _sf_update_callback_positional_count(callback)

    def update_callback(self, context):
        # Prefer Blender's native update signature.  Fall back only when the
        # original callback clearly used an older zero/one-argument convention.
        if argc is None or argc >= 2:
            try:
                return callback(self, context)
            except TypeError:
                pass
        if argc == 1:
            try:
                return callback(self)
            except TypeError:
                pass
        if argc == 0:
            try:
                return callback()
            except TypeError:
                pass
        # Last-resort compatibility for callables whose signature could not be
        # inspected accurately, such as partials or C-backed proxies.
        for call_args in ((self, context), (self,), ()):  # noqa: B007 - explicit fallback order
            try:
                return callback(*call_args)
            except TypeError:
                continue
        return None

    try:
        update_callback.__name__ = getattr(callback, "__name__", "update_callback")
        update_callback.__qualname__ = getattr(callback, "__qualname__", update_callback.__name__)
        update_callback.__module__ = getattr(callback, "__module__", __name__)
        update_callback.__doc__ = getattr(callback, "__doc__", None)
        update_callback._sfs_update_callback_compatible = True
        update_callback._sfs_update_callback_source = callback
    except Exception:
        pass
    return update_callback



def _sf_wrap_prop_factory(factory_name: str):
    if _bpy is None:
        return None
    original = getattr(_bpy.props, factory_name, None)
    if original is None:
        return None
    # Avoid nesting Smart File wrappers when bootstrap and lazy tool loading are
    # both active.  Nested wrappers can expose the inner legacy callback to
    # Blender's RNA validator before adaptation.
    original = getattr(original, "_sfs_original_prop_factory", original)

    def wrapper(*args, **kwargs):
        if args:
            args = tuple(_sf_clean_ui_text(arg) if isinstance(arg, str) else arg for arg in args)
        for key in ("name", "description", "translation_context", "text_ctxt"):
            if key in kwargs and isinstance(kwargs[key], str):
                kwargs[key] = _sf_clean_ui_text(kwargs[key])
        name_en = str(kwargs.get("name", "") or "")
        desc_en = str(kwargs.get("description", "") or "")
        if not desc_en:
            desc_en, desc_jp = _sf_property_tooltip_pair(name_en, factory_name)
            kwargs["description"] = desc_en
            _sf_register_pending_translation(desc_en, desc_jp)
        else:
            desc_jp = None
            pair = _sf_split_bilingual(desc_en)
            if pair:
                kwargs["description"] = pair[0]
                desc_en = pair[0]
                desc_jp = pair[1]
            elif _sf_has_japanese(desc_en):
                desc_jp = desc_en
            if desc_jp and desc_jp != desc_en:
                _sf_register_pending_translation(desc_en, desc_jp)
        if name_en:
            name_jp = _sf_guess_label_japanese(name_en)
            if name_jp and name_jp != name_en:
                _sf_register_pending_translation(name_en, name_jp)
        previous_update = kwargs.get("update") if callable(kwargs.get("update")) else None
        if previous_update is not None:
            previous_update = _sf_make_update_callback_compatible(previous_update)
        if factory_name in {
            "BoolProperty", "BoolVectorProperty", "EnumProperty",
            "FloatProperty", "FloatVectorProperty", "IntProperty",
            "IntVectorProperty", "StringProperty",
        }:
            def _make_persisting_update(previous):
                # Blender 5.1 validates an exact two-argument update signature.
                def _persisting_update(self, context):
                    try:
                        if callable(previous):
                            previous(self, context)
                    finally:
                        # Command/modal properties are not reusable N-panel state.
                        try:
                            is_operator = isinstance(self, _bpy.types.Operator)
                        except Exception:
                            is_operator = False
                        if not is_operator:
                            try:
                                from . import settings as _sf_settings
                                _sf_settings.schedule_save(
                                    context or getattr(_bpy, "context", None)
                                )
                            except Exception:
                                pass
                return _persisting_update
            kwargs["update"] = _make_persisting_update(previous_update)
        elif previous_update is not None:
            kwargs["update"] = previous_update
        if factory_name == "EnumProperty":
            items = kwargs.get("items")
            if isinstance(items, (list, tuple)):
                kwargs["items"] = _sf_process_enum_items(items)
            elif callable(items):
                kwargs["items"] = _sf_wrap_enum_items_callback(items)
        # Blender 5.1 validates callback signatures during RNA registration.
        # Update callbacks above are exposed through a strict two-argument
        # compatibility wrapper; other callbacks are left unchanged.
        return original(*args, **kwargs)

    wrapper.__name__ = getattr(original, "__name__", f"wrapped_{factory_name}")
    wrapper.__doc__ = getattr(original, "__doc__", None)
    try:
        wrapper._sfs_original_prop_factory = original
        wrapper._sfs_prop_factory_wrapper = True
    except Exception:
        pass
    return wrapper


def _sf_preprocess_bilingual_token_strings(text: str) -> str:
    try:
        tokens = []
        for token in _tokenize.generate_tokens(_io.StringIO(text).readline):
            if token.type == _tokenize.STRING:
                try:
                    value = _ast.literal_eval(token.string)
                except Exception:
                    value = None
                if isinstance(value, str):
                    # This pass runs over complete bundled-tool source files,
                    # so non-UI literals (newlines, separators, file content,
                    # regular expressions, commands, and paths) must remain
                    # byte-for-byte equivalent.  Only rewrite literals that
                    # are actually bilingual UI pairs.
                    if _sf_split_bilingual(value):
                        cleaned = _sf_clean_ui_text(value)
                        if cleaned != value:
                            token = token._replace(string=repr(cleaned))
            tokens.append(token)
        return _tokenize.untokenize(tokens)
    except Exception:
        return text


def _sf_source_index_map(text: str):
    lines = text.splitlines(keepends=True)
    offsets = []
    total = 0
    for line in lines:
        offsets.append(total)
        total += len(line)
    if not offsets:
        offsets = [0]
    return lines, offsets


def _sf_source_offset(lines, offsets, lineno: int, col: int) -> int:
    line_index = max(lineno - 1, 0)
    if not lines:
        return col
    try:
        line = lines[line_index]
    except Exception:
        line = lines[-1]
        line_index = len(lines) - 1
    byte_slice = line.encode("utf-8")[: max(col, 0)]
    char_col = len(byte_slice.decode("utf-8", errors="ignore"))
    return offsets[line_index] + char_col


def _sf_preprocess_feature_source(text: str) -> str:
    text = _sf_preprocess_bilingual_token_strings(text)
    try:
        tree = _ast.parse(text)
    except Exception:
        return text
    lines, offsets = _sf_source_index_map(text)
    replacements = []

    def add_replacement(node, new_value: str):
        if not isinstance(new_value, str):
            return
        start = _sf_source_offset(lines, offsets, node.lineno, node.col_offset)
        end = _sf_source_offset(lines, offsets, node.end_lineno, node.end_col_offset)
        old_segment = text[start:end]
        new_segment = repr(new_value)
        if old_segment != new_segment:
            replacements.append((start, end, new_segment))

    ui_keyword_names = {"text", "name", "description", "title"}
    ui_assign_names = {"bl_label", "bl_description", "bl_category"}
    ui_func_names = {"_t", "_tt", "_tr", "iface", "tip", "data"}

    for node in _ast.walk(tree):
        if isinstance(node, _ast.Call):
            fn_name = None
            if isinstance(node.func, _ast.Name):
                fn_name = node.func.id
            elif isinstance(node.func, _ast.Attribute):
                fn_name = node.func.attr
            if fn_name in ui_func_names and node.args:
                arg0 = node.args[0]
                if isinstance(arg0, _ast.Constant) and isinstance(arg0.value, str):
                    role = "description" if fn_name in {"tip", "_tt"} else "label"
                    new_value = _sf_normalize_msgid(arg0.value, role=role)
                    add_replacement(arg0, new_value)
            if fn_name == "report" and len(node.args) >= 2:
                msg_node = node.args[1]
                if isinstance(msg_node, _ast.Constant) and isinstance(msg_node.value, str):
                    new_value = _sf_normalize_msgid(msg_node.value, role="report")
                    add_replacement(msg_node, new_value)
            for kw in node.keywords:
                if kw.arg not in ui_keyword_names:
                    continue
                if isinstance(kw.value, _ast.Constant) and isinstance(kw.value.value, str):
                    role = "description" if kw.arg == "description" else "label"
                    new_value = _sf_normalize_msgid(kw.value.value, role=role)
                    add_replacement(kw.value, new_value)
        elif isinstance(node, _ast.ClassDef):
            for stmt in node.body:
                target_name = None
                value_node = None
                if isinstance(stmt, _ast.Assign) and stmt.targets and isinstance(stmt.targets[0], _ast.Name):
                    target_name = stmt.targets[0].id
                    value_node = stmt.value
                elif isinstance(stmt, _ast.AnnAssign) and isinstance(stmt.target, _ast.Name):
                    target_name = stmt.target.id
                    value_node = stmt.value
                if target_name not in ui_assign_names or not isinstance(value_node, _ast.Constant) or not isinstance(value_node.value, str):
                    continue
                role = "description" if target_name == "bl_description" else "label"
                new_value = _sf_normalize_msgid(value_node.value, role=role)
                add_replacement(value_node, new_value)

    if not replacements:
        return text
    pieces = []
    cursor = 0
    for start, end, new_segment in sorted(replacements, key=lambda item: item[0]):
        pieces.append(text[cursor:start])
        pieces.append(new_segment)
        cursor = end
    pieces.append(text[cursor:])
    return ''.join(pieces)




# --- Toolset Smart File runtime draw i18n wrappers v70 START ---
def _sf_i18n_runtime_text_context():
    class _NullContext:
        def __enter__(self):
            return self
        def __exit__(self, exc_type, exc, tb):
            return False
    return _NullContext()


def _sf_i18n_runtime_ui_text(value: object, *, kind: str = 'iface') -> object:
    if not isinstance(value, str):
        return value
    try:
        from .ui_language_runtime import ui_text
        return ui_text(value, kind=kind)
    except Exception:
        return value


def _sf_wrap_text_localized_method(cls, method_name: str, mode: str) -> None:
    raw_attr = getattr(cls, '__dict__', {}).get(method_name)
    if raw_attr is None:
        return
    is_classmethod = isinstance(raw_attr, classmethod)
    is_staticmethod = isinstance(raw_attr, staticmethod)
    original = raw_attr.__func__ if (is_classmethod or is_staticmethod) else raw_attr
    if not callable(original) or getattr(original, '_sfs_i18n_text_draw_wrapped', False):
        return

    if mode == 'DESCRIPTION':
        def wrapped(owner, context, properties):
            result = _sf_runtime_call_positional_compat(original, (owner, context, properties))
            return _sf_i18n_runtime_ui_text(result, kind='tip')
    elif method_name == 'draw_item':
        def wrapped(self, context, layout, data, item, icon, active_data, active_propname, index=0, flt_flag=0):
            with _sf_i18n_runtime_text_context():
                return _sf_runtime_call_positional_compat(
                    original,
                    (self, context, layout, data, item, icon, active_data, active_propname, index, flt_flag),
                )
    elif method_name == 'draw_filter':
        def wrapped(self, context, layout):
            with _sf_i18n_runtime_text_context():
                return _sf_runtime_call_positional_compat(original, (self, context, layout))
    else:
        def wrapped(self, context):
            with _sf_i18n_runtime_text_context():
                return _sf_runtime_call_positional_compat(original, (self, context))

    try:
        wrapped.__name__ = getattr(original, '__name__', method_name)
        wrapped.__qualname__ = getattr(original, '__qualname__', wrapped.__name__)
        wrapped.__module__ = getattr(original, '__module__', __name__)
        wrapped.__doc__ = getattr(original, '__doc__', None)
        wrapped._sfs_i18n_text_draw_wrapped = True
        wrapped._sfs_i18n_text_draw_source = original
    except Exception:
        pass
    try:
        if is_classmethod:
            setattr(cls, method_name, classmethod(wrapped))
        elif is_staticmethod:
            setattr(cls, method_name, staticmethod(wrapped))
        else:
            setattr(cls, method_name, wrapped)
    except Exception:
        pass


def _sf_apply_runtime_text_localization_wrappers(class_iterable=None) -> None:
    # Keep class metadata translation collection, but do not wrap Blender draw,
    # poll, description, UIList, Menu, Header, or UILayout methods. Mutating
    # registered or soon-to-be-registered draw callbacks is unstable in Blender
    # 5.1 panel drawing and can surface as python313.dll access violations.
    del class_iterable
    return None
# --- Toolset Smart File runtime draw i18n wrappers v70 END ---

def _sf_collect_runtime_class_translations(class_iterable=None):
    iterable = list(class_iterable if class_iterable is not None else (_NAMESPACE or {}).values())
    for obj in iterable:
        if not isinstance(obj, type) or not hasattr(obj, "bl_rna"):
            continue
        label = str(getattr(obj, "bl_label", "") or "").strip()
        desc = str(getattr(obj, "bl_description", "") or "").strip()
        category = str(getattr(obj, "bl_category", "") or "").strip()
        if label:
            clean_label = str(_sf_clean_ui_text(label))
            if clean_label != label:
                try:
                    setattr(obj, "bl_label", clean_label)
                except Exception:
                    pass
                label = clean_label
            label_jp = _sf_guess_label_japanese(label)
            if label_jp and label_jp != label:
                _sf_register_pending_translation(label, label_jp)
        if desc:
            clean_desc = str(_sf_clean_ui_text(desc))
            if clean_desc != desc:
                try:
                    setattr(obj, "bl_description", clean_desc)
                except Exception:
                    pass
                desc = clean_desc
            desc_jp = _sf_guess_label_japanese(desc)
            if desc_jp and desc_jp != desc:
                _sf_register_pending_translation(desc, desc_jp)
        if category:
            clean_category = str(_sf_clean_ui_text(category))
            if clean_category != category:
                try:
                    setattr(obj, "bl_category", clean_category)
                except Exception:
                    pass
                category = clean_category
            category_jp = _sf_guess_label_japanese(category)
            if category_jp and category_jp != category:
                _sf_register_pending_translation(category, category_jp)


    try:
        _sf_apply_runtime_text_localization_wrappers(iterable)
    except Exception:
        pass


def _sf_flush_pending_translations():
    pending = _SF_PENDING_TRANSLATIONS.get("ja_JP", {})
    if not pending:
        return
    td = (_NAMESPACE or {}).get("translation_dict")
    if isinstance(td, dict):
        td.setdefault("ja_JP", {}).update(pending)
    hist = (_NAMESPACE or {}).get("_sfs_hist_i18n")
    if hist is not None:
        try:
            hist.TRANSLATIONS.setdefault("ja_JP", {}).update(pending)
        except Exception:
            pass
    # Refresh Blender's translation registry after late integrated sub-tool
    # translations are merged.  This is text-only and does not modify Blender UI settings.
    try:
        if _bpy is not None and isinstance(td, dict):
            owner = str(((_NAMESPACE or {}).get('__name__')) or (__package__ or 'smart_file_suite'))
            translations = getattr(getattr(_bpy, 'app', None), 'translations', None)
            if translations is not None:
                try:
                    translations.unregister(owner)
                except Exception:
                    pass
                try:
                    translations.register(owner, td)
                except Exception:
                    pass
    except Exception:
        pass




def _sf_collect_source_keyword_translations():
    pkg_dir = _PKG_DIR
    if pkg_dir is None:
        return
    keyword_names = {"text", "name", "description", "bl_label", "bl_description", "bl_category", "title"}
    try:
        py_paths = sorted(pkg_dir.rglob("*.py"))
    except Exception:
        py_paths = []
    for path in py_paths:
        if path.name.endswith('.pyc'):
            continue
        # The detailed help catalog is intentionally lazy. Do not read or parse
        # it during startup/source translation collection; it is imported only
        # when a Help button is clicked.
        if path.name == 'help.py':
            continue
        try:
            source = path.read_text(encoding="utf-8")
            tree = _ast.parse(source)
        except Exception:
            continue
        for node in _ast.walk(tree):
            if isinstance(node, _ast.Dict):
                for key_node, value_node in zip(node.keys, node.values):
                    src = None
                    dst = None
                    if isinstance(key_node, _ast.Tuple) and len(key_node.elts) >= 2:
                        k = key_node.elts[-1]
                        if isinstance(k, _ast.Constant) and isinstance(k.value, str):
                            src = k.value
                    elif isinstance(key_node, _ast.Constant) and isinstance(key_node.value, str):
                        src = key_node.value
                    if isinstance(value_node, _ast.Constant) and isinstance(value_node.value, str):
                        dst = value_node.value
                    if isinstance(src, str) and isinstance(dst, str) and _sf_has_japanese(dst) and not _sf_has_japanese(src):
                        _sf_register_pending_translation(src, dst)
            elif isinstance(node, _ast.Tuple) and len(node.elts) == 2:
                a, b = node.elts
                if isinstance(a, _ast.Constant) and isinstance(a.value, str) and isinstance(b, _ast.Constant) and isinstance(b.value, str):
                    if _sf_has_japanese(b.value) and not _sf_has_japanese(a.value):
                        _sf_register_pending_translation(a.value, b.value)
            elif isinstance(node, _ast.Call):
                fn_name = None
                if isinstance(node.func, _ast.Name):
                    fn_name = node.func.id
                elif isinstance(node.func, _ast.Attribute):
                    fn_name = node.func.attr
                for kw in node.keywords:
                    if kw.arg not in keyword_names:
                        continue
                    value = kw.value
                    if isinstance(value, _ast.Constant) and isinstance(value.value, str):
                        cleaned = str(_sf_normalize_msgid(value.value, role="description" if kw.arg == "description" else "label")).strip()
                        if not cleaned:
                            continue
                        jp = _sf_guess_label_japanese(cleaned)
                        if jp and jp != cleaned:
                            _sf_register_pending_translation(cleaned, jp)
            elif isinstance(node, _ast.ClassDef):
                for stmt in node.body:
                    target_name = None
                    value_node = None
                    if isinstance(stmt, _ast.Assign) and stmt.targets and isinstance(stmt.targets[0], _ast.Name):
                        target_name = stmt.targets[0].id
                        value_node = stmt.value
                    elif isinstance(stmt, _ast.AnnAssign) and isinstance(stmt.target, _ast.Name):
                        target_name = stmt.target.id
                        value_node = stmt.value
                    if target_name not in keyword_names or not isinstance(value_node, _ast.Constant) or not isinstance(value_node.value, str):
                        continue
                    cleaned = str(_sf_normalize_msgid(value_node.value, role="description" if target_name == "bl_description" else "label")).strip()
                    if not cleaned:
                        continue
                    jp = _sf_guess_label_japanese(cleaned)
                    if jp and jp != cleaned:
                        _sf_register_pending_translation(cleaned, jp)


_SF_ORIGINAL_PROP_FACTORIES = {}


def _sf_resolved_feature_files(pkg_dir: _Path | None = None):
    base = list(_FEATURE_FILES)
    if pkg_dir is None:
        return tuple(base)
    seen = set(base)
    extras = []
    for candidate in sorted(pkg_dir.glob("sf_*.py")):
        name = candidate.name
        if name == _Path(__file__).name:
            continue
        if name in seen:
            continue
        seen.add(name)
        extras.append(name)
    return tuple(base + extras)


def run_bootstrap(namespace: dict, package_file: str):
    global _PKG_DIR, _NAMESPACE, _SF_PENDING_TRANSLATIONS
    _PKG_DIR = _Path(package_file).resolve().parent
    _NAMESPACE = namespace
    _SF_PENDING_TRANSLATIONS = {"ja_JP": {}}
    _SF_DYNAMIC_FORWARD_TRANSLATIONS.clear()
    _SF_DYNAMIC_REVERSE_TRANSLATIONS.clear()

    _sf_collect_source_keyword_translations()

    namespace['_sf_collect_runtime_class_translations'] = _sf_collect_runtime_class_translations
    namespace['_sf_flush_pending_translations'] = _sf_flush_pending_translations
    namespace['_sf_restore_registration_compatible_methods'] = _sf_restore_registration_compatible_methods

    # Property factories are never replaced process-wide. Property labels and
    # descriptions are normalized in source before execution.
    _SF_ORIGINAL_PROP_FACTORIES.clear()
    for _feature_file in _sf_resolved_feature_files(_PKG_DIR):
        _feature_path = _PKG_DIR / _feature_file
        with _feature_path.open("r", encoding="utf-8") as _fh:
            _source = _fh.read()
        _source = _sf_preprocess_feature_source(_source)
        exec(compile(_source, str(_feature_path), "exec", dont_inherit=True), namespace, namespace)

    try:
        _sf_collect_runtime_class_translations(namespace.get("classes"))
    except Exception:
        pass

    try:
        _sf_restore_registration_compatible_methods(namespace.get("classes"))
    except Exception:
        pass

    try:
        _bl_info = namespace.get("bl_info")
        if isinstance(_bl_info, dict):
            _name = str(_bl_info.get("name", "") or "").strip()
            _location = str(_bl_info.get("location", "") or "").strip()
            _description = str(_bl_info.get("description", "") or "").strip()
            if _name:
                _name_jp = _sf_guess_label_japanese(_name)
                if _name_jp and _name_jp != _name:
                    _sf_register_pending_translation(_name, _name_jp)
            if _location:
                _location_jp = _sf_guess_label_japanese(_location)
                if _location_jp and _location_jp != _location:
                    _sf_register_pending_translation(_location, _location_jp)
            if _description:
                _desc_jp = _sf_guess_label_japanese(_description)
                if _desc_jp and _desc_jp != _description:
                    _sf_register_pending_translation(_description, _desc_jp)
    except Exception:
        pass

    _sf_flush_pending_translations()


__all__ = ["run_bootstrap"]
