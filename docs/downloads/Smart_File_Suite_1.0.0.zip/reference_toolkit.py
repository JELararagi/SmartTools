# -----------------------------------------------------------------------------
#  Reference Toolkit / Export / Normalize / Extension Swap
# -----------------------------------------------------------------------------

from .ui_language_runtime import ui_text as _ui_text
import os


def _sf_ref_selected_root_ids(context, *, include_user_collections: bool = True) -> list[object]:
    roots = []
    seen = set()

    def add(id_):
        if id_ is None:
            return
        try:
            token = int(id_.as_pointer())
        except Exception:
            token = id(id_)
        if token in seen:
            return
        seen.add(token)
        roots.append(id_)

    selected = list(getattr(context, 'selected_objects', []) or [])
    active = getattr(context, 'active_object', None)
    if not selected and active is not None:
        selected = [active]

    for ob in selected:
        add(ob)
        if include_user_collections:
            try:
                for coll in getattr(ob, 'users_collection', []) or []:
                    add(coll)
            except Exception:
                pass

    if not roots:
        try:
            add(getattr(context, 'collection', None))
        except Exception:
            pass
    return roots



def _sf_ref_collect_scope_records(context, *, scope: str = 'CURRENT_FILE', include_libraries: bool = True, include_texts: bool = False, include_missing: bool = True) -> list[dict]:
    scope = str(scope or 'CURRENT_FILE').upper()
    if scope == 'SELECTED_HIERARCHY':
        roots = _sf_ref_selected_root_ids(context, include_user_collections=True)
        return _sf_ext_collect_from_root_ids(
            roots,
            include_libraries=include_libraries,
            include_texts=include_texts,
            include_missing=include_missing,
        )
    return _sf_ext_collect_current_file_records(
        include_libraries=include_libraries,
        include_texts=include_texts,
        include_missing=include_missing,
    )



def _sf_ref_rel_base_dir() -> str:
    return _norm_path(os.path.dirname(bpy.data.filepath or '')) if bpy.data.filepath else ''



def _sf_ref_abs_to_path_mode(abs_path: str, mode: str = 'ABSOLUTE') -> str:
    mode = str(mode or 'ABSOLUTE').upper()
    abs_path = _norm_path(abs_path or '')
    if not abs_path:
        return ''
    if mode == 'ABSOLUTE':
        return abs_path
    if mode == 'RELATIVE':
        base_dir = _sf_ref_rel_base_dir()
        if not base_dir:
            raise RuntimeError(_t('Save the current file before writing relative paths'))
        return bpy.path.relpath(abs_path, start=base_dir)
    return abs_path



def _sf_ref_preserve_path_style(old_path: str, abs_path: str) -> str:
    old_path = str(old_path or '')
    if old_path.startswith('//'):
        return _sf_ref_abs_to_path_mode(abs_path, 'RELATIVE')
    return _norm_path(abs_path)



def _sf_ref_export_seed_name(context) -> str:
    active = getattr(context, 'active_object', None)
    if active is not None:
        return _safe_filename(getattr(active, 'name', '') or 'selected_reference')
    if bpy.data.filepath:
        return _safe_filename(os.path.splitext(os.path.basename(bpy.data.filepath))[0] or 'selected_reference')
    return 'selected_reference'



def _sf_ref_sibling_replacement_candidates(rec: dict, new_ext: str) -> list[str]:
    base_dir = os.path.dirname(str(rec.get('abs_path') or rec.get('raw_path') or ''))
    base = os.path.basename(str(rec.get('abs_path') or rec.get('raw_path') or ''))
    if not base_dir or not base:
        return []
    stem = os.path.splitext(base)[0]
    out = []
    cand = _norm_path(os.path.join(base_dir, f"{stem}{new_ext}"))
    if os.path.exists(cand):
        out.append(cand)
    return out



def _sf_ref_dedup_paths(paths: list[str]) -> list[str]:
    out = []
    seen = set()
    for p in list(paths or []):
        p = _norm_path(p)
        key = p.lower()
        if not p or key in seen:
            continue
        seen.add(key)
        out.append(p)
    return out



def _sf_ref_normalized_ext(value: str) -> str:
    value = str(value or '').strip().lower()
    if not value:
        return ''
    return value if value.startswith('.') else f'.{value}'



def _sf_ref_target_token(id_block):
    try:
        if id_block is None:
            return ('NONE', '')
        ap = getattr(id_block, 'as_pointer', None)
        if callable(ap):
            ptr = int(ap())
            if ptr:
                return ('PTR', ptr)
    except Exception:
        pass
    try:
        return (type(id_block).__name__, getattr(id_block, 'name_full', '') or getattr(id_block, 'name', ''))
    except Exception:
        return (type(id_block).__name__, repr(id_block))



def _sf_ref_add_localize_candidate(id_block, out: list[object], seen: set, *, include_overrides: bool = False):
    if id_block is None:
        return
    try:
        if getattr(id_block, 'override_library', None) and (not include_overrides):
            return
    except Exception:
        pass
    try:
        linked = bool(getattr(id_block, 'library', None))
    except Exception:
        linked = False
    if not linked:
        return
    token = _sf_ref_target_token(id_block)
    if token in seen:
        return
    seen.add(token)
    out.append(id_block)



def _sf_ref_object_localize_dependencies(obj, out: list[object], seen: set, *, include_object_data: bool = True, include_materials: bool = True, include_actions: bool = True, include_node_groups: bool = True, include_user_collections: bool = False, include_overrides: bool = False, recurse_children: bool = False):
    stack = [obj] if obj is not None else []
    visited = set()
    while stack:
        ob = stack.pop()
        if ob is None:
            continue
        token = _sf_ref_target_token(ob)
        if token in visited:
            continue
        visited.add(token)
        _sf_ref_add_localize_candidate(ob, out, seen, include_overrides=include_overrides)
        if include_object_data:
            data = getattr(ob, 'data', None)
            _sf_ref_add_localize_candidate(data, out, seen, include_overrides=include_overrides)
            try:
                shape_keys = getattr(data, 'shape_keys', None)
            except Exception:
                shape_keys = None
            _sf_ref_add_localize_candidate(shape_keys, out, seen, include_overrides=include_overrides)
            try:
                for psys in getattr(ob, 'particle_systems', []) or []:
                    _sf_ref_add_localize_candidate(getattr(psys, 'settings', None), out, seen, include_overrides=include_overrides)
            except Exception:
                pass
        if include_materials:
            try:
                for slot in getattr(ob, 'material_slots', []) or []:
                    mat = getattr(slot, 'material', None)
                    _sf_ref_add_localize_candidate(mat, out, seen, include_overrides=include_overrides)
                    if include_node_groups and mat is not None:
                        _sf_ref_add_localize_candidate(getattr(mat, 'node_tree', None), out, seen, include_overrides=include_overrides)
            except Exception:
                pass
            try:
                for mat in getattr(getattr(ob, 'data', None), 'materials', []) or []:
                    _sf_ref_add_localize_candidate(mat, out, seen, include_overrides=include_overrides)
                    if include_node_groups and mat is not None:
                        _sf_ref_add_localize_candidate(getattr(mat, 'node_tree', None), out, seen, include_overrides=include_overrides)
            except Exception:
                pass
        if include_actions:
            for host in (ob, getattr(ob, 'data', None), getattr(getattr(ob, 'data', None), 'shape_keys', None)):
                try:
                    anim = getattr(host, 'animation_data', None)
                except Exception:
                    anim = None
                _sf_ref_add_localize_candidate(getattr(anim, 'action', None), out, seen, include_overrides=include_overrides)
        if include_node_groups:
            try:
                for mod in getattr(ob, 'modifiers', []) or []:
                    _sf_ref_add_localize_candidate(getattr(mod, 'node_group', None), out, seen, include_overrides=include_overrides)
            except Exception:
                pass
            try:
                geo_nodes = getattr(getattr(ob, 'data', None), 'node_tree', None)
            except Exception:
                geo_nodes = None
            _sf_ref_add_localize_candidate(geo_nodes, out, seen, include_overrides=include_overrides)
        try:
            inst_coll = getattr(ob, 'instance_collection', None)
        except Exception:
            inst_coll = None
        _sf_ref_add_localize_candidate(inst_coll, out, seen, include_overrides=include_overrides)
        if include_user_collections:
            try:
                for coll in getattr(ob, 'users_collection', []) or []:
                    _sf_ref_add_localize_candidate(coll, out, seen, include_overrides=include_overrides)
            except Exception:
                pass
        if recurse_children:
            try:
                for child in getattr(ob, 'children', []) or []:
                    stack.append(child)
            except Exception:
                pass



def _sf_ref_collection_localize_dependencies(coll, out: list[object], seen: set, *, include_object_data: bool = True, include_materials: bool = True, include_actions: bool = True, include_node_groups: bool = True, include_overrides: bool = False, recurse_children: bool = True):
    stack = [coll] if coll is not None else []
    visited = set()
    while stack:
        current = stack.pop()
        if current is None:
            continue
        token = _sf_ref_target_token(current)
        if token in visited:
            continue
        visited.add(token)
        _sf_ref_add_localize_candidate(current, out, seen, include_overrides=include_overrides)
        try:
            for ob in getattr(current, 'objects', []) or []:
                _sf_ref_object_localize_dependencies(
                    ob,
                    out,
                    seen,
                    include_object_data=include_object_data,
                    include_materials=include_materials,
                    include_actions=include_actions,
                    include_node_groups=include_node_groups,
                    include_user_collections=False,
                    include_overrides=include_overrides,
                    recurse_children=False,
                )
        except Exception:
            pass
        if recurse_children:
            try:
                for child in getattr(current, 'children', []) or []:
                    stack.append(child)
            except Exception:
                pass



def _sf_ref_current_file_localize_ids(*, include_object_data: bool = True, include_materials: bool = True, include_actions: bool = True, include_node_groups: bool = True, include_overrides: bool = False) -> list[object]:
    out = []
    seen = set()
    categories = ['collections', 'objects']
    if include_object_data:
        categories.extend(['meshes', 'curves', 'cameras', 'lights', 'armatures', 'fonts', 'lattices', 'metaballs', 'volumes', 'pointclouds', 'hair_curves', 'grease_pencils'])
    if include_materials:
        categories.extend(['materials', 'worlds'])
    if include_actions:
        categories.extend(['actions'])
    if include_node_groups:
        categories.extend(['node_groups'])
    for attr in categories:
        try:
            items = getattr(bpy.data, attr, []) or []
        except Exception:
            items = []
        for id_block in items:
            _sf_ref_add_localize_candidate(id_block, out, seen, include_overrides=include_overrides)
    return out



def _sf_ref_localize_scope_ids(context, *, scope: str = 'CURRENT_SCENE', include_object_data: bool = True, include_materials: bool = True, include_actions: bool = True, include_node_groups: bool = True, include_user_collections: bool = True, include_overrides: bool = False) -> list[object]:
    scope = str(scope or 'CURRENT_SCENE').upper()
    out = []
    seen = set()
    selected = list(getattr(context, 'selected_objects', []) or [])
    active = getattr(context, 'active_object', None)
    if not selected and active is not None:
        selected = [active]

    if scope == 'CURRENT_FILE':
        return _sf_ref_current_file_localize_ids(
            include_object_data=include_object_data,
            include_materials=include_materials,
            include_actions=include_actions,
            include_node_groups=include_node_groups,
            include_overrides=include_overrides,
        )
    if scope == 'CURRENT_SCENE':
        scene = getattr(context, 'scene', None)
        if scene is not None:
            _sf_ref_collection_localize_dependencies(
                getattr(scene, 'collection', None),
                out,
                seen,
                include_object_data=include_object_data,
                include_materials=include_materials,
                include_actions=include_actions,
                include_node_groups=include_node_groups,
                include_overrides=include_overrides,
                recurse_children=True,
            )
            if include_materials:
                _sf_ref_add_localize_candidate(getattr(scene, 'world', None), out, seen, include_overrides=include_overrides)
                try:
                    world = getattr(scene, 'world', None)
                    if world is not None and include_node_groups:
                        _sf_ref_add_localize_candidate(getattr(world, 'node_tree', None), out, seen, include_overrides=include_overrides)
                except Exception:
                    pass
        return out
    if scope in {'SELECTED_OBJECTS', 'SELECTED_HIERARCHY'}:
        if not selected:
            return []
        recurse = scope == 'SELECTED_HIERARCHY'
        for ob in selected:
            _sf_ref_object_localize_dependencies(
                ob,
                out,
                seen,
                include_object_data=include_object_data,
                include_materials=include_materials,
                include_actions=include_actions,
                include_node_groups=include_node_groups,
                include_user_collections=include_user_collections,
                include_overrides=include_overrides,
                recurse_children=recurse,
            )
        return out
    return out



def _sf_ref_make_local_id(id_block, *, clear_overrides: bool = False) -> tuple[bool, str]:
    if id_block is None:
        return False, 'missing target'
    try:
        if getattr(id_block, 'override_library', None) and (not clear_overrides):
            return False, 'override kept'
    except Exception:
        pass
    try:
        if not getattr(id_block, 'library', None):
            return False, 'already local'
    except Exception:
        return False, 'not link-capable'
    func = getattr(id_block, 'make_local', None)
    if not callable(func):
        return False, 'make_local unavailable'
    last_error = 'make_local unavailable'
    attempts = [
        {'clear_proxy': True, 'clear_liboverride': bool(clear_overrides), 'clear_asset_data': False},
        {'clear_proxy': True, 'clear_liboverride': bool(clear_overrides)},
        {'clear_liboverride': bool(clear_overrides)},
        {'clear_proxy': True},
        {},
    ]
    for kwargs in attempts:
        try:
            result = func(**kwargs) if kwargs else func()
            try:
                if result is not None and (not getattr(result, 'library', None)):
                    return True, 'localized'
            except Exception:
                return True, 'localized'
            try:
                if not getattr(id_block, 'library', None):
                    return True, 'localized'
            except Exception:
                return True, 'localized'
            return True, 'localized'
        except TypeError as ex:
            last_error = str(ex)
            continue
        except Exception as ex:
            last_error = str(ex)
            continue
    return False, last_error



class SF_OT_reference_toolkit_materialize_linked_references(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_ref_toolkit_materialize'
    bl_label = 'Materialize Linked References'
    bl_description = 'Convert linked objects, collections, data, actions, materials, and node groups into local datablocks so the current file can keep editing even when upstream libraries are unavailable. This is the Blender-side upper-layer equivalent of reference import'
    bl_options = {'UNDO'}

    scope: EnumProperty(
        name='Scope',
        items=[
            ('SELECTED_OBJECTS', 'Selected Objects', 'Make only the selected linked objects and their direct linked dependencies local.'),
            ('SELECTED_HIERARCHY', 'Selected Hierarchy', 'Make the selected objects, their children, and nearby linked dependencies local.'),
            ('CURRENT_SCENE', 'Current Scene', 'Scan the current scene collection tree and localize every linked item found there.'),
            ('CURRENT_FILE', 'Current File', 'Scan common datablock lists in the current file and localize every linked item found. Use this for full scene bind-style conversion.'),
        ],
        default='CURRENT_SCENE',
    )
    include_object_data: BoolProperty(name='Include object data', default=True, description='Also localize linked object data such as meshes, curves, cameras, lights, volumes, and other object-owned datablocks.')
    include_materials: BoolProperty(name='Include materials', default=True, description='Also localize linked materials and scene worlds so shading edits can continue inside the current file.')
    include_actions: BoolProperty(name='Include actions', default=True, description='Also localize linked animation actions attached to objects, data, and shape keys.')
    include_node_groups: BoolProperty(name='Include node groups', default=True, description='Also localize linked geometry nodes, material node trees, and related node groups found from the chosen scope.')
    include_user_collections: BoolProperty(name='Include user collections', default=True, description='When using selection scopes, also include linked collections that own the selected objects. This helps keep hierarchy context intact after localizing.')
    clear_overrides: BoolProperty(name='Convert overrides too', default=False, description='By default, library overrides are preserved and skipped. Enable this only when you intentionally want to break override relationships and make them fully local.')
    open_report: BoolProperty(name='Open report', default=True, options={'HIDDEN'})

    def execute(self, context):
        targets = _sf_ref_localize_scope_ids(
            context,
            scope=self.scope,
            include_object_data=bool(self.include_object_data),
            include_materials=bool(self.include_materials),
            include_actions=bool(self.include_actions),
            include_node_groups=bool(self.include_node_groups),
            include_user_collections=bool(self.include_user_collections),
            include_overrides=bool(self.clear_overrides),
        )
        if not targets:
            self.report({'INFO'}, _t('No linked targets were found for the chosen scope'))
            return {'FINISHED'}

        localized = []
        skipped = []
        failed = []
        report_lines = [
            f"Smart File | {_t('Materialize Linked References')} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            '',
            f"- {_t('Scope')}: {self.scope}",
            f"- {_t('Targets')}: {len(targets)}",
            f"- {_t('Include object data')}: {bool(self.include_object_data)}",
            f"- {_t('Include materials')}: {bool(self.include_materials)}",
            f"- {_t('Include actions')}: {bool(self.include_actions)}",
            f"- {_t('Include node groups')}: {bool(self.include_node_groups)}",
            f"- {_t('Convert overrides too')}: {bool(self.clear_overrides)}",
            '',
            'RESULTS',
        ]

        for id_block in targets:
            name = str(getattr(id_block, 'name_full', '') or getattr(id_block, 'name', '') or type(id_block).__name__)
            kind = type(id_block).__name__
            try:
                if getattr(id_block, 'override_library', None) and (not self.clear_overrides):
                    skipped.append({'kind': kind, 'name': name, 'reason': 'override kept'})
                    report_lines.append(_ui_text(f"- [SKIP] [{kind}] {name} | override kept", f'- [飛ばす] [{kind}] {name} | オーバーライドを残しました'))
                    continue
            except Exception:
                pass
            ok, reason = _sf_ref_make_local_id(id_block, clear_overrides=bool(self.clear_overrides))
            if ok:
                localized.append({'kind': kind, 'name': name, 'reason': reason})
                report_lines.append(f"- [OK] [{kind}] {name}")
            else:
                reason_text = str(reason or '')
                if reason_text in {'already local', 'override kept', 'not linked'}:
                    skipped.append({'kind': kind, 'name': name, 'reason': reason_text})
                    report_lines.append(f"- [SKIP] [{kind}] {name} | {reason_text}")
                else:
                    failed.append({'kind': kind, 'name': name, 'reason': reason_text})
                    report_lines.append(f"- [FAIL] [{kind}] {name} | {reason_text}")

        if failed:
            report_lines.extend(['', 'FAILED'])
            for row in failed:
                report_lines.append(f"- [{row.get('kind','')}] {row.get('name','')} | {row.get('reason','')}")
        if skipped:
            report_lines.extend(['', 'SKIPPED'])
            for row in skipped[:64]:
                report_lines.append(f"- [{row.get('kind','')}] {row.get('name','')} | {row.get('reason','')}")

        text_name = _sf_report_export(
            context,
            _t('Materialize Linked References'),
            report_lines,
            open_text=bool(self.open_report),
            activity_title=_t('Materialized linked references'),
        )
        level = {'WARNING'} if failed else {'INFO'}
        self.report(level, f"{_t('Localized')}: {len(localized)} | {_t('Skipped')}: {len(skipped)} | {_t('Failed')}: {len(failed)} | {text_name}")
        return {'FINISHED'}



class SF_OT_reference_toolkit_open(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = 'import_scene.sfs_reference_toolkit_open'
    bl_label = 'Open'
    bl_description = 'Open one compact board for auditing, relinking, path normalization, extension swapping, bundling, and exporting the current selection as a reusable reference library.'
    bl_options = {'INTERNAL'}

    popup_width: IntProperty(default=620, min=520, max=860, options={'HIDDEN'})

    def invoke(self, context, event):
        _sf_append_activity(context, _t('Opened Reference Toolkit'), _norm_path(bpy.data.filepath or ''), 'ASSET_MANAGER')
        return context.window_manager.invoke_popup(self, width=self.popup_width)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        payload = _sf_ext_popup_payload(include_libraries=True, include_texts=False)
        summary = dict(payload.get('summary') or {})

        _sf_draw_dialog_header(
            layout,
            'Reference Toolkit',
            'Audit, repair, normalize, swap, bundle, and export from one recovery-first workspace.',
            'ASSET_MANAGER',
        )

        overview = layout.box()
        _sf_draw_section_intro(
            overview,
            'Current File Snapshot',
            'Use this summary first so you can see whether the current file mainly needs repair, cleanup, or packaging.',
            'NONE',
        )
        _sf_draw_state_line(overview, 'External Records', 'READY' if int(summary.get('total_records', 0) or 0) else 'NOT SET', detail=str(int(summary.get('total_records', 0) or 0)))
        _sf_draw_state_line(overview, 'Missing', 'OK' if int(summary.get('missing_records', 0) or 0) == 0 else 'NEEDS ATTENTION', detail=str(int(summary.get('missing_records', 0) or 0)))
        _sf_draw_state_line(overview, 'Absolute', 'OK' if int(summary.get('absolute_records', 0) or 0) == 0 else 'REVIEW', detail=str(int(summary.get('absolute_records', 0) or 0)))
        _sf_draw_state_line(overview, 'Environment Variables', 'OK' if int(summary.get('env_records', 0) or 0) == 0 else 'REVIEW', detail=str(int(summary.get('env_records', 0) or 0)))
        _sf_draw_state_line(overview, 'Sequences', 'READY' if int(summary.get('sequence_records', 0) or 0) else 'NOT SET', detail=str(int(summary.get('sequence_records', 0) or 0)))

        quick = layout.box()
        _sf_draw_section_intro(
            quick,
            'Quick Actions',
            'Start with Audit or Relink for diagnostics, use Repath Roots when a server or drive moved, then use Normalize, Swap, Bundle, or Export once the direction is clear.',
            'CHECKMARK',
        )
        _sf_draw_action_block(
            quick,
            primary_actions=[
                ('import_scene.sfs_external_assets_audit', 'Audit', 'CHECKMARK', {}),
                ('import_scene.sfs_external_assets_relink_missing', 'Relink Missing', 'VIEWZOOM', {}),
                ('import_scene.sfs_root_repath_repath', 'Repath Roots', 'FILE_PARENT', {}),
                ('import_scene.sfs_reference_toolkit_normalize_external_paths', 'Normalize Paths', 'FILE_REFRESH', {}),
            ],
            secondary_actions=[
                ('import_scene.sfs_reference_toolkit_swap_external_extensions', 'Swap Extensions', 'FILE_FONT', {}),
                ('import_scene.sfs_ref_toolkit_materialize', 'Materialize Links', 'OUTLINER_DATA_MESH', {}),
                ('import_scene.sfs_external_assets_bundle_project', 'Bundle', 'EXPORT', {}),
                ('import_scene.sfs_external_assets_verify_bundle', 'Verify Bundle...', 'CHECKMARK', {}),
                ('import_scene.sfs_override_manager_audit', 'Override Audit...', 'CHECKMARK', {}),
                ('import_scene.sfs_root_repath_apply_saved_plan', 'Apply Saved Plan', 'CHECKMARK', {}),
                ('import_scene.sfs_root_repath_restore_saved_plan', 'Restore Saved Plan', 'LOOP_BACK', {}),
                ('import_scene.sfs_rm_prepare_upgrade_plan', 'Prepare Saved Upgrade', 'FILE_TICK', {}),
                ('import_scene.sfs_reference_manager_apply_saved_upgrade_plan', 'Apply Saved Upgrade', 'CHECKMARK', {}),
                ('import_scene.sfs_rm_restore_upgrade_plan', 'Restore Saved Upgrade', 'LOOP_BACK', {}),
                ('import_scene.sfs_ref_toolkit_export_library', 'Export Selection as Library', 'OUTLINER_OB_GROUP_INSTANCE', {}),
            ],
        )

        pipeline = layout.box()
        _sf_draw_section_intro(
            pipeline,
            'Pipeline Bridges',
            'Publish reusable containers, reload them into the browser, export shot manifests, and quickly inspect linked scene state.',
            'OUTLINER_COLLECTION',
        )
        _sf_draw_action_block(
            pipeline,
            primary_actions=[
                ('export_scene.sfs_pipeline_publish_container', 'Container', 'EXPORT', {}),
                ('import_scene.sfs_pipeline_load_container', 'Load Container', 'IMPORT', {}),
                ('export_scene.sfs_pipeline_shot_manifest', 'Shot Manifest', 'FILE_TEXT', {}),
            ],
            secondary_actions=[
                ('import_scene.sfs_pipeline_linked_overview', 'Linked Overview', 'LINKED', {}),
                ('import_scene.sfs_representation_open', 'Representations', 'MOD_WIREFRAME', {}),
            ],
        )

        scope_box = layout.box()
        _sf_draw_section_intro(
            scope_box,
            'Selection Export Scope',
            'Export Selection as Library writes the current selection and nearby collection context into a reusable .blend reference file.',
            'OUTLINER_OB_GROUP_INSTANCE',
        )
        sel_count = len(list(getattr(context, 'selected_objects', []) or []))
        _sf_draw_state_line(scope_box, 'Selected Objects', 'READY' if sel_count else 'NEEDS SOURCE', detail=str(sel_count))
        try:
            active_name = getattr(getattr(context, 'active_object', None), 'name', '') or _t('Not set')
        except Exception:
            active_name = _t('Not set')
        scope_box.label(text=f"{_t('Active')}: {active_name}", icon='BLANK1')

        tip = layout.box()
        _sf_draw_section_intro(
            tip,
            'Best Practice',
            'Keep shared references relative whenever possible, reserve absolute paths for staging or emergency recovery, and export modular library files from stable selection groups.',
            'LIGHT',
        )


class SF_OT_reference_toolkit_export_selection_as_library(bpy.types.Operator, ExportHelper):
    bl_idname = 'import_scene.sfs_ref_toolkit_export_library'
    bl_label = 'Export Selection as Library'
    bl_description = 'Write the current selection and nearby collection context into a reusable .blend library file so large scenes can be modularized and referenced later. Indirect dependencies are expanded by Blender when the library file is written.'
    bl_options = set()
    _sms_no_undo = True

    filename_ext = '.blend'
    filter_glob: StringProperty(default='*.blend', options={'HIDDEN'})

    include_user_collections: BoolProperty(name='Include user collections', default=True, description='Also include collections that own the selected objects so hierarchy context is preserved more reliably inside the exported library.')
    path_remap: EnumProperty(
        name='Path Remap',
        items=[
            ('NONE', 'Keep', 'Do not rewrite external file paths while writing the new library file.'),
            ('RELATIVE', 'Relative Existing', 'Only remap paths that are already relative.'),
            ('RELATIVE_ALL', 'Relative All', 'Rewrite all supported paths to be relative to the exported library file.'),
            ('ABSOLUTE', 'Absolute', 'Rewrite supported paths to absolute disk paths.'),
        ],
        default='RELATIVE_ALL',
        description='Choose how external file paths should be written into the exported library file.',
    )
    compress: BoolProperty(name='Compress .blend', default=True, description='Write the exported library as a compressed .blend file.')
    fake_user: BoolProperty(name='Mark fake users', default=False, description='Ask Blender to mark written datablocks with fake users where supported so they are harder to purge accidentally later.')
    open_after: BoolProperty(name='Open after export', default=False, description='Open the exported file or its folder after the write finishes.')

    def invoke(self, context, event):
        if not self.filepath:
            seed = _sf_ref_export_seed_name(context)
            start_dir = _sf_ref_rel_base_dir() or _sf_user_default_dir('handoff')
            self.filepath = os.path.join(start_dir, f"{seed}_library.blend")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        roots = _sf_ref_selected_root_ids(context, include_user_collections=self.include_user_collections)
        if not roots:
            self.report({'ERROR'}, _t('Select at least one object or choose a collection context first'))
            return {'CANCELLED'}

        filepath = _norm_path(self.filepath or '')
        if not filepath:
            self.report({'ERROR'}, _t('Output path is required'))
            return {'CANCELLED'}
        if not filepath.lower().endswith('.blend'):
            filepath += '.blend'
        out_dir = os.path.dirname(filepath)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)

        datablocks = set(roots)
        try:
            bpy.data.libraries.write(
                filepath,
                datablocks,
                path_remap=self.path_remap,
                fake_user=self.fake_user,
                compress=self.compress,
            )
        except Exception as ex:
            self.report({'ERROR'}, f"{_t('Library export failed')}: {ex}")
            return {'CANCELLED'}

        report_lines = [
            f"Smart File | {_t('Selection Library Export')} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            '',
            f"- {_t('Output')}: {filepath}",
            f"- {_t('Selected roots')}: {len(roots)}",
            f"- {_t('Path Remap')}: {self.path_remap}",
            f"- {_t('Compressed')}: {bool(self.compress)}",
            f"- {_t('Fake User')}: {bool(self.fake_user)}",
        ]
        for id_ in roots[:40]:
            try:
                report_lines.append(f"- {type(id_).__name__}: {getattr(id_, 'name', '')}")
            except Exception:
                pass
        _sf_report_export(
            context,
            _t('Selection Library Export'),
            report_lines,
            open_text=False,
            activity_title=_t('Exported selection as library'),
        )

        if self.open_after:
            try:
                bpy.ops.wm.path_open(filepath=filepath)
            except Exception:
                try:
                    bpy.ops.wm.path_open(filepath=os.path.dirname(filepath))
                except Exception:
                    pass

        self.report({'INFO'}, f"{_t('Library exported')}: {os.path.basename(filepath)}")
        return {'FINISHED'}


class SF_OT_reference_toolkit_normalize_external_paths(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_reference_toolkit_normalize_external_paths'
    bl_label = 'Normalize External Paths'
    bl_description = 'Rewrite supported external paths in bulk so the current file or selected hierarchy consistently uses relative or absolute paths. This is the safer Blender-side equivalent of large repath scripts used in other DCC tools.'
    bl_options = {'UNDO'}

    scope: EnumProperty(
        name='Scope',
        items=[
            ('CURRENT_FILE', 'Current File', 'Normalize all supported external references in the current file.'),
            ('SELECTED_HIERARCHY', 'Selected Hierarchy', 'Only normalize records reachable from the current selection and nearby collections.'),
        ],
        default='CURRENT_FILE',
        description='Choose whether to process the whole file or only the current selection scope.',
    )
    include_libraries: BoolProperty(name='Include linked libraries', default=True, description='Also normalize linked .blend library paths when the chosen scope reaches them.')
    include_texts: BoolProperty(name='Include text datablocks', default=False, description='Also normalize external text datablock paths.')
    target_mode: EnumProperty(
        name='Target Mode',
        items=[
            ('RELATIVE', 'Relative', 'Rewrite supported paths as relative paths to the current .blend file.'),
            ('ABSOLUTE', 'Absolute', 'Rewrite supported paths as absolute disk paths.'),
        ],
        default='RELATIVE',
        description='Choose whether normalized paths should end up relative or absolute.',
    )
    only_existing: BoolProperty(name='Only existing files', default=True, description='Skip missing references and only rewrite paths that already resolve to a real file on disk.')
    open_report: BoolProperty(name='Open report', default=True, description="Open the normalization report in Blender's Text Editor after the run.")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=640)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'scope')
        layout.prop(self, 'include_libraries')
        layout.prop(self, 'include_texts')
        layout.prop(self, 'target_mode')
        layout.prop(self, 'only_existing')
        layout.prop(self, 'open_report')

    def execute(self, context):
        if self.target_mode == 'RELATIVE' and not bpy.data.filepath:
            self.report({'ERROR'}, _t('Save the current file before writing relative paths'))
            return {'CANCELLED'}

        records = _sf_ref_collect_scope_records(
            context,
            scope=self.scope,
            include_libraries=self.include_libraries,
            include_texts=self.include_texts,
            include_missing=not self.only_existing,
        )
        if self.only_existing:
            records = [rec for rec in records if rec.get('exists') and (not rec.get('packed'))]
        else:
            records = [rec for rec in records if not rec.get('packed')]
        if not records:
            self.report({'INFO'}, _t('No eligible external paths were found'))
            return {'CANCELLED'}

        changed = 0
        unchanged = 0
        failed = []
        report_lines = [
            f"Smart File | {_t('Normalize External Paths')} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            '',
            f"- {_t('Scope')}: {self.scope}",
            f"- {_t('Target Mode')}: {self.target_mode}",
            f"- {_t('Records')}: {len(records)}",
            '',
            'RESULTS',
        ]

        for rec in records:
            try:
                id_ = rec.get('id_ref')
                old_path = getattr(id_, 'filepath', '') or ''
                abs_path = str(rec.get('abs_path') or '')
                if not abs_path:
                    unchanged += 1
                    report_lines.append(f"- [SKIP] [{rec.get('kind_label','')}] {rec.get('name','')} | {_t('No absolute path')}")
                    continue
                new_path = _sf_ref_abs_to_path_mode(abs_path, self.target_mode)
                if old_path == new_path:
                    unchanged += 1
                    report_lines.append(f"- [KEEP] [{rec.get('kind_label','')}] {rec.get('name','')} | {old_path}")
                    continue
                setattr(id_, 'filepath', new_path)
                changed += 1
                report_lines.append(f"- [OK] [{rec.get('kind_label','')}] {rec.get('name','')} | {old_path} -> {new_path}")
            except Exception as ex:
                failed.append(rec)
                report_lines.append(f"- [FAIL] [{rec.get('kind_label','')}] {rec.get('name','')} | {ex}")

        if failed:
            report_lines.extend(['', 'FAILED'])
            for rec in failed:
                report_lines.append(f"- [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('raw_path','')}")

        text_name = _sf_report_export(
            context,
            _t('Normalize External Paths'),
            report_lines,
            open_text=self.open_report,
            activity_title=_t('Normalized external paths'),
        )
        self.report({'INFO'}, f"{_t('Changed')}: {changed} | {_t('Unchanged')}: {unchanged} | {_t('Failed')}: {len(failed)} | {text_name}")
        return {'FINISHED'}


class SF_OT_reference_toolkit_swap_external_extensions(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_reference_toolkit_swap_external_extensions'
    bl_label = 'Swap External Extensions'
    bl_description = 'Search for sibling or indexed replacement files that share the same stem but use a different extension, then rewrite the supported external file paths in bulk. This covers the common texture-format migration workflow used in several DCC ecosystems.'
    bl_options = {'UNDO'}

    scope: EnumProperty(
        name='Scope',
        items=[
            ('CURRENT_FILE', 'Current File', 'Process supported records from the whole current file.'),
            ('SELECTED_HIERARCHY', 'Selected Hierarchy', 'Only process records reachable from the current selection and nearby collections.'),
        ],
        default='CURRENT_FILE',
        description='Choose whether to process the whole file or the current selection scope.',
    )
    target_kind: EnumProperty(
        name='Target Kind',
        items=[
            ('IMAGES_ONLY', 'Images Only', 'Only consider image datablocks, which is the safest option for format migrations such as PNG to TIFF or EXR.'),
            ('ALL_TYPES', 'All Supported Types', 'Also allow movie, sound, font, volume, cache, text, and linked library paths when the extension pattern matches.'),
        ],
        default='IMAGES_ONLY',
        description='Choose whether the migration should be limited to images or applied to all supported external asset records.',
    )
    from_ext: StringProperty(name='From Extension', default='.png', description='Only records with this extension are considered. You can type png or .png.')
    to_ext: StringProperty(name='To Extension', default='.tif', description='Replacement files must use this extension. You can type tif or .tif.')
    search_mode: EnumProperty(
        name='Search Mode',
        items=[
            ('SAME_FOLDER', 'Same Folder', 'Only search next to each current file path. Fastest and safest when converted files sit beside the originals.'),
            ('SEARCH_ROOTS', 'Library Roots', 'Search the current file folder and enabled library roots using a basename index.'),
            ('BOTH', 'Both', 'Check same-folder candidates first, then fall back to indexed root search.'),
        ],
        default='BOTH',
        description='Choose how replacement candidates should be searched.',
    )
    include_libraries: BoolProperty(name='Include linked libraries', default=False, description='When enabled, linked .blend library paths can also be swapped if their extension matches.')
    include_texts: BoolProperty(name='Include text datablocks', default=False, description='Allow external text datablocks to participate when their extension matches.')
    write_mode: EnumProperty(
        name='Write Mode',
        items=[
            ('KEEP_STYLE', 'Keep existing style', 'Preserve relative-vs-absolute style when possible.'),
            ('RELATIVE', 'Relative', 'Write resolved replacements as relative paths to the current .blend file.'),
            ('ABSOLUTE', 'Absolute', 'Write resolved replacements as absolute disk paths.'),
        ],
        default='KEEP_STYLE',
        description='Choose how successful replacement paths are written back into Blender.',
    )
    open_report: BoolProperty(name='Open report', default=True, description="Open the extension-swap report in Blender's Text Editor after the run.")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=700)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'scope')
        layout.prop(self, 'target_kind')
        layout.prop(self, 'from_ext')
        layout.prop(self, 'to_ext')
        layout.prop(self, 'search_mode')
        layout.prop(self, 'include_libraries')
        layout.prop(self, 'include_texts')
        layout.prop(self, 'write_mode')
        layout.prop(self, 'open_report')

    def execute(self, context):
        from_ext = _sf_ref_normalized_ext(self.from_ext)
        to_ext = _sf_ref_normalized_ext(self.to_ext)
        if not from_ext or not to_ext:
            self.report({'ERROR'}, _t('Both extensions are required'))
            return {'CANCELLED'}
        if from_ext == to_ext:
            self.report({'ERROR'}, _t('Choose two different extensions'))
            return {'CANCELLED'}
        if self.write_mode == 'RELATIVE' and not bpy.data.filepath:
            self.report({'ERROR'}, _t('Save the current file before writing relative paths'))
            return {'CANCELLED'}

        records = _sf_ref_collect_scope_records(
            context,
            scope=self.scope,
            include_libraries=self.include_libraries,
            include_texts=self.include_texts,
            include_missing=True,
        )
        if self.target_kind == 'IMAGES_ONLY':
            records = [rec for rec in records if str(rec.get('kind_key') or '') == 'IMAGE']
        targets = []
        for rec in records:
            raw_or_abs = str(rec.get('abs_path') or rec.get('raw_path') or '')
            if os.path.splitext(raw_or_abs)[1].lower() == from_ext:
                targets.append(rec)
        if not targets:
            self.report({'INFO'}, _t('No matching external records were found'))
            return {'CANCELLED'}

        index = {}
        if self.search_mode in {'SEARCH_ROOTS', 'BOTH'}:
            roots = _sf_ext_find_search_roots(context, '', include_current_file_dir=True, include_library_roots=True)
            index = _sf_ext_build_basename_index(roots, allowed_suffixes={to_ext}) if roots else {}
        changed = 0
        unresolved = []
        failed = []
        report_lines = [
            f"Smart File | {_t('Swap External Extensions')} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            '',
            f"- {_t('Scope')}: {self.scope}",
            f"- {_t('From Extension')}: {from_ext}",
            f"- {_t('To Extension')}: {to_ext}",
            f"- {_t('Targets')}: {len(targets)}",
            '',
            'RESULTS',
        ]

        for rec in targets:
            base = os.path.basename(str(rec.get('abs_path') or rec.get('raw_path') or ''))
            stem = os.path.splitext(base)[0]
            wanted_name = f"{stem}{to_ext}"
            candidates = []
            if self.search_mode in {'SAME_FOLDER', 'BOTH'}:
                candidates.extend(_sf_ref_sibling_replacement_candidates(rec, to_ext))
            if self.search_mode in {'SEARCH_ROOTS', 'BOTH'}:
                candidates.extend(list(index.get(wanted_name.lower(), []) or []))
            candidates = _sf_ref_dedup_paths(candidates)
            best = _sf_ext_pick_best_candidate(rec, candidates)
            if not best:
                unresolved.append(rec)
                report_lines.append(f"- [MISS] [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('raw_path','')}")
                continue
            try:
                id_ = rec.get('id_ref')
                old_path = getattr(id_, 'filepath', '') or ''
                if self.write_mode == 'KEEP_STYLE':
                    new_path = _sf_ref_preserve_path_style(old_path, best)
                else:
                    new_path = _sf_ref_abs_to_path_mode(best, self.write_mode)
                setattr(id_, 'filepath', new_path)
                changed += 1
                report_lines.append(f"- [OK] [{rec.get('kind_label','')}] {rec.get('name','')} | {old_path} -> {new_path}")
            except Exception as ex:
                failed.append(rec)
                report_lines.append(f"- [FAIL] [{rec.get('kind_label','')}] {rec.get('name','')} | {ex}")

        if unresolved:
            report_lines.extend(['', 'UNRESOLVED'])
            for rec in unresolved:
                report_lines.append(f"- [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('raw_path','')}")
        if failed:
            report_lines.extend(['', 'FAILED'])
            for rec in failed:
                report_lines.append(f"- [{rec.get('kind_label','')}] {rec.get('name','')} | {rec.get('raw_path','')}")

        text_name = _sf_report_export(
            context,
            _t('Swap External Extensions'),
            report_lines,
            open_text=self.open_report,
            activity_title=_t('Swapped external extensions'),
        )
        self.report({'INFO'}, f"{_t('Changed')}: {changed} | {_t('Unresolved')}: {len(unresolved)} | {_t('Failed')}: {len(failed)} | {text_name}")
        return {'FINISHED'}
