# -----------------------------------------------------------------------------
#  Batch Preview Generator (Phase 3.2)
# -----------------------------------------------------------------------------

class SF_OT_asset_preview_batch_preview(bpy.types.Operator):
    bl_idname = 'export_scene.sfs_asset_preview_batch_preview'
    bl_label = 'Batch Preview'
    bl_description = 'Create or refresh preview images for many published .blend assets at once, with optional catalog updates'
    bl_options = set()
    _sms_no_undo = True

    target_dir: StringProperty(name='Target Folder', subtype='DIR_PATH', default="", description='Folder that contains the published .blend assets you want to process')
    recursive: BoolProperty(name='Recursive', default=True, description='Search subfolders too when looking for published .blend files')
    only_missing_outdated: BoolProperty(name='Only missing / outdated', default=True, description='Skip preview files that already exist and are newer than the .blend source')
    update_catalog: BoolProperty(name='Update Catalog', default=True, description='Write the generated preview filenames back into catalog.json when possible')
    catalog_filename: StringProperty(name='Catalog File Name', default="catalog.json", description='Catalog file name to update in each processed folder')
    resolution: IntProperty(name='Thumbnail Size', default=256, min=64, max=1024, description='Square preview image resolution in pixels')
    limit: IntProperty(name='Limit', default=500, min=1, max=5000, description='Maximum number of .blend files to process in one batch run')

    def invoke(self, context, _event):
        prefs = _addon_prefs(context)
        if not self.target_dir:
            # default to first root/published
            root = _get_first_enabled_root(prefs) or os.path.dirname(_norm_path(bpy.data.filepath or ''))
            sub = getattr(prefs, 'pub_default_subdir', 'Published') if prefs else 'Published'
            self.target_dir = os.path.join(root, sub) if root else ''
        if prefs:
            try:
                self.catalog_filename = getattr(prefs, 'pub_catalog_filename', 'catalog.json')
                self.resolution = int(getattr(prefs, 'thumb_resolution', 256) or 256)
            except Exception:
                pass
        return context.window_manager.invoke_props_dialog(self, width=460)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        box = layout.box()
        box.prop(self, 'target_dir')

        split = layout.split(factor=0.5)
        left = split.column(align=True)
        right = split.column(align=True)

        left.prop(self, 'recursive')
        left.prop(self, 'only_missing_outdated', text='Only Missing / Outdated')
        left.prop(self, 'resolution', text='Size')
        right.prop(self, 'limit')
        right.prop(self, 'update_catalog', text='Update Catalog')
        sub = right.column(align=True)
        sub.enabled = bool(self.update_catalog)
        sub.prop(self, 'catalog_filename', text='Catalog')

    def execute(self, context):
        tdir = _norm_path(self.target_dir)
        if not tdir or not os.path.isdir(tdir):
            self.report({'ERROR'}, _tr('Invalid file'))
            return {'CANCELLED'}

        res = max(64, min(1024, int(self.resolution or 256)))

        # gather blend files
        blends = []
        if self.recursive:
            for root, _dirs, files in os.walk(tdir):
                for fn in files:
                    if fn.lower().endswith('.blend'):
                        blends.append(os.path.join(root, fn))
                        if len(blends) >= int(self.limit):
                            break
                if len(blends) >= int(self.limit):
                    break
        else:
            for fn in os.listdir(tdir):
                if fn.lower().endswith('.blend'):
                    blends.append(os.path.join(tdir, fn))
                    if len(blends) >= int(self.limit):
                        break

        if not blends:
            self.report({'WARNING'}, _tr('No items found'))
            return {'CANCELLED'}

        # Create a temp scene for rendering
        temp_scene = bpy.data.scenes.new('SF_BatchPreview_Scene')
        temp_scene.render.image_settings.file_format = 'PNG'
        temp_scene.render.resolution_x = res
        temp_scene.render.resolution_y = res
        temp_scene.render.resolution_percentage = 100

        cam_data = bpy.data.cameras.new('SF_Batch_Cam')
        cam_obj = bpy.data.objects.new('SF_Batch_Cam', cam_data)
        temp_scene.collection.objects.link(cam_obj)
        temp_scene.camera = cam_obj

        light_data = bpy.data.lights.new('SF_Batch_Light', type='AREA')
        light_obj = bpy.data.objects.new('SF_Batch_Light', light_data)
        temp_scene.collection.objects.link(light_obj)

        import math, mathutils

        def frame(objects):
            min_v = mathutils.Vector((1e9, 1e9, 1e9))
            max_v = mathutils.Vector((-1e9, -1e9, -1e9))
            any_bb = False
            for ob in objects:
                if ob.type in {'CAMERA', 'LIGHT'}:
                    continue
                try:
                    for v in ob.bound_box:
                        vv = ob.matrix_world @ mathutils.Vector(v)
                        min_v.x = min(min_v.x, vv.x)
                        min_v.y = min(min_v.y, vv.y)
                        min_v.z = min(min_v.z, vv.z)
                        max_v.x = max(max_v.x, vv.x)
                        max_v.y = max(max_v.y, vv.y)
                        max_v.z = max(max_v.z, vv.z)
                        any_bb = True
                except Exception:
                    pass
            if not any_bb:
                cam_obj.location = (0, -5, 3)
                cam_obj.rotation_euler = (1.1, 0.0, 0.0)
                return
            center = (min_v + max_v) * 0.5
            size = (max_v - min_v).length
            dist = max(0.5, size * 1.2)
            cam_obj.location = center + mathutils.Vector((dist, -dist, dist))
            cam_obj.rotation_euler = (math.radians(60), 0.0, math.radians(45))
            light_obj.location = center + mathutils.Vector((dist, -dist, dist * 1.2))
            light_data.energy = 200.0

        def update_catalog_preview(cat_path: str, blend_fn: str, prev_fn: str):
            cat_path = _norm_path(cat_path)
            if not cat_path or not os.path.exists(cat_path):
                return
            try:
                with open(cat_path, 'r', encoding='utf-8') as f:
                    cat = json.load(f) or {}
            except Exception:
                return
            assets = cat.get('assets') or {}
            changed = False
            for _akey, data in assets.items():
                entries = (data or {}).get('entries', []) or []
                for e in entries:
                    if (e.get('blend') or '') == blend_fn:
                        if (e.get('preview') or '') != prev_fn:
                            e['preview'] = prev_fn
                            changed = True
            if changed:
                try:
                    with open(cat_path, 'w', encoding='utf-8') as f:
                        json.dump(cat, f, ensure_ascii=False, indent=2)
                except Exception:
                    pass

        done = 0
        failures = []
        for fp in blends:
            fp = _norm_path(fp)
            out_png = os.path.splitext(fp)[0] + '.png'
            if self.only_missing_outdated and os.path.exists(out_png):
                try:
                    if os.path.getmtime(out_png) >= os.path.getmtime(fp):
                        continue
                except Exception:
                    pass

            snap = _capture_data_snapshot()
            loaded_objects = []
            loaded_collections = []

            try:
                asset_guess = _ar_guess_asset_from_filename(fp)
                requested_collections = []
                requested_objects = []
                with bpy.data.libraries.load(fp, link=False) as (df, dt):
                    cols = list(getattr(df, 'collections', []) or [])
                    objs = list(getattr(df, 'objects', []) or [])
                    if asset_guess in cols:
                        dt.collections = [asset_guess]
                    elif cols:
                        dt.collections = [cols[0]]
                    elif objs:
                        dt.objects = [objs[0]]
                requested_collections = [col for col in list(getattr(dt, 'collections', []) or []) if col is not None]
                requested_objects = [ob for ob in list(getattr(dt, 'objects', []) or []) if ob is not None]

                # link the actual datablocks returned by libraries.load so name collisions
                # with existing scene data do not point the preview at the wrong asset
                col = requested_collections[0] if requested_collections else None
                if col is not None:
                    temp_scene.collection.children.link(col)
                    loaded_collections.append(col)
                    loaded_objects = list(col.all_objects)
                else:
                    ob = requested_objects[0] if requested_objects else None
                    if ob is not None:
                        temp_scene.collection.objects.link(ob)
                        loaded_objects = [ob]
                    else:
                        # last-resort fallback for unusual blend files that expose neither
                        # collection nor object handles in the expected slot
                        fallback_col = None
                        for c in bpy.data.collections:
                            if c.name not in snap['collections']:
                                fallback_col = c
                                break
                        if fallback_col is not None:
                            temp_scene.collection.children.link(fallback_col)
                            loaded_collections.append(fallback_col)
                            loaded_objects = list(fallback_col.all_objects)
                        else:
                            fallback_ob = None
                            for o in bpy.data.objects:
                                if o.name not in snap['objects']:
                                    fallback_ob = o
                                    break
                            if fallback_ob is not None:
                                temp_scene.collection.objects.link(fallback_ob)
                                loaded_objects = [fallback_ob]

                if loaded_objects:
                    frame(loaded_objects)

                temp_scene.render.filepath = out_png
                with context.temp_override(scene=temp_scene):
                    bpy.ops.render.render(write_still=True)

                # update catalog in the same folder
                if self.update_catalog:
                    cat_path = os.path.join(os.path.dirname(fp), _safe_filename(self.catalog_filename) or 'catalog.json')
                    update_catalog_preview(cat_path, os.path.basename(fp), os.path.basename(out_png))

                done += 1

            except Exception as e:
                failures.append(f"{os.path.basename(fp)} | {type(e).__name__}: {e}")
            finally:
                # unlink
                try:
                    for col in loaded_collections:
                        try:
                            linked = temp_scene.collection.children.get(col.name)
                        except Exception:
                            linked = None
                        if linked is col:
                            temp_scene.collection.children.unlink(col)
                except Exception:
                    pass
                try:
                    for ob in loaded_objects:
                        try:
                            linked = temp_scene.collection.objects.get(ob.name)
                        except Exception:
                            linked = None
                        if linked is ob:
                            temp_scene.collection.objects.unlink(ob)
                except Exception:
                    pass
                _cleanup_new_data(snap)

        # cleanup
        try:
            bpy.data.objects.remove(cam_obj, do_unlink=True)
        except Exception:
            pass
        try:
            bpy.data.objects.remove(light_obj, do_unlink=True)
        except Exception:
            pass
        try:
            bpy.data.cameras.remove(cam_data, do_unlink=True)
        except Exception:
            pass
        try:
            bpy.data.lights.remove(light_data, do_unlink=True)
        except Exception:
            pass
        try:
            bpy.data.scenes.remove(temp_scene, do_unlink=True)
        except Exception:
            pass

        # refresh catalog view if pointing inside target
        try:
            wm = context.window_manager
            cat_fp = _norm_path(getattr(wm, 'sf_ar_catalog_file', '') or '')
            if cat_fp and os.path.exists(cat_fp) and _norm_path(os.path.dirname(cat_fp)).startswith(_norm_path(tdir)):
                bpy.ops.import_scene.sfs_asset_reader_reload_catalog('EXEC_DEFAULT')
        except Exception:
            pass

        if failures:
            lines = [
                f"Smart File | {_t('Batch Preview Report')} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                '',
                f"- {_t('Generated')}: {done}",
                f"- {_t('Failures')}: {len(failures)}",
                '',
                *failures,
            ]
            _sf_report_export(
                context,
                _t('Batch Preview Report'),
                lines,
                open_text=False,
                activity_title=_t('Generated batch previews with warnings'),
            )
            self.report({'WARNING'}, _tr('Batch preview complete') + f": {done} | {_t('Failures')}: {len(failures)}")
            return {'FINISHED'}

        self.report({'INFO'}, _tr('Batch preview complete') + f": {done}")
        return {'FINISHED'}
