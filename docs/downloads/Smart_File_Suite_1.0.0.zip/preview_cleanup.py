# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Exact-generation lifecycle owner for Smart File preview collections.

Preview collections are created only by explicit UI preparation/refresh paths.
This module registers one known ``exit_pre`` callback and one Python atexit
callback after the first collection is created, records both exact identities,
and removes only Smart File's fixed driver-namespace keys on disable/exit.
"""
from __future__ import annotations

import atexit as _atexit
import sys
import uuid

try:
    import bpy
    from bpy.app.handlers import persistent as _persistent
except Exception:  # pragma: no cover - static tooling outside Blender.
    bpy = None  # type: ignore[assignment]

    def _persistent(function):
        return function

_OWNER_KEY = "JELararagi.smart_file.preview_cleanup.lifecycle.v57540"
_LEGACY_OWNER_KEYS = (
    "JELararagi.smart_file.preview_cleanup.lifecycle.v57539",
    "JELararagi.smart_file.preview_cleanup.lifecycle.v57538",
    "JELararagi.smart_file.preview_cleanup.lifecycle.v57537",
)
_OWNER_TOKEN = object()
_GENERATION = uuid.uuid4().hex
_HANDLER_ACQUIRED = False
_LOAD_HANDLER_ACQUIRED = False
_ATEXIT_ACQUIRED = False

_PREVIEW_DRIVER_NAMESPACE_KEYS = (
    "smart_file_suite.common.preview_collection",
    "smart_file_suite.file_pipeline_icons.preview_collection",
    "smart_file_suite.decentraland.preview_collection",
    "smart_file_suite.ikea.thumbnail_preview_collection",
    "smart_file_suite.asset_reader.thumbnail_preview_collection",
    "smart_file_suite.brand_preview_collection",
)


def _namespace():
    if bpy is None:
        return None
    try:
        value = bpy.app.driver_namespace
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _previews_module():
    if bpy is None:
        return None
    try:
        import bpy.utils.previews as previews_mod
        return previews_mod
    except Exception:
        try:
            return getattr(getattr(bpy, "utils", None), "previews", None)
        except Exception:
            return None


def _reset_known_module_globals() -> None:
    package = str(__package__ or "").strip()
    records = (
        (package + ".common", {"_PREVIEW_COLLECTION": None}),
        (package + ".file_pipeline_icons", {
            "_PREVIEW_COLLECTION": None,
            "_LOADED_ICON_DIR": "",
            "_LOADED_SIGNATURE": (),
        }),
        (package + ".asset_reader", {
            "_PREVIEW_COLLECTION": None,
            "_PREVIEW_KEY_ORDER": [],
        }),
        (package + ".core", {
            "_SF_BRAND_ICON_ID": 0,
            "_SF_BRAND_PREVIEW_COLLECTION": None,
        }),
        (package + ".ikea", {"_thumbs": None}),
    )
    for module_name, values in records:
        module = sys.modules.get(module_name)
        if module is None:
            continue
        for name, value in values.items():
            try:
                setattr(module, name, value)
            except Exception:
                pass


def _known_module_preview_collections() -> tuple:
    """Return only fixed Smart File module globals that own preview resources."""
    package = str(__package__ or "").strip()
    records = (
        (package + ".common", "_PREVIEW_COLLECTION"),
        (package + ".file_pipeline_icons", "_PREVIEW_COLLECTION"),
        (package + ".asset_reader", "_PREVIEW_COLLECTION"),
        (package + ".core", "_SF_BRAND_PREVIEW_COLLECTION"),
        (package + ".ikea", "_thumbs"),
    )
    values = []
    for module_name, attr_name in records:
        module = sys.modules.get(module_name)
        if module is None:
            continue
        try:
            value = getattr(module, attr_name, None)
        except Exception:
            value = None
        if value is not None:
            values.append(value)
    decentraland = sys.modules.get(package + ".decentraland_tools.icon_loader")
    if decentraland is not None:
        try:
            values.extend(
                value for value in tuple(
                    getattr(decentraland, "preview_collections", {}).values()
                )
                if value is not None
            )
        except Exception:
            pass
    return tuple(values)


@_persistent
def cleanup_preview_collections(*_args, **_kwargs) -> None:
    """Remove only fixed Smart File previews, including post-load global owners."""
    previews_mod = _previews_module()
    namespace = _namespace()
    if previews_mod is None:
        _reset_known_module_globals()
        return
    seen: set[int] = set()
    collections = list(_known_module_preview_collections())
    if namespace is not None:
        for key in _PREVIEW_DRIVER_NAMESPACE_KEYS:
            try:
                collections.append(namespace.pop(key, None))
            except Exception:
                pass
    for pcoll in collections:
        if pcoll is None or id(pcoll) in seen:
            continue
        seen.add(id(pcoll))
        try:
            previews_mod.remove(pcoll)
        except Exception:
            pass
    _reset_known_module_globals()
    package = str(__package__ or "").strip()
    decentraland = sys.modules.get(package + ".decentraland_tools.icon_loader")
    if decentraland is not None:
        try:
            decentraland.preview_collections.clear()
            decentraland._loaded_icon_dir = ""
        except Exception:
            pass


def _cleanup_generation(token=None, generation=None) -> bool:
    global _HANDLER_ACQUIRED, _LOAD_HANDLER_ACQUIRED, _ATEXIT_ACQUIRED
    if token is not None and token is not _OWNER_TOKEN:
        return False
    if generation is not None and str(generation) != _GENERATION:
        return False
    ok = True
    if bpy is not None and _HANDLER_ACQUIRED:
        try:
            exit_pre = bpy.app.handlers.exit_pre
            # The callback object is a fixed function owned by this module. Remove
            # every occurrence of that exact identity; no name or foreign scan is
            # used, and duplicates from interrupted same-generation registration
            # cannot survive disable/reload.
            while any(item is cleanup_preview_collections for item in tuple(exit_pre)):
                exit_pre.remove(cleanup_preview_collections)
            ok = ok and not any(item is cleanup_preview_collections for item in tuple(exit_pre))
        except Exception:
            ok = False
    if bpy is not None and _LOAD_HANDLER_ACQUIRED:
        try:
            load_pre = bpy.app.handlers.load_pre
            while any(item is cleanup_preview_collections for item in tuple(load_pre)):
                load_pre.remove(cleanup_preview_collections)
            ok = ok and not any(item is cleanup_preview_collections for item in tuple(load_pre))
        except Exception:
            ok = False
    if _ATEXIT_ACQUIRED:
        try:
            _atexit.unregister(cleanup_preview_collections)
        except Exception:
            # Python may already be finalizing; collection cleanup remains safe.
            pass
    _HANDLER_ACQUIRED = False
    _LOAD_HANDLER_ACQUIRED = False
    _ATEXIT_ACQUIRED = False
    namespace = _namespace()
    if namespace is not None:
        owner = namespace.get(_OWNER_KEY)
        if isinstance(owner, dict) and owner.get("token") is _OWNER_TOKEN:
            namespace.pop(_OWNER_KEY, None)
    return bool(ok)


def _cleanup_external(owner) -> bool:
    if not isinstance(owner, dict):
        return False
    # During importlib.reload the module dictionary is reused. The old cleanup
    # function therefore sees the new token and cannot validate its own ledger.
    # Retire the immutable callback identities captured by that ledger directly.
    handler = owner.get("handler")
    exit_handler = owner.get("exit_handler") or handler
    load_handler = owner.get("load_handler") or handler
    if callable(exit_handler) or callable(load_handler):
        ok = True
        if bpy is not None:
            for handler_list, callback in (
                (getattr(bpy.app.handlers, "exit_pre", None), exit_handler),
                (getattr(bpy.app.handlers, "load_pre", None), load_handler),
            ):
                if handler_list is None or not callable(callback):
                    continue
                try:
                    while any(item is callback for item in tuple(handler_list)):
                        handler_list.remove(callback)
                    ok = bool(not any(item is callback for item in tuple(handler_list)) and ok)
                except Exception:
                    ok = False
        if bool(owner.get("atexit_acquired")) and callable(handler):
            try:
                _atexit.unregister(handler)
            except Exception:
                pass
        try:
            cleanup_preview_collections()
        except Exception:
            ok = False
        return bool(ok)
    cleanup = owner.get("cleanup")
    if not callable(cleanup):
        return False
    try:
        try:
            return bool(cleanup(owner.get("token"), owner.get("generation")))
        except TypeError:
            return bool(cleanup())
    except Exception:
        return False


def register() -> bool:
    """Install exact load/exit callbacks after the first preview exists."""
    global _HANDLER_ACQUIRED, _LOAD_HANDLER_ACQUIRED, _ATEXIT_ACQUIRED
    namespace = _namespace()
    if bpy is None or namespace is None:
        return False
    for key in _LEGACY_OWNER_KEYS:
        previous = namespace.get(key)
        if previous is not None:
            if not _cleanup_external(previous):
                return False
            namespace.pop(key, None)
    previous = namespace.get(_OWNER_KEY)
    if isinstance(previous, dict):
        if previous.get("token") is _OWNER_TOKEN and previous.get("generation") == _GENERATION:
            return True
        if not _cleanup_external(previous):
            return False
        namespace.pop(_OWNER_KEY, None)

    try:
        exit_pre = bpy.app.handlers.exit_pre
        matches = [item for item in tuple(exit_pre) if item is cleanup_preview_collections]
        if not matches:
            exit_pre.append(cleanup_preview_collections)
        elif len(matches) > 1:
            while sum(1 for item in tuple(exit_pre) if item is cleanup_preview_collections) > 1:
                exit_pre.remove(cleanup_preview_collections)
        # Exact callback identity proves Smart File ownership; adopt an interrupted
        # current-module registration so disable can still reach resource zero.
        _HANDLER_ACQUIRED = True
        load_pre = bpy.app.handlers.load_pre
        load_matches = [item for item in tuple(load_pre) if item is cleanup_preview_collections]
        if not load_matches:
            load_pre.append(cleanup_preview_collections)
        elif len(load_matches) > 1:
            while sum(1 for item in tuple(load_pre) if item is cleanup_preview_collections) > 1:
                load_pre.remove(cleanup_preview_collections)
        _LOAD_HANDLER_ACQUIRED = True
        _atexit.register(cleanup_preview_collections)
        _ATEXIT_ACQUIRED = True
        namespace[_OWNER_KEY] = {
            "schema": 1,
            "token": _OWNER_TOKEN,
            "generation": _GENERATION,
            "handler": cleanup_preview_collections,
            "exit_handler": cleanup_preview_collections,
            "load_handler": cleanup_preview_collections,
            "handler_acquired": _HANDLER_ACQUIRED,
            "load_handler_acquired": _LOAD_HANDLER_ACQUIRED,
            "atexit_acquired": _ATEXIT_ACQUIRED,
            "cleanup": _cleanup_generation,
        }
        return True
    except Exception:
        _cleanup_generation()
        return False


def unregister() -> bool:
    cleanup_preview_collections()
    return _cleanup_generation()


def register_atexit() -> bool:
    return register()


def unregister_atexit() -> bool:
    return unregister()


def runtime_status() -> dict:
    namespace = _namespace()
    owner = namespace.get(_OWNER_KEY) if namespace is not None else None
    handler_count = 0
    load_handler_count = 0
    if bpy is not None:
        try:
            handler_count = sum(1 for item in tuple(bpy.app.handlers.exit_pre) if item is cleanup_preview_collections)
        except Exception:
            handler_count = 0
        try:
            load_handler_count = sum(1 for item in tuple(bpy.app.handlers.load_pre) if item is cleanup_preview_collections)
        except Exception:
            load_handler_count = 0
    return {
        "owner_exact": bool(
            isinstance(owner, dict)
            and owner.get("token") is _OWNER_TOKEN
            and owner.get("generation") == _GENERATION
        ),
        "handler_exact_count": handler_count,
        "load_handler_exact_count": load_handler_count,
        "handler_acquired": bool(_HANDLER_ACQUIRED),
        "load_handler_acquired": bool(_LOAD_HANDLER_ACQUIRED),
        "atexit_acquired": bool(_ATEXIT_ACQUIRED),
        "preview_key_count": len(_PREVIEW_DRIVER_NAMESPACE_KEYS),
    }
