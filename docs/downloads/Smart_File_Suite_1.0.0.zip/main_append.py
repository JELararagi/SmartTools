from .ui_language_runtime import error_text as _sf_error_text
# -----------------------------------------------------------------------------
#  UIList
# -----------------------------------------------------------------------------


class SF_UL_items(bpy.types.UIList):
    bl_description = 'Show datablock rows found in the selected source .blend file so you can review names, filter the list, and choose exactly what to import next'
    def filter_items(self, context, data, propname):
        wm = context.window_manager
        flt = (getattr(wm, "sf_filter", "") or "").strip().lower()
        items = getattr(data, propname)

        flt_flags = []
        neworder = list(range(len(items)))

        for it in items:
            show = True
            if flt:
                show = flt in (it.name or "").lower()
            flt_flags.append(self.bitflag_filter_item if show else 0)

        sort = getattr(wm, "sf_sort", 'NAME_ASC')
        if sort in {'NAME_ASC', 'NAME_DESC'}:
            neworder.sort(
                key=lambda i: (items[i].name or "").lower(),
                reverse=(sort == 'NAME_DESC'),
            )

        return flt_flags, neworder

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        wm = context.window_manager
        mode = getattr(wm, "sf_mode", 'OBJECTS')
        row = layout.row(align=True)
        row.prop(item, "is_selected", text='')
        row.label(text=_sf_short_label_display(item.name, 58), icon=_mode_icon(mode), translate=False)


class SF_UL_cm_review_items(bpy.types.UIList):
    bl_description = 'Show catalog-merge review rows so you can check each proposed add, rename, metadata fill, or skip decision before applying changes'
    def draw_item(self, _context, layout, _data, item, _icon, _active_data, _active_propname, _index=0, _flt_flag=0):
        if self.layout_type not in {'DEFAULT', 'COMPACT'}:
            layout.label(text=item.label or item.action)
            return

        icon = 'DOT'
        if item.level == 'ROOT':
            icon = 'FILE_FOLDER'
        elif item.action == 'ADD_ASSET':
            icon = 'ASSET_MANAGER'
        elif item.action == 'RENAME_ASSET_KEY':
            icon = 'GREASEPENCIL'
        elif item.action == 'ADD_ENTRY':
            icon = 'ADD'
        elif item.action == 'FILL_METADATA':
            icon = 'FILE_TICK'
        elif item.action == 'SKIP_DUPLICATE':
            icon = 'NONE'

        row = layout.row(align=True)
        depth = max(0, int(getattr(item, 'depth', 0) or 0))
        for _ in range(depth):
            row.label(text='', icon='BLANK1')
        if bool(getattr(item, 'enabled', True)):
            op = row.operator(
                "import_scene.sfs_catalog_merge_toggle_selection_item",
                text='',
                emboss=True,
                icon='CHECKBOX_HLT' if bool(getattr(item, 'include', False)) else 'CHECKBOX_DEHLT',
            )
            op.index = int(_index)
            op.enable = not bool(getattr(item, 'include', False))
        else:
            row.label(text='', icon='BLANK1')
        col = row.column(align=True)
        col.label(text=item.label or item.action or item.level.title(), icon=icon)
        sub = col.row(align=True)
        if item.note:
            sub.label(text=item.note[:220])
        else:
            sub.label(text=(item.action or '')[:220])


def _sf_cm_get_active_item(prefs):
    if not prefs:
        return None
    items = _sf_cm_iter_items(prefs)
    idx = int(getattr(prefs, 'cm_review_active_index', 0) or 0)
    if idx < 0 or idx >= len(items):
        return None
    return items[idx]


_SF_CM_DETAIL_CACHE = {}


def _sf_cm_get_cached_root_review_data(prefs, root_path: str):
    root_path = _norm_path(root_path or '')
    if not prefs or not root_path or not os.path.isdir(root_path):
        return ({}, '', {})

    catalog_filename = getattr(prefs, 'pub_catalog_filename', 'catalog.json') or 'catalog.json'
    cache_key = (
        root_path,
        str(catalog_filename),
        bool(getattr(prefs, 'cm_review_only_orphans', True)),
        str(getattr(prefs, 'cm_review_category_mode', 'RELATIVE_FOLDER')),
        bool(getattr(prefs, 'cm_review_infer_preview', True)),
        bool(getattr(prefs, 'cm_review_infer_meta', True)),
    )
    cached = _SF_CM_DETAIL_CACHE.get('root_review')
    if cached and cached.get('key') == cache_key:
        return cached.get('payload') or {}, cached.get('target_catalog_path') or '', cached.get('existing_catalog') or {}

    payload, _selected, target_catalog_path = _sf_build_catalog_draft_payload_for_root(
        prefs,
        root_path,
        catalog_filename,
        only_orphans=bool(getattr(prefs, 'cm_review_only_orphans', True)),
        category_mode=str(getattr(prefs, 'cm_review_category_mode', 'RELATIVE_FOLDER')),
        infer_preview=bool(getattr(prefs, 'cm_review_infer_preview', True)),
        infer_meta=bool(getattr(prefs, 'cm_review_infer_meta', True)),
    )
    existing_catalog = _ar_load_catalog(target_catalog_path) if target_catalog_path and os.path.exists(target_catalog_path) else {}
    if not isinstance(existing_catalog, dict):
        existing_catalog = {}
    _SF_CM_DETAIL_CACHE['root_review'] = {
        'key': cache_key,
        'payload': payload,
        'target_catalog_path': target_catalog_path,
        'existing_catalog': existing_catalog,
    }
    return payload, target_catalog_path, existing_catalog


def _sf_cm_get_active_item_detail_lines(prefs, wrap_width: int = 78):
    item = _sf_cm_get_active_item(prefs)
    if not item:
        return [_t('No active review item')]

    def add_line(lines, label, value):
        value = '' if value is None else str(value)
        if value == '':
            return
        prefix = f"{label}: "
        wrapped = textwrap.wrap(value, width=max(24, int(wrap_width)), subsequent_indent='' * len(prefix)) or ['']
        if wrapped:
            lines.append(prefix + wrapped[0])
            for extra in wrapped[1:]:
                lines.append(extra)

    def yn(v):
        return 'ON' if bool(v) else 'OFF'

    level = str(getattr(item, 'level', '') or '')
    action = str(getattr(item, 'action', '') or '')
    root_path = _norm_path(getattr(item, 'root_path', '') or '')
    target_catalog_path = _norm_path(getattr(item, 'target_catalog_path', '') or '')
    draft_key = str(getattr(item, 'draft_key', '') or '')
    target_key = str(getattr(item, 'target_key', '') or '')
    entry_identity = str(getattr(item, 'entry_identity', '') or '')
    blend_rel = str(getattr(item, 'blend', '') or '')
    blend_abs = ''
    if blend_rel and target_catalog_path:
        blend_abs = _norm_path(os.path.join(os.path.dirname(target_catalog_path), blend_rel))

    payload, cached_target_catalog_path, existing_catalog = _sf_cm_get_cached_root_review_data(prefs, root_path)
    if not target_catalog_path and cached_target_catalog_path:
        target_catalog_path = cached_target_catalog_path
    draft_asset = {}
    existing_asset = {}
    draft_entry = {}
    existing_entry = {}

    assets = payload.get('assets') if isinstance(payload, dict) else {}
    if isinstance(assets, dict):
        draft_asset = assets.get(draft_key) if isinstance(assets.get(draft_key), dict) else {}

    existing_assets = existing_catalog.get('assets') if isinstance(existing_catalog, dict) else {}
    if isinstance(existing_assets, dict):
        existing_asset = existing_assets.get(target_key) if isinstance(existing_assets.get(target_key), dict) else {}

    if draft_asset and level in {'ENTRY', 'ASSET'}:
        for entry in list(draft_asset.get('entries', []) or []):
            if not isinstance(entry, dict):
                continue
            if level == 'ASSET':
                draft_entry = entry
                break
            ident = _sf_catalog_entry_identity(entry, os.path.dirname(target_catalog_path)) if target_catalog_path else ('', 0)
            if _sf_catalog_identity_token(ident) == entry_identity:
                draft_entry = entry
                break
        if (not draft_entry) and level == 'ENTRY' and blend_rel:
            for entry in list(draft_asset.get('entries', []) or []):
                if not isinstance(entry, dict):
                    continue
                if str(entry.get('blend') or '') == blend_rel and int(entry.get('version', 0) or 0) == int(getattr(item, 'version', 0) or 0):
                    draft_entry = entry
                    break

    if existing_asset and level in {'ENTRY', 'ASSET'}:
        if level == 'ASSET':
            existing_entries = [e for e in list(existing_asset.get('entries', []) or []) if isinstance(e, dict)]
            if existing_entries:
                existing_entry = existing_entries[0]
        else:
            for entry in list(existing_asset.get('entries', []) or []):
                if not isinstance(entry, dict):
                    continue
                ident = _sf_catalog_entry_identity(entry, os.path.dirname(target_catalog_path)) if target_catalog_path else ('', 0)
                if _sf_catalog_identity_token(ident) == entry_identity:
                    existing_entry = entry
                    break

    fillable = []
    if isinstance(existing_entry, dict) and isinstance(draft_entry, dict) and existing_entry and draft_entry:
        for field in ('preview', 'meta', 'category'):
            if (not str(existing_entry.get(field) or '').strip()) and str(draft_entry.get(field) or '').strip():
                fillable.append(field)
        cur_tags = existing_entry.get('tags')
        draft_tags = draft_entry.get('tags')
        if (not isinstance(cur_tags, list) or not cur_tags) and isinstance(draft_tags, list) and draft_tags:
            fillable.append('tags')

    lines = [_t('Selected item details')]
    add_line(lines, _t('Level'), level)
    add_line(lines, _t('Action'), action)
    add_line(lines, _t('Include'), yn(getattr(item, 'include', False)))
    add_line(lines, _t('Enabled'), yn(getattr(item, 'enabled', False)))
    add_line(lines, _t('Root Path'), root_path)
    add_line(lines, _t('Target Catalog'), target_catalog_path)
    add_line(lines, _t('Draft Asset Key'), draft_key)
    add_line(lines, _t('Target Asset Key'), target_key)
    add_line(lines, _t('Asset ID'), getattr(item, 'asset_id', ''))
    add_line(lines, _t('Entry Identity'), entry_identity)
    add_line(lines, _t('Blend Path'), blend_rel)
    add_line(lines, _t('Blend Absolute Path'), blend_abs)
    add_line(lines, _t('Version'), getattr(item, 'version', 0))
    add_line(lines, _t('Entry Count'), getattr(item, 'entry_count', 0))
    add_line(lines, _t('Note'), getattr(item, 'note', ''))
    add_line(lines, _t('Write target'), target_catalog_path if bool(getattr(prefs, 'cm_review_apply_changes', False)) else _t('Preview only'))

    if level in {'ASSET', 'ENTRY'}:
        lines.append('')
        add_line(lines, _t('Target asset exists'), yn(bool(existing_asset)))
        if level == 'ENTRY':
            add_line(lines, _t('Target entry exists'), yn(bool(existing_entry)))
        add_line(lines, _t('Latest'), draft_asset.get('latest') if isinstance(draft_asset, dict) else '')
        add_line(lines, _t('Draft source'), draft_entry.get('draft_source') if isinstance(draft_entry, dict) else '')
        add_line(lines, _t('Draft category'), draft_entry.get('category') if isinstance(draft_entry, dict) else '')
        add_line(lines, _t('Draft preview'), draft_entry.get('preview') if isinstance(draft_entry, dict) else '')
        add_line(lines, _t('Draft meta'), draft_entry.get('meta') if isinstance(draft_entry, dict) else '')
        add_line(lines, _t('Target category'), existing_entry.get('category') if isinstance(existing_entry, dict) else '')
        add_line(lines, _t('Target preview'), existing_entry.get('preview') if isinstance(existing_entry, dict) else '')
        add_line(lines, _t('Target meta'), existing_entry.get('meta') if isinstance(existing_entry, dict) else '')
        tags = draft_entry.get('tags') if isinstance(draft_entry, dict) else []
        if isinstance(tags, list) and tags:
            add_line(lines, _t('Tags'), ','.join([str(t) for t in tags]))
        if fillable:
            add_line(lines, _t('Fields to fill'), ','.join(fillable))

    selected_fields = []
    if bool(getattr(item, 'ovr_has_preview', False)) and bool(getattr(item, 'ovr_use_preview', False)):
        selected_fields.append('preview')
    if bool(getattr(item, 'ovr_has_meta', False)) and bool(getattr(item, 'ovr_use_meta', False)):
        selected_fields.append('meta')
    if bool(getattr(item, 'ovr_has_category', False)) and bool(getattr(item, 'ovr_use_category', False)):
        selected_fields.append('category')
    if bool(getattr(item, 'ovr_has_tags', False)) and bool(getattr(item, 'ovr_use_tags', False)):
        selected_fields.append('tags')
    if selected_fields:
        add_line(lines, _t('Selected fields'), ','.join(selected_fields))
    if bool(getattr(item, 'ovr_has_key_rename', False)):
        add_line(lines, _t('Allow key rename'), yn(getattr(item, 'ovr_allow_key_rename', True)))

    return lines



# -----------------------------------------------------------------------------
#  Override preset helpers
# -----------------------------------------------------------------------------

def _sf_cm_get_active_preset(prefs):
    if not prefs:
        return None
    presets = list(getattr(prefs, 'cm_override_presets', []) or [])
    if not presets:
        return None
    idx = int(getattr(prefs, 'cm_preset_active_index', 0) or 0)
    idx = max(0, min(idx, len(presets) - 1))
    prefs.cm_preset_active_index = idx
    return presets[idx]


def _sf_cm_find_preset_index(prefs, name: str) -> int:
    if not prefs:
        return -1
    target = str(name or '').strip()
    if not target:
        return -1
    for idx, preset in enumerate(list(getattr(prefs, 'cm_override_presets', []) or [])):
        if str(getattr(preset, 'name', '') or '').strip() == target:
            return idx
    return -1


def _sf_cm_preset_name_from_active_item(prefs) -> str:
    item = _sf_cm_get_active_item(prefs) if prefs else None
    if item:
        label = str(getattr(item, 'label', '') or '').strip()
        action = str(getattr(item, 'action', '') or '').strip()
        if label:
            return f"{action or 'PRESET'} | {label[:48]}"
        if action:
            return action
    return 'Override Preset'


def _sf_cm_copy_item_to_preset(item, preset):
    if not item or not preset:
        return
    action = str(getattr(item, 'action', '') or '').strip()
    preset.action_filter = action if action in {'ADD_ASSET', 'ADD_ENTRY', 'FILL_METADATA', 'RENAME_ASSET_KEY'} else 'ANY'
    preset.use_preview = bool(getattr(item, 'ovr_use_preview', False))
    preset.use_meta = bool(getattr(item, 'ovr_use_meta', False))
    preset.use_category = bool(getattr(item, 'ovr_use_category', False))
    preset.use_tags = bool(getattr(item, 'ovr_use_tags', False))
    preset.allow_key_rename = bool(getattr(item, 'ovr_allow_key_rename', True))


def _sf_cm_apply_preset_to_item(item, preset) -> bool:
    if not item or not preset:
        return False
    p_action = str(getattr(preset, 'action_filter', 'ANY') or 'ANY')
    action = str(getattr(item, 'action', '') or '')
    if p_action != 'ANY' and action != p_action:
        return False
    changed = False
    if bool(getattr(item, 'ovr_has_preview', False)):
        val = bool(getattr(preset, 'use_preview', False))
        if bool(getattr(item, 'ovr_use_preview', False)) != val:
            item.ovr_use_preview = val
            changed = True
    if bool(getattr(item, 'ovr_has_meta', False)):
        val = bool(getattr(preset, 'use_meta', False))
        if bool(getattr(item, 'ovr_use_meta', False)) != val:
            item.ovr_use_meta = val
            changed = True
    if bool(getattr(item, 'ovr_has_category', False)):
        val = bool(getattr(preset, 'use_category', False))
        if bool(getattr(item, 'ovr_use_category', False)) != val:
            item.ovr_use_category = val
            changed = True
    if bool(getattr(item, 'ovr_has_tags', False)):
        val = bool(getattr(preset, 'use_tags', False))
        if bool(getattr(item, 'ovr_use_tags', False)) != val:
            item.ovr_use_tags = val
            changed = True
    if bool(getattr(item, 'ovr_has_key_rename', False)):
        val = bool(getattr(preset, 'allow_key_rename', True))
        if bool(getattr(item, 'ovr_allow_key_rename', True)) != val:
            item.ovr_allow_key_rename = val
            changed = True
    return changed


def _sf_cm_apply_preset(prefs, preset, scope: str = 'MATCHING') -> int:
    if not prefs or not preset:
        return 0
    changed = 0
    scope = str(scope or 'MATCHING')
    active = _sf_cm_get_active_item(prefs)
    if scope == 'ACTIVE':
        return 1 if _sf_cm_apply_preset_to_item(active, preset) else 0
    for item in _sf_cm_iter_items(prefs):
        if scope == 'ENABLED' and not bool(getattr(item, 'enabled', True)):
            continue
        if scope == 'MATCHING' and not bool(getattr(item, 'enabled', True)):
            continue
        if _sf_cm_apply_preset_to_item(item, preset):
            changed += 1
    return changed


def _sf_cm_preset_to_dict(preset) -> dict:
    return {
        'name': str(getattr(preset, 'name', '') or ''),
        'action_filter': str(getattr(preset, 'action_filter', 'ANY') or 'ANY'),
        'use_preview': bool(getattr(preset, 'use_preview', False)),
        'use_meta': bool(getattr(preset, 'use_meta', False)),
        'use_category': bool(getattr(preset, 'use_category', False)),
        'use_tags': bool(getattr(preset, 'use_tags', False)),
        'allow_key_rename': bool(getattr(preset, 'allow_key_rename', True)),
    }


def _sf_cm_load_preset_from_dict(preset, data: dict):
    preset.name = str((data or {}).get('name') or '').strip() or 'Imported Preset'
    action = str((data or {}).get('action_filter') or 'ANY')
    if action not in {'ANY', 'ADD_ASSET', 'ADD_ENTRY', 'FILL_METADATA', 'RENAME_ASSET_KEY'}:
        action = 'ANY'
    preset.action_filter = action
    preset.use_preview = bool((data or {}).get('use_preview', False))
    preset.use_meta = bool((data or {}).get('use_meta', False))
    preset.use_category = bool((data or {}).get('use_category', False))
    preset.use_tags = bool((data or {}).get('use_tags', False))
    preset.allow_key_rename = bool((data or {}).get('allow_key_rename', True))


def _sf_cm_find_preset_by_name(prefs, name: str):
    target = str(name or '').strip()
    if not prefs or not target:
        return None
    for preset in list(getattr(prefs, 'cm_override_presets', []) or []):
        if str(getattr(preset, 'name', '') or '').strip() == target:
            return preset
    return None


def _sf_cm_get_active_route(prefs):
    routes = list(getattr(prefs, 'cm_override_routes', []) or [])
    if not routes:
        return None
    idx = int(getattr(prefs, 'cm_route_active_index', 0) or 0)
    idx = max(0, min(idx, len(routes) - 1))
    prefs.cm_route_active_index = idx
    return routes[idx]


def _sf_cm_find_route_index(prefs, name: str) -> int:
    target = str(name or '').strip()
    if not prefs or not target:
        return -1
    for idx, route in enumerate(list(getattr(prefs, 'cm_override_routes', []) or [])):
        if str(getattr(route, 'name', '') or '').strip() == target:
            return idx
    return -1


def _sf_cm_copy_ui_to_route(prefs, route):
    if not prefs or not route:
        return
    route.name = str(getattr(prefs, 'cm_route_name', '') or '').strip() or 'Route'
    action = str(getattr(prefs, 'cm_route_action_filter', 'ANY') or 'ANY')
    if action not in {'ANY', 'ADD_ASSET', 'ADD_ENTRY', 'FILL_METADATA', 'RENAME_ASSET_KEY'}:
        action = 'ANY'
    route.action_filter = action
    route.root_filter = str(getattr(prefs, 'cm_route_root_filter', '') or '').strip()
    route.category_filter = str(getattr(prefs, 'cm_route_category_filter', '') or '').strip()
    preset = _sf_cm_get_active_preset(prefs)
    route.preset_name = str(getattr(preset, 'name', '') or '').strip() if preset else ''


def _sf_cm_copy_route_to_ui(prefs, route):
    if not prefs or not route:
        return
    prefs.cm_route_name = str(getattr(route, 'name', '') or '')
    prefs.cm_route_action_filter = str(getattr(route, 'action_filter', 'ANY') or 'ANY')
    prefs.cm_route_root_filter = str(getattr(route, 'root_filter', '') or '')
    prefs.cm_route_category_filter = str(getattr(route, 'category_filter', '') or '')


def _sf_cm_route_matches_item(route, item) -> bool:
    if not route or not item:
        return False
    if not bool(getattr(route, 'enabled', True)):
        return False
    action = str(getattr(route, 'action_filter', 'ANY') or 'ANY')
    item_action = str(getattr(item, 'action', '') or '')
    if action != 'ANY' and action != item_action:
        return False
    root_filter = str(getattr(route, 'root_filter', '') or '').strip().lower()
    if root_filter:
        root_path = str(getattr(item, 'root_path', '') or '')
        root_name = os.path.basename(_norm_path(root_path))
        hay = f"{root_path} {root_name}".lower()
        if root_filter not in hay:
            return False
    cat_filter = str(getattr(route, 'category_filter', '') or '').strip().lower()
    if cat_filter:
        cat = str(getattr(item, 'draft_category', '') or '').strip().lower()
        if cat_filter not in cat:
            return False
    return True


def _sf_cm_apply_routes(prefs, items=None, enabled_only: bool = True) -> int:
    if not prefs:
        return 0
    routes = list(getattr(prefs, 'cm_override_routes', []) or [])
    if not routes:
        return 0
    changed = 0
    rows = list(items if items is not None else _sf_cm_iter_items(prefs))
    for item in rows:
        if enabled_only and not bool(getattr(item, 'enabled', True)):
            continue
        for route in routes:
            if not _sf_cm_route_matches_item(route, item):
                continue
            preset = _sf_cm_find_preset_by_name(prefs, str(getattr(route, 'preset_name', '') or ''))
            if not preset:
                continue
            if _sf_cm_apply_preset_to_item(item, preset):
                changed += 1
            break
    return changed


# -----------------------------------------------------------------------------
#  Operators: Preferences path management
# -----------------------------------------------------------------------------


class SF_OT_source_browser_use(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_source_browser_use'
    bl_label = 'Use'
    bl_description = 'Load the selected recent or favorite .blend path into Smart File and reopen the browser'
    bl_options = {'UNDO', 'INTERNAL'}

    kind: EnumProperty(
        items=[('RECENT', "Recent", ""), ('FAVORITE', "Favorite", "")],
        description='Choose whether the saved path comes from the Recent list or the Favorites list',
    )
    index: IntProperty(description='Index of the saved path entry to use')

    def execute(self, context):
        prefs = _addon_prefs(context)
        if not prefs:
            return {'CANCELLED'}
        col = prefs.recent_paths if self.kind == 'RECENT' else prefs.favorite_paths
        if self.index < 0 or self.index >= len(col):
            return {'CANCELLED'}
        path = col[self.index].path
        if not path:
            return {'CANCELLED'}
        context.window_manager.sf_filepath = path
        _reload_items(context)
        bpy.ops.import_scene.sfs_source_browser_import_2('INVOKE_DEFAULT')
        _sf_append_activity(context, _t('Open current browser'), path, 'FILE_REFRESH')
        return {'FINISHED'}


class SF_OT_source_browser_remove(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_source_browser_remove'
    bl_label = 'Remove'
    bl_description = 'Remove the selected saved path from the Recent list or the Favorites list'
    bl_options = {'UNDO', 'INTERNAL'}

    kind: EnumProperty(
        items=[('RECENT', "Recent", ""), ('FAVORITE', "Favorite", "")],
        description='Choose whether the entry should be removed from Recent or Favorites',
    )
    index: IntProperty(description='Index of the saved path entry to remove')

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        prefs = _addon_prefs(context)
        if not prefs:
            return {'CANCELLED'}
        col = prefs.recent_paths if self.kind == 'RECENT' else prefs.favorite_paths
        if 0 <= self.index < len(col):
            removed_path = _norm_path(getattr(col[self.index], 'path', '') or '')
            col.remove(self.index)
            if removed_path:
                self.report({'INFO'}, f"{_t('Removed')}: {removed_path}")
        return {'FINISHED'}


class SF_OT_source_browser_add_current_file_to_favorites(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_source_add_current_favorite'
    bl_label = 'Add current file to Favorites'
    bl_description = 'Save the currently selected source .blend file to the Favorites list for quick reuse'
    bl_options = {'UNDO', 'INTERNAL'}

    def execute(self, context):
        prefs = _addon_prefs(context)
        if not prefs:
            return {'CANCELLED'}
        fp = _norm_path(getattr(context.window_manager, "sf_filepath", ""))
        if not fp:
            return {'CANCELLED'}
        for i in range(len(prefs.favorite_paths) - 1, -1, -1):
            if _norm_path(prefs.favorite_paths[i].path) == fp:
                prefs.favorite_paths.remove(i)
        it = prefs.favorite_paths.add()
        it.path = fp
        prefs.favorite_paths.move(len(prefs.favorite_paths) - 1, 0)
        return {'FINISHED'}


def _sf_current_source_is_favorite(context) -> bool:
    prefs = _addon_prefs(context)
    if not prefs:
        return False
    fp = _norm_path(getattr(context.window_manager, "sf_filepath", ""))
    if not fp:
        return False
    for item in getattr(prefs, 'favorite_paths', []) or []:
        if _norm_path(getattr(item, 'path', '') or '') == fp:
            return True
    return False


class SF_OT_source_browser_toggle_favorite(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_source_browser_toggle_favorite'
    bl_label = 'Toggle Favorite'
    bl_description = 'Add the current source .blend file to Favorites for quick reuse, or remove it if it is already saved there.'
    bl_options = {'UNDO', 'INTERNAL'}

    def execute(self, context):
        prefs = _addon_prefs(context)
        if not prefs:
            return {'CANCELLED'}
        fp = _norm_path(getattr(context.window_manager, "sf_filepath", ""))
        if not fp:
            self.report({'WARNING'}, _t('File not found'))
            return {'CANCELLED'}
        removed = False
        for i in range(len(prefs.favorite_paths) - 1, -1, -1):
            if _norm_path(prefs.favorite_paths[i].path) == fp:
                prefs.favorite_paths.remove(i)
                removed = True
        if removed:
            self.report({'INFO'}, _t('Favorite removed'))
            return {'FINISHED'}
        it = prefs.favorite_paths.add()
        it.path = fp
        prefs.favorite_paths.move(len(prefs.favorite_paths) - 1, 0)
        self.report({'INFO'}, _t('Favorite added'))
        return {'FINISHED'}


class SF_OT_source_browser_copy_path(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_source_browser_copy_path'
    bl_label = 'Copy Path'
    bl_description = 'Copy the current source .blend path to the clipboard'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    target: EnumProperty(
        items=[('FILE', "File", ""), ('FOLDER', "Folder", "")],
        default='FILE',
        options={'HIDDEN'},
    )

    def execute(self, context):
        filepath = _norm_path(getattr(context.window_manager, "sf_filepath", ""))
        if not filepath:
            self.report({'WARNING'}, _t('File not found'))
            return {'CANCELLED'}
        value = filepath
        if self.target == 'FOLDER':
            value = os.path.dirname(filepath)
        if not value:
            self.report({'WARNING'}, _t('File not found'))
            return {'CANCELLED'}
        try:
            context.window_manager.clipboard = value
        except Exception:
            self.report({'WARNING'}, _t('Operation failed'))
            return {'CANCELLED'}
        self.report({'INFO'}, f"{_t('Copied to clipboard')}: {value}")
        return {'FINISHED'}


class SF_OT_source_browser_cleanup_saved_paths(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_source_browser_cleanup_saved_paths'
    bl_label = 'Cleanup Saved Paths'
    bl_description = 'Remove missing entries, deduplicate paths, and optionally sort a quick access list'
    bl_options = {'UNDO', 'INTERNAL'}

    kind: EnumProperty(
        name='Cleanup Mode',
        items=[('RECENT', "Recent", ""), ('FAVORITE', "Favorite", ""), ('BOTH', "Both", "")],
        default='BOTH',
    )
    remove_missing: BoolProperty(name='Remove missing files', default=True)
    deduplicate: BoolProperty(name='Remove duplicate paths', default=True)
    sort_alpha: BoolProperty(name='Sort alphabetically', default=False)

    def execute(self, context):
        prefs = _addon_prefs(context)
        if not prefs:
            return {'CANCELLED'}

        collections = []
        if self.kind in {'RECENT', 'BOTH'}:
            collections.append(('RECENT', prefs.recent_paths))
        if self.kind in {'FAVORITE', 'BOTH'}:
            collections.append(('FAVORITE', prefs.favorite_paths))

        total_missing = 0
        total_dup = 0
        total_sorted = 0

        for name, col in collections:
            original = [_norm_path(getattr(it, 'path', '') or '') for it in col]
            cleaned = []
            seen = set()
            missing = 0
            dup = 0
            for path in original:
                if not path:
                    continue
                if self.remove_missing and not os.path.isfile(path):
                    missing += 1
                    continue
                if self.deduplicate and path in seen:
                    dup += 1
                    continue
                seen.add(path)
                cleaned.append(path)
            if self.sort_alpha:
                cleaned.sort(key=lambda p: ((os.path.basename(p) or p).lower(), p.lower()))
                if cleaned != [p for p in original if p and (not self.remove_missing or os.path.isfile(p))][:len(cleaned)]:
                    total_sorted += 1
            total_missing += missing
            total_dup += dup
            while len(col):
                col.remove(len(col) - 1)
            for path in cleaned:
                it = col.add()
                it.path = path
        if not (total_missing or total_dup or total_sorted):
            self.report({'INFO'}, _t('No quick-list cleanup changes were needed'))
            return {'FINISHED'}
        parts = []
        if total_missing:
            parts.append(f"{total_missing} {_t('removed missing')}")
        if total_dup:
            parts.append(f"{total_dup} {_t('removed duplicates')}")
        if total_sorted:
            parts.append(f"{total_sorted} {_t('sorted')}")
        self.report({'INFO'}, f"{_t('Cleaned')}: " + ','.join(parts))
        return {'FINISHED'}


class SF_OT_source_browser_import(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_source_browser_import'
    bl_label = 'Import'
    bl_description = 'Open the Smart File import dialog. If no source scene is selected yet, choose a .blend scene file directly inside the dialog before browsing or importing.'
    bl_options = {'UNDO', 'INTERNAL'}

    def execute(self, context):
        wm = context.window_manager
        filepath = _norm_path(getattr(wm, "sf_filepath", ""))
        if filepath and os.path.isfile(filepath):
            _reload_items(context)
        else:
            wm.sf_filepath = ""
        bpy.ops.import_scene.sfs_source_browser_import_2('INVOKE_DEFAULT')
        return {'FINISHED'}


class SF_OT_source_browser_open_folder(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_source_browser_open_folder'
    bl_label = 'Open Folder'
    bl_description = 'Open the folder that contains the currently selected source .blend file in your operating system file browser. Use this when you want to confirm nearby files, textures, caches, or alternate scene files before importing.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def execute(self, context):
        filepath = _norm_path(getattr(context.window_manager, "sf_filepath", ""))
        if not filepath or not os.path.isfile(filepath):
            self.report({'WARNING'}, _t('File not found'))
            return {'CANCELLED'}
        folder = os.path.dirname(filepath)
        if not folder:
            self.report({'WARNING'}, _t('File not found'))
            return {'CANCELLED'}
        try:
            bpy.ops.wm.path_open(filepath=folder)
        except Exception as exc:
            self.report({'WARNING'}, _sf_error_text(exc))
            return {'CANCELLED'}
        _sf_append_activity(context, _t('Opened source folder'), folder, 'FILE_FOLDER')
        return {'FINISHED'}


class SF_OT_source_browser_clear_saved_paths(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_source_browser_clear_saved_paths'
    bl_label = 'Clear Saved Paths'
    bl_description = 'Remove every saved path from the selected quick access list'
    bl_options = {'UNDO', 'INTERNAL'}

    kind: EnumProperty(
        items=[('RECENT', "Recent", ""), ('FAVORITE', "Favorite", "")],
        description='Choose which quick access list should be cleared',
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        prefs = _addon_prefs(context)
        if not prefs:
            return {'CANCELLED'}
        col = prefs.recent_paths if self.kind == 'RECENT' else prefs.favorite_paths
        cleared = len(col)
        while len(col):
            col.remove(len(col) - 1)
        if cleared:
            self.report({'INFO'}, f"{_t('Cleared')}: {cleared}")
        return {'FINISHED'}


# -----------------------------------------------------------------------------
#  Operators: Selection helpers
# -----------------------------------------------------------------------------


class SF_OT_source_browser_select_all(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_source_browser_select_all'
    bl_label = 'Select All'
    bl_description = 'Select all, clear all, or invert the check state of the datablocks currently listed in the import browser. Use this to prepare many items quickly before you run the import.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    action: EnumProperty(
        name='Action',
        items=[
            ('SELECT', "Select", 'Turn on the check box for every datablock currently shown in the browser.'),
            ('DESELECT', "Deselect", 'Turn off the check box for every datablock currently shown in the browser.'),
            ('INVERT', "Invert", 'Flip the current check state so checked items become unchecked and unchecked items become checked.'),
        ],
        description='Choose how the current browser selection should be changed before import.',
    )

    def execute(self, context):
        wm = context.window_manager
        if self.action == 'SELECT':
            for it in wm.sf_items:
                it.is_selected = True
        elif self.action == 'DESELECT':
            for it in wm.sf_items:
                it.is_selected = False
        else:
            for it in wm.sf_items:
                it.is_selected = not it.is_selected
        return {'FINISHED'}


# -----------------------------------------------------------------------------
#  Operator: File picker
# -----------------------------------------------------------------------------


def _update_mode(_self, context):
    # When mode is changed in the dialog, reload the list for the same filepath.
    _reload_items(context)


class SF_OT_source_browser_scene_select(bpy.types.Operator):
    """Use the path typed in the source field as the active import source."""

    bl_idname = 'import_scene.sfs_source_browser_scene_select'
    bl_label = 'Scene Select'
    bl_description = 'Use the path currently written in the source field as the active .blend scene source, scan it again, and refresh the import list without leaving the dialog. This is useful after you paste or edit a path manually.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def execute(self, context):
        wm = context.window_manager
        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')
        if not filepath:
            self.report({'WARNING'}, _tr('Invalid file'))
            return {'CANCELLED'}
        if not os.path.exists(filepath):
            self.report({'WARNING'}, _tr('The file does not exist'))
            return {'CANCELLED'}
        wm.sf_filepath = filepath
        _add_recent(context, filepath)
        _reload_items(context)
        return {'FINISHED'}


class SF_OT_source_browser_open_folder_2(bpy.types.Operator, ImportHelper):
    """Select a .blend file and open the item picker dialog."""

    bl_idname = 'import_scene.sfs_source_browser_open_folder_2'
    bl_label = 'Open Folder'
    bl_description = 'Open a file browser so you can pick another source .blend scene file from disk and immediately refresh the import list for that file. Use this when you want to browse to a different folder instead of typing a path by hand.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    filter_glob: StringProperty(default="*.blend", options={'HIDDEN'})

    def execute(self, context):
        filepath = _norm_path(self.filepath)
        if not filepath:
            self.report({'WARNING'}, _tr('Invalid file'))
            return {'CANCELLED'}
        if not os.path.exists(filepath):
            self.report({'WARNING'}, _tr('The file does not exist'))
            return {'CANCELLED'}

        wm = context.window_manager
        wm.sf_filepath = filepath
        _add_recent(context, filepath)
        _reload_items(context)
        bpy.ops.import_scene.sfs_source_browser_import_2('INVOKE_DEFAULT')
        return {'FINISHED'}


# -----------------------------------------------------------------------------
#  Dialog operator (main)
# -----------------------------------------------------------------------------


class SF_OT_source_browser_import_2(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_source_browser_import_2'
    bl_label = 'Import'
    bl_description = 'Browse a source .blend file, choose the datablocks you need, and import them with options for dependency handling, naming, organization, and placement.'
    bl_options = {'UNDO', 'INTERNAL'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=720)

    def draw(self, context):
        wm = context.window_manager
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        filepath = _norm_path(getattr(wm, 'sf_filepath', '') or '')
        has_source = bool(filepath and os.path.isfile(filepath))
        listed_count = len(getattr(wm, 'sf_items', []))
        selected_count = sum(1 for it in getattr(wm, 'sf_items', []) if bool(getattr(it, 'is_selected', False)))

        scene_item_mode = wm.sf_mode in {'OBJECTS', 'COLLECTIONS'}
        object_mode = (wm.sf_mode == 'OBJECTS')

        top = layout.box()

        source_row = top.row(align=True)
        source_row.use_property_split = False
        source_row.use_property_decorate = False
        field = source_row.row(align=True)
        field.prop(wm, 'sf_filepath', text=_t('Source'))
        tools = source_row.row(align=True)
        tools.operator(SF_OT_source_browser_scene_select.bl_idname, text='', icon='FILE_TICK', emboss=True)
        tools.operator(SF_OT_source_browser_open_folder_2.bl_idname, text='', icon='FILE_FOLDER', emboss=True)
        folder_btn = tools.row(align=True)
        folder_btn.enabled = has_source
        folder_btn.operator(SF_OT_source_browser_open_folder.bl_idname, text='', icon='FOLDER_REDIRECT', emboss=True)
        fav_icon = 'HEART' if _sf_current_source_is_favorite(context) else 'SOLO_OFF'
        tools.operator(SF_OT_source_browser_toggle_favorite.bl_idname, text='', icon=fav_icon, emboss=True)

        filter_row = top.row(align=True)
        filter_row.prop(wm, 'sf_mode', text=_t('Type'))
        filter_row.prop(wm, 'sf_filter', text=_t('Search'))
        filter_row.prop(wm, 'sf_sort', text=_t('Sort'))

        batch_row = top.row(align=True)
        batch_row.operator(SF_OT_source_browser_select_all.bl_idname, text=_t('Select All')).action = 'SELECT'
        batch_row.operator(SF_OT_source_browser_select_all.bl_idname, text=_t('Select All')).action = 'DESELECT'
        batch_row.operator(SF_OT_source_browser_select_all.bl_idname, text=_t('Select All')).action = 'INVERT'
        batch_row.label(text=f"{_t('Listed')}: {listed_count}")
        batch_row.label(text=f"{_t('Selected')}: {selected_count}")

        if listed_count:
            layout.template_list('SF_UL_items', '', wm, 'sf_items', wm, 'sf_active_index', rows=8)
        else:
            msg = layout.box()
            msg.label(text=_t('No datablocks found'))
            msg.label(text=_t('Change the source, type, or search text.'), icon='BLANK1')

        split = layout.split(factor=0.52)
        left = split.column(align=True)
        right = split.column(align=True)

        box = left.box()
        box.label(text=_t('Import'), icon='IMPORT')
        box.prop(wm, 'sf_import_mode', text=_t('Mode'))
        box.prop(wm, 'sf_strict_loader', text=_t('Strict Loader'))

        name_box = left.box()
        name_box.label(text=_t('Naming'), icon='SORTALPHA')
        name_box.prop(wm, 'sf_prefix', text=_t('Prefix'))
        name_box.prop(wm, 'sf_collision', text=_t('Collision'))
        name_box.prop(wm, 'sf_apply_prefix_to_linked', text=_t('Prefix Linked'))

        dep_box = left.box()
        dep_box.label(text=_t('Dependency'), icon='CONSTRAINT')
        dep_body = dep_box.column(align=True)
        dep_body.enabled = object_mode and (not wm.sf_strict_loader)
        dep_body.prop(wm, 'sf_include_dependencies', text=_t('Include'))
        dep_body.prop(wm, 'sf_bake_world', text=_t('Bake World'))
        sub = dep_body.column(align=True)
        sub.enabled = bool(wm.sf_bake_world)
        sub.prop(wm, 'sf_clear_parent', text=_t('Clear Parent'))
        sub.prop(wm, 'sf_clear_constraints', text=_t('Clear Constraints'))
        if not object_mode:
            dep_box.label(text=_t('Objects only'))

        org_box = right.box()
        org_box.label(text=_t('Organization'), icon='OUTLINER_COLLECTION')
        org_box.prop(wm, 'sf_put_in_collection', text=_t('Use Collection'))
        sub = org_box.column(align=True)
        sub.enabled = scene_item_mode and wm.sf_put_in_collection
        sub.prop(wm, 'sf_collection_name_mode', text=_t('Name By'))
        if wm.sf_collection_name_mode == 'CUSTOM':
            sub.prop(wm, 'sf_collection_name', text=_t('Collection'))

        place_box = right.box()
        place_box.label(text=_t('Placement'), icon='EMPTY_AXIS')
        body = place_box.column(align=True)
        body.enabled = scene_item_mode
        body.prop(wm, 'sf_placement', text=_t('Mode'))
        body.prop(wm, 'sf_offset', text=_t('Offset'))
        grid = body.column(align=True)
        grid.enabled = scene_item_mode and (wm.sf_placement == 'GRID')
        grid.prop(wm, 'sf_grid_spacing', text=_t('Spacing'))
        grid.prop(wm, 'sf_grid_columns', text=_t('Columns'))
        if not scene_item_mode:
            place_box.label(text=_t('Objects / Collections only'))

        after_box = right.box()
        after_box.label(text=_t('After Import'), icon='CHECKMARK')
        body = after_box.column(align=True)
        body.enabled = scene_item_mode
        body.prop(wm, 'sf_select_imported', text=_t('Select Imported'))
        body.prop(wm, 'sf_frame_view', text=_t('Frame View'))

    def execute(self, context):
        wm = context.window_manager
        filepath = _norm_path(wm.sf_filepath)
        if not filepath:
            self.report({'WARNING'}, _tr('Invalid file'))
            return {'CANCELLED'}
        if not os.path.exists(filepath):
            self.report({'WARNING'}, _tr('The file does not exist'))
            return {'CANCELLED'}

        mode = wm.sf_mode
        names_selected = [it.name for it in wm.sf_items if it.is_selected]
        if not names_selected:
            self.report({'WARNING'}, _tr('No items selected'))
            return {'CANCELLED'}

        import_mode = wm.sf_import_mode
        do_link = (import_mode in {'LINK', 'LINK_OVERRIDE'})
        do_override = (import_mode == 'LINK_OVERRIDE')

        # Decide destination collection
        dest_col = context.collection
        if wm.sf_put_in_collection and mode in {'OBJECTS', 'COLLECTIONS'}:
            base_name = os.path.splitext(os.path.basename(filepath))[0]
            col_name = base_name if wm.sf_collection_name_mode == 'FILE' else (wm.sf_collection_name or base_name)
            dest_col = _ensure_collection(context, col_name)

        prefix = (wm.sf_prefix or "").strip()
        collision = wm.sf_collision
        prefs = _addon_prefs(context)
        apply_prefix_to_linked = bool(getattr(prefs, "apply_prefix_to_linked", False)) if prefs else False
        if wm.sf_apply_prefix_to_linked:
            apply_prefix_to_linked = True

        imported_objects: list[bpy.types.Object] = []
        imported_ids = []

        # Preserve current selection (we may override it)
        prev_active = context.view_layer.objects.active
        prev_selected = list(context.selected_objects)

        try:
            # Start with exactly the user's selection.
            names_to_load = list(names_selected)

            # Collision handling for local IDs
            def _remove_existing_id(collection, name):
                try:
                    existing = collection.get(name)
                    if existing is not None:
                        collection.remove(existing, do_unlink=True)
                except Exception:
                    pass

            if not do_link and collision == 'REPLACE':
                if mode == 'OBJECTS':
                    for n in names_to_load:
                        _remove_existing_id(bpy.data.objects, n)
                elif mode == 'COLLECTIONS':
                    for n in names_to_load:
                        _remove_existing_id(bpy.data.collections, n)
                elif mode == 'MATERIALS':
                    for n in names_to_load:
                        _remove_existing_id(bpy.data.materials, n)
                elif mode == 'NODE_GROUPS':
                    for n in names_to_load:
                        _remove_existing_id(bpy.data.node_groups, n)
                elif mode == 'ACTIONS':
                    for n in names_to_load:
                        _remove_existing_id(bpy.data.actions, n)
                elif mode == 'WORLDS':
                    for n in names_to_load:
                        _remove_existing_id(bpy.data.worlds, n)

            existing_reuse_ids = []
            if not do_link and collision == 'REUSE':
                # Skip loading items that already exist locally; reuse them instead.
                def _exists(collection, name):
                    try:
                        return collection.get(name) is not None
                    except Exception:
                        return False

                def _get(collection, name):
                    try:
                        return collection.get(name)
                    except Exception:
                        return None

                if mode == 'OBJECTS':
                    existing_reuse_ids = [
                        _get(bpy.data.objects, n) for n in names_selected if _exists(bpy.data.objects, n)
                    ]
                    names_to_load = [n for n in names_to_load if not _exists(bpy.data.objects, n)]
                elif mode == 'COLLECTIONS':
                    existing_reuse_ids = [
                        _get(bpy.data.collections, n) for n in names_selected if _exists(bpy.data.collections, n)
                    ]
                    names_to_load = [n for n in names_to_load if not _exists(bpy.data.collections, n)]
                elif mode == 'MATERIALS':
                    names_to_load = [n for n in names_to_load if not _exists(bpy.data.materials, n)]
                elif mode == 'NODE_GROUPS':
                    names_to_load = [n for n in names_to_load if not _exists(bpy.data.node_groups, n)]
                elif mode == 'ACTIONS':
                    names_to_load = [n for n in names_to_load if not _exists(bpy.data.actions, n)]
                elif mode == 'WORLDS':
                    names_to_load = [n for n in names_to_load if not _exists(bpy.data.worlds, n)]

            # Load the requested datablocks
            if wm.sf_strict_loader:
                # Strict: use wm.append/link to match Blender's dependency behavior more closely.
                loaded = _strict_load_with_wm_append(context, filepath, mode, names_to_load, do_link)
                loaded = [x for x in loaded if x is not None]
            else:
                # Fast: bpy.data.libraries.load
                with bpy.data.libraries.load(filepath, link=do_link) as (data_from, data_to):
                    attr = _data_from_attr_for_mode(mode)
                    available = set(getattr(data_from, attr, []))
                    load_names = [n for n in names_to_load if n in available]
                    setattr(data_to, attr, load_names)

                loaded = getattr(data_to, _data_from_attr_for_mode(mode), [])
                loaded = [x for x in loaded if x is not None]

            # If this import came from Asset Reader Catalog, tag the linked library with the asset_id
            # so Reference Manager can relink by ID even if filenames change.
            if do_link:
                cur_aid = getattr(wm, "sf_current_asset_id", "") or ""
                if cur_aid:
                    _sf_set_library_asset_id(filepath, cur_aid)


            # Best-effort: load additional related objects for OBJECTS.
            # (Works only when relationships can be resolved to actual object pointers.)
            if mode == 'OBJECTS' and wm.sf_include_dependencies and (not wm.sf_strict_loader):
                try:
                    loaded_objs = [o for o in loaded if isinstance(o, bpy.types.Object)]
                    related = _compute_related_object_names(loaded_objs)
                    related = set(related) - set([o.name for o in loaded_objs])
                    if related:
                        with bpy.data.libraries.load(filepath, link=do_link) as (data_from2, data_to2):
                            available2 = set(getattr(data_from2, 'objects', []))
                            extra_names = [n for n in sorted(related) if n in available2]
                            data_to2.objects = extra_names
                        extras = [o for o in data_to2.objects if o is not None]
                        for o in extras:
                            if o not in loaded:
                                loaded.append(o)
                except Exception:
                    pass

            # For REUSE (objects/collections), add existing IDs back into 'loaded'
            if existing_reuse_ids:
                for ex in existing_reuse_ids:
                    if ex is not None and ex not in loaded:
                        loaded.append(ex)

            imported_ids = loaded

            # Link to destination (objects/collections)
            if mode == 'OBJECTS':
                for obj in loaded:
                    if not isinstance(obj, bpy.types.Object):
                        continue
                    # Link into destination collection. Blender's object collections
                    # are ID collections, so use .get()/name iteration instead of string
                    # membership tests to avoid false negatives and skipped links.
                    try:
                        already_linked = False
                        getter = getattr(dest_col.objects, 'get', None)
                        if callable(getter):
                            try:
                                already_linked = getter(obj.name) is not None
                            except Exception:
                                already_linked = False
                        if not already_linked:
                            try:
                                already_linked = any(getattr(item, 'name', '') == obj.name for item in dest_col.objects)
                            except Exception:
                                already_linked = False
                        if not already_linked:
                            dest_col.objects.link(obj)
                    except Exception:
                        # If already linked elsewhere, link might fail
                        try:
                            dest_col.objects.link(obj)
                        except Exception:
                            pass
                    imported_objects.append(obj)

            elif mode == 'COLLECTIONS':
                for col in loaded:
                    if not isinstance(col, bpy.types.Collection):
                        continue
                    try:
                        already_linked = False
                        getter = getattr(dest_col.children, 'get', None)
                        if callable(getter):
                            try:
                                already_linked = getter(col.name) is not None
                            except Exception:
                                already_linked = False
                        if not already_linked:
                            try:
                                already_linked = any(getattr(item, 'name', '') == col.name for item in dest_col.children)
                            except Exception:
                                already_linked = False
                        if not already_linked:
                            dest_col.children.link(col)
                    except Exception:
                        pass
                # Collect objects for placement/selection convenience
                for col in loaded:
                    if isinstance(col, bpy.types.Collection):
                        for o in col.all_objects:
                            if o not in imported_objects:
                                imported_objects.append(o)

            # Naming (prefix)
            if prefix:
                for idb in imported_ids:
                    if _is_linked_id(idb) and not apply_prefix_to_linked:
                        continue
                    try:
                        idb.name = f"{prefix}{idb.name}"
                    except Exception:
                        pass

            # Bake world transform if requested (Objects only)
            if mode in {'OBJECTS', 'COLLECTIONS'} and wm.sf_bake_world and imported_objects:
                for o in imported_objects:
                    if wm.sf_clear_parent:
                        _clear_parent_keep_world(o)
                    if wm.sf_clear_constraints:
                        _clear_constraints_keep_world(o)

            # Placement (Objects only)
            if mode in {'OBJECTS', 'COLLECTIONS'} and imported_objects:
                _apply_placement(
                    context,
                    imported_objects,
                    wm.sf_placement,
                    wm.sf_offset,
                    wm.sf_grid_spacing,
                    wm.sf_grid_columns,
                )

            # Link + Override
            if do_override and mode in {'OBJECTS', 'COLLECTIONS'}:
                # Prefer overriding the linked root IDs directly through Blender's
                # override API. For linked collections this is safer than trying to
                # override every imported object one-by-one via an operator context.
                override_targets = []
                seen_targets = set()
                source_ids = loaded if mode == 'COLLECTIONS' else imported_objects
                for idb in list(source_ids or []):
                    try:
                        if mode == 'COLLECTIONS' and not isinstance(idb, bpy.types.Collection):
                            continue
                        if mode == 'OBJECTS' and not isinstance(idb, bpy.types.Object):
                            continue
                        if not getattr(idb, 'library', None):
                            continue
                        if getattr(idb, 'override_library', None):
                            continue
                        key = getattr(idb, 'name_full', '') or getattr(idb, 'name', '')
                        if key in seen_targets:
                            continue
                        seen_targets.add(key)
                        override_targets.append(idb)
                    except Exception:
                        continue

                def _sf_local_make_override(single_id):
                    if getattr(single_id, 'override_library', None):
                        return False, 'already override'
                    api_create = getattr(single_id, 'override_hierarchy_create', None)
                    if callable(api_create):
                        try:
                            api_create(context.scene, context.view_layer)
                            return True, ''
                        except Exception as ex:
                            last_error = str(ex)
                    else:
                        last_error = 'api unavailable'

                    if not isinstance(single_id, bpy.types.Object):
                        return False, last_error

                    op = getattr(getattr(bpy.ops, 'object', None), 'make_override_library', None)
                    if op is None:
                        return False, 'operator unavailable'
                    prev_override_active = getattr(context.view_layer.objects, 'active', None)
                    prev_override_selected = list(getattr(context, 'selected_objects', []) or [])
                    try:
                        for item in list(getattr(context, 'selected_objects', []) or []):
                            try:
                                item.select_set(False)
                            except Exception:
                                pass
                        try:
                            single_id.select_set(True)
                        except Exception:
                            return False, 'selection failed'
                        try:
                            context.view_layer.objects.active = single_id
                        except Exception:
                            pass
                        last_error = 'poll failed'
                        try:
                            with context.temp_override(
                                scene=context.scene,
                                view_layer=context.view_layer,
                                active_object=single_id,
                                object=single_id,
                                selected_objects=[single_id],
                                selected_editable_objects=[single_id],
                            ):
                                if op.poll():
                                    op()
                                    return True, ''
                        except Exception as ex:
                            last_error = str(ex)
                        try:
                            if op.poll():
                                op()
                                return True, ''
                        except Exception as ex:
                            last_error = str(ex)
                        return False, last_error
                    finally:
                        try:
                            for item in list(getattr(context, 'selected_objects', []) or []):
                                try:
                                    item.select_set(False)
                                except Exception:
                                    pass
                            for item in prev_override_selected:
                                try:
                                    item.select_set(True)
                                except Exception:
                                    pass
                            context.view_layer.objects.active = prev_override_active
                        except Exception:
                            pass

                made = 0
                failed = 0
                helper = globals().get('_rm_make_override_for_id')
                if not callable(helper):
                    helper = globals().get('_rm_make_override_for_object')
                for target in override_targets:
                    try:
                        if callable(helper):
                            ok, _msg = helper(context, target)
                        else:
                            ok, _msg = _sf_local_make_override(target)
                    except Exception:
                        ok = False
                    if ok:
                        made += 1
                    else:
                        failed += 1
                if override_targets:
                    level = {'INFO'} if failed == 0 else {'WARNING'}
                    self.report(level, f"{_tr('Overrides')}: {made} | {_tr('Failed')}: {failed}")

        except Exception as e:
            self.report({'ERROR'}, _tr('Failed to read .blend file: {}').format(str(e)))
            return {'CANCELLED'}

        # Post actions: selection and framing
        if wm.sf_select_imported and imported_objects:
            for o in context.selected_objects:
                o.select_set(False)
            for o in imported_objects:
                try:
                    o.select_set(True)
                except Exception:
                    pass
            if imported_objects:
                context.view_layer.objects.active = imported_objects[0]
        else:
            # restore previous selection
            for o in context.selected_objects:
                o.select_set(False)
            for o in prev_selected:
                try:
                    o.select_set(True)
                except Exception:
                    pass
            context.view_layer.objects.active = prev_active

        if wm.sf_frame_view and imported_objects:
            _try_frame_view(context)

        # Report
        if mode == 'OBJECTS':
            self.report({'INFO'}, _tr('Imported {} object(s)').format(len([o for o in imported_objects if isinstance(o, bpy.types.Object)])))
        else:
            self.report({'INFO'}, _tr('Imported {} item(s)').format(len(imported_ids)))

        return {'FINISHED'}


# -----------------------------------------------------------------------------
#  Debug: translation check
# -----------------------------------------------------------------------------
