# Smart File

Smart File 1.0.0 は Blender 5.1.2 用です。基本操作や設定は、付属の Smart File 解説書と SmartTools 全体仕様書で確認できます。

## STL を読み込む・書き出す

1. 読み込み時は、Smart File の STL 読み込みを開いてファイルを選びます。
2. 書き出し時は、書き出すオブジェクトの範囲と座標軸を指定し、ASCII またはバイナリを選びます。

STL の処理は Smart File に含まれます。Universal Multi Importer から Smart File の STL 読み込みを選んだ場合も、同じ読み込み設定が適用されます。
