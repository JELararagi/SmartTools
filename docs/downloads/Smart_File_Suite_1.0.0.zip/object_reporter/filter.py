"""Select by Properties — multi-condition filter with property pickers."""

import bpy
from bpy.props import EnumProperty, IntProperty, StringProperty
from bpy.types import Operator, Panel

from .core import (
    BUILTIN_FIELDS,
    _build_lookup,
    _mark_table_dirty,
    _prop_name_lookup,
    _prop_value_lookup,
    get_all_custom_keys,
    get_values_for_key,
    persist_reporter_settings,
)
from ..ui_language_runtime import ui_text as _ui_text

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_field(obj, field_name):
    f = field_name.strip().lower()
    if f == "name":
        return obj.name
    if f == "collection":
        return ", ".join(c.name for c in obj.users_collection)
    if f == "dim_x":
        return str(obj.dimensions.x)
    if f == "dim_y":
        return str(obj.dimensions.y)
    if f == "dim_z":
        return str(obj.dimensions.z)
    v = obj.get(field_name.strip())
    return str(v) if v is not None else None


def _eval_cond(obj, cond):
    mt = cond.match_type
    if mt in ("EMPTY", "NOTEMPTY"):
        v = _get_field(obj, cond.property_name)
        empty = v is None or v.strip() == ""
        return empty if mt == "EMPTY" else not empty
    v = _get_field(obj, cond.property_name)
    if v is None:
        return False
    t = cond.value
    if mt == "EXACT":
        return v.strip().lower() == t.strip().lower()
    if mt == "CONTAINS":
        return t.strip().lower() in v.strip().lower()
    try:
        vf, tf = float(v), float(t)
    except ValueError:
        return False
    return {"GT": vf > tf, "LT": vf < tf, "GTE": vf >= tf, "LTE": vf <= tf}.get(
        mt, False
    )


def _matches(obj, conditions):
    if not conditions:
        return True
    result = _eval_cond(obj, conditions[0])
    for i in range(1, len(conditions)):
        cur = _eval_cond(obj, conditions[i])
        result = (
            (result and cur) if conditions[i - 1].logic == "AND" else (result or cur)
        )
    return result


def _run_filter(operator, context, action):
    """Shared filter execution.  action is 'SELECT', 'ADD', or 'ISOLATE'."""
    s = context.scene.reporter_settings
    conditions = list(s.filter_conditions)
    if not conditions:
        operator.report({"WARNING"}, "No conditions")
        return {"CANCELLED"}
    for c in conditions:
        if not c.property_name.strip():
            operator.report({"WARNING"}, "Empty property name in condition")
            return {"CANCELLED"}
    depsgraph = context.evaluated_depsgraph_get()
    seen_ids = set()
    pool = []
    for inst in depsgraph.object_instances:
        obj = inst.object.original
        if id(obj) in seen_ids:
            continue
        seen_ids.add(id(obj))
        if obj.type != "MESH":
            continue
        if s.visible_only and obj.hide_viewport:
            continue
        pool.append(obj)
    matched = [o for o in pool if _matches(o, conditions)]
    if action == "ISOLATE":
        for o in pool:
            o.hide_viewport = o not in matched
        bpy.ops.object.select_all(action="DESELECT")
        for o in matched:
            try:
                o.select_set(True)
            except RuntimeError:
                pass
    elif action == "SELECT":
        bpy.ops.object.select_all(action="DESELECT")
        for o in matched:
            try:
                o.select_set(True)
            except RuntimeError:
                pass
    else:  # ADD
        for o in matched:
            try:
                o.select_set(True)
            except RuntimeError:
                pass
    if matched:
        try:
            context.view_layer.objects.active = matched[0]
        except Exception:
            pass
    _mark_table_dirty()
    operator.report({"INFO"}, _ui_text(f"{len(matched)} of {len(pool)} matched", f"{len(pool)} 個のうち {len(matched)} 個が一致しました"))
    return {"FINISHED"}


# ---------------------------------------------------------------------------
# Operators — filter conditions
# ---------------------------------------------------------------------------


class REPORTER_OT_object_reporter_add_condition(Operator):
    bl_idname = 'reporter.sfs_object_reporter_add_condition'
    bl_label = 'Add Condition'

    bl_options = {'UNDO'}
    def execute(self, context):
        s = context.scene.reporter_settings
        cond = s.filter_conditions.add()
        cond.match_type = "EXACT"
        cond.logic = "AND"
        s.active_filter_index = len(s.filter_conditions) - 1
        persist_reporter_settings(context)
        return {"FINISHED"}


class REPORTER_OT_object_reporter_remove(Operator):
    bl_idname = 'reporter.sfs_object_reporter_remove'
    bl_label = 'Remove Condition'
    index: IntProperty()

    bl_options = {'UNDO'}
    def execute(self, context):
        s = context.scene.reporter_settings
        if 0 <= self.index < len(s.filter_conditions):
            s.filter_conditions.remove(self.index)
            s.active_filter_index = max(
                0, min(s.active_filter_index, len(s.filter_conditions) - 1)
            )
        persist_reporter_settings(context)
        return {"FINISHED"}


class REPORTER_OT_object_reporter_clear_all(Operator):
    bl_idname = 'reporter.sfs_object_reporter_clear_all'
    bl_label = 'Clear All'

    bl_options = {'UNDO'}
    def execute(self, context):
        context.scene.reporter_settings.filter_conditions.clear()
        persist_reporter_settings(context)
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Operators — filter actions
# ---------------------------------------------------------------------------


class REPORTER_OT_object_reporter_select(Operator):
    bl_idname = 'reporter.sfs_object_reporter_select'
    bl_label = 'Select Matching'
    bl_description = "Deselect all, then select matching objects"

    bl_options = {'UNDO'}
    def execute(self, context):
        return _run_filter(self, context, "SELECT")


class REPORTER_OT_object_reporter_add_to_selection(Operator):
    bl_idname = 'reporter.sfs_object_reporter_add_to_selection'
    bl_label = 'Add to Selection'
    bl_description = "Add matching objects to current selection"

    bl_options = {'UNDO'}
    def execute(self, context):
        return _run_filter(self, context, "ADD")


class REPORTER_OT_object_reporter_isolate(Operator):
    bl_idname = 'reporter.sfs_object_reporter_isolate'
    bl_label = 'Isolate Matches'
    bl_description = "Hide non-matching objects and select matches"

    bl_options = {'UNDO'}
    def execute(self, context):
        return _run_filter(self, context, "ISOLATE")


class REPORTER_OT_object_reporter_show_all(Operator):
    bl_idname = 'reporter.sfs_object_reporter_show_all'
    bl_label = 'Show All'

    bl_options = {'UNDO'}
    def execute(self, context):
        for obj in context.view_layer.objects:
            obj.hide_viewport = False
        _mark_table_dirty()
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Operators — pickers
# ---------------------------------------------------------------------------


class REPORTER_OT_object_reporter_pick_property(Operator):
    bl_idname = 'reporter.sfs_object_reporter_pick_property'
    bl_label = 'Pick Property'
    bl_property = "chosen"
    condition_index: IntProperty()

    bl_options = {'UNDO'}
    def _items(self, context):
        return _build_lookup(
            BUILTIN_FIELDS + get_all_custom_keys(context), _prop_name_lookup
        )

    chosen: EnumProperty(name="Property", items=_items)

    def execute(self, context):
        if self.chosen == "__none__":
            return {"CANCELLED"}
        real_key = _prop_name_lookup.get(self.chosen, "")
        if not real_key:
            return {"CANCELLED"}
        s = context.scene.reporter_settings
        if self.condition_index < len(s.filter_conditions):
            s.filter_conditions[self.condition_index].property_name = real_key
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {"RUNNING_MODAL"}


class REPORTER_OT_object_reporter_pick_value(Operator):
    bl_idname = 'reporter.sfs_object_reporter_pick_value'
    bl_label = 'Pick Condition Value'
    bl_property = "chosen"
    condition_index: IntProperty()

    bl_options = {'UNDO'}
    def _items(self, context):
        s = context.scene.reporter_settings
        key = (
            s.filter_conditions[self.condition_index].property_name
            if self.condition_index < len(s.filter_conditions)
            else ""
        )
        if not key:
            return [("__none__", "(set property first)", "")]
        return _build_lookup(get_values_for_key(context, key), _prop_value_lookup)

    chosen: EnumProperty(name="Value", items=_items)

    def execute(self, context):
        if self.chosen == "__none__":
            return {"CANCELLED"}
        real_val = _prop_value_lookup.get(self.chosen, "")
        s = context.scene.reporter_settings
        if self.condition_index < len(s.filter_conditions):
            s.filter_conditions[self.condition_index].value = real_val
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {"RUNNING_MODAL"}


# ---------------------------------------------------------------------------
# Panel
# ---------------------------------------------------------------------------


class REPORTER_PT_object_reporter_object_reporter_select(Panel):
    bl_label = 'Object Reporter Select'
    bl_idname = 'REPORTER_PT_object_reporter_object_reporter_select'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart File'
    bl_parent_id = 'REPORTER_PT_object_reporter_object_reporter'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 10

    def draw(self, context):
        layout = self.layout
        s = context.scene.reporter_settings
        conditions = s.filter_conditions

        for i, cond in enumerate(conditions):
            box = layout.box()
            col = box.column(align=True)
            hrow = col.row(align=True)
            if i == 0:
                hrow.label(text="IF", icon="FILTER")
            else:
                hrow.prop(conditions[i - 1], "logic", expand=True)
            hrow.separator()
            op = hrow.operator(
                "reporter.sfs_object_reporter_remove", text="", icon="X", emboss=True
            )
            op.index = i
            prow = col.row(align=True)
            prow.prop(cond, "property_name", text="")
            opb = prow.operator(
                "reporter.sfs_object_reporter_pick_property", text="", icon="DOWNARROW_HLT", emboss=True
            )
            opb.condition_index = i
            col.prop(cond, "match_type", text="")
            if cond.match_type not in ("EMPTY", "NOTEMPTY"):
                vrow = col.row(align=True)
                vrow.prop(cond, "value", text="")
                opc = vrow.operator(
                    "reporter.sfs_object_reporter_pick_value", text="", icon="DOWNARROW_HLT", emboss=True
                )
                opc.condition_index = i

        layout.operator(
            "reporter.sfs_object_reporter_add_condition", icon="ADD", text="Add Condition"
        )
        if conditions:
            layout.operator(
                "reporter.sfs_object_reporter_clear_all", icon="X", text="Clear All"
            )

        layout.separator()
        row = layout.row(align=True)
        row.operator("reporter.sfs_object_reporter_select", icon="RESTRICT_SELECT_OFF")
        row.operator("reporter.sfs_object_reporter_add_to_selection", icon="ADD")
        row.operator("reporter.sfs_object_reporter_isolate", icon="HIDE_OFF")
        layout.operator(
            "reporter.sfs_object_reporter_show_all", icon="HIDE_OFF", text="Show All Objects"
        )
