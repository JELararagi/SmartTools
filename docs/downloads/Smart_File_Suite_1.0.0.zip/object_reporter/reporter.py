"""Viewport labels, summary table, grouping, and CSV export."""

import csv
import json
import os
import uuid
from collections import OrderedDict, defaultdict
from itertools import islice

import blf
import bpy
from bpy.app.handlers import persistent
from bpy.props import EnumProperty, IntProperty, StringProperty
from bpy.types import Operator, Panel, UIList
from mathutils import Vector
from bpy_extras.view3d_utils import location_3d_to_region_2d

from .core import (
    _build_lookup,
    _field_picker_lookup,
    _fmt_num,
    _group_by_lookup,
    _mark_table_dirty,
    _resolve_prop,
    get_active_fields,
    get_all_custom_keys,
    get_areas,
    get_evaluated_bmesh,
    get_object_volume,
    get_scene_objects,
    is_table_dirty,
    persist_reporter_settings,
    set_table_dirty,
)
from ..ui_language_runtime import ui_text as _ui_text
from ..ui_language_runtime import error_text as _sf_error_text

# ---------------------------------------------------------------------------
# Viewport label immutable caches + generation-owned runtime
# ---------------------------------------------------------------------------

_MAX_LABEL_CACHE_OBJECTS = 4096
_MAX_LABEL_LINES_PER_OBJECT = 96
_MAX_LABEL_TEXT_CHARS = 512
_MAX_LABEL_COLLECTION_NAMES = 64
_MAX_LABEL_REGION_CACHES = 32
_MAX_TABLE_CACHE_ROWS = 20000
_MAX_TABLE_CUSTOM_FIELDS = 512
_MAX_TABLE_MATERIAL_FIELDS = 512
_MAX_TABLE_TEXT_CHARS = 2048
_LABEL_RETRY_DELAYS = (0.5, 1.0, 2.0)
_LABEL_LEDGER_KEY = "JELararagi.smart_file.object_reporter.labels.v57540"
_LABEL_LEGACY_LEDGER_KEYS = (
    "JELararagi.smart_file.object_reporter.labels.v57539",
    "JELararagi.smart_file.object_reporter.labels.v57536",
    "JELararagi.smart_file.object_reporter.labels.v57535",
    "JELararagi.smart_file.object_reporter.labels.v57534",
    "JELararagi.smart_file.object_reporter.labels.v57533",
    "JELararagi.smart_file.object_reporter.labels.v57532",
    "JELararagi.smart_file.object_reporter.labels.v57531",
)
_LABEL_RUNTIME_TOKEN = object()
_LABEL_RUNTIME_GENERATION = uuid.uuid4().hex
_label_own_ledger = None

_draw_handler = None
_label_cache_by_region = OrderedDict()
_label_selection_signatures = OrderedDict()
_label_cache_dirty = True
_label_rebuild_timer_registered = False
_label_rebuild_callback = None
_label_boundary_active = False
_label_runtime_registered = False
_label_handler_records = []
_label_msgbus_owner = object()
_label_last_error = ""


def _bounded_text(value, limit):
    return str(value if value is not None else "")[:max(0, int(limit))]


def _append_label_line(lines, value) -> bool:
    if len(lines) >= _MAX_LABEL_LINES_PER_OBJECT:
        return False
    lines.append(_bounded_text(value, _MAX_LABEL_TEXT_CHARS))
    return True


def _bounded_collection_names(collections, text_limit=_MAX_LABEL_TEXT_CHARS) -> str:
    try:
        names = (
            _bounded_text(getattr(collection, "name", ""), 128)
            for collection in islice(iter(collections or ()), _MAX_LABEL_COLLECTION_NAMES)
        )
        return _bounded_text(", ".join(name for name in names if name), text_limit)
    except Exception:
        return ""


def _safe_pointer(value) -> int:
    try:
        return int(value.as_pointer()) if value is not None else 0
    except Exception:
        return 0


def _label_context_key(context) -> tuple[int, int, int]:
    return (
        _safe_pointer(getattr(context, "scene", None)),
        _safe_pointer(getattr(context, "window", None)),
        _safe_pointer(getattr(context, "region", None)),
    )


def _selection_signature(context) -> tuple[int, tuple[tuple[int, str], ...]]:
    """Return a bounded primitive selection signature; never retain RNA."""
    try:
        selected = tuple(getattr(context, "selected_objects", ()) or ())
    except Exception:
        selected = ()
    rows = []
    for obj in islice(selected, _MAX_LABEL_CACHE_OBJECTS):
        rows.append(
            (
                _safe_pointer(obj),
                _bounded_text(
                    getattr(obj, "name_full", getattr(obj, "name", "")),
                    _MAX_LABEL_TEXT_CHARS,
                ),
            )
        )
    rows.sort()
    try:
        active_ptr = _safe_pointer(getattr(context, "active_object", None))
    except Exception:
        active_ptr = 0
    return active_ptr, tuple(rows)


def _trim_label_region_caches() -> None:
    while len(_label_cache_by_region) > _MAX_LABEL_REGION_CACHES:
        key, _value = _label_cache_by_region.popitem(last=False)
        _label_selection_signatures.pop(key, None)
    while len(_label_selection_signatures) > _MAX_LABEL_REGION_CACHES:
        _label_selection_signatures.popitem(last=False)


def _clear_label_region_caches() -> None:
    global _label_cache_dirty
    _label_cache_by_region.clear()
    _label_selection_signatures.clear()
    _label_cache_dirty = True


def _world_to_screen(context, co):
    return location_3d_to_region_2d(context.region, context.space_data.region_3d, co)


def _rebuild_label_entry(context):
    """Build one immutable primitive cache entry outside every draw callback."""
    if _label_boundary_active or not _label_is_current_generation():
        return None
    try:
        scene = getattr(context, "scene", None)
        settings = getattr(scene, "reporter_settings", None)
    except Exception:
        settings = None
    if settings is None or not bool(getattr(settings, "labels_enabled", False)):
        return None

    try:
        key = _label_context_key(context)
        if not all(key):
            return None
        objects = get_scene_objects(context, limit=_MAX_LABEL_CACHE_OBJECTS)
        builtin_flags, computed_flags, custom_names = get_active_fields(settings)
        custom_names = tuple(custom_names[:_MAX_LABEL_LINES_PER_OBJECT])
        need_geom = bool(
            computed_flags["face_area"]
            or computed_flags["volume"]
            or computed_flags["material_area"]
        )
        needs_depsgraph = bool(need_geom or custom_names)
        depsgraph = context.evaluated_depsgraph_get() if needs_depsgraph else None
        n_active = sum(builtin_flags.values()) + sum(computed_flags.values()) + len(custom_names)
        show_prefix = n_active > 1
        dp = int(settings.decimal_places)
        cache_rows = []

        for obj in islice(objects, _MAX_LABEL_CACHE_OBJECTS):
            try:
                corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
                center = sum(corners, Vector()) / 8
                anchor = (float(center.x), float(center.y), float(max(c.z for c in corners)))
            except Exception:
                try:
                    location = obj.location
                    anchor = (float(location.x), float(location.y), float(location.z))
                except Exception:
                    continue

            lines = []
            if builtin_flags["name"]:
                _append_label_line(lines, getattr(obj, "name", "") or "")

            if builtin_flags["collection"]:
                value = _bounded_collection_names(getattr(obj, "users_collection", ()))
                _append_label_line(lines, ("Col: " + value) if show_prefix else value)

            for field in custom_names:
                if len(lines) >= _MAX_LABEL_LINES_PER_OBJECT:
                    break
                try:
                    value = _resolve_prop(obj, field, depsgraph=depsgraph)
                except Exception:
                    value = None
                if value is not None:
                    formatted = _fmt_num(value, dp)
                    _append_label_line(
                        lines,
                        (field + ": " + formatted) if show_prefix else formatted,
                    )

            if need_geom and getattr(obj, "type", None) == "MESH" and len(lines) < _MAX_LABEL_LINES_PER_OBJECT:
                bm = None
                try:
                    bm = get_evaluated_bmesh(obj, depsgraph)
                    if computed_flags["face_area"] or computed_flags["material_area"]:
                        total_area, material_areas = get_areas(obj, bm)
                        if computed_flags["face_area"]:
                            value = f"{total_area:.{dp}f}"
                            _append_label_line(lines, ("Area: " + value) if show_prefix else value)
                        if computed_flags["material_area"]:
                            for material_name, material_area in islice(
                                material_areas.items(), _MAX_LABEL_LINES_PER_OBJECT
                            ):
                                if len(lines) >= _MAX_LABEL_LINES_PER_OBJECT:
                                    break
                                value = f"{material_area:.{dp}f}"
                                _append_label_line(
                                    lines,
                                    (str(material_name) + ": " + value) if show_prefix else value,
                                )
                    if computed_flags["volume"] and len(lines) < _MAX_LABEL_LINES_PER_OBJECT:
                        volume = get_object_volume(bm)
                        value = f"{volume:.{dp}f}" if volume is not None else "(open mesh)"
                        _append_label_line(lines, ("Vol: " + value) if show_prefix else value)
                except Exception:
                    if computed_flags["face_area"]:
                        _append_label_line(lines, "Area: —")
                    if computed_flags["material_area"]:
                        _append_label_line(lines, "Mat.Area: —")
                    if computed_flags["volume"]:
                        _append_label_line(lines, "Vol: —")
                finally:
                    try:
                        if bm is not None:
                            bm.free()
                    except Exception:
                        pass

            if builtin_flags["dimensions"] and len(lines) < _MAX_LABEL_LINES_PER_OBJECT:
                try:
                    dimensions = obj.dimensions
                    value = (
                        f"{dimensions.x:.{dp}f} x "
                        f"{dimensions.y:.{dp}f} x "
                        f"{dimensions.z:.{dp}f}"
                    )
                    _append_label_line(lines, ("Dim: " + value) if show_prefix else value)
                except Exception:
                    pass

            if lines:
                cache_rows.append((anchor, tuple(lines[:_MAX_LABEL_LINES_PER_OBJECT])))

        try:
            color = tuple(float(value) for value in settings.label_color[:3])
        except Exception:
            color = (1.0, 1.0, 1.0)
        draw_settings = (
            max(1, int(getattr(settings, "label_font_size", 12) or 12)),
            tuple(color[:3]),
            int(getattr(settings, "label_offset_x", 0) or 0),
            int(getattr(settings, "label_offset_y", 0) or 0),
        )
        signature = _selection_signature(context) if bool(getattr(settings, "selected_only", False)) else (0, ())
        # Every value below is a tuple of Python primitives.  No Object, Scene,
        # Window, Region, depsgraph, BMesh, or other RNA reference is retained.
        return key, (tuple(cache_rows), draw_settings), signature
    except Exception:
        return None


def _iter_view3d_overrides():
    try:
        wm = getattr(bpy.context, "window_manager", None)
        windows = tuple(getattr(wm, "windows", ()) or ()) if wm is not None else ()
    except Exception:
        windows = ()
    for window in windows:
        try:
            screen = window.screen
            areas = tuple(getattr(screen, "areas", ()) or ())
        except Exception:
            continue
        for area in areas:
            if getattr(area, "type", None) != "VIEW_3D":
                continue
            try:
                regions = tuple(getattr(area, "regions", ()) or ())
                space = area.spaces.active
            except Exception:
                continue
            for region in regions:
                if getattr(region, "type", None) == "WINDOW":
                    yield window, screen, area, region, space


def _rebuild_all_label_caches() -> bool:
    """Rebuild every available View3D cache transactionally outside Draw."""
    global _label_cache_by_region, _label_selection_signatures, _label_cache_dirty
    if _label_boundary_active or not _label_runtime_registered or not _label_is_current_generation():
        return False
    built = OrderedDict()
    signatures = OrderedDict()
    view_count = 0
    success_count = 0
    for window, screen, area, region, space in _iter_view3d_overrides():
        view_count += 1
        try:
            with bpy.context.temp_override(
                window=window,
                screen=screen,
                area=area,
                region=region,
                space_data=space,
            ):
                result = _rebuild_label_entry(bpy.context)
        except Exception:
            result = None
        if result is None:
            continue
        key, entry, signature = result
        built[key] = entry
        signatures[key] = signature
        success_count += 1

    if success_count:
        _label_cache_by_region = built
        _label_selection_signatures = signatures
        _trim_label_region_caches()
        redraw_all_viewports()
    _label_cache_dirty = not bool(view_count and success_count == view_count)
    return not _label_cache_dirty


def _label_namespace():
    try:
        namespace = bpy.app.driver_namespace
        return namespace if isinstance(namespace, dict) else None
    except Exception:
        return None


def _label_ledger():
    namespace = _label_namespace()
    if namespace is None:
        return None
    ledger = namespace.get(_LABEL_LEDGER_KEY)
    if ledger is None and isinstance(_label_own_ledger, dict):
        # Opening a file empties driver_namespace while the draw handle, handlers
        # and msgbus owner stay alive, so this generation puts its ledger back.
        namespace[_LABEL_LEDGER_KEY] = _label_own_ledger
        ledger = _label_own_ledger
    return ledger


def _label_is_current_generation() -> bool:
    ledger = _label_ledger()
    return bool(
        isinstance(ledger, dict)
        and ledger.get("token") is _LABEL_RUNTIME_TOKEN
        and ledger.get("generation") == _LABEL_RUNTIME_GENERATION
        and ledger.get("owner_module") == __name__
    )


def _label_feature_enabled(scene=None) -> bool:
    """Cheap feature gate; never scans scenes or retains RNA references."""
    try:
        if scene is None:
            scene = getattr(getattr(bpy, "context", None), "scene", None)
        settings = getattr(scene, "reporter_settings", None) if scene is not None else None
        return bool(settings is not None and getattr(settings, "labels_enabled", False))
    except Exception:
        return False


def _remove_exact_label_handler(name, callback) -> bool:
    try:
        handler_list = getattr(bpy.app.handlers, name, None)
        if name in ("load_pre", "load_post", "save_pre", "save_post"):
            from .. import lifecycle_hub as _hub
            handler_list = getattr(_hub.handlers, name, None)
        if handler_list is None:
            return True
        while callback in handler_list:
            handler_list.remove(callback)
        return True
    except Exception:
        return False


def _cleanup_label_ledger(ledger) -> bool:
    """Release only exact identities recorded by one Object Reporter generation."""
    global _draw_handler, _label_runtime_registered, _label_boundary_active
    global _label_rebuild_callback, _label_rebuild_timer_registered
    global _label_handler_records
    if not isinstance(ledger, dict):
        return True
    ok = True
    for record in tuple(ledger.get("timer_records", ()) or ()):
        callback = record.get("callback") if isinstance(record, dict) else None
        if not (
            isinstance(record, dict)
            and record.get("token") is _LABEL_RUNTIME_TOKEN
            and record.get("generation") == _LABEL_RUNTIME_GENERATION
        ):
            ok = False
            continue
        try:
            checker = getattr(bpy.app.timers, "is_registered", None)
            if callable(callback) and (not callable(checker) or checker(callback)):
                bpy.app.timers.unregister(callback)
        except Exception:
            ok = False
    # Compatibility ledger field contains only this generation's exact callbacks.
    ledger["timers"] = set()
    ledger["timer_records"] = []
    for record in reversed(tuple(ledger.get("handlers", ()) or ())):
        if isinstance(record, dict):
            name = str(record.get("name") or "")
            callback = record.get("callback")
            remover = record.get("remover")
            try:
                removed = remover() if callable(remover) else _remove_exact_label_handler(name, callback)
            except Exception:
                removed = False
        else:
            try:
                name, callback = record
            except Exception:
                ok = False
                continue
            removed = _remove_exact_label_handler(name, callback)
        if removed is False:
            ok = False
    ledger["handlers"] = ()
    owner = ledger.get("msgbus_owner")
    if owner is not None:
        try:
            bpy.msgbus.clear_by_owner(owner)
        except Exception:
            ok = False
    ledger["msgbus_count"] = 0
    handle = ledger.get("draw_handle")
    if handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(handle, "WINDOW")
        except Exception:
            ok = False
    ledger["draw_handle"] = None
    ledger["active"] = False
    _draw_handler = None
    _label_handler_records = []
    _label_rebuild_callback = None
    _label_rebuild_timer_registered = False
    _label_runtime_registered = False
    _label_boundary_active = True
    _clear_label_region_caches()
    return ok


def prepare_runtime_generation() -> bool:
    """Claim the shared generation slot and remove an older exact runtime."""
    global _label_msgbus_owner, _label_last_error, _label_own_ledger
    namespace = _label_namespace()
    if namespace is None:
        _label_last_error = "bpy.app.driver_namespace is unavailable"
        return False
    _label_ledger()
    for legacy_key in _LABEL_LEGACY_LEDGER_KEYS:
        legacy = namespace.get(legacy_key)
        if isinstance(legacy, dict):
            cleanup = legacy.get("cleanup")
            try:
                cleaned = bool(cleanup(legacy)) if callable(cleanup) else False
            except Exception:
                cleaned = False
            if not cleaned:
                _label_last_error = f"legacy Object Reporter generation could not be removed: {legacy_key}"
                return False
        namespace.pop(legacy_key, None)
    previous = namespace.get(_LABEL_LEDGER_KEY)
    if isinstance(previous, dict) and previous.get("token") is not _LABEL_RUNTIME_TOKEN:
        cleanup = previous.get("cleanup")
        try:
            cleaned = bool(cleanup(previous)) if callable(cleanup) else False
        except Exception:
            cleaned = False
        if not cleaned:
            _label_last_error = "previous Object Reporter generation could not be removed"
            return False
    current = namespace.get(_LABEL_LEDGER_KEY)
    if not isinstance(current, dict) or current.get("token") is not _LABEL_RUNTIME_TOKEN:
        _label_msgbus_owner = object()
        current = {
            "schema": 1,
            "token": _LABEL_RUNTIME_TOKEN,
            "generation": _LABEL_RUNTIME_GENERATION,
            "owner_module": __name__,
            "handlers": (),
            "timers": set(),
            "timer_records": [],
            "draw_handle": None,
            "msgbus_owner": _label_msgbus_owner,
            "msgbus_count": 0,
            "active": False,
            "last_error": "",
            "cleanup": _cleanup_label_ledger,
        }
        namespace[_LABEL_LEDGER_KEY] = current
        _label_own_ledger = current
    if _label_is_current_generation():
        _label_last_error = ""
        current["last_error"] = ""
        return True
    _label_last_error = "Object Reporter generation ownership verification failed"
    return False


def _remove_label_rebuild_timer() -> bool:
    global _label_rebuild_timer_registered, _label_rebuild_callback
    ledger = _label_ledger()
    callbacks = tuple(ledger.get("timers", ()) or ()) if isinstance(ledger, dict) else ()
    ok = True
    for callback in callbacks:
        try:
            checker = getattr(bpy.app.timers, "is_registered", None)
            if not callable(checker) or checker(callback):
                bpy.app.timers.unregister(callback)
        except Exception:
            ok = False
    if isinstance(ledger, dict):
        ledger["timers"] = set()
        ledger["timer_records"] = []
    _label_rebuild_callback = None
    _label_rebuild_timer_registered = False
    return ok


def _schedule_label_cache_rebuild(delay=0.5, attempt=0):
    """Schedule one finite rebuild attempt; retries are separate one-shots."""
    global _label_cache_dirty, _label_rebuild_timer_registered
    global _label_rebuild_callback, _label_last_error
    _label_cache_dirty = True
    if (
        not _label_runtime_registered
        or _label_boundary_active
        or not _label_is_current_generation()
        or not _label_feature_enabled()
    ):
        return False
    if _label_rebuild_callback is not None:
        try:
            checker = getattr(bpy.app.timers, "is_registered", None)
            if not callable(checker) or checker(_label_rebuild_callback):
                _label_rebuild_timer_registered = True
                return True
        except Exception:
            pass
        _label_rebuild_callback = None

    token = _LABEL_RUNTIME_TOKEN
    generation = _LABEL_RUNTIME_GENERATION
    attempt = max(0, int(attempt))

    def _one_shot():
        global _label_rebuild_callback, _label_rebuild_timer_registered, _label_last_error
        ledger = _label_ledger()
        if isinstance(ledger, dict):
            timers = ledger.get("timers")
            if isinstance(timers, set):
                timers.discard(_one_shot)
            records = ledger.get("timer_records")
            if isinstance(records, list):
                records[:] = [record for record in records if record.get("callback") is not _one_shot]
        _label_rebuild_callback = None
        _label_rebuild_timer_registered = False
        if not (
            isinstance(ledger, dict)
            and ledger.get("token") is token
            and ledger.get("generation") == generation
            and ledger.get("owner_module") == __name__
            and _label_runtime_registered
            and not _label_boundary_active
        ):
            return None
        try:
            if _rebuild_all_label_caches():
                _label_last_error = ""
                return None
            if attempt < len(_LABEL_RETRY_DELAYS):
                _schedule_label_cache_rebuild(
                    _LABEL_RETRY_DELAYS[attempt], attempt=attempt + 1
                )
            # After the final retry the cache stays explicitly dirty and stops.
            return None
        except Exception as exc:
            _label_last_error = f"{type(exc).__name__}: {exc}"[:512]
            if attempt < len(_LABEL_RETRY_DELAYS):
                _schedule_label_cache_rebuild(
                    _LABEL_RETRY_DELAYS[attempt], attempt=attempt + 1
                )
            return None

    _label_rebuild_callback = _one_shot
    ledger = _label_ledger()
    if not isinstance(ledger, dict):
        _label_rebuild_callback = None
        return False
    ledger.setdefault("timers", set()).add(_one_shot)
    timer_record = {
        "callback": _one_shot,
        "token": token,
        "generation": generation,
        "one_shot": True,
        "attempt": attempt,
        "remover": _remove_label_rebuild_timer,
    }
    ledger.setdefault("timer_records", []).append(timer_record)
    try:
        bpy.app.timers.register(
            _one_shot,
            first_interval=max(0.5, float(delay)),
            persistent=False,
        )
        checker = getattr(bpy.app.timers, "is_registered", None)
        if callable(checker) and not checker(_one_shot):
            raise RuntimeError("Object Reporter rebuild timer was not retained")
        _label_rebuild_timer_registered = True
        return True
    except Exception as exc:
        ledger.get("timers", set()).discard(_one_shot)
        records = ledger.get("timer_records")
        if isinstance(records, list):
            records[:] = [record for record in records if record.get("callback") is not _one_shot]
        _label_rebuild_callback = None
        _label_rebuild_timer_registered = False
        _label_last_error = f"{type(exc).__name__}: {exc}"[:512]
        return False


def mark_label_cache_dirty(delay=0.5):
    """Event hook: mark immutable caches stale and schedule one bounded rebuild."""
    return _schedule_label_cache_rebuild(delay)


def draw_labels_callback():
    """Read primitive immutable cache data and issue BLF/GPU projection only."""
    if _label_boundary_active or not _label_is_current_generation():
        return
    context = bpy.context
    try:
        if not context.area or context.area.type != "VIEW_3D":
            return
        if not context.region or context.region.type != "WINDOW":
            return
        entry = _label_cache_by_region.get(_label_context_key(context))
    except Exception:
        return
    if not entry:
        return
    cache_rows, draw_settings = entry
    font_size, color, offset_x, offset_y = draw_settings
    font_id = 0
    try:
        blf.size(font_id, int(font_size))
        blf.color(font_id, float(color[0]), float(color[1]), float(color[2]), 1.0)
    except Exception:
        return
    line_height = int(font_size) + 3
    for anchor_values, lines in cache_rows:
        try:
            screen_co = _world_to_screen(context, Vector(anchor_values))
        except Exception:
            screen_co = None
        if screen_co is None:
            continue
        sx, sy = screen_co.x, screen_co.y
        for line_index, line in enumerate(lines):
            try:
                blf.position(
                    font_id,
                    sx + int(offset_x),
                    sy + int(offset_y) - line_index * line_height,
                    0,
                )
                blf.draw(font_id, line)
            except Exception:
                continue


def redraw_all_viewports():
    try:
        windows = tuple(getattr(bpy.context.window_manager, "windows", ()) or ())
    except Exception:
        windows = ()
    for window in windows:
        try:
            areas = tuple(getattr(window.screen, "areas", ()) or ())
        except Exception:
            continue
        for area in areas:
            if getattr(area, "type", None) == "VIEW_3D":
                try:
                    area.tag_redraw()
                except Exception:
                    pass
    return None


def _selected_only_signature_changed() -> bool:
    """Compare selection on event callbacks, never from Draw."""
    changed = False
    found = False
    for window, screen, area, region, space in _iter_view3d_overrides():
        try:
            with bpy.context.temp_override(
                window=window,
                screen=screen,
                area=area,
                region=region,
                space_data=space,
            ):
                context = bpy.context
                settings = getattr(getattr(context, "scene", None), "reporter_settings", None)
                if settings is None or not bool(getattr(settings, "labels_enabled", False)):
                    continue
                if not bool(getattr(settings, "selected_only", False)):
                    continue
                found = True
                key = _label_context_key(context)
                signature = _selection_signature(context)
                if _label_selection_signatures.get(key) != signature:
                    changed = True
        except Exception:
            continue
    return bool(found and changed)


def _label_boundary_begin(*_args):
    global _label_boundary_active
    if not _label_is_current_generation():
        return
    _label_boundary_active = True
    _clear_label_region_caches()
    _remove_label_rebuild_timer()


def _label_boundary_end(*_args):
    global _label_boundary_active
    if not _label_is_current_generation():
        return
    _label_boundary_active = False
    if _label_runtime_registered and _label_feature_enabled():
        _schedule_label_cache_rebuild(0.5)


@persistent
def _label_load_pre(*args):
    _label_boundary_begin(*args)


@persistent
def _label_load_post(*args):
    _label_boundary_end(*args)


@persistent
def _label_save_pre(*args):
    _label_boundary_begin(*args)


@persistent
def _label_save_post(*args):
    _label_boundary_end(*args)


@persistent
def _label_undo_redo_pre(*args):
    _label_boundary_begin(*args)


@persistent
def _label_undo_redo_post(*args):
    _label_boundary_end(*args)


@persistent
def _label_depsgraph_update_post(_scene, _depsgraph):
    # OFF/stale callbacks leave before context, selection, or geometry work.
    if (
        not _label_runtime_registered
        or _label_boundary_active
        or not _label_is_current_generation()
        or not _label_feature_enabled(_scene)
    ):
        return
    try:
        if not any(True for _item in islice(iter(getattr(_depsgraph, "updates", ()) or ()), 1)):
            return
    except Exception:
        pass
    # Geometry/property updates and non-active Shift-selection changes are
    # coalesced into the same finite one-shot rebuild.
    _selected_only_signature_changed()
    _schedule_label_cache_rebuild(0.5)


def _label_selection_event(*_args):
    global _label_cache_dirty
    if not _label_runtime_registered or _label_boundary_active or not _label_is_current_generation():
        return
    # Msgbus is an explicit invalidation event. Even when no View3D exists, keep
    # the cache dirty and run only the bounded one-shot sequence; never install
    # a permanent polling timer.
    _label_cache_dirty = True
    _selected_only_signature_changed()
    _schedule_label_cache_rebuild(0.5)


def _label_handler_specs():
    handlers = bpy.app.handlers
    from .. import lifecycle_hub as _hub
    hub = _hub.handlers
    specs = [
        ("load_pre", hub.load_pre, _label_load_pre),
        ("load_post", hub.load_post, _label_load_post),
        ("save_pre", hub.save_pre, _label_save_pre),
        ("save_post", hub.save_post, _label_save_post),
        ("depsgraph_update_post", getattr(handlers, "depsgraph_update_post", None), _label_depsgraph_update_post),
    ]
    for prefix in ("undo", "redo"):
        before = getattr(handlers, f"{prefix}_pre", None)
        after = getattr(handlers, f"{prefix}_post", None)
        if before is not None:
            specs.append((f"{prefix}_pre", before, _label_undo_redo_pre))
        if after is not None:
            specs.append((f"{prefix}_post", after, _label_undo_redo_post))
    return tuple(item for item in specs if item[1] is not None)


def _register_label_lifecycle_handlers() -> bool:
    global _label_handler_records, _label_last_error
    records = []
    try:
        specs = _label_handler_specs()
        for name, handler_list, callback in specs:
            while callback in handler_list:
                handler_list.remove(callback)
            handler_list.append(callback)
            if sum(1 for item in tuple(handler_list) if item is callback) != 1:
                raise RuntimeError(f"Object Reporter handler registration failed: {name}")
            records.append({
                "name": name,
                "handler_list": handler_list,
                "callback": callback,
                "token": _LABEL_RUNTIME_TOKEN,
                "generation": _LABEL_RUNTIME_GENERATION,
                "remover": (lambda hl=handler_list, cb=callback: _remove_exact_label_handler_from_list(hl, cb)),
            })
        _label_handler_records = records
        ledger = _label_ledger()
        if isinstance(ledger, dict):
            ledger["handlers"] = tuple(records)
        return _label_handlers_exact()
    except Exception as exc:
        for record in reversed(records):
            try:
                record["remover"]()
            except Exception:
                pass
        _label_handler_records = []
        ledger = _label_ledger()
        if isinstance(ledger, dict):
            ledger["handlers"] = ()
        _label_last_error = f"{type(exc).__name__}: {exc}"[:512]
        return False


def _remove_exact_label_handler_from_list(handler_list, callback) -> bool:
    try:
        while callback in handler_list:
            handler_list.remove(callback)
        return sum(1 for item in tuple(handler_list) if item is callback) == 0
    except Exception:
        return False


def _label_handlers_exact() -> bool:
    specs = _label_handler_specs()
    if len(_label_handler_records) != len(specs):
        return False
    ledger = _label_ledger()
    records = tuple(ledger.get("handlers", ()) or ()) if isinstance(ledger, dict) else ()
    if len(records) != len(specs):
        return False
    for index, ((name, handler_list, callback), record) in enumerate(zip(specs, _label_handler_records)):
        if records[index] is not record:
            return False
        if not isinstance(record, dict):
            return False
        if (
            record.get("name") != name
            or record.get("handler_list") is not handler_list
            or record.get("callback") is not callback
            or record.get("token") is not _LABEL_RUNTIME_TOKEN
            or record.get("generation") != _LABEL_RUNTIME_GENERATION
        ):
            return False
        try:
            if sum(1 for item in tuple(handler_list) if item is callback) != 1:
                return False
        except Exception:
            return False
    return True

def _subscribe_label_selection_events() -> bool:
    global _label_last_error
    ledger = _label_ledger()
    if not isinstance(ledger, dict):
        return False
    owner = ledger.get("msgbus_owner")
    try:
        bpy.msgbus.clear_by_owner(owner)
    except Exception:
        pass
    count = 0
    try:
        bpy.msgbus.subscribe_rna(
            key=(bpy.types.LayerObjects, "active"),
            owner=owner,
            args=(),
            notify=_label_selection_event,
            options={"PERSISTENT"},
        )
        count += 1
    except Exception as exc:
        ledger["msgbus_count"] = 0
        _label_last_error = f"LayerObjects.active msgbus registration failed: {type(exc).__name__}: {exc}"[:512]
        return False
    try:
        bpy.msgbus.subscribe_rna(
            key=(bpy.types.WindowManager, "operators"),
            owner=owner,
            args=(),
            notify=_label_selection_event,
            options={"PERSISTENT"},
        )
        count += 1
    except Exception:
        pass
    ledger["msgbus_count"] = count
    return count >= 1

def cleanup_stale_label_generation() -> bool:
    """Compatibility entry point: claim the exact generation-owned ledger."""
    return prepare_runtime_generation()


def get_label_runtime_status() -> dict:
    """Return primitive exact-ownership diagnostics without exposing RNA."""
    global _label_runtime_registered
    ledger = _label_ledger()
    current = bool(
        isinstance(ledger, dict)
        and ledger.get("token") is _LABEL_RUNTIME_TOKEN
        and ledger.get("generation") == _LABEL_RUNTIME_GENERATION
        and ledger.get("owner_module") == __name__
    )
    handlers_exact = bool(current and _label_handlers_exact())
    handler_count = len(_label_handler_records) if current else 0
    timers = tuple(ledger.get("timers", ()) or ()) if current else ()
    live_timer_count = 0
    checker = getattr(getattr(bpy.app, "timers", None), "is_registered", None)
    for callback in timers:
        try:
            if not callable(checker) or checker(callback):
                live_timer_count += 1
        except Exception:
            pass
    timer_exact = bool(
        live_timer_count == len(timers)
        and (
            (_label_rebuild_callback is None and len(timers) == 0)
            or (_label_rebuild_callback is not None and len(timers) == 1 and timers[0] is _label_rebuild_callback)
        )
    )
    draw_handle = ledger.get("draw_handle") if current else None
    draw_exact = bool(draw_handle is not None and draw_handle is _draw_handler)
    msgbus_exact = bool(
        current
        and ledger.get("msgbus_owner") is _label_msgbus_owner
        and int(ledger.get("msgbus_count", 0) or 0) >= 1
    )
    active = bool(current and ledger.get("active"))
    watching = bool(
        active
        and _label_runtime_registered
        and draw_exact
        and handlers_exact
        and timer_exact
        and msgbus_exact
        and not _label_boundary_active
        and not _label_last_error
    )
    return {
        "generation": _LABEL_RUNTIME_GENERATION,
        "generation_current": current,
        "registered": bool(watching),
        "watching": watching,
        "handler_count": handler_count,
        "required_handler_count": len(_label_handler_specs()),
        "handler_identities_exact": handlers_exact,
        "timer_count": live_timer_count,
        "timer_identity_exact": timer_exact,
        "msgbus_owned": msgbus_exact,
        "msgbus_count": int(ledger.get("msgbus_count", 0) or 0) if current else 0,
        "draw_handler": draw_exact,
        "cache_entries": int(len(_label_cache_by_region)),
        "cache_dirty": bool(_label_cache_dirty),
        "last_error": _label_last_error or str(ledger.get("last_error", "") if current else ""),
    }


def register_handler():
    """Enable labels with exact generation ownership and no idle polling."""
    global _draw_handler, _label_runtime_registered, _label_boundary_active
    global _label_last_error
    if not _label_feature_enabled():
        unregister_handler()
        return True
    if not prepare_runtime_generation():
        return False
    if _label_runtime_registered and _draw_handler is not None:
        _label_boundary_active = False
        handlers_ok = _register_label_lifecycle_handlers()
        msgbus_ok = _subscribe_label_selection_events()
        timer_ok = _schedule_label_cache_rebuild(0.5)
        return bool(handlers_ok and msgbus_ok and timer_ok and get_label_runtime_status().get("watching"))
    ledger = _label_ledger()
    _label_runtime_registered = True
    _label_boundary_active = False
    try:
        if not _register_label_lifecycle_handlers():
            raise RuntimeError(_label_last_error or "Object Reporter handler registration failed")
        if not _subscribe_label_selection_events():
            raise RuntimeError(_label_last_error or "Object Reporter selection events failed")
        _draw_handler = bpy.types.SpaceView3D.draw_handler_add(
            draw_labels_callback, (), "WINDOW", "POST_PIXEL"
        )
        ledger["draw_handle"] = _draw_handler
        ledger["active"] = True
        if not _schedule_label_cache_rebuild(0.5):
            raise RuntimeError(_label_last_error or "Object Reporter cache rebuild scheduling failed")
        _label_last_error = ""
        ledger["last_error"] = ""
        return bool(get_label_runtime_status().get("watching"))
    except Exception as exc:
        _label_last_error = f"{type(exc).__name__}: {exc}"[:512]
        if isinstance(ledger, dict):
            ledger["last_error"] = _label_last_error
            _cleanup_label_ledger(ledger)
        return False


def sync_label_runtime_with_scene() -> bool:
    """Match the runtime to the current scene switch.

    An update callback does not run when a load or restore leaves the value
    unchanged, so a switch saved ON in a .blend needs this call to start drawing.
    """
    if _label_feature_enabled():
        return bool(register_handler())
    if _label_runtime_registered:
        return bool(unregister_handler())
    return True


def unregister_handler():
    """Disable every owned label resource; OFF means exact zero runtime hooks."""
    ledger = _label_ledger()
    if isinstance(ledger, dict) and ledger.get("token") is _LABEL_RUNTIME_TOKEN:
        return _cleanup_label_ledger(ledger)
    _clear_label_region_caches()
    return True


def finalize_runtime_generation() -> bool:
    """Remove this generation and its shared ledger during package unregister."""
    global _label_own_ledger
    namespace = _label_namespace()
    ledger = _label_ledger()
    ok = True
    if isinstance(ledger, dict) and ledger.get("token") is _LABEL_RUNTIME_TOKEN:
        ok = _cleanup_label_ledger(ledger)
        if namespace is not None:
            latest = namespace.get(_LABEL_LEDGER_KEY)
            if isinstance(latest, dict) and latest.get("token") is _LABEL_RUNTIME_TOKEN:
                namespace.pop(_LABEL_LEDGER_KEY, None)
    _label_own_ledger = None
    return bool(ok)


# ---------------------------------------------------------------------------
# Summary table cache
# ---------------------------------------------------------------------------

_table_cache = ()


def get_table_cache():
    return _table_cache


def _build_table_cache(context):
    global _table_cache
    s = context.scene.reporter_settings
    dp = int(s.decimal_places)
    base = get_scene_objects(context, limit=_MAX_TABLE_CACHE_ROWS)
    builtin_flags, computed_flags, custom_names = get_active_fields(s)
    custom_names = tuple(custom_names[:_MAX_TABLE_CUSTOM_FIELDS])
    active_custom_names = set(custom_names)
    cumulative_set = {
        f.name for f in s.shared_fields
        if f.name in active_custom_names and f.cumulative and f.enabled
    }
    sum_face_area = s.sum_face_area
    sum_volume = s.sum_volume
    need_geom = (
        computed_flags["face_area"]
        or computed_flags["volume"]
        or computed_flags["material_area"]
    )
    depsgraph = context.evaluated_depsgraph_get()
    rows = []
    for obj in base:
        if len(rows) >= _MAX_TABLE_CACHE_ROWS:
            break
        is_mesh = obj.type == "MESH"
        row = {
            "name": _bounded_text(obj.name, _MAX_TABLE_TEXT_CHARS),
            "obj_type": _bounded_text(obj.type, 64),
            "collection": _bounded_collection_names(
                getattr(obj, "users_collection", ()),
                _MAX_TABLE_TEXT_CHARS,
            ),
            "dimensions": None,
            "face_area": None,
            "volume": None,
            "mat_area": {},
            "custom": {},
        }
        if builtin_flags["dimensions"] and is_mesh:
            d = obj.dimensions
            row["dimensions"] = f"{d.x:.{dp}f} x {d.y:.{dp}f} x {d.z:.{dp}f}"
        if need_geom and is_mesh:
            bm = None
            try:
                bm = get_evaluated_bmesh(obj, depsgraph)
                if computed_flags["volume"]:
                    vol = get_object_volume(bm)
                    row["volume"] = (
                        f"{vol:.{dp}f}" if vol is not None else "(open mesh)"
                    )
                if computed_flags["face_area"] or computed_flags["material_area"]:
                    ta, ma = get_areas(obj, bm)
                    if computed_flags["face_area"]:
                        row["face_area"] = f"{ta:.{dp}f}"
                    if computed_flags["material_area"]:
                        row["mat_area"] = {
                            _bounded_text(m, 256): _bounded_text(f"{v:.{dp}f}", _MAX_TABLE_TEXT_CHARS)
                            for m, v in islice(ma.items(), _MAX_TABLE_MATERIAL_FIELDS)
                        }
            except Exception:
                pass
            finally:
                try:
                    if bm is not None:
                        bm.free()
                except Exception:
                    pass
        for k in custom_names:
            try:
                v = _resolve_prop(obj, k, depsgraph=depsgraph)
            except Exception:
                v = None
            row["custom"][k] = (
                _bounded_text(_fmt_num(v, dp), _MAX_TABLE_TEXT_CHARS)
                if v is not None else ""
            )
        rows.append(row)
    if s.group_by_enabled and s.group_by_field:
        rows = _aggregate_rows(
            rows,
            s.group_by_field,
            custom_names,
            cumulative_set,
            sum_face_area,
            sum_volume,
            dp,
        )
    _table_cache = tuple(rows[:_MAX_TABLE_CACHE_ROWS])
    set_table_dirty(False)


def _aggregate_rows(
    rows, group_by_key, custom_names, cumulative_set, sum_face_area, sum_volume, dp
):
    groups = OrderedDict()
    for row in rows:
        gv = row["custom"].get(group_by_key, "") or "(unset)"
        if gv not in groups:
            groups[gv] = {
                "count": 0,
                "custom_vals": defaultdict(list),
                "face_areas": [],
                "volumes": [],
            }
        groups[gv]["count"] += 1
        for k in custom_names:
            groups[gv]["custom_vals"][k].append(row["custom"].get(k, ""))
        if row["face_area"] is not None:
            groups[gv]["face_areas"].append(row["face_area"])
        if row["volume"] not in (None, "(open mesh)"):
            groups[gv]["volumes"].append(row["volume"])
    result = []
    for gv, data in groups.items():
        agg = {
            "group_value": gv,
            "count": data["count"],
            "fields": {},
            "face_area": None,
            "volume": None,
        }
        for k in custom_names:
            vals = data["custom_vals"][k]
            if k in cumulative_set:
                try:
                    total = sum(float(v) for v in vals if v != "")
                    agg["fields"][k] = f"{total:.{dp}f}"
                except ValueError:
                    unique = set(v for v in vals if v)
                    agg["fields"][k] = (
                        list(unique)[0] if len(unique) == 1 else "(multiple)"
                    )
            else:
                unique = list(dict.fromkeys(v for v in vals if v))
                if len(unique) == 0:
                    agg["fields"][k] = ""
                elif len(unique) == 1:
                    agg["fields"][k] = unique[0]
                else:
                    agg["fields"][k] = "(multiple)"
        if sum_face_area and data["face_areas"]:
            try:
                agg["face_area"] = f"{sum(float(v) for v in data['face_areas']):.{dp}f}"
            except ValueError:
                pass
        if sum_volume and data["volumes"]:
            try:
                agg["volume"] = f"{sum(float(v) for v in data['volumes']):.{dp}f}"
            except ValueError:
                pass
        result.append(agg)
    return result


# ---------------------------------------------------------------------------
# Operators — shared fields
# ---------------------------------------------------------------------------


class REPORTER_OT_object_reporter_add_field(Operator):
    bl_idname = 'reporter.sfs_object_reporter_add_field'
    bl_label = 'Add Summary Field'
    bl_property = "chosen"

    bl_options = {'UNDO'}
    def _items(self, context):
        return _build_lookup(get_all_custom_keys(context), _field_picker_lookup)

    chosen: EnumProperty(name="Field", items=_items)

    def execute(self, context):
        if self.chosen == "__none__":
            return {"CANCELLED"}
        real_key = _field_picker_lookup.get(self.chosen, "")
        if not real_key:
            return {"CANCELLED"}
        s = context.scene.reporter_settings
        for f in s.shared_fields:
            if f.name == real_key:
                self.report({"INFO"}, "Already in list")
                return {"FINISHED"}
        f = s.shared_fields.add()
        f.name = real_key
        f.enabled = True
        s.active_shared_field_index = len(s.shared_fields) - 1
        _mark_table_dirty()
        persist_reporter_settings(context)
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {"RUNNING_MODAL"}


class REPORTER_OT_object_reporter_remove_2(Operator):
    bl_idname = 'reporter.sfs_object_reporter_remove_2'
    bl_label = 'Remove Summary Field'
    index: IntProperty()

    bl_options = {'UNDO'}
    def execute(self, context):
        s = context.scene.reporter_settings
        if 0 <= self.index < len(s.shared_fields):
            s.shared_fields.remove(self.index)
            s.active_shared_field_index = max(0, s.active_shared_field_index - 1)
        _mark_table_dirty()
        persist_reporter_settings(context)
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Operators — grouping
# ---------------------------------------------------------------------------


class REPORTER_OT_object_reporter_pick_field(Operator):
    bl_idname = 'reporter.sfs_object_reporter_pick_field'
    bl_label = 'Pick Field'
    bl_property = "chosen"

    bl_options = {'UNDO'}
    def _items(self, context):
        s = context.scene.reporter_settings
        candidates = [f.name for f in s.shared_fields if f.enabled and f.name]
        return _build_lookup(candidates, _group_by_lookup)

    chosen: EnumProperty(name="Field", items=_items)

    def execute(self, context):
        if self.chosen == "__none__":
            return {"CANCELLED"}
        real_key = _group_by_lookup.get(self.chosen, "")
        if real_key:
            context.scene.reporter_settings.group_by_field = real_key
            _mark_table_dirty()
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {"RUNNING_MODAL"}


class REPORTER_OT_object_reporter_clear(Operator):
    bl_idname = 'reporter.sfs_object_reporter_clear'
    bl_label = 'Clear'

    bl_options = {'UNDO'}
    def execute(self, context):
        context.scene.reporter_settings.group_by_field = ""
        _mark_table_dirty()
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Operators — table / select / export
# ---------------------------------------------------------------------------


class REPORTER_OT_object_reporter_refresh(Operator):
    bl_idname = 'reporter.sfs_object_reporter_refresh'
    bl_label = 'Refresh'
    bl_description = "Recompute the summary table (evaluates geometry if needed)"

    bl_options = {'UNDO'}
    def execute(self, context):
        _build_table_cache(context)
        return {"FINISHED"}


class REPORTER_OT_object_reporter_select_2(Operator):
    bl_idname = 'reporter.sfs_object_reporter_select_2'
    bl_label = 'Select Listed Object'
    obj_name: StringProperty()

    bl_options = {'UNDO'}
    def execute(self, context):
        obj = context.view_layer.objects.get(self.obj_name)
        if obj is None:
            self.report({"WARNING"}, _ui_text(f"Not found: {self.obj_name}", f"見つかりません：{self.obj_name}"))
            return {"CANCELLED"}
        bpy.ops.object.select_all(action="DESELECT")
        try:
            obj.select_set(True)
            context.view_layer.objects.active = obj
        except RuntimeError as e:
            self.report({"WARNING"}, _sf_error_text(e))
        return {"FINISHED"}


class REPORTER_OT_object_reporter_export_csv(Operator):
    bl_idname = 'reporter.sfs_object_reporter_export_csv'
    bl_label = 'Export CSV'

    bl_options = {'UNDO'}
    def execute(self, context):
        s = context.scene.reporter_settings
        depsgraph = context.evaluated_depsgraph_get()
        objects = get_scene_objects(context)
        dp = int(s.decimal_places)

        if not objects:
            self.report({"WARNING"}, "No objects match scope")
            return {"CANCELLED"}

        builtin_flags, computed_flags, custom_names = get_active_fields(s)
        cumulative_set = {f.name for f in s.shared_fields if f.cumulative and f.enabled}
        export_path = bpy.path.abspath(s.export_path)
        os.makedirs(os.path.dirname(export_path) or ".", exist_ok=True)

        # Grouped export
        if s.export_grouped and s.group_by_enabled and s.group_by_field:
            rows = [
                {
                    "custom": {
                        k: (str(obj.get(k)) if obj.get(k) is not None else "")
                        for k in custom_names
                    }
                }
                for obj in objects
            ]
            groups = _aggregate_rows(
                rows,
                s.group_by_field,
                custom_names,
                cumulative_set,
                s.sum_face_area,
                s.sum_volume,
                dp,
            )
            header = [s.group_by_field, "count"] + custom_names
            try:
                with open(export_path, "w", newline="", encoding="utf-8") as f:
                    writer = csv.writer(f)
                    writer.writerow(header)
                    for grp in groups:
                        writer.writerow(
                            [grp["group_value"], grp["count"]]
                            + [grp["fields"].get(k, "") for k in custom_names]
                        )
            except PermissionError:
                self.report({"ERROR"}, _ui_text(f"Cannot write: {export_path}", f"書けません：{export_path}"))
                return {"CANCELLED"}
            self.report({"INFO"}, _ui_text(f"Exported {len(groups)} groups to {export_path}", f"グループ {len(groups)} 個を {export_path} へ書き出しました"))
            return {"FINISHED"}

        # Flat export
        need_geom = (
            computed_flags["face_area"]
            or computed_flags["volume"]
            or computed_flags["material_area"]
        )
        all_mats = set()
        if computed_flags["material_area"]:
            for obj in objects:
                try:
                    bm = get_evaluated_bmesh(obj, depsgraph)
                    _, ma = get_areas(obj, bm)
                    all_mats.update(ma.keys())
                    bm.free()
                except Exception:
                    pass
        all_mats = sorted(all_mats)

        header = ["name"]
        if builtin_flags["collection"]:
            header.append("collection")
        if builtin_flags["dimensions"]:
            header += ["dim_x", "dim_y", "dim_z"]
        if computed_flags["volume"]:
            header.append("volume")
        if computed_flags["face_area"]:
            header.append("face_area")
        if computed_flags["material_area"]:
            header += ["area_" + m for m in all_mats]
        header += custom_names

        try:
            with open(export_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(header)
                for obj in objects:
                    row = [obj.name]
                    if builtin_flags["collection"]:
                        row.append(", ".join(c.name for c in obj.users_collection))
                    if builtin_flags["dimensions"]:
                        d = obj.dimensions
                        row += [round(d.x, dp), round(d.y, dp), round(d.z, dp)]
                    if need_geom:
                        try:
                            bm = get_evaluated_bmesh(obj, depsgraph)
                            if computed_flags["volume"]:
                                vol = get_object_volume(bm)
                                row.append(
                                    round(vol, dp) if vol is not None else "(open mesh)"
                                )
                            if (
                                computed_flags["face_area"]
                                or computed_flags["material_area"]
                            ):
                                ta, ma = get_areas(obj, bm)
                                if computed_flags["face_area"]:
                                    row.append(round(ta, dp))
                                if computed_flags["material_area"]:
                                    row += [round(ma.get(m, 0.0), dp) for m in all_mats]
                            bm.free()
                        except Exception:
                            n = (
                                int(computed_flags["volume"])
                                + int(computed_flags["face_area"])
                                + (
                                    len(all_mats)
                                    if computed_flags["material_area"]
                                    else 0
                                )
                            )
                            row += ["ERROR"] * n
                    for k in custom_names:
                        v = obj.get(k, "")
                        if hasattr(v, "__iter__") and not isinstance(v, str):
                            v = json.dumps(list(v))
                        row.append(v)
                    writer.writerow(row)
        except PermissionError:
            self.report({"ERROR"}, _ui_text(f"Cannot write: {export_path}", f"書けません：{export_path}"))
            return {"CANCELLED"}
        self.report({"INFO"}, _ui_text(f"Exported {len(objects)} objects to {export_path}", f"オブジェクト {len(objects)} 個を {export_path} へ書き出しました"))
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# UI Lists
# ---------------------------------------------------------------------------


class REPORTER_UL_SharedFields(UIList):
    def draw_item(
        self, context, layout, data, item, icon, active_data, active_propname
    ):
        row = layout.row(align=True)
        row.prop(item, "enabled", text="")
        row.label(text=item.name, icon="DOT", translate=False)
        sub = row.row(align=True)
        sub.scale_x = 0.6
        sub.prop(item, "cumulative", text="Σ", toggle=True)


# ---------------------------------------------------------------------------
# Panels
# ---------------------------------------------------------------------------


class REPORTER_PT_object_reporter_object_reporter_viewport_labels(Panel):
    bl_label = 'Object Reporter Viewport Labels'
    bl_idname = 'REPORTER_PT_object_reporter_object_reporter_viewport_labels'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart File'
    bl_parent_id = 'REPORTER_PT_object_reporter_object_reporter'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 20

    def draw_header(self, context):
        self.layout.label(text="", icon="HIDE_OFF")

    def draw(self, context):
        layout = self.layout
        s = context.scene.reporter_settings
        layout.active = s.labels_enabled
        col = layout.column(align=True)
        col.prop(s, "label_font_size")
        col.prop(s, "label_color")
        row = col.row(align=True)
        row.prop(s, "label_offset_x")
        row.prop(s, "label_offset_y")


class REPORTER_PT_object_reporter_object_reporter_grouping(Panel):
    bl_label = 'Object Reporter Grouping'
    bl_idname = 'REPORTER_PT_object_reporter_object_reporter_grouping'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart File'
    bl_parent_id = 'REPORTER_PT_object_reporter_object_reporter'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 21

    def draw_header(self, context):
        self.layout.prop(context.scene.reporter_settings, "group_by_enabled", text="")

    def draw(self, context):
        layout = self.layout
        s = context.scene.reporter_settings
        layout.active = s.group_by_enabled

        row = layout.row(align=True)
        row.label(text="Group by:")
        if s.group_by_field:
            row.label(text=s.group_by_field, icon="OBJECT_DATA")
            row.operator("reporter.sfs_object_reporter_pick_field", text="", icon="DOWNARROW_HLT", emboss=True)
            row.operator("reporter.sfs_object_reporter_clear", text="", icon="X", emboss=True)
        else:
            row.operator(
                "reporter.sfs_object_reporter_pick_field",
                text="Choose field…",
                icon="DOWNARROW_HLT",
            )



class REPORTER_PT_object_reporter_object_reporter_summary(Panel):
    bl_label = 'Object Reporter Summary'
    bl_idname = 'REPORTER_PT_object_reporter_object_reporter_summary'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart File'
    bl_parent_id = 'REPORTER_PT_object_reporter_object_reporter'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 22

    def draw(self, context):
        layout = self.layout
        s = context.scene.reporter_settings
        table_cache = get_table_cache()

        if is_table_dirty():
            row = layout.row()
            row.alert = True
            row.operator(
                "reporter.sfs_object_reporter_refresh",
                icon="FILE_REFRESH",
                text="Refresh  ●  data changed",
            )
        else:
            layout.operator(
                "reporter.sfs_object_reporter_refresh", icon="FILE_REFRESH", text="Refresh"
            )

        if not table_cache:
            layout.separator()
            layout.label(text="Press Refresh to load.")
            return

        layout.separator()
        builtin_flags, computed_flags, custom_names = get_active_fields(s)
        is_grouped = s.group_by_enabled and s.group_by_field
        cumulative_set = {f.name for f in s.shared_fields if f.cumulative and f.enabled}
        is_grouped_cache = table_cache and "group_value" in table_cache[0]

        dp = int(s.decimal_places)

        # ===== GROUPED VIEW =====
        if is_grouped and is_grouped_cache:
            hbox = layout.box()
            hrow = hbox.row()
            hrow.label(text=s.group_by_field)
            hrow.label(text="Count")
            if computed_flags["face_area"] and s.sum_face_area:
                hrow.label(text="Σ Face Area")
            if computed_flags["volume"] and s.sum_volume:
                hrow.label(text="Σ Volume")
            for k in custom_names:
                hrow.label(text=("Σ " + k) if k in cumulative_set else k)
            col = layout.column(align=True)
            for grp in table_cache:
                rbox = col.box()
                row = rbox.row()
                row.label(text=grp["group_value"], icon="OBJECT_DATA")
                row.label(text=str(grp["count"]))
                if computed_flags["face_area"] and s.sum_face_area:
                    row.label(text=grp.get("face_area") or "—")
                if computed_flags["volume"] and s.sum_volume:
                    row.label(text=grp.get("volume") or "—")
                for k in custom_names:
                    row.label(text=grp["fields"].get(k, "—"))

            # Totals row
            if len(table_cache) > 1:
                tbox = col.box()
                trow = tbox.row()
                trow.label(text="Total", icon="PLUS")
                trow.label(text=str(sum(grp["count"] for grp in table_cache)))
                if computed_flags["face_area"] and s.sum_face_area:
                    vals = [
                        grp.get("face_area")
                        for grp in table_cache
                        if grp.get("face_area")
                    ]
                    try:
                        trow.label(
                            text=f"{sum(float(v) for v in vals):.{dp}f}"
                            if vals
                            else "—"
                        )
                    except ValueError:
                        trow.label(text="—")
                if computed_flags["volume"] and s.sum_volume:
                    vals = [
                        grp.get("volume") for grp in table_cache if grp.get("volume")
                    ]
                    try:
                        trow.label(
                            text=f"{sum(float(v) for v in vals):.{dp}f}"
                            if vals
                            else "—"
                        )
                    except ValueError:
                        trow.label(text="—")
                for k in custom_names:
                    if k in cumulative_set:
                        raw = [grp["fields"].get(k, "") for grp in table_cache]
                        try:
                            trow.label(
                                text=f"{sum(float(v) for v in raw if v not in ('', '—', '(multiple)')):.{dp}f}"
                            )
                        except ValueError:
                            trow.label(text="—")
                    else:
                        trow.label(text="")

        # ===== FLAT VIEW =====
        elif not is_grouped and not is_grouped_cache:
            hbox = layout.box()
            hrow = hbox.row()
            hrow.label(text="Name")
            if builtin_flags["collection"]:
                hrow.label(text="Collection")
            if builtin_flags["dimensions"]:
                hrow.label(text="Dimensions")
            if computed_flags["volume"]:
                hrow.label(text="Volume")
            if computed_flags["face_area"]:
                hrow.label(text="Face Area")
            if computed_flags["material_area"]:
                hrow.label(text="Mat. Area")
            for k in custom_names:
                hrow.label(text=k)
            col = layout.column(align=True)
            active_name = (
                context.view_layer.objects.active.name
                if context.view_layer.objects.active
                else ""
            )
            for rd in table_cache:
                rbox = col.box()
                row = rbox.row()
                is_active = rd["name"] == active_name
                op = row.operator(
                    "reporter.sfs_object_reporter_select_2",
                    text=rd["name"],
                    emboss=is_active,
                    icon="LAYER_ACTIVE" if is_active else "BLANK1", translate=False
                )
                op.obj_name = rd["name"]
                if builtin_flags["collection"]:
                    row.label(text=rd["collection"], translate=False)
                if builtin_flags["dimensions"]:
                    row.label(text=rd["dimensions"] or "—")
                if computed_flags["volume"]:
                    row.label(
                        text=str(rd["volume"]) if rd["volume"] is not None else "—"
                    )
                if computed_flags["face_area"]:
                    row.label(
                        text=str(rd["face_area"])
                        if rd["face_area"] is not None
                        else "—"
                    )
                if computed_flags["material_area"]:
                    row.label(
                        text=" / ".join(
                            m + ":" + str(v) for m, v in rd["mat_area"].items()
                        )
                        or "—"
                    )
                for k in custom_names:
                    row.label(text=rd["custom"].get(k, "") or "—")

            # Totals row
            has_cumulative = bool(cumulative_set & set(custom_names))
            has_computed_totals = (
                computed_flags["volume"] or computed_flags["face_area"]
            )
            if len(table_cache) > 1 and (has_cumulative or has_computed_totals):
                tbox = col.box()
                trow = tbox.row()
                trow.label(text="Total", icon="PLUS")
                if builtin_flags["collection"]:
                    trow.label(text="")
                if builtin_flags["dimensions"]:
                    trow.label(text="")
                if computed_flags["volume"]:
                    nums = [
                        float(rd["volume"])
                        for rd in table_cache
                        if rd["volume"] not in (None, "(open mesh)")
                    ]
                    trow.label(text=f"{sum(nums):.{dp}f}" if nums else "—")
                if computed_flags["face_area"]:
                    nums = [
                        float(rd["face_area"])
                        for rd in table_cache
                        if rd["face_area"] is not None
                    ]
                    trow.label(text=f"{sum(nums):.{dp}f}" if nums else "—")
                if computed_flags["material_area"]:
                    trow.label(text="")
                for k in custom_names:
                    if k in cumulative_set:
                        raw = [rd["custom"].get(k, "") for rd in table_cache]
                        try:
                            trow.label(
                                text=f"{sum(float(v) for v in raw if v not in ('', '—')):.{dp}f}"
                            )
                        except ValueError:
                            trow.label(text="—")
                    else:
                        trow.label(text="")

        else:
            layout.label(text="Press Refresh to update view.")


class REPORTER_PT_object_reporter_object_reporter_csv_export(Panel):
    bl_label = 'Object Reporter CSV Export'
    bl_idname = 'REPORTER_PT_object_reporter_object_reporter_csv_export'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart File'
    bl_parent_id = 'REPORTER_PT_object_reporter_object_reporter'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 23

    def draw(self, context):
        layout = self.layout
        s = context.scene.reporter_settings
        layout.prop(s, "export_path")
        layout.separator()
        row = layout.row(align=True)
        row.prop(s, "export_grouped", toggle=True, icon="LINENUMBERS_ON")
        if s.export_grouped:
            if s.group_by_enabled and s.group_by_field:
                row.label(text=_ui_text("by: " + s.group_by_field, "グループ：" + s.group_by_field), icon="OBJECT_DATA", translate=False)
            else:
                row.label(text="Enable Grouping panel first", icon="ERROR")
        layout.separator()
        layout.operator("reporter.sfs_object_reporter_export_csv", icon="EXPORT", text='Export CSV')
