"""Custom property editor (Tag Selected) and metadata presets."""

import bpy
from bpy.props import EnumProperty, IntProperty, StringProperty
from bpy.types import Operator, Panel, UIList

from .core import (
    _build_lookup,
    _is_user_key,
    _mark_table_dirty,
    _preset_value_lookup,
    _tag_value_lookup,
    get_all_custom_keys,
    get_values_for_key,
    persist_reporter_settings,
)
from ..ui_language_runtime import ui_text as _ui_text

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_selected_mesh_objects(context):
    """All selected mesh objects and collection instance empties,
    regardless of scope toggles — Tag Selected operates on viewport selection."""
    result = []
    for o in context.selected_objects:
        if o.type == "MESH":
            result.append(o)
        elif o.type == "EMPTY" and o.instance_type == "COLLECTION":
            result.append(o)
    return result


# ---------------------------------------------------------------------------
# Operators — Tag Selected
# ---------------------------------------------------------------------------


class REPORTER_OT_object_reporter_set_property(Operator):
    """Set a custom property to a value on all selected mesh objects"""

    bl_idname = 'reporter.sfs_object_reporter_set_property'
    bl_label = 'Set Property'
    bl_options = {'UNDO'}

    prop_name: StringProperty()
    prop_value: StringProperty(name="Value")

    def execute(self, context):
        objects = _get_selected_mesh_objects(context)
        if not objects:
            self.report({"WARNING"}, "No mesh objects selected")
            return {"CANCELLED"}
        for obj in objects:
            existing = obj.get(self.prop_name)
            if isinstance(existing, (int, float)):
                try:
                    obj[self.prop_name] = (
                        float(self.prop_value)
                        if "." in self.prop_value
                        else int(self.prop_value)
                    )
                except ValueError:
                    obj[self.prop_name] = self.prop_value
            else:
                obj[self.prop_name] = self.prop_value
        _mark_table_dirty()
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=280)

    def draw(self, context):
        row = self.layout.row(align=True)
        row.label(text=self.prop_name, translate=False)
        row = self.layout.row(align=True)
        row.prop(self, "prop_value", text="")
        op = row.operator(
            "reporter.sfs_object_reporter_pick_value_2", text="", icon="DOWNARROW_HLT", emboss=True
        )
        op.prop_name = self.prop_name
        op.prop_value = self.prop_value


class REPORTER_OT_object_reporter_pick_value_2(Operator):
    """Pick an existing value for this property from a searchable list"""

    bl_idname = 'reporter.sfs_object_reporter_pick_value_2'
    bl_label = 'Pick Property Value'
    bl_property = "chosen"

    prop_name: StringProperty()
    prop_value: StringProperty()

    bl_options = {'UNDO'}
    def _items(self, context):
        return _build_lookup(
            get_values_for_key(context, self.prop_name), _tag_value_lookup
        )

    chosen: EnumProperty(name="Value", items=_items)

    def execute(self, context):
        if self.chosen == "__none__":
            return {"CANCELLED"}
        real = _tag_value_lookup.get(self.chosen, "")
        if not real:
            return {"CANCELLED"}
        objects = _get_selected_mesh_objects(context)
        for obj in objects:
            existing = obj.get(self.prop_name)
            if isinstance(existing, (int, float)):
                try:
                    obj[self.prop_name] = float(real) if "." in real else int(real)
                except ValueError:
                    obj[self.prop_name] = real
            else:
                obj[self.prop_name] = real
        _mark_table_dirty()
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {"RUNNING_MODAL"}


class REPORTER_OT_object_reporter_remove_property(Operator):
    """Remove a custom property from all selected mesh objects"""

    bl_idname = 'reporter.sfs_object_reporter_remove_property'
    bl_label = 'Remove Property'
    bl_options = {'UNDO'}

    prop_name: StringProperty()

    def execute(self, context):
        objects = _get_selected_mesh_objects(context)
        removed = 0
        for obj in objects:
            if self.prop_name in obj:
                del obj[self.prop_name]
                removed += 1
        _mark_table_dirty()
        self.report({"INFO"}, _ui_text(f"Removed '{self.prop_name}' from {removed} object(s)", f"オブジェクト {removed} 個から「{self.prop_name}」を取り除きました"))
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Operators — Presets
# ---------------------------------------------------------------------------


class REPORTER_OT_object_reporter_add_preset(Operator):
    bl_idname = 'reporter.sfs_object_reporter_add_preset'
    bl_label = 'Add Preset'

    bl_options = {'UNDO'}
    def execute(self, context):
        s = context.scene.reporter_settings
        p = s.presets.add()
        p.name = "New Preset"
        s.active_preset_index = len(s.presets) - 1
        persist_reporter_settings(context)
        return {"FINISHED"}


class REPORTER_OT_object_reporter_remove_preset(Operator):
    bl_idname = 'reporter.sfs_object_reporter_remove_preset'
    bl_label = 'Remove Preset'

    bl_options = {'UNDO'}
    def execute(self, context):
        s = context.scene.reporter_settings
        if s.presets:
            s.presets.remove(s.active_preset_index)
            s.active_preset_index = max(0, s.active_preset_index - 1)
        persist_reporter_settings(context)
        return {"FINISHED"}


class REPORTER_OT_object_reporter_add_field_2(Operator):
    bl_idname = 'reporter.sfs_object_reporter_add_field_2'
    bl_label = 'Add Preset Field'

    bl_options = {'UNDO'}
    def execute(self, context):
        s = context.scene.reporter_settings
        if not s.presets:
            return {"CANCELLED"}
        preset = s.presets[s.active_preset_index]
        p = preset.properties.add()
        p.name = "new_field"
        preset.active_property_index = len(preset.properties) - 1
        persist_reporter_settings(context)
        return {"FINISHED"}


class REPORTER_OT_object_reporter_remove_field(Operator):
    bl_idname = 'reporter.sfs_object_reporter_remove_field'
    bl_label = 'Remove Preset Field'

    bl_options = {'UNDO'}
    def execute(self, context):
        s = context.scene.reporter_settings
        if not s.presets:
            return {"CANCELLED"}
        preset = s.presets[s.active_preset_index]
        if preset.properties:
            preset.properties.remove(preset.active_property_index)
            preset.active_property_index = max(0, preset.active_property_index - 1)
        persist_reporter_settings(context)
        return {"FINISHED"}


class REPORTER_OT_object_reporter_apply(Operator):
    bl_idname = 'reporter.sfs_object_reporter_apply'
    bl_label = 'Apply (keep existing)'

    bl_options = {'UNDO'}
    def execute(self, context):
        s = context.scene.reporter_settings
        if not s.presets:
            return {"CANCELLED"}
        preset = s.presets[s.active_preset_index]
        objs = context.selected_objects
        if not objs:
            self.report({"WARNING"}, "No objects selected")
            return {"CANCELLED"}
        for obj in objs:
            for p in preset.properties:
                if p.name not in obj:
                    obj[p.name] = p.default_value
        _mark_table_dirty()
        self.report({"INFO"}, _ui_text(f"Applied '{preset.name}' to {len(objs)} object(s)", f"オブジェクト {len(objs)} 個に「{preset.name}」を適用しました"))
        return {"FINISHED"}


class REPORTER_OT_object_reporter_apply_and_overwrite(Operator):
    bl_idname = 'reporter.sfs_object_reporter_apply_and_overwrite'
    bl_label = 'Apply & Overwrite'

    bl_options = {'UNDO'}
    def execute(self, context):
        s = context.scene.reporter_settings
        if not s.presets:
            return {"CANCELLED"}
        preset = s.presets[s.active_preset_index]
        objs = context.selected_objects
        if not objs:
            self.report({"WARNING"}, "No objects selected")
            return {"CANCELLED"}
        for obj in objs:
            for p in preset.properties:
                obj[p.name] = p.default_value
        _mark_table_dirty()
        self.report({"INFO"}, _ui_text(f"Overwrote '{preset.name}' on {len(objs)} object(s)", f"オブジェクト {len(objs)} 個の「{preset.name}」を上書きしました"))
        return {"FINISHED"}


class REPORTER_OT_object_reporter_add_as_filter(Operator):
    bl_idname = 'reporter.sfs_object_reporter_add_as_filter'
    bl_label = 'Add as Filter'
    field_name: StringProperty()

    bl_options = {'UNDO'}
    def execute(self, context):
        s = context.scene.reporter_settings
        cond = s.filter_conditions.add()
        cond.property_name = self.field_name
        cond.match_type = "EXACT"
        cond.logic = "AND"
        s.active_filter_index = len(s.filter_conditions) - 1
        persist_reporter_settings(context)
        return {"FINISHED"}


class REPORTER_OT_object_reporter_add_to_fields(Operator):
    bl_idname = 'reporter.sfs_object_reporter_add_to_fields'
    bl_label = 'Add to Fields'
    field_name: StringProperty()

    bl_options = {'UNDO'}
    def execute(self, context):
        s = context.scene.reporter_settings
        for f in s.shared_fields:
            if f.name == self.field_name:
                self.report({"INFO"}, "Already in fields list")
                return {"FINISHED"}
        f = s.shared_fields.add()
        f.name = self.field_name
        f.enabled = True
        _mark_table_dirty()
        persist_reporter_settings(context)
        return {"FINISHED"}


class REPORTER_OT_object_reporter_pick_value_3(Operator):
    bl_idname = 'reporter.sfs_object_reporter_pick_value_3'
    bl_label = 'Pick Preset Value'
    bl_property = "chosen"
    preset_index: IntProperty()
    property_index: IntProperty()

    bl_options = {'UNDO'}
    def _items(self, context):
        s = context.scene.reporter_settings
        key = ""
        try:
            key = s.presets[self.preset_index].properties[self.property_index].name
        except (IndexError, AttributeError):
            pass
        if not key:
            return [("__none__", "(set field name first)", "")]
        return _build_lookup(get_values_for_key(context, key), _preset_value_lookup)

    chosen: EnumProperty(name="Value", items=_items)

    def execute(self, context):
        if self.chosen == "__none__":
            return {"CANCELLED"}
        real_val = _preset_value_lookup.get(self.chosen, "")
        s = context.scene.reporter_settings
        try:
            s.presets[self.preset_index].properties[
                self.property_index
            ].default_value = real_val
        except (IndexError, AttributeError):
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {"RUNNING_MODAL"}


# ---------------------------------------------------------------------------
# UI Lists
# ---------------------------------------------------------------------------


class REPORTER_UL_Presets(UIList):
    def draw_item(
        self, context, layout, data, item, icon, active_data, active_propname
    ):
        layout.prop(item, "name", text="", emboss=False, icon="PRESET")


class REPORTER_UL_PresetProperties(UIList):
    def draw_item(
        self, context, layout, data, item, icon, active_data, active_propname
    ):
        s = context.scene.reporter_settings
        preset_idx = s.active_preset_index
        prop_idx = (
            next(
                (
                    i
                    for i, p in enumerate(s.presets[preset_idx].properties)
                    if p == item
                ),
                0,
            )
            if s.presets
            else 0
        )
        row = layout.row(align=True)
        row.prop(item, "name", text="", emboss=False, icon="DOT")
        row.prop(item, "default_value", text="", emboss=True)
        op_val = row.operator(
            "reporter.sfs_object_reporter_pick_value_3",
            text="",
            icon="DOWNARROW_HLT",
            emboss=True,
        )
        op_val.preset_index = preset_idx
        op_val.property_index = prop_idx
        op_flt = row.operator(
            "reporter.sfs_object_reporter_add_as_filter",
            text="",
            icon="FILTER",
            emboss=True,
        )
        op_flt.field_name = item.name
        op_shr = row.operator(
            "reporter.sfs_object_reporter_add_to_fields",
            text="",
            icon="LINENUMBERS_ON",
            emboss=True,
        )
        op_shr.field_name = item.name


# ---------------------------------------------------------------------------
# Panels
# ---------------------------------------------------------------------------


class REPORTER_PT_object_reporter_object_reporter_presets(Panel):
    bl_label = 'Object Reporter Presets'
    bl_idname = 'REPORTER_PT_object_reporter_object_reporter_presets'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart File'
    bl_parent_id = 'REPORTER_PT_object_reporter_object_reporter'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 1

    def draw(self, context):
        layout = self.layout
        s = context.scene.reporter_settings

        row = layout.row()
        row.template_list(
            "REPORTER_UL_Presets", "", s, "presets", s, "active_preset_index", rows=3
        )
        col = row.column(align=True)
        col.operator("reporter.sfs_object_reporter_add_preset", icon="ADD", text="", emboss=True)
        col.operator("reporter.sfs_object_reporter_remove_preset", icon="REMOVE", text="", emboss=True)

        if not s.presets:
            layout.label(text="No presets.")
            return

        preset = s.presets[s.active_preset_index]
        layout.separator()
        layout.label(text=_ui_text(f"Fields in '{preset.name}':", f"「{preset.name}」のフィールド："))
        row = layout.row()
        row.template_list("REPORTER_UL_PresetProperties", "", preset, "properties", preset, "active_property_index", rows=4)
        col = row.column(align=True)
        col.operator("reporter.sfs_object_reporter_add_field_2", icon="ADD", text="", emboss=True)
        col.operator("reporter.sfs_object_reporter_remove_field", icon="REMOVE", text="", emboss=True)

        layout.separator()
        layout.label(text="Apply to Selected Objects:")
        row = layout.row(align=True)
        row.operator("reporter.sfs_object_reporter_apply", icon="OBJECT_DATA")
        row.operator("reporter.sfs_object_reporter_apply_and_overwrite", icon="FILE_REFRESH")


class REPORTER_PT_object_reporter_object_reporter_tag_selected(Panel):
    bl_label = 'Object Reporter Tag Selected'
    bl_idname = 'REPORTER_PT_object_reporter_object_reporter_tag_selected'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart File'
    bl_parent_id = 'REPORTER_PT_object_reporter_object_reporter'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 2

    def draw(self, context):
        layout = self.layout
        s = context.scene.reporter_settings
        show_internal = s.show_internal_props
        objects = _get_selected_mesh_objects(context)

        if not objects:
            layout.label(text="No mesh objects selected.")
            return

        sets = [
            set(k for k in obj.keys() if _is_user_key(k, show_internal))
            for obj in objects
        ]
        if s.tag_props_show_all:
            keys = sorted(set().union(*sets))
        else:
            keys = sorted(sets[0].intersection(*sets[1:]) if len(sets) > 1 else sets[0])

        row = layout.row(align=True)
        row.label(text=_ui_text(f"{len(objects)} object(s) selected", f"オブジェクト {len(objects)} 個を選択中"))
        sub = row.row(align=True)
        sub.alignment = "RIGHT"
        sub.prop(
            s,
            "tag_props_show_all",
            toggle=True,
            text="Any" if s.tag_props_show_all else "All",
            icon="ASSET_MANAGER" if s.tag_props_show_all else "RESTRICT_SELECT_OFF",
        )

        if not keys:
            layout.separator()
            if s.tag_props_show_all:
                layout.label(text="No custom properties found.")
            else:
                layout.label(text="No shared properties. Switch to Any.")
            return

        layout.separator()

        col = layout.column(align=True)
        for k in keys:
            vals = [str(obj[k]) for obj in objects if k in obj]
            all_same = len(set(vals)) == 1
            display = vals[0] if all_same else "(various)"

            box = col.box()
            row = box.row(align=True)
            row.label(text=k, icon="DOT")

            op_set = row.operator(
                "reporter.sfs_object_reporter_set_property", text=display, emboss=True
            )
            op_set.prop_name = k
            op_set.prop_value = vals[0] if all_same else ""

            if s.tag_props_show_all and len(vals) < len(objects):
                row.label(text=f"{len(vals)}/{len(objects)}")

            op_del = row.operator(
                "reporter.sfs_object_reporter_remove_property", text="", icon="X", emboss=True
            )
            op_del.prop_name = k
