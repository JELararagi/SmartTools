"""Main panel, Fields sub-panel, and Output section header."""

from bpy.types import Panel


class REPORTER_PT_object_reporter_object_reporter(Panel):
    bl_label = 'Object Reporter'
    bl_idname = 'REPORTER_PT_object_reporter_object_reporter'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart File'
    bl_parent_id = 'SF_PT_reference_manager_reference_manager_workspace'
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header(self, context):
        self.layout.label(text="", icon="TEXT")

    def draw(self, context):
        s = context.scene.reporter_settings
        row = self.layout.row(align=True)
        row.prop(s, "visible_only", toggle=True, icon="HIDE_OFF")
        row.prop(s, "selected_only", toggle=True, icon="RESTRICT_SELECT_OFF")
        row.prop(s, "tagged_only", toggle=True, icon="PROPERTIES")
        row.prop(s, "show_internal_props", toggle=True, icon="SYSTEM")
        row2 = self.layout.row(align=True)
        row2.label(text="Precision:")
        row2.prop(s, "decimal_places", text="")


class REPORTER_PT_object_reporter_object_reporter_fields(Panel):
    bl_label = 'Object Reporter Fields'
    bl_idname = 'REPORTER_PT_object_reporter_object_reporter_fields'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart File'
    bl_parent_id = 'REPORTER_PT_object_reporter_object_reporter'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 0

    def draw(self, context):
        layout = self.layout
        s = context.scene.reporter_settings

        col = layout.column(align=True)
        col.prop(s, "field_show_name")
        col.prop(s, "field_show_collection")
        col.prop(s, "field_show_dimensions")

        layout.separator()
        layout.label(text="Computed geometry:")
        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(s, "field_show_face_area")
        sub = row.row(align=True)
        sub.scale_x = 0.45
        sub.active = s.field_show_face_area
        sub.prop(s, "sum_face_area", text="Σ", toggle=True)
        row = col.row(align=True)
        row.prop(s, "field_show_volume")
        sub = row.row(align=True)
        sub.scale_x = 0.45
        sub.active = s.field_show_volume
        sub.prop(s, "sum_volume", text="Σ", toggle=True)
        col.prop(s, "field_show_material_area")

        layout.separator()
        layout.label(text="Custom properties:")
        row = layout.row()
        row.template_list("REPORTER_UL_SharedFields", "", s, "shared_fields", s, "active_shared_field_index", rows=4)
        col = row.column(align=True)
        col.operator("reporter.sfs_object_reporter_add_field", icon="ADD", text="", emboss=True)
        op = col.operator("reporter.sfs_object_reporter_remove_2", icon="REMOVE", text="", emboss=True)
        op.index = s.active_shared_field_index


class REPORTER_PT_object_reporter_object_reporter_output(Panel):
    bl_label = 'Object Reporter Output'
    bl_idname = 'REPORTER_PT_object_reporter_object_reporter_output'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart File'
    bl_parent_id = 'REPORTER_PT_object_reporter_object_reporter'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 15

    def draw(self, context):
        pass
