"""Shared constants, helpers, geometry utilities, and property groups."""

import json
import time

import bmesh
import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import PropertyGroup
from mathutils import Vector

try:
    from ..ui_language_runtime import ui_text as _or_ui_text
except Exception:  # pragma: no cover
    def _or_ui_text(en: str, ja: str) -> str:
        return str(en)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

INTERNAL_KEYS = {
    "cycles",
    "cycles_visibility",
    "cycles_object_shader",
    "material_mapping",
    "vs",
    "vl",
    "vp",
    "viewport_display",
    "grease_pencil_modifiers",
    "use_extra_recalc_object",
    "use_extra_recalc_data",
}

BUILTIN_FIELDS = ["name", "collection", "dim_x", "dim_y", "dim_z"]

SUPPORTED_TYPES = {"MESH", "EMPTY", "CURVE"}
_MAX_ENUM_LOOKUP_ITEMS = 8192


# ---------------------------------------------------------------------------
# Table dirty state (mutable container so all modules share it)
# ---------------------------------------------------------------------------

_table_state = {"dirty": True}


def persist_reporter_settings(context=None):
    """Queue Reporter N-panel settings through the suite persistence gate."""
    try:
        from .. import settings as _sf_persist
        if hasattr(_sf_persist, "schedule_save"):
            _sf_persist.schedule_save(context or getattr(bpy, "context", None))
    except Exception:
        pass


def _persist_reporter_property(self=None, context=None):
    persist_reporter_settings(context)


def _mark_table_dirty(self=None, context=None):
    _table_state["dirty"] = True
    try:
        ctx = context or getattr(bpy, "context", None)
        scene = getattr(ctx, "scene", None)
        settings = getattr(scene, "reporter_settings", None)
        if settings is not None and bool(getattr(settings, "labels_enabled", False)):
            from .reporter import mark_label_cache_dirty
            mark_label_cache_dirty(0.5)
    except Exception:
        pass
    persist_reporter_settings(context)


def _mark_label_style_dirty(self=None, context=None):
    try:
        from .reporter import mark_label_cache_dirty
        mark_label_cache_dirty(0.5)
    except Exception:
        pass
    persist_reporter_settings(context)


def is_table_dirty():
    return _table_state["dirty"]


def set_table_dirty(val):
    _table_state["dirty"] = val


# ---------------------------------------------------------------------------
# Formatting / key helpers
# ---------------------------------------------------------------------------


def _fmt_num(value, dp):
    """Format a value as a fixed-point number with exactly dp decimal places.
    Non-numeric values are returned as plain strings unchanged."""
    try:
        return f"{float(value):.{dp}f}"
    except (TypeError, ValueError):
        return str(value)


def _is_user_key(k, show_internal):
    if k.startswith("_"):
        return False
    if not show_internal and k in INTERNAL_KEYS:
        return False
    return True


# ---------------------------------------------------------------------------
# Unicode-safe enum helpers
# ---------------------------------------------------------------------------

_prop_name_lookup = {}
_prop_value_lookup = {}
_field_picker_lookup = {}
_preset_value_lookup = {}
_group_by_lookup = {}
_tag_value_lookup = {}


def _build_lookup(strings, table):
    table.clear()
    items = []
    for i, sv in enumerate(strings):
        if i >= _MAX_ENUM_LOOKUP_ITEMS:
            break
        key = str(i)
        table[key] = sv
        items.append((key, sv, sv))
    return items or [("__none__", "(none)", "")]


# ---------------------------------------------------------------------------
# Object collection helpers
# ---------------------------------------------------------------------------


def _collection_instance_children(obj, depsgraph):
    """Return child mesh objects for a collection instance empty.

    For local collections (library=None): use all_objects directly —
    the originals are writable and .keys() works correctly.

    For linked collections (library is not None): use the depsgraph to get
    evaluated instances, since linked originals are read-only and .keys()
    returns empty on them."""
    if not (
        obj.type == "EMPTY"
        and obj.instance_type == "COLLECTION"
        and obj.instance_collection
    ):
        return []

    coll = obj.instance_collection

    # Local collection — originals are fully readable, no depsgraph needed
    if coll.library is None:
        return [child for child in coll.all_objects if child.type == "MESH"]

    # Linked collection — must use evaluated depsgraph objects
    if depsgraph is None:
        return []

    coll_names = {child.name for child in coll.all_objects if child.type == "MESH"}
    obj_eval = obj.evaluated_get(depsgraph)

    # Try parent-pointer match first
    by_parent = [
        inst.object for inst in depsgraph.object_instances
        if inst.parent is not None
        and (inst.parent.original is obj or inst.parent is obj_eval)
        and inst.object.type == "MESH"
    ]
    if by_parent:
        return by_parent

    # Fallback: match by name within the collection
    return [
        inst.object for inst in depsgraph.object_instances
        if inst.is_instance
        and inst.object.type == "MESH"
        and inst.object.name in coll_names
    ]


def _has_user_props(obj, show_internal, depsgraph=None):
    """True if obj itself has user custom props, or (for collection instances)
    any child mesh object does. Accepts depsgraph for linked library support."""
    if any(_is_user_key(k, show_internal) for k in obj.keys()):
        return True
    for child in _collection_instance_children(obj, depsgraph):
        if any(_is_user_key(k, show_internal) for k in child.keys()):
            return True
    return False


def _resolve_prop(obj, key, viewport=False, depsgraph=None):
    """Priority/fallback custom property resolution.

    viewport=True: for collection instances, only return the empty's own
    property — no child rollup. This keeps viewport labels clean and
    top-level only.

    viewport=False (table/export): full priority/fallback —
    1. Own property on the object wins for that specific key.
    2. For collection instances with no own value: sum numeric or
       unanimous string from child meshes (including linked library objects,
       accessed via depsgraph so their properties are readable).
    3. Returns None if not found anywhere.

    Crucially, each key is resolved independently — overriding 'Svoris'
    on the empty does not affect 'Sklypas' which will still roll up from
    children if they all agree."""
    v = obj.get(key)
    if v is not None:
        return v
    if viewport:
        return None
    children = _collection_instance_children(obj, depsgraph)
    if not children:
        return None
    child_vals = []
    for child in children:
        cv = child.get(key)
        if cv is not None:
            child_vals.append(cv)
    if not child_vals:
        return None
    try:
        return sum(float(v) for v in child_vals)
    except (TypeError, ValueError):
        pass
    strs = list(dict.fromkeys(str(v) for v in child_vals))
    if len(strs) == 1:
        return strs[0]
    return f"({', '.join(strs)})" if len(strs) <= 3 else "(multiple)"


def get_scene_objects(context, limit=None):
    """Return current original datablocks without reading ``ID.original``.

    ``DepsgraphObjectInstance.object.original`` is a native PointerProperty read.
    Blender 5.1/5.1.2 can invalidate that owner around autosave/homefile boundaries
    before Python gets a catchable exception.  Resolve the live datablock by its
    current evaluated name while the iterator item is valid, and never retain the
    ``DepsgraphObjectInstance`` or evaluated Object wrapper.
    """
    s = context.scene.reporter_settings
    depsgraph = context.evaluated_depsgraph_get()
    try:
        max_items = max(0, int(limit)) if limit is not None else None
    except Exception:
        max_items = None
    if max_items == 0:
        return []
    seen_keys = set()
    result = []
    try:
        iterable = depsgraph.object_instances
    except Exception:
        iterable = ()
    for instance in iterable:
        try:
            evaluated = instance.object
            name = str(getattr(evaluated, "name_full", "") or getattr(evaluated, "name", "") or "")
            if not name:
                continue
            obj = bpy.data.objects.get(name)
            if obj is None:
                # Linked objects can expose the evaluated name with a library
                # suffix.  A scene lookup remains pointer-safe and deterministic.
                obj = context.scene.objects.get(name)
            if obj is None:
                continue
            library_path = str(getattr(getattr(obj, "library", None), "filepath", "") or "")
            key = (name, library_path)
            if key in seen_keys:
                continue
            seen_keys.add(key)
            if obj.type not in SUPPORTED_TYPES:
                continue
            if obj.type == "EMPTY" and obj.instance_type != "COLLECTION":
                continue
            if s.visible_only and obj.hide_viewport:
                continue
            if s.selected_only and not obj.select_get():
                continue
            if s.tagged_only and not _has_user_props(obj, s.show_internal_props, depsgraph):
                continue
            result.append(obj)
            if max_items is not None and len(result) >= max_items:
                break
        except (ReferenceError, RuntimeError):
            continue
        except Exception:
            continue
    return result


def get_all_custom_keys(context):
    show_internal = context.scene.reporter_settings.show_internal_props
    depsgraph = context.evaluated_depsgraph_get()
    keys = set()
    for obj in get_scene_objects(context):
        for k in obj.keys():
            if _is_user_key(k, show_internal):
                keys.add(k)
        # Also expose keys from collection instance children (incl. linked)
        for child in _collection_instance_children(obj, depsgraph):
            for k in child.keys():
                if _is_user_key(k, show_internal):
                    keys.add(k)
    return sorted(keys)


def get_values_for_key(context, key):
    values = set()
    kl = key.strip().lower()
    depsgraph = context.evaluated_depsgraph_get()
    for obj in get_scene_objects(context):
        if kl == "name":
            values.add(obj.name)
        elif kl == "collection":
            values.update(c.name for c in obj.users_collection)
        elif kl == "dim_x":
            values.add(str(round(obj.dimensions.x, 4)))
        elif kl == "dim_y":
            values.add(str(round(obj.dimensions.y, 4)))
        elif kl == "dim_z":
            values.add(str(round(obj.dimensions.z, 4)))
        else:
            v = _resolve_prop(obj, key.strip(), depsgraph=depsgraph)
            if v is not None:
                sv = str(v).strip()
                if sv:
                    values.add(sv)
    return sorted(values)


# ---------------------------------------------------------------------------
# Shared fields helper
# ---------------------------------------------------------------------------


def get_active_fields(s):
    builtin_flags = {
        "name": s.field_show_name,
        "collection": s.field_show_collection,
        "dimensions": s.field_show_dimensions,
    }
    computed_flags = {
        "face_area": s.field_show_face_area,
        "volume": s.field_show_volume,
        "material_area": s.field_show_material_area,
    }
    custom_names = [f.name for f in s.shared_fields if f.enabled and f.name]
    return builtin_flags, computed_flags, custom_names


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------


def get_evaluated_bmesh(obj, depsgraph):
    """Return a bmesh in WORLD space — modifiers applied, vertices
    transformed by the object's world matrix."""
    obj_eval = obj.evaluated_get(depsgraph)
    me = obj_eval.to_mesh()
    bm = bmesh.new()
    bm.from_mesh(me)
    obj_eval.to_mesh_clear()
    bm.transform(obj.matrix_world)
    bmesh.ops.triangulate(bm, faces=bm.faces)
    return bm


def get_object_volume(bm):
    """Signed-tetrahedra volume sum. Returns None for open meshes."""
    for edge in bm.edges:
        if len(edge.link_faces) != 2:
            return None
    vol = 0.0
    for face in bm.faces:
        v0 = face.verts[0].co
        for i in range(1, len(face.verts) - 1):
            vol += v0.dot(face.verts[i].co.cross(face.verts[i + 1].co))
    return abs(vol) / 6.0


def get_areas(obj, bm):
    """Per-face area summed by material slot."""
    total, mat_areas = 0.0, {}
    mat_names = [
        sl.material.name if sl.material else "No Material" for sl in obj.material_slots
    ]
    for face in bm.faces:
        a = face.calc_area()
        total += a
        mn = (
            mat_names[face.material_index]
            if face.material_index < len(mat_names)
            else "No Material"
        )
        mat_areas[mn] = mat_areas.get(mn, 0.0) + a
    return total, mat_areas


# ---------------------------------------------------------------------------
# Property Groups
# ---------------------------------------------------------------------------


class REPORTER_PropertyDefinition(PropertyGroup):
    name: StringProperty(name="Field Name", default="property", update=_persist_reporter_property)
    default_value: StringProperty(name="Default Value", default="", update=_persist_reporter_property)


class REPORTER_Preset(PropertyGroup):
    name: StringProperty(name="Preset Name", default="New Preset", update=_persist_reporter_property)
    properties: CollectionProperty(type=REPORTER_PropertyDefinition)
    active_property_index: IntProperty(update=_persist_reporter_property)


class REPORTER_FilterCondition(PropertyGroup):
    property_name: StringProperty(name="Property", default="", update=_persist_reporter_property)
    match_type: EnumProperty(
        name="Match",
        default="EXACT",
        items=[
            ("EXACT", "==", "Exact match"),
            ("CONTAINS", "contains", "Value contains string"),
            ("GT", ">", "Greater than (numeric)"),
            ("LT", "<", "Less than (numeric)"),
            ("GTE", ">=", "Greater than or equal"),
            ("LTE", "<=", "Less than or equal"),
            ("EMPTY", "is empty", "Not set or blank"),
            ("NOTEMPTY", "is not empty", "Set and not blank"),
        ],
        update=_persist_reporter_property,
    )
    value: StringProperty(name="Value", default="", update=_persist_reporter_property)
    logic: EnumProperty(
        name="Logic",
        default="AND",
        items=[
            ("AND", "AND", ""),
            ("OR", "OR", ""),
        ],
        update=_persist_reporter_property,
    )


class REPORTER_SharedField(PropertyGroup):
    name: StringProperty(name="Field", default="", update=_mark_table_dirty)
    enabled: BoolProperty(name="Show", default=True, update=_mark_table_dirty)
    cumulative: BoolProperty(
        name="Sum",
        default=False,
        update=_mark_table_dirty,
        description="Sigma: sum numeric values in grouped rows; non-numeric shows unanimous value or (multiple)",
    )


def _on_labels_toggle(self, context):
    # Lazy import to avoid circular dependency
    from .reporter import redraw_all_viewports, register_handler, unregister_handler

    if self.labels_enabled:
        register_handler()
    else:
        unregister_handler()
    redraw_all_viewports()
    try:
        from .. import settings as _sf_persist
        if hasattr(_sf_persist, 'schedule_save'):
            _sf_persist.schedule_save(context or getattr(bpy, 'context', None))
    except Exception:
        pass


class REPORTER_SceneSettings(PropertyGroup):
    # ---- Scope ----
    visible_only: BoolProperty(
        name="Visible Only", default=False, update=_mark_table_dirty
    )
    selected_only: BoolProperty(
        name="Selected Only", default=True, update=_mark_table_dirty
    )
    tagged_only: BoolProperty(
        name="Tagged Only",
        default=True,
        update=_mark_table_dirty,
        description="Only include objects that have at least one custom property",
    )
    show_internal_props: BoolProperty(
        name="Internal Props", default=False, update=_mark_table_dirty
    )

    # ---- Fields ----
    field_show_name: BoolProperty(
        name="Object Name", default=True, update=_mark_table_dirty
    )
    field_show_collection: BoolProperty(
        name="Collection", default=False, update=_mark_table_dirty
    )
    field_show_dimensions: BoolProperty(
        name="Dimensions", default=False, update=_mark_table_dirty
    )
    field_show_face_area: BoolProperty(
        name="Face Area", default=False, update=_mark_table_dirty
    )
    field_show_volume: BoolProperty(
        name="Volume", default=False, update=_mark_table_dirty
    )
    field_show_material_area: BoolProperty(
        name="Area per Material", default=False, update=_mark_table_dirty
    )
    sum_face_area: BoolProperty(
        name="Σ",
        default=False,
        update=_mark_table_dirty,
        description="Sum face area across grouped rows",
    )
    sum_volume: BoolProperty(
        name="Σ",
        default=False,
        update=_mark_table_dirty,
        description="Sum volume across grouped rows",
    )
    decimal_places: EnumProperty(
        name="Precision",
        default="2",
        update=_mark_table_dirty,
        description="Number of decimal places used in all numeric outputs",
        items=[
            ("0", "1", "No decimals  e.g. 3"),
            ("1", "1.0", "1 decimal place"),
            ("2", "1.00", "2 decimal places"),
            ("3", "1.000", "3 decimal places"),
            ("4", "1.0000", "4 decimal places"),
        ],
    )

    shared_fields: CollectionProperty(type=REPORTER_SharedField)
    active_shared_field_index: IntProperty(update=_persist_reporter_property)

    # ---- Grouping (shared) ----
    group_by_enabled: BoolProperty(
        name="Group Rows", default=False, update=_mark_table_dirty
    )
    group_by_field: StringProperty(
        name="Group by", default="", update=_mark_table_dirty
    )

    # ---- Presets ----
    presets: CollectionProperty(type=REPORTER_Preset)
    active_preset_index: IntProperty(update=_persist_reporter_property)

    # ---- Filter ----
    filter_conditions: CollectionProperty(type=REPORTER_FilterCondition)
    active_filter_index: IntProperty(update=_persist_reporter_property)

    # ---- Tag Selected ----
    tag_props_show_all: BoolProperty(
        name="Show All / Any",
        default=False,
        description="Off = show only properties present on ALL selected objects (intersection). On = show properties from ANY selected object (union)",
    )

    # ---- Labels ----
    labels_enabled: BoolProperty(
        name='Show Viewport Labels',
        default=False,
        update=_on_labels_toggle,
        description='Show object-report labels as a live viewport overlay. Turn this on only when you need the overlay to keep drawing while you work, and turn it off to remove the draw handler and reduce viewport overhead.',
    )
    label_font_size: IntProperty(name="Font Size", default=12, min=8, max=32, update=_mark_label_style_dirty)
    label_color: FloatVectorProperty(
        name="Color", subtype="COLOR", default=(1.0, 1.0, 1.0), min=0.0, max=1.0, update=_mark_label_style_dirty
    )
    label_offset_x: IntProperty(name="Offset X", default=10, min=-200, max=200, update=_mark_label_style_dirty)
    label_offset_y: IntProperty(name="Offset Y", default=10, min=-200, max=200, update=_mark_label_style_dirty)

    # ---- Export ----
    export_path: StringProperty(
        name="Export Path", default="//object_report.csv", subtype="FILE_PATH"
    )
    export_grouped: BoolProperty(name="Use Grouping", default=False)
