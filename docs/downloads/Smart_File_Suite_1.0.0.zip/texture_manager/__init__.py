# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

# ══════════════════════════════════════════════════════════════════════════════
# Texture File Path Editor  v2.0.0
# ══════════════════════════════════════════════════════════════════════════════

bl_info = {
    "name":        "Texture File Path Editor",
    "author": "JELararagi",
    "version":     (2, 0, 0),
    "blender": (5, 1, 0),
    "location":    "View3D > Sidebar > Texture Manager",
    "description": "Manage, relink, gather and inspect all texture paths in one panel",
    "category":    "Material",
}

import bpy
import os
import shutil
from collections import defaultdict, deque
from bpy.types  import Operator, Panel, UIList, PropertyGroup
from bpy.props  import (BoolProperty, StringProperty, IntProperty,
                        CollectionProperty, EnumProperty, PointerProperty)

from ..ui_language_runtime import ui_text as _ui_text
from .. import load_hooks as _load_hooks


# ══════════════════════════════════════════════════════════════════════════════
# CONSTANTS
# ══════════════════════════════════════════════════════════════════════════════

OCTANE_IMAGE_NODES = {
    "ShaderNodeOctImageTexture", "ShaderNodeOctGrayImageTexture",
    "ShaderNodeOctAlphaImageTexture", "ShaderNodeOctFloatImageTexture",
    "ShaderNodeOctFloatImageTex", "ShaderNodeOctGreyscaleImageTexture",
    "ShaderNodeOctRGBImageTexture", "OctaneImageTexture",
    "OctaneImage", "OctaneImageTextureNode",
}

FILTER_ITEMS = [
    ("ALL",       "All",       "Show all textures"),
    ("CONNECTED", "Connected", "Show only connected textures"),
    ("MISSING",   "Missing",   "Show only missing textures"),
    ("PACKED",    "Packed",    "Show only packed textures"),
    ("UNUSED",    "Unused",    "Show images not used in any node"),
]

OUTPUT_TYPES = {
    "OUTPUT_MATERIAL", "OUTPUT_WORLD", "OUTPUT_LIGHT",
    "OCT_OUTPUT_AOV", "OCTANE_MATERIAL_OUTPUT", "OCTANE_SHADER_OUT",
}


# ══════════════════════════════════════════════════════════════════════════════
# CACHE
# ══════════════════════════════════════════════════════════════════════════════

_cache: dict = {}
_diagnostics_cache: dict = {}


def _empty_diagnostics() -> dict:
    return {
        "counts": {"ALL": 0, "CONNECTED": 0, "MISSING": 0, "PACKED": 0, "UNUSED": 0},
        "has_missing": False,
        "can_delete_missing_or_unused": False,
        "directory_valid": False,
        "disk_size_mb": 0.0,
        "refreshed": False,
    }


def _diagnostics(scene) -> dict:
    name = str(getattr(scene, "name", "") or "")
    return dict(_diagnostics_cache.get(name) or _empty_diagnostics())

def _get(scene_name: str) -> list:
    return _cache.get(scene_name, [])

def _set(scene_name: str, data: list) -> None:
    _cache[scene_name] = data


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def image_status(img) -> str:
    if img.packed_file:
        return "PACKED"
    if img.source == "FILE" and img.filepath:
        return "CONNECTED" if os.path.exists(bpy.path.abspath(img.filepath)) else "MISSING"
    return "MISSING"


def image_folder(img) -> str:
    if img.packed_file:
        return "[Packed]"
    if img.filepath:
        d = os.path.dirname(bpy.path.abspath(img.filepath))
        return (d or "(No Path)").replace("\\", "/")
    return "(No Path)"


def image_is_unused(img) -> bool:
    for mat in bpy.data.materials:
        if not (mat.use_nodes and mat.node_tree):
            continue
        for node in mat.node_tree.nodes:
            if getattr(node, "image", None) == img:
                return False
    for tex in bpy.data.textures:
        if getattr(tex, "image", None) == img:
            return False
    return True


def image_info(img) -> str:
    try:
        if img.size[0] and img.size[1]:
            # Do not touch img.colorspace_settings.name here.
            # Some migrated or externally generated image datablocks can carry
            # an invalid colorspace enum value, and merely reading that RNA
            # property can emit Blender warnings such as:
            # "current value '-1' matches no enum in
            #  'ColorManagedInputColorspaceSettings'".
            # Keep the refresh pass read-only and warning-free.
            return f"{img.size[0]}x{img.size[1]}"
    except Exception:
        pass
    return ""


def build_file_index(root_dir: str) -> dict:
    index = {}
    if not (root_dir and os.path.isdir(root_dir)):
        return index
    for dirpath, _, files in os.walk(root_dir):
        for f in files:
            index[f.lower()] = os.path.join(dirpath, f)
    return index


def _connected_nodes(nt) -> set:
    connected = set()
    queue     = deque()
    for n in nt.nodes:
        if n.type in OUTPUT_TYPES:
            connected.add(n)
            queue.append(n)
    while queue:
        n = queue.popleft()
        for inp in n.inputs:
            for link in inp.links:
                up = link.from_node
                if up not in connected:
                    connected.add(up)
                    queue.append(up)
    return connected


def _count_by_status(scene=None) -> dict:
    """Read counts prepared by the explicit Refresh operator."""
    return dict(_diagnostics(scene or getattr(bpy.context, "scene", None))["counts"])


def _rebuild_list_from_cache(scene):
    backup = _get(scene.name)
    scene.texmgr_list.clear()
    for data in backup:
        if data["item_type"] == 0:
            _add_item(scene, data)
        else:
            hdr = next((h for h in backup
                        if h["item_type"] == 0 and h["display_name"] == data["dir_path"]), None)
            if hdr and not hdr.get("is_expanded", True):
                continue
            _add_item(scene, data)
    try:
        scene.texmgr_list_index = -1
    except Exception:
        pass


def _add_item(scene, data: dict):
    it = scene.texmgr_list.add()
    for k, v in data.items():
        try:
            setattr(it, k, v)
        except Exception:
            pass


def _disk_size_mb(img) -> float:
    try:
        p = bpy.path.abspath(img.filepath)
        if os.path.isfile(p):
            return os.path.getsize(p) / (1024 * 1024)
    except Exception:
        pass
    return 0.0


# ══════════════════════════════════════════════════════════════════════════════
# PROPERTY GROUPS
# ══════════════════════════════════════════════════════════════════════════════

class TexItem(PropertyGroup):
    item_type:      IntProperty(default=1)
    display_name:   StringProperty(default="")
    image_name_ref: StringProperty(default="")
    dir_path:       StringProperty(default="")
    status:         StringProperty(default="MISSING")
    is_expanded:    BoolProperty(default=True)
    is_selected:    BoolProperty(default=False)
    img_info:       StringProperty(default="")
    is_unused:      BoolProperty(default=False)


def _sync_texmgr_load_handler():
    try:
        scene = getattr(bpy.context, 'scene', None)
        settings = getattr(scene, 'texmgr_settings', None) if scene is not None else None
        enabled = bool(getattr(settings, 'auto_refresh_on_file_load', False)) if settings is not None else False
    except Exception:
        enabled = False
    if enabled:
        if _on_load not in _load_hooks.LOAD_POST_HOOKS:
            _load_hooks.LOAD_POST_HOOKS.append(_on_load)
    else:
        if _on_load in _load_hooks.LOAD_POST_HOOKS:
            _load_hooks.LOAD_POST_HOOKS.remove(_on_load)


def sync_runtime_after_settings() -> None:
    _sync_texmgr_load_handler()


def _on_texmgr_auto_refresh_update(self, context):
    _sync_texmgr_load_handler()
    try:
        from .. import settings as _sf_persist
        if hasattr(_sf_persist, 'schedule_save'):
            _sf_persist.schedule_save(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        wm = getattr(context, 'window_manager', None) if context is not None else getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


class TexMgrSettings(PropertyGroup):
    show_compare:      BoolProperty(name="Compare",     default=False)
    compare_directory: StringProperty(name="Compare Dir", subtype="DIR_PATH")
    auto_refresh_on_file_load: BoolProperty(
        name='Auto Refresh on File Load',
        default=False,
        update=_on_texmgr_auto_refresh_update,
        description=(
            'Refresh the texture list automatically after a Blender file is opened. Keep this off to avoid extra startup and file-load overhead, and turn it on only when you want Texture Manager to rescan automatically.'
        ),
    )


# ══════════════════════════════════════════════════════════════════════════════
# UI LIST
# ══════════════════════════════════════════════════════════════════════════════

class TEXMGR_UL_list(UIList):
    def draw_item(self, context, layout, data, item, icon,
                  active_data, active_propname, index):

        if item.item_type == 0:
            split    = layout.split(factor=0.03)
            col_tri  = split.column(align=True)
            col_main = split.column(align=True)
            tri = "TRIA_DOWN" if item.is_expanded else "TRIA_RIGHT"
            op  = col_tri.operator("texmgr.sfs_texture_manager_toggle_group", text="", icon=tri, emboss=True)
            op.group_index = index
            row = col_main.row(align=True)
            chk = row.operator("texmgr.sfs_texture_manager_toggle_select", text="",
                               icon="CHECKBOX_HLT" if item.is_selected else "CHECKBOX_DEHLT",
                               emboss=True)
            chk.group_index = index
            left = row.row(align=True)
            folder_text = item.display_name
            if folder_text == "(No Path)":
                folder_text = _ui_text("(No Path)", "（パスなし）")
            elif folder_text == "[Packed]":
                folder_text = _ui_text("[Packed]", "［パック済み］")
            left.label(text=folder_text, icon="FILE_FOLDER")
            right = row.row(align=True)
            right.alignment = "RIGHT"
            right.label(text=f"({item.image_name_ref})", translate=False)
            cp = right.operator("texmgr.sfs_texture_manager_copy_path", text="", icon="COPYDOWN", emboss=True)
            cp.group_index = index
            return

        STATUS_ICON = {
            "CONNECTED": "CHECKMARK",
            "MISSING":   "CANCEL",
            "PACKED":    "PACKAGE",
        }
        split    = layout.split(factor=0.05)
        col_icon = split.column(align=True)
        col_main = split.column(align=True)
        col_icon.alert = (item.status == "MISSING")
        col_icon.label(text="", icon=STATUS_ICON.get(item.status, "QUESTION"))
        row = col_main.row(align=True)
        row.alert = (item.status == "MISSING")
        left = row.row(align=True)
        left.label(text=item.display_name, translate=False)
        right = row.row(align=True)
        right.alignment = "RIGHT"
        if item.is_unused:
            right.label(text="unused", icon="ORPHAN_DATA")
        if item.img_info:
            right.label(text=item.img_info)
        op = right.operator("texmgr.sfs_texture_manager_select_node", text="", icon="NODE", emboss=True)
        op.image_name = item.image_name_ref
        rn = right.operator("texmgr.sfs_texture_manager_rename_image", text="", icon="GREASEPENCIL", emboss=True)
        rn.image_name = item.image_name_ref


# ══════════════════════════════════════════════════════════════════════════════
# OPERATORS — List management
# ══════════════════════════════════════════════════════════════════════════════

class TEXMGR_OT_texture_manager_refresh(Operator):
    bl_idname      = 'texmgr.sfs_texture_manager_refresh'
    bl_label       = 'Refresh'
    bl_description = "Scan all images and rebuild the list"

    bl_options = {'UNDO'}
    def execute(self, context):
        scene       = context.scene
        filter_mode = scene.texmgr_filter
        backup      = _get(scene.name)
        prev        = {(e["item_type"], e["display_name"]): e
                       for e in backup if e["item_type"] == 0}
        used_images = set()
        for mat in bpy.data.materials:
            if not (mat.use_nodes and mat.node_tree):
                continue
            for node in mat.node_tree.nodes:
                image = getattr(node, "image", None)
                if image is not None:
                    used_images.add(image)
        for tex in bpy.data.textures:
            image = getattr(tex, "image", None)
            if image is not None:
                used_images.add(image)

        grouped: dict = defaultdict(list)
        status_by_image = {}
        unused_by_image = {}
        counts = {"ALL": 0, "CONNECTED": 0, "MISSING": 0, "PACKED": 0, "UNUSED": 0}
        total_disk_mb = 0.0
        for img in bpy.data.images:
            grouped[image_folder(img)].append(img)
            status = image_status(img)
            unused = img not in used_images
            status_by_image[img] = status
            unused_by_image[img] = unused
            counts["ALL"] += 1
            if status in counts:
                counts[status] += 1
            if unused:
                counts["UNUSED"] += 1
            if not img.packed_file:
                total_disk_mb += _disk_size_mb(img)
        all_data = []
        for folder, imgs in sorted(grouped.items()):
            def _passes(img):
                st = status_by_image.get(img, "MISSING")
                if filter_mode == "ALL":    return True
                if filter_mode == "UNUSED": return bool(unused_by_image.get(img))
                return st == filter_mode
            visible = [(img, status_by_image.get(img, "MISSING")) for img in imgs if _passes(img)]
            if not visible:
                continue
            old = prev.get((0, folder), {})
            all_data.append({
                "item_type": 0, "display_name": folder,
                "image_name_ref": str(len(visible)), "dir_path": folder,
                "status": "HEADER", "is_expanded": old.get("is_expanded", False),
                "is_selected": old.get("is_selected", False),
                "img_info": "", "is_unused": False,
            })
            for img, st in visible:
                all_data.append({
                    "item_type": 1, "display_name": img.name,
                    "image_name_ref": img.name, "dir_path": folder,
                    "status": st, "is_expanded": True, "is_selected": False,
                    "img_info": image_info(img), "is_unused": bool(unused_by_image.get(img)),
                })
        _set(scene.name, all_data)
        directory = str(getattr(scene, "texmgr_directory", "") or "").strip()
        _diagnostics_cache[scene.name] = {
            "counts": counts,
            "has_missing": bool(counts["MISSING"]),
            "can_delete_missing_or_unused": bool(counts["MISSING"] or counts["UNUSED"]),
            "directory_valid": bool(directory and os.path.isdir(bpy.path.abspath(directory))),
            "disk_size_mb": float(total_disk_mb),
            "refreshed": True,
        }
        _rebuild_list_from_cache(scene)
        self.report({"INFO"}, _ui_text(f"Found {len(bpy.data.images)} image(s) in {len(grouped)} folder(s).", f"{len(grouped)} 個のフォルダーに画像 {len(bpy.data.images)} 枚が見つかりました。"))
        return {"FINISHED"}


class TEXMGR_OT_texture_manager_toggle_group(Operator):
    bl_label = 'Toggle Group'
    bl_idname = 'texmgr.sfs_texture_manager_toggle_group'; bl_label = "Toggle Group"
    bl_description = "Expand or collapse this folder group"
    group_index: IntProperty()
    bl_options = {'UNDO'}
    def execute(self, context):
        scene = context.scene
        items = scene.texmgr_list
        if not (0 <= self.group_index < len(items)): return {"CANCELLED"}
        item = items[self.group_index]
        if item.item_type != 0: return {"CANCELLED"}
        item.is_expanded = not item.is_expanded
        backup = _get(scene.name)
        for e in backup:
            if e["item_type"] == 0 and e["display_name"] == item.display_name:
                e["is_expanded"] = item.is_expanded; break
        _set(scene.name, backup)
        _rebuild_list_from_cache(scene)
        return {"FINISHED"}


class TEXMGR_OT_texture_manager_toggle_select(Operator):
    bl_label = 'Toggle Select'
    bl_idname = 'texmgr.sfs_texture_manager_toggle_select'; bl_label = "Toggle Select"
    bl_description = "Select or deselect this folder for batch operations"
    group_index: IntProperty()
    bl_options = {'UNDO'}
    def execute(self, context):
        scene = context.scene
        items = scene.texmgr_list
        if not (0 <= self.group_index < len(items)): return {"CANCELLED"}
        item = items[self.group_index]
        if item.item_type != 0: return {"CANCELLED"}
        item.is_selected = not item.is_selected
        backup = _get(scene.name)
        for e in backup:
            if e["item_type"] == 0 and e["display_name"] == item.display_name:
                e["is_selected"] = item.is_selected; break
        _set(scene.name, backup)
        try: scene.texmgr_list_index = -1
        except Exception: pass
        return {"FINISHED"}


class TEXMGR_OT_texture_manager_copy_path(Operator):
    bl_label = 'Copy Path'
    bl_idname = 'texmgr.sfs_texture_manager_copy_path'; bl_label = "Copy Path"
    bl_description = "Copy this folder path to the clipboard"
    group_index: IntProperty()
    bl_options = {'UNDO'}
    def execute(self, context):
        items = context.scene.texmgr_list
        if not (0 <= self.group_index < len(items)): return {"CANCELLED"}
        item = items[self.group_index]
        if item.item_type != 0: return {"CANCELLED"}
        context.window_manager.clipboard = item.display_name
        self.report({"INFO"}, _ui_text(f"Copied: {item.display_name}", f"コピーしました：{item.display_name}"))
        return {"FINISHED"}


class TEXMGR_OT_texture_manager_select_by_status(Operator):
    bl_label = 'Select by Status'
    bl_idname = 'texmgr.sfs_texture_manager_select_by_status'; bl_label = "Select by Status"
    bl_description = "Select all folder groups containing images of this status"
    status: StringProperty()
    bl_options = {'UNDO'}
    def execute(self, context):
        scene  = context.scene
        backup = _get(scene.name)
        folders = set()
        for e in backup:
            if e["item_type"] == 1:
                if self.status == "UNUSED":
                    img = bpy.data.images.get(e["image_name_ref"])
                    if img and image_is_unused(img): folders.add(e["dir_path"])
                elif e["status"] == self.status:
                    folders.add(e["dir_path"])
        count = 0
        for e in backup:
            if e["item_type"] == 0 and e["display_name"] in folders:
                e["is_selected"] = True; count += 1
        _set(scene.name, backup)
        _rebuild_list_from_cache(scene)
        self.report({"INFO"}, _ui_text(f"Selected {count} folder(s).", f"フォルダー {count} 個を選択しました。"))
        return {"FINISHED"}


class TEXMGR_OT_texture_manager_deselect_all(Operator):
    bl_label = 'Deselect All'
    bl_idname = 'texmgr.sfs_texture_manager_deselect_all'; bl_label = "Deselect All"
    bl_description = "Deselect all folder groups"
    bl_options = {'UNDO'}
    def execute(self, context):
        backup = _get(context.scene.name)
        for e in backup:
            if e["item_type"] == 0: e["is_selected"] = False
        _set(context.scene.name, backup)
        _rebuild_list_from_cache(context.scene)
        return {"FINISHED"}


class TEXMGR_OT_texture_manager_rename_image(Operator):
    bl_label = 'Rename Image'
    bl_idname  = 'texmgr.sfs_texture_manager_rename_image'; bl_label = "Rename Image"
    bl_description = "Rename this image datablock"; bl_options = {'UNDO'}
    image_name: StringProperty()
    new_name:   StringProperty(name="New Name")
    def invoke(self, context, event):
        self.new_name = self.image_name
        return context.window_manager.invoke_props_dialog(self)
    def draw(self, context): self.layout.prop(self, "new_name", text="Name")
    def execute(self, context):
        img = bpy.data.images.get(self.image_name)
        if not img: self.report({"ERROR"}, "Image not found."); return {"CANCELLED"}
        img.name = self.new_name.strip() or self.image_name
        bpy.ops.texmgr.sfs_texture_manager_refresh()
        self.report({"INFO"}, _ui_text(f"Renamed to '{img.name}'.", f"「{img.name}」へ名前を変えました。")); return {"FINISHED"}


# ══════════════════════════════════════════════════════════════════════════════
# OPERATORS — Relocate / Gather / Pack / Unpack
# ══════════════════════════════════════════════════════════════════════════════

class TEXMGR_OT_texture_manager_relink(Operator):
    bl_label = 'Relink'
    bl_idname = 'texmgr.sfs_texture_manager_relink'; bl_label = "Relink"
    bl_description = "Search chosen directory recursively and relink matching textures"
    bl_options = {'UNDO'}
    @classmethod
    def poll(cls, context):
        d = context.scene.texmgr_directory.strip()
        return bool(d)
    def execute(self, context):
        scene    = context.scene
        root_dir = bpy.path.abspath(scene.texmgr_directory.strip())
        selected = {it.display_name for it in scene.texmgr_list
                    if it.item_type == 0 and it.is_selected}
        index  = build_file_index(root_dir)
        images = [img for img in bpy.data.images
                  if not img.packed_file
                  and (not selected or image_folder(img) in selected)]
        wm = context.window_manager
        wm.progress_begin(0, max(len(images), 1))
        relinked = 0
        for i, img in enumerate(images):
            wm.progress_update(i)
            filepath = bpy.path.abspath(img.filepath) if img.filepath else ""
            filename = os.path.basename(filepath) or img.name
            if not filename: continue
            found = index.get(filename.lower())
            if not found: continue
            try:
                img.source = "FILE"; img.filepath = found; img.reload(); relinked += 1
            except Exception: pass
        wm.progress_end()
        bpy.ops.texmgr.sfs_texture_manager_refresh()
        self.report({"INFO"}, _ui_text(f"Relinked {relinked} texture(s).", f"テクスチャ {relinked} 枚を再リンクしました。")); return {"FINISHED"}


class TEXMGR_OT_texture_manager_collect(Operator):
    bl_label = 'Collect'
    bl_idname = 'texmgr.sfs_texture_manager_collect'; bl_label = "Collect"
    bl_description = "Copy all externally linked texture files into the chosen directory"
    bl_options = {'UNDO'}
    @classmethod
    def poll(cls, context):
        d = context.scene.texmgr_directory.strip()
        return bool(d)
    def execute(self, context):
        dest   = bpy.path.abspath(context.scene.texmgr_directory.strip())
        images = list(bpy.data.images)
        wm     = context.window_manager; wm.progress_begin(0, max(len(images), 1))
        copied = skipped = 0
        for i, img in enumerate(images):
            wm.progress_update(i)
            if img.packed_file or not img.filepath: skipped += 1; continue
            src = bpy.path.abspath(img.filepath)
            if not os.path.exists(src): skipped += 1; continue
            dst = os.path.join(dest, os.path.basename(src))
            try:
                if os.path.abspath(src) != os.path.abspath(dst): shutil.copy2(src, dst)
                copied += 1
            except Exception: skipped += 1
        wm.progress_end()
        self.report({"INFO"}, _ui_text(f"Collected {copied}, skipped {skipped}.", f"{copied} 枚を集め、{skipped} 枚を飛ばしました。")); return {"FINISHED"}


class TEXMGR_OT_texture_manager_pack(Operator):
    bl_label = 'Pack'
    bl_idname = 'texmgr.sfs_texture_manager_pack'; bl_label = "Pack"
    bl_description = "Pack images from selected folder groups into the blend file"
    bl_options = {'UNDO'}
    @classmethod
    def poll(cls, context):
        return any(it.is_selected and it.item_type == 0 for it in context.scene.texmgr_list)
    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)
    def execute(self, context):
        selected = {it.display_name for it in context.scene.texmgr_list
                    if it.item_type == 0 and it.is_selected}
        count = 0
        for img in bpy.data.images:
            if img.packed_file or image_folder(img) not in selected: continue
            try: img.pack(); count += 1
            except Exception: pass
        bpy.ops.texmgr.sfs_texture_manager_refresh()
        self.report({"INFO"}, _ui_text(f"Packed {count} image(s).", f"画像 {count} 枚をパックしました。")); return {"FINISHED"}


class TEXMGR_OT_texture_manager_unpack(Operator):
    bl_label = 'Unpack'
    bl_idname = 'texmgr.sfs_texture_manager_unpack'
    bl_description = "Unpack packed images from the blend file to disk"
    method: EnumProperty(name="Method", items=[
        ("USE_LOCAL",    "Use files in current directory", ""),
        ("WRITE_LOCAL",  "Write files to current directory", ""),
        ("USE_ORIGINAL", "Use original file paths", ""),
        ("REMOVE",       "Remove packed data", ""),
    ], default="WRITE_LOCAL")
    bl_options = {'UNDO'}
    def invoke(self, context, event): return context.window_manager.invoke_props_dialog(self)
    def draw(self, context): self.layout.prop(self, "method", expand=True)
    def execute(self, context):
        selected = [it.display_name for it in context.scene.texmgr_list
                    if it.item_type == 0 and it.is_selected]
        count = 0
        for img in bpy.data.images:
            if not img.packed_file: continue
            if selected and image_folder(img) not in selected: continue
            try: img.unpack(method=self.method); count += 1
            except Exception: pass
        bpy.ops.texmgr.sfs_texture_manager_refresh()
        self.report({"INFO"}, _ui_text(f"Unpacked {count} image(s).", f"画像 {count} 枚をパックから取り出しました。")); return {"FINISHED"}


# ══════════════════════════════════════════════════════════════════════════════
# OPERATORS — Image data actions
# ══════════════════════════════════════════════════════════════════════════════

class TEXMGR_OT_texture_manager_delete_missing_and_unused(Operator):
    bl_label = 'Delete Missing & Unused'
    bl_idname = 'texmgr.sfs_texture_manager_delete_missing_and_unused'; bl_label = "Delete Missing & Unused"
    bl_description = "Remove images missing from disk AND images not used in any node"
    bl_options = {'UNDO'}
    @classmethod
    def poll(cls, context):
        return bool(_diagnostics(context.scene).get("can_delete_missing_or_unused"))
    def invoke(self, context, event): return context.window_manager.invoke_confirm(self, event)
    def execute(self, context):
        removed = 0
        for img in list(bpy.data.images):
            if image_status(img) == "MISSING" or image_is_unused(img):
                try: bpy.data.images.remove(img, do_unlink=True); removed += 1
                except Exception: pass
        bpy.ops.texmgr.sfs_texture_manager_refresh()
        self.report({"INFO"}, _ui_text(f"Deleted {removed} image(s).", f"画像 {removed} 枚を削除しました。")); return {"FINISHED"}

class TEXMGR_OT_texture_manager_remap_duplicates(Operator):
    bl_label = 'Remap Duplicates'
    bl_idname = 'texmgr.sfs_texture_manager_remap_duplicates'; bl_label = "Remap Duplicates"
    bl_description = "Remap duplicate image nodes to originals, then delete unused copies"
    bl_options = {'UNDO'}
    def invoke(self, context, event): return context.window_manager.invoke_confirm(self, event)
    def execute(self, context):
        groups: dict = defaultdict(list)
        for img in bpy.data.images:
            base = (img.name.rsplit(".", 1)[0]
                    if "." in img.name and img.name.rsplit(".", 1)[1].isdigit()
                    else img.name)
            groups[base].append(img)
        to_delete = []; remapped = 0
        for base, imgs in groups.items():
            if len(imgs) <= 1: continue
            imgs.sort(key=lambda i: i.name); original = imgs[0]
            for dup in imgs[1:]:
                if dup == original: continue
                for mat in bpy.data.materials:
                    if not (mat.use_nodes and mat.node_tree): continue
                    for node in mat.node_tree.nodes:
                        if node.type == "TEX_IMAGE" and getattr(node,"image",None) == dup:
                            node.image = original; remapped += 1
                for tex in bpy.data.textures:
                    if getattr(tex,"image",None) == dup: tex.image = original; remapped += 1
                if dup.users == 0: to_delete.append(dup)
        deleted = 0
        for img in to_delete:
            if img.users == 0:
                try: bpy.data.images.remove(img); deleted += 1
                except Exception: pass
        bpy.ops.texmgr.sfs_texture_manager_refresh()
        if not remapped and not deleted: self.report({"INFO"}, "No duplicates found.")
        else: self.report({"INFO"}, _ui_text(f"Remapped {remapped}, deleted {deleted}.", f"{remapped} 枚を付け替え、{deleted} 枚を削除しました。"))
        return {"FINISHED"}


class TEXMGR_OT_texture_manager_make_relative(Operator):
    bl_label = 'Make Relative'
    bl_idname = 'texmgr.sfs_texture_manager_make_relative'; bl_label = "Make Relative"
    bl_description = "Make all texture paths relative to the blend file"
    bl_options = {'UNDO'}
    @classmethod
    def poll(cls, context): return bool(bpy.data.filepath)
    def execute(self, context):
        count = 0
        for img in bpy.data.images:
            if img.packed_file or not img.filepath: continue
            try:
                abs_p = bpy.path.abspath(img.filepath)
                if os.path.isfile(abs_p): img.filepath = bpy.path.relpath(abs_p); count += 1
            except Exception: pass
        bpy.ops.texmgr.sfs_texture_manager_refresh()
        self.report({"INFO"}, _ui_text(f"Made {count} path(s) relative.", f"パス {count} 個を相対にしました。")); return {"FINISHED"}


class TEXMGR_OT_texture_manager_make_absolute(Operator):
    bl_label = 'Make Absolute'
    bl_idname = 'texmgr.sfs_texture_manager_make_absolute'; bl_label = "Make Absolute"
    bl_description = "Make all texture paths absolute"
    bl_options = {'UNDO'}
    def execute(self, context):
        count = 0
        for img in bpy.data.images:
            if img.packed_file or not img.filepath: continue
            try: img.filepath = bpy.path.abspath(img.filepath); count += 1
            except Exception: pass
        bpy.ops.texmgr.sfs_texture_manager_refresh()
        self.report({"INFO"}, _ui_text(f"Made {count} path(s) absolute.", f"パス {count} 個を絶対にしました。")); return {"FINISHED"}


class TEXMGR_OT_texture_manager_change_directory(Operator):
    bl_label = 'Change Directory'
    bl_idname = 'texmgr.sfs_texture_manager_change_directory'; bl_label = "Change Directory"
    bl_description = "Change directory for all images in selected folder groups"
    bl_options = {'UNDO'}
    new_dir: StringProperty(name="New Directory", subtype="DIR_PATH")
    @classmethod
    def poll(cls, context):
        return any(it.is_selected and it.item_type==0 for it in context.scene.texmgr_list)
    def invoke(self, context, event):
        self.new_dir = ""; return context.window_manager.invoke_props_dialog(self)
    def draw(self, context): self.layout.prop(self, "new_dir", text="Directory")
    def execute(self, context):
        selected = {it.display_name for it in context.scene.texmgr_list
                    if it.item_type == 0 and it.is_selected}
        new_dir = bpy.path.abspath(self.new_dir.strip())
        if not os.path.isdir(new_dir):
            self.report({"ERROR"}, "Directory does not exist."); return {"CANCELLED"}
        count = 0
        for img in bpy.data.images:
            # 描画結果や生成画像はファイルを持たないので、パスを与えない
            if img.packed_file or img.library or img.source not in {"FILE", "SEQUENCE", "MOVIE", "TILED"}: continue
            if image_folder(img) not in selected: continue
            filename = os.path.basename(bpy.path.abspath(img.filepath)) if img.filepath else img.name
            try: img.filepath = os.path.join(new_dir, filename); img.reload(); count += 1
            except Exception: pass
        bpy.ops.texmgr.sfs_texture_manager_refresh()
        self.report({"INFO"}, _ui_text(f"Updated {count} image(s).", f"画像 {count} 枚を更新しました。")); return {"FINISHED"}


class TEXMGR_OT_texture_manager_select_node(Operator):
    bl_label = 'Select Node'
    bl_idname = 'texmgr.sfs_texture_manager_select_node'; bl_label = "Select Node"
    bl_description = "Select the object using this texture and jump to its node"
    image_name: StringProperty()
    bl_options = {'UNDO'}
    def _find_node(self, image):
        for mat in bpy.data.materials:
            if not (mat.use_nodes and mat.node_tree): continue
            for node in mat.node_tree.nodes:
                idname = getattr(node,"bl_idname","") or getattr(node,"type","")
                if ((node.type=="TEX_IMAGE" or idname in OCTANE_IMAGE_NODES)
                        and getattr(node,"image",None)==image): return mat, node
        return None, None
    def _find_owner(self, mat):
        return next((obj for obj in bpy.data.objects
                     if obj.type=="MESH" and any(s.material==mat for s in obj.material_slots)), None)
    def _find_shader_editor(self, context):
        for area in context.screen.areas:
            if area.type != "NODE_EDITOR": continue
            for sp in area.spaces:
                if getattr(sp,"tree_type","") == "ShaderNodeTree": return area, sp
        return None, None
    def execute(self, context):
        image = bpy.data.images.get(self.image_name)
        if not image: self.report({"ERROR"}, "Image not found."); return {"CANCELLED"}
        mat, node = self._find_node(image)
        if not node: self.report({"WARNING"}, _ui_text(f"Not used in any shader node.", f"どのシェーダーノードでも使われていません。")); return {"CANCELLED"}
        owner = self._find_owner(mat)
        if owner:
            try:
                bpy.ops.object.select_all(action="DESELECT")
                owner.select_set(True); context.view_layer.objects.active = owner
            except Exception: pass
        area, space = self._find_shader_editor(context)
        if not area: self.report({"WARNING"}, "No Shader Editor open."); return {"CANCELLED"}
        try: space.shader_type = "OBJECT"
        except Exception: pass
        try:
            for n in mat.node_tree.nodes: n.select = False
            node.select = True; mat.node_tree.nodes.active = node
            space.node_tree = mat.node_tree
        except Exception: pass
        try:
            with context.temp_override(area=area, space_data=space, region=area.regions[-1]):
                bpy.ops.node.view_selected("INVOKE_DEFAULT", use_all=False)
        except Exception: pass
        self.report({"INFO"}, f"{owner.name if owner else '?'} -> {mat.name} -> {node.name}")
        return {"FINISHED"}


# ══════════════════════════════════════════════════════════════════════════════
# NODE CLEANUP
# ══════════════════════════════════════════════════════════════════════════════

def _cleanup(mat) -> int:
    if not (mat and mat.node_tree): return 0
    nt = mat.node_tree; unused = set(nt.nodes) - _connected_nodes(nt); count = 0
    for n in list(unused):
        try: nt.nodes.remove(n); count += 1
        except Exception: pass
    return count


class NODE_OT_texture_manager_clean_selected(Operator):
    bl_label = 'Clean Selected'
    bl_idname = 'node.sfs_texture_manager_clean_selected'; bl_label = "Clean Selected"
    bl_description = "Remove disconnected nodes from materials on selected objects"
    bl_options = {'UNDO'}
    def invoke(self, context, event): return context.window_manager.invoke_confirm(self, event)
    def execute(self, context):
        removed = sum(_cleanup(s.material) for obj in context.selected_objects
                      for s in getattr(obj,"material_slots",[]) if s.material)
        self.report({"INFO"}, _ui_text(f"Removed {removed} unused node(s).", f"未使用のノード {removed} 個を取り除きました。")); return {"FINISHED"}


class NODE_OT_texture_manager_clean_all(Operator):
    bl_label = 'Clean All'
    bl_idname = 'node.sfs_texture_manager_clean_all'; bl_label = "Clean All"
    bl_description = "Remove disconnected nodes from every material in this file"
    bl_options = {'UNDO'}
    def invoke(self, context, event): return context.window_manager.invoke_confirm(self, event)
    def execute(self, context):
        removed = sum(_cleanup(m) for m in bpy.data.materials)
        self.report({"INFO"}, _ui_text(f"Removed {removed} unused node(s).", f"未使用のノード {removed} 個を取り除きました。")); return {"FINISHED"}


# ══════════════════════════════════════════════════════════════════════════════
# PANEL
# ══════════════════════════════════════════════════════════════════════════════

class TEXMGR_PT_texture_manager_texture_file_path_editor(Panel):
    bl_idname = 'TEXMGR_PT_texture_manager_texture_file_path_editor'
    bl_label = 'Texture File Path Editor'
    bl_space_type = "VIEW_3D"; bl_region_type = "UI"; bl_category = "Smart File"
    bl_parent_id = 'SF_PT_reference_manager_reference_manager_workspace'
    bl_options = set()

    def draw_header(self, context):
        has_missing = bool(_diagnostics(context.scene).get("has_missing"))
        self.layout.alert = has_missing
        self.layout.label(text="", icon="IMAGE_DATA")

    def draw(self, context):
        layout = self.layout
        scene  = context.scene
        if not hasattr(scene, 'texmgr_filter'):
            layout.label(text="Restart Blender to finish loading.")
            return
        settings = scene.texmgr_settings
        diagnostics = _diagnostics(scene)
        counts = dict(diagnostics.get("counts") or _empty_diagnostics()["counts"])

        # ── Filter + Refresh ──────────────────────────────────────────────
        top = layout.row(align=True)
        top.prop(scene, "texmgr_filter", text="")
        top.operator("texmgr.sfs_texture_manager_refresh", text="Refresh", icon="FILE_REFRESH", emboss=True)
        if not diagnostics.get("refreshed"):
            layout.label(text="Press Refresh to scan textures")
        layout.separator(factor=0.4)

        # ── File Operations ──────────────────────────────────────────────
        rel = layout.box()
        rel.label(text="File Operations", icon="FILE_FOLDER")
        rel.prop(scene, "texmgr_directory", text="")
        r1 = rel.row(align=True); r1.scale_y = 1.1
        r1.operator("texmgr.sfs_texture_manager_relink", icon="UV_SYNC_SELECT")
        r1.operator("texmgr.sfs_texture_manager_collect",   icon="IMPORT")
        if scene.texmgr_filter == "PACKED":
            rel.operator("texmgr.sfs_texture_manager_unpack", icon="PACKAGE")
        layout.separator(factor=0.4)

        # ── Texture list ──────────────────────────────────────────────────
        if not bpy.data.images:
            box = layout.box()
            box.label(text="No images in this file.")
            box.operator("texmgr.sfs_texture_manager_refresh", text='Refresh', icon="FILE_REFRESH")
        else:
            layout.template_list("TEXMGR_UL_list", "texmgr_list",
                                 scene, "texmgr_list", scene, "texmgr_list_index", rows=10)

        layout.separator(factor=0.4)

        # ── Image data ────────────────────────────────────────────────────
        img_box = layout.box()
        img_box.label(text="Image Data", icon="IMAGE_DATA")
        r1 = img_box.row(align=True)
        r1.operator("texmgr.sfs_texture_manager_remap_duplicates",    text='Remap Duplicates',    icon="IMAGE_DATA")
        r1.operator("texmgr.sfs_texture_manager_delete_missing_and_unused", text='Delete Missing & Unused', icon="TRASH")

        layout.separator(factor=0.2)

        # ── Node graph ────────────────────────────────────────────────────
        ng = layout.box()
        ng.label(text="Node Graph", icon="NODETREE")
        row = ng.row(align=True)
        row.operator("node.sfs_texture_manager_clean_selected", text='Clean Selected', icon="NODE")
        row.operator("node.sfs_texture_manager_clean_all",      text='Clean All',      icon="SCENE_DATA")

        layout.separator(factor=0.2)



class TEXMGR_PT_texture_manager_texture_stats(Panel):
    bl_idname = 'TEXMGR_PT_texture_manager_texture_stats'
    bl_label = 'Stats'
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart File"
    bl_parent_id = 'TEXMGR_PT_texture_manager_texture_file_path_editor'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 0

    def draw_header(self, context):
        self.layout.label(text='')

    def draw(self, context):
        diagnostics = _diagnostics(context.scene)
        counts = dict(diagnostics.get("counts") or _empty_diagnostics()["counts"])
        total_mb = float(diagnostics.get("disk_size_mb", 0.0) or 0.0)
        col = self.layout.column(align=True)
        col.label(text=_ui_text(f"Total:      {counts['ALL']}", f"合計 {counts['ALL']}"))
        col.label(text=_ui_text(f"Connected:  {counts['CONNECTED']}", f"接続済み {counts['CONNECTED']}"))
        col.label(text=_ui_text(f"Missing:    {counts['MISSING']}", f"見つからない {counts['MISSING']}"))
        col.label(text=_ui_text(f"Packed:     {counts['PACKED']}", f"パック済み {counts['PACKED']}"))
        col.label(text=_ui_text(f"Unused:     {counts['UNUSED']}", f"未使用 {counts['UNUSED']}"))
        col.separator(factor=0.3)
        col.label(text=_ui_text(f"Disk size:  {total_mb:.1f} MB", f"ディスク容量 {total_mb:.1f} MB"))
        return None


# ══════════════════════════════════════════════════════════════════════════════
# REGISTRATION
# ══════════════════════════════════════════════════════════════════════════════

classes = (
    TexItem, TexMgrSettings, TEXMGR_UL_list,
    TEXMGR_OT_texture_manager_refresh, TEXMGR_OT_texture_manager_toggle_group, TEXMGR_OT_texture_manager_toggle_select,
    TEXMGR_OT_texture_manager_copy_path, TEXMGR_OT_texture_manager_select_by_status, TEXMGR_OT_texture_manager_deselect_all,
    TEXMGR_OT_texture_manager_rename_image, TEXMGR_OT_texture_manager_relink, TEXMGR_OT_texture_manager_collect,
    TEXMGR_OT_texture_manager_pack, TEXMGR_OT_texture_manager_unpack, TEXMGR_OT_texture_manager_delete_missing_and_unused,
    TEXMGR_OT_texture_manager_remap_duplicates, TEXMGR_OT_texture_manager_make_relative,
    TEXMGR_OT_texture_manager_make_absolute, TEXMGR_OT_texture_manager_change_directory,
    TEXMGR_OT_texture_manager_select_node, NODE_OT_texture_manager_clean_selected, NODE_OT_texture_manager_clean_all,
    TEXMGR_PT_texture_manager_texture_file_path_editor,
    TEXMGR_PT_texture_manager_texture_stats,
)



@bpy.app.handlers.persistent
def _on_load(filepath):
    try:
        scene = getattr(bpy.context, 'scene', None)
        settings = getattr(scene, 'texmgr_settings', None) if scene is not None else None
        if not bool(getattr(settings, 'auto_refresh_on_file_load', False)):
            return
        bpy.ops.texmgr.sfs_texture_manager_refresh()
    except Exception:
        pass



def _apply_suite_settings_after_pointer_registration(context=None) -> None:
    try:
        from .. import settings as _sfs_settings
        if hasattr(_sfs_settings, 'apply_all'):
            _sfs_settings.apply_all(context or getattr(bpy, 'context', None))
    except Exception:
        pass

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    sce = bpy.types.Scene
    sce.texmgr_list       = CollectionProperty(type=TexItem)
    sce.texmgr_list_index = IntProperty(default=-1)
    sce.texmgr_filter     = EnumProperty(name="Filter", items=FILTER_ITEMS, default="ALL")
    sce.texmgr_directory   = StringProperty(name="Directory", subtype="DIR_PATH")
    sce.texmgr_settings    = PointerProperty(type=TexMgrSettings)
    _apply_suite_settings_after_pointer_registration(getattr(bpy, 'context', None))
    _sync_texmgr_load_handler()


def unregister():
    if _on_load in _load_hooks.LOAD_POST_HOOKS:
        _load_hooks.LOAD_POST_HOOKS.remove(_on_load)
    for cls in reversed(classes):
        try: bpy.utils.unregister_class(cls)
        except Exception: pass
    sce = bpy.types.Scene
    for attr in ("texmgr_list","texmgr_list_index","texmgr_filter",
                 "texmgr_directory","texmgr_settings"):
        try: delattr(sce, attr)
        except Exception: pass
    _cache.clear()
    _diagnostics_cache.clear()


if __name__ == "__main__":
    register()
