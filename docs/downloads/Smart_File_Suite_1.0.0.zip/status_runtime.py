# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Bounded, event-driven Smart File status compatibility runtime.

This module intentionally owns no Blender timer, handler, draw handler, msgbus
subscription, worker, thread, or process-global API wrapper.  Callers may publish
short status records at explicit operation boundaries; stale records are pruned
only when the API is called again.  Resource registration is owned by each Smart
File subsystem's exact-identity ledger instead of being observed or patched here.
"""
from __future__ import annotations

from contextlib import contextmanager
import time
from typing import Any, Dict, Iterator, Optional

try:
    import bpy
except Exception:  # pragma: no cover - static tooling outside Blender.
    bpy = None  # type: ignore[assignment]

_NAMESPACE_KEY = "JELARARAGI_SMART_FILE_STATUS_EVENT_DRIVEN_V57540"
_STATE_VERSION = 1
_MAX_ENTRIES = 64
_DEFAULT_TRANSIENT_SECONDS = 1.8


def _new_state() -> Dict[str, Any]:
    return {
        "version": _STATE_VERSION,
        "sequence": 0,
        "entries": {},
        "last_text": None,
        "stats": {},
    }


def _state() -> Dict[str, Any]:
    if bpy is None:
        state = globals().get("_FALLBACK_STATE")
        if not isinstance(state, dict) or state.get("version") != _STATE_VERSION:
            state = _new_state()
            globals()["_FALLBACK_STATE"] = state
        return state
    try:
        namespace = bpy.app.driver_namespace
        state = namespace.get(_NAMESPACE_KEY)
        if not isinstance(state, dict) or state.get("version") != _STATE_VERSION:
            state = _new_state()
            namespace[_NAMESPACE_KEY] = state
        return state
    except Exception:
        state = globals().get("_FALLBACK_STATE")
        if not isinstance(state, dict) or state.get("version") != _STATE_VERSION:
            state = _new_state()
            globals()["_FALLBACK_STATE"] = state
        return state


def _now() -> float:
    return time.monotonic()


def _prune(state: Dict[str, Any], now: Optional[float] = None) -> None:
    now = _now() if now is None else float(now)
    entries = state.get("entries")
    if not isinstance(entries, dict):
        entries = {}
        state["entries"] = entries
    for key, value in tuple(entries.items()):
        expires_at = value.get("expires_at") if isinstance(value, dict) else None
        if expires_at is not None and float(expires_at) <= now:
            entries.pop(key, None)
    if len(entries) > _MAX_ENTRIES:
        ordered = sorted(
            entries.items(),
            key=lambda item: int((item[1] or {}).get("sequence", 0)),
        )
        for key, _value in ordered[: len(entries) - _MAX_ENTRIES]:
            entries.pop(key, None)


def _top(state: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    _prune(state)
    values = [value for value in state.get("entries", {}).values() if isinstance(value, dict)]
    if not values:
        return None
    return max(values, key=lambda value: (int(value.get("priority", 0)), int(value.get("sequence", 0))))


def _publish(context=None) -> None:
    """Publish synchronously to the current workspace only; never poll/retry."""
    state = _state()
    entry = _top(state)
    text = str(entry.get("text", "")) if entry else ""
    state["last_text"] = text or None
    if bpy is None:
        return
    try:
        workspace = getattr(context, "workspace", None) or getattr(bpy.context, "workspace", None)
        setter = getattr(workspace, "status_text_set", None)
        if callable(setter):
            setter(text if text else None)
    except Exception:
        pass


def _upsert(
    key: str,
    owner: str,
    text: str,
    *,
    priority: int,
    duration: Optional[float],
    kind: str,
    context=None,
) -> str:
    state = _state()
    _prune(state)
    state["sequence"] = int(state.get("sequence", 0)) + 1
    expires_at = None if duration is None else _now() + max(0.0, float(duration))
    state["entries"][str(key)] = {
        "key": str(key),
        "owner": str(owner or ""),
        "text": str(text or ""),
        "priority": int(priority),
        "kind": str(kind or ""),
        "sequence": state["sequence"],
        "expires_at": expires_at,
    }
    _prune(state)
    _publish(context)
    return str(key)


def set_transient(owner: str, text: str, duration: float = _DEFAULT_TRANSIENT_SECONDS, *, context=None) -> str:
    return _upsert(
        f"transient:{owner}", owner, text,
        priority=20, duration=duration, kind="transient", context=context,
    )


def set_service(owner: str, text: str, *, context=None) -> str:
    return _upsert(
        f"service:{owner}", owner, text,
        priority=10, duration=None, kind="service", context=context,
    )


def begin_task(owner: str, text: str, *, context=None) -> str:
    state = _state()
    state["sequence"] = int(state.get("sequence", 0)) + 1
    token = f"task:{owner}:{state['sequence']}"
    return _upsert(token, owner, text, priority=30, duration=None, kind="task", context=context)


def update_task(token: str, text: str, *, context=None) -> bool:
    state = _state()
    _prune(state)
    entry = state.get("entries", {}).get(str(token))
    if not isinstance(entry, dict):
        return False
    state["sequence"] = int(state.get("sequence", 0)) + 1
    entry["text"] = str(text or "")
    entry["sequence"] = state["sequence"]
    _publish(context)
    return True


def finish_task(
    token: str,
    final_text: Optional[str] = None,
    *,
    duration: float = _DEFAULT_TRANSIENT_SECONDS,
    context=None,
) -> bool:
    state = _state()
    entry = state.get("entries", {}).pop(str(token), None)
    if not isinstance(entry, dict):
        _publish(context)
        return False
    if final_text:
        set_transient(str(entry.get("owner", "")), final_text, duration=duration, context=context)
    else:
        _publish(context)
    return True


def clear(owner_or_token: str, *, context=None) -> None:
    state = _state()
    key = str(owner_or_token or "")
    entries = state.get("entries", {})
    entries.pop(key, None)
    for entry_key, value in tuple(entries.items()):
        if isinstance(value, dict) and str(value.get("owner", "")) == key:
            entries.pop(entry_key, None)
    _publish(context)


def clear_prefix(prefix: str, *, context=None) -> None:
    state = _state()
    prefix = str(prefix or "")
    for key, value in tuple(state.get("entries", {}).items()):
        owner = str((value or {}).get("owner", "")) if isinstance(value, dict) else ""
        if str(key).startswith(prefix) or owner.startswith(prefix):
            state["entries"].pop(key, None)
    _publish(context)


def clear_all(*, context=None) -> None:
    state = _state()
    state["entries"] = {}
    state["last_text"] = None
    _publish(context)


def snapshot() -> Dict[str, Any]:
    state = _state()
    _prune(state)
    top = _top(state)
    return {
        "version": _STATE_VERSION,
        "entry_count": len(state.get("entries", {})),
        "max_entries": _MAX_ENTRIES,
        "last_text": state.get("last_text"),
        "top": dict(top) if isinstance(top, dict) else None,
        "timer_registered": False,
        "handler_count": 0,
        "draw_handler_count": 0,
        "msgbus_count": 0,
        "worker_count": 0,
        "process_global_capture": False,
    }


@contextmanager
def task_scope(
    owner: str,
    text: str,
    *,
    context=None,
    final_text: Optional[str] = None,
    duration: float = _DEFAULT_TRANSIENT_SECONDS,
) -> Iterator[str]:
    token = begin_task(owner, text, context=context)
    try:
        yield token
    finally:
        finish_task(token, final_text=final_text, duration=duration, context=context)


def instrument_operator_class(cls, suite_id: str, suite_label: str):
    del suite_id, suite_label
    return cls


def instrument_loaded_package_operators(package_marker: str, suite_id: str, suite_label: str) -> int:
    del package_marker, suite_id, suite_label
    return 0


@contextmanager
def capture_runtime_resources(suite_id: str, suite_label: str):
    del suite_id, suite_label
    yield


@contextmanager
def capture_registration_callbacks(suite_id: str, suite_label: str):
    del suite_id, suite_label
    yield


def instrument_loaded_package_handlers(package_marker: str, suite_id: str, suite_label: str) -> int:
    del package_marker, suite_id, suite_label
    return 0


def restore_package_handlers(suite_id: str) -> int:
    del suite_id
    return 0



class _HandlerStatusProxy:
    """Legacy compatibility wrapper; never inserted into Blender handlers."""

    def __init__(self, callback, owner: str, handler_name: str, suite_label: str):
        del owner, handler_name, suite_label
        self._callback = callback
        self.__name__ = getattr(callback, "__name__", "handler")
        self.__qualname__ = getattr(callback, "__qualname__", self.__name__)
        self.__doc__ = getattr(callback, "__doc__", None)
        self.__module__ = getattr(callback, "__module__", __name__)

    def __call__(self, *args, **kwargs):
        return self._callback(*args, **kwargs)

    def __eq__(self, other):
        return other is self or other is self._callback

    def __hash__(self):
        return hash(self._callback)

    def __getattr__(self, name):
        return getattr(self._callback, name)

def prune_orphan_persistent_handler_markers(suite_id=None) -> int:
    del suite_id
    return 0


def restore_runtime_resources(suite_id: str) -> int:
    del suite_id
    return 0


def restore_registration_callbacks(suite_id: str) -> int:
    del suite_id
    return 0


def clear_runtime_resources(suite_id: str) -> int:
    del suite_id
    return 0


def clear_registration_callbacks(suite_id: str) -> int:
    del suite_id
    return 0


def runtime_status() -> Dict[str, Any]:
    return snapshot()
