# -----------------------------------------------------------------------------
#  Asset Reader (Phase 1): Library Browser + Index + Risk + Dependencies + Thumbs
# -----------------------------------------------------------------------------



# ----------------------------
#  Cache / Index helpers
# ----------------------------

from .ui_language_runtime import ui_text as _ui_text
_INDEX_SCHEMA = 1
_PREVIEW_COLLECTION = None
_PREVIEW_COLLECTION_KEY = 'smart_file_suite.asset_reader.thumbnail_preview_collection'
_PREVIEW_KEY_ORDER = []
_MAX_THUMB_PREVIEWS = 512
_MAX_THUMB_PRIME_INPUTS = 2048
_INDEX_CACHE_PATH = ''
_INDEX_CACHE_SIGNATURE = None
_INDEX_CACHE_DATA = None


def _addon_cache_dir() -> str:
    return _sf_user_default_dir('cache')


def _index_json_path() -> str:
    return os.path.join(_addon_cache_dir(), "library_index_v1.json")


def _thumbs_dir(prefs=None) -> str:
    # preference thumb_dir overrides cache
    if prefs and getattr(prefs, "thumb_dir", "").strip():
        d = _norm_path(getattr(prefs, "thumb_dir", ""))
        if d:
            os.makedirs(d, exist_ok=True)
            return d
    d = os.path.join(_addon_cache_dir(), "thumbs")
    os.makedirs(d, exist_ok=True)
    return d


def _safe_key(s: str) -> str:
    # file-safe key (but stable)
    out = []
    for ch in s:
        if ch.isalnum() or ch in "._-":
            out.append(ch)
        else:
            out.append("_")
    return "".join(out)[:140]


def _read_blend_version_int(filepath: str) -> int:
    # Returns 3-digit blend version from file header, e.g. 500 for 5.0.0
    try:
        with open(filepath, "rb") as f:
            head = f.read(12)
        if not head.startswith(b"BLENDER"):
            return 0
        digits = head[9:12]
        try:
            return int(digits.decode("ascii", "ignore"))
        except Exception:
            return 0
    except Exception:
        return 0


def _current_blender_version_int() -> int:
    v = getattr(bpy.app, "version", (0, 0, 0))
    try:
        return int(v[0]) * 100 + int(v[1]) * 10 + int(v[2])
    except Exception:
        return 0


def _empty_index() -> dict:
    return {"schema": _INDEX_SCHEMA, "generated": time.time(), "files": {}}


def _index_file_signature(path: str) -> tuple[int, int]:
    try:
        st = os.stat(path)
        return int(getattr(st, 'st_mtime_ns', int(st.st_mtime * 1000000000))), int(st.st_size)
    except Exception:
        return -1, -1


def _load_index() -> dict:
    global _INDEX_CACHE_PATH, _INDEX_CACHE_SIGNATURE, _INDEX_CACHE_DATA
    path = _index_json_path()
    signature = _index_file_signature(path)
    if (
        _INDEX_CACHE_PATH == path
        and _INDEX_CACHE_SIGNATURE == signature
        and isinstance(_INDEX_CACHE_DATA, dict)
    ):
        return _INDEX_CACHE_DATA
    if signature[0] < 0:
        data = _empty_index()
    else:
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("schema", 0) != _INDEX_SCHEMA:
                data = _empty_index()
            else:
                data.setdefault("files", {})
        except Exception:
            data = _empty_index()
    _INDEX_CACHE_PATH = path
    _INDEX_CACHE_SIGNATURE = signature
    _INDEX_CACHE_DATA = data
    return data

def _save_index(data: dict) -> None:
    global _INDEX_CACHE_PATH, _INDEX_CACHE_SIGNATURE, _INDEX_CACHE_DATA
    data["schema"] = _INDEX_SCHEMA
    data["generated"] = time.time()
    data.setdefault("files", {})
    path = _index_json_path()
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        _INDEX_CACHE_PATH = path
        _INDEX_CACHE_SIGNATURE = _index_file_signature(path)
        _INDEX_CACHE_DATA = data
    except Exception:
        # last resort: ignore
        pass

def _scan_blend_lists(filepath: str) -> dict:
    # Uses bpy.data.libraries.load to read datablock name lists (no import).
    lists = {
        "OBJECTS": [],
        "COLLECTIONS": [],
        "MATERIALS": [],
        "NODE_GROUPS": [],
        "ACTIONS": [],
        "WORLDS": [],
    }
    try:
        with bpy.data.libraries.load(filepath, link=True) as (data_from, _data_to):
            lists["OBJECTS"] = list(getattr(data_from, "objects", []) or [])
            lists["COLLECTIONS"] = list(getattr(data_from, "collections", []) or [])
            lists["MATERIALS"] = list(getattr(data_from, "materials", []) or [])
            lists["NODE_GROUPS"] = list(getattr(data_from, "node_groups", []) or [])
            lists["ACTIONS"] = list(getattr(data_from, "actions", []) or [])
            lists["WORLDS"] = list(getattr(data_from, "worlds", []) or [])
    except Exception:
        pass
    return lists


def _iter_blend_files_under(root_dir: str):
    root_dir = _norm_path(root_dir)
    if not root_dir or not os.path.isdir(root_dir):
        return
    for dirpath, dirnames, filenames in os.walk(root_dir):
        # skip hidden folders
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d.lower() not in {"__pycache__"}]
        for fn in filenames:
            if fn.lower().endswith(".blend"):
                yield os.path.join(dirpath, fn)


def _rebuild_index_for_roots(context, roots: list[str], full_rebuild: bool = False) -> int:
    idx = _load_index()
    files = idx.setdefault("files", {})
    current_v = _current_blender_version_int()

    scanned = 0
    for root in roots:
        for fp in _iter_blend_files_under(root):
            fp = _norm_path(fp)
            try:
                st = os.stat(fp)
                mtime = int(st.st_mtime)
                size = int(st.st_size)
            except Exception:
                continue

            rec = files.get(fp)
            if (not full_rebuild) and rec and int(rec.get("mtime", -1)) == mtime and int(rec.get("size", -1)) == size:
                scanned += 1
                continue

            blend_ver = _read_blend_version_int(fp)
            lists = _scan_blend_lists(fp)

            files[fp] = {
                "mtime": mtime,
                "size": size,
                "blend_version": int(blend_ver),
                "is_newer": bool(blend_ver and current_v and blend_ver > current_v),
                "lists": lists,
                "analysis": rec.get("analysis", {}) if rec else {},
                "thumbs": rec.get("thumbs", {}) if rec else {},
            }
            scanned += 1

    _save_index(idx)
    return scanned


_AR_TEMP_DATA = (
    "objects", "collections", "meshes", "materials", "images", "node_groups",
    "actions", "worlds", "libraries",
)


def _capture_data_snapshot():
    return {name: {item.as_pointer() for item in getattr(bpy.data, name)}
            for name in _AR_TEMP_DATA}


def _cleanup_new_data(snapshot):
    for name in _AR_TEMP_DATA:
        collection = getattr(bpy.data, name)
        for item in list(collection):
            if item.as_pointer() not in snapshot[name]:
                collection.remove(item, do_unlink=True)


# ----------------------------
#  Asset Reader data models
# ----------------------------

_AR_TYPE_ITEMS = [
    ('ALL', "All Types", ""),
    ('OBJECTS', "Objects", ""),
    ('COLLECTIONS', "Collections", ""),
    ('MATERIALS', "Materials", ""),
    ('NODE_GROUPS', "Node Groups", ""),
    ('ACTIONS', "Actions", ""),
    ('WORLDS', "Worlds", ""),
]


class SF_AR_Item(bpy.types.PropertyGroup):
    bl_description = 'Store one Asset Reader result row that points to a datablock inside a source .blend file for browsing and selective import'

    name: StringProperty(name='Name')
    data_type: EnumProperty(name='Type', items=[(i[0], i[1], i[2]) for i in _AR_TYPE_ITEMS if i[0] != 'ALL'])
    file_path: StringProperty(name='File', subtype='FILE_PATH')
    checked: BoolProperty(name='Select', default=False)

    # risk / analysis (file-level)
    is_newer: BoolProperty(name='Newer', default=False)
    missing_textures: IntProperty(name='Missing', default=0, min=0)
    abs_texture_paths: IntProperty(name='Abs Paths', default=0, min=0)

    thumb_path: StringProperty(name='Thumb', subtype='FILE_PATH')



# ----------------------------
#  Asset Reader Catalog models (Phase 3.2)
# ----------------------------

class SF_AR_CatalogAsset(bpy.types.PropertyGroup):
    bl_description = 'Store one merged catalog asset entry so you can compare versions, tags, previews, and source roots before importing'

    asset: StringProperty(name='Asset')
    asset_id: StringProperty(name='Asset ID', default="", options={'HIDDEN'})
    group_key: StringProperty(name='Group Key', default="", options={'HIDDEN'})
    category: StringProperty(name='Category')
    tags: StringProperty(name='Tags')
    latest_version: IntProperty(name='Latest', default=0, min=0)
    latest_blend: StringProperty(name='Blend', subtype='FILE_PATH')
    latest_preview: StringProperty(name='Preview', subtype='FILE_PATH')
    catalog_path: StringProperty(name='Catalog', subtype='FILE_PATH')
    conflict: BoolProperty(name='Conflict', default=False, options={'HIDDEN'})
    candidates_json: StringProperty(name='Candidates JSON', default="[]", options={'HIDDEN'})
    preferred_catalog: StringProperty(name='Preferred Catalog', default="", options={'HIDDEN'})
    # JSON serialized list of entries
    entries_json: StringProperty(name='Entries JSON', default="", options={'HIDDEN'})


class SF_AR_CatalogVersion(bpy.types.PropertyGroup):
    bl_description = 'Store one published version row for the active catalog asset so you can choose the right source blend and preview'

    version: IntProperty(name='Version', default=0, min=0)
    version_str: StringProperty(name='Version Str')
    blend: StringProperty(name='Blend', subtype='FILE_PATH')
    preview: StringProperty(name='Preview', subtype='FILE_PATH')
    published_at: StringProperty(name='Published')


class SF_UL_asset_library_asset_library_catalog_asset_list(bpy.types.UIList):
    bl_label = 'Asset Library Catalog Asset List'
    bl_description = 'Show catalog-aware asset rows so you can compare names, categories, tags, and source files before importing or publishing'
    bl_idname = 'SF_UL_asset_library_asset_library_catalog_asset_list'

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        it = item
        row = layout.row(align=True)
        icon_id = 0
        if getattr(it, "latest_preview", ""):
            icon_id = _get_thumb_icon_id(getattr(it, "latest_preview", ""))
        if icon_id:
            row.label(text='', icon_value=icon_id)
        else:
            row.label(text='', icon='ASSET_MANAGER')
        row.label(text=_sf_short_label_display(it.asset, 42))
        if getattr(it, 'conflict', False):
            row.label(text='', icon='ERROR')
        sub = row.row(align=True)
        sub.alignment = 'RIGHT'
        sub.scale_x = 0.8
        sub.label(text=(f"{_t('Latest')} v{it.latest_version:03d}" if it.latest_version else _t('Latest')))


class SF_UL_asset_library_asset_library_catalog_version_list(bpy.types.UIList):
    bl_label = 'Asset Library Catalog Version List'
    bl_description = 'Show available versions for the active catalog asset so you can compare recency, source file, and preview information before choosing one'
    bl_idname = 'SF_UL_asset_library_asset_library_catalog_version_list'

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        it = item
        row = layout.row(align=True)
        icon_id = 0
        if getattr(it, "preview", ""):
            icon_id = _get_thumb_icon_id(getattr(it, "preview", ""))
        if icon_id:
            row.label(text='', icon_value=icon_id)
        else:
            row.label(text='', icon='FILE_IMAGE')
        row.label(text=it.version_str or f"v{it.version:03d}")
        sub = row.row(align=True)
        sub.alignment = 'RIGHT'
        sub.scale_x = 0.9
        published = (it.published_at or "")[:16]
        sub.label(text=(f"{_t('Published')}: {published}" if published else _t('Published')))

def _ar_root_enum_id(path: str) -> str:
    p = _norm_path(path)
    if not p:
        return "ALL"
    return f"ROOT_{uuid.uuid5(uuid.NAMESPACE_URL, p).hex[:12].upper()}"


def _ar_root_path_from_value(context, value: str) -> str:
    value = str(value or "ALL")
    if not value or value == "ALL":
        return "ALL"
    prefs = _addon_prefs(context)
    for r in getattr(prefs, "library_roots", []) or []:
        p = _norm_path(getattr(r, "path", ""))
        if not p or not getattr(r, "enabled", True):
            continue
        if value == p or value == _ar_root_enum_id(p):
            return p
    return "ALL"


def _ar_root_items(_self, context):
    prefs = _addon_prefs(context)
    items = [('ALL', _t('All Roots'), "")]
    if prefs:
        seen = set()
        for r in getattr(prefs, "library_roots", []) or []:
            p = _norm_path(getattr(r, "path", ""))
            if not p or not getattr(r, "enabled", True) or p in seen:
                continue
            seen.add(p)
            items.append((_ar_root_enum_id(p), os.path.basename(p) or p, p))
    return _sf_stable_enum_items(items if items else [('ALL', "All Roots", "")])


class SF_UL_asset_library_asset_library_item_list(bpy.types.UIList):
    bl_label = 'Asset Library Item List'
    bl_description = 'Show indexed library items so you can scan raw search results, inspect file paths, and choose which entries to analyze or import next'
    bl_idname = 'SF_UL_asset_library_asset_library_item_list'

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        it = item
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)

            # thumb icon
            icon_id = 0
            if getattr(it, "thumb_path", ""):
                icon_id = _get_thumb_icon_id(getattr(it, "thumb_path", ""))
            if icon_id:
                row.label(text='', icon_value=icon_id)
            else:
                row.label(text='', icon='FILE_BLEND')

            row.prop(it, "checked", text='')
            col = row.column(align=True)
            col.label(text=_sf_short_label_display(it.name, 42), translate=False)
            sub = row.row(align=True)
            sub.alignment = 'RIGHT'
            sub.scale_x = 0.7
            sub.label(text=f"{_t('Type')}: {it.data_type}")

            # risk flag
            if getattr(it, "is_newer", False):
                row.label(text='', icon='ERROR')
        else:
            layout.label(text=it.name, translate=False)


def _thumb_preview_collection():
    global _PREVIEW_COLLECTION
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if _PREVIEW_COLLECTION is None and ns is not None:
            _PREVIEW_COLLECTION = ns.get(_PREVIEW_COLLECTION_KEY)
        if _PREVIEW_COLLECTION is None:
            import bpy.utils.previews as _sfs_previews
            _PREVIEW_COLLECTION = _sfs_previews.new()
            if ns is not None:
                ns[_PREVIEW_COLLECTION_KEY] = _PREVIEW_COLLECTION
            try:
                from . import preview_cleanup as _sf_preview_cleanup
                _sf_preview_cleanup.register_atexit()
            except Exception:
                pass
        return _PREVIEW_COLLECTION
    except Exception:
        return None



def _get_thumb_icon_id(path: str) -> int:
    """Read the bounded thumbnail cache; no stat/load work is allowed in draw."""
    key = str(path or '')
    if not key:
        return 0
    pcoll = _PREVIEW_COLLECTION
    if pcoll is None:
        try:
            ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
            pcoll = ns.get(_PREVIEW_COLLECTION_KEY) if ns is not None else None
        except Exception:
            pcoll = None
    if pcoll is None:
        return 0
    try:
        item = pcoll.get(key)
        if item is None:
            item = pcoll.get(_norm_path(key))
        return int(getattr(item, 'icon_id', 0) or 0)
    except Exception:
        return 0


def _prime_thumb_preview(path: str) -> int:
    """Load one thumbnail only from an explicit refresh/command boundary."""
    global _PREVIEW_KEY_ORDER
    key = _norm_path(path)
    if not key or not os.path.isfile(key):
        return 0
    pcoll = _thumb_preview_collection()
    if pcoll is None:
        return 0
    try:
        item = pcoll.get(key)
    except Exception:
        item = None
    if item is not None:
        try:
            _PREVIEW_KEY_ORDER.remove(key)
        except ValueError:
            pass
        _PREVIEW_KEY_ORDER.append(key)
        return int(getattr(item, 'icon_id', 0) or 0)
    while len(_PREVIEW_KEY_ORDER) >= _MAX_THUMB_PREVIEWS:
        old_key = _PREVIEW_KEY_ORDER.pop(0)
        try:
            del pcoll[old_key]
        except Exception:
            # If Blender refuses item eviction, retain the existing bounded set
            # and decline the new file rather than growing without limit.
            _PREVIEW_KEY_ORDER.insert(0, old_key)
            return 0
    try:
        pcoll.load(key, key, 'IMAGE')
        _PREVIEW_KEY_ORDER.append(key)
        return int(getattr(pcoll[key], 'icon_id', 0) or 0)
    except Exception:
        return 0


def _prime_thumb_previews(paths) -> int:
    count = 0
    seen = set()
    for index, raw in enumerate(paths or ()):
        if index >= _MAX_THUMB_PRIME_INPUTS:
            break
        key = _norm_path(raw)
        if not key or key in seen:
            continue
        seen.add(key)
        if _prime_thumb_preview(key):
            count += 1
    return count


def _ar_refresh_items(context):
    wm = context.window_manager
    prefs = _addon_prefs(context)
    idx = _load_index()
    files = idx.get("files", {})

    root_filter = _ar_root_path_from_value(context, getattr(wm, "sf_ar_root_filter", "ALL") or "ALL")
    type_filter = getattr(wm, "sf_ar_type_filter", "ALL") or "ALL"
    q = (getattr(wm, "sf_ar_search", "") or "").strip().lower()
    sort = getattr(wm, "sf_ar_sort", "NAME_ASC") or "NAME_ASC"

    wm.sf_ar_items.clear()

    # Gather
    rows = []
    for fp, rec in files.items():
        fp_norm = _norm_path(fp)
        if root_filter != "ALL":
            # must be under root
            try:
                if not fp_norm.startswith(_norm_path(root_filter) + os.sep) and fp_norm != _norm_path(root_filter):
                    continue
            except Exception:
                pass

        lists = rec.get("lists", {}) or {}
        analysis = rec.get("analysis", {}) or {}
        thumbs = rec.get("thumbs", {}) or {}
        is_newer = bool(rec.get("is_newer", False))

        missing = int(analysis.get("missing_textures", 0) or 0)
        abs_paths = int(analysis.get("abs_texture_paths", 0) or 0)

        for dt in ['OBJECTS', 'COLLECTIONS', 'MATERIALS', 'NODE_GROUPS', 'ACTIONS', 'WORLDS']:
            if type_filter != 'ALL' and dt != type_filter:
                continue
            for name in lists.get(dt, []) or []:
                if q and (q not in name.lower()) and (q not in os.path.basename(fp_norm).lower()):
                    continue
                thumb_key = f"{dt}:{name}"
                rows.append((name, dt, fp_norm, is_newer, missing, abs_paths, thumbs.get(thumb_key, "")))

    # Sort
    if sort == "NAME_DESC":
        rows.sort(key=lambda r: (r[0].lower(), r[2].lower()), reverse=True)
    elif sort == "FILE_ASC":
        rows.sort(key=lambda r: (os.path.basename(r[2]).lower(), r[0].lower()))
    elif sort == "FILE_DESC":
        rows.sort(key=lambda r: (os.path.basename(r[2]).lower(), r[0].lower()), reverse=True)
    else:
        rows.sort(key=lambda r: (r[0].lower(), r[2].lower()))

    for name, dt, fp, is_newer, missing, abs_paths, thumb in rows:
        it = wm.sf_ar_items.add()
        it.name = name
        it.data_type = dt
        it.file_path = fp
        it.is_newer = is_newer
        it.missing_textures = missing
        it.abs_texture_paths = abs_paths
        it.thumb_path = thumb

    _prime_thumb_previews(row[6] for row in rows if len(row) > 6 and row[6])

    if len(wm.sf_ar_items) == 0:
        wm.sf_ar_active_index = 0
    else:
        wm.sf_ar_active_index = min(max(int(getattr(wm, "sf_ar_active_index", 0) or 0), 0), len(wm.sf_ar_items)-1)


# ----------------------------
#  Dependency Analysis
# ----------------------------

def _dep_add(setmap: dict, key: str, value: str):
    if not value:
        return
    setmap.setdefault(key, set()).add(value)


def _analyze_deps_for_item(filepath: str, data_type: str, name: str):
    'Load a single datablock (linked) and collect dependencies.\n    Returns: (deps_map, tree_lines)\n    deps_map keys: OBJECTS, COLLECTIONS, MATERIALS, IMAGES, NODE_GROUPS, ACTIONS, WORLDS, MESHES'
    deps = {}
    tree = []
    fp = _norm_path(filepath)

    snapshot = _capture_data_snapshot()

    try:
        collection = data_type.lower()
        if collection not in {"objects", "collections", "materials", "node_groups", "actions", "worlds"}:
            return deps, tree
        with bpy.data.libraries.load(fp, link=True) as (available, loaded):
            if name not in getattr(available, collection, ()):
                return deps, tree
            setattr(loaded, collection, [name])
        root = getattr(loaded, collection)[0]
        if root is None:
            return deps, tree

        visited = set()

        def _visit_id(id_, indent=0, label=None):
            if id_ is None:
                return
            try:
                uid = id_.as_pointer()
            except Exception:
                return
            if uid in visited:
                return
            visited.add(uid)

            tname = id_.__class__.__name__
            nm = getattr(id_, "name", "")
            prefix = '' * indent
            if label:
                tree.append(f"{prefix}{label}: {nm}")
            else:
                tree.append(f"{prefix}{tname}: {nm}")

            # categorize
            if isinstance(id_, bpy.types.Object):
                _dep_add(deps, "OBJECTS", nm)
                # parent
                if id_.parent:
                    _visit_id(id_.parent, indent+1, "Parent")
                # constraints targets
                for con in getattr(id_, "constraints", []) or []:
                    tgt = getattr(con, "target", None)
                    if tgt:
                        _visit_id(tgt, indent+1, "ConstraintTarget")
                # modifiers common object refs
                for mod in getattr(id_, "modifiers", []) or []:
                    for attr in ("object", "target", "mirror_object", "offset_object", "start_cap", "end_cap"):
                        try:
                            ref = getattr(mod, attr, None)
                        except Exception:
                            ref = None
                        if isinstance(ref, bpy.types.Object):
                            _visit_id(ref, indent+1, f"Modifier:{mod.type}")
                # data
                data = getattr(id_, "data", None)
                if data:
                    _visit_id(data, indent+1, "Data")
                # materials
                for slot in getattr(id_, "material_slots", []) or []:
                    mat = getattr(slot, "material", None)
                    if mat:
                        _visit_id(mat, indent+1, "Material")
                # action
                ad = getattr(id_, "animation_data", None)
                if ad and getattr(ad, "action", None):
                    _visit_id(ad.action, indent+1, "Action")
                # drivers targets (best-effort)
                if ad:
                    for drv in getattr(ad, "drivers", []) or []:
                        try:
                            for var in drv.driver.variables:
                                for tgt in var.targets:
                                    tid = getattr(tgt, "id", None)
                                    if tid:
                                        _visit_id(tid, indent+1, "DriverTarget")
                        except Exception:
                            pass

            elif isinstance(id_, bpy.types.Collection):
                _dep_add(deps, "COLLECTIONS", nm)
                # children collections + objects
                for ch in getattr(id_, "children", []) or []:
                    _visit_id(ch, indent+1, "ChildCollection")
                for ob in getattr(id_, "objects", []) or []:
                    _visit_id(ob, indent+1, "Object")

            elif isinstance(id_, bpy.types.Mesh):
                _dep_add(deps, "MESHES", nm)
                # materials on mesh (fallback)
                for mat in getattr(id_, "materials", []) or []:
                    if mat:
                        _visit_id(mat, indent+1, "Material")

            elif isinstance(id_, bpy.types.Material):
                _dep_add(deps, "MATERIALS", nm)
                nt = getattr(id_, "node_tree", None)
                if nt:
                    _visit_id(nt, indent+1, "NodeTree")

            elif isinstance(id_, bpy.types.NodeTree):
                _dep_add(deps, "NODE_GROUPS", nm)
                # nodes
                for node in getattr(id_, "nodes", []) or []:
                    try:
                        if getattr(node, "type", "") == 'GROUP' and getattr(node, "node_tree", None):
                            _visit_id(node.node_tree, indent+1, "Group")
                        if getattr(node, "type", "") == 'TEX_IMAGE' and getattr(node, "image", None):
                            _visit_id(node.image, indent+1, "Image")
                    except Exception:
                        pass

            elif isinstance(id_, bpy.types.Image):
                _dep_add(deps, "IMAGES", nm)
                fp_img = getattr(id_, "filepath", "") or ""
                if fp_img:
                    tree.append(f"{''*(indent+1)}Path: {fp_img}")

            elif isinstance(id_, bpy.types.Action):
                _dep_add(deps, "ACTIONS", nm)

            elif isinstance(id_, bpy.types.World):
                _dep_add(deps, "WORLDS", nm)
                nt = getattr(id_, "node_tree", None)
                if nt:
                    _visit_id(nt, indent+1, "NodeTree")

            else:
                # other ID types not tracked
                pass

        _visit_id(root, 0, data_type[:-1].title())

    finally:
        # Cleanup any temporary linked IDs
        _cleanup_new_data(snapshot)

    return deps, tree


def _summarize_deps_against_current(deps: dict) -> str:
    # Compute new vs existing by name
    lines = []
    def _count(coll, names):
        ex = 0
        nw = 0
        for n in names:
            if coll.get(n) is None:
                nw += 1
            else:
                ex += 1
        return nw, ex

    order = [
        ("OBJECTS", bpy.data.objects),
        ("COLLECTIONS", bpy.data.collections),
        ("MESHES", bpy.data.meshes),
        ("MATERIALS", bpy.data.materials),
        ("NODE_GROUPS", bpy.data.node_groups),
        ("IMAGES", bpy.data.images),
        ("ACTIONS", bpy.data.actions),
        ("WORLDS", bpy.data.worlds),
    ]
    for key, coll in order:
        if key not in deps:
            continue
        names = sorted(deps[key])
        nw, ex = _count(coll, names)
        lines.append(_ui_text(f"{key}: total {len(names)} (new {nw} / existing {ex})", f'{key}：全部 {len(names)}（新規 {nw}／既存 {ex}）'))
    return '\n'.join(lines)


def _sf_get_text_block(name: str):
    txt = bpy.data.texts.get(name)
    if txt is None:
        txt = bpy.data.texts.new(name)
    else:
        try:
            txt.clear()
        except Exception:
            try:
                bpy.data.texts.remove(txt)
            except Exception:
                pass
            txt = bpy.data.texts.new(name)
    return txt


def _sf_write_report_text(name: str, content: str) -> str:
    txt = _sf_get_text_block(name)
    try:
        txt.write(content or "")
    except Exception:
        pass
    return getattr(txt, 'name', name)


def _sf_open_text_in_any_editor(context, text_name: str) -> bool:
    if not text_name:
        return False
    try:
        txt = bpy.data.texts.get(text_name)
    except Exception:
        txt = None
    if txt is None:
        return False
    try:
        for window in context.window_manager.windows:
            screen = window.screen
            if not screen:
                continue
            for area in screen.areas:
                if area.type != 'TEXT_EDITOR':
                    continue
                space = area.spaces.active
                if space and getattr(space, 'type', '') == 'TEXT_EDITOR':
                    space.text = txt
                    return True
    except Exception:
        return False
    return False


def _sf_repair_library_roots(context,
                             normalize_paths: bool = True,
                             remove_empty: bool = True,
                             merge_duplicates: bool = True,
                             disable_missing: bool = True,
                             sort_by_priority: bool = True,
                             rebuild_index: bool = True) -> dict:
    prefs = _addon_prefs(context)
    if not prefs:
        return {
            'summary': 'No Smart File N-panel settings available',
            'report_name': '',
            'changed': False,
            'change_count': 0,
            'normalized_count': 0,
            'removed_empty_count': 0,
            'merged_duplicate_count': 0,
            'disabled_missing_count': 0,
            'rebuild_scanned': 0,
        }

    before = []
    for idx, r in enumerate(list(getattr(prefs, 'library_roots', []) or [])):
        raw = getattr(r, 'path', '') or ''
        norm = _norm_path(raw) if raw else ''
        before.append({
            'index': idx,
            'raw': raw,
            'path': norm if normalize_paths else raw,
            'enabled': bool(getattr(r, 'enabled', True)),
            'priority': int(getattr(r, 'priority', 0) or 0),
        })

    normalized_count = 0
    removed_empty_count = 0
    merged_duplicate_count = 0
    disabled_missing_count = 0
    order_changed = False
    actions = []
    work = []

    for row in before:
        raw = row['raw']
        path = row['path']
        if normalize_paths and raw and path and raw != path:
            normalized_count += 1
            actions.append(_ui_text(f"Normalized path: {raw} -> {path}", f'パスを正規化しました：{raw} -> {path}'))
        if not (path or '').strip():
            if remove_empty:
                removed_empty_count += 1
                actions.append(_ui_text(f"Removed empty root entry (index {row['index']})", f"空のルートの項目を取り除きました（番号 {row['index']}）"))
                continue
        work.append({
            'path': path,
            'enabled': bool(row['enabled']),
            'priority': int(row['priority']),
        })

    if merge_duplicates:
        merged = []
        seen = {}
        for row in work:
            p = row['path']
            if p and p in seen:
                keep = seen[p]
                merged_duplicate_count += 1
                if row['enabled'] and not keep['enabled']:
                    keep['enabled'] = True
                    actions.append(_ui_text(f"Merged duplicate root and kept enabled state: {p}", f'重複したルートを結合し、有効の状態を保ちました：{p}'))
                else:
                    actions.append(_ui_text(f"Merged duplicate root: {p}", f'重複したルートを結合しました：{p}'))
                if int(row['priority']) > int(keep['priority']):
                    keep['priority'] = int(row['priority'])
                    actions.append(_ui_text(f"Updated merged root priority to {keep['priority']}: {p}", f"結合したルートの優先度を {keep['priority']} にしました：{p}"))
                continue
            seen[p] = row
            merged.append(row)
        work = merged

    for row in work:
        p = row['path']
        if p and row['enabled'] and (not os.path.isdir(p)) and disable_missing:
            row['enabled'] = False
            disabled_missing_count += 1
            actions.append(_ui_text(f"Disabled missing root: {p}", f'見つからないルートを無効にしました：{p}'))

    before_sort = [(row['path'], bool(row['enabled']), int(row['priority'])) for row in work]
    if sort_by_priority:
        work.sort(key=lambda r: (0 if r['enabled'] else 1, -int(r['priority']), (r['path'] or '').lower()))
        after_sort = [(row['path'], bool(row['enabled']), int(row['priority'])) for row in work]
        order_changed = before_sort != after_sort
        if order_changed:
            actions.append(_ui_text("Sorted roots by enabled state, priority, and path", 'ルートを有効の状態・優先度・パスで並べ替えました'))

    final_rows = [{
        'path': row['path'],
        'enabled': bool(row['enabled']),
        'priority': int(row['priority']),
        'exists': bool(row['path'] and os.path.isdir(row['path'])),
    } for row in work]

    before_rows = [(r['raw'], bool(r['enabled']), int(r['priority'])) for r in before]
    after_rows = [(r['path'], bool(r['enabled']), int(r['priority'])) for r in final_rows]
    changed = before_rows != after_rows

    if changed:
        try:
            while len(prefs.library_roots):
                prefs.library_roots.remove(len(prefs.library_roots) - 1)
            for row in final_rows:
                it = prefs.library_roots.add()
                it.path = row['path'] or ''
                it.enabled = bool(row['enabled'])
                it.priority = int(row['priority'])
        except Exception as ex:
            actions.append(_ui_text(f"Failed to write repaired roots back to preferences: {ex}", f'直したルートを設定へ書き戻せませんでした：{ex}'))
            changed = False

    rebuild_scanned = 0
    if rebuild_index:
        roots = []
        for row in final_rows:
            if row['enabled'] and row['exists'] and row['path']:
                roots.append(row['path'])
        if roots:
            try:
                rebuild_scanned = int(_rebuild_index_for_roots(context, roots, full_rebuild=False) or 0)
                actions.append(_ui_text(f"Rebuilt library index entries: {rebuild_scanned}", f'ライブラリのインデックスを作り直しました：{rebuild_scanned} 件'))
            except Exception as ex:
                actions.append(_ui_text(f"Index rebuild failed: {ex}", f'インデックスの作り直しに失敗しました：{ex}'))

    change_count = int(normalized_count + removed_empty_count + merged_duplicate_count + disabled_missing_count + (1 if order_changed else 0))

    report_lines = [
        f"Repair Library Roots | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        '',
        'OPTIONS',
        f"- normalize_paths={bool(normalize_paths)}",
        f"- remove_empty={bool(remove_empty)}",
        f"- merge_duplicates={bool(merge_duplicates)}",
        f"- disable_missing={bool(disable_missing)}",
        f"- sort_by_priority={bool(sort_by_priority)}",
        f"- rebuild_index={bool(rebuild_index)}",
        '',
        'SUMMARY',
        f"- normalized_paths: {normalized_count}",
        f"- removed_empty_roots: {removed_empty_count}",
        f"- merged_duplicate_roots: {merged_duplicate_count}",
        f"- disabled_missing_roots: {disabled_missing_count}",
        f"- order_changed: {bool(order_changed)}",
        f"- changed: {bool(changed)}",
        f"- rebuild_scanned: {rebuild_scanned}",
        '',
        'BEFORE',
    ]
    if before:
        for row in before:
            flags = []
            flags.append('ENABLED' if row['enabled'] else 'DISABLED')
            flags.append('OK' if (row['path'] and os.path.isdir(row['path'])) else 'MISSING')
            report_lines.append(f"- [{','.join(flags)}] priority={row['priority']} | {row['raw'] or '<empty>'}")
    else:
        report_lines.append(_ui_text('- No library roots configured', '- ライブラリのルートがありません'))

    report_lines.extend(['', 'AFTER'])
    if final_rows:
        for row in final_rows:
            flags = []
            flags.append('ENABLED' if row['enabled'] else 'DISABLED')
            flags.append('OK' if row['exists'] else 'MISSING')
            report_lines.append(f"- [{','.join(flags)}] priority={row['priority']} | {row['path'] or '<empty>'}")
    else:
        report_lines.append(_ui_text('- No library roots configured', '- ライブラリのルートがありません'))

    report_lines.extend(['', 'ACTIONS'])
    if actions:
        for line in actions:
            report_lines.append(f"- {line}")
    else:
        report_lines.append(_ui_text('- No changes required', '- 変更は要りません'))

    report_name = _sf_write_report_text('smart_file_suite_Library_Repair_Report.txt', '\n'.join(report_lines) + '\n')

    summary_lines = [
        _t('Repair Library Roots'),
        _ui_text(f"Roots: before {len(before)} -> after {len(final_rows)}", f'ルート：{len(before)} 個から {len(final_rows)} 個へ'),
        _ui_text(f"Normalized: {normalized_count} | Empty removed: {removed_empty_count}", f'正規化：{normalized_count}｜空の項目の削除：{removed_empty_count}'),
        _ui_text(f"Duplicates merged: {merged_duplicate_count} | Missing disabled: {disabled_missing_count}", f'重複の結合：{merged_duplicate_count}｜見つからない物の無効化：{disabled_missing_count}'),
        _ui_text(f"Order changed: {bool(order_changed)} | Index scanned: {rebuild_scanned}", f'順序の変更：{"あり" if order_changed else "なし"}｜インデックスの走査：{rebuild_scanned}'),
        f"{_t('Report Text')}: {report_name}",
    ]
    if not change_count:
        summary_lines.append(_t('No changes required'))
    else:
        summary_lines.append(f"{_t('Changes applied')}: {change_count}")

    return {
        'summary': '\n'.join(summary_lines),
        'report_name': report_name,
        'changed': bool(change_count or changed),
        'change_count': change_count,
        'normalized_count': normalized_count,
        'removed_empty_count': removed_empty_count,
        'merged_duplicate_count': merged_duplicate_count,
        'disabled_missing_count': disabled_missing_count,
        'rebuild_scanned': rebuild_scanned,
    }


def _sf_run_library_diagnostics(context, include_disabled: bool = False, list_limit: int = 40) -> dict:
    prefs = _addon_prefs(context)
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    current_v = _current_blender_version_int()
    current_v_str = '.'.join(str(v) for v in getattr(bpy.app, 'version', (0, 0, 0)))
    catalog_filename = getattr(prefs, 'pub_catalog_filename', 'catalog.json') if prefs else 'catalog.json'

    root_rows = []
    seen_root_paths = {}
    issues = []
    notices = []
    all_blends = set()
    referenced_blends = set()
    catalog_files = []
    asset_id_map = {}
    asset_name_map = {}
    blend_ref_map = {}

    def add_issue(severity: str, code: str, message: str, path: str = ''):
        issues.append({'severity': severity, 'code': code, 'message': message, 'path': path or ''})

    def add_notice(code: str, message: str, path: str = ''):
        notices.append({'code': code, 'message': message, 'path': path or ''})

    roots_src = list(getattr(prefs, 'library_roots', []) or []) if prefs else []
    enabled_count = 0
    existing_count = 0
    duplicate_roots = 0
    missing_roots = 0

    for idx, r in enumerate(roots_src):
        raw = getattr(r, 'path', '') or ''
        path = _norm_path(raw) if raw else ''
        enabled = bool(getattr(r, 'enabled', True))
        priority = int(getattr(r, 'priority', 0) or 0)
        exists = bool(path and os.path.isdir(path))
        if enabled:
            enabled_count += 1
        if exists:
            existing_count += 1
        row = {'index': idx, 'path': path, 'enabled': enabled, 'priority': priority, 'exists': exists, 'duplicate': False}
        root_rows.append(row)
        if not path:
            add_issue('ERROR', 'EMPTY_ROOT', 'Library root path is empty', f'root[{idx}]')
            missing_roots += 1
            continue
        if path in seen_root_paths:
            duplicate_roots += 1
            row['duplicate'] = True
            add_issue('WARNING', 'DUPLICATE_ROOT', _ui_text(f'Duplicate library root entry: {path}', f'ライブラリのルートの項目が重複しています：{path}'), path)
        else:
            seen_root_paths[path] = idx
        if enabled and not exists:
            missing_roots += 1
            add_issue('ERROR', 'MISSING_ROOT', _ui_text(f'Enabled library root does not exist: {path}', f'有効なライブラリのルートがありません：{path}'), path)

    scan_roots = []
    for row in root_rows:
        if not row['path'] or not row['exists']:
            continue
        if (not include_disabled) and (not row['enabled']):
            continue
        scan_roots.append(row)

    blend_count = 0
    newer_blend_count = 0
    orphan_blends = []
    catalog_asset_groups = 0
    catalog_entry_count = 0
    missing_blend_refs = 0
    missing_preview_refs = 0
    missing_meta_refs = 0
    invalid_catalogs = 0

    for row in scan_roots:
        root = row['path']
        for fp in _iter_blend_files_under(root):
            fp = _norm_path(fp)
            if not fp:
                continue
            all_blends.add(fp)
            blend_count += 1
            try:
                bv = _read_blend_version_int(fp)
            except Exception:
                bv = 0
            if bv and current_v and bv > current_v:
                newer_blend_count += 1
                add_issue('WARNING', 'NEWER_BLEND_VERSION', _ui_text(f'Blend file is newer than current Blender ({bv} > {current_v}): {fp}', f'Blend ファイルが今の Blender より新しい版です（{bv} > {current_v}）：{fp}'), fp)

        cats = _ar_find_catalog_files(root, catalog_filename, max_depth=6, limit=1000)
        for cat_fp in cats:
            cat_fp = _norm_path(cat_fp)
            catalog_files.append(cat_fp)
            cat = _ar_load_catalog(cat_fp)
            assets = (cat.get('assets') or {}) if isinstance(cat, dict) else {}
            if not isinstance(cat, dict) or not isinstance(assets, dict):
                invalid_catalogs += 1
                add_issue('ERROR', 'INVALID_CATALOG', _ui_text(f'Catalog is invalid or unreadable: {cat_fp}', f'カタログが無効か読めません：{cat_fp}'), cat_fp)
                continue
            base_dir = os.path.dirname(cat_fp)
            for asset_key, data in assets.items():
                catalog_asset_groups += 1
                if not isinstance(data, dict):
                    add_issue('WARNING', 'INVALID_ASSET_GROUP', _ui_text(f'Catalog asset entry is not a dict: {cat_fp} :: {asset_key}', f'カタログのアセットの項目の形が違います：{cat_fp} :: {asset_key}'), cat_fp)
                    continue
                asset_name = str(asset_key)
                asset_id = str(data.get('asset_id') or '').strip()
                entries = list(data.get('entries', []) or [])
                asset_name_map.setdefault(asset_name, set())
                if asset_id:
                    asset_name_map[asset_name].add(asset_id)
                    info = asset_id_map.setdefault(asset_id, {'names': set(), 'catalogs': set(), 'paths': set()})
                    info['names'].add(asset_name)
                    info['catalogs'].add(cat_fp)
                for e in entries:
                    catalog_entry_count += 1
                    if not isinstance(e, dict):
                        add_issue('WARNING', 'INVALID_CATALOG_ENTRY', _ui_text(f'Catalog entry is not a dict: {cat_fp} :: {asset_name}', f'カタログの項目の形が違います：{cat_fp} :: {asset_name}'), cat_fp)
                        continue
                    blend_rel = str(e.get('blend') or '').strip()
                    preview_rel = str(e.get('preview') or '').strip()
                    meta_rel = str(e.get('meta') or '').strip()
                    blend_abs = _norm_path(os.path.join(base_dir, blend_rel)) if blend_rel else ''
                    preview_abs = _norm_path(os.path.join(base_dir, preview_rel)) if preview_rel else ''
                    meta_abs = _norm_path(os.path.join(base_dir, meta_rel)) if meta_rel else ''
                    try:
                        version = int(e.get('version', 0) or 0)
                    except Exception:
                        version = 0
                    ref_key = blend_abs or f'{cat_fp}::{asset_name}::v{version}'
                    blend_ref_map.setdefault(ref_key, set()).add((asset_name, asset_id or asset_name))
                    if asset_id and blend_abs:
                        asset_id_map[asset_id]['paths'].add(blend_abs)
                    if blend_abs:
                        referenced_blends.add(blend_abs)
                        if not os.path.exists(blend_abs):
                            missing_blend_refs += 1
                            add_issue('ERROR', 'CATALOG_MISSING_BLEND', _ui_text(f'Missing blend referenced by catalog: {blend_abs}', f'カタログが参照する blend がありません：{blend_abs}'), blend_abs)
                    else:
                        missing_blend_refs += 1
                        add_issue('ERROR', 'CATALOG_EMPTY_BLEND', _ui_text(f'Catalog entry has no blend path: {cat_fp} :: {asset_name} v{version}', f'カタログの項目に blend のパスがありません：{cat_fp} :: {asset_name} v{version}'), cat_fp)
                    if preview_abs and not os.path.exists(preview_abs):
                        missing_preview_refs += 1
                        add_issue('WARNING', 'CATALOG_MISSING_PREVIEW', _ui_text(f'Missing preview referenced by catalog: {preview_abs}', f'カタログが参照するプレビューがありません：{preview_abs}'), preview_abs)
                    if meta_abs and not os.path.exists(meta_abs):
                        missing_meta_refs += 1
                        add_issue('WARNING', 'CATALOG_MISSING_META', _ui_text(f'Missing metadata referenced by catalog: {meta_abs}', f'カタログが参照するメタデータがありません：{meta_abs}'), meta_abs)

    asset_id_conflicts = 0
    asset_name_id_conflicts = 0
    multi_group_blend_refs = 0

    for aid, info in asset_id_map.items():
        if len(info['names']) > 1:
            asset_id_conflicts += 1
            names = ','.join(sorted(info['names']))
            add_issue('WARNING', 'ASSET_ID_NAME_CONFLICT', _ui_text(f'Asset ID is used by multiple asset names: {aid} -> {names}', f'Asset ID が複数のアセット名で使われています：{aid} -> {names}'), aid)

    for asset_name, ids in asset_name_map.items():
        clean_ids = {i for i in ids if i}
        if len(clean_ids) > 1:
            asset_name_id_conflicts += 1
            ids_txt = ','.join(sorted(clean_ids))
            add_issue('WARNING', 'ASSET_NAME_ID_CONFLICT', _ui_text(f'Asset name maps to multiple asset IDs: {asset_name} -> {ids_txt}', f'アセット名が複数の Asset ID に対応しています：{asset_name} -> {ids_txt}'), asset_name)

    for blend_fp, groups in blend_ref_map.items():
        if len(groups) > 1:
            multi_group_blend_refs += 1
            parts = ','.join(sorted({g[0] for g in groups}))
            add_issue('WARNING', 'BLEND_REFERENCED_BY_MULTIPLE_GROUPS', _ui_text(f'Same blend is referenced by multiple asset groups: {blend_fp} -> {parts}', f'同じ blend を複数のアセットのグループが参照しています：{blend_fp} -> {parts}'), blend_fp)

    orphan_blends = sorted(fp for fp in all_blends if fp not in referenced_blends)
    if orphan_blends:
        add_notice('ORPHAN_BLEND', _ui_text(f'Orphan blend files (not referenced by catalog): {len(orphan_blends)}', f'カタログから参照されていない Blend ファイル：{len(orphan_blends)}'))

    issue_count = len(issues)
    notice_count = len(notices)

    summary_lines = [
        f"{_t('Library Diagnostics')} | {now}",
        f"Blender {current_v_str}",
        '',
        _ui_text(f"Roots: total {len(root_rows)} / enabled {enabled_count} / existing {existing_count}", f'ルート：全部 {len(root_rows)}／有効 {enabled_count}／存在 {existing_count}'),
        _ui_text(f"Catalog files: {len(catalog_files)} | asset groups: {catalog_asset_groups} | entries: {catalog_entry_count}", f'カタログのファイル：{len(catalog_files)}｜アセットのグループ：{catalog_asset_groups}｜項目：{catalog_entry_count}'),
        _ui_text(f"Blend files: {blend_count} | orphan: {len(orphan_blends)} | newer-version: {newer_blend_count}", f'Blend ファイル：{blend_count}｜参照されていない物：{len(orphan_blends)}｜新しい版の物：{newer_blend_count}'),
        _ui_text(f"Missing roots: {missing_roots} | duplicate roots: {duplicate_roots} | invalid catalogs: {invalid_catalogs}", f'見つからないルート：{missing_roots}｜重複したルート：{duplicate_roots}｜無効なカタログ：{invalid_catalogs}'),
        _ui_text(f"Missing refs -> blend: {missing_blend_refs}, preview: {missing_preview_refs}, meta: {missing_meta_refs}", f'見つからない参照：blend {missing_blend_refs}、プレビュー {missing_preview_refs}、メタ {missing_meta_refs}'),
        _ui_text(f"Conflicts -> asset_id/name: {asset_id_conflicts}, asset_name/id: {asset_name_id_conflicts}, shared blend refs: {multi_group_blend_refs}", f'衝突：asset_id と名前 {asset_id_conflicts}、asset_name と ID {asset_name_id_conflicts}、共有の blend の参照 {multi_group_blend_refs}'),
        f"Issues: {issue_count} | Notices: {notice_count}",
    ]

    report_lines = []
    report_lines.extend(summary_lines)
    report_lines.extend(['', 'ROOT STATUS'])
    if root_rows:
        for row in root_rows:
            flags = []
            flags.append('ENABLED' if row['enabled'] else 'DISABLED')
            flags.append('OK' if row['exists'] else 'MISSING')
            if row['duplicate']:
                flags.append('DUPLICATE')
            report_lines.append(f"- [{','.join(flags)}] priority={row['priority']} | {row['path'] or '<empty>'}")
    else:
        report_lines.append(_ui_text('- No library roots configured', '- ライブラリのルートがありません'))

    if issues:
        report_lines.extend(['', 'ISSUES'])
        for it in issues:
            path_txt = f" | {it['path']}" if it.get('path') else ''
            report_lines.append(f"- [{it['severity']}] {it['code']}: {it['message']}{path_txt}")

    if notices:
        report_lines.extend(['', 'NOTICES'])
        for it in notices:
            path_txt = f" | {it['path']}" if it.get('path') else ''
            report_lines.append(f"- {it['code']}: {it['message']}{path_txt}")

    if orphan_blends:
        report_lines.extend(['', 'ORPHAN BLEND FILES'])
        for fp in orphan_blends[:max(1, int(list_limit))]:
            report_lines.append(f"- {fp}")
        if len(orphan_blends) > int(list_limit):
            report_lines.append(_ui_text(f"... and {len(orphan_blends) - int(list_limit)} more", f'…ほかに {len(orphan_blends) - int(list_limit)} 件'))

    report_name = _sf_write_report_text('smart_file_suite_Library_Diagnostics.txt', '\n'.join(report_lines) + '\n')

    compact_lines = summary_lines[:]
    compact_lines.extend([''])
    if issue_count == 0:
        compact_lines.append(_t('No diagnostics issues found'))
    else:
        compact_lines.append(f"{_t('Issues found')}: {issue_count}")
        for it in issues[:10]:
            compact_lines.append(f"- {it['code']}: {it['message']}")
        if issue_count > 10:
            compact_lines.append(_ui_text(f"... and {issue_count - 10} more", f'…ほかに {issue_count - 10} 件'))
    compact_lines.append('')
    compact_lines.append(f"{_t('Report Text')}: {report_name}")

    return {'summary': '\n'.join(compact_lines), 'report_name': report_name, 'issue_count': issue_count, 'notice_count': notice_count}


# ----------------------------
#  Operators: Preferences helpers
# ----------------------------

class SF_OT_asset_library_diagnostics(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_library_diagnostics'
    bl_label = 'Diagnostics'
    bl_description = 'Scan configured library roots for missing folders, unsupported files, catalog issues, and index inconsistencies'
    bl_options = {'UNDO', 'INTERNAL'}

    include_disabled: BoolProperty(
        name='Include disabled roots',
        default=False,
        description='Scan disabled roots too when generating the diagnostics report',
    )
    open_text: BoolProperty(
        name='Open report in Text Editor',
        default=False,
        description='Switch the active Text Editor to the generated report when possible',
    )
    list_limit: IntProperty(
        name='List Limit',
        default=40,
        min=5,
        max=500,
        description='Maximum number of detailed paths to list in the report popup/text for long sections',
    )
    summary_text: StringProperty(default="", options={'HIDDEN'})
    report_name: StringProperty(default="", options={'HIDDEN'})

    def invoke(self, context, _event):
        data = _sf_run_library_diagnostics(context, include_disabled=bool(self.include_disabled), list_limit=int(self.list_limit))
        self.summary_text = data.get('summary', '')
        self.report_name = data.get('report_name', '')
        return context.window_manager.invoke_props_dialog(self, width=720)

    def draw(self, context):
        layout = self.layout
        prefs = _addon_prefs(context)
        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []
        enabled_roots = sum(1 for root in roots if bool(getattr(root, 'enabled', True)))
        box = layout.box()
        _sf_draw_section_intro(box, "Library Diagnostics", "Use this advanced check after the basic source, root, and workflow setup is already in place.", 'CHECKMARK')
        box.label(text=f"{_t('Enabled Roots')}: {enabled_roots}", icon='FILE_FOLDER')
        if enabled_roots <= 0:
            _sf_draw_hint(box, "Diagnostics will stay limited until at least one library root is enabled.", 'ERROR')
        for line in (self.summary_text or '').splitlines():
            if not line.strip():
                box.separator()
            else:
                box.label(text=line[:240])
        col = layout.column(align=True)
        col.prop(self, 'include_disabled')
        col.prop(self, 'open_text')

    def execute(self, context):
        data = _sf_run_library_diagnostics(context, include_disabled=bool(self.include_disabled), list_limit=int(self.list_limit))
        self.summary_text = data.get('summary', '')
        self.report_name = data.get('report_name', '')

        if self.open_text and self.report_name:
            _sf_open_text_in_any_editor(context, self.report_name)

        issue_count = int(data.get('issue_count', 0) or 0)
        if issue_count:
            self.report({'WARNING'}, f"{_t('Diagnostics complete')}: {_t('Issues found')} {issue_count}")
        else:
            self.report({'INFO'}, f"{_t('Diagnostics complete')}: {_t('No diagnostics issues found')}")
        return {'FINISHED'}


class SF_OT_asset_library_repair_roots(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_library_repair_roots'
    bl_label = 'Repair Roots'
    bl_description = 'Review configured library roots and apply safe cleanup and normalization suggestions before indexing or publishing'
    bl_options = {'UNDO', 'INTERNAL'}

    normalize_paths: BoolProperty(
        name='Normalize paths',
        default=True,
        description='Normalize configured library root paths before applying repair actions',
    )
    remove_empty: BoolProperty(
        name='Remove empty roots',
        default=True,
        description='Remove library root entries whose path is empty',
    )
    merge_duplicates: BoolProperty(
        name='Merge duplicate roots',
        default=True,
        description='Merge duplicate library root entries and keep the safest combined state',
    )
    disable_missing: BoolProperty(
        name='Disable missing roots',
        default=True,
        description='Disable enabled roots that no longer exist on disk',
    )
    sort_by_priority: BoolProperty(
        name='Sort by priority',
        default=True,
        description='Sort roots by enabled state and priority after repair',
    )
    rebuild_index: BoolProperty(
        name='Rebuild index after repair',
        default=True,
        description='Refresh the library index for enabled roots after repair',
    )
    open_text: BoolProperty(
        name='Open report in Text Editor',
        default=False,
        description='Open the generated repair report in a Text Editor when possible',
    )
    summary_text: StringProperty(default="", options={'HIDDEN'})
    report_name: StringProperty(default="", options={'HIDDEN'})

    def invoke(self, context, _event):
        self.summary_text = ""
        self.report_name = ""
        return context.window_manager.invoke_props_dialog(self, width=560)

    def draw(self, context):
        layout = self.layout
        prefs = _addon_prefs(context)
        roots = list(getattr(prefs, 'library_roots', []) or []) if prefs else []
        enabled_roots = sum(1 for root in roots if bool(getattr(root, 'enabled', True)))
        box = layout.box()
        _sf_draw_section_intro(box, "Repair Library Roots", "Use this advanced root-repair tool after the basic source setup is visible. Catalog files on disk are not modified.", 'PREFERENCES')
        box.label(text=f"{_t('Enabled Roots')}: {enabled_roots}", icon='FILE_FOLDER')
        if enabled_roots <= 0:
            _sf_draw_hint(box, "Root repair and index rebuild stay limited until at least one library root is enabled.", 'ERROR')
        col = layout.column(align=True)
        col.prop(self, 'normalize_paths')
        col.prop(self, 'remove_empty')
        col.prop(self, 'merge_duplicates')
        col.prop(self, 'disable_missing')
        col.prop(self, 'sort_by_priority')
        col.prop(self, 'rebuild_index')
        col.prop(self, 'open_text')
        if self.summary_text:
            sbox = layout.box()
            for line in (self.summary_text or '').splitlines():
                if not line.strip():
                    sbox.separator()
                else:
                    sbox.label(text=line[:240])

    def execute(self, context):
        data = _sf_repair_library_roots(
            context,
            normalize_paths=bool(self.normalize_paths),
            remove_empty=bool(self.remove_empty),
            merge_duplicates=bool(self.merge_duplicates),
            disable_missing=bool(self.disable_missing),
            sort_by_priority=bool(self.sort_by_priority),
            rebuild_index=bool(self.rebuild_index),
        )
        self.summary_text = data.get('summary', '')
        self.report_name = data.get('report_name', '')

        if self.open_text and self.report_name:
            _sf_open_text_in_any_editor(context, self.report_name)

        change_count = int(data.get('change_count', 0) or 0)
        if change_count:
            self.report({'INFO'}, f"{_t('Repair complete')}: {_t('Changes applied')} {change_count}")
        else:
            self.report({'INFO'}, f"{_t('Repair complete')}: {_t('No changes required')}")
        return {'FINISHED'}


def _sf_slugify(text: str) -> str:
    text = str(text or '').strip()
    text = re.sub(r'[^A-Za-z0-9_\-]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_')
    return text or 'root'


def _sf_relpath_posix(path: str, base_dir: str) -> str:
    path_n = _norm_path(path)
    base_n = _norm_path(base_dir)
    try:
        rel = os.path.relpath(path_n, base_n)
    except Exception:
        rel = path_n
    return rel.replace(os.sep, '/')


def _sf_guess_version_from_blend(blend_path: str) -> int:
    stem = os.path.splitext(os.path.basename(blend_path))[0]
    for pat in (r'[_\-.]v(\d{1,5})$', r'[_\-.]ver(\d{1,5})$'):
        m = re.search(pat, stem, flags=re.IGNORECASE)
        if m:
            try:
                return max(1, int(m.group(1)))
            except Exception:
                pass
    return 1


def _sf_guess_preview_sidecar(blend_path: str) -> str:
    stem = os.path.splitext(blend_path)[0]
    candidates = []
    for ext in ('.png', '.jpg', '.jpeg', '.webp'):
        candidates.append(stem + ext)
    for suffix in ('_preview', '_thumb', '_thumbnail'):
        for ext in ('.png', '.jpg', '.jpeg', '.webp'):
            candidates.append(stem + suffix + ext)
    for fp in candidates:
        if os.path.exists(fp):
            return _norm_path(fp)
    return ''


def _sf_guess_meta_sidecar(blend_path: str) -> str:
    stem = os.path.splitext(blend_path)[0]
    for fp in (stem + '.json', stem + '.meta.json', stem + '_meta.json'):
        if os.path.exists(fp):
            return _norm_path(fp)
    return ''


def _sf_make_catalog_draft_asset_id(prefs, asset_name: str, root_path: str, blend_path: str) -> str:
    prefix = (getattr(prefs, 'pub_asset_id_prefix', '') if prefs else '') or ''
    prefix = re.sub(r'[^A-Za-z0-9_\-]', '_', prefix.strip())
    try:
        rel = _sf_relpath_posix(blend_path, root_path)
        base = f"{prefix}:{asset_name}:{rel}" if prefix else f"{asset_name}:{rel}"
        uid = str(uuid.uuid5(uuid.NAMESPACE_URL, base))
        scheme = getattr(prefs, 'pub_asset_id_scheme', 'UUID4') if prefs else 'UUID4'
        if scheme in {'PREFIX_UUID4', 'PREFIX_UUID5'} and prefix:
            return f"{prefix}-{uid}"
        return uid
    except Exception:
        return _pub_generate_asset_id(prefs, asset_name)


def _sf_guess_draft_category(root_path: str, blend_path: str, mode: str, default_category: str = '') -> str:
    mode = str(mode or 'RELATIVE_FOLDER').upper()
    default_category = str(default_category or '').strip()
    if mode == 'DEFAULT':
        return default_category
    if mode == 'ROOT':
        return os.path.basename(_norm_path(root_path)) or default_category
    rel_dir = os.path.dirname(_sf_relpath_posix(blend_path, root_path)).strip('./')
    if not rel_dir:
        return default_category or (os.path.basename(_norm_path(root_path)) or '')
    return rel_dir.replace(os.sep, '/')


def _sf_collect_root_catalog_references(root_path: str, catalog_filename: str) -> set[str]:
    out = set()
    for cat_fp in _ar_find_catalog_files(root_path, catalog_filename, max_depth=6, limit=1000):
        cat_fp = _norm_path(cat_fp)
        cat = _ar_load_catalog(cat_fp)
        assets = (cat.get('assets') or {}) if isinstance(cat, dict) else {}
        if not isinstance(assets, dict):
            continue
        base_dir = os.path.dirname(cat_fp)
        for _asset_key, data in assets.items():
            if not isinstance(data, dict):
                continue
            for e in list(data.get('entries', []) or []):
                if not isinstance(e, dict):
                    continue
                blend_rel = str(e.get('blend') or '').strip()
                if not blend_rel:
                    continue
                out.add(_norm_path(os.path.join(base_dir, blend_rel)))
    return out


def _sf_generate_catalog_draft(context, include_disabled: bool = False, only_orphans: bool = True, category_mode: str = 'RELATIVE_FOLDER', infer_preview: bool = True, infer_meta: bool = True, list_limit: int = 40) -> dict:
    prefs = _addon_prefs(context)
    catalog_filename = getattr(prefs, 'pub_catalog_filename', 'catalog.json') if prefs else 'catalog.json'
    default_category = getattr(prefs, 'pub_default_category', '') if prefs else ''

    root_rows = []
    roots_src = list(getattr(prefs, 'library_roots', []) or []) if prefs else []
    for idx, r in enumerate(roots_src):
        path = _norm_path(getattr(r, 'path', '') or '')
        enabled = bool(getattr(r, 'enabled', True))
        exists = bool(path and os.path.isdir(path))
        if not path or not exists:
            continue
        if (not include_disabled) and (not enabled):
            continue
        root_rows.append({'index': idx, 'path': path, 'enabled': enabled, 'priority': int(getattr(r, 'priority', 0) or 0)})

    total_selected = 0
    total_roots_written = 0
    json_text_names = []
    report_lines = [
        f"{_t('Generate Catalog Draft')} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        '',
        _ui_text(f"Only orphans: {bool(only_orphans)}", f'参照されていない物のみ：{"オン" if only_orphans else "オフ"}'),
        _ui_text(f"Category mode: {category_mode}", f'カテゴリのモード：{category_mode}'),
        _ui_text(f"Infer preview: {bool(infer_preview)} | Infer meta: {bool(infer_meta)}", f'プレビューの推測：{"オン" if infer_preview else "オフ"}｜メタの推測：{"オン" if infer_meta else "オフ"}'),
        '',
    ]

    text_name_seen = set()
    for row in sorted(root_rows, key=lambda it: (-int(it['priority']), os.path.basename(it['path']).lower(), it['path'].lower())):
        root_path = row['path']
        referenced = _sf_collect_root_catalog_references(root_path, catalog_filename)
        all_blends = sorted({_norm_path(fp) for fp in _iter_blend_files_under(root_path)})
        selected = [fp for fp in all_blends if (fp not in referenced)] if only_orphans else list(all_blends)
        if not selected:
            continue

        target_catalog_path = _norm_path(os.path.join(root_path, _safe_filename(catalog_filename) or 'catalog.json'))
        target_catalog_dir = os.path.dirname(target_catalog_path)
        payload = {'assets': {}, '_meta': {
            'root_path': root_path,
            'target_catalog_path': target_catalog_path,
            'generated_at': datetime.datetime.now().isoformat(timespec='seconds'),
            'only_orphans': bool(only_orphans),
            'category_mode': category_mode,
        }}
        used_asset_keys = {}

        for blend_fp in selected:
            stem = os.path.splitext(os.path.basename(blend_fp))[0]
            asset_key_base = stem or 'Asset'
            n = used_asset_keys.get(asset_key_base.lower(), 0)
            used_asset_keys[asset_key_base.lower()] = n + 1
            asset_key = asset_key_base if n == 0 else f"{asset_key_base}__{n+1}"
            ver = _sf_guess_version_from_blend(blend_fp)
            category = _sf_guess_draft_category(root_path, blend_fp, category_mode, default_category)
            preview_abs = _sf_guess_preview_sidecar(blend_fp) if infer_preview else ''
            meta_abs = _sf_guess_meta_sidecar(blend_fp) if infer_meta else ''
            entry = {
                'version': ver,
                'blend': _sf_relpath_posix(blend_fp, target_catalog_dir),
                'preview': _sf_relpath_posix(preview_abs, target_catalog_dir) if preview_abs else '',
                'meta': _sf_relpath_posix(meta_abs, target_catalog_dir) if meta_abs else '',
                'published_at': '',
                'category': category or '',
                'tags': [],
                'draft_source': 'orphan_blend' if only_orphans else 'library_scan',
            }
            payload['assets'][asset_key] = {
                'asset_id': _sf_make_catalog_draft_asset_id(prefs, asset_key, root_path, blend_fp),
                'latest': ver,
                'entries': [entry],
            }
            total_selected += 1

        if not payload['assets']:
            continue

        root_slug = _sf_slugify(os.path.basename(root_path) or f"root_{row['index']}")
        text_name = f"smart_file_suite_Catalog_Draft_{root_slug}.json"
        if text_name in text_name_seen:
            text_name = f"smart_file_suite_Catalog_Draft_{root_slug}_{row['index']}.json"
        text_name_seen.add(text_name)
        _sf_write_report_text(text_name, json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
        json_text_names.append(text_name)
        total_roots_written += 1

        report_lines.append(f"ROOT | {root_path}")
        report_lines.append(_ui_text(f"- Target catalog path: {target_catalog_path}", f'- 対象のカタログのパス：{target_catalog_path}'))
        report_lines.append(_ui_text(f"- Draft text: {text_name}", f'- 下書きのテキスト：{text_name}'))
        report_lines.append(_ui_text(f"- Draft entries: {len(payload['assets'])}", f"- 下書きの項目：{len(payload['assets'])}"))
        sample_paths = selected[:max(1, int(list_limit))]
        for fp in sample_paths:
            report_lines.append(f"  - {_sf_relpath_posix(fp, root_path)}")
        if len(selected) > int(list_limit):
            report_lines.append(_ui_text(f"  ... and {len(selected) - int(list_limit)} more", f'  …ほかに {len(selected) - int(list_limit)} 件'))
        report_lines.append('')

    report_lines.append(f"{_t('Generated root drafts')}: {total_roots_written}")
    report_lines.append(f"{_t('Draft entries')}: {total_selected}")
    if json_text_names:
        report_lines.append(f"{_t('Draft Text')}: {','.join(json_text_names)}")
    report_name = _sf_write_report_text('smart_file_suite_Catalog_Draft_Report.txt', '\n'.join(report_lines) + '\n')

    summary_lines = [
        f"{_t('Generate Catalog Draft')} | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"{_t('Generated root drafts')}: {total_roots_written}",
        f"{_t('Draft entries')}: {total_selected}",
        f"{_t('Report Text')}: {report_name}",
    ]
    if json_text_names:
        summary_lines.append(f"{_t('Draft Text')}: {json_text_names[0]}" + (f" (+{len(json_text_names)-1})" if len(json_text_names) > 1 else ''))
    else:
        summary_lines.append(_t('No draft entries generated'))

    return {
        'summary': '\n'.join(summary_lines),
        'report_name': report_name,
        'json_text_names': json_text_names,
        'draft_count': total_roots_written,
        'entry_count': total_selected,
    }


class SF_OT_asset_library_generate_catalog_draft(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_library_generate_catalog_draft'
    bl_label = 'Generate Catalog Draft'
    bl_description = 'Build a draft catalog.json proposal from the current library roots without changing published files immediately'
    bl_options = {'UNDO', 'INTERNAL'}

    include_disabled: BoolProperty(
        name='Include disabled roots',
        default=False,
        description='Scan disabled roots too when generating the draft',
    )
    only_orphans: BoolProperty(
        name='Only orphan blends',
        default=True,
        description='Generate entries only for blend files that are not referenced by any discovered catalog',
    )
    category_mode: EnumProperty(
        name='Category Mode',
        items=[
            ('RELATIVE_FOLDER', 'Relative folder', 'Use the blend file relative folder under the library root'),
            ('ROOT', 'Root name', 'Use the library root folder name as the category'),
            ('DEFAULT', 'Default category', 'Use the add-on default publish category for every generated entry'),
        ],
        default='RELATIVE_FOLDER',
    )
    infer_preview: BoolProperty(
        name='Infer preview sidecars',
        default=True,
        description='Detect common preview image sidecars next to the blend file and include them in the draft',
    )
    infer_meta: BoolProperty(
        name='Infer metadata sidecars',
        default=True,
        description='Detect common JSON sidecars next to the blend file and include them in the draft',
    )
    open_text: BoolProperty(
        name='Open report after generation',
        default=False,
        description='Open the generated draft report in a Text Editor when possible',
    )
    list_limit: IntProperty(
        name='List Limit',
        default=25,
        min=5,
        max=500,
        description='Maximum number of paths listed per root inside the generated report',
    )
    summary_text: StringProperty(default='', options={'HIDDEN'})
    report_name: StringProperty(default='', options={'HIDDEN'})

    def invoke(self, context, _event):
        self.summary_text = ''
        self.report_name = ''
        return context.window_manager.invoke_props_dialog(self, width=620)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text=_t('Generate Catalog Draft'), icon='TEXT')
        col = layout.column(align=True)
        col.prop(self, 'include_disabled')
        col.prop(self, 'only_orphans', text=_t('Only orphan blends'))
        col.prop(self, 'category_mode')
        col.prop(self, 'infer_preview')
        col.prop(self, 'infer_meta')
        col.prop(self, 'open_text')
        if self.summary_text:
            sbox = layout.box()
            for line in (self.summary_text or '').splitlines():
                if not line.strip():
                    sbox.separator()
                else:
                    sbox.label(text=line[:240])

    def execute(self, context):
        data = _sf_generate_catalog_draft(
            context,
            include_disabled=bool(self.include_disabled),
            only_orphans=bool(self.only_orphans),
            category_mode=str(self.category_mode or 'RELATIVE_FOLDER'),
            infer_preview=bool(self.infer_preview),
            infer_meta=bool(self.infer_meta),
            list_limit=int(self.list_limit),
        )
        self.summary_text = data.get('summary', '')
        self.report_name = data.get('report_name', '')
        if self.open_text and self.report_name:
            _sf_open_text_in_any_editor(context, self.report_name)
        entry_count = int(data.get('entry_count', 0) or 0)
        if entry_count:
            self.report({'INFO'}, f"{_t('Catalog draft complete')}: {_t('Draft entries')} {entry_count}")
        else:
            self.report({'INFO'}, f"{_t('Catalog draft complete')}: {_t('No draft entries generated')}")
        return {'FINISHED'}


class SF_OT_asset_library_add_root(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_library_add_root'
    bl_label = 'Add Root'
    bl_description = 'Register a new library root folder so diagnostics, indexing, relink, and publish tools know where to search'
    bl_options = {'UNDO', 'INTERNAL'}

    def execute(self, context):
        prefs = _addon_prefs(context)
        if not prefs:
            return {'CANCELLED'}
        p = _norm_path(getattr(prefs, "new_library_root_path", ""))
        if not p or not os.path.isdir(p):
            self.report({'WARNING'}, _tr('Invalid folder'))
            return {'CANCELLED'}
        it = prefs.library_roots.add()
        it.path = p
        it.enabled = True
        prefs.new_library_root_path = ""
        return {'FINISHED'}


class SF_OT_asset_library_remove_root(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_library_remove_root'
    bl_label = 'Remove Root'
    bl_description = 'Remove the selected library root from the add-on configuration without deleting files from disk'
    bl_options = {'UNDO', 'INTERNAL'}

    index: IntProperty(default=-1)

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        prefs = _addon_prefs(context)
        if not prefs:
            return {'CANCELLED'}
        idx = int(self.index)
        if 0 <= idx < len(prefs.library_roots):
            removed_path = _norm_path(getattr(prefs.library_roots[idx], 'path', '') or '')
            prefs.library_roots.remove(idx)
            if removed_path:
                self.report({'INFO'}, f"{_t('Removed')}: {removed_path}")
        return {'FINISHED'}


class SF_OT_asset_library_rebuild_index(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_asset_library_rebuild_index'
    bl_label = 'Rebuild Index'
    bl_description = 'Rescan configured library roots and rebuild the cached index used by Asset Reader and Reference Manager'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    full_rebuild: BoolProperty(default=False)

    def execute(self, context):
        prefs = _addon_prefs(context)
        if not prefs:
            return {'CANCELLED'}
        roots = []
        for r in getattr(prefs, "library_roots", []) or []:
            if getattr(r, "enabled", True):
                p = _norm_path(getattr(r, "path", ""))
                if p and os.path.isdir(p):
                    roots.append(p)
        if not roots:
            self.report({'WARNING'}, _tr('No library roots'))
            return {'CANCELLED'}

        scanned = _rebuild_index_for_roots(context, roots, full_rebuild=bool(self.full_rebuild))
        self.report({'INFO'}, f"{_tr('Index updated')}: {scanned}")
        return {'FINISHED'}




# ----------------------------
#  Asset Reader Catalog helpers
# ----------------------------

def _ar_category_enum_id(category: str) -> str:
    c = str(category or "").strip()
    if not c:
        return "ALL"
    return f"CAT_{uuid.uuid5(uuid.NAMESPACE_URL, c).hex[:12].upper()}"


def _ar_category_value_from_enum(wm, value: str) -> str:
    value = str(value or 'ALL')
    if not value or value == 'ALL':
        return 'ALL'
    try:
        cats = json.loads(getattr(wm, 'sf_ar_cat_categories_json', '') or '[]') if wm else []
    except Exception:
        cats = []
    for c in cats:
        c = str(c or '').strip()
        if not c:
            continue
        if value == c or value == _ar_category_enum_id(c):
            return c
    return value


def _ar_cat_category_items(_self, context):
    wm = getattr(context, "window_manager", None) if context else None
    try:
        cats = json.loads(getattr(wm, 'sf_ar_cat_categories_json', '') or '[]') if wm else []
    except Exception:
        cats = []
    items = [('ALL', _t('All'), '')]
    seen = set()
    for c in cats:
        c = str(c or '').strip()
        if not c or c in seen:
            continue
        seen.add(c)
        items.append((_ar_category_enum_id(c), c, c))
    return _sf_stable_enum_items(items)


def _ar_cat_pref_source_items(_self, context):
    wm = getattr(context, "window_manager", None) if context else None
    items = [('AUTO', _t('Auto'), _t('Use merge priority rules'))]
    cand = []
    try:
        if wm and 0 <= wm.sf_ar_cat_active_index < len(wm.sf_ar_cat_assets):
            a = wm.sf_ar_cat_assets[wm.sf_ar_cat_active_index]
            cand = json.loads(getattr(a, 'candidates_json', '[]') or '[]')
    except Exception:
        cand = []
    seen = set()
    for i, p in enumerate(cand or []):
        p = _norm_path(str(p))
        if not p or p in seen:
            continue
        seen.add(p)
        label = os.path.basename(p) or _ui_text(f"Catalog {i}", f'カタログ {i}')
        parent = os.path.basename(os.path.dirname(p))
        if parent:
            label = f"{label} ({parent})"
        items.append((f"C{i}", label, p))
    return _sf_stable_enum_items(items)


def _ar_load_catalog(catalog_path: str) -> dict:
    catalog_path = _norm_path(catalog_path)
    if not catalog_path or not os.path.exists(catalog_path):
        return {}
    try:
        with open(catalog_path, 'r', encoding='utf-8') as f:
            return json.load(f) or {}
    except Exception:
        return {}
