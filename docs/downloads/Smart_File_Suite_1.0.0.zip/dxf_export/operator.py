# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender operator for SmartFile's DXF mesh exporter."""
import bpy
from bpy.props import BoolProperty, EnumProperty, StringProperty


class SFS_OT_dxf_export(bpy.types.Operator):
    """Write mesh geometry to an AutoCAD DXF drawing"""
    bl_idname = "export.sfs_dxf_export"
    bl_label = "Export"
    bl_options = {"UNDO"}

    filepath: StringProperty(subtype="FILE_PATH")
    projectionThrough: EnumProperty(
        name="Projection",
        items=[("NO", "No projection", "Export in world coordinates"),
               *((view, view.title(), "Project onto the " + view.lower() + " view")
                 for view in ("TOP", "BOTTOM", "LEFT", "RIGHT", "FRONT", "REAR"))],
        default="NO",
    )
    onlySelected: BoolProperty(name="Only selected", default=True)
    apply_modifiers: BoolProperty(name="Apply modifiers", default=True)
    mesh_as: EnumProperty(
        name="Export Mesh As",
        items=[
            ("NO", "Do not export", ""),
            ("3DFACEs", "3DFACEs", "Export each face as an entity"),
            ("POLYFACE", "POLYFACE", "Export connected faces in a polyface mesh"),
            ("POLYLINE", "POLYLINE", "Export connected faces in a polyface mesh"),
            ("LINEs", "LINEs", "Export mesh edges"),
            ("POINTs", "POINTs", "Export mesh vertices"),
        ],
        default="3DFACEs",
    )
    entitylayer_from: EnumProperty(
        name="Entity Layer",
        items=[
            ("default_LAYER", "Default Layer", "Use the chosen layer name"),
            ("obj.name", "Object name", ""),
            ("obj.layer", "Object layer", "Use the object's collection"),
            ("obj.material", "Object material", "Use the first material's name"),
            ("obj.data.name", "Object data name", ""),
            ("..vertexgroup", "Vertex Group", "Uses the default layer name"),
            ("..group", "Group", "Uses the object's collection"),
            ("..map_table", "Table", "Uses the default layer name"),
        ],
        default="obj.data.name",
    )
    entitycolor_from: EnumProperty(
        name="Entity Color",
        items=[
            ("default_COLOR", "Default Color", "Use the DXF layer color"),
            ("BYLAYER", "BYLAYER", ""),
            ("BYBLOCK", "BYBLOCK", ""),
            ("obj.layer", "Object Layer", "Assign a color by collection"),
            ("obj.color", "Object Color", "Match the nearest DXF palette color"),
            ("obj.material", "Object material", "Match the first material's color"),
        ],
        default="default_COLOR",
    )
    entityltype_from: EnumProperty(
        name="Entity Linetype",
        items=[(name, name, "") for name in (
            "default_LTYPE", "BYLAYER", "BYBLOCK", "CONTINUOUS", "DOT",
            "DASHED", "DASHDOT", "BORDER", "HIDDEN",
        )],
        default="CONTINUOUS",
    )
    layerName_from: EnumProperty(
        name="Layer Name",
        items=[
            ("LAYERNAME_DEF", "Default Name", ""),
            ("drawing_name", "From Drawing name", ""),
            ("scene_name", "From scene name", ""),
        ],
        default="LAYERNAME_DEF",
    )
    verbose: BoolProperty(name="Verbose", description="Print export details to the console", default=False)

    def invoke(self, context, _event):
        if not self.filepath:
            self.filepath = bpy.path.ensure_ext(bpy.data.filepath, ".dxf")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        from .independent.mesh_scene import export_mesh

        if not self.filepath:
            self.report({"ERROR"}, "Choose a DXF filename")
            return {"CANCELLED"}
        if self.mesh_as == "NO":
            self.report({"WARNING"}, "Mesh export is disabled")
            return {"CANCELLED"}

        try:
            filename = bpy.path.ensure_ext(self.filepath, ".dxf")
            export_mesh(self, context, bpy.path.abspath(filename))
        except (OSError, ValueError) as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}
