from .base_exporter import BasePrimitiveDXFExporter


# --- Audit guard (2026-08-19): the legacy Blender 2.4-era helper functions in
# this vendored module reference names that were never defined in this copy.
# They are bound here as inert placeholders so every name resolves; the live
# export path uses the *DXFExporter classes via export_dxf.py and never calls
# those helpers.
import mathutils
DXF = GUI_A = empty_as_list = projected_co = toGlobalOrigin = None


class EmptyDXFExporter(BasePrimitiveDXFExporter):
    pass

#-----------------------------------------------------
def exportEmpty(ob, mx, mw, **common):
    """converts Empty-Object to desired projection and representation(DXF-Entity type)
    """
    p =  mathutils.Vector(ob.loc)
    [p] = projected_co([p], mx)
    [p] = toGlobalOrigin([p])

    entities = []
    c = empty_as_list[GUI_A['empty_as'].val]
    if c=="POINT": # export Empty as POINT
        dxfPOINT = DXF.Point(points=[p],**common)
        entities.append(dxfPOINT)
    return entities
