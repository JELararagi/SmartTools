# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Expose Smart File's DXF export in Blender's File menu."""

import bpy

from . import operator


bl_info = {
    "name": "Export AutoCAD DXF Format (.dxf)",
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "File > Export",
    "description": "Export AutoCAD DXF (.dxf) files",
    "category": "Import-Export",
}
classes = (operator.SFS_OT_dxf_export,)


def menu_func(menu, _context):
    menu.layout.operator(operator.SFS_OT_dxf_export.bl_idname, text="Export")


def register():
    bpy.utils.register_class(operator.SFS_OT_dxf_export)
    try:
        bpy.types.TOPBAR_MT_file_export.append(menu_func)
    except Exception:
        bpy.utils.unregister_class(operator.SFS_OT_dxf_export)
        raise


def unregister():
    bpy.types.TOPBAR_MT_file_export.remove(menu_func)
    bpy.utils.unregister_class(operator.SFS_OT_dxf_export)
