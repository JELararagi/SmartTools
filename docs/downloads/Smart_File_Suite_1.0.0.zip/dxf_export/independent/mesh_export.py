"""Convert indexed mesh data to the independently supplied R12 writer types.

Copyright (c) 2026 JELararagi. SPDX-License-Identifier: GPL-3.0-or-later
No Blender dependency, file I/O, coordinate welding, or polygon triangulation.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
import re

from .r12_writer import Face3D, Line3D

__all__ = ['MeshExportError', 'MeshExportResult', 'mesh_to_entities']
_LAYER = re.compile(r'[A-Za-z0-9_$-]{1,31}\Z', re.ASCII)


class MeshExportError(ValueError):
    """Stable code/location/details for the product's localized messages."""

    def __init__(self, code: str, location: str, **details):
        self.code = code
        self.location = location
        self.details = details
        super().__init__(f'{code}: {location}')


@dataclass(frozen=True)
class MeshExportResult:
    entities: tuple[Face3D | Line3D, ...]
    face_count: int
    wire_count: int
    boundary_edge_indices: tuple[int, ...]
    unused_vertex_indices: tuple[int, ...]


def _sequence(value, location):
    if not isinstance(value, (list, tuple)):
        raise MeshExportError('INVALID_CONTAINER', location, actual_type=type(value).__name__)
    return tuple(value)


def _point(value, number):
    location = f'vertices[{number}]'
    values = _sequence(value, location)
    if len(values) != 3:
        raise MeshExportError('INVALID_COORDINATE_SIZE', location, size=len(values))
    result = []
    for axis, coordinate in enumerate(values):
        field = f'{location}[{axis}]'
        if isinstance(coordinate, bool) or not isinstance(coordinate, (int, float)):
            raise MeshExportError('INVALID_COORDINATE_TYPE', field, actual_type=type(coordinate).__name__)
        try:
            converted = float(coordinate)
        except (OverflowError, ValueError) as exc:
            raise MeshExportError('COORDINATE_OUT_OF_RANGE', field) from exc
        if not math.isfinite(converted):
            raise MeshExportError('NONFINITE_COORDINATE', field)
        result.append(converted)
    return tuple(result)


def _indices(value, location, sizes, vertex_count, size_code):
    result = _sequence(value, location)
    if len(result) not in sizes:
        raise MeshExportError(size_code, location, size=len(result), allowed_sizes=sizes)
    for position, index in enumerate(result):
        field = f'{location}[{position}]'
        if isinstance(index, bool) or not isinstance(index, int):
            raise MeshExportError('INVALID_INDEX_TYPE', field, actual_type=type(index).__name__)
        if not 0 <= index < vertex_count:
            raise MeshExportError('INDEX_OUT_OF_RANGE', field, index=index, vertex_count=vertex_count)
    return result


def _edge_key(a, b):
    return (a, b) if a <= b else (b, a)


def mesh_to_entities(vertices, faces=(), edges=(), *, layer='0') -> MeshExportResult:
    """Validate a mesh, then return ordered Face3D/Line3D records and omissions.

    Inputs are lists/tuples. Faces have 3 or 4 indices; edges have 2. All vertex
    coordinates must be finite int/float values (not bool). Indices are zero-based
    nonnegative integers (not bool). Layer names follow r12_writer's narrow contract.
    Faces retain their order/winding. Only edges equal to an indexed face boundary
    are omitted; all other edge entries retain order, direction, and multiplicity.
    Unreferenced vertex-pool entries are reported, not emitted as POINT entities.
    No geometric repair, area/planarity validation, I/O, or input mutation occurs.
    """
    if not isinstance(layer, str) or _LAYER.fullmatch(layer) is None:
        raise MeshExportError('INVALID_LAYER', 'layer')
    points = tuple(_point(point, i) for i, point in enumerate(_sequence(vertices, 'vertices')))
    face_indices = tuple(
        _indices(face, f'faces[{i}]', (3, 4), len(points), 'UNSUPPORTED_FACE_SIZE')
        for i, face in enumerate(_sequence(faces, 'faces'))
    )
    edge_indices = tuple(
        _indices(edge, f'edges[{i}]', (2,), len(points), 'INVALID_EDGE_SIZE')
        for i, edge in enumerate(_sequence(edges, 'edges'))
    )
    # Validate every input before constructing any output entity.
    boundary = {
        _edge_key(a, b)
        for face in face_indices
        for a, b in zip(face, face[1:] + face[:1])
    }
    omitted = tuple(i for i, (a, b) in enumerate(edge_indices) if _edge_key(a, b) in boundary)
    wire_edges = tuple((a, b) for a, b in edge_indices if _edge_key(a, b) not in boundary)
    referenced = {index for face in face_indices for index in face}
    referenced.update(index for edge in edge_indices for index in edge)
    entities = tuple(Face3D(tuple(points[index] for index in face), layer) for face in face_indices)
    entities += tuple(Line3D(points[a], points[b], layer) for a, b in wire_edges)
    return MeshExportResult(
        entities, len(face_indices), len(wire_edges), omitted,
        tuple(i for i in range(len(points)) if i not in referenced),
    )
