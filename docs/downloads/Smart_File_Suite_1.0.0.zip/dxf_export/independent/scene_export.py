'''Apply explicit world-space affine transforms before independent R12 export.

Created through JEL Local Bridge using AI generation, 2026.
Copyright (c) 2026 JELararagi. SPDX-License-Identifier: GPL-3.0-or-later
Uses only the designated independent mesh_export and r12_writer public APIs.
No Blender, third-party DXF implementation, unit conversion, or input mutation.
'''
from __future__ import annotations

from dataclasses import dataclass
import math
from pathlib import Path

from .mesh_export import MeshExportError, mesh_to_entities
from . import r12_writer
from .r12_writer import Face3D, Line3D, Point3D, Polyface3D

__all__ = [
    'IDENTITY', 'SceneMesh', 'SceneExportError', 'ObjectExportInfo',
    'SceneExportResult', 'SceneExportReceipt', 'scene_to_entities', 'export_scene_r12',
]

IDENTITY = ((1, 0, 0, 0), (0, 1, 0, 0), (0, 0, 1, 0), (0, 0, 0, 1))


class SceneExportError(ValueError):
    '''Machine-readable source information for caller-owned localized messages.'''

    def __init__(self, code, object_index, object_name, location, **details):
        self.code = code
        self.object_index = object_index
        self.object_name = object_name
        self.location = location
        self.details = details
        source = 'scene' if object_index is None else f'objects[{object_index}] ({object_name!r})'
        super().__init__(f'{code}: {source}, {location}')


@dataclass(frozen=True)
class SceneMesh:
    name: str
    vertices: list | tuple
    faces: list | tuple = ()
    edges: list | tuple = ()
    matrix_world: list | tuple = IDENTITY
    layer: str = '0'


@dataclass(frozen=True)
class ObjectExportInfo:
    object_index: int
    object_name: str
    layer: str
    entity_start: int
    entity_count: int
    face_count: int
    wire_count: int
    boundary_edge_indices: tuple[int, ...]
    unused_vertex_indices: tuple[int, ...]


@dataclass(frozen=True)
class SceneExportResult:
    entities: tuple[Face3D | Line3D, ...]
    object_reports: tuple[ObjectExportInfo, ...]


@dataclass(frozen=True)
class SceneExportReceipt:
    path: Path
    prepared: SceneExportResult


def _number(value, location, error, kind):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise error(f'INVALID_{kind}_TYPE', location, actual_type=type(value).__name__)
    try:
        converted = float(value)
    except (OverflowError, ValueError) as exc:
        raise error(f'{kind}_OUT_OF_RANGE', location) from exc
    if not math.isfinite(converted):
        raise error(f'NONFINITE_{kind}', location)
    return converted


def _matrix(value, error):
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        raise error('INVALID_MATRIX_SHAPE', 'matrix_world', expected_shape=(4, 4))
    rows = []
    for row_index, row in enumerate(value):
        location = f'matrix_world[{row_index}]'
        if not isinstance(row, (list, tuple)) or len(row) != 4:
            raise error('INVALID_MATRIX_SHAPE', location, expected_size=4)
        rows.append(tuple(
            _number(component, f'{location}[{column}]', error, 'MATRIX_VALUE')
            for column, component in enumerate(row)
        ))
    result = tuple(rows)
    if result[3] != (0.0, 0.0, 0.0, 1.0):
        raise error('UNSUPPORTED_MATRIX_FORM', 'matrix_world[3]',
                    expected=(0, 0, 0, 1), actual=result[3])
    return result


def _world_vertices(vertices, matrix, error):
    if not isinstance(vertices, (list, tuple)):
        raise error('INVALID_CONTAINER', 'vertices', actual_type=type(vertices).__name__)
    transformed = []
    for index, raw in enumerate(vertices):
        location = f'vertices[{index}]'
        if not isinstance(raw, (list, tuple)):
            raise error('INVALID_CONTAINER', location, actual_type=type(raw).__name__)
        if len(raw) != 3:
            raise error('INVALID_COORDINATE_SIZE', location, size=len(raw))
        local = tuple(
            _number(component, f'{location}[{axis}]', error, 'COORDINATE')
            for axis, component in enumerate(raw)
        )
        world = []
        for axis in range(3):
            field = f'{location}[{axis}]'
            products = []
            for column in range(3):
                product = matrix[axis][column] * local[column]
                if not math.isfinite(product):
                    raise error('TRANSFORM_OUT_OF_RANGE', field, operation='multiply',
                                matrix_row=axis, matrix_column=column)
                products.append(product)
            try:
                coordinate = math.fsum((*products, matrix[axis][3]))
            except (OverflowError, ValueError) as exc:
                raise error('TRANSFORM_OUT_OF_RANGE', field, operation='sum', matrix_row=axis) from exc
            if not math.isfinite(coordinate):
                raise error('TRANSFORM_OUT_OF_RANGE', field, operation='sum', matrix_row=axis)
            world.append(coordinate)
        transformed.append(tuple(world))
    return tuple(transformed)


def scene_primitives(objects, mode):
    '''Yield one POINT per vertex or one LINE per edge of each prepared mesh.'''
    if mode not in {"POINTs", "LINEs"}:
        raise ValueError("unsupported primitive export mode")
    for index, obj in enumerate(objects):
        def error(code, location, **details):
            return SceneExportError(code, index, obj.name, location, **details)

        points = _world_vertices(obj.vertices, _matrix(obj.matrix_world, error), error)
        if mode == "POINTs":
            yield from (Point3D(point, obj.layer) for point in points)
        else:
            yield from (Line3D(points[start], points[end], obj.layer) for start, end in obj.edges)


def scene_polyfaces(objects_with_hidden_edges):
    """Emit indexed faces and keep edges outside of faces as LINE entities."""
    for index, (obj, hidden_edges) in enumerate(objects_with_hidden_edges):
        def error(code, location, **details):
            return SceneExportError(code, index, obj.name, location, **details)

        points = _world_vertices(obj.vertices, _matrix(obj.matrix_world, error), error)
        vertex_ids = sorted({corner for f in obj.faces for corner in f})
        if vertex_ids:
            # A DXF vertex reference is one-based, with its sign marking the outgoing edge.
            remap = {old: new for new, old in enumerate(vertex_ids, start=1)}
            face_indices = tuple(
                tuple(-remap[corner] if i in hidden else remap[corner] for i, corner in enumerate(face))
                for face, hidden in zip(obj.faces, hidden_edges, strict=True)
            )
            yield Polyface3D(tuple(points[i] for i in vertex_ids), face_indices, obj.layer)
        face_edges = {
            frozenset((start, end))
            for face in obj.faces
            for start, end in zip(face, face[1:] + face[:1])
        }
        for start, end in obj.edges:
            if frozenset((start, end)) not in face_edges:
                yield Line3D(points[start], points[end], obj.layer)


def scene_to_entities(objects) -> SceneExportResult:
    '''Prepare all objects without changing inputs or writing files.

    objects is a list/tuple of SceneMesh. Each matrix is row-major 4x4 and acts
    on the column vector (x, y, z, 1). Its last row must be exactly (0,0,0,1).
    All numbers must be finite int/float values, excluding bool. Unsupported
    projective/homogeneous forms and arithmetic overflow raise SceneExportError.

    Input order, local face-corner order and wire direction remain unchanged,
    including under negative scale. Reflection therefore changes world-space
    winding naturally; no corner reversal or normal correction is performed.
    Singular affine matrices are allowed; no geometric repair is attempted.
    Units are unchanged. Every object's local indices are resolved separately.

    Object names are diagnostic strings; empty or duplicate names are allowed.
    entity_start is zero-based in the combined output. Omitted edge and unused
    vertex indices remain local to their own object, as reported by mission 01.
    An error returns no partial SceneExportResult. Empty scenes are supported.
    '''
    if not isinstance(objects, (list, tuple)):
        raise SceneExportError('INVALID_SCENE_CONTAINER', None, None, 'objects',
                               actual_type=type(objects).__name__)
    entities, reports = [], []
    emitted_layers = {}
    for index, obj in enumerate(tuple(objects)):
        if not isinstance(obj, SceneMesh):
            raise SceneExportError('INVALID_SCENE_OBJECT', index, None, 'object',
                                   actual_type=type(obj).__name__)
        if not isinstance(obj.name, str):
            raise SceneExportError('INVALID_OBJECT_NAME', index, None, 'name',
                                   actual_type=type(obj.name).__name__)

        def error(code, location, **details):
            return SceneExportError(code, index, obj.name, location, **details)

        matrix = _matrix(obj.matrix_world, error)
        points = _world_vertices(obj.vertices, matrix, error)
        try:
            converted = mesh_to_entities(points, obj.faces, obj.edges, layer=obj.layer)
        except MeshExportError as exc:
            raise error(exc.code, exc.location, **exc.details) from exc
        if converted.entities:
            key = obj.layer.casefold()
            if key in emitted_layers and emitted_layers[key] != obj.layer:
                raise error('AMBIGUOUS_LAYER', 'layer', first_spelling=emitted_layers[key],
                            conflicting_spelling=obj.layer)
            emitted_layers[key] = obj.layer
        reports.append(ObjectExportInfo(
            index, obj.name, obj.layer, len(entities), len(converted.entities),
            converted.face_count, converted.wire_count,
            converted.boundary_edge_indices, converted.unused_vertex_indices,
        ))
        entities.extend(converted.entities)
    return SceneExportResult(tuple(entities), tuple(reports))


def export_scene_r12(path, objects, *, overwrite=False) -> SceneExportReceipt:
    '''Validate the entire scene, then call the independent writer exactly once.

    Invalid geometry/matrices in any object prevent every writer call, even with
    overwrite=True. Valid inputs use the supplied writer's existing publication
    and overwrite policy. Its file/path exceptions propagate unchanged. This
    function adds no Blender access or separate file-publication mechanism.
    '''
    prepared = scene_to_entities(objects)
    written = r12_writer.export_r12(path, prepared.entities, overwrite=overwrite)
    return SceneExportReceipt(written, prepared)
