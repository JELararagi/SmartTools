# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright 2026 JELararagi
"""Project world-space DXF entities onto the six orthographic view planes."""
from .r12_writer import Face3D, Line3D, Point3D, Polyface3D

# Each tuple selects a world axis and a sign for the screen-right and screen-up vectors.
VIEW_AXES = {
    "TOP": ((0, 1), (1, 1)),
    "BOTTOM": ((0, 1), (1, -1)),
    "FRONT": ((0, 1), (2, 1)),
    "REAR": ((0, -1), (2, 1)),
    "LEFT": ((1, -1), (2, 1)),
    "RIGHT": ((1, 1), (2, 1)),
}


def _covers_area(points):
    """Test whether any two sides from the first corner span the plane."""
    x, y, _ = points[0]
    vectors = [(px - x, py - y) for px, py, _ in points[1:]]
    return any(
        ax * by != ay * bx
        for index, (ax, ay) in enumerate(vectors)
        for bx, by in vectors[index + 1:]
    )


def project_entities(entities, view):
    """Yield XY-plane faces and wires without changing the source geometry."""
    (xi, sx), (yi, sy) = VIEW_AXES[view]

    def point(source):
        return sx * source[xi], sy * source[yi], 0.0

    for entity in entities:
        if isinstance(entity, Polyface3D):
            yield Polyface3D(tuple(map(point, entity.vertices)), entity.signed_indices, entity.layer)
            continue
        if isinstance(entity, Point3D):
            yield Point3D(point(entity.position), entity.layer)
            continue
        if isinstance(entity, Line3D):
            start, end = point(entity.start), point(entity.end)
            if start != end:
                yield Line3D(start, end, entity.layer)
            continue

        points = tuple(map(point, entity.vertices))
        if _covers_area(points):
            yield Face3D(points, entity.layer)
            continue

        # The visible outline of an edge-on face remains a wire, with no zero-length edges.
        first, last = min(points), max(points)
        if first != last:
            yield Line3D(first, last, entity.layer)