"""Original, standard-library-only AutoCAD R12 ASCII DXF subset writer.

Copyright (c) 2026 JELararagi. SPDX-License-Identifier: GPL-3.0-or-later

Supports LINE, POINT, 3DFACE and POLYFACE entities with WCS 3D coordinates and named layers.
This module is not a general-purpose DXF importer/exporter and has no Blender dependency.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
import os
from pathlib import Path
import re
import tempfile
from typing import Iterable

__all__ = ["Line3D", "Point3D", "Face3D", "Polyface3D", "export_r12"]

_LAYER_NAME = re.compile(r"[A-Za-z0-9_$-]{1,31}\Z", re.ASCII)


@dataclass(frozen=True)
class Line3D:
    start: tuple[float, float, float]
    end: tuple[float, float, float]
    layer: str = "0"


@dataclass(frozen=True)
class Point3D:
    position: tuple[float, float, float]
    layer: str = "0"


@dataclass(frozen=True)
class Face3D:
    vertices: tuple[tuple[float, float, float], ...]
    layer: str = "0"


@dataclass(frozen=True)
class Polyface3D:
    vertices: tuple[tuple[float, float, float], ...]
    signed_indices: tuple[tuple[int, ...], ...]
    layer: str = "0"


def _point(point: object, description: str) -> tuple[float, float, float]:
    if not isinstance(point, (tuple, list)) or len(point) != 3:
        raise ValueError(f"{description}: exactly three numeric coordinates required")
    result = []
    for value in point:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"{description}: coordinates must be real numbers")
        try:
            converted = float(value)
        except (OverflowError, ValueError) as exc:
            raise ValueError(f"{description}: invalid numeric coordinate") from exc
        if not math.isfinite(converted):
            raise ValueError(f"{description}: NaN and infinity are prohibited")
        result.append(converted)
    return tuple(result)


def _layer(value: object) -> str:
    if not isinstance(value, str) or _LAYER_NAME.fullmatch(value) is None:
        raise ValueError("layer must be 1-31 ASCII letters/digits/$/_/- characters")
    return value


def _validate(entities: Iterable[Line3D | Point3D | Face3D | Polyface3D]):
    if isinstance(entities, (str, bytes)):
        raise TypeError("entities must be an iterable of DXF entities")
    validated = []
    layers = {"0": "0"}
    for number, entity in enumerate(entities):
        if not isinstance(entity, (Line3D, Point3D, Face3D, Polyface3D)):
            raise TypeError(f"entity {number}: unsupported entity class")
        layer = _layer(getattr(entity, "layer", None))
        key = layer.casefold()
        if key in layers and layers[key] != layer:
            raise ValueError(f"entity {number}: ambiguous layer spelling: {layer}")
        layers[key] = layer
        if isinstance(entity, Line3D):
            validated.append(("LINE", layer, (_point(entity.start, "start"), _point(entity.end, "end"))))
        elif isinstance(entity, Point3D):
            validated.append(("POINT", layer, (_point(entity.position, "position"),)))
        elif isinstance(entity, Polyface3D):
            points = tuple(_point(v, "mesh vertex") for v in entity.vertices)
            if not 3 <= len(points) <= 32767 or not 1 <= len(entity.signed_indices) <= 32767:
                raise ValueError(f"entity {number}: POLYFACE counts exceed the DXF range")
            faces = []
            for face in entity.signed_indices:
                if len(face) not in (3, 4) or any(type(i) is not int or not 1 <= abs(i) <= len(points) for i in face):
                    raise ValueError(f"entity {number}: invalid POLYFACE corner reference")
                faces.append(tuple(face) + (0,) * (4 - len(face)))
            validated.append(("POLYLINE", layer, (points, faces)))
        else:
            if not isinstance(entity.vertices, (tuple, list)) or len(entity.vertices) not in (3, 4):
                raise ValueError(f"entity {number}: 3DFACE needs exactly three or four vertices")
            points = tuple(_point(v, f"face vertex {i}") for i, v in enumerate(entity.vertices))
            if len(points) == 3:
                points += (points[2],)  # Autodesk 3DFACE: fourth corner repeats third for triangles.
            validated.append(("3DFACE", layer, points))
    return validated, ["0"] + sorted((name for key, name in layers.items() if key != "0"), key=str.casefold)


# Simple repeating marks in drawing units. Zero represents a dot.
LINE_PATTERNS = {
    "CONTINUOUS": (),
    "DOT": (0, -0.25),
    "DASHED": (0.5, -0.25),
    "DASHDOT": (0.5, -0.25, 0, -0.25),
    "BORDER": (0.5, -0.25, 0.5, -0.25, 0, -0.25),
    "HIDDEN": (0.25, -0.125),
}
INHERITED_LINE_TYPES = {"BYLAYER", "BYBLOCK"}


def _payload(validated, layers, colors, linetype) -> bytes:
    lines = []

    def pair(code: int, value: object) -> None:
        lines.append(f"{code}\r\n{value}\r\n")

    def point(index: int, values) -> None:
        for code, value in zip((10 + index, 20 + index, 30 + index), values):
            pair(code, format(value, ".17g"))

    pair(0, "SECTION")
    pair(2, "HEADER")
    pair(9, "$ACADVER")
    pair(1, "AC1009")
    pair(0, "ENDSEC")
    pair(0, "SECTION")
    pair(2, "TABLES")
    pair(0, "TABLE")
    pair(2, "LTYPE")
    table_types = ["CONTINUOUS"]
    if linetype in LINE_PATTERNS and linetype != "CONTINUOUS":
        table_types.append(linetype)
    pair(70, len(table_types))
    for name in table_types:
        marks = LINE_PATTERNS[name]
        pair(0, "LTYPE")
        pair(2, name)
        pair(70, 0)
        pair(3, "Solid line" if name == "CONTINUOUS" else name)
        pair(72, 65)
        pair(73, len(marks))
        pair(40, sum(abs(mark) for mark in marks))
        for mark in marks:
            pair(49, mark)
    pair(0, "ENDTAB")
    pair(0, "TABLE")
    pair(2, "LAYER")
    pair(70, len(layers))
    for layer in layers:
        pair(0, "LAYER")
        pair(2, layer)
        pair(70, 0)
        pair(62, 7)
        pair(6, "CONTINUOUS")
    pair(0, "ENDTAB")
    pair(0, "ENDSEC")
    pair(0, "SECTION")
    pair(2, "BLOCKS")
    pair(0, "ENDSEC")
    pair(0, "SECTION")
    pair(2, "ENTITIES")
    for (kind, layer, points), color in zip(validated, colors, strict=True):
        pair(0, kind)
        pair(8, layer)
        if color != 256:
            pair(62, color)
        if linetype not in {"BYLAYER", "CONTINUOUS"}:
            pair(6, linetype)
        if kind == "POLYLINE":
            coordinates, faces = points
            pair(66, 1)
            point(0, (0, 0, 0))
            pair(70, 64)
            pair(71, len(coordinates))
            pair(72, len(faces))
            for coordinates_at_vertex in coordinates:
                pair(0, "VERTEX")
                pair(8, layer)
                point(0, coordinates_at_vertex)
                pair(70, 192)
            for corners in faces:
                pair(0, "VERTEX")
                pair(8, layer)
                point(0, (0, 0, 0))
                pair(70, 128)
                for code, vertex_index in enumerate(corners, start=71):
                    pair(code, vertex_index)
            pair(0, "SEQEND")
            pair(8, layer)
        else:
            for index, values in enumerate(points):
                point(index, values)
    pair(0, "ENDSEC")
    pair(0, "EOF")
    return "".join(lines).encode("ascii")


def export_r12(
    path: str | os.PathLike[str],
    entities: Iterable[Line3D | Point3D | Face3D | Polyface3D],
    *,
    overwrite: bool = False,
    color: int = 256,
    linetype: str = "BYLAYER",
    entity_colors: Iterable[int] | None = None,
) -> Path:
    """Write an R12 ASCII DXF atomically, or raise without modifying the destination.

    * An existing destination is rejected unless ``overwrite=True``.
    * When overwriting, ``os.replace`` publishes a fully written temporary file.
    * New-file publication uses an atomic hardlink to avoid replacement races;
      filesystems that disallow hardlinks cause a clean failure instead.
    """
    validated, layers = _validate(entities)  # No filesystem changes until all inputs pass.
    if type(color) is not int or not 0 <= color <= 256:
        raise ValueError("color must be an AutoCAD color index from 0 to 256")
    if linetype not in {*LINE_PATTERNS, *INHERITED_LINE_TYPES}:
        raise ValueError("unsupported DXF linetype")
    colors = [color] * len(validated) if entity_colors is None else list(entity_colors)
    if len(colors) != len(validated) or any(type(item) is not int or not 0 <= item <= 256 for item in colors):
        raise ValueError("entity_colors must contain one valid DXF color index for each entity")
    content = _payload(validated, layers, colors, linetype)
    target = Path(path)
    if target.suffix.lower() != ".dxf":
        raise ValueError("target filename must end in .dxf")
    if target.is_symlink() or (target.exists() and not overwrite):
        raise FileExistsError(f"destination already exists: {target}")
    descriptor, temporary = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=target.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        if overwrite:
            os.replace(temporary, target)
        else:
            os.link(temporary, target)  # Atomic no-clobber for supported local filesystems.
        return target
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
