# Copyright (c) 2026 JELararagi. SPDX-License-Identifier: GPL-3.0-or-later
"""SmartFile's Blender adapter for its independently implemented R12 mesh writer."""
import re
from pathlib import Path

from .orthographic import project_entities
from .r12_writer import export_r12
from .scene_export import SceneMesh, scene_polyfaces, scene_primitives, scene_to_entities

_DXF_LAYER_NAME = re.compile(r"[A-Za-z0-9_$-]{1,31}")
_INHERITED_COLORS = {"default_COLOR": 256, "BYLAYER": 256, "BYBLOCK": 0}


def _entity_layer(obj, source, default_layer):
    if source == "obj.name":
        return obj.name
    if source == "obj.data.name":
        return obj.data.name
    if source in {"obj.layer", "..group"} and obj.users_collection:
        return obj.users_collection[0].name
    if source == "obj.material" and obj.material_slots:
        material = obj.material_slots[0].material
        if material is not None:
            return material.name
    return default_layer


def _display_component(value):
    value = min(1.0, max(0.0, value))
    converted = 12.92 * value if value <= 0.0031308 else 1.055 * value ** (1 / 2.4) - 0.055
    return round(255 * converted)


def _nearest_color(color):
    from ...dxf_import.dxfgrabber.color import aci_to_true_color

    rgb = tuple(_display_component(component) for component in color[:3])
    return min(range(1, 256), key=lambda index: sum(
        (channel - reference) ** 2
        for channel, reference in zip(rgb, aci_to_true_color(index).rgb(), strict=True)
    ))


def _entity_color(obj, source, collection_colors):
    if source in _INHERITED_COLORS:
        return _INHERITED_COLORS[source]
    if source == "obj.layer":
        return collection_colors[obj.users_collection[0].name] if obj.users_collection else 256
    if source == "obj.color":
        return _nearest_color(obj.color)
    if obj.material_slots:
        material = obj.material_slots[0].material
        if material is not None:
            return _nearest_color(material.diffuse_color)
    return 256


def _unique_layer_names(raw_names):
    # Keep already valid names available even if an earlier name normalizes to one.
    reserved = {name.upper() for name in raw_names if _DXF_LAYER_NAME.fullmatch(name)}
    occupied = set()
    names = {}
    for raw in dict.fromkeys(raw_names):
        if _DXF_LAYER_NAME.fullmatch(raw) and raw.upper() not in occupied:
            alias = raw
        else:
            stem = re.sub(r"[^A-Za-z0-9_$-]+", "_", raw) or "Layer"
            alias = stem[:31]
            suffix_number = 2
            while alias.upper() in reserved or alias.upper() in occupied:
                suffix = f"_{suffix_number}"
                alias = stem[:31 - len(suffix)] + suffix
                suffix_number += 1
        occupied.add(alias.upper())
        names[raw] = alias
    return names


def _mesh_input(obj, mesh, matrix, layer, include_faces):
    faces = []
    hidden_edges = []
    if include_faces:
        triangles = {}
        if any(len(p.vertices) > 4 for p in mesh.polygons):
            mesh.calc_loop_triangles()
            for item in mesh.loop_triangles:
                triangles.setdefault(item.polygon_index, []).append(tuple(item.vertices))
        for polygon in mesh.polygons:
            boundary = tuple(polygon.vertices)
            if len(boundary) <= 4:
                faces.append(boundary)
                hidden_edges.append(set())
                continue
            edges = {frozenset((a, b)) for a, b in zip(boundary, boundary[1:] + boundary[:1])}
            for triangle in triangles[polygon.index]:
                faces.append(triangle)
                hidden_edges.append({
                    i for i, (a, b) in enumerate(zip(triangle, triangle[1:] + triangle[:1]))
                    if frozenset((a, b)) not in edges
                })
    shape = SceneMesh(
        obj.name, [tuple(v.co) for v in mesh.vertices], faces,
        [tuple(e.vertices) for e in mesh.edges], tuple(tuple(row) for row in matrix), layer,
    )
    return shape, hidden_edges


def export_mesh(operator, context, path):
    """Read Blender mesh geometry and write the selected representation as R12 entities."""
    source = context.selected_objects if operator.onlySelected else context.scene.objects
    objects = [obj for obj in source if obj.type == "MESH" and not obj.hide_viewport]
    if not objects:
        raise ValueError("No mesh objects to export")

    default_layer = {
        "LAYERNAME_DEF": "0", "drawing_name": Path(path).stem, "scene_name": context.scene.name,
    }[operator.layerName_from]
    layer_sources = [_entity_layer(obj, operator.entitylayer_from, default_layer) for obj in objects]
    layers = _unique_layer_names(layer_sources)
    collections = sorted({col.name for obj in objects for col in obj.users_collection})
    collection_colors = {name: 1 + index % 255 for index, name in enumerate(collections)}

    graph = context.evaluated_depsgraph_get()
    mode = operator.mesh_as
    polyface = mode in {"POLYFACE", "POLYLINE"}
    include_faces = mode == "3DFACEs" or polyface
    view = operator.projectionThrough
    entities = []
    colors = []
    for obj, raw_layer in zip(objects, layer_sources, strict=True):
        if obj.mode == "EDIT":
            obj.update_from_editmode()
        evaluated = obj.evaluated_get(graph)
        if operator.apply_modifiers:
            mesh = evaluated.to_mesh()
            try:
                shape, hidden = _mesh_input(obj, mesh, evaluated.matrix_world, layers[raw_layer], include_faces)
            finally:
                evaluated.to_mesh_clear()
        else:
            shape, hidden = _mesh_input(obj, obj.data, evaluated.matrix_world, layers[raw_layer], include_faces)

        if polyface:
            emitted = scene_polyfaces([(shape, hidden)])
        elif include_faces:
            emitted = scene_to_entities([shape]).entities
        else:
            emitted = scene_primitives([shape], mode)
        emitted = list(project_entities(emitted, view) if view != "NO" else emitted)
        if emitted:
            color = _entity_color(obj, operator.entitycolor_from, collection_colors)
            entities.extend(emitted)
            colors.extend([color] * len(emitted))
        if operator.verbose:
            print(f"SmartFile DXF: {obj.name}: {len(emitted)} entities")

    if not entities:
        raise ValueError("No DXF entities were generated from the selected mesh objects")
    linetype = operator.entityltype_from
    if linetype == "default_LTYPE":
        linetype = "BYLAYER"
    export_r12(path, entities, overwrite=True, entity_colors=colors, linetype=linetype)
