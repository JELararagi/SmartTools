# SPDX-License-Identifier: GPL-3.0-or-later
"""Read typed header fields from the DXF stream."""

class HeaderSection(dict):
    name = "header"

    def __init__(self):
        super().__init__({"$ACADVER": "AC1009", "$DWGCODEPAGE": "ANSI_1252"})

    @classmethod
    def from_tags(cls, tags):
        header = cls()
        if len(tags) > 1 and tags[1] == (2, "HEADER"):
            header._build(tags)
        return header

    def _build(self, tags):
        key = None
        for code, value in tags[2:-1]:
            if code == 9:
                key = value
            elif key is not None:
                self[key] = value
                key = None
