# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Read the ASCII SAT records carried in DXF modeler geometry."""

import re

# A caret and the following byte occupy one logical character. The final
# caret in a record also denotes that character.
_TOKENS = re.compile(rb"\^[\x00-\x7f]?|[\x00-\x7f]")
_RESERVED = {" ": " ", "@": "_", "_": "@"}


def _symbol(value):
    source = chr(value)
    if "A" <= source <= "^":
        return chr(ord("A") + ord("^") - value)
    return _RESERVED.get(source, chr(value ^ 0x5F))


_ALPHABET = tuple(_symbol(value) for value in range(128))


def decode(text_lines):
    return [
        "".join(_ALPHABET[token[0]] for token in _TOKENS.findall(line.encode("ascii")))
        for line in text_lines
    ]
