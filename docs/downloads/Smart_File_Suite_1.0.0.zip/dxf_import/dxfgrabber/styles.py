# SPDX-License-Identifier: GPL-3.0-or-later
"""Decode text style metadata, preserving independent rotation and generation flags."""

from .layers import Table
from .tags import DXFTag, Tags


class Style:
    def __init__(self, tags):
        fields = dict(tags.plain_tags())
        self.name = fields.get(2, "")
        self.flags = fields.get(70, 0)
        self.height = fields.get(40, 1.0)
        self.width = fields.get(41, 1.0)
        self.oblique = fields.get(50, 0.0)
        generation = fields.get(71, 0)
        self.is_backwards = bool(generation & 2)
        self.is_upside_down = bool(generation & 4)
        self.font = fields.get(3, "")
        self.big_font = fields.get(4, "")


class StyleTable(Table):
    name = "styles"
    record_type = "STYLE"
    entry_type = Style


default_text_style = Style(Tags([
    DXFTag(0, "STYLE"),
    DXFTag(2, "STANDARD"),
    DXFTag(40, 0.0),
    DXFTag(3, "Arial"),
]))
