# SPDX-License-Identifier: GPL-3.0-or-later
"""Decode the layer, line pattern and text style tables used by import."""

from ..dxf_records import records
from .layers import LayerTable
from .linetypes import LinetypeTable
from .styles import StyleTable
from .tags import Tags


TABLESMAP = {"LAYER": LayerTable, "LTYPE": LinetypeTable, "STYLE": StyleTable}
_ALIASES = {"ltype": "linetypes", "vport": "viewports", "ucs": "ucs"}


def tablename(dxfname):
    name = dxfname.lower()
    return _ALIASES.get(name, name + "s")


class DefaultDrawing:
    dxfversion = "AC1009"
    encoding = "cp1252"


class TablesSection:
    name = "tables"

    def __init__(self):
        self._tables = {parser.name: parser() for parser in TABLESMAP.values()}

    @classmethod
    def from_tags(cls, tags, drawing):
        section = cls()
        for table in records(iter(tags[2:]), until="ENDSEC", closing="ENDTAB", collect=Tags):
            if table[0] == (0, "TABLE") and table[1].code == 2:
                parser = table_factory(table[1].value)
                if parser is not None:
                    section._tables[parser.name] = parser.from_tags(table)
        return section

    def __getattr__(self, key):
        if key in self._tables:
            return self._tables[key]
        raise AttributeError(key)


def table_factory(name):
    return TABLESMAP.get(name)
