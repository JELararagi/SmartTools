# SPDX-License-Identifier: GPL-3.0-or-later
"""Dispatch complete named DXF sections to the associated record readers."""

from ..dxf_records import RawSection, drawing_encoding, legacy_encoding, records
from .acdsdata import AcDsDataSection
from .blockssection import BlocksSection
from .entitysection import EntitySection, ObjectsSection
from .headersection import HeaderSection
from .tablessection import TablesSection
from .tags import Tags

SECTIONMAP = {
    "TABLES": TablesSection, "ENTITIES": EntitySection, "OBJECTS": ObjectsSection,
    "BLOCKS": BlocksSection, "ACDSDATA": AcDsDataSection,
}


class Sections:
    def __init__(self, tagreader, drawing):
        self._sections = {reader.name: reader() for reader in SECTIONMAP.values()}
        self._sections[HeaderSection.name] = HeaderSection()
        for record in records(tagreader, until="EOF", closing="ENDSEC", collect=Tags):
            if record[0] != (0, "SECTION") or record[1].code != 2:
                raise ValueError("Missing DXF section name")
            name = record[1].value
            if name == "HEADER":
                header = HeaderSection.from_tags(record)
                drawing.dxfversion = header["$ACADVER"]
                drawing.encoding = drawing_encoding(drawing.dxfversion,
                                                    legacy_encoding(header["$DWGCODEPAGE"]))
                self._sections[header.name] = header
            elif name in SECTIONMAP:
                parser = SECTIONMAP[name]
                self._sections[parser.name] = parser.from_tags(record, drawing)

    def __contains__(self, key):
        return key in self._sections

    def __getattr__(self, key):
        try:
            return self._sections[key]
        except KeyError:
            raise AttributeError(key) from None


def get_section_class(name):
    return SECTIONMAP.get(name, RawSection)
