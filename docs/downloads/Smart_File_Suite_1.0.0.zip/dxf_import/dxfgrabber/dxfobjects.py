# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Decode DXF objects, including Sun lighting and shadow settings."""

from datetime import datetime

from ..dxf_records import calendar_date


class DXFObject:
    _metadata = {5: "handle", 330: "owner"}

    def __init__(self):
        self.dxftype = "ENTITY"
        self.handle = self.owner = None

    def setup_attributes(self, tags):
        self.dxftype = tags.get_type()
        for group, value in tags.plain_tags():
            name = self._metadata.get(group)
            if name is None:
                yield group, value
            else:
                setattr(self, name, value)


def unpack_seconds(milliseconds):
    minutes, seconds = divmod(int(milliseconds / 1000), 60)
    hours, minutes = divmod(minutes, 60)
    return hours, minutes, seconds


class Sun(DXFObject):
    # Group assignments follow the Autodesk SUN records. The importer
    # retains its existing millisecond interpretation of the time value.
    _numbers = {
        40: "intensity", 63: "sun_color", 70: "shadow_type",
        71: "shadow_map_size", 90: "version", 280: "shadow_softness",
    }
    _switches = {290: "status", 291: "shadows", 292: "daylight_savings_time"}

    def __init__(self):
        super().__init__()
        self.version = 1
        self.status = self.shadows = self.daylight_savings_time = False
        self.sun_color = None
        self.intensity = self.shadow_softness = 0.0
        self.shadow_type = self.shadow_map_size = 0
        self.date = datetime.now()

    def setup_attributes(self, tags):
        when = dict.fromkeys((91, 92), 0)
        for group, value in super().setup_attributes(tags):
            if group in when:
                when[group] = value
            elif group in self._numbers:
                setattr(self, self._numbers[group], value)
            elif group in self._switches:
                setattr(self, self._switches[group], bool(value))
            else:
                yield group, value

        date = calendar_date(when[91]) if when[91] > 0 else datetime.now()
        self.date = datetime(date.year, date.month, date.day, *unpack_seconds(when[92]))


ObjectsTable = {"SUN": Sun}


def objects_factory(tags):
    obj = ObjectsTable.get(tags.get_type(), DXFObject)()
    for _ in obj.setup_attributes(tags):
        pass
    return obj
