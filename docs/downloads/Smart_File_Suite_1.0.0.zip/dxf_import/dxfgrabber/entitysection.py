# SPDX-License-Identifier: GPL-3.0-or-later
"""Read DXF entities, assembling records terminated by SEQEND."""

from .dxfentities import entity_factory
from .tags import DXFStructureError, TagGroups, Tags


class EntitySection:
    name = "entities"

    def __init__(self):
        self._entities = []

    @classmethod
    def from_tags(cls, tags, drawing):
        section = cls()
        section._entities = build_entities(TagGroups(iter(tags[2:-1])))
        return section

    def get_entities(self):
        return self._entities

    def __getitem__(self, index):
        return self._entities[index]

    def __len__(self):
        return len(self._entities)

    def __iter__(self):
        return iter(self._entities)


class ObjectsSection(EntitySection):
    name = "objects"


def build_entities(tag_groups):
    result = []
    parent = None
    children = []
    for group in tag_groups:
        try:
            record = entity_factory(Tags(group))
        except KeyError:
            continue
        if record.dxftype == "SEQEND" and parent is not None:
            parent.append_data(children)
            cast = getattr(parent, "cast", None)
            result.append(cast() if cast is not None else parent)
            parent, children = None, []
        elif parent is not None:
            children.append(record)
        elif record.dxftype in {"POLYLINE", "POLYFACE", "POLYMESH"} or (
            record.dxftype == "INSERT" and record.attribsfollow
        ):
            parent = record
        else:
            result.append(record)
    return result
