# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""DXF pair reader and grouping for Smart File's importer.

Type ranges follow the Autodesk DXF reference. The reader keeps the historical
Smart File conventions for R12 extensions and 2D coordinates.
"""

from collections import namedtuple
from io import StringIO

from ..dxf_records import legacy_encoding
from .const import acadrelease


DXFTag = namedtuple("DXFTag", ("code", "value"))
NONE_TAG = DXFTag(999999, "NONE")
APP_DATA_MARKER, SUBCLASS_MARKER, XDATA_MARKER = 102, 100, 1001
POINT_CODES = frozenset((*range(10, 20), *range(110, 113), 210, *range(1010, 1020)))
infinite, neg_infinite = float("inf"), float("-inf")


class DXFStructureError(Exception):
    pass


def point_tuple(components):
    return tuple(map(float, components))


def is_point_tag(tag):
    return tag[0] in POINT_CODES


def to_float_with_infinite(value):
    try:
        return float(value)
    except ValueError:
        text = value.strip().lower()
        for prefix, number in (("inf", infinite), ("-inf", neg_infinite)):
            if text.startswith(prefix):
                return number
        raise


_FLOAT_RANGES = ((20, 59), (113, 149), (211, 239), (460, 469), (1020, 1059))
_INTEGER_RANGES = ((60, 99), (170, 179), (270, 299), (370, 389), (400, 409),
                   (420, 429), (440, 459), (1060, 1071))
TYPES = [
    (point_tuple, POINT_CODES),
    *((to_float_with_infinite, range(start, end + 1)) for start, end in _FLOAT_RANGES),
    *((int, range(start, end + 1)) for start, end in _INTEGER_RANGES),
]


class TagCaster:
    def __init__(self):
        self._cast = self._build()

    def _build(self):
        return {code: fn for fn, codes in TYPES for code in codes}

    def cast(self, pair):
        code, value = pair
        return DXFTag(code, self.cast_value(code, value))

    def cast_value(self, code, value):
        convert = self._cast.get(code, str)
        try:
            return convert(value)
        except ValueError:
            if convert is not int:
                raise
            return int(float(value))


_TagCaster = TagCaster()
cast_tag = _TagCaster.cast
cast_tag_value = _TagCaster.cast_value


def _line_pairs(stream):
    for line_number, (code, value) in enumerate(zip(stream, stream), 1):
        yield 2 * line_number, DXFTag(int(code), value.rstrip("\r\n"))


def stream_tagger(stream, assure_3d_coords=False):
    pairs = iter(_line_pairs(iter(stream.readline, "")))
    buffered = None
    while True:
        item = buffered if buffered is not None else next(pairs, None)
        buffered = None
        if item is None:
            return
        line, part = item
        code, value = part
        if code == 999:
            continue
        if code not in POINT_CODES:
            try:
                yield cast_tag(part)
            except ValueError:
                raise DXFStructureError(f'Invalid tag (code={code}, value="{value}") near line: {line}.') from None
            continue
        ordinate = next(pairs, None)
        if ordinate is None:
            return
        line, y = ordinate
        if y.code != code + 10:
            raise DXFStructureError(f"Missing required y coordinate near line: {line}.")
        tail = next(pairs, None)
        if tail is None:
            return
        line, z = tail
        position = [value, y.value]
        if z.code == code + 20:
            position.append(z.value)
        else:
            buffered = tail
            if assure_3d_coords:
                position.append(0.0)
        try:
            point = point_tuple(position)
        except ValueError:
            raise DXFStructureError(f"Invalid floating point values near line: {line}.") from None
        yield DXFTag(code, point)


def string_tagger(text):
    return stream_tagger(StringIO(text))


class Tags(list):
    def find_all(self, code):
        return [tag for tag in self if tag.code == code]

    def tag_index(self, code, start=0, end=None):
        for index in range(start, len(self) if end is None else end):
            if self[index].code == code:
                return index
        raise ValueError(code)

    def get_value(self, code):
        return self[self.tag_index(code)].value

    @staticmethod
    def from_text(text):
        return Tags(string_tagger(text))

    def get_type(self):
        return self[0].value

    def plain_tags(self):
        outside = True
        for tag in self:
            if tag.code == APP_DATA_MARKER:
                outside = not outside
            elif outside and tag.code < 1000:
                yield tag

    def xdata(self):
        for index, tag in enumerate(self):
            if tag.code >= 1000:
                return self[index:]
        return []

    def app_data(self):
        groups = {}
        active = None
        for tag in self:
            if tag.code == APP_DATA_MARKER and tag.value != "}":
                active = [tag]
            elif tag.code == APP_DATA_MARKER:
                active.append(tag)
                groups[active[0].value] = active
                active = None
            elif active is not None:
                active.append(tag)
        return groups

    def subclasses(self):
        result = {}
        key, fields = "noname", []
        for tag in self.plain_tags():
            if tag.code == SUBCLASS_MARKER:
                result[key] = fields
                key, fields = tag.value, []
            else:
                fields.append(tag)
        result[key] = fields
        return result

    def get_subclass(self, name):
        return self.subclasses().get(name, "noname")


class TagGroups(list):
    def __init__(self, tags, split_code=0):
        super().__init__()
        self._build_groups(tags, split_code)

    def _build_groups(self, tags, splitcode):
        active = None
        for tag in tags:
            if tag.code == splitcode:
                active = Tags()
                self.append(active)
            if active is not None:
                active.append(tag)

    def get_name(self, index):
        return self[index].get_type()

    @staticmethod
    def from_text(text, split_code=0):
        return TagGroups(string_tagger(text), split_code)


class ClassifiedTags:
    def __init__(self, iterable=None):
        self.subclasses, self.appdata, self.xdata = [], [], []
        if iterable is not None:
            self._setup(iterable)

    @property
    def noclass(self):
        return self.subclasses[0]

    def _setup(self, iterable):
        active = Tags()
        self.subclasses.append(active)
        app = None
        in_extension = False
        for part in iterable:
            code, value = part
            if app is not None:
                app.append(part)
                if code == APP_DATA_MARKER:
                    app = None
            elif code == XDATA_MARKER:
                active = Tags([part])
                self.xdata.append(active)
                in_extension = True
            elif in_extension:
                active.append(part)
            elif code == SUBCLASS_MARKER:
                active = Tags([part])
                self.subclasses.append(active)
            elif code == APP_DATA_MARKER and value.startswith("{"):
                active.append(DXFTag(APP_DATA_MARKER, len(self.appdata)))
                app = Tags([part])
                self.appdata.append(app)
            else:
                active.append(part)
        if app is not None:
            raise DXFStructureError("Missing closing DXFTag(102, '}') for appdata structure.")

    def __iter__(self):
        for fields in self.subclasses:
            for part in fields:
                if part.code == APP_DATA_MARKER and isinstance(part.value, int):
                    yield from self.appdata[part.value]
                else:
                    yield part
        for fields in self.xdata:
            yield from fields

    def get_subclass(self, name):
        for fields in self.subclasses:
            if fields and fields[0].value == name:
                return fields
        raise KeyError(f"Subclass '{name}' does not exist.")

    def get_xdata(self, appid):
        for fields in self.xdata:
            if fields[0].value == appid:
                return fields
        raise ValueError(f"No extended data for APPID '{appid}'")

    def get_appdata(self, name):
        for fields in self.appdata:
            if fields[0].value == name:
                return fields
        raise ValueError(f"Application defined group '{name}' does not exist.")

    def get_type(self):
        return self.noclass.get_type()

    @staticmethod
    def from_text(text):
        return ClassifiedTags(string_tagger(text))


class DXFInfo:
    def __init__(self):
        self.release, self.version = "R12", "AC1009"
        self.encoding, self.handseed = "cp1252", "0"

    def DWGCODEPAGE(self, value):
        self.encoding = legacy_encoding(value)

    def ACADVER(self, value):
        self.version = value
        self.release = acadrelease.get(value, "R12")

    def HANDSEED(self, value):
        self.handseed = value


def dxfinfo(stream):
    result = DXFInfo()
    fields = {"$ACADVER": result.ACADVER, "$DWGCODEPAGE": result.DWGCODEPAGE, "$HANDSEED": result.HANDSEED}
    records = stream_tagger(stream)
    while (part := next(records)) != (0, "ENDSEC"):
        if part.code == 9 and part.value in fields:
            fields[part.value](next(records).value)
    return result


def binary_encoded_data_to_bytes(data):
    result = bytearray()
    for chunk in data:
        for offset in range(0, len(chunk), 2):
            result.append(int(chunk[offset:offset + 2], 16))
    return bytes(result)
