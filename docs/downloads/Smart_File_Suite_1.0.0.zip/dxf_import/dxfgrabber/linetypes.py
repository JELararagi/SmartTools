# SPDX-License-Identifier: GPL-3.0-or-later
"""Linetype descriptions and signed dash, gap and dot lengths."""

from .layers import Table


class Linetype:
    def __init__(self, tags):
        fields = list(tags.plain_tags())
        lookup = dict(fields)
        self.name = lookup.get(2, "")
        self.description = lookup.get(3, "")
        self.length = lookup.get(40, 0)
        self.pattern = [value for code, value in fields if code == 49]


class LinetypeTable(Table):
    name = "linetypes"
    record_type = "LTYPE"
    entry_type = Linetype
