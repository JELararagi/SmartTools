# SPDX-License-Identifier: GPL-3.0-or-later
"""Layer metadata and named symbol tables for ASCII DXF."""

from .tags import Tags

LOCK = 4
FROZEN = 1


class Layer:
    def __init__(self, tags):
        fields = dict(tags.plain_tags())
        self.name = fields.get(2, "")
        self.linetype = fields.get(6, "")
        color = fields.get(62, 7)
        self.color = abs(color)
        self.on = color >= 0
        flags = fields.get(70, 0)
        self.locked = bool(flags & LOCK)
        self.frozen = bool(flags & FROZEN)


class Table:
    """A named collection in declaration order."""

    record_type = None
    entry_type = None

    def __init__(self):
        self._table_entries = {}

    def __getitem__(self, name):
        return self._table_entries[name]

    def get(self, name, default=KeyError):
        if default is KeyError:
            return self[name]
        return self._table_entries.get(name, default)

    def __contains__(self, name):
        return name in self._table_entries

    def __iter__(self):
        return iter(self._table_entries.values())

    def __len__(self):
        return len(self._table_entries)

    def names(self):
        return sorted(self._table_entries)

    def entry_tags(self, tags):
        if not tags or tags[0] != (0, "TABLE") or tags[-1] != (0, "ENDTAB"):
            raise ValueError("Expected a complete DXF symbol table")
        record = []
        for tag in tags[1:]:
            if tag.code == 0:
                if record:
                    yield Tags(record)
                record = []
                if tag.value == "ENDTAB":
                    return
            if record or tag.code == 0:
                record.append(tag)

    @classmethod
    def from_tags(cls, tags):
        table = cls()
        for record in table.entry_tags(tags):
            if record[0].value == cls.record_type:
                entry = cls.entry_type(record)
                table._table_entries[entry.name] = entry
        return table


class LayerTable(Table):
    name = "layers"
    record_type = "LAYER"
    entry_type = Layer
