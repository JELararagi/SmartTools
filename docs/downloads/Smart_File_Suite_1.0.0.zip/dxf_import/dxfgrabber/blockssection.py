# SPDX-License-Identifier: GPL-3.0-or-later
"""Collect named DXF definitions and the entities inside each block."""

from .entitysection import build_entities
from .tags import TagGroups


class BlocksSection:
    name = "blocks"

    def __init__(self):
        self._blocks = {}

    @classmethod
    def from_tags(cls, tags, drawing):
        section = cls()
        if drawing.grab_blocks:
            section._build(tags)
        return section

    def _build(self, tags):
        if len(tags) < 4:
            return
        current = []
        for group in TagGroups(iter(tags[2:-1])):
            kind = group[0].value
            if kind == "BLOCK":
                current = [group]
            elif current and kind == "ENDBLK":
                block, *contents = build_entities([*current, group])
                block.set_entities(contents[:-1])
                self._blocks[block.name] = block
                current = []
            elif current:
                current.append(group)

    def __len__(self):
        return len(self._blocks)

    def __iter__(self):
        return iter(self._blocks.values())

    def __contains__(self, name):
        return name in self._blocks

    def __getitem__(self, name):
        return self._blocks[name]

    def get(self, name, default=None):
        return self._blocks.get(name, default)
