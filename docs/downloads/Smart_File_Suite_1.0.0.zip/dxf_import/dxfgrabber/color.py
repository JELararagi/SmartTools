# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Encode 24-bit DXF colors and construct Smart File's historical ACI palette."""


class TrueColor(int):
    def rgb(self):
        return tuple((self >> shift) & 0xFF for shift in (16, 8, 0))

    @property
    def r(self):
        return self.rgb()[0]

    @property
    def g(self):
        return self.rgb()[1]

    @property
    def b(self):
        return self.rgb()[2]

    def __getitem__(self, item):
        for index, channel in enumerate(self.rgb()):
            if item == index:
                return channel
        raise IndexError(item)

    @staticmethod
    def from_rgb(r, g, b):
        return TrueColor(sum((component & 255) << shift
                             for component, shift in zip((r, g, b), (16, 8, 0))))

    @staticmethod
    def from_aci(index):
        if index < 1:
            raise IndexError(index)
        return dxf_default_colors[index]


def aci_to_true_color(index):
    return TrueColor.from_aci(index)


# Five RGB intensity steps per shade are enough to describe this palette.
# Maintaining the historical rounding keeps existing drawing colors identical.
_RAMP = (
    (0, 63, 127, 191, 255), (170, 191, 212, 234, 255),
    (0, 46, 94, 141, 189), (126, 141, 157, 173, 189),
    (0, 31, 64, 96, 129), (86, 96, 107, 118, 129),
    (0, 25, 52, 78, 104), (69, 78, 86, 95, 104),
    (0, 19, 39, 59, 79), (53, 59, 66, 73, 79),
)


def _aci_colors():
    gray = lambda tone: TrueColor.from_rgb(tone, tone, tone)
    yield gray(0)
    for channels in (4, 6, 2, 3, 1, 5):
        yield TrueColor.from_rgb(*(255 if channels & mask else 0 for mask in (4, 2, 1)))
    for level in (255, 65, 128):
        yield gray(level)

    for sector, (high, moving, low) in enumerate(((0, 1, 2), (1, 0, 2), (1, 2, 0),
                                                  (2, 1, 0), (2, 0, 1), (0, 2, 1))):
        for step in range(4):
            ramp_index = 4 - step if sector % 2 else step
            for ramp in _RAMP:
                rgb = [0, 0, 0]
                rgb[high], rgb[moving], rgb[low] = ramp[-1], ramp[ramp_index], ramp[0]
                yield TrueColor.from_rgb(*rgb)

    for level in (51, 80, 105, 130, 190, 255):
        yield gray(level)


dxf_default_colors = list(_aci_colors())
