# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Open DXF streams and resolve their declared text encoding."""

from ..dxf_records import drawing_encoding
from .color import aci_to_true_color
from .const import BYBLOCK, BYLAYER

version = (0, 8, 4)
VERSION = ".".join(map(str, version))
PYTHON3 = True
tostr = str


def read(stream, options=None):
    from .drawing import Drawing

    if not hasattr(stream, "readline"):
        raise AttributeError("stream object requires a readline() method.")
    return Drawing(stream, options)


def _read_encoded_file(filename, options=None, encoding="utf-8", errors="strict"):
    with open(filename, encoding=encoding, errors=errors) as stream:
        drawing = read(stream, options)
    drawing.filename = filename
    return drawing


def readfile_as_utf8(filename, options=None, errors="strict"):
    return _read_encoded_file(filename, options, encoding="utf-8", errors=errors)


def readfile_as_asc(filename, options=None):
    from .tags import dxfinfo

    with open(filename, encoding="utf-8-sig", errors="surrogateescape") as header:
        metadata = dxfinfo(header)
    codec = drawing_encoding(metadata.version, metadata.encoding)
    return _read_encoded_file(filename, options, encoding=codec)


def readfile(filename, options=None):
    try:
        return readfile_as_asc(filename, options)
    except UnicodeDecodeError:
        return readfile_as_utf8(filename, options, errors="ignore")
