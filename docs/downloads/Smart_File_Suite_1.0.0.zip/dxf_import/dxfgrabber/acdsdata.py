# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Read ACIS binary bodies associated with DXF entity handles."""

from .tags import TagGroups, Tags, binary_encoded_data_to_bytes


_REQUIRED = object()


class Section(Tags):
    @property
    def name(self):
        return self[0].value

    @property
    def type(self):
        return self[1].value

    @property
    def data(self):
        return self[2:]


class AcDsDataRecord:
    def __init__(self, tags):
        self.dxftype = tags[0].value
        self.sections = []
        for tag in tags[2:]:
            if tag.code == 2:
                self.sections.append(Section([tag]))
            elif self.sections:
                self.sections[-1].append(tag)

    def has_section(self, name):
        return self.get_section(name, None) is not None

    def get_section(self, name, default=_REQUIRED):
        section = next((part for part in self.sections if part.name == name), default)
        if section is _REQUIRED:
            raise KeyError(name)
        return section

    def __getitem__(self, name):
        return self.get_section(name)


class AcDsDataSection:
    name = "acdsdata"

    def __init__(self):
        self.sab_data = {}

    @classmethod
    def from_tags(cls, tags, drawing):
        result = cls()
        result._build(tags)
        return result

    def _build(self, tags):
        for group in TagGroups(iter(tags[2:-1])):
            if group[0].value != "ACDSRECORD":
                continue
            record = AcDsDataRecord(group)
            if record.has_section("ASM_Data"):
                self.add_asm_data(record)

    def add_asm_data(self, acdsrecord):
        owner = acdsrecord["AcDbDs::ID"][2].value
        chunks = (tag.value for tag in acdsrecord["ASM_Data"].data if tag.code == 310)
        self.sab_data[owner] = binary_encoded_data_to_bytes(chunks)
