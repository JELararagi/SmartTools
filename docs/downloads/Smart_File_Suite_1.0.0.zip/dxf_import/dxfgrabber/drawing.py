# SPDX-License-Identifier: GPL-3.0-or-later
"""Drawing-level view of DXF entities, blocks, and symbol dictionaries."""

from .sections import Sections
from .tags import stream_tagger


DEFAULT_OPTIONS = {
    "grab_blocks": True,
    "assure_3d_coords": False,
    "resolve_text_styles": True,
}


class Drawing:
    def __init__(self, stream, options=None):
        given = options if options is not None else {}
        for name, default in DEFAULT_OPTIONS.items():
            setattr(self, name, given.get(name, default))
        self.filename = None
        self.dxfversion = "AC1009"
        self.encoding = "cp1252"
        sections = Sections(stream_tagger(stream, self.assure_3d_coords), self)
        self.header = sections.header
        self.entities = sections.entities
        self.blocks = sections.blocks
        self.objects = sections.objects
        self.layers = sections.tables.layers
        self.styles = sections.tables.styles
        self.linetypes = sections.tables.linetypes
        self.acdsdata = sections.acdsdata
        if self.dxfversion >= "AC1027":
            self.collect_sab_data()
        if self.resolve_text_styles:
            resolve_text_styles(self.entities, self.styles)
            for block in self.blocks:
                resolve_text_styles(block, self.styles)

    def modelspace(self):
        return (entity for entity in self.entities if not entity.paperspace)

    def paperspace(self):
        return (entity for entity in self.entities if entity.paperspace)

    def collect_sab_data(self):
        for entity in self.entities:
            setter = getattr(entity, "set_sab_data", None)
            if setter is not None:
                payload = self.acdsdata.sab_data.get(entity.handle)
                if payload is not None:
                    setter(payload)


def resolve_text_styles(entities, text_styles):
    for entity in entities:
        resolve = getattr(entity, "resolve_text_style", None)
        if resolve is not None:
            resolve(text_styles)
