# SPDX-License-Identifier: GPL-3.0-or-later
"""Create Blender meshes from complete, validated R12 file plans."""
import bpy
from .r12_scene_prepare import read_r12_meshes


def import_curves_and_meshes(paths, collection, chord_error):
    if collection is None or not paths:
        raise ValueError("NO_FILE_OR_DESTINATION")
    plans = [read_r12_meshes(path, chord_error=chord_error) for path in paths]
    for plan in plans:
        if not plan.parts:
            raise ValueError("EMPTY_DRAWING")
        if plan.requires_attribute_handling:
            raise ValueError("NON_GEOMETRIC_ATTRIBUTES")
    objects = []
    meshes = []
    try:
        for plan in plans:
            for part in plan.parts:
                name = f"DXF {part.entity_type} {part.layer}"
                mesh = bpy.data.meshes.new(name)
                meshes.append(mesh)
                mesh.from_pydata(part.vertices, part.edges, part.faces)
                if mesh.validate():
                    raise ValueError("INVALID_MESH")
                mesh.update()
                obj = bpy.data.objects.new(name, mesh)
                objects.append(obj)
                obj["dxf_layer"] = part.layer
                obj["dxf_entity"] = part.entity_type
                collection.objects.link(obj)
    except BaseException:
        for obj in reversed(objects):
            bpy.data.objects.remove(obj, do_unlink=True)
        for mesh in reversed(meshes):
            bpy.data.meshes.remove(mesh)
        raise
    return len(objects)
