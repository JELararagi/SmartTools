'''Read CIRCLE and ARC parameters from a deliberately limited ASCII R12 subset.

Created through JEL Local Bridge using AI generation, 2026.
Copyright (c) 2026 JELararagi. SPDX-License-Identifier: GPL-3.0-or-later
Standard library only. No geometry generation, WCS conversion, or file writes.
'''
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import math
from pathlib import Path
import re

__all__ = ['MAX_INPUT_BYTES', 'CurveReadError', 'CircleRecord', 'ArcRecord',
           'CurveReadResult', 'parse_r12_curves', 'read_r12_curves']
MAX_INPUT_BYTES = 16 * 1024 * 1024
_CODE = re.compile(r'\+?[0-9]{1,4}', re.ASCII)
_REAL = re.compile(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[Ee][+-]?[0-9]+)?', re.ASCII)
_EXTRA = frozenset((5, 6, 48, 60, 62, 67))
_GEOMETRY = frozenset((8, 10, 20, 30, 39, 40, 210, 220, 230))


class CurveReadError(ValueError):
    '''Stable diagnostic fields for caller-owned Japanese/English messages.'''

    def __init__(self, code, *, line=None, entity_index=None, entity_type=None,
                 group_code=None, path=None, **details):
        self.code = code
        self.line = line
        self.entity_index = entity_index
        self.entity_type = entity_type
        self.group_code = group_code
        self.path = path
        self.details = details
        where = [str(value) for value in (path, f'line {line}' if line is not None else None,
                 f'entity {entity_index} {entity_type}' if entity_index is not None else None,
                 f'group {group_code}' if group_code is not None else None) if value is not None]
        super().__init__(code + (': ' + ', '.join(where) if where else ''))


@dataclass(frozen=True)
class CircleRecord:
    center_ocs: tuple[float, float, float]
    radius: float
    layer: str
    extrusion: tuple[float, float, float] = (0.0, 0.0, 1.0)
    thickness: float = 0.0
    coordinate_system: str = 'OCS'
    extra_groups: tuple[tuple[int, str], ...] = ()


@dataclass(frozen=True)
class ArcRecord:
    center_ocs: tuple[float, float, float]
    radius: float
    layer: str
    start_angle_deg: float
    end_angle_deg: float
    extrusion: tuple[float, float, float] = (0.0, 0.0, 1.0)
    thickness: float = 0.0
    coordinate_system: str = 'OCS'
    extra_groups: tuple[tuple[int, str], ...] = ()


@dataclass(frozen=True)
class CurveReadResult:
    version: str
    entities: tuple[CircleRecord | ArcRecord, ...]
    unknown_entities: tuple[tuple[str, int], ...]
    layers: tuple[str, ...]
    uninterpreted_sections: tuple[str, ...]
    comments: int


@dataclass(frozen=True)
class _Pair:
    code: int
    value: str
    line: int


def _token(pair):
    return pair.value.strip().upper()


def _pairs(data):
    if not isinstance(data, (str, bytes)):
        raise CurveReadError('INVALID_INPUT_TYPE', actual_type=type(data).__name__)
    if len(data) > MAX_INPUT_BYTES:
        raise CurveReadError('INPUT_TOO_LARGE', limit_bytes=MAX_INPUT_BYTES)
    if isinstance(data, bytes):
        try:
            text = data.decode('ascii', 'strict')
        except UnicodeDecodeError as exc:
            raise CurveReadError('NON_ASCII_INPUT') from exc
    else:
        text = data
        if not text.isascii():
            raise CurveReadError('NON_ASCII_INPUT')
    if '\x00' in text or '\r' in text.replace('\r\n', ''):
        raise CurveReadError('INVALID_TEXT_OR_LINE_ENDING')
    lines = text.replace('\r\n', '\n').split('\n')
    if lines and lines[-1] == '':
        lines.pop()
    if not lines or len(lines) % 2:
        raise CurveReadError('INCOMPLETE_GROUP_PAIR', line=len(lines) or 1)
    pairs, comments = [], 0
    for offset in range(0, len(lines), 2):
        raw = lines[offset].strip()
        if not _CODE.fullmatch(raw):
            raise CurveReadError('INVALID_GROUP_CODE', line=offset + 1)
        code = int(raw)
        if code > 1071:
            raise CurveReadError('INVALID_GROUP_CODE', line=offset + 1, group_code=code)
        if code == 999:
            comments += 1
        else:
            pairs.append(_Pair(code, lines[offset + 1], offset + 1))
    return pairs, comments


def _sections(pairs):
    sections = {}
    at, eof = 0, False
    while at < len(pairs):
        current = pairs[at]
        if current.code == 0 and _token(current) == 'EOF':
            if at != len(pairs) - 1:
                raise CurveReadError('DATA_AFTER_EOF', line=pairs[at + 1].line)
            eof = True
            break
        if current.code != 0 or _token(current) != 'SECTION':
            raise CurveReadError('EXPECTED_SECTION', line=current.line, group_code=current.code)
        if at + 1 >= len(pairs) or pairs[at + 1].code != 2:
            raise CurveReadError('MISSING_SECTION_NAME', line=current.line, group_code=2)
        name = _token(pairs[at + 1])
        if not name:
            raise CurveReadError('INVALID_SECTION_NAME', line=pairs[at + 1].line + 1, group_code=2)
        if name in sections:
            raise CurveReadError('DUPLICATE_SECTION', line=current.line, section=name)
        end = at + 2
        while end < len(pairs):
            candidate = pairs[end]
            if candidate.code == 0 and _token(candidate) == 'ENDSEC':
                break
            if candidate.code == 0 and _token(candidate) in ('SECTION', 'EOF'):
                raise CurveReadError('MISSING_ENDSEC', line=candidate.line, section=name)
            end += 1
        if end == len(pairs):
            raise CurveReadError('MISSING_ENDSEC', line=current.line, section=name)
        sections[name] = tuple(pairs[at + 2:end])
        at = end + 1
    if not eof:
        raise CurveReadError('MISSING_EOF')
    return sections


def _version(sections):
    header = sections.get('HEADER', ())
    version = None
    for index, pair in enumerate(header):
        if pair.code != 9 or pair.value.strip() != '$ACADVER':
            continue
        if version is not None:
            raise CurveReadError('DUPLICATE_VERSION', line=pair.line, group_code=9)
        if index + 1 >= len(header) or header[index + 1].code != 1:
            raise CurveReadError('INVALID_VERSION_HEADER', line=pair.line, group_code=1)
        value = header[index + 1]
        version = value.value.strip()
        if version != 'AC1009':
            raise CurveReadError('UNSUPPORTED_VERSION', line=value.line + 1, group_code=1, declared=version)
    if version is None:
        raise CurveReadError('MISSING_VERSION', group_code=9)
    return version


def _curve(kind, fields, entity_index, marker_line):
    def error(code, group=None, line=None, **details):
        return CurveReadError(code, line=marker_line if line is None else line,
                              entity_index=entity_index, entity_type=kind, group_code=group, **details)

    allowed = _GEOMETRY | _EXTRA | (frozenset((50, 51)) if kind == 'ARC' else frozenset())
    found = {}
    for field in fields:
        if field.code not in allowed:
            raise error('UNSUPPORTED_ENTITY_GROUP', field.code, field.line)
        if field.code in found:
            raise error('DUPLICATE_GROUP', field.code, field.line)
        found[field.code] = field

    def required(code):
        if code not in found:
            raise error('MISSING_GROUP', code)
        return found[code]

    def number(code, default=None):
        if code not in found and default is not None:
            return float(default)
        field = required(code)
        token = field.value.strip()
        try:
            value = float(token)
        except (ValueError, OverflowError) as exc:
            raise error('INVALID_NUMBER', code, field.line + 1, token=token) from exc
        if not math.isfinite(value):
            raise error('NONFINITE_NUMBER', code, field.line + 1, token=token)
        if not _REAL.fullmatch(token):
            raise error('INVALID_NUMBER', code, field.line + 1, token=token)
        return value

    layer_field = required(8)
    layer = layer_field.value
    if not layer.strip() or any(ord(character) < 32 or ord(character) > 126 for character in layer):
        raise error('INVALID_LAYER', 8, layer_field.line + 1)
    center = tuple(number(code) for code in (10, 20, 30))
    radius = number(40)
    if radius <= 0:
        raise error('NONPOSITIVE_RADIUS', 40, found[40].line + 1, radius=radius)
    thickness = number(39, 0)
    if thickness != 0:
        raise error('UNSUPPORTED_THICKNESS', 39, found[39].line + 1, thickness=thickness)
    extrusion_codes = (210, 220, 230)
    present = tuple(code for code in extrusion_codes if code in found)
    if not present:
        extrusion = (0.0, 0.0, 1.0)
    elif len(present) != 3:
        missing = tuple(code for code in extrusion_codes if code not in found)
        raise error('INCOMPLETE_EXTRUSION', missing[0], present=present, missing=missing)
    else:
        extrusion = tuple(number(code) for code in extrusion_codes)
        if not any(value != 0 for value in extrusion):
            raise error('ZERO_EXTRUSION', 210, found[210].line + 1)
    common = dict(center_ocs=center, radius=radius, layer=layer, extrusion=extrusion,
                  thickness=thickness, extra_groups=tuple((p.code, p.value) for p in fields if p.code in _EXTRA))
    if kind == 'ARC':
        return ArcRecord(start_angle_deg=number(50), end_angle_deg=number(51), **common)
    return CircleRecord(**common)


def parse_r12_curves(data: str | bytes) -> CurveReadResult:
    '''Read all supported parameters, or raise without returning a partial result.

    Initial contract: explicit AC1009, ASCII LF/CRLF, at most 16 MiB, thickness 0.
    Layer, center XYZ, radius and ARC start/end angles are required. Extrusion is
    either entirely omitted (default 0,0,1) or contains all three components.
    These strict requirements describe this subset, not every valid DXF file.

    Centers remain OCS coordinates. Extrusion is finite and nonzero but is not
    normalized. ARC angles remain the original finite degree values, including
    wraparound and equal angles. No sweep or full-circle meaning is inferred
    from ARC endpoints. CIRCLE remains a distinct full-circle parameter type.

    Only top-level ENTITIES is interpreted. Other entity types are counted;
    other sections are named in the result. Neither is geometrically validated.
    Common groups 5,6,48,60,62,67 are retained as raw extra_groups, not interpreted
    or semantically validated. Other groups in CIRCLE/ARC are explicitly refused.
    Fields may occur in any order. No tessellation, WCS conversion, or I/O occurs.
    '''
    pairs, comments = _pairs(data)
    sections = _sections(pairs)
    version = _version(sections)
    if 'ENTITIES' not in sections:
        raise CurveReadError('MISSING_ENTITIES')
    body = sections['ENTITIES']
    output, layers, unknown = [], [], Counter()
    at, entity_index = 0, 0
    while at < len(body):
        marker = body[at]
        if marker.code != 0:
            raise CurveReadError('EXPECTED_ENTITY', line=marker.line,
                                  entity_index=entity_index, group_code=marker.code)
        kind = _token(marker)
        if not kind:
            raise CurveReadError('INVALID_ENTITY_TYPE', line=marker.line + 1, entity_index=entity_index)
        end = at + 1
        while end < len(body) and body[end].code != 0:
            end += 1
        if kind in ('CIRCLE', 'ARC'):
            entity = _curve(kind, body[at + 1:end], entity_index, marker.line)
            output.append(entity)
            if entity.layer not in layers:
                layers.append(entity.layer)
        else:
            unknown[kind] += 1
        entity_index += 1
        at = end
    return CurveReadResult(version, tuple(output), tuple(sorted(unknown.items())), tuple(layers),
                           tuple(name for name in sections if name not in ('HEADER', 'ENTITIES')), comments)


def read_r12_curves(path: str | Path) -> CurveReadResult:
    '''Read at most MAX_INPUT_BYTES + 1 bytes; never write or execute input files.'''
    try:
        if isinstance(path, str) and not path:
            raise ValueError('empty path')
        source = Path(path)
    except (TypeError, ValueError) as exc:
        raise CurveReadError('INVALID_PATH', cause_type=type(exc).__name__) from exc
    try:
        if source.is_dir():
            raise CurveReadError('NOT_A_FILE', path=str(source))
        with source.open('rb') as stream:
            data = stream.read(MAX_INPUT_BYTES + 1)
    except FileNotFoundError as exc:
        raise CurveReadError('FILE_NOT_FOUND', path=str(source)) from exc
    except IsADirectoryError as exc:
        raise CurveReadError('NOT_A_FILE', path=str(source)) from exc
    except PermissionError as exc:
        raise CurveReadError('FILE_ACCESS_DENIED', path=str(source)) from exc
    except OSError as exc:
        raise CurveReadError('FILE_IO_ERROR', path=str(source), errno=exc.errno) from exc
    try:
        return parse_r12_curves(data)
    except CurveReadError as exc:
        raise CurveReadError(exc.code, line=exc.line, entity_index=exc.entity_index,
                              entity_type=exc.entity_type, group_code=exc.group_code,
                              path=str(source), **exc.details) from exc
