"""Original Autodesk R12 ASCII DXF subset importer (stdlib only).

Created through JEL Local Bridge using AI generation, 2026.
Attribution / release name: JELararagi.
Copyright (c) 2026 JELararagi. SPDX-License-Identifier: GPL-3.0-or-later

No Blender, third-party library, or bundled SmartFile source dependencies.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import math
from pathlib import Path
import re

__all__ = [
    "DXFParseError", "Line3D", "Face3D", "LegacyPolyline",
    "ImportResult", "parse_r12", "read_r12",
]

_MAX_SIZE = 16 * 1024 * 1024
_CODE_PATTERN = re.compile(r"[+-]?\d+\Z", re.ASCII)
_NUMBER_PATTERN = re.compile(
    r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+-]?\d+)?\Z", re.ASCII
)
_POINT3 = tuple[float, float, float]


class DXFParseError(ValueError):
    """Malformed input or a feature that cannot safely be reconstructed."""


@dataclass(frozen=True)
class Point3D:
    position: _POINT3
    layer: str


@dataclass(frozen=True)
class Line3D:
    start: _POINT3
    end: _POINT3
    layer: str


@dataclass(frozen=True)
class Face3D:
    vertices: tuple[_POINT3, ...]
    layer: str
    invisible_edges: int = 0


@dataclass(frozen=True)
class LegacyPolyline:
    vertices: tuple[_POINT3, ...]
    layer: str
    closed: bool
    is_3d: bool
    coordinate_system: str
    elevation: float
    flags: int


@dataclass(frozen=True)
class ImportResult:
    version: str | None
    entities: tuple[Point3D | Line3D | Face3D | LegacyPolyline, ...]
    unknown_entities: tuple[tuple[str, int], ...]
    layers: tuple[str, ...]


def _pairs(data: str | bytes) -> list[tuple[int, str]]:
    if isinstance(data, bytes):
        if len(data) > _MAX_SIZE:
            raise DXFParseError("DXF exceeds 16 MiB")
        try:
            data = data.decode("ascii", "strict")
        except UnicodeDecodeError as exc:
            raise DXFParseError("only ASCII DXF input is supported") from exc
    elif not isinstance(data, str):
        raise TypeError("parse_r12 requires ASCII text or bytes")
    if len(data) > _MAX_SIZE:
        raise DXFParseError("DXF exceeds 16 MiB")
    if "\x00" in data or "\r" in data.replace("\r\n", ""):
        raise DXFParseError("NUL or unsupported line ending")
    lines = data.replace("\r\n", "\n").split("\n")
    if lines[-1] == "":
        lines.pop()
    if not lines or len(lines) % 2:
        raise DXFParseError("truncated or odd number of group-code/value lines")
    pairs = []
    for offset in range(0, len(lines), 2):
        code_string = lines[offset].strip()
        if not _CODE_PATTERN.fullmatch(code_string):
            raise DXFParseError(f"invalid group code at line {offset + 1}")
        code = int(code_string)
        # Stripping fixed-width whitespace is conventional for ASCII DXF values.
        pairs.append((code, lines[offset + 1].strip()))
    return pairs


def _one(fields: list[tuple[int, str]], code: int, default: str | None = None) -> str:
    values = [value for key, value in fields if key == code]
    if len(values) > 1:
        raise DXFParseError(f"duplicate group code {code}")
    if not values:
        if default is None:
            raise DXFParseError(f"missing group code {code}")
        return default
    return values[0]


def _real(text: str, context: str) -> float:
    if not _NUMBER_PATTERN.fullmatch(text):
        raise DXFParseError(f"{context}: invalid real number")
    try:
        value = float(text)
    except (OverflowError, ValueError) as exc:
        raise DXFParseError(f"{context}: invalid real number") from exc
    if not math.isfinite(value):
        raise DXFParseError(f"{context}: nonfinite coordinate or value")
    return value


def _integer(text: str, context: str) -> int:
    if not _CODE_PATTERN.fullmatch(text):
        raise DXFParseError(f"{context}: invalid integer")
    return int(text)


def _point(fields: list[tuple[int, str]], offset: int, *, optional_z: bool = False) -> _POINT3:
    codes = (10 + offset, 20 + offset, 30 + offset)
    return tuple(
        _real(_one(fields, code, "0" if optional_z and code == 30 + offset else None), f"group {code}")
        for code in codes
    )  # type: ignore[return-value]


def _layer(fields: list[tuple[int, str]]) -> str:
    name = _one(fields, 8, "0")
    if not name or any(ord(c) < 32 or ord(c) > 126 for c in name):
        raise DXFParseError("invalid ASCII layer name")
    return name


def _no_width_or_bulge(fields: list[tuple[int, str]]) -> None:
    for code in (40, 41, 42):
        if _real(_one(fields, code, "0"), f"group {code}") != 0:
            raise DXFParseError(f"unsupported nonzero width or bulge (group {code})")


def _record(pairs: list[tuple[int, str]], at: int, end: int):
    if at >= end or pairs[at][0] != 0:
        raise DXFParseError("expected entity marker (group 0)")
    j = at + 1
    while j < end and pairs[j][0] != 0:
        j += 1
    return pairs[at][1].upper(), pairs[at + 1:j], j


def _parse_polyline(header, pairs, at: int, end: int):
    layer = _layer(header)
    flag = _integer(_one(header, 70, "0"), "POLYLINE flags")
    if flag < 0 or flag & ~(1 | 8 | 128):
        raise DXFParseError("unsupported polygon mesh, polyface, spline or curve-fitted POLYLINE")
    is_3d = bool(flag & 8)
    elevation = _real(_one(header, 30, "0"), "polyline elevation")
    for code in (39, 40, 41):
        if _real(_one(header, code, "0"), f"POLYLINE group {code}") != 0:
            raise DXFParseError("POLYLINE thickness/width is not supported")
    extrusion = tuple(
        _real(_one(header, code, default), f"extrusion {code}")
        for code, default in ((210, "0"), (220, "0"), (230, "1"))
    )
    if extrusion != (0.0, 0.0, 1.0):
        raise DXFParseError("nondefault OCS extrusion is not supported")
    points = []
    while at < end:
        name, fields, at = _record(pairs, at, end)
        if name == "SEQEND":
            if not points:
                raise DXFParseError("empty POLYLINE vertex sequence")
            return (
                LegacyPolyline(tuple(points), layer, bool(flag & 1), is_3d,
                               "WCS" if is_3d else "OCS", elevation, flag),
                at,
            )
        if name != "VERTEX":
            raise DXFParseError("POLYLINE requires VERTEX records ending in SEQEND")
        vflag = _integer(_one(fields, 70, "0"), "VERTEX flags")
        if vflag < 0 or vflag & ~32 or (vflag & 32 and not is_3d):
            raise DXFParseError("unsupported fitted or mesh VERTEX")
        _no_width_or_bulge(fields)
        point = _point(fields, 0, optional_z=not is_3d)
        points.append(point)
    raise DXFParseError("POLYLINE is missing SEQEND")


def _entities(pairs: list[tuple[int, str]], start: int, end: int):
    output = []
    unknown = Counter()
    layers = []
    at = start
    while at < end:
        name, fields, at = _record(pairs, at, end)
        if name == "POINT":
            if _real(_one(fields, 39, "0"), "POINT thickness") != 0:
                raise DXFParseError("POINT thickness is not supported")
            entity = Point3D(_point(fields, 0), _layer(fields))
        elif name == "LINE":
            layer = _layer(fields)
            if _real(_one(fields, 39, "0"), "LINE thickness") != 0:
                raise DXFParseError("LINE thickness is not supported")
            entity = Line3D(_point(fields, 0), _point(fields, 1), layer)
        elif name == "3DFACE":
            layer = _layer(fields)
            vertices = tuple(_point(fields, i) for i in range(3))
            fourth_codes = (13, 23, 33)
            fourth_present = [any(code == key for code, _ in fields) for key in fourth_codes]
            if any(fourth_present) and not all(fourth_present):
                raise DXFParseError("incomplete fourth 3DFACE corner")
            fourth = _point(fields, 3) if all(fourth_present) else vertices[2]
            if fourth != vertices[2]:
                vertices += (fourth,)
            flags = _integer(_one(fields, 70, "0"), "3DFACE hidden edges")
            if flags < 0 or flags > 15:
                raise DXFParseError("invalid 3DFACE invisible-edge flags")
            entity = Face3D(vertices, layer, flags)
        elif name == "POLYLINE":
            entity, at = _parse_polyline(fields, pairs, at, end)
        elif name in ("VERTEX", "SEQEND"):
            raise DXFParseError(f"orphan {name} without POLYLINE")
        else:
            if not name:
                raise DXFParseError("blank entity type")
            unknown[name] += 1
            continue
        output.append(entity)
        if entity.layer not in layers:
            layers.append(entity.layer)
    return tuple(output), tuple(sorted(unknown.items())), tuple(layers)


def parse_r12(data: str | bytes) -> ImportResult:
    """Parse a bounded ASCII R12 drawing; never return partial results on errors.

    HEADER (and $ACADVER) may be absent, as permitted by the DXF file format.
    An explicit version must be AC1009. Only ENTITIES is interpreted for geometry.
    """
    pairs = _pairs(data)
    index = 0
    seen_sections = set()
    version = None
    parsed_entities = ()
    unknown = ()
    layers = ()
    reached_eof = False
    while index < len(pairs):
        if pairs[index] == (0, "EOF"):
            if index != len(pairs) - 1:
                raise DXFParseError("data after EOF")
            reached_eof = True
            break
        if pairs[index] != (0, "SECTION"):
            raise DXFParseError(f"expected SECTION or EOF near group {index}")
        if index + 1 >= len(pairs) or pairs[index + 1][0] != 2:
            raise DXFParseError("SECTION missing group 2 name")
        section = pairs[index + 1][1].upper()
        if not section or section in seen_sections:
            raise DXFParseError("blank or repeated section")
        seen_sections.add(section)
        start = index + 2
        end = start
        while end < len(pairs) and pairs[end] != (0, "ENDSEC"):
            if pairs[end] in ((0, "SECTION"), (0, "EOF")):
                raise DXFParseError(f"unclosed SECTION {section}")
            end += 1
        if end >= len(pairs):
            raise DXFParseError(f"SECTION {section} missing ENDSEC")
        if section == "HEADER":
            for pos in range(start, end):
                if pairs[pos] == (9, "$ACADVER"):
                    if version is not None or pos + 1 >= end or pairs[pos + 1][0] != 1:
                        raise DXFParseError("invalid or duplicated $ACADVER header")
                    version = pairs[pos + 1][1]
                    if version != "AC1009":
                        raise DXFParseError(f"not an R12 drawing ($ACADVER={version})")
        if section == "ENTITIES":
            parsed_entities, unknown, layers = _entities(pairs, start, end)
        index = end + 1
    if not reached_eof:
        raise DXFParseError("missing EOF")
    if "ENTITIES" not in seen_sections:
        raise DXFParseError("missing ENTITIES section")
    return ImportResult(version, parsed_entities, unknown, layers)


def read_r12(path: str | Path) -> ImportResult:
    """Read a local .dxf file; no writes, imports, or external execution."""
    path = Path(path)
    if path.stat().st_size > _MAX_SIZE:
        raise DXFParseError("DXF exceeds 16 MiB")
    return parse_r12(path.read_bytes())
