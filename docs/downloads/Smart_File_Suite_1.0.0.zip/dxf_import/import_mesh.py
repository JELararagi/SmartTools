# SPDX-License-Identifier: GPL-3.0-or-later
"""Bounded R12 geometry import with a single undoable unit per file selection."""
from pathlib import Path
import bpy
from .r12_reader import read_r12
from .mesh_adapter import create_mesh_objects


def import_files(paths, collection):
    if collection is None:
        raise ValueError("No active collection")
    planned = tuple(read_r12(Path(f)) for f in paths)
    if not planned:
        raise ValueError("No input file")
    created = []
    try:
        for drawing in planned:
            created.extend(create_mesh_objects(drawing, collection))
    except BaseException:
        for obj in reversed(created):
            mesh = obj.data
            bpy.data.objects.remove(obj, do_unlink=True)
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)
        raise
    return len(created)
