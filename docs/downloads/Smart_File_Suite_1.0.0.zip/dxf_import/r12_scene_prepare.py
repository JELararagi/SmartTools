'''Prepare ordered mesh-construction data from independent R12 readers.

Created through JEL Local Bridge using AI generation, 2026.
Copyright (c) 2026 JELararagi. SPDX-License-Identifier: GPL-3.0-or-later
Standard Python only. No bpy, scene access, file writes, or third-party DXF code.
'''
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, replace
import hashlib
import math
from pathlib import Path
import re
import struct

from . import r12_reader as legacy
from . import r12_curve_reader as curves
from . import r12_curve_geometry as geometry

__all__ = ['MAX_ENTITIES', 'MAX_TOTAL_VERTICES', 'ScenePrepareError', 'DXFTag',
           'UnappliedAttribute', 'MeshPart', 'ScenePlan',
           'prepare_r12_meshes', 'read_r12_meshes']
MAX_ENTITIES = 10000
MAX_TOTAL_VERTICES = 200000
_COMMON = frozenset((5,6,48,60,62,67))
_POINT_CODES = frozenset((10,20,30,11,21,31))
_ALLOWED = {
    'POINT': _COMMON | {8,10,20,30,39,50,210,220,230},
    'LINE': _COMMON | _POINT_CODES | {8,39,210,220,230},
    '3DFACE': _COMMON | {8,70,10,20,30,11,21,31,12,22,32,13,23,33},
    'POLYLINE': _COMMON | {8,10,20,30,39,40,41,66,70,210,220,230},
    'VERTEX': _COMMON | {8,10,20,30,40,41,42,70},
    'SEQEND': _COMMON | {8},
}
_SUPPORTED = frozenset(('POINT','LINE','3DFACE','POLYLINE','CIRCLE','ARC'))
_REAL = re.compile(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[Ee][+-]?[0-9]+)?',re.ASCII)


class ScenePrepareError(ValueError):
    '''Stable outer code and source position; caller supplies localized wording.'''

    def __init__(self, code, *, source_index=None, source_line=None, source_type=None, path=None, **details):
        self.code = code
        self.source_index = source_index
        self.source_line = source_line
        self.source_type = source_type
        self.path = path
        self.details = details
        where = ', '.join(str(v) for v in (path,source_index,source_type,source_line) if v is not None)
        super().__init__(code + (': ' + where if where else ''))


@dataclass(frozen=True)
class DXFTag:
    code: int
    value: str
    line: int


@dataclass(frozen=True)
class _Record:
    kind: str
    tags: tuple[DXFTag, ...]


@dataclass(frozen=True)
class _Logical:
    index: int
    line: int
    kind: str
    records: tuple[_Record, ...]


@dataclass(frozen=True)
class UnappliedAttribute:
    source_index: int
    source_line: int
    record_type: str
    group_code: int
    value: str


@dataclass(frozen=True)
class MeshPart:
    source_index: int
    source_line: int
    entity_type: str
    layer: str
    vertices: tuple[tuple[float, float, float], ...]
    edges: tuple[tuple[int, int], ...]
    faces: tuple[tuple[int, ...], ...]
    closed_wire: bool
    removed_repeated_endpoint: bool
    max_float32_abs_error: float
    max_float32_distance: float
    source_entity: object
    raw_tags: tuple[DXFTag, ...]
    curve_geometry: geometry.CurveGeometry | None


@dataclass(frozen=True)
class ScenePlan:
    version: str
    source_sha256: str
    parts: tuple[MeshPart, ...]
    layers: tuple[str, ...]
    vertex_count: int
    wire_edge_count: int
    face_count: int
    max_float32_abs_error: float
    max_float32_distance: float
    unapplied_attributes: tuple[UnappliedAttribute, ...]
    uninterpreted_sections: tuple[str, ...]
    section_tags: tuple[tuple[str, tuple[DXFTag, ...]], ...]
    header_tags: tuple[DXFTag, ...]
    comments: int
    requires_attribute_handling: bool


def _failure(code, item=None, tag=None, **details):
    return ScenePrepareError(code, source_index=item.index if item else None,
                             source_line=tag.line if tag else item.line if item else None,
                             source_type=item.kind if item else None, **details)


def _token(tag):
    return tag.value.strip().upper()


def _options(chord_error, max_segments, max_total_vertices):
    if isinstance(chord_error,bool) or not isinstance(chord_error,(int,float)):
        raise ScenePrepareError('INVALID_OPTION',location='chord_error')
    try:
        tolerance = float(chord_error)
    except (ValueError,OverflowError) as exc:
        raise ScenePrepareError('INVALID_OPTION',location='chord_error') from exc
    if not math.isfinite(tolerance) or tolerance <= 0:
        raise ScenePrepareError('INVALID_OPTION',location='chord_error')
    for name,value,limit in (('max_segments',max_segments,geometry.MAX_SEGMENTS),
                             ('max_total_vertices',max_total_vertices,MAX_TOTAL_VERTICES)):
        if isinstance(value,bool) or not isinstance(value,int) or not 1 <= value <= limit:
            raise ScenePrepareError('INVALID_OPTION',location=name,maximum=limit)
    return tolerance


def _index_validated(text):
    # The public curve parser has already validated ASCII, pairs and sections.
    lines = text.replace('\r\n','\n').split('\n')
    if lines[-1] == '':
        lines.pop()
    tags = tuple(DXFTag(int(lines[i].strip()),lines[i+1],i+1)
                 for i in range(0,len(lines),2) if int(lines[i].strip()) != 999)
    sections = {}
    at = 0
    while at < len(tags) and not (tags[at].code == 0 and _token(tags[at]) == 'EOF'):
        if tags[at].code != 0 or _token(tags[at]) != 'SECTION' or at+1 >= len(tags) or tags[at+1].code != 2:
            raise ScenePrepareError('INDEX_STRUCTURE_MISMATCH',source_line=tags[at].line)
        name = _token(tags[at+1])
        end = at+2
        while end < len(tags) and not (tags[end].code == 0 and _token(tags[end]) == 'ENDSEC'):
            end += 1
        if end == len(tags):
            raise ScenePrepareError('INDEX_STRUCTURE_MISMATCH',source_line=tags[at].line)
        sections[name] = tags[at+2:end]
        at = end+1
    if 'ENTITIES' not in sections:
        raise ScenePrepareError('INDEX_STRUCTURE_MISMATCH')
    for name,body in sections.items():
        if name not in ('HEADER','ENTITIES','TABLES','BLOCKS') or (name == 'BLOCKS' and body):
            raise ScenePrepareError('UNSUPPORTED_SECTION',source_line=body[0].line if body else None,section=name)
    body = sections['ENTITIES']
    records,at = [],0
    while at < len(body):
        if body[at].code != 0:
            raise ScenePrepareError('INDEX_STRUCTURE_MISMATCH',source_line=body[at].line)
        end = at+1
        while end < len(body) and body[end].code != 0:
            end += 1
        records.append(_Record(_token(body[at]),body[at:end]))
        at = end
    logical,at = [],0
    while at < len(records):
        head = records[at]
        item = _Logical(len(logical),head.tags[0].line,head.kind,())
        if len(logical) >= MAX_ENTITIES:
            raise _failure('ENTITY_LIMIT',item,maximum=MAX_ENTITIES)
        if head.kind in ('VERTEX','SEQEND'):
            raise _failure('ORPHAN_SEQUENCE_RECORD',item)
        group = [head]
        at += 1
        if head.kind == 'POLYLINE':
            while at < len(records) and records[at].kind == 'VERTEX':
                group.append(records[at])
                at += 1
            if at == len(records) or records[at].kind != 'SEQEND':
                raise _failure('MISSING_SEQEND',item)
            group.append(records[at])
            at += 1
        logical.append(replace(item,records=tuple(group)))
    return tuple(logical),sections


def _layer(item):
    tags = [tag for tag in item.records[0].tags[1:] if tag.code == 8]
    if len(tags) > 1:
        raise _failure('DUPLICATE_GROUP',item,tags[1],group_code=8)
    value = tags[0].value if tags else '0'
    if not value.strip() or any(ord(c) < 32 or ord(c) > 126 for c in value):
        raise _failure('INVALID_LAYER',item,tags[0] if tags else None)
    return value


def _number_field(fields,code,default,item):
    tag = fields.get(code)
    if tag is None:
        return default
    token = tag.value.strip()
    if not _REAL.fullmatch(token):
        raise _failure('INVALID_NUMBER',item,tag,group_code=code)
    try:
        value = float(token)
    except (ValueError,OverflowError) as exc:
        raise _failure('INVALID_NUMBER',item,tag,group_code=code) from exc
    if not math.isfinite(value):
        raise _failure('NONFINITE_NUMBER',item,tag,group_code=code)
    return value


def _guard_legacy(item,layer):
    maps = []
    for record in item.records:
        allowed = _ALLOWED[record.kind]
        found = {}
        for tag in record.tags[1:]:
            if tag.code not in allowed:
                raise _failure('UNSUPPORTED_GROUP',item,tag,record_type=record.kind,group_code=tag.code)
            if tag.code in found:
                raise _failure('DUPLICATE_GROUP',item,tag,record_type=record.kind,group_code=tag.code)
            found[tag.code] = tag
        maps.append(found)
        if record.kind == 'VERTEX' and 8 in found and found[8].value.strip() != layer.strip():
            raise _failure('UNSUPPORTED_VERTEX_LAYER',item,found[8])
    first = maps[0]
    if item.kind == 'LINE':
        normal = tuple(_number_field(first,code,default,item) for code,default in ((210,0.0),(220,0.0),(230,1.0)))
        if normal != (0.0,0.0,1.0):
            raise _failure('UNSUPPORTED_LINE_EXTRUSION',item,extrusion=normal)
    if item.kind == 'POLYLINE':
        for code in (10,20):
            if _number_field(first,code,0.0,item) != 0:
                raise _failure('UNSUPPORTED_POLYLINE_HEADER_POINT',item,first[code],group_code=code)


def _legacy_entity(item,layer):
    _guard_legacy(item,layer)
    tags = tuple(tag for record in item.records for tag in record.tags)
    body = ''.join(f'{tag.code}\n{tag.value}\n' for tag in tags)
    document = ('0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1009\n0\nENDSEC\n'
                '0\nSECTION\n2\nENTITIES\n' + body + '0\nENDSEC\n0\nEOF\n')
    try:
        parsed = legacy.parse_r12(document)
    except (legacy.DXFParseError,TypeError,ValueError) as exc:
        raise _failure('LEGACY_PARSE_ERROR',item,reason=str(exc)) from exc
    expected = {'POINT':legacy.Point3D,'LINE':legacy.Line3D,'3DFACE':legacy.Face3D,'POLYLINE':legacy.LegacyPolyline}[item.kind]
    if parsed.version != 'AC1009' or parsed.unknown_entities or len(parsed.entities) != 1 or not isinstance(parsed.entities[0],expected):
        raise _failure('PARSER_RESULT_MISMATCH',item,reader='r12_reader')
    entity = parsed.entities[0]
    if entity.layer != layer.strip():
        raise _failure('PARSER_RESULT_MISMATCH',item,reader='r12_reader',field='layer')
    # Retain the exact source spelling instead of propagating the older reader's strip.
    return replace(entity,layer=layer)


def _point32(point,item,index):
    if not isinstance(point,(tuple,list)) or len(point) != 3 or any(isinstance(v,bool) or not isinstance(v,(int,float)) for v in point):
        raise _failure('INVALID_COORDINATE',item,vertex_index=index)
    try:
        original = tuple(float(v) for v in point)
        if not all(math.isfinite(v) for v in original):
            raise ValueError('nonfinite coordinate')
        rounded = struct.unpack('=3f',struct.pack('=3f',*original))
    except (ValueError,OverflowError,struct.error) as exc:
        raise _failure('FLOAT32_OUT_OF_RANGE',item,vertex_index=index) from exc
    if not all(math.isfinite(v) for v in rounded):
        raise _failure('FLOAT32_OUT_OF_RANGE',item,vertex_index=index)
    return original,rounded


def _normal(points):
    following = points[1:]+points[:1]
    return tuple(math.fsum((a[(axis+1)%3]-b[(axis+1)%3]) *
                          (a[(axis+2)%3]+b[(axis+2)%3]) for a,b in zip(points,following))
                 for axis in range(3))


def _mesh_part(item,entity,layer,curve,remaining):
    edges,faces,closed,removed = (),(),False,False
    if curve is not None:
        raw = curve.points
        edges,closed = curve.edges,curve.closed
    elif isinstance(entity,legacy.Point3D):
        raw = (entity.position,)
    elif isinstance(entity,legacy.Line3D):
        raw = (entity.start,entity.end)
        edges = ((0,1),)
    elif isinstance(entity,legacy.Face3D):
        if entity.invisible_edges:
            raise _failure('UNSUPPORTED_FACE_VISIBILITY',item,flags=entity.invisible_edges)
        raw = entity.vertices
        if len(raw) not in (3,4):
            raise _failure('INVALID_FACE',item)
        faces = (tuple(range(len(raw))),)
    elif isinstance(entity,legacy.LegacyPolyline):
        expected_flags = int(entity.closed) | (8 if entity.is_3d else 0)
        if entity.flags != expected_flags:
            raise _failure('UNSUPPORTED_POLYLINE_FLAGS',item,flags=entity.flags)
        if entity.coordinate_system != ('WCS' if entity.is_3d else 'OCS'):
            raise _failure('UNSUPPORTED_POLYLINE_COORDINATES',item)
        if entity.is_3d:
            if entity.elevation != 0:
                raise _failure('UNSUPPORTED_3D_POLYLINE_ELEVATION',item)
            raw = entity.vertices
        else:
            if any(point[2] != 0 for point in entity.vertices):
                raise _failure('UNSUPPORTED_2D_VERTEX_Z',item)
            raw = tuple((point[0],point[1],entity.elevation) for point in entity.vertices)
        closed = entity.closed
        if closed and len(raw)>1 and raw[-1] == raw[0]:
            raw,removed = raw[:-1],True
        if len(raw) < (3 if closed else 2):
            raise _failure('TOO_FEW_POLYLINE_VERTICES',item)
        edges = tuple((i,i+1) for i in range(len(raw)-1))
        if closed:
            edges += ((len(raw)-1,0),)
    else:
        raise _failure('PARSER_RESULT_MISMATCH',item)
    if len(raw) > remaining:
        raise _failure('TOTAL_VERTEX_LIMIT',item,remaining=remaining,requested=len(raw))
    pairs = tuple(_point32(point,item,index) for index,point in enumerate(raw))
    original = tuple(pair[0] for pair in pairs)
    vertices = tuple(pair[1] for pair in pairs)
    if curve is not None and len(set(vertices)) != len(vertices):
        raise _failure('FLOAT32_CURVE_COLLAPSE',item)
    for a,b in edges:
        if original[a] == original[b]:
            raise _failure('ZERO_LENGTH_EDGE',item,edge=(a,b))
        if vertices[a] == vertices[b]:
            raise _failure('FLOAT32_EDGE_COLLAPSE',item,edge=(a,b))
    if faces:
        if len(set(original)) != len(original) or not any(_normal(original)):
            raise _failure('DEGENERATE_FACE',item)
        if len(set(vertices)) != len(vertices) or not any(_normal(vertices)):
            raise _failure('FLOAT32_FACE_COLLAPSE',item)
        before,after = _normal(original),_normal(vertices)
        if math.fsum(a*b for a,b in zip(before,after)) <= 0:
            raise _failure('FLOAT32_ORIENTATION_LOSS',item)
    component_error = max((abs(a-b) for p,q in pairs for a,b in zip(p,q)),default=0.0)
    distance_error = max((math.dist(p,q) for p,q in pairs),default=0.0)
    tags = tuple(tag for record in item.records for tag in record.tags)
    return MeshPart(item.index,item.line,item.kind,layer,vertices,edges,faces,closed,removed,
                    component_error,distance_error,entity,tags,curve)


def prepare_r12_meshes(data, *, chord_error, max_segments=geometry.MAX_SEGMENTS,
                       max_total_vertices=MAX_TOTAL_VERTICES) -> ScenePlan:
    '''Return a complete immutable construction plan, or raise without a partial plan.

    Source order is logical ENTITIES order. A legacy POLYLINE and its VERTEX ...
    SEQEND sequence form one part. Unknown entities abort the entire preparation.
    Existing readers are used through public APIs and are never modified.

    Vertices are float32 snapshots. Ideal curve sagitta and vertex rounding
    displacement are reported separately; chord_error is not a combined final
    float32 error guarantee. No Blender IDs are created and no rollback executor
    is implemented here. Raw attributes/sections remain explicit unapplied data.
    The total-vertex cap limits output vertices, not all parser memory allocations.
    '''
    tolerance = _options(chord_error,max_segments,max_total_vertices)
    try:
        parsed_curves = curves.parse_r12_curves(data)
    except curves.CurveReadError as exc:
        raise ScenePrepareError('INPUT_PARSE_ERROR',source_line=exc.line,source_type=exc.entity_type,
                                cause_code=exc.code,reader_entity_index=exc.entity_index,
                                group_code=exc.group_code,reason=str(exc)) from exc
    text = data.decode('ascii') if isinstance(data,bytes) else data
    logical,sections = _index_validated(text)
    unknown = tuple(item for item in logical if item.kind not in _SUPPORTED)
    if unknown:
        counts = tuple(sorted(Counter(item.kind for item in unknown).items()))
        raise _failure('UNSUPPORTED_ENTITIES',unknown[0],unknown_entities=counts,
                       source_indices=tuple(item.index for item in unknown))
    parts,layers,attributes = [],[],[]
    used,curve_index = 0,0
    for item in logical:
        layer = _layer(item)
        curve = None
        if item.kind in ('CIRCLE','ARC'):
            expected = curves.CircleRecord if item.kind == 'CIRCLE' else curves.ArcRecord
            if curve_index >= len(parsed_curves.entities):
                raise _failure('PARSER_RESULT_MISMATCH',item,reader='r12_curve_reader')
            entity = parsed_curves.entities[curve_index]
            curve_index += 1
            if not isinstance(entity,expected) or entity.layer != layer:
                raise _failure('PARSER_RESULT_MISMATCH',item,reader='r12_curve_reader')
            try:
                curve = geometry.tessellate_curve(entity,chord_error=tolerance,max_segments=max_segments)
            except geometry.CurveGeometryError as exc:
                raise _failure('CURVE_GEOMETRY_ERROR',item,cause_code=exc.code,
                               location=exc.location,geometry_details=exc.details) from exc
        else:
            entity = _legacy_entity(item,layer)
        part = _mesh_part(item,entity,layer,curve,max_total_vertices-used)
        used += len(part.vertices)
        parts.append(part)
        if layer not in layers:
            layers.append(layer)
        for record in item.records:
            attributes.extend(UnappliedAttribute(item.index,tag.line,record.kind,tag.code,tag.value)
                              for tag in record.tags[1:] if tag.code in _COMMON)
    if curve_index != len(parsed_curves.entities):
        raise ScenePrepareError('PARSER_RESULT_MISMATCH',reader='r12_curve_reader',unconsumed=len(parsed_curves.entities)-curve_index)
    section_tags = tuple((name,body) for name,body in sections.items() if name not in ('HEADER','ENTITIES'))
    header = sections.get('HEADER',())
    unapplied = bool(attributes or any(body for name,body in section_tags) or len(header)>2)
    return ScenePlan(parsed_curves.version,hashlib.sha256(text.encode('ascii')).hexdigest(),tuple(parts),tuple(layers),
                     used,sum(len(part.edges) for part in parts),sum(len(part.faces) for part in parts),
                     max((part.max_float32_abs_error for part in parts),default=0.0),
                     max((part.max_float32_distance for part in parts),default=0.0),tuple(attributes),
                     parsed_curves.uninterpreted_sections,section_tags,header,parsed_curves.comments,unapplied)


def read_r12_meshes(path, *, chord_error, max_segments=geometry.MAX_SEGMENTS,
                    max_total_vertices=MAX_TOTAL_VERTICES) -> ScenePlan:
    '''Read one bounded snapshot, then prepare it; no file writes or scene access.'''
    try:
        source = Path(path)
    except (TypeError,ValueError) as exc:
        raise ScenePrepareError('INVALID_PATH') from exc
    try:
        if source.is_dir():
            raise ScenePrepareError('NOT_A_FILE',path=str(source))
        with source.open('rb') as stream:
            data = stream.read(curves.MAX_INPUT_BYTES+1)
    except ScenePrepareError:
        raise
    except FileNotFoundError as exc:
        raise ScenePrepareError('FILE_NOT_FOUND',path=str(source)) from exc
    except PermissionError as exc:
        raise ScenePrepareError('PERMISSION_DENIED',path=str(source)) from exc
    except (OSError,ValueError) as exc:
        raise ScenePrepareError('FILE_READ_ERROR',path=str(source),reason=str(exc)) from exc
    try:
        return prepare_r12_meshes(data,chord_error=chord_error,max_segments=max_segments,
                                  max_total_vertices=max_total_vertices)
    except ScenePrepareError as exc:
        raise ScenePrepareError(exc.code,source_index=exc.source_index,source_line=exc.source_line,
                                source_type=exc.source_type,path=str(source),**exc.details) from exc
