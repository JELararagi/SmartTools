# SPDX-License-Identifier: GPL-3.0-or-later
"""DXF parsing and Blender scene construction helpers."""
