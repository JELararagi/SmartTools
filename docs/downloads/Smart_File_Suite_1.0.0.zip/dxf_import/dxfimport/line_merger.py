# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Stitch undirected DXF line geometry into polylines."""

from collections import defaultdict, deque


def _round_point(point, precision):
    return tuple(round(axis, precision) for axis in point)


def _incident_edges(lines, precision):
    pending = set()
    incident = defaultdict(deque)
    for line in lines:
        a, b = (_round_point(endpoint, precision) for endpoint in (line.start, line.end))
        if a == b:
            continue
        edge = (a, b) if a < b else (b, a)
        if edge not in pending:
            pending.add(edge)
            incident[a].append(edge)
            incident[b].append(edge)
    return pending, incident


def line_merger(lines, precision=6):
    pending, incident = _incident_edges(lines, precision)
    result = []

    def next_point(endpoint):
        for _ in range(len(incident[endpoint])):
            edge = incident[endpoint].popleft()
            if edge in pending:
                pending.remove(edge)
                return edge[1] if endpoint == edge[0] else edge[0]
        return None

    while pending:
        path = deque(pending.pop())
        left, right = path
        while left is not None or right is not None:
            if left is not None:
                left = next_point(left)
                if left is not None:
                    path.appendleft(left)
            if right is not None:
                right = next_point(right)
                if right is not None:
                    path.append(right)
        result.append(list(path))
    return result
