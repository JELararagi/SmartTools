# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Classify DXF geometry by the importer path used for it."""

from mathutils import Vector


_MESH_ENTITIES = frozenset(("3DFACE", "MESH", "POINT", "POLYFACE", "POLYMESH", "SOLID", "TRACE"))
_CURVE_ENTITIES = frozenset(("ARC", "CIRCLE", "ELLIPSE", "HELIX", "LINE", "LWPOLYLINE",
                             "POLYGON", "POLYLINE", "SPLINE"))
_NURBS_ENTITIES = frozenset(("3DSOLID", "BODY", "PLANESURFACE", "REGION", "SURFACE"))
_TEXT_ENTITIES = frozenset(("MTEXT", "TEXT"))
_SEPARATE = _TEXT_ENTITIES | {"BLOCK", "INSERT", "LIGHT", "POLYFACE", "POLYMESH"}
_PLANAR = frozenset(("ARC", "ATTDEF", "ATTRIB", "CIRCLE", "ELLIPSE", "HATCH", "IMAGE",
                     "INSERT", "LWPOLYLINE", "SHAPE", "SOLID", "TEXT", "TRACE"))


def mesh(kind):
    return kind in _MESH_ENTITIES


def mesh_entity(entity):
    return mesh(entity.dxftype)


def curve(kind):
    return kind in _CURVE_ENTITIES


def curve_entity(entity):
    return curve(entity.dxftype)


def nurbs(kind):
    return kind in _NURBS_ENTITIES


def nurbs_entity(entity):
    return nurbs(entity.dxftype)


def text(kind):
    return kind in _TEXT_ENTITIES


def text_entity(entity):
    return text(entity.dxftype)


def insert(kind):
    return kind == "INSERT"


def insert_entity(entity):
    return insert(entity.dxftype)


def light(kind):
    return kind == "LIGHT"


def light_entity(entity):
    return light(entity.dxftype)


def attrib(kind):
    return kind == "ATTDEF"


def _2D_entity(entity):
    kind = entity.dxftype
    return kind in _PLANAR or (kind == "POLYGON" and entity.mode == "spline2d")


def closed_poly_no_bulge(entity):
    if entity.dxftype not in {"POLYLINE", "LWPOLYLINE"}:
        return False
    return not any(value != 0 for value in entity.bulge) and entity.is_closed


def varying_width(entity):
    width = getattr(entity, "width", None)
    if not hasattr(width, "__iter__") or not len(width):
        return False
    left, right = width[0][:2]
    return left != right or any(pair != width[0] for pair in width)


def separated(kind):
    return kind in _SEPARATE


def separated_entity(entity):
    return separated(entity.dxftype) or varying_width(entity)


def combined(kind):
    return not separated(kind) and not attrib(kind)


def combined_entity(entity):
    return not separated_entity(entity) and not attrib(entity.dxftype)


def extrusion(entity):
    axis = entity.extrusion
    if axis is None:
        return False
    return Vector(axis) != Vector((0, 0, 1)) or getattr(entity, "elevation", 0) != 0
