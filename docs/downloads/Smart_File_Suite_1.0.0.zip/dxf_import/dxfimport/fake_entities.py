# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Geometric records for subdividing DXF polyline segments."""

from dataclasses import dataclass, field
from mathutils import Vector


@dataclass(init=False, eq=False, repr=False)
class ArcEntity:
    start_angle: float = field(init=False)
    end_angle: float = field(init=False)
    center: Vector = field(init=False)
    radius: float = field(init=False)
    angdir: int = field(init=False)

    def __init__(self, start, end, center, radius, angdir):
        self.start_angle, self.end_angle = start, end
        self.center, self.radius, self.angdir = center, radius, angdir

    def __str__(self):
        values = (
            ("startangle", self.start_angle), ("endangle", self.end_angle),
            ("center", self.center), ("radius", self.radius), ("angdir", self.angdir),
        )
        return ", ".join(f"{label}: {value}" for label, value in values)


@dataclass(eq=False, repr=False)
class LineEntity:
    start: Vector
    end: Vector
