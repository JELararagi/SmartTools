# SPDX-FileCopyrightText: 2026 JELararagi
# SPDX-License-Identifier: GPL-3.0-or-later
"""Stable groups of CAD entities with compatible Blender import settings."""

from itertools import groupby
from operator import attrgetter

from . import is_


def map_dxf_to_blender_type(kind):
    categories = (("object_mesh", is_.mesh), ("object_curve", is_.curve),
                  ("object_surface", is_.nurbs))
    for target, matches in categories:
        if matches(kind):
            return target
    print("groupsort: not mergeable type ", kind)
    return "not_mergeable"


def _groups(entities, key):
    return groupby(sorted(entities, key=key), key=key)


def _object_type(entity):
    return map_dxf_to_blender_type(entity.dxftype)


def by_blender_type(entities):
    return _groups(entities, _object_type)


def by_layer(entities):
    return _groups(entities, attrgetter("layer"))


def by_closed_poly_no_bulge(entities):
    return _groups(entities, is_.closed_poly_no_bulge)


def by_dxftype(entities):
    return _groups(entities, attrgetter("dxftype"))


def _curve_and_mesh_settings(entity):
    widths = getattr(entity, "width", ())
    widths = widths if any(channel != 0 for pair in widths for channel in pair) else [(0, 0)]
    if entity.dxftype in {"LINE", "POINT"}:
        axis = (0.0, 0.0, 1.0)
    else:
        axis = entity.extrusion if entity.extrusion is not None else ()
    return entity.thickness, getattr(entity, "subdivision_levels", -1), widths, axis


def by_attributes(entities):
    return _groups(entities, _curve_and_mesh_settings)


def by_insert_block_name(inserts):
    return _groups(inserts, attrgetter("name"))
