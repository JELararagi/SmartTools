"""Text and record handling for SmartFile's legacy ASCII DXF importer."""

from datetime import date, datetime, timedelta
from math import floor
import re


_ANSI_PAGES = frozenset((874, 932, 936, 949, 950, *range(1250, 1259)))
_UTF8_FIRST_VERSION = 1021
_GREGORIAN_REFORM_DAY = 2299161
_GREGORIAN_ORDINAL_ZERO = 1721425
_JULIAN_YEAR_ONE = 1721424
_MONTH_STARTS = (0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)


def legacy_encoding(page):
    """Map a DXF header's ANSI page to the corresponding Python codec."""
    match = re.search(r'([0-9]+)$', page.strip())
    number = int(match[1]) if match else 1252
    if number not in _ANSI_PAGES:
        number = 1252
    return 'gbk' if number == 936 else f'cp{number}'


def drawing_encoding(version, legacy):
    match = re.fullmatch(r'AC([0-9]{4})', version)
    if match and int(match[1]) >= _UTF8_FIRST_VERSION:
        return 'utf-8-sig'
    return legacy


class RawSection:
    def __init__(self, tags):
        self.tags = tags

    @classmethod
    def from_tags(cls, tags, drawing):
        return cls(tags)

    @property
    def name(self):
        return self.tags[1].value.lower()


def records(tags, *, until, closing, collect):
    """Produce complete DXF sections or tables, including their end tag."""
    record = []
    for tag in tags:
        if not record and tag == (0, until):
            return
        record.append(tag)
        if tag == (0, closing):
            yield collect(record)
            record = []
    raise ValueError(f'DXF stream ended before {closing if record else until}')


def _julian_date_from_day(day):
    cycles, remainder = divmod(day - _JULIAN_YEAR_ONE, 1461)
    year_in_cycle = min(3, remainder // 365)
    year = cycles * 4 + year_in_cycle + 1
    day_of_year = remainder - 365 * year_in_cycle
    leap = year % 4 == 0
    starts = [offset + (leap and i >= 2) for i, offset in enumerate(_MONTH_STARTS)]
    month = max(i for i, offset in enumerate(starts) if offset <= day_of_year)
    return date(year, month + 1, day_of_year - starts[month] + 1)


def calendar_date(value):
    """Decode the DXF day number and fractional day into a naive local datetime."""
    day = floor(value)
    if day >= _GREGORIAN_REFORM_DAY:
        civil = date.fromordinal(day - _GREGORIAN_ORDINAL_ZERO)
    else:
        civil = _julian_date_from_day(day)
    return datetime(civil.year, civil.month, civil.day) + timedelta(seconds=floor((value - day) * 86400))
