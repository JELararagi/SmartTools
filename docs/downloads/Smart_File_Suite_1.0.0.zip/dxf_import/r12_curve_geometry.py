'''Convert the independent R12 curve records from OCS to bounded WCS polylines.

Created through JEL Local Bridge using AI generation, 2026.
Copyright (c) 2026 JELararagi. SPDX-License-Identifier: GPL-3.0-or-later
Original implementation from Autodesk specifications and elementary geometry.
No Blender, third-party implementation, file I/O, scene mutation, or networking.
'''
from __future__ import annotations

from dataclasses import dataclass
import math

from .r12_curve_reader import ArcRecord, CircleRecord

__all__ = ['MAX_SEGMENTS', 'CurveGeometryError', 'OCSBasis', 'CurveGeometry',
           'ocs_basis', 'curve_to_polyline', 'tessellate_curve']
MAX_SEGMENTS = 4096
_POINT = tuple[float, float, float]
_EXTRA_CODES = frozenset((5, 6, 48, 60, 62, 67))


class CurveGeometryError(ValueError):
    '''Stable code, location and details for caller-owned localized messages.'''

    def __init__(self, code, location, **details):
        self.code = code
        self.location = location
        self.details = details
        super().__init__(f'{code}: {location}')


@dataclass(frozen=True)
class OCSBasis:
    x_axis: _POINT
    y_axis: _POINT
    z_axis: _POINT


@dataclass(frozen=True)
class CurveGeometry:
    entity_type: str
    layer: str
    basis: OCSBasis
    center_wcs: _POINT
    start_wcs: _POINT
    mid_wcs: _POINT
    end_wcs: _POINT
    points: tuple[_POINT, ...]
    edges: tuple[tuple[int, int], ...]
    closed: bool
    segments: int
    segment_limit: int
    start_angle_deg: float
    sweep_angle_deg: float
    source_angles_deg: tuple[float, float] | None
    chord_error_bound: float
    requested_chord_error: float | None
    extra_groups: tuple[tuple[int, str], ...]


@dataclass(frozen=True)
class _Prepared:
    kind: str
    layer: str
    basis: OCSBasis
    center: _POINT
    radius: float
    start: float
    sweep: float
    source_angles: tuple[float, float] | None
    extra: tuple[tuple[int, str], ...]


def _number(value, location):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise CurveGeometryError('INVALID_NUMERIC_TYPE', location, actual_type=type(value).__name__)
    try:
        number = float(value)
    except (OverflowError, ValueError) as exc:
        raise CurveGeometryError('NUMERIC_OUT_OF_RANGE', location) from exc
    if not math.isfinite(number):
        raise CurveGeometryError('NONFINITE_NUMBER', location)
    return number


def _vector(value, location):
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        raise CurveGeometryError('INVALID_VECTOR', location)
    return tuple(_number(component, f'{location}[{i}]') for i, component in enumerate(value))


def _unit(values, location):
    scale = max(abs(value) for value in values)
    if scale == 0:
        raise CurveGeometryError('DEGENERATE_BASIS', location)
    scaled = tuple(value / scale for value in values)
    length = math.hypot(*scaled)
    return tuple(value / length for value in scaled)


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def ocs_basis(extrusion) -> OCSBasis:
    '''Return Autodesk's Arbitrary Axis Algorithm basis, including negative Z.

    Normalize by the largest absolute component before computing the length.
    Apply the strict 1/64 polar-cap comparisons to the normalized normal.
    Both generated axes are normalized as specified by Autodesk.
    '''
    raw = _vector(extrusion, 'extrusion')
    if not any(raw):
        raise CurveGeometryError('ZERO_EXTRUSION', 'extrusion')
    normal = _unit(raw, 'extrusion')
    if abs(normal[0]) < 1.0 / 64.0 and abs(normal[1]) < 1.0 / 64.0:
        axis_x = _cross((0.0, 1.0, 0.0), normal)
    else:
        axis_x = _cross((0.0, 0.0, 1.0), normal)
    axis_x = _unit(axis_x, 'basis.x_axis')
    axis_y = _unit(_cross(normal, axis_x), 'basis.y_axis')
    return OCSBasis(axis_x, axis_y, normal)


def _sum_finite(terms, location):
    terms = tuple(terms)
    if not all(math.isfinite(value) for value in terms):
        raise CurveGeometryError('NUMERIC_OVERFLOW', location)
    try:
        total = math.fsum(terms)
    except (OverflowError, ValueError) as exc:
        raise CurveGeometryError('NUMERIC_OVERFLOW', location) from exc
    if not math.isfinite(total):
        raise CurveGeometryError('NUMERIC_OVERFLOW', location)
    return total


def _metadata(value):
    if not isinstance(value, (list, tuple)):
        raise CurveGeometryError('INVALID_METADATA', 'extra_groups')
    result, seen = [], set()
    for index, pair in enumerate(value):
        where = f'extra_groups[{index}]'
        if not isinstance(pair, (list, tuple)) or len(pair) != 2:
            raise CurveGeometryError('INVALID_METADATA', where)
        code, raw = pair
        if isinstance(code, bool) or not isinstance(code, int) or code not in _EXTRA_CODES or code in seen:
            raise CurveGeometryError('INVALID_METADATA', where)
        if not isinstance(raw, str) or not raw.isascii() or any(c in raw for c in '\r\n\x00'):
            raise CurveGeometryError('INVALID_METADATA', where)
        seen.add(code)
        result.append((code, raw))
    return tuple(result)


def _angle(value):
    result = value % 360.0
    return 0.0 if result == 360.0 else result


def _prepare(curve):
    if not isinstance(curve, (CircleRecord, ArcRecord)):
        raise CurveGeometryError('INVALID_CURVE_TYPE', 'curve', actual_type=type(curve).__name__)
    if curve.coordinate_system != 'OCS':
        raise CurveGeometryError('UNSUPPORTED_COORDINATE_SYSTEM', 'coordinate_system')
    center = _vector(curve.center_ocs, 'center_ocs')
    radius = _number(curve.radius, 'radius')
    if radius <= 0:
        raise CurveGeometryError('NONPOSITIVE_RADIUS', 'radius')
    thickness = _number(curve.thickness, 'thickness')
    if thickness != 0:
        raise CurveGeometryError('UNSUPPORTED_THICKNESS', 'thickness')
    layer = curve.layer
    if not isinstance(layer, str) or not layer.strip() or any(ord(c) < 32 or ord(c) > 126 for c in layer):
        raise CurveGeometryError('INVALID_LAYER', 'layer')
    basis = ocs_basis(curve.extrusion)
    axes = (basis.x_axis, basis.y_axis, basis.z_axis)
    world_center = tuple(_sum_finite((center[j] * axes[j][i] for j in range(3)),
                                    f'center_wcs[{i}]') for i in range(3))
    extra = _metadata(curve.extra_groups)
    if isinstance(curve, ArcRecord):
        original = (_number(curve.start_angle_deg, 'start_angle_deg'),
                    _number(curve.end_angle_deg, 'end_angle_deg'))
        start, end = (_angle(value) for value in original)
        sweep = (end - start) % 360.0
        if sweep == 0:
            raise CurveGeometryError('AMBIGUOUS_ARC_SWEEP', 'angles', source_angles=original)
        if not 0 < sweep < 360 or math.radians(sweep) == 0:
            raise CurveGeometryError('ANGLE_RESOLUTION_LOSS', 'angles')
        return _Prepared('ARC', layer, basis, world_center, radius, start, sweep, original, extra)
    return _Prepared('CIRCLE', layer, basis, world_center, radius, 0.0, 360.0, None, extra)


def _sin_cos(degrees):
    angle = _angle(degrees)
    cardinal = {0.0: (0.0, 1.0), 90.0: (1.0, 0.0),
                180.0: (0.0, -1.0), 270.0: (-1.0, 0.0)}
    if angle in cardinal:
        return cardinal[angle]
    radians = math.radians(angle)
    return math.sin(radians), math.cos(radians)


def _point(curve, angle, location):
    sine, cosine = _sin_cos(angle)
    radial_x, radial_y = curve.radius * cosine, curve.radius * sine
    return tuple(_sum_finite((curve.center[i], radial_x * curve.basis.x_axis[i],
                             radial_y * curve.basis.y_axis[i]), f'{location}[{i}]')
                 for i in range(3))


def _limit(value):
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= MAX_SEGMENTS:
        raise CurveGeometryError('INVALID_SEGMENT_LIMIT', 'max_segments', hard_limit=MAX_SEGMENTS)
    return value


def _segment_count(value, curve, limit):
    if isinstance(value, bool) or not isinstance(value, int):
        raise CurveGeometryError('INVALID_SEGMENT_COUNT', 'segments')
    minimum = 3 if curve.kind == 'CIRCLE' else 1
    if value < minimum:
        raise CurveGeometryError('TOO_FEW_SEGMENTS', 'segments', minimum=minimum)
    if value > limit:
        raise CurveGeometryError('SEGMENT_LIMIT_EXCEEDED', 'segments', max_segments=limit)
    return value


def _chord_error(curve, segments):
    # Algebraically r * (1 - cos(delta / 2)), without subtracting near-equal values.
    sine = math.sin(math.radians(curve.sweep) / (4.0 * segments))
    return (curve.radius * sine) * (2.0 * sine)


def _build(curve, segments, limit, requested):
    closed = curve.kind == 'CIRCLE'
    count = segments if closed else segments + 1
    points = tuple(_point(curve, curve.start + curve.sweep * (i / segments), f'points[{i}]')
                   for i in range(count))
    if len(set(points)) != len(points):
        raise CurveGeometryError('COORDINATE_RESOLUTION_LOSS', 'points',
                                 reason='distinct samples collapsed at float precision')
    start, end = points[0], points[0] if closed else points[-1]
    middle = _point(curve, curve.start + curve.sweep / 2.0, 'mid_wcs')
    if middle == start or (not closed and middle == end):
        raise CurveGeometryError('COORDINATE_RESOLUTION_LOSS', 'mid_wcs')
    edges = (tuple((i, (i + 1) % segments) for i in range(segments)) if closed else
             tuple((i, i + 1) for i in range(segments)))
    bound = _chord_error(curve, segments)
    if not math.isfinite(bound):
        raise CurveGeometryError('NUMERIC_OVERFLOW', 'chord_error_bound')
    return CurveGeometry(curve.kind, curve.layer, curve.basis, curve.center, start, middle, end,
                         points, edges, closed, segments, limit, curve.start, curve.sweep,
                         curve.source_angles, bound, requested, curve.extra)


def curve_to_polyline(curve, *, segments: int, max_segments: int = MAX_SEGMENTS) -> CurveGeometry:
    '''Build a fixed-count WCS polyline without mutating the source record.

    Circle: n unique points and n edges, with final edge (n-1,0); n >= 3.
    Arc: n+1 points and n edges, never closed; n >= 1. Sweep is counterclockwise
    in OCS, in (0,360) degrees. Equal normalized ARC endpoints are refused;
    a full circle must use CircleRecord. Original source angles are retained.
    All counts are bounded by max_segments <= 4096 before sample allocation.
    Chord error is the ideal geometric sagitta evaluated in float arithmetic,
    not a guarantee including coordinate rounding, Blender precision or rendering.
    '''
    limit = _limit(max_segments)
    prepared = _prepare(curve)
    count = _segment_count(segments, prepared, limit)
    return _build(prepared, count, limit, None)


def tessellate_curve(curve, *, chord_error: float, max_segments: int = MAX_SEGMENTS) -> CurveGeometry:
    '''Choose the smallest allowed count meeting the ideal sagitta tolerance.

    Tolerance uses the same drawing units as the radius. No unit conversion.
    Search is bounded and monotonic. Failure at the cap is explicit: this function
    does not return a coarser result as success. Float coordinate quantization is
    separate from ideal chord error; collapsed samples are explicitly refused.
    '''
    limit = _limit(max_segments)
    tolerance = _number(chord_error, 'chord_error')
    if tolerance <= 0:
        raise CurveGeometryError('NONPOSITIVE_TOLERANCE', 'chord_error')
    prepared = _prepare(curve)
    low, high = (3 if prepared.kind == 'CIRCLE' else 1), limit
    if high < low:
        raise CurveGeometryError('SEGMENT_LIMIT_TOO_SMALL', 'max_segments', minimum=low)
    best = _chord_error(prepared, high)
    if best > tolerance:
        raise CurveGeometryError('TOLERANCE_UNATTAINABLE', 'chord_error',
                                 requested=tolerance, minimum_error_at_limit=best,
                                 max_segments=limit)
    while low < high:
        middle = (low + high) // 2
        if _chord_error(prepared, middle) <= tolerance:
            high = middle
        else:
            low = middle + 1
    return _build(prepared, low, limit, tolerance)
