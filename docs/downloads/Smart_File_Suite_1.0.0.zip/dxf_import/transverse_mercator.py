# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright 2026 JELararagi
"""Map survey coordinates onto a spherical transverse Mercator grid in metres."""
from math import asinh, atan2, cos, degrees, exp, hypot, isfinite, radians, sin, tanh


class TransverseMercator:
    radius = 6378137

    def __init__(self, lat=0, lon=0):
        self.lat = lat
        self.lon = lon
        self.lat_rad = radians(lat)
        self.lon_rad = radians(lon)
        if not -90 <= lat <= 90 or not isfinite(lon):
            raise ValueError("Invalid projection origin")

    def fromGeographic(self, lat, lon):
        if not -90 <= lat <= 90 or not isfinite(lon):
            raise ValueError("Invalid geographic coordinates")
        latitude = radians(lat)
        offset = radians(lon - self.lon)
        # Components of a unit position in the frame of the central meridian.
        east = cos(latitude) * sin(offset)
        front = cos(latitude) * cos(offset)
        north = sin(latitude)
        meridian_length = hypot(front, north)
        if lat == 0 and abs((lon - self.lon) % 180) == 90:
            raise ValueError("The transverse Mercator grid is singular at this longitude")
        easting = self.radius * asinh(east / meridian_length)
        northing = self.radius * (atan2(north, front) - self.lat_rad)
        return easting, northing

    def toGeographic(self, x, y):
        if not isfinite(x) or not isfinite(y):
            raise ValueError("Invalid grid coordinates")
        easting = x / self.radius
        direction = y / self.radius + self.lat_rad
        # sech(easting) with a bounded exponential, even at the edge of the map.
        small = exp(-abs(easting))
        meridian_length = 2 * small / (1 + small * small)
        east = tanh(easting)
        front = meridian_length * cos(direction)
        north = meridian_length * sin(direction)
        latitude = degrees(atan2(north, hypot(front, east)))
        longitude = self.lon + degrees(atan2(east, front))
        return latitude, longitude
