"""Convert the standalone R12 reader's geometry to Blender mesh objects.

Implemented by Codex (AI-assisted), 2026. Attribution / release name: JELararagi.
Copyright (c) 2026 JELararagi. SPDX-License-Identifier: GPL-3.0-or-later
"""
from dataclasses import dataclass
import math
import struct

import bpy
from .r12_reader import Face3D, ImportResult, LegacyPolyline, Line3D, Point3D


class MeshInputError(ValueError):
    """The drawing cannot be represented by this geometry-only adapter."""


@dataclass(frozen=True)
class _Part:
    kind: str
    layer: str
    points: tuple
    edges: tuple = ()
    faces: tuple = ()


def _point(values):
    if len(values) != 3 or not all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in values):
        raise MeshInputError("expected three numeric coordinates")
    try:
        xyz = struct.unpack('=3f', struct.pack('=3f', *values))
    except (OverflowError, struct.error) as exc:
        raise MeshInputError("coordinate outside Blender's float32 range") from exc
    if not all(math.isfinite(v) for v in xyz):
        raise MeshInputError("non-finite coordinate in Blender's float32 range")
    return xyz


def _face(entity):
    if entity.invisible_edges:
        raise MeshInputError("3DFACE invisible-edge display is unsupported")
    points = tuple(_point(p) for p in entity.vertices)
    if len(points) not in (3, 4) or len(set(points)) != len(points):
        raise MeshInputError("3DFACE requires three or four distinct corners")
    # Its oriented area vector vanishes for a collapsed polygon.
    normal = [0., 0., 0.]
    for a, b in zip(points, points[1:] + points[:1]):
        normal[0] += (a[1] - b[1]) * (a[2] + b[2])
        normal[1] += (a[2] - b[2]) * (a[0] + b[0])
        normal[2] += (a[0] - b[0]) * (a[1] + b[1])
    if not any(normal):
        raise MeshInputError("3DFACE has zero oriented area")
    return _Part("3DFACE", entity.layer, points, faces=(tuple(range(len(points))),))


def _polyline(entity):
    expected_flags = int(entity.closed) | (8 if entity.is_3d else 0)
    if entity.flags != expected_flags:
        raise MeshInputError("only plain open/closed 2D and 3D POLYLINE flags are supported")
    if entity.coordinate_system != ('WCS' if entity.is_3d else 'OCS'):
        raise MeshInputError("unexpected POLYLINE coordinate system")
    if entity.is_3d and entity.elevation != 0:
        raise MeshInputError("3D POLYLINE header elevation is unsupported")
    points = []
    for raw in entity.vertices:
        if not entity.is_3d:
            if len(raw) != 3 or raw[2] != 0:
                raise MeshInputError("2D POLYLINE requires zero per-vertex z")
            raw = (raw[0], raw[1], entity.elevation)
        points.append(_point(raw))
    if entity.closed and points and points[-1] == points[0]:
        points.pop()
    if len(points) < (3 if entity.closed else 2):
        raise MeshInputError("too few distinct positions for a POLYLINE")
    edges = [(i, i + 1) for i in range(len(points) - 1)]
    if entity.closed:
        edges.append((len(points) - 1, 0))
    if any(points[i] == points[j] for i, j in edges):
        raise MeshInputError("POLYLINE contains a zero-length segment")
    return _Part("POLYLINE", entity.layer, tuple(points), tuple(edges))


def _part(entity):
    if isinstance(entity, Point3D):
        return _Part("POINT", entity.layer, (_point(entity.position),))
    if isinstance(entity, Line3D):
        points = (_point(entity.start), _point(entity.end))
        if points[0] == points[1]:
            raise MeshInputError("LINE has zero length at Blender precision")
        return _Part("LINE", entity.layer, points, ((0, 1),))
    if isinstance(entity, Face3D):
        return _face(entity)
    if isinstance(entity, LegacyPolyline):
        return _polyline(entity)
    raise MeshInputError(f"unsupported intermediate entity: {type(entity).__name__}")


def create_mesh_objects(drawing, collection):
    """Create one object per entity in the given collection, or leave no new IDs.

    Requires an ImportResult from the separately supplied r12_reader. Coordinates use
    drawing units with identity object transforms. The caller owns the returned objects.
    """
    if not isinstance(drawing, ImportResult):
        raise TypeError("expected r12_reader.ImportResult")
    if drawing.unknown_entities:
        counts = ', '.join(f'{name} x{count}' for name, count in drawing.unknown_entities)
        raise MeshInputError('unsupported ENTITIES records: ' + counts)
    parts = tuple(_part(entity) for entity in drawing.entities)
    if not parts:
        raise MeshInputError("no supported geometry to import")
    objects, meshes = [], []
    try:
        for part in parts:
            name = f'DXF {part.kind} {part.layer}'
            mesh = bpy.data.meshes.new(name)
            meshes.append(mesh)
            mesh.from_pydata(part.points, part.edges, part.faces)
            if mesh.validate():
                raise MeshInputError("Blender repaired the proposed geometry")
            mesh.update()
            obj = bpy.data.objects.new(name, mesh)
            objects.append(obj)
            obj['dxf_layer'] = part.layer
            obj['dxf_entity'] = part.kind
            collection.objects.link(obj)
    except BaseException:
        for obj in reversed(objects):
            bpy.data.objects.remove(obj, do_unlink=True)
        for mesh in reversed(meshes):
            bpy.data.meshes.remove(mesh)
        raise
    return tuple(objects)
