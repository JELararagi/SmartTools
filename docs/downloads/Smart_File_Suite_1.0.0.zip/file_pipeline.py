# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""File Pipeline: cross-DCC file, reference, package, and pipeline hub.

This feature layer implements Blender-native equivalents of the external
reference, path management, package, version, assembly, cache, shot, prefab, and
pipeline concepts listed in the attached DCC reference-management survey.  It is
loaded as part of the Smart File shared bootstrap namespace and exposes all
user controls from the Smart File N-panel, not Blender Add-on Preferences.
"""

from __future__ import annotations

from .ui_language_runtime import ui_text as _ui_text
import datetime as _datetime
import difflib as _difflib
import fnmatch as _fnmatch
import hashlib as _hashlib
import json as _json
import os as _os
from pathlib import Path as _Path
import re as _re
import shutil as _shutil
import zipfile as _zipfile
import unicodedata as _unicodedata

import bpy
from bpy.props import BoolProperty, EnumProperty, IntProperty, StringProperty

# Import the same icon facade in foreground and background Blender.  The
# facade itself performs no preview allocation until an explicit UI request.
try:
    from .file_pipeline_icons import icon_id as _sfsmart_icon_id, icon_path as _sfsmart_icon_path, load_icons as _sfsmart_load_icons, missing_icon_files as _sfsmart_missing_icon_files, unload_icons as _sfsmart_unload_icons
except Exception:  # pragma: no cover - static import / partial bootstrap fallback
    _sfsmart_icon_id = _sfsmart_icon_path = _sfsmart_load_icons = _sfsmart_missing_icon_files = _sfsmart_unload_icons = None

if not callable(_sfsmart_icon_id):
    def _sfsmart_icon_id(_name: str, fallback: int = 0) -> int:
        return int(fallback or 0)
if not callable(_sfsmart_icon_path):
    def _sfsmart_icon_path(_name: str = '') -> str:
        return ''
if not callable(_sfsmart_load_icons):
    def _sfsmart_load_icons(force: bool = False):
        return None
if not callable(_sfsmart_missing_icon_files):
    def _sfsmart_missing_icon_files() -> list[str]:
        return []
if not callable(_sfsmart_unload_icons):
    def _sfsmart_unload_icons() -> None:
        return None

try:
    _t
except NameError:  # pragma: no cover - fallback when statically importing this file.
    def _t(text):
        return str(text)

try:
    _tt
except NameError:  # pragma: no cover
    def _tt(text):
        return str(text)

try:
    _sf_short_label_display
except NameError:  # pragma: no cover
    def _sf_short_label_display(text, max_len=72):
        text = str(text or '')
        return text if len(text) <= max_len else text[: max(1, max_len - 1)] + '…'

try:
    _sf_draw_help_button
except NameError:  # pragma: no cover
    def _sf_draw_help_button(parent, **kwargs):
        return None

try:
    _sf_draw_empty_state
except NameError:  # pragma: no cover
    def _sf_draw_empty_state(parent, title, body='', icon='NONE'):
        box = parent.box()
        box.label(text=str(title), icon=icon)
        if body:
            box.label(text=str(body), icon='BLANK1')
        return box

try:
    _sf_append_activity
except NameError:  # pragma: no cover
    def _sf_append_activity(context, title, detail='', icon='NONE'):
        return None

try:
    _sf_operator_idname_registered
except NameError:  # pragma: no cover
    def _sf_operator_idname_registered(_idname):
        return True

try:
    _sf_lane_tool_entry
except NameError:  # pragma: no cover
    def _sf_lane_tool_entry(label, operator, icon='CHECKMARK', detail='', props=None, enabled=True, keywords=''):
        return {'label': label, 'operator': operator, 'icon': icon, 'detail': detail, 'props': dict(props or {}), 'enabled': bool(enabled), 'keywords': keywords}


_SFSMART_REPORT_TEXT = 'File Pipeline Report'
_SFSMART_DELTA_NAME = 'file_pipeline_delta.json'
_SFSMART_PLAN_NAME = 'file_pipeline_plan.json'
_SFSMART_CATALOG_NAME = 'file_pipeline_catalog.json'
_SFSMART_MANIFEST_NAME = 'file_pipeline_manifest.json'
_SFSMART_LOCK_NAME = 'file_pipeline_lock.json'
_SFSMART_LEGACY_DELTA_NAME = 'smart_file_smart_delta.json'  # keep-legacy-name
_SFSMART_LEGACY_MANIFEST_NAME = 'smart_file_smart_manifest.json'  # keep-legacy-name

_SFSMART_ASSET_EXTENSIONS = {
    '.blend': 'library',
    '.usd': 'usd', '.usda': 'usd', '.usdc': 'usd', '.usdz': 'usd',
    '.abc': 'cache', '.vdb': 'volume', '.bgeo': 'cache', '.bgeo.sc': 'cache',
    '.fbx': 'model', '.obj': 'model', '.gltf': 'model', '.glb': 'model', '.stl': 'model', '.dae': 'model', '.3ds': 'model', '.max': 'model', '.c4d': 'model', '.lwo': 'model', '.lws': 'model', '.skp': 'model', '.emdl': 'model', '.ztl': 'model',
    '.png': 'texture', '.jpg': 'texture', '.jpeg': 'texture', '.tif': 'texture', '.tiff': 'texture', '.exr': 'texture', '.hdr': 'texture', '.tx': 'texture', '.tga': 'texture', '.bmp': 'texture', '.webp': 'texture', '.dds': 'texture',
    '.ies': 'light',
    '.wav': 'audio', '.mp3': 'audio', '.flac': 'audio', '.ogg': 'audio',
    '.ttf': 'font', '.otf': 'font', '.woff': 'font', '.woff2': 'font',
    '.py': 'script', '.json': 'metadata', '.toml': 'metadata', '.yaml': 'metadata', '.yml': 'metadata', '.xml': 'metadata',
}

_SFSMART_SKIP_DIRS = {'__pycache__', '.git', '.svn', '.hg', 'node_modules', '.cache', '.mypy_cache', '.pytest_cache', 'Thumbs.db'}
_SFSMART_SEQUENCE_TOKENS = ('<UDIM>', '<udim>', '####')
_SFSMART_BINARY_USD_EXTS = {'.usdc', '.usdz'}

_SFSMART_ACTION_ITEMS = [
    ('PIPELINE_PREFLIGHT', 'Pipeline Preflight', 'Analyze the current scene once and produce a prioritized, production-style repair plan before any destructive action.'),
    ('SMART_RESOLVE_MISSING', 'Resolve Missing', 'Find missing external references with scored candidates from Search Root, store a plan, and apply only confident matches when Apply Changes is enabled.'),
    ('PORTABLE_HANDOFF_PACK', 'Portable Handoff Pack', 'Run preflight, build inventory, collect assets, verify the package, and write a single downstream handoff manifest.'),
    ('SCAN_REFERENCES', 'Reference Inventory', 'List linked libraries, textures, cache files, fonts, sounds, volumes, and source ownership.'),
    ('COLLECT_ASSETS', 'Collect Package', 'Copy external assets into a portable bundle, write a manifest, and optionally zip the package.'),
    ('VERIFY_PACKAGE', 'Verify Package', 'Verify the latest collected package by checking copied members, missing targets, file sizes, and SHA-1 hashes when available.'),
    ('REPATH_PREVIEW', 'Preview Repath', 'Build a safe path-replacement or missing-file search plan without changing any file paths.'),
    ('REPATH_APPLY', 'Apply Repath', 'Apply the current prefix replacement or missing-file search plan to Blender datablock paths when Apply Changes is on. When it is off, only the plan is reported.'),
    ('RELATIVE_PATHS', 'Make Paths Relative', 'Convert external asset paths to Blender-relative paths when the current file is saved and Apply Changes is on. When it is off, only the target paths are reported.'),
    ('RELOAD_LIBRARIES', 'Reload Libraries', 'Reload linked .blend libraries from disk.'),
    ('MAKE_LOCAL', 'Materialize Links', 'Convert selected or all linked datablocks to local editable data where Blender permits it.'),
    ('OVERRIDE_SELECTED', 'Make Library Overrides', 'Create library overrides for the current selection using Blender supported operators.'),
    ('DISABLE_LINKED', 'Proxy Display', 'Switch linked objects into lightweight hidden, bounds, or wire proxy states.'),
    ('RESTORE_LINKED_VISIBILITY', 'Restore Display', 'Restore linked-object visibility, selectability, renderability, and display type.'),
    ('CAPTURE_DELTA', 'Capture Delta', 'Save sparse local edits such as transforms, visibility, material slots, and selected custom properties.'),
    ('COMPARE_DELTA', 'Compare Delta', 'Compare the current scene against the saved File Pipeline delta snapshot.'),
    ('RESTORE_DELTA', 'Restore Delta', 'Restore object transforms, visibility, and display states from the saved delta snapshot.'),
    ('SHOT_MANIFEST', 'Shot Manifest', 'Export camera, marker, frame-range, output, view layer, and visibility-state handoff data.'),
    ('CAMERA_QUEUE', 'Camera Queue', 'Create a camera render queue manifest from scene cameras or timeline markers.'),
    ('CATALOG_INDEX', 'Build Asset Catalog', 'Scan the project or search root and create a searchable catalog of models, caches, textures, scripts, and .blend files.'),
    ('CATALOG_DUPLICATE_AUDIT', 'Catalog Duplicate Audit', 'Detect duplicate catalog entries and external references by normalized name, extension, size, optional hash, and version family.'),
    ('USD_MANIFEST', 'USD Layer Manifest', 'Write a USD-style composition manifest with sublayers, payload candidates, references, and variants.'),
    ('VERSION_PLAN', 'Version Upgrade Plan', 'Detect v001-style asset versions and propose newer compatible targets from the project root.'),
    ('APPLY_VERSION_PLAN', 'Apply Version Plan', 'Apply the saved version upgrade plan to matching external references when Apply Changes is on. When it is off, only the plan is reported.'),
    ('CACHE_SCAN', 'Cache Report', 'Report Alembic, USD, VDB, image-sequence, and cache-file references.'),
    ('TEXTURE_EXTENSION_SWAP', 'Texture Extension Swap', 'Preview or apply texture extension replacement, such as PNG to TIFF, only when replacement files exist.'),
    ('NAMING_REPORT', 'Naming Cleanup Report', 'Report unsafe names, duplicate names, path-token issues, and optional safe rename suggestions.'),
    ('MATERIAL_RULES', 'Material Rule Manifest', 'Export Katana and Clarisse style material assignment rules from object, collection, library, material-slot, and image dependency data.'),
    ('CHECKOUT', 'Check Out Lock', 'Create a lock record for the current scene or selected linked source under the Smart File CONFIG data root.'),
    ('CHECKIN', 'Check In Unlock', 'Remove the File Pipeline lock record and report who held it.'),
    ('ENGINE_MANIFEST', 'Engine Prefab Manifest', 'Export Unreal and Unity style prefab, addressable, and nested-reference handoff metadata.'),
    ('EXPORT_HIERARCHY_AS_LIBRARY', 'Export Selected Hierarchy', 'Write selected object hierarchies as a new linked .blend library file.'),
    ('PROJECT_QUALITY_AUDIT', 'Project Quality Audit', 'Score portability, missing links, unsafe names, absolute paths, sequence coverage, version drift, lock state, and handoff readiness in one report.'),
    ('DEPENDENCY_GRAPH', 'Dependency Graph', 'Write a scored graph of Blender datablocks, external files, linked libraries, objects, collections, references, and package relationships for technical review.'),
    ('PUBLISH_CONTAINER', 'Publish Container Manifest', 'Create an AYON and Prism style publish-load container manifest with stable IDs, representations, dependencies, and downstream handoff metadata.'),
    ('PIPELINE_SUPER_MANIFEST', 'Pipeline Super Manifest', 'Write one studio handoff manifest combining inventory, dependency graph, preflight score, package state, catalog summary, shot data, engine data, and USD data.'),
    ('EDIT_LINKED_LIBRARY', 'Edit Linked Library', 'Open the selected linked library after writing a return ticket when Apply Changes is enabled; otherwise preview the target safely.'),

]

_SFSMART_ACTION_ICON_KEYS = {
    'PIPELINE_PREFLIGHT': 'preflight',
    'SMART_RESOLVE_MISSING': 'resolve',
    'PORTABLE_HANDOFF_PACK': 'handoff',
    'SCAN_REFERENCES': 'inventory',
    'COLLECT_ASSETS': 'collect',
    'VERIFY_PACKAGE': 'verify',
    'REPATH_PREVIEW': 'repath_preview',
    'REPATH_APPLY': 'repath_apply',
    'RELATIVE_PATHS': 'relative',
    'RELOAD_LIBRARIES': 'reload',
    'MAKE_LOCAL': 'localize',
    'OVERRIDE_SELECTED': 'override',
    'DISABLE_LINKED': 'proxy',
    'RESTORE_LINKED_VISIBILITY': 'restore_display',
    'CAPTURE_DELTA': 'delta_capture',
    'COMPARE_DELTA': 'delta_compare',
    'RESTORE_DELTA': 'delta_restore',
    'SHOT_MANIFEST': 'shot',
    'CAMERA_QUEUE': 'camera_queue',
    'CATALOG_INDEX': 'catalog',
    'CATALOG_DUPLICATE_AUDIT': 'duplicate_audit',
    'USD_MANIFEST': 'usd',
    'VERSION_PLAN': 'version_plan',
    'APPLY_VERSION_PLAN': 'apply_version',
    'CACHE_SCAN': 'cache',
    'TEXTURE_EXTENSION_SWAP': 'texture_swap',
    'NAMING_REPORT': 'naming',
    'MATERIAL_RULES': 'material_rules',
    'CHECKOUT': 'checkout',
    'CHECKIN': 'checkin',
    'ENGINE_MANIFEST': 'engine',
    'EXPORT_HIERARCHY_AS_LIBRARY': 'export_hierarchy',
    'PROJECT_QUALITY_AUDIT': 'quality_audit',
    'DEPENDENCY_GRAPH': 'dependency_graph',
    'PUBLISH_CONTAINER': 'publish_container',
    'PIPELINE_SUPER_MANIFEST': 'super_manifest',
    'EDIT_LINKED_LIBRARY': 'edit_library',
}
_SFSMART_ACTION_LABEL_MAP = {item[0]: item[1] for item in _SFSMART_ACTION_ITEMS}
_SFSMART_ACTION_DESC_MAP = {item[0]: item[2] for item in _SFSMART_ACTION_ITEMS}


def _sfsmart_now_slug() -> str:
    return _datetime.datetime.now().strftime('%Y%m%d_%H%M%S')


def _sfsmart_norm(path: object) -> str:
    value = str(path or '').strip()
    if not value:
        return ''
    try:
        if value.startswith('//'):
            value = bpy.path.abspath(value)
    except Exception:
        pass
    try:
        return _os.path.normpath(_os.path.expandvars(_os.path.expanduser(value)))
    except Exception:
        return value


def _sfsmart_rel(path: str) -> str:
    path = _sfsmart_norm(path)
    if not path:
        return ''
    try:
        if bpy.data.filepath:
            return bpy.path.relpath(path)
    except Exception:
        pass
    return path


def _sfsmart_user_dir(*parts: str, create: bool = True) -> str:
    try:
        from .storage_paths import user_default_dir  # type: ignore
        base = user_default_dir('file_pipeline', create=False)
        legacy = user_default_dir('smart_file_smart', create=False)  # keep-legacy-name
        if _os.path.isdir(base) or not _os.path.isdir(legacy):
            base = user_default_dir('file_pipeline', create=create)
        else:
            base = legacy
    except Exception:
        if _os.name == 'nt':
            roaming = _os.environ.get('APPDATA') or _os.path.join(_os.path.expanduser('~'), 'AppData', 'Roaming')
            root = _os.path.join(roaming, 'Blender Foundation', 'Blender', '5.1', 'config', 'Smart_File_Suite')
        else:
            root = _os.path.join(_os.environ.get('XDG_CONFIG_HOME', _os.path.join(_os.path.expanduser('~'), '.config')), 'blender', '5.1', 'config', 'Smart_File_Suite')
        base = _os.path.join(root, 'file_pipeline')
        legacy = _os.path.join(root, 'smart_file_smart')  # keep-legacy-name
        if not _os.path.isdir(base) and _os.path.isdir(legacy):
            base = legacy
        if create:
            _os.makedirs(base, exist_ok=True)
    path = _os.path.join(base, *[str(p).strip('/\\') for p in parts if str(p or '').strip()])
    if create:
        _os.makedirs(path, exist_ok=True)
    return path


def _sfsmart_project_root(context=None) -> str:
    wm = getattr(context or bpy.context, 'window_manager', None)
    for name in ('sf_smart_project_root', 'sf_smart_search_root'):
        try:
            value = _sfsmart_norm(getattr(wm, name, '') or '')
            if value and _os.path.isdir(value):
                return value
        except Exception:
            pass
    try:
        if bpy.data.filepath:
            return _os.path.dirname(_sfsmart_norm(bpy.data.filepath))
    except Exception:
        pass
    return _sfsmart_user_dir('project', create=True)


def _sfsmart_output_dir(context=None, *subdirs: str) -> str:
    wm = getattr(context or bpy.context, 'window_manager', None)
    try:
        manual = _sfsmart_norm(getattr(wm, 'sf_smart_bundle_dir', '') or '')
    except Exception:
        manual = ''
    if manual:
        path = _os.path.join(manual, *[str(s).strip('/\\') for s in subdirs if str(s or '').strip()])
    else:
        path = _sfsmart_user_dir('outputs', *subdirs, create=False)
    _os.makedirs(path, exist_ok=True)
    return path


def _sfsmart_safe_json(value) -> str:
    try:
        return _json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)
    except Exception:
        return '{}'


def _sfsmart_read_json_file(path: str, fallback=None):
    try:
        if path and _os.path.isfile(path):
            with open(path, 'r', encoding='utf-8') as handle:
                data = _json.load(handle)
            return data
    except Exception:
        pass
    return fallback if fallback is not None else {}


def _sfsmart_write_json(path: str, data) -> str:
    _os.makedirs(_os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as handle:
        _json.dump(data, handle, ensure_ascii=False, indent=2, sort_keys=True)
    return path


def _sfsmart_text_report(title: str, payload, *, text_name: str = _SFSMART_REPORT_TEXT) -> str:
    lines = []
    lines.append(f'File Pipeline | {title}')
    lines.append(f'Time: {_datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
    try:
        lines.append(f'Blend: {bpy.data.filepath or "(unsaved)"}')
    except Exception:
        pass
    lines.append('')
    if isinstance(payload, str):
        lines.extend(payload.splitlines())
    elif isinstance(payload, list):
        for item in payload:
            if isinstance(item, str):
                lines.append(item)
            else:
                lines.append(_sfsmart_safe_json(item))
    else:
        lines.append(_sfsmart_safe_json(payload))
    text_body = '\n'.join(lines).rstrip() + '\n'
    try:
        text = bpy.data.texts.get(text_name) or bpy.data.texts.new(text_name)
        text.clear()
        text.write(text_body)
    except Exception:
        pass
    return text_body


def _sfsmart_set_last_report(context, title: str, payload, path: str = '') -> None:
    wm = getattr(context or bpy.context, 'window_manager', None)
    body = _sfsmart_text_report(title, payload)
    try:
        setattr(wm, 'sf_smart_last_report_title', str(title or ''))
        setattr(wm, 'sf_smart_last_report_path', str(path or ''))
        setattr(wm, 'sf_smart_last_report', body[:16000])
    except Exception:
        pass
    try:
        _sf_append_activity(context, f'File Pipeline: {title}', path or '', 'ASSET_MANAGER')
    except Exception:
        pass


def _sfsmart_path_exists(path: str) -> bool:
    return bool(path and _os.path.exists(_sfsmart_norm(path)))


def _sfsmart_file_hash(path: str) -> str:
    try:
        h = _hashlib.sha1()
        with open(path, 'rb') as fh:
            for chunk in iter(lambda: fh.read(1024 * 1024), b''):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return ''


def _sfsmart_stable_hash_text(value: object, length: int = 16) -> str:
    try:
        digest = _hashlib.sha1(str(value or '').encode('utf-8', errors='ignore')).hexdigest()
        return digest[: max(8, min(40, int(length or 16)))]
    except Exception:
        return ''


def _sfsmart_normcase(path: object) -> str:
    return _os.path.normcase(_sfsmart_norm(path))


def _sfsmart_stat_record(path: str) -> dict:
    path = _sfsmart_norm(path)
    try:
        st = _os.stat(path)
        return {
            'size': int(st.st_size),
            'mtime': int(st.st_mtime),
            'mtime_iso': _datetime.datetime.fromtimestamp(st.st_mtime).isoformat(timespec='seconds'),
        }
    except Exception:
        return {'size': 0, 'mtime': 0, 'mtime_iso': ''}


def _sfsmart_env_tokens_for_path(path: str) -> list[str]:
    norm = _sfsmart_norm(path)
    tokens = []
    try:
        for key, value in _os.environ.items():
            if not value or len(value) < 4:
                continue
            value_norm = _sfsmart_norm(value)
            if value_norm and _sfsmart_normcase(norm).startswith(_sfsmart_normcase(value_norm)):
                tokens.append('%' + key + '%' if _os.name == 'nt' else '$' + key)
        return sorted(set(tokens), key=lambda x: (len(x), x))[:8]
    except Exception:
        return []


def _sfsmart_project_rel(path: str, root: str = '') -> str:
    path = _sfsmart_norm(path)
    root = _sfsmart_norm(root) or _sfsmart_project_root(None)
    try:
        if root and _os.path.commonpath([path, root]) == root:
            return _os.path.relpath(path, root)
    except Exception:
        pass
    try:
        if bpy.data.filepath:
            blend_root = _os.path.dirname(_sfsmart_norm(bpy.data.filepath))
            if blend_root and _os.path.commonpath([path, blend_root]) == blend_root:
                return _os.path.relpath(path, blend_root)
    except Exception:
        pass
    return ''


def _sfsmart_common_root(paths: list[str]) -> str:
    clean = [_sfsmart_norm(p) for p in paths if p]
    if not clean:
        return ''
    try:
        return _os.path.commonpath(clean)
    except Exception:
        return ''


def _sfsmart_skip_dirs(dirs: list[str]) -> list[str]:
    return [d for d in dirs if d not in _SFSMART_SKIP_DIRS and not d.startswith('.')]


def _sfsmart_scan_files(root: str, *, max_files: int = 50000, extensions: set[str] | None = None):
    root = _sfsmart_norm(root)
    scanned = 0
    if not root or not _os.path.isdir(root):
        return
    for current, dirs, files in _os.walk(root):
        dirs[:] = _sfsmart_skip_dirs(dirs)
        for name in files:
            full = _os.path.join(current, name)
            ext = _os.path.splitext(name)[1].lower()
            if extensions and ext not in extensions:
                continue
            scanned += 1
            yield full
            if scanned >= max_files:
                return


def _sfsmart_sequence_glob_candidates(path: str) -> list[str]:
    path = _sfsmart_norm(path)
    folder = _os.path.dirname(path)
    name = _os.path.basename(path)
    if not folder or not _os.path.isdir(folder) or not name:
        return []
    patterns = []
    # UDIM token and hash/printf frame tokens.
    tokenized = name.replace('<UDIM>', '[0-9][0-9][0-9][0-9]').replace('<udim>', '[0-9][0-9][0-9][0-9]')
    tokenized = tokenized.replace('####', '[0-9][0-9][0-9][0-9]')
    tokenized = _re.sub(r'%0?(\d+)d', lambda m: '[0-9]' * max(1, min(8, int(m.group(1) or 1))), tokenized)
    if tokenized != name:
        patterns.append(tokenized)
    # Existing frame-number form such as plate_1001.exr. Require 3+ digits to avoid false positives.
    stem, ext = _os.path.splitext(name)
    m = _re.search(r'(?P<prefix>.*?)(?P<num>\d{3,6})(?P<suffix>[^\d]*)$', stem)
    if m:
        patterns.append(_fnmatch.translate(m.group('prefix') + ('[0-9]' * len(m.group('num'))) + m.group('suffix') + ext))
        # The translate result is regex, so handled below.
    hits = []
    try:
        for sibling in _os.listdir(folder):
            full = _os.path.join(folder, sibling)
            if not _os.path.isfile(full):
                continue
            matched = False
            for pat in patterns:
                if pat.startswith('(?s:'):
                    try:
                        matched = bool(_re.match(pat, sibling))
                    except Exception:
                        matched = False
                else:
                    matched = _fnmatch.fnmatchcase(sibling, pat)
                if matched:
                    hits.append(full)
                    break
    except Exception:
        return []
    return sorted(set(hits), key=lambda p: _os.path.basename(p).lower())


def _sfsmart_expand_path_family(path: str, *, max_members: int = 2000) -> list[str]:
    path = _sfsmart_norm(path)
    if not path:
        return []
    hits = []
    if _os.path.isfile(path):
        hits.append(path)
    seq_hits = _sfsmart_sequence_glob_candidates(path)
    for item in seq_hits:
        if _os.path.isfile(item):
            hits.append(item)
        if len(hits) >= max_members:
            break
    return sorted(set(hits), key=lambda p: _os.path.basename(p).lower())


def _sfsmart_sequence_summary(path: str) -> dict:
    family = _sfsmart_expand_path_family(path)
    basename = _os.path.basename(_sfsmart_norm(path))
    tokenized = any(tok in basename for tok in _SFSMART_SEQUENCE_TOKENS) or bool(_re.search(r'%0?\d+d', basename))
    frame_numbers = []
    for member in family[:5000]:
        m = _re.search(r'(\d{3,6})(?=\D*\.[^.]+$)', _os.path.basename(member))
        if m:
            try:
                frame_numbers.append(int(m.group(1)))
            except Exception:
                pass
    return {
        'is_sequence': bool(tokenized or len(family) > 1),
        'family_count': len(family),
        'first_frame': min(frame_numbers) if frame_numbers else None,
        'last_frame': max(frame_numbers) if frame_numbers else None,
        'members': family[:200],
    }


def _sfsmart_safe_filename(value: object, fallback: str = 'item') -> str:
    text = _unicodedata.normalize('NFKC', str(value or '')).strip()
    text = _re.sub(r'[<>:"/\\|?*\x00-\x1F]+', '_', text)
    text = _re.sub(r'\s+', '_', text)
    text = _re.sub(r'_+', '_', text).strip('._ ')
    if not text:
        text = fallback
    reserved = {'CON', 'PRN', 'AUX', 'NUL', *(f'COM{i}' for i in range(1, 10)), *(f'LPT{i}' for i in range(1, 10))}
    if text.upper().split('.')[0] in reserved:
        text = '_' + text
    return text[:180]


def _sfsmart_safe_relative_for_copy(src: str, *, kind: str, target_root: str, project_root: str, search_root: str) -> str:
    src = _sfsmart_norm(src)
    roots = [project_root, search_root, _os.path.dirname(_sfsmart_norm(bpy.data.filepath or ''))]
    for root in roots:
        root = _sfsmart_norm(root)
        try:
            if root and _os.path.commonpath([src, root]) == root:
                rel = _os.path.relpath(src, root)
                if not rel.startswith('..'):
                    parts = [_sfsmart_safe_filename(part) for part in rel.replace('\\', '/').split('/')]
                    return _os.path.join(_sfsmart_classify_subdir(kind), *parts)
        except Exception:
            pass
    return _os.path.join(_sfsmart_classify_subdir(kind), _sfsmart_safe_filename(_os.path.basename(src)))


def _sfsmart_destination_for_source(src: str, *, target_root: str, kind: str, used: set[str], project_root: str, search_root: str) -> str:
    rel = _sfsmart_safe_relative_for_copy(src, kind=kind, target_root=target_root, project_root=project_root, search_root=search_root)
    dst = _os.path.join(target_root, rel)
    base, ext = _os.path.splitext(dst)
    index = 1
    while _sfsmart_normcase(dst) in used and _sfsmart_normcase(dst) != _sfsmart_normcase(src):
        dst = f'{base}_{index:03d}{ext}'
        index += 1
    used.add(_sfsmart_normcase(dst))
    return dst


def _sfsmart_owner_key(owner) -> str:
    try:
        lib = getattr(owner, 'library', None)
        lib_path = _sfsmart_norm(getattr(lib, 'filepath', '') or '') if lib else ''
        ident = str(getattr(getattr(owner, 'bl_rna', None), 'identifier', '') or type(owner).__name__)
        return _sfsmart_stable_hash_text(f'{ident}|{lib_path}|{getattr(owner, "name_full", getattr(owner, "name", ""))}', 20)
    except Exception:
        return _sfsmart_stable_hash_text(str(owner), 20)


def _sfsmart_object_key(obj) -> str:
    try:
        lib = _sfsmart_norm(getattr(getattr(obj, 'library', None), 'filepath', '') or '')
        data_name = str(getattr(getattr(obj, 'data', None), 'name', '') or '')
        return _sfsmart_stable_hash_text(f'{lib}|{obj.name}|{data_name}|{getattr(obj, "type", "")}', 20)
    except Exception:
        return _sfsmart_stable_hash_text(str(getattr(obj, 'name', 'object')), 20)


def _sfsmart_similarity_tokens(path: str) -> set[str]:
    path = _sfsmart_norm(path).lower().replace('\\', '/')
    parts = []
    for part in path.split('/'):
        parts.extend(_re.split(r'[^0-9a-zA-Z_]+', part))
    stop = {'tex', 'texture', 'textures', 'img', 'image', 'cache', 'assets', 'asset', 'source', 'src', 'final', 'publish'}
    return {p for p in parts if len(p) >= 2 and not p.isdigit() and p not in stop}


def _sfsmart_normalized_stem(path: str) -> str:
    stem = _os.path.splitext(_os.path.basename(_sfsmart_norm(path)))[0].lower()
    stem = stem.replace('<udim>', '####')
    stem = _re.sub(r'%0?\d+d', '####', stem)
    stem = _re.sub(r'(?<![a-zA-Z])\d{3,6}(?![a-zA-Z])', '####', stem)
    stem = _re.sub(r'[_\-.\s]+', '_', stem)
    return stem.strip('_')


def _sfsmart_sequence_signature_for_name(path: str) -> str:
    stem = _sfsmart_normalized_stem(path)
    ext = _os.path.splitext(str(path or '').lower())[1]
    return f'{stem}{ext}'


def _sfsmart_version_tuple(path: str) -> tuple[int, ...]:
    found = []
    for match in _re.findall(r'(?i)(?:^|[_\-/\\.])v(\d{1,5})(?=$|[_\-/\\.])', str(path or '')):
        try:
            found.append(int(match))
        except Exception:
            pass
    return tuple(found[-3:])


def _sfsmart_ratio(a: str, b: str) -> float:
    try:
        return float(_difflib.SequenceMatcher(None, str(a or '').lower(), str(b or '').lower()).ratio())
    except Exception:
        return 0.0


def _sfsmart_score_candidate(record: dict, candidate: str, *, search_root: str) -> dict:
    old = _sfsmart_norm(record.get('absolute_path') or record.get('path') or '')
    candidate = _sfsmart_norm(candidate)
    old_base = _os.path.basename(old).lower()
    cand_base = _os.path.basename(candidate).lower()
    old_ext = _os.path.splitext(old_base)[1]
    cand_ext = _os.path.splitext(cand_base)[1]
    old_stem = _sfsmart_normalized_stem(old)
    cand_stem = _sfsmart_normalized_stem(candidate)
    score = 0
    reasons = []
    if cand_base == old_base:
        score += 46; reasons.append(_ui_text('exact basename', 'ファイル名の完全な一致'))
    elif cand_stem == old_stem and old_stem:
        score += 34; reasons.append(_ui_text('normalized stem match', '正規化した名前の一致'))
    else:
        ratio = _sfsmart_ratio(cand_stem, old_stem)
        if ratio >= 0.92:
            score += 27; reasons.append(_ui_text(f'stem ratio {ratio:.2f}', f'名前の一致 {ratio:.2f}'))
        elif ratio >= 0.82:
            score += 19; reasons.append(_ui_text(f'stem ratio {ratio:.2f}', f'名前の一致 {ratio:.2f}'))
        elif ratio >= 0.70:
            score += 10; reasons.append(_ui_text(f'stem ratio {ratio:.2f}', f'名前の一致 {ratio:.2f}'))
    if old_ext and cand_ext == old_ext:
        score += 15; reasons.append(_ui_text('extension match', '拡張子の一致'))
    elif old_ext and cand_ext:
        compatible = {'.jpg': '.jpeg', '.jpeg': '.jpg', '.tif': '.tiff', '.tiff': '.tif'}
        if compatible.get(old_ext) == cand_ext:
            score += 9; reasons.append(_ui_text('compatible extension', '互換のある拡張子'))
    old_kind = _sfsmart_kind_for_path(old)
    cand_kind = _sfsmart_kind_for_path(candidate)
    if cand_kind in {str(record.get('kind') or ''), old_kind}:
        score += 9; reasons.append(_ui_text('asset kind match', 'アセットの種類の一致'))
    old_stat = {'size': int(record.get('file_size') or 0), 'mtime': int(record.get('mtime') or 0)}
    cand_stat = _sfsmart_stat_record(candidate)
    old_size = int(old_stat.get('size') or 0)
    cand_size = int(cand_stat.get('size') or 0)
    if old_size and cand_size:
        if cand_size == old_size:
            score += 18; reasons.append(_ui_text('size exact', '大きさの完全な一致'))
        else:
            delta = abs(cand_size - old_size) / max(old_size, cand_size)
            if delta <= 0.005:
                score += 13; reasons.append(_ui_text('size near', '大きさが近い'))
            elif delta <= 0.03:
                score += 7; reasons.append(_ui_text('size plausible', '大きさが妥当'))
    if _sfsmart_sequence_signature_for_name(old) == _sfsmart_sequence_signature_for_name(candidate):
        score += 10; reasons.append(_ui_text('sequence signature', '連番の形の一致'))
    old_tokens = _sfsmart_similarity_tokens(old)
    cand_tokens = _sfsmart_similarity_tokens(candidate)
    overlap = 0.0
    if old_tokens and cand_tokens:
        overlap = len(old_tokens & cand_tokens) / max(1, len(old_tokens | cand_tokens))
        token_score = int(overlap * 22)
        if token_score:
            score += token_score; reasons.append(_ui_text(f'path token overlap {overlap:.2f}', f'パスの語の一致 {overlap:.2f}'))
    try:
        rel_old = _os.path.relpath(old, _sfsmart_project_root(None)).replace('\\', '/').lower()
        rel_new = _os.path.relpath(candidate, search_root).replace('\\', '/').lower()
        for tail_len, points in ((4, 22), (3, 16), (2, 9)):
            tail_old = '/'.join(rel_old.split('/')[-tail_len:])
            tail_new = '/'.join(rel_new.split('/')[-tail_len:])
            if tail_old and tail_old == tail_new:
                score += points; reasons.append(_ui_text(f'relative tail {tail_len}', f'パスの末尾 {tail_len} 階層の一致'))
                break
    except Exception:
        pass
    old_versions = _sfsmart_version_tuple(old)
    cand_versions = _sfsmart_version_tuple(candidate)
    if old_versions and cand_versions:
        if old_versions == cand_versions:
            score += 8; reasons.append(_ui_text('version token match', '版の表記の一致'))
        elif old_versions[:-1] == cand_versions[:-1] and cand_versions[-1] >= old_versions[-1]:
            score += 5; reasons.append(_ui_text('newer version family', '新しい版の系列'))
    lower_candidate = candidate.lower().replace('\\', '/')
    if '/backup/' in lower_candidate or '/autosave/' in lower_candidate or '/old/' in lower_candidate:
        score -= 10; reasons.append(_ui_text('backup/autosave penalty', 'バックアップ・自動保存の減点'))
    score = max(0, min(100, int(score)))
    if score >= 88:
        band = 'excellent'
    elif score >= 72:
        band = 'high'
    elif score >= 55:
        band = 'medium'
    else:
        band = 'low'
    return {'path': candidate, 'exists': _os.path.isfile(candidate), 'score': score, 'confidence_band': band, 'reasons': reasons, 'token_overlap': round(overlap, 3), **cand_stat}


def _sfsmart_find_missing_candidates(root: str, record: dict, *, max_hits: int = 8, max_files: int = 50000) -> list[dict]:
    root = _sfsmart_norm(root)
    if not root or not _os.path.isdir(root):
        return []
    old = _sfsmart_norm(record.get('absolute_path') or record.get('path') or '')
    basename = _os.path.basename(old).lower()
    old_ext = _os.path.splitext(old)[1].lower()
    compatible_ext = {
        '.jpg': {'.jpg', '.jpeg'}, '.jpeg': {'.jpeg', '.jpg'},
        '.tif': {'.tif', '.tiff'}, '.tiff': {'.tiff', '.tif'},
        '.exr': {'.exr'}, '.png': {'.png'}, '.usd': {'.usd', '.usda', '.usdc'},
        '.usda': {'.usda', '.usd'}, '.usdc': {'.usdc', '.usd'},
    }
    scan_exts = compatible_ext.get(old_ext, {old_ext} if old_ext else None)
    old_stem = _sfsmart_normalized_stem(old)
    old_tokens = _sfsmart_similarity_tokens(old)
    candidates = []
    seen = set()
    scan_limit = max(1000, int(max_files or 50000))
    for full in _sfsmart_scan_files(root, max_files=scan_limit, extensions=scan_exts):
        key = _sfsmart_normcase(full)
        if key in seen:
            continue
        seen.add(key)
        name = _os.path.basename(full).lower()
        stem = _sfsmart_normalized_stem(full)
        include = name == basename or stem == old_stem
        if not include:
            ratio = _sfsmart_ratio(stem, old_stem)
            if ratio >= 0.70:
                include = True
            else:
                cand_tokens = _sfsmart_similarity_tokens(full)
                if old_tokens and cand_tokens:
                    overlap = len(old_tokens & cand_tokens) / max(1, len(old_tokens | cand_tokens))
                    include = overlap >= 0.42 and (old_ext == _os.path.splitext(full)[1].lower() or not old_ext)
        if include:
            scored = _sfsmart_score_candidate(record, full, search_root=root)
            if int(scored.get('score') or 0) >= 32:
                candidates.append(scored)
        if len(candidates) >= max_hits * 24:
            break
    candidates.sort(key=lambda item: (int(item.get('score') or 0), bool(item.get('exists')), int(item.get('size') or 0)), reverse=True)
    return candidates[:max_hits]


def _sfsmart_parse_usd_ascii(path: str, *, limit_bytes: int = 2_000_000) -> dict:
    path = _sfsmart_norm(path)
    result = {'sublayers': [], 'references': [], 'payloads': [], 'assets': [], 'parse_note': ''}
    ext = _os.path.splitext(path)[1].lower()
    if ext in _SFSMART_BINARY_USD_EXTS or not _os.path.isfile(path):
        result['parse_note'] = 'binary or unavailable'
        return result
    try:
        with open(path, 'rb') as handle:
            raw = handle.read(limit_bytes)
        text = raw.decode('utf-8', errors='ignore')
    except Exception as exc:
        result['parse_note'] = str(exc)
        return result
    asset_refs = _re.findall(r'@([^@\n\r]+)@', text)
    result['assets'] = sorted(set(asset_refs))[:200]
    lowered = text.lower()
    for key, bucket in (('sublayers', 'sublayers'), ('references', 'references'), ('payload', 'payloads'), ('payloads', 'payloads')):
        if key not in lowered:
            continue
        pattern = key + r'\s*(?:=|:)\s*(?:\[[^\]]*\]|@[^@]+@|[^\n]+)'
        for block in _re.findall(pattern, text, flags=_re.I | _re.S):
            for asset in _re.findall(r'@([^@\n\r]+)@', block):
                result[bucket].append(asset)
    for bucket in ('sublayers', 'references', 'payloads'):
        result[bucket] = sorted(set(result[bucket]))[:100]
    return result


def _sfsmart_resolve_asset_relative(base_path: str, asset_path: str) -> str:
    asset_path = str(asset_path or '').strip()
    if not asset_path:
        return ''
    if _os.path.isabs(asset_path):
        return _sfsmart_norm(asset_path)
    return _sfsmart_norm(_os.path.join(_os.path.dirname(_sfsmart_norm(base_path)), asset_path))

def _sfsmart_kind_for_path(path: str) -> str:
    lower = str(path or '').lower()
    for ext, kind in sorted(_SFSMART_ASSET_EXTENSIONS.items(), key=lambda kv: -len(kv[0])):
        if lower.endswith(ext):
            return kind
    return 'external'


def _sfsmart_classify_subdir(kind: str) -> str:
    return {
        'library': 'libraries',
        'texture': 'textures',
        'cache': 'caches',
        'usd': 'usd',
        'volume': 'volumes',
        'audio': 'audio',
        'font': 'fonts',
        'light': 'lights',
        'model': 'models',
        'script': 'scripts',
        'metadata': 'metadata',
    }.get(str(kind or 'external'), 'external')


def _sfsmart_id_owner_label(owner) -> str:
    try:
        name = str(getattr(owner, 'name_full', '') or getattr(owner, 'name', '') or '')
    except Exception:
        name = ''
    try:
        type_name = str(getattr(getattr(owner, 'bl_rna', None), 'identifier', '') or type(owner).__name__)
    except Exception:
        type_name = type(owner).__name__
    return f'{type_name}:{name}' if name else type_name



def _sfsmart_datablock_path_records(include_libraries: bool = True) -> list[dict]:
    records: list[dict] = []
    seen: set[tuple[str, str, str]] = set()
    project_root = _sfsmart_project_root(None)

    def add(kind: str, owner, path: object, prop: str = 'filepath', note: str = ''):
        raw = str(path or '').strip()
        if not raw:
            return
        abspath = _sfsmart_norm(raw)
        key = (_sfsmart_id_owner_label(owner), prop, _sfsmart_normcase(abspath))
        if key in seen:
            return
        seen.add(key)
        exists = _sfsmart_path_exists(abspath)
        seq = _sfsmart_sequence_summary(abspath)
        stat = _sfsmart_stat_record(abspath)
        packed = False
        try:
            packed = bool(getattr(owner, 'packed_file', None) or getattr(owner, 'packed_files', None))
        except Exception:
            packed = False
        ext = _os.path.splitext(abspath)[1].lower()
        inferred_kind = _sfsmart_kind_for_path(abspath)
        records.append({
            'schema': 'file_pipeline.path_record.v2',
            'record_id': _sfsmart_stable_hash_text(f'{key}|{kind}', 20),
            'kind': kind,
            'file_kind': inferred_kind,
            'owner': _sfsmart_id_owner_label(owner),
            'owner_key': _sfsmart_owner_key(owner),
            'name': str(getattr(owner, 'name', '') or ''),
            'path': raw,
            'absolute_path': abspath,
            'project_relative_path': _sfsmart_project_rel(abspath, project_root),
            'exists': bool(exists),
            'packed': bool(packed),
            'extension': ext,
            'file_size': int(stat.get('size') or 0),
            'mtime': int(stat.get('mtime') or 0),
            'mtime_iso': stat.get('mtime_iso', ''),
            'is_blend_relative': raw.startswith('//'),
            'env_tokens': _sfsmart_env_tokens_for_path(abspath),
            'is_sequence': bool(seq.get('is_sequence')),
            'sequence_count': int(seq.get('family_count') or 0),
            'first_frame': seq.get('first_frame'),
            'last_frame': seq.get('last_frame'),
            'property': prop,
            'note': note,
            '_owner': owner,
            '_family': seq.get('members') or ([abspath] if exists else []),
        })

    if include_libraries:
        try:
            for lib in bpy.data.libraries:
                add('library', lib, getattr(lib, 'filepath', ''), 'filepath', 'Linked .blend library')
        except Exception:
            pass
    for collection_name, kind, prop in (
        ('images', 'texture', 'filepath'),
        ('movieclips', 'movie', 'filepath'),
        ('sounds', 'audio', 'filepath'),
        ('fonts', 'font', 'filepath'),
        ('cache_files', 'cache', 'filepath'),
        ('volumes', 'volume', 'filepath'),
    ):
        data_collection = getattr(getattr(bpy, 'data', None), collection_name, None)
        if data_collection is None:
            continue
        try:
            iterator = list(data_collection)
        except Exception:
            iterator = []
        for datablock in iterator:
            try:
                value = getattr(datablock, prop, '')
                add(kind, datablock, value, prop, collection_name)
                # Some datablocks expose filepath_raw; include it only when materially different.
                raw_value = getattr(datablock, 'filepath_raw', '')
                if raw_value and str(raw_value) != str(value):
                    add(kind, datablock, raw_value, 'filepath_raw', collection_name + ' raw path')
            except Exception:
                pass
    return records

def _sfsmart_public_records(records: list[dict]) -> list[dict]:
    public = []
    for record in records:
        public.append({k: v for k, v in record.items() if not str(k).startswith('_')})
    return public


def _sfsmart_set_record_path(record: dict, new_path: str, *, make_relative: bool = False) -> bool:
    owner = record.get('_owner')
    prop = str(record.get('property') or 'filepath')
    if owner is None or not hasattr(owner, prop):
        return False
    value = _sfsmart_rel(new_path) if make_relative else _sfsmart_norm(new_path)
    try:
        setattr(owner, prop, value)
        return True
    except Exception:
        return False



def _sfsmart_inventory(context) -> dict:
    records = _sfsmart_datablock_path_records(include_libraries=True)
    linked_ids = []
    override_issues = []
    try:
        for collection_name in ('objects', 'collections', 'materials', 'node_groups', 'actions', 'worlds', 'meshes', 'armatures', 'cameras', 'lights'):
            data_collection = getattr(bpy.data, collection_name, None)
            if data_collection is None:
                continue
            for item in data_collection:
                lib = getattr(item, 'library', None)
                override = getattr(item, 'override_library', None)
                if lib is None and override is None:
                    continue
                lib_path = _sfsmart_norm(getattr(lib, 'filepath', '') or '') if lib else ''
                item_data = {
                    'type': collection_name,
                    'name': str(getattr(item, 'name', '') or ''),
                    'key': _sfsmart_owner_key(item),
                    'library': lib_path,
                    'library_exists': _sfsmart_path_exists(lib_path) if lib_path else False,
                    'override': bool(override),
                }
                linked_ids.append(item_data)
                if override is not None and not lib_path:
                    override_issues.append({**item_data, 'issue': 'override without source library'})
    except Exception:
        pass
    missing = [r for r in records if not r.get('exists') and not r.get('packed')]
    absolute = [r for r in records if r.get('path') and not str(r.get('path')).startswith('//') and _os.path.isabs(_sfsmart_norm(r.get('path')))]
    sequences = [r for r in records if r.get('is_sequence')]
    roots = sorted(set(_sfsmart_common_root([r.get('absolute_path', '') for r in records]).splitlines())) if records else []
    data = {
        'schema': 'file_pipeline.inventory.v2',
        'blend': bpy.data.filepath or '',
        'project_root': _sfsmart_project_root(context),
        'record_count': len(records),
        'missing_count': len(missing),
        'absolute_path_count': len(absolute),
        'sequence_record_count': len(sequences),
        'linked_id_count': len(linked_ids),
        'override_issue_count': len(override_issues),
        'common_root': roots[0] if roots else '',
        'records': _sfsmart_public_records(records),
        'linked_ids': linked_ids,
        'override_issues': override_issues,
    }
    return data

def _sfsmart_scan_references(context) -> dict:
    data = _sfsmart_inventory(context)
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'reports'), f'reference_inventory_{_sfsmart_now_slug()}.json'), data)
    _sfsmart_set_last_report(context, 'Reference Inventory', data, path)
    return {'path': path, 'data': data}



def _sfsmart_collect_assets(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    include_libraries = bool(getattr(wm, 'sf_smart_include_libraries', True))
    make_relative = bool(getattr(wm, 'sf_smart_make_relative', True))
    update_paths = bool(getattr(wm, 'sf_smart_apply_changes', False))
    zip_bundle = bool(getattr(wm, 'sf_smart_zip_bundle', True))
    bundle_name = _sfsmart_safe_filename(_Path(bpy.data.filepath).stem if bpy.data.filepath else 'unsaved_scene')
    target_root = _sfsmart_output_dir(context, 'bundles', f'{bundle_name}_{_sfsmart_now_slug()}')
    project_root = _sfsmart_project_root(context)
    search_root = _sfsmart_norm(getattr(wm, 'sf_smart_search_root', '') or '') or project_root
    records = _sfsmart_datablock_path_records(include_libraries=include_libraries)
    copied = []
    skipped = []
    dedup: dict[str, str] = {}
    used_targets: set[str] = set()
    for record in records:
        src_primary = _sfsmart_norm(record.get('absolute_path') or record.get('path') or '')
        family = [p for p in (record.get('_family') or []) if _os.path.isfile(_sfsmart_norm(p))]
        if not family and src_primary and _os.path.isfile(src_primary):
            family = [src_primary]
        if not family:
            skipped.append({**{k: v for k, v in record.items() if not str(k).startswith('_')}, 'reason': 'missing, packed-only, or not a file'})
            continue
        kind = _sfsmart_kind_for_path(src_primary) if src_primary else str(record.get('kind') or 'external')
        member_results = []
        primary_target = ''
        try:
            for src in family:
                src = _sfsmart_norm(src)
                src_key = _sfsmart_normcase(src)
                if src_key in dedup:
                    dst = dedup[src_key]
                    copied_now = False
                else:
                    dst = _sfsmart_destination_for_source(src, target_root=target_root, kind=kind if kind != 'external' else str(record.get('kind') or 'external'), used=used_targets, project_root=project_root, search_root=search_root)
                    _os.makedirs(_os.path.dirname(dst), exist_ok=True)
                    if _sfsmart_normcase(dst) != src_key:
                        _shutil.copy2(src, dst)
                    dedup[src_key] = dst
                    copied_now = True
                if _sfsmart_normcase(src) == _sfsmart_normcase(src_primary) or not primary_target:
                    primary_target = dst
                member_results.append({
                    'source': src,
                    'target': dst,
                    'relative_target': _sfsmart_rel(dst),
                    'copied_now': copied_now,
                    'size': _sfsmart_stat_record(dst).get('size', 0),
                    'sha1': _sfsmart_file_hash(dst),
                })
            if update_paths and primary_target:
                _sfsmart_set_record_path(record, primary_target, make_relative=make_relative)
            copied.append({
                'kind': str(record.get('kind') or kind),
                'file_kind': kind,
                'owner': str(record.get('owner') or ''),
                'source': src_primary,
                'target': primary_target,
                'relative_target': _sfsmart_rel(primary_target),
                'sequence_count': len(member_results),
                'members': member_results,
            })
        except Exception as exc:
            skipped.append({**{k: v for k, v in record.items() if not str(k).startswith('_')}, 'reason': str(exc)})
    manifest = {
        'schema': 'file_pipeline.collect_manifest.v2',
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'blend': bpy.data.filepath or '',
        'target_root': target_root,
        'project_root': project_root,
        'search_root': search_root,
        'updated_blender_paths': update_paths,
        'relative_paths': make_relative,
        'record_count': len(records),
        'copied_record_count': len(copied),
        'copied_file_count': sum(len(item.get('members') or []) for item in copied),
        'deduplicated_source_count': len(dedup),
        'copied': copied,
        'skipped': skipped,
        'archive': target_root.rstrip('/\\') + '.zip' if zip_bundle else '',
    }
    manifest_path = _sfsmart_write_json(_os.path.join(target_root, _SFSMART_MANIFEST_NAME), manifest)
    if zip_bundle:
        try:
            with _zipfile.ZipFile(manifest['archive'], 'w', compression=_zipfile.ZIP_DEFLATED) as zf:
                for root, _dirs, files in _os.walk(target_root):
                    for name in files:
                        full = _os.path.join(root, name)
                        zf.write(full, _os.path.relpath(full, target_root))
        except Exception as exc:
            manifest['zip_error'] = str(exc)
            _sfsmart_write_json(manifest_path, manifest)
    manifest['manifest_path'] = manifest_path
    _sfsmart_set_last_report(context, 'Collect Package', manifest, manifest_path)
    return manifest


def _sfsmart_find_by_basename(root: str, basename: str, *, max_hits: int = 20) -> list[str]:
    root = _sfsmart_norm(root)
    basename = str(basename or '').lower()
    hits: list[str] = []
    if not root or not _os.path.isdir(root) or not basename:
        return hits
    ext = _os.path.splitext(basename)[1].lower()
    for full in _sfsmart_scan_files(root, max_files=100000, extensions={ext} if ext else None):
        if _os.path.basename(full).lower() == basename:
            hits.append(full)
            if len(hits) >= max_hits:
                return hits
    return hits


def _sfsmart_build_repath_plan(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    source_prefix = _sfsmart_norm(getattr(wm, 'sf_smart_repath_from', '') or '')
    target_prefix = _sfsmart_norm(getattr(wm, 'sf_smart_repath_to', '') or '')
    search_root = _sfsmart_norm(getattr(wm, 'sf_smart_search_root', '') or '') or _sfsmart_project_root(context)
    include_libraries = bool(getattr(wm, 'sf_smart_include_libraries', True))
    max_files = int(getattr(wm, 'sf_smart_max_scan_files', 2500) or 2500)
    records = _sfsmart_datablock_path_records(include_libraries=include_libraries)
    plan_items = []
    prefix_norm = _sfsmart_normcase(source_prefix)
    for record in records:
        old_path = _sfsmart_norm(record.get('absolute_path') or record.get('path') or '')
        old_norm = _sfsmart_normcase(old_path)
        new_path = ''
        reason = ''
        candidates = []
        confidence = 0
        if source_prefix and target_prefix and old_norm.startswith(prefix_norm):
            # Require path boundary to avoid replacing C:/show with C:/showroom.
            boundary_ok = len(old_norm) == len(prefix_norm) or old_norm[len(prefix_norm):len(prefix_norm)+1] in {'/', '\\'}
            if boundary_ok:
                suffix = old_path[len(source_prefix):].lstrip('/\\')
                candidate = _sfsmart_norm(_os.path.join(target_prefix, suffix))
                score = 96 if _os.path.exists(candidate) else 62
                candidates.append({'path': candidate, 'exists': _os.path.exists(candidate), 'score': score, 'reasons': ['prefix replacement']})
                new_path = candidate
                reason = 'prefix replacement'
                confidence = score
        if not new_path and not record.get('exists') and not record.get('packed'):
            candidates = _sfsmart_find_missing_candidates(search_root, record, max_hits=8, max_files=max(1000, max_files))
            if candidates:
                best = candidates[0]
                new_path = str(best.get('path') or '')
                reason = 'scored missing-file search'
                confidence = int(best.get('score') or 0)
        if new_path:
            plan_items.append({
                'owner': record.get('owner', ''),
                'owner_key': record.get('owner_key', ''),
                'record_id': record.get('record_id', ''),
                'kind': record.get('kind', ''),
                'old_path': old_path,
                'new_path': _sfsmart_norm(new_path),
                'new_exists': _sfsmart_path_exists(new_path),
                'reason': reason,
                'confidence': confidence,
                'candidates': candidates[:8],
            })
    plan = {
        'schema': 'file_pipeline.repath_plan.v2',
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'blend': bpy.data.filepath or '',
        'source_prefix': source_prefix,
        'target_prefix': target_prefix,
        'search_root': search_root,
        'record_count': len(records),
        'item_count': len(plan_items),
        'items': plan_items,
    }
    try:
        wm.sf_smart_plan_json = _sfsmart_safe_json(plan)
    except Exception:
        pass
    return plan


def _sfsmart_apply_plan(context, plan: dict | None = None) -> dict:
    plan = plan or _sfsmart_build_repath_plan(context)
    records = _sfsmart_datablock_path_records(include_libraries=True)
    updated = []
    failed = []
    by_old = {}
    by_record_id = {}
    for record in records:
        old = _sfsmart_norm(record.get('absolute_path') or record.get('path') or '')
        by_old.setdefault(_os.path.normcase(old), []).append(record)
        if record.get('record_id'):
            by_record_id.setdefault(record.get('record_id'), []).append(record)
    make_relative = bool(getattr(getattr(context, 'window_manager', None), 'sf_smart_make_relative', True))
    for item in list(plan.get('items') or []):
        old = _sfsmart_norm(item.get('old_path') or '')
        new = _sfsmart_norm(item.get('new_path') or '')
        confidence = int(item.get('confidence') or 0)
        if not new:
            failed.append({**item, 'reason': 'empty target path'})
            continue
        if confidence and confidence < 45:
            failed.append({**item, 'reason': 'confidence below safety threshold'})
            continue
        if item.get('reason') != 'prefix replacement' and not _os.path.exists(new):
            failed.append({**item, 'reason': 'target path does not exist'})
            continue
        matching = []
        if item.get('record_id'):
            matching.extend(by_record_id.get(item.get('record_id'), []))
        matching.extend(by_old.get(_os.path.normcase(old), []))
        # de-duplicate matching records by object identity.
        dedup_matching = []
        seen = set()
        for rec in matching:
            key = id(rec.get('_owner'))
            if key not in seen:
                seen.add(key); dedup_matching.append(rec)
        if not dedup_matching:
            failed.append({**item, 'reason': 'no matching datablock path'})
            continue
        for record in dedup_matching:
            if _sfsmart_set_record_path(record, new, make_relative=make_relative):
                updated.append({**item, 'owner': record.get('owner', item.get('owner', ''))})
            else:
                failed.append({**item, 'owner': record.get('owner', item.get('owner', '')), 'reason': 'could not write path'})
    result = {'updated': updated, 'failed': failed, 'plan': plan}
    return result

def _sfsmart_apply_off_notice() -> str:
    return _ui_text(
        'Apply Changes is off, so nothing was changed. Review the report, then turn on Apply Changes and run this again.',
        '「変更を適用」が切れているので、何も変えていません。レポートを確かめ、入れてからもう一度押してください。',
    )


def _sfsmart_apply_enabled(context) -> bool:
    return bool(getattr(getattr(context, 'window_manager', None), 'sf_smart_apply_changes', False))


def _sfsmart_make_paths_relative(context) -> dict:
    updated, skipped = [], []
    if not bpy.data.filepath:
        result = {'updated': updated, 'skipped': [{'reason': 'current .blend is not saved'}], 'notice': _ui_text('Save the .blend file first. Relative paths need a saved file.', '先に .blend を保存してください。相対パスには保存済みのファイルが要ります。')}
        _sfsmart_set_last_report(context, 'Make Paths Relative', result)
        return result
    if not _sfsmart_apply_enabled(context):
        records = _sfsmart_datablock_path_records(include_libraries=True)
        candidates = [{k: v for k, v in record.items() if not str(k).startswith('_')} for record in records if not str(record.get('path') or '').startswith('//')]
        result = {'updated': [], 'candidates': candidates, 'apply_changes': False, 'notice': _sfsmart_apply_off_notice()}
        _sfsmart_set_last_report(context, 'Make Paths Relative', result)
        return result
    for record in _sfsmart_datablock_path_records(include_libraries=True):
        if _sfsmart_set_record_path(record, record.get('absolute_path') or record.get('path') or '', make_relative=True):
            updated.append({k: v for k, v in record.items() if not str(k).startswith('_')})
        else:
            skipped.append({k: v for k, v in record.items() if not str(k).startswith('_')})
    result = {'updated': updated, 'skipped': skipped}
    _sfsmart_set_last_report(context, 'Make Paths Relative', result)
    return result


def _sfsmart_scope_objects(context) -> list:
    wm = getattr(context, 'window_manager', None)
    scope = str(getattr(wm, 'sf_smart_scope', 'SELECTED') or 'SELECTED').upper()
    if scope == 'SELECTED':
        return list(getattr(context, 'selected_objects', []) or [])
    objects = list(getattr(bpy.data, 'objects', []) or [])
    if scope == 'LINKED':
        objects = [obj for obj in objects if getattr(obj, 'library', None) is not None]
    return objects


def _sfsmart_linked_objects(context) -> list:
    return [obj for obj in _sfsmart_scope_objects(context) if getattr(obj, 'library', None) is not None]


def _sfsmart_reload_libraries(context) -> dict:
    reloaded, failed = [], []
    # Reloading one library can free another one that only it used, so read the names first.
    targets = []
    for lib in list(getattr(bpy.data, 'libraries', []) or []):
        try:
            targets.append((lib, str(getattr(lib, 'name', '') or ''), _sfsmart_norm(getattr(lib, 'filepath', '') or '')))
        except ReferenceError:
            continue
    for lib, name, filepath in targets:
        try:
            reload_fn = getattr(lib, 'reload', None)
            if callable(reload_fn):
                reload_fn()
                reloaded.append({'name': name, 'path': filepath})
            else:
                failed.append({'name': name, 'path': filepath, 'reason': 'library.reload is unavailable'})
        except ReferenceError:
            continue
        except Exception as exc:
            failed.append({'name': name, 'path': filepath, 'reason': str(exc)})
    result = {'reloaded': reloaded, 'failed': failed}
    _sfsmart_set_last_report(context, 'Reload Libraries', result)
    return result


def _sfsmart_make_local(context) -> dict:
    objects = _sfsmart_scope_objects(context)
    updated, failed = [], []
    for obj in objects:
        if getattr(obj, 'library', None) is None:
            continue
        try:
            make_local = getattr(obj, 'make_local', None)
            if callable(make_local):
                try:
                    make_local(clear_asset_data=False)
                except TypeError:
                    make_local()
                updated.append(str(getattr(obj, 'name', '') or ''))
            else:
                failed.append({'name': str(getattr(obj, 'name', '') or ''), 'reason': 'make_local unavailable'})
        except Exception as exc:
            failed.append({'name': str(getattr(obj, 'name', '') or ''), 'reason': str(exc)})
    result = {'materialized': updated, 'failed': failed}
    _sfsmart_set_last_report(context, 'Materialize Links', result)
    return result


def _sfsmart_make_overrides(context) -> dict:
    selected = list(getattr(context, 'selected_objects', []) or [])
    if not selected:
        result = {'created': [], 'failed': [{'reason': 'no selected objects'}]}
        _sfsmart_set_last_report(context, 'Make Library Overrides', result)
        return result
    try:
        bpy.ops.object.make_override_library()
        result = {'created': [str(getattr(obj, 'name', '') or '') for obj in selected], 'failed': []}
    except Exception as exc:
        result = {'created': [], 'failed': [{'reason': str(exc), 'selection': [str(getattr(obj, 'name', '') or '') for obj in selected]}]}
    _sfsmart_set_last_report(context, 'Make Library Overrides', result)
    return result



def _sfsmart_set_linked_visibility(context, *, restore: bool = False) -> dict:
    wm = getattr(context, 'window_manager', None)
    mode = str(getattr(wm, 'sf_smart_proxy_mode', 'BOUNDS') or 'BOUNDS').upper()
    updated = []
    snapshot_path = _os.path.join(_sfsmart_output_dir(context, 'display'), 'linked_display_state.json')
    previous = _sfsmart_read_json_file(snapshot_path, fallback={}) if restore else {}
    current_snapshot = {}
    for obj in _sfsmart_linked_objects(context):
        name = str(getattr(obj, 'name', '') or '')
        key = _sfsmart_object_key(obj)
        try:
            if restore:
                saved = previous.get(key) or previous.get(name) or {}
                obj.hide_viewport = bool(saved.get('hide_viewport', False))
                obj.hide_render = bool(saved.get('hide_render', False))
                obj.hide_select = bool(saved.get('hide_select', False))
                if saved.get('display_type'):
                    obj.display_type = saved.get('display_type')
            else:
                current_snapshot[key] = {'name': name, 'hide_viewport': bool(obj.hide_viewport), 'hide_render': bool(obj.hide_render), 'hide_select': bool(obj.hide_select), 'display_type': str(getattr(obj, 'display_type', '') or '')}
                if mode == 'HIDDEN':
                    obj.hide_viewport = True
                    obj.hide_render = True
                elif mode == 'RENDER_ONLY':
                    obj.hide_viewport = True
                    obj.hide_render = False
                elif mode == 'VIEWPORT_ONLY':
                    obj.hide_viewport = False
                    obj.hide_render = True
                else:
                    obj.hide_viewport = False
                    obj.hide_render = False
                    obj.display_type = 'WIRE' if mode == 'WIRE' else 'BOUNDS'
                obj.hide_select = mode in {'BOUNDS', 'WIRE', 'HIDDEN'}
            updated.append(name)
        except Exception:
            pass
    if not restore:
        _sfsmart_write_json(snapshot_path, current_snapshot)
    title = 'Restore Display' if restore else 'Proxy Display'
    result = {'mode': 'RESTORE' if restore else mode, 'objects': updated, 'state_file': snapshot_path}
    _sfsmart_set_last_report(context, title, result)
    return result


def _sfsmart_capture_delta(context) -> dict:
    objects = _sfsmart_scope_objects(context)
    entries = []
    for obj in objects:
        try:
            collections = []
            try:
                collections = [str(c.name) for c in list(getattr(obj, 'users_collection', []) or [])]
            except Exception:
                pass
            entries.append({
                'key': _sfsmart_object_key(obj),
                'name': str(obj.name),
                'type': str(getattr(obj, 'type', '') or ''),
                'data_name': str(getattr(getattr(obj, 'data', None), 'name', '') or ''),
                'library': _sfsmart_norm(getattr(getattr(obj, 'library', None), 'filepath', '') or ''),
                'parent': str(getattr(getattr(obj, 'parent', None), 'name', '') or ''),
                'collections': collections,
                'matrix_world': [[float(v) for v in row] for row in obj.matrix_world],
                'location': [float(v) for v in obj.location],
                'rotation_euler': [float(v) for v in obj.rotation_euler],
                'scale': [float(v) for v in obj.scale],
                'hide_viewport': bool(obj.hide_viewport),
                'hide_render': bool(obj.hide_render),
                'hide_select': bool(obj.hide_select),
                'display_type': str(getattr(obj, 'display_type', '') or ''),
                'materials': [str(getattr(slot.material, 'name', '') or '') for slot in getattr(obj, 'material_slots', [])],
                'modifiers': [{'name': str(getattr(mod, 'name', '') or ''), 'type': str(getattr(mod, 'type', '') or ''), 'show_viewport': bool(getattr(mod, 'show_viewport', True)), 'show_render': bool(getattr(mod, 'show_render', True))} for mod in list(getattr(obj, 'modifiers', []) or [])],
                'custom_properties': {str(k): obj.get(k) for k in obj.keys() if isinstance(obj.get(k), (str, int, float, bool))},
            })
        except Exception:
            pass
    delta = {'schema': 'file_pipeline.delta.v2', 'created_at': _datetime.datetime.now().isoformat(timespec='seconds'), 'blend': bpy.data.filepath or '', 'object_count': len(entries), 'objects': entries}
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'delta'), _SFSMART_DELTA_NAME), delta)
    try:
        context.window_manager.sf_smart_delta_file = path
    except Exception:
        pass
    _sfsmart_set_last_report(context, 'Capture Delta', delta, path)
    return delta

def _sfsmart_load_delta(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    path = _sfsmart_norm(getattr(wm, 'sf_smart_delta_file', '') or '')
    if not path:
        path = _os.path.join(_sfsmart_output_dir(context, 'delta'), _SFSMART_DELTA_NAME)
        if not _os.path.isfile(path):
            legacy_path = _os.path.join(_os.path.dirname(path), _SFSMART_LEGACY_DELTA_NAME)
            if _os.path.isfile(legacy_path):
                path = legacy_path
    return _sfsmart_read_json_file(path, fallback={})



def _sfsmart_compare_delta(context) -> dict:
    delta = _sfsmart_load_delta(context)
    entries = list(delta.get('objects') or []) if isinstance(delta, dict) else []
    changes = []
    objects_by_key = {_sfsmart_object_key(obj): obj for obj in list(getattr(bpy.data, 'objects', []) or [])}
    for saved in entries:
        name = str(saved.get('name') or '')
        obj = objects_by_key.get(str(saved.get('key') or '')) or bpy.data.objects.get(name)
        if obj is None:
            changes.append({'name': name, 'key': saved.get('key', ''), 'status': 'missing in current scene'})
            continue
        diffs = {}
        for prop in ('location', 'rotation_euler', 'scale'):
            try:
                cur = [round(float(v), 6) for v in getattr(obj, prop)]
                old = [round(float(v), 6) for v in saved.get(prop, [])]
                if cur != old:
                    diffs[prop] = {'saved': old, 'current': cur}
            except Exception:
                pass
        for prop in ('hide_viewport', 'hide_render', 'hide_select', 'display_type'):
            try:
                cur = getattr(obj, prop)
                old = saved.get(prop)
                if cur != old:
                    diffs[prop] = {'saved': old, 'current': cur}
            except Exception:
                pass
        try:
            cur_mats = [str(getattr(slot.material, 'name', '') or '') for slot in getattr(obj, 'material_slots', [])]
            if cur_mats != list(saved.get('materials') or []):
                diffs['materials'] = {'saved': list(saved.get('materials') or []), 'current': cur_mats}
        except Exception:
            pass
        try:
            cur_mods = [(str(getattr(mod, 'name', '') or ''), str(getattr(mod, 'type', '') or '')) for mod in list(getattr(obj, 'modifiers', []) or [])]
            old_mods = [(str(item.get('name') or ''), str(item.get('type') or '')) for item in list(saved.get('modifiers') or [])]
            if cur_mods != old_mods:
                diffs['modifiers'] = {'saved': old_mods, 'current': cur_mods}
        except Exception:
            pass
        if diffs:
            changes.append({'name': name, 'key': saved.get('key', ''), 'status': 'changed', 'diffs': diffs})
    result = {'delta_objects': len(entries), 'change_count': len(changes), 'changes': changes}
    _sfsmart_set_last_report(context, 'Compare Delta', result)
    return result


def _sfsmart_restore_delta(context) -> dict:
    delta = _sfsmart_load_delta(context)
    entries = list(delta.get('objects') or []) if isinstance(delta, dict) else []
    restored, missing = [], []
    objects_by_key = {_sfsmart_object_key(obj): obj for obj in list(getattr(bpy.data, 'objects', []) or [])}
    for saved in entries:
        obj = objects_by_key.get(str(saved.get('key') or '')) or bpy.data.objects.get(str(saved.get('name') or ''))
        if obj is None:
            missing.append(str(saved.get('name') or ''))
            continue
        try:
            if isinstance(saved.get('location'), list):
                obj.location = saved.get('location')
            if isinstance(saved.get('rotation_euler'), list):
                obj.rotation_euler = saved.get('rotation_euler')
            if isinstance(saved.get('scale'), list):
                obj.scale = saved.get('scale')
            for prop in ('hide_viewport', 'hide_render', 'hide_select', 'display_type'):
                if prop in saved:
                    setattr(obj, prop, saved.get(prop))
            # Restore material names only when materials still exist and slot counts are compatible.
            try:
                mats = list(saved.get('materials') or [])
                for idx, mat_name in enumerate(mats):
                    if idx >= len(obj.material_slots):
                        break
                    mat = bpy.data.materials.get(mat_name) if mat_name else None
                    obj.material_slots[idx].material = mat
            except Exception:
                pass
            restored.append(obj.name)
        except Exception:
            missing.append(str(saved.get('name') or ''))
    result = {'restored': restored, 'missing_or_failed': missing}
    _sfsmart_set_last_report(context, 'Restore Delta', result)
    return result


def _sfsmart_camera_entries(context) -> list[dict]:
    entries = []
    scene = getattr(context, 'scene', None)
    for obj in list(getattr(bpy.data, 'objects', []) or []):
        if getattr(obj, 'type', '') != 'CAMERA':
            continue
        cam = getattr(obj, 'data', None)
        entries.append({
            'name': str(obj.name),
            'key': _sfsmart_object_key(obj),
            'library': _sfsmart_norm(getattr(getattr(obj, 'library', None), 'filepath', '') or ''),
            'is_active': bool(scene and obj == getattr(scene, 'camera', None)),
            'location': [float(v) for v in obj.location],
            'rotation_euler': [float(v) for v in obj.rotation_euler],
            'lens': float(getattr(cam, 'lens', 0.0) or 0.0),
            'sensor_width': float(getattr(cam, 'sensor_width', 0.0) or 0.0),
            'sensor_height': float(getattr(cam, 'sensor_height', 0.0) or 0.0),
            'dof_enabled': bool(getattr(getattr(cam, 'dof', None), 'use_dof', False)),
        })
    return entries

def _sfsmart_marker_entries(context) -> list[dict]:
    markers = []
    try:
        for marker in context.scene.timeline_markers:
            markers.append({'name': str(marker.name), 'frame': int(marker.frame), 'camera': str(getattr(getattr(marker, 'camera', None), 'name', '') or '')})
    except Exception:
        pass
    return markers



def _sfsmart_shot_manifest(context, *, queue: bool = False) -> dict:
    scene = getattr(context, 'scene', None)
    root = _sfsmart_output_dir(context, 'shots')
    cameras = _sfsmart_camera_entries(context)
    markers = _sfsmart_marker_entries(context)
    render = getattr(scene, 'render', None) if scene else None
    data = {
        'schema': 'file_pipeline.camera_queue.v2' if queue else 'file_pipeline.shot_manifest.v2',
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'blend': bpy.data.filepath or '',
        'scene': str(getattr(scene, 'name', '') or ''),
        'frame_start': int(getattr(scene, 'frame_start', 1) if scene else 1),
        'frame_end': int(getattr(scene, 'frame_end', 250) if scene else 250),
        'frame_current': int(getattr(scene, 'frame_current', 1) if scene else 1),
        'fps': float(getattr(render, 'fps', 24) or 24) / max(1.0, float(getattr(render, 'fps_base', 1.0) or 1.0)) if render else 24.0,
        'resolution': {'x': int(getattr(render, 'resolution_x', 0) or 0), 'y': int(getattr(render, 'resolution_y', 0) or 0), 'percentage': int(getattr(render, 'resolution_percentage', 100) or 100)} if render else {},
        'render_output': str(getattr(render, 'filepath', '') or '') if render else '',
        'cameras': cameras,
        'markers': markers,
        'view_layers': [{'name': str(getattr(vl, 'name', '') or ''), 'use': bool(getattr(vl, 'use', True))} for vl in list(getattr(scene, 'view_layers', []) or [])] if scene else [],
        'external_summary': {'record_count': len(_sfsmart_datablock_path_records(include_libraries=True)), 'linked_libraries': [str(getattr(lib, 'filepath', '') or '') for lib in list(getattr(bpy.data, 'libraries', []) or [])]},
    }
    if queue:
        jobs = []
        for cam in cameras:
            safe_cam = _sfsmart_safe_filename(cam.get('name') or 'camera')
            jobs.append({'camera': cam.get('name'), 'camera_key': cam.get('key', ''), 'frame_start': data['frame_start'], 'frame_end': data['frame_end'], 'output': _os.path.join(root, safe_cam), 'resolution': data['resolution']})
        data['jobs'] = jobs
    path = _sfsmart_write_json(_os.path.join(root, ('camera_queue_' if queue else 'shot_manifest_') + _sfsmart_now_slug() + '.json'), data)
    _sfsmart_set_last_report(context, 'Camera Queue' if queue else 'Shot Manifest', data, path)
    return data


def _sfsmart_scan_asset_catalog(context) -> dict:
    root = _sfsmart_norm(getattr(getattr(context, 'window_manager', None), 'sf_smart_search_root', '') or '') or _sfsmart_project_root(context)
    max_files = int(getattr(getattr(context, 'window_manager', None), 'sf_smart_max_scan_files', 2500) or 2500)
    items = []
    kind_counts: dict[str, int] = {}
    versioned = 0
    sequence_count = 0
    if root and _os.path.isdir(root):
        for full in _sfsmart_scan_files(root, max_files=max_files):
            name = _os.path.basename(full)
            ext = _os.path.splitext(name)[1].lower()
            kind = _sfsmart_kind_for_path(full)
            if kind == 'external' and ext not in _SFSMART_ASSET_EXTENSIONS:
                continue
            try:
                stat = _os.stat(full)
            except Exception:
                continue
            tags = [kind, ext.lstrip('.')]
            version_key = _sfsmart_version_key(full)
            if version_key:
                tags.append('versioned'); versioned += 1
            if _re.search(r'lod\d|proxy|bbox|bounds|preview|low|high|render', name, flags=_re.I):
                tags.append('representation')
            if _re.search(r'char|character|prop|asset|shot|seq|tex|texture|cache|usd|lookdev|rig|anim', full, flags=_re.I):
                for token in ('char', 'character', 'prop', 'asset', 'shot', 'seq', 'texture', 'cache', 'usd', 'lookdev', 'rig', 'anim'):
                    if token in full.lower():
                        tags.append(token)
            seq = _sfsmart_sequence_summary(full)
            if seq.get('is_sequence'):
                tags.append('sequence'); sequence_count += 1
            kind_counts[kind] = kind_counts.get(kind, 0) + 1
            items.append({
                'asset_id': _sfsmart_stable_hash_text(_os.path.relpath(full, root), 20),
                'name': name,
                'path': full,
                'relative_path': _os.path.relpath(full, root),
                'kind': kind,
                'extension': ext,
                'size': int(stat.st_size),
                'mtime': int(stat.st_mtime),
                'mtime_iso': _datetime.datetime.fromtimestamp(stat.st_mtime).isoformat(timespec='seconds'),
                'version': version_key[2] if version_key else None,
                'version_key': list(version_key) if version_key else None,
                'sequence': {k: v for k, v in seq.items() if k != 'members'},
                'tags': sorted(set(t for t in tags if t)),
            })
    data = {
        'schema': 'file_pipeline.catalog.v2',
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'root': root,
        'item_count': len(items),
        'kind_counts': kind_counts,
        'versioned_count': versioned,
        'sequence_count': sequence_count,
        'items': items,
    }
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'catalogs'), _SFSMART_CATALOG_NAME), data)
    try:
        context.window_manager.sf_smart_catalog_file = path
    except Exception:
        pass
    _sfsmart_set_last_report(context, 'Build Asset Catalog', data, path)
    return data


def _sfsmart_usd_manifest(context) -> dict:
    records = _sfsmart_datablock_path_records(include_libraries=True)
    usd_layers = []
    payloads = []
    references = []
    parsed_layers = []
    unresolved_layer_assets = []
    for record in records:
        path = _sfsmart_norm(record.get('absolute_path') or record.get('path') or '')
        ext = _os.path.splitext(path)[1].lower()
        item = {'owner': record.get('owner', ''), 'path': path, 'exists': bool(record.get('exists')), 'kind': record.get('kind', ''), 'sequence_count': record.get('sequence_count', 0)}
        if ext in {'.usd', '.usda', '.usdc', '.usdz'}:
            parsed = _sfsmart_parse_usd_ascii(path)
            item['parsed'] = parsed
            usd_layers.append(item)
            parsed_layers.append({'path': path, **parsed})
            for dep in parsed.get('assets') or []:
                dep_abs = _sfsmart_resolve_asset_relative(path, dep)
                if dep_abs and not _os.path.exists(dep_abs):
                    unresolved_layer_assets.append({'layer': path, 'asset': dep, 'resolved_path': dep_abs})
        elif ext in {'.abc', '.vdb', '.bgeo', '.bgeo.sc'}:
            payloads.append(item)
        elif ext == '.blend':
            references.append(item)
    data = {
        'schema': 'file_pipeline.usd_composition_manifest.v2',
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'blend': bpy.data.filepath or '',
        'sublayers': usd_layers,
        'payload_candidates': payloads,
        'blend_reference_candidates': references,
        'parsed_layer_count': len(parsed_layers),
        'parsed_layers': parsed_layers,
        'unresolved_layer_asset_count': len(unresolved_layer_assets),
        'unresolved_layer_assets': unresolved_layer_assets,
        'variants': [
            {'name': 'layout_proxy', 'purpose': 'bounds or proxy display for layout'},
            {'name': 'animation_proxy', 'purpose': 'animatable low-cost representation'},
            {'name': 'lookdev_full', 'purpose': 'material and shading review'},
            {'name': 'render_full', 'purpose': 'final render representation'},
        ],
    }
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'usd'), 'usd_layer_manifest_' + _sfsmart_now_slug() + '.json'), data)
    _sfsmart_set_last_report(context, 'USD Layer Manifest', data, path)
    return data


def _sfsmart_version_key(path: str):
    norm = _sfsmart_norm(path)
    name = _os.path.basename(norm)
    # File-name versions: asset_v001.ext, asset-v001.ext, asset.v001.ext.
    match = _re.search(r'(?P<prefix>.*?)(?P<tag>[._-]?v)(?P<num>\d{2,4})(?P<suffix>(?:[._-][^.]*)?\.[^.]+)$', name, flags=_re.I)
    if match:
        prefix = _re.sub(r'[._-]+$', '', match.group('prefix')).lower()
        return (prefix, 'v', int(match.group('num')), match.group('suffix').lower())
    # Directory versions: .../asset/v001/model.usd or .../shots/010/v003/cache.abc.
    parts = list(_Path(norm).parts)
    for idx, part in enumerate(parts[:-1]):
        m = _re.fullmatch(r'[vV](\d{2,4})', part)
        if not m:
            continue
        prefix = '/'.join([p.lower() for p in parts[max(0, idx-3):idx]] + [name.lower()])
        suffix = _os.path.splitext(name)[1].lower()
        return (prefix, 'v', int(m.group(1)), suffix)
    return None

def _sfsmart_build_version_index(root: str, *, max_files: int = 4000) -> dict:
    index: dict[tuple[str, str, str], list[tuple[int, str]]] = {}
    scanned = 0
    if not root or not _os.path.isdir(root):
        return {}
    for current, dirs, files in _os.walk(root):
        dirs[:] = [d for d in dirs if d not in {'__pycache__', '.git', '.svn', 'node_modules', '.cache'}]
        for name in files:
            full = _os.path.join(current, name)
            key = _sfsmart_version_key(full)
            if key:
                prefix, tag, num, suffix = key
                index.setdefault((prefix, tag, suffix), []).append((num, full))
            scanned += 1
            if scanned >= max_files:
                return index
    return index



def _sfsmart_version_plan(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    root = _sfsmart_norm(getattr(wm, 'sf_smart_search_root', '') or '') or _sfsmart_project_root(context)
    index = _sfsmart_build_version_index(root, max_files=int(getattr(wm, 'sf_smart_max_scan_files', 2500) or 2500))
    items = []
    for record in _sfsmart_datablock_path_records(include_libraries=True):
        old = _sfsmart_norm(record.get('absolute_path') or record.get('path') or '')
        key = _sfsmart_version_key(old)
        if not key:
            continue
        prefix, tag, num, suffix = key
        candidates = sorted(index.get((prefix, tag, suffix), []), key=lambda pair: pair[0], reverse=True)
        newer = [(ver, path) for ver, path in candidates if ver > num and _sfsmart_normcase(path) != _sfsmart_normcase(old)]
        if newer:
            best_ver, best_path = newer[0]
            items.append({
                'owner': record.get('owner', ''),
                'owner_key': record.get('owner_key', ''),
                'record_id': record.get('record_id', ''),
                'kind': record.get('kind', ''),
                'old_path': old,
                'old_version': num,
                'new_path': best_path,
                'new_version': best_ver,
                'new_exists': _os.path.exists(best_path),
                'confidence': 98,
                'reason': 'newer matching version',
                'candidates': [{'version': ver, 'path': path, 'exists': _os.path.exists(path)} for ver, path in newer[:8]],
            })
    plan = {'schema': 'file_pipeline.version_plan.v2', 'created_at': _datetime.datetime.now().isoformat(timespec='seconds'), 'root': root, 'item_count': len(items), 'items': items}
    try:
        wm.sf_smart_version_plan_json = _sfsmart_safe_json(plan)
    except Exception:
        pass
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'plans'), 'version_plan_' + _sfsmart_now_slug() + '.json'), plan)
    _sfsmart_set_last_report(context, 'Version Upgrade Plan', plan, path)
    return plan

def _sfsmart_apply_version_plan(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    try:
        plan = _json.loads(getattr(wm, 'sf_smart_version_plan_json', '') or '{}')
    except Exception:
        plan = {}
    if not plan.get('items'):
        plan = _sfsmart_version_plan(context)
    if not _sfsmart_apply_enabled(context):
        result = {'updated': [], 'failed': [], 'plan': plan, 'apply_changes': False, 'notice': _sfsmart_apply_off_notice()}
        _sfsmart_set_last_report(context, 'Apply Version Plan', result)
        return result
    result = _sfsmart_apply_plan(context, plan)
    _sfsmart_set_last_report(context, 'Apply Version Plan', result)
    return result



def _sfsmart_cache_report(context) -> dict:
    records = _sfsmart_datablock_path_records(include_libraries=False)
    cache_records = []
    missing = []
    total_sequence_members = 0
    for r in records:
        path = str(r.get('absolute_path') or r.get('path') or '')
        ext = _os.path.splitext(path)[1].lower()
        is_cache = str(r.get('kind')) in {'cache', 'volume', 'movie'} or ext in {'.abc', '.usd', '.usda', '.usdc', '.usdz', '.vdb', '.bgeo', '.bgeo.sc', '.mov', '.mp4', '.mkv'}
        if is_cache:
            pub = {k: v for k, v in r.items() if not str(k).startswith('_')}
            pub['frame_range'] = {'first': r.get('first_frame'), 'last': r.get('last_frame')} if r.get('is_sequence') else None
            cache_records.append(pub)
            total_sequence_members += int(r.get('sequence_count') or 0)
            if not r.get('exists') and not r.get('packed'):
                missing.append(pub)
    result = {'schema': 'file_pipeline.cache_report.v2', 'cache_count': len(cache_records), 'missing_count': len(missing), 'sequence_member_count': total_sequence_members, 'records': cache_records, 'missing': missing}
    _sfsmart_set_last_report(context, 'Cache Report', result)
    return result

def _sfsmart_texture_extension_swap(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    src_ext = str(getattr(wm, 'sf_smart_extension_from', '') or '').strip().lower()
    dst_ext = str(getattr(wm, 'sf_smart_extension_to', '') or '').strip().lower()
    apply_changes = bool(getattr(wm, 'sf_smart_apply_changes', False))
    if src_ext and not src_ext.startswith('.'):
        src_ext = '.' + src_ext
    if dst_ext and not dst_ext.startswith('.'):
        dst_ext = '.' + dst_ext
    updated, candidates, skipped = [], [], []
    if not src_ext or not dst_ext:
        result = {'updated': updated, 'candidates': candidates, 'skipped': [{'reason': 'source and target extensions are required'}]}
        _sfsmart_set_last_report(context, 'Texture Extension Swap', result)
        return result
    for record in _sfsmart_datablock_path_records(include_libraries=False):
        if str(record.get('kind')) != 'texture':
            continue
        old = _sfsmart_norm(record.get('absolute_path') or record.get('path') or '')
        if not old.lower().endswith(src_ext):
            continue
        new = old[:-len(src_ext)] + dst_ext
        item = {'owner': record.get('owner', ''), 'old_path': old, 'new_path': new, 'new_exists': _os.path.isfile(new)}
        if _os.path.isfile(new):
            candidates.append(item)
            if apply_changes and _sfsmart_set_record_path(record, new, make_relative=bool(getattr(wm, 'sf_smart_make_relative', True))):
                updated.append(item)
        else:
            skipped.append({**item, 'reason': 'replacement file does not exist'})
    result = {'updated': updated, 'candidates': candidates, 'skipped': skipped, 'apply_changes': apply_changes}
    _sfsmart_set_last_report(context, 'Texture Extension Swap', result)
    return result



def _sfsmart_build_naming_data(context) -> dict:
    unsafe = []
    duplicates: dict[str, list[str]] = {}
    suggestion_collisions: dict[str, list[str]] = {}
    for collection_name in ('objects', 'collections', 'materials', 'images', 'meshes', 'cameras', 'lights', 'node_groups', 'actions'):
        data_collection = getattr(bpy.data, collection_name, None)
        if data_collection is None:
            continue
        seen = {}
        suggestions = {}
        for item in data_collection:
            name = str(getattr(item, 'name', '') or '')
            clean = _sfsmart_safe_filename(name, fallback='item')
            clean = _re.sub(r'[^0-9A-Za-z_.\-]+', '_', clean).strip('_') or 'item'
            issues = []
            if clean != name:
                issues.append(_ui_text('unsafe filesystem or pipeline characters', 'ファイルやパイプラインに向かない文字'))
            if name != name.strip() or '  ' in name:
                issues.append('whitespace')
            if _unicodedata.normalize('NFKC', name) != name:
                issues.append(_ui_text('unicode normalization', 'Unicode の正規化'))
            if issues:
                unsafe.append({'type': collection_name, 'name': name, 'suggested': clean, 'issues': issues, 'severity': 'warning'})
            base = name.lower().split('.')[0]
            seen.setdefault(base, []).append(name)
            suggestions.setdefault(clean.lower(), []).append(name)
        for base, names in seen.items():
            if len(names) > 1:
                duplicates[f'{collection_name}:{base}'] = names
        for clean, names in suggestions.items():
            if len(names) > 1:
                suggestion_collisions[f'{collection_name}:{clean}'] = names
    return {'unsafe_names': unsafe, 'duplicates': duplicates, 'suggestion_collisions': suggestion_collisions}



def _sfsmart_naming_report(context) -> dict:
    result = _sfsmart_build_naming_data(context)
    result['schema'] = 'file_pipeline.naming_report.v2'
    result['issue_count'] = len(result.get('unsafe_names') or []) + len(result.get('duplicates') or {}) + len(result.get('suggestion_collisions') or {})
    _sfsmart_set_last_report(context, 'Naming Cleanup Report', result)
    return result

def _sfsmart_lock_path(context) -> str:
    blend = bpy.data.filepath or 'unsaved.blend'
    name = _re.sub(r'[^0-9A-Za-z_.-]+', '_', _os.path.basename(blend)) or 'unsaved.blend'
    return _os.path.join(_sfsmart_user_dir('locks', create=True), name + '.lock.json')



def _sfsmart_checkout(context, *, checkin: bool = False) -> dict:
    path = _sfsmart_lock_path(context)
    if checkin:
        old = _sfsmart_read_json_file(path, fallback={})
        try:
            if _os.path.exists(path):
                _os.remove(path)
            result = {'unlocked': True, 'previous_lock': old, 'path': path}
        except Exception as exc:
            result = {'unlocked': False, 'previous_lock': old, 'path': path, 'error': str(exc)}
        _sfsmart_set_last_report(context, 'Check In Unlock', result, path)
        return result
    wm = getattr(context, 'window_manager', None)
    user = str(getattr(wm, 'sf_smart_checkout_user', '') or _os.environ.get('USERNAME') or _os.environ.get('USER') or 'unknown')
    existing = _sfsmart_read_json_file(path, fallback={}) if _os.path.exists(path) else {}
    if existing and str(existing.get('user') or '') and str(existing.get('user') or '') != user:
        result = {'locked': False, 'conflict': True, 'existing_lock': existing, 'requested_user': user, 'path': path}
        _sfsmart_set_last_report(context, 'Check Out Lock', result, path)
        return result
    data = {
        'schema': 'file_pipeline.lock.v2',
        'user': user,
        'blend': bpy.data.filepath or '',
        'blend_key': _sfsmart_stable_hash_text(bpy.data.filepath or 'unsaved', 20),
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'host': _os.environ.get('COMPUTERNAME') or _os.environ.get('HOSTNAME') or '',
        'selected_objects': [str(getattr(obj, 'name', '') or '') for obj in list(getattr(context, 'selected_objects', []) or [])],
    }
    _sfsmart_write_json(path, data)
    _sfsmart_set_last_report(context, 'Check Out Lock', data, path)
    return data


def _sfsmart_engine_manifest(context) -> dict:
    inventory = _sfsmart_inventory(context)
    objects = []
    for obj in list(getattr(bpy.data, 'objects', []) or []):
        try:
            matrix = [[float(v) for v in row] for row in obj.matrix_world]
            bbox = []
            try:
                bbox = [[float(v) for v in corner] for corner in getattr(obj, 'bound_box', [])]
            except Exception:
                bbox = []
            objects.append({
                'guid': _sfsmart_object_key(obj),
                'name': str(obj.name),
                'type': str(obj.type),
                'data_name': str(getattr(getattr(obj, 'data', None), 'name', '') or ''),
                'library': _sfsmart_norm(getattr(getattr(obj, 'library', None), 'filepath', '') or ''),
                'parent': str(getattr(getattr(obj, 'parent', None), 'name', '') or ''),
                'children': [str(child.name) for child in list(getattr(obj, 'children', []) or [])],
                'matrix_world': matrix,
                'bound_box': bbox,
                'addressable_key': _sfsmart_safe_filename(str(obj.name).replace(' ', '_')),
                'prefab_scope': 'linked' if getattr(obj, 'library', None) else 'local',
                'components': [{'name': str(getattr(mod, 'name', '') or ''), 'type': str(getattr(mod, 'type', '') or '')} for mod in list(getattr(obj, 'modifiers', []) or [])],
                'materials': [str(getattr(slot.material, 'name', '') or '') for slot in getattr(obj, 'material_slots', [])],
            })
        except Exception:
            pass
    data = {
        'schema': 'file_pipeline.engine_prefab_manifest.v2',
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'blend': bpy.data.filepath or '',
        'targets': {
            'unreal': {'concepts': ['linked_anim_layers', 'scene_graph_prefabs', 'soft_object_paths'], 'recommended_key': 'guid'},
            'unity': {'concepts': ['nested_prefabs', 'scriptable_object_data', 'addressables'], 'recommended_key': 'addressable_key'},
        },
        'object_count': len(objects),
        'objects': objects,
        'external_records': inventory.get('records', []),
        'missing_external_count': inventory.get('missing_count', 0),
    }
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'engine'), 'engine_prefab_manifest_' + _sfsmart_now_slug() + '.json'), data)
    _sfsmart_set_last_report(context, 'Engine Prefab Manifest', data, path)
    return data


def _sfsmart_export_selected_hierarchy(context) -> dict:
    selected = list(getattr(context, 'selected_objects', []) or [])
    if not selected:
        result = {'written': '', 'objects': [], 'error': 'no selected objects'}
        _sfsmart_set_last_report(context, 'Export Selected Hierarchy', result)
        return result
    root = _sfsmart_output_dir(context, 'libraries')
    filepath = _os.path.join(root, f'selected_hierarchy_{_sfsmart_now_slug()}.blend')
    datablocks = set(selected)
    try:
        for obj in selected:
            for child in list(getattr(obj, 'children_recursive', []) or []):
                datablocks.add(child)
            data = getattr(obj, 'data', None)
            if data is not None:
                datablocks.add(data)
                try:
                    for mat in getattr(data, 'materials', []) or []:
                        if mat:
                            datablocks.add(mat)
                            nt = getattr(mat, 'node_tree', None)
                            if nt:
                                datablocks.add(nt)
                                for node in list(getattr(nt, 'nodes', []) or []):
                                    img = getattr(node, 'image', None)
                                    if img:
                                        datablocks.add(img)
                except Exception:
                    pass
            try:
                if getattr(obj, 'animation_data', None) and obj.animation_data.action:
                    datablocks.add(obj.animation_data.action)
            except Exception:
                pass
    except Exception:
        pass
    try:
        bpy.data.libraries.write(filepath, datablocks, fake_user=True)
        manifest = {'schema': 'file_pipeline.exported_hierarchy.v2', 'written': filepath, 'objects': [str(obj.name) for obj in selected], 'datablock_count': len(datablocks), 'datablocks': sorted([_sfsmart_id_owner_label(db) for db in datablocks])}
        _sfsmart_write_json(filepath + '.manifest.json', manifest)
        result = manifest
    except Exception as exc:
        result = {'written': '', 'objects': [str(obj.name) for obj in selected], 'error': str(exc)}
    _sfsmart_set_last_report(context, 'Export Selected Hierarchy', result, filepath)
    return result


def _sfsmart_dependency_graph(context) -> dict:
    inventory = _sfsmart_inventory(context)
    records = _sfsmart_datablock_path_records(include_libraries=True)
    nodes = []
    edges = []

    def add_node(node_id: str, kind: str, label: str, **extra):
        node_id = str(node_id or '').strip()
        if not node_id:
            return
        row = {'id': node_id, 'kind': kind, 'label': str(label or node_id)}
        row.update(extra)
        nodes.append(row)

    for record in records:
        public = {k: v for k, v in record.items() if not str(k).startswith('_')}
        path_value = _sfsmart_norm(public.get('absolute_path') or public.get('path') or '')
        owner_key = str(public.get('owner_key') or public.get('owner') or 'owner')
        owner_id = 'owner:' + _sfsmart_stable_hash_text(owner_key, 20)
        file_id = 'file:' + _sfsmart_stable_hash_text(path_value or owner_key, 24)
        add_node(owner_id, 'datablock_owner', public.get('owner', 'Owner'), owner_key=owner_key, owner_type=public.get('owner_type', ''), property=public.get('property', 'filepath'))
        add_node(file_id, 'external_file', _os.path.basename(path_value) or path_value, path=path_value, exists=bool(public.get('exists')), packed=bool(public.get('packed')), reference_kind=public.get('kind', ''), file_kind=_sfsmart_kind_for_path(path_value), extension=_os.path.splitext(path_value)[1].lower(), size=int(public.get('file_size') or 0), sha1=_sfsmart_file_hash(path_value) if bool(getattr(getattr(context, 'window_manager', None), 'sf_smart_hash_files', False)) and _os.path.isfile(path_value) else '')
        edges.append({'from': owner_id, 'to': file_id, 'relation': 'uses_external_path', 'property': public.get('property', 'filepath'), 'record_id': public.get('record_id', '')})

    for linked in list(inventory.get('linked_ids') or []):
        lib_path = _sfsmart_norm(linked.get('library') or '')
        lib_id = 'file:' + _sfsmart_stable_hash_text(lib_path, 24)
        id_id = 'linked_id:' + _sfsmart_stable_hash_text(str(linked.get('key') or linked), 24)
        add_node(id_id, 'linked_id', linked.get('name', ''), data_type=linked.get('type', ''), override=bool(linked.get('override')))
        if lib_path:
            add_node(lib_id, 'external_file', _os.path.basename(lib_path) or lib_path, path=lib_path, exists=_os.path.exists(lib_path), reference_kind='library', file_kind='library')
            edges.append({'from': lib_id, 'to': id_id, 'relation': 'provides_linked_id'})

    # Object hierarchy edges make the graph useful for assembly review, not just path review.
    for obj in list(getattr(bpy.data, 'objects', []) or []):
        try:
            obj_id = 'object:' + _sfsmart_object_key(obj)
            add_node(obj_id, 'scene_object', str(obj.name), object_type=str(getattr(obj, 'type', '') or ''), linked=bool(getattr(obj, 'library', None)), override=bool(getattr(obj, 'override_library', None)))
            lib = getattr(obj, 'library', None)
            if lib:
                lib_path = _sfsmart_norm(getattr(lib, 'filepath', '') or '')
                edges.append({'from': obj_id, 'to': 'file:' + _sfsmart_stable_hash_text(lib_path, 24), 'relation': 'linked_from'})
            parent = getattr(obj, 'parent', None)
            if parent is not None:
                edges.append({'from': 'object:' + _sfsmart_object_key(parent), 'to': obj_id, 'relation': 'parent_of'})
            for col in list(getattr(obj, 'users_collection', []) or []):
                col_id = 'collection:' + _sfsmart_stable_hash_text(str(getattr(col, 'name', '')), 20)
                add_node(col_id, 'collection', str(getattr(col, 'name', '')))
                edges.append({'from': col_id, 'to': obj_id, 'relation': 'contains_object'})
        except Exception:
            pass

    node_map = {str(n.get('id')): n for n in nodes if n.get('id')}
    duplicate_by_name = {}
    duplicate_by_size = {}
    for record in records:
        path_value = _sfsmart_norm(record.get('absolute_path') or record.get('path') or '')
        if not path_value:
            continue
        base_key = _os.path.basename(path_value).lower()
        duplicate_by_name.setdefault(base_key, set()).add(path_value)
        size = int(record.get('file_size') or 0)
        if size:
            duplicate_by_size.setdefault(f'{base_key}|{size}', set()).add(path_value)
    duplicate_by_name = {k: sorted(v) for k, v in duplicate_by_name.items() if len(v) > 1}
    duplicate_by_size = {k: sorted(v) for k, v in duplicate_by_size.items() if len(v) > 1}
    health = _sfsmart_health_snapshot(context, write_cache=False)
    data = {
        'schema': 'file_pipeline.dependency_graph.v3',
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'blend': bpy.data.filepath or '',
        'project_root': _sfsmart_project_root(context),
        'health_score': int(health.get('score') or 0),
        'grade': health.get('grade', ''),
        'issue_summary': health.get('summary', {}),
        'node_count': len(node_map),
        'edge_count': len(edges),
        'nodes': list(node_map.values()),
        'edges': edges,
        'duplicate_basenames': duplicate_by_name,
        'duplicate_name_size': duplicate_by_size,
    }
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'graphs'), 'dependency_graph_' + _sfsmart_now_slug() + '.json'), data)
    _sfsmart_set_last_report(context, 'Dependency Graph', data, path)
    return data


def _sfsmart_project_quality_audit(context) -> dict:
    inventory = _sfsmart_inventory(context)
    naming = _sfsmart_build_naming_data(context)
    issues = []
    for record in inventory.get('records', []):
        if not record.get('exists') and not record.get('packed'):
            issues.append({'severity': 'blocker', 'code': 'MISSING_EXTERNAL', 'message': 'External path is missing.', 'owner': record.get('owner', ''), 'path': record.get('absolute_path', '')})
        if record.get('path') and _os.path.isabs(_sfsmart_norm(record.get('path'))) and not str(record.get('path')).startswith('//'):
            issues.append({'severity': 'warning', 'code': 'ABSOLUTE_PATH', 'message': 'Path is absolute and less portable.', 'owner': record.get('owner', ''), 'path': record.get('absolute_path', '')})
        if record.get('is_sequence') and int(record.get('sequence_count') or 0) <= 1:
            issues.append({'severity': 'warning', 'code': 'SEQUENCE_INCOMPLETE', 'message': 'Sequence or UDIM pattern has only one detected member.', 'owner': record.get('owner', ''), 'path': record.get('absolute_path', '')})
    for item in naming.get('unsafe_names') or []:
        issues.append({'severity': 'warning', 'code': 'UNSAFE_NAME', 'message': 'Name may be unsafe for pipeline export.', **item})
    for key, names in (naming.get('duplicates') or {}).items():
        issues.append({'severity': 'warning', 'code': 'DUPLICATE_BASE_NAME', 'message': 'Names share the same base and may collide downstream.', 'scope': key, 'names': names})
    lock = _sfsmart_read_json_file(_sfsmart_lock_path(context), fallback={})
    if lock:
        issues.append({'severity': 'info', 'code': 'CHECKOUT_LOCK_PRESENT', 'message': 'A File Pipeline lock exists for this scene.', 'lock': lock})
    score = 100
    for issue in issues:
        if issue.get('severity') == 'blocker':
            score -= 18
        elif issue.get('severity') == 'warning':
            score -= 5
        else:
            score -= 1
    score = max(0, min(100, score))
    result = {
        'schema': 'file_pipeline.project_quality_audit.v1',
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'score': score,
        'ready_for_handoff': score >= 85 and not any(i.get('severity') == 'blocker' for i in issues),
        'issue_count': len(issues),
        'blocker_count': sum(1 for i in issues if i.get('severity') == 'blocker'),
        'warning_count': sum(1 for i in issues if i.get('severity') == 'warning'),
        'inventory_summary': {k: inventory.get(k) for k in ('record_count', 'missing_count', 'absolute_path_count', 'sequence_record_count', 'linked_id_count', 'override_issue_count')},
        'issues': issues,
        'recommended_order': ['Preview Repath', 'Apply Repath', 'Make Paths Relative', 'Collect Package', 'Project Quality Audit'],
    }
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'audits'), 'project_quality_audit_' + _sfsmart_now_slug() + '.json'), result)
    _sfsmart_set_last_report(context, 'Project Quality Audit', result, path)
    return result


def _sfsmart_publish_container_manifest(context) -> dict:
    scope_objects = _sfsmart_scope_objects(context)
    inventory = _sfsmart_inventory(context)
    containers = []
    for obj in scope_objects:
        try:
            lib_path = _sfsmart_norm(getattr(getattr(obj, 'library', None), 'filepath', '') or '')
            representations = []
            data = getattr(obj, 'data', None)
            if data is not None:
                representations.append({'name': 'blend_object', 'kind': 'native', 'data_name': str(getattr(data, 'name', '') or '')})
            for slot in list(getattr(obj, 'material_slots', []) or []):
                if getattr(slot, 'material', None):
                    representations.append({'name': str(slot.material.name), 'kind': 'material'})
            containers.append({
                'container_id': _sfsmart_object_key(obj),
                'name': str(obj.name),
                'namespace': _sfsmart_safe_filename(str(obj.name)).lower(),
                'loader': 'reference' if lib_path else 'local',
                'source_library': lib_path,
                'family': str(getattr(obj, 'type', '') or 'object').lower(),
                'representations': representations,
                'matrix_world': [[float(v) for v in row] for row in obj.matrix_world],
                'dependencies': [r for r in inventory.get('records', []) if lib_path and _sfsmart_normcase(r.get('absolute_path', '')) == _sfsmart_normcase(lib_path)],
            })
        except Exception:
            pass
    data = {
        'schema': 'file_pipeline.publish_container_manifest.v1',
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'blend': bpy.data.filepath or '',
        'project_root': _sfsmart_project_root(context),
        'context': {
            'project': _os.environ.get('AYON_PROJECT_NAME') or _os.environ.get('PRISM_PROJECT') or '',
            'asset': _os.environ.get('AYON_ASSET') or '',
            'task': _os.environ.get('AYON_TASK') or '',
            'user': _os.environ.get('USERNAME') or _os.environ.get('USER') or '',
        },
        'container_count': len(containers),
        'containers': containers,
        'external_records': inventory.get('records', []),
    }
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'publish'), 'publish_container_manifest_' + _sfsmart_now_slug() + '.json'), data)
    _sfsmart_set_last_report(context, 'Publish Container Manifest', data, path)
    return data



def _sfsmart_grade(score: int) -> str:
    score = max(0, min(100, int(score or 0)))
    if score >= 95:
        return 'S'
    if score >= 90:
        return 'A'
    if score >= 80:
        return 'B'
    if score >= 70:
        return 'C'
    if score >= 55:
        return 'D'
    return 'E'


def _sfsmart_health_snapshot(context, *, write_cache: bool = True) -> dict:
    inventory = _sfsmart_inventory(context)
    try:
        naming = _sfsmart_build_naming_data(context)
    except Exception:
        naming = {}
    record_count = int(inventory.get('record_count') or 0)
    missing_count = int(inventory.get('missing_count') or 0)
    absolute_count = int(inventory.get('absolute_path_count') or 0)
    sequence_count = int(inventory.get('sequence_record_count') or 0)
    linked_id_count = int(inventory.get('linked_id_count') or 0)
    override_issue_count = int(inventory.get('override_issue_count') or 0)
    unsafe_count = len(naming.get('unsafe_names') or [])
    duplicate_count = sum(max(0, len(v) - 1) for v in (naming.get('duplicates') or {}).values())
    unsaved = not bool(getattr(bpy.data, 'filepath', '') or '')
    lock_present = False
    try:
        lock_present = _os.path.isfile(_sfsmart_lock_path(context))
    except Exception:
        lock_present = False
    issues = []
    def issue(severity, code, count, message, action=''):
        if int(count or 0) > 0:
            issues.append({'severity': severity, 'code': code, 'count': int(count or 0), 'message': message, 'recommended_action': action})
    issue('blocker', 'MISSING_EXTERNAL_REFERENCES', missing_count, 'External references are missing.', 'SMART_RESOLVE_MISSING')
    issue('warning', 'ABSOLUTE_PATHS', absolute_count, 'Absolute external paths reduce portability across workstations and render nodes.', 'RELATIVE_PATHS')
    issue('warning', 'OVERRIDE_SOURCE_ISSUES', override_issue_count, 'Some overrides have source-library issues and should be reviewed before handoff.', 'SCAN_REFERENCES')
    issue('warning', 'UNSAFE_NAMES', unsafe_count, 'Some names may collide or fail in downstream tools.', 'NAMING_REPORT')
    issue('info', 'DUPLICATE_NAMES', duplicate_count, 'Some datablock names share the same export base.', 'NAMING_REPORT')
    issue('info', 'SEQUENCES_DETECTED', sequence_count, 'Sequences or UDIM families are present and should be included in packages.', 'CACHE_SCAN')
    if unsaved:
        issues.append({'severity': 'warning', 'code': 'UNSAVED_BLEND', 'count': 1, 'message': 'Current .blend is unsaved, so relative-path writes and stable manifests are limited.', 'recommended_action': 'Save the file first'})
    if lock_present:
        issues.append({'severity': 'info', 'code': 'LOCK_PRESENT', 'count': 1, 'message': 'A cooperative lock is active for this scene.', 'recommended_action': 'CHECKIN'})
    score = 100
    score -= min(55, missing_count * 15)
    score -= min(20, absolute_count * 4)
    score -= min(16, override_issue_count * 8)
    score -= min(12, unsafe_count * 3)
    score -= min(8, duplicate_count)
    if unsaved:
        score -= 6
    if linked_id_count > 200:
        score -= 4
    score = max(0, min(100, int(score)))
    recommendations = []
    if missing_count:
        recommendations.append({'priority': 1, 'action': 'Resolve Missing', 'operator_action': 'SMART_RESOLVE_MISSING', 'reason': f'{missing_count} missing external references.', 'reason_ja': f'外部の参照が {missing_count} 件見つかりません。'})
    if absolute_count:
        recommendations.append({'priority': 2, 'action': 'Make Paths Relative', 'operator_action': 'RELATIVE_PATHS', 'reason': f'{absolute_count} absolute paths.', 'reason_ja': f'絶対パスが {absolute_count} 件あります。'})
    if unsafe_count or duplicate_count:
        recommendations.append({'priority': 3, 'action': 'Naming Cleanup Report', 'operator_action': 'NAMING_REPORT', 'reason': f'{unsafe_count + duplicate_count} naming risks.', 'reason_ja': f'名前の問題が {unsafe_count + duplicate_count} 件あります。'})
    recommendations.append({'priority': 4, 'action': 'Collect Package', 'operator_action': 'COLLECT_ASSETS', 'reason': 'Create a portable package after path health is acceptable.'})
    recommendations.append({'priority': 5, 'action': 'Pipeline Super Manifest', 'operator_action': 'PIPELINE_SUPER_MANIFEST', 'reason': 'Write one final handoff manifest for review.'})
    payload = {
        'schema': 'file_pipeline.health_snapshot.v2',
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'blend': bpy.data.filepath or '',
        'score': score,
        'grade': _sfsmart_grade(score),
        'risk_level': 'low' if score >= 90 and missing_count == 0 else ('medium' if score >= 72 else 'high'),
        'ready_for_handoff': score >= 90 and missing_count == 0 and absolute_count == 0,
        'summary': {
            'records': record_count,
            'missing': missing_count,
            'absolute': absolute_count,
            'linked_ids': linked_id_count,
            'override_issues': override_issue_count,
            'unsafe_names': unsafe_count,
            'duplicate_names': duplicate_count,
            'sequences': sequence_count,
            'lock_present': lock_present,
            'unsaved_blend': unsaved,
        },
        'issues': issues,
        'recommendations': sorted(recommendations, key=lambda x: int(x.get('priority', 99))),
    }
    if write_cache:
        try:
            wm = getattr(context, 'window_manager', None)
            wm.sf_smart_last_quality_score = score
            wm.sf_smart_last_health_json = _sfsmart_safe_json(payload)
        except Exception:
            pass
    return payload


def _sfsmart_pipeline_preflight(context) -> dict:
    data = _sfsmart_health_snapshot(context, write_cache=True)
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'reports'), 'pipeline_preflight_' + _sfsmart_now_slug() + '.json'), data)
    _sfsmart_set_last_report(context, 'Pipeline Preflight', data, path)
    return data


def _sfsmart_smart_resolve_missing(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    threshold = int(getattr(wm, 'sf_smart_confidence_threshold', 72) or 72)
    apply_changes = bool(getattr(wm, 'sf_smart_apply_changes', False))
    plan = _sfsmart_build_repath_plan(context)
    items = [item for item in list(plan.get('items') or []) if str(item.get('reason') or '') == 'scored missing-file search']
    confident = [item for item in items if int(item.get('confidence') or 0) >= threshold and item.get('new_exists')]
    unresolved_count = max(0, int(_sfsmart_inventory(context).get('missing_count') or 0) - len(items))
    applied = {'updated': [], 'failed': []}
    if apply_changes and confident:
        applied = _sfsmart_apply_plan(context, {'items': confident})
    result = {
        'schema': 'file_pipeline.smart_resolve_missing.v2',
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'confidence_threshold': threshold,
        'apply_changes': apply_changes,
        'candidate_count': len(items),
        'confident_count': len(confident),
        'unresolved_count': unresolved_count,
        'items': items,
        'confident_items': confident,
        'applied': applied,
    }
    try:
        wm.sf_smart_plan_json = _sfsmart_safe_json({'items': confident or items, 'schema': 'file_pipeline.smart_resolve_plan.v2'})
    except Exception:
        pass
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'plans'), 'smart_resolve_missing_' + _sfsmart_now_slug() + '.json'), result)
    _sfsmart_set_last_report(context, 'Resolve Missing', result, path)
    return result


def _sfsmart_latest_collect_manifest(context) -> str:
    wm = getattr(context, 'window_manager', None)
    candidates = []
    for value in (getattr(wm, 'sf_smart_last_report_path', '') if wm else '', getattr(wm, 'sf_smart_last_manifest_file', '') if wm else ''):
        value = _sfsmart_norm(value)
        if value and _os.path.isfile(value):
            candidates.append(value)
    root = _sfsmart_output_dir(context, 'bundles')
    try:
        for current, dirs, files in _os.walk(root):
            dirs[:] = _sfsmart_skip_dirs(dirs)
            for name in files:
                if name in (_SFSMART_MANIFEST_NAME, _SFSMART_LEGACY_MANIFEST_NAME) or name.endswith('collect_manifest.json'):
                    candidates.append(_os.path.join(current, name))
    except Exception:
        pass
    candidates = [p for p in candidates if _os.path.isfile(p)]
    if not candidates:
        return ''
    candidates.sort(key=lambda p: _os.path.getmtime(p), reverse=True)
    return candidates[0]


def _sfsmart_verify_package(context) -> dict:
    manifest_path = _sfsmart_latest_collect_manifest(context)
    manifest = _sfsmart_read_json_file(manifest_path, fallback={}) if manifest_path else {}
    verified = []
    missing = []
    changed = []
    for item in list((manifest or {}).get('copied') or []):
        members = list(item.get('members') or [])
        if not members and item.get('target'):
            members = [{'target': item.get('target'), 'sha1': item.get('sha1', ''), 'size': item.get('size', 0)}]
        for member in members:
            target = _sfsmart_norm(member.get('target') or '')
            expected_hash = str(member.get('sha1') or '')
            expected_size = int(member.get('size') or 0)
            if not target or not _os.path.isfile(target):
                missing.append({**member, 'target': target, 'reason': 'target file missing'})
                continue
            stat = _sfsmart_stat_record(target)
            actual_hash = _sfsmart_file_hash(target) if expected_hash else ''
            row = {**member, 'target': target, 'actual_size': int(stat.get('size') or 0), 'actual_sha1': actual_hash, 'size_match': not expected_size or expected_size == int(stat.get('size') or 0), 'sha1_match': not expected_hash or expected_hash == actual_hash}
            if not row['size_match'] or not row['sha1_match']:
                changed.append(row)
            else:
                verified.append(row)
    result = {
        'schema': 'file_pipeline.package_verification.v2',
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'manifest_path': manifest_path,
        'verified_count': len(verified),
        'missing_count': len(missing),
        'changed_count': len(changed),
        'status': 'OK' if manifest_path and not missing and not changed else 'REVIEW',
        'verified': verified,
        'missing': missing,
        'changed': changed,
    }
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'reports'), 'package_verification_' + _sfsmart_now_slug() + '.json'), result)
    _sfsmart_set_last_report(context, 'Verify Package', result, path)
    return result


def _sfsmart_material_image_paths(material) -> list[dict]:
    rows = []
    try:
        nodes = list(getattr(getattr(material, 'node_tree', None), 'nodes', []) or [])
    except Exception:
        nodes = []
    for node in nodes:
        try:
            image = getattr(node, 'image', None)
            if image is None:
                continue
            raw = str(getattr(image, 'filepath', '') or getattr(image, 'filepath_raw', '') or '')
            rows.append({'node': str(getattr(node, 'name', '') or ''), 'image': str(getattr(image, 'name', '') or ''), 'path': raw, 'absolute_path': _sfsmart_norm(raw), 'exists': _sfsmart_path_exists(raw)})
        except Exception:
            pass
    return rows


def _sfsmart_material_rules_manifest(context) -> dict:
    materials = {}
    rules = []
    for mat in list(getattr(bpy.data, 'materials', []) or []):
        try:
            materials[str(mat.name)] = {'name': str(mat.name), 'library': _sfsmart_norm(getattr(getattr(mat, 'library', None), 'filepath', '') or ''), 'images': _sfsmart_material_image_paths(mat)}
        except Exception:
            pass
    for obj in list(getattr(bpy.data, 'objects', []) or []):
        try:
            collections = [str(col.name) for col in list(getattr(obj, 'users_collection', []) or [])]
            for index, slot in enumerate(list(getattr(obj, 'material_slots', []) or [])):
                mat = getattr(slot, 'material', None)
                if mat is None:
                    continue
                rules.append({'object_pattern': str(obj.name), 'object_type': str(getattr(obj, 'type', '') or ''), 'collection_patterns': collections, 'library': _sfsmart_norm(getattr(getattr(obj, 'library', None), 'filepath', '') or ''), 'slot_index': index, 'slot_name': str(getattr(slot, 'name', '') or ''), 'material': str(mat.name), 'material_library': _sfsmart_norm(getattr(getattr(mat, 'library', None), 'filepath', '') or ''), 'priority': 1000 + index, 'match_mode': 'exact_object_then_collection_fallback'})
        except Exception:
            pass
    data = {'schema': 'file_pipeline.material_rules.v2', 'created_at': _datetime.datetime.now().isoformat(timespec='seconds'), 'blend': bpy.data.filepath or '', 'rule_count': len(rules), 'rules': rules, 'materials': materials, 'notes': ['Use these rules as lookdev handoff data for layer-based assignment systems.']}
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'lookdev'), 'material_rules_' + _sfsmart_now_slug() + '.json'), data)
    try:
        context.window_manager.sf_smart_material_rule_file = path
    except Exception:
        pass
    _sfsmart_set_last_report(context, 'Material Rule Manifest', data, path)
    return data


def _sfsmart_catalog_duplicate_audit(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    records = _sfsmart_datablock_path_records(include_libraries=bool(getattr(wm, 'sf_smart_include_libraries', True)))
    hash_files = bool(getattr(wm, 'sf_smart_hash_files', False))
    groups = {}
    for rec in records:
        path_value = _sfsmart_norm(rec.get('absolute_path') or rec.get('path') or '')
        if not path_value:
            continue
        stat = _sfsmart_stat_record(path_value)
        key = f"{_os.path.basename(path_value).lower()}|{_os.path.splitext(path_value)[1].lower()}|{int(stat.get('size') or 0)}"
        if hash_files and _os.path.isfile(path_value):
            key = 'sha1:' + _sfsmart_file_hash(path_value)
        row = {k: v for k, v in rec.items() if not str(k).startswith('_')}
        row.update({'fingerprint_key': key, 'size': int(stat.get('size') or 0), 'sha1': _sfsmart_file_hash(path_value) if hash_files and _os.path.isfile(path_value) else ''})
        groups.setdefault(key, []).append(row)
    duplicates = {k: v for k, v in groups.items() if len(v) > 1}
    version_families = {}
    for rec in records:
        key = _sfsmart_version_key(_sfsmart_norm(rec.get('absolute_path') or rec.get('path') or ''))
        if key:
            family_key = f'{key[0]}|{key[1]}|{key[3]}'
            version_families.setdefault(family_key, []).append({k: v for k, v in rec.items() if not str(k).startswith('_')})
    data = {'schema': 'file_pipeline.duplicate_fingerprint_audit.v2', 'created_at': _datetime.datetime.now().isoformat(timespec='seconds'), 'hash_files': hash_files, 'duplicate_group_count': len(duplicates), 'duplicates': duplicates, 'version_family_count': sum(1 for v in version_families.values() if len(v) > 1), 'version_families': {k: v for k, v in version_families.items() if len(v) > 1}}
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'reports'), 'duplicate_fingerprint_audit_' + _sfsmart_now_slug() + '.json'), data)
    _sfsmart_set_last_report(context, 'Catalog Duplicate Audit', data, path)
    return data


def _sfsmart_edit_linked_library(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    apply_changes = bool(getattr(wm, 'sf_smart_apply_changes', False))
    target = ''
    source = ''
    for obj in list(getattr(context, 'selected_objects', []) or []):
        lib = getattr(obj, 'library', None)
        if lib is not None:
            target = _sfsmart_norm(getattr(lib, 'filepath', '') or '')
            source = str(getattr(obj, 'name', '') or '')
            break
    if not target:
        for lib in list(getattr(bpy.data, 'libraries', []) or []):
            target = _sfsmart_norm(getattr(lib, 'filepath', '') or '')
            source = str(getattr(lib, 'name', '') or '')
            if target:
                break
    ticket_path = ''
    if target:
        ticket_path = _os.path.join(_sfsmart_user_dir('runtime', create=True), 'file_pipeline_link_edit_ticket.json')
        _sfsmart_write_json(ticket_path, {'parent_blend': bpy.data.filepath or '', 'child_blend': target, 'source': source, 'created_at': _datetime.datetime.now().isoformat(timespec='seconds')})
    result = {'target': target, 'source': source, 'exists': _os.path.isfile(target), 'apply_changes': apply_changes, 'ticket_path': ticket_path, 'opened': False}
    if not target or not _os.path.isfile(target):
        result['error'] = 'No selected linked library or existing linked library file was found.'
        _sfsmart_set_last_report(context, 'Edit Linked Library', result)
        return result
    if apply_changes:
        try:
            bpy.ops.wm.open_mainfile(filepath=target)
            result['opened'] = True
        except Exception as exc:
            result['error'] = str(exc)
    _sfsmart_set_last_report(context, 'Edit Linked Library', result, target)
    return result


def _sfsmart_pipeline_super_manifest(context) -> dict:
    health = _sfsmart_health_snapshot(context, write_cache=True)
    inventory = _sfsmart_inventory(context)
    graph_path = ''
    usd_path = ''
    engine_path = ''
    try:
        graph = _sfsmart_dependency_graph(context)
        graph_path = str(getattr(getattr(context, 'window_manager', None), 'sf_smart_last_report_path', '') or '')
    except Exception:
        graph = {}
    try:
        usd = _sfsmart_usd_manifest(context)
        usd_path = str(getattr(getattr(context, 'window_manager', None), 'sf_smart_last_report_path', '') or '')
    except Exception:
        usd = {}
    try:
        engine = _sfsmart_engine_manifest(context)
        engine_path = str(getattr(getattr(context, 'window_manager', None), 'sf_smart_last_report_path', '') or '')
    except Exception:
        engine = {}
    data = {
        'schema': 'file_pipeline.pipeline_super_manifest.v3',
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'blend': bpy.data.filepath or '',
        'project_root': _sfsmart_project_root(context),
        'health': health,
        'inventory_summary': {k: inventory.get(k) for k in ('record_count', 'missing_count', 'absolute_path_count', 'linked_id_count', 'override_issue_count')},
        'dependency_graph_path': graph_path,
        'usd_manifest_path': usd_path,
        'engine_manifest_path': engine_path,
        'dependency_summary': {k: graph.get(k) for k in ('schema', 'node_count', 'edge_count', 'health_score', 'grade')},
        'usd_summary': {k: usd.get(k) for k in ('schema', 'usd_count', 'layer_count', 'payload_count', 'unresolved_asset_count')},
        'engine_summary': {k: engine.get(k) for k in ('schema', 'object_count', 'prefab_count')},
        'external_records': inventory.get('records', []),
        'linked_ids': inventory.get('linked_ids', []),
    }
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'manifests'), 'pipeline_super_manifest_' + _sfsmart_now_slug() + '.json'), data)
    try:
        context.window_manager.sf_smart_last_manifest_file = path
    except Exception:
        pass
    _sfsmart_set_last_report(context, 'Pipeline Super Manifest', data, path)
    return data


def _sfsmart_portable_handoff_pack(context) -> dict:
    preflight = _sfsmart_pipeline_preflight(context)
    inventory = _sfsmart_scan_references(context)
    collect = _sfsmart_collect_assets(context)
    verify = _sfsmart_verify_package(context)
    manifest = _sfsmart_pipeline_super_manifest(context)
    result = {
        'schema': 'file_pipeline.portable_handoff_pack.v1',
        'created_at': _datetime.datetime.now().isoformat(timespec='seconds'),
        'preflight_score': int(preflight.get('score') or 0),
        'ready_for_handoff': bool(preflight.get('ready_for_handoff')) and str(verify.get('status')) == 'OK',
        'inventory_path': inventory.get('path', ''),
        'bundle_manifest': (collect.get('manifest_path') or collect.get('target_root') or ''),
        'verification_status': verify.get('status', ''),
        'super_manifest_path': getattr(getattr(context, 'window_manager', None), 'sf_smart_last_manifest_file', ''),
        'steps': {'preflight': preflight, 'inventory': inventory, 'collect': collect, 'verify': verify, 'manifest': manifest},
    }
    path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'handoff'), 'portable_handoff_pack_' + _sfsmart_now_slug() + '.json'), result)
    _sfsmart_set_last_report(context, 'Portable Handoff Pack', result, path)
    return result


def _sfsmart_run_action(context, action: str):
    action = str(action or '').upper()
    if action == 'PIPELINE_PREFLIGHT':
        return _sfsmart_pipeline_preflight(context)
    if action == 'SMART_RESOLVE_MISSING':
        return _sfsmart_smart_resolve_missing(context)
    if action == 'PORTABLE_HANDOFF_PACK':
        return _sfsmart_portable_handoff_pack(context)
    if action == 'SCAN_REFERENCES':
        return _sfsmart_scan_references(context)
    if action == 'COLLECT_ASSETS':
        return _sfsmart_collect_assets(context)
    if action == 'VERIFY_PACKAGE':
        return _sfsmart_verify_package(context)
    if action == 'REPATH_PREVIEW':
        plan = _sfsmart_build_repath_plan(context)
        path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'plans'), 'repath_plan_' + _sfsmart_now_slug() + '.json'), plan)
        _sfsmart_set_last_report(context, 'Preview Repath', plan, path)
        return plan
    if action == 'REPATH_APPLY':
        if not _sfsmart_apply_enabled(context):
            plan = _sfsmart_build_repath_plan(context)
            path = _sfsmart_write_json(_os.path.join(_sfsmart_output_dir(context, 'plans'), 'repath_plan_' + _sfsmart_now_slug() + '.json'), plan)
            result = {'updated': [], 'failed': [], 'plan': plan, 'apply_changes': False, 'notice': _sfsmart_apply_off_notice()}
            _sfsmart_set_last_report(context, 'Apply Repath', result, path)
            return result
        result = _sfsmart_apply_plan(context)
        _sfsmart_set_last_report(context, 'Apply Repath', result)
        return result
    if action == 'RELATIVE_PATHS':
        return _sfsmart_make_paths_relative(context)
    if action == 'RELOAD_LIBRARIES':
        return _sfsmart_reload_libraries(context)
    if action == 'MAKE_LOCAL':
        return _sfsmart_make_local(context)
    if action == 'OVERRIDE_SELECTED':
        return _sfsmart_make_overrides(context)
    if action == 'DISABLE_LINKED':
        return _sfsmart_set_linked_visibility(context, restore=False)
    if action == 'RESTORE_LINKED_VISIBILITY':
        return _sfsmart_set_linked_visibility(context, restore=True)
    if action == 'CAPTURE_DELTA':
        return _sfsmart_capture_delta(context)
    if action == 'COMPARE_DELTA':
        return _sfsmart_compare_delta(context)
    if action == 'RESTORE_DELTA':
        return _sfsmart_restore_delta(context)
    if action == 'SHOT_MANIFEST':
        return _sfsmart_shot_manifest(context, queue=False)
    if action == 'CAMERA_QUEUE':
        return _sfsmart_shot_manifest(context, queue=True)
    if action == 'CATALOG_INDEX':
        return _sfsmart_scan_asset_catalog(context)
    if action == 'USD_MANIFEST':
        return _sfsmart_usd_manifest(context)
    if action == 'VERSION_PLAN':
        return _sfsmart_version_plan(context)
    if action == 'APPLY_VERSION_PLAN':
        return _sfsmart_apply_version_plan(context)
    if action == 'CACHE_SCAN':
        return _sfsmart_cache_report(context)
    if action == 'TEXTURE_EXTENSION_SWAP':
        return _sfsmart_texture_extension_swap(context)
    if action == 'NAMING_REPORT':
        return _sfsmart_naming_report(context)
    if action == 'MATERIAL_RULES':
        return _sfsmart_material_rules_manifest(context)
    if action == 'CATALOG_DUPLICATE_AUDIT':
        return _sfsmart_catalog_duplicate_audit(context)
    if action == 'CHECKOUT':
        return _sfsmart_checkout(context, checkin=False)
    if action == 'CHECKIN':
        return _sfsmart_checkout(context, checkin=True)
    if action == 'ENGINE_MANIFEST':
        return _sfsmart_engine_manifest(context)
    if action == 'EXPORT_HIERARCHY_AS_LIBRARY':
        return _sfsmart_export_selected_hierarchy(context)
    if action == 'PROJECT_QUALITY_AUDIT':
        return _sfsmart_project_quality_audit(context)
    if action == 'DEPENDENCY_GRAPH':
        return _sfsmart_dependency_graph(context)
    if action == 'PUBLISH_CONTAINER':
        return _sfsmart_publish_container_manifest(context)
    if action == 'PIPELINE_SUPER_MANIFEST':
        return _sfsmart_pipeline_super_manifest(context)
    if action == 'EDIT_LINKED_LIBRARY':
        return _sfsmart_edit_linked_library(context)
    result = {'error': _ui_text(f'Unknown File Pipeline action: {action}', f'不明な ファイル パイプライン の操作です：{action}')}
    _sfsmart_set_last_report(context, 'Unknown action', result)
    return result


def sfsmart_register_props(wm_type) -> None:
    if wm_type is None:
        return
    wm_type.sf_smart_workflow = EnumProperty(
        name='Workflow',
        items=[
            ('AUTO', 'Auto', 'Show the recommended compact board for the current scene state.'),
            ('AUDIT', 'Audit', 'Prioritize preflight, dependency graph, naming, duplicate, and package verification tools.'),
            ('REPAIR', 'Repair', 'Prioritize missing reference resolution, path conversion, version upgrades, and extension swaps.'),
            ('ASSEMBLY', 'Assembly', 'Prioritize proxy display, overrides, local materialization, and delta snapshots.'),
            ('PUBLISH', 'Publish', 'Prioritize portable handoff, package collection, container manifests, USD, engine, and shot handoff.'),
        ],
        default='AUTO',
        description='Choose the File Pipeline workflow board shown first in the N-panel. It changes the recommended actions without hiding the full toolset.'
    )
    wm_type.sf_smart_ui_density = EnumProperty(
        name='UI Density',
        items=[
            ('COMFORT', 'Comfort', 'Show explanatory rows and section summaries for safer operation.'),
            ('COMPACT', 'Compact', 'Use shorter groups for smaller N-panel widths.'),
            ('EXPERT', 'Expert', 'Show advanced controls and action groups with less explanatory text.'),
        ],
        default='COMFORT',
        description='Controls how much guidance File Pipeline draws in the N-panel. The setting is stored with the N-panel settings.'
    )
    wm_type.sf_smart_show_advanced = BoolProperty(name='Show Advanced', default=False, description='Show advanced File Pipeline controls such as hashing, sequence analysis, explicit delta/catalog paths, and low-level report paths.')
    wm_type.sf_smart_action_deck_style = EnumProperty(
        name='Action Deck',
        items=[
            ('GUIDED', 'Guided', 'Show workflow-grouped action cards with recommended actions first.'),
            ('ICON', 'Icon Deck', 'Show larger frameless icon-first cards for fast visual operation.'),
            ('DENSE', 'Dense', 'Use compact rows while keeping the custom icons and safety gates.'),
        ],
        default='GUIDED',
        description='Choose how File Pipeline action buttons are arranged in the N-panel. Guided is safest, Icon Deck is the most visual, and Dense is the most compact.',
    )
    wm_type.sf_smart_icon_scale = IntProperty(name='Icon Scale', default=175, min=100, max=260, description='Controls the visual height of File Pipeline custom icon buttons. Icons are drawn without an internal frame and fill the image canvas so they remain readable at larger button sizes.')
    wm_type.sf_smart_frameless_icons = BoolProperty(name='Frameless Icons', default=True, description='Draw File Pipeline custom icon buttons without Blender button embossing where possible. The icon artwork itself has transparent background and no border so the symbol fills the available area.')
    wm_type.sf_smart_show_button_hints = BoolProperty(name='Show Button Hints', default=False, description='Show one-line hints under File Pipeline action labels. Keep disabled for a cleaner panel, enable when learning the workflow.')
    wm_type.sf_smart_hash_files = BoolProperty(name='Hash Files', default=False, description='Compute SHA-1 hashes for audit and duplicate checks. This is more accurate but can be slower on large texture or cache sets.')
    wm_type.sf_smart_analyze_sequences = BoolProperty(name='Analyze Sequences', default=True, description='Analyze UDIM, frame sequence, and cache sequence families when creating inventories, package manifests, and reports.')
    wm_type.sf_smart_confidence_threshold = IntProperty(name='Confidence Threshold', default=72, min=1, max=100, description='Minimum confidence used by Smart Resolve Missing when Apply Changes is enabled. Lower values find more files but increase risk.')
    wm_type.sf_smart_project_root = StringProperty(
        name='Project Root', subtype='DIR_PATH', default='',
        description='Optional manual project root used by File Pipeline scans, catalogs, version upgrade plans, and missing-reference searches. Leave empty to use the current .blend folder or Smart File CONFIG storage.'
    )
    wm_type.sf_smart_search_root = StringProperty(
        name='Search Root', subtype='DIR_PATH', default='',
        description='Optional manual folder searched for missing references, newer versions, watch-folder catalog items, and replacement assets. Leave empty to use Project Root.'
    )
    wm_type.sf_smart_bundle_dir = StringProperty(
        name='Output Folder', subtype='DIR_PATH', default='',
        description='Optional manual output folder for packages, catalogs, manifests, queues, and reports. Leave empty to store generated files inside the Smart File CONFIG data folder.'
    )
    wm_type.sf_smart_scope = EnumProperty(
        name='Scope',
        items=[
            ('SELECTED', 'Selected', 'Operate on selected objects only where the action supports object scope.'),
            ('LINKED', 'Linked only', 'Operate on linked library objects only.'),
            ('ALL', 'All', 'Operate on all scene objects or all external references where supported.'),
        ],
        default='SELECTED',
        description='Choose which objects File Pipeline object-scope actions affect. Path-scope actions always scan relevant external references.'
    )
    wm_type.sf_smart_proxy_mode = EnumProperty(
        name='Proxy Mode',
        items=[
            ('BOUNDS', 'Bounds proxy', 'Show linked objects as bounds and lock selection for lightweight layout.'),
            ('WIRE', 'Wire proxy', 'Show linked objects as wire for animation/layout review.'),
            ('HIDDEN', 'Hidden', 'Hide linked objects in viewport and render.'),
            ('RENDER_ONLY', 'Render only', 'Hide linked objects in viewport but keep them renderable.'),
            ('VIEWPORT_ONLY', 'Viewport only', 'Keep linked objects visible in viewport but hide them from render.'),
        ],
        default='BOUNDS',
        description='Representation applied by Proxy Display. Use Bounds or Wire for large scene assembly, Render Only for heavy assets, and Viewport Only for guides.'
    )
    wm_type.sf_smart_repath_from = StringProperty(name='Replace From', default='', description='Old path prefix to replace during Preview Repath or Apply Repath. Use this for server moves, drive-letter changes, or partner handoff remapping.')
    wm_type.sf_smart_repath_to = StringProperty(name='Replace To', default='', description='New path prefix used by Preview Repath or Apply Repath. Matching references are redirected from Replace From to this folder.')
    wm_type.sf_smart_extension_from = StringProperty(name='Source Extension', default='png', description='Texture extension to replace, for example png. The Texture Extension Swap action only targets image paths with this extension.')
    wm_type.sf_smart_extension_to = StringProperty(name='Target Extension', default='tif', description='Texture extension to use as the replacement, for example tif or exr. Replacement is applied only when the target file exists.')
    wm_type.sf_smart_include_libraries = BoolProperty(name='Include Libraries', default=True, description='Include linked .blend libraries in inventory, collection, repath, and version-plan actions. Disable when you only want textures, caches, fonts, and similar side files.')
    wm_type.sf_smart_make_relative = BoolProperty(name='Use Relative Paths', default=True, description='When File Pipeline writes paths back to Blender datablocks, store them as Blender-relative paths when the current .blend file is saved.')
    wm_type.sf_smart_apply_changes = BoolProperty(name='Apply Changes', default=False, description='When enabled, the actions that change file paths write the change, and Edit Linked Library opens the file: Resolve Missing, Apply Repath, Make Paths Relative, Apply Version Plan, Texture Extension Swap, and Collect Package. When disabled, no paths are written and the library is not opened; Collect Package still copies the files.')
    wm_type.sf_smart_zip_bundle = BoolProperty(name='Create ZIP Bundle', default=True, description='Create a ZIP archive after collecting external assets into a portable package folder.')
    wm_type.sf_smart_max_scan_files = IntProperty(name='Max Scan Files', default=2500, min=100, max=50000, description='Maximum number of files scanned when building catalogs or searching version candidates. Increase for large project roots, reduce for faster checks.')
    wm_type.sf_smart_delta_file = StringProperty(name='Delta File', subtype='FILE_PATH', default='', description='Optional path to a File Pipeline delta snapshot. Leave empty to use the default saved under Smart File CONFIG storage.')
    wm_type.sf_smart_catalog_file = StringProperty(name='Catalog File', subtype='FILE_PATH', default='', description='Last generated File Pipeline catalog JSON. This is stored as an N-panel setting so it survives restart and scene changes.')
    wm_type.sf_smart_plan_json = StringProperty(name='Repath Plan JSON', default='', options={'HIDDEN'}, description='Last generated File Pipeline repath plan stored for review or Apply Repath.')
    wm_type.sf_smart_version_plan_json = StringProperty(name='Version Plan JSON', default='', options={'HIDDEN'}, description='Last generated File Pipeline version upgrade plan stored for Apply Version Plan.')
    wm_type.sf_smart_checkout_user = StringProperty(name='Checkout User', default='', description='User name written into File Pipeline lock records. Empty uses the current operating system user name.')
    wm_type.sf_smart_last_quality_score = IntProperty(name='Last Quality Score', default=0, min=0, max=100, options={'HIDDEN'}, description='Last cached File Pipeline preflight score.')
    wm_type.sf_smart_last_health_json = StringProperty(name='Last Health JSON', default='', options={'HIDDEN'}, description='Last cached File Pipeline preflight health payload.')
    wm_type.sf_smart_material_rule_file = StringProperty(name='Material Rule File', default='', options={'HIDDEN'}, description='Last generated material rule manifest path.')
    wm_type.sf_smart_last_manifest_file = StringProperty(name='Last Manifest File', default='', options={'HIDDEN'}, description='Last generated pipeline super manifest or handoff manifest path.')
    wm_type.sf_smart_last_report = StringProperty(name='Last Report', default='', options={'HIDDEN'}, description='Latest File Pipeline report body kept in the N-panel settings store.')
    wm_type.sf_smart_last_report_title = StringProperty(name='Last Report Title', default='', options={'HIDDEN'}, description='Title of the latest File Pipeline report.')
    wm_type.sf_smart_last_report_path = StringProperty(name='Last Report Path', default='', options={'HIDDEN'}, description='File path of the latest File Pipeline JSON manifest or report.')


def sfsmart_unregister_props(wm_type) -> None:
    for name in (
        'sf_smart_workflow', 'sf_smart_ui_density', 'sf_smart_show_advanced', 'sf_smart_action_deck_style', 'sf_smart_icon_scale', 'sf_smart_frameless_icons', 'sf_smart_show_button_hints', 'sf_smart_hash_files', 'sf_smart_analyze_sequences', 'sf_smart_confidence_threshold',
        'sf_smart_project_root', 'sf_smart_search_root', 'sf_smart_bundle_dir', 'sf_smart_scope', 'sf_smart_proxy_mode',
        'sf_smart_repath_from', 'sf_smart_repath_to', 'sf_smart_extension_from', 'sf_smart_extension_to',
        'sf_smart_include_libraries', 'sf_smart_make_relative', 'sf_smart_apply_changes', 'sf_smart_zip_bundle', 'sf_smart_max_scan_files',
        'sf_smart_delta_file', 'sf_smart_catalog_file', 'sf_smart_plan_json', 'sf_smart_version_plan_json', 'sf_smart_checkout_user',
        'sf_smart_last_quality_score', 'sf_smart_last_health_json', 'sf_smart_material_rule_file', 'sf_smart_last_manifest_file',
        'sf_smart_last_report', 'sf_smart_last_report_title', 'sf_smart_last_report_path',
    ):
        try:
            if hasattr(wm_type, name):
                delattr(wm_type, name)
        except Exception:
            pass


def _sfsmart_draw_report_preview(layout, context):
    wm = getattr(context, 'window_manager', None)
    title = str(getattr(wm, 'sf_smart_last_report_title', '') or '')
    path = str(getattr(wm, 'sf_smart_last_report_path', '') or '')
    report = str(getattr(wm, 'sf_smart_last_report', '') or '')
    box = layout.box()
    _sfsmart_label_with_custom_icon(box, 'Last File Pipeline Report', 'report', 'TEXT')
    if title:
        box.label(text=_sf_short_label_display(title, 72))
    if path:
        box.label(text=_sf_short_label_display(path, 100), icon='FILE_TICK', translate=False)
    if report:
        for line in report.splitlines()[:12]:
            if line.strip():
                box.label(text=_sf_short_label_display(line, 120), icon='BLANK1')
    else:
        box.label(text=_t('No report has been generated yet.'))


def _sfsmart_action_button(parent, action: str, text: str, icon: str = 'CHECKMARK'):
    row = parent.row(align=True)
    op = row.operator(SF_OT_file_pipeline_run_action.bl_idname, text=_t(text), icon=icon)
    try:
        op.action = action
    except Exception:
        pass
    _sf_draw_help_button(row, help_key='tool', operator_id=SF_OT_file_pipeline_run_action.bl_idname, title=text, text='', icon='QUESTION')
    return op


def _sfsmart_cached_health(context) -> dict:
    wm = getattr(context, 'window_manager', None)
    try:
        raw = str(getattr(wm, 'sf_smart_last_health_json', '') or '')
        if raw:
            return _json.loads(raw)
    except Exception:
        pass
    return {}


def _sfsmart_prop(parent, owner, prop: str, *, text: str | None = None):
    try:
        if text is None:
            return parent.prop(owner, prop)
        return parent.prop(owner, prop, text=_t(text))
    except Exception:
        return None


def _sfsmart_action_icon_key(action: str) -> str:
    return _SFSMART_ACTION_ICON_KEYS.get(str(action or '').upper(), 'hub')


def _sfsmart_action_icon_value(action: str, fallback: int = 0) -> int:
    try:
        return int(_sfsmart_icon_id(_sfsmart_action_icon_key(action), fallback=fallback) or 0)
    except Exception:
        return int(fallback or 0)


def _sfsmart_ui_scale(context=None) -> float:
    wm = getattr(context or bpy.context, 'window_manager', None)
    try:
        value = int(getattr(wm, 'sf_smart_icon_scale', 175) or 175)
    except Exception:
        value = 175
    density = str(getattr(wm, 'sf_smart_ui_density', 'COMFORT') or 'COMFORT').upper() if wm is not None else 'COMFORT'
    if density == 'COMPACT':
        value = min(value, 145)
    elif density == 'EXPERT':
        value = max(value, 155)
    return max(1.0, min(2.6, value / 100.0))


def _sfsmart_set_action(op, action: str):
    try:
        op.action = action
    except Exception:
        pass
    return op


def _sfsmart_label_with_custom_icon(parent, text: str, icon_key: str, fallback: str = 'ASSET_MANAGER'):
    icon_value = 0
    try:
        icon_value = int(_sfsmart_icon_id(icon_key, fallback=0) or 0)
    except Exception:
        icon_value = 0
    try:
        if icon_value:
            return parent.label(text=_t(text), icon_value=icon_value)
    except Exception:
        pass
    return parent.label(text=_t(text), icon=fallback)


def _sfsmart_run_button(parent, action: str, label: str, icon: str = 'CHECKMARK', *, danger: bool = False):
    wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    row = parent.row(align=True)
    try:
        row.alert = bool(danger)
    except Exception:
        pass
    scale = _sfsmart_ui_scale(getattr(bpy, 'context', None))
    frameless = bool(getattr(wm, 'sf_smart_frameless_icons', True)) if wm is not None else True
    show_hints = bool(getattr(wm, 'sf_smart_show_button_hints', False)) if wm is not None else False
    icon_value = _sfsmart_action_icon_value(action)
    op = None
    if icon_value:
        icon_slot = row.row(align=True)
        icon_slot.ui_units_x = scale
        icon_slot.scale_y = scale
        try:
            op = icon_slot.operator(SF_OT_file_pipeline_run_action.bl_idname, text='', icon_value=icon_value, emboss=True)
            _sfsmart_set_action(op, action)
        except TypeError:
            op = icon_slot.operator(SF_OT_file_pipeline_run_action.bl_idname, text='', icon_value=icon_value, emboss=True)
            _sfsmart_set_action(op, action)
        except Exception:
            op = None
    label_col = row.column(align=True)
    label_col.scale_y = max(1.0, min(1.42, scale * 0.72))
    try:
        if op is None:
            op = label_col.operator(SF_OT_file_pipeline_run_action.bl_idname, text=_t(label), icon=icon, emboss=not frameless)
        else:
            text_op = label_col.operator(SF_OT_file_pipeline_run_action.bl_idname, text=_t(label), icon='NONE', emboss=False if frameless else True)
            _sfsmart_set_action(text_op, action)
        _sfsmart_set_action(op, action)
    except Exception:
        try:
            label_col.label(text=_t(label), icon=icon)
        except Exception:
            pass
    if show_hints:
        desc = _SFSMART_ACTION_DESC_MAP.get(str(action or '').upper(), '')
        if desc:
            label_col.label(text=_sf_short_label_display(_t(desc), 96), icon='BLANK1')
    help_slot = row.row(align=True)
    help_slot.scale_x = 0.82
    help_slot.scale_y = 1.0
    _sf_draw_help_button(help_slot, help_key='file_pipeline_action', section=str(action or ''), operator_id=SF_OT_file_pipeline_run_action.bl_idname, title=label, text='', icon='QUESTION')
    return op


def _sfsmart_score_bar(score: int, width: int = 12) -> str:
    try:
        score = max(0, min(100, int(score or 0)))
    except Exception:
        score = 0
    filled = int(round((score / 100.0) * max(1, width)))
    return '▰' * filled + '▱' * max(0, width - filled)


def _sfsmart_draw_command_center(layout, context):
    wm = getattr(context, 'window_manager', None)
    box = layout.box()
    header = box.row(align=True)
    _sfsmart_label_with_custom_icon(header, 'Command Center', 'hub', 'ASSET_MANAGER')
    header_help = header.row(align=True)
    header_help.alignment = 'RIGHT'
    _sf_draw_help_button(header_help, help_key='file_pipeline_section', section='SFSMART_COMMAND_CENTER', operator_id=SF_OT_file_pipeline_open.bl_idname, title=_t('Command Center'), text='', icon='QUESTION')
    if wm is None:
        box.label(text=_t('WindowManager settings are unavailable.'), icon='ERROR')
        return
    health = _sfsmart_cached_health(context)
    summary = dict(health.get('summary') or {}) if health else {}
    score = int(health.get('score') or getattr(wm, 'sf_smart_last_quality_score', 0) or 0)
    grade = str(health.get('grade') or (_sfsmart_grade(score) if score else '-'))
    ready = bool(health.get('ready_for_handoff')) if health else False
    status_box = box.box()
    row = status_box.row(align=True)
    row.label(text=f"{_t('Quality Score')}: {score if score else '-'}  {_sfsmart_score_bar(score)}", icon='CHECKMARK' if ready else ('ERROR' if score else 'QUESTION'))
    row.label(text=f"{_t('Grade')}: {grade}", icon='BLANK1')
    row.label(text=_t('Ready for handoff') if ready else _t('Needs review'), icon='CHECKMARK' if ready else 'ERROR')
    grid = status_box.grid_flow(columns=4, row_major=True, even_columns=True, even_rows=False, align=True)
    for label, key, icon in (
        ('Records', 'records', 'FILE'),
        ('Missing', 'missing', 'ERROR' if int(summary.get('missing') or 0) else 'CHECKMARK'),
        ('Absolute', 'absolute', 'NONE' if int(summary.get('absolute') or 0) else 'CHECKMARK'),
        ('Linked IDs', 'linked_ids', 'LINKED'),
        ('Overrides', 'override_issues', 'LIBRARY_DATA_OVERRIDE'),
        ('Unsafe Names', 'unsafe_names', 'SORTALPHA'),
        ('Duplicates', 'duplicate_names', 'DUPLICATE'),
        ('Sequences', 'sequences', 'SEQ_STRIP_META'),
    ):
        cell = grid.column(align=True)
        cell.label(text=f"{_t(label)}: {int(summary.get(key) or 0)}", icon=icon)
    if not health:
        status_box.label(text=_t('Run Pipeline Preflight to populate this board with a current score and recommendations.'))
    else:
        for rec in list(health.get('recommendations') or [])[:3]:
            status_box.label(text=f"{_t('Next')}: {_t(str(rec.get('action') or ''))} — {_ui_text(str(rec.get('reason') or ''), str(rec.get('reason_ja') or _t(str(rec.get('reason') or ''))))[:120]}", icon='FORWARD')
    quick = box.box()
    quick_header = quick.row(align=True)
    quick_header.label(text=_t('Recommended Actions'), icon='CHECKMARK')
    quick_help = quick_header.row(align=True)
    quick_help.alignment = 'RIGHT'
    _sf_draw_help_button(quick_help, help_key='file_pipeline_section', section='SFSMART_RECOMMENDED_ACTIONS', operator_id=SF_OT_file_pipeline_open.bl_idname, title=_t('Recommended Actions'), text='', icon='QUESTION')
    row = quick.row(align=True)
    _sfsmart_run_button(row, 'PIPELINE_PREFLIGHT', 'Pipeline Preflight', 'VIEWZOOM')
    _sfsmart_run_button(row, 'SMART_RESOLVE_MISSING', 'Resolve Missing', 'FILE_REFRESH')
    row = quick.row(align=True)
    _sfsmart_run_button(row, 'PORTABLE_HANDOFF_PACK', 'Portable Handoff Pack', 'PACKAGE')
    _sfsmart_run_button(row, 'PIPELINE_SUPER_MANIFEST', 'Pipeline Super Manifest', 'NETWORK_DRIVE')
    row = quick.row(align=True)
    try:
        row.operator(SF_OT_file_pipeline_open_report.bl_idname, text=_t('Open Report'), icon='TEXT')
        row.operator(SF_OT_file_pipeline_open_icon_reference.bl_idname, text=_t('Open Icon Reference'), icon_value=_sfsmart_icon_id('reference_board', 0) or 0)
    except Exception:
        pass
    _sfsmart_run_button(row, 'VERIFY_PACKAGE', 'Verify Package', 'FILE_TICK')


def _sfsmart_draw_settings(layout, context):
    wm = getattr(context, 'window_manager', None)
    box = layout.box()
    header = box.row(align=True)
    header.label(text=_t('File Pipeline Settings'), icon='PREFERENCES')
    help_row = header.row(align=True)
    help_row.alignment = 'RIGHT'
    _sf_draw_help_button(help_row, help_key='file_pipeline_section', section='SFSMART_SETTINGS', operator_id=SF_OT_file_pipeline_open.bl_idname, title=_t('File Pipeline Settings'), text='', icon='QUESTION')
    if wm is None:
        box.label(text=_t('WindowManager settings are unavailable.'), icon='ERROR')
        return
    row = box.row(align=True)
    _sfsmart_prop(row, wm, 'sf_smart_workflow')
    _sfsmart_prop(row, wm, 'sf_smart_ui_density')
    _sfsmart_prop(row, wm, 'sf_smart_show_advanced')
    visual = box.box()
    visual_header = visual.row(align=True)
    visual_header.label(text=_t('Visual Operation'), icon='IMAGE_DATA')
    visual_help = visual_header.row(align=True)
    visual_help.alignment = 'RIGHT'
    _sf_draw_help_button(visual_help, help_key='file_pipeline_section', section='SFSMART_VISUAL_OPERATION', operator_id=SF_OT_file_pipeline_open.bl_idname, title=_t('Visual Operation'), text='', icon='QUESTION')
    row = visual.row(align=True)
    _sfsmart_prop(row, wm, 'sf_smart_action_deck_style')
    _sfsmart_prop(row, wm, 'sf_smart_icon_scale')
    toggles = visual.grid_flow(columns=2, row_major=True, even_columns=True, even_rows=False, align=True)
    for prop in ('sf_smart_frameless_icons', 'sf_smart_show_button_hints'):
        _sfsmart_prop(toggles, wm, prop)
    roots = box.box()
    roots_header = roots.row(align=True)
    roots_header.label(text=_t('Roots and Output'), icon='FILE_FOLDER')
    roots_help = roots_header.row(align=True)
    roots_help.alignment = 'RIGHT'
    _sf_draw_help_button(roots_help, help_key='file_pipeline_section', section='SFSMART_ROOTS_OUTPUT', operator_id=SF_OT_file_pipeline_open.bl_idname, title=_t('Roots and Output'), text='', icon='QUESTION')
    for prop in ('sf_smart_project_root', 'sf_smart_search_root', 'sf_smart_bundle_dir'):
        _sfsmart_prop(roots, wm, prop)
    behavior = box.box()
    behavior_header = behavior.row(align=True)
    behavior_header.label(text=_t('Behavior and Safety'), icon='TOOL_SETTINGS')
    behavior_help = behavior_header.row(align=True)
    behavior_help.alignment = 'RIGHT'
    _sf_draw_help_button(behavior_help, help_key='file_pipeline_section', section='SFSMART_BEHAVIOR_SAFETY', operator_id=SF_OT_file_pipeline_open.bl_idname, title=_t('Behavior and Safety'), text='', icon='QUESTION')
    row = behavior.row(align=True)
    _sfsmart_prop(row, wm, 'sf_smart_scope')
    _sfsmart_prop(row, wm, 'sf_smart_proxy_mode')
    toggles = behavior.grid_flow(columns=2, row_major=True, even_columns=True, even_rows=False, align=True)
    for prop in ('sf_smart_include_libraries', 'sf_smart_make_relative', 'sf_smart_apply_changes', 'sf_smart_zip_bundle'):
        _sfsmart_prop(toggles, wm, prop)
    advanced = bool(getattr(wm, 'sf_smart_show_advanced', False)) or str(getattr(wm, 'sf_smart_ui_density', 'COMFORT')) == 'EXPERT'
    if advanced:
        adv = box.box()
        adv_header = adv.row(align=True)
        adv_header.label(text=_t('Advanced Precision'), icon='MODIFIER')
        adv_help = adv_header.row(align=True)
        adv_help.alignment = 'RIGHT'
        _sf_draw_help_button(adv_help, help_key='file_pipeline_section', section='SFSMART_ADVANCED_PRECISION', operator_id=SF_OT_file_pipeline_open.bl_idname, title=_t('Advanced Precision'), text='', icon='QUESTION')
        row = adv.row(align=True)
        _sfsmart_prop(row, wm, 'sf_smart_confidence_threshold')
        _sfsmart_prop(row, wm, 'sf_smart_max_scan_files')
        toggles = adv.grid_flow(columns=2, row_major=True, even_columns=True, even_rows=False, align=True)
        for prop in ('sf_smart_hash_files', 'sf_smart_analyze_sequences'):
            _sfsmart_prop(toggles, wm, prop)
        col = adv.column(align=True)
        for prop in ('sf_smart_repath_from', 'sf_smart_repath_to', 'sf_smart_extension_from', 'sf_smart_extension_to', 'sf_smart_delta_file', 'sf_smart_catalog_file', 'sf_smart_checkout_user'):
            _sfsmart_prop(col, wm, prop)
    else:
        compact = box.row(align=True)
        _sfsmart_prop(compact, wm, 'sf_smart_confidence_threshold')
        _sfsmart_prop(compact, wm, 'sf_smart_max_scan_files')


def _sfsmart_draw_actions(layout, context):
    wm = getattr(context, 'window_manager', None)
    workflow = str(getattr(wm, 'sf_smart_workflow', 'AUTO') or 'AUTO').upper()
    advanced = bool(getattr(wm, 'sf_smart_show_advanced', False)) or str(getattr(wm, 'sf_smart_ui_density', 'COMFORT')) == 'EXPERT'
    deck_style = str(getattr(wm, 'sf_smart_action_deck_style', 'GUIDED') or 'GUIDED').upper()
    sections = [
        ('Audit and repair', 'VIEWZOOM', [
            ('PIPELINE_PREFLIGHT', 'Pipeline Preflight', 'VIEWZOOM', False),
            ('SCAN_REFERENCES', 'Reference Inventory', 'FILE_TEXT', False),
            ('SMART_RESOLVE_MISSING', 'Resolve Missing', 'FILE_REFRESH', False),
            ('REPATH_PREVIEW', 'Preview Repath', 'VIEWZOOM', False),
            ('REPATH_APPLY', 'Apply Repath', 'CHECKMARK', True),
            ('RELATIVE_PATHS', 'Make Paths Relative', 'FILE_REFRESH', True),
        ]),
        ('Package and publish', 'PACKAGE', [
            ('PORTABLE_HANDOFF_PACK', 'Portable Handoff Pack', 'PACKAGE', False),
            ('COLLECT_ASSETS', 'Collect Package', 'EXPORT', False),
            ('VERIFY_PACKAGE', 'Verify Package', 'FILE_TICK', False),
            ('PIPELINE_SUPER_MANIFEST', 'Pipeline Super Manifest', 'NETWORK_DRIVE', False),
            ('PUBLISH_CONTAINER', 'Publish Container Manifest', 'ASSET_MANAGER', False),
            ('ENGINE_MANIFEST', 'Engine Prefab Manifest', 'OUTLINER_OB_GROUP_INSTANCE', False),
        ]),
        ('Assembly and overrides', 'MOD_WIREFRAME', [
            ('DISABLE_LINKED', 'Proxy Display', 'HIDE_OFF', False),
            ('RESTORE_LINKED_VISIBILITY', 'Restore Display', 'RESTRICT_VIEW_OFF', False),
            ('OVERRIDE_SELECTED', 'Make Library Overrides', 'LIBRARY_DATA_OVERRIDE', True),
            ('MAKE_LOCAL', 'Materialize Links', 'APPEND_BLEND', True),
            ('CAPTURE_DELTA', 'Capture Delta', 'PRESET', False),
            ('COMPARE_DELTA', 'Compare Delta', 'VIEWZOOM', False),
            ('RESTORE_DELTA', 'Restore Delta', 'LOOP_BACK', True),
            ('EDIT_LINKED_LIBRARY', 'Edit Linked Library', 'FILE_FOLDER', True),
        ]),
        ('Shot, cache, USD, and lookdev', 'SCENE_DATA', [
            ('SHOT_MANIFEST', 'Shot Manifest', 'FILE_TEXT', False),
            ('CAMERA_QUEUE', 'Camera Queue', 'RENDER_STILL', False),
            ('CACHE_SCAN', 'Cache Report', 'FILE', False),
            ('USD_MANIFEST', 'USD Layer Manifest', 'FILE_BLEND', False),
            ('MATERIAL_RULES', 'Material Rule Manifest', 'MATERIAL', False),
        ]),
        ('Catalog and maintenance', 'ASSET_MANAGER', [
            ('CATALOG_INDEX', 'Build Asset Catalog', 'ASSET_MANAGER', False),
            ('CATALOG_DUPLICATE_AUDIT', 'Catalog Duplicate Audit', 'ZOOM_SELECTED', False),
            ('VERSION_PLAN', 'Version Upgrade Plan', 'SORTTIME', False),
            ('APPLY_VERSION_PLAN', 'Apply Version Plan', 'CHECKMARK', True),
            ('TEXTURE_EXTENSION_SWAP', 'Texture Extension Swap', 'IMAGE_DATA', True),
            ('NAMING_REPORT', 'Naming Cleanup Report', 'SORTALPHA', False),
            ('PROJECT_QUALITY_AUDIT', 'Project Quality Audit', 'CHECKMARK', False),
            ('DEPENDENCY_GRAPH', 'Dependency Graph', 'NODETREE', False),
            ('CHECKOUT', 'Check Out Lock', 'LOCKED', False),
            ('CHECKIN', 'Check In Unlock', 'UNLOCKED', False),
            ('EXPORT_HIERARCHY_AS_LIBRARY', 'Export Selected Hierarchy', 'EXPORT', False),
        ]),
    ]
    if deck_style == 'ICON':
        box = layout.box()
        box_header = box.row(align=True)
        _sfsmart_label_with_custom_icon(box_header, 'Icon Action Deck', 'hub', 'ASSET_MANAGER')
        box_help = box_header.row(align=True)
        box_help.alignment = 'RIGHT'
        _sf_draw_help_button(box_help, help_key='file_pipeline_section', section='SFSMART_ICON_DECK', operator_id=SF_OT_file_pipeline_open.bl_idname, title=_t('Icon Action Deck'), text='', icon='QUESTION')
        grid = box.grid_flow(columns=3, row_major=True, even_columns=True, even_rows=False, align=True)
        for action, label, _desc in _SFSMART_ACTION_ITEMS:
            if action in {'REPATH_APPLY', 'OVERRIDE_SELECTED', 'MAKE_LOCAL', 'RESTORE_DELTA', 'APPLY_VERSION_PLAN', 'TEXTURE_EXTENSION_SWAP', 'EDIT_LINKED_LIBRARY'} and not advanced:
                continue
            _sfsmart_run_button(grid.column(align=True), action, label, 'CHECKMARK', danger=action in {'REPATH_APPLY', 'OVERRIDE_SELECTED', 'MAKE_LOCAL', 'RESTORE_DELTA', 'APPLY_VERSION_PLAN', 'TEXTURE_EXTENSION_SWAP', 'EDIT_LINKED_LIBRARY'})
        return
    priority = {
        'AUDIT': {'Audit and repair', 'Catalog and maintenance'},
        'REPAIR': {'Audit and repair', 'Catalog and maintenance'},
        'ASSEMBLY': {'Assembly and overrides', 'Audit and repair'},
        'PUBLISH': {'Package and publish', 'Shot, cache, USD, and lookdev'},
    }.get(workflow, None)
    for title, icon, actions in sections:
        if priority is not None and title not in priority and not advanced:
            continue
        box = layout.box()
        header = box.row(align=True)
        _sfsmart_label_with_custom_icon(header, title, 'hub' if title == 'File Pipeline' else _sfsmart_action_icon_key(actions[0][0]) if actions else 'hub', icon)
        section_map = {'Audit and repair': 'SFSMART_AUDIT_REPAIR', 'Package and publish': 'SFSMART_PACKAGE_PUBLISH', 'Assembly and overrides': 'SFSMART_ASSEMBLY_OVERRIDES', 'Shot, cache, USD, and lookdev': 'SFSMART_SHOT_CACHE_USD_LOOKDEV', 'Catalog and maintenance': 'SFSMART_CATALOG_MAINTENANCE'}
        header_help = header.row(align=True)
        header_help.alignment = 'RIGHT'
        _sf_draw_help_button(header_help, help_key='file_pipeline_section', section=section_map.get(title, ''), operator_id=SF_OT_file_pipeline_open.bl_idname, title=_t(title), text='', icon='QUESTION')
        grid = box.grid_flow(columns=2, row_major=True, even_columns=True, even_rows=False, align=True)
        for action, label, btn_icon, danger in actions:
            if danger and not advanced and action not in {'REPATH_APPLY', 'RELATIVE_PATHS'}:
                continue
            _sfsmart_run_button(grid.column(align=True), action, label, btn_icon, danger=danger)


def draw_file_pipeline_ui(layout, context, *, embedded: bool = False):
    hero = layout.box()
    row = hero.row(align=True)
    _sfsmart_label_with_custom_icon(row, 'File Pipeline', 'hub', 'ASSET_MANAGER')
    row_help = row.row(align=True)
    row_help.alignment = 'RIGHT'
    _sf_draw_help_button(row_help, help_key='file_pipeline', operator_id=SF_OT_file_pipeline_open.bl_idname, title='File Pipeline', text='', icon='QUESTION')
    _sfsmart_draw_command_center(layout, context)
    _sfsmart_draw_settings(layout, context)
    _sfsmart_draw_actions(layout, context)
    _sfsmart_draw_report_preview(layout, context)


class SF_OT_file_pipeline_open(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = 'import_scene.sfs_file_pipeline_open'
    bl_label = 'Open'
    bl_description = 'Open the File Pipeline hub. It consolidates external-reference inventory, path repath, asset collection, catalog indexing, scene assembly, delta snapshots, cache reports, shot manifests, version upgrade plans, engine handoff manifests, and check-in/check-out locks in the Smart File N-panel workflow.'
    bl_options = {'INTERNAL'}

    popup_width: IntProperty(default=1040, min=640, max=1400, options={'HIDDEN'})

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=int(self.popup_width or 1040))

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        draw_file_pipeline_ui(self.layout, context, embedded=False)


class SF_OT_file_pipeline_run_action(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_file_pipeline_run_action'
    bl_label = 'Run Action'
    bl_description = 'Run one File Pipeline action. Use the action buttons in the File Pipeline hub; path-changing actions respect the Apply Changes switch, relative-path switch, scope selector, output folder, project root, and search root stored in the N-panel.'
    bl_options = {'UNDO'}

    action: EnumProperty(name='Action', items=_SFSMART_ACTION_ITEMS, default='SCAN_REFERENCES')

    @classmethod
    def description(cls, context, properties):
        action = str(getattr(properties, 'action', '') or '')
        label = _t(dict((item[0], item[1]) for item in _SFSMART_ACTION_ITEMS).get(action, 'File Pipeline action'))
        desc = _t(dict((item[0], item[2]) for item in _SFSMART_ACTION_ITEMS).get(action, cls.bl_description))
        return f'{label}: {desc}'

    def execute(self, context):
        try:
            result = _sfsmart_run_action(context, self.action)
            if isinstance(result, dict) and result.get('error'):
                self.report({'WARNING'}, str(result.get('error'))[:220])
                return {'CANCELLED'}
            if isinstance(result, dict) and result.get('notice'):
                self.report({'WARNING'}, str(result.get('notice')))
                return {'FINISHED'}
            self.report({'INFO'}, _t('File Pipeline action completed.'))
            return {'FINISHED'}
        except Exception as exc:
            _sfsmart_set_last_report(context, 'File Pipeline error', {'action': self.action, 'error': str(exc)})
            self.report({'ERROR'}, str(exc)[:220])
            return {'CANCELLED'}


class SF_OT_file_pipeline_open_report(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_file_pipeline_open_report'
    bl_label = 'Open Report'
    bl_description = 'Open the latest File Pipeline report in Blender Text Editor data so it can be copied, saved, or inspected without searching the output folder.'
    bl_options = {'UNDO', 'INTERNAL'}

    def execute(self, context):
        try:
            report = str(getattr(context.window_manager, 'sf_smart_last_report', '') or '')
            _sfsmart_text_report(str(getattr(context.window_manager, 'sf_smart_last_report_title', '') or 'File Pipeline Report'), report or 'No report has been generated yet.')
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc)[:220])
            return {'CANCELLED'}


class SF_OT_file_pipeline_open_icon_reference(bpy.types.Operator):
    bl_idname = 'import_scene.sfs_file_pipeline_open_icon_reference'
    bl_label = 'Open Icon Reference'
    bl_description = 'Load the generated File Pipeline icon reference sheet into Blender image data. The sheet documents the custom frameless icon set used by the visual action deck.'
    bl_options = {'UNDO', 'INTERNAL'}

    def execute(self, context):
        path = _sfsmart_icon_path('reference_board') or _sfsmart_icon_path('hub')
        if not path or not _os.path.isfile(path):
            self.report({'WARNING'}, _t('Icon reference image was not found.'))
            return {'CANCELLED'}
        try:
            bpy.data.images.load(path, check_existing=True)
            _sfsmart_set_last_report(context, 'Icon reference', {'image': path}, path)
            self.report({'INFO'}, _t('Icon reference image loaded.'))
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc)[:220])
            return {'CANCELLED'}


_SFSMART_CLASSES = (
    SF_OT_file_pipeline_open,
    SF_OT_file_pipeline_run_action,
    SF_OT_file_pipeline_open_report,
    SF_OT_file_pipeline_open_icon_reference,
)


def _sfsmart_lane_sections(context, category: str) -> list[dict]:
    category = str(category or 'OTHER').upper()
    base_items = [
        _sf_lane_tool_entry(_t('File Pipeline'), SF_OT_file_pipeline_open.bl_idname, 'ASSET_MANAGER', _t('Open the cross-DCC file, reference, package, catalog, assembly, cache, shot, version, and pipeline hub.'), keywords='file pipeline dcc reference package catalog'),
    ]
    try:
        base_items[0]['icon_value_key'] = 'hub'
        base_items[0]['frameless_icon'] = True
    except Exception:
        pass
    lane_actions = {
        'LINK': [
            ('PIPELINE_PREFLIGHT', 'Pipeline Preflight', 'VIEWZOOM'),
            ('SMART_RESOLVE_MISSING', 'Resolve Missing', 'FILE_REFRESH'),
            ('SCAN_REFERENCES', 'Reference Inventory', 'VIEWZOOM'),
            ('REPATH_PREVIEW', 'Preview Repath', 'VIEWZOOM'),
            ('REPATH_APPLY', 'Apply Repath', 'CHECKMARK'),
            ('RELOAD_LIBRARIES', 'Reload Libraries', 'FILE_REFRESH'),
            ('DEPENDENCY_GRAPH', 'Dependency Graph', 'NODETREE'),
        ],
        'APPEND': [
            ('MAKE_LOCAL', 'Materialize Links', 'APPEND_BLEND'),
            ('OVERRIDE_SELECTED', 'Make Library Overrides', 'LIBRARY_DATA_OVERRIDE'),
            ('EXPORT_HIERARCHY_AS_LIBRARY', 'Export Selected Hierarchy', 'EXPORT'),
        ],
        'IMPORT': [
            ('CATALOG_INDEX', 'Build Asset Catalog', 'ASSET_MANAGER'),
            ('VERSION_PLAN', 'Version Upgrade Plan', 'SORTTIME'),
            ('ENGINE_MANIFEST', 'Engine Prefab Manifest', 'OUTLINER_OB_GROUP_INSTANCE'),
        ],
        'EXPORT': [
            ('COLLECT_ASSETS', 'Collect Package', 'EXPORT'),
            ('SHOT_MANIFEST', 'Shot Manifest', 'FILE_TEXT'),
            ('USD_MANIFEST', 'USD Layer Manifest', 'FILE_BLEND'),
            ('PUBLISH_CONTAINER', 'Publish Container Manifest', 'ASSET_MANAGER'),
        ],
        'PREVIEW': [
            ('CACHE_SCAN', 'Cache Report', 'FILE'),
            ('COMPARE_DELTA', 'Compare Delta', 'VIEWZOOM'),
            ('NAMING_REPORT', 'Naming Cleanup Report', 'SORTALPHA'),
            ('PROJECT_QUALITY_AUDIT', 'Project Quality Audit', 'CHECKMARK'),
        ],
        'HISTORY': [
            ('CAPTURE_DELTA', 'Capture Delta', 'PRESET'),
            ('RESTORE_DELTA', 'Restore Delta', 'LOOP_BACK'),
            ('CHECKOUT', 'Check Out Lock', 'LOCKED'),
            ('CHECKIN', 'Check In Unlock', 'UNLOCKED'),
        ],
        'OTHER': [
            ('TEXTURE_EXTENSION_SWAP', 'Texture Extension Swap', 'IMAGE_DATA'),
            ('CAMERA_QUEUE', 'Camera Queue', 'RENDER_STILL'),
            ('RELATIVE_PATHS', 'Make Paths Relative', 'FILE_REFRESH'),
        ],
    }
    for action, label, icon in lane_actions.get(category, lane_actions['OTHER']):
        item = _sf_lane_tool_entry(_t(label), SF_OT_file_pipeline_run_action.bl_idname, icon, _t(dict((i[0], i[2]) for i in _SFSMART_ACTION_ITEMS).get(action, label)), props={'action': action}, keywords='file pipeline ' + action.lower())
        item['help_key'] = 'tool'
        item['icon_value_key'] = _sfsmart_action_icon_key(action)
        item['frameless_icon'] = True
        item['operator_id'] = SF_OT_file_pipeline_run_action.bl_idname
        item['help_title'] = label
        base_items.append(item)
    return [{
        'title': _t('File Pipeline'),
        'subtitle': _t('Upper-compatible cross-DCC file-management layer integrated into the Smart File N-panel.'),
        'icon': 'ASSET_MANAGER',
        'icon_value_key': 'hub',
        'help_key': 'tool',
        'lane': category,
        'section': 'File Pipeline',
        'items': base_items,
    }]
