# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""One dispatcher per load/save/exit handler list for Smart File Suite.

Smart File modules register their lifecycle callbacks here instead of adding
each one to ``bpy.app.handlers``.  Each list (load_pre, load_post, save_pre,
save_post, exit_pre) holds exactly one Smart File function, which calls the registered
callbacks in registration order.  The list proxies below offer the small
list API the owners already use (append, remove, iteration, membership).
"""
from __future__ import annotations

try:
    import bpy
    from bpy.app.handlers import persistent as _persistent
except Exception:  # pragma: no cover - static tooling outside Blender.
    bpy = None  # type: ignore[assignment]

    def _persistent(function):
        return function

_LIST_NAMES = ("load_pre", "load_post", "save_pre", "save_post", "exit_pre")
_MARK = "_sf_lifecycle_hub_dispatcher"


_WARNED = set()


def _warn_once(key, exc):
    if key not in _WARNED:
        _WARNED.add(key)
        print(f"[Smart File] {key}: {exc}")


def _call_with_accepted_args(callback, args):
    """Call ``callback`` with the leading arguments its signature accepts.

    Blender passes (filepath, None) to a handler that takes ``*args`` but only
    (filepath) to a one-argument handler.  The dispatcher takes ``*args``, so it
    must give every callback the same count Blender would have given it.
    """
    code = getattr(callback, "__code__", None)
    if code is None or (code.co_flags & 0x04):
        return callback(*args)
    count = code.co_argcount - (1 if getattr(callback, "__self__", None) is not None else 0)
    return callback(*args[:max(count, 0)])


def _make_dispatcher(list_name):
    @_persistent
    def sf_lifecycle_dispatch(*args, **kwargs):
        for callback in tuple(_PROXIES[list_name]._subs):
            try:
                _call_with_accepted_args(callback, args)
            except Exception as exc:
                _warn_once(list_name + ":" + getattr(callback, "__name__", "?"), exc)
    sf_lifecycle_dispatch.__name__ = "sf_lifecycle_dispatch_" + list_name
    setattr(sf_lifecycle_dispatch, _MARK, True)
    return sf_lifecycle_dispatch


class _ListProxy:
    def __init__(self, list_name):
        self._name = list_name
        self._subs = []
        self._dispatcher = _make_dispatcher(list_name)

    def _real(self):
        if bpy is None:
            return None
        return getattr(bpy.app.handlers, self._name, None)

    def _ensure(self):
        real = self._real()
        if real is None:
            return
        for item in tuple(real):
            if getattr(item, _MARK, False) and item is not self._dispatcher:
                real.remove(item)
        count = sum(1 for item in tuple(real) if item is self._dispatcher)
        while count > 1:
            real.remove(self._dispatcher)
            count -= 1
        if count == 0:
            real.append(self._dispatcher)

    def _drop(self):
        real = self._real()
        if real is None:
            return
        while any(item is self._dispatcher for item in tuple(real)):
            real.remove(self._dispatcher)

    def append(self, callback):
        self._subs.append(callback)
        self._ensure()

    def remove(self, callback):
        for index, item in enumerate(self._subs):
            if item is callback:
                del self._subs[index]
                break
        else:
            raise ValueError("callback is not registered")
        if not self._subs:
            self._drop()

    def __iter__(self):
        return iter(tuple(self._subs))

    def __len__(self):
        return len(self._subs)

    def __contains__(self, callback):
        return any(item is callback for item in self._subs)


_PROXIES = {name: _ListProxy(name) for name in _LIST_NAMES}


class _Handlers:
    load_pre = _PROXIES["load_pre"]
    load_post = _PROXIES["load_post"]
    save_pre = _PROXIES["save_pre"]
    save_post = _PROXIES["save_post"]
    exit_pre = _PROXIES["exit_pre"]


handlers = _Handlers()


def shutdown():
    """Drop every callback and dispatcher this generation owns."""
    for proxy in _PROXIES.values():
        del proxy._subs[:]
        try:
            proxy._drop()
        except Exception:
            pass
    return True
