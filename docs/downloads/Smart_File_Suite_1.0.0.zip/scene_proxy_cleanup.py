# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Scene proxy hygiene for Smart File Suite.

This module removes broken proxy remnants that are safe to discard because they
no longer point to an existing runtime source or proxy target.  It deliberately
avoids changing active library links, object display representations, user mesh
objects, or valid proxy relationships.
"""

from __future__ import annotations

import time
import uuid
from typing import Any, Iterable, Mapping

import bpy
from bpy.app.handlers import persistent

_REPORT_KEY = "smart_file_suite_scene_proxy_cleanup_report_v1"
_OWNER_KEY = "JELararagi.smart_file.scene_proxy_cleanup.lifecycle.v57540"
_LEGACY_OWNER_KEYS = (
    "JELararagi.smart_file.scene_proxy_cleanup.lifecycle.v57539",
    "JELararagi.smart_file.scene_proxy_cleanup.lifecycle.v57536",
    "JELararagi.smart_file.scene_proxy_cleanup.lifecycle.v57535",
    "JELararagi.smart_file.scene_proxy_cleanup.lifecycle.v57534",
    "JELararagi.smart_file.scene_proxy_cleanup.lifecycle.v57533",
    "smart_file_suite_scene_proxy_cleanup_timer_v1",
)
_OWNER_TOKEN = object()
_OWNER_GENERATION = uuid.uuid4().hex
_LAST_RUN = 0.0
_RUNNING = False
_REGISTERED = False
_HANDLER_RECORDS: list[dict[str, Any]] = []
_TIMER_CALLBACK = None
_LAST_RUNTIME_ERROR = ""

# Broken proxy custom properties observed in real production .blend files.  They
# are not Smart File runtime state and are removed only when their referenced
# object/source is missing or the owner is an internal generated proxy remnant.
_MS_SHAPE_PROXY_KEYS = {
    "ms_shape_mesh_proxy_link_id",
    "ms_shape_mesh_proxy_source",
    "ms_shape_mesh_proxy_source_id",
    "ms_shape_mesh_proxy_object",
    "ms_shape_mesh_proxy_object_id",
    "ms_shape_proxy_internal",
}

# Smart File-specific old proxy markers are included for forward cleanup.  These
# are data-block custom properties only; WindowManager settings such as
# sf_smart_proxy_mode are not touched.
_SFS_PROXY_KEYS = {
    "smart_file_suite_proxy_internal",
    "smart_file_suite_proxy_source",
    "smart_file_suite_proxy_target",
    "smart_file_suite_proxy_source_id",
    "smart_file_suite_proxy_target_id",
    "sfs_proxy_internal",
    "sfs_proxy_source",
    "sfs_proxy_target",
    "_sfs_proxy_internal",
    "_sfs_proxy_source",
    "_sfs_proxy_target",
}

_SFS_PROXY_PREFIXES = (
    "smart_file_suite_proxy_",
    "sfs_proxy_",
    "_sfs_proxy_",
)



def _bool_prop(value) -> bool:
    try:
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in {"1", "true", "yes", "on"}
    except Exception:
        return False



def _idprop_keys(id_block) -> list[str]:
    try:
        return [str(key) for key in id_block.keys()]
    except Exception:
        return []



def _has_any_prop(id_block, keys: Iterable[str]) -> bool:
    try:
        existing = set(_idprop_keys(id_block))
        return any(key in existing for key in keys)
    except Exception:
        return False



def _delete_props(id_block, keys: Iterable[str]) -> int:
    removed = 0
    for key in list(keys or ()):  # copy, because ID properties change in-place
        try:
            if key in id_block:
                del id_block[key]
                removed += 1
        except Exception:
            pass
    return removed



def _proxy_prop_keys_on(id_block) -> set[str]:
    keys = set()
    for key in _idprop_keys(id_block):
        low = key.lower()
        if key in _MS_SHAPE_PROXY_KEYS or key in _SFS_PROXY_KEYS:
            keys.add(key)
        elif any(low.startswith(prefix) for prefix in _SFS_PROXY_PREFIXES):
            keys.add(key)
    return keys



def _object_exists(name: str) -> bool:
    name = str(name or "").strip()
    if not name:
        return False
    try:
        return bpy.data.objects.get(name) is not None
    except Exception:
        return False



def _node_group_source_missing(node_group) -> bool:
    name = str(getattr(node_group, "name", "") or "")
    if not _bool_prop(getattr(node_group, "get", lambda _k, _d=None: _d)("ms_shape_proxy_internal", False)):
        return False
    # Typical name: "SMS Curve To Mesh - Spiral.010".  If that source object is
    # gone, this converter is an old generated remnant rather than live scene data.
    if " - " in name:
        source_name = name.rsplit(" - ", 1)[-1].strip()
        if source_name and not _object_exists(source_name):
            return True
    return False



def _is_ms_shape_internal_object(ob) -> bool:
    try:
        return _bool_prop(ob.get("ms_shape_proxy_internal", False))
    except Exception:
        return False



def _is_sfs_internal_proxy_object(ob) -> bool:
    try:
        return _bool_prop(ob.get("smart_file_suite_proxy_internal", False)) or _bool_prop(ob.get("sfs_proxy_internal", False)) or _bool_prop(ob.get("_sfs_proxy_internal", False))
    except Exception:
        return False



def _is_internal_proxy_object(ob) -> bool:
    return _is_ms_shape_internal_object(ob) or _is_sfs_internal_proxy_object(ob)



def _ms_shape_internal_object_is_stale(ob, object_names: set[str], referenced_proxy_names: set[str]) -> bool:
    try:
        if not _is_ms_shape_internal_object(ob):
            return False
        name = str(getattr(ob, "name", "") or "")
        source_name = str(ob.get("ms_shape_mesh_proxy_source", "") or "").strip()
        if source_name and source_name not in object_names:
            return True
        if name and name not in referenced_proxy_names and ("_SMS_CurveMesh" in name or str(getattr(getattr(ob, "data", None), "name", "") or "").endswith("_SMS_MeshData")):
            return True
    except Exception:
        return False
    return False



def _sfs_internal_object_is_stale(ob, object_names: set[str]) -> bool:
    try:
        if not _is_sfs_internal_proxy_object(ob):
            return False
        source = str(ob.get("smart_file_suite_proxy_source", "") or ob.get("sfs_proxy_source", "") or ob.get("_sfs_proxy_source", "") or "").strip()
        target = str(ob.get("smart_file_suite_proxy_target", "") or ob.get("sfs_proxy_target", "") or ob.get("_sfs_proxy_target", "") or "").strip()
        return bool((source and source not in object_names) or (target and target not in object_names))
    except Exception:
        return False



def _remove_object_and_orphan_data(ob) -> tuple[int, int]:
    removed_objects = 0
    removed_data = 0
    data = None
    try:
        data = getattr(ob, "data", None)
    except Exception:
        data = None
    try:
        bpy.data.objects.remove(ob, do_unlink=True)
        removed_objects += 1
    except Exception:
        return removed_objects, removed_data
    try:
        if data is not None and getattr(data, "users", 0) == 0:
            # Remove only common generated object data-block types.  This avoids
            # broad orphan purges that could surprise the user.
            for collection_name in ("meshes", "curves", "grease_pencils", "lattices", "metaballs"):
                coll = getattr(bpy.data, collection_name, None)
                if coll is not None and hasattr(coll, "remove"):
                    try:
                        coll.remove(data)
                        removed_data += 1
                        break
                    except Exception:
                        pass
    except Exception:
        pass
    return removed_objects, removed_data



def cleanup_stale_proxy_data(context=None, *, force: bool = False) -> dict:
    """Clean broken proxy remnants from the current .blend data-blocks.

    The scan is intentionally narrow: it deletes only invalid proxy metadata and
    generated internal proxy objects whose source/target is already missing.
    """
    global _LAST_RUN, _RUNNING
    now = time.monotonic()
    if _RUNNING:
        return {"removed_objects": 0, "removed_props": 0, "removed_data": 0, "removed_node_groups": 0, "skipped": "already_running"}
    if not force and now - _LAST_RUN < 8.0:
        return {"removed_objects": 0, "removed_props": 0, "removed_data": 0, "removed_node_groups": 0, "skipped": "throttled"}
    _RUNNING = True
    _LAST_RUN = now
    report = {
        "removed_objects": 0,
        "removed_props": 0,
        "removed_data": 0,
        "removed_node_groups": 0,
        "cleaned_owners": [],
        "removed_object_names": [],
        "removed_node_group_names": [],
    }
    try:
        objects = list(getattr(bpy.data, "objects", []) or [])
        object_names = {str(getattr(ob, "name", "") or "") for ob in objects}
        referenced_proxy_names = set()
        for ob in objects:
            try:
                proxy_name = str(ob.get("ms_shape_mesh_proxy_object", "") or "").strip()
                if proxy_name:
                    referenced_proxy_names.add(proxy_name)
            except Exception:
                pass

        # 1) Remove stale link metadata on normal objects.  The object itself is
        # not deleted because it may be real user scene content.
        for ob in list(objects):
            try:
                if _is_internal_proxy_object(ob):
                    continue
                prop_keys = _proxy_prop_keys_on(ob)
                if not prop_keys:
                    continue
                proxy_name = str(ob.get("ms_shape_mesh_proxy_object", "") or ob.get("smart_file_suite_proxy_target", "") or ob.get("sfs_proxy_target", "") or ob.get("_sfs_proxy_target", "") or "").strip()
                source_name = str(ob.get("ms_shape_mesh_proxy_source", "") or ob.get("smart_file_suite_proxy_source", "") or ob.get("sfs_proxy_source", "") or ob.get("_sfs_proxy_source", "") or "").strip()
                broken = bool((proxy_name and proxy_name not in object_names) or (source_name and source_name not in object_names))
                if broken:
                    removed = _delete_props(ob, prop_keys)
                    if removed:
                        report["removed_props"] += removed
                        report["cleaned_owners"].append(str(getattr(ob, "name", "") or ""))
            except Exception:
                pass

        # 2) Remove generated internal proxy objects whose source/target is gone.
        for ob in list(getattr(bpy.data, "objects", []) or []):
            try:
                name = str(getattr(ob, "name", "") or "")
                stale = _ms_shape_internal_object_is_stale(ob, object_names, referenced_proxy_names) or _sfs_internal_object_is_stale(ob, object_names)
                if not stale:
                    continue
                removed_objects, removed_data = _remove_object_and_orphan_data(ob)
                if removed_objects:
                    report["removed_objects"] += removed_objects
                    report["removed_data"] += removed_data
                    report["removed_object_names"].append(name)
            except Exception:
                pass

        # If generated proxies were removed above, remove any metadata that now
        # points at those deleted proxy targets.  This covers files where the
        # source object survived but an old generated proxy object became invalid.
        if report["removed_objects"]:
            object_names = {str(getattr(ob, "name", "") or "") for ob in list(getattr(bpy.data, "objects", []) or [])}
            for ob in list(getattr(bpy.data, "objects", []) or []):
                try:
                    if _is_internal_proxy_object(ob):
                        continue
                    prop_keys = _proxy_prop_keys_on(ob)
                    if not prop_keys:
                        continue
                    proxy_name = str(ob.get("ms_shape_mesh_proxy_object", "") or ob.get("smart_file_suite_proxy_target", "") or ob.get("sfs_proxy_target", "") or ob.get("_sfs_proxy_target", "") or "").strip()
                    source_name = str(ob.get("ms_shape_mesh_proxy_source", "") or ob.get("smart_file_suite_proxy_source", "") or ob.get("sfs_proxy_source", "") or ob.get("_sfs_proxy_source", "") or "").strip()
                    broken = bool((proxy_name and proxy_name not in object_names) or (source_name and source_name not in object_names))
                    if broken:
                        removed = _delete_props(ob, prop_keys)
                        if removed:
                            report["removed_props"] += removed
                            report["cleaned_owners"].append(str(getattr(ob, "name", "") or ""))
                except Exception:
                    pass

        # 3) Remove orphan generated node groups after proxy object removal.
        for ng in list(getattr(bpy.data, "node_groups", []) or []):
            try:
                if not _node_group_source_missing(ng):
                    continue
                # Be conservative: remove only if nothing else uses it after the
                # stale proxy object cleanup above.
                if int(getattr(ng, "users", 0) or 0) > 0:
                    continue
                name = str(getattr(ng, "name", "") or "")
                bpy.data.node_groups.remove(ng)
                report["removed_node_groups"] += 1
                report["removed_node_group_names"].append(name)
            except Exception:
                pass

        # 4) Remove dangling proxy props from node groups and generated meshes
        # whose sources are missing, without touching unrelated user data.
        for coll_name in ("node_groups", "meshes", "curves", "collections"):
            coll = getattr(bpy.data, coll_name, None)
            if coll is None:
                continue
            for item in list(coll or []):
                try:
                    prop_keys = _proxy_prop_keys_on(item)
                    if not prop_keys:
                        continue
                    source_name = str(item.get("ms_shape_mesh_proxy_source", "") or item.get("smart_file_suite_proxy_source", "") or item.get("sfs_proxy_source", "") or item.get("_sfs_proxy_source", "") or "").strip()
                    target_name = str(item.get("smart_file_suite_proxy_target", "") or item.get("sfs_proxy_target", "") or item.get("_sfs_proxy_target", "") or "").strip()
                    if (source_name and source_name not in object_names) or (target_name and target_name not in object_names):
                        removed = _delete_props(item, prop_keys)
                        if removed:
                            report["removed_props"] += removed
                            report["cleaned_owners"].append(f"{coll_name}:{getattr(item, 'name', '')}")
                except Exception:
                    pass

        # Diagnostic name lists are bounded independently from the scene size.
        for _key in ("cleaned_owners", "removed_object_names", "removed_node_group_names"):
            try:
                report[_key] = list(report.get(_key, ())[:2048])
            except Exception:
                report[_key] = []
        try:
            bpy.app.driver_namespace[_REPORT_KEY] = dict(report)
        except Exception:
            pass
        return report
    finally:
        _RUNNING = False



def _namespace() -> dict | None:
    try:
        value = getattr(getattr(bpy, "app", None), "driver_namespace", None)
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _ledger() -> dict | None:
    namespace = _namespace()
    value = namespace.get(_OWNER_KEY) if namespace is not None else None
    return value if isinstance(value, dict) else None


def _is_current_generation() -> bool:
    owner = _ledger()
    return bool(
        owner
        and owner.get("token") is _OWNER_TOKEN
        and owner.get("generation") == _OWNER_GENERATION
    )


def _timer_is_registered(callback=None) -> bool:
    callback = callback if callback is not None else _TIMER_CALLBACK
    if callback is None:
        return False
    try:
        checker = getattr(bpy.app.timers, "is_registered", None)
        return bool(checker(callback)) if callable(checker) else True
    except Exception:
        return False


def _remove_exact_handler(record: Mapping[str, Any]) -> bool:
    collection = record.get("collection")
    callback = record.get("callback")
    if record.get("token") is not _OWNER_TOKEN or record.get("generation") != _OWNER_GENERATION:
        return False
    try:
        for index in reversed([i for i, value in enumerate(tuple(collection or ())) if value is callback]):
            collection.pop(index)
        return not any(value is callback for value in tuple(collection or ()))
    except Exception:
        return False


def _cancel_timer() -> bool:
    global _TIMER_CALLBACK
    callback = _TIMER_CALLBACK
    ok = True
    if callback is not None:
        try:
            if _timer_is_registered(callback):
                bpy.app.timers.unregister(callback)
        except Exception:
            ok = not _timer_is_registered(callback)
    _TIMER_CALLBACK = None
    owner = _ledger()
    if isinstance(owner, dict):
        owner["timer"] = None
    return ok


def _cleanup_generation(token=None, generation=None) -> bool:
    global _REGISTERED, _HANDLER_RECORDS
    if token is not None and token is not _OWNER_TOKEN:
        return True
    if generation is not None and str(generation) != _OWNER_GENERATION:
        return True
    ok = _cancel_timer()
    for record in reversed(tuple(_HANDLER_RECORDS)):
        if not _remove_exact_handler(record):
            ok = False
    _HANDLER_RECORDS = []
    _REGISTERED = False
    return ok


def _cleanup_external_owner(owner: Mapping[str, Any]) -> bool:
    cleanup = owner.get("cleanup") if isinstance(owner, Mapping) else None
    if not callable(cleanup):
        # Legacy scalar callback keys are removed without touching the callback;
        # only ledgers with an exact native remover are considered cleanable.
        return not isinstance(owner, Mapping)
    try:
        try:
            return bool(cleanup(owner.get("token"), owner.get("generation")))
        except TypeError:
            return bool(cleanup())
    except Exception:
        return False


def _install_owner() -> bool:
    namespace = _namespace()
    if namespace is None:
        return False
    for key in _LEGACY_OWNER_KEYS:
        legacy = namespace.get(key)
        if isinstance(legacy, Mapping):
            if not _cleanup_external_owner(legacy):
                return False
        elif callable(legacy):
            # Legacy builds stored the exact package-owned callback directly.
            # The package-specific namespace key is its ownership proof.
            try:
                checker = getattr(bpy.app.timers, "is_registered", None)
                if not callable(checker) or checker(legacy):
                    bpy.app.timers.unregister(legacy)
            except Exception:
                try:
                    if callable(checker) and checker(legacy):
                        return False
                except Exception:
                    return False
        namespace.pop(key, None)
    current = namespace.get(_OWNER_KEY)
    if isinstance(current, Mapping) and not (
        current.get("token") is _OWNER_TOKEN
        and current.get("generation") == _OWNER_GENERATION
    ):
        if not _cleanup_external_owner(current):
            return False
    namespace[_OWNER_KEY] = {
        "schema": 1,
        "token": _OWNER_TOKEN,
        "generation": _OWNER_GENERATION,
        "handlers": _HANDLER_RECORDS,
        "timer": None,
        "cleanup": _cleanup_generation,
    }
    return True


@persistent
def _sfs_proxy_cleanup_load_post(_dummy):
    if not _is_current_generation():
        return
    try:
        cleanup_stale_proxy_data(getattr(bpy, "context", None), force=True)
    except Exception:
        return


@persistent
def _sfs_proxy_cleanup_save_pre(_dummy):
    if not _is_current_generation():
        return
    try:
        cleanup_stale_proxy_data(getattr(bpy, "context", None), force=True)
    except Exception:
        return


def _timer_cleanup():
    """Compatibility one-shot callback; never becomes a periodic poll."""
    global _TIMER_CALLBACK
    callback = _TIMER_CALLBACK
    if not _is_current_generation():
        return None
    owner = _ledger()
    timer = owner.get("timer") if isinstance(owner, dict) else None
    if not (
        isinstance(timer, Mapping)
        and timer.get("callback") is callback
        and timer.get("token") is _OWNER_TOKEN
        and timer.get("generation") == _OWNER_GENERATION
    ):
        return None
    _TIMER_CALLBACK = None
    owner["timer"] = None
    try:
        cleanup_stale_proxy_data(getattr(bpy, "context", None), force=True)
    except Exception:
        pass
    return None


def _append_exact_handler(collection, callback, role: str) -> bool:
    global _HANDLER_RECORDS
    if any(value is callback for value in tuple(collection or ())):
        if not any(record.get("callback") is callback for record in _HANDLER_RECORDS):
            _HANDLER_RECORDS.append({
                "collection": collection, "callback": callback, "role": role,
                "token": _OWNER_TOKEN, "generation": _OWNER_GENERATION,
                "acquired": False,
                "remover": lambda rec_collection=collection, rec_callback=callback: _remove_exact_handler({
                    "collection": rec_collection, "callback": rec_callback,
                    "token": _OWNER_TOKEN, "generation": _OWNER_GENERATION,
                }),
            })
        return True
    collection.append(callback)
    if not any(value is callback for value in tuple(collection or ())):
        return False
    _HANDLER_RECORDS.append({
        "collection": collection, "callback": callback, "role": role,
        "token": _OWNER_TOKEN, "generation": _OWNER_GENERATION,
        "acquired": True,
        "remover": lambda rec_collection=collection, rec_callback=callback: _remove_exact_handler({
            "collection": rec_collection, "callback": rec_callback,
            "token": _OWNER_TOKEN, "generation": _OWNER_GENERATION,
        }),
    })
    return True


def _schedule_one_shot() -> bool:
    global _TIMER_CALLBACK
    _cancel_timer()
    token = _OWNER_TOKEN
    generation = _OWNER_GENERATION

    def callback():
        if token is not _OWNER_TOKEN or generation != _OWNER_GENERATION:
            return None
        return _timer_cleanup()

    _TIMER_CALLBACK = callback
    owner = _ledger()
    if isinstance(owner, dict):
        owner["timer"] = {
            "callback": callback, "token": token, "generation": generation,
            "one_shot": True,
            "remover": _cancel_timer,
        }
    try:
        bpy.app.timers.register(callback, first_interval=2.0, persistent=False)
        if not _timer_is_registered(callback):
            raise RuntimeError("proxy cleanup one-shot timer was not retained")
        return True
    except Exception:
        _cancel_timer()
        return False


def sync(enabled: bool, context=None) -> bool:
    global _REGISTERED, _LAST_RUNTIME_ERROR
    _LAST_RUNTIME_ERROR = ""
    unregister()
    if not bool(enabled):
        return True
    if not _install_owner():
        _LAST_RUNTIME_ERROR = "proxy cleanup owner ledger unavailable"
        return False
    try:
        if not _append_exact_handler(bpy.app.handlers.load_post, _sfs_proxy_cleanup_load_post, "load_post"):
            raise RuntimeError("proxy cleanup load_post handler registration failed")
        if not _append_exact_handler(bpy.app.handlers.save_pre, _sfs_proxy_cleanup_save_pre, "save_pre"):
            raise RuntimeError("proxy cleanup save_pre handler registration failed")
        owner = _ledger()
        if isinstance(owner, dict):
            owner["handlers"] = tuple(_HANDLER_RECORDS)
        if not _schedule_one_shot():
            raise RuntimeError("proxy cleanup one-shot scheduling failed")
        _REGISTERED = True
        return True
    except Exception as exc:
        _LAST_RUNTIME_ERROR = f"{type(exc).__name__}: {exc}"
        _cleanup_generation()
        return False


def register(context=None) -> bool:
    """Restore the explicit default-False Always-on preference."""
    ctx = context or getattr(bpy, "context", None)
    enabled = False
    try:
        wm = getattr(ctx, "window_manager", None)
        prefs = getattr(wm, "sf_addon_settings", None) if wm is not None else None
        enabled = bool(getattr(prefs, "enable_automatic_proxy_cleanup", False))
    except Exception:
        enabled = False
    return sync(enabled, ctx)


def unregister() -> bool:
    global _REGISTERED
    ok = _cleanup_generation()
    namespace = _namespace()
    if namespace is not None:
        owner = namespace.get(_OWNER_KEY)
        if isinstance(owner, dict) and owner.get("token") is _OWNER_TOKEN:
            namespace.pop(_OWNER_KEY, None)
    _REGISTERED = False
    return ok


def runtime_status() -> dict[str, Any]:
    owner = _ledger()
    handler_exact = bool(
        len(_HANDLER_RECORDS) == 2
        and all(
            record.get("token") is _OWNER_TOKEN
            and record.get("generation") == _OWNER_GENERATION
            and sum(1 for value in tuple(record.get("collection") or ()) if value is record.get("callback")) == 1
            for record in _HANDLER_RECORDS
        )
    ) if _REGISTERED else not _HANDLER_RECORDS
    timer_exact = bool(
        _TIMER_CALLBACK is None or (
            _timer_is_registered(_TIMER_CALLBACK)
            and isinstance((owner or {}).get("timer"), Mapping)
            and owner["timer"].get("callback") is _TIMER_CALLBACK
        )
    )
    return {
        "registered": bool(_REGISTERED and _is_current_generation() and handler_exact and timer_exact),
        "enabled": bool(_REGISTERED),
        "generation": _OWNER_GENERATION,
        "handler_count": len(_HANDLER_RECORDS),
        "timer_count": 1 if _timer_is_registered(_TIMER_CALLBACK) else 0,
        "timer_one_shot": True,
        "worker_count": 0,
        "file_poll_count": 0,
        "last_runtime_error": _LAST_RUNTIME_ERROR,
    }
