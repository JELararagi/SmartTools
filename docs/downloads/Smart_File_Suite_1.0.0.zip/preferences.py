# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Legacy registration interface. Settings now belong to the sidebar."""


def register():
    pass


unregister = register
