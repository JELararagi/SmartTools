# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

# Retired compatibility preferences module.
# Smart File settings are drawn and managed from the standard Smart File N-panel.


def register() -> None:
    return None


def unregister() -> None:
    return None
