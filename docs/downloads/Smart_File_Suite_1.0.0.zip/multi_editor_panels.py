# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Generation-owned multi-editor N-panel proxies for Smart File.

The canonical full-body Smart File panel is registered once by the core.  This
module registers editor-specific proxy roots that forward to that exact
package class.  Blender Extension classes are not required to be published as
``bpy.types.<PythonName>``; class-owned RNA and package-namespace identity are
used throughout.
"""

from __future__ import annotations

import sys
import uuid
from typing import Any

import bpy


_TARGETS: tuple[tuple[str, str], ...] = (
    ("IMAGE_EDITOR", "SFS_PT_file_image"),
    ("NODE_EDITOR", "SFS_PT_file_node"),
    ("SEQUENCE_EDITOR", "SFS_PT_file_sequence"),
    ("CLIP_EDITOR", "SFS_PT_file_clip"),
    ("DOPESHEET_EDITOR", "SFS_PT_file_dopesheet"),
    ("GRAPH_EDITOR", "SFS_PT_file_graph"),
    ("NLA_EDITOR", "SFS_PT_file_nla"),
    ("TEXT_EDITOR", "SFS_PT_file_text"),
    ("FILE_BROWSER", "SFS_PT_file_browser"),
    ("SPREADSHEET", "SFS_PT_file_spreadsheet"),
)

_ASSET_PANEL_ID = "FILEBROWSER_PT_sfs_asset_root"

_SOURCE_PANEL_IDS: tuple[str, ...] = (
    "SF_PT_reference_manager_reference_manager_workspace",
    "SMARTFILESUITE_PT_system_file_suite_2",
    "SMARTFILESUITE_PT_system_file_suite",
)
_CHILD_SOURCE_PANEL_ID = "SMART_FILE_PT_system_file_suite_always_on_toggle"

_LOGICAL_EDITORS_BY_SPACE: dict[str, tuple[str, ...]] = {
    "VIEW_3D": ("VIEW_3D",),
    "IMAGE_EDITOR": ("IMAGE_EDITOR", "UV_EDITOR"),
    "NODE_EDITOR": ("SHADER_EDITOR", "COMPOSITOR", "GEOMETRY_NODE_EDITOR", "TEXTURE_NODE_EDITOR"),
    "SEQUENCE_EDITOR": ("VIDEO_SEQUENCER",),
    "CLIP_EDITOR": ("MOVIE_CLIP_EDITOR",),
    "DOPESHEET_EDITOR": ("DOPE_SHEET",),
    "GRAPH_EDITOR": ("GRAPH_EDITOR", "DRIVERS"),
    "NLA_EDITOR": ("NLA_EDITOR",),
    "TEXT_EDITOR": ("TEXT_EDITOR",),
    "FILE_BROWSER": ("ASSET_BROWSER", "FILE_BROWSER"),
    "SPREADSHEET": ("SPREADSHEET",),
}
_MANAGER_TOOL_KEY = "SMART_FILE"
_MANAGER_RUNTIME_NAMESPACE_KEY = "JELARARAGI_SMART_TOOLS_MANAGER_RUNTIME_API_V1"
_MANAGER_PARENT_PACKAGE = str(__package__ or "").strip().rpartition(".")[0]
_MANAGER_MODULE_NAMES: tuple[str, ...] = tuple(dict.fromkeys(tuple(
    name for name in (
        f"{_MANAGER_PARENT_PACKAGE}.smart_tools_manager.manager" if _MANAGER_PARENT_PACKAGE else "",
        f"{_MANAGER_PARENT_PACKAGE}.smart_tools_manager" if _MANAGER_PARENT_PACKAGE else "",
        "bl_ext.user_default.smart_tools_manager.manager",
        "bl_ext.user_default.smart_tools_manager",
        "smart_tools_manager.manager",
        "smart_tools_manager",
    ) if name
)))

_OWNER_KEY = "JELararagi.smart_file.multi_editor_panels.v57540"
_LEGACY_OWNER_KEYS = (
    "JELararagi.smart_file.multi_editor_panels.v57539",
    "JELararagi.smart_file.multi_editor_panels.v57538",
    "JELararagi.smart_file.multi_editor_panels.v57536",
    "JELararagi.smart_file.multi_editor_panels.v57535",
    "JELararagi.smart_file.multi_editor_panels.v57534",
    "JELararagi.smart_file.multi_editor_panels.v57533",
    "JELararagi.smart_file.multi_editor_panels.v57532",
    "JELararagi.smart_file.multi_editor_panels.v57531",
)
_OWNER_TOKEN = object()
_GENERATION = uuid.uuid4().hex
_REGISTERED_CLONES: list[type] = []
_REGISTERED_CHILD_CLONES: list[type] = []
_CLONE_BY_SPACE: dict[str, type] = {}
_CHILD_CLONE_BY_SPACE: dict[str, type] = {}
_SOURCE_CLASS: type | None = None
_CHILD_SOURCE_CLASS: type | None = None
_LAST_ERROR = ""
_DEGRADED = False
_MANAGER_RULE_CACHE: dict[str, Any] = {
    "generation": "",
    "revision": -1,
    "active": False,
    "decisions": {},
}
_MANAGER_WORKSPACE_ALIASES: dict[str, tuple[str, ...]] = {
    "LAYOUT": ("Layout", "\u30ec\u30a4\u30a2\u30a6\u30c8"),
    "MODELING": ("Modeling", "\u30e2\u30c7\u30ea\u30f3\u30b0"),
    "SCULPTING": ("Sculpting", "\u30b9\u30ab\u30eb\u30d7\u30c8"),
    "UV_EDITING": ("UV Editing", "UV\u30a8\u30c7\u30a3\u30c6\u30a3\u30f3\u30b0", "UV\u7de8\u96c6"),
    "TEXTURE_PAINT": ("Texture Paint", "\u30c6\u30af\u30b9\u30c1\u30e3\u30da\u30a4\u30f3\u30c8"),
    "SHADING": ("Shading", "\u30b7\u30a7\u30fc\u30c7\u30a3\u30f3\u30b0"),
    "ANIMATION": ("Animation", "\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3"),
    "RENDERING": ("Rendering", "\u30ec\u30f3\u30c0\u30ea\u30f3\u30b0"),
    "COMPOSITING": ("Compositing", "\u30b3\u30f3\u30dd\u30b8\u30c6\u30a3\u30f3\u30b0"),
    "GEOMETRY_NODES": ("Geometry Nodes", "Geometry Node", "\u30b8\u30aa\u30e1\u30c8\u30ea\u30ce\u30fc\u30c9"),
    "SCRIPTING": ("Scripting", "\u30b9\u30af\u30ea\u30d7\u30c6\u30a3\u30f3\u30b0", "\u30b9\u30af\u30ea\u30d7\u30c8\u4f5c\u6210"),
    "ANIMATION_2D": ("2D Animation", "2D\u30a2\u30cb\u30e1\u30fc\u30b7\u30e7\u30f3"),
    "FULL_CANVAS_2D": ("2D Full Canvas", "2D\u30d5\u30eb\u30ad\u30e3\u30f3\u30d0\u30b9"),
    "MASKING": ("Masking", "\u30de\u30b9\u30ad\u30f3\u30b0"),
    "MOTION_TRACKING": ("Motion Tracking", "\u30e2\u30fc\u30b7\u30e7\u30f3\u30c8\u30e9\u30c3\u30ad\u30f3\u30b0"),
    "VIDEO_EDITING": ("Video Editing", "\u30d3\u30c7\u30aa\u7de8\u96c6"),
}


def _manager_normalize_name(value: Any) -> str:
    try:
        return "".join(ch for ch in str(value or "").casefold() if ch.isalnum())
    except Exception:
        return ""


_MANAGER_WORKSPACE_BY_NAME = {
    _manager_normalize_name(alias): workspace_key
    for workspace_key, aliases in _MANAGER_WORKSPACE_ALIASES.items()
    for alias in (workspace_key, *aliases)
    if _manager_normalize_name(alias)
}


class _ContextAreaNoneProxy:
    __slots__ = ("_context",)

    def __init__(self, context):
        self._context = context

    @property
    def area(self):
        return None

    def __getattr__(self, name):
        return getattr(self._context, name)


def _namespace() -> dict | None:
    try:
        value = getattr(getattr(bpy, "app", None), "driver_namespace", None)
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _ledger() -> dict | None:
    namespace = _namespace()
    value = namespace.get(_OWNER_KEY) if namespace is not None else None
    return value if isinstance(value, dict) else None


def _class_owns_rna(cls) -> bool:
    try:
        if not isinstance(cls, type):
            return False
        rna = vars(cls).get("bl_rna")
        return bool(rna is not None and str(getattr(rna, "identifier", "") or "").strip())
    except Exception:
        return False


def _package_root_module():
    package = str(__package__ or "").strip()
    return sys.modules.get(package)


def _package_common_module():
    package = str(__package__ or "").strip()
    module_name = f"{package}.common" if package else "common"
    return sys.modules.get(module_name)


def _active_space(context):
    try:
        area = getattr(context, "area", None)
        spaces = getattr(area, "spaces", None)
        return getattr(spaces, "active", None)
    except Exception:
        return None


def _logical_editor_key(context, target_space: str) -> str:
    area = getattr(context, "area", None) if context is not None else None
    space = _active_space(context)
    area_ui = str(getattr(area, "ui_type", "") or "").strip().upper()
    mode = str(getattr(space, "mode", "") or getattr(space, "ui_mode", "") or "").strip().upper()
    tree_type = str(getattr(space, "tree_type", "") or area_ui).strip().upper()
    browse_mode = str(
        getattr(space, "browse_mode", "")
        or getattr(getattr(space, "params", None), "browse_mode", "")
        or mode
    ).strip().upper()
    if target_space == "IMAGE_EDITOR":
        return "UV_EDITOR" if mode in {"UV", "UV_EDIT", "UVS", "UV_EDITOR"} or area_ui in {"UV", "UV_EDIT", "UVS", "UV_EDITOR"} else "IMAGE_EDITOR"
    if target_space == "NODE_EDITOR":
        if tree_type in {"COMPOSITORNODETREE", "COMPOSITOR", "COMPOSITOR_NODE_TREE"}:
            return "COMPOSITOR"
        if tree_type in {"GEOMETRYNODETREE", "GEOMETRY", "GEOMETRY_NODE_TREE"}:
            return "GEOMETRY_NODE_EDITOR"
        if tree_type in {"TEXTURENODETREE", "TEXTURE", "TEXTURE_NODE_TREE"}:
            return "TEXTURE_NODE_EDITOR"
        return "SHADER_EDITOR"
    if target_space == "GRAPH_EDITOR":
        return "DRIVERS" if mode in {"DRIVERS", "DRIVER"} or area_ui in {"DRIVERS", "DRIVER"} else "GRAPH_EDITOR"
    if target_space == "FILE_BROWSER":
        return "ASSET_BROWSER" if browse_mode in {"ASSETS", "ASSET_BROWSER"} or area_ui in {"ASSETS", "ASSET_BROWSER"} else "FILE_BROWSER"
    logical = _LOGICAL_EDITORS_BY_SPACE.get(target_space, ())
    return logical[0] if logical else str(target_space or "")


def _manager_placement_result(value) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return True
    if isinstance(value, dict):
        phase = str(value.get("phase") or value.get("state") or value.get("status") or "").strip().upper()
        if phase in {"", "NOT_READY", "DISABLED", "UNREGISTERED", "INACTIVE"}:
            return True
        if phase == "READY":
            return bool(value.get("allowed", value.get("value", True)))
        if "allowed" in value:
            return bool(value.get("allowed"))
        return True
    if isinstance(value, (tuple, list)) and len(value) >= 2:
        phase = str(value[0] or "").strip().upper()
        if phase in {"NOT_READY", "DISABLED", "UNREGISTERED", "INACTIVE"}:
            return True
        if phase == "READY":
            return bool(value[1])
    if isinstance(value, str):
        phase = value.strip().upper()
        if phase in {"", "NOT_READY", "DISABLED", "UNREGISTERED", "INACTIVE"}:
            return True
        if phase in {"ALLOW", "ALLOWED", "ON", "TRUE"}:
            return True
        if phase in {"DENY", "DENIED", "OFF", "FALSE"}:
            return False
    return bool(value)


def _manager_module_explicitly_unready(module) -> bool:
    """Read only explicit Manager lifecycle fields; absence is fail-open."""
    if module is None:
        return True
    values = vars(module)
    for name in ("__addon_enabled__", "_manager_registered"):
        if name in values and not bool(values.get(name)):
            return True
    for name in (
        "PLACEMENT_API_STATE", "placement_api_state", "_placement_api_state",
        "PLACEMENT_PHASE", "placement_phase", "_placement_phase",
    ):
        if name not in values:
            continue
        phase = str(values.get(name) or "").strip().upper()
        if phase in {"", "NOT_READY", "DISABLED", "UNREGISTERED", "INACTIVE", "ERROR"}:
            return True
    return False


def _manager_runtime_record() -> dict[str, Any] | None:
    """Return the generation-bound Manager record without importing anything."""
    namespace = _namespace()
    record = namespace.get(_MANAGER_RUNTIME_NAMESPACE_KEY) if namespace is not None else None
    if not isinstance(record, dict):
        return None
    if record.get("package_id") != "smart_tools_manager" or record.get("status") != "ACTIVE":
        return None
    generation = record.get("generation")
    revision = record.get("revision")
    if not isinstance(generation, str) or not generation:
        return None
    if type(revision) is not int or revision < 0:
        return None
    if not isinstance(record.get("public_api"), dict):
        return None
    return record


def _manager_snapshot_ready(snapshot) -> bool:
    if not isinstance(snapshot, dict):
        return False
    status = str(getattr(snapshot, "status", "") or "").strip().upper()
    ready = getattr(snapshot, "ready", None)
    authoritative = getattr(snapshot, "authoritative", None)
    if status and status != "READY":
        return False
    if ready is False or authoritative is False:
        return False
    return bool(status == "READY" or ready is True)


def _refresh_manager_rule_cache(record: dict[str, Any]) -> None:
    generation = str(record.get("generation") or "")
    revision = int(record.get("revision") or 0)
    decisions: dict[tuple[str, str], bool] = {}
    snapshot_fn = record.get("public_api", {}).get("get_rule_matrix_snapshot")
    snapshot = None
    if callable(snapshot_fn):
        try:
            snapshot = snapshot_fn()
        except Exception:
            snapshot = None
    ready = _manager_snapshot_ready(snapshot)
    if ready:
        workspace_rows = tuple(snapshot.items())
        for workspace_key, editor_rows in workspace_rows:
            if not isinstance(editor_rows, dict):
                continue
            for editor_key, tool_rows in tuple(editor_rows.items()):
                if not isinstance(tool_rows, dict):
                    continue
                value = tool_rows.get(_MANAGER_TOOL_KEY)
                if isinstance(value, bool):
                    decisions[(str(workspace_key), str(editor_key).upper())] = value
    _MANAGER_RULE_CACHE.update({
        "generation": generation,
        "revision": revision,
        "active": bool(ready),
        "decisions": decisions,
    })


def _manager_workspace_key(context) -> str:
    """Resolve Blender's localized workspace name to a Manager matrix key."""
    decisions = _MANAGER_RULE_CACHE.get("decisions")
    if not isinstance(decisions, dict):
        return ""
    available = {key[0] for key in decisions if isinstance(key, tuple) and len(key) == 2}
    for source in (
        getattr(context, "workspace", None),
        getattr(getattr(context, "window", None), "workspace", None),
    ):
        normalized = _manager_normalize_name(getattr(source, "name", ""))
        candidate = _MANAGER_WORKSPACE_BY_NAME.get(normalized)
        if candidate in available:
            return str(candidate)
    return ""


def manager_allows_context(context, editor_key: str | None = None) -> bool:
    """Read a revision cache; ordinary redraws never call Manager placement APIs."""
    exact_editor_key = str(editor_key or "").strip().upper()
    record = _manager_runtime_record()
    if record is None:
        _MANAGER_RULE_CACHE.update({
            "generation": "", "revision": -1, "active": False, "decisions": {},
        })
        return True
    generation = str(record.get("generation") or "")
    revision = int(record.get("revision") or 0)
    if (
        _MANAGER_RULE_CACHE.get("generation") != generation
        or _MANAGER_RULE_CACHE.get("revision") != revision
    ):
        _refresh_manager_rule_cache(record)
    if not _MANAGER_RULE_CACHE.get("active"):
        return True
    workspace_key = _manager_workspace_key(context)
    value = _MANAGER_RULE_CACHE.get("decisions", {}).get((workspace_key, exact_editor_key))
    return value if isinstance(value, bool) else True


def _package_class(identifier: str):
    root = _package_root_module()
    candidate = getattr(root, str(identifier), None) if root is not None else None
    return candidate if isinstance(candidate, type) else None


def _resolve_source_panel():
    for identifier in _SOURCE_PANEL_IDS:
        source = _package_class(identifier)
        if not _class_owns_rna(source):
            continue
        try:
            if str(getattr(source, "bl_space_type", "") or "") != "VIEW_3D":
                continue
            if str(getattr(source, "bl_region_type", "") or "") != "UI":
                continue
            if str(getattr(source, "bl_category", "") or "") != "Smart File":
                continue
            if not callable(getattr(source, "draw", None)):
                continue
        except Exception:
            continue
        return source
    return None


def _resolve_child_source_panel():
    module = _package_common_module()
    source = getattr(module, _CHILD_SOURCE_PANEL_ID, None) if module is not None else None
    if not _class_owns_rna(source):
        return None
    try:
        if str(getattr(source, "bl_space_type", "") or "") != "VIEW_3D":
            return None
        if str(getattr(source, "bl_region_type", "") or "") != "UI":
            return None
        if str(getattr(source, "bl_category", "") or "") != "Smart File":
            return None
        if not callable(getattr(source, "draw", None)):
            return None
    except Exception:
        return None
    return source


def _source_poll_allows(source_cls, context) -> bool:
    poll = getattr(source_cls, "poll", None)
    if poll is None:
        return True
    try:
        if bool(poll(context)):
            return True
    except Exception:
        pass
    try:
        return bool(poll(_ContextAreaNoneProxy(context)))
    except Exception:
        return False


def _copy_attr(attrs: dict[str, Any], source_cls, name: str) -> None:
    try:
        if hasattr(source_cls, name):
            attrs[name] = getattr(source_cls, name)
    except Exception:
        pass


def _make_clone(source_cls, target_space: str, class_id: str, *, asset_browser: bool = False) -> type:
    if len(class_id.encode("utf-8")) > 63:
        raise ValueError(f"Panel id exceeds Blender RNA limit: {class_id}")
    # Capture the canonical callables once while registering.  Blender Extension
    # classes are not guaranteed to appear in bpy.types and a first redraw can
    # occur while runtime class lookup is transiently unavailable.  The closure
    # keeps only Python callables/classes owned by this package, never RNA data.
    source_draw = vars(source_cls).get("draw") if isinstance(source_cls, type) else None
    source_draw_header = vars(source_cls).get("draw_header") if isinstance(source_cls, type) else None
    source_draw_header_preset = getattr(source_cls, "draw_header_preset", None)
    if not callable(source_draw):
        source_draw = getattr(source_cls, "draw", None)
    if not callable(source_draw):
        raise RuntimeError("canonical Smart File panel has no full-body draw callable")
    attrs: dict[str, Any] = {
        "__module__": __name__,
        "_sfs_multi_editor_proxy": True,
        "_sfs_multi_editor_source_cls": source_cls,
        "bl_idname": class_id,
        "bl_label": str(getattr(source_cls, "bl_label", "Smart File") or "Smart File"),
        "bl_space_type": target_space,
        "bl_region_type": "TOOL_PROPS" if asset_browser else "UI",
        "bl_category": "Smart File",
        "_smart_tools_manager_tool_key": _MANAGER_TOOL_KEY,
        "_smart_tools_manager_editor_key": "",
        "_smart_tools_manager_native_npanel_root": True,
        "_smart_tools_manager_disable_proxy": True,
        "_smart_tools_manager_no_cross_editor_proxy": True,
        "_smart_tools_manager_no_active_object_required": True,
        "_smart_tools_manager_cross_editor_safe": True,
    }
    for name in (
        "bl_description",
        "bl_order",
        "bl_options",
        "bl_ui_units_x",
        "bl_translation_context",
        "_sfs_standard_npanel_anchor",
    ):
        _copy_attr(attrs, source_cls, name)

    @classmethod
    def poll(cls, context):
        area = getattr(context, "area", None) if context is not None else None
        if area is not None and str(getattr(area, "type", "") or "") != target_space:
            return False
        editor_key = _logical_editor_key(context, target_space)
        if (editor_key == "ASSET_BROWSER") != asset_browser:
            return False
        return bool(manager_allows_context(context, editor_key))

    def draw(self, context):
        # Full body on the first Blender draw.  Never return the helper's
        # bool/status value to Blender; every Panel.draw boundary returns None.
        try:
            source_draw(self, context)
        except Exception:
            # The canonical panel owns its own crash guard.  This outer guard is
            # limited to the proxy boundary so a transient editor context cannot
            # abort Blender's redraw loop.
            pass
        return None

    def draw_header(self, context):
        if callable(source_draw_header):
            try:
                source_draw_header(self, context)
            except Exception:
                pass
        return None

    def draw_header_preset(self, context):
        if callable(source_draw_header_preset):
            source_draw_header_preset(self, context)
        else:
            op = self.layout.operator('smart_file_suite.open_help', text='', icon='QUESTION')

    attrs["poll"] = poll
    attrs["draw"] = draw
    attrs["draw_header_preset"] = draw_header_preset
    if callable(source_draw_header):
        attrs["draw_header"] = draw_header
    return type(class_id, (bpy.types.Panel,), attrs)


def _make_child_clone(source_cls, target_space: str, class_id: str, parent_id: str) -> type:
    if len(class_id.encode("utf-8")) > 63:
        raise ValueError(f"Panel id exceeds Blender RNA limit: {class_id}")
    source_draw = vars(source_cls).get("draw") if isinstance(source_cls, type) else None
    source_draw_header = vars(source_cls).get("draw_header") if isinstance(source_cls, type) else None
    source_draw_header_preset = getattr(source_cls, "draw_header_preset", None)
    if not callable(source_draw):
        source_draw = getattr(source_cls, "draw", None)
    if not callable(source_draw):
        raise RuntimeError("native Smart File child panel has no draw callable")
    attrs: dict[str, Any] = {
        "__module__": __name__,
        "_sfs_multi_editor_child_proxy": True,
        "_sfs_multi_editor_source_cls": source_cls,
        "bl_idname": class_id,
        "bl_label": str(getattr(source_cls, "bl_label", "Always-on Toggles") or "Always-on Toggles"),
        "bl_space_type": target_space,
        "bl_region_type": "UI",
        "bl_category": "Smart File",
        "bl_parent_id": parent_id,
    }
    for name in (
        "bl_description",
        "bl_order",
        "bl_options",
        "bl_ui_units_x",
        "bl_translation_context",
    ):
        _copy_attr(attrs, source_cls, name)

    @classmethod
    def poll(cls, context):
        if bool(getattr(source_cls, "_sfs_inline_top_section_replacement", False)):
            return False
        area = getattr(context, "area", None) if context is not None else None
        if area is not None and str(getattr(area, "type", "") or "") != target_space:
            return False
        editor_key = _logical_editor_key(context, target_space)
        return bool(manager_allows_context(context, editor_key))

    def draw(self, context):
        try:
            source_draw(self, context)
        except Exception:
            pass
        return None

    def draw_header(self, context):
        if callable(source_draw_header):
            try:
                source_draw_header(self, context)
            except Exception:
                pass
        return None

    attrs["poll"] = poll
    attrs["draw"] = draw
    if callable(source_draw_header_preset):
        attrs["draw_header_preset"] = source_draw_header_preset
    if callable(source_draw_header):
        attrs["draw_header"] = draw_header
    return type(class_id, (bpy.types.Panel,), attrs)


def _register_exact(cls) -> None:
    if _class_owns_rna(cls):
        return
    # This known class is recorded by the multi-editor generation ledger below;
    # no shared status module or package-wide class scan is needed.
    bpy.utils.register_class(cls)
    if not _class_owns_rna(cls):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        raise RuntimeError(f"Multi-editor Panel RNA registration failed: {cls.__name__}")


def _unregister_exact(cls) -> bool:
    if not _class_owns_rna(cls):
        return True
    try:
        bpy.utils.unregister_class(cls)
        return not _class_owns_rna(cls)
    except Exception:
        return False


def _cleanup_generation(token=None, generation=None) -> bool:
    global _SOURCE_CLASS, _CHILD_SOURCE_CLASS
    if token is not None and token is not _OWNER_TOKEN:
        return True
    if generation is not None and str(generation) != _GENERATION:
        return True
    ok = True
    for cls in reversed(tuple(_REGISTERED_CHILD_CLONES)):
        ok = _unregister_exact(cls) and ok
    for cls in reversed(tuple(_REGISTERED_CLONES)):
        ok = _unregister_exact(cls) and ok
    _REGISTERED_CHILD_CLONES.clear()
    _REGISTERED_CLONES.clear()
    _CHILD_CLONE_BY_SPACE.clear()
    _CLONE_BY_SPACE.clear()
    _SOURCE_CLASS = None
    _CHILD_SOURCE_CLASS = None
    namespace = _namespace()
    if namespace is not None:
        current = namespace.get(_OWNER_KEY)
        if isinstance(current, dict) and current.get("token") is _OWNER_TOKEN:
            namespace.pop(_OWNER_KEY, None)
    return ok


def _cleanup_previous(ledger) -> bool:
    if not isinstance(ledger, dict):
        return True
    cleanup = ledger.get("cleanup")
    if not callable(cleanup):
        return False
    try:
        return bool(cleanup(ledger.get("token"), ledger.get("generation")))
    except TypeError:
        try:
            return bool(cleanup())
        except Exception:
            return False
    except Exception:
        return False


def register() -> bool:
    """Register native editor roots and compatibility children as one generation."""
    global _SOURCE_CLASS, _CHILD_SOURCE_CLASS, _LAST_ERROR, _DEGRADED
    _LAST_ERROR = ""
    _DEGRADED = False
    namespace = _namespace()
    if namespace is None:
        _LAST_ERROR = "driver_namespace unavailable for multi-editor panels"
        _DEGRADED = True
        return False
    local: list[type] = []
    try:
        for legacy_key in _LEGACY_OWNER_KEYS:
            previous = namespace.get(legacy_key)
            if previous is None:
                continue
            if not _cleanup_previous(previous):
                raise RuntimeError(f"previous multi-editor panel generation cleanup failed: {legacy_key}")
            namespace.pop(legacy_key, None)
        previous = namespace.get(_OWNER_KEY)
        if isinstance(previous, dict) and previous.get("token") is not _OWNER_TOKEN:
            if not _cleanup_previous(previous):
                raise RuntimeError("previous multi-editor panel generation cleanup failed")
            namespace.pop(_OWNER_KEY, None)
        _cleanup_generation()

        source = _resolve_source_panel()
        if source is None:
            raise RuntimeError("canonical Smart File full-body panel was not found in package namespace")
        child_source = _resolve_child_source_panel()
        if child_source is None:
            raise RuntimeError("canonical Smart File native child panel was not found in package namespace")
        _SOURCE_CLASS = source
        _CHILD_SOURCE_CLASS = child_source
        for target_space, class_id in _TARGETS:
            clone = _make_clone(source, target_space, class_id)
            _register_exact(clone)
            local.append(clone)
            _REGISTERED_CLONES.append(clone)
            _CLONE_BY_SPACE[target_space] = clone

            child_id = f"{class_id}_always"
            child_clone = _make_child_clone(child_source, target_space, child_id, class_id)
            _register_exact(child_clone)
            local.append(child_clone)
            _REGISTERED_CHILD_CLONES.append(child_clone)
            _CHILD_CLONE_BY_SPACE[target_space] = child_clone
        asset_root = _make_clone(source, "FILE_BROWSER", _ASSET_PANEL_ID, asset_browser=True)
        _register_exact(asset_root)
        local.append(asset_root)
        _REGISTERED_CLONES.append(asset_root)

        if len(_REGISTERED_CLONES) != len(_TARGETS) + 1:
            raise RuntimeError("multi-editor root clone count mismatch")
        if len(_REGISTERED_CHILD_CLONES) != len(_TARGETS):
            raise RuntimeError("multi-editor child clone count mismatch")
        if any(not _class_owns_rna(cls) for cls in tuple(_REGISTERED_CLONES) + tuple(_REGISTERED_CHILD_CLONES)):
            raise RuntimeError("multi-editor clone exact RNA validation failed")
        namespace[_OWNER_KEY] = {
            "schema": 4,
            "token": _OWNER_TOKEN,
            "generation": _GENERATION,
            "source": source,
            "child_source": child_source,
            "clones": tuple(_REGISTERED_CLONES),
            "child_clones": tuple(_REGISTERED_CHILD_CLONES),
            "cleanup": _cleanup_generation,
        }
        tag_redraw()
        return True
    except Exception as exc:
        for cls in reversed(local):
            _unregister_exact(cls)
        _REGISTERED_CHILD_CLONES.clear()
        _REGISTERED_CLONES.clear()
        _CHILD_CLONE_BY_SPACE.clear()
        _CLONE_BY_SPACE.clear()
        _SOURCE_CLASS = None
        _CHILD_SOURCE_CLASS = None
        _LAST_ERROR = f"{type(exc).__name__}: {exc}"[:1024]
        _DEGRADED = True
        return False


def unregister() -> bool:
    return _cleanup_generation()


def tag_redraw() -> None:
    try:
        wm = getattr(getattr(bpy, "context", None), "window_manager", None)
    except Exception:
        wm = None
    supported = {space for space, _class_id in _TARGETS} | {"VIEW_3D"}
    for window in getattr(wm, "windows", ()) if wm is not None else ():
        screen = getattr(window, "screen", None)
        for area in getattr(screen, "areas", ()) if screen is not None else ():
            try:
                if str(getattr(area, "type", "") or "") in supported:
                    area.tag_redraw()
            except Exception:
                pass


def registered_clone_count() -> int:
    return len(_REGISTERED_CLONES)


def registered_child_clone_count() -> int:
    return len(_REGISTERED_CHILD_CLONES)


def physical_root_count() -> int:
    return (1 if _class_owns_rna(_SOURCE_CLASS) else 0) + len(_REGISTERED_CLONES)


def runtime_status() -> dict[str, Any]:
    ledger = _ledger()
    exact = bool(
        isinstance(ledger, dict)
        and ledger.get("token") is _OWNER_TOKEN
        and ledger.get("generation") == _GENERATION
        and ledger.get("source") is _SOURCE_CLASS
        and ledger.get("child_source") is _CHILD_SOURCE_CLASS
        and tuple(ledger.get("clones", ()) or ()) == tuple(_REGISTERED_CLONES)
        and tuple(ledger.get("child_clones", ()) or ()) == tuple(_REGISTERED_CHILD_CLONES)
        and _class_owns_rna(_SOURCE_CLASS)
        and _class_owns_rna(_CHILD_SOURCE_CLASS)
        and len(_REGISTERED_CLONES) == len(_TARGETS) + 1
        and len(_REGISTERED_CHILD_CLONES) == len(_TARGETS)
        and all(_class_owns_rna(cls) for cls in tuple(_REGISTERED_CLONES) + tuple(_REGISTERED_CHILD_CLONES))
    )
    return {
        "registered": exact,
        "generation": _GENERATION,
        "source_exact": bool(_class_owns_rna(_SOURCE_CLASS)),
        "child_source_exact": bool(_class_owns_rna(_CHILD_SOURCE_CLASS)),
        "clone_count": len(_REGISTERED_CLONES),
        "child_clone_count": len(_REGISTERED_CHILD_CLONES),
        "expected_clone_count": len(_TARGETS) + 1,
        "physical_root_count": physical_root_count(),
        "logical_editor_count": sum(len(items) for items in _LOGICAL_EDITORS_BY_SPACE.values()),
        "logical_editors": tuple(item for items in _LOGICAL_EDITORS_BY_SPACE.values() for item in items),
        "manager_query_mode": "fixed-sys-modules-placement-allowed-read-only-fail-open",
        "authoritative_native_roots": sum(1 for cls in ((_SOURCE_CLASS,) + tuple(_REGISTERED_CLONES)) if bool(getattr(cls, "_smart_tools_manager_native_npanel_root", False))),
        "ids_within_limit": all(
            len(str(getattr(cls, "bl_idname", "")).encode("utf-8")) <= 63
            for cls in tuple(_REGISTERED_CLONES) + tuple(_REGISTERED_CHILD_CLONES)
        ),
        "degraded": bool(_DEGRADED),
        "last_error": str(_LAST_ERROR),
        "first_draw_mode": "closure-captured-canonical-full-body",
    }
