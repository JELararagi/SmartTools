"""Core utilities, storage, manifests, and material helpers."""
from __future__ import annotations
from .translation import loc_text as _lt
from .translation import AddonError
import json
import re
import time
from datetime import datetime
from collections import defaultdict
from pathlib import Path
from typing import Iterable
import bpy
from . import data, storage
TEXTURE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.tif', '.tiff', '.exr', '.hdr', '.bmp', '.tga', '.webp', '.tx'}
_JSON_LOAD_CACHE: dict[str, tuple[float, int, object]] = {}
_MATERIAL_AUDIT_CACHE: dict[tuple, tuple[float, dict]] = {}
_MATERIAL_USAGE_USERS_CACHE: dict[tuple, tuple[float, tuple[str, ...]]] = {}
CLEANUP_PROTECTION_KEY = 'sss_cleanup_protected'
CLEANUP_PROTECTION_REASON_KEY = 'sss_cleanup_protection_reason'

def _sanitize_json_payload(payload) -> list[dict]:
    if isinstance(payload, dict):
        for key in ('presets', 'items', 'library', 'variants', 'recipes', 'layers', 'catalog', 'entries', 'materials'):
            value = payload.get(key)
            if isinstance(value, list):
                payload = value
                break
        else:
            if payload.get('name') or payload.get('material_name') or payload.get('builder') or payload.get('manifest'):
                payload = [payload]
            else:
                return []
    if not isinstance(payload, list):
        return []
    return [item for item in payload if isinstance(item, dict)]


def safe_json_load(path: Path) -> list[dict]:
    try:
        path = Path(path)
    except Exception:
        return []
    if not path.exists():
        return []
    try:
        stat = path.stat()
        cache_key = str(path.resolve())
        mtime = float(stat.st_mtime)
        size = int(stat.st_size)
    except Exception:
        cache_key = str(path)
        mtime = 0.0
        size = -1
    cached = _JSON_LOAD_CACHE.get(cache_key)
    if cached is not None and cached[0] == mtime and cached[1] == size:
        payload = cached[2]
        return [dict(item) for item in payload] if isinstance(payload, list) else []
    try:
        payload = json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return []
    clean = _sanitize_json_payload(payload)
    _JSON_LOAD_CACHE[cache_key] = (mtime, size, [dict(item) for item in clean])
    if len(_JSON_LOAD_CACHE) > 128:
        for old_key in list(_JSON_LOAD_CACHE.keys())[:32]:
            _JSON_LOAD_CACHE.pop(old_key, None)
    return clean


def safe_json_save(path: Path, payload: list) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
    try:
        _JSON_LOAD_CACHE.pop(str(path.resolve()), None)
    except Exception:
        _JSON_LOAD_CACHE.pop(str(path), None)


def addon_package_keys() -> list[str]:
    package_name = (__package__ or data.ADDON_ID).strip()
    leaf_name = package_name.split('.')[-1] if package_name else data.ADDON_ID
    keys: list[str] = []
    for key in (package_name, data.ADDON_ID, leaf_name, storage.package_id(data.ADDON_ID)):
        key = str(key or '').strip()
        if key and key not in keys:
            keys.append(key)
    return keys

def addon_preferences():
    # Compatibility shim: user-facing settings are stored on the N-panel
    # WindowManager property group, not on AddonPreferences.
    try:
        from . import preferences as _preferences
        return _preferences.addon_preferences_owner(getattr(bpy, 'context', None))
    except Exception:
        return None
def extension_package_id_candidates() -> tuple[str, ...]:
    candidates: list[str] = []
    for value in addon_package_keys():
        text = str(value or '').strip()
        leaf = text.split('.')[-1] if text else ''
        for candidate in (text, leaf):
            if candidate and candidate not in candidates:
                candidates.append(candidate)
    if data.ADDON_ID not in candidates:
        candidates.append(data.ADDON_ID)
    return tuple(candidates) or (data.ADDON_ID,)

def extension_package_id() -> str:
    return extension_package_id_candidates()[0]


def extension_user_root(create: bool=False) -> Path:
    return storage.extension_user_root(create=create)
def addon_storage_dir() -> Path:
    # Automatic Smart Shader data never follows the legacy Library Path field.
    # Manual directory properties are handled by their own operators; generated
    # reports, manifests, caches, and helper files stay in config/Smart_Shader_Suite.
    base_dir = storage.data_dir(create=True)
    base_dir.mkdir(parents=True, exist_ok=True)
    return base_dir

def clean_library_name(value: str) -> str:
    return re.sub('\\s+', ' ', str(value or '').strip())

def library_name_key(value: str) -> str:
    return clean_library_name(value).casefold()

def safe_version_string() -> str:
    value = str(getattr(getattr(bpy, 'app', None), 'version_string', '') or '').strip()
    if value:
        return value
    version = getattr(getattr(bpy, 'app', None), 'version', ())
    try:
        if version:
            return '.'.join((str(part) for part in version))
    except Exception:
        pass
    return ''


def safe_data_collection(collection_name: str):
    """Return a bpy.data collection only when Blender data access is available.

    Blender calls dynamic EnumProperty callbacks while addon registration and
    extension metadata reloads are still inside _RestrictData.  Accessing
    bpy.data.materials directly in that phase raises AttributeError and turns a
    harmless UI refresh into a console traceback.  This helper keeps normal
    runtime behavior unchanged and simply returns None during restricted phases.
    """
    data_block = getattr(bpy, 'data', None)
    if data_block is None:
        return None
    try:
        return getattr(data_block, str(collection_name or ''))
    except Exception:
        return None


def safe_data_iter(collection_name: str) -> list:
    collection = safe_data_collection(collection_name)
    if collection is None:
        return []
    try:
        return list(collection)
    except Exception:
        return []


def safe_data_get(collection_name: str, name: str):
    key = str(name or '').strip()
    if not key:
        return None
    collection = safe_data_collection(collection_name)
    get_fn = getattr(collection, 'get', None) if collection is not None else None
    if not callable(get_fn):
        return None
    try:
        return get_fn(key)
    except Exception:
        return None

def safe_remove_id(collection, datablock) -> bool:
    if collection is None or datablock is None:
        return False
    remove = getattr(collection, 'remove', None)
    if remove is None:
        return False
    try:
        remove(datablock, do_unlink=True)
        return True
    except TypeError:
        pass
    except Exception:
        pass
    try:
        remove(datablock)
        return True
    except Exception:
        return False

def custom_preset_path() -> Path:
    return addon_storage_dir() / 'custom_presets.json'

def scene_variant_path() -> Path:
    return addon_storage_dir() / 'scene_variants.json'

def scene_variant_library_path() -> Path:
    return addon_storage_dir() / 'scene_variant_library.json'

def list_scene_variants() -> list[dict]:
    items = [item for item in (_sanitize_scene_variant_entry(entry) for entry in safe_json_load(scene_variant_path())) if item is not None]
    items.sort(key=lambda item: library_name_key(item.get('name', '')))
    return items

def find_scene_variant(name: str) -> dict | None:
    target = library_name_key(name)
    if not target:
        return None
    for item in list_scene_variants():
        if library_name_key(item.get('name', '')) == target:
            return item
    return None

def _sanitize_scene_variant_entry(entry: dict) -> dict | None:
    if not isinstance(entry, dict):
        return None
    name = clean_library_name(entry.get('name', ''))
    if not name:
        return None
    clean = dict(entry)
    clean['name'] = name
    if not isinstance(clean.get('materials'), list):
        clean['materials'] = []
    if not isinstance(clean.get('objects'), list):
        clean['objects'] = []
    if not isinstance(clean.get('world'), dict):
        clean['world'] = {}
    if not isinstance(clean.get('protected_counts'), dict):
        clean['protected_counts'] = {}
    return clean

def export_scene_variant_library(path: Path) -> int:
    payload = list_scene_variants()
    safe_json_save(Path(path), payload)
    return len(payload)

def _load_scene_variant_library_payload(path: Path) -> list[dict]:
    if not Path(path).exists():
        return []
    try:
        payload = json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return []
    if isinstance(payload, dict):
        for key in ('variants', 'items', 'library'):
            value = payload.get(key)
            if isinstance(value, list):
                payload = value
                break
        else:
            if payload.get('name'):
                payload = [payload]
            else:
                return []
    if not isinstance(payload, list):
        return []
    return [item for item in payload if isinstance(item, dict)]

def repair_scene_variant_library() -> dict:
    original = _load_scene_variant_library_payload(scene_variant_path())
    repaired: list[dict] = []
    seen: dict[str, int] = {}
    dropped = 0
    duplicates = 0
    for entry in original:
        clean = _sanitize_scene_variant_entry(entry)
        if clean is None:
            dropped += 1
            continue
        key = library_name_key(clean['name'])
        if key in seen:
            repaired[seen[key]] = clean
            duplicates += 1
        else:
            seen[key] = len(repaired)
            repaired.append(clean)
    safe_json_save(scene_variant_path(), repaired)
    return {'before': len(original), 'after': len(repaired), 'dropped': dropped, 'duplicates': duplicates}

def import_scene_variant_library(path: Path, mode: str='MERGE') -> dict:
    incoming_raw = _load_scene_variant_library_payload(Path(path))
    incoming: list[dict] = []
    skipped_invalid = 0
    for entry in incoming_raw:
        clean = _sanitize_scene_variant_entry(entry)
        if clean is None:
            skipped_invalid += 1
            continue
        incoming.append(clean)
    if mode == 'REPLACE':
        incoming.sort(key=lambda item: library_name_key(item.get('name', '')))
        safe_json_save(scene_variant_path(), incoming)
        return {'imported': len(incoming), 'replaced': 0, 'skipped_invalid': skipped_invalid, 'total': len(incoming), 'mode': 'REPLACE'}
    existing = safe_json_load(scene_variant_path())
    merged: list[dict] = []
    seen: dict[str, int] = {}
    for entry in existing:
        clean = _sanitize_scene_variant_entry(entry)
        if clean is None:
            continue
        key = library_name_key(clean['name'])
        seen[key] = len(merged)
        merged.append(clean)
    replaced = 0
    imported = 0
    for entry in incoming:
        key = library_name_key(entry['name'])
        if key in seen:
            merged[seen[key]] = entry
            replaced += 1
        else:
            seen[key] = len(merged)
            merged.append(entry)
            imported += 1
    merged.sort(key=lambda item: library_name_key(item.get('name', '')))
    safe_json_save(scene_variant_path(), merged)
    return {'imported': imported, 'replaced': replaced, 'skipped_invalid': skipped_invalid, 'total': len(merged), 'mode': 'MERGE'}

def save_scene_variant_payload(payload: dict) -> None:
    if not isinstance(payload, dict):
        raise AddonError(_lt('Scene variant payload must be a dictionary.', 'シーンバリアントのペイロードは辞書形式である必要があります。'))
    clean = _sanitize_scene_variant_entry(payload)
    if clean is None:
        raise AddonError(_lt('Scene variant name is required.', 'シーンバリアント名が必要です。'))
    name_key = library_name_key(clean.get('name', ''))
    db = list_scene_variants()
    replaced = False
    for index, item in enumerate(db):
        if library_name_key(item.get('name', '')) == name_key:
            db[index] = clean
            replaced = True
            break
    if not replaced:
        db.append(clean)
    db.sort(key=lambda item: library_name_key(item.get('name', '')))
    safe_json_save(scene_variant_path(), db)

def delete_scene_variant(name: str) -> bool:
    target = library_name_key(name)
    if not target:
        return False
    db = list_scene_variants()
    kept = [item for item in db if library_name_key(item.get('name', '')) != target]
    if len(kept) == len(db):
        return False
    safe_json_save(scene_variant_path(), kept)
    return True

def scene_variant_payload(context, name: str) -> dict:
    payload = scene_manifest(context)
    payload['scope'] = 'scene_variant'
    payload['name'] = str(name or '').strip()
    payload['saved_at'] = datetime.utcnow().isoformat(timespec='seconds') + 'Z'
    payload['target_material'] = getattr(getattr(context, 'scene', None), 'sss_target_material_name', '')
    payload['active_material'] = getattr(active_material(context), 'name', '')
    return payload

def package_dir() -> Path:
    return Path(__file__).resolve().parent

def bundled_file_path(name: str) -> Path:
    return package_dir() / name

def read_bundled_text(name: str) -> str:
    path = bundled_file_path(name)
    try:
        return path.read_text(encoding='utf-8')
    except Exception:
        return ''

def report_to_scene(scene, message: str) -> None:
    if scene is not None:
        scene.sss_last_report = message

def active_material(context):
    material = getattr(context, 'material', None)
    if material is not None:
        return material
    obj = getattr(context, 'object', None)
    if obj is not None:
        return getattr(obj, 'active_material', None)
    return None

def get_target_material(context):
    scene = getattr(context, 'scene', None)
    name = getattr(scene, 'sss_target_material_name', '').strip() if scene else ''
    if not name:
        return None
    return safe_data_get('materials', name)

def preferred_material(context):
    try:
        return active_material(context) or get_target_material(context)
    except Exception:
        return active_material(context)

def assign_mode(context) -> str:
    try:
        return getattr(context.scene, 'sss_assign_mode', 'ACTIVE_SLOT') or 'ACTIVE_SLOT'
    except Exception:
        return 'ACTIVE_SLOT'

def _object_material_collection(obj):
    data_block = getattr(obj, 'data', None)
    if not data_block or not hasattr(data_block, 'materials'):
        return None
    return data_block.materials


def material_slot_count(obj) -> int:
    materials = _object_material_collection(obj)
    if materials is None:
        return 0
    try:
        return max(0, int(len(materials)))
    except Exception:
        return 0


def material_slot_capable(obj) -> bool:
    return _object_material_collection(obj) is not None


def selected_material_target_objects(context, *, assign_selected: bool=True) -> list:
    """Return material-slot-capable assignment targets, with active object first."""
    targets = []
    seen = set()

    def add(obj):
        if obj is None or not material_slot_capable(obj):
            return
        try:
            key = getattr(obj, 'name_full', None) or getattr(obj, 'name', '') or str(id(obj))
        except Exception:
            key = str(id(obj))
        if key in seen:
            return
        seen.add(key)
        targets.append(obj)

    active_obj = getattr(context, 'object', None) or getattr(context, 'active_object', None)
    if assign_selected:
        add(active_obj)
        try:
            for obj in list(getattr(context, 'selected_objects', []) or []):
                add(obj)
        except Exception:
            pass
    else:
        add(active_obj)
    if not targets:
        add(active_obj)
    return targets


def is_multi_object_material_slot_assignment(context, *, assign_selected: bool | None=None, obj=None) -> bool:
    scene = getattr(context, 'scene', None) if context is not None else None
    if scene is None:
        return False
    try:
        if str(assign_mode(context) or 'ACTIVE_SLOT') != 'ACTIVE_SLOT':
            return False
    except Exception:
        return False
    if assign_selected is None:
        try:
            assign_selected = bool(getattr(scene, 'sss_assign_selected', True))
        except Exception:
            assign_selected = True
    if not bool(assign_selected):
        return False
    targets = selected_material_target_objects(context, assign_selected=True)
    if len(targets) <= 1:
        return False
    if obj is not None:
        try:
            if obj not in targets:
                return False
        except Exception:
            return False
    return True


def material_target_slot_index_from_object(obj) -> int:
    try:
        return max(0, int(getattr(obj, 'active_material_index', 0)))
    except Exception:
        return 0


def set_material_target_slot_index_on_object(obj, index: int) -> int:
    try:
        idx = max(0, int(index))
    except Exception:
        idx = 0
    try:
        count = material_slot_count(obj)
        if count > 0:
            idx = max(0, min(count - 1, idx))
    except Exception:
        pass
    if obj is not None:
        try:
            if material_slot_count(obj) > 0:
                obj.active_material_index = idx
        except Exception:
            pass
    return idx


def material_generation_should_assign_selected(context) -> bool:
    try:
        if len(selected_material_target_objects(context, assign_selected=True)) > 1:
            return True
    except Exception:
        pass
    scene = getattr(context, 'scene', None) if context is not None else None
    try:
        return bool(getattr(scene, 'sss_assign_selected', True))
    except Exception:
        return True


def material_slot_label(obj, index: int, *, empty_label: str='Empty') -> str:
    try:
        idx = max(0, int(index))
    except Exception:
        idx = 0
    name = ''
    try:
        slots = getattr(obj, 'material_slots', None)
        if slots is not None and 0 <= idx < len(slots):
            mat = slots[idx].material
            name = str(getattr(mat, 'name', '') or '') if mat is not None else ''
    except Exception:
        name = ''
    if not name:
        try:
            materials = _object_material_collection(obj)
            mat = materials[idx] if materials is not None and 0 <= idx < len(materials) else None
            name = str(getattr(mat, 'name', '') or '') if mat is not None else ''
        except Exception:
            name = ''
    return f'{idx + 1}: {name or empty_label}'


def selected_material_slot_index(context, obj=None, *, clamp: bool=True) -> int:
    obj = obj or getattr(context, 'object', None) or getattr(context, 'active_object', None)
    slot_count = material_slot_count(obj)
    scene = getattr(context, 'scene', None)

    # When several objects are selected, each object keeps its own popup-selected
    # target slot. Do not reuse the active object's scene-level slot for all of
    # them.
    if context is not None and obj is not None and is_multi_object_material_slot_assignment(context, assign_selected=True, obj=obj):
        raw_index = material_target_slot_index_from_object(obj)
        if not clamp:
            return max(0, raw_index)
        if slot_count <= 0:
            return 0
        return max(0, min(slot_count - 1, raw_index))

    raw_index = -1
    if scene is not None:
        try:
            raw_index = int(getattr(scene, 'sss_material_target_slot_index', -1))
        except Exception:
            raw_index = -1
    if raw_index < 0:
        raw_index = material_target_slot_index_from_object(obj)
    if not clamp:
        return max(0, raw_index)
    if slot_count <= 0:
        return 0
    return max(0, min(slot_count - 1, raw_index))


def sync_selected_material_slot_to_active_object(context) -> int:
    obj = getattr(context, 'object', None) or getattr(context, 'active_object', None)
    idx = selected_material_slot_index(context, obj)
    if obj is not None and material_slot_count(obj) > 0:
        try:
            obj.active_material_index = idx
        except Exception:
            pass
    return idx


def set_material_on_object(obj, material, mode: str='ACTIVE_SLOT', context=None) -> bool:
    if obj is None or material is None:
        return False
    materials = _object_material_collection(obj)
    if materials is None:
        return False
    try:
        slot_count = len(materials)
    except Exception:
        slot_count = 0
    try:
        if mode == 'APPEND':
            for existing in materials:
                if existing == material:
                    return True
            materials.append(material)
            return True
        if mode == 'ALL_SLOTS':
            if slot_count == 0:
                materials.append(material)
            else:
                for index in range(slot_count):
                    materials[index] = material
            return True
        if mode == 'FIRST_SLOT':
            if slot_count == 0:
                materials.append(material)
            else:
                materials[0] = material
            return True
        if slot_count == 0:
            materials.append(material)
            try:
                obj.active_material_index = 0
            except Exception:
                pass
        else:
            active_index = selected_material_slot_index(context, obj) if context is not None else max(0, int(getattr(obj, 'active_material_index', 0)))
            if active_index >= slot_count:
                active_index = slot_count - 1
            materials[active_index] = material
            try:
                obj.active_material_index = active_index
            except Exception:
                pass
        try:
            obj.active_material = material
        except Exception:
            pass
        return True
    except Exception:
        return False

def set_active_material(context, material) -> bool:
    if material_generation_should_assign_selected(context):
        return assign_material_to_selected(context, material) > 0
    obj = getattr(context, 'object', None)
    return set_material_on_object(obj, material, assign_mode(context), context=context)

def assign_material_to_selected(context, material) -> int:
    if not material:
        return 0
    targets = selected_material_target_objects(context, assign_selected=True)
    assigned = 0
    mode = assign_mode(context)
    for obj in targets:
        if set_material_on_object(obj, material, mode, context=context):
            assigned += 1
    return assigned
_DUPLICATE_SUFFIX_RE = re.compile('([._-](copy|dup|sss))+$', re.IGNORECASE)
_NUMERIC_SUFFIX_RE = re.compile('[._-](\\d{3,4})$')

def material_base_name(name: str) -> str:
    value = (name or '').strip()
    if not value:
        return ''
    value = _NUMERIC_SUFFIX_RE.sub('', value)
    value = _DUPLICATE_SUFFIX_RE.sub('', value)
    return value.strip('._- ').lower()

def material_merge_key(material) -> tuple:
    if material is None:
        return ('NONE',)
    builder = str(material.get('sss_builder', '') or '').strip()
    if builder and builder != 'EXTERNAL_CAPTURE':
        params = get_material_params(material)
        return ('SMART', builder, json.dumps(params or {}, ensure_ascii=False, sort_keys=True))
    approx = approx_params_from_material(material)
    return ('APPROX', material_base_name(getattr(material, 'name', '')), json.dumps(approx, ensure_ascii=False, sort_keys=True))

def duplicate_material_groups(materials=None) -> list[list]:
    mats = [mat for mat in materials or safe_data_iter('materials') if mat]
    grouped: dict[tuple, list] = defaultdict(list)
    for material in mats:
        grouped[material_merge_key(material)].append(material)
    return [group for group in grouped.values() if len(group) > 1]

def select_objects_by_material(context, material, extend: bool=False) -> int:
    if material is None:
        return 0
    scene = getattr(context, 'scene', None)
    objects = getattr(scene, 'objects', None) or safe_data_iter('objects')
    selected = []
    for obj in objects:
        data_block = getattr(obj, 'data', None)
        if not data_block or not hasattr(data_block, 'materials'):
            continue
        if any((slot_mat == material for slot_mat in data_block.materials)):
            selected.append(obj)
    if not extend:
        for obj in objects:
            try:
                obj.select_set(False)
            except Exception:
                pass
    first = None
    for obj in selected:
        try:
            obj.select_set(True)
            if first is None:
                first = obj
        except Exception:
            pass
    if first is not None:
        try:
            context.view_layer.objects.active = first
        except Exception:
            pass
    return len(selected)

def replace_material_references(old_material, new_material, objects=None) -> int:
    if old_material is None or new_material is None or old_material == new_material:
        return 0
    objects = objects or safe_data_iter('objects')
    changed = 0
    for obj in objects:
        materials = _object_material_collection(obj)
        if materials is None:
            continue
        for index in range(len(materials)):
            try:
                if materials[index] == old_material:
                    materials[index] = new_material
                    changed += 1
            except Exception:
                continue
    return changed

def clear_material_from_objects(objects, material=None, mode: str='ACTIVE_SLOT') -> dict:
    processed = 0
    cleared_slots = 0
    for obj in objects:
        materials = _object_material_collection(obj)
        if materials is None:
            continue
        slot_count = len(materials)
        if slot_count == 0:
            continue
        indices: list[int] = []
        if mode == 'FIRST_SLOT':
            indices = [0]
        elif mode in {'ALL_SLOTS', 'APPEND'}:
            indices = list(range(slot_count))
        else:
            active_index = max(0, min(slot_count - 1, int(getattr(obj, 'active_material_index', 0))))
            indices = [active_index]
        touched = False
        for index in indices:
            try:
                current = materials[index]
            except Exception:
                continue
            if material is not None and current != material and (mode not in {'ALL_SLOTS', 'APPEND'}):
                continue
            if material is not None and mode in {'ALL_SLOTS', 'APPEND'} and (current != material):
                continue
            try:
                materials[index] = None
                cleared_slots += 1
                touched = True
            except Exception:
                continue
        if touched:
            processed += 1
    cleanup = cleanup_material_slots(objects)
    return {'objects': processed, 'cleared_slots': cleared_slots, 'removed_slots': cleanup.get('removed_slots', 0), 'remapped_faces': cleanup.get('remapped_faces', 0)}

def merge_duplicate_materials(materials=None) -> dict:
    mats = [mat for mat in materials or scene_materials() if mat]
    groups = duplicate_material_groups(mats)
    objects = safe_data_iter('objects')
    merged = 0
    reassigned_slots = 0
    removed = 0
    skipped = 0

    def keeper_sort_key(mat):
        return (0 if getattr(mat, 'asset_data', None) else 1, -int(getattr(mat, 'users', 0) or 0), 0 if getattr(mat, 'use_fake_user', False) else 1, len(getattr(mat, 'name', '') or ''), getattr(mat, 'name', '') or '')
    for group in groups:
        ordered = sorted(group, key=keeper_sort_key)
        keeper = ordered[0]
        for duplicate in ordered[1:]:
            if is_cleanup_protected(duplicate):
                skipped += 1
                continue
            reassigned_slots += replace_material_references(duplicate, keeper, objects=objects)
            if getattr(duplicate, 'users', 0) == 0 and (not getattr(duplicate, 'use_fake_user', False)):
                if safe_remove_id(bpy.data.materials, duplicate):
                    removed += 1
                else:
                    skipped += 1
            else:
                skipped += 1
            merged += 1
    return {'groups': len(groups), 'merged': merged, 'reassigned_slots': reassigned_slots, 'removed': removed, 'skipped': skipped}

def mark_material_as_asset(material) -> None:
    if not material:
        return
    if hasattr(material, 'asset_mark'):
        try:
            material.asset_mark()
        except Exception:
            pass
    if hasattr(material, 'asset_generate_preview'):
        try:
            material.asset_generate_preview()
        except Exception:
            pass

def duplicate_for_non_destructive(context, material):
    if not material or not getattr(context.scene, 'sss_non_destructive', True):
        return material
    copy = material.copy()
    copy.name = f'{material.name}_SSS'
    set_active_material(context, copy)
    return copy

def serialize_value(value):
    if value is None:
        return None
    if isinstance(value, (bool, int, float, str)):
        return value
    if hasattr(value, 'to_tuple'):
        try:
            return list(value.to_tuple())
        except Exception:
            pass
    if hasattr(value, 'to_list'):
        try:
            return list(value.to_list())
        except Exception:
            pass
    try:
        return [serialize_value(v) for v in value]
    except Exception:
        pass
    try:
        return float(value)
    except Exception:
        return str(value)

def get_material_params(material) -> dict:
    if not material:
        return {}
    raw = material.get('sss_params')
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except Exception:
        return {}

def get_material_tags(material) -> list[str]:
    if not material:
        return []
    raw = material.get('sss_tags')
    if not raw:
        return []
    try:
        tags = json.loads(raw)
        if isinstance(tags, list):
            return [str(tag) for tag in tags]
    except Exception:
        return []
    return []

def store_smart_metadata(material, preset_id: str, params: dict, summary_en: str, summary_ja: str, tags: list[str] | None=None):
    meta = data.PRESET_LIBRARY.get(preset_id, {})
    material['sss_builder'] = preset_id
    material['sss_family'] = meta.get('family', 'UNKNOWN')
    material['sss_version'] = data.ADDON_VERSION
    material['sss_summary_en'] = summary_en
    material['sss_summary_ja'] = summary_ja
    material['sss_params'] = json.dumps(params or {}, ensure_ascii=False, sort_keys=True)
    material['sss_tags'] = json.dumps(tags or meta.get('tags', []), ensure_ascii=False)

def set_managed_metadata_only(material, note_en: str | None=None, note_ja: str | None=None, params: dict | None=None, tags: list[str] | None=None):
    if not material:
        return
    material['sss_builder'] = material.get('sss_builder', 'EXTERNAL_CAPTURE')
    material['sss_family'] = material.get('sss_family', 'CAPTURED')
    material['sss_version'] = data.ADDON_VERSION
    if not material.get('sss_summary_en'):
        material['sss_summary_en'] = note_en or 'Captured external material managed by Smart Shader.'
    if not material.get('sss_summary_ja'):
        material['sss_summary_ja'] = note_ja or _lt('スマートシェーダーで管理対象として取り込んだ既存マテリアルです。')
    if params is None:
        params = material.get('sss_params')
        try:
            params = json.loads(params) if isinstance(params, str) else {}
        except Exception:
            params = {}
    material['sss_params'] = json.dumps(params or {}, ensure_ascii=False, sort_keys=True)
    material['sss_tags'] = json.dumps(tags or get_material_tags(material) or ['Captured'], ensure_ascii=False)

def iter_image_nodes(material):
    if not material or not material.use_nodes or (not material.node_tree):
        return []
    return [node for node in material.node_tree.nodes if hasattr(node, 'image') and getattr(node, 'image', None)]

def _safe_image_abspath(image) -> str:
    if image is None:
        return ''
    try:
        return bpy.path.abspath(getattr(image, 'filepath', '') or '')
    except Exception:
        return str(getattr(image, 'filepath', '') or '')


def _material_audit_cache_key(material) -> tuple:
    if material is None:
        return ()
    try:
        pointer = int(material.as_pointer())
    except Exception:
        pointer = id(material)
    try:
        node_tree = getattr(material, 'node_tree', None)
        nodes = getattr(node_tree, 'nodes', []) if node_tree is not None else []
        links = getattr(node_tree, 'links', []) if node_tree is not None else []
        node_count = len(nodes)
        link_count = len(links)
    except Exception:
        node_count = 0
        link_count = 0
    return (pointer, str(getattr(material, 'name', '') or ''), bool(getattr(material, 'use_nodes', False)), node_count, link_count)


def clear_material_audit_cache() -> None:
    _MATERIAL_AUDIT_CACHE.clear()


def material_node_audit(material) -> dict:
    result = {'texture_usages': {}, 'missing_textures': 0, 'node_count': 0, 'output_type': ''}
    if not material or not getattr(material, 'use_nodes', False) or (not getattr(material, 'node_tree', None)):
        return result
    cache_key = _material_audit_cache_key(material)
    now = time.monotonic()
    cached = _MATERIAL_AUDIT_CACHE.get(cache_key)
    if cached is not None and now - cached[0] < 0.75:
        return dict(cached[1])
    try:
        result['node_count'] = len(material.node_tree.nodes)
    except Exception:
        result['node_count'] = 0
    out = find_output_node(material)
    if out is not None:
        result['output_type'] = getattr(out, 'type', '') or getattr(out, 'bl_idname', '') or out.__class__.__name__
    try:
        from . import textures
    except Exception:
        textures = None
    for node in iter_image_nodes(material):
        usage = 'unknown'
        if textures is not None:
            try:
                usage = str(textures.guess_image_usage(node) or 'unknown').strip().lower() or 'unknown'
            except Exception:
                usage = 'unknown'
        result['texture_usages'][usage] = result['texture_usages'].get(usage, 0) + 1
        image = getattr(node, 'image', None)
        if image is None or getattr(image, 'packed_file', None):
            continue
        raw = _safe_image_abspath(image)
        if not raw or not Path(raw).exists():
            result['missing_textures'] += 1
    _MATERIAL_AUDIT_CACHE[cache_key] = (now, dict(result))
    if len(_MATERIAL_AUDIT_CACHE) > 512:
        for old_key in list(_MATERIAL_AUDIT_CACHE.keys())[:128]:
            _MATERIAL_AUDIT_CACHE.pop(old_key, None)
    return result


def count_missing_image_nodes(material) -> int:
    return int(material_node_audit(material).get('missing_textures', 0) or 0)

def iter_group_node_trees(material):
    if not material or not material.use_nodes or (not material.node_tree):
        return []
    groups = []
    seen = set()
    for node in material.node_tree.nodes:
        if node.bl_idname != 'ShaderNodeGroup':
            continue
        tree = getattr(node, 'node_tree', None)
        if tree is None:
            continue
        key = getattr(tree, 'name_full', None) or getattr(tree, 'name', None) or id(tree)
        if key in seen:
            continue
        seen.add(key)
        groups.append(tree)
    return groups

def is_cleanup_protected(datablock) -> bool:
    if datablock is None:
        return False
    try:
        return bool(datablock.get(CLEANUP_PROTECTION_KEY))
    except Exception:
        return False

def set_cleanup_protection(datablock, value: bool=True, reason: str='') -> bool:
    if datablock is None:
        return False
    try:
        if value:
            datablock[CLEANUP_PROTECTION_KEY] = True
            if reason:
                datablock[CLEANUP_PROTECTION_REASON_KEY] = str(reason)
            return True
        if CLEANUP_PROTECTION_KEY in datablock:
            del datablock[CLEANUP_PROTECTION_KEY]
        if CLEANUP_PROTECTION_REASON_KEY in datablock:
            del datablock[CLEANUP_PROTECTION_REASON_KEY]
        return True
    except Exception:
        return False

def protection_reason(datablock) -> str:
    if datablock is None:
        return ''
    try:
        return str(datablock.get(CLEANUP_PROTECTION_REASON_KEY, '') or '')
    except Exception:
        return ''

def protect_material_bundle(material, value: bool=True, reason: str='') -> dict:
    result = {'materials': 0, 'images': 0, 'node_groups': 0}
    if material is None:
        return result
    if set_cleanup_protection(material, value=value, reason=reason):
        result['materials'] += 1
    for node in iter_image_nodes(material):
        image = getattr(node, 'image', None)
        if image is None:
            continue
        if set_cleanup_protection(image, value=value, reason=reason):
            result['images'] += 1
    for group in iter_group_node_trees(material):
        if set_cleanup_protection(group, value=value, reason=reason):
            result['node_groups'] += 1
    return result

def count_protected_datablocks() -> dict:
    data_block = getattr(bpy, 'data', None)
    return {'materials': sum((1 for item in getattr(data_block, 'materials', []) if item and is_cleanup_protected(item))), 'images': sum((1 for item in getattr(data_block, 'images', []) if item and is_cleanup_protected(item))), 'node_groups': sum((1 for item in getattr(data_block, 'node_groups', []) if item and is_cleanup_protected(item)))}

def first_node_of_type(material, bl_idname: str):
    if not material or not material.use_nodes or (not material.node_tree):
        return None
    for node in material.node_tree.nodes:
        if node.bl_idname == bl_idname:
            return node
    return None

def first_principled_node(material):
    return first_node_of_type(material, 'ShaderNodeBsdfPrincipled')
PRINCIPLED_SOCKET_MAP = {'base_color': ('Base Color',), 'roughness': ('Roughness',), 'metallic': ('Metallic',), 'ior': ('IOR',), 'transmission': ('Transmission Weight', 'Transmission'), 'coat': ('Coat Weight', 'Clearcoat'), 'coat_roughness': ('Coat Roughness', 'Clearcoat Roughness'), 'subsurface': ('Subsurface Weight', 'Subsurface'), 'normal': ('Normal',), 'alpha': ('Alpha',), 'emission_color': ('Emission Color', 'Emission'), 'emission_strength': ('Emission Strength',), 'sheen': ('Sheen Weight', 'Sheen')}

def render_engine(context=None) -> str:
    try:
        context = context or bpy.context
        return str(context.scene.render.engine or '')
    except Exception:
        return ''

def node_tree_from_material_or_nt(material_or_nt):
    if material_or_nt is None:
        return None
    if hasattr(material_or_nt, 'nodes') and hasattr(material_or_nt, 'links'):
        return material_or_nt
    if getattr(material_or_nt, 'use_nodes', False) and getattr(material_or_nt, 'node_tree', None):
        return material_or_nt.node_tree
    return None

def output_nodes(material_or_nt) -> list:
    nt = node_tree_from_material_or_nt(material_or_nt)
    if nt is None:
        return []
    return [node for node in nt.nodes if node.bl_idname == 'ShaderNodeOutputMaterial']

def preferred_output_node(material_or_nt, engine: str=''):
    nt = node_tree_from_material_or_nt(material_or_nt)
    outputs = [node for node in getattr(nt, 'nodes', []) if getattr(node, 'bl_idname', '') == 'ShaderNodeOutputMaterial']
    if not outputs:
        return None
    normalized = (engine or render_engine()).upper()
    target = 'ALL'
    if normalized == 'CYCLES':
        target = 'CYCLES'
    elif normalized in {'BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT', 'EEVEE'}:
        target = 'EEVEE'

    def rank(node):
        node_target = str(getattr(node, 'target', 'ALL') or 'ALL').upper()
        active = bool(getattr(node, 'is_active_output', False))
        if node_target == target and active:
            return (0, getattr(node, 'name', ''))
        if node_target == target:
            return (1, getattr(node, 'name', ''))
        if node_target == 'ALL' and active:
            return (2, getattr(node, 'name', ''))
        if node_target == 'ALL':
            return (3, getattr(node, 'name', ''))
        if active:
            return (4, getattr(node, 'name', ''))
        return (5, getattr(node, 'name', ''))
    return sorted(outputs, key=rank)[0]

def ensure_output_node(material_or_nt, engine: str=''):
    nt = node_tree_from_material_or_nt(material_or_nt)
    if nt is None:
        return None
    out = preferred_output_node(nt, engine=engine)
    if out is not None:
        return out
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    out.location = (340, 0)
    normalized = (engine or '').upper()
    if normalized in {'CYCLES', 'EEVEE'}:
        try:
            out.target = normalized
        except Exception:
            pass
    return out

def find_output_node(material_or_nt, engine: str=''):
    nt = node_tree_from_material_or_nt(material_or_nt)
    if nt is None:
        return None
    return preferred_output_node(nt, engine=engine)

def first_node_in_tree(nt, bl_idname: str):
    if nt is None:
        return None
    for node in nt.nodes:
        if node.bl_idname == bl_idname:
            return node
    return None

def first_principled_on_output_path(material_or_nt, engine: str=''):
    nt = node_tree_from_material_or_nt(material_or_nt)
    if nt is None:
        return None
    out = preferred_output_node(nt, engine=engine)
    if out is None:
        return first_node_in_tree(nt, 'ShaderNodeBsdfPrincipled')
    surface = socket_by_name(out.inputs, 'Surface')
    if surface is None or not getattr(surface, 'is_linked', False):
        return first_node_in_tree(nt, 'ShaderNodeBsdfPrincipled')
    visited = set()

    def walk(node):
        if node is None or node in visited:
            return None
        visited.add(node)
        if node.bl_idname == 'ShaderNodeBsdfPrincipled':
            return node
        for inp in getattr(node, 'inputs', []):
            for link_ in getattr(inp, 'links', []):
                found = walk(getattr(link_, 'from_node', None))
                if found is not None:
                    return found
        return None
    try:
        from_node = surface.links[0].from_node
    except Exception:
        from_node = None
    return walk(from_node) or first_node_in_tree(nt, 'ShaderNodeBsdfPrincipled')

def connected_nodes_from_output(material_or_nt, engine: str='') -> set:
    nt = node_tree_from_material_or_nt(material_or_nt)
    if nt is None:
        return set()
    out = preferred_output_node(nt, engine=engine)
    if out is None:
        return set()
    connected = set()

    def visit(node):
        if node is None or node in connected:
            return
        connected.add(node)
        for inp in getattr(node, 'inputs', []):
            for link_ in getattr(inp, 'links', []):
                visit(getattr(link_, 'from_node', None))
    visit(out)
    return connected

def connected_nodes_from_all_outputs(material_or_nt) -> set:
    nt = node_tree_from_material_or_nt(material_or_nt)
    if nt is None:
        return set()
    outputs = output_nodes(nt)
    if not outputs:
        return set()
    connected = set()

    def visit(node):
        if node is None or node in connected:
            return
        connected.add(node)
        for inp in getattr(node, 'inputs', []):
            for link_ in getattr(inp, 'links', []):
                visit(getattr(link_, 'from_node', None))
    for out in outputs:
        visit(out)
    return connected

def auto_layout_node_tree(material_or_nt, engine: str='', x_gap: int=260, y_gap: int=170) -> int:
    nt = node_tree_from_material_or_nt(material_or_nt)
    if nt is None:
        return 0
    out = preferred_output_node(nt, engine=engine)
    if out is None:
        return 0
    # A node's column is its distance from the output side, so the graph reads left to right.
    consumers = defaultdict(set)
    nodes = [node for node in nt.nodes if node.bl_idname not in {'NodeFrame'}]
    for link_ in nt.links:
        consumers[getattr(link_, 'from_node', None)].add(getattr(link_, 'to_node', None))
    level_cache = {}

    def level(node):
        if node in level_cache:
            return level_cache[node]
        level_cache[node] = 0
        children = {child for child in consumers.get(node, set()) if child is not None}
        if children:
            level_cache[node] = 1 + max((level(child) for child in children))
        return level_cache[node]
    layers = defaultdict(list)
    for node in nodes:
        layers[level(node)].append(node)
    moved = 0
    ui_scale = float(bpy.context.preferences.system.ui_scale) or 1.0
    y_margin = 30.0
    column_x = 0.0
    for depth, layer_nodes in sorted(layers.items(), key=lambda item: item[0]):
        layer_nodes = sorted(layer_nodes, key=lambda node: (-float(node.location[1]), node.name))
        heights = [(float(node.dimensions.y) / ui_scale) or (y_gap - y_margin) for node in layer_nodes]
        top = (sum(heights) + y_margin * (len(heights) - 1)) * 0.5
        if depth:
            column_x -= max(float(x_gap), max(float(node.width) for node in layer_nodes) + 40.0)
        for node, height in zip(layer_nodes, heights):
            node.location.x = column_x
            node.location.y = top
            top -= height + y_margin
            moved += 1
    try:
        out.location = (340, 0)
    except Exception:
        pass
    return moved

def prune_unconnected_nodes(material_or_nt, engine: str='') -> int:
    nt = node_tree_from_material_or_nt(material_or_nt)
    if nt is None:
        return 0
    connected = connected_nodes_from_all_outputs(nt)
    if not connected:
        connected = connected_nodes_from_output(nt, engine=engine)
    removed = 0
    for node in list(nt.nodes):
        if node.bl_idname in {'ShaderNodeOutputMaterial', 'NodeFrame'}:
            continue
        if node not in connected:
            nt.nodes.remove(node)
            removed += 1
    for node in list(nt.nodes):
        if node.bl_idname != 'NodeFrame':
            continue
        children = [child for child in nt.nodes if getattr(child, 'parent', None) == node]
        if not children:
            nt.nodes.remove(node)
    return removed

def socket_by_name(collection, *names):
    lowered = [str(name).lower() for name in names]
    for name in names:
        try:
            return collection[name]
        except Exception:
            continue
    for socket in collection:
        sname = str(getattr(socket, 'name', '')).lower()
        if sname in lowered or any((sname.startswith(name) for name in lowered)):
            return socket
    return None

def approx_params_from_material(material) -> dict:
    params: dict = {}
    bsdf = first_principled_node(material)
    if bsdf:
        base = socket_by_name(bsdf.inputs, 'Base Color')
        metallic = socket_by_name(bsdf.inputs, 'Metallic')
        roughness = socket_by_name(bsdf.inputs, 'Roughness')
        ior = socket_by_name(bsdf.inputs, 'IOR')
        transmission = socket_by_name(bsdf.inputs, 'Transmission Weight', 'Transmission')
        subsurface = socket_by_name(bsdf.inputs, 'Subsurface Weight', 'Subsurface')
        coat = socket_by_name(bsdf.inputs, 'Coat Weight', 'Clearcoat')
        if base is not None:
            params['base_color'] = serialize_value(base.default_value)
        if metallic is not None:
            params['metallic'] = serialize_value(metallic.default_value)
        if roughness is not None:
            params['roughness'] = serialize_value(roughness.default_value)
        if ior is not None:
            params['ior'] = serialize_value(ior.default_value)
        if transmission is not None:
            params['transmission'] = serialize_value(transmission.default_value)
        if subsurface is not None:
            params['subsurface'] = serialize_value(subsurface.default_value)
        if coat is not None:
            params['coat_weight'] = serialize_value(coat.default_value)
    return params

def portable_parameter_payload(material) -> dict:
    params = get_material_params(material) or approx_params_from_material(material)
    builder = material.get('sss_builder', '') if material else ''
    payload = {'source': 'Smart Shader approximate portable mapping', 'builder': builder, 'family': material.get('sss_family', '') if material else '', 'base_color': params.get('base_color') or params.get('dry_color') or params.get('grass_color') or params.get('paint_color') or params.get('base'), 'metalness': params.get('metallic', 0.0), 'roughness': params.get('roughness', params.get('base_roughness', params.get('dry_roughness', 0.5))), 'coat_weight': params.get('clearcoat', params.get('coat_weight', 0.0)), 'coat_roughness': params.get('clearcoat_roughness', params.get('coat_roughness', 0.03)), 'ior': params.get('ior', 1.45), 'transmission': params.get('transmission', 1.0 if builder in {'GLASS_PRO', 'LIQUID_SURFACE', 'PROCEDURAL_RIPPLE'} else 0.0), 'subsurface_weight': params.get('subsurface', params.get('subsurface_weight', 0.0)), 'anisotropy': params.get('anisotropy', 0.0), 'sheen_weight': params.get('sheen', params.get('sheen_weight', 0.0)), 'emission_color': params.get('emission_color') or params.get('rim_color'), 'emission_strength': params.get('emission_strength', params.get('rim_strength', 0.0)), 'alpha': params.get('alpha', params.get('transparency', 1.0)), 'absorption_color': params.get('absorption_color'), 'absorption_density': params.get('density')}
    return payload

def node_inputs_payload(node) -> dict:
    payload: dict = {}
    for socket in getattr(node, 'inputs', []):
        try:
            if not getattr(socket, 'is_linked', False):
                payload[socket.name] = serialize_value(socket.default_value)
        except Exception:
            continue
    return payload

def node_outputs_payload(node) -> list[str]:
    names: list[str] = []
    for socket in getattr(node, 'outputs', []):
        try:
            names.append(socket.name)
        except Exception:
            continue
    return names

def image_payload(image) -> dict:
    filepath = ''
    exists = False
    usage = ''
    try:
        filepath = bpy.path.abspath(image.filepath)
        exists = Path(filepath).exists() if filepath else False
    except Exception:
        filepath = ''
    try:
        usage = str(image.get('sss_usage_hint', '') or '').strip().lower()
    except Exception:
        usage = ''
    if not usage:
        try:
            from . import textures
            usage = textures.guess_usage_from_text(filepath or image.name)
        except Exception:
            usage = ''
    return {'name': image.name, 'filepath': filepath, 'exists': exists, 'source': getattr(image, 'source', ''), 'colorspace': getattr(getattr(image, 'colorspace_settings', None), 'name', ''), 'packed': bool(getattr(image, 'packed_file', None)), 'usage': usage}

def material_manifest(material, context) -> dict:
    nodes = []
    links = []
    textures = []
    texture_usages: list[str] = []
    if material.use_nodes and material.node_tree:
        for node in material.node_tree.nodes:
            item = {'name': node.name, 'label': node.label, 'type': node.bl_idname, 'location': [float(node.location[0]), float(node.location[1])], 'mute': bool(getattr(node, 'mute', False)), 'inputs': node_inputs_payload(node), 'outputs': node_outputs_payload(node)}
            for attr in ('blend_type', 'operation', 'distribution', 'wave_type', 'bands_direction', 'projection', 'mode'):
                if hasattr(node, attr):
                    try:
                        item[attr] = getattr(node, attr)
                    except Exception:
                        pass
            if hasattr(node, 'uv_map') and getattr(node, 'uv_map', ''):
                item['uv_map'] = node.uv_map
            if hasattr(node, 'image') and node.image:
                image_info = image_payload(node.image)
                try:
                    usage_hint = str(node.get('sss_usage_hint', '') or '').strip().lower()
                except Exception:
                    usage_hint = ''
                if usage_hint:
                    image_info['usage_hint'] = usage_hint
                item['image'] = image_info
                textures.append(image_info)
                usage_value = str(image_info.get('usage') or usage_hint or '').strip().lower()
                if usage_value and usage_value != 'unknown' and (usage_value not in texture_usages):
                    texture_usages.append(usage_value)
            if node.bl_idname == 'ShaderNodeScript':
                if getattr(node, 'script', None):
                    item['script'] = node.script.name
                if getattr(node, 'filepath', ''):
                    item['filepath'] = node.filepath
            nodes.append(item)
        for link in material.node_tree.links:
            links.append({'from_node': link.from_node.name, 'from_socket': link.from_socket.name, 'to_node': link.to_node.name, 'to_socket': link.to_socket.name})
    portable = portable_parameter_payload(material)
    manifest = {'manifest_version': 3, 'addon': data.ADDON_NAME, 'addon_version': data.ADDON_VERSION, 'blender_version': safe_version_string(), 'material_name': material.name, 'smart_shader': {'builder': material.get('sss_builder', ''), 'family': material.get('sss_family', ''), 'version': material.get('sss_version', ''), 'summary_en': material.get('sss_summary_en', ''), 'summary_ja': material.get('sss_summary_ja', ''), 'params': get_material_params(material), 'tags': get_material_tags(material), 'cleanup_protected': is_cleanup_protected(material), 'cleanup_protection_reason': protection_reason(material)}, 'portable_models': {'openpbr_surface_approx': portable, 'openpbr_approx': portable, 'materialx_standard_surface_approx': portable, 'usd_preview_surface_approx': portable}, 'texture_summary': {'recognized_usages': texture_usages, 'texture_count': len(textures)}, 'render_engine': getattr(context.scene.render, 'engine', '') if context and getattr(context, 'scene', None) else '', 'asset_marked': bool(getattr(material, 'asset_data', None)), 'users': sorted(iter_scene_material_users(material)), 'use_nodes': bool(material.use_nodes), 'node_count': len(nodes), 'link_count': len(links), 'textures': textures, 'nodes': nodes, 'links': links}
    return manifest

def scene_manifest(context) -> dict:
    materials = scene_materials(context)
    objects_payload = []
    objects = getattr(getattr(context, 'scene', None), 'objects', None) or safe_data_iter('objects')
    for obj in objects:
        data_block = getattr(obj, 'data', None)
        slot_materials = []
        if data_block is not None and hasattr(data_block, 'materials'):
            for index, material in enumerate(data_block.materials):
                slot_materials.append({'slot': index, 'material': material.name if material else None})
        objects_payload.append({'name': obj.name, 'type': getattr(obj, 'type', ''), 'materials': slot_materials})
    world_payload = {'has_world': False, 'world_name': '', 'has_hdri': False, 'missing': False, 'path': '', 'status_en': 'No HDRI world', 'status_ja': _lt('HDRIワールドなし')}
    try:
        from . import environment
        world_payload = environment.world_hdri_state(context)
    except Exception:
        pass
    return {'manifest_version': 1, 'scope': 'scene', 'scene_name': getattr(getattr(context, 'scene', None), 'name', ''), 'addon': data.ADDON_NAME, 'addon_version': data.ADDON_VERSION, 'blender_version': safe_version_string(), 'materials': [material_manifest(material, context) for material in materials], 'objects': objects_payload, 'world': world_payload, 'cleanup_protection': count_protected_datablocks()}

def save_custom_preset_from_material(material, name: str):
    preset_name = clean_library_name(name)
    if not preset_name:
        raise AddonError(_lt('Custom preset name is required.', 'カスタムプリセット名が必要です。'))
    db = list_custom_presets()
    builder = material.get('sss_builder', '')
    entry = {'name': preset_name, 'builder': builder, 'family': material.get('sss_family', ''), 'params': get_material_params(material) or approx_params_from_material(material), 'description': _lt('JP: スマートシェーダーから保存されたカスタムプリセットです。対応ビルダーがある場合は再構築できます。\nEN: Custom preset saved from Smart Shader. It can be rebuilt when a matching builder exists.'), 'summary_en': material.get('sss_summary_en', ''), 'summary_ja': material.get('sss_summary_ja', ''), 'tags': get_material_tags(material), 'material_name': material.name, 'rebuildable': bool(builder and builder in data.PRESET_LIBRARY), 'portable_fallback': True, 'manifest': material_manifest(material, bpy.context)}
    replaced = False
    for index, item in enumerate(db):
        if library_name_key(item.get('name', '')) == library_name_key(preset_name):
            db[index] = entry
            replaced = True
            break
    if not replaced:
        db.append(entry)
    db.sort(key=lambda item: library_name_key(item.get('name', '')))
    safe_json_save(custom_preset_path(), db)

def find_custom_preset(name: str):
    target = library_name_key(name)
    if not target:
        return None
    for entry in list_custom_presets():
        if library_name_key(entry.get('name', '')) == target:
            return entry
    return None

def list_custom_presets() -> list[dict]:
    items = [item for item in (_sanitize_custom_preset_entry(entry) for entry in safe_json_load(custom_preset_path())) if item is not None]
    items.sort(key=lambda item: library_name_key(item.get('name', '')))
    return items

def delete_custom_preset(name: str) -> bool:
    target = library_name_key(name)
    if not target:
        return False
    db = list_custom_presets()
    kept = [entry for entry in db if library_name_key(entry.get('name', '')) != target]
    if len(kept) == len(db):
        return False
    safe_json_save(custom_preset_path(), kept)
    return True

def custom_preset_count() -> int:
    return len(list_custom_presets())

def preview_cleanup_unused_data() -> dict:
    preview = {'materials': {'removable': 0, 'protected': 0, 'skipped': 0, 'samples': []}, 'images': {'removable': 0, 'protected': 0, 'skipped': 0, 'samples': []}, 'node_groups': {'removable': 0, 'protected': 0, 'skipped': 0, 'samples': []}}
    for material in safe_data_iter('materials'):
        if not material:
            continue
        if material.users != 0 or material.use_fake_user:
            continue
        if is_cleanup_protected(material):
            preview['materials']['protected'] += 1
            continue
        preview['materials']['removable'] += 1
        if len(preview['materials']['samples']) < 5:
            preview['materials']['samples'].append(material.name)
    for image in safe_data_iter('images'):
        if not image:
            continue
        if image.users != 0 or getattr(image, 'use_fake_user', False):
            continue
        if is_cleanup_protected(image):
            preview['images']['protected'] += 1
            continue
        if getattr(image, 'is_dirty', False) or getattr(image, 'packed_file', None) or getattr(image, 'source', 'FILE') != 'FILE' or image.name in {'Render Result', 'Viewer Node'}:
            preview['images']['skipped'] += 1
            continue
        preview['images']['removable'] += 1
        if len(preview['images']['samples']) < 5:
            preview['images']['samples'].append(image.name)
    for group in safe_data_iter('node_groups'):
        if not group:
            continue
        if group.users != 0 or group.use_fake_user:
            continue
        if is_cleanup_protected(group):
            preview['node_groups']['protected'] += 1
            continue
        preview['node_groups']['removable'] += 1
        if len(preview['node_groups']['samples']) < 5:
            preview['node_groups']['samples'].append(group.name)
    return preview

def export_custom_preset_library(path: Path) -> int:
    payload = list_custom_presets()
    safe_json_save(Path(path), payload)
    return len(payload)

def _load_custom_library_payload(path: Path) -> list[dict]:
    if not Path(path).exists():
        return []
    try:
        payload = json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return []
    if isinstance(payload, dict):
        for key in ('presets', 'items', 'library'):
            value = payload.get(key)
            if isinstance(value, list):
                payload = value
                break
        else:
            if payload.get('name'):
                payload = [payload]
            else:
                return []
    if not isinstance(payload, list):
        return []
    return [item for item in payload if isinstance(item, dict)]

def _sanitize_custom_preset_entry(entry: dict) -> dict | None:
    if not isinstance(entry, dict):
        return None
    name = clean_library_name(entry.get('name', ''))
    if not name:
        return None
    clean = {'name': name, 'builder': str(entry.get('builder', '') or '').strip(), 'family': str(entry.get('family', '') or '').strip(), 'params': entry.get('params') if isinstance(entry.get('params'), dict) else {}, 'description': str(entry.get('description', '') or '').strip(), 'summary_en': str(entry.get('summary_en', '') or '').strip(), 'summary_ja': str(entry.get('summary_ja', '') or '').strip(), 'tags': [str(tag).strip() for tag in entry.get('tags') or [] if str(tag).strip()], 'material_name': str(entry.get('material_name', '') or '').strip(), 'rebuildable': bool(entry.get('rebuildable', False)), 'portable_fallback': bool(entry.get('portable_fallback', True)), 'manifest': entry.get('manifest') if isinstance(entry.get('manifest'), dict) else {}}
    return clean

def repair_custom_preset_library() -> dict:
    original = _load_custom_library_payload(custom_preset_path())
    repaired: list[dict] = []
    seen: dict[str, int] = {}
    dropped = 0
    duplicates = 0
    for entry in original:
        clean = _sanitize_custom_preset_entry(entry)
        if clean is None:
            dropped += 1
            continue
        key = library_name_key(clean['name'])
        if key in seen:
            repaired[seen[key]] = clean
            duplicates += 1
        else:
            seen[key] = len(repaired)
            repaired.append(clean)
    safe_json_save(custom_preset_path(), repaired)
    return {'before': len(original), 'after': len(repaired), 'dropped': dropped, 'duplicates': duplicates}

def import_custom_preset_library(path: Path, mode: str='MERGE') -> dict:
    incoming_raw = _load_custom_library_payload(Path(path))
    incoming = []
    skipped_invalid = 0
    for entry in incoming_raw:
        clean = _sanitize_custom_preset_entry(entry)
        if clean is None:
            skipped_invalid += 1
            continue
        incoming.append(clean)
    if mode == 'REPLACE':
        incoming.sort(key=lambda item: library_name_key(item.get('name', '')))
        safe_json_save(custom_preset_path(), incoming)
        return {'imported': len(incoming), 'replaced': 0, 'skipped_invalid': skipped_invalid, 'total': len(incoming), 'mode': 'REPLACE'}
    existing = list_custom_presets()
    merged: list[dict] = []
    seen: dict[str, int] = {}
    for entry in existing:
        clean = _sanitize_custom_preset_entry(entry)
        if clean is None:
            continue
        key = library_name_key(clean['name'])
        seen[key] = len(merged)
        merged.append(clean)
    replaced = 0
    imported = 0
    for entry in incoming:
        key = library_name_key(entry['name'])
        if key in seen:
            merged[seen[key]] = entry
            replaced += 1
        else:
            seen[key] = len(merged)
            merged.append(entry)
            imported += 1
    merged.sort(key=lambda item: library_name_key(item.get('name', '')))
    safe_json_save(custom_preset_path(), merged)
    return {'imported': imported, 'replaced': replaced, 'skipped_invalid': skipped_invalid, 'total': len(merged), 'mode': 'MERGE'}

def scoped_materials_for_textures(context) -> list:
    scene = context.scene
    scope = getattr(scene, 'sss_texture_scope', 'ACTIVE')
    if scope == 'TARGET':
        mat = get_target_material(context)
        return [mat] if mat else []
    if scope == 'SCENE':
        return [mat for mat in safe_data_iter('materials') if mat]
    mat = active_material(context)
    return [mat] if mat else []
_UDIM_TAG_RE = re.compile('(?i)([._-]?<udim>)')
_UDIM_NUMBER_RE = re.compile('(?i)([._-]?)(1\\d{3})$')
_UV_TILE_RE = re.compile('(?i)([._-]?u\\d+_v\\d+)$')

def normalize_texture_token(token: str) -> str:
    token = (token or '').strip().lower()
    if not token:
        return ''
    token = _UDIM_TAG_RE.sub('', token)
    token = _UV_TILE_RE.sub('', token)
    token = _UDIM_NUMBER_RE.sub('', token)
    return token.rstrip('._-')

def texture_lookup_keys(value: str) -> list[str]:
    value = (value or '').strip()
    if not value:
        return []
    path = Path(value)
    name = path.name.lower()
    stem = path.stem.lower()
    suffix = path.suffix.lower()
    keys: list[str] = []
    for candidate in (name, stem, normalize_texture_token(name), normalize_texture_token(stem)):
        candidate = (candidate or '').strip().lower()
        if candidate and candidate not in keys:
            keys.append(candidate)
    normalized_stem = normalize_texture_token(stem)
    if normalized_stem and suffix:
        combined = f'{normalized_stem}{suffix}'
        if combined not in keys:
            keys.append(combined)
    return keys

def index_files_by_name(root: Path) -> dict[str, list[Path]]:
    table: dict[str, list[Path]] = {}
    if not root.exists():
        return table
    for file_path in root.rglob('*'):
        if not file_path.is_file():
            continue
        if file_path.suffix.lower() not in TEXTURE_EXTENSIONS:
            continue
        for key in texture_lookup_keys(file_path.name) + texture_lookup_keys(file_path.stem):
            table.setdefault(key, [])
            if file_path not in table[key]:
                table[key].append(file_path)
    return table

def best_texture_match(candidates: list[Path], missing_path: str='', image_name: str='') -> Path | None:
    if not candidates:
        return None
    # bpy.path.basename: pathlib reads "//dir/x.png" as a Windows UNC share with no name.
    missing_name = bpy.path.basename(missing_path) if missing_path else ''
    desired_suffix = Path(missing_name).suffix.lower()
    desired_name = missing_name.lower() if missing_path else image_name.lower()

    def sort_key(path: Path):
        name = path.name.lower()
        exact_score = 0 if desired_name and name == desired_name else 1
        suffix_score = 0 if desired_suffix and path.suffix.lower() == desired_suffix else 1
        return (exact_score, suffix_score, len(str(path)), str(path))
    return sorted(candidates, key=sort_key)[0]

def create_or_replace_text_block(name: str, body: str):
    txt = bpy.data.texts.get(name)
    if txt is None:
        txt = bpy.data.texts.new(name)
    txt.clear()
    txt.write(body)
    return txt

def scene_materials(context=None) -> list:
    materials = []
    seen = set()
    if context and getattr(context, 'scene', None):
        objects = getattr(context.scene, 'objects', None) or safe_data_iter('objects')
    else:
        objects = safe_data_iter('objects')
    for obj in objects:
        data_block = getattr(obj, 'data', None)
        if not data_block or not hasattr(data_block, 'materials'):
            continue
        for material in data_block.materials:
            if material is None:
                continue
            if material.name in seen:
                continue
            seen.add(material.name)
            materials.append(material)
    return materials

def cleanup_material_slots(objects) -> dict:
    processed = 0
    removed_slots = 0
    remapped_faces = 0
    for obj in objects:
        if getattr(obj, 'type', '') != 'MESH':
            continue
        data_block = getattr(obj, 'data', None)
        materials = getattr(data_block, 'materials', None)
        polygons = getattr(data_block, 'polygons', None)
        if materials is None:
            continue
        slots = list(materials)
        if not slots:
            continue
        used = set()
        if polygons is not None:
            for poly in polygons:
                try:
                    used.add(int(poly.material_index))
                except Exception:
                    continue
        kept = []
        index_map = {}
        for old_index, material in enumerate(slots):
            keep = material is not None and (not used or old_index in used)
            if keep:
                index_map[old_index] = len(kept)
                kept.append(material)
        if not kept:
            first = next((mat for mat in slots if mat is not None), None)
            if first is not None:
                kept = [first]
                index_map = {0: 0}
        for old_index in range(len(slots)):
            index_map.setdefault(old_index, 0 if kept else old_index)
        if polygons is not None and kept:
            for poly in polygons:
                try:
                    old_index = int(poly.material_index)
                    new_index = index_map.get(old_index, 0)
                    if new_index != old_index:
                        poly.material_index = new_index
                        remapped_faces += 1
                except Exception:
                    continue
        try:
            materials.clear()
        except Exception:
            while len(materials) > 0:
                materials.pop(index=len(materials) - 1)
        for material in kept:
            materials.append(material)
        removed_slots += max(0, len(slots) - len(kept))
        processed += 1
    return {'objects': processed, 'removed_slots': removed_slots, 'remapped_faces': remapped_faces}

def create_osl_text_block():
    text_name = 'SSS_Ripple_Hologram_OSL'
    body = 'shader sss_ripple_hologram(\n    color Tint = color(0.10, 0.90, 1.00),\n    float StripeScale = 32.0,\n    float StripeStrength = 0.5,\n    output closure color BSDF = emission())\n{\n    float stripes = 0.5 + 0.5 * sin(P[2] * StripeScale);\n    color c = Tint * mix(1.0, stripes, StripeStrength);\n    BSDF = emission() * c;\n}\n'
    return create_or_replace_text_block(text_name, body)

def manifest_text_block_name(material_name: str) -> str:
    safe_name = material_name.replace(' ', '_')
    return f'SSS_Manifest_{safe_name}'

def write_manifest_text_block(material_name: str, manifest: dict):
    body = json.dumps(manifest, indent=2, ensure_ascii=False)
    return create_or_replace_text_block(manifest_text_block_name(material_name), body)

def iter_scene_material_users(material) -> Iterable[str]:
    key = _material_runtime_key(material)
    if not key:
        return iter(())
    try:
        object_count = len(safe_data_collection('objects') or [])
    except Exception:
        object_count = 0
    cache_key = (key, object_count)
    now = time.monotonic()
    cached = _MATERIAL_USAGE_USERS_CACHE.get(cache_key)
    if cached is not None and now - cached[0] < 0.75:
        return iter(cached[1])
    names: list[str] = []
    for obj in safe_data_iter('objects'):
        data_block = getattr(obj, 'data', None)
        if not data_block or not hasattr(data_block, 'materials'):
            continue
        for slot_mat in data_block.materials:
            if slot_mat == material:
                names.append(obj.name)
                break
    payload = tuple(names)
    _MATERIAL_USAGE_USERS_CACHE[cache_key] = (now, payload)
    if len(_MATERIAL_USAGE_USERS_CACHE) > 256:
        for old_key in list(_MATERIAL_USAGE_USERS_CACHE.keys())[:64]:
            _MATERIAL_USAGE_USERS_CACHE.pop(old_key, None)
    return iter(payload)

def _material_runtime_key(material) -> int:
    if material is None:
        return 0
    try:
        pointer = int(material.as_pointer())
        if pointer:
            return pointer
    except Exception:
        pass
    return id(material)


def material_usage_map(objects=None) -> dict[int, dict]:
    objects = list(objects or safe_data_iter('objects'))
    usage: dict[int, dict] = {}
    for obj in objects:
        materials = _object_material_collection(obj)
        if materials is None:
            continue
        object_hits: set[int] = set()
        for slot_mat in materials:
            key = _material_runtime_key(slot_mat)
            if not key:
                continue
            bucket = usage.setdefault(key, {'objects': 0, 'slots': 0})
            bucket['slots'] += 1
            object_hits.add(key)
        for key in object_hits:
            usage[key]['objects'] += 1
    return usage


def material_usage_counts(material, objects=None, usage_map=None) -> dict:
    """Return how often a material is assigned across objects and slots."""
    key = _material_runtime_key(material)
    if key and isinstance(usage_map, dict):
        bucket = dict(usage_map.get(key) or {})
        return {'objects': int(bucket.get('objects', 0) or 0), 'slots': int(bucket.get('slots', 0) or 0)}
    objects = list(objects or safe_data_iter('objects'))
    object_count = 0
    slot_count = 0
    for obj in objects:
        materials = _object_material_collection(obj)
        if materials is None:
            continue
        hit = False
        for slot_mat in materials:
            if slot_mat == material:
                slot_count += 1
                hit = True
        if hit:
            object_count += 1
    return {'objects': object_count, 'slots': slot_count}


def material_texture_usages(material) -> dict[str, int]:
    return dict(material_node_audit(material).get('texture_usages') or {})


def material_compare_payload(material, objects=None, usage=None, usage_map=None) -> dict:
    if material is None:
        return {}
    params = get_material_params(material)
    tags = get_material_tags(material)
    node_audit = material_node_audit(material)
    usage = material_usage_counts(material, objects=objects, usage_map=usage_map) if usage is None else dict(usage or {})
    manifest_text = ''
    try:
        texts = safe_data_collection('texts')
        if texts is not None and hasattr(texts, 'get'):
            block = texts.get(manifest_text_block_name(material.name))
            if block is not None:
                manifest_text = str(getattr(block, 'as_string', lambda: '')())
    except Exception:
        manifest_text = ''
    return {'name': getattr(material, 'name', ''), 'builder': str(material.get('sss_builder', '') or ''), 'family': str(material.get('sss_family', '') or ''), 'summary_en': str(material.get('sss_summary_en', '') or ''), 'summary_ja': str(material.get('sss_summary_ja', '') or ''), 'params': params, 'tags': tags, 'managed': bool(material.get('sss_builder')), 'protected': is_cleanup_protected(material), 'asset': bool(getattr(material, 'asset_data', None)), 'use_fake_user': bool(getattr(material, 'use_fake_user', False)), 'users': int(getattr(material, 'users', 0) or 0), 'node_count': int(node_audit.get('node_count', 0) or 0), 'missing_textures': int(node_audit.get('missing_textures', 0) or 0), 'texture_usages': dict(node_audit.get('texture_usages') or {}), 'usage_objects': int(usage.get('objects', 0) or 0), 'usage_slots': int(usage.get('slots', 0) or 0), 'output_type': str(node_audit.get('output_type', '') or ''), 'has_manifest_text': bool(manifest_text)}

def compare_materials(source_material, target_material, objects=None) -> dict:
    source = material_compare_payload(source_material, objects=objects)
    target = material_compare_payload(target_material, objects=objects)
    if not source or not target:
        return {'same_material': False, 'missing': True, 'source': source, 'target': target, 'differences': []}
    differences: list[dict] = []

    def _append(key: str, source_value, target_value, label_en: str, label_ja: str):
        if source_value == target_value:
            return
        differences.append({'key': key, 'source': source_value, 'target': target_value, 'label_en': label_en, 'label_ja': label_ja})
    _append('builder', source.get('builder'), target.get('builder'), 'Builder', _lt('ビルダー'))
    _append('family', source.get('family'), target.get('family'), 'Family', _lt('分類'))
    _append('params', source.get('params'), target.get('params'), 'Stored parameters', _lt('保存パラメータ'))
    _append('tags', source.get('tags'), target.get('tags'), 'Tags', _lt('タグ'))
    _append('texture_usages', source.get('texture_usages'), target.get('texture_usages'), 'Texture usages', _lt('テクスチャ用途'))
    _append('missing_textures', source.get('missing_textures'), target.get('missing_textures'), 'Missing textures', _lt('欠損テクスチャ'))
    _append('node_count', source.get('node_count'), target.get('node_count'), 'Node count', _lt('ノード数'))
    _append('output_type', source.get('output_type'), target.get('output_type'), 'Output type', _lt('出力種類'))
    _append('protected', source.get('protected'), target.get('protected'), 'Cleanup protection', _lt('保護状態'))
    _append('asset', source.get('asset'), target.get('asset'), 'Asset mark', _lt('アセット化'))
    _append('use_fake_user', source.get('use_fake_user'), target.get('use_fake_user'), 'Fake User', _lt('保持'))
    return {'same_material': source_material == target_material, 'missing': False, 'same_builder': source.get('builder') == target.get('builder'), 'same_family': source.get('family') == target.get('family'), 'same_params': source.get('params') == target.get('params'), 'same_tags': source.get('tags') == target.get('tags'), 'source': source, 'target': target, 'differences': differences}

def replace_material_in_scope(old_material, new_material, scope: str='SCENE', objects=None, cleanup_slots: bool=True) -> dict:
    scope = str(scope or 'SCENE').upper()
    if scope == 'SELECTED':
        objects = list(objects or [])
    else:
        objects = list(objects or safe_data_iter('objects'))
    affected_objects = []
    for obj in objects:
        materials = _object_material_collection(obj)
        if materials is None:
            continue
        if any((slot_mat == old_material for slot_mat in materials)):
            affected_objects.append(obj)
    changed_slots = replace_material_references(old_material, new_material, objects=affected_objects)
    cleanup = {'objects': 0, 'removed_slots': 0, 'remapped_faces': 0}
    if cleanup_slots and affected_objects:
        cleanup = cleanup_material_slots(affected_objects)
    return {'scope': scope, 'changed_slots': changed_slots, 'cleanup_objects': cleanup.get('objects', 0), 'removed_slots': cleanup.get('removed_slots', 0), 'remapped_faces': cleanup.get('remapped_faces', 0), 'objects_in_scope': len(objects), 'affected_objects': len(affected_objects)}

def _smart_shader_manifest_extension_id(default: str='') -> str:
    default = str(default or '').strip()
    try:
        current = Path(__file__).resolve().parent
        while True:
            manifest = current / 'blender_manifest.toml'
            if manifest.is_file():
                for raw_line in manifest.read_text(encoding='utf-8').splitlines():
                    line = raw_line.strip()
                    if not line.startswith('id'):
                        continue
                    _, _, value = line.partition('=')
                    value = str(value or '').strip().strip('"').strip("'")
                    if value:
                        return value
                break
            if current.parent == current:
                break
            current = current.parent
    except Exception:
        pass
    if '.user_default.' in default or default.startswith('bl_ext.'):
        default = default.rsplit('.', 1)[-1]
    if '.' in default:
        head = default.split('.', 1)[0].strip()
        if head:
            default = head
    return default


def _smart_shader_version_user_default_root(package_id: str, create: bool=False) -> Path:
    return storage.extension_user_root(_smart_shader_manifest_extension_id(package_id), create=create)
def _smart_shader_extension_candidates() -> tuple[str, ...]:
    values = []
    try:
        values.extend(list(extension_package_id_candidates()))
    except Exception:
        pass
    values.append(data.ADDON_ID)
    out = []
    for value in values:
        value = _smart_shader_manifest_extension_id(value)
        if value and value not in out:
            out.append(value)
    return tuple(out) or (_smart_shader_manifest_extension_id(data.ADDON_ID),)

def _smart_shader_extension_user_root(create: bool=False) -> Path:
    for package_id in _smart_shader_extension_candidates():
        path = _smart_shader_version_user_default_root(package_id, create=create)
        if path:
            return path
    return _smart_shader_version_user_default_root(data.ADDON_ID, create=create)
extension_user_root = lambda create=False: storage.extension_user_root(create=create)

def _smart_shader_manifest_dir() -> Path:
    try:
        current = Path(__file__).resolve().parent
        while True:
            if (current / 'blender_manifest.toml').is_file():
                return current
            if current.parent == current:
                break
            current = current.parent
    except Exception:
        pass
    return Path(__file__).resolve().parent

def _smart_shader_has_visible_entries(path: Path) -> bool:
    try:
        return any((item.name not in {'.DS_Store', 'Thumbs.db'} for item in path.iterdir()))
    except Exception:
        return False

def _smart_shader_merge_tree(src: Path, dst: Path) -> None:
    import shutil
    dst.mkdir(parents=True, exist_ok=True)
    for item in src.iterdir():
        if item.name in {'.DS_Store', 'Thumbs.db'}:
            continue
        target = dst / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        elif item.is_file() and (not target.exists()):
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)


def _smart_shader_version_user_default_root(package_id: str, create: bool=False) -> Path:
    return storage.extension_user_root(_smart_shader_manifest_extension_id(package_id), create=create)
