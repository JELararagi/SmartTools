# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

import json
import re
import sys
from pathlib import Path

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, StringProperty

from .translation import loc_text as _lt
from .translation import exc_text as _exc_text

try:
    from . import storage as _sss_storage
except Exception:  # pragma: no cover - defensive fallback outside package import.
    _sss_storage = None

PACKAGE_ID = 'smart_shader_suite'
ADDON_NAME = 'Smart_Shader_Suite'
TOOL_LABEL_EN = 'Smart Shader'
TOOL_LABEL_JA = 'Smart Shader'
PANEL_CATEGORY = TOOL_LABEL_EN
_ALWAYS_ON_PROP = PACKAGE_ID + '_always_on_enabled'
_STORAGE_DIRNAME = 'user_data'

_PREVIEW_COLLECTION = None
_ICON_RENAME_ALIASES = {
    'quality_upgrade': 'quality_upgrade',
    'pbr_import_set': 'pbr_import_set',
    'smart_material_create': 'smart_material_create',
    'smart_weathering': 'smart_weathering',
    'material_capsule_save': 'material_capsule_save',
    'material_capsule_restore': 'material_capsule_restore',
    'supreme_finish': 'supreme_finish',
    'node_layout_auto': 'node_layout_auto',
    'bridge_transfer': 'bridge_transfer',
    'photo_to_pbr': 'photo_to_pbr',
    'toon_shader_create': 'toon_shader_create',
    'npr_polish': 'npr_polish',
    'precision_upgrade': 'precision_upgrade',
}

_REGISTERED_CLASSES = []
_PATCHED_PANELS = []
_PATCHED_PREFERENCES = []
_PATCHED_POLLS = []
_ORIGINAL_REGISTER_CLASS = None
_REGISTER_PATCH_DEPTH = 0
_AUTOSAVE_FINGERPRINT = ''
_LOADED_SETTINGS = {}

_TRANSLATIONS = {
    ('*', 'Help'): 'ヘルプ',
    ('*', 'Open Help'): 'ヘルプを開く',
    ('*', 'Feature Overview'): '機能概要',
    ('*', 'Usage'): '使用方法',
    ('*', 'Settings'): '設定項目',
    ('*', 'Commands'): 'コマンド',
    ('*', 'Resident Toggle'): '常時機能切り替え',
    ('*', 'Enabled'): '有効',
    ('*', 'Disabled'): '無効',
    ('*', 'Save Preferences'): 'プリファレンスを保存',
    ('*', 'Settings are managed in the N-panel.'): '設定はNパネルで管理します。',
    ('*', 'Open the 3D View Sidebar and use this tool tab.'): '3Dビューのサイドバーを開き、このツールのタブを使用してください。',
    ('*', TOOL_LABEL_EN): TOOL_LABEL_JA,
    # Localization pass 2026-08-19: catalog gaps found by ast inventory.
    ('*', 'Open the detailed help popup for this tool group.'): 'このツールグループの詳細ヘルプポップアップを開きます。',
    ('*', 'Set a resident feature to enabled or disabled and save the N-panel setting immediately.'): '常時機能の有効/無効を切り替え、Nパネル設定を直ちに保存します。',
    ('*', 'Save current N-panel settings to the package-local Smart_Shader_Suite storage folder and request Blender to save user preferences.'): '現在のNパネル設定をパッケージ用のSmart_Shader_Suite保存フォルダへ保存し、Blenderへユーザープリファレンスの保存を要求します。',
    ('*', 'Resident'): '常時機能',
    ('*', 'Saved resident switch for this tool. Enable it only when you want persistent helper behavior; disable it for ordinary manual use.'): 'このツールの保存済み常時機能スイッチです。補助動作を常時有効にしたいときのみオンにし、通常の手動使用ではオフにしてください。',
    ('*', 'Saved resident switch for this tool. Enable it only when persistent helper behavior is required.'): 'このツールの保存済み常時機能スイッチです。補助動作の常時有効化が必要な場合のみオンにしてください。',
}


def _ui_is_japanese(context=None):
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja')
    except Exception:
        return False


def text(en, ja=None, context=None):
    return str(ja if (ja is not None and _ui_is_japanese(context)) else en)


def package_root():
    return Path(__file__).resolve().parent


def storage_root(create=True):
    # Generated common runtime files must stay in Blender's user-writable
    # config/Smart_Shader_Suite folder. The installed package directory is never
    # used as a fallback because extension repositories may be read-only.
    root = None
    if _sss_storage is not None:
        try:
            root = _sss_storage.extension_user_root(PACKAGE_ID, create=bool(create)) / _STORAGE_DIRNAME
        except Exception:
            root = None
    if root is None:
        try:
            import bpy as _bpy  # type: ignore
            value = _bpy.utils.user_resource('CONFIG', path=f'{ADDON_NAME}/{_STORAGE_DIRNAME}', create=bool(create))
            root = Path(value) if value else None
        except Exception:
            root = None
    if root is None:
        root = Path.home() / ADDON_NAME / _STORAGE_DIRNAME
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


def storage_path(*parts, create_parent=True):
    clean_parts = []
    for part in parts:
        value = str(part or '').replace('\\', '/').strip('/')
        if not value or value in {'.', '..'}:
            continue
        for piece in value.split('/'):
            if piece and piece not in {'.', '..'}:
                clean_parts.append(piece)
    path = storage_root(True).joinpath(*clean_parts)
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def settings_path():
    try:
        return _sss_storage.suite_settings_path(create=True) if _sss_storage is not None else storage_path('settings', 'Smart_Shader_Suite.json')
    except Exception:
        return storage_path('settings', 'Smart_Shader_Suite.json')


def _load_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is not None:
        return _PREVIEW_COLLECTION
    try:
        import bpy.utils.previews
        pcoll = bpy.utils.previews.new()
        loaded = set()
        for icons_dir in (package_root() / 'icons', package_root() / 'icon'):
            if not icons_dir.exists() or not icons_dir.is_dir():
                continue
            for path in sorted(icons_dir.glob('*.png')):
                key = path.stem
                if key in loaded:
                    continue
                try:
                    pcoll.load(key, str(path), 'IMAGE')
                    loaded.add(key)
                except Exception:
                    pass
        _PREVIEW_COLLECTION = pcoll
    except Exception:
        _PREVIEW_COLLECTION = None
    return _PREVIEW_COLLECTION


def _icon_candidates(name):
    key = str(name or '').strip()
    candidates = []
    for item in (key, _ICON_RENAME_ALIASES.get(key)):
        if item and item not in candidates:
            candidates.append(item)
    return candidates


def icon_value(name, fallback=0):
    # Do not recreate preview collections while a panel is being drawn.  Missing
    # custom previews fall back until the add-on is re-registered.
    pcoll = _load_previews()
    for key in _icon_candidates(name):
        try:
            item = pcoll.get(key) if pcoll is not None else None
            icon_id = int(getattr(item, 'icon_id', 0) or 0)
            if icon_id:
                return icon_id
        except Exception:
            pass
    return fallback


def _remove_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is None:
        return
    try:
        import bpy.utils.previews
        bpy.utils.previews.remove(_PREVIEW_COLLECTION)
    except Exception:
        pass
    _PREVIEW_COLLECTION = None


def _translation_payload():
    data = dict(_TRANSLATIONS)
    try:
        from . import language_extra
        extra = getattr(language_extra, 'EXTRA_TRANSLATIONS', {})
        if isinstance(extra, dict):
            data.update(extra)
    except Exception:
        pass
    return {'ja_JP': data}


def _wrap_lines(value, width_px):
    import textwrap
    text_value = str(value or '').replace('\r\n', '\n').replace('\r', '\n')
    # Approximate Blender UI label width.  This wraps only when the line would
    # exceed the popup width rather than at a fixed text width.
    chars = max(26, min(160, int(max(260, width_px) / 7)))
    lines = []
    for para in text_value.split('\n'):
        raw = para.strip()
        if not raw:
            lines.append('')
            continue
        wrapped = textwrap.wrap(raw, width=chars, break_long_words=False, break_on_hyphens=False)
        lines.extend(wrapped or [raw])
    return lines


def _draw_wrapped(layout, context, value, icon='NONE'):
    try:
        width = int(getattr(getattr(context, 'region', None), 'width', 620) or 620)
    except Exception:
        width = 620
    first = True
    for line in _wrap_lines(value, width):
        if not line:
            layout.separator(factor=0.35)
        elif first and icon != 'NONE':
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)
            first = False


def _group_text_list(group, key_en, key_ja, context=None):
    values = group.get(key_ja if _ui_is_japanese(context) else key_en) or []
    if isinstance(values, str):
        return [values]
    if isinstance(values, (list, tuple)):
        return [str(v) for v in values]
    return []


class SMART_SHADER_OT_open_help(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = PACKAGE_ID + '.open_help'
    bl_label = _lt('Open Help', 'ヘルプを開く')
    bl_description = 'Open the detailed help popup for this tool group.'
    bl_options = set()

    topic: StringProperty(default='overview', options={'SKIP_SAVE'})

    def invoke(self, context, event):
        try:
            return context.window_manager.invoke_popup(self, width=680)
        except Exception:
            return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        topic = str(getattr(self, 'topic', '') or 'overview')
        try:
            from . import help as _help_runtime
            _help_runtime.draw_help(layout, context, topic, popup_width=680)
            return
        except Exception as exc:
            box = layout.box()
            box.label(text=text('Open Help', 'ヘルプを開く', context), icon='ERROR')
            _draw_wrapped(box, context, text(
                'The help catalog could not be loaded.',
                'ヘルプカタログを読み込めませんでした。',
                context,
            ))


class SMART_SHADER_OT_toggle_always_on(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.set_always_on'
    bl_label = _lt('Toggle Resident Feature', '常時機能を切り替え')
    bl_description = 'Set a resident feature to enabled or disabled and save the N-panel setting immediately.'
    bl_options = set()

    alias: StringProperty(default='', options={'SKIP_SAVE'})
    feature_key: StringProperty(default='', options={'SKIP_SAVE'})
    enabled: BoolProperty(default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        done = False
        alias = str(getattr(self, 'alias', '') or '')
        feature_key = str(getattr(self, 'feature_key', '') or '')
        if alias and feature_key:
            try:
                from . import feature_toggle
                setter = getattr(feature_toggle, 'set_feature_enabled', None)
                if callable(setter):
                    done = bool(setter(alias, feature_key, bool(self.enabled)))
            except Exception as exc:
                self.report({'WARNING'}, _exc_text(exc))
        if not done:
            try:
                setattr(context.window_manager, _ALWAYS_ON_PROP, bool(self.enabled))
                done = True
            except Exception as exc:
                self.report({'WARNING'}, _exc_text(exc))
        try:
            save_persistent_settings(context, force=True)
        except Exception:
            pass
        return {'FINISHED'}


class SMART_SHADER_OT_save_preferences(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.save_preferences'
    bl_label = _lt('Save Preferences', 'プリファレンスを保存')
    bl_description = 'Save current N-panel settings to the package-local Smart_Shader_Suite storage folder and request Blender to save user preferences.'
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        try:
            from . import preferences as _preferences
            saver = getattr(_preferences, 'save_all_npanel_settings', None)
            if callable(saver):
                saver(context)
            else:
                save_persistent_settings(context, force=True)
        except Exception:
            save_persistent_settings(context, force=True)
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        self.report({'INFO'}, text('Preferences saved.', 'プリファレンスを保存しました。', context))
        return {'FINISHED'}



def _feature_entries():
    try:
        from . import feature_toggle
        entries_fn = getattr(feature_toggle, 'feature_entries', None)
        aliases_fn = getattr(feature_toggle, 'all_feature_aliases', None)
        if callable(entries_fn):
            aliases = list(aliases_fn()) if callable(aliases_fn) else []
            if aliases:
                out = []
                for alias in aliases:
                    try:
                        out.extend(list(entries_fn(alias)))
                    except Exception:
                        pass
                return out
            return list(entries_fn())
    except Exception:
        pass
    return []


def _entry_text(entry, key_en, key_ja, fallback='', context=None):
    if _ui_is_japanese(context):
        value = entry.get(key_ja) or entry.get(key_en) or fallback
    else:
        value = entry.get(key_en) or entry.get(key_ja) or fallback
    return str(value or '').strip()


def draw_always_on_panel(layout, context):
    col = layout.column(align=True)
    entries = _feature_entries()
    if entries:
        for item in entries:
            alias = str(item.get('alias') or '')
            feature_key = str(item.get('key') or item.get('feature_key') or '')
            label = _entry_text(item, 'label_en', 'label_ja', feature_key or TOOL_LABEL_EN, context)
            enabled = bool(item.get('enabled'))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = True
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = False
        return
    enabled = bool(getattr(context.window_manager, _ALWAYS_ON_PROP, False))
    row = col.row(align=True)
    row.label(text=TOOL_LABEL_EN)
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
    op.enabled = True
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
    op.enabled = False


def _module_prefix():
    package = str(__package__ or '').strip()
    return package or PACKAGE_ID


def _same_package_class(cls):
    module_name = str(getattr(cls, '__module__', '') or '')
    prefix = _module_prefix()
    return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))


def _clean_label(label):
    raw = str(label or '').strip()
    if not raw:
        return raw
    for token in (' Suite', '_Suite', ' Toolset', ' ツールセット', 'ツールセット'):
        raw = raw.replace(token, '')
    if raw == ADDON_NAME or raw.replace('_', ' ') == ADDON_NAME.replace('_', ' '):
        return TOOL_LABEL_EN
    return raw


def _old_generated_name(name):
    text_value = str(name or '')
    upper = text_value.upper()
    return (
        '_SUITE_OT_OPEN_HELP' in upper or
        '_SUITE_OT_SET_ALWAYS_ON' in upper or
        '_SUITE_PT_ROOT' in upper or
        '_SUITE_PT_ALWAYS_ON' in upper
    )


def _materialize_annotations(cls):
    if not isinstance(cls, type):
        return cls
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
    except Exception:
        annotations = {}
    module = sys.modules.get(str(getattr(cls, '__module__', '') or ''))
    namespace = {}
    if module is not None:
        try:
            namespace.update(getattr(module, '__dict__', {}) or {})
        except Exception:
            pass
    namespace.setdefault('bpy', bpy)
    prop_names = (
        'BoolProperty', 'BoolVectorProperty', 'CollectionProperty', 'EnumProperty',
        'FloatProperty', 'FloatVectorProperty', 'IntProperty', 'IntVectorProperty',
        'PointerProperty', 'StringProperty',
    )
    for prop_name in prop_names:
        try:
            namespace[prop_name] = getattr(bpy.props, prop_name)
        except Exception:
            pass
    changed = False
    for name, value in list(annotations.items()):
        if isinstance(value, str) and 'Property' in value and '(' in value:
            expr = value.strip().replace('bpy.props.', '')
            try:
                annotations[name] = eval(expr, namespace, namespace)
                changed = True
            except Exception:
                pass
    try:
        is_operator = issubclass(cls, bpy.types.Operator)
    except Exception:
        is_operator = False
    if is_operator:
        try:
            options = set(getattr(cls, 'bl_options', set()) or set())
            if bool(getattr(cls, '_sms_no_undo', False)):
                options.discard('UNDO')
                options.discard('UNDO_GROUPED')
                setattr(cls, 'bl_options', options)
        except Exception:
            pass
        # Blender UI code frequently assigns these operator properties from
        # buttons. If a legacy class forgot to declare them, adding harmless
        # saved-skipped string properties prevents "property not found" warnings.
        for prop_name in ('mode', 'action', 'topic'):
            if prop_name not in annotations:
                try:
                    annotations[prop_name] = bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
                    changed = True
                except Exception:
                    pass
    if changed:
        try:
            setattr(cls, '__annotations__', annotations)
        except Exception:
            pass
    return cls


def _safe_unregister_class(cls):
    try:
        bpy.utils.unregister_class(cls)
        return True
    except Exception:
        return False


def _flatten_npanel_parent_before_register(cls):
    """Keep all SmartTools N-panel sections horizontally aligned.

    Blender indents Panel classes that use ``bl_parent_id``.  In a deep or
    lazily loaded SmartTools UI this compounds every time a child/grandchild
    section is exposed.  Flatten only sidebar (``bl_region_type == 'UI'``)
    panels before registration; non-sidebar panels keep their native parents.
    """
    try:
        if isinstance(cls, type) and issubclass(cls, bpy.types.Panel):
            if str(getattr(cls, 'bl_region_type', '') or '') == 'UI':
                if str(getattr(cls, 'bl_parent_id', '') or ''):
                    cls.bl_parent_id = ''
    except Exception:
        pass
    return cls


def _register_class_wrapper(cls):
    raise RuntimeError('Global register_class interception is disabled')


def begin_register():
    return None


def end_register():
    return None


def _iter_relevant_panels():
    return ()


def _is_always_panel(cls):
    value = ' '.join((
        str(getattr(cls, '__name__', '') or ''),
        str(getattr(cls, 'bl_idname', '') or ''),
        str(getattr(cls, 'bl_label', '') or ''),
    )).lower()
    return ('always' in value or '常時' in value or 'persistent' in value) and 'catalog' not in value


def _patch_panel_headers():
    """Normalize Smart Shader panel metadata without installing draw_header hooks.

    Blender 5.1 can crash inside panel_draw_header when an add-on or manager
    injects dynamic Python draw_header callbacks into many N-panel classes during
    extension reloads.  Keep category/label cleanup, but leave panel headers to
    Blender's native C/RNA drawing path.
    """
    for cls in _iter_relevant_panels():
        try:
            cls.bl_category = PANEL_CATEGORY
        except Exception:
            pass
        try:
            label = str(getattr(cls, 'bl_label', '') or '')
            clean = _clean_label(label)
            if clean and clean != label:
                cls.bl_label = clean
        except Exception:
            pass
        if _is_always_panel(cls):
            try:
                original_poll = getattr(cls, 'poll', None)
                cls.poll = classmethod(lambda _cls, context: False)
                _PATCHED_POLLS.append((cls, original_poll))
            except Exception:
                pass
            continue
        # Remove only draw_header callbacks that were injected by previous
        # Smart Shader common builds.  Do not add a replacement callback.
        try:
            if getattr(cls, '_smart_common_header_patched', False):
                if hasattr(cls, 'draw_header'):
                    delattr(cls, 'draw_header')
                delattr(cls, '_smart_common_header_patched')
        except Exception:
            pass

def _unpatch_panel_headers():
    for cls, original in reversed(_PATCHED_PANELS):
        try:
            if original is None:
                if hasattr(cls, 'draw_header'):
                    delattr(cls, 'draw_header')
            else:
                cls.draw_header = original
            if hasattr(cls, '_smart_common_header_patched'):
                delattr(cls, '_smart_common_header_patched')
        except Exception:
            pass
    _PATCHED_PANELS.clear()
    for cls, original in reversed(_PATCHED_POLLS):
        try:
            if original is None:
                if hasattr(cls, 'poll'):
                    delattr(cls, 'poll')
            else:
                cls.poll = original
        except Exception:
            pass
    _PATCHED_POLLS.clear()


def _iter_relevant_addon_preferences():
    return ()


def _patch_addon_preferences():
    for cls in _iter_relevant_addon_preferences():
        if getattr(cls, '_smart_common_preferences_patched', False):
            continue
        original = getattr(cls, 'draw', None)

        def _draw_npanel_only(self, context):
            try:
                box = self.layout.box()
                box.label(text=text('Settings are managed in the N-panel.', '設定はNパネルで管理します。', context), icon='PREFERENCES')
                box.label(text=text('Open the 3D View Sidebar and use this tool tab.', '3Dビューのサイドバーを開き、このツールのタブを使用してください。', context))
            except Exception:
                pass

        try:
            cls.draw = _draw_npanel_only
            cls._smart_common_preferences_patched = True
            _PATCHED_PREFERENCES.append((cls, original))
        except Exception:
            pass


def _unpatch_addon_preferences():
    for cls, original in reversed(_PATCHED_PREFERENCES):
        try:
            if original is None:
                if hasattr(cls, 'draw'):
                    delattr(cls, 'draw')
            else:
                cls.draw = original
            if hasattr(cls, '_smart_common_preferences_patched'):
                delattr(cls, '_smart_common_preferences_patched')
        except Exception:
            pass
    _PATCHED_PREFERENCES.clear()


def _simple_rna_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return None


def _iter_setting_roots(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return []
    roots = []
    for attr in ('window_manager', 'scene'):
        root = getattr(ctx, attr, None)
        if root is not None:
            roots.append((attr, root))
    return roots


def _prop_relevant(name, value, owner=None):
    lower = str(name or '').lower()
    # ``common_settings`` used to take a second broad snapshot of every
    # sss_* RNA value.  The owning Shader modules already provide canonical
    # sections (scene_settings, feature_toggle_rna, smart_toon_materials,
    # material_studio, ...); duplicating them here allowed two restore
    # paths to disagree and made an OFF -> ON flush non-deterministic.  Keep
    # only the compatibility fallback switch owned by this module.  Loading
    # older broad common_settings payloads remains supported as a one-way
    # migration, while the next save rewrites this section canonically.
    del value, owner
    return lower == _ALWAYS_ON_PROP.lower()


def _serialize_group(obj, depth=0):
    if depth > 2 or obj is None:
        return {}
    data = {}
    try:
        props = getattr(getattr(obj, 'rna_type', None), 'properties', [])
    except Exception:
        props = []
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not identifier or identifier == 'rna_type' or getattr(prop, 'is_readonly', False):
                continue
            value = getattr(obj, identifier)
            simple = _simple_rna_value(value)
            if simple is not None:
                if _prop_relevant(identifier, value, obj):
                    data[identifier] = simple
            elif _prop_relevant(identifier, value, obj):
                nested = _serialize_group(value, depth + 1)
                if nested:
                    data[identifier] = nested
        except Exception:
            continue
    return data


def collect_persistent_settings(context=None):
    payload = {}
    for root_name, root in _iter_setting_roots(context):
        data = _serialize_group(root, 0)
        if data:
            payload[root_name] = data
    return payload


def _apply_group(obj, data, depth=0):
    if depth > 2 or not isinstance(data, dict):
        return
    for key, value in data.items():
        try:
            if isinstance(value, dict):
                child = getattr(obj, key, None)
                if child is not None:
                    _apply_group(child, value, depth + 1)
            elif hasattr(obj, key):
                setattr(obj, key, value)
        except Exception:
            pass


def apply_persistent_settings(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return
    data = _LOADED_SETTINGS or load_settings_file()
    for root_name, root in _iter_setting_roots(ctx):
        if root_name in data:
            _apply_group(root, data[root_name], 0)


def load_settings_file():
    global _LOADED_SETTINGS
    if _sss_storage is not None:
        try:
            raw = _sss_storage.read_suite_section('common_settings', {})
            if isinstance(raw, dict):
                _LOADED_SETTINGS = raw
                return raw
        except Exception:
            pass
    path = settings_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(raw, dict):
                _LOADED_SETTINGS = raw
                return raw
    except Exception:
        pass
    _LOADED_SETTINGS = {}
    return {}


def save_persistent_settings(context=None, force=False):
    global _AUTOSAVE_FINGERPRINT
    data = collect_persistent_settings(context)
    try:
        raw = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2)
    except Exception:
        return
    if not force and raw == _AUTOSAVE_FINGERPRINT:
        return
    if _sss_storage is not None:
        try:
            if _sss_storage.write_suite_section('common_settings', data):
                _AUTOSAVE_FINGERPRINT = raw
                return
        except Exception:
            pass
        # Never bypass the central OFF/corrupt/read/replace safety barrier.
        return


def _autosave_timer():
    try:
        if _sss_storage is None or _sss_storage.npanel_state_save_enabled(default=True):
            save_persistent_settings(bpy.context)
    except Exception:
        pass
    return 5.0


@persistent
def _load_post_handler(dummy=None):
    try:
        from . import transform_guard as _sss_transform_guard
        with _sss_transform_guard.preserve_object_transforms('common settings load_post'):
            load_settings_file()
            apply_persistent_settings(bpy.context)
    except Exception:
        pass


def _append_handler_once(collection, handler):
    try:
        if handler not in collection:
            collection.append(handler)
    except Exception:
        pass


def _remove_handler(collection, handler):
    try:
        while handler in collection:
            collection.remove(handler)
    except Exception:
        pass


def register():
    try:
        bpy.app.translations.unregister(PACKAGE_ID)
    except Exception:
        pass
    try:
        bpy.app.translations.register(PACKAGE_ID, _translation_payload())
    except Exception:
        pass
    try:
        if not hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            setattr(bpy.types.WindowManager, _ALWAYS_ON_PROP, BoolProperty(
                name='Resident',
                description='Saved resident switch for this tool. Enable it only when you want persistent helper behavior; disable it for ordinary manual use.',
                default=False,
            ))
    except Exception:
        pass
    # Do not unregister legacy/foreign panel classes by name.  The current
    # Suite-owned root panels are managed only through exact class ledgers.
    # Do not register SMART_SHADER_PT_always_on. The resident controls remain
    # only inside the main Smart Shader panel to avoid a duplicate standalone
    # N-panel labeled "Resident Toggle" / "常時機能切り替え".
    for cls in (SMART_SHADER_OT_open_help, SMART_SHADER_OT_toggle_always_on, SMART_SHADER_OT_save_preferences):
        try:
            _materialize_annotations(cls)
            bpy.utils.register_class(cls)
            _REGISTERED_CLASSES.append(cls)
        except ValueError:
            _REGISTERED_CLASSES.append(cls)
        except Exception:
            pass
    load_settings_file()
    try:
        apply_persistent_settings(bpy.context)
    except Exception:
        pass
    # v012: no recurring autosave timer and no per-common load handler.
    # N-panel state is saved through property updates when N-panel State Save is
    # enabled and through the central preferences load/save handlers otherwise.
    try:
        _remove_handler(bpy.app.handlers.load_post, _load_post_handler)
    except Exception:
        pass
    pass
    _patch_panel_headers()
    _patch_addon_preferences()


def unregister():
    try:
        save_persistent_settings(bpy.context, force=True)
    except Exception:
        pass
    _unpatch_panel_headers()
    _unpatch_addon_preferences()
    pass
    _remove_handler(bpy.app.handlers.load_post, _load_post_handler)
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()
    try:
        if hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            delattr(bpy.types.WindowManager, _ALWAYS_ON_PROP)
    except Exception:
        pass
    _remove_previews()
    try:
        bpy.app.translations.unregister(PACKAGE_ID)
    except Exception:
        pass
    end_register()

# -----------------------------------------------------------------------------
# Smart Shader Suite 5.18.224 exact-owned, idle-zero common runtime.
# -----------------------------------------------------------------------------
_COMMON_V1208_OWNER_UUID = '3f6d8d7f-671d-4ff1-bf32-bf15518208aa'
_COMMON_V1208_GENERATION = '5.18.230'
_COMMON_V1208_CLASSES: list[type] = []
_COMMON_V1208_OWNED_ALWAYS_ON_PROP = False
_COMMON_V1208_TRANSLATIONS_OWNED = False

# UI/settings operators do not create an undoable Blender data transaction.
SMART_SHADER_OT_toggle_always_on.bl_options = set()
SMART_SHADER_OT_toggle_always_on._sms_no_undo = True


def begin_register():
    """Compatibility no-op; Blender shared registration APIs are never patched."""
    return None


def end_register():
    return None


def _patch_panel_headers():
    """No-op: Suite panel classes own their metadata directly."""
    return None


def _unpatch_panel_headers():
    _PATCHED_PANELS.clear()
    _PATCHED_POLLS.clear()


def _patch_addon_preferences():
    """No-op: never replace any AddonPreferences.draw implementation."""
    return None


def _unpatch_addon_preferences():
    _PATCHED_PREFERENCES.clear()


def _common_v1208_class_has_own_bl_rna(cls):
    try:
        rna = vars(cls).get('bl_rna') or getattr(cls, 'bl_rna', None)
        identifier = str(getattr(rna, 'identifier', '') or '')
        inherited = {'Operator', 'Panel', 'PropertyGroup', 'Menu', 'UIList', 'AddonPreferences'}
        return bool(identifier and identifier not in inherited)
    except Exception:
        return False

def _common_v1208_register_class(cls):
    if not isinstance(cls, type):
        raise TypeError('Blender class must be a Python type')
    if cls in _COMMON_V1208_CLASSES and _common_v1208_class_has_own_bl_rna(cls):
        return
    if _common_v1208_class_has_own_bl_rna(cls):
        raise RuntimeError(f'RNA class is already registered outside this generation ledger: {getattr(cls, "__name__", "<unnamed>")}')
    try:
        bpy.utils.register_class(cls)
    except Exception:
        if cls in _COMMON_V1208_CLASSES and _common_v1208_class_has_own_bl_rna(cls):
            return
        raise
    if not _common_v1208_class_has_own_bl_rna(cls):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        raise RuntimeError(f'RNA class registration did not publish class bl_rna: {getattr(cls, "__name__", "<unnamed>")}')
    if cls not in _COMMON_V1208_CLASSES:
        _COMMON_V1208_CLASSES.append(cls)

def register():
    global _COMMON_V1208_OWNED_ALWAYS_ON_PROP, _COMMON_V1208_TRANSLATIONS_OWNED
    created_classes = len(_COMMON_V1208_CLASSES)
    try:
        try:
            bpy.app.translations.register(PACKAGE_ID, _translation_payload())
            _COMMON_V1208_TRANSLATIONS_OWNED = True
        except ValueError:
            _COMMON_V1208_TRANSLATIONS_OWNED = False
        if not hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            setattr(bpy.types.WindowManager, _ALWAYS_ON_PROP, BoolProperty(
                name='Resident',
                description='Saved resident switch for this tool. Enable it only when persistent helper behavior is required.',
                default=False,
            ))
            _COMMON_V1208_OWNED_ALWAYS_ON_PROP = True
        for cls in (SMART_SHADER_OT_open_help, SMART_SHADER_OT_toggle_always_on, SMART_SHADER_OT_save_preferences):
            _common_v1208_register_class(cls)
        load_settings_file()
        apply_persistent_settings(getattr(bpy, 'context', None))
    except Exception:
        for cls in reversed(_COMMON_V1208_CLASSES[created_classes:]):
            try:
                if _common_v1208_class_has_own_bl_rna(cls):
                    bpy.utils.unregister_class(cls)
            except Exception:
                pass
        del _COMMON_V1208_CLASSES[created_classes:]
        if _COMMON_V1208_OWNED_ALWAYS_ON_PROP and hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            try:
                delattr(bpy.types.WindowManager, _ALWAYS_ON_PROP)
            except Exception:
                pass
        _COMMON_V1208_OWNED_ALWAYS_ON_PROP = False
        if _COMMON_V1208_TRANSLATIONS_OWNED:
            try:
                bpy.app.translations.unregister(PACKAGE_ID)
            except Exception:
                pass
        _COMMON_V1208_TRANSLATIONS_OWNED = False
        raise


def unregister():
    global _COMMON_V1208_OWNED_ALWAYS_ON_PROP, _COMMON_V1208_TRANSLATIONS_OWNED
    for cls in reversed(tuple(_COMMON_V1208_CLASSES)):
        try:
            if _common_v1208_class_has_own_bl_rna(cls):
                bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _COMMON_V1208_CLASSES.clear()
    if _COMMON_V1208_OWNED_ALWAYS_ON_PROP and hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
        try:
            delattr(bpy.types.WindowManager, _ALWAYS_ON_PROP)
        except Exception:
            pass
    _COMMON_V1208_OWNED_ALWAYS_ON_PROP = False
    _remove_previews()
    if _COMMON_V1208_TRANSLATIONS_OWNED:
        try:
            bpy.app.translations.unregister(PACKAGE_ID)
        except Exception:
            pass
    _COMMON_V1208_TRANSLATIONS_OWNED = False
