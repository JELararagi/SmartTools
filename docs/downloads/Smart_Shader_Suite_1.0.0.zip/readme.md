# Smart Shader 1.0.0

Blender 5.1.2 のマテリアルとシェーダーを編集する拡張機能です。
導入方法、使い方、実例は SmartShader の解説書を参照してください。

Edit materials and shaders in Blender 5.1.2.
The SmartShader guide covers installation and worked examples.
