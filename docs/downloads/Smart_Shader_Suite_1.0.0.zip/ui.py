"""UI drawing code for Smart Shader."""
from .translation import loc_text as _lt
from .translation import exc_text as _exc_text
import bpy
from . import ui_sections
from bpy.types import Panel
import importlib
import sys
import re
import time
from pathlib import Path


class _LazyModule:
    __slots__ = ("_module_name", "_module")

    def __init__(self, module_name: str):
        self._module_name = str(module_name or '').strip()
        self._module = None

    def _load(self):
        module = self._module
        if module is None:
            module = importlib.import_module(f'.{self._module_name}', __package__)
            self._module = module
        return module

    def __getattr__(self, item):
        return getattr(self._load(), item)


def _lazy_module(module_name: str):
    return _LazyModule(module_name)

catalog = _lazy_module('catalog')
core = _lazy_module('core')
data = _lazy_module('data')
environment = _lazy_module('environment')
finder = _lazy_module('finder')
material_editor = _lazy_module('material_editor')
preset_preview_browser = _lazy_module('preset_preview_browser')
slot_selection = _lazy_module('slot_selection')



def _preset_preview_root() -> Path:
    return preset_preview_browser.preview_root()


def _preset_preview_path(preset_id: str) -> Path:
    return preset_preview_browser.preview_path(str(preset_id or '').strip())


def _load_preview_image(path: Path):
    if path is None:
        return None
    try:
        candidate = Path(path)
    except Exception:
        return None
    if not candidate.exists():
        return None
    try:
        target = str(candidate.resolve())
        mtime = float(candidate.stat().st_mtime)
    except Exception:
        target = str(candidate)
        mtime = 0.0
    cached = _PRESET_PREVIEW_IMAGE_CACHE.get(target)
    if cached is not None and cached[0] == mtime:
        return cached[1]
    image = None
    try:
        for candidate_image in bpy.data.images:
            try:
                if bpy.path.abspath(getattr(candidate_image, 'filepath', '') or '') == target:
                    image = candidate_image
                    break
            except Exception:
                continue
    except Exception:
        pass
    if image is None:
        try:
            image = bpy.data.images.load(target, check_existing=True)
        except Exception:
            image = None
    _PRESET_PREVIEW_IMAGE_CACHE[target] = (mtime, image)
    if len(_PRESET_PREVIEW_IMAGE_CACHE) > 128:
        for old_key in list(_PRESET_PREVIEW_IMAGE_CACHE.keys())[:32]:
            _PRESET_PREVIEW_IMAGE_CACHE.pop(old_key, None)
    return image


def _draw_preset_preview(layout, context, preset_attr: str = 'sss_preset_name'):
    scene = getattr(context, 'scene', None)
    preset_id = str(getattr(scene, preset_attr, '') or '') if scene is not None else ''
    box = _n_section(layout, context, 'Preset Preview', 'プリセットプレビュー', 'IMAGE_DATA')
    if not preset_id or preset_id in {'NO_PRESETS', 'NO_PRESETS_MATCH', 'NO_CUSTOM_PRESETS'}:
        _n_text(box, context, tx(scene, 'Select a preset to view its Suzanne preview.', 'プレビューを表示するにはプリセットを選択してください。'))
        row = box.column(align=True)
        _n_op(row, context, 'sss.render_preset_previews', icon='RENDER_STILL')
        try:
            op = row.operator('sss.open_preset_preview_popup', text=tx(scene, 'Image List', '画像一覧'), icon='IMAGE_DATA')
            op.target = 'PBR' if preset_attr == 'sss_pbr_preset_name' else 'MAIN'
            op.generate = False
        except Exception:
            pass
        return
    path = _preset_preview_path(preset_id)
    row = box.column(align=True)
    _n_op(row, context, 'sss.render_preset_previews', icon='RENDER_STILL')
    try:
        op = row.operator('sss.open_preset_preview_popup', text=tx(scene, 'Image List', '画像一覧'), icon='IMAGE_DATA')
        op.target = 'PBR' if preset_attr == 'sss_pbr_preset_name' else 'MAIN'
        op.generate = False
    except Exception:
        pass
    box.label(text=tx(scene, '256×256 Suzanne', '256×256 スザンヌ'))
    if path.exists():
        image = _load_preview_image(path)
        if image is not None:
            try:
                target = str(path.resolve())
                try:
                    mtime = float(path.stat().st_mtime)
                except Exception:
                    mtime = 0.0
                icon_key = (target, mtime)
                icon_id = int(_PRESET_PREVIEW_ICON_CACHE.get(icon_key, 0) or 0)
                if icon_id <= 0:
                    image.preview_ensure()
                    icon_id = int(getattr(getattr(image, 'preview', None), 'icon_id', 0) or 0)
                    if icon_id > 0:
                        _PRESET_PREVIEW_ICON_CACHE[icon_key] = icon_id
                if icon_id > 0:
                    box.template_icon(icon_value=icon_id, scale=12.0)
                else:
                    box.label(text=tx(scene, 'Preview image is loaded but has no icon preview yet.', 'プレビュー画像は読み込み済みですが、アイコンプレビューがまだありません。'), icon='IMAGE_DATA')
            except Exception:
                box.label(text=tx(scene, 'Preview image display failed; the file itself is still available.', 'プレビュー表示に失敗しましたが、画像ファイル自体は利用できます。'), icon='ERROR')
        box.label(text=path.name, icon='FILE_IMAGE', translate=False)
    else:
        _n_text(box, context, tx(scene, 'Preview image has not been rendered yet.', 'プレビュー画像がまだ生成されていません。'), 'ERROR')
        box.label(text=path.name, icon='FILE_IMAGE', translate=False)
inventory = _lazy_module('inventory')
layers = _lazy_module('layers')
rules = _lazy_module('rules')
sss_operators = _lazy_module('operators')
sss_properties = _lazy_module('properties')
preferences = _lazy_module('preferences')
tool_preferences = _lazy_module('tool_preferences')
ui_runtime = _lazy_module('ui_runtime')
feature_toggle = _lazy_module('feature_toggle')
material_studio = _lazy_module('material_studio')
smart_toon = _lazy_module('smart_toon')
from .translation import locale_is_japanese, tx, wrap_lines, yes_no
_UI_SHUTTING_DOWN = False
_UI_DRAW_IN_PROGRESS = False
_UI_READY_SCENE_CACHE: dict[tuple[int, str], bool] = {}
_UI_DEFAULTS_READY_SCENES: set[int] = set()
_AREA_EDITOR_KEY_CACHE: dict[tuple, tuple[str, float]] = {}
_DYNAMIC_ENUM_SANITIZE_PENDING = False
_DYNAMIC_ENUM_SANITIZE_LAST_KEY: tuple | None = None
_PRESET_PREVIEW_IMAGE_CACHE: dict[str, tuple[float, object]] = {}
_PRESET_PREVIEW_ICON_CACHE: dict[tuple[str, float], int] = {}
_TEXT_WIDTH_CACHE: dict[tuple[str, str], float] = {}
_WRAP_LABEL_CACHE: dict[tuple[str, str, int, int], tuple[str, ...]] = {}


def _ui_can_open_popup(context) -> bool:
    try:
        if bool(getattr(bpy.app, 'background', False)):
            return False
        wm = getattr(context, 'window_manager', None)
        window = getattr(context, 'window', None)
        return wm is not None and window is not None
    except Exception:
        return False


def _scene_has_rna_property(scene, prop_name: str) -> bool:
    if scene is None or not prop_name:
        return False
    try:
        props = getattr(getattr(scene, 'bl_rna', None), 'properties', None)
    except Exception:
        props = None
    if props is None:
        return False
    try:
        return props.get(str(prop_name)) is not None
    except Exception:
        pass
    try:
        return str(prop_name) in props.keys()
    except Exception:
        return False


def begin_ui_shutdown():
    global _UI_SHUTTING_DOWN
    _UI_SHUTTING_DOWN = True

def end_ui_shutdown():
    global _UI_SHUTTING_DOWN
    _UI_SHUTTING_DOWN = False

def _scene_cache_key(scene) -> int:
    if scene is None:
        return 0
    try:
        pointer = int(scene.as_pointer())
        if pointer:
            return pointer
    except Exception:
        pass
    return id(scene)


def ui_ready(context) -> bool:
    if _UI_SHUTTING_DOWN:
        return False
    scene = getattr(context, 'scene', None)
    if scene is None:
        return False
    key = (_scene_cache_key(scene), 'sss_last_report')
    cached = _UI_READY_SCENE_CACHE.get(key)
    if cached is not None:
        return cached
    ready = _scene_has_rna_property(scene, 'sss_last_report')
    _UI_READY_SCENE_CACHE[key] = ready
    if len(_UI_READY_SCENE_CACHE) > 64:
        for old_key in list(_UI_READY_SCENE_CACHE.keys())[:16]:
            _UI_READY_SCENE_CACHE.pop(old_key, None)
    return ready


def _node_editor_tree_type(context) -> str:
    """Return the current node-editor tree type without forcing unsafe RNA lookups."""
    space = getattr(context, 'space_data', None)
    if space is None:
        try:
            area = getattr(context, 'area', None)
            space = getattr(getattr(area, 'spaces', None), 'active', None)
        except Exception:
            space = None
    for attr in ('tree_type', 'ui_type'):
        try:
            value = str(getattr(space, attr, '') or '')
        except Exception:
            value = ''
        if value:
            return value
    try:
        node_tree = getattr(space, 'node_tree', None)
        value = str(getattr(node_tree, 'bl_idname', '') or '')
        if value:
            return value
    except Exception:
        pass
    return ''


_N_PANEL_EDITOR_SPACE_TYPES = {
    'VIEW_3D': 'VIEW_3D',
    'IMAGE_EDITOR': 'IMAGE_EDITOR',
    'UV_EDITOR': 'IMAGE_EDITOR',
    'SHADER_EDITOR': 'NODE_EDITOR',
    'COMPOSITOR': 'NODE_EDITOR',
    'GEOMETRY_NODE_EDITOR': 'NODE_EDITOR',
    'TEXTURE_NODE_EDITOR': 'NODE_EDITOR',
    'VIDEO_SEQUENCER': 'SEQUENCE_EDITOR',
    'MOVIE_CLIP_EDITOR': 'CLIP_EDITOR',
    'DOPE_SHEET': 'DOPESHEET_EDITOR',
    'GRAPH_EDITOR': 'GRAPH_EDITOR',
    'DRIVERS': 'GRAPH_EDITOR',
    'NLA_EDITOR': 'NLA_EDITOR',
    'TEXT_EDITOR': 'TEXT_EDITOR',
    'ASSET_BROWSER': 'FILE_BROWSER',
    'FILE_BROWSER': 'FILE_BROWSER',
    'SPREADSHEET': 'SPREADSHEET',
}

_N_PANEL_EDITOR_ORDER = (
    'VIEW_3D',
    'IMAGE_EDITOR',
    'UV_EDITOR',
    'SHADER_EDITOR',
    'COMPOSITOR',
    'GEOMETRY_NODE_EDITOR',
    'TEXTURE_NODE_EDITOR',
    'VIDEO_SEQUENCER',
    'MOVIE_CLIP_EDITOR',
    'DOPE_SHEET',
    'GRAPH_EDITOR',
    'DRIVERS',
    'NLA_EDITOR',
    'TEXT_EDITOR',
    'ASSET_BROWSER',
    'FILE_BROWSER',
    'SPREADSHEET',
)


def _area_enum_text(value) -> str:
    try:
        identifier = getattr(value, 'identifier', None)
    except Exception:
        identifier = None
    if identifier:
        return str(identifier).upper()
    return str(value or '').upper()


def _active_space_for_context(context):
    try:
        space = getattr(context, 'space_data', None)
    except Exception:
        space = None
    if space is not None:
        return space
    try:
        area = getattr(context, 'area', None)
        return getattr(getattr(area, 'spaces', None), 'active', None)
    except Exception:
        return None


def _space_attr_text(space, *names: str) -> str:
    if space is None:
        return ''
    for name in names:
        try:
            value = getattr(space, name, None)
        except Exception:
            value = None
        text = _area_enum_text(value)
        if text:
            return text
    return ''


def _area_attr_text(area, *names: str) -> str:
    if area is None:
        return ''
    for name in names:
        try:
            value = getattr(area, name, None)
        except Exception:
            value = None
        text = _area_enum_text(value)
        if text:
            return text
    return ''


def _is_shader_editor_area(context) -> bool:
    area = getattr(context, 'area', None)
    if area is None or getattr(area, 'type', None) != 'NODE_EDITOR':
        return False
    tree_type = _node_editor_tree_type(context)
    return not tree_type or tree_type in {'ShaderNodeTree', 'SHADER', 'SHADERNODETREE', 'SHADER_NODE_TREE'}


def _area_pointer_key(value) -> int:
    if value is None:
        return 0
    try:
        pointer = int(value.as_pointer())
        if pointer:
            return pointer
    except Exception:
        pass
    return id(value)


def _current_npanel_editor_key(context) -> str:
    area = getattr(context, 'area', None)
    if area is None:
        return ''
    space = _active_space_for_context(context)
    area_type = _area_attr_text(area, 'type')
    area_ui_type = _area_attr_text(area, 'ui_type')
    space_type = _space_attr_text(space, 'type')
    tree_type = _space_attr_text(space, 'tree_type') or area_ui_type
    image_mode = _space_attr_text(space, 'mode', 'ui_mode')
    graph_mode = _space_attr_text(space, 'mode', 'ui_mode')
    dopesheet_mode = _space_attr_text(space, 'mode', 'ui_mode')
    sequence_view = _space_attr_text(space, 'view_type', 'display_mode', 'mode')
    try:
        params = getattr(space, 'params', None)
    except Exception:
        params = None
    file_browse_mode = _space_attr_text(space, 'browse_mode', 'mode') or _space_attr_text(params, 'browse_mode')
    cache_key = (
        _area_pointer_key(area),
        _area_pointer_key(space),
        area_type, area_ui_type, space_type, tree_type, image_mode,
        graph_mode, dopesheet_mode, sequence_view, file_browse_mode,
    )
    cached = _AREA_EDITOR_KEY_CACHE.get(cache_key)
    now = time.monotonic()
    if cached is not None and now - cached[1] < 2.0:
        return cached[0]

    actual = space_type or area_type
    uv_image_modes = {'UV', 'UV_EDIT', 'UVS', 'UV_EDITOR'}
    shader_types = {'SHADERNODETREE', 'SHADER', 'SHADER_NODE_TREE'}
    compositor_types = {'COMPOSITORNODETREE', 'COMPOSITOR', 'COMPOSITOR_NODE_TREE'}
    geometry_types = {'GEOMETRYNODETREE', 'GEOMETRY', 'GEOMETRY_NODE_TREE'}
    texture_types = {'TEXTURENODETREE', 'TEXTURE', 'TEXTURE_NODE_TREE'}
    asset_browser_modes = {'ASSETS', 'ASSET_BROWSER'}

    result = ''
    if actual == 'VIEW_3D':
        result = 'VIEW_3D'
    elif actual == 'IMAGE_EDITOR':
        result = 'UV_EDITOR' if image_mode in uv_image_modes or area_ui_type in uv_image_modes else 'IMAGE_EDITOR'
    elif actual == 'NODE_EDITOR':
        if not tree_type or tree_type in shader_types:
            result = 'SHADER_EDITOR'
        elif tree_type in compositor_types:
            result = 'COMPOSITOR'
        elif tree_type in geometry_types:
            result = 'GEOMETRY_NODE_EDITOR'
        elif tree_type in texture_types:
            result = 'TEXTURE_NODE_EDITOR'
    elif actual == 'SEQUENCE_EDITOR':
        result = 'VIDEO_SEQUENCER' if sequence_view not in {'PREVIEW'} else ''
    elif actual == 'CLIP_EDITOR':
        result = 'MOVIE_CLIP_EDITOR'
    elif actual == 'DOPESHEET_EDITOR':
        result = '' if area_ui_type in {'DRIVERS', 'DRIVER', 'TIMELINE'} or dopesheet_mode in {'DRIVERS', 'DRIVER', 'TIMELINE'} else 'DOPE_SHEET'
    elif actual == 'GRAPH_EDITOR':
        result = 'DRIVERS' if graph_mode in {'DRIVERS', 'DRIVER'} or area_ui_type in {'DRIVERS', 'DRIVER'} else 'GRAPH_EDITOR'
    elif actual == 'NLA_EDITOR':
        result = 'NLA_EDITOR'
    elif actual == 'TEXT_EDITOR':
        result = 'TEXT_EDITOR'
    elif actual == 'FILE_BROWSER':
        result = 'ASSET_BROWSER' if file_browse_mode in asset_browser_modes or area_ui_type in asset_browser_modes else 'FILE_BROWSER'
    elif actual == 'SPREADSHEET':
        result = 'SPREADSHEET'

    _AREA_EDITOR_KEY_CACHE[cache_key] = (result, now)
    if len(_AREA_EDITOR_KEY_CACHE) > 256:
        for old_key in list(_AREA_EDITOR_KEY_CACHE.keys())[:64]:
            _AREA_EDITOR_KEY_CACHE.pop(old_key, None)
    return result


def _n_panel_area_matches_editor_key(context, editor_key: str) -> bool:
    return _current_npanel_editor_key(context) == str(editor_key or '').upper()


def _is_supported_npanel_area(context) -> bool:
    return bool(_current_npanel_editor_key(context))


def _context_mode_name(context) -> str:
    try:
        return str(getattr(context, 'mode', '') or 'OBJECT')
    except Exception:
        return 'OBJECT'


def _safe_active_object(context):
    try:
        obj = getattr(context, 'active_object', None)
    except Exception:
        return None
    if obj is None:
        return None
    try:
        _ = obj.name
    except Exception:
        return None
    return obj


def _is_stable_panel_context(context, editor_key: str | None = None) -> bool:
    """Return whether the Smart Shader N-panel should remain visible.

    This guard must be permissive.  Earlier builds hid the entire N-panel in
    non-object modes or when Blender/Smart Tools Manager supplied a partial
    redraw context where the exact editor subtype could not be resolved.  That
    made the sidebar appear to disappear even though the add-on was enabled.
    The draw body itself is already defensive, so the panel entry should stay
    visible whenever Blender gives us a scene and a compatible UI area.
    """
    if context is None or _UI_SHUTTING_DOWN:
        return False
    if getattr(context, 'scene', None) is None:
        return False

    expected = str(editor_key or '').upper() if editor_key is not None else ''
    actual_editor = _current_npanel_editor_key(context)
    if actual_editor:
        return not expected or actual_editor == expected

    # Fallback for transient redraw contexts and manager/proxy contexts.  Some
    # Blender 5.1 panel polls are evaluated before ``space_data.tree_type`` or
    # mode-specific UI attributes are populated; in that case keep the matching
    # space-type panel visible instead of hiding the whole N-panel tab.
    if expected:
        try:
            expected_space = _N_PANEL_EDITOR_SPACE_TYPES.get(expected, '')
            area = getattr(context, 'area', None)
            space = _active_space_for_context(context)
            area_type = _area_attr_text(area, 'type')
            space_type = _space_attr_text(space, 'type') or area_type
            if expected_space and space_type == expected_space:
                return True
        except Exception:
            pass
        return False
    return True


def _safe_panel_draw(panel, context, callback, *args, **kwargs):
    global _UI_DRAW_IN_PROGRESS
    if _UI_DRAW_IN_PROGRESS:
        return None
    if not _is_stable_panel_context(context):
        return None
    layout = getattr(panel, 'layout', None)
    if layout is None:
        return None
    _UI_DRAW_IN_PROGRESS = True
    try:
        try:
            return callback(layout, context, *args, **kwargs)
        except Exception as exc:
            try:
                warn = layout.box()
                warn.alert = True
                warn.label(text=tx(getattr(context, 'scene', None), 'Smart Shader UI draw error', _lt('スマートシェーダー UI 描画エラー')), icon='ERROR')
                warn.label(text=_exc_text(exc))
            except Exception:
                pass
            return None
    finally:
        _UI_DRAW_IN_PROGRESS = False


def _ui_can_open_popup(context) -> bool:
    try:
        if bool(getattr(bpy.app, 'background', False)):
            return False
        wm = getattr(context, 'window_manager', None)
        window = getattr(context, 'window', None)
        return wm is not None and window is not None
    except Exception:
        return False

class SSS_OT_show_info(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = 'sss.show_info'
    bl_label = _lt('Show Info', '情報表示')
    bl_description = _lt('JP: この見出しの説明をツールチップで表示します。\nEN: Show this section explanation in a tooltip.')
    bl_options = {'INTERNAL'}

    tooltip: bpy.props.StringProperty(default='', options={'HIDDEN', 'SKIP_SAVE'})
    topic: bpy.props.StringProperty(default='', options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        value = str(getattr(properties, 'tooltip', '') or '').strip()
        return value or cls.bl_description

    def execute(self, context):
        return {'FINISHED'}


class SSS_OT_open_help(bpy.types.Operator):
    _sms_no_undo = True
    _HELP_POPUP_WIDTH = 860
    bl_idname = 'sss.open_help'
    bl_label = _lt('Open Help', 'ヘルプを開く')
    bl_description = _lt('JP: 選択したスマートシェーダー機能の詳細ヘルプをポップアップ表示します。\nEN: Show a detailed popup help page for the selected Smart Shader feature.')
    bl_options = {'INTERNAL'}

    topic: bpy.props.StringProperty(default='smart_shader_root', options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        return tx(
            getattr(context, 'scene', None),
            'Open the dedicated help popup for this tool.',
            'このツール専用のヘルプポップアップを開きます。',
        )

    def _draw_popup_content(self, context):
        try:
            import importlib as _importlib
            module = _importlib.import_module('.help', __package__)
            module.draw_help(self.layout, context, getattr(self, 'topic', 'smart_shader_root'), popup_width=self._HELP_POPUP_WIDTH)
        except Exception as exc:
            warn = self.layout.box()
            warn.alert = True
            warn.label(text=tx(getattr(context, 'scene', None), 'Help popup error', 'ヘルプポップアップエラー'), icon='ERROR')
            warn.label(text=_exc_text(exc))

    def draw(self, context):
        self._draw_popup_content(context)

    def invoke(self, context, _event):
        if not _ui_can_open_popup(context):
            return self.execute(context)
        try:
            return context.window_manager.invoke_popup(self, width=self._HELP_POPUP_WIDTH)
        except Exception:
            return self.execute(context)

    def execute(self, context):
        if not _ui_can_open_popup(context):
            try:
                self.report({'INFO'}, tx(getattr(context, 'scene', None), 'Help popup is unavailable in background mode.', 'バックグラウンドモードではヘルプポップアップを表示できません。'))
            except Exception:
                pass
            return {'FINISHED'}
        try:
            def _popup(menu, popup_context):
                try:
                    import importlib as _importlib
                    module = _importlib.import_module('.help', __package__)
                    module.draw_help(menu.layout, popup_context, getattr(self, 'topic', 'smart_shader_root'), popup_width=self._HELP_POPUP_WIDTH)
                except Exception as exc:
                    box = menu.layout.box()
                    box.alert = True
                    box.label(text=tx(getattr(popup_context, 'scene', None), 'Help popup error', 'ヘルプポップアップエラー'), icon='ERROR')
                    box.label(text=_exc_text(exc))
            context.window_manager.popup_menu(_popup, title=tx(getattr(context, 'scene', None), 'Help', 'ヘルプ'), icon='BOOKMARKS')
            return {'FINISHED'}
        except Exception:
            return {'CANCELLED'}




_ACTIVE_MATERIAL_PICK_ITEMS = []
_ACTIVE_MATERIAL_PICK_MAP = {}


def _material_slot_capable_object(context):
    obj = _safe_active_object(context)
    if obj is None:
        return None
    try:
        data_block = getattr(obj, 'data', None)
    except Exception:
        data_block = None
    try:
        if data_block is None or not hasattr(data_block, 'materials'):
            return None
    except Exception:
        return None
    return obj


def _active_material_pick_items(self, context):
    global _ACTIVE_MATERIAL_PICK_ITEMS, _ACTIVE_MATERIAL_PICK_MAP
    scene = getattr(context, 'scene', None)
    items = []
    mapping = {}
    try:
        materials = sorted(list(getattr(bpy.data, 'materials', ()) or ()), key=lambda mat: str(getattr(mat, 'name', '') or '').lower())
    except Exception:
        materials = []
    for index, material in enumerate(materials):
        name = str(getattr(material, 'name', '') or '').strip()
        if not name:
            continue
        token = f'MAT_{index:04d}'
        mapping[token] = name
        items.append((
            token,
            name,
            tx(scene, f'Assign {name} to the active material slot.', f'{name} をアクティブマテリアルスロットへ割り当てます。'),
            'MATERIAL',
            index,
        ))
    if not items:
        items = [(
            'MATLIB_NONE',
            tx(scene, 'No materials available', '利用できるマテリアルがありません'),
            tx(scene, 'Create a material first.', '先にマテリアルを作成してください。'),
            'ERROR',
            0,
        )]
        mapping['MATLIB_NONE'] = ''
    _ACTIVE_MATERIAL_PICK_ITEMS = items
    _ACTIVE_MATERIAL_PICK_MAP = mapping
    return _ACTIVE_MATERIAL_PICK_ITEMS


def _active_material_token_for_name(material_name: str) -> str:
    material_name = str(material_name or '')
    for token, name in _ACTIVE_MATERIAL_PICK_MAP.items():
        if name == material_name:
            return token
    return next(iter(_ACTIVE_MATERIAL_PICK_MAP), 'MATLIB_NONE')


def _assign_active_object_material(context, material):
    obj = _material_slot_capable_object(context)
    if obj is None or material is None:
        return False
    try:
        assigned = core.set_material_on_object(obj, material, core.assign_mode(context), context=context)
    except Exception:
        assigned = False
    if assigned:
        scene = getattr(context, 'scene', None)
        if scene is not None and _scene_has_rna_property(scene, 'sss_target_material_name'):
            try:
                scene.sss_target_material_name = str(getattr(material, 'name', '') or '')
            except Exception:
                pass
    return bool(assigned)


_MATERIAL_TARGET_SLOT_ITEMS = []
_MATERIAL_TARGET_SLOT_MAP = {}


def _material_target_slot_items(self, context):
    global _MATERIAL_TARGET_SLOT_ITEMS, _MATERIAL_TARGET_SLOT_MAP
    scene = getattr(context, 'scene', None)
    obj = _material_slot_capable_object(context)
    items = []
    mapping = {}
    if obj is not None:
        try:
            slots = getattr(obj, 'material_slots', ()) or ()
        except Exception:
            slots = ()
        for index, slot in enumerate(slots):
            try:
                mat = slot.material
            except Exception:
                mat = None
            mat_name = str(getattr(mat, 'name', '') or tx(scene, 'Empty', '空'))
            token = f'SLOT_{index:03d}'
            label = f'{index + 1}: {mat_name}'
            desc = tx(scene, f'Use material slot {index + 1} as the target for material creation and apply operations.', f'{index + 1}番スロットをマテリアル作成・適用の対象にします。')
            items.append((token, label, desc, 'MATERIAL', index))
            mapping[token] = index
    if not items:
        items = [('SLOT_000', tx(scene, '1: Empty', '1: 空'), tx(scene, 'Create or apply the material to the first available material slot.', '最初に利用できるマテリアルスロットへ作成・適用します。'), 'MATERIAL', 0)]
        mapping['SLOT_000'] = 0
    _MATERIAL_TARGET_SLOT_ITEMS = items
    _MATERIAL_TARGET_SLOT_MAP = mapping
    return _MATERIAL_TARGET_SLOT_ITEMS


def _target_slot_token_for_index(index: int) -> str:
    token = f'SLOT_{max(0, int(index)):03d}'
    return token if token in _MATERIAL_TARGET_SLOT_MAP else next(iter(_MATERIAL_TARGET_SLOT_MAP), 'SLOT_000')


class SSS_OT_choose_material_target_slot(bpy.types.Operator):
    bl_idname = 'sss.choose_material_target_slot'
    bl_label = _lt('Choose Material Slot', 'マテリアルスロット選択')
    bl_description = _lt('Choose which material slot on the active object receives newly generated or applied materials when Active Slot assignment is used.', 'アクティブスロット割当で新規生成または適用したマテリアルを受け取る、アクティブオブジェクト上のマテリアルスロットを選択します。')
    bl_options = {'INTERNAL'}
    bl_property = 'slot_token'

    slot_token: bpy.props.EnumProperty(
        name=_lt('Material Slot', 'マテリアルスロット'),
        description=_lt('Choose the active object material slot to replace during material generation or apply operations.', 'マテリアル生成または適用時に置き換えるアクティブオブジェクトのマテリアルスロットを選択します。'),
        items=_material_target_slot_items,
        options={'SKIP_SAVE'},
    )

    @classmethod
    def poll(cls, context):
        return _material_slot_capable_object(context) is not None

    def invoke(self, context, _event):
        _material_target_slot_items(self, context)
        try:
            current = core.selected_material_slot_index(context, _material_slot_capable_object(context))
            self.slot_token = _target_slot_token_for_index(current)
        except Exception:
            pass
        try:
            context.window_manager.invoke_search_popup(self)
            return {'RUNNING_MODAL'}
        except Exception:
            return self.execute(context)

    def execute(self, context):
        scene = getattr(context, 'scene', None)
        token = str(getattr(self, 'slot_token', '') or '')
        index = _MATERIAL_TARGET_SLOT_MAP.get(token, None)
        if index is None and token.startswith('SLOT_'):
            try:
                index = int(token.split('_', 1)[1])
            except Exception:
                index = None
        if index is None:
            index = 0
        if scene is not None and _scene_has_rna_property(scene, 'sss_material_target_slot_index'):
            try:
                scene.sss_material_target_slot_index = int(index)
            except Exception:
                pass
        obj = _material_slot_capable_object(context)
        if obj is not None:
            try:
                slot_count = len(getattr(obj, 'material_slots', ()) or ())
                if slot_count > 0:
                    obj.active_material_index = max(0, min(slot_count - 1, int(index)))
            except Exception:
                pass
        return {'FINISHED'}


def _active_object_slot_count(context) -> int:
    obj = _material_slot_capable_object(context)
    if obj is None:
        return 0
    try:
        return len(getattr(obj, 'material_slots', ()) or ())
    except Exception:
        return 0


def _material_target_slot_label(context) -> str:
    scene = getattr(context, 'scene', None)
    obj = _material_slot_capable_object(context)
    if obj is None:
        return tx(scene, 'No active object', 'アクティブオブジェクトなし')
    try:
        index = core.selected_material_slot_index(context, obj)
        return core.material_slot_label(obj, index, empty_label=tx(scene, 'Empty', '空'))
    except Exception:
        return tx(scene, 'Active slot', 'アクティブスロット')


def _draw_material_target_slot_selector(layout, context):
    scene = getattr(context, 'scene', None)
    try:
        needs_multi = slot_selection.needs_material_target_slot_choice(context, assign_selected=True) and len(core.selected_material_target_objects(context, assign_selected=True)) > 1
    except Exception:
        needs_multi = False
    if _active_object_slot_count(context) <= 1 and not needs_multi:
        return
    label = tx(scene, 'Selected objects', '選択オブジェクト') if needs_multi else _material_target_slot_label(context)
    row = layout.row(align=True)
    try:
        row.enabled = str(getattr(scene, 'sss_assign_mode', 'ACTIVE_SLOT') or 'ACTIVE_SLOT') == 'ACTIVE_SLOT'
    except Exception:
        pass
    row.operator('sss.choose_material_target_slot', text=tx(scene, f'Apply Slot: {label}', f'適用スロット: {label}'), icon='MATERIAL')


class SSS_OT_select_active_material(bpy.types.Operator):
    bl_idname = 'sss.select_active_material'
    bl_label = _lt('Select Active Material', 'アクティブマテリアル選択')
    bl_description = _lt('JP: 標準の幅広いマテリアルIDブラウザを使わず、検索ポップアップから既存マテリアルを選んでアクティブスロットへ割り当てます。Nパネルの横幅を超える表示を避けるためのコンパクト選択UIです。\nEN: Select an existing material from a search popup and assign it to the active slot without using Blender\'s wide default material ID browser, keeping the N-panel layout inside its bounds.')
    bl_options = {'INTERNAL'}
    bl_property = 'material_token'

    material_token: bpy.props.EnumProperty(
        name=_lt('JP: マテリアル\nEN: Material'),
        description=_lt('JP: アクティブオブジェクトへ割り当てる既存マテリアルです。\nEN: Existing material to assign to the active object.'),
        items=_active_material_pick_items,
        options={'SKIP_SAVE'},
    )

    @classmethod
    def poll(cls, context):
        return _material_slot_capable_object(context) is not None

    def invoke(self, context, _event):
        _active_material_pick_items(self, context)
        current = getattr(getattr(context, 'active_object', None), 'active_material', None)
        current_name = str(getattr(current, 'name', '') or '')
        try:
            self.material_token = _active_material_token_for_name(current_name)
        except Exception:
            pass
        try:
            context.window_manager.invoke_search_popup(self)
            return {'RUNNING_MODAL'}
        except Exception:
            return self.execute(context)

    def execute(self, context):
        token = str(getattr(self, 'material_token', '') or '')
        material_name = _ACTIVE_MATERIAL_PICK_MAP.get(token, '')
        material = bpy.data.materials.get(material_name) if material_name else None
        if material is None:
            self.report({'WARNING'}, tx(getattr(context, 'scene', None), 'No material was selected.', 'マテリアルが選択されていません。'))
            return {'CANCELLED'}
        if not _assign_active_object_material(context, material):
            self.report({'WARNING'}, tx(getattr(context, 'scene', None), 'The selected object cannot receive materials.', '選択オブジェクトへマテリアルを割り当てられません。'))
            return {'CANCELLED'}
        return {'FINISHED'}


class SSS_OT_create_active_material(bpy.types.Operator):
    bl_idname = 'sss.create_active_material'
    bl_label = _lt('Create Active Material', 'アクティブマテリアル作成')
    bl_description = _lt('JP: 現在のアクティブオブジェクトに新しいマテリアルを作成して割り当てます。標準のマテリアルIDブラウザを描画しないため、狭いNパネルでも横にはみ出しません。名前欄が空の場合はBlenderの既定名を使います。\nEN: Create and assign a new material to the active object without drawing the default material ID browser, so narrow N-panels stay within bounds. If the name field is empty, Blender\'s default material name is used.')
    bl_options = {'INTERNAL', 'UNDO'}
    bl_property = 'sss_target_slot_token'

    sss_target_slot_token: bpy.props.EnumProperty(**slot_selection.MATERIAL_TARGET_SLOT_PROPERTY_KWARGS)

    @classmethod
    def poll(cls, context):
        return _material_slot_capable_object(context) is not None

    def invoke(self, context, _event):
        result = slot_selection.invoke_operator_material_target_slot_search(self, context, assign_selected=True)
        if result:
            return result
        return self.execute(context)

    def execute(self, context):
        slot_selection.apply_operator_material_target_slot(self, context)
        scene = getattr(context, 'scene', None)
        desired = str(getattr(scene, 'sss_material_name', '') or '').strip() if scene is not None else ''
        try:
            material = bpy.data.materials.new(name=desired or 'Material')
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        if not _assign_active_object_material(context, material):
            try:
                bpy.data.materials.remove(material)
            except Exception:
                pass
            self.report({'WARNING'}, tx(scene, 'The selected object cannot receive materials.', '選択オブジェクトへマテリアルを割り当てられません。'))
            return {'CANCELLED'}
        return {'FINISHED'}

_SCENE_MATERIAL_PICK_ITEMS = []
_SCENE_MATERIAL_PICK_MAP = {}


def _scene_material_pick_items(self, context):
    global _SCENE_MATERIAL_PICK_ITEMS, _SCENE_MATERIAL_PICK_MAP
    scene = getattr(context, 'scene', None)
    items = []
    mapping = {}
    try:
        materials = sorted(list(getattr(bpy.data, 'materials', ()) or ()), key=lambda mat: str(getattr(mat, 'name', '') or '').lower())
    except Exception:
        materials = []
    for index, material in enumerate(materials):
        name = str(getattr(material, 'name', '') or '').strip()
        if not name:
            continue
        token = f'MATPROP_{index:04d}'
        mapping[token] = name
        items.append((
            token,
            name,
            tx(scene, f'Set the material field to {name}.', f'マテリアル欄へ {name} を設定します。'),
            'MATERIAL',
            index,
        ))
    if not items:
        token = 'MATPROP_NONE'
        mapping[token] = ''
        items.append((token, tx(scene, 'No materials available', '利用できるマテリアルがありません'), tx(scene, 'Create or import a material first.', '先にマテリアルを作成または読み込んでください。'), 'ERROR', 0))
    _SCENE_MATERIAL_PICK_ITEMS = items
    _SCENE_MATERIAL_PICK_MAP = mapping
    return _SCENE_MATERIAL_PICK_ITEMS


def _scene_material_token_for_name(material_name: str) -> str:
    material_name = str(material_name or '')
    for token, name in _SCENE_MATERIAL_PICK_MAP.items():
        if name == material_name:
            return token
    return next(iter(_SCENE_MATERIAL_PICK_MAP), 'MATPROP_NONE')


class SSS_OT_pick_material_field(bpy.types.Operator):
    bl_idname = 'sss.pick_material_field'
    bl_label = _lt('Pick Material Field', 'マテリアル欄選択')
    bl_description = _lt('JP: Blender標準の横長マテリアル参照UIを使わず、検索ポップアップから既存マテリアルを選んでNパネル内のマテリアル名欄へ設定します。\nEN: Select an existing material through a search popup and write it into the N-panel material-name field without drawing Blender\'s wide material reference UI.')
    bl_options = {'INTERNAL'}
    bl_property = 'material_token'

    prop_name: bpy.props.StringProperty(default='', options={'HIDDEN', 'SKIP_SAVE'})
    material_token: bpy.props.EnumProperty(
        name=_lt('JP: マテリアル\nEN: Material'),
        description=_lt('JP: この欄へ設定する既存マテリアルです。\nEN: Existing material to write into this field.'),
        items=_scene_material_pick_items,
        options={'SKIP_SAVE'},
    )

    _ALLOWED_PROPS = {'sss_target_material_name', 'sss_compare_source_material_name', 'sss_material_name', 'sss_npr_material_name'}

    @classmethod
    def poll(cls, context):
        return getattr(context, 'scene', None) is not None

    def invoke(self, context, _event):
        _scene_material_pick_items(self, context)
        scene = getattr(context, 'scene', None)
        prop_name = str(getattr(self, 'prop_name', '') or '').strip()
        current_name = str(getattr(scene, prop_name, '') or '') if scene is not None and prop_name in self._ALLOWED_PROPS else ''
        try:
            self.material_token = _scene_material_token_for_name(current_name)
        except Exception:
            pass
        try:
            context.window_manager.invoke_search_popup(self)
            return {'RUNNING_MODAL'}
        except Exception:
            return self.execute(context)

    def execute(self, context):
        scene = getattr(context, 'scene', None)
        prop_name = str(getattr(self, 'prop_name', '') or '').strip()
        if scene is None or prop_name not in self._ALLOWED_PROPS or not _scene_has_rna_property(scene, prop_name):
            self.report({'WARNING'}, tx(scene, 'Unknown material field.', '不明なマテリアル欄です。'))
            return {'CANCELLED'}
        material_name = _SCENE_MATERIAL_PICK_MAP.get(str(getattr(self, 'material_token', '') or ''), '')
        if not material_name:
            self.report({'WARNING'}, tx(scene, 'No material was selected.', 'マテリアルが選択されていません。'))
            return {'CANCELLED'}
        try:
            setattr(scene, prop_name, material_name)
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        return {'FINISHED'}

class SSS_OT_toggle_entry(bpy.types.Operator):
    bl_idname = 'sss.toggle_entry'
    bl_label = _lt('Toggle Entry', '項目切替')
    bl_description = _lt('JP: 常時機能切り替えグループ内の項目を有効または無効にします。設定は即時保存され、次回起動時にも維持されます。\nEN: Enable or disable an entry in the Resident Feature Toggles group. The setting is saved immediately and kept for the next startup.')
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    prop_name: bpy.props.StringProperty(default='', options={'HIDDEN', 'SKIP_SAVE'})
    label_text: bpy.props.StringProperty(default='', options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, 'label_text', '') or '').strip()
        base = tx(
            getattr(context, 'scene', None),
            'Enable or disable this resident item. Enabled items are shown as pressed blue buttons and the setting is saved immediately.',
            'この常時機能項目を有効または無効にします。有効な項目は押下状態の青いボタンで表示され、設定は即時保存されます。',
        )
        return f'{label}: {base}' if label else base

    def execute(self, context):
        prop_name = str(getattr(self, 'prop_name', '') or '').strip()
        if not _is_allowed_always_on_pref(prop_name):
            self.report({'WARNING'}, tx(getattr(context, 'scene', None), 'Unknown resident setting.', '不明な常時機能設定です。'))
            return {'CANCELLED'}
        owner = _addon_prefs_owner(context)
        if owner is None or not _n_has_prop(owner, prop_name):
            self.report({'WARNING'}, tx(getattr(context, 'scene', None), 'Persistent settings could not be loaded.', '永続設定を読み込めませんでした。'))
            return {'CANCELLED'}
        try:
            setattr(owner, prop_name, not bool(getattr(owner, prop_name)))
        except Exception as exc:
            self.report({'ERROR'}, tx(getattr(context, 'scene', None), 'Failed to change the setting.', '設定の変更に失敗しました。'))
            return {'CANCELLED'}
        _tag_redraw_view3d(context)
        return {'FINISHED'}


def _help_topic_from_title(title_en: str) -> str:
    slug = re.sub(r'[^0-9a-z]+', '_', str(title_en or '').strip().lower()).strip('_')
    return slug or 'smart_shader_root'


def draw_help_button(layout, scene, topic: str, *, text: str | None = None):
    # Keep N-panel help controls compact: always draw an icon-only question button.
    # The localized help label remains available as the operator tooltip/title, but
    # it is not shown in the panel body.
    del text
    previous_context = getattr(layout, 'operator_context', None)
    try:
        layout.operator_context = 'INVOKE_DEFAULT'
    except Exception:
        previous_context = None
    try:
        row = layout.row(align=True)
        row.scale_x = 0.82
        row.scale_y = 1.0
        op = row.operator(SSS_OT_open_help.bl_idname, text='', icon='QUESTION', emboss=True)
        op.topic = str(topic or 'smart_shader_root')
        return op
    except Exception:
        try:
            row = layout.row(align=True)
            row.scale_x = 0.82
            row.scale_y = 1.0
            row.label(text='', icon='QUESTION')
        except Exception:
            pass
        return None
    finally:
        if previous_context is not None:
            try:
                layout.operator_context = previous_context
            except Exception:
                pass


def draw_panel_help_button(layout, context, topic: str):
    scene = getattr(context, 'scene', None)
    row = layout.column(align=True)
    row.alignment = 'RIGHT'
    draw_help_button(row, scene, topic)


def _tooltip_text(scene, title_en: str, title_ja: str, tip_en: str = '', tip_ja: str = '') -> str:
    title = tx(scene, title_en, title_ja)
    tip = tx(scene, tip_en, tip_ja) if (tip_en or tip_ja) else ''
    tip = str(tip or '').strip()
    if tip and tip != title:
        return f'{title}\n{tip}'
    return title


def draw_tooltip_label(layout, scene, title_en: str, title_ja: str, icon: str = 'NONE', tip_en: str = '', tip_ja: str = ''):
    topic = _help_topic_from_title(title_en)
    try:
        row = layout.column(align=True)
        split = row.column(align=True)
        left = split.column(align=True)
        op = left.operator(
            'sss.show_info',
            text=tx(scene, title_en, title_ja),
            icon=icon,
            emboss=False,
        )
        op.tooltip = _tooltip_text(scene, title_en, title_ja, tip_en, tip_ja)
        right = split.column(align=True)
        right.alignment = 'RIGHT'
        draw_help_button(right, scene, topic)
    except Exception:
        fallback = layout.column(align=True)
        kwargs = {'text': tx(scene, title_en, title_ja)}
        if icon and icon != 'NONE':
            kwargs['icon'] = icon
        fallback.label(**kwargs)
        draw_help_button(fallback, scene, topic)

def coverage_lines(scene):
    lines = []
    for item in data.COVERAGE_ITEMS:
        title = tx(scene, item['title_en'], item['title_ja'])
        summary = tx(scene, item['summary_en'], item['summary_ja'])
        lines.append(f'• {title}')
        lines.extend((f'  {line}' for line in wrap_lines(summary, width=64)))
    return lines

def draw_section_hint(layout, scene, en: str, ja: str):
    # Section explanations are exposed from the section-header tooltip helpers.
    return None

def draw_status_dashboard(layout, context):
    scene = context.scene
    mat = core.active_material(context)
    box = layout.box()
    header = box.row(align=True)
    header.label(text=tx(scene, 'Dashboard', _lt('ダッシュボード')), icon='MATERIAL')
    right = header.row(align=True)
    right.alignment = 'RIGHT'
    draw_help_button(right, scene, 'smart_shader_root')
    stats = box.column(align=True)
    if mat:
        stats.label(text=f"{tx(scene, 'Active', _lt('アクティブ'))}: {mat.name}", icon='NODE_MATERIAL')
        stats.label(text=f"{tx(scene, 'Managed', _lt('管理中'))}: {yes_no(scene, bool(mat.get('sss_builder')))}", icon='CHECKMARK' if mat.get('sss_builder') else 'BLANK1')
        stats.label(text=f"{tx(scene, 'Asset', _lt('アセット'))}: {yes_no(scene, bool(getattr(mat, 'asset_data', None)))}", icon='ASSET_MANAGER')
        stats.label(text=f"{tx(scene, 'Protected', _lt('保護'))}: {yes_no(scene, core.is_cleanup_protected(mat))}", icon='LOCKED' if core.is_cleanup_protected(mat) else 'UNLOCKED')
        stats.label(text=f"{tx(scene, 'Nodes', _lt('ノード数'))}: {(len(mat.node_tree.nodes) if mat.use_nodes and mat.node_tree else 0)}", icon='NODETREE')
        stats.label(text=f"{tx(scene, 'Users', _lt('使用オブジェクト数'))}: {len(list(core.iter_scene_material_users(mat)))}", icon='OUTLINER_OB_MESH')
        stats.label(text=f"{tx(scene, 'Missing Textures', _lt('欠損テクスチャ'))}: {core.count_missing_image_nodes(mat)}", icon='IMAGE_DATA')
        stats.label(text=f"{tx(scene, 'Layer Stack', _lt('レイヤースタック'))}: {layers.layer_stack_count(mat)}", icon='MOD_MASK')
        stats.label(text=f"{tx(scene, 'Saved Recipes', _lt('保存済みレシピ'))}: {layers.layer_recipe_count()}", icon='FILE_FOLDER')
        stats.label(text=f"{tx(scene, 'Catalog Entries', _lt('カタログ件数'))}: {catalog.catalog_count()}", icon='ASSET_MANAGER')
    else:
        stats.label(text=tx(scene, 'No active material', _lt('アクティブマテリアルなし')), icon='ERROR')
        stats.label(text=f"{tx(scene, 'Custom Presets', _lt('カスタム数'))}: {core.custom_preset_count()}", icon='FILE_FOLDER')
        stats.label(text=f"{tx(scene, 'Catalog Entries', _lt('カタログ件数'))}: {catalog.catalog_count()}", icon='ASSET_MANAGER')
    world_state = environment.world_hdri_state(context)
    box.label(text=f"{tx(scene, 'World', _lt('ワールド'))}: {tx(scene, world_state['status_en'], world_state['status_ja'])}", icon='WORLD_DATA')
    chips = box.column(align=True)
    chips.prop(scene, 'sss_non_destructive', toggle=True, text=tx(scene, 'Safe', _lt('安全')))
    chips.prop(scene, 'sss_mark_asset', toggle=True, text=tx(scene, 'Asset', _lt('アセット')))
    chips.prop(scene, 'sss_assign_selected', toggle=True, text=tx(scene, 'Assign', _lt('割当')))

def draw_quick_actions(layout, context):
    scene = context.scene
    box = layout.box()
    row = box.row(align=True)
    row.label(text=tx(scene, 'Quick Actions', _lt('クイック操作')), icon='VIEWZOOM')
    right = row.row(align=True)
    right.alignment = 'RIGHT'
    draw_help_button(right, scene, 'quick_actions')
    box.prop(scene, 'sss_quick_action_search')
    row = box.column(align=True)
    row.prop(scene, 'sss_quick_action', text='')
    row.operator('sss.run_action', text=tx(scene, 'Run Quick Action Quick Action', _lt('クイック操作クイック操作実行')), icon='PLAY')
    meta = data.QUICK_ACTION_META.get(getattr(scene, 'sss_quick_action', ''))
    if meta:
        summary_box = box.box()
        summary_box.label(text=tx(scene, 'Selected Action', _lt('選択中の操作')))
        for line in wrap_lines(tx(scene, meta['summary_en'], meta['summary_ja']), width=58):
            if line:
                summary_box.label(text=line)

def draw_compact_workspace(layout, context):
    scene = context.scene
    box = layout.box()
    header = box.column(align=True)
    draw_tooltip_label(header, scene, 'Compact Workspace', _lt('コンパクトワークスペース'), 'TOOL_SETTINGS', 'The main UI keeps the reduced workflow launcher, while All Tools reveals the detailed tools as categorized panels arranged by workflow stage and function.', _lt('メインUIは絞り込んだ代表ワークフローを維持しつつ、「全機能」で詳細ツールを工程別・機能別のカテゴリーパネルとして表示します。'))
    header.prop(scene, 'sss_show_advanced', toggle=True, text=tx(scene, 'All Tools', _lt('全機能')))
    box.prop(scene, 'sss_workspace_recipe', text='')
    recipe = getattr(scene, 'sss_workspace_recipe', 'BUILD_PRESET')
    meta = getattr(data, 'WORKSPACE_RECIPE_META', {}).get(recipe)
    if meta:
        for line in wrap_lines(tx(scene, meta['summary_en'], meta['summary_ja']), width=58):
            if line:
                box.label(text=line)
    if recipe == 'BUILD_PRESET':
        col = box.column(align=True)
        _n_prop(col, context, scene, 'sss_preset_family')
        _n_prop(col, context, scene, 'sss_preset_search')
        _n_prop(col, context, scene, 'sss_preset_name')
        col.prop(scene, 'sss_material_name')
        opts = box.column(align=True)
        opts.prop(scene, 'sss_assign_selected', toggle=True)
        opts.prop(scene, 'sss_mark_asset', toggle=True)
        opts.prop(scene, 'sss_auto_audit_after_build', toggle=True)
        draw_preset_summary(box, context)
    elif recipe == 'FIND_APPLY':
        _n_prop(box, context, scene, 'sss_asset_search_query')
        _n_prop(box, context, scene, 'sss_asset_search_pick')
        result_key = getattr(scene, 'sss_asset_search_pick', '')
        result = None if result_key == finder.ASSET_SEARCH_SENTINEL else finder.find_asset_search_result(result_key, query=getattr(scene, 'sss_asset_search_query', ''))
        summary = finder.asset_result_summary(scene, result)
        for line in wrap_lines(summary, width=58):
            if line:
                box.label(text=line)
    elif recipe == 'IMPORT_TEXTURE_SET':
        _n_prop(box, context, scene, 'sss_texture_search_root')
        _n_prop(box, context, scene, 'sss_texture_set_filter')
        _n_prop(box, context, scene, 'sss_texture_import_mode')
        box.prop(scene, 'sss_material_name')
        opts = box.column(align=True)
        opts.prop(scene, 'sss_assign_selected', toggle=True)
        opts.prop(scene, 'sss_mark_asset', toggle=True)
        opts.prop(scene, 'sss_allow_multi_group_texture_build', toggle=True)
    elif recipe == 'PHOTO_TO_PBR':
        _n_prop(box, context, scene, 'sss_photo_source')
        _n_prop(box, context, scene, 'sss_photo_output_dir')
        row = box.column(align=True)
        row.prop(scene, 'sss_photo_max_size')
        row.prop(scene, 'sss_photo_normal_strength')
        box.prop(scene, 'sss_photo_detail_strength')
        opts = box.column(align=True)
        opts.prop(scene, 'sss_assign_selected', toggle=True)
        opts.prop(scene, 'sss_mark_asset', toggle=True)
    elif recipe == 'QUICK_FIX':
        box.prop(scene, 'sss_target_material_name')
        _n_prop(box, context, scene, 'sss_texture_search_root')
        row = box.column(align=True)
        row.prop(scene, 'sss_texture_force_rewire', toggle=True)
        row.prop(scene, 'sss_auto_audit_after_build', toggle=True)
    elif recipe == 'SCENE_DOCTOR':
        _n_prop(box, context, scene, 'sss_batch_doctor_scope')
        _n_prop(box, context, scene, 'sss_batch_doctor_filter')
        row = box.column(align=True)
        row.prop(scene, 'sss_batch_doctor_limit')
        row.prop(scene, 'sss_batch_doctor_relink_missing', toggle=True)
        if getattr(scene, 'sss_batch_doctor_relink_missing', True):
            _n_prop(box, context, scene, 'sss_texture_search_root')
    elif recipe == 'ASSIGN_TARGET':
        box.prop(scene, 'sss_target_material_name')
    elif recipe == 'BUILD_HDRI_WORLD':
        box.prop(scene, 'sss_hdri_path')
        row = box.column(align=True)
        row.prop(scene, 'sss_hdri_strength')
        row.prop(scene, 'sss_hdri_rotation')
    elif recipe == 'SAVE_CUSTOM':
        box.prop(scene, 'sss_target_material_name')
        _n_prop(box, context, scene, 'sss_custom_preset_name')
    run_row = box.column(align=True)
    run_row.operator('sss.run_workflow', text=tx(scene, 'Run Workflow', _lt('ワークフロー実行')), icon='PLAY')

def draw_feature_explorer(layout, context):
    scene = context.scene
    if not getattr(scene, 'sss_show_advanced', False):
        return
    wrapper = layout.box()
    header = wrapper.column(align=True)
    draw_tooltip_label(header, scene, 'Feature Explorer', _lt('機能エクスプローラー'), 'PREFERENCES', 'Every original function remains available here. Choose a broad group, then open only the detailed module you need so the panel stays compact.', _lt('元バージョンの全機能をここから使えます。大分類を選び、必要な詳細モジュールだけを開くことでパネルをコンパクトに保ちます。'))
    header.prop(scene, 'sss_show_advanced', toggle=True, text=tx(scene, 'Hide', _lt('閉じる')))
    wrapper.prop(scene, 'sss_feature_group')
    wrapper.prop(scene, 'sss_feature_panel', text='')
    panel_id = getattr(scene, 'sss_feature_panel', '')
    if panel_id == 'BUILD_APPLY':
        draw_build_apply_core(wrapper, context)
        draw_custom_library_box(wrapper, context)
    elif panel_id == 'NPR_STUDIO':
        draw_npr_studio(wrapper, context)
    elif panel_id == 'SEARCH_LIBRARY':
        draw_search_library_suite(wrapper, context)
    elif panel_id == 'PHOTO_TO_PBR':
        draw_photo_to_pbr(wrapper, context)
    elif panel_id == 'MATERIAL_MANAGER':
        draw_material_manager_core(wrapper, context)
    elif panel_id == 'SCENE_TOOLS':
        draw_scene_tools_suite(wrapper, context)
    elif panel_id == 'SMART_LAYERS':
        draw_smart_layers(wrapper, context)
    elif panel_id == 'SCENE_VARIANTS':
        draw_scene_variants_box(wrapper, context)
    elif panel_id == 'RELINK_TEXTURES':
        draw_relink_cleanup_core(wrapper, context)
    elif panel_id == 'SCENE_DOCTOR':
        draw_scene_doctor(wrapper, context)
    elif panel_id == 'AUDIT_SUITE':
        draw_audit(wrapper, context)
    elif panel_id == 'HDRI_TOOLS':
        draw_hdri_tools(wrapper, context)
    elif panel_id == 'INTEROP_BUNDLE':
        draw_interop(wrapper, context)
    elif panel_id == 'QUICK_ACTIONS':
        draw_quick_actions(wrapper, context)
    else:
        draw_coverage(wrapper, context)

def draw_section_tabs(layout, context):
    box = layout.box()
    box.prop(context.window_manager, 'sss_ui_section', expand=True)

def draw_preset_summary(layout, context):
    scene = context.scene
    preset_id = scene.sss_preset_name
    box = layout.box()
    draw_tooltip_label(box, scene, 'Preset Overview', _lt('プリセット概要'), 'SHADING_RENDERED', 'Hover over the preset selector for full usage, key controls, compatibility, and tag details. This area keeps only the essential selected-preset status visible.', _lt('プリセット選択欄にマウスを重ねると、使い方、主要コントロール、互換性、タグの詳細を確認できます。この欄では選択中プリセットの要点だけを表示します。'))
    if scene.sss_preset_family == 'CUSTOM':
        entry = core.find_custom_preset(preset_id)
        if not entry:
            box.label(text=tx(scene, 'No custom preset selected.', _lt('カスタムプリセットが選択されていません。')))
            return
        title = entry.get('name', preset_id)
        summary = tx(scene, entry.get('summary_en', ''), entry.get('summary_ja', ''))
        tags = ', '.join(entry.get('tags', []))
        box.label(text=title, icon='CURRENT_FILE')
        for line in wrap_lines(summary, width=58):
            if line:
                box.label(text=line)
        if tags:
            box.label(text=f"{tx(scene, 'Tags', _lt('タグ'))}: {tags}", icon='BOOKMARKS')
        box.label(text=f"{tx(scene, 'Rebuildable', _lt('再構築可能'))}: {yes_no(scene, bool(entry.get('builder')))}", icon='FILE_REFRESH')
        return
    meta = data.PRESET_LIBRARY.get(preset_id)
    if not meta:
        box.label(text=tx(scene, 'No preset information.', _lt('プリセット情報がありません。')))
        return
    box.label(text=tx(scene, meta['label_en'], meta['label_ja']), icon='SHADING_RENDERED')
    info = box.column(align=True)
    info.label(text=f"{tx(scene, 'Compatibility', _lt('互換性'))}: {meta['compat']}", icon='CHECKMARK')
    info.label(text=f"{tx(scene, 'Tags', _lt('タグ'))}: {', '.join(meta.get('tags', [])[:3])}", icon='BOOKMARKS')
    box.separator()

def draw_build_apply_core(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Build & Apply', _lt('生成と適用'), 'TOOL_SETTINGS', 'Choose a preset, review its overview, then create, apply, capture, or save it as a reusable custom entry.', _lt('プリセットを選び、概要を確認してから、新規作成・適用・取り込み・カスタム保存へ進みます。'))
    draw_section_hint(box, scene, 'Choose a preset, review its overview, then create, apply, capture, or save it as a reusable custom entry.', _lt('プリセットを選び、概要を確認してから、新規作成・適用・取り込み・カスタム保存へ進みます。'))
    col = box.column(align=True)
    _n_prop(col, context, scene, 'sss_preset_family')
    _n_prop(col, context, scene, 'sss_preset_search')
    _n_prop(col, context, scene, 'sss_preset_name')
    col.prop(scene, 'sss_material_name')
    draw_preset_summary(col, context)
    actions = box.column(align=True)
    actions.operator('sss.create_preset_material', icon='ADD')
    actions.operator('sss.apply_to_active', icon='FILE_TICK')
    actions.operator('sss.capture_active_material', icon='IMPORT')
    actions.operator('sss.save_custom_preset', icon='CURRENT_FILE')
    if scene.sss_preset_family == 'CUSTOM':
        actions.operator('sss.delete_custom_preset', icon='TRASH')
    options = box.column(align=True)
    options.prop(scene, 'sss_use_fake_user', toggle=True)
    options.prop(scene, 'sss_auto_audit_after_build', toggle=True)
    options.prop(scene, 'sss_auto_layout_after_build', toggle=True)
    options.prop(scene, 'sss_prune_after_build', toggle=True)
    _n_prop(box, context, scene, 'sss_custom_preset_name')

def draw_custom_library_box(layout, context):
    scene = context.scene
    library_box = layout.box()
    library_box.label(text=tx(scene, 'Custom Library', _lt('カスタムライブラリ')), icon='FILE_FOLDER')
    _n_prop(library_box, context, scene, 'sss_custom_library_mode')
    lib_ops = library_box.column(align=True)
    lib_ops.operator('sss.export_custom_library', icon='EXPORT')
    lib_ops.operator('sss.import_custom_library', icon='IMPORT')
    lib_ops.operator('sss.repair_custom_library', icon='TOOL_SETTINGS')

def draw_npr_studio(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Advanced Illustration NPR', _lt('高度イラストNPR'), 'SHADING_RENDERED', 'Eevee-first advanced illustration shader controls for paper, hatch, halftone, specular, reflection, and rim look development.', _lt('Eevee優先の高度イラストシェーダーです。紙感、ハッチ、ハーフトーン、スペキュラ、反射、リムの細かな調整に使います。'))
    draw_section_hint(box, scene, 'This is an original Eevee-first advanced illustration shader module. It keeps the UI compact while exposing deeper paper, hatch, halftone, specular, reflection, and rim controls for print-style or comic-style lookdev.', _lt('これは独自実装のEevee優先・高度イラストシェーダーモジュールです。UIはコンパクトなまま、紙感、ハッチ、ハーフトーン、スペキュラ、反射、リムの細かな制御をまとめて扱えます。'))
    box.prop(scene, 'sss_npr_material_name')
    opts = box.column(align=True)
    opts.prop(scene, 'sss_assign_selected', toggle=True)
    opts.prop(scene, 'sss_use_fake_user', toggle=True)
    opts.prop(scene, 'sss_mark_asset', toggle=True)
    opts.prop(scene, 'sss_auto_audit_after_build', toggle=True)
    zones = box.box()
    zones.label(text=tx(scene, 'Shading Zones', _lt('シェーディングゾーン')), icon='NODE_MATERIAL')
    zones.prop(scene, 'sss_npr_zone_count')
    zones.prop(scene, 'sss_npr_base_color')
    zones.prop(scene, 'sss_npr_threshold_1')
    if scene.sss_npr_zone_count >= 2:
        zones.prop(scene, 'sss_npr_zone2_color')
    if scene.sss_npr_zone_count >= 3:
        zones.prop(scene, 'sss_npr_threshold_2')
        zones.prop(scene, 'sss_npr_zone3_color')
    if scene.sss_npr_zone_count >= 4:
        zones.prop(scene, 'sss_npr_threshold_3')
        zones.prop(scene, 'sss_npr_zone4_color')
    row = zones.column(align=True)
    row.prop(scene, 'sss_npr_shadow_smooth')
    row.prop(scene, 'sss_npr_alpha')
    light = box.box()
    light.label(text=tx(scene, 'Highlight / Reflection / Rim', _lt('ハイライト・反射・リム')), icon='LIGHT')
    light.prop(scene, 'sss_npr_highlight_color')
    row = light.column(align=True)
    row.prop(scene, 'sss_npr_highlight_level')
    row.prop(scene, 'sss_npr_highlight_size')
    row.prop(scene, 'sss_npr_highlight_smooth')
    light.prop(scene, 'sss_npr_reflection_color')
    row = light.column(align=True)
    row.prop(scene, 'sss_npr_reflection_strength')
    row.prop(scene, 'sss_npr_reflection_roughness')
    light.prop(scene, 'sss_npr_rim_color')
    row = light.column(align=True)
    row.prop(scene, 'sss_npr_rim_width')
    row.prop(scene, 'sss_npr_rim_strength')
    surf = box.box()
    surf.label(text=tx(scene, 'Surface FX', _lt('表面FX')), icon='TEXTURE')
    row = surf.column(align=True)
    row.prop(scene, 'sss_npr_detail_scale')
    row.prop(scene, 'sss_npr_detail_normal')
    surf.prop(scene, 'sss_npr_paper_tint')
    row = surf.column(align=True)
    row.prop(scene, 'sss_npr_paper_scale')
    row.prop(scene, 'sss_npr_paper_strength')
    row = surf.column(align=True)
    row.prop(scene, 'sss_npr_hatch_enable', toggle=True)
    row.prop(scene, 'sss_npr_halftone_enable', toggle=True)
    if scene.sss_npr_hatch_enable:
        hatch = surf.box()
        hatch.label(text=tx(scene, 'Hatch Overlay', _lt('ハッチ重ね')), icon='GREASEPENCIL')
        hatch.prop(scene, 'sss_npr_hatch_color')
        row = hatch.column(align=True)
        row.prop(scene, 'sss_npr_hatch_scale')
        row.prop(scene, 'sss_npr_hatch_strength')
        row.prop(scene, 'sss_npr_hatch_softness')
        hatch.prop(scene, 'sss_npr_hatch_angle')
        hatch.prop(scene, 'sss_npr_hatch_cross_enable', toggle=True)
        if scene.sss_npr_hatch_cross_enable:
            row = hatch.column(align=True)
            row.prop(scene, 'sss_npr_hatch_cross_angle')
            row.prop(scene, 'sss_npr_hatch_cross_strength')
    if scene.sss_npr_halftone_enable:
        tone = surf.box()
        tone.label(text=tx(scene, 'Halftone Overlay', _lt('ハーフトーン重ね')), icon='IMAGE_ALPHA')
        tone.prop(scene, 'sss_npr_halftone_color')
        row = tone.column(align=True)
        row.prop(scene, 'sss_npr_halftone_scale')
        row.prop(scene, 'sss_npr_halftone_strength')
        row.prop(scene, 'sss_npr_halftone_softness')
        row = tone.column(align=True)
        row.prop(scene, 'sss_npr_halftone_threshold')
        row.prop(scene, 'sss_npr_halftone_rotation')
    ops = box.column(align=True)
    ops.operator('sss.load_from_active', icon='IMPORT')
    ops.operator('sss.update_material', icon='FILE_REFRESH')
    ops.operator('sss.create_material', icon='ADD')

def draw_build_apply(layout, context):
    draw_build_apply_core(layout, context)
    draw_custom_library_box(layout, context)
    draw_asset_search(layout, context)
    draw_photo_to_pbr(layout, context)
    draw_material_catalog(layout, context)

def draw_asset_search(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Smart Search & Asset Finder', _lt('スマート検索とアセットファインダー'), 'VIEWZOOM', 'Search built-in presets, custom presets, and the material catalog from one field, then use or apply the selected result.', _lt('組み込みプリセット、カスタムプリセット、マテリアルカタログを一つの欄で横断検索し、選択結果を利用または適用します。'))
    _n_prop(box, context, scene, 'sss_asset_search_query')
    _n_prop(box, context, scene, 'sss_asset_search_pick')
    result_key = getattr(scene, 'sss_asset_search_pick', '')
    result = None if result_key == finder.ASSET_SEARCH_SENTINEL else finder.find_asset_search_result(result_key, query=getattr(scene, 'sss_asset_search_query', ''))
    summary = finder.asset_result_summary(scene, result)
    for line in wrap_lines(summary, width=58):
        if line:
            box.label(text=line)
    ops = box.column(align=True)
    ops.operator('sss.use_result', icon='EYEDROPPER')
    ops.operator('sss.apply_result', icon='PLAY')

def draw_photo_to_pbr(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Photo to PBR', _lt('写真からPBR'), 'IMAGE_DATA', 'Generate a conservative starter PBR set from one photo, then build a managed material from the generated maps.', _lt('1枚の写真から保守的なPBRスターターマップを生成し、その結果から管理マテリアルを構築します。'))
    _n_prop(box, context, scene, 'sss_photo_source')
    _n_prop(box, context, scene, 'sss_photo_output_dir')
    controls = box.column(align=True)
    controls.prop(scene, 'sss_photo_max_size')
    controls.prop(scene, 'sss_photo_normal_strength')
    box.prop(scene, 'sss_photo_detail_strength')
    ops = box.column(align=True)
    ops.operator('sss.create_photo_pbr', icon='SHADING_TEXTURE')

def draw_material_catalog(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Material Catalog', _lt('マテリアルカタログ'), 'ASSET_MANAGER', 'Save reusable material snapshots with manifest data, tags, and lightweight search for safe rebuilds later.', _lt('再利用したい材質をマニフェスト情報・タグ・検索用メタデータ付きで保存し、後から安全に再構築できるようにします。'))
    _n_prop(box, context, scene, 'sss_catalog_search')
    _n_prop(box, context, scene, 'sss_catalog_entry_name')
    _n_prop(box, context, scene, 'sss_catalog_tags')
    _n_prop(box, context, scene, 'sss_catalog_pick')
    selected_name = getattr(scene, 'sss_catalog_pick', '') or ''
    entry = catalog.find_catalog_entry(selected_name) if selected_name and selected_name != catalog.CATALOG_SENTINEL else None
    if entry:
        box.label(text=tx(scene, 'Selected Entry Summary', _lt('選択項目の概要')))
        summary = tx(scene, entry.get('summary_en', ''), entry.get('summary_ja', ''))
        for line in wrap_lines(summary, width=58):
            if line:
                box.label(text=line)
        tags = ', '.join(entry.get('tags', [])) or '-'
        usages = ', '.join(entry.get('texture_usages', [])) or '-'
        stats = box.column(align=True)
        stats.label(text=f"{tx(scene, 'Builder', _lt('ビルダー'))}: {entry.get('builder', '-')}", icon='NODETREE')
        stats.label(text=f"{tx(scene, 'Family', _lt('分類'))}: {entry.get('family', '-')}", icon='MATERIAL')
        stats.label(text=f"{tx(scene, 'Nodes', _lt('ノード数'))}: {entry.get('node_count', 0)}", icon='NODETREE')
        stats.label(text=f"{tx(scene, 'Textures', _lt('テクスチャ数'))}: {entry.get('texture_count', 0)}", icon='IMAGE_DATA')
        stats.label(text=f"{tx(scene, 'Missing', _lt('欠損'))}: {entry.get('missing_texture_count', 0)}", icon='ERROR')
        stats.label(text=f"{tx(scene, 'Saved', _lt('保存'))}: {entry.get('saved_at', '-')}", icon='TIME')
        box.label(text=f"{tx(scene, 'Tags', _lt('タグ'))}: {tags}", icon='BOOKMARKS')
        box.label(text=f"{tx(scene, 'Usages', _lt('用途候補'))}: {usages}", icon='TEXTURE')
    else:
        box.label(text=tx(scene, 'No saved catalog entry selected yet.', _lt('まだ保存済みカタログ項目が選択されていません。')))
    ops = box.column(align=True)
    ops.operator('sss.save_entry', icon='CURRENT_FILE')
    ops.operator('sss.apply_entry', icon='FILE_REFRESH')
    ops.operator('sss.delete_entry', icon='TRASH')
    _n_prop(box, context, scene, 'sss_catalog_library_mode')
    lib_ops = box.column(align=True)
    lib_ops.operator('sss.export_library', icon='EXPORT')
    lib_ops.operator('sss.import_library', icon='IMPORT')
    lib_ops.operator('sss.repair_library', icon='TOOL_SETTINGS')

def draw_search_library_suite(layout, context):
    draw_asset_search(layout, context)
    draw_material_catalog(layout, context)

def draw_compare_replace(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Compare & Replace', _lt('比較と置換'), 'UV_SYNC_SELECT', 'Compare a source material against the current manager target, then replace references in the selected scope.', _lt('比較元材質を現在のターゲット材質と見比べ、指定範囲の参照を置換します。'))
    _draw_scene_material_property_selector(box, context, 'sss_compare_source_material_name', 'Compare Source', _lt('比較元'), icon='MATERIAL')
    _n_prop(box, context, scene, 'sss_replace_scope')
    ops = box.column(align=True)
    ops.operator('sss.preview_diff', icon='TEXT')
    ops.operator('sss.replace_with_target', icon='FILE_REFRESH')

def draw_assignment_rules(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Assignment Rules', _lt('割当ルール'), 'SORTBYEXT', 'Save reusable batch-assignment rules that target a stored material name and match objects by name, collection, or material.', _lt('保存済み材質名を対象にし、オブジェクト名・コレクション名・現在割当済み材質で条件分岐できる一括割当ルールを保存します。'))
    _n_prop(box, context, scene, 'sss_rule_name')
    _n_prop(box, context, scene, 'sss_rule_search')
    _n_prop(box, context, scene, 'sss_rule_pick')
    _n_prop(box, context, scene, 'sss_rule_object_pattern')
    _n_prop(box, context, scene, 'sss_rule_collection_pattern')
    _n_prop(box, context, scene, 'sss_rule_current_material_pattern')
    toggles = box.column(align=True)
    toggles.prop(scene, 'sss_rule_use_regex', toggle=True)
    _n_prop(toggles, context, scene, 'sss_rule_scope')
    target = core.get_target_material(context)
    box.label(text=tx(scene, f"Saved target material: {getattr(target, 'name', '-')}", _lt(f"保存対象マテリアル: {getattr(target, 'name', '-')}")), icon='MATERIAL')
    selected = rules.find_assignment_rule(getattr(scene, 'sss_rule_pick', '')) if getattr(scene, 'sss_rule_pick', '') != rules.ASSIGN_RULE_SENTINEL else None
    if selected:
        box.label(text=tx(scene, 'Selected Rule Summary', _lt('選択中ルールの概要')))
        for line in rules.summary_lines(scene, selected):
            box.label(text=line)
    ops = box.column(align=True)
    ops.operator('sss.save_rule', icon='CURRENT_FILE')
    ops.operator('sss.preview_rule', icon='VIEWZOOM')
    ops.operator('sss.apply_rule', icon='FILE_REFRESH')
    ops.operator('sss.delete_rule', icon='TRASH')
    _n_prop(box, context, scene, 'sss_rule_library_mode')
    lib = box.column(align=True)
    lib.operator('sss.export_rule_library', icon='EXPORT')
    lib.operator('sss.import_rule_library', icon='IMPORT')
    lib.operator('sss.repair_rule_library', icon='TOOL_SETTINGS')

def draw_smart_layers(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Smart Layers & Masks', _lt('スマートレイヤーとマスク'), 'MOD_MASK', 'Overlay reusable wear, rust, moss, snow, wetness, or dust layers without rebuilding the base material. AUTO mask mode uses safe utility maps when present.', _lt('ベース材質を作り直さず、摩耗・錆・苔・雪・濡れ・埃のレイヤーを重ねます。自動マスクは既存の安全な補助マップを優先利用します。'))
    draw_section_hint(box, scene, 'Overlay reusable wear, rust, moss, snow, wetness, or dust layers without rebuilding the base material. AUTO mask mode prefers safe imported utility maps when they already exist.', _lt('ベース材質を作り直さずに、摩耗、錆、苔、雪、濡れ、埃のレイヤーを重ねられます。自動マスクは、既に存在する安全な補助マップを優先利用します。'))
    col = box.column(align=True)
    _n_prop(col, context, scene, 'sss_layer_preset')
    _n_prop(col, context, scene, 'sss_layer_mask_mode')
    controls = box.column(align=True)
    controls.prop(scene, 'sss_layer_strength')
    controls.prop(scene, 'sss_layer_noise_scale')
    box.prop(scene, 'sss_layer_mask_contrast')
    meta = layers.layer_preset_meta(scene.sss_layer_preset)
    box.label(text=tx(scene, meta['label_en'], meta['label_ja']), icon='SHADING_RENDERED')
    active_stack = layers.layer_stack_count(core.preferred_material(context))
    box.label(text=tx(scene, f'Current stack: {active_stack} layers', _lt(f'現在のスタック: {active_stack} レイヤー')), icon='MOD_MASK')
    recipe_box = box.box()
    draw_tooltip_label(recipe_box, scene, 'Layer Recipes', _lt('レイヤーレシピ'), 'FILE_FOLDER', 'Save the current smart-layer stack as a reusable Smart Material style recipe, then apply it to other materials non-destructively.', _lt('現在のスマートレイヤースタックを再利用可能なスマートマテリアル風レシピとして保存し、他の材質へ非破壊で適用できます。'))
    _n_prop(recipe_box, context, scene, 'sss_layer_recipe_name')
    _n_prop(recipe_box, context, scene, 'sss_layer_recipe_pick')
    recipe_ops = recipe_box.column(align=True)
    recipe_ops.operator('sss.save_recipe', icon='CURRENT_FILE')
    recipe_ops.operator('sss.apply_recipe', icon='FILE_REFRESH')
    recipe_ops.operator('sss.delete_recipe', icon='TRASH')
    _n_prop(recipe_box, context, scene, 'sss_layer_recipe_library_mode')
    recipe_lib = recipe_box.column(align=True)
    recipe_lib.operator('sss.export_recipe_library', icon='EXPORT')
    recipe_lib.operator('sss.import_recipe_library', icon='IMPORT')
    recipe_lib.operator('sss.repair_recipe_library', icon='TOOL_SETTINGS')
    ops = box.column(align=True)
    ops.operator('sss.apply_layer', icon='MODIFIER')
    ops.operator('sss.add_mask_utilities', icon='NODETREE')

def draw_scene_material_index(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Scene Material Index', _lt('シーン材質インデックス'), 'MATERIAL', 'Browse scene-used, managed-only, or all materials with usage counts, missing-texture alerts, and complexity hints.', _lt('シーン使用中・管理中のみ・全材質を、使用数、欠損テクスチャ、複雑さの目安つきで閲覧します。'))
    _n_prop(box, context, scene, 'sss_inventory_search')
    filters = box.column(align=True)
    _n_prop(filters, context, scene, 'sss_inventory_scope')
    _n_prop(filters, context, scene, 'sss_inventory_sort')
    _n_prop(box, context, scene, 'sss_inventory_pick')
    inventory_pick = sss_properties.scene_raw_enum_value(scene, 'sss_inventory_pick', '')
    entry = None if inventory_pick == inventory.INVENTORY_SENTINEL else inventory.find_inventory_entry(inventory_pick, scene=scene)
    for line in wrap_lines(inventory.inventory_summary(scene, entry), width=58):
        if line:
            box.label(text=line)
    ops = box.column(align=True)
    ops.operator('sss.use_index_pick', icon='EYEDROPPER')
    ops.operator('sss.select_index_users', icon='RESTRICT_SELECT_OFF')

def draw_scene_variants_box(layout, context):
    scene = context.scene
    variants = layout.box()
    draw_tooltip_label(variants, scene, 'Scene Variants', _lt('シーンバリアント'), 'SEQ_STRIP_DUPLICATE', 'Save scene-wide material slot assignments and HDRI state, then re-apply them later as lookdev or shot variants.', _lt('シーン全体の材質スロット割り当てとHDRI状態を保存し、後からルック案やショット別バリアントとして再適用します。'))
    _n_prop(variants, context, scene, 'sss_scene_variant_name')
    _n_prop(variants, context, scene, 'sss_scene_variant_pick')
    var_ops = variants.column(align=True)
    var_ops.operator('sss.save_variant', icon='FILE_TICK')
    var_ops.operator('sss.apply_variant', icon='FILE_REFRESH')
    var_ops.operator('sss.delete_variant', icon='TRASH')
    variant_library = variants.box()
    variant_library.label(text=tx(scene, 'Scene Variant Library', _lt('シーンバリアントライブラリ')), icon='FILE_FOLDER')
    _n_prop(variant_library, context, scene, 'sss_scene_variant_library_mode')
    var_lib_ops = variant_library.column(align=True)
    var_lib_ops.operator('sss.export_variant_library', icon='EXPORT')
    var_lib_ops.operator('sss.import_variant_library', icon='IMPORT')
    var_lib_ops.operator('sss.repair_variant_library', icon='TOOL_SETTINGS')



def _enum_locale_key_for_ui() -> str:
    try:
        return 'ja' if locale_is_japanese() else 'en'
    except Exception:
        return 'en'


def _ui_text_px(text):
    text = str(text or '')
    if not text:
        return 0.0
    key = (_enum_locale_key_for_ui(), text)
    cached = _TEXT_WIDTH_CACHE.get(key)
    if cached is not None:
        return cached
    try:
        import blf  # type: ignore
        font_id = 0
        try:
            blf.size(font_id, 11)
        except TypeError:
            blf.size(font_id, 11, 72)
        width, _height = blf.dimensions(font_id, text)
        value = float(width)
    except Exception:
        value = float(sum(12 if ord(ch) > 127 else 7 for ch in text))
    _TEXT_WIDTH_CACHE[key] = value
    if len(_TEXT_WIDTH_CACHE) > 2048:
        for old_key in list(_TEXT_WIDTH_CACHE.keys())[:512]:
            _TEXT_WIDTH_CACHE.pop(old_key, None)
    return value


def _n_panel_text_px(context, padding_px=72):
    try:
        width = int(getattr(getattr(context, 'region', None), 'width', 0) or 0)
    except Exception:
        width = 0
    if width <= 0:
        width = 240
    return max(64.0, float(width - padding_px))


def _wrap_n_panel_label(context, text, padding_px=72):
    raw = str(text or '').strip()
    if not raw:
        return ['']
    max_px = int(_n_panel_text_px(context, padding_px=padding_px))
    width_bucket = max(64, (max_px // 16) * 16)
    key = (_enum_locale_key_for_ui(), raw, int(padding_px), width_bucket)
    cached = _WRAP_LABEL_CACHE.get(key)
    if cached is not None:
        return list(cached)
    if _ui_text_px(raw) <= max_px:
        lines = (raw,)
    else:
        lines_list = []
        current = ''
        for ch in raw:
            candidate = current + ch
            if current and _ui_text_px(candidate) > max_px:
                head, space, tail = current.rpartition(' ')
                if space and head and ch != ' ' and ch.isascii():
                    lines_list.append(head)
                    current = tail + ch
                else:
                    lines_list.append(current)
                    current = ch.lstrip()
            else:
                current = candidate
        if current:
            lines_list.append(current)
        lines = tuple(lines_list or [raw])
    _WRAP_LABEL_CACHE[key] = lines
    if len(_WRAP_LABEL_CACHE) > 1024:
        for old_key in list(_WRAP_LABEL_CACHE.keys())[:256]:
            _WRAP_LABEL_CACHE.pop(old_key, None)
    return list(lines)


def _draw_wrapped_npanel_label(layout, context, text, icon='NONE', translate=True):
    for index, line in enumerate(_wrap_n_panel_label(context, text)):
        if index == 0 and icon and icon != 'NONE':
            layout.label(text=line, icon=icon, translate=translate)
        else:
            layout.label(text=line, translate=translate)


def _draw_compact_active_material_selector(layout, context):
    scene = getattr(context, 'scene', None)
    obj = _material_slot_capable_object(context)
    col = layout.column(align=True)
    try:
        col.use_property_split = False
        col.use_property_decorate = False
    except Exception:
        pass
    col.label(text=tx(scene, 'Active Object Material', 'アクティブオブジェクト材質'), icon='MATERIAL')
    if obj is None:
        col.label(text=tx(scene, 'No active object. Target-based material tools still work with the saved target material below.', 'アクティブオブジェクトがなくても、下の保存済みターゲット材質を使って対象材質ツールは利用できます。'))
        return
    material = getattr(obj, 'active_material', None)
    if material is not None:
        _draw_wrapped_npanel_label(col, context, str(getattr(material, 'name', '') or ''), icon='NODE_MATERIAL', translate=False)
    else:
        col.label(text=tx(scene, 'No material assigned to the active slot.', 'アクティブスロットにマテリアルがありません。'))
    _draw_material_target_slot_selector(col, context)
    actions = col.column(align=True)
    actions.operator('sss.select_active_material', text=tx(scene, 'Select Existing Material', '既存マテリアル選択'), icon='VIEWZOOM')
    actions.operator('sss.create_active_material', text=tx(scene, 'Create Material', 'マテリアル作成'), icon='ADD')


def _draw_scene_material_property_selector(layout, context, prop_name: str, title_en: str, title_ja: str, *, icon: str='MATERIAL'):
    scene = getattr(context, 'scene', None)
    col = layout.column(align=True)
    _configure_panel_layout(col)
    col.label(text=tx(scene, title_en, title_ja), icon=icon)
    value = str(getattr(scene, prop_name, '') or '').strip() if scene is not None else ''
    _draw_wrapped_npanel_label(col, context, value or tx(scene, 'No material selected', 'マテリアル未選択'), icon='NODE_MATERIAL' if value else 'NONE', translate=False)
    pick = col.column(align=True)
    op = pick.operator('sss.pick_material_field', text=tx(scene, 'Choose Existing Material', '既存マテリアル選択'), icon='VIEWZOOM')
    op.prop_name = str(prop_name)
    try:
        col.prop(scene, prop_name, text=tx(scene, 'Material Name', 'マテリアル名'))
    except Exception:
        pass


def draw_material_manager_core(layout, context, include_graph_cleanup: bool=True):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Material Manager', _lt('マテリアル管理'), 'MATERIAL', 'Pick a target material, then assign, select users, unassign, rebuild, or consolidate duplicates without leaving the panel.', _lt('ターゲット材質を選び、割り当て、使用オブジェクト選択、解除、再構築、重複統合までこの欄で行えます。'))
    draw_section_hint(box, scene, 'Pick a target material, then assign, select users, unassign, rebuild, or consolidate duplicates without leaving the panel.', _lt('ターゲット材質を選び、割り当て、使用オブジェクト選択、解除、再構築、重複統合までこの欄で行えます。'))
    obj = getattr(context, 'object', None)
    _draw_compact_active_material_selector(box, context)
    box.prop(scene, 'sss_non_destructive', toggle=True)
    _draw_scene_material_property_selector(box, context, 'sss_target_material_name', 'Target Material', _lt('対象マテリアル'), icon='MATERIAL')
    box.prop(scene, 'sss_material_name')
    _n_prop(box, context, scene, 'sss_assign_mode')
    _draw_material_target_slot_selector(box, context)
    row = box.column(align=True)
    row.operator('sss.pick_active_material', icon='EYEDROPPER')
    row.operator('sss.set_active_target', icon='RESTRICT_SELECT_OFF')
    row.operator('sss.assign_to_selection', icon='LINK_BLEND')
    row2 = box.column(align=True)
    row2.operator('sss.select_users', icon='RESTRICT_SELECT_OFF')
    row2.operator('sss.unassign_material', icon='X')
    grid = box.column(align=True)
    grid.operator('sss.duplicate_target', icon='DUPLICATE')
    grid.operator('sss.localize_target', icon='MATERIAL')
    grid.operator('sss.localize_per_object', icon='MATERIAL_DATA')
    grid.operator('sss.rename_target', icon='GREASEPENCIL')
    grid.operator('sss.mark_target_asset', icon='ASSET_MANAGER')
    grid.operator('sss.rebuild_target', icon='FILE_REFRESH')
    if include_graph_cleanup:
        grid.operator('sss.auto_layout_nodes', icon='NODETREE')
        grid.operator('sss.prune_unconnected_nodes', icon='TRASH')
    grid.operator('sss.capture_scene_materials', icon='IMPORT')
    grid.operator('sss.mark_used_materials_as_assets', icon='ASSET_MANAGER')
    grid.operator('sss.rebuild_managed_materials', icon='FILE_REFRESH')
    grid.operator('sss.cleanup_slots', icon='NODE_MATERIAL')
    grid.operator('sss.merge_duplicates', icon='COPY_ID')
    grid.operator('sss.protect_target_bundle', icon='LOCKED')
    grid.operator('sss.clear_protection', icon='UNLOCKED')

def draw_scene_tools_suite(layout, context):
    draw_scene_material_index(layout, context)
    draw_compare_replace(layout, context)
    draw_assignment_rules(layout, context)


def draw_material_creation_suite(layout, context):
    draw_panel_help_button(layout, context, 'create_import')
    draw_build_apply_core(layout, context)
    draw_photo_to_pbr(layout, context)
    draw_pbr_lookdev_feature(layout, context)


def draw_library_search_suite(layout, context):
    draw_panel_help_button(layout, context, 'search_libraries')
    draw_asset_search(layout, context)
    draw_material_catalog(layout, context)
    draw_custom_library_box(layout, context)
    draw_material_library_feature(layout, context)


def draw_scene_tools_category(layout, context):
    draw_panel_help_button(layout, context, 'scene_materials_rules')
    draw_scene_material_index(layout, context)
    draw_compare_replace(layout, context)
    draw_assignment_rules(layout, context)


def draw_layers_variants_suite(layout, context):
    draw_panel_help_button(layout, context, 'layers_variants')
    draw_smart_layers(layout, context)
    draw_scene_variants_box(layout, context)


def draw_texture_cleanup_suite(layout, context):
    draw_panel_help_button(layout, context, 'textures_cleanup')
    draw_relink_cleanup_core(layout, context)
    draw_scene_doctor(layout, context)


def draw_material_operations_suite(layout, context):
    draw_panel_help_button(layout, context, 'target_material_operations')
    draw_material_manager_core(layout, context, include_graph_cleanup=False)


def draw_audit_suite(layout, context):
    draw_panel_help_button(layout, context, 'audit_node_debug')
    draw_audit(layout, context, include_report=False)


def draw_workflow_launcher(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Workflow Launcher', _lt('ワークフローランチャー'), 'PLAY', 'Select a guided workflow shortcut, adjust any needed settings in the corresponding category, then run it here.', _lt('ガイド付きワークフローを選び、必要な設定は対応カテゴリで調整してからここでクイック操作実行します。'))
    draw_section_hint(box, scene, 'Select a guided workflow shortcut, adjust any needed settings in the corresponding category above, then run it here. This keeps the workflow command reachable without duplicating the full setting blocks again.', _lt('ガイド付きワークフローのショートカットを選び、必要な設定は上の対応カテゴリで調整してからここでクイック操作実行します。詳細設定ブロックを二重表示せずに、ワークフロー実行だけを到達可能にする構成です。'))
    box.prop(scene, 'sss_workspace_recipe', text='')
    recipe = getattr(scene, 'sss_workspace_recipe', 'BUILD_PRESET')
    meta = getattr(data, 'WORKSPACE_RECIPE_META', {}).get(recipe)
    if meta:
        for line in wrap_lines(tx(scene, meta['summary_en'], meta['summary_ja']), width=58):
            if line:
                box.label(text=line)
    run_row = box.column(align=True)
    run_row.operator('sss.run_workflow', text=tx(scene, 'Run Workflow', _lt('ワークフロー実行')), icon='PLAY')




def _addon_prefs_owner(context):
    try:
        return preferences.addon_preferences_owner(context)
    except Exception:
        return None


def _integrated_tool_label(scene, alias: str) -> str:
    try:
        meta = tool_preferences.tool_meta(alias)
    except Exception:
        meta = {}
    return tx(scene, str(meta.get('display_en') or alias), str(meta.get('display_ja') or alias))


def _allowed_always_on_pref_names() -> set[str]:
    names = {
        'npanel_state_save',
        'integrated_material_library_auto_refresh_on_load',
    }
    try:
        for alias in tuple(tool_preferences.TOOL_ORDER):
            names.add(tool_preferences.prop_name(alias, 'enabled'))
    except Exception:
        pass
    return names


def _is_allowed_always_on_pref(prop_name: str) -> bool:
    return str(prop_name or '').strip() in _allowed_always_on_pref_names()


def _tag_redraw_view3d(context=None) -> None:
    try:
        wm = getattr(context, 'window_manager', None) if context is not None else getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                area_type = str(getattr(area, 'type', '') or '')
                if area_type == 'VIEW_3D':
                    area.tag_redraw()
                    continue
                if area_type == 'NODE_EDITOR':
                    try:
                        space = getattr(getattr(area, 'spaces', None), 'active', None)
                        tree_type = str(getattr(space, 'tree_type', '') or getattr(space, 'ui_type', '') or '')
                    except Exception:
                        tree_type = ''
                    if tree_type == 'ShaderNodeTree':
                        area.tag_redraw()
    except Exception:
        pass


def _draw_bool_pref_row(layout, owner, prop_name: str, label: str, *, icon: str = 'NONE') -> bool:
    if owner is None or not _n_has_prop(owner, prop_name):
        return False
    try:
        enabled = bool(getattr(owner, prop_name))
    except Exception:
        enabled = False
    try:
        row = layout.row(align=True)
        row.scale_y = 0.95
        split = row.split(factor=0.72, align=True)
        left = split.row(align=True)
        left.label(text=label, icon=icon if icon and icon != 'NONE' else 'DOT')
        right = split.row(align=True)
        right.alignment = 'RIGHT'
        right.use_property_split = False
        right.use_property_decorate = False
        right.row(align=True).prop(
            owner,
            prop_name,
            text=tx(None, 'On' if enabled else 'Off', '有効' if enabled else '無効'),
            icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
            toggle=True,
        )
        return True
    except Exception:
        try:
            layout.prop(owner, prop_name, text=label, toggle=True, icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT')
            return True
        except Exception:
            return False


def draw_always_on_toggles(layout, context):
    scene = getattr(context, 'scene', None)
    owner = _addon_prefs_owner(context)
    if owner is None:
        warn = layout.box()
        warn.alert = True
        warn.label(text=tx(scene, 'Persistent settings could not be loaded.', _lt('永続設定を読み込めませんでした。')), icon='ERROR')
        return

    col = layout.column(align=True)
    rows = (
        ('integrated_material_library_auto_refresh_on_load', 'Library Load Refresh', _lt('ライブラリ読込時更新'), 'MATERIAL'),
    )
    for prop, en, ja, icon in rows:
        _draw_bool_pref_row(col, owner, prop, tx(scene, en, ja), icon=icon)

    try:
        def _alias_label(alias: str) -> str:
            return _integrated_tool_label(scene, alias)
        feature_toggle.draw_global_toggles(col, context, alias_label_callback=_alias_label)
    except Exception:
        pass

def draw_settings(layout, context):
    draw_panel_help_button(layout, context, 'settings')
    scene = context.scene
    draw_section_hint(
        layout,
        scene,
        'Persistent Smart Shader storage settings are managed here. Feature-specific settings are placed inside the workflow category where that feature is used.',
        _lt('スマートシェーダーの永続保存設定をここで管理します。機能ごとの設定は、その機能を使うワークフローカテゴリ内に配置しています。'),
    )
    try:
        preferences.draw_storage_settings(layout, context)
    except Exception as exc:
        warn = layout.box()
        warn.alert = True
        warn.label(text=tx(scene, 'Settings UI error', _lt('設定 UI エラー')), icon='ERROR')
        warn.label(text=_exc_text(exc))


def draw_settings_integrated_tools(layout, context):
    draw_settings(layout, context)


def draw_material_library_feature(layout, context):
    try:
        ui_runtime.draw_tool_section(layout, context, 'material_library', default_closed=True)
    except Exception as exc:
        warn = layout.box()
        warn.alert = True
        warn.label(text=tx(context.scene, 'Material Library UI error', _lt('マテリアルライブラリ UI エラー')), icon='ERROR')
        warn.label(text=_exc_text(exc))


def draw_pbr_lookdev_feature(layout, context):
    try:
        ui_runtime.draw_tool_section(layout, context, 'pbr_lookdev', default_closed=True)
    except Exception as exc:
        warn = layout.box()
        warn.alert = True
        warn.label(text=tx(context.scene, 'PBR Lookdev UI error', _lt('PBR ルックデブ UI エラー')), icon='ERROR')
        warn.label(text=_exc_text(exc))


def draw_node_tools_suite(layout, context):
    draw_panel_help_button(layout, context, 'node_tools_presets')
    try:
        ui_runtime.draw_tool_group(
            layout,
            context,
            ('math_controller',),
            default_closed=True,
        )
    except Exception as exc:
        warn = layout.box()
        warn.alert = True
        warn.label(text=tx(context.scene, 'Node Tools UI error', _lt('ノードツール UI エラー')), icon='ERROR')
        warn.label(text=_exc_text(exc))


def draw_quick_actions_suite(layout, context):
    draw_panel_help_button(layout, context, 'quick_actions')
    draw_workflow_launcher(layout, context)
    draw_quick_actions(layout, context)


def draw_category_group(layout, context, title_en: str, title_ja: str, icon: str, callback):
    scene = context.scene
    title = tx(scene, title_en, title_ja)
    topic = _help_topic_from_title(title_en)
    raw_key = str(topic or title_en or title).strip().lower()
    key = 'category_' + re.sub(r'[^0-9a-z_]+', '_', raw_key).strip('_')
    _box, body, _expanded = ui_sections.draw_group(
        layout,
        context,
        key,
        title,
        icon=icon if icon else 'NONE',
        topic=topic,
        default_open=False,
    )
    callback(body, context)



def draw_manifest_exchange(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Manifest Exchange', _lt('マニフェスト相互運用'), 'FILE_CACHE', 'Exports embed OpenPBR, MaterialX, and UsdPreview approximations. Scene manifest import can batch-restore materials, slots, and HDRI world state, preferring referenced texture-set rebuilds before portable fallback.', _lt('エクスポートにはOpenPBR / MaterialX / UsdPreviewの近似情報を埋め込みます。シーンマニフェスト読込では材質・スロット・HDRIワールド状態を一括復元し、参照テクスチャセットからの復元を優先します。'))
    buttons = box.column(align=True)
    buttons.operator('sss.export_manifest', icon='EXPORT')
    buttons.operator('sss.export_scene_manifest', icon='EXPORT')
    buttons.operator('sss.import_manifest', icon='IMPORT')
    buttons.operator('sss.import_scene_manifest', icon='IMPORT')


def draw_exchange_reference_suite(layout, context):
    draw_panel_help_button(layout, context, 'exchange_reference')
    draw_material_bundle(layout, context)
    draw_manifest_exchange(layout, context)
    draw_coverage(layout, context)
    draw_report_box(layout, context)


def draw_manager(layout, context):
    draw_material_manager_core(layout, context)
    draw_scene_material_index(layout, context)
    draw_compare_replace(layout, context)
    draw_assignment_rules(layout, context)
    draw_smart_layers(layout, context)
    draw_scene_variants_box(layout, context)

def draw_hdri_tools(layout, context):
    draw_panel_help_button(layout, context, 'world_hdri')
    scene = context.scene
    hdri = layout.box()
    draw_tooltip_label(hdri, scene, 'HDRI Environment', _lt('HDRI環境'), 'WORLD_DATA', 'Pick an HDRI file, then build or relink the world from this panel for quick lookdev lighting.', _lt('HDRIファイルを指定し、このパネルからワールドを構築または再リンクして素早くルックデブ照明を設定します。'))
    hdri.prop(scene, 'sss_hdri_path')
    row_hdri = hdri.column(align=True)
    row_hdri.prop(scene, 'sss_hdri_strength')
    row_hdri.prop(scene, 'sss_hdri_rotation')
    row_hdri_ops = hdri.column(align=True)
    row_hdri_ops.operator('sss.build_world', text=tx(scene, 'Build HDRI World', _lt('HDRIワールド構築')), icon='WORLD_DATA')
    row_hdri_ops.operator('sss.relink_world', icon='FILE_REFRESH')
    state = environment.world_hdri_state(context)
    hdri.label(text=tx(scene, state['status_en'], state['status_ja']), icon='CHECKMARK' if not state['missing'] and state['has_hdri'] else 'ERROR')
    draw_hdri_search(hdri, context)

def draw_relink_cleanup_core(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Relink & Cleanup', _lt('再リンクと掃除'), 'FILEBROWSER', 'Use one folder for relinking, texture-set import, library scan/build, color-space repair, and auto-wiring. The filter can isolate one asset set inside a larger root.', _lt('一つのフォルダを基点に、再リンク、テクスチャセット構築、ライブラリ診断・構築、色空間補正、自動配線を行います。絞込文字列で大きなフォルダ内の対象セットを限定できます。'))
    draw_section_hint(box, scene, 'Use one folder for relinking, single texture-set import, whole-library scan/build, color-space repair, and auto-wiring. The optional filter helps isolate one asset set or narrow a larger library root.', _lt('一つのフォルダを基点に、再リンク、単体テクスチャセット構築、ライブラリ一括診断・構築、色空間補正、自動配線をまとめて行えます。絞込文字列を使うと大きなフォルダから一つのセットだけ、または対象ライブラリだけを拾いやすくなります。'))
    _n_prop(box, context, scene, 'sss_texture_scope')
    _n_prop(box, context, scene, 'sss_texture_search_root')
    _n_prop(box, context, scene, 'sss_texture_set_filter')
    _n_prop(box, context, scene, 'sss_texture_import_mode')
    box.prop(scene, 'sss_allow_multi_group_texture_build', toggle=True)
    box.prop(scene, 'sss_texture_batch_limit')
    row = box.column(align=True)
    row.operator('sss.scan_set', icon='VIEWZOOM')
    row.operator('sss.build_from_set', icon='SHADING_TEXTURE')
    row.operator('sss.relink_textures', icon='FILE_REFRESH')
    row.prop(scene, 'sss_cleanup_recursive', toggle=True)
    batch = box.column(align=True)
    batch.operator('sss.scan_library', icon='OUTLINER_COLLECTION')
    batch.operator('sss.build_library', icon='ASSET_MANAGER')
    box.prop(scene, 'sss_texture_force_rewire', toggle=True)
    tools = box.column(align=True)
    tools.operator('sss.standardize_color_space', icon='IMAGE_RGB')
    tools.operator('sss.auto_wire_textures', icon='NODE_MATERIAL')
    tools.operator('sss.preview_cleanup', icon='VIEWZOOM')
    tools.operator('sss.cleanup_unused_data', icon='TRASH')

def draw_relink_cleanup(layout, context):
    draw_relink_cleanup_core(layout, context)
    draw_hdri_tools(layout, context)
    draw_scene_doctor(layout, context)

def draw_scene_doctor(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Scene Doctor', _lt('シーンドクター'), 'TOOL_SETTINGS', 'Preview or batch-repair materials in the chosen scope for recovery, cleanup, and larger lookdev scenes.', _lt('指定範囲の材質をプレビューまたは一括修復し、復旧・掃除・大きめのルックデブシーンの整理に使います。'))
    _n_prop(box, context, scene, 'sss_batch_doctor_scope')
    _n_prop(box, context, scene, 'sss_batch_doctor_filter')
    row = box.column(align=True)
    row.prop(scene, 'sss_batch_doctor_limit')
    row.prop(scene, 'sss_batch_doctor_relink_missing', toggle=True)
    if getattr(scene, 'sss_batch_doctor_relink_missing', True):
        _n_prop(box, context, scene, 'sss_texture_search_root')
    ops = box.column(align=True)
    ops.operator('sss.preview_repair', icon='VIEWZOOM')
    ops.operator('sss.run_repair', icon='TOOL_SETTINGS')

def draw_hdri_search(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'HDRI Library Browser', _lt('HDRIライブラリブラウザ'), 'FILE_FOLDER', 'Search an HDRI library by name or folder, then send the result to the world target or apply it immediately.', _lt('HDRIライブラリを名前やフォルダで検索し、現在のワールド構築対象へ反映、または即時適用します。'))
    box.prop(scene, 'sss_hdri_library_root')
    box.prop(scene, 'sss_hdri_search')
    box.prop(scene, 'sss_hdri_pick')
    entry_key = getattr(scene, 'sss_hdri_pick', '')
    entry = None if entry_key == environment.HDRI_SEARCH_SENTINEL else environment.find_hdri_candidate(entry_key, scene=scene)
    summary = environment.hdri_candidate_summary(scene, entry)
    for line in wrap_lines(summary, width=58):
        if line:
            box.label(text=line)
    ops = box.column(align=True)
    ops.operator('sss.use_candidate', icon='EYEDROPPER')
    ops.operator('sss.apply_candidate', icon='WORLD_DATA')

def draw_audit(layout, context, include_report: bool=True):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Audit & Safety', _lt('監査と安全'), 'CHECKMARK', 'Audit the current graph. Library audit, normalization, and self-check help recover broken outputs and imported materials.', _lt('現在のグラフを点検します。ライブラリ監査、正規化、自己診断は壊れた出力や取り込み材質の復旧を助けます。'))
    draw_section_hint(box, scene, 'Audit checks the current graph, while library audit, normalization, and self-check help recover from broken outputs and imported materials.', _lt('監査は現在のグラフを点検し、ライブラリ監査、正規化、自己診断は壊れた出力や取り込み材質の復旧を助けます。'))
    grid = box.column(align=True)
    grid.operator('sss.audit_active_material', icon='VIEWZOOM')
    grid.operator('sss.audit_library', icon='OUTLINER_COLLECTION')
    grid.operator('sss.normalize_output', icon='NODE_MATERIAL')
    grid.operator('sss.quick_fix_material', icon='TOOL_SETTINGS')
    grid.operator('sss.run_self_check', icon='SYSTEM')
    grid.operator('sss.add_osl_helper', icon='TEXT')
    grid.operator('sss.auto_layout_nodes', icon='NODETREE')
    grid.operator('sss.prune_unconnected_nodes', icon='TRASH')
    draw_node_lens(box, context)
    if include_report:
        draw_report_box(box, context)

def draw_node_lens(layout, context):
    scene = context.scene
    try:
        _n_dynamic_enum_sanitize(context)
    except Exception:
        pass
    material = core.preferred_material(context)
    box = layout.box()
    draw_tooltip_label(box, scene, 'Node Lens', _lt('ノードレンズ'), 'NODETREE', 'Inspect the current node graph by name, type, image, and guessed usage for larger material debugging.', _lt('現在のノードグラフを、名前、種類、画像、用途推定で確認し、大きな材質のデバッグに使います。'))
    box.prop(scene, 'sss_node_query')
    box.prop(scene, 'sss_node_pick')
    if material is not None and getattr(material, 'use_nodes', False) and getattr(material, 'node_tree', None):
        node_name = sss_properties._safe_scene_get_value(scene, 'sss_node_pick', '')
        node = None if node_name == finder.NODE_PICK_SENTINEL else finder.find_node(material, node_name)
        summary = finder.node_summary_text(scene, material, node)
        for line in wrap_lines(summary, width=58):
            if line:
                box.label(text=line)
        ops = box.column(align=True)
        ops.operator('sss.select_node', icon='RESTRICT_SELECT_OFF')
        ops.operator('sss.write_node_report', icon='TEXT')
    else:
        box.label(text=tx(scene, 'No node-based material is available for inspection.', _lt('調査できるノードベース材質がありません。')))

def draw_report_box(layout, context):
    scene = context.scene
    report_box = layout.box()
    header = report_box.column(align=True)
    split = header.column(align=True)
    split.label(text=tx(scene, 'Latest Report', _lt('最新レポート')), icon='TEXT')
    right = split.column(align=True)
    right.alignment = 'RIGHT'
    draw_help_button(right, scene, 'audit_safety')
    report = scene.sss_last_report.strip()
    if not report:
        report_box.label(text=tx(scene, 'No report yet.', _lt('まだレポートはありません。')))
    else:
        for line in wrap_lines(report, width=62):
            if line:
                report_box.label(text=line)

def draw_material_bundle(layout, context):
    scene = context.scene
    box = layout.box()
    draw_tooltip_label(box, scene, 'Portable Material Bundle', _lt('ポータブル材質バンドル'), 'FILE_CACHE', 'Package the current material and reachable textures into one zip bundle, then restore it later from the embedded manifest.', _lt('現在の材質と到達可能なテクスチャを一つのzip バンドルにまとめ、後から埋め込みマニフェスト経由で復元します。'))
    ops = box.column(align=True)
    ops.operator('sss.export_bundle', icon='EXPORT')
    ops.operator('sss.import_bundle', icon='IMPORT')

def draw_interop(layout, context, include_report: bool=True):
    draw_material_bundle(layout, context)
    draw_manifest_exchange(layout, context)
    if include_report:
        draw_report_box(layout, context)

def draw_coverage(layout, context):
    scene = context.scene
    box = layout.box()
    header = box.column(align=True)
    draw_tooltip_label(header, scene, 'Coverage Notes', _lt('カバレッジノート'), 'BOOKMARKS', 'Shows how the add-on merges the attached document tool families into Blender-side superset workflows.', _lt('添付ドキュメントにある各ツール群をBlender側の上位互換ワークフローへどう統合したかを示します。'))
    header.operator('sss.write_coverage_report', text='', icon='TEXT', emboss=True)
    box.label(text=tx(scene, f"Document tools mapped: {getattr(data, 'DOC_TOOL_COUNT', 0)}", _lt(f"対応元ツール数: {getattr(data, 'DOC_TOOL_COUNT', 0)}")), icon='CHECKMARK')
    box.label(text=tx(scene, f'Coverage groups: {len(data.COVERAGE_ITEMS)}', _lt(f'統合グループ数: {len(data.COVERAGE_ITEMS)}')), icon='CHECKMARK')
    for item in data.COVERAGE_ITEMS[:6]:
        sub = box.box()
        title = tx(scene, item['title_en'], item['title_ja'])
        summary = tx(scene, item['summary_en'], item['summary_ja'])
        for line in wrap_lines(title, width=56):
            if line:
                sub.label(text=line, icon='RIGHTARROW_THIN')
        for line in wrap_lines(summary, width=56):
            if line:
                sub.label(text=line)
    matrix_exists = bool(core.read_bundled_text(data.FEATURE_MATRIX_FILE).strip())
    source_exists = bool(core.read_bundled_text(getattr(data, 'DOC_SOURCE_INDEX_FILE', '')).strip())
    box.label(text=tx(scene, f'Bundled coverage matrix: {yes_no(scene, matrix_exists)}', _lt(f'同梱カバレッジ表: {yes_no(scene, matrix_exists)}')), icon='TEXT')
    box.label(text=tx(scene, f'Bundled source index: {yes_no(scene, source_exists)}', _lt(f'同梱ソース索引: {yes_no(scene, source_exists)}')), icon='TEXT')

def draw_current_section(layout, context):
    section = context.window_manager.sss_ui_section
    if section == 'BUILD':
        draw_build_apply(layout, context)
    elif section == 'MANAGE':
        draw_manager(layout, context)
    elif section == 'RELINK':
        draw_relink_cleanup(layout, context)
    elif section == 'AUDIT':
        draw_audit(layout, context)
    elif section == 'INTEROP':
        draw_interop(layout, context)
    else:
        draw_coverage(layout, context)

def draw_all(layout, context):
    draw_category_group(layout, context, 'Settings', '設定', 'PREFERENCES', draw_settings)
    draw_category_group(layout, context, 'Create & Import', '生成と取り込み', 'IMPORT', draw_material_creation_suite)
    draw_category_group(layout, context, 'Search & Libraries', '検索とライブラリ', 'VIEWZOOM', draw_library_search_suite)
    draw_category_group(layout, context, 'NPR Studio', 'NPRスタジオ', 'SHADING_RENDERED', draw_npr_studio)
    draw_category_group(layout, context, 'Target Operations', '対象マテリアル操作', 'MATERIAL', draw_material_operations_suite)
    draw_category_group(layout, context, 'Scene Materials & Rules', 'シーン材質とルール', 'MATERIAL', draw_scene_tools_category)
    draw_category_group(layout, context, 'Layers & Variants', 'レイヤーとバリアント', 'MOD_MASK', draw_layers_variants_suite)
    draw_category_group(layout, context, 'World & HDRI', 'ワールドとHDRI', 'WORLD_DATA', draw_hdri_tools)
    draw_category_group(layout, context, 'Textures & Cleanup', 'テクスチャとクリーンアップ', 'FILEBROWSER', draw_texture_cleanup_suite)
    draw_category_group(layout, context, 'Math Controller & Node Reports', '数式コントローラーとノードレポート', 'NODETREE', draw_node_tools_suite)
    draw_category_group(layout, context, 'Audit & Node Debug', '監査とノード調査', 'CHECKMARK', draw_audit_suite)
    draw_category_group(layout, context, 'Exchange & Reference', '受け渡しと参照', 'FILE_CACHE', draw_exchange_reference_suite)
    draw_category_group(layout, context, 'Quick Actions', 'クイック操作', 'PLAY', draw_quick_actions_suite)

def draw_feature_explorer_controls(layout, context):
    scene = context.scene
    column = layout.column(align=True)
    row = column.column(align=True)
    row.prop(scene, 'sss_show_advanced', toggle=True, text=tx(scene, 'All Tools', _lt('全機能')))
    if not getattr(scene, 'sss_show_advanced', False):
        return None
    column.prop(scene, 'sss_feature_group')
    group_meta = getattr(data, 'FEATURE_BROWSER_GROUP_META', {}).get(getattr(scene, 'sss_feature_group', ''))
    if group_meta:
        summary = column.box()
        summary.label(text=tx(scene, group_meta['label_en'], group_meta['label_ja']), icon='BOOKMARKS')
        for line in wrap_lines(tx(scene, group_meta['summary_en'], group_meta['summary_ja']), width=58):
            if line:
                summary.label(text=line)
    column.prop(scene, 'sss_feature_panel', text='')
    return getattr(scene, 'sss_feature_panel', '')

def _operator_catalog_entries():
    items = []
    seen = set()
    for cls in getattr(sss_operators, 'CLASSES', ()):
        op_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not op_id or op_id in seen:
            continue
        seen.add(op_id)
        label = str(getattr(cls, 'bl_label', '') or op_id).strip() or op_id
        desc = str(getattr(cls, 'bl_description', '') or '').strip()
        items.append((op_id, label, desc))
    items.sort(key=lambda item: (item[1].lower(), item[0].lower()))
    return items

def draw_operator_catalog(layout, context):
    scene = context.scene
    box = layout.box()
    flow = box.column(align=True)
    for op_id, label, _desc in _operator_catalog_entries():
        try:
            flow.operator(op_id, text=label)
        except Exception:
            flow.label(text=label, icon='ERROR')

def draw_selected_feature_panel(layout, context, panel_id: str | None=None):
    scene = context.scene
    panel_id = panel_id or getattr(scene, 'sss_feature_panel', '')
    if panel_id == 'BUILD_APPLY':
        draw_build_apply_core(layout, context)
        draw_custom_library_box(layout, context)
    elif panel_id == 'NPR_STUDIO':
        draw_npr_studio(layout, context)
    elif panel_id == 'SEARCH_LIBRARY':
        draw_search_library_suite(layout, context)
    elif panel_id == 'PHOTO_TO_PBR':
        draw_photo_to_pbr(layout, context)
    elif panel_id == 'MATERIAL_MANAGER':
        draw_material_manager_core(layout, context)
    elif panel_id == 'SCENE_TOOLS':
        draw_scene_tools_suite(layout, context)
    elif panel_id == 'SMART_LAYERS':
        draw_smart_layers(layout, context)
    elif panel_id == 'SCENE_VARIANTS':
        draw_scene_variants_box(layout, context)
    elif panel_id == 'RELINK_TEXTURES':
        draw_relink_cleanup_core(layout, context)
    elif panel_id == 'SCENE_DOCTOR':
        draw_scene_doctor(layout, context)
    elif panel_id == 'AUDIT_SUITE':
        draw_audit(layout, context)
    elif panel_id == 'HDRI_TOOLS':
        draw_hdri_tools(layout, context)
    elif panel_id == 'INTEROP_BUNDLE':
        draw_interop(layout, context)
    elif panel_id == 'QUICK_ACTIONS':
        draw_quick_actions(layout, context)
    else:
        draw_coverage(layout, context)

def draw_feature_group_workspace(layout, context, group_id: str):
    scene = context.scene
    panel_groups = getattr(data, 'FEATURE_BROWSER_PANEL_GROUPS', {})
    valid_ids = tuple(panel_groups.get(group_id, ()))
    panel_id = getattr(scene, 'sss_feature_panel', '')
    if valid_ids and panel_id not in valid_ids:
        panel_id = valid_ids[0]
    draw_selected_feature_panel(layout, context, panel_id=panel_id)

def draw_properties_root_summary(layout, context, include_action_chips: bool=True):
    scene = getattr(context, 'scene', None)
    obj = _safe_active_object(context)
    _draw_compact_active_material_selector(layout, context)
    info = layout.box()
    if obj is None:
        info.label(text=tx(scene, 'No active object. Scene-level tools still work here, and target-based material tools remain available below.', _lt('アクティブオブジェクトがありません。シーン単位のツールはここで使え、ターゲットベースの材質ツールも下から利用できます。')))
    else:
        info.label(text=f"{tx(scene, 'Active Object', _lt('アクティブオブジェクト'))}: {obj.name}", icon='OBJECT_DATA')
        info.label(text=f"{tx(scene, 'Object Type', _lt('オブジェクト種類'))}: {getattr(obj, 'type', 'UNKNOWN')}")
    try:
        mat = getattr(obj, 'active_material', None) if obj is not None else None
    except Exception:
        mat = None
    if mat is not None:
        info.label(text=f"{tx(scene, 'Active Material', _lt('アクティブマテリアル'))}: {mat.name}", icon='MATERIAL')
    else:
        target_name = getattr(scene, 'sss_target_material_name', '').strip()
        if target_name:
            info.label(text=f"{tx(scene, 'Target Material', _lt('ターゲット材質'))}: {target_name}", icon='NODE_MATERIAL')
        else:
            info.label(text=tx(scene, 'No active material. Use Build workflows or choose a saved target material.', _lt('アクティブマテリアルがありません。構築ワークフローを使うか、保存済みターゲット材質を選んでください。')))
    world_state = environment.world_hdri_state(context)
    info.label(text=f"{tx(scene, 'World', _lt('ワールド'))}: {tx(scene, world_state['status_en'], world_state['status_ja'])}", icon='WORLD_DATA')
    if include_action_chips:
        chips = layout.column(align=True)
        chips.prop(scene, 'sss_non_destructive', toggle=True, text=tx(scene, 'Safe', _lt('安全')))
        chips.prop(scene, 'sss_assign_selected', toggle=True, text=tx(scene, 'Assign', _lt('割当')))
        chips.prop(scene, 'sss_mark_asset', toggle=True, text=tx(scene, 'Asset', _lt('アセット')))

def _configure_panel_layout(layout):
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass


def _safe_category_draw(panel, context, callback):
    try:
        _configure_panel_layout(panel.layout)
    except Exception:
        return None
    return _safe_panel_draw(panel, context, callback)


class _SSS_NPanelBase:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Shader'
    _sss_target_editor_key = 'VIEW_3D'
    _smart_tools_manager_editor_key = 'VIEW_3D'

    @classmethod
    def poll(cls, context):
        if _UI_SHUTTING_DOWN:
            return False
        return _is_stable_panel_context(context, getattr(cls, '_sss_target_editor_key', 'VIEW_3D'))


class _SSS_NPanelEditorBase:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Shader'
    _sss_target_editor_key = 'VIEW_3D'
    _smart_tools_manager_editor_key = 'VIEW_3D'

    @classmethod
    def poll(cls, context):
        if _UI_SHUTTING_DOWN:
            return False
        return _is_stable_panel_context(context, getattr(cls, '_sss_target_editor_key', 'VIEW_3D'))


class _SSS_NPanelShaderEditorBase(_SSS_NPanelEditorBase):
    bl_space_type = 'NODE_EDITOR'
    _sss_target_editor_key = 'SHADER_EDITOR'
    _smart_tools_manager_editor_key = 'SHADER_EDITOR'


def draw_always_on_toggles_group(layout, context):
    scene = getattr(context, 'scene', None)
    owner = _addon_prefs_owner(context)
    box = layout.box()
    is_open = bool(getattr(owner, 'show_always_on_toggles', False)) if owner is not None else False

    header = box.split(factor=0.88, align=True)
    left = header.row(align=True)
    if owner is not None and _n_has_prop(owner, 'show_always_on_toggles'):
        left.prop(
            owner,
            'show_always_on_toggles',
            text='',
            icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT',
            emboss=True,
        )
    else:
        left.label(text='', icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT')
    left.label(text=tx(scene, 'Resident Feature Toggles', '常時機能切り替え'), icon='TIME')
    right = header.row(align=True)
    right.alignment = 'RIGHT'
    draw_help_button(right, scene, 'always_on_toggles')

    if not is_open:
        return
    draw_always_on_toggles(box, context)


def draw_npanel_root(layout, context):
    draw_panel_help_button(layout, context, 'smart_shader_root')
    draw_always_on_toggles_group(layout, context)
    draw_properties_root_summary(layout, context)


class SSS_PT_shader_tools(_SSS_NPanelBase, Panel):
    def draw_header_preset(self, context):
        draw_help_button(self.layout, getattr(context, 'scene', None), 'smart_shader_root')

    bl_idname = 'SSS_PT_shader_tools'
    bl_label = _lt('Smart Shader', 'Smart Shader')
    bl_description = _lt('Show Smart Shader settings and tools in the standard 3D View N-panel.', 'スマートシェーダーの設定とツールを通常の 3D ビュー N パネルに表示します。')
    bl_order = 0
    _smart_tools_manager_tool_key = 'SMART_SHADER'
    _smart_tools_manager_native_npanel_root = True

    def draw(self, context):
        _safe_category_draw(self, context, draw_npanel_root)


class SSS_PT_shader_settings(_SSS_NPanelBase, Panel):
    bl_idname = 'SSS_PT_shader_settings'
    bl_label = _lt('Shader Settings', 'シェーダー設定')
    bl_description = _lt('JP: スマートシェーダーの保存先や基本設定を表示します。\nEN: Show Smart Shader storage and basic settings.')
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 10

    def draw(self, context):
        _safe_category_draw(self, context, draw_settings)


class SSS_PT_material_creation_and_import(_SSS_NPanelBase, Panel):
    bl_idname = 'SSS_PT_material_creation_and_import'
    bl_label = _lt('Material Creation & Import', 'マテリアル生成・取込')
    bl_description = _lt('JP: マテリアル生成、写真からPBR化、PBR ルックデブ をまとめて表示します。\nEN: Show material creation, photo-to-PBR, and PBR Lookdev tools.')
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 20

    def draw(self, context):
        _safe_category_draw(self, context, draw_material_creation_suite)


class SSS_PT_asset_search_and_libraries(_SSS_NPanelBase, Panel):
    bl_idname = 'SSS_PT_asset_search_and_libraries'
    bl_label = _lt('Asset Search & Libraries', 'アセット検索・ライブラリ')
    bl_description = _lt('JP: マテリアル検索、カタログ、カスタムライブラリ、マテリアルライブラリを表示します。\nEN: Show material search, catalog, custom library, and Material Library tools.')
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 30

    def draw(self, context):
        _safe_category_draw(self, context, draw_library_search_suite)


class SSS_PT_npr_studio(_SSS_NPanelBase, Panel):
    bl_idname = 'SSS_PT_npr_studio'
    bl_label = _lt('NPR Studio', 'NPRスタジオ')
    bl_description = _lt('JP: NPR・トゥーン系マテリアル制作機能を表示します。\nEN: Show NPR and toon material tools.')
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 40

    def draw(self, context):
        _safe_category_draw(self, context, draw_npr_studio)


class SSS_PT_material_operations(_SSS_NPanelBase, Panel):
    bl_idname = 'SSS_PT_material_operations'
    bl_label = _lt('Material Operations', 'マテリアル操作')
    bl_description = _lt('JP: 選択・保存した対象マテリアルへの割当、複製、更新、整理操作を表示します。\nEN: Show assignment, duplication, update, and cleanup operations for the target material.')
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 50

    def draw(self, context):
        _safe_category_draw(self, context, draw_material_operations_suite)


class SSS_PT_scene_material_rules(_SSS_NPanelBase, Panel):
    bl_idname = 'SSS_PT_scene_material_rules'
    bl_label = _lt('Scene Material Rules', 'シーンマテリアルルール')
    bl_description = _lt('JP: シーン内マテリアル一覧、比較置換、割当ルールを表示します。\nEN: Show scene material index, compare/replace, and assignment-rule tools.')
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 60

    def draw(self, context):
        _safe_category_draw(self, context, draw_scene_tools_category)


class SSS_PT_layer_variants(_SSS_NPanelBase, Panel):
    bl_idname = 'SSS_PT_layer_variants'
    bl_label = _lt('Layer Variants', 'レイヤーバリアント')
    bl_description = _lt('JP: スマートレイヤー、レイヤーレシピ、シーンバリアントを表示します。\nEN: Show smart layers, layer recipes, and scene variants.')
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 70

    def draw(self, context):
        _safe_category_draw(self, context, draw_layers_variants_suite)


class SSS_PT_world_hdri(_SSS_NPanelBase, Panel):
    bl_idname = 'SSS_PT_world_hdri'
    bl_label = _lt('World HDRI', 'ワールドHDRI')
    bl_description = _lt('JP: ワールド環境、HDRI、Lookdev 用ライト設定を表示します。\nEN: Show world environment, HDRI, and lookdev lighting tools.')
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 80

    def draw(self, context):
        _safe_category_draw(self, context, draw_hdri_tools)


class SSS_PT_texture_cleanup(_SSS_NPanelBase, Panel):
    bl_idname = 'SSS_PT_texture_cleanup'
    bl_label = _lt('Texture Cleanup', 'テクスチャクリーンアップ')
    bl_description = _lt('JP: テクスチャ再リンク、欠損チェック、シーンクリーンアップを表示します。\nEN: Show texture relinking, missing-texture checks, and scene cleanup tools.')
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 90

    def draw(self, context):
        _safe_category_draw(self, context, draw_texture_cleanup_suite)


class SSS_PT_node_tools_and_presets(_SSS_NPanelBase, Panel):
    bl_idname = 'SSS_PT_node_tools_and_presets'
    bl_label = _lt('Math Controller & Node Reports', '数式コントローラー・ノードレポート')
    bl_description = _lt('Show the math controller and node inspection reports.', '数式コントローラーとノード調査レポートを表示します。')
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 100

    def draw(self, context):
        _safe_category_draw(self, context, draw_node_tools_suite)


class SSS_PT_node_audit_and_debug(_SSS_NPanelBase, Panel):
    bl_idname = 'SSS_PT_node_audit_and_debug'
    bl_label = _lt('Node Audit & Debug', 'ノード監査・デバッグ')
    bl_description = _lt('JP: マテリアル監査、ノード調査、レポート確認を表示します。\nEN: Show material audit, node inspection, and report tools.')
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 110

    def draw(self, context):
        _safe_category_draw(self, context, draw_audit_suite)


class SSS_PT_data_exchange_and_reference(_SSS_NPanelBase, Panel):
    bl_idname = 'SSS_PT_data_exchange_and_reference'
    bl_label = _lt('Data Exchange & Reference', 'データ受け渡し・参照')
    bl_description = _lt('JP: マテリアルバンドル、マニフェスト、参照情報、レポート出力を表示します。\nEN: Show material bundle, manifest, reference, and report-export tools.')
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 120

    def draw(self, context):
        _safe_category_draw(self, context, draw_exchange_reference_suite)


class SSS_PT_quick_actions(_SSS_NPanelBase, Panel):
    bl_idname = 'SSS_PT_quick_actions'
    bl_label = _lt('Quick Actions', 'クイック操作')
    bl_description = _lt('JP: ワークフローランチャーとクイック操作を表示します。\nEN: Show the workflow launcher and quick actions.')
    bl_parent_id = ""
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 130

    def draw(self, context):
        _safe_category_draw(self, context, draw_quick_actions_suite)



# -----------------------------------------------------------------------------
# N-panel complete single-column UI rebuild
# -----------------------------------------------------------------------------
# These functions intentionally override the earlier panel draw functions.  They
# use only vertical cards, plain StringProperty fields, and search-popup operators.
# Blender's prop_search/template_ID material browser is not used here because it
# can draw the wide "browse linked material" control outside a narrow N-panel.


def _n_has_prop(owner, prop_name: str) -> bool:
    if owner is None or not prop_name:
        return False
    try:
        props = getattr(getattr(owner, 'bl_rna', None), 'properties', None)
    except Exception:
        props = None
    if props is None:
        return False
    try:
        return props.get(str(prop_name)) is not None
    except Exception:
        pass
    try:
        return str(prop_name) in props.keys()
    except Exception:
        return False


def _n_compact(layout):
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    return layout


def _n_card(layout, context, title_en: str, title_ja: str, icon: str = 'NONE', topic: str = ''):
    scene = getattr(context, 'scene', None)
    title = tx(scene, title_en, title_ja)
    raw_key = str(topic or title_en or title_ja or title or 'section').strip().lower()
    key = 'card_' + re.sub(r'[^0-9a-z_]+', '_', raw_key).strip('_')
    _box, body, _expanded = ui_sections.draw_group(
        layout,
        context,
        key,
        title,
        icon=icon if icon else 'NONE',
        topic=str(topic or _help_topic_from_title(title_en) or '').strip(),
        default_open=False,
    )
    return _n_compact(body)



def _n_section(layout, context, title_en: str, title_ja: str, icon: str = 'NONE', topic: str = ''):
    scene = getattr(context, 'scene', None)
    title = tx(scene, title_en, title_ja)
    help_topic = str(topic or _help_topic_from_title(title_en) or '').strip()
    raw_key = str(help_topic or title_en or title_ja or title or 'section').strip().lower()
    key = 'section_' + re.sub(r'[^0-9a-z_]+', '_', raw_key).strip('_')
    _box, body, _expanded = ui_sections.draw_group(
        layout,
        context,
        key,
        title,
        icon=icon if icon else 'NONE',
        topic=help_topic,
        default_open=False,
    )
    return _n_compact(body)



def _n_long_field_label(owner, prop_name: str, text=None) -> str:
    """Return the label to put above a text/enum field whose name would be clipped beside it."""
    if text == '':
        return ''
    try:
        rna = owner.bl_rna.properties[prop_name]
        if rna.type not in {'ENUM', 'STRING', 'POINTER'}:
            return ''
        label = str(text) if text is not None else bpy.app.translations.pgettext_iface(rna.name, rna.translation_context)
    except Exception:
        return ''
    limit = 7 if label.isascii() else 8
    return label if sum(1 if ord(ch) < 128 else 2 for ch in label) > limit else ''


def _n_prop(layout, context, owner, prop_name: str, *, text=None, toggle: bool=False, icon: str='NONE'):
    if not _n_has_prop(owner, prop_name):
        return False
    try:
        if not toggle:
            long_label = _n_long_field_label(owner, prop_name, text)
            if long_label:
                stacked = layout.column(align=True)
                stacked.label(text=long_label, translate=False)
                stacked.prop(owner, prop_name, text='')
                return True
        kwargs = {}
        if text is not None:
            kwargs['text'] = text
        if toggle:
            kwargs['toggle'] = True
        if icon and icon != 'NONE':
            kwargs['icon'] = icon
        layout.prop(owner, prop_name, **kwargs)
        return True
    except Exception as exc:
        try:
            warn = _n_compact(layout.box())
            warn.alert = True
            warn.label(text=_exc_text(exc), icon='ERROR')
        except Exception:
            pass
        return False


def _n_props(layout, context, owner, props):
    for prop_name in props:
        _n_prop(layout, context, owner, str(prop_name))


def _n_bool(layout, context, owner, prop_name: str, text=None):
    return _n_prop(layout, context, owner, prop_name, text=text, toggle=True)


def _n_op(layout, context, op_id: str, *, text=None, icon: str='NONE'):
    try:
        if text is None:
            return layout.operator(op_id, icon=icon if icon else 'NONE')
        return layout.operator(op_id, text=text, icon=icon if icon else 'NONE')
    except Exception as exc:
        try:
            layout.label(text=_exc_text(exc), icon='ERROR')
        except Exception:
            pass
        return None


def _n_text(layout, context, text, icon: str='NONE'):
    try:
        for idx, line in enumerate(_wrap_n_panel_label(context, str(text or ''), padding_px=84)):
            layout.label(text=line, icon=icon if idx == 0 and icon and icon != 'NONE' else 'NONE')
    except Exception:
        try:
            layout.label(text=str(text or ''), icon=icon if icon else 'NONE')
        except Exception:
            pass


def _n_error(layout, context, error) -> None:
    try:
        _n_text(layout, context, _exc_text(error), 'ERROR')
    except Exception:
        try:
            layout.label(text=_exc_text(error), icon='ERROR')
        except Exception:
            pass


def _n_material_field(layout, context, prop_name: str, title_en: str, title_ja: str, *, allow_active: bool=False):
    scene = getattr(context, 'scene', None)
    col = _n_section(layout, context, title_en, title_ja, 'MATERIAL')
    value = str(getattr(scene, prop_name, '') or '').strip() if scene is not None and _n_has_prop(scene, prop_name) else ''
    _n_text(col, context, tx(scene, f'Current: {value}', f'現在: {value}') if value else tx(scene, 'No material selected', 'マテリアル未選択'), 'NODE_MATERIAL' if value else 'NONE')
    op = _n_op(col, context, 'sss.pick_material_field', text=tx(scene, 'Choose Existing Material', '既存マテリアル選択'), icon='VIEWZOOM')
    if op is not None:
        try:
            op.prop_name = prop_name
        except Exception:
            pass
    if allow_active:
        _n_op(col, context, 'sss.pick_active_material', text=tx(scene, 'Use Active Material', 'アクティブ材質を使用'), icon='EYEDROPPER')
    _n_prop(col, context, scene, prop_name, text=tx(scene, 'Material Name', 'マテリアル名'))


def _n_primary_options(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_section(layout, context, 'Main Options', '主要オプション', 'OPTIONS')
    for prop in ('sss_non_destructive', 'sss_assign_selected', 'sss_mark_asset', 'sss_use_fake_user', 'sss_auto_audit_after_build', 'sss_auto_layout_after_build', 'sss_prune_after_build'):
        _n_bool(col, context, scene, prop)


def _dynamic_enum_sanitize_key(scene) -> tuple:
    if scene is None:
        return ()
    try:
        getter = getattr(scene, 'get', None)
        raw = getter if callable(getter) else None
    except Exception:
        raw = None
    def _raw(name: str, fallback: str = '') -> str:
        try:
            if raw is not None:
                return str(raw(name, fallback) or '')
        except Exception:
            pass
        try:
            return str(getattr(scene, name, fallback) or '')
        except Exception:
            return str(fallback or '')
    return (
        _scene_cache_key(scene),
        _raw('sss_node_pick'), _raw('sss_node_query'),
        _raw('sss_inventory_pick'), _raw('sss_inventory_search'), _raw('sss_inventory_scope'), _raw('sss_inventory_sort'),
        _raw('sss_asset_search_pick'), _raw('sss_asset_search_query'),
    )


def _deferred_dynamic_enum_sanitize():
    global _DYNAMIC_ENUM_SANITIZE_PENDING, _DYNAMIC_ENUM_SANITIZE_LAST_KEY
    _DYNAMIC_ENUM_SANITIZE_PENDING = False
    context = getattr(bpy, 'context', None)
    scene = getattr(context, 'scene', None) if context is not None else None
    if scene is None or _UI_SHUTTING_DOWN:
        return None
    key = _dynamic_enum_sanitize_key(scene)
    if key and key == _DYNAMIC_ENUM_SANITIZE_LAST_KEY:
        return None
    try:
        sss_properties.normalize_selected_node_pick(scene, context)
    except Exception:
        pass
    try:
        sss_properties.normalize_selected_inventory(scene, context)
    except Exception:
        pass
    try:
        sss_properties.normalize_selected_asset_search(scene, context)
    except Exception:
        pass
    _DYNAMIC_ENUM_SANITIZE_LAST_KEY = _dynamic_enum_sanitize_key(scene)
    return None


def _n_dynamic_enum_sanitize(context):
    """Schedule dynamic enum repair outside the draw path.

    The previous implementation normalized node, inventory, and asset-search
    enums synchronously on every N-panel draw. During 3D view navigation Blender
    redraws the sidebar for each mouse event; those normalizers can scan scene
    objects, materials, node trees, and JSON libraries. Scheduling one coalesced
    repair keeps old .blend compatibility without blocking viewport pan/rotate/zoom.
    """
    # Legacy enum repair runs at registration and file-load boundaries.  Never
    # schedule work from N-panel draw: with every resident feature disabled,
    # ordinary panel viewing must not leave a timer behind.
    del context
    return None


def draw_panel_help_button(layout, context, topic: str):
    # Section headers carry the help icon in the Smart Modeling-style UI.
    # Keep this helper as a no-op for legacy callers to avoid duplicate help rows.
    return None



def draw_tooltip_label(layout, scene, title_en: str, title_ja: str, icon: str = 'NONE', tip_en: str = '', tip_ja: str = ''):
    # Keep the N-panel body concise.  Detailed feature overview, usage, and
    # setting explanations are intentionally moved to the lazy help popup.
    del tip_en, tip_ja
    col = _n_compact(layout.column(align=True))
    try:
        header = col.row(align=True)
        split = header.split(factor=0.84, align=True)
        left = split.row(align=True)
        left.label(text=tx(scene, title_en, title_ja), icon=icon if icon else 'NONE')
        right = split.row(align=True)
        right.alignment = 'RIGHT'
        draw_help_button(right, scene, _help_topic_from_title(title_en))
    except Exception:
        try:
            col.label(text=tx(scene, title_en, title_ja), icon=icon if icon else 'NONE')
        except Exception:
            col.label(text=tx(scene, title_en, title_ja))


def _draw_bool_pref_row(layout, owner, prop_name: str, label: str, *, icon: str = 'NONE') -> bool:
    if owner is None or not _n_has_prop(owner, prop_name):
        return False
    try:
        enabled = bool(getattr(owner, prop_name))
    except Exception:
        enabled = False
    try:
        row = _n_compact(layout.row(align=True))
        row.scale_y = 0.95
        split = row.split(factor=0.72, align=True)
        left = split.row(align=True)
        left.label(text=str(label or prop_name))
        right = split.row(align=True)
        right.alignment = 'RIGHT'
        right.use_property_split = False
        right.use_property_decorate = False
        right.row(align=True).prop(
            owner,
            prop_name,
            text=tx(None, 'On' if enabled else 'Off', '有効' if enabled else '無効'),
            icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
            toggle=True,
        )
        return True
    except Exception:
        try:
            return _n_bool(layout, None, owner, prop_name, text=label)
        except Exception:
            return False


def draw_always_on_toggles(layout, context):
    scene = getattr(context, 'scene', None)
    owner = _addon_prefs_owner(context)
    if owner is None:
        _n_text(layout, context, tx(scene, 'Persistent settings could not be loaded.', '永続設定を読み込めませんでした。'), 'ERROR')
        return
    _draw_bool_pref_row(layout, owner, 'npanel_state_save', tx(scene, 'N-panel State Save', 'Nパネル状態保存'), icon='FILE_TICK')
    try:
        layout.separator(factor=0.5)
    except Exception:
        pass
    # Only background / automatic behaviors live here.  General bundled-tool
    # availability stays in Settings so one-shot tools remain UI-only until loaded.
    rows = (
        ('integrated_material_library_auto_refresh_on_load', 'Library Load Refresh', 'ライブラリ読込時更新', 'MATERIAL'),
        ('material_studio_settings_handlers', 'Settings Load Restore', '設定の読込時復元', 'FILE_REFRESH'),
        ('smart_toon_live_sync_enabled', 'Toon Live Sync', 'トゥーン ライブ同期', 'SHADING_RENDERED'),
        ('material_editor_load_restore_enabled', 'Editor Load Restore', 'エディター読込時復元', 'MATERIAL'),
    )
    for prop, en, ja, icon in rows:
        _draw_bool_pref_row(layout, owner, prop, tx(scene, en, ja), icon=icon)


def draw_always_on_toggles_group(layout, context):
    scene = getattr(context, 'scene', None)
    owner = _addon_prefs_owner(context)
    title = tx(scene, 'Always-on Toggles', '常時機能切り替え')
    # The shared top-level header (ui_sections.draw_group) owns the open/close
    # button, title button, gap and the "?" help button.
    box, body, expanded = ui_sections.draw_group(
        layout, context, 'always_on_toggles', title, icon='TIME', topic='always_on_toggles', default_open=False,
    )
    if not expanded:
        return
    if owner is None:
        _n_text(body, context, tx(scene, 'Persistent settings could not be loaded.', '永続設定を読み込めませんでした。'), 'ERROR')
        return
    draw_always_on_toggles(_n_compact(body), context)


def _draw_feature_list_section(layout, context, section_key: str, title_en: str, title_ja: str, icon: str, topic: str, drawer, *, default_open: bool=False):
    scene = getattr(context, 'scene', None)
    title = tx(scene, title_en, title_ja)
    _box, body, expanded = ui_sections.draw_group(layout, context, section_key, title, icon=icon, topic=topic or section_key, default_open=default_open)
    if not expanded:
        return
    try:
        drawer(_n_compact(body), context)
    except Exception as exc:
        _n_error(body, context, exc)



def draw_pbr_fx_creation_suite(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_card(layout, context, 'PBR / FX Preset', 'PBR / FXプリセット', 'SHADING_RENDERED', 'pbr_material_generation')
    _n_props(col, context, scene, ('sss_pbr_preset_family', 'sss_pbr_preset_genre', 'sss_preset_search', 'sss_pbr_preset_name', 'sss_material_name'))
    try:
        op = col.operator('sss.open_preset_preview_popup', text=tx(scene, 'Choose from Preview Images', 'プレビュー画像から選択'), icon='IMAGE_DATA')
        op.target = 'PBR'
        op.generate = True
    except Exception:
        pass
    _draw_preset_preview(col, context, 'sss_pbr_preset_name')
    opt = _n_section(col, context, 'Build Options', '生成オプション', 'OPTIONS')
    for prop in ('sss_assign_selected', 'sss_use_fake_user', 'sss_mark_asset'):
        _n_bool(opt, context, scene, prop)
    _draw_material_target_slot_selector(opt, context)
    _n_op(col, context, 'sss.create_pbr_fx_material', icon='ADD')
    pbr = _n_section(col, context, 'Photo to PBR', '写真からPBR', 'IMAGE_DATA')
    _n_props(pbr, context, scene, ('sss_photo_source', 'sss_photo_output_dir', 'sss_photo_max_size', 'sss_photo_normal_strength', 'sss_photo_detail_strength'))
    _n_op(pbr, context, 'sss.create_photo_pbr', icon='IMAGE_DATA')
    draw_pbr_lookdev_feature(col, context)


def _draw_pbr_material_generation(layout, context):
    scene = getattr(context, 'scene', None)
    draw_pbr_fx_creation_suite(layout, context)
    try:
        draw_smart_layers(layout, context)
    except Exception as exc:
        _n_error(layout, context, exc)


def _draw_smart_toon(layout, context):
    try:
        smart_toon.draw_ui(layout, context)
    except Exception as exc:
        _n_error(layout, context, exc)


def _draw_texture_set_import_autowire(layout, context):
    scene = getattr(context, 'scene', None)
    draw_relink_cleanup_core(layout, context)


def _draw_material_library_management(layout, context):
    scene = getattr(context, 'scene', None)
    draw_library_search_suite(layout, context)


def _draw_scene_material_rules(layout, context):
    scene = getattr(context, 'scene', None)
    draw_material_operations_suite(layout, context)
    draw_scene_tools_category(layout, context)
    try:
        draw_scene_variants_box(layout, context)
    except Exception as exc:
        _n_error(layout, context, exc)


def _draw_hdri_world_management(layout, context):
    scene = getattr(context, 'scene', None)
    draw_hdri_tools(layout, context)


def _draw_audit_repair_report_handoff(layout, context):
    scene = getattr(context, 'scene', None)
    draw_audit_suite(layout, context)
    try:
        draw_scene_doctor(layout, context)
    except Exception as exc:
        _n_error(layout, context, exc)
    draw_exchange_reference_suite(layout, context)
    try:
        draw_settings(layout, context)
    except Exception as exc:
        _n_error(layout, context, exc)


def _draw_material_editor(layout, context):
    material_editor.draw_ui(layout, context)


def draw_npanel_root(layout, context):
    _n_dynamic_enum_sanitize(context)
    draw_panel_help_button(layout, context, 'smart_shader_root')
    draw_always_on_toggles_group(layout, context)
    sections = (
        ('material_editor', 'Material Editor', 'マテリアルエディター', 'MATERIAL', 'material_editor', _draw_material_editor),
        ('pbr_material_generation', 'PBR Material Generation', 'PBRマテリアル生成', 'SHADING_RENDERED', 'pbr_material_generation', _draw_pbr_material_generation),
        ('smart_toon', 'Smart Toon', 'スマート トゥーン', 'SHADING_RENDERED', 'smart_toon', _draw_smart_toon),
        ('texture_set_import_autowire', 'Texture Set Import', 'テクスチャセット取り込み', 'TEXTURE', 'texture_set_import_autowire', _draw_texture_set_import_autowire),
        ('material_library_management', 'Material Library', 'マテリアルライブラリ管理', 'ASSET_MANAGER', 'material_library_management', _draw_material_library_management),
        ('scene_material_rules', 'Scene Materials & Rules', 'シーン内マテリアル整理', 'MATERIAL', 'scene_material_rules', _draw_scene_material_rules),
        ('hdri_world_management', 'HDRI World Management', 'HDRIワールド管理', 'WORLD_DATA', 'hdri_world_management', _draw_hdri_world_management),
        ('audit_repair_report_handoff', 'Audit, Repair & Handoff', '監査・修復・受け渡し', 'CHECKMARK', 'audit_repair_report_handoff', _draw_audit_repair_report_handoff),
    )
    for key, en, ja, icon, topic, drawer in sections:
        _draw_feature_list_section(layout, context, key, en, ja, icon, topic, drawer, default_open=False)
    return None


def draw_settings(layout, context):
    col = _n_card(layout, context, 'Settings', '設定', 'PREFERENCES', 'settings')
    try:
        preferences.draw_storage_settings(col, context)
    except Exception as exc:
        _n_text(col, context, _exc_text(exc), 'ERROR')


def draw_preset_summary(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_section(layout, context, 'Preset Overview', 'プリセット概要', 'SHADING_RENDERED')
    preset_id = str(getattr(scene, 'sss_preset_name', '') or '') if scene is not None else ''
    meta = None
    try:
        meta = data.PRESET_LIBRARY.get(preset_id)
    except Exception:
        meta = None
    if meta:
        _n_text(col, context, tx(scene, meta.get('label_en',''), meta.get('label_ja','')), 'MATERIAL')
        _n_text(col, context, tx(scene, meta.get('summary_en',''), meta.get('summary_ja','')))
    else:
        _n_text(col, context, tx(scene, 'No preset information.', 'プリセット情報がありません。'))


def draw_material_creation_suite(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_card(layout, context, 'PBR Presets', 'PBRプリセット', 'SHADING_RENDERED', 'pbr_preset_only')
    _n_props(col, context, scene, ('sss_preset_family', 'sss_preset_genre', 'sss_preset_search', 'sss_preset_name', 'sss_material_name'))
    try:
        op = col.operator('sss.open_preset_preview_popup', text=tx(scene, 'Choose from Preview Images', 'プレビュー画像から選択'), icon='IMAGE_DATA')
        op.target = 'MAIN'
        op.generate = True
    except Exception:
        pass
    draw_preset_summary(col, context)
    _draw_preset_preview(col, context)
    opt = _n_section(col, context, 'Build Options', '生成オプション', 'OPTIONS')
    for prop in ('sss_assign_selected', 'sss_use_fake_user', 'sss_mark_asset'):
        _n_bool(opt, context, scene, prop)
    _draw_material_target_slot_selector(opt, context)
    actions = _n_section(col, context, 'Build / Apply', '生成／適用', 'ADD')
    for op, icon in (('sss.create_preset_material','ADD'), ('sss.apply_to_active','FILE_TICK')):
        _n_op(actions, context, op, icon=icon)
    pbr = _n_section(col, context, 'Photo to PBR', '写真からPBR', 'IMAGE_DATA')
    _n_props(pbr, context, scene, ('sss_photo_source', 'sss_photo_output_dir', 'sss_photo_max_size', 'sss_photo_normal_strength', 'sss_photo_detail_strength'))
    _n_op(pbr, context, 'sss.create_photo_pbr', icon='IMAGE_DATA')
    draw_pbr_lookdev_feature(col, context)


def draw_custom_library_box(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_section(layout, context, 'Custom Library', 'カスタムライブラリ', 'FILE_FOLDER')
    _n_props(col, context, scene, ('sss_custom_preset_name', 'sss_custom_library_mode'))
    for op, icon in (('sss.export_custom_library','EXPORT'), ('sss.import_custom_library','IMPORT'), ('sss.repair_custom_library','TOOL_SETTINGS')):
        _n_op(col, context, op, icon=icon)


def draw_library_search_suite(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_card(layout, context, 'Search & Libraries', '検索とライブラリ', 'VIEWZOOM', 'search_libraries')
    smart = _n_section(col, context, 'Smart Search', 'スマート検索', 'VIEWZOOM')
    _n_props(smart, context, scene, ('sss_asset_search_query', 'sss_asset_search_pick'))
    _n_op(smart, context, 'sss.use_result', icon='EYEDROPPER')
    _n_op(smart, context, 'sss.apply_result', icon='PLAY')
    catalog = _n_section(col, context, 'Material Catalog', 'マテリアルカタログ', 'ASSET_MANAGER')
    _n_props(catalog, context, scene, ('sss_catalog_search', 'sss_catalog_pick', 'sss_catalog_entry_name', 'sss_catalog_tags', 'sss_catalog_library_mode'))
    for op, icon in (('sss.save_entry','FILE_TICK'), ('sss.apply_entry','FILE_REFRESH'), ('sss.delete_entry','TRASH'), ('sss.export_library','EXPORT'), ('sss.import_library','IMPORT'), ('sss.repair_library','TOOL_SETTINGS')):
        _n_op(catalog, context, op, icon=icon)
    draw_custom_library_box(col, context)
    draw_material_library_feature(col, context)


def draw_npr_studio(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_card(layout, context, 'NPR Studio', 'NPRスタジオ', 'SHADING_RENDERED', 'npr_studio')
    props = ('sss_npr_material_name','sss_npr_zone_count','sss_npr_base_color','sss_npr_threshold_1','sss_npr_zone2_color','sss_npr_threshold_2','sss_npr_zone3_color','sss_npr_threshold_3','sss_npr_zone4_color','sss_npr_shadow_smooth','sss_npr_alpha','sss_npr_highlight_color','sss_npr_highlight_level','sss_npr_highlight_size','sss_npr_highlight_smooth','sss_npr_reflection_color','sss_npr_reflection_strength','sss_npr_reflection_roughness','sss_npr_rim_color','sss_npr_rim_width','sss_npr_rim_strength','sss_npr_detail_scale','sss_npr_detail_normal','sss_npr_paper_tint','sss_npr_paper_scale','sss_npr_paper_strength')
    _n_props(col, context, scene, props)
    _n_bool(col, context, scene, 'sss_npr_hatch_enable')
    if getattr(scene, 'sss_npr_hatch_enable', False):
        _n_props(col, context, scene, ('sss_npr_hatch_color','sss_npr_hatch_scale','sss_npr_hatch_strength','sss_npr_hatch_softness','sss_npr_hatch_angle','sss_npr_hatch_cross_enable','sss_npr_hatch_cross_angle','sss_npr_hatch_cross_strength'))
    _n_bool(col, context, scene, 'sss_npr_halftone_enable')
    if getattr(scene, 'sss_npr_halftone_enable', False):
        _n_props(col, context, scene, ('sss_npr_halftone_color','sss_npr_halftone_scale','sss_npr_halftone_strength','sss_npr_halftone_softness','sss_npr_halftone_threshold','sss_npr_halftone_rotation'))
    for op, icon in (('sss.load_from_active','IMPORT'), ('sss.update_material','FILE_REFRESH'), ('sss.create_material','ADD')):
        _n_op(col, context, op, icon=icon)


def draw_material_operations_suite(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_card(layout, context, 'Target Operations', '対象マテリアル操作', 'MATERIAL', 'target_material_operations')
    _draw_compact_active_material_selector(col, context)
    _n_material_field(col, context, 'sss_target_material_name', 'Target Material', '対象マテリアル', allow_active=True)
    _n_props(col, context, scene, ('sss_material_name','sss_assign_mode'))
    _draw_material_target_slot_selector(col, context)
    _n_bool(col, context, scene, 'sss_non_destructive')
    for op, icon in (('sss.set_active_target','RESTRICT_SELECT_OFF'),('sss.assign_to_selection','LINK_BLEND'),('sss.select_users','RESTRICT_SELECT_OFF'),('sss.unassign_material','X'),('sss.duplicate_target','DUPLICATE'),('sss.localize_target','MATERIAL'),('sss.localize_per_object','MATERIAL_DATA'),('sss.rename_target','GREASEPENCIL'),('sss.rebuild_target','FILE_REFRESH'),('sss.rebuild_managed_materials','FILE_REFRESH'),('sss.cleanup_slots','NODE_MATERIAL'),('sss.merge_duplicates','COPY_ID'),('sss.protect_target_bundle','LOCKED'),('sss.clear_protection','UNLOCKED')):
        _n_op(col, context, op, icon=icon)


def draw_scene_tools_category(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_card(layout, context, 'Scene Materials & Rules', 'シーン材質とルール', 'MATERIAL', 'scene_materials_rules')
    inv = _n_section(col, context, 'Scene Material Index', 'シーン材質インデックス', 'MATERIAL')
    _n_props(inv, context, scene, ('sss_inventory_search','sss_inventory_scope','sss_inventory_sort','sss_inventory_pick'))
    _n_op(inv, context, 'sss.use_index_pick', icon='EYEDROPPER')
    _n_op(inv, context, 'sss.select_index_users', icon='RESTRICT_SELECT_OFF')
    cmp = _n_section(col, context, 'Compare & Replace', '比較と置換', 'ARROW_LEFTRIGHT')
    _n_material_field(cmp, context, 'sss_compare_source_material_name', 'Compare Source', '比較元')
    _n_material_field(cmp, context, 'sss_target_material_name', 'Target Material', '対象マテリアル', allow_active=True)
    _n_props(cmp, context, scene, ('sss_replace_scope',))
    _n_op(cmp, context, 'sss.preview_diff', icon='VIEWZOOM')
    _n_op(cmp, context, 'sss.replace_with_target', icon='FILE_REFRESH')
    rules_col = _n_section(col, context, 'Assignment Rules', '割当ルール', 'PRESET')
    _n_props(rules_col, context, scene, ('sss_rule_name','sss_rule_search','sss_rule_pick','sss_rule_object_pattern','sss_rule_collection_pattern','sss_rule_current_material_pattern','sss_rule_use_regex','sss_rule_scope','sss_rule_library_mode'))
    for op, icon in (('sss.save_rule','FILE_TICK'),('sss.preview_rule','VIEWZOOM'),('sss.apply_rule','PLAY'),('sss.delete_rule','TRASH'),('sss.export_rule_library','EXPORT'),('sss.import_rule_library','IMPORT'),('sss.repair_rule_library','TOOL_SETTINGS')):
        _n_op(rules_col, context, op, icon=icon)


def draw_layers_variants_suite(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_card(layout, context, 'Layers & Variants', 'レイヤーとバリアント', 'MOD_MASK', 'layers_variants')
    lay = _n_section(col, context, 'Smart Layers', 'スマートレイヤー', 'MOD_MASK')
    _n_props(lay, context, scene, ('sss_layer_preset','sss_layer_mask_mode','sss_layer_strength','sss_layer_noise_scale','sss_layer_mask_contrast','sss_layer_recipe_name','sss_layer_recipe_pick','sss_layer_recipe_library_mode'))
    for op, icon in (('sss.apply_layer','MOD_MASK'),('sss.add_mask_utilities','NODETREE'),('sss.save_recipe','FILE_TICK'),('sss.apply_recipe','FILE_REFRESH'),('sss.delete_recipe','TRASH'),('sss.export_recipe_library','EXPORT'),('sss.import_recipe_library','IMPORT'),('sss.repair_recipe_library','TOOL_SETTINGS')):
        _n_op(lay, context, op, icon=icon)
    var = _n_section(col, context, 'Scene Variants', 'シーンバリアント', 'SEQ_STRIP_DUPLICATE')
    _n_props(var, context, scene, ('sss_scene_variant_name','sss_scene_variant_pick','sss_scene_variant_library_mode'))
    for op, icon in (('sss.save_variant','FILE_TICK'),('sss.apply_variant','FILE_REFRESH'),('sss.delete_variant','TRASH'),('sss.export_variant_library','EXPORT'),('sss.import_variant_library','IMPORT'),('sss.repair_variant_library','TOOL_SETTINGS')):
        _n_op(var, context, op, icon=icon)


def draw_hdri_tools(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_card(layout, context, 'World & HDRI', 'ワールドとHDRI', 'WORLD_DATA', 'world_hdri')
    col.label(text=tx(scene, 'HDRI File', 'HDRIファイル'))
    _n_prop(col, context, scene, 'sss_hdri_path', text='')
    _n_prop(col, context, scene, 'sss_hdri_strength', text=tx(scene, 'HDRI Strength', 'HDRI強度'))
    _n_prop(col, context, scene, 'sss_hdri_rotation', text=tx(scene, 'HDRI Rotation', 'HDRI回転'))
    col.label(text=tx(scene, 'HDRI Library', 'HDRIライブラリ'))
    _n_prop(col, context, scene, 'sss_hdri_library_root', text='')
    col.label(text=tx(scene, 'HDRI Search', 'HDRI検索'))
    _n_prop(col, context, scene, 'sss_hdri_search', text='')
    col.label(text=tx(scene, 'HDRI Candidate', 'HDRI候補'))
    _n_prop(col, context, scene, 'sss_hdri_pick', text='')
    _n_op(col, context, 'sss.build_world', text=tx(scene, 'Build HDRI World', _lt('HDRIワールド構築')), icon='WORLD_DATA')
    for op, icon, en, ja in (('sss.relink_world','FILE_REFRESH','Relink World','ワールド再リンク'),('sss.use_candidate','EYEDROPPER','Use Candidate','候補を使用'),('sss.apply_candidate','PLAY','Apply Candidate','候補適用')):
        _n_op(col, context, op, text=tx(scene, en, ja), icon=icon)
    try:
        state = environment.world_hdri_state(context)
        _n_text(col, context, tx(scene, state.get('status_en',''), state.get('status_ja','')), 'WORLD_DATA')
    except Exception:
        pass


def draw_texture_cleanup_suite(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_card(layout, context, 'Texture Sets & Auto Wiring', 'テクスチャセットと自動配線', 'FILEBROWSER', 'textures_autowire')
    _n_props(col, context, scene, ('sss_texture_search_root','sss_texture_set_filter','sss_texture_import_mode','sss_texture_batch_limit','sss_texture_scope'))
    _n_bool(col, context, scene, 'sss_allow_multi_group_texture_build')
    _n_bool(col, context, scene, 'sss_texture_force_rewire')
    for op, icon in (('sss.scan_set','VIEWZOOM'),('sss.build_from_set','PLAY'),('sss.scan_library','FILE_FOLDER'),('sss.build_library','IMPORT'),('sss.relink_textures','FILE_REFRESH'),('sss.standardize_color_space','IMAGE_DATA'),('sss.auto_wire_textures','NODETREE')):
        _n_op(col, context, op, icon=icon)


def draw_node_tools_suite(layout, context):
    _n_dynamic_enum_sanitize(context)
    scene = getattr(context, 'scene', None)
    col = _n_card(layout, context, 'Math Controller & Node Reports', '数式コントローラーとノードレポート', 'NODETREE', 'node_tools_presets')
    lens = _n_section(col, context, 'Node Inspector', 'ノード調査', 'VIEWZOOM')
    _n_props(lens, context, scene, ('sss_node_query','sss_node_pick'))
    _n_op(lens, context, 'sss.select_node', icon='RESTRICT_SELECT_OFF')
    _n_op(lens, context, 'sss.write_node_report', icon='TEXT')
    try:
        ui_runtime.draw_tool_group(col, context, ('math_controller',), default_closed=True)
    except Exception as exc:
        _n_text(col, context, _exc_text(exc), 'ERROR')


def _n_report_lines(layout, context):
    # The report has one finding per line; a one-line text field cannot show that.
    scene = getattr(context, 'scene', None)
    layout.label(text=tx(scene, 'Last Report', '最終レポート'), translate=False)
    report = str(getattr(scene, 'sss_last_report', '') or '').strip()
    if not report:
        layout.label(text=tx(scene, 'No report yet.', _lt('まだレポートはありません。')), translate=False)
        return
    for line in wrap_lines(report, width=62):
        if line:
            layout.label(text=line, translate=False)


def draw_audit_suite(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_card(layout, context, 'Audit & Node Debug', '監査とノード調査', 'CHECKMARK', 'audit_node_debug')
    for op, icon in (('sss.audit_active_material','CHECKMARK'),('sss.audit_library','FILE_FOLDER'),('sss.normalize_output','TOOL_SETTINGS'),('sss.run_self_check','ERROR')):
        _n_op(col, context, op, icon=icon)
    _n_report_lines(col, context)


def draw_exchange_reference_suite(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_card(layout, context, 'Exchange & Reference', '受け渡しと参照', 'FILE_CACHE', 'exchange_reference')
    for op, icon in (('sss.export_bundle','EXPORT'),('sss.import_bundle','IMPORT'),('sss.export_manifest','EXPORT'),('sss.export_scene_manifest','EXPORT'),('sss.import_manifest','IMPORT'),('sss.import_scene_manifest','IMPORT'),('sss.write_coverage_report','TEXT')):
        _n_op(col, context, op, icon=icon)
    _n_report_lines(col, context)


def draw_quick_actions_suite(layout, context):
    scene = getattr(context, 'scene', None)
    col = _n_card(layout, context, 'Quick Actions', 'クイック操作', 'PLAY', 'quick_actions')
    _n_props(col, context, scene, ('sss_workspace_recipe','sss_quick_action_search','sss_quick_action'))
    _n_op(col, context, 'sss.run_workflow', icon='PLAY')
    _n_op(col, context, 'sss.run_action', icon='PLAY')


PANEL_SOURCE_CLASSES = (
    SSS_PT_shader_tools,
)


_PANEL_EDITOR_ID_SUFFIX = {
    'IMAGE_EDITOR': 'image_editor',
    'UV_EDITOR': 'uv_editor',
    'SHADER_EDITOR': 'shader_editor',
    'COMPOSITOR': 'compositor',
    'GEOMETRY_NODE_EDITOR': 'geometry_node_editor',
    'TEXTURE_NODE_EDITOR': 'texture_node_editor',
    'VIDEO_SEQUENCER': 'video_sequencer',
    'MOVIE_CLIP_EDITOR': 'movie_clip_editor',
    'DOPE_SHEET': 'dope_sheet',
    'GRAPH_EDITOR': 'graph_editor',
    'DRIVERS': 'drivers',
    'NLA_EDITOR': 'nla_editor',
    'TEXT_EDITOR': 'text_editor',
    'ASSET_BROWSER': 'asset_browser',
    'FILE_BROWSER': 'file_browser',
    'SPREADSHEET': 'spreadsheet',
}


def _make_editor_npanel_class(source_cls, editor_key: str):
    """Create a Smart Shader N-panel host for one Blender editor.

    Smart Tools Manager reads ``_smart_tools_manager_editor_key`` to route the
    panel by workspace and editor without relying on VIEW_3D-only proxy panels.
    """
    editor_key = str(editor_key or '').upper()
    source_id = str(getattr(source_cls, 'bl_idname', source_cls.__name__))
    suffix = _PANEL_EDITOR_ID_SUFFIX.get(editor_key, editor_key.lower())
    panel_id = f'{source_id}_{suffix}'
    attrs = {
        '__module__': __name__,
        'bl_idname': panel_id,
        'bl_label': getattr(source_cls, 'bl_label', source_cls.__name__),
        'bl_description': getattr(source_cls, 'bl_description', ''),
        'bl_space_type': _N_PANEL_EDITOR_SPACE_TYPES[editor_key],
        'bl_region_type': 'UI',
        'bl_category': getattr(source_cls, 'bl_category', 'Smart Shader'),
        'bl_order': int(getattr(source_cls, 'bl_order', 0) or 0),
        '_sss_target_editor_key': editor_key,
        '_smart_tools_manager_editor_key': editor_key,
        '_smart_tools_manager_tool_key': 'SMART_SHADER',
        '_smart_tools_manager_native_npanel_root': True,
        'draw': getattr(source_cls, 'draw'),
        'draw_header_preset': getattr(source_cls, 'draw_header_preset'),
    }
    options = getattr(source_cls, 'bl_options', None)
    if options:
        attrs['bl_options'] = set(options)
    return type(panel_id, (_SSS_NPanelEditorBase, Panel), attrs)


PANEL_EDITOR_CLASSES = tuple(
    _make_editor_npanel_class(SSS_PT_shader_tools, editor_key)
    for editor_key in _N_PANEL_EDITOR_ORDER
    if editor_key != 'VIEW_3D'
)


CLASSES = ui_sections.CLASSES + (
    SSS_OT_show_info,
    SSS_OT_open_help,
    SSS_OT_choose_material_target_slot,
    SSS_OT_select_active_material,
    SSS_OT_create_active_material,
    SSS_OT_pick_material_field,
    SSS_OT_toggle_entry,
) + PANEL_SOURCE_CLASSES + PANEL_EDITOR_CLASSES

# -----------------------------------------------------------------------------
# Smart Shader Suite 5.18.224 canonical N-panel placement contract.
# One Suite-owned root per physical space, with logical-editor routing inside
# that root and an O(1), read-only Smart Tools Manager current-cell query.
# -----------------------------------------------------------------------------

_MANAGER_TOOL_KEY = 'SMART_SHADER'
_MANAGER_GET_PLACEMENT_STATE = None
_MANAGER_API_SOURCE = ''
_MANAGER_API_CONFIGURED = False

_PHYSICAL_ROOT_GROUPS = (
    ('VIEW_3D', ('VIEW_3D',)),
    ('IMAGE_EDITOR', ('IMAGE_EDITOR', 'UV_EDITOR')),
    ('SHADER_EDITOR', ('SHADER_EDITOR', 'COMPOSITOR', 'GEOMETRY_NODE_EDITOR', 'TEXTURE_NODE_EDITOR')),
    ('VIDEO_SEQUENCER', ('VIDEO_SEQUENCER',)),
    ('MOVIE_CLIP_EDITOR', ('MOVIE_CLIP_EDITOR',)),
    ('DOPE_SHEET', ('DOPE_SHEET',)),
    ('GRAPH_EDITOR', ('GRAPH_EDITOR', 'DRIVERS')),
    ('NLA_EDITOR', ('NLA_EDITOR',)),
    ('TEXT_EDITOR', ('TEXT_EDITOR',)),
    ('FILE_BROWSER', ('FILE_BROWSER',)),
    ('ASSET_BROWSER', ('ASSET_BROWSER',)),
    ('SPREADSHEET', ('SPREADSHEET',)),
)


def configure_manager_placement_api() -> bool:
    """Resolve the Manager placement API from already loaded modules only."""
    global _MANAGER_GET_PLACEMENT_STATE, _MANAGER_API_SOURCE, _MANAGER_API_CONFIGURED
    if _MANAGER_API_CONFIGURED:
        return callable(_MANAGER_GET_PLACEMENT_STATE)
    _MANAGER_API_CONFIGURED = True
    candidates = (
        'bl_ext.user_default.smart_tools_manager',
        'smart_tools_manager',
        'bl_ext.user_default.smart_tools_manager.placement_api',
        'smart_tools_manager.placement_api',
        'bl_ext.user_default.smart_tools_manager.manager_api',
        'smart_tools_manager.manager_api',
    )
    for module_name in candidates:
        module = sys.modules.get(module_name)
        if module is None:
            continue
        getter = getattr(module, 'placement_allowed', None)
        if callable(getter):
            _MANAGER_GET_PLACEMENT_STATE = getter
            _MANAGER_API_SOURCE = module_name
            return True
    return False


def clear_manager_placement_api() -> None:
    global _MANAGER_GET_PLACEMENT_STATE, _MANAGER_API_SOURCE, _MANAGER_API_CONFIGURED
    _MANAGER_GET_PLACEMENT_STATE = None
    _MANAGER_API_SOURCE = ''
    _MANAGER_API_CONFIGURED = False


def _manager_placement_allowed(context, editor_key: str) -> bool:
    if not _MANAGER_API_CONFIGURED:
        configure_manager_placement_api()
    getter = _MANAGER_GET_PLACEMENT_STATE
    if not callable(getter):
        return True
    try:
        result = getter(_MANAGER_TOOL_KEY, context, editor_key=str(editor_key or '').upper())
    except Exception:
        return True
    if isinstance(result, bool):
        return result
    try:
        return bool(result)
    except Exception:
        return True


def ui_ready(context) -> bool:
    if context is None or _UI_SHUTTING_DOWN:
        return False
    scene = getattr(context, 'scene', None)
    return scene is not None and _scene_has_rna_property(scene, 'sss_last_report')


def _current_npanel_editor_key(context) -> str:
    """Pure logical editor classification; no cache, I/O, import, or mutation."""
    area = getattr(context, 'area', None)
    if area is None:
        return ''
    space = _active_space_for_context(context)
    area_type = _area_attr_text(area, 'type')
    area_ui_type = _area_attr_text(area, 'ui_type')
    actual = _space_attr_text(space, 'type') or area_type
    tree_type = _space_attr_text(space, 'tree_type') or area_ui_type
    mode = _space_attr_text(space, 'mode', 'ui_mode')
    try:
        params = getattr(space, 'params', None)
    except Exception:
        params = None
    browse_mode = _space_attr_text(space, 'browse_mode', 'mode') or _space_attr_text(params, 'browse_mode')
    if actual == 'VIEW_3D':
        return 'VIEW_3D'
    if actual == 'IMAGE_EDITOR':
        return 'UV_EDITOR' if mode in {'UV', 'UV_EDIT', 'UVS', 'UV_EDITOR'} or area_ui_type in {'UV', 'UV_EDIT', 'UVS', 'UV_EDITOR'} else 'IMAGE_EDITOR'
    if actual == 'NODE_EDITOR':
        token = tree_type.replace('_', '')
        if not token or token in {'SHADERNODETREE', 'SHADER'}:
            return 'SHADER_EDITOR'
        if token in {'COMPOSITORNODETREE', 'COMPOSITOR'}:
            return 'COMPOSITOR'
        if token in {'GEOMETRYNODETREE', 'GEOMETRY'}:
            return 'GEOMETRY_NODE_EDITOR'
        if token in {'TEXTURENODETREE', 'TEXTURE'}:
            return 'TEXTURE_NODE_EDITOR'
        return ''
    if actual == 'SEQUENCE_EDITOR':
        return 'VIDEO_SEQUENCER'
    if actual == 'CLIP_EDITOR':
        return 'MOVIE_CLIP_EDITOR'
    if actual == 'DOPESHEET_EDITOR':
        return '' if mode in {'DRIVERS', 'DRIVER', 'TIMELINE'} or area_ui_type in {'DRIVERS', 'DRIVER', 'TIMELINE'} else 'DOPE_SHEET'
    if actual == 'GRAPH_EDITOR':
        return 'DRIVERS' if mode in {'DRIVERS', 'DRIVER'} or area_ui_type in {'DRIVERS', 'DRIVER'} else 'GRAPH_EDITOR'
    if actual == 'NLA_EDITOR':
        return 'NLA_EDITOR'
    if actual == 'TEXT_EDITOR':
        return 'TEXT_EDITOR'
    if actual == 'FILE_BROWSER':
        return 'ASSET_BROWSER' if browse_mode in {'ASSETS', 'ASSET_BROWSER'} or area_ui_type in {'ASSETS', 'ASSET_BROWSER'} else 'FILE_BROWSER'
    if actual == 'SPREADSHEET':
        return 'SPREADSHEET'
    return ''


def _canonical_root_poll(cls, context):
    if context is None or _UI_SHUTTING_DOWN:
        return False
    logical = _current_npanel_editor_key(context)
    if not logical:
        return False
    accepted = tuple(getattr(cls, '_sss_logical_editor_keys', (getattr(cls, '_sss_target_editor_key', ''),)))
    if logical not in accepted:
        return False
    area = getattr(context, 'area', None)
    expected_space = _N_PANEL_EDITOR_SPACE_TYPES.get(logical, '')
    if area is None or _area_attr_text(area, 'type') != expected_space:
        return False
    if not ui_ready(context):
        return False
    return _manager_placement_allowed(context, logical)


_SSS_NPanelBase.poll = classmethod(_canonical_root_poll)
_SSS_NPanelEditorBase.poll = classmethod(_canonical_root_poll)

# Reuse only one generated class for each physical space.  Logical subtypes are
# routed by the class-local tuple and the Manager current-cell editor_key.
_generated_by_key = {
    str(getattr(panel_cls, '_sss_target_editor_key', '')): panel_cls
    for panel_cls in tuple(PANEL_EDITOR_CLASSES)
}
SSS_PT_shader_tools._sss_logical_editor_keys = ('VIEW_3D',)
SSS_PT_shader_tools._smart_tools_manager_editor_keys = ('VIEW_3D',)
SSS_PT_shader_tools._smart_tools_manager_editor_key = 'VIEW_3D'
_canonical_editor_classes = []
for representative, logical_keys in _PHYSICAL_ROOT_GROUPS[1:]:
    panel_cls = _generated_by_key[representative]
    panel_cls._sss_logical_editor_keys = tuple(logical_keys)
    panel_cls._smart_tools_manager_editor_keys = tuple(logical_keys)
    panel_cls._smart_tools_manager_editor_key = representative
    panel_cls._smart_tools_manager_tool_key = 'SMART_SHADER'
    panel_cls._smart_tools_manager_native_npanel_root = True
    if representative == 'ASSET_BROWSER':
        panel_cls.bl_region_type = 'TOOL_PROPS'
        panel_cls.bl_options = {'DEFAULT_CLOSED'}
    _canonical_editor_classes.append(panel_cls)
PANEL_EDITOR_CLASSES = tuple(_canonical_editor_classes)
PANEL_SOURCE_CLASSES = (SSS_PT_shader_tools,)

CLASSES = ui_sections.CLASSES + (
    SSS_OT_show_info,
    SSS_OT_open_help,
    SSS_OT_choose_material_target_slot,
    SSS_OT_select_active_material,
    SSS_OT_create_active_material,
    SSS_OT_pick_material_field,
    SSS_OT_toggle_entry,
) + PANEL_SOURCE_CLASSES + PANEL_EDITOR_CLASSES
