# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Supplemental UI translations generated from static source labels."""

EXTRA_TRANSLATIONS = {('*', 'NODE_MT_precise_node_color_pie'): 'ノードカラーパイ（精密）',
 ('*', 'NODE_MT_quick_node_color_pie'): 'ノードカラーパイ（クイック）',
 ('*', 'Smart Shader'): 'Smart Shader',
 ('*', 'Shader Studio'): 'スマートシェーダー',
 ('*', 'Smart Shader'): 'Smart Shader',
 ('*', 'id'): 'ID',
 ('*', 'members'): 'メンバー',
 ('*', 'weight'): 'ウェイト'}
