# SPDX-License-Identifier: GPL-3.0-or-later
"""Additional Japanese labels for Shader Suite menus."""

EXTRA_TRANSLATIONS = {
    ("*", label): japanese
    for label, japanese in (
        ("NODE_MT_precise_node_color_pie", "ノードカラーパイ（精密）"),
        ("NODE_MT_quick_node_color_pie", "ノードカラーパイ（クイック）"),
        ("Smart Shader", "Smart Shader"),
        ("Shader Studio", "スマートシェーダー"),
        ("id", "ID"),
        ("members", "メンバー"),
        ("weight", "ウェイト"),
    )
}
