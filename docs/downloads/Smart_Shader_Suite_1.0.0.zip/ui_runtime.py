# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package


import hashlib
import importlib
import json
import textwrap
from typing import Any

import bpy

from . import loader as loader, registry as registry, tool_preferences as tool_prefs, feature_toggle
from . import ui_sections
from .translation import tx, loc_text as _lt
from .translation import AddonError
from .translation import exc_text as _exc_text

_REGISTERED_CLASSES: list[type] = []
_RECORDS_BY_ALIAS: dict[str, dict[str, Any]] = {}
_SUITE_RECORDS: dict[str, list[dict[str, Any]]] = {}
_NAV_MODULE_CACHE: dict[str, object] = {}
_SUITE_ROOT_PANEL_IDS: dict[str, str] = {}
_ADDON_PANEL_IDS: dict[str, str] = {}
_UI_REBUILD_SCHEDULED = False


class _IdFactory:
    @staticmethod
    def token(*parts: object, size: int = 10) -> str:
        source = '||'.join(str(part or '') for part in parts)
        return hashlib.md5(source.encode('utf-8')).hexdigest()[: max(6, int(size))].upper()

    @staticmethod
    def panel(prefix: str, *parts: object) -> tuple[str, str]:
        token = _IdFactory.token(prefix, *parts)
        class_name = f'SSS_NPANEL_PT_{prefix}_{token}'
        return class_name, class_name


ID_FACTORY = _IdFactory()


def _deferred_ui_rebuild():
    """Refresh the bounded in-memory feature inventory synchronously.

    No timer, handler, redraw watcher, class mutation, or module scan is installed.
    This compatibility entry point is called only by an explicit user action.
    """
    global _UI_REBUILD_SCHEDULED
    _UI_REBUILD_SCHEDULED = False
    _collect_records()
    return None


def _schedule_ui_rebuild() -> None:
    global _UI_REBUILD_SCHEDULED
    if _UI_REBUILD_SCHEDULED:
        return
    _UI_REBUILD_SCHEDULED = True
    try:
        _deferred_ui_rebuild()
    finally:
        _UI_REBUILD_SCHEDULED = False


def _ui(en: str, ja: str) -> str:
    return tx(None, str(en or ''), str(ja or ''))



def _draw_help_button(layout, topic: str) -> None:
    previous_context = getattr(layout, 'operator_context', None)
    try:
        layout.operator_context = 'INVOKE_DEFAULT'
    except Exception:
        previous_context = None
    try:
        op = layout.operator('sss.open_help', text='', icon='QUESTION', emboss=True)
        op.topic = str(topic or 'smart_shader_root')
    except Exception:
        try:
            layout.label(text='', icon='QUESTION')
        except Exception:
            pass
    finally:
        if previous_context is not None:
            try:
                layout.operator_context = previous_context
            except Exception:
                pass


def _ensure_operator_undo_options(cls: type) -> None:
    """Compatibility no-op: operator Undo policy is declared by each class."""
    del cls
    return None


def _class_has_own_bl_rna(cls: type) -> bool:
    try:
        rna = vars(cls).get('bl_rna') or getattr(cls, 'bl_rna', None)
        identifier = str(getattr(rna, 'identifier', '') or '')
        inherited = {'Operator', 'Panel', 'PropertyGroup', 'Menu', 'UIList', 'AddonPreferences'}
        return bool(identifier and identifier not in inherited)
    except Exception:
        return False

def _safe_register_class(cls: type) -> None:
    """Register exact Suite-owned classes without relying on bpy.types name lookup."""
    if not isinstance(cls, type):
        raise TypeError('Blender class must be a Python type')
    if cls in _REGISTERED_CLASSES and _class_has_own_bl_rna(cls):
        return
    if _class_has_own_bl_rna(cls):
        raise RuntimeError(f'RNA class is already registered outside this generation ledger: {getattr(cls, "__name__", "<unnamed>")}')
    try:
        bpy.utils.register_class(cls)
    except Exception:
        if cls in _REGISTERED_CLASSES and _class_has_own_bl_rna(cls):
            return
        raise
    if not _class_has_own_bl_rna(cls):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        raise RuntimeError(f'RNA class registration did not publish class bl_rna: {getattr(cls, "__name__", "<unnamed>")}')
    if cls not in _REGISTERED_CLASSES:
        _REGISTERED_CLASSES.append(cls)

def _safe_unregister_registered_classes() -> None:
    for cls in reversed(tuple(_REGISTERED_CLASSES)):
        try:
            if _class_has_own_bl_rna(cls):
                bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()
    _SUITE_ROOT_PANEL_IDS.clear()
    _ADDON_PANEL_IDS.clear()
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()


def _import_nav_module(module_name: str):
    cached = _NAV_MODULE_CACHE.get(module_name)
    if cached is not None:
        return cached
    mod = importlib.import_module(f'.{module_name}', __package__)
    _NAV_MODULE_CACHE[module_name] = mod
    return mod


def suite_is_active(context, suite_key: str) -> bool:
    del context
    return bool(str(suite_key or '').strip())


def suite_panel_context(suite_key: str) -> str:
    del suite_key
    return 'material'


def refresh_all_suites(context=None) -> None:
    del context
    _schedule_ui_rebuild()


def _wrap_lines(layout, text: str, width: int = 78, icon: str = 'NONE') -> None:
    text = str(text or '').strip()
    if not text:
        return
    lines = textwrap.wrap(text, width=max(24, int(width))) or [text]
    first = True
    for line in lines:
        if first:
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)


def _status_text(record: dict) -> str:
    status = str(record.get('status') or '')
    if status == 'loaded':
        return _ui('Loaded', '読み込み済み')
    if status == 'ready':
        return _ui('On-demand', '使用時に読み込み')
    if status == 'unsupported_platform':
        return _ui('Unsupported platform', '現在の OS・CPU では無効')
    if status == 'failed':
        return _ui('Load failed', '読み込み失敗')
    if status == 'disabled_by_user':
        return _ui('Disabled', '無効')
    if status == 'disabled':
        return _ui('Unavailable', '利用不可')
    return status or _ui('Unknown', '不明')


def _addon_help(spec: dict) -> str:
    summary = _ui(str(spec.get('summary_en') or spec.get('description') or spec.get('display_name') or '').strip(), str(spec.get('summary_ja') or spec.get('description') or spec.get('display_name') or '').strip())
    usage = _ui(str(spec.get('usage_en') or '').strip(), str(spec.get('usage_ja') or '').strip())
    if summary and usage:
        return _ui(f'Function: {summary} How to use: {usage}', f'機能: {summary} 使い方: {usage}')
    if summary:
        return _ui(f'Function: {summary}', f'機能: {summary}')
    return _ui('Function: This add-on has been integrated into Smart Shader.', '機能: このアドオンは スマートシェーダーへ統合されています。')


def _target_help(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    label = str(label or '').strip() or _ui('Tool', '機能')
    desc = str(desc or '').strip()
    if kind == 'menu':
        menu_kind_en = 'pie menu' if is_pie else 'menu'
        menu_kind_ja = 'パイメニュー' if is_pie else 'メニュー'
        return _ui(
            f'Function: opens the {label} {menu_kind_en} inside Smart Shader. How to use: click this button, then choose a command from the opened menu.',
            f'機能: スマートシェーダー内で {label} {menu_kind_ja} を開きます。使い方: このボタンを押して、表示されたメニューから目的の機能を選んでください。',
        )
    body = desc or label
    return _ui(
        f'Function: {body}. How to use: click this button to run the command inside Smart Shader. Some tools may open additional dialogs or require a valid selection or mode.',
        f'機能: {body}。使い方: このボタンを押すと スマートシェーダー内のコマンドを実行します。機能によっては追加ダイアログが開く場合や、選択状態・モードが必要な場合があります。',
    )


def _trace_excerpt(text: str) -> str:
    for line in reversed(str(text or '').splitlines()):
        line = line.strip()
        if line:
            return line[:240]
    return ''


def _call_draw(draw_fn, panel_cls, layout, context) -> None:
    # Intentionally disabled.  Calling another add-on's Panel.draw() through a
    # synthetic Python shim while Blender is drawing a VIEW_3D/UI panel can leave
    # Blender with invalid panel state and has been observed to crash inside
    # panel_draw/PyEvalFramePushAndInit.  Integrated tools must expose explicit
    # draw_smart_shader_runtime_controls() hooks instead.
    del draw_fn, panel_cls, layout, context
    raise AddonError(_ui('Direct drawing of this feature panel is disabled for crash safety.', 'クラッシュ防止のため、この機能パネルの直接描画は無効にしています。'))


def _menu_entries(record: dict) -> list[tuple[str, str, bool]]:
    items = []
    seen = set()
    for cls in record.get('menus', ()) or ():
        menu_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not menu_id or menu_id in seen:
            continue
        seen.add(menu_id)
        label = str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or menu_id).strip()
        upper = f'{menu_id} {label} {getattr(cls, "__name__", "")}'.upper()
        is_pie = 'PIE' in upper
        items.append((menu_id, label or menu_id, is_pie))
    items.sort(key=lambda item: item[1].lower())
    return items


def _operator_entries(record: dict) -> list[tuple[str, str, str]]:
    items = []
    seen = set()
    module = record.get('module')
    hidden_ids = set(str(item).strip() for item in getattr(module, 'SSS_HIDE_OPERATOR_IDS', ()) or ()) if module is not None else set()
    for cls in record.get('operators', ()) or ():
        op_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if op_id == 'wm.tool_set_by_id':
            continue
        if not op_id or op_id in seen or op_id in hidden_ids:
            continue
        options = set(getattr(cls, 'bl_options', set()) or set())
        if 'INTERNAL' in options:
            continue
        seen.add(op_id)
        label = str(getattr(cls, 'bl_label', '') or '').strip() or op_id
        desc = str(getattr(cls, 'bl_description', '') or '').strip()
        items.append((op_id, label, desc))
    items.sort(key=lambda item: (item[1].lower(), item[0].lower()))
    return items


def _quick_entries(record: dict, limit: int = 6) -> list[tuple[str, str, str, str, bool]]:
    quick: list[tuple[str, str, str, str, bool]] = []
    menu_limit = max(1, int(limit) // 2) if limit else 0
    for menu_id, label, is_pie in _menu_entries(record)[:menu_limit]:
        quick.append(('menu', menu_id, label, '', is_pie))
    remaining = max(0, int(limit) - len(quick))
    for op_id, label, desc in _operator_entries(record)[:remaining]:
        quick.append(('operator', op_id, label, desc, False))
    return quick


def _invoke_operator(
    layout,
    *,
    addon_alias: str,
    target_kind: str,
    target_id: str,
    label: str,
    desc: str = '',
    is_pie: bool = False,
    kwargs_json: str = '',
    override_hint: str = '',
) -> None:
    icon = 'PRESET' if target_kind == 'menu' and is_pie else ('DOWNARROW_HLT' if target_kind == 'menu' else 'TOOL_SETTINGS')
    try:
        op = layout.operator(SMART_SHADER_SUITE_04BF59_NPANEL_OT_run_tool.bl_idname, text=label, icon=icon)
        op.addon_alias = addon_alias
        op.target_kind = target_kind
        op.target_id = target_id
        op.target_label = label
        op.target_desc = desc
        op.is_pie_menu = bool(is_pie)
        op.target_kwargs_json = kwargs_json
        op.override_hint = override_hint
    except Exception:
        layout.label(text=label)


def _draw_tool_list(layout, record: dict, compact: bool = False) -> None:
    alias = str(record.get('spec', {}).get('alias') or '')
    menus = _menu_entries(record)
    operators = _operator_entries(record)
    if not menus and not operators:
        layout.label(
            text=_ui('No direct operator or menu entry was found.', '直接呼び出せるオペレーターやメニューが見つかりませんでした。'),
        )
        return

    if menus:
        box = layout.box()
        box.label(text=_ui('Menus', 'メニュー'), icon='MENU_PANEL')
        col = box.column(align=True)
        for menu_id, label, is_pie in menus:
            _invoke_operator(col, addon_alias=alias, target_kind='menu', target_id=menu_id, label=label, is_pie=is_pie)

    if operators:
        box = layout.box()
        box.label(text=_ui('Operators', 'オペレーター'), icon='TOOL_SETTINGS')
        flow = box.column(align=True)
        for op_id, label, desc in operators:
            _invoke_operator(flow, addon_alias=alias, target_kind='operator', target_id=op_id, label=label, desc=desc)



def _record_for_alias(alias: str) -> dict[str, Any] | None:
    alias = str(alias or '').strip()
    if not alias:
        return None
    if not _RECORDS_BY_ALIAS:
        try:
            _collect_records()
        except Exception:
            pass
    record = _RECORDS_BY_ALIAS.get(alias)
    if record is None:
        try:
            for item in loader.get_records():
                spec = item.get('spec') or {}
                if str(spec.get('alias') or '').strip() == alias:
                    record = item
                    _RECORDS_BY_ALIAS[alias] = item
                    break
        except Exception:
            record = None
    return record


def _tool_display_and_icon(alias: str, record: dict | None = None) -> tuple[str, str]:
    spec = (record or {}).get('spec', {}) if isinstance(record, dict) else {}
    meta = tool_prefs.tool_meta(alias)
    display = _ui(
        str(meta.get('display_en') or spec.get('display_name_en') or spec.get('display_name') or alias),
        str(meta.get('display_ja') or spec.get('display_name_ja') or spec.get('display_name') or alias),
    )
    icon = str(meta.get('icon') or spec.get('icon') or 'PLUGIN')
    return display, icon



def _draw_captured_panels(layout, context, record: dict) -> bool:
    # Do not re-host arbitrary Panel.draw callbacks.  The supported integration
    # path is draw_smart_shader_runtime_controls(), which receives a normal UILayout
    # and avoids Blender panel-class lifetime issues.
    del layout, context, record
    return False


def _draw_record_body(layout, context, alias: str, record: dict) -> None:
    status = str(record.get('status') or '')
    if status == 'disabled_by_user':
        layout.label(text=_ui('Disabled', '無効'), icon='CHECKBOX_DEHLT')
        return
    if status == 'unsupported_platform':
        layout.label(text=_ui('Unsupported platform', '現在の OS・CPU では無効'), icon='ERROR')
        return
    if status == 'failed':
        row = layout.column(align=True)
        op = row.operator(SMART_SHADER_SUITE_04BF59_NPANEL_OT_load_feature.bl_idname, text=_ui('Reload', '再読み込み'), icon='FILE_REFRESH')
        op.addon_alias = alias
        op.force_reload = True
        row.label(text=_ui('Load failed', '読み込み失敗'), icon='ERROR')
        excerpt = _trace_excerpt(record.get('error', ''))
        if excerpt:
            layout.label(text=excerpt)
        return
    if status != 'loaded':
        row = layout.column(align=True)
        op = row.operator(SMART_SHADER_SUITE_04BF59_NPANEL_OT_load_feature.bl_idname, text=_ui('Load', '読み込み'), icon='IMPORT')
        op.addon_alias = alias
        op.force_reload = False
        row.label(text=_ui('On-demand', '使用時に読み込み'), icon='TIME')
        return

    module = record.get('module')
    hook = getattr(module, 'draw_smart_shader_runtime_controls', None) if module is not None else None
    drew_hook = False
    if callable(hook):
        try:
            hook(layout, context)
            drew_hook = True
        except Exception as exc:
            warn = layout.box()
            warn.alert = True
            warn.label(text=_ui('Feature UI error', '機能UIエラー'), icon='ERROR')
            warn.label(text=_exc_text(exc))
    if not drew_hook:
        layout.label(text=_ui('No safe settings UI hook was exposed by this feature.', 'この機能から安全な設定UIフックが公開されていません。'))

    if _menu_entries(record) or _operator_entries(record):
        commands = layout.box()
        commands.label(text=_ui('Additional Commands', '追加コマンド'), icon='TOOL_SETTINGS')
        _draw_tool_list(commands, record, compact=True)


def draw_tool_section(layout, context, alias: str, *, default_closed: bool = True) -> bool:
    """Draw one bundled feature as a Smart Modeling-style collapsible section."""
    alias = str(alias or '').strip()
    record = _record_for_alias(alias)
    display, icon = _tool_display_and_icon(alias, record)
    _box, section, expanded = ui_sections.draw_group(
        layout,
        context,
        'runtime_' + alias,
        display,
        icon=icon if icon else 'NONE',
        topic=alias,
        default_open=not bool(default_closed),
    )
    if not expanded:
        return True

    enabled = tool_prefs.tool_enabled(alias, context=context, default=True)
    if record is None:
        section.label(text=_ui('This feature module was not found in the package.', 'この機能モジュールがパッケージ内に見つかりません。'), icon='ERROR')
        return False
    if not enabled:
        section.label(text=_ui('This feature is disabled. Enable it from Settings > Bundled Features.', 'この機能は無効です。設定 > 同梱機能 で有効にしてください。'), icon='CHECKBOX_DEHLT')
        return True
    _draw_record_body(section, context, alias, record)
    return True



def draw_tool_group(layout, context, aliases: tuple[str, ...] | list[str], *, default_closed: bool = True) -> None:
    for alias in aliases:
        draw_tool_section(layout, context, str(alias), default_closed=default_closed)


def _resolve_operator_callable(op_id: str):
    op_id = str(op_id or '').strip()
    if '.' not in op_id:
        return None
    head, tail = op_id.split('.', 1)
    group = getattr(bpy.ops, head, None)
    if group is None:
        return None
    return getattr(group, tail, None)


def _json_dict(text: str) -> dict[str, Any]:
    text = str(text or '').strip()
    if not text:
        return {}
    try:
        value = json.loads(text)
    except Exception:
        return {}
    return value if isinstance(value, dict) else {}


def _iter_window_area_regions(context):
    seen: set[tuple[int, int, int]] = set()

    def _yield_from(window):
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) or ():
            region = next((reg for reg in getattr(area, 'regions', ()) or () if getattr(reg, 'type', None) == 'WINDOW'), None)
            if region is None:
                continue
            key = (id(window), id(area), id(region))
            if key in seen:
                continue
            seen.add(key)
            yield window, area, region

    current_window = getattr(context, 'window', None) or getattr(getattr(bpy, 'context', None), 'window', None)
    if current_window is not None:
        yield from _yield_from(current_window)

    wm = getattr(context, 'window_manager', None) or getattr(getattr(bpy, 'context', None), 'window_manager', None)
    for window in getattr(wm, 'windows', ()) or ():
        yield from _yield_from(window)


def _node_space_matches(space, *, tree_type: str = '', shader_type: str = '') -> bool:
    if space is None:
        return False
    if tree_type and str(getattr(space, 'tree_type', '') or '') != tree_type:
        return False
    if shader_type and str(getattr(space, 'shader_type', '') or '') != shader_type:
        return False
    return True


def _override_from_hint(context, hint: str) -> dict[str, Any] | None:
    hint = str(hint or '').strip().upper()
    if not hint:
        return None

    area_type = hint
    tree_type = ''
    shader_type = ''
    if hint in {'NODE_EDITOR', 'NODE', 'NODE_ANY'}:
        area_type = 'NODE_EDITOR'
    elif hint == 'NODE_SHADER':
        area_type = 'NODE_EDITOR'
        tree_type = 'ShaderNodeTree'
        shader_type = 'OBJECT'
    elif hint == 'NODE_GEOMETRY':
        area_type = 'NODE_EDITOR'
        tree_type = 'GeometryNodeTree'
    elif hint == 'NODE_COMPOSITOR':
        area_type = 'NODE_EDITOR'
        tree_type = 'CompositorNodeTree'
    elif hint == 'VIEW3D':
        area_type = 'VIEW_3D'

    fallback = None
    exact_required = bool(tree_type or shader_type)
    for window, area, region in _iter_window_area_regions(context):
        if getattr(area, 'type', None) != area_type:
            continue
        spaces = getattr(area, 'spaces', None)
        space = getattr(spaces, 'active', None) if spaces is not None else None
        override = {'window': window, 'area': area, 'region': region}
        if area_type == 'NODE_EDITOR':
            if _node_space_matches(space, tree_type=tree_type, shader_type=shader_type):
                return override
            if not exact_required and fallback is None:
                fallback = override
        else:
            return override
    return None if exact_required else fallback


def _default_override_hint(alias: str, kind: str, target_id: str) -> str:
    alias = str(alias or '').strip()
    kind = str(kind or '').strip()
    target_id = str(target_id or '').strip()
    if alias in {'math_controller'}:
        return 'NODE_EDITOR'
    if kind == 'menu' and target_id.startswith('NODE_MT_'):
        return 'NODE_EDITOR'
    if target_id.startswith('node.') or target_id.startswith('o_oo.') or target_id.startswith('wm.main_panel'):
        return 'NODE_EDITOR'
    return ''


def _call_with_override(context, override: dict[str, Any] | None, callback):
    base_context = context or getattr(bpy, 'context', None)
    if override and base_context is not None and hasattr(base_context, 'temp_override'):
        with base_context.temp_override(**override):
            return callback()
    return callback()


def _context_requirement_message(hint: str) -> str:
    hint = str(hint or '').strip().upper()
    if hint.startswith('NODE'):
        return _ui('Open a Node Editor area for this tool, then try again.', 'この機能は ノードエディター を開いた状態で実行してください。')
    if hint in {'VIEW_3D', 'VIEW3D'}:
        return _ui('Open a 3D View area for this tool, then try again.', 'この機能は 3Dビューポート を開いた状態で実行してください。')
    return ''


class SMART_SHADER_SUITE_04BF59_NPANEL_OT_load_feature(bpy.types.Operator):
    bl_idname = 'smart_shader_suite.load_feature'
    bl_label = _ui('Load Feature', '機能読み込み')
    bl_description = _lt('JP: 選択した機能だけを必要時に読み込み、スマートシェーダーNパネル内で操作できるようにします。起動時に全機能を一括読み込みしないため、Blenderの立ち上がりと通常操作を軽く保てます。\nEN: Load only the selected feature on demand and expose its controls in the Smart Shader N-panel. Startup stays lighter because bundled tools are not batch-loaded.')
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})
    force_reload: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        alias = str(getattr(self, 'addon_alias', '') or '').strip()
        if not alias:
            self.report({'WARNING'}, _ui('No feature was specified.', '読み込む機能が指定されていません。'))
            return {'CANCELLED'}
        if not tool_prefs.tool_enabled(alias, context=context, default=True):
            self.report({'WARNING'}, _ui('This feature is disabled in Settings > Bundled Features.', 'この機能は設定 > 同梱機能で無効になっています。'))
            return {'CANCELLED'}
        if bool(getattr(self, 'force_reload', False)):
            try:
                loader.unload_addon(alias)
            except Exception:
                pass
        record = loader.load_addon(alias)
        try:
            _collect_records()
        except Exception:
            pass
        try:
            refresh_all_suites(context)
        except Exception:
            pass
        if not isinstance(record, dict) or str(record.get('status') or '') != 'loaded':
            excerpt = _trace_excerpt((record or {}).get('error', '') if isinstance(record, dict) else '')
            self.report({'ERROR'}, excerpt or _ui('The selected feature could not be loaded.', '選択した機能を読み込めませんでした。'))
            return {'CANCELLED'}
        spec = dict(record.get('spec') or {})
        display = _ui(str(spec.get('display_name_en') or spec.get('display_name') or alias), str(spec.get('display_name_ja') or spec.get('display_name') or alias))
        self.report({'INFO'}, _ui(f'Loaded {display}.', f'{display} を読み込みました。'))
        return {'FINISHED'}


class SMART_SHADER_SUITE_04BF59_NPANEL_OT_show_tool_info(bpy.types.Operator):
    bl_idname = 'smart_shader_suite.show_tool_info'
    bl_label = _ui('Show Tool Info', '機能情報表示')
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        alias = str(getattr(properties, 'addon_alias', '') or '')
        record = _RECORDS_BY_ALIAS.get(alias, {})
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = _status_text(record) if isinstance(record, dict) else _ui('Unknown', '不明')
        note = str(spec.get('note') or '').strip()
        lines = [
            f"{spec.get('display_name', alias)}",
            _addon_help(spec),
            _ui(f'Status: {status}', f'状態: {status}'),
        ]
        if note:
            lines.append(_ui(f'Note: {note}', f'注記: {note}'))
        return ' '.join(str(line) for line in lines if line)

    def execute(self, _context):
        alias = str(self.addon_alias or '')
        record = _RECORDS_BY_ALIAS.get(alias, {})
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = _status_text(record) if isinstance(record, dict) else _ui('Unknown', '不明')
        self.report({'INFO'}, _ui(f"{spec.get('display_name', alias)} - {status}", f"{spec.get('display_name', alias)} - {status}"))
        return {'FINISHED'}


class SMART_SHADER_SUITE_04BF59_NPANEL_OT_run_tool(bpy.types.Operator):
    bl_idname = 'smart_shader_suite.run_tool'
    bl_label = _ui('Run Tool', '機能実行')
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_kind: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_id: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_label: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_desc: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_kwargs_json: bpy.props.StringProperty(options={'SKIP_SAVE'})
    override_hint: bpy.props.StringProperty(options={'SKIP_SAVE'})
    is_pie_menu: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        kind = str(getattr(properties, 'target_kind', '') or '')
        label = str(getattr(properties, 'target_label', '') or '')
        desc = str(getattr(properties, 'target_desc', '') or '')
        is_pie = bool(getattr(properties, 'is_pie_menu', False))
        return ' '.join([
            _target_help(kind, label, desc, is_pie=is_pie),
        ])

    def execute(self, context):
        alias = str(self.addon_alias or '').strip()
        if alias:
            record = loader.load_addon(alias)
            if isinstance(record, dict) and str(record.get('status') or '') == 'loaded':
                try:
                    _collect_records()
                except Exception:
                    pass
        kind = str(self.target_kind or '').strip()
        target_id = str(self.target_id or '').strip()
        if not target_id:
            self.report({'WARNING'}, _ui('No tool command was selected.', 'ツールコマンドが選択されていません。'))
            return {'CANCELLED'}
        override_hint = str(self.override_hint or '').strip() or _default_override_hint(alias, kind, target_id)
        override = _override_from_hint(context, override_hint)
        requirement = _context_requirement_message(override_hint) if override is None else ''

        if kind == 'menu':
            try:
                def _menu_call():
                    if self.is_pie_menu:
                        return bpy.ops.wm.call_menu_pie(name=target_id)
                    return bpy.ops.wm.call_menu(name=target_id)
                return _call_with_override(context, override, _menu_call)
            except Exception as exc:
                message = _ui('The menu could not be opened.', 'メニューを開けませんでした。')
                if requirement:
                    message = f'{message} {requirement}'
                self.report({'ERROR'}, message)
                return {'CANCELLED'}

        if target_id == 'wm.tool_set_by_id':
            self.report({'ERROR'}, _ui('Workspace toolbar tools are not used by Smart Shader. This command was blocked to avoid activating an empty 3D View tool.', 'スマートシェーダーはワークスペースのツールバー機能を使用しません。空の3Dビュー用ツールを有効化しないよう、このコマンドはブロックしました。'))
            return {'CANCELLED'}

        op_callable = _resolve_operator_callable(target_id)
        if not callable(op_callable):
            self.report({'ERROR'}, _ui('This command is not available.', 'このコマンドは使えません。'))
            return {'CANCELLED'}

        kwargs = _json_dict(self.target_kwargs_json)
        last_error = None
        call_attempts = []
        if kwargs:
            call_attempts.extend([(('INVOKE_DEFAULT',), kwargs), (('EXEC_DEFAULT',), kwargs), (tuple(), kwargs)])
        else:
            call_attempts.extend([(('INVOKE_DEFAULT',), {}), (('EXEC_DEFAULT',), {}), (tuple(), {})])

        for args, extra_kwargs in call_attempts:
            try:
                result = _call_with_override(context, override, lambda args=args, extra_kwargs=extra_kwargs: op_callable(*args, **extra_kwargs))
                if isinstance(result, set):
                    return result
                return {'FINISHED'}
            except Exception as exc:
                last_error = exc
        message = _ui('The command could not be run.', 'コマンドを実行できませんでした。')
        if requirement:
            message = f'{message} {requirement}'
        self.report({'ERROR'}, message)
        return {'CANCELLED'}


# Dynamic proxy/host panels from older SmartTools builds are intentionally not
# generated in this N-panel build.  The root add-on owns normal static Panel
# classes in ui.py, and this module only provides operators plus inline drawing
# helpers for those panels.

def _collect_records() -> None:
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()
    for record in loader.get_records():
        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '')
        suite_key = str(spec.get('suite') or '')
        if alias:
            _RECORDS_BY_ALIAS[alias] = record
        if suite_key:
            _SUITE_RECORDS.setdefault(suite_key, []).append(record)



def register() -> None:
    _safe_unregister_registered_classes()
    _collect_records()
    _safe_register_class(SMART_SHADER_SUITE_04BF59_NPANEL_OT_load_feature)
    _safe_register_class(SMART_SHADER_SUITE_04BF59_NPANEL_OT_show_tool_info)
    _safe_register_class(SMART_SHADER_SUITE_04BF59_NPANEL_OT_run_tool)


def unregister() -> None:
    global _UI_REBUILD_SCHEDULED
    _UI_REBUILD_SCHEDULED = False
    _safe_unregister_registered_classes()
