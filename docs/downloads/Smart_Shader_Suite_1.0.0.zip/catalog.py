"""Reusable material catalog / vault built from full manifest snapshots."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
import re

from . import core
from .translation import loc_text as _lt, tx
from .translation import AddonError


CATALOG_SENTINEL = "NO_CATALOG_ENTRIES"
TAG_SPLIT_RE = re.compile(r"[,;、/|]+")


def catalog_path() -> Path:
    return core.addon_storage_dir() / "smart_shader_suite_material_catalog.json"


def _split_tag_values(values) -> list[str]:
    if values is None:
        return []
    if isinstance(values, str):
        raw_items = TAG_SPLIT_RE.split(values)
    elif isinstance(values, (list, tuple, set)):
        raw_items = []
        for item in values:
            raw_items.extend(_split_tag_values(item))
        return raw_items
    else:
        raw_items = [str(values)]
    return [str(item or "").strip() for item in raw_items if str(item or "").strip()]


def _sanitize_tags(values) -> list[str]:
    tags: list[str] = []
    seen: set[str] = set()
    for tag in _split_tag_values(values):
        clean = core.clean_library_name(tag)
        if not clean:
            continue
        key = core.library_name_key(clean)
        if key in seen:
            continue
        seen.add(key)
        tags.append(clean)
    return tags


def _auto_summaries(material_name: str, builder: str, family: str, node_count: int, texture_count: int, usages: list[str]) -> tuple[str, str]:
    builder_text = builder or family or "captured"
    usage_text = ", ".join(usages[:4]) if usages else "shader-driven"
    summary_en = (
        f"Reusable material asset snapshot captured from {material_name} using {builder_text}. "
        f"It stores a full manifest with {node_count} nodes and {texture_count} texture(s), plus recognized usages such as {usage_text}."
    )
    summary_ja = (
        f"{material_name} から取得した再利用用マテリアル資産スナップショットです。{builder_text} を基準に、"
        f"{node_count} ノードと {texture_count} 枚のテクスチャを含む完全マニフェストを保存し、{usage_text} などの用途情報も保持します。"
    )
    return summary_en, summary_ja


def _sanitize_catalog_entry(entry: dict) -> dict | None:
    if not isinstance(entry, dict):
        return None
    name = core.clean_library_name(entry.get("name", ""))
    if not name:
        return None
    manifest = entry.get("manifest") if isinstance(entry.get("manifest"), dict) else {}
    if not manifest:
        return None
    smart = manifest.get("smart_shader", {}) if isinstance(manifest.get("smart_shader"), dict) else {}
    texture_summary = manifest.get("texture_summary", {}) if isinstance(manifest.get("texture_summary"), dict) else {}
    usages = [
        str(item).strip().lower()
        for item in (entry.get("texture_usages") or texture_summary.get("recognized_usages") or [])
        if str(item).strip()
    ]
    seen_usages: set[str] = set()
    clean_usages: list[str] = []
    for usage in usages:
        if usage in seen_usages:
            continue
        seen_usages.add(usage)
        clean_usages.append(usage)
    node_count = int(entry.get("node_count", manifest.get("node_count", 0)) or 0)
    link_count = int(entry.get("link_count", manifest.get("link_count", 0)) or 0)
    texture_count = int(entry.get("texture_count", texture_summary.get("texture_count", 0)) or 0)
    missing_texture_count = int(entry.get("missing_texture_count", 0) or 0)
    builder = str(entry.get("builder", smart.get("builder", "")) or "").strip()
    family = str(entry.get("family", smart.get("family", "")) or "").strip()
    source_material = core.clean_library_name(entry.get("source_material", manifest.get("material_name", "")))
    summary_en = str(entry.get("summary_en", "") or "").strip()
    summary_ja = str(entry.get("summary_ja", "") or "").strip()
    if not summary_en or not summary_ja:
        auto_en, auto_ja = _auto_summaries(source_material or name, builder, family, node_count, texture_count, clean_usages)
        summary_en = summary_en or auto_en
        summary_ja = summary_ja or auto_ja
    return {
        "name": name,
        "summary_en": summary_en,
        "summary_ja": summary_ja,
        "tags": _sanitize_tags(entry.get("tags") or smart.get("tags") or []),
        "saved_at": str(entry.get("saved_at", "") or "").strip(),
        "source_material": source_material or name,
        "builder": builder,
        "family": family,
        "manifest": manifest,
        "texture_usages": clean_usages,
        "texture_count": texture_count,
        "node_count": node_count,
        "link_count": link_count,
        "missing_texture_count": missing_texture_count,
        "asset_marked": bool(entry.get("asset_marked", manifest.get("asset_marked", False))),
        "cleanup_protected": bool(entry.get("cleanup_protected", bool(smart.get("cleanup_protected", False)))),
    }


def _catalog_haystack(entry: dict) -> str:
    return " ".join(
        [
            str(entry.get("name", "") or ""),
            str(entry.get("source_material", "") or ""),
            str(entry.get("builder", "") or ""),
            str(entry.get("family", "") or ""),
            str(entry.get("summary_en", "") or ""),
            str(entry.get("summary_ja", "") or ""),
            " ".join(entry.get("tags", []) or []),
            " ".join(entry.get("texture_usages", []) or []),
        ]
    ).lower()


def _catalog_match_score(entry: dict, query: str) -> int:
    token_text = str(query or "").strip().lower()
    if not token_text:
        return 0
    terms = [core.normalize_texture_token(term) for term in token_text.split() if core.normalize_texture_token(term)]
    if not terms:
        return 0

    name = str(entry.get("name", "") or "").lower()
    tags = " ".join(entry.get("tags", []) or []).lower()
    builder = " ".join([str(entry.get("builder", "") or ""), str(entry.get("family", "") or "")]).lower()
    usages = " ".join(entry.get("texture_usages", []) or []).lower()
    summary = _catalog_haystack(entry)
    score = 0
    for term in terms:
        if term in name:
            score += 8
        elif term in tags:
            score += 6
        elif term in builder:
            score += 4
        elif term in usages:
            score += 3
        elif term in summary:
            score += 1
        else:
            return -1
    return score


def list_catalog_entries(query: str = "") -> list[dict]:
    entries = [item for item in (_sanitize_catalog_entry(entry) for entry in core.safe_json_load(catalog_path())) if item is not None]
    if query:
        scored = []
        for entry in entries:
            score = _catalog_match_score(entry, query)
            if score >= 0:
                scored.append((score, entry))
        scored.sort(key=lambda item: (-item[0], core.library_name_key(item[1].get("name", ""))))
        return [entry for _, entry in scored]
    entries.sort(key=lambda item: core.library_name_key(item.get("name", "")))
    return entries


def find_catalog_entry(name: str):
    target_key = core.library_name_key(name)
    if not target_key:
        return None
    for entry in list_catalog_entries():
        if core.library_name_key(entry.get("name", "")) == target_key:
            return entry
    return None


def catalog_count() -> int:
    return len(list_catalog_entries())


def catalog_items(scene=None):
    query = getattr(scene, "sss_catalog_search", "") if scene is not None else ""
    items = []
    for entry in list_catalog_entries(query=query):
        name = str(entry.get("name", "") or "")
        tags = ", ".join(entry.get("tags", []) or [])
        usages = ", ".join(entry.get("texture_usages", [])[:4] or [])
        en = (
            f"{entry.get('summary_en', '')}\n"
            f"Builder/Family: {entry.get('builder', '-') or '-'} / {entry.get('family', '-') or '-'}\n"
            f"Nodes: {entry.get('node_count', 0)}  Links: {entry.get('link_count', 0)}  Textures: {entry.get('texture_count', 0)}  Missing: {entry.get('missing_texture_count', 0)}\n"
            f"Tags: {tags or '-'}\n"
            f"Usages: {usages or '-'}"
        )
        ja = (
            f"{entry.get('summary_ja', '')}\n"
            f"ビルダー/ファミリー: {entry.get('builder', '-') or '-'} / {entry.get('family', '-') or '-'}\n"
            f"ノード: {entry.get('node_count', 0)}  リンク: {entry.get('link_count', 0)}  テクスチャ: {entry.get('texture_count', 0)}  欠損: {entry.get('missing_texture_count', 0)}\n"
            f"タグ: {tags or '-'}\n"
            f"用途: {usages or '-'}"
        )
        items.append((name, name, tx(scene, en, ja)))
    if not items:
        items.append((
            CATALOG_SENTINEL,
            tx(scene, "No Catalog Entries", "カタログ未登録"),
            tx(scene, "Save a material to the catalog first or adjust the search filter.", "先にマテリアルをカタログへ保存するか、検索条件を変えてください。"),
        ))
    return items


def save_catalog_entry_from_material(material, context, name: str = "", tags_text: str = "") -> dict:
    if material is None:
        raise AddonError(_lt("No material provided.", "マテリアルが指定されていません。"))
    entry_name = core.clean_library_name(name or getattr(material, "name", ""))
    if not entry_name:
        raise AddonError(_lt("Catalog entry name is required.", "カタログ項目名が必要です。"))
    manifest = core.material_manifest(material, context)
    smart = manifest.get("smart_shader", {}) if isinstance(manifest.get("smart_shader"), dict) else {}
    texture_summary = manifest.get("texture_summary", {}) if isinstance(manifest.get("texture_summary"), dict) else {}
    usages = [str(item).strip().lower() for item in (texture_summary.get("recognized_usages") or []) if str(item).strip()]
    summary_en, summary_ja = _auto_summaries(
        getattr(material, "name", entry_name),
        str(smart.get("builder", "") or "").strip(),
        str(smart.get("family", "") or "").strip(),
        int(manifest.get("node_count", 0) or 0),
        int(texture_summary.get("texture_count", 0) or 0),
        usages,
    )
    tags = _sanitize_tags(list(smart.get("tags") or []) + _split_tag_values(tags_text) + usages[:4])
    entry = {
        "name": entry_name,
        "summary_en": summary_en,
        "summary_ja": summary_ja,
        "tags": tags,
        "saved_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "source_material": getattr(material, "name", entry_name),
        "builder": str(smart.get("builder", "") or "").strip(),
        "family": str(smart.get("family", "") or "").strip(),
        "manifest": manifest,
        "texture_usages": usages,
        "texture_count": int(texture_summary.get("texture_count", 0) or 0),
        "node_count": int(manifest.get("node_count", 0) or 0),
        "link_count": int(manifest.get("link_count", 0) or 0),
        "missing_texture_count": core.count_missing_image_nodes(material),
        "asset_marked": bool(getattr(material, "asset_data", None)),
        "cleanup_protected": core.is_cleanup_protected(material),
    }
    db = list_catalog_entries()
    target_key = core.library_name_key(entry_name)
    replaced = False
    for index, item in enumerate(db):
        if core.library_name_key(item.get("name", "")) == target_key:
            db[index] = entry
            replaced = True
            break
    if not replaced:
        db.append(entry)
    db.sort(key=lambda item: core.library_name_key(item.get("name", "")))
    core.safe_json_save(catalog_path(), db)
    return {"saved": True, "replaced": replaced, "name": entry_name, "texture_count": entry["texture_count"], "node_count": entry["node_count"]}


def delete_catalog_entry(name: str) -> bool:
    target_key = core.library_name_key(name)
    if not target_key:
        return False
    db = list_catalog_entries()
    kept = [entry for entry in db if core.library_name_key(entry.get("name", "")) != target_key]
    if len(kept) == len(db):
        return False
    core.safe_json_save(catalog_path(), kept)
    return True


def export_catalog_library(path: Path) -> int:
    payload = list_catalog_entries()
    core.safe_json_save(Path(path), payload)
    return len(payload)


def _load_catalog_library_payload(path: Path) -> list[dict]:
    path = Path(path)
    if not path.exists():
        return []
    try:
        import json
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return []
    if isinstance(payload, dict):
        for key in ("catalog", "entries", "items", "library", "materials"):
            value = payload.get(key)
            if isinstance(value, list):
                payload = value
                break
        else:
            if payload.get("name") and isinstance(payload.get("manifest"), dict):
                payload = [payload]
            else:
                return []
    if not isinstance(payload, list):
        return []
    return [entry for entry in payload if isinstance(entry, dict)]


def import_catalog_library(path: Path, mode: str = "MERGE") -> dict:
    incoming_raw = _load_catalog_library_payload(Path(path))
    incoming: list[dict] = []
    skipped_invalid = 0
    for entry in incoming_raw:
        clean = _sanitize_catalog_entry(entry)
        if clean is None:
            skipped_invalid += 1
            continue
        incoming.append(clean)

    if mode == "REPLACE":
        core.safe_json_save(catalog_path(), incoming)
        return {"imported": len(incoming), "replaced": 0, "skipped_invalid": skipped_invalid, "total": len(incoming), "mode": "REPLACE"}

    merged: list[dict] = []
    seen: dict[str, int] = {}
    for entry in list_catalog_entries():
        key = core.library_name_key(entry.get("name", ""))
        seen[key] = len(merged)
        merged.append(entry)

    imported = 0
    replaced = 0
    for entry in incoming:
        key = core.library_name_key(entry.get("name", ""))
        if key in seen:
            merged[seen[key]] = entry
            replaced += 1
        else:
            seen[key] = len(merged)
            merged.append(entry)
            imported += 1
    merged.sort(key=lambda item: core.library_name_key(item.get("name", "")))
    core.safe_json_save(catalog_path(), merged)
    return {"imported": imported, "replaced": replaced, "skipped_invalid": skipped_invalid, "total": len(merged), "mode": "MERGE"}


def repair_catalog_library() -> dict:
    original = _load_catalog_library_payload(catalog_path())
    repaired: list[dict] = []
    seen: dict[str, int] = {}
    dropped = 0
    duplicates = 0
    for entry in original:
        clean = _sanitize_catalog_entry(entry)
        if clean is None:
            dropped += 1
            continue
        key = core.library_name_key(clean.get("name", ""))
        if key in seen:
            repaired[seen[key]] = clean
            duplicates += 1
        else:
            seen[key] = len(repaired)
            repaired.append(clean)
    repaired.sort(key=lambda item: core.library_name_key(item.get("name", "")))
    core.safe_json_save(catalog_path(), repaired)
    return {"before": len(original), "after": len(repaired), "dropped": dropped, "duplicates": duplicates}
