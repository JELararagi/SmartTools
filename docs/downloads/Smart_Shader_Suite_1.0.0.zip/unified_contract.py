# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Public Shader editor placements, runtime options and persistence ownership."""

CONTRACT_VERSION = 2
EXTENSION_ID = "smart_shader_suite"
SUITE_ID = EXTENSION_ID
SUITE_OWNER_UUID = "3f6d8d7f-671d-4ff1-bf32-bf15518208aa"
GENERATION = "5.18.230"
MANAGER_TOOL_KEY = "SMART_SHADER"
MANAGER_PUBLIC_API = "get_placement_state"
MANAGER_API_CALL = f"{MANAGER_PUBLIC_API}(tool_key, context, editor_key=...)"

CONFIG_FOLDER = "Smart_Shader_Suite"
CONFIG_FILE = f"{CONFIG_FOLDER}.json"
_SETTINGS = "window_manager.sss_npanel_settings"
_STUDIO = "window_manager.sss_material_studio"
_MATERIAL_EDITOR = "scene.sss_material_editor"
_TOON = "material.smart_toon_settings"
STATE_SAVE_PATH = f"{_SETTINGS}.npanel_state_save"
SECTION_OPEN_PATH = f"{_SETTINGS}.show_always_on_toggles"
RUNTIME_TOGGLE_PATHS = tuple(f"{_SETTINGS}.{name}" for name in (
    "integrated_material_library_auto_refresh_on_load", "material_studio_settings_handlers",
    "smart_toon_live_sync_enabled", "material_editor_load_restore_enabled",
    "transform_guard_enabled", "legacy_proxy_cleanup_enabled",
))
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()

# Each row is an actual sidebar container and the editor types it handles.
_EDITOR_PLACEMENTS = (
    ("", "VIEW_3D", ("VIEW_3D",)),
    ("image_editor", "IMAGE_EDITOR", ("IMAGE_EDITOR", "UV_EDITOR")),
    ("shader_editor", "NODE_EDITOR", (
        "SHADER_EDITOR", "COMPOSITOR", "GEOMETRY_NODE_EDITOR", "TEXTURE_NODE_EDITOR",
    )),
    ("video_sequencer", "SEQUENCE_EDITOR", ("VIDEO_SEQUENCER",)),
    ("movie_clip_editor", "CLIP_EDITOR", ("MOVIE_CLIP_EDITOR",)),
    ("dope_sheet", "DOPESHEET_EDITOR", ("DOPE_SHEET",)),
    ("graph_editor", "GRAPH_EDITOR", ("GRAPH_EDITOR", "DRIVERS")),
    ("nla_editor", "NLA_EDITOR", ("NLA_EDITOR",)),
    ("text_editor", "TEXT_EDITOR", ("TEXT_EDITOR",)),
    ("file_browser", "FILE_BROWSER", ("FILE_BROWSER",)),
    ("asset_browser", "FILE_BROWSER", ("ASSET_BROWSER",)),
    ("spreadsheet", "SPREADSHEET", ("SPREADSHEET",)),
)
_PANEL = "SSS_PT_shader_tools"
ROOT_LOGICAL_EDITOR_KEYS = {
    f"{_PANEL}_{suffix}" if suffix else _PANEL: editors
    for suffix, _, editors in _EDITOR_PLACEMENTS
}
ROOT_PANEL_IDS = tuple(ROOT_LOGICAL_EDITOR_KEYS)
LOGICAL_TO_PHYSICAL = {
    editor: physical for _, physical, editors in _EDITOR_PLACEMENTS for editor in editors
}
PHYSICAL_ROOTS = tuple(dict.fromkeys(LOGICAL_TO_PHYSICAL.values()))
LOGICAL_EDITORS = tuple(LOGICAL_TO_PHYSICAL)
# This order is the manager's category order for the two file-based editors.
_file = LOGICAL_EDITORS.index("FILE_BROWSER")
LOGICAL_EDITORS = (*LOGICAL_EDITORS[:_file], "ASSET_BROWSER", "FILE_BROWSER", "SPREADSHEET")
LOGICAL_TO_PHYSICAL = {name: LOGICAL_TO_PHYSICAL[name] for name in LOGICAL_EDITORS}

ROOT_BODY_CALLABLE = "ui.draw_npanel_root"
ROOT_BODY_FINGERPRINT_POLICY = "identical_callable_identity"
POLL_MUTATION_ALLOWED = DRAW_MUTATION_ALLOWED = False
MANAGER_MISSING_POLICY = "FAIL_OPEN"
MANAGER_NOT_READY_POLICY = "MANAGER_LAST_KNOWN_CURRENT_CELL"

PERSISTENCE_ROOTS = (_SETTINGS, _STUDIO, "scene.sss_*", _MATERIAL_EDITOR, _TOON)
EXCLUDED_TRANSIENT_PATHS = (
    f"{_SETTINGS}.name", f"{_STUDIO}.name", _MATERIAL_EDITOR,
    *(f"{_MATERIAL_EDITOR}.{key}" for key in ("name", "video_result", "scene_material_page")),
    "scene.sss_last_report", f"{_TOON}.name", "material.pbr_properties.name", "scene.matlib.name",
)
PERSISTED_DYNAMIC_RNA_PATTERNS = ("window_manager.sss_ft_*", "scene.matlib", "material.pbr_properties")
PERSISTED_INTERNAL_STATE_KEYS = ("window_manager.pbr_ui_state",)
PERSISTED_IDPROPERTY_PATTERNS = ('window_manager["sss_ui_section_open__*"]',)
