"""SmartToonのシーン内一括更新。Blenderのテキストエディターから単体実行可能。

有効なSmartShaderを利用する。更新前に別名バックアップを保存する。
原本ではなく作業用blendで実行する。結果はSMART_TOON_PATCH_RESULTに残る。
"""
import hashlib
import json
import sys
import tempfile
import uuid
from pathlib import Path

import bpy

MARKER = "B58_08_SCENE_REBUILD_20261024"
# 版と実行コードの SHA への固定は外した。動いている SmartShader の版と SHA は結果に記録する。
REQUIRED_CORE_NAMES = (
    "SETTINGS_PROPERTY_NAME", "SMART_TOON_SHADER_CORE_VERSION_TEXT", "_SuspendLiveUpdate",
    "_is_smart_toon_material", "_toon_settings", "_smart_toon_v1208_managed_nodes",
    "_smart_toon_v1208_capture_graph_transaction", "_smart_toon_v1208_restore_graph_transaction",
)


def _core():
    found = [m for name, m in tuple(sys.modules.items())
             if name.endswith(".smart_toon") and m is not None
             and callable(getattr(m, "rebuild_toon_material", None))
             and hasattr(bpy.types.Material, getattr(m, "SETTINGS_PROPERTY_NAME", ""))]
    if len(found) != 1:
        raise RuntimeError("SmartShaderのSmartToonを1つだけ有効にしてから実行してください。")
    missing = [name for name in REQUIRED_CORE_NAMES if not hasattr(found[0], name)]
    if missing:
        raise RuntimeError("このSmartToonにはパッチに必要な機能がありません（SmartToon lacks functions this patch needs）: "
                           + ", ".join(missing))
    return found[0]


def _runtime_identity(st):
    version = []
    try:
        import tomllib
        with Path(st.__file__).with_name("blender_manifest.toml").open("rb") as handle:
            text = str(tomllib.load(handle).get("version", ""))
        version = [int(part) for part in text.split(".") if part.isdigit()]
    except Exception:
        version = []
    core_sha256 = hashlib.sha256(Path(st.__file__).read_bytes()).hexdigest()
    return version, core_sha256


def _light_cache_keys(st, before):
    """再構築でライトから計算し直される方向の値（ライブの向きはドライバーが追う）。"""
    keys = ["light_x", "light_y", "light_z"] if before.get("lighting_mode") == "BLENDER_STANDARD" else []
    for index in range(1, int(getattr(st, "SMART_TOON_RIM_MAX", 4) or 4) + 1):
        prefix = "rim" if index == 1 else f"rim{index}"
        if before.get(f"{prefix}_mode") == "SEPARATE_LIGHT" and before.get(f"{prefix}_light_object"):
            keys += [f"{prefix}_light_{axis}" for axis in "xyz"]
    return [key for key in keys if key in before]


def _value(value):
    if isinstance(value, bpy.types.ID):
        return [value.bl_rna.identifier, value.name_full,
                value.library.filepath if value.library else ""]
    if isinstance(value, bpy.types.PropertyGroup):
        return settings_state(value)
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    return [_value(v) for v in value]


def settings_state(settings):
    return {p.identifier: _value(getattr(settings, p.identifier))
            for p in settings.bl_rna.properties
            if p.identifier != "rna_type" and not p.is_readonly}


def _brief(value):
    text = json.dumps(value, ensure_ascii=False, default=str)
    return text if len(text) <= 60 else text[:60] + "…"


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(",", ":")).encode("utf-8")).hexdigest()


def graph_state(material):
    tree = material.node_tree
    if tree is None:
        return None
    drivers = []
    driven = set()
    animation = tree.animation_data
    for curve in animation.drivers if animation else ():
        driven.add(curve.data_path)
        drivers.append([curve.data_path, curve.array_index, curve.driver.type,
                        curve.driver.expression,
                        [[v.name, v.type,
                          [[_value(t.id), t.data_path, t.bone_target,
                            t.transform_type, t.transform_space] for t in v.targets]]
                         for v in curve.driver.variables]])
    def socket_value(socket):
        # ドライバーの評価済みキャッシュ値は再描画で変わる。式と参照元を照合する。
        return ("DRIVEN" if socket.path_from_id('default_value') in driven
                else _value(socket.default_value))
    nodes = []
    for n in tree.nodes:
        nodes.append([n.name, n.bl_idname,
                      _value(getattr(n, "image", None)),
                      _value(getattr(n, "node_tree", None)),
                      [[[s.identifier, socket_value(s)] for s in sockets
                        if hasattr(s, "default_value")] for sockets in (n.inputs, n.outputs)]])
    return [sorted(nodes), sorted([l.from_node.name, l.from_socket.identifier,
                                  l.to_node.name, l.to_socket.identifier] for l in tree.links),
            sorted(drivers)]


def _stamp(st, material):
    return _digest([MARKER, st.SMART_TOON_SHADER_CORE_VERSION_TEXT,
                    settings_state(st._toon_settings(material)), graph_state(material)])


def patch_scene(scene=None, backup_directory=None):
    """開いているファイルのSmartToonを更新。シーン指定時はその使用材質に限定。"""
    st = _core()
    runtime_version, core_sha256 = _runtime_identity(st)
    materials = ({slot.material.as_pointer(): slot.material
                  for obj in scene.objects for slot in obj.material_slots if slot.material}
                 if scene is not None else {m.as_pointer(): m for m in bpy.data.materials})
    result = {"marker": MARKER, "runtime": runtime_version, "updated": [],
              "unchanged": [], "skipped": [], "failed": [], "rollback": [], "backup": None,
              "not_processed": [], "core_sha256": core_sha256}
    pending = []
    for mat in sorted(materials.values(), key=lambda m: m.name):
        if not st._is_smart_toon_material(mat):
            result["skipped"].append({"material": mat.name, "reason": "SmartToon対象外"})
            continue
        if mat.library or mat.override_library or not mat.is_editable:
            result["skipped"].append({"material": mat.name, "reason": "リンクまたはオーバーライド"})
            continue
        if (st.SETTINGS_PROPERTY_NAME not in mat.keys()
                and not st._smart_toon_v1208_managed_nodes(mat, mat.node_tree)):
            result["skipped"].append({"material": mat.name, "reason": "設定の所有根拠が不明確"})
            continue
        if mat.get(MARKER) == _stamp(st, mat):
            result["unchanged"].append(mat.name)
        else:
            pending.append(mat)
    if pending:
        folder = Path(backup_directory or (Path(tempfile.gettempdir()) / "SmartToon_Backups"))
        folder.mkdir(parents=True, exist_ok=True)
        backup = folder / ("SmartToon_" + uuid.uuid4().hex + ".blend")
        # 保存時のdepsgraph通知で、バックアップ前の値を変更させない。
        with st._SuspendLiveUpdate():
            saved = bpy.ops.wm.save_as_mainfile(filepath=str(backup), copy=True)
        if saved != {'FINISHED'} or not backup.is_file():
            raise RuntimeError("バックアップを保存できないため更新を中止しました。")
        result["backup"] = str(backup)
    for index, mat in enumerate(pending):
        before = settings_state(st._toon_settings(mat))
        before_graph = graph_state(mat)
        snapshot = st._smart_toon_v1208_capture_graph_transaction(mat)
        # アドオンの保存先から読んだ保留のプロファイルは材質の名前で引かれる。別のファイルの
        # 同じ名前の材質の値を組み直しで当てないよう、この材質の分は先に捨てる（今の設定を保つ）。
        pending_profiles = getattr(st, "_SMART_TOON_PENDING_PROFILES_V1208", None)
        if isinstance(pending_profiles, dict):
            pending_profiles.pop(mat.name, None)
        try:
            st.rebuild_toon_material(mat)
            # 標準ライトと別ライトのリムの再構築は、未使用材質の方向キャッシュも再計算する。
            # ユーザーが保持していた手動方向は保存し、ライブ追従はドライバーに任せる。
            settings = st._toon_settings(mat)
            restore = _light_cache_keys(st, before)
            if restore:
                with st._SuspendLiveUpdate():
                    for key in restore:
                        setattr(settings, key, before[key])
            after = settings_state(st._toon_settings(mat))
            if after != before:
                changed = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k))
                raise RuntimeError("再構築後の設定照合に失敗しました（Settings changed by the rebuild）: "
                                   + "; ".join(f"{k}: {_brief(before.get(k))} → {_brief(after.get(k))}"
                                               for k in changed[:8])
                                   + (f" ほか{len(changed) - 8}件" if len(changed) > 8 else ""))
            mat[MARKER] = _stamp(st, mat)
            result["updated"].append(mat.name)
        except Exception as exc:
            result["failed"].append({"material": mat.name, "error": str(exc)})
            try:
                with st._SuspendLiveUpdate():
                    st._smart_toon_v1208_restore_graph_transaction(mat, snapshot)
                restored = settings_state(st._toon_settings(mat)) == before and graph_state(mat) == before_graph
                result['rollback'].append({'material': mat.name, 'restored': restored})
            except Exception as restore_error:
                result['rollback'].append({'material': mat.name, 'restored': False, 'error': str(restore_error)})
            result['not_processed'] = [m.name for m in pending[index+1:]]
            break
    result["status"] = "FAILED" if result["failed"] else ("APPLIED" if pending else "PASS_NO_CHANGES")
    text = next((t for t in bpy.data.texts if t.get(MARKER) == "report"), None)
    if text is None:
        text = bpy.data.texts.new("SmartToon_一括更新結果.json"); text[MARKER] = "report"
    text.clear(); text.write(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
    return result


if __name__ == "__main__":
    SMART_TOON_PATCH_RESULT = patch_scene()
    print(json.dumps(SMART_TOON_PATCH_RESULT, ensure_ascii=False, indent=2))
