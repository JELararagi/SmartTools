# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import tool_preferences as tool_prefs
from . import storage
from .translation import tx

SUITE_META = {
    'smart_shader_suite': ('Smart Shader', ''),
}

SUITE_ORDER: tuple[str, ...] = tuple(SUITE_META.keys())

INTEGRATED_LAYOUT: tuple[tuple[str, str, str], ...] = (
    ('material_library', 'material_library', 'Material Library'),
    ('math_controller', 'math_controller', 'Math Controller'),
    ('pbr_lookdev', 'pbr_lookdev', 'PBR Lookdev'),
)

ALIAS_TO_FOLDER = {alias: folder for alias, folder, _display in INTEGRATED_LAYOUT}
FOLDER_TO_ALIAS = {folder: alias for alias, folder, _display in INTEGRATED_LAYOUT}
ALIAS_TO_DISPLAY = {alias: display for alias, _folder, display in INTEGRATED_LAYOUT}

_REPORT_LINE_RE = re.compile(
    r'^- \*\*(?P<display>.+?)\*\* \(`(?P<outer>.+?)`\) → `(?P<suite>.+?)` / (?P<status>load|skip)\s*$'
)

_CACHE: list[dict[str, Any]] | None = None


def package_root() -> Path:
    return Path(__file__).resolve().parent


def report_path() -> Path:
    return storage.user_data_file('reports', 'INTEGRATED_ADDONS_REPORT.md', create_parent=True)


def clear_cache() -> None:
    global _CACHE
    _CACHE = None


def sanitize_alias(filename: str) -> str:
    text = str(filename or '').strip()
    if text.lower().endswith('.zip'):
        text = text[:-4]
    text = text.replace(' ', '_')
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    if not text:
        text = 'integrated_addon'
    if not re.match(r'[A-Za-z_]', text):
        text = '_' + text
    return text


def _suite_name_to_key(label: str) -> str:
    normalized = str(label or '').strip().lower()
    if 'core' in normalized:
        return 'smart_shader_suite'
    return 'smart_shader_suite'


def _parse_report() -> dict[str, dict[str, Any]]:
    path = report_path()
    if not path.exists():
        return {}

    specs: dict[str, dict[str, Any]] = {}
    current: dict[str, Any] | None = None
    for raw_line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        line = raw_line.rstrip('\n')
        match = _REPORT_LINE_RE.match(line.strip())
        if match:
            alias = sanitize_alias(match.group('outer'))
            current = {
                'alias': alias,
                'outer_zip': match.group('outer').strip(),
                'display_name': match.group('display').strip(),
                'suite': _suite_name_to_key(match.group('suite').strip()),
                'suite_name': match.group('suite').strip(),
                'load': match.group('status').strip() == 'load',
                'note': '',
                'duplicate_of': '',
                'superseded_by': '',
                'spaces': [],
            }
            specs[alias] = current
            continue
        if current is None:
            continue
        stripped = line.strip()
        if stripped.startswith('- note:'):
            current['note'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- duplicate_of:'):
            current['duplicate_of'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- superseded_by:'):
            current['superseded_by'] = stripped.split(':', 1)[1].strip()
        elif stripped.startswith('- ui_strategy:'):
            _, _, rest = stripped.partition('spaces:')
            text = rest.strip()
            current['spaces'] = [] if not text or text == '-' else [item.strip() for item in text.split(',') if item.strip()]
    return specs


def _read_bl_info_name_and_description(py_path: Path) -> tuple[str, str]:
    try:
        text = py_path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return '', ''
    name_match = re.search(r'["\']name["\']\s*:\s*["\']([^"\']+)["\']', text)
    desc_match = re.search(r'["\']description["\']\s*:\s*["\']([^"\']+)["\']', text)
    return (name_match.group(1).strip() if name_match else '', desc_match.group(1).strip() if desc_match else '')


def build_specs(force: bool = False) -> list[dict[str, Any]]:
    global _CACHE
    if _CACHE is not None and not force:
        return list(_CACHE)

    report_specs = _parse_report()
    results: list[dict[str, Any]] = []
    root = package_root()
    for alias, folder, display in INTEGRATED_LAYOUT:
        folder_dir = root / folder
        if not folder_dir.exists():
            continue
        spec = dict(report_specs.get(alias) or {
            'alias': alias,
            'outer_zip': alias + '.zip',
            'display_name': display,
            'suite': 'smart_shader_suite',
            'suite_name': 'Smart Shader',
            'load': True,
            'note': '',
            'duplicate_of': '',
            'superseded_by': '',
            'spaces': [],
        })
        init_path = folder_dir / '__init__.py'
        if not init_path.exists():
            continue
        spec['folder'] = folder
        spec['vendor_dir'] = str(folder_dir)
        spec['src_dir'] = str(folder_dir)
        spec['source_root'] = ''
        spec['import_mode'] = 'root_package'
        spec['init_relpath'] = '__init__.py'
        spec['search_root'] = ''
        spec['suite_name'] = spec.get('suite_name') or SUITE_META.get(spec['suite'], ('Unknown', ''))[0]
        meta = tool_prefs.tool_meta(alias)
        needs_file_meta = not bool(meta.get('display_en') or meta.get('summary_en'))
        name = ''
        description = ''
        if needs_file_meta:
            name, description = _read_bl_info_name_and_description(init_path)
        display_en = str(meta.get('display_en') or spec.get('display_name') or name or display or folder)
        display_ja = str(meta.get('display_ja') or display_en)
        spec['display_name_en'] = display_en
        spec['display_name_ja'] = display_ja
        spec['display_name'] = tx(None, display_en, display_ja)
        spec['summary_en'] = str(meta.get('summary_en') or description or display_en)
        spec['summary_ja'] = str(meta.get('summary_ja') or spec['summary_en'])
        spec['usage_en'] = str(meta.get('usage_en') or '')
        spec['usage_ja'] = str(meta.get('usage_ja') or spec['usage_en'])
        spec['icon'] = str(meta.get('icon') or 'PLUGIN')
        spec['description'] = description or display_en
        results.append(spec)

    _CACHE = list(results)
    return list(results)
