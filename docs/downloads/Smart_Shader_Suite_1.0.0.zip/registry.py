# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Discover the shipped tools and read optional user integration records."""

import ast
from copy import deepcopy
from pathlib import Path
import re

from . import storage, tool_preferences
from .translation import tx

SUITE_META = {"smart_shader_suite": ("Smart Shader", "")}
SUITE_ORDER = tuple(SUITE_META)
INTEGRATED_LAYOUT = tuple(
    (name, name, tool_preferences.tool_display(name)) for name in tool_preferences.TOOL_ORDER
)
ALIAS_TO_FOLDER = {alias: folder for alias, folder, _ in INTEGRATED_LAYOUT}
FOLDER_TO_ALIAS = {folder: alias for alias, folder, _ in INTEGRATED_LAYOUT}
ALIAS_TO_DISPLAY = {alias: label for alias, _, label in INTEGRATED_LAYOUT}

_REPORT_HEADER = re.compile(r"- \*\*(.*?)\*\* \(`([^`]+)`\) → `([^`]+)` / (load|skip)")
_OPTIONAL_FIELDS = {"note", "duplicate_of", "superseded_by"}
_CACHE = None


def package_root():
    return Path(__file__).resolve().parent


def report_path():
    return storage.user_data_file("reports", "INTEGRATED_ADDONS_REPORT.md", create_parent=True)


def clear_cache():
    global _CACHE
    _CACHE = None


def sanitize_alias(filename):
    name = str(filename or "").strip()
    if name.casefold().endswith(".zip"):
        name = name[:-4]
    alias = "_".join(re.findall(r"[A-Za-z0-9]+", name)).lower() or "integrated_addon"
    return "_" + alias if alias[0].isdigit() else alias


def _parse_report():
    try:
        content = report_path().read_text(encoding="utf-8-sig", errors="replace")
    except FileNotFoundError:
        return {}
    result = {}
    current = None
    for line in content.splitlines():
        line = line.strip()
        header = _REPORT_HEADER.fullmatch(line)
        if header:
            label, archive, suite_label, state = header.groups()
            current = {"display_name": label.strip(), "outer_zip": archive.strip(),
                       "suite_name": suite_label.strip(), "load": state == "load"}
            result[sanitize_alias(archive)] = current
            continue
        if current is None or not line.startswith("- "):
            continue
        key, _, value = line[2:].partition(":")
        if key in _OPTIONAL_FIELDS:
            current[key] = value.strip()
        if key == "ui_strategy":
            spaces = value.partition("spaces:")[2].strip()
            current["spaces"] = [item.strip() for item in spaces.split(",")
                                 if item.strip() and item.strip() != "-"]
    return result


def _read_bl_info_name_and_description(path):
    try:
        module = ast.parse(path.read_bytes())
    except (OSError, SyntaxError):
        return "", ""
    for node in module.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == "bl_info" for target in node.targets
        ) and isinstance(node.value, ast.Dict):
            metadata = {k.value: v.value.strip() for k, v in zip(node.value.keys, node.value.values)
                        if isinstance(k, ast.Constant) and isinstance(v, ast.Constant)
                        and isinstance(v.value, str)}
            return metadata.get("name", ""), metadata.get("description", "")
    return "", ""


def build_specs(force=False):
    global _CACHE
    if _CACHE is not None and not force:
        return deepcopy(_CACHE)
    reports = _parse_report()
    found = []
    for alias, folder, label in INTEGRATED_LAYOUT:
        directory = package_root() / folder
        init = directory / "__init__.py"
        if not init.is_file():
            continue
        report = reports.get(alias, {})
        meta = tool_preferences.tool_meta(alias)
        name, description = ("", "") if (meta.get("display_en") or meta.get("summary_en")) else (
            _read_bl_info_name_and_description(init)
        )
        english = meta.get("display_en") or report.get("display_name") or name or label
        japanese = meta.get("display_ja") or english
        summary = meta.get("summary_en") or description or english
        usage = meta.get("usage_en", "")
        entry = dict(alias=alias, outer_zip=alias + ".zip", suite_name="Smart Shader",
                     load=True, note="", duplicate_of="", superseded_by="", spaces=[])
        entry.update(report)
        entry.update(suite="smart_shader_suite", folder=folder, vendor_dir=str(directory),
                     src_dir=str(directory), import_mode="root_package", init_relpath="__init__.py",
                     source_root="", search_root="", display_name=tx(None, english, japanese),
                     display_name_en=english, display_name_ja=japanese, summary_en=summary,
                     summary_ja=meta.get("summary_ja") or summary, usage_en=usage,
                     usage_ja=meta.get("usage_ja") or usage, icon=meta.get("icon") or "PLUGIN",
                     description=description or english)
        found.append(entry)
    _CACHE = found
    return deepcopy(found)
