# ============================================================================
# Add Node
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
# ============================================================================

bl_info = {'name': 'Add Node', 'author': 'JELararagi', 'version': (1, 0, 0), 'blender': (5, 1, 0), 'location': 'Smart Shader > Add Node', 'description': 'Formula-driven node controller tools integrated into Smart Shader', 'category': 'Node'}
from ..translation import loc_text as _lt
from .. import ui_sections
import bpy
from bpy.app.translations import pgettext_iface
import traceback
import ast
MATH_OPS = {ast.Add: 'ADD', ast.Sub: 'SUBTRACT', ast.Mult: 'MULTIPLY', ast.Div: 'DIVIDE', ast.Pow: 'POWER'}
FUNC_OPS = {'add': 'ADD', 'sub': 'SUBTRACT', 'mul': 'MULTIPLY', 'div': 'DIVIDE', 'madd': 'MULTIPLY_ADD', 'pow': 'POWER', 'log': 'LOGARITHM', 'sqrt': 'SQRT', 'inv_sqrt': 'INVERSE_SQRT', 'abs': 'ABSOLUTE', 'exp': 'EXPONENT', 'min': 'MINIMUM', 'max': 'MAXIMUM', 'less': 'LESS_THAN', 'greater': 'GREATER_THAN', 'sign': 'SIGN', 'compare': 'COMPARE', 's_min': 'SMOOTH_MIN', 's_max': 'SMOOTH_MAX', 'round': 'ROUND', 'floor': 'FLOOR', 'ceil': 'CEIL', 'trunc': 'TRUNCATE', 'fract': 'FRACTION', 'mod_t': 'TRUNCATED_MODULO', 'mod_f': 'FLOORED_MODULO', 'wrap': 'WRAP', 'snap': 'SNAP', 'pingpong': 'PINGPONG', 'sin': 'SINE', 'cos': 'COSINE', 'tan': 'TANGENT', 'asin': 'ARCSINE', 'acos': 'ARCCOSINE', 'atan': 'ARCTANGENT', 'atan2': 'ARCTAN2', 'sinh': 'SINH', 'cosh': 'COSH', 'tanh': 'TANH', 'rad': 'RADIANS', 'deg': 'DEGREES'}
HELP_LAYOUT_DATA = {'Functions': [('+    add(  ,  )', 'Add'), ('-    sub(  ,  )', 'Subtract'), ('*    mul(  ,  )', 'Multiply'), ('/    div(  ,  )', 'Divide'), ('madd(  ,  ,  )', 'Multiply Add'), ('', ''), ('log(  ,  )', 'Logarithm'), ('sqrt(  )', 'Square Root'), ('inv_sqrt(  )', 'Inverse Square Root'), ('abs(  )', 'Absolute'), ('exp(  )', 'Exponent')], 'Comparison': [('min(  ,  )', 'Minimum'), ('max(  ,  )', 'Maximum'), ('less(  ,  )', 'Less Than'), ('greater(  ,  )', 'Greater Than'), ('sign(  )', 'Sign'), ('compare(  ,  ,  )', 'Compare'), ('s_min(  ,  ,  )', 'Smooth Minimum'), ('s_max(  ,  ,  )', 'Smooth Maximum')], 'Rounding': [('round(  )', 'Round'), ('floor(  )', 'Floor'), ('ceil(  )', 'Ceil'), ('trunc(  )', 'Truncate'), ('', ''), ('fract(  )', 'Fraction'), ('mod_t(  ,  )', 'Modulo'), ('mod_f(  ,  )', 'Floored Modulo'), ('wrap(  ,  ,  )', 'Wrap'), ('snap(  ,  )', 'Snap'), ('pingpong(  ,  )', 'Ping-Pong')], 'Trigonometric': [('sin(  )', 'Sine'), ('cos(  )', 'Cosine'), ('tan(  )', 'Tangent'), ('', ''), ('asin(  )', 'Arcsine'), ('acos(  )', 'Arccosine'), ('atan(  )', 'Arctangent'), ('atan2(  ,  )', 'Arctan2'), ('', ''), ('sinh(  )', 'Hyperbolic Sine'), ('cosh(  )', 'Hyperbolic Cosine'), ('tanh(  )', 'Hyperbolic Tangent')], 'Conversion': [('rad(  )', 'To Radians'), ('deg(  )', 'To Degrees')]}
change_list_formula = [['^', '**']]

class o_oo_FormulaItem(bpy.types.PropertyGroup):

    def get_parent_node(self):
        parent_nodes = self.id_data.nodes
        parent_node = parent_nodes.get(self.get('parent_node_name', ''))
        if not parent_node or not hasattr(parent_node, 'formulas') or self not in parent_node.formulas.values():
            for n in parent_nodes:
                if hasattr(n, 'formulas') and any((i == self for i in n.formulas)):
                    self['parent_node_name'] = n.name
                    return n
                else:
                    None
        return parent_node

    def update_in_FromulaItem(self, context):
        parent_node = self.get_parent_node()
        if parent_node and hasattr(parent_node, 'update_in_MathController'):
            parent_node.update_in_MathController(self)
    num: bpy.props.IntProperty(name=_lt('Num'), description=_lt('JP: 数式スロットの番号です。コントローラーノード内で複数の数式を順番に管理するために使用します。\nEN: Formula slot number. Used to keep multiple formulas ordered inside the controller node.'))
    name: bpy.props.StringProperty(name=_lt('Name'), description=_lt('JP: 数式スロット名です。生成される入力や内部参照の識別に使用します。\nEN: Formula slot name. Used to identify generated inputs and internal references.'))
    expression: bpy.props.StringProperty(name=_lt('Formula'), description=_lt('JP: ノードネットワークへ変換する数式です。関数一覧の名前を使い、値や入力名を組み合わせて記述します。編集するとコントローラーが更新されます。\nEN: Formula converted into a node network. Use names from the function list and combine values or input names. Editing this field updates the controller.'), default='', update=update_in_FromulaItem)
    last_formula: bpy.props.StringProperty(name=_lt('Last_Formula'), description=_lt('JP: 前回処理した数式を保持する内部値です。変更検出と再構築判定に使用します。\nEN: Internal value storing the last processed formula. Used for change detection and rebuild decisions.'), default='')

    def id_property_register(self):
        self['input_sockets'] = list()
        self['error_msg'] = ''
        self['scale'] = [0, 0]
        self['parent_node_name'] = ''

class o_oo_NODE_OT_AddFormula(bpy.types.Operator):
    bl_idname = 'o_oo.add_formula'
    bl_label = _lt('Add Formula', '数式追加')
    bl_options = {'UNDO'}

    def execute(self, context):
        parent_node = getattr(context, 'node', None) or getattr(context, 'active_node', None)
        if not hasattr(parent_node, 'formulas'):
            return {'CANCELLED'}
        new_idx = len(parent_node.formulas) + 1
        item = parent_node.formulas.add()
        item.num = new_idx
        item.name = f'f{new_idx}'
        item.id_property_register()
        item['parent_node_name'] = parent_node.name
        return {'FINISHED'}

class o_oo_NODE_OT_RemoveFormula(bpy.types.Operator):
    bl_idname = 'o_oo.remove_formula'
    bl_label = _lt('Remove Formula', '数式削除')
    bl_options = {'UNDO'}

    def execute(self, context):
        node = getattr(context, 'node', None) or getattr(context, 'active_node', None)
        if not hasattr(node, 'formulas') or len(node.formulas) <= 1:
            return {'CANCELLED'}
        last_item = node.formulas[-1]
        if last_item.expression != '':
            self.report({'WARNING'}, _lt('Clear the formula first.'))
            return {'CANCELLED'}
        node.formulas.remove(len(node.formulas) - 1)
        return {'FINISHED'}

class o_oo_NODE_OT_EditFormula(bpy.types.Operator):
    bl_idname = 'o_oo.edit_formula'
    bl_label = _lt('Edit Formula', '数式編集')
    bl_options = {'UNDO'}
    index: bpy.props.IntProperty(description=_lt('JP: 編集対象の数式スロット番号です。高度な数式エディターを開くときに内部で使用します。\nEN: Index of the formula slot being edited. Used internally when opening the advanced formula editor.'))
    node_name: bpy.props.StringProperty(description=_lt('JP: 編集対象のAdd Nodeノード名です。エディター実行時に対象ノードを再取得するために使用します。\nEN: Name of the Add Node node being edited. Used to find the target node again when the editor runs.'))
    text_input: bpy.props.StringProperty(name='', description=_lt('JP: 高度な数式エディターで入力された数式テキストです。確定時に対象スロットへ反映されます。\nEN: Formula text entered in the advanced editor. Applied to the target slot when confirmed.'))

    def execute(self, context):
        if not getattr(self, 'node', None):
            tree = getattr(context.space_data, 'edit_tree', None)
            if not tree:
                return {'CANCELLED'}
            self.node = tree.nodes.get(self.node_name)
        if hasattr(getattr(self, 'node', None), 'formulas') and 0 <= self.index < len(self.node.formulas):
            self.node.formulas[self.index].expression = self.text_input
            return {'FINISHED'}
        return {'CANCELLED'}

    def invoke(self, context, event):
        if not getattr(self, 'node', ''):
            self.node = getattr(context, 'node', None) or getattr(context, 'active_node', None)
        if not hasattr(self.node, 'formulas') or not 0 <= self.index < len(self.node.formulas):
            return {'CANCELLED'}
        self.node_name = self.node.name
        self.text_input = self.node.formulas[self.index].expression
        d_width = len(self.text_input) // 10 * 100
        d_width = 1000 if d_width < 1000 else d_width if d_width < 10000 else 10000
        return context.window_manager.invoke_props_dialog(self, width=int(d_width))

    def draw_recursive(self, layout, func_node):
        if isinstance(func_node, list):
            row = layout.column(align=True)
            row.alignment = 'LEFT'
            for item in func_node:
                if isinstance(item, list):
                    col = row.column(align=True)
                    col.alignment = 'LEFT'
                    col.label(text='')
                    self.draw_recursive(col, item)
                elif isinstance(item, str):
                    row.label(text=_lt(str(item)))
        else:
            pass

    def draw(self, context):
        layout = self.layout
        row = layout.column()
        row.prop(self, 'text_input', text='')
        box = layout.box()
        a = o_oo_FormulaParser(self.text_input)
        funcs = a.parse()
        self.draw_recursive(box, funcs)
        box2 = layout.box()
        Hrow = box2.row(align=True)
        for category, items in HELP_LAYOUT_DATA.items():
            Hcol = Hrow.column(align=True)
            Hcol.alignment = 'LEFT'
            category_inte = _lt(pgettext_iface(category, 'NodeTree'))
            Hcol.label(text=category_inte)
            Hcol.label(text='─' * 17)
            Hrow2 = Hcol.row(align=True)
            Hrow2.alignment = 'LEFT'
            Hcol1 = Hrow2.column(align=True)
            Hcol2 = Hrow2.column(align=True)
            Hcol1.alignment = 'LEFT'
            Hcol2.alignment = 'LEFT'
            for symbol, desc in items:
                if symbol and desc:
                    desc_inte = _lt(pgettext_iface(desc, 'NodeTree'))
                    Hcol1.label(text=desc_inte)
                    Hcol2.label(text=symbol)
                else:
                    Hcol1.label(text='─' * 10)
                    Hcol2.label(text='─' * 7)

class o_oo_FormulaParser:

    def __init__(self, formula):
        self.formula = formula
        self.pos = 0
        self.pos2 = 0

    def parse(self):
        result = []
        try:
            while self.pos < len(self.formula):
                char = self.formula[self.pos]
                if char == ')':
                    self.pos2 += -1
                    if self.pos2 >= 0:
                        return result
                    else:
                        self.pos2 = 0
                if not result:
                    result.append(char)
                else:
                    result[-1] += char
                self.pos += 1
                if char == '(':
                    self.pos2 += 1
                    result.append(self.parse())
                    char = self.formula[self.pos]
                    result.append(char)
                    self.pos += 1
        finally:
            return result

class o_oo_NODE_OT_ExpandToGroupNode(bpy.types.Operator):
    bl_idname = 'o_oo.expand_to_group_node'
    bl_label = _lt('Expand to Group Node', 'グループノード展開')
    bl_options = {'UNDO'}

    def execute(self, context):
        parent_tree = getattr(context.space_data, 'edit_tree', None)
        parent_node = getattr(context, 'node', None) or getattr(context, 'active_node', None)
        if not (parent_tree and hasattr(parent_node, 'group_type') and getattr(parent_node, 'node_tree', None)):
            return {'CANCELLED'}
        group_node = parent_tree.nodes.new(type=parent_node.group_type)
        group_node.node_tree = parent_node.node_tree
        group_node.location = parent_node.location
        bpy.ops.node.select_all(action='DESELECT')
        group_node.select = True
        parent_tree.nodes.active = group_node
        bpy.ops.node.translate_attach_remove_on_cancel('INVOKE_DEFAULT')
        return {'FINISHED'}

class o_oo_NodeBuilder:

    def __init__(self, controller, tree):
        self.c = controller
        self.tree = tree
        self.links = tree.links
        self.node_in = None
        self.node_out = None
        self.anchor_name = self.c.formula_id
        self.node_dimension = []

    def get_or_create_frame(self):
        frame_name = f'Frame_{self.anchor_name}'
        frame = self.tree.nodes.get(frame_name)
        if not frame:
            frame = self.tree.nodes.new('NodeFrame')
            frame.name = frame_name
            frame.label = f'Formula:{self.anchor_name}'
        self.frame = frame
        return

    def clear_frame_contents(self, frame):
        for node in list(self.tree.nodes):
            if node.parent == frame and node.bl_idname != 'NodeReroute':
                self.tree.nodes.remove(node)

    def get_or_create_reroute(self, frame):
        reroute_name = f'Anchor_{self.anchor_name}'
        reroute = self.tree.nodes.get(reroute_name)
        if not reroute:
            reroute = self.tree.nodes.new('NodeReroute')
            reroute.name = reroute_name
            reroute.location = (200, -20 * self.c.formula_num)
        self.reroute = reroute
        return

    def renew(self, now: set, new: set):
        return (now - new, new - now)

    def setup_interface(self, all_vars):
        last_vars = set()
        for i, item in enumerate(self.c.formulas):
            if i != self.c.formula_num:
                last_vars |= set(item['input_sockets'])
        remo, make = self.renew({item.name for item in self.tree.interface.items_tree if item.in_out == 'INPUT'}, last_vars | all_vars)
        makesockets = sorted(list(make))
        for newsocket in makesockets:
            self.tree.interface.new_socket(name=newsocket, in_out='INPUT', socket_type='NodeSocketFloat')
        socket = next((item for item in self.tree.interface.items_tree if item.name == self.anchor_name and item.in_out == 'OUTPUT'), None)
        if not socket:
            socket = self.tree.interface.new_socket(name=self.anchor_name, in_out='OUTPUT', socket_type='NodeSocketFloat')
        self.c.forms['input_sockets'] = list(all_vars)
        my_num = self.tree.interface.items_tree.find(socket.name)
        for i in range(my_num):
            item = self.tree.interface.items_tree[i]
            oth_num = self.tree.interface.items_tree.find(item.name)
            if item.in_out == 'OUTPUT':
                if int(socket.name[1:]) < int(item.name[1:]):
                    my_num += -1
        self.tree.interface.move(socket, my_num)
        output_rema = {i.name for i in self.c.formulas if i.expression}
        for item in list(self.tree.interface.items_tree):
            if item.item_type == 'SOCKET' and item.in_out == 'INPUT' and (item.name in remo):
                if not getattr(self.c.inputs.get(item.name, 'no'), 'is_linked', ''):
                    self.tree.interface.remove(item)
        for item in list(self.tree.interface.items_tree):
            if item.item_type == 'SOCKET' and item.in_out == 'OUTPUT' and (item.name not in output_rema):
                if not getattr(self.c.inputs.get(item.name, 'no'), 'is_linked', ''):
                    self.tree.interface.remove(item)

    def dig_unary(self, ast_node, i):
        """連続した符号をまとめる"""
        'Combine consecutive unary signs'
        if isinstance(ast_node, ast.UnaryOp):
            if isinstance(ast_node.op, ast.USub):
                i = -i
            if isinstance(ast_node.operand, ast.UnaryOp):
                return self.dig_unary(ast_node.operand, i)
            else:
                return (ast_node.operand, i)
        return (ast_node, 0)

    def build_node(self, ast_node, depth):
        """再帰的なノード構築"""
        'Recursive node construction'
        if isinstance(ast_node, ast.Constant):
            return ast_node.value
        elif isinstance(ast_node, ast.Name):
            if ast_node.id[0] == 'f' and ast_node.id[1:].isdigit():
                reroute = self.tree.nodes.get('Anchor_' + ast_node.id, None)
                if reroute:
                    return reroute
                else:
                    self.c.forms['error_msg'] = 'Unavailable function symbol'
                    return 0
            else:
                return ast_node.id
        if isinstance(ast_node, (ast.BinOp, ast.Call)):
            depth += 1
            if depth > len(self.node_dimension) - 1:
                self.node_dimension.append(-1)
            self.node_dimension[depth] += 1
            math_node = self.tree.nodes.new('ShaderNodeMath')
            math_node.location = (-200 * depth, -180 * self.node_dimension[depth])
            if isinstance(ast_node, ast.BinOp):
                left = self.build_node(ast_node.left, depth)
                right = self.build_node(ast_node.right, depth)
                try:
                    math_node.operation = MATH_OPS.get(type(ast_node.op), '')
                    for i, val in enumerate([left, right]):
                        if isinstance(val, (int, float)):
                            math_node.inputs[i].default_value = val
                        elif isinstance(val, str):
                            self.links.new(self.node_in.outputs[val], math_node.inputs[i])
                        else:
                            self.links.new(val.outputs[0], math_node.inputs[i])
                except:
                    self.c.forms['error_msg'] = 'maybe: unavailable symbol'
            elif isinstance(ast_node, ast.Call):
                math_node.operation = FUNC_OPS.get(ast_node.func.id, 'ADD')
                args = []
                for h, arg in enumerate(ast_node.args):
                    args.append(self.build_node(arg, depth))
                for i, val in enumerate(args):
                    try:
                        if isinstance(val, (int, float)):
                            math_node.inputs[i].default_value = val
                        elif isinstance(val, str):
                            self.links.new(self.node_in.outputs[val], math_node.inputs[i])
                        else:
                            self.links.new(val.outputs[0], math_node.inputs[i])
                    except:
                        self.c.forms['error_msg'] = 'function:' + ast_node.func.id
                        self.c.forms['error_msg'] = self.c.forms['error_msg'] + ',maybe:' + 'too many vars'
                        None
            math_node.parent = self.frame
            return math_node
        elif isinstance(ast_node, ast.UnaryOp):
            new_ast, i = self.dig_unary(ast_node, 1)
            if i == 1:
                return self.build_node(new_ast, depth)
            elif isinstance(new_ast, ast.Constant):
                return -self.build_node(new_ast, depth)
            else:
                new_node = ast.BinOp(left=ast.Constant(value=-1), op=ast.Mult(), right=new_ast)
                ast.fix_missing_locations(new_node)
                return self.build_node(new_node, depth)

    def run(self, node_ast, all_vars):
        """構築プロセスの実行フロー"""
        'Execution flow of the build process'
        _lt('フレームベースの構築フロー')
        'Frame-based build flow'
        self.get_or_create_frame()
        self.clear_frame_contents(self.frame)
        self.frame.shrink = False
        self.get_or_create_reroute(self.frame)
        self.setup_interface(all_vars)
        self.tree.nodes.remove(self.frame)
        if node_ast:
            self.get_or_create_frame()
        self.node_in = next((n for n in self.tree.nodes if n.bl_idname == 'NodeGroupInput'), None)
        if not self.node_in:
            self.node_in = self.tree.nodes.new('NodeGroupInput')
            self.node_in.location = (-300, 0)
        self.node_out = next((n for n in self.tree.nodes if n.bl_idname == 'NodeGroupOutput'), None)
        if not self.node_out:
            self.node_out = self.tree.nodes.new('NodeGroupOutput')
            self.node_out.location = (300, 0)
        if node_ast:
            final_node = self.build_node(node_ast, -1)
            if final_node:
                if isinstance(final_node, (int, float)):
                    self.node_out.inputs[self.anchor_name].default_value = final_node
                elif isinstance(final_node, str):
                    self.links.new(self.node_in.outputs[final_node], self.reroute.inputs[0])
                else:
                    self.links.new(final_node.outputs[0], self.reroute.inputs[0])
            self.links.new(self.reroute.outputs[0], self.node_out.inputs[self.c.formula_id])
        else:
            pass
        o_oo_delayed_positioning(self)

def o_oo_delayed_positioning(builder):
    try:
        b = builder
        farthest = 300
        scale_x = 0
        scale_y = 0
        for n in b.tree.nodes:
            if farthest > n.location[0] and n.bl_idname != 'NodeGroupInput':
                farthest = n.location[0]
            if scale_x < abs(n.location[0]) and n.parent == b.frame:
                scale_x = abs(n.location[0])
            if scale_y < abs(n.location[1]) and n.parent == b.frame:
                scale_y = abs(n.location[1])
        b.node_in.location = (farthest - 200, 0)
        k = 0
        b.c.forms['scale'] = [scale_x, scale_y]
        for i in b.c.formulas:
            if i.expression:
                b.tree.nodes.get(f'Frame_{i.name}').location.y = k
                k += -i['scale'][1] - 200
    finally:
        return None

def o_oo_delay_copy(new, old):
    try:
        if old.node_tree:
            new.node_tree = old.node_tree.copy()
        else:
            new_tree = bpy.data.node_groups.new('.FormulaTree', new.node_type)
            new.node_tree = new_tree
        new.node_tree.name = '.internal_copy'
    finally:
        return None

class o_oo_BaseMathController(bpy.types.NodeCustomGroup):
    bl_label = _lt('Add Node')
    bl_icon = 'NODE'
    bl_tree_type = 'GeometryNodeTree'
    formulas: bpy.props.CollectionProperty(type=o_oo_FormulaItem, description=_lt('JP: Add Nodeノード内の数式スロット一覧です。各スロットからノード演算ネットワークを生成します。\nEN: Collection of formula slots inside the Add Node node. Each slot generates part of the math node network.'))

    def init(self, context):
        new_tree = bpy.data.node_groups.new('.internal', self.bl_tree_type)
        self.node_tree = new_tree
        self.width = 240
        if len(self.formulas) == 0:
            item = self.formulas.add()
            item.num = 1
            item.name = 'f1'
            item.id_property_register()
            item['parent_node_name'] = self.name

    def copy(self, node):
        o_oo_delay_copy(self, node)

    def draw_buttons(self, context, layout):
        main_col = layout.column(align=True)
        btn_row = main_col.column(align=True)
        btn_row.alignment = 'RIGHT'
        btn_row.operator('o_oo.add_formula', icon='ADD', text='', emboss=True)
        btn_row.operator('o_oo.remove_formula', icon='REMOVE', text='', emboss=True)
        for i, item in enumerate(self.formulas):
            row = main_col.column(align=True)
            sub = row.column(align=True)
            sub.alignment = 'LEFT'
            sub.label(text=f'{item.name} =', translate=False)
            row.prop(item, 'expression', text='')
            op = row.operator('o_oo.edit_formula', icon='TEXT', text='', emboss=True)
            if op:
                op.index = i
            error = item.get('error_msg', '')
            if error:
                box = main_col.box()
                box.alert = True
                box.label(text=error, icon='ERROR')
        sub_row = main_col.column(align=True)
        sub_col = sub_row.column(align=True)
        if self.node_tree:
            sub_row.label(text=_lt(f'JP: リンク済み: {self.node_tree.name}\nEN: Linked: {self.node_tree.name}'), icon='LINKED')
            op = sub_row.operator('o_oo.expand_to_group_node', text='', icon='NODETREE', emboss=True)
        else:
            None

    def update_in_MathController(self, forms):
        self.forms = forms
        self.formula = forms.expression
        self.formula_id = forms.name
        self.formula_num = int(self.formula_id[1:]) - 1
        self.last_formula = forms.last_formula
        try:
            if self.last_formula == self.formula:
                None
                return
            if self.get('_rebuilding', False):
                None
                return
            if not self.node_tree:
                None
                return
            self._rebuilding = True
            try:
                self.forms['error_msg'] = ''
                self.rebuild_internal(self.node_tree)
                self.last_formula = self.formula
                self.formulas[self.formula_num].last_formula = self.last_formula
            finally:
                self._rebuilding = False
        except Exception as e:
            self.forms['error_msg'] = 'unklnown error'
            None
            None

    def rebuild_internal(self, tree):
        formula_nor = self.formula
        for old, new in change_list_formula:
            formula_nor = formula_nor.replace(old, new)
        try:
            if self.formula != '':
                node_ast = ast.parse(formula_nor, mode='eval').body
                funcs = {n.func.id for n in ast.walk(node_ast) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)}
                all_vars = {n.id for n in ast.walk(node_ast) if isinstance(n, ast.Name) and n.id not in funcs}
                all_vars = {i for i in all_vars if not (i[0] == 'f' and i[1:].isdigit())}
            else:
                node_ast = ''
                all_vars = set()
        except Exception as e:
            None
            None
            self.forms['error_msg'] = _lt('Invalid Formula')
            return
        if any((len(i) > 60 for i in all_vars)):
            self.forms['error_msg'] = _lt('Variable name too long (max 60 chars)')
            return
        builder = o_oo_NodeBuilder(self, tree)
        builder.run(node_ast, all_vars)

    def free(self):
        if self.node_tree and self.node_tree.users <= 2:
            bpy.data.node_groups.remove(self.node_tree)

class o_oo_SHADER_NodeMathController(bpy.types.ShaderNodeCustomGroup, o_oo_BaseMathController):
    bl_idname = 'o_oo.ShaderNodeMathController'
    bl_tree_type = 'ShaderNodeTree'
    group_type = 'ShaderNodeGroup'

    def init(self, context):
        super().init(context)

class o_oo_COMP_NodeMathController(bpy.types.CompositorNodeCustomGroup, o_oo_BaseMathController):
    bl_idname = 'o_oo.CompositorNodeMathController'
    bl_tree_type = 'CompositorNodeTree'
    group_type = 'CompositorNodeGroup'

    def init(self, context):
        super().init(context)

class o_oo_GEO_NodeMathController(bpy.types.GeometryNodeCustomGroup, o_oo_BaseMathController):
    bl_idname = 'o_oo.GeometryNodeMathController'
    bl_tree_type = 'GeometryNodeTree'
    group_type = 'GeometryNodeGroup'

    def init(self, context):
        super().init(context)

class o_oo_NODE_OT_AddController(bpy.types.Operator):
    bl_idname = 'o_oo.add_controller'
    bl_label = _lt('Add Controller', 'コントローラー追加')
    bl_description = _lt('EN: Create a Add Node node directly from Smart Shader without using the Add menu. Choose Shader for the active material tree, Geometry for the active Geometry Nodes modifier, or Compositor for the current scene compositor tree. JP: Add メニューを使わずに スマートシェーダー から直接 Add Node ノードを追加します。Shader はアクティブマテリアル、Geometry はアクティブな ジオメトリノード モディファイア、Compositor は現在シーンのコンポジットツリーへ追加します。')
    bl_options = {'UNDO'}
    tree_kind: bpy.props.EnumProperty(name=_lt('Tree Kind'), description=_lt('JP: Add Nodeを追加するノードツリー種別です。Shaderはアクティブ材質、Geometryはアクティブジオメトリノード、Compositorは現在シーンのコンポジターへ追加します。\nEN: Node-tree type used when adding the Add Node. Shader targets the active material, Geometry targets active Geometry Nodes, and Compositor targets the current scene compositor.'), items=(('SHADER', _lt('Shader'), _lt('Add to the active object material node tree')), ('GEOMETRY', _lt('Geometry'), _lt('Add to the active Geometry Nodes modifier node group')), ('COMPOSITOR', _lt('Compositor'), _lt('Add to the active scene compositor node tree'))), default='SHADER')

    def execute(self, context):
        tree = None
        node_type = ''
        label = ''
        if self.tree_kind == 'SHADER':
            obj = getattr(context, 'active_object', None)
            mat = getattr(obj, 'active_material', None) if obj is not None else None
            if mat is None:
                self.report({'ERROR'}, _lt('Active object needs an active material. / アクティブオブジェクトにアクティブマテリアルが必要です。'))
                return {'CANCELLED'}
            try:
                mat.use_nodes = True
            except Exception:
                pass
            tree = getattr(mat, 'node_tree', None)
            node_type = 'o_oo.ShaderNodeMathController'
            label = 'Shader'
        elif self.tree_kind == 'GEOMETRY':
            obj = getattr(context, 'active_object', None)
            modifiers = getattr(obj, 'modifiers', None) if obj is not None else None
            active_modifier = getattr(modifiers, 'active', None) if modifiers is not None else None
            if getattr(active_modifier, 'type', None) == 'NODES' and getattr(active_modifier, 'node_group', None) is not None:
                tree = active_modifier.node_group
            elif modifiers is not None:
                for modifier in modifiers:
                    if getattr(modifier, 'type', None) == 'NODES' and getattr(modifier, 'node_group', None) is not None:
                        tree = modifier.node_group
                        break
            if tree is None:
                self.report({'ERROR'}, _lt('Active object needs a Geometry Nodes modifier with a node group. / アクティブオブジェクトにノードグループ付きの ジオメトリノード モディファイアが必要です。'))
                return {'CANCELLED'}
            node_type = 'o_oo.GeometryNodeMathController'
            label = 'Geometry'
        else:
            scene = getattr(context, 'scene', None)
            if scene is None:
                return {'CANCELLED'}
            tree = getattr(scene, 'compositing_node_group', None)
            if tree is None:
                before = set(bpy.data.node_groups)
                bpy.ops.node.new_compositing_node_group(name='Compositor')
                tree = next((item for item in bpy.data.node_groups if item not in before), None)
                if tree is not None:
                    tree.user_clear()
                    scene.compositing_node_group = tree
            node_type = 'o_oo.CompositorNodeMathController'
            label = 'Compositor'
        if tree is None:
            self.report({'ERROR'}, _lt('Target node tree was not found. / 追加先ノードツリーが見つかりません。'))
            return {'CANCELLED'}
        try:
            existing = [node for node in getattr(tree, 'nodes', ()) or ()]
            node = tree.nodes.new(type=node_type)
            max_x = max((float(getattr(item, 'location', (0.0, 0.0))[0]) + float(getattr(item, 'width', 180.0)) for item in existing), default=0.0)
            node.location = (max_x + 80.0, 0.0)
            for item in getattr(tree, 'nodes', ()) or ():
                try:
                    item.select = False
                except Exception:
                    pass
            try:
                node.select = True
            except Exception:
                pass
            try:
                tree.nodes.active = node
            except Exception:
                pass
        except Exception as exc:
            self.report({'ERROR'}, _lt('JP: Add Node の作成に失敗しました。\nEN: Failed to create Add Node.'))
            return {'CANCELLED'}
        self.report({'INFO'}, _lt(f'{label} Add Node created. / {label} 用 Add Node を追加しました。'))
        return {'FINISHED'}
SSS_DISABLE_PROXY_PANELS = True
SSS_HIDE_OPERATOR_IDS = {'o_oo.add_formula', 'o_oo.remove_formula', 'o_oo.edit_formula', 'o_oo.expand_to_group_node'}

def draw_smart_shader_runtime_controls(layout, context):
    _box, box, _expanded = ui_sections.draw_group(layout, context, 'math_controller_add_node', _lt('Add Node', 'ノード追加'), icon='NODETREE', topic='math_controller', default_open=False)
    col = box.column(align=True)
    op = col.operator('o_oo.add_controller', text=_lt('Add Shader Controller', 'シェーダーコントローラー追加'), icon='MATERIAL')
    op.tree_kind = 'SHADER'
    op = col.operator('o_oo.add_controller', text=_lt('Add Geometry Controller', 'ジオメトリコントローラー追加'), icon='GEOMETRY_NODES')
    op.tree_kind = 'GEOMETRY'
    op = col.operator('o_oo.add_controller', text=_lt('Add Compositor Controller', 'コンポジターコントローラー追加'), icon='NODE_COMPOSITING')
    op.tree_kind = 'COMPOSITOR'

classes = (o_oo_FormulaItem, o_oo_NODE_OT_AddFormula, o_oo_NODE_OT_RemoveFormula, o_oo_NODE_OT_EditFormula, o_oo_NODE_OT_ExpandToGroupNode, o_oo_NODE_OT_AddController, o_oo_BaseMathController, o_oo_SHADER_NodeMathController, o_oo_GEO_NodeMathController, o_oo_COMP_NodeMathController)

def o_oo_menu_func_geo(self, context):
    op = self.layout.operator('node.add_node', text=_lt('Add Node'))
    op.type = 'o_oo.GeometryNodeMathController'

def o_oo_menu_func_shader(self, context):
    op = self.layout.operator('node.add_node', text=_lt('Add Node'))
    op.type = 'o_oo.ShaderNodeMathController'

def o_oo_menu_func_comp(self, context):
    op = self.layout.operator('node.add_node', text=_lt('Add Node'))
    op.type = 'o_oo.CompositorNodeMathController'

def register():
    for i in classes:
        bpy.utils.register_class(i)

def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
if __name__ == '__main__':
    register()
