# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Shader Studio: upper-compatible material workflow upgrade.

This module integrates a Blender-native set of material, map, shader, library,
cleanup, relink, NPR, MaterialX/USD, and Substance-like smart material tools.
Generated settings and manifests are stored through storage.py under the
config/Smart_Shader_Suite area unless the user explicitly chooses a manual folder.
"""

import json
import math
import os
import random
import re
import time
from pathlib import Path
from xml.sax.saxutils import escape as _xml_escape

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, PropertyGroup

from . import storage
from .rules import _pattern_matcher
from . import core
from . import slot_selection
from . import smart_ui_assets
from . import ui_sections
from .translation import tx, loc_text as _lt


ADDON_VERSION = (5, 18, 224)
SETTINGS_FILENAME = "smart_shader_smart_settings.json"  # keep-legacy-name
VARIANT_DIRNAME = "shader_studio_variants"
LIBRARY_DIRNAME = "shader_studio_library"
EXPORT_DIRNAME = "shader_studio_exports"
# Folder names used before the rename. Keep reading them so existing variants, libraries and exports are found.
LEGACY_DIRNAMES = {
    VARIANT_DIRNAME: "smart_shader_smart_variants",  # keep-legacy-name
    LIBRARY_DIRNAME: "smart_shader_smart_library",  # keep-legacy-name
    EXPORT_DIRNAME: "smart_shader_smart_exports",  # keep-legacy-name
}


def _ui(en: str, ja: str) -> str:
    return tx(None, str(en or ""), str(ja or ""))


def _context_ui(context, en: str, ja: str) -> str:
    scene = getattr(context, "scene", None) if context is not None else None
    return tx(scene, str(en or ""), str(ja or ""))


def _safe_report(operator, level: set[str], message: str) -> None:
    try:
        from . import report_safety
        report_safety.safe_report(operator, level, message, tag="SmartShader.material_studio")
        return
    except Exception:
        pass
    try:
        operator.report(level, message)
    except Exception:
        pass


def _set_status(settings, message: str) -> None:
    if settings is None:
        return
    try:
        settings.last_report = str(message or "")[:2000]
    except Exception:
        pass


_SETTINGS_APPLYING = False
_SETTINGS_CACHE = None
_HANDLERS_REGISTERED = False
_POINTER_REGISTERED = False
_SECTION_ROOT_LAYOUT = None


def _class_has_bl_rna(cls: type) -> bool:
    try:
        rna = vars(cls).get('bl_rna') or getattr(cls, 'bl_rna', None)
        identifier = str(getattr(rna, 'identifier', '') or '')
        inherited = {'PropertyGroup', 'Panel', 'Operator', 'Menu', 'UIList', 'AddonPreferences'}
        return bool(identifier and identifier not in inherited)
    except Exception:
        return False

def _ensure_settings_class_registered() -> bool:
    global _SMS_SETTINGS_CLASS_REGISTERED
    if _class_has_bl_rna(SSS_MaterialStudioSettings):
        _SMS_SETTINGS_CLASS_REGISTERED = True
        return True
    try:
        bpy.utils.register_class(SSS_MaterialStudioSettings)
    except Exception:
        return _class_has_bl_rna(SSS_MaterialStudioSettings)
    _SMS_SETTINGS_CLASS_REGISTERED = _class_has_bl_rna(SSS_MaterialStudioSettings)
    return _SMS_SETTINGS_CLASS_REGISTERED


def _settings_path() -> Path | None:
    try:
        return storage.suite_settings_path(create=True)
    except Exception:
        return None


def _legacy_settings_path() -> Path | None:
    try:
        return storage.settings_file(SETTINGS_FILENAME, create=False)
    except Exception:
        return None


def _settings_owner(context=None):
    try:
        wm = getattr(context, "window_manager", None) if context is not None else getattr(bpy.context, "window_manager", None)
        return getattr(wm, "sss_material_studio", None)
    except Exception:
        return None


_PERSISTENT_NAMES = (
    "active_page", "ui_density", "use_large_icon_deck", "icon_button_scale", "show_visual_references", "quality_profile", "auto_layout_nodes", "auto_color_space_fix", "strict_texture_detection", "generate_quality_report", "material_preset", "style_preset", "atomic_preset", "assignment_scope",
    "material_name", "texture_directory", "photo_source", "relink_root", "library_root",
    "export_directory", "search_query", "rule_expression", "variant_name", "use_regex_rules",
    "assign_to_selected", "mark_asset", "use_fake_user", "cleanup_images", "cleanup_slots",
    "cleanup_duplicates", "recursive_scan", "force_texture_rewire", "create_outline_shell",
    "texture_scale", "roughness", "metallic", "normal_strength", "height_strength",
    "weathering_amount", "edge_wear_amount", "dirt_amount", "wetness_amount",
    "toon_steps", "toon_threshold", "line_width",
    "anime_line_mode", "anime_target_scope", "anime_line_set_name", "anime_brush_instance_name",
    "anime_reduction_instance_name", "anime_line_size_map", "anime_line_set_id",
    "anime_line_render_priority", "anime_line_output_mode", "anime_visible_lines", "anime_hidden_lines",
    "anime_merge_groups", "anime_self_intersection", "anime_viewport_preview", "anime_attribute_override_enabled",
    "anime_edge_outline", "anime_edge_open", "anime_edge_object", "anime_edge_intersection",
    "anime_edge_smoothing_boundary", "anime_edge_material_boundary", "anime_edge_selected",
    "anime_edge_normal_angle", "anime_edge_wireframe", "anime_brush_width", "anime_hidden_width",
    "anime_brush_color", "anime_hidden_color", "anime_brush_opacity", "anime_hidden_opacity",
    "anime_brush_angle", "anime_brush_jitter", "anime_brush_taper", "anime_brush_random_width",
    "anime_brush_dash_enabled", "anime_brush_dash_length", "anime_brush_gap_length",
    "anime_normal_angle_threshold", "anime_curve_bevel_scale", "anime_depth_offset",
    "anime_reduction_enabled", "anime_reduction_start", "anime_reduction_end",
    "anime_reduction_min_width", "anime_reduction_min_alpha", "anime_material_override_enabled",
    "anime_material_replace_color", "anime_material_disable_intersection",
    "anime_material_hidden_as_visible", "anime_material_mask_hidden_targets",
    "anime_render_visible_element", "anime_render_hidden_element", "anime_render_edge_elements",
    "anime_render_background_enabled", "anime_render_background_color",
    "anime_shader_base_color", "anime_shader_shadow_color", "anime_shader_highlight_color",
    "anime_shader_rim_color", "anime_shader_zone1", "anime_shader_zone2", "anime_shader_zone3",
    "anime_shader_highlight_strength", "anime_shader_rim_strength", "anime_shader_hatching_strength",
    "hdri_strength", "hdri_rotation",
    "decal_size", "id_slot_count", "batch_limit", "random_seed", "last_report",
)


def _owner_has_rna_property(owner, name: str) -> bool:
    if owner is None or not name:
        return False
    try:
        props = getattr(getattr(owner, "bl_rna", None), "properties", None)
    except Exception:
        props = None
    if props is None:
        return False
    try:
        return props.get(name) is not None
    except Exception:
        pass
    try:
        return str(name) in props.keys()
    except Exception:
        return False


def _collect_settings(owner) -> dict:
    data = {}
    if owner is None:
        return data
    for name in _PERSISTENT_NAMES:
        if not _owner_has_rna_property(owner, name):
            continue
        try:
            value = getattr(owner, name)
        except Exception:
            continue
        if isinstance(value, (str, int, float, bool)):
            data[name] = value
            continue
        try:
            if hasattr(value, "__iter__") and not isinstance(value, (str, bytes, bytearray)):
                items = [float(v) for v in list(value)]
                data[name] = items
        except Exception:
            continue
    return data


def _read_settings() -> dict:
    try:
        data = storage.read_suite_section('material_studio', {})
        if isinstance(data, dict) and data:
            return data
    except Exception:
        pass
    path = _legacy_settings_path()
    if path is None or not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def save_settings(owner=None, *, force: bool = False) -> None:
    global _SETTINGS_CACHE
    if _SETTINGS_APPLYING:
        return
    owner = owner or _settings_owner()
    if owner is None:
        return
    data = _collect_settings(owner)
    if not data:
        return
    if not force and data == _SETTINGS_CACHE:
        return
    try:
        if storage.write_suite_section('material_studio', data):
            _SETTINGS_CACHE = dict(data)
            return
    except Exception:
        pass


def apply_settings(owner=None) -> None:
    global _SETTINGS_APPLYING, _SETTINGS_CACHE
    owner = owner or _settings_owner()
    if owner is None:
        return
    data = _read_settings()
    if not data:
        _SETTINGS_CACHE = _collect_settings(owner)
        return
    _SETTINGS_APPLYING = True
    try:
        for name, value in data.items():
            if name not in _PERSISTENT_NAMES or not _owner_has_rna_property(owner, name):
                continue
            try:
                setattr(owner, name, value)
            except Exception:
                pass
    finally:
        _SETTINGS_APPLYING = False
    _SETTINGS_CACHE = _collect_settings(owner)


def _save_update(self, context) -> None:
    del context
    if not _SETTINGS_APPLYING:
        try:
            if not storage.npanel_state_save_enabled(default=True):
                return
        except Exception:
            pass
        save_settings(self)


@persistent
def _load_post_handler(_dummy=None):
    try:
        from . import transform_guard as _sss_transform_guard
        with _sss_transform_guard.preserve_object_transforms('material smart settings load_post'):
            apply_settings()
    except Exception:
        pass


@persistent
def _save_pre_handler(_dummy=None):
    try:
        from . import transform_guard as _sss_transform_guard
        with _sss_transform_guard.preserve_object_transforms('material smart settings save_pre'):
            save_settings(force=True)
    except Exception:
        pass



def _settings_handlers_enabled(context=None) -> bool:
    try:
        from . import preferences as _sss_preferences
        owner = _sss_preferences.npanel_settings_owner(context)
        if owner is not None and hasattr(owner, 'material_studio_settings_handlers'):
            return bool(getattr(owner, 'material_studio_settings_handlers'))
    except Exception:
        pass
    return False


def _register_settings_handlers() -> bool:
    try:
        if _load_post_handler not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(_load_post_handler)
        if _save_pre_handler not in bpy.app.handlers.save_pre:
            bpy.app.handlers.save_pre.append(_save_pre_handler)
        return True
    except Exception:
        return False


def _unregister_settings_handlers() -> None:
    try:
        if _load_post_handler in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(_load_post_handler)
        if _save_pre_handler in bpy.app.handlers.save_pre:
            bpy.app.handlers.save_pre.remove(_save_pre_handler)
    except Exception:
        pass


def sync_settings_handlers(context=None) -> None:
    global _HANDLERS_REGISTERED
    if _settings_handlers_enabled(context):
        _HANDLERS_REGISTERED = _register_settings_handlers()
    else:
        _unregister_settings_handlers()
        _HANDLERS_REGISTERED = False


_sync_settings_handlers = sync_settings_handlers

def _page_items(_self=None, _context=None):
    return [
        ("CREATE", _ui("Create", "生成"), _ui("Generate procedural, PBR, NPR, and atomic-node style materials.", "プロシージャル、PBR、NPR、アトミックノード風マテリアルを生成します。"), "MATERIAL", 0),
        ("SMART", _ui("Smart masks", "スマートマスク"), _ui("Apply mesh-aware approximations such as edge wear, dirt, wetness, moss, and puddles.", "エッジ摩耗、汚れ、濡れ、苔、水たまりなどのメッシュ対応風マスクを適用します。"), "MOD_MASK", 1),
        ("LIBRARY", _ui("Library", "ライブラリ"), _ui("Search, save, restore, and mark material assets.", "材質アセットの検索、保存、復元、アセット化を行います。"), "ASSET_MANAGER", 3),
        ("SCENE", _ui("Scene", "シーン"), _ui("Relink, cleanup, select by material, create material-ID palettes, and manage variants.", "再リンク、クリーンアップ、材質逆引き選択、IDパレット、バリアント管理を行います。"), "SCENE_DATA", 4),
        ("EXCHANGE", _ui("Exchange", "受け渡し"), _ui("Export MaterialX/USD approximations, AOV helpers, HDRI, and dynamic texture paths.", "MaterialX/USD近似出力、AOV補助、HDRI、動的テクスチャパスを扱います。"), "FILE_CACHE", 5),
    ]


def _material_items(_self=None, _context=None):
    return [
        ("PBR_UBER", _ui("Uber PBR", "汎用PBR"), _ui("Principled BSDF material equivalent to a general DCC uber shader.", "各DCCの汎用ウーバーシェーダーに相当するPrincipled BSDF材質です。"), "SHADING_RENDERED", 0),
        ("METAL", _ui("Metal", "金属"), _ui("Layered rough metal with procedural scratches and wear.", "傷と摩耗を含むプロシージャル金属です。"), "MESH_CYLINDER", 1),
        ("WOOD", _ui("Wood", "木材"), _ui("Wave and noise based procedural wood material.", "波形とノイズで生成する木材材質です。"), "OUTLINER_OB_CURVE", 2),
        ("STONE", _ui("Stone", "石材"), _ui("Voronoi and noise based stone, concrete, and mineral material.", "ボロノイとノイズで生成する石材・コンクリート系材質です。"), "MESH_ICOSPHERE", 3),
        ("FABRIC", _ui("Fabric", "布"), _ui("Fine bump and weave-like procedural fabric.", "細かい凹凸と織り目風の布材質です。"), "MOD_CLOTH", 4),
        ("WOOL", _ui("Wool", "羊毛"), _ui("High-frequency fiber bump and soft diffuse wool shader.", "高周波の繊維凹凸と柔らかい拡散を持つ羊毛材質です。"), "PARTICLES", 5),
        ("CLAY", _ui("Clay", "粘土"), _ui("Rough clay material with fingerprint-like micro displacement.", "指紋風の微細凹凸を持つ粘土材質です。"), "SCULPTMODE_HLT", 6),
        ("LIQUID", _ui("Liquid", "液体"), _ui("Transparent wet material with noise-driven surface tension approximation.", "ノイズ凹凸で表面張力を近似する透明・濡れ系材質です。"), "MOD_FLUID", 7),
        ("SKIN", _ui("Skin", "肌"), _ui("Subsurface and dual-specular approximated skin material.", "サブサーフェスと二重スペキュラを近似した肌材質です。"), "USER", 8),
        ("DECAL", _ui("Decal", "デカール"), _ui("Transparent decal material suitable for non-destructive surface details.", "非破壊サーフェスディテール向けの透明デカール材質です。"), "IMAGE_DATA", 9),
        ("EMISSIVE", _ui("Emissive", "発光"), _ui("Emission and motion-graphics style material.", "発光・モーショングラフィックス向け材質です。"), "LIGHT", 10),
    ]


def _style_items(_self=None, _context=None):
    return [
        ("TOON", _ui("Toon", "トゥーン"), _ui("Stepped toon shader using color ramps and high-contrast shading.", "カラーランプで階調化するトゥーン材質です。"), "COLOR", 0),
        ("HALFTONE", _ui("Halftone", "ハーフトーン"), _ui("Screen-tone style shader with procedural dot patterns.", "ドットパターンによるスクリーントーン風材質です。"), "GRID", 1),
        ("WATERCOLOR", _ui("Watercolor", "水彩"), _ui("Soft paper-noise based watercolor material.", "紙ノイズと淡い色変化を含む水彩風材質です。"), "BRUSH_DATA", 2),
        ("COMIC", _ui("Comic", "コミック"), _ui("Hard bands, rim light, and hatch-friendly contrast material.", "硬い階調、リムライト、ハッチング向けコントラストを含む材質です。"), "GREASEPENCIL", 3),
    ]


def _atomic_items(_self=None, _context=None):
    return [
        ("NOISE", _ui("Noise", "ノイズ"), _ui("Substance Designer style noise generator material.", "Substance Designer風のノイズ生成材質です。"), "FORCE_TURBULENCE", 0),
        ("VORONOI", _ui("Voronoi", "Voronoi"), _ui("Cellular distance pattern material.", "セル状距離パターン材質です。"), "MESH_ICOSPHERE", 1),
        ("GRADIENT", _ui("Gradient map", "グラデーションマップ"), _ui("Grayscale remap through a color ramp.", "グレースケールをカラーランプで再マップします。"), "COLOR", 2),
        ("EMBOSS", _ui("Emboss", "エンボス"), _ui("Emboss-like bump material.", "エンボス風のバンプ材質です。"), "MOD_DISPLACE", 3),
        ("REACTION", _ui("Reaction diffusion", "反応拡散"), _ui("Reaction-diffusion approximation built from mixed procedural noises.", "複数ノイズで反応拡散を近似します。"), "MOD_WAVE", 4),
    ]


def _scope_items(_self=None, _context=None):
    return [
        ("SELECTED", _ui("Selected", "選択中"), _ui("Operate on selected objects only.", "選択中のオブジェクトのみ処理します。"), "RESTRICT_SELECT_OFF", 0),
        ("ACTIVE", _ui("Active", "アクティブ"), _ui("Operate on the active object or material.", "アクティブオブジェクトまたは材質のみ処理します。"), "OBJECT_DATA", 1),
        ("SCENE", _ui("Scene", "シーン"), _ui("Operate across the whole scene.", "シーン全体を処理します。"), "SCENE_DATA", 2),
    ]


def _ui_density_items(_self=None, _context=None):
    return [
        ("COMPACT", _ui("Compact", "コンパクト"), _ui("Show only the main production controls and high-value actions.", "主要な制作項目と高価値アクションだけを表示します。"), "HIDE_OFF", 0),
        ("STUDIO", _ui("Studio", "スタジオ"), _ui("Balanced layout for daily production: core controls, quality tools, and current page details.", "日常制作向けに、基本項目、品質強化、現在ページ詳細をバランスよく表示します。"), "WORKSPACE", 1),
        ("FULL", _ui("Full", "全機能"), _ui("Expose every implemented section for deep setup and troubleshooting.", "詳細設定や検証のため、実装済み項目をすべて表示します。"), "PREFERENCES", 2),
    ]


def _quality_profile_items(_self=None, _context=None):
    return [
        ("BALANCED", _ui("Balanced", "バランス"), _ui("Safe lookdev defaults: reliable PBR routing, moderate cleanup, and readable node layout.", "安全なルックデブ標準です。PBR配線、適度な整理、読みやすいノード配置を行います。"), "SHADING_RENDERED", 0),
        ("REALTIME", _ui("Realtime", "リアルタイム"), _ui("Prefer Eevee/viewport responsiveness: reduce extreme bump, clamp roughness, and avoid heavy cleanup.", "Eevee/ビューポート応答性を優先します。過剰な凹凸を抑え、粗さを整え、重い整理を避けます。"), "RENDERLAYERS", 1),
        ("CINEMATIC", _ui("Cinematic", "シネマ品質"), _ui("Prioritize final-look quality: preserve texture detail, strengthen metadata, AOV readiness, and stable exchange output.", "最終ルック品質を優先します。テクスチャ詳細、メタデータ、AOV準備、安定した受け渡しを強化します。"), "RENDER_STILL", 2),
        ("SUPREME", _ui("Supreme production", "最高精度制作"), _ui("Use the most conservative texture routing, strongest metadata, strict audit, full node layout, fake-user protection, and exchange readiness for final production files.", "最終制作ファイル向けに、最も保守的なテクスチャ配線、強いメタデータ、厳密監査、完全ノード整列、フェイクユーザー保護、受け渡し準備を行います。"), "SOLO_ON", 3),
        ("ANIME_NPR", _ui("Anime/NPR", "アニメ/NPR"), _ui("Prioritize toon bands, line metadata, material IDs, stable alpha, and NPR handoff.", "トゥーン階調、線画メタデータ、マテリアルID、安定アルファ、NPRユーティリティ受け渡しを優先します。"), "GREASEPENCIL", 4),
    ]

def _anime_line_mode_items(_self=None, _context=None):
    return [
        ("BALANCED", _ui("Balanced", "標準精度"), _ui("Freestyle plus mesh-curve extraction for a balanced anime production setup.", "Freestyleと実体カーブ抽出を併用する標準的なアニメ制作向け設定です。"), "GREASEPENCIL", 0),
        ("PRODUCTION", _ui("Production", "制作精度"), _ui("Prefer conservative detection, render elements, material overrides, and stable handoff data.", "保守的な検出、レンダー要素、材質別上書き、安定した受け渡しデータを優先します。"), "RENDER_STILL", 1),
        ("SKETCH", _ui("Rough sketch", "ラフスケッチ"), _ui("Use jitter, width modulation, and offset curves for a rough hand-drawn look.", "ジッター、線幅揺らぎ、オフセットでラフな手描き線にします。"), "BRUSH_DATA", 2),
        ("CLEAN", _ui("Clean cel", "クリーンセル"), _ui("Use crisp material boundaries, normal-angle edges, and low jitter for clean anime line art.", "材質境界、法線角、低ジッターでクリーンなアニメ線にします。"), "MOD_SMOOTH", 3),
    ]

def _anime_target_scope_items(_self=None, _context=None):
    return [
        ("SELECTED", _ui("Selected objects", "選択オブジェクト"), _ui("Use selected mesh objects as line targets.", "選択中メッシュを線画対象にします。"), "RESTRICT_SELECT_OFF", 0),
        ("ACTIVE", _ui("Active object", "アクティブオブジェクト"), _ui("Use only the active mesh object as a line target.", "アクティブメッシュのみ線画対象にします。"), "OBJECT_DATA", 1),
        ("SCENE", _ui("Whole scene", "シーン全体"), _ui("Use all mesh objects in the scene as line targets.", "シーン内の全メッシュを線画対象にします。"), "SCENE_DATA", 2),
        ("MATERIAL", _ui("Active material users", "アクティブ材質使用物"), _ui("Use objects that reference the active material as line targets.", "アクティブ材質を参照するオブジェクトを線画対象にします。"), "MATERIAL", 3),
    ]

def _anime_output_mode_items(_self=None, _context=None):
    return [
        ("BOTH", _ui("Freestyle + curves", "Freestyle＋カーブ"), _ui("Configure Freestyle and generate editable curve strokes for supported edge classes.", "Freestyle設定と編集可能カーブ線の両方を生成します。"), "GREASEPENCIL", 0),
        ("FREESTYLE", _ui("Freestyle only", "Freestyleのみ"), _ui("Configure Blender Freestyle line sets without creating extra line geometry.", "追加ジオメトリを作らずBlender Freestyleラインセットのみ設定します。"), "RENDER_STILL", 1),
        ("CURVE", _ui("Editable curves only", "編集カーブのみ"), _ui("Generate editable 3D curve strokes for line handoff, layout, and vector export.", "受け渡し、レイアウト、ベクター出力向けの編集可能3Dカーブ線を生成します。"), "CURVE_DATA", 2),
    ]

class SSS_MaterialStudioSettings(PropertyGroup):
    active_page: EnumProperty(name=_ui("Page", "ページ"), description=_ui("Select which Smart Shader tool group is shown in the N-panel.", "Nパネルに表示するスマートシェーダーのツール群を選択します。"), items=_page_items, default=0, update=_save_update)
    ui_density: EnumProperty(name=_ui("UI density", "UI密度"), description=_ui("Controls how many Smart Shader controls are shown at once. Compact hides low-frequency controls; Studio is the recommended default; Full exposes every implemented section.", "一度に表示するスマートシェーダーの項目量です。コンパクトは低頻度項目を隠し、スタジオは推奨標準、全機能は実装済み項目をすべて表示します。"), items=_ui_density_items, default=1, update=_save_update)
    use_large_icon_deck: BoolProperty(name=_ui("Large icon deck", "大判アイコンデッキ"), description=_ui("Show large frame-free icon-only command buttons at the top of Shader Studio. Icons are custom generated with maximum figure coverage for readability.", "スマートシェーダー上部に、枠無しの大判アイコン専用コマンドボタンを表示します。アイコンは視認性のため図形を最大限大きく生成しています。"), default=True, update=_save_update)
    icon_button_scale: FloatProperty(name=_ui("Icon button scale", "アイコンボタン倍率"), description=_ui("Vertical scale of the large no-frame icon buttons. Increase this when the N-panel is wide enough and you want the icon figures as large as Blender UI allows.", "枠無し大判アイコンボタンの縦倍率です。Nパネル幅に余裕があり、Blender UI上で図形をさらに大きく見せたい場合に上げます。"), default=3.35, min=1.2, max=6.0, update=_save_update)
    show_visual_references: BoolProperty(name=_ui("Visual reference cards", "画像リファレンスカード"), description=_ui("Show compact abstract reference cards for PBR, NPR line, and asset pipeline flows. These are generated local images and do not use external assets.", "PBR、NPR線画、アセットパイプラインの抽象リファレンスカードを表示します。ローカル生成画像で、外部アセットは使用しません。"), default=False, update=_save_update)
    quality_profile: EnumProperty(name=_ui("Quality profile", "品質プロファイル"), description=_ui("Production tuning profile used by the scene quality upgrade, texture importer, and diagnostic report.", "シーン品質強化、テクスチャ取り込み、診断レポートで使う制作向け調整プロファイルです。"), items=_quality_profile_items, default=0, update=_save_update)
    auto_layout_nodes: BoolProperty(name=_ui("Auto layout nodes", "ノード自動整列"), description=_ui("Automatically place generated or upgraded material nodes into readable left-to-right columns after construction.", "生成または品質強化した材質ノードを、読みやすい左から右への列配置へ自動整列します。"), default=True, update=_save_update)
    auto_color_space_fix: BoolProperty(name=_ui("Fix data color space", "データ色空間を修正"), description=_ui("Set roughness, metallic, normal, height, alpha, AO, and packed data maps to Non-Color/Raw where Blender supports it.", "粗さ、メタリック、法線、高さ、アルファ、AO、パックマップを、対応環境では非カラー／Rawへ設定します。"), default=True, update=_save_update)
    strict_texture_detection: BoolProperty(name=_ui("Strict texture detection", "厳密テクスチャ検出"), description=_ui("Use token-aware scoring when identifying texture-set channels so files such as color IDs, masks, or previews are less likely to be misrouted.", "テクスチャセットのチャンネル判定でトークンベースのスコアを使い、カラーID、マスク、プレビュー画像の誤配線を抑えます。"), default=True, update=_save_update)
    generate_quality_report: BoolProperty(name=_ui("Quality report", "品質レポート"), description=_ui("Create a Text data-block report after quality upgrades, including missing maps, suspicious color spaces, unconnected outputs, and material health scores.", "品質強化後に、リンク切れ、疑わしい色空間、未接続出力、材質ヘルススコアを含むテキストレポートを生成します。"), default=True, update=_save_update)
    material_preset: EnumProperty(name=_ui("Material preset", "材質プリセット"), description=_ui("Base material family used by procedural and PBR builder commands.", "プロシージャル生成とPBR構築で使う基本材質ファミリーです。"), items=_material_items, default=0, update=_save_update)
    style_preset: EnumProperty(name=_ui("NPR style", "NPRスタイル"), description=_ui("Stylized shader family used by the NPR builder.", "NPR生成で使うスタイル種別です。"), items=_style_items, default=0, update=_save_update)
    atomic_preset: EnumProperty(name=_ui("Atomic pattern", "アトミックパターン"), description=_ui("Substance Designer-like atomic node pattern to build as a Blender material.", "Substance Designer風のアトミックノードパターンをBlender材質として生成します。"), items=_atomic_items, default=0, update=_save_update)
    assignment_scope: EnumProperty(name=_ui("Scope", "対象範囲"), description=_ui("Controls whether scene commands affect the active object, selected objects, or the full scene.", "シーン系コマンドがアクティブ、選択中、シーン全体のどれを対象にするかを指定します。"), items=_scope_items, default=0, update=_save_update)
    material_name: StringProperty(name=_ui("Material name", "材質名"), description=_ui("Name for generated, imported, saved, or restored materials.", "生成、取り込み、保存、復元する材質の名前です。"), default="Shader Studio Material", update=_save_update)
    texture_directory: StringProperty(name=_ui("Texture folder", "テクスチャフォルダ"), description=_ui("Manual folder used for PBR texture-set import. This user-selected path is respected and is not moved into Smart_Shader_Suite storage.", "PBRテクスチャセット取り込みに使う手動指定フォルダです。ユーザー指定のため Smart_Shader_Suite 保存フォルダへ移動しません。"), subtype="DIR_PATH", default="", update=_save_update)
    photo_source: StringProperty(name=_ui("Photo source", "写真ソース"), description=_ui("Manual image file used by the photo-to-PBR sampler approximation or HDRI world builder.", "写真からPBRを作るサンプラー近似またはHDRIワールド構築で使う手動指定画像です。"), subtype="FILE_PATH", default="", update=_save_update)
    relink_root: StringProperty(name=_ui("Relink root", "再リンク基点"), description=_ui("Manual root folder searched recursively when repairing missing texture and HDRI paths.", "リンク切れテクスチャやHDRIを修復するときに再帰検索する手動指定フォルダです。"), subtype="DIR_PATH", default="", update=_save_update)
    library_root: StringProperty(name=_ui("Library root", "ライブラリ基点"), description=_ui("Optional manual folder for material capsules. Empty uses Smart_Shader_Suite storage.", "マテリアルカプセル用の任意手動フォルダです。空なら Smart_Shader_Suite 保存フォルダを使います。"), subtype="DIR_PATH", default="", update=_save_update)
    export_directory: StringProperty(name=_ui("Export folder", "書き出しフォルダ"), description=_ui("Optional manual export folder for MaterialX, USD, and reports. Empty uses Smart_Shader_Suite storage.", "MaterialX、USD、レポート用の任意手動書き出し先です。空なら Smart_Shader_Suite 保存フォルダを使います。"), subtype="DIR_PATH", default="", update=_save_update)
    search_query: StringProperty(name=_ui("Search", "検索"), description=_ui("Keyword used by the local asset browser, material browser, and command search approximation.", "ローカルアセットブラウザ、材質ブラウザ、コマンド検索近似で使うキーワードです。"), default="", update=_save_update)
    rule_expression: StringProperty(name=_ui("Rule", "ルール"), description=_ui("Object name pattern or regular expression used by rule-based material assignment.", "ルールベース材質割り当てで使うオブジェクト名パターンまたは正規表現です。"), default="", update=_save_update)
    variant_name: StringProperty(name=_ui("Variant name", "バリアント名"), description=_ui("Name used when saving or restoring material state sets.", "材質ステートセットの保存・復元で使う名前です。"), default="Default Look", update=_save_update)
    use_regex_rules: BoolProperty(name=_ui("Regex rules", "正規表現ルール"), description=_ui("Interpret the rule field as a Python regular expression. Off uses plain case-insensitive contains matching.", "ルール欄をPython正規表現として解釈します。オフでは大文字小文字を無視した部分一致です。"), default=False, update=_save_update)
    assign_to_selected: BoolProperty(name=_ui("Assign to selected", "選択へ割り当て"), description=_ui("Assign newly generated or imported materials to selected mesh objects immediately.", "生成または取り込みした材質を選択中メッシュへ即時割り当てます。"), default=True, update=_save_update)
    mark_asset: BoolProperty(name=_ui("Mark as asset", "アセット化"), description=_ui("Mark generated materials as Blender assets when the running Blender build supports asset metadata.", "実行中のBlenderがアセットメタデータに対応している場合、生成材質をBlenderアセットとしてマークします。"), default=False, update=_save_update)
    use_fake_user: BoolProperty(name=_ui("Fake user", "フェイクユーザー"), description=_ui("Keep generated materials in the file even if they are not assigned to an object.", "オブジェクトへ割り当てられていない生成材質もファイル内に保持します。"), default=True, update=_save_update)
    cleanup_images: BoolProperty(name=_ui("Cleanup images", "画像も整理"), description=_ui("Allow cleanup commands to remove unused images in addition to materials and slots.", "クリーンアップ時に材質やスロットだけでなく未使用画像も削除対象にします。"), default=False, update=_save_update)
    cleanup_slots: BoolProperty(name=_ui("Cleanup slots", "スロット整理"), description=_ui("Remove material slots that are not used by any polygon on mesh objects.", "メッシュ面で使われていない材質スロットを削除します。"), default=True, update=_save_update)
    cleanup_duplicates: BoolProperty(name=_ui("Merge .001 duplicates", ".001重複統合"), description=_ui("Replace material duplicates such as Name.001 with the original material when a matching base material exists.", "Name.001のような重複材質を、対応する元材質がある場合に置換します。"), default=False, update=_save_update)
    recursive_scan: BoolProperty(name=_ui("Recursive scan", "再帰検索"), description=_ui("Search subfolders when importing texture sets, relinking assets, and scanning libraries.", "テクスチャセット取り込み、再リンク、ライブラリ走査でサブフォルダも検索します。"), default=True, update=_save_update)
    force_texture_rewire: BoolProperty(name=_ui("Force rewire", "強制再配線"), description=_ui("When importing a PBR texture set, rebuild the material node graph even if existing nodes are present.", "PBRテクスチャセット取り込み時、既存ノードがあっても材質ノードを再構築します。"), default=True, update=_save_update)
    create_outline_shell: BoolProperty(name=_ui("Outline shell", "輪郭シェル"), description=_ui("Create a non-destructive inverted-hull style outline object for selected meshes.", "選択メッシュに非破壊の反転ハル風輪郭オブジェクトを作成します。"), default=True, update=_save_update)
    texture_scale: FloatProperty(name=_ui("Texture scale", "テクスチャスケール"), description=_ui("Global mapping scale used by procedural and imported texture materials.", "プロシージャル材質と取り込みテクスチャ材質で使う全体マッピングスケールです。"), default=1.0, min=0.001, max=1000.0, update=_save_update)
    roughness: FloatProperty(name=_ui("Roughness", "粗さ"), description=_ui("Default roughness for generated materials and PBR fallback values.", "生成材質とPBRフォールバック値で使う粗さです。"), default=0.55, min=0.0, max=1.0, update=_save_update)
    metallic: FloatProperty(name=_ui("Metallic", "金属度"), description=_ui("Default metallic value for generated materials.", "生成材質で使う金属度です。"), default=0.0, min=0.0, max=1.0, update=_save_update)
    normal_strength: FloatProperty(name=_ui("Normal strength", "法線強度"), description=_ui("Strength of generated normal, bump, and sampler detail maps.", "生成法線、バンプ、サンプラー風ディテールの強度です。"), default=0.18, min=0.0, max=10.0, update=_save_update)
    height_strength: FloatProperty(name=_ui("Height strength", "高さ強度"), description=_ui("Displacement or bump height strength used by procedural materials.", "プロシージャル材質で使うディスプレイスメントまたはバンプ高さ強度です。"), default=0.05, min=0.0, max=10.0, update=_save_update)
    weathering_amount: FloatProperty(name=_ui("Weathering", "経年変化"), description=_ui("Overall strength for smart weathering masks.", "スマートウェザリングマスク全体の強度です。"), default=0.45, min=0.0, max=1.0, update=_save_update)
    edge_wear_amount: FloatProperty(name=_ui("Edge wear", "エッジ摩耗"), description=_ui("Approximate exposed-edge wear strength used by smart masks.", "スマートマスクで使う露出エッジ摩耗の近似強度です。"), default=0.35, min=0.0, max=1.0, update=_save_update)
    dirt_amount: FloatProperty(name=_ui("Dirt", "汚れ"), description=_ui("Amount of dirt and cavity-darkening added to the active material.", "アクティブ材質へ追加する汚れ・溝暗化の量です。"), default=0.35, min=0.0, max=1.0, update=_save_update)
    wetness_amount: FloatProperty(name=_ui("Wetness", "濡れ"), description=_ui("Wetness effect amount; lowers roughness and darkens base color in the smart material layer.", "濡れ効果の量です。粗さを下げ、スマート材質レイヤーでベース色を暗くします。"), default=0.25, min=0.0, max=1.0, update=_save_update)
    toon_steps: IntProperty(name=_ui("Toon steps", "トゥーン階調"), description=_ui("Number of main tonal zones used by the NPR shader approximation.", "NPRシェーダー近似で使う主階調数です。"), default=3, min=2, max=8, update=_save_update)
    toon_threshold: FloatProperty(name=_ui("Toon threshold", "トゥーン境界"), description=_ui("Threshold used by toon and halftone ramp generation.", "トゥーンとハーフトーンのランプ生成で使う境界値です。"), default=0.55, min=0.0, max=1.0, update=_save_update)
    line_width: FloatProperty(name=_ui("Line width", "線幅"), description=_ui("Line width for Freestyle and outline-shell approximations.", "Freestyleと輪郭シェル近似で使う線幅です。"), default=0.02, min=0.0001, max=1.0, update=_save_update)
    anime_line_mode: EnumProperty(name=_ui("Line quality mode", "線画品質モード"), description=_ui("Preset strategy for anime line generation: balanced, production, rough sketch, or clean cel.", "アニメ線画生成の戦略です。標準精度、制作精度、ラフスケッチ、クリーンセルから選びます。"), items=_anime_line_mode_items, default=0, update=_save_update)
    anime_target_scope: EnumProperty(name=_ui("Line targets", "線画対象"), description=_ui("Controls which objects are used by NPR line setup and curve extraction.", "NPRユーティリティライン設定とカーブ抽出で使う対象オブジェクトを指定します。"), items=_anime_target_scope_items, default=0, update=_save_update)
    anime_line_output_mode: EnumProperty(name=_ui("Line output", "線画出力"), description=_ui("Choose Freestyle, editable curve strokes, or both. Curves are useful for handoff and vector export; Freestyle handles view-dependent outlines and hidden lines.", "Freestyle、編集可能カーブ線、または両方を選びます。カーブは受け渡しやベクター出力に、Freestyleは視点依存アウトラインや陰線に向きます。"), items=_anime_output_mode_items, default=0, update=_save_update)
    anime_line_set_name: StringProperty(name=_ui("Line set name", "ラインセット名"), description=_ui("Name for the managed line set, generated curve collection, render-element files, and preset data.", "管理ラインセット、生成カーブコレクション、レンダー要素ファイル、プリセットデータに使う名前です。"), default="Smart Anime Line Set", update=_save_update)
    anime_brush_instance_name: StringProperty(name=_ui("Brush instance", "ブラシインスタンス"), description=_ui("Reusable brush-setting instance name. Multiple line sets can share this name to keep color, opacity, width, jitter, taper, dash, and variation logically synchronized.", "再利用するブラシ設定インスタンス名です。複数ラインセットで同じ名前を使うと、色、不透明度、幅、ジッター、入り抜き、破線、揺らぎを論理的に共有できます。"), default="Main Brush", update=_save_update)
    anime_reduction_instance_name: StringProperty(name=_ui("Reduction instance", "リダクションインスタンス"), description=_ui("Reusable size/alpha reduction instance name for distance-based line control.", "距離による線幅・アルファ制御で使う再利用可能なリダクション設定名です。"), default="Camera Distance", update=_save_update)
    anime_line_size_map: StringProperty(name=_ui("Line size map", "線幅マップ"), description=_ui("Optional manual image file used as line-size-map metadata for pipeline handoff. The user-selected file path is preserved and is not moved into Smart_Shader_Suite storage.", "パイプライン受け渡し用の任意手動指定線幅マップ画像です。ユーザー指定ファイルのため Smart_Shader_Suite 保存フォルダへ移動しません。"), subtype="FILE_PATH", default="", update=_save_update)
    anime_line_set_id: IntProperty(name=_ui("Line set ID", "ラインセットID"), description=_ui("ID from 1 to 8 used for render-element separation and line-set grouping.", "レンダー要素分離とラインセット分類に使う1〜8のIDです。"), default=1, min=1, max=8, update=_save_update)
    anime_line_render_priority: IntProperty(name=_ui("Render priority", "描画優先度"), description=_ui("Drawing priority for this line set. Higher priority is drawn later when the renderer supports ordering.", "このラインセットの描画優先度です。対応レンダラーでは値が大きいほど後から描画します。"), default=0, min=-1000, max=1000, update=_save_update)
    anime_visible_lines: BoolProperty(name=_ui("Visible lines", "可視線"), description=_ui("Generate and configure visible lines.", "可視線を生成・設定します。"), default=True, update=_save_update)
    anime_hidden_lines: BoolProperty(name=_ui("Hidden lines", "陰線"), description=_ui("Configure hidden-line output. Freestyle is used for depth-aware hidden lines; generated curves store hidden-line styling metadata.", "陰線出力を設定します。奥行き判定つき陰線はFreestyleを使い、生成カーブには陰線スタイル情報を記録します。"), default=False, update=_save_update)
    anime_merge_groups: BoolProperty(name=_ui("Merge groups", "マージグループ"), description=_ui("Keep generated line curves grouped by edge category and line-set ID, approximating line-merge helper workflows for clean compositing and handoff.", "生成ラインカーブをエッジ種別とラインセットIDごとにグループ化し、コンポジットと受け渡し向けのラインマージ補助を近似します。"), default=True, update=_save_update)
    anime_self_intersection: BoolProperty(name=_ui("Self-intersection", "自己交差線"), description=_ui("Enable self-intersection intent in Freestyle metadata and exported presets. Geometry-level self-intersection extraction is limited to edges detectable from mesh topology.", "Freestyleメタデータと書き出しプリセットで自己交差線意図を有効にします。ジオメトリ実体抽出はメッシュトポロジーから検出可能な範囲に限られます。"), default=True, update=_save_update)
    anime_viewport_preview: BoolProperty(name=_ui("Viewport preview", "ビューポート確認"), description=_ui("Enable viewport-oriented settings such as outline shells, curve strokes, show-in-front hidden-line guides, and OpenGL preview rendering.", "輪郭シェル、カーブ線、前面表示の陰線ガイド、OpenGLプレビュー出力などビューポート確認向け設定を有効にします。"), default=True, update=_save_update)
    anime_attribute_override_enabled: BoolProperty(name=_ui("Attribute override", "属性オーバーライド"), description=_ui("Store the current line settings on the scene and active view layer as animatable custom-property metadata for shot-level overrides.", "現在のライン設定をシーンとアクティブビューレイヤーにカスタムプロパティメタデータとして保存し、ショット単位の上書きに使います。"), default=True, update=_save_update)
    anime_edge_outline: BoolProperty(name=_ui("Outline", "アウトライン"), description=_ui("Detect view-dependent silhouettes through Freestyle and optional outline-shell support.", "Freestyleと任意の輪郭シェルで視点依存シルエットを扱います。"), default=True, update=_save_update)
    anime_edge_open: BoolProperty(name=_ui("Open edge", "開放エッジ"), description=_ui("Generate lines on boundary edges used by only one polygon.", "1面だけが使う境界エッジに線を生成します。"), default=True, update=_save_update)
    anime_edge_object: BoolProperty(name=_ui("Object", "オブジェクト境界"), description=_ui("Configure object-boundary line detection. In curve mode this is approximated by open, sharp, and normal-angle edges.", "オブジェクト境界線を設定します。カーブモードでは開放、シャープ、法線角エッジで近似します。"), default=True, update=_save_update)
    anime_edge_intersection: BoolProperty(name=_ui("Intersection", "交差線"), description=_ui("Enable object-intersection line detection where Freestyle supports it and record intersection intent in exported presets.", "Freestyleが対応する場合にオブジェクト交差線を有効化し、書き出しプリセットへ交差線意図を記録します。"), default=True, update=_save_update)
    anime_edge_smoothing_boundary: BoolProperty(name=_ui("Smoothing boundary", "スムージング境界"), description=_ui("Detect edges where face smoothing differs or the edge is marked sharp.", "面のスムージング差またはシャープ指定があるエッジを検出します。"), default=True, update=_save_update)
    anime_edge_material_boundary: BoolProperty(name=_ui("Material boundary", "材質境界"), description=_ui("Detect edges where adjacent polygons use different material slots.", "隣接面の材質スロットが異なるエッジを検出します。"), default=True, update=_save_update)
    anime_edge_selected: BoolProperty(name=_ui("Selected edge", "選択エッジ"), description=_ui("Detect mesh edges that are explicitly selected or marked for manual line control.", "明示的に選択されたメッシュエッジを検出します。手動ライン制御に使います。"), default=False, update=_save_update)
    anime_edge_normal_angle: BoolProperty(name=_ui("Normal angle", "法線角"), description=_ui("Detect creases where adjacent face normals exceed the threshold.", "隣接面の法線角がしきい値を超える折れ目を検出します。"), default=True, update=_save_update)
    anime_edge_wireframe: BoolProperty(name=_ui("Wireframe", "ワイヤーフレーム"), description=_ui("Generate lines for all mesh edges. Use carefully on dense meshes.", "すべてのメッシュエッジに線を生成します。高密度メッシュでは注意してください。"), default=False, update=_save_update)
    anime_brush_width: FloatProperty(name=_ui("Visible width px", "可視線幅px"), description=_ui("Visible line width in pixels for Freestyle and as a scaled bevel depth for generated curves.", "Freestyle用の可視線幅pxです。生成カーブではスケール変換したベベル深度として使います。"), default=6.0, min=0.01, max=200.0, update=_save_update)
    anime_hidden_width: FloatProperty(name=_ui("Hidden width px", "陰線幅px"), description=_ui("Hidden line width in pixels.", "陰線の線幅pxです。"), default=3.0, min=0.01, max=200.0, update=_save_update)
    anime_brush_color: FloatVectorProperty(name=_ui("Visible color", "可視線色"), description=_ui("Visible line color used by Freestyle, curve materials, and exported line manifests.", "Freestyle、カーブ材質、線画マニフェストで使う可視線色です。"), subtype="COLOR", size=4, default=(0.0, 0.0, 0.0, 1.0), min=0.0, max=1.0, update=_save_update)
    anime_hidden_color: FloatVectorProperty(name=_ui("Hidden color", "陰線色"), description=_ui("Hidden line color used by Freestyle and exported hidden-line elements.", "Freestyleと陰線要素出力で使う陰線色です。"), subtype="COLOR", size=4, default=(0.0, 0.0, 0.0, 0.35), min=0.0, max=1.0, update=_save_update)
    anime_brush_opacity: FloatProperty(name=_ui("Visible opacity", "可視線不透明度"), description=_ui("Opacity for visible line materials and Freestyle alpha.", "可視線材質とFreestyleアルファの不透明度です。"), default=1.0, min=0.0, max=1.0, update=_save_update)
    anime_hidden_opacity: FloatProperty(name=_ui("Hidden opacity", "陰線不透明度"), description=_ui("Opacity for hidden lines.", "陰線の不透明度です。"), default=0.35, min=0.0, max=1.0, update=_save_update)
    anime_brush_angle: FloatProperty(name=_ui("Brush angle", "ブラシ角度"), description=_ui("Brush angle metadata used for exported stroke data and Freestyle texture-angle approximation when available.", "書き出しストロークデータと、利用可能な場合のFreestyleテクスチャ角度近似で使うブラシ角度です。"), default=0.0, min=-180.0, max=180.0, update=_save_update)
    anime_brush_jitter: FloatProperty(name=_ui("Jitter", "ジッター"), description=_ui("Random positional jitter for generated curves. Keep low for production clean lines.", "生成カーブのランダム位置揺らぎです。制作向けクリーン線では低めにします。"), default=0.0, min=0.0, max=1.0, update=_save_update)
    anime_brush_taper: FloatProperty(name=_ui("Taper", "入り抜き"), description=_ui("Taper amount metadata for strokes. Freestyle thickness modifiers are configured when available.", "ストロークの入り抜き量です。利用可能な場合はFreestyle線幅モディファイアにも反映します。"), default=0.25, min=0.0, max=1.0, update=_save_update)
    anime_brush_random_width: FloatProperty(name=_ui("Width variation", "線幅揺らぎ"), description=_ui("Random width modulation for generated edge curves and Freestyle settings when available.", "生成カーブと、利用可能な場合のFreestyle設定に使う線幅ランダム変化です。"), default=0.15, min=0.0, max=1.0, update=_save_update)
    anime_brush_dash_enabled: BoolProperty(name=_ui("Dashed hidden lines", "陰線破線"), description=_ui("Use dashed styling for hidden lines and exported SVG/manifest data.", "陰線とSVG/マニフェスト出力に破線スタイルを使います。"), default=True, update=_save_update)
    anime_brush_dash_length: FloatProperty(name=_ui("Dash length", "破線長"), description=_ui("Dash length for hidden-line styling.", "陰線破線の線分長です。"), default=14.0, min=0.1, max=500.0, update=_save_update)
    anime_brush_gap_length: FloatProperty(name=_ui("Gap length", "隙間長"), description=_ui("Gap length for dashed hidden-line styling.", "陰線破線の隙間長です。"), default=8.0, min=0.1, max=500.0, update=_save_update)
    anime_normal_angle_threshold: FloatProperty(name=_ui("Normal angle threshold", "法線角しきい値"), description=_ui("Angle in degrees above which adjacent faces are treated as a normal-angle line.", "隣接面を法線角ラインとして扱う角度しきい値です。"), default=35.0, min=0.0, max=180.0, update=_save_update)
    anime_curve_bevel_scale: FloatProperty(name=_ui("Curve scale", "カーブ線幅倍率"), description=_ui("Conversion scale from pixel width to generated 3D curve bevel depth.", "ピクセル線幅から生成3Dカーブのベベル深度へ変換する倍率です。"), default=0.0008, min=0.000001, max=1.0, update=_save_update)
    anime_depth_offset: FloatProperty(name=_ui("Depth offset", "奥行きオフセット"), description=_ui("Small normal offset for generated curves to reduce z-fighting on the mesh surface.", "生成カーブをメッシュ表面から少し浮かせ、Zファイトを抑えるための法線方向オフセットです。"), default=0.001, min=-1.0, max=1.0, update=_save_update)
    anime_reduction_enabled: BoolProperty(name=_ui("Distance reduction", "距離リダクション"), description=_ui("Reduce line width and alpha by camera distance using generated curve bevels and exported reduction metadata.", "カメラ距離で線幅とアルファを減衰します。生成カーブのベベルと書き出しメタデータに反映します。"), default=True, update=_save_update)
    anime_reduction_start: FloatProperty(name=_ui("Reduction start", "減衰開始"), description=_ui("Camera distance where size/alpha reduction starts.", "線幅・アルファ減衰を開始するカメラ距離です。"), default=5.0, min=0.0, max=100000.0, update=_save_update)
    anime_reduction_end: FloatProperty(name=_ui("Reduction end", "減衰終了"), description=_ui("Camera distance where size/alpha reaches the minimum values.", "線幅・アルファが最小値に達するカメラ距離です。"), default=50.0, min=0.0, max=100000.0, update=_save_update)
    anime_reduction_min_width: FloatProperty(name=_ui("Minimum width", "最小線幅"), description=_ui("Minimum line width factor after distance reduction.", "距離減衰後の最小線幅倍率です。"), default=0.35, min=0.0, max=1.0, update=_save_update)
    anime_reduction_min_alpha: FloatProperty(name=_ui("Minimum alpha", "最小アルファ"), description=_ui("Minimum line alpha factor after distance reduction.", "距離減衰後の最小アルファ倍率です。"), default=0.45, min=0.0, max=1.0, update=_save_update)
    anime_material_override_enabled: BoolProperty(name=_ui("Material line functions", "材質別ライン機能"), description=_ui("Enable material-level line override data similar to NPR line functions.", "NPRユーティリティライン機能に近い材質別ライン上書きデータを有効にします。"), default=True, update=_save_update)
    anime_material_replace_color: BoolProperty(name=_ui("Replace material line color", "材質線色を置換"), description=_ui("Store active-material line color replacement metadata and apply generated curve material colors.", "アクティブ材質に線色置換メタデータを保存し、生成カーブ材質色にも反映します。"), default=False, update=_save_update)
    anime_material_disable_intersection: BoolProperty(name=_ui("Disable material intersection", "材質交差線を無効"), description=_ui("Mark the active material to suppress intersection lines where the line builder can honor it.", "線生成側が対応できる範囲で、アクティブ材質の交差線を抑制する印を付けます。"), default=False, update=_save_update)
    anime_material_hidden_as_visible: BoolProperty(name=_ui("Hidden as visible", "陰線を可視線化"), description=_ui("Mark the active material so hidden lines behind it should be treated as visible by compatible line workflows.", "互換ライン処理で、この材質の背後の陰線を可視線として扱う印を付けます。"), default=False, update=_save_update)
    anime_material_mask_hidden_targets: BoolProperty(name=_ui("Mask hidden targets", "陰線対象をマスク"), description=_ui("Mark the active material to mask hidden target lines in exported settings and compatible workflows.", "書き出し設定と互換処理で、アクティブ材質が陰線対象をマスクする印を付けます。"), default=False, update=_save_update)
    anime_render_visible_element: BoolProperty(name=_ui("Visible element", "可視線要素"), description=_ui("Export visible-line element metadata and generated visible curve data.", "可視線レンダー要素メタデータと生成可視線カーブ情報を書き出します。"), default=True, update=_save_update)
    anime_render_hidden_element: BoolProperty(name=_ui("Hidden element", "陰線要素"), description=_ui("Export hidden-line element metadata.", "陰線レンダー要素メタデータを書き出します。"), default=True, update=_save_update)
    anime_render_edge_elements: BoolProperty(name=_ui("Edge elements", "エッジ別要素"), description=_ui("Export edge-type separation metadata for outline, open, object, intersection, smoothing, material, selected, normal-angle, and wireframe lines.", "アウトライン、開放、オブジェクト、交差、スムージング、材質、選択、法線角、ワイヤーフレームのエッジ種別分離メタデータを書き出します。"), default=True, update=_save_update)
    anime_render_background_enabled: BoolProperty(name=_ui("Background color", "背景色"), description=_ui("Store a background color for line-only render element inspection.", "線画のみのレンダー要素確認用背景色を保存します。"), default=False, update=_save_update)
    anime_render_background_color: FloatVectorProperty(name=_ui("Background", "背景"), description=_ui("Background color for line render-element previews and exported SVG.", "線画レンダー要素プレビューとSVG出力で使う背景色です。"), subtype="COLOR", size=4, default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0, update=_save_update)
    anime_shader_base_color: FloatVectorProperty(name=_ui("Anime base", "アニメ基本色"), description=_ui("Base zone color for the advanced anime cel shader.", "高精度アニメセルシェーダーの基本階調色です。"), subtype="COLOR", size=4, default=(0.82, 0.58, 0.42, 1.0), min=0.0, max=1.0, update=_save_update)
    anime_shader_shadow_color: FloatVectorProperty(name=_ui("Anime shadow", "アニメ影色"), description=_ui("Shadow zone color for the advanced anime cel shader.", "高精度アニメセルシェーダーの影階調色です。"), subtype="COLOR", size=4, default=(0.32, 0.22, 0.20, 1.0), min=0.0, max=1.0, update=_save_update)
    anime_shader_highlight_color: FloatVectorProperty(name=_ui("Anime highlight", "アニメハイライト"), description=_ui("Highlight color for hand-drawn style highlights.", "手描き風ハイライトの色です。"), subtype="COLOR", size=4, default=(1.0, 0.9, 0.72, 1.0), min=0.0, max=1.0, update=_save_update)
    anime_shader_rim_color: FloatVectorProperty(name=_ui("Anime rim", "アニメリム"), description=_ui("Rim-light color for silhouette emphasis.", "シルエット強調用リムライト色です。"), subtype="COLOR", size=4, default=(0.1, 0.16, 0.28, 1.0), min=0.0, max=1.0, update=_save_update)
    anime_shader_zone1: FloatProperty(name=_ui("Shadow boundary", "影境界"), description=_ui("Lower boundary of cel shading color zones.", "セル階調の低側境界です。"), default=0.38, min=0.0, max=1.0, update=_save_update)
    anime_shader_zone2: FloatProperty(name=_ui("Mid boundary", "中間境界"), description=_ui("Middle boundary of cel shading color zones.", "セル階調の中間境界です。"), default=0.62, min=0.0, max=1.0, update=_save_update)
    anime_shader_zone3: FloatProperty(name=_ui("Highlight boundary", "ハイライト境界"), description=_ui("Upper boundary where highlight influence begins.", "ハイライト影響が始まる上側境界です。"), default=0.84, min=0.0, max=1.0, update=_save_update)
    anime_shader_highlight_strength: FloatProperty(name=_ui("Highlight strength", "ハイライト強度"), description=_ui("Strength of stylized hand-drawn highlights.", "手描き風ハイライトの強度です。"), default=0.45, min=0.0, max=5.0, update=_save_update)
    anime_shader_rim_strength: FloatProperty(name=_ui("Rim strength", "リム強度"), description=_ui("Strength of rim/silhouette color contribution.", "リム・シルエット色の寄与強度です。"), default=0.35, min=0.0, max=5.0, update=_save_update)
    anime_shader_hatching_strength: FloatProperty(name=_ui("Hatching", "ハッチング"), description=_ui("Procedural hatch/screen-tone contribution for manga-style shading.", "漫画風シェーディング用のプロシージャルハッチ・スクリーントーン寄与です。"), default=0.20, min=0.0, max=1.0, update=_save_update)
    hdri_strength: FloatProperty(name=_ui("HDRI strength", "HDRI強度"), description=_ui("Background strength used when building a lookdev HDRI world.", "ルックデブHDRIワールド構築時の背景強度です。"), default=1.0, min=0.0, max=100.0, update=_save_update)
    hdri_rotation: FloatProperty(name=_ui("HDRI rotation", "HDRI回転"), description=_ui("Z-axis rotation in degrees used by the HDRI world mapping node.", "HDRIワールドのマッピングノードで使うZ軸回転角度です。"), default=0.0, min=-360.0, max=360.0, update=_save_update)
    decal_size: FloatProperty(name=_ui("Decal size", "デカールサイズ"), description=_ui("Size of created decal planes.", "作成するデカール平面のサイズです。"), default=1.0, min=0.001, max=1000.0, update=_save_update)
    id_slot_count: IntProperty(name=_ui("ID slots", "IDスロット数"), description=_ui("Number of material-ID palette slots generated for selected mesh objects.", "選択メッシュに生成するマテリアルIDパレットのスロット数です。"), default=8, min=1, max=64, update=_save_update)
    batch_limit: IntProperty(name=_ui("Batch limit", "一括処理上限"), description=_ui("Maximum number of files or materials processed by one batch command. Zero means unlimited.", "1回の一括処理で扱うファイルまたは材質の上限です。0なら無制限です。"), default=200, min=0, max=100000, update=_save_update)
    random_seed: IntProperty(name=_ui("Random seed", "ランダムシード"), description=_ui("Seed used by random color and variation commands.", "ランダムカラーやバリエーション系コマンドで使うシードです。"), default=1234, min=0, max=2147483647, update=_save_update)
    last_report: StringProperty(name=_ui("Report", "レポート"), description=_ui("Last Smart Shader operation report.", "スマートシェーダーの直近操作レポートです。"), default="", update=_save_update)


_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".exr", ".hdr", ".bmp", ".tga", ".webp"}
_DATA_COLORSPACE_NAMES = {"Non-Color", "Non Color", "Linear", "Raw"}
_CHANNEL_KEYWORDS = {
    "base_color": ("basecolor", "base_color", "albedo", "diffuse", "color", "col", "bc"),
    "roughness": ("roughness", "rough", "rgh", "gloss", "glossiness", "orm", "arm", "rma", "occlusionroughnessmetallic"),
    "metallic": ("metallic", "metalness", "metal", "mtl", "orm", "arm", "rma", "occlusionroughnessmetallic"),
    "normal": ("normal", "nrm", "norm", "normalgl", "normaldx"),
    "height": ("height", "displacement", "disp", "bump", "depth"),
    "ao": ("ambientocclusion", "ambient_occlusion", "occlusion", "ao", "orm", "arm", "rma", "occlusionroughnessmetallic"),
    "alpha": ("opacity", "alpha", "transparent", "transparency"),
    "emission": ("emission", "emissive", "emit"),
}

def _clean_name(value: str, fallback: str = "Shader Studio Material") -> str:
    text = str(value or "").strip() or fallback
    text = re.sub(r"[\\/:*?\"<>|]+", "_", text).strip(" ._")
    return text or fallback


def _manual_or_storage_dir(value: str, dirname: str, *, create: bool = True) -> Path:
    text = str(value or "").strip()
    if text:
        path = Path(bpy.path.abspath(text)).expanduser()
        if create:
            try:
                path.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass
        return path
    return _storage_dir_with_legacy(storage.data_dir, dirname, create=create)


def _storage_dir_with_legacy(base, dirname: str, *, create: bool = True) -> Path:
    """Use the pre-rename folder while the new one does not exist yet."""
    legacy = LEGACY_DIRNAMES.get(dirname)
    if legacy:
        try:
            base(create=create)  # prepare the parent first (this also runs the extension data migration)
            new_path = base(dirname, create=False)
            old_path = base(legacy, create=False)
            if not new_path.exists() and old_path.is_dir():
                return old_path
        except Exception:
            pass
    return base(dirname, create=create)


def _iter_files(root, recursive: bool = True, extensions=None):
    try:
        path = Path(bpy.path.abspath(str(root))).expanduser()
    except Exception:
        path = Path(str(root or "")).expanduser()
    if not path.exists():
        return []
    result = []
    iterator = path.rglob("*") if recursive else path.glob("*")
    for item in iterator:
        try:
            if item.is_file() and (not extensions or item.suffix.lower() in extensions):
                result.append(item)
        except Exception:
            pass
    return result


def _find_by_basename(root: Path, filename: str, recursive: bool = True):
    target = str(filename or "").lower()
    if not target:
        return None
    for path in _iter_files(root, recursive=recursive):
        try:
            if path.name.lower() == target:
                return path
        except Exception:
            pass
    return None


def _open_image(path: Path):
    try:
        return bpy.data.images.load(str(path), check_existing=True)
    except TypeError:
        try:
            return bpy.data.images.load(str(path))
        except Exception:
            return None
    except Exception:
        return None


def _set_image_data_colorspace(image) -> None:
    if image is None:
        return
    try:
        settings = getattr(image, "colorspace_settings", None)
        if settings is not None:
            for name in _DATA_COLORSPACE_NAMES:
                try:
                    settings.name = name
                    return
                except Exception:
                    continue
    except Exception:
        pass


def _is_missing_path(path_text: str) -> bool:
    text = str(path_text or "").strip()
    if not text:
        return False
    try:
        return not Path(bpy.path.abspath(text)).exists()
    except Exception:
        return False


def _tokenize_texture_name(path: Path) -> list[str]:
    stem = str(getattr(path, "stem", path) or "").lower()
    stem = stem.replace("basecolour", "basecolor").replace("colour", "color")
    return [token for token in re.split(r"[^a-z0-9]+", stem) if token]


def _texture_channel_score(path: Path, channel: str, *, strict: bool = True) -> int:
    tokens = _tokenize_texture_name(path)
    compact = "".join(tokens)
    token_set = set(tokens)
    channel = str(channel or "").lower()
    score = 0
    strong = {
        "base_color": {"basecolor": 120, "albedo": 115, "diffuse": 100, "base": 52, "color": 35, "col": 24, "bc": 34},
        "roughness": {"roughness": 120, "rough": 112, "rgh": 105, "glossiness": 82, "gloss": 62, "orm": 70, "arm": 70, "rma": 52, "occlusionroughnessmetallic": 95},
        "metallic": {"metallic": 120, "metalness": 118, "metal": 106, "mtl": 86, "orm": 70, "arm": 70, "rma": 52, "occlusionroughnessmetallic": 95},
        "normal": {"normal": 125, "normalgl": 124, "normaldx": 124, "nrm": 116, "norm": 105, "bentnormal": 80},
        "height": {"height": 120, "displacement": 118, "disp": 112, "bump": 96, "depth": 80},
        "ao": {"ambientocclusion": 122, "occlusion": 112, "ao": 118, "orm": 70, "arm": 70, "rma": 52, "occlusionroughnessmetallic": 95},
        "alpha": {"opacity": 120, "alpha": 118, "transparent": 84, "transparency": 84, "mask": 42},
        "emission": {"emission": 120, "emissive": 120, "emit": 100, "glow": 72},
    }
    for key, weight in strong.get(channel, {}).items():
        if key in token_set:
            score = max(score, weight)
        elif key in compact and len(key) >= 4:
            score = max(score, weight - 12)
    if strict:
        false_tokens = {
            "base_color": {"normal", "roughness", "rough", "metallic", "metal", "height", "displacement", "ao", "opacity", "alpha", "mask", "id", "preview"},
            "roughness": {"basecolor", "albedo", "diffuse", "normal", "height", "opacity", "emissive", "preview", "id"},
            "metallic": {"basecolor", "albedo", "diffuse", "normal", "height", "opacity", "emissive", "preview", "id"},
            "normal": {"basecolor", "albedo", "diffuse", "roughness", "metallic", "height", "opacity", "preview", "id"},
            "height": {"basecolor", "albedo", "diffuse", "roughness", "metallic", "normal", "opacity", "preview", "id"},
            "ao": {"basecolor", "albedo", "diffuse", "normal", "height", "opacity", "emissive", "preview", "id"},
            "alpha": {"basecolor", "albedo", "diffuse", "normal", "height", "roughness", "metallic", "preview", "id"},
            "emission": {"basecolor", "albedo", "diffuse", "normal", "height", "roughness", "metallic", "preview", "id"},
        }
        score -= 55 * len(token_set.intersection(false_tokens.get(channel, set())))
    return score


def _scan_texture_set(folder: Path, recursive: bool = True, limit: int = 0, *, strict: bool = True) -> dict:
    files = _iter_files(folder, recursive=recursive, extensions=_IMAGE_EXTENSIONS)
    if limit and limit > 0:
        files = files[:limit]
    channels = {}
    scored = []
    for file in files:
        for channel in _CHANNEL_KEYWORDS.keys():
            score = _texture_channel_score(file, channel, strict=strict)
            if score > 0:
                scored.append((channel, score, len(file.name), file))
    for channel, _score, _length, file in sorted(scored, key=lambda item: (-item[1], item[2], item[3].name.lower())):
        channels.setdefault(channel, file)
    if "base_color" not in channels:
        reject = {"normal", "roughness", "rough", "metallic", "metal", "height", "displacement", "ao", "opacity", "alpha", "emissive", "emission", "mask", "id"}
        fallback = [f for f in files if not any(token in set(_tokenize_texture_name(f)) for token in reject)]
        if fallback:
            channels["base_color"] = sorted(fallback, key=lambda f: (len(f.name), f.name.lower()))[0]
        elif files:
            channels["base_color"] = sorted(files, key=lambda f: (len(f.name), f.name.lower()))[0]
    return channels


def _active_material(context=None):
    context = context or bpy.context
    try:
        obj = getattr(context, "object", None)
        if obj is not None and getattr(obj, "active_material", None) is not None:
            return obj.active_material
    except Exception:
        pass
    try:
        mat = getattr(context, "material", None)
        if mat is not None:
            return mat
    except Exception:
        pass
    return None


def _selected_mesh_objects(context=None):
    context = context or bpy.context
    try:
        selected = list(getattr(context, "selected_objects", []) or [])
    except Exception:
        selected = []
    if not selected:
        obj = getattr(context, "object", None)
        if obj is not None:
            selected = [obj]
    return [obj for obj in selected if getattr(obj, "type", None) == "MESH"]


def _objects_for_scope(context, scope: str):
    scope = str(scope or "SELECTED").upper()
    if scope == "ACTIVE":
        obj = getattr(context, "object", None)
        return [obj] if obj is not None and getattr(obj, "type", None) == "MESH" else []
    if scope == "SCENE":
        try:
            return [obj for obj in bpy.data.objects if getattr(obj, "type", None) == "MESH"]
        except Exception:
            return []
    return _selected_mesh_objects(context)


def _assign_material_to_objects(mat, objects, context=None) -> int:
    count = 0
    if mat is None:
        return 0
    mode = core.assign_mode(context) if context is not None else "ACTIVE_SLOT"
    for obj in objects or []:
        try:
            if core.set_material_on_object(obj, mat, mode, context=context):
                count += 1
        except Exception:
            pass
    return count


def _draw_suite_material_slot_selector(layout, context) -> None:
    scene = getattr(context, "scene", None)
    obj = getattr(context, "object", None) or getattr(context, "active_object", None)
    try:
        slots = getattr(obj, "material_slots", None)
        slot_count = len(slots) if slots is not None else 0
    except Exception:
        slot_count = 0
    if slot_count <= 1:
        return
    try:
        index = core.selected_material_slot_index(context, obj)
        label = core.material_slot_label(obj, index, empty_label=_context_ui(context, "Empty", "空"))
    except Exception:
        label = _context_ui(context, "Active slot", "アクティブスロット")
    row = layout.row(align=True)
    try:
        row.enabled = str(getattr(scene, "sss_assign_mode", "ACTIVE_SLOT") or "ACTIVE_SLOT") == "ACTIVE_SLOT"
    except Exception:
        pass
    row.operator("sss.choose_material_target_slot", text=_context_ui(context, f"Apply slot: {label}", f"適用スロット: {label}"), icon="MATERIAL")


def _mark_material_asset(mat, settings=None) -> None:
    if mat is None:
        return
    try:
        mat.use_fake_user = bool(getattr(settings, "use_fake_user", True))
    except Exception:
        pass
    if not bool(getattr(settings, "mark_asset", False)):
        return
    try:
        mat.asset_mark()
        if getattr(mat, "asset_data", None) is not None:
            mat.asset_data.description = _ui("Generated by Shader Studio material upgrade tools.", "スマートシェーダーのマテリアル上位互換ツールで生成されました。")
            try:
                mat.asset_data.tags.new("Shader Studio")
            except Exception:
                pass
    except Exception:
        pass


def _make_material(name: str, settings=None, clear: bool = True):
    mat_name = _clean_name(name)
    mat = bpy.data.materials.get(mat_name) or bpy.data.materials.new(mat_name)
    try:
        mat.use_nodes = True
        mat.use_fake_user = bool(getattr(settings, "use_fake_user", True))
    except Exception:
        pass
    nt = getattr(mat, "node_tree", None)
    if nt is not None and clear:
        try:
            nt.nodes.clear()
        except Exception:
            pass
    return mat


def _new_node(nodes, node_type: str, *, location=(0, 0), label: str = ""):
    try:
        node = nodes.new(node_type)
        try:
            node.location = location
        except Exception:
            pass
        if label:
            try:
                node.label = label
            except Exception:
                pass
        return node
    except Exception:
        return None


def _node_input(node, *names: str):
    if node is None:
        return None
    inputs = getattr(node, "inputs", None)
    if inputs is None:
        return None
    for name in names:
        try:
            if name in inputs:
                return inputs[name]
        except Exception:
            pass
    try:
        lowered = {str(sock.name).lower(): sock for sock in inputs}
        for name in names:
            sock = lowered.get(str(name).lower())
            if sock is not None:
                return sock
    except Exception:
        pass
    return None


def _node_output(node, *names: str):
    if node is None:
        return None
    outputs = getattr(node, "outputs", None)
    if outputs is None:
        return None
    for name in names:
        try:
            if name in outputs:
                return outputs[name]
        except Exception:
            pass
    try:
        lowered = {str(sock.name).lower(): sock for sock in outputs}
        for name in names:
            sock = lowered.get(str(name).lower())
            if sock is not None:
                return sock
    except Exception:
        pass
    return None


def _link(nt, output_socket, input_socket) -> bool:
    if nt is None or output_socket is None or input_socket is None:
        return False
    try:
        nt.links.new(output_socket, input_socket)
        return True
    except Exception:
        return False


def _set_input(node, names, value) -> None:
    if isinstance(names, str):
        names = (names,)
    sock = _node_input(node, *names)
    if sock is not None:
        try:
            sock.default_value = value
        except Exception:
            pass


def _get_input_value(node, names, default=None):
    if isinstance(names, str):
        names = (names,)
    sock = _node_input(node, *names)
    if sock is None:
        return default
    try:
        return sock.default_value
    except Exception:
        return default


def _create_basic_principled(mat, settings=None):
    nt = mat.node_tree
    nodes = nt.nodes
    out = _new_node(nodes, "ShaderNodeOutputMaterial", location=(560, 0), label="Material Output")
    bsdf = _new_node(nodes, "ShaderNodeBsdfPrincipled", location=(300, 0), label="Shader Studio Principled")
    _link(nt, _node_output(bsdf, "BSDF"), _node_input(out, "Surface"))
    _set_input(bsdf, "Roughness", float(getattr(settings, "roughness", 0.55)) if settings else 0.55)
    _set_input(bsdf, "Metallic", float(getattr(settings, "metallic", 0.0)) if settings else 0.0)
    return nt, nodes, nt.links, out, bsdf


def _create_mapping_chain(nt, nodes, settings=None, *, location=(-900, 0)):
    texcoord = _new_node(nodes, "ShaderNodeTexCoord", location=location, label="Coordinates")
    mapping = _new_node(nodes, "ShaderNodeMapping", location=(location[0] + 180, location[1]), label="Shared Mapping")
    scale = float(getattr(settings, "texture_scale", 1.0)) if settings is not None else 1.0
    try:
        _node_input(mapping, "Scale").default_value = (scale, scale, scale)
    except Exception:
        pass
    _link(nt, _node_output(texcoord, "Generated", "Object", "UV"), _node_input(mapping, "Vector"))
    return texcoord, mapping


def _configure_color_ramp(ramp_node, colors):
    if ramp_node is None:
        return
    try:
        ramp = ramp_node.color_ramp
        while len(ramp.elements) < len(colors):
            ramp.elements.new(0.5)
        for element, item in zip(ramp.elements, colors):
            pos, color = item
            element.position = float(pos)
            element.color = color
    except Exception:
        pass


def _add_noise_bump(nt, nodes, bsdf, settings=None, *, scale=35.0, detail=8.0, location=(-360, -380)):
    noise = _new_node(nodes, "ShaderNodeTexNoise", location=location, label="Procedural detail")
    _set_input(noise, "Scale", scale)
    _set_input(noise, "Detail", detail)
    _set_input(noise, "Roughness", 0.58)
    bump = _new_node(nodes, "ShaderNodeBump", location=(location[0] + 280, location[1] - 20), label="Generated bump")
    _set_input(bump, "Strength", float(getattr(settings, "normal_strength", 0.18)) if settings else 0.18)
    _set_input(bump, "Distance", float(getattr(settings, "height_strength", 0.05)) if settings else 0.05)
    _link(nt, _node_output(noise, "Fac"), _node_input(bump, "Height"))
    _link(nt, _node_output(bump, "Normal"), _node_input(bsdf, "Normal"))
    return noise, bump


def _set_material_blend(mat, alpha: float = 1.0) -> None:
    try:
        if alpha < 1.0:
            mat.blend_method = "BLEND"
            mat.use_screen_refraction = True
            mat.show_transparent_back = True
    except Exception:
        pass


def _summarize_principled(mat) -> dict:
    data = {"name": getattr(mat, "name", ""), "textures": [], "inputs": {}}
    nt = getattr(mat, "node_tree", None)
    if nt is None:
        return data
    bsdf = next((node for node in nt.nodes if getattr(node, "type", "") == "BSDF_PRINCIPLED"), None)
    if bsdf is not None:
        for key in ("Base Color", "Metallic", "Roughness", "Alpha", "Emission Strength"):
            value = _get_input_value(bsdf, key, None)
            if value is None:
                continue
            try:
                if hasattr(value, "__iter__") and not isinstance(value, str):
                    value = list(value)
            except Exception:
                pass
            data["inputs"][key] = value
    for node in nt.nodes:
        if getattr(node, "type", "") == "TEX_IMAGE":
            image = getattr(node, "image", None)
            if image is not None:
                data["textures"].append({"node": getattr(node, "name", ""), "image": getattr(image, "name", ""), "path": getattr(image, "filepath", "")})
    return data


def _write_json(path: Path, data: dict) -> bool:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        return True
    except Exception:
        return False


def _read_json(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

_PRESET_BASE_COLORS = {
    "PBR_UBER": (0.72, 0.72, 0.70, 1.0), "METAL": (0.66, 0.62, 0.55, 1.0),
    "WOOD": (0.55, 0.32, 0.16, 1.0), "STONE": (0.45, 0.46, 0.44, 1.0),
    "FABRIC": (0.35, 0.38, 0.52, 1.0), "WOOL": (0.75, 0.72, 0.65, 1.0),
    "CLAY": (0.70, 0.37, 0.25, 1.0), "LIQUID": (0.40, 0.70, 0.95, 0.45),
    "SKIN": (0.78, 0.50, 0.40, 1.0), "DECAL": (1.0, 1.0, 1.0, 0.75),
    "EMISSIVE": (0.10, 0.65, 1.0, 1.0),
}


def build_procedural_material(name: str, preset: str, settings=None):
    preset = str(preset or "PBR_UBER").upper()
    mat = _make_material(name, settings, clear=True)
    nt, nodes, _links, out, bsdf = _create_basic_principled(mat, settings)
    _create_mapping_chain(nt, nodes, settings)
    base = _PRESET_BASE_COLORS.get(preset, _PRESET_BASE_COLORS["PBR_UBER"])
    _set_input(bsdf, "Base Color", base)
    _set_input(bsdf, "Alpha", base[3])
    _set_material_blend(mat, base[3])
    if preset == "METAL":
        _set_input(bsdf, "Metallic", 1.0)
        _set_input(bsdf, "Roughness", max(0.08, float(getattr(settings, "roughness", 0.35))))
        noise = _new_node(nodes, "ShaderNodeTexNoise", location=(-520, 160), label="Scratches and anisotropic wear")
        ramp = _new_node(nodes, "ShaderNodeValToRGB", location=(-260, 160), label="Metal tone ramp")
        _set_input(noise, "Scale", 95.0); _set_input(noise, "Detail", 16.0)
        _configure_color_ramp(ramp, [(0.0, (0.28, 0.27, 0.25, 1)), (0.72, (0.72, 0.69, 0.62, 1)), (1.0, (1.0, 0.96, 0.84, 1))])
        _link(nt, _node_output(noise, "Fac"), _node_input(ramp, "Fac")); _link(nt, _node_output(ramp, "Color"), _node_input(bsdf, "Base Color"))
        _add_noise_bump(nt, nodes, bsdf, settings, scale=160.0, detail=12.0)
    elif preset == "WOOD":
        wave = _new_node(nodes, "ShaderNodeTexWave", location=(-520, 180), label="Wood rings")
        ramp = _new_node(nodes, "ShaderNodeValToRGB", location=(-250, 180), label="Wood color ramp")
        _set_input(wave, "Scale", 12.0); _set_input(wave, "Distortion", 18.0)
        _configure_color_ramp(ramp, [(0.0, (0.20, 0.10, 0.035, 1)), (0.45, (0.55, 0.31, 0.13, 1)), (1.0, (0.86, 0.62, 0.34, 1))])
        _link(nt, _node_output(wave, "Color", "Fac"), _node_input(ramp, "Fac")); _link(nt, _node_output(ramp, "Color"), _node_input(bsdf, "Base Color"))
        _add_noise_bump(nt, nodes, bsdf, settings, scale=42.0, detail=10.0)
    elif preset == "STONE":
        vor = _new_node(nodes, "ShaderNodeTexVoronoi", location=(-560, 160), label="Stone cells")
        ramp = _new_node(nodes, "ShaderNodeValToRGB", location=(-260, 160), label="Mineral ramp")
        _set_input(vor, "Scale", 18.0)
        _configure_color_ramp(ramp, [(0.0, (0.18, 0.18, 0.17, 1)), (0.50, (0.48, 0.49, 0.47, 1)), (1.0, (0.82, 0.82, 0.78, 1))])
        _link(nt, _node_output(vor, "Distance", "Fac"), _node_input(ramp, "Fac")); _link(nt, _node_output(ramp, "Color"), _node_input(bsdf, "Base Color"))
        _add_noise_bump(nt, nodes, bsdf, settings, scale=75.0, detail=14.0)
    elif preset in {"FABRIC", "WOOL"}:
        wave = _new_node(nodes, "ShaderNodeTexWave", location=(-560, 200), label="Weave / fiber direction")
        ramp = _new_node(nodes, "ShaderNodeValToRGB", location=(-260, 120), label="Fabric color ramp")
        _set_input(wave, "Scale", 28.0 if preset == "FABRIC" else 55.0); _set_input(wave, "Distortion", 5.0 if preset == "FABRIC" else 18.0)
        _configure_color_ramp(ramp, [(0.0, (0.18, 0.19, 0.24, 1)), (0.5, base), (1.0, (0.86, 0.84, 0.78, 1))])
        _link(nt, _node_output(wave, "Color", "Fac"), _node_input(ramp, "Fac")); _link(nt, _node_output(ramp, "Color"), _node_input(bsdf, "Base Color"))
        _add_noise_bump(nt, nodes, bsdf, settings, scale=130.0 if preset == "WOOL" else 85.0, detail=14.0)
    elif preset == "CLAY":
        _set_input(bsdf, "Roughness", 0.92); _add_noise_bump(nt, nodes, bsdf, settings, scale=95.0, detail=16.0)
    elif preset == "LIQUID":
        _set_input(bsdf, "Roughness", 0.03); _set_input(bsdf, "Alpha", 0.38); _set_input(bsdf, ("Transmission Weight", "Transmission"), 0.7); _set_input(bsdf, "IOR", 1.333)
        _set_material_blend(mat, 0.38); _add_noise_bump(nt, nodes, bsdf, settings, scale=18.0, detail=8.0)
    elif preset == "SKIN":
        _set_input(bsdf, "Roughness", 0.42); _set_input(bsdf, ("Subsurface Weight", "Subsurface"), 0.35); _set_input(bsdf, ("Subsurface Radius",), (1.0, 0.45, 0.28))
        _set_input(bsdf, ("Coat Weight", "Coat"), 0.18); _set_input(bsdf, "Coat Roughness", 0.32); _add_noise_bump(nt, nodes, bsdf, settings, scale=145.0, detail=15.0)
    elif preset == "DECAL":
        _set_input(bsdf, "Roughness", 0.38); _set_input(bsdf, "Alpha", 0.72); _set_material_blend(mat, 0.72)
    elif preset == "EMISSIVE":
        _set_input(bsdf, "Emission Color", base); _set_input(bsdf, "Emission Strength", 2.5); _set_input(bsdf, "Roughness", 0.25)
    else:
        noise = _new_node(nodes, "ShaderNodeTexNoise", location=(-520, 160), label="Procedural color breakup")
        ramp = _new_node(nodes, "ShaderNodeValToRGB", location=(-260, 160), label="PBR color ramp")
        _set_input(noise, "Scale", 18.0); _set_input(noise, "Detail", 10.0)
        _configure_color_ramp(ramp, [(0.0, (0.36, 0.36, 0.34, 1)), (1.0, base)])
        _link(nt, _node_output(noise, "Fac"), _node_input(ramp, "Fac")); _link(nt, _node_output(ramp, "Color"), _node_input(bsdf, "Base Color"))
        _add_noise_bump(nt, nodes, bsdf, settings, scale=55.0, detail=9.0)
    try:
        mat["sss_material_studio_preset"] = preset
        mat["sss_material_studio_version"] = ".".join(str(v) for v in ADDON_VERSION)
    except Exception:
        pass
    _mark_material_asset(mat, settings)
    return mat


def build_npr_material(name: str, style: str, settings=None):
    style = str(style or "TOON").upper()
    mat = _make_material(name, settings, clear=True)
    nt, nodes, _links, out, bsdf = _create_basic_principled(mat, settings)
    base = {"WATERCOLOR": (0.62, 0.78, 0.92, 1), "COMIC": (1.0, 0.62, 0.18, 1), "HALFTONE": (0.82, 0.82, 0.80, 1)}.get(style, (0.86, 0.58, 0.34, 1))
    _set_input(bsdf, "Base Color", base); _set_input(bsdf, "Roughness", 0.78); _create_mapping_chain(nt, nodes, settings)
    noise = _new_node(nodes, "ShaderNodeTexNoise", location=(-560, 180), label="NPR tone source")
    ramp = _new_node(nodes, "ShaderNodeValToRGB", location=(-280, 180), label="Stepped toon ramp")
    _set_input(noise, "Scale", 82.0 if style == "HALFTONE" else 9.0 if style == "WATERCOLOR" else 18.0); _set_input(noise, "Detail", 6.0)
    threshold = float(getattr(settings, "toon_threshold", 0.55)) if settings else 0.55
    steps = max(2, int(getattr(settings, "toon_steps", 3)) if settings else 3)
    colors = []
    for i in range(steps):
        pos = min(1.0, max(0.0, i / max(1, steps - 1)))
        factor = 0.55 + (0.55 * pos)
        color = (0.03, 0.03, 0.035, 1) if style == "COMIC" and i == 0 else (min(base[0] * factor, 1), min(base[1] * factor, 1), min(base[2] * factor, 1), 1)
        colors.append((min(1.0, max(0.0, pos * 0.85 + threshold * 0.15)), color))
    _configure_color_ramp(ramp, colors)
    _link(nt, _node_output(noise, "Fac"), _node_input(ramp, "Fac")); _link(nt, _node_output(ramp, "Color"), _node_input(bsdf, "Base Color"))
    _add_noise_bump(nt, nodes, bsdf, settings, scale=36.0 if style != "WATERCOLOR" else 22.0, detail=8.0)
    try:
        mat["sss_material_studio_style"] = style
    except Exception:
        pass
    _mark_material_asset(mat, settings)
    return mat


def build_atomic_material(name: str, atomic: str, settings=None):
    atomic = str(atomic or "NOISE").upper()
    mat = _make_material(name, settings, clear=True)
    nt, nodes, _links, out, bsdf = _create_basic_principled(mat, settings)
    _create_mapping_chain(nt, nodes, settings)
    source_type, label, scale = "ShaderNodeTexNoise", "Atomic noise", 28.0
    if atomic == "VORONOI": source_type, label, scale = "ShaderNodeTexVoronoi", "Atomic Voronoi distance", 20.0
    elif atomic == "GRADIENT": source_type, label, scale = "ShaderNodeTexGradient", "Atomic gradient", 1.0
    elif atomic == "EMBOSS": source_type, label, scale = "ShaderNodeTexWave", "Atomic emboss wave", 34.0
    elif atomic == "REACTION": source_type, label, scale = "ShaderNodeTexNoise", "Reaction-diffusion approximation", 65.0
    source = _new_node(nodes, source_type, location=(-560, 160), label=label)
    ramp = _new_node(nodes, "ShaderNodeValToRGB", location=(-280, 160), label="Atomic remap")
    _set_input(source, "Scale", scale); _set_input(source, "Detail", 14.0); _set_input(source, "Distortion", 18.0)
    if atomic == "REACTION": colors = [(0.0, (0.02, 0.03, 0.04, 1)), (0.42, (0.12, 0.55, 0.48, 1)), (0.6, (0.9, 0.86, 0.46, 1)), (1.0, (0.04, 0.07, 0.12, 1))]
    elif atomic == "EMBOSS": colors = [(0.0, (0.23, 0.23, 0.23, 1)), (0.5, (0.56, 0.56, 0.56, 1)), (1.0, (0.96, 0.96, 0.96, 1))]
    elif atomic == "VORONOI": colors = [(0.0, (0.06, 0.10, 0.14, 1)), (0.55, (0.50, 0.64, 0.72, 1)), (1.0, (0.96, 0.98, 1.0, 1))]
    else: colors = [(0.0, (0.08, 0.08, 0.10, 1)), (0.5, (0.55, 0.58, 0.62, 1)), (1.0, (1.0, 0.92, 0.72, 1))]
    _configure_color_ramp(ramp, colors)
    _link(nt, _node_output(source, "Fac", "Distance", "Color"), _node_input(ramp, "Fac")); _link(nt, _node_output(ramp, "Color"), _node_input(bsdf, "Base Color"))
    bump = _new_node(nodes, "ShaderNodeBump", location=(-30, -140), label="Atomic height / emboss")
    _set_input(bump, "Strength", float(getattr(settings, "normal_strength", 0.18)) if settings else 0.18); _set_input(bump, "Distance", float(getattr(settings, "height_strength", 0.05)) if settings else 0.05)
    _link(nt, _node_output(source, "Fac", "Distance", "Color"), _node_input(bump, "Height")); _link(nt, _node_output(bump, "Normal"), _node_input(bsdf, "Normal"))
    try:
        mat["sss_material_studio_atomic"] = atomic
    except Exception:
        pass
    _mark_material_asset(mat, settings)
    return mat

def _texture_node_filepath(node) -> str:
    try:
        image = getattr(node, "image", None)
        return str(getattr(image, "filepath", "") or getattr(image, "name", "") or "")
    except Exception:
        return ""

def _pbr_packed_channel_name(filepath: str, channel: str) -> str:
    name = re.sub(r"[^a-z0-9]+", "", Path(bpy.path.basename(str(filepath or ""))).stem.lower())
    channel = str(channel or "").lower()
    # Common packed-map conventions: ORM/ARM = R:AO, G:Roughness, B:Metallic.
    if any(token in name for token in ("orm", "arm", "occlusionroughnessmetallic", "ambientroughnessmetallic")):
        return {"ao": "Red", "roughness": "Green", "metallic": "Blue"}.get(channel, "Red")
    # RMA is often R:Roughness, G:Metallic, B:AO.
    if "rma" in name:
        return {"roughness": "Red", "metallic": "Green", "ao": "Blue"}.get(channel, "Red")
    return "Red"

def _pbr_channel_output(nt, nodes, node, channel: str, *, location=(0, 0)):
    if node is None:
        return None
    sep = _new_node(nodes, "ShaderNodeSeparateColor", location=location, label=f"{channel} packed channel")
    if sep is None:
        return _node_output(node, "Color", "Fac", "Alpha")
    _link(nt, _node_output(node, "Color", "Fac", "Alpha"), _node_input(sep, "Color", "Image"))
    socket_name = _pbr_packed_channel_name(_texture_node_filepath(node), channel)
    return _node_output(sep, socket_name, socket_name[0], "Red", "R")

def _normal_color_output(nt, nodes, normal_node):
    """Return a normal-map color socket, inverting Y for DirectX-style filenames."""
    if normal_node is None:
        return None
    path_text = _texture_node_filepath(normal_node).lower()
    if not any(token in path_text for token in ("normaldx", "directx", "_dx", "-dx")):
        return _node_output(normal_node, "Color")
    sep = _new_node(nodes, "ShaderNodeSeparateColor", location=(-360, -520), label="DirectX normal split")
    inv = _new_node(nodes, "ShaderNodeMath", location=(-140, -520), label="Invert normal Y")
    comb = _new_node(nodes, "ShaderNodeCombineColor", location=(60, -520), label="OpenGL normal recombine")
    try:
        inv.operation = "SUBTRACT"
    except Exception:
        pass
    try:
        inv.inputs[0].default_value = 1.0
    except Exception:
        pass
    _link(nt, _node_output(normal_node, "Color"), _node_input(sep, "Color", "Image"))
    _link(nt, _node_output(sep, "Red", "R"), _node_input(comb, "Red", "R"))
    try:
        _link(nt, _node_output(sep, "Green", "G"), inv.inputs[1])
    except Exception:
        pass
    _link(nt, _node_output(inv, "Value"), _node_input(comb, "Green", "G"))
    _link(nt, _node_output(sep, "Blue", "B"), _node_input(comb, "Blue", "B"))
    return _node_output(comb, "Color") or _node_output(normal_node, "Color")


def build_texture_set_material(name: str, folder: Path, settings=None):
    channels = _scan_texture_set(folder, recursive=bool(getattr(settings, "recursive_scan", True)), limit=int(getattr(settings, "batch_limit", 0)), strict=bool(getattr(settings, "strict_texture_detection", True)))
    mat = _make_material(name, settings, clear=bool(getattr(settings, "force_texture_rewire", True)))
    if not getattr(mat, "use_nodes", False) or getattr(mat, "node_tree", None) is None:
        mat.use_nodes = True
    nt = mat.node_tree
    nodes = nt.nodes
    if bool(getattr(settings, "force_texture_rewire", True)):
        nodes.clear()
        nt, nodes, _links, out, bsdf = _create_basic_principled(mat, settings)
    else:
        bsdf = next((node for node in nodes if getattr(node, "type", "") == "BSDF_PRINCIPLED"), None)
        if bsdf is None:
            nt, nodes, _links, out, bsdf = _create_basic_principled(mat, settings)
    texcoord, mapping = _create_mapping_chain(nt, nodes, settings)
    image_nodes = {}
    y = 260
    for channel, path in channels.items():
        image = _open_image(path)
        if image is None:
            continue
        if channel != "base_color" and bool(getattr(settings, "auto_color_space_fix", True)):
            _set_image_data_colorspace(image)
        node = _new_node(nodes, "ShaderNodeTexImage", location=(-620, y), label=f"PBR {channel}")
        if node is None:
            continue
        try:
            node.image = image
        except Exception:
            pass
        _link(nt, _node_output(mapping, "Vector"), _node_input(node, "Vector"))
        image_nodes[channel] = node
        y -= 260
    base_node = image_nodes.get("base_color")
    ao_node = image_nodes.get("ao")
    if base_node is not None and ao_node is not None:
        mix = _new_node(nodes, "ShaderNodeMixRGB", location=(-120, 230), label="Base × AO")
        if mix is not None:
            try: mix.blend_type = "MULTIPLY"
            except Exception: pass
            _set_input(mix, "Fac", 1.0)
            ao_socket = _pbr_channel_output(nt, nodes, ao_node, "ao", location=(-120, 20))
            _link(nt, _node_output(base_node, "Color"), _node_input(mix, "Color1", "A")); _link(nt, ao_socket, _node_input(mix, "Color2", "B"))
            _link(nt, _node_output(mix, "Color", "Result"), _node_input(bsdf, "Base Color"))
        else:
            _link(nt, _node_output(base_node, "Color"), _node_input(bsdf, "Base Color"))
    elif base_node is not None:
        _link(nt, _node_output(base_node, "Color"), _node_input(bsdf, "Base Color"))
    for channel, input_names in (("roughness", ("Roughness",)), ("metallic", ("Metallic",))):
        node = image_nodes.get(channel)
        if node is None:
            continue
        output = _pbr_channel_output(nt, nodes, node, channel, location=(-120, getattr(node, "location", (0, 0)).y if hasattr(getattr(node, "location", None), "y") else -160))
        _link(nt, output, _node_input(bsdf, *input_names))
    normal_node = image_nodes.get("normal"); height_node = image_nodes.get("height")
    if normal_node is not None and height_node is not None:
        normal_map = _new_node(nodes, "ShaderNodeNormalMap", location=(-120, -380), label="Normal map")
        bump = _new_node(nodes, "ShaderNodeBump", location=(90, -470), label="Normal + height composite")
        _set_input(normal_map, "Strength", float(getattr(settings, "normal_strength", 1.0)))
        _set_input(bump, "Strength", float(getattr(settings, "normal_strength", 0.18)) * 0.55)
        _set_input(bump, "Distance", float(getattr(settings, "height_strength", 0.05)))
        _link(nt, _normal_color_output(nt, nodes, normal_node), _node_input(normal_map, "Color"))
        _link(nt, _node_output(normal_map, "Normal"), _node_input(bump, "Normal"))
        _link(nt, _node_output(height_node, "Color", "Alpha"), _node_input(bump, "Height"))
        _link(nt, _node_output(bump, "Normal"), _node_input(bsdf, "Normal"))
    elif normal_node is not None:
        normal_map = _new_node(nodes, "ShaderNodeNormalMap", location=(-120, -380), label="Normal map")
        _set_input(normal_map, "Strength", float(getattr(settings, "normal_strength", 1.0)))
        _link(nt, _normal_color_output(nt, nodes, normal_node), _node_input(normal_map, "Color")); _link(nt, _node_output(normal_map, "Normal"), _node_input(bsdf, "Normal"))
    elif height_node is not None:
        bump = _new_node(nodes, "ShaderNodeBump", location=(-120, -420), label="Height to bump")
        _set_input(bump, "Strength", float(getattr(settings, "normal_strength", 0.18))); _set_input(bump, "Distance", float(getattr(settings, "height_strength", 0.05)))
        _link(nt, _node_output(height_node, "Color", "Alpha"), _node_input(bump, "Height")); _link(nt, _node_output(bump, "Normal"), _node_input(bsdf, "Normal"))
    alpha_node = image_nodes.get("alpha")
    if alpha_node is not None:
        _link(nt, _node_output(alpha_node, "Alpha", "Color"), _node_input(bsdf, "Alpha")); _set_material_blend(mat, 0.5)
    emission_node = image_nodes.get("emission")
    if emission_node is not None:
        _link(nt, _node_output(emission_node, "Color"), _node_input(bsdf, "Emission Color")); _set_input(bsdf, "Emission Strength", 1.0)
    try:
        mat["sss_material_studio_texture_set"] = str(folder)
        mat["sss_material_studio_channels"] = ",".join(sorted(channels.keys()))
    except Exception:
        pass
    _mark_material_asset(mat, settings)
    if bool(getattr(settings, "auto_layout_nodes", True)):
        _layout_material_nodes(mat)
    return mat, channels


def build_photo_sampler_material(name: str, image_path: Path, settings=None):
    mat = _make_material(name, settings, clear=True)
    nt, nodes, _links, out, bsdf = _create_basic_principled(mat, settings)
    _create_mapping_chain(nt, nodes, settings)
    image = _open_image(image_path)
    if image is not None:
        tex = _new_node(nodes, "ShaderNodeTexImage", location=(-620, 160), label="Photo base")
        try: tex.image = image
        except Exception: pass
        _link(nt, _node_output(tex, "Color"), _node_input(bsdf, "Base Color"))
    noise = _new_node(nodes, "ShaderNodeTexNoise", location=(-620, -160), label="Generated sampler detail")
    ramp = _new_node(nodes, "ShaderNodeValToRGB", location=(-360, -160), label="Generated roughness")
    bump = _new_node(nodes, "ShaderNodeBump", location=(-80, -260), label="Generated photo height")
    _set_input(noise, "Scale", 95.0); _set_input(noise, "Detail", 14.0)
    _configure_color_ramp(ramp, [(0.0, (0.22, 0.22, 0.22, 1)), (1.0, (0.86, 0.86, 0.86, 1))])
    _link(nt, _node_output(noise, "Fac"), _node_input(ramp, "Fac")); _link(nt, _node_output(ramp, "Color"), _node_input(bsdf, "Roughness"))
    _set_input(bump, "Strength", float(getattr(settings, "normal_strength", 0.18))); _set_input(bump, "Distance", float(getattr(settings, "height_strength", 0.05)))
    _link(nt, _node_output(noise, "Fac"), _node_input(bump, "Height")); _link(nt, _node_output(bump, "Normal"), _node_input(bsdf, "Normal"))
    try: mat["sss_material_studio_sampler_source"] = str(image_path)
    except Exception: pass
    _mark_material_asset(mat, settings)
    return mat


def apply_smart_weathering(mat, settings=None) -> bool:
    if mat is None:
        return False
    try: mat.use_nodes = True
    except Exception: pass
    nt = getattr(mat, "node_tree", None)
    if nt is None:
        return False
    nodes = nt.nodes
    bsdf = next((node for node in nodes if getattr(node, "type", "") == "BSDF_PRINCIPLED"), None)
    if bsdf is None:
        _, nodes, _, _, bsdf = _create_basic_principled(mat, settings)
    base_color_value = _get_input_value(bsdf, "Base Color", (0.8, 0.8, 0.8, 1.0))
    base_input = _node_input(bsdf, "Base Color"); normal_input = _node_input(bsdf, "Normal")
    existing_base = base_input.links[0].from_socket if base_input is not None and base_input.is_linked else None
    existing_normal = normal_input.links[0].from_socket if normal_input is not None and normal_input.is_linked else None
    noise = _new_node(nodes, "ShaderNodeTexNoise", location=(-760, -620), label="Smart dirt / grunge mask")
    ramp = _new_node(nodes, "ShaderNodeValToRGB", location=(-500, -620), label="Wear-dirt mask remap")
    mix = _new_node(nodes, "ShaderNodeMixRGB", location=(-220, -500), label="Smart weathering blend")
    ao = _new_node(nodes, "ShaderNodeAmbientOcclusion", location=(-760, -880), label="Cavity/AO approximation")
    _set_input(noise, "Scale", 55.0); _set_input(noise, "Detail", 14.0)
    dirt = float(getattr(settings, "dirt_amount", 0.35)) if settings else 0.35
    weather = float(getattr(settings, "weathering_amount", 0.45)) if settings else 0.45
    _configure_color_ramp(ramp, [(0.0, (0.02, 0.018, 0.012, 1)), (max(0.05, 1.0 - dirt), (0.33, 0.27, 0.18, 1)), (1.0, (0.92, 0.84, 0.65, 1))])
    _link(nt, _node_output(noise, "Fac"), _node_input(ramp, "Fac"))
    if mix is not None:
        try: mix.blend_type = "OVERLAY"
        except Exception: pass
        _set_input(mix, "Fac", weather)
        try: _node_input(mix, "Color1", "A").default_value = base_color_value
        except Exception: pass
        # The weathering goes on top of what already drives the base color and normal.
        if existing_base is not None: _link(nt, existing_base, _node_input(mix, "Color1", "A"))
        _link(nt, _node_output(ramp, "Color"), _node_input(mix, "Color2", "B"))
        cavity = _new_node(nodes, "ShaderNodeMixRGB", location=(-40, -500), label="Smart weathering cavity")
        if cavity is not None:
            try: cavity.blend_type = "MULTIPLY"
            except Exception: pass
            _set_input(cavity, "Fac", weather)
            _link(nt, _node_output(mix, "Color", "Result"), _node_input(cavity, "Color1", "A")); _link(nt, _node_output(ao, "Color"), _node_input(cavity, "Color2", "B"))
            _link(nt, _node_output(cavity, "Color", "Result"), _node_input(bsdf, "Base Color"))
        else:
            _link(nt, _node_output(mix, "Color", "Result"), _node_input(bsdf, "Base Color"))
    bump_noise = _new_node(nodes, "ShaderNodeTexNoise", location=(-500, -940), label="Weathered micro damage")
    bump = _new_node(nodes, "ShaderNodeBump", location=(-200, -880), label="Weathering damage bump")
    _set_input(bump_noise, "Scale", 180.0); _set_input(bump_noise, "Detail", 12.0)
    wear = float(getattr(settings, "edge_wear_amount", 0.35)) if settings else 0.35
    _set_input(bump, "Strength", max(0.0, wear) * float(getattr(settings, "normal_strength", 0.18) if settings else 0.18)); _set_input(bump, "Distance", float(getattr(settings, "height_strength", 0.05) if settings else 0.05))
    _link(nt, _node_output(bump_noise, "Fac"), _node_input(bump, "Height"))
    if existing_normal is not None: _link(nt, existing_normal, _node_input(bump, "Normal"))
    _link(nt, _node_output(bump, "Normal"), _node_input(bsdf, "Normal"))
    wet = float(getattr(settings, "wetness_amount", 0.25)) if settings else 0.25
    current_rough = float(_get_input_value(bsdf, "Roughness", 0.55) or 0.55)
    _set_input(bsdf, "Roughness", max(0.02, current_rough * (1.0 - wet * 0.85)))
    try: mat["sss_material_studio_weathering"] = weather
    except Exception: pass
    return True


def _iter_material_nodes(mat):
    nt = getattr(mat, "node_tree", None)
    if nt is None:
        return []
    try:
        return list(nt.nodes)
    except Exception:
        return []


def _find_principled(mat):
    for node in _iter_material_nodes(mat):
        if getattr(node, "type", "") == "BSDF_PRINCIPLED":
            return node
    return None


def _ensure_material_has_principled(mat, settings=None):
    if mat is None:
        return None
    try:
        mat.use_nodes = True
    except Exception:
        pass
    bsdf = _find_principled(mat)
    if bsdf is not None:
        return bsdf
    try:
        _create_basic_principled(mat, settings)
    except Exception:
        pass
    return _find_principled(mat)


def _clamp_float(value, minimum=0.0, maximum=1.0, fallback=0.0):
    try:
        return max(float(minimum), min(float(maximum), float(value)))
    except Exception:
        return float(fallback)


def _layout_material_nodes(mat) -> int:
    """Layout material nodes using link depth first, then type buckets.

    This produces a cleaner shader graph than fixed type columns for large
    imported texture sets: texture readers stay left, conversion nodes form the
    middle columns, and BSDF/output nodes remain on the right.
    """
    nt = getattr(mat, "node_tree", None)
    if nt is None:
        return 0
    try:
        nodes = list(nt.nodes)
        links = list(nt.links)
    except Exception:
        return 0
    if not nodes:
        return 0
    type_fallback = {
        "TEX_COORD": -5, "MAPPING": -4, "TEX_IMAGE": -3, "TEX_NOISE": -3, "TEX_VORONOI": -3,
        "TEX_WAVE": -3, "VALTORGB": -2, "SEPARATE_COLOR": -2, "COMBINE_COLOR": -1,
        "MIX": -1, "MIX_RGB": -1, "NORMAL_MAP": -1, "BUMP": 0, "GROUP": 0,
        "BSDF_PRINCIPLED": 1, "OUTPUT_MATERIAL": 2,
    }
    incoming = {node: [] for node in nodes}
    outgoing = {node: [] for node in nodes}
    for link in links:
        try:
            a, b = link.from_node, link.to_node
            outgoing.setdefault(a, []).append(b)
            incoming.setdefault(b, []).append(a)
        except Exception:
            pass
    memo = {}
    def depth(node, seen=None):
        if node in memo:
            return memo[node]
        seen = set() if seen is None else set(seen)
        if node in seen:
            return type_fallback.get(str(getattr(node, "type", "") or ""), 0)
        seen.add(node)
        parents = incoming.get(node, [])
        if not parents:
            value = type_fallback.get(str(getattr(node, "type", "") or ""), 0)
        else:
            value = max(depth(parent, seen) + 1 for parent in parents)
        memo[node] = value
        return value
    buckets = {}
    for node in nodes:
        try:
            d = depth(node)
        except Exception:
            d = type_fallback.get(str(getattr(node, "type", "") or ""), 0)
        if str(getattr(node, "type", "") or "") == "OUTPUT_MATERIAL":
            d = max(d, 5)
        buckets.setdefault(d, []).append(node)
    moved = 0
    x_step = 310
    y_step = 220
    min_depth = min(buckets.keys()) if buckets else -3
    for d in sorted(buckets.keys()):
        column = sorted(buckets[d], key=lambda n: (str(getattr(n, "type", "") or ""), str(getattr(n, "name", "") or "")))
        x = int((d - min_depth) * x_step - 900)
        y = int((len(column) - 1) * y_step * 0.5)
        for node in column:
            try:
                node.location.x = x
                node.location.y = y
                y -= y_step
                moved += 1
            except Exception:
                pass
    return moved



def _connected_socket_names(mat) -> dict[str, set[str]]:
    result = {"from": set(), "to": set()}
    nt = getattr(mat, "node_tree", None)
    if nt is None:
        return result
    try:
        for link in nt.links:
            result["from"].add(str(getattr(link.from_socket, "name", "") or "").lower())
            result["to"].add(str(getattr(link.to_socket, "name", "") or "").lower())
    except Exception:
        pass
    return result


def _names_data_texture(text) -> bool:
    # Whole tokens only: a substring test read "uniform" as ORM and "chaos" as AO.
    # The whole text, not a Path stem: an image name such as "wall.normal" has no extension.
    name = str(text or "")
    color = _texture_channel_score(name, "base_color")
    return any(_texture_channel_score(name, channel) > max(0, color) for channel in ("roughness", "metallic", "normal", "height", "ao", "alpha"))


def _fix_principled_routing(mat, bsdf) -> int:
    nt = getattr(mat, "node_tree", None)
    if nt is None or bsdf is None:
        return 0
    fixed = 0
    nodes = nt.nodes
    outputs = [node for node in nodes if getattr(node, "type", "") == "OUTPUT_MATERIAL"]
    output = next((node for node in outputs if getattr(node, "is_active_output", False)), outputs[0] if outputs else None)
    if output is None:
        output = _new_node(nodes, "ShaderNodeOutputMaterial", location=(320, 0))
    surface = _node_input(output, "Surface")
    if surface is not None and not surface.is_linked and _link(nt, _node_output(bsdf, "BSDF"), surface):
        fixed += 1
    normal = _node_input(bsdf, "Normal")
    source = normal.links[0].from_node if normal is not None and normal.is_linked else None
    if source is not None and getattr(source, "type", "") == "TEX_IMAGE":
        normal_map = _new_node(nodes, "ShaderNodeNormalMap", location=(-220, -300))
        if normal_map is not None:
            _link(nt, _node_output(source, "Color"), _node_input(normal_map, "Color")); _link(nt, _node_output(normal_map, "Normal"), normal)
            _set_image_data_colorspace(getattr(source, "image", None))
            fixed += 1
    return fixed


def _fix_texture_color_spaces(mat) -> int:
    fixed = 0
    for node in _iter_material_nodes(mat):
        if getattr(node, "type", "") != "TEX_IMAGE":
            continue
        image = getattr(node, "image", None)
        if image is None:
            continue
        if any(_names_data_texture(name) for name in (getattr(node, "label", ""), getattr(node, "name", ""), bpy.path.basename(str(getattr(image, "filepath", "") or "")), getattr(image, "name", ""))):
            before = str(getattr(getattr(image, "colorspace_settings", None), "name", "") or "")
            _set_image_data_colorspace(image)
            after = str(getattr(getattr(image, "colorspace_settings", None), "name", "") or "")
            if after and after != before:
                fixed += 1
    return fixed


def _material_health_score(mat) -> tuple[int, list[str]]:
    warnings = []
    score = 100
    if mat is None:
        return 0, ["Material is None"]
    nt = getattr(mat, "node_tree", None)
    if nt is None or not getattr(mat, "use_nodes", False):
        return 25, ["Material does not use nodes"]
    bsdf = _find_principled(mat)
    if bsdf is None:
        score -= 25; warnings.append("No Principled BSDF")
    nodes = _iter_material_nodes(mat)
    if len(nodes) > 80:
        score -= 8; warnings.append("Very dense node tree")
    for node in nodes:
        if getattr(node, "type", "") == "TEX_IMAGE":
            image = getattr(node, "image", None)
            path = str(getattr(image, "filepath", "") or "") if image is not None else ""
            if not image:
                score -= 7; warnings.append(f"Image node without image: {getattr(node, 'name', '')}")
            elif path and _is_missing_path(path):
                score -= 12; warnings.append(f"Missing image: {path}")
    links = _connected_socket_names(mat)
    if bsdf is not None:
        if "base color" not in links["to"]:
            warnings.append("Base Color uses default value")
        if "roughness" not in links["to"]:
            warnings.append("Roughness uses default value")
        if "normal" not in links["to"]:
            warnings.append("No normal/bump input")
    return max(0, min(100, score)), warnings


def upgrade_material_quality(mat, settings=None) -> dict:
    report = {"material": str(getattr(mat, "name", "") or ""), "changed": 0, "score_before": 0, "score_after": 0, "warnings": []}
    if mat is None:
        return report
    before, warnings_before = _material_health_score(mat)
    report["score_before"] = before
    bsdf = _ensure_material_has_principled(mat, settings)
    if bsdf is not None:
        profile = str(getattr(settings, "quality_profile", "BALANCED") or "BALANCED")
        rough = _clamp_float(_get_input_value(bsdf, "Roughness", getattr(settings, "roughness", 0.55)), 0.0, 1.0, 0.55)
        metal = _clamp_float(_get_input_value(bsdf, "Metallic", getattr(settings, "metallic", 0.0)), 0.0, 1.0, 0.0)
        if profile == "REALTIME":
            rough = max(0.18, min(0.92, rough)); metal = metal if metal > 0.08 else 0.0
        elif profile == "CINEMATIC":
            rough = max(0.03, min(0.98, rough))
        elif profile == "SUPREME":
            rough = max(0.04, min(0.96, rough)); metal = max(0.0, min(1.0, metal))
            try:
                mat.use_fake_user = True
            except Exception:
                pass
        elif profile == "ANIME_NPR":
            rough = max(0.45, min(0.85, rough)); metal = 0.0
        _set_input(bsdf, "Roughness", rough); _set_input(bsdf, "Metallic", metal)
        report["changed"] += 1 + _fix_principled_routing(mat, bsdf)
    if bool(getattr(settings, "auto_color_space_fix", True)):
        report["changed"] += _fix_texture_color_spaces(mat)
    try:
        mat.use_fake_user = bool(getattr(settings, "use_fake_user", True))
    except Exception:
        pass
    if bool(getattr(settings, "auto_layout_nodes", True)):
        report["changed"] += _layout_material_nodes(mat)
    try:
        mat["sss_material_studio_quality_profile"] = str(getattr(settings, "quality_profile", "BALANCED") or "BALANCED")
        mat["sss_material_studio_quality_checked"] = time.time()
    except Exception:
        pass
    after, warnings_after = _material_health_score(mat)
    report["score_after"] = after
    report["warnings"] = warnings_after or warnings_before
    return report


def _quality_target_materials(context, settings):
    scope = str(getattr(settings, "assignment_scope", "SELECTED") or "SELECTED").upper()
    mats = []
    seen = set()
    objects = _objects_for_scope(context, scope)
    for obj in objects:
        for mat in getattr(getattr(obj, "data", None), "materials", []) or []:
            if mat is not None and mat.name not in seen:
                mats.append(mat); seen.add(mat.name)
    if scope == "SCENE":
        for mat in getattr(bpy.data, "materials", []) or []:
            if mat is not None and mat.name not in seen:
                mats.append(mat); seen.add(mat.name)
    if not mats:
        mat = _active_material(context)
        if mat is not None:
            mats.append(mat)
    return mats


def _write_quality_report(context, settings, reports: list[dict]) -> str:
    lines = ["Shader Studio Quality Report", "=" * 72, f"Profile: {getattr(settings, 'quality_profile', 'BALANCED') if settings else 'BALANCED'}", f"Materials: {len(reports)}", ""]
    for item in reports:
        lines.append(f"{item.get('material', '-')}: {item.get('score_before', 0)} -> {item.get('score_after', 0)} / changed {item.get('changed', 0)}")
        for warning in item.get("warnings", [])[:10]:
            lines.append(f"  - {warning}")
    try:
        text = bpy.data.texts.get("SSS_Quality_Report") or bpy.data.texts.new("SSS_Quality_Report")
        text.clear(); text.write("\n".join(lines))
        return text.name
    except Exception:
        return ""



def _write_supreme_manifest(context, settings, reports: list[dict]) -> Path | None:
    try:
        export_dir = _manual_or_storage_dir(getattr(settings, "export_directory", ""), EXPORT_DIRNAME, create=True)
        path = export_dir / "shader_studio_supreme_manifest.json"
        data = {
            "tool": "Shader Studio",
            "version": ".".join(str(v) for v in ADDON_VERSION),
            "profile": str(getattr(settings, "quality_profile", "BALANCED") or "BALANCED"),
            "created": time.time(),
            "material_count": len(reports),
            "average_score_after": sum(float(item.get("score_after", 0) or 0) for item in reports) / max(1, len(reports)),
            "reports": reports,
        }
        _write_json(path, data)
        return path
    except Exception:
        return None


class SSS_OT_finish_production_material(Operator):
    bl_idname = 'sss.finish_production_material'
    bl_label = _ui('Finish Production Material', '制作マテリアル仕上げ')
    bl_description = _ui("Run the strongest Shader Studio finishing pass: strict material audit, quality upgrade, data color-space correction, readable node layout, fake-user protection, optional report, and exchange manifest generation.", "スマートシェーダーの最強仕上げ処理を実行します。厳密監査、品質強化、データ色空間補正、読みやすいノード整列、フェイクユーザー保護、任意レポート、受け渡しマニフェスト生成をまとめて行います。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context)
        if settings is None:
            return {"CANCELLED"}
        old_profile = str(getattr(settings, "quality_profile", "BALANCED") or "BALANCED")
        try:
            settings.quality_profile = "SUPREME"
        except Exception:
            pass
        mats = _quality_target_materials(context, settings)
        reports = [upgrade_material_quality(mat, settings) for mat in mats]
        for mat in mats:
            try:
                mat.use_fake_user = True
                mat["sss_material_studio_supreme_finished"] = time.time()
                mat["sss_material_studio_exchange_ready"] = True
            except Exception:
                pass
        report_name = _write_quality_report(context, settings, reports) if bool(getattr(settings, "generate_quality_report", True)) else ""
        manifest_path = _write_supreme_manifest(context, settings, reports)
        try:
            if old_profile and old_profile != "SUPREME":
                settings.quality_profile = old_profile
        except Exception:
            pass
        avg = sum(item.get("score_after", 0) for item in reports) / max(1, len(reports))
        msg = _context_ui(context, f"Supreme finished {len(reports)} material(s). Average health: {avg:.1f}.", f"{len(reports)}件の材質を最高精度で仕上げました。平均ヘルス: {avg:.1f}。")
        if report_name:
            msg += _context_ui(context, f" Report: {report_name}", f" レポート: {report_name}")
        if manifest_path:
            msg += _context_ui(context, f" Manifest: {manifest_path}", f" マニフェスト: {manifest_path}")
        _set_status(settings, msg)
        _safe_report(self, {"INFO"}, msg)
        return {"FINISHED"}


class SSS_OT_upgrade_material_quality(Operator):
    bl_idname = 'sss.upgrade_material_quality'
    bl_label = _ui('Upgrade Material Quality', 'マテリアル品質強化')
    bl_description = _ui("Analyze target materials, fix common PBR routing issues, normalize roughness/metallic ranges, correct data-map color spaces, add metadata, and optionally auto-layout node trees.", "対象材質を解析し、PBR配線のよくある問題、粗さ/金属度範囲、データマップ色空間、メタデータ、ノード整列をまとめて補正します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context)
        if settings is None:
            return {"CANCELLED"}
        mats = _quality_target_materials(context, settings)
        reports = [upgrade_material_quality(mat, settings) for mat in mats]
        report_name = _write_quality_report(context, settings, reports) if bool(getattr(settings, "generate_quality_report", True)) else ""
        avg = sum(item.get("score_after", 0) for item in reports) / max(1, len(reports))
        msg = _context_ui(context, f"Upgraded {len(reports)} material(s). Average health: {avg:.1f}.", f"{len(reports)}件の材質を品質強化しました。平均ヘルス: {avg:.1f}。")
        if report_name:
            msg += _context_ui(context, f" Report: {report_name}", f" レポート: {report_name}")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}


class SSS_OT_audit_material_quality(Operator):
    bl_idname = 'sss.audit_material_quality'
    bl_label = _ui('Audit Material Quality', 'マテリアル品質監査')
    bl_description = _ui("Create a health report without changing materials. It lists missing texture paths, missing Principled BSDF nodes, default-only channels, and dense node trees.", "材質を変更せずヘルスレポートを生成します。リンク切れ、Principled BSDF欠落、初期値のみのチャンネル、過密ノードを一覧化します。")
    bl_options = set()
    def execute(self, context):
        settings = _settings_owner(context)
        mats = _quality_target_materials(context, settings)
        reports = []
        for mat in mats:
            score, warnings = _material_health_score(mat)
            reports.append({"material": getattr(mat, "name", ""), "score_before": score, "score_after": score, "changed": 0, "warnings": warnings})
        report_name = _write_quality_report(context, settings, reports)
        msg = _context_ui(context, f"Audited {len(reports)} material(s). Report: {report_name}", f"{len(reports)}件の材質を監査しました。レポート: {report_name}")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}


class SSS_OT_layout_active_material_nodes(Operator):
    bl_idname = 'sss.layout_active_material_nodes'
    bl_label = _ui('Layout Active Material Nodes', 'アクティブマテリアルノード整列')
    bl_description = _ui("Rearrange the active material node tree into readable columns without changing shader values.", "シェーダー値を変更せず、アクティブ材質のノードツリーを読みやすい列配置へ整列します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context)
        mat = _active_material(context)
        if mat is None:
            msg = _context_ui(context, "No active material.", "アクティブ材質がありません。")
            _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        moved = _layout_material_nodes(mat)
        msg = _context_ui(context, f"Laid out {moved} node(s): {mat.name}", f"{moved}個のノードを整列しました: {mat.name}")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_create_procedural_material(Operator):
    bl_label = _ui('Create Material', 'マテリアル作成')
    bl_idname = 'sss.create_procedural_material'
    bl_description = _ui("Create a Blender-native procedural material inspired by DCC material libraries, PBR presets, weathering, fluid, wool, clay, skin, decal, and emission workflows.", "DCC材質ライブラリ、PBRプリセット、ウェザリング、流体、羊毛、粘土、肌、デカール、発光ワークフローを参考にしたBlenderネイティブ材質を生成します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context)
        if settings is None: return {"CANCELLED"}
        mat = build_procedural_material(settings.material_name or "Shader Studio Material", settings.material_preset, settings)
        if bool(getattr(settings, "auto_layout_nodes", True)): _layout_material_nodes(mat)
        assigned = _assign_material_to_objects(mat, _selected_mesh_objects(context), context=context) if settings.assign_to_selected else 0
        msg = _context_ui(context, "Created material: ", "材質を生成しました: ") + mat.name + (_context_ui(context, f" / assigned to {assigned} object(s).", f" / {assigned}個のオブジェクトへ割り当てました。") if assigned else "")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_create_npr_material(Operator):
    bl_label = _ui('Create NPR Material', 'NPRマテリアル作成')
    bl_idname = 'sss.create_npr_material'
    bl_description = _ui("Create a stylized shader inspired by toon, halftone, watercolor, comic, anime line-friendly workflows, and Blender shader-node NPR construction.", "トゥーン、ハーフトーン、水彩、コミック、anime line/Flair風の線画連携、BlenderノードNPR構築を参考にしたスタイライズ材質を生成します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context)
        if settings is None: return {"CANCELLED"}
        mat = build_npr_material(settings.material_name or "Smart NPR Material", settings.style_preset, settings)
        if bool(getattr(settings, "auto_layout_nodes", True)): _layout_material_nodes(mat)
        assigned = _assign_material_to_objects(mat, _selected_mesh_objects(context), context=context) if settings.assign_to_selected else 0
        msg = _context_ui(context, "Created NPR material: ", "NPR材質を生成しました: ") + mat.name + (_context_ui(context, f" / assigned to {assigned} object(s).", f" / {assigned}個のオブジェクトへ割り当てました。") if assigned else "")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_create_atomic_pattern(Operator):
    bl_label = _ui('Create Atomic Pattern', 'アトミックパターン作成')
    bl_idname = 'sss.create_atomic_pattern'
    bl_description = _ui("Create Substance Designer-like atomic node patterns such as noise, Voronoi, gradient map, emboss, and reaction-diffusion approximations as editable Blender shader networks.", "Substance Designer風のノイズ、ボロノイ、グラデーションマップ、エンボス、反応拡散近似を編集可能なBlenderシェーダーネットワークとして生成します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context)
        if settings is None: return {"CANCELLED"}
        mat = build_atomic_material(settings.material_name or "Smart Atomic Pattern", settings.atomic_preset, settings)
        if bool(getattr(settings, "auto_layout_nodes", True)): _layout_material_nodes(mat)
        assigned = _assign_material_to_objects(mat, _selected_mesh_objects(context), context=context) if settings.assign_to_selected else 0
        msg = _context_ui(context, "Created atomic material: ", "アトミック材質を生成しました: ") + mat.name + (_context_ui(context, f" / assigned to {assigned} object(s).", f" / {assigned}個のオブジェクトへ割り当てました。") if assigned else "")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_import_pbr_texture_set(Operator):
    bl_label = _ui('Import PBR Texture Set', 'PBRテクスチャセット取込')
    bl_idname = 'sss.import_pbr_texture_set'
    bl_description = _ui("Scan a folder for Base Color, Roughness, Metallic, Normal, Height, AO, Alpha, and Emission maps, then auto-route them into a managed Principled BSDF material.", "指定フォルダからベースカラー、粗さ、メタリック、法線、高さ、AO、アルファ、放射マップを検出し、Principled BSDF材質へ自動配線します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context)
        if settings is None: return {"CANCELLED"}
        folder_text = str(settings.texture_directory or "").strip()
        if not folder_text:
            msg = _context_ui(context, "Texture folder is not set.", "テクスチャフォルダが未設定です。"); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        folder = Path(bpy.path.abspath(folder_text)).expanduser()
        if not folder.exists():
            msg = _context_ui(context, "Texture folder does not exist: ", "テクスチャフォルダが存在しません: ") + str(folder); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        mat, channels = build_texture_set_material(settings.material_name or folder.name, folder, settings)
        assigned = _assign_material_to_objects(mat, _selected_mesh_objects(context), context=context) if settings.assign_to_selected else 0
        msg = _context_ui(context, "Imported PBR material: ", "PBR材質を取り込みました: ") + mat.name + " / " + ", ".join(sorted(channels.keys())) + (_context_ui(context, f" / assigned to {assigned} object(s).", f" / {assigned}個のオブジェクトへ割り当てました。") if assigned else "")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_create_photo_pbr_sampler(Operator):
    bl_label = _ui('Create Photo PBR Sampler', '写真PBRサンプラー作成')
    bl_idname = 'sss.create_photo_pbr_sampler'
    bl_description = _ui("Build a conservative Substance Sampler-like starter material from one photo, using the photo as base color and procedural detail for roughness and bump.", "1枚の写真からSubstance Sampler風のスターター材質を作成します。写真をベースカラーに使い、粗さとバンプを補完します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context)
        if settings is None: return {"CANCELLED"}
        path_text = str(settings.photo_source or "").strip()
        if not path_text:
            msg = _context_ui(context, "Photo source is not set.", "写真ソースが未設定です。"); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        path = Path(bpy.path.abspath(path_text)).expanduser()
        if not path.exists():
            msg = _context_ui(context, "Photo source does not exist: ", "写真ソースが存在しません: ") + str(path); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        mat = build_photo_sampler_material(settings.material_name or path.stem, path, settings)
        if bool(getattr(settings, "auto_layout_nodes", True)): _layout_material_nodes(mat)
        assigned = _assign_material_to_objects(mat, _selected_mesh_objects(context), context=context) if settings.assign_to_selected else 0
        export_dir = _manual_or_storage_dir(settings.export_directory, EXPORT_DIRNAME, create=True)
        manifest = export_dir / (_clean_name(mat.name) + "_sampler_manifest.json")
        _write_json(manifest, {"material": mat.name, "photo": str(path), "created": time.time(), "mode": "photo_to_pbr_sampler_approximation"})
        msg = _context_ui(context, "Created photo sampler material: ", "写真サンプラー材質を生成しました: ") + mat.name + (_context_ui(context, f" / assigned to {assigned} object(s).", f" / {assigned}個のオブジェクトへ割り当てました。") if assigned else "") + _context_ui(context, " / manifest: ", " / マニフェスト: ") + str(manifest)
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_apply_weathering(Operator):
    bl_label = _ui('Apply Weathering', '経年変化適用')
    bl_idname = 'sss.apply_weathering'
    bl_description = _ui("Add smart material layers for dirt, grunge, edge wear, micro damage, wetness, moss/puddle-style roughness change, and AO-like cavity darkening to the active material.", "アクティブ材質へ、汚れ、グランジ、エッジ摩耗、微細ダメージ、濡れ、苔・水たまり風の粗さ変化、AO風の溝暗化を追加します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context); mat = _active_material(context)
        if mat is None:
            msg = _context_ui(context, "No active material.", "アクティブ材質がありません。"); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        ok = apply_smart_weathering(mat, settings)
        if ok and bool(getattr(settings, "auto_layout_nodes", True)): _layout_material_nodes(mat)
        msg = (_context_ui(context, "Applied smart weathering to: ", "スマート経年変化を適用しました: ") + mat.name) if ok else _context_ui(context, "Failed to apply weathering.", "経年変化の適用に失敗しました。")
        _set_status(settings, msg); _safe_report(self, {"INFO" if ok else "WARNING"}, msg); return {"FINISHED" if ok else "CANCELLED"}

class SSS_OT_setup_npr_lines(Operator):
    bl_label = _ui('Setup NPR Lines', 'NPR線設定')
    bl_idname = 'sss.setup_npr_lines'
    bl_description = _ui("Enable Freestyle where available and optionally create selected-object outline shells, approximating Grease Pencil Line Art, anime line, and viewport NPR line workflows.", "利用可能な場合はFreestyleを有効化し、必要に応じて選択オブジェクトの輪郭シェルを作成します。グリースペンシル ラインアート、anime line、ビューポートNPR線画を近似します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context); scene = getattr(context, "scene", None); changed = 0
        try:
            scene.render.use_freestyle = True; changed += 1
            try: scene.view_layers[0].use_freestyle = True
            except Exception: pass
        except Exception: pass
        if bool(getattr(settings, "create_outline_shell", True)):
            outline_mat = build_procedural_material("SSS_NPR_Outline_Black", "PBR_UBER", settings)
            try: outline_mat.diffuse_color = (0, 0, 0, 1)
            except Exception: pass
            for obj in _selected_mesh_objects(context):
                try:
                    dup = obj.copy(); dup.data = obj.data.copy(); dup.name = "SSS_Outline_" + obj.name; context.collection.objects.link(dup); dup.matrix_world = obj.matrix_world.copy()
                    dup.data.materials.clear(); dup.data.materials.append(outline_mat)
                    mod = dup.modifiers.new("Shader Studio Outline", "SOLIDIFY"); mod.thickness = float(getattr(settings, "line_width", 0.02))
                    try: mod.use_flip_normals = True
                    except Exception: pass
                    try: dup.show_in_front = True
                    except Exception: pass
                    changed += 1
                except Exception: pass
        msg = _context_ui(context, f"NPR line setup updated ({changed} change(s)).", f"NPR線設定を更新しました（{changed}件）。")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_create_decal_plane(Operator):
    bl_label = _ui('Create Decal Plane', 'デカール平面作成')
    bl_idname = 'sss.create_decal_plane'
    bl_description = _ui("Create a non-destructive decal plane at the active object or cursor, assign a transparent decal material, and optionally use the photo source image as decal texture.", "アクティブオブジェクトまたはカーソル位置に非破壊デカール平面を作成し、透明デカール材質を割り当てます。写真ソース画像があればデカールテクスチャとして使用します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context); size = float(getattr(settings, "decal_size", 1.0)) if settings else 1.0
        try:
            loc = getattr(getattr(context, "object", None), "location", None) or context.scene.cursor.location
            half = size * 0.5
            mesh = bpy.data.meshes.new("SSS_Decal_Mesh")
            mesh.from_pydata([(-half, -half, 0.0), (half, -half, 0.0), (half, half, 0.0), (-half, half, 0.0)], [], [(0, 1, 2, 3)])
            mesh.update()
            plane = bpy.data.objects.new("SSS_Decal_Plane", mesh)
            plane.location = loc
            context.collection.objects.link(plane)
            try:
                for obj in getattr(context, "selected_objects", []) or []:
                    obj.select_set(False)
                plane.select_set(True)
                context.view_layer.objects.active = plane
            except Exception:
                pass
        except Exception:
            msg = _context_ui(context, "Could not create decal plane.", "デカール平面を作成できませんでした。"); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        mat = build_procedural_material(settings.material_name or "Smart Decal", "DECAL", settings)
        photo_raw = str(getattr(settings, "photo_source", "") or "").strip()
        photo = Path(bpy.path.abspath(photo_raw)).expanduser() if photo_raw else None
        if photo is not None and photo.exists() and photo.is_file():
            try:
                nt = mat.node_tree; nodes = nt.nodes; bsdf = next((n for n in nodes if getattr(n, "type", "") == "BSDF_PRINCIPLED"), None)
                tex = _new_node(nodes, "ShaderNodeTexImage", location=(-420, 260), label="Decal texture"); tex.image = _open_image(photo)
                _link(nt, _node_output(tex, "Color"), _node_input(bsdf, "Base Color")); _link(nt, _node_output(tex, "Alpha"), _node_input(bsdf, "Alpha"))
            except Exception: pass
        try: plane.data.materials.append(mat); plane.name = "SSS_Decal_" + _clean_name(mat.name, "Decal")
        except Exception: pass
        msg = _context_ui(context, "Created decal plane: ", "デカール平面を作成しました: ") + getattr(plane, "name", "")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_save_material_capsule(Operator):
    bl_label = _ui('Save Material Capsule', 'マテリアルカプセル保存')
    bl_idname = 'sss.save_material_capsule'
    bl_description = _ui("Save active material values, texture references, metadata, and exchange information as a local JSON material capsule. Empty library root uses Smart_Shader_Suite storage.", "アクティブ材質の値、テクスチャ参照、メタデータ、受け渡し情報をローカルJSON材質カプセルとして保存します。ライブラリ基点が空なら Smart_Shader_Suite 保存フォルダを使います。")
    bl_options = set()
    def execute(self, context):
        settings = _settings_owner(context); mat = _active_material(context)
        if mat is None:
            msg = _context_ui(context, "No active material to save.", "保存するアクティブ材質がありません。"); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        root = _manual_or_storage_dir(settings.library_root if settings else "", LIBRARY_DIRNAME, create=True)
        capsule = _summarize_principled(mat); capsule.update({"format": "Shader Studio Material Capsule", "version": ".".join(str(v) for v in ADDON_VERSION), "created": time.time()})
        path = root / (_clean_name(mat.name) + ".sss_material.json")
        if not _write_json(path, capsule):
            msg = _context_ui(context, "Failed to save material capsule.", "材質カプセルの保存に失敗しました。"); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        msg = _context_ui(context, "Saved material capsule: ", "材質カプセルを保存しました: ") + str(path)
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_restore_material_capsule(Operator):
    bl_label = _ui('Restore Material Capsule', 'マテリアルカプセル復元')
    bl_idname = 'sss.restore_material_capsule'
    bl_description = _ui("Restore the best matching material capsule found by the search field. Texture paths are relinked when the original images are still available.", "検索欄に最も一致する材質カプセルを復元します。元画像が利用可能な場合はテクスチャパスも再リンクします。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context); root = _manual_or_storage_dir(settings.library_root if settings else "", LIBRARY_DIRNAME, create=True); query = str(getattr(settings, "search_query", "") or "").strip().lower()
        files = list(root.rglob("*.sss_material.json")) if root.exists() else []
        if not files:
            msg = _context_ui(context, "No material capsules found.", "材質カプセルが見つかりません。"); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        def score(path):
            text = path.stem.lower(); return (query in text if query else True, -abs(len(text) - len(query)), text)
        path = sorted(files, key=score, reverse=True)[0]; capsule = _read_json(path)
        name = _clean_name(settings.material_name or capsule.get("name") or path.stem.replace(".sss_material", ""))
        mat = _make_material(name, settings, clear=True); nt, nodes, _links, out, bsdf = _create_basic_principled(mat, settings)
        inputs = capsule.get("inputs", {}) if isinstance(capsule.get("inputs"), dict) else {}
        for key, value in inputs.items():
            try: _set_input(bsdf, key, tuple(value) if isinstance(value, list) else value)
            except Exception: pass
        y = 180
        for tex_data in capsule.get("textures", []) or []:
            path_text = str(tex_data.get("path", "") if isinstance(tex_data, dict) else "")
            if not path_text: continue
            image_path = Path(bpy.path.abspath(path_text)).expanduser()
            if not image_path.exists() and settings and settings.relink_root:
                found = _find_by_basename(Path(bpy.path.abspath(settings.relink_root)).expanduser(), image_path.name, bool(settings.recursive_scan))
                if found: image_path = found
            if not image_path.exists(): continue
            tex = _new_node(nodes, "ShaderNodeTexImage", location=(-520, y), label=str(tex_data.get("node", "Capsule texture"))); tex.image = _open_image(image_path)
            if y == 180: _link(nt, _node_output(tex, "Color"), _node_input(bsdf, "Base Color"))
            y -= 240
        _mark_material_asset(mat, settings)
        if settings and settings.assign_to_selected: _assign_material_to_objects(mat, _selected_mesh_objects(context), context=context)
        msg = _context_ui(context, "Restored material capsule: ", "材質カプセルを復元しました: ") + str(path)
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_search_local_assets(Operator):
    bl_label = _ui('Search Local Assets', 'ローカルアセット検索')
    bl_idname = 'sss.search_local_assets'
    bl_description = _ui("Search Blender materials, saved capsules, texture files, and HDRI files from the local library root. This gives a Commander/Asset Browser style local search without internet dependency.", "Blender内材質、保存済みカプセル、テクスチャ、HDRIをローカルライブラリ基点から検索します。インターネットに依存しないCommander/アセットブラウザー風ローカル検索です。")
    bl_options = set()
    def execute(self, context):
        settings = _settings_owner(context); query = str(getattr(settings, "search_query", "") or "").strip().lower(); root = _manual_or_storage_dir(getattr(settings, "library_root", "") if settings else "", LIBRARY_DIRNAME, create=True)
        hits = []
        for mat in getattr(bpy.data, "materials", []) or []:
            text = getattr(mat, "name", "")
            if not query or query in text.lower(): hits.append("MAT:" + text)
        for file in _iter_files(root, recursive=bool(getattr(settings, "recursive_scan", True)), extensions=None):
            text = file.name.lower()
            if (not query or query in text) and (file.suffix.lower() in _IMAGE_EXTENSIONS or file.name.endswith(".sss_material.json") or file.suffix.lower() in {".json", ".mtlx", ".usd", ".usda"}): hits.append("FILE:" + file.name)
        limit = int(getattr(settings, "batch_limit", 200) or 0)
        if limit > 0: hits = hits[:limit]
        msg = _context_ui(context, f"Found {len(hits)} asset(s): ", f"{len(hits)}件のアセットを検出: ") + ", ".join(hits[:16]) + (" ..." if len(hits) > 16 else "")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_mark_materials_as_assets(Operator):
    bl_label = _ui('Mark Materials as Assets', 'マテリアルをアセット化')
    bl_idname = 'sss.mark_materials_as_assets'
    bl_description = _ui("Mark active, selected, or scene materials as Blender assets and add Shader Studio metadata when available.", "アクティブ、選択中、またはシーン内材質をBlenderアセットとしてマークし、利用可能な場合はスマートシェーダーのメタデータを追加します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context); mats = set(); scope = getattr(settings, "assignment_scope", "SELECTED") if settings else "SELECTED"
        if scope == "ACTIVE":
            mat = _active_material(context)
            if mat: mats.add(mat)
        else:
            for obj in _objects_for_scope(context, scope):
                try:
                    for slot in obj.material_slots:
                        if slot.material: mats.add(slot.material)
                except Exception: pass
        old_mark = getattr(settings, "mark_asset", True) if settings else True
        try: settings.mark_asset = True
        except Exception: pass
        for mat in mats: _mark_material_asset(mat, settings)
        try: settings.mark_asset = old_mark
        except Exception: pass
        msg = _context_ui(context, f"Marked {len(mats)} material(s) as assets.", f"{len(mats)}件の材質をアセット化しました。")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_relink_missing_assets(Operator):
    bl_label = _ui('Relink Missing Assets', '欠損アセット再リンク')
    bl_idname = 'sss.relink_missing_assets'
    bl_description = _ui("Repair missing image, HDRI, decal, and texture-node file paths by recursively searching the selected relink root by file name.", "指定した再リンク基点をファイル名で再帰検索し、リンク切れ画像、HDRI、デカール、テクスチャノードのパスを修復します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context); root_text = str(getattr(settings, "relink_root", "") or "").strip()
        if not root_text:
            msg = _context_ui(context, "Relink root is not set.", "再リンク基点が未設定です。"); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        root = Path(bpy.path.abspath(root_text)).expanduser()
        if not root.exists():
            msg = _context_ui(context, "Relink root does not exist: ", "再リンク基点が存在しません: ") + str(root); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        fixed = checked = 0
        for image in getattr(bpy.data, "images", []) or []:
            try:
                filepath = str(getattr(image, "filepath", "") or "")
                if not filepath: continue
                checked += 1
                if not _is_missing_path(filepath): continue
                found = _find_by_basename(root, bpy.path.basename(filepath), bool(getattr(settings, "recursive_scan", True)))
                if found: image.filepath = str(found); fixed += 1
            except Exception: pass
        msg = _context_ui(context, f"Relink checked {checked} image(s), repaired {fixed} path(s).", f"{checked}件の画像を確認し、{fixed}件のパスを修復しました。")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_cleanup_materials(Operator):
    bl_label = _ui('Cleanup Materials', 'マテリアルクリーンアップ')
    bl_idname = 'sss.cleanup_materials'
    bl_description = _ui("Remove unused materials, optional unused images, empty material slots, and optional .001 duplicate materials. This approximates Maya Optimize Scene Size, 3ds Max purge, and C4D unused material cleanup workflows.", "未使用材質、任意の未使用画像、空材質スロット、任意の.001重複材質を削除・統合します。Maya Optimize Scene Size、3ds Max purge、C4D未使用材質整理を近似します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context); removed_slots = removed_mats = removed_images = merged_dupes = kept_editing = 0
        if bool(getattr(settings, "cleanup_duplicates", False)):
            pattern = re.compile(r"^(.*)\.\d{3}$")
            for mat in list(getattr(bpy.data, "materials", []) or []):
                if core.is_cleanup_protected(mat): continue
                m = pattern.match(mat.name)
                if not m: continue
                base = bpy.data.materials.get(m.group(1))
                if base is None or base is mat: continue
                for obj in getattr(bpy.data, "objects", []) or []:
                    try:
                        for slot in obj.material_slots:
                            if slot.material is mat: slot.material = base; merged_dupes += 1
                    except Exception: pass
                try:
                    if mat.users == 0: bpy.data.materials.remove(mat); removed_mats += 1
                except Exception: pass
        if bool(getattr(settings, "cleanup_slots", True)):
            for obj in getattr(bpy.data, "objects", []) or []:
                try:
                    if getattr(obj, "type", None) != "MESH": continue
                    # While editing, the face data is in the edit mesh and mesh.polygons is stale,
                    # and Blender itself does not allow removing a slot then.
                    if obj.data.is_editmode: kept_editing += 1; continue
                    mesh = obj.data; used = {int(poly.material_index) for poly in getattr(mesh, "polygons", [])}; slots = mesh.materials
                    for idx in reversed(range(len(slots))):
                        if idx not in used:
                            # Blender shifts the polygon material indices itself on pop.
                            slots.pop(index=idx); removed_slots += 1
                except Exception: pass
        for mat in list(getattr(bpy.data, "materials", []) or []):
            try:
                if mat.users == 0 and not getattr(mat, "use_fake_user", False) and not core.is_cleanup_protected(mat): bpy.data.materials.remove(mat); removed_mats += 1
            except Exception: pass
        if bool(getattr(settings, "cleanup_images", False)):
            for image in list(getattr(bpy.data, "images", []) or []):
                try:
                    if image.users == 0 and not getattr(image, "use_fake_user", False) and not image.is_dirty and not core.is_cleanup_protected(image): bpy.data.images.remove(image); removed_images += 1
                except Exception: pass
        msg = _context_ui(context, f"Cleanup complete: {removed_mats} material(s), {removed_images} image(s), {removed_slots} slot(s), {merged_dupes} duplicate link(s).", f"クリーンアップ完了: 材質{removed_mats}件、画像{removed_images}件、スロット{removed_slots}件、重複リンク{merged_dupes}件。")
        if kept_editing: msg += _context_ui(context, f" Slots of {kept_editing} object(s) in Edit Mode were kept; leave Edit Mode to clean them.", f" 編集モード中の{kept_editing}個のオブジェクトのスロットは残しました。編集モードを抜けると整理できます。")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_select_by_material(Operator):
    bl_label = _ui('Select by Material', 'マテリアル逆引き選択')
    bl_idname = 'sss.select_by_material'
    bl_description = _ui("Select all scene objects using the active material, equivalent to Scene Materials reverse selection workflows in other DCCs.", "アクティブ材質を使用しているシーン内オブジェクトをすべて選択します。他DCCのScene Materials逆引き選択に相当します。")
    bl_options = set()
    def execute(self, context):
        settings = _settings_owner(context); mat = _active_material(context)
        if mat is None:
            msg = _context_ui(context, "No active material.", "アクティブ材質がありません。"); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        count = 0
        try:
            for obj in getattr(context, "selected_objects", []) or []:
                obj.select_set(False)
        except Exception: pass
        for obj in getattr(bpy.data, "objects", []) or []:
            try:
                if any(slot.material is mat for slot in obj.material_slots): obj.select_set(True); count += 1
            except Exception: pass
        msg = _context_ui(context, f"Selected {count} object(s) using material: ", f"材質を使用している{count}個のオブジェクトを選択しました: ") + mat.name
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_create_material_id_palette(Operator):
    bl_label = _ui('Create Material ID Palette', 'マテリアルIDパレット作成')
    bl_idname = 'sss.create_material_id_palette'
    bl_description = _ui("Create Multi/Sub-Object style material-ID slots on selected mesh objects. Existing polygon material indices are preserved unless more slots are needed.", "選択メッシュにマルチ／サブオブジェクト風のマテリアルIDスロットを作成します。必要なスロット追加のみ行い、既存面の材質インデックスは保持します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context); count = max(1, int(getattr(settings, "id_slot_count", 8) if settings else 8)); random.seed(int(getattr(settings, "random_seed", 1234) if settings else 1234))
        def id_material(idx):
            name = f"SSS_ID_{idx:02d}"; mat = bpy.data.materials.get(name)
            if mat is None:
                mat = bpy.data.materials.new(name)
                try: mat.diffuse_color = (random.random(), random.random(), random.random(), 1.0)
                except Exception: pass
            return mat
        objects = _selected_mesh_objects(context); added = 0
        for obj in objects:
            try:
                while len(obj.data.materials) < count: obj.data.materials.append(id_material(len(obj.data.materials))); added += 1
            except Exception: pass
        msg = _context_ui(context, f"Added {added} material-ID slots to {len(objects)} object(s).", f"{len(objects)}個のオブジェクトへ{added}個のマテリアルIDスロットを追加しました。")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_apply_assignment_rule(Operator):
    bl_label = _ui('Apply Assignment Rule', '割当ルール適用')
    bl_idname = 'sss.apply_assignment_rule'
    bl_description = _ui("Assign the active material to objects whose names match the plain text or regular expression rule. This approximates Houdini/Solaris rule-based material assignment in Blender.", "名前が通常テキストまたは正規表現ルールに一致するオブジェクトへアクティブ材質を割り当てます。Houdini/Solarisのルールベース材質割り当てをBlenderで近似します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context); mat = _active_material(context); rule = str(getattr(settings, "rule_expression", "") or "").strip()
        if mat is None or not rule:
            msg = _context_ui(context, "Active material or rule is missing.", "アクティブ材質またはルールが未設定です。"); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        regex = None
        if bool(getattr(settings, "use_regex_rules", False)):
            try: regex = re.compile(rule, re.IGNORECASE)
            except Exception as exc:
                msg = _context_ui(context, "Invalid regular expression: ", "正規表現が不正です: ") + str(rule); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        count = 0
        for obj in getattr(bpy.data, "objects", []) or []:
            try:
                if getattr(obj, "type", None) != "MESH": continue
                matched = bool(regex.search(obj.name)) if regex else _pattern_matcher(rule, False)(obj.name)
                if matched: count += _assign_material_to_objects(mat, [obj], context=context)
            except Exception: pass
        msg = _context_ui(context, f"Assigned active material to {count} object(s) by rule.", f"ルールにより{count}個のオブジェクトへアクティブ材質を割り当てました。")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_save_material_variant(Operator):
    bl_label = _ui('Save Material Variant', 'マテリアルバリアント保存')
    bl_idname = 'sss.save_material_variant'
    bl_description = _ui("Save a scene material state set: object names and their material slot assignments, approximating MaxFlow/C4D scene-state material variations.", "オブジェクト名と材質スロット割り当てをシーン材質ステートセットとして保存します。MaxFlow/C4Dのシーン状態・材質バリエーションを近似します。")
    bl_options = set()
    def execute(self, context):
        settings = _settings_owner(context); name = _clean_name(getattr(settings, "variant_name", "Default Look") if settings else "Default Look", "Default Look"); root = _storage_dir_with_legacy(storage.settings_dir, VARIANT_DIRNAME, create=True)
        data = {"name": name, "created": time.time(), "objects": {}}
        for obj in getattr(bpy.data, "objects", []) or []:
            try:
                if getattr(obj, "type", None) == "MESH": data["objects"][obj.name] = [slot.material.name if slot.material else "" for slot in obj.material_slots]
            except Exception: pass
        path = root / (name + ".json"); _write_json(path, data)
        msg = _context_ui(context, "Saved material variant: ", "材質バリアントを保存しました: ") + str(path)
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_apply_material_variant(Operator):
    bl_label = _ui('Apply Material Variant', 'マテリアルバリアント適用')
    bl_idname = 'sss.apply_material_variant'
    bl_description = _ui("Restore a previously saved material state set by name. Missing materials are skipped safely.", "名前で保存済み材質ステートセットを復元します。存在しない材質は安全にスキップします。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context); name = _clean_name(getattr(settings, "variant_name", "Default Look") if settings else "Default Look", "Default Look"); path = _storage_dir_with_legacy(storage.settings_dir, VARIANT_DIRNAME, create=True) / (name + ".json"); data = _read_json(path)
        if not data:
            msg = _context_ui(context, "Variant not found: ", "バリアントが見つかりません: ") + str(path); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        restored = 0; objects = data.get("objects", {}) if isinstance(data.get("objects"), dict) else {}
        for obj_name, mat_names in objects.items():
            obj = bpy.data.objects.get(obj_name)
            if obj is None or getattr(obj, "type", None) != "MESH": continue
            try:
                obj.data.materials.clear()
                for mat_name in mat_names:
                    mat = bpy.data.materials.get(str(mat_name or ""))
                    if mat is not None: obj.data.materials.append(mat)
                restored += 1
            except Exception: pass
        msg = _context_ui(context, f"Applied material variant to {restored} object(s).", f"材質バリアントを{restored}個のオブジェクトへ適用しました。")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_randomize_material_colors(Operator):
    bl_label = _ui('Randomize Material Colors', 'マテリアル色ランダム化')
    bl_idname = 'sss.randomize_material_colors'
    bl_description = _ui("Randomize material viewport/base colors for selected objects, similar to C4D random object color utilities.", "選択オブジェクトの材質ビューポート色・ベース色をランダム化します。C4Dのランダムオブジェクトカラー系ユーティリティを近似します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context); random.seed(int(getattr(settings, "random_seed", 1234) if settings else 1234)); changed = 0
        for obj in _objects_for_scope(context, getattr(settings, "assignment_scope", "SELECTED") if settings else "SELECTED"):
            for slot in getattr(obj, "material_slots", []) or []:
                mat = getattr(slot, "material", None)
                if mat is None: continue
                color = (random.random(), random.random(), random.random(), 1.0)
                try: mat.diffuse_color = color
                except Exception: pass
                try:
                    if mat.use_nodes and mat.node_tree:
                        for node in mat.node_tree.nodes:
                            if getattr(node, "type", "") == "BSDF_PRINCIPLED": _set_input(node, "Base Color", color); break
                except Exception: pass
                changed += 1
        msg = _context_ui(context, f"Randomized {changed} material color(s).", f"{changed}件の材質色をランダム化しました。")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_build_hdri_world(Operator):
    bl_label = _ui('Build HDRI World', 'HDRIワールド構築')
    bl_idname = 'sss.build_hdri_world'
    bl_description = _ui("Use the Photo Source image as an HDRI/environment texture and build a lookdev world with mapping rotation and strength controls.", "写真ソース画像をHDRI/環境テクスチャとして使い、回転と強度を制御できるルックデブワールドを構築します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context); path_text = str(getattr(settings, "photo_source", "") or "").strip()
        if not path_text:
            msg = _context_ui(context, "Photo source/HDRI path is not set.", "写真ソース/HDRIパスが未設定です。"); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        path = Path(bpy.path.abspath(path_text)).expanduser()
        if not path.exists():
            msg = _context_ui(context, "HDRI path does not exist: ", "HDRIパスが存在しません: ") + str(path); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        scene = getattr(context, "scene", None)
        if scene is None: return {"CANCELLED"}
        world = scene.world or bpy.data.worlds.new("Shader Studio World"); scene.world = world; world.use_nodes = True
        nt = world.node_tree; nodes = nt.nodes; nodes.clear()
        out = _new_node(nodes, "ShaderNodeOutputWorld", location=(560, 0), label="World Output"); bg = _new_node(nodes, "ShaderNodeBackground", location=(300, 0), label="HDRI Background")
        env = _new_node(nodes, "ShaderNodeTexEnvironment", location=(-260, 0), label="HDRI Texture"); mapping = _new_node(nodes, "ShaderNodeMapping", location=(-520, 0), label="HDRI Rotation"); texcoord = _new_node(nodes, "ShaderNodeTexCoord", location=(-760, 0), label="World Coordinates")
        try: env.image = _open_image(path)
        except Exception: pass
        _set_input(bg, "Strength", float(getattr(settings, "hdri_strength", 1.0) if settings else 1.0))
        try: _node_input(mapping, "Rotation").default_value[2] = math.radians(float(getattr(settings, "hdri_rotation", 0.0) if settings else 0.0))
        except Exception: pass
        _link(nt, _node_output(texcoord, "Generated", "Object"), _node_input(mapping, "Vector")); _link(nt, _node_output(mapping, "Vector"), _node_input(env, "Vector")); _link(nt, _node_output(env, "Color"), _node_input(bg, "Color")); _link(nt, _node_output(bg, "Background"), _node_input(out, "Surface"))
        msg = _context_ui(context, "Built HDRI world from: ", "HDRIワールドを構築しました: ") + str(path)
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_export_materialx_usd(Operator):
    bl_label = _ui('Export MaterialX/USD', 'MaterialX/USD書出し')
    bl_idname = 'sss.export_materialx_usd'
    bl_description = _ui("Export active material as a portable MaterialX Standard Surface and USD Preview Surface approximation with texture references and scalar values.", "アクティブ材質を、テクスチャ参照とスカラー値を含むMaterialX Standard SurfaceおよびUSD Preview Surface近似として書き出します。")
    bl_options = set()
    _sms_no_undo = True
    def execute(self, context):
        settings = _settings_owner(context); mat = _active_material(context)
        if mat is None:
            msg = _context_ui(context, "No active material to export.", "書き出すアクティブ材質がありません。"); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        export_dir = _manual_or_storage_dir(getattr(settings, "export_directory", "") if settings else "", EXPORT_DIRNAME, create=True); data = _summarize_principled(mat); name = _clean_name(mat.name); inputs = data.get("inputs", {})
        base = inputs.get("Base Color", [0.8, 0.8, 0.8, 1.0]); base = base if isinstance(base, (list, tuple)) else [0.8, 0.8, 0.8, 1.0]
        rough = inputs.get("Roughness", 0.5); metal = inputs.get("Metallic", 0.0); textures = data.get("textures", []) or []
        image_lines = []
        for idx, tex in enumerate(textures):
            path = _xml_escape(str(tex.get("path", ""))) if isinstance(tex, dict) else ""
            image_lines.append(f'  <image name="image_{idx}" type="color3" file="{path}" />')
        mtlx = ['<?xml version="1.0"?>', '<materialx version="1.38">', *image_lines, f'  <standard_surface name="{_xml_escape(name)}_surface" type="surfaceshader">', f'    <input name="base_color" type="color3" value="{float(base[0]):.6f}, {float(base[1]):.6f}, {float(base[2]):.6f}" />', f'    <input name="metalness" type="float" value="{float(metal):.6f}" />', f'    <input name="specular_roughness" type="float" value="{float(rough):.6f}" />', '  </standard_surface>', f'  <surfacematerial name="{_xml_escape(name)}" type="material">', f'    <input name="surfaceshader" type="surfaceshader" nodename="{_xml_escape(name)}_surface" />', '  </surfacematerial>', '</materialx>']
        safe_usd_name = re.sub(r"[^A-Za-z0-9_]", "_", name)
        usd = ['#usda 1.0', '(', f'    doc = "Shader Studio USD Preview Surface approximation for {safe_usd_name}"', ')', f'def Material "{safe_usd_name}"', '{', '    def Shader "PreviewSurface"', '    {', '        uniform token info:id = "UsdPreviewSurface"', f'        color3f inputs:diffuseColor = ({float(base[0]):.6f}, {float(base[1]):.6f}, {float(base[2]):.6f})', f'        float inputs:metallic = {float(metal):.6f}', f'        float inputs:roughness = {float(rough):.6f}', '        token outputs:surface', '    }', f'    token outputs:surface.connect = </{safe_usd_name}/PreviewSurface.outputs:surface>', '}']
        mtlx_path = export_dir / (name + ".mtlx"); usd_path = export_dir / (name + ".usda"); manifest_path = export_dir / (name + "_exchange_manifest.json")
        try:
            mtlx_path.write_text("\n".join(mtlx), encoding="utf-8"); usd_path.write_text("\n".join(usd), encoding="utf-8"); _write_json(manifest_path, {"material": data, "materialx": str(mtlx_path), "usd": str(usd_path), "created": time.time()})
        except Exception as exc:
            msg = _context_ui(context, "Export failed.", "書き出しに失敗しました。"); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        msg = _context_ui(context, "Exported MaterialX/USD: ", "MaterialX/USDを書き出しました: ") + str(export_dir)
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_add_aov_lpe_helpers(Operator):
    bl_label = _ui('Add AOV/LPE Helpers', 'AOV/LPE補助追加')
    bl_idname = 'sss.add_aov_lpe_helpers'
    bl_description = _ui("Create common view-layer AOV names and assign material/object pass indices for downstream compositing, approximating Houdini/Karma LPE and render-element planning.", "一般的なビューレイヤー AOV名を作成し、コンポジット用の材質・オブジェクトパス番号を割り当てます。Houdini/Karma LPEやレンダーエレメント設計を近似します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context); view_layer = getattr(context, "view_layer", None); names = ["sss_diffuse", "sss_specular", "sss_transmission", "sss_emission", "sss_material_id"]; added = 0
        try:
            existing = {aov.name for aov in view_layer.aovs}
            for name in names:
                if name not in existing:
                    aov = view_layer.aovs.add(); aov.name = name; added += 1
        except Exception: pass
        idx = 1
        for mat in getattr(bpy.data, "materials", []) or []:
            try: mat.pass_index = idx; idx += 1
            except Exception: pass
        for i, obj in enumerate(getattr(bpy.data, "objects", []) or [], start=1):
            try: obj.pass_index = i
            except Exception: pass
        msg = _context_ui(context, f"Added {added} AOV helper(s) and refreshed pass indices.", f"AOV補助を{added}件追加し、パス番号を更新しました。")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_resolve_dynamic_texture_paths(Operator):
    bl_label = _ui('Resolve Dynamic Texture Paths', '動的テクスチャパス解決')
    bl_idname = 'sss.resolve_dynamic_texture_paths'
    bl_description = _ui("Resolve texture path tokens such as $F and #### to the current frame when a matching file exists, approximating Solaris animated texture path workflows.", "$Fや####などのテクスチャパストークンを、該当ファイルがある場合に現在フレームへ解決します。Solaris風の連番テクスチャパス運用を近似します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context); frame = int(getattr(getattr(context, "scene", None), "frame_current", 1) or 1); resolved = 0
        for image in getattr(bpy.data, "images", []) or []:
            try:
                path = str(image.filepath or "")
                if "$F" not in path and "####" not in path: continue
                # $F4 is one padded token; replacing the bare $F first read it as $F + "4".
                candidate = re.sub(r"\$F(\d*)", lambda token: str(frame).zfill(int(token.group(1) or 0)), path).replace("####", f"{frame:04d}")
                full = Path(bpy.path.abspath(candidate)).expanduser()
                if full.exists(): image.filepath = str(full); resolved += 1
            except Exception: pass
        msg = _context_ui(context, f"Resolved {resolved} dynamic texture path(s).", f"動的テクスチャパスを{resolved}件解決しました。")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

class SSS_OT_generate_node_report(Operator):
    bl_label = _ui('Generate Node Report', 'ノードレポート生成')
    bl_idname = 'sss.generate_node_report'
    bl_description = _ui("Create a text-block report of active material nodes, links, image paths, missing files, and portable exchange hints. This replaces node preview/debug overview workflows.", "アクティブ材質のノード、リンク、画像パス、リンク切れ、ポータブル受け渡しヒントをテキストデータブロックとして生成します。ノードプレビュー/デバッグ概要ワークフローの代替です。")
    bl_options = set()
    _sms_no_undo = True
    def execute(self, context):
        settings = _settings_owner(context); mat = _active_material(context)
        if mat is None or getattr(mat, "node_tree", None) is None:
            msg = _context_ui(context, "No active node material.", "アクティブなノード材質がありません。"); _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        nt = mat.node_tree; lines = [f"Shader Studio Node Report: {mat.name}", "=" * 72, ""]
        for node in nt.nodes:
            lines.append(f"NODE {node.name} / {getattr(node, 'bl_idname', getattr(node, 'type', ''))}")
            if getattr(node, "type", "") == "TEX_IMAGE":
                image = getattr(node, "image", None); path = str(getattr(image, "filepath", "") or "") if image is not None else ""
                lines.append(f"  image={getattr(image, 'name', '') if image else ''}"); lines.append(f"  path={path}")
                if path and _is_missing_path(path): lines.append("  WARNING=missing file")
        lines.append(""); lines.append("LINKS")
        for link in nt.links:
            try: lines.append(f"  {link.from_node.name}.{link.from_socket.name} -> {link.to_node.name}.{link.to_socket.name}")
            except Exception: pass
        text_name = "SSS_Node_Report_" + _clean_name(mat.name); text = bpy.data.texts.get(text_name) or bpy.data.texts.new(text_name); text.clear(); text.write("\n".join(lines))
        msg = _context_ui(context, "Generated node report text block: ", "ノードレポートテキストを生成しました: ") + text.name
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}

# -----------------------------------------------------------------------------
# Smart Anime Line / NPR utility upgrade
# -----------------------------------------------------------------------------
_ANIME_EDGE_LABELS = {
    "outline": ("Outline", "アウトライン"),
    "open": ("Open edge", "開放エッジ"),
    "object": ("Object", "オブジェクト境界"),
    "intersection": ("Intersection", "交差線"),
    "smoothing_boundary": ("Smoothing boundary", "スムージング境界"),
    "material_boundary": ("Material boundary", "材質境界"),
    "selected": ("Selected edge", "選択エッジ"),
    "normal_angle": ("Normal angle", "法線角"),
    "wireframe": ("Wireframe", "ワイヤーフレーム"),
}


def _anime_bool(settings, name: str, default=False) -> bool:
    try:
        return bool(getattr(settings, name, default))
    except Exception:
        return bool(default)


def _anime_float(settings, name: str, default=0.0) -> float:
    try:
        return float(getattr(settings, name, default))
    except Exception:
        return float(default)


def _anime_color(settings, name: str, default=(0.0, 0.0, 0.0, 1.0)) -> tuple:
    try:
        value = getattr(settings, name, default)
        return tuple(float(v) for v in value[:4])
    except Exception:
        return tuple(default)


def _anime_target_objects(context, settings) -> list:
    mode = str(getattr(settings, "anime_target_scope", "SELECTED") or "SELECTED").upper()
    if mode == "MATERIAL":
        mat = _active_material(context)
        if mat is None:
            return []
        result = []
        try:
            for obj in bpy.data.objects:
                if getattr(obj, "type", None) != "MESH":
                    continue
                for slot in getattr(obj, "material_slots", []) or []:
                    if getattr(slot, "material", None) is mat:
                        result.append(obj)
                        break
        except Exception:
            return []
        return result
    return _objects_for_scope(context, mode)


def _anime_line_material(name: str, color, opacity: float, settings=None):
    mat = _make_material(name, settings, clear=True)
    rgba = tuple(color[:3]) + (max(0.0, min(1.0, float(opacity))),)
    try:
        mat.diffuse_color = rgba
    except Exception:
        pass
    nt = getattr(mat, "node_tree", None)
    if nt is not None:
        nodes = nt.nodes
        out = _new_node(nodes, "ShaderNodeOutputMaterial", location=(320, 0), label="Line Output")
        emission = _new_node(nodes, "ShaderNodeEmission", location=(60, 60), label="Anime line emission")
        transparent = _new_node(nodes, "ShaderNodeBsdfTransparent", location=(60, -120), label="Line alpha transparent")
        mix = _new_node(nodes, "ShaderNodeMixShader", location=(220, 0), label="Line opacity")
        try:
            _set_input(emission, "Color", rgba)
            _set_input(emission, "Strength", 1.0)
            _set_input(mix, "Fac", 1.0 - rgba[3])
            _link(nt, _node_output(transparent, "BSDF"), _node_input(mix, "Shader", "Shader_001"))
            _link(nt, _node_output(emission, "Emission"), _node_input(mix, "Shader", "Shader_002"))
            _link(nt, _node_output(mix, "Shader"), _node_input(out, "Surface"))
        except Exception:
            try:
                _link(nt, _node_output(emission, "Emission"), _node_input(out, "Surface"))
            except Exception:
                pass
    _set_material_blend(mat, rgba[3])
    try:
        mat["sss_anime_line_material"] = True
        mat["sss_anime_line_color"] = list(rgba)
    except Exception:
        pass
    return mat


def _anime_add_collection(name: str):
    base = _clean_name(name, "SSS_Anime_Line")
    collection = bpy.data.collections.get(base)
    if collection is not None:
        stamp = int(time.time())
        collection = bpy.data.collections.new(f"{base}_{stamp}")
    else:
        collection = bpy.data.collections.new(base)
    try:
        bpy.context.scene.collection.children.link(collection)
    except Exception:
        try:
            bpy.context.collection.children.link(collection)
        except Exception:
            pass
    return collection


def _anime_world_point(matrix, vec):
    try:
        return matrix @ vec
    except Exception:
        return vec


def _anime_offset_point(point, normal, offset: float, jitter: float, rng):
    p = point
    try:
        if normal is not None and offset:
            p = p + normal.normalized() * offset
    except Exception:
        pass
    if jitter > 0.0:
        try:
            p = p + normal.normalized() * ((rng.random() - 0.5) * jitter)
        except Exception:
            pass
    return p


def _anime_face_angle_degrees(face_a, face_b) -> float:
    try:
        return math.degrees(face_a.normal.angle(face_b.normal, 0.0))
    except Exception:
        return 0.0


def _anime_edge_to_faces(mesh) -> dict:
    edge_key_to_index = {}
    try:
        for edge in mesh.edges:
            edge_key_to_index[tuple(sorted(edge.vertices))] = edge.index
    except Exception:
        return {}
    edge_faces = {idx: [] for idx in edge_key_to_index.values()}
    try:
        for poly in mesh.polygons:
            for key in getattr(poly, "edge_keys", []) or []:
                idx = edge_key_to_index.get(tuple(sorted(key)))
                if idx is not None:
                    edge_faces.setdefault(idx, []).append(poly.index)
    except Exception:
        pass
    return edge_faces


def _anime_edge_types_for(mesh, edge, faces, settings) -> list:
    types = []
    try:
        polys = mesh.polygons
    except Exception:
        polys = []
    if _anime_bool(settings, "anime_edge_wireframe", False):
        types.append("wireframe")
    if len(faces) <= 1:
        if _anime_bool(settings, "anime_edge_open", True):
            types.append("open")
        if _anime_bool(settings, "anime_edge_object", True):
            types.append("object")
    if _anime_bool(settings, "anime_edge_selected", False):
        try:
            if bool(edge.select):
                types.append("selected")
        except Exception:
            pass
    if len(faces) >= 2:
        try:
            p0 = polys[faces[0]]; p1 = polys[faces[1]]
            if _anime_bool(settings, "anime_edge_material_boundary", True) and int(getattr(p0, "material_index", -1)) != int(getattr(p1, "material_index", -1)):
                types.append("material_boundary")
            if _anime_bool(settings, "anime_edge_smoothing_boundary", True) and bool(getattr(p0, "use_smooth", False)) != bool(getattr(p1, "use_smooth", False)):
                types.append("smoothing_boundary")
            try:
                if _anime_bool(settings, "anime_edge_smoothing_boundary", True) and bool(getattr(edge, "use_edge_sharp", False)):
                    types.append("smoothing_boundary")
            except Exception:
                pass
            if _anime_bool(settings, "anime_edge_normal_angle", True):
                angle = _anime_face_angle_degrees(p0, p1)
                if angle >= _anime_float(settings, "anime_normal_angle_threshold", 35.0):
                    types.append("normal_angle")
        except Exception:
            pass
    # De-duplicate while preserving semantic priority.
    result = []
    for item in types:
        if item not in result:
            result.append(item)
    return result


def _anime_material_override_for_edge(mesh, faces, settings):
    if not _anime_bool(settings, "anime_material_override_enabled", True):
        return None
    try:
        for idx in faces[:2]:
            mat_index = int(mesh.polygons[idx].material_index)
            # The evaluated mesh does not keep material slots. This function returns
            # metadata only; actual material lookup is handled by object data where possible.
            if mat_index >= 0:
                return mat_index
    except Exception:
        pass
    return None


def _anime_distance_factor(context, midpoint, settings) -> tuple[float, float]:
    if not _anime_bool(settings, "anime_reduction_enabled", True):
        return 1.0, 1.0
    scene = getattr(context, "scene", None)
    camera = getattr(scene, "camera", None) if scene is not None else None
    if camera is None:
        return 1.0, 1.0
    try:
        distance = (camera.matrix_world.translation - midpoint).length
    except Exception:
        try:
            distance = (camera.location - midpoint).length
        except Exception:
            return 1.0, 1.0
    start = _anime_float(settings, "anime_reduction_start", 5.0)
    end = max(start + 0.0001, _anime_float(settings, "anime_reduction_end", 50.0))
    t = max(0.0, min(1.0, (distance - start) / (end - start)))
    width = 1.0 + (_anime_float(settings, "anime_reduction_min_width", 0.35) - 1.0) * t
    alpha = 1.0 + (_anime_float(settings, "anime_reduction_min_alpha", 0.45) - 1.0) * t
    return max(0.0, width), max(0.0, alpha)


def _anime_collect_curve_segments(context, settings, targets: list) -> dict:
    rng = random.Random(int(getattr(settings, "random_seed", 1234) or 1234))
    edge_map = {key: [] for key in _ANIME_EDGE_LABELS.keys()}
    limit = int(getattr(settings, "batch_limit", 0) or 0)
    count = 0
    offset = _anime_float(settings, "anime_depth_offset", 0.001)
    jitter = _anime_float(settings, "anime_brush_jitter", 0.0) * max(0.0001, _anime_float(settings, "anime_curve_bevel_scale", 0.0008) * _anime_float(settings, "anime_brush_width", 6.0)) * 10.0
    depsgraph = None
    try:
        depsgraph = context.evaluated_depsgraph_get()
    except Exception:
        depsgraph = None
    for obj in targets:
        eval_obj = obj
        mesh = None
        try:
            eval_obj = obj.evaluated_get(depsgraph) if depsgraph is not None else obj
            mesh = eval_obj.to_mesh()
        except Exception:
            try:
                mesh = obj.data
            except Exception:
                mesh = None
        if mesh is None:
            continue
        matrix = getattr(eval_obj, "matrix_world", getattr(obj, "matrix_world", None))
        edge_faces = _anime_edge_to_faces(mesh)
        try:
            vertices = mesh.vertices
            polygons = mesh.polygons
            for edge in mesh.edges:
                if limit and count >= limit:
                    break
                faces = edge_faces.get(edge.index, [])
                edge_types = _anime_edge_types_for(mesh, edge, faces, settings)
                if not edge_types:
                    continue
                try:
                    p1 = _anime_world_point(matrix, vertices[edge.vertices[0]].co)
                    p2 = _anime_world_point(matrix, vertices[edge.vertices[1]].co)
                except Exception:
                    continue
                normal = None
                try:
                    if faces:
                        normal = polygons[faces[0]].normal.copy()
                        if len(faces) > 1:
                            normal = normal + polygons[faces[1]].normal
                        normal = matrix.to_3x3() @ normal
                except Exception:
                    normal = None
                p1 = _anime_offset_point(p1, normal, offset, jitter, rng)
                p2 = _anime_offset_point(p2, normal, offset, jitter, rng)
                try:
                    midpoint = (p1 + p2) * 0.5
                except Exception:
                    midpoint = p1
                width_factor, alpha_factor = _anime_distance_factor(context, midpoint, settings)
                material_index = _anime_material_override_for_edge(mesh, faces, settings)
                for edge_type in edge_types:
                    edge_map.setdefault(edge_type, []).append({
                        "object": getattr(obj, "name", ""),
                        "p1": (float(p1.x), float(p1.y), float(p1.z)),
                        "p2": (float(p2.x), float(p2.y), float(p2.z)),
                        "width_factor": width_factor,
                        "alpha_factor": alpha_factor,
                        "material_index": material_index,
                    })
                count += 1
        finally:
            try:
                if hasattr(eval_obj, "to_mesh_clear") and mesh is not getattr(obj, "data", None):
                    eval_obj.to_mesh_clear()
            except Exception:
                pass
    return {key: value for key, value in edge_map.items() if value}


def _anime_create_curve_object(collection, edge_type: str, segments: list, settings, *, hidden=False):
    if not segments:
        return None
    label_en, label_ja = _ANIME_EDGE_LABELS.get(edge_type, (edge_type, edge_type))
    name = _clean_name(f"SSS_AnimeLine_{getattr(settings, 'anime_line_set_id', 1)}_{label_en}")
    curve = bpy.data.curves.new(name, "CURVE")
    try:
        curve.dimensions = "3D"
        curve.resolution_u = 1
        curve.bevel_depth = max(0.000001, _anime_float(settings, "anime_brush_width", 6.0) * _anime_float(settings, "anime_curve_bevel_scale", 0.0008))
        curve.bevel_resolution = 1
        curve.use_path = False
    except Exception:
        pass
    for seg in segments:
        try:
            spl = curve.splines.new("POLY")
            spl.points.add(1)
            p1 = seg["p1"]; p2 = seg["p2"]
            spl.points[0].co = (p1[0], p1[1], p1[2], 1.0)
            spl.points[1].co = (p2[0], p2[1], p2[2], 1.0)
        except Exception:
            continue
    obj = bpy.data.objects.new(name, curve)
    try:
        collection.objects.link(obj)
    except Exception:
        try:
            bpy.context.collection.objects.link(obj)
        except Exception:
            pass
    color = _anime_color(settings, "anime_hidden_color" if hidden else "anime_brush_color", (0, 0, 0, 1))
    opacity = _anime_float(settings, "anime_hidden_opacity" if hidden else "anime_brush_opacity", 1.0)
    mat = _anime_line_material(name + "_Material", color, opacity, settings)
    try:
        obj.data.materials.append(mat)
    except Exception:
        pass
    try:
        obj.show_in_front = bool(hidden)
        obj["sss_anime_line_edge_type"] = edge_type
        obj["sss_anime_line_set_id"] = int(getattr(settings, "anime_line_set_id", 1) or 1)
        obj["sss_anime_line_set_name"] = str(getattr(settings, "anime_line_set_name", "Smart Anime Line Set") or "")
        obj["sss_anime_brush_angle"] = _anime_float(settings, "anime_brush_angle", 0.0)
        obj["sss_anime_brush_taper"] = _anime_float(settings, "anime_brush_taper", 0.25)
        obj["sss_anime_brush_random_width"] = _anime_float(settings, "anime_brush_random_width", 0.15)
        obj["sss_anime_hidden"] = bool(hidden)
        obj["sss_anime_segment_count"] = len(segments)
    except Exception:
        pass
    return obj


def _anime_set_attr(obj, attr: str, value) -> bool:
    try:
        if hasattr(obj, attr):
            setattr(obj, attr, value)
            return True
    except Exception:
        pass
    return False


def _anime_configure_line_style(linestyle, settings, *, hidden=False) -> None:
    if linestyle is None:
        return
    color = _anime_color(settings, "anime_hidden_color" if hidden else "anime_brush_color", (0, 0, 0, 1))
    width = _anime_float(settings, "anime_hidden_width" if hidden else "anime_brush_width", 6.0)
    opacity = _anime_float(settings, "anime_hidden_opacity" if hidden else "anime_brush_opacity", 1.0)
    for attr, value in (("color", color[:3]), ("alpha", opacity), ("thickness", width)):
        _anime_set_attr(linestyle, attr, value)
    # Freestyle APIs vary by Blender version. Set what exists and leave the rest as custom metadata.
    _anime_set_attr(linestyle, "thickness_position", "CENTER")
    _anime_set_attr(linestyle, "caps", "ROUND")
    try:
        linestyle["sss_anime_brush_angle"] = _anime_float(settings, "anime_brush_angle", 0.0)
        linestyle["sss_anime_brush_jitter"] = _anime_float(settings, "anime_brush_jitter", 0.0)
        linestyle["sss_anime_brush_taper"] = _anime_float(settings, "anime_brush_taper", 0.25)
        linestyle["sss_anime_brush_random_width"] = _anime_float(settings, "anime_brush_random_width", 0.15)
        linestyle["sss_anime_dash_enabled"] = _anime_bool(settings, "anime_brush_dash_enabled", True) and hidden
        linestyle["sss_anime_dash_length"] = _anime_float(settings, "anime_brush_dash_length", 14.0)
        linestyle["sss_anime_gap_length"] = _anime_float(settings, "anime_brush_gap_length", 8.0)
    except Exception:
        pass


def _anime_get_lineset(linesets, name: str):
    try:
        existing = linesets.get(name)
        if existing is not None:
            return existing
    except Exception:
        pass
    try:
        return linesets.new(name=name)
    except TypeError:
        try:
            return linesets.new(name)
        except Exception:
            return None
    except Exception:
        return None


def _anime_configure_freestyle(context, settings, targets: list) -> int:
    changed = 0
    scene = getattr(context, "scene", None)
    if scene is None:
        return 0
    try:
        scene.render.use_freestyle = True
        changed += 1
    except Exception:
        pass
    line_name = _clean_name(getattr(settings, "anime_line_set_name", "Smart Anime Line Set") or "Smart Anime Line Set")
    view_layers = []
    try:
        view_layers = list(scene.view_layers)
    except Exception:
        pass
    for view_layer in view_layers:
        try:
            view_layer.use_freestyle = True
        except Exception:
            pass
        fs = getattr(view_layer, "freestyle_settings", None)
        if fs is None:
            continue
        linesets = getattr(fs, "linesets", None)
        if linesets is None:
            continue
        for hidden in (False, True):
            if hidden and not _anime_bool(settings, "anime_hidden_lines", False):
                continue
            if (not hidden) and not _anime_bool(settings, "anime_visible_lines", True):
                continue
            ls = _anime_get_lineset(linesets, line_name + (" Hidden" if hidden else " Visible"))
            if ls is None:
                continue
            changed += 1
            try:
                ls.name = line_name + (" Hidden" if hidden else " Visible")
            except Exception:
                pass
            _anime_set_attr(ls, "select_by_edge_types", True)
            _anime_set_attr(ls, "visibility", "HIDDEN" if hidden else "VISIBLE")
            _anime_set_attr(ls, "qi_start", 1 if hidden else 0)
            _anime_set_attr(ls, "qi_end", 999 if hidden else 0)
            attr_map = {
                "select_silhouette": _anime_bool(settings, "anime_edge_outline", True),
                "select_border": _anime_bool(settings, "anime_edge_open", True) or _anime_bool(settings, "anime_edge_object", True),
                "select_crease": _anime_bool(settings, "anime_edge_normal_angle", True) or _anime_bool(settings, "anime_edge_smoothing_boundary", True),
                "select_material_boundary": _anime_bool(settings, "anime_edge_material_boundary", True),
                "select_edge_mark": _anime_bool(settings, "anime_edge_selected", False),
                "select_contour": _anime_bool(settings, "anime_edge_outline", True),
                "select_suggestive_contour": _anime_bool(settings, "anime_edge_object", True),
                "select_ridge_valley": _anime_bool(settings, "anime_edge_normal_angle", True),
            }
            for attr, value in attr_map.items():
                _anime_set_attr(ls, attr, bool(value))
            try:
                ls["sss_anime_line_set_id"] = int(getattr(settings, "anime_line_set_id", 1) or 1)
                ls["sss_anime_render_priority"] = int(getattr(settings, "anime_line_render_priority", 0) or 0)
                ls["sss_anime_intersection"] = _anime_bool(settings, "anime_edge_intersection", True)
                ls["sss_anime_wireframe"] = _anime_bool(settings, "anime_edge_wireframe", False)
            except Exception:
                pass
            _anime_configure_line_style(getattr(ls, "linestyle", None), settings, hidden=hidden)
    return changed


def _anime_create_outline_shells(context, settings, targets: list) -> int:
    if not _anime_bool(settings, "anime_edge_outline", True):
        return 0
    if not _anime_bool(settings, "create_outline_shell", True):
        return 0
    mat = _anime_line_material("SSS_Anime_Outline_Shell_Material", _anime_color(settings, "anime_brush_color", (0, 0, 0, 1)), _anime_float(settings, "anime_brush_opacity", 1.0), settings)
    created = 0
    thickness = max(0.000001, _anime_float(settings, "anime_brush_width", 6.0) * _anime_float(settings, "anime_curve_bevel_scale", 0.0008) * 8.0)
    for obj in targets:
        try:
            dup = obj.copy()
            dup.data = obj.data.copy()
            dup.name = "SSS_Anime_OutlineShell_" + obj.name
            context.collection.objects.link(dup)
            dup.matrix_world = obj.matrix_world.copy()
            dup.data.materials.clear()
            dup.data.materials.append(mat)
            mod = dup.modifiers.new("Smart Anime Line Outline Shell", "SOLIDIFY")
            mod.thickness = thickness
            try:
                mod.use_flip_normals = True
            except Exception:
                pass
            try:
                dup.show_in_front = True
            except Exception:
                pass
            dup["sss_anime_outline_shell"] = True
            dup["sss_anime_line_set_id"] = int(getattr(settings, "anime_line_set_id", 1) or 1)
            created += 1
        except Exception:
            continue
    return created


def _anime_create_curve_lines(context, settings, targets: list) -> tuple[int, dict]:
    edge_segments = _anime_collect_curve_segments(context, settings, targets)
    if not edge_segments:
        return 0, {}
    collection = _anime_add_collection(f"SSS_AnimeLine_{getattr(settings, 'anime_line_set_id', 1)}_{getattr(settings, 'anime_line_set_name', 'LineSet')}")
    created = 0
    for edge_type, segments in edge_segments.items():
        obj = _anime_create_curve_object(collection, edge_type, segments, settings, hidden=False)
        if obj is not None:
            created += 1
    if _anime_bool(settings, "anime_hidden_lines", False):
        # Hidden-line objects are metadata-only editable duplicates. Depth-aware hidden lines are handled by Freestyle.
        for edge_type, segments in edge_segments.items():
            if edge_type not in {"open", "material_boundary", "normal_angle", "wireframe"}:
                continue
            obj = _anime_create_curve_object(collection, "hidden_" + edge_type, segments, settings, hidden=True)
            if obj is not None:
                created += 1
    try:
        collection["sss_anime_line_manifest"] = json.dumps(_anime_line_manifest(settings, targets, edge_segments), ensure_ascii=False)
    except Exception:
        pass
    return created, edge_segments


def _anime_line_manifest(settings, targets: list, edge_segments: dict | None = None) -> dict:
    edge_segments = edge_segments or {}
    return {
        "format": "Shader Studio Anime Line Preset",
        "version": ".".join(str(v) for v in ADDON_VERSION),
        "created": time.time(),
        "line_set": {
            "name": str(getattr(settings, "anime_line_set_name", "Smart Anime Line Set") or ""),
            "id": int(getattr(settings, "anime_line_set_id", 1) or 1),
            "render_priority": int(getattr(settings, "anime_line_render_priority", 0) or 0),
            "mode": str(getattr(settings, "anime_line_mode", "BALANCED") or "BALANCED"),
            "output_mode": str(getattr(settings, "anime_line_output_mode", "BOTH") or "BOTH"),
            "brush_instance": str(getattr(settings, "anime_brush_instance_name", "Main Brush") or "Main Brush"),
            "reduction_instance": str(getattr(settings, "anime_reduction_instance_name", "Camera Distance") or "Camera Distance"),
            "line_size_map": str(getattr(settings, "anime_line_size_map", "") or ""),
            "merge_groups": _anime_bool(settings, "anime_merge_groups", True),
            "self_intersection": _anime_bool(settings, "anime_self_intersection", True),
            "viewport_preview": _anime_bool(settings, "anime_viewport_preview", True),
            "attribute_override": _anime_bool(settings, "anime_attribute_override_enabled", True),
        },
        "targets": [getattr(obj, "name", "") for obj in targets],
        "categories": {
            "visible_lines": _anime_bool(settings, "anime_visible_lines", True),
            "hidden_lines": _anime_bool(settings, "anime_hidden_lines", False),
            "outline": _anime_bool(settings, "anime_edge_outline", True),
            "open_edge": _anime_bool(settings, "anime_edge_open", True),
            "object": _anime_bool(settings, "anime_edge_object", True),
            "intersection": _anime_bool(settings, "anime_edge_intersection", True),
            "smoothing_boundary": _anime_bool(settings, "anime_edge_smoothing_boundary", True),
            "material_boundary": _anime_bool(settings, "anime_edge_material_boundary", True),
            "selected_edge": _anime_bool(settings, "anime_edge_selected", False),
            "normal_angle": _anime_bool(settings, "anime_edge_normal_angle", True),
            "wireframe": _anime_bool(settings, "anime_edge_wireframe", False),
            "self_intersection": _anime_bool(settings, "anime_self_intersection", True),
        },
        "brush": {
            "visible_width_px": _anime_float(settings, "anime_brush_width", 6.0),
            "hidden_width_px": _anime_float(settings, "anime_hidden_width", 3.0),
            "visible_color": list(_anime_color(settings, "anime_brush_color", (0, 0, 0, 1))),
            "hidden_color": list(_anime_color(settings, "anime_hidden_color", (0, 0, 0, 0.35))),
            "visible_opacity": _anime_float(settings, "anime_brush_opacity", 1.0),
            "hidden_opacity": _anime_float(settings, "anime_hidden_opacity", 0.35),
            "angle": _anime_float(settings, "anime_brush_angle", 0.0),
            "jitter": _anime_float(settings, "anime_brush_jitter", 0.0),
            "taper": _anime_float(settings, "anime_brush_taper", 0.25),
            "random_width": _anime_float(settings, "anime_brush_random_width", 0.15),
            "dash_enabled": _anime_bool(settings, "anime_brush_dash_enabled", True),
            "dash_length": _anime_float(settings, "anime_brush_dash_length", 14.0),
            "gap_length": _anime_float(settings, "anime_brush_gap_length", 8.0),
        },
        "reduction": {
            "enabled": _anime_bool(settings, "anime_reduction_enabled", True),
            "start": _anime_float(settings, "anime_reduction_start", 5.0),
            "end": _anime_float(settings, "anime_reduction_end", 50.0),
            "min_width": _anime_float(settings, "anime_reduction_min_width", 0.35),
            "min_alpha": _anime_float(settings, "anime_reduction_min_alpha", 0.45),
        },
        "render_elements": {
            "visible": _anime_bool(settings, "anime_render_visible_element", True),
            "hidden": _anime_bool(settings, "anime_render_hidden_element", True),
            "edge_elements": _anime_bool(settings, "anime_render_edge_elements", True),
            "background_enabled": _anime_bool(settings, "anime_render_background_enabled", False),
            "background_color": list(_anime_color(settings, "anime_render_background_color", (1, 1, 1, 1))),
        },
        "edge_counts": {key: len(value) for key, value in edge_segments.items()},
    }


def _anime_write_svg(path: Path, settings, edge_segments: dict) -> bool:
    # Lightweight orthographic XY projection for line review / handoff. The 3D curves remain the authoritative editable output.
    try:
        all_points = []
        for segments in edge_segments.values():
            for seg in segments:
                all_points.extend([seg["p1"], seg["p2"]])
        if not all_points:
            return False
        min_x = min(p[0] for p in all_points); max_x = max(p[0] for p in all_points)
        min_y = min(p[1] for p in all_points); max_y = max(p[1] for p in all_points)
        width = max(1.0, max_x - min_x); height = max(1.0, max_y - min_y)
        scale = 900.0 / max(width, height)
        color = _anime_color(settings, "anime_brush_color", (0, 0, 0, 1))
        stroke = f"rgb({int(color[0]*255)},{int(color[1]*255)},{int(color[2]*255)})"
        bg = _anime_color(settings, "anime_render_background_color", (1, 1, 1, 1))
        lines = ["<?xml version=\"1.0\" encoding=\"UTF-8\"?>", f"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"960\" height=\"960\" viewBox=\"0 0 960 960\">"]
        if _anime_bool(settings, "anime_render_background_enabled", False):
            lines.append(f"<rect x=\"0\" y=\"0\" width=\"960\" height=\"960\" fill=\"rgb({int(bg[0]*255)},{int(bg[1]*255)},{int(bg[2]*255)})\"/>")
        for edge_type, segments in edge_segments.items():
            label = _ANIME_EDGE_LABELS.get(edge_type, (edge_type, edge_type))[0]
            lines.append(f"<g id=\"{_xml_escape(str(label))}\" data-edge-type=\"{_xml_escape(str(edge_type))}\">")
            for seg in segments:
                x1 = (seg["p1"][0] - min_x) * scale + 30.0
                y1 = 930.0 - ((seg["p1"][1] - min_y) * scale + 30.0)
                x2 = (seg["p2"][0] - min_x) * scale + 30.0
                y2 = 930.0 - ((seg["p2"][1] - min_y) * scale + 30.0)
                sw = max(0.1, _anime_float(settings, "anime_brush_width", 6.0) * float(seg.get("width_factor", 1.0)))
                alpha = max(0.0, min(1.0, _anime_float(settings, "anime_brush_opacity", 1.0) * float(seg.get("alpha_factor", 1.0))))
                dash = ""
                if _anime_bool(settings, "anime_brush_dash_enabled", True) and edge_type.startswith("hidden"):
                    dash = f" stroke-dasharray=\"{_anime_float(settings, 'anime_brush_dash_length', 14.0)} {_anime_float(settings, 'anime_brush_gap_length', 8.0)}\""
                lines.append(f"<line x1=\"{x1:.3f}\" y1=\"{y1:.3f}\" x2=\"{x2:.3f}\" y2=\"{y2:.3f}\" stroke=\"{stroke}\" stroke-opacity=\"{alpha:.3f}\" stroke-width=\"{sw:.3f}\" stroke-linecap=\"round\"{dash}/>")
            lines.append("</g>")
        lines.append("</svg>")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("\n".join(lines), encoding="utf-8")
        return True
    except Exception:
        return False


def _anime_write_eps(path: Path, settings, edge_segments: dict) -> bool:
    try:
        all_points = []
        for segments in edge_segments.values():
            for seg in segments:
                all_points.extend([seg["p1"], seg["p2"]])
        if not all_points:
            return False
        min_x = min(p[0] for p in all_points); max_x = max(p[0] for p in all_points)
        min_y = min(p[1] for p in all_points); max_y = max(p[1] for p in all_points)
        width = max(1.0, max_x - min_x); height = max(1.0, max_y - min_y)
        scale = 540.0 / max(width, height)
        color = _anime_color(settings, "anime_brush_color", (0, 0, 0, 1))
        lines = ["%!PS-Adobe-3.0 EPSF-3.0", "%%BoundingBox: 0 0 600 600", "%%Creator: Shader Studio Anime Line", "%%EndComments", f"{color[0]:.4f} {color[1]:.4f} {color[2]:.4f} setrgbcolor", "1 setlinejoin 1 setlinecap"]
        for edge_type, segments in edge_segments.items():
            lines.append(f"% Edge: {edge_type}")
            for seg in segments:
                x1 = (seg["p1"][0] - min_x) * scale + 30.0
                y1 = (seg["p1"][1] - min_y) * scale + 30.0
                x2 = (seg["p2"][0] - min_x) * scale + 30.0
                y2 = (seg["p2"][1] - min_y) * scale + 30.0
                sw = max(0.1, _anime_float(settings, "anime_brush_width", 6.0) * float(seg.get("width_factor", 1.0)))
                lines.append(f"{sw:.4f} setlinewidth newpath {x1:.4f} {y1:.4f} moveto {x2:.4f} {y2:.4f} lineto stroke")
        lines.append("showpage")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("\n".join(lines), encoding="utf-8")
        return True
    except Exception:
        return False


def build_anime_cel_material(name: str, settings=None):
    mat = _make_material(name, settings, clear=True)
    nt = mat.node_tree
    nodes = nt.nodes
    out = _new_node(nodes, "ShaderNodeOutputMaterial", location=(760, 0), label="Anime Output")
    bsdf = _new_node(nodes, "ShaderNodeBsdfPrincipled", location=(500, 0), label="Smart Anime Cel Shader")
    _link(nt, _node_output(bsdf, "BSDF"), _node_input(out, "Surface"))
    base = _anime_color(settings, "anime_shader_base_color", (0.82, 0.58, 0.42, 1.0))
    shadow = _anime_color(settings, "anime_shader_shadow_color", (0.32, 0.22, 0.20, 1.0))
    highlight = _anime_color(settings, "anime_shader_highlight_color", (1.0, 0.9, 0.72, 1.0))
    rim = _anime_color(settings, "anime_shader_rim_color", (0.1, 0.16, 0.28, 1.0))
    layer = _new_node(nodes, "ShaderNodeLayerWeight", location=(-760, 160), label="View-facing tone driver")
    noise = _new_node(nodes, "ShaderNodeTexNoise", location=(-760, -80), label="Paper / hatch breakup")
    wave = _new_node(nodes, "ShaderNodeTexWave", location=(-760, -320), label="Manga hatch bands")
    ramp = _new_node(nodes, "ShaderNodeValToRGB", location=(-480, 140), label="Cel zones")
    hatch_ramp = _new_node(nodes, "ShaderNodeValToRGB", location=(-480, -300), label="Hatch mask")
    mix_hatch = _new_node(nodes, "ShaderNodeMixRGB", location=(-160, -80), label="Hatch over cel")
    mix_rim = _new_node(nodes, "ShaderNodeMixRGB", location=(120, 60), label="Rim / highlight mix")
    bump = _new_node(nodes, "ShaderNodeBump", location=(160, -260), label="Paint surface bump")
    z1 = sorted([_anime_float(settings, "anime_shader_zone1", 0.38), _anime_float(settings, "anime_shader_zone2", 0.62), _anime_float(settings, "anime_shader_zone3", 0.84)])
    _configure_color_ramp(ramp, [(0.0, shadow), (z1[0], shadow), (z1[0] + 0.001, base), (z1[1], base), (z1[1] + 0.001, highlight), (1.0, highlight)])
    _configure_color_ramp(hatch_ramp, [(0.0, (0.0, 0.0, 0.0, 1)), (max(0.01, z1[0]), (0.0, 0.0, 0.0, 1)), (min(0.99, z1[0] + 0.02), (1.0, 1.0, 1.0, 1)), (1.0, (1.0, 1.0, 1.0, 1))])
    _set_input(noise, "Scale", 80.0); _set_input(noise, "Detail", 12.0); _set_input(noise, "Roughness", 0.62)
    _set_input(wave, "Scale", 32.0); _set_input(wave, "Distortion", 4.0)
    _link(nt, _node_output(layer, "Facing"), _node_input(ramp, "Fac"))
    _link(nt, _node_output(wave, "Color", "Fac"), _node_input(hatch_ramp, "Fac"))
    _link(nt, _node_output(ramp, "Color"), _node_input(mix_hatch, "Color1", "A"))
    _link(nt, _node_output(hatch_ramp, "Color"), _node_input(mix_hatch, "Color2", "B"))
    _set_input(mix_hatch, "Fac", _anime_float(settings, "anime_shader_hatching_strength", 0.20))
    try:
        mix_hatch.blend_type = "MULTIPLY"
    except Exception:
        pass
    _link(nt, _node_output(mix_hatch, "Color", "Result"), _node_input(mix_rim, "Color1", "A"))
    try:
        _node_input(mix_rim, "Color2", "B").default_value = rim
    except Exception:
        pass
    _set_input(mix_rim, "Fac", min(1.0, _anime_float(settings, "anime_shader_rim_strength", 0.35)))
    _link(nt, _node_output(mix_rim, "Color", "Result"), _node_input(bsdf, "Base Color"))
    _set_input(bsdf, "Roughness", 0.88)
    _set_input(bsdf, "Metallic", 0.0)
    _set_input(bsdf, "Emission Color", highlight)
    _set_input(bsdf, "Emission Strength", _anime_float(settings, "anime_shader_highlight_strength", 0.45) * 0.15)
    _set_input(bump, "Strength", min(1.0, _anime_float(settings, "normal_strength", 0.18)))
    _set_input(bump, "Distance", max(0.0, _anime_float(settings, "height_strength", 0.05)))
    _link(nt, _node_output(noise, "Fac"), _node_input(bump, "Height"))
    _link(nt, _node_output(bump, "Normal"), _node_input(bsdf, "Normal"))
    try:
        mat["sss_anime_cel_shader"] = True
        mat["sss_anime_shader_version"] = ".".join(str(v) for v in ADDON_VERSION)
        mat["sss_anime_shader_zones"] = list(z1)
    except Exception:
        pass
    _mark_material_asset(mat, settings)
    return mat


class SSS_OT_create_anime_cel_shader(Operator):
    bl_idname = 'sss.create_anime_cel_shader'
    bl_label = _ui('Create Anime Cel Shader', 'アニメセルシェーダー作成')
    bl_description = _ui("Create an editable Blender-native cel/NPR shader with stepped zones, stylized highlights, rim contribution, hatch masking, paper noise, and line metadata for NPR utility workflows.", "階調ゾーン、手描き風ハイライト、リム寄与、ハッチマスク、紙ノイズ、NPRユーティリティライン連携メタデータを持つ編集可能なBlenderネイティブのセル/NPRシェーダーを生成します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context)
        if settings is None:
            return {"CANCELLED"}
        name = settings.material_name or "Smart Anime Cel Shader"
        mat = build_anime_cel_material(name, settings)
        assigned = _assign_material_to_objects(mat, _selected_mesh_objects(context), context=context) if settings.assign_to_selected else 0
        msg = _context_ui(context, "Created advanced anime shader: ", "高精度アニメシェーダーを生成しました: ") + mat.name
        if assigned:
            msg += _context_ui(context, f" / assigned to {assigned} object(s).", f" / {assigned}個のオブジェクトへ割り当てました。")
        _set_status(settings, msg)
        _safe_report(self, {"INFO"}, msg)
        return {"FINISHED"}


class SSS_OT_apply_material_line_functions(Operator):
    bl_idname = 'sss.apply_material_line_functions'
    bl_label = _ui('Apply Material Line Functions', 'マテリアル別ライン機能適用')
    bl_description = _ui("Store NPR material line-function metadata on the active material: line color replacement, intersection suppression, hidden-as-visible, and hidden-target masking.", "アクティブ材質へ、線色置換、交差線抑制、陰線の可視線化、陰線ターゲットマスクなどのNPRユーティリティ材質別ライン機能メタデータを保存します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context)
        mat = _active_material(context)
        if mat is None:
            msg = _context_ui(context, "No active material.", "アクティブ材質がありません。")
            _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        try:
            mat["sss_anime_line_functions"] = True
            mat["sss_anime_replace_line_color"] = _anime_bool(settings, "anime_material_replace_color", False)
            mat["sss_anime_line_color"] = list(_anime_color(settings, "anime_brush_color", (0, 0, 0, 1)))
            mat["sss_anime_disable_intersection"] = _anime_bool(settings, "anime_material_disable_intersection", False)
            mat["sss_anime_hidden_as_visible"] = _anime_bool(settings, "anime_material_hidden_as_visible", False)
            mat["sss_anime_mask_hidden_targets"] = _anime_bool(settings, "anime_material_mask_hidden_targets", False)
            mat["sss_anime_line_set_id"] = int(getattr(settings, "anime_line_set_id", 1) or 1)
        except Exception:
            msg = _context_ui(context, "Failed to write material line metadata.", "材質ラインメタデータの書き込みに失敗しました。")
            _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        msg = _context_ui(context, "Applied material line functions to: ", "材質別ライン機能を適用しました: ") + mat.name
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}


class SSS_OT_apply_attribute_override(Operator):
    bl_idname = 'sss.apply_attribute_override'
    bl_label = _ui('Apply Attribute Override', '属性オーバーライド適用')
    bl_description = _ui("Store current anime line settings on the scene and active view layer as shot-level override metadata, then refresh Freestyle settings when possible.", "現在のアニメ線画設定をシーンとアクティブビューレイヤーへショット単位の上書きメタデータとして保存し、可能な場合はFreestyle設定を更新します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context)
        if settings is None:
            return {"CANCELLED"}
        targets = _anime_target_objects(context, settings)
        manifest = _anime_line_manifest(settings, targets, {})
        payload = json.dumps(manifest, ensure_ascii=False)
        written = 0
        try:
            context.scene["sss_anime_attribute_override"] = payload
            written += 1
        except Exception:
            pass
        try:
            context.view_layer["sss_anime_attribute_override"] = payload
            written += 1
        except Exception:
            pass
        refreshed = _anime_configure_freestyle(context, settings, targets) if _anime_bool(settings, "anime_attribute_override_enabled", True) else 0
        msg = _context_ui(context, f"Applied anime attribute override to {written} owner(s), refreshed {refreshed} Freestyle line set(s).", f"アニメ属性オーバーライドを{written}件へ適用し、Freestyleラインセットを{refreshed}件更新しました。")
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}


class SSS_OT_export_viewport_line_preview(Operator):
    bl_idname = 'sss.export_viewport_line_preview'
    bl_label = _ui('Export Viewport Line Preview', 'ビューポート線画プレビュー書出し')
    bl_description = _ui("Write an OpenGL viewport preview image using the current line setup. The file is saved to the manual export folder or Smart_Shader_Suite storage.", "現在のライン設定を使ってOpenGLビューポートプレビュー画像を書き出します。ファイルは手動書き出し先または Smart_Shader_Suite 保存フォルダへ保存します。")
    bl_options = set()
    _sms_no_undo = True
    def execute(self, context):
        settings = _settings_owner(context)
        if settings is None:
            return {"CANCELLED"}
        export_dir = _manual_or_storage_dir(getattr(settings, "export_directory", ""), EXPORT_DIRNAME, create=True)
        path = export_dir / (_clean_name(getattr(settings, "anime_line_set_name", "Smart Anime Line Set")) + "_viewport_preview.png")
        old_path = None
        try:
            old_path = context.scene.render.filepath
            context.scene.render.filepath = str(path)
            bpy.ops.render.opengl(write_still=True, view_context=True)
        except Exception as exc:
            try:
                if old_path is not None:
                    context.scene.render.filepath = old_path
            except Exception:
                pass
            msg = _context_ui(context, "Viewport preview render failed.", "ビューポートプレビュー書き出しに失敗しました。")
            _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        try:
            if old_path is not None:
                context.scene.render.filepath = old_path
        except Exception:
            pass
        msg = _context_ui(context, "Viewport line preview saved: ", "ビューポート線画プレビューを保存しました: ") + str(path)
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}


class SSS_OT_build_anime_line_set(Operator):
    bl_idname = 'sss.build_anime_line_set'
    bl_label = _ui('Build Anime Line Set', 'アニメラインセット構築')
    bl_description = _ui("Build NPR line settings: Freestyle visible/hidden line sets, editable curve strokes for supported edge categories, optional outline shells, and line-set metadata.", "NPRユーティリティライン設定として、Freestyleの可視線/陰線ラインセット、対応エッジ種別の編集可能カーブ線、任意の輪郭シェル、ラインセットメタデータを構築します。")
    bl_options = {'UNDO'}
    def execute(self, context):
        settings = _settings_owner(context)
        if settings is None:
            return {"CANCELLED"}
        targets = _anime_target_objects(context, settings)
        if not targets:
            msg = _context_ui(context, "No mesh targets for anime line generation.", "アニメ線画生成対象のメッシュがありません。")
            _set_status(settings, msg); _safe_report(self, {"WARNING"}, msg); return {"CANCELLED"}
        output = str(getattr(settings, "anime_line_output_mode", "BOTH") or "BOTH").upper()
        freestyle_changed = 0
        curve_count = 0
        edge_segments = {}
        if output in {"BOTH", "FREESTYLE"}:
            freestyle_changed = _anime_configure_freestyle(context, settings, targets)
        if output in {"BOTH", "CURVE"}:
            curve_count, edge_segments = _anime_create_curve_lines(context, settings, targets)
        shells = _anime_create_outline_shells(context, settings, targets) if _anime_bool(settings, "create_outline_shell", True) else 0
        export_dir = _manual_or_storage_dir(getattr(settings, "export_directory", ""), EXPORT_DIRNAME, create=True)
        preset_path = export_dir / (_clean_name(getattr(settings, "anime_line_set_name", "Smart Anime Line Set")) + ".sss_anime_line.json")
        _write_json(preset_path, _anime_line_manifest(settings, targets, edge_segments))
        svg_path = export_dir / (_clean_name(getattr(settings, "anime_line_set_name", "Smart Anime Line Set")) + ".svg")
        svg_written = _anime_write_svg(svg_path, settings, edge_segments) if edge_segments else False
        eps_path = export_dir / (_clean_name(getattr(settings, "anime_line_set_name", "Smart Anime Line Set")) + ".eps")
        eps_written = _anime_write_eps(eps_path, settings, edge_segments) if edge_segments else False
        msg = _context_ui(context, "Built anime line set: ", "アニメラインセットを構築しました: ") + str(getattr(settings, "anime_line_set_name", ""))
        msg += _context_ui(context, f" / targets {len(targets)}, Freestyle {freestyle_changed}, curves {curve_count}, shells {shells}", f" / 対象{len(targets)}、Freestyle{freestyle_changed}、カーブ{curve_count}、シェル{shells}")
        msg += _context_ui(context, " / preset: ", " / プリセット: ") + str(preset_path)
        if svg_written:
            msg += _context_ui(context, " / SVG: ", " / SVG: ") + str(svg_path)
        if eps_written:
            msg += _context_ui(context, " / EPS: ", " / EPS: ") + str(eps_path)
        _set_status(settings, msg); _safe_report(self, {"INFO"}, msg); return {"FINISHED"}


class SSS_OT_export_anime_line_preset_elements(Operator):
    bl_idname = 'sss.export_anime_line_preset_elements'
    bl_label = _ui('Export Line Preset Elements', '線画プリセット要素書出し')
    bl_description = _ui("Export current anime line settings as Smart_Shader_Suite or manually selected JSON, with visible/hidden categories, edge outputs, brush, reduction, material override, and render-element metadata.", "現在のアニメ線画設定をJSONとして書き出します。可視線/陰線、エッジ出力、ブラシ、リダクション、材質別上書き、レンダー要素メタデータを含みます。")
    bl_options = set()
    _sms_no_undo = True
    def execute(self, context):
        settings = _settings_owner(context)
        if settings is None:
            return {"CANCELLED"}
        targets = _anime_target_objects(context, settings)
        export_dir = _manual_or_storage_dir(getattr(settings, "export_directory", ""), EXPORT_DIRNAME, create=True)
        path = export_dir / (_clean_name(getattr(settings, "anime_line_set_name", "Smart Anime Line Set")) + ".sss_anime_line.json")
        ok = _write_json(path, _anime_line_manifest(settings, targets, {}))
        msg = (_context_ui(context, "Exported anime line preset: ", "アニメ線画プリセットを書き出しました: ") + str(path)) if ok else _context_ui(context, "Failed to export anime line preset.", "アニメ線画プリセットの書き出しに失敗しました。")
        _set_status(settings, msg); _safe_report(self, {"INFO" if ok else "WARNING"}, msg); return {"FINISHED" if ok else "CANCELLED"}


def _wrap_text_for_popup(text: str, width: int = 860) -> list:
    text = str(text or "")
    if not text: return [""]
    try:
        import blf  # type: ignore
        font_id = 0; max_width = max(120, int(width) - 64); words = re.split(r"(\s+)", text); lines = []; current = ""
        for token in words:
            candidate = current + token
            try: too_wide = blf.dimensions(font_id, candidate)[0] > max_width
            except Exception: too_wide = len(candidate) > max(20, max_width // 9)
            if current and too_wide: lines.append(current.rstrip()); current = token.lstrip()
            else: current = candidate
        if current.strip(): lines.append(current.strip())
        return lines or [text]
    except Exception:
        max_chars = max(20, int(width) // 9); lines = []; current = ""
        for word in text.split():
            candidate = (current + " " + word).strip()
            if current and len(candidate) > max_chars: lines.append(current); current = word
            else: current = candidate
        if current: lines.append(current)
        return lines or [text]

def _draw_help_button(layout, topic: str):
    mapping = {
        "overview": "shader_studio",
        "create": "sms_generation_import",
        "smart": "sms_smart_masks_npr",
        "library": "sms_library_assets",
        "scene": "sms_scene_management",
        "pencil": "sms_pencil_npr",
        "exchange": "sms_exchange_reports",
    }
    help_topic = mapping.get(str(topic or "overview"), str(topic or "shader_studio"))
    previous_context = getattr(layout, "operator_context", None)
    try:
        layout.operator_context = "INVOKE_DEFAULT"
    except Exception:
        previous_context = None
    try:
        row = layout.row(align=True)
        row.scale_x = 0.82
        row.scale_y = 1.0
        op = row.operator("sss.open_help", text="", icon="QUESTION", emboss=True)
        op.topic = help_topic
    except Exception:
        try:
            row = layout.row(align=True)
            row.scale_x = 0.82
            row.scale_y = 1.0
            row.label(text="", icon="QUESTION")
        except Exception:
            pass
    finally:
        if previous_context is not None:
            try:
                layout.operator_context = previous_context
            except Exception:
                pass


def _icon_value(name: str) -> int:
    try:
        return smart_ui_assets.icon_value(name)
    except Exception:
        return 0


def _draw_operator(layout, operator_id: str, *, text: str, icon_name: str = "", blender_icon: str = "NONE", emboss: bool = True):
    fallback = str(blender_icon or "NONE")
    if fallback == "NONE":
        fallback = smart_ui_assets.fallback_icon(icon_name)
    use_standard = fallback != "NONE"
    icon_id = 0 if use_standard else (_icon_value(icon_name) if icon_name else 0)
    try:
        if icon_id:
            return layout.operator(operator_id, text=text, icon_value=icon_id, emboss=emboss)
        return layout.operator(operator_id, text=text, icon=fallback, emboss=emboss)
    except TypeError:
        try:
            if icon_id:
                return layout.operator(operator_id, text=text, icon_value=icon_id)
            return layout.operator(operator_id, text=text, icon=fallback)
        except Exception:
            return layout.operator(operator_id, text=text, icon="NONE")
    except Exception:
        try:
            return layout.operator(operator_id, text=text, icon=fallback)
        except Exception:
            return None


def _draw_header(layout, context, title_en: str, title_ja: str, icon: str, topic: str):
    """Draw a Smart Modeling-style section at the Shader Studio root level.

    Blender UI boxes are visually indented every time a section is drawn from a
    child body layout.  Several page drawers are called after other section
    drawers, so always route Shader Studio section headers through the
    root layout captured by ``draw_shader_studio``.  This keeps "Core
    settings" and all following sections aligned with "Visual command deck"
    instead of forming a staircase.
    """
    title = _context_ui(context, title_en, title_ja)
    raw_key = str(topic or title_en or title or 'section').strip().lower()
    normalized_key = re.sub(r'[^0-9a-z_]+', '_', raw_key).strip('_') or 'section'
    key = normalized_key if normalized_key.startswith('sms_') else 'sms_' + normalized_key
    root_layout = _SECTION_ROOT_LAYOUT if _SECTION_ROOT_LAYOUT is not None else layout
    _box, body, _expanded = ui_sections.draw_group(
        root_layout,
        context,
        key,
        title,
        icon=icon if icon else "NONE",
        topic=str(topic or "").strip(),
        default_open=False,
    )
    return body



def _draw_large_icon_button(parent, context, operator_id: str, icon_name: str, label_en: str, label_ja: str, description_en: str = "", description_ja: str = ""):
    settings = _settings_owner(context)
    label = _context_ui(context, label_en, label_ja)
    desc = _context_ui(context, description_en, description_ja) if (description_en or description_ja) else ""
    cell = parent.column(align=True)
    try:
        cell.use_property_split = False
        cell.use_property_decorate = False
    except Exception:
        pass
    row = cell.row(align=True)
    row.alignment = "CENTER"
    try:
        row.scale_y = float(getattr(settings, "icon_button_scale", 3.35) or 3.35)
    except Exception:
        row.scale_y = 3.35
    op = _draw_operator(row, operator_id, text="", icon_name=icon_name, blender_icon=smart_ui_assets.fallback_icon(icon_name), emboss=True)
    try:
        op.tooltip = desc
    except Exception:
        pass
    text_row = cell.row(align=True)
    text_row.alignment = "CENTER"
    text_row.label(text=label)
    return cell


def _draw_action_deck(layout, context, settings):
    if not bool(getattr(settings, "use_large_icon_deck", True)):
        return
    box = _draw_header(layout, context, "Visual command deck", "ビジュアルコマンドデッキ", "SOLO_ON", "sms_visual_command_deck")
    try:
        box.scale_y = 1.0
    except Exception:
        pass
    density = str(getattr(settings, "ui_density", "STUDIO") or "STUDIO").upper()
    actions = [
        (SSS_OT_finish_production_material.bl_idname, "supreme_finish", "Supreme", "最高精度", "Run the strongest finishing pass.", "最強仕上げを実行します。"),
        (SSS_OT_upgrade_material_quality.bl_idname, "quality_upgrade", "Quality", "品質強化", "Improve material health and node layout.", "材質ヘルスとノード構成を改善します。"),
        (SSS_OT_import_pbr_texture_set.bl_idname, "pbr_import_set", "PBR import", "PBR取込", "Import and route a texture set.", "テクスチャセットを取り込み配線します。"),
        (SSS_OT_create_procedural_material.bl_idname, "smart_material_create", "Material", "材質生成", "Create a procedural smart material.", "プロシージャル材質を生成します。"),
        (SSS_OT_apply_weathering.bl_idname, "smart_weathering", "Weather", "経年変化", "Add smart masks and weathering.", "スマートマスクと経年変化を追加します。"),
        (SSS_OT_build_anime_line_set.bl_idname, "line_set", "Line set", "線画生成", "Build anime line set output.", "アニメ線画セットを生成します。"),
    ]
    if density in {"STUDIO", "FULL"}:
        actions += [
            (SSS_OT_save_material_capsule.bl_idname, "material_capsule_save", "Capsule", "カプセル", "Save active material as a local capsule.", "アクティブ材質をローカル保存します。"),
            (SSS_OT_relink_missing_assets.bl_idname, "relink", "Relink", "再リンク", "Repair missing texture paths.", "リンク切れパスを修復します。"),
            (SSS_OT_cleanup_materials.bl_idname, "cleanup", "Cleanup", "整理", "Purge unused material data safely.", "未使用材質データを安全に整理します。"),
            (SSS_OT_export_materialx_usd.bl_idname, "bridge_transfer", "Exchange", "受け渡し", "Export MaterialX/USD approximations.", "MaterialX/USD近似を書き出します。"),
            (SSS_OT_audit_material_quality.bl_idname, "audit", "Audit", "監査", "Create a report without editing.", "編集せずレポート化します。"),
            (SSS_OT_layout_active_material_nodes.bl_idname, "node_layout_auto", "Layout", "整列", "Layout active material nodes.", "アクティブ材質ノードを整列します。"),
        ]
    flow = box.grid_flow(row_major=True, columns=3, even_columns=True, even_rows=True, align=True)
    for action in actions:
        _draw_large_icon_button(flow, context, *action)
    if bool(getattr(settings, "show_visual_references", False)):
        ref = box.column(align=True)
        ref.separator(factor=0.5)
        refs = [("ref_pbr_pipeline", "PBR"), ("ref_npr_pipeline", "NPR"), ("ref_asset_pipeline", "Assets")]
        rflow = ref.grid_flow(row_major=True, columns=1, even_columns=True, align=True)
        for key, title in refs:
            icon_id = _icon_value(key)
            if icon_id:
                sub = rflow.column(align=True)
                sub.label(text=title)
                try:
                    sub.template_icon(icon_value=icon_id, scale=6.0)
                except Exception:
                    pass

def _draw_status(layout, settings):
    text = str(getattr(settings, "last_report", "") or "").strip() if settings else ""
    if not text: return
    box = layout.box(); box.label(text=_ui("Last report", "直近レポート"))
    for line in _wrap_text_for_popup(text, 360)[:8]: box.label(text=line)

def _draw_settings_card(layout, context, settings):
    col = _draw_header(layout, context, "Core settings", "基本設定", "PREFERENCES", "sms_core_settings")
    col.prop(settings, "active_page", text=_context_ui(context, "Page", "ページ")); col.prop(settings, "ui_density", text=_context_ui(context, "UI density", "UI密度")); col.prop(settings, "quality_profile", text=_context_ui(context, "Quality", "品質"))
    col.prop(settings, "material_name", text=_context_ui(context, "Material name", "材質名")); col.prop(settings, "assignment_scope", text=_context_ui(context, "Scope", "対象範囲"))
    col.prop(settings, "assign_to_selected", text=_context_ui(context, "Assign to selected", "選択へ割り当て")); col.prop(settings, "use_fake_user", text=_context_ui(context, "Fake user", "フェイクユーザー")); col.prop(settings, "mark_asset", text=_context_ui(context, "Mark as asset", "アセット化"))
    _draw_suite_material_slot_selector(col, context)
    col.prop(settings, "auto_layout_nodes", text=_context_ui(context, "Auto layout nodes", "ノード自動整列")); col.prop(settings, "auto_color_space_fix", text=_context_ui(context, "Fix data color space", "データ色空間修正")); col.prop(settings, "strict_texture_detection", text=_context_ui(context, "Strict texture detection", "厳密テクスチャ検出"))

def _draw_create_page(layout, context, settings):
    qcol = _draw_header(layout, context, "Production quality upgrade", "制作品質アップグレード", "CHECKMARK", "sms_quality_upgrade")
    qcol.prop(settings, "quality_profile", text=_context_ui(context, "Profile", "プロファイル")); qcol.prop(settings, "generate_quality_report", text=_context_ui(context, "Report", "レポート"))
    qrow = qcol.row(align=True); _draw_operator(qrow, SSS_OT_upgrade_material_quality.bl_idname, text=_context_ui(context, "Upgrade", "強化"), icon_name="quality_upgrade", blender_icon="NONE"); _draw_operator(qrow, SSS_OT_audit_material_quality.bl_idname, text=_context_ui(context, "Audit", "監査"), icon_name="audit", blender_icon="VIEWZOOM")
    _draw_operator(qcol, SSS_OT_layout_active_material_nodes.bl_idname, text=_context_ui(context, "Layout active material nodes", "アクティブ材質ノードを整列"), icon_name="node_layout_auto", blender_icon="NONE")
    col = _draw_header(layout, context, "Procedural and PBR generation", "プロシージャルとPBR生成", "MATERIAL", "sms_generation_import")
    col.prop(settings, "material_preset", text=_context_ui(context, "Preset", "プリセット")); col.prop(settings, "texture_scale", text=_context_ui(context, "Texture scale", "テクスチャスケール")); col.prop(settings, "roughness", text=_context_ui(context, "Roughness", "粗さ")); col.prop(settings, "metallic", text=_context_ui(context, "Metallic", "金属度")); col.prop(settings, "normal_strength", text=_context_ui(context, "Normal", "法線")); _draw_operator(col, SSS_OT_create_procedural_material.bl_idname, text=_context_ui(context, "Create Smart material", "スマート材質を生成"), icon_name="smart_material_create", blender_icon="NONE")
    col.separator(); col.prop(settings, "texture_directory", text=_context_ui(context, "Texture folder", "テクスチャフォルダ")); row = col.row(align=True); row.prop(settings, "recursive_scan", text=_context_ui(context, "Recursive", "再帰")); row.prop(settings, "force_texture_rewire", text=_context_ui(context, "Rewire", "再配線")); _draw_operator(col, SSS_OT_import_pbr_texture_set.bl_idname, text=_context_ui(context, "Import PBR texture set", "PBRテクスチャセットを取り込み"), icon_name="pbr_import_set", blender_icon="NONE")
    col.separator(); col.prop(settings, "photo_source", text=_context_ui(context, "Photo/HDRI", "写真/HDRI")); _draw_operator(col, SSS_OT_create_photo_pbr_sampler.bl_idname, text=_context_ui(context, "Photo to PBR sampler", "写真からPBR サンプラー"), icon_name="photo_to_pbr", blender_icon="NONE")
    col = _draw_header(layout, context, "NPR and atomic node patterns", "NPRとアトミックノードパターン", "SHADING_RENDERED", "sms_npr_atomic")
    col.prop(settings, "style_preset", text=_context_ui(context, "NPR style", "NPRスタイル")); col.prop(settings, "toon_steps", text=_context_ui(context, "Steps", "階調")); col.prop(settings, "toon_threshold", text=_context_ui(context, "Threshold", "境界")); _draw_operator(col, SSS_OT_create_npr_material.bl_idname, text=_context_ui(context, "Create NPR material", "NPR材質を生成"), icon_name="toon_shader_create", blender_icon="NONE")
    col.separator(); col.prop(settings, "atomic_preset", text=_context_ui(context, "Atomic", "アトミック")); _draw_operator(col, SSS_OT_create_atomic_pattern.bl_idname, text=_context_ui(context, "Create atomic node material", "アトミックノード材質を生成"), icon_name="node_layout", blender_icon="NODETREE")

def _draw_smart_page(layout, context, settings):
    col = _draw_header(layout, context, "Smart masks and weathering", "スマートマスクと経年変化", "MOD_MASK", "sms_smart_masks_weathering")
    col.prop(settings, "weathering_amount", text=_context_ui(context, "Weathering", "経年変化")); col.prop(settings, "edge_wear_amount", text=_context_ui(context, "Edge wear", "エッジ摩耗")); col.prop(settings, "dirt_amount", text=_context_ui(context, "Dirt", "汚れ")); col.prop(settings, "wetness_amount", text=_context_ui(context, "Wetness", "濡れ")); _draw_operator(col, SSS_OT_apply_weathering.bl_idname, text=_context_ui(context, "Apply smart weathering", "スマート経年変化を適用"), icon_name="smart_weathering", blender_icon="NONE")
    col = _draw_header(layout, context, "NPR lines and decals", "NPR線とデカール", "GREASEPENCIL", "sms_npr_lines_decals")
    col.prop(settings, "line_width", text=_context_ui(context, "Line width", "線幅")); col.prop(settings, "create_outline_shell", text=_context_ui(context, "Outline shell", "輪郭シェル")); _draw_operator(col, SSS_OT_setup_npr_lines.bl_idname, text=_context_ui(context, "Setup NPR outline", "NPR輪郭を設定"), icon_name="line_set", blender_icon="GREASEPENCIL")
    col.separator(); col.prop(settings, "decal_size", text=_context_ui(context, "Decal size", "デカールサイズ")); _draw_operator(col, SSS_OT_create_decal_plane.bl_idname, text=_context_ui(context, "Create decal plane", "デカール平面を作成"), icon_name="decal", blender_icon="IMAGE_DATA")

def _draw_library_page(layout, context, settings):
    col = _draw_header(layout, context, "Local material library", "ローカル材質ライブラリ", "ASSET_MANAGER", "sms_local_material_library")
    col.prop(settings, "library_root", text=_context_ui(context, "Library root", "ライブラリ基点")); col.prop(settings, "search_query", text=_context_ui(context, "Search", "検索")); _draw_operator(col, SSS_OT_search_local_assets.bl_idname, text=_context_ui(context, "Search local assets", "ローカルアセットを検索"), icon_name="audit", blender_icon="VIEWZOOM"); _draw_operator(col, SSS_OT_save_material_capsule.bl_idname, text=_context_ui(context, "Save material capsule", "材質カプセルを保存"), icon_name="material_capsule_save", blender_icon="NONE"); _draw_operator(col, SSS_OT_restore_material_capsule.bl_idname, text=_context_ui(context, "Restore material capsule", "材質カプセルを復元"), icon_name="material_capsule_restore", blender_icon="NONE"); _draw_operator(col, SSS_OT_mark_materials_as_assets.bl_idname, text=_context_ui(context, "Mark materials as assets", "材質をアセット化"), icon_name="library", blender_icon="ASSET_MANAGER")

def _draw_scene_page(layout, context, settings):
    col = _draw_header(layout, context, "Relink and cleanup", "再リンクとクリーンアップ", "FILE_REFRESH", "sms_relink_cleanup")
    col.prop(settings, "relink_root", text=_context_ui(context, "Relink root", "再リンク基点")); col.prop(settings, "recursive_scan", text=_context_ui(context, "Recursive scan", "再帰検索")); _draw_operator(col, SSS_OT_relink_missing_assets.bl_idname, text=_context_ui(context, "Relink missing assets", "リンク切れアセットを再リンク"), icon_name="relink", blender_icon="FILE_REFRESH")
    col.separator(); col.prop(settings, "cleanup_slots", text=_context_ui(context, "Cleanup slots", "スロット整理")); col.prop(settings, "cleanup_images", text=_context_ui(context, "Cleanup images", "画像も整理")); col.prop(settings, "cleanup_duplicates", text=_context_ui(context, "Merge duplicates", "重複統合")); _draw_operator(col, SSS_OT_cleanup_materials.bl_idname, text=_context_ui(context, "Cleanup materials", "材質をクリーンアップ"), icon_name="cleanup", blender_icon="TRASH")
    col = _draw_header(layout, context, "Scene material management", "シーン材質管理", "SCENE_DATA", "sms_scene_material_management")
    _draw_operator(col, SSS_OT_select_by_material.bl_idname, text=_context_ui(context, "Select by material", "材質で逆引き選択"), icon_name="palette", blender_icon="RESTRICT_SELECT_OFF"); col.prop(settings, "id_slot_count", text=_context_ui(context, "ID slots", "IDスロット")); _draw_operator(col, SSS_OT_create_material_id_palette.bl_idname, text=_context_ui(context, "Create Material-ID palette", "Material-IDパレットを生成"), icon_name="palette", blender_icon="MATERIAL")
    col.separator(); col.prop(settings, "rule_expression", text=_context_ui(context, "Rule", "ルール")); col.prop(settings, "use_regex_rules", text=_context_ui(context, "Regex", "正規表現")); _draw_operator(col, SSS_OT_apply_assignment_rule.bl_idname, text=_context_ui(context, "Apply material rule", "材質ルールを適用"), icon_name="quality", blender_icon="CONSTRAINT")
    col.separator(); col.prop(settings, "variant_name", text=_context_ui(context, "Variant", "バリアント")); row = col.row(align=True); _draw_operator(row, SSS_OT_save_material_variant.bl_idname, text=_context_ui(context, "Save", "保存"), icon_name="variant", blender_icon="FILE_TICK"); _draw_operator(row, SSS_OT_apply_material_variant.bl_idname, text=_context_ui(context, "Apply", "適用"), icon_name="variant", blender_icon="FILE_REFRESH"); col.prop(settings, "random_seed", text=_context_ui(context, "Seed", "シード")); _draw_operator(col, SSS_OT_randomize_material_colors.bl_idname, text=_context_ui(context, "Randomize material colors", "材質色をランダム化"), icon_name="palette", blender_icon="COLOR")

def _draw_exchange_page(layout, context, settings):
    col = _draw_header(layout, context, "Portable exchange", "ポータブル受け渡し", "FILE_CACHE", "sms_portable_exchange")
    col.prop(settings, "export_directory", text=_context_ui(context, "Export folder", "書き出しフォルダ")); _draw_operator(col, SSS_OT_export_materialx_usd.bl_idname, text=_context_ui(context, "Export MaterialX/USD", "MaterialX/USDを書き出し"), icon_name="exchange", blender_icon="EXPORT"); _draw_operator(col, SSS_OT_generate_node_report.bl_idname, text=_context_ui(context, "Generate node report", "ノードレポートを生成"), icon_name="audit", blender_icon="TEXT")
    col = _draw_header(layout, context, "HDRI, AOV, and dynamic paths", "HDRI・AOV・動的パス", "WORLD_DATA", "sms_hdri_aov_dynamic_paths")
    col.prop(settings, "photo_source", text=_context_ui(context, "HDRI image", "HDRI画像")); col.prop(settings, "hdri_strength", text=_context_ui(context, "Strength", "強度")); col.prop(settings, "hdri_rotation", text=_context_ui(context, "Rotation", "回転")); _draw_operator(col, SSS_OT_build_hdri_world.bl_idname, text=_context_ui(context, "Build HDRI world", "HDRIワールドを構築"), icon_name="hdri", blender_icon="WORLD_DATA")
    col.separator(); _draw_operator(col, SSS_OT_add_aov_lpe_helpers.bl_idname, text=_context_ui(context, "Add AOV helpers", "AOV補助を追加"), icon_name="render_preview", blender_icon="RENDERLAYERS"); _draw_operator(col, SSS_OT_resolve_dynamic_texture_paths.bl_idname, text=_context_ui(context, "Resolve dynamic paths", "動的パスを解決"), icon_name="relink", blender_icon="FILE_REFRESH")


def _draw_pencil_page(layout, context, settings):
    col = _draw_header(layout, context, "Smart Anime Line / NPR utility system", "Smart Anime Line / NPRライン", "GREASEPENCIL", "sms_anime_line_overview")
    col.prop(settings, "anime_line_mode", text=_context_ui(context, "Quality", "品質"))
    col.prop(settings, "anime_target_scope", text=_context_ui(context, "Targets", "対象"))
    col.prop(settings, "anime_line_output_mode", text=_context_ui(context, "Output", "出力"))
    col.prop(settings, "anime_line_set_name", text=_context_ui(context, "Line set", "ラインセット"))
    col.prop(settings, "anime_brush_instance_name", text=_context_ui(context, "Brush instance", "ブラシ設定"))
    col.prop(settings, "anime_reduction_instance_name", text=_context_ui(context, "Reduction instance", "リダクション設定"))
    col.prop(settings, "anime_line_size_map", text=_context_ui(context, "Line size map", "線幅マップ"))
    row = col.row(align=True)
    row.prop(settings, "anime_line_set_id", text=_context_ui(context, "ID", "ID"))
    row.prop(settings, "anime_line_render_priority", text=_context_ui(context, "Priority", "優先度"))
    row = col.row(align=True)
    row.prop(settings, "anime_visible_lines", text=_context_ui(context, "Visible", "可視線"))
    row.prop(settings, "anime_hidden_lines", text=_context_ui(context, "Hidden", "陰線"))
    col.prop(settings, "anime_merge_groups", text=_context_ui(context, "Merge groups", "マージグループ"))
    col.prop(settings, "anime_self_intersection", text=_context_ui(context, "Self-intersection", "自己交差線"))
    col.prop(settings, "anime_viewport_preview", text=_context_ui(context, "Viewport preview", "ビューポート確認"))
    col.prop(settings, "anime_attribute_override_enabled", text=_context_ui(context, "Attribute override", "属性オーバーライド"))
    _draw_operator(col, SSS_OT_build_anime_line_set.bl_idname, text=_context_ui(context, "Build anime line set", "アニメラインセットを構築"), icon_name="line_set", blender_icon="GREASEPENCIL")
    _draw_operator(col, SSS_OT_apply_attribute_override.bl_idname, text=_context_ui(context, "Apply attribute override", "属性オーバーライドを適用"), icon_name="quality", blender_icon="CONSTRAINT")
    _draw_operator(col, SSS_OT_export_viewport_line_preview.bl_idname, text=_context_ui(context, "Render anime preview", "アニメプレビューを描画"), icon_name="render_preview", blender_icon="RENDER_STILL")
    _draw_operator(col, SSS_OT_export_anime_line_preset_elements.bl_idname, text=_context_ui(context, "Export line preset", "線画プリセットを書き出し"), icon_name="exchange", blender_icon="EXPORT")

    col = _draw_header(layout, context, "Anime cel shader", "アニメセルシェーダー", "SHADING_RENDERED", "sms_anime_cel_shader")
    col.prop(settings, "anime_shader_base_color", text=_context_ui(context, "Base", "基本色"))
    col.prop(settings, "anime_shader_shadow_color", text=_context_ui(context, "Shadow", "影色"))
    col.prop(settings, "anime_shader_highlight_color", text=_context_ui(context, "Highlight", "ハイライト"))
    col.prop(settings, "anime_shader_rim_color", text=_context_ui(context, "Rim", "リム"))
    col.prop(settings, "anime_shader_zone1", text=_context_ui(context, "Shadow boundary", "影境界"))
    col.prop(settings, "anime_shader_zone2", text=_context_ui(context, "Mid boundary", "中間境界"))
    col.prop(settings, "anime_shader_zone3", text=_context_ui(context, "Highlight boundary", "ハイライト境界"))
    col.prop(settings, "anime_shader_highlight_strength", text=_context_ui(context, "Highlight strength", "ハイライト強度"))
    col.prop(settings, "anime_shader_rim_strength", text=_context_ui(context, "Rim strength", "リム強度"))
    col.prop(settings, "anime_shader_hatching_strength", text=_context_ui(context, "Hatching", "ハッチング"))
    _draw_operator(col, SSS_OT_create_anime_cel_shader.bl_idname, text=_context_ui(context, "Create anime cel shader", "アニメセルシェーダーを生成"), icon_name="toon_shader_create", blender_icon="NONE")

    col = _draw_header(layout, context, "Edge detection", "エッジ検出", "MOD_EDGESPLIT", "sms_edge_detection")
    col.prop(settings, "anime_edge_outline", text=_context_ui(context, "Outline", "アウトライン"))
    col.prop(settings, "anime_edge_open", text=_context_ui(context, "Open edge", "開放エッジ"))
    col.prop(settings, "anime_edge_object", text=_context_ui(context, "Object", "オブジェクト境界"))
    col.prop(settings, "anime_edge_intersection", text=_context_ui(context, "Intersection", "交差線"))
    col.prop(settings, "anime_edge_smoothing_boundary", text=_context_ui(context, "Smoothing boundary", "スムージング境界"))
    col.prop(settings, "anime_edge_material_boundary", text=_context_ui(context, "Material boundary", "材質境界"))
    col.prop(settings, "anime_edge_selected", text=_context_ui(context, "Selected edge", "選択エッジ"))
    col.prop(settings, "anime_edge_normal_angle", text=_context_ui(context, "Normal angle", "法線角"))
    col.prop(settings, "anime_normal_angle_threshold", text=_context_ui(context, "Angle threshold", "角度しきい値"))
    col.prop(settings, "anime_edge_wireframe", text=_context_ui(context, "Wireframe", "ワイヤーフレーム"))

    col = _draw_header(layout, context, "Brush, stroke, and reduction", "ブラシ・ストローク・リダクション", "BRUSH_DATA", "sms_brush_stroke_reduction")
    col.prop(settings, "anime_brush_color", text=_context_ui(context, "Visible color", "可視線色"))
    col.prop(settings, "anime_hidden_color", text=_context_ui(context, "Hidden color", "陰線色"))
    col.prop(settings, "anime_brush_width", text=_context_ui(context, "Visible width", "可視線幅"))
    col.prop(settings, "anime_hidden_width", text=_context_ui(context, "Hidden width", "陰線幅"))
    col.prop(settings, "anime_brush_opacity", text=_context_ui(context, "Visible opacity", "可視線不透明度"))
    col.prop(settings, "anime_hidden_opacity", text=_context_ui(context, "Hidden opacity", "陰線不透明度"))
    col.prop(settings, "anime_brush_angle", text=_context_ui(context, "Brush angle", "ブラシ角度"))
    col.prop(settings, "anime_brush_jitter", text=_context_ui(context, "Jitter", "ジッター"))
    col.prop(settings, "anime_brush_taper", text=_context_ui(context, "Taper", "入り抜き"))
    col.prop(settings, "anime_brush_random_width", text=_context_ui(context, "Width variation", "線幅揺らぎ"))
    row = col.row(align=True)
    row.prop(settings, "anime_brush_dash_enabled", text=_context_ui(context, "Dash", "破線"))
    row.prop(settings, "anime_brush_dash_length", text=_context_ui(context, "Dash", "破線長"))
    row.prop(settings, "anime_brush_gap_length", text=_context_ui(context, "Gap", "隙間"))
    col.separator()
    col.prop(settings, "anime_reduction_enabled", text=_context_ui(context, "Distance reduction", "距離リダクション"))
    col.prop(settings, "anime_reduction_start", text=_context_ui(context, "Start", "開始"))
    col.prop(settings, "anime_reduction_end", text=_context_ui(context, "End", "終了"))
    col.prop(settings, "anime_reduction_min_width", text=_context_ui(context, "Min width", "最小線幅"))
    col.prop(settings, "anime_reduction_min_alpha", text=_context_ui(context, "Min alpha", "最小アルファ"))
    col.prop(settings, "anime_curve_bevel_scale", text=_context_ui(context, "Curve scale", "カーブ倍率"))
    col.prop(settings, "anime_depth_offset", text=_context_ui(context, "Depth offset", "奥行きオフセット"))

    col = _draw_header(layout, context, "Material line functions and render elements", "材質別ライン機能とレンダー要素", "MATERIAL", "sms_material_line_render_elements")
    col.prop(settings, "anime_material_override_enabled", text=_context_ui(context, "Material overrides", "材質別上書き"))
    col.prop(settings, "anime_material_replace_color", text=_context_ui(context, "Replace line color", "線色置換"))
    col.prop(settings, "anime_material_disable_intersection", text=_context_ui(context, "Disable intersection", "交差線無効"))
    col.prop(settings, "anime_material_hidden_as_visible", text=_context_ui(context, "Hidden as visible", "陰線を可視線化"))
    col.prop(settings, "anime_material_mask_hidden_targets", text=_context_ui(context, "Mask hidden targets", "陰線対象をマスク"))
    _draw_operator(col, SSS_OT_apply_material_line_functions.bl_idname, text=_context_ui(context, "Apply material line functions", "材質別ライン機能を適用"), icon_name="palette", blender_icon="MATERIAL")
    col.separator()
    col.prop(settings, "anime_render_visible_element", text=_context_ui(context, "Visible element", "可視線要素"))
    col.prop(settings, "anime_render_hidden_element", text=_context_ui(context, "Hidden element", "陰線要素"))
    col.prop(settings, "anime_render_edge_elements", text=_context_ui(context, "Edge elements", "エッジ別要素"))
    col.prop(settings, "anime_render_background_enabled", text=_context_ui(context, "Background", "背景"))
    col.prop(settings, "anime_render_background_color", text=_context_ui(context, "Background color", "背景色"))
    col.prop(settings, "export_directory", text=_context_ui(context, "Export folder", "書き出しフォルダ"))

def draw_shader_studio(layout, context, *, embedded: bool = False):
    global _SECTION_ROOT_LAYOUT
    try:
        ui_sections.cleanup_legacy_section_state(context)
    except Exception:
        pass
    previous_root_layout = _SECTION_ROOT_LAYOUT
    try:
        root_layout = layout.column(align=True)
        root_layout.use_property_split = False
        root_layout.use_property_decorate = False
    except Exception:
        root_layout = layout
    _SECTION_ROOT_LAYOUT = root_layout
    try:
        settings = _settings_owner(context)
        if settings is None:
            root_layout.label(text=_context_ui(context, "Shader Studio settings are not registered.", "スマートシェーダーの設定が登録されていません。"), icon="ERROR"); return
        try:
            root_layout.use_property_split = False; root_layout.use_property_decorate = False
        except Exception: pass
        if not embedded:
            header = root_layout.box(); row = header.row(align=True); row.label(text="Shader Studio", icon="SHADING_RENDERED"); right = row.row(align=True); right.alignment = "RIGHT"; _draw_help_button(right, "overview")
        _draw_action_deck(root_layout, context, settings)
        _draw_settings_card(root_layout, context, settings)
        density = str(getattr(settings, "ui_density", "STUDIO") or "STUDIO").upper()
        page = str(getattr(settings, "active_page", "CREATE") or "CREATE")
        if density == "COMPACT":
            qcol = _draw_header(root_layout, context, "Main production actions", "主要制作アクション", "WORKSPACE", "sms_main_actions")
            qrow = qcol.row(align=True); _draw_operator(qrow, SSS_OT_upgrade_material_quality.bl_idname, text=_context_ui(context, "Upgrade", "強化"), icon_name="quality_upgrade", blender_icon="NONE"); _draw_operator(qrow, SSS_OT_audit_material_quality.bl_idname, text=_context_ui(context, "Audit", "監査"), icon_name="audit", blender_icon="VIEWZOOM")
            _draw_operator(qcol, SSS_OT_import_pbr_texture_set.bl_idname, text=_context_ui(context, "Import PBR texture set", "PBRテクスチャセットを取り込み"), icon_name="pbr_import_set", blender_icon="NONE")
            _draw_operator(qcol, SSS_OT_create_anime_cel_shader.bl_idname, text=_context_ui(context, "Create anime cel shader", "アニメセルシェーダーを生成"), icon_name="toon_shader_create", blender_icon="NONE")
            _draw_operator(qcol, SSS_OT_build_anime_line_set.bl_idname, text=_context_ui(context, "Build anime line set", "アニメラインセットを構築"), icon_name="line_set", blender_icon="GREASEPENCIL")
            _draw_status(root_layout, settings)
            return
        if page == "SMART": _draw_smart_page(root_layout, context, settings)
        elif page == "PENCIL": _draw_create_page(root_layout, context, settings)
        elif page == "LIBRARY": _draw_library_page(root_layout, context, settings)
        elif page == "SCENE": _draw_scene_page(root_layout, context, settings)
        elif page == "EXCHANGE": _draw_exchange_page(root_layout, context, settings)
        else: _draw_create_page(root_layout, context, settings)
        if density == "FULL":
            col = _draw_header(root_layout, context, "All-in-one deep actions", "全機能ディープ操作", "TOOL_SETTINGS", "sms_deep_actions")
            _draw_operator(col, SSS_OT_finish_production_material.bl_idname, text=_context_ui(context, "Supreme production finish", "最高精度で仕上げ"), icon_name="supreme_finish", blender_icon="NONE"); _draw_operator(col, SSS_OT_upgrade_material_quality.bl_idname, text=_context_ui(context, "Upgrade material quality", "材質品質を強化"), icon_name="quality_upgrade", blender_icon="NONE"); _draw_operator(col, SSS_OT_cleanup_materials.bl_idname, text=_context_ui(context, "Cleanup materials", "材質をクリーンアップ"), icon_name="cleanup", blender_icon="TRASH"); _draw_operator(col, SSS_OT_relink_missing_assets.bl_idname, text=_context_ui(context, "Relink missing assets", "リンク切れアセットを再リンク"), icon_name="relink", blender_icon="FILE_REFRESH"); _draw_operator(col, SSS_OT_export_materialx_usd.bl_idname, text=_context_ui(context, "Export MaterialX/USD", "MaterialX/USDを書き出し"), icon_name="exchange", blender_icon="EXPORT")
        _draw_status(root_layout, settings)
    finally:
        _SECTION_ROOT_LAYOUT = previous_root_layout
def draw_shader_studio_embedded(layout, context):
    draw_shader_studio(layout, context, embedded=True)


CLASSES = (
    SSS_MaterialStudioSettings,
    SSS_OT_create_procedural_material, SSS_OT_create_npr_material, SSS_OT_create_atomic_pattern,
    SSS_OT_create_anime_cel_shader, SSS_OT_apply_material_line_functions, SSS_OT_apply_attribute_override, SSS_OT_export_viewport_line_preview, SSS_OT_build_anime_line_set, SSS_OT_export_anime_line_preset_elements,
    SSS_OT_import_pbr_texture_set, SSS_OT_create_photo_pbr_sampler, SSS_OT_apply_weathering, SSS_OT_setup_npr_lines,
    SSS_OT_create_decal_plane, SSS_OT_save_material_capsule, SSS_OT_restore_material_capsule, SSS_OT_search_local_assets,
    SSS_OT_mark_materials_as_assets, SSS_OT_relink_missing_assets, SSS_OT_cleanup_materials, SSS_OT_select_by_material,
    SSS_OT_create_material_id_palette, SSS_OT_apply_assignment_rule, SSS_OT_save_material_variant, SSS_OT_apply_material_variant,
    SSS_OT_randomize_material_colors, SSS_OT_build_hdri_world, SSS_OT_export_materialx_usd, SSS_OT_add_aov_lpe_helpers,
    SSS_OT_resolve_dynamic_texture_paths, SSS_OT_generate_node_report, SSS_OT_finish_production_material, SSS_OT_upgrade_material_quality, SSS_OT_audit_material_quality, SSS_OT_layout_active_material_nodes,
)




def _sms_slot_prop_annotation():
    return EnumProperty(**slot_selection.MATERIAL_TARGET_SLOT_PROPERTY_KWARGS)


def _sms_slot_prompt_needed(self, context) -> bool:
    try:
        settings = _settings_owner(context)
        return bool(getattr(settings, "assign_to_selected", False))
    except Exception:
        return False


def _sms_wrap_material_target_slot_prompt(cls):
    if getattr(cls, "_sss_material_target_slot_prompt_wrapped", False):
        return cls
    annotations = dict(getattr(cls, "__annotations__", {}) or {})
    if "sss_target_slot_token" not in annotations:
        annotations["sss_target_slot_token"] = _sms_slot_prop_annotation()
        cls.__annotations__ = annotations
    if not getattr(cls, "bl_property", ""):
        try:
            cls.bl_property = "sss_target_slot_token"
        except Exception:
            pass
    original_invoke = getattr(cls, "invoke", None)
    original_execute = getattr(cls, "execute", None)

    def invoke(self, context, event):
        if _sms_slot_prompt_needed(self, context):
            result = slot_selection.invoke_operator_material_target_slot_search(self, context, assign_selected=True)
            if result:
                return result
        if callable(original_invoke):
            return original_invoke(self, context, event)
        if callable(original_execute):
            return self.execute(context)
        return {"CANCELLED"}

    def execute(self, context):
        try:
            slot_selection.apply_operator_material_target_slot(self, context)
        except Exception:
            pass
        if callable(original_execute):
            return original_execute(self, context)
        return {"CANCELLED"}

    cls.invoke = invoke
    cls.execute = execute
    cls._sss_material_target_slot_prompt_wrapped = True
    return cls


for _sms_slot_cls in (
    SSS_OT_create_procedural_material,
    SSS_OT_create_npr_material,
    SSS_OT_create_atomic_pattern,
    SSS_OT_import_pbr_texture_set,
    SSS_OT_create_photo_pbr_sampler,
    SSS_OT_restore_material_capsule,
    SSS_OT_apply_assignment_rule,
    SSS_OT_create_anime_cel_shader,
):
    _sms_wrap_material_target_slot_prompt(_sms_slot_cls)

_LEGACY_PANEL_CLASS_NAMES = ('SSS_SMS_PT_view3d_panel', 'SSS_SMS_PT_shader_editor_panel')

def _unregister_legacy_panel_classes():
    # Legacy panel classes are no longer removed by name; current Suite-owned
    # root panels are registered through the exact class ledger.
    return None

def register():
    global _POINTER_REGISTERED, _HANDLERS_REGISTERED
    _unregister_legacy_panel_classes()
    if not _POINTER_REGISTERED and _ensure_settings_class_registered():
        try:
            if hasattr(bpy.types.WindowManager, 'sss_material_studio'):
                try:
                    del bpy.types.WindowManager.sss_material_studio
                except Exception:
                    pass
            bpy.types.WindowManager.sss_material_studio = PointerProperty(type=SSS_MaterialStudioSettings)
            _POINTER_REGISTERED = True
        except Exception:
            _POINTER_REGISTERED = False
    try: apply_settings()
    except Exception: pass
    if not _HANDLERS_REGISTERED:
        sync_settings_handlers(getattr(bpy, 'context', None))

def unregister():
    global _POINTER_REGISTERED, _HANDLERS_REGISTERED
    _unregister_legacy_panel_classes()
    try: save_settings(force=True)
    except Exception: pass
    _unregister_settings_handlers()
    _HANDLERS_REGISTERED = False
    if _POINTER_REGISTERED:
        try: del bpy.types.WindowManager.sss_material_studio
        except Exception: pass
        _POINTER_REGISTERED = False

# -----------------------------------------------------------------------------
# Smart Shader Suite 5.18.224 exact-owned Material Studio runtime.
# -----------------------------------------------------------------------------
_SMS_V1208_OWNED_POINTER = False
_SMS_V1208_HANDLER_LEDGER = []


def _unregister_legacy_panel_classes():
    """No-op: never remove a class by name or module prefix."""
    return None


def _ensure_settings_class_registered() -> bool:
    """The suite-level class ledger owns this PropertyGroup registration."""
    return _class_has_bl_rna(SSS_MaterialStudioSettings)


@persistent
def _load_post_handler(_dummy=None):
    """Restore bounded scalar settings only; never scan datablocks or graphs."""
    try:
        apply_settings()
    except Exception:
        pass


@persistent
def _save_pre_handler(_dummy=None):
    try:
        save_settings(force=True)
    except Exception:
        pass


def _register_settings_handlers() -> bool:
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return False
    added = []
    try:
        for name, callback in (('load_post', _load_post_handler), ('save_pre', _save_pre_handler)):
            container = getattr(handlers, name, None)
            if container is not None and callback not in container:
                container.append(callback)
                added.append((container, callback))
        _SMS_V1208_HANDLER_LEDGER.extend(added)
        return True
    except Exception:
        for container, callback in reversed(added):
            try:
                if callback in container:
                    container.remove(callback)
            except Exception:
                pass
        return False


def _unregister_settings_handlers() -> None:
    for container, callback in reversed(tuple(_SMS_V1208_HANDLER_LEDGER)):
        try:
            if callback in container:
                container.remove(callback)
        except Exception:
            pass
    _SMS_V1208_HANDLER_LEDGER.clear()


def register():
    global _POINTER_REGISTERED, _HANDLERS_REGISTERED, _SMS_V1208_OWNED_POINTER
    if not _ensure_settings_class_registered():
        raise RuntimeError('Material Studio settings RNA is unavailable')
    existing = getattr(bpy.types.WindowManager, 'sss_material_studio', None)
    if existing is None:
        bpy.types.WindowManager.sss_material_studio = PointerProperty(type=SSS_MaterialStudioSettings)
        _SMS_V1208_OWNED_POINTER = True
        _POINTER_REGISTERED = True
    else:
        # Preserve an existing/foreign property unchanged.  Never delete by name.
        _SMS_V1208_OWNED_POINTER = False
        _POINTER_REGISTERED = False
    apply_settings()
    sync_settings_handlers(getattr(bpy, 'context', None))


def unregister():
    global _POINTER_REGISTERED, _HANDLERS_REGISTERED, _SMS_V1208_OWNED_POINTER
    _unregister_settings_handlers()
    _HANDLERS_REGISTERED = False
    if _SMS_V1208_OWNED_POINTER and hasattr(bpy.types.WindowManager, 'sss_material_studio'):
        try:
            del bpy.types.WindowManager.sss_material_studio
        except Exception:
            pass
    _SMS_V1208_OWNED_POINTER = False
    _POINTER_REGISTERED = False

# Central Suite persistence is authoritative; no per-feature resident handlers.
def sync_settings_handlers(context=None) -> None:
    global _HANDLERS_REGISTERED
    _unregister_settings_handlers()
    enabled = False
    try:
        from . import preferences as _suite_preferences
        owner = _suite_preferences.addon_preferences_owner(context or getattr(bpy, 'context', None))
        enabled = bool(getattr(owner, 'material_studio_settings_handlers', False)) if owner is not None else False
    except Exception:
        enabled = False
    _HANDLERS_REGISTERED = _register_settings_handlers() if enabled else False


_sync_settings_handlers = sync_settings_handlers
