"""Language helpers."""

from __future__ import annotations

import locale as _py_locale
import re
import textwrap
from functools import lru_cache


_JA_RE = re.compile(r"[ぁ-んァ-ヴー一-龠々〆〤]")
_LATIN_RE = re.compile(r"[A-Za-z]")
_LANG_MARKER_RE = re.compile(r"(?P<tag>\b(?:EN|JP|JA)\b)\s*:\s*", re.IGNORECASE)


# Fixed English -> Japanese UI translations used for bundled tools that still
# expose Blender RNA strings directly.  The English source text remains the
# canonical message id so Blender's own translation system can display only the
# active interface language instead of bilingual labels.
_STATIC_EN_JA: dict[str, str] = {
    # Shared / integrated UI
    "Tool Info": "機能情報",
    "Smart Shader Tool": "スマートシェーダー機能",
    "Unknown": "不明",
    "Menu": "メニュー",
    "No special flags": "特記事項なし",
    "shader-driven": "シェーダー駆動",
    "Operator not found": "オペレーターが見つかりません",
    "Proxy draw failed": "プロキシ描画に失敗しました",

    # Material Library
    "Material Library": "マテリアルライブラリ",
    "Material Library VX": "マテリアルライブラリ VX",
    "Search": "検索",
    "Find By Name": "名前で検索します",
    "Linked": "リンク",
    "Link the material": "マテリアルをリンクします",
    "Force Import": "強制インポート",
    "Use Scene Materials by default": "既定でシーン内マテリアルを使います",
    "Filter": "フィルター",
    "Filter Categories": "カテゴリを絞り込みます",
    "show_prefs": "設定表示",
    "Preferences": "設定",
    "Last Selected": "最後の選択",
    "Hide Search": "検索を隠す",
    "Use Blender Search Only": "Blender検索のみを使います",
    "Libraries Menu": "ライブラリメニュー",
    "Categories Menu": "カテゴリメニュー",
    "All": "すべて",
    "Add active material": "アクティブマテリアルを追加",
    "Remove material from library": "ライブラリからマテリアルを削除",
    "Reload library": "ライブラリを再読み込み",
    "Apply material": "マテリアルを適用",
    "Preview selected material": "選択マテリアルをプレビュー",
    "Flush unused materials": "未使用マテリアルを解放",
    "New": "新規",
    "Category": "カテゴリ",
    "Command": "コマンド",
    "Library": "ライブラリ",
    "New Library": "新規ライブラリ",
    "Add To Library": "ライブラリへ追加",
    "Apply To Selected": "選択へ適用",
    "Reload Material": "マテリアルを再読み込み",
    "Preview Material": "マテリアルをプレビュー",
    "Remove Preview": "プレビューを削除",
    "Remove Material": "マテリアルを削除",
    "Settings": "設定",
    "Category:": "カテゴリ:",
    "Category Tools:": "カテゴリツール:",
    "Set Type": "種類を設定",
    "Refresh Material Libraries": "マテリアルライブラリを更新",
    "Choose Material Library Folder": "マテリアルライブラリフォルダを選択",
    "Reset Material Library Folder": "マテリアルライブラリフォルダをリセット",
    "Additional Path": "追加パス",
    "User defined path to .blend libraries files": "ユーザー定義の .blend ライブラリファイル用パスです",
    "Select a Library": "ライブラリを選択してください",

    # Math Controller
    "Math Controller": "数式コントローラー",
    "Add Math Controller": "数式コントローラーを追加",
    "Num": "番号",
    "Name": "名前",
    "Formula": "数式",
    "Last_Formula": "前回の数式",
    "Add": "追加",
    "Remove": "削除",
    "Advanced Formula Editor": "高度な数式エディター",
    "Expand to Group Node": "グループノードへ展開",
    "Tree Kind": "ツリー種類",
    "Shader": "シェーダー",
    "Geometry": "ジオメトリ",
    "Compositor": "コンポジター",
    "Add to the active object material node tree": "アクティブオブジェクトのマテリアルノードツリーへ追加します",
    "Add to the active Geometry Nodes modifier node group": "アクティブな ジオメトリノード モディファイアのノードグループへ追加します",
    "Add to the active scene compositor node tree": "現在シーンのコンポジターノードツリーへ追加します",
    "Clear the formula first.": "先に数式を空にしてください。",

    "Mode": "モード",
    "Nodes": "ノード",
    "Trees": "ツリー",
    "Selected nodes in the current node tree": "現在のノードツリー内の選択ノードです",
    "All node trees in the current .blend file": "現在の .blend ファイル内の全ノードツリーです",
    "What to arrange": "整列対象を選びます",
    "Spacing": "間隔",
    "Space between nodes": "ノード間の間隔です",
    "Iterations": "反復回数",
    "Number of times to reduce crossings between links (higher values give less crossings, but are slower). To resolve all unnecessary crossings, this option may need to be set very high (since it is probabilistic)": "リンク交差を減らす試行回数です。値を大きくすると交差は減りやすくなりますが遅くなります。不要な交差をすべて解消するには、確率的処理のため高い値が必要になる場合があります。",
    "Bottom Left": "左下",
    "Bottom Right": "右下",
    "Top Left": "左上",
    "Top Right": "右上",
    "Balanced": "バランス",
    "Combine four extreme layouts, evening out their directional tendencies": "4方向の極端なレイアウトを組み合わせ、方向の偏りを均します",
    "Node Alignment": "ノード配置",
    "Direction of layout": "レイアウト方向です",
    "Socket Alignment": "ソケット配置",
    "Method to align sockets with other sockets": "ソケット同士を揃える方法です",
    "None": "なし",
    "Only try to align the tops of nodes": "ノード上端のみを揃えます",
    "Moderate": "標準",
    "Align sockets or node tops depending on the heights of the nodes": "ノードの高さに応じてソケットまたはノード上端を揃えます",
    "Full": "完全",
    "Always try to align sockets with other sockets": "常にソケット同士を揃えます",
    "Add Reroutes": "リルートを追加",
    "Insert reroutes into links": "リンクへリルートを挿入します",
    "Place Reroutes Outside Frames": "リルートをフレーム外へ配置",
    "Always attach reroutes to the lowest common frame of the nodes they connect": "接続先ノードの共通する最下位フレームへリルートを配置します",
    "Stack Collapsed Nodes": "折りたたみノードを積み重ね",
    "Stack collapsed math and vector math nodes on top of one another": "折りたたまれた Math / Vector Math ノードを重ねて配置します",
    "Spacing Y Factor": "Y間隔係数",
    "Factor for vertical spacing between stacked nodes": "積み重ねたノードの縦方向間隔係数です",
    "What to recenter": "再センター対象を選びます",
    "Enable Alt+G Hotkey": "Alt+G ホットキーを有効化",
    "Automatic shortcut registration is disabled. Use Blender Preferences > Keymap to assign Alt+G manually if you want this command on a shortcut.": "自動ショートカット登録は無効です。このコマンドをショートカット化したい場合は、Blender プリファレンス > キーマップ で Alt+G を手動割り当てしてください。",
    "Origin": "基準",
    "Center": "中心",
    "Move selected nodes by the difference of their average location from (0, 0)": "選択ノードの平均位置と (0, 0) の差分だけ移動します",
    "Active Output": "アクティブ出力",
    "Move selected nodes by the difference of the active output(s) location from (0, 0)": "アクティブ出力ノードの位置と (0, 0) の差分だけ移動します",
    "Active Node": "アクティブノード",
    "Move selected nodes by the difference of the active node's location from (0, 0)": "アクティブノードの位置と (0, 0) の差分だけ移動します",
    "Arrange": "整列",
    "Alignment": "配置",
    "Sockets": "ソケット",
    "Crossed Links": "交差リンク",
    "Reroutes": "リルート",
    "Place Outside Frames": "フレーム外へ配置",
    "Collapsed Nodes": "折りたたみノード",
    "Arrange Selected Nodes": "選択ノードを整列",
    "Recenter": "再センター",
    "Recenter Selected Nodes": "選択ノードを再センター",
    "Arrange Selected": "選択ノードを整列",
    "Arrange selected nodes": "選択ノードを整列します",
    "Arrange All Node Trees": "全ノードツリーを整列",
    "Arrange all node trees in the current .blend file with the below settings.\nWarning: May be slow if there are expensive node trees, due to re-evaluation": "現在の .blend ファイル内の全ノードツリーを下の設定で整列します。\n警告: 再評価により、重いノードツリーがある場合は遅くなることがあります。",
    "Recenter Selected": "選択ノードを再センター",
    "Clear the locations of selected nodes": "選択ノードの位置をクリアします",
    "Recenter All Node Trees": "全ノードツリーを再センター",
    "Recenter all node trees in the current .blend file with the below settings": "現在の .blend ファイル内の全ノードツリーを下の設定で再センターします",
    "Active node tree is undefined.": "アクティブノードツリーが未定義です。",
    "No nodes selected": "ノードが選択されていません",
    "No valid nodes selected": "有効なノードが選択されていません",
    "No valid active node": "有効なアクティブノードがありません",
    "No active output": "アクティブ出力がありません",

    "Random Color": "ランダムカラー",
    "Copy Color from Active Node": "アクティブノードから色をコピー",
    "Set": "設定",
    "Remove Color": "色を削除",
    "Set Color 1": "色1を設定",
    "Set Color": "色を設定",
    "Node Color": "ノードカラー",
    "Set random color": "ランダムカラーを設定",
    "Precise Colors": "精密カラー",
    "Quick Colors": "クイックカラー",
    "Copy from Active": "アクティブからコピー",
    "Random": "ランダム",
    "Set recommended key": "推奨キーを設定",
    "Press any key to store it as the recommended manual shortcut": "任意のキーを押すと、推奨手動ショートカットとして保存します",
    "Manual Pie Hotkey Setup": "手動パイホットキー設定",
    "Automatic keymap registration is disabled. Keep your preferred pie-menu shortcut settings here and register them manually in Preferences > Keymap.": "自動キーマップ登録は無効です。ここに好みのパイメニュー用ショートカット設定を保存し、プリファレンス > キーマップ で手動登録してください。",
    "Pie Menu Hotkey": "パイメニューホットキー",
    "Recommended manual shortcut key for the precise pie menu": "精密パイメニュー用の推奨手動ショートカットキーです",
    "Capturing Key": "キー取得中",
    "Ctrl": "Ctrl",
    "Alt": "Alt",
    "Shift": "Shift",
    "Pie Menu Hotkey 2": "パイメニューホットキー2",
    "Recommended manual shortcut key for the quick pie menu": "クイックパイメニュー用の推奨手動ショートカットキーです",
    "Capturing Key 2": "キー取得中2",
    "Manual keymap setup only": "手動キーマップ設定のみ",
    "This add-on no longer creates or removes Blender keymaps automatically.": "このアドオンは Blender キーマップを自動作成・削除しません。",
    "Pick your preferred keys below, then add them manually in Preferences > Keymap under Node Editor.": "下で好みのキーを選び、プリファレンス > キーマップ の ノードエディター で手動追加してください。",
    "Recommended shortcut setup": "推奨ショートカット設定",
    "Quick Color Pie Menu": "クイックカラーパイメニュー",
    "Precise Color Pie Menu": "精密カラーパイメニュー",
    "Color 1": "色1",
    "Color 2": "色2",
    "Color 3": "色3",
    "Color 4": "色4",
    "Color 5": "色5",

    "Template": "テンプレート",
    "No node tree available": "ノードツリーが利用できません",
    "Incompatible node type": "互換性のないノードタイプです",
    "No nodes available": "利用可能なノードがありません",
    "Dimension": "次元",

    # PBR Lookdev
    "PBR Lookdev": "PBR ルックデブ",
    "Layered PBR Lookdev panel integrated into Smart Shader": "レイヤー式 PBR ルックデブ パネルを スマートシェーダーに統合したものです",
    "Texture Layer": "テクスチャレイヤー",
    "Image": "画像",
    "UDIM": "UDIM",
    "Treat as UDIM tile sequence": "UDIM タイル連番として扱います",
    "Treat mask as UDIM tile sequence": "マスクを UDIM タイル連番として扱います",
    "Treat this path as a UDIM tile sequence": "このパスを UDIM タイル連番として扱います",
    "Min": "最小",
    "Max": "最大",
    "Black point": "黒点",
    "White point": "白点",
    "Mask black point": "マスク黒点",
    "Mask white point": "マスク白点",
    "Strength": "強度",
    "Hue": "色相",
    "Saturation": "彩度",
    "Value": "明度",
    "Contrast": "コントラスト",
    "Gamma": "ガンマ",
    "Mask": "マスク",
    "Invert": "反転",
    "Override Mapping": "マッピングを上書き",
    "X": "X",
    "Y": "Y",
    "Lock": "ロック",
    "Rot": "回転",
    "Rotation": "回転",
    "Mask Type": "マスク種類",
    "Scale": "スケール",
    "Detail": "詳細",
    "Roughness": "粗さ",
    "Distortion": "歪み",
    "Wave Type": "波形種類",
    "Wave Profile": "波形プロファイル",
    "Gradient Type": "グラデーション種類",
    "Feature": "特徴",
    "Distance": "距離",
    "Randomness": "ランダム性",
    "Distribution": "分布",
    "SSS Method": "SSS方式",
    "Folder": "フォルダ",
    "Layer Name": "レイヤー名",
    "Normal Strength": "ノーマル強度",
    "Bump Strength": "バンプ強度",
    "AO Strength": "AO強度",
    "Emission Strength": "発光強度",
    "Roughness Bias": "粗さバイアス",
    "Metallic Bias": "メタリックバイアス",
    "Midlevel": "中間値",
    "SSS Scale": "SSSスケール",
    "Blend": "ブレンド",
    "New PBR Material": "新規PBRマテリアル",
    "Create a new named material": "名前付きの新規マテリアルを作成します",
    "Add Layer": "レイヤーを追加",
    "Add a new shader layer": "新しいシェーダーレイヤーを追加します",
    "Remove Layer": "レイヤーを削除",
    "Move Layer": "レイヤーを移動",
    "Scan Folder": "フォルダをスキャン",
    "Clear Layer": "レイヤーをクリア",
    "Add Overlay": "オーバーレイを追加",
    "Add an image overlay with blend mask for this channel": "このチャンネルへブレンドマスク付き画像オーバーレイを追加します",
    "Remove Overlay": "オーバーレイを削除",
    "Move Overlay": "オーバーレイを移動",
    "Duplicate Layer": "レイヤーを複製",
    "Duplicate this shader layer with all its settings": "このシェーダーレイヤーをすべての設定ごと複製します",
    "Set Tiling": "タイリングを設定",
    "Set tiling to a preset value": "タイリングをプリセット値へ設定します",
    "Collapse All": "すべて折りたたむ",
    "Collapse every layer, map group and overlay": "すべてのレイヤー、マップグループ、オーバーレイを折りたたみます",
    "Build Material": "マテリアルを構築",
    "Build the full layered shader network": "完全なレイヤー式シェーダーネットワークを構築します",
    "Rebuild": "再構築",
    "Force full rebuild of the shader network": "シェーダーネットワークを完全に再構築します",
    "Toggle UI": "UIを切り替え",
    "Wave": "波形",
    "Profile": "プロファイル",
    "Type": "種類",
    "Range:": "範囲:",
    "Color Correction": "色補正",
    "Mapping": "マッピング",
    "Tiling": "タイリング",
    "Value:": "値:",
    "Bias:": "バイアス:",
    "Strength:": "強度:",
    "Scale:": "スケール:",
    "Midlevel:": "中間値:",
    "Scan": "スキャン",
    "Clear": "クリア",
    "Preset:": "プリセット:",
    "Offset": "オフセット",
    "Blend Mode": "ブレンドモード",
    "Mask Transform": "マスク変形",
    "No active material": "アクティブマテリアルなし",
    "Rebuild Network": "ネットワークを再構築",
    "Maps": "マップ",
    "Layer Mask": "レイヤーマスク",
    "connected": "接続あり",
    "none": "なし",
    "Layer": "レイヤー",
    "BANDS": "バンド",
    "RINGS": "リング",
    "Bands": "バンド",
    "Rings": "リング",
    "Bandsaw": "バンド鋸波",
    "Ringsaw": "リング鋸波",
    "Sine": "サイン",
    "Saw": "鋸波",
    "Triangle": "三角波",
    "Linear": "線形",
    "Quadratic": "二次",
    "Easing": "イージング",
    "Diagonal": "斜め",
    "Spherical": "球状",
    "Quadratic Sphere": "二次球状",
    "Radial": "放射状",
    "Distance to Edge": "エッジまでの距離",
    "N-Sphere Radius": "N球半径",
    "Euclidean": "ユークリッド",
    "Manhattan": "マンハッタン",
    "Chebychev": "チェビシェフ",
    "Minkowski": "ミンコフスキー",
    "Mix": "ミックス",
    "Multiply": "乗算",
    "Multiply (darken)": "乗算（暗く）",
    "Add (brighten)": "加算（明るく）",
    "Screen": "スクリーン",
    "Screen (lighten)": "スクリーン（明るく）",
    "Overlay": "オーバーレイ",
    "Soft Light": "ソフトライト",
    "Soft light": "ソフトライト",
    "Principled BSDF": "プリンシプルBSDF",
    "Full PBR shader": "フルPBRシェーダー",
    "Glass BSDF": "グラスBSDF",
    "Refractive glass shader": "屈折ガラスシェーダー",
    "Emission": "発光",
    "Emissive light shader": "発光ライトシェーダー",
    "Diffuse BSDF": "ディフューズBSDF",
    "Simple diffuse shader": "単純なディフューズシェーダー",
    "Subsurface Scattering": "サブサーフェス散乱",
    "SSS shader": "SSSシェーダー",
    "Base Color": "ベースカラー",
    "Diffuse Roughness": "拡散粗さ",
    "Metallic": "メタリック",
    "IOR": "IOR",
    "Specular": "スペキュラー",
    "Specular IOR Level": "スペキュラーIORレベル",
    "Specular Tint": "スペキュラーティント",
    "Anisotropic": "異方性",
    "Anisotropic Rotation": "異方性回転",
    "Normal": "ノーマル",
    "Bump": "バンプ",
    "Coat Weight": "コート量",
    "Coat Roughness": "コート粗さ",
    "Coat IOR": "コートIOR",
    "Coat Normal": "コートノーマル",
    "Sheen Weight": "シーン量",
    "Sheen Roughness": "シーン粗さ",
    "Sheen Tint": "シーンティント",
    "Emission Color": "発光カラー",
    "Opacity / Alpha": "不透明度/アルファ",
    "Ambient Occ.": "アンビエント遮蔽",
    "Subsurface Weight": "サブサーフェス量",
    "Transmission / Translucency": "透過/半透明",
    "Displacement": "ディスプレイスメント",
    "Glossiness": "光沢度",
    "SSS Radius": "SSS半径",
    "SSS Anisotropy": "SSS異方性",
    "SSS IOR": "SSS IOR",
    "Thin Film Thickness": "薄膜厚み",
    "Thin Film IOR": "薄膜IOR",
    "Non-Color": "非カラー",
    "COLOR": "カラー",
    "FLOAT": "浮動小数",
    "NONE": "なし",
    "Metal / Specular": "金属/スペキュラー",
    "Normal / Bump": "ノーマル/バンプ",
    "Coat": "コート",
    "Sheen": "シーン",
    "Transparency": "透明",
    "Subsurface": "サブサーフェス",
    "Thin Film": "薄膜",

    # Reports and status strings
    "Audit complete.": "監査が完了しました。",
    "Library audit complete.": "ライブラリ監査が完了しました。",
    "No coherent texture-library groups were found.": "一貫したテクスチャライブラリグループが見つかりませんでした。",
    "Coverage notes written.": "対応メモを書き出しました。",
    "OSL helper added.": "OSL補助を追加しました。",
    "Self check complete.": "自己診断が完了しました。",
    "No usable texture-set files selected.": "使用可能なテクスチャセットファイルが選択されていません。",
    "Cleanup preview ready.": "クリーンアッププレビューの準備ができました。",
    "Select a mesh first.": "先にメッシュを選択してください。",
    "Cannot remove last layer.": "最後のレイヤーは削除できません。",
    "Set a valid folder.": "有効なフォルダを設定してください。",
    "Rebuilt.": "再構築しました。",
}


# Additional one-language UI translations for legacy migrated tools and runtime reports.
_STATIC_EN_JA.update({
    "Smart Shader": "Smart Shader",
    'Smart Shader > Material Library': 'スマートシェーダー > マテリアルライブラリ',
    'Smart Shader > Math Controller': 'スマートシェーダー > 数式コントローラー',
    'Smart Shader > PBR Lookdev': 'スマートシェーダー > PBR ルックデブ',
    "Smart Shader": "Smart Shader",
    "View3D > Sidebar > Smart Shader": "3Dビュー > サイドバー > スマートシェーダー",
    "View3D > Sidebar > Smart Shader": "3Dビュー > サイドバー > スマートシェーダー",
    "Smart Shader exposes its Smart Shader settings in the 3D View Sidebar N-panel category Smart Shader.": "スマートシェーダーの設定を 3Dビューサイドバーの Nパネルカテゴリ『スマートシェーダー』に表示します。",
    "Blender 5 material platform implemented as standard 3D View and Shader Editor Sidebar N-panel tools": "通常の3DビューとシェーダーエディターのサイドバーNパネルとして実装した Blender 5 用マテリアルプラットフォームです。",
    "Tools": "ツール",
    "Bundled Features": "同梱機能",
    "Loaded": "読み込み済み",
    "On-demand": "使用時に読み込み",
    "Unsupported platform": "現在の OS・CPU では無効",
    "Load failed": "読み込み失敗",
    "Superseded or deduplicated": "上位互換または重複のため統合対象外",
    "No direct operator or menu entry was found.": "直接実行できるオペレーターまたはメニュー項目が見つかりませんでした。",
    "Menus": "メニュー",
    "Operators": "オペレーター",
    "Open a Node Editor area for this tool, then try again.": "この機能は ノードエディター を開いた状態で実行してください。",
    "Open a 3D View area for this tool, then try again.": "この機能は 3Dビューポート を開いた状態で実行してください。",
    "Always Active": "常時有効",
    "Automatic initialization is pending for this tool.": "このツールは自動初期化待機中です。",
    "Quick Access": "クイックアクセス",
    "This package is bundled, but it is disabled on the current platform.": "このパッケージは同梱されていますが、現在のプラットフォームでは無効です。",
    "This package is intentionally disabled because a duplicate or superseded version was skipped.": "重複または上位互換版があるため、このパッケージは意図的に無効化されています。",
    "Original panel has no draw function.": "元パネルに描画処理がありません。",

    "Reusable .blend material library workflow integrated into Smart Shader": "再利用可能な .blend マテリアルライブラリのワークフローを スマートシェーダーに統合したものです",
    "Library already exists.": "ライブラリは既に存在します。",
    "There was an error creating the file. Make sure you run Blender with admin rights.": "ファイル作成中にエラーが発生しました。管理者権限で Blender を実行しているか確認してください。",
    "Library added": "ライブラリを追加しました",
    "Library not found!.": "ライブラリが見つかりません。",
    "There was an error.": "エラーが発生しました。",
    "Select a material": "マテリアルを選択してください",
    "Select a material from the list.": "一覧からマテリアルを選択してください。",
    "Can't preview on EDIT MODE": "編集モードではプレビューできません",
    "Please select an object": "オブジェクトを選択してください",
    "Apply is disabled for the Material Preview Object": "マテリアルプレビュー用オブジェクトには適用できません",
    "Select a material from the scene.": "シーン内のマテリアルを選択してください。",
    "Save this file before export.": "エクスポート前にこのファイルを保存してください。",
    "Cannot export linked materials.": "リンクマテリアルはエクスポートできません。",
    "Material added.": "マテリアルを追加しました。",
    "Save Material Error: Run Blender with administrative privileges.": "マテリアル保存エラー: Blender を管理者権限で実行してください。",
    "There was an error saving the material": "マテリアル保存中にエラーが発生しました",
    "Material libraries refreshed.": "マテリアルライブラリを更新しました。",
    "Material library folder reset to default.": "マテリアルライブラリフォルダを既定値へ戻しました。",
    "Library Folder": "ライブラリフォルダ",
    "Startup Optimization": "起動最適化",
    "Main Library Tools": "メインライブラリツール",

    "Formula-driven node controller tools integrated into Smart Shader": "数式駆動ノードコントローラーツールを スマートシェーダーに統合したものです",
    "Functions": "関数",
    "Comparison": "比較",
    "Rounding": "丸め",
    "Trigonometric": "三角関数",
    "Conversion": "変換",
    "Subtract": "減算",
    "Multiply Add": "乗算加算",
    "Logarithm": "対数",
    "Square Root": "平方根",
    "Inverse Square Root": "逆平方根",
    "Absolute": "絶対値",
    "Exponent": "指数",
    "Minimum": "最小",
    "Maximum": "最大",
    "Less Than": "小なり",
    "Greater Than": "大なり",
    "Sign": "符号",
    "Compare": "比較",
    "Smooth Minimum": "スムーズ最小",
    "Smooth Maximum": "スムーズ最大",
    "Round": "四捨五入",
    "Floor": "床関数",
    "Ceil": "天井関数",
    "Truncate": "切り捨て",
    "Fraction": "小数部",
    "Modulo": "剰余",
    "Floored Modulo": "床剰余",
    "Wrap": "ラップ",
    "Snap": "スナップ",
    "Ping-Pong": "ピンポン",
    "Tangent": "タンジェント",
    "Arcsine": "アークサイン",
    "Arccosine": "アークコサイン",
    "Arctangent": "アークタンジェント",
    "Arctan2": "アークタンジェント2",
    "Hyperbolic Sine": "双曲線サイン",
    "Hyperbolic Cosine": "双曲線コサイン",
    "Hyperbolic Tangent": "双曲線タンジェント",
    "To Radians": "ラジアンへ変換",
    "To Degrees": "度へ変換",
    "Invalid Formula": "無効な数式です",
    "Variable name too long (max 60 chars)": "変数名が長すぎます（最大60文字）",
    "Active object needs an active material.": "アクティブオブジェクトにアクティブマテリアルが必要です。",
    "Active object needs a Geometry Nodes modifier with a node group.": "アクティブオブジェクトにノードグループ付きの ジオメトリノード モディファイアが必要です。",
    "Target node tree was not found.": "追加先ノードツリーが見つかりません。",

    "Preset Colors": "プリセット色",
    "Copy Active": "アクティブからコピー",
    "Pie Menus": "パイメニュー",
    "Manual Hotkey Setup": "手動ホットキー設定",

    "Not set": "未設定",
    "Templates": "テンプレート一覧",
    "Error": "エラー",


    "Image": "画像",
    "Use an image texture as mask": "画像テクスチャをマスクとして使います",
    "Noise": "ノイズ",
    "Procedural noise texture": "プロシージャルノイズテクスチャ",
    "Procedural wave texture": "プロシージャル波形テクスチャ",
    "Gradient": "グラデーション",
    "Procedural gradient": "プロシージャルグラデーション",
    "Voronoi": "ボロノイ",
    "Voronoi / cellular texture": "ボロノイ／セル状テクスチャ",
    "Smooth F1": "スムーズF1",
    "F1": "F1",
    "F2": "F2",
    "Blend using mask": "マスクを使ってブレンドします",
    "Base Layer": "ベースレイヤー",
    "Shader": "シェーダー",
    "Multiply": "乗算",
    "Add": "追加",
    "Divide": "除算",
    "Sine": "サイン",
    "Cosine": "コサイン",
    "Alpha": "アルファ",
    "Color": "カラー",
    "Clearcoat": "クリアコート",
    "Clearcoat Roughness": "クリアコート粗さ",
    "Clearcoat Normal": "クリアコートノーマル",
    "Subsurface Radius": "サブサーフェス半径",
    "Subsurface Scale": "サブサーフェススケール",
    "Subsurface Anisotropy": "サブサーフェス異方性",
    "Transmission Weight": "透過量",
    "Transmission": "透過",
    "Anisotropy": "異方性",

    "Custom preset not found.": "カスタムプリセットが見つかりません。",
    "Select a real preset first.": "先に実際のプリセットを選択してください。",
    "Assignment rule not found.": "割当ルールが見つかりません。",
    "Manifest payload must be a JSON object.": "マニフェスト本体は JSON オブジェクト である必要があります。",
    "No active material.": "アクティブマテリアルがありません。",
})


_STATIC_EN_JA.update({
    "Fac": "係数",
    "Range": "範囲",
    "Scale Ratio": "スケール比",
    "Detail 1": "詳細1",
    "Detail 2": "詳細2",
    "Result": "結果",
    "From Min": "変換元最小",
    "From Max": "変換元最大",
    "Lacunarity": "ラキュナリティ",
    "Gain": "ゲイン",
    "Input Map": "入力マップ",
    "Division": "分割",
    "Fix Range": "範囲補正",
    "Cells": "セル",
    "Falloff": "減衰",
    "Ratio": "比率",
    "Spread": "広がり",
    "Count": "数",
    "Variation": "変化量",
    "Steps": "段数",
    "Line Thickness": "線の太さ",
    "Voxel Position": "ボクセル位置",
    "Voxel Vector": "ボクセルベクトル",
    "min": "最小",
    "max": "最大",
    "Use the scalar value W as input": "スカラー値 W を入力として使います",
    "Use the 2D vector (X,Y) as input. The Z component is ignored": "2D ベクトル (X,Y) を入力として使います。Z 成分は無視されます",
    "Use the 3D vector (X,Y,Z) as input": "3D ベクトル (X,Y,Z) を入力として使います",
    "Use the 4D vector (X,Y,Z,W) as input": "4D ベクトル (X,Y,Z,W) を入力として使います",
})


_STATIC_EN_JA.update({
    "Multiscatter GGX": "マルチスキャッター GGX",
    "Christensen-Burley": "Christensen-Burley",
    "Random Walk": "ランダムウォーク",
    "Random Walk (Skin)": "ランダムウォーク（スキン）",
    "Up": "上へ",
    "Down": "下へ",
})


_STATIC_EN_JA.update({
    # General controls and runtime feature toggles
    "Dashboard": "ダッシュボード",
    "Active": "アクティブ",
    "Managed": "管理中",
    "Safe": "安全",
    "Assign": "割当",
    "Run": "実行",
    "Key": "キー",
    "Enabled": "有効",
    "Disabled": "無効",
    "Toggle Feature": "機能を切り替え",
    "Switch a resident feature on or off and save the setting immediately.": "常時機能の有効 / 無効を切り替え、設定を即時保存します。",
    "Click to switch this feature between enabled and disabled.": "クリックすると、この機能の有効 / 無効を切り替えます。",
    "Toggle a resident Smart Shader feature. The setting is saved immediately.": "スマートシェーダーの常時機能を切り替えます。設定は即時保存されます。",
    "The selected feature could not be changed.": "選択した機能を変更できませんでした。",
    "Feature setting saved.": "機能設定を保存しました。",
    "Library Path": "ライブラリ保存先",
    "Material Library Folder": "マテリアルライブラリフォルダ",
    "Auto refresh on file load": "ファイル読込時に自動更新",
    "Precise pie key": "詳細パイキー",
    "Quick pie key": "簡易パイキー",
    "Enable background callbacks": "バックグラウンドコールバックを有効化",
    "Vector": "ベクトル",
    "W": "W",
    "Create Library": "ライブラリ作成",
    "Add Active Material": "アクティブマテリアル追加",
    "Apply Selected Material": "選択マテリアルを適用",
    "Show All Categories": "すべてのカテゴリを表示",
    "Set Category": "カテゴリを設定",
    "Create Item": "項目作成",
    "Remove Item": "アイテムを削除",
})

_STATIC_JA_EN: dict[str, str] = {ja: en for en, ja in _STATIC_EN_JA.items() if ja}
# Blender's translation table is shared by every add-on, so RNA names of this
# add-on use their own context and cannot be replaced by another add-on's entry.
RNA_TEXT_CONTEXT = "SmartShaderSuite"
# Everyday words whose wording here only fits this add-on (a sort mode called
# "Nodes", a scope called "Scene"). Blender's table is shared by every add-on, so
# they stay in this add-on's own context and elsewhere Blender's wording is kept.
_PRIVATE_CONTEXT_ONLY = frozenset((
    "Unknown", "Preferences", "Add", "Nodes", "Full", "Origin", "Set", "Shift", "Strength", "Value", "Detail",
    "Feature", "Type", "Profile", "Wave", "Triangle", "Linear", "Radial", "Emission", "Metallic", "Transparency",
    "Loaded", "Absolute", "Less Than", "Greater Than", "Round", "Floor", "Rounding", "Templates", "Steps", "Up",
    "Down", "Assign", "Run", "Scope", "Object", "Intersection", "Taper", "Section", "Build", "Coverage",
    "Selected Objects", "Scene", "Sort", "Users", "Missing", "Append", "Fake User", "Merge", "Replace",
    "Selected", "Limit", "Create", "Production", "General", "Edge", "Facing", "On", "Off", "Advanced", "Effects",
    "Generated", "Extend", "Dimensions", "Frequency", "Orientation", "Colors", "Lighting", "Cast Shadow",
    "Target Object", "Target Material", "Detail Scale", "Detail Strength", "Transmission", "Iterations",
    "Formula", "Folder", "Normal Strength", "Emission Strength", "Randomness", "Wood", "Stone", "Clay", "Skin",
))


def drop_private_words(table: dict) -> None:
    """Remove the words above from a table registered in the shared contexts."""
    for key in [key for key in table if key[1] in _PRIVATE_CONTEXT_ONLY and key[0] in ("*", "Operator")]:
        del table[key]


_TRANSLATION_CONTEXTS = (
    RNA_TEXT_CONTEXT,
    "*",
    "Operator",
    "RNA",
    "UI_Events_KeyMaps",
    "WindowManager",
    "Addon",
)


def _remember_pair(en: str, ja: str) -> None:
    """Remember a runtime English/Japanese pair for Blender's translation table."""
    en_text = str(en or "").strip()
    ja_text = str(ja or "").strip()
    if not en_text or not ja_text or en_text == ja_text:
        return
    if len(en_text) > 900 or len(ja_text) > 900:
        return
    cache_changed = False
    try:
        before = len(_STATIC_EN_JA) + len(_STATIC_JA_EN)
        _STATIC_EN_JA.setdefault(en_text, ja_text)
        _STATIC_JA_EN.setdefault(ja_text, en_text)
        cache_changed = (len(_STATIC_EN_JA) + len(_STATIC_JA_EN)) != before
    except NameError:
        # During module bootstrap the reverse table may not exist yet.
        before = len(_STATIC_EN_JA)
        _STATIC_EN_JA.setdefault(en_text, ja_text)
        cache_changed = len(_STATIC_EN_JA) != before
    if cache_changed:
        try:
            _static_lookup_cached.cache_clear()
        except Exception:
            pass


def ja_for_en(text: str) -> str:
    """Return the registered Japanese string for an English UI string."""
    raw = str(text or "")
    return _STATIC_EN_JA.get(raw, raw)


def en_for_ja(text: str) -> str:
    """Return the registered English string for a Japanese UI string."""
    raw = str(text or "")
    return _STATIC_JA_EN.get(raw, raw)


def _static_lookup(text: str) -> str:
    raw = str(text or "")
    if not raw:
        return raw
    return _static_lookup_cached(raw, locale_is_japanese() and not _REGISTERING_RNA_TEXT)


@lru_cache(maxsize=8192)
def _static_lookup_cached(raw: str, is_japanese: bool) -> str:
    table = _STATIC_EN_JA if is_japanese else _STATIC_JA_EN
    if raw in table:
        return table[raw]
    stripped = raw.strip()
    if stripped in table:
        translated = table[stripped]
        return raw.replace(stripped, translated, 1)
    dynamic = _dynamic_static_lookup(raw, is_japanese)
    if dynamic != raw:
        return dynamic
    return raw




def _jp_bool_word(value: str) -> str:
    lowered = str(value or "").strip().lower()
    if lowered == "true":
        return "はい"
    if lowered == "false":
        return "いいえ"
    return str(value or "")


@lru_cache(maxsize=4096)
def _dynamic_static_lookup(text: str, is_japanese: bool) -> str:
    raw = str(text or "")
    if not raw or not is_japanese:
        return raw
    patterns = (
        (r"^(.+) created\. Assigned=(True|False)$", lambda m: f"{m.group(1)} を作成しました。割当={_jp_bool_word(m.group(2))}"),
        (r"^Photo-to-PBR created: (.+)$", lambda m: f"Photo-to-PBR を作成しました: {m.group(1)}"),
        (r"^Applied preset to (.+)$", lambda m: f"プリセットを適用しました: {m.group(1)}"),
        (r"^Captured (.+)$", lambda m: f"取得しました: {m.group(1)}"),
        (r"^Saved custom preset: (.+)$", lambda m: f"カスタムプリセットを保存しました: {m.group(1)}"),
        (r"^Deleted custom preset: (.+)$", lambda m: f"カスタムプリセットを削除しました: {m.group(1)}"),
        (r"^Assigned to (\d+) object\(s\)$", lambda m: f"{m.group(1)} 個のオブジェクトへ割り当てました"),
        (r"^Set active material: (.+)$", lambda m: f"アクティブマテリアルを設定しました: {m.group(1)}"),
        (r"^Selected (\d+) object\(s\)$", lambda m: f"{m.group(1)} 個のオブジェクトを選択しました"),
        (r"^Inventory target set: (.+)$", lambda m: f"インベントリ対象を設定しました: {m.group(1)}"),
        (r"^Cleared=(\d+) Removed=(\d+)$", lambda m: f"クリア={m.group(1)} 削除={m.group(2)}"),
        (r"^Compared (.+) -> (.+)$", lambda m: f"比較しました: {m.group(1)} -> {m.group(2)}"),
        (r"^Matches=(\d+)$", lambda m: f"一致={m.group(1)}"),
        (r"^Duplicated (.+)$", lambda m: f"複製しました: {m.group(1)}"),
        (r"^Localized (.+) -> (.+)$", lambda m: f"ローカル化しました: {m.group(1)} -> {m.group(2)}"),
        (r"^Localized variants created: (\d+)$", lambda m: f"ローカル化バリアントを作成しました: {m.group(1)}"),
        (r"^Renamed (.+)$", lambda m: f"名前を変更しました: {m.group(1)}"),
        (r"^Marked asset: (.+)$", lambda m: f"アセット化しました: {m.group(1)}"),
        (r"^Rebuilt (.+)$", lambda m: f"再構築しました: {m.group(1)}"),
        (r"^Rebuilt=(\d+) Failed=(\d+)$", lambda m: f"再構築={m.group(1)} 失敗={m.group(2)}"),
        (r"^Normalized (.+)$", lambda m: f"正規化しました: {m.group(1)}"),
        (r"^Imported (.+)$", lambda m: f"インポートしました: {m.group(1)}"),
        (r"^Saved scene variant: (.+)$", lambda m: f"シーンバリアントを保存しました: {m.group(1)}"),
        (r"^Applied scene variant: (.+)$", lambda m: f"シーンバリアントを適用しました: {m.group(1)}"),
        (r"^Deleted scene variant: (.+)$", lambda m: f"シーンバリアントを削除しました: {m.group(1)}"),
        (r"^Imported scene manifest: (\d+) materials$", lambda m: f"シーンマニフェストをインポートしました: {m.group(1)} 個のマテリアル"),
        (r"^Groups=(\d+)$", lambda m: f"グループ={m.group(1)}"),
        (r"^Built (\d+) materials$", lambda m: f"{m.group(1)} 個のマテリアルを構築しました"),
        (r"^Quick fixed: (.+)$", lambda m: f"クイック修復しました: {m.group(1)}"),
        (r"^Applied smart layer to: (.+)$", lambda m: f"スマートレイヤーを適用しました: {m.group(1)}"),
        (r"^Added mask utilities to: (.+)$", lambda m: f"マスク補助を追加しました: {m.group(1)}"),
        (r"^Applied layer recipe to: (.+)$", lambda m: f"レイヤーレシピを適用しました: {m.group(1)}"),
        (r"^Deleted layer recipe: (.+)$", lambda m: f"レイヤーレシピを削除しました: {m.group(1)}"),
        (r"^Selected (\d+) files$", lambda m: f"{m.group(1)} 個のファイルを選択しました"),
        (r"^Texture set built: (.+)$", lambda m: f"テクスチャセットを構築しました: {m.group(1)}"),
        (r"^Resolved=(\d+) Unresolved=(\d+)$", lambda m: f"解決={m.group(1)} 未解決={m.group(2)}"),
        (r"^Auto-layout moved (\d+) nodes$", lambda m: f"自動レイアウトで {m.group(1)} 個のノードを移動しました"),
        (r"^Pruned (\d+) nodes$", lambda m: f"{m.group(1)} 個のノードを整理しました"),
        (r"^Checked=(\d+) Fixed=(\d+)$", lambda m: f"確認={m.group(1)} 修正={m.group(2)}"),
        (r"^Links=(\d+) Nodes=(\d+)$", lambda m: f"リンク={m.group(1)} ノード={m.group(2)}"),
        (r"^Captured (\d+) materials$", lambda m: f"{m.group(1)} 個のマテリアルを取得しました"),
        (r"^Marked (\d+) assets$", lambda m: f"{m.group(1)} 個をアセット化しました"),
        (r"^slots=(\d+) faces=(\d+)$", lambda m: f"スロット={m.group(1)} 面={m.group(2)}"),
        (r"^Merged=(\d+) Groups=(\d+)$", lambda m: f"統合={m.group(1)} グループ={m.group(2)}"),
        (r"^Scene Doctor preview: (\d+) materials$", lambda m: f"シーンドクタープレビュー: {m.group(1)} 個のマテリアル"),
        (r"^Scene Doctor processed (\d+) materials$", lambda m: f"シーンドクター処理済み: {m.group(1)} 個のマテリアル"),
        (r"^Cleanup done\. mats=(\d+), images=(\d+), groups=(\d+)$", lambda m: f"クリーンアップ完了。マテリアル={m.group(1)}、画像={m.group(2)}、グループ={m.group(3)}"),
        (r"^Updated: (.+)$", lambda m: f"更新しました: {m.group(1)}"),
        (r"^Loaded parameters from (.+)$", lambda m: f"{m.group(1)} からパラメータを読み込みました"),
    )
    for pattern, formatter in patterns:
        match = re.match(pattern, raw)
        if match:
            try:
                return formatter(match)
            except Exception:
                return raw
    return raw

def _build_translation_data() -> dict:
    ja_items: dict[tuple[str, str], str] = {}
    en_items: dict[tuple[str, str], str] = {}
    for en, ja in _STATIC_EN_JA.items():
        if not en or not ja:
            continue
        contexts = (RNA_TEXT_CONTEXT,) if en in _PRIVATE_CONTEXT_ONLY else _TRANSLATION_CONTEXTS
        for ctxt in contexts:
            ja_items[(ctxt, en)] = ja
            en_items[(ctxt, ja)] = en
    return {
        "ja_JP": ja_items,
        "ja_JP.UTF-8": ja_items,
        "ja": ja_items,
        "en_US": en_items,
        "en_US.UTF-8": en_items,
        "en": en_items,
    }


_LOCALE_CACHE_KEY = None
_LOCALE_CACHE_VALUE = False
_SYSTEM_LOCALE_CACHE = None


def _system_locale_code() -> str:
    """Return the process locale once.

    The OS locale cannot change during one Blender process, while UI language
    can.  Keeping this component separate preserves language-switch behaviour
    and avoids repeated deprecated locale API calls during class registration.
    """
    global _SYSTEM_LOCALE_CACHE
    if _SYSTEM_LOCALE_CACHE is not None:
        return str(_SYSTEM_LOCALE_CACHE)
    value = ""
    try:
        value = str((_py_locale.getdefaultlocale()[0] or "").lower())
    except Exception:
        value = ""
    _SYSTEM_LOCALE_CACHE = value
    return value


def locale_is_japanese() -> bool:
    global _LOCALE_CACHE_KEY, _LOCALE_CACHE_VALUE
    use_translate = True
    language = ""
    locale_code = ""
    try:
        import bpy  # type: ignore

        ctx = getattr(bpy, "context", None)
        prefs = getattr(ctx, "preferences", None)
        view = getattr(prefs, "view", None)
        if view is not None:
            use_translate = bool(getattr(view, "use_translate_interface", True))
            language = str(getattr(view, "language", "") or "")
        locale_code = str(getattr(getattr(bpy.app, "translations", None), "locale", "") or "")
    except Exception:
        pass
    system_locale = _system_locale_code()
    key = (use_translate, language, locale_code, system_locale)
    if key == _LOCALE_CACHE_KEY:
        return _LOCALE_CACHE_VALUE
    if not use_translate:
        value = False
    else:
        lowered = language.lower()
        if lowered and lowered not in {"default", "auto"}:
            value = lowered.startswith("ja") or "japanese" in lowered
        elif locale_code.lower().startswith("ja"):
            value = True
        else:
            value = system_locale.startswith("ja")
    _LOCALE_CACHE_KEY = key
    _LOCALE_CACHE_VALUE = bool(value)
    return _LOCALE_CACHE_VALUE


# RNA names, tooltips and enum items are fixed when they are registered, so they
# are stored in English and Blender's translation table shows them in the active
# language.  This stays on from import until the add-on finishes registering.
_REGISTERING_RNA_TEXT = True


def begin_rna_text_registration() -> None:
    global _REGISTERING_RNA_TEXT
    _REGISTERING_RNA_TEXT = True


def end_rna_text_registration() -> None:
    global _REGISTERING_RNA_TEXT
    _REGISTERING_RNA_TEXT = False


def rna_text_context_prop(factory):
    """Wrap a bpy.props factory so its name and enum items use this add-on's context."""
    def _prop(**kwargs):
        kwargs.setdefault("translation_context", RNA_TEXT_CONTEXT)
        return factory(**kwargs)
    return _prop


_RNA_TEXT_PAIRS: dict[str, str] = {}


def apply_rna_text_context(cls: type) -> None:
    """Give an operator whose label was written with a pair this add-on's context."""
    if str(getattr(cls, "bl_label", "") or "") in _RNA_TEXT_PAIRS and hasattr(cls, "bl_idname"):
        cls.bl_translation_context = RNA_TEXT_CONTEXT


def tx(scene, en: str, ja: str) -> str:
    _ = scene
    _remember_pair(str(en or ""), str(ja or ""))
    if _REGISTERING_RNA_TEXT:
        en_text = str(en or "").strip()
        ja_text = str(ja or "").strip()
        if en_text and ja_text and en_text != ja_text and len(ja_text) <= 900 and en_text not in _RNA_TEXT_PAIRS:
            # The wording written beside a registered name is the one shown for it.
            _RNA_TEXT_PAIRS[en_text] = ja_text
            _STATIC_EN_JA[en_text] = ja_text
        return str(en or "")
    return str(ja or "") if locale_is_japanese() else str(en or "")


def yes_no(scene, value: bool) -> str:
    return tx(scene, "Yes", "はい") if value else tx(scene, "No", "いいえ")


def wrap_lines(text: str, width: int = 68) -> list[str]:
    lines: list[str] = []
    for paragraph in (text or "").splitlines():
        if not paragraph.strip():
            lines.append("")
            continue
        lines.extend(textwrap.wrap(paragraph, width=width) or [""])
    return lines


def joined(scene, items: list[str], sep_en: str = ", ", sep_ja: str = "、") -> str:
    _ = scene
    if not items:
        return ""
    sep = sep_ja if locale_is_japanese() else sep_en
    return sep.join(items)


@lru_cache(maxsize=4096)
def _count_japanese(text: str) -> int:
    return len(_JA_RE.findall(str(text or "")))


@lru_cache(maxsize=4096)
def _count_latin(text: str) -> int:
    return len(_LATIN_RE.findall(str(text or "")))


@lru_cache(maxsize=4096)
def _language_profile(text: str) -> str:
    raw = str(text or "")
    ja_count = _count_japanese(raw)
    latin_count = _count_latin(raw)
    if ja_count and not latin_count:
        return "ja"
    if latin_count and not ja_count:
        return "en"
    if ja_count and latin_count:
        if ja_count >= max(1, int(latin_count * 1.6)):
            return "ja"
        if latin_count >= max(1, int(ja_count * 1.6)):
            return "en"
        return "mixed"
    return ""


@lru_cache(maxsize=4096)
def _split_marked_text(text: str) -> tuple[str, str]:
    raw = str(text or "").strip()
    if not raw:
        return "", ""
    matches = list(_LANG_MARKER_RE.finditer(raw))
    if len(matches) < 2:
        return "", ""
    en_parts: list[str] = []
    ja_parts: list[str] = []
    for index, match in enumerate(matches):
        tag = str(match.group("tag") or "").upper()
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(raw)
        chunk = raw[start:end].strip().strip("/").strip()
        if not chunk:
            continue
        if tag == "EN":
            en_parts.append(chunk)
        elif tag in {"JP", "JA"}:
            ja_parts.append(chunk)
    return "\n".join(en_parts).strip(), "\n".join(ja_parts).strip()


@lru_cache(maxsize=4096)
def _split_slash_pair(text: str) -> tuple[str, str]:
    raw = str(text or "").strip()
    if not raw or raw.count(" / ") != 1:
        return "", ""
    left, right = (part.strip() for part in raw.split(" / ", 1))
    if not left or not right:
        return "", ""
    left_has_ja = bool(_JA_RE.search(left))
    right_has_ja = bool(_JA_RE.search(right))
    if right_has_ja and not left_has_ja:
        return left, right
    if left_has_ja and not right_has_ja:
        return right, left
    left_profile = _language_profile(left)
    right_profile = _language_profile(right)
    if left_profile == "en" and right_profile == "ja":
        return left, right
    if left_profile == "ja" and right_profile == "en":
        return right, left
    return "", ""


def loc_text(text: str, ja: str | None = None) -> str:
    if ja is not None:
        return tx(None, str(text or ""), str(ja or ""))

    raw = str(text or "")
    if not raw:
        return raw

    en_text, ja_text = _split_marked_text(raw)
    if en_text or ja_text:
        if en_text and ja_text:
            return tx(None, en_text, ja_text)
        return ja_text or en_text

    en_text, ja_text = _split_slash_pair(raw)
    if en_text and ja_text:
        return tx(None, en_text, ja_text)

    return _static_lookup(raw)


def ja_text(en: str) -> str:
    """Return the Japanese wording of an English name, or an empty string."""
    return _STATIC_EN_JA.get(str(en or "").strip(), "")


class AddonError(ValueError):
    """A problem this add-on words for the user, already in the active language."""


def exc_text(exc, en: str = "The operation could not be completed.", ja: str = "処理を完了できませんでした。") -> str:
    """Return an exception message fit for the UI in the active language.

    AddonError messages are already localized and shown as they are. Anything
    else (a failed poll, a Python error) is shown only when it can be read in
    the active language, and is otherwise replaced by a plain sentence.
    """
    message = str(exc or "").strip()
    is_japanese = locale_is_japanese() and not _REGISTERING_RNA_TEXT
    fallback = ja if is_japanese else en
    if not message:
        return fallback
    if isinstance(exc, AddonError):
        return message
    if is_japanese:
        if _JA_RE.search(message):
            return message
        translated = _static_lookup(message)
        return translated if _JA_RE.search(translated) else fallback
    if not _JA_RE.search(message):
        return message if message in _STATIC_EN_JA else fallback
    translated = _static_lookup(message)
    return translated if not _JA_RE.search(translated) else fallback


_TRANSLATION_OWNER = (__name__ or "smart_shader_suite")
_TRANSLATION_DATA: dict = _build_translation_data()


def register_translations() -> None:
    global _TRANSLATION_DATA
    try:
        import bpy  # type: ignore
        unregister_translations()
        try:
            _static_lookup_cached.cache_clear()
            _dynamic_static_lookup.cache_clear()
        except Exception:
            pass
        _TRANSLATION_DATA = _build_translation_data()
        if _TRANSLATION_DATA:
            bpy.app.translations.register(_TRANSLATION_OWNER, _TRANSLATION_DATA)
    except Exception:
        pass


def unregister_translations() -> None:
    try:
        _static_lookup_cached.cache_clear()
        _dynamic_static_lookup.cache_clear()
    except Exception:
        pass
    try:
        import bpy  # type: ignore
        if _TRANSLATION_DATA:
            bpy.app.translations.unregister(_TRANSLATION_OWNER)
    except Exception:
        pass
