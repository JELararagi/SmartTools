# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Persistent resident feature switches without shared-API interception.

This module intentionally does not monkeypatch Blender timers, handlers,
message bus, draw APIs, or keymaps.  Integrated features must register their
own exact-owned resources through their native lifecycle.  The compatibility
capture context remains available as a no-op so existing public imports keep
working.
"""

from __future__ import annotations

import re
from contextlib import AbstractContextManager
from typing import Any, Callable

import bpy

from . import storage

try:
    from .translation import tx as _translation_tx
except Exception:
    _translation_tx = None

_SUITE_ID = 'smart_shader_suite'
_OWNER_UUID = 'f24781fa-f17d-4f79-96cf-0518208fea70'
_GENERATION = '5.18.230'
_SUITE_KEY = ''
_SUITE_LABEL = ''
_CATEGORY = ''
_OPERATOR_ID = ''
_FEATURES: dict[str, dict[str, dict[str, Any]]] = {}
_STATE_CACHE: dict[str, dict[str, bool]] | None = None
_REGISTERED_CLASSES: list[type] = []
_REGISTERED_PROPERTIES: list[tuple[type, str, Any]] = []
_DYNAMIC_BOOL_PROPS: dict[tuple[str, str], str] = {}
_DYNAMIC_PROP_GUARD: set[str] = set()

_KIND_ORDER = ('handlers', 'timers', 'msgbus', 'keymaps', 'draw_handlers')
_KIND_INFO = {
    'handlers': ('Application Handlers', 'アプリケーションハンドラー',
                 'Enable automatic event handlers for this integrated feature.',
                 'この統合機能の自動イベントハンドラーを有効にします。'),
    'timers': ('Background Timers', 'バックグラウンドタイマー',
               'Enable operation-owned delayed callbacks for this integrated feature.',
               'この統合機能で操作中だけ使う遅延コールバックを有効にします。'),
    'msgbus': ('RNA Message Bus Watchers', 'RNAメッセージバス監視',
               'Enable exact-owned RNA message-bus subscriptions for this integrated feature.',
               'この統合機能が所有するRNAメッセージバス購読を有効にします。'),
    'keymaps': ('Hotkeys', 'ホットキー',
                'Enable exact-owned shortcuts for this integrated feature.',
                'この統合機能が所有するショートカットを有効にします。'),
    'draw_handlers': ('Viewport / Editor Draw', 'ビューポート / エディター描画',
                      'Enable operation-owned helper drawing for this integrated feature.',
                      'この統合機能が操作中だけ行う補助描画を有効にします。'),
}


def _clean_identifier(value: str, fallback: str = 'smart_shader_suite') -> str:
    text = str(value or '').strip().split('.')[-1]
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    return text or fallback


def _title_from_key(value: str) -> str:
    text = str(value or '').strip().split('.')[-1].replace('_suite', '').replace('_', ' ').strip()
    return ' '.join(part[:1].upper() + part[1:] for part in text.split()) or 'Smart Shader'


def _infer_suite_key() -> str:
    package = str(__package__ or '').strip('.')
    parts = [part for part in package.split('.') if part]
    if 'user_default' in parts:
        index = parts.index('user_default')
        if index + 1 < len(parts):
            return _clean_identifier(parts[index + 1])
    return _clean_identifier(parts[-1] if parts else 'smart_shader_suite')


def _infer_category(suite_key: str) -> str:
    title = _title_from_key(suite_key)
    return title if title.lower().startswith('smart ') else f'Smart {title}'


def configure(*, suite_key: str | None = None, suite_label: str | None = None,
              category: str | None = None) -> None:
    global _SUITE_KEY, _SUITE_LABEL, _CATEGORY, _OPERATOR_ID
    _SUITE_KEY = _clean_identifier(suite_key or _SUITE_KEY or _infer_suite_key())
    _SUITE_LABEL = str(suite_label or _SUITE_LABEL or _title_from_key(_SUITE_KEY)).strip()
    _CATEGORY = str(category or _CATEGORY or _infer_category(_SUITE_KEY)).strip()
    _OPERATOR_ID = f'{_SUITE_KEY}.toggle_feature'


def _is_ja(context=None) -> bool:
    try:
        prefs = getattr(getattr(context or bpy.context, 'preferences', None), 'view', None)
        language = str(getattr(prefs, 'language', '') or '').lower()
    except Exception:
        language = ''
    try:
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').lower()
    except Exception:
        locale = ''
    return language.startswith('ja') or locale.startswith('ja') or 'japanese' in language


def _t(context, en: str, ja: str) -> str:
    if _translation_tx is not None:
        try:
            return str(_translation_tx(None, str(en or ''), str(ja or '')))
        except Exception:
            pass
    return str(ja if _is_ja(context) else en)


def _static_t(en: str, ja: str) -> str:
    return _t(None, en, ja)


def _load_state() -> dict[str, dict[str, bool]]:
    global _STATE_CACHE
    if _STATE_CACHE is not None:
        return _STATE_CACHE
    result: dict[str, dict[str, bool]] = {}
    try:
        raw = storage.read_suite_section('feature_toggles', {})
    except Exception:
        raw = {}
    if isinstance(raw, dict):
        for alias, values in raw.items():
            if isinstance(values, dict):
                result[str(alias)] = {str(key): bool(value) for key, value in values.items()}
    _STATE_CACHE = result
    return result


def _save_state(*, force: bool = False) -> None:
    if not force:
        try:
            if not storage.npanel_state_save_enabled(default=True):
                return
        except Exception:
            return
    state = _load_state()
    flat = {
        _property_name(alias, key): bool(value)
        for alias, values in state.items() if isinstance(values, dict)
        for key, value in values.items()
    }
    try:
        storage.write_suite_sections({'feature_toggles': state, 'feature_toggle_rna': flat})
    except Exception:
        pass


def save_feature_toggle_state(*, force: bool = False) -> None:
    _save_state(force=force)


def is_feature_enabled(alias: str, feature_key: str) -> bool:
    return bool(_load_state().get(str(alias or '').strip(), {}).get(str(feature_key or '').strip(), False))


def set_feature_enabled(alias: str, feature_key: str, enabled: bool) -> bool:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    if not alias or not feature_key:
        return False
    _load_state().setdefault(alias, {})[feature_key] = bool(enabled)
    _sync_property_from_state(alias, feature_key, bool(enabled))
    _save_state()
    _tag_redraw()
    return True


def _feature_record(alias: str, tool_label: str, feature_key: str) -> dict[str, Any]:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    values = _KIND_INFO.get(feature_key, (feature_key, feature_key, '', ''))
    feature = _FEATURES.setdefault(alias, {}).setdefault(feature_key, {
        'alias': alias,
        'tool_label': str(tool_label or alias or 'Tool'),
        'key': feature_key,
        'label_en': values[0], 'label_ja': values[1],
        'description_en': values[2], 'description_ja': values[3],
        'actions': [],
    })
    return feature


def _prop_safe_part(value: str) -> str:
    text = re.sub(r'[^0-9A-Za-z_]+', '_', str(value or '').strip().lower())
    return re.sub(r'_+', '_', text).strip('_') or 'feature'


def _property_name(alias: str, feature_key: str) -> str:
    return f'sss_ft_{_prop_safe_part(alias)}_{_prop_safe_part(feature_key)}'


def _wm_instance(context=None):
    try:
        return getattr(context or bpy.context, 'window_manager', None)
    except Exception:
        return None


def _sync_property_from_state(alias: str, feature_key: str, value: bool, context=None) -> None:
    prop_name = _DYNAMIC_BOOL_PROPS.get((alias, feature_key), _property_name(alias, feature_key))
    wm = _wm_instance(context)
    if wm is None or not hasattr(wm, prop_name):
        return
    _DYNAMIC_PROP_GUARD.add(prop_name)
    try:
        setattr(wm, prop_name, bool(value))
    except Exception:
        pass
    finally:
        _DYNAMIC_PROP_GUARD.discard(prop_name)


def _dynamic_update_factory(alias: str, feature_key: str, prop_name: str):
    def _update(self, context):
        if prop_name not in _DYNAMIC_PROP_GUARD:
            set_feature_enabled(alias, feature_key, bool(getattr(self, prop_name, False)))
    return _update


def _ensure_toggle_property(alias: str, feature_key: str, feature: dict[str, Any] | None = None) -> str:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    prop_name = _property_name(alias, feature_key)
    _DYNAMIC_BOOL_PROPS[(alias, feature_key)] = prop_name
    if hasattr(bpy.types.WindowManager, prop_name):
        return prop_name
    feature = feature or _FEATURES.get(alias, {}).get(feature_key, {})
    prop = bpy.props.BoolProperty(
        name=_static_t(str(feature.get('label_en') or feature_key), str(feature.get('label_ja') or feature_key)),
        description=_static_t(str(feature.get('description_en') or ''), str(feature.get('description_ja') or '')),
        default=is_feature_enabled(alias, feature_key),
        update=_dynamic_update_factory(alias, feature_key, prop_name),
    )
    setattr(bpy.types.WindowManager, prop_name, prop)
    _REGISTERED_PROPERTIES.append((bpy.types.WindowManager, prop_name, prop))
    return prop_name


def _draw_dynamic_feature_row(layout, context, item: dict[str, Any], *, alias_label: str = '') -> bool:
    alias = str(item.get('alias') or '')
    key = str(item.get('key') or '')
    prop_name = _DYNAMIC_BOOL_PROPS.get((alias, key), _property_name(alias, key))
    wm = _wm_instance(context)
    if wm is None or not hasattr(wm, prop_name):
        return False
    label = _t(context, str(item.get('label_en') or key), str(item.get('label_ja') or key))
    if alias_label:
        label = f'{alias_label}: {label}'
    row = layout.row(align=True)
    row.label(text=label)
    row.prop(wm, prop_name, text='', toggle=True)
    return True


def _add_action(alias: str, tool_label: str, feature_key: str, action: dict[str, Any]) -> None:
    feature = _feature_record(alias, tool_label, feature_key)
    # Compatibility metadata only.  Resource interception is intentionally absent.
    feature.setdefault('actions', []).append(dict(action or {}))
    _ensure_toggle_property(alias, feature_key, feature)


def feature_entries(alias: str | None = None) -> list[dict[str, Any]]:
    aliases = [str(alias).strip()] if alias else sorted(_FEATURES)
    out: list[dict[str, Any]] = []
    for alias_key in aliases:
        for key in _KIND_ORDER:
            feature = _FEATURES.get(alias_key, {}).get(key)
            if not feature:
                continue
            item = dict(feature)
            item['enabled'] = is_feature_enabled(alias_key, key)
            item['action_count'] = len(feature.get('actions') or ())
            out.append(item)
    return out


def all_feature_aliases() -> tuple[str, ...]:
    return tuple(sorted(_FEATURES))


def purge_invalid_workspace_tool_keymaps() -> None:
    """Compatibility no-op; foreign/user keymaps are never scanned or removed."""


def deactivate_alias(alias: str) -> None:
    # Integrated modules own and stop their resources themselves.
    return None


def clear_alias(alias: str) -> None:
    _FEATURES.pop(str(alias or '').strip(), None)


class _DummyDrawHandle:
    __slots__ = ('owner_uuid', 'suite_id', 'generation')

    def __init__(self):
        self.owner_uuid = _OWNER_UUID
        self.suite_id = _SUITE_ID
        self.generation = _GENERATION


class _RuntimeCapture(AbstractContextManager):
    """Public compatibility context that performs no shared-API mutation."""

    def __init__(self, alias: str, tool_label: str | None = None):
        self.alias = str(alias or '').strip()
        self.tool_label = str(tool_label or self.alias or 'Tool')

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        return False

    def kind_enabled(self, feature_key: str) -> bool:
        return is_feature_enabled(self.alias, feature_key)

    def record_action(self, feature_key: str, action: dict[str, Any]) -> None:
        _add_action(self.alias, self.tool_label, feature_key, action)


def capture_runtime(alias: str, tool_label: str | None = None) -> _RuntimeCapture:
    return _RuntimeCapture(alias, tool_label)


def capture_call(alias: str, tool_label: str | None, callback: Callable[[], Any]) -> Any:
    with capture_runtime(alias, tool_label):
        return callback()


def _tag_redraw() -> None:
    # User-triggered toggle only; no resident redraw monitoring.
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            for area in getattr(getattr(window, 'screen', None), 'areas', ()) or ():
                if str(getattr(area, 'type', '') or '') in {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}:
                    area.tag_redraw()
    except Exception:
        pass


def _class_has_own_bl_rna(cls: type) -> bool:
    try:
        rna = vars(cls).get('bl_rna') or getattr(cls, 'bl_rna', None)
        identifier = str(getattr(rna, 'identifier', '') or '')
        inherited = {'Operator', 'Panel', 'PropertyGroup', 'Menu', 'UIList', 'AddonPreferences'}
        return bool(identifier and identifier not in inherited)
    except Exception:
        return False

def _operator_description(context, properties) -> str:
    return _t(context,
              'Switch this exact Smart Shader resident feature and save the setting.',
              'このスマートシェーダー常時機能だけを切り替えて設定を保存します。')


def register_ui(*, suite_key: str | None = None, suite_label: str | None = None,
                category: str | None = None) -> None:
    configure(suite_key=suite_key, suite_label=suite_label, category=category)
    if _REGISTERED_CLASSES:
        return
    operator_id = _OPERATOR_ID

    class SSS_OT_toggle_feature(bpy.types.Operator):
        bl_idname = operator_id
        bl_label = _static_t('Toggle Feature', '機能を切り替え')
        bl_description = _static_t(
            'Switch a resident feature on or off and save the setting immediately.',
            '常時機能の有効・無効を切り替え、設定を即時保存します。')
        bl_options = set()

        alias: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
        feature_key: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
        enabled: bpy.props.BoolProperty(default=True, options={'SKIP_SAVE'})

        @classmethod
        def description(cls, context, properties):
            return _operator_description(context, properties)

        def execute(self, context):
            if not set_feature_enabled(self.alias, self.feature_key, bool(self.enabled)):
                self.report({'WARNING'}, _t(context, 'The selected feature could not be changed.', '選択した機能を変更できませんでした。'))
                return {'CANCELLED'}
            return {'FINISHED'}

    SSS_OT_toggle_feature.__name__ = f'SSS_OT_{_SUITE_KEY.upper()}_TOGGLE_PERSISTENT_FEATURE'
    SSS_OT_toggle_feature.__qualname__ = SSS_OT_toggle_feature.__name__
    SSS_OT_toggle_feature.__module__ = __name__
    if _class_has_own_bl_rna(SSS_OT_toggle_feature):
        return
    try:
        bpy.utils.register_class(SSS_OT_toggle_feature)
    except Exception:
        return
    if _class_has_own_bl_rna(SSS_OT_toggle_feature) and SSS_OT_toggle_feature not in _REGISTERED_CLASSES:
        _REGISTERED_CLASSES.append(SSS_OT_toggle_feature)
    for alias, items in tuple(_FEATURES.items()):
        for key, feature in tuple(items.items()):
            _ensure_toggle_property(alias, key, feature)


def draw_inline_toggles(layout, context, alias: str, *, compact: bool = True) -> bool:
    entries = feature_entries(alias)
    if not entries:
        return False
    col = layout.column(align=True)
    for item in entries:
        _draw_dynamic_feature_row(col, context, item)
        if not compact:
            desc = _t(context, str(item.get('description_en') or ''), str(item.get('description_ja') or ''))
            if desc:
                col.label(text=desc[:240])
    return True


def draw_global_toggles(layout, context, *, alias_label_callback=None) -> bool:
    entries = feature_entries()
    if not entries:
        return False
    col = layout.column(align=True)
    for item in entries:
        alias = str(item.get('alias') or '')
        label = ''
        if callable(alias_label_callback):
            try:
                label = str(alias_label_callback(alias) or '')
            except Exception:
                label = alias
        _draw_dynamic_feature_row(col, context, item, alias_label=label or alias)
    return True


def unregister_ui() -> None:
    for owner, name, _prop in reversed(_REGISTERED_PROPERTIES):
        try:
            if hasattr(owner, name):
                delattr(owner, name)
        except Exception:
            pass
    _REGISTERED_PROPERTIES.clear()
    _DYNAMIC_BOOL_PROPS.clear()
    _DYNAMIC_PROP_GUARD.clear()
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            if _class_has_own_bl_rna(cls):
                bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()


def unregister_all() -> None:
    unregister_ui()
    _FEATURES.clear()


def _safe_safe_set_kmi_property_v60(kmi, prop_name, value) -> bool:
    try:
        properties = getattr(kmi, 'properties', None)
        prop_map = getattr(getattr(properties, 'bl_rna', None), 'properties', None)
        if prop_map is None or prop_map.get(str(prop_name)) is None:
            return False
        setattr(properties, str(prop_name), value)
        return True
    except Exception:
        return False
