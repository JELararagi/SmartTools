# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Read the integrated tool controls from Smart Shader's N-panel owner."""

TOOL_ORDER = ("material_library", "math_controller", "pbr_lookdev")
TOOL_META = {
    "material_library": dict(
        display_en="Material Library", display_ja="マテリアルライブラリ", icon="MATERIAL",
        summary_en="Preview materials in local Blender libraries, append or link them, and save reusable looks.",
        summary_ja="ローカルの Blender ライブラリから材質をプレビューし、追加・リンクや再利用用の保存を行います。",
        usage_en="Set the folder and refresh. Select a material to preview or apply. Add To Library stores the active material.",
        usage_ja="フォルダーを指定して更新し、材質を選んでプレビューまたは適用します。Add To Library はアクティブな材質を保存します。",
    ),
    "math_controller": dict(
        display_en="Math Controller", display_ja="数式コントローラー", icon="NODETREE",
        summary_en="Turn a formula into a node network in the shader, geometry, or compositor editor.",
        summary_ja="数式からシェーダー・ジオメトリ・コンポジットのノードネットワークを生成します。",
        usage_en="Add a controller in the target editor and edit its formula. Expand to Group makes an editable node group.",
        usage_ja="使うエディターでコントローラーを追加し、数式を編集します。Expand to Group で編集可能なノードグループに展開します。",
    ),
    "pbr_lookdev": dict(
        display_en="PBR Lookdev", display_ja="PBR ルックデブ", icon="SHADING_TEXTURE",
        summary_en="Build layered PBR materials from texture slots, masks, and overlays.",
        summary_ja="テクスチャスロット・マスク・オーバーレイからレイヤー構造の PBR 材質を組み立てます。",
        usage_en="Choose a material, assign textures or scan a folder, then build or rebuild the shader.",
        usage_ja="材質を選び、テクスチャを割り当てるかフォルダーを走査し、シェーダーを構築・再構築します。",
    ),
}


def root_addon_id():
    return __package__ or __name__.rpartition(".")[0] or "smart_shader_suite"


def candidate_addon_ids():
    package = root_addon_id()
    normalized = package.replace("-", "_")
    return tuple(dict.fromkeys((package, package.lower(), normalized,
                               normalized.lower(), "smart_shader_suite")))


def addon_preferences(context=None):
    try:
        from . import preferences

        return preferences.npanel_settings_owner(context)
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return None


def prop_name(alias, field):
    return "_".join(("integrated", str(alias or "").strip(), str(field or "").strip()))


def tool_value(alias, field, context=None, default=None):
    try:
        return getattr(addon_preferences(context), prop_name(alias, field), default)
    except (ReferenceError, RuntimeError):
        return default


def set_tool_value(alias, field, value, context=None):
    owner = addon_preferences(context)
    if owner is not None:
        try:
            setattr(owner, prop_name(alias, field), value)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
    return value


def tool_enabled(alias, context=None, default=True):
    return bool(tool_value(alias, "enabled", context, default))


def tool_meta(alias):
    return TOOL_META.get(str(alias or "").strip(), {}).copy()


def tool_display(alias, *, japanese=False):
    meta = tool_meta(alias)
    english = meta.get("display_en", str(alias))
    return meta.get("display_ja", english) if japanese else english
