# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from typing import Any

TOOL_ORDER: tuple[str, ...] = (
    'material_library',
    'math_controller',
    'pbr_lookdev',
)

TOOL_META: dict[str, dict[str, str]] = {
    'material_library': {
        'display_en': 'Material Library',
        'display_ja': 'マテリアルライブラリ',
        'icon': 'MATERIAL',
        'summary_en': 'Browse local .blend material libraries, preview saved looks, append or link materials, and maintain reusable material collections from inside Smart Shader.',
        'summary_ja': 'スマートシェーダー内からローカルの .blend マテリアルライブラリを参照し、保存済みルックのプレビュー、追加、リンク、再利用用コレクション管理を行います。',
        'usage_en': 'Set the library folder first, refresh the list, choose a library and material, then preview or apply it. Use Add To Library when you want to save the active material into the current library file.',
        'usage_ja': '最初にライブラリフォルダを設定し、一覧を更新してライブラリとマテリアルを選んでから、プレビューまたは適用します。現在のライブラリへアクティブ材質を保存したい場合は Add To Library を使います。',
    },
    'math_controller': {
        'display_en': 'Math Controller',
        'display_ja': '数式コントローラー',
        'icon': 'NODETREE',
        'summary_en': 'Creates controller nodes that turn editable formulas into Shader, Geometry, or Compositor math networks.',
        'summary_ja': '編集可能な数式を Shader / Geometry / Compositor 用の数式ネットワークへ変換するコントローラーノードを作成します。',
        'usage_en': 'Open the matching node editor, add the controller from Smart Shader, then edit the formulas inside the created controller node. Expand to Group when you need a regular editable node group version.',
        'usage_ja': '対応するノードエディターを開き、スマートシェーダー からコントローラーを追加して、作成されたノード内部で数式を編集します。通常の編集可能なノードグループへ展開したい場合は Expand to Group を使います。',
    },
    'pbr_lookdev': {
        'display_en': 'PBR Lookdev',
        'display_ja': 'PBR ルックデブ',
        'icon': 'SHADING_TEXTURE',
        'summary_en': 'Builds layered PBR materials with per-layer texture slots, masks, overlays, scan-folder helpers, and rebuild controls from one Smart Shader workspace.',
        'summary_ja': 'レイヤーごとのテクスチャスロット、マスク、オーバーレイ、フォルダ走査補助、再構築操作を備えたレイヤー式 PBR マテリアルを スマートシェーダー内の一画面で構築します。',
        'usage_en': 'Create or select a material, add layers as needed, assign texture paths or scan folders, then build or rebuild the generated shader network from the integrated Smart Shader panel.',
        'usage_ja': 'マテリアルを作成または選択し、必要なレイヤーを追加して、テクスチャパスや走査フォルダを設定した後、統合済み スマートシェーダー パネルからシェーダーネットワークを構築または再構築します。',
    },
}


def root_addon_id() -> str:
    package = str(__package__ or '').strip()
    if package:
        return package
    name = str(__name__ or '').strip()
    if '.' in name:
        return name.rsplit('.', 1)[0]
    return name or 'smart_shader_suite'



def candidate_addon_ids() -> tuple[str, ...]:
    root = root_addon_id().strip()
    candidates: list[str] = []
    for item in (
        root,
        root.lower(),
        root.replace('-', '_'),
        root.replace('-', '_').lower(),
        'smart_shader_suite',
        'smart_shader_suite',
    ):
        item = str(item or '').strip()
        if item and item not in candidates:
            candidates.append(item)
    return tuple(candidates)



def addon_preferences(context=None):
    # Historical function name kept for compatibility with integrated modules.
    # It now returns Smart Shader's N-panel settings PropertyGroup rather than
    # bpy.types.AddonPreferences, because all user-facing settings live in the
    # N-panel.
    try:
        from . import preferences as _preferences  # type: ignore
        return _preferences.npanel_settings_owner(context)
    except Exception:
        return None



def prop_name(alias: str, field: str) -> str:
    return f'integrated_{str(alias or "").strip()}_{str(field or "").strip()}'



def tool_value(alias: str, field: str, context=None, default: Any = None) -> Any:
    prefs = addon_preferences(context)
    if prefs is None:
        return default
    try:
        return getattr(prefs, prop_name(alias, field))
    except Exception:
        return default



def set_tool_value(alias: str, field: str, value: Any, context=None) -> Any:
    prefs = addon_preferences(context)
    if prefs is None:
        return value
    try:
        setattr(prefs, prop_name(alias, field), value)
    except Exception:
        pass
    return value



def tool_enabled(alias: str, context=None, default: bool = True) -> bool:
    value = tool_value(alias, 'enabled', context=context, default=default)
    try:
        return bool(value)
    except Exception:
        return bool(default)



def tool_meta(alias: str) -> dict[str, str]:
    return dict(TOOL_META.get(str(alias or '').strip()) or {})



def tool_display(alias: str, *, japanese: bool = False) -> str:
    meta = tool_meta(alias)
    if japanese:
        return str(meta.get('display_ja') or meta.get('display_en') or alias)
    return str(meta.get('display_en') or alias)
