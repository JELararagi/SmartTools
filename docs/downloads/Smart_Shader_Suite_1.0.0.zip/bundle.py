"""Portable material bundle export/import helpers."""

from __future__ import annotations

from .translation import loc_text as _lt
from .translation import AddonError

import json
import re
import shutil
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

from . import core, data, storage

BUNDLE_VERSION = 1
BUNDLE_MANIFEST_NAME = "manifest.json"
BUNDLE_INFO_NAME = "bundle_info.json"


def clean_bundle_basename(value: str) -> str:
    raw = str(value or "").strip() or "material_bundle"
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", raw)
    cleaned = cleaned.strip("._-") or "material_bundle"
    return cleaned[:96]


def bundle_extract_root() -> Path:
    root = core.addon_storage_dir() / "material_bundles"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _copy_texture_entries(texture_entries: list[dict], out_dir: Path) -> tuple[list[dict], list[dict], list[dict]]:
    textures_dir = out_dir / "textures"
    textures_dir.mkdir(parents=True, exist_ok=True)
    rewritten: list[dict] = []
    copied: list[dict] = []
    skipped: list[dict] = []
    used_names: set[str] = set()

    for index, entry in enumerate(texture_entries or []):
        item = dict(entry) if isinstance(entry, dict) else {}
        src_raw = str(item.get("filepath") or "").strip()
        usage = str(item.get("usage") or item.get("usage_hint") or "").strip().lower()
        packed = bool(item.get("packed"))
        source_name = Path(src_raw).name if src_raw else str(item.get("name") or f"texture_{index}")
        stem = clean_bundle_basename(Path(source_name).stem or f"texture_{index}")
        suffix = Path(source_name).suffix or ".png"
        candidate_name = f"{stem}{suffix}"
        dedupe = 1
        while candidate_name.casefold() in used_names:
            dedupe += 1
            candidate_name = f"{stem}_{dedupe}{suffix}"
        used_names.add(candidate_name.casefold())

        if src_raw and Path(src_raw).exists() and Path(src_raw).is_file() and not packed:
            dst = textures_dir / candidate_name
            shutil.copy2(src_raw, dst)
            rel_path = dst.relative_to(out_dir).as_posix()
            item["filepath"] = rel_path
            item["bundle_path"] = rel_path
            rewritten.append(item)
            copied.append({
                "usage": usage,
                "source": src_raw,
                "bundle_path": rel_path,
                "name": candidate_name,
            })
        else:
            item["bundle_path"] = ""
            rewritten.append(item)
            skipped.append({
                "usage": usage,
                "source": src_raw,
                "packed": packed,
                "reason": "missing_or_packed" if packed or src_raw else "no_filepath",
                "name": source_name,
            })
    return rewritten, copied, skipped


def export_material_bundle(material, context=None, export_path: Path | None = None) -> dict:
    if material is None:
        raise AddonError(_lt("No material provided.", "マテリアルが指定されていません。"))

    manifest = core.material_manifest(material, context)
    bundle_name = clean_bundle_basename(material.name)
    export_path = Path(export_path) if export_path else bundle_extract_root() / f"{bundle_name}_bundle.zip"
    if export_path.suffix.lower() != ".zip":
        export_path = export_path.with_suffix(".zip")
    export_path.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="sss_bundle_export_", dir=str(storage.runtime_dir('bundle_exports', create=True))) as tmp_dir_raw:
        tmp_dir = Path(tmp_dir_raw)
        bundle_dir = tmp_dir / bundle_name
        bundle_dir.mkdir(parents=True, exist_ok=True)

        rewritten_textures, copied, skipped = _copy_texture_entries(list(manifest.get("textures") or []), bundle_dir)
        manifest["textures"] = rewritten_textures
        manifest.setdefault("smart_shader", {})["bundle_exported"] = True
        manifest["smart_shader"]["bundle_name"] = bundle_name

        manifest_path = bundle_dir / BUNDLE_MANIFEST_NAME
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

        bundle_info = {
            "bundle_version": BUNDLE_VERSION,
            "addon": data.ADDON_NAME,
            "addon_version": data.ADDON_VERSION,
            "exported_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
            "material_name": material.name,
            "manifest_name": BUNDLE_MANIFEST_NAME,
            "copied_texture_count": len(copied),
            "skipped_texture_count": len(skipped),
            "copied_textures": copied,
            "skipped_textures": skipped,
        }
        (bundle_dir / BUNDLE_INFO_NAME).write_text(json.dumps(bundle_info, indent=2, ensure_ascii=False), encoding="utf-8")

        with zipfile.ZipFile(export_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for path in sorted(bundle_dir.rglob("*")):
                if path.is_file():
                    zf.write(path, arcname=path.relative_to(bundle_dir).as_posix())

    return {
        "path": str(export_path),
        "bundle_name": bundle_name,
        "copied_texture_count": len(copied),
        "skipped_texture_count": len(skipped),
        "copied_textures": copied,
        "skipped_textures": skipped,
    }


def _find_manifest_in_dir(extract_dir: Path) -> Path | None:
    direct = extract_dir / BUNDLE_MANIFEST_NAME
    if direct.exists():
        return direct
    for path in sorted(extract_dir.rglob("*.json")):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if isinstance(payload, dict) and (payload.get("material_name") or payload.get("scope") == "material"):
            return path
    return None


def import_material_bundle(bundle_path: Path, extract_root: Path | None = None) -> dict:
    path = Path(bundle_path)
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(str(path))
    if path.suffix.lower() != ".zip":
        raise AddonError(_lt("Material bundle must be a .zip file.", "マテリアルバンドルは .zip ファイルである必要があります。"))

    root = Path(extract_root) if extract_root else bundle_extract_root()
    root.mkdir(parents=True, exist_ok=True)
    stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    extract_dir = root / f"{clean_bundle_basename(path.stem)}_{stamp}"
    extract_dir.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(path, "r") as zf:
        zf.extractall(extract_dir)

    manifest_path = _find_manifest_in_dir(extract_dir)
    if manifest_path is None:
        raise AddonError(_lt("Bundle does not contain a readable manifest.json file.", "バンドル内に読み取り可能な manifest.json がありません。"))

    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    info_candidates = [extract_dir / BUNDLE_INFO_NAME, manifest_path.parent / BUNDLE_INFO_NAME]
    bundle_info = {}
    for info_path in info_candidates:
        if not info_path.exists():
            continue
        try:
            bundle_info = json.loads(info_path.read_text(encoding="utf-8"))
            break
        except Exception:
            bundle_info = {}

    return {
        "bundle_path": str(path),
        "extract_dir": str(extract_dir),
        "manifest_path": str(manifest_path),
        "manifest_payload": payload,
        "bundle_info": bundle_info,
    }
