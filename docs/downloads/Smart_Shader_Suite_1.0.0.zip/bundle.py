"""Write portable Smart Shader material archives and restore their relative assets."""

from datetime import datetime, timezone
import json
from pathlib import Path
import re
import shutil
from stat import S_ISLNK
from tempfile import NamedTemporaryFile, mkdtemp
from zipfile import ZIP_DEFLATED, ZipFile

from . import core, data
from .translation import AddonError, loc_text

BUNDLE_VERSION = 1
BUNDLE_MANIFEST_NAME = "manifest.json"
BUNDLE_INFO_NAME = "bundle_info.json"
_DEFAULT_BASENAME = "material_bundle"
_BAD_FILENAME = re.compile(r"[^A-Za-z0-9._-]+")


def clean_bundle_basename(value):
    name = _BAD_FILENAME.sub("_", str(value or "").strip()).strip("._-")
    return (name or _DEFAULT_BASENAME)[:96]


def bundle_extract_root():
    folder = core.addon_storage_dir() / "material_bundles"
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def _texture_members(package, entries):
    reserved = set()
    copies, omissions, manifest_entries = [], [], []
    for index, entry in enumerate(entries):
        item = dict(entry) if isinstance(entry, dict) else {}
        manifest_entries.append(item)
        source = str(item.get("filepath") or "").strip()
        usage = str(item.get("usage") or item.get("usage_hint") or "").strip().lower()
        packed = bool(item.get("packed"))
        label = Path(source).name if source else str(item.get("name") or f"texture_{index}")
        file = Path(label)
        stem = clean_bundle_basename(file.stem or f"texture_{index}")
        suffix = file.suffix or ".png"
        name = stem + suffix
        number = 1
        while name.casefold() in reserved:
            number += 1
            name = f"{stem}_{number}{suffix}"
        reserved.add(name.casefold())

        if not source or packed or not Path(source).is_file():
            item["bundle_path"] = ""
            reason = "missing_or_packed" if packed or source else "no_filepath"
            omissions.append(dict(usage=usage, source=source, name=label, packed=packed, reason=reason))
            continue

        member = f"textures/{name}"
        package.write(source, member)
        item.update(filepath=member, bundle_path=member)
        copies.append(dict(usage=usage, source=source, name=name, bundle_path=member))
    return manifest_entries, copies, omissions


def _json_bytes(payload):
    return json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")


def export_material_bundle(material, context=None, export_path=None):
    if material is None:
        raise AddonError(loc_text("No material provided.", "マテリアルが指定されていません。"))
    manifest = core.material_manifest(material, context)
    name = clean_bundle_basename(material.name)
    destination = Path(export_path) if export_path else bundle_extract_root() / f"{name}_bundle.zip"
    if destination.suffix.lower() != ".zip":
        destination = destination.with_suffix(".zip")
    destination.parent.mkdir(parents=True, exist_ok=True)

    with NamedTemporaryFile(dir=destination.parent, prefix=".smart_shader_", suffix=".tmp", delete=False) as file:
        pending = Path(file.name)
    try:
        with ZipFile(pending, "w", compression=ZIP_DEFLATED) as package:
            textures, copied, skipped = _texture_members(package, manifest.get("textures") or ())
            manifest["textures"] = textures
            manifest.setdefault("smart_shader", {}).update(bundle_exported=True, bundle_name=name)
            counts = dict(copied_texture_count=len(copied), skipped_texture_count=len(skipped),
                          copied_textures=copied, skipped_textures=skipped)
            info = dict(bundle_version=BUNDLE_VERSION, addon=data.ADDON_NAME, addon_version=data.ADDON_VERSION,
                        exported_at=datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
                        material_name=material.name, manifest_name=BUNDLE_MANIFEST_NAME, **counts)
            package.writestr(BUNDLE_MANIFEST_NAME, _json_bytes(manifest))
            package.writestr(BUNDLE_INFO_NAME, _json_bytes(info))
        pending.replace(destination)
    finally:
        pending.unlink(missing_ok=True)
    return dict(path=str(destination), bundle_name=name, **counts)


def _extract(package, folder):
    seen = set()
    for entry in package.infolist():
        pieces = entry.filename.removesuffix("/").split("/")
        if (any(part in ("", ".", "..") or "\\" in part or ":" in part for part in pieces)
                or S_ISLNK(entry.external_attr >> 16)):
            raise AddonError(loc_text("Invalid path in material bundle.", "バンドルのパスが無効です。"))
        key = tuple(part.casefold() for part in pieces)
        if key in seen:
            raise AddonError(loc_text("Repeated path in material bundle.", "バンドルのパスが重複しています。"))
        seen.add(key)
        path = folder.joinpath(*pieces)
        if entry.is_dir():
            path.mkdir(parents=True, exist_ok=True)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            with package.open(entry) as source, path.open("xb") as target:
                shutil.copyfileobj(source, target)


def _read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def _manifest(folder):
    direct = folder / BUNDLE_MANIFEST_NAME
    if direct.is_file():
        return direct, _read_json(direct)
    for entry in sorted(folder.rglob("*.json")):
        try:
            payload = _read_json(entry)
        except (OSError, ValueError):
            continue
        if isinstance(payload, dict) and (payload.get("material_name") or payload.get("scope") == "material"):
            return entry, payload
    raise AddonError(loc_text("Bundle does not contain a readable manifest.json file.",
                              "バンドル内に読み取り可能な manifest.json がありません。"))


def import_material_bundle(bundle_path, extract_root=None):
    source = Path(bundle_path)
    if not source.is_file():
        raise FileNotFoundError(str(source))
    if source.suffix.lower() != ".zip":
        raise AddonError(loc_text("Material bundle must be a .zip file.",
                                  "マテリアルバンドルは .zip ファイルである必要があります。"))
    root = Path(extract_root) if extract_root else bundle_extract_root()
    root.mkdir(parents=True, exist_ok=True)
    folder = Path(mkdtemp(prefix=clean_bundle_basename(source.stem) + "_", dir=root))
    try:
        with ZipFile(source) as package:
            _extract(package, folder)
        manifest_path, payload = _manifest(folder)
        info = {}
        for parent in dict.fromkeys((folder, manifest_path.parent)):
            try:
                info = _read_json(parent / BUNDLE_INFO_NAME)
            except (OSError, ValueError):
                continue
            break
    except BaseException:
        shutil.rmtree(folder)
        raise
    return dict(bundle_path=str(source), extract_dir=str(folder), manifest_path=str(manifest_path),
                manifest_payload=payload, bundle_info=info)
