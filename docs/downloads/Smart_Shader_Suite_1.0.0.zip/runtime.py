# SPDX-License-Identifier: GPL-3.0-or-later
"""Lifecycle boundary for the Shader Suite."""

from . import loader, ui_runtime


def register():
    loader.register_all()
    try:
        ui_runtime.register()
    except Exception:
        loader.unregister_all()
        raise


def unregister():
    try:
        ui_runtime.unregister()
    finally:
        loader.unregister_all()
