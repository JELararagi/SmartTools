"""Photo-to-PBR helpers inspired by modern material-capture workflows.

This module intentionally keeps the core image analysis free of Blender-specific
APIs so it can be smoke-tested in headless Python environments.
"""

from __future__ import annotations

from .translation import loc_text as _lt
from .translation import AddonError
from . import data, storage

import json
import math
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np

try:
    from PIL import Image, ImageFilter  # type: ignore
except Exception:  # pragma: no cover - optional dependency
    Image = None
    ImageFilter = None


def _has_pillow() -> bool:
    return Image is not None and ImageFilter is not None


def _safe_output_root(source_path: Path, preferred_dir: str | Path | None = None) -> Path:
    if preferred_dir:
        candidate = Path(str(preferred_dir)).expanduser()
        if str(candidate).strip():
            try:
                candidate.mkdir(parents=True, exist_ok=True)
                return candidate
            except Exception:
                pass
    fallback = storage.runtime_dir('sampler', source_path.stem, create=True)
    fallback.mkdir(parents=True, exist_ok=True)
    return fallback


def _resize_nearest(arr: np.ndarray, new_w: int, new_h: int) -> np.ndarray:
    src_h, src_w = arr.shape[:2]
    if src_h <= 0 or src_w <= 0:
        raise AddonError(_lt("Cannot resize an empty image array", "空の画像配列はリサイズできません。"))
    if src_h == new_h and src_w == new_w:
        return np.asarray(arr, dtype=np.float32)
    y_idx = np.linspace(0, src_h - 1, new_h).round().astype(np.int32)
    x_idx = np.linspace(0, src_w - 1, new_w).round().astype(np.int32)
    return np.asarray(arr[y_idx][:, x_idx], dtype=np.float32)


def _open_rgb_pillow(path: Path, max_size: int = 1024) -> np.ndarray:
    image = Image.open(path).convert("RGB")
    max_size = int(max(256, min(4096, max_size or 1024)))
    if max(image.size) > max_size:
        scale = max_size / float(max(image.size))
        new_size = (
            max(32, int(round(image.size[0] * scale))),
            max(32, int(round(image.size[1] * scale))),
        )
        resampling = getattr(getattr(Image, "Resampling", Image), "LANCZOS", getattr(Image, "LANCZOS", 1))
        image = image.resize(new_size, resampling)
    arr = np.asarray(image, dtype=np.float32) / 255.0
    return np.clip(arr, 0.0, 1.0)


def _open_rgb_blender(path: Path, max_size: int = 1024) -> np.ndarray:
    import bpy  # type: ignore

    image = bpy.data.images.load(str(path), check_existing=False)
    try:
        width = int(getattr(image, "size", [0, 0])[0] or 0)
        height = int(getattr(image, "size", [0, 0])[1] or 0)
        if width <= 0 or height <= 0:
            raise RuntimeError(f"Failed to read image size from {path}")
        pixels = np.array(image.pixels[:], dtype=np.float32)
        if pixels.size < width * height * 4:
            raise RuntimeError(f"Failed to read pixel buffer from {path}")
        rgb = pixels.reshape((height, width, 4))[..., :3]
    finally:
        try:
            bpy.data.images.remove(image)
        except Exception:
            pass

    max_size = int(max(256, min(4096, max_size or 1024)))
    if max(width, height) > max_size:
        scale = max_size / float(max(width, height))
        new_w = max(32, int(round(width * scale)))
        new_h = max(32, int(round(height * scale)))
        rgb = _resize_nearest(rgb, new_w, new_h)
    return np.clip(rgb, 0.0, 1.0).astype(np.float32)


def _open_rgb(path: Path, max_size: int = 1024) -> np.ndarray:
    if _has_pillow():
        return _open_rgb_pillow(path, max_size=max_size)
    try:
        return _open_rgb_blender(path, max_size=max_size)
    except Exception as exc:
        raise AddonError(_lt(
            "The image could not be loaded.",
            "画像を読み込めませんでした。"
        )) from exc


def _array_to_image(arr: np.ndarray, mode: str = "RGB"):
    if not _has_pillow():
        raise AddonError(_lt("The image could not be converted because Pillow is not available.", "Pillow を使えないため、画像を変換できません。"))
    arr = np.asarray(arr)
    if arr.ndim == 2:
        arr = np.clip(arr * 255.0, 0.0, 255.0).astype(np.uint8)
        return Image.fromarray(arr, mode="L")
    arr = np.clip(arr * 255.0, 0.0, 255.0).astype(np.uint8)
    return Image.fromarray(arr, mode=mode)


def _grayscale(rgb: np.ndarray) -> np.ndarray:
    return np.clip(rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722, 0.0, 1.0)


def _normalize(arr: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    arr = np.asarray(arr, dtype=np.float32)
    low = float(np.nanmin(arr))
    high = float(np.nanmax(arr))
    if not math.isfinite(low) or not math.isfinite(high) or abs(high - low) < eps:
        return np.zeros_like(arr, dtype=np.float32)
    return np.clip((arr - low) / (high - low), 0.0, 1.0)


def _moving_average_axis(arr: np.ndarray, radius: int, axis: int) -> np.ndarray:
    radius = int(max(1, radius))
    kernel = radius * 2 + 1
    pad = [(0, 0)] * arr.ndim
    pad[axis] = (radius, radius)
    padded = np.pad(np.asarray(arr, dtype=np.float32), pad, mode="edge")
    cumsum = np.cumsum(padded, axis=axis, dtype=np.float32)
    zero_shape = list(cumsum.shape)
    zero_shape[axis] = 1
    cumsum = np.concatenate([np.zeros(zero_shape, dtype=np.float32), cumsum], axis=axis)
    hi = [slice(None)] * arr.ndim
    lo = [slice(None)] * arr.ndim
    hi[axis] = slice(kernel, None)
    lo[axis] = slice(None, -kernel)
    return (cumsum[tuple(hi)] - cumsum[tuple(lo)]) / float(kernel)


def _blur_gray_numpy(gray: np.ndarray, radius: float) -> np.ndarray:
    radius_px = int(max(1, round(float(radius))))
    arr = np.asarray(gray, dtype=np.float32)
    for _ in range(2):
        arr = _moving_average_axis(arr, radius_px, 0)
        arr = _moving_average_axis(arr, radius_px, 1)
    return np.clip(arr, 0.0, 1.0)


def _blur_gray(gray: np.ndarray, radius: float) -> np.ndarray:
    radius = max(0.1, float(radius))
    if _has_pillow():
        return np.asarray(_array_to_image(gray).filter(ImageFilter.GaussianBlur(radius=radius)), dtype=np.float32) / 255.0
    return _blur_gray_numpy(gray, radius=radius)


def _saturation(rgb: np.ndarray) -> np.ndarray:
    maximum = np.max(rgb, axis=-1)
    minimum = np.min(rgb, axis=-1)
    return np.where(maximum > 1e-6, (maximum - minimum) / np.maximum(maximum, 1e-6), 0.0).astype(np.float32)


def _illumination_compensated_base(rgb: np.ndarray) -> np.ndarray:
    gray = _grayscale(rgb)
    radius = max(6.0, min(rgb.shape[0], rgb.shape[1]) / 22.0)
    illum = _blur_gray(gray, radius=radius)
    illum = np.clip(illum, 0.05, 1.0)
    target = float(np.mean(illum))
    corrected = rgb / illum[..., None] * max(target, 0.18)
    corrected = corrected / np.maximum(np.percentile(corrected, 99.0), 1e-4)
    return np.clip(corrected, 0.0, 1.0)


def _height_from_photo(rgb: np.ndarray, detail_strength: float = 1.0) -> np.ndarray:
    gray = _grayscale(rgb)
    blur_small = _blur_gray(gray, radius=max(1.2, min(rgb.shape[0], rgb.shape[1]) / 160.0))
    blur_large = _blur_gray(gray, radius=max(5.0, min(rgb.shape[0], rgb.shape[1]) / 26.0))
    detail_strength = float(max(0.2, min(4.0, detail_strength or 1.0)))
    high = gray - blur_small
    mid = gray - blur_large
    height = gray * 0.45 + _normalize(mid) * 0.30 + _normalize(high) * 0.25 * detail_strength
    return _normalize(height)


def _roughness_from_photo(rgb: np.ndarray, height: np.ndarray) -> np.ndarray:
    sat = _saturation(rgb)
    detail = np.abs(height - _blur_gray(height, radius=max(1.6, min(rgb.shape[0], rgb.shape[1]) / 90.0)))
    detail = _normalize(detail)
    tonal = _normalize(_grayscale(rgb))
    rough = 0.18 + detail * 0.42 + (1.0 - sat) * 0.24 + tonal * 0.16
    return np.clip(rough, 0.02, 0.98).astype(np.float32)


def _occlusion_from_height(height: np.ndarray) -> np.ndarray:
    blur_mid = _blur_gray(height, radius=max(1.6, min(height.shape[0], height.shape[1]) / 80.0))
    cavities = np.clip(blur_mid - height, 0.0, 1.0)
    ao = 1.0 - _normalize(cavities) * 0.5
    return np.clip(ao, 0.0, 1.0).astype(np.float32)


def _normal_from_height(height: np.ndarray, normal_strength: float = 3.0) -> np.ndarray:
    normal_strength = float(max(0.1, min(20.0, normal_strength or 3.0)))
    gy, gx = np.gradient(height.astype(np.float32))
    nx = -gx * normal_strength
    ny = -gy * normal_strength
    nz = np.ones_like(height, dtype=np.float32)
    norm = np.sqrt(nx * nx + ny * ny + nz * nz) + 1e-8
    nx = nx / norm
    ny = ny / norm
    nz = nz / norm
    rgb = np.stack(((nx * 0.5 + 0.5), (ny * 0.5 + 0.5), (nz * 0.5 + 0.5)), axis=-1)
    return np.clip(rgb, 0.0, 1.0).astype(np.float32)


def _save_map_pillow(path: Path, arr: np.ndarray, mode: str = "RGB") -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    _array_to_image(arr, mode=mode).save(path)
    return str(path)


def _save_map_blender(path: Path, arr: np.ndarray, mode: str = "RGB") -> str:
    import bpy  # type: ignore

    path.parent.mkdir(parents=True, exist_ok=True)
    data = np.asarray(arr, dtype=np.float32)
    if data.ndim == 2:
        rgb = np.repeat(data[..., None], 3, axis=2)
    else:
        rgb = data[..., :3]
    rgb = np.clip(rgb, 0.0, 1.0)
    height, width = rgb.shape[:2]
    alpha = np.ones((height, width, 1), dtype=np.float32)
    rgba = np.concatenate([rgb, alpha], axis=2)

    image = bpy.data.images.new(name=f"SSS_{path.stem}", width=width, height=height, alpha=True, float_buffer=False)
    try:
        flat = rgba.astype(np.float32).ravel()
        try:
            image.pixels.foreach_set(flat)
        except Exception:
            image.pixels = flat.tolist()
        image.filepath_raw = str(path)
        image.file_format = "PNG"
        image.save()
        return str(path)
    finally:
        try:
            bpy.data.images.remove(image)
        except Exception:
            pass


def _save_map(path: Path, arr: np.ndarray, mode: str = "RGB") -> str:
    if _has_pillow():
        return _save_map_pillow(path, arr, mode=mode)
    try:
        return _save_map_blender(path, arr, mode=mode)
    except Exception as exc:
        raise AddonError(_lt(
            "The image could not be saved.",
            "画像を保存できませんでした。"
        )) from exc


def generate_pbr_maps(
    source_path: str | Path,
    output_dir: str | Path | None = None,
    max_size: int = 1024,
    normal_strength: float = 3.0,
    detail_strength: float = 1.0,
) -> dict[str, Any]:
    """Generate a small PBR set from a single input photo.

    The algorithm is intentionally conservative and deterministic. It favors
    robust, reusable maps over aggressive AI-like inference.
    """

    source = Path(source_path)
    if not source.exists() or not source.is_file():
        raise FileNotFoundError(f"Source photo not found: {source}")

    out_root = _safe_output_root(source, output_dir)
    stamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    run_dir = out_root / f"{source.stem}_pbr_{stamp}"
    run_dir.mkdir(parents=True, exist_ok=True)

    result: dict[str, Any] = {
        "ok": False,
        "backend": "generated_maps",
        "io_backend": "pillow" if _has_pillow() else "blender_fallback",
        "source": str(source),
        "output_dir": str(run_dir),
        "generated": {},
        "notes": [],
        "manifest_path": "",
    }
    if not _has_pillow():
        result["notes"].append(_lt("Pillow was not found, so images are read and written by Blender.", "Pillow が見つからないため、画像の読み書きは Blender で行います。"))

    rgb = _open_rgb(source, max_size=max_size)
    result["resolution"] = [int(rgb.shape[1]), int(rgb.shape[0])]

    try:
        base = _illumination_compensated_base(rgb)
        height = _height_from_photo(rgb, detail_strength=detail_strength)
        roughness = _roughness_from_photo(rgb, height)
        occlusion = _occlusion_from_height(height)
        normal = _normal_from_height(height, normal_strength=normal_strength)
    except Exception as exc:
        result["backend"] = "proxy_only"
        result["notes"].append(_lt("Map generation failed, so the base color image is used instead.", "マップを生成できなかったため、ベースカラーの画像で代用します。"))
        base = np.clip(rgb, 0.0, 1.0)
        height = None
        roughness = None
        occlusion = None
        normal = None

    generated: dict[str, str] = {}
    generated["base_color"] = _save_map(run_dir / f"{source.stem}_basecolor.png", base, mode="RGB")
    if height is not None:
        generated["height"] = _save_map(run_dir / f"{source.stem}_height.png", height, mode="L")
    if roughness is not None:
        generated["roughness"] = _save_map(run_dir / f"{source.stem}_roughness.png", roughness, mode="L")
    if occlusion is not None:
        generated["occlusion"] = _save_map(run_dir / f"{source.stem}_ao.png", occlusion, mode="L")
    if normal is not None:
        generated["normal"] = _save_map(run_dir / f"{source.stem}_normal.png", normal, mode="RGB")

    manifest_payload = {
        "smart_shader_suite": {
            "generated_from": str(source),
            "generator": "photo_to_pbr",
            "version": data.ADDON_VERSION,
            "created_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
            "notes": result["notes"],
        },
        "textures": [
            {"usage": usage, "path": path, "usage_hint": usage}
            for usage, path in sorted(generated.items())
        ],
    }
    manifest_path = run_dir / f"{source.stem}_photo_to_pbr_manifest.json"
    manifest_path.write_text(json.dumps(manifest_payload, ensure_ascii=False, indent=2), encoding="utf-8")

    result["generated"] = generated
    result["manifest_path"] = str(manifest_path)
    result["manifest_payload"] = manifest_payload
    result["ok"] = True
    return result
