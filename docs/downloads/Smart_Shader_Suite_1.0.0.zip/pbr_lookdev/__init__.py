# ============================================================================
# PBR Lookdev
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
# ============================================================================

from ..translation import loc_text as _lt, ja_for_en as _ja_for_en
from ..translation import exc_text as _exc_text
from .. import storage
from .. import core
from .. import slot_selection
from .. import ui_sections
bl_info = {'name': 'PBR Lookdev', 'author': 'JELararagi', 'version': (4, 0, 3), 'blender': (5, 1, 0), 'location': 'Smart Shader > PBR Lookdev', 'description': 'Layered PBR Lookdev panel integrated into Smart Shader', 'category': 'Material'}
import bpy, os, json
from pathlib import Path
from bpy.app.handlers import persistent
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import StringProperty, BoolProperty, FloatProperty, FloatVectorProperty, IntProperty, CollectionProperty, EnumProperty, PointerProperty
from ..translation import rna_text_context_prop as _rna_prop
StringProperty, BoolProperty, FloatProperty, FloatVectorProperty, IntProperty, EnumProperty = map(_rna_prop, (StringProperty, BoolProperty, FloatProperty, FloatVectorProperty, IntProperty, EnumProperty))


def _pbr_fallback_property_description(kwargs):
    label = str(kwargs.get('name') or '').strip() or 'PBR setting'
    return _lt(
        f'JP: {label} のPBR ルックデブ設定です。レイヤー、テクスチャ、マスク、マッピングUI切替、シェーダー生成結果を調整します。変更後は必要に応じてビルドまたは再ビルドを実行してください。\n'
        f'EN: {label} PBR Lookdev setting. It adjusts layers, textures, masks, mapping, and generated shader output. Build or rebuild the material when the change should be applied to the node network.'
    )


def _pbr_wrap_property(factory):
    def _wrapped(*args, **kwargs):
        kwargs = dict(kwargs)
        if not kwargs.get('description'):
            kwargs['description'] = _pbr_fallback_property_description(kwargs)
        # CollectionProperty does not accept update=.  Every scalar/vector/
        # pointer N-panel setting does, so chain central persistence behind the
        # tool's existing live shader callback.
        if str(getattr(factory, '__name__', '')) != 'CollectionProperty':
            original_update = kwargs.get('update')

            def _combined_update(self, context):
                if callable(original_update):
                    original_update(self, context)
                callback = globals().get('_pbr_persistence_property_update')
                if callable(callback):
                    callback(self, context)

            kwargs['update'] = _combined_update
        return factory(*args, **kwargs)
    return _wrapped


StringProperty = _pbr_wrap_property(StringProperty)
BoolProperty = _pbr_wrap_property(BoolProperty)
FloatProperty = _pbr_wrap_property(FloatProperty)
FloatVectorProperty = _pbr_wrap_property(FloatVectorProperty)
IntProperty = _pbr_wrap_property(IntProperty)
CollectionProperty = _pbr_wrap_property(CollectionProperty)
EnumProperty = _pbr_wrap_property(EnumProperty)
PointerProperty = _pbr_wrap_property(PointerProperty)


_PBR_PERSISTENCE_APPLYING = False
_PBR_PERSISTENCE_DIRTY = False


def _pbr_state_save_enabled() -> bool:
    try:
        from .. import preferences
        return bool(preferences.is_npanel_state_save_enabled())
    except Exception:
        try:
            return bool(storage.npanel_state_save_enabled(default=True))
        except Exception:
            return True


def _legacy_pbr_ui_state_path() -> Path | None:
    try:
        return storage.settings_file('smart_shader_suite_pbr_lookdev_ui_state.json', create=True)
    except Exception:
        return None


def _pbr_save_ui_state(context=None, *, force: bool = False) -> None:
    try:
        wm = getattr(context, 'window_manager', None) if context is not None else getattr(getattr(bpy, 'context', None), 'window_manager', None)
        value = str(getattr(wm, 'pbr_ui_state', '{}') or '{}') if wm is not None else '{}'
        json.loads(value)
    except Exception:
        value = '{}'
    if not _pbr_state_save_enabled():
        return
    try:
        storage.write_suite_section('pbr_ui_state', json.loads(value))
    except Exception:
        pass


def _pbr_apply_ui_state(context=None) -> None:
    wm = getattr(context, 'window_manager', None) if context is not None else getattr(getattr(bpy, 'context', None), 'window_manager', None)
    if wm is None or not hasattr(wm, 'pbr_ui_state'):
        return
    try:
        wm.pbr_ui_sections.clear()
    except Exception:
        pass
    try:
        document = storage._read_suite_settings_cached()
        if isinstance(document, dict) and 'pbr_ui_state' in document:
            value = document.get('pbr_ui_state')
            if not isinstance(value, dict):
                value = {}
            wm.pbr_ui_state = json.dumps(value, ensure_ascii=False, sort_keys=True)
            return
    except Exception:
        pass
    # One-way compatibility read for the old per-feature JSON.
    path = _legacy_pbr_ui_state_path()
    if path is None or not path.exists():
        return
    try:
        value = path.read_text(encoding='utf-8')
        parsed = json.loads(value)
        wm.pbr_ui_state = json.dumps(parsed, ensure_ascii=False, sort_keys=True)
        storage.write_suite_section('pbr_ui_state', parsed if isinstance(parsed, dict) else {})
    except Exception:
        pass

def _ui_key(*parts):
    return '|'.join((str(p) for p in parts))

def _ui_get(context, *parts, default=False):
    wm = context.window_manager
    store = getattr(wm, 'pbr_ui_state', '{}')
    try:
        return json.loads(store).get(_ui_key(*parts), default)
    except Exception:
        return default

def _ui_set(context, value, *parts):
    wm = context.window_manager
    store = getattr(wm, 'pbr_ui_state', '{}')
    try:
        d = json.loads(store)
    except Exception:
        d = {}
    d[_ui_key(*parts)] = value
    wm.pbr_ui_state = json.dumps(d)
    _pbr_save_ui_state(context)


_PBR_UI_STATE_BRIDGE_SYNC = False


def _pbr_ui_state_item_update(self, context):
    if _PBR_UI_STATE_BRIDGE_SYNC:
        return
    key = str(getattr(self, 'key', '') or '')
    if key:
        _ui_set(context, bool(getattr(self, 'is_open', False)), key)


class PBR_UISectionState(PropertyGroup):
    key: bpy.props.StringProperty(options={'SKIP_SAVE'})
    is_open: bpy.props.BoolProperty(options={'SKIP_SAVE'}, update=_pbr_ui_state_item_update)


def _pbr_ui_state_item(context, key: str, default: bool):
    global _PBR_UI_STATE_BRIDGE_SYNC
    wm = getattr(context, 'window_manager', None)
    items = getattr(wm, 'pbr_ui_sections', None) if wm is not None else None
    if items is None:
        return None
    for item in items:
        if str(getattr(item, 'key', '') or '') == key:
            return item
    item = items.add()
    _PBR_UI_STATE_BRIDGE_SYNC = True
    try:
        item.key = key
        item.is_open = bool(_ui_get(context, key, default=default))
    finally:
        _PBR_UI_STATE_BRIDGE_SYNC = False
    return item


def _pbr_native_panel(layout, context, key: str, *, default: bool):
    item = _pbr_ui_state_item(context, key, default)
    if item is not None:
        return layout.panel_prop(item, 'is_open')
    return layout.panel(
        idname='pbr_lookdev_child_' + str(abs(hash(key))),
        default_closed=not bool(default),
    )
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.exr', '.tif', '.tiff', '.tga', '.bmp', '.hdr', '.webp'}

def _localized_enum_items(items):
    localized = []
    for item in items:
        if len(item) >= 3:
            localized.append((item[0], _lt(item[1]), _lt(item[2]), *item[3:]))
        else:
            localized.append(item)
    return localized

MASK_TYPES = _localized_enum_items([('IMAGE', 'Image', 'Use an image texture as mask'), ('NOISE', 'Noise', 'Procedural noise texture'), ('WAVE', 'Wave', 'Procedural wave texture'), ('GRADIENT', 'Gradient', 'Procedural gradient'), ('VORONOI', 'Voronoi', 'Voronoi / cellular texture')])
WAVE_TYPES = _localized_enum_items([('BANDS', 'Bands', ''), ('RINGS', 'Rings', ''), ('BANDSAW', 'Bandsaw', ''), ('RINGSAW', 'Ringsaw', '')])
WAVE_PROFILES = _localized_enum_items([('SIN', 'Sine', ''), ('SAW', 'Saw', ''), ('TRI', 'Triangle', '')])
GRADIENT_TYPES = _localized_enum_items([('LINEAR', 'Linear', ''), ('QUADRATIC', 'Quadratic', ''), ('EASING', 'Easing', ''), ('DIAGONAL', 'Diagonal', ''), ('SPHERICAL', 'Spherical', ''), ('QUADRATIC_SPHERE', 'Quadratic Sphere', ''), ('RADIAL', 'Radial', '')])
VORONOI_FEATURES = _localized_enum_items([('F1', 'F1', ''), ('F2', 'F2', ''), ('SMOOTH_F1', 'Smooth F1', ''), ('DISTANCE_TO_EDGE', 'Distance to Edge', ''), ('N_SPHERE_RADIUS', 'N-Sphere Radius', '')])
VORONOI_DISTANCES = _localized_enum_items([('EUCLIDEAN', 'Euclidean', ''), ('MANHATTAN', 'Manhattan', ''), ('CHEBYCHEV', 'Chebychev', ''), ('MINKOWSKI', 'Minkowski', '')])
BLEND_MODES = _localized_enum_items([('MIX', 'Mix', 'Blend using mask'), ('MULTIPLY', 'Multiply', 'Multiply (darken)'), ('ADD', 'Add', 'Add (brighten)'), ('SCREEN', 'Screen', 'Screen (lighten)'), ('OVERLAY', 'Overlay', 'Overlay'), ('SOFT_LIGHT', 'Soft Light', 'Soft light')])
SHADER_ITEMS = _localized_enum_items([('PRINCIPLED', 'Principled BSDF', 'Full PBR shader', 'NODE_MATERIAL', 0), ('GLASS', 'Glass BSDF', 'Refractive glass shader', 'MATERIAL', 1), ('EMISSION', 'Emission', 'Emissive light shader', 'LIGHT_SUN', 2), ('DIFFUSE', 'Diffuse BSDF', 'Simple diffuse shader', 'SHADING_SOLID', 3), ('SSS', 'Subsurface Scattering', 'SSS shader', 'OUTLINER_DATA_META', 4)])
MAP_DEF = [('base_color', 'Base Color', 'MATERIAL', 'sRGB', 'COLOR'), ('roughness', 'Roughness', 'NODE_MATERIAL', 'Non-Color', 'FLOAT'), ('diffuse_roughness', 'Diffuse Roughness', 'NODE_MATERIAL', 'Non-Color', 'FLOAT'), ('metallic', 'Metallic', 'SHADING_RENDERED', 'Non-Color', 'FLOAT'), ('ior', 'IOR', 'DRIVER', 'Non-Color', 'FLOAT'), ('specular', 'Specular', 'LIGHT', 'Non-Color', 'FLOAT'), ('specular_ior', 'Specular IOR Level', 'DRIVER', 'Non-Color', 'FLOAT'), ('specular_tint', 'Specular Tint', 'COLOR', 'sRGB', 'COLOR'), ('anisotropic', 'Anisotropic', 'ORIENTATION_GIMBAL', 'Non-Color', 'FLOAT'), ('anisotropic_rot', 'Anisotropic Rotation', 'LOOP_FORWARDS', 'Non-Color', 'FLOAT'), ('normal', 'Normal', 'NORMALS_FACE', 'Non-Color', 'NONE'), ('bump', 'Bump', 'MOD_DISPLACE', 'Non-Color', 'NONE'), ('coat_weight', 'Coat Weight', 'NODE_MATERIAL', 'Non-Color', 'FLOAT'), ('coat_roughness', 'Coat Roughness', 'MESH_CIRCLE', 'Non-Color', 'FLOAT'), ('coat_ior', 'Coat IOR', 'DRIVER', 'Non-Color', 'FLOAT'), ('coat_normal', 'Coat Normal', 'NORMALS_VERTEX_FACE', 'Non-Color', 'NONE'), ('sheen_weight', 'Sheen Weight', 'SURFACE_DATA', 'Non-Color', 'FLOAT'), ('sheen_roughness', 'Sheen Roughness', 'OUTLINER_DATA_SURFACE', 'Non-Color', 'FLOAT'), ('sheen_tint', 'Sheen Tint', 'COLOR', 'sRGB', 'COLOR'), ('emission', 'Emission', 'LIGHT_SUN', 'sRGB', 'COLOR'), ('opacity', 'Opacity / Alpha', 'IMAGE_ALPHA', 'Non-Color', 'FLOAT'), ('ao', 'Ambient Occ.', 'SHADING_SOLID', 'Non-Color', 'FLOAT'), ('sss', 'Subsurface Weight', 'OUTLINER_DATA_META', 'Non-Color', 'FLOAT'), ('translucency', 'Transmission / Translucency', 'MOD_OPACITY', 'Non-Color', 'FLOAT'), ('displacement', 'Displacement', 'MOD_WARP', 'Non-Color', 'FLOAT'), ('glossiness', 'Glossiness', 'SHADING_TEXTURE', 'Non-Color', 'FLOAT'), ('sss_radius', 'SSS Radius', 'OUTLINER_DATA_META', 'sRGB', 'COLOR'), ('sss_scale', 'SSS Scale', 'OUTLINER_DATA_META', 'Non-Color', 'FLOAT'), ('sss_anisotropy', 'SSS Anisotropy', 'ORIENTATION_GIMBAL', 'Non-Color', 'FLOAT'), ('sss_ior', 'SSS IOR', 'DRIVER', 'Non-Color', 'FLOAT'), ('thin_film_thick', 'Thin Film Thickness', 'MESH_CIRCLE', 'Non-Color', 'FLOAT'), ('thin_film_ior', 'Thin Film IOR', 'DRIVER', 'Non-Color', 'FLOAT')]
MAP_KEYS = [d[0] for d in MAP_DEF]
MAP_INFO = {d[0]: d[1:] for d in MAP_DEF}
BSDF_SOCKETS = {'PRINCIPLED': {'base_color': 'Base Color', 'roughness': 'Roughness', 'diffuse_roughness': ('Diffuse Roughness',), 'glossiness': 'Roughness', 'metallic': 'Metallic', 'ior': 'IOR', 'specular': 'Specular Tint', 'specular_ior': ('Specular IOR Level',), 'specular_tint': 'Specular Tint', 'anisotropic': 'Anisotropic', 'anisotropic_rot': 'Anisotropic Rotation', 'normal': 'Normal', 'bump': 'Normal', 'coat_weight': ('Coat Weight', 'Clear Layercoat'), 'coat_roughness': ('Coat Roughness', 'Clear Layercoat Roughness'), 'coat_ior': ('Coat IOR',), 'coat_normal': ('Coat Normal', 'Clear Layercoat Normal'), 'sheen_weight': ('Sheen Weight', 'Sheen'), 'sheen_roughness': ('Sheen Roughness',), 'sheen_tint': ('Sheen Tint',), 'emission': ('Emission Color', 'Emission'), 'opacity': 'Alpha', 'sss': ('Subsurface Weight', 'Subsurface'), 'sss_radius': ('Subsurface Radius',), 'sss_scale': ('Subsurface Scale',), 'sss_anisotropy': ('Subsurface Anisotropy',), 'thin_film_thick': ('Thin Film Thickness',), 'thin_film_ior': ('Thin Film IOR',), 'translucency': ('Transmission Weight', 'Transmission')}, 'GLASS': {'base_color': 'Color', 'roughness': 'Roughness', 'ior': 'IOR', 'normal': 'Normal', 'bump': 'Normal'}, 'EMISSION': {'emission': 'Color'}, 'DIFFUSE': {'base_color': 'Color', 'roughness': 'Roughness', 'diffuse_roughness': ('Diffuse Roughness',), 'normal': 'Normal', 'bump': 'Normal'}, 'SSS': {'base_color': 'Color', 'roughness': 'Roughness', 'normal': 'Normal', 'bump': 'Normal', 'sss': ('Scale',), 'sss_radius': ('Subsurface Radius',), 'sss_scale': ('Scale',), 'sss_anisotropy': ('Anisotropy',), 'sss_ior': ('IOR',), 'anisotropic': ('Anisotropy',)}}
SHADER_MAPS = {'PRINCIPLED': [k for k in MAP_KEYS if k != 'displacement'], 'GLASS': ['base_color', 'roughness', 'glossiness', 'ior', 'normal', 'bump'], 'EMISSION': ['emission'], 'DIFFUSE': ['base_color', 'roughness', 'diffuse_roughness', 'glossiness', 'normal', 'bump'], 'SSS': ['base_color', 'roughness', 'normal', 'bump', 'sss', 'sss_radius', 'sss_scale', 'sss_anisotropy', 'anisotropic']}
SHADER_NODE_TYPE = {'PRINCIPLED': 'ShaderNodeBsdfPrincipled', 'GLASS': 'ShaderNodeBsdfGlass', 'EMISSION': 'ShaderNodeEmission', 'DIFFUSE': 'ShaderNodeBsdfDiffuse', 'SSS': 'ShaderNodeSubsurfaceScattering'}
SHADER_OUTPUT_SOCKET = {'PRINCIPLED': 'BSDF', 'GLASS': 'BSDF', 'EMISSION': 'Emission', 'DIFFUSE': 'BSDF', 'SSS': 'BSDF'}
SHADER_BSDF_TYPE = {'PRINCIPLED': 'BSDF_PRINCIPLED', 'GLASS': 'BSDF_GLASS', 'EMISSION': 'EMISSION', 'DIFFUSE': 'BSDF_DIFFUSE', 'SSS': 'SUBSURFACE_SCATTERING'}
SHADER_OUTPUT_SOCKET = {'PRINCIPLED': 'BSDF', 'GLASS': 'BSDF', 'EMISSION': 'Emission', 'DIFFUSE': 'BSDF', 'SSS': 'BSDF'}
MAP_GROUPS = [('base', 'Base Color', 'MATERIAL', ['base_color']), ('roughness', 'Roughness', 'NODE_MATERIAL', ['roughness', 'glossiness', 'diffuse_roughness']), ('metal_spec', 'Metal / Specular', 'SHADING_RENDERED', ['metallic', 'ior', 'specular_ior', 'specular_tint', 'anisotropic', 'anisotropic_rot']), ('normal', 'Normal / Bump', 'NORMALS_FACE', ['normal', 'bump']), ('coat', 'Coat', 'NODE_MATERIAL', ['coat_weight', 'coat_roughness', 'coat_ior', 'coat_normal']), ('sheen', 'Sheen', 'SURFACE_DATA', ['sheen_weight', 'sheen_roughness', 'sheen_tint']), ('emission', 'Emission', 'LIGHT_SUN', ['emission']), ('transparency', 'Transparency', 'IMAGE_ALPHA', ['opacity', 'translucency']), ('sss', 'Subsurface', 'OUTLINER_DATA_META', ['sss', 'sss_radius', 'sss_scale', 'sss_anisotropy']), ('thin_film', 'Thin Film', 'MESH_CIRCLE', ['thin_film_thick', 'thin_film_ior']), ('ao', 'Ambient Occ.', 'SHADING_SOLID', ['ao']), ('displacement', 'Displacement', 'MOD_WARP', ['displacement'])]
SHADER_GROUPS = {'PRINCIPLED': ['base', 'roughness', 'metal_spec', 'normal', 'coat', 'sheen', 'emission', 'transparency', 'sss', 'thin_film', 'ao', 'displacement'], 'GLASS': ['base', 'roughness', 'metal_spec', 'normal'], 'EMISSION': ['emission'], 'DIFFUSE': ['base', 'roughness', 'normal'], 'SSS': ['base', 'roughness', 'normal', 'sss', 'thin_film']}
GRAYSCALE_KEYS = {k for k in MAP_KEYS if MAP_INFO[k][3] == 'FLOAT'}
MAP_KEYWORDS = {'base_color': ['basecolor', 'base_color', 'albedo', 'diffuse', '_diff', '_col_', '_color', '_alb', '_bc'], 'roughness': ['roughness', '_rough', '_rgh', '_roughness'], 'diffuse_roughness': ['diffuse_rough', 'diffuseroughness', '_diffrough'], 'glossiness': ['glossiness', '_gloss', '_gls', 'gloss'], 'metallic': ['metallic', 'metalness', '_metal', '_met_', '_mtl'], 'normal': ['_normal', '_nor_', '_nrm', '_nrl', 'normalgl', 'normaldx'], 'bump': ['_bump', '_bmp', 'bump_'], 'ao': ['ambientocclusion', 'ambient_occlusion', '_ao', '_ao_', 'occlusion', '_occ'], 'emission': ['emission', 'emissive', '_emit', '_glow'], 'opacity': ['opacity', '_alpha', '_transparent', '_mask', '_opac'], 'displacement': ['displacement', '_disp', '_height', '_hgt', 'heightmap'], 'sss': ['subsurface', '_sss', 'scattering'], 'translucency': ['translucency', 'translucent', 'transmission', '_trans_'], 'specular': ['specular', '_spec', '_spc'], 'specular_ior': ['specularior', 'specular_ior', 'spec_ior'], 'specular_tint': ['speculartint', 'specular_tint'], 'coat_weight': ['clearcoat', 'coat', '_coat'], 'coat_roughness': ['clearcoat_rough', 'coat_rough', 'coatroughness'], 'coat_ior': ['coat_ior', 'clearcoat_ior'], 'sheen_weight': ['sheen', '_sheen'], 'anisotropic': ['anisotropic', 'aniso'], 'anisotropic_rot': ['anisotropic_rot', 'aniso_rot'], 'ior': [], 'coat_normal': ['coat_normal', 'clearcoat_normal'], 'sheen_roughness': ['sheen_rough', 'sheenroughness'], 'sheen_tint': ['sheen_tint', 'sheentint'], 'sss_radius': ['sss_radius', 'subsurface_radius'], 'sss_scale': ['sss_scale', 'subsurface_scale'], 'sss_anisotropy': ['sss_anisotropy'], 'sss_ior': ['sss_ior'], 'thin_film_thick': ['thin_film', 'thinfilm'], 'thin_film_ior': ['thin_film_ior']}

def _detect_map(filename):
    name = os.path.splitext(filename)[0].lower().replace('-', '_').replace(' ', '_')
    scores = {mt: sum((len(k) for k in kws if kws and k.replace(' ', '_') in name)) for mt, kws in MAP_KEYWORDS.items()}
    scores = {k: v for k, v in scores.items() if v}
    return max(scores, key=scores.get) if scores else None

def scan_dir(directory):
    if not (directory and os.path.isdir(directory)):
        return {}
    best = {}
    for f in os.listdir(directory):
        if os.path.splitext(f)[1].lower() not in IMAGE_EXTENSIONS:
            continue
        mt = _detect_map(f)
        if not mt:
            continue
        sc = sum((len(k) for k in MAP_KEYWORDS.get(mt, []) if k.replace(' ', '_') in f.lower()))
        if mt not in best or sc > best[mt][0]:
            best[mt] = (sc, os.path.join(directory, f))
    return {mt: v[1] for mt, v in best.items()}


def _pbr_json_value(value):
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    try:
        result = []
        for item in value:
            if not isinstance(item, (bool, int, float, str)) and item is not None:
                return None
            result.append(item)
        return result
    except Exception:
        return None


def _pbr_serialize_group(group) -> dict:
    result = {}
    try:
        props = getattr(getattr(group, 'bl_rna', None), 'properties', ()) or ()
    except Exception:
        props = ()
    for prop in props:
        name = str(getattr(prop, 'identifier', '') or '')
        if not name or name == 'rna_type':
            continue
        try:
            value = getattr(group, name)
        except Exception:
            continue
        prop_type = str(getattr(prop, 'type', '') or '')
        if prop_type == 'COLLECTION':
            try:
                result[name] = [_pbr_serialize_group(item) for item in value]
            except Exception:
                pass
            continue
        if prop_type == 'POINTER':
            # Do not copy external Blender datablocks into the global settings.
            continue
        converted = _pbr_json_value(value)
        if converted is not None or value is None:
            result[name] = converted
    return result


def _pbr_apply_group(group, payload) -> int:
    if group is None or not isinstance(payload, dict):
        return 0
    applied = 0
    try:
        prop_map = getattr(getattr(group, 'bl_rna', None), 'properties', None)
    except Exception:
        prop_map = None
    for name, value in payload.items():
        try:
            prop = prop_map.get(str(name)) if prop_map is not None else None
        except Exception:
            prop = None
        prop_type = str(getattr(prop, 'type', '') or '')
        if prop_type == 'COLLECTION' and isinstance(value, list):
            try:
                collection = getattr(group, str(name))
                collection.clear()
                for item_payload in value:
                    item = collection.add()
                    applied += _pbr_apply_group(item, item_payload)
                applied += 1
            except Exception:
                pass
            continue
        if prop_type == 'POINTER':
            continue
        try:
            setattr(group, str(name), value)
            applied += 1
        except Exception:
            pass
    return applied


def save_pbr_material_settings(material=None, *, force: bool = False) -> bool:
    """Persist PBR N-panel options by exact material name, never node data."""
    global _PBR_PERSISTENCE_DIRTY
    if not force and not _pbr_state_save_enabled():
        _PBR_PERSISTENCE_DIRTY = True
        return False
    try:
        if material is None:
            materials = {}
            for mat in list(getattr(bpy.data, 'materials', ()) or ()):
                props = getattr(mat, 'pbr_properties', None)
                if props is None:
                    continue
                # An unbuilt material can still contain user-edited PBR
                # N-panel state (for example the active row or options chosen
                # before the first Build).  A forced all-settings flush must
                # therefore serialize every material that owns the property
                # group.  Dropping unbuilt/empty materials here erased those
                # deferred edits when N-panel State Save was re-enabled.
                materials[str(mat.name)] = _pbr_serialize_group(props)
        else:
            materials = storage.read_suite_section('pbr_materials', {})
            materials = dict(materials) if isinstance(materials, dict) else {}
            props = getattr(material, 'pbr_properties', None)
            if props is not None:
                materials[str(material.name)] = _pbr_serialize_group(props)
        saved = bool(storage.write_suite_section('pbr_materials', materials))
        if saved:
            _PBR_PERSISTENCE_DIRTY = False
        return saved
    except Exception:
        return False


def restore_pbr_material_settings() -> int:
    global _PBR_PERSISTENCE_APPLYING
    payload = storage.read_suite_section('pbr_materials', {})
    if not isinstance(payload, dict):
        return 0
    applied = 0
    _PBR_PERSISTENCE_APPLYING = True
    try:
        for material_name, values in payload.items():
            try:
                material = bpy.data.materials.get(str(material_name))
            except Exception:
                material = None
            if material is None:
                continue
            applied += _pbr_apply_group(getattr(material, 'pbr_properties', None), values)
    finally:
        _PBR_PERSISTENCE_APPLYING = False
    return applied


def _pbr_persistence_property_update(self, context) -> None:
    if _PBR_PERSISTENCE_APPLYING:
        return
    try:
        material = getattr(self, 'id_data', None)
        if not isinstance(material, bpy.types.Material):
            material = _active_mat(context)
        if material is not None:
            save_pbr_material_settings(material)
    except Exception:
        pass


def _live(self, context):
    if _PBR_PERSISTENCE_APPLYING:
        return
    mat = _active_mat(context)
    if mat and mat.pbr_properties.is_built:
        build_network(mat)

class PBR_Overlay(PropertyGroup):
    """One image overlay entry — image + its blend mask, always paired."""
    name: StringProperty(name=_lt('Name'), default='Texture Layer')
    enabled: BoolProperty(default=True, update=_live)
    path: StringProperty(name=_lt('Image'), subtype='FILE_PATH', update=_live)
    udim: BoolProperty(name=_lt('UDIM'), default=False, update=_live, description=_lt('Treat as UDIM tile sequence'))
    img_min: FloatProperty(name=_lt('Min'), default=0.0, min=0.0, max=1.0, description=_lt('Black point'), update=_live)
    img_max: FloatProperty(name=_lt('Max'), default=1.0, min=0.0, max=1.0, description=_lt('White point'), update=_live)
    blend_mode: EnumProperty(items=BLEND_MODES, default='MIX', update=_live)
    strength: FloatProperty(name=_lt('Strength'), default=1.0, min=0.0, max=1.0, subtype='FACTOR', update=_live)
    hue: FloatProperty(name=_lt('Hue'), default=0.5, min=0.0, max=1.0, subtype='FACTOR', update=_live)
    saturation: FloatProperty(name=_lt('Saturation'), default=1.0, min=0.0, soft_max=2.0, update=_live)
    value: FloatProperty(name=_lt('Value'), default=1.0, min=0.0, soft_max=2.0, update=_live)
    contrast: FloatProperty(name=_lt('Contrast'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
    gamma: FloatProperty(name=_lt('Gamma'), default=1.0, min=0.01, soft_max=5.0, update=_live)
    mask_path: StringProperty(name=_lt('Mask'), subtype='FILE_PATH', update=_live)
    mask_udim: BoolProperty(name=_lt('UDIM'), default=False, update=_live, description=_lt('Treat mask as UDIM tile sequence'))
    mask_min: FloatProperty(name=_lt('Min'), default=0.0, min=0.0, max=1.0, description=_lt('Mask black point'), update=_live)
    mask_max: FloatProperty(name=_lt('Max'), default=1.0, min=0.0, max=1.0, description=_lt('Mask white point'), update=_live)
    mask_invert: BoolProperty(name=_lt('Invert'), default=False, update=_live)
    mask_use_own_mapping: BoolProperty(name=_lt('Override Mapping', 'マッピングを上書き'), default=False, update=_live)
    mask_tiling_x: FloatProperty(name=_lt('X'), default=1.0, min=0.001, soft_max=100.0, update=_live)
    mask_tiling_y: FloatProperty(name=_lt('Y'), default=1.0, min=0.001, soft_max=100.0, update=_live)
    mask_tiling_lock: BoolProperty(name=_lt('Lock'), default=True, update=_live)
    mask_offset_x: FloatProperty(name=_lt('X'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
    mask_offset_y: FloatProperty(name=_lt('Y'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
    mask_rotation: FloatProperty(name=_lt('Rot'), default=0.0, subtype='ANGLE', update=_live)
    mask_type: EnumProperty(name=_lt('Mask Type'), items=MASK_TYPES, default='IMAGE', update=_live)
    mask_proc_scale: FloatProperty(name=_lt('Scale'), default=5.0, min=0.0, soft_max=100.0, update=_live)
    mask_proc_detail: FloatProperty(name=_lt('Detail'), default=2.0, min=0.0, max=15.0, update=_live)
    mask_proc_roughness: FloatProperty(name=_lt('Roughness'), default=0.5, min=0.0, max=1.0, update=_live)
    mask_proc_distortion: FloatProperty(name=_lt('Distortion'), default=0.0, min=-1000.0, max=1000.0, update=_live)
    mask_wave_type: EnumProperty(name=_lt('Wave Type'), items=WAVE_TYPES, default='BANDS', update=_live)
    mask_wave_profile: EnumProperty(name=_lt('Wave Profile'), items=WAVE_PROFILES, default='SIN', update=_live)
    mask_gradient_type: EnumProperty(name=_lt('Gradient Type'), items=GRADIENT_TYPES, default='LINEAR', update=_live)
    mask_voronoi_feature: EnumProperty(name=_lt('Feature'), items=VORONOI_FEATURES, default='F1', update=_live)
    mask_voronoi_distance: EnumProperty(name=_lt('Distance'), items=VORONOI_DISTANCES, default='EUCLIDEAN', update=_live)
    mask_voronoi_random: FloatProperty(name=_lt('Randomness'), default=1.0, min=0.0, max=1.0, update=_live)
    img_tiling_x: FloatProperty(name=_lt('X'), default=1.0, min=0.001, soft_max=100.0, update=_live)
    img_tiling_y: FloatProperty(name=_lt('Y'), default=1.0, min=0.001, soft_max=100.0, update=_live)
    img_tiling_lock: BoolProperty(name=_lt('Lock'), default=True, update=_live)
    img_offset_x: FloatProperty(name=_lt('X'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
    img_offset_y: FloatProperty(name=_lt('Y'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
    img_rotation: FloatProperty(name=_lt('Rot'), default=0.0, subtype='ANGLE', update=_live)
    img_use_own_mapping: BoolProperty(name=_lt('Override Mapping', 'マッピングを上書き'), default=False, update=_live)
    show_overlay: BoolProperty(default=True, options={'SKIP_SAVE'})
    show_mask_settings: BoolProperty(default=False, options={'SKIP_SAVE'})
    show_color_correction: BoolProperty(default=False, options={'SKIP_SAVE'})

def _make_path_properties():
    return {f'path_{k}': StringProperty(name=_lt(MAP_INFO[k][0]), subtype='FILE_PATH') for k in MAP_KEYS}

def _make_use_properties():
    return {f'use_{k}': BoolProperty(default=True, update=_live) for k in MAP_KEYS}

def _make_strength_properties():
    return {f'str_{k}': FloatProperty(name=_lt('Strength'), default=1.0, min=0.0, soft_max=100.0, update=_live) for k in MAP_KEYS}

def _make_udim_properties():
    return {f'udim_{k}': BoolProperty(name=_lt('UDIM'), default=False, description=_lt('Treat this path as a UDIM tile sequence'), update=_live) for k in MAP_KEYS}

def _make_extra_properties():
    return {f'extra_{k}': CollectionProperty(type=PBR_Overlay) for k in MAP_KEYS}

def _make_range_properties():
    """Min/Max per grayscale channel."""
    properties = {}
    for k in GRAYSCALE_KEYS:
        properties[f'min_{k}'] = FloatProperty(name=_lt('Min'), default=0.0, min=0.0, max=1.0, description=_lt(f"{MAP_INFO[k][0]} black point", f"{_ja_for_en(MAP_INFO[k][0])} 黒点"), update=_live)
        properties[f'max_{k}'] = FloatProperty(name=_lt('Max'), default=1.0, min=0.0, max=1.0, description=_lt(f"{MAP_INFO[k][0]} white point", f"{_ja_for_en(MAP_INFO[k][0])} 白点"), update=_live)
    return properties

def _make_val_properties():
    properties = {}
    for k in MAP_KEYS:
        vtype = MAP_INFO[k][3]
        if vtype == 'COLOR':
            if k == 'sss_radius':
                properties[f'val_{k}'] = FloatVectorProperty(name=_lt(MAP_INFO[k][0]), subtype='NONE', default=(1.0, 0.2, 0.1), size=3, min=0.0, soft_max=10.0, update=_live)
            else:
                default = (1.0, 1.0, 1.0, 1.0) if k not in ('emission', 'specular_tint', 'sheen_tint') else (0.0, 0.0, 0.0, 1.0)
                properties[f'val_{k}'] = FloatVectorProperty(name=_lt(MAP_INFO[k][0]), subtype='COLOR', default=default, size=4, min=0.0, max=1.0, update=_live)
        elif vtype == 'FLOAT':
            defaults = {'roughness': 0.5, 'metallic': 0.0, 'ior': 1.45, 'specular': 0.5, 'specular_ior': 1.5, 'diffuse_roughness': 0.0, 'coat_weight': 0.0, 'sheen_weight': 0.0, 'opacity': 1.0, 'ao': 1.0, 'sss': 0.0, 'translucency': 0.0, 'displacement': 0.0, 'glossiness': 0.5, 'anisotropic': 0.0, 'anisotropic_rot': 0.0, 'coat_ior': 1.5, 'coat_roughness': 0.03, 'sss_scale': 0.05, 'sss_anisotropy': 0.0, 'sss_ior': 1.4, 'thin_film_thick': 0.0, 'thin_film_ior': 1.5, 'sheen_roughness': 0.5}
            range_overrides = {'ior': (1.0, 5.0), 'specular_ior': (1.0, 5.0), 'sss_ior': (1.0, 5.0), 'coat_ior': (1.0, 5.0), 'thin_film_ior': (1.0, 5.0), 'sss_scale': (0.0, 100.0), 'thin_film_thick': (0.0, 1000.0), 'displacement': (-10.0, 10.0), 'anisotropic_rot': (0.0, 1.0)}
            mn, mx = range_overrides.get(k, (0.0, 1.0))
            properties[f'val_{k}'] = FloatProperty(name=_lt(MAP_INFO[k][0]), default=defaults.get(k, 0.0), min=mn, soft_max=mx, update=_live)
    return properties

class PBR_MapLayer(PropertyGroup):
    name: StringProperty(name=_lt('Layer Name'), default='Layer')
    enabled: BoolProperty(default=True, update=_live)
    shader_type: EnumProperty(name=_lt('Shader'), items=SHADER_ITEMS, default='PRINCIPLED', update=_live)
    tiling_x: FloatProperty(name=_lt('X'), default=1.0, min=0.001, soft_max=100.0, update=_live)
    tiling_y: FloatProperty(name=_lt('Y'), default=1.0, min=0.001, soft_max=100.0, update=_live)
    tiling_lock: BoolProperty(name=_lt('Lock'), default=True, update=_live)
    offset_x: FloatProperty(name=_lt('X'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
    offset_y: FloatProperty(name=_lt('Y'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
    rotation: FloatProperty(name=_lt('Rotation'), default=0.0, subtype='ANGLE', update=_live)
    hue: FloatProperty(name=_lt('Hue'), default=0.5, min=0.0, max=1.0, subtype='FACTOR', update=_live)
    saturation: FloatProperty(name=_lt('Saturation'), default=1.0, min=0.0, soft_max=2.0, update=_live)
    value: FloatProperty(name=_lt('Value'), default=1.0, min=0.0, soft_max=2.0, update=_live)
    contrast: FloatProperty(name=_lt('Contrast'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
    gamma: FloatProperty(name=_lt('Gamma'), default=1.0, min=0.01, soft_max=5.0, update=_live)
    normal_strength: FloatProperty(name=_lt('Normal Strength'), default=1.0, min=0.0, soft_max=10.0, update=_live)
    bump_strength: FloatProperty(name=_lt('Bump Strength'), default=0.1, min=0.0, soft_max=1.0, update=_live)
    ao_strength: FloatProperty(name=_lt('AO Strength'), default=0.8, min=0.0, soft_max=1.0, subtype='FACTOR', update=_live)
    emission_strength: FloatProperty(name=_lt('Emission Strength'), default=1.0, min=0.0, soft_max=10.0, update=_live)
    roughness_bias: FloatProperty(name=_lt('Roughness Bias'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
    metallic_bias: FloatProperty(name=_lt('Metallic Bias'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
    disp_scale: FloatProperty(name=_lt('Scale'), default=0.1, min=0.0, soft_max=1.0, update=_live)
    disp_midlevel: FloatProperty(name=_lt('Midlevel'), default=0.5, min=0.0, max=1.0, update=_live)
    sss_scale: FloatProperty(name=_lt('SSS Scale'), default=0.05, min=0.0, soft_max=2.0, update=_live)
    mask_path: StringProperty(name=_lt('Mask'), subtype='FILE_PATH', update=_live)
    mask_udim: BoolProperty(name=_lt('UDIM'), default=False, update=_live, description=_lt('Treat mask as UDIM tile sequence'))
    mask_invert: BoolProperty(name=_lt('Invert'), default=False, update=_live)
    mask_strength: FloatProperty(name=_lt('Strength'), default=1.0, min=0.0, max=1.0, subtype='FACTOR', update=_live)
    mask_min: FloatProperty(name=_lt('Min'), default=0.0, min=0.0, max=1.0, update=_live)
    mask_max: FloatProperty(name=_lt('Max'), default=1.0, min=0.0, max=1.0, update=_live)
    blend_mode: EnumProperty(name=_lt('Blend'), items=BLEND_MODES, default='MIX', update=_live)
    mask_type: EnumProperty(name=_lt('Mask Type'), items=MASK_TYPES, default='IMAGE', update=_live)
    mask_proc_scale: FloatProperty(name=_lt('Scale'), default=5.0, min=0.0, soft_max=100.0, update=_live)
    mask_proc_detail: FloatProperty(name=_lt('Detail'), default=2.0, min=0.0, max=15.0, update=_live)
    mask_proc_roughness: FloatProperty(name=_lt('Roughness'), default=0.5, min=0.0, max=1.0, update=_live)
    mask_proc_distortion: FloatProperty(name=_lt('Distortion'), default=0.0, min=-1000.0, max=1000.0, update=_live)
    mask_wave_type: EnumProperty(name=_lt('Wave Type'), items=WAVE_TYPES, default='BANDS', update=_live)
    mask_wave_profile: EnumProperty(name=_lt('Wave Profile'), items=WAVE_PROFILES, default='SIN', update=_live)
    mask_gradient_type: EnumProperty(name=_lt('Gradient Type'), items=GRADIENT_TYPES, default='LINEAR', update=_live)
    mask_voronoi_feature: EnumProperty(name=_lt('Feature'), items=VORONOI_FEATURES, default='F1', update=_live)
    mask_voronoi_distance: EnumProperty(name=_lt('Distance'), items=VORONOI_DISTANCES, default='EUCLIDEAN', update=_live)
    mask_voronoi_random: FloatProperty(name=_lt('Randomness'), default=1.0, min=0.0, max=1.0, update=_live)
    mask_tiling_x: FloatProperty(name=_lt('X'), default=1.0, min=0.001, soft_max=100.0, update=_live)
    mask_tiling_y: FloatProperty(name=_lt('Y'), default=1.0, min=0.001, soft_max=100.0, update=_live)
    mask_tiling_lock: BoolProperty(name=_lt('Lock'), default=True, update=_live)
    mask_offset_x: FloatProperty(name=_lt('X'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
    mask_offset_y: FloatProperty(name=_lt('Y'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
    mask_rotation: FloatProperty(name=_lt('Rot'), default=0.0, subtype='ANGLE', update=_live)
    specular_distribution: EnumProperty(name=_lt('Distribution'), items=_localized_enum_items([('GGX', 'GGX', ''), ('MULTI_GGX', 'Multiscatter GGX', '')]), default='MULTI_GGX', update=_live)
    sss_method: EnumProperty(name=_lt('SSS Method'), items=_localized_enum_items([('BURLEY', 'Christensen-Burley', ''), ('RANDOM_WALK', 'Random Walk', ''), ('RANDOM_WALK_SKIN', 'Random Walk (Skin)', '')]), default='RANDOM_WALK', update=_live)
    bc_tiling_x: FloatProperty(name=_lt('X'), default=1.0, min=0.001, soft_max=100.0, update=_live)
    bc_tiling_y: FloatProperty(name=_lt('Y'), default=1.0, min=0.001, soft_max=100.0, update=_live)
    bc_tiling_lock: BoolProperty(name=_lt('Lock'), default=True, update=_live)
    bc_offset_x: FloatProperty(name=_lt('X'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
    bc_offset_y: FloatProperty(name=_lt('Y'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
    bc_rotation: FloatProperty(name=_lt('Rot'), default=0.0, subtype='ANGLE', update=_live)
    bc_use_own_mapping: BoolProperty(name=_lt('Override Mapping', 'マッピングを上書き'), default=False, update=_live)
    scan_dir_path: StringProperty(name=_lt('Folder'), subtype='DIR_PATH', default='')
    show_maps: BoolProperty(default=False, options={'SKIP_SAVE'})
    show_mapping: BoolProperty(default=False, options={'SKIP_SAVE'})
    show_color: BoolProperty(default=False, options={'SKIP_SAVE'})
    show_surface: BoolProperty(default=False, options={'SKIP_SAVE'})
    show_geometry: BoolProperty(default=False, options={'SKIP_SAVE'})
    show_mask: BoolProperty(default=False, options={'SKIP_SAVE'})

def _make_own_transform_properties():
    properties = {}
    for k in MAP_KEYS:
        properties[f'ch_tiling_x_{k}'] = FloatProperty(name=_lt('X'), default=1.0, min=0.001, soft_max=100.0, update=_live)
        properties[f'ch_tiling_y_{k}'] = FloatProperty(name=_lt('Y'), default=1.0, min=0.001, soft_max=100.0, update=_live)
        properties[f'ch_tiling_lock_{k}'] = BoolProperty(name=_lt('Lock'), default=True, update=_live)
        properties[f'ch_offset_x_{k}'] = FloatProperty(name=_lt('X'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
        properties[f'ch_offset_y_{k}'] = FloatProperty(name=_lt('Y'), default=0.0, soft_min=-1.0, soft_max=1.0, update=_live)
        properties[f'ch_rotation_{k}'] = FloatProperty(name=_lt('Rot'), default=0.0, subtype='ANGLE', update=_live)
        properties[f'ch_own_mapping_{k}'] = BoolProperty(name=_lt('Override Mapping', 'マッピングを上書き'), default=False, update=_live)
    return properties
_slot_show = {f'show_slot_{k}': BoolProperty(default=False, options={'SKIP_SAVE'}) for k in MAP_KEYS}
_group_show = {f'show_group_{g[0]}': BoolProperty(default=False, options={'SKIP_SAVE'}) for g in MAP_GROUPS}
for _k, _prop in {**_make_path_properties(), **_make_use_properties(), **_make_udim_properties(), **_make_strength_properties(), **_make_extra_properties(), **_make_range_properties(), **_make_val_properties(), **_make_own_transform_properties(), **_slot_show, **_group_show}.items():
    PBR_MapLayer.__annotations__[_k] = _prop

class PBR_MaterialProps(PropertyGroup):
    layers: CollectionProperty(type=PBR_MapLayer)
    active_layer_index: IntProperty(default=0)
    is_built: BoolProperty(default=False)

def _ppath(layer, key):
    p = getattr(layer, f'path_{key}', '').strip()
    return bpy.path.abspath(p) if p else ''

def _has_img(layer, key):
    p = _ppath(layer, key)
    return bool(p and os.path.isfile(p))

def _has_extras(layer, key):
    return any((os.path.isfile(bpy.path.abspath(e.path.strip())) for e in getattr(layer, f'extra_{key}', []) if e.path.strip()))

def _use(layer, key):
    return getattr(layer, f'use_{key}', True)

def _pbr_safe_active_object(context):
    try:
        obj = getattr(context, 'active_object', None)
    except Exception:
        return None
    if obj is None:
        return None
    try:
        _ = obj.name
    except Exception:
        return None
    return obj


def _pbr_context_is_stable(context):
    if context is None or getattr(context, 'scene', None) is None:
        return False
    try:
        mode = str(getattr(context, 'mode', '') or 'OBJECT')
    except Exception:
        mode = 'OBJECT'
    try:
        area_type = getattr(getattr(context, 'area', None), 'type', '')
    except Exception:
        area_type = ''
    obj = _pbr_safe_active_object(context)
    if area_type == 'VIEW_3D' and mode not in {'', 'OBJECT'}:
        return False
    if obj is None and mode not in {'', 'OBJECT'}:
        return False
    return True


def _active_mat(context):
    try:
        spc = getattr(context, 'space_data', None)
    except Exception:
        spc = None
    try:
        if spc and getattr(spc, 'type', '') == 'NODE_EDITOR':
            id_ = getattr(spc, 'id', None)
            if isinstance(id_, bpy.types.Material):
                return id_
    except Exception:
        pass
    obj = _pbr_safe_active_object(context)
    try:
        if obj and getattr(obj, 'type', '') == 'MESH':
            return getattr(obj, 'active_material', None)
    except Exception:
        return None
    return None

def _nl(li, tag):
    return f'L{li}_{tag}'

def _by_lbl(nt, l):
    return next((n for n in nt.nodes if n.label == l), None)

def _ensure(nt, ntype, label, x, y):
    n = _by_lbl(nt, label)
    if n is None:
        n = nt.nodes.new(ntype)
        n.label = label
        n.location = (x, y)
    return n

def _link(nt, a, b):
    for l in list(b.links):
        nt.links.remove(l)
    nt.links.new(a, b)

def _load_img(path, cs, udim=False):
    """Load a regular image or a UDIM tile sequence."""
    if not path or not path.strip():
        return None
    abs_path = bpy.path.abspath(path.strip())
    if udim:
        img_name = os.path.basename(abs_path)
        existing = bpy.data.images.get(img_name)
        if existing and existing.source == 'TILED':
            existing.colorspace_settings.name = cs
            return existing
        if existing:
            bpy.data.images.remove(existing)
        if not os.path.isfile(abs_path):
            return None
        img = bpy.data.images.load(abs_path, check_existing=False)
        img.name = img_name
        img.source = 'TILED'
        img.colorspace_settings.name = cs
        try:
            img.reload()
        except Exception:
            pass
        return img
    if not os.path.isfile(abs_path):
        return None
    try:
        img = bpy.data.images.load(abs_path, check_existing=True)
        img.colorspace_settings.name = cs
        if img.source == 'TILED':
            img.source = 'FILE'
        return img
    except Exception:
        return None

def _purge(nt, prefix):
    for n in [n for n in nt.nodes if n.label.startswith(prefix)]:
        nt.nodes.remove(n)

def _maprange(nt, label, in_sock, mn, mx, x, y):
    """Insert a MapRange node for min/max (black/white point). Returns output Value socket."""
    if mn == 0.0 and mx == 1.0:
        n = _by_lbl(nt, label)
        if n:
            nt.nodes.remove(n)
        return in_sock
    mr = _ensure(nt, 'ShaderNodeMapRange', label, x, y)
    mr.data_type = 'FLOAT'
    mr.interpolation_type = 'LINEAR'
    mr.clamp = True
    mr.inputs[1].default_value = mn
    mr.inputs[2].default_value = mx
    mr.inputs[3].default_value = 0.0
    mr.inputs[4].default_value = 1.0
    _link(nt, in_sock, mr.inputs[0])
    return mr.outputs[0]

def _bsdf_out(bsdf, stype):
    """Return the correct output socket regardless of shader type."""
    name = SHADER_OUTPUT_SOCKET.get(stype, 'BSDF')
    try:
        return bsdf.outputs[name]
    except Exception:
        return bsdf.outputs[0]

def _sock(bsdf, name_or_tuple):
    names = name_or_tuple if isinstance(name_or_tuple, (list, tuple)) else [name_or_tuple]
    for nm in names:
        try:
            return bsdf.inputs[nm]
        except Exception:
            pass
    return None

def _connect(nt, bsdf, key, sockets_map, out_sock):
    target = sockets_map.get(key)
    if not target:
        return
    s = _sock(bsdf, target)
    if s:
        _link(nt, out_sock, s)

def _set_val(bsdf, key, sockets_map, value):
    target = sockets_map.get(key)
    if not target:
        return
    s = _sock(bsdf, target)
    if s:
        try:
            s.default_value = value
        except Exception:
            pass

def _build_proc_mask(nt, properties, label_prefix, x, y):
    """
    Build a procedural mask node network from properties (PBR_MapLayer or PBR_Overlay).
    Returns final Color output socket.
    properties must have: mask_type, mask_proc_scale, mask_proc_detail, mask_proc_roughness,
                     mask_proc_distortion, mask_tiling_x/y/lock, mask_offset_x/y, mask_rotation
    """
    mtype = getattr(properties, 'mask_type', 'NOISE')
    scale = getattr(properties, 'mask_proc_scale', 5.0)
    detail = getattr(properties, 'mask_proc_detail', 2.0)
    rough = getattr(properties, 'mask_proc_roughness', 0.5)
    dist = getattr(properties, 'mask_proc_distortion', 0.0)
    tx = getattr(properties, 'mask_tiling_x', 1.0)
    ty = getattr(properties, 'mask_tiling_y', 1.0)
    lock = getattr(properties, 'mask_tiling_lock', True)
    ox = getattr(properties, 'mask_offset_x', 0.0)
    oy = getattr(properties, 'mask_offset_y', 0.0)
    rot = getattr(properties, 'mask_rotation', 0.0)
    uv = _ensure(nt, 'ShaderNodeTexCoord', f'{label_prefix}_UV', x - 440, y)
    mapp = _ensure(nt, 'ShaderNodeMapping', f'{label_prefix}_MAPP', x - 220, y)
    _link(nt, uv.outputs['UV'], mapp.inputs['Vector'])
    mapp.inputs['Scale'].default_value = (tx, ty if not lock else tx, 1.0)
    mapp.inputs['Location'].default_value = (ox, oy, 0.0)
    mapp.inputs['Rotation'].default_value = (0.0, 0.0, rot)
    if mtype == 'NOISE':
        nd = _ensure(nt, 'ShaderNodeTexNoise', f'{label_prefix}_PROC', x, y)
        nd.inputs['Scale'].default_value = scale
        nd.inputs['Detail'].default_value = detail
        nd.inputs['Roughness'].default_value = rough
        nd.inputs['Distortion'].default_value = dist
        _link(nt, mapp.outputs['Vector'], nd.inputs['Vector'])
        return nd.outputs['Fac']
    elif mtype == 'WAVE':
        nd = _ensure(nt, 'ShaderNodeTexWave', f'{label_prefix}_PROC', x, y)
        nd.wave_type = getattr(properties, 'mask_wave_type', 'BANDS')
        nd.bands_direction = 'X'
        nd.wave_profile = getattr(properties, 'mask_wave_profile', 'SIN')
        nd.inputs['Scale'].default_value = scale
        nd.inputs['Distortion'].default_value = dist
        nd.inputs['Detail'].default_value = detail
        nd.inputs['Detail Roughness'].default_value = rough
        _link(nt, mapp.outputs['Vector'], nd.inputs['Vector'])
        return nd.outputs['Color']
    elif mtype == 'GRADIENT':
        nd = _ensure(nt, 'ShaderNodeTexGradient', f'{label_prefix}_PROC', x, y)
        nd.gradient_type = getattr(properties, 'mask_gradient_type', 'LINEAR')
        _link(nt, mapp.outputs['Vector'], nd.inputs['Vector'])
        return nd.outputs['Fac']
    elif mtype == 'VORONOI':
        nd = _ensure(nt, 'ShaderNodeTexVoronoi', f'{label_prefix}_PROC', x, y)
        nd.feature = getattr(properties, 'mask_voronoi_feature', 'F1')
        nd.distance = getattr(properties, 'mask_voronoi_distance', 'EUCLIDEAN')
        nd.inputs['Scale'].default_value = scale
        nd.inputs['Randomness'].default_value = getattr(properties, 'mask_voronoi_random', 1.0)
        _link(nt, mapp.outputs['Vector'], nd.inputs['Vector'])
        try:
            return nd.outputs['Distance']
        except:
            return nd.outputs['Color']
    return None

def _build_mask(nt, mask_path, mask_invert, mask_min, mask_max, tx, ty, lock, ox, oy, rot, uv_node, label_prefix, x, y, mask_type='IMAGE', proc_properties=None, udim=False):
    """
    Build mask sub-network. Returns final Factor socket or None.
    mask_type: 'IMAGE' | 'NOISE' | 'WAVE' | 'GRADIENT' | 'VORONOI'
    proc_properties: object with procedural mask properties (used when mask_type != IMAGE)
    """
    if mask_type != 'IMAGE' and proc_properties is not None:
        out = _build_proc_mask(nt, proc_properties, label_prefix, x, y)
        if out is None:
            _purge(nt, f'{label_prefix}_')
            return None
        if mask_invert:
            inv = _ensure(nt, 'ShaderNodeInvert', f'{label_prefix}_INV', x + 220, y)
            _link(nt, out, inv.inputs['Color'])
            out = inv.outputs['Color']
        else:
            n = _by_lbl(nt, f'{label_prefix}_INV')
            if n:
                nt.nodes.remove(n)
        out = _maprange(nt, f'{label_prefix}_RANGE', out, mask_min, mask_max, x + 440, y)
        n = _by_lbl(nt, f'{label_prefix}_TEX')
        if n:
            nt.nodes.remove(n)
        return out
    abs_mp = bpy.path.abspath(mask_path.strip()) if mask_path.strip() else ''
    if not abs_mp or not os.path.isfile(abs_mp):
        _purge(nt, f'{label_prefix}_')
        return None
    n = _by_lbl(nt, f'{label_prefix}_PROC')
    if n:
        nt.nodes.remove(n)
    mapp = _ensure(nt, 'ShaderNodeMapping', f'{label_prefix}_MAPP', x - 220, y)
    _link(nt, uv_node.outputs['UV'], mapp.inputs['Vector'])
    ty_ = ty if not lock else tx
    mapp.inputs['Scale'].default_value = (tx, ty_, 1.0)
    mapp.inputs['Location'].default_value = (ox, oy, 0.0)
    mapp.inputs['Rotation'].default_value = (0.0, 0.0, rot)
    tex = _ensure(nt, 'ShaderNodeTexImage', f'{label_prefix}_TEX', x, y)
    img = _load_img(abs_mp, 'Non-Color', udim=udim)
    if img:
        tex.image = img
    if udim:
        _link(nt, uv_node.outputs['UV'], tex.inputs['Vector'])
        n = _by_lbl(nt, f'{label_prefix}_MAPP')
        if n:
            nt.nodes.remove(n)
    else:
        _link(nt, mapp.outputs['Vector'], tex.inputs['Vector'])
    out = tex.outputs['Color']
    if mask_invert:
        inv = _ensure(nt, 'ShaderNodeInvert', f'{label_prefix}_INV', x + 220, y)
        _link(nt, out, inv.inputs['Color'])
        out = inv.outputs['Color']
    else:
        n = _by_lbl(nt, f'{label_prefix}_INV')
        if n:
            nt.nodes.remove(n)
    out = _maprange(nt, f'{label_prefix}_RANGE', out, mask_min, mask_max, x + 440, y)
    return out

def _build_channel(nt, layer, li, key, mapp_node, uv_node, x, y, cc_layer=None):
    """
    Build full composite for one map channel including overlay stack.
    Returns final Color/Value output socket, or None if nothing assigned.
    """
    label, icon, cs, vtype = MAP_INFO[key]
    px = _ppath(layer, key)
    use = _use(layer, key)
    if not use:
        _purge(nt, f'{_nl(li, key.upper())}_')
        return None
    extras = getattr(layer, f'extra_{key}', [])
    valid_extras = [e for e in extras if e.path.strip() and os.path.isfile(bpy.path.abspath(e.path.strip()))]
    has_primary = px and os.path.isfile(px)
    if not has_primary and (not valid_extras):
        _purge(nt, f'{_nl(li, key.upper())}_')
        return None
    TAG = _nl(li, key.upper())
    cur_y = y
    if has_primary:
        pn = _ensure(nt, 'ShaderNodeTexImage', f'{TAG}_IMG0', x, cur_y)
        is_udim = getattr(layer, f'udim_{key}', False)
        img = _load_img(px, cs, udim=is_udim)
        if img:
            pn.image = img
        if key == 'base_color' and getattr(layer, 'bc_use_own_mapping', False):
            bc_uv = _ensure(nt, 'ShaderNodeTexCoord', f'{TAG}_BCUV', x - 440, cur_y)
            bc_mapp = _ensure(nt, 'ShaderNodeMapping', f'{TAG}_BCMAPP', x - 220, cur_y)
            _link(nt, bc_uv.outputs['UV'], bc_mapp.inputs['Vector'])
            bc_ty = layer.bc_tiling_y if not layer.bc_tiling_lock else layer.bc_tiling_x
            bc_mapp.inputs['Scale'].default_value = (layer.bc_tiling_x, bc_ty, 1.0)
            bc_mapp.inputs['Location'].default_value = (layer.bc_offset_x, layer.bc_offset_y, 0.0)
            bc_mapp.inputs['Rotation'].default_value = (0.0, 0.0, layer.bc_rotation)
            vec_src = bc_mapp.outputs['Vector']
        elif getattr(layer, f'ch_own_mapping_{key}', False):
            ch_uv = _ensure(nt, 'ShaderNodeTexCoord', f'{TAG}_CHUV', x - 440, cur_y)
            ch_mapp = _ensure(nt, 'ShaderNodeMapping', f'{TAG}_CHMAPP', x - 220, cur_y)
            _link(nt, ch_uv.outputs['UV'], ch_mapp.inputs['Vector'])
            ch_ty = getattr(layer, f'ch_tiling_y_{key}', 1.0) if not getattr(layer, f'ch_tiling_lock_{key}', True) else getattr(layer, f'ch_tiling_x_{key}', 1.0)
            ch_mapp.inputs['Scale'].default_value = (getattr(layer, f'ch_tiling_x_{key}', 1.0), ch_ty, 1.0)
            ch_mapp.inputs['Location'].default_value = (getattr(layer, f'ch_offset_x_{key}', 0.0), getattr(layer, f'ch_offset_y_{key}', 0.0), 0.0)
            ch_mapp.inputs['Rotation'].default_value = (0.0, 0.0, getattr(layer, f'ch_rotation_{key}', 0.0))
            vec_src = ch_mapp.outputs['Vector']
        else:
            for lbl in (f'{TAG}_BCUV', f'{TAG}_BCMAPP', f'{TAG}_CHUV', f'{TAG}_CHMAPP'):
                n = _by_lbl(nt, lbl)
                if n:
                    nt.nodes.remove(n)
            vec_src = uv_node.outputs['UV'] if is_udim else mapp_node.outputs['Vector']
        _link(nt, vec_src, pn.inputs['Vector'])
        out = pn.outputs['Color']
        str_val = getattr(layer, f'str_{key}', 1.0)
        if str_val != 1.0:
            vtype = MAP_INFO[key][3]
            if vtype == 'COLOR':
                sm = _ensure(nt, 'ShaderNodeMixRGB', f'{TAG}_STR', x + 220, cur_y)
                sm.blend_type = 'MULTIPLY'
                sm.inputs['Fac'].default_value = 1.0
                sm.inputs['Color1'].default_value = (str_val, str_val, str_val, 1.0)
                _link(nt, out, sm.inputs['Color2'])
                out = sm.outputs['Color']
            else:
                sm = _ensure(nt, 'ShaderNodeMath', f'{TAG}_STR', x + 220, cur_y)
                sm.operation = 'MULTIPLY'
                sm.inputs[1].default_value = str_val
                _link(nt, out, sm.inputs[0])
                out = sm.outputs['Value']
        else:
            n = _by_lbl(nt, f'{TAG}_STR')
            if n:
                nt.nodes.remove(n)
        if key in GRAYSCALE_KEYS:
            mn = getattr(layer, f'min_{key}', 0.0)
            mx = getattr(layer, f'max_{key}', 1.0)
            out = _maprange(nt, f'{TAG}_RANGE0', out, mn, mx, x + 240, cur_y)
        if cc_layer is not None:
            cc_x = x + 500
            hs = _ensure(nt, 'ShaderNodeHueSaturation', f'{TAG}_HUESAT', cc_x, cur_y)
            hs.inputs['Hue'].default_value = cc_layer.hue
            hs.inputs['Saturation'].default_value = cc_layer.saturation
            hs.inputs['Value'].default_value = cc_layer.value
            _link(nt, out, hs.inputs['Color'])
            out = hs.outputs['Color']
            bc_n = _ensure(nt, 'ShaderNodeBrightContrast', f'{TAG}_BRTCON', cc_x + 220, cur_y)
            bc_n.inputs['Bright'].default_value = 0.0
            bc_n.inputs['Contrast'].default_value = cc_layer.contrast
            _link(nt, out, bc_n.inputs['Color'])
            out = bc_n.outputs['Color']
            gm_n = _ensure(nt, 'ShaderNodeGamma', f'{TAG}_GAMMA', cc_x + 440, cur_y)
            gm_n.inputs['Gamma'].default_value = cc_layer.gamma
            _link(nt, out, gm_n.inputs['Color'])
            out = gm_n.outputs['Color']
        cur_y -= 350
    else:
        first = valid_extras.pop(0)
        pn = _ensure(nt, 'ShaderNodeTexImage', f'{TAG}_IMG0', x, cur_y)
        img = _load_img(bpy.path.abspath(first.path.strip()), cs)
        if img:
            pn.image = img
        _link(nt, mapp_node.outputs['Vector'], pn.inputs['Vector'])
        out = pn.outputs['Color']
        if key in GRAYSCALE_KEYS:
            out = _maprange(nt, f'{TAG}_RANGE0', out, first.img_min, first.img_max, x + 240, cur_y)
        cur_y -= 350
    for oi, extra in enumerate(valid_extras):
        if not extra.enabled:
            continue
        EP = f'{TAG}_OV{oi}'
        ex_tex = _ensure(nt, 'ShaderNodeTexImage', f'{EP}_TEX', x, cur_y)
        ov_udim = getattr(extra, 'udim', False)
        img = _load_img(bpy.path.abspath(extra.path.strip()), cs, udim=ov_udim)
        if img:
            ex_tex.image = img
        if getattr(extra, 'img_use_own_mapping', False):
            ov_uv = _ensure(nt, 'ShaderNodeTexCoord', f'{EP}_OVUV', x - 440, cur_y)
            ov_mapp = _ensure(nt, 'ShaderNodeMapping', f'{EP}_OVMAPP', x - 220, cur_y)
            _link(nt, ov_uv.outputs['UV'], ov_mapp.inputs['Vector'])
            ov_ty = extra.img_tiling_y if not extra.img_tiling_lock else extra.img_tiling_x
            ov_mapp.inputs['Scale'].default_value = (extra.img_tiling_x, ov_ty, 1.0)
            ov_mapp.inputs['Location'].default_value = (extra.img_offset_x, extra.img_offset_y, 0.0)
            ov_mapp.inputs['Rotation'].default_value = (0.0, 0.0, extra.img_rotation)
            ov_vec = ov_mapp.outputs['Vector']
        else:
            for lbl in (f'{EP}_OVUV', f'{EP}_OVMAPP'):
                n = _by_lbl(nt, lbl)
                if n:
                    nt.nodes.remove(n)
            ov_vec = uv_node.outputs['UV'] if ov_udim else mapp_node.outputs['Vector']
        _link(nt, ov_vec, ex_tex.inputs['Vector'])
        ex_out = ex_tex.outputs['Color']
        if key in GRAYSCALE_KEYS:
            ex_out = _maprange(nt, f'{EP}_IMGRANGE', ex_out, extra.img_min, extra.img_max, x + 240, cur_y)
        ov_hs = _ensure(nt, 'ShaderNodeHueSaturation', f'{EP}_HUESAT', x + 500, cur_y)
        ov_hs.inputs['Hue'].default_value = extra.hue
        ov_hs.inputs['Saturation'].default_value = extra.saturation
        ov_hs.inputs['Value'].default_value = extra.value
        _link(nt, ex_out, ov_hs.inputs['Color'])
        ex_out = ov_hs.outputs['Color']
        ov_bc = _ensure(nt, 'ShaderNodeBrightContrast', f'{EP}_BRTCON', x + 720, cur_y)
        ov_bc.inputs['Bright'].default_value = 0.0
        ov_bc.inputs['Contrast'].default_value = extra.contrast
        _link(nt, ex_out, ov_bc.inputs['Color'])
        ex_out = ov_bc.outputs['Color']
        ov_gm = _ensure(nt, 'ShaderNodeGamma', f'{EP}_GAMMA', x + 940, cur_y)
        ov_gm.inputs['Gamma'].default_value = extra.gamma
        _link(nt, ex_out, ov_gm.inputs['Color'])
        ex_out = ov_gm.outputs['Color']
        mix = _ensure(nt, 'ShaderNodeMixRGB', f'{EP}_MIX', x + 1200, cur_y + 175)
        mix.blend_type = extra.blend_mode
        _link(nt, out, mix.inputs['Color1'])
        _link(nt, ex_out, mix.inputs['Color2'])
        fac = _build_mask(nt, extra.mask_path, extra.mask_invert, extra.mask_min, extra.mask_max, extra.mask_tiling_x, extra.mask_tiling_y, extra.mask_tiling_lock, extra.mask_offset_x, extra.mask_offset_y, extra.mask_rotation, uv_node, f'{EP}_MASK', x - 500, cur_y - 200, mask_type=getattr(extra, 'mask_type', 'IMAGE'), proc_properties=extra, udim=getattr(extra, 'mask_udim', False))
        if fac:
            str_n = _ensure(nt, 'ShaderNodeMath', f'{EP}_STR', x - 200, cur_y - 200)
            str_n.operation = 'MULTIPLY'
            str_n.inputs[1].default_value = extra.strength
            _link(nt, fac, str_n.inputs[0])
            _link(nt, str_n.outputs['Value'], mix.inputs['Fac'])
        else:
            mix.inputs['Fac'].default_value = extra.strength
        out = mix.outputs['Color']
        cur_y -= 350
    return out

def _build_layer(nt, layer, li, y_base):
    X_UV = -1800
    X_MAP = -1580
    X_TEX = -1200
    X_MID = 200
    X_AO = 560
    X_BSD = 800
    STEP = 380
    stype = layer.shader_type
    v_keys = SHADER_MAPS.get(stype, MAP_KEYS)
    sockets = BSDF_SOCKETS.get(stype, {})
    uv = _ensure(nt, 'ShaderNodeTexCoord', _nl(li, 'UV'), X_UV, y_base)
    mapp = _ensure(nt, 'ShaderNodeMapping', _nl(li, 'MAPP'), X_MAP, y_base)
    _link(nt, uv.outputs['UV'], mapp.inputs['Vector'])
    ty = layer.tiling_y if not layer.tiling_lock else layer.tiling_x
    mapp.inputs['Scale'].default_value = (layer.tiling_x, ty, 1.0)
    mapp.inputs['Location'].default_value = (layer.offset_x, layer.offset_y, 0.0)
    mapp.inputs['Rotation'].default_value = (0.0, 0.0, layer.rotation)
    bsdf = _by_lbl(nt, _nl(li, 'BSDF'))
    if bsdf is None:
        if li == 0:
            bsdf = next((n for n in nt.nodes if n.type == SHADER_BSDF_TYPE.get(stype, '') and (not n.label)), None)
        if bsdf is None:
            bsdf = nt.nodes.new(SHADER_NODE_TYPE[stype])
        bsdf.label = _nl(li, 'BSDF')
    elif bsdf.type != SHADER_BSDF_TYPE.get(stype, ''):
        loc = bsdf.location.copy()
        nt.nodes.remove(bsdf)
        bsdf = nt.nodes.new(SHADER_NODE_TYPE[stype])
        bsdf.label = _nl(li, 'BSDF')
        bsdf.location = loc
    bsdf.location = (X_BSD, y_base)
    y_cur = [y_base - STEP]

    def ny():
        v = y_cur[0]
        y_cur[0] -= STEP
        return v

    def ch(key, cc=False):
        return _build_channel(nt, layer, li, key, mapp, uv, X_TEX, ny(), cc_layer=layer if cc else None)
    if 'base_color' in v_keys and 'base_color' in sockets:
        sock = ch('base_color', cc=True)
        if sock:
            final_bc = sock
            if stype == 'PRINCIPLED':
                ao_sock = ch('ao') if 'ao' in v_keys else None
                if ao_sock:
                    ao_mix = _ensure(nt, 'ShaderNodeMixRGB', _nl(li, 'AO_MIX'), X_AO, y_base)
                    ao_mix.blend_type = 'MULTIPLY'
                    ao_mix.inputs['Fac'].default_value = layer.ao_strength
                    _link(nt, final_bc, ao_mix.inputs['Color1'])
                    _link(nt, ao_sock, ao_mix.inputs['Color2'])
                    final_bc = ao_mix.outputs['Color']
                else:
                    n = _by_lbl(nt, _nl(li, 'AO_MIX'))
                    if n:
                        nt.nodes.remove(n)
            _connect(nt, bsdf, 'base_color', sockets, final_bc)
        else:
            n = _by_lbl(nt, _nl(li, 'HUESAT'))
            if n:
                nt.nodes.remove(n)
            s = _sock(bsdf, sockets.get('base_color', ''))
            if s:
                try:
                    s.default_value = (*layer.val_base_color[:3], 1.0)
                except Exception:
                    pass
    if 'roughness' in v_keys and 'roughness' in sockets:
        r_sock = ch('roughness')
        if r_sock:
            if layer.roughness_bias != 0.0:
                rb = _ensure(nt, 'ShaderNodeMath', _nl(li, 'ROUGH_BIAS'), X_MID, y_cur[0] + STEP)
                rb.operation = 'ADD'
                rb.inputs[1].default_value = layer.roughness_bias
                _link(nt, r_sock, rb.inputs[0])
                _connect(nt, bsdf, 'roughness', sockets, rb.outputs['Value'])
            else:
                _connect(nt, bsdf, 'roughness', sockets, r_sock)
        elif 'glossiness' in v_keys:
            g_sock = ch('glossiness')
            if g_sock:
                inv = _ensure(nt, 'ShaderNodeInvert', _nl(li, 'GLOSS_INV'), X_MID, y_cur[0] + STEP)
                _link(nt, g_sock, inv.inputs['Color'])
                _connect(nt, bsdf, 'roughness', sockets, inv.outputs['Color'])
            else:
                _set_val(bsdf, 'roughness', sockets, 1.0 - layer.val_glossiness)
        else:
            _set_val(bsdf, 'roughness', sockets, layer.val_roughness)
    simple_keys = [k for k in v_keys if k not in ('base_color', 'roughness', 'glossiness', 'ao', 'normal', 'bump', 'coat_normal', 'emission', 'displacement')]
    for key in simple_keys:
        if key not in sockets:
            continue
        sock = ch(key)
        if sock:
            _connect(nt, bsdf, key, sockets, sock)
        else:
            vtype = MAP_INFO[key][3]
            if vtype == 'COLOR':
                val = getattr(layer, f'val_{key}', None)
                if val is not None:
                    s = _sock(bsdf, sockets[key])
                    if s:
                        try:
                            v = list(val)
                            if len(s.default_value) == 3:
                                s.default_value = (v[0], v[1], v[2])
                            else:
                                s.default_value = (v[0], v[1], v[2], 1.0)
                        except Exception:
                            pass
            elif vtype == 'FLOAT':
                _set_val(bsdf, key, sockets, getattr(layer, f'val_{key}', 0.0))
    nor_target = sockets.get('normal') or sockets.get('bump')
    if nor_target:
        if 'normal' in v_keys:
            n_sock = ch('normal')
            if n_sock:
                nm = _ensure(nt, 'ShaderNodeNormalMap', _nl(li, 'NMAP'), X_MID, y_cur[0] + STEP)
                nm.inputs['Strength'].default_value = layer.normal_strength
                _link(nt, n_sock, nm.inputs['Color'])
                _connect(nt, bsdf, 'normal', sockets, nm.outputs['Normal'])
                _purge(nt, _nl(li, 'BUMP_'))
            elif 'bump' in v_keys:
                b_sock = ch('bump')
                if b_sock:
                    bm = _ensure(nt, 'ShaderNodeBump', _nl(li, 'BUMP_N'), X_MID, y_cur[0] + STEP)
                    bm.inputs['Strength'].default_value = layer.bump_strength
                    _link(nt, b_sock, bm.inputs['Height'])
                    _connect(nt, bsdf, 'bump', sockets, bm.outputs['Normal'])
                    _purge(nt, _nl(li, 'NMAP'))
    if 'coat_normal' in v_keys and 'coat_normal' in sockets:
        cn_sock = ch('coat_normal')
        if cn_sock:
            cnm = _ensure(nt, 'ShaderNodeNormalMap', _nl(li, 'COAT_NMAP'), X_MID, y_cur[0] + STEP)
            cnm.inputs['Strength'].default_value = layer.normal_strength
            _link(nt, cn_sock, cnm.inputs['Color'])
            _connect(nt, bsdf, 'coat_normal', sockets, cnm.outputs['Normal'])
    if 'emission' in v_keys and 'emission' in sockets:
        e_sock = ch('emission')
        if e_sock:
            _connect(nt, bsdf, 'emission', sockets, e_sock)
        else:
            s = _sock(bsdf, sockets['emission'])
            if s:
                try:
                    s.default_value = (*layer.val_emission[:3], 1.0)
                except Exception:
                    pass
        try:
            bsdf.inputs['Emission Strength'].default_value = layer.emission_strength
        except Exception:
            pass
    if stype == 'EMISSION':
        try:
            bsdf.inputs['Strength'].default_value = layer.emission_strength
        except Exception:
            pass
    if stype == 'SSS':
        try:
            bsdf.inputs['Scale'].default_value = layer.sss_scale
        except Exception:
            pass
    if stype == 'PRINCIPLED':
        try:
            bsdf.distribution = layer.specular_distribution
        except Exception:
            pass
        try:
            bsdf.subsurface_method = layer.sss_method
        except Exception:
            pass
    return bsdf

def _arrange_nodes(nt):
    """Frame the node editor only when a real UI context is available.

    Blender 5.1 can crash in background/headless execution when node selection
    and node-editor view operators are forced after constructing a large shader
    tree.  The arrangement step is only a viewport convenience, so it is skipped
    unless an interactive node-editor window, area, space, and WINDOW region are
    all present.
    """
    if not nt:
        return
    try:
        if bool(getattr(bpy.app, 'background', False)):
            return
        screen = getattr(bpy.context, 'screen', None)
        window = getattr(bpy.context, 'window', None)
        if screen is None or window is None:
            return
        for area in getattr(screen, 'areas', []):
            if getattr(area, 'type', '') != 'NODE_EDITOR':
                continue
            region = next((r for r in getattr(area, 'regions', []) if getattr(r, 'type', '') == 'WINDOW'), None)
            if region is None:
                continue
            for space in getattr(area, 'spaces', []):
                if getattr(space, 'type', '') != 'NODE_EDITOR' or getattr(space, 'tree_type', '') != 'ShaderNodeTree':
                    continue
                try:
                    with bpy.context.temp_override(window=window, screen=screen, area=area, region=region, space_data=space):
                        bpy.ops.node.view_all()
                except Exception:
                    pass
    except Exception:
        pass

def build_network(mat):
    if not mat:
        return
    properties = mat.pbr_properties
    if not properties.layers:
        return
    mat.use_nodes = True
    nt = mat.node_tree
    active = [l for l in properties.layers if l.enabled]
    if not active:
        return
    out = _by_lbl(nt, 'PBR_OUTPUT')
    if out is None:
        out = next((n for n in nt.nodes if n.type == 'OUTPUT_MATERIAL'), None)
        if out:
            out.label = 'PBR_OUTPUT'
        else:
            out = nt.nodes.new('ShaderNodeOutputMaterial')
            out.label = 'PBR_OUTPUT'
    out.location = (1400, 300)
    Y_STEP = 3200
    bsdfs = []
    for idx, layer in enumerate(active):
        bsdf = _build_layer(nt, layer, idx, -(idx * Y_STEP))
        bsdfs.append((idx, layer, bsdf))
    base = active[0]
    base_mapp = _by_lbl(nt, _nl(0, 'MAPP'))
    base_uv = _by_lbl(nt, _nl(0, 'UV'))
    if base_mapp and base_uv and (_has_img(base, 'displacement') or _has_extras(base, 'displacement')):
        d_sock = _build_channel(nt, base, 0, 'displacement', base_mapp, base_uv, -880, -2400)
        if d_sock:
            dn = _ensure(nt, 'ShaderNodeDisplacement', 'PBR_DISP', 800, -300)
            dn.inputs['Scale'].default_value = base.disp_scale
            dn.inputs['Midlevel'].default_value = base.disp_midlevel
            _link(nt, d_sock, dn.inputs['Height'])
            _link(nt, dn.outputs['Displacement'], out.inputs['Displacement'])
            try:
                mat.cycles.displacement_method = 'BOTH'
            except AttributeError:
                pass
    else:
        n = _by_lbl(nt, 'PBR_DISP')
        if n:
            nt.nodes.remove(n)
    has_opacity = any((_has_img(l, 'opacity') or _has_extras(l, 'opacity') for l in active))
    mat.blend_method = 'CLIP' if has_opacity else 'OPAQUE'
    if hasattr(mat, 'shadow_method'):
        mat.shadow_method = 'CLIP' if has_opacity else 'OPAQUE'
    _purge(nt, 'LMIX_')
    if len(bsdfs) == 1:
        _link(nt, _bsdf_out(bsdfs[0][2], active[0].shader_type), out.inputs['Surface'])
        return
    prev = _bsdf_out(bsdfs[0][2], active[0].shader_type)
    for si in range(1, len(bsdfs)):
        li, layer, bsdf = bsdfs[si]
        y_base = -(li * Y_STEP)
        mix = _ensure(nt, 'ShaderNodeMixShader', f'LMIX_{si}', 900, 300 - (si - 1) * 200)
        _link(nt, prev, mix.inputs[1])
        _link(nt, _bsdf_out(bsdf, layer.shader_type), mix.inputs[2])
        uv_node = _by_lbl(nt, _nl(li, 'UV'))
        fac = _build_mask(nt, layer.mask_path, layer.mask_invert, layer.mask_min, layer.mask_max, layer.mask_tiling_x, layer.mask_tiling_y, layer.mask_tiling_lock, layer.mask_offset_x, layer.mask_offset_y, layer.mask_rotation, uv_node, f'LMASK_{li}', -1500, y_base - 300, mask_type=layer.mask_type, proc_properties=layer, udim=getattr(layer, 'mask_udim', False)) if uv_node else None
        if fac:
            str_n = _ensure(nt, 'ShaderNodeMath', f'LMASK_{li}_STR', -1200, y_base - 300)
            str_n.operation = 'MULTIPLY'
            str_n.inputs[1].default_value = layer.mask_strength
            _link(nt, fac, str_n.inputs[0])
            _link(nt, str_n.outputs['Value'], mix.inputs['Fac'])
        else:
            mix.inputs['Fac'].default_value = layer.mask_strength
        prev = mix.outputs['Shader']
    _link(nt, prev, out.inputs['Surface'])

class PBR_OT_CreateMaterial(Operator):
    bl_idname = 'pbr_ld.create_material'
    bl_label = _lt('Create Material', 'マテリアル作成')
    bl_description = _lt('Create a new named material')
    bl_options = {'UNDO'}
    mat_name: StringProperty(name=_lt('Name'), default='PBR_Material')
    sss_target_slot_token: EnumProperty(**slot_selection.MATERIAL_TARGET_SLOT_PROPERTY_KWARGS)

    def invoke(self, context, event):
        slot_selection.init_operator_material_target_slot(self, context)
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, 'mat_name', text=_lt('Name'))
        obj = getattr(context, 'active_object', None)
        try:
            slot_count = len(getattr(obj, 'material_slots', ()) or ())
        except Exception:
            slot_count = 0
        if slot_count > 1 and str(core.assign_mode(context) or 'ACTIVE_SLOT') == 'ACTIVE_SLOT':
            slot_selection.draw_operator_material_target_slot(self.layout, self, context)

    def execute(self, context):
        slot_selection.apply_operator_material_target_slot(self, context)
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, _lt('Select a mesh first.'))
            return {'CANCELLED'}
        mat = bpy.data.materials.new(name=self.mat_name)
        mat.use_nodes = True
        if core.material_generation_should_assign_selected(context):
            assigned_ok = core.assign_material_to_selected(context, mat) > 0
        else:
            assigned_ok = core.set_material_on_object(obj, mat, core.assign_mode(context), context=context)
        if not assigned_ok:
            try:
                bpy.data.materials.remove(mat)
            except Exception:
                pass
            self.report({'WARNING'}, _lt('The selected object cannot receive materials.', '選択オブジェクトへマテリアルを割り当てられません。'))
            return {'CANCELLED'}
        mat.pbr_properties.layers.add().name = _lt('Base Layer')
        save_pbr_material_settings(mat)
        self.report({'INFO'}, _lt(f"JP: '{mat.name}' を作成しました。\nEN: Created '{mat.name}'."))
        return {'FINISHED'}

class PBR_OT_AddLayer(Operator):
    bl_idname = 'pbr_ld.add_layer'
    bl_label = _lt('Add Layer', 'レイヤー追加')
    bl_description = _lt('Add a new shader layer')
    bl_options = {'UNDO'}
    shader_type: EnumProperty(name=_lt('Shader'), items=SHADER_ITEMS, default='PRINCIPLED')
    layer_name: StringProperty(name=_lt('Name'), default='')

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        col = self.layout.column(align=True)
        col.prop(self, 'shader_type')
        col.prop(self, 'layer_name')

    def execute(self, context):
        mat = _active_mat(context)
        if not mat:
            return {'CANCELLED'}
        layer = mat.pbr_properties.layers.add()
        layer.shader_type = self.shader_type
        layer.name = self.layer_name.strip() or _lt(f"JP: レイヤー {len(mat.pbr_properties.layers)}\nEN: Layer {len(mat.pbr_properties.layers)}")
        mat.pbr_properties.active_layer_index = len(mat.pbr_properties.layers) - 1
        if mat.pbr_properties.is_built:
            build_network(mat)
        save_pbr_material_settings(mat)
        return {'FINISHED'}

class PBR_OT_RemoveLayer(Operator):
    bl_idname = 'pbr_ld.remove_layer'
    bl_label = _lt('Remove Layer', 'レイヤー削除')
    bl_options = {'UNDO'}
    layer_index: IntProperty()

    def execute(self, context):
        mat = _active_mat(context)
        if not mat:
            return {'CANCELLED'}
        properties = mat.pbr_properties
        if len(properties.layers) <= 1:
            self.report({'WARNING'}, _lt('Cannot remove last layer.'))
            return {'CANCELLED'}
        if mat.use_nodes:
            _purge(mat.node_tree, f'L{self.layer_index}_')
        properties.layers.remove(self.layer_index)
        properties.active_layer_index = max(0, min(properties.active_layer_index, len(properties.layers) - 1))
        if properties.is_built:
            build_network(mat)
        save_pbr_material_settings(mat)
        return {'FINISHED'}

class PBR_OT_MoveLayer(Operator):
    bl_idname = 'pbr_ld.move_layer'
    bl_label = _lt('Move Layer', 'レイヤー移動')
    bl_options = {'UNDO'}
    layer_index: IntProperty()
    direction: EnumProperty(items=_localized_enum_items([('UP', 'Up', ''), ('DOWN', 'Down', '')]))

    def execute(self, context):
        mat = _active_mat(context)
        if not mat:
            return {'CANCELLED'}
        properties = mat.pbr_properties
        i = self.layer_index
        if self.direction == 'UP' and i > 0:
            properties.layers.move(i, i - 1)
            properties.active_layer_index = i - 1
        elif self.direction == 'DOWN' and i < len(properties.layers) - 1:
            properties.layers.move(i, i + 1)
            properties.active_layer_index = i + 1
        else:
            return {'FINISHED'}
        if properties.is_built and mat.use_nodes:
            nt = mat.node_tree
            for n in [x for x in nt.nodes if x.label and x.label[:1] == 'L' and ('_' in x.label) and x.label.split('_')[0][1:].isdigit()]:
                nt.nodes.remove(n)
            _purge(nt, 'LMIX_')
            _purge(nt, 'LMASK_')
            _purge(nt, 'PBR_DISP')
            build_network(mat)
        save_pbr_material_settings(mat)
        return {'FINISHED'}

class PBR_OT_ScanLayerFolder(Operator):
    bl_idname = 'pbr_ld.scan_layer_folder'
    bl_label = _lt('Scan Layer Folder', 'レイヤーフォルダをスキャン')
    bl_options = set()
    layer_index: IntProperty()

    def execute(self, context):
        mat = _active_mat(context)
        if not mat:
            return {'CANCELLED'}
        layer = mat.pbr_properties.layers[self.layer_index]
        d = bpy.path.abspath(layer.scan_dir_path.strip())
        if not os.path.isdir(d):
            self.report({'WARNING'}, _lt('Set a valid folder.'))
            return {'CANCELLED'}
        found = scan_dir(d)
        for k, fp in found.items():
            setattr(layer, f'path_{k}', fp)
        self.report({'INFO'}, _lt(f'JP: {len(found)} 個のマップを検出しました。Build を押してください。\nEN: Found {len(found)} maps — click Build.'))
        return {'FINISHED'}

class PBR_OT_ClearLayer(Operator):
    bl_idname = 'pbr_ld.clear_layer'
    bl_label = _lt('Clear Layer', 'レイヤーをクリア')
    bl_options = {'UNDO'}
    layer_index: IntProperty()

    def execute(self, context):
        mat = _active_mat(context)
        if not mat:
            return {'CANCELLED'}
        layer = mat.pbr_properties.layers[self.layer_index]
        for k in MAP_KEYS:
            setattr(layer, f'path_{k}', '')
        layer.mask_path = ''
        if mat.pbr_properties.is_built:
            _purge(mat.node_tree, f'L{self.layer_index}_')
            build_network(mat)
        return {'FINISHED'}

class PBR_OT_AddOverlay(Operator):
    bl_idname = 'pbr_ld.add_overlay'
    bl_label = _lt('Add Overlay', 'オーバーレイ追加')
    bl_description = _lt('Add an image overlay with blend mask for this channel')
    bl_options = {'UNDO'}
    layer_index: IntProperty()
    map_key: StringProperty()

    def execute(self, context):
        mat = _active_mat(context)
        if not mat or not 0 <= self.layer_index < len(mat.pbr_properties.layers) or self.map_key not in MAP_KEYS:
            return {'CANCELLED'}
        layer = mat.pbr_properties.layers[self.layer_index]
        getattr(layer, f'extra_{self.map_key}').add()
        save_pbr_material_settings(mat)
        return {'FINISHED'}

class PBR_OT_RemoveOverlay(Operator):
    bl_idname = 'pbr_ld.remove_overlay'
    bl_label = _lt('Remove Overlay', 'オーバーレイ削除')
    bl_options = {'UNDO'}
    layer_index: IntProperty()
    map_key: StringProperty()
    overlay_index: IntProperty()

    def execute(self, context):
        mat = _active_mat(context)
        if not mat or not 0 <= self.layer_index < len(mat.pbr_properties.layers) or self.map_key not in MAP_KEYS:
            return {'CANCELLED'}
        layer = mat.pbr_properties.layers[self.layer_index]
        overlays = getattr(layer, f'extra_{self.map_key}')
        if not 0 <= self.overlay_index < len(overlays):
            return {'CANCELLED'}
        overlays.remove(self.overlay_index)
        if mat.pbr_properties.is_built:
            build_network(mat)
        save_pbr_material_settings(mat)
        return {'FINISHED'}

class PBR_OT_MoveOverlay(Operator):
    bl_idname = 'pbr_ld.move_overlay'
    bl_label = _lt('Move Overlay', 'オーバーレイ移動')
    bl_options = {'UNDO'}
    layer_index: IntProperty()
    map_key: StringProperty()
    overlay_index: IntProperty()
    direction: EnumProperty(items=_localized_enum_items([('UP', 'Up', ''), ('DOWN', 'Down', '')]))

    def execute(self, context):
        mat = _active_mat(context)
        if not mat:
            return {'CANCELLED'}
        layer = mat.pbr_properties.layers[self.layer_index]
        col = getattr(layer, f'extra_{self.map_key}', None)
        if col is None:
            return {'CANCELLED'}
        i = self.overlay_index
        if self.direction == 'UP' and i > 0:
            col.move(i, i - 1)
        elif self.direction == 'DOWN' and i < len(col) - 1:
            col.move(i, i + 1)
        if mat.pbr_properties.is_built:
            build_network(mat)
        save_pbr_material_settings(mat)
        return {'FINISHED'}

class PBR_OT_DuplicateLayer(Operator):
    bl_idname = 'pbr_ld.duplicate_layer'
    bl_label = _lt('Duplicate Layer', 'レイヤー複製')
    bl_description = _lt('Duplicate this shader layer with all its settings')
    bl_options = {'UNDO'}
    layer_index: IntProperty()

    def execute(self, context):
        mat = _active_mat(context)
        if not mat:
            return {'CANCELLED'}
        properties = mat.pbr_properties
        if self.layer_index >= len(properties.layers):
            return {'CANCELLED'}
        src_layer = properties.layers[self.layer_index]
        new_layer = properties.layers.add()
        skip = {'rna_type'}
        for prop in src_layer.bl_rna.properties:
            if prop.identifier in skip or prop.identifier.startswith('extra_'):
                continue
            try:
                setattr(new_layer, prop.identifier, getattr(src_layer, prop.identifier))
            except Exception:
                pass
        # Collection RNA values cannot be assigned with setattr. Duplicate
        # each overlay so its image, mask and blend settings stay with the
        # layer, and later edits do not alias the source collection.
        for map_key in MAP_KEYS:
            source_overlays = getattr(src_layer, f'extra_{map_key}')
            target_overlays = getattr(new_layer, f'extra_{map_key}')
            for source_overlay in source_overlays:
                target_overlay = target_overlays.add()
                for prop in source_overlay.bl_rna.properties:
                    if prop.identifier == 'rna_type' or prop.is_readonly:
                        continue
                    setattr(target_overlay, prop.identifier,
                            getattr(source_overlay, prop.identifier))
        new_layer.name = src_layer.name + ' Copy'
        target_idx = self.layer_index + 1
        properties.layers.move(len(properties.layers) - 1, target_idx)
        properties.active_layer_index = target_idx
        if properties.is_built:
            build_network(mat)
        save_pbr_material_settings(mat)
        return {'FINISHED'}

class PBR_OT_SetTiling(Operator):
    bl_idname = 'pbr_ld.set_tiling'
    bl_label = _lt('Set Tiling', 'タイリング設定')
    bl_description = _lt('Set tiling to a preset value')
    bl_options = {'UNDO'}
    layer_index: IntProperty()
    value: bpy.props.FloatProperty(default=1.0)

    def execute(self, context):
        mat = _active_mat(context)
        if not mat:
            return {'CANCELLED'}
        layer = mat.pbr_properties.layers[self.layer_index]
        layer.tiling_x = self.value
        layer.tiling_y = self.value
        if mat.pbr_properties.is_built:
            build_network(mat)
        return {'FINISHED'}

class PBR_OT_CollapseAll(Operator):
    bl_idname = 'pbr_ld.collapse_all'
    bl_label = _lt('Collapse All', 'すべて折りたたみ')
    bl_description = _lt('Collapse every layer, map group and overlay')
    bl_options = set()

    def execute(self, context):
        global _PBR_UI_STATE_BRIDGE_SYNC
        mat = _active_mat(context)
        if not mat:
            return {'CANCELLED'}
        wm = context.window_manager
        try:
            d = json.loads(getattr(wm, 'pbr_ui_state', '{}'))
            mn = mat.name
            keys_to_remove = [k for k in d if k.startswith(mn + '|')]
            for k in keys_to_remove:
                del d[k]
            wm.pbr_ui_state = json.dumps(d)
            _pbr_save_ui_state(context)
        except Exception:
            wm.pbr_ui_state = '{}'
            _pbr_save_ui_state(context)
        _PBR_UI_STATE_BRIDGE_SYNC = True
        try:
            prefix = mat.name + '|'
            for item in getattr(wm, 'pbr_ui_sections', ()):
                if str(getattr(item, 'key', '') or '').startswith(prefix):
                    item.is_open = False
        finally:
            _PBR_UI_STATE_BRIDGE_SYNC = False
        for area in context.screen.areas:
            area.tag_redraw()
        return {'FINISHED'}

class PBR_OT_BuildMaterial(Operator):
    bl_idname = 'pbr_ld.build_material'
    bl_label = _lt('Build Material', 'マテリアル構築')
    bl_description = _lt('Build the full layered shader network')
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        mat = _active_mat(context)
        return mat is not None and (not mat.pbr_properties.is_built)

    def execute(self, context):
        mat = _active_mat(context)
        if not mat:
            return {'CANCELLED'}
        build_network(mat)
        mat.pbr_properties.is_built = True
        _arrange_nodes(mat.node_tree)
        self.report({'INFO'}, _lt(f'JP: {len(mat.pbr_properties.layers)} 個のレイヤーを構築しました。\nEN: Built {len(mat.pbr_properties.layers)} layer(s).'))
        return {'FINISHED'}

class PBR_OT_RebuildMaterial(Operator):
    bl_idname = 'pbr_ld.rebuild_material'
    bl_label = _lt('Rebuild Material', 'マテリアル再構築')
    bl_description = _lt('Force full rebuild of the shader network')
    bl_options = {'UNDO'}

    def execute(self, context):
        mat = _active_mat(context)
        if not mat:
            return {'CANCELLED'}
        mat.pbr_properties.is_built = False
        build_network(mat)
        mat.pbr_properties.is_built = True
        _arrange_nodes(mat.node_tree)
        self.report({'INFO'}, _lt('Rebuilt.'))
        return {'FINISHED'}

class PBR_OT_ToggleUI(Operator):
    """Toggle a UI expand/collapse state without touching the material."""
    bl_idname = 'pbr_ld.toggle_ui'
    bl_label = _lt('Toggle UI', 'UI切替')
    bl_options = {'INTERNAL'}
    key: StringProperty()
    default: BoolProperty(default=False)

    def execute(self, context):
        cur = _ui_get(context, self.key, default=self.default)
        _ui_set(context, not cur, self.key)
        for area in context.screen.areas:
            area.tag_redraw()
        return {'FINISHED'}

def _tog(layout, context, label, icon_open, icon_closed, *key_parts, default=False, **kwargs):
    """Draw a clickable toggle row using WM state. Returns current expanded bool."""
    key = _ui_key(*key_parts)
    expanded = _ui_get(context, key, default=default)
    op = layout.operator('pbr_ld.toggle_ui', text=label, icon=icon_open if expanded else icon_closed, emboss=False, **kwargs)
    op.key = key
    op.default = default
    return expanded

def _draw_proc_mask_ui(layout, properties):
    """Draw procedural mask controls for a layer or overlay."""
    mtype = getattr(properties, 'mask_type', 'NOISE')
    col = layout.column(align=True)
    col.prop(properties, 'mask_proc_scale', slider=True)
    if mtype == 'NOISE':
        col.prop(properties, 'mask_proc_detail', slider=True)
        col.prop(properties, 'mask_proc_roughness', slider=True)
        col.prop(properties, 'mask_proc_distortion', slider=True)
    elif mtype == 'WAVE':
        col.prop(properties, 'mask_wave_type', text=_lt('Wave'))
        col.prop(properties, 'mask_wave_profile', text=_lt('Profile'))
        col.prop(properties, 'mask_proc_distortion', slider=True)
        col.prop(properties, 'mask_proc_detail', slider=True)
        col.prop(properties, 'mask_proc_roughness', slider=True)
    elif mtype == 'GRADIENT':
        col.prop(properties, 'mask_gradient_type', text=_lt('Type'))
    elif mtype == 'VORONOI':
        col.prop(properties, 'mask_voronoi_feature', text=_lt('Feature'))
        col.prop(properties, 'mask_voronoi_distance', text=_lt('Distance'))
        col.prop(properties, 'mask_voronoi_random', slider=True)

def _draw_overlay(col, ov, li, key, oi):
    label, icon, _, _ = MAP_INFO[key]
    mat_name = ov.id_data.name if hasattr(ov, 'id_data') and ov.id_data else ''
    ctx = bpy.context
    ov_key = _ui_key(mat_name, li, key, oi, 'ov')
    header, inner = _pbr_native_panel(col, ctx, ov_key, default=True)
    hdr = header.row(align=True)
    hdr.prop(ov, 'enabled', text='', icon='HIDE_OFF' if ov.enabled else 'HIDE_ON')
    hdr.prop(ov, 'name', text='', emboss=True)
    up = hdr.operator('pbr_ld.move_overlay', text='', icon='TRIA_UP', emboss=True)
    up.layer_index = li
    up.map_key = key
    up.overlay_index = oi
    up.direction = 'UP'
    dn = hdr.operator('pbr_ld.move_overlay', text='', icon='TRIA_DOWN', emboss=True)
    dn.layer_index = li
    dn.map_key = key
    dn.overlay_index = oi
    dn.direction = 'DOWN'
    rm = hdr.operator('pbr_ld.remove_overlay', text='', icon='X', emboss=True)
    rm.layer_index = li
    rm.map_key = key
    rm.overlay_index = oi
    if inner is None:
        return
    cc_key = _ui_key(mat_name, li, key, oi, 'cc')
    cc_header, c1 = _pbr_native_panel(inner, ctx, cc_key, default=False)
    r1 = cc_header.row(align=True)
    r1.prop(ov, 'enabled', text='', icon='HIDE_OFF' if ov.enabled else 'HIDE_ON')
    r1.label(text=_lt(f'JP: レイヤー {oi + 1:02d}\nEN: Layer {oi + 1:02d}'))
    if c1 is not None:
        c1 = c1.column(align=True)
        pr = c1.column(align=True)
        pr.prop(ov, 'path', text='', icon='FILE_IMAGE')
        if hasattr(ov, 'udim'):
            pr.prop(ov, 'udim', text='', icon='LIBRARY_DATA_DIRECT' if ov.udim else 'LIBRARY_DATA_OVERRIDE')
        bs = c1.column(align=True)
        bs.prop(ov, 'blend_mode', text='')
        bs.prop(ov, 'strength', text=_lt('Strength'), slider=True)
        if key in GRAYSCALE_KEYS and ov.path.strip():
            rng = c1.column(align=True)
            rng.label(text=_lt('Range:'))
            rng.prop(ov, 'img_min', text=_lt('Min'), slider=True)
            rng.prop(ov, 'img_max', text=_lt('Max'), slider=True)
        c1.separator(factor=0.3)
        c1.label(text=_lt('Color Correction'), icon='COLOR')
        cc = c1.column(align=True)
        cc.prop(ov, 'hue', slider=True)
        cc.prop(ov, 'saturation', slider=True)
        cc.prop(ov, 'value', slider=True)
        cc.prop(ov, 'contrast', slider=True)
        cc.prop(ov, 'gamma', slider=True)
        c1.separator(factor=0.3)
        c1.prop(ov, 'img_use_own_mapping', text=_lt('Override Mapping', 'マッピングを上書き'), icon='DRIVER_TRANSFORM')
        if ov.img_use_own_mapping:
            tc = c1.column(align=True)
            tl = tc.column(align=True)
            tl.prop(ov, 'img_tiling_lock', text='', icon='LOCKED' if ov.img_tiling_lock else 'UNLOCKED')
            if ov.img_tiling_lock:
                tl.prop(ov, 'img_tiling_x', text=_lt('Tiling'))
            else:
                tl.prop(ov, 'img_tiling_x', text=_lt('X'))
                tl.prop(ov, 'img_tiling_y', text=_lt('Y'))
            of = tc.column(align=True)
            of.prop(ov, 'img_offset_x')
            of.prop(ov, 'img_offset_y')
            tc.prop(ov, 'img_rotation')
    msk_key = _ui_key(mat_name, li, key, oi, 'msk')
    msk_header, ms = _pbr_native_panel(inner, ctx, msk_key, default=False)
    r2 = msk_header.row(align=True)
    r2.label(text=_lt('Mask'), icon='IMAGE_ALPHA')
    if ms is not None:
        ms = ms.column(align=True)
        ms.prop(ov, 'mask_type', text='')
        if ov.mask_type == 'IMAGE':
            mr = ms.column(align=True)
            mr.prop(ov, 'mask_path', text='', icon='FILE_IMAGE')
            if hasattr(ov, 'mask_udim'):
                mr.prop(ov, 'mask_udim', text='', icon='LIBRARY_DATA_DIRECT' if ov.mask_udim else 'LIBRARY_DATA_OVERRIDE')
        else:
            _draw_proc_mask_ui(ms, ov)
        ms.prop(ov, 'mask_invert')
        rng = ms.column(align=True)
        rng.prop(ov, 'mask_min', text=_lt('Min'), slider=True)
        rng.prop(ov, 'mask_max', text=_lt('Max'), slider=True)
        ms.separator(factor=0.3)
        ms.prop(ov, 'mask_use_own_mapping', text=_lt('Toggle Mapping UI', 'マッピングUI切替'), icon='DRIVER_TRANSFORM')
        if getattr(ov, 'mask_use_own_mapping', False):
            til = ms.column(align=True)
            til.prop(ov, 'mask_tiling_lock', text='', icon='LOCKED' if ov.mask_tiling_lock else 'UNLOCKED')
            if ov.mask_tiling_lock:
                til.prop(ov, 'mask_tiling_x', text=_lt('Tiling'))
            else:
                til.prop(ov, 'mask_tiling_x', text=_lt('X'))
                til.prop(ov, 'mask_tiling_y', text=_lt('Y'))
            off = ms.column(align=True)
            off.prop(ov, 'mask_offset_x')
            off.prop(ov, 'mask_offset_y')
            ms.prop(ov, 'mask_rotation')

def _draw_map_slot(col, layer, li, key):
    label, icon, cs, vtype = MAP_INFO[key]
    primary = getattr(layer, f'path_{key}', '').strip()
    use_key = f'use_{key}'
    use_val = getattr(layer, use_key, True)
    abs_p = bpy.path.abspath(primary) if primary else ''
    ok = bool(primary and os.path.isfile(abs_p))
    miss = bool(primary and (not ok))
    extras = getattr(layer, f'extra_{key}', [])
    has_any = bool(primary) or any((e.path.strip() for e in extras))
    slot_box = col.box()
    r1 = slot_box.column(align=True)
    r1.prop(layer, use_key, text='', icon='HIDE_OFF' if use_val else 'HIDE_ON', emboss=True)
    r1.label(text='', icon='CHECKMARK' if ok else 'ERROR' if miss else 'RADIOBUT_OFF')
    r1.label(text=_lt(label), icon=icon)
    r2 = slot_box.column(align=True)
    r2.prop(layer, f'path_{key}', text='', icon='FILE_IMAGE')
    if hasattr(layer, f'udim_{key}'):
        r2.prop(layer, f'udim_{key}', text='', icon='LIBRARY_DATA_DIRECT' if getattr(layer, f'udim_{key}', False) else 'LIBRARY_DATA_OVERRIDE')
    add = r2.operator('pbr_ld.add_overlay', text='', icon='ADD', emboss=True)
    add.layer_index = li
    add.map_key = key
    SPLIT = 0.3
    if ok and key in GRAYSCALE_KEYS:
        sp = slot_box.column(align=True)
        sp.label(text=_lt('Range:'))
        rv = sp.column(align=True)
        rv.prop(layer, f'min_{key}', text=_lt('Min'), slider=True)
        rv.prop(layer, f'max_{key}', text=_lt('Max'), slider=True)
    if not has_any and vtype != 'NONE' and use_val:
        sp = slot_box.column(align=True)
        sp.label(text=_lt('Value:'))
        if vtype == 'COLOR':
            sp.prop(layer, f'val_{key}', text='')
        else:
            sp.prop(layer, f'val_{key}', text='', slider=True)
    if key == 'base_color' and has_any:
        cc_box = slot_box.box()
        cc_col = cc_box.column(align=True)
        cc_col.label(text=_lt('Color Correction'), icon='COLOR')
        cc_col.prop(layer, 'hue', slider=True)
        cc_col.prop(layer, 'saturation', slider=True)
        cc_col.prop(layer, 'value', slider=True)
        cc_col.prop(layer, 'contrast', slider=True)
        cc_col.prop(layer, 'gamma', slider=True)
        cc_col.separator(factor=0.3)
        cc_col.prop(layer, 'bc_use_own_mapping', text=_lt('Override Mapping', 'マッピングを上書き'), icon='DRIVER_TRANSFORM')
        if layer.bc_use_own_mapping:
            tc = cc_col.column(align=True)
            tl = tc.column(align=True)
            tl.prop(layer, 'bc_tiling_lock', text='', icon='LOCKED' if layer.bc_tiling_lock else 'UNLOCKED')
            if layer.bc_tiling_lock:
                tl.prop(layer, 'bc_tiling_x', text=_lt('Tiling'))
            else:
                tl.prop(layer, 'bc_tiling_x', text=_lt('X'))
                tl.prop(layer, 'bc_tiling_y', text=_lt('Y'))
            of = tc.column(align=True)
            of.prop(layer, 'bc_offset_x')
            of.prop(layer, 'bc_offset_y')
            tc.prop(layer, 'bc_rotation')
    elif key in ('roughness', 'glossiness') and has_any:
        sp = slot_box.column(align=True)
        sp.label(text=_lt('Bias:'))
        sp.prop(layer, 'roughness_bias', text='', slider=True)
        sp2 = slot_box.column(align=True)
        sp2.label(text=_lt('Strength:'))
        sp2.prop(layer, f'str_{key}', text='', slider=True)
    elif key == 'metallic' and has_any:
        sp = slot_box.column(align=True)
        sp.label(text=_lt('Bias:'))
        sp.prop(layer, 'metallic_bias', text='', slider=True)
        sp2 = slot_box.column(align=True)
        sp2.label(text=_lt('Strength:'))
        sp2.prop(layer, 'str_metallic', text='', slider=True)
    elif key == 'normal' and has_any:
        sp = slot_box.column(align=True)
        sp.label(text=_lt('Strength:'))
        sp.prop(layer, 'normal_strength', text='', slider=True)
    elif key == 'bump' and has_any:
        sp = slot_box.column(align=True)
        sp.label(text=_lt('Strength:'))
        sp.prop(layer, 'bump_strength', text='', slider=True)
    elif key == 'ao' and has_any:
        sp = slot_box.column(align=True)
        sp.label(text=_lt('Strength:'))
        sp.prop(layer, 'ao_strength', text='', slider=True)
    elif key == 'emission':
        sp = slot_box.column(align=True)
        sp.label(text=_lt('Strength:'))
        sp.prop(layer, 'emission_strength', text='', slider=True)
    elif key == 'coat_normal' and has_any:
        sp = slot_box.column(align=True)
        sp.label(text=_lt('Strength:'))
        sp.prop(layer, 'normal_strength', text='', slider=True)
    elif key == 'displacement' and li == 0:
        sp1 = slot_box.column(align=True)
        sp1.label(text=_lt('Scale:'))
        sp1.prop(layer, 'disp_scale', text='', slider=True)
        sp2 = slot_box.column(align=True)
        sp2.label(text=_lt('Midlevel:'))
        sp2.prop(layer, 'disp_midlevel', text='', slider=True)
    if key != 'base_color' and ok:
        own_key = f'ch_own_mapping_{key}'
        lock_k = f'ch_tiling_lock_{key}'
        tr = slot_box.box()
        tr.prop(layer, own_key, text=_lt('Override Mapping', 'マッピングを上書き'), icon='DRIVER_TRANSFORM')
        if getattr(layer, own_key, False):
            tc = tr.column(align=True)
            tl = tc.column(align=True)
            tl.prop(layer, lock_k, text='', icon='LOCKED' if getattr(layer, lock_k, True) else 'UNLOCKED')
            if getattr(layer, lock_k, True):
                tl.prop(layer, f'ch_tiling_x_{key}', text=_lt('Tiling'))
            else:
                tl.prop(layer, f'ch_tiling_x_{key}', text=_lt('X'))
                tl.prop(layer, f'ch_tiling_y_{key}', text=_lt('Y'))
            of = tc.column(align=True)
            of.prop(layer, f'ch_offset_x_{key}')
            of.prop(layer, f'ch_offset_y_{key}')
            tc.prop(layer, f'ch_rotation_{key}')
    for oi, ov in enumerate(extras):
        _draw_overlay(col, ov, li, key, oi)

def _draw_layer(layout, layer, li, is_only):
    v_keys = SHADER_MAPS.get(layer.shader_type, MAP_KEYS)
    n_conn = sum((1 for k in v_keys if _has_img(layer, k) or _has_extras(layer, k)))
    ctx = bpy.context
    mat = _active_mat(ctx)
    mn = mat.name if mat else ''
    layer_key = _ui_key(mn, li, 'exp')
    header, col = _pbr_native_panel(layout, ctx, layer_key, default=True)
    hrow = header.row(align=True)
    hrow.prop(layer, 'enabled', text='', icon='HIDE_OFF' if layer.enabled else 'HIDE_ON', emboss=True)
    hrow.prop(layer, 'name', text='', emboss=col is not None)
    if col is None and n_conn:
        hrow.label(text=_lt(f'JP: {n_conn} 個のマップ\nEN: {n_conn} maps'))
    up = hrow.operator('pbr_ld.move_layer', text='', icon='TRIA_UP', emboss=True)
    up.layer_index = li
    up.direction = 'UP'
    dn = hrow.operator('pbr_ld.move_layer', text='', icon='TRIA_DOWN', emboss=True)
    dn.layer_index = li
    dn.direction = 'DOWN'
    cp = hrow.operator('pbr_ld.duplicate_layer', text='', icon='DUPLICATE', emboss=True)
    cp.layer_index = li
    if not is_only:
        rm = hrow.operator('pbr_ld.remove_layer', text='', icon='X', emboss=True)
        rm.layer_index = li
    if col is None:
        return
    col = col.column(align=False)
    sr = col.column(align=True)
    sr.label(text=_lt('Shader'), icon='NODE_MATERIAL')
    sr.prop(layer, 'shader_type', text='')
    if layer.shader_type == 'PRINCIPLED':
        col.prop(layer, 'specular_distribution', text=_lt('Distribution'))
        col.prop(layer, 'sss_method', text=_lt('SSS Method'))
    if layer.shader_type == 'SSS':
        col.prop(layer, 'sss_scale', slider=True)
    if layer.shader_type == 'EMISSION':
        col.prop(layer, 'emission_strength', slider=True)
    col.separator(factor=0.4)
    sb = col.box()
    sb.prop(layer, 'scan_dir_path', text='')
    sr2 = sb.column(align=True)
    sr2.scale_y = 1.1
    so = sr2.operator('pbr_ld.scan_layer_folder', text=_lt('Scan Layer Layer'), icon='VIEWZOOM')
    so.layer_index = li
    co = sr2.operator('pbr_ld.clear_layer', text=_lt('Clear Layer', 'レイヤーをクリア'), icon='X')
    co.layer_index = li
    col.separator(factor=0.3)
    maps_key = _ui_key(mn, li, 'maps')
    maps_header, maps_body = _pbr_native_panel(col, ctx, maps_key, default=False)
    maps_header.label(text=_lt(f'JP: マップ ({n_conn})\nEN: Maps ({n_conn})') if n_conn else _lt('Maps'))
    if maps_body is not None:
        stype_ = layer.shader_type
        visible_groups = SHADER_GROUPS.get(stype_, [g[0] for g in MAP_GROUPS])
        for grp_key, grp_label, grp_icon, grp_keys in MAP_GROUPS:
            if grp_key not in visible_groups:
                continue
            if grp_key == 'displacement' and li != 0:
                continue
            visible_keys = [k for k in grp_keys if k in v_keys or grp_key == 'displacement']
            if not visible_keys:
                continue
            grp_key_full = _ui_key(mn, li, 'grp', grp_key)
            grp_header, grp_body = _pbr_native_panel(maps_body, ctx, grp_key_full, default=False)
            grp_header.label(text=_lt(grp_label), icon=grp_icon)
            if grp_body is not None:
                for k in visible_keys:
                    _draw_map_slot(grp_body.column(align=True), layer, li, k)
    col.separator(factor=0.3)
    mapping_key = _ui_key(mn, li, 'mapping')
    mapping_header, mb2 = _pbr_native_panel(col, ctx, mapping_key, default=False)
    mapping_header.label(text=_lt('Mapping', 'マッピング'))
    if mb2 is not None:
        pre = mb2.column(align=True)
        pre.label(text=_lt('Preset:'))
        for val, lbl in ((0.5, '½'), (1, '1×'), (2, '2×'), (4, '4×'), (8, '8×')):
            op = pre.operator('pbr_ld.set_tiling', text=lbl)
            op.layer_index = li
            op.value = val
        tr = mb2.column(align=True)
        tr.label(text=_lt('Tiling'))
        tr.prop(layer, 'tiling_lock', text='', icon='LOCKED' if layer.tiling_lock else 'UNLOCKED')
        if layer.tiling_lock:
            mb2.prop(layer, 'tiling_x', text=_lt('Scale'))
        else:
            sr3 = mb2.column(align=True)
            sr3.prop(layer, 'tiling_x')
            sr3.prop(layer, 'tiling_y')
        mb2.label(text=_lt('Offset'))
        or2 = mb2.column(align=True)
        or2.prop(layer, 'offset_x')
        or2.prop(layer, 'offset_y')
        mb2.prop(layer, 'rotation')
    col.separator(factor=0.3)
    if li > 0:
        mp = layer.mask_path.strip()
        has_m = bool(mp and os.path.isfile(bpy.path.abspath(mp)))
        mask_state_en = 'connected' if has_m else 'none'; mask_state_ja = _lt('connected') if has_m else _lt('none')
        mask_key = _ui_key(mn, li, 'lmask')
        mask_header, mk = _pbr_native_panel(col, ctx, mask_key, default=False)
        mask_header.label(text=_lt(f'Layer Mask ({mask_state_en})', f'レイヤーマスク ({mask_state_ja})'))
        if mk is not None:
            mk.prop(layer, 'blend_mode', text=_lt('Blend Mode'))
            mk.prop(layer, 'mask_strength', slider=True)
            mk.separator(factor=0.3)
            mk.prop(layer, 'mask_type', text='')
            if layer.mask_type == 'IMAGE':
                mr = mk.column(align=True)
                mr.prop(layer, 'mask_path', text='', icon='FILE_IMAGE')
                if hasattr(layer, 'mask_udim'):
                    mr.prop(layer, 'mask_udim', text='', icon='LIBRARY_DATA_DIRECT' if layer.mask_udim else 'LIBRARY_DATA_OVERRIDE')
            else:
                _draw_proc_mask_ui(mk, layer)
            mk.prop(layer, 'mask_invert')
            mnmxr = mk.column(align=True)
            mnmxr.prop(layer, 'mask_min', text=_lt('Min'), slider=True)
            mnmxr.prop(layer, 'mask_max', text=_lt('Max'), slider=True)
            mk.separator(factor=0.3)
            mk.label(text=_lt('Mask Transform'), icon='DRIVER_TRANSFORM')
            til2 = mk.column(align=True)
            til2.prop(layer, 'mask_tiling_lock', text='', icon='LOCKED' if layer.mask_tiling_lock else 'UNLOCKED')
            if layer.mask_tiling_lock:
                til2.prop(layer, 'mask_tiling_x', text=_lt('Tiling'))
            else:
                til2.prop(layer, 'mask_tiling_x')
                til2.prop(layer, 'mask_tiling_y')
            off2 = mk.column(align=True)
            off2.prop(layer, 'mask_offset_x')
            off2.prop(layer, 'mask_offset_y')
            mk.prop(layer, 'mask_rotation')
        col.separator(factor=0.3)

def draw_pbr_panel(layout, context, *, embedded: bool = False):
    if not _pbr_context_is_stable(context):
        return
    if not embedded:
        _box, layout, _expanded = ui_sections.draw_group(layout, context, 'pbr_lookdev_panel', _lt('PBR Lookdev', 'PBR ルックデブ'), icon='SHADING_TEXTURE', topic='pbr_lookdev', default_open=False)
    mat = _active_mat(context)
    if mat is None:
        b = layout.box()
        b.label(text=_lt('No active material'))
        b.operator('pbr_ld.create_material', text=_lt('Create Material'), icon='ADD')
        return
    properties = mat.pbr_properties
    if not properties.layers:
        b = layout.box()
        b.label(text=_lt('No PBR layers yet', 'PBRレイヤーなし'))
        b.operator('pbr_ld.add_layer', text=_lt('JP: ベースレイヤー追加\nEN: Add Base Layer'), icon='ADD')
        return
    top = layout.column(align=True)
    top.label(text=mat.name, icon='MATERIAL', translate=False)
    top.operator('pbr_ld.collapse_all', text='', icon='RIGHTARROW_THIN', emboss=True)
    top.operator('pbr_ld.create_material', text=_lt('Create Material'), icon='ADD')
    layout.separator(factor=0.3)
    is_only = len(properties.layers) == 1
    for idx, layer in enumerate(properties.layers):
        _draw_layer(layout, layer, idx, is_only)
    layout.column().operator('pbr_ld.add_layer', text=_lt('Add Layer'), icon='ADD')
    layout.separator(factor=0.5)
    if properties.is_built:
        layout.column().operator('pbr_ld.rebuild_material', text=_lt('Rebuild Network'), icon='FILE_REFRESH')
    else:
        layout.column().operator('pbr_ld.build_material', text=_lt('Build Material'), icon='NODE_COMPOSITING')

SSS_DISABLE_PROXY_PANELS = True

def draw_smart_shader_runtime_controls(layout, context):
    try:
        draw_pbr_panel(layout, context, embedded=True)
    except Exception as exc:
        warn = layout.box()
        warn.alert = True
        warn.label(text=_lt('PBR Lookdev UI could not be drawn.', 'PBR ルックデブ UI を描画できませんでした。'), icon='ERROR')
        warn.label(text=_exc_text(exc))


class PBR_PT_PBRLookdev(Panel):
    bl_label = _lt('PBR Lookdev', 'PBR ルックデブ')
    bl_idname = 'PBR_PT_PBRLookdev'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = _lt('Smart Shader')

    @classmethod
    def poll(cls, context):
        if not _pbr_context_is_stable(context):
            return False
        try:
            s = getattr(context, 'space_data', None)
            return getattr(s, 'type', '') == 'NODE_EDITOR' and getattr(s, 'tree_type', '') == 'ShaderNodeTree' and (getattr(s, 'shader_type', '') == 'OBJECT')
        except Exception:
            return False


    def draw(self, context):
        try:
            draw_pbr_panel(self.layout, context)
        except Exception as exc:
            try:
                self.layout.label(text=_exc_text(exc), icon='ERROR')
            except Exception:
                pass

class PBR_PT_PBRLookdevViewport(Panel):
    bl_label = _lt('PBR Lookdev', 'PBR ルックデブ')
    bl_idname = 'PBR_PT_PBRLookdevViewport'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = _lt('Smart Shader')

    @classmethod
    def poll(cls, context):
        if not _pbr_context_is_stable(context):
            return False
        try:
            area = getattr(context, 'area', None)
            return getattr(area, 'type', '') == 'VIEW_3D'
        except Exception:
            return False


    def draw(self, context):
        try:
            draw_pbr_panel(self.layout, context)
        except Exception as exc:
            try:
                self.layout.label(text=_exc_text(exc), icon='ERROR')
            except Exception:
                pass
classes = (PBR_UISectionState, PBR_Overlay, PBR_MapLayer, PBR_MaterialProps, PBR_OT_CreateMaterial, PBR_OT_AddLayer, PBR_OT_RemoveLayer, PBR_OT_MoveLayer, PBR_OT_ScanLayerFolder, PBR_OT_ClearLayer, PBR_OT_AddOverlay, PBR_OT_RemoveOverlay, PBR_OT_MoveOverlay, PBR_OT_DuplicateLayer, PBR_OT_SetTiling, PBR_OT_CollapseAll, PBR_OT_ToggleUI, PBR_OT_BuildMaterial, PBR_OT_RebuildMaterial, PBR_PT_PBRLookdev, PBR_PT_PBRLookdevViewport)


@persistent
def _pbr_apply_ui_state_on_load(_dummy=None):
    try:
        from .. import transform_guard as _sss_transform_guard
    except Exception:
        from . import transform_guard as _sss_transform_guard
    with _sss_transform_guard.preserve_object_transforms('pbr lookdev ui load_post'):
        _pbr_apply_ui_state(getattr(bpy, 'context', None))
        restore_pbr_material_settings()


@persistent
def _pbr_save_ui_state_on_save(_dummy=None):
    try:
        from .. import transform_guard as _sss_transform_guard
    except Exception:
        from . import transform_guard as _sss_transform_guard
    with _sss_transform_guard.preserve_object_transforms('pbr lookdev ui save_pre'):
        _pbr_save_ui_state(getattr(bpy, 'context', None), force=True)
        save_pbr_material_settings(force=True)


def _pbr_register_ui_state_handlers() -> None:
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is None:
            return
        load_post = getattr(handlers, 'load_post', None)
        save_pre = getattr(handlers, 'save_pre', None)
        if load_post is not None and _pbr_apply_ui_state_on_load not in load_post:
            load_post.append(_pbr_apply_ui_state_on_load)
        if save_pre is not None and _pbr_save_ui_state_on_save not in save_pre:
            save_pre.append(_pbr_save_ui_state_on_save)
    except Exception:
        pass


def _pbr_unregister_ui_state_handlers() -> None:
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is None:
            return
        load_post = getattr(handlers, 'load_post', None)
        save_pre = getattr(handlers, 'save_pre', None)
        if load_post is not None and _pbr_apply_ui_state_on_load in load_post:
            load_post.remove(_pbr_apply_ui_state_on_load)
        if save_pre is not None and _pbr_save_ui_state_on_save in save_pre:
            save_pre.remove(_pbr_save_ui_state_on_save)
    except Exception:
        pass


def set_ui_persistence_enabled(enabled: bool) -> None:
    _pbr_unregister_ui_state_handlers()
    if bool(enabled):
        _pbr_register_ui_state_handlers()


_PBR_REGISTERED_CLASSES = []


def _pbr_class_has_own_bl_rna(cls):
    try:
        rna = vars(cls).get('bl_rna') or getattr(cls, 'bl_rna', None)
        identifier = str(getattr(rna, 'identifier', '') or '')
        inherited = {'Operator', 'Panel', 'PropertyGroup', 'Menu', 'UIList', 'AddonPreferences'}
        return bool(identifier and identifier not in inherited)
    except Exception:
        return False

def _pbr_safe_register_class(cls):
    if cls in _PBR_REGISTERED_CLASSES and _pbr_class_has_own_bl_rna(cls):
        return
    if _pbr_class_has_own_bl_rna(cls):
        raise RuntimeError(f'RNA class is already registered outside this generation ledger: {getattr(cls, "__name__", "<unnamed>")}')
    bpy.utils.register_class(cls)
    if _pbr_class_has_own_bl_rna(cls) and cls not in _PBR_REGISTERED_CLASSES:
        _PBR_REGISTERED_CLASSES.append(cls)

def _pbr_safe_unregister_class(cls):
    if cls in _PBR_REGISTERED_CLASSES and _pbr_class_has_own_bl_rna(cls):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            return
    if not _pbr_class_has_own_bl_rna(cls):
        try:
            _PBR_REGISTERED_CLASSES.remove(cls)
        except ValueError:
            pass


def register():
    for c in classes:
        _pbr_safe_register_class(c)
    bpy.types.Material.pbr_properties = PointerProperty(type=PBR_MaterialProps)
    bpy.types.WindowManager.pbr_ui_state = StringProperty(default='{}')
    bpy.types.WindowManager.pbr_ui_sections = bpy.props.CollectionProperty(type=PBR_UISectionState, options={'SKIP_SAVE'})
    set_ui_persistence_enabled(storage.npanel_state_save_enabled(default=True))
    _pbr_apply_ui_state(getattr(bpy, 'context', None))
    restore_pbr_material_settings()

def unregister():
    _pbr_unregister_ui_state_handlers()
    _pbr_save_ui_state(getattr(bpy, 'context', None), force=True)
    save_pbr_material_settings(force=True)
    try:
        del bpy.types.WindowManager.pbr_ui_sections
    except Exception:
        pass
    try:
        del bpy.types.Material.pbr_properties
    except Exception:
        pass
    for c in reversed(classes):
        try:
            _pbr_safe_unregister_class(c)
        except Exception:
            pass
    try:
        del bpy.types.WindowManager.pbr_ui_state
    except Exception:
        pass
if __name__ == '__main__':
    register()
