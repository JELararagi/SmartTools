"""Bounded, side-effect-free Smart Toon image alpha analysis helpers."""

from __future__ import annotations

from array import array
from collections import OrderedDict
from dataclasses import dataclass
import os
import time
from typing import Any, Iterable

PROFILE_NONE = "NONE"
PROFILE_BINARY = "BINARY"
PROFILE_SEMI = "SEMI"
PROFILE_UNKNOWN = "UNKNOWN"
PROFILE_INVALID = "INVALID"

CAPABILITY_YES = "ALPHA"
CAPABILITY_NO = "NO_ALPHA"
CAPABILITY_UNKNOWN = "UNKNOWN"

NO_ALPHA_EXTENSIONS = {".jpg", ".jpeg", ".jpe", ".jfif"}
NO_ALPHA_FORMATS = {"JPEG"}


class BoundedLRU:
    def __init__(self, limit: int = 128):
        self.limit = max(1, int(limit))
        self.data: OrderedDict[Any, Any] = OrderedDict()

    def get(self, key: Any, default: Any = None) -> Any:
        try:
            value = self.data.pop(key)
        except KeyError:
            return default
        self.data[key] = value
        return value

    def set(self, key: Any, value: Any) -> None:
        self.data.pop(key, None)
        self.data[key] = value
        while len(self.data) > self.limit:
            self.data.popitem(last=False)

    def pop(self, key: Any, default: Any = None) -> Any:
        return self.data.pop(key, default)

    def clear(self) -> None:
        self.data.clear()

    def __len__(self) -> int:
        return len(self.data)


@dataclass(frozen=True)
class ImageMetadata:
    identity: int
    name: str
    has_data: bool
    width: int
    height: int
    channels: int
    depth: int
    alpha_mode: str
    source: str
    file_format: str
    filepath: str
    file_mtime_ns: int
    file_size: int
    dirty: bool
    packed: bool

    @property
    def pixel_count(self) -> int:
        return max(0, self.width) * max(0, self.height)

    @property
    def revision(self) -> tuple:
        return (
            self.identity, self.name, self.has_data, self.width, self.height,
            self.channels, self.depth, self.alpha_mode, self.source,
            self.file_format, self.filepath, self.file_mtime_ns,
            self.file_size, self.dirty, self.packed,
        )


def _safe_identity(image: Any) -> int:
    if image is None:
        return 0
    try:
        return int(image.as_pointer())
    except Exception:
        return id(image)


def image_metadata(image: Any, resolved_path: str = "") -> ImageMetadata:
    if image is None:
        return ImageMetadata(0, "<none>", False, 0, 0, 0, 0, "", "", "", "", 0, 0, False, False)
    try:
        size = getattr(image, "size", (0, 0))
        width, height = int(size[0]), int(size[1])
    except Exception:
        width, height = 0, 0
    try:
        path = str(resolved_path or getattr(image, "filepath", "") or "")
    except Exception:
        path = str(resolved_path or "")
    mtime_ns = 0
    file_size = 0
    if path:
        try:
            stat = os.stat(path)
            mtime_ns = int(getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1_000_000_000)))
            file_size = int(stat.st_size)
        except OSError:
            pass
    try:
        name = str(getattr(image, "name_full", getattr(image, "name", "<unnamed>")) or "<unnamed>")
    except Exception:
        name = "<unnamed>"
    def _int(name: str) -> int:
        try:
            return int(getattr(image, name, 0) or 0)
        except Exception:
            return 0
    def _text(name: str) -> str:
        try:
            return str(getattr(image, name, "") or "").upper()
        except Exception:
            return ""
    def _bool(name: str) -> bool:
        try:
            return bool(getattr(image, name, False))
        except Exception:
            return False
    try:
        packed = bool(getattr(image, "packed_file", None))
    except Exception:
        packed = False
    return ImageMetadata(
        _safe_identity(image), name, _bool("has_data"), width, height,
        _int("channels"), _int("depth"), _text("alpha_mode"),
        _text("source"), _text("file_format"), path, mtime_ns,
        file_size, _bool("is_dirty"), packed,
    )


def metadata_capability(metadata: ImageMetadata) -> str:
    if metadata.identity == 0:
        return CAPABILITY_NO
    if metadata.alpha_mode in {"CHANNEL_PACKED", "NONE"}:
        return CAPABILITY_NO
    if metadata.file_format in NO_ALPHA_FORMATS:
        return CAPABILITY_NO
    if os.path.splitext(metadata.filepath.lower())[1] in NO_ALPHA_EXTENSIONS:
        return CAPABILITY_NO
    if metadata.channels in {1, 3}:
        return CAPABILITY_NO
    if metadata.channels in {2, 4}:
        return CAPABILITY_YES
    return CAPABILITY_UNKNOWN


def classify_alpha_values(values: Iterable[float], epsilon: float = 1.0e-6, *, zero_is_transparent: bool = False) -> str:
    saw_zero = False
    saw_one = False
    saw_middle = False
    count = 0
    for raw in values:
        try:
            value = float(raw)
        except Exception:
            continue
        count += 1
        if value <= epsilon:
            saw_zero = True
        elif value >= 1.0 - epsilon:
            saw_one = True
        else:
            saw_middle = True
            break
    if count == 0:
        return PROFILE_UNKNOWN
    if saw_middle:
        return PROFILE_SEMI
    # B58_06_FILE_PNG_ZERO_ALPHA_20261024
    # 明示的なPNGの透明チャンネルは全画素0でも有効。
    # 生成画像やその他の経路では従来の空チャンネル保護を維持する。
    if saw_zero and not saw_one:
        return PROFILE_BINARY if zero_is_transparent else PROFILE_NONE
    if saw_zero and saw_one:
        return PROFILE_BINARY
    return PROFILE_NONE


def bulk_alpha_profile(image: Any, metadata: ImageMetadata, max_floats: int = 262_144) -> tuple[str, str]:
    """Read one bounded contiguous pixel buffer; never perform random indexing."""
    capability = metadata_capability(metadata)
    if capability == CAPABILITY_NO:
        return PROFILE_NONE, "metadata_no_alpha"
    if not metadata.has_data or metadata.width <= 0 or metadata.height <= 0:
        return PROFILE_INVALID, "image_not_ready"
    channels = metadata.channels
    if channels not in {2, 4}:
        return PROFILE_UNKNOWN, "uncertain_channels"
    total = metadata.pixel_count * channels
    if total <= 0:
        return PROFILE_INVALID, "empty_pixels"
    if total > max(1, int(max_floats)):
        return PROFILE_UNKNOWN, "bounded_scan_skipped"
    pixels = getattr(image, "pixels", None)
    foreach_get = getattr(pixels, "foreach_get", None)
    if not callable(foreach_get):
        return PROFILE_INVALID, "pixels_foreach_get_unavailable"
    buffer = array("f", [0.0]) * total
    try:
        foreach_get(buffer)
    except Exception as exc:
        return PROFILE_INVALID, f"pixels_foreach_get_failed:{type(exc).__name__}"
    alpha_index = channels - 1
    zero_is_transparent = (
        metadata.source == "FILE"
        and metadata.file_format == "PNG"
        and metadata.alpha_mode in {"STRAIGHT", "PREMUL"}
    )
    return classify_alpha_values(
        buffer[alpha_index::channels], zero_is_transparent=zero_is_transparent
    ), "bulk_foreach_get"


class AlphaAnalysisRuntime:
    def __init__(self, cache_limit: int = 128, cooldown_seconds: float = 0.75, max_floats: int = 262_144):
        self.profiles = BoundedLRU(cache_limit)
        self.transient_failures = BoundedLRU(cache_limit)
        self.retry_gates = BoundedLRU(cache_limit)
        self.diagnostics = BoundedLRU(cache_limit)
        self.cooldown_seconds = max(0.05, float(cooldown_seconds))
        self.max_floats = max(4, int(max_floats))

    def clear(self) -> None:
        self.profiles.clear()
        self.transient_failures.clear()
        self.retry_gates.clear()
        self.diagnostics.clear()

    def invalidate(self, image: Any | None = None) -> None:
        if image is None:
            self.clear()
            return
        identity = _safe_identity(image)
        for cache in (self.profiles, self.transient_failures, self.retry_gates, self.diagnostics):
            for key in tuple(cache.data):
                if isinstance(key, tuple) and identity in key:
                    cache.pop(key, None)

    def _record_once(self, metadata: ImageMetadata, cause: str, detail: str = "") -> None:
        key = (metadata.identity, cause)
        if self.diagnostics.get(key) is None:
            self.diagnostics.set(key, {"cause": cause, "detail": str(detail)[:240]})

    def profile(self, image: Any, *, resolved_path: str = "", allow_pixels: bool = True, now: float | None = None) -> tuple[str, dict[str, Any]]:
        metadata = image_metadata(image, resolved_path)
        key = metadata.revision
        cached = self.profiles.get(key)
        if cached is not None:
            return cached[0], dict(cached[1])
        capability = metadata_capability(metadata)
        if capability == CAPABILITY_NO:
            result = (PROFILE_NONE, {"source": "metadata", "metadata": metadata})
            self.profiles.set(key, result)
            return result[0], dict(result[1])
        if not metadata.has_data or metadata.pixel_count <= 0:
            cause = "image_not_ready"
            timestamp = time.monotonic() if now is None else float(now)
            failure_key = (metadata.identity, cause)
            retry_at = float(self.transient_failures.get(failure_key, 0.0) or 0.0)
            if timestamp >= retry_at:
                self.transient_failures.set(failure_key, timestamp + self.cooldown_seconds)
                self._record_once(metadata, cause)
            return PROFILE_INVALID, {"source": "transient", "cause": cause, "retry_at": retry_at, "metadata": metadata}
        if not allow_pixels:
            return PROFILE_UNKNOWN, {"source": "metadata_conservative", "metadata": metadata}
        timestamp = time.monotonic() if now is None else float(now)
        gate = self.retry_gates.get(key)
        if isinstance(gate, dict) and timestamp < float(gate.get("retry_at", 0.0) or 0.0):
            return PROFILE_INVALID, {
                "source": "transient_cooldown",
                "cause": str(gate.get("cause", "image_not_ready")),
                "retry_at": float(gate.get("retry_at", 0.0) or 0.0),
                "metadata": metadata,
            }
        profile, cause = bulk_alpha_profile(image, metadata, self.max_floats)
        if profile == PROFILE_INVALID:
            retry_at = timestamp + self.cooldown_seconds
            failure_key = (metadata.identity, cause)
            self.transient_failures.set(failure_key, retry_at)
            self.retry_gates.set(key, {"retry_at": retry_at, "cause": cause})
            self._record_once(metadata, cause)
            # Transient failures are deliberately not placed in profiles.
            return profile, {"source": "transient", "cause": cause, "retry_at": retry_at, "metadata": metadata}
        result = (profile, {"source": cause, "metadata": metadata})
        self.profiles.set(key, result)
        self.retry_gates.pop(key, None)
        self.transient_failures.pop((metadata.identity, cause), None)
        return result[0], dict(result[1])


def bulk_luminance_profile(image: Any, metadata: ImageMetadata, max_floats: int = 262_144) -> tuple[str, str]:
    """Classify a grayscale/separate-alpha image from one bounded bulk read."""
    if not metadata.has_data or metadata.width <= 0 or metadata.height <= 0:
        return PROFILE_INVALID, "image_not_ready"
    channels = metadata.channels
    if channels <= 0:
        return PROFILE_UNKNOWN, "uncertain_channels"
    total = metadata.pixel_count * channels
    if total <= 0:
        return PROFILE_INVALID, "empty_pixels"
    if total > max(1, int(max_floats)):
        return PROFILE_UNKNOWN, "bounded_scan_skipped"
    pixels = getattr(image, "pixels", None)
    foreach_get = getattr(pixels, "foreach_get", None)
    if not callable(foreach_get):
        return PROFILE_INVALID, "pixels_foreach_get_unavailable"
    buffer = array("f", [0.0]) * total
    try:
        foreach_get(buffer)
    except Exception as exc:
        return PROFILE_INVALID, f"pixels_foreach_get_failed:{type(exc).__name__}"
    values = []
    if channels == 1:
        values = buffer
    elif channels == 2:
        values = buffer[0::2]
    else:
        for base in range(0, total, channels):
            r = float(buffer[base])
            g = float(buffer[base + 1]) if channels > 1 else r
            b = float(buffer[base + 2]) if channels > 2 else r
            values.append((r + g + b) / 3.0)
    return classify_alpha_values(values), "bulk_foreach_get_luminance"
