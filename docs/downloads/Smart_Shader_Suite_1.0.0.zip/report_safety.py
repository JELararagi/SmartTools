# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Route messages away from Blender's popup queue during editor teardown."""

from collections import Counter
from contextlib import contextmanager
from contextvars import ContextVar

import bpy

ROUTING_LOG = []
_BLOCKS = ContextVar("shader_report_blocks", default=())
_DEFAULT = "SmartShader"


@contextmanager
def unsafe_context(tag=""):
    scope = _BLOCKS.set((*_BLOCKS.get(), tag))
    try:
        yield tag
    finally:
        _BLOCKS.reset(scope)


def in_unsafe_context():
    return bool(_BLOCKS.get())


def popup_capable(context=None):
    if bpy.app.background or in_unsafe_context():
        return False
    context = bpy.context if context is None else context
    try:
        window = context.window
        screen = (getattr(window, "screen", None) or context.screen) if window else None
        return bool(screen and not getattr(screen, "show_fullscreen", False) and context.area)
    except (AttributeError, ReferenceError, RuntimeError):
        return False


def _levels(level):
    if isinstance(level, str):
        return [level]
    try:
        return sorted(map(str, level or ()))
    except TypeError:
        return [str(level)]


def console(level, message, tag=_DEFAULT):
    try:
        print(f"[{tag}][{'/'.join(_levels(level)) or 'INFO'}] {message}", flush=True)
    except (OSError, UnicodeError, ValueError):
        pass


def routing_counts():
    counts = Counter(item["destination"] for item in ROUTING_LOG)
    return {"report": counts["report"], "console": counts["console"]}


def safe_report(operator, level, message, *, tag=_DEFAULT, force_console=False):
    levels = _levels(level)
    text = str(message)
    destination = "console"
    reason = "console requested"
    if not force_console and not isinstance(operator, ReportProxy) and operator is not None:
        reason = "no stable popup context"
        if popup_capable():
            try:
                operator.report(set(levels), text)
                destination, reason = "report", "popup capable"
            except Exception:
                reason = "report raised"
    if destination == "console":
        console(levels, text, tag)
    if len(ROUTING_LOG) < 512:
        ROUTING_LOG.append(dict(destination=destination, level=levels, message=text[:240],
                                reason=reason, unsafe_depth=len(_BLOCKS.get())))
    return destination


class ReportProxy:
    __slots__ = ("operator", "tag")

    def __init__(self, operator, tag=_DEFAULT):
        object.__setattr__(self, "operator", operator)
        object.__setattr__(self, "tag", tag)

    @property
    def sss_wrapped_operator(self):
        return self.operator

    def report(self, level, message):
        safe_report(None, level, message, tag=self.tag, force_console=True)

    def __getattr__(self, name):
        return getattr(self.operator, name)

    def __setattr__(self, name, value):
        setattr(self.operator, name, value)


def call_with_report_proxy(operator, method_name, *args, **kwargs):
    with unsafe_context("operator delegation"):
        function = getattr(type(operator), method_name, None)
        if callable(function):
            return function(ReportProxy(operator), *args, **kwargs)
        return getattr(operator, method_name)(*args, **kwargs)


def defer(function, *, first_interval=0.0, tag="deferred"):
    def once():
        try:
            function()
        except Exception as error:
            console({"WARNING"}, f"{tag}: {error}")
        return None

    try:
        bpy.app.timers.register(once, first_interval=float(first_interval), persistent=False)
    except Exception as error:
        console({"WARNING"}, f"{tag}: could not schedule ({error})")
        once()
        return False
    return True
