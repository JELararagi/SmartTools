# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Context-safe operator reporting and deferred screen mutation.

Blender does not draw an operator's reports while the operator runs.  It queues
them and, once the operator returns ``FINISHED``/``CANCELLED``, builds a report
popup from the event loop::

    wm_handler_operator_call -> wm_operator_reports -> UI_popup_menu_reports
        -> ui_popup_block_create -> ui_region_temp_add(CTX_wm_screen(C))
        -> BLI_addtail(&screen->regionbase, ...)

``ui_region_temp_add`` never checks its ``bScreen``.  If the operator destroyed
the screen that hosted it before returning -- ``screen.back_to_previous``,
``screen.screen_full_area``, ``wm.window_close`` -- or if it ran from a context
with no screen at all (an RNA ``update=`` callback, an ``app.timers`` callback, a
handler), that ``BLI_addtail`` dereferences a freed or null ``bScreen`` and
Blender dies with ``EXCEPTION_ACCESS_VIOLATION`` reading the ``regionbase``
offset -- ``0x1D0`` on the 5.1.2 ``ec6e62d40fa9`` build.

Two rules follow, and this module implements both:

1. Never queue a report Blender will have to draw later against a screen that is
   already gone or was never there.  :func:`safe_report` checks the context and
   degrades to the console instead.
2. Never let an operator tear down its own hosting screen or window before it
   returns, and never call ``bpy.ops`` from an RNA update callback.
   :func:`defer` runs the mutation from a one-shot ``bpy.app.timers`` callback,
   so the operator returns while its screen is still alive.

Pure stdlib plus ``bpy``.  No registration, no state that survives a reload.
"""

from __future__ import annotations

import contextlib

import bpy

__all__ = (
    'console',
    'defer',
    'in_unsafe_context',
    'popup_capable',
    'ReportProxy',
    'ROUTING_LOG',
    'routing_counts',
    'safe_report',
    'unsafe_context',
)

# Depth of "a report queued right now would be drawn against a dead or missing
# screen".  Pushed around screen/window teardown and around RNA update callbacks.
_UNSAFE_DEPTH = 0

# Bounded evidence trail.  Every routing decision is recorded so a headless probe
# can prove that nothing reached Blender's report queue from an unsafe path.
ROUTING_LOG: list[dict] = []
_ROUTING_LOG_LIMIT = 512

_CONSOLE_TAG = 'SmartShader'


def _log(destination: str, level, message: str, reason: str) -> None:
    if len(ROUTING_LOG) >= _ROUTING_LOG_LIMIT:
        return
    try:
        levels = sorted(str(item) for item in (level or ()))
    except Exception:
        levels = [str(level)]
    ROUTING_LOG.append({
        'destination': destination,
        'level': levels,
        'message': str(message)[:240],
        'reason': reason,
        'unsafe_depth': _UNSAFE_DEPTH,
    })


def routing_counts() -> dict:
    """Summary of :data:`ROUTING_LOG`, for gate evidence."""
    counts = {'report': 0, 'console': 0}
    for record in ROUTING_LOG:
        key = str(record.get('destination') or '')
        counts[key] = counts.get(key, 0) + 1
    return counts


def in_unsafe_context() -> bool:
    """True while an RNA update callback or a screen teardown is in progress."""
    return _UNSAFE_DEPTH > 0


@contextlib.contextmanager
def unsafe_context(tag: str = ''):
    """Mark a block from which no report may reach Blender's report queue."""
    global _UNSAFE_DEPTH
    _UNSAFE_DEPTH += 1
    try:
        yield tag
    finally:
        _UNSAFE_DEPTH = max(0, _UNSAFE_DEPTH - 1)


def popup_capable(context=None) -> bool:
    """True only when Blender can build a report popup for the current context.

    ``UI_popup_menu_begin`` needs a window, and ``ui_region_temp_add`` needs the
    window's screen.  Background Blender never draws one, so it is never capable.
    """
    if getattr(getattr(bpy, 'app', None), 'background', False):
        return False
    if _UNSAFE_DEPTH > 0:
        return False
    ctx = context if context is not None else getattr(bpy, 'context', None)
    if ctx is None:
        return False
    try:
        window = getattr(ctx, 'window', None)
        if window is None:
            return False
        screen = getattr(window, 'screen', None) or getattr(ctx, 'screen', None)
        if screen is None:
            return False
        # A temporary fullscreen screen is about to be replaced by
        # screen.back_to_previous; treat it as not capable so the message goes to
        # the console rather than to a popup drawn against a freed screen.
        if bool(getattr(screen, 'show_fullscreen', False)):
            return False
        return getattr(ctx, 'area', None) is not None
    except Exception:
        return False


def console(level, message: str, tag: str = _CONSOLE_TAG) -> None:
    """Emit a diagnostic that can never reach Blender's report popup path."""
    try:
        levels = '/'.join(sorted(str(item) for item in (level or ()))) or 'INFO'
    except Exception:
        levels = 'INFO'
    try:
        print('[%s][%s] %s' % (tag, levels, message), flush=True)
    except Exception:
        pass


def safe_report(operator, level, message: str, *, tag: str = _CONSOLE_TAG,
                force_console: bool = False) -> str:
    """Report through ``operator`` only when the context can host the popup.

    Returns ``'report'`` when the message was handed to Blender and ``'console'``
    when it was printed instead.  Never raises.
    """
    text = str(message)
    if operator is None or force_console or not popup_capable():
        reason = ('forced' if force_console
                  else 'no operator' if operator is None
                  else 'unsafe context')
        _log('console', level, text, reason)
        console(level, text, tag)
        return 'console'
    try:
        operator.report(level, text)
    except Exception:
        _log('console', level, text, 'report raised')
        console(level, text, tag)
        return 'console'
    _log('report', level, text, 'popup capable')
    return 'report'


class ReportProxy:
    """Transparent stand-in for an operator whose reports must not be queued.

    Attribute reads and writes pass through to the real operator, so callee code
    that inspects ``self.target`` or assigns ``self.preset_id`` keeps working.
    Only ``report`` is replaced: it always goes to the console, because the
    caller is on a path that destroys the screen the popup would need.
    """

    __slots__ = ('_sss_operator', '_sss_tag')

    def __init__(self, operator, tag: str = _CONSOLE_TAG):
        object.__setattr__(self, '_sss_operator', operator)
        object.__setattr__(self, '_sss_tag', tag)

    @property
    def sss_wrapped_operator(self):
        return object.__getattribute__(self, '_sss_operator')

    def report(self, level, message):
        safe_report(None, level, message,
                    tag=object.__getattribute__(self, '_sss_tag'),
                    force_console=True)
        return None

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, '_sss_operator'), name)

    def __setattr__(self, name, value):
        setattr(object.__getattribute__(self, '_sss_operator'), name, value)

    def __repr__(self):
        return '<ReportProxy %r>' % (object.__getattribute__(self, '_sss_operator'),)


def call_with_report_proxy(operator, method_name: str, *args, **kwargs):
    """Call ``operator.<method_name>`` with reports forced to the console.

    The method is looked up on the class and invoked with a :class:`ReportProxy`
    as ``self``, so every ``self.report`` inside it -- including in wrappers
    other modules installed on the class -- is routed away from Blender's report
    queue.  Falls back to the bound method inside an :func:`unsafe_context` when
    the class lookup is not possible.
    """
    if operator is None:
        raise AttributeError(method_name)
    function = getattr(type(operator), method_name, None)
    if callable(function):
        return function(ReportProxy(operator), *args, **kwargs)
    bound = getattr(operator, method_name)
    with unsafe_context('report_proxy_fallback'):
        return bound(*args, **kwargs)


def defer(function, *, first_interval: float = 0.0, tag: str = 'deferred') -> bool:
    """Run ``function`` from a one-shot ``bpy.app.timers`` callback.

    Used for the screen and window operators the picker needs after it is done:
    running them inline would free the screen Blender still has to draw the
    operator's report popup against, and ``bpy.ops`` must never be called from an
    RNA update callback at all.  Returns True when the callback was scheduled;
    on failure the function is run inline so behaviour is preserved.
    """
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        try:
            function()
        except Exception as exc:
            console({'WARNING'}, 'deferred %s failed inline: %s' % (tag, exc))
        return False

    def _one_shot():
        try:
            function()
        except Exception as exc:
            console({'WARNING'}, 'deferred %s failed: %s' % (tag, exc))
        return None

    try:
        timers.register(_one_shot, first_interval=float(first_interval), persistent=False)
        return True
    except Exception as exc:
        console({'WARNING'}, 'could not defer %s: %s' % (tag, exc))
        try:
            function()
        except Exception as inner:
            console({'WARNING'}, 'deferred %s failed inline: %s' % (tag, inner))
        return False
