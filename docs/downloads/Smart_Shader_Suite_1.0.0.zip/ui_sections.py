"""Smart Modeling-style collapsible UI section helpers for Smart Shader Suite."""

from __future__ import annotations

import re

import bpy
from bpy.props import StringProperty

from . import storage

from .translation import loc_text as _lt


_STATE_PREFIX = "sss_ui_section_open__"
_FALLBACK_STATE: dict[str, bool] = {}


def _normalize_key(value: str | None) -> str:
    text = str(value or "").strip().lower()
    if not text:
        return "section"
    text = re.sub(r"[^a-z0-9_]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("_")
    return text or "section"


def _state_key(section_key: str | None) -> str:
    return _STATE_PREFIX + _normalize_key(section_key)


def _wm(context):
    try:
        return getattr(context, "window_manager", None)
    except Exception:
        return None


def is_open(context, section_key: str | None, default: bool = False) -> bool:
    key = _state_key(section_key)
    wm = _wm(context)
    try:
        if wm is not None and key in wm:
            return bool(wm[key])
    except Exception:
        pass
    return bool(_FALLBACK_STATE.get(key, default))


def _collect_section_state(context=None) -> dict[str, bool]:
    ctx = context or getattr(bpy, "context", None)
    out: dict[str, bool] = {}
    wm = _wm(ctx)
    try:
        if wm is not None:
            for key in list(wm.keys()):
                key = str(key or '')
                if key.startswith(_STATE_PREFIX):
                    out[key] = bool(wm[key])
    except Exception:
        pass
    for key, value in _FALLBACK_STATE.items():
        try:
            if str(key).startswith(_STATE_PREFIX):
                out[str(key)] = bool(value)
        except Exception:
            pass
    return out


def save_section_state(context=None, *, force: bool = False) -> None:
    if not force:
        try:
            if not storage.npanel_state_save_enabled(default=True):
                return
        except Exception:
            pass
    try:
        storage.write_suite_section('ui_sections', _collect_section_state(context))
    except Exception:
        pass


def apply_section_state(context=None) -> None:
    ctx = context or getattr(bpy, "context", None)
    try:
        data = storage.read_suite_section('ui_sections', {})
    except Exception:
        data = {}
    if not isinstance(data, dict):
        return
    wm = _wm(ctx)
    for key, value in data.items():
        try:
            key = str(key or '')
            if not key.startswith(_STATE_PREFIX):
                continue
            enabled = bool(value)
            _FALLBACK_STATE[key] = enabled
            if wm is not None:
                wm[key] = enabled
        except Exception:
            pass


def set_open(context, section_key: str | None, value: bool) -> None:
    key = _state_key(section_key)
    value = bool(value)
    wm = _wm(context)
    try:
        if wm is not None:
            wm[key] = value
    except Exception:
        pass
    _FALLBACK_STATE[key] = value
    save_section_state(context)
    tag_redraw(context)




def cleanup_legacy_section_state(context=None) -> None:
    """Remove stale section-open keys that came from older section-key logic.

    Older builds could persist keys such as ``sms_sms_core_settings``.  Those
    stale keys can make nested Shader Studio sections appear opened and
    visually step to the right.  Delete only known duplicate-prefix keys and
    leave the current ``sms_*`` state untouched.
    """
    ctx = context or getattr(bpy, "context", None)
    prefixes = (_STATE_PREFIX + "sms_sms_",)
    wm = _wm(ctx)
    if wm is not None:
        try:
            keys = [str(k) for k in wm.keys()]
        except Exception:
            keys = []
        for key in keys:
            if key.startswith(prefixes):
                try:
                    wm.pop(key, None)
                except Exception:
                    try:
                        del wm[key]
                    except Exception:
                        pass
    for key in list(_FALLBACK_STATE.keys()):
        try:
            if str(key).startswith(prefixes):
                _FALLBACK_STATE.pop(key, None)
        except Exception:
            pass


def tag_redraw(context=None) -> None:
    try:
        context = context or bpy.context
        screen = getattr(context, "screen", None)
        for area in getattr(screen, "areas", ()) or ():
            try:
                area.tag_redraw()
            except Exception:
                pass
    except Exception:
        pass


class SSS_OT_toggle_ui_section(bpy.types.Operator):
    bl_idname = "sss.toggle_ui_section"
    bl_label = _lt("Toggle UI Section", "UIセクション開閉")
    bl_description = _lt("Open or close this section.", "このセクションを開閉します。")
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    section_key: StringProperty(options={"SKIP_SAVE"})
    label: StringProperty(options={"SKIP_SAVE"})

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, "label", "") or getattr(properties, "section_key", "") or "").strip()
        if label:
            return _lt(f"Open or close the {label} section.", f"{label} セクションを開閉します。")
        return _lt("Open or close this section.", "このセクションを開閉します。")

    def execute(self, context):
        key = str(self.section_key or "").strip()
        if not key:
            return {"CANCELLED"}
        set_open(context, key, not is_open(context, key, False))
        return {"FINISHED"}


class _NoOpOperator:
    """Safe dummy operator returned by collapsed-section layouts."""

    def __setattr__(self, name, value):
        object.__setattr__(self, name, value)

    def __getattr__(self, name):
        return None


class _NoOpLayout:
    """Layout-like object used when a collapsed section should ignore draw calls.

    Important: ``operator()`` must not return ``self``.  Blender operator proxy
    properties such as ``label`` or ``tooltip`` are frequently assigned after
    ``layout.operator(...)``.  Returning the layout itself lets those assignments
    overwrite methods like ``label()``, which produced ``'str' object is not
    callable`` during nested collapsed-section drawing.
    """

    _METHOD_NAMES = {
        'row', 'column', 'box', 'split', 'grid_flow', 'label', 'operator', 'prop',
        'prop_search', 'menu', 'separator', 'panel', 'panel_prop', 'template_ID',
        'template_icon', 'template_list', 'popover', 'context_pointer_set',
    }

    def __init__(self):
        object.__setattr__(self, "enabled", False)
        object.__setattr__(self, "active", False)
        object.__setattr__(self, "alert", False)
        object.__setattr__(self, "scale_x", 1.0)
        object.__setattr__(self, "scale_y", 1.0)
        object.__setattr__(self, "alignment", "LEFT")
        object.__setattr__(self, "use_property_split", False)
        object.__setattr__(self, "use_property_decorate", False)
        object.__setattr__(self, "operator_context", "EXEC_DEFAULT")

    def __setattr__(self, name, value):
        # Never let operator-style property assignment replace layout methods.
        if str(name) in self._METHOD_NAMES:
            object.__setattr__(self, f"_ignored_{name}", value)
            return
        object.__setattr__(self, name, value)

    def __getattr__(self, name):
        def _noop(*args, **kwargs):
            return _NoOpLayout()
        return _noop

    def row(self, *args, **kwargs): return _NoOpLayout()
    def column(self, *args, **kwargs): return _NoOpLayout()
    def box(self, *args, **kwargs): return _NoOpLayout()
    def split(self, *args, **kwargs): return _NoOpLayout()
    def grid_flow(self, *args, **kwargs): return _NoOpLayout()
    def label(self, *args, **kwargs): return None
    def operator(self, *args, **kwargs): return _NoOpOperator()
    def prop(self, *args, **kwargs): return None
    def prop_search(self, *args, **kwargs): return None
    def menu(self, *args, **kwargs): return None
    def separator(self, *args, **kwargs): return None
    def panel(self, *args, **kwargs): return _NoOpLayout(), None
    def panel_prop(self, *args, **kwargs): return _NoOpLayout(), None
    def template_ID(self, *args, **kwargs): return None
    def template_icon(self, *args, **kwargs): return None
    def template_list(self, *args, **kwargs): return None


NOOP_LAYOUT = _NoOpLayout()


_CUSTOM_HEADER_KEYS = {
    'always_on_toggles',
    'material_editor',
    'pbr_material_generation',
    'smart_toon',
    'npr_toon_line_production',
    'texture_set_import_autowire',
    'material_library_management',
    'scene_material_rules',
    'hdri_world_management',
    'audit_repair_report_handoff',
}


def _draw_standard_child_panel(
    layout,
    context,
    section_key: str,
    title: str,
    *,
    icon: str = "NONE",
    topic: str = "",
    default_open: bool = False,
):
    """Draw a child section with Blender's native disclosure panel.

    ``UILayout.panel`` owns the live open/closed state in the current UI region.
    The previous persisted section value is used only as the first-show default,
    so existing defaults migrate without recreating a custom disclosure button.
    """
    section_key = _normalize_key(section_key)
    title = str(title or "").strip()
    initial_open = is_open(context, section_key, default_open)
    header, native_body = layout.panel(
        "sss_native_child__" + section_key,
        default_closed=not initial_open,
    )

    split = header.split(factor=0.88, align=True)
    left = split.row(align=True)
    if icon and icon != "NONE":
        left.label(text=title, icon=icon)
    else:
        left.label(text=title)
    right = split.row(align=True)
    right.alignment = "RIGHT"
    draw_help_button(right, context, topic, label="")

    if native_body is None:
        return layout, NOOP_LAYOUT, False

    body = native_body.column(align=True)
    body.use_property_split = False
    body.use_property_decorate = False
    return layout, body, True

def _safe_operator(layout, operator_id: str, *, text: str = "", icon: str = "NONE", emboss: bool = True, depress: bool = False):
    try:
        return layout.operator(operator_id, text=text, icon=icon or "NONE", emboss=emboss, depress=depress)
    except Exception:
        try:
            return layout.operator(operator_id, text=text, icon="NONE", emboss=emboss, depress=depress)
        except Exception:
            return None


def draw_help_button(layout, context, topic: str | None, *, label: str = "") -> bool:
    topic = str(topic or "").strip()
    if not topic:
        return False
    try:
        op = layout.operator("sss.open_help", text=label, icon="QUESTION", emboss=True)
        op.topic = topic
        return True
    except Exception:
        try:
            layout.label(text="", icon="QUESTION")
        except Exception:
            pass
        return False


def draw_group(
    layout,
    context,
    section_key: str,
    title: str,
    *,
    icon: str = "NONE",
    topic: str = "",
    default_open: bool = False,
):
    """Draw one Smart Shader collapsible section.

    Suite top-level sections retain their existing custom header. Every child
    and grandchild section is routed through ``UILayout.panel`` and therefore
    uses Blender's native thin disclosure chevron. The return interface remains
    ``(container, body, expanded)`` and collapsed bodies remain no-op layouts.
    """
    section_key = _normalize_key(section_key)
    title = str(title or "").strip()
    if section_key not in _CUSTOM_HEADER_KEYS:
        return _draw_standard_child_panel(
            layout,
            context,
            section_key,
            title,
            icon=icon,
            topic=topic,
            default_open=default_open,
        )

    expanded = is_open(context, section_key, default_open)

    try:
        box = layout.box()
    except Exception:
        box = layout

    try:
        # Shared Smart Tools section header: triangle, borderless icon+title, small gap, compact help.
        header = box.row(align=True)
        header.use_property_split = False
        header.use_property_decorate = False

        left = header
        # Root headers must retain Blender's standard control height.  Body
        # compactness is intentionally applied only by descendant drawers.
        left.scale_y = 1.0
        op = _safe_operator(
            left,
            "sss.toggle_ui_section",
            text="",
            icon="TRIA_DOWN" if expanded else "TRIA_RIGHT",
            emboss=True,
            depress=expanded,
        )
        if op is not None:
            op.section_key = section_key
            op.label = title

        title_op = _safe_operator(
            left,
            "sss.toggle_ui_section",
            text=title,
            icon=icon if icon and icon != "NONE" else "NONE",
            emboss=False,
            depress=expanded,
        )
        if not title_op:
            left.label(text=title, icon=icon if icon and icon != "NONE" else "NONE")
        else:
            title_op.section_key = section_key
            title_op.label = title

        try:
            header.separator(factor=0.35)
        except Exception:
            pass
        help_row = header.row(align=True)
        help_row.scale_x = 0.82
        draw_help_button(help_row, context, topic, label="")
    except Exception:
        try:
            box.label(text=title, icon=icon or "NONE")
        except Exception:
            pass

    if not expanded:
        return box, _NoOpLayout(), False

    try:
        body = box.column(align=True)
        body.use_property_split = False
        body.use_property_decorate = False
    except Exception:
        body = box
    return box, body, True


CLASSES = (
    SSS_OT_toggle_ui_section,
)
