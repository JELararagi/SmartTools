"""World/HDRI helpers for lookdev environments and relinking."""
from __future__ import annotations
from .translation import loc_text as _lt
from .translation import AddonError
from pathlib import Path
import os
import time
import bpy
from . import core
from .translation import tx
HDRI_EXTENSIONS = {'.hdr', '.exr', '.tx', '.tif', '.tiff', '.png', '.jpg', '.jpeg', '.webp'}
HDRI_SEARCH_SENTINEL = 'NO_HDRI_CANDIDATES'
_WORLD_HDRI_STATE_CACHE: dict[tuple, tuple[float, dict]] = {}

def _new_node(nt, bl_idname: str, x: float, y: float, label: str=''):
    node = nt.nodes.new(bl_idname)
    node.location = (x, y)
    if label:
        node.label = label
        try:
            node.name = label
        except Exception:
            pass
    return node

def _safe_socket(collection, *names):
    return core.socket_by_name(collection, *names)

def _connect(nt, out_socket, in_socket):
    if out_socket is None or in_socket is None:
        return False
    try:
        nt.links.new(out_socket, in_socket)
        return True
    except Exception:
        return False

_HDRI_ENTRY_CACHE: dict[tuple[str, str], list[dict]] = {}


def invalidate_hdri_cache() -> None:
    _HDRI_ENTRY_CACHE.clear()


def _hdri_cache_key(root: Path | str | None, filter_text: str='') -> tuple[str, str]:
    try:
        root_text = str(Path(root or '').expanduser().resolve())
    except Exception:
        root_text = str(root or '')
    return (root_text, str(filter_text or '').strip().lower())


def _iter_hdri_files(root: Path):
    root = Path(root)
    if not root.exists():
        return
    try:
        if root.is_file():
            try:
                stat = root.stat()
            except Exception:
                stat = None
            yield root, stat
            return
    except Exception:
        return
    stack = [root]
    while stack:
        current = stack.pop()
        entries = []
        try:
            entries = list(os.scandir(current))
        except Exception:
            continue
        dirs: list[Path] = []
        for entry in entries:
            try:
                if entry.is_dir(follow_symlinks=False):
                    dirs.append(Path(entry.path))
                    continue
                if entry.is_file(follow_symlinks=False):
                    stat = None
                    try:
                        stat = entry.stat(follow_symlinks=False)
                    except Exception:
                        stat = None
                    yield Path(entry.path), stat
            except Exception:
                continue
        dirs.sort(key=lambda item: str(item).lower(), reverse=True)
        stack.extend(dirs)


def _scan_hdri_entries(root: Path | str | None, filter_text: str='') -> list[dict]:
    if not root:
        return []
    root = Path(root)
    if not root.exists():
        return []
    filter_lc = (filter_text or '').strip().lower()
    entries: list[dict] = []
    priority = {'.exr': 0, '.hdr': 1, '.tx': 2, '.tif': 3, '.tiff': 4, '.png': 5, '.jpg': 6, '.jpeg': 7, '.webp': 8}
    for path_obj, stat in _iter_hdri_files(root):
        if path_obj.suffix.lower() not in HDRI_EXTENSIONS:
            continue
        haystack = f'{path_obj.name} {path_obj.stem} {path_obj.parent.name}'.lower()
        if filter_lc and filter_lc not in haystack:
            continue
        size_bytes = 0
        if stat is not None:
            try:
                size_bytes = int(getattr(stat, 'st_size', 0) or 0)
            except Exception:
                size_bytes = 0
        folder = path_obj.parent.name or str(path_obj.parent)
        entries.append({'key': str(path_obj), 'path': str(path_obj), 'filename': path_obj.name, 'name': path_obj.stem, 'folder': folder, 'extension': path_obj.suffix.lower().lstrip('.'), 'size_mb': round(float(size_bytes) / (1024.0 * 1024.0), 2)})
    entries.sort(key=lambda item: (priority.get('.' + str(item.get('extension', '') or '').lower(), 99), len(str(item.get('path', '') or '')), str(item.get('filename', '') or '').lower()))
    return entries


def collect_hdri_candidates(root: Path, filter_text: str='') -> list[Path]:
    return [Path(entry.get('path', '')) for entry in list_hdri_entries(root, query=filter_text, limit=1000000)]


def list_hdri_entries(root: Path | str | None, query: str='', limit: int=48) -> list[dict]:
    if not root:
        return []
    cache_key = _hdri_cache_key(root, query)
    cached = _HDRI_ENTRY_CACHE.get(cache_key)
    if cached is None:
        cached = _scan_hdri_entries(root, filter_text=query)
        _HDRI_ENTRY_CACHE[cache_key] = list(cached)
    return [dict(entry) for entry in list(cached)[:max(1, int(limit or 48))]]

def _scene_hdri_root(scene) -> str:
    if scene is None:
        return ''
    raw = str(getattr(scene, 'sss_hdri_library_root', '') or '').strip()
    if not raw:
        return ''
    if bpy is not None:
        try:
            raw = bpy.path.abspath(raw)
        except Exception:
            pass
    return raw

def hdri_search_items(scene=None):
    root = _scene_hdri_root(scene)
    query = getattr(scene, 'sss_hdri_search', '') if scene is not None else ''
    items = []
    for entry in list_hdri_entries(root, query=query):
        label_en = str(entry.get('filename', '') or entry.get('name', '') or 'HDRI')
        label_ja = label_en
        folder = str(entry.get('folder', '') or '-')
        ext = str(entry.get('extension', '') or '-')
        size_mb = float(entry.get('size_mb', 0.0) or 0.0)
        en = f'Folder: {folder} | Format: {ext.upper()} | Size: {size_mb:.2f} MB'
        ja = _lt(f'フォルダ: {folder} | 形式: {ext.upper()} | サイズ: {size_mb:.2f} MB')
        if scene is None:
            label = tx(None, label_en, label_ja)
            desc = tx(None, en, ja)
        else:
            label = tx(scene, label_en, label_ja)
            desc = tx(scene, en, ja)
        items.append((str(entry.get('key', '')), label, desc))
    if not items:
        items.append((HDRI_SEARCH_SENTINEL, tx(scene, 'No HDRI Candidates', _lt('一致するHDRI候補なし')), tx(scene, 'Choose an HDRI library root or change the search text.', _lt('HDRI ライブラリのルートを指定するか、検索語を変えてください。'))))
    return items

def find_hdri_candidate(key: str, scene=None):
    value = str(key or '').strip()
    if not value or value == HDRI_SEARCH_SENTINEL:
        return None
    root = _scene_hdri_root(scene)
    query = getattr(scene, 'sss_hdri_search', '') if scene is not None else ''
    for entry in list_hdri_entries(root, query=query, limit=256):
        if entry.get('key') == value or core.library_name_key(entry.get('path', '')) == core.library_name_key(value):
            return entry
    path = Path(value)
    if path.exists() and path.is_file() and (path.suffix.lower() in HDRI_EXTENSIONS):
        return list_hdri_entries(path, limit=1)[0]
    return None

def hdri_candidate_summary(scene, entry: dict | None) -> str:
    if not entry:
        return tx(scene, 'No HDRI candidate selected yet.', _lt('まだHDRI候補が選択されていません。'))
    path = str(entry.get('path', '') or '')
    current = str(getattr(scene, 'sss_hdri_path', '') or '') if scene is not None else ''
    selected = core.library_name_key(current) == core.library_name_key(path)
    lines_en = [f"File: {entry.get('filename', '-')}", f"Folder: {entry.get('folder', '-')}", f"Format: {str(entry.get('extension', '-') or '-').upper()}", f"Size: {float(entry.get('size_mb', 0.0) or 0.0):.2f} MB", f'Selected for build: {selected}', f"Path: {path or '-'}"]
    lines_ja = [_lt(f"ファイル: {entry.get('filename', '-')}"), _lt(f"フォルダ: {entry.get('folder', '-')}"), _lt(f"形式: {str(entry.get('extension', '-') or '-').upper()}"), _lt(f"サイズ: {float(entry.get('size_mb', 0.0) or 0.0):.2f} MB"), _lt(f'構築対象に選択中: {selected}'), _lt(f"パス: {path or '-'}")]
    return tx(scene, '\n'.join(lines_en), '\n'.join(lines_ja))

def apply_hdri_candidate_to_scene(scene, entry: dict) -> str:
    path = str((entry or {}).get('path', '') or '')
    if not path:
        raise AddonError(_lt('HDRI candidate path is empty.', 'HDRI候補のパスが空です。'))
    scene.sss_hdri_path = path
    return path

def ensure_scene_world(context, name: str='SSS_HDRI_World'):
    scene = getattr(context, 'scene', None)
    if scene is None:
        return None
    world = getattr(scene, 'world', None)
    if world is None:
        world = bpy.data.worlds.new(name)
        scene.world = world
    world.use_nodes = True
    return world

def world_environment_nodes(world) -> list:
    if world is None or not getattr(world, 'use_nodes', False) or (not getattr(world, 'node_tree', None)):
        return []
    return [node for node in world.node_tree.nodes if node.bl_idname == 'ShaderNodeTexEnvironment']

def active_world_environment_node(world):
    nodes = world_environment_nodes(world)
    return nodes[0] if nodes else None

def active_world_image(world):
    node = active_world_environment_node(world)
    return getattr(node, 'image', None) if node else None

def active_world_mapping_node(world):
    if world is None or not getattr(world, 'use_nodes', False) or (not getattr(world, 'node_tree', None)):
        return None
    for node in world.node_tree.nodes:
        if node.bl_idname == 'ShaderNodeMapping':
            return node
    return None

def active_world_background_node(world):
    if world is None or not getattr(world, 'use_nodes', False) or (not getattr(world, 'node_tree', None)):
        return None
    for node in world.node_tree.nodes:
        if node.bl_idname == 'ShaderNodeBackground':
            return node
    return None

def _mapping_z_rotation(node) -> float:
    if node is None:
        return 0.0
    socket = _safe_socket(getattr(node, 'inputs', None), 'Rotation')
    if socket is None:
        return 0.0
    try:
        value = list(socket.default_value)
        if len(value) >= 3:
            return float(value[2])
    except Exception:
        pass
    return 0.0

def _background_strength(node) -> float:
    if node is None:
        return 1.0
    socket = _safe_socket(getattr(node, 'inputs', None), 'Strength')
    if socket is None:
        return 1.0
    try:
        return float(socket.default_value)
    except Exception:
        return 1.0

def _id_pointer(value) -> int:
    if value is None:
        return 0
    try:
        pointer = int(value.as_pointer())
        if pointer:
            return pointer
    except Exception:
        pass
    return id(value)


def _world_state_cache_key(world) -> tuple:
    node_count = 0
    link_count = 0
    image_path = ''
    image_name = ''
    image_packed = False
    try:
        tree = getattr(world, 'node_tree', None)
        if tree is not None:
            node_count = len(getattr(tree, 'nodes', []) or [])
            link_count = len(getattr(tree, 'links', []) or [])
    except Exception:
        node_count = 0
        link_count = 0
    try:
        image = active_world_image(world)
    except Exception:
        image = None
    if image is not None:
        image_name = str(getattr(image, 'name', '') or '')
        image_path = str(getattr(image, 'filepath', '') or '')
        image_packed = bool(getattr(image, 'packed_file', None))
    return (_id_pointer(world), str(getattr(world, 'name', '') or ''), node_count, link_count, image_name, image_path, image_packed)


def _cache_world_state(cache_key: tuple, state: dict) -> dict:
    _WORLD_HDRI_STATE_CACHE[cache_key] = (time.monotonic(), dict(state))
    if len(_WORLD_HDRI_STATE_CACHE) > 64:
        for old_key in list(_WORLD_HDRI_STATE_CACHE.keys())[:16]:
            _WORLD_HDRI_STATE_CACHE.pop(old_key, None)
    return state


def world_hdri_state(context) -> dict:
    scene = getattr(context, 'scene', None)
    world = getattr(scene, 'world', None) if scene else None
    state = {'has_world': bool(world), 'world_name': getattr(world, 'name', '') if world else '', 'has_hdri': False, 'missing': False, 'path': '', 'strength': 1.0, 'rotation': 0.0, 'status_en': 'No HDRI world', 'status_ja': _lt('HDRIワールドなし')}
    if world is None:
        return state
    cache_key = _world_state_cache_key(world)
    now = time.monotonic()
    cached = _WORLD_HDRI_STATE_CACHE.get(cache_key)
    if cached is not None and now - cached[0] < 1.0:
        return dict(cached[1])
    current_strength = _background_strength(active_world_background_node(world))
    current_rotation = _mapping_z_rotation(active_world_mapping_node(world))
    state['strength'] = current_strength
    state['rotation'] = current_rotation
    image = active_world_image(world)
    if image is None:
        state['status_en'] = f"World '{world.name}' has no environment texture"
        state['status_ja'] = _lt(f'ワールド「{world.name}」に環境テクスチャがありません')
        return _cache_world_state(cache_key, state)
    state['has_hdri'] = True
    try:
        raw = bpy.path.abspath(getattr(image, 'filepath', '') or '')
    except Exception:
        raw = str(getattr(image, 'filepath', '') or '')
    state['path'] = raw
    if not raw:
        state['missing'] = True
        state['status_en'] = f"HDRI image '{image.name}' has an empty path"
        state['status_ja'] = _lt(f'HDRI画像「{image.name}」のパスが空です')
        return _cache_world_state(cache_key, state)
    if not getattr(image, 'packed_file', None) and (not Path(raw).exists()):
        state['missing'] = True
        state['status_en'] = f'HDRI image is missing: {Path(raw).name}'
        state['status_ja'] = _lt(f'HDRI画像が見つかりません: {Path(raw).name}')
        return _cache_world_state(cache_key, state)
    state['status_en'] = f'HDRI ready: {Path(raw).name}'
    state['status_ja'] = _lt(f'HDRI準備完了: {Path(raw).name}')
    return _cache_world_state(cache_key, state)

def build_hdri_world(context, hdri_path: Path | str, strength: float=1.0, rotation: float=0.0) -> dict:
    result = {'created_nodes': 0, 'loaded_image': False, 'world_name': '', 'notes': []}
    if not hdri_path:
        result['notes'].append(tx(getattr(context, 'scene', None), 'No HDRI path', _lt('HDRIのパスがありません')))
        return result
    hdri_path = Path(hdri_path)
    if not hdri_path.exists() or not hdri_path.is_file():
        result['notes'].append(tx(getattr(context, 'scene', None), f'HDRI file not found: {hdri_path}', _lt(f'HDRIファイルが見つかりません: {hdri_path}')))
        return result
    world = ensure_scene_world(context)
    if world is None:
        result['notes'].append(tx(getattr(context, 'scene', None), 'No scene/world', _lt('シーンまたはワールドがありません')))
        return result
    nt = world.node_tree
    nt.nodes.clear()
    texcoord = _new_node(nt, 'ShaderNodeTexCoord', -860, 0, 'Texture Coordinate')
    mapping = _new_node(nt, 'ShaderNodeMapping', -620, 0, 'HDRI Mapping')
    env = _new_node(nt, 'ShaderNodeTexEnvironment', -380, 0, 'HDRI Environment')
    background = _new_node(nt, 'ShaderNodeBackground', -140, 0, 'Background')
    output = _new_node(nt, 'ShaderNodeOutputWorld', 120, 0, 'World Output')
    result['created_nodes'] = 5
    try:
        image = bpy.data.images.load(str(hdri_path), check_existing=True)
        env.image = image
        result['loaded_image'] = True
    except Exception as exc:
        result['notes'].append(tx(getattr(context, 'scene', None), f'Failed to load HDRI: {Path(hdri_path).name}', f'HDRIを読み込めませんでした: {Path(hdri_path).name}'))
        return result
    rotation_socket = _safe_socket(mapping.inputs, 'Rotation')
    if rotation_socket is not None:
        try:
            value = list(rotation_socket.default_value)
            while len(value) < 3:
                value.append(0.0)
            value[2] = float(rotation)
            rotation_socket.default_value = value
        except Exception:
            pass
    strength_socket = _safe_socket(background.inputs, 'Strength')
    if strength_socket is not None:
        try:
            strength_socket.default_value = float(strength)
        except Exception:
            pass
    vector_out = _safe_socket(texcoord.outputs, 'Generated', 'Reflection', 'Camera')
    _connect(nt, vector_out, _safe_socket(mapping.inputs, 'Vector'))
    _connect(nt, _safe_socket(mapping.outputs, 'Vector'), _safe_socket(env.inputs, 'Vector'))
    _connect(nt, _safe_socket(env.outputs, 'Color'), _safe_socket(background.inputs, 'Color'))
    _connect(nt, _safe_socket(background.outputs, 'Background'), _safe_socket(output.inputs, 'Surface'))
    try:
        world['sss_managed_hdri'] = True
        world['sss_hdri_path'] = str(hdri_path)
        world['sss_hdri_strength'] = float(strength)
        world['sss_hdri_rotation'] = float(rotation)
    except Exception:
        pass
    try:
        context.scene.sss_hdri_path = str(hdri_path)
    except Exception:
        pass
    result['world_name'] = world.name
    result['notes'].append(tx(getattr(context, 'scene', None), f'HDRI file: {hdri_path.name}', _lt(f'HDRIファイル: {hdri_path.name}')))
    return result

def relink_hdri_world(context, root: Path) -> dict:
    result = {'relinked': False, 'path': '', 'notes': []}
    scene = getattr(context, 'scene', None)
    world = getattr(scene, 'world', None) if scene else None
    if world is None:
        result['notes'].append(tx(scene, 'No world', _lt('ワールドがありません')))
        return result
    if root is None:
        result['notes'].append(tx(scene, 'No search root', _lt('検索フォルダがありません')))
        return result
    root = Path(root)
    if not root.exists():
        result['notes'].append(tx(scene, f'Search root not found: {root}', _lt(f'検索フォルダが見つかりません: {root}')))
        return result
    current_strength = _background_strength(active_world_background_node(world))
    current_rotation = _mapping_z_rotation(active_world_mapping_node(world))
    state = {}  # guard: was unbound here (pre-existing); values are informational only
    state['strength'] = current_strength
    state['rotation'] = current_rotation
    image = active_world_image(world)
    desired_path = ''
    desired_name = ''
    if image is not None:
        desired_name = getattr(image, 'name', '') or ''
        try:
            desired_path = bpy.path.abspath(getattr(image, 'filepath', '') or '')
        except Exception:
            desired_path = str(getattr(image, 'filepath', '') or '')
    if not desired_path and scene is not None:
        desired_path = str(getattr(scene, 'sss_hdri_path', '') or '')
    lookup = core.index_files_by_name(root)
    candidates = []
    seed = desired_path or desired_name
    for key in core.texture_lookup_keys(seed):
        candidates.extend(lookup.get(key, []))
    if not candidates and desired_name:
        for key in core.texture_lookup_keys(desired_name):
            candidates.extend(lookup.get(key, []))
    best = core.best_texture_match(candidates, missing_path=desired_path, image_name=desired_name)
    if best is None:
        fallback_filter = Path(seed).stem if seed else ''
        fallback_candidates = collect_hdri_candidates(root, filter_text=fallback_filter)
        if not fallback_candidates and (not fallback_filter):
            fallback_candidates = collect_hdri_candidates(root)
        if fallback_candidates:
            best = fallback_candidates[0]
            result['notes'].append(tx(scene, f'Fallback HDRI candidate used: {best.name}', _lt(f'名前の一致が無いので近い候補を使いました: {best.name}')))
        else:
            result['notes'].append(tx(scene, 'No matching HDRI candidate was found', _lt('一致するHDRI候補が見つかりません')))
            return result
    if image is None:
        strength = float(getattr(scene, 'sss_hdri_strength', current_strength))
        rotation = float(getattr(scene, 'sss_hdri_rotation', current_rotation))
        built = build_hdri_world(context, best, strength=strength, rotation=rotation)
        result['relinked'] = built.get('loaded_image', False)
        result['path'] = str(best)
        result['notes'].extend(built.get('notes', []))
        return result
    try:
        image.filepath = str(best)
        image.reload()
    except Exception:
        try:
            replacement = bpy.data.images.load(str(best), check_existing=True)
            node = active_world_environment_node(world)
            if node is not None:
                node.image = replacement
        except Exception as exc:
            result['notes'].append(tx(scene, f'Failed to relink HDRI: {Path(best).name}', f'HDRIを再リンクできませんでした: {Path(best).name}'))
            return result
    try:
        world['sss_hdri_path'] = str(best)
    except Exception:
        pass
    try:
        scene.sss_hdri_path = str(best)
    except Exception:
        pass
    result['relinked'] = True
    result['path'] = str(best)
    return result
