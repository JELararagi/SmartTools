"""Scene material inventory helpers."""
from __future__ import annotations
from .translation import loc_text as _lt
from typing import Iterable
import time
try:
    import bpy
except Exception:
    bpy = None
from . import core
from .translation import tx
INVENTORY_SENTINEL = 'NO_SCENE_MATERIALS'
_INVENTORY_ENTRY_CACHE: dict[tuple, tuple[float, list[dict]]] = {}
_INVENTORY_ITEM_CACHE: dict[tuple, tuple[float, list[tuple]]] = {}

def _all_materials() -> list:
    if bpy is None:
        return []
    try:
        return list(getattr(bpy.data, 'materials', []) or [])
    except Exception:
        return []

def _scene_objects(scene=None) -> list:
    if bpy is None:
        return []
    if scene is not None:
        try:
            return list(getattr(scene, 'objects', []) or [])
        except Exception:
            pass
    try:
        return list(getattr(bpy.data, 'objects', []) or [])
    except Exception:
        return []

def _inventory_scope(scene=None) -> str:
    return str(getattr(scene, 'sss_inventory_scope', 'SCENE_USED') or 'SCENE_USED').upper()

def _inventory_sort(scene=None) -> str:
    return str(getattr(scene, 'sss_inventory_sort', 'USERS') or 'USERS').upper()

def _scene_pointer(scene) -> int:
    if scene is None:
        return 0
    try:
        pointer = int(scene.as_pointer())
        if pointer:
            return pointer
    except Exception:
        pass
    return id(scene)


def _inventory_cache_key(scene=None, query: str='') -> tuple:
    try:
        material_count = len(core.safe_data_collection('materials') or [])
    except Exception:
        material_count = 0
    try:
        object_count = len(getattr(scene, 'objects', []) or []) if scene is not None else len(core.safe_data_collection('objects') or [])
    except Exception:
        object_count = 0
    return (_scene_pointer(scene), str(query or getattr(scene, 'sss_inventory_search', '') or '').strip().lower(), _inventory_scope(scene), _inventory_sort(scene), material_count, object_count)


def inventory_identifier_items(scene=None) -> list[str]:
    """Return valid inventory identifiers for enum repair without full audit payloads.

    Full inventory rows include material audit summaries, missing-texture checks,
    and texture usage hints.  Dynamic enum repair only needs valid identifiers and
    a deterministic fallback; using this lightweight path keeps N-panel redraw
    repairs from scanning every material node tree during viewport navigation.
    """
    query_text = str(getattr(scene, 'sss_inventory_search', '') or '').strip().lower()
    sort_mode = _inventory_sort(scene)
    # Non-empty searches can match builder/family/tag/texture usage fields, and
    # MISSING sorting depends on the full audit payload.  Preserve those exact
    # semantics by delegating to the full inventory only for those cases.
    if query_text or sort_mode == 'MISSING':
        return [str(entry.get('name', '') or '') for entry in list_inventory_entries(scene=scene, query=query_text) if str(entry.get('name', '') or '')]
    scope = _inventory_scope(scene)
    objects = _scene_objects(scene)
    usage_map = core.material_usage_map(objects=objects)
    rows: list[tuple] = []
    for material in _all_materials():
        if material is None:
            continue
        name = str(getattr(material, 'name', '') or '').strip()
        if not name:
            continue
        usage = core.material_usage_counts(material, objects=objects, usage_map=usage_map)
        object_count = int(usage.get('objects', 0) or 0)
        slot_count = int(usage.get('slots', 0) or 0)
        managed = bool(material.get('sss_builder')) if hasattr(material, 'get') else False
        if scope == 'SCENE_USED' and object_count <= 0:
            continue
        if scope == 'MANAGED_ONLY' and (not managed):
            continue
        try:
            node_count = len(getattr(getattr(material, 'node_tree', None), 'nodes', []) or []) if getattr(material, 'use_nodes', False) else 0
        except Exception:
            node_count = 0
        rows.append((name, object_count, slot_count, node_count))
    if sort_mode == 'NAME':
        rows.sort(key=lambda item: core.library_name_key(item[0]))
    elif sort_mode == 'NODES':
        rows.sort(key=lambda item: (-item[3], -item[1], core.library_name_key(item[0])))
    else:
        rows.sort(key=lambda item: (-item[1], -item[2], core.library_name_key(item[0])))
    return [item[0] for item in rows]


def list_inventory_entries(scene=None, query: str='') -> list[dict]:
    query_text = str(query or getattr(scene, 'sss_inventory_search', '') or '').strip().lower()
    scope = _inventory_scope(scene)
    sort_mode = _inventory_sort(scene)
    cache_key = _inventory_cache_key(scene, query_text)
    now = time.monotonic()
    cached = _INVENTORY_ENTRY_CACHE.get(cache_key)
    if cached is not None and now - cached[0] < 0.75:
        # Cached rows must not hand out material references: a material deleted
        # (or undone) inside the window would raise ReferenceError in the caller.
        fresh = []
        for item in cached[1]:
            material = bpy.data.materials.get(str(item.get('name', '') or ''))
            if material is not None:
                fresh.append(dict(item, material=material))
        return fresh
    objects = _scene_objects(scene)
    usage_map = core.material_usage_map(objects=objects)
    entries: list[dict] = []
    for material in _all_materials():
        if material is None:
            continue
        name = str(getattr(material, 'name', '') or '').strip()
        if not name:
            continue
        usage = core.material_usage_counts(material, objects=objects, usage_map=usage_map)
        object_count = int(usage.get('objects', 0) or 0)
        slot_count = int(usage.get('slots', 0) or 0)
        managed = bool(material.get('sss_builder')) if hasattr(material, 'get') else False
        if scope == 'SCENE_USED' and object_count <= 0:
            continue
        if scope == 'MANAGED_ONLY' and (not managed):
            continue
        payload = core.material_compare_payload(material, objects=objects, usage=usage, usage_map=usage_map)
        entry = {'name': name, 'material': material, 'managed': managed, 'builder': str(payload.get('builder', '') or ''), 'family': str(payload.get('family', '') or ''), 'summary_en': str(payload.get('summary_en', '') or ''), 'summary_ja': str(payload.get('summary_ja', '') or ''), 'object_count': object_count, 'slot_count': slot_count, 'missing_textures': int(payload.get('missing_textures', 0) or 0), 'node_count': int(payload.get('node_count', 0) or 0), 'asset': bool(payload.get('asset', False)), 'protected': bool(payload.get('protected', False)), 'tags': list(payload.get('tags') or []), 'texture_usages': dict(payload.get('texture_usages') or {})}
        hay = ' '.join([entry['name'], entry['builder'], entry['family'], entry['summary_en'], entry['summary_ja'], ' '.join(entry['tags']), ' '.join(sorted(entry['texture_usages'].keys()))]).lower()
        if query_text and query_text not in hay:
            continue
        entries.append(entry)
    if sort_mode == 'NAME':
        entries.sort(key=lambda item: core.library_name_key(item.get('name', '')))
    elif sort_mode == 'MISSING':
        entries.sort(key=lambda item: (-item.get('missing_textures', 0), -item.get('object_count', 0), core.library_name_key(item.get('name', ''))))
    elif sort_mode == 'NODES':
        entries.sort(key=lambda item: (-item.get('node_count', 0), -item.get('object_count', 0), core.library_name_key(item.get('name', ''))))
    else:
        entries.sort(key=lambda item: (-item.get('object_count', 0), -item.get('slot_count', 0), core.library_name_key(item.get('name', ''))))
    _INVENTORY_ENTRY_CACHE[cache_key] = (now, [dict(item) for item in entries])
    if len(_INVENTORY_ENTRY_CACHE) > 128:
        for old_key in list(_INVENTORY_ENTRY_CACHE.keys())[:32]:
            _INVENTORY_ENTRY_CACHE.pop(old_key, None)
    return entries

def inventory_items(scene=None):
    query = getattr(scene, 'sss_inventory_search', '') if scene is not None else ''
    cache_key = ('items', _inventory_cache_key(scene, query))
    now = time.monotonic()
    cached = _INVENTORY_ITEM_CACHE.get(cache_key)
    if cached is not None and now - cached[0] < 0.75:
        return list(cached[1])
    items = []
    for entry in list_inventory_entries(scene=scene, query=query):
        flags = []
        if entry.get('managed'):
            flags.append('Managed')
        if entry.get('asset'):
            flags.append('Asset')
        if entry.get('protected'):
            flags.append('Protected')
        if entry.get('missing_textures'):
            flags.append(f"Missing {entry['missing_textures']}")
        flags_text = ', '.join(flags) or '-'
        en = f"Objects: {entry['object_count']} | Slots: {entry['slot_count']} | Nodes: {entry['node_count']}\nBuilder: {entry.get('builder') or '-'} | Family: {entry.get('family') or '-'}\nStatus: {flags_text}"
        ja = _lt(f"使用オブジェクト: {entry['object_count']} | スロット: {entry['slot_count']} | ノード: {entry['node_count']}\nビルダー: {entry.get('builder') or '-'} | 分類: {entry.get('family') or '-'}\n状態: {flags_text}")
        if scene is None:
            label = entry['name']
            desc = tx(None, en, ja)
        else:
            label = entry['name']
            desc = tx(scene, en, ja)
        items.append((entry['name'], label, desc))
    if not items:
        items.append((INVENTORY_SENTINEL, tx(scene, 'No Scene Materials', _lt('対象材質なし')), tx(scene, 'No materials matched the current inventory filters.', _lt('現在のインデックス条件に一致する材質はありません。'))))
    _INVENTORY_ITEM_CACHE[cache_key] = (now, list(items))
    if len(_INVENTORY_ITEM_CACHE) > 128:
        for old_key in list(_INVENTORY_ITEM_CACHE.keys())[:32]:
            _INVENTORY_ITEM_CACHE.pop(old_key, None)
    return items

def find_inventory_entry(name: str, scene=None):
    key = core.library_name_key(name)
    if not key:
        return None
    for entry in list_inventory_entries(scene=scene, query=''):
        if core.library_name_key(entry.get('name', '')) == key:
            return entry
    return None

def inventory_summary(scene, entry: dict | None) -> str:
    if not entry:
        return tx(scene, 'Select a material from the Scene Material Index to inspect or reuse it.', _lt('シーン材質インデックス から材質を選ぶと、状態確認や再利用の導線が表示されます。'))
    flags = []
    if entry.get('managed'):
        flags.append(tx(scene, 'Managed', _lt('管理中')))
    if entry.get('asset'):
        flags.append(tx(scene, 'Asset', _lt('アセット')))
    if entry.get('protected'):
        flags.append(tx(scene, 'Protected', _lt('保護')))
    if entry.get('missing_textures'):
        flags.append(tx(scene, f"Missing {entry['missing_textures']}", _lt(f"欠損 {entry['missing_textures']}")))
    flags_text = ', '.join(flags) or tx(scene, 'No special flags', _lt('特記事項なし'))
    usage_keys = ', '.join(sorted((entry.get('texture_usages') or {}).keys())[:6]) or '-'
    en = f"{entry.get('name', '-')}: objects={entry.get('object_count', 0)}, slots={entry.get('slot_count', 0)}, nodes={entry.get('node_count', 0)}. Builder={entry.get('builder') or '-'}, family={entry.get('family') or '-'}. Usage hints: {usage_keys}. Status: {flags_text}."
    ja = _lt(f"{entry.get('name', '-')}: 使用オブジェクト={entry.get('object_count', 0)}, スロット={entry.get('slot_count', 0)}, ノード={entry.get('node_count', 0)}。ビルダー={entry.get('builder') or '-'}, 分類={entry.get('family') or '-'}。用途ヒント: {usage_keys}。状態: {flags_text}。")
    return tx(scene, en, ja)
