"""Texture inference, colorspace fixes, safe auto-wiring, and texture-set import helpers."""
from __future__ import annotations
from .translation import loc_text as _lt
from pathlib import Path
import os
import re
import bpy
from . import core
KEYWORD_USAGE_MAP = {'packed_orm': ['occlusionroughnessmetallic', 'occlusion_roughness_metallic', 'ao_roughness_metallic', 'ao_rough_metal', 'arm', 'orm'], 'packed_rma': ['roughnessmetallicao', 'roughness_metallic_ao', 'rough_metal_ao', 'rma'], 'packed_mra': ['metallicroughnessao', 'metallic_roughness_ao', 'metal_rough_ao', 'mra'], 'base_color': ['basecolor', 'base_color', 'albedo', 'diffuse', 'color', 'colour'], 'roughness': ['roughness', 'rough'], 'glossiness': ['glossiness', 'gloss', 'smoothness', 'smooth'], 'metallic': ['metallic', 'metalness', 'metal'], 'specular': ['specular', 'spec', 'reflectivity', 'speclevel', 'specularlevel'], 'normal': ['normal', 'nrm'], 'height': ['height', 'displacement', 'disp', 'bump'], 'occlusion': ['ao', 'occlusion', 'ambientocclusion', 'cavityao'], 'emissive': ['emissive', 'emission', 'emit', 'glow'], 'alpha': ['alpha', 'opacity', 'mask', 'transparency', 'translucencymask'], 'transmission': ['transmission', 'trans', 'refraction', 'refract'], 'coat': ['coat', 'clearcoat', 'clear_coat', 'clearcoatweight', 'coatweight'], 'coat_roughness': ['coatroughness', 'coat_roughness', 'clearcoatroughness', 'clear_coat_roughness'], 'sheen': ['sheen', 'fuzz', 'sheenweight'], 'subsurface': ['subsurface', 'sss', 'subsurfaceweight', 'scatter'], 'thickness': ['thickness', 'thick'], 'anisotropy': ['anisotropy', 'anisotropic', 'aniso'], 'curvature': ['curvature', 'curv'], 'cavity': ['cavity'], 'world_normal': ['worldnormal', 'world_normal', 'wsnormal', 'worldspace_normal', 'normalws'], 'position': ['position', 'pos', 'worldposition', 'world_position', 'wsposition']}
COMPOUND_TOKEN_MAP = {'basecolor': ['base', 'color'], 'basecolour': ['base', 'colour'], 'ambientocclusion': ['ambient', 'occlusion'], 'roughnessmetallicao': ['roughness', 'metallic', 'ao'], 'roughmetalao': ['rough', 'metal', 'ao'], 'metallicroughnessao': ['metallic', 'roughness', 'ao'], 'metalroughao': ['metal', 'rough', 'ao'], 'occlusionroughnessmetallic': ['occlusion', 'roughness', 'metallic'], 'aoroughnessmetallic': ['ao', 'roughness', 'metallic'], 'aoroughmetal': ['ao', 'rough', 'metal'], 'normalgl': ['normal', 'gl'], 'normaldx': ['normal', 'dx'], 'specularlevel': ['specular', 'level'], 'speclevel': ['spec', 'level'], 'clearcoat': ['clear', 'coat'], 'clearcoatweight': ['clear', 'coat', 'weight'], 'coatweight': ['coat', 'weight'], 'clearcoatroughness': ['clear', 'coat', 'roughness'], 'coatroughness': ['coat', 'roughness'], 'subsurfaceweight': ['subsurface', 'weight'], 'sheenweight': ['sheen', 'weight'], 'translucencymask': ['translucency', 'mask'], 'worldnormal': ['world', 'normal'], 'worldspace_normal': ['worldspace', 'normal'], 'worldposition': ['world', 'position'], 'world_position': ['world', 'position']}
USAGE_TOKEN_SETS = {'base_color': {'base', 'color', 'colour', 'basecolor', 'basecolour', 'albedo', 'diffuse'}, 'roughness': {'roughness', 'rough'}, 'glossiness': {'glossiness', 'gloss', 'smoothness', 'smooth'}, 'metallic': {'metallic', 'metalness', 'metal'}, 'specular': {'specular', 'spec', 'reflectivity', 'speclevel', 'specularlevel'}, 'normal': {'normal', 'nrm', 'normalgl', 'normaldx'}, 'height': {'height', 'displacement', 'disp', 'bump'}, 'occlusion': {'ao', 'occlusion', 'ambient', 'ambientocclusion', 'cavityao'}, 'emissive': {'emissive', 'emission', 'emit', 'glow'}, 'alpha': {'alpha', 'opacity', 'mask', 'transparency', 'translucencymask'}, 'transmission': {'transmission', 'trans', 'refraction', 'refract'}, 'coat': {'coat', 'clearcoat', 'clear', 'coatweight', 'clearcoatweight'}, 'coat_roughness': {'coatroughness', 'coat', 'roughness', 'clearcoatroughness', 'clear'}, 'sheen': {'sheen', 'fuzz', 'sheenweight'}, 'subsurface': {'subsurface', 'sss', 'subsurfaceweight', 'scatter'}, 'thickness': {'thickness', 'thick'}, 'anisotropy': {'anisotropy', 'anisotropic', 'aniso'}, 'curvature': {'curvature', 'curv'}, 'cavity': {'cavity'}, 'world_normal': {'worldnormal', 'world_normal', 'wsnormal', 'normalws', 'worldspace_normal'}, 'position': {'position', 'pos', 'worldposition', 'world_position', 'wsposition'}}
PACKED_GROUP_STRIP = {'packed_orm': {'orm', 'arm', 'ao', 'occlusion', 'ambient', 'rough', 'roughness', 'metal', 'metallic', 'metalness'}, 'packed_rma': {'rma', 'ao', 'occlusion', 'ambient', 'rough', 'roughness', 'metal', 'metallic', 'metalness'}, 'packed_mra': {'mra', 'ao', 'occlusion', 'ambient', 'rough', 'roughness', 'metal', 'metallic', 'metalness'}}
COMPOUND_SPLIT_RE = re.compile('(?<=[a-z0-9])(?=[A-Z])')
NON_ALNUM_RE = re.compile('[^A-Za-z0-9]+')
UDIM_TOKEN_RE = re.compile('(?i)^1\\d{3}$')
UV_TILE_TOKEN_RE = re.compile('(?i)^[uv]\\d+$')
USAGE_HINT_KEY = 'sss_usage_hint'
NODE_USAGE_HINT_KEY = 'sss_usage_hint'
DIRECT_DATA_USAGES = {'roughness', 'glossiness', 'metallic', 'specular', 'normal', 'height', 'occlusion', 'packed_orm', 'packed_rma', 'packed_mra', 'transmission', 'coat', 'coat_roughness', 'sheen', 'subsurface', 'thickness', 'anisotropy', 'curvature', 'cavity', 'world_normal', 'position'}
DATA_MAP_USAGES = set(DIRECT_DATA_USAGES)
ALPHA_USAGES = {'alpha'}
DIRECT_WIRE_USAGES = {'base_color', 'roughness', 'metallic', 'specular', 'normal', 'emissive', 'alpha', 'transmission', 'coat', 'coat_roughness', 'sheen', 'subsurface', 'anisotropy'}
ADVISORY_USAGES = {'thickness', 'curvature', 'cavity', 'world_normal', 'position'}
PRINCIPLED_INPUT_MAP = {'base_color': ('Base Color',), 'roughness': ('Roughness',), 'metallic': ('Metallic',), 'specular': ('Specular IOR Level', 'Specular', 'Specular Level'), 'emission_color': ('Emission Color', 'Emission'), 'emission_strength': ('Emission Strength',), 'alpha': ('Alpha',), 'normal': ('Normal',), 'transmission': ('Transmission Weight', 'Transmission'), 'coat': ('Coat Weight', 'Clearcoat'), 'coat_roughness': ('Coat Roughness', 'Clearcoat Roughness'), 'sheen': ('Sheen Weight', 'Sheen'), 'subsurface': ('Subsurface Weight', 'Subsurface'), 'anisotropy': ('Anisotropic', 'Specular Anisotropy'), 'height': ('Displacement',)}

def _haystack_from_node(node) -> str:
    image = getattr(node, 'image', None)
    parts = [getattr(node, 'name', '') or '', getattr(node, 'label', '') or '', getattr(image, 'name', '') or '', getattr(image, 'filepath', '') or '']
    return ' '.join((part for part in parts if part)).lower()

def _source_name_text(text: str) -> str:
    value = str(text or '')
    if not value:
        return ''
    try:
        return Path(value).name
    except Exception:
        return value

def _source_stem_text(text: str) -> str:
    value = _source_name_text(text)
    if not value:
        return ''
    try:
        stem = Path(value).stem
        return stem or value
    except Exception:
        return value.rsplit('.', 1)[0] if '.' in value else value

def _compact_usage_text(text: str) -> str:
    return re.sub('[^a-z0-9]+', '', _source_stem_text(text).lower())

def _texture_name_tokens(text: str) -> list[str]:
    value = _source_stem_text(text)
    value = value.replace('<UDIM>', ' ').replace('<udim>', ' ')
    value = COMPOUND_SPLIT_RE.sub(' ', value)
    value = NON_ALNUM_RE.sub(' ', value)
    tokens: list[str] = []
    for raw in value.lower().split():
        if not raw or UDIM_TOKEN_RE.fullmatch(raw) or UV_TILE_TOKEN_RE.fullmatch(raw):
            continue
        expanded = COMPOUND_TOKEN_MAP.get(raw)
        if expanded:
            tokens.extend(expanded)
        else:
            tokens.append(raw)
    return tokens

def _usage_hint_from_owner(owner) -> str:
    if owner is None:
        return ''
    try:
        value = str(owner.get(USAGE_HINT_KEY, '') or '').strip().lower()
    except Exception:
        value = ''
    return value if value in KEYWORD_USAGE_MAP or value in {'base_color', 'roughness', 'glossiness', 'metallic', 'specular', 'normal', 'height', 'occlusion', 'emissive', 'alpha', 'transmission', 'coat', 'coat_roughness', 'sheen', 'subsurface', 'thickness', 'anisotropy', 'curvature', 'cavity', 'world_normal', 'position'} else ''

def _set_usage_hint(owner, usage: str) -> None:
    if owner is None or not usage or usage == 'unknown':
        return
    try:
        owner[USAGE_HINT_KEY] = usage
    except Exception:
        pass

def _has_usage_token(tokens: list[str], usage: str) -> bool:
    token_set = USAGE_TOKEN_SETS.get(usage, set())
    if not token_set:
        return False
    compact = ''.join(tokens)
    return any((token in token_set for token in tokens)) or compact in token_set

def _semantic_positions(tokens: list[str]) -> dict[str, int]:
    positions: dict[str, int] = {}
    for index, token in enumerate(tokens):
        for usage, token_set in USAGE_TOKEN_SETS.items():
            if token in token_set and usage not in positions:
                positions[usage] = index
    if 'occlusion' not in positions and 'ambient' in tokens and ('occlusion' in tokens):
        positions['occlusion'] = min(tokens.index('ambient'), tokens.index('occlusion'))
    return positions

def _guess_packed_usage(tokens: list[str]) -> str:
    if not tokens:
        return ''
    token_list = list(tokens)
    token_set = set(token_list)
    if 'orm' in token_set or 'arm' in token_set:
        return 'packed_orm'
    if 'rma' in token_set:
        return 'packed_rma'
    if 'mra' in token_set:
        return 'packed_mra'
    if token_list and token_list[-1] == 'arm' and (len(token_list) <= 3):
        return 'packed_orm'
    positions = _semantic_positions(token_list)
    if {'occlusion', 'roughness', 'metallic'}.issubset(positions):
        order = tuple((usage for usage, _idx in sorted(((usage, positions[usage]) for usage in ('occlusion', 'roughness', 'metallic')), key=lambda item: item[1])))
        if order == ('occlusion', 'roughness', 'metallic'):
            return 'packed_orm'
        if order == ('roughness', 'metallic', 'occlusion'):
            return 'packed_rma'
        if order == ('metallic', 'roughness', 'occlusion'):
            return 'packed_mra'
    return ''

def guess_usage_from_text(text: str) -> str:
    compact = _compact_usage_text(text)
    tokens = _texture_name_tokens(text)
    token_set = set(tokens)
    packed = _guess_packed_usage(tokens)
    if packed:
        return packed
    if _has_usage_token(tokens, 'base_color') or compact in {'basecolor', 'basecolour', 'albedo', 'diffuse'}:
        return 'base_color'
    if compact in {'worldnormal', 'world_normal', 'wsnormal', 'worldspace_normal', 'normalws'} or (('world' in token_set or 'worldspace' in token_set) and 'normal' in token_set):
        return 'world_normal'
    if _has_usage_token(tokens, 'normal') or compact in {'normal', 'normalgl', 'normaldx', 'nrm'}:
        return 'normal'
    if compact in {'coatroughness', 'clearcoatroughness', 'clearcoatrough', 'coat_roughness', 'clear_coat_roughness'} or ('roughness' in token_set and ('coat' in token_set or 'clearcoat' in token_set or 'clear' in token_set)):
        return 'coat_roughness'
    if compact in {'coat', 'clearcoat', 'coatweight', 'clearcoatweight'} or (('coat' in token_set or 'clearcoat' in token_set or 'clear' in token_set) and 'roughness' not in token_set):
        return 'coat'
    if _has_usage_token(tokens, 'roughness') or compact == 'roughness':
        return 'roughness'
    if _has_usage_token(tokens, 'glossiness') or compact in {'glossiness', 'smoothness'}:
        return 'glossiness'
    if _has_usage_token(tokens, 'metallic') or compact in {'metallic', 'metalness'}:
        return 'metallic'
    if _has_usage_token(tokens, 'specular') or compact in {'specular', 'spec', 'reflectivity', 'speclevel', 'specularlevel'}:
        return 'specular'
    if _has_usage_token(tokens, 'occlusion') or compact in {'ao', 'occlusion', 'ambientocclusion', 'cavityao'}:
        return 'occlusion'
    if _has_usage_token(tokens, 'height') or compact in {'height', 'displacement', 'disp', 'bump'}:
        return 'height'
    if _has_usage_token(tokens, 'emissive') or compact in {'emissive', 'emission', 'emit', 'glow'}:
        return 'emissive'
    if _has_usage_token(tokens, 'alpha') or compact in {'alpha', 'opacity', 'mask', 'transparency', 'translucencymask'}:
        return 'alpha'
    if _has_usage_token(tokens, 'transmission') or compact in {'transmission', 'trans', 'refraction', 'refract'}:
        return 'transmission'
    if _has_usage_token(tokens, 'sheen') or compact in {'sheen', 'fuzz', 'sheenweight'}:
        return 'sheen'
    if _has_usage_token(tokens, 'subsurface') or compact in {'subsurface', 'sss', 'subsurfaceweight', 'scatter'}:
        return 'subsurface'
    if _has_usage_token(tokens, 'thickness') or compact in {'thickness', 'thick'}:
        return 'thickness'
    if _has_usage_token(tokens, 'anisotropy') or compact in {'anisotropy', 'anisotropic', 'aniso'}:
        return 'anisotropy'
    if _has_usage_token(tokens, 'curvature') or compact in {'curvature', 'curv'}:
        return 'curvature'
    if _has_usage_token(tokens, 'cavity') or compact == 'cavity':
        return 'cavity'
    if _has_usage_token(tokens, 'position') or compact in {'position', 'pos', 'worldposition', 'world_position', 'wsposition'} or (('world' in token_set or 'object' in token_set) and 'position' in token_set):
        return 'position'
    return 'unknown'

def _group_key_for_path(path: Path) -> str:
    usage = guess_usage_from_text(path.name)
    tokens = _texture_name_tokens(path.stem)
    strip = set(USAGE_TOKEN_SETS.get(usage, set())) | PACKED_GROUP_STRIP.get(usage, set()) | {'gl', 'dx', 'map', 'tex', 'texture'}
    kept = [token for token in tokens if token not in strip]
    if kept:
        return '_'.join(kept)
    parent_name = core.normalize_texture_token(getattr(path.parent, 'name', '') or '')
    if parent_name:
        return parent_name
    return 'texture_set'

def _iter_files_under_root(root: Path):
    root = Path(root)
    if not root.exists():
        return
    try:
        if root.is_file():
            yield root
            return
    except Exception:
        return
    stack = [root]
    while stack:
        current = stack.pop()
        entries = []
        try:
            entries = list(os.scandir(current))
        except Exception:
            continue
        dirs: list[Path] = []
        for entry in entries:
            try:
                if entry.is_dir(follow_symlinks=False):
                    dirs.append(Path(entry.path))
                    continue
                if entry.is_file(follow_symlinks=False):
                    yield Path(entry.path)
            except Exception:
                continue
        dirs.sort(key=lambda item: str(item).lower(), reverse=True)
        stack.extend(dirs)


def _recognized_texture_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for file_path in _iter_files_under_root(root):
        if file_path.suffix.lower() not in core.TEXTURE_EXTENSIONS:
            continue
        if guess_usage_from_text(file_path.name) == 'unknown':
            continue
        files.append(file_path)
    return files

def _rank_texture_candidate(path: Path, usage: str) -> tuple:
    tokens = _texture_name_tokens(path.stem)
    token_set = set(tokens)
    compact = _compact_usage_text(path.stem)
    exact = 1
    if usage == 'packed_orm':
        if 'orm' in token_set:
            exact = 0
        elif 'arm' in token_set:
            exact = 1
        else:
            exact = 2
    elif usage == 'packed_rma':
        exact = 0 if 'rma' in token_set else 1
    elif usage == 'packed_mra':
        exact = 0 if 'mra' in token_set else 1
    elif usage == 'normal':
        if 'normal' in token_set:
            exact = 0
        elif compact in {'normalgl', 'normaldx', 'nrm'} or 'nrm' in token_set:
            exact = 1
        else:
            exact = 2
    else:
        usage_tokens = USAGE_TOKEN_SETS.get(usage, set())
        exact = 0 if any((token in token_set for token in usage_tokens)) else 1
    return (exact, len(path.name), str(path).lower())

def _reduce_duplicate_usages(files: list[Path]) -> list[Path]:
    by_usage: dict[str, list[Path]] = {}
    for file_path in files:
        usage = guess_usage_from_text(file_path.name)
        by_usage.setdefault(usage, []).append(file_path)
    reduced: list[Path] = []
    for usage, bucket in by_usage.items():
        reduced.append(sorted(bucket, key=lambda path: _rank_texture_candidate(path, usage))[0])
    usage_order = {key: index for index, key in enumerate(KEYWORD_USAGE_MAP.keys())}
    reduced.sort(key=lambda path: (usage_order.get(guess_usage_from_text(path.name), 999), path.name.lower()))
    return reduced

def _group_score(group_key: str, files: list[Path], filter_text: str='', name_hint: str='') -> tuple:
    usages = {guess_usage_from_text(path.name) for path in files}
    score = len(usages) * 100 - max(0, len(files) - len(usages)) * 3
    haystack = ' '.join(core.texture_lookup_keys(group_key) + [group_key.lower()])
    for hint in (filter_text, name_hint):
        token = core.normalize_texture_token(hint or '')
        if not token:
            continue
        if token == group_key or token in haystack or group_key in token:
            score += 500
        else:
            score += sum((25 for part in token.split('_') if part and part in haystack))
    return (score, len(usages), -len(files), -len(group_key), group_key)

def _relative_texture_folder(root: Path, file_path: Path) -> str:
    try:
        rel = file_path.parent.resolve().relative_to(root.resolve())
        rel_text = str(rel).replace('\\', '/')
    except Exception:
        rel_text = str(getattr(file_path.parent, 'name', '') or '')
    return rel_text if rel_text and rel_text != '.' else '.'

def _texture_group_label(display_name: str, relative_folder: str) -> str:
    if not relative_folder or relative_folder == '.':
        return display_name
    return f'{display_name} [{relative_folder}]'

def _texture_group_haystack(entry: dict) -> str:
    parts = [str(entry.get('display_name', '') or ''), str(entry.get('group_key', '') or ''), str(entry.get('relative_folder', '') or ''), str(entry.get('label', '') or ''), str(entry.get('folder_name', '') or '')]
    parts.extend((Path(path).name for path in entry.get('all_files') or []))
    return ' '.join(core.texture_lookup_keys(' '.join(parts)))

def _entry_matches_filter(entry: dict, filter_text: str='') -> bool:
    token = core.normalize_texture_token(filter_text or '')
    if not token:
        return True
    return token in _texture_group_haystack(entry)

def _collect_texture_group_entries(root: Path, filter_text: str='', name_hint: str='', files: list[Path] | None=None) -> list[dict]:
    files = list(files or _recognized_texture_files(root))
    if not files:
        return []
    grouped: dict[tuple[str, str], list[Path]] = {}
    for file_path in files:
        relative_folder = _relative_texture_folder(root, file_path)
        group_key = _group_key_for_path(file_path)
        grouped.setdefault((relative_folder, group_key), []).append(file_path)
    entries: list[dict] = []
    for (relative_folder, group_key), bucket in grouped.items():
        folder_name = Path(relative_folder).name if relative_folder and relative_folder != '.' else Path(root).name
        display_name = group_key or folder_name or 'TextureSet'
        reduced = _reduce_duplicate_usages(bucket)
        usage_counts: dict[str, int] = {}
        for file_path in reduced:
            usage = guess_usage_from_text(file_path.name)
            usage_counts[usage] = usage_counts.get(usage, 0) + 1
        score = _group_score(display_name, bucket, filter_text=filter_text, name_hint=name_hint or folder_name)[0]
        entry = {'relative_folder': relative_folder, 'folder_name': folder_name, 'group_key': group_key, 'display_name': display_name, 'label': _texture_group_label(display_name, relative_folder), 'recognized_files': len(bucket), 'selected_files': len(reduced), 'usages': len(usage_counts), 'usage_counts': usage_counts, 'score': score, 'files': reduced, 'all_files': bucket}
        entries.append(entry)
    entries.sort(key=lambda item: (item['score'], item['usages'], item['selected_files'], item['label']), reverse=True)
    return entries

def _select_texture_group_entries(root: Path, filter_text: str='', mode: str='AUTO_GROUP', name_hint: str='', entries: list[dict] | None=None) -> dict:
    entries = list(entries or _collect_texture_group_entries(root, filter_text=filter_text, name_hint=name_hint))
    token = core.normalize_texture_token(filter_text or '')
    matched_entries = [entry for entry in entries if _entry_matches_filter(entry, token)] if token else list(entries)
    notes: list[str] = []
    mode_name = (mode or 'AUTO_GROUP').upper()
    if token and (not matched_entries):
        return {'entries': entries, 'matched_entries': [], 'selected_entries': [], 'selected_files': [], 'mode': mode_name, 'notes': [_lt('JP: 絞込文字列に一致するテクスチャグループがありません。 / EN: No texture groups matched the current filter.')], 'selection_spans_groups': False}
    selected_entries: list[dict]
    if mode_name == 'AUTO_GROUP':
        selected_entries = matched_entries[:1]
    elif mode_name == 'FILTER_ONLY':
        if not token and len(entries) > 1:
            notes.append(_lt('JP: 絞込未指定のため、別アセット混在を避ける安全動作として最も整合する1グループだけを選びました。 / EN: No filter was supplied, so the safest single coherent group was chosen to avoid mixing unrelated assets.'))
        elif len(matched_entries) > 1:
            notes.append(_lt('JP: 絞込に複数グループが一致したため、最も整合する1グループだけを選びました。 / EN: The filter matched multiple groups, so the safest best-matching group was selected.'))
        selected_entries = matched_entries[:1] if matched_entries else entries[:1]
    elif mode_name == 'ALL_MATCHING':
        if not token and len(entries) > 1:
            notes.append(_lt('JP: 絞込未指定で複数グループが見つかったため、誤混在防止のため最も整合する1グループだけを選びました。 / EN: Multiple groups were found with no filter, so the safest single coherent group was selected to prevent cross-asset mixing.'))
            selected_entries = entries[:1]
        else:
            selected_entries = matched_entries
            if len(selected_entries) > 1:
                notes.append(_lt('JP: 選択結果が複数グループにまたがっています。安全優先なら 自動グループ を使うか、絞込文字列を追加してください。 / EN: The selection spans multiple groups. For safer results, use Auto Group or add a more specific filter.'))
    else:
        selected_entries = matched_entries[:1] if matched_entries else entries[:1]
    selected_files: list[Path] = []
    for entry in selected_entries:
        for file_path in entry.get('files') or []:
            if file_path not in selected_files:
                selected_files.append(file_path)
    return {'entries': entries, 'matched_entries': matched_entries, 'selected_entries': selected_entries, 'selected_files': _reduce_duplicate_usages(selected_files), 'mode': mode_name, 'notes': notes, 'selection_spans_groups': len(selected_entries) > 1}

def collect_texture_set_files(root: Path, filter_text: str='', mode: str='AUTO_GROUP', name_hint: str='') -> list[Path]:
    selection = _select_texture_group_entries(root, filter_text=filter_text, mode=mode, name_hint=name_hint)
    return list(selection.get('selected_files') or [])

def scan_texture_set(root: Path, filter_text: str='', mode: str='AUTO_GROUP', name_hint: str='') -> dict:
    report = {'recognized_total': 0, 'selected_total': 0, 'matched_group_total': 0, 'selected_group': '', 'selected_folder': '', 'selected_groups': [], 'selection_spans_groups': False, 'mode': (mode or 'AUTO_GROUP').upper(), 'selected': [], 'usage_counts': {}, 'group_candidates': [], 'notes': []}
    if root is None or not Path(root).exists():
        report['notes'].append(_lt('The texture folder was not found.', 'テクスチャフォルダーが見つかりません。'))
        return report
    root = Path(root)
    recognized_files = _recognized_texture_files(root)
    report['recognized_total'] = len(recognized_files)
    if not recognized_files:
        report['notes'].append(_lt('No textures were recognized.', '認識できるテクスチャがありません。'))
        return report
    entries = _collect_texture_group_entries(root, filter_text=filter_text, name_hint=name_hint, files=recognized_files)
    if not entries:
        report['notes'].append(_lt('No textures were recognized.', '認識できるテクスチャがありません。'))
        return report
    report['group_candidates'] = [{'group': entry.get('group_key', ''), 'folder': entry.get('relative_folder', '.'), 'label': entry.get('label', ''), 'files': entry.get('selected_files', 0), 'usages': entry.get('usages', 0), 'score': entry.get('score', 0)} for entry in entries[:6]]
    selection = _select_texture_group_entries(root, filter_text=filter_text, mode=mode, name_hint=name_hint, entries=entries)
    selected_entries = list(selection.get('selected_entries') or [])
    selected = list(selection.get('selected_files') or [])
    report['matched_group_total'] = len(selection.get('matched_entries') or [])
    report['selected_groups'] = [entry.get('label', '') for entry in selected_entries if entry.get('label')]
    report['selection_spans_groups'] = bool(selection.get('selection_spans_groups'))
    if selected_entries:
        first_entry = selected_entries[0]
        report['selected_group'] = str(first_entry.get('label', '') or '')
        report['selected_folder'] = str(first_entry.get('relative_folder', '') or '')
    report['selected'] = [{'name': file_path.name, 'usage': guess_usage_from_text(file_path.name), 'path': str(file_path)} for file_path in selected]
    report['selected_total'] = len(selected)
    usage_counts: dict[str, int] = {}
    for item in report['selected']:
        usage = item['usage']
        usage_counts[usage] = usage_counts.get(usage, 0) + 1
    report['usage_counts'] = usage_counts
    report['notes'].extend(selection.get('notes') or [])
    if not selected:
        report['notes'].append(_lt('The selection has no usable files.', '選択の中に使えるファイルがありません。'))
    return report

def scan_texture_library(root: Path, filter_text: str='') -> dict:
    report = {'recognized_total': 0, 'group_total': 0, 'groups': [], 'notes': []}
    if root is None or not Path(root).exists():
        report['notes'].append(_lt('The texture folder was not found.', 'テクスチャフォルダーが見つかりません。'))
        return report
    root = Path(root)
    files = _recognized_texture_files(root)
    report['recognized_total'] = len(files)
    if not files:
        report['notes'].append(_lt('No textures were recognized.', '認識できるテクスチャがありません。'))
        return report
    entries = _collect_texture_group_entries(root, filter_text=filter_text, name_hint=root.name, files=files)
    filter_token = core.normalize_texture_token(filter_text or '')
    if filter_token:
        entries = [entry for entry in entries if _entry_matches_filter(entry, filter_token)]
    report['groups'] = entries
    report['group_total'] = len(entries)
    if not entries:
        report['notes'].append(_lt('No texture groups match the filter.', '絞り込みに一致するテクスチャグループがありません。'))
    return report

def _unique_paths(paths: list[Path]) -> list[Path]:
    unique: list[Path] = []
    seen: set[str] = set()
    for file_path in paths:
        try:
            key = str(file_path.resolve())
        except Exception:
            key = str(file_path)
        if key in seen:
            continue
        seen.add(key)
        unique.append(file_path)
    return unique

def resolve_manifest_texture_files(texture_entries, base_dir: Path | None=None, search_roots: list[Path] | None=None) -> dict:
    result = {'files': [], 'resolved': [], 'missing': [], 'notes': [], 'usage_hints': {}}
    if not isinstance(texture_entries, list) or not texture_entries:
        result['notes'].append(_lt('The manifest has no textures.', 'マニフェストにテクスチャがありません。'))
        return result
    base_dirs: list[Path] = []
    for candidate in [base_dir] + list(search_roots or []):
        if candidate is None:
            continue
        try:
            path_obj = Path(candidate)
        except Exception:
            continue
        if path_obj not in base_dirs:
            base_dirs.append(path_obj)
    indexes: dict[Path, dict[str, list[Path]]] = {}
    files: list[Path] = []
    for entry in texture_entries:
        if not isinstance(entry, dict):
            continue
        raw_path = str(entry.get('filepath', '') or '').strip()
        image_name = str(entry.get('name', '') or '').strip()
        declared_usage = str(entry.get('usage') or entry.get('usage_hint') or '').strip().lower()
        resolved = None
        direct = Path(raw_path) if raw_path else None
        if direct is not None:
            try:
                if direct.exists() and direct.is_file():
                    resolved = direct
            except Exception:
                resolved = None
        if resolved is None and direct is not None and raw_path and (not direct.is_absolute()):
            for folder in base_dirs:
                try:
                    candidate = (folder / direct).resolve()
                except Exception:
                    candidate = folder / direct
                try:
                    if candidate.exists() and candidate.is_file():
                        resolved = candidate
                        break
                except Exception:
                    continue
        if resolved is None:
            lookup_terms = []
            for value in (raw_path, image_name, bpy.path.basename(raw_path) if raw_path else ''):
                for key in core.texture_lookup_keys(value):
                    if key and key not in lookup_terms:
                        lookup_terms.append(key)
            for folder in base_dirs:
                index = indexes.setdefault(folder, core.index_files_by_name(folder))
                candidates: list[Path] = []
                for key in lookup_terms:
                    candidates.extend(index.get(key, []))
                resolved = core.best_texture_match(_unique_paths(candidates), missing_path=raw_path, image_name=image_name)
                if resolved is not None:
                    break
        usage = declared_usage or guess_usage_from_text(raw_path or image_name)
        if resolved is None:
            result['missing'].append({'name': image_name or bpy.path.basename(raw_path) or '<unnamed>', 'filepath': raw_path, 'usage': usage})
            continue
        if resolved not in files:
            files.append(resolved)
        resolved_key = str(resolved.resolve())
        if usage and usage != 'unknown':
            result['usage_hints'][resolved_key] = usage
        result['resolved'].append({'name': image_name or resolved.name, 'filepath': str(resolved), 'usage': usage})
    result['files'] = _unique_paths(files)
    if result['resolved']:
        result['notes'].append(_lt(f"Manifest textures found: {len(result['resolved'])}", f"見つかったマニフェストのテクスチャ: {len(result['resolved'])}"))
    if result['missing']:
        result['notes'].append(_lt(f"Manifest textures missing: {len(result['missing'])}", f"見つからないマニフェストのテクスチャ: {len(result['missing'])}"))
    return result

def build_material_from_manifest_textures(material, texture_entries, base_dir: Path | None=None, search_roots: list[Path] | None=None, force: bool=True, group_name: str='Manifest') -> dict:
    resolved = resolve_manifest_texture_files(texture_entries, base_dir=base_dir, search_roots=search_roots)
    result = {'files': 0, 'loaded_images': 0, 'created_nodes': 0, 'new_links': 0, 'color_fixes': 0, 'alpha_fixes': 0, 'resolved_texture_files': len(resolved.get('resolved') or []), 'missing_textures': len(resolved.get('missing') or []), 'notes': list(resolved.get('notes') or [])}
    files = list(resolved.get('files') or [])
    if not files:
        result['notes'].append(_lt('None of the manifest textures were found.', 'マニフェストのテクスチャが 1 つも見つかりません。'))
        return result
    built = build_material_from_texture_files(material, files, force=force, group_name=group_name, usage_hints=resolved.get('usage_hints') or {})
    built['resolved_texture_files'] = result['resolved_texture_files']
    built['missing_textures'] = result['missing_textures']
    built['notes'] = result['notes'] + built.get('notes', [])
    return built

def guess_image_usage(node) -> str:
    hinted = _usage_hint_from_owner(node)
    if hinted:
        return hinted
    image = getattr(node, 'image', None)
    hinted = _usage_hint_from_owner(image)
    if hinted:
        return hinted
    return guess_usage_from_text(_haystack_from_node(node))

def image_path(image) -> str:
    try:
        return str(Path(bpy.path.abspath(getattr(image, 'filepath', '') or '')).resolve())
    except Exception:
        return str(getattr(image, 'filepath', '') or '')

def is_data_colorspace(image) -> bool:
    current = str(getattr(getattr(image, 'colorspace_settings', None), 'name', '') or '').strip().lower()
    return current in {'non-color', 'non color', 'raw'}

def set_noncolor_if_needed(image) -> bool:
    if image is None or is_data_colorspace(image):
        return False
    try:
        image.colorspace_settings.name = 'Non-Color'
        return True
    except Exception:
        return False

def _principled_input(node, key: str):
    return core.socket_by_name(node.inputs, *PRINCIPLED_INPUT_MAP.get(key, (key,)))

def material_uses_alpha(material) -> bool:
    if not material or not material.use_nodes or (not material.node_tree):
        return False
    bsdf = core.first_principled_on_output_path(material)
    if bsdf is not None:
        alpha_sock = _principled_input(bsdf, 'alpha')
        if alpha_sock is not None:
            try:
                if alpha_sock.is_linked:
                    return True
            except Exception:
                pass
            try:
                if float(alpha_sock.default_value) < 0.999:
                    return True
            except Exception:
                pass
    for node in core.iter_image_nodes(material):
        if guess_image_usage(node) in ALPHA_USAGES:
            return True
    return False

def material_transparency_state(material):
    state = {'configured': False, 'mode': ''}
    for attr in ('surface_render_method', 'blend_method'):
        if not hasattr(material, attr):
            continue
        try:
            value = str(getattr(material, attr, '') or '')
        except Exception:
            value = ''
        if value:
            state['mode'] = value
            if value.upper() not in {'OPAQUE', 'NONE'}:
                state['configured'] = True
                return state
    return state

def configure_material_transparency(material):
    applied = []
    if material is None:
        return applied
    candidates = {'surface_render_method': ['DITHERED', 'BLENDED', 'BLEND', 'HASHED'], 'blend_method': ['BLEND', 'HASHED', 'CLIP'], 'shadow_method': ['HASHED', 'CLIP', 'NONE']}
    for attr, values in candidates.items():
        if not hasattr(material, attr):
            continue
        before = str(getattr(material, attr, '') or '')
        for value in values:
            try:
                setattr(material, attr, value)
                after = str(getattr(material, attr, '') or '')
                if after == value:
                    if before != after:
                        applied.append(f'{attr}={after}')
                    break
            except Exception:
                continue
    for attr, value in (('use_backface_culling', False), ('show_transparent_back', False)):
        if not hasattr(material, attr):
            continue
        try:
            before = bool(getattr(material, attr))
            setattr(material, attr, value)
            after = bool(getattr(material, attr))
            if before != after:
                applied.append(f'{attr}={after}')
        except Exception:
            pass
    return applied

def standardize_material_images(material):
    result = {'checked': 0, 'fixed': 0, 'details': []}
    if not material or not material.use_nodes or (not material.node_tree):
        return result
    for node in core.iter_image_nodes(material):
        image = getattr(node, 'image', None)
        if image is None:
            continue
        usage = guess_image_usage(node)
        result['checked'] += 1
        if usage in DATA_MAP_USAGES:
            changed = set_noncolor_if_needed(image)
            if changed:
                result['fixed'] += 1
                result['details'].append(f'{image.name}: {usage} -> Non-Color')
    if material_uses_alpha(material):
        applied = configure_material_transparency(material)
        if applied:
            result['details'].append('transparency: ' + ', '.join(applied))
    return result

def texture_audit_findings(material) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []
    if not material or not material.use_nodes or (not material.node_tree):
        return findings
    advisory_found: list[str] = []
    for node in core.iter_image_nodes(material):
        image = getattr(node, 'image', None)
        if image is None:
            continue
        usage = guess_image_usage(node)
        if usage in DATA_MAP_USAGES and (not is_data_colorspace(image)):
            findings.append({'en': f'{node.name}: {usage} texture is likely a data map but is not set to Non-Color.', 'ja': _lt(f'{node.name}: {usage} テクスチャはデータマップの可能性がありますが、Non-Color になっていません。')})
        if usage in ADVISORY_USAGES and usage not in advisory_found:
            advisory_found.append(usage)
    if advisory_found:
        findings.append({'en': 'Advisory maps were detected and intentionally left for manual lookdev review: ' + ', '.join(sorted(advisory_found)) + '.', 'ja': _lt('補助的なマップを検出したため、意図的に自動接続せず手動ルック調整向けとして残しています: ') + '、'.join(sorted(advisory_found)) + '。'})
    if material_uses_alpha(material):
        state = material_transparency_state(material)
        if not state['configured']:
            findings.append({'en': 'Material appears to use alpha/transparency but the material render method still looks opaque.', 'ja': _lt('アルファ/透明を使っている可能性がありますが、マテリアルの描画方式が不透明のままです。')})
    return findings

def _new_node(nt, bl_idname, x, y, label=None):
    node = nt.nodes.new(bl_idname)
    node.location = (x, y)
    if label:
        node.label = label
        try:
            node.name = label
        except Exception:
            pass
    return node

def _new_node_any(nt, bl_ids, x, y, label=None):
    last_error = None
    for bl_id in bl_ids:
        try:
            return _new_node(nt, bl_id, x, y, label=label)
        except Exception as exc:
            last_error = exc
    raise RuntimeError(f'Unable to create node from {bl_ids}: {last_error}')

def _safe_socket(collection, *names):
    return core.socket_by_name(collection, *names)

def _disconnect_input_links(nt, socket):
    for link_ in list(getattr(socket, 'links', [])):
        try:
            nt.links.remove(link_)
        except Exception:
            pass

def _socket_is_linked(socket) -> bool:
    try:
        return bool(socket and socket.is_linked)
    except Exception:
        return False

def _connect_input(nt, out_socket, in_socket, force=False):
    if out_socket is None or in_socket is None:
        return False
    if _socket_is_linked(in_socket) and (not force):
        return False
    if force:
        _disconnect_input_links(nt, in_socket)
    try:
        nt.links.new(out_socket, in_socket)
        return True
    except Exception:
        return False

def _find_node_by_type(nt, bl_idname: str, label: str=''):
    for node in nt.nodes:
        if node.bl_idname != bl_idname:
            continue
        if label and getattr(node, 'label', '') != label and (getattr(node, 'name', '') != label):
            continue
        return node
    return None

def _create_principled_chain(nt):
    out = core.ensure_output_node(nt)
    bsdf = core.first_principled_on_output_path(nt)
    created = 0
    if bsdf is None:
        bsdf = _new_node(nt, 'ShaderNodeBsdfPrincipled', -200, 80, 'Principled BSDF')
        created += 1
    surface = _safe_socket(out.inputs, 'Surface') if out is not None else None
    if surface is not None and (not _socket_is_linked(surface)):
        if _connect_input(nt, _safe_socket(bsdf.outputs, 'BSDF'), surface):
            created += 1
    return (out, bsdf, created)

def _packed_channel_plan(usage: str) -> dict[str, str]:
    if usage == 'packed_rma':
        return {'roughness': 'R', 'metallic': 'G', 'occlusion': 'B'}
    if usage == 'packed_mra':
        return {'metallic': 'R', 'roughness': 'G', 'occlusion': 'B'}
    return {'occlusion': 'R', 'roughness': 'G', 'metallic': 'B'}

def _socket_from_channel(node, channel: str):
    if channel == 'R':
        return _safe_socket(node.outputs, 'R', 'Red')
    if channel == 'G':
        return _safe_socket(node.outputs, 'G', 'Green')
    return _safe_socket(node.outputs, 'B', 'Blue')

def _source_socket_from_image(node):
    return _safe_socket(node.outputs, 'Color') or _safe_socket(node.outputs, 'Alpha')

def _ensure_mix_multiply(nt, label: str, x: int, y: int):
    node = _find_node_by_type(nt, 'ShaderNodeMixRGB', label) or _find_node_by_type(nt, 'ShaderNodeMix', label)
    if node is None:
        node = _new_node_any(nt, ['ShaderNodeMixRGB', 'ShaderNodeMix'], x, y, label)
        try:
            node.blend_type = 'MULTIPLY'
        except Exception:
            pass
        try:
            fac = _safe_socket(node.inputs, 'Factor', 'Fac')
            if fac is not None:
                fac.default_value = 1.0
        except Exception:
            pass
    return node

def _ensure_invert(nt, label: str, x: int, y: int):
    node = _find_node_by_type(nt, 'ShaderNodeInvert', label)
    if node is None:
        node = _new_node(nt, 'ShaderNodeInvert', x, y, label)
        try:
            fac = _safe_socket(node.inputs, 'Fac')
            if fac is not None:
                fac.default_value = 1.0
        except Exception:
            pass
    return node

def _ensure_separate_rgb(nt, label: str, x: int, y: int):
    node = _find_node_by_type(nt, 'ShaderNodeSeparateColor', label) or _find_node_by_type(nt, 'ShaderNodeSeparateRGB', label)
    if node is None:
        node = _new_node_any(nt, ['ShaderNodeSeparateColor', 'ShaderNodeSeparateRGB'], x, y, label)
    return node

def _connect_base_with_ao(nt, base_node, ao_source, base_socket, force=False):
    if base_node is None or base_socket is None:
        return (0, 0)
    if ao_source is None and (not _socket_is_linked(base_socket) or force):
        if _connect_input(nt, _safe_socket(base_node.outputs, 'Color'), base_socket, force=force):
            return (0, 1)
        return (0, 0)
    if ao_source is None:
        return (0, 0)
    mix = _ensure_mix_multiply(nt, 'SSS AO Multiply', -420, 300)
    created_nodes = 0
    if mix and getattr(mix, 'label', '') == 'SSS AO Multiply':
        try:
            if not getattr(mix.inputs[1], 'is_linked', False) and (not getattr(mix.inputs[2], 'is_linked', False)):
                created_nodes = 1
        except Exception:
            created_nodes = 1
    new_links = 0
    if _connect_input(nt, _safe_socket(base_node.outputs, 'Color'), _safe_socket(mix.inputs, 'Color1', 'A'), force=True):
        new_links += 1
    if _connect_input(nt, ao_source, _safe_socket(mix.inputs, 'Color2', 'B'), force=True):
        new_links += 1
    if _connect_input(nt, _safe_socket(mix.outputs, 'Color', 'Result'), base_socket, force=force):
        new_links += 1
    return (created_nodes, new_links)

def build_material_from_texture_files(material, files: list[Path], force: bool=True, group_name: str='', usage_hints: dict[str, str] | None=None) -> dict:
    result = {'files': 0, 'loaded_images': 0, 'created_nodes': 0, 'new_links': 0, 'color_fixes': 0, 'alpha_fixes': 0, 'notes': []}
    usable_files = [Path(file_path) for file_path in files or [] if file_path and Path(file_path).exists()]
    if not usable_files:
        result['notes'].append(_lt('No texture set files were recognized.', '認識できるテクスチャセットのファイルがありません。'))
        return result
    usage_hints = {str(Path(key).resolve()) if key else str(key): str(value or '').strip().lower() for key, value in (usage_hints or {}).items() if value}
    if group_name:
        result['notes'].append(_lt(f'Selected group: {group_name}', f'選択したグループ: {group_name}'))
    material.use_nodes = True
    nt = material.node_tree
    nt.nodes.clear()
    texcoord = _new_node_any(nt, ['ShaderNodeTexCoord'], -1180, 0, 'Texture Coordinate')
    mapping = _new_node_any(nt, ['ShaderNodeMapping'], -940, 0, 'Texture Mapping')
    result['created_nodes'] += 2
    _connect_input(nt, _safe_socket(texcoord.outputs, 'UV', 'Generated'), _safe_socket(mapping.inputs, 'Vector'), force=True)
    _out, _bsdf, created = _create_principled_chain(nt)
    result['created_nodes'] += created
    recognized_usages: list[str] = []
    y = 420
    for file_path in usable_files:
        try:
            image = bpy.data.images.load(str(file_path), check_existing=True)
            result['loaded_images'] += 1
        except Exception as exc:
            result['notes'].append(_lt(f'Failed to load image: {file_path.name}', f'画像を読み込めませんでした: {file_path.name}'))
            continue
        label = file_path.stem
        node = _new_node(nt, 'ShaderNodeTexImage', -640, y, label)
        node.image = image
        result['created_nodes'] += 1
        result['files'] += 1
        if _connect_input(nt, _safe_socket(mapping.outputs, 'Vector'), _safe_socket(node.inputs, 'Vector'), force=True):
            result['new_links'] += 1
        resolved_key = str(file_path.resolve())
        usage = usage_hints.get(resolved_key) or guess_usage_from_text(file_path.name)
        if usage and usage != 'unknown':
            recognized_usages.append(usage)
            _set_usage_hint(image, usage)
            _set_usage_hint(node, usage)
        if usage in DATA_MAP_USAGES and set_noncolor_if_needed(image):
            result['color_fixes'] += 1
        y -= 180
    if recognized_usages:
        usage_count = len(dict.fromkeys(recognized_usages))
        result['notes'].append(_lt(f'Recognized map types: {usage_count}', f'認識したマップの種類: {usage_count}'))
    auto = autowire_material_textures(material, force=force)
    for key in ('created_nodes', 'new_links', 'color_fixes', 'alpha_fixes'):
        result[key] += auto.get(key, 0)
    result['notes'].extend(auto.get('notes', []))
    return result

def build_material_from_texture_set(material, root: Path, filter_text: str='', force: bool=True, mode: str='AUTO_GROUP', name_hint: str='') -> dict:
    result = {'files': 0, 'loaded_images': 0, 'created_nodes': 0, 'new_links': 0, 'color_fixes': 0, 'alpha_fixes': 0, 'notes': []}
    if root is None or not root.exists():
        result['notes'].append(_lt('The texture folder was not found.', 'テクスチャフォルダーが見つかりません。'))
        return result
    selection = _select_texture_group_entries(root, filter_text=filter_text, mode=mode, name_hint=name_hint)
    files = list(selection.get('selected_files') or [])
    if not files:
        result['notes'].extend(selection.get('notes') or [])
        result['notes'].append(_lt('No texture set files were recognized.', '認識できるテクスチャセットのファイルがありません。'))
        return result
    result['notes'].extend(selection.get('notes') or [])
    selected_entries = list(selection.get('selected_entries') or [])
    group_name = ''
    if len(selected_entries) == 1:
        group_name = str(selected_entries[0].get('label', '') or '')
    elif selected_entries:
        labels = [str(entry.get('label', '') or '') for entry in selected_entries if entry.get('label')]
        group_name = ', '.join(labels[:3])
    built = build_material_from_texture_files(material, files, force=force, group_name=group_name)
    built['notes'] = result['notes'] + built.get('notes', [])
    return built

def autowire_material_textures(material, force=False):
    result = {'created_nodes': 0, 'new_links': 0, 'color_fixes': 0, 'alpha_fixes': 0, 'notes': []}
    if material is None:
        result['notes'].append(_lt('No material.', 'マテリアルがありません。'))
        return result
    material.use_nodes = True
    nt = material.node_tree
    if nt is None:
        result['notes'].append(_lt('The material has no node tree.', 'マテリアルにノードツリーがありません。'))
        return result
    _out, bsdf, created = _create_principled_chain(nt)
    result['created_nodes'] += created
    by_usage: dict[str, list] = {}
    for node in core.iter_image_nodes(material):
        image = getattr(node, 'image', None)
        if image is None:
            continue
        usage = guess_image_usage(node)
        by_usage.setdefault(usage, []).append(node)
        if usage in DATA_MAP_USAGES and set_noncolor_if_needed(image):
            result['color_fixes'] += 1
    base_socket = _principled_input(bsdf, 'base_color')
    rough_socket = _principled_input(bsdf, 'roughness')
    metal_socket = _principled_input(bsdf, 'metallic')
    spec_socket = _principled_input(bsdf, 'specular')
    emissive_socket = _principled_input(bsdf, 'emission_color')
    alpha_socket = _principled_input(bsdf, 'alpha')
    normal_socket = _principled_input(bsdf, 'normal')
    base_node = by_usage.get('base_color', [None])[0]
    ao_node = by_usage.get('occlusion', [None])[0]
    packed_node = by_usage.get('packed_orm', [None])[0] or by_usage.get('packed_rma', [None])[0] or by_usage.get('packed_mra', [None])[0]
    packed_usage = guess_image_usage(packed_node) if packed_node is not None else ''
    packed_outputs = {}
    if packed_node is not None:
        had_separate = _find_node_by_type(nt, 'ShaderNodeSeparateColor', 'SSS Packed Split') or _find_node_by_type(nt, 'ShaderNodeSeparateRGB', 'SSS Packed Split')
        separate = _ensure_separate_rgb(nt, 'SSS Packed Split', -420, 120)
        if _connect_input(nt, _safe_socket(packed_node.outputs, 'Color'), _safe_socket(separate.inputs, 'Image', 'Color'), force=force):
            result['new_links'] += 1
        if had_separate is None:
            result['created_nodes'] += 1
        plan = _packed_channel_plan(packed_usage)
        packed_outputs = {key: _socket_from_channel(separate, channel) for key, channel in plan.items()}
        result['notes'].append(_lt(f'Packed map: {str(packed_usage).upper()}', f'パックマップ: {str(packed_usage).upper()}'))
    ao_source = None
    if ao_node is not None:
        ao_source = _source_socket_from_image(ao_node)
    elif packed_outputs.get('occlusion') is not None:
        ao_source = packed_outputs.get('occlusion')
    created_nodes, new_links = _connect_base_with_ao(nt, base_node, ao_source, base_socket, force=force)
    result['created_nodes'] += created_nodes
    result['new_links'] += new_links
    rough_node = by_usage.get('roughness', [None])[0]
    gloss_node = by_usage.get('glossiness', [None])[0]
    rough_source = None
    if rough_node is not None:
        rough_source = _source_socket_from_image(rough_node)
    elif packed_outputs.get('roughness') is not None:
        rough_source = packed_outputs.get('roughness')
    if gloss_node is not None and rough_socket is not None and (not _socket_is_linked(rough_socket) or force):
        had_invert = _find_node_by_type(nt, 'ShaderNodeInvert', 'SSS Gloss to Roughness')
        invert = _ensure_invert(nt, 'SSS Gloss to Roughness', -420, 20)
        if had_invert is None:
            result['created_nodes'] += 1
        if _connect_input(nt, _source_socket_from_image(gloss_node), _safe_socket(invert.inputs, 'Color'), force=force):
            result['new_links'] += 1
        if _connect_input(nt, _safe_socket(invert.outputs, 'Color'), rough_socket, force=force):
            result['new_links'] += 1
        result['notes'].append(_lt('Glossiness was converted to roughness.', '光沢度を粗さへ変換しました。'))
    elif rough_source is not None and rough_socket is not None and (not _socket_is_linked(rough_socket) or force):
        if _connect_input(nt, rough_source, rough_socket, force=force):
            result['new_links'] += 1
    metal_node = by_usage.get('metallic', [None])[0]
    metal_source = None
    if metal_node is not None:
        metal_source = _source_socket_from_image(metal_node)
    elif packed_outputs.get('metallic') is not None:
        metal_source = packed_outputs.get('metallic')
    if metal_source is not None and metal_socket is not None and (not _socket_is_linked(metal_socket) or force):
        if _connect_input(nt, metal_source, metal_socket, force=force):
            result['new_links'] += 1
    spec_node = by_usage.get('specular', [None])[0]
    if spec_node is not None and spec_socket is not None and (not _socket_is_linked(spec_socket) or force):
        if _connect_input(nt, _source_socket_from_image(spec_node), spec_socket, force=force):
            result['new_links'] += 1
            result['notes'].append(_lt('The specular map was connected.', 'スペキュラーマップを接続しました。'))
    emit_node = by_usage.get('emissive', [None])[0]
    if emit_node is not None and emissive_socket is not None and (not _socket_is_linked(emissive_socket) or force):
        if _connect_input(nt, _safe_socket(emit_node.outputs, 'Color'), emissive_socket, force=force):
            result['new_links'] += 1
        strength_socket = _principled_input(bsdf, 'emission_strength')
        if strength_socket is not None:
            try:
                if float(strength_socket.default_value) <= 0.0:
                    strength_socket.default_value = 1.0
            except Exception:
                pass
    alpha_node = by_usage.get('alpha', [None])[0]
    if alpha_node is not None and alpha_socket is not None and (not _socket_is_linked(alpha_socket) or force):
        source = _safe_socket(alpha_node.outputs, 'Alpha') or _safe_socket(alpha_node.outputs, 'Color')
        if _connect_input(nt, source, alpha_socket, force=force):
            result['new_links'] += 1
        applied = configure_material_transparency(material)
        if applied:
            result['alpha_fixes'] += 1
            result['notes'].append(_lt('Transparency settings were applied.', '透過の設定を適用しました。'))
    direct_scalar_targets = (('transmission', 'transmission', 'transmission workflow map connected'), ('coat', 'coat', 'coat map connected'), ('coat_roughness', 'coat_roughness', 'coat roughness map connected'), ('sheen', 'sheen', 'sheen map connected'), ('subsurface', 'subsurface', 'subsurface map connected'), ('anisotropy', 'anisotropy', 'anisotropy map connected'))
    for usage, key, note in direct_scalar_targets:
        node = by_usage.get(usage, [None])[0]
        socket = _principled_input(bsdf, key)
        if node is None or socket is None:
            continue
        if not _socket_is_linked(socket) or force:
            if _connect_input(nt, _source_socket_from_image(node), socket, force=force):
                result['new_links'] += 1
                result['notes'].append(note)
    normal_node = by_usage.get('normal', [None])[0]
    height_node = by_usage.get('height', [None])[0]
    normal_map = _find_node_by_type(nt, 'ShaderNodeNormalMap', 'Normal Map') if normal_node else None
    bump = _find_node_by_type(nt, 'ShaderNodeBump', 'Height Bump') if height_node else None
    if normal_node is not None and normal_map is None:
        normal_map = _new_node(nt, 'ShaderNodeNormalMap', -440, -260, 'Normal Map')
        result['created_nodes'] += 1
    if height_node is not None and bump is None:
        bump = _new_node(nt, 'ShaderNodeBump', -220, -430, 'Height Bump')
        result['created_nodes'] += 1
    if normal_node is not None and normal_map is not None:
        if _connect_input(nt, _safe_socket(normal_node.outputs, 'Color'), _safe_socket(normal_map.inputs, 'Color'), force=force):
            result['new_links'] += 1
    if height_node is not None and bump is not None:
        if _connect_input(nt, _safe_socket(height_node.outputs, 'Color'), _safe_socket(bump.inputs, 'Height'), force=force):
            result['new_links'] += 1
    if normal_socket is not None:
        if normal_map is not None and bump is not None:
            if _connect_input(nt, _safe_socket(normal_map.outputs, 'Normal'), _safe_socket(bump.inputs, 'Normal'), force=force):
                result['new_links'] += 1
            if _connect_input(nt, _safe_socket(bump.outputs, 'Normal'), normal_socket, force=force):
                result['new_links'] += 1
        elif normal_map is not None and (not _socket_is_linked(normal_socket) or force):
            if _connect_input(nt, _safe_socket(normal_map.outputs, 'Normal'), normal_socket, force=force):
                result['new_links'] += 1
        elif bump is not None and (not _socket_is_linked(normal_socket) or force):
            if _connect_input(nt, _safe_socket(bump.outputs, 'Normal'), normal_socket, force=force):
                result['new_links'] += 1
    advisory_found = [usage for usage in sorted(ADVISORY_USAGES) if by_usage.get(usage)]
    if advisory_found:
        result['notes'].append(_lt(f'Helper maps found and left unconnected: {len(advisory_found)}', f'接続せずに残した補助マップ: {len(advisory_found)}'))
    recognized = [usage for usage in sorted(by_usage) if usage and usage != 'unknown']
    if recognized:
        result['notes'].append(_lt(f'Image map types detected: {len(recognized)}', f'検出した画像マップの種類: {len(recognized)}'))
    if material_uses_alpha(material):
        applied = configure_material_transparency(material)
        if applied:
            result['alpha_fixes'] += 1
            result['notes'].append(_lt('Transparency settings were applied.', '透過の設定を適用しました。'))
    return result
