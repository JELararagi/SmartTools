"""Properties, enums, and persistent N-panel settings."""
from .translation import loc_text as _lt
from .translation import ja_text as _ja_text
import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, StringProperty
from .translation import rna_text_context_prop as _rna_prop
BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, StringProperty = map(_rna_prop, (BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, StringProperty))
from bpy.app.handlers import persistent
import importlib
import json
import sys
import zlib
from pathlib import Path
from . import storage


class _LazyModule:
    __slots__ = ("_module_name", "_module")

    def __init__(self, module_name: str):
        self._module_name = str(module_name or '').strip()
        self._module = None

    def _load(self):
        module = self._module
        if module is None:
            module = importlib.import_module(f'.{self._module_name}', __package__)
            self._module = module
        return module

    def __getattr__(self, item):
        return getattr(self._load(), item)


def _lazy_module(module_name: str):
    return _LazyModule(module_name)

catalog = _lazy_module('catalog')
core = _lazy_module('core')
data = _lazy_module('data')
environment = _lazy_module('environment')
finder = _lazy_module('finder')
inventory = _lazy_module('inventory')
layers = _lazy_module('layers')
rules = _lazy_module('rules')
_preferences = _lazy_module('preferences')
from .translation import tx, locale_is_japanese

_SCENE_DEFAULTS_FLAG = '_sss_defaults_initialized_v5103'
_SCENE_PERSISTENCE_FLAG = '_sss_persistent_settings_applied_v1'
_PERSISTENCE_APPLYING = False
_SCENE_SETTINGS_CACHE: dict[str, object] | None = None
_SCENE_LAST_REPORT_CACHE: dict[int, str] = {}
_SCENE_DEFAULTS_INITIALIZED: set[int] = set()
_SCENE_PERSISTENCE_APPLIED: set[int] = set()
_SCENE_SESSION_CACHE_LIMIT = 128
_ENUM_ITEM_CACHE: dict[tuple, list[tuple]] = {}
_DESCRIPTION_CACHE: dict[tuple, str] = {}
_SCENE_MSGBUS_OWNER = object()


def _enum_locale_key() -> str:
    return 'ja' if locale_is_japanese() else 'en'


def _cached_enum_items(key: tuple, builder):
    cached = _ENUM_ITEM_CACHE.get(key)
    if cached is not None:
        return cached
    value = list(builder())
    _ENUM_ITEM_CACHE[key] = value
    if len(_ENUM_ITEM_CACHE) > 512:
        # Keep the cache bounded while preserving the latest UI states.
        for old_key in list(_ENUM_ITEM_CACHE.keys())[:128]:
            _ENUM_ITEM_CACHE.pop(old_key, None)
    return value


def clear_enum_item_cache() -> None:
    _ENUM_ITEM_CACHE.clear()
    _DESCRIPTION_CACHE.clear()

_PERSISTENT_SCENE_PROPS = ('sss_ui_section', 'sss_workspace_recipe', 'sss_show_advanced', 'sss_feature_group', 'sss_feature_panel', 'sss_preset_family', 'sss_preset_genre', 'sss_preset_search', 'sss_preset_name', 'sss_pbr_preset_family', 'sss_pbr_preset_genre', 'sss_pbr_preset_name', 'sss_material_name', 'sss_target_material_name', 'sss_custom_preset_name', 'sss_compare_source_material_name', 'sss_replace_scope', 'sss_inventory_search', 'sss_inventory_scope', 'sss_inventory_sort', 'sss_inventory_pick', 'sss_texture_search_root', 'sss_texture_set_filter', 'sss_texture_import_mode', 'sss_allow_multi_group_texture_build', 'sss_texture_batch_limit', 'sss_texture_scope', 'sss_mark_asset', 'sss_assign_selected', 'sss_assign_mode', 'sss_material_target_slot_index', 'sss_non_destructive', 'sss_use_fake_user', 'sss_auto_audit_after_build', 'sss_auto_layout_after_build', 'sss_prune_after_build', 'sss_texture_force_rewire', 'sss_layer_preset', 'sss_layer_mask_mode', 'sss_layer_strength', 'sss_layer_noise_scale', 'sss_layer_mask_contrast', 'sss_layer_recipe_name', 'sss_layer_recipe_pick', 'sss_layer_recipe_library_mode', 'sss_catalog_entry_name', 'sss_catalog_tags', 'sss_catalog_search', 'sss_catalog_pick', 'sss_catalog_library_mode', 'sss_asset_search_query', 'sss_asset_search_pick', 'sss_node_query', 'sss_node_pick', 'sss_photo_source', 'sss_photo_output_dir', 'sss_photo_max_size', 'sss_photo_normal_strength', 'sss_photo_detail_strength', 'sss_npr_material_name', 'sss_npr_zone_count', 'sss_npr_base_color', 'sss_npr_zone2_color', 'sss_npr_zone3_color', 'sss_npr_zone4_color', 'sss_npr_threshold_1', 'sss_npr_threshold_2', 'sss_npr_threshold_3', 'sss_npr_shadow_smooth', 'sss_npr_alpha', 'sss_npr_highlight_color', 'sss_npr_highlight_level', 'sss_npr_highlight_size', 'sss_npr_highlight_smooth', 'sss_npr_reflection_color', 'sss_npr_reflection_strength', 'sss_npr_reflection_roughness', 'sss_npr_rim_color', 'sss_npr_rim_width', 'sss_npr_rim_strength', 'sss_npr_detail_scale', 'sss_npr_detail_normal', 'sss_npr_hatch_enable', 'sss_npr_hatch_color', 'sss_npr_hatch_scale', 'sss_npr_hatch_strength', 'sss_npr_hatch_softness', 'sss_npr_hatch_angle', 'sss_npr_hatch_cross_enable', 'sss_npr_hatch_cross_angle', 'sss_npr_hatch_cross_strength', 'sss_npr_halftone_enable', 'sss_npr_halftone_color', 'sss_npr_halftone_scale', 'sss_npr_halftone_strength', 'sss_npr_halftone_threshold', 'sss_npr_halftone_softness', 'sss_npr_halftone_rotation', 'sss_npr_paper_tint', 'sss_npr_paper_scale', 'sss_npr_paper_strength', 'sss_hdri_path', 'sss_hdri_strength', 'sss_hdri_rotation', 'sss_hdri_library_root', 'sss_hdri_search', 'sss_hdri_pick', 'sss_cleanup_recursive', 'sss_batch_doctor_scope', 'sss_batch_doctor_filter', 'sss_batch_doctor_limit', 'sss_batch_doctor_relink_missing', 'sss_quick_action_search', 'sss_quick_action', 'sss_scene_variant_name', 'sss_scene_variant_pick', 'sss_custom_library_mode', 'sss_scene_variant_library_mode', 'sss_rule_name', 'sss_rule_search', 'sss_rule_pick', 'sss_rule_object_pattern', 'sss_rule_collection_pattern', 'sss_rule_current_material_pattern', 'sss_rule_use_regex', 'sss_rule_scope', 'sss_rule_library_mode')


def _settings_path() -> Path | None:
    try:
        return storage.suite_settings_path(create=True)
    except Exception:
        return None


def _legacy_settings_path() -> Path | None:
    try:
        return storage.settings_file('smart_shader_suite_npanel_scene_settings.json', create=False)
    except Exception:
        return None


def _read_saved_scene_settings() -> dict[str, object]:
    try:
        data = storage.read_suite_section('scene_settings', {})
        if isinstance(data, dict) and data:
            return data
    except Exception:
        pass
    path = _legacy_settings_path()
    if path is None or not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _json_value(value):
    if isinstance(value, bytes):
        try:
            return value.decode('utf-8', errors='replace')
        except Exception:
            return repr(value)
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    try:
        if isinstance(value, (tuple, list)):
            return [_json_value(item) for item in value]
    except Exception:
        pass
    try:
        return list(value)
    except Exception:
        try:
            return str(value)
        except Exception:
            return None


def _scene_rna_property(scene, name: str):
    if scene is None or not name:
        return None
    try:
        props = getattr(getattr(scene, 'bl_rna', None), 'properties', None)
    except Exception:
        props = None
    if props is None:
        return None
    try:
        return props.get(name)
    except Exception:
        pass
    try:
        return props[name]
    except Exception:
        return None


def _scene_has_rna_property(scene, name: str) -> bool:
    return _scene_rna_property(scene, name) is not None


def _scene_property_is_enum(scene, name: str) -> bool:
    prop = _scene_rna_property(scene, name)
    try:
        return str(getattr(prop, 'type', '') or '') == 'ENUM'
    except Exception:
        return False




def _safe_scene_id_get(scene, name: str, default=None):
    if scene is None or not name:
        return default
    try:
        getter = getattr(scene, 'get', None)
        if callable(getter):
            return getter(name, default)
    except Exception:
        pass
    try:
        return scene[name]
    except Exception:
        return default


def _enum_text(value, default: str = '') -> str:
    if value is None:
        return str(default or '').strip()
    if isinstance(value, bytes):
        try:
            text = value.decode('utf-8', errors='ignore')
        except Exception:
            text = ''
        return str(text or default or '').strip()
    try:
        return str(value).strip()
    except Exception:
        return str(default or '').strip()


def _legacy_enum_fallback(prop_name: str) -> str:
    name = str(prop_name or '').strip()
    try:
        if name == 'sss_node_pick':
            return str(finder.NODE_PICK_SENTINEL)
        if name == 'sss_inventory_pick':
            return str(inventory.INVENTORY_SENTINEL)
        if name == 'sss_asset_search_pick':
            return str(finder.ASSET_SEARCH_SENTINEL)
        if name == 'sss_hdri_pick':
            return str(environment.HDRI_SEARCH_SENTINEL)
        if name == 'sss_rule_pick':
            return str(rules.ASSIGN_RULE_SENTINEL)
        if name == 'sss_catalog_pick':
            return str(catalog.CATALOG_SENTINEL)
    except Exception:
        pass
    return {
        'sss_preset_family': 'PBR',
        'sss_preset_genre': 'ALL',
        'sss_preset_name': 'UNIVERSAL_PBR',
        'sss_pbr_preset_family': 'PBR',
        'sss_pbr_preset_genre': 'ALL',
        'sss_pbr_preset_name': 'UNIVERSAL_PBR',
        'sss_workspace_recipe': 'BUILD_PRESET',
        'sss_feature_group': 'BUILD',
        'sss_feature_panel': 'BUILD_APPLY',
        'sss_layer_preset': 'EDGE_WEAR_LAYER',
        'sss_layer_mask_mode': 'AUTO',
        'sss_quick_action': 'QUICK_FIX',
        'sss_texture_import_mode': 'AUTO_GROUP',
        'sss_texture_scope': 'ACTIVE',
        'sss_assign_mode': 'ACTIVE_SLOT',
        'sss_replace_scope': 'SELECTED',
        'sss_rule_scope': 'SELECTED',
        'sss_custom_library_mode': 'MERGE',
        'sss_scene_variant_library_mode': 'MERGE',
        'sss_rule_library_mode': 'MERGE',
        'sss_layer_recipe_pick': 'NO_LAYER_RECIPES',
        'sss_scene_variant_pick': 'NO_SCENE_VARIANTS',
    }.get(name, '')


def _set_scene_id_value(scene, prop_name: str, value) -> bool:
    if scene is None or not prop_name:
        return False
    try:
        scene[str(prop_name)] = value
        return True
    except Exception:
        return False


def _repair_legacy_scene_enum_values(scene=None, *, require_rna: bool = False) -> bool:
    """Normalize stale enum IDProperties before Blender tries to display them.

    Older builds and old .blend files can contain numeric enum IDs such as 0.
    Dynamic EnumProperty callbacks in Blender 5.1 then repeatedly print
    "current value '0' matches no enum" before normal UI code can fix it.
    This function edits raw IDProperty storage first, so registration, loading,
    drawing, and save handlers all see valid string identifiers.
    """
    if scene is None:
        return False
    repaired = False
    targets = (
        'sss_node_pick', 'sss_inventory_pick', 'sss_asset_search_pick', 'sss_hdri_pick',
        'sss_rule_pick', 'sss_catalog_pick', 'sss_layer_recipe_pick', 'sss_scene_variant_pick',
        'sss_quick_action', 'sss_workspace_recipe', 'sss_feature_group', 'sss_feature_panel',
        'sss_preset_family', 'sss_preset_genre', 'sss_preset_name', 'sss_pbr_preset_family', 'sss_pbr_preset_genre', 'sss_pbr_preset_name', 'sss_layer_preset', 'sss_layer_mask_mode', 'sss_texture_import_mode',
        'sss_texture_scope', 'sss_assign_mode', 'sss_replace_scope', 'sss_rule_scope',
        'sss_custom_library_mode', 'sss_scene_variant_library_mode', 'sss_rule_library_mode',
    )
    invalid_tokens = {'', '0', 'NONE', 'None', 'null', 'NULL'}
    for name in targets:
        if require_rna and not _scene_has_rna_property(scene, name):
            continue
        raw = _safe_scene_id_get(scene, name, None)
        raw_text = _enum_text(raw, '')
        needs_repair = raw is not None and (isinstance(raw, int) or isinstance(raw, bytes) or raw_text in invalid_tokens)
        if not needs_repair:
            continue
        fallback = _legacy_enum_fallback(name)
        if not fallback:
            try:
                del scene[name]
                repaired = True
            except Exception:
                pass
            continue
        if _set_scene_id_value(scene, name, fallback):
            repaired = True
    return repaired


def _repair_all_scenes_legacy_enum_values(*, require_rna: bool = False) -> bool:
    repaired = False
    try:
        scenes = list(getattr(getattr(bpy, 'data', None), 'scenes', []) or [])
    except Exception:
        scenes = []
    for scene in scenes:
        try:
            repaired = _repair_legacy_scene_enum_values(scene, require_rna=require_rna) or repaired
        except Exception:
            pass
    return repaired

def _safe_scene_get_value(scene, name: str, default=None):
    if not _scene_has_rna_property(scene, name):
        return default
    if _scene_property_is_enum(scene, name):
        # Once registration-time repair has normalized stale legacy payloads,
        # RNA returns the stable enum identifier while raw IDProperty access can
        # expose Blender's internal integer. Persist the identifier first.
        try:
            return getattr(scene, name)
        except Exception:
            return scene_raw_enum_value(scene, name, default if default is not None else '')
    try:
        return getattr(scene, name)
    except Exception:
        return default


def _scene_session_key(scene) -> int:
    if scene is None:
        return 0
    try:
        return int(scene.as_pointer())
    except Exception:
        try:
            return int(id(scene))
        except Exception:
            return 0


def _trim_scene_session_state() -> None:
    if len(_SCENE_LAST_REPORT_CACHE) > _SCENE_SESSION_CACHE_LIMIT:
        keep = set(list(_SCENE_LAST_REPORT_CACHE.keys())[-_SCENE_SESSION_CACHE_LIMIT:])
        for key in list(_SCENE_LAST_REPORT_CACHE.keys()):
            if key not in keep:
                _SCENE_LAST_REPORT_CACHE.pop(key, None)
    for key_set in (_SCENE_DEFAULTS_INITIALIZED, _SCENE_PERSISTENCE_APPLIED):
        if len(key_set) <= _SCENE_SESSION_CACHE_LIMIT:
            continue
        for key in list(key_set)[:-_SCENE_SESSION_CACHE_LIMIT]:
            key_set.discard(key)


def _get_scene_last_report(scene) -> str:
    return _SCENE_LAST_REPORT_CACHE.get(_scene_session_key(scene), '')


def _set_scene_last_report(scene, value) -> None:
    key = _scene_session_key(scene)
    if not key:
        return
    text = '' if value is None else str(value)
    if text:
        _SCENE_LAST_REPORT_CACHE[key] = text
    else:
        _SCENE_LAST_REPORT_CACHE.pop(key, None)
    _trim_scene_session_state()


def _scene_last_report_get(scene) -> str:
    return _get_scene_last_report(scene)


def _scene_last_report_set(scene, value) -> None:
    _set_scene_last_report(scene, value)


def _scene_defaults_initialized(scene) -> bool:
    return _scene_session_key(scene) in _SCENE_DEFAULTS_INITIALIZED


def _set_scene_defaults_initialized(scene, value: bool = True) -> None:
    key = _scene_session_key(scene)
    if not key:
        return
    if value:
        _SCENE_DEFAULTS_INITIALIZED.add(key)
    else:
        _SCENE_DEFAULTS_INITIALIZED.discard(key)
    _trim_scene_session_state()


def _scene_persistence_applied(scene) -> bool:
    return _scene_session_key(scene) in _SCENE_PERSISTENCE_APPLIED


def _set_scene_persistence_applied(scene, value: bool = True) -> None:
    key = _scene_session_key(scene)
    if not key:
        return
    if value:
        _SCENE_PERSISTENCE_APPLIED.add(key)
    else:
        _SCENE_PERSISTENCE_APPLIED.discard(key)
    _trim_scene_session_state()


def _clear_scene_session_state(scene=None) -> None:
    if scene is None:
        _SCENE_LAST_REPORT_CACHE.clear()
        _SCENE_DEFAULTS_INITIALIZED.clear()
        _SCENE_PERSISTENCE_APPLIED.clear()
        return
    key = _scene_session_key(scene)
    _SCENE_LAST_REPORT_CACHE.pop(key, None)
    _SCENE_DEFAULTS_INITIALIZED.discard(key)
    _SCENE_PERSISTENCE_APPLIED.discard(key)


def _clear_legacy_raw_scene_bookkeeping(scene) -> None:
    if scene is None:
        return
    for name in (_SCENE_DEFAULTS_FLAG, _SCENE_PERSISTENCE_FLAG, 'sss_last_report'):
        try:
            scene.pop(name, None)
        except Exception:
            pass


def _clear_legacy_raw_last_report(scene) -> None:
    _clear_legacy_raw_scene_bookkeeping(scene)


def _clear_legacy_raw_last_reports_before_registration() -> None:
    for scene in list(getattr(getattr(bpy, 'data', None), 'scenes', []) or []):
        _clear_legacy_raw_scene_bookkeeping(scene)


def _collect_scene_settings(scene) -> dict[str, object]:
    data: dict[str, object] = {}
    if scene is None:
        return data
    for name in _PERSISTENT_SCENE_PROPS:
        if not _scene_has_rna_property(scene, name):
            continue
        value = _safe_scene_get_value(scene, name, None)
        if name == 'sss_node_pick' and str(value or '').strip() in {'', '0', 'NONE'}:
            value = finder.NODE_PICK_SENTINEL
        try:
            data[name] = _json_value(value)
        except Exception:
            pass
    return data


def save_persistent_scene_settings(scene=None, *, force: bool = False) -> None:
    global _SCENE_SETTINGS_CACHE
    if _PERSISTENCE_APPLYING:
        return
    scene = scene or getattr(getattr(bpy, 'context', None), 'scene', None)
    if scene is None:
        return
    if not _scene_defaults_initialized(scene) and not force:
        return
    _clear_legacy_raw_scene_bookkeeping(scene)
    data = _collect_scene_settings(scene)
    if not data or (not force and data == _SCENE_SETTINGS_CACHE):
        return
    try:
        if storage.write_suite_section('scene_settings', data):
            _SCENE_SETTINGS_CACHE = dict(data)
            return
    except Exception:
        pass


def apply_persistent_scene_settings(scene=None) -> None:
    global _PERSISTENCE_APPLYING, _SCENE_SETTINGS_CACHE
    scene = scene or getattr(getattr(bpy, 'context', None), 'scene', None)
    if scene is None:
        return
    _clear_legacy_raw_scene_bookkeeping(scene)
    if _scene_persistence_applied(scene):
        return
    data = _read_saved_scene_settings()
    if not data:
        _set_scene_persistence_applied(scene)
        _SCENE_SETTINGS_CACHE = _collect_scene_settings(scene)
        return
    _PERSISTENCE_APPLYING = True
    try:
        for name, value in data.items():
            if name not in _PERSISTENT_SCENE_PROPS or not _scene_has_rna_property(scene, name):
                continue
            if name == 'sss_node_pick' and str(value or '').strip() in {'', '0', 'NONE'}:
                value = finder.NODE_PICK_SENTINEL
            # Old persistence data may contain numeric enum indices from earlier
            # builds.  Do not assign them to Blender EnumProperty values because
            # Blender 5.1 logs "current value '133' matches no enum" before UI
            # code can repair the state.  Convert to a safe string identifier first.
            if _scene_property_is_enum(scene, name):
                value_text = _enum_text(value, '')
                if isinstance(value, int) or isinstance(value, bytes) or value_text in {'', '0', 'NONE', 'None', 'null', 'NULL'}:
                    value = _legacy_enum_fallback(name) or value_text
            try:
                if isinstance(value, list):
                    setattr(scene, name, tuple(value))
                else:
                    setattr(scene, name, value)
            except Exception:
                if _scene_property_is_enum(scene, name):
                    try:
                        _set_scene_enum_value(scene, name, value)
                    except Exception:
                        pass
        _set_scene_persistence_applied(scene)
    finally:
        _PERSISTENCE_APPLYING = False
    _SCENE_SETTINGS_CACHE = _collect_scene_settings(scene)


def _persistent_scene_update(self, context) -> None:
    try:
        from . import storage as _sss_storage
        if not _sss_storage.npanel_state_save_enabled(default=True):
            return
    except Exception:
        pass
    scene = getattr(context, 'scene', None) if context is not None else self
    # Property updates are the authoritative real-time persistence boundary.
    # ``force=True`` bypasses only the registration-default guard; the global
    # N-panel State Save policy above is still respected.
    save_persistent_scene_settings(scene, force=True)


def _chain_scene_update(callback):
    def _update(self, context):
        try:
            if callable(callback):
                callback(self, context)
        finally:
            _persistent_scene_update(self, context)
    return _update


def _fallback_scene_property_description(kwargs: dict) -> str:
    label = str(kwargs.get('name') or '').strip() or 'Smart Shader setting'
    label_ja = _ja_text(label) or 'この項目'
    return _lt(
        f'JP: {label_ja} の設定値です。Nパネルから変更すると自動保存され、Blender再起動・ファイル読み込み・別シーン切り替え後も復元されます。関連機能を使うときだけ調整してください。\n'
        f'EN: {label} setting. Changes made from the N-panel are saved automatically and restored after Blender restarts, file loads, and scene changes. Adjust it only when using the related feature.'
    )


def _wrap_scene_property(factory):
    def _wrapped(*args, **kwargs):
        kwargs = dict(kwargs)
        if not kwargs.get('description'):
            kwargs['description'] = _fallback_scene_property_description(kwargs)
        kwargs['update'] = _chain_scene_update(kwargs.get('update'))
        return factory(*args, **kwargs)
    return _wrapped


BoolProperty = _wrap_scene_property(BoolProperty)
EnumProperty = _wrap_scene_property(EnumProperty)
FloatProperty = _wrap_scene_property(FloatProperty)
FloatVectorProperty = _wrap_scene_property(FloatVectorProperty)
IntProperty = _wrap_scene_property(IntProperty)
StringProperty = _wrap_scene_property(StringProperty)


@persistent
def _apply_persistent_scene_settings_on_load(_dummy=None):
    try:
        from . import transform_guard as _sss_transform_guard
        with _sss_transform_guard.preserve_object_transforms('scene settings load_post'):
            _repair_all_scenes_legacy_enum_values(require_rna=False)
            for scene in list(getattr(getattr(bpy, 'data', None), 'scenes', []) or []):
                _clear_scene_session_state(scene)
                _clear_legacy_raw_scene_bookkeeping(scene)
            initialize_scene_defaults()
            # Material Library runtime handlers are legitimately removable from
            # the Always-on section.  Its UI state still belongs to the global
            # N-panel persistence contract, so restore it here at the Suite's
            # non-resident load boundary as well.
            material_ui = storage.read_suite_section('material_library_ui', {})
            if isinstance(material_ui, dict):
                for scene in list(getattr(getattr(bpy, 'data', None), 'scenes', []) or []):
                    owner = getattr(scene, 'matlib', None)
                    if owner is None:
                        continue
                    for name, value in material_ui.items():
                        try:
                            if hasattr(owner, str(name)):
                                setattr(owner, str(name), value)
                        except Exception:
                            pass
    except Exception:
        pass
    # Material-owned Smart Toon PointerProperties are materialised before the
    # file is opened, but Blender can still deserialize their ID pointers as
    # ``None`` while replacing the main database. The canonical JSON stores
    # both explicit nulls and stable datablock names, so replay it only after
    # load_post, when Images/Objects are available for name resolution.
    try:
        from . import smart_toon as _smart_toon
        restore_materials = getattr(_smart_toon, 'restore_smart_toon_profile_scalars_on_load', None)
        if callable(restore_materials):
            restore_materials()
    except Exception:
        pass
    _register_scene_change_subscription()


def _on_active_scene_changed() -> None:
    scene = getattr(getattr(bpy, 'context', None), 'scene', None)
    if scene is None:
        return
    _set_scene_persistence_applied(scene, False)
    _clear_legacy_raw_scene_bookkeeping(scene)
    apply_persistent_scene_settings(scene)
    material_editor = sys.modules.get(__package__ + '.material_editor')
    restore_editor = getattr(material_editor, 'restore_material_editor_settings', None) if material_editor is not None else None
    if callable(restore_editor):
        try:
            restore_editor(scene, force=True)
        except Exception:
            pass
    try:
        from . import smart_toon as _smart_toon
        restore_toon = getattr(_smart_toon, 'restore_smart_toon_profile_scalars_on_load', None)
        if callable(restore_toon):
            restore_toon()
    except Exception:
        pass
    material_library = sys.modules.get(__package__ + '.material_library')
    if material_library is None:
        # Integrated tools live in the loader's private runtime namespace.
        # Resolve the active record instead of assuming a normal submodule
        # name; this keeps the root event-only Window.scene subscription able
        # to restore the lazy Material Library settings.
        loader_module = sys.modules.get(__package__ + '.loader')
        record_for_alias = getattr(loader_module, 'record_for_alias', None) if loader_module is not None else None
        if callable(record_for_alias):
            try:
                record = record_for_alias('material_library')
                material_library = record.get('module') if isinstance(record, dict) else None
            except Exception:
                material_library = None
    restore_library = getattr(material_library, 'apply_matlib_ui_settings', None) if material_library is not None else None
    if callable(restore_library):
        try:
            restore_library(getattr(scene, 'matlib', None))
        except Exception:
            pass
    _register_scene_change_subscription()


def _register_scene_change_subscription() -> None:
    try:
        bpy.msgbus.clear_by_owner(_SCENE_MSGBUS_OWNER)
    except Exception:
        pass
    try:
        bpy.msgbus.subscribe_rna(
            key=(bpy.types.Window, 'scene'),
            owner=_SCENE_MSGBUS_OWNER,
            args=(),
            notify=_on_active_scene_changed,
            options={'PERSISTENT'},
        )
    except Exception:
        pass


@persistent
def _save_persistent_scene_settings_on_save(_dummy=None):
    # Headless wm.save_as_mainfile must not traverse any UI-capable save path.
    if bool(getattr(getattr(bpy, 'app', None), 'background', False)):
        return None
    try:
        from . import transform_guard as _sss_transform_guard
        with _sss_transform_guard.preserve_object_transforms('scene settings save_pre'):
            scenes = list(getattr(getattr(bpy, 'data', None), 'scenes', []) or [])
            active_scene = getattr(getattr(bpy, 'context', None), 'scene', None)
            if active_scene is not None:
                scenes = [scene for scene in scenes if scene is not active_scene]
                scenes.append(active_scene)
            for scene in scenes:
                _clear_legacy_raw_scene_bookkeeping(scene)
                save_persistent_scene_settings(scene, force=True)
    except Exception:
        pass


def _register_scene_persistence_handler() -> None:
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        load_post = getattr(handlers, 'load_post', None) if handlers is not None else None
        save_pre = getattr(handlers, 'save_pre', None) if handlers is not None else None
        if load_post is not None and _apply_persistent_scene_settings_on_load not in load_post:
            load_post.append(_apply_persistent_scene_settings_on_load)
        if save_pre is not None and _save_persistent_scene_settings_on_save not in save_pre:
            save_pre.append(_save_persistent_scene_settings_on_save)
    except Exception:
        pass
    _register_scene_change_subscription()


def set_scene_persistence_enabled(enabled: bool) -> None:
    """Install or release exact-owned Scene persistence resources."""
    _unregister_scene_persistence_handler()
    if bool(enabled):
        _register_scene_persistence_handler()


def _unregister_scene_persistence_handler() -> None:
    try:
        bpy.msgbus.clear_by_owner(_SCENE_MSGBUS_OWNER)
    except Exception:
        pass
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        load_post = getattr(handlers, 'load_post', None) if handlers is not None else None
        save_pre = getattr(handlers, 'save_pre', None) if handlers is not None else None
        if load_post is not None and _apply_persistent_scene_settings_on_load in load_post:
            load_post.remove(_apply_persistent_scene_settings_on_load)
        if save_pre is not None and _save_persistent_scene_settings_on_save in save_pre:
            save_pre.remove(_save_persistent_scene_settings_on_save)
    except Exception:
        pass



def family_enum_items(scene=None):
    key = ('family', _enum_locale_key(), tuple(data.FAMILY_ORDER))

    def _build():
        items = []
        for family_id in data.FAMILY_ORDER:
            meta = data.FAMILY_META[family_id]
            label = tx(scene, meta['label_en'], meta['label_ja'])
            desc = tx(scene, meta['summary_en'], meta['summary_ja'])
            items.append((family_id, label, desc))
        return items

    return _cached_enum_items(key, _build)

def _preset_genre_id(preset_id: str, meta: dict) -> str:
    try:
        infer = getattr(data, 'infer_preset_genre', None)
        if callable(infer):
            return str(infer(preset_id, meta) or 'GENERAL').upper()
    except Exception:
        pass
    return str((meta or {}).get('genre') or 'GENERAL').upper()


def preset_genre_enum_items(scene=None, *, family: str | None = None, pbr_scope: bool = False):
    key = ('preset_genre', _enum_locale_key(), str(family or ''), bool(pbr_scope), len(data.PRESET_LIBRARY))

    def _build():
        result = [('ALL', tx(scene, 'All Genres', _lt('すべてのジャンル')), tx(scene, 'Show every genre in the selected category.', _lt('選択カテゴリ内の全ジャンルを表示します。')))]
        seen = set()
        allowed_families = {'PBR', 'STYLIZED', 'FX'} if pbr_scope else None
        for preset_id, meta in data.PRESET_LIBRARY.items():
            fam = str(meta.get('family', '') or '')
            if family and fam != family:
                continue
            if allowed_families is not None and fam not in allowed_families:
                continue
            gid = _preset_genre_id(preset_id, meta)
            if gid in seen:
                continue
            seen.add(gid)
        order = list(getattr(data, 'GENRE_ORDER', []) or [])
        meta_map = getattr(data, 'GENRE_META', {}) or {}
        ordered = [gid for gid in order if gid in seen] + sorted(gid for gid in seen if gid not in set(order))
        for gid in ordered:
            gmeta = meta_map.get(gid, {}) if isinstance(meta_map, dict) else {}
            label = tx(scene, gmeta.get('label_en', gid.title()), gmeta.get('label_ja', gid))
            desc = tx(scene, gmeta.get('summary_en', ''), gmeta.get('summary_ja', ''))
            result.append((gid, label, desc))
        return result

    return _cached_enum_items(key, _build)


_COMPAT_JA = (
    ('OpenPBR-style interchange', 'OpenPBR 互換の受け渡し'),
    ('Smart Shader procedural look preset', 'スマートシェーダーの手続き型ルックプリセット'),
    (' (dual outputs)', '（出力を使い分け）'),
    (' (Eevee uses curvature fallback)', '（Eevee は曲率の代替を使用）'),
    (' (portable interop)', '（受け渡し向け）'),
    ('Eevee primary / Cycles approximate', 'Eevee 主体／Cycles は近似'),
)


def preset_description(scene, meta: dict) -> str:
    tags = ', '.join(meta.get('tags', []))
    key = ('preset_description', _enum_locale_key(), id(meta), tags)
    cached = _DESCRIPTION_CACHE.get(key)
    if cached is not None:
        return cached
    en = f"{meta['summary_en']}\nUse: {meta['usage_en']}\nControls: {meta['controls_en']}\nCompatibility: {meta['compat']}"
    compat_ja = str(meta['compat'])
    for compat_en, compat_text in _COMPAT_JA:
        compat_ja = compat_ja.replace(compat_en, compat_text)
    ja = f"{meta['summary_ja']}\n用途: {meta['usage_ja']}\n操作項目: {meta['controls_ja']}\n互換性: {compat_ja}"
    value = tx(scene, en, ja)
    _DESCRIPTION_CACHE[key] = value
    return value

def filtered_builtin_presets(scene, family: str, *, genre: str = 'ALL') -> list[tuple[str, str, str]]:
    search = (getattr(scene, 'sss_preset_search', '') or '').strip().lower()
    genre = str(genre or 'ALL').upper()
    key = ('builtin_presets', _enum_locale_key(), str(family or ''), genre, search, len(data.PRESET_LIBRARY))

    def _build():
        items = []
        for preset_id, meta in data.PRESET_LIBRARY.items():
            if meta['family'] != family:
                continue
            gid = _preset_genre_id(preset_id, meta)
            if genre not in {'', 'ALL'} and gid != genre:
                continue
            gmeta = getattr(data, 'GENRE_META', {}).get(gid, {}) if isinstance(getattr(data, 'GENRE_META', {}), dict) else {}
            haystack = ' '.join([preset_id, meta.get('label_en', ''), meta.get('label_ja', ''), meta.get('summary_en', ''), meta.get('summary_ja', ''), gid, gmeta.get('label_en', ''), gmeta.get('label_ja', ''), ' '.join(meta.get('tags', []))]).lower()
            if search and search not in haystack:
                continue
            label = tx(scene, meta['label_en'], meta['label_ja'])
            desc = preset_description(scene, meta)
            items.append((preset_id, label, desc))
        # Dynamic enum values are stored by position, so the order must not depend on the language.
        items.sort(key=lambda item: str(data.PRESET_LIBRARY[item[0]].get('label_en', '')).lower())
        return items

    return _cached_enum_items(key, _build)

def filtered_custom_presets(scene) -> list[tuple[str, str, str]]:
    search = (getattr(scene, 'sss_preset_search', '') or '').strip().lower()
    items = []
    for entry in core.list_custom_presets():
        name = entry.get('name', 'Custom')
        summary_en = entry.get('summary_en') or 'Saved custom preset.'
        summary_ja = entry.get('summary_ja') or _lt('保存済みのカスタムプリセットです。')
        tags = ', '.join(entry.get('tags', []))
        haystack = ' '.join([name, summary_en, summary_ja, tags]).lower()
        if search and search not in haystack:
            continue
        desc = tx(scene, f"{summary_en}\nBuilder: {entry.get('builder', '-')}\nTags: {tags or '-'}", _lt(f"{summary_ja}\nビルダー: {entry.get('builder', '-')}\nタグ: {tags or '-'}"))
        items.append((name, name, desc))
    if not items:
        items.append(('NO_CUSTOM_PRESETS', tx(scene, 'No Custom Presets', _lt('カスタム未登録')), tx(scene, 'No custom presets matched the current filter. Save or import one first.', _lt('現在のフィルタに一致するカスタムプリセットはありません。先に保存またはインポートしてください。'))))
    return items

def preset_enum_items(self, context):
    scene = context.scene if context and getattr(context, 'scene', None) else None
    family = getattr(scene, 'sss_preset_family', 'PBR') if scene else 'PBR'
    if family == 'CUSTOM':
        return filtered_custom_presets(scene)
    items = filtered_builtin_presets(scene, family, genre=getattr(scene, 'sss_preset_genre', 'ALL') if scene else 'ALL')
    if not items:
        items.append(('NO_PRESETS_MATCH', tx(scene, 'No Presets Match', _lt('一致するプリセットなし')), tx(scene, 'Adjust the search filter.', _lt('検索条件を変えてください。'))))
    return items


def pbr_preset_family_enum_items(scene=None):
    key = ('pbr_family', _enum_locale_key())

    def _build():
        result = []
        for family_id in ('PBR', 'STYLIZED', 'FX'):
            meta = data.FAMILY_META.get(family_id, {})
            result.append((family_id, tx(scene, meta.get('label_en', family_id), meta.get('label_ja', family_id)), tx(scene, meta.get('summary_en', ''), meta.get('summary_ja', ''))))
        return result

    return _cached_enum_items(key, _build)


def pbr_preset_enum_items(self, context):
    scene = context.scene if context and getattr(context, 'scene', None) else None
    family = getattr(scene, 'sss_pbr_preset_family', 'PBR') if scene else 'PBR'
    if family not in {'PBR', 'STYLIZED', 'FX'}:
        family = 'PBR'
    items = filtered_builtin_presets(scene, family, genre=getattr(scene, 'sss_pbr_preset_genre', 'ALL') if scene else 'ALL')
    if not items:
        items.append(('NO_PRESETS_MATCH', tx(scene, 'No PBR/FX Presets Match', _lt('一致するPBR/FXプリセットなし')), tx(scene, 'Adjust the search filter.', _lt('検索条件を変えてください。'))))
    return items


def _stored_enum_index_is_valid(scene, prop_name, items):
    # Reading a dynamic enum whose stored index left the item list makes RNA print a warning.
    stored_props = scene.bl_system_properties_get()
    stored = stored_props.get(prop_name, 0) if stored_props is not None else 0
    return isinstance(stored, int) and 0 <= stored < len(items)


def normalize_selected_pbr_preset(scene, context):
    items = pbr_preset_enum_items(None, context)
    if not _stored_enum_index_is_valid(scene, 'sss_pbr_preset_name', items):
        scene.sss_pbr_preset_name = items[0][0]


def on_pbr_family_or_search_update(self, context):
    try:
        normalize_selected_pbr_preset(context.scene, context)
    except Exception:
        pass

def normalize_selected_preset(scene, context):
    items = preset_enum_items(None, context)
    if not _stored_enum_index_is_valid(scene, 'sss_preset_name', items):
        scene.sss_preset_name = items[0][0]

def on_family_or_search_update(self, context):
    try:
        normalize_selected_preset(context.scene, context)
    except Exception:
        pass
    try:
        normalize_selected_pbr_preset(context.scene, context)
    except Exception:
        pass

def quick_action_description(scene, meta: dict) -> str:
    keywords = ', '.join(meta.get('keywords_en', []))
    keywords_ja = '、'.join(meta.get('keywords_ja', []))
    key = ('quick_action_description', _enum_locale_key(), id(meta), keywords, keywords_ja)
    cached = _DESCRIPTION_CACHE.get(key)
    if cached is not None:
        return cached
    en = f"{meta['summary_en']}\nKeywords: {keywords or '-'}"
    ja = _lt(f"{meta['summary_ja']}\nキーワード: {keywords_ja or '-'}")
    value = tx(scene, en, ja)
    _DESCRIPTION_CACHE[key] = value
    return value

def quick_action_enum_items(self, context):
    scene = context.scene if context and getattr(context, 'scene', None) else None
    search = (getattr(scene, 'sss_quick_action_search', '') or '').strip().lower()
    ordered_actions = tuple(data.quick_action_ids_in_order() if hasattr(data, 'quick_action_ids_in_order') else list(data.QUICK_ACTION_ORDER))
    key = ('quick_actions', _enum_locale_key(), search, ordered_actions, len(data.QUICK_ACTION_META))

    def _build():
        terms = [term for term in search.split() if term]
        items = []
        for action_id in ordered_actions:
            meta = data.QUICK_ACTION_META.get(action_id)
            if not meta:
                continue
            haystack = ' '.join([action_id, meta.get('label_en', ''), meta.get('label_ja', ''), meta.get('summary_en', ''), meta.get('summary_ja', ''), ' '.join(meta.get('keywords_en', [])), ' '.join(meta.get('keywords_ja', [])), meta.get('operator', '')]).lower()
            if terms and (not all((term in haystack for term in terms))):
                continue
            items.append((action_id, tx(scene, meta['label_en'], meta['label_ja']), quick_action_description(scene, meta)))
        if not items:
            items.append(('NO_QUICK_ACTIONS', tx(scene, 'No Quick Actions Match', _lt('一致するクイック操作なし')), tx(scene, 'Adjust the quick-action search filter.', _lt('クイック操作の検索条件を変えてください。'))))
        return items

    return _cached_enum_items(key, _build)

def normalize_selected_quick_action(scene, context):
    items = quick_action_enum_items(None, context)
    valid = {item[0] for item in items}
    if scene.sss_quick_action not in valid:
        scene.sss_quick_action = items[0][0]

def on_quick_action_search_update(self, context):
    try:
        normalize_selected_quick_action(context.scene, context)
    except Exception:
        pass

def workspace_recipe_description(scene, meta: dict) -> str:
    key = ('workspace_recipe_description', _enum_locale_key(), id(meta))
    cached = _DESCRIPTION_CACHE.get(key)
    if cached is not None:
        return cached
    en = f"{meta['summary_en']}"
    ja = _lt(f"{meta['summary_ja']}")
    value = tx(scene, en, ja)
    _DESCRIPTION_CACHE[key] = value
    return value

def workspace_recipe_enum_items(self, context):
    scene = context.scene if context and getattr(context, 'scene', None) else None
    order = tuple(getattr(data, 'WORKSPACE_RECIPE_ORDER', []))
    key = ('workspace_recipes', _enum_locale_key(), order, len(getattr(data, 'WORKSPACE_RECIPE_META', {})))

    def _build():
        items = []
        for recipe_id in order:
            meta = data.WORKSPACE_RECIPE_META.get(recipe_id)
            if not meta:
                continue
            items.append((recipe_id, tx(scene, meta['label_en'], meta['label_ja']), workspace_recipe_description(scene, meta)))
        if not items:
            items.append(('BUILD_PRESET', tx(scene, 'Build Preset Material', _lt('プリセット材質を構築')), tx(scene, 'Fallback compact workflow.', _lt('コンパクトUIのフォールバック導線です。'))))
        return items

    return _cached_enum_items(key, _build)

def normalize_selected_workspace_recipe(scene, context):
    items = workspace_recipe_enum_items(None, context)
    valid = {item[0] for item in items}
    if scene.sss_workspace_recipe not in valid:
        scene.sss_workspace_recipe = items[0][0]

def feature_browser_group_description(scene, meta: dict) -> str:
    key = ('feature_browser_group_description', _enum_locale_key(), id(meta))
    cached = _DESCRIPTION_CACHE.get(key)
    if cached is not None:
        return cached
    value = tx(scene, meta['summary_en'], meta['summary_ja'])
    _DESCRIPTION_CACHE[key] = value
    return value

def feature_browser_group_enum_items(self, context):
    scene = context.scene if context and getattr(context, 'scene', None) else None
    order = tuple(getattr(data, 'FEATURE_BROWSER_GROUP_ORDER', []))
    key = ('feature_browser_groups', _enum_locale_key(), order, len(getattr(data, 'FEATURE_BROWSER_GROUP_META', {})))

    def _build():
        items = []
        for group_id in order:
            meta = getattr(data, 'FEATURE_BROWSER_GROUP_META', {}).get(group_id)
            if not meta:
                continue
            items.append((group_id, tx(scene, meta['label_en'], meta['label_ja']), feature_browser_group_description(scene, meta)))
        if not items:
            items.append(('BUILD', tx(scene, 'Build', _lt('生成')), tx(scene, 'Fallback feature-browser group.', _lt('機能エクスプローラーのフォールバックグループです。'))))
        return items

    return _cached_enum_items(key, _build)

def normalize_selected_feature_group(scene, context):
    items = feature_browser_group_enum_items(None, context)
    valid = {item[0] for item in items}
    if scene.sss_feature_group not in valid:
        scene.sss_feature_group = items[0][0]

def feature_browser_panel_description(scene, meta: dict) -> str:
    key = ('feature_browser_panel_description', _enum_locale_key(), id(meta))
    cached = _DESCRIPTION_CACHE.get(key)
    if cached is not None:
        return cached
    value = tx(scene, meta['summary_en'], meta['summary_ja'])
    _DESCRIPTION_CACHE[key] = value
    return value

def feature_browser_panel_enum_items(self, context):
    scene = context.scene if context and getattr(context, 'scene', None) else None
    group_id = getattr(scene, 'sss_feature_group', 'BUILD') if scene else 'BUILD'
    panel_groups = getattr(data, 'FEATURE_BROWSER_PANEL_GROUPS', {})
    panel_meta = getattr(data, 'FEATURE_BROWSER_PANEL_META', {})
    panel_order = tuple(panel_groups.get(group_id, []))
    key = ('feature_browser_panels', _enum_locale_key(), str(group_id), panel_order, len(panel_meta))

    def _build():
        items = []
        for panel_id in panel_order:
            meta = panel_meta.get(panel_id)
            if not meta:
                continue
            items.append((panel_id, tx(scene, meta['label_en'], meta['label_ja']), feature_browser_panel_description(scene, meta)))
        if not items:
            meta = panel_meta.get('BUILD_APPLY', {'label_en': 'Build & Custom Library', 'label_ja': _lt('生成とカスタムライブラリ'), 'summary_en': 'Fallback feature panel.', 'summary_ja': _lt('フォールバックの機能パネルです。')})
            items.append(('BUILD_APPLY', tx(scene, meta['label_en'], meta['label_ja']), feature_browser_panel_description(scene, meta)))
        return items

    return _cached_enum_items(key, _build)

def normalize_selected_feature_panel(scene, context):
    items = feature_browser_panel_enum_items(None, context)
    valid = {item[0] for item in items}
    if scene.sss_feature_panel not in valid:
        scene.sss_feature_panel = items[0][0]

def on_feature_group_update(self, context):
    try:
        normalize_selected_feature_panel(context.scene, context)
    except Exception:
        pass

def normalize_selected_scene_variant(scene, context):
    items = scene_variant_enum_items(None, context)
    valid = {item[0] for item in items}
    if scene.sss_scene_variant_pick not in valid:
        scene.sss_scene_variant_pick = items[0][0]

def normalize_selected_layer_recipe(scene, context):
    items = layer_recipe_enum_items(None, context)
    valid = {item[0] for item in items}
    if scene.sss_layer_recipe_pick not in valid:
        scene.sss_layer_recipe_pick = items[0][0]

def normalize_selected_catalog_entry(scene, context):
    items = catalog_entry_enum_items(None, context)
    valid = {item[0] for item in items}
    if scene.sss_catalog_pick not in valid:
        scene.sss_catalog_pick = items[0][0]

def layer_recipe_enum_items(self, context):
    scene = context.scene if context and getattr(context, 'scene', None) else None
    return layers.layer_recipe_items(scene)

def catalog_entry_enum_items(self, context):
    scene = context.scene if context and getattr(context, 'scene', None) else None
    return catalog.catalog_items(scene)

def on_catalog_search_update(self, context):
    try:
        normalize_selected_catalog_entry(context.scene, context)
    except Exception:
        pass

def asset_search_enum_items(self, context):
    scene = context.scene if context and getattr(context, 'scene', None) else None
    return finder.asset_search_items(scene)

def normalize_selected_asset_search(scene, context):
    items = asset_search_enum_items(None, context)
    valid = {str(item[0]) for item in items}
    current_value = scene_raw_enum_value(scene, 'sss_asset_search_pick', '')
    if current_value not in valid:
        _set_scene_enum_value(scene, 'sss_asset_search_pick', items[0][0], use_rna=False)

def on_asset_search_update(self, context):
    try:
        normalize_selected_asset_search(context.scene, context)
    except Exception:
        pass

_SSS_INVENTORY_ENUM_GUARD = False
_NODE_PICK_ENUM_CACHE = []
_LEGACY_NODE_PICK_IDENTIFIERS = {'', '0', 'NONE'}
_NODE_PICK_DEFAULT = finder.NODE_PICK_SENTINEL


def _stable_enum_number(identifier: str, used: set[int] | None = None) -> int:
    text = str(identifier or '')
    fixed = {finder.NODE_PICK_SENTINEL: 0, '0': 1, 'NONE': 2}
    if text in fixed:
        number = fixed[text]
    else:
        try:
            number = 1000 + (zlib.crc32(text.encode('utf-8', errors='replace')) % 2000000000)
        except Exception:
            number = 1000
    if used is not None:
        while number in used:
            number += 1
        used.add(number)
    return number


def scene_raw_enum_value(scene, prop_name: str, default: str = '') -> str:
    """Read a custom EnumProperty without forcing RNA enum conversion.

    Old .blend files can contain stale enum payloads such as integer 0.  Calling
    getattr(scene, prop_name) while such a payload is active can emit RNA
    warnings or decoding errors before the add-on has a chance to repair it.
    IDProperty access is used first and every failure falls back safely.
    """
    if scene is None or not prop_name:
        return str(default or '')
    value = _safe_scene_id_get(scene, prop_name, default)
    return _enum_text(value, default)


def _set_scene_enum_value(scene, prop_name: str, value, *, use_rna: bool=True) -> bool:
    if scene is None or not prop_name:
        return False
    text = _enum_text(value, '')
    assigned = False
    # Write the raw IDProperty first.  This repairs old numeric enum storage
    # without forcing Blender to read an invalid dynamic enum value first.
    try:
        scene[str(prop_name)] = text
        assigned = True
    except Exception:
        pass
    if use_rna:
        try:
            setattr(scene, prop_name, text)
            assigned = True
        except Exception:
            pass
    return assigned


def inventory_enum_items(self, context):
    global _SSS_INVENTORY_ENUM_GUARD
    if _SSS_INVENTORY_ENUM_GUARD:
        return [('NONE', 'No Scene Materials', 'No materials matched the current inventory filters.')]
    _SSS_INVENTORY_ENUM_GUARD = True
    try:
        scene = context.scene if context and getattr(context, 'scene', None) else None
        try:
            items = list(inventory.inventory_items(scene))
        except Exception:
            items = []
        try:
            current_value = scene_raw_enum_value(scene, 'sss_inventory_pick', '') if scene is not None else ''
        except Exception:
            current_value = ''
        if current_value in {'0', 'NONE'}:
            fallback_value = str(items[0][0]) if items else str(getattr(inventory, 'INVENTORY_SENTINEL', 'NONE'))
            _set_scene_enum_value(scene, 'sss_inventory_pick', fallback_value, use_rna=False)
            current_value = fallback_value
        if current_value and all(str(item[0]) != current_value for item in items if item):
            items.insert(0, (current_value, current_value, current_value))
        if not items:
            try:
                items = [(inventory.INVENTORY_SENTINEL, 'No Scene Materials', 'No materials matched the current inventory filters.')]
            except Exception:
                items = [('NONE', 'No Scene Materials', 'No materials matched the current inventory filters.')]
        return items
    finally:
        _SSS_INVENTORY_ENUM_GUARD = False

def normalize_selected_inventory(scene, context):
    try:
        identifiers = [str(item or '') for item in inventory.inventory_identifier_items(scene) if str(item or '')]
    except Exception:
        identifiers = []
    if not identifiers:
        try:
            identifiers = [str(item[0]) for item in inventory_enum_items(None, context) if item]
        except Exception:
            identifiers = [inventory.INVENTORY_SENTINEL]
    valid = set(identifiers)
    current_value = scene_raw_enum_value(scene, 'sss_inventory_pick', '')
    if current_value not in valid:
        _set_scene_enum_value(scene, 'sss_inventory_pick', identifiers[0] if identifiers else inventory.INVENTORY_SENTINEL, use_rna=False)

def on_inventory_update(self, context):
    try:
        normalize_selected_inventory(context.scene, context)
    except Exception:
        pass

def assign_rule_enum_items(self, context):
    scene = context.scene if context and getattr(context, 'scene', None) else None
    return rules.assign_rule_items(scene)

def normalize_selected_assign_rule(scene, context):
    items = assign_rule_enum_items(None, context)
    valid = {item[0] for item in items}
    if scene.sss_rule_pick not in valid:
        scene.sss_rule_pick = items[0][0]

def on_assign_rule_update(self, context):
    try:
        normalize_selected_assign_rule(context.scene, context)
    except Exception:
        pass

def node_pick_enum_items(self, context):
    global _NODE_PICK_ENUM_CACHE
    try:
        scene = context.scene if context and getattr(context, 'scene', None) else None
    except Exception:
        scene = None
    try:
        material = core.preferred_material(context) if context else None
    except Exception:
        material = None
    sentinel_label = tx(scene, 'No Nodes Match', _lt('一致するノードなし'))
    sentinel_desc = tx(scene, 'Adjust the node query or capture a node-based material first.', _lt('ノード検索語を変えるか、ノード材質を取り込んでください。'))
    try:
        raw_items = list(finder.node_pick_items(material, scene))
    except Exception:
        raw_items = []
    # Always keep numeric and string legacy entries in the dynamic EnumProperty.
    # Blender validates the stored enum value against this returned item list
    # before our load/update handlers can normalize old .blend values.  The
    # safe sentinel uses numeric value 0, while the literal identifiers '0' and
    # 'NONE' catch older string payloads.
    used_numbers = set()
    cache = [(finder.NODE_PICK_SENTINEL, sentinel_label, sentinel_desc, 'NONE', _stable_enum_number(finder.NODE_PICK_SENTINEL, used_numbers))]
    seen = {finder.NODE_PICK_SENTINEL}
    for item in raw_items:
        try:
            ident = str(item[0] or '')
            label = str(item[1] if len(item) > 1 else ident)
            desc = str(item[2] if len(item) > 2 else label)
        except Exception:
            continue
        if not ident or ident in {'0', 'NONE'} or ident in seen:
            continue
        seen.add(ident)
        cache.append((ident, label, desc, 'NONE', _stable_enum_number(ident, used_numbers)))
    legacy_label = tx(scene, 'Legacy empty node value', _lt('旧形式の空ノード値'))
    legacy_desc = tx(scene, 'Compatibility item used only to suppress old saved enum warnings; it is normalized automatically.', _lt('旧保存列挙プロパティの警告を抑えるためだけの互換項目です。自動的に安全値へ正規化されます。'))
    for legacy_id in ('0', 'NONE'):
        if legacy_id not in seen:
            cache.append((legacy_id, legacy_label, legacy_desc, 'NONE', _stable_enum_number(legacy_id, used_numbers)))
            seen.add(legacy_id)
    try:
        current_value = scene_raw_enum_value(scene, 'sss_node_pick', '')
        if current_value in {'0', 'NONE', ''}:
            _set_scene_enum_value(scene, 'sss_node_pick', finder.NODE_PICK_SENTINEL, use_rna=False)
    except Exception:
        pass
    _NODE_PICK_ENUM_CACHE = cache
    return _NODE_PICK_ENUM_CACHE

def hdri_search_enum_items(self, context):
    scene = context.scene if context and getattr(context, 'scene', None) else None
    return environment.hdri_search_items(scene)

def normalize_selected_hdri_search(scene, context):
    items = hdri_search_enum_items(None, context)
    valid = {item[0] for item in items}
    if scene.sss_hdri_pick not in valid:
        scene.sss_hdri_pick = items[0][0]

def on_hdri_library_root_update(self, context):
    try:
        environment.invalidate_hdri_cache()
    except Exception:
        pass
    try:
        normalize_selected_hdri_search(context.scene, context)
    except Exception:
        pass

def on_hdri_search_update(self, context):
    try:
        normalize_selected_hdri_search(context.scene, context)
    except Exception:
        pass

def normalize_selected_node_pick(scene, context):
    items = node_pick_enum_items(None, context)
    valid = {str(item[0]) for item in items}
    current = scene_raw_enum_value(scene, 'sss_node_pick', '')
    if current in _LEGACY_NODE_PICK_IDENTIFIERS or current not in valid:
        non_legacy = [str(item[0]) for item in items if str(item[0]) not in _LEGACY_NODE_PICK_IDENTIFIERS]
        fallback = finder.NODE_PICK_SENTINEL if finder.NODE_PICK_SENTINEL in valid else (non_legacy[0] if non_legacy else '')
        if fallback:
            _set_scene_enum_value(scene, 'sss_node_pick', fallback, use_rna=False)

def on_node_query_update(self, context):
    try:
        normalize_selected_node_pick(context.scene, context)
    except Exception:
        pass

def scene_variant_enum_items(self, context):
    scene = context.scene if context and getattr(context, 'scene', None) else None
    items = []
    for entry in core.list_scene_variants():
        name = str(entry.get('name', '') or '').strip()
        if not name:
            continue
        saved_at = str(entry.get('saved_at', '') or '')
        world = entry.get('world', {}) if isinstance(entry.get('world'), dict) else {}
        world_name = world.get('world_name') or tx(scene, 'No HDRI', _lt('HDRIなし'))
        en = f"Scene-wide snapshot saved at {saved_at or '-'} | World: {world_name}"
        ja = _lt(f"保存日時: {saved_at or '-'} | ワールド: {world_name}")
        items.append((name, name, tx(scene, en, ja)))
    if not items:
        items.append(('NO_SCENE_VARIANTS', tx(scene, 'No Scene Variants', _lt('保存済みバリアントなし')), tx(scene, 'Save a scene variant first.', _lt('先にシーンバリアントを保存してください。'))))
    return items

SSSPreferences = _preferences.SSSPreferences


def on_material_target_slot_index_update(self, context):
    obj = getattr(context, 'object', None) or getattr(context, 'active_object', None)
    if obj is None:
        return
    try:
        slots = getattr(obj, 'material_slots', None)
        slot_count = len(slots) if slots is not None else 0
    except Exception:
        slot_count = 0
    if slot_count <= 0:
        return
    try:
        index = int(getattr(self, 'sss_material_target_slot_index', -1))
    except Exception:
        index = -1
    if index < 0:
        return
    index = max(0, min(slot_count - 1, index))
    try:
        obj.active_material_index = index
    except Exception:
        pass


def register_properties():
    clear_enum_item_cache()
    bpy.types.Scene.sss_ui_section = EnumProperty(name=_lt('表示セクション / Section'), description=_lt('JP: UIの表示セクションです。必要な機能だけを表示して、画面をコンパクトに保ちます。\nEN: Choose the visible UI section to keep the panel compact and focused.'), items=[('BUILD', _lt('生成 / Build'), _lt('JP: プリセットの作成と適用。 EN: Create and apply presets.')), ('MANAGE', _lt('管理 / Manage'), _lt('JP: 材質管理とスロット操作。 EN: Material manager and slot operations.')), ('RELINK', _lt('再リンク / Relink'), _lt('JP: テクスチャ再リンクと掃除。 EN: Texture relink and cleanup.')), ('AUDIT', _lt('監査 / Audit'), _lt('JP: 監査、自己診断、OSL補助。 EN: Audits, self-check, and OSL helpers.')), ('INTEROP', _lt('互換 / Interop'), _lt('JP: マニフェストや相互運用。 EN: Manifest and interoperability tools.')), ('COVERAGE', _lt('網羅 / Coverage'), _lt('JP: ドキュメント対応表。 EN: Document coverage mapping.'))], default='BUILD')
    bpy.types.Scene.sss_workspace_recipe = EnumProperty(name=_lt('コンパクト作業 / Compact Workflow'), description=_lt('JP: 個別ボタンを大幅に減らした主導線です。似た機能を上位互換寄りの代表ワークフローへまとめています。\nEN: Main compact entry point with far fewer individual buttons. Similar tools are merged into higher-level representative workflows.'), items=workspace_recipe_enum_items)
    bpy.types.Scene.sss_show_advanced = BoolProperty(name=_lt('全機能を表示 / Show All Tools'), description=_lt('JP: コンパクトUIの下に、実装済みツールを工程別・機能別へ整理し直した詳細カテゴリーパネルを表示します。普段は主導線だけを使い、必要な時だけオンにすると、画面を散らかしにくいまま全機能へ到達できます。\nEN: Show the detailed categorized panels under the compact UI, reorganized by workflow stage and function. Leave this off for the compact main flow, then enable it when you want access to every implemented tool without the older grouped browser.'), default=False)
    bpy.types.Scene.sss_feature_group = EnumProperty(name=_lt('全機能グループ / Feature Group'), description=_lt('JP: 機能エクスプローラー内の大分類です。似た機能を5系統前後へまとめています。\nEN: High-level grouping used by the feature explorer. Similar tools are bundled into about five broad families.'), items=feature_browser_group_enum_items, update=on_feature_group_update)
    bpy.types.Scene.sss_feature_panel = EnumProperty(name=_lt('機能パネル / Feature Panel'), description=_lt('JP: 選択したグループ内で開く機能パネルです。元バージョンの各主要機能を1つずつ使えます。\nEN: Feature panel opened within the selected group. Each panel restores one of the original add-on capabilities.'), items=feature_browser_panel_enum_items)
    bpy.types.Scene.sss_preset_family = EnumProperty(name=_lt('Category', 'カテゴリ'), description=_lt('Choose from PBR, Stylized, FX & Weathering, or Custom.', 'PBR、スタイライズ、FX・ウェザリング、カスタムから選びます。'), items=lambda self, context: family_enum_items(context.scene if context else None), update=on_family_or_search_update)
    bpy.types.Scene.sss_preset_genre = EnumProperty(name=_lt('Genre', 'ジャンル'), description=_lt('Filter presets by material/look genre such as anime, cyber, hair, rim bounce, manga, fabric, glass, metal, skin, nature, or product looks.', 'アニメ系、サイバー系、ヘアー系、照り返し系、漫画、布、ガラス、金属、肌、自然物、製品ルックなど、質感ジャンルでプリセットを絞り込みます。'), items=lambda self, context: preset_genre_enum_items(context.scene if context else None, family=getattr(context.scene, 'sss_preset_family', None) if context and getattr(context, 'scene', None) else None), update=on_family_or_search_update)
    bpy.types.Scene.sss_preset_search = StringProperty(name=_lt('Search', '検索'), description=_lt('Search preset names, summaries, tags, and genre labels in either English or Japanese.', 'プリセット名、概要、タグ、ジャンル名を横断検索します。英語・日本語どちらでも検索できます。'), default='', update=on_family_or_search_update)
    bpy.types.Scene.sss_preset_name = EnumProperty(name=_lt('プリセット / Preset'), description=_lt('JP: 作成・適用したいプリセットです。各プリセットは概要欄とツールチップで詳細を確認できます。\nEN: Preset to create or apply. See the summary box and tooltip for details.'), items=preset_enum_items)
    bpy.types.Scene.sss_pbr_preset_family = EnumProperty(name=_lt('Preset Category', 'プリセットカテゴリ'), description=_lt('Category used by the material generation section. PBR, stylized, and FX/weathering presets are available.', 'マテリアル生成セクション用のカテゴリです。PBR、スタイライズ、FX・ウェザリング系プリセットを選べます。'), items=lambda self, context: pbr_preset_family_enum_items(context.scene if context else None), update=on_pbr_family_or_search_update)
    bpy.types.Scene.sss_pbr_preset_genre = EnumProperty(name=_lt('Genre', 'ジャンル'), description=_lt('Filter material-generation presets by look genre before selecting or opening the image popup.', '画像ポップアップやプリセット選択前に、ルックジャンルでマテリアル生成用プリセットを絞り込みます。'), items=lambda self, context: preset_genre_enum_items(context.scene if context else None, family=getattr(context.scene, 'sss_pbr_preset_family', None) if context and getattr(context, 'scene', None) else None, pbr_scope=True), update=on_pbr_family_or_search_update)
    bpy.types.Scene.sss_pbr_preset_name = EnumProperty(name=_lt('Preset', 'プリセット'), description=_lt('Preset used by the material generation section. PBR, stylized, and FX/weathering looks are shown according to the selected category and genre.', 'マテリアル生成セクション用のプリセットです。選択したカテゴリとジャンルに応じて、PBR、スタイライズ、FX・ウェザリング系ルックを表示します。'), items=pbr_preset_enum_items)
    bpy.types.Scene.sss_material_name = StringProperty(name=_lt('名前 / Name'), description=_lt('JP: 新規作成名やリネーム時の名前です。空欄ならプリセット名または既存名を使います。\nEN: Name used for creation or renaming. If empty, the preset name or existing name is used.'), default='')
    bpy.types.Scene.sss_target_material_name = StringProperty(name=_lt('対象材質 / Target Material'), description=_lt('JP: 管理、複製、割当、アセット化、再構築の対象にするマテリアルです。\nEN: Material targeted by manager actions such as assign, duplicate, asset mark, and rebuild.'), default='')
    bpy.types.Scene.sss_compare_source_material_name = StringProperty(name=_lt('比較元 / Compare Source'), description=_lt('JP: 比較や置換の元になる材質名です。空欄なら、ターゲットと異なるアクティブ材質を優先し、それも無ければアクティブ材質を使います。\nEN: Material used as the source for compare-and-replace tools. When empty, the add-on prefers the active material if it differs from the target; otherwise it falls back to the active material.'), default='')
    bpy.types.Scene.sss_replace_scope = EnumProperty(name=_lt('置換範囲 / Replace Scope'), description=_lt('JP: 比較と置換で参照置換を行う範囲です。選択オブジェクトは現在選択中だけ、シーンはシーン全体を対象にします。初心者には選択オブジェクトがより安全です。\nEN: Scope used by Compare & Replace when swapping material references. Selected Objects limits the change to the current selection, while Scene processes the entire scene. Selected Objects is the safer beginner option.'), items=[('SELECTED', _lt('Selected Objects / 選択オブジェクト'), _lt('JP: 現在選択中のオブジェクトだけを置換対象にします。 EN: Replace references only on currently selected objects.')), ('SCENE', _lt('Scene / シーン全体'), _lt('JP: シーン全体のオブジェクトを置換対象にします。 EN: Replace references across the full scene.'))], default='SELECTED')
    bpy.types.Scene.sss_inventory_search = StringProperty(name=_lt('インデックス検索 / Index Search'), description=_lt('JP: シーン材質インデックス を名前、分類、ビルダー、タグ、用途ヒントで絞り込みます。大きなシーンで材質を逆引き・整理したい時に便利です。\nEN: Filter the Scene Material Index by name, family, builder, tags, and usage hints. Useful when reverse-looking-up or organizing materials in larger scenes.'), default='', update=on_inventory_update)
    bpy.types.Scene.sss_inventory_scope = EnumProperty(name=_lt('インデックス範囲 / Index Scope'), description=_lt('JP: シーン材質インデックス に表示する材質の範囲です。シーン使用中はシーンで使われているものだけ、管理中のみはスマートシェーダーの管理中だけ、全材質は全材質を出します。\nEN: Controls which materials appear in the Scene Material Index. Scene Used shows only materials used by the scene, Managed Only shows Smart Shader managed materials, and All lists every material datablock.'), items=[('SCENE_USED', _lt('Scene Used / シーン使用中'), _lt('JP: 現在のシーンで使われている材質だけを表示します。 EN: Show only materials currently used in the scene.')), ('MANAGED_ONLY', _lt('Managed Only / 管理中のみ'), _lt('JP: スマートシェーダー 管理対象の材質だけを表示します。 EN: Show only Smart Shader managed materials.')), ('ALL', _lt('All Materials / 全材質'), _lt('JP: 未使用も含めた全マテリアルを表示します。 EN: Show all material datablocks, including unused ones.'))], default='SCENE_USED', update=on_inventory_update)
    bpy.types.Scene.sss_inventory_sort = EnumProperty(name=_lt('並び順 / Sort'), description=_lt('JP: シーン材質インデックス の並び順です。使用数は使用数の多い順、欠損優先は欠損の多い順、複雑さはノードの多い順、名前は名前順です。\nEN: Sort order for the Scene Material Index. Users prioritizes assignment count, Missing prioritizes broken textures, Nodes prioritizes graph complexity, and Name sorts alphabetically.'), items=[('USERS', _lt('Users / 使用数'), _lt('JP: 使用オブジェクト数とスロット数が多いものを先に表示します。 EN: Show the most used materials first.')), ('MISSING', _lt('Missing / 欠損優先'), _lt('JP: 欠損テクスチャが多いものを先に表示します。 EN: Show materials with missing textures first.')), ('NODES', _lt('Nodes / 複雑さ'), _lt('JP: ノード数が多いものを先に表示します。 EN: Show the most complex node graphs first.')), ('NAME', _lt('Name / 名前順'), _lt('JP: 名前順に表示します。 EN: Sort alphabetically by name.'))], default='USERS', update=on_inventory_update)
    bpy.types.Scene.sss_inventory_pick = EnumProperty(name=_lt('Scene Material Index / シーン材質インデックス'), description=_lt('JP: 現在のシーン材質一覧から管理したい項目を選びます。選択後はターゲット化や使用オブジェクト選択へ進めます。\nEN: Pick a material from the current scene inventory. After selecting one, you can promote it to the manager target or select its users directly.'), items=inventory_enum_items)
    bpy.types.Scene.sss_custom_preset_name = StringProperty(name=_lt('保存名 / Custom Save Name'), description=_lt('JP: カスタムプリセットとして保存する名前です。空欄なら現在のマテリアル名を使います。\nEN: Name used when saving a custom preset. If empty, the current material name is used.'), default='')
    bpy.types.Scene.sss_texture_search_root = StringProperty(name=_lt('検索フォルダ / Texture Search Root'), description=_lt('JP: リンク切れテクスチャの再探索に使うフォルダです。サブフォルダも再帰検索します。\nEN: Root folder used when relinking missing textures. Subfolders are searched recursively.'), subtype='DIR_PATH', default='')
    bpy.types.Scene.sss_texture_set_filter = StringProperty(name=_lt('テクスチャセット絞込 / Texture Set Filter'), description=_lt('JP: テクスチャセット構築時に使う任意の絞込文字列です。材質名、アセット名、セット名などを入れると、同じフォルダ内の別セットを巻き込みにくくなります。\nEN: Optional filter string used when building from a texture set. Use a material, asset, or set name to avoid pulling unrelated textures from the same folder.'), default='')
    bpy.types.Scene.sss_texture_import_mode = EnumProperty(name=_lt('取込方式 / Import Mode'), description=_lt('JP: 自動グループは最も整合する 1 セットを自動選択、絞込優先は絞込に一致した最適グループを優先、一致を全使用は複数グループ候補も扱える上級者向け方式です。初心者には自動グループが最も安全です。\nEN: Auto Group picks the most coherent single set, Filter Only prefers the best group that matches the filter, and All Matching is an expert mode that can span multiple groups. Auto Group remains the safest default for beginners.'), items=[('AUTO_GROUP', _lt('Auto Group / 自動グループ'), _lt('JP: 大きなフォルダでも 1 アセット分の整合するセットを自動選択します。 EN: Automatically pick the most coherent single asset set from a larger folder.')), ('FILTER_ONLY', _lt('Filter Only / 絞込優先'), _lt('JP: 絞込に一致した候補群から、最も整合する安全な1グループを優先します。 EN: From the filtered candidates, prefer the safest single coherent group.')), ('ALL_MATCHING', _lt('All Matching / 一致を全使用'), _lt('JP: 一致した複数グループも扱える上級者向け方式です。通常は単一アセット専用フォルダ向けで、複数グループ時は安全ガードが働きます。 EN: Expert mode that can include multiple matching groups. Best for dedicated single-asset folders, with a safety guard when multiple groups are detected.'))], default='AUTO_GROUP')
    bpy.types.Scene.sss_allow_multi_group_texture_build = BoolProperty(name=_lt('複数グループ許可 / Allow Multi-Group Import'), description=_lt('JP: 「一致を全使用」で複数の整合グループにまたがる結果を、あえて 1 マテリアルへまとめる上級者向けオプションです。通常はオフのままにして、別アセットの混在事故を防いでください。\nEN: Expert option that allows one material build to span multiple coherent groups in All Matching mode. Leave this disabled to avoid mixing unrelated assets into the same material.'), default=False)
    bpy.types.Scene.sss_texture_batch_limit = IntProperty(name=_lt('一括上限 / Batch Limit'), description=_lt('JP: テクスチャライブラリ一括構築で一度に作成する最大マテリアル数です。大きなライブラリでも事故を避けやすい安全上限として使います。\nEN: Maximum number of materials created in one batch texture-library build. Use this as a safety limit when scanning larger libraries.'), min=1, soft_max=200, default=12)
    bpy.types.Scene.sss_texture_scope = EnumProperty(name=_lt('対象範囲 / Texture Scope'), description=_lt('JP: テクスチャ再リンクの対象範囲です。アクティブ、ターゲット、またはシーン全体から選べます。\nEN: Scope for texture relinking: active material, target material, or the whole scene.'), items=[('ACTIVE', _lt('アクティブ / Active'), _lt('JP: アクティブ材質のみ対象。 EN: Process the active material only.')), ('TARGET', _lt('ターゲット / Target'), _lt('JP: マネージャーの対象材質のみ対象。 EN: Process only the manager target material.')), ('SCENE', _lt('シーン全体 / Scene'), _lt('JP: シーン内の全マテリアルを対象。 EN: Process all scene materials.'))], default='ACTIVE')
    bpy.types.Scene.sss_mark_asset = BoolProperty(name=_lt('アセット化 / Mark Asset'), description=_lt('JP: 新規作成・取り込み時にBlenderアセットとしてマークし、アセットブラウザ管理しやすくします。\nEN: Mark materials as Blender assets during creation/capture for easier Asset Browser workflows.'), default=False)
    bpy.types.Scene.sss_assign_selected = BoolProperty(name=_lt('選択へ割当 / Assign to Selected'), description=_lt('JP: 作成や適用のあと、選択中オブジェクトへ自動で割り当てます。新しく作った材質をすぐ見たい時に便利ですが、複数オブジェクトへ一斉に反映されるので、試作時に勝手に変えたくない場合はオフにしてください。\nEN: Automatically assign the result to selected objects after create or apply. This is convenient when you want to preview the new material immediately, but remember that every selected object can be changed at once, so disable it when you are experimenting and do not want automatic reassignment.'), default=True)
    bpy.types.Scene.sss_assign_mode = EnumProperty(name=_lt('割当方式 / Assign Mode'), description=_lt('JP: マテリアルをどのスロットへ入れるかを決めます。アクティブスロットは現在のスロットだけ、先頭スロットは先頭固定、追加は新しいスロットへ追加、全スロットは全スロット置換です。\nEN: Choose where a material is assigned. Active Slot affects the current slot only, First Slot always targets slot 0, Append adds a new slot when needed, and All Slots replaces every slot on the object.'), items=[('ACTIVE_SLOT', _lt('Active Slot / アクティブスロット'), _lt('JP: 現在のアクティブスロットだけを置き換えます。初心者向けの安全な通常モードです。 EN: Replace only the current active slot. Safe default for most workflows.')), ('FIRST_SLOT', _lt('First Slot / 先頭スロット'), _lt('JP: 常に最初のスロットへ設定します。単一材質オブジェクト向けです。 EN: Always assign to the first slot. Useful for single-material objects.')), ('APPEND', _lt('Append / 追加'), _lt('JP: 既存スロットを壊さず、新しいスロットとして追加します。同一材質なら重複追加を避けます。 EN: Append as a new slot without replacing existing materials. Duplicate entries are avoided when possible.')), ('ALL_SLOTS', _lt('All Slots / 全スロット'), _lt('JP: すべてのスロットを同じ材質に置き換えます。オブジェクト全体を一括で統一したい時向けです。 EN: Replace every slot with the same material. Useful when you want a full-object override.'))], default='ACTIVE_SLOT')
    bpy.types.Scene.sss_material_target_slot_index = IntProperty(name=_lt('Material Slot', 'マテリアルスロット'), description=_lt('Choose the active object material slot used by material generation and apply operations when Active Slot assignment is used. When an object has several material slots, set this to the slot you want to replace before creating or applying a material.', 'アクティブスロット割当でマテリアル生成や適用を行うときに使う、アクティブオブジェクトのマテリアルスロット番号です。複数スロットがある場合は、作成または適用前に置き換えたいスロットを指定します。'), default=-1, min=-1, soft_min=0, soft_max=31, update=on_material_target_slot_index_update)
    bpy.types.Scene.sss_non_destructive = BoolProperty(name=_lt('非破壊 / Non-Destructive'), description=_lt('JP: 上書き前に複製を作る安全モードです。元の材質を残したまま試せるので、初心者や本番データでの作業時に特に有効です。差し替え前後を見比べたい時や、失敗時にすぐ戻したい時はオンを推奨します。\nEN: Safe mode that duplicates before editing so the original material stays intact. It is especially useful for beginners or production files because you can compare before and after states and recover quickly if the result is not what you wanted.'), default=True)
    bpy.types.Scene.sss_use_fake_user = BoolProperty(name=_lt('保持 / Fake User'), description=_lt('JP: 未使用でも保存時に消えにくくするため 保持を有効化します。まだどのオブジェクトにも割り当てていない試作材質や、ライブラリ用途で保管したい材質を守りたい時に有効です。\nEN: Enable Fake User so materials are less likely to be lost when saving. This is helpful for prototype materials that are not assigned yet, or for library materials you want to keep even when nothing currently uses them.'), default=True)
    bpy.types.Scene.sss_auto_audit_after_build = BoolProperty(name=_lt('自動監査 / Auto Audit'), description=_lt('JP: 作成や適用の直後に監査レポートを自動生成します。欠損テクスチャ、未接続ノード、管理状態などを続けて確認したい時に便利です。結果は最終レポート欄へ残るので、初めて使う人の確認用としても役立ちます。\nEN: Automatically run an audit after create or apply. This is useful when you want an immediate check for missing textures, unmanaged states, or suspicious node setups, and it is especially helpful for beginners because the result is written to the Last Report field right away.'), default=True)
    bpy.types.Scene.sss_auto_layout_after_build = BoolProperty(name=_lt('自動整列 / Auto Layout'), description=_lt('JP: 生成・再構築・自動配線の後にノードを見やすく自動整列します。ネットワークを把握しやすくしたい初心者に特に有効です。\nEN: Automatically arrange nodes after build, rebuild, or auto-wire. Especially helpful for beginners who want cleaner graphs that are easier to read.'), default=True)
    bpy.types.Scene.sss_prune_after_build = BoolProperty(name=_lt('未接続削除 / Prune Unconnected'), description=_lt('JP: 出力に接続されていないノードを自動削除します。不要ノードの蓄積を防ぎたいときに使います。\nEN: Automatically remove nodes that are not connected to the active output path. Use this to keep graphs compact and avoid dead nodes.'), default=False)
    bpy.types.Scene.sss_texture_force_rewire = BoolProperty(name=_lt('強制再配線 / Force Rewire'), description=_lt('JP: テクスチャ自動配線時に既存リンクがあっても上書きします。安全に試したい場合はオフのまま使ってください。\nEN: During texture auto-wiring, replace existing links when needed. Leave this off if you want a safer, less destructive pass.'), default=False)
    bpy.types.Scene.sss_layer_preset = EnumProperty(name=_lt('レイヤー / Smart Layer'), description=_lt('JP: 非破壊で重ねるスマートレイヤーの種類です。摩耗、錆、苔、雪、濡れ、埃などを後から加えられます。\nEN: Choose the non-destructive smart layer to overlay. Use this for wear, rust, moss, snow, wetness, or dust without rebuilding the base graph.'), items=lambda self, context: layers.layer_preset_items(context.scene if context else None))
    bpy.types.Scene.sss_layer_mask_mode = EnumProperty(name=_lt('マスク方式 / Mask Mode'), description=_lt('JP: レイヤーのかかり方を決めるマスク方式です。AUTO はレイヤー内容に応じて最も安全な方法を選び、必要に応じて既存の曲率・キャビティ・厚みマップも利用します。\nEN: Mask mode for the selected layer. AUTO chooses the safest method for the chosen layer and can reuse existing curvature, cavity, or thickness maps when they already exist.'), items=lambda self, context: layers.mask_mode_items(context.scene if context else None))
    bpy.types.Scene.sss_layer_strength = FloatProperty(name=_lt('レイヤー強度 / Layer Strength'), description=_lt('JP: レイヤーの効き具合です。0 に近いほど控えめ、1 に近いほど強く重なります。まずは 0.35 から 0.75 の間で調整すると扱いやすいです。\nEN: Overall influence of the smart layer. Lower values keep the effect subtle; higher values push it harder. Starting around 0.35 to 0.75 is usually the easiest range.'), min=0.0, soft_max=1.0, default=0.65)
    bpy.types.Scene.sss_layer_noise_scale = FloatProperty(name=_lt('ノイズ尺度 / Noise Scale'), description=_lt('JP: プロシージャルなマスクの大きさです。小さいほど大柄、大きいほど細かい揺らぎになります。\nEN: Scale for procedural mask breakup. Lower values create broader large-scale breakup; higher values create finer variation.'), min=0.1, soft_max=64.0, default=8.0)
    bpy.types.Scene.sss_layer_mask_contrast = FloatProperty(name=_lt('マスクコントラスト / Mask Contrast'), description=_lt('JP: マスクの切れ味です。高いほど境界がはっきりし、低いほど緩やかに混ざります。\nEN: Contrast of the generated or reused mask. Higher values produce crisper transitions; lower values create softer blends.'), min=0.1, soft_max=3.0, default=1.0)
    bpy.types.Scene.sss_layer_recipe_name = StringProperty(name=_lt('レシピ名 / Recipe Name'), description=_lt('JP: 現在のスマートレイヤー構成を、再利用できるレイヤーレシピとして保存するときの名前です。Substance の Smart Material に近い使い方で、複数レイヤーをまとめて再利用できます。\nEN: Name used when saving the current smart-layer stack as a reusable layer recipe. This acts like a Blender-side Smart Material style preset for multi-layer reuse.'), default='')
    bpy.types.Scene.sss_layer_recipe_pick = EnumProperty(name=_lt('保存済みレシピ / Saved Recipe'), description=_lt('JP: 保存済みのスマートレイヤーレシピを選びます。適用すると、保存されていた複数レイヤーをまとめて現在の材質へ重ねます。\nEN: Choose a saved smart-layer recipe. Applying it overlays the stored multi-layer stack onto the current material.'), items=layer_recipe_enum_items)
    bpy.types.Scene.sss_layer_recipe_library_mode = EnumProperty(name=_lt('レシピ読込方式 / Recipe Import Mode'), description=_lt('JP: レイヤーレシピライブラリの読込方式です。追加更新は既存を残しつつ同名だけ更新し、全置換は現在のレシピ保存を置き換えます。\nEN: Import mode for the layer-recipe library. Merge keeps existing entries and updates matching names, while Replace swaps the current recipe set.'), items=[('MERGE', _lt('Merge / 追加更新'), _lt('JP: 既存を残しながら同名だけ上書きします。 EN: Keep existing entries and replace only matching names.')), ('REPLACE', _lt('Replace / 全置換'), _lt('JP: 現在のレシピ保存を丸ごと置き換えます。 EN: Replace the current saved recipes entirely.'))], default='MERGE')
    bpy.types.Scene.sss_catalog_entry_name = StringProperty(name=_lt('カタログ名 / Catalog Name'), description=_lt('JP: 現在の材質を、再利用できるマテリアルカタログ項目として保存するときの名前です。見た目のスナップショットだけでなく、再構築しやすいマニフェスト情報もまとめて保持します。\nEN: Name used when saving the current material as a reusable material-catalog entry. It stores not only the visible look snapshot but also the manifest data needed for safer rebuilding and sharing.'), default='')
    bpy.types.Scene.sss_catalog_tags = StringProperty(name=_lt('カタログタグ / Catalog Tags'), description=_lt('JP: カンマ区切りのタグです。材質用途、プロジェクト名、表面種類、検索語などを入れておくと、後で英語・日本語の両方で探しやすくなります。\nEN: Comma-separated tags for use cases, project names, surface types, and search terms. Good tags make later discovery easier in both English and Japanese.'), default='')
    bpy.types.Scene.sss_catalog_search = StringProperty(name=_lt('カタログ検索 / Catalog Search'), description=_lt('JP: 保存済みカタログを名前、概要、タグ、用途ヒントで絞り込みます。手元の再利用材質を素早く探せます。\nEN: Filter saved catalog entries by name, summary, tags, and usage hints. This acts like a compact local asset-browser or material-database search for reusable looks.'), default='', update=on_catalog_search_update)
    bpy.types.Scene.sss_catalog_pick = EnumProperty(name=_lt('保存済みカタログ / Saved Catalog Entry'), description=_lt('JP: 保存済みのマテリアルカタログ項目を選びます。適用すると、保存されていた材質マニフェストを使って安全寄りに材質を復元または再構築します。\nEN: Choose a saved material-catalog entry. Applying it restores or rebuilds the stored material manifest in a safer, reusable way.'), items=catalog_entry_enum_items)
    bpy.types.Scene.sss_catalog_library_mode = EnumProperty(name=_lt('カタログ読込方式 / Catalog Import Mode'), description=_lt('JP: マテリアルカタログの読込方式です。追加更新は既存を残しつつ同名だけ更新し、全置換は現在のカタログ保存を全置換します。\nEN: Import mode for the material catalog. Merge keeps existing entries and updates matching names, while Replace swaps the entire saved catalog.'), items=[('MERGE', _lt('Merge / 追加更新'), _lt('JP: 既存項目を残しつつ同名だけ更新します。 EN: Keep existing entries and update only matching names.')), ('REPLACE', _lt('Replace / 全置換'), _lt('JP: 現在のカタログ保存を丸ごと置き換えます。 EN: Replace the entire current catalog library.'))], default='MERGE')
    bpy.types.Scene.sss_asset_search_query = StringProperty(name=_lt('スマート検索 / Smart Search'), description=_lt('JP: 組み込みプリセット、カスタムプリセット、マテリアルカタログを横断して検索します。用途語や表面名から候補を絞れます。\nEN: Search across built-in presets, custom presets, and the material catalog from one field. This acts like a compact AI-search / commander style lookup for surface names, use cases, and tags.'), default='', update=on_asset_search_update)
    bpy.types.Scene.sss_asset_search_pick = EnumProperty(name=_lt('検索結果 / Search Result'), description=_lt('JP: スマート検索で見つかった候補です。「結果を使用」で現在の選択へ反映し、「結果を適用」で直接構築・復元できます。\nEN: Result selected from Smart Search. Use Result transfers it into the current UI selection, while Apply Result builds or restores it directly.'), items=asset_search_enum_items)
    bpy.types.Scene.sss_node_query = StringProperty(name=_lt('ノード検索 / Node Search'), description=_lt('JP: アクティブまたは対象材質のノードを、名前、ラベル、種類、画像名、用途推定で絞り込みます。ノードプレビュー や SearchBar に近い確認用レンズです。\nEN: Filter nodes in the active or target material by name, label, type, image name, and guessed texture usage. This acts like a compact Node Preview / SearchBar style inspection lens.'), default='', update=on_node_query_update)
    bpy.types.Scene.sss_node_pick = EnumProperty(name=_lt('ノード候補 / Node Candidate'), description=_lt('JP: 検索に一致したノードです。Select Node で選択・アクティブ化し、Node Report で詳細を確認できます。\nEN: Node matched by the current query. Use Select Node to activate it in the graph, or Node Report for a detailed inspection summary.'), items=node_pick_enum_items, default=0)
    bpy.types.Scene.sss_photo_source = StringProperty(name=_lt('写真ソース / Photo Source'), description=_lt('JP: ベースとなる写真または画像ファイルです。写真からPBR は、この1枚から色・粗さ・高さ・法線・AOのスターターマップを生成します。完全自動の真値推定ではなく、後で整えやすい安全寄りの下地生成を目指しています。\nEN: Source photo or image file used by Photo to PBR. The operator generates starter base-color, roughness, height, normal, and AO maps from this single image. It is intentionally conservative so the result stays easier to refine later instead of over-guessing.'), subtype='FILE_PATH', default='')
    bpy.types.Scene.sss_photo_output_dir = StringProperty(name=_lt('生成先フォルダ / Output Folder'), description=_lt('JP: 生成した PBR マップと簡易マニフェストを書き出すフォルダです。空欄なら、元画像の横に スマートシェーダー 用の専用フォルダを自動作成します。\nEN: Folder used for the generated PBR maps and helper manifest. Leave it empty to create a Smart Shader output folder next to the source image automatically.'), subtype='DIR_PATH', default='')
    bpy.types.Scene.sss_photo_max_size = IntProperty(name=_lt('解析解像度上限 / Max Analyze Size'), description=_lt('JP: 解析時に使う最大辺です。大きいほど細部は残りますが、処理は重くなります。1024 から 2048 あたりが扱いやすい初期値です。\nEN: Maximum image dimension used for analysis. Higher values preserve more detail but cost more time and memory. Around 1024 to 2048 is usually a comfortable starting range.'), min=256, soft_max=4096, default=1024)
    bpy.types.Scene.sss_photo_normal_strength = FloatProperty(name=_lt('法線強度 / Normal Strength'), description=_lt('JP: 生成する法線マップの凹凸強度です。強すぎる場合は 1.0 から 2.5 付近へ下げると安定しやすいです。\nEN: Strength of the generated normal map. If the result feels too harsh, lowering it to roughly 1.0 to 2.5 usually produces a steadier starter surface.'), min=0.1, soft_max=12.0, default=3.0)
    bpy.types.Scene.sss_photo_detail_strength = FloatProperty(name=_lt('細部強調 / Detail Strength'), description=_lt('JP: 高さマップへ取り込む細部の強さです。細かい凹凸を拾いたいときは上げ、ノイズっぽさを減らしたいときは下げます。\nEN: Amount of fine detail injected into the generated height map. Raise it when you want more micro detail, or lower it when the result feels too noisy.'), min=0.2, soft_max=4.0, default=1.0)
    bpy.types.Scene.sss_npr_material_name = StringProperty(name=_lt('NPR材質名 / NPR Material Name'), description=_lt('JP: 高度NPRスタジオで作成するマテリアル名です。新規作成時の名前になり、既存の管理対象を読み込んで更新する時は識別の目印にもなります。作品用の分かりやすい名前を付けておくと、後から管理しやすくなります。\nEN: Material name used by the Advanced NPR Studio builder. It becomes the name of newly created NPR materials and also helps you identify the correct managed material later when loading and updating an existing NPR setup.'), default='NPR Studio Pro')
    bpy.types.Scene.sss_npr_zone_count = IntProperty(name=_lt('ゾーン数 / Zone Count'), description=_lt('JP: 表示するトゥーン段数です。少ない段数はシンプルでアニメ調、多い段数は情報量が増えて細かい塗り分けに向きます。まずは 3 か 4 から試し、境界が多すぎると感じたら減らしてください。\nEN: Number of toon shading zones to expose. Fewer zones create a simpler anime-style result, while more zones give you finer control over color separation. Starting with 3 or 4 is usually a good beginner choice.'), default=4, min=2, max=4)
    bpy.types.Scene.sss_npr_base_color = FloatVectorProperty(name=_lt('ライト色 / Light Color'), subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.88, 0.72, 0.68, 1.0))
    bpy.types.Scene.sss_npr_zone2_color = FloatVectorProperty(name=_lt('ゾーン2色 / Zone 2'), subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.64, 0.48, 0.48, 1.0))
    bpy.types.Scene.sss_npr_zone3_color = FloatVectorProperty(name=_lt('ゾーン3色 / Zone 3'), subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.36, 0.24, 0.28, 1.0))
    bpy.types.Scene.sss_npr_zone4_color = FloatVectorProperty(name=_lt('ゾーン4色 / Zone 4'), subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.15, 0.1, 0.14, 1.0))
    bpy.types.Scene.sss_npr_threshold_1 = FloatProperty(name=_lt('境界1 / Threshold 1'), default=0.72, min=0.05, max=0.98)
    bpy.types.Scene.sss_npr_threshold_2 = FloatProperty(name=_lt('境界2 / Threshold 2'), default=0.48, min=0.03, max=0.96)
    bpy.types.Scene.sss_npr_threshold_3 = FloatProperty(name=_lt('境界3 / Threshold 3'), default=0.24, min=0.01, max=0.94)
    bpy.types.Scene.sss_npr_shadow_smooth = FloatProperty(name=_lt('境界のなめらかさ / Shadow Smooth'), default=0.03, min=0.0, max=0.25)
    bpy.types.Scene.sss_npr_alpha = FloatProperty(name=_lt('アルファ / Alpha'), default=1.0, min=0.0, max=1.0)
    bpy.types.Scene.sss_npr_highlight_color = FloatVectorProperty(name=_lt('ハイライト色 / Highlight Color'), subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0, 1.0, 1.0, 1.0))
    bpy.types.Scene.sss_npr_highlight_level = FloatProperty(name=_lt('ハイライト強度 / Highlight Level'), default=0.28, min=0.0, max=2.0)
    bpy.types.Scene.sss_npr_highlight_size = FloatProperty(name=_lt('ハイライトサイズ / Highlight Size'), default=0.12, min=0.02, max=0.95)
    bpy.types.Scene.sss_npr_highlight_smooth = FloatProperty(name=_lt('ハイライトなめらかさ / Highlight Smooth'), default=0.04, min=0.0, max=0.5)
    bpy.types.Scene.sss_npr_reflection_color = FloatVectorProperty(name=_lt('反射色 / Reflection Color'), subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0, 1.0, 1.0, 1.0))
    bpy.types.Scene.sss_npr_reflection_strength = FloatProperty(name=_lt('反射強度 / Reflection Strength'), default=0.16, min=0.0, max=2.0)
    bpy.types.Scene.sss_npr_reflection_roughness = FloatProperty(name=_lt('反射ラフネス / Reflection Roughness'), default=0.08, min=0.0, max=1.0)
    bpy.types.Scene.sss_npr_rim_color = FloatVectorProperty(name=_lt('リム色 / Rim Color'), subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0, 1.0, 1.0, 1.0))
    bpy.types.Scene.sss_npr_rim_width = FloatProperty(name=_lt('リム幅 / Rim Width'), default=0.9, min=0.1, max=0.98)
    bpy.types.Scene.sss_npr_rim_strength = FloatProperty(name=_lt('リム強度 / Rim Strength'), default=0.85, min=0.0, max=4.0)
    bpy.types.Scene.sss_npr_detail_scale = FloatProperty(name=_lt('法線ディテール / Detail Scale'), default=24.0, min=1.0, max=300.0)
    bpy.types.Scene.sss_npr_detail_normal = FloatProperty(name=_lt('法線強度 / Detail Normal'), default=0.03, min=0.0, max=1.0)
    bpy.types.Scene.sss_npr_hatch_enable = BoolProperty(name=_lt('ハッチ有効 / Hatch'), default=True)
    bpy.types.Scene.sss_npr_hatch_color = FloatVectorProperty(name=_lt('ハッチ色 / Hatch Color'), subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.05, 0.05, 0.05, 1.0))
    bpy.types.Scene.sss_npr_hatch_scale = FloatProperty(name=_lt('ハッチスケール / Hatch Scale'), default=48.0, min=1.0, max=300.0)
    bpy.types.Scene.sss_npr_hatch_strength = FloatProperty(name=_lt('ハッチ強度 / Hatch Strength'), default=0.22, min=0.0, max=1.0)
    bpy.types.Scene.sss_npr_hatch_softness = FloatProperty(name=_lt('ハッチ境界 / Hatch Softness'), default=0.16, min=0.0, max=1.0)
    bpy.types.Scene.sss_npr_hatch_angle = FloatProperty(name=_lt('ハッチ角度 / Hatch Angle'), default=0.78539816339, min=-3.1415926535, max=3.1415926535, subtype='ANGLE')
    bpy.types.Scene.sss_npr_hatch_cross_enable = BoolProperty(name=_lt('クロスハッチ / Cross Hatch'), default=False)
    bpy.types.Scene.sss_npr_hatch_cross_angle = FloatProperty(name=_lt('クロス角度 / Cross Angle'), default=-0.78539816339, min=-3.1415926535, max=3.1415926535, subtype='ANGLE')
    bpy.types.Scene.sss_npr_hatch_cross_strength = FloatProperty(name=_lt('クロス強度 / Cross Strength'), default=0.08, min=0.0, max=1.0)
    bpy.types.Scene.sss_npr_halftone_enable = BoolProperty(name=_lt('ハーフトーン有効 / Halftone'), default=False)
    bpy.types.Scene.sss_npr_halftone_color = FloatVectorProperty(name=_lt('ハーフトーン色 / Halftone Color'), subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.05, 0.05, 0.05, 1.0))
    bpy.types.Scene.sss_npr_halftone_scale = FloatProperty(name=_lt('ハーフトーンスケール / Halftone Scale'), default=30.0, min=1.0, max=300.0)
    bpy.types.Scene.sss_npr_halftone_strength = FloatProperty(name=_lt('ハーフトーン強度 / Halftone Strength'), default=0.18, min=0.0, max=1.0)
    bpy.types.Scene.sss_npr_halftone_threshold = FloatProperty(name=_lt('ハーフトーン閾値 / Halftone Threshold'), default=0.58, min=0.02, max=0.98)
    bpy.types.Scene.sss_npr_halftone_softness = FloatProperty(name=_lt('ドット境界 / Dot Softness'), default=0.16, min=0.0, max=0.49)
    bpy.types.Scene.sss_npr_halftone_rotation = FloatProperty(name=_lt('ドット角度 / Dot Rotation'), default=0.0, min=-3.1415926535, max=3.1415926535, subtype='ANGLE')
    bpy.types.Scene.sss_npr_paper_tint = FloatVectorProperty(name=_lt('紙色 / Paper Tint'), subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0, 1.0, 1.0, 1.0))
    bpy.types.Scene.sss_npr_paper_scale = FloatProperty(name=_lt('紙スケール / Paper Scale'), default=10.0, min=0.1, max=200.0)
    bpy.types.Scene.sss_npr_paper_strength = FloatProperty(name=_lt('紙強度 / Paper Strength'), default=0.08, min=0.0, max=1.0)
    bpy.types.Scene.sss_hdri_path = StringProperty(name=_lt('HDRIファイル / HDRI File'), description=_lt('JP: 環境ライティングに使う HDRI / EXR ファイルです。HDRIワールド構築 で現在のシーンワールドへ読み込みます。\nEN: HDRI or EXR file used for environment lighting. Build HDRI World loads it into the current scene world.'), subtype='FILE_PATH', default='')
    bpy.types.Scene.sss_hdri_strength = FloatProperty(name=_lt('HDRI強度 / HDRI Strength'), description=_lt('JP: ワールド背景の明るさです。見た目の変化が大きいので、まずは 0.5 から 2.0 付近で調整すると扱いやすいです。\nEN: Brightness of the world background. Start around 0.5 to 2.0 for most lookdev scenes.'), min=0.0, soft_max=10.0, default=1.0)
    bpy.types.Scene.sss_hdri_rotation = FloatProperty(name=_lt('HDRI回転 / HDRI Rotation'), description=_lt('JP: HDRI の水平回転です。ハイライトや反射の向きを変えたいときに使います。\nEN: Horizontal HDRI rotation. Use this to rotate reflections and the main light direction.'), subtype='ANGLE', default=0.0)
    bpy.types.Scene.sss_hdri_library_root = StringProperty(name=_lt('HDRIライブラリ / HDRI Library'), description=_lt('JP: HDRI 検索に使うルートフォルダです。Poly Haven や社内ライブラリのような大きな環境フォルダを指定し、検索欄と候補一覧から目的のHDRIを素早く選べます。\nEN: Root folder used for HDRI search. Point this to a larger environment library, then use the search field and candidate list to pick a lighting map quickly.'), subtype='DIR_PATH', default='', update=on_hdri_library_root_update)
    bpy.types.Scene.sss_hdri_search = StringProperty(name=_lt('HDRI検索 / HDRI Search'), description=_lt('JP: HDRI ライブラリ候補を名前やフォルダ名で絞り込みます。製品CG、屋外、スタジオなど用途に応じて環境マップを探しやすくするための検索欄です。\nEN: Filter HDRI-library candidates by name or folder. This makes it easier to locate studio, outdoor, product-CGI, or other environment maps inside larger libraries.'), default='', update=on_hdri_search_update)
    bpy.types.Scene.sss_hdri_pick = EnumProperty(name=_lt('HDRI候補 / HDRI Candidate'), description=_lt('JP: 検索結果に一致した HDRI 候補です。Use HDRI で現在の構築対象へ反映し、Apply HDRI でそのままワールドへ適用できます。\nEN: HDRI candidate matched by the current library search. Use HDRI transfers it into the current build target, while Apply HDRI builds the world immediately from the selection.'), items=hdri_search_enum_items)
    bpy.types.Scene.sss_cleanup_recursive = BoolProperty(name=_lt('再帰パージ / Recursive Purge'), description=_lt('JP: 可能なら孤立データの削除を再帰実行して未使用データを深く掃除します。\nEN: When possible, run recursive orphan purge for a deeper cleanup of unused data.'), default=True)
    bpy.types.Scene.sss_batch_doctor_scope = EnumProperty(name=_lt('診断範囲 / Doctor Scope'), description=_lt('JP: シーンドクターが処理する材質の範囲です。アクティブは現在材質、ターゲットはターゲット材質、選択オブジェクトは選択物、管理材質は管理中の材質、シーンはシーン全体です。\nEN: Material scope processed by Scene Doctor. Active uses the current material, Target uses the manager target, Selected uses the current selection, Managed limits to Smart Shader materials, and Scene scans the whole scene.'), items=[('ACTIVE', _lt('Active / アクティブ材質'), _lt('JP: 現在のアクティブ材質だけを対象にします。 EN: Process only the active material.')), ('TARGET', _lt('Target / ターゲット材質'), _lt('JP: ターゲット材質だけを対象にします。 EN: Process only the target material.')), ('SELECTED', _lt('Selected / 選択オブジェクト'), _lt('JP: 選択オブジェクトで使われている材質を対象にします。 EN: Process materials used by selected objects.')), ('MANAGED', _lt('Managed / 管理材質'), _lt('JP: スマートシェーダー 管理中の材質を対象にします。 EN: Process only Smart Shader managed materials.')), ('SCENE', _lt('Scene / シーン全体'), _lt('JP: シーン全体の材質を対象にします。 EN: Process materials across the whole scene.'))], default='SCENE')
    bpy.types.Scene.sss_batch_doctor_filter = StringProperty(name=_lt('診断フィルタ / Doctor Filter'), description=_lt('JP: 材質名、ビルダー名、タグでシーンドクター対象を絞り込みます。\nEN: Narrow Scene Doctor targets by material name, builder name, or tags.'), default='')
    bpy.types.Scene.sss_batch_doctor_limit = IntProperty(name=_lt('上限 / Limit'), description=_lt('JP: 1回のシーンドクターで処理する材質数の安全上限です。\nEN: Safety cap for how many materials Scene Doctor processes in one run.'), default=64, min=1, soft_max=512, max=10000)
    bpy.types.Scene.sss_batch_doctor_relink_missing = BoolProperty(name=_lt('欠損画像を再リンク / Relink Missing Images'), description=_lt('JP: テクスチャ検索ルートが指定されている場合、欠損画像の再リンクも一緒に試みます。\nEN: When a texture search root is set, also try to relink missing images during Scene Doctor.'), default=True)
    bpy.types.Scene.sss_quick_action_search = StringProperty(name=_lt('クイック検索 / Quick Search'), description=_lt('JP: クイック操作を名前、説明、キーワードで絞り込みます。Commander や SearchBar のように、英語・日本語の両方で探せます。\nEN: Filter quick actions by name, summary, and keywords. Search in English or Japanese like a compact commander/search bar.'), default='', update=on_quick_action_search_update)
    bpy.types.Scene.sss_quick_action = EnumProperty(name=_lt('クイック操作 / Quick Action'), description=_lt('JP: よく使う操作を検索しながら選べるコマンドランチャーです。初心者は探しやすく、上級者は移動を減らせます。\nEN: Searchable command launcher for common actions. It helps beginners find the right tool and lets advanced users move faster.'), items=quick_action_enum_items)
    bpy.types.Scene.sss_scene_variant_name = StringProperty(name=_lt('バリアント名 / Variant Name'), description=_lt('JP: シーン全体の材質割り当てと HDRI 状態を保存する名前です。ルック案やショット別バリエーションの管理に使えます。\nEN: Name for saving scene-wide material-slot assignments and HDRI state. Useful for lookdev options and shot variants.'), default='')
    bpy.types.Scene.sss_scene_variant_pick = EnumProperty(name=_lt('保存済みバリアント / Saved Variant'), description=_lt('JP: 保存済みのシーンバリアントを選びます。適用で材質スロットと HDRI 状態を復元します。\nEN: Choose a saved scene variant. Apply restores material slots and HDRI state.'), items=scene_variant_enum_items)
    bpy.types.Scene.sss_custom_library_mode = EnumProperty(name=_lt('読込方式 / Library Import Mode'), description=_lt('JP: カスタムプリセットライブラリの読み込み方式です。追加更新は既存を残しつつ同名だけ更新し、全置換は現在のライブラリを置き換えます。\nEN: Import mode for the custom preset library. Merge keeps existing entries and updates matching names, while Replace swaps the whole library.'), items=[('MERGE', _lt('Merge / 追加更新'), _lt('JP: 既存を残しながら同名だけ上書きします。 EN: Keep existing entries and replace only matching names.')), ('REPLACE', _lt('Replace / 全置換'), _lt('JP: 現在のライブラリを丸ごと置き換えます。 EN: Replace the current library entirely.'))], default='MERGE')
    bpy.types.Scene.sss_scene_variant_library_mode = EnumProperty(name=_lt('バリアント読込方式 / Variant Import Mode'), description=_lt('JP: シーンバリアントライブラリの読み込み方式です。追加更新は既存を残しつつ同名だけ更新し、全置換は現在のバリアント保存を置き換えます。\nEN: Import mode for the scene variant library. Merge keeps existing entries and updates matching names, while Replace swaps the whole saved variant set.'), items=[('MERGE', _lt('Merge / 追加更新'), _lt('JP: 既存を残しながら同名だけ上書きします。 EN: Keep existing entries and replace only matching names.')), ('REPLACE', _lt('Replace / 全置換'), _lt('JP: 現在のバリアント保存を丸ごと置き換えます。 EN: Replace the current saved variants entirely.'))], default='MERGE')
    bpy.types.Scene.sss_rule_name = StringProperty(name=_lt('ルール名 / Rule Name'), description=_lt('JP: 一括材質割当ルールの保存名です。後から再利用しやすいよう、用途や対象を含む名前にすると管理しやすくなります。\nEN: Saved name for a batch material-assignment rule. Include the intent or target in the name so it stays easy to reuse later.'), default='')
    bpy.types.Scene.sss_rule_search = StringProperty(name=_lt('ルール検索 / Rule Search'), description=_lt('JP: 保存済み割当ルールを名前、対象材質、条件、タグで検索します。\nEN: Search saved assignment rules by name, target material, conditions, or tags.'), default='', update=on_assign_rule_update)
    bpy.types.Scene.sss_rule_pick = EnumProperty(name=_lt('保存済みルール / Saved Rule'), description=_lt('JP: 保存済みの一括割当ルールです。確認や実行の対象をここで選びます。\nEN: Saved batch-assignment rule used by preview and apply actions.'), items=assign_rule_enum_items)
    bpy.types.Scene.sss_rule_object_pattern = StringProperty(name=_lt('オブジェクト条件 / Object Match'), description=_lt('JP: オブジェクト名の一致条件です。正規表現がオフなら部分一致またはワイルドカード、オンなら正規表現として扱います。\nEN: Object-name match condition. With regex off it behaves like contains/wildcard matching; with regex on it is treated as a regular expression.'), default='')
    bpy.types.Scene.sss_rule_collection_pattern = StringProperty(name=_lt('コレクション条件 / Collection Match'), description=_lt('JP: コレクション名の一致条件です。空欄ならコレクション条件は使いません。\nEN: Collection-name match condition. Leave empty to skip collection filtering.'), default='')
    bpy.types.Scene.sss_rule_current_material_pattern = StringProperty(name=_lt('現在材質条件 / Current Material Match'), description=_lt('JP: 現在そのオブジェクトに入っている材質名の一致条件です。置換前の材質を絞りたいときに使います。\nEN: Match condition for materials already assigned to an object. Use this when the rule should only affect objects with specific current materials.'), default='')
    bpy.types.Scene.sss_rule_use_regex = BoolProperty(name=_lt('正規表現 / Regex'), description=_lt('JP: 条件欄を正規表現として扱います。オフなら部分一致またはワイルドカードとして扱うので初心者向けです。\nEN: Treat rule conditions as regular expressions. Leave this off for simpler contains/wildcard matching.'), default=False)
    bpy.types.Scene.sss_rule_scope = EnumProperty(name=_lt('ルール範囲 / Rule Scope'), description=_lt('JP: ルールをシーン全体へ適用するか、現在選択中だけに限定するかを保存します。\nEN: Store whether the rule applies scene-wide or only to the current selection.'), items=[('SELECTED', _lt('Selected Objects / 選択オブジェクト'), _lt('JP: 現在選択中のオブジェクトだけを対象にします。 EN: Affect only the current selection.')), ('SCENE', _lt('Scene / シーン全体'), _lt('JP: シーン内の全オブジェクトを対象にします。 EN: Affect all scene objects.'))], default='SELECTED')
    bpy.types.Scene.sss_rule_library_mode = EnumProperty(name=_lt('ルール読込方式 / Rule Import Mode'), description=_lt('JP: 割当ルール JSON の読み込み方式です。追加更新は追加更新、全置換は全置換です。\nEN: Import mode for assignment-rule JSON files. Merge adds or updates by name, Replace swaps the whole rule library.'), items=[('MERGE', _lt('Merge / 追加更新'), _lt('JP: 既存ルールを残しつつ同名だけ更新します。 EN: Keep existing rules and update matching names.')), ('REPLACE', _lt('Replace / 全置換'), _lt('JP: 現在のルールライブラリを丸ごと置き換えます。 EN: Replace the current rule library entirely.'))], default='MERGE')
    bpy.types.Scene.sss_last_report = StringProperty(name=_lt('最終レポート / Last Report'), description=_lt('JP: 監査、自己診断、書き出し、再リンクなどの最新ログです。ボタン実行後に何が起きたかを確認するための読み取り専用メモとして使えます。エラーだけでなく、修正件数や処理対象の要約もここで確認できます。\nEN: Stores the latest audit, self-check, export, and relink log. Think of this as a read-only memo that tells you what happened after running a tool, including not only errors but also summaries such as how many items were repaired or processed.'), get=_scene_last_report_get, set=_scene_last_report_set, options={'SKIP_SAVE'})
    _register_scene_persistence_handler()

def _enum_first_id(items, fallback=''):
    if not items:
        return fallback
    first = items[0]
    if isinstance(first, (tuple, list)) and first:
        return str(first[0])
    return fallback

def sanitize_legacy_scene_enum_values(scene=None) -> None:
    try:
        if scene is None:
            _repair_all_scenes_legacy_enum_values(require_rna=False)
        else:
            _repair_legacy_scene_enum_values(scene, require_rna=False)
    except Exception:
        pass

def initialize_scene_defaults(scene=None):
    if scene is not None:
        scenes = [scene]
    else:
        scenes = list(getattr(getattr(bpy, 'data', None), 'scenes', []) or [])
    for scene in scenes:
        try:
            _repair_legacy_scene_enum_values(scene, require_rna=True)
        except Exception:
            pass
        if _scene_defaults_initialized(scene):
            try:
                save_persistent_scene_settings(scene, force=True)
            except Exception:
                pass
            continue
        try:
            apply_persistent_scene_settings(scene)
        except Exception:
            pass
        try:
            current_family = getattr(scene, 'sss_preset_family', '') or ''
            if not current_family:
                scene.sss_preset_family = _enum_first_id(family_enum_items(scene), 'PBR')
        except Exception:
            pass
        try:
            current_preset = getattr(scene, 'sss_preset_name', '') or ''
            if not current_preset:
                ctx = type('_Ctx', (), {'scene': scene})()
                scene.sss_preset_name = _enum_first_id(preset_enum_items(None, ctx), '')
        except Exception:
            pass
        try:
            current_workspace = getattr(scene, 'sss_workspace_recipe', '') or ''
            if not current_workspace:
                ctx = type('_Ctx', (), {'scene': scene})()
                scene.sss_workspace_recipe = _enum_first_id(workspace_recipe_enum_items(None, ctx), 'BUILD_PRESET')
        except Exception:
            pass
        try:
            current_feature_group = getattr(scene, 'sss_feature_group', '') or ''
            if not current_feature_group:
                ctx = type('_Ctx', (), {'scene': scene})()
                scene.sss_feature_group = _enum_first_id(feature_browser_group_enum_items(None, ctx), 'BUILD')
        except Exception:
            pass
        try:
            current_feature_panel = getattr(scene, 'sss_feature_panel', '') or ''
            if not current_feature_panel:
                ctx = type('_Ctx', (), {'scene': scene})()
                scene.sss_feature_panel = _enum_first_id(feature_browser_panel_enum_items(None, ctx), 'BUILD_APPLY')
        except Exception:
            pass
        try:
            current_layer_preset = getattr(scene, 'sss_layer_preset', '') or ''
            if not current_layer_preset:
                ctx = type('_Ctx', (), {'scene': scene})()
                scene.sss_layer_preset = _enum_first_id(layers.layer_preset_items(scene), 'EDGE_WEAR_LAYER')
        except Exception:
            pass
        try:
            current_layer_mask = getattr(scene, 'sss_layer_mask_mode', '') or ''
            if not current_layer_mask:
                ctx = type('_Ctx', (), {'scene': scene})()
                scene.sss_layer_mask_mode = _enum_first_id(layers.mask_mode_items(scene), 'AUTO')
        except Exception:
            pass
        try:
            current_quick = getattr(scene, 'sss_quick_action', '') or ''
            if not current_quick:
                ctx = type('_Ctx', (), {'scene': scene})()
                scene.sss_quick_action = _enum_first_id(quick_action_enum_items(None, ctx), 'QUICK_FIX')
        except Exception:
            pass
        try:
            current_asset_search = getattr(scene, 'sss_asset_search_pick', '') or ''
            if not current_asset_search:
                ctx = type('_Ctx', (), {'scene': scene})()
                normalize_selected_asset_search(scene, ctx)
        except Exception:
            pass
        try:
            current_inventory = scene_raw_enum_value(scene, 'sss_inventory_pick', '') or ''
            if current_inventory in {'0', 'NONE'}:
                _set_scene_enum_value(scene, 'sss_inventory_pick', '')
                current_inventory = ''
            if not current_inventory:
                ctx = type('_Ctx', (), {'scene': scene})()
                normalize_selected_inventory(scene, ctx)
        except Exception:
            pass
        try:
            current_node_pick = scene_raw_enum_value(scene, 'sss_node_pick', '') or ''
            if current_node_pick in {'', '0', 'NONE'}:
                _set_scene_enum_value(scene, 'sss_node_pick', finder.NODE_PICK_SENTINEL, use_rna=False)
                current_node_pick = finder.NODE_PICK_SENTINEL
            if not current_node_pick:
                ctx = type('_Ctx', (), {'scene': scene, 'material': None, 'object': None})()
                normalize_selected_node_pick(scene, ctx)
        except Exception:
            pass
        try:
            current_variant = getattr(scene, 'sss_scene_variant_pick', '') or ''
            if not current_variant:
                ctx = type('_Ctx', (), {'scene': scene})()
                normalize_selected_scene_variant(scene, ctx)
        except Exception:
            pass
        try:
            current_layer_recipe = getattr(scene, 'sss_layer_recipe_pick', '') or ''
            if not current_layer_recipe:
                ctx = type('_Ctx', (), {'scene': scene})()
                normalize_selected_layer_recipe(scene, ctx)
        except Exception:
            pass
        try:
            current_catalog = getattr(scene, 'sss_catalog_pick', '') or ''
            if not current_catalog:
                ctx = type('_Ctx', (), {'scene': scene})()
                normalize_selected_catalog_entry(scene, ctx)
        except Exception:
            pass
        try:
            current_rule = getattr(scene, 'sss_rule_pick', '') or ''
            if not current_rule:
                ctx = type('_Ctx', (), {'scene': scene})()
                normalize_selected_assign_rule(scene, ctx)
        except Exception:
            pass
        try:
            current_hdri = getattr(scene, 'sss_hdri_pick', '') or ''
            if not current_hdri:
                ctx = type('_Ctx', (), {'scene': scene})()
                normalize_selected_hdri_search(scene, ctx)
        except Exception:
            pass
        _set_scene_defaults_initialized(scene)
        try:
            save_persistent_scene_settings(scene, force=True)
        except Exception:
            pass

def ensure_scene_defaults(context_or_scene=None):
    scene = getattr(context_or_scene, 'scene', context_or_scene)
    if scene is None:
        return
    try:
        _repair_legacy_scene_enum_values(scene, require_rna=True)
    except Exception:
        pass
    if _scene_defaults_initialized(scene):
        return
    initialize_scene_defaults(scene)

def unregister_properties():
    _unregister_scene_persistence_handler()
    clear_enum_item_cache()
    for prop in ('sss_ui_section', 'sss_workspace_recipe', 'sss_show_advanced', 'sss_feature_group', 'sss_feature_panel', 'sss_preset_family', 'sss_preset_genre', 'sss_preset_search', 'sss_preset_name', 'sss_pbr_preset_family', 'sss_pbr_preset_genre', 'sss_pbr_preset_name', 'sss_material_name', 'sss_target_material_name', 'sss_custom_preset_name', 'sss_compare_source_material_name', 'sss_replace_scope', 'sss_inventory_search', 'sss_inventory_scope', 'sss_inventory_sort', 'sss_inventory_pick', 'sss_texture_search_root', 'sss_texture_set_filter', 'sss_texture_import_mode', 'sss_allow_multi_group_texture_build', 'sss_texture_batch_limit', 'sss_texture_scope', 'sss_mark_asset', 'sss_assign_selected', 'sss_assign_mode', 'sss_material_target_slot_index', 'sss_non_destructive', 'sss_use_fake_user', 'sss_auto_audit_after_build', 'sss_auto_layout_after_build', 'sss_prune_after_build', 'sss_texture_force_rewire', 'sss_layer_preset', 'sss_layer_mask_mode', 'sss_layer_strength', 'sss_layer_noise_scale', 'sss_layer_mask_contrast', 'sss_layer_recipe_name', 'sss_layer_recipe_pick', 'sss_layer_recipe_library_mode', 'sss_catalog_entry_name', 'sss_catalog_tags', 'sss_catalog_search', 'sss_catalog_pick', 'sss_catalog_library_mode', 'sss_asset_search_query', 'sss_asset_search_pick', 'sss_node_query', 'sss_node_pick', 'sss_photo_source', 'sss_photo_output_dir', 'sss_photo_max_size', 'sss_photo_normal_strength', 'sss_photo_detail_strength', 'sss_npr_material_name', 'sss_npr_zone_count', 'sss_npr_base_color', 'sss_npr_zone2_color', 'sss_npr_zone3_color', 'sss_npr_zone4_color', 'sss_npr_threshold_1', 'sss_npr_threshold_2', 'sss_npr_threshold_3', 'sss_npr_shadow_smooth', 'sss_npr_alpha', 'sss_npr_highlight_color', 'sss_npr_highlight_level', 'sss_npr_highlight_size', 'sss_npr_highlight_smooth', 'sss_npr_reflection_color', 'sss_npr_reflection_strength', 'sss_npr_reflection_roughness', 'sss_npr_rim_color', 'sss_npr_rim_width', 'sss_npr_rim_strength', 'sss_npr_detail_scale', 'sss_npr_detail_normal', 'sss_npr_hatch_enable', 'sss_npr_hatch_color', 'sss_npr_hatch_scale', 'sss_npr_hatch_strength', 'sss_npr_hatch_softness', 'sss_npr_hatch_angle', 'sss_npr_hatch_cross_enable', 'sss_npr_hatch_cross_angle', 'sss_npr_hatch_cross_strength', 'sss_npr_halftone_enable', 'sss_npr_halftone_color', 'sss_npr_halftone_scale', 'sss_npr_halftone_strength', 'sss_npr_halftone_threshold', 'sss_npr_halftone_softness', 'sss_npr_halftone_rotation', 'sss_npr_paper_tint', 'sss_npr_paper_scale', 'sss_npr_paper_strength', 'sss_hdri_path', 'sss_hdri_strength', 'sss_hdri_rotation', 'sss_hdri_library_root', 'sss_hdri_search', 'sss_hdri_pick', 'sss_cleanup_recursive', 'sss_batch_doctor_scope', 'sss_batch_doctor_filter', 'sss_batch_doctor_limit', 'sss_batch_doctor_relink_missing', 'sss_quick_action_search', 'sss_quick_action', 'sss_scene_variant_name', 'sss_scene_variant_pick', 'sss_custom_library_mode', 'sss_scene_variant_library_mode', 'sss_rule_name', 'sss_rule_search', 'sss_rule_pick', 'sss_rule_object_pattern', 'sss_rule_collection_pattern', 'sss_rule_current_material_pattern', 'sss_rule_use_regex', 'sss_rule_scope', 'sss_rule_library_mode', 'sss_last_report'):
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)
CLASSES = tuple()


# -----------------------------------------------------------------------------
# Smart Shader Suite 5.18.224 exact-owned Scene RNA and load-safe persistence.
# -----------------------------------------------------------------------------
_SSS_V1208_SCENE_PROPERTY_NAMES = ('sss_allow_multi_group_texture_build', 'sss_asset_search_pick', 'sss_asset_search_query', 'sss_assign_mode', 'sss_assign_selected', 'sss_auto_audit_after_build', 'sss_auto_layout_after_build', 'sss_batch_doctor_filter', 'sss_batch_doctor_limit', 'sss_batch_doctor_relink_missing', 'sss_batch_doctor_scope', 'sss_catalog_entry_name', 'sss_catalog_library_mode', 'sss_catalog_pick', 'sss_catalog_search', 'sss_catalog_tags', 'sss_cleanup_recursive', 'sss_compare_source_material_name', 'sss_custom_library_mode', 'sss_custom_preset_name', 'sss_feature_group', 'sss_feature_panel', 'sss_hdri_library_root', 'sss_hdri_path', 'sss_hdri_pick', 'sss_hdri_rotation', 'sss_hdri_search', 'sss_hdri_strength', 'sss_inventory_pick', 'sss_inventory_scope', 'sss_inventory_search', 'sss_inventory_sort', 'sss_last_report', 'sss_layer_mask_contrast', 'sss_layer_mask_mode', 'sss_layer_noise_scale', 'sss_layer_preset', 'sss_layer_recipe_library_mode', 'sss_layer_recipe_name', 'sss_layer_recipe_pick', 'sss_layer_strength', 'sss_mark_asset', 'sss_material_name', 'sss_material_target_slot_index', 'sss_node_pick', 'sss_node_query', 'sss_non_destructive', 'sss_npr_alpha', 'sss_npr_base_color', 'sss_npr_detail_normal', 'sss_npr_detail_scale', 'sss_npr_halftone_color', 'sss_npr_halftone_enable', 'sss_npr_halftone_rotation', 'sss_npr_halftone_scale', 'sss_npr_halftone_softness', 'sss_npr_halftone_strength', 'sss_npr_halftone_threshold', 'sss_npr_hatch_angle', 'sss_npr_hatch_color', 'sss_npr_hatch_cross_angle', 'sss_npr_hatch_cross_enable', 'sss_npr_hatch_cross_strength', 'sss_npr_hatch_enable', 'sss_npr_hatch_scale', 'sss_npr_hatch_softness', 'sss_npr_hatch_strength', 'sss_npr_highlight_color', 'sss_npr_highlight_level', 'sss_npr_highlight_size', 'sss_npr_highlight_smooth', 'sss_npr_material_name', 'sss_npr_paper_scale', 'sss_npr_paper_strength', 'sss_npr_paper_tint', 'sss_npr_reflection_color', 'sss_npr_reflection_roughness', 'sss_npr_reflection_strength', 'sss_npr_rim_color', 'sss_npr_rim_strength', 'sss_npr_rim_width', 'sss_npr_shadow_smooth', 'sss_npr_threshold_1', 'sss_npr_threshold_2', 'sss_npr_threshold_3', 'sss_npr_zone2_color', 'sss_npr_zone3_color', 'sss_npr_zone4_color', 'sss_npr_zone_count', 'sss_pbr_preset_family', 'sss_pbr_preset_genre', 'sss_pbr_preset_name', 'sss_photo_detail_strength', 'sss_photo_max_size', 'sss_photo_normal_strength', 'sss_photo_output_dir', 'sss_photo_source', 'sss_preset_family', 'sss_preset_genre', 'sss_preset_name', 'sss_preset_search', 'sss_prune_after_build', 'sss_quick_action', 'sss_quick_action_search', 'sss_replace_scope', 'sss_rule_collection_pattern', 'sss_rule_current_material_pattern', 'sss_rule_library_mode', 'sss_rule_name', 'sss_rule_object_pattern', 'sss_rule_pick', 'sss_rule_scope', 'sss_rule_search', 'sss_rule_use_regex', 'sss_scene_variant_library_mode', 'sss_scene_variant_name', 'sss_scene_variant_pick', 'sss_show_advanced', 'sss_target_material_name', 'sss_texture_batch_limit', 'sss_texture_force_rewire', 'sss_texture_import_mode', 'sss_texture_scope', 'sss_texture_search_root', 'sss_texture_set_filter', 'sss_ui_section', 'sss_use_fake_user', 'sss_workspace_recipe')
_SSS_V1208_OWNED_SCENE_PROPERTIES = []
_SSS_V1208_HANDLER_LEDGER = []
_sss_v1208_legacy_register_properties = register_properties


@persistent
def _apply_persistent_scene_settings_on_load(_dummy=None):
    """Restore only the active Scene scalar state and bounded profile cache."""
    scenes = list(getattr(getattr(bpy, 'data', None), 'scenes', []) or [])
    for scene in scenes:
        _clear_scene_session_state(scene)
        _clear_legacy_raw_scene_bookkeeping(scene)
    scene = getattr(getattr(bpy, 'context', None), 'scene', None)
    if scene is not None:
        try:
            apply_persistent_scene_settings(scene)
        except Exception:
            pass
    try:
        from . import smart_toon as _smart_toon
        restore = getattr(_smart_toon, 'restore_smart_toon_profile_scalars_on_load', None)
        if callable(restore):
            restore(getattr(bpy, 'context', None))
    except Exception:
        pass
    _register_scene_change_subscription()


def _register_scene_persistence_handler() -> None:
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return
    # The central preferences load_post performs the single bounded scalar
    # restore.  This module owns only its explicit save boundary and msgbus
    # subscription; no duplicate file-open callback is installed.
    if not storage.npanel_state_save_enabled(default=True):
        return
    for container_name, callback in (
        ('save_pre', _save_persistent_scene_settings_on_save),
    ):
        container = getattr(handlers, container_name, None)
        if container is not None and callback not in container:
            container.append(callback)
            _SSS_V1208_HANDLER_LEDGER.append((container, callback))
    _register_scene_change_subscription()


def _unregister_scene_persistence_handler() -> None:
    for container, callback in reversed(tuple(_SSS_V1208_HANDLER_LEDGER)):
        try:
            if callback in container:
                container.remove(callback)
        except Exception:
            pass
    _SSS_V1208_HANDLER_LEDGER.clear()
    try:
        bpy.msgbus.clear_by_owner(_SCENE_MSGBUS_OWNER)
    except Exception:
        pass


def register_properties():
    """Register only absent Scene properties and record exact ownership."""
    if _SSS_V1208_OWNED_SCENE_PROPERTIES:
        return None
    collisions = [name for name in _SSS_V1208_SCENE_PROPERTY_NAMES if hasattr(bpy.types.Scene, name)]
    if collisions:
        raise RuntimeError('Smart Shader Scene RNA collision kept unchanged: ' + ', '.join(collisions[:8]))
    before = {name for name in _SSS_V1208_SCENE_PROPERTY_NAMES if hasattr(bpy.types.Scene, name)}
    try:
        _clear_legacy_raw_last_reports_before_registration()
        _sss_v1208_legacy_register_properties()
        for name in _SSS_V1208_SCENE_PROPERTY_NAMES:
            if name not in before and hasattr(bpy.types.Scene, name):
                _SSS_V1208_OWNED_SCENE_PROPERTIES.append(name)
        missing = [name for name in _SSS_V1208_SCENE_PROPERTY_NAMES if not hasattr(bpy.types.Scene, name)]
        if missing:
            raise RuntimeError('Smart Shader Scene RNA registration incomplete: ' + ', '.join(missing[:8]))
        return None
    except Exception:
        _unregister_scene_persistence_handler()
        rollback_names = list(_SSS_V1208_OWNED_SCENE_PROPERTIES)
        rollback_names.extend(
            name for name in _SSS_V1208_SCENE_PROPERTY_NAMES
            if name not in before and hasattr(bpy.types.Scene, name) and name not in rollback_names
        )
        for name in reversed(tuple(rollback_names)):
            try:
                if hasattr(bpy.types.Scene, name):
                    delattr(bpy.types.Scene, name)
            except Exception:
                pass
        _SSS_V1208_OWNED_SCENE_PROPERTIES.clear()
        raise


def unregister_properties():
    _unregister_scene_persistence_handler()
    clear_enum_item_cache()
    _clear_scene_session_state()
    for name in reversed(tuple(_SSS_V1208_OWNED_SCENE_PROPERTIES)):
        try:
            if hasattr(bpy.types.Scene, name):
                delattr(bpy.types.Scene, name)
        except Exception:
            pass
    _SSS_V1208_OWNED_SCENE_PROPERTIES.clear()
