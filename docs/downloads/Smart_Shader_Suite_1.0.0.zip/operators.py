"""Operators for build, manage, import/export, audit, cleanup, and relink."""
from .translation import loc_text as _lt
from .translation import AddonError
from .translation import exc_text as _exc_text
import json
from pathlib import Path
import bpy
from bpy.props import BoolProperty, StringProperty, EnumProperty
from bpy.types import Operator
import importlib


class _LazyModule:
    __slots__ = ("_module_name", "_module")

    def __init__(self, module_name: str):
        self._module_name = str(module_name or '').strip()
        self._module = None

    def _load(self):
        module = self._module
        if module is None:
            module = importlib.import_module(f'.{self._module_name}', __package__)
            self._module = module
        return module

    def __getattr__(self, item):
        return getattr(self._load(), item)


def _lazy_module(module_name: str):
    return _LazyModule(module_name)

audit = _lazy_module('audit')
builders = _lazy_module('builders')
bundle = _lazy_module('bundle')
catalog = _lazy_module('catalog')
core = _lazy_module('core')
data = _lazy_module('data')
environment = _lazy_module('environment')
finder = _lazy_module('finder')
inventory = _lazy_module('inventory')
layers = _lazy_module('layers')
properties = _lazy_module('properties')
preset_preview_browser = _lazy_module('preset_preview_browser')
report_safety = _lazy_module('report_safety')
rules = _lazy_module('rules')
sampler = _lazy_module('sampler')
slot_selection = _lazy_module('slot_selection')
storage = _lazy_module('storage')
textures = _lazy_module('textures')
from .translation import tx
INVALID_PRESET_IDS = {'', 'NO_CUSTOM_PRESETS', 'NO_PRESETS_MATCH'}

PRESET_PREVIEW_BACKGROUND_HEX = '#555555'

def _srgb_to_linear_channel(value: float) -> float:
    value = max(0.0, min(1.0, float(value)))
    if value <= 0.04045:
        return value / 12.92
    return ((value + 0.055) / 1.055) ** 2.4

def _hex_to_linear_rgba(hex_color: str) -> tuple[float, float, float, float]:
    text = str(hex_color or '').strip().lstrip('#')
    if len(text) != 6:
        text = '555555'
    try:
        srgb = tuple(int(text[i:i+2], 16) / 255.0 for i in (0, 2, 4))
    except Exception:
        srgb = (85 / 255.0, 85 / 255.0, 85 / 255.0)
    return (_srgb_to_linear_channel(srgb[0]), _srgb_to_linear_channel(srgb[1]), _srgb_to_linear_channel(srgb[2]), 1.0)

PRESET_PREVIEW_BACKGROUND_LINEAR = _hex_to_linear_rgba(PRESET_PREVIEW_BACKGROUND_HEX)


class _OperatorExecutionShim:
    __slots__ = ('_reporter', '__dict__')

    def __init__(self, reporter=None, **kwargs):
        self._reporter = reporter
        for key, value in kwargs.items():
            setattr(self, key, value)

    def report(self, types, message):
        # Routed through the context-safety gate: a shim is used exactly where an
        # operator body runs outside its own invoke, so the context may have no
        # popup-capable area for Blender to build the report popup in.
        report_safety.safe_report(self._reporter, types, message,
                                  tag='SmartShader.operators')


def _execute_sss_operator_direct(context, operator_name: str, reporter=None, **kwargs):
    op_name = str(operator_name or '').strip()
    if not op_name:
        return None
    op_idname = op_name if '.' in op_name else f'sss.{op_name}'
    for cls in CLASSES:
        if getattr(cls, 'bl_idname', '') != op_idname:
            continue
        poll = getattr(cls, 'poll', None)
        if callable(poll):
            try:
                if not bool(poll(context)):
                    return {'CANCELLED'}
            except TypeError:
                try:
                    if not bool(poll(cls, context)):
                        return {'CANCELLED'}
                except Exception:
                    return {'CANCELLED'}
            except Exception:
                return {'CANCELLED'}
        execute = getattr(cls, 'execute', None)
        if not callable(execute):
            return None
        shim = _OperatorExecutionShim(reporter, **kwargs)
        try:
            return execute(shim, context)
        except TypeError:
            return None
    return None



def preset_preview_root() -> Path:
    """Return the writable CONFIG directory for rendered preview images."""
    return storage.preset_previews_dir(create=True)


def preset_preview_path(preset_id: str) -> Path:
    return storage.preset_preview_path(preset_id, create_parent=True)


def _remove_preview_helpers():
    names = {'SSS_PREVIEW_CAMERA', 'SSS_PREVIEW_LIGHT', 'SSS_PREVIEW_MONKEY'}
    for obj in list(getattr(bpy.data, 'objects', [])):
        try:
            if obj.name not in names:
                continue
            data_block = getattr(obj, 'data', None)
            bpy.data.objects.remove(obj, do_unlink=True)
            if data_block is not None and getattr(data_block, 'users', 0) == 0:
                if obj.type == 'CAMERA':
                    bpy.data.cameras.remove(data_block)
                elif obj.type == 'LIGHT':
                    bpy.data.lights.remove(data_block)
                elif obj.type == 'MESH':
                    bpy.data.meshes.remove(data_block)
        except Exception:
            pass


def _available_render_engines(scene) -> set[str]:
    try:
        return {item.identifier for item in scene.render.bl_rna.properties['engine'].enum_items}
    except Exception:
        return set()


def _choose_preview_render_engine(scene) -> str:
    engines = _available_render_engines(scene)
    if 'BLENDER_EEVEE' in engines:
        return 'BLENDER_EEVEE'
    if 'BLENDER_EEVEE_NEXT' in engines:
        return 'BLENDER_EEVEE_NEXT'
    if 'CYCLES' in engines:
        return 'CYCLES'
    if 'BLENDER_WORKBENCH' in engines:
        return 'BLENDER_WORKBENCH'
    return str(getattr(scene.render, 'engine', '') or '')


def _setup_preview_scene(context):
    """Create an isolated preview scene for preset thumbnail rendering.

    The preview generator must not delete or alter the user's current scene.
    This temporary scene is removed by the calling operator after rendering.
    """
    original_window_scene = None
    try:
        original_window_scene = getattr(getattr(context, 'window', None), 'scene', None)
    except Exception:
        original_window_scene = None

    preview_scene = bpy.data.scenes.new('SSS_PRESET_PREVIEW_SCENE')
    try:
        if getattr(context, 'window', None) is not None:
            context.window.scene = preview_scene
    except Exception:
        pass

    scene = preview_scene
    preview_engine = _choose_preview_render_engine(scene)
    if preview_engine:
        try:
            scene.render.engine = preview_engine
        except Exception:
            pass
    scene.render.resolution_x = 256
    scene.render.resolution_y = 256
    scene.render.resolution_percentage = 100
    scene.render.film_transparent = False
    try:
        scene.render.image_settings.file_format = 'PNG'
        scene.render.image_settings.color_mode = 'RGBA'
    except Exception:
        pass
    try:
        scene.render.dither_intensity = 0.0
    except Exception:
        pass
    try:
        scene.view_settings.view_transform = 'Standard'
        scene.view_settings.look = 'None'
        scene.view_settings.exposure = 0.0
        scene.view_settings.gamma = 1.0
    except Exception:
        pass
    if getattr(scene.render, 'engine', '') == 'CYCLES' and hasattr(scene, 'cycles'):
        try:
            scene.cycles.samples = 4
            scene.cycles.use_adaptive_sampling = False
            scene.cycles.preview_samples = 4
        except Exception:
            pass
    if getattr(scene.render, 'engine', '') in {'BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT'} and hasattr(scene, 'eevee'):
        try:
            scene.eevee.taa_render_samples = 1
            scene.eevee.taa_samples = 1
        except Exception:
            pass
        for attr, value in (
            ('use_gtao', False),
            ('use_bloom', False),
            ('shadow_cube_size', '512'),
            ('shadow_cascade_size', '512'),
        ):
            try:
                setattr(scene.eevee, attr, value)
            except Exception:
                pass
    try:
        world = scene.world or bpy.data.worlds.new('SSS_PREVIEW_WORLD')
        scene.world = world
        world.use_nodes = True
        bg = world.node_tree.nodes.get('Background') if world.node_tree else None
        if bg is not None:
            bg.inputs[0].default_value = PRESET_PREVIEW_BACKGROUND_LINEAR
            bg.inputs[1].default_value = 1.0
    except Exception:
        pass

    bpy.ops.mesh.primitive_monkey_add(size=3.6, location=(-0.5, 0.0, 0.0), rotation=(0.0, 0.0, 0.0))
    monkey = context.active_object
    monkey.name = 'SSS_PREVIEW_MONKEY'
    try:
        for polygon in getattr(getattr(monkey, 'data', None), 'polygons', []) or []:
            polygon.use_smooth = True
        subsurf = monkey.modifiers.new('SSS Preview Smooth x2', 'SUBSURF')
        subsurf.levels = 2
        subsurf.render_levels = 2
    except Exception:
        pass
    camera_data = bpy.data.cameras.new('SSS_PREVIEW_CAMERA')
    camera = bpy.data.objects.new('SSS_PREVIEW_CAMERA', camera_data)
    scene.collection.objects.link(camera)
    camera.location = (4.3, -4.3, 2.8)
    camera.rotation_euler = (1.12, 0.0, 0.79)
    try:
        camera.data.lens = 50
        camera.data.shift_x = 0.0
        camera.data.shift_y = 0.04
    except Exception:
        pass
    scene.camera = camera
    light_data = bpy.data.lights.new('SSS_PREVIEW_LIGHT', type='SUN')
    light = bpy.data.objects.new('SSS_PREVIEW_LIGHT', light_data)
    scene.collection.objects.link(light)
    light.location = (2.5, -2.5, 5.0)
    try:
        light.data.energy = 3.0
        light.rotation_euler = (0.78, 0.0, 0.52)
    except Exception:
        pass
    return scene, monkey, original_window_scene


def _cleanup_preview_scene(context, preview_scene, original_window_scene=None) -> None:
    try:
        if original_window_scene is not None and getattr(context, 'window', None) is not None:
            context.window.scene = original_window_scene
    except Exception:
        pass
    try:
        if preview_scene is None:
            return
        for obj in list(getattr(preview_scene, 'objects', [])):
            try:
                data_block = getattr(obj, 'data', None)
                bpy.data.objects.remove(obj, do_unlink=True)
                if data_block is not None and getattr(data_block, 'users', 0) == 0:
                    if obj.type == 'CAMERA':
                        bpy.data.cameras.remove(data_block)
                    elif obj.type == 'LIGHT':
                        bpy.data.lights.remove(data_block)
                    elif obj.type == 'MESH':
                        bpy.data.meshes.remove(data_block)
            except Exception:
                pass
        try:
            bpy.data.scenes.remove(preview_scene)
        except Exception:
            pass
    except Exception:
        pass


def ensure_json_export_path(filepath: str, fallback_name: str) -> Path:
    raw = str(filepath or '').strip()
    if not raw:
        return core.addon_storage_dir() / fallback_name
    path = Path(raw)
    if raw.endswith(('/', '\\')) or (path.exists() and path.is_dir()):
        path = path / fallback_name
    suffix = path.suffix.lower()
    if suffix != '.json':
        if path.suffix:
            path = path.with_suffix('.json')
        else:
            path = path.with_name(path.name + '.json')
    return path

def ensure_json_import_path(filepath: str) -> Path:
    raw = str(filepath or '').strip()
    if not raw:
        return Path('__missing__.json')
    path = Path(raw)
    if path.exists() and path.is_dir():
        return path / '__missing__.json'
    return path

def ensure_valid_scene_preset(scene):
    preset_id = getattr(scene, 'sss_preset_name', '')
    if preset_id in INVALID_PRESET_IDS:
        raise AddonError(tx(scene, 'Select a real preset first.', _lt('先に実際のプリセットを選択してください。')))
    return preset_id

def resolve_custom_entry(scene):
    entry = core.find_custom_preset(scene.sss_preset_name)
    if not entry:
        raise AddonError(_lt('Custom preset not found.', 'カスタムプリセットが見つかりません。'))
    return entry

def build_material_from_custom_entry(material, entry, context=None) -> str:
    builder = str(entry.get('builder', '') or '').strip()
    params = entry.get('params') or {}
    if builder in builders.BUILDERS:
        builders.build_preset(material, builder, custom_params=params)
        return 'builder'
    manifest = entry.get('manifest') or {}
    if isinstance(manifest, dict):
        search_roots = []
        scene = getattr(context, 'scene', None) if context else None
        root_raw = getattr(scene, 'sss_texture_search_root', '') if scene else ''
        if root_raw:
            try:
                search_roots.append(Path(bpy.path.abspath(root_raw)))
            except Exception:
                pass
        texture_build = textures.build_material_from_manifest_textures(material, manifest.get('textures', []), base_dir=None, search_roots=search_roots, force=True, group_name=str(entry.get('material_name') or entry.get('name') or material.name))
        if texture_build.get('loaded_images', 0) > 0:
            if builder:
                material['sss_builder'] = builder
            core.set_managed_metadata_only(material, note_en=entry.get('summary_en') or 'Custom preset rebuilt from manifest textures.', note_ja=entry.get('summary_ja') or _lt('カスタムプリセットをマニフェスト内のテクスチャ参照から再構築しました。'), params=params or core.approx_params_from_material(material), tags=entry.get('tags', []) or ['Custom', 'Manifest Textures'])
            return 'manifest_textures'
    portable_models = manifest.get('portable_models', {}) if isinstance(manifest, dict) else {}
    portable = portable_models.get('openpbr_surface_approx') or portable_models.get('openpbr_approx') or portable_models.get('materialx_standard_surface_approx') or portable_models.get('usd_preview_surface_approx') or params
    builders.build_portable_principled(material, portable or params)
    if builder:
        material['sss_builder'] = builder
    core.set_managed_metadata_only(material, note_en=entry.get('summary_en') or 'Custom preset rebuilt with portable fallback.', note_ja=entry.get('summary_ja') or _lt('カスタムプリセットをポータブル近似で再構築しました。'), params=params or portable or {}, tags=entry.get('tags', []) or ['Custom', 'Portable Fallback'])
    return 'portable'

def _display_name_for_preset(scene, preset_id: str) -> str:
    meta = data.PRESET_LIBRARY.get(str(preset_id or '').strip(), {}) or {}
    label = tx(scene, meta.get('label_en', ''), meta.get('label_ja', '')) if meta else ''
    return str(label or preset_id or 'Smart Shader Material').strip()


def _new_material_name_for_preset(scene, preset_id: str) -> str:
    explicit = str(getattr(scene, 'sss_material_name', '') or '').strip() if scene is not None else ''
    return explicit or _display_name_for_preset(scene, preset_id)


def create_material_from_scene_preset(context):
    scene = context.scene
    preset_id = ensure_valid_scene_preset(scene)
    if scene.sss_preset_family == 'CUSTOM':
        entry = resolve_custom_entry(scene)
        material = bpy.data.materials.new(name=scene.sss_material_name or scene.sss_preset_name)
        material.use_fake_user = scene.sss_use_fake_user
        try:
            build_material_from_custom_entry(material, entry, context=context)
        except Exception:
            core.safe_remove_id(bpy.data.materials, material)
            raise
        return material
    material = bpy.data.materials.new(name=_new_material_name_for_preset(scene, preset_id))
    material.use_fake_user = scene.sss_use_fake_user
    try:
        builders.build_preset(material, preset_id)
    except Exception:
        core.safe_remove_id(bpy.data.materials, material)
        raise
    return material


def create_builtin_material_from_preset_id(context, preset_id: str):
    scene = context.scene
    preset_id = str(preset_id or '').strip()
    if preset_id in INVALID_PRESET_IDS or preset_id not in data.PRESET_LIBRARY:
        raise AddonError(tx(scene, 'No valid preset selected.', _lt('有効なプリセットが選択されていません。')))
    material = bpy.data.materials.new(name=_new_material_name_for_preset(scene, preset_id))
    material.use_fake_user = bool(getattr(scene, 'sss_use_fake_user', True))
    try:
        builders.build_preset(material, preset_id)
    except Exception:
        core.safe_remove_id(bpy.data.materials, material)
        raise
    return material


def finish_created_preset_material(context, material, *, report_title_en: str, report_title_ja: str):
    scene = context.scene
    notes = postprocess_material_graph(material, context)
    if bool(getattr(scene, 'sss_mark_asset', False)):
        core.mark_material_as_asset(material)
    assigned = core.assign_material_to_selected(context, material) if core.material_generation_should_assign_selected(context) else 0
    if not assigned:
        core.set_active_material(context, material)
    scene.sss_target_material_name = material.name
    if bool(getattr(scene, 'sss_auto_audit_after_build', False)):
        try:
            core.report_to_scene(scene, join_notes(audit.format_audit_report(material, context), notes))
        except Exception:
            core.report_to_scene(scene, join_notes(tx(scene, report_title_en, _lt(report_title_ja)), notes))
    else:
        core.report_to_scene(scene, join_notes(tx(scene, report_title_en, _lt(report_title_ja)), notes))
    return assigned

def choose_target_or_active(context):
    return core.get_target_material(context) or core.active_material(context)


def choose_current_material(context):
    return core.preferred_material(context)


def _scene_has_rna_property(scene, prop_name: str) -> bool:
    if scene is None or not prop_name:
        return False
    try:
        props = getattr(getattr(scene, 'bl_rna', None), 'properties', None)
    except Exception:
        props = None
    if props is None:
        return False
    try:
        return props.get(str(prop_name)) is not None
    except Exception:
        pass
    try:
        return str(prop_name) in props.keys()
    except Exception:
        return False


def npr_studio_params_from_scene(scene) -> dict:
    return {'base_color': list(getattr(scene, 'sss_npr_base_color', (0.88, 0.72, 0.68, 1.0))), 'zone2_color': list(getattr(scene, 'sss_npr_zone2_color', (0.64, 0.48, 0.48, 1.0))), 'zone3_color': list(getattr(scene, 'sss_npr_zone3_color', (0.36, 0.24, 0.28, 1.0))), 'zone4_color': list(getattr(scene, 'sss_npr_zone4_color', (0.15, 0.1, 0.14, 1.0))), 'paper_tint': list(getattr(scene, 'sss_npr_paper_tint', (1.0, 1.0, 1.0, 1.0))), 'paper_scale': float(getattr(scene, 'sss_npr_paper_scale', 10.0)), 'paper_strength': float(getattr(scene, 'sss_npr_paper_strength', 0.08)), 'zone_count': int(getattr(scene, 'sss_npr_zone_count', 4)), 'threshold_1': float(getattr(scene, 'sss_npr_threshold_1', 0.72)), 'threshold_2': float(getattr(scene, 'sss_npr_threshold_2', 0.48)), 'threshold_3': float(getattr(scene, 'sss_npr_threshold_3', 0.24)), 'shadow_smooth': float(getattr(scene, 'sss_npr_shadow_smooth', 0.03)), 'alpha': float(getattr(scene, 'sss_npr_alpha', 1.0)), 'highlight_color': list(getattr(scene, 'sss_npr_highlight_color', (1.0, 1.0, 1.0, 1.0))), 'highlight_level': float(getattr(scene, 'sss_npr_highlight_level', 0.28)), 'highlight_size': float(getattr(scene, 'sss_npr_highlight_size', 0.12)), 'highlight_smooth': float(getattr(scene, 'sss_npr_highlight_smooth', 0.04)), 'reflection_color': list(getattr(scene, 'sss_npr_reflection_color', (1.0, 1.0, 1.0, 1.0))), 'reflection_strength': float(getattr(scene, 'sss_npr_reflection_strength', 0.16)), 'reflection_roughness': float(getattr(scene, 'sss_npr_reflection_roughness', 0.08)), 'rim_color': list(getattr(scene, 'sss_npr_rim_color', (1.0, 1.0, 1.0, 1.0))), 'rim_width': float(getattr(scene, 'sss_npr_rim_width', 0.9)), 'rim_strength': float(getattr(scene, 'sss_npr_rim_strength', 0.85)), 'detail_scale': float(getattr(scene, 'sss_npr_detail_scale', 24.0)), 'detail_normal': float(getattr(scene, 'sss_npr_detail_normal', 0.03)), 'hatch_enable': bool(getattr(scene, 'sss_npr_hatch_enable', True)), 'hatch_color': list(getattr(scene, 'sss_npr_hatch_color', (0.05, 0.05, 0.05, 1.0))), 'hatch_scale': float(getattr(scene, 'sss_npr_hatch_scale', 48.0)), 'hatch_strength': float(getattr(scene, 'sss_npr_hatch_strength', 0.22)), 'hatch_softness': float(getattr(scene, 'sss_npr_hatch_softness', 0.16)), 'hatch_angle': float(getattr(scene, 'sss_npr_hatch_angle', 0.78539816339)), 'hatch_cross_enable': bool(getattr(scene, 'sss_npr_hatch_cross_enable', False)), 'hatch_cross_angle': float(getattr(scene, 'sss_npr_hatch_cross_angle', -0.78539816339)), 'hatch_cross_strength': float(getattr(scene, 'sss_npr_hatch_cross_strength', 0.08)), 'halftone_enable': bool(getattr(scene, 'sss_npr_halftone_enable', False)), 'halftone_color': list(getattr(scene, 'sss_npr_halftone_color', (0.05, 0.05, 0.05, 1.0))), 'halftone_scale': float(getattr(scene, 'sss_npr_halftone_scale', 30.0)), 'halftone_strength': float(getattr(scene, 'sss_npr_halftone_strength', 0.18)), 'halftone_threshold': float(getattr(scene, 'sss_npr_halftone_threshold', 0.58)), 'halftone_softness': float(getattr(scene, 'sss_npr_halftone_softness', 0.16)), 'halftone_rotation': float(getattr(scene, 'sss_npr_halftone_rotation', 0.0))}

def apply_npr_studio_params_to_scene(scene, params: dict):
    if not isinstance(params, dict):
        return
    mapping = {'sss_npr_base_color': params.get('base_color'), 'sss_npr_zone2_color': params.get('zone2_color'), 'sss_npr_zone3_color': params.get('zone3_color'), 'sss_npr_zone4_color': params.get('zone4_color'), 'sss_npr_paper_tint': params.get('paper_tint'), 'sss_npr_paper_scale': params.get('paper_scale'), 'sss_npr_paper_strength': params.get('paper_strength'), 'sss_npr_zone_count': params.get('zone_count'), 'sss_npr_threshold_1': params.get('threshold_1'), 'sss_npr_threshold_2': params.get('threshold_2'), 'sss_npr_threshold_3': params.get('threshold_3'), 'sss_npr_shadow_smooth': params.get('shadow_smooth'), 'sss_npr_alpha': params.get('alpha'), 'sss_npr_highlight_color': params.get('highlight_color'), 'sss_npr_highlight_level': params.get('highlight_level'), 'sss_npr_highlight_size': params.get('highlight_size'), 'sss_npr_highlight_smooth': params.get('highlight_smooth'), 'sss_npr_reflection_color': params.get('reflection_color'), 'sss_npr_reflection_strength': params.get('reflection_strength'), 'sss_npr_reflection_roughness': params.get('reflection_roughness'), 'sss_npr_rim_color': params.get('rim_color'), 'sss_npr_rim_width': params.get('rim_width'), 'sss_npr_rim_strength': params.get('rim_strength'), 'sss_npr_detail_scale': params.get('detail_scale'), 'sss_npr_detail_normal': params.get('detail_normal'), 'sss_npr_hatch_enable': params.get('hatch_enable'), 'sss_npr_hatch_color': params.get('hatch_color'), 'sss_npr_hatch_scale': params.get('hatch_scale'), 'sss_npr_hatch_strength': params.get('hatch_strength'), 'sss_npr_hatch_softness': params.get('hatch_softness'), 'sss_npr_hatch_angle': params.get('hatch_angle'), 'sss_npr_hatch_cross_enable': params.get('hatch_cross_enable'), 'sss_npr_hatch_cross_angle': params.get('hatch_cross_angle'), 'sss_npr_hatch_cross_strength': params.get('hatch_cross_strength'), 'sss_npr_halftone_enable': params.get('halftone_enable'), 'sss_npr_halftone_color': params.get('halftone_color'), 'sss_npr_halftone_scale': params.get('halftone_scale'), 'sss_npr_halftone_strength': params.get('halftone_strength'), 'sss_npr_halftone_threshold': params.get('halftone_threshold'), 'sss_npr_halftone_softness': params.get('halftone_softness'), 'sss_npr_halftone_rotation': params.get('halftone_rotation')}
    for attr, value in mapping.items():
        if value is None or not _scene_has_rna_property(scene, attr):
            continue
        try:
            setattr(scene, attr, value)
        except Exception:
            pass

def choose_compare_source(context):
    scene = context.scene
    name = str(getattr(scene, 'sss_compare_source_material_name', '') or '').strip()
    source = bpy.data.materials.get(name) if name else None
    target = core.get_target_material(context)
    active = core.active_material(context)
    if source:
        return source
    if active and active != target:
        return active
    return active or target

def resolve_assign_rule(scene):
    name = str(getattr(scene, 'sss_rule_pick', '') or '').strip()
    if not name or name == rules.ASSIGN_RULE_SENTINEL:
        raise AddonError(tx(scene, 'Select a saved assignment rule first.', _lt('先に保存済みの割当ルールを選択してください。')))
    entry = rules.find_assignment_rule(name)
    if not entry:
        raise AddonError(tx(scene, 'Assignment rule not found.', _lt('割当ルールが見つかりません。')))
    return entry

def material_diff_report_lines(scene, diff: dict) -> list[str]:
    if diff.get('missing'):
        return [tx(scene, 'Material comparison could not be built.', _lt('材質比較を作成できませんでした。'))]
    source = diff.get('source', {}) or {}
    target = diff.get('target', {}) or {}
    lines = [tx(scene, f"Source: {source.get('name', '-')}", _lt(f"比較元: {source.get('name', '-')}")), tx(scene, f"Target: {target.get('name', '-')}", _lt(f"比較先: {target.get('name', '-')}")), tx(scene, f"Same builder: {diff.get('same_builder', False)}", _lt(f"ビルダー一致: {diff.get('same_builder', False)}")), tx(scene, f"Same family: {diff.get('same_family', False)}", _lt(f"分類一致: {diff.get('same_family', False)}")), tx(scene, f"Same params: {diff.get('same_params', False)}", _lt(f"パラメータ一致: {diff.get('same_params', False)}")), tx(scene, f"Same tags: {diff.get('same_tags', False)}", _lt(f"タグ一致: {diff.get('same_tags', False)}")), tx(scene, f"Source users: objects={source.get('usage_objects', 0)} slots={source.get('usage_slots', 0)}", _lt(f"比較元の使用数: オブジェクト={source.get('usage_objects', 0)} スロット={source.get('usage_slots', 0)}")), tx(scene, f"Target users: objects={target.get('usage_objects', 0)} slots={target.get('usage_slots', 0)}", _lt(f"比較先の使用数: オブジェクト={target.get('usage_objects', 0)} スロット={target.get('usage_slots', 0)}"))]
    differences = diff.get('differences') or []
    if differences:
        lines.append(tx(scene, 'Differences:', _lt('差分:')))
        for item in differences[:12]:
            label = tx(scene, item.get('label_en', item.get('key', 'field')), item.get('label_ja', item.get('key', _lt('項目'))))
            lines.append(f"- {label}: {item.get('source')} -> {item.get('target')}")
    else:
        lines.append(tx(scene, 'No stored differences were detected.', _lt('保存情報ベースでは差分が見つかりませんでした。')))
    return lines

def postprocess_material_graph(material, context) -> list[str]:
    scene = getattr(context, 'scene', None)
    notes: list[str] = []
    if not material or not getattr(material, 'use_nodes', False) or (not getattr(material, 'node_tree', None)):
        return notes
    engine = core.render_engine(context)
    removed = 0
    moved = 0
    if scene and getattr(scene, 'sss_prune_after_build', False):
        removed = core.prune_unconnected_nodes(material, engine=engine)
        if removed:
            notes.append(tx(scene, f'Removed unconnected nodes: {removed}', _lt(f'未接続ノードを削除: {removed}')))
    if scene and getattr(scene, 'sss_auto_layout_after_build', True):
        moved = core.auto_layout_node_tree(material, engine=engine)
        if moved:
            notes.append(tx(scene, f'Auto-layout moved {moved} nodes.', _lt(f'自動整列したノード数: {moved}')))
    return notes

def join_notes(message: str, notes: list[str]) -> str:
    if not notes:
        return message
    block = '\n'.join(notes)
    return f'{message}\n\n{block}' if message else block

def iter_scene_doctor_materials(context):
    scene = context.scene
    scope = getattr(scene, 'sss_batch_doctor_scope', 'SCENE')
    filter_key = core.library_name_key(getattr(scene, 'sss_batch_doctor_filter', ''))
    limit = max(1, int(getattr(scene, 'sss_batch_doctor_limit', 64) or 64))
    if scope == 'ACTIVE':
        candidates = [core.active_material(context)]
    elif scope == 'TARGET':
        candidates = [core.get_target_material(context)]
    elif scope == 'SELECTED':
        candidates = []
        for obj in getattr(context, 'selected_objects', None) or []:
            data_block = getattr(obj, 'data', None)
            if not data_block or not hasattr(data_block, 'materials'):
                continue
            candidates.extend(list(getattr(data_block, 'materials', [])))
    elif scope == 'MANAGED':
        candidates = [mat for mat in core.scene_materials(context) if mat and mat.get('sss_builder')]
    else:
        candidates = core.scene_materials(context)
        if not candidates:
            candidates = [mat for mat in getattr(bpy.data, 'materials', []) if mat]
    results = []
    seen = set()
    for material in candidates:
        if material is None:
            continue
        key = getattr(material, 'name', '')
        if key in seen:
            continue
        seen.add(key)
        if filter_key:
            hay = ' '.join([core.library_name_key(getattr(material, 'name', '')), core.library_name_key(str(material.get('sss_builder', ''))), core.library_name_key(' '.join(core.get_material_tags(material) or []))])
            if filter_key not in hay:
                continue
        results.append(material)
        if len(results) >= limit:
            break
    return results

def relink_missing_images_on_materials(materials, root: Path) -> dict:
    file_index = core.index_files_by_name(root)
    resolved = 0
    unresolved: list[str] = []
    for material in materials:
        for node in core.iter_image_nodes(material):
            image = getattr(node, 'image', None)
            if image is None or getattr(image, 'packed_file', None):
                continue
            try:
                current = bpy.path.abspath(image.filepath)
            except Exception:
                current = ''
            if current and Path(current).exists():
                continue
            lookup_keys: list[str] = []
            for source in (current, getattr(image, 'filepath', ''), getattr(image, 'name', '')):
                for key in core.texture_lookup_keys(source):
                    if key not in lookup_keys:
                        lookup_keys.append(key)
            candidates = []
            for key in lookup_keys:
                for candidate in file_index.get(key, []):
                    if candidate not in candidates:
                        candidates.append(candidate)
            best = core.best_texture_match(candidates, current or getattr(image, 'filepath', ''), getattr(image, 'name', ''))
            if best:
                try:
                    new_path = str(best)
                    try:
                        if getattr(bpy.data, 'filepath', ''):
                            new_path = bpy.path.relpath(new_path)
                    except Exception:
                        pass
                    image.filepath = new_path
                    image.reload()
                    resolved += 1
                except Exception:
                    unresolved.append(f'{material.name}::{node.name}')
            else:
                unresolved.append(f'{material.name}::{node.name}')
    return {'resolved': resolved, 'unresolved': unresolved}

def scene_doctor_summary_lines(context, result: dict) -> list[str]:
    scene = context.scene
    lines = [tx(scene, f"Materials in scope: {result.get('materials_in_scope', 0)}", _lt(f"対象材質数: {result.get('materials_in_scope', 0)}")), tx(scene, f"Processed: {result.get('processed', 0)}", _lt(f"処理数: {result.get('processed', 0)}")), tx(scene, f"Missing before: {result.get('missing_before', 0)}", _lt(f"修復前欠損: {result.get('missing_before', 0)}")), tx(scene, f"Missing after: {result.get('missing_after', 0)}", _lt(f"修復後欠損: {result.get('missing_after', 0)}")), tx(scene, f"Relinked files: {result.get('relinked', 0)}", _lt(f"再リンク成功: {result.get('relinked', 0)}")), tx(scene, f"Colorspace fixes: {result.get('colorspace_fixes', 0)}", _lt(f"色空間補正: {result.get('colorspace_fixes', 0)}")), tx(scene, f"Helper nodes created: {result.get('helper_nodes', 0)}", _lt(f"補助ノード作成: {result.get('helper_nodes', 0)}")), tx(scene, f"Links created: {result.get('new_links', 0)}", _lt(f"新規リンク: {result.get('new_links', 0)}")), tx(scene, f"Materials still reporting audit errors: {result.get('materials_with_errors', 0)}", _lt(f"監査エラーが残る材質: {result.get('materials_with_errors', 0)}")), tx(scene, f"Materials still reporting audit warnings: {result.get('materials_with_warnings', 0)}", _lt(f"監査警告が残る材質: {result.get('materials_with_warnings', 0)}"))]
    samples = result.get('sample_materials') or []
    if samples:
        lines.append(tx(scene, f"Sample materials: {', '.join(samples)}", _lt(f"サンプル材質: {', '.join(samples)}")))
    unresolved = result.get('unresolved_samples') or []
    if unresolved:
        lines.append(tx(scene, f"Still unresolved: {', '.join(unresolved)}", _lt(f"未解決例: {', '.join(unresolved)}")))
    return lines

def run_scene_doctor_pass(context, preview: bool=False) -> dict:
    materials = iter_scene_doctor_materials(context)
    result = {'materials_in_scope': len(materials), 'processed': 0, 'missing_before': 0, 'missing_after': 0, 'relinked': 0, 'colorspace_fixes': 0, 'helper_nodes': 0, 'new_links': 0, 'materials_with_errors': 0, 'materials_with_warnings': 0, 'sample_materials': [mat.name for mat in materials[:8]], 'unresolved_samples': [], 'preview': preview}
    if not materials:
        return result
    core.clear_material_audit_cache()
    for material in materials:
        result['missing_before'] += core.count_missing_image_nodes(material)
    root_raw = str(getattr(context.scene, 'sss_texture_search_root', '') or '').strip()
    if not preview and getattr(context.scene, 'sss_batch_doctor_relink_missing', True) and root_raw:
        root = Path(bpy.path.abspath(root_raw))
        if root.exists():
            relink = relink_missing_images_on_materials(materials, root)
            result['relinked'] = relink.get('resolved', 0)
            result['unresolved_samples'] = list(relink.get('unresolved', []))[:10]
    for material in materials:
        if not preview:
            standardized = textures.standardize_material_images(material)
            wired = textures.autowire_material_textures(material, force=bool(getattr(context.scene, 'sss_texture_force_rewire', False)))
            postprocess_material_graph(material, context)
            result['colorspace_fixes'] += standardized.get('fixed', 0)
            result['helper_nodes'] += wired.get('created_nodes', 0)
            result['new_links'] += wired.get('new_links', 0)
        core.clear_material_audit_cache()
        audit_result = audit.audit_material(material, context)
        if audit_result.get('errors'):
            result['materials_with_errors'] += 1
        if audit_result.get('warnings'):
            result['materials_with_warnings'] += 1
        result['missing_after'] += core.count_missing_image_nodes(material)
        result['processed'] += 1
    return result

def format_texture_scan_report(scene, scan: dict) -> str:
    lines = [tx(scene, f"Recognized candidates: {scan.get('recognized_total', 0)}", _lt(f"認識候補数: {scan.get('recognized_total', 0)}")), tx(scene, f"Matched groups: {scan.get('matched_group_total', 0)}", _lt(f"一致グループ数: {scan.get('matched_group_total', 0)}")), tx(scene, f"Selected files: {scan.get('selected_total', 0)}", _lt(f"選択ファイル数: {scan.get('selected_total', 0)}")), tx(scene, f"Mode: {scan.get('mode', '')}", _lt(f"モード: {scan.get('mode', '')}"))]
    if scan.get('selected_group'):
        lines.append(tx(scene, f"Selected group: {scan['selected_group']}", _lt(f"選択グループ: {scan['selected_group']}")))
    if scan.get('selected_folder') and scan.get('selected_folder') != '.':
        lines.append(tx(scene, f"Selected folder: {scan['selected_folder']}", _lt(f"選択フォルダ: {scan['selected_folder']}")))
    if scan.get('selection_spans_groups'):
        lines.append(tx(scene, 'Selection currently spans multiple groups. This can mix unrelated assets unless multi-group import is intentionally enabled.', _lt('現在の選択は複数グループにまたがっています。意図的に複数グループ取込を有効化していない限り、別アセット混在の原因になります。')))
    usage_counts = scan.get('usage_counts', {}) or {}
    if usage_counts:
        usage_line = ', '.join((f'{usage}={count}' for usage, count in sorted(usage_counts.items())))
        lines.append(tx(scene, f'Usages: {usage_line}', _lt(f'用途内訳: {usage_line}')))
    for item in (scan.get('selected') or [])[:12]:
        lines.append(f"{item.get('usage', 'unknown')}: {item.get('name', '')}")
    candidates = scan.get('group_candidates') or []
    if candidates:
        lines.append(tx(scene, 'Top group candidates:', _lt('上位候補グループ:')))
        for item in candidates[:4]:
            lines.append(tx(scene, f"  {item.get('label', '')} | files={item.get('files', 0)} | usages={item.get('usages', 0)}", _lt(f"  {item.get('label', '')} | ファイル={item.get('files', 0)} | 用途={item.get('usages', 0)}")))
    for note in (scan.get('notes') or [])[:6]:
        lines.append(note)
    return '\n'.join(lines)

def format_texture_library_scan_report(scene, scan: dict) -> str:
    lines = [tx(scene, f"Recognized candidates: {scan.get('recognized_total', 0)}", _lt(f"認識候補数: {scan.get('recognized_total', 0)}")), tx(scene, f"Coherent groups: {scan.get('group_total', 0)}", _lt(f"整合グループ数: {scan.get('group_total', 0)}"))]
    for item in (scan.get('groups') or [])[:10]:
        usage_line = ', '.join((f'{usage}={count}' for usage, count in sorted((item.get('usage_counts') or {}).items())))
        lines.append(tx(scene, f"{item.get('label', '')} | files={item.get('selected_files', 0)} | usages={item.get('usages', 0)}", _lt(f"{item.get('label', '')} | ファイル={item.get('selected_files', 0)} | 用途={item.get('usages', 0)}")))
        if usage_line:
            lines.append(tx(scene, f'  {usage_line}', f'  {usage_line}'))
    for note in (scan.get('notes') or [])[:6]:
        lines.append(note)
    return '\n'.join(lines)

def import_material_manifest_payload(context, payload: dict, path_hint: Path | None=None, material_name_override: str='', assign_selected: bool | None=None, activate_when_unassigned: bool=True) -> dict:
    if not isinstance(payload, dict):
        raise AddonError(tx(context.scene, 'Manifest payload must be a JSON object.', _lt('マニフェスト本体は JSON オブジェクト である必要があります。')))
    scene = context.scene
    smart = payload.get('smart_shader', {})
    if not isinstance(smart, dict):
        smart = {}
    builder_id = str(smart.get('builder', '') or '').strip()
    params = smart.get('params', {}) or {}
    if not isinstance(params, dict):
        params = {}
    portable_models = payload.get('portable_models', {})
    if not isinstance(portable_models, dict):
        portable_models = {}
    suggested_name = (material_name_override or '').strip() or scene.sss_material_name.strip() or str(payload.get('material_name') or '').strip() or (path_hint.stem if path_hint else 'Imported_Material')
    material = bpy.data.materials.new(name=suggested_name)
    material.use_fake_user = scene.sss_use_fake_user
    rebuilt = False
    build_mode = 'portable'
    rebuild_error = ''
    build_notes: list[str] = []
    texture_fallback_result: dict = {}
    try:
        if builder_id in builders.BUILDERS:
            try:
                builders.build_preset(material, builder_id, custom_params=params)
                rebuilt = True
                build_mode = 'builder'
            except Exception as exc:
                rebuild_error = str(exc)
                rebuilt = False
        if not rebuilt:
            search_roots = []
            root_raw = getattr(scene, 'sss_texture_search_root', '').strip()
            if root_raw:
                try:
                    search_roots.append(Path(bpy.path.abspath(root_raw)))
                except Exception:
                    pass
            texture_payload = payload.get('textures', [])
            if isinstance(texture_payload, list) and texture_payload:
                texture_fallback_result = textures.build_material_from_manifest_textures(material, texture_payload, base_dir=path_hint.parent if path_hint else None, search_roots=search_roots, force=True, group_name=suggested_name)
                if texture_fallback_result.get('loaded_images', 0) > 0:
                    build_mode = 'manifest_textures'
                    if builder_id:
                        material['sss_builder'] = builder_id
                    if smart.get('family'):
                        material['sss_family'] = str(smart.get('family'))
                    core.set_managed_metadata_only(material, note_en='Imported manifest rebuilt from referenced textures.', note_ja=_lt('マニフェスト内の参照テクスチャから材質を再構築しました。'), params=params or core.approx_params_from_material(material), tags=smart.get('tags', []) or ['Imported Manifest', 'Manifest Textures'])
                    build_notes.extend(texture_fallback_result.get('notes', []))
            if build_mode == 'portable':
                portable = portable_models.get('openpbr_surface_approx', {}) or portable_models.get('openpbr_approx', {}) or portable_models.get('materialx_standard_surface_approx', {}) or portable_models.get('usd_preview_surface_approx', {})
                if not isinstance(portable, dict):
                    portable = {}
                builders.build_portable_principled(material, portable or params)
                if builder_id:
                    material['sss_builder'] = builder_id
                if smart.get('family'):
                    material['sss_family'] = str(smart.get('family'))
                core.set_managed_metadata_only(material, note_en='Imported manifest without a rebuildable Smart Shader builder.', note_ja=_lt('再構築可能なスマートシェーダービルダーがないマニフェストを取り込みました。'), params=params or portable or {}, tags=smart.get('tags', []) or ['Imported Manifest'])
                build_notes.extend(texture_fallback_result.get('notes', []))
        try:
            if smart.get('summary_en'):
                material['sss_summary_en'] = str(smart.get('summary_en'))
            if smart.get('summary_ja'):
                material['sss_summary_ja'] = str(smart.get('summary_ja'))
            if params:
                material['sss_params'] = json.dumps(params, ensure_ascii=False, sort_keys=True)
            tags = smart.get('tags', [])
            if isinstance(tags, list):
                material['sss_tags'] = json.dumps([str(tag) for tag in tags], ensure_ascii=False)
            material['sss_import_mode'] = build_mode
        except Exception:
            pass
        try:
            core.write_manifest_text_block(material.name, payload)
        except Exception:
            pass
        if bool(smart.get('cleanup_protected', False)):
            try:
                core.set_cleanup_protection(material, True, str(smart.get('cleanup_protection_reason', '') or 'Imported manifest'))
            except Exception:
                pass
        if bool(payload.get('asset_marked', False)) or scene.sss_mark_asset:
            core.mark_material_as_asset(material)
        notes = build_notes + postprocess_material_graph(material, context)
        if rebuild_error:
            notes.append(tx(scene, 'The native rebuild could not be used, so the material was restored another way.', 'ネイティブ再構築を使えなかったため、別の方法で材質を復元しました。'))
        if build_mode == 'manifest_textures':
            notes.append(tx(scene, f"Manifest texture fallback used {texture_fallback_result.get('loaded_images', 0)} image(s).", _lt(f"マニフェストテクスチャフォールバックで {texture_fallback_result.get('loaded_images', 0)} 枚の画像を使いました。")))
        if assign_selected is None:
            assign_selected = bool(scene.sss_assign_selected)
        assigned = 0
        if assign_selected:
            assigned = core.assign_material_to_selected(context, material)
        elif activate_when_unassigned:
            core.set_active_material(context, material)
        return {'material': material, 'rebuilt': rebuilt, 'build_mode': build_mode, 'assigned': assigned, 'notes': notes}
    except Exception:
        core.safe_remove_id(bpy.data.materials, material)
        raise

def _scene_object_by_name(context, name: str):
    if not name:
        return None
    scene = getattr(context, 'scene', None)
    objects = getattr(scene, 'objects', None)
    if objects is not None:
        try:
            found = objects.get(name)
            if found is not None:
                return found
        except Exception:
            pass
        try:
            for obj in objects:
                if getattr(obj, 'name', '') == name:
                    return obj
        except Exception:
            pass
    for obj in getattr(bpy.data, 'objects', []):
        if getattr(obj, 'name', '') == name:
            return obj
    return None

def restore_scene_material_assignments(context, objects_payload, material_lookup: dict[str, object]) -> dict:
    result = {'objects_found': 0, 'objects_missing': 0, 'slots_restored': 0, 'materials_missing': 0, 'empty_slots_skipped': 0, 'notes': []}
    if not isinstance(objects_payload, list):
        result['notes'].append(tx(None, 'The manifest has no objects to restore.', 'マニフェストに復元するオブジェクトがありません。'))
        return result
    for item in objects_payload:
        if not isinstance(item, dict):
            continue
        obj = _scene_object_by_name(context, str(item.get('name', '') or ''))
        if obj is None:
            result['objects_missing'] += 1
            continue
        mats = getattr(getattr(obj, 'data', None), 'materials', None)
        if mats is None:
            continue
        result['objects_found'] += 1
        slot_items = sorted([slot for slot in item.get('materials', []) if isinstance(slot, dict)], key=lambda slot: int(slot.get('slot', 0) or 0))
        for slot in slot_items:
            slot_index = max(0, int(slot.get('slot', 0) or 0))
            source_name = slot.get('material')
            if not source_name:
                result['empty_slots_skipped'] += 1
                continue
            material = material_lookup.get(str(source_name)) or bpy.data.materials.get(str(source_name))
            if material is None:
                result['materials_missing'] += 1
                continue
            try:
                while len(mats) <= slot_index:
                    try:
                        mats.append(None)
                    except Exception:
                        break
                if len(mats) <= slot_index:
                    mats.append(material)
                else:
                    mats[slot_index] = material
                result['slots_restored'] += 1
            except Exception as exc:
                result['notes'].append(f"{getattr(obj, 'name', '<object>')}[{slot_index}] -> {source_name}: {_exc_text(exc)}")
    return result

def restore_scene_world_from_manifest(context, payload: dict) -> dict:
    result = {'restored': False, 'notes': [], 'path': ''}
    world_payload = payload.get('world', {})
    if not isinstance(world_payload, dict):
        result['notes'].append(tx(None, 'The manifest has no world to restore.', 'マニフェストに復元するワールドがありません。'))
        return result
    raw_path = str(world_payload.get('path', '') or '').strip()
    if not raw_path:
        result['notes'].append(tx(None, 'The manifest has no HDRI path.', 'マニフェストに HDRI のパスがありません。'))
        return result
    scene = context.scene
    try:
        scene.sss_hdri_strength = float(world_payload.get('strength', scene.sss_hdri_strength))
    except Exception:
        pass
    try:
        scene.sss_hdri_rotation = float(world_payload.get('rotation', scene.sss_hdri_rotation))
    except Exception:
        pass
    candidate = Path(bpy.path.abspath(raw_path))
    if not candidate.exists():
        root_raw = scene.sss_texture_search_root.strip()
        if root_raw:
            root = Path(bpy.path.abspath(root_raw))
            raw_name = bpy.path.basename(raw_path)
            matches = environment.collect_hdri_candidates(root, raw_name)
            if not matches:
                matches = environment.collect_hdri_candidates(root, Path(raw_name).stem)
            if matches:
                candidate = matches[0]
    if not candidate.exists():
        result['notes'].append(tx(None, f'HDRI not found: {bpy.path.basename(raw_path)}', f'HDRI が見つかりません: {bpy.path.basename(raw_path)}'))
        return result
    scene.sss_hdri_path = str(candidate)
    build = environment.build_hdri_world(context, candidate, strength=getattr(scene, 'sss_hdri_strength', 1.0), rotation=getattr(scene, 'sss_hdri_rotation', 0.0))
    result['path'] = str(candidate)
    result['restored'] = bool(build.get('loaded_image'))
    result['notes'].extend(build.get('notes', []))
    return result

class SSS_OT_create_pbr_fx_material(Operator):
    bl_idname = 'sss.create_pbr_fx_material'
    bl_label = _lt('Create Preset Look Material', 'プリセットルックマテリアル作成')
    bl_description = _lt('JP: PBR、スタイライズ、FX系プリセットから新しいマテリアルを作成し、必要なら選択オブジェクトへ割り当てます。\nEN: Create a material from a PBR, stylized, or FX preset and optionally assign it to selected objects.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        preset_id = str(getattr(scene, 'sss_pbr_preset_name', '') or '').strip()
        if preset_id in INVALID_PRESET_IDS or not preset_id:
            self.report({'ERROR'}, tx(scene, 'No preset selected.', _lt('プリセットが選択されていません。')))
            return {'CANCELLED'}
        meta = data.PRESET_LIBRARY.get(preset_id, {})
        if meta.get('family') not in {'PBR', 'FX', 'STYLIZED'}:
            self.report({'ERROR'}, tx(scene, 'The selected item is not a built-in material look preset.', _lt('選択項目は内蔵マテリアルルックプリセットではありません。')))
            return {'CANCELLED'}
        try:
            material = create_builtin_material_from_preset_id(context, preset_id)
            assigned = finish_created_preset_material(context, material, report_title_en='Preset look material created.', report_title_ja='プリセットルックマテリアルを作成しました。')
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, tx(scene, f'{material.name} created. Assigned={assigned}', _lt(f'{material.name} を作成しました。割当={assigned}')))
        return {'FINISHED'}


class SSS_OT_create_preset_material(Operator):
    bl_idname = 'sss.create_preset_material'
    bl_label = _lt('Create Preset Material', 'プリセットマテリアル作成')
    bl_description = _lt('JP: 選択したプリセットから新しいマテリアルを作成し、必要なら選択オブジェクトへ割り当てます。\nEN: Create a new material from the selected preset and optionally assign it to selected objects.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        try:
            material = create_material_from_scene_preset(context)
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        notes = postprocess_material_graph(material, context)
        if scene.sss_mark_asset:
            core.mark_material_as_asset(material)
        assigned = core.assign_material_to_selected(context, material) if core.material_generation_should_assign_selected(context) else 0
        if not assigned:
            core.set_active_material(context, material)
        scene.sss_target_material_name = material.name
        if scene.sss_auto_audit_after_build:
            core.report_to_scene(scene, join_notes(audit.format_audit_report(material, context), notes))
        else:
            core.report_to_scene(scene, join_notes(tx(scene, 'Material created.', _lt('マテリアルを作成しました。')), notes))
        self.report({'INFO'}, _lt(f'{material.name} created. Assigned={assigned}'))
        return {'FINISHED'}

class SSS_OT_create_photo_pbr(Operator):
    bl_idname = 'sss.create_photo_pbr'
    bl_label = _lt('Create Photo PBR', '写真PBR作成')
    bl_description = _lt('JP: 1枚の写真から安全寄りの PBR スターターマップを生成し、その結果から管理マテリアルを自動配線付きで構築します。完全再現ではなく、あとで整えやすい下地生成を目的としています。\nEN: Generate a conservative starter PBR set from one photo, then build a managed material with auto-wired maps. The goal is an editable starting point rather than a claim of perfect physical reconstruction.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        source_raw = str(getattr(scene, 'sss_photo_source', '') or '').strip()
        if not source_raw:
            self.report({'ERROR'}, _lt('JP: 元画像を指定してください。 / EN: Choose a source image first.'))
            return {'CANCELLED'}
        try:
            source_path = Path(bpy.path.abspath(source_raw))
        except Exception:
            source_path = Path(source_raw)
        if not source_path.exists() or not source_path.is_file():
            self.report({'ERROR'}, _lt('JP: 元画像が見つかりません。 / EN: Source image not found.'))
            return {'CANCELLED'}
        output_raw = str(getattr(scene, 'sss_photo_output_dir', '') or '').strip()
        output_dir = None
        if output_raw:
            try:
                output_dir = Path(bpy.path.abspath(output_raw))
            except Exception:
                output_dir = Path(output_raw)
        try:
            generated = sampler.generate_pbr_maps(source_path, output_dir=output_dir, max_size=getattr(scene, 'sss_photo_max_size', 1024), normal_strength=getattr(scene, 'sss_photo_normal_strength', 3.0), detail_strength=getattr(scene, 'sss_photo_detail_strength', 1.0))
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        files = [Path(path) for path in (generated.get('generated') or {}).values() if path]
        if not files:
            self.report({'ERROR'}, _lt('JP: 生成されたマップがありません。 / EN: No generated maps were produced.'))
            return {'CANCELLED'}
        material_name = str(getattr(scene, 'sss_material_name', '') or '').strip() or f'{source_path.stem}_PBR'
        material = bpy.data.materials.new(name=material_name)
        material.use_fake_user = bool(getattr(scene, 'sss_use_fake_user', True))
        usage_hints = {str(Path(path).resolve()): usage for usage, path in (generated.get('generated') or {}).items() if path}
        try:
            build = textures.build_material_from_texture_files(material, files, force=bool(getattr(scene, 'sss_texture_force_rewire', True)), group_name=f'PhotoToPBR:{source_path.stem}', usage_hints=usage_hints)
        except Exception:
            core.safe_remove_id(bpy.data.materials, material)
            raise
        params = {'photo_source': str(source_path), 'generated_map_count': len(files), 'max_size': int(getattr(scene, 'sss_photo_max_size', 1024)), 'normal_strength': float(getattr(scene, 'sss_photo_normal_strength', 3.0)), 'detail_strength': float(getattr(scene, 'sss_photo_detail_strength', 1.0))}
        core.set_managed_metadata_only(material, note_en='Managed material generated from a photo-to-PBR starter workflow.', note_ja=_lt('写真からPBRのスターターワークフローで生成した管理マテリアルです。'), params=params, tags=['PhotoToPBR', 'ImageToMaterial', 'Generated', 'Managed'])
        try:
            manifest = core.material_manifest(material, context)
            core.write_manifest_text_block(material.name, manifest)
        except Exception:
            pass
        notes = list(build.get('notes', [])) + postprocess_material_graph(material, context)
        if scene.sss_mark_asset:
            core.mark_material_as_asset(material)
        assigned = core.assign_material_to_selected(context, material) if core.material_generation_should_assign_selected(context) else 0
        if not assigned:
            core.set_active_material(context, material)
        scene.sss_target_material_name = material.name
        summary = [tx(scene, f'Photo source: {source_path.name}', _lt(f'元画像: {source_path.name}')), tx(scene, f'Generated maps: {len(files)}', _lt(f'生成マップ数: {len(files)}')), tx(scene, f"Output: {generated.get('output_dir', '-')}", _lt(f"出力先: {generated.get('output_dir', '-')}")), tx(scene, f"Manifest: {generated.get('manifest_path', '-')}", _lt(f"マニフェスト: {generated.get('manifest_path', '-')}"))]
        if scene.sss_auto_audit_after_build:
            report = join_notes(audit.format_audit_report(material, context), summary + notes)
        else:
            report = join_notes(tx(scene, 'Photo-to-PBR material created.', _lt('写真からPBRのマテリアルを作成しました。')), summary + notes)
        core.report_to_scene(scene, report)
        self.report({'INFO'}, _lt(f'Photo-to-PBR created: {material.name}'))
        return {'FINISHED'}


def _smart_toon_apply_pbr_base_preview_selection(context, preset_id: str, target: str = 'MAIN', generate: bool = False) -> bool:
    """Apply a clicked PBR preview to Smart Toon only when Smart Toon opened the picker."""
    try:
        if bool(generate) or str(target or '').upper() not in {'PBR', 'PBR_FX'}:
            return False
        scene = getattr(context, 'scene', None)
        if scene is None or not bool(scene.get('sss_smart_toon_pbr_base_preview_pending', False)):
            return False
        try:
            scene['sss_smart_toon_pbr_base_preview_pending'] = False
        except Exception:
            pass
        preset_id = str(preset_id or '').strip()
        if not preset_id:
            return False
        # This runs from the modal preview picker, which closes itself right
        # afterwards.  Invoking sss.smart_toon_use_pbr_preset_base through
        # bpy.ops made a second operator queue an INFO/ERROR report that Blender
        # then had to draw against the picker's dying fullscreen screen, and it
        # is also reachable from an RNA update callback where bpy.ops is not
        # allowed at all.  Do the same work directly on the data instead.
        from . import smart_toon as _smart_toon
        material = _smart_toon._active_material(context)
        if material is None:
            report_safety.console({'WARNING'}, 'No active material for the Smart Toon PBR/FX base.')
            return False
        if not _smart_toon._smart_toon_is_pbr_preset_id(preset_id):
            report_safety.console({'WARNING'}, 'Not a PBR/FX preset id: %s' % preset_id)
            return False
        if not _smart_toon._smart_toon_set_material_to_pbr_base(material, preset_id, mark_toon=True):
            return False
        _smart_toon.rebuild_toon_material(material)
        report_safety.console({'INFO'}, 'Smart Toon PBR/FX base applied: %s' % preset_id)
        return True
    except Exception as exc:
        report_safety.console({'WARNING'}, 'Smart Toon PBR/FX base preview failed: %s' % exc)
        return False


class SSS_OT_select_preset_from_preview(Operator):
    bl_idname = 'sss.select_preset_from_preview'
    bl_label = _lt('Select Preset from Preview', 'プレビューからプリセット選択')
    bl_description = _lt('Select the clicked preset thumbnail and sync the Smart Shader preset fields. PBR Material Generation is updated when the chosen preset belongs to PBR or FX.', 'クリックしたプレビューのプリセットを選択し、スマートシェーダーのプリセット欄へ反映します。PBR または FX の場合は PBR マテリアル生成欄も更新します。')
    bl_options = set()
    _sms_no_undo = True

    preset_id: StringProperty(options={'SKIP_SAVE'})
    target: StringProperty(default='MAIN', options={'SKIP_SAVE'})
    generate: BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        preset_id = str(getattr(properties, 'preset_id', '') or '').strip()
        scene = getattr(context, 'scene', None)
        meta = data.PRESET_LIBRARY.get(preset_id, {}) if preset_id else {}
        label = tx(scene, meta.get('label_en', preset_id), meta.get('label_ja', preset_id)) if meta else preset_id
        summary = tx(scene, meta.get('summary_en', ''), meta.get('summary_ja', '')) if meta else ''
        if summary:
            return tx(scene, f'Name: {label}\nSummary: {summary}', _lt(f'名前: {label}\n概要: {summary}'))
        if label:
            return tx(scene, f'Name: {label}', _lt(f'名前: {label}'))
        return cls.bl_description

    def execute(self, context):
        scene = getattr(context, 'scene', None)
        preset_id = str(getattr(self, 'preset_id', '') or '').strip()
        target = str(getattr(self, 'target', 'MAIN') or 'MAIN').upper()
        if not preset_id:
            self.report({'ERROR'}, tx(scene, 'Preset could not be selected.', _lt('プリセットを選択できませんでした。')))
            return {'CANCELLED'}
        try:
            selected, material, assigned = preset_preview_browser.select_or_generate_preset(
                context,
                preset_id,
                target=target,
                generate=bool(getattr(self, 'generate', False)),
            )
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        if not selected:
            self.report({'ERROR'}, tx(scene, 'Preset could not be selected.', _lt('プリセットを選択できませんでした。')))
            return {'CANCELLED'}
        if _smart_toon_apply_pbr_base_preview_selection(context, preset_id, target=target, generate=bool(getattr(self, 'generate', False))):
            self.report({'INFO'}, tx(scene, 'Selected preview was applied as the Smart Toon PBR/FX base.', _lt('選択したプレビューをスマート トゥーンのPBR/FXベースへ反映しました。')))
            return {'FINISHED'}
        if material is not None:
            self.report({'INFO'}, tx(scene, f'{material.name} created from preview. Assigned={assigned}', _lt(f'{material.name} をプレビューから作成しました。割当={assigned}')))
            return {'FINISHED'}
        self.report({'INFO'}, tx(scene, f'Selected preset: {preset_preview_browser.preset_label(scene, preset_id)}', _lt(f'プリセットを選択しました: {preset_preview_browser.preset_label(scene, preset_id)}')))
        return {'FINISHED'}


class SSS_OT_open_preset_preview_popup(Operator):
    bl_idname = 'sss.open_preset_preview_popup'
    bl_label = _lt('Preset Image List', 'プリセット画像一覧')
    bl_description = _lt('Show built-in preset previews as large image-only buttons. Hover a thumbnail to read its name and summary, then click it to select the preset.', '組み込みプリセットのプレビューを、大きめの画像だけのボタンとして表示します。画像にマウスを置くと名前と概要をツールチップで確認でき、クリックするとプリセットを選択します。')
    bl_options = set()
    _sms_no_undo = True

    target: StringProperty(default='MAIN', options={'SKIP_SAVE'})
    generate: BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return preset_preview_browser.workspace_runtime_allowed(context)

    def _execute_preview_selection(self, context, preset_id: str, target: str = 'MAIN', generate: bool = False):
        # Direct path used by the image-button picker.  It avoids bpy.ops during
        # modal teardown, so clicking a preview with generate=True reliably
        # creates the material instead of only updating dropdown fields.
        ctx = context
        try:
            if getattr(bpy, 'context', None) is not None and getattr(bpy.context, 'scene', None) is not None:
                ctx = bpy.context
        except Exception:
            pass
        scene = getattr(ctx, 'scene', None) if ctx is not None else None
        preset_id = str(preset_id or '').strip()
        target = str(target or 'MAIN').upper()
        if not preset_id or not preset_preview_browser.select_preset(scene, preset_id, target=target):
            self.report({'ERROR'}, tx(scene, 'Preset could not be selected.', _lt('プリセットを選択できませんでした。')))
            return {'CANCELLED'}
        if _smart_toon_apply_pbr_base_preview_selection(ctx, preset_id, target=target, generate=bool(generate)):
            self.report({'INFO'}, tx(scene, 'Selected preview was applied as the Smart Toon PBR/FX base.', _lt('選択したプレビューをスマート トゥーンのPBR/FXベースへ反映しました。')))
            return {'FINISHED'}
        if bool(generate):
            try:
                material = create_builtin_material_from_preset_id(ctx, preset_id)
                assigned = finish_created_preset_material(ctx, material, report_title_en='Preset look material created from preview.', report_title_ja='プレビューからプリセットルックマテリアルを作成しました。')
            except Exception as exc:
                self.report({'ERROR'}, _exc_text(exc))
                return {'CANCELLED'}
            self.report({'INFO'}, tx(scene, f'{material.name} created from preview. Assigned={assigned}', _lt(f'{material.name} をプレビューから作成しました。割当={assigned}')))
            return {'FINISHED'}
        self.report({'INFO'}, tx(scene, f'Selected preset: {preset_preview_browser.preset_label(scene, preset_id)}', _lt(f'プリセットを選択しました: {preset_preview_browser.preset_label(scene, preset_id)}')))
        return {'FINISHED'}

    def invoke(self, context, event):
        if not preset_preview_browser.workspace_runtime_allowed(context):
            return {'CANCELLED'}
        wm = getattr(context, 'window_manager', None)
        if wm is None:
            return {'CANCELLED'}
        target = str(getattr(self, 'target', 'MAIN') or 'MAIN').upper()
        try:
            preset_preview_browser.sync_preview_choice(context, target=target)
        except Exception:
            pass
        try:
            preset_preview_browser.prepare_preview_grid(context, target=target, generate=bool(getattr(self, 'generate', False)), force=True)
        except Exception:
            pass
        # Blender 5.1 native UI cannot make preview PNGs fill operator buttons
        # and does not provide a scrollable image-button grid without the
        # unsupported template_list(type="GRID") path.  Use the internal
        # fullscreen modal picker instead: it does not create a new 3D View/window,
        # draws the PNG itself as the clickable button, keeps category groups, and
        # provides an internal scrollbar.  A native popup is retained only as a
        # safe fallback when GPU drawing is unavailable.
        result = preset_preview_browser.open_modal_preview_picker(
            self,
            context,
            target=target,
            generate=bool(getattr(self, 'generate', False)),
            columns=12,
            use_dedicated_window=False,
        )
        if result:
            return result
        try:
            win_w = int(getattr(getattr(context, 'window', None), 'width', 0) or 0)
        except Exception:
            win_w = 0
        popup_width = max(960, min(1480, win_w - 40 if win_w > 0 else 1180))
        return wm.invoke_popup(self, width=popup_width)

    def modal(self, context, event):
        try:
            return preset_preview_browser.modal_preview_picker(self, context, event)
        except Exception:
            try:
                preset_preview_browser.close_modal_preview_picker(self)
            except Exception:
                pass
            return {'CANCELLED'}

    def cancel(self, context):
        try:
            preset_preview_browser.close_modal_preview_picker(self)
        except Exception:
            pass

    def draw(self, context):
        layout = self.layout
        target = str(getattr(self, 'target', 'MAIN') or 'MAIN').upper()
        grid = layout.box()
        preset_preview_browser.draw_preview_icon_grid(grid, context, target=target, generate=bool(getattr(self, 'generate', False)), columns=12)

    def execute(self, context):
        return {'FINISHED'}


class SSS_OT_render_preset_previews(Operator):
    bl_idname = 'sss.render_preset_previews'
    bl_label = _lt('Render Preset Previews', 'プリセットプレビュー生成')
    bl_description = _lt('JP: すべてのシェーダープリセットをSuzanneへ適用し、256×256のレンダリング画像をBlender の設定フォルダー/Smart_Shader_Suite/preset_previewsへ生成します。同梱画像とアドオン本体は変更しません。\nEN: Apply every shader preset to Suzanne and render 256x256 preview images into Blender config/Smart_Shader_Suite/preset_previews. Bundled images and the installed add-on remain unchanged.')
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        user_scene = context.scene
        preview_dir = preset_preview_root()
        preview_scene = None
        original_window_scene = None
        try:
            preview_scene, monkey, original_window_scene = _setup_preview_scene(context)
            scene = preview_scene
            rendered = 0
            failures = []
            material_name_backup = str(getattr(user_scene, 'sss_material_name', '') or '')
            for preset_id in data.PRESET_LIBRARY.keys():
                try:
                    if monkey.active_material is not None:
                        monkey.active_material = None
                    material = bpy.data.materials.new(name=f'SSS Preview {preset_id}')
                    material.use_fake_user = False
                    builders.build_preset(material, preset_id)
                    if len(monkey.data.materials):
                        monkey.data.materials[0] = material
                    else:
                        monkey.data.materials.append(material)
                    scene.render.filepath = str(preset_preview_path(preset_id))
                    bpy.ops.render.render(write_still=True, scene=scene.name)
                    rendered += 1
                except Exception as exc:
                    failures.append(f'{preset_id}: {_exc_text(exc)}')
                finally:
                    try:
                        material = monkey.active_material or (monkey.data.materials[0] if len(monkey.data.materials) else None)
                    except Exception:
                        material = None
                    try:
                        monkey.data.materials.clear()
                    except Exception:
                        pass
                    if material is not None and getattr(material, 'users', 0) == 0:
                        try:
                            bpy.data.materials.remove(material)
                        except Exception:
                            pass
            try:
                user_scene.sss_material_name = material_name_backup
            except Exception:
                pass
            if failures:
                summary = tx(user_scene, f'Rendered previews: {rendered}. Failed: {len(failures)}', _lt(f'生成済みプレビュー: {rendered}件 / 失敗: {len(failures)}件'))
                core.report_to_scene(user_scene, summary + '\n' + '\n'.join(failures[:10]))
                self.report({'WARNING'}, tx(user_scene, f'Rendered previews: {rendered} / failed: {len(failures)}', _lt(f'プレビュー生成: {rendered}件 / 失敗: {len(failures)}件')))
            else:
                core.report_to_scene(user_scene, tx(user_scene, f'All preset previews rendered to {preview_dir}', _lt(f'全プリセットのプレビューを生成しました: {preview_dir}')))
                self.report({'INFO'}, tx(user_scene, f'Rendered {rendered} preset previews', _lt(f'{rendered}件のプリセットプレビューを生成しました')))
            return {'FINISHED'}
        finally:
            _cleanup_preview_scene(context, preview_scene, original_window_scene)


class SSS_OT_apply_to_active(Operator):
    bl_idname = 'sss.apply_to_active'
    bl_label = _lt('Apply to Active', 'アクティブへ適用')
    bl_description = _lt('JP: 選択中のプリセットをアクティブマテリアルへ適用します。非破壊モードでは複製してから適用します。\nEN: Apply the selected preset to the active material. In non-destructive mode, a copy is made first.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        material = core.active_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: アクティブマテリアルがありません。 / EN: No active material.'))
            return {'CANCELLED'}
        original_material = material
        material = core.duplicate_for_non_destructive(context, material)
        duplicated = material is not original_material
        material.use_fake_user = scene.sss_use_fake_user
        try:
            ensure_valid_scene_preset(scene)
            if scene.sss_preset_family == 'CUSTOM':
                entry = resolve_custom_entry(scene)
                mode = build_material_from_custom_entry(material, entry, context=context)
                if mode in {'portable', 'manifest_textures'}:
                    material['sss_summary_en'] = entry.get('summary_en', material.get('sss_summary_en', ''))
                    material['sss_summary_ja'] = entry.get('summary_ja', material.get('sss_summary_ja', ''))
            else:
                builders.build_preset(material, scene.sss_preset_name)
        except Exception as exc:
            if duplicated:
                core.safe_remove_id(bpy.data.materials, material)
                try:
                    core.set_active_material(context, original_material)
                except Exception:
                    pass
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        notes = postprocess_material_graph(material, context)
        if scene.sss_mark_asset:
            core.mark_material_as_asset(material)
        if scene.sss_assign_selected:
            core.assign_material_to_selected(context, material)
        scene.sss_target_material_name = material.name
        if scene.sss_auto_audit_after_build:
            core.report_to_scene(scene, join_notes(audit.format_audit_report(material, context), notes))
        else:
            core.report_to_scene(scene, join_notes(tx(scene, 'Preset applied.', _lt('プリセットを適用しました。')), notes))
        self.report({'INFO'}, _lt(f'Applied preset to {material.name}'))
        return {'FINISHED'}

class SSS_OT_capture_active_material(Operator):
    bl_idname = 'sss.capture_active_material'
    bl_label = _lt('Capture Active Material', 'アクティブマテリアル取込')
    bl_description = _lt('JP: 現在のアクティブマテリアルをスマートシェーダー管理対象として取り込みます。ノードは変更しません。\nEN: Register the active material as managed by Smart Shader without changing its node graph.')
    bl_options = set()

    def execute(self, context):
        material = core.active_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: アクティブマテリアルがありません。 / EN: No active material.'))
            return {'CANCELLED'}
        params = core.approx_params_from_material(material)
        core.set_managed_metadata_only(material, note_en='Captured external material managed by Smart Shader.', note_ja=_lt('スマートシェーダーで管理対象として取り込んだ既存マテリアルです。'), params=params, tags=['Captured', 'Managed'])
        if context.scene.sss_mark_asset:
            core.mark_material_as_asset(material)
        context.scene.sss_target_material_name = material.name
        core.report_to_scene(context.scene, audit.format_audit_report(material, context))
        self.report({'INFO'}, _lt(f'Captured {material.name}'))
        return {'FINISHED'}

class SSS_OT_save_custom_preset(Operator):
    bl_idname = 'sss.save_custom_preset'
    bl_label = _lt('Save Custom Preset', 'カスタムプリセット保存')
    bl_description = _lt('JP: アクティブマテリアルをカスタムプリセットとして保存します。後で再適用・再利用できます。\nEN: Save the active material as a custom preset for later reuse.')
    bl_options = set()

    def execute(self, context):
        material = core.active_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: アクティブマテリアルがありません。 / EN: No active material.'))
            return {'CANCELLED'}
        name = context.scene.sss_custom_preset_name.strip() or material.name
        core.save_custom_preset_from_material(material, name)
        core.report_to_scene(context.scene, tx(context.scene, f'Saved custom preset: {name}', _lt(f'カスタムプリセットを保存しました: {name}')))
        self.report({'INFO'}, _lt(f'Saved custom preset: {name}'))
        return {'FINISHED'}

class SSS_OT_delete_custom_preset(Operator):
    bl_idname = 'sss.delete_custom_preset'
    bl_label = _lt('Delete Custom Preset', 'カスタムプリセット削除')
    bl_description = _lt('JP: 選択中のカスタムプリセットをライブラリから削除します。不要になった保存データの整理に使います。\nEN: Delete the selected custom preset from the library to keep saved data organized.')
    bl_options = set()

    def execute(self, context):
        scene = context.scene
        if scene.sss_preset_family != 'CUSTOM':
            self.report({'ERROR'}, _lt('JP: カスタムカテゴリを開いてください。 / EN: Switch to the Custom category first.'))
            return {'CANCELLED'}
        preset_name = ensure_valid_scene_preset(scene)
        if not core.delete_custom_preset(preset_name):
            self.report({'ERROR'}, _lt('JP: カスタムプリセットを削除できませんでした。 / EN: Failed to delete the custom preset.'))
            return {'CANCELLED'}
        remaining = core.list_custom_presets()
        scene.sss_preset_name = remaining[0].get('name', 'NO_CUSTOM_PRESETS') if remaining else 'NO_CUSTOM_PRESETS'
        try:
            properties.normalize_selected_preset(scene, context)
        except Exception:
            pass
        core.report_to_scene(scene, tx(scene, f'Deleted custom preset: {preset_name}', _lt(f'カスタムプリセットを削除しました: {preset_name}')))
        self.report({'INFO'}, _lt(f'Deleted custom preset: {preset_name}'))
        return {'FINISHED'}

class SSS_OT_export_custom_library(Operator):
    bl_idname = 'sss.export_custom_library'
    bl_label = _lt('Export Library', 'ライブラリ書出し')
    bl_description = _lt('JP: 現在のカスタムプリセットライブラリを JSON として書き出します。共有、バックアップ、クラウド保存の土台に使えます。\nEN: Export the current custom preset library as JSON for sharing, backup, or cloud storage.')
    bl_options = set()
    _sms_no_undo = True
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = str(core.addon_storage_dir() / 'smart_shader_suite_custom_presets.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        export_path = ensure_json_export_path(self.filepath, 'smart_shader_suite_custom_presets.json')
        count = core.export_custom_preset_library(export_path)
        try:
            properties.normalize_selected_preset(context.scene, context)
        except Exception:
            pass
        message = tx(context.scene, f'Exported custom preset library: {count} presets', _lt(f'カスタムプリセットライブラリを書き出しました: {count} 件'))
        core.report_to_scene(context.scene, join_notes(message, [str(export_path)]))
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_import_custom_library(Operator):
    bl_idname = 'sss.import_custom_library'
    bl_label = _lt('Import Library', 'ライブラリ読込')
    bl_description = _lt('JP: JSON からカスタムプリセットライブラリを読み込みます。追加更新は追加更新、全置換は全置換です。\nEN: Import a custom preset library from JSON. Merge updates by name, Replace swaps the whole library.')
    bl_options = set()
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = str(core.addon_storage_dir() / 'smart_shader_suite_custom_presets.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        path = ensure_json_import_path(self.filepath)
        if not path.exists() or not path.is_file():
            self.report({'ERROR'}, _lt('JP: ファイルが見つかりません。 / EN: File not found.'))
            return {'CANCELLED'}
        result = core.import_custom_preset_library(path, mode=getattr(context.scene, 'sss_custom_library_mode', 'MERGE'))
        try:
            properties.normalize_selected_preset(context.scene, context)
        except Exception:
            pass
        message = tx(context.scene, f"Imported={result['imported']} Replaced={result['replaced']} Invalid={result['skipped_invalid']} Total={result['total']}", _lt(f"追加={result['imported']} 置換={result['replaced']} 不正={result['skipped_invalid']} 合計={result['total']}"))
        core.report_to_scene(context.scene, join_notes(message, [str(path), f"mode={result['mode']}"]))
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_repair_custom_library(Operator):
    bl_idname = 'sss.repair_custom_library'
    bl_label = _lt('Repair Library', 'ライブラリ修復')
    bl_description = _lt('JP: 壊れた、重複した、名前のないカスタムプリセットを整理し、ライブラリを安全な形へ再保存します。\nEN: Repair broken, duplicate, or unnamed custom presets and resave the library in a safe normalized form.')
    bl_options = set()

    def execute(self, context):
        result = core.repair_custom_preset_library()
        try:
            properties.normalize_selected_preset(context.scene, context)
        except Exception:
            pass
        message = tx(context.scene, f"Custom library repaired: before={result['before']} after={result['after']} dropped={result['dropped']} duplicates={result['duplicates']}", _lt(f"カスタムライブラリを修復しました: 修復前={result['before']} 修復後={result['after']} 破棄={result['dropped']} 重複整理={result['duplicates']}"))
        core.report_to_scene(context.scene, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_assign_to_selection(Operator):
    bl_idname = 'sss.assign_to_selection'
    bl_label = _lt('Assign to Selection', '選択へ割当')
    bl_description = _lt('JP: マネージャーで選択した材質を選択オブジェクトへまとめて割り当てます。\nEN: Assign the manager target material to all selected objects.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = core.get_target_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象マテリアルが見つかりません。 / EN: Target material not found.'))
            return {'CANCELLED'}
        assigned = core.assign_material_to_selected(context, material)
        core.report_to_scene(context.scene, tx(context.scene, f'Assigned to {assigned} object(s).', _lt(f'{assigned} 個のオブジェクトへ割り当てました。')))
        self.report({'INFO'}, _lt(f'Assigned to {assigned} object(s)'))
        return {'FINISHED'}

class SSS_OT_set_active_target(Operator):
    bl_idname = 'sss.set_active_target'
    bl_label = _lt('Set Active Target', 'アクティブターゲット設定')
    bl_description = _lt('JP: マネージャーで選択した材質をアクティブオブジェクトへ設定します。\nEN: Set the manager target material on the active object.')
    bl_options = set()

    def execute(self, context):
        material = core.get_target_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象マテリアルが見つかりません。 / EN: Target material not found.'))
            return {'CANCELLED'}
        # Only the active object: assigning to the selection is the separate assign_to_selection button.
        if not core.set_material_on_object(getattr(context, 'object', None), material, core.assign_mode(context), context=context):
            self.report({'ERROR'}, _lt('JP: アクティブオブジェクトへ設定できません。 / EN: Failed to set the active material.'))
            return {'CANCELLED'}
        core.report_to_scene(context.scene, tx(context.scene, 'Active material set.', _lt('アクティブ材質を設定しました。')))
        self.report({'INFO'}, _lt(f'Set active material: {material.name}'))
        return {'FINISHED'}

class SSS_OT_select_users(Operator):
    bl_idname = 'sss.select_users'
    bl_label = _lt('Select Users', '使用オブジェクト選択')
    bl_description = _lt('JP: ターゲットまたはアクティブマテリアルを使っているオブジェクトをシーンから選択します。材質から逆引きしたい時に便利です。\nEN: Select all scene objects using the target or active material. Useful for reverse-lookup from a material to its assigned objects.')
    bl_options = set()

    def execute(self, context):
        material = choose_target_or_active(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material.'))
            return {'CANCELLED'}
        count = core.select_objects_by_material(context, material, extend=False)
        core.report_to_scene(context.scene, tx(context.scene, f'Selected objects using {material.name}: {count}', _lt(f'{material.name} を使うオブジェクトを選択: {count}')))
        self.report({'INFO'}, _lt(f'Selected {count} object(s)'))
        return {'FINISHED'}

class SSS_OT_use_index_pick(Operator):
    bl_idname = 'sss.use_index_pick'
    bl_label = _lt('Use Index Pick', 'インデックス選択を使用')
    bl_description = _lt('JP: シーン材質インデックス で選んだ材質を、マネージャーのターゲット材質へ設定します。逆引きした材質をそのまま管理・比較・置換の流れへつなげたい時に便利です。\nEN: Push the material selected in the Scene Material Index into the manager target field. Useful when you want to go from scene lookup directly into management, compare, or replace workflows.')
    bl_options = set()

    def execute(self, context):
        pick = getattr(context.scene, 'sss_inventory_pick', '')
        if pick == inventory.INVENTORY_SENTINEL:
            self.report({'ERROR'}, tx(context.scene, 'Pick a real inventory material first.', _lt('先に実際のインデックス材質を選択してください。')))
            return {'CANCELLED'}
        entry = inventory.find_inventory_entry(pick, scene=context.scene)
        if not entry:
            self.report({'ERROR'}, tx(context.scene, 'Inventory material could not be found.', _lt('選択したインデックス材質が見つかりません。')))
            return {'CANCELLED'}
        context.scene.sss_target_material_name = entry.get('name', '')
        core.report_to_scene(context.scene, tx(context.scene, f"Inventory pick set as target: {entry.get('name', '-')}", _lt(f"インデックス材質をターゲット化: {entry.get('name', '-')}")))
        self.report({'INFO'}, _lt(f"Inventory target set: {entry.get('name', '-')}"))
        return {'FINISHED'}

class SSS_OT_select_index_users(Operator):
    bl_idname = 'sss.select_index_users'
    bl_label = _lt('Select Index Users', 'インデックス使用者選択')
    bl_description = _lt('JP: シーン材質インデックス で選んだ材質を使っているオブジェクトを選択します。逆引きを、管理欄からすぐ行いたい時に便利です。\nEN: Select objects using the material chosen in the Scene Material Index. Useful for a Scene Materials style reverse lookup directly from the manager area.')
    bl_options = set()

    def execute(self, context):
        pick = getattr(context.scene, 'sss_inventory_pick', '')
        if pick == inventory.INVENTORY_SENTINEL:
            self.report({'ERROR'}, tx(context.scene, 'Pick a real inventory material first.', _lt('先に実際のインデックス材質を選択してください。')))
            return {'CANCELLED'}
        entry = inventory.find_inventory_entry(pick, scene=context.scene)
        material = None if not entry else entry.get('material')
        if material is None:
            self.report({'ERROR'}, tx(context.scene, 'Inventory material could not be found.', _lt('選択したインデックス材質が見つかりません。')))
            return {'CANCELLED'}
        count = core.select_objects_by_material(context, material, extend=False)
        core.report_to_scene(context.scene, tx(context.scene, f'Selected users of {material.name}: {count}', _lt(f'{material.name} の使用オブジェクトを選択: {count}')))
        self.report({'INFO'}, _lt(f'Selected {count} object(s)'))
        return {'FINISHED'}

class SSS_OT_unassign_material(Operator):
    bl_idname = 'sss.unassign_material'
    bl_label = _lt('Unassign Material', 'マテリアル割当解除')
    bl_description = _lt('JP: 選択オブジェクトからターゲット材質を外します。割当方式に応じて現在スロット、先頭、または一致スロットを安全に整理します。\nEN: Remove the target material from selected objects. Depending on Assign Mode, the current slot, first slot, or matching slots are cleared and then cleaned safely.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = core.get_target_material(context) or core.active_material(context)
        objects = list(getattr(context, 'selected_objects', []) or [])
        if not objects and getattr(context, 'object', None):
            objects = [context.object]
        if not objects:
            self.report({'ERROR'}, _lt('JP: 対象オブジェクトがありません。 / EN: No target object was found.'))
            return {'CANCELLED'}
        result = core.clear_material_from_objects(objects, material=material, mode=core.assign_mode(context))
        core.report_to_scene(context.scene, tx(context.scene, f"Cleared slots: {result['cleared_slots']} | Removed slots: {result['removed_slots']} | Remapped faces: {result['remapped_faces']}", _lt(f"解除スロット: {result['cleared_slots']} | 削除スロット: {result['removed_slots']} | 再割当面数: {result['remapped_faces']}")))
        self.report({'INFO'}, _lt(f"Cleared={result['cleared_slots']} Removed={result['removed_slots']}"))
        return {'FINISHED'}

class SSS_OT_preview_diff(Operator):
    bl_idname = 'sss.preview_diff'
    bl_label = _lt('Preview Diff', '差分プレビュー')
    bl_description = _lt('JP: 比較元材質とターゲット材質の保存情報、使用数、テクスチャ用途、欠損状況などを比較し、置換前の判断材料をレポートします。\nEN: Compare the source and target materials by stored metadata, usage counts, texture roles, and missing-file state, then write a pre-replace report.')
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        source = choose_compare_source(context)
        target = core.get_target_material(context) or core.active_material(context)
        if not source or not target:
            self.report({'ERROR'}, _lt('JP: 比較元または比較先がありません。 / EN: Missing source or target material.'))
            return {'CANCELLED'}
        diff = core.compare_materials(source, target, objects=getattr(bpy.data, 'objects', []))
        lines = material_diff_report_lines(context.scene, diff)
        core.report_to_scene(context.scene, '\n'.join(lines))
        self.report({'INFO'}, _lt(f'Compared {source.name} -> {target.name}'))
        return {'FINISHED'}

class SSS_OT_replace_with_target(Operator):
    bl_idname = 'sss.replace_with_target'
    bl_label = _lt('Replace with Target', 'ターゲットへ置換')
    bl_description = _lt('JP: 比較元材質の参照を、現在のターゲット材質へ置換します。選択オブジェクトだけ、またはシーン全体を対象にでき、置換後はスロット整理も行います。\nEN: Replace references to the compare-source material with the current target material. The change can be limited to selected objects or applied scene-wide, followed by slot cleanup.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        source = choose_compare_source(context)
        target = core.get_target_material(context) or core.active_material(context)
        if not source or not target:
            self.report({'ERROR'}, _lt('JP: 比較元または比較先がありません。 / EN: Missing source or target material.'))
            return {'CANCELLED'}
        if source == target:
            self.report({'ERROR'}, _lt('JP: 同じ材質同士は置換できません。 / EN: Source and target material are identical.'))
            return {'CANCELLED'}
        scope = str(getattr(scene, 'sss_replace_scope', 'SELECTED') or 'SELECTED').upper()
        objects = list(getattr(context, 'selected_objects', []) or []) if scope == 'SELECTED' else list(getattr(bpy.data, 'objects', []))
        if scope == 'SELECTED' and (not objects):
            self.report({'ERROR'}, _lt('JP: 選択オブジェクトがありません。 / EN: No selected objects.'))
            return {'CANCELLED'}
        result = core.replace_material_in_scope(source, target, scope=scope, objects=objects, cleanup_slots=True)
        message = tx(scene, f"Replaced {source.name} -> {target.name} | Changed slots={result['changed_slots']} | Removed slots={result['removed_slots']} | Remapped faces={result['remapped_faces']}", _lt(f"置換しました {source.name} -> {target.name} | 変更スロット={result['changed_slots']} | 削除スロット={result['removed_slots']} | 再割当面数={result['remapped_faces']}"))
        core.report_to_scene(scene, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_save_rule(Operator):
    bl_idname = 'sss.save_rule'
    bl_label = _lt('Save Rule', 'ルール保存')
    bl_description = _lt('JP: 現在のターゲット材質と条件欄を、一括材質割当ルールとして保存します。オブジェクト名、コレクション名、現在材質名の条件を再利用できます。\nEN: Save the current target material and match fields as a reusable batch material-assignment rule. Reuse object-name, collection-name, and current-material conditions later.')
    bl_options = set()

    def execute(self, context):
        scene = context.scene
        target = core.get_target_material(context) or core.active_material(context)
        if not target:
            self.report({'ERROR'}, _lt('JP: ターゲット材質がありません。 / EN: No target material was found.'))
            return {'CANCELLED'}
        name = str(getattr(scene, 'sss_rule_name', '') or '').strip() or f'Assign {target.name}'
        entry = rules.save_assignment_rule({'name': name, 'material_name': target.name, 'object_pattern': getattr(scene, 'sss_rule_object_pattern', ''), 'collection_pattern': getattr(scene, 'sss_rule_collection_pattern', ''), 'current_material_pattern': getattr(scene, 'sss_rule_current_material_pattern', ''), 'use_regex': getattr(scene, 'sss_rule_use_regex', False), 'scope': getattr(scene, 'sss_rule_scope', 'SELECTED'), 'assign_mode': getattr(scene, 'sss_assign_mode', 'ACTIVE_SLOT')})
        scene.sss_rule_pick = entry['name']
        scene.sss_rule_name = entry['name']
        message = tx(scene, f"Saved assignment rule: {entry['name']}", _lt(f"割当ルールを保存しました: {entry['name']}"))
        core.report_to_scene(scene, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_preview_rule(Operator):
    bl_idname = 'sss.preview_rule'
    bl_label = _lt('Preview Rule', 'ルールプレビュー')
    bl_description = _lt('JP: 保存済みの一括割当ルールが、どのオブジェクトに一致するかをレポートします。実行前の安全確認に使います。\nEN: Report which objects match the selected saved assignment rule. Use this as a safety check before applying it.')
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        scene = context.scene
        try:
            entry = resolve_assign_rule(scene)
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        preview = rules.preview_assignment_rule(context, entry)
        lines = [tx(scene, f"Rule: {entry.get('name', '-')}", _lt(f"ルール: {entry.get('name', '-')}")), tx(scene, f"Target material: {preview['target_material_name']}", _lt(f"対象材質: {preview['target_material_name']}")), tx(scene, f"Target exists: {preview['target_material_exists']}", _lt(f"対象材質が存在: {preview['target_material_exists']}")), tx(scene, f"Scope object count: {preview['scope_object_count']}", _lt(f"対象範囲オブジェクト数: {preview['scope_object_count']}")), tx(scene, f"Matched objects: {len(preview['matched_names'])}", _lt(f"一致オブジェクト数: {len(preview['matched_names'])}"))]
        if preview['matched_names']:
            lines.append(tx(scene, 'Matches:', _lt('一致一覧:')))
            lines.extend((f'- {name}' for name in preview['matched_names'][:16]))
        core.report_to_scene(scene, '\n'.join(lines))
        self.report({'INFO'}, _lt(f"Matches={len(preview['matched_names'])}"))
        return {'FINISHED'}

class SSS_OT_apply_rule(Operator):
    bl_idname = 'sss.apply_rule'
    bl_label = _lt('Apply Rule', 'ルール適用')
    bl_description = _lt('JP: 選択中の保存済み一括割当ルールを実行し、一致したオブジェクトへ対象材質を割り当てます。\nEN: Run the selected saved batch-assignment rule and assign its target material to matching objects.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        try:
            entry = resolve_assign_rule(scene)
            result = rules.apply_assignment_rule(context, entry)
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        message = tx(scene, f"Applied rule {entry.get('name', '-')} | Assigned={result['assigned']} Failed={result['failed']} Matched={len(result['matched_names'])}", _lt(f"ルール適用 {entry.get('name', '-')} | 割当={result['assigned']} 失敗={result['failed']} 一致={len(result['matched_names'])}"))
        details = message + ('\n' + '\n'.join(result['matched_names'][:16]) if result['matched_names'] else '')
        core.report_to_scene(scene, details)
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_delete_rule(Operator):
    bl_idname = 'sss.delete_rule'
    bl_label = _lt('Delete Rule', 'ルール削除')
    bl_description = _lt('JP: 選択中の保存済み割当ルールをローカルライブラリから削除します。\nEN: Remove the selected saved assignment rule from the local library.')
    bl_options = set()

    def execute(self, context):
        scene = context.scene
        try:
            entry = resolve_assign_rule(scene)
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        if not rules.delete_assignment_rule(entry.get('name', '')):
            self.report({'ERROR'}, _lt('JP: 割当ルールを削除できませんでした。 / EN: Failed to delete the assignment rule.'))
            return {'CANCELLED'}
        try:
            properties.normalize_selected_assign_rule(scene, context)
        except Exception:
            pass
        message = tx(scene, f"Deleted assignment rule: {entry.get('name', '-')}", _lt(f"割当ルールを削除しました: {entry.get('name', '-')}"))
        core.report_to_scene(scene, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_export_rule_library(Operator):
    bl_idname = 'sss.export_rule_library'
    bl_label = _lt('Export Rule Library', 'ルールライブラリ書出し')
    bl_description = _lt('JP: 保存済み割当ルールライブラリを JSON として書き出します。共有やバックアップに使えます。\nEN: Export the saved assignment-rule library as JSON for sharing or backup.')
    bl_options = set()
    _sms_no_undo = True
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = str(core.addon_storage_dir() / 'smart_shader_suite_assignment_rules.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        export_path = ensure_json_export_path(self.filepath, 'smart_shader_suite_assignment_rules.json')
        count = rules.export_assignment_rule_library(export_path)
        message = tx(context.scene, f'Exported assignment rules: {count}', _lt(f'割当ルールを書き出しました: {count}'))
        core.report_to_scene(context.scene, join_notes(message, [str(export_path)]))
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_import_rule_library(Operator):
    bl_idname = 'sss.import_rule_library'
    bl_label = _lt('Import Rule Library', 'ルールライブラリ読込')
    bl_description = _lt('JP: JSON から割当ルールライブラリを読み込みます。追加更新は追加更新、全置換は全置換です。\nEN: Import an assignment-rule library from JSON. Merge updates by name, Replace swaps the whole library.')
    bl_options = set()
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = str(core.addon_storage_dir() / 'smart_shader_suite_assignment_rules.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        path = ensure_json_import_path(self.filepath)
        if not path.exists() or not path.is_file():
            self.report({'ERROR'}, _lt('JP: ファイルが見つかりません。 / EN: File not found.'))
            return {'CANCELLED'}
        result = rules.import_assignment_rule_library(path, mode=getattr(context.scene, 'sss_rule_library_mode', 'MERGE'))
        try:
            properties.normalize_selected_assign_rule(context.scene, context)
        except Exception:
            pass
        message = tx(context.scene, f"Imported={result['imported']} Replaced={result['replaced']} Invalid={result['skipped_invalid']} Total={result['total']}", _lt(f"追加={result['imported']} 置換={result['replaced']} 不正={result['skipped_invalid']} 合計={result['total']}"))
        core.report_to_scene(context.scene, join_notes(message, [str(path), f"mode={result['mode']}"]))
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_repair_rule_library(Operator):
    bl_idname = 'sss.repair_rule_library'
    bl_label = _lt('Repair Rule Library', 'ルールライブラリ修復')
    bl_description = _lt('JP: 壊れた、重複した、名前や対象材質が欠けた割当ルールを整理し、安全な形に再保存します。\nEN: Repair broken, duplicate, or incomplete assignment rules and resave the library in a safe normalized form.')
    bl_options = set()

    def execute(self, context):
        result = rules.repair_assignment_rule_library()
        try:
            properties.normalize_selected_assign_rule(context.scene, context)
        except Exception:
            pass
        message = tx(context.scene, f"Before={result['before']} After={result['after']} Duplicates removed={result['removed_duplicates']} Invalid removed={result['removed_invalid']}", _lt(f"修復前={result['before']} 修復後={result['after']} 重複除去={result['removed_duplicates']} 不正除去={result['removed_invalid']}"))
        core.report_to_scene(context.scene, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_pick_active_material(Operator):
    bl_idname = 'sss.pick_active_material'
    bl_label = _lt('Pick Active Material', 'アクティブマテリアル取得')
    bl_description = _lt('JP: 現在のアクティブマテリアル名をマネージャー欄へ取り込みます。\nEN: Copy the active material name into the manager field.')
    bl_options = set()

    def execute(self, context):
        material = core.active_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: アクティブマテリアルがありません。 / EN: No active material.'))
            return {'CANCELLED'}
        context.scene.sss_target_material_name = material.name
        self.report({'INFO'}, material.name)
        return {'FINISHED'}

class SSS_OT_duplicate_target(Operator):
    bl_idname = 'sss.duplicate_target'
    bl_label = _lt('Duplicate Target', 'ターゲット複製')
    bl_description = _lt('JP: 選択中の管理マテリアルを複製します。元の材質は保持されるので安全です。\nEN: Duplicate the selected manager material and keep the original intact.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = core.get_target_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象マテリアルが見つかりません。 / EN: Target material not found.'))
            return {'CANCELLED'}
        copy = material.copy()
        copy.name = f'{material.name}_Copy'
        context.scene.sss_target_material_name = copy.name
        core.set_active_material(context, copy)
        core.report_to_scene(context.scene, tx(context.scene, f'Duplicated {material.name}.', _lt(f'{material.name} を複製しました。')))
        self.report({'INFO'}, _lt(f'Duplicated {material.name}'))
        return {'FINISHED'}

class SSS_OT_localize_target(Operator):
    bl_idname = 'sss.localize_target'
    bl_label = _lt('Localize Target', 'ターゲットローカライズ')
    bl_description = _lt('JP: ターゲット材質を複製し、そのコピーだけを選択オブジェクトへ割り当てます。共有材質を壊さず個別調整したいときに便利です。\nEN: Duplicate the target material and assign the copy only to the selected objects. Useful when you want per-object edits without touching a shared shader.')
    bl_options = {'UNDO'}

    def execute(self, context):
        source = core.get_target_material(context) or core.active_material(context)
        if not source:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material.'))
            return {'CANCELLED'}
        new_name = (context.scene.sss_material_name or '').strip() or f'{source.name}_Local'
        material = source.copy()
        material.name = new_name
        if getattr(context.scene, 'sss_use_fake_user', False):
            material.use_fake_user = True
        assigned = core.assign_material_to_selected(context, material)
        context.scene.sss_target_material_name = material.name
        try:
            core.set_active_material(context, material)
        except Exception:
            pass
        core.report_to_scene(context.scene, tx(context.scene, f'Localized {source.name} -> {material.name} | Assigned objects: {assigned}', _lt(f'{source.name} を {material.name} としてローカライズ | 割当オブジェクト数: {assigned}')))
        self.report({'INFO'}, _lt(f'Localized {source.name} -> {material.name}'))
        return {'FINISHED'}

class SSS_OT_localize_per_object(Operator):
    bl_idname = 'sss.localize_per_object'
    bl_label = _lt('Localize Per Object', 'オブジェクト別ローカライズ')
    bl_description = _lt('JP: 選択オブジェクトごとにターゲット材質の複製を作り、それぞれへ割り当てます。共有材質を壊さずに、オブジェクト単位の差分ルックを作りたいときに便利です。\nEN: Create a localized copy of the target material for each selected object and assign it individually. Useful when you want per-object look variations without breaking a shared shader.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        source = core.get_target_material(context) or core.active_material(context)
        if not source:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material.'))
            return {'CANCELLED'}
        objects = list(getattr(context, 'selected_objects', []) or [])
        if not objects and getattr(context, 'object', None):
            objects = [context.object]
        if not objects:
            self.report({'ERROR'}, _lt('JP: 対象オブジェクトがありません。 / EN: No target objects.'))
            return {'CANCELLED'}
        assigned = 0
        created_names = []
        mode = core.assign_mode(context)
        for obj in objects:
            material = source.copy()
            material.name = f"{source.name}_{getattr(obj, 'name', 'Object')}"
            if getattr(scene, 'sss_use_fake_user', False):
                material.use_fake_user = True
            if core.set_material_on_object(obj, material, mode, context=context):
                assigned += 1
                created_names.append(material.name)
            else:
                core.safe_remove_id(bpy.data.materials, material)
        if not created_names:
            self.report({'ERROR'}, _lt('JP: 個別ローカライズに失敗しました。 / EN: Failed to localize materials per object.'))
            return {'CANCELLED'}
        scene.sss_target_material_name = created_names[0]
        core.report_to_scene(scene, tx(scene, f'Localized per object from {source.name} | Assigned objects: {assigned}', _lt(f'{source.name} をオブジェクト別にローカライズ | 割当オブジェクト数: {assigned}')))
        self.report({'INFO'}, _lt(f'Localized variants created: {assigned}'))
        return {'FINISHED'}

class SSS_OT_rename_target(Operator):
    bl_idname = 'sss.rename_target'
    bl_label = _lt('Rename Target', 'ターゲット名称変更')
    bl_description = _lt('JP: ターゲット材質の名前を入力欄の名前へ変更します。\nEN: Rename the target material using the Name field.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = core.get_target_material(context)
        new_name = context.scene.sss_material_name.strip()
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象マテリアルが見つかりません。 / EN: Target material not found.'))
            return {'CANCELLED'}
        if not new_name:
            self.report({'ERROR'}, _lt('JP: 新しい名前を入力してください。 / EN: Enter a new name first.'))
            return {'CANCELLED'}
        old_name = material.name
        material.name = new_name
        context.scene.sss_target_material_name = material.name
        core.report_to_scene(context.scene, tx(context.scene, f'Renamed {old_name} to {material.name}.', _lt(f'{old_name} を {material.name} に変更しました。')))
        self.report({'INFO'}, _lt(f'Renamed {old_name}'))
        return {'FINISHED'}

class SSS_OT_mark_target_asset(Operator):
    bl_idname = 'sss.mark_target_asset'
    bl_label = _lt('Mark Target Asset', 'ターゲットアセット化')
    bl_description = _lt('JP: 選択中の管理マテリアルをBlenderアセットとしてマークし、プレビュー生成を試みます。\nEN: Mark the selected manager material as a Blender asset and try to generate a preview.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = core.get_target_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象マテリアルが見つかりません。 / EN: Target material not found.'))
            return {'CANCELLED'}
        core.mark_material_as_asset(material)
        core.report_to_scene(context.scene, tx(context.scene, 'Marked as asset.', _lt('アセット化しました。')))
        self.report({'INFO'}, _lt(f'Marked asset: {material.name}'))
        return {'FINISHED'}

class SSS_OT_rebuild_target(Operator):
    bl_idname = 'sss.rebuild_target'
    bl_label = _lt('Rebuild Target', 'ターゲット再構築')
    bl_description = _lt('JP: ターゲットまたはアクティブ材質に保存されたスマートシェーダーメタデータから材質を再構築します。\nEN: Rebuild the target or active material using stored Smart Shader metadata.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = choose_target_or_active(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material.'))
            return {'CANCELLED'}
        builder_id = material.get('sss_builder', '')
        if builder_id not in builders.BUILDERS:
            self.report({'ERROR'}, _lt('JP: 再構築可能なスマートシェーダービルダー情報がありません。 / EN: No rebuildable Smart Shader builder metadata was found.'))
            return {'CANCELLED'}
        source_material = material
        material = core.duplicate_for_non_destructive(context, material)
        duplicated = material is not source_material
        params = core.get_material_params(material)
        try:
            builders.build_preset(material, builder_id, custom_params=params)
        except Exception as exc:
            if duplicated:
                core.safe_remove_id(bpy.data.materials, material)
                try:
                    core.set_active_material(context, source_material)
                except Exception:
                    pass
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        notes = postprocess_material_graph(material, context)
        context.scene.sss_target_material_name = material.name
        core.report_to_scene(context.scene, join_notes(audit.format_audit_report(material, context), notes))
        self.report({'INFO'}, _lt(f'Rebuilt {material.name}'))
        return {'FINISHED'}

class SSS_OT_rebuild_managed_materials(Operator):
    bl_idname = 'sss.rebuild_managed_materials'
    bl_label = _lt('Rebuild Managed Materials', '管理マテリアル一括再構築')
    bl_description = _lt('JP: シーンで使われている管理対象マテリアルを一括再構築します。保存済みパラメータとビルダーを使うため、壊れたノードグラフの再生成や一括更新に便利です。\nEN: Rebuild all managed scene materials in one pass using their stored builders and parameters. Useful for regenerating broken graphs and refreshing a whole scene.')
    bl_options = {'UNDO'}

    def execute(self, context):
        materials = core.scene_materials(context)
        if not materials:
            self.report({'ERROR'}, _lt('JP: シーンで使用中のマテリアルがありません。 / EN: No scene-used materials were found.'))
            return {'CANCELLED'}
        rebuilt = 0
        skipped = 0
        failed = []
        for material in materials:
            builder_id = str(material.get('sss_builder', '') or '')
            if builder_id not in builders.BUILDERS:
                skipped += 1
                continue
            params = core.get_material_params(material)
            try:
                builders.build_preset(material, builder_id, custom_params=params)
                postprocess_material_graph(material, context)
                rebuilt += 1
            except Exception as exc:
                failed.append(f'{material.name}: {_exc_text(exc)}')
        message = [tx(context.scene, f'Rebuilt managed materials: {rebuilt}', _lt(f'再構築した管理材質: {rebuilt}')), tx(context.scene, f'Skipped materials: {skipped}', _lt(f'スキップした材質: {skipped}')), tx(context.scene, f'Failed materials: {len(failed)}', _lt(f'失敗した材質: {len(failed)}'))]
        if failed:
            message.extend(failed[:10])
        core.report_to_scene(context.scene, '\n'.join(message))
        self.report({'INFO'}, _lt(f'Rebuilt={rebuilt} Failed={len(failed)}'))
        return {'FINISHED'}

class SSS_OT_audit_active_material(Operator):
    bl_idname = 'sss.audit_active_material'
    bl_label = _lt('Audit Active Material', 'アクティブ監査')
    bl_description = _lt('JP: アクティブマテリアルのノード構成、画像参照、出力状態を点検します。\nEN: Inspect the active material graph, image references, and output state.')
    bl_options = set()

    def execute(self, context):
        text = audit.format_audit_report(core.active_material(context), context)
        core.report_to_scene(context.scene, text)
        self.report({'INFO'}, _lt('Audit complete.'))
        return {'FINISHED'}

class SSS_OT_audit_library(Operator):
    bl_idname = 'sss.audit_library'
    bl_label = _lt('Audit Library', 'ライブラリ監査')
    bl_description = _lt('JP: シーン内の全マテリアルを簡易集計し、未使用材質やリンク切れ画像数を確認します。\nEN: Summarize all scene materials and report orphan counts and missing image references.')
    bl_options = set()

    def execute(self, context):
        core.report_to_scene(context.scene, audit.audit_library_text(context))
        self.report({'INFO'}, _lt('Library audit complete.'))
        return {'FINISHED'}

class SSS_OT_normalize_output(Operator):
    bl_idname = 'sss.normalize_output'
    bl_label = _lt('Normalize Output', '出力正規化')
    bl_description = _lt('JP: ノード未使用の材質をノード化し、必要最低限のPrincipled + マテリアル出力構成を保証します。\nEN: Enable nodes and guarantee a minimal Principled + Material Output setup.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = core.active_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: アクティブマテリアルがありません。 / EN: No active material.'))
            return {'CANCELLED'}
        if context.scene.sss_non_destructive:
            material = core.duplicate_for_non_destructive(context, material)
        material.use_nodes = True
        nt = material.node_tree
        out = core.ensure_output_node(nt, engine=core.render_engine(context))
        if out is not None:
            out.location = (240, 40)
        surface = core.socket_by_name(out.inputs, 'Surface') if out is not None else None
        if surface is None or not surface.is_linked:
            bsdf = nt.nodes.new('ShaderNodeBsdfPrincipled')
            bsdf.location = (-80, 40)
            nt.links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])
        notes = postprocess_material_graph(material, context)
        params = core.approx_params_from_material(material)
        core.set_managed_metadata_only(material, params=params, tags=['Normalized', 'Managed'])
        core.report_to_scene(context.scene, join_notes(audit.format_audit_report(material, context), notes))
        self.report({'INFO'}, _lt(f'Normalized {material.name}'))
        return {'FINISHED'}

class SSS_OT_export_bundle(Operator):
    bl_idname = 'sss.export_bundle'
    bl_label = _lt('Export Bundle', 'バンドル書出し')
    bl_description = _lt('JP: 現在の材質と到達可能なテクスチャを 1 つの ZIP バンドルにまとめます。別PCへの受け渡し、アーカイブ、再リンクに強い再利用向けです。\nEN: Package the current material and any reachable textures into one zip bundle for handoff, archive, and reuse on another machine.')
    bl_options = set()
    _sms_no_undo = True
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.zip'
    filter_glob: StringProperty(default='*.zip', options={'HIDDEN'})

    def invoke(self, context, event):
        material = choose_current_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material.'))
            return {'CANCELLED'}
        fallback = core.addon_storage_dir() / f'{bundle.clean_bundle_basename(material.name)}_bundle.zip'
        self.filepath = str(fallback)
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        material = choose_current_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material.'))
            return {'CANCELLED'}
        raw = str(self.filepath or '').strip()
        export_path = Path(raw) if raw else core.addon_storage_dir() / f'{bundle.clean_bundle_basename(material.name)}_bundle.zip'
        if export_path.suffix.lower() != '.zip':
            export_path = export_path.with_suffix('.zip')
        try:
            result = bundle.export_material_bundle(material, context=context, export_path=export_path)
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        message = '\n'.join([tx(context.scene, f"Exported material bundle: {result['path']}", _lt(f"材質バンドルを書き出しました: {result['path']}")), tx(context.scene, f"Copied textures: {result['copied_texture_count']}", _lt(f"同梱したテクスチャ数: {result['copied_texture_count']}")), tx(context.scene, f"Skipped textures: {result['skipped_texture_count']}", _lt(f"同梱できなかったテクスチャ数: {result['skipped_texture_count']}"))])
        core.report_to_scene(context.scene, message)
        self.report({'INFO'}, str(result['path']))
        return {'FINISHED'}

class SSS_OT_import_bundle(Operator):
    bl_idname = 'sss.import_bundle'
    bl_label = _lt('Import Bundle', 'バンドル読込')
    bl_description = _lt('JP: ZIP バンドルを展開し、内包マニフェストと同梱テクスチャから材質を再構築します。\nEN: Unpack a zip bundle and rebuild a material from its embedded manifest and bundled textures.')
    bl_options = {'UNDO'}
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.zip'
    filter_glob: StringProperty(default='*.zip', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = str(core.addon_storage_dir() / 'material_bundle.zip')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        path = Path(str(self.filepath or '').strip())
        if not path.exists() or not path.is_file():
            self.report({'ERROR'}, _lt('JP: バンドルファイルが見つかりません。 / EN: Bundle file not found.'))
            return {'CANCELLED'}
        try:
            imported_bundle = bundle.import_material_bundle(path)
            imported = import_material_manifest_payload(context, imported_bundle['manifest_payload'], path_hint=Path(imported_bundle['manifest_path']))
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        material = imported['material']
        context.scene.sss_target_material_name = material.name
        notes = list(imported.get('notes', []))
        notes.append(tx(context.scene, f"Bundle extracted to: {imported_bundle['extract_dir']}", _lt(f"バンドル展開先: {imported_bundle['extract_dir']}")))
        notes.append(tx(context.scene, f"Build mode: {imported.get('build_mode', 'unknown')}", _lt(f"構築方式: {imported.get('build_mode', 'unknown')}")))
        message = tx(context.scene, f'Imported material bundle: {path.name}', _lt(f'材質バンドルを読み込みました: {path.name}'))
        core.report_to_scene(context.scene, join_notes(message, notes))
        self.report({'INFO'}, _lt(f'Imported {path.name}'))
        return {'FINISHED'}

class SSS_OT_export_manifest(Operator):
    bl_idname = 'sss.export_manifest'
    bl_label = _lt('Export Material Manifest', '材質マニフェスト書出し')
    bl_description = _lt('JP: 現在の材質をJSONマニフェストとして書き出します。共有、バックアップ、解析、移植の土台に使えます。\nEN: Export the current material as a JSON manifest for backup, analysis, sharing, and portability.')
    bl_options = set()
    _sms_no_undo = True
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        material = choose_current_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material.'))
            return {'CANCELLED'}
        self.filepath = str(core.addon_storage_dir() / f'{material.name}_manifest.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        material = choose_current_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material.'))
            return {'CANCELLED'}
        payload = core.material_manifest(material, context)
        export_path = ensure_json_export_path(self.filepath, f'{material.name}_manifest.json')
        try:
            export_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        core.report_to_scene(context.scene, tx(context.scene, f'Exported manifest to {export_path}', _lt(f'マニフェストを書き出しました: {export_path}')))
        self.report({'INFO'}, str(export_path))
        return {'FINISHED'}

class SSS_OT_save_variant(Operator):
    bl_idname = 'sss.save_variant'
    bl_label = _lt('Save Variant', 'バリアント保存')
    bl_description = _lt('JP: シーン全体の材質スロット割り当てと HDRI 状態を保存し、あとから再適用できるルックバリアントとして残します。\nEN: Save scene-wide material-slot assignments and HDRI state as a reusable lookdev variant.')
    bl_options = set()

    def execute(self, context):
        scene = context.scene
        name = (getattr(scene, 'sss_scene_variant_name', '') or '').strip() or f"{getattr(scene, 'name', 'Scene')}_Variant"
        try:
            payload = core.scene_variant_payload(context, name)
            core.save_scene_variant_payload(payload)
            scene.sss_scene_variant_name = name
            scene.sss_scene_variant_pick = name
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        core.report_to_scene(scene, tx(scene, f'Saved scene variant: {name}', _lt(f'シーンバリアントを保存しました: {name}')))
        self.report({'INFO'}, _lt(f'Saved scene variant: {name}'))
        return {'FINISHED'}

class SSS_OT_apply_variant(Operator):
    bl_idname = 'sss.apply_variant'
    bl_label = _lt('Apply Variant', 'バリアント適用')
    bl_description = _lt('JP: 保存済みシーンバリアントから、材質スロット割り当てと HDRI 状態を可能な範囲で復元します。\nEN: Restore material-slot assignments and HDRI state from a saved scene variant.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        name = (getattr(scene, 'sss_scene_variant_pick', '') or '').strip()
        if not name or name == 'NO_SCENE_VARIANTS':
            self.report({'ERROR'}, _lt('JP: 適用するシーンバリアントがありません。 / EN: No scene variant selected.'))
            return {'CANCELLED'}
        payload = core.find_scene_variant(name)
        if not payload:
            self.report({'ERROR'}, _lt('JP: シーンバリアントが見つかりません。 / EN: Scene variant not found.'))
            return {'CANCELLED'}
        material_lookup = {}
        for item in payload.get('materials', []) if isinstance(payload.get('materials'), list) else []:
            if not isinstance(item, dict):
                continue
            mat = bpy.data.materials.get(str(item.get('material_name', '') or ''))
            if mat is not None:
                material_lookup[mat.name] = mat
        restore = restore_scene_material_assignments(context, payload.get('objects', []), material_lookup)
        world_restore = restore_scene_world_from_manifest(context, payload)
        report = tx(scene, f"Applied scene variant: {name} | Slots restored: {restore['slots_restored']} | HDRI restored: {world_restore['restored']}", _lt(f"シーンバリアントを適用しました: {name} | 復元スロット数: {restore['slots_restored']} | HDRI復元: {world_restore['restored']}"))
        core.report_to_scene(scene, report)
        self.report({'INFO'}, _lt(f'Applied scene variant: {name}'))
        return {'FINISHED'}

class SSS_OT_delete_variant(Operator):
    bl_idname = 'sss.delete_variant'
    bl_label = _lt('Delete Variant', 'バリアント削除')
    bl_description = _lt('JP: 選択した保存済みシーンバリアントをローカルライブラリから削除します。\nEN: Remove the selected saved scene variant from the local library.')
    bl_options = set()

    def execute(self, context):
        scene = context.scene
        name = (getattr(scene, 'sss_scene_variant_pick', '') or '').strip()
        if not name or name == 'NO_SCENE_VARIANTS':
            self.report({'ERROR'}, _lt('JP: 削除するシーンバリアントがありません。 / EN: No scene variant selected.'))
            return {'CANCELLED'}
        if not core.delete_scene_variant(name):
            self.report({'ERROR'}, _lt('JP: シーンバリアントが見つかりません。 / EN: Scene variant not found.'))
            return {'CANCELLED'}
        try:
            properties.normalize_selected_scene_variant(scene, context)
        except Exception:
            scene.sss_scene_variant_pick = 'NO_SCENE_VARIANTS'
        core.report_to_scene(scene, tx(scene, f'Deleted scene variant: {name}', _lt(f'シーンバリアントを削除しました: {name}')))
        self.report({'INFO'}, _lt(f'Deleted scene variant: {name}'))
        return {'FINISHED'}

class SSS_OT_export_variant_library(Operator):
    bl_idname = 'sss.export_variant_library'
    bl_label = _lt('Export Variant Library', 'バリアントライブラリ書出し')
    bl_description = _lt('JP: 保存済みシーンバリアントのローカルライブラリを JSON として書き出します。共有やバックアップに使えます。\nEN: Export the saved local scene-variant library as JSON for sharing and backup.')
    bl_options = set()
    _sms_no_undo = True
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = str(core.addon_storage_dir() / 'smart_shader_suite_scene_variants.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        export_path = ensure_json_export_path(self.filepath, 'smart_shader_suite_scene_variants.json')
        count = core.export_scene_variant_library(export_path)
        try:
            properties.normalize_selected_scene_variant(context.scene, context)
        except Exception:
            pass
        message = tx(context.scene, f'Exported scene variants: {count}', _lt(f'シーンバリアントを書き出しました: {count} 件'))
        core.report_to_scene(context.scene, join_notes(message, [str(export_path)]))
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_import_variant_library(Operator):
    bl_idname = 'sss.import_variant_library'
    bl_label = _lt('Import Variant Library', 'バリアントライブラリ読込')
    bl_description = _lt('JP: JSON からシーンバリアントライブラリを読み込みます。追加更新は追加更新、全置換は全置換です。\nEN: Import a scene-variant library from JSON. Merge updates by name, Replace swaps the whole library.')
    bl_options = set()
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = str(core.addon_storage_dir() / 'smart_shader_suite_scene_variants.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        path = ensure_json_import_path(self.filepath)
        if not path.exists() or not path.is_file():
            self.report({'ERROR'}, _lt('JP: ファイルが見つかりません。 / EN: File not found.'))
            return {'CANCELLED'}
        result = core.import_scene_variant_library(path, mode=getattr(context.scene, 'sss_scene_variant_library_mode', 'MERGE'))
        try:
            properties.normalize_selected_scene_variant(context.scene, context)
        except Exception:
            pass
        message = tx(context.scene, f"Imported={result['imported']} Replaced={result['replaced']} Invalid={result['skipped_invalid']} Total={result['total']}", _lt(f"追加={result['imported']} 置換={result['replaced']} 不正={result['skipped_invalid']} 合計={result['total']}"))
        core.report_to_scene(context.scene, join_notes(message, [str(path), f"mode={result['mode']}"]))
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_repair_variant_library(Operator):
    bl_idname = 'sss.repair_variant_library'
    bl_label = _lt('Repair Variant Library', 'バリアントライブラリ修復')
    bl_description = _lt('JP: 壊れた、重複した、名前のないシーンバリアントを整理し、安全な形へ再保存します。\nEN: Repair broken, duplicate, or unnamed scene variants and resave the library in a safe normalized form.')
    bl_options = set()

    def execute(self, context):
        result = core.repair_scene_variant_library()
        try:
            properties.normalize_selected_scene_variant(context.scene, context)
        except Exception:
            pass
        message = tx(context.scene, f"Scene variant library repaired: before={result['before']} after={result['after']} dropped={result['dropped']} duplicates={result['duplicates']}", _lt(f"シーンバリアントライブラリを修復しました: 修復前={result['before']} 修復後={result['after']} 破棄={result['dropped']} 重複整理={result['duplicates']}"))
        core.report_to_scene(context.scene, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_export_scene_manifest(Operator):
    bl_idname = 'sss.export_scene_manifest'
    bl_label = _lt('Export Scene Manifest', 'シーンマニフェスト書出し')
    bl_description = _lt('JP: シーン内の材質一覧とオブジェクト割り当てをJSONで書き出します。USD/LOPs 風の棚卸しや共有に使えます。\nEN: Export all scene materials and object assignments as JSON for inventory, sharing, and USD/LOPs-style inspection.')
    bl_options = set()
    _sms_no_undo = True
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        scene_name = getattr(context.scene, 'name', 'Scene') or 'Scene'
        self.filepath = str(core.addon_storage_dir() / f'{scene_name}_scene_manifest.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        payload = core.scene_manifest(context)
        export_path = ensure_json_export_path(self.filepath, f"{getattr(context.scene, 'name', 'Scene') or 'Scene'}_scene_manifest.json")
        try:
            export_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        core.report_to_scene(context.scene, tx(context.scene, f'Exported scene manifest to {export_path}', _lt(f'シーンマニフェストを書き出しました: {export_path}')))
        self.report({'INFO'}, str(export_path))
        return {'FINISHED'}

class SSS_OT_import_manifest(Operator):
    bl_idname = 'sss.import_manifest'
    bl_label = _lt('Import Material Manifest', '材質マニフェスト読込')
    bl_description = _lt('JP: JSONマニフェストから材質を作成または取り込みます。対応ビルダーがあれば再構築し、なければ参照テクスチャやポータブル近似で復元します。\nEN: Import a JSON manifest. Rebuild natively when a compatible builder exists, otherwise restore from referenced textures or a portable approximation.')
    bl_options = {'UNDO'}
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = str(core.addon_storage_dir() / 'material_manifest.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        path = ensure_json_import_path(self.filepath)
        if not path.exists() or not path.is_file():
            self.report({'ERROR'}, _lt('JP: ファイルが見つかりません。 / EN: File not found.'))
            return {'CANCELLED'}
        try:
            payload = json.loads(path.read_text(encoding='utf-8'))
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        if not isinstance(payload, dict):
            self.report({'ERROR'}, _lt('JP: マニフェストの最上位は JSON オブジェクト である必要があります。 / EN: Manifest root must be a JSON object.'))
            return {'CANCELLED'}
        if payload.get('scope') == 'scene':
            materials_payload = payload.get('materials', [])
            if not isinstance(materials_payload, list) or not materials_payload:
                self.report({'ERROR'}, _lt('JP: シーンマニフェストに材質情報がありません。 / EN: Scene manifest does not contain any materials.'))
                return {'CANCELLED'}
            desired = (context.scene.sss_material_name or '').strip().lower()
            selected_payload = None
            if desired:
                for item in materials_payload:
                    if not isinstance(item, dict):
                        continue
                    if str(item.get('material_name', '') or '').strip().lower() == desired:
                        selected_payload = item
                        break
            if selected_payload is None and len(materials_payload) == 1:
                selected_payload = materials_payload[0]
            if selected_payload is None:
                self.report({'ERROR'}, _lt('JP: シーンマニフェストには複数材質があります。単体読込なら名前欄に材質名を入れるか、『シーンマニフェスト読込』を使ってください。 / EN: Scene manifest contains multiple materials. Enter a material name for single import or use Import Scene Manifest for batch restore.'))
                return {'CANCELLED'}
            payload = selected_payload
        try:
            imported = import_material_manifest_payload(context, payload, path_hint=path)
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        material = imported['material']
        context.scene.sss_target_material_name = material.name
        import_message = tx(context.scene, f"Imported manifest: {path.name} (mode={imported.get('build_mode', 'unknown')}, rebuilt={imported['rebuilt']})", _lt(f"マニフェストを読み込みました: {path.name} (方式={imported.get('build_mode', 'unknown')}, 再構築={imported['rebuilt']})"))
        if context.scene.sss_auto_audit_after_build:
            core.report_to_scene(context.scene, join_notes(audit.format_audit_report(material, context), imported.get('notes', [])))
        else:
            core.report_to_scene(context.scene, join_notes(import_message, imported.get('notes', [])))
        self.report({'INFO'}, _lt(f'Imported {path.name}'))
        return {'FINISHED'}

class SSS_OT_import_scene_manifest(Operator):
    bl_idname = 'sss.import_scene_manifest'
    bl_label = _lt('Import Scene Manifest', 'シーンマニフェスト読込')
    bl_description = _lt('JP: シーンマニフェストに含まれる複数マテリアルをまとめて復元し、可能な範囲でオブジェクト割り当てと HDRI ワールドも戻します。大きなライブラリや別シーンからの再構築向けです。\nEN: Restore multiple materials from a scene manifest, then best-effort restore object assignments and the HDRI world. Useful for rebuilding larger libraries or transferring lookdev between scenes.')
    bl_options = {'UNDO'}
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = str(core.addon_storage_dir() / 'scene_manifest.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        path = ensure_json_import_path(self.filepath)
        if not path.exists() or not path.is_file():
            self.report({'ERROR'}, _lt('JP: ファイルが見つかりません。 / EN: File not found.'))
            return {'CANCELLED'}
        try:
            payload = json.loads(path.read_text(encoding='utf-8'))
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        if not isinstance(payload, dict) or payload.get('scope') != 'scene':
            self.report({'ERROR'}, _lt('JP: これはシーンマニフェストではありません。 / EN: This is not a scene manifest.'))
            return {'CANCELLED'}
        materials_payload = payload.get('materials', [])
        if not isinstance(materials_payload, list) or not materials_payload:
            self.report({'ERROR'}, _lt('JP: 読み込める材質がありません。 / EN: No importable materials were found.'))
            return {'CANCELLED'}
        imported_materials = []
        material_lookup = {}
        rebuilt_count = 0
        manifest_texture_count = 0
        fallback_count = 0
        failures = []
        for item in materials_payload:
            if not isinstance(item, dict):
                continue
            source_name = str(item.get('material_name', '') or '').strip()
            try:
                result = import_material_manifest_payload(context, item, path_hint=path, material_name_override=source_name, assign_selected=False, activate_when_unassigned=False)
                material = result['material']
                imported_materials.append(material)
                if source_name:
                    material_lookup[source_name] = material
                if result.get('rebuilt'):
                    rebuilt_count += 1
                elif result.get('build_mode') == 'manifest_textures':
                    manifest_texture_count += 1
                else:
                    fallback_count += 1
            except Exception as exc:
                failures.append(f"{source_name or '<unnamed>'}: {_exc_text(exc)}")
        if not imported_materials:
            self.report({'ERROR'}, _lt('JP: 材質を復元できませんでした。 / EN: No materials could be restored.'))
            return {'CANCELLED'}
        restore = restore_scene_material_assignments(context, payload.get('objects', []), material_lookup)
        world_restore = restore_scene_world_from_manifest(context, payload)
        first = imported_materials[0]
        try:
            core.set_active_material(context, first)
        except Exception:
            pass
        context.scene.sss_target_material_name = first.name
        lines = [tx(context.scene, f'Imported materials: {len(imported_materials)}', _lt(f'復元したマテリアル数: {len(imported_materials)}')), tx(context.scene, f'Native rebuilds: {rebuilt_count}', _lt(f'ネイティブ再構築数: {rebuilt_count}')), tx(context.scene, f'Manifest texture fallbacks: {manifest_texture_count}', _lt(f'マニフェストテクスチャ復元数: {manifest_texture_count}')), tx(context.scene, f'Portable fallbacks: {fallback_count}', _lt(f'ポータブルフォールバック数: {fallback_count}')), tx(context.scene, f"Objects matched: {restore['objects_found']}", _lt(f"一致オブジェクト数: {restore['objects_found']}")), tx(context.scene, f"Objects missing: {restore['objects_missing']}", _lt(f"見つからなかったオブジェクト数: {restore['objects_missing']}")), tx(context.scene, f"Slots restored: {restore['slots_restored']}", _lt(f"復元したスロット数: {restore['slots_restored']}")), tx(context.scene, f"Missing material references: {restore['materials_missing']}", _lt(f"見つからなかった材質参照: {restore['materials_missing']}")), tx(context.scene, f"HDRI restored: {world_restore['restored']}", _lt(f"HDRI復元: {world_restore['restored']}"))]
        lines.extend((f'• {material.name}' for material in imported_materials[:8]))
        lines.extend((restore.get('notes') or [])[:6])
        lines.extend((world_restore.get('notes') or [])[:6])
        lines.extend(failures[:6])
        core.report_to_scene(context.scene, '\n'.join(lines))
        self.report({'INFO'}, _lt(f'Imported scene manifest: {len(imported_materials)} materials'))
        return {'FINISHED'}

class SSS_OT_scan_library(Operator):
    bl_idname = 'sss.scan_library'
    bl_label = _lt('Scan Library', 'ライブラリ診断')
    bl_description = _lt('JP: 指定ルート配下の整合するテクスチャセット群を一覧化します。どのグループが一括構築対象になるかを事前確認したいときに使います。\nEN: List coherent texture-set groups under the chosen root. Use this before batch-building a larger texture library.')
    bl_options = set()

    def execute(self, context):
        root_raw = context.scene.sss_texture_search_root.strip()
        if not root_raw:
            self.report({'ERROR'}, _lt('JP: テクスチャルートを指定してください。 / EN: Choose a texture root first.'))
            return {'CANCELLED'}
        root = Path(bpy.path.abspath(root_raw))
        scan = textures.scan_texture_library(root, filter_text=context.scene.sss_texture_set_filter.strip())
        report = format_texture_library_scan_report(context.scene, scan)
        core.report_to_scene(context.scene, report)
        if not scan.get('group_total'):
            self.report({'WARNING'}, _lt('No coherent texture-library groups were found.'))
            return {'CANCELLED'}
        self.report({'INFO'}, _lt(f"Groups={scan.get('group_total', 0)}"))
        return {'FINISHED'}

class SSS_OT_build_library(Operator):
    bl_idname = 'sss.build_library'
    bl_label = _lt('Build Library', 'ライブラリ構築')
    bl_description = _lt('JP: 指定ルート配下の整合する複数テクスチャセットから、まとめて複数マテリアルを生成します。大規模ライブラリでも上限件数を守りながら安全に取り込む用途です。\nEN: Build multiple materials from coherent texture sets under the chosen root. Intended for safer bulk imports with a configurable batch limit.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        root_raw = scene.sss_texture_search_root.strip()
        if not root_raw:
            self.report({'ERROR'}, _lt('JP: テクスチャルートを指定してください。 / EN: Choose a texture root first.'))
            return {'CANCELLED'}
        root = Path(bpy.path.abspath(root_raw))
        if not root.exists():
            self.report({'ERROR'}, _lt('JP: テクスチャルートが存在しません。 / EN: Texture root does not exist.'))
            return {'CANCELLED'}
        scan = textures.scan_texture_library(root, filter_text=scene.sss_texture_set_filter.strip())
        groups = list(scan.get('groups') or [])
        if not groups:
            report = format_texture_library_scan_report(scene, scan)
            core.report_to_scene(scene, report)
            self.report({'ERROR'}, _lt('JP: 構築できるグループが見つかりません。 / EN: No buildable texture groups were found.'))
            return {'CANCELLED'}
        limit = max(1, int(getattr(scene, 'sss_texture_batch_limit', 12) or 12))
        selected_groups = groups[:limit]
        created_materials = []
        failure_notes = []
        total_images = 0
        for group in selected_groups:
            base_name = str(group.get('display_name') or group.get('group_key') or 'TextureSet').strip() or 'TextureSet'
            if scene.sss_material_name.strip():
                base_name = f'{scene.sss_material_name.strip()}_{base_name}'
            material = bpy.data.materials.new(name=base_name)
            material.use_fake_user = scene.sss_use_fake_user
            result = textures.build_material_from_texture_files(material, list(group.get('files') or []), force=True, group_name=str(group.get('group_key', '') or ''))
            if result.get('files', 0) <= 0 or result.get('loaded_images', 0) <= 0:
                core.safe_remove_id(bpy.data.materials, material)
                failure_notes.append(tx(scene, f'{base_name}: no usable images', f'{base_name}: 使える画像がありません'))
                continue
            total_images += int(result.get('loaded_images', 0) or 0)
            notes = postprocess_material_graph(material, context)
            params = core.approx_params_from_material(material)
            core.set_managed_metadata_only(material, note_en='Built from a batch texture-library import.', note_ja=_lt('一括テクスチャライブラリ取り込みから構築したマテリアルです。'), params=params, tags=['Texture Library', 'Imported', 'Managed', str(group.get('group_key', '') or 'Texture Set')])
            if scene.sss_mark_asset:
                core.mark_material_as_asset(material)
            created_materials.append(material)
            failure_notes.extend((result.get('notes') or [])[:2])
            failure_notes.extend(notes[:2])
        if not created_materials:
            self.report({'ERROR'}, _lt('JP: マテリアルを作成できませんでした。 / EN: No materials were created.'))
            return {'CANCELLED'}
        first = created_materials[0]
        try:
            core.set_active_material(context, first)
        except Exception:
            pass
        scene.sss_target_material_name = first.name
        lines = [tx(scene, f'Created materials: {len(created_materials)}', _lt(f'作成したマテリアル数: {len(created_materials)}')), tx(scene, f'Batch limit: {limit}', _lt(f'一括上限: {limit}')), tx(scene, f"Scanned groups: {scan.get('group_total', 0)}", _lt(f"診断グループ数: {scan.get('group_total', 0)}")), tx(scene, f'Loaded images: {total_images}', _lt(f'読み込んだ画像数: {total_images}')), tx(scene, 'Batch build does not auto-assign materials to selected objects for safety.', _lt('一括構築は安全のため選択オブジェクトへ自動割当しません。'))]
        lines.extend((f'• {material.name}' for material in created_materials[:12]))
        lines.extend(failure_notes[:8])
        core.report_to_scene(scene, '\n'.join(lines))
        self.report({'INFO'}, _lt(f'Built {len(created_materials)} materials'))
        return {'FINISHED'}

class SSS_OT_write_coverage_report(Operator):
    bl_idname = 'sss.write_coverage_report'
    bl_label = _lt('Write Coverage Report', 'カバレッジ出力')
    bl_description = _lt('JP: 添付ドキュメント由来の機能統合マッピングを Blender のテキストデータとして出力します。\nEN: Write the document-to-feature coverage mapping into a Blender text datablock.')
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        bundled = core.read_bundled_text(data.FEATURE_MATRIX_FILE).strip()
        source_index = core.read_bundled_text(getattr(data, 'DOC_SOURCE_INDEX_FILE', '')).strip()
        if bundled or source_index:
            parts = [part for part in (bundled, source_index) if part]
            body = '\n\n---\n\n'.join(parts)
        else:
            lines = ['Smart Shader Coverage Notes', '--------------------------------']
            lines.append(f"Document tool rows: {getattr(data, 'DOC_TOOL_COUNT', 0)}")
            lines.append('')
            for item in data.COVERAGE_ITEMS:
                lines.append(tx(context.scene, item['title_en'], item['title_ja']))
                lines.append(tx(context.scene, item['summary_en'], item['summary_ja']))
                lines.append('')
            body = '\n'.join(lines).strip()
        core.create_or_replace_text_block('SSS_Coverage_Notes', body)
        core.report_to_scene(context.scene, tx(context.scene, 'Coverage notes were written to the SSS_Coverage_Notes text block.', _lt('SSS_Coverage_Notes テキストへカバレッジノートを書き出しました。')))
        self.report({'INFO'}, _lt('Coverage notes written.'))
        return {'FINISHED'}

class SSS_OT_add_osl_helper(Operator):
    bl_idname = 'sss.add_osl_helper'
    bl_label = _lt('Add OSL Helper', 'OSL補助追加')
    bl_description = _lt('JP: サンプルOSLテキストとScriptノードを追加します。CyclesのOSLワークフロー向けです。\nEN: Add a sample OSL text block and Script node for Cycles OSL workflows.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = core.active_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: アクティブマテリアルがありません。 / EN: No active material.'))
            return {'CANCELLED'}
        material.use_nodes = True
        txt = core.create_osl_text_block()
        nt = material.node_tree
        script = nt.nodes.new('ShaderNodeScript')
        script.location = (-500, -500)
        script.label = 'SSS OSL Script'
        script.name = 'SSS OSL Script'
        try:
            script.mode = 'INTERNAL'
        except Exception:
            pass
        if hasattr(script, 'script'):
            script.script = txt
        core.report_to_scene(context.scene, tx(context.scene, 'Added OSL helper. In Cycles, enable OSL and update the Script node if needed.', _lt('OSL補助を追加しました。CyclesでOSLを有効にし、必要ならScriptノードを更新してください。')))
        self.report({'INFO'}, _lt('OSL helper added.'))
        return {'FINISHED'}

class SSS_OT_quick_fix_material(Operator):
    bl_idname = 'sss.quick_fix_material'
    bl_label = _lt('Quick Fix Material', 'マテリアルクイック修復')
    bl_description = _lt('JP: 選んでいる物の今の材質（無い時は対象マテリアル）に対し、出力補正、色空間補正、自動配線、整列、監査までを一括で実行します。壊れた取り込み材質の復旧に向きます。\nEN: Run output normalization, colorspace fixes, auto-wiring, layout, and audit on the selected object\'s current material (or the target material when it has none) in one pass. Useful for recovering imported or broken materials.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = choose_current_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material.'))
            return {'CANCELLED'}
        if context.scene.sss_non_destructive:
            material = core.duplicate_for_non_destructive(context, material)
        material.use_fake_user = context.scene.sss_use_fake_user
        material.use_nodes = True
        nt = material.node_tree
        out = core.ensure_output_node(nt, engine=core.render_engine(context))
        surface = core.socket_by_name(out.inputs, 'Surface') if out is not None else None
        if surface is None or not getattr(surface, 'is_linked', False):
            bsdf = nt.nodes.new('ShaderNodeBsdfPrincipled')
            bsdf.location = (-80, 40)
            nt.links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])
        standardized = textures.standardize_material_images(material)
        wired = textures.autowire_material_textures(material, force=bool(getattr(context.scene, 'sss_texture_force_rewire', False)))
        notes = postprocess_material_graph(material, context)
        params = core.get_material_params(material) or core.approx_params_from_material(material)
        core.set_managed_metadata_only(material, params=params, tags=core.get_material_tags(material) or ['Quick Fix', 'Managed'])
        context.scene.sss_target_material_name = material.name
        summary = [tx(context.scene, f"Checked textures: {standardized.get('checked', 0)}", _lt(f"確認テクスチャ: {standardized.get('checked', 0)}")), tx(context.scene, f"Fixed textures: {standardized.get('fixed', 0)}", _lt(f"補正テクスチャ: {standardized.get('fixed', 0)}")), tx(context.scene, f"Created helper nodes: {wired.get('created_nodes', 0)}", _lt(f"作成した補助ノード: {wired.get('created_nodes', 0)}")), tx(context.scene, f"Created links: {wired.get('new_links', 0)}", _lt(f"作成したリンク: {wired.get('new_links', 0)}"))]
        for note in wired.get('notes', [])[:6]:
            summary.append(note)
        report = join_notes('\n'.join(summary) + '\n\n' + audit.format_audit_report(material, context), notes)
        core.report_to_scene(context.scene, report)
        self.report({'INFO'}, _lt(f'Quick fixed: {material.name}'))
        return {'FINISHED'}

def _mask_label(scene, value) -> str:
    meta = layers.SMART_MASK_META.get(str(value or '').strip().upper())
    return tx(scene, meta['label_en'], meta['label_ja']) if meta else str(value or '')


class SSS_OT_apply_layer(Operator):
    bl_idname = 'sss.apply_layer'
    bl_label = _lt('Apply Layer', 'レイヤー適用')
    bl_description = _lt('JP: 選んでいる物の今の材質（無い時は対象マテリアル）へ、非破壊のスマートレイヤーを重ねます。摩耗、錆、苔、雪、濡れ、埃などを、再利用可能なマスク方式で追加できます。\nEN: Overlay a non-destructive smart layer onto the selected object\'s current material (or the target material when it has none). Add wear, rust, moss, snow, wetness, or dust through a reusable mask workflow.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = choose_current_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material.'))
            return {'CANCELLED'}
        if context.scene.sss_non_destructive:
            material = core.duplicate_for_non_destructive(context, material)
        material.use_fake_user = context.scene.sss_use_fake_user
        try:
            result = layers.apply_smart_layer(material, preset_id=context.scene.sss_layer_preset, mask_mode=context.scene.sss_layer_mask_mode, strength=context.scene.sss_layer_strength, noise_scale=context.scene.sss_layer_noise_scale, contrast=context.scene.sss_layer_mask_contrast)
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        notes = list(result.get('notes', [])) + postprocess_material_graph(material, context)
        context.scene.sss_target_material_name = material.name
        summary = [tx(context.scene, f"Layer: {result.get('label_en', '')}", _lt(f"レイヤー: {result.get('label_ja', '')}")), tx(context.scene, f"Mask mode: {_mask_label(context.scene, result.get('mask_mode', ''))}", f"マスク方式: {_mask_label(context.scene, result.get('mask_mode', ''))}"), tx(context.scene, f"Mask source: {_mask_label(context.scene, result.get('mask_source', '-') or '-')}", f"マスク源: {_mask_label(context.scene, result.get('mask_source', '-') or '-')}"), tx(context.scene, f"Created nodes: {result.get('created_nodes', 0)}", _lt(f"作成ノード数: {result.get('created_nodes', 0)}"))]
        core.report_to_scene(context.scene, join_notes('\n'.join(summary), notes))
        self.report({'INFO'}, _lt(f'Applied smart layer to: {material.name}'))
        return {'FINISHED'}

class SSS_OT_add_mask_utilities(Operator):
    bl_idname = 'sss.add_mask_utilities'
    bl_label = _lt('Add Mask Utilities', 'マスクユーティリティ追加')
    bl_description = _lt('JP: 現在の見た目を変えずに、上向き・エッジ・面方向・ノイズなどの再利用マスク補助ノードを追加します。手動調整用の下地づくりに向きます。\nEN: Add reusable mask helper nodes such as upward, edge, facing, and noise utilities without changing the current visible look. Useful as a manual setup base.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = choose_current_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material.'))
            return {'CANCELLED'}
        if context.scene.sss_non_destructive:
            material = core.duplicate_for_non_destructive(context, material)
        material.use_fake_user = context.scene.sss_use_fake_user
        try:
            result = layers.add_mask_utilities(material, noise_scale=context.scene.sss_layer_noise_scale, contrast=context.scene.sss_layer_mask_contrast)
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        notes = list(result.get('notes', [])) + postprocess_material_graph(material, context)
        context.scene.sss_target_material_name = material.name
        advisory = ', '.join(result.get('advisory_maps', [])) or '-'
        summary = [tx(context.scene, f"Created nodes: {result.get('created_nodes', 0)}", _lt(f"作成ノード数: {result.get('created_nodes', 0)}")), tx(context.scene, f'Detected advisory maps: {advisory}', _lt(f'検出した補助マップ: {advisory}')), tx(context.scene, 'Utilities were added unconnected for manual reuse.', _lt('ユーティリティは未接続のまま追加され、手動再利用しやすい状態です。'))]
        core.report_to_scene(context.scene, join_notes('\n'.join(summary), notes))
        self.report({'INFO'}, _lt(f'Added mask utilities to: {material.name}'))
        return {'FINISHED'}

class SSS_OT_save_recipe(Operator):
    bl_idname = 'sss.save_recipe'
    bl_label = _lt('Save Recipe', 'レシピ保存')
    bl_description = _lt('JP: 現在のスマートレイヤースタックを、再利用できるスマートマテリアル風レシピとして保存します。材質に保存済みのレイヤー履歴がある場合のみ保存できます。\nEN: Save the current smart-layer stack as a reusable smart-material style recipe. This works when the material already stores a smart-layer history.')
    bl_options = set()

    def execute(self, context):
        scene = context.scene
        material = choose_current_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material.'))
            return {'CANCELLED'}
        name = str(getattr(scene, 'sss_layer_recipe_name', '') or '').strip()
        if not name:
            self.report({'ERROR'}, _lt('JP: レイヤーレシピ名を入力してください。 / EN: Enter a layer recipe name first.'))
            return {'CANCELLED'}
        try:
            result = layers.save_layer_recipe_from_material(material, name)
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        try:
            properties.normalize_selected_layer_recipe(scene, context)
            scene.sss_layer_recipe_pick = result.get('name', name)
        except Exception:
            pass
        message = tx(scene, f"Saved layer recipe: {result.get('name', name)} | Layers={result.get('layer_count', 0)} | Replaced={result.get('replaced', False)}", _lt(f"レイヤーレシピを保存しました: {result.get('name', name)} | レイヤー数={result.get('layer_count', 0)} | 上書き={result.get('replaced', False)}"))
        core.report_to_scene(scene, join_notes(message, [material.name]))
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_apply_recipe(Operator):
    bl_idname = 'sss.apply_recipe'
    bl_label = _lt('Apply Recipe', 'レシピ適用')
    bl_description = _lt('JP: 保存済みレイヤーレシピを、選んでいる物の今の材質（無い時は対象マテリアル）へ適用します。複数のスマートレイヤーをまとめて再利用でき、Substance 系のスマートマテリアル風ワークフローを再現します。\nEN: Apply a saved layer recipe to the selected object\'s current material (or the target material when it has none). This reuses multiple smart layers as a stack, approximating a Substance-style smart-material workflow.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        material = choose_current_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material.'))
            return {'CANCELLED'}
        name = (getattr(scene, 'sss_layer_recipe_pick', '') or '').strip()
        if not name or name == 'NO_LAYER_RECIPES':
            self.report({'ERROR'}, _lt('JP: 適用する保存済みレイヤーレシピがありません。 / EN: No saved layer recipe is selected.'))
            return {'CANCELLED'}
        if getattr(scene, 'sss_non_destructive', False):
            material = core.duplicate_for_non_destructive(context, material)
        material.use_fake_user = getattr(scene, 'sss_use_fake_user', False)
        try:
            result = layers.apply_layer_recipe(material, name)
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        notes = list(result.get('notes', []) or []) + postprocess_material_graph(material, context)
        context.scene.sss_target_material_name = material.name
        labels_en = ', '.join(result.get('applied_labels_en', [])[:6]) or '-'
        labels_ja = '、'.join(result.get('applied_labels_ja', [])[:6]) or '-'
        summary = [tx(scene, f"Recipe: {result.get('recipe_name', name)}", _lt(f"レシピ: {result.get('recipe_name', name)}")), tx(scene, f"Layers applied: {result.get('layers_applied', 0)}", _lt(f"適用レイヤー数: {result.get('layers_applied', 0)}")), tx(scene, f"Created nodes: {result.get('created_nodes', 0)}", _lt(f"作成ノード数: {result.get('created_nodes', 0)}")), tx(scene, f'Applied layers: {labels_en}', _lt(f'適用レイヤー: {labels_ja}'))]
        core.report_to_scene(scene, join_notes('\n'.join(summary), notes))
        self.report({'INFO'}, _lt(f'Applied layer recipe to: {material.name}'))
        return {'FINISHED'}

class SSS_OT_delete_recipe(Operator):
    bl_idname = 'sss.delete_recipe'
    bl_label = _lt('Delete Recipe', 'レシピ削除')
    bl_description = _lt('JP: 選択した保存済みレイヤーレシピをローカルライブラリから削除します。\nEN: Remove the selected saved layer recipe from the local library.')
    bl_options = set()

    def execute(self, context):
        scene = context.scene
        name = (getattr(scene, 'sss_layer_recipe_pick', '') or '').strip()
        if not name or name == 'NO_LAYER_RECIPES':
            self.report({'ERROR'}, _lt('JP: 削除するレイヤーレシピがありません。 / EN: No layer recipe selected.'))
            return {'CANCELLED'}
        if not layers.delete_layer_recipe(name):
            self.report({'ERROR'}, _lt('JP: レイヤーレシピが見つかりません。 / EN: Layer recipe not found.'))
            return {'CANCELLED'}
        try:
            properties.normalize_selected_layer_recipe(scene, context)
        except Exception:
            scene.sss_layer_recipe_pick = 'NO_LAYER_RECIPES'
        core.report_to_scene(scene, tx(scene, f'Deleted layer recipe: {name}', _lt(f'レイヤーレシピを削除しました: {name}')))
        self.report({'INFO'}, _lt(f'Deleted layer recipe: {name}'))
        return {'FINISHED'}

class SSS_OT_export_recipe_library(Operator):
    bl_idname = 'sss.export_recipe_library'
    bl_label = _lt('Export Recipe Library', 'レシピライブラリ書出し')
    bl_description = _lt('JP: 保存済みレイヤーレシピのローカルライブラリを JSON として書き出します。共有、バックアップ、チーム再利用の土台に使えます。\nEN: Export the saved layer-recipe library as JSON for sharing, backup, or team reuse.')
    bl_options = set()
    _sms_no_undo = True
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = str(core.addon_storage_dir() / 'smart_shader_suite_layer_recipes.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        export_path = ensure_json_export_path(self.filepath, 'smart_shader_suite_layer_recipes.json')
        count = layers.export_layer_recipe_library(export_path)
        try:
            properties.normalize_selected_layer_recipe(context.scene, context)
        except Exception:
            pass
        message = tx(context.scene, f'Exported layer recipes: {count}', _lt(f'レイヤーレシピを書き出しました: {count} 件'))
        core.report_to_scene(context.scene, join_notes(message, [str(export_path)]))
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_import_recipe_library(Operator):
    bl_idname = 'sss.import_recipe_library'
    bl_label = _lt('Import Recipe Library', 'レシピライブラリ読込')
    bl_description = _lt('JP: JSON からレイヤーレシピライブラリを読み込みます。追加更新は追加更新、全置換は全置換です。\nEN: Import a layer-recipe library from JSON. Merge updates by name, Replace swaps the whole library.')
    bl_options = set()
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = str(core.addon_storage_dir() / 'smart_shader_suite_layer_recipes.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        path = ensure_json_import_path(self.filepath)
        if not path.exists() or not path.is_file():
            self.report({'ERROR'}, _lt('JP: ファイルが見つかりません。 / EN: File not found.'))
            return {'CANCELLED'}
        result = layers.import_layer_recipe_library(path, mode=getattr(context.scene, 'sss_layer_recipe_library_mode', 'MERGE'))
        try:
            properties.normalize_selected_layer_recipe(context.scene, context)
        except Exception:
            pass
        message = tx(context.scene, f"Imported={result['imported']} Replaced={result['replaced']} Invalid={result['skipped_invalid']} Total={result['total']}", _lt(f"追加={result['imported']} 置換={result['replaced']} 不正={result['skipped_invalid']} 合計={result['total']}"))
        core.report_to_scene(context.scene, join_notes(message, [str(path), f"mode={result['mode']}"]))
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_repair_recipe_library(Operator):
    bl_idname = 'sss.repair_recipe_library'
    bl_label = _lt('Repair Recipe Library', 'レシピライブラリ修復')
    bl_description = _lt('JP: 壊れた、重複した、名前のないレイヤーレシピを整理し、安全な形へ再保存します。\nEN: Repair broken, duplicate, or unnamed layer recipes and resave the library in a safe normalized form.')
    bl_options = set()

    def execute(self, context):
        result = layers.repair_layer_recipe_library()
        try:
            properties.normalize_selected_layer_recipe(context.scene, context)
        except Exception:
            pass
        message = tx(context.scene, f"Layer recipe library repaired: before={result['before']} after={result['after']} dropped={result['dropped']} duplicates={result['duplicates']}", _lt(f"レイヤーレシピライブラリを修復しました: 修復前={result['before']} 修復後={result['after']} 破棄={result['dropped']} 重複整理={result['duplicates']}"))
        core.report_to_scene(context.scene, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_save_entry(Operator):
    bl_idname = 'sss.save_entry'
    bl_label = _lt('Save Entry', 'エントリー保存')
    bl_description = _lt('JP: 現在の材質を、再利用できるマテリアルカタログ項目として保存します。見た目だけでなく、再構築や共有に役立つマニフェストと検索用タグもまとめて保持します。\nEN: Save the current material as a reusable material-catalog entry. This captures not only the look, but also the manifest and search tags needed for rebuilding, sharing, and later discovery.')
    bl_options = set()

    def execute(self, context):
        material = choose_current_material(context)
        if not material:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material.'))
            return {'CANCELLED'}
        scene = context.scene
        name = str(getattr(scene, 'sss_catalog_entry_name', '') or '').strip() or material.name
        tags_text = str(getattr(scene, 'sss_catalog_tags', '') or '')
        try:
            entry = catalog.save_catalog_entry_from_material(material, context, name=name, tags_text=tags_text)
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        try:
            properties.normalize_selected_catalog_entry(scene, context)
            scene.sss_catalog_pick = entry.get('name', name)
        except Exception:
            pass
        scene.sss_catalog_entry_name = entry.get('name', name)
        summary = tx(scene, f"Saved catalog entry: {entry.get('name', name)}", _lt(f"カタログ項目を保存しました: {entry.get('name', name)}"))
        details = [tx(scene, f"Tags: {', '.join(entry.get('tags', [])) or '-'}", _lt(f"タグ: {', '.join(entry.get('tags', [])) or '-'}")), tx(scene, f"Usages: {', '.join(entry.get('texture_usages', [])) or '-'}", _lt(f"用途候補: {', '.join(entry.get('texture_usages', [])) or '-'}"))]
        core.report_to_scene(scene, join_notes(summary, details))
        self.report({'INFO'}, summary)
        return {'FINISHED'}

class SSS_OT_apply_entry(Operator):
    bl_idname = 'sss.apply_entry'
    bl_label = _lt('Apply Entry', 'エントリー適用')
    bl_description = _lt('JP: 保存済みマテリアルカタログ項目を、現在のシーンへ安全寄りに復元または再構築します。保存されていたマニフェストを使うため、単なる見た目コピーより再利用性が高いです。\nEN: Restore or rebuild a saved material-catalog entry into the current scene using its stored manifest. This is more reusable than copying only the visible look.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        name = str(getattr(scene, 'sss_catalog_pick', '') or '').strip()
        if not name or name == catalog.CATALOG_SENTINEL:
            self.report({'ERROR'}, _lt('JP: 先に保存済みカタログ項目を選んでください。 / EN: Select a saved catalog entry first.'))
            return {'CANCELLED'}
        entry = catalog.find_catalog_entry(name)
        if not entry:
            self.report({'ERROR'}, _lt('JP: カタログ項目が見つかりません。 / EN: Catalog entry not found.'))
            return {'CANCELLED'}
        payload = entry.get('manifest')
        if not isinstance(payload, dict):
            self.report({'ERROR'}, _lt('JP: 保存済みマニフェストが壊れています。 / EN: Stored manifest is invalid.'))
            return {'CANCELLED'}
        material_name = str(getattr(scene, 'sss_material_name', '') or '').strip() or str(entry.get('source_material', '') or '').strip() or str(entry.get('name', '') or 'Catalog Material').strip()
        try:
            imported = import_material_manifest_payload(context, payload, material_name_override=material_name)
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        material = imported['material']
        scene.sss_target_material_name = material.name
        scene.sss_material_name = material.name
        summary = tx(scene, f"Applied catalog entry: {entry.get('name', name)}", _lt(f"カタログ項目を適用しました: {entry.get('name', name)}"))
        details = [tx(scene, f'Result material: {material.name}', _lt(f'生成材質: {material.name}')), tx(scene, f"Build mode: {imported.get('build_mode', 'unknown')}", _lt(f"再構築方式: {imported.get('build_mode', 'unknown')}"))]
        core.report_to_scene(scene, join_notes(summary, details + list(imported.get('notes', []))))
        self.report({'INFO'}, summary)
        return {'FINISHED'}

class SSS_OT_delete_entry(Operator):
    bl_idname = 'sss.delete_entry'
    bl_label = _lt('Delete Entry', 'エントリー削除')
    bl_description = _lt('JP: 選択中のマテリアルカタログ項目を削除します。重複や不要な再利用材質の整理に使います。\nEN: Delete the selected material-catalog entry to keep the reusable library organized and free of duplicates.')
    bl_options = set()

    def execute(self, context):
        scene = context.scene
        name = str(getattr(scene, 'sss_catalog_pick', '') or '').strip()
        if not name or name == catalog.CATALOG_SENTINEL:
            self.report({'ERROR'}, _lt('JP: 削除するカタログ項目を選んでください。 / EN: Select a catalog entry to delete.'))
            return {'CANCELLED'}
        if not catalog.delete_catalog_entry(name):
            self.report({'ERROR'}, _lt('JP: カタログ項目を削除できませんでした。 / EN: Failed to delete the catalog entry.'))
            return {'CANCELLED'}
        try:
            properties.normalize_selected_catalog_entry(scene, context)
        except Exception:
            pass
        summary = tx(scene, f'Deleted catalog entry: {name}', _lt(f'カタログ項目を削除しました: {name}'))
        core.report_to_scene(scene, summary)
        self.report({'INFO'}, summary)
        return {'FINISHED'}

class SSS_OT_export_library(Operator):
    bl_idname = 'sss.export_library'
    bl_label = _lt('Export Library', 'ライブラリ書出し')
    bl_description = _lt('JP: 保存済みマテリアルカタログを JSON として書き出します。共有、バックアップ、チーム用ライブラリの土台に使えます。\nEN: Export the saved material catalog as JSON for sharing, backup, or team-library workflows.')
    bl_options = set()
    _sms_no_undo = True
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = str(core.addon_storage_dir() / 'smart_shader_suite_material_catalog.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        export_path = ensure_json_export_path(self.filepath, 'smart_shader_suite_material_catalog.json')
        count = catalog.export_catalog_library(export_path)
        try:
            properties.normalize_selected_catalog_entry(context.scene, context)
        except Exception:
            pass
        message = tx(context.scene, f'Exported material catalog: {count} entries', _lt(f'マテリアルカタログを書き出しました: {count} 件'))
        core.report_to_scene(context.scene, join_notes(message, [str(export_path)]))
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_import_library(Operator):
    bl_idname = 'sss.import_library'
    bl_label = _lt('Import Library', 'ライブラリ読込')
    bl_description = _lt('JP: JSON からマテリアルカタログを読み込みます。追加更新は追加更新、全置換は現在のカタログ保存を全置換します。\nEN: Import a material catalog from JSON. Merge updates by name, while Replace swaps the entire current catalog.')
    bl_options = set()
    filepath: StringProperty(subtype='FILE_PATH', default='')
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = str(core.addon_storage_dir() / 'smart_shader_suite_material_catalog.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        path = ensure_json_import_path(self.filepath)
        if not path.exists() or not path.is_file():
            self.report({'ERROR'}, _lt('JP: ファイルが見つかりません。 / EN: File not found.'))
            return {'CANCELLED'}
        result = catalog.import_catalog_library(path, mode=getattr(context.scene, 'sss_catalog_library_mode', 'MERGE'))
        try:
            properties.normalize_selected_catalog_entry(context.scene, context)
        except Exception:
            pass
        message = tx(context.scene, f"Imported={result['imported']} Replaced={result['replaced']} Invalid={result['skipped_invalid']} Total={result['total']}", _lt(f"追加={result['imported']} 置換={result['replaced']} 不正={result['skipped_invalid']} 合計={result['total']}"))
        core.report_to_scene(context.scene, join_notes(message, [str(path), f"mode={result['mode']}"]))
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_repair_library(Operator):
    bl_idname = 'sss.repair_library'
    bl_label = _lt('Repair Library', 'ライブラリ修復')
    bl_description = _lt('JP: 壊れた、重複した、名前のないマテリアルカタログ項目を整理し、検索しやすい安全な形へ再保存します。\nEN: Repair broken, duplicate, or unnamed material-catalog entries and resave the catalog in a safe normalized form.')
    bl_options = set()

    def execute(self, context):
        result = catalog.repair_catalog_library()
        try:
            properties.normalize_selected_catalog_entry(context.scene, context)
        except Exception:
            pass
        message = tx(context.scene, f"Catalog repaired: before={result['before']} after={result['after']} dropped={result['dropped']} duplicates={result['duplicates']}", _lt(f"カタログを修復しました: 修復前={result['before']} 修復後={result['after']} 破棄={result['dropped']} 重複整理={result['duplicates']}"))
        core.report_to_scene(context.scene, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_use_result(Operator):
    bl_idname = 'sss.use_result'
    bl_label = _lt('Use Result', '結果を使用')
    bl_description = _lt('JP: スマート検索の選択結果を、現在の UI 選択へ反映します。プリセットはカテゴリと項目を切り替え、カタログは保存済み項目選択へ移します。\nEN: Transfer the selected Smart Search result into the current UI selection. Presets switch category and preset choice, while catalog results switch the saved catalog selection.')
    bl_options = set()

    def execute(self, context):
        key = getattr(context.scene, 'sss_asset_search_pick', '')
        if key == finder.ASSET_SEARCH_SENTINEL:
            self.report({'ERROR'}, tx(context.scene, 'No search result is available.', _lt('一致する検索結果がありません。')))
            return {'CANCELLED'}
        result = finder.find_asset_search_result(key, query=getattr(context.scene, 'sss_asset_search_query', ''))
        if not result:
            self.report({'ERROR'}, tx(context.scene, 'Search result could not be resolved.', _lt('検索結果を解決できませんでした。')))
            return {'CANCELLED'}
        kind = finder.apply_asset_search_selection_to_scene(context.scene, result)
        core.report_to_scene(context.scene, finder.asset_result_summary(context.scene, result))
        self.report({'INFO'}, tx(context.scene, f'Applied search result to UI selection ({kind}).', _lt(f'検索結果を UI 選択へ反映しました ({kind})。')))
        return {'FINISHED'}

class SSS_OT_apply_result(Operator):
    bl_idname = 'sss.apply_result'
    bl_label = _lt('Apply Result', '結果を適用')
    bl_description = _lt('JP: スマート検索で選んだ結果を、そのまま構築または復元します。プリセット系は新規作成、カタログ系は保存マニフェストから再構築します。\nEN: Build or restore the selected Smart Search result directly. Preset-style results create a material, while catalog results restore from the saved manifest.')
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        key = getattr(context.scene, 'sss_asset_search_pick', '')
        if key == finder.ASSET_SEARCH_SENTINEL:
            self.report({'ERROR'}, tx(context.scene, 'No search result is available.', _lt('一致する検索結果がありません。')))
            return {'CANCELLED'}
        result = finder.find_asset_search_result(key, query=getattr(context.scene, 'sss_asset_search_query', ''))
        if not result:
            self.report({'ERROR'}, tx(context.scene, 'Search result could not be resolved.', _lt('検索結果を解決できませんでした。')))
            return {'CANCELLED'}
        kind = finder.apply_asset_search_selection_to_scene(context.scene, result)
        if kind in {'PRESET', 'CUSTOM'}:
            direct = _execute_sss_operator_direct(context, 'create_preset_material', reporter=self)
            return direct if direct is not None else bpy.ops.sss.create_preset_material()
        if kind == 'CATALOG':
            direct = _execute_sss_operator_direct(context, 'apply_entry', reporter=self)
            return direct if direct is not None else bpy.ops.sss.apply_entry()
        self.report({'ERROR'}, tx(context.scene, 'Unsupported search result kind.', _lt('未対応の検索結果種別です。')))
        return {'CANCELLED'}

class SSS_OT_select_node(Operator):
    bl_idname = 'sss.select_node'
    bl_label = _lt('Select Node', 'ノード選択')
    bl_description = _lt('JP: ノードレンズ で選んだノードを、現在の材質ノードツリー上で選択してアクティブ化します。\nEN: Select and activate the node chosen in Node Lens inside the current material node tree.')
    bl_options = set()

    def execute(self, context):
        scene = context.scene
        material = core.preferred_material(context)
        if material is None or not getattr(material, 'use_nodes', False) or getattr(material, 'node_tree', None) is None:
            self.report({'ERROR'}, tx(scene, 'No node-based material is available.', _lt('ノードベース材質が見つかりません。')))
            return {'CANCELLED'}
        node_name = properties._safe_scene_get_value(scene, 'sss_node_pick', '')
        if node_name == finder.NODE_PICK_SENTINEL or not node_name:
            self.report({'ERROR'}, tx(scene, 'No matching node is selected.', _lt('一致するノードが選ばれていません。')))
            return {'CANCELLED'}
        node = finder.find_node(material, node_name)
        if node is None:
            self.report({'ERROR'}, tx(scene, 'Selected node could not be found.', _lt('選択ノードが見つかりません。')))
            return {'CANCELLED'}
        try:
            for item in material.node_tree.nodes:
                item.select = False
        except Exception:
            pass
        try:
            node.select = True
        except Exception:
            pass
        try:
            material.node_tree.nodes.active = node
        except Exception:
            pass
        core.report_to_scene(scene, finder.node_summary_text(scene, material, node))
        self.report({'INFO'}, tx(scene, f'Selected node: {node.name}', _lt(f'ノードを選択: {node.name}')))
        return {'FINISHED'}

class SSS_OT_write_node_report(Operator):
    bl_idname = 'sss.write_node_report'
    bl_label = _lt('Write Node Report', 'ノードレポート出力')
    bl_description = _lt('JP: ノードレンズ で選んだノードの詳細をレポート化します。画像ノードなら用途推定、色空間、欠損パスも表示します。\nEN: Write a detailed report for the node selected in Node Lens. Image nodes include guessed usage, color space, and missing-path status.')
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        scene = context.scene
        material = core.preferred_material(context)
        if material is None or not getattr(material, 'use_nodes', False) or getattr(material, 'node_tree', None) is None:
            self.report({'ERROR'}, tx(scene, 'No node-based material is available.', _lt('ノードベース材質が見つかりません。')))
            return {'CANCELLED'}
        node_name = properties._safe_scene_get_value(scene, 'sss_node_pick', '')
        if node_name == finder.NODE_PICK_SENTINEL or not node_name:
            self.report({'ERROR'}, tx(scene, 'No matching node is selected.', _lt('一致するノードが選ばれていません。')))
            return {'CANCELLED'}
        node = finder.find_node(material, node_name)
        if node is None:
            self.report({'ERROR'}, tx(scene, 'Selected node could not be found.', _lt('選択ノードが見つかりません。')))
            return {'CANCELLED'}
        core.report_to_scene(scene, finder.node_summary_text(scene, material, node))
        self.report({'INFO'}, tx(scene, f'Node report ready: {node.name}', _lt(f'ノードレポートを作成: {node.name}')))
        return {'FINISHED'}

class SSS_OT_run_self_check(Operator):
    bl_idname = 'sss.run_self_check'
    bl_label = _lt('Run Self Check', '自己診断実行')
    bl_description = _lt('JP: 実行環境、保存先、プリセット数、アクティブ材質、テクスチャ範囲設定を簡易診断します。\nEN: Run a lightweight diagnostic on environment, storage, preset counts, active material, and texture-scope settings.')
    bl_options = set()

    def execute(self, context):
        lines = ['Smart Shader Self Check', '------------------------------']
        lines.append(_lt(f'JP: Blenderバージョン = {core.safe_version_string()} / EN: Blender = {core.safe_version_string()}'))
        lines.append(_lt(f'JP: レンダーエンジン = {context.scene.render.engine} / EN: Render engine = {context.scene.render.engine}'))
        lines.append(_lt(f'JP: 保存先 = {core.addon_storage_dir()} / EN: Storage path = {core.addon_storage_dir()}'))
        lines.append(_lt(f'JP: 組み込みプリセット数 = {len(data.PRESET_LIBRARY)} / EN: Built-in presets = {len(data.PRESET_LIBRARY)}'))
        lines.append(_lt(f'JP: カスタムプリセット数 = {core.custom_preset_count()} / EN: Custom presets = {core.custom_preset_count()}'))
        lines.append(_lt(f"JP: ドキュメント対応元ツール数 = {getattr(data, 'DOC_TOOL_COUNT', 0)} / EN: Document source tools = {getattr(data, 'DOC_TOOL_COUNT', 0)}"))
        lines.append(_lt(f'JP: 割当方式 = {context.scene.sss_assign_mode} / EN: Assign mode = {context.scene.sss_assign_mode}'))
        lines.append(_lt(f'JP: テクスチャ再リンク範囲 = {context.scene.sss_texture_scope} / EN: Texture relink scope = {context.scene.sss_texture_scope}'))
        lines.append(_lt(f"JP: 自動整列 = {getattr(context.scene, 'sss_auto_layout_after_build', False)} / EN: Auto layout = {getattr(context.scene, 'sss_auto_layout_after_build', False)}"))
        lines.append(_lt(f"JP: 未接続削除 = {getattr(context.scene, 'sss_prune_after_build', False)} / EN: Prune unconnected = {getattr(context.scene, 'sss_prune_after_build', False)}"))
        lines.append(_lt(f"JP: 強制再配線 = {getattr(context.scene, 'sss_texture_force_rewire', False)} / EN: Force rewire = {getattr(context.scene, 'sss_texture_force_rewire', False)}"))
        lines.append(_lt(f"JP: HDRIパス = {getattr(context.scene, 'sss_hdri_path', '')} / EN: HDRI path = {getattr(context.scene, 'sss_hdri_path', '')}"))
        lines.append(_lt(f"JP: HDRI強度 = {getattr(context.scene, 'sss_hdri_strength', 1.0)} / EN: HDRI strength = {getattr(context.scene, 'sss_hdri_strength', 1.0)}"))
        lines.append(_lt(f"JP: HDRI回転 = {getattr(context.scene, 'sss_hdri_rotation', 0.0)} / EN: HDRI rotation = {getattr(context.scene, 'sss_hdri_rotation', 0.0)}"))
        lines.append(_lt(f"JP: HDRIライブラリ = {getattr(context.scene, 'sss_hdri_library_root', '')} / EN: HDRI library root = {getattr(context.scene, 'sss_hdri_library_root', '')}"))
        hdri_hits = environment.list_hdri_entries(getattr(context.scene, 'sss_hdri_library_root', ''), query=getattr(context.scene, 'sss_hdri_search', ''), limit=8)
        lines.append(_lt(f'JP: HDRI検索ヒット数(上限8) = {len(hdri_hits)} / EN: HDRI search hits (cap 8) = {len(hdri_hits)}'))
        lines.append(_lt(f'JP: カバレッジ表同梱 = {bool(core.read_bundled_text(data.FEATURE_MATRIX_FILE).strip())} / EN: Coverage matrix bundled = {bool(core.read_bundled_text(data.FEATURE_MATRIX_FILE).strip())}'))
        protected = core.count_protected_datablocks()
        lines.append(_lt(f"JP: 保護マテリアル数 = {protected['materials']} / EN: Protected materials = {protected['materials']}"))
        lines.append(_lt(f"JP: 保護画像数 = {protected['images']} / EN: Protected images = {protected['images']}"))
        lines.append(_lt(f"JP: 保護ノードグループ数 = {protected['node_groups']} / EN: Protected node groups = {protected['node_groups']}"))
        world_state = environment.world_hdri_state(context)
        lines.append(_lt(f"JP: ワールドHDRI状態 = {world_state['status_ja']} / EN: World HDRI status = {world_state['status_en']}"))
        lines.append(_lt(f"JP: スマートレイヤー = {getattr(context.scene, 'sss_layer_preset', '')} / EN: Smart layer preset = {getattr(context.scene, 'sss_layer_preset', '')}"))
        mode_value = getattr(context.scene, 'sss_layer_mask_mode', '')
        lines.append(_lt(f'Layer mask mode = {_mask_label(None, mode_value)}', f'レイヤーマスク方式 = {_mask_label(None, mode_value)}'))
        lines.append(_lt(f"JP: レイヤー強度 = {getattr(context.scene, 'sss_layer_strength', 0.0)} / EN: Layer strength = {getattr(context.scene, 'sss_layer_strength', 0.0)}"))
        lines.append(_lt(f'JP: 保存済みレイヤーレシピ数 = {layers.layer_recipe_count()} / EN: Saved layer recipes = {layers.layer_recipe_count()}'))
        lines.append(_lt(f'JP: 保存済みカタログ数 = {catalog.catalog_count()} / EN: Saved catalog entries = {catalog.catalog_count()}'))
        quick_actions = data.quick_action_ids_in_order() if hasattr(data, 'quick_action_ids_in_order') else list(data.QUICK_ACTION_ORDER)
        lines.append(_lt(f'JP: クイック操作数 = {len(quick_actions)} / EN: Quick actions = {len(quick_actions)}'))
        lines.append(_lt(f'JP: 保存済み割当ルール数 = {len(rules.list_assignment_rules())} / EN: Saved assignment rules = {len(rules.list_assignment_rules())}'))
        search_hits = finder.list_asset_search_results(getattr(context.scene, 'sss_asset_search_query', ''), limit=8)
        lines.append(_lt(f'JP: スマート検索ヒット数(上限8) = {len(search_hits)} / EN: Smart-search hits (cap 8) = {len(search_hits)}'))
        inventory_hits = inventory.list_inventory_entries(context.scene, query=getattr(context.scene, 'sss_inventory_search', ''))
        lines.append(_lt(f'JP: シーン材質インデックス件数 = {len(inventory_hits)} / EN: Scene Material Index entries = {len(inventory_hits)}'))
        try:
            layer_recipe_current = getattr(context.scene, 'sss_layer_recipe_pick', '')
            if layer_recipe_current:
                lines.append(_lt(f'JP: 選択中レイヤーレシピ = {layer_recipe_current} / EN: Selected layer recipe = {layer_recipe_current}'))
        except Exception:
            pass
        try:
            catalog_current = getattr(context.scene, 'sss_catalog_pick', '')
            if catalog_current and catalog_current != catalog.CATALOG_SENTINEL:
                lines.append(_lt(f'JP: 選択中カタログ = {catalog_current} / EN: Selected catalog entry = {catalog_current}'))
        except Exception:
            pass
        integrity = audit.addon_integrity_report(context)
        if integrity.get('info') or integrity.get('warnings') or integrity.get('errors'):
            lines.append('')
            lines.append(_lt('Addon Integrity / アドオン整合性'))
            lines.extend(integrity.get('info', []))
            if integrity.get('warnings'):
                lines.append(_lt('Warnings / 注意:'))
                lines.extend((f'- {line}' for line in integrity.get('warnings', [])))
            if integrity.get('errors'):
                lines.append(_lt('Errors / エラー:'))
                lines.extend((f'- {line}' for line in integrity.get('errors', [])))
        mat = core.active_material(context)
        if mat:
            lines.append(_lt(f'JP: アクティブ材質 = {mat.name} / EN: Active material = {mat.name}'))
            if mat.use_nodes and mat.node_tree:
                lines.append(_lt(f'JP: ノード数 = {len(mat.node_tree.nodes)} / EN: Node count = {len(mat.node_tree.nodes)}'))
                node_hits = finder.list_node_entries(mat, query=getattr(context.scene, 'sss_node_query', ''))
                lines.append(_lt(f'JP: ノードレンズ一致数 = {len(node_hits)} / EN: Node Lens matches = {len(node_hits)}'))
        else:
            lines.append(_lt('JP: アクティブ材質なし / EN: No active material'))
        core.report_to_scene(context.scene, '\n'.join(lines))
        self.report({'INFO'}, _lt('Self check complete.'))
        return {'FINISHED'}

class SSS_OT_run_action(Operator):
    bl_idname = 'sss.run_action'
    bl_label = _lt('Run Action', 'アクション実行')
    bl_description = _lt('JP: 選んだクイック操作を即座に実行します。検索しながら操作を呼び出せる、コンパクトなコマンドランチャーです。\nEN: Execute the selected quick action immediately. This acts as a compact searchable command launcher for the most common workflows.')
    bl_options = {'UNDO'}

    def execute(self, context):
        action = getattr(context.scene, 'sss_quick_action', 'QUICK_FIX')
        if action == 'NO_QUICK_ACTIONS':
            self.report({'ERROR'}, _lt('JP: 一致するクイック操作がありません。 / EN: No quick action matches the current search.'))
            return {'CANCELLED'}
        meta = data.QUICK_ACTION_META.get(action)
        if not meta:
            self.report({'ERROR'}, _lt('JP: クイック操作が見つかりません。 / EN: Quick action not found.'))
            return {'CANCELLED'}
        op_name = str(meta.get('operator', '') or '').strip()
        op = getattr(getattr(bpy.ops, 'sss', None), op_name, None)
        if not op_name or op is None:
            self.report({'ERROR'}, _lt('JP: 対応オペレーターが見つかりません。 / EN: Matching operator not found.'))
            return {'CANCELLED'}
        try:
            if bool(meta.get('invoke_default')):
                result = op('INVOKE_DEFAULT')
            else:
                result = _execute_sss_operator_direct(context, op_name, reporter=self)
                if result is None:
                    result = op()
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        if 'CANCELLED' in result:
            return {'CANCELLED'}
        return {'FINISHED'}

class SSS_OT_run_workflow(Operator):
    bl_idname = 'sss.run_workflow'
    bl_label = _lt('Run Workflow', 'ワークフロー実行')
    bl_description = _lt('JP: コンパクトUIで選択した代表ワークフローを実行します。似た機能を上位互換寄りの入口へまとめた実行ボタンです。\nEN: Execute the representative workflow selected in the compact UI. Similar tools are grouped behind this higher-level entry point.')
    bl_options = {'UNDO'}

    def execute(self, context):
        recipe = getattr(context.scene, 'sss_workspace_recipe', 'BUILD_PRESET')
        meta = getattr(data, 'WORKSPACE_RECIPE_META', {}).get(recipe)
        if not meta:
            self.report({'ERROR'}, _lt('JP: ワークフロー定義が見つかりません。 / EN: Workflow definition not found.'))
            return {'CANCELLED'}
        op_name = str(meta.get('operator', '') or '').strip()
        op = getattr(getattr(bpy.ops, 'sss', None), op_name, None)
        if not op_name or op is None:
            self.report({'ERROR'}, _lt('JP: 対応オペレーターが見つかりません。 / EN: Matching operator not found.'))
            return {'CANCELLED'}
        try:
            if bool(meta.get('invoke_default')):
                result = op('INVOKE_DEFAULT')
            else:
                result = _execute_sss_operator_direct(context, op_name, reporter=self)
                if result is None:
                    result = op()
        except Exception as exc:
            self.report({'ERROR'}, _exc_text(exc))
            return {'CANCELLED'}
        if 'CANCELLED' in result:
            return {'CANCELLED'}
        return {'FINISHED'}

class SSS_OT_scan_set(Operator):
    bl_idname = 'sss.scan_set'
    bl_label = _lt('Scan Set', 'セット診断')
    bl_description = _lt('JP: 現在のフォルダ、絞込、モード設定で、どのテクスチャが選ばれるかを先に診断します。誤配線や混在フォルダ事故の予防に向きます。\nEN: Preview which textures would be chosen with the current folder, filter, and mode. Useful for catching mixed-folder mistakes before building.')
    bl_options = set()

    def execute(self, context):
        root_raw = context.scene.sss_texture_search_root.strip()
        if not root_raw:
            self.report({'ERROR'}, _lt('JP: テクスチャフォルダを指定してください。 / EN: Choose a texture-set folder first.'))
            return {'CANCELLED'}
        root = Path(bpy.path.abspath(root_raw))
        scan = textures.scan_texture_set(root, filter_text=context.scene.sss_texture_set_filter.strip(), mode=context.scene.sss_texture_import_mode, name_hint=context.scene.sss_material_name.strip() or root.name)
        report = format_texture_scan_report(context.scene, scan)
        core.report_to_scene(context.scene, report)
        if not scan.get('selected_total'):
            self.report({'WARNING'}, _lt('No usable texture-set files selected.'))
            return {'CANCELLED'}
        self.report({'INFO'}, _lt(f"Selected {scan.get('selected_total', 0)} files"))
        return {'FINISHED'}

class SSS_OT_build_from_set(Operator):
    bl_idname = 'sss.build_from_set'
    bl_label = _lt('Build from Set', 'セットから構築')
    bl_description = _lt('JP: 指定フォルダから認識できる PBR テクスチャ一式を読み込み、新しいマテリアルを作成して自動配線します。ORM/ARM/RMA/MRA のパック済みマップや Glossiness/Smoothness にも対応します。\nEN: Read a recognizable PBR texture set from the chosen folder, build a new material, and auto-wire it. Packed ORM/ARM/RMA/MRA maps and Glossiness/Smoothness are also supported.')
    bl_options = {'UNDO'}

    def execute(self, context):
        root_raw = context.scene.sss_texture_search_root.strip()
        if not root_raw:
            self.report({'ERROR'}, _lt('JP: テクスチャフォルダを指定してください。 / EN: Choose a texture-set folder first.'))
            return {'CANCELLED'}
        root = Path(bpy.path.abspath(root_raw))
        if not root.exists():
            self.report({'ERROR'}, _lt('JP: テクスチャフォルダが存在しません。 / EN: Texture-set folder does not exist.'))
            return {'CANCELLED'}
        name_hint = context.scene.sss_material_name.strip() or context.scene.sss_texture_set_filter.strip() or root.name
        scan = textures.scan_texture_set(root, filter_text=context.scene.sss_texture_set_filter.strip(), mode=context.scene.sss_texture_import_mode, name_hint=name_hint)
        if not scan.get('selected_total'):
            report = format_texture_scan_report(context.scene, scan)
            core.report_to_scene(context.scene, report)
            self.report({'ERROR'}, _lt('JP: 使えるテクスチャセットが見つかりません。 / EN: No usable texture-set files were found.'))
            return {'CANCELLED'}
        if scan.get('selection_spans_groups') and (not context.scene.sss_allow_multi_group_texture_build):
            report = format_texture_scan_report(context.scene, scan)
            extra = tx(context.scene, 'Build aborted because the current selection spans multiple groups. Tighten the filter, switch to Auto Group, or explicitly enable multi-group import if this is intentional.', _lt('現在の選択が複数グループにまたがっているため、構築を中止しました。絞込を厳しくするか 自動グループ に切り替えるか、意図した処理なら複数グループ取込を明示的に有効化してください。'))
            core.report_to_scene(context.scene, join_notes(report, [extra]))
            self.report({'ERROR'}, extra)
            return {'CANCELLED'}
        material = bpy.data.materials.new(name=name_hint or 'TextureSet')
        material.use_fake_user = context.scene.sss_use_fake_user
        result = textures.build_material_from_texture_set(material, root, filter_text=context.scene.sss_texture_set_filter.strip(), force=True, mode=context.scene.sss_texture_import_mode, name_hint=name_hint)
        if result.get('files', 0) <= 0 or result.get('loaded_images', 0) <= 0:
            core.safe_remove_id(bpy.data.materials, material)
            message = join_notes(tx(context.scene, 'Texture-set build aborted because no usable images were loaded.', _lt('使える画像を読み込めなかったため、テクスチャセット構築を中止しました。')), result.get('notes', []) or scan.get('notes', []))
            core.report_to_scene(context.scene, message)
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        notes = postprocess_material_graph(material, context)
        params = core.approx_params_from_material(material)
        core.set_managed_metadata_only(material, note_en='Built from imported texture set.', note_ja=_lt('読み込んだテクスチャセットから構築したマテリアルです。'), params=params, tags=['Texture Set', 'Imported', 'Managed'])
        if context.scene.sss_mark_asset:
            core.mark_material_as_asset(material)
        assigned = core.assign_material_to_selected(context, material) if core.material_generation_should_assign_selected(context) else 0
        if not assigned:
            core.set_active_material(context, material)
        context.scene.sss_target_material_name = material.name
        message = [tx(context.scene, f"Loaded textures: {result['files']}", _lt(f"読み込んだテクスチャ数: {result['files']}")), tx(context.scene, f"Loaded images: {result['loaded_images']}", _lt(f"ロード済み画像数: {result['loaded_images']}")), tx(context.scene, f"Created nodes: {result['created_nodes']}", _lt(f"作成ノード数: {result['created_nodes']}")), tx(context.scene, f"Created links: {result['new_links']}", _lt(f"作成リンク数: {result['new_links']}")), tx(context.scene, f'Assigned objects: {assigned}', _lt(f'割り当てたオブジェクト数: {assigned}'))]
        if scan.get('selected_group'):
            message.append(tx(context.scene, f"Selected group: {scan['selected_group']}", _lt(f"選択グループ: {scan['selected_group']}")))
        if result.get('notes'):
            message.extend(result['notes'][:10])
        core.report_to_scene(context.scene, join_notes('\n'.join(message), notes))
        self.report({'INFO'}, _lt(f'Texture set built: {material.name}'))
        return {'FINISHED'}

class SSS_OT_relink_textures(Operator):
    bl_idname = 'sss.relink_textures'
    bl_label = _lt('Relink Textures', 'テクスチャ再リンク')
    bl_description = _lt('JP: 指定フォルダを再帰検索し、リンク切れ画像をファイル名一致で再接続します。\nEN: Search the given folder recursively and relink missing image textures by filename.')
    bl_options = {'UNDO'}

    def execute(self, context):
        root_raw = context.scene.sss_texture_search_root.strip()
        if not root_raw:
            self.report({'ERROR'}, _lt('JP: 検索フォルダを指定してください。 / EN: Choose a texture search root first.'))
            return {'CANCELLED'}
        root = Path(bpy.path.abspath(root_raw))
        if not root.exists():
            self.report({'ERROR'}, _lt('JP: 検索フォルダが存在しません。 / EN: Search root does not exist.'))
            return {'CANCELLED'}
        materials = [mat for mat in core.scoped_materials_for_textures(context) if mat]
        if not materials:
            self.report({'ERROR'}, _lt('JP: 対象マテリアルがありません。 / EN: No material matches the current texture scope.'))
            return {'CANCELLED'}
        relink = relink_missing_images_on_materials(materials, root)
        resolved = relink.get('resolved', 0)
        unresolved = relink.get('unresolved', [])
        message = [tx(context.scene, f'Resolved textures: {resolved}', _lt(f'再リンク成功: {resolved}')), tx(context.scene, f'Unresolved textures: {len(unresolved)}', _lt(f'未解決: {len(unresolved)}'))]
        if unresolved:
            message.append('\n'.join(unresolved[:12]))
        core.report_to_scene(context.scene, '\n'.join(message))
        self.report({'INFO'}, _lt(f'Resolved={resolved} Unresolved={len(unresolved)}'))
        return {'FINISHED'}

class SSS_OT_auto_layout_nodes(Operator):
    bl_idname = 'sss.auto_layout_nodes'
    bl_label = _lt('Auto Layout Nodes', 'ノード自動整列')
    bl_description = _lt('JP: 選んでいる物の今の材質（無い時は対象マテリアル）のノードを見やすく自動整列します。\nEN: Automatically arrange the node graph of the selected object\'s current material (or the target material when it has none) for readability.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = choose_current_material(context)
        if not material or not material.use_nodes or (not material.node_tree):
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active node material was found.'))
            return {'CANCELLED'}
        moved = core.auto_layout_node_tree(material, engine=core.render_engine(context))
        core.report_to_scene(context.scene, tx(context.scene, f'Auto-layout moved {moved} nodes.', _lt(f'自動整列したノード数: {moved}')))
        self.report({'INFO'}, _lt(f'Auto-layout moved {moved} nodes'))
        return {'FINISHED'}

class SSS_OT_prune_unconnected_nodes(Operator):
    bl_idname = 'sss.prune_unconnected_nodes'
    bl_label = _lt('Prune Unconnected Nodes', '未接続ノード削除')
    bl_description = _lt('JP: 現在の出力につながっていないノードを削除して、ノードツリーをコンパクトに保ちます。\nEN: Remove nodes that are not connected to the current output path and keep the node tree compact.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = choose_current_material(context)
        if not material or not material.use_nodes or (not material.node_tree):
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active node material was found.'))
            return {'CANCELLED'}
        removed = core.prune_unconnected_nodes(material, engine=core.render_engine(context))
        if getattr(context.scene, 'sss_auto_layout_after_build', True):
            core.auto_layout_node_tree(material, engine=core.render_engine(context))
        core.report_to_scene(context.scene, tx(context.scene, f'Removed unconnected nodes: {removed}', _lt(f'未接続ノードを削除: {removed}')))
        self.report({'INFO'}, _lt(f'Pruned {removed} nodes'))
        return {'FINISHED'}

class SSS_OT_standardize_color_space(Operator):
    bl_idname = 'sss.standardize_color_space'
    bl_label = _lt('Standardize Color Space', '色空間標準化')
    bl_description = _lt('JP: Roughness、Normal、AO などのデータマップを Non-Color に補正し、透明材質の基本設定も整えます。\nEN: Standardize texture setup by switching likely data maps to Non-Color and by fixing basic transparency settings when needed.')
    bl_options = {'UNDO'}

    def execute(self, context):
        materials = [mat for mat in core.scoped_materials_for_textures(context) if mat]
        if not materials:
            self.report({'ERROR'}, _lt('JP: 対象マテリアルがありません。 / EN: No material matches the current texture scope.'))
            return {'CANCELLED'}
        checked = 0
        fixed = 0
        details: list[str] = []
        for material in materials:
            result = textures.standardize_material_images(material)
            checked += result.get('checked', 0)
            fixed += result.get('fixed', 0)
            for detail in result.get('details', [])[:6]:
                details.append(f'{material.name}: {detail}')
        message = [tx(context.scene, f'Checked textures: {checked}', _lt(f'確認したテクスチャ数: {checked}')), tx(context.scene, f'Fixed textures: {fixed}', _lt(f'補正したテクスチャ数: {fixed}'))]
        if details:
            message.extend(details[:12])
        core.report_to_scene(context.scene, '\n'.join(message))
        self.report({'INFO'}, _lt(f'Checked={checked} Fixed={fixed}'))
        return {'FINISHED'}

class SSS_OT_auto_wire_textures(Operator):
    bl_idname = 'sss.auto_wire_textures'
    bl_label = _lt('Auto-Wire Textures', 'テクスチャ自動配線')
    bl_description = _lt('JP: 画像ノード名から用途を推定し、Principled BSDF へ不足リンクを自動接続します。必要なら AO 乗算、Normal、Bump、Alpha も補います。\nEN: Guess texture usage from image node names and automatically connect missing links to a Principled BSDF, including AO multiply, Normal, Bump, and Alpha when appropriate.')
    bl_options = {'UNDO'}

    def execute(self, context):
        materials = [mat for mat in core.scoped_materials_for_textures(context) if mat]
        if not materials:
            self.report({'ERROR'}, _lt('JP: 対象マテリアルがありません。 / EN: No material matches the current texture scope.'))
            return {'CANCELLED'}
        created_nodes = 0
        new_links = 0
        color_fixes = 0
        alpha_fixes = 0
        notes: list[str] = []
        force = bool(getattr(context.scene, 'sss_texture_force_rewire', False))
        for material in materials:
            result = textures.autowire_material_textures(material, force=force)
            created_nodes += result.get('created_nodes', 0)
            new_links += result.get('new_links', 0)
            color_fixes += result.get('color_fixes', 0)
            alpha_fixes += result.get('alpha_fixes', 0)
            notes.extend((f'{material.name}: {note}' for note in result.get('notes', [])[:4]))
            postprocess_material_graph(material, context)
        message = [tx(context.scene, f'Created helper nodes: {created_nodes}', _lt(f'作成した補助ノード: {created_nodes}')), tx(context.scene, f'Created links: {new_links}', _lt(f'作成したリンク: {new_links}')), tx(context.scene, f'Color-space fixes: {color_fixes}', _lt(f'色空間補正: {color_fixes}')), tx(context.scene, f'Transparency fixes: {alpha_fixes}', _lt(f'透明設定補正: {alpha_fixes}'))]
        if notes:
            message.extend(notes[:12])
        core.report_to_scene(context.scene, '\n'.join(message))
        self.report({'INFO'}, _lt(f'Links={new_links} Nodes={created_nodes}'))
        return {'FINISHED'}

class SSS_OT_capture_scene_materials(Operator):
    bl_idname = 'sss.capture_scene_materials'
    bl_label = _lt('Capture Scene Materials', 'シーンマテリアル取込')
    bl_description = _lt('JP: シーンで使われているマテリアルを一括で管理対象として登録します。既存ノードは壊さず、概要・近似パラメータだけを記録します。\nEN: Capture all scene-used materials into Smart Shader management without altering their node graphs. Only metadata and approximate parameters are recorded.')
    bl_options = set()

    def execute(self, context):
        materials = core.scene_materials(context)
        if not materials:
            self.report({'ERROR'}, _lt('JP: シーンで使用中のマテリアルがありません。 / EN: No scene-used materials were found.'))
            return {'CANCELLED'}
        count = 0
        for material in materials:
            params = core.approx_params_from_material(material)
            core.set_managed_metadata_only(material, note_en='Captured scene material managed by Smart Shader.', note_ja=_lt('スマートシェーダーで管理対象として取り込んだシーン内マテリアルです。'), params=params, tags=['Captured', 'Scene', 'Managed'])
            if context.scene.sss_mark_asset:
                core.mark_material_as_asset(material)
            count += 1
        core.report_to_scene(context.scene, tx(context.scene, f'Captured scene materials: {count}', _lt(f'取り込んだシーン内マテリアル数: {count}')))
        self.report({'INFO'}, _lt(f'Captured {count} materials'))
        return {'FINISHED'}

class SSS_OT_mark_used_materials_as_assets(Operator):
    bl_idname = 'sss.mark_used_materials_as_assets'
    bl_label = _lt('Mark Used Materials as Assets', '使用マテリアルをアセット化')
    bl_description = _lt('JP: シーンで使われているマテリアルを一括で Blender アセット化します。ライブラリ整理や共有前の準備に向いています。\nEN: Mark all scene-used materials as Blender assets. Useful before library organization or sharing.')
    bl_options = {'UNDO'}

    def execute(self, context):
        materials = core.scene_materials(context)
        if not materials:
            self.report({'ERROR'}, _lt('JP: シーンで使用中のマテリアルがありません。 / EN: No scene-used materials were found.'))
            return {'CANCELLED'}
        count = 0
        for material in materials:
            core.mark_material_as_asset(material)
            count += 1
        core.report_to_scene(context.scene, tx(context.scene, f'Marked used materials as assets: {count}', _lt(f'アセット化した使用中マテリアル数: {count}')))
        self.report({'INFO'}, _lt(f'Marked {count} assets'))
        return {'FINISHED'}

class SSS_OT_cleanup_slots(Operator):
    bl_idname = 'sss.cleanup_slots'
    bl_label = _lt('Cleanup Slots', 'スロットクリーンアップ')
    bl_description = _lt('JP: 選択オブジェクトの未使用または空のマテリアルスロットを安全に整理し、必要なら面インデックスを再割り当てします。\nEN: Safely clean empty or unused material slots on selected objects and remap face indices when needed.')
    bl_options = {'UNDO'}

    def execute(self, context):
        objects = list(getattr(context, 'selected_objects', []) or [])
        if not objects and getattr(context, 'object', None):
            objects = [context.object]
        if not objects:
            self.report({'ERROR'}, _lt('JP: 対象オブジェクトがありません。 / EN: No target object was found.'))
            return {'CANCELLED'}
        result = core.cleanup_material_slots(objects)
        core.report_to_scene(context.scene, tx(context.scene, f"Processed objects: {result['objects']} | Removed slots: {result['removed_slots']} | Remapped faces: {result['remapped_faces']}", _lt(f"処理オブジェクト数: {result['objects']} | 削除スロット: {result['removed_slots']} | 再割当面数: {result['remapped_faces']}")))
        self.report({'INFO'}, _lt(f"slots={result['removed_slots']} faces={result['remapped_faces']}"))
        return {'FINISHED'}

class SSS_OT_merge_duplicates(Operator):
    bl_idname = 'sss.merge_duplicates'
    bl_label = _lt('Merge Duplicates', '重複マテリアル統合')
    bl_description = _lt('JP: 同じ スマートシェーダー ビルダーと保存パラメータ、または近似的に同じ材質内容を持つ重複マテリアルを統合します。参照を置き換えたあと、不要になった複製材質を安全に削除します。\nEN: Merge duplicate materials that share the same Smart Shader builder and stored parameters, or closely matching fallback parameters. References are replaced first and removable duplicates are deleted safely.')
    bl_options = {'UNDO'}

    def execute(self, context):
        result = core.merge_duplicate_materials(core.scene_materials(context))
        core.report_to_scene(context.scene, tx(context.scene, f"Duplicate groups: {result['groups']} | Merged materials: {result['merged']} | Reassigned slots: {result['reassigned_slots']} | Removed: {result['removed']} | Skipped: {result['skipped']}", _lt(f"重複グループ: {result['groups']} | 統合材質: {result['merged']} | 差し替えスロット: {result['reassigned_slots']} | 削除: {result['removed']} | スキップ: {result['skipped']}")))
        self.report({'INFO'}, _lt(f"Merged={result['merged']} Groups={result['groups']}"))
        return {'FINISHED'}

class SSS_OT_protect_target_bundle(Operator):
    bl_idname = 'sss.protect_target_bundle'
    bl_label = _lt('Protect Target Bundle', 'ターゲット一式保護')
    bl_description = _lt('JP: 対象またはアクティブ材質と、その画像・ノードグループをクリーンアップ保護します。未使用掃除で消したくない重要アセットの固定に使います。\nEN: Protect the target or active material together with its linked images and node groups so cleanup tools will keep them.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = choose_target_or_active(context)
        if material is None:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material was found.'))
            return {'CANCELLED'}
        result = core.protect_material_bundle(material, value=True, reason='Pinned from Smart Shader')
        message = tx(context.scene, f"Protected bundle for {material.name}: materials={result['materials']} images={result['images']} groups={result['node_groups']}", _lt(f"{material.name} を保護しました: マテリアル={result['materials']} 画像={result['images']} グループ={result['node_groups']}"))
        core.report_to_scene(context.scene, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_clear_protection(Operator):
    bl_idname = 'sss.clear_protection'
    bl_label = _lt('Clear Protection', '保護解除')
    bl_description = _lt('JP: 対象またはアクティブ材質と、その画像・ノードグループからクリーンアップ保護を外します。\nEN: Remove cleanup protection from the target or active material and its linked images and node groups.')
    bl_options = {'UNDO'}

    def execute(self, context):
        material = choose_target_or_active(context)
        if material is None:
            self.report({'ERROR'}, _lt('JP: 対象またはアクティブ材質がありません。 / EN: No target or active material was found.'))
            return {'CANCELLED'}
        result = core.protect_material_bundle(material, value=False, reason='')
        message = tx(context.scene, f"Protection cleared for {material.name}: materials={result['materials']} images={result['images']} groups={result['node_groups']}", _lt(f"{material.name} の保護を解除しました: マテリアル={result['materials']} 画像={result['images']} グループ={result['node_groups']}"))
        core.report_to_scene(context.scene, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_build_world(Operator):
    bl_idname = 'sss.build_world'
    bl_label = _lt('Build World', 'ワールド構築')
    bl_description = _lt('JP: 指定した HDRI / EXR ファイルからワールド環境を構築します。LookDev、反射確認、製品CGの環境照明に向きます。\nEN: Build a world environment from the selected HDRI or EXR file for lookdev, reflections, and product CGI lighting.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        raw = bpy.path.abspath(scene.sss_hdri_path) if scene.sss_hdri_path else ''
        if not raw:
            self.report({'INFO'}, _lt('JP: HDRIファイルを指定してください。 / EN: Choose an HDRI file first.'))
            return {'CANCELLED'}
        result = environment.build_hdri_world(context, Path(raw), strength=float(getattr(scene, 'sss_hdri_strength', 1.0)), rotation=float(getattr(scene, 'sss_hdri_rotation', 0.0)))
        if not result.get('loaded_image'):
            message = join_notes(tx(scene, 'Failed to build HDRI world.', _lt('HDRIワールドの構築に失敗しました。')), result.get('notes', []))
            core.report_to_scene(scene, message)
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        message = join_notes(tx(scene, f"HDRI world ready: {result.get('world_name', '')}", _lt(f"HDRIワールドを構築しました: {result.get('world_name', '')}")), result.get('notes', []))
        core.report_to_scene(scene, message)
        self.report({'INFO'}, message)
        return {'FINISHED'}

class SSS_OT_relink_world(Operator):
    bl_idname = 'sss.relink_world'
    bl_label = _lt('Relink World', 'ワールド再リンク')
    bl_description = _lt('JP: 現在のワールド HDRI が見つからないとき、「HDRIライブラリ」のフォルダから一致候補を探して再リンクします。\nEN: When the current world HDRI is missing, search the HDRI Library folder and relink the best matching file.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        raw = environment._scene_hdri_root(scene) or (bpy.path.abspath(scene.sss_texture_search_root) if scene.sss_texture_search_root else '')
        if not raw:
            self.report({'INFO'}, _lt('JP: 先に「HDRIライブラリ」のフォルダを指定してください。 / EN: Choose an HDRI Library folder first.'))
            return {'CANCELLED'}
        result = environment.relink_hdri_world(context, Path(raw))
        success = bool(result.get('relinked'))
        message = join_notes(tx(scene, f"HDRI relinked: {result.get('path', '')}", _lt(f"HDRIを再リンクしました: {result.get('path', '')}")) if success else tx(scene, 'HDRI relink failed.', _lt('HDRIの再リンクに失敗しました。')), result.get('notes', []))
        core.report_to_scene(scene, message)
        self.report({'INFO'} if success else {'ERROR'}, message)
        return {'FINISHED'} if success else {'CANCELLED'}

class SSS_OT_use_candidate(Operator):
    bl_idname = 'sss.use_candidate'
    bl_label = _lt('Use Candidate', '候補を使用')
    bl_description = _lt('JP: HDRI ライブラリ検索で選んだ候補を、現在の HDRI ファイル欄へ反映します。すぐに HDRIワールド構築 したい前段の選択操作です。\nEN: Transfer the selected HDRI-library candidate into the current HDRI file field. This is the pick step before building the world.')
    bl_options = set()

    def execute(self, context):
        scene = context.scene
        key = getattr(scene, 'sss_hdri_pick', '')
        if key == environment.HDRI_SEARCH_SENTINEL:
            self.report({'ERROR'}, tx(scene, 'No HDRI candidate is available.', _lt('一致するHDRI候補がありません。')))
            return {'CANCELLED'}
        entry = environment.find_hdri_candidate(key, scene=scene)
        if not entry:
            self.report({'ERROR'}, tx(scene, 'HDRI candidate could not be resolved.', _lt('HDRI候補を解決できませんでした。')))
            return {'CANCELLED'}
        path = environment.apply_hdri_candidate_to_scene(scene, entry)
        message = environment.hdri_candidate_summary(scene, entry)
        core.report_to_scene(scene, message)
        self.report({'INFO'}, tx(scene, f'HDRI candidate selected: {Path(path).name}', _lt(f'HDRI候補を選択しました: {Path(path).name}')))
        return {'FINISHED'}

class SSS_OT_apply_candidate(Operator):
    bl_idname = 'sss.apply_candidate'
    bl_label = _lt('Apply Candidate', '候補適用')
    bl_description = _lt('JP: HDRI ライブラリ検索で選んだ候補を、そのままシーンワールドへ適用します。HDRI Link 風の検索→適用導線を、このパネルの中で完結させます。\nEN: Build the scene world directly from the selected HDRI-library candidate. This keeps an HDRI Link style search-to-apply workflow inside the same panel.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        key = getattr(scene, 'sss_hdri_pick', '')
        if key == environment.HDRI_SEARCH_SENTINEL:
            self.report({'ERROR'}, tx(scene, 'No HDRI candidate is available.', _lt('一致するHDRI候補がありません。')))
            return {'CANCELLED'}
        entry = environment.find_hdri_candidate(key, scene=scene)
        if not entry:
            self.report({'ERROR'}, tx(scene, 'HDRI candidate could not be resolved.', _lt('HDRI候補を解決できませんでした。')))
            return {'CANCELLED'}
        path = environment.apply_hdri_candidate_to_scene(scene, entry)
        result = environment.build_hdri_world(context, Path(path), strength=float(getattr(scene, 'sss_hdri_strength', 1.0)), rotation=float(getattr(scene, 'sss_hdri_rotation', 0.0)))
        if not result.get('loaded_image'):
            message = join_notes(tx(scene, 'Failed to build HDRI world from the selected candidate.', _lt('選択した候補からHDRIワールドを構築できませんでした。')), result.get('notes', []))
            core.report_to_scene(scene, message)
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        message = join_notes(environment.hdri_candidate_summary(scene, entry), result.get('notes', []))
        core.report_to_scene(scene, message)
        self.report({'INFO'}, tx(scene, f'Applied HDRI candidate: {Path(path).name}', _lt(f'HDRI候補を適用しました: {Path(path).name}')))
        return {'FINISHED'}

class SSS_OT_preview_repair(Operator):
    bl_idname = 'sss.preview_repair'
    bl_label = _lt('Preview Repair', '修復プレビュー')
    bl_description = _lt('JP: 現在の範囲・絞込・上限で シーンドクター が何件の材質を点検し、欠損や監査問題がどの程度ありそうかを変更前に確認します。\nEN: Preview how many materials the Scene Doctor would inspect and how many missing-texture or audit issues are in scope before changing anything.')
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        result = run_scene_doctor_pass(context, preview=True)
        report = '\n'.join(scene_doctor_summary_lines(context, result))
        core.report_to_scene(context.scene, report)
        self.report({'INFO'}, _lt(f"Scene Doctor preview: {result.get('materials_in_scope', 0)} materials"))
        return {'FINISHED'}

class SSS_OT_run_repair(Operator):
    bl_idname = 'sss.run_repair'
    bl_label = _lt('Run Repair', '修復実行')
    bl_description = _lt('JP: 指定範囲の材質を一括修復します。欠損再リンク、色空間補正、自動配線、整列を行い、残る監査問題をまとめます。\nEN: Batch-repair materials in the chosen scope by relinking missing images, fixing colorspaces, auto-wiring likely maps, laying out graphs, and summarizing the remaining audit issues.')
    bl_options = {'UNDO'}

    def execute(self, context):
        result = run_scene_doctor_pass(context, preview=False)
        if not result.get('materials_in_scope', 0):
            self.report({'ERROR'}, _lt('JP: 条件に一致する材質がありません。 / EN: No materials matched the current Scene Doctor scope.'))
            return {'CANCELLED'}
        report = '\n'.join(scene_doctor_summary_lines(context, result))
        core.report_to_scene(context.scene, report)
        self.report({'INFO'}, _lt(f"Scene Doctor processed {result.get('processed', 0)} materials"))
        return {'FINISHED'}

class SSS_OT_preview_cleanup(Operator):
    bl_idname = 'sss.preview_cleanup'
    bl_label = _lt('Preview Cleanup', 'クリーンアッププレビュー')
    bl_description = _lt('JP: 未使用データ掃除を実行する前に、削除候補と保護される項目数を確認します。\nEN: Preview removable and protected data counts before running cleanup.')
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        preview = core.preview_cleanup_unused_data()
        lines = []
        for key, label_en, label_ja in (('materials', 'Materials', _lt('マテリアル')), ('images', 'Images', _lt('画像')), ('node_groups', 'Node Groups', _lt('ノードグループ'))):
            block = preview.get(key, {})
            lines.append(tx(context.scene, f"{label_en}: removable={block.get('removable', 0)} protected={block.get('protected', 0)} skipped={block.get('skipped', 0)}", _lt(f"{label_ja}: 削除候補={block.get('removable', 0)} 保護={block.get('protected', 0)} スキップ={block.get('skipped', 0)}")))
            samples = block.get('samples') or []
            if samples:
                lines.append(tx(context.scene, f"  samples: {', '.join(samples)}", _lt(f"  例: {', '.join(samples)}")))
        report = '\n'.join(lines)
        core.report_to_scene(context.scene, report)
        self.report({'INFO'}, _lt('Cleanup preview ready.'))
        return {'FINISHED'}

class SSS_OT_cleanup_unused_data(Operator):
    bl_idname = 'sss.cleanup_unused_data'
    bl_label = _lt('Cleanup Unused Data', '未使用データクリーンアップ')
    bl_description = _lt('JP: 未使用マテリアル、画像、ノードグループを掃除し、可能なら孤立データの削除も実行します。\nEN: Clean up unused materials, images, and node groups, and run orphan purge when available.')
    bl_options = {'UNDO'}

    def execute(self, context):
        removed_materials = 0
        removed_images = 0
        removed_groups = 0
        skipped_materials = 0
        skipped_images = 0
        skipped_groups = 0
        protected_materials = 0
        protected_images = 0
        protected_groups = 0
        for material in list(bpy.data.materials):
            if material and material.users == 0 and (not material.use_fake_user):
                if core.is_cleanup_protected(material):
                    protected_materials += 1
                    continue
                if core.safe_remove_id(bpy.data.materials, material):
                    removed_materials += 1
                else:
                    skipped_materials += 1
        for image in list(bpy.data.images):
            if not image:
                continue
            if image.users != 0 or getattr(image, 'use_fake_user', False):
                continue
            if core.is_cleanup_protected(image):
                protected_images += 1
                continue
            if getattr(image, 'is_dirty', False) or getattr(image, 'packed_file', None):
                continue
            if getattr(image, 'source', 'FILE') != 'FILE':
                continue
            if image.name in {'Render Result', 'Viewer Node'}:
                continue
            if core.safe_remove_id(bpy.data.images, image):
                removed_images += 1
            else:
                skipped_images += 1
        for group in list(bpy.data.node_groups):
            if group and group.users == 0 and (not group.use_fake_user):
                if core.is_cleanup_protected(group):
                    protected_groups += 1
                    continue
                if core.safe_remove_id(bpy.data.node_groups, group):
                    removed_groups += 1
                else:
                    skipped_groups += 1
        purge_note = ''
        if hasattr(bpy.data, 'orphans_purge'):
            # orphans_purge takes every zero-user ID, so what the loops above kept
            # (protected, packed, generated, ...) holds a fake user while it runs.
            kept_ids = [item for collection in (bpy.data.materials, bpy.data.images, bpy.data.node_groups) for item in collection if item.users == 0 and not item.use_fake_user]
            for item in kept_ids:
                item.use_fake_user = True
            try:
                if context.scene.sss_cleanup_recursive:
                    bpy.data.orphans_purge(do_local_ids=True, do_linked_ids=False, do_recursive=True)
                else:
                    bpy.data.orphans_purge()
                purge_note = tx(context.scene, 'Orphan purge executed.', _lt('未使用データの削除を実行しました。'))
            except Exception:
                purge_note = tx(context.scene, 'Orphan purge skipped.', _lt('未使用データの削除はスキップされました。'))
            finally:
                for item in kept_ids:
                    item.use_fake_user = False
        report = '\n'.join([tx(context.scene, f'Removed materials: {removed_materials}', _lt(f'削除したマテリアル: {removed_materials}')), tx(context.scene, f'Skipped materials: {skipped_materials}', _lt(f'削除をスキップしたマテリアル: {skipped_materials}')), tx(context.scene, f'Removed images: {removed_images}', _lt(f'削除した画像: {removed_images}')), tx(context.scene, f'Skipped images: {skipped_images}', _lt(f'削除をスキップした画像: {skipped_images}')), tx(context.scene, f'Removed node groups: {removed_groups}', _lt(f'削除したノードグループ: {removed_groups}')), tx(context.scene, f'Skipped node groups: {skipped_groups}', _lt(f'削除をスキップしたノードグループ: {skipped_groups}')), tx(context.scene, f'Protected materials kept: {protected_materials}', _lt(f'保護により保持したマテリアル: {protected_materials}')), tx(context.scene, f'Protected images kept: {protected_images}', _lt(f'保護により保持した画像: {protected_images}')), tx(context.scene, f'Protected node groups kept: {protected_groups}', _lt(f'保護により保持したノードグループ: {protected_groups}')), purge_note]).strip()
        core.report_to_scene(context.scene, report)
        self.report({'INFO'}, _lt(f'Cleanup done. mats={removed_materials}, images={removed_images}, groups={removed_groups}'))
        return {'FINISHED'}

class SSS_OT_create_material(Operator):
    bl_idname = 'sss.create_material'
    bl_label = _lt('Create Material', 'マテリアル作成')
    bl_description = _lt('JP: 高度NPRスタジオの現在の設定から新規マテリアルを作成します。\nEN: Create a new material from the current Advanced NPR Studio settings.')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        name = str(getattr(scene, 'sss_npr_material_name', '') or 'NPR Studio Pro').strip() or 'NPR Studio Pro'
        material = bpy.data.materials.new(name=name)
        material.use_fake_user = bool(getattr(scene, 'sss_use_fake_user', False))
        try:
            builders.build_preset(material, 'NPR_STUDIO_PRO', custom_params=npr_studio_params_from_scene(scene))
        except Exception:
            core.safe_remove_id(bpy.data.materials, material)
            raise
        notes = postprocess_material_graph(material, context)
        if bool(getattr(scene, 'sss_mark_asset', False)):
            core.mark_material_as_asset(material)
        assigned = core.assign_material_to_selected(context, material) if bool(getattr(scene, 'sss_assign_selected', False)) else 0
        if not assigned:
            core.set_active_material(context, material)
        scene.sss_target_material_name = material.name
        if bool(getattr(scene, 'sss_auto_audit_after_build', False)):
            core.report_to_scene(scene, join_notes(audit.format_audit_report(material, context), notes))
        else:
            core.report_to_scene(scene, join_notes(tx(scene, 'Advanced NPR material created.', _lt('高度NPRマテリアルを作成しました。')), notes))
        self.report({'INFO'}, _lt(f'{material.name} created. Assigned={assigned}'))
        return {'FINISHED'}

def _choose_npr_update_material(context):
    current = core.active_material(context)
    target = core.get_target_material(context)
    for material in (current, target):
        if material is not None and material.get('sss_builder') == 'NPR_STUDIO_PRO':
            return material
    if current is not None:
        return core.duplicate_for_non_destructive(context, current)
    return target


class SSS_OT_update_material(Operator):
    bl_idname = 'sss.update_material'
    bl_label = _lt('Update Material', 'マテリアル更新')
    bl_description = _lt('JP: 選んでいる物のNPR材質を、高度NPRスタジオの現在設定で再構築します。今の材質がNPR材質でなければ、対象マテリアルのNPR材質を再構築します。どちらも無い時は今の材質を再構築します（非破壊がオンなら複製に対して行い、元の材質は残ります）。\nEN: Rebuild the selected object\'s NPR material using the current Advanced NPR Studio settings. If its current material is not an NPR material, the target NPR material is rebuilt instead. If neither exists, the current material is rebuilt (with Non-Destructive on, a copy is rebuilt and the original is kept).')
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        material = _choose_npr_update_material(context)
        if material is None:
            self.report({'ERROR'}, tx(scene, 'No active or target material.', _lt('アクティブまたはターゲットのマテリアルがありません。')))
            return {'CANCELLED'}
        builders.build_preset(material, 'NPR_STUDIO_PRO', custom_params=npr_studio_params_from_scene(scene))
        notes = postprocess_material_graph(material, context)
        if bool(getattr(scene, 'sss_mark_asset', False)):
            core.mark_material_as_asset(material)
        scene.sss_target_material_name = material.name
        if bool(getattr(scene, 'sss_auto_audit_after_build', False)):
            core.report_to_scene(scene, join_notes(audit.format_audit_report(material, context), notes))
        else:
            core.report_to_scene(scene, join_notes(tx(scene, f'Updated: {material.name}', _lt(f'更新しました: {material.name}')), notes))
        self.report({'INFO'}, tx(scene, f'Updated: {material.name}', _lt(f'更新しました: {material.name}')))
        return {'FINISHED'}

class SSS_OT_load_from_active(Operator):
    bl_idname = 'sss.load_from_active'
    bl_label = _lt('Load from Active', 'アクティブから読込')
    bl_description = _lt('JP: アクティブまたはターゲットのマテリアルに保存されているNPRパラメータを、高度NPRスタジオのUIへ読み戻します。\nEN: Load stored NPR parameters from the active or target material back into the Advanced NPR Studio UI.')
    bl_options = set()

    def execute(self, context):
        material = choose_current_material(context)
        if material is None:
            self.report({'ERROR'}, tx(context.scene, 'No active or target material.', _lt('アクティブまたはターゲットのマテリアルがありません。')))
            return {'CANCELLED'}
        params = core.get_material_params(material)
        if not params:
            self.report({'ERROR'}, tx(context.scene, 'The chosen material has no stored Smart Shader parameters.', _lt('選択材質には保存済みスマートシェーダーパラメータがありません。')))
            return {'CANCELLED'}
        apply_npr_studio_params_to_scene(context.scene, params)
        try:
            context.scene.sss_npr_material_name = material.name
        except Exception:
            pass
        self.report({'INFO'}, tx(context.scene, f'Loaded parameters from {material.name}', _lt(f'{material.name} からパラメータを読み込みました')))
        return {'FINISHED'}
CLASSES = (SSS_OT_select_preset_from_preview, SSS_OT_open_preset_preview_popup, SSS_OT_render_preset_previews, SSS_OT_create_pbr_fx_material, SSS_OT_create_preset_material, SSS_OT_create_material, SSS_OT_update_material, SSS_OT_load_from_active, SSS_OT_create_photo_pbr, SSS_OT_apply_to_active, SSS_OT_capture_active_material, SSS_OT_save_custom_preset, SSS_OT_delete_custom_preset, SSS_OT_export_custom_library, SSS_OT_import_custom_library, SSS_OT_repair_custom_library, SSS_OT_assign_to_selection, SSS_OT_set_active_target, SSS_OT_select_users, SSS_OT_use_index_pick, SSS_OT_select_index_users, SSS_OT_unassign_material, SSS_OT_preview_diff, SSS_OT_replace_with_target, SSS_OT_save_rule, SSS_OT_preview_rule, SSS_OT_apply_rule, SSS_OT_delete_rule, SSS_OT_export_rule_library, SSS_OT_import_rule_library, SSS_OT_repair_rule_library, SSS_OT_pick_active_material, SSS_OT_duplicate_target, SSS_OT_localize_target, SSS_OT_localize_per_object, SSS_OT_rename_target, SSS_OT_mark_target_asset, SSS_OT_rebuild_target, SSS_OT_rebuild_managed_materials, SSS_OT_audit_active_material, SSS_OT_audit_library, SSS_OT_normalize_output, SSS_OT_export_bundle, SSS_OT_import_bundle, SSS_OT_export_manifest, SSS_OT_save_variant, SSS_OT_apply_variant, SSS_OT_delete_variant, SSS_OT_export_variant_library, SSS_OT_import_variant_library, SSS_OT_repair_variant_library, SSS_OT_export_scene_manifest, SSS_OT_import_manifest, SSS_OT_import_scene_manifest, SSS_OT_write_coverage_report, SSS_OT_add_osl_helper, SSS_OT_quick_fix_material, SSS_OT_apply_layer, SSS_OT_add_mask_utilities, SSS_OT_save_recipe, SSS_OT_apply_recipe, SSS_OT_delete_recipe, SSS_OT_export_recipe_library, SSS_OT_import_recipe_library, SSS_OT_repair_recipe_library, SSS_OT_save_entry, SSS_OT_apply_entry, SSS_OT_delete_entry, SSS_OT_export_library, SSS_OT_import_library, SSS_OT_repair_library, SSS_OT_use_result, SSS_OT_apply_result, SSS_OT_select_node, SSS_OT_write_node_report, SSS_OT_run_self_check, SSS_OT_run_workflow, SSS_OT_run_action, SSS_OT_scan_set, SSS_OT_build_from_set, SSS_OT_scan_library, SSS_OT_build_library, SSS_OT_relink_textures, SSS_OT_auto_layout_nodes, SSS_OT_prune_unconnected_nodes, SSS_OT_standardize_color_space, SSS_OT_auto_wire_textures, SSS_OT_capture_scene_materials, SSS_OT_mark_used_materials_as_assets, SSS_OT_cleanup_slots, SSS_OT_merge_duplicates, SSS_OT_protect_target_bundle, SSS_OT_clear_protection, SSS_OT_build_world, SSS_OT_relink_world, SSS_OT_use_candidate, SSS_OT_apply_candidate, SSS_OT_preview_repair, SSS_OT_run_repair, SSS_OT_preview_cleanup, SSS_OT_cleanup_unused_data)



def _sss_slot_prop_annotation():
    return EnumProperty(**slot_selection.MATERIAL_TARGET_SLOT_PROPERTY_KWARGS)


def _sss_apply_operator_slot_token(self, context):
    try:
        slot_selection.apply_operator_material_target_slot(self, context)
    except Exception:
        pass


def _sss_slot_prompt_needed_default(self, context) -> bool:
    return True


def _sss_slot_prompt_needed_preview(self, context) -> bool:
    return bool(getattr(self, 'generate', False))


def _sss_slot_prompt_needed_apply_to_active(self, context) -> bool:
    scene = getattr(context, 'scene', None)
    if scene is None:
        return False
    return bool(getattr(scene, 'sss_non_destructive', True) or getattr(scene, 'sss_assign_selected', False))


def _sss_slot_prompt_needed_non_destructive(self, context) -> bool:
    scene = getattr(context, 'scene', None)
    if scene is None:
        return False
    return bool(getattr(scene, 'sss_non_destructive', False))


def _sss_slot_prompt_needed_apply_result(self, context) -> bool:
    scene = getattr(context, 'scene', None)
    if scene is None:
        return False
    try:
        key = getattr(scene, 'sss_asset_search_pick', '')
        if key == finder.ASSET_SEARCH_SENTINEL:
            return False
        result = finder.find_asset_search_result(key, query=getattr(scene, 'sss_asset_search_query', ''))
        kind = finder.apply_asset_search_selection_to_scene(scene, result) if result else ''
        return kind in {'PRESET', 'CUSTOM', 'CATALOG'}
    except Exception:
        return True


def _wrap_material_target_slot_prompt(cls, need_getter=_sss_slot_prompt_needed_default):
    if getattr(cls, '_sss_material_target_slot_prompt_wrapped', False):
        return cls
    annotations = dict(getattr(cls, '__annotations__', {}) or {})
    if 'sss_target_slot_token' not in annotations:
        annotations['sss_target_slot_token'] = _sss_slot_prop_annotation()
        cls.__annotations__ = annotations
    if not getattr(cls, 'bl_property', ''):
        try:
            cls.bl_property = 'sss_target_slot_token'
        except Exception:
            pass
    original_invoke = getattr(cls, 'invoke', None)
    original_execute = getattr(cls, 'execute', None)

    def invoke(self, context, event):
        try:
            should_prompt = bool(need_getter(self, context))
        except Exception:
            should_prompt = True
        if should_prompt:
            result = slot_selection.invoke_operator_material_target_slot_search(self, context, assign_selected=True)
            if result:
                return result
        if callable(original_invoke):
            return original_invoke(self, context, event)
        if callable(original_execute):
            return self.execute(context)
        return {'CANCELLED'}

    def execute(self, context):
        _sss_apply_operator_slot_token(self, context)
        if callable(original_execute):
            return original_execute(self, context)
        return {'CANCELLED'}

    cls.invoke = invoke
    cls.execute = execute
    cls._sss_material_target_slot_prompt_wrapped = True
    return cls


def _patch_preset_preview_popup_slot_prompt():
    cls = SSS_OT_open_preset_preview_popup
    if getattr(cls, '_sss_material_target_slot_prompt_wrapped', False):
        return
    annotations = dict(getattr(cls, '__annotations__', {}) or {})
    if 'sss_target_slot_token' not in annotations:
        annotations['sss_target_slot_token'] = _sss_slot_prop_annotation()
        cls.__annotations__ = annotations
    if not getattr(cls, 'bl_property', ''):
        try:
            cls.bl_property = 'sss_target_slot_token'
        except Exception:
            pass
    original_invoke = getattr(cls, 'invoke', None)
    original_execute = getattr(cls, 'execute', None)

    def _open_picker_from_context(self, context):
        if not preset_preview_browser.workspace_runtime_allowed(context):
            return {'CANCELLED'}
        target = str(getattr(self, 'target', 'MAIN') or 'MAIN').upper()
        try:
            preset_preview_browser.sync_preview_choice(context, target=target)
            preset_preview_browser.sync_preview_choice(context, target=target)
        except Exception:
            pass
        try:
            preset_preview_browser.prepare_preview_grid(context, target=target, generate=bool(getattr(self, 'generate', False)), force=True)
        except Exception:
            pass
        result = preset_preview_browser.open_modal_preview_picker(
            self,
            context,
            target=target,
            generate=bool(getattr(self, 'generate', False)),
            columns=12,
            use_dedicated_window=False,
        )
        if result:
            return result
        try:
            win_w = int(getattr(getattr(context, 'window', None), 'width', 0) or 0)
        except Exception:
            win_w = 0
        popup_width = max(960, min(1480, win_w - 40 if win_w > 0 else 1180))
        try:
            return context.window_manager.invoke_popup(self, width=popup_width)
        except Exception:
            return {'FINISHED'}

    def invoke(self, context, event):
        if not preset_preview_browser.workspace_runtime_allowed(context):
            return {'CANCELLED'}
        if bool(getattr(self, 'generate', False)):
            result = slot_selection.invoke_operator_material_target_slot_search(self, context, assign_selected=True)
            if result:
                return result
        if callable(original_invoke):
            return original_invoke(self, context, event)
        return _open_picker_from_context(self, context)

    def execute(self, context):
        if not preset_preview_browser.workspace_runtime_allowed(context):
            return {'CANCELLED'}
        _sss_apply_operator_slot_token(self, context)
        if bool(getattr(self, 'generate', False)):
            return _open_picker_from_context(self, context)
        if callable(original_execute):
            return original_execute(self, context)
        return {'FINISHED'}

    cls.invoke = invoke
    cls.execute = execute
    cls._sss_material_target_slot_prompt_wrapped = True


def _wrap_file_selector_material_target_slot_prompt(cls, need_getter=_sss_slot_prompt_needed_default):
    if getattr(cls, '_sss_material_target_file_slot_prompt_wrapped', False):
        return cls
    annotations = dict(getattr(cls, '__annotations__', {}) or {})
    if 'sss_target_slot_token' not in annotations:
        annotations['sss_target_slot_token'] = _sss_slot_prop_annotation()
    if 'sss_target_slot_search_active' not in annotations:
        annotations['sss_target_slot_search_active'] = BoolProperty(default=False, options={'SKIP_SAVE', 'HIDDEN'})
    cls.__annotations__ = annotations
    if not getattr(cls, 'bl_property', ''):
        try:
            cls.bl_property = 'sss_target_slot_token'
        except Exception:
            pass
    original_invoke = getattr(cls, 'invoke', None)
    original_execute = getattr(cls, 'execute', None)

    def _open_file_selector(self, context, event=None):
        if callable(original_invoke):
            return original_invoke(self, context, event)
        return {'CANCELLED'}

    def invoke(self, context, event):
        try:
            should_prompt = bool(need_getter(self, context))
        except Exception:
            should_prompt = True
        if should_prompt:
            result = slot_selection.invoke_operator_material_target_slot_search(self, context, assign_selected=True)
            if result:
                try:
                    self.sss_target_slot_search_active = True
                except Exception:
                    pass
                return result
        return _open_file_selector(self, context, event)

    def execute(self, context):
        search_active = False
        try:
            search_active = bool(getattr(self, 'sss_target_slot_search_active', False))
        except Exception:
            search_active = False
        _sss_apply_operator_slot_token(self, context)
        if search_active:
            try:
                self.sss_target_slot_search_active = False
            except Exception:
                pass
            return _open_file_selector(self, context, None)
        if callable(original_execute):
            return original_execute(self, context)
        return {'CANCELLED'}

    cls.invoke = invoke
    cls.execute = execute
    cls._sss_material_target_file_slot_prompt_wrapped = True
    return cls


def _enable_material_target_slot_prompts():
    for cls, getter in (
        (SSS_OT_select_preset_from_preview, _sss_slot_prompt_needed_preview),
        (SSS_OT_create_pbr_fx_material, _sss_slot_prompt_needed_default),
        (SSS_OT_create_preset_material, _sss_slot_prompt_needed_default),
        (SSS_OT_create_photo_pbr, _sss_slot_prompt_needed_default),
        (SSS_OT_apply_to_active, _sss_slot_prompt_needed_apply_to_active),
        (SSS_OT_assign_to_selection, _sss_slot_prompt_needed_default),
        (SSS_OT_set_active_target, _sss_slot_prompt_needed_default),
        (SSS_OT_duplicate_target, _sss_slot_prompt_needed_default),
        (SSS_OT_apply_rule, _sss_slot_prompt_needed_default),
        (SSS_OT_rebuild_target, _sss_slot_prompt_needed_non_destructive),
        (SSS_OT_normalize_output, _sss_slot_prompt_needed_non_destructive),
        (SSS_OT_quick_fix_material, _sss_slot_prompt_needed_non_destructive),
        (SSS_OT_apply_layer, _sss_slot_prompt_needed_non_destructive),
        (SSS_OT_add_mask_utilities, _sss_slot_prompt_needed_non_destructive),
        (SSS_OT_apply_recipe, _sss_slot_prompt_needed_non_destructive),
        (SSS_OT_localize_target, _sss_slot_prompt_needed_default),
        (SSS_OT_localize_per_object, _sss_slot_prompt_needed_default),
        (SSS_OT_apply_entry, _sss_slot_prompt_needed_default),
        (SSS_OT_apply_result, _sss_slot_prompt_needed_apply_result),
        (SSS_OT_build_from_set, _sss_slot_prompt_needed_default),
        (SSS_OT_build_library, _sss_slot_prompt_needed_default),
        (SSS_OT_create_material, _sss_slot_prompt_needed_default),
    ):
        _wrap_material_target_slot_prompt(cls, getter)
    for cls, getter in (
        (SSS_OT_import_bundle, _sss_slot_prompt_needed_default),
        (SSS_OT_import_manifest, _sss_slot_prompt_needed_default),
    ):
        _wrap_file_selector_material_target_slot_prompt(cls, getter)
    _patch_preset_preview_popup_slot_prompt()


_enable_material_target_slot_prompts()
