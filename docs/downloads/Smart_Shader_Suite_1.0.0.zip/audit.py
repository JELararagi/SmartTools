"""Audit and validation helpers."""
from __future__ import annotations
from .translation import loc_text as _lt
from pathlib import Path
import bpy
from . import builders, bundle, catalog, core, data, environment, finder, inventory, layers, rules, textures

def audit_material(material, context) -> dict:
    errors: list[str] = []
    warnings: list[str] = []
    info: list[str] = []
    if not material:
        errors.append(_lt('JP: アクティブマテリアルがありません。 / EN: No active material.'))
        return {'errors': errors, 'warnings': warnings, 'info': info}
    engine = core.render_engine(context)
    info.append(_lt(f'JP: マテリアル名 = {material.name} / EN: Material = {material.name}'))
    info.append(_lt(f'JP: ユーザー数 = {material.users} / EN: Users = {material.users}'))
    users = list(core.iter_scene_material_users(material))
    info.append(_lt(f'JP: 使用オブジェクト数 = {len(users)} / EN: Object users = {len(users)}'))
    info.append(_lt(f"JP: アセット化 = {bool(getattr(material, 'asset_data', None))} / EN: Asset marked = {bool(getattr(material, 'asset_data', None))}"))
    info.append(_lt(f'JP: クリーンアップ保護 = {core.is_cleanup_protected(material)} / EN: Cleanup protected = {core.is_cleanup_protected(material)}'))
    if material.users == 0:
        warnings.append(_lt('JP: このマテリアルは未使用です。 / EN: This material currently has no users.'))
    if not material.use_nodes or not material.node_tree:
        errors.append(_lt('JP: ノードベースのマテリアルではありません。 / EN: Material is not node-based.'))
        return {'errors': errors, 'warnings': warnings, 'info': info}
    nt = material.node_tree
    info.append(_lt(f'JP: ノード数 = {len(nt.nodes)} / EN: Node count = {len(nt.nodes)}'))
    info.append(_lt(f'JP: リンク数 = {len(nt.links)} / EN: Link count = {len(nt.links)}'))
    outputs = core.output_nodes(nt)
    if not outputs:
        errors.append(_lt('JP: マテリアル出力ノードがありません。 / EN: No Material Output node was found.'))
    else:
        targets: dict[str, int] = {}
        for node in outputs:
            target = str(getattr(node, 'target', 'ALL') or 'ALL')
            targets[target] = targets.get(target, 0) + 1
        info.append(_lt(f'JP: 出力ターゲット = {targets} / EN: Output targets = {targets}'))
        selected_output = core.preferred_output_node(nt, engine=engine)
        if selected_output is not None:
            selected_target = str(getattr(selected_output, 'target', 'ALL') or 'ALL')
            info.append(_lt(f'JP: 現在エンジン向け出力 = {selected_output.name} ({selected_target}) / EN: Selected output for current engine = {selected_output.name} ({selected_target})'))
        else:
            selected_output = outputs[0]
        active_outputs = [node for node in outputs if getattr(node, 'is_active_output', False)]
        if not active_outputs and len(outputs) == 1:
            warnings.append(_lt('JP: アクティブなマテリアル出力が見つかりません。単一出力として扱います。 / EN: No active Material Output was flagged, treating the only output as active.'))
        elif len(outputs) > 1:
            duplicate_targets = [target for target, count in targets.items() if count > 1]
            if duplicate_targets:
                warnings.append(_lt('JP: 同じターゲット向けの マテリアル出力 が複数あります。整理を推奨します。 / EN: Multiple Material Outputs target the same renderer; cleanup is recommended.'))
            else:
                info.append(_lt('JP: レンダラー別の マテリアル出力 分岐を検出しました。 / EN: Renderer-specific Material Output branches were detected.'))
        output = selected_output
        try:
            surface = core.socket_by_name(output.inputs, 'Surface')
            if surface is None or not surface.is_linked:
                errors.append(_lt('JP: 現在のレンダーエンジン向けマテリアル出力のSurfaceが未接続です。 / EN: Surface is not linked on the Material Output chosen for the current render engine.'))
        except Exception:
            errors.append(_lt('JP: マテリアル出力のSurface確認に失敗しました。 / EN: Failed to inspect the Material Output Surface.'))
        try:
            displacement = core.socket_by_name(output.inputs, 'Displacement')
            if displacement is not None and displacement.is_linked:
                info.append(_lt('JP: ディスプレイスメント接続あり / EN: Displacement is connected.'))
                if engine == 'CYCLES':
                    method = getattr(getattr(material, 'cycles', None), 'displacement_method', '')
                    if method in {'BUMP', 'BUMP_ONLY'}:
                        warnings.append(_lt('JP: ディスプレイスメントが接続されていますが、材質設定がBump系です。 / EN: Displacement is connected but the material displacement mode is bump-only.'))
            else:
                info.append(_lt('JP: ディスプレイスメント未接続 / EN: Displacement is not connected.'))
        except Exception:
            pass
    image_nodes = core.iter_image_nodes(material)
    info.append(_lt(f'JP: 画像テクスチャ数 = {len(image_nodes)} / EN: Image textures = {len(image_nodes)}'))
    missing_images: list[str] = []
    abs_paths = 0
    for node in image_nodes:
        image = node.image
        try:
            raw = bpy.path.abspath(image.filepath)
        except Exception:
            raw = ''
        if raw:
            if Path(raw).is_absolute():
                abs_paths += 1
            if not getattr(image, 'packed_file', None) and (not Path(raw).exists()):
                missing_images.append(f'{node.name}: {raw}')
        else:
            missing_images.append(f'{node.name}: <empty path>')
    if missing_images:
        warnings.append(_lt('JP: リンク切れ画像があります。 / EN: Some image textures are missing.\n') + '\n'.join(missing_images[:8]))
    if abs_paths:
        warnings.append(_lt(f'JP: 絶対パスの画像が {abs_paths} 件あります。 / EN: {abs_paths} image(s) use absolute paths.'))
    for finding in textures.texture_audit_findings(material):
        warnings.append(_lt(f"JP: {finding['ja']} / EN: {finding['en']}"))
    obj = getattr(context, 'object', None)
    if obj and obj.type == 'MESH' and image_nodes:
        uv_layers = getattr(obj.data, 'uv_layers', None)
        if uv_layers is not None and len(uv_layers) == 0:
            warnings.append(_lt('JP: 画像テクスチャがありますがUVが見つかりません。 / EN: Image textures exist but no UV map was found.'))
    script_nodes = [node for node in nt.nodes if node.bl_idname == 'ShaderNodeScript']
    if script_nodes:
        if engine != 'CYCLES':
            warnings.append(_lt('JP: Script/OSLノードがありますが、現在のレンダーエンジンがCyclesではありません。 / EN: Script/OSL nodes are present but the current render engine is not Cycles.'))
        shading_system = ''
        try:
            shading_system = context.scene.cycles.shading_system
        except Exception:
            shading_system = ''
        if shading_system not in {'OSL'}:
            warnings.append(_lt('JP: Script/OSLノードがあります。CyclesのOSL設定を確認してください。 / EN: Script/OSL nodes are present. Check the Cycles OSL setting.'))
    shader_to_rgb = [node for node in nt.nodes if node.bl_idname == 'ShaderNodeShaderToRGB']
    if shader_to_rgb and engine == 'CYCLES':
        warnings.append(_lt('JP: Shader to RGBは主にEevee系向けです。 / EN: Shader to RGB is mainly intended for Eevee-style workflows.'))
    if engine != 'CYCLES':
        pointiness_links = []
        for node in nt.nodes:
            if node.bl_idname != 'ShaderNodeNewGeometry':
                continue
            pointiness = core.socket_by_name(node.outputs, 'Pointiness')
            if pointiness is not None and getattr(pointiness, 'is_linked', False):
                pointiness_links.append(node.name)
        if pointiness_links:
            warnings.append(_lt('JP: Pointiness は現在のレンダーエンジンでは信頼性が低いため、Eevee では近似結果になる可能性があります。 / EN: Pointiness is not reliable in the current render engine, so Eevee may use only an approximate result.\n') + '\n'.join(pointiness_links[:8]))
    broken_groups = [node.name for node in nt.nodes if node.bl_idname == 'ShaderNodeGroup' and getattr(node, 'node_tree', None) is None]
    if broken_groups:
        errors.append(_lt('JP: 参照先を失ったノードグループがあります。 / EN: Some node groups lost their backing node tree.\n') + '\n'.join(broken_groups[:8]))
    connected = core.connected_nodes_from_all_outputs(nt)
    if not connected:
        connected = core.connected_nodes_from_output(nt, engine=engine)
    disconnected = [node.name for node in nt.nodes if node.bl_idname not in {'ShaderNodeOutputMaterial', 'NodeFrame'} and node not in connected]
    if disconnected:
        warnings.append(_lt('JP: どの マテリアル出力 にもつながっていない未使用ノードがあります。整理で削除候補になります。 / EN: Some nodes are disconnected from every Material Output branch and can be removed by cleanup.\n') + '\n'.join(disconnected[:8]))
    if len(nt.nodes) > 150:
        warnings.append(_lt('JP: ノード数が多く、管理が難しくなる可能性があります。 / EN: The material has a high node count and may be harder to maintain.'))
    builder = material.get('sss_builder', '')
    if core.is_cleanup_protected(material):
        reason = core.protection_reason(material)
        if reason:
            info.append(_lt(f'JP: 保護理由 = {reason} / EN: Protection reason = {reason}'))
    if builder:
        info.append(_lt(f'JP: スマートシェーダープリセット = {builder} / EN: Smart Shader preset = {builder}'))
    else:
        info.append(_lt('JP: スマートシェーダー管理外のマテリアルです。 / EN: This material is not yet managed by Smart Shader.'))
    return {'errors': errors, 'warnings': warnings, 'info': info}

def format_audit_report(material, context) -> str:
    data = audit_material(material, context)
    lines = ['Smart Shader Audit', '------------------------']
    lines.extend(data['info'])
    if data['errors']:
        lines.append('')
        lines.append(_lt('Errors / エラー:'))
        lines.extend((f'- {line}' for line in data['errors']))
    if data['warnings']:
        lines.append('')
        lines.append(_lt('Warnings / 注意:'))
        lines.extend((f'- {line}' for line in data['warnings']))
    if not data['errors'] and (not data['warnings']):
        lines.append('')
        lines.append(_lt('JP: 重大な問題は見つかりませんでした。 / EN: No major issues were found.'))
    return '\n'.join(lines)

def audit_library_text(context) -> str:
    managed = 0
    rebuildable = 0
    node_based = 0
    missing_texture_nodes = 0
    orphan_materials = 0
    total_images = 0
    texture_fix_candidates = 0
    protected = core.count_protected_datablocks()
    lines = ['Smart Shader Library Audit', '-------------------------------']
    world_state = environment.world_hdri_state(context)
    materials = [material for material in bpy.data.materials if material is not None]
    duplicate_groups = core.duplicate_material_groups(materials)
    for material in materials:
        if material.use_nodes and material.node_tree:
            node_based += 1
        if material.users == 0:
            orphan_materials += 1
        if material.get('sss_builder'):
            managed += 1
            if str(material.get('sss_builder', '')) in builders.BUILDERS:
                rebuildable += 1
        findings = textures.texture_audit_findings(material)
        if findings:
            texture_fix_candidates += len(findings)
        for node in core.iter_image_nodes(material):
            total_images += 1
            image = node.image
            try:
                raw = bpy.path.abspath(image.filepath)
            except Exception:
                raw = ''
            if raw and (not getattr(image, 'packed_file', None)) and (not Path(raw).exists()):
                missing_texture_nodes += 1
    duplicate_materials = sum((max(0, len(group) - 1) for group in duplicate_groups))
    lines.append(_lt(f'JP: 総マテリアル数 = {len(materials)} / EN: Total materials = {len(materials)}'))
    lines.append(_lt(f'JP: ノード材質数 = {node_based} / EN: Node-based materials = {node_based}'))
    lines.append(_lt(f'JP: 管理済み材質数 = {managed} / EN: Managed materials = {managed}'))
    lines.append(_lt(f'JP: 再構築可能な管理材質数 = {rebuildable} / EN: Rebuildable managed materials = {rebuildable}'))
    lines.append(_lt(f'JP: 未使用材質数 = {orphan_materials} / EN: Orphan materials = {orphan_materials}'))
    lines.append(_lt(f'JP: 重複グループ数 = {len(duplicate_groups)} / EN: Duplicate groups = {len(duplicate_groups)}'))
    lines.append(_lt(f'JP: 重複候補材質数 = {duplicate_materials} / EN: Duplicate material candidates = {duplicate_materials}'))
    lines.append(_lt(f'JP: 画像ノード総数 = {total_images} / EN: Total image nodes = {total_images}'))
    lines.append(_lt(f'JP: リンク切れ画像ノード数 = {missing_texture_nodes} / EN: Missing image nodes = {missing_texture_nodes}'))
    lines.append(_lt(f'JP: 色空間/透明設定の要確認項目 = {texture_fix_candidates} / EN: Texture color-space/transparency findings = {texture_fix_candidates}'))
    lines.append(_lt(f"JP: 保護マテリアル数 = {protected['materials']} / EN: Protected materials = {protected['materials']}"))
    lines.append(_lt(f"JP: 保護画像数 = {protected['images']} / EN: Protected images = {protected['images']}"))
    lines.append(_lt(f"JP: 保護ノードグループ数 = {protected['node_groups']} / EN: Protected node groups = {protected['node_groups']}"))
    lines.append(_lt(f"JP: ワールドHDRI状態 = {world_state['status_ja']} / EN: World HDRI status = {world_state['status_en']}"))
    return '\n'.join(lines)

def addon_integrity_report(context=None) -> dict:
    errors: list[str] = []
    warnings: list[str] = []
    info: list[str] = []
    builder_function_names = {getattr(func, '__name__', '') for func in builders.BUILDERS.values()}
    missing_preset_builders = sorted((preset_id for preset_id, meta in data.PRESET_LIBRARY.items() if preset_id not in builders.BUILDERS and str(meta.get('builder', '') or '') not in builder_function_names))
    missing_builder_meta = sorted((builder_id for builder_id in builders.BUILDERS.keys() if builder_id not in data.PRESET_LIBRARY))
    if missing_preset_builders:
        errors.append(_lt('JP: ビルダー未対応のプリセットがあります。 / EN: Some presets do not have matching builders.\n') + ', '.join(missing_preset_builders))
    else:
        info.append(_lt(f'JP: プリセット対応 = {len(data.PRESET_LIBRARY)} 件すべて整合 / EN: Preset coverage = all {len(data.PRESET_LIBRARY)} entries have builders'))
    if missing_builder_meta:
        warnings.append(_lt('JP: メタデータ未登録のビルダーがあります。 / EN: Some builders are missing metadata.\n') + ', '.join(missing_builder_meta[:12]))
    else:
        info.append(_lt(f'JP: ビルダーメタデータ整合 = {len(builders.BUILDERS)} / EN: Builder metadata parity = {len(builders.BUILDERS)}'))
    bilingual_missing: list[str] = []
    for preset_id, meta in data.PRESET_LIBRARY.items():
        for key in ('label_en', 'label_ja', 'summary_en', 'summary_ja', 'usage_en', 'usage_ja', 'controls_en', 'controls_ja'):
            if not str(meta.get(key, '') or '').strip():
                bilingual_missing.append(f'{preset_id}:{key}')
    if bilingual_missing:
        warnings.append(_lt('JP: 日英メタデータが空の項目があります。 / EN: Some bilingual metadata fields are empty.\n') + ', '.join(bilingual_missing[:14]))
    else:
        info.append(_lt('JP: 日英メタデータ完備 / EN: Bilingual metadata complete'))
    try:
        from . import operators as operators_module
        operator_names = {str(getattr(cls, 'bl_idname', '')).split('.', 1)[1] for cls in getattr(operators_module, 'CLASSES', ()) if str(getattr(cls, 'bl_idname', '')).startswith('sss.')}
        ordered_actions = list(getattr(data, 'quick_action_ids_in_order', lambda: list(getattr(data, 'QUICK_ACTION_ORDER', []) or []))())
        meta_actions = set(getattr(data, 'QUICK_ACTION_META', {}).keys())
        missing_actions = sorted((action_id for action_id, meta in data.QUICK_ACTION_META.items() if str(meta.get('operator', '') or '').strip() not in operator_names))
        ordered_missing_meta = sorted((action_id for action_id in ordered_actions if action_id not in meta_actions))
        meta_missing_order = sorted((action_id for action_id in meta_actions if action_id not in ordered_actions))
        if missing_actions:
            errors.append(_lt('JP: 対応オペレーターが見つからないクイック操作があります。 / EN: Some quick actions point to missing operators.\n') + ', '.join(missing_actions))
        else:
            info.append(_lt(f'JP: クイック操作整合 = {len(ordered_actions)} / EN: Quick-action mappings OK = {len(ordered_actions)}'))
        if ordered_missing_meta:
            errors.append(_lt('JP: 順序表にあるのにメタデータがないクイック操作があります。 / EN: Some quick actions are ordered but missing metadata.\n') + ', '.join(ordered_missing_meta))
        if meta_missing_order:
            info.append(_lt(f'JP: 自動補完されたクイック操作 = {len(meta_missing_order)} / EN: Auto-appended quick actions = {len(meta_missing_order)}'))
    except Exception as exc:
        warnings.append(_lt(f'JP: クイック操作整合の検査に失敗しました。 / EN: Failed to inspect quick-action mappings.'))
    try:
        layer_meta_missing = sorted((preset_id for preset_id in layers.SMART_LAYER_PRESET_ORDER if preset_id not in layers.SMART_LAYER_PRESET_META))
        if layer_meta_missing:
            errors.append(_lt('JP: メタデータ未登録のスマートレイヤーがあります。 / EN: Some smart-layer presets are missing metadata.\n') + ', '.join(layer_meta_missing))
        else:
            info.append(_lt(f'JP: スマートレイヤー整合 = {len(layers.SMART_LAYER_PRESET_ORDER)} / EN: Smart-layer metadata parity = {len(layers.SMART_LAYER_PRESET_ORDER)}'))
        info.append(_lt(f'JP: 保存済みカタログ数 = {catalog.catalog_count()} / EN: Saved catalog entries = {catalog.catalog_count()}'))
        layer_bilingual_missing: list[str] = []
        for preset_id, meta in layers.SMART_LAYER_PRESET_META.items():
            for key in ('label_en', 'label_ja', 'summary_en', 'summary_ja', 'usage_en', 'usage_ja', 'controls_en', 'controls_ja'):
                if not str(meta.get(key, '') or '').strip():
                    layer_bilingual_missing.append(f'{preset_id}:{key}')
        if layer_bilingual_missing:
            warnings.append(_lt('JP: スマートレイヤーの日英メタデータが空の項目があります。 / EN: Some smart-layer bilingual metadata fields are empty.\n') + ', '.join(layer_bilingual_missing[:14]))
        recipe_library = layers.list_layer_recipes()
        info.append(_lt(f'JP: 保存済みレイヤーレシピ数 = {len(recipe_library)} / EN: Saved layer recipes = {len(recipe_library)}'))
        info.append(_lt(f'JP: 保存済み割当ルール数 = {len(rules.list_assignment_rules())} / EN: Saved assignment rules = {len(rules.list_assignment_rules())}'))
        info.append(_lt(f'JP: シーン材質インデックス件数 = {len(inventory.list_inventory_entries())} / EN: Scene Material Index entries = {len(inventory.list_inventory_entries())}'))
    except Exception as exc:
        warnings.append(_lt(f'JP: スマートレイヤー整合の検査に失敗しました。 / EN: Failed to inspect smart-layer integrity.'))
    try:
        readme_text = core.read_bundled_text('readme.md')
        manifest_text = core.read_bundled_text('blender_manifest.toml')
        readme_ok = data.ADDON_VERSION in readme_text
        manifest_ok = f'version = "{data.ADDON_VERSION}"' in manifest_text
        if not readme_ok or not manifest_ok:
            warnings.append(_lt('JP: 同梱ドキュメントの版数表記にずれがあります。 / EN: Bundled document version strings are out of sync.'))
        else:
            info.append(_lt(f'JP: 版数表記整合 = {data.ADDON_VERSION} / EN: Version strings aligned = {data.ADDON_VERSION}'))
    except Exception as exc:
        warnings.append(_lt(f'JP: 版数表記整合の検査に失敗しました。 / EN: Failed to inspect bundled version strings.'))
    try:
        info.append(_lt(f'JP: バンドル保管先 = {bundle.bundle_extract_root()} / EN: Bundle storage root = {bundle.bundle_extract_root()}'))
    except Exception as exc:
        warnings.append(_lt(f'JP: バンドル保管先の確認に失敗しました。 / EN: Failed to inspect bundle storage root.'))
    try:
        search_samples = {'archviz concrete': [item.get('kind') for item in finder.list_asset_search_results('archviz concrete', limit=3)], 'anime toon': [item.get('kind') for item in finder.list_asset_search_results('anime toon', limit=3)], 'rust worn metal': [item.get('kind') for item in finder.list_asset_search_results('rust worn metal', limit=3)]}
        info.append(_lt(f'JP: スマート検索サンプル = {len(search_samples)} / EN: Smart-search samples = {len(search_samples)}'))
    except Exception as exc:
        warnings.append(_lt(f'JP: スマート検索サンプル検査に失敗しました。 / EN: Failed to run smart-search samples.'))
    try:
        samples = {'ARM.png': textures.guess_usage_from_text('ARM.png'), 'curvature.exr': textures.guess_usage_from_text('curvature.exr'), 'thickness.exr': textures.guess_usage_from_text('thickness.exr'), 'coatRoughness.png': textures.guess_usage_from_text('coatRoughness.png'), 'worldNormal.exr': textures.guess_usage_from_text('worldNormal.exr'), 'position.exr': textures.guess_usage_from_text('position.exr')}
        info.append(_lt(f'JP: テクスチャ検出サンプル = {len(samples)} / EN: Texture-detection samples = {len(samples)}'))
    except Exception as exc:
        warnings.append(_lt(f'JP: テクスチャ検出サンプル検査に失敗しました。 / EN: Failed to run texture-detection samples.'))
    return {'errors': errors, 'warnings': warnings, 'info': info}
