# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations
from pathlib import Path
from typing import Iterable
import math
import bpy
from bpy.types import PropertyGroup, UIList
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, IntProperty, StringProperty, PointerProperty
try:
    import gpu
    import blf
    from gpu_extras.batch import batch_for_shader
except Exception:  # pragma: no cover - Blender runtime only
    gpu = None
    blf = None
    batch_for_shader = None
from . import data, report_safety, storage
from .translation import tx, loc_text as _lt
from .translation import exc_text as _exc_text

_PREVIEW_COLLECTION = None
_PREVIEW_COLLECTION_KEY = None
_PREVIEW_ENUM_ITEMS_MAIN: list[tuple] = []
_PREVIEW_ENUM_ITEMS_PBR: list[tuple] = []
_PREVIEW_ENUM_KEY_MAIN = None
_PREVIEW_ENUM_KEY_PBR = None
_PREVIEW_UPDATE_GUARD = False
_PREVIEW_ROOTS_CACHE: tuple[Path, ...] | None = None
_GRID_UPDATE_GUARD = False
_GRID_SIGNATURES: dict[str, tuple] = {}
_TEXTURE_UPDATE_GUARD = False
_TEXTURE_PREFIX = "SSS_PREVIEW_TILE__"
_IMAGE_PREFIX = "SSS_PREVIEW_IMAGE__"
_ACTIVE_MODAL_STATE = None
_MODAL_DRAW_HANDLERS: list[tuple[object, str, object]] = []
_GPU_TEXTURE_CACHE: dict[str, object] = {}
_COLOR_SHADER = None
_IMAGE_SHADER = None
_MANAGER_RUNTIME_API_KEY = 'JELARARAGI_SMART_TOOLS_MANAGER_RUNTIME_API_V1'

_PBR_PREVIEW_TARGETS = {'PBR', 'PBR_FX', 'SMART_TOON_PBR_BASE'}


def workspace_runtime_allowed(context=None) -> bool:
    """Accept OFF only from the active Manager generation's workspace OR."""
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if not isinstance(namespace, dict):
            return True
        record = namespace.get(_MANAGER_RUNTIME_API_KEY)
        if not (
            isinstance(record, dict)
            and record.get('schema') == 1
            and record.get('package_id') == 'smart_tools_manager'
            and record.get('status') == 'ACTIVE'
        ):
            return True
        generation = record.get('generation')
        revision = record.get('revision')
        public_api = record.get('public_api')
        if not (
            isinstance(generation, str)
            and bool(generation.strip())
            and type(revision) is int
            and revision >= 0
            and isinstance(public_api, dict)
        ):
            return True
        allowed_fn = public_api.get('workspace_tool_allowed')
        if not callable(allowed_fn):
            return True
        value = allowed_fn('SMART_SHADER', context)
        current_namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if current_namespace is not namespace:
            return True
        current = current_namespace.get(_MANAGER_RUNTIME_API_KEY)
        if not (
            current is record
            and current.get('schema') == 1
            and current.get('package_id') == 'smart_tools_manager'
            and current.get('status') == 'ACTIVE'
            and current.get('generation') == generation
            and current.get('revision') == revision
            and current.get('public_api') is public_api
            and public_api.get('workspace_tool_allowed') is allowed_fn
        ):
            return True
        return value if type(value) is bool else True
    except Exception:
        return True


def _is_pbr_preview_target(target: str) -> bool:
    return str(target or '').upper() in _PBR_PREVIEW_TARGETS



# The current popup uses direct operator buttons.  These legacy collection/UIList
# classes are intentionally not registered because Blender 5.1.0 exposes only
# older Blender list modes cannot draw preview grids safely.
CLASSES = tuple()

def preview_root() -> Path:
    """Return the non-creating writable root used by newly rendered previews."""
    return storage.preset_previews_dir(create=False)


def bundled_preview_root() -> Path:
    """Return the read-only directory containing previews shipped in the ZIP."""
    return storage.bundled_preset_previews_dir()


def preview_roots() -> list[Path]:
    """Return all locations that may contain Smart Shader preset preview PNGs.

    Results are cached because this function is used while building hundreds of
    preview entries.  Paths are normalized without resolving missing directories,
    avoiding slow filesystem probes on Windows profile / OneDrive environments.
    """
    global _PREVIEW_ROOTS_CACHE
    if _PREVIEW_ROOTS_CACHE is not None:
        return list(_PREVIEW_ROOTS_CACHE)

    roots: list[Path] = []

    def add(path) -> None:
        try:
            candidate = Path(path).expanduser().absolute()
        except Exception:
            return
        if candidate not in roots:
            roots.append(candidate)

    # Prefer user-generated previews, then fall back to the immutable images
    # bundled in the Extension.  Merely drawing the N-panel never creates the
    # CONFIG directory.
    add(storage.preset_previews_dir(create=False))
    add(bundled_preview_root())

    # Construct standard Blender user paths from resource_path('USER') instead of
    # repeatedly asking user_resource() while enum callbacks are running.
    try:
        user_root = Path(bpy.utils.resource_path('USER')).expanduser().absolute()
        add(user_root / "extensions" / "user_default" / "smart_shader_suite" / "preset_previews")
        add(user_root / "scripts" / "addons" / "smart_shader_suite" / "preset_previews")
    except Exception:
        pass

    _PREVIEW_ROOTS_CACHE = tuple(roots)
    return list(_PREVIEW_ROOTS_CACHE)

def preview_source_ids(preset_id: str) -> tuple[str, ...]:
    """Return preview filename candidates for a preset.

    Prefer a PNG named after the actual preset id.  This fixes genre-expansion
    preview packs that render every preset under its own id, while preserving
    compatibility with older packs that reused ``preview_id`` / ``preview_alias``
    files.
    """
    preset_id = str(preset_id or '').strip()
    ids: list[str] = []
    if preset_id:
        ids.append(preset_id)
    try:
        meta = data.PRESET_LIBRARY.get(preset_id) or {}
        for key in ('preview_id', 'preview_alias'):
            alias = str(meta.get(key) or '').strip()
            if alias and alias not in ids:
                ids.append(alias)
    except Exception:
        pass
    return tuple(ids)


def preview_source_id(preset_id: str) -> str:
    ids = preview_source_ids(preset_id)
    return ids[0] if ids else str(preset_id or '').strip()


def preview_path(preset_id: str) -> Path:
    ids = preview_source_ids(preset_id)
    roots = preview_roots()
    for source_id in ids:
        for root in roots:
            path = root / f"{source_id}.png"
            if path.exists():
                return path
    # Missing previews point at their future writable CONFIG destination, never
    # at the installed package directory.
    root = preview_root()
    fallback = ids[0] if ids else str(preset_id or '').strip()
    return root / f"{fallback}.png"

def _safe_mtime(path: Path) -> float:
    try: return float(path.stat().st_mtime)
    except Exception: return 0.0

def _available_preview_signature() -> tuple[tuple[str, str, str, float], ...]:
    pairs=[]
    try:
        for preset_id in data.PRESET_LIBRARY.keys():
            path = preview_path(preset_id)
            if path.exists():
                pairs.append((preset_id, path.stem, str(path), _safe_mtime(path)))
    except Exception:
        return tuple()
    return tuple(pairs)

def _remove_collection() -> None:
    global _PREVIEW_COLLECTION
    pcoll=_PREVIEW_COLLECTION
    _PREVIEW_COLLECTION=None
    if pcoll is not None:
        try:
            import bpy.utils.previews
            bpy.utils.previews.remove(pcoll)
        except Exception:
            pass

def _ensure_collection():
    global _PREVIEW_COLLECTION, _PREVIEW_COLLECTION_KEY
    sig=_available_preview_signature()
    key=(len(data.PRESET_LIBRARY), sig)
    if _PREVIEW_COLLECTION is not None and _PREVIEW_COLLECTION_KEY == key:
        return _PREVIEW_COLLECTION
    _remove_collection()
    try:
        import bpy.utils.previews
        pcoll=bpy.utils.previews.new()
    except Exception:
        _PREVIEW_COLLECTION_KEY=key
        return None
    for preset_id, _source_id, path, _mtime in sig:
        try: pcoll.load(preset_id, str(path), 'IMAGE')
        except Exception: pass
    _PREVIEW_COLLECTION=pcoll
    _PREVIEW_COLLECTION_KEY=key
    return pcoll

def clear_preview_cache() -> None:
    close_modal_preview_picker(None)
    global _PREVIEW_COLLECTION_KEY, _PREVIEW_ENUM_KEY_MAIN, _PREVIEW_ENUM_KEY_PBR, _PREVIEW_ROOTS_CACHE, _GRID_SIGNATURES
    _remove_collection()
    _PREVIEW_COLLECTION_KEY=None
    _PREVIEW_ENUM_KEY_MAIN=None
    _PREVIEW_ENUM_KEY_PBR=None
    _PREVIEW_ROOTS_CACHE=None
    _GRID_SIGNATURES.clear()

def icon_value_for_preset(preset_id: str) -> int:
    preset_id=str(preset_id or '').strip()
    if not preset_id: return 0
    pcoll=_ensure_collection()
    if pcoll is None: return 0
    try: return int(getattr(pcoll.get(preset_id), 'icon_id', 0) or 0)
    except Exception: return 0

def _label(scene, meta: dict, preset_id: str) -> str:
    return tx(scene, meta.get('label_en', preset_id), meta.get('label_ja', preset_id))

def _summary(scene, meta: dict) -> str:
    return tx(scene, meta.get('summary_en', ''), meta.get('summary_ja', ''))

def _preset_genre(meta: dict, preset_id: str) -> str:
    try:
        genre = str(meta.get('genre') or meta.get('style_genre') or '').strip().upper()
        if genre:
            return genre
    except Exception:
        pass
    try:
        infer = getattr(data, 'infer_preset_genre', None)
        if callable(infer):
            value = str(infer(preset_id, meta) or '').strip().upper()
            if value:
                return value
    except Exception:
        pass
    return 'GENERAL'


def sorted_builtin_entries(scene=None, *, family_filter: Iterable[str] | None = None, genre_filter: Iterable[str] | None = None) -> list[dict[str, object]]:
    families={str(f) for f in family_filter} if family_filter else None
    genres={str(g).upper() for g in genre_filter if str(g).upper() not in {'', 'ALL'}} if genre_filter else None
    entries=[]
    for preset_id, meta in data.PRESET_LIBRARY.items():
        family=str(meta.get('family', '') or '')
        if families is not None and family not in families: continue
        genre=_preset_genre(meta, preset_id)
        if genres is not None and genre not in genres: continue
        label=_label(scene, meta, preset_id)
        entries.append({'id':preset_id,'family':family,'genre':genre,'label':label,'summary':_summary(scene, meta),'compat':str(meta.get('compat','') or ''),'tags':tuple(meta.get('tags',[]) or ()), 'has_preview':preview_path(preset_id).exists(), 'sort_key':(genre,family,label.lower(),preset_id.lower())})
    entries.sort(key=lambda item: item.get('sort_key', ('','','','')))
    return entries

def select_preset(scene, preset_id: str, *, target: str='MAIN') -> bool:
    preset_id=str(preset_id or '').strip()
    meta=data.PRESET_LIBRARY.get(preset_id)
    if scene is None or not meta: return False
    family=str(meta.get('family','PBR') or 'PBR')
    target=str(target or 'MAIN').upper()
    # Store the new enum identifiers in raw IDProperty first.  Setting the family
    # enum fires update callbacks that read the current preset enum; without this
    # guard, old saved numeric values such as 133 can trigger Blender 5.1 enum
    # warnings before the visible field is updated.
    try:
        if family in {'PBR','STYLIZED','FX'}:
            scene['sss_preset_name'] = preset_id
            if _is_pbr_preview_target(target):
                scene['sss_pbr_preset_name'] = preset_id
    except Exception:
        pass
    try:
        if family in {'PBR','STYLIZED','FX'}:
            scene.sss_preset_search=''
            scene.sss_preset_family=family
            scene.sss_preset_name=preset_id
    except Exception: pass
    if _is_pbr_preview_target(target) and family in {'PBR','FX','STYLIZED'}:
        try:
            scene.sss_preset_search=''
            scene.sss_pbr_preset_family=family
            scene.sss_pbr_preset_name=preset_id
        except Exception: pass
    return True



def select_or_generate_preset(context, preset_id: str, *, target: str='MAIN', generate: bool=False) -> tuple[bool, object | None, int]:
    """Select a preview preset and optionally create the material immediately.

    This helper is used by both native popup buttons and the custom image-button
    picker.  Calling the operator again from a modal draw/click handler can lose
    the original context after full-area restore, so material creation is handled
    directly here with a late import of operators.py.
    """
    scene = getattr(context, 'scene', None) if context is not None else None
    preset_id = str(preset_id or '').strip()
    if not preset_id:
        return (False, None, 0)
    if not select_preset(scene, preset_id, target=target):
        return (False, None, 0)
    if str(target or '').upper() == 'SMART_TOON_PBR_BASE':
        try:
            from . import smart_toon as _smart_toon
            material = _smart_toon._active_material(context)
            if material is None or not _smart_toon._smart_toon_is_pbr_preset_id(preset_id):
                return (False, None, 0)
            _smart_toon._smart_toon_set_material_to_pbr_base(material, preset_id, mark_toon=True)
            _smart_toon.rebuild_toon_material(material)
            return (True, material, 0)
        except Exception:
            raise
    if not bool(generate):
        return (True, None, 0)
    try:
        from . import operators as _sss_ops
        material = _sss_ops.create_builtin_material_from_preset_id(context, preset_id)
        assigned = _sss_ops.finish_created_preset_material(
            context,
            material,
            report_title_en='Preset look material created from preview.',
            report_title_ja='プレビューからプリセットルックマテリアルを作成しました。',
        )
        return (True, material, int(assigned or 0))
    except Exception:
        raise

def preset_label(scene, preset_id: str) -> str:
    preset_id=str(preset_id or '').strip()
    meta=data.PRESET_LIBRARY.get(preset_id) or {}
    return _label(scene, meta, preset_id) if meta else preset_id


def _tooltip_for_entry(scene, entry: dict[str, object]) -> str:
    label = str(entry.get('label') or entry.get('id') or '')
    summary = str(entry.get('summary') or '').replace('\n', ' ').strip()
    if summary:
        return tx(scene, f"Name: {label}\nSummary: {summary}", _lt(f"名前: {label}\n概要: {summary}"))
    return tx(scene, f"Name: {label}", _lt(f"名前: {label}"))


def _enum_signature(scene=None, *, family_filter: Iterable[str] | None = None) -> tuple:
    families = tuple(sorted(str(f) for f in family_filter)) if family_filter else tuple()
    try:
        preview_sig = _available_preview_signature()
    except Exception:
        preview_sig = tuple()
    lang = 'ja' if tx(scene, 'en', 'ja') == 'ja' else 'en'
    return (len(data.PRESET_LIBRARY), families, preview_sig, lang)


def _enum_items_for(scene=None, *, family_filter: Iterable[str] | None = None, target: str = 'MAIN') -> list[tuple]:
    entries = sorted_builtin_entries(scene, family_filter=family_filter)
    items: list[tuple] = []
    for index, entry in enumerate(entries, start=1):
        preset_id = str(entry.get('id') or '')
        if not preset_id:
            continue
        label = str(entry.get('label') or preset_id)
        desc = _tooltip_for_entry(scene, entry)
        # These enum properties are retained only for backward compatibility with
        # older saved UI state.  The current popup draws a direct operator grid, so
        # avoid loading preview collections during add-on registration.
        icon_id = 0
        # Number values must stay positive and stable enough for Blender's icon view.
        items.append((preset_id, label, desc, icon_id, index))
    if not items:
        empty_id = 'NO_PRESET_PREVIEW_ITEMS'
        empty_name = tx(scene, 'No preview presets', _lt('プレビュープリセットなし'))
        empty_desc = tx(scene, 'No matching preset previews are available.', _lt('条件に合うプリセットプレビューがありません。'))
        items.append((empty_id, empty_name, empty_desc, 0, 1))
    return items


def preview_enum_items_main(self, context):
    global _PREVIEW_ENUM_ITEMS_MAIN, _PREVIEW_ENUM_KEY_MAIN
    scene = getattr(context, 'scene', None) if context is not None else None
    key = _enum_signature(scene, family_filter=None)
    if _PREVIEW_ENUM_KEY_MAIN != key:
        _PREVIEW_ENUM_ITEMS_MAIN = _enum_items_for(scene, family_filter=None, target='MAIN')
        _PREVIEW_ENUM_KEY_MAIN = key
    return _PREVIEW_ENUM_ITEMS_MAIN


def preview_enum_items_pbr(self, context):
    global _PREVIEW_ENUM_ITEMS_PBR, _PREVIEW_ENUM_KEY_PBR
    scene = getattr(context, 'scene', None) if context is not None else None
    key = _enum_signature(scene, family_filter={'PBR', 'STYLIZED', 'FX'})
    if _PREVIEW_ENUM_KEY_PBR != key:
        _PREVIEW_ENUM_ITEMS_PBR = _enum_items_for(scene, family_filter={'PBR', 'STYLIZED', 'FX'}, target='PBR')
        _PREVIEW_ENUM_KEY_PBR = key
    return _PREVIEW_ENUM_ITEMS_PBR


def _safe_select_from_preview_property(context, value: str, *, target: str) -> None:
    global _PREVIEW_UPDATE_GUARD
    value = str(value or '').strip()
    if not value or value == 'NO_PRESET_PREVIEW_ITEMS' or _PREVIEW_UPDATE_GUARD:
        return
    scene = getattr(context, 'scene', None) if context is not None else None
    if scene is None:
        return
    _PREVIEW_UPDATE_GUARD = True
    try:
        select_preset(scene, value, target=target)
    except Exception:
        pass
    finally:
        _PREVIEW_UPDATE_GUARD = False


def _update_preview_choice_main(self, context):
    try:
        _safe_select_from_preview_property(context, getattr(self, 'sss_preset_preview_popup_main', ''), target='MAIN')
    except Exception:
        pass


def _update_preview_choice_pbr(self, context):
    try:
        _safe_select_from_preview_property(context, getattr(self, 'sss_preset_preview_popup_pbr', ''), target='PBR')
    except Exception:
        pass


def _default_preview_id(*, family_filter: Iterable[str] | None = None) -> str:
    try:
        entries = sorted_builtin_entries(None, family_filter=family_filter)
        for entry in entries:
            preset_id = str(entry.get('id') or '').strip()
            if preset_id:
                return preset_id
    except Exception:
        pass
    return 'NO_PRESET_PREVIEW_ITEMS'


def sync_preview_choice(context, *, target: str = 'MAIN') -> None:
    """Compatibility no-op for older callers.

    Older builds used WindowManager EnumProperty icon views for the preview
    picker. Blender 5.1.0 reports stale enum values such as ``0`` during file
    load and the current picker no longer needs these properties, so this
    function intentionally avoids touching any RNA enum state.
    """
    return

def _entry_matches_search(entry: dict[str, object], query: str) -> bool:
    query = str(query or '').strip().lower()
    if not query:
        return True
    haystack = ' '.join([
        str(entry.get('id') or ''),
        str(entry.get('label') or ''),
        str(entry.get('summary') or ''),
        str(entry.get('family') or ''),
        str(entry.get('genre') or ''),
        ' '.join(str(t) for t in (entry.get('tags') or ())),
    ]).lower()
    return query in haystack


def _entries_for_target(scene, *, target: str = 'MAIN', use_scene_filters: bool = False) -> list[dict[str, object]]:
    target = str(target or 'MAIN').upper()

    # The preview-image popup is primarily a visual catalog.  It must open as a
    # complete thumbnail grid even if the current dropdown category is CUSTOM, a
    # genre has no matches, or a previous search string filters every item out.
    if not use_scene_filters:
        family_filter = {'PBR', 'STYLIZED', 'FX'} if _is_pbr_preview_target(target) else None
        return sorted_builtin_entries(scene, family_filter=family_filter, genre_filter=None)

    if _is_pbr_preview_target(target):
        family = str(getattr(scene, 'sss_pbr_preset_family', '') or '').strip() if scene is not None else ''
        family_filter = {family} if family in {'PBR', 'STYLIZED', 'FX'} else {'PBR', 'STYLIZED', 'FX'}
        genre = str(getattr(scene, 'sss_pbr_preset_genre', 'ALL') or 'ALL') if scene is not None else 'ALL'
        entries = sorted_builtin_entries(scene, family_filter=family_filter, genre_filter={genre})
    else:
        family = str(getattr(scene, 'sss_preset_family', '') or '').strip() if scene is not None else ''
        family_filter = {family} if family in {'PBR', 'STYLIZED', 'FX'} else None
        genre = str(getattr(scene, 'sss_preset_genre', 'ALL') or 'ALL') if scene is not None else 'ALL'
        entries = sorted_builtin_entries(scene, family_filter=family_filter, genre_filter={genre})
    query = str(getattr(scene, 'sss_preset_search', '') or '') if scene is not None else ''
    filtered = [entry for entry in entries if _entry_matches_search(entry, query)]
    if filtered:
        return filtered
    # Last-resort fallback prevents the popup from becoming empty after stale
    # saved enum/search state from older versions.
    family_filter = {'PBR', 'STYLIZED', 'FX'} if _is_pbr_preview_target(target) else None
    return sorted_builtin_entries(scene, family_filter=family_filter, genre_filter=None)


def _grid_names(target: str):
    target = str(target or 'MAIN').upper()
    return ('sss_preset_preview_grid_pbr','sss_preset_preview_grid_index_pbr','PBR') if _is_pbr_preview_target(target) else ('sss_preset_preview_grid_main','sss_preset_preview_grid_index_main','MAIN')


def _preview_entries(context, *, target: str = 'MAIN') -> list[dict]:
    scene = getattr(context, 'scene', None) if context is not None else None
    normalized = 'PBR' if _is_pbr_preview_target(target) else 'MAIN'
    try:
        return list(_entries_for_target(scene, target=normalized, use_scene_filters=False))
    except TypeError:
        try:
            return list(_entries_for_target(scene, target=normalized))
        except Exception:
            return []
    except Exception:
        return []


def _safe_data_collection(name: str):
    try:
        return getattr(bpy.data, name)
    except Exception:
        return None


def _preview_texture_name(preset_id: str) -> str:
    return f"{_TEXTURE_PREFIX}{str(preset_id or '').strip()}"


def _preview_image_name(preset_id: str) -> str:
    return f"{_IMAGE_PREFIX}{str(preset_id or '').strip()}"


def _load_preview_image_datablock(preset_id: str):
    preset_id = str(preset_id or '').strip()
    if not preset_id:
        return None
    path = preview_path(preset_id)
    if not path.exists():
        return None
    images = _safe_data_collection('images')
    if images is None:
        return None
    image_name = _preview_image_name(preset_id)
    img = images.get(image_name)
    if img is None:
        try:
            img = images.load(str(path), check_existing=True)
        except Exception:
            return None
        try:
            img.name = image_name
        except Exception:
            pass
    try:
        img.filepath = str(path)
        img['sss_preset_id'] = preset_id
        img['sss_preset_preview'] = True
        img.use_fake_user = False
    except Exception:
        pass
    return img


def _get_or_create_preview_texture(preset_id: str):
    """Return a temporary IMAGE Texture datablock for a preset preview.

    Blender 5.1 operator buttons draw custom ``icon_value`` thumbnails as small
    native UI icons.  ``legacy ID preview selector`` draws Texture previews as real
    square image tiles, so the popup uses temporary legacy image textures for the
    visual selector.  They are cleaned during unregister and are not fake-user
    saved.
    """
    preset_id = str(preset_id or '').strip()
    if not preset_id:
        return None
    textures = _safe_data_collection('textures')
    if textures is None:
        return None
    img = _load_preview_image_datablock(preset_id)
    if img is None:
        return None
    tex_name = _preview_texture_name(preset_id)
    tex = textures.get(tex_name)
    if tex is None:
        try:
            tex = textures.new(tex_name, type='IMAGE')
        except Exception:
            return None
    try:
        tex.image = img
        tex['sss_preset_id'] = preset_id
        tex['sss_preset_preview'] = True
        tex.use_fake_user = False
    except Exception:
        pass
    return tex


def _cleanup_preview_textures(valid_ids: set[str] | None = None) -> None:
    textures = _safe_data_collection('textures')
    images = _safe_data_collection('images')
    valid_tex = {_preview_texture_name(pid) for pid in (valid_ids or set())}
    valid_img = {_preview_image_name(pid) for pid in (valid_ids or set())}
    if textures is not None:
        for tex in list(textures):
            try:
                name = str(getattr(tex, 'name', '') or '')
                marked = bool(tex.get('sss_preset_preview', False)) if hasattr(tex, 'get') else False
                if (name.startswith(_TEXTURE_PREFIX) or marked) and (valid_ids is None or name not in valid_tex):
                    textures.remove(tex)
            except Exception:
                pass
    if images is not None:
        for img in list(images):
            try:
                name = str(getattr(img, 'name', '') or '')
                marked = bool(img.get('sss_preset_preview', False)) if hasattr(img, 'get') else False
                if (name.startswith(_IMAGE_PREFIX) or marked) and (valid_ids is None or name not in valid_img) and getattr(img, 'users', 0) <= 0:
                    images.remove(img)
            except Exception:
                pass


def _preview_texture_update(self, context):
    global _TEXTURE_UPDATE_GUARD
    if _TEXTURE_UPDATE_GUARD:
        return
    wm = getattr(context, 'window_manager', None) if context is not None else None
    scene = getattr(context, 'scene', None) if context is not None else None
    if wm is None:
        return
    tex = getattr(wm, 'sss_preset_preview_texture', None)
    if tex is None:
        return
    try:
        preset_id = str(tex.get('sss_preset_id', '') or '').strip()
    except Exception:
        preset_id = ''
    if not preset_id or preset_id not in data.PRESET_LIBRARY:
        return
    target = str(getattr(wm, 'sss_preset_preview_target', 'MAIN') or 'MAIN').upper()
    generate = bool(getattr(wm, 'sss_preset_preview_generate', False))
    _TEXTURE_UPDATE_GUARD = True
    try:
        select_or_generate_preset(context, preset_id, target=target, generate=generate)
    finally:
        _TEXTURE_UPDATE_GUARD = False


def _set_preview_texture_selection(context, preset_id: str | None) -> None:
    global _TEXTURE_UPDATE_GUARD
    wm = getattr(context, 'window_manager', None) if context is not None else None
    if wm is None or not hasattr(wm, 'sss_preset_preview_texture'):
        return
    tex = _get_or_create_preview_texture(preset_id or '') if preset_id else None
    _TEXTURE_UPDATE_GUARD = True
    try:
        try:
            wm.sss_preset_preview_texture = tex
        except Exception:
            pass
    finally:
        _TEXTURE_UPDATE_GUARD = False


def _prepare_preview_texture_grid(context, *, target: str = 'MAIN', generate: bool = False) -> int:
    wm = getattr(context, 'window_manager', None) if context is not None else None
    scene = getattr(context, 'scene', None) if context is not None else None
    normalized = 'PBR' if _is_pbr_preview_target(target) else 'MAIN'
    target_upper = str(target or '').upper()
    entries = _preview_entries(context, target=normalized)
    valid_ids = {str(entry.get('id') or '').strip() for entry in entries if str(entry.get('id') or '').strip()}
    _cleanup_preview_textures(valid_ids)
    if wm is not None:
        try:
            wm.sss_preset_preview_target = target_upper if target_upper == 'SMART_TOON_PBR_BASE' else normalized
            wm.sss_preset_preview_generate = bool(generate)
        except Exception:
            pass
    first_id = ''
    current_id = ''
    try:
        current_id = str(getattr(scene, 'sss_pbr_preset_name' if normalized == 'PBR' else 'sss_preset_name', '') or '').strip()
    except Exception:
        current_id = ''
    for entry in entries:
        preset_id = str(entry.get('id') or '').strip()
        if not preset_id:
            continue
        tex = _get_or_create_preview_texture(preset_id)
        if tex is not None and not first_id:
            first_id = preset_id
    # In generate mode, leave the selector unselected so clicking the first tile
    # also triggers an update.  For selection-only mode, keep the current preset
    # highlighted if possible.
    if generate:
        _set_preview_texture_selection(context, None)
    else:
        _set_preview_texture_selection(context, current_id if current_id in data.PRESET_LIBRARY else first_id)
    return len(entries)


def prepare_preview_grid(context, *, target: str='MAIN', generate: bool=False, force: bool=False) -> int:
    normalized = 'PBR' if _is_pbr_preview_target(target) else 'MAIN'
    try:
        if hasattr(bpy.types.WindowManager, 'sss_preset_preview_texture'):
            return _prepare_preview_texture_grid(context, target=target if str(target or '').upper() == 'SMART_TOON_PBR_BASE' else normalized, generate=generate)
    except Exception:
        pass
    return len(_preview_entries(context, target=normalized))





def _space_class_for_area(area_type: str):
    mapping = {
        'VIEW_3D': getattr(bpy.types, 'SpaceView3D', None),
        'IMAGE_EDITOR': getattr(bpy.types, 'SpaceImageEditor', None),
        'NODE_EDITOR': getattr(bpy.types, 'SpaceNodeEditor', None),
        'SEQUENCE_EDITOR': getattr(bpy.types, 'SpaceSequenceEditor', None),
        'CLIP_EDITOR': getattr(bpy.types, 'SpaceClipEditor', None),
        'DOPESHEET_EDITOR': getattr(bpy.types, 'SpaceDopeSheetEditor', None),
        'GRAPH_EDITOR': getattr(bpy.types, 'SpaceGraphEditor', None),
        'NLA_EDITOR': getattr(bpy.types, 'SpaceNLA', None),
        'TEXT_EDITOR': getattr(bpy.types, 'SpaceTextEditor', None),
        'FILE_BROWSER': getattr(bpy.types, 'SpaceFileBrowser', None),
        'SPREADSHEET': getattr(bpy.types, 'SpaceSpreadsheet', None),
        'PROPERTIES': getattr(bpy.types, 'SpaceProperties', None),
        'OUTLINER': getattr(bpy.types, 'SpaceOutliner', None),
    }
    return mapping.get(str(area_type or ''), None)


def _window_region_for_area(area):
    try:
        for region in area.regions:
            if getattr(region, 'type', '') == 'WINDOW':
                return region
    except Exception:
        pass
    return None


def _area_pointer(area) -> int:
    try:
        return int(area.as_pointer())
    except Exception:
        return 0


def _ui_scale(context=None) -> float:
    try:
        prefs = bpy.context.preferences if context is None else context.preferences
        return max(0.75, min(2.5, float(getattr(getattr(prefs, 'system', None), 'ui_scale', 1.0) or 1.0)))
    except Exception:
        return 1.0


def _shader_color():
    global _COLOR_SHADER
    if gpu is None:
        return None
    if _COLOR_SHADER is None:
        try:
            _COLOR_SHADER = gpu.shader.from_builtin('UNIFORM_COLOR')
        except Exception:
            _COLOR_SHADER = None
    return _COLOR_SHADER


def _shader_image():
    global _IMAGE_SHADER
    if gpu is None:
        return None
    if _IMAGE_SHADER is None:
        try:
            _IMAGE_SHADER = gpu.shader.from_builtin('IMAGE')
        except Exception:
            _IMAGE_SHADER = None
    return _IMAGE_SHADER


def _draw_rect(x: float, y: float, w: float, h: float, color: tuple[float, float, float, float]) -> None:
    if gpu is None or batch_for_shader is None:
        return
    shader = _shader_color()
    if shader is None:
        return
    try:
        batch = batch_for_shader(shader, 'TRI_FAN', {'pos': ((x, y), (x + w, y), (x + w, y + h), (x, y + h))})
        shader.bind()
        shader.uniform_float('color', color)
        batch.draw(shader)
    except Exception:
        pass


def _draw_border(x: float, y: float, w: float, h: float, color: tuple[float, float, float, float], thickness: float = 1.0) -> None:
    t = max(1.0, float(thickness or 1.0))
    _draw_rect(x, y, w, t, color)
    _draw_rect(x, y + h - t, w, t, color)
    _draw_rect(x, y, t, h, color)
    _draw_rect(x + w - t, y, t, h, color)


def _draw_line(x1: float, y1: float, x2: float, y2: float, color: tuple[float, float, float, float], thickness: float = 1.0) -> None:
    """Draw a simple overlay line in region-local coordinates.

    The preview picker's close mark uses this instead of a BLF text glyph.
    Blender 5.1 can place the baseline of the unicode multiplication sign
    slightly above the button rectangle on some UI/font-scale combinations,
    which makes the close icon look clipped.  Vector lines are independent of
    font metrics and therefore stay centered inside the square button.
    """
    if gpu is None or batch_for_shader is None:
        return
    shader = _shader_color()
    if shader is None:
        return
    try:
        try:
            gpu.state.line_width_set(max(1.0, float(thickness or 1.0)))
        except Exception:
            pass
        batch = batch_for_shader(shader, 'LINES', {'pos': ((x1, y1), (x2, y2))})
        shader.bind()
        shader.uniform_float('color', color)
        batch.draw(shader)
    except Exception:
        pass
    finally:
        try:
            gpu.state.line_width_set(1.0)
        except Exception:
            pass


def _draw_text(text: str, x: float, y: float, size: int = 12, color: tuple[float, float, float, float] = (1, 1, 1, 1), *, max_width: float | None = None) -> float:
    if blf is None or not text:
        return 0.0
    font_id = 0
    try:
        blf.size(font_id, int(size))
    except Exception:
        try:
            blf.size(font_id, int(size), 72)
        except Exception:
            pass
    try:
        blf.color(font_id, color[0], color[1], color[2], color[3])
    except Exception:
        pass
    lines: list[str] = []
    for base in str(text).split('\n'):
        if max_width and max_width > 40:
            current = ''
            for ch in base:
                test = current + ch
                try:
                    width = blf.dimensions(font_id, test)[0]
                except Exception:
                    width = len(test) * size * 0.55
                if current and width > max_width:
                    lines.append(current)
                    current = ch
                else:
                    current = test
            lines.append(current)
        else:
            lines.append(base)
    line_h = max(12.0, float(size) * 1.35)
    yy = float(y)
    for line in lines:
        try:
            blf.position(font_id, float(x), yy, 0)
            blf.draw(font_id, line)
        except Exception:
            pass
        yy -= line_h
    return line_h * len(lines)


def _gpu_texture_for_preset(preset_id: str):
    preset_id = str(preset_id or '').strip()
    if not preset_id or gpu is None:
        return None
    cached = _GPU_TEXTURE_CACHE.get(preset_id)
    if cached is not None:
        return cached
    img = _load_preview_image_datablock(preset_id)
    if img is None:
        _GPU_TEXTURE_CACHE[preset_id] = None
        return None
    try:
        try:
            img.gl_load()
        except Exception:
            pass
        tex = gpu.texture.from_image(img)
    except Exception:
        tex = None
    _GPU_TEXTURE_CACHE[preset_id] = tex
    return tex


def _draw_image_tile(preset_id: str, x: float, y: float, size: float) -> bool:
    if gpu is None or batch_for_shader is None:
        return False
    shader = _shader_image()
    tex = _gpu_texture_for_preset(preset_id)
    if shader is None or tex is None:
        return False
    try:
        batch = batch_for_shader(
            shader,
            'TRI_FAN',
            {
                'pos': ((x, y), (x + size, y), (x + size, y + size), (x, y + size)),
                'texCoord': ((0, 0), (1, 0), (1, 1), (0, 1)),
            },
        )
        shader.bind()
        shader.uniform_sampler('image', tex)
        batch.draw(shader)
        return True
    except Exception:
        return False



class _ModalPreviewPickerState:
    __slots__ = (
        'target', 'generate', 'entries', 'groups', 'columns', 'scroll', 'max_scroll', 'tile_size', 'gap',
        'panel_rect', 'content_rect', 'scrollbar_rect', 'thumb_rect', 'hit_rects', 'hover_entry',
        'mouse_window', 'drag_scroll', 'drag_start_y', 'drag_start_scroll', 'window', 'source_window', 'owns_window', 'window_width',
        'window_height', 'operator', 'closed', 'title', 'scene', 'scale', 'content_height', '_close_rect',
        'fullscreen_started', 'fullscreen_window',
    )

    def __init__(self, operator, context, *, target: str, generate: bool, columns: int = 12, source_window=None, owns_window: bool = False):
        self.target = str(target or '').upper() if str(target or '').upper() == 'SMART_TOON_PBR_BASE' else ('PBR' if _is_pbr_preview_target(target) else 'MAIN')
        self.generate = bool(generate)
        self.scene = getattr(context, 'scene', None)
        self.entries = _preview_entries(context, target=self.target)
        self.groups = _group_entries_by_category(self.scene, self.entries)
        self.columns = max(1, int(columns or 12))
        self.scroll = 0.0
        self.max_scroll = 0.0
        self.tile_size = 80.0
        self.gap = 6.0
        self.panel_rect = (0.0, 0.0, 100.0, 100.0)
        self.content_rect = (0.0, 0.0, 100.0, 100.0)
        self.scrollbar_rect = (0.0, 0.0, 0.0, 0.0)
        self.thumb_rect = (0.0, 0.0, 0.0, 0.0)
        self.hit_rects: list[tuple[float, float, float, float, dict[str, object]]] = []
        self.hover_entry = None
        self.mouse_window = (0.0, 0.0)
        self.drag_scroll = False
        self.drag_start_y = 0.0
        self.drag_start_scroll = 0.0
        self.window = getattr(context, 'window', None)
        self.source_window = source_window
        self.owns_window = bool(owns_window)
        self.window_width = float(getattr(self.window, 'width', 0) or 0)
        self.window_height = float(getattr(self.window, 'height', 0) or 0)
        if self.window_width <= 0 or self.window_height <= 0:
            try:
                region = getattr(context, 'region', None)
                self.window_width = float(getattr(region, 'width', 1180) or 1180)
                self.window_height = float(getattr(region, 'height', 720) or 720)
            except Exception:
                self.window_width = 1180.0
                self.window_height = 720.0
        self.operator = operator
        self.closed = False
        self.title = tx(self.scene, 'Preset Image List', _lt('プリセット画像一覧'))
        self.scale = _ui_scale(context)
        self.content_height = 0.0
        self._close_rect = (0.0, 0.0, 0.0, 0.0)
        self.fullscreen_started = False
        self.fullscreen_window = None

    def refresh_window_size(self):
        try:
            window = self.window or getattr(bpy.context, 'window', None)
            self.window = window
            ww = float(getattr(window, 'width', 0) or 0)
            wh = float(getattr(window, 'height', 0) or 0)
            if ww > 0 and wh > 0:
                self.window_width = ww
                self.window_height = wh
        except Exception:
            pass
        return self.window_width, self.window_height

    def tag_redraw(self):
        try:
            screen = getattr(self.window, 'screen', None) or getattr(bpy.context, 'screen', None)
            for area in getattr(screen, 'areas', []) or []:
                try:
                    area.tag_redraw()
                except Exception:
                    pass
        except Exception:
            pass

    def rel_mouse(self, event):
        # event.mouse_x / event.mouse_y are Blender-window coordinates.  Using
        # them directly prevents the cursor-hit mismatch that happens when a
        # popup is drawn from a Shader Editor local region but covers N-panel/UI
        # regions as well.
        try:
            return (float(event.mouse_x), float(event.mouse_y))
        except Exception:
            return (0.0, 0.0)

    @staticmethod
    def _inside(rect, x: float, y: float) -> bool:
        rx, ry, rw, rh = rect
        return rx <= x <= rx + rw and ry <= y <= ry + rh

    @staticmethod
    def _intersects(rect, region) -> bool:
        rx, ry, rw, rh = rect
        try:
            gx = float(getattr(region, 'x', 0) or 0)
            gy = float(getattr(region, 'y', 0) or 0)
            gw = float(getattr(region, 'width', 0) or 0)
            gh = float(getattr(region, 'height', 0) or 0)
        except Exception:
            return True
        return (rx < gx + gw and rx + rw > gx and ry < gy + gh and ry + rh > gy)

    @staticmethod
    def _local_rect(region, rect):
        try:
            ox = float(getattr(region, 'x', 0) or 0)
            oy = float(getattr(region, 'y', 0) or 0)
        except Exception:
            ox = oy = 0.0
        x, y, w, h = rect
        return (x - ox, y - oy, w, h)

    def _layout_metrics(self):
        scale = self.scale
        win_w, win_h = self.refresh_window_size()
        margin = max(12.0, 18.0 * scale)
        panel_w = max(260.0, float(win_w) - margin * 2.0)
        panel_h = max(220.0, float(win_h) - margin * 2.0)
        # The modal overlay is laid out in Blender-window coordinates, not in an
        # editor's local WINDOW region.  Each region then draws only its visible
        # clipped part, so the picker appears above N-panels/headers instead of
        # being hidden behind them.
        px = margin
        py = margin
        header_h = max(32.0, 34.0 * scale)
        pad = max(8.0, 10.0 * scale)
        scrollbar_w = max(12.0, 14.0 * scale)
        content_x = px + pad
        content_y = py + pad
        content_w = panel_w - pad * 2.0 - scrollbar_w - max(5.0, 6.0 * scale)
        content_h = panel_h - header_h - pad * 2.0
        gap = max(4.0, 6.0 * scale)
        requested_columns = max(1, self.columns)
        tile = math.floor((content_w - gap * (requested_columns - 1)) / requested_columns)
        if tile < 64:
            requested_columns = max(2, int((content_w + gap) // (64 + gap)))
            tile = math.floor((content_w - gap * (requested_columns - 1)) / requested_columns)
        tile = max(56.0, min(154.0, float(tile)))
        columns = max(1, min(self.columns, int((content_w + gap) // (tile + gap))))
        if columns < 1:
            columns = 1
        tile = max(56.0, math.floor((content_w - gap * (columns - 1)) / columns))
        self.columns = columns
        self.tile_size = tile
        self.gap = gap
        self.panel_rect = (px, py, panel_w, panel_h)
        self.content_rect = (content_x, content_y, content_w, content_h)
        self.scrollbar_rect = (content_x + content_w + max(5.0, 6.0 * scale), content_y, scrollbar_w, content_h)
        return header_h, pad

    def _measure_content(self):
        scale = self.scale
        header_h = max(22.0, 24.0 * scale)
        group_pad = max(7.0, 8.0 * scale)
        tile = self.tile_size
        gap = self.gap
        total = 0.0
        for _gid, _label, items in self.groups:
            if not items:
                continue
            rows = int(math.ceil(len(items) / max(1, self.columns)))
            total += header_h + group_pad + rows * tile + max(0, rows - 1) * gap + group_pad + gap
        self.content_height = max(0.0, total)
        _, _, _, ch = self.content_rect
        self.max_scroll = max(0.0, self.content_height - ch)
        self.scroll = min(max(0.0, self.scroll), self.max_scroll)

    def _iter_tile_rects(self):
        cx, cy, cw, ch = self.content_rect
        y_down = 0.0
        header_h = max(22.0, 24.0 * self.scale)
        group_pad = max(7.0, 8.0 * self.scale)
        tile = self.tile_size
        gap = self.gap
        content_top = cy + ch
        for gid, category_label, items in self.groups:
            if not items:
                continue
            rows = int(math.ceil(len(items) / max(1, self.columns)))
            group_h = header_h + group_pad + rows * tile + max(0, rows - 1) * gap + group_pad
            group_screen_top = content_top - (y_down - self.scroll)
            group_screen_y = group_screen_top - group_h
            yield ('group', gid, category_label, items, (cx, group_screen_y, cw, group_h), group_screen_top, header_h)
            hy = group_screen_top - header_h
            start_y = hy - group_pad - tile
            for idx, entry in enumerate(items):
                row = idx // max(1, self.columns)
                col = idx % max(1, self.columns)
                x = cx + col * (tile + gap)
                y = start_y - row * (tile + gap)
                yield ('tile', entry, (x, y, tile, tile))
            y_down += group_h + gap

    def _update_hit_rects(self):
        self.hit_rects = []
        self.hover_entry = None
        mx, my = self.mouse_window
        cx, cy, cw, ch = self.content_rect
        for item in self._iter_tile_rects():
            if item[0] != 'tile':
                continue
            _kind, entry, rect = item
            x, y, w, h = rect
            if y + h < cy or y > cy + ch:
                continue
            self.hit_rects.append((x, y, w, h, entry))
            if self._inside(rect, mx, my):
                self.hover_entry = entry

    def _draw_rect_local(self, region, rect, color):
        _draw_rect(*self._local_rect(region, rect), color)

    def _draw_border_local(self, region, rect, color, thickness=1.0):
        _draw_border(*self._local_rect(region, rect), color, thickness)

    def _draw_line_local(self, region, x1, y1, x2, y2, color, thickness=1.0):
        try:
            ox = float(getattr(region, 'x', 0) or 0)
            oy = float(getattr(region, 'y', 0) or 0)
        except Exception:
            ox = oy = 0.0
        _draw_line(float(x1) - ox, float(y1) - oy, float(x2) - ox, float(y2) - oy, color, thickness)

    def _draw_close_icon_local(self, region, rect):
        x, y, w, h = rect
        inset = max(7.0 * self.scale, min(w, h) * 0.30)
        thickness = max(1.5, 2.0 * self.scale)
        color = (1.0, 1.0, 1.0, 0.96)
        self._draw_line_local(region, x + inset, y + inset, x + w - inset, y + h - inset, color, thickness)
        self._draw_line_local(region, x + inset, y + h - inset, x + w - inset, y + inset, color, thickness)

    def _draw_text_local(self, region, text, x, y, size, color, *, max_width=None):
        try:
            ox = float(getattr(region, 'x', 0) or 0)
            oy = float(getattr(region, 'y', 0) or 0)
        except Exception:
            ox = oy = 0.0
        _draw_text(text, x - ox, y - oy, size, color, max_width=max_width)

    def _draw_image_tile_local(self, region, preset_id: str, rect) -> bool:
        x, y, w, h = self._local_rect(region, rect)
        # Tiles are square by construction.  Preserve the source image as-is; do
        # not draw a filled hover layer over it, so hover never washes the image
        # out to white.
        return _draw_image_tile(preset_id, x, y, min(w, h))

    def _draw_scrollbar(self, region):
        sx, sy, sw, sh = self.scrollbar_rect
        self._draw_rect_local(region, self.scrollbar_rect, (0.09, 0.09, 0.09, 0.85))
        self._draw_border_local(region, self.scrollbar_rect, (0.30, 0.30, 0.30, 0.75), 1.0)
        if self.max_scroll <= 0.0:
            self.thumb_rect = (sx + 2, sy + 2, max(2, sw - 4), max(12, sh - 4))
            self._draw_rect_local(region, self.thumb_rect, (0.34, 0.34, 0.34, 0.95))
            return
        visible_ratio = min(1.0, max(0.05, sh / max(sh, self.content_height)))
        thumb_h = max(26.0, sh * visible_ratio)
        scroll_ratio = self.scroll / self.max_scroll if self.max_scroll > 0 else 0.0
        thumb_y = sy + (sh - thumb_h) * (1.0 - scroll_ratio)
        self.thumb_rect = (sx + 2, thumb_y, max(2, sw - 4), thumb_h)
        self._draw_rect_local(region, self.thumb_rect, (0.52, 0.52, 0.52, 0.96))
        self._draw_border_local(region, self.thumb_rect, (0.72, 0.72, 0.72, 0.95), 1.0)

    def _draw_tooltip(self, region):
        entry = self.hover_entry
        if not entry:
            return
        label = str(entry.get('label') or entry.get('id') or '')
        summary = str(entry.get('summary') or '').strip()
        if summary:
            text = tx(self.scene, f'Name: {label}\nSummary: {summary}', _lt(f'名前: {label}\n概要: {summary}'))
        else:
            text = tx(self.scene, f'Name: {label}', _lt(f'名前: {label}'))
        mx, my = self.mouse_window
        px, py, pw, ph = self.panel_rect
        max_w = min(520.0 * self.scale, pw - 30.0)
        lines = max(2, int(len(text) / 28) + text.count('\n') + 1)
        box_w = max(240.0, max_w)
        box_h = min(210.0, 24.0 + lines * 18.0)
        tx_x = min(mx + 18.0, px + pw - box_w - 10.0)
        tx_y = max(py + 10.0, min(my - box_h - 10.0, py + ph - box_h - 10.0))
        rect = (tx_x, tx_y, box_w, box_h)
        if not self._intersects(rect, region):
            return
        self._draw_rect_local(region, rect, (0.02, 0.02, 0.02, 0.94))
        self._draw_border_local(region, rect, (0.66, 0.66, 0.66, 0.95), 1.0)
        self._draw_text_local(region, text, tx_x + 10.0, tx_y + box_h - 18.0, int(12 * self.scale), (1.0, 1.0, 1.0, 1.0), max_width=box_w - 20.0)

    def draw(self):
        if self.closed or gpu is None:
            return
        region = getattr(bpy.context, 'region', None)
        if region is None:
            return
        # Only draw for regions in the active Blender window, when that
        # information is available.  This still covers every editor/UI/N-panel
        # region in that window, so the picker stays in front of the full UI.
        try:
            if self.window is not None and getattr(bpy.context, 'window', None) not in {None, self.window}:
                return
        except Exception:
            pass
        self._layout_metrics()
        self._measure_content()
        self._update_hit_rects()
        px, py, pw, ph = self.panel_rect
        cx, cy, cw, ch = self.content_rect
        if not self._intersects(self.panel_rect, region):
            return

        try:
            gpu.state.blend_set('ALPHA')
            gpu.state.depth_test_set('NONE')
        except Exception:
            pass

        self._draw_rect_local(region, self.panel_rect, (0.10, 0.10, 0.10, 0.985))
        self._draw_border_local(region, self.panel_rect, (0.48, 0.48, 0.48, 0.96), 1.0)
        header_h = max(32.0, 34.0 * self.scale)
        header_rect = (px, py + ph - header_h, pw, header_h)
        self._draw_rect_local(region, header_rect, (0.14, 0.14, 0.14, 0.99))
        self._draw_text_local(region, self.title, px + 12.0, py + ph - 21.0 * self.scale, int(13 * self.scale), (1, 1, 1, 1), max_width=pw - 80.0)
        close_w = max(26.0, 28.0 * self.scale)
        # Center the button vertically inside the header.  Do not draw a unicode
        # text glyph here: depending on the active UI scale and font baseline,
        # the glyph can be clipped at the top of the popup header.
        close_y = py + ph - header_h + max(2.0, (header_h - close_w) * 0.5)
        self._close_rect = (px + pw - close_w - 7.0, close_y, close_w, close_w)
        self._draw_rect_local(region, self._close_rect, (0.20, 0.20, 0.20, 0.96))
        self._draw_border_local(region, self._close_rect, (0.55, 0.55, 0.55, 0.95), 1.0)
        self._draw_close_icon_local(region, self._close_rect)

        # Content clipping in current region-local coordinates.
        try:
            local_content = self._local_rect(region, self.content_rect)
            gpu.state.scissor_test_set(True)
            gpu.state.scissor_set(int(local_content[0]), int(local_content[1]), int(local_content[2]), int(local_content[3]))
        except Exception:
            pass
        header_h2 = max(22.0, 24.0 * self.scale)
        for item in self._iter_tile_rects():
            kind = item[0]
            if kind == 'group':
                _kind, gid, category_label, items, group_rect, group_screen_top, _header_h = item
                if group_rect[1] < cy + ch and group_rect[1] + group_rect[3] > cy and self._intersects(group_rect, region):
                    self._draw_rect_local(region, group_rect, (0.125, 0.125, 0.125, 0.80))
                    self._draw_border_local(region, group_rect, (0.30, 0.30, 0.30, 0.92), 1.0)
                    hy = group_screen_top - header_h2
                    header_rect2 = (cx, hy, cw, header_h2)
                    self._draw_rect_local(region, header_rect2, (0.18, 0.18, 0.18, 0.96))
                    self._draw_text_local(region, f'{category_label}  ({len(items)})', cx + 8.0, hy + header_h2 - 7.5 * self.scale, int(11 * self.scale), (0.92, 0.92, 0.92, 1.0), max_width=cw - 16.0)
            elif kind == 'tile':
                _kind, entry, rect = item
                x, y, tile_w, tile_h = rect
                if y + tile_h < cy or y > cy + ch or not self._intersects(rect, region):
                    continue
                preset_id = str(entry.get('id') or '').strip()
                hovered = self._inside(rect, self.mouse_window[0], self.mouse_window[1])
                self._draw_rect_local(region, rect, (0.055, 0.055, 0.055, 1.0))
                if preset_id and not self._draw_image_tile_local(region, preset_id, rect):
                    self._draw_rect_local(region, rect, (0.22, 0.22, 0.22, 1.0))
                    self._draw_text_local(region, '?', x + tile_w * 0.43, y + tile_h * 0.60, int(16 * self.scale), (0.85, 0.85, 0.85, 1.0))
                if hovered:
                    # Hover must never tint the image white.  Draw only an outer
                    # frame/edge overlay so the existing rendered preview remains
                    # visually unchanged.
                    self._draw_border_local(region, (x - 2.0, y - 2.0, tile_w + 4.0, tile_h + 4.0), (1.0, 0.72, 0.22, 1.0), 3.0)
                    self._draw_border_local(region, rect, (1.0, 1.0, 1.0, 0.95), 1.0)
                else:
                    self._draw_border_local(region, rect, (0.24, 0.24, 0.24, 1.0), 1.0)
        try:
            gpu.state.scissor_test_set(False)
        except Exception:
            pass
        self._draw_scrollbar(region)
        self._draw_tooltip(region)

    def scroll_by(self, amount: float) -> None:
        self.scroll = min(max(0.0, self.scroll + amount), self.max_scroll)
        self.tag_redraw()

    def close(self) -> None:
        if self.closed:
            return
        self.closed = True
        picker_window = self.window
        should_close_window = bool(getattr(self, 'owns_window', False))
        _remove_modal_draw_handlers()
        self.tag_redraw()
        if should_close_window and picker_window is not None:
            def _close_picker_window():
                try:
                    if picker_window not in list(getattr(bpy.context.window_manager, 'windows', [])):
                        return None
                except Exception:
                    pass
                # Closing a temporary fullscreen screen with a full screen/area
                # override raises "temporary screen isn't supported" in Blender
                # 5.1.  A window-only override is enough and remains valid for
                # normal and fullscreen picker windows.
                try:
                    with bpy.context.temp_override(window=picker_window):
                        bpy.ops.wm.window_close()
                    return None
                except Exception:
                    pass
                try:
                    screen = getattr(picker_window, 'screen', None)
                    area = None
                    region = None
                    for candidate_area in getattr(screen, 'areas', []) or []:
                        area = candidate_area
                        for candidate_region in getattr(candidate_area, 'regions', []) or []:
                            if getattr(candidate_region, 'type', '') == 'WINDOW':
                                region = candidate_region
                                break
                        if region is not None:
                            break
                    override = {'window': picker_window}
                    if screen is not None:
                        override['screen'] = screen
                    if area is not None:
                        override['area'] = area
                    if region is not None:
                        override['region'] = region
                    with bpy.context.temp_override(**override):
                        bpy.ops.wm.window_close()
                except Exception:
                    try:
                        bpy.ops.wm.window_close()
                    except Exception:
                        pass
                return None
            # wm.window_close frees the window whose screen Blender still needs
            # to draw this operator's report popup against, and it must never run
            # from an RNA update callback.  Run it from a one-shot timer so the
            # operator returns while its host is still alive.
            report_safety.defer(_close_picker_window, tag='wm.window_close')
            # A second deferred close used to register a global timer here.
            # The explicit picker operation now performs only the immediate close;
            # no callback is allowed to survive the operation.



def _modal_draw_callback(state: _ModalPreviewPickerState) -> None:
    try:
        context = getattr(bpy, 'context', None)
        current_window = getattr(context, 'window', None) if context is not None else None
        state_window = getattr(state, 'window', None)
        if state_window is not None and current_window is not None and current_window != state_window:
            return
        # The picker state is a truthy context-shaped authority.  Passing its
        # raw Blender Window would let Manager's ``context or bpy.context``
        # fallback select a stale global workspace when the Window is falsey.
        runtime_context = state if state_window is not None else context
        if not workspace_runtime_allowed(runtime_context):
            return
        state.draw()
    except Exception:
        pass


def _modal_space_classes() -> list[object]:
    classes = []
    for name in (
        'SpaceView3D', 'SpaceImageEditor', 'SpaceNodeEditor', 'SpaceSequenceEditor', 'SpaceClipEditor',
        'SpaceDopeSheetEditor', 'SpaceGraphEditor', 'SpaceNLA', 'SpaceTextEditor', 'SpaceFileBrowser',
        'SpaceSpreadsheet', 'SpaceProperties', 'SpaceOutliner', 'SpacePreferences', 'SpaceConsole',
        'SpaceInfo', 'SpaceTopBar', 'SpaceStatusBar',
    ):
        cls = getattr(bpy.types, name, None)
        if cls is not None and cls not in classes:
            classes.append(cls)
    return classes


def _modal_region_types() -> tuple[str, ...]:
    # Register the same overlay over editor WINDOW regions and the UI/sidebar
    # regions that can otherwise cover the popup.  Unsupported combinations are
    # ignored by _add_modal_draw_handlers().
    return ('WINDOW', 'UI', 'HEADER', 'TOOLS', 'TOOL_HEADER', 'CHANNELS', 'PREVIEW', 'NAVIGATION_BAR', 'EXECUTE', 'FOOTER')


def _remove_modal_draw_handlers() -> None:
    global _MODAL_DRAW_HANDLERS
    for cls, region_type, handler in list(_MODAL_DRAW_HANDLERS):
        try:
            cls.draw_handler_remove(handler, region_type)
        except Exception:
            try:
                cls.draw_handler_remove(handler, 'WINDOW')
            except Exception:
                pass
    _MODAL_DRAW_HANDLERS = []


def _add_modal_draw_handlers(state: _ModalPreviewPickerState) -> bool:
    global _MODAL_DRAW_HANDLERS
    _remove_modal_draw_handlers()
    added = []
    for cls in _modal_space_classes():
        for region_type in _modal_region_types():
            try:
                handler = cls.draw_handler_add(_modal_draw_callback, (state,), region_type, 'POST_PIXEL')
            except Exception:
                continue
            added.append((cls, region_type, handler))
    _MODAL_DRAW_HANDLERS = added
    return bool(added)



def _screen_area_count(context) -> int:
    try:
        screen = getattr(context, 'screen', None) or getattr(getattr(context, 'window', None), 'screen', None)
        return len(getattr(screen, 'areas', []) or [])
    except Exception:
        return 0


def _enter_preview_fullscreen(context) -> tuple[bool, object]:
    """Temporarily maximize the invoking area for the image-button picker.

    Blender's Python GPU draw handlers are clipped by editor regions.  A true
    image-as-button picker with a custom scrollbar therefore needs a single
    unclipped editor area.  The preview picker enters temporary fullscreen only
    while it is open, but never hides panels, headers, or toolbars.  It restores
    the previous screen immediately after select, cancel, or unregister.
    """
    window = getattr(context, 'window', None) or getattr(bpy.context, 'window', None)
    screen = getattr(context, 'screen', None) or getattr(window, 'screen', None) or getattr(bpy.context, 'screen', None)
    try:
        areas = list(getattr(screen, 'areas', []) or [])
    except Exception:
        areas = []
    # If the screen already has one area, there is no split frame / N-panel to
    # hide and toggling fullscreen would instead restore a previous screen.
    if len(areas) <= 1:
        return False, window
    area = getattr(context, 'area', None)
    if area is None or area not in areas:
        # Timer/invoke contexts can occasionally lack an area.  Pick the largest
        # non-header editor area so the picker still opens as a single full
        # Blender-window overlay instead of falling back to a clipped native UI.
        usable = [a for a in areas if str(getattr(a, 'type', '')) not in {'TOPBAR', 'STATUSBAR'}]
        area = max(usable or areas, key=lambda a: (getattr(a, 'width', 0) or 0) * (getattr(a, 'height', 0) or 0), default=None)
    region = getattr(context, 'region', None)
    if region is None and area is not None:
        try:
            for candidate in area.regions:
                if getattr(candidate, 'type', '') == 'WINDOW':
                    region = candidate
                    break
        except Exception:
            region = None
    try:
        kwargs = {'window': window, 'screen': screen, 'area': area}
        if region is not None:
            kwargs['region'] = region
        # screen_full_area replaces the screen; nothing may queue a report while
        # it runs, and it must never be reached from an RNA update callback.
        if report_safety.in_unsafe_context():
            return False, window
        with report_safety.unsafe_context('screen_fullscreen_enter'):
            with context.temp_override(**{k:v for k,v in kwargs.items() if v is not None}):
                result = bpy.ops.screen.screen_full_area(use_hide_panels=False)
        if 'FINISHED' in result:
            return True, window
    except Exception:
        pass
    return False, window


def _restore_preview_fullscreen(state) -> None:
    """Leave the picker's temporary fullscreen screen -- from a one-shot timer.

    ``screen.back_to_previous`` frees the temporary ``bScreen`` the picker is
    drawn on.  Running it inline, before the modal operator returns, is what made
    Blender build the operator's report popup against a freed screen and crash in
    ``ui_region_temp_add``.  The restore is now deferred, so the operator returns
    while its screen is still alive; the screen is swapped one timer tick later.
    """
    if state is None or not getattr(state, 'fullscreen_started', False):
        return
    # Mark the restore as started immediately: the picker is logically closed and
    # a second close() must not schedule the screen swap twice.
    try:
        state.fullscreen_started = False
    except Exception:
        pass
    stored_window = getattr(state, 'fullscreen_window', None) or getattr(state, 'window', None)

    def _restore():
        window = stored_window
        try:
            windows = list(getattr(bpy.context.window_manager, 'windows', []) or [])
        except Exception:
            windows = []
        if window is None or (windows and window not in windows):
            window = getattr(bpy.context, 'window', None)
        if window is None:
            return
        screen = getattr(window, 'screen', None) or getattr(bpy.context, 'screen', None)
        area = None
        try:
            areas = list(getattr(screen, 'areas', []) or [])
            area = areas[0] if areas else None
        except Exception:
            area = None
        override = {k: v for k, v in {'window': window, 'screen': screen, 'area': area}.items() if v is not None}
        # No report may be queued while the screen is being replaced.
        with report_safety.unsafe_context('screen_teardown'):
            try:
                with bpy.context.temp_override(**override):
                    res = bpy.ops.screen.back_to_previous()
                if 'FINISHED' in res:
                    return
            except Exception:
                pass
            try:
                with bpy.context.temp_override(**override):
                    bpy.ops.screen.screen_full_area(use_hide_panels=False)
            except Exception:
                pass

    report_safety.defer(_restore, tag='screen.back_to_previous')

def _window_context_parts(window):
    screen = getattr(window, 'screen', None)
    area = None
    region = None
    try:
        for candidate_area in getattr(screen, 'areas', []) or []:
            if area is None:
                area = candidate_area
            for candidate_region in getattr(candidate_area, 'regions', []) or []:
                if getattr(candidate_region, 'type', '') == 'WINDOW':
                    area = candidate_area
                    region = candidate_region
                    return screen, area, region
    except Exception:
        pass
    return screen, area, region


def _open_dedicated_picker_window(context):
    """Disabled: the preview picker must not create an extra Blender window."""
    return None

def _context_for_window(window):
    screen, area, region = _window_context_parts(window)
    override = {'window': window}
    if screen is not None:
        override['screen'] = screen
    if area is not None:
        override['area'] = area
    if region is not None:
        override['region'] = region
    return override


def open_modal_preview_picker(operator, context, *, target: str = 'MAIN', generate: bool = False, columns: int = 12, use_dedicated_window: bool = False):
    """Open the preset picker as an internal fullscreen image-button overlay.

    Blender 5.1.0 does not provide a native scrollable preview-button grid that
    both uses rendered PNGs as full-size buttons and avoids unsupported
    the unsupported native GRID preview list mode.  This picker temporarily maximizes the
    invoking area without hiding headers/toolbars, draws the PNG rectangles as
    the actual clickable buttons, groups entries by category, supplies its own
    scrollbar, and restores the previous screen immediately after selection or
    cancel.
    """
    if not workspace_runtime_allowed(context):
        return {'CANCELLED'}
    global _ACTIVE_MODAL_STATE
    close_modal_preview_picker(None)
    source_window = getattr(context, 'window', None) if context is not None else None
    picker_context = context
    owns_window = False

    # Extra Blender windows are intentionally disabled.
    use_dedicated_window = False

    fullscreen_started = False
    fullscreen_window = None
    if not owns_window:
        fullscreen_started, fullscreen_window = _enter_preview_fullscreen(context)
        # After screen_full_area, bpy.context may point at the temporary full area.
        # Use it for window/region dimensions when available.
        try:
            picker_context = bpy.context
        except Exception:
            pass

    state_context = picker_context if picker_context is not None else context
    state = _ModalPreviewPickerState(operator, state_context, target=target, generate=generate, columns=columns, source_window=source_window, owns_window=owns_window)
    state.fullscreen_started = bool(fullscreen_started)
    state.fullscreen_window = fullscreen_window
    if not state.entries or gpu is None:
        if state.fullscreen_started:
            _restore_preview_fullscreen(state)
        if owns_window:
            try:
                state.close()
            except Exception:
                pass
        return None

    def _start_modal_with_context(ctx):
        if not _add_modal_draw_handlers(state):
            state.close()
            return None
        try:
            ctx.window_manager.modal_handler_add(operator)
        except Exception:
            state.close()
            return None
        return {'RUNNING_MODAL'}

    result = None
    if owns_window and state.window is not None:
        try:
            override = _context_for_window(state.window)
            with bpy.context.temp_override(**override):
                result = _start_modal_with_context(bpy.context)
        except Exception:
            result = _start_modal_with_context(state_context)
    else:
        result = _start_modal_with_context(state_context)

    if result is None:
        _ACTIVE_MODAL_STATE = None
        return None
    _ACTIVE_MODAL_STATE = state
    state.tag_redraw()
    return result



def _execute_modal_preset_selection(state, context, preset_id: str) -> bool:
    """Select and optionally generate the clicked preset from the image picker."""
    preset_id = str(preset_id or '').strip()
    if not preset_id:
        return False
    target = str(getattr(state, 'target', 'MAIN') or 'MAIN').upper()
    generate = bool(getattr(state, 'generate', False))
    try:
        op = getattr(state, 'operator', None)
        hook = getattr(op, '_execute_preview_selection', None) if op is not None else None
        if callable(hook):
            # The picker closes itself the moment this returns, so every
            # self.report() inside the selection hook -- in this module, in
            # operators.py and in the smart_toon wrapper installed on the class --
            # must go to the console instead of into Blender's report queue.
            result = report_safety.call_with_report_proxy(
                op, '_execute_preview_selection', context, preset_id,
                target=target, generate=generate,
            )
            if isinstance(result, set):
                return 'FINISHED' in result
            if isinstance(result, dict):
                return 'FINISHED' in result
            return bool(result)
        with report_safety.unsafe_context('modal_preset_selection'):
            selected, _material, _assigned = select_or_generate_preset(context, preset_id, target=target, generate=generate)
        return bool(selected)
    except Exception as exc:
        try:
            if getattr(state, 'scene', None) is not None:
                # Keep the selection synchronized even if material construction fails.
                select_preset(state.scene, preset_id, target=target)
        except Exception:
            pass
        report_safety.safe_report(getattr(state, 'operator', None), {'ERROR'}, _exc_text(exc),
                                  force_console=True)
        return False

def modal_preview_picker(operator, context, event):
    global _ACTIVE_MODAL_STATE
    state = _ACTIVE_MODAL_STATE
    if state is None or state.closed:
        return {'FINISHED'}
    current_window = getattr(context, 'window', None) if context is not None else None
    state_window = getattr(state, 'window', None)
    if state_window is not None and current_window is not None and current_window != state_window:
        return {'PASS_THROUGH'}
    if not workspace_runtime_allowed(context):
        close_modal_preview_picker(operator)
        return {'CANCELLED'}
    try:
        mx, my = state.rel_mouse(event)
        state.mouse_window = (mx, my)
    except Exception:
        mx, my = (0.0, 0.0)
    etype = getattr(event, 'type', '')
    evalue = getattr(event, 'value', '')

    if etype in {'ESC', 'RIGHTMOUSE'} and evalue in {'PRESS', 'CLICK', 'RELEASE'}:
        close_modal_preview_picker(operator)
        return {'CANCELLED'}

    if etype == 'MOUSEMOVE':
        if state.drag_scroll:
            _sx, sy, _sw, sh = state.scrollbar_rect
            _tx, _ty, _tw, th = state.thumb_rect
            travel = max(1.0, sh - th)
            delta = float(my) - float(state.drag_start_y)
            state.scroll = min(max(0.0, state.drag_start_scroll - (delta / travel) * state.max_scroll), state.max_scroll)
        state.tag_redraw()
        return {'RUNNING_MODAL'}

    if etype in {'WHEELDOWNMOUSE', 'WHEELUPMOUSE'}:
        step = max(48.0, state.tile_size + state.gap)
        state.scroll_by(step if etype == 'WHEELDOWNMOUSE' else -step)
        return {'RUNNING_MODAL'}

    if etype == 'LEFTMOUSE' and evalue == 'PRESS':
        try:
            if state._inside(getattr(state, '_close_rect', (0, 0, 0, 0)), mx, my):
                close_modal_preview_picker(operator)
                return {'CANCELLED'}
        except Exception:
            pass
        if state._inside(state.thumb_rect, mx, my):
            state.drag_scroll = True
            state.drag_start_y = my
            state.drag_start_scroll = state.scroll
            return {'RUNNING_MODAL'}
        # Hit rectangles are built in window coordinates, so they remain aligned
        # even when the overlay spans Shader Editor, 3D View, and N-panel regions.
        for x, y, w, h, entry in list(state.hit_rects):
            if state._inside((x, y, w, h), mx, my):
                preset_id = str(entry.get('id') or '').strip()
                if preset_id:
                    ok = _execute_modal_preset_selection(state, context, preset_id)
                    close_modal_preview_picker(operator)
                    return {'FINISHED'} if ok else {'CANCELLED'}
        if not state._inside(state.panel_rect, mx, my):
            close_modal_preview_picker(operator)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    if etype == 'LEFTMOUSE' and evalue == 'RELEASE':
        state.drag_scroll = False
        return {'RUNNING_MODAL'}

    state.tag_redraw()
    return {'RUNNING_MODAL'}


def close_modal_preview_picker(operator=None) -> None:
    """Tear the picker down without queueing anything Blender must draw later.

    Reachable from the modal itself, from ``cancel()``, and from
    ``unregister_properties`` -- which the add-on preferences feature toggles
    reach from an RNA update callback.  The whole teardown runs inside an
    unsafe-context mark, so any report attempted underneath it degrades to the
    console instead of asking Blender for a popup on a dying screen.
    """
    global _ACTIVE_MODAL_STATE
    state = _ACTIVE_MODAL_STATE
    _ACTIVE_MODAL_STATE = None
    if state is not None:
        with report_safety.unsafe_context('picker_teardown'):
            try:
                state.close()
            except Exception:
                pass
            try:
                _restore_preview_fullscreen(state)
            except Exception:
                pass
    return

def _genre_label(scene, genre_id: str) -> str:
    gid = str(genre_id or 'GENERAL').strip().upper() or 'GENERAL'
    try:
        meta = getattr(data, 'GENRE_META', {}).get(gid, {}) or {}
        if meta:
            return tx(scene, meta.get('label_en', gid.title()), meta.get('label_ja', gid))
    except Exception:
        pass
    return gid.replace('_', ' ').title()


def _category_order_key(genre_id: str) -> tuple[int, str]:
    gid = str(genre_id or 'GENERAL').strip().upper() or 'GENERAL'
    try:
        order = list(getattr(data, 'GENRE_ORDER', []) or [])
        if gid in order:
            return (order.index(gid), gid)
    except Exception:
        pass
    return (10_000, gid)


def _group_entries_by_category(scene, entries: list[dict[str, object]]) -> list[tuple[str, str, list[dict[str, object]]]]:
    groups: dict[str, list[dict[str, object]]] = {}
    for entry in entries:
        gid = str(entry.get('genre') or _preset_genre({}, str(entry.get('id') or '')) or 'GENERAL').strip().upper() or 'GENERAL'
        groups.setdefault(gid, []).append(entry)
    result: list[tuple[str, str, list[dict[str, object]]]] = []
    for gid in sorted(groups.keys(), key=_category_order_key):
        items = groups.get(gid) or []
        items.sort(key=lambda item: (str(item.get('label') or '').lower(), str(item.get('id') or '').lower()))
        result.append((gid, _genre_label(scene, gid), items))
    return result


def _draw_native_preview_tile(cell, scene, *, preset_id: str, target: str, generate: bool, icon_id: int):
    """Draw one preview tile using Blender 5.1-safe native UI.

    Blender 5.1 keeps ``operator(icon_value=...)`` icons at the small UI-icon
    size even when the button is scaled.  To make the rendered PNG occupy the
    tile, draw the preview with ``template_icon`` at the tile size and place the
    direct selection button in the same boxed tile.  This preserves the native
    front popup, avoids unsupported Blender 5.1 preview-list grid modes, and keeps the
    shader name/summary on the operator tooltip.
    """
    try:
        tile = cell.box()
    except Exception:
        tile = cell
    try:
        tile.ui_units_x = 5.4
        tile.ui_units_y = 5.9
    except Exception:
        pass

    # Large rendered preview.  This is the visible tile image and uses the
    # existing 256x256 PNG preview through Blender's preview collection.
    if icon_id > 0:
        try:
            img_col = tile.column(align=True)
            img_col.alignment = 'CENTER'
            img_col.template_icon(icon_value=icon_id, scale=5.25)
        except Exception:
            pass
    else:
        try:
            img_row = tile.row(align=True)
            img_row.alignment = 'CENTER'
            img_row.scale_y = 4.8
            img_row.label(text='', icon='MATERIAL')
        except Exception:
            pass

    # Direct selectable shader button.  It is intentionally image-only/blank in
    # visible text, while its tooltip is supplied by the operator description.
    op_row = tile.row(align=True)
    try:
        op_row.scale_y = 0.95
    except Exception:
        pass
    try:
        op = op_row.operator('sss.select_preset_from_preview', text='', icon='BLANK1', emboss=True)
    except Exception:
        op = op_row.operator('sss.select_preset_from_preview', text='', icon='MATERIAL', emboss=True)
    try:
        op.preset_id = preset_id
        op.target = str(target or 'MAIN').upper()
        op.generate = bool(generate)
    except Exception:
        pass
    return op


def draw_preview_icon_grid(layout, context, *, target: str = 'MAIN', generate: bool = False, columns: int = 12) -> None:
    scene = getattr(context, 'scene', None) if context is not None else None
    normalized = 'PBR' if _is_pbr_preview_target(target) else 'MAIN'
    target_upper = str(target or '').upper()
    entries = _preview_entries(context, target=normalized)
    if not entries:
        layout.label(text=tx(scene, 'No preset previews are available.', _lt('プレビュープリセットがありません。')), icon='ERROR')
        return

    column_count = max(1, int(columns or 12))
    for _gid, category_label, category_entries in _group_entries_by_category(scene, entries):
        if not category_entries:
            continue
        group_box = layout.box()
        header = group_box.row(align=True)
        header.label(text=f'{category_label}  ({len(category_entries)})', icon='FILE_FOLDER')
        try:
            grid = group_box.grid_flow(row_major=True, columns=column_count, even_columns=True, even_rows=True, align=True)
        except TypeError:
            try:
                grid = group_box.column_flow(columns=column_count, align=True)
            except Exception:
                grid = group_box.column(align=True)
        for entry in category_entries:
            preset_id = str(entry.get('id') or '').strip()
            if not preset_id:
                continue
            try:
                icon_id = icon_value_for_preset(preset_id)
            except Exception:
                icon_id = 0
            cell = grid.column(align=True)
            try:
                cell.scale_x = 1.0
                cell.scale_y = 1.0
            except Exception:
                pass
            _draw_native_preview_tile(cell, scene, preset_id=preset_id, target=normalized, generate=bool(generate), icon_id=icon_id)

def register_properties() -> None:
    # Clear legacy enum/UIList/texture preview properties from older builds.  The
    # current picker is a direct image grid and does not store any WindowManager
    # enum value, avoiding stale saved values such as "0" and preventing the
    # one-preview-first selector from appearing.
    unregister_properties()


def unregister_properties() -> None:
    close_modal_preview_picker(None)
    for prop in (
        'sss_preset_preview_popup_main', 'sss_preset_preview_popup_pbr',
        'sss_preset_preview_grid_main', 'sss_preset_preview_grid_pbr',
        'sss_preset_preview_grid_index_main', 'sss_preset_preview_grid_index_pbr',
        'sss_preset_preview_target', 'sss_preset_preview_generate', 'sss_preset_preview_texture',
    ):
        if hasattr(bpy.types.WindowManager, prop):
            try:
                delattr(bpy.types.WindowManager, prop)
            except Exception:
                pass
    try:
        wm = bpy.context.window_manager
        for prop in (
            'sss_preset_preview_popup_main', 'sss_preset_preview_popup_pbr',
            'sss_preset_preview_grid_main', 'sss_preset_preview_grid_pbr',
            'sss_preset_preview_grid_index_main', 'sss_preset_preview_grid_index_pbr',
            'sss_preset_preview_target', 'sss_preset_preview_generate', 'sss_preset_preview_texture',
        ):
            try:
                if prop in wm:
                    del wm[prop]
            except Exception:
                pass
    except Exception:
        pass
    _cleanup_preview_textures(None)
    global _PREVIEW_ENUM_KEY_MAIN, _PREVIEW_ENUM_KEY_PBR, _PREVIEW_ENUM_ITEMS_MAIN, _PREVIEW_ENUM_ITEMS_PBR, _GRID_SIGNATURES
    _PREVIEW_ENUM_KEY_MAIN = None
    _PREVIEW_ENUM_KEY_PBR = None
    _PREVIEW_ENUM_ITEMS_MAIN = []
    _PREVIEW_ENUM_ITEMS_PBR = []
    _GRID_SIGNATURES.clear()

def preview_status_text(scene) -> str:
    total=len(data.PRESET_LIBRARY)
    try: existing=sum(1 for preset_id in data.PRESET_LIBRARY.keys() if preview_path(preset_id).exists())
    except Exception: existing=0
    return tx(scene, f'Preview images: {existing} / {total}', _lt(f'プレビュー画像: {existing} / {total}'))
