"""Smart asset search and node-inspector helpers."""
from __future__ import annotations
from .translation import loc_text as _lt
from .translation import AddonError
from pathlib import Path
from urllib.parse import quote, unquote
import re
import time
try:
    import bpy
except Exception:
    bpy = None
from . import catalog, core, data, textures
from .translation import tx, locale_is_japanese
ASSET_SEARCH_SENTINEL = 'NO_ASSET_SEARCH_RESULTS'
NODE_PICK_SENTINEL = 'NO_NODE_MATCHES'
_ASSET_SEARCH_RESULT_CACHE: dict[tuple, tuple[float, list[dict]]] = {}
_NODE_ENTRY_CACHE: dict[tuple, tuple[float, list[dict]]] = {}
_NODE_ITEM_CACHE: dict[tuple, tuple[float, list[tuple]]] = {}
_QUERY_SPLIT_RE = re.compile('[\\s,;:/|]+')

def _query_terms(query: str) -> list[str]:
    terms: list[str] = []
    for raw in _QUERY_SPLIT_RE.split(str(query or '').strip().lower()):
        clean = core.normalize_texture_token(raw)
        if not clean or clean in terms:
            continue
        terms.append(clean)
    return terms

def _encode_key(kind: str, value: str) -> str:
    return f"{kind}::{quote(str(value or ''), safe='')}"

def decode_asset_search_key(key: str) -> tuple[str, str]:
    value = str(key or '')
    if '::' not in value:
        return ('', '')
    kind, raw = value.split('::', 1)
    return (kind.strip().upper(), unquote(raw))

def _score_terms(terms: list[str], weighted_fields: list[tuple[int, str]]) -> int:
    if not terms:
        return 0
    score = 0
    phrase = ' '.join(terms)
    for term in terms:
        matched = False
        for weight, text in weighted_fields:
            hay = str(text or '').lower()
            if term and term in hay:
                score += weight
                matched = True
                break
        if not matched:
            return -1
    if phrase and any((phrase in str(text or '').lower() for _, text in weighted_fields)):
        score += 3
    return score

def _base_result(kind: str, value: str, label_en: str, label_ja: str, summary_en: str, summary_ja: str, tags: list[str], score: int, extra: dict | None=None) -> dict:
    payload = {'key': _encode_key(kind, value), 'kind': kind, 'value': value, 'label_en': label_en, 'label_ja': label_ja, 'summary_en': summary_en, 'summary_ja': summary_ja, 'tags': [str(tag).strip() for tag in tags or [] if str(tag).strip()], 'score': score}
    if extra:
        payload.update(extra)
    return payload

def _builtin_results(query: str) -> list[dict]:
    terms = _query_terms(query)
    results: list[dict] = []
    for preset_id, meta in data.PRESET_LIBRARY.items():
        fields = [(12, preset_id), (11, meta.get('label_en', '')), (11, meta.get('label_ja', '')), (9, ' '.join(meta.get('tags', []))), (7, meta.get('family', '')), (5, meta.get('summary_en', '')), (5, meta.get('summary_ja', '')), (3, meta.get('usage_en', '')), (3, meta.get('usage_ja', '')), (2, meta.get('controls_en', '')), (2, meta.get('controls_ja', ''))]
        score = _score_terms(terms, fields)
        if terms and score < 0:
            continue
        results.append(_base_result('PRESET', preset_id, str(meta.get('label_en', preset_id) or preset_id), str(meta.get('label_ja', preset_id) or preset_id), str(meta.get('summary_en', '') or ''), str(meta.get('summary_ja', '') or ''), list(meta.get('tags', []) or []), score, extra={'family': str(meta.get('family', '') or '')}))
    return results

def _custom_results(query: str) -> list[dict]:
    terms = _query_terms(query)
    results: list[dict] = []
    for entry in core.list_custom_presets():
        name = str(entry.get('name', '') or '').strip()
        if not name:
            continue
        tags = [str(tag).strip() for tag in entry.get('tags') or [] if str(tag).strip()]
        fields = [(12, name), (10, entry.get('builder', '')), (9, ' '.join(tags)), (6, entry.get('summary_en', '')), (6, entry.get('summary_ja', ''))]
        score = _score_terms(terms, fields)
        if terms and score < 0:
            continue
        results.append(_base_result('CUSTOM', name, name, name, str(entry.get('summary_en', 'Saved custom preset.') or 'Saved custom preset.'), str(entry.get('summary_ja', _lt('保存済みのカスタムプリセットです。')) or _lt('保存済みのカスタムプリセットです。')), tags, score, extra={'builder': str(entry.get('builder', '') or '')}))
    return results

def _catalog_results(query: str) -> list[dict]:
    terms = _query_terms(query)
    results: list[dict] = []
    for entry in catalog.list_catalog_entries():
        name = str(entry.get('name', '') or '').strip()
        if not name:
            continue
        tags = [str(tag).strip() for tag in entry.get('tags') or [] if str(tag).strip()]
        usages = [str(tag).strip() for tag in entry.get('texture_usages') or [] if str(tag).strip()]
        fields = [(12, name), (9, entry.get('source_material', '')), (8, ' '.join(tags)), (7, ' '.join(usages)), (6, entry.get('builder', '')), (6, entry.get('family', '')), (4, entry.get('summary_en', '')), (4, entry.get('summary_ja', ''))]
        score = _score_terms(terms, fields)
        if terms and score < 0:
            continue
        results.append(_base_result('CATALOG', name, name, name, str(entry.get('summary_en', '') or ''), str(entry.get('summary_ja', '') or ''), tags + usages, score, extra={'builder': str(entry.get('builder', '') or ''), 'family': str(entry.get('family', '') or ''), 'texture_count': int(entry.get('texture_count', 0) or 0)}))
    return results

def list_asset_search_results(query: str='', limit: int=24) -> list[dict]:
    limit = max(1, int(limit or 24))
    query_text = str(query or '')
    # File-backed custom/catalog results are already mtime-cached in core.safe_json_load.
    # This short in-memory cache avoids re-scoring the full built-in preset table on
    # every sidebar redraw while still refreshing quickly after user edits.
    cache_key = (query_text.strip().lower(), limit)
    now = time.monotonic()
    cached = _ASSET_SEARCH_RESULT_CACHE.get(cache_key)
    if cached is not None and now - cached[0] < 1.0:
        return [dict(item) for item in cached[1]]
    results = _builtin_results(query_text) + _custom_results(query_text) + _catalog_results(query_text)
    results.sort(key=lambda item: (-int(item.get('score', 0) or 0), str(item.get('kind', '')), core.library_name_key(item.get('value', item.get('label_en', '')))))
    payload = results[:limit]
    _ASSET_SEARCH_RESULT_CACHE[cache_key] = (now, [dict(item) for item in payload])
    if len(_ASSET_SEARCH_RESULT_CACHE) > 128:
        for old_key in list(_ASSET_SEARCH_RESULT_CACHE.keys())[:32]:
            _ASSET_SEARCH_RESULT_CACHE.pop(old_key, None)
    return payload

def find_asset_search_result(key: str, query: str=''):
    for entry in list_asset_search_results(query=query, limit=64):
        if entry.get('key') == key:
            return entry
    kind, value = decode_asset_search_key(key)
    if not kind or not value:
        return None
    for entry in _builtin_results('') + _custom_results('') + _catalog_results(''):
        if entry.get('kind') == kind and core.library_name_key(entry.get('value', '')) == core.library_name_key(value):
            return entry
    return None

def asset_search_items(scene=None):
    query = getattr(scene, 'sss_asset_search_query', '') if scene is not None else ''
    items = []
    for entry in list_asset_search_results(query=query):
        kind = str(entry.get('kind', '') or '')
        kind_en = {'PRESET': 'Preset', 'CUSTOM': 'Custom', 'CATALOG': 'Catalog'}.get(kind, kind.title())
        kind_ja = {'PRESET': _lt('プリセット'), 'CUSTOM': _lt('カスタム'), 'CATALOG': _lt('カタログ')}.get(kind, kind)
        tags = ', '.join(entry.get('tags', [])[:6]) or '-'
        en = f"{kind_en} | {entry.get('summary_en', '')}\nTags: {tags}"
        ja = _lt(f"{kind_ja} | {entry.get('summary_ja', '')}\nタグ: {tags}")
        if scene is None:
            label = tx(None, str(entry.get('label_en', '') or ''), str(entry.get('label_ja', '') or ''))
            desc = tx(None, en, ja)
        else:
            label = tx(scene, str(entry.get('label_en', '') or ''), str(entry.get('label_ja', '') or ''))
            desc = tx(scene, en, ja)
        items.append((str(entry.get('key', '')), label, desc))
    if not items:
        items.append((ASSET_SEARCH_SENTINEL, tx(scene, 'No Search Results', _lt('一致する検索結果なし')), tx(scene, 'Adjust the asset-search query or save more presets and catalog entries.', _lt('検索語を変えるか、プリセットやカタログを増やしてください。'))))
    return items

def apply_asset_search_selection_to_scene(scene, result: dict) -> str:
    kind = str(result.get('kind', '') or '')
    value = str(result.get('value', '') or '')
    if kind == 'PRESET':
        family = str(result.get('family', 'PBR') or 'PBR')
        scene.sss_preset_family = family
        scene.sss_preset_name = value
        # The value is the preset id; an empty name field gives the material the preset's own name.
        scene.sss_material_name = ''
        return kind
    if kind == 'CUSTOM':
        scene.sss_preset_family = 'CUSTOM'
        scene.sss_preset_name = value
        scene.sss_material_name = value
        return kind
    if kind == 'CATALOG':
        scene.sss_catalog_pick = value
        scene.sss_catalog_entry_name = value
        return kind
    raise AddonError(_lt('Unsupported asset-search result kind.', '未対応のアセット検索結果種別です。'))

def asset_result_summary(scene, result: dict | None) -> str:
    if not result:
        return tx(scene, 'No search result selected yet.', _lt('まだ検索結果が選択されていません。'))
    kind = str(result.get('kind', '') or '')
    kind_en = {'PRESET': 'Preset', 'CUSTOM': 'Custom', 'CATALOG': 'Catalog'}.get(kind, kind.title())
    kind_ja = {'PRESET': _lt('プリセット'), 'CUSTOM': _lt('カスタム'), 'CATALOG': _lt('カタログ')}.get(kind, kind)
    tags = ', '.join(result.get('tags', [])[:6]) or '-'
    extra_en = []
    extra_ja = []
    if result.get('family'):
        extra_en.append(f"Family: {result.get('family')}")
        extra_ja.append(_lt(f"分類: {result.get('family')}"))
    if result.get('builder'):
        extra_en.append(f"Builder: {result.get('builder')}")
        extra_ja.append(_lt(f"ビルダー: {result.get('builder')}"))
    if result.get('texture_count') is not None and kind == 'CATALOG':
        extra_en.append(f"Textures: {result.get('texture_count')}")
        extra_ja.append(_lt(f"テクスチャ: {result.get('texture_count')}"))
    extra_en.append(f'Tags: {tags}')
    extra_ja.append(_lt(f'タグ: {tags}'))
    return tx(scene, f"{kind_en} | {result.get('summary_en', '')}\n" + '\n'.join(extra_en), f"{kind_ja} | {result.get('summary_ja', '')}\n" + '\n'.join(extra_ja))

def _node_haystack(node) -> str:
    image = getattr(node, 'image', None)
    return ' '.join([str(getattr(node, 'name', '') or ''), str(getattr(node, 'label', '') or ''), str(getattr(node, 'bl_idname', '') or ''), str(getattr(getattr(node, 'bl_rna', None), 'name', '') or ''), str(getattr(image, 'name', '') or ''), str(getattr(image, 'filepath', '') or ''), str(textures.guess_image_usage(node) or '')]).lower()

def _node_link_counts(node) -> tuple[int, int]:
    inputs = getattr(node, 'inputs', []) or []
    outputs = getattr(node, 'outputs', []) or []
    linked_inputs = sum((1 for socket in inputs if getattr(socket, 'is_linked', False)))
    linked_outputs = sum((1 for socket in outputs if getattr(socket, 'is_linked', False)))
    return (linked_inputs, linked_outputs)

def _node_dead_end(node) -> bool:
    if str(getattr(node, 'bl_idname', '') or '') == 'ShaderNodeOutputMaterial':
        return False
    _linked_inputs, linked_outputs = _node_link_counts(node)
    return linked_outputs == 0

def _image_abspath(image) -> str:
    raw = str(getattr(image, 'filepath', '') or '')
    if not raw:
        return ''
    if bpy is not None:
        try:
            return str(bpy.path.abspath(raw))
        except Exception:
            pass
    return raw

def _material_pointer(material) -> int:
    if material is None:
        return 0
    try:
        pointer = int(material.as_pointer())
        if pointer:
            return pointer
    except Exception:
        pass
    return id(material)


def _node_cache_key(material, query: str='') -> tuple:
    try:
        tree = getattr(material, 'node_tree', None)
        node_count = len(getattr(tree, 'nodes', []) or []) if tree is not None else 0
        link_count = len(getattr(tree, 'links', []) or []) if tree is not None else 0
    except Exception:
        node_count = 0
        link_count = 0
    return (_material_pointer(material), str(getattr(material, 'name', '') or ''), node_count, link_count, str(query or '').strip().lower())


def list_node_entries(material, query: str='') -> list[dict]:
    if material is None or not getattr(material, 'use_nodes', False) or getattr(material, 'node_tree', None) is None:
        return []
    cache_key = _node_cache_key(material, query)
    now = time.monotonic()
    cached = _NODE_ENTRY_CACHE.get(cache_key)
    if cached is not None and now - cached[0] < 0.75:
        return [dict(item) for item in cached[1]]
    terms = _query_terms(query)
    entries: list[dict] = []
    for node in getattr(material.node_tree, 'nodes', []) or []:
        text = _node_haystack(node)
        if terms and (not all((term in text for term in terms))):
            continue
        linked_inputs, linked_outputs = _node_link_counts(node)
        image = getattr(node, 'image', None)
        usage = textures.guess_image_usage(node) if image is not None else ''
        missing = False
        raw = ''
        if image is not None and (not getattr(image, 'packed_file', None)):
            raw = _image_abspath(image)
            missing = bool(raw) and (not Path(raw).exists())
        entries.append({'name': str(getattr(node, 'name', '') or ''), 'label': str(getattr(node, 'label', '') or ''), 'bl_idname': str(getattr(node, 'bl_idname', '') or ''), 'type_name': str(getattr(getattr(node, 'bl_rna', None), 'name', '') or getattr(node, 'bl_idname', '')), 'usage': usage, 'linked_inputs': linked_inputs, 'linked_outputs': linked_outputs, 'image_name': str(getattr(image, 'name', '') or ''), 'image_path': raw, 'dead_end': _node_dead_end(node), 'missing_image': missing})
    entries.sort(key=lambda item: (item['dead_end'], item['missing_image'], core.library_name_key(item['name'])))
    _NODE_ENTRY_CACHE[cache_key] = (now, [dict(item) for item in entries])
    if len(_NODE_ENTRY_CACHE) > 128:
        for old_key in list(_NODE_ENTRY_CACHE.keys())[:32]:
            _NODE_ENTRY_CACHE.pop(old_key, None)
    return entries

def node_pick_items(material, scene=None):
    query = getattr(scene, 'sss_node_query', '') if scene is not None else ''
    cache_key = ('items', _node_cache_key(material, query), 'ja' if locale_is_japanese() else 'en')
    now = time.monotonic()
    cached = _NODE_ITEM_CACHE.get(cache_key)
    if cached is not None and now - cached[0] < 0.75:
        return list(cached[1])
    items = [(NODE_PICK_SENTINEL, tx(scene, 'No Node Selected', _lt('ノード未選択')), tx(scene, 'Choose a node from the candidates below before running node selection or node reporting.', _lt('ノード選択やノードレポートを実行する前に、下の候補からノードを選んでください。')))]
    for entry in list_node_entries(material, query=query):
        usage = str(entry.get('usage', '') or '')
        usage_en = f' | Usage: {usage}' if usage else ''
        usage_ja = _lt(f' | 用途: {usage}') if usage else ''
        flags_en = []
        flags_ja = []
        if entry.get('dead_end'):
            flags_en.append('dead-end')
            flags_ja.append(_lt('行き止まり'))
        if entry.get('missing_image'):
            flags_en.append('missing image')
            flags_ja.append(_lt('欠損画像'))
        flag_en = f" | {', '.join(flags_en)}" if flags_en else ''
        flag_ja = f" | {', '.join(flags_ja)}" if flags_ja else ''
        en = f"{entry.get('type_name', entry.get('bl_idname', ''))} | in={entry.get('linked_inputs', 0)} out={entry.get('linked_outputs', 0)}{usage_en}{flag_en}"
        ja = _lt(f"{entry.get('type_name', entry.get('bl_idname', ''))} | 入={entry.get('linked_inputs', 0)} 出={entry.get('linked_outputs', 0)}{usage_ja}{flag_ja}")
        label_en = entry.get('name') or entry.get('label') or entry.get('bl_idname')
        label_ja = entry.get('name') or entry.get('label') or entry.get('bl_idname')
        if scene is None:
            label = tx(None, label_en, label_ja)
            desc = tx(None, en, ja)
        else:
            label = tx(scene, label_en, label_ja)
            desc = tx(scene, en, ja)
        items.append((str(entry.get('name', '')), label, desc))
    if len(items) == 1:
        items[0] = (NODE_PICK_SENTINEL, tx(scene, 'No Nodes Match', _lt('一致するノードなし')), tx(scene, 'Adjust the node query or capture a node-based material first.', _lt('ノード検索語を変えるか、ノード材質を取り込んでください。')))
    _NODE_ITEM_CACHE[cache_key] = (now, list(items))
    if len(_NODE_ITEM_CACHE) > 128:
        for old_key in list(_NODE_ITEM_CACHE.keys())[:32]:
            _NODE_ITEM_CACHE.pop(old_key, None)
    return items

def find_node(material, name: str):
    if material is None or not getattr(material, 'use_nodes', False) or getattr(material, 'node_tree', None) is None:
        return None
    target = core.library_name_key(name)
    if not target:
        return None
    for node in getattr(material.node_tree, 'nodes', []) or []:
        if core.library_name_key(getattr(node, 'name', '')) == target:
            return node
    return None

def node_summary_text(scene, material, node) -> str:
    if material is None or node is None:
        return tx(scene, 'No node selected.', _lt('ノードが選択されていません。'))
    linked_inputs, linked_outputs = _node_link_counts(node)
    lines_en = [f"Node: {getattr(node, 'name', '')}", f"Type: {getattr(getattr(node, 'bl_rna', None), 'name', '') or getattr(node, 'bl_idname', '')}", f'Inputs linked: {linked_inputs}', f'Outputs linked: {linked_outputs}']
    lines_ja = [_lt(f"ノード: {getattr(node, 'name', '')}"), _lt(f"種類: {getattr(getattr(node, 'bl_rna', None), 'name', '') or getattr(node, 'bl_idname', '')}"), _lt(f'入力リンク数: {linked_inputs}'), _lt(f'出力リンク数: {linked_outputs}')]
    if getattr(node, 'label', ''):
        lines_en.append(f"Label: {getattr(node, 'label', '')}")
        lines_ja.append(_lt(f"ラベル: {getattr(node, 'label', '')}"))
    if _node_dead_end(node):
        lines_en.append('This node currently does not feed any downstream node.')
        lines_ja.append(_lt('現在このノードは後段ノードへ出力していません。'))
    if str(getattr(node, 'bl_idname', '') or '') == 'ShaderNodeOutputMaterial':
        target = str(getattr(node, 'target', 'ALL') or 'ALL')
        lines_en.append(f'Output target: {target}')
        lines_ja.append(_lt(f'出力ターゲット: {target}'))
    image = getattr(node, 'image', None)
    if image is not None:
        usage = textures.guess_image_usage(node) or 'unknown'
        packed = bool(getattr(image, 'packed_file', None))
        raw = _image_abspath(image)
        exists = True
        if raw and (not packed):
            exists = Path(raw).exists()
        colorspace = str(getattr(getattr(image, 'colorspace_settings', None), 'name', '') or '')
        lines_en.extend([f"Image: {getattr(image, 'name', '')}", f'Guessed usage: {usage}', f'Packed: {packed}', f'Exists: {exists}', f"Color space: {colorspace or '-'}", f"Path: {raw or '-'}"])
        lines_ja.extend([_lt(f"画像: {getattr(image, 'name', '')}"), _lt(f'推定用途: {usage}'), _lt(f'パック済み: {packed}'), _lt(f'存在: {exists}'), _lt(f"色空間: {colorspace or '-'}"), _lt(f"パス: {raw or '-'}")])
    return tx(scene, '\n'.join(lines_en), '\n'.join(lines_ja))
