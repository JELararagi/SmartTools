"""Rule-based material assignment helpers."""
from __future__ import annotations
from .translation import loc_text as _lt
from .translation import AddonError
import fnmatch
import re
from datetime import datetime
from pathlib import Path
try:
    import bpy
except Exception:
    bpy = None
from . import core
from .translation import tx
ASSIGN_RULE_SENTINEL = 'NO_ASSIGN_RULES'
_RULE_QUERY_SPLIT = re.compile('[\\s,;:/|]+')

def assign_rule_path() -> Path:
    return core.addon_storage_dir() / 'assignment_rules.json'

def _now_iso() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + 'Z'

def _clean_tags(raw) -> list[str]:
    if isinstance(raw, (list, tuple, set)):
        values = [str(item or '').strip() for item in raw]
    else:
        values = [chunk.strip() for chunk in re.split('[,;\\n]+', str(raw or ''))]
    out: list[str] = []
    for value in values:
        if not value or value in out:
            continue
        out.append(value)
    return out

def _pattern_matcher(pattern: str, use_regex: bool):
    clean = str(pattern or '').strip()
    if not clean:
        return lambda value: True
    if use_regex:
        try:
            regex = re.compile(clean, re.IGNORECASE)
            return lambda value: bool(regex.search(str(value or '')))
        except re.error:
            pass
    wildcard = clean.lower()
    if not any((ch in wildcard for ch in '*?[]')):
        wildcard = f'*{wildcard}*'
    return lambda value: fnmatch.fnmatch(str(value or '').lower(), wildcard)

def _object_collection_names(obj) -> list[str]:
    names: list[str] = []
    for coll in list(getattr(obj, 'users_collection', []) or []):
        name = str(getattr(coll, 'name', '') or '').strip()
        if name and name not in names:
            names.append(name)
    return names

def _object_material_names(obj) -> list[str]:
    names: list[str] = []
    data_block = getattr(obj, 'data', None)
    materials = getattr(data_block, 'materials', None) if data_block is not None else None
    if materials is None:
        return names
    for material in list(materials):
        name = str(getattr(material, 'name', '') or '').strip()
        if name and name not in names:
            names.append(name)
    return names

def normalize_assignment_rule(entry: dict) -> dict:
    name = str(entry.get('name', '') or '').strip()
    material_name = str(entry.get('material_name', '') or '').strip()
    object_pattern = str(entry.get('object_pattern', '') or '').strip()
    collection_pattern = str(entry.get('collection_pattern', '') or '').strip()
    current_material_pattern = str(entry.get('current_material_pattern', '') or '').strip()
    use_regex = bool(entry.get('use_regex', False))
    scope = str(entry.get('scope', 'SCENE') or 'SCENE').upper()
    if scope not in {'SCENE', 'SELECTED'}:
        scope = 'SCENE'
    assign_mode = str(entry.get('assign_mode', 'ACTIVE_SLOT') or 'ACTIVE_SLOT').upper()
    if assign_mode not in {'ACTIVE_SLOT', 'FIRST_SLOT', 'APPEND', 'ALL_SLOTS'}:
        assign_mode = 'ACTIVE_SLOT'
    tags = _clean_tags(entry.get('tags', []))
    summary_en = str(entry.get('summary_en', '') or '').strip()
    summary_ja = str(entry.get('summary_ja', '') or '').strip()
    if not summary_en:
        summary_en = f"Assign {material_name or 'the target material'} when object / collection / current-material patterns match."
    if not summary_ja:
        summary_ja = _lt(f"オブジェクト名・コレクション名・現在材質名の条件に一致した対象へ、{material_name or _lt('指定材質')} を割り当てます。")
    if not tags:
        tags = ['Rule', 'Batch Assign']
    return {'name': name, 'material_name': material_name, 'object_pattern': object_pattern, 'collection_pattern': collection_pattern, 'current_material_pattern': current_material_pattern, 'use_regex': use_regex, 'scope': scope, 'assign_mode': assign_mode, 'summary_en': summary_en, 'summary_ja': summary_ja, 'tags': tags, 'saved_at': str(entry.get('saved_at', '') or _now_iso())}

def _valid_rule(entry: dict) -> bool:
    return bool(str(entry.get('name', '') or '').strip()) and bool(str(entry.get('material_name', '') or '').strip())

def _load_assign_rule_payload(path: Path) -> list[dict]:
    return [normalize_assignment_rule(item) for item in core.safe_json_load(path) if _valid_rule(normalize_assignment_rule(item))]

def list_assignment_rules(query: str='') -> list[dict]:
    rules = _load_assign_rule_payload(assign_rule_path())
    query_terms = [term for term in _RULE_QUERY_SPLIT.split(str(query or '').strip().lower()) if term]
    filtered: list[dict] = []
    seen: set[str] = set()
    for entry in rules:
        key = core.library_name_key(entry.get('name', ''))
        if not key or key in seen:
            continue
        seen.add(key)
        hay = ' '.join([str(entry.get('name', '')), str(entry.get('material_name', '')), str(entry.get('object_pattern', '')), str(entry.get('collection_pattern', '')), str(entry.get('current_material_pattern', '')), str(entry.get('summary_en', '')), str(entry.get('summary_ja', '')), ' '.join(entry.get('tags', []) or [])]).lower()
        if query_terms and (not all((term in hay for term in query_terms))):
            continue
        filtered.append(entry)
    filtered.sort(key=lambda item: core.library_name_key(item.get('name', '')))
    return filtered

def assign_rule_items(scene=None):
    query = getattr(scene, 'sss_rule_search', '') if scene is not None else ''
    items = []
    for entry in list_assignment_rules(query=query):
        tags = ', '.join(entry.get('tags', [])[:5]) or '-'
        en = f"{entry.get('summary_en', '')}\nTarget: {entry.get('material_name', '-')}\nTags: {tags}"
        ja = _lt(f"{entry.get('summary_ja', '')}\n対象材質: {entry.get('material_name', '-')}\nタグ: {tags}")
        if scene is None:
            label = tx(None, entry.get('name', ''), entry.get('name', ''))
            desc = tx(None, en, ja)
        else:
            label = tx(scene, entry.get('name', ''), entry.get('name', ''))
            desc = tx(scene, en, ja)
        items.append((str(entry.get('name', '')), label, desc))
    if not items:
        items.append((ASSIGN_RULE_SENTINEL, tx(scene, 'No Assign Rules', _lt('割当ルールなし')), tx(scene, 'Save an assignment rule first.', _lt('先に割当ルールを保存してください。'))))
    return items

def find_assignment_rule(name: str):
    key = core.library_name_key(name)
    for entry in list_assignment_rules():
        if core.library_name_key(entry.get('name', '')) == key:
            return entry
    return None

def save_assignment_rule(entry: dict) -> dict:
    normalized = normalize_assignment_rule(entry)
    if not _valid_rule(normalized):
        raise AddonError(_lt('Assignment rule needs a name and target material.', '割当ルールには名前とターゲットマテリアルが必要です。'))
    db = [item for item in list_assignment_rules() if core.library_name_key(item.get('name', '')) != core.library_name_key(normalized.get('name', ''))]
    db.append(normalized)
    db.sort(key=lambda item: core.library_name_key(item.get('name', '')))
    core.safe_json_save(assign_rule_path(), db)
    return normalized

def delete_assignment_rule(name: str) -> bool:
    key = core.library_name_key(name)
    db = list_assignment_rules()
    kept = [item for item in db if core.library_name_key(item.get('name', '')) != key]
    if len(kept) == len(db):
        return False
    core.safe_json_save(assign_rule_path(), kept)
    return True

def export_assignment_rule_library(path: Path | str) -> int:
    payload = list_assignment_rules()
    core.safe_json_save(Path(path), payload)
    return len(payload)

def import_assignment_rule_library(path: Path | str, mode: str='MERGE') -> dict:
    incoming = _load_assign_rule_payload(Path(path))
    result = {'mode': str(mode or 'MERGE').upper(), 'imported': 0, 'replaced': 0, 'skipped_invalid': 0, 'total': 0}
    result['total'] = len(incoming)
    if result['mode'] == 'REPLACE':
        core.safe_json_save(assign_rule_path(), incoming)
        result['imported'] = len(incoming)
        return result
    existing = list_assignment_rules()
    merged = {core.library_name_key(item.get('name', '')): item for item in existing}
    for item in incoming:
        key = core.library_name_key(item.get('name', ''))
        if not key:
            result['skipped_invalid'] += 1
            continue
        if key in merged:
            result['replaced'] += 1
        else:
            result['imported'] += 1
        merged[key] = item
    payload = sorted(merged.values(), key=lambda item: core.library_name_key(item.get('name', '')))
    core.safe_json_save(assign_rule_path(), payload)
    return result

def repair_assignment_rule_library() -> dict:
    original = core.safe_json_load(assign_rule_path())
    repaired: list[dict] = []
    seen: set[str] = set()
    duplicate_names = 0
    invalid = 0
    for raw in original:
        item = normalize_assignment_rule(raw)
        key = core.library_name_key(item.get('name', ''))
        if not _valid_rule(item):
            invalid += 1
            continue
        if key in seen:
            duplicate_names += 1
            continue
        seen.add(key)
        repaired.append(item)
    repaired.sort(key=lambda item: core.library_name_key(item.get('name', '')))
    core.safe_json_save(assign_rule_path(), repaired)
    return {'before': len(original), 'after': len(repaired), 'removed_duplicates': duplicate_names, 'removed_invalid': invalid}

def _scope_objects(context, scope: str) -> list:
    scope_value = str(scope or 'SCENE').upper()
    if scope_value == 'SELECTED':
        objs = list(getattr(context, 'selected_objects', []) or [])
        if not objs and getattr(context, 'object', None) is not None:
            objs = [context.object]
        return objs
    scene = getattr(context, 'scene', None)
    return list(getattr(scene, 'objects', []) or [])

def preview_assignment_rule(context, entry: dict) -> dict:
    normalized = normalize_assignment_rule(entry)
    objects = _scope_objects(context, normalized.get('scope', 'SCENE'))
    object_match = _pattern_matcher(normalized.get('object_pattern', ''), normalized.get('use_regex', False))
    collection_match = _pattern_matcher(normalized.get('collection_pattern', ''), normalized.get('use_regex', False))
    current_material_match = _pattern_matcher(normalized.get('current_material_pattern', ''), normalized.get('use_regex', False))
    matched = []
    for obj in objects:
        obj_name = str(getattr(obj, 'name', '') or '')
        if not object_match(obj_name):
            continue
        collections = _object_collection_names(obj)
        if normalized.get('collection_pattern') and (not any((collection_match(name) for name in collections))):
            continue
        material_names = _object_material_names(obj)
        if normalized.get('current_material_pattern') and (not any((current_material_match(name) for name in material_names))):
            continue
        if core._object_material_collection(obj) is None:
            continue
        matched.append(obj)
    target_name = str(normalized.get('material_name', '') or '')
    material_exists = bool(bpy and core.safe_data_get('materials', target_name))
    return {'rule': normalized, 'scope_object_count': len(objects), 'matched_objects': matched, 'matched_names': [str(getattr(obj, 'name', '') or '') for obj in matched], 'target_material_name': target_name, 'target_material_exists': material_exists}

def apply_assignment_rule(context, entry: dict) -> dict:
    preview = preview_assignment_rule(context, entry)
    target_name = preview.get('target_material_name', '')
    if not bpy or not target_name:
        raise AddonError(_lt('Target material is missing.', 'ターゲットマテリアルが見つかりません。'))
    material = core.safe_data_get('materials', target_name)
    if material is None:
        raise AddonError(tx(None, f'Target material not found: {target_name}', f'ターゲットマテリアルが見つかりません: {target_name}'))
    mode = str(preview['rule'].get('assign_mode', 'ACTIVE_SLOT') or 'ACTIVE_SLOT')
    assigned = 0
    failed = 0
    for obj in preview['matched_objects']:
        if core.set_material_on_object(obj, material, mode=mode, context=context):
            assigned += 1
        else:
            failed += 1
    return {**preview, 'assigned': assigned, 'failed': failed, 'assign_mode': mode}

def summary_lines(scene, entry: dict) -> list[str]:
    normalized = normalize_assignment_rule(entry)
    return [tx(scene, f"Target: {normalized.get('material_name', '-')}", _lt(f"対象材質: {normalized.get('material_name', '-')}")), tx(scene, f"Object match: {normalized.get('object_pattern', '*') or '*'}", _lt(f"オブジェクト条件: {normalized.get('object_pattern', '*') or '*'}")), tx(scene, f"Collection match: {normalized.get('collection_pattern', '*') or '*'}", _lt(f"コレクション条件: {normalized.get('collection_pattern', '*') or '*'}")), tx(scene, f"Current material match: {normalized.get('current_material_pattern', '*') or '*'}", _lt(f"現在材質条件: {normalized.get('current_material_pattern', '*') or '*'}")), tx(scene, f"Scope: {normalized.get('scope', 'SCENE')}", _lt(f"範囲: {normalized.get('scope', 'SCENE')}")), tx(scene, f"Assign mode: {normalized.get('assign_mode', 'ACTIVE_SLOT')}", _lt(f"割当方式: {normalized.get('assign_mode', 'ACTIVE_SLOT')}"))]
