# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart Shader Suite integrated Material Editor for Blender 5.1+.

Integrated compact material-editor workflow with Blender-native material, node, viewport, and library operations.
"""

import json
import math
import time
from typing import Iterable, Optional

import bpy
from bpy.types import (
    Menu,
    Operator,
    PropertyGroup,
    UIList,
)
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy_extras.io_utils import ExportHelper, ImportHelper

from . import core, slot_selection, storage
from .translation import exc_text as _exc_text

try:
    import bmesh
except Exception:  # pragma: no cover - bmesh is always available inside Blender.
    bmesh = None

bl_info = {
    "name": "Smart Shader Suite - Material Editor",
    "author": "JELararagi",
    "version": (5, 18, 224),
    "blender": (5, 1, 0),
    "location": "Smart Shader N-panel > Material Editor",
    "description": "Integrated compact material editor for Smart Shader Suite.",
    "category": "Material",
}

ADDON_ID = __package__ or __name__
ADDON_BASENAME = "smart_shader_suite"
SLOT_DEFAULT_COUNT = 24
PREVIEW_COLLECTION_NAME = "SSS_Material_Editor_Preview"
PREVIEW_OBJECT_PREFIX = "SSS_ME_Preview_"
CHECKER_MATERIAL_NAME = "SSS_ME_Checker_Background"
DEFAULT_MATERIAL_PREFIX = "SSS Material Editor Slot"

# Native material preview requests are asynchronous.  Track IDs that have
# already been submitted so repeated N-panel redraws do not enqueue the same
# preview render over and over while Blender is still working.
_MATERIAL_PREVIEW_REQUESTED_IDS: set[int] = set()
_MATERIAL_PREVIEW_QUEUE: list[bpy.types.Material] = []
_MATERIAL_EDITOR_MSGBUS_OWNER = object()
_MATERIAL_EDITOR_LOAD_RESTORE_ENABLED = False
_MATERIAL_EDITOR_PERSISTENCE_APPLYING = False
_MATERIAL_EDITOR_PERSISTENCE_DIRTY = False
_MATERIAL_EDITOR_RESTORED_SCENES: set[int] = set()

# Scene Materials tab snapshots.  Plain Python containers, never RNA, so
# filling them during draw does not violate unified_contract
# DRAW_MUTATION_ALLOWED.  TTL, cap and eviction step mirror the accepted
# inventory.list_inventory_entries cache; clear_scene_material_caches() below
# is the reachable .clear() the module-cache hygiene rule requires.
_SCENE_MATERIAL_CACHE_TTL = 0.75
_SCENE_MATERIAL_CACHE_LIMIT = 64
_SCENE_MATERIAL_CACHE_EVICT = 16
_SCENE_MATERIAL_PAGE_SIZE = 20
_SCENE_MATERIAL_INDEX_CACHE: dict[tuple, tuple[float, list[dict]]] = {}
_MATERIAL_USER_INDEX_CACHE: dict[tuple, tuple[float, list[dict]]] = {}
# B3-01.  The Scene Materials tab selection is persisted as (name, library),
# which any rename of that datablock invalidates -- including renames this
# feature does not own, such as sss.rename_target in operators.py, which
# writes material.name directly on a pre-existing datablock.  This note lets
# the tab re-find the SAME datablock after such a rename by its session_uid.
#
# It is deliberately a MODULE global and never an RNA property: session_uid is
# stable only within one Blender session and is reassigned when a .blend is
# loaded, so a value that survived into a saved file could later name a
# DIFFERENT datablock.  Keeping it out of the .blend, and clearing it in the
# pre-existing _load_post handler, means a stale uid can never be consulted.
#
# 5.18.252 / R-B01.  The note carries one further state: a TOMBSTONE.  Once a
# selection has been bound to a datablock in this session and that datablock
# goes away, the note is not discarded -- its (name, library) key is kept with
# uid 0 and 'dead' set.  A tombstoned note still applies, so every later
# resolve for that same persisted pair keeps failing closed and the
# persisted-NAME resolution stays unreachable for it.  5.18.251 cleared the
# note on a miss instead, which made the refusal last exactly one resolve.
_SCENE_MATERIAL_SELECTION_UID: dict[str, object] = {}

# 5.18.259.  Only the Standard-tab slot workflow is persisted.  The editor tab
# and every Scene Materials value -- filter, sort, the inspected material and
# the object-list extend flag -- are deliberately absent: they live on the
# WindowManager (SSSME_RuntimeState) and are session-transient by construction,
# so no scene, material or object inventory is ever written to the suite state
# file or into a saved .blend.
_MATERIAL_EDITOR_SETTING_NAMES = (
    'active_index', 'display_mode', 'source_index', 'target_index',
    'show_shaded', 'sample_type', 'checker_background', 'backlight',
    'uv_tiling', 'effect_channel', 'material_browser_choice',
    'node_stack_json', 'current_node', 'current_socket',
)


def _scene_identity(scene) -> int:
    try:
        return int(scene.as_pointer())
    except Exception:
        return id(scene)


#: WindowManager attribute that owns every transient Material Editor value.
RUNTIME_STATE_ATTR = 'sss_material_editor_runtime'


def editor_state(context=None):
    """The transient Material Editor state, or None before registration.

    5.18.259.  The editor tab and the inspected-material identity are session
    state, not document state.  They are held on the WindowManager, which is
    rebuilt when a .blend is loaded and is never written into the file, so the
    tab cannot resurrect a stale material name from a saved document and no
    scene/material/object inventory is persisted anywhere.  Every consumer goes
    through this accessor and tolerates None, so a draw that runs before
    register_properties() degrades to the Standard tab instead of raising.
    """
    ctx = context if context is not None else getattr(bpy, 'context', None)
    try:
        return getattr(getattr(ctx, 'window_manager', None), RUNTIME_STATE_ATTR, None)
    except Exception:
        return None


def _state_save_enabled() -> bool:
    """Read the shared suite switch without importing preferences at module load."""
    try:
        from . import preferences
        return bool(preferences.is_npanel_state_save_enabled())
    except Exception:
        try:
            return bool(storage.npanel_state_save_enabled(default=True))
        except Exception:
            return True


def save_material_editor_settings(scene=None, *, force: bool = False) -> bool:
    """Persist every user-editable Material Editor N-panel value."""
    global _MATERIAL_EDITOR_PERSISTENCE_DIRTY
    if _MATERIAL_EDITOR_PERSISTENCE_APPLYING:
        return False
    scene = scene or getattr(bpy.context, 'scene', None)
    props = getattr(scene, 'sss_material_editor', None) if scene is not None else None
    if props is None:
        return False
    if not force and not _state_save_enabled():
        _MATERIAL_EDITOR_PERSISTENCE_DIRTY = True
        return False
    values = {}
    for name in _MATERIAL_EDITOR_SETTING_NAMES:
        try:
            values[name] = getattr(props, name)
        except Exception:
            pass
    custom = getattr(props, 'custom_sample_object', None)
    values['custom_sample_object'] = getattr(custom, 'name', '') if custom is not None else ''
    slots = []
    for slot in list(getattr(props, 'slots', ()) or ()):
        material = getattr(slot, 'material', None)
        slots.append({
            'name': str(getattr(slot, 'name', '') or ''),
            'material': getattr(material, 'name', '') if material is not None else '',
            'note': str(getattr(slot, 'note', '') or ''),
        })
    saved = bool(storage.write_suite_section('material_editor', {
        'schema_version': 1,
        'settings': values,
        'slots': slots,
    }))
    if saved:
        _MATERIAL_EDITOR_PERSISTENCE_DIRTY = False
    return saved


def restore_material_editor_settings(scene=None, *, force: bool = False) -> bool:
    global _MATERIAL_EDITOR_PERSISTENCE_APPLYING
    # RNA update callbacks can query the active slot while the persisted
    # settings are being assigned.  That query reaches ``ensure_slots`` and
    # would otherwise re-enter this restore before the scene is marked done.
    if _MATERIAL_EDITOR_PERSISTENCE_APPLYING:
        return True
    scene = scene or getattr(bpy.context, 'scene', None)
    props = getattr(scene, 'sss_material_editor', None) if scene is not None else None
    if props is None:
        return False
    key = _scene_identity(scene)
    if key in _MATERIAL_EDITOR_RESTORED_SCENES and not force:
        return True
    payload = storage.read_suite_section('material_editor', {})
    if not isinstance(payload, dict):
        payload = {}
    settings = payload.get('settings', {})
    slots = payload.get('slots', [])
    _MATERIAL_EDITOR_PERSISTENCE_APPLYING = True
    try:
        if isinstance(settings, dict):
            for name in _MATERIAL_EDITOR_SETTING_NAMES:
                if name not in settings or not hasattr(props, name):
                    continue
                try:
                    setattr(props, name, settings[name])
                except Exception:
                    pass
            object_name = str(settings.get('custom_sample_object', '') or '')
            if hasattr(props, 'custom_sample_object'):
                try:
                    props.custom_sample_object = bpy.data.objects.get(object_name) if object_name else None
                except Exception:
                    pass
        if isinstance(slots, list) and slots:
            try:
                props.slots.clear()
            except Exception:
                pass
            for item in slots:
                if not isinstance(item, dict):
                    continue
                try:
                    slot = props.slots.add()
                    slot.name = str(item.get('name', '') or 'Slot')
                    slot.note = str(item.get('note', '') or '')
                    material_name = str(item.get('material', '') or '')
                    slot.material = bpy.data.materials.get(material_name) if material_name else None
                except Exception:
                    pass
    finally:
        _MATERIAL_EDITOR_PERSISTENCE_APPLYING = False
    _MATERIAL_EDITOR_RESTORED_SCENES.add(key)
    return True

# UI terms are authored in English and translated at draw time.  The add-on never
# shows bilingual slash-separated text; it shows only the active UI language.
JA = {
    "Material Editor": "マテリアルエディター",
    "Slots": "スロット",
    "Slot": "スロット",
    "Display": "表示",
    "3 x 2 compact slots": "3 x 2 コンパクトスロット",
    "5 x 3 compact slots": "5 x 3 コンパクトスロット",
    "6 x 4 compact slots": "6 x 4 コンパクトスロット",
    "Unlimited list": "無制限リスト",
    "Active": "アクティブ",
    "Hot": "Hot",
    "Cool": "Cool",
    "Selected": "選択中",
    "Empty": "空",
    "Scene Link": "シーン連携",
    "Assign Material to Selection": "選択に割り当て",
    "Pick Material from Active Object": "アクティブオブジェクトから取得",
    "Pick Material from Shader Editor": "シェーダーエディターから取得",
    "Show in Shader Editor": "シェーダーエディターに表示",
    "Pick Material from Viewport Click": "ビューポートクリックで取得",
    "Select by Material": "マテリアルで選択",
    "Put Material to Scene": "シーンへ適用",
    "Slot Transfer": "スロット転送",
    "Source": "転送元",
    "Target": "転送先",
    "Copy": "コピー",
    "Instance": "インスタンス",
    "Swap": "入れ替え",
    "Preview": "プレビュー",
    "Show Shaded Material in Viewport": "ビューポートでマテリアル表示",
    "Sample Type": "サンプルタイプ",
    "Sphere": "球",
    "Cylinder": "円柱",
    "Cube": "立方体",
    "Custom Object": "カスタムオブジェクト",
    "Checker Background": "チェッカー背景",
    "Backlight": "バックライト",
    "UV Tiling": "UVタイリング",
    "Update Preview Object": "プレビューオブジェクト更新",
    "Video Color Check": "ビデオカラーチェック",
    "Video Safe": "ビデオ安全色",
    "Video Warning": "ビデオ警告",
    "Material / Map Navigator": "マテリアル / マップナビゲーター",
    "Hierarchy": "階層",
    "Current Node": "現在のノード",
    "Go to Parent": "親に戻る",
    "Go Forward to Sibling": "兄弟へ進む",
    "Open Navigator": "ナビゲーターを開く",
    "Map Buttons": "マップボタン",
    "Base Color": "ベースカラー",
    "Metallic": "メタリック",
    "Roughness": "ラフネス",
    "Alpha": "アルファ",
    "Normal": "ノーマル",
    "Bump": "バンプ",
    "Library and Utilities": "ライブラリとユーティリティ",
    "Get Material": "マテリアルを取得",
    "New Material": "新規マテリアル",
    "Browse Scene Materials": "シーン内マテリアルを選択",
    "Load Material Library": "マテリアルライブラリを読み込み",
    "Put to Library": "ライブラリへ保存",
    "Make Unique": "個別化",
    "Reset Slot to Default": "スロットを初期状態へリセット",
    "Effects Channel ID": "エフェクトチャンネルID",
    "Material": "マテリアル",
    "No active material.": "アクティブなマテリアルがありません。",
    "No active slot.": "アクティブスロットがありません。",
    "No selectable material was found.": "取得可能なマテリアルが見つかりません。",
    "No material is open in the Shader Editor.": "シェーダーエディターで開かれているマテリアルがありません。",
    "No editor area is available for the Shader Editor.": "シェーダーエディター表示に使えるエディターエリアがありません。",
    "Preview object updated.": "プレビューオブジェクトを更新しました。",
    "Assigned material to selection.": "選択対象へマテリアルを割り当てました。",
    "Picked material from active object.": "アクティブオブジェクトからマテリアルを取得しました。",
    "Picked material from Shader Editor.": "シェーダーエディターからマテリアルを取得しました。",
    "Displayed active slot material in the Shader Editor.": "アクティブスロットのマテリアルをシェーダーエディターに表示しました。",
    "Picked material from viewport.": "ビューポートからマテリアルを取得しました。",
    "Selected objects or faces by material.": "同じマテリアルのオブジェクトまたは面を選択しました。",
    "Scene synchronized with active slot material.": "アクティブスロットのマテリアルをシーンへ同期しました。",
    "Copied source slot material to target slot.": "転送元スロットのマテリアルを転送先へコピーしました。",
    "Instanced source slot material to target slot.": "転送元スロットのマテリアルを転送先へインスタンス共有しました。",
    "Swapped source and target slots.": "転送元と転送先のスロットを入れ替えました。",
    "Material made unique.": "マテリアルを個別化しました。",
    "Slot reset to default material.": "スロットを初期マテリアルへリセットしました。",
    "Saved material library.": "マテリアルライブラリを保存しました。",
    "Loaded material library.": "マテリアルライブラリを読み込みました。",
    "Created new material.": "新規マテリアルを作成しました。",
    "Selected scene material.": "シーン内マテリアルを選択しました。",
    "Material has no node tree.": "マテリアルにノードツリーがありません。",
    "No linked map exists; a Blender map node was created and linked.": "リンク済みマップが無かったため、Blenderのマップノードを作成して接続しました。",
    "Moved to parent node.": "親ノードへ戻りました。",
    "Moved to sibling node.": "兄弟ノードへ移動しました。",
    "No parent node is stored.": "保存されている親ノードがありません。",
    "No sibling map is available.": "移動可能な兄弟マップがありません。",
    "Safe broadcast approximation.": "放送安全色の近似範囲内です。",
    "Color may exceed broadcast-safe luma or saturation limits.": "色が放送安全色の輝度または彩度の近似範囲を超える可能性があります。",
    "Initialize Slots": "スロット初期化",
    "Add Slot": "スロット追加",
    "Remove Slot": "スロット削除",
    "Clear Slot": "スロットを空にする",
    "Set Active Slot": "アクティブスロットに設定",
    "Material Slot": "マテリアルスロット",
    "Choose Active Object Material Slot": "アクティブオブジェクトのスロットを選択",
    "Pick the material slot to read from the active object.": "アクティブオブジェクトから読み取るマテリアルスロットを選択します。",
    "Custom Sample Object": "カスタムサンプルオブジェクト",
    "Node Parameters": "ノードパラメーター",
    "No editable node is selected.": "編集可能なノードが選択されていません。",
    "Open Node Editor": "ノードエディターを開く",
    "Active slot material": "アクティブスロットのマテリアル",
    "Mode": "モード",
    "Status": "状態",
    "Users": "ユーザー数",
    "Pass Index": "パスインデックス",
    "Library File": "ライブラリファイル",
    "Select Material": "マテリアル選択",
    "Material Name": "マテリアル名",
    "Append all materials from a .blend library file": ".blendライブラリファイルから全マテリアルを追加します",
    "Save active material as a .blend library file": "アクティブマテリアルを.blendライブラリファイルとして保存します",
    "Use active slot material for selected objects or selected mesh faces.": "アクティブスロットのマテリアルを、選択中のオブジェクトまたは選択中のメッシュ面へ割り当てます。",
    "Read the active object's current material and place it in the active compact slot.": "アクティブオブジェクトで現在使われているマテリアルを読み取り、アクティブなコンパクトスロットへ入れます。",
    "Read the material currently displayed or pinned in an open Shader Editor and place it in the active compact slot. Use this after selecting the destination slot in the Material Editor. World shaders and non-shader node editors are ignored.": "開いているシェーダーエディターで現在表示中、またはピン留め中のマテリアルを読み取り、選択中のコンパクトスロットへ登録します。先にマテリアルエディター側で登録先スロットを選択してから実行します。ワールドシェーダーやシェーダー以外のノードエディターは対象外です。",
    "Display the active compact slot material in a Shader Editor. If no Shader Editor is open, an available editor area is switched to the Shader Editor and the material node tree is shown without changing scene material assignments.": "アクティブなコンパクトスロットのマテリアルをシェーダーエディターに表示します。シェーダーエディターが開いていない場合は、使用可能なエディターエリアをシェーダーエディターへ切り替え、シーン内のマテリアル割り当てを変更せずにマテリアルノードツリーを表示します。",
    "Click an object in the 3D View and place its hit-face material in the active compact slot.": "3Dビューでオブジェクトをクリックし、ヒットした面のマテリアルをアクティブなコンパクトスロットへ入れます。",
    "Select every scene object, or matching edit-mode faces, that use the active slot material.": "アクティブスロットのマテリアルを使用しているシーン内オブジェクト、または編集モードの一致面を選択します。",
    "Force objects using duplicate same-base-name materials to use the active slot material.": "同じ基底名を持つ重複マテリアルを使用しているオブジェクトを、アクティブスロットのマテリアルへ強制的に同期します。",
    "Duplicate the material datablock so edits no longer affect other linked users.": "マテリアルデータブロックを複製し、以後の編集が他の共有ユーザーへ影響しない状態にします。",
    "Create a new default Principled BSDF material in the active compact slot.": "アクティブなコンパクトスロットに、標準のPrincipled BSDFマテリアルを新規作成します。",
    "Set material.pass_index from 0 to 15 for compositor or render-pass identification.": "コンポジターやレンダーパス識別に使う パスインデックスを0から15の範囲で設定します。",
}


JA.update({
    'Add an area light behind the sample object to reveal rim highlights, metallic response, cloth sheen, and silhouette readability.': 'サンプルオブジェクトの背後にエリアライトを追加し、リムライト、金属反応、布の光沢、シルエットの見やすさを確認しやすくします。',
    'Add an extra compact material slot. This is the Blender upper-compatible mode beyond the original 24-slot limit.': 'コンパクトマテリアルスロットを1つ追加します。従来の24枠を超えて使える、Blender向けの上位互換モードです。',
    'Append all materials from a .blend library file and place the first loaded material into the active compact slot.': '指定した .blend ライブラリファイルから全マテリアルを追加し、最初に読み込まれたマテリアルをアクティブスロットへ入れます。',
    'Check the active material base color against an approximate broadcast-safe luma and saturation range, similar to the legacy 3ds Max video color check.': 'アクティブマテリアルのベースカラーが、放送安全色に近い輝度・彩度範囲に収まっているかを簡易チェックします。',
    'Choose a 3ds Max compact grid size or the Blender upper-compatible unlimited scrolling list.': '3ds Max風のコンパクトグリッドサイズ、またはBlender向けの無制限スクロールリスト表示を選びます。',
    'Clear the active compact slot while keeping the material datablock in bpy.data.materials if it has other users.': 'アクティブスロットだけを空にします。他で使われているマテリアルはファイル内に残します。',
    'Click an object in the 3D View and place its hit-face material in the active compact slot. This reproduces the compact editor eyedropper.': '3Dビュー内のオブジェクトをクリックし、当たった面のマテリアルをアクティブスロットへ入れます。コンパクトエディターのスポイト操作を再現します。',
    'Read the material currently displayed or pinned in an open Shader Editor and place it in the active compact slot. Use this after selecting the destination slot in the Material Editor. World shaders and non-shader node editors are ignored.': '開いているシェーダーエディターで現在表示中、またはピン留め中のマテリアルを読み取り、選択中のコンパクトスロットへ登録します。先にマテリアルエディター側で登録先スロットを選択してから実行します。ワールドシェーダーやシェーダー以外のノードエディターは対象外です。',
    'Display the active compact slot material in a Shader Editor. If no Shader Editor is open, an available editor area is switched to the Shader Editor and the material node tree is shown without changing scene material assignments.': 'アクティブなコンパクトスロットのマテリアルをシェーダーエディターに表示します。シェーダーエディターが開いていない場合は、使用可能なエディターエリアをシェーダーエディターへ切り替え、シーン内のマテリアル割り当てを変更せずにマテリアルノードツリーを表示します。',
    'Compact material slot label. Use it as a reusable palette position, similar to 3ds Max sample slots.': 'コンパクトマテリアルスロットのラベルです。3ds Maxのサンプルスロットのように、再利用するパレット位置として使います。',
    'Copy, instance-link, or swap compact material slots. Copy creates a new material datablock; Instance shares the same datablock; Swap exchanges slot contents.': 'コンパクトスロット間でコピー、インスタンス共有、入れ替えを行います。コピーは新しいマテリアルデータブロックを作り、インスタンスは同じデータブロックを共有し、入れ替えはスロット内容を交換します。',
    'Create Default Materials': '標準マテリアル作成',
    'Create a new default Principled BSDF material in the active compact slot. The material is a normal Blender datablock and can be edited anywhere.': 'アクティブスロットに標準のPrincipled BSDFマテリアルを新規作成します。通常のBlenderマテリアルデータブロックなので、他の場所からも編集できます。',
    'Create or refresh the Blender-native material sample object using the selected sample type, checker background, backlight, and UV tiling settings.': '選択したサンプル形状、チェッカー背景、バックライト、UVタイリング設定を使って、Blenderネイティブのマテリアル確認用サンプルオブジェクトを作成または更新します。',
    'Create the classic twenty-four compact material editor slots if they do not already exist. Existing slots and materials are preserved.': 'クラシックな24個のコンパクトマテリアルスロットを、まだ存在しない場合に作成します。既存スロットとマテリアルは保持します。',
    'Current Socket': '現在のソケット',
    'Currently edited material/map node in the compact hierarchy navigator.': 'コンパクト階層ナビゲーターで現在編集しているマテリアル／マップノードです。',
    'Duplicate the material datablock so edits no longer affect other linked users. Selected objects using the original active material are redirected to the unique copy.': 'マテリアルデータブロックを複製し、以後の編集が他の共有ユーザーへ影響しない状態にします。元のアクティブマテリアルを使っていた選択オブジェクトは個別コピーへ切り替えます。',
    'Enter Map': 'マップに入る',
    'Fill empty compact slots with default gray Principled BSDF materials, reproducing the populated 3ds Max sample-slot behavior.': '空のコンパクトスロットへ標準のグレーPrincipled BSDFマテリアルを入れ、3ds Maxのサンプルスロットが埋まっている状態に近づけます。',
    'Force objects using duplicate same-base-name materials to use the active slot material. This resolves name conflicts and synchronizes the scene to the slot.': '同じ基底名を持つ重複マテリアルを使っているオブジェクトを、アクティブスロットのマテリアルへ統一します。名前衝突を整理し、シーン側をスロット内容へ同期します。',
    'Go down into the map node connected to the specified material parameter. If no map exists, create a Blender map node and link it.': '指定したマテリアルパラメーターへ接続されたマップノード階層に入ります。マップが無い場合はBlenderのマップノードを作成して接続します。',
    'Index of the currently active compact slot. The active slot is the target for Assign, Pick, preview, hierarchy navigation, and library operations.': '現在アクティブなコンパクトスロットの番号です。割り当て、取得、プレビュー、階層ナビゲーション、ライブラリ操作はこのスロットを対象にします。',
    'Internal parent stack for compact material/map hierarchy navigation.': 'コンパクトマテリアル／マップ階層ナビゲーション用の内部親スタックです。',
    'Make this compact slot active. All editor actions operate on the active slot.': 'このコンパクトスロットをアクティブにします。エディター内の各操作はアクティブスロットを対象に実行されます。',
    'Material stored in this compact editor slot. Assign it to objects, pick it from objects, copy it, instance it, or save it to a library.': 'このコンパクトエディタースロットに保存されているマテリアルです。オブジェクトへ割り当て、オブジェクトから取得、コピー、インスタンス共有、ライブラリ保存に使います。',
    'Move one level up from the current map node to its parent material or parent map, reproducing the compact editor parent navigation button.': '現在のマップノードから親マテリアルまたは親マップへ1階層戻ります。コンパクトエディターの親へ戻るボタンを再現します。',
    'Move to the next linked map under the same parent node, matching the compact editor sibling navigation control.': '同じ親ノードの下にある次のリンク済みマップへ移動します。コンパクトエディターの兄弟マップ移動操作に相当します。',
    'Name of the new Blender material datablock placed into the active compact slot.': 'アクティブスロットへ入れる新しいBlenderマテリアルデータブロックの名前です。',
    'Node Name': 'ノード名',
    'Node Stack': 'ノードスタック',
    'Note': 'メモ',
    'Object used when Sample Type is Custom Object. Its mesh is duplicated for preview so the source object is not modified.': 'サンプルタイプがカスタムオブジェクトのときに使うオブジェクトです。プレビュー用にメッシュを複製するため、元オブジェクトは変更されません。',
    'Open a compact browser of existing bpy.data.materials and place the chosen material into the active slot.': 'ファイル内の既存のマテリアルをコンパクトな選択ダイアログで表示し、選んだマテリアルをアクティブスロットへ入れます。',
    'Open a tree navigator that shows the active slot material and its connected map hierarchy, similar to the 3ds Max Material/Map Navigator.': 'アクティブスロットのマテリアルと接続マップ階層をツリー表示するナビゲーターを開きます。3ds MaxのMaterial/Map Navigatorに近い操作です。',
    'Optional private memo for this material slot. It does not change the Blender material datablock.': 'このマテリアルスロット用の任意メモです。Blenderのマテリアルデータブロック自体は変更しません。',
    'Place a checker plane behind the sample object to evaluate alpha, glass, refraction-like transparency, and edge contrast.': 'サンプルオブジェクトの背後にチェッカー平面を置き、アルファ、ガラス、屈折風の透過、輪郭コントラストを確認しやすくします。',
    'Preview object shape used to inspect the active material, matching the 3ds Max sphere, cylinder, cube, and custom object sample types.': 'アクティブマテリアル確認に使うプレビューオブジェクト形状です。3ds Max風の球、円柱、立方体、カスタムオブジェクトに対応します。',
    "Read the active object's current material and place it in the active compact slot. Use this as the non-modal eyedropper equivalent.": 'アクティブオブジェクトの現在のマテリアルを読み取り、アクティブスロットへ入れます。モーダル操作ではないスポイト相当の機能として使います。',
    'Remove the active compact slot from the palette. The Blender material datablock is not deleted.': 'アクティブスロットをパレットから削除します。Blenderのマテリアルデータブロック自体は削除しません。',
    'Reset the active compact slot to a fresh default Principled BSDF material, matching Reset Map/Mtl to Default Settings.': 'アクティブスロットを新しい標準Principled BSDFマテリアルへ戻します。Reset Map/Mtl to Default Settingsに近い初期化です。',
    'Result of the broadcast-safe color approximation for the active material base color.': 'アクティブマテリアルのベースカラーに対する、放送安全色近似チェックの結果です。',
    'Save active material as a .blend library file. The saved material can be loaded later with Get Material > Load Material Library.': 'アクティブマテリアルを .blend ライブラリファイルとして保存します。保存したマテリアルは「マテリアルを取得 > マテリアルライブラリを読み込み」から後で読み込めます。',
    'Scale preview-object UV coordinates to temporarily inspect 1x1, 2x2, 3x3, or higher texture tiling without modifying the material itself.': 'マテリアル自体を変更せずに、プレビューオブジェクトのUV座標を一時的に拡大し、1x1、2x2、3x3以上のテクスチャタイリングを確認します。',
    'Scene material to place in the active compact slot.': 'アクティブスロットへ入れるシーン内マテリアルです。',
    'Select Node': 'ノード選択',
    'Select every scene object, or matching edit-mode faces, that use the active slot material. This mirrors 3ds Max Select by Material.': 'アクティブスロットのマテリアルを使っているシーン内オブジェクト、または編集モードの一致する面をすべて選択します。3ds MaxのSelect by Materialに相当します。',
    'Select this node in the compact material/map hierarchy and make its socket parameters editable in the panel.': 'コンパクトマテリアル／マップ階層内でこのノードを選択し、パネル内でソケットパラメーターを編集できるようにします。',
    'Slot Index': 'スロット番号',
    'Socket': 'ソケット',
    'Socket name through which the current map node was entered.': '現在のマップノードへ入るときに使ったソケット名です。',
    'Source compact slot index for Copy, Instance, and Swap operations.': 'コピー、インスタンス共有、入れ替え操作で使う転送元コンパクトスロット番号です。',
    'Switch 3D View areas to Material Preview mode so the active material and its texture maps are visible while editing.': '編集中にアクティブマテリアルとテクスチャマップが見えるよう、3Dビューをマテリアルプレビューモードへ切り替えます。',
    'Switch the largest available editor area to Shader Node Editor and select the current map node for detailed Blender-native editing.': '使用可能な最大エリアをシェーダーノードエディターへ切り替え、現在のマップノードを選択してBlenderネイティブの詳細編集を行いやすくします。',
    'Target compact slot index for Copy, Instance, and Swap operations.': 'コピー、インスタンス共有、入れ替え操作で使う転送先コンパクトスロット番号です。',
    'Toggle Material Preview in every 3D View area so texture maps and material shading are visible during compact-editor work.': '全3Dビューのマテリアルプレビュー表示を切り替え、コンパクトエディター作業中にテクスチャマップと材質シェーディングを確認できるようにします。',
    "Use active slot material for selected objects or selected mesh faces. In Object Mode it writes to each object's active material slot; in Edit Mode it writes to selected faces.": 'アクティブスロットのマテリアルを、選択オブジェクトまたは選択メッシュ面へ割り当てます。オブジェクトモードでは各オブジェクトのアクティブマテリアルスロットへ書き込み、編集モードでは選択面へ書き込みます。',
})

JA.update({
    "Material Editor": "マテリアルエディター",
    "Material Editor UI error": "マテリアルエディター UI エラー",
})

# Localization pass 2026-08-19: catalog gaps found by ast inventory.
JA.update({
    'Select Node in Hierarchy': 'ヒエラルキー内のノードを選択',
    'Select the chosen node in the active material node tree and make it the current compact Material Editor node.': '選択したノードをアクティブマテリアルのノードツリー内で選択し、現在のコンパクトマテリアルエディターノードにします。',
    'Name of the material node to select.': '選択するマテリアルノードの名前です。',
    'Show six reusable compact material slots in a 3 by 2 grid.': '再利用可能なコンパクトマテリアルスロット6個を3×2グリッドで表示します。',
    'Show fifteen reusable compact material slots in a 5 by 3 grid.': '再利用可能なコンパクトマテリアルスロット15個を5×3グリッドで表示します。',
    'Show the classic twenty-four reusable compact material slots in a 6 by 4 grid.': '定番の24個の再利用可能なコンパクトマテリアルスロットを6×4グリッドで表示します。',
    'Show all material slots in a scrolling UIList so the palette is not limited to twenty-four slots.': 'すべてのマテリアルスロットをスクロール可能なリストで表示し、パレットを24スロットに制限しません。',
    'Use a UV sphere as the material preview sample.': 'マテリアルプレビューのサンプルとしてUV球を使います。',
    'Use a cylinder as the material preview sample.': 'マテリアルプレビューのサンプルとして円柱を使います。',
    'Use a cube as the material preview sample.': 'マテリアルプレビューのサンプルとして立方体を使います。',
    'Duplicate the selected custom object as the material preview sample.': '選択したカスタムオブジェクトを複製してマテリアルプレビューのサンプルにします。',
    'Duplicate source material datablock into target slot.': 'コピー元のマテリアルデータブロックを複製してコピー先スロットへ入れます。',
    'Assign the exact same material datablock to target slot.': '全く同じマテリアルデータブロックをコピー先スロットへ割り当てます。',
    'Exchange source and target slot contents.': 'コピー元とコピー先のスロット内容を入れ替えます。',
})

JA.update({
    'Scene Materials': 'シーンのマテリアル',
    'Scene': 'シーン',
    'Standard': '標準',
    'Editor Tab': 'エディタータブ',
    'Show the standard compact slot material editor.': '標準のコンパクトスロット マテリアルエディターを表示します。',
    'List every material in the scene and the objects that use it.': 'シーン内のすべてのマテリアルと、それを使用しているオブジェクトを一覧表示します。',
    'List every distinct material used by an object in this scene, and the objects that use it.': 'このシーンのオブジェクトが使用している各マテリアルと、それを使用しているオブジェクトを一覧表示します。',
    'Slots are not initialized.': 'スロットが未初期化です。',
    'The object is no longer in this scene.': 'このオブジェクトはこのシーンに存在しません。',
    'Leave Edit Mode to select an object from this list.': 'この一覧からオブジェクトを選択するには編集モードを終了してください。',
    'No object using this material can be selected.': 'このマテリアルを使用しているオブジェクトのうち、選択できるものはありません。',
    'No object in this scene uses a material.': 'このシーンにはマテリアルを使用しているオブジェクトがありません。',
    'Which Material Editor view is shown.': '表示するマテリアルエディターのビューを選びます。',
    'Search': '検索',
    'Filter the scene material list by name.': 'シーンマテリアル一覧を名前で絞り込みます。',
    'Sort': '並び順',
    'Order of the scene material list.': 'シーンマテリアル一覧の並び順です。',
    'Name': '名前',
    'Scope': '対象範囲',
    'Which materials the scene material list shows.': 'シーンマテリアル一覧に表示するマテリアルの範囲です。',
    'Slot Count': 'スロット数',
    'Sort by name.': '名前順に並べます。',
    'Sort by the number of objects using the material.': 'マテリアルを使用しているオブジェクト数順に並べます。',
    'Sort by the number of material slots using the material.': 'マテリアルを使用しているマテリアルスロット数順に並べます。',
    'All materials': 'すべてのマテリアル',
    'Used in this scene': 'このシーンで使用中',
    'List every material datablock in this file.': 'このファイル内のすべてのマテリアルデータブロックを一覧表示します。',
    'List only materials used by an object in this scene.': 'このシーンのオブジェクトが使用しているマテリアルだけを一覧表示します。',
    'Materials': 'マテリアル',
    'Page': 'ページ',
    'Prev': '前へ',
    'Next': '次へ',
    'Selected Material': '選択中のマテリアル',
    'Objects Using This Material': 'このマテリアルを使用しているオブジェクト',
    'Objects': 'オブジェクト',
    'Extend selection': '選択に追加',
    'Deselect': '選択解除',
    'Keep the current selection and add objects picked from this list.': '現在の選択を保持したまま、この一覧で選んだオブジェクトを追加します。',
    'Select All Objects Using This Material': 'このマテリアルを使用中のすべてのオブジェクトを選択',
    'Put into Active Slot': 'アクティブスロットへ入れる',
    'Put the selected scene material into the active material slot.': '選択中のシーンマテリアルをアクティブなマテリアルスロットへ入れます。',
    'Rename': '名前を変更',
    'Rename the material datablock. Blender keeps material names unique and may add a numeric suffix.': 'マテリアルデータブロックの名前を変更します。Blenderはマテリアル名を一意に保つため、数字の接尾辞を付ける場合があります。',
    'Renamed material.': 'マテリアル名を変更しました。',
    'Enter a new name first.': '先に新しい名前を入力してください。',
    'This material is linked and cannot be renamed here.': 'このマテリアルはリンクされているため、ここでは名前を変更できません。',
    'Linked material. Rename it in its source file.': 'リンクされたマテリアルです。元のファイルで名前を変更してください。',
    'Library override. The name follows the linked material.': 'ライブラリオーバーライドです。名前はリンク元のマテリアルに従います。',
    'Indirectly linked material.': '間接的にリンクされたマテリアルです。',
    'No material is selected.': 'マテリアルが選択されていません。',
    'No object in this scene uses this material.': 'このシーンにこのマテリアルを使用しているオブジェクトはありません。',
    'No material matched the current filter.': '現在の絞り込み条件に一致するマテリアルはありません。',
    'Selection is disabled for this object.': 'このオブジェクトは選択が無効になっています。',
    'Not in the active view layer.': 'アクティブなビューレイヤーにありません。',
    'Hidden in this view layer.': 'このビューレイヤーで非表示です。',
    'Leave Edit Mode to select objects by material.': 'マテリアルでオブジェクトを選択するには編集モードを終了してください。',
    'Selected object.': 'オブジェクトを選択しました。',
    'Deselected object.': 'オブジェクトの選択を解除しました。',
    'Object could not be selected.': 'オブジェクトを選択できませんでした。',
    'Select a material in the Scene Materials list, or move the list page.': 'シーンマテリアル一覧でマテリアルを選択するか、一覧のページを移動します。',
    'Select this object in the scene. Hold Ctrl or Shift to add to the current selection.': 'このオブジェクトをシーン内で選択します。CtrlまたはShiftを押しながらで現在の選択に追加します。',
    'Select every object in this scene that uses the selected material.': '選択中のマテリアルを使用している、このシーン内のすべてのオブジェクトを選択します。',
    'Rename the material shown in the Material Editor. Linked and library-override materials are refused.': 'マテリアルエディターに表示中のマテリアル名を変更します。リンクおよびライブラリオーバーライドのマテリアルは拒否されます。',
    'Material selected in the scene material list. Stored by name so the list never becomes a hidden user of the material.': 'シーンマテリアル一覧で選択中のマテリアルです。名前で保持するため、一覧がマテリアルの隠れたユーザーになることはありません。',
    'Internal page cursor for the scene material list. Not persisted.': 'シーンマテリアル一覧の内部ページカーソルです。保存されません。',
    'Library': 'ライブラリ',
    'Library filepath of the material selected in the scene material list. Empty for a local material.': 'シーンマテリアル一覧で選択中のマテリアルのライブラリファイルパスです。ローカルマテリアルの場合は空になります。',
    'skipped': 'スキップ',
    'object': 'オブジェクト',
    'data': 'データ',
})

_TRANSLATIONS = {
    "ja_JP": {(ctx, key): value for ctx in ("*", "Operator") for key, value in JA.items()}
}


def _is_japanese_ui() -> bool:
    try:
        prefs = bpy.context.preferences.view
        if getattr(prefs, "use_translate_interface", True):
            lang = getattr(prefs, "language", "") or getattr(bpy.app.translations, "locale", "")
            if lang.startswith("ja"):
                return True
        return getattr(bpy.app.translations, "locale", "").startswith("ja")
    except Exception:
        return False


def tr(text: str) -> str:
    return JA.get(text, text) if _is_japanese_ui() else text


def report(operator: Operator, level: set[str], message: str) -> None:
    """Central report entry point, routed through the context-safety gate.

    Blender builds an operator report popup only after the operator returns.
    When the caller has no popup-capable context -- an RNA update callback, a
    timer, or a path that is tearing a screen down -- the message goes to the
    console instead of into Blender's report queue.
    """
    from . import report_safety
    report_safety.safe_report(operator, level, tr(message), tag="SmartShader.material_editor")


def ensure_slots(scene: bpy.types.Scene, minimum: int = SLOT_DEFAULT_COUNT) -> None:
    restore_material_editor_settings(scene)
    props = scene.sss_material_editor
    original_count = len(props.slots)
    while len(props.slots) < minimum:
        slot = props.slots.add()
        slot.name = f"{tr('Slot')} {len(props.slots):02d}"
    if props.active_index < 0:
        props.active_index = 0
    if props.active_index >= len(props.slots):
        props.active_index = max(0, len(props.slots) - 1)
    if props.source_index >= len(props.slots):
        props.source_index = max(0, len(props.slots) - 1)
    if props.target_index >= len(props.slots):
        props.target_index = max(0, len(props.slots) - 1)
    if len(props.slots) != original_count:
        save_material_editor_settings(scene)


def slot_at(scene: bpy.types.Scene, index: int):
    props = getattr(scene, "sss_material_editor", None)
    if props is None:
        return None
    if 0 <= index < len(props.slots):
        return props.slots[index]
    return None


def active_slot(context: bpy.types.Context):
    return slot_at(context.scene, context.scene.sss_material_editor.active_index)


def active_material(context: bpy.types.Context) -> Optional[bpy.types.Material]:
    slot = active_slot(context)
    return slot.material if slot else None


def material_users_in_scene(scene: bpy.types.Scene, mat: bpy.types.Material) -> list[bpy.types.Object]:
    users = []
    if mat is None:
        return users
    for obj in scene.objects:
        if hasattr(obj, "material_slots"):
            for mslot in obj.material_slots:
                if mslot.material == mat:
                    users.append(obj)
                    break
    return users


def material_used_by_object(obj: bpy.types.Object, mat: bpy.types.Material) -> bool:
    if obj is None or mat is None or not hasattr(obj, "material_slots"):
        return False
    return any(mslot.material == mat for mslot in obj.material_slots)


def _material_is_renamable(mat) -> bool:
    """Return True only when Blender will accept a write to ``mat.name``.

    A linked, indirectly linked, or library-overridden material keeps the name
    it carries in its source file.  Every property read here is a read-only RNA
    property on Blender 5.1.2.  ``is_editable`` alone is the modern gate; the
    three explicit checks are kept so the UI can say which case it hit, and so
    the predicate still answers correctly if ``is_editable`` is ever missing.
    """
    if mat is None:
        return False
    if getattr(mat, 'library', None) is not None:
        return False
    if bool(getattr(mat, 'is_library_indirect', False)):
        return False
    if getattr(mat, 'override_library', None) is not None:
        return False
    return bool(getattr(mat, 'is_editable', True))


def _material_link_badge(mat) -> tuple[str, str]:
    """Return (icon, untranslated reason) for a non-editable material."""
    if mat is None:
        return '', ''
    if bool(getattr(mat, 'is_library_indirect', False)):
        return 'LIBRARY_DATA_INDIRECT', 'Indirectly linked material.'
    if getattr(mat, 'override_library', None) is not None:
        return 'LIBRARY_DATA_OVERRIDE', 'Library override. The name follows the linked material.'
    if getattr(mat, 'library', None) is not None:
        return 'LIBRARY_DATA_DIRECT', 'Linked material. Rename it in its source file.'
    return '', ''


def _library_path_of(datablock) -> str:
    """The linked library filepath of an ID, or '' when it is local."""
    try:
        return str(getattr(getattr(datablock, 'library', None), 'filepath', '') or '')
    except Exception:
        return ''


def _verified_by_library(datablock, library_path: str):
    """Return ``datablock`` only if its ACTUAL library equals the requested one.

    MN-04 correction.  Both identity resolvers below key ``bpy.data`` with a
    ``(name, library)`` tuple and, before this check, trusted whatever came
    back.  That made them correct only for as long as the tuple-key contract
    holds exactly as assumed -- and the one failure mode that is NOT
    fails-closed is the tuple being ACCEPTED while ``None`` matches any
    library rather than local-only, which would return a same-named LINKED
    datablock with no exception for the ``try`` to catch.  Re-deriving the
    resolved datablock's own ``library.filepath`` and refusing any mismatch
    makes both resolvers correct by construction regardless of how the
    tuple-key API behaves, which is what retires RT-00 as a load-bearing
    unverified claim.  A refusal is always a refusal: this function never
    substitutes a different datablock, it only returns the requested one or
    None.
    """
    if datablock is None:
        return None
    if _library_path_of(datablock) != (library_path or ''):
        return None
    return datablock


def _material_by_identity(name: str, library_path: str):
    """Resolve a material by (name, library filepath), never by a bare name.

    ``bpy.data`` ID collections accept a ``(name, library)`` tuple key, where
    ``library`` is the linked library's filepath and ``None`` matches only a
    LOCAL datablock; a bare string key returns whichever datablock ``bpy.data``
    happens to hand back first when a local and a linked datablock share a
    name.  ``library_path == ''`` (this feature's persisted default) means
    'the local datablock' and is passed through as ``None``.

    Every call site in this feature that already holds a resolved Material
    (a Scene Materials row, the tab's own persisted selection) derives
    ``library_path`` from that material's own ``.library.filepath``, so the
    lookup is always exact and never guessed.  A caller that supplies only a
    name and means a LINKED material -- something this feature itself never
    does, but a direct ``bpy.ops`` call could -- fails closed: it returns
    None rather than silently retargeting a same-named local datablock.
    Silently retargeting the wrong datablock is the B-01 defect this
    resolver exists to close.
    """
    if not name:
        return None
    try:
        result = bpy.data.materials.get((name, library_path or None))
    except Exception:
        return None
    return _verified_by_library(result, library_path)


def _object_by_identity(name: str, library_path: str):
    """Resolve an object by (name, library filepath). Same rationale as
    _material_by_identity: object names are unique only per library, and
    a bare-name lookup is exactly as ambiguous for objects as it is for
    materials.
    """
    if not name:
        return None
    try:
        result = bpy.data.objects.get((name, library_path or None))
    except Exception:
        return None
    return _verified_by_library(result, library_path)


def _object_identity(obj) -> tuple:
    """The (name, library filepath) pair that uniquely identifies an object.

    This is the object-side counterpart of the material identity pair, and it
    is the ONLY key this feature uses for object membership tests.  A bare
    name is not an identity: a linked object and a local object may carry the
    same name, and ``bpy.data.objects`` distinguishes them only by library.
    """
    try:
        return (str(getattr(obj, 'name', '') or ''), _library_path_of(obj))
    except Exception:
        return ('', '')


def _session_uid_of(datablock) -> int:
    """The datablock's session_uid, or 0 when it has none.

    ``ID.session_uid`` is a read-only int that is unique across every ID
    currently loaded in the session; 0 is Blender's 'unset' sentinel and is
    never a usable identity, so it is normalised away here.
    """
    try:
        return int(getattr(datablock, 'session_uid', 0) or 0)
    except Exception:
        return 0


def _note_scene_material_selection(mat, name: str, library_path: str) -> None:
    """Record the session_uid of the material the tab selection now names.

    Called from the only two writers of scene_material_active_name.  The note
    stores the (name, library) it was taken for so it can only ever be
    consulted for that exact selection.
    """
    uid = _session_uid_of(mat)
    if uid <= 0:
        _SCENE_MATERIAL_SELECTION_UID.clear()
        return
    _SCENE_MATERIAL_SELECTION_UID.clear()
    _SCENE_MATERIAL_SELECTION_UID.update({
        'name': str(name or ''),
        'library': str(library_path or ''),
        'uid': uid,
        'current_name': str(getattr(mat, 'name', '') or ''),
    })


def _tombstone_scene_material_note(name: str, library_path: str) -> None:
    """Record that this selection WAS bound and its datablock is now gone.

    R-B01.  5.18.251 called _SCENE_MATERIAL_SELECTION_UID.clear() here.  That
    refusal was real but lasted exactly one resolve: with no note left,
    _scene_material_note_applies() went False and the NEXT call to
    scene_tab_material took the else branch and resolved the persisted
    (name, library) with _material_by_identity.  Anything that had since taken
    the freed name -- Blender frees a local ID name the moment the ID is
    removed, so a same-named replacement is possible from exactly that instant
    -- silently became the tab's selection, and _ensure_scene_material_note()
    then re-seeded the note onto that impostor, making the retarget sticky.

    A tombstone keeps the (name, library) key and marks it dead.
    _scene_material_note_applies() still returns True for it, so the
    persisted-name branch of scene_tab_material stays unreachable for this
    selection and every later resolve refuses identically.  The tombstone is
    released only by an explicit change of selection (both writers of
    scene_material_active_name call _note_scene_material_selection, which
    rebuilds the note from scratch) or by a .blend load (_load_post clears the
    whole note).  It is NOT released by snapshot invalidation: see
    clear_scene_material_snapshots.
    """
    _SCENE_MATERIAL_SELECTION_UID.clear()
    _SCENE_MATERIAL_SELECTION_UID.update({
        'name': str(name or ''),
        'library': str(library_path or ''),
        'uid': 0,
        'current_name': '',
        'dead': True,
    })


def _ensure_scene_material_note(mat, name: str, library_path: str) -> None:
    """Take a note for a selection that resolved by name and has none yet.

    The two operator writers cover selections made in this session, but a
    selection restored from a saved .blend arrives with no note at all -- and
    that is precisely the state a user is in when they open a file and press
    Rename Target.  Seeding the note the first time the selection resolves
    closes that window.  This mutates a module dict, never RNA, so it is safe
    on a draw path.

    R-B01: it must never RESURRECT a tombstone.  A tombstoned selection has
    already been refused; re-seeding it from a name lookup is precisely the
    retarget the tombstone exists to prevent.  Only an explicit user selection
    may establish a new identity for that pair.  This guard is defence in
    depth -- scene_tab_material cannot reach this function for a tombstoned
    selection, because a tombstoned note applies.
    """
    note = _SCENE_MATERIAL_SELECTION_UID
    if (note.get('dead')
            and note.get('name') == str(name or '')
            and note.get('library') == str(library_path or '')):
        return
    if (note
            and note.get('name') == str(name or '')
            and note.get('library') == str(library_path or '')):
        note['current_name'] = str(getattr(mat, 'name', '') or '')
        return
    _note_scene_material_selection(mat, name, library_path)


def _scene_material_note_applies(name: str, library_path: str) -> bool:
    """True when the recorded note was taken for exactly this selection.

    R-B01: a TOMBSTONED note (uid 0, 'dead' set) still APPLIES.  That is the
    whole mechanism of the durable refusal -- while the note applies,
    scene_tab_material never reaches the persisted-name resolution, so a
    same-named replacement cannot be bound to this selection.
    """
    note = _SCENE_MATERIAL_SELECTION_UID
    if not note:
        return False
    if note.get('name') != str(name or ''):
        return False
    if note.get('library') != str(library_path or ''):
        return False
    return int(note.get('uid') or 0) > 0 or bool(note.get('dead'))


def _scene_material_note_is_dead(name: str, library_path: str) -> bool:
    """True when this exact selection carries a tombstone."""
    note = _SCENE_MATERIAL_SELECTION_UID
    if not _scene_material_note_applies(name, library_path):
        return False
    return bool(note.get('dead'))


def _scene_material_by_selection_uid(name: str, library_path: str):
    """Re-find the material the tab selection actually IS, by session_uid.

    This cannot retarget.  session_uid is unique among every ID loaded in the
    session, so a match is by construction the same datablock the user picked;
    the library is re-derived and verified on top of that; and the note is
    dropped by _load_post, so a uid from a previous file is never consulted.
    A miss returns None and the caller fails the selection closed -- it must
    never fall back to the name, because after a rename that name may belong
    to an unrelated datablock.

    R-B01: a TOMBSTONED note refuses immediately.  It records that this
    selection was bound and its datablock is gone, so there is nothing left to
    scan for and the refusal must be returned unchanged for as long as the
    selection stands.
    """
    if not _scene_material_note_applies(name, library_path):
        return None
    note = _SCENE_MATERIAL_SELECTION_UID
    if note.get('dead'):
        return None
    uid = int(note.get('uid') or 0)
    library = str(library_path or '')
    # Fast path: the name this datablock carried when it was last resolved.
    # In the ordinary case -- nothing renamed it -- this is a single keyed
    # lookup and no scan happens on the draw path.
    current = str(note.get('current_name') or '')
    if current:
        mat = _material_by_identity(current, library)
        if mat is not None and _session_uid_of(mat) == uid:
            return mat
    for mat in getattr(bpy.data, 'materials', ()):
        if _session_uid_of(mat) != uid:
            continue
        if _library_path_of(mat) != library:
            return None
        note['current_name'] = str(getattr(mat, 'name', '') or '')
        return mat
    return None


def clear_scene_material_snapshots() -> None:
    """Drop the Scene Materials list snapshots ONLY.

    This is exactly what 5.18.251's clear_scene_material_caches() did at every
    one of its mid-session call sites, and it is what those call sites still
    need: a filter change, a rename and a row selection all invalidate the
    cached row lists, and none of them invalidates WHICH DATABLOCK the tab is
    bound to.

    R-B01 requires the split.  The selection note -- including a tombstone --
    is selection state, not a snapshot.  If a mid-session snapshot
    invalidation dropped it, a user who merely changed the list filter after
    the selected material was removed would put scene_tab_material back on the
    persisted-name path and reopen the retarget.  So the note is cleared only
    by clear_scene_material_caches() below (the two terminal register paths)
    and by _load_post.
    """
    _SCENE_MATERIAL_INDEX_CACHE.clear()
    _MATERIAL_USER_INDEX_CACHE.clear()


def clear_scene_material_caches() -> None:
    """Drop EVERY module-level Scene Materials cache, selection note included.

    Called from the terminal register_properties and unregister_properties.
    Keeping this a named module function in this same file is what satisfies
    the suite module-cache hygiene rule.

    R-N01.  _SCENE_MATERIAL_SELECTION_UID is the third module-level cache this
    feature owns.  Blender keeps the module in sys.modules across an add-on
    disable/enable, so a note taken before a disable would otherwise still be
    consulted after the re-enable.  Clearing it here puts every cache this
    feature adds under the same terminal hygiene as the two snapshots.
    """
    clear_scene_material_snapshots()
    _SCENE_MATERIAL_SELECTION_UID.clear()


def _scene_material_cache_fetch(cache: dict, key):
    entry = cache.get(key)
    if entry is None:
        return None
    if time.monotonic() - entry[0] >= _SCENE_MATERIAL_CACHE_TTL:
        return None
    return entry[1]


def _scene_material_cache_store(cache: dict, key, payload) -> None:
    cache[key] = (time.monotonic(), payload)
    if len(cache) > _SCENE_MATERIAL_CACHE_LIMIT:
        for stale_key in list(cache.keys())[:_SCENE_MATERIAL_CACHE_EVICT]:
            cache.pop(stale_key, None)


def _scene_object_list(scene) -> list:
    try:
        return list(getattr(scene, 'objects', ()) or ())
    except Exception:
        return []


def _object_material_hits(obj) -> dict:
    """Map material identity key -> {'material', 'object': [i], 'data': [i]}.

    Two passes, neither redundant.  ``obj.material_slots[i].material`` is the
    RESOLVED material and therefore honours ``MaterialSlot.link``: it is the
    only view that sees an OBJECT-link assignment.  ``obj.data.materials[i]``
    is the mesh-level material regardless of link: it is the only view that
    sees a DATA assignment sitting underneath an OBJECT-link override.

    Using one pass alone reproduces one of the two blind spots this codebase
    already has -- material_users_in_scene reads slots only, and
    core._object_material_collection reads data only.  This is the single
    definition of the union rule; both consumers below share it so they can
    never disagree with each other.  The dict key here is a per-draw session
    identity (_material_preview_request_key), which is fine: it only groups
    hits within one call, it is never persisted and never used to resolve a
    material back from a name.
    """
    hits: dict = {}
    try:
        slots = list(getattr(obj, 'material_slots', ()) or ())
    except Exception:
        slots = []
    for index, mslot in enumerate(slots):
        entry = getattr(mslot, 'material', None)
        if entry is None:
            continue
        entry_key = _material_preview_request_key(entry)
        if not entry_key:
            continue
        bucket = hits.setdefault(entry_key, {'material': entry, 'object': [], 'data': []})
        if str(getattr(mslot, 'link', 'DATA') or 'DATA') == 'OBJECT':
            bucket['object'].append(index)
        elif index not in bucket['data']:
            bucket['data'].append(index)
    try:
        data_materials = getattr(getattr(obj, 'data', None), 'materials', None)
        entries = list(data_materials) if data_materials is not None else []
    except Exception:
        entries = []
    for index, entry in enumerate(entries):
        if entry is None:
            continue
        entry_key = _material_preview_request_key(entry)
        if not entry_key:
            continue
        bucket = hits.setdefault(entry_key, {'material': entry, 'object': [], 'data': []})
        if index not in bucket['data']:
            bucket['data'].append(index)
    return hits


def _view_layer_object_identities(context) -> set:
    """(name, library) identities of every object in the active view layer.

    M2-02 correction.  The rejected design tested view-layer membership with a
    set of bare NAMES, so a LINKED object sharing a name with a local object
    that IS in the view layer was reported in_view_layer=True and
    selectable=True, with no badge and a wrong reason string.  The operator
    still failed closed at select_set(), but the row lied and the error
    misattributed the cause.  Membership is an identity question, so it is
    asked with the same (name, library) pair every resolver in this feature
    uses.
    """
    try:
        view_layer = getattr(context, 'view_layer', None)
        return {_object_identity(obj) for obj in (getattr(view_layer, 'objects', ()) or ())}
    except Exception:
        return set()


def _scene_object_identities(scene) -> set:
    """(name, library) identities of every object in the scene. See M2-02."""
    try:
        return {_object_identity(obj) for obj in (getattr(scene, 'objects', ()) or ())}
    except Exception:
        return set()


def _view_layer_identity(context) -> int:
    """Identify the active view layer for cache-key purposes.

    material_object_users' cached rows encode in_view_layer, selectable and
    the hide_get() result, all derived from context.view_layer.  Two windows
    on the same Scene with different active view layers must not share a
    cache entry within the TTL -- scene identity alone cannot tell them
    apart, which is finding M-03.  ViewLayer is not an ID datablock (it has
    no session_uid); as_pointer() is the identity every other cache key in
    this feature already relies on for non-ID objects.
    """
    try:
        return int(context.view_layer.as_pointer())
    except Exception:
        return 0


def _slot_epoch(objects) -> int:
    total = 0
    for obj in objects:
        try:
            total += len(getattr(obj, 'material_slots', ()) or ())
        except Exception:
            pass
    return total


def material_object_users(context, mat) -> list:
    """Every object in the context scene that uses ``mat``, with slot origin."""
    scene = getattr(context, 'scene', None)
    if mat is None or scene is None:
        return []
    objects = _scene_object_list(scene)
    material_key = _material_preview_request_key(mat)
    key = (
        _scene_identity(scene), material_key, len(objects), _slot_epoch(objects),
        _view_layer_identity(context),
    )
    cached = _scene_material_cache_fetch(_MATERIAL_USER_INDEX_CACHE, key)
    if cached is not None:
        return [dict(row) for row in cached]
    view_layer_identities = _view_layer_object_identities(context)
    rows: list = []
    for obj in objects:
        bucket = _object_material_hits(obj).get(material_key)
        if not bucket:
            continue
        identity = _object_identity(obj)
        name = identity[0]
        # M2-02: identity membership, never a bare-name set.
        in_view_layer = identity in view_layer_identities
        hide_select = bool(getattr(obj, 'hide_select', False))
        hidden = False
        if in_view_layer:
            try:
                hidden = bool(obj.hide_get())
            except Exception:
                hidden = False
        if not in_view_layer:
            reason = 'Not in the active view layer.'
        elif hide_select:
            reason = 'Selection is disabled for this object.'
        elif hidden:
            reason = 'Hidden in this view layer.'
        else:
            reason = ''
        rows.append({
            'name': name,
            'object_library': identity[1],
            'object_type': str(getattr(obj, 'type', '') or ''),
            'slots_object': sorted(bucket['object']),
            'slots_data': sorted(bucket['data']),
            # 5.18.259: a hidden object is NOT selectable.  Blender ignores
            # select_set on it, and SSSME_OT_select_material_user refuses it
            # rather than unhiding it, so the row must agree with the operator
            # instead of offering an enabled button that silently does nothing.
            'selectable': bool(in_view_layer and not hide_select and not hidden),
            'hidden': hidden,
            'reason': reason,
            'linked': bool(identity[1]),
            'in_view_layer': in_view_layer,
        })
    rows.sort(key=lambda row: (core.library_name_key(row['name']), row['name'], row['object_library']))
    _scene_material_cache_store(_MATERIAL_USER_INDEX_CACHE, key, [dict(row) for row in rows])
    return rows


def scene_material_index(context) -> list:
    """Ordered snapshot of the CURRENT SCENE's materials for the live settings.

    5.18.259.  Membership is derived only from the objects that are in
    ``context.scene`` right now, through ``_object_material_hits``, which reads
    every material slot of every object -- object-linked and data-linked alike
    -- and therefore includes objects that are hidden or excluded from the view
    layer, because ``scene.objects`` does not filter on visibility.  Three
    consequences follow by construction and are the whole point of building the
    list from the usage map instead of from ``bpy.data.materials``:

    * an unused material datablock is never listed, because it produces no hit;
    * a material used only by objects in ANOTHER scene is never listed, because
      this scene's objects never reference it;
    * one material used by many objects, or many times on one object, is listed
      exactly once, because the usage map is keyed by datablock identity
      (``session_uid``) and the material is carried on the bucket.

    The former ALL/SCENE_USED scope switch is gone: 'every material datablock in
    this file' is not a scene material list, and offering it was the one way
    this tab could show a material this scene does not use.
    """
    scene = getattr(context, 'scene', None)
    if scene is None:
        return []
    state = editor_state(context)
    sort_mode = str(getattr(state, 'scene_material_sort', 'NAME') or 'NAME')
    query = str(getattr(state, 'scene_material_filter', '') or '').strip().casefold()
    objects = _scene_object_list(scene)
    materials = _safe_materials()
    key = (
        _scene_identity(scene), sort_mode, query,
        len(materials), len(objects), _slot_epoch(objects),
    )
    cached = _scene_material_cache_fetch(_SCENE_MATERIAL_INDEX_CACHE, key)
    if cached is not None:
        return [dict(row) for row in cached]
    usage: dict = {}
    for obj in objects:
        for entry_key, bucket in _object_material_hits(obj).items():
            counts = usage.setdefault(entry_key, {'material': bucket['material'], 'objects': 0, 'slots': 0})
            counts['objects'] += 1
            counts['slots'] += len(bucket['object']) + len(bucket['data'])
    rows: list = []
    for entry_key, counts in usage.items():
        mat = counts.get('material')
        name = str(getattr(mat, 'name', '') or '')
        if not name:
            continue
        object_count = int(counts.get('objects', 0) or 0)
        slot_count = int(counts.get('slots', 0) or 0)
        if object_count <= 0:
            continue
        if query and query not in name.casefold():
            continue
        badge_icon, badge_reason = _material_link_badge(mat)
        rows.append({
            'name': name,
            'library_path': _library_path_of(mat),
            'object_count': object_count,
            'slot_count': slot_count,
            'users': int(getattr(mat, 'users', 0) or 0),
            'renamable': _material_is_renamable(mat),
            'badge_icon': badge_icon,
            'badge_reason': badge_reason,
            'session_key': _material_preview_request_key(mat),
        })
    # (name, library_path) is a unique key in bpy.data, so library_path is
    # always the sort's real final tiebreaker -- two rows can never tie past
    # it.  session_key stays on the row for internal use only: it is
    # per-session and unstable across a reload, so it must never be part of
    # a sort key (this is the R1 review's ordering-determinism finding).
    if sort_mode == 'USERS':
        rows.sort(key=lambda row: (-row['object_count'], -row['slot_count'],
                                   core.library_name_key(row['name']), row['name'], row['library_path']))
    elif sort_mode == 'SLOTS':
        rows.sort(key=lambda row: (-row['slot_count'], -row['object_count'],
                                   core.library_name_key(row['name']), row['name'], row['library_path']))
    else:
        rows.sort(key=lambda row: (core.library_name_key(row['name']), row['name'], row['library_path']))
    _scene_material_cache_store(_SCENE_MATERIAL_INDEX_CACHE, key, [dict(row) for row in rows])
    return rows


def scene_tab_material(context):
    """Resolve the Scene Materials tab selection by (name, library)."""
    state = editor_state(context)
    if state is None:
        return None
    name = str(getattr(state, 'scene_material_active_name', '') or '')
    if not name:
        return None
    library_path = str(getattr(state, 'scene_material_active_library', '') or '')
    # B3-01.  When this session recorded WHICH datablock the selection is, that
    # recording is authoritative and is consulted FIRST.  Resolving by the
    # persisted name first would be wrong in both directions: after
    # sss.rename_target renames the selected material the name no longer finds
    # it (the orphan), and if anything then takes the freed name -- a new local
    # material, or a linked one that was always there -- the name would resolve
    # onto a DIFFERENT datablock and silently retarget the tab.  session_uid
    # cannot do either.
    if _scene_material_note_applies(name, library_path):
        mat = _scene_material_by_selection_uid(name, library_path)
        if mat is not None:
            return mat
        # The datablock this selection names is gone.  Fail closed, and KEEP
        # failing closed: tombstone the note instead of discarding it, so this
        # branch is re-entered on every later resolve for the same persisted
        # pair.  Discarding it (5.18.251) made the refusal last exactly one
        # resolve -- the next call fell through to the name below and bound the
        # tab to whatever had taken it.  Nothing after this if-statement is
        # reachable once a note applies.
        _tombstone_scene_material_note(name, library_path)
        return None
    mat = _material_by_identity(name, library_path)
    if mat is None:
        return None
    # A persisted selection without a session note is allowed to seed one only
    # from the current scene's live rows.  Otherwise an unrelated datablock
    # created later with a freed old name would silently become the tab target.
    # The identity comparison deliberately uses the same (name, library) pair
    # as the index, so a genuine selected material in this scene remains valid.
    identity = (str(getattr(mat, 'name', '') or ''), _library_path_of(mat))
    if not any((str(row.get('name', '') or ''),
                str(row.get('library_path', '') or '')) == identity
               for row in scene_material_index(context)):
        return None
    _ensure_scene_material_note(mat, name, library_path)
    return mat


def scene_tab_material_identity(context):
    """The (name, library) the tab selection CURRENTLY resolves to, or None.

    Row highlighting must agree with the detail box, so it has to compare
    against the resolved datablock's live identity rather than the persisted
    name, which an external rename leaves stale.
    """
    mat = scene_tab_material(context)
    if mat is None:
        return None
    return (str(getattr(mat, 'name', '') or ''), _library_path_of(mat))


def material_status(context: bpy.types.Context, mat: Optional[bpy.types.Material]) -> tuple[str, str, str]:
    """Return (key, label, icon) for the Max-like Hot/Cool status."""
    if mat is None:
        return "EMPTY", tr("Empty"), "BLANK1"
    users = material_users_in_scene(context.scene, mat)
    selected = any(obj.select_get() for obj in users if hasattr(obj, "select_get"))
    if selected:
        return "SELECTED", "◆ " + tr("Selected"), "RADIOBUT_ON"
    if users:
        return "HOT", "▲ " + tr("Hot"), "MATERIAL"
    return "COOL", "○ " + tr("Cool"), "MATERIAL_DATA"


def make_default_material(name: str) -> bpy.types.Material:
    mat = bpy.data.materials.new(name=name)
    mat.diffuse_color = (0.8, 0.8, 0.8, 1.0)
    mat.use_nodes = True
    principled = get_principled_node(mat)
    if principled:
        set_socket_value(principled, "Base Color", (0.8, 0.8, 0.8, 1.0))
        set_socket_value(principled, "Roughness", 0.5)
    return mat


def get_or_create_default_slot_material(index: int) -> bpy.types.Material:
    base = f"{DEFAULT_MATERIAL_PREFIX} {index + 1:02d}"
    mat = bpy.data.materials.get(base)
    if mat is None:
        mat = make_default_material(base)
    return mat


def fresh_default_slot_material(index: int) -> bpy.types.Material:
    """A new default material for the slot; an earlier one that was edited is not reused."""
    base = f"{DEFAULT_MATERIAL_PREFIX} {index + 1:02d}"
    earlier = bpy.data.materials.get(base)
    fresh = make_default_material(base)
    if earlier is not None and earlier.users == 0:
        bpy.data.materials.remove(earlier)
        fresh.name = base
    return fresh


def get_principled_node(mat: Optional[bpy.types.Material]) -> Optional[bpy.types.Node]:
    if mat is None or not mat.use_nodes or mat.node_tree is None:
        return None
    for node in mat.node_tree.nodes:
        if node.bl_idname == "ShaderNodeBsdfPrincipled":
            return node
    return None


def get_material_output_node(mat: bpy.types.Material) -> Optional[bpy.types.Node]:
    if mat is None or not mat.use_nodes or mat.node_tree is None:
        return None
    for node in mat.node_tree.nodes:
        if node.bl_idname == "ShaderNodeOutputMaterial":
            return node
    return None


def socket_by_name(node: bpy.types.Node, name: str):
    if node is None:
        return None
    if name in node.inputs:
        return node.inputs[name]
    # Blender versions may localize display names or slightly rename sockets.
    lowered = name.lower()
    aliases = {
        "base color": {"base color", "color", "diffuse color"},
        "metallic": {"metallic", "metalness"},
        "roughness": {"roughness"},
        "alpha": {"alpha", "opacity"},
        "normal": {"normal"},
    }
    candidates = aliases.get(lowered, {lowered})
    for sock in node.inputs:
        if sock.name.lower() in candidates:
            return sock
    return None


def set_socket_value(node: bpy.types.Node, socket_name: str, value) -> bool:
    sock = socket_by_name(node, socket_name)
    if sock and hasattr(sock, "default_value"):
        try:
            sock.default_value = value
            return True
        except Exception:
            return False
    return False


def get_socket_value(node: bpy.types.Node, socket_name: str, fallback=None):
    sock = socket_by_name(node, socket_name)
    if sock and hasattr(sock, "default_value"):
        return sock.default_value
    return fallback


def material_base_color(mat: bpy.types.Material) -> tuple[float, float, float, float]:
    principled = get_principled_node(mat)
    if principled:
        value = get_socket_value(principled, "Base Color", None)
        if value is not None:
            try:
                return tuple(value[:4])
            except Exception:
                pass
    return tuple(mat.diffuse_color)


def object_supports_materials(obj: bpy.types.Object) -> bool:
    return obj is not None and hasattr(obj.data, "materials")


def material_index_in_object(obj: bpy.types.Object, mat: bpy.types.Material) -> int:
    if not object_supports_materials(obj):
        return -1
    for i, existing in enumerate(obj.data.materials):
        if existing == mat:
            return i
    obj.data.materials.append(mat)
    return len(obj.data.materials) - 1


def assign_material_to_object_slot(obj: bpy.types.Object, mat: bpy.types.Material, context: Optional[bpy.types.Context] = None) -> bool:
    if not object_supports_materials(obj):
        return False
    if context is not None:
        try:
            return bool(core.set_material_on_object(obj, mat, core.assign_mode(context), context=context))
        except Exception:
            pass
    if len(obj.data.materials) == 0:
        obj.data.materials.append(mat)
        obj.active_material_index = 0
    else:
        idx = max(0, min(obj.active_material_index, len(obj.data.materials) - 1))
        obj.data.materials[idx] = mat
        obj.active_material_index = idx
    return True


def assign_material_to_selected_faces(context: bpy.types.Context, mat: bpy.types.Material) -> int:
    if bmesh is None:
        return 0
    count = 0
    edit_objects = getattr(context, "objects_in_mode_unique_data", []) or []
    for obj in edit_objects:
        if obj.type != "MESH" or not object_supports_materials(obj):
            continue
        index = material_index_in_object(obj, mat)
        bm = bmesh.from_edit_mesh(obj.data)
        for face in bm.faces:
            if face.select:
                face.material_index = index
                count += 1
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    return count


def select_faces_by_material(context: bpy.types.Context, mat: bpy.types.Material) -> int:
    if bmesh is None:
        return 0
    selected = 0
    edit_objects = getattr(context, "objects_in_mode_unique_data", []) or []
    for obj in edit_objects:
        if obj.type != "MESH" or not object_supports_materials(obj):
            continue
        indices = [i for i, existing in enumerate(obj.data.materials) if existing == mat]
        if not indices:
            continue
        bm = bmesh.from_edit_mesh(obj.data)
        for face in bm.faces:
            hit = face.material_index in indices
            face.select_set(hit)
            if hit:
                selected += 1
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    return selected


def _active_object_material_entries(context: bpy.types.Context) -> list[tuple[int, bpy.types.Material]]:
    obj = getattr(context, "object", None) or getattr(context, "active_object", None)
    if obj is None or not hasattr(obj, "material_slots"):
        return []
    entries: list[tuple[int, bpy.types.Material]] = []
    try:
        slots = obj.material_slots
    except Exception:
        return []
    for index, mslot in enumerate(slots):
        try:
            mat = mslot.material
        except Exception:
            mat = None
        if isinstance(mat, bpy.types.Material):
            entries.append((index, mat))
    return entries


def current_object_material(context: bpy.types.Context, slot_index: int | None = None) -> Optional[bpy.types.Material]:
    obj = getattr(context, "object", None) or getattr(context, "active_object", None)
    if obj is None or not hasattr(obj, "material_slots") or len(obj.material_slots) == 0:
        return None
    if slot_index is None:
        idx = max(0, min(obj.active_material_index, len(obj.material_slots) - 1))
    else:
        idx = max(0, min(int(slot_index), len(obj.material_slots) - 1))
    mslot = obj.material_slots[idx]
    return mslot.material


_ME_ACTIVE_OBJECT_SLOT_ITEMS: list[tuple[str, str, str, str, int]] = []
_ME_ACTIVE_OBJECT_SLOT_MAP: dict[str, int] = {}


def _active_object_material_slot_enum_items(self, context):
    global _ME_ACTIVE_OBJECT_SLOT_ITEMS, _ME_ACTIVE_OBJECT_SLOT_MAP
    scene = getattr(context, "scene", None)
    items: list[tuple[str, str, str, str, int]] = []
    mapping: dict[str, int] = {}
    for order, (slot_index, mat) in enumerate(_active_object_material_entries(context)):
        name = str(getattr(mat, "name", "") or tr("Material"))
        token = f"SLOT_{slot_index:03d}"
        label = f"{slot_index + 1}: {name}"
        desc = tr("Pick the material slot to read from the active object.")
        items.append((token, label, desc, "MATERIAL", order))
        mapping[token] = slot_index
    if not items:
        items = [("NO_MATERIAL", tr("No selectable material was found."), tr("No selectable material was found."), "ERROR", 0)]
        mapping["NO_MATERIAL"] = -1
    _ME_ACTIVE_OBJECT_SLOT_ITEMS = items
    _ME_ACTIVE_OBJECT_SLOT_MAP = mapping
    return _ME_ACTIVE_OBJECT_SLOT_ITEMS


def _active_object_material_slot_token_for_index(slot_index: int) -> str:
    token = f"SLOT_{max(0, int(slot_index)):03d}"
    return token if token in _ME_ACTIVE_OBJECT_SLOT_MAP else next(iter(_ME_ACTIVE_OBJECT_SLOT_MAP), "NO_MATERIAL")


def _object_active_material(obj: Optional[bpy.types.Object]) -> Optional[bpy.types.Material]:
    if obj is None:
        return None
    try:
        direct = getattr(obj, "active_material", None)
    except Exception:
        direct = None
    if isinstance(direct, bpy.types.Material):
        return direct
    if not hasattr(obj, "material_slots") or len(obj.material_slots) == 0:
        return None
    try:
        idx = max(0, min(int(getattr(obj, "active_material_index", 0)), len(obj.material_slots) - 1))
        return obj.material_slots[idx].material
    except Exception:
        return None


def _material_from_candidate_id(candidate) -> Optional[bpy.types.Material]:
    if candidate is None:
        return None
    if isinstance(candidate, bpy.types.Material):
        return candidate
    if isinstance(candidate, bpy.types.Object):
        return _object_active_material(candidate)
    return None


def _node_tree_pointer(tree) -> int:
    if tree is None:
        return 0
    try:
        return int(tree.as_pointer())
    except Exception:
        return 0


def _shader_space_node_tree_pointers(space) -> set[int]:
    pointers: set[int] = set()
    for attr in ("id", "node_tree", "edit_tree"):
        try:
            item = getattr(space, attr, None)
        except Exception:
            item = None
        if isinstance(item, bpy.types.Material):
            item = item.node_tree
        pointer = _node_tree_pointer(item)
        if pointer:
            pointers.add(pointer)
    try:
        for path_item in getattr(space, "path", []) or []:
            try:
                pointer = _node_tree_pointer(getattr(path_item, "node_tree", None))
            except Exception:
                pointer = 0
            if pointer:
                pointers.add(pointer)
    except Exception:
        pass
    return pointers


def _material_from_shader_space(space, context: Optional[bpy.types.Context] = None) -> Optional[bpy.types.Material]:
    if space is None or getattr(space, "type", "") != "NODE_EDITOR":
        return None
    if str(getattr(space, "tree_type", "") or "") != "ShaderNodeTree":
        return None

    for attr in ("id", "id_from"):
        try:
            mat = _material_from_candidate_id(getattr(space, attr, None))
        except Exception:
            mat = None
        if mat is not None:
            return mat

    tree_pointers = _shader_space_node_tree_pointers(space)
    if tree_pointers:
        for mat in _safe_materials():
            try:
                if _node_tree_pointer(getattr(mat, "node_tree", None)) in tree_pointers:
                    return mat
            except Exception:
                continue

    if context is not None and getattr(context, "space_data", None) is space:
        try:
            mat = getattr(context, "material", None)
        except Exception:
            mat = None
        if isinstance(mat, bpy.types.Material):
            return mat
    return None


def _iter_shader_editor_spaces(context: bpy.types.Context):
    seen: set[int] = set()

    def add_space(space):
        if space is None or getattr(space, "type", "") != "NODE_EDITOR":
            return None
        if str(getattr(space, "tree_type", "") or "") != "ShaderNodeTree":
            return None
        try:
            pointer = int(space.as_pointer())
        except Exception:
            pointer = id(space)
        if pointer in seen:
            return None
        seen.add(pointer)
        return space

    current = add_space(getattr(context, "space_data", None))
    if current is not None:
        yield current

    screen = getattr(context, "screen", None)
    if screen is None:
        return
    for area in getattr(screen, "areas", []) or []:
        if getattr(area, "type", "") != "NODE_EDITOR":
            continue
        for space in getattr(area, "spaces", []) or []:
            candidate = add_space(space)
            if candidate is not None:
                yield candidate


def shader_editor_material(context: bpy.types.Context) -> Optional[bpy.types.Material]:
    for space in _iter_shader_editor_spaces(context):
        mat = _material_from_shader_space(space, context)
        if mat is not None:
            return mat
    return None


def ensure_material_node_tree(mat: bpy.types.Material):
    if mat is None:
        return None
    try:
        if not getattr(mat, "use_nodes", False) or getattr(mat, "node_tree", None) is None:
            mat.use_nodes = True
    except Exception:
        pass
    return getattr(mat, "node_tree", None)


def _shader_editor_target(context: bpy.types.Context):
    screen = getattr(context, "screen", None)
    if screen is None:
        return None, None

    for area in getattr(screen, "areas", []) or []:
        if getattr(area, "type", "") != "NODE_EDITOR":
            continue
        for space in getattr(area, "spaces", []) or []:
            if getattr(space, "type", "") == "NODE_EDITOR":
                return area, space

    candidates = [
        area for area in (getattr(screen, "areas", []) or [])
        if getattr(area, "type", "") not in {"TOPBAR", "STATUSBAR"}
    ]
    if not candidates:
        return None, None
    area = max(candidates, key=lambda item: getattr(item, "width", 0) * getattr(item, "height", 0))
    try:
        area.type = "NODE_EDITOR"
    except Exception:
        return None, None
    for space in getattr(area, "spaces", []) or []:
        if getattr(space, "type", "") == "NODE_EDITOR":
            return area, space
    return area, getattr(getattr(area, "spaces", None), "active", None)


# Node editor space pointer -> Material pointer of a tree pinned through path.start().
# Blender keeps such a tree without tracking its owner, so deleting the material
# would leave the editor reading freed memory until something releases the pin.
_PINNED_MATERIAL_TREES: dict[int, int] = {}


def _release_deleted_pinned_trees(*_args) -> None:
    if not _PINNED_MATERIAL_TREES:
        return
    alive = {material.as_pointer() for material in bpy.data.materials}
    seen = set()
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            for space in area.spaces:
                if space.type != "NODE_EDITOR":
                    continue
                pointer = space.as_pointer()
                owner = _PINNED_MATERIAL_TREES.get(pointer)
                if owner is None:
                    continue
                if not space.pin:
                    continue
                seen.add(pointer)
                if owner not in alive:
                    space.pin = False
                    space.path.clear()
                    seen.discard(pointer)
                    area.tag_redraw()
    for pointer in tuple(_PINNED_MATERIAL_TREES):
        if pointer not in seen:
            _PINNED_MATERIAL_TREES.pop(pointer, None)
    if not _PINNED_MATERIAL_TREES:
        _set_pinned_tree_watch(False)


def _set_pinned_tree_watch(enabled: bool) -> None:
    for handlers in (bpy.app.handlers.depsgraph_update_pre, bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if enabled and _release_deleted_pinned_trees not in handlers:
            handlers.append(_release_deleted_pinned_trees)
        elif not enabled and _release_deleted_pinned_trees in handlers:
            handlers.remove(_release_deleted_pinned_trees)


def _release_all_pinned_trees() -> None:
    # Once the watch is gone nothing would release these pins when the material is deleted later.
    if not _PINNED_MATERIAL_TREES:
        return
    window_manager = bpy.context.window_manager
    for window in window_manager.windows if window_manager is not None else ():
        for area in window.screen.areas:
            for space in area.spaces:
                if space.type == "NODE_EDITOR" and space.as_pointer() in _PINNED_MATERIAL_TREES and space.pin:
                    space.pin = False
                    space.path.clear()
                    area.tag_redraw()


def remember_pinned_material_tree(space, material) -> None:
    _PINNED_MATERIAL_TREES[space.as_pointer()] = material.as_pointer()
    _set_pinned_tree_watch(True)


def display_material_in_shader_editor(context: bpy.types.Context, mat: bpy.types.Material) -> bool:
    node_tree = ensure_material_node_tree(mat)
    if node_tree is None:
        return False
    area, space = _shader_editor_target(context)
    if area is None or space is None:
        return False
    try:
        space.tree_type = "ShaderNodeTree"
    except Exception:
        pass
    try:
        space.shader_type = "OBJECT"
    except Exception:
        pass
    try:
        space.pin = True
    except Exception:
        pass
    try:
        space.path.clear()
    except Exception:
        pass
    try:
        space.path.start(node_tree)
    except Exception:
        return False
    remember_pinned_material_tree(space, mat)
    try:
        node = get_principled_node(mat)
        if node is not None:
            select_node_in_tree(mat, node)
    except Exception:
        pass
    try:
        area.tag_redraw()
    except Exception:
        pass
    return True


def base_material_name(name: str) -> str:
    # Blender resolves duplicate names as Name.001, Name.002.  Use this to mimic
    # 3ds Max's conflict-resolution workflow for Put Material to Scene.
    if len(name) > 4 and name[-4] == "." and name[-3:].isdigit():
        return name[:-4]
    return name


def sync_effect_channel(context: bpy.types.Context) -> None:
    props = context.scene.sss_material_editor
    mat = active_material(context)
    if mat:
        try:
            mat.pass_index = int(props.effect_channel)
        except Exception:
            pass


def set_effect_channel_from_active_material(context: bpy.types.Context) -> None:
    props = context.scene.sss_material_editor
    mat = active_material(context)
    if mat:
        props.effect_channel = max(0, min(15, int(getattr(mat, "pass_index", 0))))


def get_preview_collection(scene: bpy.types.Scene) -> bpy.types.Collection:
    coll = bpy.data.collections.get(PREVIEW_COLLECTION_NAME)
    if coll is None:
        coll = bpy.data.collections.new(PREVIEW_COLLECTION_NAME)
    if coll.name not in scene.collection.children:
        try:
            scene.collection.children.link(coll)
        except RuntimeError:
            pass
    return coll


def remove_preview_objects(scene: bpy.types.Scene) -> None:
    for obj in list(bpy.data.objects):
        if obj.get("sss_material_editor_preview"):
            bpy.data.objects.remove(obj, do_unlink=True)


def get_checker_material() -> bpy.types.Material:
    mat = bpy.data.materials.get(CHECKER_MATERIAL_NAME)
    if mat is None:
        mat = bpy.data.materials.new(CHECKER_MATERIAL_NAME)
        mat.diffuse_color = (0.5, 0.5, 0.5, 1.0)
        mat.use_nodes = True
        nt = mat.node_tree
        bsdf = get_principled_node(mat)
        checker = nt.nodes.new("ShaderNodeTexChecker")
        checker.inputs["Scale"].default_value = 8.0
        if bsdf:
            nt.links.new(checker.outputs.get("Color"), socket_by_name(bsdf, "Base Color"))
    return mat


def mark_preview_object(obj: bpy.types.Object) -> None:
    obj["sss_material_editor_preview"] = True
    obj.hide_select = False


def scale_uvs(obj: bpy.types.Object, tiling: int) -> None:
    if obj is None or obj.type != "MESH" or not obj.data.uv_layers:
        return
    factor = max(1, int(tiling))
    for layer in obj.data.uv_layers:
        for uv in layer.data:
            uv.uv.x *= factor
            uv.uv.y *= factor


def create_preview_object(context: bpy.types.Context) -> Optional[bpy.types.Object]:
    # The Material Editor preview section was removed from the integrated Smart
    # Shader UI.  Keep this legacy function as a safe no-op so older shortcuts,
    # scripts, or delayed handlers cannot create scene-level preview/proxy
    # objects in user .blend files.
    try:
        remove_preview_objects(context.scene)
    except Exception:
        pass
    return None

def set_viewport_material_preview(context: bpy.types.Context, enabled: bool) -> None:
    screen = getattr(context, "screen", None)
    if not screen:
        return
    for area in screen.areas:
        if area.type != "VIEW_3D":
            continue
        for space in area.spaces:
            if space.type == "VIEW_3D":
                space.shading.type = "MATERIAL" if enabled else "SOLID"


def node_by_name(mat: bpy.types.Material, name: str) -> Optional[bpy.types.Node]:
    if mat is None or not mat.use_nodes or mat.node_tree is None or not name:
        return None
    return mat.node_tree.nodes.get(name)


def get_current_node(context: bpy.types.Context) -> Optional[bpy.types.Node]:
    mat = active_material(context)
    props = context.scene.sss_material_editor
    node = node_by_name(mat, props.current_node)
    if node:
        return node
    return get_principled_node(mat)


def load_node_stack(props) -> list[str]:
    try:
        data = json.loads(props.node_stack_json or "[]")
        if isinstance(data, list):
            return [str(v) for v in data]
    except Exception:
        pass
    return []


def save_node_stack(props, stack: Iterable[str]) -> None:
    props.node_stack_json = json.dumps([str(v) for v in stack])


def linked_input_nodes(node: bpy.types.Node) -> list[tuple[str, bpy.types.Node]]:
    result = []
    if node is None:
        return result
    for sock in node.inputs:
        if sock.is_linked and sock.links:
            result.append((sock.name, sock.links[0].from_node))
    return result


def create_map_node_for_socket(mat: bpy.types.Material, parent: bpy.types.Node, socket_name: str) -> Optional[bpy.types.Node]:
    nt = mat.node_tree
    sock = socket_by_name(parent, socket_name)
    if sock is None:
        return None
    lower = socket_name.lower()
    if lower in {"normal", "bump"}:
        node = nt.nodes.new("ShaderNodeBump")
        node.name = "CME Bump"
        if "Strength" in node.inputs:
            node.inputs["Strength"].default_value = 0.1
        nt.links.new(node.outputs.get("Normal"), sock)
        return node
    if lower in {"roughness", "metallic", "alpha"}:
        node = nt.nodes.new("ShaderNodeTexNoise")
        node.name = "CME Noise Map"
        out = node.outputs.get("Fac") or node.outputs[0]
        nt.links.new(out, sock)
        return node
    node = nt.nodes.new("ShaderNodeTexImage")
    node.name = "CME Image Map"
    out = node.outputs.get("Color") or node.outputs[0]
    nt.links.new(out, sock)
    return node


def select_node_in_tree(mat: bpy.types.Material, node: bpy.types.Node) -> None:
    if mat is None or mat.node_tree is None or node is None:
        return
    for n in mat.node_tree.nodes:
        n.select = False
    node.select = True
    mat.node_tree.nodes.active = node


def find_node_path_from_principled(mat: bpy.types.Material, target_name: str) -> list[str]:
    root = get_principled_node(mat)
    if root is None:
        return []
    seen = set()

    def walk(node: bpy.types.Node, path: list[str]) -> Optional[list[str]]:
        if node.name == target_name:
            return path
        if node.name in seen:
            return None
        seen.add(node.name)
        for _, child in linked_input_nodes(node):
            found = walk(child, path + [node.name])
            if found is not None:
                return found
        return None

    result = walk(root, [])
    return result or []


def draw_node_tree(layout, mat: bpy.types.Material, node: bpy.types.Node, depth: int = 0, visited: Optional[set[str]] = None) -> None:
    if visited is None:
        visited = set()
    if node is None:
        return
    if node.name in visited:
        return
    visited.add(node.name)
    indent = "    " * depth
    row = layout.row(align=True)
    op = row.operator("sss.material_editor_select_node_in_hierarchy", text=f"{indent}{node.name}", icon="NODE", translate=False)
    op.node_name = node.name
    for sock_name, child in linked_input_nodes(node):
        row = layout.row(align=True)
        row.label(text=f"{indent}  {sock_name} →", icon="RIGHTARROW")
        draw_node_tree(layout, mat, child, depth + 1, visited)


class SSSME_OT_select_node_in_hierarchy(Operator):
    bl_idname = "sss.material_editor_select_node_in_hierarchy"
    bl_label = "Select Node in Hierarchy"
    bl_description = "Select the chosen node in the active material node tree and make it the current compact Material Editor node."
    bl_options = {"INTERNAL"}
    _sms_no_undo = True

    node_name: StringProperty(
        name="Node",
        description="Name of the material node to select.",
        default="",
    )

    def execute(self, context):
        mat = active_material(context)
        props = getattr(getattr(context, "scene", None), "sss_material_editor", None)
        node = node_by_name(mat, self.node_name) if mat is not None else None
        if mat is None or props is None or node is None:
            self.report({"WARNING"}, tr("No editable node is selected."))
            return {"CANCELLED"}
        select_node_in_tree(mat, node)
        props.current_node = node.name
        props.current_socket = ""
        save_node_stack(props, find_node_path_from_principled(mat, node.name))
        try:
            for area in getattr(getattr(context, "screen", None), "areas", ()):
                if getattr(area, "type", "") == "NODE_EDITOR":
                    area.tag_redraw()
        except Exception:
            pass
        return {"FINISHED"}


def _safe_materials() -> list:
    try:
        data = getattr(bpy, "data", None)
        materials = getattr(data, "materials", None)
        if materials is None:
            return []
        return [mat for mat in materials if mat is not None]
    except Exception:
        return []


def material_enum_items(self, context):
    items = []
    for i, mat in enumerate(_safe_materials()):
        try:
            name = str(getattr(mat, "name", "") or "")
        except Exception:
            name = ""
        if name:
            items.append((name, name, tr("Select Material"), "MATERIAL", i))
    if not items:
        items.append(("__NONE__", tr("Empty"), tr("No selectable material was found."), "ERROR", 0))
    return items


def update_effect_channel_property(self, context):
    if _MATERIAL_EDITOR_PERSISTENCE_APPLYING:
        return
    sync_effect_channel(context)
    save_material_editor_settings(getattr(context, 'scene', None))


def update_material_editor_property(self, context):
    del self
    save_material_editor_settings(getattr(context, 'scene', None))


def update_scene_material_list_property(self, context):
    """Invalidate the list snapshot and rewind the page cursor.

    5.18.259: nothing is persisted here.  ``self`` is the transient
    WindowManager state, so a filter or sort change is session-only and must
    not reach save_material_editor_settings().
    """
    del context
    try:
        self.scene_material_page = 0
    except Exception:
        pass
    clear_scene_material_snapshots()


def update_slot_material_preview(self, context):
    """Queue a native preview as soon as a compact slot receives a material."""
    try:
        _request_material_preview(getattr(self, "material", None))
    except Exception:
        pass
    try:
        save_material_editor_settings(getattr(context, 'scene', None))
    except Exception:
        pass
    try:
        screen = getattr(context, "screen", None)
        for area in list(getattr(screen, "areas", ()) or ()):
            area.tag_redraw()
    except Exception:
        pass


class SSSME_Slot(PropertyGroup):
    name: StringProperty(
        name="Slot",
        description="Compact material slot label. Use it as a reusable palette position, similar to 3ds Max sample slots.",
        default="Slot",
        update=update_material_editor_property,
    )
    material: PointerProperty(
        name="Material",
        type=bpy.types.Material,
        description="Material stored in this compact editor slot. Assign it to objects, pick it from objects, copy it, instance it, or save it to a library.",
        update=update_slot_material_preview,
    )
    note: StringProperty(
        name="Note",
        description="Optional private memo for this material slot. It does not change the Blender material datablock.",
        default="",
        update=update_material_editor_property,
    )


class SSSME_Settings(PropertyGroup):
    slots: CollectionProperty(type=SSSME_Slot)
    active_index: IntProperty(
        name="Active",
        description="Index of the currently active compact slot. The active slot is the target for Assign, Pick, preview, hierarchy navigation, and library operations.",
        default=0,
        min=0,
        update=update_material_editor_property,
    )
    display_mode: EnumProperty(
        name="Display",
        description="Choose a 3ds Max compact grid size or the Blender upper-compatible unlimited scrolling list.",
        items=(
            ("GRID_3X2", "3 x 2 compact slots", "Show six reusable compact material slots in a 3 by 2 grid.", "GRID", 0),
            ("GRID_5X3", "5 x 3 compact slots", "Show fifteen reusable compact material slots in a 5 by 3 grid.", "GRID", 1),
            ("GRID_6X4", "6 x 4 compact slots", "Show the classic twenty-four reusable compact material slots in a 6 by 4 grid.", "GRID", 2),
            ("LIST", "Unlimited list", "Show all material slots in a scrolling UIList so the palette is not limited to twenty-four slots.", "LINENUMBERS_ON", 3),
        ),
        default="GRID_6X4",
        update=update_material_editor_property,
    )
    source_index: IntProperty(
        name="Source",
        description="Source compact slot index for Copy, Instance, and Swap operations.",
        default=0,
        min=0,
        update=update_material_editor_property,
    )
    target_index: IntProperty(
        name="Target",
        description="Target compact slot index for Copy, Instance, and Swap operations.",
        default=1,
        min=0,
        update=update_material_editor_property,
    )
    show_shaded: BoolProperty(
        name="Show Shaded Material in Viewport",
        description="Switch 3D View areas to Material Preview mode so the active material and its texture maps are visible while editing.",
        default=False,
        update=update_material_editor_property,
    )
    sample_type: EnumProperty(
        name="Sample Type",
        description="Preview object shape used to inspect the active material, matching the 3ds Max sphere, cylinder, cube, and custom object sample types.",
        items=(
            ("SPHERE", "Sphere", "Use a UV sphere as the material preview sample.", "MESH_UVSPHERE", 0),
            ("CYLINDER", "Cylinder", "Use a cylinder as the material preview sample.", "MESH_CYLINDER", 1),
            ("CUBE", "Cube", "Use a cube as the material preview sample.", "MESH_CUBE", 2),
            ("CUSTOM", "Custom Object", "Duplicate the selected custom object as the material preview sample.", "OBJECT_DATA", 3),
        ),
        default="SPHERE",
        update=update_material_editor_property,
    )
    custom_sample_object: PointerProperty(
        name="Custom Sample Object",
        type=bpy.types.Object,
        description="Object used when Sample Type is Custom Object. Its mesh is duplicated for preview so the source object is not modified.",
        update=update_material_editor_property,
    )
    checker_background: BoolProperty(
        name="Checker Background",
        description="Place a checker plane behind the sample object to evaluate alpha, glass, refraction-like transparency, and edge contrast.",
        default=False,
        update=update_material_editor_property,
    )
    backlight: BoolProperty(
        name="Backlight",
        description="Add an area light behind the sample object to reveal rim highlights, metallic response, cloth sheen, and silhouette readability.",
        default=False,
        update=update_material_editor_property,
    )
    uv_tiling: IntProperty(
        name="UV Tiling",
        description="Scale preview-object UV coordinates to temporarily inspect 1x1, 2x2, 3x3, or higher texture tiling without modifying the material itself.",
        default=1,
        min=1,
        max=16,
        update=update_material_editor_property,
    )
    video_result: StringProperty(
        name="Video Color Check",
        description="Result of the broadcast-safe color approximation for the active material base color.",
        default="",
    )
    node_stack_json: StringProperty(
        name="Node Stack",
        description="Internal parent stack for compact material/map hierarchy navigation.",
        default="[]",
        options={"HIDDEN"},
        update=update_material_editor_property,
    )
    current_node: StringProperty(
        name="Current Node",
        description="Currently edited material/map node in the compact hierarchy navigator.",
        default="",
        update=update_material_editor_property,
    )
    current_socket: StringProperty(
        name="Current Socket",
        description="Socket name through which the current map node was entered.",
        default="",
        update=update_material_editor_property,
    )
    effect_channel: IntProperty(
        name="Effects Channel ID",
        description="Set material.pass_index from 0 to 15 for compositor or render-pass identification.",
        default=0,
        min=0,
        max=15,
        update=update_effect_channel_property,
    )
    material_browser_choice: EnumProperty(
        name="Material Name",
        description="Scene material to place in the active compact slot.",
        items=material_enum_items,
        update=update_material_editor_property,
    )





class SSSME_RuntimeState(PropertyGroup):
    """Transient Material Editor state, owned by the WindowManager.

    5.18.259.  Everything here is view state: which tab is showing, how the
    scene material list is filtered and sorted, and WHICH material is currently
    being inspected.  None of it belongs in the document or in the suite state
    file, so none of it is on Scene and none of it appears in
    _MATERIAL_EDITOR_SETTING_NAMES.  The WindowManager is rebuilt on file load
    and never saved, which is what makes the transience structural rather than
    a promise: there is no place for a stale material name to survive to.

    The inspected material is held as the two strings that identify a datablock
    (name and library filepath) and is resolved live by scene_tab_material().
    A PointerProperty would make this list a real user of the material and
    would keep a removed material alive; a bare name would be ambiguous between
    a local and a linked datablock.  Nothing here is an inventory: no object,
    material or scene list is ever stored.
    """

    editor_tab: EnumProperty(
        name="Editor Tab",
        description="Which Material Editor view is shown.",
        items=(
            ("SLOTS", "Standard", "Show the standard compact slot material editor.", "GRID", 0),
            ("SCENE", "Scene",
             "List every distinct material used by an object in this scene, and the objects that use it.",
             "MATERIAL", 1),
        ),
        default="SLOTS",
        options={"SKIP_SAVE"},
    )
    scene_material_filter: StringProperty(
        name="Search",
        description="Filter the scene material list by name.",
        default="",
        options={"SKIP_SAVE"},
        update=update_scene_material_list_property,
    )
    scene_material_sort: EnumProperty(
        name="Sort",
        description="Order of the scene material list.",
        items=(
            ("NAME", "Name", "Sort by name.", "SORTALPHA", 0),
            ("USERS", "Users", "Sort by the number of objects using the material.", "USER", 1),
            ("SLOTS", "Slot Count", "Sort by the number of material slots using the material.", "SORTSIZE", 2),
        ),
        default="NAME",
        options={"SKIP_SAVE"},
        update=update_scene_material_list_property,
    )
    scene_material_active_name: StringProperty(
        name="Selected Material",
        description="Material selected in the scene material list. Stored by name so the list never becomes a hidden user of the material.",
        default="",
        options={"SKIP_SAVE"},
    )
    scene_material_active_library: StringProperty(
        name="Library",
        description="Library filepath of the material selected in the scene material list. Empty for a local material.",
        default="",
        options={"SKIP_SAVE"},
    )
    scene_user_extend: BoolProperty(
        name="Extend selection",
        description="Keep the current selection and add objects picked from this list.",
        default=False,
        options={"SKIP_SAVE"},
    )
    scene_material_page: IntProperty(
        name="Page",
        description="Internal page cursor for the scene material list. Not persisted.",
        default=0,
        min=0,
        options={"HIDDEN", "SKIP_SAVE"},
    )


class SSSME_OT_initialize_slots(Operator):
    bl_idname = "sss.material_editor_initialize_slots"
    bl_label = "Initialize Slots"
    bl_description = "Create the classic twenty-four compact material editor slots if they do not already exist. Existing slots and materials are preserved."
    bl_options = {'UNDO'}

    create_default_materials: BoolProperty(
        name="Create Default Materials",
        description="Fill empty compact slots with default gray Principled BSDF materials, reproducing the populated 3ds Max sample-slot behavior.",
        default=False,
    )

    def execute(self, context):
        ensure_slots(context.scene, SLOT_DEFAULT_COUNT)
        if self.create_default_materials:
            for i, slot in enumerate(context.scene.sss_material_editor.slots[:SLOT_DEFAULT_COUNT]):
                if slot.material is None:
                    slot.material = get_or_create_default_slot_material(i)
        return {"FINISHED"}


class SSSME_OT_add_slot(Operator):
    bl_idname = "sss.material_editor_add_slot"
    bl_label = "Add Slot"
    bl_description = "Add an extra compact material slot. This is the Blender upper-compatible mode beyond the original 24-slot limit."
    bl_options = {'UNDO'}

    def execute(self, context):
        ensure_slots(context.scene)
        props = context.scene.sss_material_editor
        slot = props.slots.add()
        slot.name = f"{tr('Slot')} {len(props.slots):02d}"
        props.active_index = len(props.slots) - 1
        return {"FINISHED"}


class SSSME_OT_remove_slot(Operator):
    bl_idname = "sss.material_editor_remove_slot"
    bl_label = "Remove Slot"
    bl_description = "Remove the active compact slot from the palette. The Blender material datablock is not deleted."
    bl_options = {'UNDO'}

    def execute(self, context):
        ensure_slots(context.scene)
        props = context.scene.sss_material_editor
        if len(props.slots) <= 1:
            return {"CANCELLED"}
        props.slots.remove(props.active_index)
        props.active_index = max(0, min(props.active_index, len(props.slots) - 1))
        return {"FINISHED"}


class SSSME_OT_clear_slot(Operator):
    bl_idname = "sss.material_editor_clear_slot"
    bl_label = "Clear Slot"
    bl_description = "Clear the active compact slot while keeping the material datablock in bpy.data.materials if it has other users."
    bl_options = {'UNDO'}

    def execute(self, context):
        slot = active_slot(context)
        if slot is None:
            report(self, {"ERROR"}, "No active slot.")
            return {"CANCELLED"}
        slot.material = None
        return {"FINISHED"}


class SSSME_OT_set_active_slot(Operator):
    bl_idname = "sss.material_editor_set_active_slot"
    bl_label = "Set Active Slot"
    bl_description = "Make this compact slot active. All editor actions operate on the active slot."
    bl_options = set()

    index: IntProperty(name="Slot Index", default=0, min=0)

    def execute(self, context):
        ensure_slots(context.scene)
        props = context.scene.sss_material_editor
        props.active_index = max(0, min(self.index, len(props.slots) - 1))
        set_effect_channel_from_active_material(context)
        return {"FINISHED"}


class SSSME_OT_assign_to_selection(Operator):
    bl_idname = "sss.material_editor_assign_to_selection"
    bl_label = "Assign Material to Selection"
    bl_description = "Use active slot material for selected objects or selected mesh faces. In Object Mode it writes to each object's active material slot; in Edit Mode it writes to selected faces."
    bl_options = {'UNDO'}
    bl_property = "sss_target_slot_token"

    sss_target_slot_token: EnumProperty(**slot_selection.MATERIAL_TARGET_SLOT_PROPERTY_KWARGS)

    def invoke(self, context, _event):
        if context.mode != "EDIT_MESH":
            result = slot_selection.invoke_operator_material_target_slot_search(self, context, assign_selected=True)
            if result:
                return result
        return self.execute(context)

    def execute(self, context):
        slot_selection.apply_operator_material_target_slot(self, context)
        mat = active_material(context)
        if mat is None:
            report(self, {"ERROR"}, "No active material.")
            return {"CANCELLED"}
        changed = 0
        if context.mode == "EDIT_MESH":
            changed = assign_material_to_selected_faces(context, mat)
        else:
            for obj in context.selected_objects:
                if assign_material_to_object_slot(obj, mat, context=context):
                    changed += 1
        if changed == 0:
            report(self, {"WARNING"}, "No selectable material was found.")
            return {"CANCELLED"}
        report(self, {"INFO"}, "Assigned material to selection.")
        return {"FINISHED"}


class SSSME_OT_pick_from_active(Operator):
    bl_idname = "sss.material_editor_pick_from_active"
    bl_label = "Pick Material from Active Object"
    bl_description = "Read the active object's current material and place it in the active compact slot. Use this as the non-modal eyedropper equivalent."
    bl_options = set()
    bl_property = "material_slot_token"

    material_slot_token: EnumProperty(
        name="Material Slot",
        description="Pick the material slot to read from the active object.",
        items=_active_object_material_slot_enum_items,
        options={"SKIP_SAVE"},
    )

    def invoke(self, context, _event):
        entries = _active_object_material_entries(context)
        if len(entries) > 1:
            _active_object_material_slot_enum_items(self, context)
            obj = getattr(context, "object", None) or getattr(context, "active_object", None)
            try:
                self.material_slot_token = _active_object_material_slot_token_for_index(int(getattr(obj, "active_material_index", 0)))
            except Exception:
                pass
            try:
                context.window_manager.invoke_search_popup(self)
                return {"RUNNING_MODAL"}
            except Exception:
                pass
        return self.execute(context)

    def execute(self, context):
        token = str(getattr(self, "material_slot_token", "") or "")
        slot_index = _ME_ACTIVE_OBJECT_SLOT_MAP.get(token, None) if token else None
        if slot_index is None and token.startswith("SLOT_"):
            try:
                slot_index = int(token.split("_", 1)[1])
            except Exception:
                slot_index = None
        mat = current_object_material(context, slot_index if slot_index is not None and slot_index >= 0 else None)
        if mat is None:
            report(self, {"ERROR"}, "No selectable material was found.")
            return {"CANCELLED"}
        slot = active_slot(context)
        if slot is None:
            report(self, {"ERROR"}, "No active slot.")
            return {"CANCELLED"}
        slot.material = mat
        set_effect_channel_from_active_material(context)
        report(self, {"INFO"}, "Picked material from active object.")
        return {"FINISHED"}


class SSSME_OT_pick_from_shader_editor(Operator):
    bl_idname = "sss.material_editor_pick_from_shader_editor"
    bl_label = "Pick Material from Shader Editor"
    bl_description = "Read the material currently displayed or pinned in an open Shader Editor and place it in the active compact slot. Use this after selecting the destination slot in the Material Editor. World shaders and non-shader node editors are ignored."
    bl_options = set()

    def execute(self, context):
        mat = shader_editor_material(context)
        if mat is None:
            report(self, {"ERROR"}, "No material is open in the Shader Editor.")
            return {"CANCELLED"}
        slot = active_slot(context)
        if slot is None:
            report(self, {"ERROR"}, "No active slot.")
            return {"CANCELLED"}
        slot.material = mat
        set_effect_channel_from_active_material(context)
        report(self, {"INFO"}, "Picked material from Shader Editor.")
        return {"FINISHED"}


class SSSME_OT_show_in_shader_editor(Operator):
    bl_idname = "sss.material_editor_show_in_shader_editor"
    bl_label = "Show in Shader Editor"
    bl_description = "Display the active compact slot material in a Shader Editor. If no Shader Editor is open, an available editor area is switched to the Shader Editor and the material node tree is shown without changing scene material assignments."
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        mat = active_material(context)
        if mat is None:
            report(self, {"ERROR"}, "No active material.")
            return {"CANCELLED"}
        node_tree = ensure_material_node_tree(mat)
        if node_tree is None:
            report(self, {"ERROR"}, "Material has no node tree.")
            return {"CANCELLED"}
        if not display_material_in_shader_editor(context, mat):
            report(self, {"ERROR"}, "No editor area is available for the Shader Editor.")
            return {"CANCELLED"}
        report(self, {"INFO"}, "Displayed active slot material in the Shader Editor.")
        return {"FINISHED"}


class SSSME_OT_pick_from_viewport(Operator):
    bl_idname = "sss.material_editor_pick_from_viewport"
    bl_label = "Pick Material from Viewport Click"
    bl_description = "Click an object in the 3D View and place its hit-face material in the active compact slot. This reproduces the compact editor eyedropper."
    bl_options = set()

    def execute(self, context):
        report(self, {"WARNING"}, "No selectable material was found.")
        return {"CANCELLED"}

    def invoke(self, context, event):
        if context.area is None or context.area.type != "VIEW_3D":
            report(self, {"ERROR"}, "No selectable material was found.")
            return {"CANCELLED"}
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type in {"ESC", "RIGHTMOUSE"}:
            return {"CANCELLED"}
        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            mat = self._material_under_mouse(context, event)
            if mat is None:
                report(self, {"ERROR"}, "No selectable material was found.")
                return {"CANCELLED"}
            slot = active_slot(context)
            if slot is None:
                report(self, {"ERROR"}, "No active slot.")
                return {"CANCELLED"}
            slot.material = mat
            set_effect_channel_from_active_material(context)
            report(self, {"INFO"}, "Picked material from viewport.")
            return {"FINISHED"}
        return {"RUNNING_MODAL"}

    @staticmethod
    def _material_under_mouse(context, event) -> Optional[bpy.types.Material]:
        from bpy_extras import view3d_utils

        region = context.region
        rv3d = context.region_data
        coord = (event.mouse_region_x, event.mouse_region_y)
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        depsgraph = context.evaluated_depsgraph_get()
        hit, _loc, _normal, face_index, obj, _matrix = context.scene.ray_cast(depsgraph, origin, direction)
        if not hit or obj is None:
            return None
        source_obj = getattr(obj, "original", obj)
        if face_index is not None and face_index >= 0 and getattr(source_obj, "type", None) == "MESH":
            polys = source_obj.data.polygons
            if face_index < len(polys):
                mi = polys[face_index].material_index
                if mi < len(source_obj.material_slots):
                    return source_obj.material_slots[mi].material
        if hasattr(source_obj, "active_material"):
            return source_obj.active_material
        return None


class SSSME_OT_select_by_material(Operator):
    bl_idname = "sss.material_editor_select_by_material"
    bl_label = "Select by Material"
    bl_description = "Select every scene object, or matching edit-mode faces, that use the active slot material. This mirrors 3ds Max Select by Material."
    bl_options = set()

    # All three properties are SKIP_SAVE and all defaults reproduce the
    # 5.18.249 behaviour exactly.  An argument-free invocation takes the
    # legacy branch below and is byte-for-byte the original operator.
    material_name: StringProperty(name="Material", default="", options={"SKIP_SAVE"})
    material_library: StringProperty(name="Library", default="", options={"SKIP_SAVE"})
    extend: BoolProperty(name="Extend selection", default=False, options={"SKIP_SAVE"})

    def execute(self, context):
        requested = str(self.material_name or '').strip()
        if requested:
            return self._execute_named(context, requested, str(self.material_library or '').strip())
        mat = active_material(context)
        if mat is None:
            report(self, {"ERROR"}, "No active material.")
            return {"CANCELLED"}
        count = 0
        if context.mode == "EDIT_MESH":
            count = select_faces_by_material(context, mat)
        else:
            for obj in context.scene.objects:
                selectable = getattr(obj, "hide_select", False) is False and not obj.hide_get()
                hit = selectable and material_used_by_object(obj, mat)
                obj.select_set(bool(hit))
                if hit:
                    context.view_layer.objects.active = obj
                    count += 1
        if count == 0:
            report(self, {"WARNING"}, "No selectable material was found.")
            return {"CANCELLED"}
        report(self, {"INFO"}, "Selected objects or faces by material.")
        return {"FINISHED"}

    def _execute_named(self, context, requested: str, requested_library: str):
        """Scene Materials tab path: an explicit material, object mode only."""
        if context.mode == "EDIT_MESH":
            report(self, {"WARNING"}, "Leave Edit Mode to select objects by material.")
            return {"CANCELLED"}
        mat = _material_by_identity(requested, requested_library)
        if mat is None:
            report(self, {"ERROR"}, "No active material.")
            return {"CANCELLED"}
        rows = material_object_users(context, mat)
        # 5.18.259: resolve every eligible object BEFORE writing any selection.
        # The rejected ordering cleared the whole selection first and only then
        # discovered that nothing was selectable, which destroyed the user's
        # selection on a path that reports CANCELLED.
        eligible: list = []
        skipped = 0
        for row in rows:
            if not row.get('selectable'):
                skipped += 1
                continue
            obj = _object_by_identity(row.get('name', ''), row.get('object_library', ''))
            if obj is None:
                skipped += 1
                continue
            eligible.append(obj)
        if not eligible:
            report(self, {"WARNING"}, "No object using this material can be selected.")
            return {"CANCELLED"}
        # Compared by (name, library), never by id(): Blender hands back a new
        # Python wrapper for the same object on every access.
        keep = {_object_identity(obj) for obj in eligible}
        if not self.extend:
            for other in (getattr(getattr(context, 'view_layer', None), 'objects', ()) or ()):
                if _object_identity(other) in keep:
                    continue
                try:
                    other.select_set(False)
                except Exception:
                    pass
        selected = 0
        first = None
        for obj in eligible:
            try:
                obj.select_set(True)
            except Exception:
                skipped += 1
                continue
            selected += 1
            if first is None:
                first = obj
        if first is not None:
            try:
                context.view_layer.objects.active = first
            except Exception:
                pass
        if selected == 0:
            report(self, {"WARNING"}, "No object using this material can be selected.")
            return {"CANCELLED"}
        total = selected + skipped
        message = f"{tr('Objects')}: {selected} / {total}"
        if skipped:
            message = f"{message} ({skipped} {tr('skipped')})"
        report(self, {"INFO"}, message)
        return {"FINISHED"}


class SSSME_OT_put_to_scene(Operator):
    bl_idname = "sss.material_editor_put_to_scene"
    bl_label = "Put Material to Scene"
    bl_description = "Force objects using duplicate same-base-name materials to use the active slot material. This resolves name conflicts and synchronizes the scene to the slot."
    bl_options = {'UNDO'}

    def execute(self, context):
        mat = active_material(context)
        if mat is None:
            report(self, {"ERROR"}, "No active material.")
            return {"CANCELLED"}
        base = base_material_name(mat.name)
        changed = 0
        for obj in context.scene.objects:
            if not hasattr(obj, "material_slots"):
                continue
            for i, mslot in enumerate(obj.material_slots):
                other = mslot.material
                if other is not None and other != mat and base_material_name(other.name) == base:
                    obj.data.materials[i] = mat
                    changed += 1
        # Ensure at least the selected objects can receive the active material when no duplicate exists.
        if changed == 0:
            for obj in context.selected_objects:
                if assign_material_to_object_slot(obj, mat, context=context):
                    changed += 1
        report(self, {"INFO"}, "Scene synchronized with active slot material.")
        return {"FINISHED"}


class SSSME_OT_transfer_slot(Operator):
    bl_idname = "sss.material_editor_transfer_slot"
    bl_label = "Slot Transfer"
    bl_description = "Copy, instance-link, or swap compact material slots. Copy creates a new material datablock; Instance shares the same datablock; Swap exchanges slot contents."
    bl_options = {'UNDO'}

    action: EnumProperty(
        name="Mode",
        items=(
            ("COPY", "Copy", "Duplicate source material datablock into target slot."),
            ("INSTANCE", "Instance", "Assign the exact same material datablock to target slot."),
            ("SWAP", "Swap", "Exchange source and target slot contents."),
        ),
        default="COPY",
    )

    def execute(self, context):
        ensure_slots(context.scene)
        props = context.scene.sss_material_editor
        src = slot_at(context.scene, props.source_index)
        dst = slot_at(context.scene, props.target_index)
        if src is None or dst is None or src == dst:
            return {"CANCELLED"}
        if self.action in {"COPY", "INSTANCE"} and src.material is None:
            report(self, {"ERROR"}, "No active material.")
            return {"CANCELLED"}
        if self.action == "COPY":
            dst.material = src.material.copy()
            dst.material.name = f"{src.material.name}_Copy"
            report(self, {"INFO"}, "Copied source slot material to target slot.")
        elif self.action == "INSTANCE":
            dst.material = src.material
            report(self, {"INFO"}, "Instanced source slot material to target slot.")
        else:
            src.material, dst.material = dst.material, src.material
            src.name, dst.name = dst.name, src.name
            report(self, {"INFO"}, "Swapped source and target slots.")
        return {"FINISHED"}


class SSSME_OT_create_material(Operator):
    bl_idname = "sss.material_editor_create_material"
    bl_label = "New Material"
    bl_description = "Create a new default Principled BSDF material in the active compact slot. The material is a normal Blender datablock and can be edited anywhere."
    bl_options = {'UNDO'}

    name: StringProperty(
        name="Material Name",
        description="Name of the new Blender material datablock placed into the active compact slot.",
        default="CME Material",
    )

    def execute(self, context):
        slot = active_slot(context)
        if slot is None:
            report(self, {"ERROR"}, "No active slot.")
            return {"CANCELLED"}
        mat = make_default_material(self.name)
        slot.material = mat
        set_effect_channel_from_active_material(context)
        report(self, {"INFO"}, "Created new material.")
        return {"FINISHED"}


class SSSME_OT_browse_scene_materials(Operator):
    bl_idname = "sss.material_editor_browse_scene_materials"
    bl_label = "Browse Scene Materials"
    bl_description = "Open a compact browser of existing bpy.data.materials and place the chosen material into the active slot."
    bl_options = set()
    _sms_no_undo = True

    material_name: EnumProperty(name="Material Name", items=material_enum_items)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def execute(self, context):
        if self.material_name == "__NONE__":
            report(self, {"ERROR"}, "No selectable material was found.")
            return {"CANCELLED"}
        mat = bpy.data.materials.get(self.material_name)
        if mat is None:
            report(self, {"ERROR"}, "No selectable material was found.")
            return {"CANCELLED"}
        slot = active_slot(context)
        if slot is None:
            report(self, {"ERROR"}, "No active slot.")
            return {"CANCELLED"}
        slot.material = mat
        set_effect_channel_from_active_material(context)
        report(self, {"INFO"}, "Selected scene material.")
        return {"FINISHED"}

    def draw(self, context):
        self.layout.prop(self, "material_name", text=tr("Material Name"))


class SSSME_OT_put_to_library(Operator, ExportHelper):
    bl_idname = "sss.material_editor_put_to_library"
    bl_label = "Put to Library"
    bl_description = "Save active material as a .blend library file. The saved material can be loaded later with Get Material > Load Material Library."
    bl_options = set()

    filename_ext = ".blend"
    filter_glob: StringProperty(default="*.blend", options={"HIDDEN"})

    def execute(self, context):
        mat = active_material(context)
        if mat is None:
            report(self, {"ERROR"}, "No active material.")
            return {"CANCELLED"}
        try:
            bpy.data.libraries.write(self.filepath, {mat}, fake_user=True, compress=True)
        except TypeError:
            bpy.data.libraries.write(self.filepath, {mat}, fake_user=True)
        report(self, {"INFO"}, "Saved material library.")
        return {"FINISHED"}


class SSSME_OT_load_material_library(Operator, ImportHelper):
    bl_idname = "sss.material_editor_load_material_library"
    bl_label = "Load Material Library"
    bl_description = "Append all materials from a .blend library file and place the first loaded material into the active compact slot."
    bl_options = {'UNDO'}

    filename_ext = ".blend"
    filter_glob: StringProperty(default="*.blend", options={"HIDDEN"})

    def execute(self, context):
        before_names = set(bpy.data.materials.keys())
        loaded = []
        try:
            with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
                names = list(data_from.materials)
                data_to.materials = names
            loaded = [m for m in data_to.materials if m is not None]
        except Exception:
            loaded = []
        if not loaded:
            after_names = set(bpy.data.materials.keys())
            created_names = sorted(after_names - before_names)
            loaded = [bpy.data.materials[name] for name in created_names if name in bpy.data.materials]
        if not loaded:
            report(self, {"ERROR"}, "No selectable material was found.")
            return {"CANCELLED"}
        slot = active_slot(context)
        if slot is not None:
            slot.material = loaded[0]
            set_effect_channel_from_active_material(context)
        report(self, {"INFO"}, "Loaded material library.")
        return {"FINISHED"}


class SSSME_OT_make_unique(Operator):
    bl_idname = "sss.material_editor_make_unique"
    bl_label = "Make Unique"
    bl_description = "Duplicate the material datablock so edits no longer affect other linked users. Selected objects using the original active material are redirected to the unique copy."
    bl_options = {'UNDO'}

    def execute(self, context):
        slot = active_slot(context)
        mat = slot.material if slot else None
        if mat is None:
            report(self, {"ERROR"}, "No active material.")
            return {"CANCELLED"}
        new_mat = mat.copy()
        new_mat.name = f"{mat.name}_Unique"
        slot.material = new_mat
        for obj in context.selected_objects:
            if not object_supports_materials(obj):
                continue
            for material_slot in obj.material_slots:
                if material_slot.material == mat:
                    # A shared mesh also belongs to unselected objects. Use
                    # an object override so Make Unique cannot change them.
                    # Read the effective slot material, including an existing
                    # object override, rather than only the mesh's material.
                    if obj.data.users > 1:
                        material_slot.link = 'OBJECT'
                    material_slot.material = new_mat
        set_effect_channel_from_active_material(context)
        report(self, {"INFO"}, "Material made unique.")
        return {"FINISHED"}


class SSSME_OT_reset_slot(Operator):
    bl_idname = "sss.material_editor_reset_slot"
    bl_label = "Reset Slot to Default"
    bl_description = "Reset the active compact slot to a fresh default Principled BSDF material, matching Reset Map/Mtl to Default Settings."
    bl_options = {'UNDO'}

    def execute(self, context):
        ensure_slots(context.scene)
        props = context.scene.sss_material_editor
        slot = active_slot(context)
        if slot is None:
            report(self, {"ERROR"}, "No active slot.")
            return {"CANCELLED"}
        slot.material = None
        slot.material = fresh_default_slot_material(props.active_index)
        set_effect_channel_from_active_material(context)
        report(self, {"INFO"}, "Slot reset to default material.")
        return {"FINISHED"}


class SSSME_OT_rename_material(Operator):
    bl_idname = "sss.material_editor_rename_material"
    bl_label = "Rename"
    bl_description = "Rename the material shown in the Material Editor. Linked and library-override materials are refused."
    bl_options = {'UNDO'}

    material_name: StringProperty(name="Material", default="", options={"SKIP_SAVE"})
    material_library: StringProperty(name="Library", default="", options={"SKIP_SAVE"})
    new_name: StringProperty(name="Rename", default="", options={"SKIP_SAVE"})

    def _resolve(self, context):
        """The material this invocation targets, by identity when one was given.

        M2-01 correction.  This operator is the ONLY rename surface in the
        feature: the rejected design registered it and then drew every rename
        control as a direct layout.prop(mat, 'name'), which bypassed both the
        cache clear and the tab-selection re-sync below, leaving them dead
        code and orphaning the tab selection on every rename.
        """
        source = str(self.material_name or '').strip()
        if source:
            return _material_by_identity(source, str(self.material_library or '').strip())
        state = editor_state(context)
        if state is not None and str(getattr(state, 'editor_tab', 'SLOTS') or 'SLOTS') == 'SCENE':
            return scene_tab_material(context)
        return active_material(context)

    def invoke(self, context, event):
        mat = self._resolve(context)
        if mat is None:
            report(self, {"ERROR"}, "No active material.")
            return {"CANCELLED"}
        if not _material_is_renamable(mat):
            report(self, {"ERROR"}, "This material is linked and cannot be renamed here.")
            return {"CANCELLED"}
        # Pin the resolved identity so the dialog cannot drift onto another
        # datablock between invoke and execute, and seed the field with the
        # current name so the dialog behaves like an in-place edit.
        self.material_name = str(getattr(mat, 'name', '') or '')
        self.material_library = _library_path_of(mat)
        if not str(self.new_name or '').strip():
            self.new_name = self.material_name
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context):
        self.layout.prop(self, "new_name", text=tr("Rename"))

    def execute(self, context):
        mat = self._resolve(context)
        if mat is None:
            report(self, {"ERROR"}, "No active material.")
            return {"CANCELLED"}
        target = str(self.new_name or '').strip()
        if not target:
            report(self, {"ERROR"}, "Enter a new name first.")
            return {"CANCELLED"}
        if not _material_is_renamable(mat):
            report(self, {"ERROR"}, "This material is linked and cannot be renamed here.")
            return {"CANCELLED"}
        previous_name = str(getattr(mat, 'name', '') or '')
        previous_library = _library_path_of(mat)
        if target == previous_name:
            # Nothing to write.  Assigning the identical name would still be
            # harmless, but reporting a rename that did not happen is not.
            report(self, {"INFO"}, "Renamed material.")
            return {"FINISHED"}
        # Blender owns uniqueness and length clamping for ID names.  Assign and
        # then read back; the resulting name may carry a numeric suffix and that
        # is the correct, Outliner-identical behaviour.  This writes ONLY
        # ``Material.name`` on the datablock the user is looking at: the
        # datablock is not copied, replaced or relinked, so every object slot,
        # node tree and user count that referenced it before still references
        # exactly it afterwards, and ``mat.users`` is unchanged.
        mat.name = target
        state = editor_state(context)
        if (state is not None
                and str(getattr(state, 'scene_material_active_name', '') or '') == previous_name
                and str(getattr(state, 'scene_material_active_library', '') or '') == previous_library):
            try:
                state.scene_material_active_name = mat.name
            except Exception:
                pass
            _note_scene_material_selection(mat, mat.name, previous_library)
        clear_scene_material_snapshots()
        report(self, {"INFO"}, "Renamed material.")
        return {"FINISHED"}


class SSSME_OT_set_scene_material(Operator):
    bl_idname = "sss.material_editor_set_scene_material"
    bl_label = "Selected Material"
    bl_description = "Select a material in the Scene Materials list, or move the list page."
    bl_options = set()
    _sms_no_undo = True

    material_name: StringProperty(name="Material", default="", options={"SKIP_SAVE"})
    material_library: StringProperty(name="Library", default="", options={"SKIP_SAVE"})
    page_delta: IntProperty(name="Page", default=0, options={"SKIP_SAVE"})

    def execute(self, context):
        state = editor_state(context)
        if state is None:
            return {"CANCELLED"}
        if int(self.page_delta or 0):
            rows = scene_material_index(context)
            pages = max(1, (len(rows) + _SCENE_MATERIAL_PAGE_SIZE - 1) // _SCENE_MATERIAL_PAGE_SIZE)
            current = int(getattr(state, 'scene_material_page', 0) or 0)
            state.scene_material_page = min(max(0, current + int(self.page_delta)), pages - 1)
            return {"FINISHED"}
        name = str(self.material_name or '').strip()
        if not name:
            report(self, {"ERROR"}, "No material is selected.")
            return {"CANCELLED"}
        library = str(self.material_library or '').strip()
        # Inspecting a material writes two transient strings and nothing else.
        # No object selection, no material assignment and no active-slot change.
        state.scene_material_active_name = name
        state.scene_material_active_library = library
        # B3-01: remember which datablock this row actually is, so a later
        # rename by any surface cannot orphan the selection.
        _note_scene_material_selection(_material_by_identity(name, library), name, library)
        clear_scene_material_snapshots()
        return {"FINISHED"}


class SSSME_OT_put_scene_material_in_slot(Operator):
    """Put an identified scene material into the active material slot.

    B2-01 correction.  The rejected design reused
    sss.material_editor_browse_scene_materials for this button, presetting its
    bare-name EnumProperty and suppressing its picker with EXEC_DEFAULT.  That
    operator resolves with a bare bpy.data.materials.get(name), so a LINKED
    material sharing a name with a LOCAL one silently assigned the LOCAL
    datablock while reporting success on the user's actual pick.  A dedicated
    operator carrying (name, library) closes that path without touching the
    pre-existing picker, whose own dialog behaviour therefore stays intact.
    """

    bl_idname = "sss.material_editor_put_scene_material_in_slot"
    bl_label = "Put into Active Slot"
    bl_description = "Put the selected scene material into the active material slot."
    bl_options = {'UNDO'}

    material_name: StringProperty(name="Material", default="", options={"SKIP_SAVE"})
    material_library: StringProperty(name="Library", default="", options={"SKIP_SAVE"})

    def execute(self, context):
        mat = _material_by_identity(
            str(self.material_name or '').strip(),
            str(self.material_library or '').strip(),
        )
        if mat is None:
            report(self, {"ERROR"}, "No selectable material was found.")
            return {"CANCELLED"}
        slot = active_slot(context)
        if slot is None:
            report(self, {"ERROR"}, "No active slot.")
            return {"CANCELLED"}
        slot.material = mat
        set_effect_channel_from_active_material(context)
        report(self, {"INFO"}, "Selected scene material.")
        return {"FINISHED"}


class SSSME_OT_select_material_user(Operator):
    bl_idname = "sss.material_editor_select_material_user"
    bl_label = "Objects Using This Material"
    bl_description = "Select this object in the scene. Hold Ctrl or Shift to add to the current selection."
    bl_options = set()
    _sms_no_undo = True

    object_name: StringProperty(name="Objects", default="", options={"SKIP_SAVE"})
    object_library: StringProperty(name="Library", default="", options={"SKIP_SAVE"})
    extend: BoolProperty(name="Extend selection", default=False, options={"SKIP_SAVE"})
    deselect: BoolProperty(name="Deselect", default=False, options={"SKIP_SAVE"})

    def invoke(self, context, event):
        # Modifier handling lives here only.  execute() reads properties alone,
        # so every semantic stays reachable from a background Blender.
        obj = _object_by_identity(str(self.object_name or '').strip(), str(self.object_library or '').strip())
        modifier = bool(getattr(event, 'ctrl', False) or getattr(event, 'shift', False))
        if modifier:
            self.extend = True
        if bool(getattr(event, 'ctrl', False)) and obj is not None:
            try:
                self.deselect = bool(obj.select_get())
            except Exception:
                self.deselect = False
        return self.execute(context)

    def execute(self, context):
        """Select and activate one usage object, or refuse without side effects.

        5.18.259.  Every rejection is decided BEFORE anything is written, and
        the first write is always the target object's own select_set.  That
        ordering is the contract: an ineligible or vanished object leaves the
        user's existing selection, the active object and the current mode
        exactly as they were.  This operator never unhides an object, never
        relinks it into the view layer, never switches scene, and never leaves
        Edit Mode -- a hidden, excluded, non-selectable, removed or
        mode-incompatible target is reported, not worked around.
        """
        name = str(self.object_name or '').strip()
        obj = _object_by_identity(name, str(self.object_library or '').strip()) if name else None
        scene = getattr(context, 'scene', None)
        # M2-02: scene and view-layer membership are identity questions.  A
        # bare-name test passes a linked object off as a local one that
        # happens to share its name, and then misattributes the failure.
        identity = _object_identity(obj) if obj is not None else None
        if obj is None or scene is None:
            report(self, {"ERROR"}, "Object could not be selected.")
            return {"CANCELLED"}
        if identity not in _scene_object_identities(scene):
            # Removed from bpy.data, or moved/unlinked to another scene since
            # the row was drawn.  Never switch scene to reach it.
            report(self, {"ERROR"}, "The object is no longer in this scene.")
            return {"CANCELLED"}
        # Mode is checked before membership details so the message names the
        # real blocker.  Object selection outside Object Mode is not applied by
        # Blender, and leaving the current mode implicitly is forbidden.
        if str(getattr(context, 'mode', 'OBJECT') or 'OBJECT') != 'OBJECT':
            report(self, {"WARNING"}, "Leave Edit Mode to select an object from this list.")
            return {"CANCELLED"}
        if identity not in _view_layer_object_identities(context):
            # Excluded collection, or a different view layer entirely.
            report(self, {"WARNING"}, "Not in the active view layer.")
            return {"CANCELLED"}
        if bool(getattr(obj, 'hide_select', False)):
            report(self, {"WARNING"}, "Selection is disabled for this object.")
            return {"CANCELLED"}
        try:
            hidden = bool(obj.hide_get())
        except Exception:
            hidden = False
        if hidden:
            # hide_get() is view-layer local.  Refuse; do not unhide.
            report(self, {"WARNING"}, "Hidden in this view layer.")
            return {"CANCELLED"}
        if self.deselect:
            try:
                obj.select_set(False)
            except Exception:
                report(self, {"ERROR"}, "Object could not be selected.")
                return {"CANCELLED"}
            report(self, {"INFO"}, "Deselected object.")
            return {"FINISHED"}
        try:
            obj.select_set(True)
        except Exception:
            # The only remaining failure mode, and it happens before any other
            # object has been touched, so the existing selection is intact.
            report(self, {"ERROR"}, "Object could not be selected.")
            return {"CANCELLED"}
        if not self.extend:
            for other in (getattr(getattr(context, 'view_layer', None), 'objects', ()) or ()):
                # Identity, not ``is``: Blender returns a fresh Python wrapper
                # for the same object on every collection access.
                if _object_identity(other) == identity:
                    continue
                try:
                    other.select_set(False)
                except Exception:
                    pass
        try:
            context.view_layer.objects.active = obj
        except Exception:
            pass
        report(self, {"INFO"}, "Selected object.")
        return {"FINISHED"}


class SSSME_MT_get_material(Menu):
    bl_idname = "SSSME_MT_get_material"
    bl_label = "Get Material"

    def draw(self, context):
        layout = self.layout
        layout.operator("sss.material_editor_create_material", text=tr("New Material"), icon="ADD")
        layout.operator("sss.material_editor_browse_scene_materials", text=tr("Browse Scene Materials"), icon="MATERIAL")
        layout.operator("sss.material_editor_load_material_library", text=tr("Load Material Library"), icon="FILE_FOLDER")


def _material_preview_request_key(material: bpy.types.Material) -> int:
    try:
        key = int(getattr(material, "session_uid", 0) or 0)
    except Exception:
        key = 0
    if key <= 0:
        try:
            key = int(material.as_pointer())
        except Exception:
            key = id(material)
    return key


def _material_preview_queue_tick():
    _MATERIAL_PREVIEW_QUEUE.clear()
    _MATERIAL_PREVIEW_REQUESTED_IDS.clear()
    return None


def _ensure_material_preview_timer() -> None:
    return None


def _request_material_preview(material: Optional[bpy.types.Material]) -> None:
    del material
    return None


def _draw_material_thumbnail(
    layout,
    material: Optional[bpy.types.Material],
    *,
    scale: float = 3.0,
) -> None:
    """Draw a safe, cached 3ds Max-style material sample thumbnail.

    ``template_icon`` uses Blender's ID preview cache and is intentionally used
    instead of multiple ``template_preview`` widgets.  The latter starts full
    preview widgets per cell and can become unstable or unnecessarily expensive
    when the classic 24-slot grid is visible.
    """
    if material is None:
        placeholder = layout.column(align=True)
        placeholder.scale_y = max(1.5, float(scale) * 0.72)
        placeholder.label(text=tr("Empty"), icon="MATERIAL")
        return

    try:
        icon_value = int(layout.icon(material))
    except Exception:
        icon_value = 0
    if icon_value > 0:
        layout.template_icon(icon_value=icon_value, scale=max(1.0, float(scale)))
    else:
        placeholder = layout.column(align=True)
        placeholder.scale_y = max(1.5, float(scale) * 0.72)
        placeholder.label(text=material.name, icon="MATERIAL", translate=False)


class SSSME_UL_slots(UIList):
    bl_idname = "SSSME_UL_slots"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        slot = item
        props = context.scene.sss_material_editor
        status_key, status_label, status_icon = material_status(context, slot.material)
        row = layout.row(align=True)
        op = row.operator("sss.material_editor_set_active_slot", text="", icon="RADIOBUT_ON" if index == props.active_index else "RADIOBUT_OFF", emboss=False)
        op.index = index
        preview = row.column(align=True)
        _draw_material_thumbnail(preview, slot.material, scale=2.0)
        row.prop(slot, "material", text="", emboss=False)
        row.label(text=status_label, icon=status_icon)
        if slot.material:
            row.label(text=str(slot.material.users), icon="USER")


def draw_slot_box(layout, context, index: int, preview_scale: float = 3.0) -> None:
    props = context.scene.sss_material_editor
    slot = slot_at(context.scene, index)
    if slot is None:
        return
    status_key, status_label, status_icon = material_status(context, slot.material)
    box = layout.box()
    row = box.row(align=True)
    op = row.operator("sss.material_editor_set_active_slot", text=f"{index + 1:02d}", icon="RADIOBUT_ON" if index == props.active_index else "RADIOBUT_OFF", depress=index == props.active_index)
    op.index = index
    row.label(text=status_label, icon=status_icon)
    _draw_material_thumbnail(box, slot.material, scale=preview_scale)
    box.prop(slot, "material", text="")


def draw_slot_grid(layout, context, count: int, columns: int) -> None:
    props = getattr(context.scene, "sss_material_editor", None)
    available = len(getattr(props, "slots", ())) if props is not None else 0
    count = min(int(count), int(available))
    rows = math.ceil(count / columns)
    # Keep the classic grids compact while retaining a readable sample sphere.
    # 3 columns can use a large icon; the 24-slot 6-column layout uses a smaller
    # thumbnail so it remains usable inside a normal Blender N-panel width.
    preview_scale = max(2.25, 15.0 / max(1, int(columns)))
    for r in range(rows):
        row = layout.row(align=True)
        for c in range(columns):
            i = r * columns + c
            if i < count:
                col = row.column(align=True)
                draw_slot_box(col, context, i, preview_scale=preview_scale)


def _draw_material_name_field(layout, mat) -> None:
    """The active material name field. It edits the real Material datablock.

    5.18.259 / requirement 1.  The field shows the datablock's current name and
    opens the in-place rename dialog seeded with it.  The write itself is
    ``mat.name = target`` inside SSSME_OT_rename_material, on the very
    datablock this row was drawn for, resolved by (name, library): the
    datablock is never copied, replaced or relinked, so its identity, its user
    count and every object slot, node tree and library reference pointing at it
    are unchanged by the rename.

    It is deliberately not a ``layout.prop(mat, "name")``.  That widget writes
    the same field but bypasses the snapshot invalidation and the Scene
    Materials selection re-sync the operator performs, which is finding M2-01.

    Read-only library data disables the field and states which case it is, so a
    linked, indirectly linked or library-overridden material is refused in the
    UI as well as inside the operator.
    """
    row = layout.row(align=True)
    row.label(text=f"{tr('Material Name')}:")
    field = row.row(align=True)
    field.enabled = _material_is_renamable(mat)
    op = field.operator(
        "sss.material_editor_rename_material",
        text=str(getattr(mat, 'name', '') or ''),
        icon="GREASEPENCIL",
    )
    op.material_name = mat.name
    op.material_library = _library_path_of(mat)
    op.new_name = ""
    badge_icon, badge_reason = _material_link_badge(mat)
    if badge_icon:
        layout.row(align=True).label(text=tr(badge_reason), icon=badge_icon)


def draw_active_material_summary(layout, context) -> None:
    mat = active_material(context)
    props = context.scene.sss_material_editor
    box = layout.box()
    box.label(text=tr("Active slot material"), icon="MATERIAL")
    if mat is None:
        box.label(text=tr("No active material."), icon="ERROR")
        return
    status_key, status_label, status_icon = material_status(context, mat)
    _draw_material_name_field(box, mat)
    row = box.row(align=True)
    row.label(text=f"{tr('Status')}: {status_label}", icon=status_icon)
    row.label(text=f"{tr('Users')}: {mat.users}", icon="USER")
    row = box.row(align=True)
    row.prop(props, "effect_channel", text=tr("Effects Channel ID"))
    row.label(text=f"{tr('Pass Index')}: {getattr(mat, 'pass_index', 0)}")


def draw_node_parameters(layout, context) -> None:
    mat = active_material(context)
    node = get_current_node(context)
    if mat is None or node is None:
        layout.label(text=tr("No editable node is selected."), icon="ERROR")
        return
    layout.label(text=f"{tr('Current Node')}: {node.name}", icon="NODE")
    select_node_in_tree(mat, node)
    inputs_drawn = 0
    for sock in node.inputs:
        if hasattr(sock, "default_value") and not sock.is_linked:
            try:
                layout.prop(sock, "default_value", text=sock.name)
                inputs_drawn += 1
            except Exception:
                pass
    if inputs_drawn == 0:
        layout.label(text=tr("No editable node is selected."))
















def _draw_material_editor_main(layout, context) -> None:
    props = context.scene.sss_material_editor
    layout.prop(props, "display_mode", text=tr("Display"))
    if props.display_mode == "GRID_3X2":
        draw_slot_grid(layout, context, 6, 3)
    elif props.display_mode == "GRID_5X3":
        draw_slot_grid(layout, context, 15, 5)
    elif props.display_mode == "GRID_6X4":
        draw_slot_grid(layout, context, 24, 6)
    else:
        layout.template_list("SSSME_UL_slots", "", props, "slots", props, "active_index", rows=8)
    row = layout.row(align=True)
    row.operator("sss.material_editor_add_slot", text=tr("Add Slot"), icon="ADD")
    row.operator("sss.material_editor_remove_slot", text=tr("Remove Slot"), icon="REMOVE")
    layout.operator("sss.material_editor_clear_slot", text=tr("Clear Slot"), icon="TRASH")
    draw_active_material_summary(layout, context)


def _section_box(layout, title: str, icon: str = "NONE"):
    box = layout.box()
    box.label(text=tr(title), icon=icon if icon else "NONE")
    return box


def _draw_scene_link(layout, context) -> None:
    col = layout.column(align=True)
    col.operator("sss.material_editor_assign_to_selection", text=tr("Assign Material to Selection"), icon="MATERIAL")
    col.operator("sss.material_editor_show_in_shader_editor", text=tr("Show in Shader Editor"), icon="NODE_MATERIAL")
    col.operator("sss.material_editor_pick_from_active", text=tr("Pick Material from Active Object"), icon="EYEDROPPER")
    col.operator("sss.material_editor_pick_from_shader_editor", text=tr("Pick Material from Shader Editor"), icon="NODE_MATERIAL")
    viewport_row = col.row(align=True)
    try:
        viewport_row.enabled = bool(getattr(getattr(context, "area", None), "type", "") == "VIEW_3D")
    except Exception:
        viewport_row.enabled = False
    viewport_row.operator("sss.material_editor_pick_from_viewport", text=tr("Pick Material from Viewport Click"), icon="VIEW3D")
    col.operator("sss.material_editor_select_by_material", text=tr("Select by Material"), icon="RESTRICT_SELECT_OFF")
    col.operator("sss.material_editor_put_to_scene", text=tr("Put Material to Scene"), icon="FILE_TICK")


def _draw_transfer(layout, context) -> None:
    props = context.scene.sss_material_editor
    row = layout.row(align=True)
    row.prop(props, "source_index", text=tr("Source"))
    row.prop(props, "target_index", text=tr("Target"))
    row = layout.row(align=True)
    op = row.operator("sss.material_editor_transfer_slot", text=tr("Copy"), icon="DUPLICATE")
    op.action = "COPY"
    op = row.operator("sss.material_editor_transfer_slot", text=tr("Instance"), icon="LINKED")
    op.action = "INSTANCE"
    op = row.operator("sss.material_editor_transfer_slot", text=tr("Swap"), icon="ARROW_LEFTRIGHT")
    op.action = "SWAP"



def _draw_library(layout, context) -> None:
    row = layout.row(align=True)
    row.menu("SSSME_MT_get_material", text=tr("Get Material"), icon="MATERIAL")
    row.operator("sss.material_editor_put_to_library", text=tr("Put to Library"), icon="FILE_TICK")
    col = layout.column(align=True)
    col.operator("sss.material_editor_make_unique", text=tr("Make Unique"), icon="UNLINKED")
    col.operator("sss.material_editor_reset_slot", text=tr("Reset Slot to Default"), icon="FILE_REFRESH")


def _draw_scene_material_filters(layout, context, state) -> None:
    del context
    row = layout.row(align=True)
    row.prop(state, "scene_material_filter", text="", icon="VIEWZOOM")
    row.prop(state, "scene_material_sort", text="")
    # The ALL/SCENE_USED scope switch is gone in 5.18.259: this list is defined
    # as the current scene's materials, so a scope that shows other scenes'
    # and unused datablocks has no correct setting.


def _draw_scene_material_rows(layout, context, state) -> None:
    rows = scene_material_index(context)
    total = len(rows)
    pages = max(1, (total + _SCENE_MATERIAL_PAGE_SIZE - 1) // _SCENE_MATERIAL_PAGE_SIZE)
    # Clamp into a local only.  Writing props.scene_material_page here would be
    # an RNA write from draw(), which unified_contract forbids.
    page = min(max(0, int(getattr(state, "scene_material_page", 0) or 0)), pages - 1)
    header = layout.row(align=True)
    header.label(text=f"{tr('Materials')}: {total}", icon="MATERIAL")
    if pages > 1:
        header.label(text=f"{tr('Page')} {page + 1} / {pages}")
    if total == 0:
        empty = tr("No material matched the current filter.")
        if not str(getattr(state, "scene_material_filter", "") or "").strip():
            empty = tr("No object in this scene uses a material.")
        layout.label(text=empty)
        return
    # B3-01: compare against what the selection RESOLVES to, not against the
    # persisted name, which an external rename leaves stale.  Falling back to
    # the persisted pair keeps the highlight correct when nothing resolves.
    resolved_identity = scene_tab_material_identity(context)
    if resolved_identity is None:
        active_name = str(getattr(state, "scene_material_active_name", "") or "")
        active_library = str(getattr(state, "scene_material_active_library", "") or "")
    else:
        active_name, active_library = resolved_identity
    body = layout.column(align=True)
    for entry in rows[page * _SCENE_MATERIAL_PAGE_SIZE:(page + 1) * _SCENE_MATERIAL_PAGE_SIZE]:
        name = entry["name"]
        library_path = entry["library_path"]
        is_active = name == active_name and library_path == active_library
        line = body.row(align=True)
        op = line.operator(
            "sss.material_editor_set_scene_material",
            text="",
            icon="RADIOBUT_ON" if is_active else "RADIOBUT_OFF",
            emboss=False,
        )
        op.material_name = name
        op.material_library = library_path
        # Name only.  No template_icon and no thumbnail: an N-panel draw must
        # never enqueue or render a material preview.  The label is read-only;
        # renaming is a button that runs the identity-carrying operator, never
        # a direct layout.prop(mat, "name") -- see M2-01.  This also removes
        # the per-row bpy.data lookup the rejected design did during draw.
        line.label(text=name, icon="MATERIAL", translate=False)
        line.label(text=str(entry["object_count"]), icon="USER")
        if entry["renamable"]:
            rename_op = line.operator(
                "sss.material_editor_rename_material",
                text="",
                icon="GREASEPENCIL",
                emboss=False,
            )
            rename_op.material_name = name
            rename_op.material_library = library_path
            rename_op.new_name = ""
        if entry["badge_icon"]:
            line.label(text="", icon=entry["badge_icon"])
    if pages > 1:
        pager = layout.row(align=True)
        prev_op = pager.operator("sss.material_editor_set_scene_material", text=tr("Prev"), icon="TRIA_LEFT")
        prev_op.page_delta = -1
        next_op = pager.operator("sss.material_editor_set_scene_material", text=tr("Next"), icon="TRIA_RIGHT")
        next_op.page_delta = 1


def _draw_scene_material_detail(layout, context, state) -> None:
    del state
    mat = scene_tab_material(context)
    if mat is None:
        layout.label(text=tr("No material is selected."))
        return
    library_path = _library_path_of(mat)
    # Same name field as the Standard tab, on the inspected datablock.
    _draw_material_name_field(layout, mat)
    status_key, status_label, status_icon = material_status(context, mat)
    info = layout.row(align=True)
    info.label(text=f"{tr('Status')}: {status_label}", icon=status_icon)
    info.label(text=f"{tr('Users')}: {mat.users}", icon="USER")
    actions = layout.row(align=True)
    # B2-01: a dedicated operator carrying (name, library).  The rejected
    # design drove the pre-existing bare-name picker with EXEC_DEFAULT, which
    # silently assigned a same-named LOCAL material instead of the LINKED one
    # the user had selected.  operator_context is left alone here.
    put_op = actions.operator(
        "sss.material_editor_put_scene_material_in_slot",
        text=tr("Put into Active Slot"),
        icon="MATERIAL",
    )
    put_op.material_name = mat.name
    put_op.material_library = library_path
    actions.operator("sss.material_editor_show_in_shader_editor", text=tr("Show in Shader Editor"), icon="NODE_MATERIAL")


def _draw_scene_material_object_users(layout, context, state) -> None:
    mat = scene_tab_material(context)
    if mat is None:
        return
    # Derived live from context.scene on every draw, deduplicated by object:
    # scene.objects yields each object once, so an object using the material in
    # several slots appears on exactly one row.  Drawing this list reads only;
    # it never changes the selection or any material assignment.
    rows = material_object_users(context, mat)
    header = layout.row(align=True)
    header.label(text=f"{tr('Objects')}: {len(rows)}", icon="OBJECT_DATA")
    header.prop(state, "scene_user_extend", text=tr("Extend selection"))
    if not rows:
        layout.label(text=tr("No object in this scene uses this material."))
        return
    extend = bool(getattr(state, "scene_user_extend", False))
    body = layout.column(align=True)
    for entry in rows:
        line = body.row(align=True)
        select_row = line.row(align=True)
        select_row.enabled = bool(entry["selectable"])
        op = select_row.operator("sss.material_editor_select_material_user", text="", icon="RESTRICT_SELECT_OFF")
        op.object_name = entry["name"]
        op.object_library = entry["object_library"]
        op.extend = extend
        line.label(text=entry["name"], icon="OBJECT_DATA", translate=False)
        parts = []
        if entry["slots_data"]:
            parts.append(f"{tr('data')} {','.join(str(i) for i in entry['slots_data'])}")
        if entry["slots_object"]:
            parts.append(f"{tr('object')} {','.join(str(i) for i in entry['slots_object'])}")
        if parts:
            line.label(text=" / ".join(parts))
        if entry["linked"]:
            line.label(text="", icon="LIBRARY_DATA_DIRECT")
        if entry["reason"]:
            line.label(text="", icon="ERROR" if not entry["in_view_layer"] else "HIDE_ON")
    select_all = layout.row(align=True)
    all_op = select_all.operator(
        "sss.material_editor_select_by_material",
        text=tr("Select All Objects Using This Material"),
        icon="RESTRICT_SELECT_OFF",
    )
    all_op.material_name = mat.name
    all_op.material_library = _library_path_of(mat)
    all_op.extend = extend


def _draw_scene_materials_tab(layout, context, state) -> None:
    listing = _section_box(layout, "Scene Materials", "MATERIAL")
    _draw_scene_material_filters(listing, context, state)
    _draw_scene_material_rows(listing, context, state)
    _draw_scene_material_detail(_section_box(layout, "Selected Material", "MATERIAL_DATA"), context, state)
    _draw_scene_material_object_users(_section_box(layout, "Objects Using This Material", "OBJECT_DATA"), context, state)


def draw_ui(layout, context) -> None:
    """Draw the integrated Material Editor inside the Smart Shader N-panel."""
    try:
        layout.label(text=tr("Material Editor"), icon="MATERIAL")
        props = getattr(context.scene, "sss_material_editor", None)
        if props is None:
            return
        # Switching tabs writes one transient enum on the WindowManager and
        # redraws.  It assigns, duplicates, deletes and rebuilds nothing: the
        # Standard branch below is entered unchanged, with the same slots, the
        # same active index and the same materials it had before the switch.
        state = editor_state(context)
        if state is not None:
            tabs = layout.row(align=True)
            tabs.prop(state, "editor_tab", expand=True)
        if state is not None and str(getattr(state, "editor_tab", "SLOTS") or "SLOTS") == "SCENE":
            _draw_scene_materials_tab(layout, context, state)
            return
        if len(getattr(props, "slots", ())) == 0:
            info = layout.box()
            info.label(text=tr("Slots are not initialized."))
            info.operator("sss.material_editor_initialize_slots", text=tr("Initialize Slots"), icon="ADD")
            return
        _draw_material_editor_main(layout, context)
        _draw_scene_link(_section_box(layout, "Scene Link", "LINK_BLEND"), context)
        _draw_transfer(_section_box(layout, "Slot Transfer", "ARROW_LEFTRIGHT"), context)
        _draw_library(_section_box(layout, "Library and Utilities", "ASSET_MANAGER"), context)
    except Exception as exc:
        warn = layout.box()
        warn.alert = True
        warn.label(text=tr("Material Editor UI error"), icon="ERROR")
        warn.label(text=_exc_text(exc))

classes = (
    SSSME_Slot,
    SSSME_Settings,
    SSSME_RuntimeState,
    SSSME_OT_initialize_slots,
    SSSME_OT_add_slot,
    SSSME_OT_remove_slot,
    SSSME_OT_clear_slot,
    SSSME_OT_set_active_slot,
    SSSME_OT_assign_to_selection,
    SSSME_OT_pick_from_active,
    SSSME_OT_pick_from_shader_editor,
    SSSME_OT_show_in_shader_editor,
    SSSME_OT_pick_from_viewport,
    SSSME_OT_select_node_in_hierarchy,
    SSSME_OT_select_by_material,
    SSSME_OT_put_to_scene,
    SSSME_OT_transfer_slot,
    SSSME_OT_create_material,
    SSSME_OT_browse_scene_materials,
    SSSME_OT_put_to_library,
    SSSME_OT_load_material_library,
    SSSME_OT_make_unique,
    SSSME_OT_reset_slot,
    SSSME_OT_rename_material,
    SSSME_OT_set_scene_material,
    SSSME_OT_select_material_user,
    SSSME_OT_put_scene_material_in_slot,
    SSSME_MT_get_material,
    SSSME_UL_slots,
)


def _auto_initialize_all_scenes():
    try:
        scenes = list(getattr(getattr(bpy, "data", None), "scenes", []) or [])
    except Exception:
        scenes = []
    for scene in scenes:
        if hasattr(scene, "sss_material_editor"):
            try:
                ensure_slots(scene)
            except Exception:
                pass
    return None


def _load_post(_dummy):
    _MATERIAL_EDITOR_RESTORED_SCENES.clear()
    # B3-01: session_uid values are reassigned when a .blend is loaded, so a
    # note taken before the load would name a different datablock.  Dropping
    # it here is what keeps the fallback unable to retarget across a file
    # change.  This adds no handler -- it is one line inside the handler this
    # module already registers.
    _SCENE_MATERIAL_SELECTION_UID.clear()
    _auto_initialize_all_scenes()


def _material_editor_settings_changed(*_args) -> None:
    try:
        save_material_editor_settings(getattr(bpy.context, 'scene', None))
    except Exception:
        pass


def _subscribe_material_editor_persistence() -> None:
    try:
        bpy.msgbus.clear_by_owner(_MATERIAL_EDITOR_MSGBUS_OWNER)
    except Exception:
        pass
    for owner_type, names in (
        (SSSME_Settings, _MATERIAL_EDITOR_SETTING_NAMES + ('custom_sample_object',)),
        (SSSME_Slot, ('name', 'material', 'note')),
    ):
        for name in names:
            try:
                bpy.msgbus.subscribe_rna(
                    key=(owner_type, name),
                    owner=_MATERIAL_EDITOR_MSGBUS_OWNER,
                    args=(),
                    notify=_material_editor_settings_changed,
                    options={'PERSISTENT'},
                )
            except Exception:
                pass


def set_load_restore_enabled(enabled: bool) -> None:
    """Toggle only the optional file-load restoration handler."""
    global _MATERIAL_EDITOR_LOAD_RESTORE_ENABLED
    _MATERIAL_EDITOR_LOAD_RESTORE_ENABLED = bool(enabled)
    try:
        while _load_post in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(_load_post)
    except Exception:
        pass
    if not _MATERIAL_EDITOR_LOAD_RESTORE_ENABLED:
        return
    try:
        bpy.app.handlers.load_post.append(_load_post)
    except Exception:
        pass
    _auto_initialize_all_scenes()


def register_properties():
    """Register integrated Material Editor runtime properties and handlers.

    Class registration is handled by Smart Shader Suite's addon_runtime so all
    operators are routed through the same duplicate-registration and UNDO policy.
    """
    _MATERIAL_PREVIEW_REQUESTED_IDS.clear()
    _MATERIAL_PREVIEW_QUEUE.clear()
    try:
        bpy.app.translations.register(__name__, _TRANSLATIONS)
    except ValueError:
        pass
    except Exception:
        pass
    if not hasattr(bpy.types.Scene, "sss_material_editor"):
        bpy.types.Scene.sss_material_editor = PointerProperty(type=SSSME_Settings)
    if not hasattr(bpy.types.Scene, "sss_material_editor"):
        raise RuntimeError("Smart Shader Suite material editor scene property was not registered.")
    # Direct RNA update callbacks above provide synchronous writes without a
    # permanently subscribed message-bus callback.
    try:
        bpy.msgbus.clear_by_owner(_MATERIAL_EDITOR_MSGBUS_OWNER)
    except Exception:
        pass
    scene = getattr(bpy.context, 'scene', None)
    restore_material_editor_settings(scene)
    if scene is not None:
        ensure_slots(scene, SLOT_DEFAULT_COUNT)
    save_material_editor_settings(scene, force=True)
    set_load_restore_enabled(_MATERIAL_EDITOR_LOAD_RESTORE_ENABLED)


def unregister_properties():
    _MATERIAL_PREVIEW_REQUESTED_IDS.clear()
    _MATERIAL_PREVIEW_QUEUE.clear()
    try:
        save_material_editor_settings(getattr(bpy.context, 'scene', None), force=True)
    except Exception:
        pass
    try:
        bpy.msgbus.clear_by_owner(_MATERIAL_EDITOR_MSGBUS_OWNER)
    except Exception:
        pass
    set_load_restore_enabled(False)
    pass
    try:
        if _load_post in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(_load_post)
    except Exception:
        pass
    pass
    try:
        if hasattr(bpy.types.Scene, "sss_material_editor"):
            del bpy.types.Scene.sss_material_editor
    except Exception:
        pass
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass


def register():
    # Standalone fallback for development only. The installed Smart Shader Suite
    # build registers classes through addon_runtime.
    for cls in classes:
        bpy.utils.register_class(cls)
    register_properties()


def unregister():
    unregister_properties()
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass


CLASSES = classes


if __name__ == "__main__":
    register()

# -----------------------------------------------------------------------------
# Smart Shader Suite 5.18.224 exact-owned, load-safe Material Editor runtime.
# -----------------------------------------------------------------------------
_MATERIAL_EDITOR_V1208_OWNED_POINTER = False
_MATERIAL_EDITOR_V1208_TRANSLATIONS_OWNED = False
# 5.18.259: ownership flag for the transient WindowManager state pointer, kept
# separate from the Scene pointer flag so a re-register that finds one already
# present never deletes the other generation's property.
_MATERIAL_EDITOR_OWNED_RUNTIME_POINTER = False


def set_load_restore_enabled(enabled: bool) -> None:
    """Install exactly one owned file-load restore callback while enabled."""
    global _MATERIAL_EDITOR_LOAD_RESTORE_ENABLED
    _MATERIAL_EDITOR_LOAD_RESTORE_ENABLED = bool(enabled)
    try:
        while _load_post in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(_load_post)
    except Exception:
        pass
    if not _MATERIAL_EDITOR_LOAD_RESTORE_ENABLED:
        return
    try:
        if _load_post not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(_load_post)
    except Exception:
        _MATERIAL_EDITOR_LOAD_RESTORE_ENABLED = False


def register_properties():
    global _MATERIAL_EDITOR_V1208_OWNED_POINTER, _MATERIAL_EDITOR_V1208_TRANSLATIONS_OWNED
    global _MATERIAL_EDITOR_OWNED_RUNTIME_POINTER
    _MATERIAL_PREVIEW_REQUESTED_IDS.clear()
    _MATERIAL_PREVIEW_QUEUE.clear()
    clear_scene_material_caches()
    try:
        bpy.app.translations.register(__name__, _TRANSLATIONS)
        _MATERIAL_EDITOR_V1208_TRANSLATIONS_OWNED = True
    except ValueError:
        _MATERIAL_EDITOR_V1208_TRANSLATIONS_OWNED = False
    existing = getattr(bpy.types.Scene, 'sss_material_editor', None)
    if existing is None:
        bpy.types.Scene.sss_material_editor = PointerProperty(type=SSSME_Settings)
        _MATERIAL_EDITOR_V1208_OWNED_POINTER = True
    else:
        _MATERIAL_EDITOR_V1208_OWNED_POINTER = False
    # 5.18.259: the transient editor state.  WindowManager, not Scene, so it is
    # never written into a .blend and resets with Blender.  This is a plain
    # PointerProperty registration -- no handler, timer, msgbus subscription or
    # keymap entry is added here or anywhere else in this module.
    if getattr(bpy.types.WindowManager, RUNTIME_STATE_ATTR, None) is None:
        setattr(bpy.types.WindowManager, RUNTIME_STATE_ATTR, PointerProperty(type=SSSME_RuntimeState))
        _MATERIAL_EDITOR_OWNED_RUNTIME_POINTER = True
    else:
        _MATERIAL_EDITOR_OWNED_RUNTIME_POINTER = False
    try:
        bpy.msgbus.clear_by_owner(_MATERIAL_EDITOR_MSGBUS_OWNER)
    except Exception:
        pass
    scene = getattr(getattr(bpy, 'context', None), 'scene', None)
    if scene is not None:
        restore_material_editor_settings(scene)
        ensure_slots(scene, SLOT_DEFAULT_COUNT)
    set_load_restore_enabled(False)


def unregister_properties():
    global _MATERIAL_EDITOR_V1208_OWNED_POINTER, _MATERIAL_EDITOR_V1208_TRANSLATIONS_OWNED
    _release_all_pinned_trees()
    _PINNED_MATERIAL_TREES.clear()
    _set_pinned_tree_watch(False)
    global _MATERIAL_EDITOR_OWNED_RUNTIME_POINTER
    _MATERIAL_PREVIEW_REQUESTED_IDS.clear()
    _MATERIAL_PREVIEW_QUEUE.clear()
    clear_scene_material_caches()
    try:
        bpy.msgbus.clear_by_owner(_MATERIAL_EDITOR_MSGBUS_OWNER)
    except Exception:
        pass
    set_load_restore_enabled(False)
    if _MATERIAL_EDITOR_OWNED_RUNTIME_POINTER and getattr(bpy.types.WindowManager, RUNTIME_STATE_ATTR, None) is not None:
        try:
            delattr(bpy.types.WindowManager, RUNTIME_STATE_ATTR)
        except Exception:
            pass
    _MATERIAL_EDITOR_OWNED_RUNTIME_POINTER = False
    if _MATERIAL_EDITOR_V1208_OWNED_POINTER and hasattr(bpy.types.Scene, 'sss_material_editor'):
        try:
            del bpy.types.Scene.sss_material_editor
        except Exception:
            pass
    _MATERIAL_EDITOR_V1208_OWNED_POINTER = False
    if _MATERIAL_EDITOR_V1208_TRANSLATIONS_OWNED:
        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
    _MATERIAL_EDITOR_V1208_TRANSLATIONS_OWNED = False

# Cached previews already present in the Material datablock may be drawn, but an
# N-panel draw must never enqueue/render previews or register a timer.
def _material_preview_queue_tick():
    _MATERIAL_PREVIEW_QUEUE.clear()
    _MATERIAL_PREVIEW_REQUESTED_IDS.clear()
    return None


def _ensure_material_preview_timer() -> None:
    return None


def _request_material_preview(material) -> None:
    del material
    return None
