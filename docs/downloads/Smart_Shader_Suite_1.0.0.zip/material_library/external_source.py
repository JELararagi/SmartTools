"""Read material libraries chosen by the user, without changing source files.

Implemented by Codex for JELararagi. SPDX-License-Identifier: GPL-3.0-or-later
"""
from pathlib import Path

import bpy
from bpy.props import EnumProperty, StringProperty
from bpy.types import Operator

from .. import slot_selection
from ..translation import loc_text as _lt


def _source_path(value):
    if not value:
        raise ValueError(_lt('Choose a .blend file.', '.blend ファイルを選択してください。'))
    path = Path(bpy.path.abspath(value)).resolve()
    if path.suffix.lower() != '.blend' or not path.is_file():
        raise ValueError(_lt('The chosen .blend file is missing.', '指定した .blend ファイルが見つかりません。'))
    if bpy.data.filepath and path == Path(bpy.data.filepath).resolve():
        raise ValueError(_lt('Choose a different .blend file.', '現在のシーンとは別の .blend を選択してください。'))
    return path


class MATLIB_OT_open_source_blend(Operator):
    bl_idname = 'matlib.open_source_blend'
    bl_label = _lt('Choose Source .blend', '素材の .blend を選択')
    bl_description = _lt('List materials from your .blend file', '選んだ .blend の材質を一覧にします')
    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default='*.blend', options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = context.scene.matlib.source_blend
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        try:
            path = _source_path(self.filepath)
            with bpy.data.libraries.load(str(path)) as (catalog, _):
                names = sorted(catalog.materials)
            if not names:
                raise ValueError(_lt('This file contains no materials.', 'このファイルに材質はありません。'))
        except (OSError, RuntimeError, ValueError) as error:
            self.report({'WARNING'}, str(error))
            return {'CANCELLED'}
        state = context.scene.matlib
        state.source_blend = str(path)
        state.source_materials.clear()
        for name in names:
            state.source_materials.add().name = name
        if state.source_material not in names:
            state.source_material = names[0]
        return {'FINISHED'}


class MATLIB_OT_apply_source_material(Operator):
    bl_idname = 'matlib.apply_source_material'
    bl_label = _lt('Apply Source Material', '素材ファイルの材質を適用')
    bl_description = _lt('Use the selected material on the active object', '選んだ材質をアクティブオブジェクトに適用します')
    bl_options = {'REGISTER', 'UNDO'}
    bl_property = 'sss_target_slot_token'
    sss_target_slot_token: EnumProperty(**slot_selection.MATERIAL_TARGET_SLOT_PROPERTY_KWARGS)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return bool(context.mode == 'OBJECT' and obj and obj.is_editable
                    and hasattr(obj.data, 'materials') and obj.data.is_editable
                    and context.scene.matlib.source_material)

    def invoke(self, context, event):
        result = slot_selection.invoke_operator_material_target_slot_search(self, context, assign_selected=False)
        return result or self.execute(context)

    def execute(self, context):
        state = context.scene.matlib
        try:
            path = _source_path(state.source_blend)
            with bpy.data.libraries.load(str(path), link=state.source_link, relative=False) as (catalog, requested):
                if state.source_material not in catalog.materials:
                    raise ValueError(_lt('The selected material is missing.', '選んだ材質がファイルにありません。'))
                requested.materials = [state.source_material]
        except (OSError, RuntimeError, ValueError) as error:
            self.report({'WARNING'}, str(error))
            return {'CANCELLED'}
        material = requested.materials[0]
        if material is None:
            self.report({'WARNING'}, _lt('Material could not be loaded.', '材質を読み込めませんでした。'))
            return {'CANCELLED'}
        obj = context.active_object
        slot_selection.apply_operator_material_target_slot(self, context)
        if obj.material_slots:
            obj.material_slots[obj.active_material_index].material = material
        else:
            obj.data.materials.append(material)
        return {'FINISHED'}


def draw(layout, state):
    box = layout.box()
    box.label(text=_lt('Materials from your .blend', '自分の .blend から材質を使う'), icon='MATERIAL')
    box.operator('matlib.open_source_blend', icon='FILE_FOLDER')
    if state.source_blend:
        box.label(text=Path(state.source_blend).name, translate=False)
        box.prop_search(state, 'source_material', state, 'source_materials', text=_lt('Material', '材質'))
        box.prop(state, 'source_link', text=_lt('Link to source', '元ファイルにリンク'))
        box.operator('matlib.apply_source_material', icon='MATERIAL')
