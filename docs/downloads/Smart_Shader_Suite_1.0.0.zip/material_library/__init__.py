# ============================================================================
# Material Library
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
# ============================================================================

from ..translation import loc_text as _lt
from ..translation import exc_text as _exc_text
from .. import storage
from .. import ui_sections
from .. import core
from .. import slot_selection
from . import external_source
from .. import tool_preferences as _st_prefs
bl_info = {'name': 'Material Library', 'author': 'JELararagi', 'version': (0, 6, 0), 'blender': (5, 1, 0), 'location': 'Smart Shader > Material Library', 'description': 'Reusable .blend material library workflow integrated into Smart Shader', 'warning': '', 'doc_url': '', 'tracker_url': '', 'category': 'Material'}
import bpy
import json
import re
import os
import tempfile
from pathlib import Path
from bpy.app.handlers import persistent
from bpy.props import StringProperty, IntProperty, BoolProperty, PointerProperty, CollectionProperty, EnumProperty
from ..translation import rna_text_context_prop as _rna_prop
StringProperty, BoolProperty, IntProperty, EnumProperty = map(_rna_prop, (StringProperty, BoolProperty, IntProperty, EnumProperty))


def _matlib_fallback_property_description(kwargs):
    label = str(kwargs.get('name') or '').strip() or 'Material Library setting'
    return _lt(
        f'JP: {label} のマテリアルライブラリ設定です。.blend ライブラリ、カテゴリ、検索、リンク/追加、プレビュー操作の対象を制御します。Nパネルで変更した状態は保存対象になります。\n'
        f'EN: {label} Material Library setting. It controls .blend libraries, categories, search, link/append behavior, and preview targets. N-panel changes are included in saved UI state.'
    )


def _matlib_wrap_property(factory):
    def _wrapped(*args, **kwargs):
        kwargs = dict(kwargs)
        if not kwargs.get('description'):
            kwargs['description'] = _matlib_fallback_property_description(kwargs)
        return factory(*args, **kwargs)
    return _wrapped


StringProperty = _matlib_wrap_property(StringProperty)
IntProperty = _matlib_wrap_property(IntProperty)
BoolProperty = _matlib_wrap_property(BoolProperty)
PointerProperty = _matlib_wrap_property(PointerProperty)
CollectionProperty = _matlib_wrap_property(CollectionProperty)
from bpy.types import Panel, Menu, Operator, PropertyGroup, UIList, Scene
from rna_prop_ui import PropertyPanel
dev = False


def _ensure_default_matlib_path() -> str:
    return str(storage.data_dir('material_library', create=True))


matlib_path = _ensure_default_matlib_path()
_MATLIB_DEFAULT_PATH = str(matlib_path or '')
_MATLIB_RUNTIME_PREFS = {'matlib_path': str(matlib_path or '')}
_MATLIB_UI_PERSISTENCE_APPLYING = False
_MATLIB_UI_CACHE: dict[str, object] | None = None
_MATLIB_UI_PROPS = ('lib_index', 'mat_index', 'cat_index', 'search', 'link', 'force_import', 'filter', 'show_prefs', 'last_selected', 'hide_search')


def _matlib_ui_settings_path() -> Path | None:
    try:
        return storage.settings_file('smart_shader_suite_material_library_ui_settings.json', create=True)
    except Exception:
        return None


def _matlib_rna_has_property(data, name: str) -> bool:
    if data is None or not name:
        return False
    try:
        props = getattr(getattr(data, 'bl_rna', None), 'properties', None)
    except Exception:
        props = None
    if props is None:
        return False
    try:
        return props.get(str(name)) is not None
    except Exception:
        pass
    try:
        return str(name) in props.keys()
    except Exception:
        return False


def _matlib_ui_collect(data) -> dict[str, object]:
    result: dict[str, object] = {}
    if data is None:
        return result
    for name in _MATLIB_UI_PROPS:
        if not _matlib_rna_has_property(data, name):
            continue
        try:
            value = getattr(data, name)
        except Exception:
            continue
        if isinstance(value, (str, int, float, bool)):
            result[name] = value
    return result


def _matlib_ui_read() -> dict[str, object]:
    try:
        data = storage.read_suite_section('material_library_ui', {})
        if isinstance(data, dict) and data:
            return data
    except Exception:
        pass
    path = _matlib_ui_settings_path()
    if path is None or not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def save_matlib_ui_settings(data=None) -> None:
    global _MATLIB_UI_CACHE
    if _MATLIB_UI_PERSISTENCE_APPLYING:
        return
    if data is None:
        try:
            data = getattr(getattr(bpy.context, 'scene', None), 'matlib', None)
        except Exception:
            data = None
    values = _matlib_ui_collect(data)
    if not values:
        return
    if values == _MATLIB_UI_CACHE:
        try:
            canonical = storage.read_suite_section('material_library_ui', {})
            if isinstance(canonical, dict) and canonical == values:
                return
        except Exception:
            pass
    try:
        if not storage.npanel_state_save_enabled(default=True):
            return
    except Exception:
        pass
    try:
        if storage.write_suite_section('material_library_ui', values):
            _MATLIB_UI_CACHE = dict(values)
            return
    except Exception:
        pass


def apply_matlib_ui_settings(data=None) -> None:
    global _MATLIB_UI_PERSISTENCE_APPLYING, _MATLIB_UI_CACHE
    if data is None:
        try:
            data = getattr(getattr(bpy.context, 'scene', None), 'matlib', None)
        except Exception:
            data = None
    if data is None:
        return
    saved = _matlib_ui_read()
    if not saved:
        _MATLIB_UI_CACHE = _matlib_ui_collect(data)
        return
    _MATLIB_UI_PERSISTENCE_APPLYING = True
    try:
        for name, value in saved.items():
            if name in _MATLIB_UI_PROPS and _matlib_rna_has_property(data, name):
                try:
                    setattr(data, name, value)
                except Exception:
                    pass
    finally:
        _MATLIB_UI_PERSISTENCE_APPLYING = False
    _MATLIB_UI_CACHE = _matlib_ui_collect(data)


def _matlib_run_ui_update(self, context, callback=None):
    try:
        if callable(callback):
            callback(self, context)
    finally:
        if not _MATLIB_UI_PERSISTENCE_APPLYING:
            save_matlib_ui_settings(self)


def _matlib_update_ui_only(self, context):
    _matlib_run_ui_update(self, context, None)


def _matlib_update_lib_index(self, context):
    _matlib_run_ui_update(self, context, update_lib_index)


def _matlib_update_cat_index(self, context):
    _matlib_run_ui_update(self, context, update_cat_index)


def _matlib_update_search_index(self, context):
    _matlib_run_ui_update(self, context, update_search_index)


def _matlib_update_filter(self, context):
    _matlib_run_ui_update(self, context, update_filter)


# Backward-compatible helper for old internal callers.  Blender property
# definitions below use named two-argument functions directly so RNA
# registration never receives a zero-argument callback by mistake.
def _matlib_chain_ui_update(callback=None):
    def _update(self, context):
        _matlib_run_ui_update(self, context, callback)
    return _update


@persistent
def _matlib_apply_ui_on_load(_dummy=None):
    try:
        from .. import transform_guard as _sss_transform_guard
        with _sss_transform_guard.preserve_object_transforms('material library settings load_post'):
            for scene in bpy.data.scenes:
                apply_matlib_ui_settings(getattr(scene, 'matlib', None))
    except Exception:
        pass


@persistent
def _matlib_save_ui_on_save(_dummy=None):
    try:
        from .. import transform_guard as _sss_transform_guard
        with _sss_transform_guard.preserve_object_transforms('material library settings save_pre'):
            for scene in bpy.data.scenes:
                save_matlib_ui_settings(getattr(scene, 'matlib', None))
    except Exception:
        pass


def _matlib_register_ui_persistence_handler() -> None:
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        load_post = getattr(handlers, 'load_post', None) if handlers is not None else None
        save_pre = getattr(handlers, 'save_pre', None) if handlers is not None else None
        if load_post is not None and _matlib_apply_ui_on_load not in load_post:
            load_post.append(_matlib_apply_ui_on_load)
        if save_pre is not None and _matlib_save_ui_on_save not in save_pre:
            save_pre.append(_matlib_save_ui_on_save)
    except Exception:
        pass


def _matlib_unregister_ui_persistence_handler() -> None:
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        load_post = getattr(handlers, 'load_post', None) if handlers is not None else None
        save_pre = getattr(handlers, 'save_pre', None) if handlers is not None else None
        if load_post is not None and _matlib_apply_ui_on_load in load_post:
            load_post.remove(_matlib_apply_ui_on_load)
        if save_pre is not None and _matlib_save_ui_on_save in save_pre:
            save_pre.remove(_matlib_save_ui_on_save)
    except Exception:
        pass


def set_ui_persistence_enabled(enabled: bool) -> None:
    _matlib_unregister_ui_persistence_handler()
    if bool(enabled):
        _matlib_register_ui_persistence_handler()

def _matlib_auto_refresh_enabled(context=None):
    value = _st_prefs.tool_value('material_library', 'auto_refresh_on_load', context=context, default=False)
    return bool(value)


_MATLIB_AUTO_REFRESH_HANDLER_LEDGER = []


def _matlib_remove_owned_auto_refresh_handler():
    for container, callback in reversed(tuple(_MATLIB_AUTO_REFRESH_HANDLER_LEDGER)):
        try:
            if callback in container:
                container.remove(callback)
        except Exception:
            pass
    _MATLIB_AUTO_REFRESH_HANDLER_LEDGER.clear()


def unregister_owned_callbacks():
    """Remove only resident callbacks actually appended by this module."""
    _matlib_remove_owned_auto_refresh_handler()


def _sync_matlib_load_post_handler(context=None):
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    load_post = getattr(handlers, 'load_post', None) if handlers is not None else None
    if load_post is None:
        return
    enabled = _matlib_auto_refresh_enabled(context)
    if enabled:
        if refresh_libs not in load_post:
            load_post.append(refresh_libs)
            if not any(container is load_post and callback is refresh_libs for container, callback in _MATLIB_AUTO_REFRESH_HANDLER_LEDGER):
                _MATLIB_AUTO_REFRESH_HANDLER_LEDGER.append((load_post, refresh_libs))
    else:
        _matlib_remove_owned_auto_refresh_handler()

def _matlib_auto_refresh_update(_self=None, context=None):
    _sync_matlib_load_post_handler(context)

def _ensure_libraries_loaded():
    global libraries
    global matlib_path
    if libraries:
        return libraries
    default_path = _get_matlib_pref_path()
    if default_path:
        matlib_path = default_path
    libraries = get_libraries()
    return libraries

def _matlib_addon_preferences():
    prefs = _st_prefs.addon_preferences(getattr(bpy, 'context', None))
    if prefs is not None and _matlib_rna_has_property(prefs, _st_prefs.prop_name('material_library', 'path')):
        return prefs
    return None

def _get_matlib_pref_path():
    value = _st_prefs.tool_value('material_library', 'path', context=getattr(bpy, 'context', None), default='')
    value = str(value or '').strip()
    if value:
        return value
    runtime_value = str(_MATLIB_RUNTIME_PREFS.get('matlib_path', '') or '').strip()
    if runtime_value:
        return runtime_value
    return str(_MATLIB_DEFAULT_PATH or '').strip()

def _set_matlib_pref_path(value):
    text = str(value or '').strip()
    if text:
        try:
            text = bpy.path.abspath(text)
        except Exception:
            pass
    _MATLIB_RUNTIME_PREFS['matlib_path'] = text
    _st_prefs.set_tool_value('material_library', 'path', text, context=getattr(bpy, 'context', None))
    return text

def dd(*args, dodir=False):
    if dev:
        if dodir:
            None
        None

def winpath(path):
    return path.replace('\\', '\\\\')

def update_search_index(self, context):
    search = self.search
    for i, it in enumerate(self.materials):
        if it.name == search:
            self.mat_index = i
            break

def check_path(path):
    if path and os.path.exists(path) and os.path.isfile(path) and os.path.isabs(path):
        try:
            if bpy.data.filepath and bpy.path.relpath(bpy.data.filepath) == bpy.path.relpath(path):
                return False
        except:
            pass
        return True
    return False

def update_lib_index(self, context):
    self.load_library()

def update_cat_index(self, context):
    dd('cat index:', self.current_category, self.filter)
    if self.filter:
        self.filter = True

def update_filter(self, context):
    dd('filter:', self.filter, self.cat_index, self.current_category)
    self.update_list()

def check_index(collection, index):
    count = len(collection)
    return count > 0 and index < count and (index >= 0)

def send_command(cmd, output='sendmat.py'):
    bin = winpath(bpy.app.binary_path)
    script_path_obj = storage.runtime_file(output, 'material_library_scripts', create=True)
    scriptpath = winpath(str(script_path_obj))
    try:
        try:
            with open(scriptpath, 'w', encoding='utf-8') as f:
                f.write(cmd)
        except Exception as exc:
            dd('material library command script write failed:', exc)
            return 0
        try:
            import subprocess
            if output == 'createlib.py':
                args = [bin, '-b', '--python-exit-code', '1', '-P', scriptpath]
            else:
                current = getattr(getattr(bpy.context, 'scene', None), 'matlib', None)
                library = getattr(current, 'current_library', None)
                libpath_raw = getattr(library, 'path', '')
                if not libpath_raw:
                    return 0
                args = [bin, '-b']
                if output.startswith('read_categories_'):
                    args.extend(['--factory-startup', '--disable-autoexec', '--offline-mode', '--threads', '1'])
                args.extend([winpath(libpath_raw), '--python-exit-code', '1', '-P', scriptpath])
            completed = subprocess.run(args, check=False, timeout=300)
            code = getattr(completed, 'returncode', None)
        except Exception as exc:
            dd('material library background command failed:', exc)
            return 0
        return int(type(code) is int and code == 0)
    finally:
        try:
            Path(script_path_obj).unlink(missing_ok=True)
        except Exception:
            pass

def list_materials(path, sort=False):
    list = []
    with bpy.data.libraries.load(path) as (data_from, data_to):
        for mat in data_from.materials:
            list.append(mat)
    if sort:
        list = sorted(list)
    return list

class EmptyGroup(PropertyGroup):
    pass

class matlibMaterials(PropertyGroup):
    category: StringProperty()

class Categories:

    def __init__(self, cats):
        self.cats = cats

    def save(self):
        scn = bpy.context.scene
        cats = set([cat.name for cat in self.cats])
        libpath = bpy.context.scene.matlib.current_library.path
        cmd = '\npass\nimport bpy\nif not hasattr(bpy.types.Scene, "matlib_categories"):\n  class EmptyProps(bpy.types.PropertyGroup):\n    pass\n  bpy.utils.register_class(EmptyProps)\n  bpy.types.Scene.matlib_categories = bpy.props.CollectionProperty(type=EmptyProps)\ncats = bpy.context.scene.matlib_categories\nfor cat in cats:\n  cats.remove(0)\n'
        for cat in cats:
            cmd += '\ncat = cats.add()\ncat.name = "%s" ' % cat.capitalize()
        cmd += '\nbpy.ops.wm.save_mainfile(filepath="%s", check_existing=False, compress=True)' % winpath(libpath)
        return send_command(cmd, 'save_categories.py')

    def read(self, pull=True):
        if not pull:
            with open(os.path.join(matlib_path, 'categories.txt'), encoding='utf-8') as saved:
                return json.load(saved)
        runtime = storage.runtime_dir('material_library_scripts', create=True)
        with tempfile.TemporaryDirectory(prefix='read_categories_', dir=runtime) as folder:
            catfile = str(Path(folder) / 'categories.json')
            cmd = '\nimport bpy, json\nclass EmptyProps(bpy.types.PropertyGroup):\n  pass\nbpy.utils.register_class(EmptyProps)\nbpy.types.Scene.matlib_categories = bpy.props.CollectionProperty(type=EmptyProps)\ncats = []\nfor cat in bpy.context.scene.matlib_categories:\n  materials = []\n  for mat in bpy.data.materials:\n    if "category" in mat.keys() and mat[\'category\'] == cat.name:\n      materials.append(mat.name)\n  cats.append([cat.name, materials])\nwith open(%r, "w", encoding="utf-8") as f:\n  f.write(json.dumps(cats, sort_keys=True, indent=4))\n' % catfile
            if not send_command(cmd, Path(folder).name + '.py'):
                raise RuntimeError(_lt('Could not read library categories.', 'カテゴリを読み込めませんでした。'))
            with open(catfile, encoding='utf-8') as result:
                return json.load(result)


    def view(self):
        for cat in self.cats:
            dd(cat.name)

    def add(self, name):
        if name and name not in [item.name for item in self.cats]:
            name = name.strip().capitalize()
            item = self.cats.add()
            item.name = name
            if self.save():
                dd(name, 'added')
                return True
        else:
            dd('duplicated?')

    def remove(self, index):
        self.cats.remove(index)
        self.save()

class Library:

    def __init__(self, matlib_path, name):
        self.name = name
        self.path = os.path.join(matlib_path, name)

    @property
    def shortname(self):
        return bpy.path.display_name(self.name).title()

    def __repr__(self):
        return str(type(self).__name__) + "('" + self.name + "')"

def get_libraries():
    if not matlib_path or not os.path.isdir(matlib_path):
        return []
    libs = [Library(matlib_path, f) for f in os.listdir(matlib_path) if f[-5:] == 'blend']
    return sorted(libs, key=lambda x: bpy.path.display_name(x.name))
libraries = []

class matlibProperties(PropertyGroup):
    source_blend: StringProperty(subtype='FILE_PATH')
    source_material: StringProperty()
    source_materials: CollectionProperty(type=matlibMaterials)
    source_link: BoolProperty(default=False)
    lib_index: IntProperty(min=-1, default=2, update=_matlib_update_lib_index)
    all_materials: CollectionProperty(type=matlibMaterials)
    materials: CollectionProperty(type=matlibMaterials)
    mat_index: IntProperty(min=-1, default=-1, update=_matlib_update_ui_only)
    categories: CollectionProperty(type=EmptyGroup)
    cat_index: IntProperty(min=-1, default=-1, update=_matlib_update_cat_index)
    search: StringProperty(name=_lt('Search'), description=_lt('Find By Name'), update=_matlib_update_search_index)
    link: BoolProperty(name=_lt('Linked'), description=_lt('Link the material'), default=False, update=_matlib_update_ui_only)
    force_import: BoolProperty(name=_lt('Force Import'), description=_lt('Use Scene Materials by default'), default=False, update=_matlib_update_ui_only)
    filter: BoolProperty(name=_lt('Filter'), description=_lt('Filter Categories'), default=True, update=_matlib_update_filter)
    show_prefs: BoolProperty(name=_lt('show_prefs'), description=_lt('Preferences'), default=False, update=_matlib_update_ui_only)
    last_selected: StringProperty(name=_lt('Last Selected'), update=_matlib_update_ui_only)
    hide_search: BoolProperty(name=_lt('Hide Search'), description=_lt('Use Blender Search Only'), update=_matlib_update_ui_only)

    @property
    def libraries(self):
        global libraries
        return _ensure_libraries_loaded()

    @property
    def current_library(self):
        current_libraries = _ensure_libraries_loaded()
        if check_index(current_libraries, self.lib_index):
            return current_libraries[self.lib_index]

    @property
    def active_material(self):
        if check_index(self.materials, self.mat_index):
            return self.materials[self.mat_index]

    def reload(self):
        dd('loading libraries')
        current_libraries = _ensure_libraries_loaded()
        if self.current_library:
            return self.load_library()
        elif self.lib_index == -1 and len(current_libraries):
            self.lib_index = 0
        return None

    def reload_library(self):
        """Reload the currently selected library. Kept for operator compatibility."""
        return self.load_library()

    def add_library(self, path, setEnabled=False):
        ext = os.path.extsep + 'blend'
        if not path.endswith(ext):
            path += ext
        if check_path(path):
            return ('ERROR', _lt('Library already exists.'))
        else:
            dd("Can't find " + path)
            cmd = (
                "import bpy\nbpy.ops.wm.read_factory_settings(use_empty=True)\n"
                f"bpy.ops.wm.save_mainfile(filepath={path!r}, check_existing=False, compress=True)"
            )
            if not send_command(cmd, 'createlib.py'):
                return ('ERROR', _lt('There was an error creating the file. Make sure you run Blender with admin rights.'))
            dd('adding library', path)
            global libraries
            libraries = get_libraries()
            return ('INFO', _lt('Library added'))

    def load_library(self):
        self.empty_list(True)
        if not self.current_library:
            return ('ERROR', _lt('Library not found!.'))
        path = self.current_library.path
        dd('loading library', self.lib_index, path)
        if check_path(path):
            self.filter = False
            self.cat_index = -1
            categories = Categories(self.categories)
            self.cats = categories.read(True)
            self.load_categories()
            for mat in self.all_materials:
                self.all_materials.remove(0)
            for mat in list_materials(self.current_library.path, True):
                item = self.all_materials.add()
                item.name = mat
                for cat in self.cats:
                    if mat in cat[1]:
                        item.category = cat[0]
                        break
            self.update_list()
        else:
            return ('ERROR', _lt('Library not found!.'))

    def update_list(self):
        self.empty_list()
        if self.current_library:
            current_category = self.current_category
            for mat in self.all_materials:
                if not self.filter or (self.filter and mat.category == current_category) or current_category == '':
                    item = self.materials.add()
                    item.name = mat.name
                    item.category = mat.category

    def empty_list(self, cats=False):
        for it in self.materials:
            self.materials.remove(0)
        if cats:
            for c in self.categories:
                self.categories.remove(0)

    @property
    def current_category(self):
        if check_index(self.categories, self.cat_index):
            return self.categories[self.cat_index].name
        return ''

    def load_categories(self):
        for c in self.categories:
            self.categories.remove(0)
        for c in self.cats:
            cat = self.categories.add()
            cat.name = c[0]

    def add_category(self, name):
        if name:
            name = name.strip().title()
            dd('add category', name)
            categories = Categories(self.categories)
            categories.add(name)

    def remove_category(self):
        dd('removing category', self.current_category)
        if not check_index(self.categories, self.cat_index):
            return
        categories = Categories(self.categories)
        categories.remove(self.cat_index)

    def set_category(self):
        mat = self.active_material
        if mat:
            item = next((it for it in self.all_materials if it.name == mat.name), None)
            if item is None:
                return ('WARNING', _lt('Select a material'))
            cat = self.current_category if self.cat_index > -1 else ''
            if cat == item.category:
                return
            if cat:
                assign = 'mat[\'category\'] = "%s"' % cat
            else:
                assign = 'mat.pop(\'category\', None)'
            cmd = '\nimport bpy\ntry:\n  mat = bpy.data.materials[\'%s\']\nexcept:\n  mat = None\nif mat:\n  %s\n  bpy.ops.wm.save_mainfile(filepath="%s", check_existing=False, compress=True)\n' % (mat.name, assign, winpath(self.current_library.path))
            if send_command(cmd):
                item.category = cat
                mat.category = cat
            else:
                return ('WARNING', _lt('There was an error.'))
        else:
            return ('WARNING', _lt('Select a material'))

    def get_material(self, name, link=False):
        with bpy.data.libraries.load(self.current_library.path, link=link, relative=False) as (data_from, data_to):
            data_to.materials = [name]
        if link:
            None
        else:
            None

    def apply(self, context, preview=False):
        if not self.active_material:
            return ('WARNING', _lt('Select a material from the list.'))
        name = self.active_material.name
        if not name:
            return ('WARNING', _lt('Select a material from the list.'))
        linked = self.link or preview
        force = self.force_import or linked
        objects = []
        active = context.object
        dummy = self.get_dummy(context)
        if preview:
            if context.mode == 'EDIT_MESH':
                return ('WARNING', _lt("Can't preview on EDIT MODE"))
            if dummy != active:
                self.last_selected = active.name if active is not None else ''
            context.view_layer.objects.active = dummy
            objects.append(dummy)
        else:
            objects = [obj for obj in context.selected_objects if hasattr(obj.data, 'materials')]
        if not objects:
            return ('INFO', _lt('Please select an object'))
        if dummy == context.object and (not preview):
            if len(objects) == 1 and dummy.select_get():
                return ('ERROR', _lt('Apply is disabled for the Material Preview Object'))
            try:
                last = context.scene.objects[self.last_selected]
                if last in context.selected_objects:
                    context.view_layer.objects.active = last
                else:
                    self.last_selected = ''
            except:
                context.view_layer.objects.active = None
        dummy.select_set(False)
        material = None
        for mat in bpy.data.materials:
            try:
                samelib = bpy.path.relpath(mat.library.filepath) == bpy.path.relpath(self.current_library.path)
            except:
                samelib = False
            if mat.name == name and mat.library and samelib:
                material = mat
                dd('encontre linked', name, 'no importo nada')
                break
        if not force:
            for mat in bpy.data.materials:
                if mat.name == name and (not mat.library):
                    material = mat
                    dd('encontre no linkado', name, 'no importo nada')
                    break
        if not material:
            dd('voy a buscarlo')
            nmats = len(bpy.data.materials)
            self.get_material(name, linked)
            if not self.force_import:
                try:
                    material = bpy.data.materials[name]
                except:
                    pass
            if not material:
                if nmats == len(bpy.data.materials) and (not linked):
                    return ('ERROR', _lt(f"JP: {name} はライブラリに存在しません ({linked})\nEN: {name} does not exist in library ({linked})"))
                else:
                    for mat in reversed(bpy.data.materials):
                        if mat.name[0:len(name)] == name:
                            try:
                                samelib = bpy.path.relpath(mat.library.filepath) == bpy.path.relpath(self.current_library.path)
                            except:
                                samelib = False
                            if linked and mat.library and samelib:
                                material = mat
                                dd(name, 'importado con link')
                                break
                            elif not mat.library:
                                dd(name, 'importado sin link')
                                material = mat
                                break
                if material:
                    material.use_fake_user = False
                    material.user_clear()
        None
        if context.mode == 'EDIT_MESH':
            obj = context.object
            dd(material)
            index = -1
            for i, mat in enumerate(obj.data.materials):
                if mat == material:
                    index = i
                    break
            if index == -1:
                obj.data.materials.append(material)
                index = len(obj.data.materials) - 1
            dd(index)
            import bmesh
            bm = bmesh.from_edit_mesh(obj.data)
            for f in bm.faces:
                if f.select:
                    f.material_index = index
        else:
            for obj in objects:
                index = core.selected_material_slot_index(context, obj)
                if index < len(obj.material_slots):
                    obj.material_slots[index].material = None
                    obj.material_slots[index].material = material
                else:
                    obj.data.materials.append(material)
            if not linked:
                bpy.ops.object.make_local(type='SELECT_OBDATA_MATERIAL')

    def apply_material(self, context, preview=False):
        return self.apply(context, preview)

    def add_material(self, mat):
        if not mat:
            return ('WARNING', _lt('Select a material from the scene.'))
        name = mat.name
        library = self.current_library
        if library is None:
            return ('WARNING', _lt('Library not found.', 'ライブラリが見つかりません。'))
        libpath = winpath(library.path)
        if not libpath:
            return ('WARNING', _lt('Library not found.', 'ライブラリが見つかりません。'))
        if mat.library:
            return ('WARNING', _lt('Cannot export linked materials.'))
        dd('adding material', name, libpath)
        overwrite = name in list_materials(libpath)
        # Snapshot only this material and its dependencies. Export must not save
        # the user's working scene or read an older, on-disk material state.
        with tempfile.TemporaryDirectory(prefix='smartshader_material_') as temp_dir:
            snapshot = str(Path(temp_dir) / 'material.blend')
            bpy.data.libraries.write(snapshot, {mat}, path_remap='ABSOLUTE', fake_user=True, compress=True)
            replace_existing = (
                f"mat = bpy.data.materials[{name!r}]\n"
                "mat.name = 'tmp'\nmat.use_fake_user = False\nmat.user_clear()\n"
            ) if overwrite else ''
            cmd = (
                "import bpy\n" + replace_existing
                + f"with bpy.data.libraries.load({snapshot!r}) as (data_from, data_to):\n"
                + f"    data_to.materials = [{name!r}]\n"
                + f"mat = bpy.data.materials[{name!r}]\nmat.use_fake_user = True\n"
                + "bpy.ops.file.pack_all()\n"
                + f"bpy.ops.wm.save_mainfile(filepath={libpath!r}, check_existing=False, compress=True)\n"
            )
            saved = send_command(cmd)
        if saved:
            if not overwrite:
                item = self.all_materials.add()
                item.name = name
                if 'category' in mat.keys():
                    item.category = mat['category']
                items = sorted([[item.name, item.category] for item in self.all_materials], key=lambda x: x[0])
                self.all_materials.clear()
                for it in items:
                    item = self.all_materials.add()
                    item.name = it[0]
                    item.category = it[1]
                self.update_list()
            return ('INFO', _lt('Material added.'))
        else:
            None
            return ('WARNING', _lt('The material could not be saved.', 'マテリアルを保存できませんでした。'))

    def remove_material(self):
        if not self.active_material:
            return ('WARNING', _lt('Select a material from the list.'))
        name = self.active_material.name
        libpath = winpath(self.current_library.path)
        if name and libpath and (name in list_materials(libpath)):
            cmd = 'import bpy\nmat = bpy.data.materials["%s"]\nmat.use_fake_user = False\nmat.user_clear()\nbpy.ops.wm.save_mainfile(filepath="%s", check_existing=False, compress=True)' % (name, libpath)
            if send_command(cmd, 'removemat.py'):
                for index, item in enumerate(self.all_materials):
                    if item.name == name:
                        self.all_materials.remove(index)
                        break
                self.update_list()
            else:
                return ('ERROR', _lt('The material could not be removed.', 'マテリアルを削除できませんでした。'))
        else:
            return ('ERROR', _lt('The material could not be removed.', 'マテリアルを削除できませんでした。'))
        return ('INFO', _lt(f'{name} removed.', f'{name} を削除しました。'))

    def get_dummy(self, context):
        dummy_name = 'Material_Preview_Dummy'
        dummy_mesh = 'Material_Preview_Mesh'
        scn = context.scene
        try:
            dummy = scn.objects[dummy_name]
        except:
            try:
                me = bpy.data.meshes(dummy_mesh)
            except:
                me = bpy.data.meshes.new(dummy_mesh)
            dummy = bpy.data.objects.new(dummy_name, me)
            context.collection.objects.link(dummy)
        dummy.hide_set(True)
        dummy.hide_render = True
        dummy.hide_select = True
        return dummy

class MATLIB_MT_MaterialLibraryMenu(Menu):
    bl_idname = 'MATLIB_MT_MaterialLibraryMenu'
    bl_label = _lt('Material Library Menu', 'マテリアルライブラリメニュー')

    def draw(self, context):
        layout = self.layout
        libs = libraries
        for i, lib in enumerate(libs):
            layout.operator('matlib.create_item', text=lib.shortname).cmd = 'lib' + str(i)

class MATLIB_MT_MaterialCategoryMenu(Menu):
    bl_idname = 'MATLIB_MT_MaterialCategoryMenu'
    bl_label = _lt('Material Category Menu', 'マテリアルカテゴリメニュー')

    def draw(self, context):
        layout = self.layout
        cats = context.scene.matlib.categories
        layout.operator('matlib.create_item', text=_lt('Show All Categories')).cmd = 'cat-1'
        for i, cat in enumerate(cats):
            layout.operator('matlib.create_item', text=cat.name, translate=False).cmd = 'cat' + str(i)

def _scene_material_for_library_export(context, matlib):
    obj = context.object
    dummy = context.scene.objects.get('Material_Preview_Dummy')
    if obj is not None and obj == dummy:
        obj = context.view_layer.objects.get(matlib.last_selected)
        if obj == dummy or obj not in context.selected_objects:
            return None
    return getattr(obj, 'active_material', None)


class MATLIB_OT_add_active_material(Operator):
    """Add active material to library"""
    bl_idname = 'matlib.add_active_material'
    bl_label = _lt('Add Active Material', 'アクティブマテリアル追加')
    bl_options = set()

    @classmethod
    def poll(cls, context):
        matlib = context.scene.matlib
        return _scene_material_for_library_export(context, matlib) is not None

    def execute(self, context):
        matlib = context.scene.matlib
        success = matlib.add_material(_scene_material_for_library_export(context, matlib))
        if type(success).__name__ == 'tuple':
            self.report({success[0]}, _lt(success[1]))
            if success[0] in {'WARNING', 'ERROR'}:
                return {'CANCELLED'}
        return {'FINISHED'}


def _matlib_measure_ui_text_px(text):
    text = str(text or '')
    if not text:
        return 0.0
    try:
        import blf  # type: ignore
        font_id = 0
        try:
            blf.size(font_id, 11)
        except TypeError:
            blf.size(font_id, 11, 72)
        width, _height = blf.dimensions(font_id, text)
        return float(width)
    except Exception:
        # Fallback for syntax checks or non-Blender execution. Japanese glyphs are
        # usually wider than Latin glyphs, so count them conservatively.
        width = 0.0
        for ch in text:
            width += 12.0 if ord(ch) > 127 else 7.0
        return width


def _matlib_region_text_width_px(context, padding_px=54):
    try:
        region_width = int(getattr(getattr(context, 'region', None), 'width', 0) or 0)
    except Exception:
        region_width = 0
    if region_width <= 0:
        region_width = 240
    return max(72.0, float(region_width - padding_px))


def _matlib_text_units(text):
    # Keep Latin words together while allowing Japanese labels to wrap per glyph.
    raw = str(text or '')
    units = []
    word = ''
    for ch in raw:
        if ch.isspace():
            if word:
                units.append(word)
                word = ''
            units.append(ch)
        elif ord(ch) < 128 and (ch.isalnum() or ch in "._-:/\\"):
            word += ch
        else:
            if word:
                units.append(word)
                word = ''
            units.append(ch)
    if word:
        units.append(word)
    return units or ['']


def _matlib_wrap_ui_text(context, text, padding_px=54):
    raw = str(text or '').strip()
    if not raw:
        return ['']
    max_px = _matlib_region_text_width_px(context, padding_px=padding_px)
    if _matlib_measure_ui_text_px(raw) <= max_px:
        return [raw]

    lines = []
    current = ''
    for unit in _matlib_text_units(raw):
        candidate = (current + unit) if current else unit.lstrip()
        if current and _matlib_measure_ui_text_px(candidate.rstrip()) > max_px:
            lines.append(current.rstrip())
            current = unit.lstrip()
        else:
            current = candidate

        # Extremely long Latin tokens still need a safe character-level break.
        while current and _matlib_measure_ui_text_px(current.rstrip()) > max_px and len(current) > 1:
            split_at = len(current) - 1
            for idx in range(1, len(current) + 1):
                if _matlib_measure_ui_text_px(current[:idx]) > max_px:
                    split_at = max(1, idx - 1)
                    break
            lines.append(current[:split_at].rstrip())
            current = current[split_at:].lstrip()

    if current:
        lines.append(current.rstrip())
    return [line for line in lines if line] or [raw]


def _matlib_set_compact_layout(layout):
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    return layout




def _matlib_help_button(layout, topic='material_library'):
    previous_context = getattr(layout, 'operator_context', None)
    try:
        layout.operator_context = 'INVOKE_DEFAULT'
    except Exception:
        previous_context = None
    try:
        op = layout.operator('sss.open_help', text='', icon='QUESTION', emboss=True)
        op.topic = str(topic or 'material_library')
    except Exception:
        try:
            layout.label(text='', icon='QUESTION')
        except Exception:
            pass
    finally:
        if previous_context is not None:
            try:
                layout.operator_context = previous_context
            except Exception:
                pass


def _matlib_header(layout, context, title, icon='NONE', topic='material_library'):
    row = _matlib_set_compact_layout(layout.row(align=True))
    try:
        split = row.split(factor=0.84, align=True)
        left = split.row(align=True)
        left.label(text=title, icon=icon if icon else 'NONE')
        right = split.row(align=True)
        right.alignment = 'RIGHT'
        _matlib_help_button(right, topic)
    except Exception:
        try:
            row.label(text=title, icon=icon if icon else 'NONE')
            _matlib_help_button(row, topic)
        except Exception:
            pass


def _matlib_group(layout, context, title, icon='NONE', topic='material_library', key=''):
    key = str(key or title or topic or 'material_library').strip()
    key = 'matlib_' + re.sub(r'[^a-z0-9_]+', '_', key.lower()).strip('_')
    _box, body, _expanded = ui_sections.draw_group(
        layout,
        context,
        key,
        str(title or ''),
        icon=icon if icon else 'NONE',
        topic=topic,
        default_open=False,
    )
    return _matlib_set_compact_layout(body)


def _draw_matlib_wrapped_label(layout, context, text, icon='NONE'):
    lines = _matlib_wrap_ui_text(context, text)
    for index, line in enumerate(lines):
        if index == 0 and icon and icon != 'NONE':
            layout.label(text=line, icon=icon, translate=False)
        else:
            layout.label(text=line, translate=False)


def _draw_matlib_toggle_control(layout, context, matlib, prop_name, label_text, icon='CHECKBOX_HLT'):
    # Draw the setting without layout.prop(). Blender's default BoolProperty row can
    # reserve a right-side control column and push translated text outside narrow
    # N-panels.  A label plus a full-width operator button keeps all pixels inside
    # the panel and still toggles the original stored property.
    item = _matlib_set_compact_layout(layout.box())
    label_col = _matlib_set_compact_layout(item.column(align=True))
    _draw_matlib_wrapped_label(label_col, context, label_text, icon=icon)
    enabled = False
    try:
        enabled = bool(getattr(matlib, prop_name))
    except Exception:
        enabled = False
    button_text = _lt('Enabled') if enabled else _lt('Disabled')
    button = _matlib_set_compact_layout(item.column(align=True))
    try:
        button.prop(matlib, prop_name, text=button_text, icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT', toggle=True)
    except Exception:
        button.label(text=button_text, icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT')


def _draw_matlib_settings_section(layout, context, matlib):
    settings_col = _matlib_group(layout, context, _lt('Settings'), 'MODIFIER', 'material_library', 'settings_detail')
    _draw_matlib_toggle_control(settings_col, context, matlib, 'force_import', _lt('Force Import'), icon='IMPORT')
    _draw_matlib_toggle_control(settings_col, context, matlib, 'link', _lt('Linked'), icon='LINKED')
    _draw_matlib_toggle_control(settings_col, context, matlib, 'hide_search', _lt('Hide Search'), icon='HIDE_ON')



class MATLIB_OT_toggle_setting(Operator):
    bl_idname = 'matlib.toggle_setting'
    bl_label = _lt('Toggle Setting', '設定切替')
    bl_description = _lt('JP: マテリアルライブラリの真偽値設定をNパネル幅に収まるボタンUIから切り替えます。標準の分割プロパティ行を使わないため、長いラベルや翻訳でも右にはみ出しません。\nEN: Toggle a Material Library boolean setting through a compact button UI. This avoids Blender\'s split property row so long labels and translations do not overflow the N-panel.')
    bl_options = {'INTERNAL'}

    prop_name: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context):
        matlib = getattr(getattr(context, 'scene', None), 'matlib', None)
        prop_name = str(getattr(self, 'prop_name', '') or '').strip()
        if matlib is None or prop_name not in {'force_import', 'link', 'hide_search', 'filter', 'show_prefs'}:
            return {'CANCELLED'}
        try:
            setattr(matlib, prop_name, not bool(getattr(matlib, prop_name)))
        except Exception:
            return {'CANCELLED'}
        return {'FINISHED'}

class MATLIB_OT_select_material(Operator):
    bl_idname = 'matlib.select_material'
    bl_label = _lt('Select Material', 'マテリアル選択')
    bl_description = _lt('JP: マテリアルライブラリの一覧からマテリアルを選択します。Nパネル幅に収まる縦積みボタンとして表示します。\nEN: Select a material from the Material Library list using a vertical button layout that stays inside the N-panel width.')
    bl_options = {'INTERNAL'}

    index: IntProperty(default=-1, options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context):
        matlib = getattr(getattr(context, 'scene', None), 'matlib', None)
        index = int(getattr(self, 'index', -1))
        if matlib is None or index < 0 or index >= len(getattr(matlib, 'materials', ()) or ()): 
            return {'CANCELLED'}
        try:
            matlib.mat_index = index
        except Exception:
            return {'CANCELLED'}
        return {'FINISHED'}


class MATLIB_OT_remove_material(Operator):
    """Remove Item material from library"""
    bl_idname = 'matlib.remove_material'
    bl_label = _lt('Remove Material', 'マテリアル削除')
    bl_options = set()

    @classmethod
    def poll(cls, context):
        matlib = context.scene.matlib
        return check_index(matlib.materials, matlib.mat_index)

    def execute(self, context):
        matlib = context.scene.matlib
        success = matlib.remove_material()
        if type(success).__name__ == 'tuple':
            None
            self.report({success[0]}, _lt(success[1]))
        return {'FINISHED'}

class MATLIB_OT_reload_library(Operator):
    """Reload library"""
    bl_idname = 'matlib.reload_library'
    bl_label = _lt('Reload Library', 'ライブラリ再読み込み')
    bl_options = set()

    def execute(self, context):
        matlib = context.scene.matlib
        success = matlib.reload_library()
        if type(success).__name__ == 'tuple':
            None
            self.report({success[0]}, _lt(success[1]))
        return {'FINISHED'}

class MATLIB_OT_apply_material(Operator):
    """Apply selected material"""
    bl_idname = 'matlib.apply_material'
    bl_label = _lt('Apply Material', 'マテリアル適用')
    bl_options = {'UNDO'}
    bl_property = 'sss_target_slot_token'

    sss_target_slot_token: EnumProperty(**slot_selection.MATERIAL_TARGET_SLOT_PROPERTY_KWARGS)

    @classmethod
    def poll(cls, context):
        matlib = context.scene.matlib
        index = matlib.mat_index
        l = len(matlib.materials)
        # Preview makes the hidden dummy active: active_object is then None, while
        # object still names it and apply() returns to the last selected object.
        obj = context.object
        return l > 0 and index >= 0 and (index < l) and (obj is not None)

    def invoke(self, context, _event):
        result = slot_selection.invoke_operator_material_target_slot_search(self, context, assign_selected=True)
        if result:
            return result
        return self.execute(context)

    def execute(self, context):
        slot_selection.apply_operator_material_target_slot(self, context)
        matlib = context.scene.matlib
        success = matlib.apply_material(context, False)
        if type(success).__name__ == 'tuple':
            None
            self.report({success[0]}, _lt(success[1]))
        return {'FINISHED'}

class MATLIB_OT_preview_selected_material(Operator):
    """Preview selected material"""
    bl_idname = 'matlib.preview_selected_material'
    bl_label = _lt('Preview Selected Material', '選択マテリアルプレビュー')
    bl_options = set()
    bl_property = 'sss_target_slot_token'

    sss_target_slot_token: EnumProperty(**slot_selection.MATERIAL_TARGET_SLOT_PROPERTY_KWARGS)

    @classmethod
    def poll(cls, context):
        matlib = context.scene.matlib
        index = matlib.mat_index
        l = len(matlib.materials)
        obj = context.active_object
        return l > 0 and index >= 0 and (index < l)

    def invoke(self, context, _event):
        result = slot_selection.invoke_operator_material_target_slot_search(self, context, assign_selected=True)
        if result:
            return result
        return self.execute(context)

    def execute(self, context):
        slot_selection.apply_operator_material_target_slot(self, context)
        matlib = context.scene.matlib
        success = matlib.apply_material(context, True)
        if type(success).__name__ == 'tuple':
            None
            self.report({success[0]}, _lt(success[1]))
        return {'FINISHED'}

class MATLIB_OT_flush_unused_materials(Operator):
    """Flush unused materials"""
    bl_idname = 'matlib.flush_unused_materials'
    bl_label = _lt('Flush Unused Materials', '未使用マテリアル解放')
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        matlib = context.scene.matlib
        index = matlib.mat_index
        l = len(matlib.materials)
        obj = context.active_object
        return l > 0 and index >= 0 and (index < l)

    def execute(self, context):
        matlib = context.scene.matlib
        dummy = matlib.get_dummy(context)
        if dummy == context.object:
            try:
                context.view_layer.objects.active = context.scene.objects[matlib.last_selected]
            except:
                pass
        for slot in dummy.material_slots:
            slot.material = None
        i = 0
        for mat in bpy.data.materials:
            if mat.users == 0:
                i += 1
                None
                bpy.data.materials.remove(mat)
        plural = '' if i == 1 else 's'
        self.report({'INFO'}, _lt(f"JP: {i} 個のマテリアル削除しました。\nEN: {i} material(s) removed."))
        return {'FINISHED'}

class MATLIB_OT_create_item(Operator):
    """Add, Remove Item, Reload, Apply, Preview, Clean Material"""
    bl_label = _lt('Create Item', '項目作成')
    bl_options = set()
    bl_idname = 'matlib.create_item'
    __doc__ = 'Add, Remove Item, Reload, Apply, Preview, Clean Material'
    category: StringProperty(name=_lt('Category'))
    filepath: StringProperty(options={'HIDDEN'})
    cmd: bpy.props.StringProperty(name=_lt('Command'), options={'HIDDEN'})
    filter_glob: StringProperty(default='*.blend', options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return context.object is not None

    def draw(self, context):
        layout = self.layout
        if self.cmd == 'LIBRARY_ADD':
            layout.prop(self, 'category', text=_lt('Library'))
        elif self.cmd == 'FILTER_ADD':
            layout.prop(self, 'category')

    def invoke(self, context, event):
        cmd = self.cmd
        None
        if cmd == 'LIBRARY_ADD':
            self.filepath = matlib_path + os.path.sep
            dd('filepath', self.filepath, matlib_path)
            context.window_manager.invoke_props_dialog(self)
            return {'RUNNING_MODAL'}
        elif cmd == 'FILTER_ADD':
            context.window_manager.invoke_props_dialog(self)
            return {'RUNNING_MODAL'}
        return self.execute(context)

    def execute(self, context):
        success = ''
        matlib = context.scene.matlib
        if self.cmd == 'init':
            None
            return {'FINISHED'}
        if self.cmd[0:3] == 'lib':
            index = int(self.cmd[3:])
            matlib.lib_index = index
        elif self.cmd == 'LIBRARY_ADD':
            dd('execute lib add')
            libname = self.category.strip()
            if libname[-6:] == '.blend':
                libname = libname[:-6].strip()
            if not libname:
                self.report({'WARNING'}, _lt('Enter a library name.', 'ライブラリ名を入力してください。'))
                return {'CANCELLED'}
            libname += '.blend'
            libname = os.path.join(matlib_path, libname)
            None
            success = matlib.add_library(libname, True)
            for i, l in enumerate(libraries):
                if l.name == os.path.basename(libname):
                    matlib.lib_index = i
                    break
        elif self.cmd == 'RELOAD':
            success = matlib.reload_library()
        if not matlib.current_library:
            self.report({'ERROR'}, _lt('Select a Library'))
            return {'CANCELLED'}
        if self.cmd == 'FILTER_ADD':
            success = matlib.add_category(self.category)
            for i, cat in enumerate(matlib.categories):
                if cat.name == self.category:
                    matlib.cat_index = i
                    break
        elif self.cmd == 'FILTER_REMOVE':
            matlib.remove_category()
        elif self.cmd == 'FILTER_SET':
            success = matlib.set_category()
        elif self.cmd[0:3] == 'cat':
            index = int(self.cmd[3:])
            matlib.cat_index = index
        elif self.cmd == 'ADD':
            success = matlib.add_material(_scene_material_for_library_export(context, matlib))
        elif self.cmd == 'REMOVE':
            success = matlib.remove_material()
        elif self.cmd == 'APPLY':
            success = matlib.apply_material(context)
        elif self.cmd == 'PREVIEW':
            success = matlib.apply_material(context, True)
        elif self.cmd == 'FLUSH':
            dummy = matlib.get_dummy(context)
            if dummy == context.object:
                try:
                    context.view_layer.objects.active = context.scene.objects[matlib.last_selected]
                except:
                    pass
            for slot in dummy.material_slots:
                slot.material = None
            i = 0
            for mat in bpy.data.materials:
                if mat.users == 0:
                    i += 1
                    None
                    bpy.data.materials.remove(mat)
            plural = 's'
            if i == 1:
                plural = ''
            self.report({'INFO'}, _lt(f"JP: {i} 個のマテリアル削除しました。\nEN: {i} material(s) removed."))
        elif self.cmd == 'CONVERT':
            return {'FINISHED'}
            lib = matlib.current_library
            if lib:
                path = os.path.join(matlib_path, 'www')
                if not os.path.exists(path):
                    os.mkdir(path)
                path = os.path.join(path, lib.shortname)
                if not os.path.exists(path):
                    os.mkdir(path)
                path = winpath(path)
                libpath = winpath(lib.name)
                None
                None
                cmd = '\npass\nimport bpy, os\ndef list_materials():\n  list = []\n  with bpy.data.libraries.load("{0}") as (data_from, data_to):\n    for mat in data_from.materials:\n      list.append(mat)\n  return sorted(list)\n\ndef get_material(name, link=False):\n  with bpy.data.libraries.load("{0}", link=link, relative=False) as (data_from, data_to):\n    data_to.materials = [name]\n  if link:\n    pass\n  else:\n    pass\n\nfor scn in bpy.data.scenes:\n  for obj in scn.objects:\n    scn.objects.unlink(obj)\n    obj.user_clear()\n    bpy.data.objects.remove(obj)\n\ndef clean_materials():\n  for mat in bpy.data.materials:\n    mat.user_clear()\n    bpy.data.materials.remove(mat)\n\nbin = bpy.app.binary_path\nmats = list_materials()\nbpy.context.preferences.filepaths.save_version = 0\nfor mat in mats:\n  clean_materials()\n  matpath = os.path.join("{1}", mat + ".blend")\n  pass\n  get_material(mat)\n  material = bpy.data.materials[0]\n  material.use_fake_user = True\n  bpy.ops.wm.save_mainfile(filepath = matpath, compress=True, check_existing=False)\n'.format(libpath, path)
                None
                send_command(cmd, 'createlib.py')
        if type(success).__name__ == 'tuple':
            None
            self.report({success[0]}, _lt(success[1]))
        return {'FINISHED'}


def _matlib_material_name(item) -> str:
    try:
        return str(getattr(item, 'name', '') or '').strip()
    except Exception:
        return ''


def _matlib_material_category(item) -> str:
    try:
        return str(getattr(item, 'category', '') or '').strip()
    except Exception:
        return ''


def _matlib_visible_indices(matlib, limit: int = 12) -> list[int]:
    try:
        count = len(matlib.materials)
    except Exception:
        return []
    query = str(getattr(matlib, 'search', '') or '').strip().lower()
    indices: list[int] = []
    for idx in range(count):
        try:
            item = matlib.materials[idx]
        except Exception:
            continue
        name = _matlib_material_name(item)
        category = _matlib_material_category(item)
        haystack = f'{name} {category}'.lower()
        if query and query not in haystack:
            continue
        indices.append(idx)
    active = int(getattr(matlib, 'mat_index', -1) or -1)
    if active >= 0 and active in indices:
        # Keep the active item visible near the top without building a horizontal list.
        indices = [active, *(idx for idx in indices if idx != active)]
    return indices[: max(1, int(limit))]


def _draw_matlib_controls_body(layout, context):
    scene = getattr(context, 'scene', None)
    matlib = getattr(scene, 'matlib', None) if scene is not None else None
    if matlib is None:
        layout.label(text=_lt('JP: マテリアルライブラリ設定はまだ利用できません。\nEN: Material Library settings are not available yet.'), icon='ERROR')
        return

    root = _matlib_set_compact_layout(layout.column(align=True))
    external_source.draw(root, matlib)

    library_col = _matlib_group(root, context, _lt('JP: ライブラリ\nEN: Library'), 'FILE_FOLDER', 'material_library', 'library')
    current_text = matlib.current_library.shortname if matlib.current_library else _lt('Select a Library')
    library_col.menu('MATLIB_MT_MaterialLibraryMenu', text=current_text)
    library_col.operator('matlib.create_item', icon='ADD', text=_lt('Create Library')).cmd = 'LIBRARY_ADD'

    search_col = _matlib_group(root, context, _lt('Search'), 'VIEWZOOM', 'material_library', 'search')
    search_col.prop(matlib, 'search', text='')
    _draw_matlib_toggle_control(search_col, context, matlib, 'hide_search', _lt('Hide Search'), icon='HIDE_ON')

    list_box = _matlib_group(root, context, _lt('JP: マテリアル一覧\nEN: Material List'), 'MATERIAL', 'material_library', 'material_list')
    try:
        total = len(matlib.materials)
    except Exception:
        total = 0
    active = getattr(matlib, 'active_material', None)
    if active is not None:
        _draw_matlib_wrapped_label(list_box, context, _lt('JP: 選択中\nEN: Selected'), icon='CHECKMARK')
        _draw_matlib_wrapped_label(list_box, context, _matlib_material_name(active), icon='NODE_MATERIAL')
        cat = _matlib_material_category(active)
        if cat:
            _draw_matlib_wrapped_label(list_box, context, _lt(f'EN: Category: {cat}\nJP: カテゴリ: {cat}'))
    elif total:
        list_box.label(text=_lt('JP: マテリアルを選択してください。\nEN: Select a material.'))
    else:
        list_box.label(text=_lt('JP: このライブラリにマテリアルがありません。\nEN: This library has no materials.'))

    indices = _matlib_visible_indices(matlib, limit=12)
    if total:
        list_box.label(text=_lt(f'EN: Showing {len(indices)} of {total}\nJP: {total}件中{len(indices)}件を表示'))
    for index in indices:
        try:
            item = matlib.materials[index]
        except Exception:
            continue
        name = _matlib_material_name(item) or str(index)
        label = name
        category = _matlib_material_category(item)
        if category:
            label = f'{name} [{category}]'
        op = list_box.operator('matlib.select_material', text=label, translate=False, icon='RADIOBUT_ON' if index == getattr(matlib, 'mat_index', -1) else 'RADIOBUT_OFF', depress=index == getattr(matlib, 'mat_index', -1))
        op.index = int(index)

    action_col = _matlib_group(root, context, _lt('Command'), 'TOOL_SETTINGS', 'material_library', 'command')
    action_col.operator('matlib.create_item', icon='ADD', text=_lt('Add Active Material')).cmd = 'ADD'
    action_col.operator('matlib.create_item', icon='MATERIAL', text=_lt('Apply Selected Material')).cmd = 'APPLY'
    action_col.operator('matlib.create_item', icon='FILE_REFRESH', text=_lt('Reload Material')).cmd = 'RELOAD'
    action_col.operator('matlib.create_item', icon='COLOR', text=_lt('Preview Material')).cmd = 'PREVIEW'
    action_col.operator('matlib.create_item', icon='GHOST_DISABLED', text=_lt('Remove Preview')).cmd = 'FLUSH'
    action_col.operator('matlib.create_item', icon='REMOVE', text=_lt('Remove Material')).cmd = 'REMOVE'

    category_col = _matlib_group(root, context, _lt('Category'), 'BOOKMARKS', 'material_library', 'category')
    category_text = _lt('Show All Categories')
    if matlib.current_category:
        category_text = matlib.current_category
    category_col.menu('MATLIB_MT_MaterialCategoryMenu', text=category_text)
    _draw_matlib_toggle_control(category_col, context, matlib, 'filter', _lt('Filter'), icon='FILTER')
    category_col.operator('matlib.create_item', icon='FILE_PARENT', text=_lt('Set Category')).cmd = 'FILTER_SET'
    category_col.operator('matlib.create_item', icon='ADD', text=_lt('Create Item')).cmd = 'FILTER_ADD'
    category_col.operator('matlib.create_item', icon='REMOVE', text=_lt('Remove Item')).cmd = 'FILTER_REMOVE'

    settings_toggle = _matlib_group(root, context, _lt('Settings'), 'MODIFIER', 'material_library', 'settings_toggle')
    _draw_matlib_toggle_control(settings_toggle, context, matlib, 'show_prefs', _lt('Settings'), icon='MODIFIER')
    if matlib.show_prefs:
        _draw_matlib_settings_section(root, context, matlib)

def _matlib_is_shader_editor_context(context) -> bool:
    try:
        area = getattr(context, 'area', None)
        if area is None or getattr(area, 'type', None) != 'NODE_EDITOR':
            return False
    except Exception:
        return False
    try:
        space = getattr(context, 'space_data', None)
    except Exception:
        space = None
    if space is None:
        try:
            space = getattr(getattr(area, 'spaces', None), 'active', None)
        except Exception:
            space = None
    for attr in ('tree_type', 'ui_type'):
        try:
            if str(getattr(space, attr, '') or '') == 'ShaderNodeTree':
                return True
        except Exception:
            pass
    try:
        node_tree = getattr(space, 'node_tree', None)
        return str(getattr(node_tree, 'bl_idname', '') or '') == 'ShaderNodeTree'
    except Exception:
        return False


def _matlib_safe_active_material(context):
    try:
        obj = getattr(context, 'active_object', None)
    except Exception:
        return None
    if obj is None:
        return None
    try:
        _ = obj.name
        return getattr(obj, 'active_material', None)
    except Exception:
        return None


def _matlib_context_is_stable(context):
    if context is None or getattr(context, 'scene', None) is None:
        return False
    try:
        mode = str(getattr(context, 'mode', '') or 'OBJECT')
    except Exception:
        mode = 'OBJECT'
    try:
        area_type = getattr(getattr(context, 'area', None), 'type', '')
    except Exception:
        area_type = ''
    try:
        obj = getattr(context, 'active_object', None)
    except Exception:
        obj = None
    if area_type == 'VIEW_3D' and mode not in {'', 'OBJECT'}:
        return False
    if obj is None and mode not in {'', 'OBJECT'}:
        return False
    return True


class MATLIB_PT_material_library_management(Panel):
    bl_idname = 'MATLIB_PT_material_library_management'
    bl_label = _lt('Material Library Management', 'マテリアルライブラリ管理')
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = _lt('Smart Shader')
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        if not _matlib_context_is_stable(context):
            return False
        return _matlib_safe_active_material(context) is not None

    def draw(self, context):
        try:
            _draw_matlib_controls_body(self.layout, context)
        except Exception as exc:
            try:
                self.layout.label(text=_exc_text(exc), icon='ERROR')
            except Exception:
                pass


class MATLIB_PT_material_library_management_shader_editor(Panel):
    bl_idname = 'MATLIB_PT_material_library_management_shader_editor'
    bl_label = _lt('Material Library Management', 'マテリアルライブラリ管理')
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = _lt('Smart Shader')
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        if not _matlib_context_is_stable(context):
            return False
        if not _matlib_is_shader_editor_context(context):
            return False
        return _matlib_safe_active_material(context) is not None

    def draw(self, context):
        try:
            _draw_matlib_controls_body(self.layout, context)
        except Exception as exc:
            try:
                self.layout.label(text=_exc_text(exc), icon='ERROR')
            except Exception:
                pass

@persistent
def refresh_libs(dummy=None):
    from .. import transform_guard as _sss_transform_guard
    with _sss_transform_guard.preserve_object_transforms('material library refresh load_post'):
        global libraries
        global matlib_path
        default_path = _get_matlib_pref_path()
        if default_path:
            matlib_path = default_path
        libraries = get_libraries()

def reload_library(self, context):
    global matlib_path
    value = str(getattr(self, 'matlib_path', '') or '').strip()
    if value:
        try:
            value = bpy.path.abspath(value)
        except Exception:
            pass
        try:
            self.matlib_path = value
        except Exception:
            pass
    _set_matlib_pref_path(value)
    matlib_path = value or _MATLIB_DEFAULT_PATH
    refresh_libs(self)

class MATLIB_OT_refresh_libraries(Operator):
    bl_idname = 'matlib.refresh_libraries'
    bl_label = _lt('Refresh Libraries', 'ライブラリ更新')
    bl_description = _lt('Refresh the material library list now without keeping a background callback active. / 常時コールバックを有効にせず、必要な時だけ今すぐマテリアルライブラリ一覧を更新します。')
    bl_options = {'INTERNAL'}

    def execute(self, context):
        refresh_libs()
        matlib = getattr(getattr(context, 'scene', None), 'matlib', None)
        if matlib is not None:
            try:
                matlib.reload_library()
            except Exception:
                pass
        self.report({'INFO'}, _lt('Material libraries refreshed. / マテリアルライブラリを更新しました。'))
        return {'FINISHED'}

class MATLIB_OT_choose_library_folder(Operator):
    bl_idname = 'matlib.choose_library_folder'
    bl_label = _lt('Choose Library Folder', 'ライブラリフォルダを選択')
    bl_description = _lt('EN: Choose the folder that contains your material-library .blend files for Smart Shader. JP: スマートシェーダーで使うマテリアルライブラリ .blend ファイルの格納フォルダを選択します。')
    bl_options = {'INTERNAL'}
    directory: StringProperty(subtype='DIR_PATH')

    def execute(self, context):
        path = str(self.directory or '').strip()
        if path:
            try:
                path = bpy.path.abspath(path)
            except Exception:
                pass
        _set_matlib_pref_path(path)
        refresh_libs()
        matlib = getattr(getattr(context, 'scene', None), 'matlib', None)
        if matlib is not None:
            try:
                matlib.reload_library()
            except Exception:
                pass
        self.report({'INFO'}, _lt(f"Material library folder set: {path or '(empty)'} / マテリアルライブラリフォルダを設定しました: {path or '(empty)'}"))
        return {'FINISHED'}

    def invoke(self, context, _event):
        self.directory = _get_matlib_pref_path()
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class MATLIB_OT_reset_library_folder(Operator):
    bl_idname = 'matlib.reset_library_folder'
    bl_label = _lt('Reset Library Folder', 'ライブラリフォルダ初期化')
    bl_description = _lt('EN: Reset the material-library folder back to the default user data folder used by Smart Shader. JP: スマートシェーダーで使うマテリアルライブラリフォルダを既定のユーザーデータフォルダーへ戻します。')
    bl_options = {'INTERNAL'}

    def execute(self, context):
        _set_matlib_pref_path(_MATLIB_DEFAULT_PATH)
        refresh_libs()
        matlib = getattr(getattr(context, 'scene', None), 'matlib', None)
        if matlib is not None:
            try:
                matlib.reload_library()
            except Exception:
                pass
        self.report({'INFO'}, _lt('Material library folder reset to default. / マテリアルライブラリフォルダを既定値へ戻しました。'))
        return {'FINISHED'}

SSS_DISABLE_PROXY_PANELS = True

def _draw_matlib_panel_inline(layout, context):
    _draw_matlib_controls_body(layout, context)

def draw_smart_shader_runtime_controls(layout, context):
    prefs = _st_prefs.addon_preferences(context)
    path_box = _matlib_group(layout, context, _lt('Library Folder', 'ライブラリフォルダ'), 'FILE_FOLDER', 'material_library', 'runtime_library_folder')
    current_path = _get_matlib_pref_path() or str(_MATLIB_DEFAULT_PATH)
    path_box.label(text=current_path)
    if prefs is not None and _matlib_rna_has_property(prefs, _st_prefs.prop_name('material_library', 'path')):
        path_box.prop(prefs, _st_prefs.prop_name('material_library', 'path'), text=_lt('Folder', 'フォルダー'))
    path_actions = path_box.column(align=True)
    path_actions.operator('matlib.choose_library_folder', text=_lt('Choose Library Folder', 'ライブラリフォルダを選択'), icon='FILE_FOLDER')
    path_actions.operator('matlib.reset_library_folder', text=_lt('Reset Library Folder', 'ライブラリフォルダ初期化'), icon='LOOP_BACK')

    refresh_box = _matlib_group(layout, context, _lt('Manual Refresh', '手動更新'), 'FILE_REFRESH', 'material_library', 'runtime_manual_refresh')
    refresh_actions = refresh_box.column(align=True)
    refresh_actions.operator('matlib.refresh_libraries', text=_lt('Refresh Libraries', 'ライブラリ更新'), icon='FILE_REFRESH')
    refresh_actions.operator('matlib.create_item', text=_lt('Reload Active Library', '現在ライブラリ再読み込み'), icon='FILE_REFRESH').cmd = 'RELOAD'

    body = _matlib_group(layout, context, _lt('Main Library Tools', 'メインライブラリツール'), 'MATERIAL', 'material_library', 'runtime_main_library_tools')
    try:
        _draw_matlib_panel_inline(body, context)
    except Exception as exc:
        body.alert = True
        body.label(text=_lt('Material Library UI could not be drawn.', 'マテリアルライブラリ UI を描画できませんでした。'), icon='ERROR')
        body.label(text=_exc_text(exc))


classes = [matlibMaterials, EmptyGroup, external_source.MATLIB_OT_open_source_blend, external_source.MATLIB_OT_apply_source_material, MATLIB_OT_add_active_material, MATLIB_OT_toggle_setting, MATLIB_OT_select_material, MATLIB_OT_remove_material, MATLIB_OT_reload_library, MATLIB_OT_apply_material, MATLIB_OT_preview_selected_material, MATLIB_OT_flush_unused_materials, MATLIB_PT_material_library_management, MATLIB_PT_material_library_management_shader_editor, MATLIB_OT_create_item, MATLIB_OT_refresh_libraries, MATLIB_OT_choose_library_folder, MATLIB_OT_reset_library_folder, MATLIB_MT_MaterialLibraryMenu, MATLIB_MT_MaterialCategoryMenu, matlibProperties]

_MATLIB_REGISTERED_CLASSES = []


def _matlib_class_has_own_bl_rna(cls):
    try:
        rna = vars(cls).get('bl_rna') or getattr(cls, 'bl_rna', None)
        identifier = str(getattr(rna, 'identifier', '') or '')
        inherited = {'Operator', 'Panel', 'PropertyGroup', 'Menu', 'UIList', 'AddonPreferences'}
        return bool(identifier and identifier not in inherited)
    except Exception:
        return False

def _matlib_safe_register_class(cls):
    if cls in _MATLIB_REGISTERED_CLASSES and _matlib_class_has_own_bl_rna(cls):
        return
    if _matlib_class_has_own_bl_rna(cls):
        raise RuntimeError(f'RNA class is already registered outside this generation ledger: {getattr(cls, "__name__", "<unnamed>")}')
    bpy.utils.register_class(cls)
    if _matlib_class_has_own_bl_rna(cls) and cls not in _MATLIB_REGISTERED_CLASSES:
        _MATLIB_REGISTERED_CLASSES.append(cls)

def _matlib_safe_unregister_class(cls):
    try:
        if cls in _MATLIB_REGISTERED_CLASSES and _matlib_class_has_own_bl_rna(cls):
            bpy.utils.unregister_class(cls)
    except Exception:
        pass
    try:
        _MATLIB_REGISTERED_CLASSES.remove(cls)
    except ValueError:
        pass

def register():
    global matlib_path
    for c in classes:
        _matlib_safe_register_class(c)
    Scene.matlib_categories = CollectionProperty(type=EmptyGroup)
    Scene.matlib = PointerProperty(type=matlibProperties)
    set_ui_persistence_enabled(storage.npanel_state_save_enabled(default=True))
    try:
        for scene in bpy.data.scenes:
            apply_matlib_ui_settings(getattr(scene, 'matlib', None))
            save_matlib_ui_settings(getattr(scene, 'matlib', None))
    except Exception:
        pass
    _sync_matlib_load_post_handler(getattr(bpy, 'context', None))

def unregister():
    _matlib_unregister_ui_persistence_handler()
    unregister_owned_callbacks()
    global libraries
    try:
        del Scene.matlib_categories
    except:
        pass
    try:
        del Scene.matlib
    except Exception:
        pass
    libraries.clear()
    for c in reversed(classes):
        _matlib_safe_unregister_class(c)
if __name__ == '__main__':
    register()
