"""Material builders and node helpers."""

from __future__ import annotations

import math

import bpy  # type: ignore

from . import core, data


def ensure_material(material):
    material.use_nodes = True
    nt = material.node_tree
    nt.nodes.clear()
    return nt


def create_node(nt, node_types, x, y, name=None):
    if isinstance(node_types, str):
        node_types = [node_types]
    last_error = None
    for node_type in node_types:
        try:
            node = nt.nodes.new(node_type)
            node.location = (x, y)
            if name:
                node.name = name
                node.label = name
            return node
        except Exception as exc:
            last_error = exc
            continue
    raise RuntimeError(f"Unable to create node from {node_types}: {last_error}")


def link(nt, from_socket, to_socket):
    if from_socket is None or to_socket is None:
        return
    nt.links.new(from_socket, to_socket)


def try_input(node, *names):
    socket = core.socket_by_name(node.inputs, *names)
    if socket is None:
        raise KeyError(f"Input not found on {node.name}: {names}")
    return socket


def try_output(node, *names):
    socket = core.socket_by_name(node.outputs, *names)
    if socket is None:
        raise KeyError(f"Output not found on {node.name}: {names}")
    return socket


def new_rgb(nt, x, y, color, label):
    node = create_node(nt, "ShaderNodeRGB", x, y, label)
    try_output(node, "Color").default_value = color
    return node


def new_value(nt, x, y, value, label):
    node = create_node(nt, "ShaderNodeValue", x, y, label)
    try_output(node, "Value").default_value = value
    return node


def new_math(nt, x, y, operation, label):
    node = create_node(nt, "ShaderNodeMath", x, y, label)
    node.operation = operation
    return node


def new_mix_color(nt, x, y, label):
    node = create_node(nt, ["ShaderNodeMix", "ShaderNodeMixRGB"], x, y, label)
    if node.bl_idname == "ShaderNodeMix":
        try:
            node.data_type = "RGBA"
        except Exception:
            pass
    return node


def mix_color_fac_input(node):
    return core.socket_by_name(node.inputs, "Factor", "Fac")


def mix_color_a_input(node):
    return core.socket_by_name(node.inputs, "A", "Color1")


def mix_color_b_input(node):
    return core.socket_by_name(node.inputs, "B", "Color2")


def mix_color_output(node):
    return core.socket_by_name(node.outputs, "Result", "Color")


def new_bw_ramp(nt, x, y, label, pos0=0.35, pos1=0.65):
    ramp = create_node(nt, "ShaderNodeValToRGB", x, y, label)
    ramp.color_ramp.elements[0].position = pos0
    ramp.color_ramp.elements[1].position = pos1
    ramp.color_ramp.elements[0].color = (0.0, 0.0, 0.0, 1.0)
    ramp.color_ramp.elements[1].color = (1.0, 1.0, 1.0, 1.0)
    return ramp


def set_principled_common(bsdf, base_color=None, roughness=None, metallic=None, normal=None):
    if base_color is not None:
        link_or_set(base_color, try_input(bsdf, "Base Color"))
    if roughness is not None:
        link_or_set(roughness, try_input(bsdf, "Roughness"))
    if metallic is not None:
        link_or_set(metallic, try_input(bsdf, "Metallic"))
    if normal is not None:
        link_or_set(normal, try_input(bsdf, "Normal"))


def link_or_set(source, target_socket):
    if source is None or target_socket is None:
        return
    if hasattr(source, "node"):
        target_socket.id_data.links.new(source, target_socket)
    else:
        try:
            target_socket.default_value = source
        except Exception:
            pass


def principled_socket(bsdf, *names):
    return core.socket_by_name(bsdf.inputs, *names)


def set_socket_value(socket, value):
    if socket is None:
        return
    try:
        socket.default_value = value
    except Exception:
        pass


def add_micro_bump(nt, vector_socket, scale_value, strength_value, x=-900, y=-280, label_prefix="Detail"):
    scale = new_value(nt, x - 250, y - 140, scale_value, f"{label_prefix} Scale")
    noise = create_node(nt, "ShaderNodeTexNoise", x, y, f"{label_prefix} Noise")
    bump_strength = new_value(nt, x, y - 210, strength_value, f"{label_prefix} Bump")
    bump = create_node(nt, "ShaderNodeBump", x + 260, y, f"{label_prefix} Bump Node")
    link(nt, vector_socket, try_input(noise, "Vector"))
    link(nt, try_output(scale, "Value"), try_input(noise, "Scale"))
    set_socket_value(principled_socket(noise, "Detail"), 8.0)
    link(nt, try_output(noise, "Fac"), try_input(bump, "Height"))
    link(nt, try_output(bump_strength, "Value"), try_input(bump, "Strength"))
    return try_output(bump, "Normal")


def add_mapping_chain(nt, x=-1260, y=-80, label_prefix="Mapping"):
    texcoord = create_node(nt, "ShaderNodeTexCoord", x, y, f"{label_prefix} TexCoord")
    mapping = create_node(nt, "ShaderNodeMapping", x + 220, y, f"{label_prefix} Mapping")
    link(nt, try_output(texcoord, "Object"), try_input(mapping, "Vector"))
    return texcoord, mapping


def add_rim_mask(nt, x=-700, y=-120, label_prefix="Rim", width=(0.55, 0.88)):
    layer = create_node(nt, "ShaderNodeLayerWeight", x, y, f"{label_prefix} Layer Weight")
    ramp = new_bw_ramp(nt, x + 220, y, f"{label_prefix} Ramp", width[0], width[1])
    link(nt, try_output(layer, "Facing"), try_input(ramp, "Fac"))
    return try_output(ramp, "Color")


def new_output(nt, x, y, label, target="ALL"):
    output = create_node(nt, "ShaderNodeOutputMaterial", x, y, label)
    try:
        output.target = target
    except Exception:
        pass
    return output


def connect_surface(output, shader_socket, nt):
    if output is None or shader_socket is None:
        return
    link(nt, shader_socket, try_input(output, "Surface"))


def connect_volume(output, volume_socket, nt):
    if output is None or volume_socket is None:
        return
    link(nt, volume_socket, try_input(output, "Volume"))


def current_engine():
    try:
        return bpy.context.scene.render.engine
    except Exception:
        return ""


def prefer_cycles_curvature():
    return current_engine() == "CYCLES"


def add_eevee_toon_ramp(nt, x, y, label_prefix="Eevee Toon", shade_pos=(0.45, 0.55), shadow_color=(0.18, 0.18, 0.18, 1.0), light_color=(1.0, 1.0, 1.0, 1.0)):
    shader_to_rgb = create_node(nt, "ShaderNodeShaderToRGB", x, y, f"{label_prefix} Shader To RGB")
    ramp = create_node(nt, "ShaderNodeValToRGB", x + 220, y, f"{label_prefix} Ramp")
    try:
        ramp.color_ramp.interpolation = "CONSTANT"
    except Exception:
        pass
    ramp.color_ramp.elements[0].position = shade_pos[0]
    ramp.color_ramp.elements[1].position = shade_pos[1]
    ramp.color_ramp.elements[0].color = shadow_color
    ramp.color_ramp.elements[1].color = light_color
    link(nt, try_output(shader_to_rgb, "Color"), try_input(ramp, "Fac"))
    return shader_to_rgb, ramp


def add_upward_mask(nt, x=-980, y=420, label_prefix="Upward", noise_vector=None, noise_scale=7.0, noise_strength=0.18, range_pos=(0.55, 0.75)):
    geo = create_node(nt, "ShaderNodeNewGeometry", x, y, f"{label_prefix} Geometry")
    sep = create_node(nt, "ShaderNodeSeparateXYZ", x + 220, y, f"{label_prefix} Separate XYZ")
    link(nt, try_output(geo, "Normal"), try_input(sep, "Vector"))

    if noise_vector is not None:
        noise = create_node(nt, "ShaderNodeTexNoise", x, y - 320, f"{label_prefix} Noise")
        scale = new_value(nt, x - 220, y - 500, noise_scale, f"{label_prefix} Noise Scale")
        mul = new_math(nt, x + 220, y - 160, "MULTIPLY", f"{label_prefix} Noise Strength")
        add = new_math(nt, x + 440, y + 60, "ADD", f"{label_prefix} Combine")
        ramp = new_bw_ramp(nt, x + 660, y + 60, f"{label_prefix} Ramp", range_pos[0], range_pos[1])
        link(nt, noise_vector, try_input(noise, "Vector"))
        link(nt, try_output(scale, "Value"), try_input(noise, "Scale"))
        link(nt, try_output(noise, "Fac"), try_input(mul, 0))
        set_socket_value(try_input(mul, 1), noise_strength)
        link(nt, try_output(sep, "Z"), try_input(add, 0))
        link(nt, try_output(mul, "Value"), try_input(add, 1))
        link(nt, try_output(add, "Value"), try_input(ramp, "Fac"))
        return try_output(ramp, "Color")
    return try_output(sep, "Z")


def add_edge_mask(nt, x=-1100, y=380, label_prefix="Edge", noise_vector=None, noise_scale=20.0, edge_strength=1.0, use_pointiness=None):
    source = None
    if use_pointiness is None:
        use_pointiness = prefer_cycles_curvature()
    if use_pointiness:
        geo = create_node(nt, "ShaderNodeNewGeometry", x, y, f"{label_prefix} Geometry")
        pointiness = core.socket_by_name(geo.outputs, "Pointiness")
        if pointiness is not None:
            source = pointiness
    if source is None:
        layer = create_node(nt, "ShaderNodeLayerWeight", x, y, f"{label_prefix} Layer Weight")
        source = try_output(layer, "Facing")
        invert = new_math(nt, x + 220, y, "SUBTRACT", f"{label_prefix} Invert")
        set_socket_value(try_input(invert, 0), 1.0)
        link(nt, source, try_input(invert, 1))
        source = try_output(invert, "Value")

    if noise_vector is not None:
        noise = create_node(nt, "ShaderNodeTexNoise", x, y - 260, f"{label_prefix} Noise")
        scale = new_value(nt, x - 220, y - 420, noise_scale, f"{label_prefix} Noise Scale")
        mul = new_math(nt, x + 220, y - 120, "MULTIPLY", f"{label_prefix} Noise Strength")
        add = new_math(nt, x + 440, y, "MULTIPLY", f"{label_prefix} Combine")
        ramp = new_bw_ramp(nt, x + 660, y, f"{label_prefix} Ramp", 0.45, 0.68)
        link(nt, noise_vector, try_input(noise, "Vector"))
        link(nt, try_output(scale, "Value"), try_input(noise, "Scale"))
        link(nt, try_output(noise, "Fac"), try_input(mul, 0))
        set_socket_value(try_input(mul, 1), edge_strength)
        link(nt, source, try_input(add, 0))
        link(nt, try_output(mul, "Value"), try_input(add, 1))
        link(nt, try_output(add, "Value"), try_input(ramp, "Fac"))
        return try_output(ramp, "Color")
    return source


def _shader_output_priority(node):
    bl_idname = str(getattr(node, "bl_idname", "") or "")
    name = str(getattr(node, "name", "") or "")
    order = {
        "ShaderNodeBsdfPrincipled": 0,
        "ShaderNodeBsdfDiffuse": 1,
        "ShaderNodeBsdfGlossy": 2,
        "ShaderNodeBsdfGlass": 3,
        "ShaderNodeEmission": 4,
        "ShaderNodeAddShader": 5,
        "ShaderNodeMixShader": 6,
        "ShaderNodeBsdfTransparent": 7,
    }
    return (order.get(bl_idname, 50), name)


def _candidate_shader_outputs(nt):
    candidates = []
    if nt is None:
        return candidates
    for node in getattr(nt, "nodes", []) or []:
        for socket in getattr(node, "outputs", []) or []:
            try:
                if str(getattr(socket, "type", "") or "").upper() != "SHADER":
                    continue
            except Exception:
                continue
            candidates.append((_shader_output_priority(node), node, socket))
    candidates.sort(key=lambda item: item[0])
    return candidates


def ensure_renderable_output_path(material, engine: str = "CYCLES") -> dict:
    """Guarantee that a material has a renderable Surface path to Material Output.

    The builders normally wire this explicitly.  This final safety pass is kept
    deliberately conservative: it does not replace existing valid links, and it
    only creates a fallback output when no active ALL/CYCLES output can receive
    a shader.  The status is stored as custom metadata for audit tests.
    """
    status = {"ok": False, "repaired": 0, "output": "", "from": ""}
    if material is None:
        return status
    try:
        material.use_nodes = True
    except Exception:
        pass
    nt = getattr(material, "node_tree", None)
    if nt is None:
        return status
    try:
        outputs = [node for node in nt.nodes if getattr(node, "type", "") == "OUTPUT_MATERIAL"]
    except Exception:
        outputs = []
    valid_targets = {"", "ALL", "CYCLES"}
    for output in outputs:
        try:
            target = str(getattr(output, "target", "") or "")
            surface = core.socket_by_name(output.inputs, "Surface")
            if target in valid_targets and surface is not None and getattr(surface, "is_linked", False):
                status.update({"ok": True, "output": getattr(output, "name", ""), "from": getattr(surface.links[0].from_node, "name", "")})
                break
        except Exception:
            continue
    if not status["ok"]:
        output = core.ensure_output_node(nt, engine=engine) or core.ensure_output_node(nt, engine="")
        surface = core.socket_by_name(output.inputs, "Surface") if output is not None else None
        if output is not None and surface is not None and not getattr(surface, "is_linked", False):
            candidates = _candidate_shader_outputs(nt)
            shader_socket = candidates[0][2] if candidates else None
            if shader_socket is None:
                try:
                    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
                    bsdf.location = (-180, 0)
                    shader_socket = core.socket_by_name(bsdf.outputs, "BSDF")
                except Exception:
                    shader_socket = None
            if shader_socket is not None:
                try:
                    nt.links.new(shader_socket, surface)
                    status["repaired"] += 1
                except Exception:
                    pass
        if output is not None and surface is not None and getattr(surface, "is_linked", False):
            status.update({"ok": True, "output": getattr(output, "name", ""), "from": getattr(surface.links[0].from_node, "name", "")})
    try:
        material["sss_surface_output_ok"] = bool(status["ok"])
        material["sss_surface_output_repaired"] = int(status["repaired"])
        material["sss_surface_output_node"] = str(status["output"])
        material["sss_surface_output_from"] = str(status["from"])
    except Exception:
        pass
    return status


def finalize_material(material, preset_id, params):
    meta = data.PRESET_LIBRARY[preset_id]
    ensure_renderable_output_path(material, engine="CYCLES")
    core.store_smart_metadata(
        material,
        preset_id,
        params,
        meta["summary_en"],
        meta["summary_ja"],
        tags=meta.get("tags", []),
    )


def ensure_ramp_elements(ramp, count: int):
    elements = ramp.color_ramp.elements
    while len(elements) < count:
        elements.new(1.0)
    while len(elements) > count:
        elements.remove(elements[-1])
    return elements


def configure_constant_color_ramp(ramp, colors, positions):
    try:
        ramp.color_ramp.interpolation = "CONSTANT"
    except Exception:
        pass
    elements = ensure_ramp_elements(ramp, len(colors))
    for element, color, position in zip(elements, colors, positions):
        element.position = max(0.0, min(1.0, float(position)))
        element.color = tuple(float(c) for c in color)
    return ramp


def configure_soft_toon_ramp(ramp, zone_colors, thresholds, smooth):
    smooth = max(0.0, float(smooth or 0.0))
    zone_colors = [tuple(float(c) for c in color) for color in zone_colors]
    thresholds = [max(0.0, min(1.0, float(t))) for t in thresholds]
    if smooth <= 0.0005 or not thresholds:
        positions = [0.0] + sorted(thresholds) + [1.0]
        colors = list(reversed(zone_colors)) + [zone_colors[0]]
        return configure_constant_color_ramp(ramp, colors, positions)

    elements_data = [(0.0, zone_colors[-1])]
    zone_index = len(zone_colors) - 1
    half = smooth * 0.5
    for threshold in sorted(thresholds):
        left = max(0.0, min(1.0, threshold - half))
        right = max(0.0, min(1.0, threshold + half))
        elements_data.append((left, zone_colors[zone_index]))
        zone_index = max(0, zone_index - 1)
        elements_data.append((right, zone_colors[zone_index]))
    elements_data.append((1.0, zone_colors[0]))

    try:
        ramp.color_ramp.interpolation = "LINEAR"
    except Exception:
        pass
    elements = ensure_ramp_elements(ramp, len(elements_data))
    for element, (position, color) in zip(elements, elements_data):
        element.position = max(0.0, min(1.0, float(position)))
        element.color = color
    return ramp


def build_universal_pbr(material, params=None):
    params = params or {
        "base_color": [0.68, 0.68, 0.68, 1.0],
        "roughness": 0.42,
        "metallic": 0.0,
        "detail_scale": 8.0,
        "detail_bump": 0.05,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -880, 220, params["base_color"], "Base Color")
    rough = new_value(nt, -880, 20, params["roughness"], "Roughness")
    metal = new_value(nt, -880, -150, params["metallic"], "Metallic")
    _, mapping = add_mapping_chain(nt, -1280, -40, "Universal")
    normal = add_micro_bump(nt, try_output(mapping, "Vector"), params["detail_scale"], params["detail_bump"], -860, -250, "Universal")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", -180, 60, "Principled BSDF")
    out = create_node(nt, "ShaderNodeOutputMaterial", 220, 60, "Material Output")

    link(nt, try_output(base, "Color"), try_input(bsdf, "Base Color"))
    link(nt, try_output(rough, "Value"), try_input(bsdf, "Roughness"))
    link(nt, try_output(metal, "Value"), try_input(bsdf, "Metallic"))
    link(nt, normal, try_input(bsdf, "Normal"))
    link(nt, try_output(bsdf, "BSDF"), try_input(out, "Surface"))
    finalize_material(material, "UNIVERSAL_PBR", params)


def build_auto_clearcoat(material, params=None):
    params = params or {
        "base_color": [0.72, 0.05, 0.02, 1.0],
        "roughness": 0.16,
        "metallic": 0.08,
        "clearcoat": 1.0,
        "clearcoat_roughness": 0.03,
        "flake_scale": 240.0,
        "flake_bump": 0.015,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -980, 220, params["base_color"], "Paint Color")
    rough = new_value(nt, -980, 20, params["roughness"], "Base Roughness")
    metal = new_value(nt, -980, -150, params["metallic"], "Metallic")
    coat = new_value(nt, -980, -320, params["clearcoat"], "Coat Weight")
    coat_rough = new_value(nt, -980, -480, params["clearcoat_roughness"], "Coat Roughness")
    _, mapping = add_mapping_chain(nt, -1280, -80, "Car Paint")
    flake_scale = new_value(nt, -1280, -380, params["flake_scale"], "Flake Scale")
    voronoi = create_node(nt, "ShaderNodeTexVoronoi", -760, -90, "Flake Pattern")
    noise = create_node(nt, "ShaderNodeTexNoise", -760, -290, "Flake Noise")
    mix = new_mix_color(nt, -500, -180, "Flake Mix")
    bump = create_node(nt, "ShaderNodeBump", -240, -180, "Flake Bump")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", 0, 80, "Principled BSDF")
    out = create_node(nt, "ShaderNodeOutputMaterial", 340, 80, "Material Output")

    link(nt, try_output(mapping, "Vector"), try_input(voronoi, "Vector"))
    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    link(nt, try_output(flake_scale, "Value"), try_input(voronoi, "Scale"))
    set_socket_value(try_input(noise, "Scale"), 38.0)
    link(nt, try_output(voronoi, "Distance"), mix_color_a_input(mix))
    link(nt, try_output(noise, "Fac"), mix_color_b_input(mix))
    set_socket_value(mix_color_fac_input(mix), 0.5)
    link(nt, mix_color_output(mix), try_input(bump, "Height"))
    set_socket_value(try_input(bump, "Strength"), params["flake_bump"])

    link(nt, try_output(base, "Color"), try_input(bsdf, "Base Color"))
    link(nt, try_output(rough, "Value"), try_input(bsdf, "Roughness"))
    link(nt, try_output(metal, "Value"), try_input(bsdf, "Metallic"))
    link(nt, try_output(coat, "Value"), principled_socket(bsdf, "Coat Weight", "Clearcoat"))
    link(nt, try_output(coat_rough, "Value"), principled_socket(bsdf, "Coat Roughness", "Clearcoat Roughness"))
    link(nt, try_output(bump, "Normal"), try_input(bsdf, "Normal"))
    link(nt, try_output(bsdf, "BSDF"), try_input(out, "Surface"))
    finalize_material(material, "AUTO_CLEARCOAT", params)


def build_glass_pro(material, params=None):
    params = params or {
        "base_color": [0.82, 0.96, 0.98, 1.0],
        "roughness": 0.02,
        "ior": 1.45,
        "absorption_color": [0.75, 0.98, 0.96, 1.0],
        "density": 0.2,
    }
    nt = ensure_material(material)
    tint = new_rgb(nt, -860, 220, params["base_color"], "Glass Tint")
    rough = new_value(nt, -860, 40, params["roughness"], "Roughness")
    ior = new_value(nt, -860, -140, params["ior"], "IOR")
    abs_col = new_rgb(nt, -860, -320, params["absorption_color"], "Absorption Color")
    density = new_value(nt, -860, -490, params["density"], "Density")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", -180, 90, "Principled BSDF")
    absorption = create_node(nt, "ShaderNodeVolumeAbsorption", -180, -250, "Volume Absorption")
    out = create_node(nt, "ShaderNodeOutputMaterial", 220, 20, "Material Output")

    link(nt, try_output(tint, "Color"), try_input(bsdf, "Base Color"))
    link(nt, try_output(rough, "Value"), try_input(bsdf, "Roughness"))
    link(nt, try_output(ior, "Value"), principled_socket(bsdf, "IOR"))
    set_socket_value(principled_socket(bsdf, "Transmission Weight", "Transmission"), 1.0)
    link(nt, try_output(abs_col, "Color"), try_input(absorption, "Color"))
    link(nt, try_output(density, "Value"), try_input(absorption, "Density"))
    link(nt, try_output(bsdf, "BSDF"), try_input(out, "Surface"))
    link(nt, try_output(absorption, "Volume"), try_input(out, "Volume"))
    finalize_material(material, "GLASS_PRO", params)


def build_skin_lite(material, params=None):
    params = params or {
        "base_color": [0.73, 0.53, 0.46, 1.0],
        "roughness": 0.45,
        "subsurface": 0.18,
        "detail_scale": 55.0,
        "detail_bump": 0.02,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -920, 220, params["base_color"], "Skin Color")
    rough = new_value(nt, -920, 40, params["roughness"], "Roughness")
    sss = new_value(nt, -920, -130, params["subsurface"], "Subsurface")
    _, mapping = add_mapping_chain(nt, -1280, -60, "Skin Lite")
    noise = create_node(nt, "ShaderNodeTexNoise", -690, -160, "Pore Noise")
    scale = new_value(nt, -1280, -280, params["detail_scale"], "Pore Scale")
    ramp = new_bw_ramp(nt, -470, -160, "Pore Contrast", 0.35, 0.65)
    bump = create_node(nt, "ShaderNodeBump", -230, -160, "Pore Bump")
    bump_strength = new_value(nt, -690, -350, params["detail_bump"], "Pore Strength")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", 10, 70, "Principled BSDF")
    out = create_node(nt, "ShaderNodeOutputMaterial", 340, 70, "Material Output")

    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    link(nt, try_output(scale, "Value"), try_input(noise, "Scale"))
    set_socket_value(principled_socket(noise, "Detail"), 12.0)
    link(nt, try_output(noise, "Fac"), try_input(ramp, "Fac"))
    link(nt, try_output(ramp, "Color"), try_input(bump, "Height"))
    link(nt, try_output(bump_strength, "Value"), try_input(bump, "Strength"))

    link(nt, try_output(base, "Color"), try_input(bsdf, "Base Color"))
    link(nt, try_output(rough, "Value"), try_input(bsdf, "Roughness"))
    link(nt, try_output(sss, "Value"), principled_socket(bsdf, "Subsurface Weight", "Subsurface"))
    link(nt, try_output(bump, "Normal"), try_input(bsdf, "Normal"))
    link(nt, try_output(bsdf, "BSDF"), try_input(out, "Surface"))
    finalize_material(material, "SKIN_LITE", params)


def build_skin_pro(material, params=None):
    params = params or {
        "base_color": [0.73, 0.51, 0.43, 1.0],
        "roughness": 0.38,
        "secondary_gloss": 0.08,
        "subsurface": 0.24,
        "detail_scale": 75.0,
        "detail_bump": 0.03,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -1080, 260, params["base_color"], "Skin Color")
    rough = new_value(nt, -1080, 90, params["roughness"], "Primary Roughness")
    sec = new_value(nt, -1080, -70, params["secondary_gloss"], "Secondary Gloss")
    sss = new_value(nt, -1080, -230, params["subsurface"], "Subsurface")
    _, mapping = add_mapping_chain(nt, -1440, -100, "Skin Pro")
    pore_noise = create_node(nt, "ShaderNodeTexNoise", -860, -210, "Pore Noise")
    pore_scale = new_value(nt, -1440, -320, params["detail_scale"], "Pore Scale")
    pore_ramp = new_bw_ramp(nt, -640, -210, "Pore Contrast", 0.33, 0.67)
    bump = create_node(nt, "ShaderNodeBump", -420, -210, "Pore Bump")
    bump_strength = new_value(nt, -860, -420, params["detail_bump"], "Pore Strength")
    skin = create_node(nt, "ShaderNodeBsdfPrincipled", -140, 120, "Skin BSDF")
    glossy_a = create_node(nt, "ShaderNodeBsdfGlossy", -140, -70, "Primary Gloss")
    glossy_b = create_node(nt, "ShaderNodeBsdfGlossy", -140, -250, "Secondary Gloss")
    add_a = create_node(nt, "ShaderNodeAddShader", 120, 40, "Add Skin + Gloss")
    add_b = create_node(nt, "ShaderNodeAddShader", 340, -40, "Add Dual Gloss")
    out = create_node(nt, "ShaderNodeOutputMaterial", 580, -40, "Material Output")

    link(nt, try_output(mapping, "Vector"), try_input(pore_noise, "Vector"))
    link(nt, try_output(pore_scale, "Value"), try_input(pore_noise, "Scale"))
    set_socket_value(principled_socket(pore_noise, "Detail"), 14.0)
    link(nt, try_output(pore_noise, "Fac"), try_input(pore_ramp, "Fac"))
    link(nt, try_output(pore_ramp, "Color"), try_input(bump, "Height"))
    link(nt, try_output(bump_strength, "Value"), try_input(bump, "Strength"))

    link(nt, try_output(base, "Color"), try_input(skin, "Base Color"))
    link(nt, try_output(rough, "Value"), try_input(skin, "Roughness"))
    link(nt, try_output(sss, "Value"), principled_socket(skin, "Subsurface Weight", "Subsurface"))
    link(nt, try_output(bump, "Normal"), try_input(skin, "Normal"))

    link(nt, try_output(base, "Color"), try_input(glossy_a, "Color"))
    link(nt, try_output(base, "Color"), try_input(glossy_b, "Color"))
    set_socket_value(try_input(glossy_a, "Roughness"), 0.12)
    link(nt, try_output(sec, "Value"), try_input(glossy_b, "Roughness"))
    link(nt, try_output(bump, "Normal"), try_input(glossy_a, "Normal"))
    link(nt, try_output(bump, "Normal"), try_input(glossy_b, "Normal"))

    link(nt, try_output(skin, "BSDF"), try_input(add_a, 0))
    link(nt, try_output(glossy_a, "BSDF"), try_input(add_a, 1))
    link(nt, try_output(add_a, "Shader"), try_input(add_b, 0))
    link(nt, try_output(glossy_b, "BSDF"), try_input(add_b, 1))
    link(nt, try_output(add_b, "Shader"), try_input(out, "Surface"))
    finalize_material(material, "SKIN_PRO", params)


def build_foliage(material, params=None):
    params = params or {
        "base_color": [0.18, 0.42, 0.12, 1.0],
        "roughness": 0.68,
        "subsurface": 0.08,
        "transmission": 0.2,
        "detail_scale": 18.0,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -950, 240, params["base_color"], "Leaf Color")
    rough = new_value(nt, -950, 70, params["roughness"], "Roughness")
    sss = new_value(nt, -950, -90, params["subsurface"], "Subsurface")
    transmission = new_value(nt, -950, -250, params["transmission"], "Transmission")
    _, mapping = add_mapping_chain(nt, -1280, -40, "Foliage")
    normal = add_micro_bump(nt, try_output(mapping, "Vector"), params["detail_scale"], 0.03, -820, -200, "Leaf")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", -80, 70, "Principled BSDF")
    out = create_node(nt, "ShaderNodeOutputMaterial", 250, 70, "Material Output")

    link(nt, try_output(base, "Color"), try_input(bsdf, "Base Color"))
    link(nt, try_output(rough, "Value"), try_input(bsdf, "Roughness"))
    link(nt, try_output(sss, "Value"), principled_socket(bsdf, "Subsurface Weight", "Subsurface"))
    link(nt, try_output(transmission, "Value"), principled_socket(bsdf, "Transmission Weight", "Transmission"))
    link(nt, normal, try_input(bsdf, "Normal"))
    link(nt, try_output(bsdf, "BSDF"), try_input(out, "Surface"))
    finalize_material(material, "FOLIAGE", params)


def build_fabric_wool(material, params=None):
    params = params or {
        "base_color": [0.42, 0.33, 0.28, 1.0],
        "roughness": 0.75,
        "sheen": 0.35,
        "fiber_scale": 55.0,
        "fuzz_strength": 0.04,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -1060, 220, params["base_color"], "Fabric Color")
    rough = new_value(nt, -1060, 60, params["roughness"], "Roughness")
    sheen = new_value(nt, -1060, -100, params["sheen"], "Sheen")
    _, mapping = add_mapping_chain(nt, -1380, -100, "Fabric")
    wave = create_node(nt, "ShaderNodeTexWave", -850, -80, "Fiber Wave")
    noise = create_node(nt, "ShaderNodeTexNoise", -850, -280, "Fiber Noise")
    scale = new_value(nt, -1380, -300, params["fiber_scale"], "Fiber Scale")
    mix = new_mix_color(nt, -620, -170, "Fiber Mix")
    bump = create_node(nt, "ShaderNodeBump", -380, -170, "Fiber Bump")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", -100, 80, "Principled BSDF")
    out = create_node(nt, "ShaderNodeOutputMaterial", 240, 80, "Material Output")

    set_socket_value(try_input(wave, "Scale"), params["fiber_scale"])
    try:
        wave.wave_type = "BANDS"
        wave.bands_direction = "X"
    except Exception:
        pass
    link(nt, try_output(mapping, "Vector"), try_input(wave, "Vector"))
    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    link(nt, try_output(scale, "Value"), try_input(noise, "Scale"))
    link(nt, try_output(wave, "Color"), mix_color_a_input(mix))
    link(nt, try_output(noise, "Color"), mix_color_b_input(mix))
    set_socket_value(mix_color_fac_input(mix), 0.35)
    link(nt, mix_color_output(mix), try_input(bump, "Height"))
    set_socket_value(try_input(bump, "Strength"), params["fuzz_strength"])

    link(nt, try_output(base, "Color"), try_input(bsdf, "Base Color"))
    link(nt, try_output(rough, "Value"), try_input(bsdf, "Roughness"))
    link(nt, try_output(sheen, "Value"), principled_socket(bsdf, "Sheen Weight", "Sheen"))
    set_socket_value(principled_socket(bsdf, "Sheen Tint"), 0.25)
    link(nt, try_output(bump, "Normal"), try_input(bsdf, "Normal"))
    link(nt, try_output(bsdf, "BSDF"), try_input(out, "Surface"))
    finalize_material(material, "FABRIC_WOOL", params)


def build_brushed_metal(material, params=None):
    params = params or {
        "base_color": [0.72, 0.74, 0.76, 1.0],
        "roughness": 0.22,
        "anisotropy": 0.7,
        "brush_scale": 120.0,
        "detail_bump": 0.025,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -1020, 230, params["base_color"], "Metal Color")
    rough = new_value(nt, -1020, 60, params["roughness"], "Roughness")
    anis = new_value(nt, -1020, -100, params["anisotropy"], "Anisotropy")
    _, mapping = add_mapping_chain(nt, -1360, -60, "Metal")
    wave = create_node(nt, "ShaderNodeTexWave", -820, -60, "Brush Pattern")
    noise = create_node(nt, "ShaderNodeTexNoise", -820, -250, "Brush Noise")
    mix = new_mix_color(nt, -570, -150, "Brush Mix")
    bump = create_node(nt, "ShaderNodeBump", -330, -150, "Brush Bump")
    scale = new_value(nt, -1360, -280, params["brush_scale"], "Brush Scale")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", -60, 90, "Principled BSDF")
    out = create_node(nt, "ShaderNodeOutputMaterial", 260, 90, "Material Output")

    try:
        wave.wave_type = "BANDS"
        wave.bands_direction = "X"
    except Exception:
        pass
    link(nt, try_output(mapping, "Vector"), try_input(wave, "Vector"))
    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    link(nt, try_output(scale, "Value"), try_input(wave, "Scale"))
    set_socket_value(try_input(noise, "Scale"), 14.0)
    link(nt, try_output(wave, "Color"), mix_color_a_input(mix))
    link(nt, try_output(noise, "Color"), mix_color_b_input(mix))
    set_socket_value(mix_color_fac_input(mix), 0.22)
    link(nt, mix_color_output(mix), try_input(bump, "Height"))
    set_socket_value(try_input(bump, "Strength"), params["detail_bump"])

    link(nt, try_output(base, "Color"), try_input(bsdf, "Base Color"))
    set_socket_value(try_input(bsdf, "Metallic"), 1.0)
    link(nt, try_output(rough, "Value"), try_input(bsdf, "Roughness"))
    link(nt, try_output(anis, "Value"), principled_socket(bsdf, "Anisotropic", "Specular Anisotropy"))
    link(nt, try_output(bump, "Normal"), try_input(bsdf, "Normal"))
    link(nt, try_output(bsdf, "BSDF"), try_input(out, "Surface"))
    finalize_material(material, "BRUSHED_METAL", params)


def build_ceramic_coat(material, params=None):
    params = params or {
        "base_color": [0.92, 0.92, 0.94, 1.0],
        "roughness": 0.12,
        "coat_weight": 0.65,
        "coat_roughness": 0.04,
        "speckle_scale": 160.0,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -980, 240, params["base_color"], "Ceramic Color")
    rough = new_value(nt, -980, 70, params["roughness"], "Base Roughness")
    coat = new_value(nt, -980, -90, params["coat_weight"], "Coat Weight")
    coat_r = new_value(nt, -980, -250, params["coat_roughness"], "Coat Roughness")
    _, mapping = add_mapping_chain(nt, -1280, -80, "Ceramic")
    noise = create_node(nt, "ShaderNodeTexNoise", -760, -120, "Speckle Noise")
    scale = new_value(nt, -1280, -280, params["speckle_scale"], "Speckle Scale")
    bump = create_node(nt, "ShaderNodeBump", -520, -120, "Speckle Bump")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", -180, 90, "Principled BSDF")
    out = create_node(nt, "ShaderNodeOutputMaterial", 180, 90, "Material Output")

    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    link(nt, try_output(scale, "Value"), try_input(noise, "Scale"))
    set_socket_value(try_input(noise, "Detail"), 2.0)
    link(nt, try_output(noise, "Fac"), try_input(bump, "Height"))
    set_socket_value(try_input(bump, "Strength"), 0.01)

    link(nt, try_output(base, "Color"), try_input(bsdf, "Base Color"))
    link(nt, try_output(rough, "Value"), try_input(bsdf, "Roughness"))
    link(nt, try_output(coat, "Value"), principled_socket(bsdf, "Coat Weight", "Clearcoat"))
    link(nt, try_output(coat_r, "Value"), principled_socket(bsdf, "Coat Roughness", "Clearcoat Roughness"))
    link(nt, try_output(bump, "Normal"), try_input(bsdf, "Normal"))
    link(nt, try_output(bsdf, "BSDF"), try_input(out, "Surface"))
    finalize_material(material, "CERAMIC_COAT", params)


def build_liquid_surface(material, params=None):
    params = params or {
        "base_color": [0.70, 0.94, 0.98, 1.0],
        "roughness": 0.03,
        "ior": 1.333,
        "ripple_scale": 12.0,
        "ripple_strength": 0.08,
        "density": 0.05,
    }
    nt = ensure_material(material)
    color = new_rgb(nt, -1120, 250, params["base_color"], "Liquid Tint")
    rough = new_value(nt, -1120, 80, params["roughness"], "Roughness")
    ior = new_value(nt, -1120, -80, params["ior"], "IOR")
    density = new_value(nt, -1120, -240, params["density"], "Density")
    _, mapping = add_mapping_chain(nt, -1450, -90, "Liquid")
    wave = create_node(nt, "ShaderNodeTexWave", -900, -70, "Ripple Wave")
    noise = create_node(nt, "ShaderNodeTexNoise", -900, -260, "Ripple Noise")
    mix = new_mix_color(nt, -660, -160, "Ripple Mix")
    bump = create_node(nt, "ShaderNodeBump", -420, -160, "Ripple Bump")
    scale = new_value(nt, -1450, -310, params["ripple_scale"], "Ripple Scale")
    absorption = create_node(nt, "ShaderNodeVolumeAbsorption", -160, -250, "Volume Absorption")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", -160, 100, "Principled BSDF")
    out = create_node(nt, "ShaderNodeOutputMaterial", 240, 20, "Material Output")

    try:
        wave.wave_type = "RINGS"
        wave.rings_direction = "Z"
    except Exception:
        pass
    link(nt, try_output(mapping, "Vector"), try_input(wave, "Vector"))
    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    link(nt, try_output(scale, "Value"), try_input(wave, "Scale"))
    set_socket_value(try_input(noise, "Scale"), params["ripple_scale"] * 0.6)
    link(nt, try_output(wave, "Color"), mix_color_a_input(mix))
    link(nt, try_output(noise, "Color"), mix_color_b_input(mix))
    set_socket_value(mix_color_fac_input(mix), 0.35)
    link(nt, mix_color_output(mix), try_input(bump, "Height"))
    set_socket_value(try_input(bump, "Strength"), params["ripple_strength"])

    link(nt, try_output(color, "Color"), try_input(bsdf, "Base Color"))
    link(nt, try_output(rough, "Value"), try_input(bsdf, "Roughness"))
    link(nt, try_output(ior, "Value"), principled_socket(bsdf, "IOR"))
    set_socket_value(principled_socket(bsdf, "Transmission Weight", "Transmission"), 1.0)
    link(nt, try_output(bump, "Normal"), try_input(bsdf, "Normal"))
    link(nt, try_output(color, "Color"), try_input(absorption, "Color"))
    link(nt, try_output(density, "Value"), try_input(absorption, "Density"))
    link(nt, try_output(bsdf, "BSDF"), try_input(out, "Surface"))
    link(nt, try_output(absorption, "Volume"), try_input(out, "Volume"))
    finalize_material(material, "LIQUID_SURFACE", params)


def build_anime_toon(material, params=None):
    params = params or {
        "base_color": [0.86, 0.32, 0.29, 1.0],
        "shadow_color": [0.28, 0.10, 0.10, 1.0],
        "rim_color": [1.0, 1.0, 1.0, 1.0],
        "size": 0.52,
        "smooth": 0.04,
        "rim_strength": 1.1,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -1240, 220, params["base_color"], "Base Color")
    shadow = new_rgb(nt, -1240, 60, params["shadow_color"], "Shadow Color")
    rim = new_rgb(nt, -1240, -100, params["rim_color"], "Rim Color")
    rim_strength = new_value(nt, -1240, -260, params["rim_strength"], "Rim Strength")
    rim_mask = add_rim_mask(nt, -900, -120, "Rim", (0.55, 0.88))
    rim_mul = new_math(nt, -640, -200, "MULTIPLY", "Rim Multiply")
    cycles_toon = create_node(nt, "ShaderNodeBsdfToon", -300, 180, "Cycles Toon BSDF")
    cycles_rim = create_node(nt, "ShaderNodeEmission", -60, -100, "Cycles Rim Emission")
    cycles_add = create_node(nt, "ShaderNodeAddShader", 160, 70, "Cycles Add Shader")
    out_cycles = new_output(nt, 440, 70, "Cycles Output", target="CYCLES")

    diffuse = create_node(nt, "ShaderNodeBsdfDiffuse", -600, 420, "Eevee Diffuse")
    shader_to_rgb, toon_ramp = add_eevee_toon_ramp(
        nt,
        -360,
        420,
        label_prefix="Anime Eevee",
        shade_pos=(max(0.02, params["size"] - params["smooth"]), min(0.98, params["size"] + params["smooth"])),
        shadow_color=tuple(params["shadow_color"]),
        light_color=tuple(params["base_color"]),
    )
    eevee_emit = create_node(nt, "ShaderNodeEmission", -20, 360, "Eevee Toon Emission")
    eevee_rim = create_node(nt, "ShaderNodeEmission", -20, 170, "Eevee Rim Emission")
    eevee_add = create_node(nt, "ShaderNodeAddShader", 210, 280, "Eevee Add Shader")
    out_eevee = new_output(nt, 500, 280, "Eevee Output", target="EEVEE")

    set_socket_value(try_input(cycles_toon, "Size"), params["size"])
    set_socket_value(try_input(cycles_toon, "Smooth"), params["smooth"])
    link(nt, try_output(base, "Color"), try_input(cycles_toon, "Color"))
    link(nt, rim_mask, try_input(rim_mul, 0))
    link(nt, try_output(rim_strength, "Value"), try_input(rim_mul, 1))
    link(nt, try_output(rim, "Color"), try_input(cycles_rim, "Color"))
    link(nt, try_output(rim_mul, "Value"), try_input(cycles_rim, "Strength"))
    link(nt, try_output(cycles_toon, "BSDF"), try_input(cycles_add, 0))
    link(nt, try_output(cycles_rim, "Emission"), try_input(cycles_add, 1))
    connect_surface(out_cycles, try_output(cycles_add, "Shader"), nt)

    link(nt, try_output(base, "Color"), try_input(diffuse, "Color"))
    link(nt, try_output(diffuse, "BSDF"), try_input(shader_to_rgb, "Shader"))
    link(nt, try_output(toon_ramp, "Color"), try_input(eevee_emit, "Color"))
    set_socket_value(try_input(eevee_emit, "Strength"), 1.0)
    link(nt, try_output(rim, "Color"), try_input(eevee_rim, "Color"))
    link(nt, try_output(rim_mul, "Value"), try_input(eevee_rim, "Strength"))
    link(nt, try_output(eevee_emit, "Emission"), try_input(eevee_add, 0))
    link(nt, try_output(eevee_rim, "Emission"), try_input(eevee_add, 1))
    connect_surface(out_eevee, try_output(eevee_add, "Shader"), nt)
    finalize_material(material, "ANIME_TOON", params)


def build_clay_doh(material, params=None):
    params = params or {
        "base_color": [0.72, 0.70, 0.68, 1.0],
        "roughness": 0.86,
        "subsurface": 0.03,
        "fingerprint_bump": 0.01,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -900, 220, params["base_color"], "Clay Color")
    rough = new_value(nt, -900, 60, params["roughness"], "Roughness")
    sss = new_value(nt, -900, -100, params["subsurface"], "Subsurface")
    _, mapping = add_mapping_chain(nt, -1260, -80, "Clay")
    wave = create_node(nt, "ShaderNodeTexWave", -700, -120, "Finger Print")
    noise = create_node(nt, "ShaderNodeTexNoise", -700, -310, "Clay Noise")
    mix = new_mix_color(nt, -470, -200, "Surface Breakup")
    bump = create_node(nt, "ShaderNodeBump", -230, -200, "Clay Bump")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", 0, 80, "Principled BSDF")
    out = create_node(nt, "ShaderNodeOutputMaterial", 320, 80, "Material Output")

    try:
        wave.wave_type = "BANDS"
        wave.bands_direction = "Y"
    except Exception:
        pass
    set_socket_value(try_input(wave, "Scale"), 18.0)
    link(nt, try_output(mapping, "Vector"), try_input(wave, "Vector"))
    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    set_socket_value(try_input(noise, "Scale"), 5.0)
    link(nt, try_output(wave, "Color"), mix_color_a_input(mix))
    link(nt, try_output(noise, "Color"), mix_color_b_input(mix))
    set_socket_value(mix_color_fac_input(mix), 0.25)
    link(nt, mix_color_output(mix), try_input(bump, "Height"))
    set_socket_value(try_input(bump, "Strength"), params["fingerprint_bump"])

    link(nt, try_output(base, "Color"), try_input(bsdf, "Base Color"))
    link(nt, try_output(rough, "Value"), try_input(bsdf, "Roughness"))
    link(nt, try_output(sss, "Value"), principled_socket(bsdf, "Subsurface Weight", "Subsurface"))
    link(nt, try_output(bump, "Normal"), try_input(bsdf, "Normal"))
    set_socket_value(try_input(bsdf, "Metallic"), 0.0)
    link(nt, try_output(bsdf, "BSDF"), try_input(out, "Surface"))
    finalize_material(material, "CLAY_DOH", params)


def build_rim_glow(material, params=None):
    params = params or {
        "base_color": [0.10, 0.12, 0.14, 1.0],
        "rim_color": [0.35, 0.75, 1.0, 1.0],
        "roughness": 0.30,
        "rim_width": 0.90,
        "rim_strength": 2.5,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -980, 200, params["base_color"], "Base Color")
    rough = new_value(nt, -980, 40, params["roughness"], "Roughness")
    rim = new_rgb(nt, -980, -120, params["rim_color"], "Rim Color")
    rim_strength = new_value(nt, -980, -280, params["rim_strength"], "Rim Strength")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", -260, 90, "Principled BSDF")
    rim_mask = add_rim_mask(nt, -620, -40, "Rim", (0.55, params["rim_width"]))
    mul = new_math(nt, -50, -160, "MULTIPLY", "Rim Multiply")
    emission = create_node(nt, "ShaderNodeEmission", 180, -160, "Emission")
    add = create_node(nt, "ShaderNodeAddShader", 400, 20, "Add Shader")
    out = create_node(nt, "ShaderNodeOutputMaterial", 680, 20, "Material Output")

    link(nt, try_output(base, "Color"), try_input(bsdf, "Base Color"))
    link(nt, try_output(rough, "Value"), try_input(bsdf, "Roughness"))
    link(nt, rim_mask, try_input(mul, 0))
    link(nt, try_output(rim_strength, "Value"), try_input(mul, 1))
    link(nt, try_output(rim, "Color"), try_input(emission, "Color"))
    link(nt, try_output(mul, "Value"), try_input(emission, "Strength"))
    link(nt, try_output(bsdf, "BSDF"), try_input(add, 0))
    link(nt, try_output(emission, "Emission"), try_input(add, 1))
    link(nt, try_output(add, "Shader"), try_input(out, "Surface"))
    finalize_material(material, "RIM_GLOW", params)


def build_hologram_fx(material, params=None):
    params = params or {
        "emission_color": [0.15, 0.95, 1.0, 1.0],
        "stripe_scale": 40.0,
        "rim_strength": 3.0,
        "transparency": 0.55,
        "breakup_strength": 0.65,
    }
    nt = ensure_material(material)
    color = new_rgb(nt, -1300, 190, params["emission_color"], "Emission Color")
    stripe_scale = new_value(nt, -1300, 0, params["stripe_scale"], "Stripe Scale")
    rim_strength = new_value(nt, -1300, -180, params["rim_strength"], "Rim Strength")
    transparency = new_value(nt, -1300, -360, params["transparency"], "Transparency")
    breakup = new_value(nt, -1300, -540, params["breakup_strength"], "Breakup Strength")
    _, mapping = add_mapping_chain(nt, -1580, -60, "Hologram")
    wave = create_node(nt, "ShaderNodeTexWave", -1080, -40, "Stripe Wave")
    noise = create_node(nt, "ShaderNodeTexNoise", -1080, -250, "Noise")
    mix = new_mix_color(nt, -850, -120, "Stripe Mix")
    pattern_mul = new_math(nt, -620, -150, "MULTIPLY", "Breakup Multiply")
    add = new_math(nt, -400, -240, "ADD", "Pattern Add")
    rim_mask = add_rim_mask(nt, -860, -380, "Rim", (0.55, 0.95))
    transparency_inv = new_math(nt, -420, -430, "SUBTRACT", "Transparency Invert")
    transparent = create_node(nt, "ShaderNodeBsdfTransparent", -120, -20, "Transparent")
    emission = create_node(nt, "ShaderNodeEmission", -120, -220, "Emission")
    shader_mix = create_node(nt, "ShaderNodeMixShader", 140, -70, "Mix Shader")
    out = create_node(nt, "ShaderNodeOutputMaterial", 420, -70, "Material Output")

    try:
        wave.wave_type = "BANDS"
        wave.bands_direction = "Z"
    except Exception:
        pass
    set_socket_value(try_input(noise, "Scale"), 8.0)
    link(nt, try_output(mapping, "Vector"), try_input(wave, "Vector"))
    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    link(nt, try_output(stripe_scale, "Value"), try_input(wave, "Scale"))
    link(nt, try_output(wave, "Color"), mix_color_a_input(mix))
    link(nt, try_output(noise, "Color"), mix_color_b_input(mix))
    set_socket_value(mix_color_fac_input(mix), 0.6)
    link(nt, mix_color_output(mix), try_input(pattern_mul, 0))
    link(nt, try_output(breakup, "Value"), try_input(pattern_mul, 1))
    link(nt, try_output(pattern_mul, "Value"), try_input(add, 0))
    link(nt, rim_mask, try_input(add, 1))
    set_socket_value(try_input(transparency_inv, 0), 1.0)
    link(nt, try_output(transparency, "Value"), try_input(transparency_inv, 1))
    link(nt, try_output(color, "Color"), try_input(emission, "Color"))
    link(nt, try_output(add, "Value"), try_input(emission, "Strength"))
    link(nt, try_output(transparency_inv, "Value"), try_input(shader_mix, "Fac"))
    link(nt, try_output(transparent, "BSDF"), try_input(shader_mix, 1))
    link(nt, try_output(emission, "Emission"), try_input(shader_mix, 2))
    link(nt, try_output(shader_mix, "Shader"), try_input(out, "Surface"))
    finalize_material(material, "HOLOGRAM_FX", params)


def build_watercolor_npr(material, params=None):
    params = params or {
        "base_color": [0.58, 0.52, 0.76, 1.0],
        "wash_color": [0.88, 0.91, 0.97, 1.0],
        "softness": 0.35,
        "paper_scale": 12.0,
        "wash_strength": 0.35,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -1260, 240, params["base_color"], "Primary Color")
    wash = new_rgb(nt, -1260, 60, params["wash_color"], "Wash Color")
    softness = new_value(nt, -1260, -120, params["softness"], "Softness")
    wash_strength = new_value(nt, -1260, -300, params["wash_strength"], "Wash Strength")
    _, mapping = add_mapping_chain(nt, -1560, -80, "Watercolor")
    noise = create_node(nt, "ShaderNodeTexNoise", -1020, -60, "Paper Noise")
    scale = new_value(nt, -1560, -280, params["paper_scale"], "Paper Scale")
    ramp = new_bw_ramp(nt, -800, -60, "Wash Ramp", 0.35, 0.68)
    mix_color = new_mix_color(nt, -560, 110, "Color Mix")

    cycles_toon = create_node(nt, "ShaderNodeBsdfToon", -260, 120, "Cycles Toon BSDF")
    cycles_wash = create_node(nt, "ShaderNodeEmission", -260, -120, "Cycles Soft Wash")
    cycles_add = create_node(nt, "ShaderNodeAddShader", 20, 10, "Cycles Add Shader")
    out_cycles = new_output(nt, 320, 10, "Cycles Output", target="CYCLES")

    diffuse = create_node(nt, "ShaderNodeBsdfDiffuse", -560, 400, "Eevee Diffuse")
    shader_to_rgb, toon_ramp = add_eevee_toon_ramp(
        nt,
        -300,
        400,
        label_prefix="Watercolor Eevee",
        shade_pos=(0.48, min(0.95, 0.48 + max(0.02, params["softness"]))),
        shadow_color=tuple(params["wash_color"]),
        light_color=tuple(params["base_color"]),
    )
    eevee_mix = new_mix_color(nt, -40, 300, "Eevee Wash Mix")
    eevee_emit = create_node(nt, "ShaderNodeEmission", 220, 300, "Eevee Emission")
    out_eevee = new_output(nt, 500, 300, "Eevee Output", target="EEVEE")

    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    link(nt, try_output(scale, "Value"), try_input(noise, "Scale"))
    link(nt, try_output(noise, "Fac"), try_input(ramp, "Fac"))
    link(nt, try_output(base, "Color"), mix_color_a_input(mix_color))
    link(nt, try_output(wash, "Color"), mix_color_b_input(mix_color))
    link(nt, try_output(ramp, "Color"), mix_color_fac_input(mix_color))

    set_socket_value(try_input(cycles_toon, "Size"), 0.72)
    link(nt, try_output(softness, "Value"), try_input(cycles_toon, "Smooth"))
    link(nt, mix_color_output(mix_color), try_input(cycles_toon, "Color"))
    link(nt, try_output(wash, "Color"), try_input(cycles_wash, "Color"))
    link(nt, try_output(wash_strength, "Value"), try_input(cycles_wash, "Strength"))
    link(nt, try_output(cycles_toon, "BSDF"), try_input(cycles_add, 0))
    link(nt, try_output(cycles_wash, "Emission"), try_input(cycles_add, 1))
    connect_surface(out_cycles, try_output(cycles_add, "Shader"), nt)

    link(nt, try_output(base, "Color"), try_input(diffuse, "Color"))
    link(nt, try_output(diffuse, "BSDF"), try_input(shader_to_rgb, "Shader"))
    link(nt, try_output(toon_ramp, "Color"), mix_color_a_input(eevee_mix))
    link(nt, try_output(wash, "Color"), mix_color_b_input(eevee_mix))
    link(nt, try_output(ramp, "Color"), mix_color_fac_input(eevee_mix))
    link(nt, mix_color_output(eevee_mix), try_input(eevee_emit, "Color"))
    set_socket_value(try_input(eevee_emit, "Strength"), 1.0)
    connect_surface(out_eevee, try_output(eevee_emit, "Emission"), nt)
    finalize_material(material, "WATERCOLOR_NPR", params)


def build_halftone_comic(material, params=None):
    params = params or {
        "base_color": [0.94, 0.22, 0.20, 1.0],
        "dot_color": [0.08, 0.08, 0.08, 1.0],
        "dot_scale": 38.0,
        "contrast": 0.6,
        "dot_strength": 0.8,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -1260, 240, params["base_color"], "Base Color")
    dots = new_rgb(nt, -1260, 60, params["dot_color"], "Dot Color")
    dot_scale = new_value(nt, -1260, -120, params["dot_scale"], "Dot Scale")
    contrast = new_value(nt, -1260, -300, params["contrast"], "Contrast")
    strength = new_value(nt, -1260, -480, params["dot_strength"], "Dot Strength")
    _, mapping = add_mapping_chain(nt, -1560, -80, "Halftone")
    voronoi = create_node(nt, "ShaderNodeTexVoronoi", -980, -20, "Dot Pattern")
    ramp = new_bw_ramp(nt, -740, -20, "Dot Ramp", 0.25, 0.42)

    cycles_toon = create_node(nt, "ShaderNodeBsdfToon", -430, 100, "Cycles Toon BSDF")
    cycles_emission = create_node(nt, "ShaderNodeEmission", -430, -120, "Cycles Dot Emission")
    cycles_mix = create_node(nt, "ShaderNodeMixShader", -100, 10, "Cycles Dot Mix")
    transparent = create_node(nt, "ShaderNodeBsdfTransparent", -430, -280, "Transparent")
    cycles_add = create_node(nt, "ShaderNodeAddShader", 120, 10, "Cycles Add Toon + Dots")
    out_cycles = new_output(nt, 400, 10, "Cycles Output", target="CYCLES")

    diffuse = create_node(nt, "ShaderNodeBsdfDiffuse", -720, 370, "Eevee Diffuse")
    shader_to_rgb, toon_ramp = add_eevee_toon_ramp(
        nt,
        -460,
        370,
        label_prefix="Halftone Eevee",
        shade_pos=(0.40, min(0.92, 0.40 + max(0.04, params["contrast"] * 0.25))),
        shadow_color=(0.35, 0.10, 0.10, 1.0),
        light_color=tuple(params["base_color"]),
    )
    eevee_base_emit = create_node(nt, "ShaderNodeEmission", -140, 330, "Eevee Base Emission")
    eevee_dot_emit = create_node(nt, "ShaderNodeEmission", -140, 120, "Eevee Dot Emission")
    eevee_dot_mix = create_node(nt, "ShaderNodeMixShader", 120, 220, "Eevee Dot Mix")
    out_eevee = new_output(nt, 410, 220, "Eevee Output", target="EEVEE")

    set_socket_value(try_input(cycles_toon, "Size"), 0.45)
    set_socket_value(try_input(cycles_toon, "Smooth"), params["contrast"])
    link(nt, try_output(base, "Color"), try_input(cycles_toon, "Color"))

    link(nt, try_output(mapping, "Vector"), try_input(voronoi, "Vector"))
    link(nt, try_output(dot_scale, "Value"), try_input(voronoi, "Scale"))
    link(nt, try_output(voronoi, "Distance"), try_input(ramp, "Fac"))
    link(nt, try_output(dots, "Color"), try_input(cycles_emission, "Color"))
    link(nt, try_output(strength, "Value"), try_input(cycles_emission, "Strength"))
    link(nt, try_output(ramp, "Color"), try_input(cycles_mix, "Fac"))
    link(nt, try_output(transparent, "BSDF"), try_input(cycles_mix, 1))
    link(nt, try_output(cycles_emission, "Emission"), try_input(cycles_mix, 2))
    link(nt, try_output(cycles_toon, "BSDF"), try_input(cycles_add, 0))
    link(nt, try_output(cycles_mix, "Shader"), try_input(cycles_add, 1))
    connect_surface(out_cycles, try_output(cycles_add, "Shader"), nt)

    link(nt, try_output(base, "Color"), try_input(diffuse, "Color"))
    link(nt, try_output(diffuse, "BSDF"), try_input(shader_to_rgb, "Shader"))
    link(nt, try_output(toon_ramp, "Color"), try_input(eevee_base_emit, "Color"))
    set_socket_value(try_input(eevee_base_emit, "Strength"), 1.0)
    link(nt, try_output(dots, "Color"), try_input(eevee_dot_emit, "Color"))
    link(nt, try_output(strength, "Value"), try_input(eevee_dot_emit, "Strength"))
    link(nt, try_output(ramp, "Color"), try_input(eevee_dot_mix, "Fac"))
    link(nt, try_output(transparent, "BSDF"), try_input(eevee_dot_mix, 1))
    link(nt, try_output(eevee_dot_emit, "Emission"), try_input(eevee_dot_mix, 2))
    add = create_node(nt, "ShaderNodeAddShader", 120, 330, "Eevee Add Base + Dots")
    link(nt, try_output(eevee_base_emit, "Emission"), try_input(add, 0))
    link(nt, try_output(eevee_dot_mix, "Shader"), try_input(add, 1))
    connect_surface(out_eevee, try_output(add, "Shader"), nt)
    finalize_material(material, "HALFTONE_COMIC", params)


def build_ink_hatch(material, params=None):
    params = params or {
        "ink_color": [0.07, 0.07, 0.07, 1.0],
        "paper_color": [0.95, 0.95, 0.92, 1.0],
        "hatch_scale": 65.0,
        "hatch_strength": 0.75,
        "shadow_softness": 0.12,
    }
    nt = ensure_material(material)
    ink = new_rgb(nt, -1260, 250, params["ink_color"], "Ink Color")
    paper = new_rgb(nt, -1260, 70, params["paper_color"], "Paper Color")
    hatch_scale = new_value(nt, -1260, -110, params["hatch_scale"], "Hatch Scale")
    hatch_strength = new_value(nt, -1260, -280, params["hatch_strength"], "Hatch Strength")
    softness = new_value(nt, -1260, -450, params["shadow_softness"], "Shadow Softness")
    _, mapping = add_mapping_chain(nt, -1560, -80, "Ink Hatch")
    wave_a = create_node(nt, "ShaderNodeTexWave", -1030, 0, "Wave A")
    wave_b = create_node(nt, "ShaderNodeTexWave", -1030, -220, "Wave B")
    mix = new_mix_color(nt, -790, -110, "Hatch Mix")
    ramp = new_bw_ramp(nt, -560, -290, "Hatch Mask", 0.40, 0.62)
    transparent = create_node(nt, "ShaderNodeBsdfTransparent", -300, -170, "Transparent")

    cycles_toon = create_node(nt, "ShaderNodeBsdfToon", -470, 100, "Cycles Toon BSDF")
    cycles_emission = create_node(nt, "ShaderNodeEmission", -300, -340, "Cycles Ink Emission")
    cycles_mix = create_node(nt, "ShaderNodeMixShader", -40, -210, "Cycles Mix Shader")
    cycles_add = create_node(nt, "ShaderNodeAddShader", 190, -20, "Cycles Add Shader")
    out_cycles = new_output(nt, 470, -20, "Cycles Output", target="CYCLES")

    diffuse = create_node(nt, "ShaderNodeBsdfDiffuse", -760, 390, "Eevee Diffuse")
    shader_to_rgb, toon_ramp = add_eevee_toon_ramp(
        nt,
        -500,
        390,
        label_prefix="Ink Eevee",
        shade_pos=(0.48, min(0.90, 0.48 + max(0.02, params["shadow_softness"] * 1.5))),
        shadow_color=(0.32, 0.32, 0.30, 1.0),
        light_color=tuple(params["paper_color"]),
    )
    eevee_base_emit = create_node(nt, "ShaderNodeEmission", -190, 350, "Eevee Paper Emission")
    eevee_ink_emit = create_node(nt, "ShaderNodeEmission", -40, 120, "Eevee Ink Emission")
    eevee_mix = create_node(nt, "ShaderNodeMixShader", 210, 220, "Eevee Mix Shader")
    out_eevee = new_output(nt, 500, 220, "Eevee Output", target="EEVEE")

    for wave, direction in ((wave_a, "X"), (wave_b, "Y")):
        try:
            wave.wave_type = "BANDS"
            wave.bands_direction = direction
        except Exception:
            pass
        link(nt, try_output(mapping, "Vector"), try_input(wave, "Vector"))
        link(nt, try_output(hatch_scale, "Value"), try_input(wave, "Scale"))

    link(nt, try_output(wave_a, "Color"), mix_color_a_input(mix))
    link(nt, try_output(wave_b, "Color"), mix_color_b_input(mix))
    set_socket_value(mix_color_fac_input(mix), 0.5)
    link(nt, mix_color_output(mix), try_input(ramp, "Fac"))

    set_socket_value(try_input(cycles_toon, "Size"), 0.38)
    link(nt, try_output(softness, "Value"), try_input(cycles_toon, "Smooth"))
    link(nt, try_output(paper, "Color"), try_input(cycles_toon, "Color"))
    link(nt, try_output(ink, "Color"), try_input(cycles_emission, "Color"))
    link(nt, try_output(hatch_strength, "Value"), try_input(cycles_emission, "Strength"))
    link(nt, try_output(ramp, "Color"), try_input(cycles_mix, "Fac"))
    link(nt, try_output(transparent, "BSDF"), try_input(cycles_mix, 1))
    link(nt, try_output(cycles_emission, "Emission"), try_input(cycles_mix, 2))
    link(nt, try_output(cycles_toon, "BSDF"), try_input(cycles_add, 0))
    link(nt, try_output(cycles_mix, "Shader"), try_input(cycles_add, 1))
    connect_surface(out_cycles, try_output(cycles_add, "Shader"), nt)

    link(nt, try_output(paper, "Color"), try_input(diffuse, "Color"))
    link(nt, try_output(diffuse, "BSDF"), try_input(shader_to_rgb, "Shader"))
    link(nt, try_output(toon_ramp, "Color"), try_input(eevee_base_emit, "Color"))
    set_socket_value(try_input(eevee_base_emit, "Strength"), 1.0)
    link(nt, try_output(ink, "Color"), try_input(eevee_ink_emit, "Color"))
    link(nt, try_output(hatch_strength, "Value"), try_input(eevee_ink_emit, "Strength"))
    link(nt, try_output(ramp, "Color"), try_input(eevee_mix, "Fac"))
    link(nt, try_output(transparent, "BSDF"), try_input(eevee_mix, 1))
    link(nt, try_output(eevee_ink_emit, "Emission"), try_input(eevee_mix, 2))
    add = create_node(nt, "ShaderNodeAddShader", 210, 350, "Eevee Add Shader")
    link(nt, try_output(eevee_base_emit, "Emission"), try_input(add, 0))
    link(nt, try_output(eevee_mix, "Shader"), try_input(add, 1))
    connect_surface(out_eevee, try_output(add, "Shader"), nt)
    finalize_material(material, "INK_HATCH", params)


def build_terrain_blend(material, params=None):
    params = params or {
        "grass_color": [0.18, 0.34, 0.11, 1.0],
        "rock_color": [0.28, 0.27, 0.25, 1.0],
        "grass_roughness": 0.72,
        "rock_roughness": 0.88,
        "noise_scale": 7.0,
    }
    nt = ensure_material(material)
    grass_col = new_rgb(nt, -1280, 360, params["grass_color"], "Grass Color")
    rock_col = new_rgb(nt, -1280, 110, params["rock_color"], "Rock Color")
    grass_r = new_value(nt, -1280, -50, params["grass_roughness"], "Grass Roughness")
    rock_r = new_value(nt, -1280, -210, params["rock_roughness"], "Rock Roughness")
    _, mapping = add_mapping_chain(nt, -1280, -430, "Terrain")
    mask = add_upward_mask(nt, -1030, 540, "Terrain Blend", try_output(mapping, "Vector"), params["noise_scale"], 0.25, (0.38, 0.62))
    grass = create_node(nt, "ShaderNodeBsdfPrincipled", -330, 140, "Grass BSDF")
    rock = create_node(nt, "ShaderNodeBsdfPrincipled", -330, -160, "Rock BSDF")
    mix = create_node(nt, "ShaderNodeMixShader", 150, 20, "Mix Shader")
    out = create_node(nt, "ShaderNodeOutputMaterial", 430, 20, "Material Output")

    link(nt, try_output(grass_col, "Color"), try_input(grass, "Base Color"))
    link(nt, try_output(grass_r, "Value"), try_input(grass, "Roughness"))
    link(nt, try_output(rock_col, "Color"), try_input(rock, "Base Color"))
    link(nt, try_output(rock_r, "Value"), try_input(rock, "Roughness"))
    link(nt, mask, try_input(mix, "Fac"))
    link(nt, try_output(rock, "BSDF"), try_input(mix, 1))
    link(nt, try_output(grass, "BSDF"), try_input(mix, 2))
    link(nt, try_output(mix, "Shader"), try_input(out, "Surface"))
    finalize_material(material, "TERRAIN_BLEND", params)


def build_wet_surface(material, params=None):
    params = params or {
        "dry_color": [0.28, 0.28, 0.29, 1.0],
        "wet_color": [0.12, 0.12, 0.13, 1.0],
        "dry_roughness": 0.78,
        "wet_roughness": 0.05,
        "noise_scale": 6.0,
    }
    nt = ensure_material(material)
    dry_col = new_rgb(nt, -1230, 320, params["dry_color"], "Dry Color")
    wet_col = new_rgb(nt, -1230, 100, params["wet_color"], "Wet Color")
    dry_r = new_value(nt, -1230, -70, params["dry_roughness"], "Dry Roughness")
    wet_r = new_value(nt, -1230, -240, params["wet_roughness"], "Wet Roughness")
    _, mapping = add_mapping_chain(nt, -1260, -430, "Wet")
    noise = create_node(nt, "ShaderNodeTexNoise", -980, -430, "Wet Mask")
    scale = new_value(nt, -1260, -600, params["noise_scale"], "Noise Scale")
    ramp = new_bw_ramp(nt, -740, -430, "Wet Ramp", 0.40, 0.75)
    dry = create_node(nt, "ShaderNodeBsdfPrincipled", -310, 150, "Dry BSDF")
    wet = create_node(nt, "ShaderNodeBsdfPrincipled", -310, -140, "Wet BSDF")
    mix = create_node(nt, "ShaderNodeMixShader", 100, 20, "Mix Shader")
    out = create_node(nt, "ShaderNodeOutputMaterial", 380, 20, "Material Output")

    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    link(nt, try_output(scale, "Value"), try_input(noise, "Scale"))
    set_socket_value(try_input(noise, "Detail"), 8.0)
    link(nt, try_output(noise, "Fac"), try_input(ramp, "Fac"))

    link(nt, try_output(dry_col, "Color"), try_input(dry, "Base Color"))
    link(nt, try_output(dry_r, "Value"), try_input(dry, "Roughness"))
    link(nt, try_output(wet_col, "Color"), try_input(wet, "Base Color"))
    link(nt, try_output(wet_r, "Value"), try_input(wet, "Roughness"))
    link(nt, try_output(ramp, "Color"), try_input(mix, "Fac"))
    link(nt, try_output(dry, "BSDF"), try_input(mix, 1))
    link(nt, try_output(wet, "BSDF"), try_input(mix, 2))
    link(nt, try_output(mix, "Shader"), try_input(out, "Surface"))
    finalize_material(material, "WET_SURFACE", params)


def build_snow_mask(material, params=None):
    params = params or {
        "base_color": [0.22, 0.20, 0.18, 1.0],
        "snow_color": [0.94, 0.96, 1.0, 1.0],
        "base_roughness": 0.84,
        "snow_roughness": 0.35,
        "noise_scale": 9.0,
    }
    nt = ensure_material(material)
    base_col = new_rgb(nt, -1280, 320, params["base_color"], "Base Color")
    snow_col = new_rgb(nt, -1280, 100, params["snow_color"], "Snow Color")
    base_r = new_value(nt, -1280, -70, params["base_roughness"], "Base Roughness")
    snow_r = new_value(nt, -1280, -240, params["snow_roughness"], "Snow Roughness")
    _, mapping = add_mapping_chain(nt, -1060, -320, "Snow")
    mask = add_upward_mask(nt, -1040, 440, "Snow Mask", try_output(mapping, "Vector"), params["noise_scale"], 0.18, (0.55, 0.75))
    base = create_node(nt, "ShaderNodeBsdfPrincipled", -320, 300, "Base BSDF")
    snow = create_node(nt, "ShaderNodeBsdfPrincipled", -320, -10, "Snow BSDF")
    mix = create_node(nt, "ShaderNodeMixShader", 160, 120, "Mix Shader")
    out = create_node(nt, "ShaderNodeOutputMaterial", 440, 120, "Material Output")

    link(nt, try_output(base_col, "Color"), try_input(base, "Base Color"))
    link(nt, try_output(base_r, "Value"), try_input(base, "Roughness"))
    link(nt, try_output(snow_col, "Color"), try_input(snow, "Base Color"))
    link(nt, try_output(snow_r, "Value"), try_input(snow, "Roughness"))
    link(nt, mask, try_input(mix, "Fac"))
    link(nt, try_output(base, "BSDF"), try_input(mix, 1))
    link(nt, try_output(snow, "BSDF"), try_input(mix, 2))
    link(nt, try_output(mix, "Shader"), try_input(out, "Surface"))
    finalize_material(material, "SNOW_MASK", params)


def build_moss_growth(material, params=None):
    params = params or {
        "base_color": [0.26, 0.25, 0.22, 1.0],
        "moss_color": [0.19, 0.34, 0.12, 1.0],
        "roughness": 0.78,
        "moss_roughness": 0.92,
        "growth_scale": 8.0,
        "coverage": 0.55,
    }
    nt = ensure_material(material)
    base_col = new_rgb(nt, -1320, 340, params["base_color"], "Base Color")
    moss_col = new_rgb(nt, -1320, 120, params["moss_color"], "Moss Color")
    base_r = new_value(nt, -1320, -40, params["roughness"], "Base Roughness")
    moss_r = new_value(nt, -1320, -210, params["moss_roughness"], "Moss Roughness")
    coverage = new_value(nt, -1320, -380, params["coverage"], "Coverage")
    _, mapping = add_mapping_chain(nt, -1080, -340, "Moss")
    mask = add_upward_mask(nt, -1120, 460, "Moss Upward", try_output(mapping, "Vector"), params["growth_scale"], 0.25, (0.45, 0.76))
    mul = new_math(nt, -130, 220, "MULTIPLY", "Coverage Multiply")
    base = create_node(nt, "ShaderNodeBsdfPrincipled", -420, 270, "Base BSDF")
    moss = create_node(nt, "ShaderNodeBsdfPrincipled", -420, -30, "Moss BSDF")
    mix = create_node(nt, "ShaderNodeMixShader", 160, 120, "Mix Shader")
    out = create_node(nt, "ShaderNodeOutputMaterial", 440, 120, "Material Output")

    link(nt, mask, try_input(mul, 0))
    link(nt, try_output(coverage, "Value"), try_input(mul, 1))
    link(nt, try_output(base_col, "Color"), try_input(base, "Base Color"))
    link(nt, try_output(base_r, "Value"), try_input(base, "Roughness"))
    link(nt, try_output(moss_col, "Color"), try_input(moss, "Base Color"))
    link(nt, try_output(moss_r, "Value"), try_input(moss, "Roughness"))
    set_socket_value(principled_socket(moss, "Subsurface Weight", "Subsurface"), 0.02)
    link(nt, try_output(mul, "Value"), try_input(mix, "Fac"))
    link(nt, try_output(base, "BSDF"), try_input(mix, 1))
    link(nt, try_output(moss, "BSDF"), try_input(mix, 2))
    link(nt, try_output(mix, "Shader"), try_input(out, "Surface"))
    finalize_material(material, "MOSS_GROWTH", params)


def build_rusted_paint(material, params=None):
    params = params or {
        "paint_color": [0.22, 0.34, 0.75, 1.0],
        "rust_color": [0.40, 0.16, 0.05, 1.0],
        "paint_roughness": 0.28,
        "rust_roughness": 0.86,
        "chip_scale": 18.0,
        "rust_amount": 0.75,
    }
    nt = ensure_material(material)
    paint_col = new_rgb(nt, -1370, 360, params["paint_color"], "Paint Color")
    rust_col = new_rgb(nt, -1370, 150, params["rust_color"], "Rust Color")
    paint_r = new_value(nt, -1370, -10, params["paint_roughness"], "Paint Roughness")
    rust_r = new_value(nt, -1370, -180, params["rust_roughness"], "Rust Roughness")
    rust_amount = new_value(nt, -1370, -350, params["rust_amount"], "Rust Amount")
    _, mapping = add_mapping_chain(nt, -1120, -300, "Rust")
    edge_mask = add_edge_mask(nt, -1130, 520, "Rust Edge", try_output(mapping, "Vector"), params["chip_scale"], 1.0)
    amount_mul = new_math(nt, -180, 210, "MULTIPLY", "Rust Amount Multiply")
    paint = create_node(nt, "ShaderNodeBsdfPrincipled", -480, 300, "Paint BSDF")
    rust = create_node(nt, "ShaderNodeBsdfPrincipled", -480, -10, "Rust BSDF")
    mix = create_node(nt, "ShaderNodeMixShader", 160, 120, "Mix Shader")
    out = create_node(nt, "ShaderNodeOutputMaterial", 440, 120, "Material Output")

    link(nt, edge_mask, try_input(amount_mul, 0))
    link(nt, try_output(rust_amount, "Value"), try_input(amount_mul, 1))
    link(nt, try_output(paint_col, "Color"), try_input(paint, "Base Color"))
    link(nt, try_output(paint_r, "Value"), try_input(paint, "Roughness"))
    link(nt, try_output(rust_col, "Color"), try_input(rust, "Base Color"))
    link(nt, try_output(rust_r, "Value"), try_input(rust, "Roughness"))
    set_socket_value(try_input(rust, "Metallic"), 0.0)
    link(nt, try_output(amount_mul, "Value"), try_input(mix, "Fac"))
    link(nt, try_output(paint, "BSDF"), try_input(mix, 1))
    link(nt, try_output(rust, "BSDF"), try_input(mix, 2))
    link(nt, try_output(mix, "Shader"), try_input(out, "Surface"))
    finalize_material(material, "RUSTED_PAINT", params)


def build_edge_wear(material, params=None):
    params = params or {
        "coat_color": [0.13, 0.14, 0.15, 1.0],
        "exposed_color": [0.70, 0.70, 0.72, 1.0],
        "coat_roughness": 0.36,
        "exposed_roughness": 0.18,
        "wear_scale": 28.0,
        "edge_strength": 0.85,
    }
    nt = ensure_material(material)
    coat_col = new_rgb(nt, -1350, 350, params["coat_color"], "Coat Color")
    exposed_col = new_rgb(nt, -1350, 130, params["exposed_color"], "Exposed Color")
    coat_r = new_value(nt, -1350, -30, params["coat_roughness"], "Coat Roughness")
    exposed_r = new_value(nt, -1350, -200, params["exposed_roughness"], "Exposed Roughness")
    edge_strength = new_value(nt, -1350, -380, params["edge_strength"], "Edge Strength")
    _, mapping = add_mapping_chain(nt, -1120, -300, "Wear")
    edge = add_edge_mask(nt, -1120, 510, "Edge Wear", try_output(mapping, "Vector"), params["wear_scale"], 1.0)
    mul = new_math(nt, -160, 210, "MULTIPLY", "Edge Strength Multiply")
    coat = create_node(nt, "ShaderNodeBsdfPrincipled", -480, 300, "Coat BSDF")
    exposed = create_node(nt, "ShaderNodeBsdfPrincipled", -480, -10, "Exposed BSDF")
    mix = create_node(nt, "ShaderNodeMixShader", 160, 120, "Mix Shader")
    out = create_node(nt, "ShaderNodeOutputMaterial", 440, 120, "Material Output")

    link(nt, edge, try_input(mul, 0))
    link(nt, try_output(edge_strength, "Value"), try_input(mul, 1))
    link(nt, try_output(coat_col, "Color"), try_input(coat, "Base Color"))
    link(nt, try_output(coat_r, "Value"), try_input(coat, "Roughness"))
    link(nt, try_output(exposed_col, "Color"), try_input(exposed, "Base Color"))
    link(nt, try_output(exposed_r, "Value"), try_input(exposed, "Roughness"))
    set_socket_value(try_input(exposed, "Metallic"), 1.0)
    link(nt, try_output(mul, "Value"), try_input(mix, "Fac"))
    link(nt, try_output(coat, "BSDF"), try_input(mix, 1))
    link(nt, try_output(exposed, "BSDF"), try_input(mix, 2))
    link(nt, try_output(mix, "Shader"), try_input(out, "Surface"))
    finalize_material(material, "EDGE_WEAR", params)


def add_frame_driver(socket, component_index=2, expression="frame * 0.03"):
    try:
        fcurve = socket.driver_add("default_value", component_index)
        driver = fcurve.driver
        driver.type = "SCRIPTED"
        variable = driver.variables.new()
        variable.name = "frame"
        target = variable.targets[0]
        target.id_type = "SCENE"
        target.id = bpy.context.scene
        target.data_path = "frame_current"
        driver.expression = expression
        return True
    except Exception:
        return False


def build_procedural_ripple(material, params=None):
    params = params or {
        "base_color": [0.08, 0.11, 0.18, 1.0],
        "ripple_color": [0.42, 0.78, 1.0, 1.0],
        "ripple_scale": 18.0,
        "ripple_strength": 0.85,
        "animation_speed": 0.03,
        "transparency": 0.25,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -1400, 260, params["base_color"], "Base Color")
    ripple = new_rgb(nt, -1400, 70, params["ripple_color"], "Ripple Color")
    scale = new_value(nt, -1400, -110, params["ripple_scale"], "Ripple Scale")
    strength = new_value(nt, -1400, -290, params["ripple_strength"], "Ripple Strength")
    transparency = new_value(nt, -1400, -470, params["transparency"], "Transparency")
    _, mapping = add_mapping_chain(nt, -1680, -80, "Ripple")
    wave = create_node(nt, "ShaderNodeTexWave", -1160, -20, "Ripple Wave")
    noise = create_node(nt, "ShaderNodeTexNoise", -1160, -240, "Ripple Noise")
    mix_color = new_mix_color(nt, -920, -120, "Ripple Mix")
    rim_mask = add_rim_mask(nt, -930, -360, "Ripple Rim", (0.65, 0.95))
    add_math = new_math(nt, -690, -200, "ADD", "Ripple Add")
    mul = new_math(nt, -470, -200, "MULTIPLY", "Ripple Multiply")
    emission = create_node(nt, "ShaderNodeEmission", -230, -210, "Ripple Emission")
    transparent = create_node(nt, "ShaderNodeBsdfTransparent", -230, -20, "Transparent")
    mix_shader = create_node(nt, "ShaderNodeMixShader", 10, -60, "Mix Shader")
    out = create_node(nt, "ShaderNodeOutputMaterial", 290, -60, "Material Output")

    try:
        wave.wave_type = "RINGS"
        wave.rings_direction = "Z"
    except Exception:
        pass

    link(nt, try_output(mapping, "Vector"), try_input(wave, "Vector"))
    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    link(nt, try_output(scale, "Value"), try_input(wave, "Scale"))
    set_socket_value(try_input(noise, "Scale"), params["ripple_scale"] * 0.55)
    set_socket_value(try_input(noise, "Detail"), 4.0)
    link(nt, try_output(wave, "Color"), mix_color_a_input(mix_color))
    link(nt, try_output(noise, "Color"), mix_color_b_input(mix_color))
    set_socket_value(mix_color_fac_input(mix_color), 0.25)
    link(nt, mix_color_output(mix_color), try_input(add_math, 0))
    link(nt, rim_mask, try_input(add_math, 1))
    link(nt, try_output(add_math, "Value"), try_input(mul, 0))
    link(nt, try_output(strength, "Value"), try_input(mul, 1))
    link(nt, try_output(ripple, "Color"), try_input(emission, "Color"))
    link(nt, try_output(mul, "Value"), try_input(emission, "Strength"))
    link(nt, try_output(transparency, "Value"), try_input(mix_shader, "Fac"))
    link(nt, try_output(transparent, "BSDF"), try_input(mix_shader, 1))
    link(nt, try_output(emission, "Emission"), try_input(mix_shader, 2))
    link(nt, try_output(mix_shader, "Shader"), try_input(out, "Surface"))
    set_socket_value(try_input(mapping, "Location"), (0.0, 0.0, 0.0))
    add_frame_driver(try_input(mapping, "Location"), 2, f"frame * {float(params['animation_speed'])}")
    finalize_material(material, "PROCEDURAL_RIPPLE", params)


def build_puddle_mixer(material, params=None):
    params = params or {
        "base_color": [0.20, 0.20, 0.22, 1.0],
        "puddle_color": [0.08, 0.09, 0.10, 1.0],
        "base_roughness": 0.82,
        "puddle_roughness": 0.03,
        "puddle_scale": 5.5,
        "puddle_amount": 0.78,
    }
    nt = ensure_material(material)
    base_col = new_rgb(nt, -1320, 340, params["base_color"], "Base Color")
    puddle_col = new_rgb(nt, -1320, 120, params["puddle_color"], "Puddle Color")
    base_r = new_value(nt, -1320, -40, params["base_roughness"], "Base Roughness")
    puddle_r = new_value(nt, -1320, -210, params["puddle_roughness"], "Puddle Roughness")
    puddle_amount = new_value(nt, -1320, -380, params["puddle_amount"], "Puddle Amount")
    _, mapping = add_mapping_chain(nt, -1320, -560, "Puddle")
    noise = create_node(nt, "ShaderNodeTexNoise", -1080, -560, "Puddle Noise")
    scale = new_value(nt, -1320, -730, params["puddle_scale"], "Puddle Scale")
    ramp = new_bw_ramp(nt, -840, -560, "Puddle Ramp", 0.52, 0.74)
    mul = new_math(nt, -620, -400, "MULTIPLY", "Puddle Amount Multiply")
    base = create_node(nt, "ShaderNodeBsdfPrincipled", -360, 250, "Base BSDF")
    puddle = create_node(nt, "ShaderNodeBsdfPrincipled", -360, -40, "Puddle BSDF")
    mix = create_node(nt, "ShaderNodeMixShader", 110, 110, "Mix Shader")
    out = create_node(nt, "ShaderNodeOutputMaterial", 390, 110, "Material Output")

    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    link(nt, try_output(scale, "Value"), try_input(noise, "Scale"))
    set_socket_value(try_input(noise, "Detail"), 10.0)
    link(nt, try_output(noise, "Fac"), try_input(ramp, "Fac"))
    link(nt, try_output(ramp, "Color"), try_input(mul, 0))
    link(nt, try_output(puddle_amount, "Value"), try_input(mul, 1))

    link(nt, try_output(base_col, "Color"), try_input(base, "Base Color"))
    link(nt, try_output(base_r, "Value"), try_input(base, "Roughness"))
    link(nt, try_output(puddle_col, "Color"), try_input(puddle, "Base Color"))
    link(nt, try_output(puddle_r, "Value"), try_input(puddle, "Roughness"))
    set_socket_value(principled_socket(puddle, "Coat Weight", "Clearcoat"), 0.4)
    link(nt, try_output(mul, "Value"), try_input(mix, "Fac"))
    link(nt, try_output(base, "BSDF"), try_input(mix, 1))
    link(nt, try_output(puddle, "BSDF"), try_input(mix, 2))
    link(nt, try_output(mix, "Shader"), try_input(out, "Surface"))
    finalize_material(material, "PUDDLE_MIXER", params)


def coerce_float(value, default: float) -> float:
    try:
        return float(value)
    except Exception:
        return float(default)


def coerce_color4(value, default=(0.8, 0.8, 0.8, 1.0)):
    if value is None:
        return default
    try:
        seq = list(value)
    except Exception:
        return default
    if len(seq) == 3:
        seq.append(1.0)
    if len(seq) < 4:
        return default
    try:
        return tuple(float(seq[i]) for i in range(4))
    except Exception:
        return default


def build_decal_detail(material, params=None):
    params = params or {
        "decal_color": [0.88, 0.86, 0.82, 1.0],
        "trim_color": [0.06, 0.06, 0.06, 1.0],
        "roughness": 0.38,
        "emboss_strength": 0.05,
        "border_softness": 0.28,
        "grime_amount": 0.24,
        "metallic_trim": 0.18,
    }
    nt = ensure_material(material)
    decal = new_rgb(nt, -1340, 240, params["decal_color"], "Decal Color")
    trim = new_rgb(nt, -1340, 50, params["trim_color"], "Trim Color")
    rough = new_value(nt, -1340, -140, params["roughness"], "Roughness")
    emboss = new_value(nt, -1340, -320, params["emboss_strength"], "Emboss Strength")
    grime = new_value(nt, -1340, -500, params["grime_amount"], "Grime Amount")
    _, mapping = add_mapping_chain(nt, -1640, -80, "Decal")
    voronoi = create_node(nt, "ShaderNodeTexVoronoi", -1100, 120, "Edge Voronoi")
    noise = create_node(nt, "ShaderNodeTexNoise", -1100, -150, "Grime Noise")
    border_ramp = new_bw_ramp(nt, -860, 120, "Border Ramp", max(0.02, params["border_softness"] * 0.35), min(0.98, 0.55 + params["border_softness"] * 0.35))
    grime_ramp = new_bw_ramp(nt, -860, -150, "Grime Ramp", 0.45, 0.72)
    grime_mix = new_mix_color(nt, -620, 20, "Decal Mix")
    bump = create_node(nt, "ShaderNodeBump", -380, -150, "Decal Bump")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", -120, 80, "Principled BSDF")
    out = new_output(nt, 220, 80, "Material Output", target="ALL")

    link(nt, try_output(mapping, "Vector"), try_input(voronoi, "Vector"))
    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    set_socket_value(try_input(voronoi, "Scale"), 6.5)
    set_socket_value(try_input(noise, "Scale"), 18.0)
    link(nt, try_output(voronoi, "Distance"), try_input(border_ramp, "Fac"))
    link(nt, try_output(noise, "Fac"), try_input(grime_ramp, "Fac"))
    link(nt, try_output(trim, "Color"), mix_color_a_input(grime_mix))
    link(nt, try_output(decal, "Color"), mix_color_b_input(grime_mix))
    link(nt, try_output(border_ramp, "Color"), mix_color_fac_input(grime_mix))
    link(nt, try_output(grime_ramp, "Color"), try_input(bump, "Height"))
    link(nt, try_output(emboss, "Value"), try_input(bump, "Strength"))
    link(nt, mix_color_output(grime_mix), try_input(bsdf, "Base Color"))
    link(nt, try_output(rough, "Value"), try_input(bsdf, "Roughness"))
    link(nt, try_output(grime, "Value"), try_input(bsdf, "Metallic"))
    link(nt, try_output(bump, "Normal"), try_input(bsdf, "Normal"))
    connect_surface(out, try_output(bsdf, "BSDF"), nt)
    finalize_material(material, "DECAL_DETAIL", params)


def build_portable_principled(material, payload=None):
    payload = payload or {}
    nt = ensure_material(material)
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", -120, 80, "Portable Principled")
    out = create_node(nt, "ShaderNodeOutputMaterial", 240, 80, "Material Output")
    link(nt, try_output(bsdf, "BSDF"), try_input(out, "Surface"))

    set_socket_value(principled_socket(bsdf, "Base Color"), coerce_color4(payload.get("base_color"), (0.8, 0.8, 0.8, 1.0)))
    set_socket_value(principled_socket(bsdf, "Roughness"), coerce_float(payload.get("roughness"), 0.45))
    set_socket_value(principled_socket(bsdf, "Metallic"), coerce_float(payload.get("metalness"), 0.0))
    set_socket_value(principled_socket(bsdf, "IOR"), coerce_float(payload.get("ior"), 1.45))
    set_socket_value(principled_socket(bsdf, "Transmission Weight", "Transmission"), coerce_float(payload.get("transmission"), 0.0))
    set_socket_value(principled_socket(bsdf, "Subsurface Weight", "Subsurface"), coerce_float(payload.get("subsurface_weight"), 0.0))
    set_socket_value(principled_socket(bsdf, "Coat Weight", "Clearcoat"), coerce_float(payload.get("coat_weight"), 0.0))
    set_socket_value(principled_socket(bsdf, "Coat Roughness", "Clearcoat Roughness"), coerce_float(payload.get("coat_roughness"), 0.03))
    set_socket_value(principled_socket(bsdf, "Sheen Weight", "Sheen"), coerce_float(payload.get("sheen_weight"), 0.0))
    set_socket_value(principled_socket(bsdf, "Anisotropic", "Specular Anisotropy"), coerce_float(payload.get("anisotropy"), 0.0))
    set_socket_value(principled_socket(bsdf, "Alpha"), coerce_float(payload.get("alpha"), 1.0))

    emission_color = payload.get("emission_color")
    if emission_color is not None:
        set_socket_value(principled_socket(bsdf, "Emission Color", "Emission"), coerce_color4(emission_color, (0.0, 0.0, 0.0, 1.0)))
        set_socket_value(principled_socket(bsdf, "Emission Strength"), coerce_float(payload.get("emission_strength"), 1.0))

    absorption_color = payload.get("absorption_color")
    absorption_density = coerce_float(payload.get("absorption_density"), 0.0)
    if absorption_color is not None and absorption_density > 0.0:
        volume = create_node(nt, "ShaderNodeVolumeAbsorption", -120, -180, "Portable Absorption")
        set_socket_value(try_input(volume, "Color"), coerce_color4(absorption_color, (1.0, 1.0, 1.0, 1.0)))
        set_socket_value(try_input(volume, "Density"), absorption_density)
        link(nt, try_output(volume, "Volume"), try_input(out, "Volume"))

    try:
        alpha = coerce_float(payload.get("alpha"), 1.0)
        if alpha < 0.999 or coerce_float(payload.get("transmission"), 0.0) > 0.0:
            material.blend_method = "BLEND"
            material.shadow_method = "HASHED"
    except Exception:
        pass

    return material


def build_npr_studio_pro(material, params=None):
    params = params or {
        "base_color": [0.88, 0.72, 0.68, 1.0],
        "zone2_color": [0.64, 0.48, 0.48, 1.0],
        "zone3_color": [0.36, 0.24, 0.28, 1.0],
        "zone4_color": [0.15, 0.10, 0.14, 1.0],
        "paper_tint": [1.0, 1.0, 1.0, 1.0],
        "paper_scale": 10.0,
        "paper_strength": 0.08,
        "zone_count": 4,
        "threshold_1": 0.72,
        "threshold_2": 0.48,
        "threshold_3": 0.24,
        "shadow_smooth": 0.03,
        "alpha": 1.0,
        "highlight_color": [1.0, 1.0, 1.0, 1.0],
        "highlight_level": 0.28,
        "highlight_size": 0.12,
        "highlight_smooth": 0.04,
        "reflection_color": [1.0, 1.0, 1.0, 1.0],
        "reflection_strength": 0.16,
        "reflection_roughness": 0.08,
        "rim_color": [1.0, 1.0, 1.0, 1.0],
        "rim_width": 0.9,
        "rim_strength": 0.85,
        "detail_scale": 24.0,
        "detail_normal": 0.03,
        "hatch_enable": True,
        "hatch_color": [0.05, 0.05, 0.05, 1.0],
        "hatch_scale": 48.0,
        "hatch_strength": 0.22,
        "hatch_softness": 0.16,
        "hatch_angle": 0.78539816339,
        "hatch_cross_enable": False,
        "hatch_cross_angle": -0.78539816339,
        "hatch_cross_strength": 0.08,
        "halftone_enable": False,
        "halftone_color": [0.05, 0.05, 0.05, 1.0],
        "halftone_scale": 30.0,
        "halftone_strength": 0.18,
        "halftone_threshold": 0.58,
        "halftone_softness": 0.16,
        "halftone_rotation": 0.0,
    }
    nt = ensure_material(material)

    zone_count = max(2, min(4, int(params.get("zone_count", 4) or 4)))
    threshold_1 = max(0.05, min(0.98, float(params.get("threshold_1", 0.72))))
    threshold_2 = max(0.03, min(threshold_1 - 0.02, float(params.get("threshold_2", 0.48))))
    threshold_3 = max(0.01, min(threshold_2 - 0.02, float(params.get("threshold_3", 0.24))))
    zone_colors = [
        params.get("base_color", [1.0, 1.0, 1.0, 1.0]),
        params.get("zone2_color", [0.7, 0.7, 0.7, 1.0]),
        params.get("zone3_color", [0.45, 0.45, 0.45, 1.0]),
        params.get("zone4_color", [0.2, 0.2, 0.2, 1.0]),
    ][:zone_count]
    active_thresholds = [threshold_1, threshold_2, threshold_3][: zone_count - 1]
    highlight_level = max(0.0, float(params.get("highlight_level", 0.28)))
    highlight_smooth = max(0.0, min(1.0, float(params.get("highlight_smooth", 0.04))))
    highlight_size = max(0.02, min(0.98, float(params.get("highlight_size", 0.12))))
    reflection_strength = max(0.0, float(params.get("reflection_strength", 0.16)))
    reflection_roughness = max(0.0, min(1.0, float(params.get("reflection_roughness", 0.08))))
    rim_strength_value = max(0.0, float(params.get("rim_strength", 0.85)))
    paper_scale_value = max(0.1, float(params.get("paper_scale", 10.0)))
    paper_strength_value = max(0.0, min(1.0, float(params.get("paper_strength", 0.08))))
    hatch_enable = bool(params.get("hatch_enable", True))
    hatch_strength_value = max(0.0, min(1.0, float(params.get("hatch_strength", 0.22)))) if hatch_enable else 0.0
    hatch_softness = max(0.0, min(1.0, float(params.get("hatch_softness", 0.16))))
    hatch_cross_enable = bool(params.get("hatch_cross_enable", False)) and hatch_enable
    hatch_cross_strength_value = max(0.0, min(1.0, float(params.get("hatch_cross_strength", 0.08)))) if hatch_cross_enable else 0.0
    halftone_enable = bool(params.get("halftone_enable", False))
    halftone_strength_value = max(0.0, min(1.0, float(params.get("halftone_strength", 0.18)))) if halftone_enable else 0.0
    halftone_threshold = max(0.02, min(0.98, float(params.get("halftone_threshold", 0.58))))
    halftone_softness = max(0.0, min(0.49, float(params.get("halftone_softness", 0.16))))

    def _scale_color(color, strength):
        rgba = list(color)[:4]
        if len(rgba) < 4:
            rgba += [1.0] * (4 - len(rgba))
        rgb = [max(0.0, min(1.0, float(channel))) * strength for channel in rgba[:3]]
        return tuple(rgb + [float(rgba[3])])

    paper = new_rgb(nt, -1700, 600, params["paper_tint"], "Paper Tint")
    hatch_color = new_rgb(nt, -1700, -760, params["hatch_color"], "Hatch Color")
    halftone_color = new_rgb(nt, -1700, -1240, params["halftone_color"], "Halftone Color")
    rim = new_rgb(nt, -1700, -360, params["rim_color"], "Rim Color")
    rim_strength = new_value(nt, -1700, -530, rim_strength_value, "Rim Strength")
    highlight_color = new_rgb(nt, -1700, 260, _scale_color(params["highlight_color"], highlight_level), "Highlight Color")
    reflection_color = new_rgb(nt, -1700, 10, _scale_color(params["reflection_color"], reflection_strength), "Reflection Color")

    white = new_rgb(nt, -1460, 760, [1.0, 1.0, 1.0, 1.0], "Lighting White")
    diffuse = create_node(nt, "ShaderNodeBsdfDiffuse", -1240, 760, "Eevee Diffuse")
    shader_to_rgb = create_node(nt, "ShaderNodeShaderToRGB", -1020, 760, "Eevee Shader To RGB")
    bw = create_node(nt, "ShaderNodeRGBToBW", -820, 640, "Lighting Luma")
    toon_ramp = create_node(nt, "ShaderNodeValToRGB", -760, 800, "Zone Ramp")
    configure_soft_toon_ramp(toon_ramp, zone_colors, active_thresholds, float(params.get("shadow_smooth", 0.03)))
    paper_mix = new_mix_color(nt, -500, 840, "Paper Mix")
    paper_noise = create_node(nt, "ShaderNodeTexNoise", -760, 1020, "Paper Noise")
    paper_noise_scale = new_value(nt, -980, 1020, paper_scale_value, "Paper Scale")
    paper_noise_fac = new_math(nt, -280, 1050, "MULTIPLY", "Paper Amount")

    _, detail_mapping = add_mapping_chain(nt, -1500, -20, "NPR Detail")
    normal = add_micro_bump(nt, try_output(detail_mapping, "Vector"), float(params.get("detail_scale", 24.0)), float(params.get("detail_normal", 0.03)), -1260, -210, "NPR Detail")

    shadow_invert = new_math(nt, -610, 540, "SUBTRACT", "Shadow Invert")
    shadow_fac = new_math(nt, -380, 540, "MULTIPLY", "Shadow Factor")

    _, hatch_mapping = add_mapping_chain(nt, -1500, -760, "NPR Hatch")
    hatch_wave = create_node(nt, "ShaderNodeTexWave", -1220, -760, "Hatch Wave")
    hatch_band = max(0.02, hatch_softness * 0.5)
    hatch_ramp = new_bw_ramp(nt, -980, -760, "Hatch Ramp", max(0.01, 0.5 - hatch_band), min(0.99, 0.5 + hatch_band))
    hatch_mul = new_math(nt, -740, -760, "MULTIPLY", "Hatch Shadow Mix")
    hatch_strength = new_value(nt, -1220, -980, hatch_strength_value, "Hatch Strength")
    hatch_mul2 = new_math(nt, -520, -760, "MULTIPLY", "Hatch Strength Mix")
    hatch_mix = new_mix_color(nt, -300, -760, "Hatch Color Mix")

    _, cross_mapping = add_mapping_chain(nt, -1500, -980, "NPR Cross Hatch")
    cross_wave = create_node(nt, "ShaderNodeTexWave", -1220, -980, "Cross Hatch Wave")
    cross_ramp = new_bw_ramp(nt, -980, -980, "Cross Hatch Ramp", max(0.01, 0.5 - hatch_band), min(0.99, 0.5 + hatch_band))
    cross_mul = new_math(nt, -740, -980, "MULTIPLY", "Cross Hatch Shadow Mix")
    cross_strength = new_value(nt, -1220, -1200, hatch_cross_strength_value, "Cross Hatch Strength")
    cross_mul2 = new_math(nt, -520, -980, "MULTIPLY", "Cross Hatch Strength Mix")
    cross_mix = new_mix_color(nt, -300, -980, "Cross Hatch Color Mix")

    _, halftone_mapping = add_mapping_chain(nt, -1500, -1260, "NPR Halftone")
    halftone_voronoi = create_node(nt, "ShaderNodeTexVoronoi", -1220, -1260, "Halftone Voronoi")
    tone_edge = max(0.02, halftone_softness)
    halftone_ramp = new_bw_ramp(nt, -980, -1260, "Halftone Ramp", max(0.02, halftone_threshold - tone_edge), min(0.98, halftone_threshold + tone_edge))
    halftone_mul = new_math(nt, -740, -1260, "MULTIPLY", "Halftone Shadow Mix")
    halftone_strength = new_value(nt, -1220, -1460, halftone_strength_value, "Halftone Strength")
    halftone_mul2 = new_math(nt, -520, -1260, "MULTIPLY", "Halftone Strength Mix")
    halftone_mix = new_mix_color(nt, -300, -1200, "Halftone Color Mix")

    eevee_emit = create_node(nt, "ShaderNodeEmission", 120, 760, "Eevee Base Emission")
    eevee_gloss = create_node(nt, "ShaderNodeBsdfGlossy", -140, 460, "Eevee Highlight Gloss")
    eevee_refl = create_node(nt, "ShaderNodeBsdfGlossy", -140, 220, "Eevee Reflection Gloss")
    eevee_rim_mask = add_rim_mask(nt, -880, 220, "Eevee Rim", (max(0.05, float(params.get("rim_width", 0.9)) - 0.15), float(params.get("rim_width", 0.9))))
    eevee_rim_mul = new_math(nt, -600, 160, "MULTIPLY", "Eevee Rim Multiply")
    eevee_rim_emit = create_node(nt, "ShaderNodeEmission", -140, 0, "Eevee Rim Emission")
    eevee_add_1 = create_node(nt, "ShaderNodeAddShader", 140, 400, "Eevee Add 1")
    eevee_add_2 = create_node(nt, "ShaderNodeAddShader", 360, 280, "Eevee Add 2")
    eevee_add_3 = create_node(nt, "ShaderNodeAddShader", 580, 160, "Eevee Add 3")
    out_eevee = new_output(nt, 840, 160, "Eevee Output", target="EEVEE")

    cycles_base = new_rgb(nt, -1260, 1500, params["base_color"], "Cycles Base Color")
    cycles_toon = create_node(nt, "ShaderNodeBsdfToon", -1020, 1500, "Cycles Toon BSDF")
    cycles_gloss = create_node(nt, "ShaderNodeBsdfGlossy", -780, 1270, "Cycles Highlight Gloss")
    cycles_refl = create_node(nt, "ShaderNodeBsdfGlossy", -780, 1060, "Cycles Reflection Gloss")
    cycles_rim_mask = add_rim_mask(nt, -1240, 1090, "Cycles Rim", (max(0.05, float(params.get("rim_width", 0.9)) - 0.15), float(params.get("rim_width", 0.9))))
    cycles_rim_mul = new_math(nt, -1000, 1020, "MULTIPLY", "Cycles Rim Multiply")
    cycles_rim_emit = create_node(nt, "ShaderNodeEmission", -780, 840, "Cycles Rim Emission")
    cycles_add_1 = create_node(nt, "ShaderNodeAddShader", -520, 1360, "Cycles Add 1")
    cycles_add_2 = create_node(nt, "ShaderNodeAddShader", -260, 1220, "Cycles Add 2")
    cycles_add_3 = create_node(nt, "ShaderNodeAddShader", 0, 1080, "Cycles Add 3")
    out_cycles = new_output(nt, 260, 1080, "Cycles Output", target="CYCLES")

    link(nt, try_output(white, "Color"), try_input(diffuse, "Color"))
    link(nt, try_output(diffuse, "BSDF"), try_input(shader_to_rgb, "Shader"))
    link(nt, try_output(shader_to_rgb, "Color"), try_input(bw, "Color"))
    link(nt, try_output(shader_to_rgb, "Color"), try_input(toon_ramp, "Fac"))

    link(nt, try_output(paper_noise_scale, "Value"), try_input(paper_noise, "Scale"))
    link(nt, try_output(detail_mapping, "Vector"), try_input(paper_noise, "Vector"))
    set_socket_value(principled_socket(paper_noise, "Detail"), 6.0)
    link(nt, mix_color_output(toon_ramp), mix_color_a_input(paper_mix))
    link(nt, try_output(paper, "Color"), mix_color_b_input(paper_mix))
    link(nt, try_output(paper_noise, "Fac"), try_input(paper_noise_fac, 0))
    set_socket_value(try_input(paper_noise_fac, 1), paper_strength_value)
    link(nt, try_output(paper_noise_fac, "Value"), mix_color_fac_input(paper_mix))

    set_socket_value(try_input(shadow_invert, 0), 1.0)
    link(nt, try_output(bw, "Val"), try_input(shadow_invert, 1))
    set_socket_value(try_input(shadow_fac, 1), 1.0)
    link(nt, try_output(shadow_invert, "Value"), try_input(shadow_fac, 0))

    try:
        hatch_wave.wave_type = "BANDS"
        hatch_wave.bands_direction = "Y"
    except Exception:
        pass
    try:
        hatch_mapping.inputs[3].default_value[2] = float(params.get("hatch_angle", 0.78539816339))
    except Exception:
        pass
    link(nt, try_output(hatch_mapping, "Vector"), try_input(hatch_wave, "Vector"))
    set_socket_value(try_input(hatch_wave, "Scale"), float(params.get("hatch_scale", 48.0)))
    set_socket_value(try_input(hatch_wave, "Distortion"), 0.2)
    link(nt, try_output(hatch_wave, "Color"), try_input(hatch_ramp, "Fac"))
    link(nt, try_output(hatch_ramp, "Color"), try_input(hatch_mul, 0))
    link(nt, try_output(shadow_fac, "Value"), try_input(hatch_mul, 1))
    link(nt, try_output(hatch_mul, "Value"), try_input(hatch_mul2, 0))
    link(nt, try_output(hatch_strength, "Value"), try_input(hatch_mul2, 1))
    link(nt, mix_color_output(paper_mix), mix_color_a_input(hatch_mix))
    link(nt, try_output(hatch_color, "Color"), mix_color_b_input(hatch_mix))
    link(nt, try_output(hatch_mul2, "Value"), mix_color_fac_input(hatch_mix))

    try:
        cross_wave.wave_type = "BANDS"
        cross_wave.bands_direction = "Y"
    except Exception:
        pass
    try:
        cross_mapping.inputs[3].default_value[2] = float(params.get("hatch_cross_angle", -0.78539816339))
    except Exception:
        pass
    link(nt, try_output(cross_mapping, "Vector"), try_input(cross_wave, "Vector"))
    set_socket_value(try_input(cross_wave, "Scale"), float(params.get("hatch_scale", 48.0)))
    set_socket_value(try_input(cross_wave, "Distortion"), 0.2)
    link(nt, try_output(cross_wave, "Color"), try_input(cross_ramp, "Fac"))
    link(nt, try_output(cross_ramp, "Color"), try_input(cross_mul, 0))
    link(nt, try_output(shadow_fac, "Value"), try_input(cross_mul, 1))
    link(nt, try_output(cross_mul, "Value"), try_input(cross_mul2, 0))
    link(nt, try_output(cross_strength, "Value"), try_input(cross_mul2, 1))
    link(nt, mix_color_output(hatch_mix), mix_color_a_input(cross_mix))
    link(nt, try_output(hatch_color, "Color"), mix_color_b_input(cross_mix))
    link(nt, try_output(cross_mul2, "Value"), mix_color_fac_input(cross_mix))

    try:
        halftone_mapping.inputs[3].default_value[2] = float(params.get("halftone_rotation", 0.0))
    except Exception:
        pass
    link(nt, try_output(halftone_mapping, "Vector"), try_input(halftone_voronoi, "Vector"))
    set_socket_value(try_input(halftone_voronoi, "Scale"), float(params.get("halftone_scale", 30.0)))
    link(nt, try_output(halftone_voronoi, "Distance"), try_input(halftone_ramp, "Fac"))
    link(nt, try_output(halftone_ramp, "Color"), try_input(halftone_mul, 0))
    link(nt, try_output(shadow_fac, "Value"), try_input(halftone_mul, 1))
    link(nt, try_output(halftone_mul, "Value"), try_input(halftone_mul2, 0))
    link(nt, try_output(halftone_strength, "Value"), try_input(halftone_mul2, 1))
    link(nt, mix_color_output(cross_mix), mix_color_a_input(halftone_mix))
    link(nt, try_output(halftone_color, "Color"), mix_color_b_input(halftone_mix))
    link(nt, try_output(halftone_mul2, "Value"), mix_color_fac_input(halftone_mix))

    link(nt, mix_color_output(halftone_mix), try_input(eevee_emit, "Color"))
    set_socket_value(try_input(eevee_emit, "Strength"), 1.0)
    gloss_roughness = max(0.001, min(1.0, (1.0 - highlight_size) * 0.85 + highlight_smooth * 0.55))
    link(nt, try_output(highlight_color, "Color"), try_input(eevee_gloss, "Color"))
    set_socket_value(try_input(eevee_gloss, "Roughness"), gloss_roughness)
    link(nt, normal, try_input(eevee_gloss, "Normal"))
    link(nt, try_output(reflection_color, "Color"), try_input(eevee_refl, "Color"))
    set_socket_value(try_input(eevee_refl, "Roughness"), reflection_roughness)
    link(nt, normal, try_input(eevee_refl, "Normal"))
    link(nt, eevee_rim_mask, try_input(eevee_rim_mul, 0))
    link(nt, try_output(rim_strength, "Value"), try_input(eevee_rim_mul, 1))
    link(nt, try_output(rim, "Color"), try_input(eevee_rim_emit, "Color"))
    link(nt, try_output(eevee_rim_mul, "Value"), try_input(eevee_rim_emit, "Strength"))
    link(nt, try_output(eevee_emit, "Emission"), try_input(eevee_add_1, 0))
    link(nt, try_output(eevee_gloss, "BSDF"), try_input(eevee_add_1, 1))
    link(nt, try_output(eevee_add_1, "Shader"), try_input(eevee_add_2, 0))
    link(nt, try_output(eevee_refl, "BSDF"), try_input(eevee_add_2, 1))
    link(nt, try_output(eevee_add_2, "Shader"), try_input(eevee_add_3, 0))
    link(nt, try_output(eevee_rim_emit, "Emission"), try_input(eevee_add_3, 1))
    connect_surface(out_eevee, try_output(eevee_add_3, "Shader"), nt)

    link(nt, try_output(cycles_base, "Color"), try_input(cycles_toon, "Color"))
    set_socket_value(try_input(cycles_toon, "Size"), threshold_1)
    set_socket_value(try_input(cycles_toon, "Smooth"), float(params.get("shadow_smooth", 0.03)))
    link(nt, try_output(highlight_color, "Color"), try_input(cycles_gloss, "Color"))
    set_socket_value(try_input(cycles_gloss, "Roughness"), gloss_roughness)
    link(nt, normal, try_input(cycles_gloss, "Normal"))
    link(nt, try_output(reflection_color, "Color"), try_input(cycles_refl, "Color"))
    set_socket_value(try_input(cycles_refl, "Roughness"), reflection_roughness)
    link(nt, normal, try_input(cycles_refl, "Normal"))
    link(nt, cycles_rim_mask, try_input(cycles_rim_mul, 0))
    link(nt, try_output(rim_strength, "Value"), try_input(cycles_rim_mul, 1))
    link(nt, try_output(rim, "Color"), try_input(cycles_rim_emit, "Color"))
    link(nt, try_output(cycles_rim_mul, "Value"), try_input(cycles_rim_emit, "Strength"))
    link(nt, try_output(cycles_toon, "BSDF"), try_input(cycles_add_1, 0))
    link(nt, try_output(cycles_gloss, "BSDF"), try_input(cycles_add_1, 1))
    link(nt, try_output(cycles_add_1, "Shader"), try_input(cycles_add_2, 0))
    link(nt, try_output(cycles_refl, "BSDF"), try_input(cycles_add_2, 1))
    link(nt, try_output(cycles_add_2, "Shader"), try_input(cycles_add_3, 0))
    link(nt, try_output(cycles_rim_emit, "Emission"), try_input(cycles_add_3, 1))
    connect_surface(out_cycles, try_output(cycles_add_3, "Shader"), nt)

    try:
        material.blend_method = "BLEND" if float(params.get("alpha", 1.0)) < 0.999 else "OPAQUE"
    except Exception:
        pass
    try:
        material.shadow_method = "HASHED" if float(params.get("alpha", 1.0)) < 0.999 else "OPAQUE"
    except Exception:
        pass

    finalize_material(material, "NPR_STUDIO_PRO", params)



BUILDERS = {
    "UNIVERSAL_PBR": build_universal_pbr,
    "AUTO_CLEARCOAT": build_auto_clearcoat,
    "GLASS_PRO": build_glass_pro,
    "SKIN_LITE": build_skin_lite,
    "SKIN_PRO": build_skin_pro,
    "FOLIAGE": build_foliage,
    "FABRIC_WOOL": build_fabric_wool,
    "BRUSHED_METAL": build_brushed_metal,
    "CERAMIC_COAT": build_ceramic_coat,
    "LIQUID_SURFACE": build_liquid_surface,
    "ANIME_TOON": build_anime_toon,
    "NPR_STUDIO_PRO": build_npr_studio_pro,
    "CLAY_DOH": build_clay_doh,
    "RIM_GLOW": build_rim_glow,
    "HOLOGRAM_FX": build_hologram_fx,
    "WATERCOLOR_NPR": build_watercolor_npr,
    "HALFTONE_COMIC": build_halftone_comic,
    "INK_HATCH": build_ink_hatch,
    "TERRAIN_BLEND": build_terrain_blend,
    "WET_SURFACE": build_wet_surface,
    "SNOW_MASK": build_snow_mask,
    "MOSS_GROWTH": build_moss_growth,
    "RUSTED_PAINT": build_rusted_paint,
    "EDGE_WEAR": build_edge_wear,
    "DECAL_DETAIL": build_decal_detail,
    "PROCEDURAL_RIPPLE": build_procedural_ripple,
    "PUDDLE_MIXER": build_puddle_mixer,
}

_BUILDER_DEFAULT_PARAMS: dict[str, dict] = {}


def _default_params_for_builder(preset_id: str, builder) -> dict:
    """Capture a builder's complete defaults for backward-compatible rebuilds.

    Older material metadata can contain only the parameters that existed in the
    version which created it.  Feeding that partial dictionary directly to a
    newer builder raises KeyError after the node tree has already been cleared.
    Build once on a temporary material, cache the stored defaults, and merge the
    saved values on top before touching the user's material.
    """
    cached = _BUILDER_DEFAULT_PARAMS.get(preset_id)
    if cached is not None:
        return dict(cached)
    temporary = bpy.data.materials.new(name=f"__SSS_Defaults_{preset_id}")
    try:
        builder(temporary, params=None)
        defaults = core.get_material_params(temporary)
        if not isinstance(defaults, dict):
            defaults = {}
        _BUILDER_DEFAULT_PARAMS[preset_id] = dict(defaults)
        return dict(defaults)
    finally:
        try:
            bpy.data.materials.remove(temporary, do_unlink=True)
        except Exception:
            pass


def build_preset(material, preset_id: str, custom_params=None):
    builder = BUILDERS.get(preset_id)
    if not builder:
        raise ValueError(f"Unknown preset: {preset_id}")
    if isinstance(custom_params, dict):
        params = _default_params_for_builder(preset_id, builder)
        params.update(custom_params)
        builder(material, params=params)
    else:
        builder(material, params=custom_params)


def build_product_plastic(material, params=None):
    params = params or {
        "base_color": [0.14, 0.18, 0.24, 1.0],
        "accent_color": [0.20, 0.24, 0.30, 1.0],
        "roughness": 0.22,
        "coat_weight": 0.32,
        "coat_roughness": 0.05,
        "ior": 1.47,
        "grain_scale": 28.0,
        "micro_bump": 0.018,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -1100, 260, params["base_color"], "Plastic Base")
    accent = new_rgb(nt, -1100, 80, params["accent_color"], "Plastic Accent")
    rough = new_value(nt, -1100, -110, params["roughness"], "Roughness")
    coat = new_value(nt, -1100, -290, params["coat_weight"], "Coat Weight")
    coat_rough = new_value(nt, -1100, -470, params["coat_roughness"], "Coat Roughness")
    _, mapping = add_mapping_chain(nt, -1400, -60, "Product Plastic")
    grain_scale = new_value(nt, -1400, -290, params["grain_scale"], "Grain Scale")
    noise = create_node(nt, "ShaderNodeTexNoise", -900, -40, "Plastic Breakup")
    ramp = new_bw_ramp(nt, -660, -40, "Plastic Breakup Ramp", 0.34, 0.68)
    mix = new_mix_color(nt, -430, 160, "Plastic Color Mix")
    normal = add_micro_bump(nt, try_output(mapping, "Vector"), params["grain_scale"], params["micro_bump"], -920, -330, "Plastic Detail")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", -120, 80, "Principled BSDF")
    out = create_node(nt, "ShaderNodeOutputMaterial", 240, 80, "Material Output")

    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    link(nt, try_output(grain_scale, "Value"), try_input(noise, "Scale"))
    set_socket_value(try_input(noise, "Detail"), 10.0)
    link(nt, try_output(noise, "Fac"), try_input(ramp, "Fac"))
    link(nt, try_output(base, "Color"), mix_color_a_input(mix))
    link(nt, try_output(accent, "Color"), mix_color_b_input(mix))
    link(nt, try_output(ramp, "Color"), mix_color_fac_input(mix))

    link(nt, mix_color_output(mix), principled_socket(bsdf, "Base Color"))
    link(nt, try_output(rough, "Value"), principled_socket(bsdf, "Roughness"))
    link(nt, try_output(coat, "Value"), principled_socket(bsdf, "Coat Weight", "Clearcoat"))
    link(nt, try_output(coat_rough, "Value"), principled_socket(bsdf, "Coat Roughness", "Clearcoat Roughness"))
    set_socket_value(principled_socket(bsdf, "IOR"), params["ior"])
    link(nt, normal, principled_socket(bsdf, "Normal"))
    link(nt, try_output(bsdf, "BSDF"), try_input(out, "Surface"))
    finalize_material(material, "PRODUCT_PLASTIC", params)


def build_archviz_wood(material, params=None):
    params = params or {
        "light_color": [0.63, 0.43, 0.23, 1.0],
        "dark_color": [0.34, 0.19, 0.08, 1.0],
        "roughness": 0.42,
        "grain_scale": 12.0,
        "grain_strength": 0.055,
        "finish_coat": 0.12,
        "finish_roughness": 0.08,
    }
    nt = ensure_material(material)
    light = new_rgb(nt, -1180, 260, params["light_color"], "Light Wood")
    dark = new_rgb(nt, -1180, 70, params["dark_color"], "Dark Wood")
    rough = new_value(nt, -1180, -120, params["roughness"], "Roughness")
    coat = new_value(nt, -1180, -300, params["finish_coat"], "Finish Coat")
    coat_rough = new_value(nt, -1180, -470, params["finish_roughness"], "Finish Roughness")
    _, mapping = add_mapping_chain(nt, -1500, -50, "Archviz Wood")
    grain_scale = new_value(nt, -1500, -270, params["grain_scale"], "Grain Scale")
    wave = create_node(nt, "ShaderNodeTexWave", -980, 40, "Wood Grain")
    noise = create_node(nt, "ShaderNodeTexNoise", -980, -220, "Wood Distortion")
    ramp = new_bw_ramp(nt, -720, 40, "Wood Grain Ramp", 0.37, 0.67)
    color_mix = new_mix_color(nt, -450, 170, "Wood Color Mix")
    bump = create_node(nt, "ShaderNodeBump", -210, -60, "Wood Grain Bump")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", 40, 90, "Principled BSDF")
    out = create_node(nt, "ShaderNodeOutputMaterial", 360, 90, "Material Output")

    try:
        wave.wave_type = "BANDS"
        wave.bands_direction = "X"
    except Exception:
        pass
    link(nt, try_output(mapping, "Vector"), try_input(wave, "Vector"))
    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    link(nt, try_output(grain_scale, "Value"), try_input(wave, "Scale"))
    set_socket_value(try_input(noise, "Scale"), max(2.0, params["grain_scale"] * 0.35))
    set_socket_value(try_input(noise, "Detail"), 9.0)
    link(nt, try_output(noise, "Fac"), try_input(wave, "Distortion"))
    link(nt, try_output(wave, "Fac"), try_input(ramp, "Fac"))
    link(nt, try_output(light, "Color"), mix_color_a_input(color_mix))
    link(nt, try_output(dark, "Color"), mix_color_b_input(color_mix))
    link(nt, try_output(ramp, "Color"), mix_color_fac_input(color_mix))
    link(nt, try_output(wave, "Fac"), try_input(bump, "Height"))
    set_socket_value(try_input(bump, "Strength"), params["grain_strength"])

    link(nt, mix_color_output(color_mix), principled_socket(bsdf, "Base Color"))
    link(nt, try_output(rough, "Value"), principled_socket(bsdf, "Roughness"))
    link(nt, try_output(coat, "Value"), principled_socket(bsdf, "Coat Weight", "Clearcoat"))
    link(nt, try_output(coat_rough, "Value"), principled_socket(bsdf, "Coat Roughness", "Clearcoat Roughness"))
    link(nt, try_output(bump, "Normal"), principled_socket(bsdf, "Normal"))
    link(nt, try_output(bsdf, "BSDF"), try_input(out, "Surface"))
    finalize_material(material, "ARCHVIZ_WOOD", params)


def build_archviz_concrete(material, params=None):
    params = params or {
        "base_color": [0.63, 0.63, 0.61, 1.0],
        "aggregate_color": [0.45, 0.45, 0.43, 1.0],
        "roughness": 0.72,
        "breakup_scale": 7.0,
        "speckle_strength": 0.42,
        "surface_bump": 0.038,
    }
    nt = ensure_material(material)
    base = new_rgb(nt, -1200, 250, params["base_color"], "Concrete Base")
    aggregate = new_rgb(nt, -1200, 70, params["aggregate_color"], "Concrete Aggregate")
    rough = new_value(nt, -1200, -110, params["roughness"], "Roughness")
    _, mapping = add_mapping_chain(nt, -1520, -60, "Archviz Concrete")
    breakup_scale = new_value(nt, -1520, -270, params["breakup_scale"], "Breakup Scale")
    speckle = new_value(nt, -1520, -450, params["speckle_strength"], "Speckle Strength")
    noise = create_node(nt, "ShaderNodeTexNoise", -1000, 10, "Concrete Noise")
    voronoi = create_node(nt, "ShaderNodeTexVoronoi", -1000, -250, "Aggregate Pattern")
    pattern_mix = new_mix_color(nt, -760, -110, "Concrete Pattern Mix")
    ramp = new_bw_ramp(nt, -520, -110, "Concrete Pattern Ramp", 0.32, 0.72)
    color_mix = new_mix_color(nt, -280, 140, "Concrete Color Mix")
    bump = create_node(nt, "ShaderNodeBump", -40, -80, "Concrete Bump")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", 200, 80, "Principled BSDF")
    out = create_node(nt, "ShaderNodeOutputMaterial", 520, 80, "Material Output")

    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    link(nt, try_output(mapping, "Vector"), try_input(voronoi, "Vector"))
    link(nt, try_output(breakup_scale, "Value"), try_input(noise, "Scale"))
    set_socket_value(try_input(noise, "Detail"), 12.0)
    set_socket_value(try_input(voronoi, "Scale"), params["breakup_scale"] * 2.4)
    link(nt, try_output(noise, "Color"), mix_color_a_input(pattern_mix))
    link(nt, try_output(voronoi, "Color"), mix_color_b_input(pattern_mix))
    link(nt, try_output(speckle, "Value"), mix_color_fac_input(pattern_mix))
    link(nt, mix_color_output(pattern_mix), try_input(ramp, "Fac"))
    link(nt, try_output(base, "Color"), mix_color_a_input(color_mix))
    link(nt, try_output(aggregate, "Color"), mix_color_b_input(color_mix))
    link(nt, try_output(ramp, "Color"), mix_color_fac_input(color_mix))
    link(nt, try_output(voronoi, "Distance"), try_input(bump, "Height"))
    set_socket_value(try_input(bump, "Strength"), params["surface_bump"])

    link(nt, mix_color_output(color_mix), principled_socket(bsdf, "Base Color"))
    link(nt, try_output(rough, "Value"), principled_socket(bsdf, "Roughness"))
    link(nt, try_output(bump, "Normal"), principled_socket(bsdf, "Normal"))
    link(nt, try_output(bsdf, "BSDF"), try_input(out, "Surface"))
    finalize_material(material, "ARCHVIZ_CONCRETE", params)


def build_velvet_sheen(material, params=None):
    params = params or {
        "base_color": [0.26, 0.09, 0.16, 1.0],
        "roughness": 0.62,
        "sheen": 0.72,
        "fiber_scale": 85.0,
        "fuzz_strength": 0.06,
    }
    build_fabric_wool(material, params=params)
    nt = getattr(material, "node_tree", None)
    bsdf = core.first_principled_on_output_path(material) if nt else None
    if bsdf is not None:
        set_socket_value(principled_socket(bsdf, "Sheen Tint"), 0.48)
    finalize_material(material, "VELVET_SHEEN", params)


def build_neon_emissive(material, params=None):
    params = params or {
        "glow_color": [0.14, 0.95, 1.0, 1.0],
        "glow_strength": 8.0,
        "rim_width": 0.93,
        "panel_tint": [0.04, 0.06, 0.08, 1.0],
        "edge_breakup": 0.32,
    }
    nt = ensure_material(material)
    panel = new_rgb(nt, -1080, 230, params["panel_tint"], "Panel Tint")
    glow = new_rgb(nt, -1080, 40, params["glow_color"], "Glow Color")
    strength = new_value(nt, -1080, -150, params["glow_strength"], "Glow Strength")
    breakup = new_value(nt, -1080, -330, params["edge_breakup"], "Edge Breakup")
    _, mapping = add_mapping_chain(nt, -1380, -40, "Neon")
    noise = create_node(nt, "ShaderNodeTexNoise", -860, -190, "Edge Noise")
    rim_mask = add_rim_mask(nt, -840, 10, "Neon Rim", (0.62, params["rim_width"]))
    mul = new_math(nt, -610, -60, "MULTIPLY", "Glow Multiply")
    add = new_math(nt, -390, -150, "ADD", "Breakup Add")
    bsdf = create_node(nt, "ShaderNodeBsdfPrincipled", -180, 90, "Principled BSDF")
    emission = create_node(nt, "ShaderNodeEmission", -180, -160, "Emission")
    shader_add = create_node(nt, "ShaderNodeAddShader", 120, -10, "Add Shader")
    out = create_node(nt, "ShaderNodeOutputMaterial", 400, -10, "Material Output")

    link(nt, try_output(mapping, "Vector"), try_input(noise, "Vector"))
    set_socket_value(try_input(noise, "Scale"), 12.0)
    set_socket_value(try_input(noise, "Detail"), 8.0)
    link(nt, rim_mask, try_input(mul, 0))
    link(nt, try_output(strength, "Value"), try_input(mul, 1))
    link(nt, try_output(noise, "Fac"), try_input(add, 0))
    link(nt, try_output(breakup, "Value"), try_input(add, 1))

    link(nt, try_output(panel, "Color"), principled_socket(bsdf, "Base Color"))
    set_socket_value(principled_socket(bsdf, "Roughness"), 0.18)
    link(nt, try_output(glow, "Color"), try_input(emission, "Color"))
    link(nt, try_output(mul, "Value"), try_input(emission, "Strength"))
    link(nt, try_output(bsdf, "BSDF"), try_input(shader_add, 0))
    link(nt, try_output(emission, "Emission"), try_input(shader_add, 1))
    link(nt, try_output(shader_add, "Shader"), try_input(out, "Surface"))
    finalize_material(material, "NEON_EMISSIVE", params)


def build_paper_ink(material, params=None):
    params = params or {
        "ink_color": [0.06, 0.06, 0.07, 1.0],
        "paper_color": [0.98, 0.97, 0.94, 1.0],
        "hatch_scale": 48.0,
        "hatch_strength": 0.62,
        "shadow_softness": 0.18,
    }
    build_ink_hatch(material, params=params)
    finalize_material(material, "PAPER_INK", params)


def build_painterly_oil(material, params=None):
    params = params or {
        "base_color": [0.63, 0.42, 0.18, 1.0],
        "wash_color": [0.23, 0.16, 0.11, 1.0],
        "softness": 0.18,
        "paper_scale": 18.0,
        "wash_strength": 0.58,
    }
    build_watercolor_npr(material, params=params)
    finalize_material(material, "PAINTERLY_OIL", params)


BUILDERS.update({
    "PRODUCT_PLASTIC": build_product_plastic,
    "ARCHVIZ_WOOD": build_archviz_wood,
    "ARCHVIZ_CONCRETE": build_archviz_concrete,
    "VELVET_SHEEN": build_velvet_sheen,
    "NEON_EMISSIVE": build_neon_emissive,
    "PAPER_INK": build_paper_ink,
    "PAINTERLY_OIL": build_painterly_oil,
})



def build_openpbr_surface(material, params=None):
    params = params or {
        "base_color": [0.74, 0.74, 0.76, 1.0],
        "roughness": 0.42,
        "metalness": 0.0,
        "ior": 1.5,
        "coat_weight": 0.12,
        "coat_roughness": 0.08,
        "transmission": 0.0,
        "subsurface_weight": 0.0,
    }
    build_portable_principled(material, params)
    finalize_material(material, "OPENPBR_SURFACE", params)



def build_materialx_standard(material, params=None):
    params = params or {
        "base_color": [0.72, 0.73, 0.75, 1.0],
        "roughness": 0.35,
        "metalness": 0.0,
        "ior": 1.5,
        "transmission": 0.0,
        "subsurface_weight": 0.0,
        "coat_weight": 0.0,
        "coat_roughness": 0.03,
        "sheen_weight": 0.0,
    }
    build_portable_principled(material, params)
    finalize_material(material, "MATERIALX_STANDARD", params)



def build_usd_preview_safe(material, params=None):
    params = params or {
        "base_color": [0.78, 0.78, 0.78, 1.0],
        "roughness": 0.5,
        "metalness": 0.0,
        "ior": 1.45,
        "alpha": 1.0,
        "transmission": 0.0,
        "emission_color": [0.0, 0.0, 0.0, 1.0],
        "emission_strength": 1.0,
    }
    build_portable_principled(material, params)
    finalize_material(material, "USD_PREVIEW_SAFE", params)


BUILDERS.update({
    "OPENPBR_SURFACE": build_openpbr_surface,
    "MATERIALX_STANDARD": build_materialx_standard,
    "USD_PREVIEW_SAFE": build_usd_preview_safe,
})


# v5.18.64 software-reference PBR builder expansion
def _software_pbr_param_color(params, key, fallback):
    value = params.get(key, fallback)
    try:
        if isinstance(value, (list, tuple)) and len(value) >= 3:
            rgb = [float(value[i]) for i in range(3)]
            alpha = float(value[3]) if len(value) > 3 else 1.0
            return (rgb[0], rgb[1], rgb[2], alpha)
    except Exception:
        pass
    return tuple(fallback)


def _software_pbr_param_float(params, key, fallback=0.0):
    try:
        return float(params.get(key, fallback))
    except Exception:
        return float(fallback)


def _set_principled_optional(bsdf, names, value):
    socket = principled_socket(bsdf, *names) if isinstance(names, (list, tuple)) else principled_socket(bsdf, names)
    if socket is not None:
        set_socket_value(socket, value)



def _software_mix_literal(nt, current_socket, color, factor, label, x, y):
    try:
        mix = new_mix_color(nt, x, y, label)
        rgb = new_rgb(nt, x - 220, y - 70, tuple(color), label + ' Color')
        link(nt, current_socket, mix_color_a_input(mix))
        link(nt, try_output(rgb, 'Color'), mix_color_b_input(mix))
        if hasattr(factor, 'node'):
            link(nt, factor, mix_color_fac_input(mix))
        else:
            set_socket_value(mix_color_fac_input(mix), max(0.0, min(1.0, float(factor))))
        return mix_color_output(mix)
    except Exception:
        return current_socket


def _software_apply_look_nodes(nt, params, current_socket, base_color, accent_color):
    # Hard cel bands driven by object height keep the look visible in preview and final renders.
    try:
        cel_shadow = params.get('cel_shadow_color')
        cel_light = params.get('cel_light_color') or base_color
        if cel_shadow:
            coord = create_node(nt, 'ShaderNodeTexCoord', -1160, 560, 'Cel Coordinates')
            sep = create_node(nt, 'ShaderNodeSeparateXYZ', -940, 560, 'Cel Height')
            ramp = create_node(nt, 'ShaderNodeValToRGB', -700, 560, 'Hard Cel Ramp')
            threshold = max(0.0, min(1.0, _software_pbr_param_float(params, 'cel_threshold', 0.48)))
            try:
                ramp.color_ramp.interpolation = 'CONSTANT'
                ramp.color_ramp.elements[0].position = threshold
                ramp.color_ramp.elements[0].color = tuple(cel_shadow)
                ramp.color_ramp.elements[1].position = min(1.0, threshold + 0.02)
                ramp.color_ramp.elements[1].color = tuple(cel_light)
                if params.get('cel_highlight_color'):
                    el = ramp.color_ramp.elements.new(max(0.0, min(1.0, _software_pbr_param_float(params, 'cel_highlight_pos', 0.84))))
                    el.color = tuple(params.get('cel_highlight_color'))
            except Exception:
                pass
            link(nt, try_output(coord, 'Generated', 'Object'), try_input(sep, 'Vector'))
            link(nt, try_output(sep, 'Z'), try_input(ramp, 'Fac'))
            current_socket = try_output(ramp, 'Color')
    except Exception:
        pass
    # Opposing gel/side-light colors.
    try:
        left = params.get('left_light_color')
        right = params.get('right_light_color')
        strength = max(0.0, min(1.0, _software_pbr_param_float(params, 'side_light_strength', 0.0)))
        if left and right and strength > 0.0:
            coord = create_node(nt, 'ShaderNodeTexCoord', -1160, 760, 'Side Light Coordinates')
            sep = create_node(nt, 'ShaderNodeSeparateXYZ', -940, 760, 'Side Light Split')
            ramp = create_node(nt, 'ShaderNodeValToRGB', -700, 760, 'Dual Gel Colors')
            try:
                ramp.color_ramp.interpolation = 'EASE'
                ramp.color_ramp.elements[0].position = 0.18
                ramp.color_ramp.elements[0].color = tuple(left)
                ramp.color_ramp.elements[1].position = 0.82
                ramp.color_ramp.elements[1].color = tuple(right)
            except Exception:
                pass
            link(nt, try_output(coord, 'Generated', 'Object'), try_input(sep, 'Vector'))
            link(nt, try_output(sep, 'X'), try_input(ramp, 'Fac'))
            mix = new_mix_color(nt, -440, 650, 'Side Gel Overlay')
            link(nt, current_socket, mix_color_a_input(mix))
            link(nt, try_output(ramp, 'Color'), mix_color_b_input(mix))
            set_socket_value(mix_color_fac_input(mix), strength)
            current_socket = mix_color_output(mix)
    except Exception:
        pass
    # View-dependent rim/backlight.
    try:
        rim_color = params.get('rim_color') or params.get('backlight_color')
        rim_strength = max(0.0, min(1.0, _software_pbr_param_float(params, 'rim_strength', 0.0)))
        if rim_color and rim_strength > 0.0:
            fresnel = create_node(nt, 'ShaderNodeFresnel', -650, 420, 'Rim Fresnel')
            ramp = create_node(nt, 'ShaderNodeValToRGB', -440, 420, 'Rim Mask')
            try:
                set_socket_value(try_input(fresnel, 'IOR'), max(1.01, _software_pbr_param_float(params, 'rim_ior', 1.75)))
                width = max(0.01, min(0.95, _software_pbr_param_float(params, 'rim_width', 0.44)))
                ramp.color_ramp.interpolation = 'EASE'
                ramp.color_ramp.elements[0].position = max(0.0, 1.0 - width)
                ramp.color_ramp.elements[0].color = (0.0, 0.0, 0.0, 1.0)
                ramp.color_ramp.elements[1].position = 1.0
                ramp.color_ramp.elements[1].color = (rim_strength, rim_strength, rim_strength, 1.0)
            except Exception:
                pass
            link(nt, try_output(fresnel, 'Fac'), try_input(ramp, 'Fac'))
            current_socket = _software_mix_literal(nt, current_socket, tuple(rim_color), try_output(ramp, 'Color'), 'Rim / Backlight Mix', -180, 440)
    except Exception:
        pass
    # Poster/noir shadow bias.
    try:
        poster = params.get('poster_shadow_color')
        poster_strength = max(0.0, min(1.0, _software_pbr_param_float(params, 'poster_shadow_strength', 0.0)))
        if poster and poster_strength > 0.0:
            current_socket = _software_mix_literal(nt, current_socket, tuple(poster), poster_strength, 'Poster Shadow Bias', -160, 760)
    except Exception:
        pass
    return current_socket

def build_software_pbr_variant(material, preset_id: str, params=None):
    defaults = dict(getattr(data, 'SOFTWARE_PBR_DEFAULTS', {}).get(preset_id, {}) or {})
    if params:
        defaults.update(params)
    params = defaults
    base_color = _software_pbr_param_color(params, 'base_color', (0.72, 0.72, 0.72, 1.0))
    accent_color = _software_pbr_param_color(params, 'accent_color', base_color)
    alpha = max(0.0, min(1.0, _software_pbr_param_float(params, 'alpha', base_color[3] if len(base_color) > 3 else 1.0)))
    base_color = (base_color[0], base_color[1], base_color[2], alpha)
    accent_color = (accent_color[0], accent_color[1], accent_color[2], alpha)
    metallic = max(0.0, min(1.0, _software_pbr_param_float(params, 'metallic', 0.0)))
    roughness = max(0.0, min(1.0, _software_pbr_param_float(params, 'roughness', 0.5)))
    coat_weight = max(0.0, min(1.0, _software_pbr_param_float(params, 'coat_weight', 0.0)))
    coat_roughness = max(0.0, min(1.0, _software_pbr_param_float(params, 'coat_roughness', 0.08)))
    ior = max(1.0, min(2.5, _software_pbr_param_float(params, 'ior', 1.5)))
    transmission = max(0.0, min(1.0, _software_pbr_param_float(params, 'transmission', 0.0)))
    subsurface = max(0.0, min(1.0, _software_pbr_param_float(params, 'subsurface_weight', 0.0)))
    sheen = max(0.0, min(1.0, _software_pbr_param_float(params, 'sheen_weight', 0.0)))
    anisotropic = max(0.0, min(1.0, _software_pbr_param_float(params, 'anisotropic', 0.0)))
    micro_bump = max(0.0, min(0.2, _software_pbr_param_float(params, 'micro_bump', 0.018)))
    detail_scale = max(0.1, _software_pbr_param_float(params, 'detail_scale', 32.0))
    noise_strength = max(0.0, min(1.0, _software_pbr_param_float(params, 'noise_strength', 0.22)))
    emission_color = _software_pbr_param_color(params, 'emission_color', (0.0, 0.0, 0.0, 1.0))
    emission_strength = max(0.0, _software_pbr_param_float(params, 'emission_strength', 0.0))

    nt = ensure_material(material)
    base = new_rgb(nt, -1160, 260, base_color, 'Base Color')
    accent = new_rgb(nt, -1160, 80, accent_color, 'Accent Tint')
    _, mapping = add_mapping_chain(nt, -1460, -60, 'Software PBR')
    noise = create_node(nt, 'ShaderNodeTexNoise', -920, -80, 'Procedural Breakup')
    amp = new_math(nt, -680, -80, 'MULTIPLY', 'Breakup Amount')
    mix = new_mix_color(nt, -440, 160, 'Base/Accent Mix')
    bump = create_node(nt, 'ShaderNodeBump', -200, -120, 'Micro Bump')
    bsdf = create_node(nt, 'ShaderNodeBsdfPrincipled', 80, 100, 'Principled BSDF')
    out = new_output(nt, 390, 100, 'Material Output')

    link(nt, try_output(mapping, 'Vector'), try_input(noise, 'Vector'))
    set_socket_value(try_input(noise, 'Scale'), detail_scale)
    set_socket_value(try_input(noise, 'Detail'), 8.0)
    set_socket_value(try_input(noise, 'Roughness'), 0.58)
    link(nt, try_output(noise, 'Fac'), try_input(amp, 0))
    set_socket_value(try_input(amp, 1), noise_strength)
    link(nt, try_output(base, 'Color'), mix_color_a_input(mix))
    link(nt, try_output(accent, 'Color'), mix_color_b_input(mix))
    link(nt, try_output(amp, 'Value'), mix_color_fac_input(mix))
    link(nt, try_output(noise, 'Fac'), try_input(bump, 'Height'))
    set_socket_value(try_input(bump, 'Strength'), micro_bump)

    final_color_socket = _software_apply_look_nodes(nt, params, mix_color_output(mix), base_color, accent_color)
    link(nt, final_color_socket, principled_socket(bsdf, 'Base Color'))
    _set_principled_optional(bsdf, ('Metallic', 'Metalness'), metallic)
    _set_principled_optional(bsdf, 'Roughness', roughness)
    _set_principled_optional(bsdf, 'Alpha', alpha)
    _set_principled_optional(bsdf, 'IOR', ior)
    _set_principled_optional(bsdf, ('Coat Weight', 'Clearcoat'), coat_weight)
    _set_principled_optional(bsdf, ('Coat Roughness', 'Clearcoat Roughness'), coat_roughness)
    _set_principled_optional(bsdf, ('Transmission Weight', 'Transmission'), transmission)
    _set_principled_optional(bsdf, ('Subsurface Weight', 'Subsurface'), subsurface)
    _set_principled_optional(bsdf, ('Sheen Weight', 'Sheen'), sheen)
    _set_principled_optional(bsdf, ('Alpha',), alpha)
    _set_principled_optional(bsdf, ('Anisotropic IOR', 'Anisotropic'), anisotropic)
    if emission_strength > 0.0:
        _set_principled_optional(bsdf, ('Emission Color', 'Emission'), emission_color)
        _set_principled_optional(bsdf, ('Emission Strength',), emission_strength)
    link(nt, try_output(bump, 'Normal'), principled_socket(bsdf, 'Normal'))
    connect_surface(out, try_output(bsdf, 'BSDF'), nt)

    try:
        material.diffuse_color = base_color
    except Exception:
        pass
    if alpha < 0.999 or transmission > 0.0:
        for attr, value in (('blend_method', 'BLEND'), ('surface_render_method', 'BLENDED'), ('use_screen_refraction', True)):
            try:
                setattr(material, attr, value)
            except Exception:
                pass
    finalize_material(material, preset_id, params)


def _make_software_pbr_builder(preset_id):
    def _builder(material, params=None, _preset_id=preset_id):
        return build_software_pbr_variant(material, _preset_id, params=params)
    try:
        _builder.__name__ = f'build_{str(preset_id).lower()}'
    except Exception:
        pass
    return _builder

try:
    BUILDERS.update({preset_id: _make_software_pbr_builder(preset_id) for preset_id in getattr(data, 'SOFTWARE_PBR_DEFAULTS', {}).keys()})
except Exception:
    pass
