"""Read-only bounded metadata audit for oversized Smart Toon signatures.

This module never prints, copies, hashes, or returns signature contents.
Run it only in an explicitly admitted isolated Blender process.
"""

from __future__ import annotations

SIGNATURE_KEYS = (
    "_smart_toon_structure_signature",
    "_jel_pencil_toon_structure_signature",
)
THRESHOLD_CHARS = 1024 * 1024
MAX_DETAIL_ROWS = 64
SCANNED_COLLECTIONS = (
    ("Material", "materials"),
    ("NodeTree", "node_groups"),
    ("Object", "objects"),
    ("Scene", "scenes"),
    ("World", "worlds"),
)
UNSCANNED_ID_TYPES = (
    "Action", "Armature", "Brush", "Collection", "Curve", "GreasePencil",
    "Image", "Light", "Mesh", "MovieClip", "Sound", "Text", "Texture",
)


def _owner_classification(owner, id_type: str) -> str:
    try:
        if getattr(owner, "library", None) is not None or bool(getattr(owner, "is_library_indirect", False)):
            return "linked_read_only"
        if hasattr(owner, "is_editable") and not bool(owner.is_editable):
            return "local_read_only"
        if id_type != "Material":
            return "foreign_property_owner"
        if not bool(owner.get("smart_toon_shader") or owner.get("jel_pencil_toon_shader")):
            return "foreign_material_property"
        return "local_writable_smart_toon"
    except Exception:
        return "unreadable_owner"


def audit_oversized_structure_signatures(bpy_module=None, *, max_rows: int = MAX_DETAIL_ROWS):
    if bpy_module is None:
        import bpy as bpy_module
    max_rows = max(0, min(int(max_rows), MAX_DETAIL_ROWS))
    result = {
        "schema": "smartshader.structure-signature-audit.v1",
        "threshold_chars": THRESHOLD_CHARS,
        "oversized_count": 0,
        "malformed_count": 0,
        "detail_rows": [],
        "detail_rows_truncated": False,
        "scanned_id_types": [name for name, _collection in SCANNED_COLLECTIONS],
        "unscanned_id_types": list(UNSCANNED_ID_TYPES),
        "mutated": False,
    }
    for id_type, collection_name in SCANNED_COLLECTIONS:
        collection = getattr(getattr(bpy_module, "data", None), collection_name, ()) or ()
        for owner in collection:
            for key in SIGNATURE_KEYS:
                try:
                    if key not in owner:
                        continue
                    value = owner.get(key, None)
                    is_string = isinstance(value, str)
                    length = len(value) if is_string else -1
                    del value
                except Exception:
                    is_string = False
                    length = -1
                if not is_string:
                    result["malformed_count"] += 1
                    category = "malformed"
                elif length > THRESHOLD_CHARS:
                    result["oversized_count"] += 1
                    category = "oversized"
                else:
                    continue
                if len(result["detail_rows"]) < max_rows:
                    result["detail_rows"].append({
                        "id_type": id_type,
                        "owner": str(getattr(owner, "name_full", getattr(owner, "name", "")) or "")[:256],
                        "property_path": key,
                        "character_length": int(length),
                        "category": category,
                        "ownership": _owner_classification(owner, id_type),
                    })
                else:
                    result["detail_rows_truncated"] = True
    return result


__all__ = ("audit_oversized_structure_signatures",)
