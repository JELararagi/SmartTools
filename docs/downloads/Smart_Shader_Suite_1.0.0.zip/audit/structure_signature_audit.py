# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only report of Smart Toon metadata that needs migration."""

SIGNATURE_KEYS = tuple(f"_{prefix}_structure_signature"
                       for prefix in ("smart_toon", "jel_pencil_toon"))
THRESHOLD_CHARS = 2 ** 20
MAX_DETAIL_ROWS = 64
SCANNED_COLLECTIONS = (
    ("Material", "materials"), ("NodeTree", "node_groups"), ("Object", "objects"),
    ("Scene", "scenes"), ("World", "worlds"),
)
UNSCANNED_ID_TYPES = (
    "Action", "Armature", "Brush", "Collection", "Curve", "GreasePencil",
    "Image", "Light", "Mesh", "MovieClip", "Sound", "Text", "Texture",
)
__all__ = ("audit_oversized_structure_signatures",)


def _ownership(owner, data_type):
    try:
        if getattr(owner, "library", None) or getattr(owner, "is_library_indirect", False):
            return "linked_read_only"
        if not getattr(owner, "is_editable", True):
            return "local_read_only"
        if data_type != "Material":
            return "foreign_property_owner"
        if owner.get("smart_toon_shader") or owner.get("jel_pencil_toon_shader"):
            return "local_writable_smart_toon"
        return "foreign_material_property"
    except Exception:
        return "unreadable_owner"


def _problem(owner, key):
    try:
        if key not in owner:
            return None
        raw = owner.get(key)
        length = len(raw) if isinstance(raw, str) else -1
    except Exception:
        length = -1
    if length < 0:
        return "malformed", length
    if length > THRESHOLD_CHARS:
        return "oversized", length
    return None


def audit_oversized_structure_signatures(bpy_module=None, *, max_rows=MAX_DETAIL_ROWS):
    if bpy_module is None:
        import bpy as bpy_module
    limit = min(MAX_DETAIL_ROWS, max(0, int(max_rows)))
    counts = dict.fromkeys(("malformed_count", "oversized_count"), 0)
    details = []
    data = getattr(bpy_module, "data", None)
    for data_type, collection in SCANNED_COLLECTIONS:
        for owner in getattr(data, collection, ()) or ():
            for key in SIGNATURE_KEYS:
                problem = _problem(owner, key)
                if problem is None:
                    continue
                category, length = problem
                counts[f"{category}_count"] += 1
                if len(details) == limit:
                    continue
                details.append({
                    "id_type": data_type,
                    "owner": str(getattr(owner, "name_full", getattr(owner, "name", "")) or "")[:256],
                    "property_path": key,
                    "character_length": length,
                    "category": category,
                    "ownership": _ownership(owner, data_type),
                })
    return {
        "schema": "smartshader.structure-signature-audit.v1",
        "threshold_chars": THRESHOLD_CHARS,
        **counts,
        "detail_rows": details,
        "detail_rows_truncated": sum(counts.values()) > len(details),
        "scanned_id_types": [data_type for data_type, _ in SCANNED_COLLECTIONS],
        "unscanned_id_types": list(UNSCANNED_ID_TYPES),
        "mutated": False,
    }
