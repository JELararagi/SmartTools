# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Non-resident compatibility surface for historical proxy cleanup.

Legacy builds used periodic broad data scans.  This version deliberately performs
no automatic scan or prefix/name-based deletion.  Existing user, foreign, linked,
and old-generation data is left unchanged unless a future explicit migration can
prove exact owner UUID, suite ID, generation, and Python/RNA identity.
"""

from __future__ import annotations

from typing import Any

_REGISTERED = False
_EMPTY_REPORT = {
    "objects": 0,
    "meshes": 0,
    "collections": 0,
    "materials": 0,
    "node_groups": 0,
    "properties": 0,
}


def cleanup_legacy_proxy_data(reason: str = "manual") -> dict[str, Any]:
    """Return a bounded no-op report; never inspect or delete broad bpy.data sets."""
    report = dict(_EMPTY_REPORT)
    report["reason"] = str(reason or "manual")
    report["status"] = "NO_EXACT_OWNERSHIP_MANIFEST"
    return report


def _run_timer_cleanup():
    return None


def _schedule_cleanup(delay: float = 0.0) -> None:
    del delay
    return None


def register() -> None:
    """Compatibility toggle; no handler, timer, worker, or watcher is installed."""
    global _REGISTERED
    _REGISTERED = True


def unregister() -> None:
    global _REGISTERED
    _REGISTERED = False
