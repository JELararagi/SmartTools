# SPDX-License-Identifier: GPL-3.0-or-later
"""Keep historical entry points without touching unowned Blender data."""

_REGISTERED = False
_REPORTED_ID_TYPES = ("objects", "meshes", "collections", "materials", "node_groups", "properties")


def cleanup_legacy_proxy_data(reason="manual"):
    return dict.fromkeys(_REPORTED_ID_TYPES, 0) | {
        "reason": str(reason or "manual"),
        "status": "NO_EXACT_OWNERSHIP_MANIFEST",
    }


def _run_timer_cleanup():
    """No deferred cleanup is scheduled."""


def _schedule_cleanup(delay=0.0):
    """Leave existing data alone when compatibility callers request a scan."""


def register():
    global _REGISTERED
    _REGISTERED = True


def unregister():
    global _REGISTERED
    _REGISTERED = False
