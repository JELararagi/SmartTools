# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Idle-zero compatibility surface for legacy Smart Shader status hooks.

The suite no longer replaces Blender registration, timer, handler, msgbus or draw
APIs.  These functions remain as bounded, non-resident compatibility shims for
callers that still import the historical status module.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Dict, Optional
import time
import uuid

_DEFAULT_TRANSIENT_SECONDS = 0.0
_ENTRIES: dict[str, dict[str, Any]] = {}
_MAX_ENTRIES = 64


def _new_state():
    return {'entries': _ENTRIES, 'resident_resources': 0, 'timer_registered': False}


def _state():
    return _new_state()


def _now():
    return time.monotonic()


def _on_main_thread():
    return True


def _workspace_candidates(context=None):
    del context
    return ()


def _remove_expired_locked(state: Dict[str, Any], now: Optional[float] = None):
    del state, now
    return 0


def _top_entry_locked(state: Dict[str, Any]):
    del state
    return None


def _publish_locked(state: Dict[str, Any], context=None):
    del state, context
    return None


def _next_delay_locked(state: Dict[str, Any]):
    del state
    return None


def _shared_timer():
    return None


def _ensure_timer_locked(state: Dict[str, Any]):
    del state
    return None


def _upsert(key: str, owner: str, text: str, *, priority: int, duration: Optional[float], kind: str, context=None):
    del priority, duration, context
    token = str(key or uuid.uuid4())
    _ENTRIES[token] = {'owner': str(owner or ''), 'text': str(text or '')[:240], 'kind': str(kind or '')}
    while len(_ENTRIES) > _MAX_ENTRIES:
        _ENTRIES.pop(next(iter(_ENTRIES)))
    return token


def set_transient(owner: str, text: str, duration: float = _DEFAULT_TRANSIENT_SECONDS, *, context=None):
    return _upsert(f'transient:{owner}', owner, text, priority=0, duration=duration, kind='transient', context=context)


def set_service(owner: str, text: str, *, context=None):
    return _upsert(f'service:{owner}', owner, text, priority=0, duration=None, kind='service', context=context)


def begin_task(owner: str, text: str, *, context=None):
    return _upsert(str(uuid.uuid4()), owner, text, priority=0, duration=None, kind='task', context=context)


def update_task(token: str, text: str, *, context=None):
    del context
    entry = _ENTRIES.get(str(token))
    if entry is not None:
        entry['text'] = str(text or '')[:240]
    return token


def finish_task(token: str, final_text: Optional[str] = None, duration: float = 0.12, *, context=None):
    del duration, context
    if final_text:
        update_task(token, final_text)
    _ENTRIES.pop(str(token), None)
    return None


def _cancel_timer_if_idle_locked(state: Dict[str, Any]):
    del state
    return None


def clear(owner_or_token: str, *, context=None):
    del context
    token = str(owner_or_token or '')
    _ENTRIES.pop(token, None)
    for key in tuple(_ENTRIES):
        if str(_ENTRIES[key].get('owner', '')) == token:
            _ENTRIES.pop(key, None)
    return None


def clear_prefix(prefix: str, *, context=None):
    del context
    prefix = str(prefix or '')
    for key in tuple(_ENTRIES):
        entry = _ENTRIES.get(key, {})
        if key.startswith(prefix) or str(entry.get('owner', '')).startswith(prefix):
            _ENTRIES.pop(key, None)
    return None


def clear_all(*, context=None):
    del context
    _ENTRIES.clear()
    return None


def snapshot():
    return {'entries': tuple((k, dict(v)) for k, v in _ENTRIES.items()), 'resident_resources': 0}


@contextmanager
def task_scope(owner: str, text: str, *, context=None, completed_text: Optional[str] = None, error_prefix: Optional[str] = None):
    del error_prefix
    token = begin_task(owner, text, context=context)
    try:
        yield token
    finally:
        finish_task(token, completed_text, context=context)


def _is_japanese(context=None):
    del context
    return False


def _translated_label(value: str):
    return str(value or '')


def _humanize_identifier(value: str):
    return str(value or '').replace('_', ' ').strip()


def _default_operator_description(cls, suite_label: str):
    del cls, suite_label
    return ""


def _default_property_description(display_name: str, property_kind: str):
    del display_name, property_kind
    return ""


def _ensure_rna_class_tooltips(cls, suite_label: str):
    del suite_label
    return cls


def _operator_status_text(suite_label: str, operator_label: str, phase: str, context=None):
    del context
    return f'{suite_label}: {operator_label}: {phase}'


def _result_has(result, value: str):
    try:
        return str(value) in result
    except Exception:
        return False


def instrument_operator_class(cls, suite_id: str, suite_label: str):
    del suite_id, suite_label
    return cls


def _iter_operator_subclasses():
    return ()


def instrument_loaded_package_operators(package_marker: str, suite_id: str, suite_label: str):
    del package_marker, suite_id, suite_label
    return 0


def _callback_display_name(callback):
    return str(getattr(callback, '__name__', callback))


def _suite_registration_active(suite_id: str):
    del suite_id
    return False


def _active_resource_context(state=None):
    del state
    return None


def _is_internal_status_timer(callback):
    del callback
    return False


def _resource_status_text(suite_label: str, callback, kind_en: str, kind_ja: str, *, active=False):
    del kind_ja, active
    return f'{suite_label}: {kind_en}: {_callback_display_name(callback)}'


def _timer_record_for(callback, state=None, suite_id=None):
    del callback, state, suite_id
    return None


def _native_timer_apis(state=None):
    del state
    return (None, None, None)


def _cancel_resource_monitor_if_idle(state=None):
    del state
    return None


def _drop_timer_record(record, *, clear_status=True):
    del record, clear_status
    return None


def _resource_monitor_timer():
    return None


def _ensure_resource_monitor(state=None, *, native_register=None, native_is_registered=None):
    del state, native_register, native_is_registered
    return None


def _captured_timer_register(function, *args, **kwargs):
    del args, kwargs
    return function


def _captured_timer_unregister(function):
    del function
    return None


def _captured_timer_is_registered(function):
    del function
    return False


def _draw_boundary_handler_lists():
    return ()


def _global_draw_boundary_begin(*_args):
    return None


def _global_draw_boundary_end(*_args):
    return None


def _ensure_global_draw_boundary_handlers():
    return None


def _remove_global_draw_boundary_handlers_if_unused():
    return None


def _draw_callback_execution_safe(record=None):
    del record
    return True


def _discover_draw_space_classes(state):
    del state
    return ()


def _drop_draw_record(record, *, clear_status=True):
    del record, clear_status
    return None


def _refresh_draw_record(record):
    return record


def _make_draw_callback_wrapper(record):
    return record


def _make_captured_draw_add(space_name, original_add):
    del space_name
    return original_add


def _make_captured_draw_remove(space_name, original_remove):
    del space_name
    return original_remove


def _install_resource_api_capture(state):
    del state
    return None


def _restore_one_draw_api(cls, name, owned, raw_value, fallback):
    del cls, name, owned, raw_value
    return fallback


def _restore_resource_api_capture(state):
    del state
    return None


@contextmanager
def capture_runtime_resources(suite_id: str, suite_label: str):
    del suite_id, suite_label
    yield None


def _cleanup_resource_records(prefix: str):
    del prefix
    return None


def _callback_invocation_adapter(callback):
    return callback


def _adapt_callback_invocation(args, kwargs, adapter):
    del adapter
    return args, kwargs


def _run_callback_with_status(callback, args, kwargs, *, owner: str, suite_label: str, kind_en: str, kind_ja: str):
    del owner, suite_label, kind_en, kind_ja
    return callback(*args, **kwargs)


def _increment_stat(suite_id: str, key: str, amount: int = 1):
    del suite_id, key, amount
    return None


def _wrap_property_callback(callback, suite_id: str, suite_label: str, callback_kind: str):
    del suite_id, suite_label, callback_kind
    return callback


def _wrap_msgbus_notify(callback, suite_id: str, suite_label: str):
    del suite_id, suite_label
    return callback


@contextmanager
def capture_registration_callbacks(suite_id: str, suite_label: str):
    del suite_id, suite_label
    yield None


def _handler_lists():
    return ()


def _make_persistent_handler_status_marker(callback, owner: str, handler_name: str, suite_label: str, handler_list):
    del owner, handler_name, suite_label, handler_list
    return callback


class _HandlerStatusProxy:
    def __init__(self, callback=None):
        self.callback = callback

    def __call__(self, *args, **kwargs):
        if callable(self.callback):
            return self.callback(*args, **kwargs)
        return None


def prune_orphan_persistent_handler_markers(suite_id: Optional[str] = None):
    del suite_id
    return 0


def _restore_missing_persistent_handler_markers():
    return 0


def _global_persistent_handler_prune_load_post(_filepath=None, *_args):
    return None


def _ensure_global_persistent_handler_prune_callback():
    return None


def _remove_global_persistent_handler_prune_if_unused():
    return None


def instrument_loaded_package_handlers(package_marker: str, suite_id: str, suite_label: str):
    del package_marker, suite_id, suite_label
    return 0


def restore_package_handlers(suite_id: str):
    del suite_id
    return 0
