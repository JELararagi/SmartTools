# SPDX-License-Identifier: GPL-3.0-or-later
"""Scope transform restoration to an explicit Smart Shader operation."""

from contextlib import contextmanager
from dataclasses import dataclass

import bpy


_REPORT = "SMART_SHADER_SUITE_TRANSFORM_GUARD_LAST_REPORT"
_CHANNELS = (
    "location", "rotation_euler", "rotation_quaternion", "rotation_axis_angle",
    "scale", "delta_location", "delta_rotation_euler", "delta_rotation_quaternion",
    "delta_scale",
)
_TOLERANCE = 1e-6


@dataclass(frozen=True)
class _Transform:
    reference: bpy.types.Object
    mode: str
    channels: tuple
    parent_inverse: tuple


def _objects_in_scope(objects):
    if objects is not None:
        return tuple(objects)
    scene = bpy.context.scene
    return tuple(scene.objects) if scene else ()


def _writable(obj):
    try:
        return obj is not None and obj.library is None and obj.mode == "OBJECT"
    except ReferenceError:
        return False


def _capture(obj):
    return _Transform(
        obj, obj.rotation_mode, tuple(tuple(getattr(obj, name)) for name in _CHANNELS),
        tuple(tuple(row) for row in obj.matrix_parent_inverse),
    )


def snapshot_scene_object_transforms(objects=None):
    return {obj.as_pointer(): _capture(obj) for obj in _objects_in_scope(objects) if _writable(obj)}


def _differs(current, previous):
    return any(abs(a - b) > _TOLERANCE for a, b in zip(current, previous))


def _restore(obj, saved):
    changed = obj.rotation_mode != saved.mode
    if changed:
        obj.rotation_mode = saved.mode
    for name, value in zip(_CHANNELS, saved.channels):
        if _differs(getattr(obj, name), value):
            setattr(obj, name, value)
            changed = True
    if any(_differs(a, b) for a, b in zip(obj.matrix_parent_inverse, saved.parent_inverse)):
        obj.matrix_parent_inverse = saved.parent_inverse
        changed = True
    return changed


def restore_scene_object_transforms(snapshot, *, reason="", objects=None):
    if not snapshot:
        return 0
    restored = 0
    for obj in _objects_in_scope(objects):
        if not _writable(obj):
            continue
        saved = snapshot.get(obj.as_pointer())
        if saved is not None and saved.reference == obj:
            restored += int(_restore(obj, saved))
    if restored:
        bpy.app.driver_namespace[_REPORT] = {
            "restored_objects": restored, "reason": str(reason), "filepath": bpy.data.filepath,
        }
    return restored


@contextmanager
def preserve_object_transforms(reason="", objects=None):
    selection = tuple(objects) if objects is not None else None
    before = snapshot_scene_object_transforms(selection)
    try:
        yield
    finally:
        restore_scene_object_transforms(before, reason=reason, objects=selection)


def register():
    return None


def unregister():
    bpy.app.driver_namespace.pop(_REPORT, None)
