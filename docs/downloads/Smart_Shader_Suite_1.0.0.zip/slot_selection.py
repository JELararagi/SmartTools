# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Shared material-target slot selection helpers for Smart Shader Suite."""

from __future__ import annotations

import bpy
from . import core
from .translation import tx, loc_text as _lt

_MATERIAL_TARGET_SLOT_ITEMS: list[tuple] = []
_MATERIAL_TARGET_SLOT_MAP: dict[str, int] = {}
_MULTI_SLOT_DIALOG_ATTR = "_sss_multi_material_target_slot_prompt_active"
_MULTI_SLOT_DRAW_WRAPPED_ATTR = "_sss_multi_material_target_slot_draw_wrapped"
_MULTI_SLOT_ORIGINAL_DRAW_ATTR = "_sss_multi_material_target_slot_original_draw"
_SCENE_MULTI_SLOT_COLLECTION = "sss_material_target_object_slots"


def material_slot_capable_object(context):
    obj = getattr(context, "object", None) or getattr(context, "active_object", None)
    if obj is None:
        return None
    data_block = getattr(obj, "data", None)
    if data_block is None or not hasattr(data_block, "materials"):
        return None
    return obj


def material_slot_count(context, obj=None) -> int:
    obj = obj or material_slot_capable_object(context)
    if obj is None:
        return 0
    try:
        return len(getattr(obj, "material_slots", ()) or ())
    except Exception:
        try:
            return len(getattr(getattr(obj, "data", None), "materials", ()) or ())
        except Exception:
            return 0


def target_material_objects(context, *, assign_selected: bool=True) -> list:
    try:
        return core.selected_material_target_objects(context, assign_selected=assign_selected)
    except Exception:
        obj = material_slot_capable_object(context)
        return [obj] if obj is not None else []


def _object_from_slot_item(item):
    obj = None
    try:
        obj = getattr(item, "object_ref", None)
    except Exception:
        obj = None
    if obj is None:
        try:
            name = str(getattr(item, "object_name", "") or "")
            obj = bpy.data.objects.get(name) if name else None
        except Exception:
            obj = None
    return obj


def _slot_token_from_index(index: int) -> str:
    try:
        return f"SLOT_{max(0, int(index)):03d}"
    except Exception:
        return "SLOT_000"


def _slot_index_from_token(token: str, fallback: int=0) -> int:
    token = str(token or "")
    if token.startswith("SLOT_"):
        try:
            return max(0, int(token.split("_", 1)[1]))
        except Exception:
            return max(0, int(fallback or 0))
    try:
        return max(0, int(token))
    except Exception:
        return max(0, int(fallback or 0))


def object_material_slot_items(self, context):
    scene = getattr(context, "scene", None) if context is not None else None
    obj = _object_from_slot_item(self)
    items: list[tuple] = []
    if obj is not None:
        try:
            slots = getattr(obj, "material_slots", ()) or ()
        except Exception:
            slots = ()
        for index, slot in enumerate(slots):
            try:
                material = slot.material
            except Exception:
                material = None
            mat_name = str(getattr(material, "name", "") or tx(scene, "Empty", "空"))
            token = _slot_token_from_index(index)
            label = f"{index + 1}: {mat_name}"
            desc = tx(
                scene,
                f"Apply the generated material to {obj.name}'s slot {index + 1}. Current material: {mat_name}.",
                f"生成したマテリアルを {obj.name} の {index + 1} 番スロットへ適用します。現在のマテリアル: {mat_name}。",
            )
            items.append((token, label, desc, "MATERIAL", index))
    if not items:
        items.append((
            "SLOT_000",
            tx(scene, "1: New slot", "1: 新規スロット"),
            tx(scene, "Create the first material slot and apply the generated material there.", "最初のマテリアルスロットを作成し、生成したマテリアルをそこへ適用します。"),
            "MATERIAL",
            0,
        ))
    return items


def _on_object_slot_token_update(self, context):
    obj = _object_from_slot_item(self)
    try:
        idx = _slot_index_from_token(getattr(self, "slot_token", ""), getattr(self, "slot_index", 0))
    except Exception:
        idx = 0
    try:
        self.slot_index = idx
    except Exception:
        pass
    try:
        core.set_material_target_slot_index_on_object(obj, idx)
    except Exception:
        pass


class SSS_PG_material_target_object_slot(bpy.types.PropertyGroup):
    object_name: bpy.props.StringProperty(options={"SKIP_SAVE", "HIDDEN"})
    object_ref: bpy.props.PointerProperty(type=bpy.types.Object, options={"SKIP_SAVE", "HIDDEN"})
    slot_index: bpy.props.IntProperty(default=0, min=0, options={"SKIP_SAVE", "HIDDEN"})
    slot_token: bpy.props.EnumProperty(
        name=_lt("Apply Slot", "適用スロット"),
        description=_lt(
            "Choose the material slot on this selected object that receives the generated material.",
            "この選択オブジェクト上で、生成したマテリアルを受け取るマテリアルスロットを選択します。",
        ),
        items=object_material_slot_items,
        update=_on_object_slot_token_update,
        options={"SKIP_SAVE"},
    )


CLASSES = (SSS_PG_material_target_object_slot,)


def _scene_has_multi_slot_collection(scene) -> bool:
    if scene is None:
        return False
    try:
        return hasattr(scene, _SCENE_MULTI_SLOT_COLLECTION)
    except Exception:
        return False


def prepare_selected_material_target_slots(context, *, assign_selected: bool=True) -> int:
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None or not _scene_has_multi_slot_collection(scene):
        return 0
    collection = getattr(scene, _SCENE_MULTI_SLOT_COLLECTION)
    try:
        collection.clear()
    except Exception:
        pass
    count = 0
    for obj in target_material_objects(context, assign_selected=assign_selected):
        try:
            item = collection.add()
        except Exception:
            continue
        try:
            item.object_ref = obj
        except Exception:
            pass
        try:
            item.object_name = str(getattr(obj, "name", "") or "")
        except Exception:
            pass
        try:
            idx = core.selected_material_slot_index(context, obj)
        except Exception:
            idx = 0
        try:
            item.slot_index = idx
            item.slot_token = _slot_token_from_index(idx)
        except Exception:
            pass
        count += 1
    return count


def apply_selected_material_target_slots(context) -> int | None:
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None or not _scene_has_multi_slot_collection(scene):
        return None
    active_index = None
    active_obj = getattr(context, "object", None) or getattr(context, "active_object", None)
    try:
        collection = list(getattr(scene, _SCENE_MULTI_SLOT_COLLECTION) or [])
    except Exception:
        collection = []
    for item in collection:
        obj = _object_from_slot_item(item)
        if obj is None:
            continue
        idx = _slot_index_from_token(getattr(item, "slot_token", ""), getattr(item, "slot_index", 0))
        try:
            idx = core.set_material_target_slot_index_on_object(obj, idx)
        except Exception:
            pass
        if obj == active_obj:
            active_index = idx
    if active_index is not None:
        try:
            scene.sss_material_target_slot_index = int(active_index)
        except Exception:
            pass
    return active_index


def draw_selected_material_target_slots(layout, context) -> None:
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None or not _scene_has_multi_slot_collection(scene):
        return
    try:
        if len(getattr(scene, _SCENE_MULTI_SLOT_COLLECTION)) == 0:
            prepare_selected_material_target_slots(context, assign_selected=True)
    except Exception:
        pass
    layout.label(text=tx(scene, "Choose material slots for selected objects", "選択オブジェクトごとの適用スロットを選択"), icon="MATERIAL")
    col = layout.column(align=True)
    try:
        collection = list(getattr(scene, _SCENE_MULTI_SLOT_COLLECTION) or [])
    except Exception:
        collection = []
    for item in collection:
        obj = _object_from_slot_item(item)
        if obj is None:
            continue
        name = str(getattr(obj, "name", "") or tx(scene, "Object", "オブジェクト"))
        slot_count = material_slot_count(context, obj)
        box = col.box()
        row = box.row(align=True)
        row.label(text=name, icon="OBJECT_DATA", translate=False)
        if slot_count > 1:
            row.prop(item, "slot_token", text="")
        elif slot_count == 1:
            row.label(text=core.material_slot_label(obj, 0, empty_label=tx(scene, "Empty", "空")), icon="MATERIAL")
        else:
            row.label(text=tx(scene, "1: New slot", "1: 新規スロット"), icon="ADD")


def _has_selected_multi_object_slot_choice(context, *, assign_selected: bool | None=None) -> bool:
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return False
    # Multiple-object generation must apply to all selected objects even when
    # the legacy scene toggle was off, so the slot dialog treats this as enabled.
    if assign_selected is None:
        try:
            assign_selected = bool(getattr(scene, "sss_assign_selected", True))
        except Exception:
            assign_selected = True
    if not bool(assign_selected):
        return False
    try:
        if str(core.assign_mode(context) or "ACTIVE_SLOT") != "ACTIVE_SLOT":
            return False
    except Exception:
        return False
    targets = target_material_objects(context, assign_selected=True)
    if len(targets) <= 1:
        return False
    return any(material_slot_count(context, obj) > 1 for obj in targets)


def _install_multi_slot_dialog_draw(operator) -> None:
    cls = operator.__class__
    if getattr(cls, _MULTI_SLOT_DRAW_WRAPPED_ATTR, False):
        return
    original_draw = getattr(cls, "draw", None)
    try:
        setattr(cls, _MULTI_SLOT_ORIGINAL_DRAW_ATTR, original_draw)
    except Exception:
        pass

    def draw(self, context):
        try:
            if bool(getattr(self, _MULTI_SLOT_DIALOG_ATTR, False)):
                draw_selected_material_target_slots(self.layout, context)
                return
        except Exception:
            pass
        original = getattr(self.__class__, _MULTI_SLOT_ORIGINAL_DRAW_ATTR, None)
        if callable(original):
            return original(self, context)
        return None

    try:
        cls.draw = draw
        setattr(cls, _MULTI_SLOT_DRAW_WRAPPED_ATTR, True)
    except Exception:
        pass


def material_target_slot_items(self, context):
    global _MATERIAL_TARGET_SLOT_ITEMS, _MATERIAL_TARGET_SLOT_MAP
    scene = getattr(context, "scene", None) if context is not None else None
    obj = material_slot_capable_object(context)
    items: list[tuple] = []
    mapping: dict[str, int] = {}
    if obj is not None:
        try:
            slots = getattr(obj, "material_slots", ()) or ()
        except Exception:
            slots = ()
        for index, slot in enumerate(slots):
            try:
                material = slot.material
            except Exception:
                material = None
            mat_name = str(getattr(material, "name", "") or tx(scene, "Empty", "空"))
            token = _slot_token_from_index(index)
            label = f"{index + 1}: {mat_name}"
            desc = tx(
                scene,
                f"Apply the generated material to slot {index + 1}. Current material: {mat_name}.",
                f"生成したマテリアルを {index + 1} 番スロットへ適用します。現在のマテリアル: {mat_name}。",
            )
            items.append((token, label, desc, "MATERIAL", index))
            mapping[token] = index
    if not items:
        token = "SLOT_000"
        mapping[token] = 0
        items.append((
            token,
            tx(scene, "1: Empty", "1: 空"),
            tx(scene, "Apply the generated material to the first material slot.", "生成したマテリアルを最初のマテリアルスロットへ適用します。"),
            "MATERIAL",
            0,
        ))
    _MATERIAL_TARGET_SLOT_ITEMS = items
    _MATERIAL_TARGET_SLOT_MAP = mapping
    return _MATERIAL_TARGET_SLOT_ITEMS


def token_for_index(index: int) -> str:
    token = _slot_token_from_index(index)
    if token in _MATERIAL_TARGET_SLOT_MAP:
        return token
    return next(iter(_MATERIAL_TARGET_SLOT_MAP), "SLOT_000")


def selected_token(context) -> str:
    obj = material_slot_capable_object(context)
    material_target_slot_items(None, context)
    try:
        index = core.selected_material_slot_index(context, obj)
    except Exception:
        index = 0
    return token_for_index(index)


def set_scene_target_slot_index(context, index: int) -> int:
    try:
        idx = max(0, int(index))
    except Exception:
        idx = 0
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is not None:
        try:
            scene.sss_material_target_slot_index = idx
        except Exception:
            pass
    obj = material_slot_capable_object(context)
    if obj is not None:
        try:
            idx = core.set_material_target_slot_index_on_object(obj, idx)
        except Exception:
            try:
                count = material_slot_count(context, obj)
                if count > 0:
                    obj.active_material_index = max(0, min(count - 1, idx))
            except Exception:
                pass
    return idx


def operator_slot_property_is_active(operator, attr: str = "sss_target_slot_token") -> bool:
    try:
        if bool(getattr(operator, _MULTI_SLOT_DIALOG_ATTR, False)):
            return True
    except Exception:
        pass
    marker = f"{attr}_initialized"
    try:
        if bool(getattr(operator, marker, False)):
            return True
    except Exception:
        pass
    checker = getattr(operator, "is_property_set", None)
    if callable(checker):
        try:
            return bool(checker(attr))
        except Exception:
            pass
    props = getattr(operator, "properties", None)
    checker = getattr(props, "is_property_set", None)
    if callable(checker):
        try:
            return bool(checker(attr))
        except Exception:
            pass
    return False


def apply_operator_material_target_slot(operator, context, attr: str = "sss_target_slot_token") -> int | None:
    try:
        if bool(getattr(operator, _MULTI_SLOT_DIALOG_ATTR, False)):
            result = apply_selected_material_target_slots(context)
            try:
                setattr(operator, _MULTI_SLOT_DIALOG_ATTR, False)
            except Exception:
                pass
            return result
    except Exception:
        pass
    if not operator_slot_property_is_active(operator, attr=attr):
        return None
    token = str(getattr(operator, attr, "") or "")
    if not token:
        return None
    material_target_slot_items(operator, context)
    index = _MATERIAL_TARGET_SLOT_MAP.get(token)
    if index is None:
        index = _slot_index_from_token(token, 0)
    return set_scene_target_slot_index(context, index)


def init_operator_material_target_slot(operator, context, attr: str = "sss_target_slot_token") -> str:
    token = selected_token(context)
    try:
        setattr(operator, attr, token)
    except Exception:
        pass
    try:
        setattr(operator, f"{attr}_initialized", True)
    except Exception:
        pass
    return token


def needs_material_target_slot_choice(context, *, assign_selected: bool | None = None) -> bool:
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return False
    if assign_selected is None:
        try:
            assign_selected = bool(getattr(scene, "sss_assign_selected", True))
        except Exception:
            assign_selected = True
    if not bool(assign_selected):
        return False
    try:
        if str(core.assign_mode(context) or "ACTIVE_SLOT") != "ACTIVE_SLOT":
            return False
    except Exception:
        return False
    if _has_selected_multi_object_slot_choice(context, assign_selected=assign_selected):
        return True
    return material_slot_count(context) > 1


def invoke_operator_material_target_slot_search(operator, context, *, assign_selected: bool | None = None, attr: str = "sss_target_slot_token"):
    if not needs_material_target_slot_choice(context, assign_selected=assign_selected):
        return None
    wm = getattr(context, "window_manager", None) if context is not None else None
    if _has_selected_multi_object_slot_choice(context, assign_selected=assign_selected):
        prepare_selected_material_target_slots(context, assign_selected=True)
        try:
            setattr(operator, _MULTI_SLOT_DIALOG_ATTR, True)
        except Exception:
            pass
        _install_multi_slot_dialog_draw(operator)
        if wm is None:
            apply_operator_material_target_slot(operator, context, attr=attr)
            return None
        try:
            wm.invoke_props_dialog(operator, width=680)
            return {"RUNNING_MODAL"}
        except Exception:
            apply_operator_material_target_slot(operator, context, attr=attr)
            return None
    init_operator_material_target_slot(operator, context, attr=attr)
    if wm is None:
        apply_operator_material_target_slot(operator, context, attr=attr)
        return None
    try:
        wm.invoke_search_popup(operator)
        return {"RUNNING_MODAL"}
    except Exception:
        apply_operator_material_target_slot(operator, context, attr=attr)
        return None


def draw_operator_material_target_slot(layout, operator, context, attr: str = "sss_target_slot_token") -> None:
    scene = getattr(context, "scene", None) if context is not None else None
    try:
        if bool(getattr(operator, _MULTI_SLOT_DIALOG_ATTR, False)) or _has_selected_multi_object_slot_choice(context, assign_selected=True):
            draw_selected_material_target_slots(layout, context)
            return
    except Exception:
        pass
    try:
        layout.label(text=tx(scene, "Choose the target material slot", "適用先マテリアルスロットを選択"), icon="MATERIAL")
        layout.prop(operator, attr, text=tx(scene, "Apply Slot", "適用スロット"))
    except Exception:
        pass


MATERIAL_TARGET_SLOT_PROPERTY_KWARGS = dict(
    name=_lt("Apply Slot", "適用スロット"),
    description=_lt(
        "Choose which material slot receives the generated or applied material. With several selected objects, choose a separate slot for each selected object in the popup.",
        "生成または適用したマテリアルを受け取るマテリアルスロットを選択します。複数オブジェクト選択時は、ポップアップ内で各選択オブジェクトごとのスロットを指定します。",
    ),
    items=material_target_slot_items,
    options={"SKIP_SAVE"},
)


_REGISTERED_SLOT_CLASSES: list[type] = []


def _slot_class_has_own_bl_rna(cls: type) -> bool:
    try:
        rna = vars(cls).get("bl_rna") or getattr(cls, "bl_rna", None)
        identifier = str(getattr(rna, "identifier", "") or "")
        inherited = {"Operator", "Panel", "PropertyGroup", "Menu", "UIList", "AddonPreferences"}
        return bool(identifier and identifier not in inherited)
    except Exception:
        return False

def register_properties():
    for cls in CLASSES:
        try:
            if cls in _REGISTERED_SLOT_CLASSES and _slot_class_has_own_bl_rna(cls):
                continue
            if _slot_class_has_own_bl_rna(cls):
                raise RuntimeError(f'RNA class is already registered outside this generation ledger: {getattr(cls, "__name__", "<unnamed>")}')
            bpy.utils.register_class(cls)
            if _slot_class_has_own_bl_rna(cls) and cls not in _REGISTERED_SLOT_CLASSES:
                _REGISTERED_SLOT_CLASSES.append(cls)
        except Exception:
            pass
    try:
        if not hasattr(bpy.types.Scene, _SCENE_MULTI_SLOT_COLLECTION):
            setattr(
                bpy.types.Scene,
                _SCENE_MULTI_SLOT_COLLECTION,
                bpy.props.CollectionProperty(type=SSS_PG_material_target_object_slot, options={"SKIP_SAVE"}),
            )
    except Exception:
        pass

def unregister_properties():
    try:
        if hasattr(bpy.types.Scene, _SCENE_MULTI_SLOT_COLLECTION):
            delattr(bpy.types.Scene, _SCENE_MULTI_SLOT_COLLECTION)
    except Exception:
        pass
    for cls in reversed(tuple(_REGISTERED_SLOT_CLASSES)):
        try:
            if _slot_class_has_own_bl_rna(cls):
                bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_SLOT_CLASSES.clear()
