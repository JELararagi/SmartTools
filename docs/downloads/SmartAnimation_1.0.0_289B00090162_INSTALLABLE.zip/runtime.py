# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Transactional Smart Animation runtime registration.

One generation owns every native class, RNA property, lifecycle handler and
shared UI class by exact identity.  Lazy integrated tools use child ledgers in
:mod:`loader`; no resource is removed by class name, package prefix or global
Blender API interception.
"""

from __future__ import annotations

import importlib
from typing import Any

import bpy

from . import lifecycle, modal_registry
from .panel_header_guard import harden_class_callbacks
from .undo_support import ensure_operator_undo

_ROOT_PACKAGE = (__package__ or __name__).strip()
_REGISTERED = False
_DEGRADED = False
_LEDGER: lifecycle.GenerationLedger | None = None
_CLEANUP_RUNNING = False
_LAST_REGISTRATION_FAILURES: tuple[str, ...] = ()

_ROOT_TRANSLATION_OWNER = f'{_ROOT_PACKAGE}.root_translations'
_ROOT_TRANSLATIONS = {
    'ja_JP': {
        ('*', 'Smart Animation displays its tools in the standard Sidebar N-panel category Smart Animation.'):
            'Smart Animation は標準のサイドバーNパネルカテゴリ Smart Animation にツールを表示します。',
        ('*', 'Standard Sidebar N-panel runtime for Smart Animation, Smart Animation Smart, and centralized always-on toggles.'):
            'Smart Animation 用の標準サイドバーNパネル実行環境です。',
    },
}

_NATIVE_MODULES: dict[str, Any] = {}
_NATIVE_CLASS_GROUPS: dict[str, tuple[type, ...]] = {
    'property_groups': (),
    'non_property_classes': (),
}


def _import_relative(module_name: str):
    name = str(module_name or '').strip()
    if not name:
        raise ValueError('module_name is empty')
    module = _NATIVE_MODULES.get(name)
    if module is None:
        module = importlib.import_module(f'.{name}', _ROOT_PACKAGE)
        _NATIVE_MODULES[name] = module
    return module


def _is_property_group_class(cls: type) -> bool:
    try:
        return isinstance(cls, type) and issubclass(cls, bpy.types.PropertyGroup)
    except Exception:
        return False


def _build_native_class_groups() -> dict[str, tuple[type, ...]]:
    if _NATIVE_CLASS_GROUPS['non_property_classes']:
        return _NATIVE_CLASS_GROUPS
    core = _import_relative('core')
    ui = _import_relative('ui')
    modules_and_attrs = (
        ('operators', 'OPERATOR_CLASSES'),
        ('plus_operators', 'OPERATOR_PLUS_CLASSES'),
        ('workflow_operators', 'OPERATOR_WORKFLOW_CLASSES'),
        ('motion_fx_operators', 'OPERATOR_MOTION_FX_CLASSES'),
        ('signal_fx_operators', 'OPERATOR_SIGNAL_FX_CLASSES'),
        ('spring_magic_operators', 'OPERATOR_SPRING_MAGIC_CLASSES'),
        ('smart_animation_smart', 'OPERATOR_SMART_ANIMATION_SMART_CLASSES'),
        ('compact_operators', 'OPERATOR_COMPACT_CLASSES'),
    )
    classes: list[type] = list(tuple(getattr(core, 'CORE_CLASSES', ()) or ()))
    for module_name, attr_name in modules_and_attrs:
        module = _import_relative(module_name)
        classes.extend(tuple(getattr(module, attr_name, ()) or ()))
    classes.extend(tuple(getattr(ui, 'UI_CLASSES', ()) or ()))

    # Preserve declaration order and exact class identity.
    unique: list[type] = []
    seen: set[int] = set()
    for cls in classes:
        if not isinstance(cls, type) or id(cls) in seen:
            continue
        seen.add(id(cls))
        unique.append(cls)
    property_groups = tuple(cls for cls in unique if _is_property_group_class(cls))
    non_property = tuple(cls for cls in unique if cls not in property_groups)
    _NATIVE_CLASS_GROUPS['property_groups'] = property_groups
    _NATIVE_CLASS_GROUPS['non_property_classes'] = non_property
    return _NATIVE_CLASS_GROUPS


def _is_native_npanel_root(cls: type) -> bool:
    try:
        return bool(vars(cls).get('_smart_tools_manager_native_npanel_root', False))
    except Exception:
        return False


def _prepare_class(cls: type, generation: int) -> type:
    # Native Manager roots are declared statically in ui.py and already contain
    # exception-safe poll/draw methods. Do not rewrite their callbacks, labels,
    # category, or metadata at runtime; the Manager contract requires stable
    # exact class identities and immutable registered root definitions.
    if _is_native_npanel_root(cls):
        return cls
    try:
        translation = _import_relative('translation')
        normalize = getattr(translation, 'normalize_class_ui_metadata', None)
        if callable(normalize):
            normalize(cls)
    except Exception:
        pass
    ensure_operator_undo(cls)
    harden_class_callbacks(cls)
    modal_registry.instrument_operator_class(cls, generation=generation)
    return cls


def _validate_native_root_contract(ledger: lifecycle.GenerationLedger, ui_module: Any) -> bool:
    """Validate the native sidebar roots and the Asset Browser Tool Properties root."""
    expected_spaces = (
        'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR',
        'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR',
        'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET',
    )
    roots = tuple(getattr(ui_module, '_ROOT_PANEL_CLASSES', ()) or ())
    valid = True

    def check(condition: bool, message: str) -> bool:
        nonlocal valid
        if not condition:
            valid = False
            ledger.note_failure(message)
            return False
        return True

    expected_hosts = {(space, 'UI') for space in expected_spaces}
    expected_hosts.add(('FILE_BROWSER', 'TOOL_PROPS'))
    check(len(roots) == len(expected_hosts), 'native root count must match the supported hosts')
    by_host: dict[tuple[str, str], list[type]] = {host: [] for host in expected_hosts}
    for cls in roots:
        if not check(isinstance(cls, type), 'native root entry is not a class'):
            continue
        space = str(vars(cls).get('bl_space_type', '') or '')
        region = str(vars(cls).get('bl_region_type', '') or '')
        host = (space, region)
        name = getattr(cls, '__name__', cls)
        if check(host in by_host, f'native root host mismatch: {name}'):
            by_host[host].append(cls)
        if space == 'FILE_BROWSER':
            logical = 'ASSET_BROWSER' if region == 'TOOL_PROPS' else 'FILE_BROWSER'
            check(vars(cls).get('_smart_tools_manager_logical_editor_keys') == (logical,),
                  f'native browser root must serve only {logical}: {name}')
        check(vars(cls).get('_smart_tools_manager_native_npanel_root') is True,
              f'native root marker missing: {name}')
        check(vars(cls).get('_smart_tools_manager_tool_key') == 'SMART_ANIMATION',
              f'native root tool key mismatch: {name}')
        check(vars(cls).get('bl_category') == 'Smart Animation', f'native root category mismatch: {name}')
        check(not bool(vars(cls).get('_smart_tools_manager_proxy', False)),
              f'native root cannot be a proxy: {name}')
        check(not bool(vars(cls).get('_smart_tools_manager_anchor', False)),
              f'native root cannot be an anchor: {name}')
        check('bl_parent_id' not in vars(cls) or not str(vars(cls).get('bl_parent_id') or ''),
              f'native root must be top-level: {name}')
        check('_sas_safe_panel_callbacks_wrapped' not in vars(cls),
              f'native root was mutated by callback hardening: {name}')
        check(callable(getattr(cls, 'poll', None)), f'native root poll missing: {name}')
        check(callable(getattr(cls, 'draw', None)), f'native root draw missing: {name}')
        check(lifecycle.class_is_registered_exact(cls), f'native root is not exact-registered: {name}')
        check(any(
            record.kind == 'class' and record.metadata.get('class') is cls
            for record in ledger.records
        ), f'native root is not owned by the current generation: {name}')

    for host in sorted(expected_hosts):
        check(len(by_host[host]) == 1, f'native root count for {host} must be exactly one')
    return valid



def _register_translation(ledger: lifecycle.GenerationLedger, owner: str, payload: dict, label: str) -> bool:
    exact_owner = f'{owner}.g{ledger.generation}.{id(ledger.token):x}'
    registered = False
    try:
        result = bpy.app.translations.register(exact_owner, payload)
        if result is False:
            ledger.note_failure(f'translation registration returned False: {label}')
            return False
        registered = True
        ledger.record_callback(
            kind='translation', label=label, identity=exact_owner,
            remover=lambda _owner=exact_owner: bpy.app.translations.unregister(_owner),
        )
        registered = False  # remover is now exact-generation owned
        return True
    except Exception as exc:
        if registered:
            try:
                bpy.app.translations.unregister(exact_owner)
            except Exception:
                pass
        ledger.note_failure(f'translation registration failed {label}: {type(exc).__name__}: {exc}')
        return False



def _register_native_runtime(ledger: lifecycle.GenerationLedger) -> None:
    """Acquire independent native phases and retain every successful identity."""
    try:
        groups = _build_native_class_groups()
        core = _import_relative('core')
        ui = _import_relative('ui')
        translation = _import_relative('translation')
        tooltip_audit = _import_relative('tooltip_audit')
        icons = _import_relative('icons')
    except Exception as exc:
        ledger.note_failure(f'native module import failed: {type(exc).__name__}: {exc}')
        return

    audit_started = False
    try:
        tooltip_audit.begin_runtime_audit()
        audit_started = True
    except Exception as exc:
        ledger.note_failure(f'tooltip audit start failed: {type(exc).__name__}: {exc}')

    try:
        result = icons.register()
        if result is False:
            ledger.note_failure('icon preview registration returned False')
        else:
            try:
                ledger.record_callback(
                    kind='icon_preview', label='Smart Animation icon previews', identity=id(icons),
                    remover=icons.unregister,
                )
            except Exception as exc:
                try:
                    icons.unregister()
                except Exception:
                    pass
                ledger.note_failure(f'icon preview ledger failed: {type(exc).__name__}: {exc}')
    except Exception as exc:
        ledger.note_failure(f'icon preview registration failed: {type(exc).__name__}: {exc}')

    for cls in groups['property_groups']:
        try:
            ledger.register_class(_prepare_class(cls, ledger.generation), required=False)
        except Exception as exc:
            ledger.note_failure(f'property class phase failed {getattr(cls, "__name__", cls)}: {type(exc).__name__}: {exc}')

    settings_type = getattr(core, 'SAS_Settings', None)
    settings_property = None
    if isinstance(settings_type, type) and lifecycle.class_is_registered_exact(settings_type):
        try:
            from bpy.props import PointerProperty
            settings_property = ledger.set_rna_property(
                bpy.types.Scene, 'sas_settings', PointerProperty(type=settings_type),
                fixed_type=settings_type, required=False,
            )
        except Exception as exc:
            ledger.note_failure(f'Scene.sas_settings registration failed: {type(exc).__name__}: {exc}')
    else:
        ledger.note_failure('SAS_Settings was not exact-registered; Scene.sas_settings was skipped')

    if settings_property is not None:
        try:
            core.install_settings_persistence(ledger=ledger)
        except Exception as exc:
            ledger.note_failure(f'settings handler registration failed: {type(exc).__name__}: {exc}')

    for cls in groups['non_property_classes']:
        try:
            ledger.register_class(_prepare_class(cls, ledger.generation), required=False)
        except Exception as exc:
            ledger.note_failure(f'class phase failed {getattr(cls, "__name__", cls)}: {type(exc).__name__}: {exc}')

    _validate_native_root_contract(ledger, ui)

    try:
        register_cache = getattr(ui, 'register_performance_cache', None)
        if callable(register_cache):
            register_cache()
    except Exception as exc:
        ledger.note_failure(f'performance cache initialization failed: {type(exc).__name__}: {exc}')

    try:
        manager_compat = _import_relative('smart_tools_manager_compat')
        manager_compat.apply_smart_animation_panel_compat()
    except Exception as exc:
        ledger.note_failure(f'Manager compatibility initialization failed: {type(exc).__name__}: {exc}')

    try:
        blend_cleanup = _import_relative('blend_cleanup')
        blend_cleanup.install_cleanup_handlers()
    except Exception as exc:
        ledger.note_failure(f'legacy cleanup retirement failed: {type(exc).__name__}: {exc}')

    _register_translation(ledger, _ROOT_TRANSLATION_OWNER, _ROOT_TRANSLATIONS, 'root translations')
    _register_translation(ledger, f'{_ROOT_PACKAGE}.translation', getattr(translation, 'TRANSLATIONS', {}), 'suite translations')

    if audit_started:
        try:
            tooltip_audit.finish_runtime_audit()
        except Exception as exc:
            ledger.note_failure(f'tooltip audit validation failed: {type(exc).__name__}: {exc}')
            try:
                tooltip_audit.abort_runtime_audit()
            except Exception:
                pass



def _register_generation(ledger: lifecycle.GenerationLedger) -> None:
    # First acquisition of the generation: the persistent load_post re-arm that
    # re-publishes the anchored generation record after Blender replaces
    # bpy.app.driver_namespace.  Acquiring it first means it is journaled ahead
    # of every other resource, runs before this suite's own settings handlers,
    # and is released by the same exact reverse rollback on unregister.
    if not lifecycle.record_state_rearm_handler(ledger):
        ledger.note_failure('lifecycle generation re-arm handler was not acquired')

    _register_native_runtime(ledger)

    common = None
    try:
        common = _import_relative('common')
        if common.register(ledger=ledger) is False:
            ledger.note_failure('common runtime registration completed in degraded mode')
    except Exception as exc:
        ledger.note_failure(f'common runtime registration failed: {type(exc).__name__}: {exc}')

    try:
        tool_runtime = _import_relative('tool_runtime')
        if tool_runtime.register(ledger=ledger) is False:
            ledger.note_failure('integrated tool runtime registration completed in degraded mode')
    except Exception as exc:
        ledger.note_failure(f'integrated tool runtime registration failed: {type(exc).__name__}: {exc}')

    # Read the canonical payload exactly once after dependent RNA exists.  Every
    # restoration phase consumes the same immutable snapshot/hash, and common is
    # limited to distinct WindowManager-owned state.
    try:
        core = _import_relative('core')
        payload = core.load_settings_payload(refresh=True)
        core.apply_saved_settings_to_all_scenes(force=False, payload=payload)
        if common is not None:
            common_payload = common.load_settings_file(payload=payload)
            common.apply_persistent_settings(getattr(bpy, 'context', None), payload=common_payload)
    except Exception as exc:
        ledger.note_failure(f'settings restoration failed: {type(exc).__name__}: {exc}')

    try:
        runtime_persistence = _import_relative('runtime_persistence')
        runtime_persistence.apply_saved_runtime_properties(
            context=getattr(bpy, 'context', None), force=True,
        )
    except Exception as exc:
        ledger.note_failure(f'runtime property restoration failed: {type(exc).__name__}: {exc}')



def _cleanup_generation(ledger: lifecycle.GenerationLedger) -> bool:
    """Release only the exact resources captured by *ledger*.

    A Blender teardown-order conflict is retried by ``ledger.rollback()``.  If
    an exact remover still cannot complete, its live record and the module
    objects needed by the captured closure are retained for the next finite
    disable/register attempt.  Nothing is rediscovered by class name, package
    prefix, ``bpy.types`` enumeration, or broad ``sys.modules`` scanning.
    """
    global _REGISTERED, _DEGRADED, _LEDGER, _CLEANUP_RUNNING
    if ledger.released:
        return True
    if _CLEANUP_RUNNING:
        return False
    _CLEANUP_RUNNING = True
    cleanup_complete = False
    modal_cleanup_complete = True
    integrated_runtime_complete = True
    modal_metadata_complete = True

    def cleanup_phase(label: str, callback) -> bool:
        try:
            result = callback()
            if result is False:
                ledger.note_failure(f'cleanup {label} returned False')
                return False
            return True
        except Exception as exc:
            try:
                ledger.note_failure(f'cleanup {label} failed: {type(exc).__name__}: {exc}')
            except Exception:
                pass
            return False

    try:
        def cancel_generation_modals() -> bool:
            modal_registry.cancel_all_active(
                generation=ledger.generation, context=getattr(bpy, 'context', None),
            )
            return modal_registry.active_count(generation=ledger.generation) == 0

        modal_cleanup_complete = cleanup_phase(
            'active modal cancellation', cancel_generation_modals,
        )

        core = _NATIVE_MODULES.get('core')
        if core is not None:
            cleanup_phase(
                'dirty settings commit',
                lambda: core.commit_dirty_settings(context=getattr(bpy, 'context', None)),
            )

        tool_runtime = _NATIVE_MODULES.get('tool_runtime')
        if tool_runtime is not None:
            integrated_runtime_complete = cleanup_phase(
                'integrated tool runtime',
                lambda: tool_runtime.unregister(ledger_owned=True),
            )

        common = _NATIVE_MODULES.get('common')
        if common is not None:
            cleanup_phase('common runtime', lambda: common.unregister(ledger_owned=True))

        if core is not None:
            cleanup_phase('settings persistence', lambda: core.uninstall_settings_persistence(remove_handlers=False))

        blend_cleanup = _NATIVE_MODULES.get('blend_cleanup')
        if blend_cleanup is not None:
            cleanup_phase('legacy cleanup handlers', blend_cleanup.uninstall_cleanup_handlers)

        ui_module = _NATIVE_MODULES.get('ui')
        if ui_module is not None:
            unregister_cache = getattr(ui_module, 'unregister_performance_cache', None)
            if callable(unregister_cache):
                cleanup_phase('performance cache', unregister_cache)

        runtime_persistence = _NATIVE_MODULES.get('runtime_persistence')
        if runtime_persistence is not None:
            cleanup_phase('runtime persistence cache', runtime_persistence.clear_runtime_caches)

        translation = _NATIVE_MODULES.get('translation')
        if translation is not None:
            unregister_dynamic = getattr(translation, 'unregister_dynamic_ui_translations', None)
            if callable(unregister_dynamic):
                cleanup_phase('dynamic UI translations', unregister_dynamic)

        tooltip_audit = _NATIVE_MODULES.get('tooltip_audit')
        if tooltip_audit is not None:
            clear_audit = getattr(tooltip_audit, 'clear_runtime_audit', None)
            if callable(clear_audit):
                cleanup_phase('tooltip audit', clear_audit)

        cleanup_phase('exact generation rollback', ledger.rollback)
        modal_metadata_complete = cleanup_phase(
            'modal instrumentation metadata',
            lambda: modal_registry.clear_instrumentation_metadata(generation=ledger.generation),
        )
        cleanup_complete = bool(
            ledger.released and integrated_runtime_complete
            and modal_cleanup_complete and modal_metadata_complete
        )
        if cleanup_complete:
            cleanup_complete = cleanup_phase(
                'driver namespace ownership',
                lambda: lifecycle.clear_current_if_owned(ledger),
            )
    finally:
        _REGISTERED = False
        _CLEANUP_RUNNING = False
        if cleanup_complete:
            if _LEDGER is ledger:
                _LEDGER = None
            _NATIVE_MODULES.clear()
            _NATIVE_CLASS_GROUPS['property_groups'] = ()
            _NATIVE_CLASS_GROUPS['non_property_classes'] = ()
            _DEGRADED = False
        else:
            # Keep only the exact generation ledger and the imported module
            # identities required by its captured removers.  Re-publish the same
            # exact callback so a live replacement can retry without adopting or
            # mutating foreign/user resources.
            _LEDGER = ledger
            _DEGRADED = True
            lifecycle.publish_current_cleanup_soft(
                ledger, lambda _ledger=ledger: _cleanup_generation(_ledger),
            )
            lifecycle.warn_once(
                'UNREGISTER_DEFERRED',
                'Exact generation cleanup was deferred and will be retried without scanning foreign resources.',
            )
    return cleanup_complete



def register() -> None:
    """Register without leaking any exception to Blender's enable boundary."""
    global _REGISTERED, _DEGRADED, _LEDGER, _LAST_REGISTRATION_FAILURES
    if _REGISTERED and _LEDGER is not None and lifecycle.is_current(_LEDGER):
        if not _DEGRADED:
            return None
        # A degraded generation must not become a permanent no-op on a direct
        # re-enable/live-reload call. Retire only its captured exact identities,
        # then retry acquisition in a fresh generation when cleanup completes.
        try:
            if not _cleanup_generation(_LEDGER):
                lifecycle.warn_once(
                    'REGISTER_RETRY_DEFERRED',
                    'Degraded generation cleanup is still pending; registration completed without touching foreign resources.',
                )
                return None
        except Exception as exc:
            try:
                _LEDGER.note_failure(f'degraded re-enable cleanup failed: {type(exc).__name__}: {exc}')
            except Exception:
                pass
            lifecycle.warn_once(
                'REGISTER_RETRY_DEFERRED',
                'Degraded generation cleanup failed; registration completed without touching foreign resources.',
            )
            return None

    if _LEDGER is not None and not _LEDGER.released:
        try:
            _cleanup_generation(_LEDGER)
        except Exception:
            # _cleanup_generation is itself guarded; this is the final enable
            # boundary shield for a partially replaced live module.
            pass

    try:
        ledger = lifecycle.GenerationLedger.begin('Smart Animation Suite')
    except Exception as exc:
        ledger = lifecycle.GenerationLedger(
            label='Smart Animation Suite (detached)', generation=0, token=object(),
        )
        ledger.note_failure(f'generation begin failed: {type(exc).__name__}: {exc}')

    _LEDGER = ledger
    prior_cleanup_pending = any(
        record.kind == 'prior_generation_cleanup' and record.active
        for record in ledger.records
    )
    if prior_cleanup_pending:
        # A still-live exact prior generation is never adopted or overlaid. The
        # enable boundary completes in a tagged degraded state and the captured
        # prior callback remains retryable on the next disable/re-enable.
        ledger.note_failure('registration acquisition skipped while prior exact cleanup is pending')
    else:
        try:
            _register_generation(ledger)
        except Exception as exc:
            ledger.note_failure(f'unhandled registration phase failed: {type(exc).__name__}: {exc}')

    try:
        healthy = bool(ledger.commit_degraded())
    except Exception as exc:
        ledger.note_failure(f'degraded commit failed: {type(exc).__name__}: {exc}')
        healthy = False
        ledger.committed = True

    _REGISTERED = True
    _DEGRADED = not healthy
    published = lifecycle.publish_current_cleanup_soft(
        ledger, lambda _ledger=ledger: _cleanup_generation(_ledger),
    )
    if not published:
        _DEGRADED = True
    else:
        try:
            core = _NATIVE_MODULES.get('core')
            if core is not None and core.arm_settings_context_ready(ledger) is False:
                ledger.note_failure('settings context-ready owner callback was not armed')
                _DEGRADED = True
        except Exception as exc:
            ledger.note_failure(f'settings context-ready owner arm failed: {type(exc).__name__}: {exc}')
            _DEGRADED = True

    _LAST_REGISTRATION_FAILURES = tuple(dict.fromkeys(str(item) for item in ledger.failures))[-64:]
    if _DEGRADED:
        lifecycle.warn_once(
            'REGISTER_DEGRADED',
            'Registration completed in degraded mode; every acquired resource remains exact-generation owned.',
        )
    return None



def unregister() -> None:
    ledger = _LEDGER
    if ledger is None:
        return None
    try:
        _cleanup_generation(ledger)
    except Exception as exc:
        try:
            ledger.note_failure(f'unregister boundary failure: {type(exc).__name__}: {exc}')
        except Exception:
            pass
    return None



def registration_boundary_fallback(exc: BaseException) -> None:
    """Last-resort no-raise boundary for restricted/live-replacement startup."""
    global _REGISTERED, _DEGRADED, _LAST_REGISTRATION_FAILURES
    message = f'public register boundary failure: {type(exc).__name__}: {exc}'
    ledger = _LEDGER
    if ledger is not None:
        try:
            ledger.note_failure(message)
        except Exception:
            pass
    _REGISTERED = True
    _DEGRADED = True
    _LAST_REGISTRATION_FAILURES = tuple(dict.fromkeys((*_LAST_REGISTRATION_FAILURES, message)))[-64:]
    try:
        lifecycle.warn_once(
            'REGISTER_BOUNDARY_DEGRADED',
            'Registration boundary recovered in degraded mode; no foreign resource was changed.',
        )
    except Exception:
        pass
    return None


def unregister_boundary_fallback(exc: BaseException) -> None:
    """Contain a final unregister exception without touching foreign resources."""
    ledger = _LEDGER
    if ledger is not None:
        try:
            ledger.note_failure(f'public unregister boundary failure: {type(exc).__name__}: {exc}')
        except Exception:
            pass
    return None


def ensure_runtime_initialized(context=None, *args, force: bool = False, **kwargs) -> bool:
    del context, args, force, kwargs
    register()
    return bool(_REGISTERED)



def repair_runtime(context=None) -> bool:
    del context
    if not _REGISTERED or _DEGRADED or _LEDGER is None or not lifecycle.is_current(_LEDGER):
        return False
    try:
        return _LEDGER.verify_all()
    except Exception:
        return False



def preflight_cleanup(package_name: str | None = None, module_name: str | None = None, module_file: str | None = None):
    del package_name, module_name, module_file
    return {
        'generation_exact_identity': True,
        'registered': bool(_REGISTERED),
        'degraded': bool(_DEGRADED),
        'generation': int(getattr(_LEDGER, 'generation', 0) or 0),
        'failure_count': len(_LAST_REGISTRATION_FAILURES),
        'failures': tuple(_LAST_REGISTRATION_FAILURES),
    }



def get_preferences(context=None, package_name: str | None = None, module_name: str | None = None, module_file: str | None = None):
    del context, package_name, module_name, module_file
    return None


if __name__ == '__main__':
    register()
