import copy
import importlib
import inspect
import textwrap
import sys
from typing import Any
import bpy
from bpy.props import BoolProperty, PointerProperty, StringProperty
from . import translation as _smart_locale
from . import rna_safety as _rna_safety
from . import _sss_lifecycle as _lifecycle
from .core.preferences import SSS_Preferences as SMARTTOOLS_PG_CORE
from .navigation.properties import SCULPTNAV_AddonPreferences as SMARTTOOLS_PG_NAVIGATION
from .mask_facesets_tools import My_AddonPreferences as SMARTTOOLS_PG_MASK_FACESETS_TOOLS
_ICON_ALIASES = {'TRANSFORM_MOVE': 'HAND'}
_ICON_ENUM_CACHE: set[str] | None = None

def _initialize_icon_cache() -> None:
    global _ICON_ENUM_CACHE
    identifiers: set[str] = set()
    try:
        layout_rna = getattr(getattr(bpy, 'types', None), 'UILayout', None)
        functions = getattr(getattr(layout_rna, 'bl_rna', None), 'functions', None)
        operator_fn = functions['operator'] if functions is not None else None
        parameters = getattr(operator_fn, 'parameters', None)
        icon_param = parameters['icon'] if parameters is not None else None
        for item in getattr(icon_param, 'enum_items', ()) or ():
            identifier = str(getattr(item, 'identifier', '') or '').strip()
            if identifier:
                identifiers.add(identifier)
    except Exception:
        identifiers = set()
    _ICON_ENUM_CACHE = identifiers


def _safe_icon(icon: str | None, fallback: str='NONE') -> str:
    value = str(icon or '').strip() or str(fallback or 'NONE').strip() or 'NONE'
    fallback_value = str(fallback or 'NONE').strip() or 'NONE'
    value = _ICON_ALIASES.get(value, value)
    fallback_value = _ICON_ALIASES.get(fallback_value, fallback_value)
    identifiers = _ICON_ENUM_CACHE if _ICON_ENUM_CACHE is not None else set()
    if identifiers:
        if value in identifiers:
            return value
        if fallback_value in identifiers:
            return fallback_value
        if 'NONE' in identifiers:
            return 'NONE'
    return value


def _compact_npanel_layout(layout):
    """Use compact N-panel-safe layout flags for embedded settings."""
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    return layout

def _replace_proxy_group_reference(original: type, replacement: type) -> None:
    """Static proxy schema classes are never rebound."""
    return None

def _safe_register_class_common(cls: type) -> bool:
    if not isinstance(cls, type):
        return False
    return bool(_rna_safety.register_class(cls))

def _safe_unregister_class_common(cls: type) -> None:
    _rna_safety.unregister_class(cls)
TOOL_ORDER: tuple[str, ...] = ('core', 'navigation', 'mask_facesets_tools')
_TOOL_META: dict[str, dict[str, Any]] = {'core': {'display_en': 'Smart Sculpt', 'display_ja': 'スマートスカルプト', 'icon': 'SCULPTMODE_HLT', 'summary_en': 'This is the main Smart Sculpt workflow suite. It groups preparation, analysis, generation, topology, masks, face sets, non-destructive backups, and exchange helpers into one 3D View Sidebar N-panel workspace.', 'summary_ja': 'スマートスカルプトの中核となるスカルプト用ツールセットです。準備、診断、生成、トポロジ、マスク、フェイスセット、非破壊バックアップ、受け渡し補助を、3DビューサイドバーのNパネルへ集約しています。', 'usage_en': 'Open the Smart Sculpt N-panel, stay in Sculpt mode for most actions, then move through the sections in order. Start with preparation and diagnostics before destructive steps, and use snapshots when you want a safer checkpoint.', 'usage_ja': 'スマートスカルプトのNパネルを開き、主な操作はスカルプトモードで進めます。基本は各セクションを順番に使い、破壊的な処理の前に準備と診断を確認し、安全な区切りが欲しい時はスナップショットを使います。', 'container_attr': 'core_prefs', 'section_attr': 'show_core_section', 'enabled_attr': '', 'proxy_module': 'core.preferences', 'proxy_class': 'SSS_Preferences', 'supports_runtime_toggle': False}, 'navigation': {'display_en': 'Sculpt Navigation', 'display_ja': 'スカルプトナビゲーション', 'icon': 'VIEW3D', 'summary_en': 'This tool brings ZBrush and 3D-Coat style navigation into Blender. It separates empty-space navigation from on-mesh sculpting, supports border navigation zones, brush adjustment, roll, focus, and ignore rules.', 'summary_ja': 'ZBrush や 3D-Coat に近い操作感のナビゲーションを Blender へ移植するツールです。空きスペースでの視点移動とメッシュ上でのスカルプトを分離し、境界ナビゲーション、ブラシ調整、ロール、フォーカス、無視ルールをまとめて扱えます。', 'usage_en': 'Enable the tool, register the recommended shortcuts in the Sculpt keymap, then use empty-space gestures to orbit, pan, dolly, roll, or zoom without interrupting sculpting. Adjust the border and ignore settings if navigation triggers too often or too rarely.', 'usage_ja': 'まず有効化し、推奨ショートカットをスカルプトのキーマップへ登録します。その後は空きスペース上のジェスチャーで回転、パン、ドリー、ロール、ズームを行い、スカルプト操作を止めずに視点移動します。反応範囲が広すぎる場合や狭すぎる場合は、境界幅や無視設定を調整してください。', 'container_attr': 'navigation_prefs', 'section_attr': 'show_navigation_section', 'enabled_attr': '', 'proxy_module': 'navigation.properties', 'proxy_class': 'SCULPTNAV_AddonPreferences', 'supports_runtime_toggle': False}, 'mask_facesets_tools': {'display_en': 'Sculpt Mask FaceSets Tools', 'display_ja': 'スカルプトマスク・フェイスセットツール', 'icon': 'MOD_MASK', 'summary_en': 'This tool concentrates mask, face set, visibility, trim, extract, and mesh-filter actions into a compact sculpt pie menu. It is suited to fast repetitive sculpt support work that should stay close to the cursor.', 'summary_ja': 'マスク、フェイスセット、表示、トリム、抽出、メッシュフィルター操作を、コンパクトなスカルプト用パイメニューへまとめたツールです。カーソル付近で素早く繰り返す補助操作に向いています。', 'usage_en': 'Enable the tool, assign the pie menu to an easy Sculpt shortcut, then call it whenever you need common mask or face-set commands near the cursor. The menu is best used for fast context switches rather than long sequential setup.', 'usage_ja': 'まず有効化し、パイメニューをスカルプト中に押しやすいショートカットへ割り当てます。マスクやフェイスセットの定番操作をカーソル付近ですばやく呼び出したい時に使います。長い設定作業よりも、素早い文脈切り替え用の操作として使うと効果的です。', 'container_attr': 'mask_facesets_tools_prefs', 'section_attr': 'show_mask_facesets_tools_section', 'enabled_attr': '', 'proxy_module': 'mask_facesets_tools', 'proxy_class': 'My_AddonPreferences', 'supports_runtime_toggle': False}}
_LAYOUT_ATTR_MISSING = object()
_PROXY_GROUP_CLASSES: dict[str, type] = {'core': SMARTTOOLS_PG_CORE, 'navigation': SMARTTOOLS_PG_NAVIGATION, 'mask_facesets_tools': SMARTTOOLS_PG_MASK_FACESETS_TOOLS}
_INTEGRATED_RUNTIME_SIGNATURE: tuple[tuple[str, bool], ...] | None = None
_PREFERENCES_REGISTERED = False
_ROOT_PREFERENCES_ATTR = 'smart_sculpt_suite_preferences'
_LEGACY_ROOT_PREFERENCES_ATTRS = ('preferences',)
_KNOWN_CONTROLS_JSON_ATTR = 'known_controls_json'
_FEATURE_TOGGLES_JSON_ATTR = 'feature_toggles_json'
_ALWAYS_ON_PREF_PROP_IDS = {'canvas_navigation_enabled', 'canvas_rmb_enabled', 'double_click_focus_enabled', 'show_border_overlay'}

def _is_always_on_pref_prop(data, identifier: str) -> bool:
    identifier = str(identifier or '')
    if identifier not in _ALWAYS_ON_PREF_PROP_IDS:
        return False
    type_name = str(getattr(type(data), '__name__', '') or '').upper()
    return 'SCULPTNAV' in type_name or 'SCULPT_NAV' in type_name or 'SCULPT_NAVIGATION' in type_name

class _InjectedLayoutDescriptor:

    def __init__(self, layout):
        self._layout = layout

    def __get__(self, _obj, _objtype=None):
        return self._layout

def _root_addon_id() -> str:
    name = __package__ or __name__
    if name.endswith('.preferences'):
        return name.rsplit('.', 1)[0]
    return name or 'core'

def _root_runtime_module():
    return sys.modules.get(_root_addon_id())

def _localized_text(english: str, japanese: str) -> str:
    return _smart_locale.ui_text(english, japanese)

def _rna_prop_label(data, prop_name: str) -> str:
    prop_name = str(prop_name or '').strip()
    if not prop_name:
        return ''
    try:
        props = getattr(getattr(data, 'bl_rna', None), 'properties', None)
        prop = None
        if props is not None:
            if hasattr(props, 'get'):
                prop = props.get(prop_name)
            else:
                try:
                    prop = props[prop_name]
                except Exception:
                    prop = None
        label = str(getattr(prop, 'name', '') or '').strip() if prop is not None else ''
        if label:
            return label
    except Exception:
        pass
    return prop_name.replace('_', ' ').strip().title()

def _draw_npanel_prop(layout, data, prop_name: str, *, text: str | None=None, **kwargs) -> bool:
    layout = _compact_npanel_layout(layout)
    prop_name = str(prop_name or '').strip()
    if data is None or not prop_name or (not hasattr(data, prop_name)):
        return False
    label = str(text if text is not None else _rna_prop_label(data, prop_name) or '').strip()
    control_kwargs = dict(kwargs or {})
    control_kwargs.pop('expand', None)
    col = _compact_npanel_layout(layout.column(align=True))
    if label:
        try:
            col.label(text=label)
        except Exception:
            pass
    try:
        row = _compact_npanel_layout(col.row(align=True))
        row.prop(data, prop_name, text='', **control_kwargs)
        return True
    except Exception as exc:
        try:
            col.label(text=_smart_locale.exception_ui_text(exc), icon='ERROR')
        except Exception:
            pass
        return False

def _wrap_labels(layout, text: str, width: int=88, icon: str='NONE') -> None:
    cleaned = str(text or '').strip()
    if not cleaned:
        return
    lines = textwrap.wrap(cleaned, width=max(32, int(width))) or [cleaned]
    first = True
    for line in lines:
        if first:
            layout.label(text=line, icon=_safe_icon(icon))
            first = False
        else:
            layout.label(text=line)

def _help_button_row(layout):
    try:
        layout.separator(factor=0.35)
    except TypeError:
        try:
            layout.separator()
        except Exception:
            pass
    except Exception:
        pass
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.alignment = 'RIGHT'
    except Exception:
        pass
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    return row

def _help_button(layout, topic_id: str) -> bool:
    topic_id = str(topic_id or '').strip()
    if not topic_id:
        return False
    try:
        op = _help_button_row(layout).operator('smart_sculpt.open_help_popup', text='', icon='QUESTION')
        op.topic_id = topic_id
        return True
    except Exception:
        return False


def _native_preferences_panel_id(key: str) -> str:
    identifier = ''.join((ch.upper() if ch.isalnum() else '_' for ch in str(key or ''))).strip('_')
    return 'SMART_SCULPT_PREFERENCES_' + (identifier or 'SECTION')


def _draw_preferences_section_box(layout, prefs, attr_name: str, title: str, icon: str, topic_id: str, *, default: bool=False):
    attr_name = str(attr_name or '').strip()
    if prefs is not None and attr_name and hasattr(prefs, attr_name):
        header, body = layout.panel_prop(prefs, attr_name)
    else:
        header, body = layout.panel(
            _native_preferences_panel_id(attr_name or title),
            default_closed=not bool(default),
        )
    header = _compact_npanel_layout(header)
    header.label(text=title, icon=_safe_icon(icon or 'TOOL_SETTINGS'))
    _help_button(header, topic_id)
    if body is None:
        return None
    return _compact_npanel_layout(body.column(align=True))

class SMARTTOOLS_OT_toggle_preferences_section(bpy.types.Operator):
    bl_idname = 'smart_sculpt.toggle_preferences_section'
    bl_label = 'Toggle Smart Sculpt Preferences Section'
    bl_description = 'Open or close this Smart Sculpt preferences section.'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True
    attr_name: StringProperty(default='', options={'SKIP_SAVE'})
    label: StringProperty(default='', options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, 'label', '') or '').strip()
        return _localized_text(f'Open or close the {label} settings section.', f'{label} 設定セクションを開閉します。')

    def execute(self, context):
        attr = str(getattr(self, 'attr_name', '') or '').strip()
        prefs = root_preferences(context)
        if prefs is None or not attr or (not hasattr(prefs, attr)):
            return {'CANCELLED'}
        try:
            setattr(prefs, attr, not bool(getattr(prefs, attr)))
        except Exception:
            return {'CANCELLED'}
        try:
            screen = getattr(context, 'screen', None)
            for area in getattr(screen, 'areas', ()):
                if getattr(area, 'type', None) == 'VIEW_3D':
                    area.tag_redraw()
        except Exception:
            pass
        return {'FINISHED'}

def _runtime_status() -> tuple[bool, bool]:
    try:
        module = _root_runtime_module()
    except Exception:
        return (False, False)
    try:
        main_enabled = bool(getattr(module, 'is_main_runtime_enabled', lambda: False)())
    except Exception:
        main_enabled = False
    try:
        integrated_enabled = bool(getattr(module, 'is_integrated_runtime_enabled', lambda: False)())
    except Exception:
        integrated_enabled = False
    if not main_enabled:
        integrated_enabled = False
    return (main_enabled, integrated_enabled)

def _preferences_owner(context=None):
    context = context or getattr(bpy, 'context', None)
    return getattr(context, 'window_manager', None)

def _legacy_addon_preferences(context=None):
    return None

def root_preferences(context=None):
    preferences = _preferences_owner(context)
    if preferences is not None:
        try:
            storage = getattr(preferences, _ROOT_PREFERENCES_ATTR, None)
        except Exception:
            storage = None
        if storage is not None:
            return storage
    return None

def tool_meta(alias: str) -> dict[str, Any]:
    return dict(_TOOL_META.get(str(alias or '').strip()) or {})

def _meta_text(alias: str, english_key: str, japanese_key: str, default: str='') -> str:
    meta = tool_meta(alias)
    if _smart_locale.locale_is_japanese():
        value = meta.get(japanese_key) or meta.get(english_key) or default
    else:
        value = meta.get(english_key) or meta.get(japanese_key) or default
    return str(value)

def tool_title(alias: str) -> str:
    return _meta_text(alias, 'display_en', 'display_ja', str(alias or 'Tool'))

def tool_summary(alias: str) -> str:
    return _meta_text(alias, 'summary_en', 'summary_ja')

def tool_usage(alias: str) -> str:
    return _meta_text(alias, 'usage_en', 'usage_ja')

def tool_enabled(alias: str, context=None) -> bool:
    alias = str(alias or '').strip()
    meta = tool_meta(alias)
    enabled_attr = str(meta.get('enabled_attr') or '').strip()
    if not enabled_attr:
        return True
    prefs = root_preferences(context)
    if prefs is None or not hasattr(prefs, enabled_attr):
        return True
    try:
        return bool(getattr(prefs, enabled_attr))
    except Exception:
        return True

def find_tool_settings(alias: str, context=None):
    meta = tool_meta(alias)
    container_attr = str(meta.get('container_attr') or '').strip()
    if not container_attr:
        return None
    prefs = root_preferences(context)
    if prefs is None or not hasattr(prefs, container_attr):
        return None
    try:
        return getattr(prefs, container_attr)
    except Exception:
        return None

def _integrated_runtime_signature(context=None) -> tuple[tuple[str, bool], ...]:
    prefs = root_preferences(context)
    signature: list[tuple[str, bool]] = []
    for alias in TOOL_ORDER:
        meta = tool_meta(alias)
        enabled_attr = str(meta.get('enabled_attr') or '').strip()
        if not enabled_attr:
            continue
        enabled = True
        if prefs is not None and hasattr(prefs, enabled_attr):
            try:
                enabled = bool(getattr(prefs, enabled_attr))
            except Exception:
                enabled = True
        signature.append((enabled_attr, enabled))
    return tuple(signature)

def mark_integrated_runtime_state(context=None):
    global _INTEGRATED_RUNTIME_SIGNATURE
    _INTEGRATED_RUNTIME_SIGNATURE = _integrated_runtime_signature(context)
    return _INTEGRATED_RUNTIME_SIGNATURE

def _clone_keyword_value(value):
    if isinstance(value, dict):
        return {key: _clone_keyword_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_clone_keyword_value(item) for item in value]
    if isinstance(value, tuple):
        return tuple((_clone_keyword_value(item) for item in value))
    try:
        return copy.deepcopy(value)
    except Exception:
        return value

def _preferences_owner_type():
    return getattr(bpy.types, 'WindowManager', None)

def _save_preferences_after_update(context=None) -> None:
    try:
        settings_mod = importlib.import_module(f'{_root_addon_id()}.core.settings')
        if bool(getattr(settings_mod, 'is_applying', lambda: False)()):
            return
        scene = None
        try:
            scene = getattr(context, 'scene', None)
        except Exception:
            scene = None
        if scene is None:
            try:
                scene = getattr(getattr(bpy, 'context', None), 'scene', None)
            except Exception:
                scene = None
        request_save = getattr(settings_mod, 'request_immediate_save', None)
        if callable(request_save):
            request_save(scene, context, force=False)
            return
        immediate = getattr(settings_mod, 'immediate_save_enabled', None)
        if callable(immediate) and (not bool(immediate(scene))):
            return
        save_fn = getattr(settings_mod, 'save_preferences', None)
        if callable(save_fn):
            try:
                save_fn(context, force=False)
            except TypeError:
                save_fn(context)
    except Exception:
        pass

def _smarttools_wrap_update_callback(callback):
    if bool(getattr(callback, '_smarttools_update_wrapper', False)):
        return callback
    captured_callback = callback

    def _wrapped(self, context):
        result = None
        if callable(captured_callback):
            attempts = ((self, context), (self,), tuple(), (self, context, None), (self, context, ''))
            try:
                signature = inspect.signature(captured_callback)
            except Exception:
                signature = None
            if signature is not None:
                positional = [param for param in signature.parameters.values() if param.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)]
                required = [param for param in positional if param.default is inspect._empty]
                has_varargs = any((param.kind == inspect.Parameter.VAR_POSITIONAL for param in signature.parameters.values()))
                min_args = len(required)
                max_args = float('inf') if has_varargs else len(positional)
                if min_args <= 2 <= max_args:
                    attempts = ((self, context),)
            for args in attempts:
                try:
                    result = captured_callback(*args)
                    break
                except TypeError:
                    continue
                except Exception:
                    result = None
                    break
        _save_preferences_after_update(context)
        return result
    try:
        _wrapped.__name__ = getattr(captured_callback, '__name__', 'smarttools_update_wrapper') if callable(captured_callback) else 'smarttools_update_save'
    except Exception:
        pass
    _wrapped._smarttools_update_wrapper = True
    return _wrapped
_PREFERENCE_UPDATE_FACTORY_NAMES = {'BoolProperty', 'IntProperty', 'FloatProperty', 'StringProperty', 'EnumProperty', 'BoolVectorProperty', 'IntVectorProperty', 'FloatVectorProperty'}

def _sanitize_deferred_property_keywords(kwargs: dict[str, Any], factory_name: str='') -> dict[str, Any]:
    if not isinstance(kwargs, dict):
        return {}
    cleaned = dict(kwargs)
    factory_name = str(factory_name or '').strip()
    if factory_name in _PREFERENCE_UPDATE_FACTORY_NAMES or 'update' in cleaned:
        cleaned['update'] = _smarttools_wrap_update_callback(cleaned.get('update'))
    return cleaned

def _deferred_property_metadata(prop_def) -> tuple[str, dict[str, Any]]:
    keywords = getattr(prop_def, 'keywords', None)
    function = getattr(prop_def, 'function', None)
    factory_name = getattr(function, '__name__', '') if function is not None else ''
    if isinstance(keywords, dict) and factory_name:
        return (factory_name, _sanitize_deferred_property_keywords({key: _clone_keyword_value(value) for key, value in keywords.items()}, factory_name))
    if isinstance(prop_def, tuple) and len(prop_def) == 2 and isinstance(prop_def[1], dict):
        tuple_factory = str(prop_def[0] or '')
        return (tuple_factory, _sanitize_deferred_property_keywords({key: _clone_keyword_value(value) for key, value in prop_def[1].items()}, tuple_factory))
    return ('', {})

def _clone_deferred_property(prop_def):
    factory_name, kwargs = _deferred_property_metadata(prop_def)
    if not factory_name:
        return None
    factory = getattr(bpy.props, factory_name, None)
    if not callable(factory):
        return None
    try:
        return factory(**kwargs)
    except Exception:
        return None

def _build_empty_proxy_group(alias: str) -> type:
    return _PROXY_GROUP_CLASSES[alias]

def _original_pref_class(alias: str):
    meta = tool_meta(alias)
    module_suffix = str(meta.get('proxy_module') or '').strip()
    class_name = str(meta.get('proxy_class') or '').strip()
    if not module_suffix or not class_name:
        return None
    module = importlib.import_module(f'{_root_addon_id()}.{module_suffix}')
    return getattr(module, class_name, None)

def _iter_declared_property_names(cls) -> tuple[str, ...]:
    names: list[str] = []
    seen: set[str] = set()
    for owner in reversed(tuple(getattr(cls, '__mro__', (cls,)))):
        annotations = getattr(owner, '__annotations__', None)
        if not isinstance(annotations, dict):
            continue
        for name in annotations.keys():
            text = str(name or '').strip()
            if not text or text.startswith('_') or text in seen:
                continue
            seen.add(text)
            names.append(text)
    return tuple(names)

def _copy_declared_properties(src, dst) -> None:
    if src is None or dst is None:
        return
    for name in _iter_declared_property_names(type(dst)):
        if not hasattr(src, name):
            continue
        try:
            src_value = getattr(src, name)
        except Exception:
            continue
        dst_value = None
        has_nested = False
        try:
            dst_value = getattr(dst, name)
            has_nested = hasattr(dst_value, 'bl_rna') and hasattr(src_value, 'bl_rna')
        except Exception:
            has_nested = False
        if has_nested:
            try:
                _copy_declared_properties(src_value, dst_value)
                continue
            except Exception:
                pass
        try:
            setattr(dst, name, src_value)
        except Exception:
            pass

def _migrate_legacy_addon_preferences(context=None) -> bool:
    return False

def _build_proxy_property_group(alias: str) -> type:
    return _proxy_group(alias)

def _ensure_proxy_groups() -> None:
    """Static mapping is complete at import time."""
    return None

def _proxy_group(alias: str) -> type:
    key = str(alias or '').strip()
    try:
        return _PROXY_GROUP_CLASSES[key]
    except KeyError as exc:
        raise KeyError(f'Unknown Smart Sculpt preference schema: {key}') from exc

def _call_group_draw(draw_fn, group_instance, layout, context) -> None:
    """Compatibility stub.

    Older builds injected a fake ``layout`` attribute and executed the original
    AddonPreferences.draw() body inside the Smart Sculpt N-panel.  That can
    crash Blender 5.x because those draw methods were written for the native
    Preferences editor RNA object.  Keep this function for stale callers, but do
    not use it for N-panel rendering.
    """
    raise RuntimeError('Direct preference draw injection is disabled for native N-panel safety.')

def _iter_drawable_rna_properties(data):
    if data is None:
        return
    try:
        props = tuple(getattr(getattr(data, 'bl_rna', None), 'properties', ()) or ())
    except Exception:
        props = ()
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
        except Exception:
            continue
        if not identifier or identifier == 'rna_type':
            continue
        if identifier.startswith('_'):
            continue
        if _is_always_on_pref_prop(data, identifier):
            continue
        try:
            if bool(getattr(prop, 'is_hidden', False)) or bool(getattr(prop, 'is_readonly', False)):
                continue
        except Exception:
            pass
        if not hasattr(data, identifier):
            continue
        yield (identifier, prop)

def _draw_rna_settings(layout, data, *, columns: int=1) -> bool:
    """Draw settings through native UILayout.prop calls only.

    This avoids invoking arbitrary draw methods from embedded add-ons while still
    exposing every registered RNA property that Blender can safely edit in the
    Smart Sculpt N-panel.
    """
    del columns
    layout = _compact_npanel_layout(layout)
    props = list(_iter_drawable_rna_properties(data) or ())
    if not props:
        return False
    target = _compact_npanel_layout(layout.column(align=True))
    drawn = False
    for identifier, prop in props:
        try:
            _draw_npanel_prop(target, data, identifier)
            drawn = True
        except Exception as exc:
            try:
                prop_type = str(getattr(prop, 'type', '') or '').upper()
                label = str(getattr(prop, 'name', '') or identifier)
                row = target.row(align=True)
                row.enabled = False
                row.label(text=_localized_text(f'{label}: managed internally', f'{label}: 内部管理項目です'), icon='NONE' if prop_type in {'COLLECTION', 'POINTER'} else 'ERROR')
            except Exception:
                pass
    return drawn

def _refresh_integrated_runtime_impl(context=None, *, force: bool=False) -> bool:
    try:
        module = _root_runtime_module()
        result = getattr(module, 'ensure_integrated_runtime', lambda: (True, ''))()
        return bool(result[0]) if isinstance(result, tuple) and result else True
    except Exception:
        return False

def _refresh_integrated_runtime(_self, _context) -> None:
    _refresh_integrated_runtime_impl(_context)
_ensure_proxy_groups()

def _save_root_preferences_update(_self, context) -> None:
    _save_preferences_after_update(context)

class SMARTTOOLS_PG_RootPreferences(bpy.types.PropertyGroup):
    show_core_section: BoolProperty(name='Smart Sculpt Section', description=_localized_text('Show or hide Smart Sculpt settings in the N-panel settings area.', 'Nパネル設定領域でスマートスカルプト設定を表示または折りたたみます。'), default=True, update=_save_root_preferences_update)
    show_navigation_section: BoolProperty(name='Sculpt Navigation', description=_localized_text('Show or hide Sculpt Navigation settings in the N-panel settings area.', 'Nパネル設定領域でスカルプトナビゲーション設定を表示または折りたたみます。'), default=True, update=_save_root_preferences_update)
    show_mask_facesets_tools_section: BoolProperty(name='Sculpt Mask FaceSets Tools', description=_localized_text('Show or hide mask and Face Set tool settings in the N-panel settings area.', 'Nパネル設定領域でマスク・フェイスセットツール設定を表示または折りたたみます。'), default=True, update=_save_root_preferences_update)
    show_runtime_status_section: BoolProperty(name='Runtime Status', description=_localized_text('Show or hide the Smart Sculpt runtime status section in the N-panel settings area.', 'Nパネル設定領域でスマートスカルプトランタイム状態セクションを表示または折りたたみます。'), default=False, update=_save_root_preferences_update)
    show_tool_sections_section: BoolProperty(name='Tool Sections', description=_localized_text('Show or hide the integrated tool settings section in the N-panel settings area.', 'Nパネル設定領域で統合ツール設定セクションを表示または折りたたみます。'), default=False, update=_save_root_preferences_update)
    known_controls_json: StringProperty(name='Known Always-on Control State', description=_localized_text('Hidden storage that mirrors the N-panel always-on control state into Blender Preferences. It is maintained automatically and is not edited from the add-on Preferences UI.', 'Nパネルの常時起動切り替え状態を Blender プリファレンスへミラー保存する非表示領域です。自動管理され、アドオンプリファレンスUIからは編集しません。'), default='', options={'HIDDEN'})
    feature_toggles_json: StringProperty(name='Runtime Feature Toggle State', description=_localized_text('Hidden storage that mirrors detected runtime feature toggles into Blender Preferences so Save Preferences can preserve the N-panel state.', '検出されたランタイム機能切り替えを Blender プリファレンスへミラー保存し、「プリファレンスの保存」でNパネル状態を維持するための非表示領域です。'), default='', options={'HIDDEN'})
    core_prefs: PointerProperty(type=_proxy_group('core'))
    navigation_prefs: PointerProperty(type=_proxy_group('navigation'))
    mask_facesets_tools_prefs: PointerProperty(type=_proxy_group('mask_facesets_tools'))

    def _draw_tool_settings(self, layout, alias: str, context) -> None:
        settings = find_tool_settings(alias, context=context)
        if settings is None:
            layout.label(text=_localized_text('Settings storage is not available for this tool.', 'このツールの設定保存先を取得できません。'), icon='ERROR')
            return
        try:
            if _draw_rna_settings(layout, settings, columns=1):
                return
        except Exception as exc:
            layout.label(text=f"{_localized_text('Settings draw failed', '設定描画に失敗')}: {_smart_locale.exception_ui_text(exc)}", icon='ERROR')
            return
        layout.label(text=_localized_text('This tool does not expose additional editable settings.', 'このツールには追加で編集できる設定がありません。'), icon='NONE')

    def _draw_tool_section(self, layout, alias: str, context) -> None:
        meta = tool_meta(alias)
        title = tool_title(alias)
        section_attr = str(meta.get('section_attr') or '')
        icon = _safe_icon(str(meta.get('icon') or 'TOOL_SETTINGS'))
        if section_attr and hasattr(self, section_attr):
            header, body = layout.panel_prop(self, section_attr)
        else:
            header, body = layout.panel(
                _native_preferences_panel_id(f'tool_{alias}'),
                default_closed=False,
            )
        header = _compact_npanel_layout(header)
        header.label(text=title, icon=icon)
        _help_button(header, 'settings_all' if alias == 'core' else f'integrated:{alias}')
        if body is None:
            return
        self._draw_tool_settings(_compact_npanel_layout(body.column(align=True)), alias, context)

    def draw(self, context):
        return None

def draw_preferences_in_smart_tools(layout, context) -> None:
    try:
        layout = _compact_npanel_layout(_smart_locale.localized_layout(layout))
    except Exception:
        layout = _compact_npanel_layout(layout)
    prefs = root_preferences(context)
    if prefs is None:
        layout.label(text=_localized_text('Smart Sculpt preferences are not available.', 'スマートスカルプトプリファレンスを取得できません。'), icon='ERROR')
        return
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    main_runtime_enabled, integrated_runtime_enabled = _runtime_status()
    status_col = _draw_preferences_section_box(layout, prefs, 'show_runtime_status_section', _localized_text('Runtime Status', 'ランタイム状態'), 'SYSTEM', 'always_on', default=False)
    if status_col is not None:
        status_col.label(text=_localized_text('Smart Sculpt Runtime: Loaded', 'スマートスカルプトランタイム: 読込済み') if main_runtime_enabled else _localized_text('Smart Sculpt Runtime: Not Loaded', 'スマートスカルプトランタイム: 未読込'), icon='CHECKMARK' if main_runtime_enabled else 'PAUSE')
        status_col.label(text=_localized_text('Integrated Tools: Loaded', '統合ツール: 読込済み') if integrated_runtime_enabled else _localized_text('Integrated Tools: Not Loaded', '統合ツール: 未読込'), icon='CHECKMARK' if integrated_runtime_enabled else 'PAUSE')
    tool_box = _draw_preferences_section_box(layout, prefs, 'show_tool_sections_section', _localized_text('Tool Sections', 'ツール別設定'), 'PLUGIN', 'settings_all', default=False)
    if tool_box is not None:
        for alias in TOOL_ORDER:
            try:
                prefs._draw_tool_section(tool_box, alias, context)
            except Exception as exc:
                fail_box = tool_box.box()
                fail_box.label(text=f'{tool_title(alias)}: {_smart_locale.exception_ui_text(exc)}', icon='ERROR')
classes = tuple((_PROXY_GROUP_CLASSES[alias] for alias in TOOL_ORDER)) + (SMARTTOOLS_OT_toggle_preferences_section, SMARTTOOLS_PG_RootPreferences)

def _purge_registered_preferences_classes() -> None:
    """No purge: only current-generation exact classes are released."""
    return None

def _delete_preferences_owner_property(owner, attr_name: str) -> None:
    if owner is None or str(attr_name or '') != _ROOT_PREFERENCES_ATTR:
        return
    _rna_safety.unregister_property(owner, _ROOT_PREFERENCES_ATTR)

def _register_preferences_owner_property() -> None:
    owner = _preferences_owner_type()
    if owner is None:
        raise RuntimeError('Blender WindowManager RNA type is not available.')
    _rna_safety.register_property(owner, _ROOT_PREFERENCES_ATTR, PointerProperty(type=SMARTTOOLS_PG_RootPreferences))

def _unregister_preferences_owner_property() -> None:
    owner = _preferences_owner_type()
    if owner is not None:
        _rna_safety.unregister_property(owner, _ROOT_PREFERENCES_ATTR)

def register() -> None:
    global _PREFERENCES_REGISTERED
    if _PREFERENCES_REGISTERED:
        return
    registered_now = []
    try:
        _initialize_icon_cache()
        try:
            _smart_locale.normalize_class_texts(classes)
        except Exception:
            pass
        _smart_locale.register_translations()
        for cls in classes:
            if not _safe_register_class_common(cls):
                raise RuntimeError(f'Class registration failed: {cls.__name__}')
            registered_now.append(cls)
        _register_preferences_owner_property()
        _PREFERENCES_REGISTERED = True
    except Exception:
        _unregister_preferences_owner_property()
        for cls in reversed(registered_now):
            try:
                _safe_unregister_class_common(cls)
            except Exception:
                pass
        try:
            _smart_locale.unregister_translations()
        except Exception:
            pass
        _PREFERENCES_REGISTERED = False
        raise

def rollback_registration() -> None:
    global _PREFERENCES_REGISTERED, _ICON_ENUM_CACHE
    _ICON_ENUM_CACHE = None
    try:
        _unregister_preferences_owner_property()
    except Exception:
        pass
    for cls in reversed(classes):
        try:
            _safe_unregister_class_common(cls)
        except Exception:
            pass
    try:
        _smart_locale.unregister_translations()
    except Exception:
        pass
    _PREFERENCES_REGISTERED = False

def unregister() -> None:
    rollback_registration()
