import importlib
import sys
import time
import bpy
from bpy.types import Menu, Panel, UIList
from . import icon_assets, properties, utils
from . import navigation_properties as _navigation_properties
_PANEL_CLASSES = tuple()
_SMART_SCULPT_NPANEL_SPACE_TYPES = {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}
_SMART_TOOLS_MANAGER_PANEL_PATCHED_FROM_POLL = False
_SMART_TOOLS_MANAGER_PANEL_PATCH_LAST = 0.0
_SMART_TOOLS_MANAGER_PANEL_PATCH_ATTEMPTS = 0

def _patch_smart_tools_manager_panel_policy_from_poll() -> None:
    """Compatibility no-op: Smart Sculpt never mutates Smart Tools Manager internals."""
    return None

def _is_native_npanel_context(context) -> bool:
    area = getattr(context, 'area', None)
    if area is None:
        return True
    try:
        return str(getattr(area, 'type', '') or '') in _SMART_SCULPT_NPANEL_SPACE_TYPES
    except Exception:
        return False

def cleanup_legacy_smarttools_npanel_artifacts() -> None:
    """No-op: registered Panels are never purged or rewritten."""
    return None

def _loaded_sibling_module(name: str):
    package = str(__package__ or '').strip()
    root = package.rsplit('.core', 1)[0] if '.core' in package else package.rsplit('.', 1)[0]
    return sys.modules.get(f'{root}.{str(name or "").strip()}') if root else None


def _preferences_module():
    return _loaded_sibling_module('preferences')


def _compact_npanel_layout(layout):
    """Keep N-panel controls inside the sidebar width by disabling split/decorator layout state."""
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    return layout

def _is_null_layout(layout) -> bool:
    try:
        return bool(getattr(layout, '_sss_null_layout', False))
    except Exception:
        return False

def _rna_prop_label(data, prop_name: str) -> str:
    """Return the current-language RNA label for a property without forcing a split row."""
    prop_name = str(prop_name or '').strip()
    if not prop_name:
        return ''
    try:
        props = getattr(getattr(data, 'bl_rna', None), 'properties', None)
        prop = None
        if props is not None:
            if hasattr(props, 'get'):
                prop = props.get(prop_name)
            else:
                try:
                    prop = props[prop_name]
                except Exception:
                    prop = None
        label = str(getattr(prop, 'name', '') or '').strip() if prop is not None else ''
        if label:
            return utils.translate_registered_text(label)
    except Exception:
        pass
    return prop_name.replace('_', ' ').strip().title()

def _draw_npanel_prop(layout, data, prop_name: str, *, text: str | None=None, icon: str='NONE', **kwargs) -> bool:
    """Draw one property as label-above-control so narrow N-panels never push controls to the right."""
    if _is_null_layout(layout):
        return False
    layout = _compact_npanel_layout(layout)
    prop_name = str(prop_name or '').strip()
    if data is None or not prop_name or (not hasattr(data, prop_name)):
        return False
    label = str(text if text is not None else _rna_prop_label(data, prop_name) or '').strip()
    control_kwargs = dict(kwargs or {})
    control_kwargs.pop('expand', None)
    col = _compact_npanel_layout(layout.column(align=True))
    if label:
        try:
            if icon and icon != 'NONE':
                col.label(text=label, icon=utils.safe_icon(icon))
            else:
                col.label(text=label)
        except Exception:
            pass
    try:
        control = _compact_npanel_layout(col.row(align=True))
        control.prop(data, prop_name, text='', **control_kwargs)
        return True
    except Exception as exc:
        try:
            col.label(text=utils.exception_ui_text(exc), icon=utils.safe_icon('ERROR'))
        except Exception:
            pass
        return False

def _help_button_row(layout):
    try:
        layout.separator(factor=0.35)
    except TypeError:
        try:
            layout.separator()
        except Exception:
            pass
    except Exception:
        pass
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.alignment = 'RIGHT'
    except Exception:
        pass
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    return row

def _draw_help_button(layout, topic_id: str, *, text: str='', icon: str='QUESTION') -> bool:
    del text, icon
    topic_id = str(topic_id or '').strip()
    if not topic_id:
        return False
    try:
        op = _help_button_row(layout).operator('smart_sculpt.open_help_popup', text='', icon='QUESTION')
        op.topic_id = topic_id
        return True
    except Exception:
        return False
_SECTION_DEFAULTS = {'always_on': False, 'edit_mode_sculpt': True, 'top_viewport': False, 'top_efficiency': False, 'top_brush': False, 'top_remesh_retopo': False, 'top_generate_deform': False, 'top_analysis_repair': False, 'top_save_io': False}
_TOP_LEVEL_SECTION_KEYS = frozenset(_SECTION_DEFAULTS.keys())

def _is_top_level_section(section_key: str | None) -> bool:
    return str(section_key or '').strip() in _TOP_LEVEL_SECTION_KEYS

def _section_storage_key(section_key: str) -> str:
    text = str(section_key or '').strip().lower()
    text = ''.join((ch if ch.isalnum() else '_' for ch in text)).strip('_')
    return 'ui_section_' + (text or 'section')

def _section_label(title_en: str, title_ja: str, context=None) -> str:
    return utils.ui_text(str(title_en or ''), str(title_ja or title_en or ''))

def _section_state_get(settings, section_key: str, default: bool=False) -> bool:
    key = str(section_key or '').strip()
    if not key:
        return bool(default)
    if key == 'always_on' and settings is not None and hasattr(settings, 'show_always_on_toggles'):
        try:
            return bool(getattr(settings, 'show_always_on_toggles'))
        except Exception:
            pass
    storage_key = _section_storage_key(key)
    try:
        if settings is not None:
            try:
                if storage_key in settings:
                    return bool(settings[storage_key])
            except Exception:
                value = settings.get(storage_key, None) if hasattr(settings, 'get') else None
                if value is not None:
                    return bool(value)
    except Exception:
        pass
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        if wm is not None and storage_key in wm:
            return bool(wm[storage_key])
    except Exception:
        pass
    return bool(_SECTION_DEFAULTS.get(key, default))

def _section_state_set(settings, section_key: str, value: bool, *, context=None) -> None:
    key = str(section_key or '').strip()
    if not key:
        return
    value = bool(value)
    if key == 'always_on' and settings is not None and hasattr(settings, 'show_always_on_toggles'):
        try:
            setattr(settings, 'show_always_on_toggles', value)
            return
        except Exception:
            pass
    storage_key = _section_storage_key(key)
    try:
        if settings is not None:
            settings[storage_key] = value
            try:
                from . import settings as _smart_settings
                scene = getattr(context or getattr(bpy, 'context', None), 'scene', None)
                _smart_settings.request_immediate_save(scene, context=context or getattr(bpy, 'context', None), force=False)
            except Exception:
                pass
            return
    except Exception:
        pass
    try:
        wm = getattr(context or getattr(bpy, 'context', None), 'window_manager', None)
        if wm is not None:
            wm[storage_key] = value
    except Exception:
        pass

def _tag_redraw_view3d(context=None) -> None:
    try:
        screen = getattr(context or getattr(bpy, 'context', None), 'screen', None)
        for area in getattr(screen, 'areas', ()):
            try:
                if getattr(area, 'type', None) == 'VIEW_3D':
                    area.tag_redraw()
            except Exception:
                pass
    except Exception:
        pass

class SSS_OT_toggle_ui_section(bpy.types.Operator):
    bl_idname = 'smart_sculpt.toggle_ui_section'
    bl_label = 'Toggle UI Section'
    bl_description = 'Expand or collapse this Smart Sculpt UI section.'
    bl_options = {'UNDO', 'INTERNAL'}
    section_key: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
    label: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, 'label', '') or getattr(properties, 'section_key', '') or '').strip()
        return utils.ui_text(f'Open or close the {label} section.', f'{label} セクションを開閉します。')

    def execute(self, context):
        section_key = str(getattr(self, 'section_key', '') or '').strip()
        if not section_key:
            return {'CANCELLED'}
        scene = _safe_context_scene(context)
        settings = getattr(scene, 'core', None) if scene is not None else None
        current = _section_state_get(settings, section_key, bool(_SECTION_DEFAULTS.get(section_key, False)))
        _section_state_set(settings, section_key, not current, context=context)
        _tag_redraw_view3d(context)
        return {'FINISHED'}

def _draw_section_help_icon(row, topic_id: str) -> bool:
    topic_id = str(topic_id or '').strip()
    if not topic_id:
        return False
    try:
        row.separator(factor=0.35)
    except TypeError:
        try:
            row.separator()
        except Exception:
            pass
    except Exception:
        pass
    try:
        help_row = row.row(align=True)
    except Exception:
        help_row = row
    try:
        help_row.scale_x = 0.82
        help_row.scale_y = 1.0
    except Exception:
        pass
    try:
        op = help_row.operator('smart_sculpt.open_help_popup', text='', icon='QUESTION', emboss=True)
        op.topic_id = topic_id
        return True
    except Exception:
        return False

def _draw_section_header(box, context, settings, section_key: str, title_en: str, title_ja: str, icon: str, topic_id: str, *, default: bool=False) -> bool:
    label = _section_label(title_en, title_ja, context)
    expanded = _section_state_get(settings, section_key, default)
    row = _compact_npanel_layout(box.row(align=True))
    try:
        row.use_property_split = False
        row.use_property_decorate = False
    except Exception:
        pass
    try:
        op = row.operator('smart_sculpt.toggle_ui_section', text='', icon=utils.safe_icon('TRIA_DOWN' if expanded else 'TRIA_RIGHT'), emboss=True, depress=bool(expanded))
        op.section_key = str(section_key or '')
        op.label = label
    except Exception:
        row.label(text='', icon=utils.safe_icon('TRIA_DOWN' if expanded else 'TRIA_RIGHT'))
    try:
        op = row.operator('smart_sculpt.toggle_ui_section', text=label, icon=utils.safe_icon(icon or 'TOOL_SETTINGS'), emboss=False, depress=bool(expanded))
        op.section_key = str(section_key or '')
        op.label = label
    except Exception:
        row.label(text=label, icon=utils.safe_icon(icon or 'TOOL_SETTINGS'))
    _draw_section_help_icon(row, topic_id)
    return bool(expanded)

def _draw_child_help_icon(header, topic_id: str) -> bool:
    topic_id = str(topic_id or '').strip()
    if not topic_id:
        return False
    try:
        header.separator(factor=0.35)
    except TypeError:
        try:
            header.separator()
        except Exception:
            pass
    except Exception:
        pass
    try:
        help_row = header.row(align=True)
    except Exception:
        help_row = header
    try:
        help_row.alignment = 'RIGHT'
        help_row.scale_x = 0.82
        help_row.scale_y = 1.0
    except Exception:
        pass
    try:
        op = help_row.operator('smart_sculpt.open_help_popup', text='', icon='QUESTION', emboss=True)
        op.topic_id = topic_id
        return True
    except Exception:
        return False

def _native_child_panel_id(section_key: str) -> str:
    key = ''.join((ch.upper() if ch.isalnum() else '_' for ch in str(section_key or ''))).strip('_')
    return 'SMART_SCULPT_CHILD_' + (key or 'SECTION')


def _draw_child_section_box_fallback(layout, context, settings, section_key: str, title_en: str, title_ja: str, icon: str, topic_id: str, *, default: bool=False):
    """Draw one child section through Blender's native ``UILayout.panel()``.

    Native panels provide Blender's thin chevron and region-owned disclosure
    state.  The prior right-shift diagnosis was incorrect: the confirmed cause
    is ``separator_spacer()`` inside a non-full-width header, not
    ``UILayout.panel()`` itself.  Child headers therefore use a regular
    right-aligned row and never use ``separator_spacer()``.
    """
    if _is_null_layout(layout):
        return None
    layout = _compact_npanel_layout(utils.localized_layout(layout))
    if _is_null_layout(layout):
        return None
    label = _section_label(title_en, title_ja, context)
    expanded_default = _section_state_get(settings, section_key, default)
    header, body = layout.panel(
        _native_child_panel_id(section_key),
        default_closed=not bool(expanded_default),
    )
    header = _compact_npanel_layout(header)
    try:
        header.use_property_split = False
        header.use_property_decorate = False
    except Exception:
        pass
    header.label(text=label, icon=utils.safe_icon(icon or 'TOOL_SETTINGS'))
    _draw_child_help_icon(header, topic_id)
    if body is None:
        return None
    body = _compact_npanel_layout(body.column(align=True))
    try:
        body.use_property_split = False
        body.use_property_decorate = False
    except Exception:
        pass
    return body

def _draw_child_section_box(layout, context, settings, section_key: str, title_en: str, title_ja: str, icon: str, topic_id: str, *, default: bool=False):
    """Draw non-top-level sections as native Blender child panels."""
    return _draw_child_section_box_fallback(layout, context, settings, section_key, title_en, title_ja, icon, topic_id, default=default)

def _draw_section_box(layout, context, settings, section_key: str, title_en: str, title_ja: str, icon: str, topic_id: str, *, default: bool=False):
    if not _is_top_level_section(section_key):
        return _draw_child_section_box(layout, context, settings, section_key, title_en, title_ja, icon, topic_id, default=default)
    box = _compact_npanel_layout(layout.box())
    expanded = _draw_section_header(box, context, settings, section_key, title_en, title_ja, icon, topic_id, default=default)
    if not expanded:
        return None
    body = _compact_npanel_layout(box.column(align=True))
    return body

class _NullUILayout:
    """No-op layout sink used to keep collapsed legacy section bodies invisible."""

    def __init__(self):
        self.enabled = False
        self.active = False
        self.alert = False
        self.alignment = 'EXPAND'
        self.scale_x = 1.0
        self.scale_y = 1.0
        self.use_property_split = False
        self.use_property_decorate = False
        self._sss_null_layout = True

    def row(self, *args, **kwargs):
        return self

    def column(self, *args, **kwargs):
        return self

    def box(self, *args, **kwargs):
        return self

    def grid_flow(self, *args, **kwargs):
        return self

    def split(self, *args, **kwargs):
        return self

    def separator(self, *args, **kwargs):
        return None

    def label(self, *args, **kwargs):
        return None

    def prop(self, *args, **kwargs):
        return None

    def operator(self, *args, **kwargs):
        return self

    def template_list(self, *args, **kwargs):
        raise RuntimeError('collapsed section')
_NULL_LAYOUT = _NullUILayout()

def _draw_section_box_or_empty(layout, context, settings, section_key: str, title_en: str, title_ja: str, icon: str, topic_id: str, *, default: bool=False):
    body = _draw_section_box(layout, context, settings, section_key, title_en, title_ja, icon, topic_id, default=default)
    return body if body is not None else _NULL_LAYOUT

def _draw_box_header(box, title_en: str, title_ja: str, icon: str, topic_id: str) -> None:
    box = _compact_npanel_layout(box)
    row = box.row(align=True)
    _compact_npanel_layout(row)
    row.label(text=utils.ui_text(title_en, title_ja), icon=utils.safe_icon(icon))
    _draw_help_button(row, topic_id)

def _clip_ui_text(text: object, max_chars: int=24) -> str:
    value = str(text or '').strip()
    if not value:
        return ''
    limit = max(8, int(max_chars))
    return value if len(value) <= limit else value[:max(1, limit - 1)] + '…'

def _draw_wrapped_label(layout, context, text: object, *, icon: str='NONE') -> None:
    """Draw a status sentence on as many lines as the N-panel width needs."""
    value = str(text or '').strip()
    if not value or _is_null_layout(layout):
        return
    lines = [value]
    try:
        from . import help_content
        ctx = context or bpy.context
        width = float(getattr(getattr(ctx, 'region', None), 'width', 0) or 0)
        scale = help_content._ui_scale()
        if width > 0:
            margin = (64.0 if icon == 'NONE' else 84.0) * scale
            lines = help_content._pixel_wrap_lines(value, max_pixels=(width - margin) * 0.86, min_pixels=60.0 * scale) or [value]
    except Exception:
        lines = [value]
    column = layout.column(align=True)
    for index, line in enumerate(lines):
        if index == 0 and icon != 'NONE':
            column.label(text=line, icon=utils.safe_icon(icon))
        else:
            column.label(text=line)

def _draw_embedded_preferences(layout, context) -> None:
    if _is_null_layout(layout):
        return
    layout = _compact_npanel_layout(utils.localized_layout(layout))
    prefs_module = _preferences_module()
    if prefs_module is None:
        _draw_wrapped_label(layout, context, utils.ui_text('Smart Tools preferences module is not available.', 'スマートツールプリファレンスモジュールを取得できません。'), icon='ERROR')
        return
    draw_fn = getattr(prefs_module, 'draw_preferences_in_smart_tools', None)
    if callable(draw_fn):
        try:
            draw_fn(layout, context)
            return
        except Exception as exc:
            layout.label(text=f"{utils.ui_text('Settings draw failed', '設定描画に失敗')}: {utils.exception_ui_text(exc)}", icon='ERROR')
            return
    layout.label(text=utils.ui_text('Smart Tools settings UI is not available.', 'スマートツール設定 UI を取得できません。'), icon='ERROR')

def _draw_setting_prop(layout, data, prop_name: str, *, text: str | None=None) -> bool:
    return _draw_npanel_prop(layout, data, prop_name, text=text)

def _draw_setting_prop_grid(layout, data, prop_names: tuple[str, ...], *, columns: int=2) -> bool:
    del columns
    layout = _compact_npanel_layout(layout)
    available = [name for name in prop_names if hasattr(data, name)]
    if not available:
        return False
    flow = _compact_npanel_layout(layout.column(align=True))
    drawn = False
    for prop_name in available:
        if _draw_setting_prop(flow, data, prop_name):
            drawn = True
    return drawn

def _draw_scene_settings_section(layout, context, settings, title_en: str, title_ja: str, icon: str, prop_names: tuple[str, ...], *, columns: int=2) -> bool:
    layout = _compact_npanel_layout(layout)
    if settings is None:
        return False
    if not any((hasattr(settings, name) for name in prop_names)):
        return False
    section_key = 'scene_' + ''.join((ch.lower() if ch.isalnum() else '_' for ch in str(title_en or ''))).strip('_')
    box = _draw_section_box_or_empty(layout, context, settings, section_key, title_en, title_ja, icon, 'settings_all', default=False)
    return _draw_setting_prop_grid(box, settings, prop_names, columns=columns)

def _draw_all_scene_settings(layout, context, settings) -> None:
    layout = _compact_npanel_layout(utils.localized_layout(layout))
    if settings is None:
        layout.label(text=utils.ui_text('Scene settings are not available.', 'シーン設定を取得できません。'), icon='ERROR')
        return
    parent = _draw_section_box_or_empty(layout, context, settings, 'smart_sculpt_scene_settings', 'Scene Settings', 'シーン設定', 'SCENE_DATA', 'settings_all', default=False)
    sections = (('Navigation Preferences', 'ナビゲーション設定', 'VIEW3D', ('navigation_enabled', 'navigation_canvas_enabled', 'navigation_rmb_enabled', 'navigation_double_click_focus_enabled'), 1), ('Workflow Selectors', 'ワークフロー選択', 'TOOL_SETTINGS', ('core_action', 'compact_viewport_preset', 'quick_tool', 'tool_pipe_slot_index', 'surface_action', 'compact_remesh_mode', 'compact_multires_action', 'compact_mask_action', 'compact_face_set_action', 'compact_filter_domain', 'build_action', 'compact_primitive_type', 'compact_boolean_operation', 'compact_axis', 'compact_procedural_preset', 'snapshot_action', 'recovery_action', 'layer_action', 'session_action', 'transfer_action', 'profile'), 2), ('Smart Upgrade Tools', 'スマートアップグレード', 'AUTO', ('smart_upgrade_action', 'smart_upgrade_quality', 'smart_upgrade_show_icon_board', 'smart_upgrade_show_metrics', 'smart_upgrade_icon_scale', 'smart_upgrade_auto_preflight', 'smart_upgrade_adaptive_scale', 'smart_upgrade_non_destructive', 'smart_upgrade_write_report', 'smart_upgrade_target_faces', 'smart_upgrade_strength', 'smart_upgrade_density', 'smart_upgrade_count', 'smart_upgrade_segments', 'smart_upgrade_axis', 'smart_upgrade_use_voxel', 'smart_upgrade_use_multires', 'smart_upgrade_make_snapshot', 'smart_photo_reference_path'), 2), ('Sculpt / Brush / View', 'スカルプト / ブラシ / 表示', 'BRUSH_DATA', ('auto_enter_sculpt', 'quick_tool', 'compact_viewport_preset', 'profile', 'tool_pipe_slot_1', 'tool_pipe_slot_2', 'tool_pipe_slot_3'), 1), ('Surface / Topology / Masks', 'サーフェイス / マスク', 'MOD_REMESH', ('dyntopo_mode', 'dyntopo_detail', 'voxel_size', 'voxel_adaptivity', 'multires_levels', 'quad_target_faces', 'extract_thickness', 'mask_extract_smooth_iterations', 'mask_extract_add_boundary_loop', 'mask_extract_apply_shrinkwrap', 'mask_slice_fill_holes', 'mesh_filter_type', 'cloth_filter_type', 'filter_strength', 'retopo_offset', 'retopo_use_mirror', 'unwrap_margin'), 2), ('Build / Boolean / Procedural', 'ビルド / プロシージャル', 'MESH_CUBE', ('primitive_radius', 'primitive_operation', 'boolean_cleanup_voxel', 'procedural_strength', 'procedural_scale', 'rail_length', 'rail_width', 'rail_depth', 'rail_apply_to_target', 'rail_apply_boolean', 'rail_remove_cutter', 'rail_add_bevel', 'scatter_count', 'scatter_min_scale', 'scatter_max_scale', 'scatter_align_to_normal', 'scatter_normal_offset', 'scatter_seed', 'scatter_avoid_overlap', 'scatter_min_gap', 'scatter_tilt_degrees', 'compact_chain_count', 'compact_curve_length', 'compact_axis', 'compact_procedural_preset'), 2), ('Safety / Sessions / Cleanup', '安全 / セッション / 整理', 'RECOVER_LAST', ('enable_recovery_backups', 'hide_originals_on_proxy', 'session_mode', 'session_initialize_face_sets', 'session_face_set_mode', 'multi_object_make_single_user', 'apply_scale_on_fix', 'recalc_normals_on_fix', 'delete_loose_on_fix', 'dissolve_degenerate_on_fix', 'degenerate_threshold_on_fix', 'merge_distance_on_fix', 'cleanup_include_snapshots'), 2), ('Exchange / Layer Driver', '受け渡し / レイヤードライバー', 'IMPORT', ('exchange_dir', 'exchange_format', 'exchange_scope', 'exchange_timestamped_export', 'driver_bone', 'driver_channel', 'driver_min', 'driver_max'), 1))
    drawn_names: set[str] = {'show_always_on_toggles', 'always_on_npanel_autosave_restore', 'navigation_enabled', 'navigation_canvas_enabled', 'navigation_rmb_enabled', 'navigation_double_click_focus_enabled', 'always_on_navigation_border_overlay'}
    for title_en, title_ja, icon, prop_names, columns in sections:
        if _draw_scene_settings_section(parent, context, settings, title_en, title_ja, icon, tuple(prop_names), columns=columns):
            drawn_names.update((name for name in prop_names if hasattr(settings, name)))
    try:
        rna_props = getattr(getattr(settings, 'bl_rna', None), 'properties', ())
    except Exception:
        rna_props = ()
    remaining = []
    for prop in rna_props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
        except Exception:
            continue
        if not identifier or identifier == 'rna_type' or identifier in drawn_names:
            continue
        try:
            if bool(getattr(prop, 'is_readonly', False)):
                continue
        except Exception:
            pass
        try:
            if bool(getattr(prop, 'is_hidden', False)):
                continue
        except Exception:
            pass
        if identifier in {'diagnostics'} or identifier.endswith('_tool'):
            continue
        if hasattr(settings, identifier):
            remaining.append(identifier)
    if remaining:
        _draw_scene_settings_section(parent, context, settings, 'Other Registered Settings', 'その他の登録済み設定', 'PREFERENCES', tuple(remaining), columns=2)

def _prepare_npanel_panels():
    cleanup_legacy_smarttools_npanel_artifacts()
    return None

def _has_snapshot_runtime(obj) -> bool:
    if obj is None:
        return False
    obj_type = getattr(bpy, 'types', None)
    object_type = getattr(obj_type, 'Object', None) if obj_type is not None else None
    if object_type is None:
        return False
    try:
        return hasattr(object_type, 'smart_sculpt_snapshots') and hasattr(object_type, 'smart_sculpt_snapshot_index')
    except Exception:
        return False

def _safe_context_scene(context):
    try:
        return getattr(context, 'scene', None)
    except Exception:
        return None

def _safe_object_mode(obj) -> str:
    try:
        return str(getattr(obj, 'mode', '') or '')
    except Exception:
        return ''

def _safe_object_name(obj, fallback: str='') -> str:
    try:
        name = str(getattr(obj, 'name', '') or '').strip()
    except Exception:
        name = ''
    return name or fallback

def _object_data_lists_are_safe(context, obj) -> bool:
    del context
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False
    try:
        if int(obj.as_pointer()) == 0:
            return False
    except Exception:
        pass
    mode = _safe_object_mode(obj)
    return mode in {'', 'OBJECT'}

def _safe_topology_signature(obj) -> tuple[int, int, int]:
    try:
        return utils.topology_signature(obj)
    except Exception:
        return (0, 0, 0)

def _lightweight_ui_mesh_stats(obj) -> dict[str, object]:
    verts, edges, faces = _safe_topology_signature(obj)
    mesh = getattr(obj, 'data', None) if obj is not None else None
    try:
        uv_count = len(getattr(mesh, 'uv_layers', []) or []) if mesh is not None else 0
    except Exception:
        uv_count = 0
    try:
        shape_key_count = len(getattr(getattr(mesh, 'shape_keys', None), 'key_blocks', []) or []) if mesh is not None else 0
    except Exception:
        shape_key_count = 0
    return {'measured': False, 'precision_score': 0, 'vertices': verts, 'edges': edges, 'faces': faces, 'quad_ratio': 0.0, 'non_manifold_edges': 0, 'uv_layers': uv_count, 'shape_keys': shape_key_count}
_UI_MESH_STATS_CACHE: dict[str, object] = {'object_ptr': 0, 'data_ptr': 0, 'mode': '', 'signature': (0, 0, 0), 'timestamp': 0.0, 'stats': None}


def clear_ui_caches() -> None:
    """Release the single data-only mesh-stat snapshot on disable/reload."""
    _UI_MESH_STATS_CACHE.clear()
    _UI_MESH_STATS_CACHE.update({'object_ptr': 0, 'data_ptr': 0, 'mode': '', 'signature': (0, 0, 0), 'timestamp': 0.0, 'stats': None})

def cache_ui_mesh_stats(obj, stats: dict[str, object] | None) -> None:
    """Store one explicit-operation mesh analysis for later lightweight UI reads.

    N-panel draw callbacks must never walk all vertices/edges/faces. Smart
    operators that already compute a full analysis call this function once at
    execution completion; the cache is a single active-object record.
    """
    if obj is None or getattr(obj, 'type', None) != 'MESH' or (not isinstance(stats, dict)):
        return
    try:
        obj_ptr = int(obj.as_pointer())
    except Exception:
        obj_ptr = 0
    try:
        data = getattr(obj, 'data', None)
        data_ptr = int(data.as_pointer()) if data is not None else 0
    except Exception:
        data_ptr = 0
    _UI_MESH_STATS_CACHE.update({'object_ptr': obj_ptr, 'data_ptr': data_ptr, 'mode': _safe_object_mode(obj), 'signature': _safe_topology_signature(obj), 'timestamp': time.monotonic(), 'stats': dict(stats)})

def _cached_ui_mesh_stats(obj, *, allow_full: bool=True) -> dict[str, object]:
    """Return explicit cached analysis or constant-cost topology counters only."""
    del allow_full
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return {}
    mode = _safe_object_mode(obj)
    signature = _safe_topology_signature(obj)
    try:
        obj_ptr = int(obj.as_pointer())
    except Exception:
        obj_ptr = 0
    try:
        data = getattr(obj, 'data', None)
        data_ptr = int(data.as_pointer()) if data is not None else 0
    except Exception:
        data_ptr = 0
    cache = _UI_MESH_STATS_CACHE
    if cache.get('object_ptr') == obj_ptr and cache.get('data_ptr') == data_ptr and (cache.get('mode') == mode) and (cache.get('signature') == signature) and isinstance(cache.get('stats'), dict):
        return dict(cache.get('stats') or {})
    return _lightweight_ui_mesh_stats(obj)

def _safe_template_list(layout, *args, **kwargs) -> bool:
    if _is_null_layout(layout):
        return False
    try:
        layout.template_list(*args, **kwargs)
        return True
    except Exception:
        return False

_INTEGRATED_CATEGORIES = frozenset({'VIEWPORT', 'SCULPT', 'BRUSH', 'SURFACE'})


def _smart_button_scale(settings) -> float:
    # 文字付きのボタンの高さ。アイコンサイズの設定（2.2〜8.0）を 1.2〜2.8 倍へ写す。
    value = float(getattr(settings, 'smart_upgrade_icon_scale', 4.4) or 4.4)
    return max(1.2, min(2.8, value * 0.35))


def _draw_integrated_navigation(layout, context) -> None:
    t = utils.ui_text
    box = _compact_npanel_layout(layout.box())
    header = box.row(align=True)
    header.label(text=t('Sculpt Navigation', 'スカルプトナビゲーション'), icon=utils.safe_icon('ORIENTATION_VIEW'))
    _draw_help_button(header, 'integrated:navigation')
    box.operator('sculptnav.focus_hud', text=t('Focus: Ignore Modifiers', 'フォーカス：無視するモディファイア'), icon=utils.safe_icon('ZOOM_SELECTED'))
    scene = getattr(context, 'scene', None)
    if scene is None or not hasattr(scene, 'sculptnav_ignored_collections'):
        return
    box.label(text=t('Ignored Collections', '無視コレクション'), icon=utils.safe_icon('OUTLINER_COLLECTION'))
    row = box.row()
    if _safe_template_list(row, 'SCULPTNAV_UL_ignored_collections', '', scene, 'sculptnav_ignored_collections', scene, 'sculptnav_ignored_collections_index', rows=3):
        buttons = row.column(align=True)
        buttons.operator('sculptnav.ignored_collection_add', icon='ADD', text='')
        buttons.operator('sculptnav.ignored_collection_remove', icon='REMOVE', text='')
    collections = scene.sculptnav_ignored_collections
    index = int(getattr(scene, 'sculptnav_ignored_collections_index', 0) or 0)
    if 0 <= index < len(collections):
        _draw_npanel_prop(box, collections[index], 'collection')


def _draw_integrated_mask(layout, context, *, include_selection: bool) -> None:
    t = utils.ui_text
    box = _compact_npanel_layout(layout.box())
    header = box.row(align=True)
    header.label(text=t('Mask / Face Set Tools', 'マスク/フェイスセットツール'), icon=utils.safe_icon('MOD_MASK'))
    _draw_help_button(header, 'integrated:mask_facesets_tools')
    pie_row = box.row(align=True)
    pie_row.enabled = _safe_object_mode(getattr(context, 'active_object', None)) == 'SCULPT'
    pie = pie_row.operator('wm.call_menu_pie', text=t('Mask / Face Set Pie', 'マスク/フェイスセットのパイ'), icon=utils.safe_icon('MENU_PANEL'))
    pie.name = 'SCULPTMASKSUPPORT_MT_piemenu'
    if include_selection:
        box.operator('sculptmask.selection_to_mask', text=t('Selection to Mask', '選択をスカルプトマスクへ'), icon=utils.safe_icon('MOD_MASK'))


def _draw_migrated_category(layout, context, category_key: str) -> bool:
    if _is_null_layout(layout):
        return False
    category = str(category_key or '').upper()
    if category not in _INTEGRATED_CATEGORIES:
        return False
    layout = utils.localized_layout(layout)
    try:
        if category in {'VIEWPORT', 'SCULPT'}:
            _draw_integrated_navigation(layout, context)
        if category in {'BRUSH', 'SCULPT'}:
            _draw_integrated_mask(layout, context, include_selection=False)
        if category == 'SURFACE':
            _draw_integrated_mask(layout, context, include_selection=True)
        return True
    except Exception as exc:
        try:
            layout.label(text=f"{utils.ui_text('Migrated controls draw failed', '移植済み操作の描画に失敗')}: {utils.exception_ui_text(exc)}", icon='ERROR')
        except Exception:
            pass
        return False

class SSS_UL_snapshots(UIList):
    bl_idname = 'SSS_UL_snapshots'

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0):
        t = utils.ui_text
        layout = utils.localized_layout(layout)
        col = layout.column(align=True)
        name = str(getattr(item, 'name', '') or '')
        vertex_count = int(getattr(item, 'vertex_count', 0) or 0)
        polygon_count = int(getattr(item, 'polygon_count', 0) or 0)
        modifier_count = int(getattr(item, 'modifier_count', 0) or 0)
        shape_key_count = int(getattr(item, 'shape_key_count', 0) or 0)
        col.label(text=_clip_ui_text(name, 22), icon='RECOVER_LAST', translate=False)
        info = f'V:{vertex_count:,} F:{polygon_count:,}'
        if modifier_count:
            info += f' M:{modifier_count}'
        if shape_key_count:
            info += f' K:{shape_key_count}'
        col.label(text=_clip_ui_text(info, 24))

class SSS_MT_quick_pie(Menu):
    bl_idname = 'SSS_MT_quick_pie'
    bl_label = 'Smart Sculpt Quick Pie'

    def draw(self, context):
        t = utils.ui_text
        pie = utils.localized_layout(self.layout).menu_pie()
        op = pie.operator('smart_sculpt.set_sculpt_tool', text=t('Draw', '描画'), icon='BRUSH_DATA')
        op.tool = 'DRAW'
        op = pie.operator('smart_sculpt.set_sculpt_tool', text=t('Smooth', 'スムーズ'), icon='MOD_SMOOTH')
        op.tool = 'SMOOTH'
        op = pie.operator('smart_sculpt.set_sculpt_tool', text=t('Grab', 'つかみ'), icon='HAND')
        op.tool = 'GRAB'
        op = pie.operator('smart_sculpt.set_sculpt_tool', text=t('Pose', 'ポーズ'), icon='ARMATURE_DATA')
        op.tool = 'POSE'
        pie.operator('smart_sculpt.configure_dyntopo', text=t('Dyntopo', 'ダイナミックトポロジー'), icon='SCULPTMODE_HLT')
        pie.operator('smart_sculpt.voxel_remesh', text=t('Voxel Remesh', 'ボクセルリメッシュ'), icon='MOD_REMESH')
        pie.operator('smart_sculpt.mask_extract', text=t('Extract Mask', 'マスク抽出'), icon='MOD_SOLIDIFY')
        pie.operator('smart_sculpt.save_snapshot', text=t('Snapshot', 'スナップショット'), icon='RECOVER_LAST')

def _object_mode_name(mode: str) -> str:
    """Return Blender's own display name for an Object.mode identifier."""
    try:
        return str(bpy.types.Object.bl_rna.properties['mode'].enum_items[str(mode)].name)
    except Exception:
        return str(mode)

class SSS_PT_main(Panel):
    bl_idname = 'SSS_PT_main'
    bl_label = 'Smart Sculpt'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Sculpt'

    @classmethod
    def poll(cls, context):
        del cls
        try:
            return _is_native_npanel_context(context) and _safe_context_scene(context) is not None
        except Exception:
            return False

    def _op(self, layout, operator_id: str, *, text: str='', icon: str='NONE', icon_value: int=0, emboss=None, **props):
        layout = _compact_npanel_layout(layout)
        kwargs = {'text': text}
        try:
            icon_value_int = int(icon_value or 0)
        except Exception:
            icon_value_int = 0
        try:
            if icon_value_int > 0:
                kwargs['icon_value'] = icon_value_int
            elif icon and icon != 'NONE':
                kwargs['icon'] = utils.safe_icon(icon)
        except Exception:
            if icon and icon != 'NONE':
                kwargs['icon'] = utils.safe_icon(icon)
        if emboss is not None:
            has_icon_only_label = not str(text or '') and (icon_value_int > 0 or (icon and icon != 'NONE'))
            kwargs['emboss'] = True if has_icon_only_label else bool(emboss)
        try:
            op = layout.operator(operator_id, **kwargs)
        except TypeError:
            kwargs.pop('emboss', None)
            try:
                op = layout.operator(operator_id, **kwargs)
            except TypeError:
                kwargs.pop('icon_value', None)
                if icon and icon != 'NONE':
                    kwargs['icon'] = utils.safe_icon(icon)
                op = layout.operator(operator_id, **kwargs)
        for name, value in props.items():
            setattr(op, name, value)
        return op

    def _draw_diagnostics_summary(self, layout, settings):
        t = utils.ui_text
        if not getattr(settings, 'diagnostics', None):
            return
        diag_box = layout.box()
        diag_box.label(text=t('Latest Diagnostics', '最新診断'))
        for item in list(settings.diagnostics):
            icon = 'DOT' if item.severity == 'INFO' else 'ERROR' if item.severity == 'ERROR' else 'QUESTION'
            col = diag_box.column(align=True)
            _draw_wrapped_label(col, None, item.title, icon=icon)
            if item.detail:
                _draw_wrapped_label(col, None, item.detail)

    def _popup_op(self, layout, operator_id: str, *, text: str, icon: str='NONE', **props):
        operator_id = str(operator_id or '').strip()
        if not operator_id:
            return None
        kwargs = {'text': text}
        if icon and icon != 'NONE':
            kwargs['icon'] = utils.safe_icon(icon)
        op = layout.operator(operator_id, **kwargs)
        for name, value in props.items():
            setattr(op, name, value)
        return op

    def _help_button(self, layout, topic_id: str, *, text: str='', icon: str='QUESTION') -> bool:
        return _draw_help_button(layout, topic_id, text=text, icon=icon)

    def _box_header(self, box, title_en: str, title_ja: str, icon: str, topic_id: str) -> None:
        _draw_box_header(box, title_en, title_ja, icon, topic_id)

    def _section_box(self, layout, context, settings, section_key: str, title_en: str, title_ja: str, icon: str, topic_id: str | None=None, *, default: bool=False):
        return _draw_section_box(layout, context, settings, section_key, title_en, title_ja, icon, topic_id or section_key, default=default)

    def _section_box_or_empty(self, layout, context, settings, section_key: str, title_en: str, title_ja: str, icon: str, topic_id: str | None=None, *, default: bool=False):
        return _draw_section_box_or_empty(layout, context, settings, section_key, title_en, title_ja, icon, topic_id or section_key, default=default)

    def _draw_integrated_section(self, layout, context, settings, section_key: str, title_en: str, title_ja: str, icon: str, topic_id: str | None=None, *, default: bool=False, category: str='') -> None:
        # 中身の無い統合の枠は見出しごと出さない。
        if str(category or '').upper() not in _INTEGRATED_CATEGORIES:
            return
        body = self._section_box_or_empty(layout, context, settings, section_key, title_en, title_ja, icon, topic_id, default=default)
        _draw_migrated_category(body, context, category)

    def _section(self, layout, context, settings, section_key: str, title_en: str, title_ja: str, icon: str, topic_id: str, draw_fn, *, default: bool=False) -> bool:
        if _is_top_level_section(section_key):
            header_box = _compact_npanel_layout(layout.box())
            expanded = _draw_section_header(header_box, context, settings, section_key, title_en, title_ja, icon, topic_id, default=default)
            if not expanded:
                return False
            body = _compact_npanel_layout(utils.localized_layout(header_box.column(align=True)))
        else:
            body = self._section_box(layout, context, settings, section_key, title_en, title_ja, icon, topic_id, default=default)
            if body is None:
                return False
        try:
            draw_fn(body)
            return True
        except Exception as exc:
            try:
                target = body if body is not None else layout
                target.label(text=f"{utils.ui_text('Section draw failed', 'セクション描画に失敗')}: {utils.exception_ui_text(exc)}", icon=utils.safe_icon('ERROR'))
            except Exception:
                pass
            return False

    def _button_grid(self, layout, *, columns: int=2):
        del columns
        return _compact_npanel_layout(layout.column(align=True))

    def _draw_label_stack(self, layout, lines, *, icon: str='NONE') -> None:
        first = True
        for line in list(lines or ()):
            line = str(line or '').strip()
            if not line:
                continue
            if first and icon and (icon != 'NONE'):
                layout.label(text=line, icon=utils.safe_icon(icon))
                first = False
            else:
                layout.label(text=line)
                first = False

    def _draw_always_on_toggles(self, layout, context, settings):
        try:
            persistent_controls = _loaded_sibling_module('core.controls')
            draw_controls = getattr(persistent_controls, 'draw_persistent_controls', None)
            if callable(draw_controls):
                draw_controls(layout, context, settings)
        except Exception as exc:
            try:
                box = layout.box()
                box.label(text=f"{utils.ui_text('Always-on toggle draw failed', '常時起動切り替えの描画に失敗しました')}: {utils.exception_ui_text(exc)}", icon=utils.safe_icon('ERROR'))
            except Exception:
                pass

    def _draw_full_access(self, layout, context, settings, obj):
        t = utils.ui_text
        utility_box = self._section_box(layout, context, settings, 'direct_access', 'Direct Access', '直接アクセス', 'TOOL_SETTINGS', 'tab_all', default=False)
        if utility_box is not None:
            pie_proxy_id = ''
            enum_popup_id = ''
            try:
                pie_proxy_id = str(_navigation_properties.popup_menu_pie_proxy_operator_id() or '')
            except Exception:
                pie_proxy_id = ''
            try:
                enum_popup_id = str(_navigation_properties.popup_operator_enum_operator_id() or '')
            except Exception:
                enum_popup_id = ''
            row = _compact_npanel_layout(utility_box.column(align=True))
            if pie_proxy_id:
                self._popup_op(row, pie_proxy_id, text=t('Quick Pie', 'クイックパイ'), icon='MENU_PANEL', menu_idname='SSS_MT_quick_pie', popup_label=t('Smart Sculpt Quick Pie', 'スマートスカルプトクイックパイ'))
            else:
                op = row.operator('wm.call_menu_pie', text=t('Quick Pie', 'クイックパイ'), icon='MENU_PANEL')
                op.name = 'SSS_MT_quick_pie'
            if enum_popup_id:
                row = _compact_npanel_layout(utility_box.column(align=True))
                self._popup_op(row, enum_popup_id, text=t('Viewport Presets', '表示プリセット一覧'), icon='SHADING_SOLID', operator_idname='smart_sculpt.set_viewport_preset', property_idname='preset', popup_label=t('Viewport Presets', '表示プリセット一覧'))
                self._popup_op(row, enum_popup_id, text=t('Profiles', 'プロファイル一覧'), icon='SETTINGS', operator_idname='smart_sculpt.apply_profile', property_idname='profile', popup_label=t('Smart Sculpt Profiles', 'スマートスカルプトプロファイル一覧'))
        self._draw_compact_smart(layout, context, settings, obj)
        self.draw_dashboard(layout, context, settings, obj)
        self.draw_topology(layout, context, settings, obj)
        self.draw_procedural(layout, context, settings, obj)
        self.draw_nondestructive(layout, context, settings, obj)
        self.draw_retopo(layout, context, settings, obj)
        migrated_labels = {'SCULPT': ('integrated_sculpt_all', 'Integrated Sculpt Tools', '統合スカルプトツール', 'SCULPTMODE_HLT', 'tab_sculpt'), 'SMART': ('integrated_smart_all', 'Integrated Smart Tools', '統合スマートツール', 'AUTO', 'tab_smart'), 'SURFACE': ('integrated_surface_all', 'Integrated Surface Tools', '統合サーフェイスツール', 'MOD_REMESH', 'tab_surface'), 'BUILD': ('integrated_build_all', 'Integrated Build Tools', '統合造形ツール', 'MESH_CUBE', 'tab_build'), 'SAFE': ('integrated_safe_all', 'Integrated Safe Tools', '統合安全ツール', 'RECOVER_LAST', 'tab_safe'), 'SETTINGS': ('integrated_settings_all', 'Integrated Settings', '統合設定', 'PREFERENCES', 'settings_all')}
        for category in ('SCULPT', 'SMART', 'SURFACE', 'BUILD', 'SAFE', 'SETTINGS'):
            key, title_en, title_ja, icon, topic = migrated_labels[category]
            self._draw_integrated_section(layout, context, settings, key, title_en, title_ja, icon, topic, default=False, category=category)

    def _draw_active_target_summary(self, layout, context, settings, obj):
        del settings
        t = utils.ui_text
        col = _compact_npanel_layout(layout.column(align=True))
        mode_label = _safe_object_mode(obj)
        col.label(text=_safe_object_name(obj, t('No Mesh', 'メッシュなし')), translate=False, icon=utils.safe_icon('MESH_DATA' if obj else 'ERROR'))
        if obj is None:
            _draw_wrapped_label(col, context, t('Select a mesh object to use object-dependent Smart Sculpt tools.', 'オブジェクト依存のスマートスカルプト機能を使うにはメッシュオブジェクトを選択してください。'))
            return
        counts = _safe_topology_signature(obj)
        col.label(text=f"{t('Mode', 'モード')}: {bpy.app.translations.pgettext_iface(_object_mode_name(mode_label or 'OBJECT'))}")
        col.label(text=f"{t('Vertices', '頂点')}: {counts[0]:,}")
        col.label(text=f"{t('Edges', '辺')}: {counts[1]:,}")
        col.label(text=f"{t('Faces', '面')}: {counts[2]:,}")
        if mode_label and mode_label != 'OBJECT':
            _draw_wrapped_label(col, context, t('Object-data lists and detailed mesh diagnostics are held while this object is not in Object mode.', 'オブジェクト以外のモードでは、オブジェクトデータ一覧と詳細メッシュ診断を一時停止します。'))

    def _smart_action_run_kwargs(self, settings, action: str) -> dict:
        return {'action': str(action or '').strip().upper(), 'strength': getattr(settings, 'smart_upgrade_strength', 0.0), 'density': getattr(settings, 'smart_upgrade_density', 0.0), 'count': getattr(settings, 'smart_upgrade_count', 0), 'segments': getattr(settings, 'smart_upgrade_segments', 0), 'use_voxel': getattr(settings, 'smart_upgrade_use_voxel', True), 'use_multires': getattr(settings, 'smart_upgrade_use_multires', True)}

    def _draw_smart_action_group(self, layout, context, settings, section_key: str, title_en: str, title_ja: str, icon: str, actions, topic_id: str) -> None:
        if not bool(getattr(settings, 'smart_upgrade_show_icon_board', True)):
            return
        box = self._section_box_or_empty(layout, context, settings, section_key, title_en, title_ja, icon, topic_id, default=False)
        obj = utils.active_mesh_object(context)
        safe_custom_icons = _object_data_lists_are_safe(context, obj)
        for action in tuple(actions or ()):
            action = str(action or '').strip().upper()
            if not action:
                continue
            label = _clip_ui_text(self._smart_action_label(action), 30)
            icon_value = icon_assets.action_icon_value(action) if safe_custom_icons else 0
            self._op(box, 'smart_sculpt.run_smart_upgrade_tool', text=label, icon=icon_assets.action_fallback_icon(action), icon_value=icon_value, **self._smart_action_run_kwargs(settings, action))

    def _draw_edit_mode_sculpt(self, layout, context, settings, obj):
        del obj
        t = utils.ui_text
        edit_mod = _loaded_sibling_module('edit_mode_sculpt')
        if edit_mod is None:
            try:
                layout.label(text=t('Edit Mode Sculpt module is not available.', '編集モード専用スカルプトを取得できません。'), icon=utils.safe_icon('ERROR'))
            except Exception:
                pass
            return
        try:
            ensure_edit = getattr(edit_mod, '_ensure_edit_mesh', None)
            if callable(ensure_edit) and ensure_edit(context) is None:
                info_box = layout.box()
                _draw_wrapped_label(info_box, context, t('This section is designed for Mesh Edit Mode.', 'このセクションはメッシュ編集モード専用です。'), icon=utils.safe_icon('EDITMODE_HLT'))
                _draw_wrapped_label(info_box, context, t('Select a mesh and enter Edit Mode before running mesh-changing tools.', 'メッシュを選択して編集モードに入ってから、メッシュを変更する機能を実行してください。'))
                obj_candidate = utils.active_mesh_object(context)
                if obj_candidate is not None:
                    try:
                        op = info_box.operator('object.mode_set', text=t('Enter Mesh Edit Mode', 'メッシュ編集モードへ'), icon=utils.safe_icon('EDITMODE_HLT'))
                        op.mode = 'EDIT'
                    except Exception:
                        pass
        except Exception:
            pass
        draw_fn = getattr(edit_mod, 'draw_integrated_ui', None)
        if not callable(draw_fn):
            layout.label(text=t('Edit Mode Sculpt UI is unavailable.', '編集モード専用スカルプトUIを取得できません。'), icon=utils.safe_icon('ERROR'))
            return
        try:
            draw_fn(layout, context)
        except Exception as exc:
            try:
                layout.label(text=f"{t('Edit Mode Sculpt UI draw failed', '編集モード専用スカルプトUIの描画に失敗しました')}: {utils.exception_ui_text(exc)}", icon=utils.safe_icon('ERROR'))
            except Exception:
                pass

    def _draw_top_viewport(self, layout, context, settings, obj):
        del obj
        t = utils.ui_text
        view_box = self._section_box_or_empty(layout, context, settings, 'viewport_visibility_tools', 'Viewport Visibility', 'ビューポート視認性', 'SHADING_SOLID', 'top_viewport', default=False)
        _draw_npanel_prop(view_box, settings, 'compact_viewport_preset', text=t('Viewport Preset', '表示プリセット'))
        self._op(view_box, 'smart_sculpt.set_viewport_preset', text=t('Apply Selected View', '選択表示を適用'), icon='SHADING_SOLID', preset=settings.compact_viewport_preset)
        self._op(view_box, 'smart_sculpt.toggle_silhouette', text=t('Toggle Silhouette', 'シルエット切り替え'), icon='SHADING_SOLID')
        for preset, label_en, label_ja, icon in (('CLAY', 'Clay View', 'クレイ表示', 'SHADING_SOLID'), ('TECHNICAL', 'Technical View', 'テクニカル表示', 'MOD_WIREFRAME'), ('FACESETS', 'Face Set View', 'フェイスセット表示', 'MESH_GRID'), ('WIREFRAME', 'Wireframe View', 'ワイヤーフレーム表示', 'MOD_WIREFRAME')):
            self._op(view_box, 'smart_sculpt.set_viewport_preset', text=t(label_en, label_ja), icon=icon, preset=preset)
        popup_box = self._section_box_or_empty(layout, context, settings, 'viewport_popup_access', 'Viewport Popup', 'ビューポートポップアップ', 'MENU_PANEL', 'top_viewport', default=False)
        enum_popup_id = ''
        try:
            enum_popup_id = str(_navigation_properties.popup_operator_enum_operator_id() or '')
        except Exception:
            enum_popup_id = ''
        if enum_popup_id:
            self._popup_op(popup_box, enum_popup_id, text=t('Viewport Presets', '表示プリセット一覧'), icon='SHADING_SOLID', operator_idname='smart_sculpt.set_viewport_preset', property_idname='preset', popup_label=t('Viewport Presets', '表示プリセット一覧'))
        else:
            _draw_wrapped_label(popup_box, context, t('Viewport preset popup is not available in this context.', 'このコンテキストでは表示プリセットポップアップを利用できません。'))
        self._draw_integrated_section(layout, context, settings, 'integrated_viewport_tools', 'Integrated Viewport Tools', '統合ビューポートツール', 'SHADING_SOLID', 'top_viewport', default=False, category='VIEWPORT')

    def _draw_top_efficiency(self, layout, context, settings, obj):
        t = utils.ui_text
        target = self._section_box_or_empty(layout, context, settings, 'efficiency_active_target', 'Active Target', 'アクティブ対象', 'MESH_DATA', 'top_efficiency', default=False)
        self._draw_active_target_summary(target, context, settings, obj)
        workflow = self._section_box_or_empty(layout, context, settings, 'efficiency_workflow', 'Workflow Launcher', 'ワークフロー実行', 'TOOL_SETTINGS', 'top_efficiency', default=False)
        _draw_npanel_prop(workflow, settings, 'core_action', text=t('Action', '操作'))
        action = str(getattr(settings, 'core_action', 'PREPARE') or 'PREPARE')
        if action == 'MULTI_OBJECT':
            _draw_npanel_prop(workflow, settings, 'multi_object_make_single_user', text=t('Make Shared Meshes Single-User', '共有メッシュをシングルユーザー化'))
        action_map = {'PREPARE': ('smart_sculpt.prepare_workspace', t('Run Core Setup', 'コア設定を実行'), 'TOOL_SETTINGS', {}), 'MULTI_OBJECT': ('smart_sculpt.prepare_multi_object_sculpt', t('Prepare Multi-Object', '複数オブジェクト準備'), 'GROUP', {}), 'CYCLE_PREV': ('smart_sculpt.cycle_selected_mesh', t('Previous Part', '前パーツ'), 'TRIA_LEFT', {'direction': 'PREV'}), 'CYCLE_NEXT': ('smart_sculpt.cycle_selected_mesh', t('Next Part', '次パーツ'), 'TRIA_RIGHT', {'direction': 'NEXT'}), 'ANALYZE': ('smart_sculpt.analyze_active_mesh', t('Analyze Active Mesh', 'アクティブメッシュ解析'), 'VIEWZOOM', {}), 'FIX': ('smart_sculpt.fix_common_issues', t('Run Common Fix', '共通修正を実行'), 'FILE_REFRESH', {}), 'REPORT': ('smart_sculpt.export_diagnostic_report', t('Export Diagnostic Report', '診断レポートを書き出し'), 'TEXT', {})}
        op_id, label, icon, props = action_map.get(action, action_map['PREPARE'])
        self._op(workflow, op_id, text=label, icon=icon, **props)
        _draw_npanel_prop(workflow, settings, 'auto_enter_sculpt', text=t('Auto Enter Sculpt', '自動でスカルプトへ'))
        direct = self._section_box_or_empty(layout, context, settings, 'efficiency_direct_access', 'Direct Access', '直接アクセス', 'MENU_PANEL', 'top_efficiency', default=False)
        pie_proxy_id = ''
        enum_popup_id = ''
        try:
            pie_proxy_id = str(_navigation_properties.popup_menu_pie_proxy_operator_id() or '')
            enum_popup_id = str(_navigation_properties.popup_operator_enum_operator_id() or '')
        except Exception:
            pass
        if pie_proxy_id:
            self._popup_op(direct, pie_proxy_id, text=t('Quick Pie', 'クイックパイ'), icon='MENU_PANEL', menu_idname='SSS_MT_quick_pie', popup_label=t('Smart Sculpt Quick Pie', 'スマートスカルプトクイックパイ'))
        else:
            op = direct.operator('wm.call_menu_pie', text=t('Quick Pie', 'クイックパイ'), icon=utils.safe_icon('MENU_PANEL'))
            op.name = 'SSS_MT_quick_pie'
        if enum_popup_id:
            self._popup_op(direct, enum_popup_id, text=t('Workflow Profiles', 'ワークフロープロファイル一覧'), icon='SETTINGS', operator_idname='smart_sculpt.apply_profile', property_idname='profile', popup_label=t('Smart Sculpt Profiles', 'スマートスカルプトプロファイル一覧'))
        smart = self._section_box_or_empty(layout, context, settings, 'efficiency_smart_launcher', 'Smart Workflow', 'スマートワークフロー', 'AUTO', 'top_efficiency', default=False)
        _draw_npanel_prop(smart, settings, 'smart_upgrade_action', text=t('Action', '操作'))
        self._op(smart, 'smart_sculpt.run_smart_upgrade_tool', text=t('Run Selected Smart Action', '選択スマートアクションを実行'), icon='PLAY', **self._smart_action_run_kwargs(settings, getattr(settings, 'smart_upgrade_action', 'APEX_AUTOPILOT_PASS')))
        _draw_npanel_prop(smart, settings, 'smart_upgrade_show_icon_board', text=t('Smart Action Buttons', 'スマートアクションボタン'))
        _draw_npanel_prop(smart, settings, 'smart_upgrade_show_metrics', text=t('Live Metrics', 'ライブ指標'))
        _draw_npanel_prop(smart, settings, 'smart_upgrade_icon_scale', text=t('Icon Size', 'アイコンサイズ'))
        self._draw_smart_action_group(layout, context, settings, 'efficiency_smart_actions', 'Workflow Smart Actions', 'ワークフロースマート実行', 'AUTO', ('APEX_AUTOPILOT_PASS', 'SUPREME_STUDIO_PIPELINE', 'PRECISION_FRONTIER_PASS', 'ADAPTIVE_MASTER_PASS', 'MULTI_OBJECT_HARMONIZER', 'SPEED_BLOCKOUT'), 'top_efficiency')
        session = self._section_box_or_empty(layout, context, settings, 'efficiency_sculpt_session', 'Sculpt Sessions', 'スカルプトセッション管理', 'DUPLICATE', 'top_efficiency', default=False)
        _draw_npanel_prop(session, settings, 'session_action', text=t('Action', '操作'))
        if settings.session_action == 'CREATE':
            _draw_npanel_prop(session, settings, 'session_mode', text=t('Session Mode', 'セッションモード'))
            _draw_npanel_prop(session, settings, 'session_face_set_mode', text=t('Face Set Mode', 'フェイスセットモード'))
            _draw_npanel_prop(session, settings, 'session_initialize_face_sets', text=t('Legacy Face Set Fallback', '旧フェイスセット補完'))
            _draw_npanel_prop(session, settings, 'hide_originals_on_proxy', text=t('Hide Originals', '元を隠す'))
            self._op(session, 'smart_sculpt.create_proxy_session', text=t('Create Sculpt Session', 'スカルプトセッション作成'), icon='DUPLICATE')
        elif settings.session_action == 'RESTORE':
            self._op(session, 'smart_sculpt.restore_proxy_sources', text=t('Restore Session Sources', '元オブジェクトを再表示'), icon='HIDE_OFF')
        else:
            self._op(session, 'smart_sculpt.close_sculpt_session', text=t('Close Sculpt Session', 'スカルプトセッション終了'), icon='PANEL_CLOSE')

    def _draw_top_brush(self, layout, context, settings, obj):
        del obj
        t = utils.ui_text
        tool_box = self._section_box_or_empty(layout, context, settings, 'brush_consolidated_tools', 'Brush Tools', 'ブラシ操作', 'BRUSH_DATA', 'top_brush', default=False)
        _draw_npanel_prop(tool_box, settings, 'quick_tool', text=t('Quick Tool', 'クイックツール'))
        self._op(tool_box, 'smart_sculpt.set_sculpt_tool', text=t('Activate Tool', 'ツールを有効化'), icon='BRUSH_DATA', tool=settings.quick_tool)
        _draw_npanel_prop(tool_box, settings, 'profile', text=t('Workflow Profile', 'ワークフロープロファイル'))
        self._op(tool_box, 'smart_sculpt.apply_profile', text=t('Apply Profile', 'プロファイル適用'), icon='PLAY', profile=settings.profile)
        slot = max(1, min(3, int(getattr(settings, 'tool_pipe_slot_index', 1) or 1)))
        slot_attr = utils.tool_pipe_slot_attr(slot)
        _draw_npanel_prop(tool_box, settings, 'tool_pipe_slot_index', text=t('Favorite Slot', 'お気に入りスロット'))
        _draw_npanel_prop(tool_box, settings, slot_attr, text=t('Stored Brush', '保存ブラシ'))
        self._op(tool_box, 'smart_sculpt.use_brush_slot', text=t('Recall', '呼び出し'), icon='PLAY', slot=slot)
        self._op(tool_box, 'smart_sculpt.store_active_brush_slot', text=t('Save', '保存'), icon='IMPORT', slot=slot)
        self._op(tool_box, 'smart_sculpt.clear_brush_slot', text=t('Clear Slot', 'スロット消去'), icon='X', slot=slot)
        tool_box.label(text=utils.tool_pipe_slot_label(settings, slot), icon='BRUSH_DATA')
        quick = self._section_box_or_empty(layout, context, settings, 'brush_quick_buttons', 'Quick Brushes', 'クイックブラシ', 'BRUSH_DATA', 'top_brush', default=False)
        for tool_id, label_en, label_ja, icon in (('DRAW', 'Draw', '描画', 'BRUSH_DATA'), ('CLAY', 'Clay', 'クレイ', 'SCULPTMODE_HLT'), ('CLAY_STRIPS', 'Clay Strips', 'クレイストリップ', 'MESH_PLANE'), ('GRAB', 'Grab', 'つかみ', 'HAND'), ('SMOOTH', 'Smooth', 'スムーズ', 'MOD_SMOOTH'), ('SCRAPE', 'Scrape', 'スクレイプ', 'MOD_WIREFRAME'), ('POSE', 'Pose', 'ポーズ', 'ARMATURE_DATA'), ('CLOTH', 'Cloth', 'クロス', 'MOD_CLOTH'), ('DRAW_SHARP', 'Draw Sharp', 'シャープ描画', 'GREASEPENCIL'), ('CREASE', 'Crease', 'クリーズ', 'IPO_EASE_IN_OUT')):
            self._op(quick, 'smart_sculpt.set_sculpt_tool', text=t(label_en, label_ja), icon=icon, tool=tool_id)
        filters = self._section_box_or_empty(layout, context, settings, 'brush_filter_tools', 'Brush-like Filters', 'ブラシ系フィルター', 'MOD_SMOOTH', 'top_brush', default=False)
        _draw_npanel_prop(filters, settings, 'compact_filter_domain', text=t('Filter Domain', 'フィルター対象'))
        _draw_npanel_prop(filters, settings, 'filter_strength', text=t('Strength', '強度'))
        if getattr(settings, 'compact_filter_domain', 'MESH') == 'MESH':
            _draw_npanel_prop(filters, settings, 'mesh_filter_type', text=t('Mesh Filter', 'メッシュフィルター'))
            self._op(filters, 'smart_sculpt.apply_mesh_filter', text=t('Apply Mesh Filter', 'メッシュフィルター適用'), icon='MOD_SMOOTH', filter_type=settings.mesh_filter_type, strength=settings.filter_strength)
        else:
            _draw_npanel_prop(filters, settings, 'cloth_filter_type', text=t('Cloth Filter', 'クロスフィルター'))
            self._op(filters, 'smart_sculpt.apply_cloth_filter', text=t('Apply Cloth Filter', 'クロスフィルター適用'), icon='MOD_CLOTH', filter_type=settings.cloth_filter_type, strength=settings.filter_strength)
        zbrush_brush = self._section_box_or_empty(layout, context, settings, 'zbrush_gap_brush_tools', 'IMM / VDM / Layers', 'IMM / VDM / レイヤー', 'BRUSH_DATA', 'top_brush', default=False)
        _draw_npanel_prop(zbrush_brush, settings, 'zbrush_gap_imm_part', text=t('IMM Part', 'IMMパーツ'))
        _draw_npanel_prop(zbrush_brush, settings, 'zbrush_gap_imm_count', text=t('IMM Count', 'IMM個数'))
        _draw_npanel_prop(zbrush_brush, settings, 'zbrush_gap_imm_spacing', text=t('IMM Spacing', 'IMM間隔'))
        self._op(zbrush_brush, 'smart_sculpt.insert_multi_mesh_part', text=t('Insert Multi Mesh', 'インサートマルチメッシュ生成'), icon='MESH_CUBE')
        _draw_npanel_prop(zbrush_brush, settings, 'zbrush_gap_vdm_stamp', text=t('VDM Stamp', 'VDMスタンプ'))
        _draw_npanel_prop(zbrush_brush, settings, 'zbrush_gap_detail_strength', text=t('Detail Strength', 'ディテール強度'))
        self._op(zbrush_brush, 'smart_sculpt.vdm_stamp', text=t('Create VDM Stamp', 'VDMスタンプ作成'), icon='TEXTURE')
        _draw_npanel_prop(zbrush_brush, settings, 'zbrush_gap_layer_action', text=t('3D Layer', '3Dレイヤー'))
        self._op(zbrush_brush, 'smart_sculpt.sculpt_layer_pro_action', text=t('Run 3D Layer Action', '3Dレイヤー操作を実行'), icon='SHAPEKEY_DATA')
        _draw_npanel_prop(zbrush_brush, settings, 'zbrush_gap_morph_action', text=t('Morph Target', 'モーフターゲット'))
        self._op(zbrush_brush, 'smart_sculpt.morph_target_action', text=t('Run Morph Target Action', 'モーフターゲット操作を実行'), icon='RECOVER_LAST')
        self._draw_smart_action_group(layout, context, settings, 'brush_smart_actions', 'Brush Smart Actions', 'ブラシスマート実行', 'BRUSH_DATA', ('SCULPT_TRANSFER_PROFILE', 'PROCEDURAL_MICRODETAIL_BRUSH'), 'top_brush')
        self._draw_integrated_section(layout, context, settings, 'integrated_brush_tools', 'Integrated Brush Tools', '統合ブラシツール', 'BRUSH_DATA', 'top_brush', default=False, category='BRUSH')

    def _draw_top_remesh_retopo(self, layout, context, settings, obj):
        del obj
        t = utils.ui_text
        launcher = self._section_box_or_empty(layout, context, settings, 'remesh_retopo_launcher', 'Remesh / Retopo Launcher', 'リメッシュ/リトポ実行', 'MOD_REMESH', 'top_remesh_retopo', default=False)
        _draw_npanel_prop(launcher, settings, 'surface_action', text=t('Action', '操作'))
        action = str(getattr(settings, 'surface_action', 'DYNTOPO') or 'DYNTOPO')
        if action in {'DYNTOPO', 'FLOOD'}:
            self._op(launcher, 'smart_sculpt.configure_dyntopo' if action == 'DYNTOPO' else 'smart_sculpt.detail_flood_fill', text=t('Run Selected Topology Action', '選択トポロジー操作を実行'), icon='MOD_TRIANGULATE')
        elif action == 'REMESH':
            self._op(launcher, 'smart_sculpt.voxel_remesh' if getattr(settings, 'compact_remesh_mode', 'VOXEL') == 'VOXEL' else 'smart_sculpt.quadriflow_remesh', text=t('Run Selected Topology Action', '選択トポロジー操作を実行'), icon='MOD_REMESH')
        elif action == 'MULTIRES':
            self._op(launcher, 'smart_sculpt.multires_action', text=t('Run Selected Topology Action', '選択トポロジー操作を実行'), icon='MOD_MULTIRES', action=settings.compact_multires_action)
        elif action == 'MASK':
            if settings.compact_mask_action == 'EXTRACT':
                self._op(launcher, 'smart_sculpt.mask_extract', text=t('Run Selected Topology Action', '選択トポロジー操作を実行'), icon='MOD_SOLIDIFY')
            elif settings.compact_mask_action == 'SLICE':
                self._op(launcher, 'smart_sculpt.mask_slice', text=t('Run Selected Topology Action', '選択トポロジー操作を実行'), icon='MESH_CUBE')
            else:
                self._op(launcher, 'smart_sculpt.mask_action', text=t('Run Selected Topology Action', '選択トポロジー操作を実行'), icon='BRUSH_DATA', action=settings.compact_mask_action)
        elif action == 'FACE_SET':
            if settings.compact_face_set_action == 'EXTRACT':
                self._op(launcher, 'smart_sculpt.face_set_extract', text=t('Run Selected Topology Action', '選択トポロジー操作を実行'), icon='MESH_GRID')
            else:
                mapping = {'LOOSE_PARTS': 'INIT_LOOSE', 'MATERIALS': 'INIT_MATERIALS', 'NORMALS': 'INIT_NORMALS', 'UV_SEAMS': 'INIT_UV_SEAMS', 'SHARP_EDGES': 'INIT_SHARP_EDGES', 'CREASES': 'INIT_CREASES', 'BEVEL_WEIGHT': 'INIT_BEVEL_WEIGHT'}
                face_action = settings.compact_face_set_action
                self._op(launcher, 'smart_sculpt.face_set_action', text=t('Run Selected Topology Action', '選択トポロジー操作を実行'), icon='MESH_GRID', action=mapping.get(face_action, face_action))
        elif action == 'RETOPO':
            self._op(launcher, 'smart_sculpt.create_retopo_setup', text=t('Run Selected Topology Action', '選択トポロジー操作を実行'), icon='SNAP_FACE')
        elif action == 'AUTO_UV':
            self._op(launcher, 'smart_sculpt.auto_uv_project', text=t('Run Selected Topology Action', '選択トポロジー操作を実行'), icon='GROUP_UVS')
        else:
            _draw_wrapped_label(launcher, context, t('Filter actions are available in the Brush section.', 'フィルター操作はブラシセクションに集約されています。'))
        dyntopo = self._section_box_or_empty(layout, context, settings, 'dyntopo_tools', 'Dyntopo', 'ダイナミックトポロジー', 'MOD_TRIANGULATE', 'top_remesh_retopo', default=False)
        _draw_npanel_prop(dyntopo, settings, 'dyntopo_mode', text=t('Mode', 'モード'))
        _draw_npanel_prop(dyntopo, settings, 'dyntopo_detail', text=t('Detail', '細かさ'))
        self._op(dyntopo, 'smart_sculpt.configure_dyntopo', text=t('Configure Dyntopo', 'ダイナミックトポロジーを設定'), icon='MOD_TRIANGULATE')
        self._op(dyntopo, 'smart_sculpt.detail_flood_fill', text=t('Flood Fill Detail', 'ディテール均一化'), icon='BRUSH_DATA')
        remesh = self._section_box_or_empty(layout, context, settings, 'remesh_tools', 'Remesh', 'リメッシュ', 'MOD_REMESH', 'top_remesh_retopo', default=False)
        _draw_npanel_prop(remesh, settings, 'compact_remesh_mode', text=t('Remesh Mode', 'リメッシュ方式'))
        _draw_npanel_prop(remesh, settings, 'voxel_size', text=t('Voxel Size', 'ボクセルサイズ'))
        _draw_npanel_prop(remesh, settings, 'voxel_adaptivity', text=t('Adaptivity', '適応度'))
        self._op(remesh, 'smart_sculpt.voxel_remesh', text=t('Voxel Remesh', 'ボクセルリメッシュ'), icon='MOD_REMESH')
        _draw_npanel_prop(remesh, settings, 'quad_target_faces', text=t('Quad Target Faces', 'クアッド目標面数'))
        self._op(remesh, 'smart_sculpt.quadriflow_remesh', text=t('Run QuadriFlow', 'クアッドリメッシュ実行'), icon='MOD_DECIM')
        multires = self._section_box_or_empty(layout, context, settings, 'multires_tools', 'Multires', 'マルチレゾ', 'MOD_MULTIRES', 'top_remesh_retopo', default=False)
        _draw_npanel_prop(multires, settings, 'compact_multires_action', text=t('Action', '操作'))
        _draw_npanel_prop(multires, settings, 'multires_levels', text=t('Levels', 'レベル'))
        self._op(multires, 'smart_sculpt.multires_action', text=t('Run Multires', 'マルチレゾ実行'), icon='MOD_MULTIRES', action=settings.compact_multires_action)
        mask = self._section_box_or_empty(layout, context, settings, 'mask_tools', 'Mask', 'マスク', 'NODE_SOCKET_MATERIAL', 'top_remesh_retopo', default=False)
        _draw_npanel_prop(mask, settings, 'compact_mask_action', text=t('Action', '操作'))
        _draw_npanel_prop(mask, settings, 'extract_thickness', text=t('Extract Thickness', '抽出厚み'))
        _draw_npanel_prop(mask, settings, 'mask_extract_smooth_iterations', text=t('Extract Smooth', '抽出スムーズ'))
        _draw_npanel_prop(mask, settings, 'mask_extract_add_boundary_loop', text=t('Boundary Loop', '境界ループ'))
        _draw_npanel_prop(mask, settings, 'mask_extract_apply_shrinkwrap', text=t('Shrinkwrap', 'シュリンクラップ'))
        _draw_npanel_prop(mask, settings, 'mask_slice_fill_holes', text=t('Fill Slice Holes', 'スライス穴埋め'))
        if settings.compact_mask_action == 'EXTRACT':
            self._op(mask, 'smart_sculpt.mask_extract', text=t('Extract Mask', 'マスク抽出'), icon='MOD_SOLIDIFY')
        elif settings.compact_mask_action == 'SLICE':
            self._op(mask, 'smart_sculpt.mask_slice', text=t('Slice Mask', 'マスクスライス'), icon='MESH_CUBE')
        else:
            self._op(mask, 'smart_sculpt.mask_action', text=t('Run Mask Action', 'マスク操作を実行'), icon='BRUSH_DATA', action=settings.compact_mask_action)
        face = self._section_box_or_empty(layout, context, settings, 'face_set_tools', 'Face Sets', 'フェイスセット', 'MESH_GRID', 'top_remesh_retopo', default=False)
        _draw_npanel_prop(face, settings, 'compact_face_set_action', text=t('Action', '操作'))
        _draw_npanel_prop(face, settings, 'extract_thickness', text=t('Extract Thickness', '抽出厚み'))
        if settings.compact_face_set_action == 'EXTRACT':
            self._op(face, 'smart_sculpt.face_set_extract', text=t('Extract Face Set', 'フェイスセット抽出'), icon='MOD_SOLIDIFY')
        else:
            mapping = {'LOOSE_PARTS': 'INIT_LOOSE', 'MATERIALS': 'INIT_MATERIALS', 'NORMALS': 'INIT_NORMALS', 'UV_SEAMS': 'INIT_UV_SEAMS', 'SHARP_EDGES': 'INIT_SHARP_EDGES', 'CREASES': 'INIT_CREASES', 'BEVEL_WEIGHT': 'INIT_BEVEL_WEIGHT'}
            face_action = settings.compact_face_set_action
            self._op(face, 'smart_sculpt.face_set_action', text=t('Run Face Set Action', 'フェイスセット操作を実行'), icon='MESH_GRID', action=mapping.get(face_action, face_action))
        retopo = self._section_box_or_empty(layout, context, settings, 'retopo_uv_tools', 'Retopo / UV', 'リトポ / UV', 'SNAP_FACE', 'top_remesh_retopo', default=False)
        _draw_npanel_prop(retopo, settings, 'quad_target_faces', text=t('Target Faces', '目標面数'))
        _draw_npanel_prop(retopo, settings, 'retopo_offset', text=t('Offset', 'オフセット'))
        _draw_npanel_prop(retopo, settings, 'retopo_use_mirror', text=t('Mirror', 'ミラー'))
        self._op(retopo, 'smart_sculpt.quadriflow_remesh', text=t('QuadriFlow', 'QuadriFlow'), icon='MOD_DECIM')
        self._op(retopo, 'smart_sculpt.create_retopo_setup', text=t('Create Retopo Helper', 'リトポ補助を作成'), icon='SNAP_FACE')
        _draw_npanel_prop(retopo, settings, 'unwrap_margin', text=t('UV Margin', 'UVマージン'))
        self._op(retopo, 'smart_sculpt.auto_uv_project', text=t('Run Auto UV', '自動UV展開'), icon='GROUP_UVS')
        zbrush_retopo = self._section_box_or_empty(layout, context, settings, 'zbrush_gap_retopo_tools', 'Polygroups / Flow Remesh', 'ポリグループ / フロー', 'MESH_GRID', 'top_remesh_retopo', default=False)
        _draw_npanel_prop(zbrush_retopo, settings, 'zbrush_gap_polygroup_count', text=t('Polygroup Count', 'ポリグループ数'))
        self._op(zbrush_retopo, 'smart_sculpt.polygroup_integrate', text=t('Create Deep Polygroups', '深層ポリグループ作成'), icon='MESH_GRID')
        _draw_npanel_prop(zbrush_retopo, settings, 'zbrush_gap_flow_guide_count', text=t('Flow Guide Count', 'フローガイド数'))
        self._op(zbrush_retopo, 'smart_sculpt.flow_remesh_guide_setup', text=t('Create Flow Remesh Guides', 'フローリメッシュガイド作成'), icon='CURVE_DATA')
        self._draw_smart_action_group(layout, context, settings, 'remesh_retopo_smart_actions', 'Retopo Smart Actions', 'リトポのスマート実行', 'MOD_REMESH', ('QUICK_POLYGROUP_PLUS', 'VOXEL_HYBRID_SURFACE', 'WRAP_RETOPO_UV'), 'top_remesh_retopo')
        self._draw_integrated_section(layout, context, settings, 'integrated_surface', 'Integrated Surface Tools', '統合サーフェイスツール', 'MOD_REMESH', 'top_remesh_retopo', default=False, category='SURFACE')

    def _draw_top_generate_deform(self, layout, context, settings, obj):
        t = utils.ui_text
        self._draw_compact_build(layout, context, settings, obj)
        zmodeler = self._section_box_or_empty(layout, context, settings, 'zbrush_gap_generate_tools', 'ZModeler / Insert Tools', 'Zモデラー / 挿入ツール', 'MOD_BEVEL', 'top_generate_deform', default=False)
        _draw_npanel_prop(zmodeler, settings, 'zbrush_gap_zmodeler_action', text=t('ZModeler Action', 'Zモデラー操作'))
        self._op(zmodeler, 'smart_sculpt.zmodeler_sculpt_action', text=t('Run ZModeler Helper', 'Zモデラー補助を実行'), icon='MOD_BEVEL')
        _draw_npanel_prop(zmodeler, settings, 'zbrush_gap_imm_part', text=t('IMM Part', 'IMMパーツ'))
        _draw_npanel_prop(zmodeler, settings, 'zbrush_gap_imm_count', text=t('IMM Count', 'IMM個数'))
        self._op(zmodeler, 'smart_sculpt.insert_multi_mesh_part', text=t('Insert Multi Mesh', 'インサートマルチメッシュ生成'), icon='MESH_CUBE')
        _draw_npanel_prop(zmodeler, settings, 'zbrush_gap_vdm_stamp', text=t('VDM Stamp', 'VDMスタンプ'))
        self._op(zmodeler, 'smart_sculpt.vdm_stamp', text=t('Create VDM Stamp', 'VDMスタンプ作成'), icon='TEXTURE')
        self._draw_smart_action_group(layout, context, settings, 'generate_deform_smart_actions', 'Generate Smart Actions', '生成/変形スマート実行', 'MESH_CUBE', ('SURFACE_DETAIL_SYNTH', 'BSPHERE_ARMATURE_BLOCKOUT', 'ANCHOR_BEND_PRO', 'HARD_SURFACE_CUTKIT', 'VELLUM_CLOTH_DRAPE', 'MUSCLE_LAYER_DRIVER', 'CURVE_SWEEP_RAIL_CUT', 'ENVIRONMENT_GROWTH'), 'top_generate_deform')

    def _draw_top_analysis_repair(self, layout, context, settings, obj):
        t = utils.ui_text
        target = self._section_box_or_empty(layout, context, settings, 'analysis_active_target', 'Mesh Information', 'メッシュ情報', 'MESH_DATA', 'top_analysis_repair', default=False)
        self._draw_active_target_summary(target, context, settings, obj)
        analysis = self._section_box_or_empty(layout, context, settings, 'analysis_repair', 'Analysis / Repair', '解析/修復', 'VIEWZOOM', 'top_analysis_repair', default=False)
        analysis.operator('smart_sculpt.analyze_active_mesh', text=t('Analyze', '解析'), icon=utils.safe_icon('VIEWZOOM'))
        analysis.operator('smart_sculpt.fix_common_issues', text=t('Fix', '修正'), icon=utils.safe_icon('FILE_REFRESH'))
        analysis.operator('smart_sculpt.export_diagnostic_report', text=t('Report', 'レポート'), icon=utils.safe_icon('TEXT'))
        _draw_npanel_prop(analysis, settings, 'apply_scale_on_fix', text=t('Apply Scale On Fix', '修正時にスケール適用'))
        _draw_npanel_prop(analysis, settings, 'recalc_normals_on_fix', text=t('Recalculate Normals', '法線再計算'))
        _draw_npanel_prop(analysis, settings, 'delete_loose_on_fix', text=t('Delete Loose Geometry', '孤立ジオメトリ削除'))
        _draw_npanel_prop(analysis, settings, 'dissolve_degenerate_on_fix', text=t('Dissolve Degenerate Geometry', '縮退ジオメトリ溶解'))
        if getattr(settings, 'dissolve_degenerate_on_fix', False):
            _draw_npanel_prop(analysis, settings, 'degenerate_threshold_on_fix', text=t('Degenerate Threshold', '縮退閾値'))
        _draw_npanel_prop(analysis, settings, 'merge_distance_on_fix', text=t('Merge Distance', 'マージ距離'))
        self._draw_diagnostics_summary(analysis, settings)
        self._draw_smart_metrics(layout, context, obj, settings)
        self._draw_smart_selected_action_card(layout, context, settings, str(getattr(settings, 'smart_upgrade_action', 'MESH_DOCTOR_PRO') or 'MESH_DOCTOR_PRO'))
        safety = self._section_box_or_empty(layout, context, settings, 'smart_safety_options', 'Smart Safety / Quality', 'スマート安全 / 品質', 'FILE_TICK', 'top_analysis_repair', default=False)
        for attr, label_en, label_ja in (('smart_upgrade_quality', 'Quality', '品質'), ('smart_upgrade_auto_preflight', 'Preflight', '事前検査'), ('smart_upgrade_adaptive_scale', 'Adaptive Scale', '適応スケール'), ('smart_upgrade_make_snapshot', 'Snapshot', 'スナップショット'), ('smart_upgrade_non_destructive', 'Non-Destructive', '非破壊優先'), ('smart_upgrade_write_report', 'Report', 'レポート')):
            _draw_npanel_prop(safety, settings, attr, text=t(label_en, label_ja))
        params = self._section_box_or_empty(layout, context, settings, 'smart_action_parameters', 'Smart Action Parameters', 'アクションの数値', 'SETTINGS', 'top_analysis_repair', default=False)
        for attr, label_en, label_ja in (('smart_upgrade_strength', 'Strength', '強度'), ('smart_upgrade_density', 'Density', '密度'), ('smart_upgrade_count', 'Count', '個数'), ('smart_upgrade_segments', 'Segments', '分割数'), ('smart_upgrade_axis', 'Axis', '軸'), ('smart_upgrade_use_voxel', 'Voxel', 'ボクセル'), ('smart_upgrade_use_multires', 'Multires', 'マルチレゾ'), ('smart_upgrade_target_faces', 'Target Faces', '目標面数')):
            _draw_npanel_prop(params, settings, attr, text=t(label_en, label_ja))
        zbrush_analysis = self._section_box_or_empty(layout, context, settings, 'zbrush_gap_analysis_tools', 'ZBrush Gap Coverage', 'ZBrush差分カバレッジ', 'VIEWZOOM', 'top_analysis_repair', default=False)
        _draw_npanel_prop(zbrush_analysis, settings, 'zbrush_gap_hd_levels', text=t('HD Levels', 'HDレベル'))
        _draw_npanel_prop(zbrush_analysis, settings, 'zbrush_gap_detail_strength', text=t('Detail Strength', 'ディテール強度'))
        self._op(zbrush_analysis, 'smart_sculpt.hd_microtile_setup', text=t('Create HD Microtile Stack', 'HDマイクロタイルスタック作成'), icon='MOD_MULTIRES')
        _draw_npanel_prop(zbrush_analysis, settings, 'zbrush_gap_polygroup_count', text=t('Polygroup Count', 'ポリグループ数'))
        self._op(zbrush_analysis, 'smart_sculpt.polygroup_integrate', text=t('Create Deep Polygroups', '深層ポリグループ作成'), icon='MESH_GRID')
        self._op(zbrush_analysis, 'smart_sculpt.zbrush_gap_pipeline', text=t('Run ZBrush-Class Pipeline', 'ZBrush級パイプライン実行'), icon='AUTO')
        self._op(zbrush_analysis, 'smart_sculpt.zbrush_gap_report', text=t('Create Coverage Report', 'カバレッジレポート作成'), icon='TEXT')
        self._draw_smart_action_group(layout, context, settings, 'analysis_repair_smart_actions', 'Repair Smart Actions', '解析/修復スマート実行', 'VIEWZOOM', ('MESH_DOCTOR_PRO', 'MESH_CLEANER_PRO', 'FULL_SAFE_SETUP', 'SYMMETRY_POSE_GUARD'), 'top_analysis_repair')
        self._draw_integrated_section(layout, context, settings, 'integrated_analysis_tools', 'Integrated Analysis Tools', '統合解析ツール', 'VIEWZOOM', 'top_analysis_repair', default=False, category='SMART')

    def _draw_top_save_io(self, layout, context, settings, obj):
        t = utils.ui_text
        snap_box = self._section_box_or_empty(layout, context, settings, 'snapshots', 'Snapshots', 'スナップショット', 'RECOVER_LAST', 'top_save_io', default=False)
        _draw_npanel_prop(snap_box, settings, 'snapshot_action', text=t('Action', '操作'))
        safe_object_data = _object_data_lists_are_safe(context, obj)
        if safe_object_data and _has_snapshot_runtime(obj):
            if _safe_template_list(snap_box, 'SSS_UL_snapshots', '', obj, 'smart_sculpt_snapshots', obj, 'smart_sculpt_snapshot_index', rows=3):
                preview_name = str(obj.get('sss_snapshot_preview', '') or '')
                if preview_name:
                    snap_box.label(text=f"{t('Snapshot Preview', 'スナップショット比較表示')}: {preview_name}", icon=utils.safe_icon('HIDE_OFF'))
        snapshot_action = settings.snapshot_action
        if snapshot_action == 'SAVE':
            self._op(snap_box, 'smart_sculpt.save_snapshot', text=t('Save Snapshot', 'スナップショット保存'), icon='ADD')
        elif snapshot_action == 'RESTORE':
            self._op(snap_box, 'smart_sculpt.restore_snapshot', text=t('Restore Snapshot', 'スナップショット復元'), icon='IMPORT')
        elif snapshot_action == 'PREVIEW':
            self._op(snap_box, 'smart_sculpt.preview_snapshot', text=t('Snapshot Preview', 'スナップショット比較表示'), icon='HIDE_OFF')
        elif snapshot_action == 'CLEAR_PREVIEW':
            self._op(snap_box, 'smart_sculpt.clear_snapshot_preview', text=t('Clear Snapshot Preview', '比較表示を解除'), icon='HIDE_ON')
        elif snapshot_action == 'DELETE':
            self._op(snap_box, 'smart_sculpt.delete_snapshot', text=t('Delete Snapshot', 'スナップショット削除'), icon='TRASH')
        recovery_box = self._section_box_or_empty(layout, context, settings, 'recovery', 'Recovery', '回復', 'RECOVER_LAST', 'top_save_io', default=False)
        _draw_npanel_prop(recovery_box, settings, 'enable_recovery_backups', text=t('Recovery Backups', '回復バックアップ'))
        _draw_npanel_prop(recovery_box, settings, 'recovery_action', text=t('Action', '操作'))
        if settings.recovery_action == 'RESTORE':
            self._op(recovery_box, 'smart_sculpt.restore_recovery_backup', text=t('Restore Recovery Backup', '回復バックアップ復元'), icon='IMPORT')
        else:
            self._op(recovery_box, 'smart_sculpt.clear_recovery_backup', text=t('Delete Recovery Backup', '回復バックアップ削除'), icon='TRASH')
        layer_box = self._section_box_or_empty(layout, context, settings, 'shape_layers', 'Shape Layers', 'シェイプレイヤー', 'SHAPEKEY_DATA', 'top_save_io', default=False)
        _draw_npanel_prop(layer_box, settings, 'layer_action', text=t('Action', '操作'))
        if safe_object_data and obj and getattr(getattr(obj, 'data', None), 'shape_keys', None):
            if _safe_template_list(layer_box, 'MESH_UL_shape_keys', '', obj.data.shape_keys, 'key_blocks', obj, 'active_shape_key_index', rows=3):
                active_key = obj.active_shape_key
                if active_key is not None and obj.active_shape_key_index > 0:
                    _draw_npanel_prop(layer_box, active_key, 'value', text=t('Layer Strength', 'レイヤー強度'))
        if settings.layer_action == 'DRIVE':
            _draw_npanel_prop(layer_box, settings, 'driver_bone', text=t('Driver Bone', '駆動ボーン'))
            _draw_npanel_prop(layer_box, settings, 'driver_channel', text=t('Channel', 'チャンネル'))
            _draw_npanel_prop(layer_box, settings, 'driver_min', text=t('Min', '最小'))
            _draw_npanel_prop(layer_box, settings, 'driver_max', text=t('Max', '最大'))
        layer_map = {'CREATE': ('smart_sculpt.create_shape_layer', t('Create Shape Layer', 'シェイプレイヤー作成'), 'ADD'), 'DUPLICATE': ('smart_sculpt.duplicate_active_shape_layer', t('Duplicate Active Layer', 'アクティブレイヤー複製'), 'DUPLICATE'), 'DELETE': ('smart_sculpt.delete_active_shape_layer', t('Delete Active Layer', 'アクティブレイヤー削除'), 'TRASH'), 'DRIVE': ('smart_sculpt.drive_active_shape_layer', t('Drive Active Layer', 'アクティブレイヤーを駆動'), 'DRIVER')}
        op_id, label, icon = layer_map.get(settings.layer_action, layer_map['CREATE'])
        self._op(layer_box, op_id, text=label, icon=icon)
        transfer_box = self._section_box_or_empty(layout, context, settings, 'transfer_cleanup', 'Transfer / Cleanup', '入出力 / 整理', 'IMPORT', 'top_save_io', default=False)
        _draw_npanel_prop(transfer_box, settings, 'transfer_action', text=t('Action', '操作'))
        if settings.transfer_action in {'EXPORT', 'IMPORT'}:
            _draw_npanel_prop(transfer_box, settings, 'exchange_format', text=t('Format', '形式'))
            _draw_npanel_prop(transfer_box, settings, 'exchange_scope', text=t('Scope', '対象'))
            _draw_npanel_prop(transfer_box, settings, 'exchange_timestamped_export', text=t('Timestamped Names', 'タイムスタンプ名'))
            _draw_npanel_prop(transfer_box, settings, 'exchange_dir', text=t('Folder', 'フォルダー'))
            if settings.transfer_action == 'EXPORT':
                self._op(transfer_box, 'smart_sculpt.export_exchange', text=t('Export Exchange', '受け渡し書き出し'), icon='EXPORT')
            else:
                self._op(transfer_box, 'smart_sculpt.import_latest_exchange', text=t('Import Latest Exchange', '最新受け渡しを読み込み'), icon='IMPORT')
        else:
            _draw_npanel_prop(transfer_box, settings, 'cleanup_include_snapshots', text=t('Include Snapshots', 'スナップショットも整理'))
            self._op(transfer_box, 'smart_sculpt.cleanup_generated_data', text=t('Cleanup Generated Data', '生成データ整理'), icon='TRASH')
        zbrush_io = self._section_box_or_empty(layout, context, settings, 'zbrush_gap_layer_morph_io', '3D Layers / Morph Targets / Reports', '3Dレイヤー / モーフターゲット / レポート', 'SHAPEKEY_DATA', 'top_save_io', default=False)
        _draw_npanel_prop(zbrush_io, settings, 'zbrush_gap_layer_action', text=t('3D Layer Action', '3Dレイヤー操作'))
        self._op(zbrush_io, 'smart_sculpt.sculpt_layer_pro_action', text=t('Run 3D Layer Action', '3Dレイヤー操作を実行'), icon='SHAPEKEY_DATA')
        _draw_npanel_prop(zbrush_io, settings, 'zbrush_gap_morph_action', text=t('Morph Target Action', 'モーフターゲット操作'))
        self._op(zbrush_io, 'smart_sculpt.morph_target_action', text=t('Run Morph Target Action', 'モーフターゲット操作を実行'), icon='RECOVER_LAST')
        self._op(zbrush_io, 'smart_sculpt.zbrush_gap_report', text=t('Create ZBrush Gap Report', 'ZBrush差分レポート作成'), icon='TEXT')
        self._draw_smart_action_group(layout, context, settings, 'save_io_smart_actions', 'Save / I/O Smart Actions', '保存/入出力スマート実行', 'EXPORT', ('SCULPT_LAYER_STACK_PRO', 'PHOTO_REFERENCE_HANDOFF', 'INTEROP_ROUNDTRIP'), 'top_save_io')
        self._draw_compact_settings(layout, context, settings, obj)

    def _draw_compact_sculpt(self, layout, context, settings, obj):
        t = utils.ui_text
        workflow = self._section_box_or_empty(layout, context, settings, 'core_workflow', 'Core Workflow', 'コアワークフロー', 'TOOL_SETTINGS', 'core_workflow', default=False)
        _draw_npanel_prop(workflow, settings, 'core_action', text=t('Action', '操作'))
        action = str(getattr(settings, 'core_action', 'PREPARE') or 'PREPARE')
        if action == 'MULTI_OBJECT':
            _draw_npanel_prop(workflow, settings, 'multi_object_make_single_user', text=t('Make Shared Meshes Single-User', '共有メッシュをシングルユーザー化'))
        row = workflow.row(align=True)
        if action == 'PREPARE':
            self._op(row, 'smart_sculpt.prepare_workspace', text=t('Run Core Setup', 'コア設定を実行'), icon='TOOL_SETTINGS')
        elif action == 'MULTI_OBJECT':
            self._op(row, 'smart_sculpt.prepare_multi_object_sculpt', text=t('Prepare Multi-Object', '複数オブジェクト準備'), icon='GROUP')
        elif action == 'CYCLE_PREV':
            self._op(row, 'smart_sculpt.cycle_selected_mesh', text=t('Previous Part', '前パーツ'), icon='TRIA_LEFT', direction='PREV')
        elif action == 'CYCLE_NEXT':
            self._op(row, 'smart_sculpt.cycle_selected_mesh', text=t('Next Part', '次パーツ'), icon='TRIA_RIGHT', direction='NEXT')
        elif action == 'ANALYZE':
            self._op(row, 'smart_sculpt.analyze_active_mesh', text=t('Analyze Active Mesh', 'アクティブメッシュ解析'), icon='VIEWZOOM')
        elif action == 'FIX':
            self._op(row, 'smart_sculpt.fix_common_issues', text=t('Run Common Fix', '共通修正を実行'), icon='FILE_REFRESH')
        elif action == 'REPORT':
            self._op(row, 'smart_sculpt.export_diagnostic_report', text=t('Export Diagnostic Report', '診断レポートを書き出し'), icon='TEXT')
        _draw_npanel_prop(workflow, settings, 'auto_enter_sculpt', text=t('Auto Enter Sculpt', '自動でスカルプトへ'))
        analysis = self._section_box_or_empty(layout, context, settings, 'analysis_repair', 'Analysis & Repair', '解析と修復', 'CHECKMARK', 'analysis_repair', default=False)
        analysis.operator('smart_sculpt.analyze_active_mesh', text=t('Analyze', '解析'), icon='VIEWZOOM')
        analysis.operator('smart_sculpt.fix_common_issues', text=t('Fix', '修正'), icon='FILE_REFRESH')
        analysis.operator('smart_sculpt.export_diagnostic_report', text=t('Report', 'レポート'), icon='TEXT')
        _draw_npanel_prop(analysis, settings, 'apply_scale_on_fix', text=t('Apply Scale On Fix', '修正時にスケール適用'))
        _draw_npanel_prop(analysis, settings, 'recalc_normals_on_fix', text=t('Recalculate Normals', '法線再計算'))
        _draw_npanel_prop(analysis, settings, 'delete_loose_on_fix', text=t('Delete Loose Geometry', '孤立ジオメトリ削除'))
        _draw_npanel_prop(analysis, settings, 'dissolve_degenerate_on_fix', text=t('Dissolve Degenerate Geometry', '縮退ジオメトリ溶解'))
        if getattr(settings, 'dissolve_degenerate_on_fix', False):
            _draw_npanel_prop(analysis, settings, 'degenerate_threshold_on_fix', text=t('Degenerate Threshold', '縮退閾値'))
        _draw_npanel_prop(analysis, settings, 'merge_distance_on_fix', text=t('Merge Distance', 'マージ距離'))
        self._draw_diagnostics_summary(analysis, settings)
        view_box = self._section_box_or_empty(layout, context, settings, 'view_profile', 'View & Profile', '表示とプロファイル', 'SHADING_SOLID', 'view_profile', default=False)
        _draw_npanel_prop(view_box, settings, 'compact_viewport_preset', text=t('Viewport Preset', '表示プリセット'))
        self._op(view_box, 'smart_sculpt.set_viewport_preset', text=t('Apply View', '表示適用'), icon='SHADING_SOLID', preset=settings.compact_viewport_preset)
        self._op(view_box, 'smart_sculpt.toggle_silhouette', text=t('Silhouette', 'シルエット'), icon='SHADING_SOLID')
        _draw_npanel_prop(view_box, settings, 'profile', text=t('Quick Profile', 'クイックプロファイル'))
        self._op(view_box, 'smart_sculpt.apply_profile', text=t('Apply Profile', 'プロファイル適用'), icon='PLAY', profile=settings.profile)
        tool_box = self._section_box_or_empty(layout, context, settings, 'brush_access', 'Brush Access', 'ブラシアクセス', 'BRUSH_DATA', 'brush_access', default=False)
        _draw_npanel_prop(tool_box, settings, 'quick_tool', text=t('Quick Tool', 'クイックツール'))
        self._op(tool_box, 'smart_sculpt.set_sculpt_tool', text=t('Activate Tool', 'ツールを有効化'), icon='BRUSH_DATA', tool=settings.quick_tool)
        slot = max(1, min(3, int(getattr(settings, 'tool_pipe_slot_index', 1) or 1)))
        slot_attr = utils.tool_pipe_slot_attr(slot)
        _draw_npanel_prop(tool_box, settings, 'tool_pipe_slot_index', text=t('Favorite Slot', 'お気に入りスロット'))
        _draw_npanel_prop(tool_box, settings, slot_attr, text=t('Stored Brush', '保存ブラシ'))
        self._op(tool_box, 'smart_sculpt.use_brush_slot', text=t('Recall', '呼び出し'), icon='PLAY', slot=slot)
        self._op(tool_box, 'smart_sculpt.store_active_brush_slot', text=t('Save', '保存'), icon='IMPORT', slot=slot)
        self._op(tool_box, 'smart_sculpt.clear_brush_slot', text=t('Clear Slot', 'スロット消去'), icon='X', slot=slot)
        tool_box.label(text=utils.tool_pipe_slot_label(settings, slot), icon='BRUSH_DATA')
        self._draw_integrated_section(layout, context, settings, 'integrated_sculpt', 'Integrated Sculpt Tools', '統合スカルプトツール', 'SCULPTMODE_HLT', 'tab_sculpt', default=False, category='SCULPT')

    def _smart_action_label(self, action: str) -> str:
        action_key = str(action or '').strip().upper()
        for item in getattr(properties, 'SMART_ACTION_ITEMS', ()):
            try:
                if str(item[0]).upper() == action_key:
                    return str(bpy.app.translations.pgettext_iface(str(item[1])))
            except Exception:
                continue
        return action_key.replace('_', ' ').title()

    def _draw_smart_metrics(self, layout, context, obj, settings) -> None:
        if not bool(getattr(settings, 'smart_upgrade_show_metrics', True)):
            return
        t = utils.ui_text
        box = self._section_box(layout, context, settings, 'smart_live_mesh_readiness', 'Live Mesh Readiness', 'ライブメッシュ準備度', 'VIEWZOOM', 'smart_precision_ui', default=False)
        if box is None:
            return
        if obj is None or getattr(obj, 'type', None) != 'MESH':
            _draw_wrapped_label(box, context, t('No active mesh: setup-only actions remain available.', 'アクティブメッシュなし: セットアップ専用アクションは使用できます。'))
            return
        mode = _safe_object_mode(obj)
        stats = _cached_ui_mesh_stats(obj, allow_full=not bool(mode and mode != 'OBJECT'))
        if mode and mode != 'OBJECT':
            _draw_wrapped_label(box, context, t('Detailed live metrics are paused during mode changes or non-Object mode.', 'モード切替中またはオブジェクト以外のモードでは詳細ライブ指標を一時停止します。'))
        measured = bool(stats.get('measured', True))
        score = int(stats.get('precision_score', 0) or 0)
        if measured:
            score_icon = 'CHECKMARK' if score >= 82 else 'ERROR' if score < 55 else 'DOT'
            self._draw_label_stack(box, (f"{t('Score', 'スコア')}: {score}/100", f"{t('Faces', '面')}: {int(stats.get('faces', 0) or 0):,}", f"{t('Quad', '四角面')}: {float(stats.get('quad_ratio', 0.0) or 0.0):.2f}", f"{t('Risk Edges', 'リスク辺')}: {int(stats.get('non_manifold_edges', 0) or 0):,}", f"{t('UV', 'UV')}: {int(stats.get('uv_layers', 0) or 0)}", f"{t('Shape Layers', '形状レイヤー')}: {int(stats.get('shape_keys', 0) or 0)}"), icon=score_icon)
        else:
            self._draw_label_stack(box, (f"{t('Score', 'スコア')}: {t('Not measured', '未計測')}", f"{t('Faces', '面')}: {int(stats.get('faces', 0) or 0):,}", f"{t('UV', 'UV')}: {int(stats.get('uv_layers', 0) or 0)}", f"{t('Shape Layers', '形状レイヤー')}: {int(stats.get('shape_keys', 0) or 0)}"), icon='DOT')
            _draw_wrapped_label(box, context, t('Run Analyze to measure the score.', '「解析」を実行するとスコアを計測します。'))
        recommended = 'APEX_AUTOPILOT_PASS'
        if measured:
            try:
                _smart_ops = _loaded_sibling_module('core.smart_upgrade_operators')
                recommend = getattr(_smart_ops, 'recommend_smart_action', None)
                recommended = str(recommend(stats, obj, settings)) if callable(recommend) else 'PRECISION_FRONTIER_PASS'
            except Exception:
                recommended = 'PRECISION_FRONTIER_PASS'
        _draw_wrapped_label(box, context, f"{t('Apex Route', '最上位推奨')}: {self._smart_action_label(recommended)}", icon='AUTO')
        apex_row = box.row(align=True)
        apex_row.scale_y = _smart_button_scale(settings)
        apex_icon_value = 0 if mode and mode != 'OBJECT' else icon_assets.action_icon_value('APEX_AUTOPILOT_PASS')
        self._op(apex_row, 'smart_sculpt.run_smart_upgrade_tool', text=self._smart_action_label('APEX_AUTOPILOT_PASS'), icon=icon_assets.action_fallback_icon('APEX_AUTOPILOT_PASS'), icon_value=apex_icon_value, action='APEX_AUTOPILOT_PASS', strength=getattr(settings, 'smart_upgrade_strength', 0.0), density=getattr(settings, 'smart_upgrade_density', 0.0), count=getattr(settings, 'smart_upgrade_count', 0), segments=getattr(settings, 'smart_upgrade_segments', 0), use_voxel=getattr(settings, 'smart_upgrade_use_voxel', True), use_multires=getattr(settings, 'smart_upgrade_use_multires', True))
        if measured and score < 70:
            _draw_wrapped_label(box, context, t('Recommended: Apex Autopilot or Mesh Doctor Pro before high-density sculpting.', '推奨: 高密度スカルプト前に自動最適パスまたはメッシュ診断プロを実行してください。'), icon='ERROR')

    def _draw_smart_feature_badges(self, layout, settings) -> None:
        t = utils.ui_text
        col = layout.column(align=True)
        for attr, label_en, label_ja, icon in (('smart_upgrade_auto_preflight', 'Preflight', '事前検査', 'VIEWZOOM'), ('smart_upgrade_adaptive_scale', 'Adaptive', '適応', 'MODIFIER'), ('smart_upgrade_non_destructive', 'Layered', '非破壊', 'MOD_MULTIRES'), ('smart_upgrade_write_report', 'Report', 'レポート', 'TEXT')):
            active = bool(getattr(settings, attr, False))
            badge = col.row(align=True)
            badge.enabled = active
            badge.label(text=t(label_en, label_ja), icon=utils.safe_icon(icon if active else 'BLANK1'))

    def _draw_smart_selected_action_card(self, layout, context, settings, action: str) -> None:
        t = utils.ui_text
        card = self._section_box(layout, context, settings, 'smart_selected_action', 'Selected Smart Action', '選択スマートアクション', 'AUTO', 'tab_smart', default=False)
        if card is None:
            return
        label = self._smart_action_label(action)
        obj = utils.active_mesh_object(context)
        allow_custom_icon = _object_data_lists_are_safe(context, obj)
        icon_value = icon_assets.action_icon_value(action) if allow_custom_icon else 0
        card.label(text=label, icon=utils.safe_icon('AUTO'))
        self._draw_smart_feature_badges(card, settings)
        run_row = card.row(align=True)
        run_row.scale_y = _smart_button_scale(settings)
        self._op(run_row, 'smart_sculpt.run_smart_upgrade_tool', text=t('Run Selected Smart Action', '選択スマートアクションを実行'), icon=icon_assets.action_fallback_icon(action), icon_value=icon_value, action=action, strength=getattr(settings, 'smart_upgrade_strength', 0.0), density=getattr(settings, 'smart_upgrade_density', 0.0), count=getattr(settings, 'smart_upgrade_count', 0), segments=getattr(settings, 'smart_upgrade_segments', 0), use_voxel=getattr(settings, 'smart_upgrade_use_voxel', True), use_multires=getattr(settings, 'smart_upgrade_use_multires', True))

    def _draw_smart_icon_board(self, layout, context, settings) -> None:
        if not bool(getattr(settings, 'smart_upgrade_show_icon_board', True)):
            return
        obj = utils.active_mesh_object(context)
        allow_custom_icon = _object_data_lists_are_safe(context, obj)
        t = utils.ui_text
        board = self._section_box(layout, context, settings, 'smart_apex_command_deck', 'Apex Command Deck', '最上位コマンドデッキ', 'SEQ_STRIP_META', 'smart_precision_ui', default=False)
        if board is None:
            return
        actions = {str(item[0]): str(bpy.app.translations.pgettext_iface(str(item[1]))) for item in list(getattr(properties, 'SMART_ACTION_ITEMS', ()) or []) if len(item) >= 2}
        groups = (('smart_group_pipeline', 'Pipeline / Autopilot', 'パイプライン / 自動処理', 'AUTO', ('APEX_AUTOPILOT_PASS', 'SUPREME_STUDIO_PIPELINE', 'PRECISION_FRONTIER_PASS', 'ADAPTIVE_MASTER_PASS')), ('smart_group_diagnosis', 'Diagnosis / Cleanup', '診断 / クリーンアップ', 'CHECKMARK', ('MESH_DOCTOR_PRO', 'MESH_CLEANER_PRO', 'FULL_SAFE_SETUP')), ('smart_group_layers_pose', 'Layers / Symmetry / Pose', 'レイヤー / 対称 / ポーズ', 'MOD_MIRROR', ('SCULPT_LAYER_STACK_PRO', 'SYMMETRY_POSE_GUARD', 'MUSCLE_LAYER_DRIVER', 'ANCHOR_BEND_PRO')), ('smart_group_surface_retopo', 'Surface / Retopo / UV', 'サーフェイス / リトポ / UV', 'MOD_REMESH', ('SURFACE_DETAIL_SYNTH', 'VOXEL_HYBRID_SURFACE', 'WRAP_RETOPO_UV', 'PROCEDURAL_MICRODETAIL_BRUSH')), ('smart_group_blockout_build', 'Blockout / Hard Surface', 'ブロックアウト / ハードサーフェス', 'MESH_CUBE', ('BSPHERE_ARMATURE_BLOCKOUT', 'SPEED_BLOCKOUT', 'HARD_SURFACE_CUTKIT', 'CURVE_SWEEP_RAIL_CUT', 'QUICK_POLYGROUP_PLUS')), ('smart_group_scene_exchange', 'Scene Growth / Exchange', 'シーン生成 / 受け渡し', 'IMPORT', ('ENVIRONMENT_GROWTH', 'PHOTO_REFERENCE_HANDOFF', 'INTEROP_ROUNDTRIP', 'SCULPT_TRANSFER_PROFILE', 'MULTI_OBJECT_HARMONIZER', 'VELLUM_CLOTH_DRAPE')))
        for group_key, title_en, title_ja, group_icon, group_actions in groups:
            group_box = self._section_box(board, context, settings, group_key, title_en, title_ja, group_icon, 'smart_precision_ui', default=False)
            if group_box is None:
                continue
            flow = _compact_npanel_layout(group_box.column(align=True))
            for action_id in group_actions:
                label = actions.get(action_id)
                if not label:
                    continue
                cell = flow.column(align=True)
                button_row = cell.row(align=True)
                button_row.scale_y = _smart_button_scale(settings)
                board_icon_value = icon_assets.action_icon_value(action_id) if allow_custom_icon else 0
                self._op(button_row, 'smart_sculpt.run_smart_upgrade_tool', text=label, icon=icon_assets.action_fallback_icon(action_id), icon_value=board_icon_value, action=action_id, strength=getattr(settings, 'smart_upgrade_strength', 0.0), density=getattr(settings, 'smart_upgrade_density', 0.0), count=getattr(settings, 'smart_upgrade_count', 0), segments=getattr(settings, 'smart_upgrade_segments', 0), use_voxel=getattr(settings, 'smart_upgrade_use_voxel', True), use_multires=getattr(settings, 'smart_upgrade_use_multires', True))

    def _draw_compact_smart(self, layout, context, settings, obj):
        t = utils.ui_text
        action = str(getattr(settings, 'smart_upgrade_action', 'QUICK_POLYGROUP_PLUS') or 'QUICK_POLYGROUP_PLUS')
        selector = self._section_box_or_empty(layout, context, settings, 'smart_upgrade_tools', 'Smart Action Select', 'スマートアクション選択', 'AUTO', 'tab_smart', default=False)
        _draw_npanel_prop(selector, settings, 'smart_upgrade_action', text=t('Action', '操作'))
        self._op(selector, 'smart_sculpt.run_smart_upgrade_tool', text=t('Run Smart Upgrade', 'スマートアップグレード実行'), icon='PLAY', action=action, strength=getattr(settings, 'smart_upgrade_strength', 0.0), density=getattr(settings, 'smart_upgrade_density', 0.0), count=getattr(settings, 'smart_upgrade_count', 0), segments=getattr(settings, 'smart_upgrade_segments', 0), use_voxel=getattr(settings, 'smart_upgrade_use_voxel', True), use_multires=getattr(settings, 'smart_upgrade_use_multires', True))
        _draw_npanel_prop(selector, settings, 'smart_upgrade_show_icon_board', text=t('Icon Board', 'アイコンボード'))
        _draw_npanel_prop(selector, settings, 'smart_upgrade_show_metrics', text=t('Live Metrics', 'ライブ指標'))
        _draw_npanel_prop(selector, settings, 'smart_upgrade_icon_scale', text=t('Icon Size', 'アイコンサイズ'))
        self._draw_smart_metrics(layout, context, obj, settings)
        self._draw_smart_selected_action_card(layout, context, settings, action)
        safety = self._section_box_or_empty(layout, context, settings, 'smart_safety_options', 'Safety / Quality', '安全 / 品質', 'FILE_TICK', 'smart_precision_ui', default=False)
        _draw_npanel_prop(safety, settings, 'smart_upgrade_quality', text=t('Quality', '品質'))
        _draw_npanel_prop(safety, settings, 'smart_upgrade_auto_preflight', text=t('Preflight', '事前検査'))
        _draw_npanel_prop(safety, settings, 'smart_upgrade_adaptive_scale', text=t('Adaptive Scale', '適応スケール'))
        _draw_npanel_prop(safety, settings, 'smart_upgrade_make_snapshot', text=t('Snapshot', 'スナップショット'))
        _draw_npanel_prop(safety, settings, 'smart_upgrade_non_destructive', text=t('Non-Destructive', '非破壊優先'))
        _draw_npanel_prop(safety, settings, 'smart_upgrade_write_report', text=t('Report', 'レポート'))
        params = self._section_box_or_empty(layout, context, settings, 'smart_action_parameters', 'Action Parameters', 'アクションパラメータ', 'SETTINGS', 'smart_precision_ui', default=False)
        if action in {'APEX_AUTOPILOT_PASS', 'SUPREME_STUDIO_PIPELINE', 'PRECISION_FRONTIER_PASS', 'ADAPTIVE_MASTER_PASS', 'SURFACE_DETAIL_SYNTH', 'SCULPT_LAYER_STACK_PRO', 'SYMMETRY_POSE_GUARD', 'ANCHOR_BEND_PRO', 'VOXEL_HYBRID_SURFACE', 'VELLUM_CLOTH_DRAPE', 'ENVIRONMENT_GROWTH', 'CURVE_SWEEP_RAIL_CUT', 'HARD_SURFACE_CUTKIT', 'PROCEDURAL_MICRODETAIL_BRUSH', 'BSPHERE_ARMATURE_BLOCKOUT', 'SPEED_BLOCKOUT'}:
            _draw_npanel_prop(params, settings, 'smart_upgrade_strength', text=t('Strength', '強度'))
            _draw_npanel_prop(params, settings, 'smart_upgrade_density', text=t('Density', '密度'))
        if action in {'APEX_AUTOPILOT_PASS', 'SUPREME_STUDIO_PIPELINE', 'PRECISION_FRONTIER_PASS', 'ADAPTIVE_MASTER_PASS', 'ENVIRONMENT_GROWTH', 'CURVE_SWEEP_RAIL_CUT', 'BSPHERE_ARMATURE_BLOCKOUT'}:
            _draw_npanel_prop(params, settings, 'smart_upgrade_count', text=t('Count', '個数'))
            _draw_npanel_prop(params, settings, 'smart_upgrade_segments', text=t('Segments', '分割数'))
        if action in {'APEX_AUTOPILOT_PASS', 'SUPREME_STUDIO_PIPELINE', 'PRECISION_FRONTIER_PASS', 'SYMMETRY_POSE_GUARD', 'ANCHOR_BEND_PRO', 'CURVE_SWEEP_RAIL_CUT', 'HARD_SURFACE_CUTKIT'}:
            _draw_npanel_prop(params, settings, 'smart_upgrade_axis', text=t('Axis', '軸'))
        if action in {'APEX_AUTOPILOT_PASS', 'SUPREME_STUDIO_PIPELINE', 'PRECISION_FRONTIER_PASS', 'ADAPTIVE_MASTER_PASS', 'VOXEL_HYBRID_SURFACE'}:
            _draw_npanel_prop(params, settings, 'smart_upgrade_use_voxel', text=t('Voxel', 'ボクセル'))
            _draw_npanel_prop(params, settings, 'smart_upgrade_use_multires', text=t('Multires', 'マルチレゾ'))
        if action in {'APEX_AUTOPILOT_PASS', 'SUPREME_STUDIO_PIPELINE', 'PRECISION_FRONTIER_PASS', 'ADAPTIVE_MASTER_PASS', 'WRAP_RETOPO_UV', 'MULTI_OBJECT_HARMONIZER', 'MESH_DOCTOR_PRO', 'MESH_CLEANER_PRO'}:
            _draw_npanel_prop(params, settings, 'smart_upgrade_target_faces', text=t('Target Faces', '目標面数'))
        if action == 'PHOTO_REFERENCE_HANDOFF':
            _draw_npanel_prop(params, settings, 'smart_photo_reference_path', text=t('Reference File', '参照ファイル'))
        if action == 'INTEROP_ROUNDTRIP':
            _draw_npanel_prop(params, settings, 'exchange_format', text=t('Format', '形式'))
            _draw_npanel_prop(params, settings, 'exchange_scope', text=t('Scope', '対象'))
            _draw_npanel_prop(params, settings, 'exchange_dir', text=t('Folder', 'フォルダー'))
        if action in {'MUSCLE_LAYER_DRIVER', 'SCULPT_LAYER_STACK_PRO'}:
            _draw_npanel_prop(params, settings, 'driver_bone', text=t('Driver Bone', '駆動ボーン'))
            _draw_npanel_prop(params, settings, 'driver_channel', text=t('Channel', 'チャンネル'))
        self._draw_smart_icon_board(layout, context, settings)
        self._draw_integrated_section(layout, context, settings, 'integrated_smart', 'Integrated Smart Tools', '統合スマートツール', 'AUTO', 'tab_smart', default=False, category='SMART')

    def _draw_compact_surface(self, layout, context, settings, obj):
        t = utils.ui_text
        launcher = self._section_box_or_empty(layout, context, settings, 'surface_action_launcher', 'Surface Launcher', 'サーフェイス実行', 'MOD_REMESH', 'surface_actions', default=False)
        _draw_npanel_prop(launcher, settings, 'surface_action', text=t('Action', '操作'))
        action = str(getattr(settings, 'surface_action', 'DYNTOPO') or 'DYNTOPO')
        if action == 'DYNTOPO':
            self._op(launcher, 'smart_sculpt.configure_dyntopo', text=t('Run Selected Surface Action', '選択サーフェイス操作を実行'), icon='MOD_TRIANGULATE')
        elif action == 'FLOOD':
            self._op(launcher, 'smart_sculpt.detail_flood_fill', text=t('Run Selected Surface Action', '選択サーフェイス操作を実行'), icon='BRUSH_DATA')
        elif action == 'REMESH':
            if getattr(settings, 'compact_remesh_mode', 'VOXEL') == 'VOXEL':
                self._op(launcher, 'smart_sculpt.voxel_remesh', text=t('Run Selected Surface Action', '選択サーフェイス操作を実行'), icon='MOD_REMESH')
            else:
                self._op(launcher, 'smart_sculpt.quadriflow_remesh', text=t('Run Selected Surface Action', '選択サーフェイス操作を実行'), icon='MOD_DECIM')
        elif action == 'MULTIRES':
            self._op(launcher, 'smart_sculpt.multires_action', text=t('Run Selected Surface Action', '選択サーフェイス操作を実行'), icon='MOD_MULTIRES', action=settings.compact_multires_action)
        elif action == 'MASK':
            if settings.compact_mask_action == 'EXTRACT':
                self._op(launcher, 'smart_sculpt.mask_extract', text=t('Run Selected Surface Action', '選択サーフェイス操作を実行'), icon='MOD_SOLIDIFY')
            elif settings.compact_mask_action == 'SLICE':
                self._op(launcher, 'smart_sculpt.mask_slice', text=t('Run Selected Surface Action', '選択サーフェイス操作を実行'), icon='MESH_CUBE')
            else:
                self._op(launcher, 'smart_sculpt.mask_action', text=t('Run Selected Surface Action', '選択サーフェイス操作を実行'), icon='BRUSH_DATA', action=settings.compact_mask_action)
        elif action == 'FACE_SET':
            if settings.compact_face_set_action == 'EXTRACT':
                self._op(launcher, 'smart_sculpt.face_set_extract', text=t('Run Selected Surface Action', '選択サーフェイス操作を実行'), icon='MOD_SOLIDIFY')
            else:
                face_action = settings.compact_face_set_action
                mapping = {'LOOSE_PARTS': 'INIT_LOOSE', 'MATERIALS': 'INIT_MATERIALS', 'NORMALS': 'INIT_NORMALS', 'UV_SEAMS': 'INIT_UV_SEAMS', 'SHARP_EDGES': 'INIT_SHARP_EDGES', 'CREASES': 'INIT_CREASES', 'BEVEL_WEIGHT': 'INIT_BEVEL_WEIGHT'}
                self._op(launcher, 'smart_sculpt.face_set_action', text=t('Run Selected Surface Action', '選択サーフェイス操作を実行'), icon='MESH_GRID', action=mapping.get(face_action, face_action))
        elif action == 'FILTER':
            if getattr(settings, 'compact_filter_domain', 'MESH') == 'MESH':
                self._op(launcher, 'smart_sculpt.apply_mesh_filter', text=t('Run Selected Surface Action', '選択サーフェイス操作を実行'), icon='MOD_SMOOTH', filter_type=settings.mesh_filter_type, strength=settings.filter_strength)
            else:
                self._op(launcher, 'smart_sculpt.apply_cloth_filter', text=t('Run Selected Surface Action', '選択サーフェイス操作を実行'), icon='MOD_CLOTH', filter_type=settings.cloth_filter_type, strength=settings.filter_strength)
        elif action == 'RETOPO':
            self._op(launcher, 'smart_sculpt.create_retopo_setup', text=t('Run Selected Surface Action', '選択サーフェイス操作を実行'), icon='SNAP_FACE')
        elif action == 'AUTO_UV':
            self._op(launcher, 'smart_sculpt.auto_uv_project', text=t('Run Selected Surface Action', '選択サーフェイス操作を実行'), icon='GROUP_UVS')
        dyntopo = self._section_box_or_empty(layout, context, settings, 'dyntopo_tools', 'Dyntopo', 'ダイナミックトポロジー', 'MOD_TRIANGULATE', 'dyntopo', default=False)
        _draw_npanel_prop(dyntopo, settings, 'dyntopo_mode', text=t('Mode', 'モード'))
        _draw_npanel_prop(dyntopo, settings, 'dyntopo_detail', text=t('Detail', '細かさ'))
        self._op(dyntopo, 'smart_sculpt.configure_dyntopo', text=t('Configure Dyntopo', 'ダイナミックトポロジーを設定'), icon='MOD_TRIANGULATE')
        self._op(dyntopo, 'smart_sculpt.detail_flood_fill', text=t('Flood Fill Detail', 'ディテール均一化'), icon='BRUSH_DATA')
        remesh = self._section_box_or_empty(layout, context, settings, 'remesh_tools', 'Remesh', 'リメッシュ', 'MOD_REMESH', 'remesh', default=False)
        _draw_npanel_prop(remesh, settings, 'compact_remesh_mode', text=t('Remesh Mode', 'リメッシュ方式'))
        _draw_npanel_prop(remesh, settings, 'voxel_size', text=t('Voxel Size', 'ボクセルサイズ'))
        _draw_npanel_prop(remesh, settings, 'voxel_adaptivity', text=t('Adaptivity', '適応度'))
        self._op(remesh, 'smart_sculpt.voxel_remesh', text=t('Voxel Remesh', 'ボクセルリメッシュ'), icon='MOD_REMESH')
        _draw_npanel_prop(remesh, settings, 'quad_target_faces', text=t('Quad Target Faces', 'クアッド目標面数'))
        self._op(remesh, 'smart_sculpt.quadriflow_remesh', text=t('Run QuadriFlow', 'クアッドリメッシュ実行'), icon='MOD_DECIM')
        multires = self._section_box_or_empty(layout, context, settings, 'multires_tools', 'Multires', 'マルチレゾ', 'MOD_MULTIRES', 'multires', default=False)
        _draw_npanel_prop(multires, settings, 'compact_multires_action', text=t('Action', '操作'))
        _draw_npanel_prop(multires, settings, 'multires_levels', text=t('Levels', 'レベル'))
        self._op(multires, 'smart_sculpt.multires_action', text=t('Run Multires', 'マルチレゾ実行'), icon='MOD_MULTIRES', action=settings.compact_multires_action)
        mask = self._section_box_or_empty(layout, context, settings, 'mask_tools', 'Mask', 'マスク', 'NODE_SOCKET_MATERIAL', 'mask_tools', default=False)
        _draw_npanel_prop(mask, settings, 'compact_mask_action', text=t('Action', '操作'))
        _draw_npanel_prop(mask, settings, 'extract_thickness', text=t('Extract Thickness', '抽出厚み'))
        _draw_npanel_prop(mask, settings, 'mask_extract_smooth_iterations', text=t('Extract Smooth', '抽出スムーズ'))
        _draw_npanel_prop(mask, settings, 'mask_extract_add_boundary_loop', text=t('Boundary Loop', '境界ループ'))
        _draw_npanel_prop(mask, settings, 'mask_extract_apply_shrinkwrap', text=t('Shrinkwrap', 'シュリンクラップ'))
        _draw_npanel_prop(mask, settings, 'mask_slice_fill_holes', text=t('Fill Slice Holes', 'スライス穴埋め'))
        if settings.compact_mask_action == 'EXTRACT':
            self._op(mask, 'smart_sculpt.mask_extract', text=t('Extract Mask', 'マスク抽出'), icon='MOD_SOLIDIFY')
        elif settings.compact_mask_action == 'SLICE':
            self._op(mask, 'smart_sculpt.mask_slice', text=t('Slice Mask', 'マスクスライス'), icon='MESH_CUBE')
        else:
            self._op(mask, 'smart_sculpt.mask_action', text=t('Run Mask Action', 'マスク操作を実行'), icon='BRUSH_DATA', action=settings.compact_mask_action)
        face = self._section_box_or_empty(layout, context, settings, 'face_set_tools', 'Face Sets', 'フェイスセット', 'MESH_GRID', 'face_sets', default=False)
        _draw_npanel_prop(face, settings, 'compact_face_set_action', text=t('Action', '操作'))
        _draw_npanel_prop(face, settings, 'extract_thickness', text=t('Extract Thickness', '抽出厚み'))
        if settings.compact_face_set_action == 'EXTRACT':
            self._op(face, 'smart_sculpt.face_set_extract', text=t('Extract Face Set', 'フェイスセット抽出'), icon='MOD_SOLIDIFY')
        else:
            face_action = settings.compact_face_set_action
            mapping = {'LOOSE_PARTS': 'INIT_LOOSE', 'MATERIALS': 'INIT_MATERIALS', 'NORMALS': 'INIT_NORMALS', 'UV_SEAMS': 'INIT_UV_SEAMS', 'SHARP_EDGES': 'INIT_SHARP_EDGES', 'CREASES': 'INIT_CREASES', 'BEVEL_WEIGHT': 'INIT_BEVEL_WEIGHT'}
            self._op(face, 'smart_sculpt.face_set_action', text=t('Run Face Set Action', 'フェイスセット操作を実行'), icon='MESH_GRID', action=mapping.get(face_action, face_action))
        filters = self._section_box_or_empty(layout, context, settings, 'filter_tools', 'Filters', 'フィルター', 'MOD_SMOOTH', 'filters', default=False)
        _draw_npanel_prop(filters, settings, 'compact_filter_domain', text=t('Filter Domain', 'フィルター対象'))
        _draw_npanel_prop(filters, settings, 'filter_strength', text=t('Strength', '強度'))
        _draw_npanel_prop(filters, settings, 'mesh_filter_type', text=t('Mesh Filter', 'メッシュフィルター'))
        self._op(filters, 'smart_sculpt.apply_mesh_filter', text=t('Apply Mesh Filter', 'メッシュフィルター適用'), icon='MOD_SMOOTH', filter_type=settings.mesh_filter_type, strength=settings.filter_strength)
        _draw_npanel_prop(filters, settings, 'cloth_filter_type', text=t('Cloth Filter', 'クロスフィルター'))
        self._op(filters, 'smart_sculpt.apply_cloth_filter', text=t('Apply Cloth Filter', 'クロスフィルター適用'), icon='MOD_CLOTH', filter_type=settings.cloth_filter_type, strength=settings.filter_strength)
        retopo = self._section_box_or_empty(layout, context, settings, 'retopo_uv_tools', 'Retopo / UV', 'リトポ / UV', 'SNAP_FACE', 'retopo_uv', default=False)
        _draw_npanel_prop(retopo, settings, 'quad_target_faces', text=t('Target Faces', '目標面数'))
        _draw_npanel_prop(retopo, settings, 'retopo_offset', text=t('Offset', 'オフセット'))
        _draw_npanel_prop(retopo, settings, 'retopo_use_mirror', text=t('Mirror', 'ミラー'))
        self._op(retopo, 'smart_sculpt.quadriflow_remesh', text=t('QuadriFlow', 'QuadriFlow'), icon='MOD_DECIM')
        self._op(retopo, 'smart_sculpt.create_retopo_setup', text=t('Create Retopo Helper', 'リトポ補助を作成'), icon='SNAP_FACE')
        _draw_npanel_prop(retopo, settings, 'unwrap_margin', text=t('UV Margin', 'UVマージン'))
        self._op(retopo, 'smart_sculpt.auto_uv_project', text=t('Run Auto UV', '自動UV展開'), icon='GROUP_UVS')
        self._draw_integrated_section(layout, context, settings, 'integrated_surface', 'Integrated Surface Tools', '統合サーフェイスツール', 'MOD_REMESH', 'tab_surface', default=False, category='SURFACE')

    def _draw_compact_build(self, layout, context, settings, obj):
        t = utils.ui_text
        launcher = self._section_box_or_empty(layout, context, settings, 'build_actions', 'Build Launcher', '造形実行', 'MESH_CUBE', 'build_actions', default=False)
        _draw_npanel_prop(launcher, settings, 'build_action', text=t('Action', '操作'))
        action = str(getattr(settings, 'build_action', 'PRIMITIVE') or 'PRIMITIVE')
        if action == 'PRIMITIVE':
            self._op(launcher, 'smart_sculpt.add_primitive', text=t('Run Selected Build Action', '選択造形操作を実行'), icon='MESH_UVSPHERE', primitive=settings.compact_primitive_type, boolean_mode=settings.primitive_operation, radius=settings.primitive_radius, apply_boolean=settings.primitive_operation != 'NONE')
        elif action == 'SELECTION_BOOLEAN':
            self._op(launcher, 'smart_sculpt.boolean_from_selection', text=t('Run Selected Build Action', '選択造形操作を実行'), icon='MOD_BOOLEAN', operation=settings.compact_boolean_operation, apply_boolean=True, voxel_cleanup=settings.boolean_cleanup_voxel)
        elif action == 'RAIL_CUTTER':
            self._op(launcher, 'smart_sculpt.add_rail_cutter', text=t('Run Selected Build Action', '選択造形操作を実行'), icon='MOD_BOOLEAN', axis=settings.compact_axis, length=settings.rail_length, width=settings.rail_width, depth=settings.rail_depth, apply_to_target=settings.rail_apply_to_target, apply_boolean=settings.rail_apply_boolean, remove_cutter=settings.rail_remove_cutter, add_bevel=settings.rail_add_bevel)
        elif action == 'SPHERE_CHAIN':
            self._op(launcher, 'smart_sculpt.add_sphere_chain', text=t('Run Selected Build Action', '選択造形操作を実行'), icon='MESH_UVSPHERE', count=settings.compact_chain_count, radius=max(settings.primitive_radius * 0.6, 0.01), spacing=max(settings.primitive_radius * 0.9, 0.02))
        elif action == 'CURVE_TUBE':
            self._op(launcher, 'smart_sculpt.add_curve_tube', text=t('Run Selected Build Action', '選択造形操作を実行'), icon='CURVE_DATA', radius=max(settings.primitive_radius * 0.4, 0.01), length=max(settings.compact_curve_length, 0.05), convert_to_mesh=True)
        elif action == 'DETAIL_SCATTER':
            self._op(launcher, 'smart_sculpt.add_detail_scatter', text=t('Run Selected Build Action', '選択造形操作を実行'), icon='PARTICLES', count=settings.scatter_count, min_scale=settings.scatter_min_scale, max_scale=settings.scatter_max_scale, align_to_normal=settings.scatter_align_to_normal, normal_offset=settings.scatter_normal_offset, seed=settings.scatter_seed, avoid_overlap=settings.scatter_avoid_overlap, min_gap=settings.scatter_min_gap, tilt_degrees=settings.scatter_tilt_degrees)
        elif action == 'ANCHOR_BEND':
            self._op(launcher, 'smart_sculpt.create_anchor_bend_setup', text=t('Run Selected Build Action', '選択造形操作を実行'), icon='EMPTY_DATA', axis=settings.compact_axis, angle=0.0)
        elif action == 'PROCEDURAL':
            self._op(launcher, 'smart_sculpt.add_procedural_stack', text=t('Run Selected Build Action', '選択造形操作を実行'), icon='MODIFIER', preset=settings.compact_procedural_preset)
        primitive = self._section_box_or_empty(layout, context, settings, 'primitive_tools', 'Primitives', 'プリミティブ', 'MESH_UVSPHERE', 'primitive_tools', default=False)
        _draw_npanel_prop(primitive, settings, 'compact_primitive_type', text=t('Primitive', 'プリミティブ'))
        _draw_npanel_prop(primitive, settings, 'primitive_radius', text=t('Size', 'サイズ'))
        _draw_npanel_prop(primitive, settings, 'primitive_operation', text=t('Boolean', 'ブーリアン'))
        self._op(primitive, 'smart_sculpt.add_primitive', text=t('Create Primitive', 'プリミティブ作成'), icon='MESH_UVSPHERE', primitive=settings.compact_primitive_type, boolean_mode=settings.primitive_operation, radius=settings.primitive_radius, apply_boolean=settings.primitive_operation != 'NONE')
        boolean = self._section_box_or_empty(layout, context, settings, 'boolean_cutters', 'Boolean / Cutters', 'ブーリアン / カッター', 'MOD_BOOLEAN', 'boolean_cutters', default=False)
        _draw_npanel_prop(boolean, settings, 'compact_boolean_operation', text=t('Operation', '方式'))
        _draw_npanel_prop(boolean, settings, 'boolean_cleanup_voxel', text=t('Voxel Cleanup', 'ボクセル整理'))
        self._op(boolean, 'smart_sculpt.boolean_from_selection', text=t('Run Selection Boolean', '選択ブーリアン実行'), icon='MOD_BOOLEAN', operation=settings.compact_boolean_operation, apply_boolean=True, voxel_cleanup=settings.boolean_cleanup_voxel)
        _draw_npanel_prop(boolean, settings, 'compact_axis', text=t('Axis', '軸'))
        _draw_npanel_prop(boolean, settings, 'rail_length', text=t('Rail Length', 'レール長さ'))
        _draw_npanel_prop(boolean, settings, 'rail_width', text=t('Rail Width', 'レール幅'))
        _draw_npanel_prop(boolean, settings, 'rail_depth', text=t('Rail Depth', 'レール深さ'))
        _draw_npanel_prop(boolean, settings, 'rail_apply_to_target', text=t('Boolean To Target', 'ターゲットへブーリアン'))
        _draw_npanel_prop(boolean, settings, 'rail_apply_boolean', text=t('Apply', '適用'))
        _draw_npanel_prop(boolean, settings, 'rail_remove_cutter', text=t('Delete Cutter', 'カッター削除'))
        _draw_npanel_prop(boolean, settings, 'rail_add_bevel', text=t('Bevel Cutter', 'カッターにベベル'))
        self._op(boolean, 'smart_sculpt.add_rail_cutter', text=t('Create Rail Cutter', 'レールカッター作成'), icon='MOD_BOOLEAN', axis=settings.compact_axis, length=settings.rail_length, width=settings.rail_width, depth=settings.rail_depth, apply_to_target=settings.rail_apply_to_target, apply_boolean=settings.rail_apply_boolean, remove_cutter=settings.rail_remove_cutter, add_bevel=settings.rail_add_bevel)
        blockout = self._section_box_or_empty(layout, context, settings, 'blockout_forms', 'Blockout Forms', 'ブロックアウト形状', 'MESH_UVSPHERE', 'blockout_forms', default=False)
        _draw_npanel_prop(blockout, settings, 'compact_chain_count', text=t('Sphere Count', 'スフィア数'))
        _draw_npanel_prop(blockout, settings, 'primitive_radius', text=t('Size', 'サイズ'))
        self._op(blockout, 'smart_sculpt.add_sphere_chain', text=t('Create Sphere Chain', 'スフィアチェーン作成'), icon='MESH_UVSPHERE', count=settings.compact_chain_count, radius=max(settings.primitive_radius * 0.6, 0.01), spacing=max(settings.primitive_radius * 0.9, 0.02))
        _draw_npanel_prop(blockout, settings, 'compact_curve_length', text=t('Curve Length', 'カーブ長さ'))
        self._op(blockout, 'smart_sculpt.add_curve_tube', text=t('Create Curve Tube', 'カーブチューブ作成'), icon='CURVE_DATA', radius=max(settings.primitive_radius * 0.4, 0.01), length=max(settings.compact_curve_length, 0.05), convert_to_mesh=True)
        _draw_npanel_prop(blockout, settings, 'compact_axis', text=t('Bend Axis', 'ベンド軸'))
        self._op(blockout, 'smart_sculpt.create_anchor_bend_setup', text=t('Create Anchor Bend', 'アンカーベンド作成'), icon='EMPTY_DATA', axis=settings.compact_axis, angle=0.0)
        scatter = self._section_box_or_empty(layout, context, settings, 'scatter_procedural', 'Scatter / Procedural', '散布 / プロシージャル', 'PARTICLES', 'scatter_procedural', default=False)
        _draw_npanel_prop(scatter, settings, 'scatter_count', text=t('Count', '個数'))
        _draw_npanel_prop(scatter, settings, 'scatter_seed', text=t('Seed', 'シード'))
        _draw_npanel_prop(scatter, settings, 'scatter_min_scale', text=t('Min Scale', '最小スケール'))
        _draw_npanel_prop(scatter, settings, 'scatter_max_scale', text=t('Max Scale', '最大スケール'))
        _draw_npanel_prop(scatter, settings, 'scatter_align_to_normal', text=t('Align Normal', '法線合わせ'))
        _draw_npanel_prop(scatter, settings, 'scatter_normal_offset', text=t('Offset', 'オフセット'))
        _draw_npanel_prop(scatter, settings, 'scatter_avoid_overlap', text=t('Avoid Overlap', '重なり回避'))
        _draw_npanel_prop(scatter, settings, 'scatter_min_gap', text=t('Gap', '隙間'))
        _draw_npanel_prop(scatter, settings, 'scatter_tilt_degrees', text=t('Random Tilt', 'ランダム傾き'))
        self._op(scatter, 'smart_sculpt.add_detail_scatter', text=t('Scatter Detail', 'ディテール散布'), icon='PARTICLES', count=settings.scatter_count, min_scale=settings.scatter_min_scale, max_scale=settings.scatter_max_scale, align_to_normal=settings.scatter_align_to_normal, normal_offset=settings.scatter_normal_offset, seed=settings.scatter_seed, avoid_overlap=settings.scatter_avoid_overlap, min_gap=settings.scatter_min_gap, tilt_degrees=settings.scatter_tilt_degrees)
        _draw_npanel_prop(scatter, settings, 'compact_procedural_preset', text=t('Preset', 'プリセット'))
        _draw_npanel_prop(scatter, settings, 'procedural_strength', text=t('Strength', '強度'))
        _draw_npanel_prop(scatter, settings, 'procedural_scale', text=t('Scale', 'スケール'))
        self._op(scatter, 'smart_sculpt.add_procedural_stack', text=t('Add Procedural Stack', 'プロシージャル追加'), icon='MODIFIER', preset=settings.compact_procedural_preset)
        self._draw_integrated_section(layout, context, settings, 'integrated_build', 'Integrated Build Tools', '統合造形ツール', 'MESH_CUBE', 'tab_build', default=False, category='BUILD')

    def _draw_compact_settings(self, layout, context, settings, obj):
        prefs_box = self._section_box_or_empty(layout, context, settings, 'embedded_preferences', 'Preferences', 'プリファレンス', 'PREFERENCES', 'settings_all', default=False)
        _draw_embedded_preferences(prefs_box, context)
        _draw_all_scene_settings(layout, context, settings)
        self._draw_integrated_section(layout, context, settings, 'integrated_settings', 'Integrated Settings', '統合設定', 'PLUGIN', 'settings_all', default=False, category='SETTINGS')

    def _draw_compact_safe(self, layout, context, settings, obj):
        t = utils.ui_text
        snap_box = self._section_box_or_empty(layout, context, settings, 'snapshots', 'Snapshots', 'スナップショット', 'RECOVER_LAST', 'snapshots', default=False)
        _draw_npanel_prop(snap_box, settings, 'snapshot_action', text=t('Action', '操作'))
        snapshot_action = settings.snapshot_action
        safe_object_data = _object_data_lists_are_safe(context, obj)
        if safe_object_data and _has_snapshot_runtime(obj):
            if _safe_template_list(snap_box, 'SSS_UL_snapshots', '', obj, 'smart_sculpt_snapshots', obj, 'smart_sculpt_snapshot_index', rows=3):
                preview_name = str(obj.get('sss_snapshot_preview', '') or '')
                if preview_name:
                    snap_box.label(text=f"{t('Snapshot Preview', 'スナップショット比較表示')}: {preview_name}", icon=utils.safe_icon('HIDE_OFF'))
        if snapshot_action == 'SAVE':
            self._op(snap_box, 'smart_sculpt.save_snapshot', text=t('Save Snapshot', 'スナップショット保存'), icon='ADD')
        elif snapshot_action == 'RESTORE':
            self._op(snap_box, 'smart_sculpt.restore_snapshot', text=t('Restore Snapshot', 'スナップショット復元'), icon='IMPORT')
        elif snapshot_action == 'PREVIEW':
            self._op(snap_box, 'smart_sculpt.preview_snapshot', text=t('Snapshot Preview', 'スナップショット比較表示'), icon='HIDE_OFF')
        elif snapshot_action == 'CLEAR_PREVIEW':
            self._op(snap_box, 'smart_sculpt.clear_snapshot_preview', text=t('Clear Snapshot Preview', '比較表示を解除'), icon='HIDE_ON')
        elif snapshot_action == 'DELETE':
            self._op(snap_box, 'smart_sculpt.delete_snapshot', text=t('Delete Snapshot', 'スナップショット削除'), icon='TRASH')
        recovery_box = self._section_box_or_empty(layout, context, settings, 'recovery', 'Recovery', '回復', 'RECOVER_LAST', 'recovery', default=False)
        _draw_npanel_prop(recovery_box, settings, 'enable_recovery_backups', text=t('Recovery Backups', '回復バックアップ'))
        _draw_npanel_prop(recovery_box, settings, 'recovery_action', text=t('Action', '操作'))
        if settings.recovery_action == 'RESTORE':
            self._op(recovery_box, 'smart_sculpt.restore_recovery_backup', text=t('Restore Recovery Backup', '回復バックアップ復元'), icon='IMPORT')
        else:
            self._op(recovery_box, 'smart_sculpt.clear_recovery_backup', text=t('Delete Recovery Backup', '回復バックアップ削除'), icon='TRASH')
        if obj is not None:
            backup_name = utils.recovery_backup_name(obj)
            if backup_name:
                recovery_box.label(text=_clip_ui_text(f"{t('Backup', 'バックアップ')}: {backup_name}", 28), icon='RECOVER_LAST')
                reason = utils.recovery_backup_reason(obj)
                if reason:
                    recovery_box.label(text=_clip_ui_text(f"{t('Reason', '理由')}: {reason}", 28))
                saved_at = utils.recovery_backup_saved_at(obj)
                if saved_at:
                    recovery_box.label(text=_clip_ui_text(f"{t('Saved At', '保存日時')}: {saved_at}", 28))
        layer_box = self._section_box_or_empty(layout, context, settings, 'shape_layers', 'Shape Layers', 'シェイプレイヤー', 'SHAPEKEY_DATA', 'shape_layers', default=False)
        _draw_npanel_prop(layer_box, settings, 'layer_action', text=t('Action', '操作'))
        if settings.layer_action == 'DRIVE':
            _draw_npanel_prop(layer_box, settings, 'driver_bone', text=t('Driver Bone', '駆動ボーン'))
            _draw_npanel_prop(layer_box, settings, 'driver_channel', text=t('Channel', 'チャンネル'))
            _draw_npanel_prop(layer_box, settings, 'driver_min', text=t('Min', '最小'))
            _draw_npanel_prop(layer_box, settings, 'driver_max', text=t('Max', '最大'))
        if safe_object_data and obj and getattr(getattr(obj, 'data', None), 'shape_keys', None):
            if _safe_template_list(layer_box, 'MESH_UL_shape_keys', '', obj.data.shape_keys, 'key_blocks', obj, 'active_shape_key_index', rows=3):
                active_key = obj.active_shape_key
                if active_key is not None and obj.active_shape_key_index > 0:
                    _draw_npanel_prop(layer_box, active_key, 'value', text=t('Layer Strength', 'レイヤー強度'))
        layer_map = {'CREATE': ('smart_sculpt.create_shape_layer', t('Create Shape Layer', 'シェイプレイヤー作成'), 'ADD'), 'DUPLICATE': ('smart_sculpt.duplicate_active_shape_layer', t('Duplicate Active Layer', 'アクティブレイヤー複製'), 'DUPLICATE'), 'DELETE': ('smart_sculpt.delete_active_shape_layer', t('Delete Active Layer', 'アクティブレイヤー削除'), 'TRASH'), 'DRIVE': ('smart_sculpt.drive_active_shape_layer', t('Drive Active Layer', 'アクティブレイヤーを駆動'), 'DRIVER')}
        op_id, label, icon = layer_map[settings.layer_action]
        self._op(layer_box, op_id, text=label, icon=utils.safe_icon(icon))
        session_box = self._section_box_or_empty(layout, context, settings, 'sculpt_session', 'Sculpt Session', 'スカルプトセッション', 'DUPLICATE', 'sculpt_session', default=False)
        _draw_npanel_prop(session_box, settings, 'session_action', text=t('Action', '操作'))
        if settings.session_action == 'CREATE':
            _draw_npanel_prop(session_box, settings, 'session_mode', text=t('Session Mode', 'セッションモード'))
            _draw_npanel_prop(session_box, settings, 'session_face_set_mode', text=t('Face Set Mode', 'フェイスセットモード'))
            legacy_face_sets_col = _compact_npanel_layout(session_box.column(align=True))
            legacy_face_sets_col.enabled = True
            _draw_npanel_prop(legacy_face_sets_col, settings, 'session_initialize_face_sets', text=t('Legacy Face Set Fallback', '旧フェイスセット補完'))
            _draw_npanel_prop(session_box, settings, 'hide_originals_on_proxy', text=t('Hide Originals', '元を隠す'))
            self._op(session_box, 'smart_sculpt.create_proxy_session', text=t('Create Sculpt Session', 'スカルプトセッション作成'), icon='DUPLICATE')
        elif settings.session_action == 'RESTORE':
            self._op(session_box, 'smart_sculpt.restore_proxy_sources', text=t('Restore Session Sources', '元オブジェクトを再表示'), icon='HIDE_OFF')
        else:
            self._op(session_box, 'smart_sculpt.close_sculpt_session', text=t('Close Sculpt Session', 'スカルプトセッション終了'), icon='PANEL_CLOSE')
        if obj is not None and str(obj.get('sss_generated_kind', '') or '') in {'session', 'proxy'}:
            source_count = len(utils.session_source_names(obj))
            session_mode = str(obj.get('sss_session_mode', '') or settings.session_mode)
            session_box.label(text=f"{t('Active Session', '現在のセッション')}: {session_mode} | {t('Source Objects', '元オブジェクト数')}: {source_count}", icon='SCULPTMODE_HLT')
        transfer_box = self._section_box_or_empty(layout, context, settings, 'transfer_cleanup', 'Transfer & Cleanup', '受け渡しと整理', 'IMPORT', 'transfer_cleanup', default=False)
        _draw_npanel_prop(transfer_box, settings, 'transfer_action', text=t('Action', '操作'))
        if settings.transfer_action in {'EXPORT', 'IMPORT'}:
            _draw_npanel_prop(transfer_box, settings, 'exchange_format', text=t('Format', '形式'))
            _draw_npanel_prop(transfer_box, settings, 'exchange_scope', text=t('Scope', '対象'))
            _draw_npanel_prop(transfer_box, settings, 'exchange_timestamped_export', text=t('Timestamped Names', 'タイムスタンプ名'))
            _draw_npanel_prop(transfer_box, settings, 'exchange_dir', text=t('Folder', 'フォルダー'))
            if settings.transfer_action == 'EXPORT':
                self._op(transfer_box, 'smart_sculpt.export_exchange', text=t('Export Exchange', '受け渡し書き出し'), icon='EXPORT')
            else:
                self._op(transfer_box, 'smart_sculpt.import_latest_exchange', text=t('Import Latest Exchange', '最新受け渡しを読み込み'), icon='IMPORT')
        else:
            _draw_npanel_prop(transfer_box, settings, 'cleanup_include_snapshots', text=t('Include Snapshots', 'スナップショットも整理'))
            self._op(transfer_box, 'smart_sculpt.cleanup_generated_data', text=t('Cleanup Generated Data', '生成データ整理'), icon='TRASH')
        self._draw_integrated_section(layout, context, settings, 'integrated_safe', 'Integrated Safe Tools', '統合安全ツール', 'RECOVER_LAST', 'tab_safe', default=False, category='SAFE')

    def draw(self, context):
        try:
            panel_self = self
            if not callable(getattr(self, '_draw_always_on_toggles', None)):

                class _PanelDrawProxy:

                    def __init__(proxy_self, layout):
                        proxy_self.layout = layout

                    def __getattr__(proxy_self, name):
                        descriptor = vars(SSS_PT_main).get(name)
                        if descriptor is None:
                            raise AttributeError(name)
                        getter = getattr(descriptor, '__get__', None)
                        return getter(proxy_self, type(proxy_self)) if callable(getter) else descriptor
                panel_self = _PanelDrawProxy(self.layout)
            SSS_PT_main._draw_impl(panel_self, context)
        except Exception as exc:
            try:
                layout = _compact_npanel_layout(utils.localized_layout(self.layout))
                layout.label(text=f"{utils.ui_text('Smart Sculpt panel draw failed', 'スマートスカルプトパネル描画に失敗')}: {utils.exception_ui_text(exc)}", icon=utils.safe_icon('ERROR'))
            except Exception:
                pass

    def _draw_impl(self, context):
        t = utils.ui_text
        layout = _compact_npanel_layout(utils.localized_layout(self.layout))
        scene = _safe_context_scene(context)
        settings = getattr(scene, 'core', None) if scene is not None else None
        obj = utils.active_mesh_object(context)
        if settings is None:
            layout.label(text=t('Settings unavailable', '設定を取得できません'), icon=utils.safe_icon('ERROR'))
            return
        self._draw_always_on_toggles(layout, context, settings)
        try:
            self._section(layout, context, settings, 'edit_mode_sculpt', 'Edit Mode Sculpt Only', '編集モード専用スカルプト', 'EDITMODE_HLT', 'edit_mode_sculpt', lambda body: self._draw_edit_mode_sculpt(body, context, settings, obj), default=True)
        except Exception as exc:
            error_box = layout.box()
            error_box.label(text=f"{t('Edit Mode Sculpt section failed', '編集モード専用スカルプトセクションの描画に失敗')}: {utils.exception_ui_text(exc)}", icon=utils.safe_icon('ERROR'))
        top_sections = (('top_viewport', 'Viewport', 'ビューポート', 'SHADING_SOLID', 'top_viewport', lambda body: self._draw_top_viewport(body, context, settings, obj)), ('top_efficiency', 'Efficiency', '効率化', 'PLAY', 'top_efficiency', lambda body: self._draw_top_efficiency(body, context, settings, obj)), ('top_brush', 'Brush', 'ブラシ', 'BRUSH_DATA', 'top_brush', lambda body: self._draw_top_brush(body, context, settings, obj)), ('top_remesh_retopo', 'Remesh / Retopo', 'リメッシュ/リトポ', 'MOD_REMESH', 'top_remesh_retopo', lambda body: self._draw_top_remesh_retopo(body, context, settings, obj)), ('top_generate_deform', 'Generate / Deform', '生成/変形', 'MESH_CUBE', 'top_generate_deform', lambda body: self._draw_top_generate_deform(body, context, settings, obj)), ('top_analysis_repair', 'Analyze / Repair', '解析/修復', 'VIEWZOOM', 'top_analysis_repair', lambda body: self._draw_top_analysis_repair(body, context, settings, obj)), ('top_save_io', 'Save / I/O', '保存/入出力', 'EXPORT', 'top_save_io', lambda body: self._draw_top_save_io(body, context, settings, obj)))
        for section_key, title_en, title_ja, icon, topic_id, draw_fn in top_sections:
            try:
                self._section(layout, context, settings, section_key, title_en, title_ja, icon, topic_id, draw_fn, default=False)
            except Exception as exc:
                error_box = layout.box()
                error_box.label(text=f"{t('Smart Sculpt panel section failed', 'スマートスカルプトパネル項目の描画に失敗')}: {utils.exception_ui_text(exc)}", icon=utils.safe_icon('ERROR'))

    def draw_dashboard(self, layout, context, settings, obj):
        t = utils.ui_text
        box = self._section_box_or_empty(layout, context, settings, 'workspace', 'Workspace', 'ワークスペース', 'TOOL_SETTINGS', 'core_workflow', default=False)
        box.operator('smart_sculpt.prepare_workspace', text=t('Prepare', '準備'), icon='TOOL_SETTINGS')
        box.operator('smart_sculpt.toggle_silhouette', text=t('Silhouette', 'シルエット'), icon='SHADING_SOLID')
        box.operator('smart_sculpt.prepare_multi_object_sculpt', text=t('Prepare Multi-Object', '複数オブジェクト準備'), icon='GROUP')
        op = box.operator('smart_sculpt.cycle_selected_mesh', text=t('Previous Part', '前パーツ'), icon='TRIA_LEFT')
        op.direction = 'PREV'
        op = box.operator('smart_sculpt.cycle_selected_mesh', text=t('Next Part', '次パーツ'), icon='TRIA_RIGHT')
        op.direction = 'NEXT'
        _draw_npanel_prop(box, settings, 'auto_enter_sculpt', text=t('Auto Enter Sculpt', '自動でスカルプトへ'))
        _draw_npanel_prop(box, settings, 'multi_object_make_single_user', text=t('Make Shared Meshes Single-User', '共有メッシュをシングルユーザー化'))
        view_box = self._section_box_or_empty(layout, context, settings, 'viewport_presets', 'Viewport Presets', 'ビューポートプリセット', 'SHADING_SOLID', 'view_profile', default=False)
        op = view_box.operator('smart_sculpt.set_viewport_preset', text=t('Clay', 'クレイ'), icon='SHADING_SOLID')
        op.preset = 'CLAY'
        op = view_box.operator('smart_sculpt.set_viewport_preset', text=t('Technical', 'テクニカル'), icon='MOD_WIREFRAME')
        op.preset = 'TECHNICAL'
        op = view_box.operator('smart_sculpt.set_viewport_preset', text=t('Face Sets', 'フェイスセット'), icon='MESH_GRID')
        op.preset = 'FACESETS'
        op = view_box.operator('smart_sculpt.set_viewport_preset', text=t('Wireframe', 'ワイヤーフレーム'), icon='MOD_WIREFRAME')
        op.preset = 'WIREFRAME'
        box = self._section_box_or_empty(layout, context, settings, 'analysis_repair', 'Analysis & Repair', '解析と修復', 'CHECKMARK', 'analysis_repair', default=False)
        box.operator('smart_sculpt.analyze_active_mesh', text=t('Analyze', '解析'), icon='VIEWZOOM')
        box.operator('smart_sculpt.fix_common_issues', text=t('Fix', '修正'), icon='FILE_REFRESH')
        box.operator('smart_sculpt.export_diagnostic_report', text=t('Report', 'レポート'), icon='TEXT')
        _draw_npanel_prop(box, settings, 'apply_scale_on_fix', text=t('Apply Scale On Fix', '修正時にスケール適用'))
        _draw_npanel_prop(box, settings, 'recalc_normals_on_fix', text=t('Recalculate Normals', '法線再計算'))
        _draw_npanel_prop(box, settings, 'delete_loose_on_fix', text=t('Delete Loose Geometry', '孤立ジオメトリ削除'))
        _draw_npanel_prop(box, settings, 'dissolve_degenerate_on_fix', text=t('Dissolve Degenerate Geometry', '縮退ジオメトリ溶解'))
        if getattr(settings, 'dissolve_degenerate_on_fix', False):
            _draw_npanel_prop(box, settings, 'degenerate_threshold_on_fix', text=t('Degenerate Threshold', '縮退閾値'))
        _draw_npanel_prop(box, settings, 'merge_distance_on_fix', text=t('Merge Distance', 'マージ距離'))
        if settings.diagnostics:
            diag_box = box.box()
            diag_box.label(text=t('Current Findings', '現在の検出結果'))
            for item in settings.diagnostics:
                icon = 'DOT' if item.severity == 'INFO' else 'ERROR' if item.severity == 'ERROR' else 'QUESTION'
                col = diag_box.column(align=True)
                _draw_wrapped_label(col, None, item.title, icon=icon)
                if item.detail:
                    _draw_wrapped_label(col, None, item.detail)
        box = self._section_box_or_empty(layout, context, settings, 'quick_profiles', 'Quick Profiles', 'クイックプロファイル', 'SETTINGS', 'view_profile', default=False)
        _draw_npanel_prop(box, settings, 'profile', text='')
        op = box.operator('smart_sculpt.apply_profile', text=t('Apply Profile', 'プロファイル適用'), icon='PLAY')
        op.profile = settings.profile
        box = self._section_box_or_empty(layout, context, settings, 'quick_tools', 'Quick Tools', 'クイックツール', 'BRUSH_DATA', 'quick_tools', default=False)
        grid = self._button_grid(box, columns=2)
        tool_labels = {'DRAW': t('Draw', '描画'), 'CLAY': t('Clay', 'クレイ'), 'CLAY_STRIPS': t('Clay Strips', 'クレイストリップ'), 'GRAB': t('Grab', 'つかみ'), 'SMOOTH': t('Smooth', 'スムーズ'), 'SCRAPE': t('Scrape', 'スクレイプ'), 'POSE': t('Pose', 'ポーズ'), 'CLOTH': t('Cloth', 'クロス'), 'DRAW_SHARP': t('Draw Sharp', 'シャープ描画'), 'CREASE': t('Crease', 'クリーズ')}
        for tool, icon in [('DRAW', 'BRUSH_DATA'), ('CLAY', 'BRUSH_DATA'), ('CLAY_STRIPS', 'BRUSH_DATA'), ('GRAB', 'HAND'), ('SMOOTH', 'MOD_SMOOTH'), ('SCRAPE', 'MOD_BEVEL'), ('POSE', 'ARMATURE_DATA'), ('CLOTH', 'MOD_CLOTH'), ('DRAW_SHARP', 'IPO_EASE_IN_OUT'), ('CREASE', 'MOD_EDGESPLIT')]:
            op = grid.operator('smart_sculpt.set_sculpt_tool', text=tool_labels[tool], icon=utils.safe_icon(icon))
            op.tool = tool
        pipe_box = self._section_box_or_empty(layout, context, settings, 'tool_pipe', 'Tool Pipe', 'ツールパイプ', 'BRUSH_DATA', 'tool_pipe', default=False)
        for slot in (1, 2, 3):
            slot_attr = utils.tool_pipe_slot_attr(slot)
            slot_label = utils.tool_pipe_slot_label(settings, slot)
            slot_box = pipe_box.box()
            _draw_npanel_prop(slot_box, settings, slot_attr, text=f"{t('Slot', 'スロット')} {slot}")
            if not getattr(settings, slot_attr, ''):
                slot_box.label(text=slot_label, icon='BRUSH_DATA')
            op = slot_box.operator('smart_sculpt.use_brush_slot', text=t('Use', '使用'), icon='PLAY')
            op.slot = slot
            op = slot_box.operator('smart_sculpt.store_active_brush_slot', text=t('Save', '保存'), icon='IMPORT')
            op.slot = slot
            op = slot_box.operator('smart_sculpt.clear_brush_slot', text=t('Clear Slot', 'スロット消去'), icon='X')
            op.slot = slot
        box = self._section_box_or_empty(layout, context, settings, 'exchange', 'Exchange', '受け渡し', 'IMPORT', 'exchange', default=False)
        _draw_npanel_prop(box, settings, 'exchange_dir', text=t('Exchange Folder', '受け渡しフォルダ'))
        _draw_npanel_prop(box, settings, 'exchange_format', text=t('Exchange Format', '受け渡し形式'))
        _draw_npanel_prop(box, settings, 'exchange_scope', text=t('Exchange Scope', '受け渡し対象'))
        _draw_npanel_prop(box, settings, 'exchange_timestamped_export', text=t('Timestamped Export Names', 'タイムスタンプ書き出し名'))
        box.operator('smart_sculpt.export_exchange', text=t('Export', 'エクスポート'), icon='EXPORT')
        box.operator('smart_sculpt.import_latest_exchange', text=t('Import Latest', '最新を読み込み'), icon='IMPORT')

    def draw_topology(self, layout, context, settings, obj):
        t = utils.ui_text
        box = self._section_box_or_empty(layout, context, settings, 'dyntopo', 'Dyntopo', 'ダイナミックトポロジー', 'SCULPTMODE_HLT', 'dyntopo', default=False)
        _draw_npanel_prop(box, settings, 'dyntopo_mode', text=t('Mode', 'モード'))
        _draw_npanel_prop(box, settings, 'dyntopo_detail', text=t('Detail', '細かさ'))
        box.operator('smart_sculpt.configure_dyntopo', text=t('Configure', '設定する'), icon='MOD_TRIANGULATE')
        box.operator('smart_sculpt.detail_flood_fill', text=t('Flood Fill', '均一化'), icon='BRUSH_DATA')
        box = self._section_box_or_empty(layout, context, settings, 'voxel_remesh', 'Voxel & Remesh', 'ボクセルとリメッシュ', 'MOD_REMESH', 'voxel_remesh', default=False)
        _draw_npanel_prop(box, settings, 'voxel_size', text=t('Voxel Size', 'ボクセルサイズ'))
        _draw_npanel_prop(box, settings, 'voxel_adaptivity', text=t('Adaptivity', '適応度'))
        box.operator('smart_sculpt.voxel_remesh', text=t('Voxel', 'ボクセル'), icon='MOD_REMESH')
        box.operator('smart_sculpt.quadriflow_remesh', text=t('QuadriFlow', 'QuadriFlow'), icon='MOD_DECIM')
        box = self._section_box_or_empty(layout, context, settings, 'multires', 'Multires', 'マルチレゾ', 'MOD_MULTIRES', 'multires', default=False)
        _draw_npanel_prop(box, settings, 'multires_levels', text=t('Levels', 'レベル'))
        grid = self._button_grid(box, columns=2)
        actions = [('ADD', t('Add', '追加')), ('SUBDIVIDE', t('Subdivide', '細分化')), ('LEVEL_UP', '+'), ('LEVEL_DOWN', '-'), ('APPLY_BASE', t('Apply Base', 'ベース反映'))]
        multires_icons = {'ADD': 'ADD', 'SUBDIVIDE': 'MOD_MULTIRES', 'LEVEL_UP': 'TRIA_UP', 'LEVEL_DOWN': 'TRIA_DOWN', 'APPLY_BASE': 'CHECKMARK'}
        for action, text in actions:
            op = grid.operator('smart_sculpt.multires_action', text=text, icon=utils.safe_icon(multires_icons.get(action, 'MOD_MULTIRES')))
            op.action = action
        box = self._section_box_or_empty(layout, context, settings, 'mask_facesets', 'Mask & Face Sets', 'マスクとフェイスセット', 'MESH_GRID', 'mask_facesets', default=False)
        sub = box.box()
        sub.label(text=t('Mask', 'マスク'))
        grid = self._button_grid(sub, columns=2)
        mask_icons = {'SMOOTH': 'MOD_SMOOTH', 'SHARPEN': 'BRUSH_DATA', 'GROW': 'ADD', 'SHRINK': 'REMOVE', 'INVERT': 'IMAGE_ALPHA', 'CLEAR': 'X', 'CAVITY': 'BRUSH_DATA'}
        for action, text in [('SMOOTH', t('Smooth', 'スムーズ')), ('SHARPEN', t('Sharpen', 'シャープ化')), ('GROW', t('Grow', '拡張')), ('SHRINK', t('Shrink', '縮小')), ('INVERT', t('Invert', '反転')), ('CLEAR', t('Clear Mask', 'マスク解除')), ('CAVITY', t('Cavity', 'キャビティ'))]:
            op = grid.operator('smart_sculpt.mask_action', text=text, icon=utils.safe_icon(mask_icons.get(action, 'BRUSH_DATA')))
            op.action = action
        _draw_npanel_prop(sub, settings, 'extract_thickness', text=t('Extract Thickness', '抽出厚み'))
        _draw_npanel_prop(sub, settings, 'mask_extract_smooth_iterations', text=t('Smooth', 'スムーズ'))
        _draw_npanel_prop(sub, settings, 'mask_slice_fill_holes', text=t('Fill Holes', '穴埋め'))
        _draw_npanel_prop(sub, settings, 'mask_extract_add_boundary_loop', text=t('Boundary Loop', '境界ループ'))
        _draw_npanel_prop(sub, settings, 'mask_extract_apply_shrinkwrap', text=t('Shrinkwrap', 'シュリンクラップ'))
        sub.operator('smart_sculpt.mask_extract', text=t('Extract Mask', 'マスク抽出'), icon='MOD_SOLIDIFY')
        sub.operator('smart_sculpt.mask_slice', text=t('Slice Mask', 'マスクスライス'), icon='MESH_CUBE')
        sub = box.box()
        sub.label(text=t('Face Sets', 'フェイスセット'))
        grid = self._button_grid(sub, columns=2)
        face_set_buttons = [('INIT_LOOSE', t('Loose', 'ルーズ')), ('INIT_MATERIALS', t('Materials', 'マテリアル')), ('INIT_NORMALS', t('Normals', '法線')), ('INIT_UV_SEAMS', t('UV Seams', 'UVシーム')), ('INIT_SHARP_EDGES', t('Sharp', 'シャープ')), ('INIT_CREASES', t('Creases', 'クリース')), ('INIT_BEVEL_WEIGHT', t('Bevel', 'ベベル')), ('QUICK_POLYGROUP', t('Quick Polygroup', 'クイックポリグループ'))]
        face_set_icons = {'INIT_LOOSE': 'MESH_GRID', 'INIT_MATERIALS': 'MATERIAL', 'INIT_NORMALS': 'NORMALS_FACE', 'INIT_UV_SEAMS': 'GROUP_UVS', 'INIT_SHARP_EDGES': 'MOD_BEVEL', 'INIT_CREASES': 'MOD_EDGESPLIT', 'INIT_BEVEL_WEIGHT': 'MOD_BEVEL', 'QUICK_POLYGROUP': 'MESH_GRID'}
        for action, text_value in face_set_buttons:
            op = grid.operator('smart_sculpt.face_set_action', text=text_value, icon=utils.safe_icon(face_set_icons.get(action, 'MESH_GRID')))
            op.action = action
        extra_grid = self._button_grid(sub, columns=2)
        face_set_extra_icons = {'MASKED': 'IMAGE_ALPHA', 'VISIBLE': 'HIDE_OFF', 'RANDOMIZE': 'COLOR', 'TOGGLE_VIS': 'HIDE_OFF', 'SHOW_ACTIVE': 'HIDE_OFF', 'HIDE_ACTIVE': 'HIDE_ON', 'SHOW_ALL': 'RESTRICT_VIEW_OFF'}
        for action, text in [('MASKED', t('From Mask', 'マスクから')), ('VISIBLE', t('Visible', '可視部')), ('RANDOMIZE', t('Colors', '色替え')), ('TOGGLE_VIS', t('Solo', '単独表示')), ('SHOW_ACTIVE', t('Show Active', 'アクティブ表示')), ('HIDE_ACTIVE', t('Hide Active', 'アクティブ非表示')), ('SHOW_ALL', t('Show All', '全表示'))]:
            op = extra_grid.operator('smart_sculpt.face_set_action', text=text, icon=utils.safe_icon(face_set_extra_icons.get(action, 'MESH_GRID')))
            op.action = action
        sub.operator('smart_sculpt.face_set_extract', text=t('Extract Face Set', 'フェイスセット抽出'), icon='MOD_SOLIDIFY')
        box = self._section_box_or_empty(layout, context, settings, 'filters', 'Mesh / Cloth Filters', 'メッシュ / クロスフィルター', 'MOD_CLOTH', 'filters', default=False)
        _draw_npanel_prop(box, settings, 'filter_strength', text=t('Filter Strength', 'フィルター強度'))
        _draw_npanel_prop(box, settings, 'mesh_filter_type', text=t('Mesh Filter', 'メッシュフィルター'))
        op = box.operator('smart_sculpt.apply_mesh_filter', text=t('Apply Mesh', 'メッシュ適用'), icon=utils.safe_icon('MOD_SMOOTH'))
        op.filter_type = settings.mesh_filter_type
        op.strength = settings.filter_strength
        _draw_npanel_prop(box, settings, 'cloth_filter_type', text=t('Cloth Filter', 'クロスフィルター'))
        op = box.operator('smart_sculpt.apply_cloth_filter', text=t('Apply Cloth', 'クロス適用'), icon=utils.safe_icon('MOD_CLOTH'))
        op.filter_type = settings.cloth_filter_type
        op.strength = settings.filter_strength

    def draw_nondestructive(self, layout, context, settings, obj):
        t = utils.ui_text
        box = self._section_box_or_empty(layout, context, settings, 'snapshots', 'Snapshots', 'スナップショット', 'RECOVER_LAST', 'snapshots', default=False)
        box.operator('smart_sculpt.save_snapshot', text=t('Save', '保存'), icon='ADD')
        box.operator('smart_sculpt.restore_snapshot', text=t('Restore', '復元'), icon='IMPORT')
        box.operator('smart_sculpt.delete_snapshot', text=t('Delete', '削除'), icon='TRASH')
        box.operator('smart_sculpt.preview_snapshot', text=t('Snapshot Preview', 'スナップショット比較表示'), icon='HIDE_OFF')
        box.operator('smart_sculpt.clear_snapshot_preview', text=t('Clear Preview', '比較解除'), icon='HIDE_ON')
        safe_object_data = _object_data_lists_are_safe(context, obj)
        if safe_object_data and _has_snapshot_runtime(obj):
            if _safe_template_list(box, 'SSS_UL_snapshots', '', obj, 'smart_sculpt_snapshots', obj, 'smart_sculpt_snapshot_index', rows=4):
                preview_name = str(obj.get('sss_snapshot_preview', '') or '')
                if preview_name:
                    box.label(text=_clip_ui_text(f"{t('Snapshot Preview', 'スナップショット比較表示')}: {preview_name}", 28), icon=utils.safe_icon('HIDE_OFF'))
        recovery_box = self._section_box_or_empty(layout, context, settings, 'recovery', 'Recovery', '回復', 'FILE_REFRESH', 'recovery', default=False)
        recovery_box.operator('smart_sculpt.restore_recovery_backup', text=t('Restore', '復元'), icon='IMPORT')
        recovery_box.operator('smart_sculpt.clear_recovery_backup', text=t('Delete', '削除'), icon='TRASH')
        if obj is not None:
            backup_name = utils.recovery_backup_name(obj)
            if backup_name:
                recovery_box.label(text=_clip_ui_text(f"{t('Backup', 'バックアップ')}: {backup_name}", 28), icon='RECOVER_LAST')
                reason = utils.recovery_backup_reason(obj)
                if reason:
                    recovery_box.label(text=_clip_ui_text(f"{t('Reason', '理由')}: {reason}", 28))
                saved_at = utils.recovery_backup_saved_at(obj)
                if saved_at:
                    recovery_box.label(text=_clip_ui_text(f"{t('Saved At', '保存日時')}: {saved_at}", 28))
        box = self._section_box_or_empty(layout, context, settings, 'shape_layers', 'Shape Layers', 'シェイプレイヤー', 'SHAPEKEY_DATA', 'shape_layers', default=False)
        box.operator('smart_sculpt.create_shape_layer', text=t('Create', '作成'), icon='ADD')
        box.operator('smart_sculpt.duplicate_active_shape_layer', text=t('Duplicate', '複製'), icon='DUPLICATE')
        box.operator('smart_sculpt.delete_active_shape_layer', text=t('Delete', '削除'), icon='TRASH')
        if safe_object_data and obj and getattr(getattr(obj, 'data', None), 'shape_keys', None):
            if _safe_template_list(box, 'MESH_UL_shape_keys', '', obj.data.shape_keys, 'key_blocks', obj, 'active_shape_key_index', rows=4):
                active_key = obj.active_shape_key
                if active_key is not None and obj.active_shape_key_index > 0:
                    _draw_npanel_prop(box, active_key, 'value', text=t('Layer Strength', 'レイヤー強度'))
        driver_box = self._section_box_or_empty(layout, context, settings, 'bone_driven_layer', 'Bone-driven Layer', 'ボーン駆動レイヤー', 'DRIVER', 'shape_layers', default=False)
        _draw_npanel_prop(driver_box, settings, 'driver_bone', text=t('Driver Bone', '駆動ボーン'))
        _draw_npanel_prop(driver_box, settings, 'driver_channel', text=t('Driver Channel', '駆動チャンネル'))
        _draw_npanel_prop(driver_box, settings, 'driver_min', text=t('Min', '最小'))
        _draw_npanel_prop(driver_box, settings, 'driver_max', text=t('Max', '最大'))
        driver_box.operator('smart_sculpt.drive_active_shape_layer', text=t('Drive Active Layer', 'アクティブレイヤーを駆動'), icon='DRIVER')
        box = self._section_box_or_empty(layout, context, settings, 'sculpt_session', 'Sculpt Session', 'スカルプトセッション', 'OUTLINER_COLLECTION', 'sculpt_session', default=False)
        _draw_npanel_prop(box, settings, 'session_mode', text=t('Session Mode', 'セッションモード'))
        _draw_npanel_prop(box, settings, 'session_face_set_mode', text=t('Session Face Set Mode', 'セッションのフェイスセットモード'))
        legacy_face_sets_col = _compact_npanel_layout(box.column(align=True))
        legacy_face_sets_col.enabled = True
        _draw_npanel_prop(legacy_face_sets_col, settings, 'session_initialize_face_sets', text=t('Legacy Face Set Fallback', '旧フェイスセット補完'))
        _draw_npanel_prop(box, settings, 'hide_originals_on_proxy', text=t('Hide Originals In Session', 'セッション作成時に元を隠す'))
        if obj is not None and str(obj.get('sss_generated_kind', '')) in {'session', 'proxy'}:
            source_count = len(utils.session_source_names(obj))
            session_mode = str(obj.get('sss_session_mode', '') or settings.session_mode)
            box.label(text=_clip_ui_text(f"{t('Active Session', '現在のセッション')}: {session_mode}", 28), icon='SCULPTMODE_HLT')
            box.label(text=_clip_ui_text(f"{t('Source Objects', '元オブジェクト数')}: {source_count}", 28))
        box.operator('smart_sculpt.create_proxy_session', text=t('Create Session', 'セッション作成'), icon='DUPLICATE')
        box.operator('smart_sculpt.restore_proxy_sources', text=t('Restore Sources', '元を再表示'), icon='HIDE_OFF')
        box.operator('smart_sculpt.close_sculpt_session', text=t('Close Session', 'セッション終了'), icon='PANEL_CLOSE')

    def draw_procedural(self, layout, context, settings, obj):
        t = utils.ui_text
        box = self._section_box_or_empty(layout, context, settings, 'primitive_boolean', 'Primitive & Boolean', 'プリミティブとブーリアン', 'MESH_UVSPHERE', 'primitive_boolean', default=False)
        _draw_npanel_prop(box, settings, 'primitive_radius', text=t('Primitive Radius', 'プリミティブ半径'))
        _draw_npanel_prop(box, settings, 'primitive_operation', text=t('Boolean Mode', 'ブーリアンモード'))
        grid = self._button_grid(box, columns=2)
        primitive_labels = {'SPHERE': t('Sphere', '球'), 'CUBE': t('Cube', '立方体'), 'CYLINDER': t('Cylinder', '円柱'), 'CONE': t('Cone', '円錐'), 'TORUS': t('Torus', 'トーラス')}
        for primitive, icon in [('SPHERE', 'MESH_UVSPHERE'), ('CUBE', 'MESH_CUBE'), ('CYLINDER', 'MESH_CYLINDER'), ('CONE', 'MESH_CONE'), ('TORUS', 'MESH_TORUS')]:
            op = grid.operator('smart_sculpt.add_primitive', text=primitive_labels[primitive], icon=utils.safe_icon(icon))
            op.primitive = primitive
            op.boolean_mode = settings.primitive_operation
            op.radius = settings.primitive_radius
            op.apply_boolean = True
        sub = box.box()
        sub.label(text=t('Selection Boolean', '選択ブーリアン'))
        _draw_npanel_prop(sub, settings, 'boolean_cleanup_voxel', text=t('Voxel Cleanup After Boolean', 'ブーリアン後にボクセル整理'))
        grid = self._button_grid(sub, columns=2)
        boolean_icons = {'UNION': 'SELECT_EXTEND', 'DIFFERENCE': 'SELECT_SUBTRACT', 'INTERSECT': 'SELECT_INTERSECT'}
        for operation, text in [('UNION', t('Union', '結合')), ('DIFFERENCE', t('Difference', '差分')), ('INTERSECT', t('Intersect', '積集合'))]:
            op = grid.operator('smart_sculpt.boolean_from_selection', text=text, icon=utils.safe_icon(boolean_icons.get(operation, 'MOD_BOOLEAN')))
            op.operation = operation
            op.voxel_cleanup = settings.boolean_cleanup_voxel
        box = self._section_box_or_empty(layout, context, settings, 'sphere_tube', 'Sphere Chain & Tube', 'スフィアチェーンとチューブ', 'CURVE_DATA', 'sphere_tube', default=False)
        op = box.operator('smart_sculpt.add_sphere_chain', text=t('Sphere Chain', 'スフィアチェーン'), icon='MESH_UVSPHERE')
        op.radius = max(settings.primitive_radius * 0.6, 0.01)
        op.spacing = max(settings.primitive_radius * 0.9, 0.02)
        op = box.operator('smart_sculpt.add_curve_tube', text=t('Curve Tube', 'カーブチューブ'), icon='CURVE_DATA')
        op.radius = max(settings.primitive_radius * 0.4, 0.01)
        op.length = max(settings.primitive_radius * 4.0, 0.1)
        op.convert_to_mesh = True
        box = self._section_box_or_empty(layout, context, settings, 'rail_scatter', 'Rail Cutter & Scatter', 'レールカッターと散布', 'MOD_BOOLEAN', 'rail_scatter', default=False)
        col = box.column(align=True)
        _draw_npanel_prop(col, settings, 'rail_length', text=t('Length', '長さ'))
        _draw_npanel_prop(col, settings, 'rail_width', text=t('Width', '幅'))
        _draw_npanel_prop(col, settings, 'rail_depth', text=t('Depth', '深さ'))
        options = col.column(align=True)
        _draw_npanel_prop(options, settings, 'rail_apply_to_target', text=t('Boolean To Target', 'ターゲットへブーリアン'))
        _draw_npanel_prop(options, settings, 'rail_apply_boolean', text=t('Apply Boolean', 'ブーリアン適用'))
        _draw_npanel_prop(options, settings, 'rail_remove_cutter', text=t('Delete Cutter', 'カッター削除'))
        _draw_npanel_prop(options, settings, 'rail_add_bevel', text=t('Bevel Cutter', 'カッターにベベル'))
        rail_grid = self._button_grid(col, columns=2)
        for axis, text_value in [('X', t('Rail X', 'Xレール')), ('Y', t('Rail Y', 'Yレール')), ('Z', t('Rail Z', 'Zレール'))]:
            op = rail_grid.operator('smart_sculpt.add_rail_cutter', text=text_value, icon='MOD_BOOLEAN')
            op.axis = axis
            op.length = settings.rail_length
            op.width = settings.rail_width
            op.depth = settings.rail_depth
            op.apply_to_target = settings.rail_apply_to_target
            op.apply_boolean = settings.rail_apply_boolean
            op.remove_cutter = settings.rail_remove_cutter
            op.add_bevel = settings.rail_add_bevel
        col.separator()
        _draw_npanel_prop(col, settings, 'scatter_count', text=t('Count', '個数'))
        _draw_npanel_prop(col, settings, 'scatter_seed', text=t('Seed', 'シード'))
        _draw_npanel_prop(col, settings, 'scatter_min_scale', text=t('Min Scale', '最小スケール'))
        _draw_npanel_prop(col, settings, 'scatter_max_scale', text=t('Max Scale', '最大スケール'))
        _draw_npanel_prop(col, settings, 'scatter_align_to_normal', text=t('Align To Normal', '法線に合わせる'))
        _draw_npanel_prop(col, settings, 'scatter_normal_offset', text=t('Offset', 'オフセット'))
        _draw_npanel_prop(col, settings, 'scatter_avoid_overlap', text=t('Avoid Overlap', '重なり回避'))
        _draw_npanel_prop(col, settings, 'scatter_min_gap', text=t('Gap', '隙間'))
        _draw_npanel_prop(col, settings, 'scatter_tilt_degrees', text=t('Random Tilt', 'ランダム傾き'))
        op = col.operator('smart_sculpt.add_detail_scatter', text=t('Scatter Detail', 'ディテール散布'), icon='PARTICLES')
        op.count = settings.scatter_count
        op.min_scale = settings.scatter_min_scale
        op.max_scale = settings.scatter_max_scale
        op.align_to_normal = settings.scatter_align_to_normal
        op.normal_offset = settings.scatter_normal_offset
        op.seed = settings.scatter_seed
        op.avoid_overlap = getattr(settings, 'scatter_avoid_overlap', False)
        op.min_gap = getattr(settings, 'scatter_min_gap', 0.0)
        op.tilt_degrees = getattr(settings, 'scatter_tilt_degrees', 0.0)
        box = self._section_box_or_empty(layout, context, settings, 'anchor_bend', 'Anchor Bend', 'アンカーベンド', 'EMPTY_DATA', 'anchor_bend', default=False)
        grid = self._button_grid(box, columns=2)
        axis_icons = {'X': 'EVENT_X', 'Y': 'EVENT_Y', 'Z': 'EVENT_Z'}
        for axis, label_text in [('X', t('Bend X', 'Xベンド')), ('Y', t('Bend Y', 'Yベンド')), ('Z', t('Bend Z', 'Zベンド'))]:
            op = grid.operator('smart_sculpt.create_anchor_bend_setup', text=label_text, icon=utils.safe_icon(axis_icons.get(axis, 'EMPTY_DATA')))
            op.axis = axis
            op.angle = 0.0
        box = self._section_box_or_empty(layout, context, settings, 'procedural_stack', 'Procedural Stack', 'プロシージャルスタック', 'MODIFIER', 'procedural_stack', default=False)
        _draw_npanel_prop(box, settings, 'procedural_strength', text=t('Detail Strength', 'ディテール強度'))
        _draw_npanel_prop(box, settings, 'procedural_scale', text=t('Detail Scale', 'ディテールスケール'))
        grid = self._button_grid(box, columns=2)
        procedural_icons = {'SURFACE_NOISE': 'TEXTURE', 'MICRO_BREAKUP': 'BRUSH_DATA', 'SHELL': 'MOD_SOLIDIFY', 'WRINKLE': 'MOD_CLOTH', 'SCAFFOLDER': 'MODIFIER', 'DLA_GROWTH': 'PARTICLES', 'HYBRID_SURFACE': 'MOD_REMESH'}
        for preset, text in [('SURFACE_NOISE', t('Noise', 'ノイズ')), ('MICRO_BREAKUP', t('Micro', 'マイクロ')), ('SHELL', t('Shell', 'シェル')), ('WRINKLE', t('Wrinkle', 'しわ')), ('SCAFFOLDER', t('Scaffolder', 'スキャフォールダー')), ('DLA_GROWTH', t('Aggregate', '集合体')), ('HYBRID_SURFACE', t('Hybrid', 'ハイブリッド'))]:
            op = grid.operator('smart_sculpt.add_procedural_stack', text=text, icon=utils.safe_icon(procedural_icons.get(preset, 'MODIFIER')))
            op.preset = preset

    def draw_retopo(self, layout, context, settings, obj):
        t = utils.ui_text
        box = self._section_box_or_empty(layout, context, settings, 'retopo_setup', 'Retopo Setup', 'リトポセットアップ', 'SNAP_FACE', 'retopo_setup', default=False)
        _draw_npanel_prop(box, settings, 'quad_target_faces', text=t('QuadriFlow Target', 'クアッドリメッシュ目標面数'))
        _draw_npanel_prop(box, settings, 'retopo_offset', text=t('Retopo Offset', 'リトポオフセット'))
        _draw_npanel_prop(box, settings, 'retopo_use_mirror', text=t('Use Mirror', 'ミラーを使う'))
        box.operator('smart_sculpt.quadriflow_remesh', text=t('QuadriFlow', 'QuadriFlow'), icon='MOD_DECIM')
        box.operator('smart_sculpt.create_retopo_setup', text=t('Create Setup', 'セットアップ作成'), icon='SNAP_FACE')
        box = self._section_box_or_empty(layout, context, settings, 'auto_uv', 'Auto UV', '自動UV', 'GROUP_UVS', 'auto_uv', default=False)
        _draw_npanel_prop(box, settings, 'unwrap_margin', text=t('UV Margin', 'UVマージン'))
        box.operator('smart_sculpt.auto_uv_project', text=t('Run Auto UV', '自動UV展開'), icon='GROUP_UVS')
        box = self._section_box_or_empty(layout, context, settings, 'cleanup', 'Cleanup', '整理', 'TRASH', 'cleanup', default=False)
        _draw_npanel_prop(box, settings, 'cleanup_include_snapshots', text=t('Include Snapshots', 'スナップショットも整理'))
        box.operator('smart_sculpt.cleanup_generated_data', text=t('Cleanup Generated Data', '生成データ整理'), icon='TRASH')
_PANEL_CLASSES = (SSS_PT_main,)
classes = (SSS_OT_toggle_ui_section, SSS_UL_snapshots, SSS_MT_quick_pie, SSS_PT_main)

def refresh_npanel_runtime() -> bool:
    cleanup_legacy_smarttools_npanel_artifacts()
    try:
        _navigation_properties.force_runtime_refresh(preferred_owner='core')
    except Exception:
        pass
    return True

def npanel_runtime_needs_refresh() -> bool:
    return False

def has_npanel_host_candidates() -> bool:
    return False

def cancel_npanel_runtime_refresh():
    return None

def schedule_npanel_runtime_refresh(*_args, **_kwargs):
    refresh_npanel_runtime()
    return None

def install_npanel_runtime():
    return refresh_npanel_runtime()

def uninstall_npanel_runtime():
    cleanup_legacy_smarttools_npanel_artifacts()
    try:
        _navigation_properties.uninstall('core')
    except Exception:
        pass
    return None
