# ============================================================================
# Render Naming - Properties
# ============================================================================
# All property definitions for the extension
# Properties can be stored per-scene or globally (shared across all scenes)

import bpy
from bpy.props import (
    StringProperty,
    BoolProperty,
    IntProperty,
    EnumProperty,
    CollectionProperty,
    PointerProperty,
)
from bpy.types import PropertyGroup

from ..translation import localize_inline, localize_pair


def _persistent_property(factory):
    def _factory(*args, **kwargs):
        options = dict(kwargs)
        previous = options.get('update')

        def _update(self, context):
            if callable(previous):
                previous(self, context)
            try:
                from .. import settings as _suite_settings
                if not _suite_settings.is_applying_context():
                    _suite_settings.snapshot_context(context, force=False)
            except Exception:
                pass

        options['update'] = _update
        return factory(*args, **options)
    return _factory


StringProperty = _persistent_property(StringProperty)
BoolProperty = _persistent_property(BoolProperty)
IntProperty = _persistent_property(IntProperty)
EnumProperty = _persistent_property(EnumProperty)


# ============================================================================
# Property Definitions
# ============================================================================

class RENDERNAMES_PresetItem(PropertyGroup):
    """Individual preset entry for the presets list."""
    name: StringProperty(
        name="Preset Name",
        default="",
    )


class RENDERNAMES_GlobalSettings(PropertyGroup):
    """Global settings stored on WindowManager - single source of truth for global mode."""
    
    # Copy of all synced properties
    enabled: BoolProperty(default=False)
    template: StringProperty(default="{{scene}}_")
    base_path: StringProperty(default="")
    use_base_path: BoolProperty(default=False)
    folder_per_scene: BoolProperty(default=False)
    folder_per_camera: BoolProperty(default=False)
    folder_per_date: BoolProperty(default=False)
    use_blend_root: BoolProperty(default=False)
    sanitize_names: BoolProperty(default=True)
    lowercase: BoolProperty(default=False)
    frame_padding: IntProperty(default=4, min=1, max=8)
    include_extension: BoolProperty(default=True)
    auto_refresh_preview: BoolProperty(default=False)


class RENDERNAMES_Properties(PropertyGroup):
    """Main property group for Render Naming settings."""
    
    # -------------------------------------------------------------------------
    # Master Toggle
    # -------------------------------------------------------------------------
    enabled: BoolProperty(
        name=localize_pair("レンダー時の出力名フック", "Render-time Output Hook"),
        description=localize_pair(
            "レンダー開始時にテンプレートから出力パスを生成し、レンダー終了またはキャンセル後に元のパスへ戻す常時起動フックです。通常はNパネル最上部の「常時機能切り替え」でオン・オフします。",
            "Always-on hook that builds a render output path from the template at render start and restores the original path after render completion or cancel. Normally switch this from the Always-on Toggles group at the top of the N-panel.",
        ),
        default=False,
        update=lambda self, ctx: _on_enabled_changed(self, ctx),
    )
    
    # -------------------------------------------------------------------------
    # Storage Mode (Global vs Per-Scene)
    # -------------------------------------------------------------------------
    use_global_settings: BoolProperty(
        name="Use Global Settings",
        description="Share settings across all scenes. When off, each scene has its own settings",
        default=True,
        update=lambda self, ctx: _on_storage_mode_changed(self, ctx),
    )
    
    # -------------------------------------------------------------------------
    # Template System
    # -------------------------------------------------------------------------
    template: StringProperty(
        name="Template",
        description="Template for render output naming. Use {{variable}} syntax",
        default="{{scene}}_",
        update=lambda self, ctx: _update_preview(self, ctx),
    )
    
    base_path: StringProperty(
        name="Base Path",
        description=localize_pair('レンダー出力の手動ベースフォルダーです。空欄のままなら Blender の設定フォルダー内の Smart_Render_Suite 出力先を使用します。', "Manual base directory for renders. Leave empty to use the Smart_Render_Suite output folder in Blender's config directory."),
        default="",
        subtype="DIR_PATH",
        update=lambda self, ctx: _on_setting_changed(self, ctx),
    )
    
    use_base_path: BoolProperty(
        name="Use Custom Base Path",
        description=localize_pair('Blender の設定フォルダー内の Smart_Render_Suite 出力先ではなく、上の手動ベースパスを使用します。', "Use the manual base path instead of the Smart_Render_Suite output folder in Blender's config directory."),
        default=False,
        update=lambda self, ctx: _on_setting_changed(self, ctx),
    )
    
    # -------------------------------------------------------------------------
    # Organization Options (Folder Creation)
    # -------------------------------------------------------------------------
    folder_per_scene: BoolProperty(
        name="Folder per Scene",
        description="Create a subfolder for each scene",
        default=False,
        update=lambda self, ctx: _sync_template_from_options(self, ctx),
    )
    
    folder_per_camera: BoolProperty(
        name="Folder per Camera",
        description="Create a subfolder for each camera",
        default=False,
        update=lambda self, ctx: _sync_template_from_options(self, ctx),
    )
    
    folder_per_date: BoolProperty(
        name="Folder per Date",
        description="Create a subfolder for each render date",
        default=False,
        update=lambda self, ctx: _sync_template_from_options(self, ctx),
    )
    
    use_blend_root: BoolProperty(
        name="Use Blend File as Root",
        description="Use the .blend filename as the root folder",
        default=False,
        update=lambda self, ctx: _sync_template_from_options(self, ctx),
    )
    
    # -------------------------------------------------------------------------
    # Naming Options
    # -------------------------------------------------------------------------
    sanitize_names: BoolProperty(
        name="Sanitize Names",
        description="Replace special characters and spaces with underscores",
        default=True,
        update=lambda self, ctx: _on_setting_changed(self, ctx),
    )
    
    lowercase: BoolProperty(
        name="Lowercase",
        description="Convert all text to lowercase",
        default=False,
        update=lambda self, ctx: _on_setting_changed(self, ctx),
    )
    
    frame_padding: IntProperty(
        name="Frame Padding",
        description="Number of digits for frame numbers (e.g., 4 = 0001)",
        default=4,
        min=1,
        max=8,
        update=lambda self, ctx: _on_setting_changed(self, ctx),
    )
    
    # -------------------------------------------------------------------------
    # File Format Override
    # -------------------------------------------------------------------------
    include_extension: BoolProperty(
        name="Include Extension",
        description="Automatically append file extension based on output format",
        default=True,
        update=lambda self, ctx: _on_setting_changed(self, ctx),
    )
    
    # -------------------------------------------------------------------------
    # Optional Runtime Preview Refresh
    # -------------------------------------------------------------------------
    auto_refresh_preview: BoolProperty(
        name=localize_pair("自動プレビュー更新", "Auto Refresh Preview"),
        description=localize_pair(
            "プレビューはテンプレート変更時とパネル描画時に更新されます。この旧項目は互換用で、バックグラウンド更新タイマーは登録しません。",
            "The preview updates on template edits and panel draw. This legacy compatibility setting no longer registers a background timer.",
        ),
        default=False,
        update=lambda self, ctx: _on_auto_refresh_preview_changed(self, ctx),
    )

    # -------------------------------------------------------------------------
    # Live Preview (Read-only, computed)
    # -------------------------------------------------------------------------
    preview: StringProperty(
        name="Preview",
        description="Live preview of the render output path",
        default="",
    )
    
    # -------------------------------------------------------------------------
    # UI State
    # -------------------------------------------------------------------------
    show_options: BoolProperty(
        name="Show Options",
        description="Expand/collapse the options panel",
        default=True,
        update=lambda self, ctx: _on_setting_changed(self, ctx),
    )
    
    show_variables: BoolProperty(
        name="Show Tokens",
        description="Expand/collapse the variables reference",
        default=False,
        update=lambda self, ctx: _on_setting_changed(self, ctx),
    )
    
    # -------------------------------------------------------------------------
    # Preset Management
    # -------------------------------------------------------------------------
    preset_name: StringProperty(
        name="Preset Name",
        description="Name for saving the current settings as a preset",
        default="",
        update=lambda self, ctx: _on_setting_changed(self, ctx),
    )
    
    presets: CollectionProperty(
        type=RENDERNAMES_PresetItem,
        name="Presets",
    )
    
    active_preset_index: IntProperty(
        name="Active Preset",
        default=0,
        update=lambda self, ctx: _on_setting_changed(self, ctx),
    )


# ============================================================================
# Update Callbacks
# ============================================================================

def _on_enabled_changed(props, context):
    """Start or stop Render Naming background hooks when the central switch changes."""
    try:
        from . import handlers
        sync_path = getattr(handlers, 'sync_render_path_hooks', None)
        if callable(sync_path):
            sync_path(context)
        handlers.sync_runtime_hooks(context)
    except Exception:
        pass

    # Cross-scene propagation below intentionally assigns the same value to
    # every global-mode scene under the preset guard.  Do not recursively
    # propagate or save those mirror assignments back through the active scene.
    try:
        from . import presets
        if presets.is_applying_preset():
            return
    except Exception:
        pass

    # ``enabled`` is the centralized Always-on switch.  Changing that one
    # switch must not copy every Scene naming option over the independently
    # persisted WindowManager/global profile.  In particular, a freshly opened
    # scene can legitimately contain older/local naming values while the user
    # profile already contains newer global values.  The former implementation
    # called ``_on_setting_changed`` here, which copied the entire Scene group
    # and silently rolled the global profile back whenever the runtime was
    # toggled ON or OFF.
    if (
        props.use_global_settings
        and context is not None
        and getattr(context, "scene", None) is not None
    ):
        _save_to_global_settings(context, property_names=("enabled",))
        _sync_global_to_all_scenes(context, property_names=("enabled",))

    try:
        from .. import settings as persistent_settings
        persistent_settings.snapshot_context(
            context,
            force=persistent_settings.is_npanel_state_save_enabled(context),
        )
    except Exception:
        pass


def _on_setting_changed(props, context):
    """Called when any synced setting changes. Syncs to global and other scenes if in global mode."""
    from . import presets

    # Don't sync while applying a preset
    if presets.is_applying_preset():
        try:
            from . import handlers
            handlers.sync_runtime_hooks(context)
        except Exception:
            pass
        return

    if props.use_global_settings and context is not None and context.scene is not None:
        # Update the global storage on WindowManager
        _save_to_global_settings(context)

        # IMMEDIATELY sync to all other scenes in global mode
        _sync_global_to_all_scenes(context)

    try:
        from . import handlers
        handlers.sync_runtime_hooks(context)
    except Exception:
        pass
    try:
        from .. import settings as persistent_settings
        persistent_settings.snapshot_context(
            context,
            force=persistent_settings.is_npanel_state_save_enabled(context),
        )
    except Exception:
        pass


def _update_preview(props, context):
    """Update the live preview when template changes."""
    # Import here to avoid circular imports
    from . import template_engine
    from . import presets
    
    if context.scene:
        preview_path = template_engine.render_template(
            props.template,
            context.scene,
            props,
        )
        props["preview"] = preview_path
        
        # If using global settings and not applying a preset, sync to global and other scenes
        if props.use_global_settings and not presets.is_applying_preset():
            _save_to_global_settings(context)
            _sync_global_to_all_scenes(context)

        try:
            from . import handlers
            handlers.sync_runtime_hooks(context)
        except Exception:
            pass
        try:
            from .. import settings as persistent_settings
            persistent_settings.snapshot_context(
                context,
                force=persistent_settings.is_npanel_state_save_enabled(context),
            )
        except Exception:
            pass


def _sync_template_from_options(props, context):
    """Build template path from folder structure checkboxes."""
    # Don't overwrite template while applying a preset
    from . import presets
    if presets.is_applying_preset():
        return
    
    parts = []
    
    # Root folder
    if props.use_blend_root:
        parts.append("{{blend_file}}")
    
    # Subfolders
    if props.folder_per_scene:
        parts.append("{{scene}}")
    if props.folder_per_camera:
        parts.append("{{camera}}")
    if props.folder_per_date:
        parts.append("{{date}}")
    
    # Filename base
    if not props.folder_per_scene:
        # If scene isn't a folder, include it in filename
        parts.append("{{scene}}_")
    else:
        # Scene is already a folder, just add underscore for frame
        parts.append("")
    
    # Build path
    props.template = "/".join(parts)
    
    # Update preview (this also handles global sync)
    _update_preview(props, context)


def _on_storage_mode_changed(props, context):
    """Called when use_global_settings toggle changes."""
    if props.use_global_settings:
        # Switching to global mode - copy current scene settings to global
        _save_to_global_settings(context)
    else:
        # Switching to local mode - settings stay as-is for this scene
        pass

    try:
        from . import handlers
        handlers.sync_runtime_hooks(context)
    except Exception:
        pass
    try:
        from .. import settings as persistent_settings
        persistent_settings.snapshot_context(
            context,
            force=persistent_settings.is_npanel_state_save_enabled(context),
        )
    except Exception:
        pass


def _on_auto_refresh_preview_changed(props, context):
    """Enable preview timers only when the user explicitly asks for them."""
    _on_setting_changed(props, context)
    try:
        from . import handlers
        handlers.sync_runtime_hooks(context)
    except Exception:
        pass


# ============================================================================
# Global Settings Helpers
# ============================================================================

# Properties to sync between global and local settings
_SYNC_PROPERTIES = [
    "enabled",
    "template",
    "base_path",
    "use_base_path",
    "folder_per_scene",
    "folder_per_camera",
    "folder_per_date",
    "use_blend_root",
    "sanitize_names",
    "lowercase",
    "frame_padding",
    "include_extension",
    "auto_refresh_preview",
]


def _get_global_settings(context):
    """Get the global settings property group from WindowManager."""
    try:
        wm = context.window_manager
        return getattr(wm, "rendernames_global", None)
    except Exception:
        return None


def _save_to_global_settings(context, *, property_names=None):
    """Save current scene's settings to the global storage on WindowManager."""
    if not context.scene or not hasattr(context.scene, "rendernames"):
        return
    
    scene_props = context.scene.rendernames
    global_props = _get_global_settings(context)
    
    if global_props is None:
        return
    
    # Copy all synced properties for ordinary global-setting edits, or the
    # explicitly requested subset for a narrowly scoped action such as the
    # centralized runtime switch.
    names = tuple(property_names) if property_names is not None else _SYNC_PROPERTIES
    for prop_name in names:
        if prop_name not in _SYNC_PROPERTIES:
            continue
        if hasattr(scene_props, prop_name):
            value = getattr(scene_props, prop_name)
            if hasattr(global_props, prop_name):
                setattr(global_props, prop_name, value)


def _load_from_global_settings(context, target_props):
    """Load settings from global storage to a scene's properties."""
    if not context.scene:
        return
    
    global_props = _get_global_settings(context)
    if global_props is None:
        return
    
    # Use the preset flag to prevent update callbacks
    from . import presets
    original_flag = presets._applying_preset
    presets._applying_preset = True
    
    try:
        for prop_name in _SYNC_PROPERTIES:
            if hasattr(global_props, prop_name) and hasattr(target_props, prop_name):
                value = getattr(global_props, prop_name)
                setattr(target_props, prop_name, value)
    finally:
        presets._applying_preset = original_flag


def _sync_global_to_all_scenes(context, *, property_names=None):
    """IMMEDIATELY sync global settings to all scenes that use global mode."""
    global_props = _get_global_settings(context)
    if global_props is None:
        return
    
    from . import presets
    
    for scene in bpy.data.scenes:
        if not hasattr(scene, "rendernames"):
            continue
        
        scene_props = scene.rendernames
        
        # Skip scenes not in global mode
        if not scene_props.use_global_settings:
            continue
        
        # Skip the current scene (already updated)
        if scene == context.scene:
            continue
        
        # Temporarily set the flag
        original_flag = presets._applying_preset
        presets._applying_preset = True
        
        try:
            # Copy all synced properties from global to this scene
            names = tuple(property_names) if property_names is not None else _SYNC_PROPERTIES
            for prop_name in names:
                if prop_name not in _SYNC_PROPERTIES:
                    continue
                if hasattr(global_props, prop_name) and hasattr(scene_props, prop_name):
                    value = getattr(global_props, prop_name)
                    setattr(scene_props, prop_name, value)
        finally:
            presets._applying_preset = original_flag


def get_effective_props(scene):
    """Get the effective properties for a scene."""
    return scene.rendernames


# ============================================================================
# Registration
# ============================================================================

_classes = (
    RENDERNAMES_PresetItem,
    RENDERNAMES_GlobalSettings,
    RENDERNAMES_Properties,
)


def register():
    """Register property classes."""
    from ..rna_safety import ensure_registered_class, register_pointer_property
    for cls in _classes:
        ensure_registered_class(cls)
    
    # Attach global settings to WindowManager - session-persistent
    register_pointer_property(
        bpy.types.WindowManager,
        "rendernames_global",
        RENDERNAMES_GlobalSettings,
    )
    
    # Attach per-scene settings to Scene
    register_pointer_property(
        bpy.types.Scene,
        "rendernames",
        RENDERNAMES_Properties,
    )


def unregister():
    """Unregister property classes."""
    # Remove from WindowManager
    if hasattr(bpy.types.WindowManager, "rendernames_global"):
        del bpy.types.WindowManager.rendernames_global
    
    # Remove from Scene
    if hasattr(bpy.types.Scene, "rendernames"):
        del bpy.types.Scene.rendernames
    
    from ..rna_safety import unregister_existing_class
    for cls in reversed(_classes):
        unregister_existing_class(cls)
