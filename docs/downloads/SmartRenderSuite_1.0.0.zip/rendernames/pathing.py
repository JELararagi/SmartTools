# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import os
from typing import Any

import bpy

from ..compat import abspath, default_output_root


def default_rendernames_base(*, create: bool = True) -> str:
    base = os.path.join(default_output_root(create=create), "rendernames")
    if create:
        os.makedirs(base, exist_ok=True)
    return base


def base_output_dir(scene: bpy.types.Scene, props: Any, *, create: bool = True) -> str:
    try:
        if bool(getattr(props, "use_base_path", False)) and str(getattr(props, "base_path", "") or "").strip():
            return str(getattr(props, "base_path") or "").strip()
    except Exception:
        pass
    return default_rendernames_base(create=create)


def build_output_path(scene: bpy.types.Scene, props: Any, rendered: str, *, create: bool = True) -> str:
    rendered_fragment = str(rendered or "render").lstrip("/\\")
    base = base_output_dir(scene, props, create=create)
    full_path = os.path.normpath(os.path.join(base, rendered_fragment))
    if create:
        try:
            directory = os.path.dirname(abspath(full_path))
            if directory:
                os.makedirs(directory, exist_ok=True)
        except Exception:
            pass
    return full_path


def absolute_output_path(scene: bpy.types.Scene, props: Any, rendered: str, *, create: bool = True) -> str:
    return bpy.path.abspath(build_output_path(scene, props, rendered, create=create))
