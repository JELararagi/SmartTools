# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

# Generated from Smart_Render_Suite_domainless_naming_proposal_JP_EN.docx.
# Top-level tool directory keys and saved manifest/token keys remain backward-compatible;
# command/panel IDs are renamed through ID_RENAME_MAP.

NAMING_ROWS = [
  {
    "category": "Top-level tool",
    "area": "bridges",
    "id": "bridges",
    "old_en": "Bridges",
    "old_ja": "未登録（英名表示）",
    "new_en": "External Pipeline Bridge",
    "new_ja": "外部パイプラインブリッジ"
  },
  {
    "category": "Top-level tool",
    "area": "render_pipeline",
    "id": "smart_render_smart",
    "old_en": "Smart Render Smart",
    "old_ja": "未登録（英名表示）",
    "new_en": "Render Pipeline Manager",
    "new_ja": "レンダーパイプライン管理"
  },
  {
    "category": "Top-level tool",
    "area": "camera_plane",
    "id": "camera_plane",
    "old_en": "Camera Plane",
    "old_ja": "カメラプレーン",
    "new_en": "Camera Image Plane",
    "new_ja": "カメラ画像プレーン"
  },
  {
    "category": "Top-level tool",
    "area": "camera_rigs",
    "id": "camera_rigs",
    "old_en": "Camera Rigs",
    "old_ja": "未登録（英名表示）",
    "new_en": "Camera Rig Builder",
    "new_ja": "カメラリグ作成"
  },
  {
    "category": "Top-level tool",
    "area": "dynamic_sky",
    "id": "dynamic_sky",
    "old_en": "Dynamic Sky",
    "old_ja": "未登録（英名表示）",
    "new_en": "Cycles Sky Generator",
    "new_ja": "Cyclesスカイ生成"
  },
  {
    "category": "Top-level tool",
    "area": "frame_range_renderer",
    "id": "frame_range_renderer",
    "old_en": "Frame Range Renderer",
    "old_ja": "フレーム範囲レンダラー",
    "new_en": "Frame Range Render",
    "new_ja": "フレーム範囲レンダー"
  },
  {
    "category": "Top-level tool",
    "area": "freestyle_svg_exporter",
    "id": "freestyle_svg_exporter",
    "old_en": "Freestyle SVG Exporter",
    "old_ja": "未登録（英名表示）",
    "new_en": "Freestyle SVG Export",
    "new_ja": "Freestyle SVG書き出し"
  },
  {
    "category": "Top-level tool",
    "area": "hdr_rotation",
    "id": "hdr_rotation",
    "old_en": "HDR Rotation",
    "old_ja": "HDR 回転",
    "new_en": "HDRI Rotation",
    "new_ja": "HDRI回転"
  },
  {
    "category": "Top-level tool",
    "area": "k_tools_render_preset_manager",
    "id": "k_tools_render_preset_manager",
    "old_en": "Render Preset Manager",
    "old_ja": "レンダープリセットマネージャー",
    "new_en": "Render Preset Manager",
    "new_ja": "レンダープリセット管理"
  },
  {
    "category": "Top-level tool",
    "area": "overscan",
    "id": "overscan",
    "old_en": "Overscan",
    "old_ja": "オーバースキャン",
    "new_en": "Render Overscan",
    "new_ja": "レンダーオーバースキャン"
  },
  {
    "category": "Top-level tool",
    "area": "pseudo_rendering_farm",
    "id": "pseudo_rendering_farm",
    "old_en": "Pseudo Rendering Farm",
    "old_ja": "疑似レンダリングファーム",
    "new_en": "Local Render Farm",
    "new_ja": "ローカルレンダーファーム"
  },
  {
    "category": "Top-level tool",
    "area": "profiler",
    "id": "profiler",
    "old_en": "Render Profiler",
    "old_ja": "レンダー Profiler",
    "new_en": "Render Profiler",
    "new_ja": "レンダープロファイラー"
  },
  {
    "category": "Top-level tool",
    "area": "rendernames",
    "id": "rendernames",
    "old_en": "Render Names",
    "old_ja": "未登録（英名表示）",
    "new_en": "Render Output Naming",
    "new_ja": "レンダー出力命名"
  },
  {
    "category": "Top-level tool",
    "area": "sun_position",
    "id": "sun_position",
    "old_en": "Sun Position",
    "old_ja": "太陽 Position",
    "new_en": "Sun Position Control",
    "new_ja": "太陽位置制御"
  },
  {
    "category": "Top-level tool",
    "area": "tri_lighting",
    "id": "tri_lighting",
    "old_en": "Tri Lighting",
    "old_ja": "未登録（英名表示）",
    "new_en": "Three-Point Lighting",
    "new_ja": "三点照明"
  },
  {
    "category": "Top-level tool",
    "area": "use_for_rendering_plus",
    "id": "use_for_rendering_plus",
    "old_en": "View Layer Plus",
    "old_ja": "未登録（英名表示）",
    "new_en": "View Layer Manager",
    "new_ja": "ビューレイヤー管理"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Plane",
    "id": "camera.camera_plane_add_opacity",
    "old_en": "Add Opacity to Plane",
    "old_ja": "プレーンに不透明度を追加",
    "new_en": "Add Plane Opacity",
    "new_ja": "プレーンに透明度を追加"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Plane",
    "id": "camera.camera_plane_group",
    "old_en": "Group Selected Planes",
    "old_ja": "選択プレーンをグループ化",
    "new_en": "Group Selected Planes",
    "new_ja": "選択プレーンをグループ化"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Plane",
    "id": "camera.camera_plane_update_groups",
    "old_en": "Update Groups",
    "old_ja": "グループを更新",
    "new_en": "Update Plane Groups",
    "new_ja": "プレーングループを更新"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Plane",
    "id": "camera.camera_plane_ungroup",
    "old_en": "Ungroup",
    "old_ja": "グループ解除",
    "new_en": "Ungroup Planes",
    "new_ja": "プレーンのグループを解除"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Plane",
    "id": "camera.camera_plane_build",
    "old_en": "Import Camera Plane",
    "old_ja": "カメラプレーンを読み込み",
    "new_en": "Import Camera Plane",
    "new_ja": "カメラプレーンを読み込み"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Plane",
    "id": "camera.camera_plane_setup_layers",
    "old_en": "Setup Layers",
    "old_ja": "レイヤーを設定",
    "new_en": "Set Up Plane Layers",
    "new_ja": "プレーンレイヤーを設定"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Plane",
    "id": "camera.camera_plane_space",
    "old_en": "Space Evenly",
    "old_ja": "等間隔に配置",
    "new_en": "Space Planes Evenly",
    "new_ja": "プレーンを等間隔に配置"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Plane",
    "id": "camera.camera_plane_reverse",
    "old_en": "Reverse",
    "old_ja": "反転",
    "new_en": "Reverse Order",
    "new_ja": "順序を反転"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Plane",
    "id": "camera.camera_plane_apply",
    "old_en": "Apply Camera Plane",
    "old_ja": "カメラプレーンを適用",
    "new_en": "Apply Camera Plane",
    "new_ja": "カメラプレーンを適用"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Plane",
    "id": "camera.camera_plane_run_load_maintenance",
    "old_en": "Run Camera Plane Maintenance",
    "old_ja": "カメラプレーンのメンテナンスを実行",
    "new_en": "Run Maintenance",
    "new_ja": "メンテナンスを実行"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Plane",
    "id": "object.camera_mapping",
    "old_en": "Convert to Camera Mapping",
    "old_ja": "カメラマッピングへ変換",
    "new_en": "Convert to Camera Mapping",
    "new_ja": "カメラマッピングへ変換"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Plane",
    "id": "",
    "old_en": "Camera Plane Options",
    "old_ja": "カメラプレーンオプション",
    "new_en": "Options",
    "new_ja": "オプション"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Plane",
    "id": "",
    "old_en": "Camera Plane",
    "old_ja": "カメラプレーン",
    "new_en": "Camera Plane",
    "new_ja": "カメラプレーン"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Rig",
    "id": "object.build_camera_rig",
    "old_en": "Build Camera Rig",
    "old_ja": "カメラリグを作成",
    "new_en": "Build Camera Rig",
    "new_ja": "カメラリグを作成"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Rig",
    "id": "",
    "old_en": "Composition Guides",
    "old_ja": "構図ガイド",
    "new_en": "Composition Guides",
    "new_ja": "構図ガイド"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Rig",
    "id": "add_camera_rigs.set_scene_camera",
    "old_en": "Make Camera Active",
    "old_ja": "カメラをアクティブにする",
    "new_en": "Make Camera Active",
    "new_ja": "カメラをアクティブ化"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Rig",
    "id": "add_camera_rigs.add_marker_bind",
    "old_en": "Add Marker and Bind Camera",
    "old_ja": "マーカーを追加してカメラをバインド",
    "new_en": "Add Marker and Bind Camera",
    "new_ja": "マーカー追加とカメラ割り当て"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Rig",
    "id": "add_camera_rigs.set_dof_bone",
    "old_en": "Set DOF to Aim",
    "old_ja": "DOF を Aim に設定",
    "new_en": "Set DOF to Aim Control",
    "new_ja": "DOFをAimに設定"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Rig",
    "id": "add_camera_rigs.set_dolly_zoom",
    "old_en": "Set Dolly Zoom",
    "old_ja": "ドリーズームを設定",
    "new_en": "Set Dolly Zoom",
    "new_ja": "ドリーズームを設定"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Rig",
    "id": "add_camera_rigs.remove_dolly_zoom",
    "old_en": "Remove Dolly Zoom",
    "old_ja": "ドリーズームを削除",
    "new_en": "Remove Dolly Zoom",
    "new_ja": "ドリーズームを解除"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Rig",
    "id": "add_camera_rigs.shift_to_pivot",
    "old_en": "Shift To Pivot",
    "old_ja": "ピボットへシフト",
    "new_en": "Shift to Pivot",
    "new_ja": "ピボットへ移動"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Rig",
    "id": "add_camera_rigs.swap_lens",
    "old_en": "Swap Lens",
    "old_ja": "レンズを切り替え",
    "new_en": "Swap Lens",
    "new_ja": "レンズを切り替え"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Rig",
    "id": "",
    "old_en": "Camera Rig Lens Specials",
    "old_ja": "カメラリグ レンズ特殊設定",
    "new_en": "Lens Tools",
    "new_ja": "レンズツール"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Rig",
    "id": "",
    "old_en": "Camera Rig",
    "old_ja": "カメラリグ",
    "new_en": "Camera Rig",
    "new_ja": "カメラリグ"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Rig",
    "id": "",
    "old_en": "Depth of Field",
    "old_ja": "被写界深度",
    "new_en": "Depth of Field",
    "new_ja": "被写界深度"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Rig",
    "id": "",
    "old_en": "Viewport Display",
    "old_ja": "ビューポート表示",
    "new_en": "Viewport Display",
    "new_ja": "ビューポート表示"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Camera Rig",
    "id": "",
    "old_en": "Rig Properties",
    "old_ja": "リグプロパティ",
    "new_en": "Rig Properties",
    "new_ja": "リグプロパティ"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Suite",
    "id": "PACKAGE_ID + '.open_help'",
    "old_en": "Open Help",
    "old_ja": "未登録",
    "new_en": "Open Help",
    "new_ja": "ヘルプを開く"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Suite",
    "id": "PACKAGE_ID + '.set_always_on'",
    "old_en": "Always-on Toggle",
    "old_ja": "未登録",
    "new_en": "Toggle Startup Control",
    "new_ja": "常時起動を切り替え"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Suite",
    "id": "PACKAGE_ID + '.save_preferences'",
    "old_en": "Save Preferences",
    "old_ja": "未登録",
    "new_en": "Save Settings",
    "new_ja": "設定を保存"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Startup Controls",
    "id": "srr.toggle_known_persistent_control",
    "old_en": "Toggle Always-on Control",
    "old_ja": "常時起動項目を切り替え",
    "new_en": "Toggle Startup Control",
    "new_ja": "常時起動を切り替え"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Sky",
    "id": "sky.dyn",
    "old_en": "Make a Procedural sky",
    "old_ja": "プロシージャルスカイを作成",
    "new_en": "Create Procedural Sky",
    "new_ja": "プロシージャルスカイを作成"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Sky",
    "id": "DYNSKY_PT_tools",
    "old_en": "Dynamic sky",
    "old_ja": "ダイナミックスカイ",
    "new_en": "Dynamic Sky",
    "new_ja": "ダイナミックスカイ"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Startup Controls",
    "id": "operator_id",
    "old_en": "Toggle Feature",
    "old_ja": "機能を切り替え",
    "new_en": "Toggle Feature",
    "new_ja": "機能を切り替え"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Frame Range",
    "id": "render.clear_frame_input",
    "old_en": "Clear",
    "old_ja": "クリア",
    "new_en": "Clear Frame List",
    "new_ja": "フレーム指定をクリア"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Frame Range",
    "id": "render.render_frame_ranges",
    "old_en": "Render Frame Ranges",
    "old_ja": "フレーム範囲をレンダー",
    "new_en": "Render Frame Ranges",
    "new_ja": "フレーム範囲をレンダー"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Frame Range",
    "id": "render.cancel_frame_ranges",
    "old_en": "Cancel Render",
    "old_ja": "レンダーをキャンセル",
    "new_en": "Cancel Frame Render",
    "new_ja": "フレームレンダーを中止"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Frame Range",
    "id": "RENDER_PT_frame_range_renderer",
    "old_en": "Frame Range Renderer",
    "old_ja": "フレーム範囲レンダラー",
    "new_en": "Frame Range Renderer",
    "new_ja": "フレーム範囲レンダー"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Line SVG",
    "id": "RENDER_PT_SVGExporterLinesetPanel",
    "old_en": "Freestyle Line Style SVG Export",
    "old_ja": "Freestyle ラインスタイル SVG 書き出し",
    "new_en": "Line Style SVG Export",
    "new_ja": "ラインスタイルSVG書き出し"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Line SVG",
    "id": "RENDER_PT_SVGExporterPanel",
    "old_en": "Freestyle SVG Export",
    "old_ja": "Freestyle SVG 書き出し",
    "new_en": "Freestyle SVG Export",
    "new_ja": "Freestyle SVG書き出し"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "HDRI",
    "id": "hdr.rotation",
    "old_en": "HDR Rotation",
    "old_ja": "HDR 回転",
    "new_en": "Rotate HDRI",
    "new_ja": "HDRIを回転"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Suite Help",
    "id": "smart_render_suite.help_popup",
    "old_en": "Help",
    "old_ja": "ヘルプ",
    "new_en": "Help",
    "new_ja": "ヘルプ"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.sync_blacklist",
    "old_en": "Sync Property List",
    "old_ja": "プロパティ一覧を同期",
    "new_en": "Sync Property List",
    "new_ja": "プロパティリストを同期"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.remove_user_preset",
    "old_en": "Confirm Preset Deletion",
    "old_ja": "プリセット削除の確認",
    "new_en": "Confirm Preset Deletion",
    "new_ja": "プリセット削除を確認"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.validate_list",
    "old_en": "Run Full Property Audit",
    "old_ja": "完全プロパティ監査を実行",
    "new_en": "Run Property Audit",
    "new_ja": "プロパティ監査を実行"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.generate_new_list",
    "old_en": "Generate New List from Scraper",
    "old_ja": "スクレイパーから新規リストを生成",
    "new_en": "Generate Property List",
    "new_ja": "プロパティリストを生成"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.validation_report_popup",
    "old_en": "Validation Report",
    "old_ja": "検証レポート",
    "new_en": "Validation Report",
    "new_ja": "検証レポート"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.fuzz_test_scene",
    "old_en": "Fuzz Test Scene (Monkey Test)",
    "old_ja": "ファズテストシーン（モンキーテスト）",
    "new_en": "Run Fuzz Test",
    "new_ja": "ファズテストを実行"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.load_from_filepath",
    "old_en": "Load Preset from Filepath",
    "old_ja": "ファイルパスからプリセットを読み込み",
    "new_en": "Load Preset from Path",
    "new_ja": "パスからプリセットを読み込み"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "RENDER_PRESET_FH_drop_handler",
    "old_en": "Render Preset File Handler",
    "old_ja": "レンダープリセットファイルハンドラー",
    "new_en": "Preset File Handler",
    "new_ja": "プリセットファイルハンドラー"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.load",
    "old_en": "Load Render Preset",
    "old_ja": "レンダープリセットを読み込み",
    "new_en": "Load Render Preset",
    "new_ja": "レンダープリセットを読み込み"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.load_preview",
    "old_en": "Load Render Preset",
    "old_ja": "レンダープリセットを読み込み",
    "new_en": "Load Render Preset",
    "new_ja": "レンダープリセットを読み込み"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.load_confirm",
    "old_en": "Confirm Load",
    "old_ja": "読み込み確認",
    "new_en": "Confirm Load",
    "new_ja": "読み込みを確認"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.load_from_path",
    "old_en": "Load Preset From Path (Direct)",
    "old_ja": "パスからプリセットを直接読み込み",
    "new_en": "Load Preset Directly",
    "new_ja": "プリセットを直接読み込み"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.load_from_list",
    "old_en": "Load Selected Preset",
    "old_ja": "選択プリセットを読み込み",
    "new_en": "Load Selected Preset",
    "new_ja": "選択プリセットを読み込み"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.save",
    "old_en": "Save Preset to File...",
    "old_ja": "プリセットをファイルに保存...",
    "new_en": "Save Preset to File",
    "new_ja": "プリセットをファイルへ保存"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.save_to_user_repo",
    "old_en": "Save to User Repository",
    "old_ja": "ユーザーリポジトリに保存",
    "new_en": "Save to User Presets",
    "new_ja": "ユーザープリセットへ保存"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.save_overwrite_confirm",
    "old_en": "Confirm Overwrite",
    "old_ja": "上書き確認",
    "new_en": "Confirm Overwrite",
    "new_ja": "上書きを確認"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.undo",
    "old_en": "Undo Preset Load",
    "old_ja": "プリセット読み込みを取り消し",
    "new_en": "Undo Preset Load",
    "new_ja": "プリセット読み込みを取り消し"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.refresh_defaults",
    "old_en": "Refresh Default Presets",
    "old_ja": "デフォルトプリセットを更新",
    "new_en": "Refresh Default Presets",
    "new_ja": "既定プリセットを更新"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.load_default",
    "old_en": "Load Selected Default",
    "old_ja": "選択デフォルトを読み込み",
    "new_en": "Load Selected Default Preset",
    "new_ja": "選択した既定プリセットを読み込み"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.refresh_user",
    "old_en": "Update User Presets",
    "old_ja": "ユーザープリセットを更新",
    "new_en": "Refresh User Presets",
    "new_ja": "ユーザープリセットを更新"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.load_user",
    "old_en": "Load User Preset",
    "old_ja": "ユーザープリセットを読み込み",
    "new_en": "Load User Preset",
    "new_ja": "ユーザープリセットを読み込み"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "render_preset.update_preset_api_list",
    "old_en": "Update Preset API List",
    "old_ja": "プリセット API リストを更新",
    "new_en": "Update Preset API List",
    "new_ja": "プリセットAPIリストを更新"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "RENDER_PRESET_PT_panel_normal",
    "old_en": "Render Preset Manager",
    "old_ja": "レンダープリセットマネージャー",
    "new_en": "Render Presets",
    "new_ja": "レンダープリセット"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Presets",
    "id": "RENDER_PRESET_PT_panel_no_header",
    "old_en": "Render Preset Manager",
    "old_ja": "レンダープリセットマネージャー",
    "new_en": "Render Presets",
    "new_ja": "レンダープリセット"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.toggle_properties_tab",
    "old_en": "未登録",
    "old_ja": "Smart Render Nパネル更新",
    "new_en": "Refresh N-Panel",
    "new_ja": "Nパネルを更新"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.apply_render_elements_quick_set",
    "old_en": "Apply Render Elements Quick Set",
    "old_ja": "レンダーエレメント一括反映",
    "new_en": "Apply AOV Quick Set",
    "new_ja": "AOVクイックセットを適用"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.apply_profile",
    "old_en": "Apply Profile",
    "old_ja": "プロファイル適用",
    "new_en": "Apply Render Profile",
    "new_ja": "レンダープロファイルを適用"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.prepare_setup",
    "old_en": "Prepare Setup",
    "old_ja": "基本設定を整える",
    "new_en": "Prepare Scene Setup",
    "new_ja": "シーン基本設定を準備"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.apply_pass_bundle",
    "old_en": "Apply Pass Bundle",
    "old_ja": "パス適用",
    "new_en": "Apply Pass Bundle",
    "new_ja": "パスバンドルを適用"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.workflow_recipe_dialog",
    "old_en": "Workflow Recipes",
    "old_ja": "ワークフローレシピ",
    "new_en": "Workflow Recipes",
    "new_ja": "ワークフローレシピ"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.apply_workflow_recipe",
    "old_en": "Apply Workflow Recipe",
    "old_ja": "ワークフローレシピ適用",
    "new_en": "Apply Workflow Recipe",
    "new_ja": "ワークフローレシピを適用"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.auto_repair_scene",
    "old_en": "Auto Repair",
    "old_ja": "自動整理",
    "new_en": "Auto Repair Scene",
    "new_ja": "シーンを自動整理"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.analyze_scene",
    "old_en": "Analyze Scene",
    "old_ja": "シーン診断",
    "new_en": "Analyze Scene",
    "new_ja": "シーンを診断"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.sync_queue",
    "old_en": "Sync Queue",
    "old_ja": "キュー同期",
    "new_en": "Sync Render Queue",
    "new_ja": "レンダーキューを同期"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.clear_queue",
    "old_en": "Clear Queue",
    "old_ja": "キュー削除",
    "new_en": "Clear Render Queue",
    "new_ja": "レンダーキューを削除"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.add_queue_item",
    "old_en": "Add Queue Item",
    "old_ja": "キュー項目追加",
    "new_en": "Add Queue Item",
    "new_ja": "キュー項目を追加"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.duplicate_queue_item",
    "old_en": "Duplicate Queue Item",
    "old_ja": "キュー項目複製",
    "new_en": "Duplicate Queue Item",
    "new_ja": "キュー項目を複製"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.remove_queue_item",
    "old_en": "Remove Queue Item",
    "old_ja": "キュー項目削除",
    "new_en": "Remove Queue Item",
    "new_ja": "キュー項目を削除"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.move_queue_item",
    "old_en": "Move Queue Item",
    "old_ja": "キュー並び替え",
    "new_en": "Move Queue Item",
    "new_ja": "キュー項目を移動"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.clear_logs",
    "old_en": "Clear Logs",
    "old_ja": "ログ削除",
    "new_en": "Clear Logs",
    "new_ja": "ログを削除"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.preview_outputs",
    "old_en": "Preview Paths",
    "old_ja": "出力プレビュー",
    "new_en": "Preview Output Paths",
    "new_ja": "出力パスを確認"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.setup_render_elements",
    "old_en": "Setup Render Elements",
    "old_ja": "レンダーエレメント準備",
    "new_en": "Prepare Render Elements",
    "new_ja": "レンダーエレメントを準備"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.prepare_network_render",
    "old_en": "Prepare Network Render",
    "old_ja": "ネットワークレンダー準備",
    "new_en": "Prepare Network Render",
    "new_ja": "ネットワークレンダーを準備"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.export_manifest",
    "old_en": "Export Manifest",
    "old_ja": "マニフェスト書き出し",
    "new_en": "Export Manifest",
    "new_ja": "マニフェストを書き出し"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.import_manifest",
    "old_en": "Import Manifest",
    "old_ja": "マニフェスト読み込み",
    "new_en": "Import Manifest",
    "new_ja": "マニフェストを読み込み"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.export_bridge_manifest",
    "old_en": "Export Bridge JSON",
    "old_ja": "ブリッジJSON書き出し",
    "new_en": "Export Bridge Manifest",
    "new_ja": "ブリッジマニフェストを書き出し"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.export_headless_scripts",
    "old_en": "Export Headless Scripts",
    "old_ja": "ヘッドレス実行スクリプト書き出し",
    "new_en": "Export Headless Scripts",
    "new_ja": "ヘッドレススクリプトを書き出し"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.add_variant_from_current",
    "old_en": "Add Variant From Current",
    "old_ja": "現在状態から追加",
    "new_en": "Add Variant From Current State",
    "new_ja": "現在状態からバリアントを追加"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.add_child_variant",
    "old_en": "Add Child Variant",
    "old_ja": "子バリアント追加",
    "new_en": "Add Child Variant",
    "new_ja": "子バリアントを追加"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.duplicate_variant",
    "old_en": "Duplicate Variant",
    "old_ja": "バリアント複製",
    "new_en": "Duplicate Variant",
    "new_ja": "バリアントを複製"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.remove_variant",
    "old_en": "Remove Variant",
    "old_ja": "バリアント削除",
    "new_en": "Remove Variant",
    "new_ja": "バリアントを削除"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.capture_variant_overrides",
    "old_en": "Capture Overrides",
    "old_ja": "現在状態を取り込み",
    "new_en": "Capture Overrides",
    "new_ja": "オーバーライドを取り込み"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.apply_variant",
    "old_en": "Apply Variant",
    "old_ja": "バリアント適用",
    "new_en": "Apply Variant",
    "new_ja": "バリアントを適用"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.build_compositor_outputs",
    "old_en": "Build File Output Nodes",
    "old_ja": "File Outputノード構築",
    "new_en": "Build File Output Nodes",
    "new_ja": "File Outputノードを構築"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "srr.render_queue",
    "old_en": "Render Queue",
    "old_ja": "キュー実行",
    "new_en": "Run Render Queue",
    "new_ja": "レンダーキューを実行"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Overscan",
    "id": "RENDER_PT_overscan",
    "old_en": "Overscan",
    "old_ja": "オーバースキャン",
    "new_en": "Overscan",
    "new_ja": "オーバースキャン"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Overscan",
    "id": "render.revert_overscan",
    "old_en": "Revert",
    "old_ja": "元に戻す",
    "new_en": "Revert Overscan",
    "new_ja": "オーバースキャンを戻す"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Profiler",
    "id": "profiler.open_report",
    "old_en": "Open Render Profiler Report in Browser",
    "old_ja": "Render Profiler レポートをブラウザーで開く",
    "new_en": "Open Report in Browser",
    "new_ja": "レポートをブラウザーで開く"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Profiler",
    "id": "profiler.stop_profiling",
    "old_en": "Stop Profiling",
    "old_ja": "プロファイルを停止",
    "new_en": "Stop Profiling",
    "new_ja": "計測を停止"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Local Farm",
    "id": "render.pseudo_rendering_farm",
    "old_en": "Launch Pseudo Rendering Farm",
    "old_ja": "疑似レンダリングファームを起動",
    "new_en": "Launch Local Render Farm",
    "new_ja": "ローカルレンダーファームを起動"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Local Farm",
    "id": "render.cancel_pseudo_rendering_farm",
    "old_en": "Cancel All Renders",
    "old_ja": "すべてのレンダーをキャンセル",
    "new_en": "Cancel All Renders",
    "new_ja": "すべてのレンダーを中止"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Local Farm",
    "id": "render.benchmarking",
    "old_en": "Launch benchmark",
    "old_ja": "ベンチマークを起動",
    "new_en": "Run Benchmark",
    "new_ja": "ベンチマークを実行"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Local Farm",
    "id": "RENDER_PT_pseudo_rendering_farm",
    "old_en": "Pseudo Rendering Farm",
    "old_ja": "疑似レンダリングファーム",
    "new_en": "Local Render Farm",
    "new_ja": "ローカルレンダーファーム"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "rendernames.insert_variable",
    "old_en": "Insert Variable",
    "old_ja": "変数を挿入",
    "new_en": "Insert Token",
    "new_ja": "トークンを挿入"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "rendernames.copy_variable",
    "old_en": "Copy Variable",
    "old_ja": "変数をコピー",
    "new_en": "Copy Token",
    "new_ja": "トークンをコピー"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "RENDERNAMES_MT_variable_menu",
    "old_en": "Variables",
    "old_ja": "変数",
    "new_en": "Tokens",
    "new_ja": "トークン"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "rendernames.reset_template",
    "old_en": "Reset Template",
    "old_ja": "テンプレートをリセット",
    "new_en": "Reset Naming Template",
    "new_ja": "命名テンプレートをリセット"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "rendernames.clear_template",
    "old_en": "Clear Template",
    "old_ja": "テンプレートをクリア",
    "new_en": "Clear Naming Template",
    "new_ja": "命名テンプレートをクリア"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "rendernames.copy_preview",
    "old_en": "Copy Preview Path",
    "old_ja": "プレビューパスをコピー",
    "new_en": "Copy Preview Path",
    "new_ja": "プレビューパスをコピー"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "rendernames.apply_to_render",
    "old_en": "Apply to Render Settings",
    "old_ja": "レンダー設定へ適用",
    "new_en": "Apply to Render Settings",
    "new_ja": "レンダー設定へ適用"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "rendernames.save_preset",
    "old_en": "Save Preset",
    "old_ja": "プリセットを保存",
    "new_en": "Save Preset",
    "new_ja": "プリセットを保存"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "rendernames.load_preset",
    "old_en": "Load Preset",
    "old_ja": "プリセットを読み込み",
    "new_en": "Load Preset",
    "new_ja": "プリセットを読み込み"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "rendernames.delete_preset",
    "old_en": "Delete Preset",
    "old_ja": "プリセットを削除",
    "new_en": "Delete Preset",
    "new_ja": "プリセットを削除"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "rendernames.refresh_presets",
    "old_en": "Refresh Presets",
    "old_ja": "プリセットを更新",
    "new_en": "Refresh Presets",
    "new_ja": "プリセットを更新"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "rendernames.import_preset",
    "old_en": "Import Preset",
    "old_ja": "プリセットを読み込み",
    "new_en": "Import Preset",
    "new_ja": "プリセットをインポート"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "rendernames.export_preset",
    "old_en": "Export Preset",
    "old_ja": "プリセットを書き出し",
    "new_en": "Export Preset",
    "new_ja": "プリセットをエクスポート"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "RENDERNAMES_MT_presets",
    "old_en": "Presets",
    "old_ja": "プリセット",
    "new_en": "Presets",
    "new_ja": "プリセット"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "RENDERNAMES_PT_main",
    "old_en": "RenderNames",
    "old_ja": "レンダー 名前",
    "new_en": "Render Naming",
    "new_ja": "レンダーネーミング"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "RENDERNAMES_PT_options",
    "old_en": "Options",
    "old_ja": "オプション",
    "new_en": "Options",
    "new_ja": "オプション"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "RENDERNAMES_PT_presets",
    "old_en": "Presets",
    "old_ja": "プリセット",
    "new_en": "Presets",
    "new_ja": "プリセット"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "RENDERNAMES_PT_variables",
    "old_en": "Variables Reference",
    "old_ja": "変数リファレンス",
    "new_en": "Token Reference",
    "new_ja": "トークンリファレンス"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Naming",
    "id": "RENDERNAMES_PT_render_output_notice",
    "old_en": "未登録",
    "old_ja": "未登録",
    "new_en": "Naming:",
    "new_ja": "名称未設定"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "smart_render_smart.analyze",
    "old_en": "Analyze",
    "old_ja": "診断",
    "new_en": "Analyze",
    "new_ja": "診断"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "smart_render_smart.apply_preset",
    "old_en": "Apply Preset",
    "old_ja": "プリセット反映",
    "new_en": "Apply Pipeline Preset",
    "new_ja": "パイプラインプリセットを適用"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "smart_render_smart.build_queue",
    "old_en": "Build Queue",
    "old_ja": "キュー生成",
    "new_en": "Build Render Queue",
    "new_ja": "レンダーキューを生成"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "smart_render_smart.create_standard_layers",
    "old_en": "Create Standard Layers",
    "old_ja": "標準レイヤー作成",
    "new_en": "Create Standard View Layers",
    "new_ja": "標準ビューレイヤーを作成"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "smart_render_smart.export_manifest",
    "old_en": "Export Manifest",
    "old_ja": "マニフェスト書き出し",
    "new_en": "Export Manifest",
    "new_ja": "マニフェストを書き出し"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "smart_render_smart.export_headless_script",
    "old_en": "Export Headless Script",
    "old_ja": "Headlessスクリプト生成",
    "new_en": "Export Headless Script",
    "new_ja": "ヘッドレススクリプトを書き出し"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "smart_render_smart.optimize_precision",
    "old_en": "Optimize Precision",
    "old_ja": "精度最適化",
    "new_en": "Optimize Precision and Safety",
    "new_ja": "精度と安全性を最適化"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "smart_render_smart.export_submission_pack",
    "old_en": "Export Submission Pack",
    "old_ja": "提出パック書き出し",
    "new_en": "Export Submission Pack",
    "new_ja": "提出パックを書き出し"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "smart_render_smart.autopilot",
    "old_en": "Production Autopilot",
    "old_ja": "本番オートパイロット",
    "new_en": "Run Production Autopilot",
    "new_ja": "本番オートパイロットを実行"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "smart_render_smart.open_diagnostics_text",
    "old_en": "Open Diagnostics Text",
    "old_ja": "診断テキストを開く",
    "new_en": "Open Diagnostics Text",
    "new_ja": "診断テキストを開く"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "smart_render_smart.copy_diagnostics",
    "old_en": "Copy Diagnostics",
    "old_ja": "診断をコピー",
    "new_en": "Copy Diagnostics",
    "new_ja": "診断をコピー"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "smart_render_smart.load_support_tools",
    "old_en": "Load Support Tools",
    "old_ja": "関連ツールを読み込む",
    "new_en": "Load Support Tools",
    "new_ja": "関連ツールを読み込む"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "smart_render_smart.copy_last_path",
    "old_en": "Copy Path",
    "old_ja": "パスをコピー",
    "new_en": "Copy Output Path",
    "new_ja": "出力パスをコピー"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "smart_render_smart.open_output_dir",
    "old_en": "Open Output Folder",
    "old_ja": "出力フォルダーを開く",
    "new_en": "Open Output Folder",
    "new_ja": "出力フォルダーを開く"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "SMART_RENDER_SMART_PT_main",
    "old_en": "Smart Render Smart",
    "old_ja": "Smart Render Smart",
    "new_en": "Render Pipeline",
    "new_ja": "レンダーパイプライン"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "SMART_RENDER_SMART_PT_precision",
    "old_en": "Precision and Safety",
    "old_ja": "精度と安全性",
    "new_en": "Precision and Safety",
    "new_ja": "精度と安全性"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "SMART_RENDER_SMART_PT_state",
    "old_en": "State Management",
    "old_ja": "ステート管理",
    "new_en": "State Management",
    "new_ja": "ステート管理"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "SMART_RENDER_SMART_PT_batch",
    "old_en": "Queue and Naming",
    "old_ja": "キューと命名",
    "new_en": "Queue and Naming",
    "new_ja": "キューと命名"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "SMART_RENDER_SMART_PT_aov",
    "old_en": "AOV and Quality",
    "old_ja": "AOVと品質",
    "new_en": "AOV and Quality",
    "new_ja": "AOVと品質"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "SMART_RENDER_SMART_PT_bridge",
    "old_en": "Bridge and Farm",
    "old_ja": "ブリッジとファーム",
    "new_en": "Bridge and Farm",
    "new_ja": "ブリッジとファーム"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "SMART_RENDER_SMART_PT_validation",
    "old_en": "Validation",
    "old_ja": "検証",
    "new_en": "Validation",
    "new_ja": "検証"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "SMART_RENDER_SMART_PT_output",
    "old_en": "Output",
    "old_ja": "出力",
    "new_en": "Output",
    "new_ja": "出力"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "SMART_RENDER_SMART_PT_visual_reference",
    "old_en": "UI Reference",
    "old_ja": "UIリファレンス",
    "new_en": "UI Reference",
    "new_ja": "UIリファレンス"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Sun Position",
    "id": "world.sunpos_show_env",
    "old_en": "Pick Sun in Viewport",
    "old_ja": "Pick 太陽 in ビューポート",
    "new_en": "Pick Sun in Viewport",
    "new_ja": "ビューポートで太陽を選択"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Sun Position",
    "id": "world.sunpos_create_analemmas_object",
    "old_en": "Create Sun Analemmas Object",
    "old_ja": "Create 太陽 Analemmas オブジェクト",
    "new_en": "Create Analemma Object",
    "new_ja": "アナレンマオブジェクトを作成"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Sun Position",
    "id": "world.sunpos_create_surface_object",
    "old_en": "Create Sun Surface Object",
    "old_ja": "Create 太陽 Surface オブジェクト",
    "new_en": "Create Sun Path Surface",
    "new_ja": "太陽軌道面を作成"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Sun Position",
    "id": "",
    "old_en": "Sun Position Presets",
    "old_ja": "太陽 Position プリセット",
    "new_en": "Sun Position Presets",
    "new_ja": "太陽位置プリセット"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Sun Position",
    "id": "world.sunpos_add_preset",
    "old_en": "Add Sun Position preset",
    "old_ja": "太陽 Position presetを追加します。",
    "new_en": "Add Sun Position Preset",
    "new_ja": "太陽位置プリセットを追加"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Sun Position",
    "id": "",
    "old_en": "Sun Position",
    "old_ja": "太陽 Position",
    "new_en": "Sun Position",
    "new_ja": "太陽位置"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Sun Position",
    "id": "",
    "old_en": "Location",
    "old_ja": "場所",
    "new_en": "Location",
    "new_ja": "場所"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Sun Position",
    "id": "",
    "old_en": "Time",
    "old_ja": "時刻",
    "new_en": "Time",
    "new_ja": "時刻"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Lighting",
    "id": "object.trilighting",
    "old_en": "3-Point Lighting",
    "old_ja": "3点ライティング",
    "new_en": "Create Three-Point Lighting",
    "new_ja": "三点照明を作成"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "SRR_PT_properties_nav",
    "old_en": "Smart Render",
    "old_ja": "Smart Render",
    "new_en": "Smart Render",
    "new_ja": "Smart Render"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "SRR_PT_main",
    "old_en": "Smart Render",
    "old_ja": "Smart Render",
    "new_en": "Smart Render",
    "new_ja": "Smart Render"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "",
    "old_en": "Dashboard",
    "old_ja": "ダッシュボード",
    "new_en": "Dashboard",
    "new_ja": "ダッシュボード"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "",
    "old_en": "Profile",
    "old_ja": "プロファイル",
    "new_en": "Render Profile",
    "new_ja": "レンダープロファイル"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "",
    "old_en": "Render Elements",
    "old_ja": "レンダーエレメント",
    "new_en": "Render Elements",
    "new_ja": "レンダーエレメント"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "",
    "old_en": "Network Render",
    "old_ja": "ネットワークレンダー",
    "new_en": "Network Render",
    "new_ja": "ネットワークレンダー"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "",
    "old_en": "Workflow Recipes",
    "old_ja": "ワークフローレシピ",
    "new_en": "Workflow Recipes",
    "new_ja": "ワークフローレシピ"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "",
    "old_en": "Execution",
    "old_ja": "実行計画",
    "new_en": "Execution Plan",
    "new_ja": "実行計画"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "",
    "old_en": "Variants / Takes",
    "old_ja": "バリアント",
    "new_en": "Variants and Takes",
    "new_ja": "バリアントとテイク"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "",
    "old_en": "Output",
    "old_ja": "出力",
    "new_en": "Output",
    "new_ja": "出力"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "",
    "old_en": "Batch Queue",
    "old_ja": "バッチキュー",
    "new_en": "Render Queue",
    "new_ja": "レンダーキュー"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "",
    "old_en": "Extra Tools",
    "old_ja": "追加ツール",
    "new_en": "Integrated Tools",
    "new_ja": "統合ツール"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "",
    "old_en": "Bridge",
    "old_ja": "ブリッジ",
    "new_en": "Bridge",
    "new_ja": "ブリッジ"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Pipeline",
    "id": "",
    "old_en": "Logs",
    "old_ja": "ログ",
    "new_en": "Logs",
    "new_ja": "ログ"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Tool Loader",
    "id": "smart_render_suite.load_integrated_tool",
    "old_en": "Load Smart Render Tool",
    "old_ja": "Smart Render ツールを読み込む",
    "new_en": "Load Integrated Tool",
    "new_ja": "統合ツールを読み込む"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Tool Loader",
    "id": "smart_render_suite.integrated_addon_info",
    "old_en": "Integrated Add-on Info",
    "old_ja": "統合アドオン情報",
    "new_en": "Show Integrated Tool Info",
    "new_ja": "統合ツール情報を表示"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "Tool Loader",
    "id": "smart_render_suite.integrated_invoke",
    "old_en": "Smart Render Tool",
    "old_ja": "Smart Render ツール",
    "new_en": "Integrated Tool",
    "new_ja": "統合ツール"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.toggle",
    "old_en": "Use for rendering selected",
    "old_ja": "for rendering selectedを使用します。",
    "new_en": "Toggle Selected for Rendering",
    "new_ja": "選択項目のレンダー使用を切り替え"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.batch",
    "old_en": "Use for rendering batch",
    "old_ja": "for rendering batchを使用します。",
    "new_en": "Batch Toggle Rendering",
    "new_ja": "レンダー使用を一括切り替え"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.only_active",
    "old_en": "Enable unmuted only",
    "old_ja": "unmuted onlyを有効にします。",
    "new_en": "Enable Only Unmuted Nodes",
    "new_ja": "ミュートされていないノードのみ有効"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.only_selected",
    "old_en": "Enable selected only",
    "old_ja": "selected onlyを有効にします。",
    "new_en": "Enable Only Selected",
    "new_ja": "選択項目のみ有効"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.switch_render_layer",
    "old_en": "Switch to active Render Layer Node",
    "old_ja": "アクティブな Render Layer ノードへ切り替え",
    "new_en": "Switch to Active Render Layer Node",
    "new_ja": "アクティブなRender Layerノードへ切替"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.view_layer_add",
    "old_en": "Add View Layer",
    "old_ja": "ビューレイヤーを追加します。",
    "new_en": "Add View Layer",
    "new_ja": "ビューレイヤーを追加"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.view_layer_remove",
    "old_en": "Remove View Layer",
    "old_ja": "ビューレイヤーを削除します。",
    "new_en": "Remove View Layer",
    "new_ja": "ビューレイヤーを削除"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.switch_view_layer",
    "old_en": "Switch to View Layer",
    "old_ja": "Switch to ビューレイヤー",
    "new_en": "Switch View Layer",
    "new_ja": "ビューレイヤーを切替"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.all_passes",
    "old_en": "Check/Uncheck all",
    "old_ja": "すべてチェック/解除",
    "new_en": "Toggle All Copy Passes",
    "new_ja": "コピーパスを一括切り替え"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.reload_passes",
    "old_en": "Reload passes to copy",
    "old_ja": "コピー対象パスを再読み込み",
    "new_en": "Reload Copy Passes",
    "new_ja": "コピーパスを再読み込み"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.copy_layer_props",
    "old_en": "Copy properties and render settings",
    "old_ja": "プロパティとレンダー設定をコピー",
    "new_en": "Copy Layer Settings",
    "new_ja": "レイヤー設定をコピー"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.paste_layer_props",
    "old_en": "Paste properties and render settings",
    "old_ja": "プロパティとレンダー設定を貼り付け",
    "new_en": "Paste Layer Settings",
    "new_ja": "レイヤー設定を貼り付け"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.copy_to_selected",
    "old_en": "Copy Collection's settings to...",
    "old_ja": "コレクション's settings to...をコピーします。",
    "new_en": "Copy Collection Settings",
    "new_ja": "コレクション設定をコピー"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.move_layer",
    "old_en": "Move View Layer",
    "old_ja": "ビューレイヤーを移動します。",
    "new_en": "Move View Layer",
    "new_ja": "ビューレイヤーを移動"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "ufrp.sort_layers",
    "old_en": "Sort layers",
    "old_ja": "layersを並び替えます。",
    "new_en": "Sort View Layers",
    "new_ja": "ビューレイヤーを並び替え"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "UFRP_PT_layer_filter",
    "old_en": "ViewLayerPlus Manager filter",
    "old_ja": "ViewLayerPlus マネージャーフィルター",
    "new_en": "Manager Filter",
    "new_ja": "管理フィルター"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "UFRP_PT_passes_filter",
    "old_en": "ViewLayerPlus copy passes filter",
    "old_ja": "ViewLayerPlus コピーパスフィルター",
    "new_en": "Copy Pass Filter",
    "new_ja": "コピーパスフィルター"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "",
    "old_en": "ViewLayerPlus manager specials",
    "old_ja": "ViewLayerPlus マネージャー特殊操作",
    "new_en": "Manager Tools",
    "new_ja": "管理ツール"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "",
    "old_en": "ViewLayerPlus Manager",
    "old_ja": "ViewLayerPlus マネージャー",
    "new_en": "View Layer Manager",
    "new_ja": "ビューレイヤーマネージャー"
  },
  {
    "category": "UI/Operator/Panel",
    "area": "View Layers",
    "id": "UFRP_MT_menu",
    "old_en": "View Layers",
    "old_ja": "ビューレイヤー数",
    "new_en": "View Layers",
    "new_ja": "ビューレイヤー"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "GENERIC",
    "old_en": "Generic manifest",
    "old_ja": "共通マニフェスト",
    "new_en": "Generic Bridge",
    "new_ja": "汎用ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "MAYA_RENDER_SETUP",
    "old_en": "Maya Render Setup",
    "old_ja": "Maya Render Setup",
    "new_en": "Maya Render Setup Bridge",
    "new_ja": "Maya Render Setup ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "MAX_STATE_SETS",
    "old_en": "3ds Max State Sets",
    "old_ja": "3ds Max State Sets",
    "new_en": "3ds Max State Sets Bridge",
    "new_ja": "3ds Max State Sets ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "BACKBURNER",
    "old_en": "Backburner",
    "old_ja": "Backburner",
    "new_en": "Backburner Bridge",
    "new_ja": "Backburner ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "C4D_TAKES",
    "old_en": "Cinema 4D Takes",
    "old_ja": "Cinema 4D Takes",
    "new_en": "Cinema 4D Takes Bridge",
    "new_ja": "Cinema 4D Takes ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "TEAM_RENDER",
    "old_en": "Team Render",
    "old_ja": "Team Render",
    "new_en": "Team Render Bridge",
    "new_ja": "Team Render ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "HOUDINI_SOLARIS",
    "old_en": "Houdini Solaris / PDG",
    "old_ja": "Houdini Solaris / PDG",
    "new_en": "Houdini Solaris / PDG Bridge",
    "new_ja": "Houdini Solaris / PDG ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "USD_HYDRA",
    "old_en": "USD / Hydra",
    "old_ja": "USD / Hydra",
    "new_en": "USD / Hydra Bridge",
    "new_ja": "USD / Hydra ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "UNREAL_MRQ",
    "old_en": "Unreal MRQ",
    "old_ja": "Unreal MRQ",
    "new_en": "Unreal MRQ Bridge",
    "new_ja": "Unreal MRQ ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "UNITY_RECORDER",
    "old_en": "Unity Recorder",
    "old_ja": "Unity Recorder",
    "new_en": "Unity Recorder Bridge",
    "new_ja": "Unity Recorder ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "KATANA",
    "old_en": "Katana",
    "old_ja": "Katana",
    "new_en": "Katana Bridge",
    "new_ja": "Katana ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "CLARISSE_IFX",
    "old_en": "Clarisse iFX",
    "old_ja": "Clarisse iFX",
    "new_en": "Clarisse iFX Bridge",
    "new_ja": "Clarisse iFX ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "GOLAEM",
    "old_en": "Golaem",
    "old_ja": "Golaem",
    "new_en": "Golaem Bridge",
    "new_ja": "Golaem ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "CROWDRENDER",
    "old_en": "Crowdrender",
    "old_ja": "Crowdrender",
    "new_en": "Crowdrender Bridge",
    "new_ja": "Crowdrender ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "DEADLINE",
    "old_en": "Deadline",
    "old_ja": "Deadline",
    "new_en": "Deadline Bridge",
    "new_ja": "Deadline ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "FLAMENCO",
    "old_en": "Flamenco",
    "old_ja": "Flamenco",
    "new_en": "Flamenco Bridge",
    "new_ja": "Flamenco ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "ROYAL_RENDER",
    "old_en": "Royal Render",
    "old_ja": "Royal Render",
    "new_en": "Royal Render Bridge",
    "new_ja": "Royal Render ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "QUBE",
    "old_en": "Qube!",
    "old_ja": "Qube!",
    "new_en": "Qube! Bridge",
    "new_ja": "Qube! ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "SMEDGE",
    "old_en": "Smedge",
    "old_ja": "Smedge",
    "new_en": "Smedge Bridge",
    "new_ja": "Smedge ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "TRACTOR",
    "old_en": "Tractor",
    "old_ja": "Tractor",
    "new_en": "Tractor Bridge",
    "new_ja": "Tractor ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "GRIDMARKETS",
    "old_en": "GridMarkets",
    "old_ja": "GridMarkets",
    "new_en": "GridMarkets Bridge",
    "new_ja": "GridMarkets ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "DROP_AND_RENDER",
    "old_en": "Drop & Render",
    "old_ja": "Drop & Render",
    "new_en": "Drop & Render Bridge",
    "new_ja": "Drop & Render ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "PRISM_PIPELINE",
    "old_en": "Prism Pipeline",
    "old_ja": "Prism Pipeline",
    "new_en": "Prism Pipeline Bridge",
    "new_ja": "Prism Pipeline ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "REBUSFARM",
    "old_en": "RebusFarm",
    "old_ja": "RebusFarm",
    "new_en": "RebusFarm Bridge",
    "new_ja": "RebusFarm ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "SHEEPIT",
    "old_en": "SheepIt",
    "old_ja": "SheepIt",
    "new_en": "SheepIt Bridge",
    "new_ja": "SheepIt ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "FOX_RENDERFARM",
    "old_en": "Fox Renderfarm",
    "old_ja": "Fox Renderfarm",
    "new_en": "Fox Renderfarm Bridge",
    "new_ja": "Fox Renderfarm ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "GARAGEFARM",
    "old_en": "GarageFarm",
    "old_ja": "GarageFarm",
    "new_en": "GarageFarm Bridge",
    "new_ja": "GarageFarm ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "IRENDER",
    "old_en": "iRender",
    "old_ja": "iRender",
    "new_en": "iRender Bridge",
    "new_ja": "iRender ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "RANCH_COMPUTING",
    "old_en": "Ranch Computing",
    "old_ja": "Ranch Computing",
    "new_en": "Ranch Computing Bridge",
    "new_ja": "Ranch Computing ブリッジ"
  },
  {
    "category": "Bridge target",
    "area": "Bridge",
    "id": "RENDER_NETWORK",
    "old_en": "Render Network",
    "old_ja": "Render Network",
    "new_en": "Render Network Bridge",
    "new_ja": "Render Network ブリッジ"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "BEAUTY",
    "old_en": "Beauty",
    "old_ja": "Beauty",
    "new_en": "Beauty",
    "new_ja": "ビューティー"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "ALPHA",
    "old_en": "Alpha",
    "old_ja": "Alpha",
    "new_en": "Alpha",
    "new_ja": "アルファ"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "ZDEPTH",
    "old_en": "ZDepth",
    "old_ja": "ZDepth",
    "new_en": "ZDepth",
    "new_ja": "Z深度"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "MIST",
    "old_en": "Mist",
    "old_ja": "Mist",
    "new_en": "Mist",
    "new_ja": "ミスト"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "NORMAL",
    "old_en": "Normal",
    "old_ja": "Normal",
    "new_en": "Normal",
    "new_ja": "法線"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "VELOCITY",
    "old_en": "Velocity",
    "old_ja": "Velocity",
    "new_en": "Velocity",
    "new_ja": "ベロシティ"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "WORLD_POSITION",
    "old_en": "World Position",
    "old_ja": "World Position",
    "new_en": "World Position",
    "new_ja": "ワールド位置"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "UV",
    "old_en": "UV",
    "old_ja": "UV",
    "new_en": "UV",
    "new_ja": "UV"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "AMBIENT_OCCLUSION",
    "old_en": "Ambient Occlusion",
    "old_ja": "Ambient Occlusion",
    "new_en": "Ambient Occlusion",
    "new_ja": "アンビエントオクルージョン"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "SHADOW",
    "old_en": "Shadow",
    "old_ja": "Shadow",
    "new_en": "Shadow",
    "new_ja": "シャドウ"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "SELF_ILLUMINATION",
    "old_en": "Self Illumination",
    "old_ja": "Self Illumination",
    "new_en": "Self Illumination",
    "new_ja": "自己発光"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "BACKGROUND",
    "old_en": "Background",
    "old_ja": "Background",
    "new_en": "Background",
    "new_ja": "背景"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "OBJECT_ID",
    "old_en": "Object ID",
    "old_ja": "Object ID",
    "new_en": "Object ID",
    "new_ja": "オブジェクトID"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "MATERIAL_ID",
    "old_en": "Material ID",
    "old_ja": "Material ID",
    "new_en": "Material ID",
    "new_ja": "マテリアルID"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "CRYPTO_OBJECT",
    "old_en": "Crypto Object",
    "old_ja": "Crypto Object",
    "new_en": "Crypto Object",
    "new_ja": "Cryptomatteオブジェクト"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "CRYPTO_MATERIAL",
    "old_en": "Crypto Material",
    "old_ja": "Crypto Material",
    "new_en": "Crypto Material",
    "new_ja": "Cryptomatteマテリアル"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "CRYPTO_ASSET",
    "old_en": "Crypto Asset",
    "old_ja": "Crypto Asset",
    "new_en": "Crypto Asset",
    "new_ja": "Cryptomatteアセット"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "DIFFUSE_LIGHTING",
    "old_en": "Diffuse Lighting",
    "old_ja": "Diffuse Lighting",
    "new_en": "Diffuse Lighting",
    "new_ja": "ディフューズ照明"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "GLOBAL_ILLUMINATION",
    "old_en": "Global Illumination",
    "old_ja": "Global Illumination",
    "new_en": "Global Illumination",
    "new_ja": "グローバルイルミネーション"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "DIFFUSE_FILTER",
    "old_en": "Diffuse Filter",
    "old_ja": "Diffuse Filter",
    "new_en": "Diffuse Filter",
    "new_ja": "ディフューズフィルター"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "SPECULAR_LIGHTING",
    "old_en": "Specular Lighting",
    "old_ja": "Specular Lighting",
    "new_en": "Specular Lighting",
    "new_ja": "スペキュラー照明"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "REFLECTION",
    "old_en": "Reflection",
    "old_ja": "Reflection",
    "new_en": "Reflection",
    "new_ja": "反射"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "SPECULAR_COLOR",
    "old_en": "Specular Color",
    "old_ja": "Specular Color",
    "new_en": "Specular Color",
    "new_ja": "スペキュラーカラー"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "REFRACTION_LIGHTING",
    "old_en": "Refraction Lighting",
    "old_ja": "Refraction Lighting",
    "new_en": "Refraction Lighting",
    "new_ja": "屈折照明"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "REFRACTION",
    "old_en": "Refraction",
    "old_ja": "Refraction",
    "new_en": "Refraction",
    "new_ja": "屈折"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "REFRACTION_FILTER",
    "old_en": "Refraction Filter",
    "old_ja": "Refraction Filter",
    "new_en": "Refraction Filter",
    "new_ja": "屈折フィルター"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "VOLUME_LIGHTING",
    "old_en": "Volume Lighting",
    "old_ja": "Volume Lighting",
    "new_en": "Volume Lighting",
    "new_ja": "ボリューム照明"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "VOLUME_INDIRECT",
    "old_en": "Volume Indirect",
    "old_ja": "Volume Indirect",
    "new_en": "Volume Indirect",
    "new_ja": "ボリューム間接光"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "SSS_DIRECT",
    "old_en": "SSS Direct",
    "old_ja": "SSS Direct",
    "new_en": "SSS Direct",
    "new_ja": "SSS直接光"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "SSS_INDIRECT",
    "old_en": "SSS Indirect",
    "old_ja": "SSS Indirect",
    "new_en": "SSS Indirect",
    "new_ja": "SSS間接光"
  },
  {
    "category": "Render element",
    "area": "Render Elements",
    "id": "SSS_COLOR",
    "old_en": "SSS Color",
    "old_ja": "SSS Color",
    "new_en": "SSS Color",
    "new_ja": "SSSカラー"
  },
  {
    "category": "Workflow recipe",
    "area": "Workflow",
    "id": "SAFE_REVIEW",
    "old_en": "Safe Review Stills",
    "old_ja": "安全レビュー静止画",
    "new_en": "Review Stills",
    "new_ja": "レビュー静止画"
  },
  {
    "category": "Workflow recipe",
    "area": "Workflow",
    "id": "FINAL_EXR_COMPOSITE",
    "old_en": "Final EXR Composite",
    "old_ja": "最終EXR合成",
    "new_en": "Final EXR Composite",
    "new_ja": "最終EXR合成"
  },
  {
    "category": "Workflow recipe",
    "area": "Workflow",
    "id": "LOOKDEV_EXR",
    "old_en": "Lookdev EXR",
    "old_ja": "ルックデブEXR",
    "new_en": "Lookdev EXR",
    "new_ja": "ルックデブEXR"
  },
  {
    "category": "Workflow recipe",
    "area": "Workflow",
    "id": "LIGHTING_BREAKDOWN",
    "old_en": "Lighting Breakdown",
    "old_ja": "ライティング分解",
    "new_en": "Lighting Breakdown",
    "new_ja": "ライティング分解"
  },
  {
    "category": "Workflow recipe",
    "area": "Workflow",
    "id": "NPR_LINEART",
    "old_en": "NPR / Line Art",
    "old_ja": "NPR / 線画",
    "new_en": "NPR Line Art",
    "new_ja": "NPR線画"
  },
  {
    "category": "Workflow recipe",
    "area": "Workflow",
    "id": "DATASET_EXR",
    "old_en": "Dataset EXR",
    "old_ja": "データセットEXR",
    "new_en": "Dataset EXR",
    "new_ja": "データセットEXR"
  },
  {
    "category": "Workflow recipe",
    "area": "Workflow",
    "id": "ANIMATIC_MOVIE",
    "old_en": "Animatic / Review Movie",
    "old_ja": "アニマティック / レビュー動画",
    "new_en": "Review Movie",
    "new_ja": "レビュー動画"
  },
  {
    "category": "Always-on control",
    "area": "camera_plane",
    "id": "auto_load_maintenance",
    "old_en": "Camera Plane: File-load maintenance",
    "old_ja": "Camera Plane: ファイル読込メンテナンス",
    "new_en": "Camera Plane Maintenance",
    "new_ja": "カメラプレーンメンテナンス"
  },
  {
    "category": "Always-on control",
    "area": "rendernames",
    "id": "enabled",
    "old_en": "Render Names: Render-time output hook",
    "old_ja": "Render Names: レンダー時の出力名フック",
    "new_en": "Render Naming Hook",
    "new_ja": "レンダー命名フック"
  },
  {
    "category": "Always-on control",
    "area": "rendernames",
    "id": "auto_refresh_preview",
    "old_en": "Render Names: Auto preview refresh",
    "old_ja": "Render Names: プレビュー自動更新",
    "new_en": "Naming Preview Refresh",
    "new_ja": "命名プレビュー更新"
  },
  {
    "category": "Always-on control",
    "area": "freestyle_svg_exporter",
    "id": "auto_render_hooks",
    "old_en": "Freestyle SVG: Render-time SVG hooks",
    "old_ja": "Freestyle SVG: レンダー時SVGフック",
    "new_en": "Freestyle SVG Hook",
    "new_ja": "Freestyle SVGフック"
  },
  {
    "category": "Always-on control",
    "area": "sun_position",
    "id": "auto_update_callbacks",
    "old_en": "Sun Position: Timeline/load auto update",
    "old_ja": "Sun Position: 再生・読込中の自動更新",
    "new_en": "Sun Position Auto Update",
    "new_ja": "太陽位置自動更新"
  },
  {
    "category": "Always-on control",
    "area": "sun_position",
    "id": "show_north",
    "old_en": "Sun Position: North overlay",
    "old_ja": "Sun Position: 北方向オーバーレイ",
    "new_en": "North Overlay",
    "new_ja": "北方向オーバーレイ"
  },
  {
    "category": "Always-on control",
    "area": "sun_position",
    "id": "show_analemmas",
    "old_en": "Sun Position: Analemma display",
    "old_ja": "Sun Position: アナレンマ表示",
    "new_en": "Analemma Overlay",
    "new_ja": "アナレンマ表示"
  },
  {
    "category": "Always-on control",
    "area": "sun_position",
    "id": "show_surface",
    "old_en": "Sun Position: Sun-path surface display",
    "old_ja": "Sun Position: 太陽軌道面表示",
    "new_en": "Sun Path Surface",
    "new_ja": "太陽軌道面表示"
  },
  {
    "category": "Always-on control",
    "area": "k_tools_render_preset_manager",
    "id": "auto_sync_on_startup",
    "old_en": "Render Preset Manager: Startup auto sync",
    "old_ja": "Render Preset Manager: 起動時自動同期",
    "new_en": "Preset Auto Sync",
    "new_ja": "プリセット自動同期"
  },
  {
    "category": "Always-on control",
    "area": "profiler",
    "id": "report_enabled",
    "old_en": "Render Profiler: Live updates",
    "old_ja": "Render Profiler: ライブ更新",
    "new_en": "Profiler Live Update",
    "new_ja": "プロファイラーライブ更新"
  },
  {
    "category": "Always-on feature kind",
    "area": "controls",
    "id": "handlers",
    "old_en": "Application Handlers",
    "old_ja": "アプリケーションハンドラー",
    "new_en": "Application Handlers",
    "new_ja": "アプリケーションハンドラー"
  },
  {
    "category": "Always-on feature kind",
    "area": "controls",
    "id": "timers",
    "old_en": "Background Timers",
    "old_ja": "バックグラウンドタイマー",
    "new_en": "Background Timers",
    "new_ja": "バックグラウンドタイマー"
  },
  {
    "category": "Always-on feature kind",
    "area": "controls",
    "id": "msgbus",
    "old_en": "RNA Message Bus Watchers",
    "old_ja": "RNAメッセージバス監視",
    "new_en": "RNA Message Bus",
    "new_ja": "RNAメッセージバス"
  },
  {
    "category": "Always-on feature kind",
    "area": "controls",
    "id": "keymaps",
    "old_en": "Hotkeys",
    "old_ja": "ホットキー",
    "new_en": "Hotkeys",
    "new_ja": "ホットキー"
  },
  {
    "category": "Always-on feature kind",
    "area": "controls",
    "id": "draw_handlers",
    "old_en": "Viewport / Editor Draw",
    "old_ja": "ビューポート / エディター描画",
    "new_en": "Viewport Draw",
    "new_ja": "ビューポート描画"
  },
  {
    "category": "Token group",
    "area": "Naming Tokens",
    "id": "identity",
    "old_en": "Scene / take identity",
    "old_ja": "シーン / テイク識別",
    "new_en": "Scene and Take Identity",
    "new_ja": "シーンとテイク"
  },
  {
    "category": "Token group",
    "area": "Naming Tokens",
    "id": "frame",
    "old_en": "Frame / time",
    "old_ja": "フレーム / 時間",
    "new_en": "Frame and Time",
    "new_ja": "フレームと時間"
  },
  {
    "category": "Token group",
    "area": "Naming Tokens",
    "id": "render",
    "old_en": "Render / output",
    "old_ja": "レンダー / 出力",
    "new_en": "Render and Output",
    "new_ja": "レンダーと出力"
  },
  {
    "category": "Token group",
    "area": "Naming Tokens",
    "id": "variant",
    "old_en": "Variant / inheritance",
    "old_ja": "バリアント / 継承",
    "new_en": "Variant and Inheritance",
    "new_ja": "バリアントと継承"
  },
  {
    "category": "Token group",
    "area": "Naming Tokens",
    "id": "color",
    "old_en": "Color / look",
    "old_ja": "カラー / ルック",
    "new_en": "Color and Look",
    "new_ja": "カラーとルック"
  },
  {
    "category": "Token group",
    "area": "Naming Tokens",
    "id": "meta",
    "old_en": "Job / execution metadata",
    "old_ja": "案件 / 実行メタ",
    "new_en": "Job and Execution Metadata",
    "new_ja": "ジョブと実行情報"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{blend}",
    "old_en": "Blend name",
    "old_ja": "blend名",
    "new_en": "Blend File Name",
    "new_ja": "blend名"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{blend_file}",
    "old_en": "Blend name (alias)",
    "old_ja": "blend名(別名)",
    "new_en": "Blend File Name Alias",
    "new_ja": "blend名(別名)"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{blend_dir}",
    "old_en": "Blend parent folder",
    "old_ja": "blend親フォルダー",
    "new_en": "Blend Parent Folder",
    "new_ja": "blend親フォルダー"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{scene}",
    "old_en": "Scene name",
    "old_ja": "シーン名",
    "new_en": "Scene Name",
    "new_ja": "シーン名"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{scene_camera}",
    "old_en": "Scene camera",
    "old_ja": "シーンカメラ",
    "new_en": "Scene Camera",
    "new_ja": "シーンカメラ"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{camera}",
    "old_en": "Resolved camera",
    "old_ja": "解決カメラ",
    "new_en": "Resolved Camera",
    "new_ja": "解決カメラ"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{view_layer}",
    "old_en": "Resolved view layer",
    "old_ja": "解決ビューレイヤー",
    "new_en": "Resolved View Layer",
    "new_ja": "解決ビューレイヤー"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{render_layer}",
    "old_en": "Resolved view layer (alias)",
    "old_ja": "解決ビューレイヤー(別名)",
    "new_en": "Resolved View Layer Alias",
    "new_ja": "解決ビューレイヤー(別名)"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{layer}",
    "old_en": "Resolved view layer (short alias)",
    "old_ja": "解決ビューレイヤー(短縮別名)",
    "new_en": "Resolved View Layer Short Alias",
    "new_ja": "解決ビューレイヤー(短縮別名)"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{variant}",
    "old_en": "Variant name",
    "old_ja": "バリアント名",
    "new_en": "Variant Name",
    "new_ja": "バリアント名"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{take}",
    "old_en": "Take name (alias)",
    "old_ja": "テイク名(別名)",
    "new_en": "Take Name Alias",
    "new_ja": "テイク名(別名)"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{parent_variant}",
    "old_en": "Parent variant name",
    "old_ja": "親バリアント名",
    "new_en": "Parent Variant Name",
    "new_ja": "親バリアント名"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{parent_take}",
    "old_en": "Parent take name (alias)",
    "old_ja": "親テイク名(別名)",
    "new_en": "Parent Take Name Alias",
    "new_ja": "親テイク名(別名)"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{parent_variant_path}",
    "old_en": "Parent take path",
    "old_ja": "親テイクパス",
    "new_en": "Parent Take Path",
    "new_ja": "親テイクパス"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{variant_path}",
    "old_en": "Take path",
    "old_ja": "テイクパス",
    "new_en": "Take Path",
    "new_ja": "テイクパス"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{take_path}",
    "old_en": "Take path (alias)",
    "old_ja": "テイクパス(別名)",
    "new_en": "Take Path Alias",
    "new_ja": "テイクパス(別名)"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{variant_root}",
    "old_en": "Root variant",
    "old_ja": "ルートバリアント",
    "new_en": "Root Variant",
    "new_ja": "ルートバリアント"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{variant_chain}",
    "old_en": "Variant chain",
    "old_ja": "継承チェーン",
    "new_en": "Variant Chain",
    "new_ja": "継承チェーン"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{variant_depth}",
    "old_en": "Inheritance depth",
    "old_ja": "継承の深さ",
    "new_en": "Inheritance Depth",
    "new_ja": "継承の深さ"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{engine}",
    "old_en": "Render engine",
    "old_ja": "レンダーエンジン",
    "new_en": "Render Engine",
    "new_ja": "レンダーエンジン"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{renderer}",
    "old_en": "Render engine (alias)",
    "old_ja": "レンダーエンジン(別名)",
    "new_en": "Render Engine Alias",
    "new_ja": "レンダーエンジン(別名)"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{render_engine}",
    "old_en": "Render engine (long alias)",
    "old_ja": "レンダーエンジン(長い別名)",
    "new_en": "Render Engine Long Alias",
    "new_ja": "レンダーエンジン(長い別名)"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{quality}",
    "old_en": "Quality preset",
    "old_ja": "品質プリセット",
    "new_en": "Quality Preset",
    "new_ja": "品質プリセット"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{pass_bundle}",
    "old_en": "Pass bundle",
    "old_ja": "パスバンドル",
    "new_en": "Pass Bundle",
    "new_ja": "パスバンドル"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{format}",
    "old_en": "Image format",
    "old_ja": "保存形式",
    "new_en": "Image Format",
    "new_ja": "保存形式"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{ext}",
    "old_en": "Extension",
    "old_ja": "拡張子",
    "new_en": "Extension",
    "new_ja": "拡張子"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{fps}",
    "old_en": "FPS",
    "old_ja": "FPS",
    "new_en": "FPS",
    "new_ja": "FPS"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{frame}",
    "old_en": "Current frame",
    "old_ja": "現在フレーム",
    "new_en": "Current Frame",
    "new_ja": "現在フレーム"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{frame_start}",
    "old_en": "Start frame",
    "old_ja": "開始フレーム",
    "new_en": "Start Frame",
    "new_ja": "開始フレーム"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{frame_end}",
    "old_en": "End frame",
    "old_ja": "終了フレーム",
    "new_en": "End Frame",
    "new_ja": "終了フレーム"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{frame_count}",
    "old_en": "Frame count",
    "old_ja": "フレーム数",
    "new_en": "Frame Count",
    "new_ja": "フレーム数"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{frame_range}",
    "old_en": "Frame range",
    "old_ja": "フレーム範囲",
    "new_en": "Frame Range",
    "new_ja": "フレーム範囲"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{frame_spec}",
    "old_en": "Frame spec (alias)",
    "old_ja": "フレーム指定(別名)",
    "new_en": "Frame Spec Alias",
    "new_ja": "フレーム指定(別名)"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{resolution_x}",
    "old_en": "Resolution X",
    "old_ja": "横解像度",
    "new_en": "Resolution X",
    "new_ja": "横解像度"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{resolution_y}",
    "old_en": "Resolution Y",
    "old_ja": "縦解像度",
    "new_en": "Resolution Y",
    "new_ja": "縦解像度"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{base_resolution_x}",
    "old_en": "Base Resolution X",
    "old_ja": "元の横解像度",
    "new_en": "Base Resolution X",
    "new_ja": "元の横解像度"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{base_resolution_y}",
    "old_en": "Base Resolution Y",
    "old_ja": "元の縦解像度",
    "new_en": "Base Resolution Y",
    "new_ja": "元の縦解像度"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{representation}",
    "old_en": "Representation Mode",
    "old_ja": "Representation モード",
    "new_en": "Representation Mode",
    "new_ja": "Representation モード"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{view_transform}",
    "old_en": "View Transform",
    "old_ja": "View Transform",
    "new_en": "View Transform",
    "new_ja": "View Transform"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{look}",
    "old_en": "Look",
    "old_ja": "Look",
    "new_en": "Look",
    "new_ja": "Look"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{world}",
    "old_en": "World",
    "old_ja": "World",
    "new_en": "World",
    "new_ja": "World"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{material}",
    "old_en": "Material override",
    "old_ja": "Material Override",
    "new_en": "Material Override",
    "new_ja": "Material Override"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{date}",
    "old_en": "Date",
    "old_ja": "日付",
    "new_en": "Date",
    "new_ja": "日付"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{time}",
    "old_en": "Time",
    "old_ja": "時刻",
    "new_en": "Time",
    "new_ja": "時刻"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{datetime}",
    "old_en": "Date time",
    "old_ja": "日時",
    "new_en": "Date Time",
    "new_ja": "日時"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{year}",
    "old_en": "Year",
    "old_ja": "年",
    "new_en": "Year",
    "new_ja": "年"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{month}",
    "old_en": "Month",
    "old_ja": "月",
    "new_en": "Month",
    "new_ja": "月"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{day}",
    "old_en": "Day",
    "old_ja": "日",
    "new_en": "Day",
    "new_ja": "日"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{hour}",
    "old_en": "Hour",
    "old_ja": "時",
    "new_en": "Hour",
    "new_ja": "時"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{minute}",
    "old_en": "Minute",
    "old_ja": "分",
    "new_en": "Minute",
    "new_ja": "分"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{second}",
    "old_en": "Second",
    "old_ja": "秒",
    "new_en": "Second",
    "new_ja": "秒"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{job}",
    "old_en": "Job name",
    "old_ja": "ジョブ名",
    "new_en": "Job name",
    "new_ja": "ジョブ名"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{shot}",
    "old_en": "Shot name (alias)",
    "old_ja": "ショット名(別名)",
    "new_en": "Shot name (alias)",
    "new_ja": "ショット名(別名)"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{device}",
    "old_en": "Execution device",
    "old_ja": "実行デバイス方針",
    "new_en": "Execution device",
    "new_ja": "実行デバイス方針"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{job_tags}",
    "old_en": "Job tags",
    "old_ja": "ジョブタグ",
    "new_en": "Job tags",
    "new_ja": "ジョブタグ"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{source_mode}",
    "old_en": "Queue source mode",
    "old_ja": "キューソース種別",
    "new_en": "Queue source mode",
    "new_ja": "キューソース種別"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{label}",
    "old_en": "Label",
    "old_ja": "ラベル",
    "new_en": "Label",
    "new_ja": "ラベル"
  },
  {
    "category": "Token",
    "area": "Naming Tokens",
    "id": "{queue_label}",
    "old_en": "Queue label (alias)",
    "old_ja": "ラベル(別名)",
    "new_en": "Queue label (alias)",
    "new_ja": "ラベル(別名)"
  }
]

ID_RENAME_MAP = {
  "smart_render_smart.apply_pipeline_preset": "render_pipeline.apply_pipeline_preset",  # keep-legacy-name
  "smart_render_smart.build_render_queue": "render_pipeline.build_render_queue",  # keep-legacy-name
  "smart_render_smart.create_standard_view_layers": "render_pipeline.create_standard_view_layers",  # keep-legacy-name
  "smart_render_smart.optimize_precision_and_safety": "render_pipeline.optimize_precision_and_safety",  # keep-legacy-name
  "smart_render_smart.run_production_autopilot": "render_pipeline.run_production_autopilot",  # keep-legacy-name
  "smart_render_smart.copy_output_path": "render_pipeline.copy_output_path",  # keep-legacy-name
  "smart_render_smart.open_output_folder": "render_pipeline.open_output_folder",  # keep-legacy-name
  "SMART_RENDER_SMART_PT_RENDER_PIPELINE": "RENDER_PIPELINE_PT_RENDER_PIPELINE",  # keep-legacy-name
  "SMART_RENDER_SMART_PT_PRECISION_AND_SAFETY": "RENDER_PIPELINE_PT_PRECISION_AND_SAFETY",  # keep-legacy-name
  "SMART_RENDER_SMART_PT_STATE_MANAGEMENT": "RENDER_PIPELINE_PT_STATE_MANAGEMENT",  # keep-legacy-name
  "SMART_RENDER_SMART_PT_QUEUE_AND_NAMING": "RENDER_PIPELINE_PT_QUEUE_AND_NAMING",  # keep-legacy-name
  "SMART_RENDER_SMART_PT_AOV_AND_QUALITY": "RENDER_PIPELINE_PT_AOV_AND_QUALITY",  # keep-legacy-name
  "SMART_RENDER_SMART_PT_BRIDGE_AND_FARM": "RENDER_PIPELINE_PT_BRIDGE_AND_FARM",  # keep-legacy-name
  "SMART_RENDER_SMART_PT_VALIDATION": "RENDER_PIPELINE_PT_VALIDATION",  # keep-legacy-name
  "SMART_RENDER_SMART_PT_OUTPUT": "RENDER_PIPELINE_PT_OUTPUT",  # keep-legacy-name
  "SMART_RENDER_SMART_PT_UI_REFERENCE": "RENDER_PIPELINE_PT_UI_REFERENCE",  # keep-legacy-name
  "camera.camera_plane_add_opacity": "camera.add_plane_opacity",
  "camera.camera_plane_group": "camera.group_selected_planes",
  "camera.camera_plane_update_groups": "camera.update_plane_groups",
  "camera.camera_plane_ungroup": "camera.ungroup_planes",
  "camera.camera_plane_build": "camera.import_camera_plane",
  "camera.camera_plane_setup_layers": "camera.set_up_plane_layers",
  "camera.camera_plane_space": "camera.space_planes_evenly",
  "camera.camera_plane_reverse": "camera.reverse_order",
  "camera.camera_plane_apply": "camera.apply_camera_plane",
  "camera.camera_plane_run_load_maintenance": "camera.run_maintenance",
  "object.camera_mapping": "object.convert_to_camera_mapping",
  "add_camera_rigs.set_scene_camera": "add_camera_rigs.make_camera_active",
  "add_camera_rigs.add_marker_bind": "add_camera_rigs.add_marker_and_bind_camera",
  "add_camera_rigs.set_dof_bone": "add_camera_rigs.set_dof_to_aim_control",
  "srr.toggle_known_persistent_control": "srr.toggle_startup_control",
  "sky.dyn": "sky.create_procedural_sky",
  "DYNSKY_PT_tools": "DYNSKY_PT_DYNAMIC_SKY",
  "render.clear_frame_input": "render.clear_frame_list",
  "render.cancel_frame_ranges": "render.cancel_frame_render",
  "RENDER_PT_frame_range_renderer": "RENDER_PT_FRAME_RANGE_RENDERER",
  "RENDER_PT_SVGExporterLinesetPanel": "RENDER_PT_LINE_STYLE_SVG_EXPORT",
  "RENDER_PT_SVGExporterPanel": "RENDER_PT_FREESTYLE_SVG_EXPORT",
  "hdr.rotation": "hdr.rotate_hdri",
  "smart_render_suite.help_popup": "smart_render_suite.help",
  "render_preset.sync_blacklist": "render_preset.sync_property_list",
  "render_preset.remove_user_preset": "render_preset.confirm_preset_deletion",
  "render_preset.validate_list": "render_preset.run_property_audit",
  "render_preset.generate_new_list": "render_preset.generate_property_list",
  "render_preset.validation_report_popup": "render_preset.validation_report",
  "render_preset.fuzz_test_scene": "render_preset.run_fuzz_test",
  "render_preset.load_from_filepath": "render_preset.load_preset_from_path",
  "RENDER_PRESET_FH_drop_handler": "RENDER_PRESET_FH_PRESET_FILE_HANDLER",
  "render_preset.load": "render_preset.load_render_preset",
  "render_preset.load_preview": "render_preset.load_render_preset_load_preview",
  "render_preset.load_confirm": "render_preset.confirm_load",
  "render_preset.load_from_path": "render_preset.load_preset_directly",
  "render_preset.load_from_list": "render_preset.load_selected_preset",
  "render_preset.save": "render_preset.save_preset_to_file",
  "render_preset.save_to_user_repo": "render_preset.save_to_user_presets",
  "render_preset.save_overwrite_confirm": "render_preset.confirm_overwrite",
  "render_preset.undo": "render_preset.undo_preset_load",
  "render_preset.refresh_defaults": "render_preset.refresh_default_presets",
  "render_preset.load_default": "render_preset.load_selected_default_preset",
  "render_preset.refresh_user": "render_preset.refresh_user_presets",
  "render_preset.load_user": "render_preset.load_user_preset",
  "RENDER_PRESET_PT_panel_normal": "RENDER_PRESET_PT_RENDER_PRESETS",
  "RENDER_PRESET_PT_panel_no_header": "RENDER_PRESET_PT_RENDER_PRESETS_PANEL_NO_HEADER",
  "srr.toggle_properties_tab": "srr.refresh_n_panel",
  "srr.apply_render_elements_quick_set": "srr.apply_aov_quick_set",
  "srr.apply_profile": "srr.apply_render_profile",
  "srr.prepare_setup": "srr.prepare_scene_setup",
  "srr.workflow_recipe_dialog": "srr.workflow_recipes",
  "srr.sync_queue": "srr.sync_render_queue",
  "srr.clear_queue": "srr.clear_render_queue",
  "srr.preview_outputs": "srr.preview_output_paths",
  "srr.setup_render_elements": "srr.prepare_render_elements",
  "srr.add_variant_from_current": "srr.add_variant_from_current_state",
  "srr.capture_variant_overrides": "srr.capture_overrides",
  "srr.build_compositor_outputs": "srr.build_file_output_nodes",
  "srr.render_queue": "srr.run_render_queue",
  "RENDER_PT_overscan": "RENDER_PT_OVERSCAN",
  "profiler.open_report": "profiler.open_report_in_browser",
  "render.pseudo_rendering_farm": "render.launch_local_render_farm",
  "render.cancel_pseudo_rendering_farm": "render.cancel_all_renders",
  "render.benchmarking": "render.run_benchmark",
  "RENDER_PT_pseudo_rendering_farm": "RENDER_PT_LOCAL_RENDER_FARM",
  "rendernames.insert_variable": "rendernames.insert_token",
  "rendernames.copy_variable": "rendernames.copy_token",
  "RENDERNAMES_MT_variable_menu": "RENDERNAMES_MT_TOKENS",
  "rendernames.reset_template": "rendernames.reset_naming_template",
  "rendernames.clear_template": "rendernames.clear_naming_template",
  "rendernames.copy_preview": "rendernames.copy_preview_path",
  "rendernames.apply_to_render": "rendernames.apply_to_render_settings",
  "RENDERNAMES_MT_presets": "RENDERNAMES_MT_PRESETS",
  "RENDERNAMES_PT_main": "RENDERNAMES_PT_RENDER_NAMING",
  "RENDERNAMES_PT_options": "RENDERNAMES_PT_OPTIONS",
  "RENDERNAMES_PT_presets": "RENDERNAMES_PT_PRESETS",
  "RENDERNAMES_PT_variables": "RENDERNAMES_PT_TOKEN_REFERENCE",
  "RENDERNAMES_PT_render_output_notice": "RENDERNAMES_PT_NAMING",
  "smart_render_smart.apply_preset": "render_pipeline.apply_pipeline_preset",
  "smart_render_smart.build_queue": "render_pipeline.build_render_queue",
  "smart_render_smart.create_standard_layers": "render_pipeline.create_standard_view_layers",
  "smart_render_smart.optimize_precision": "render_pipeline.optimize_precision_and_safety",
  "smart_render_smart.autopilot": "render_pipeline.run_production_autopilot",
  "smart_render_smart.copy_last_path": "render_pipeline.copy_output_path",
  "smart_render_smart.open_output_dir": "render_pipeline.open_output_folder",
  "SMART_RENDER_SMART_PT_main": "RENDER_PIPELINE_PT_RENDER_PIPELINE",
  "SMART_RENDER_SMART_PT_precision": "RENDER_PIPELINE_PT_PRECISION_AND_SAFETY",
  "SMART_RENDER_SMART_PT_state": "RENDER_PIPELINE_PT_STATE_MANAGEMENT",
  "SMART_RENDER_SMART_PT_batch": "RENDER_PIPELINE_PT_QUEUE_AND_NAMING",
  "SMART_RENDER_SMART_PT_aov": "RENDER_PIPELINE_PT_AOV_AND_QUALITY",
  "SMART_RENDER_SMART_PT_bridge": "RENDER_PIPELINE_PT_BRIDGE_AND_FARM",
  "SMART_RENDER_SMART_PT_validation": "RENDER_PIPELINE_PT_VALIDATION",
  "SMART_RENDER_SMART_PT_output": "RENDER_PIPELINE_PT_OUTPUT",
  "SMART_RENDER_SMART_PT_visual_reference": "RENDER_PIPELINE_PT_UI_REFERENCE",
  "world.sunpos_show_env": "world.pick_sun_in_viewport",
  "world.sunpos_create_analemmas_object": "world.create_analemma_object",
  "world.sunpos_create_surface_object": "world.create_sun_path_surface",
  "world.sunpos_add_preset": "world.add_sun_position_preset",
  "object.trilighting": "object.create_three_point_lighting",
  "SRR_PT_properties_nav": "SRR_PT_PANEL_NAVIGATION",
  "SRR_PT_main": "SRR_PT_MAIN_PANEL",
  "smart_render_suite.integrated_addon_info": "smart_render_suite.show_integrated_tool_info",
  "smart_render_suite.integrated_invoke": "smart_render_suite.integrated_tool",
  "ufrp.toggle": "ufrp.toggle_selected_for_rendering",
  "ufrp.batch": "ufrp.batch_toggle_rendering",
  "ufrp.only_active": "ufrp.enable_only_unmuted_nodes",
  "ufrp.only_selected": "ufrp.enable_only_selected",
  "ufrp.switch_render_layer": "ufrp.switch_to_active_render_layer_node",
  "ufrp.view_layer_add": "ufrp.add_view_layer",
  "ufrp.view_layer_remove": "ufrp.remove_view_layer",
  "ufrp.all_passes": "ufrp.toggle_all_copy_passes",
  "ufrp.reload_passes": "ufrp.reload_copy_passes",
  "ufrp.copy_layer_props": "ufrp.copy_layer_settings",
  "ufrp.paste_layer_props": "ufrp.paste_layer_settings",
  "ufrp.copy_to_selected": "ufrp.copy_collection_settings",
  "ufrp.move_layer": "ufrp.move_view_layer",
  "ufrp.sort_layers": "ufrp.sort_view_layers",
  "UFRP_PT_layer_filter": "UFRP_PT_MANAGER_FILTER",
  "UFRP_PT_passes_filter": "UFRP_PT_COPY_PASS_FILTER",
  "UFRP_MT_menu": "UFRP_MT_VIEW_LAYERS"
}

LABEL_RENAME_MAP = {
  "カメラプレーン": "カメラ画像プレーン",
  "Camera Rigs": "Camera Rig Builder",
  "Dynamic Sky": "Cycles Sky Generator",
  "Frame Range Renderer": "Frame Range Render",
  "フレーム範囲レンダラー": "フレーム範囲レンダー",
  "Freestyle SVG Exporter": "Freestyle SVG Export",
  "オーバースキャン": "レンダーオーバースキャン",
  "Pseudo Rendering Farm": "Local Render Farm",
  "疑似レンダリングファーム": "ローカルレンダーファーム",
  "レンダー Profiler": "レンダープロファイラー",
  "Render Names": "Render Output Naming",
  "Sun Position": "Sun Position Control",
  "Tri Lighting": "Three-Point Lighting",
  "View Layer Plus": "View Layer Manager",
  "Add Opacity to Plane": "Add Plane Opacity",
  "プレーンに不透明度を追加": "プレーンに透明度を追加",
  "Update Groups": "Update Plane Groups",
  "グループを更新": "プレーングループを更新",
  "Ungroup": "Ungroup Planes",
  "グループ解除": "プレーンのグループを解除",
  "Setup Layers": "Set Up Plane Layers",
  "レイヤーを設定": "プレーンレイヤーを設定",
  "Space Evenly": "Space Planes Evenly",
  "等間隔に配置": "プレーンを等間隔に配置",
  "Reverse": "Reverse Order",
  "反転": "順序を反転",
  "Run Camera Plane Maintenance": "Run Maintenance",
  "カメラプレーンのメンテナンスを実行": "メンテナンスを実行",
  "Camera Plane Options": "Options",
  "カメラプレーンオプション": "オプション",
  "カメラをアクティブにする": "カメラをアクティブ化",
  "マーカーを追加してカメラをバインド": "マーカー追加とカメラ割り当て",
  "Set DOF to Aim": "Set DOF to Aim Control",
  "DOF を Aim に設定": "DOFをAimに設定",
  "ドリーズームを削除": "ドリーズームを解除",
  "Shift To Pivot": "Shift to Pivot",
  "ピボットへシフト": "ピボットへ移動",
  "Camera Rig Lens Specials": "Lens Tools",
  "カメラリグ レンズ特殊設定": "レンズツール",
  "Always-on Toggle": "Always-on Toggles",
  "Save Preferences": "Save Settings",
  "Toggle Always-on Control": "Toggle Startup Control",
  "常時起動項目を切り替え": "常時機能切り替え",
  "Make a Procedural sky": "Create Procedural Sky",
  "Dynamic sky": "Dynamic Sky",
  "Cancel Render": "Cancel Frame Render",
  "レンダーをキャンセル": "フレームレンダーを中止",
  "Freestyle Line Style SVG Export": "Line Style SVG Export",
  "Freestyle ラインスタイル SVG 書き出し": "ラインスタイルSVG書き出し",
  "Freestyle SVG 書き出し": "Freestyle SVG書き出し",
  "プロパティ一覧を同期": "プロパティリストを同期",
  "プリセット削除の確認": "プリセット削除を確認",
  "Run Full Property Audit": "Run Property Audit",
  "完全プロパティ監査を実行": "プロパティ監査を実行",
  "Generate New List from Scraper": "Generate Property List",
  "スクレイパーから新規リストを生成": "プロパティリストを生成",
  "Fuzz Test Scene (Monkey Test)": "Run Fuzz Test",
  "ファズテストシーン（モンキーテスト）": "ファズテストを実行",
  "Load Preset from Filepath": "Load Preset from Path",
  "ファイルパスからプリセットを読み込み": "パスからプリセットを読み込み",
  "Render Preset File Handler": "Preset File Handler",
  "レンダープリセットファイルハンドラー": "プリセットファイルハンドラー",
  "読み込み確認": "読み込みを確認",
  "Load Preset From Path (Direct)": "Load Preset Directly",
  "パスからプリセットを直接読み込み": "プリセットを直接読み込み",
  "Save Preset to File...": "Save Preset to File",
  "プリセットをファイルに保存...": "プリセットをファイルへ保存",
  "Save to User Repository": "Save to User Presets",
  "ユーザーリポジトリに保存": "ユーザープリセットへ保存",
  "上書き確認": "上書きを確認",
  "デフォルトプリセットを更新": "既定プリセットを更新",
  "Load Selected Default": "Load Selected Default Preset",
  "選択デフォルトを読み込み": "選択した既定プリセットを読み込み",
  "Update User Presets": "Refresh User Presets",
  "プリセット API リストを更新": "プリセットAPIリストを更新",
  "Render Preset Manager": "Render Presets",
  "Smart Render Nパネル更新": "Nパネルを更新",
  "Apply Render Elements Quick Set": "Apply AOV Quick Set",
  "レンダーエレメント一括反映": "AOVクイックセットを適用",
  "Apply Profile": "Apply Render Profile",
  "プロファイル適用": "レンダープロファイルを適用",
  "Prepare Setup": "Prepare Scene Setup",
  "基本設定を整える": "シーン基本設定を準備",
  "パス適用": "パスバンドルを適用",
  "ワークフローレシピ適用": "ワークフローレシピを適用",
  "Auto Repair": "Auto Repair Scene",
  "自動整理": "シーンを自動整理",
  "シーン診断": "シーンを診断",
  "Sync Queue": "Sync Render Queue",
  "キュー同期": "レンダーキューを同期",
  "Clear Queue": "Clear Render Queue",
  "キュー削除": "レンダーキューを削除",
  "キュー項目追加": "キュー項目を追加",
  "キュー項目複製": "キュー項目を複製",
  "キュー項目削除": "キュー項目を削除",
  "キュー並び替え": "キュー項目を移動",
  "ログ削除": "ログを削除",
  "Preview Paths": "Preview Output Paths",
  "出力プレビュー": "出力パスを確認",
  "Setup Render Elements": "Prepare Render Elements",
  "レンダーエレメント準備": "レンダーエレメントを準備",
  "ネットワークレンダー準備": "ネットワークレンダーを準備",
  "マニフェスト書き出し": "マニフェストを書き出し",
  "マニフェスト読み込み": "マニフェストを読み込み",
  "Export Bridge JSON": "Export Bridge Manifest",
  "ブリッジJSON書き出し": "ブリッジマニフェストを書き出し",
  "ヘッドレス実行スクリプト書き出し": "ヘッドレススクリプトを書き出し",
  "Add Variant From Current": "Add Variant From Current State",
  "現在状態から追加": "現在状態からバリアントを追加",
  "子バリアント追加": "子バリアントを追加",
  "バリアント複製": "バリアントを複製",
  "バリアント削除": "バリアントを削除",
  "現在状態を取り込み": "オーバーライドを取り込み",
  "バリアント適用": "バリアントを適用",
  "File Outputノード構築": "File Outputノードを構築",
  "Render Queue": "Run Render Queue",
  "キュー実行": "レンダーキューを実行",
  "Open Render Profiler Report in Browser": "Open Report in Browser",
  "Render Profiler レポートをブラウザーで開く": "レポートをブラウザーで開く",
  "プロファイルを停止": "計測を停止",
  "Launch Pseudo Rendering Farm": "Launch Local Render Farm",
  "疑似レンダリングファームを起動": "ローカルレンダーファームを起動",
  "すべてのレンダーをキャンセル": "すべてのレンダーを中止",
  "Launch benchmark": "Run Benchmark",
  "ベンチマークを起動": "ベンチマークを実行",
  "Insert Variable": "Insert Token",
  "変数を挿入": "トークンを挿入",
  "Copy Variable": "Copy Token",
  "変数をコピー": "トークンをコピー",
  "Variables": "Tokens",
  "変数": "トークン",
  "Reset Template": "Reset Naming Template",
  "テンプレートをリセット": "命名テンプレートをリセット",
  "Clear Template": "Clear Naming Template",
  "テンプレートをクリア": "命名テンプレートをクリア",
  "プリセットを読み込み": "プリセットをインポート",
  "プリセットを書き出し": "プリセットをエクスポート",
  "RenderNames": "Render Naming",
  "レンダー 名前": "レンダーネーミング",
  "Variables Reference": "Token Reference",
  "変数リファレンス": "トークンリファレンス",
  "Apply Preset": "Apply Pipeline Preset",
  "プリセット反映": "パイプラインプリセットを適用",
  "Build Queue": "Build Render Queue",
  "キュー生成": "レンダーキューを生成",
  "Create Standard Layers": "Create Standard View Layers",
  "標準レイヤー作成": "標準ビューレイヤーを作成",
  "Headlessスクリプト生成": "ヘッドレススクリプトを書き出し",
  "Optimize Precision": "Optimize Precision and Safety",
  "精度最適化": "精度と安全性を最適化",
  "提出パック書き出し": "提出パックを書き出し",
  "Production Autopilot": "Run Production Autopilot",
  "本番オートパイロット": "本番オートパイロットを実行",
  "Copy Path": "Copy Output Path",
  "パスをコピー": "出力パスをコピー",
  "Pick 太陽 in ビューポート": "ビューポートで太陽を選択",
  "Create Sun Analemmas Object": "Create Analemma Object",
  "Create 太陽 Analemmas オブジェクト": "アナレンマオブジェクトを作成",
  "Create Sun Surface Object": "Create Sun Path Surface",
  "Create 太陽 Surface オブジェクト": "太陽軌道面を作成",
  "太陽 Position プリセット": "太陽位置プリセット",
  "Add Sun Position preset": "Add Sun Position Preset",
  "太陽 Position presetを追加します。": "太陽位置プリセットを追加",
  "3-Point Lighting": "Create Three-Point Lighting",
  "3点ライティング": "三点照明を作成",
  "Profile": "Render Profile",
  "プロファイル": "レンダープロファイル",
  "Execution": "Execution Plan",
  "Variants / Takes": "Variants and Takes",
  "バリアント": "バリアントとテイク",
  "Batch Queue": "Render Queue",
  "バッチキュー": "レンダーキュー",
  "Extra Tools": "Integrated Tools",
  "追加ツール": "統合ツール",
  "Load Smart Render Tool": "Load Integrated Tool",
  "Smart Render ツールを読み込む": "統合ツールを読み込む",
  "Integrated Add-on Info": "Show Integrated Tool Info",
  "統合アドオン情報": "統合ツール情報を表示",
  "Smart Render Tool": "Integrated Tool",
  "Smart Render ツール": "統合ツール",
  "Use for rendering selected": "Toggle Selected for Rendering",
  "for rendering selectedを使用します。": "選択項目のレンダー使用を切り替え",
  "Use for rendering batch": "Batch Toggle Rendering",
  "for rendering batchを使用します。": "レンダー使用を一括切り替え",
  "Enable unmuted only": "Enable Only Unmuted Nodes",
  "unmuted onlyを有効にします。": "ミュートされていないノードのみ有効",
  "Enable selected only": "Enable Only Selected",
  "selected onlyを有効にします。": "選択項目のみ有効",
  "Switch to active Render Layer Node": "Switch to Active Render Layer Node",
  "アクティブな Render Layer ノードへ切り替え": "アクティブなRender Layerノードへ切替",
  "ビューレイヤーを追加します。": "ビューレイヤーを追加",
  "ビューレイヤーを削除します。": "ビューレイヤーを削除",
  "Switch to View Layer": "Switch View Layer",
  "Switch to ビューレイヤー": "ビューレイヤーを切替",
  "Check/Uncheck all": "Toggle All Copy Passes",
  "すべてチェック/解除": "コピーパスを一括切り替え",
  "Reload passes to copy": "Reload Copy Passes",
  "コピー対象パスを再読み込み": "コピーパスを再読み込み",
  "Copy properties and render settings": "Copy Layer Settings",
  "プロパティとレンダー設定をコピー": "レイヤー設定をコピー",
  "Paste properties and render settings": "Paste Layer Settings",
  "プロパティとレンダー設定を貼り付け": "レイヤー設定を貼り付け",
  "Copy Collection's settings to...": "Copy Collection Settings",
  "コレクション's settings to...をコピーします。": "コレクション設定をコピー",
  "ビューレイヤーを移動します。": "ビューレイヤーを移動",
  "Sort layers": "Sort View Layers",
  "layersを並び替えます。": "ビューレイヤーを並び替え",
  "ViewLayerPlus Manager filter": "Manager Filter",
  "ViewLayerPlus マネージャーフィルター": "管理フィルター",
  "ViewLayerPlus copy passes filter": "Copy Pass Filter",
  "ViewLayerPlus コピーパスフィルター": "コピーパスフィルター",
  "ViewLayerPlus manager specials": "Manager Tools",
  "ViewLayerPlus マネージャー特殊操作": "管理ツール",
  "ViewLayerPlus Manager": "View Layer Manager",
  "ViewLayerPlus マネージャー": "ビューレイヤーマネージャー",
  "ビューレイヤー数": "ビューレイヤー",
  "Generic manifest": "Generic Bridge",
  "共通マニフェスト": "汎用ブリッジ",
  "ZDepth": "Z深度",
  "Velocity": "ベロシティ",
  "World Position": "ワールド位置",
  "Ambient Occlusion": "アンビエントオクルージョン",
  "Self Illumination": "自己発光",
  "Background": "背景",
  "Object ID": "オブジェクトID",
  "Material ID": "マテリアルID",
  "Crypto Object": "Cryptomatteオブジェクト",
  "Crypto Material": "Cryptomatteマテリアル",
  "Crypto Asset": "Cryptomatteアセット",
  "Diffuse Lighting": "ディフューズ照明",
  "Global Illumination": "グローバルイルミネーション",
  "Diffuse Filter": "ディフューズフィルター",
  "Specular Lighting": "スペキュラー照明",
  "Reflection": "反射",
  "Specular Color": "スペキュラーカラー",
  "Refraction Lighting": "屈折照明",
  "Refraction": "屈折",
  "Refraction Filter": "屈折フィルター",
  "Volume Lighting": "ボリューム照明",
  "Volume Indirect": "ボリューム間接光",
  "SSS Direct": "SSS直接光",
  "SSS Indirect": "SSS間接光",
  "SSS Color": "SSSカラー",
  "Safe Review Stills": "Review Stills",
  "安全レビュー静止画": "レビュー静止画",
  "NPR / Line Art": "NPR Line Art",
  "NPR / 線画": "NPR線画",
  "Animatic / Review Movie": "Review Movie",
  "アニマティック / レビュー動画": "レビュー動画",
  "Camera Plane: File-load maintenance": "Camera Plane Maintenance",
  "Camera Plane: ファイル読込メンテナンス": "カメラプレーンメンテナンス",
  "Render Names: Render-time output hook": "Render Naming Hook",
  "Render Names: レンダー時の出力名フック": "レンダー命名フック",
  "Render Names: Auto preview refresh": "Naming Preview Refresh",
  "Render Names: プレビュー自動更新": "命名プレビュー更新",
  "Freestyle SVG: Render-time SVG hooks": "Freestyle SVG Hook",
  "Freestyle SVG: レンダー時SVGフック": "Freestyle SVGフック",
  "Sun Position: Timeline/load auto update": "Sun Position Auto Update",
  "Sun Position: 再生・読込中の自動更新": "太陽位置自動更新",
  "Sun Position: North overlay": "North Overlay",
  "Sun Position: 北方向オーバーレイ": "北方向オーバーレイ",
  "Sun Position: Analemma display": "Analemma Overlay",
  "Sun Position: アナレンマ表示": "アナレンマ表示",
  "Sun Position: Sun-path surface display": "Sun Path Surface",
  "Sun Position: 太陽軌道面表示": "太陽軌道面表示",
  "Render Preset Manager: Startup auto sync": "Preset Auto Sync",
  "Render Preset Manager: 起動時自動同期": "プリセット自動同期",
  "Render Profiler: Live updates": "Profiler Live Update",
  "Render Profiler: ライブ更新": "プロファイラーライブ更新",
  "RNA Message Bus Watchers": "RNA Message Bus",
  "RNAメッセージバス監視": "RNAメッセージバス",
  "Viewport / Editor Draw": "Viewport Draw",
  "ビューポート / エディター描画": "ビューポート描画",
  "Scene / take identity": "Scene and Take Identity",
  "シーン / テイク識別": "シーンとテイク",
  "Frame / time": "Frame and Time",
  "フレーム / 時間": "フレームと時間",
  "Render / output": "Render and Output",
  "レンダー / 出力": "レンダーと出力",
  "Variant / inheritance": "Variant and Inheritance",
  "バリアント / 継承": "バリアントと継承",
  "Color / look": "Color and Look",
  "カラー / ルック": "カラーとルック",
  "Job / execution metadata": "Job and Execution Metadata",
  "案件 / 実行メタ": "ジョブと実行情報",
  "Blend name": "Blend File Name",
  "Blend name (alias)": "Blend File Name Alias",
  "Blend parent folder": "Blend Parent Folder",
  "Scene name": "Scene Name",
  "Scene camera": "Scene Camera",
  "Resolved camera": "Resolved Camera",
  "Resolved view layer": "Resolved View Layer",
  "Resolved view layer (alias)": "Resolved View Layer Alias",
  "Resolved view layer (short alias)": "Resolved View Layer Short Alias",
  "Variant name": "Variant Name",
  "Take name (alias)": "Take Name Alias",
  "Parent variant name": "Parent Variant Name",
  "Parent take name (alias)": "Parent Take Name Alias",
  "Parent take path": "Parent Take Path",
  "Take path": "Take Path",
  "Take path (alias)": "Take Path Alias",
  "Root variant": "Root Variant",
  "Variant chain": "Variant Chain",
  "Inheritance depth": "Inheritance Depth",
  "Render engine": "Render Engine",
  "Render engine (alias)": "Render Engine Alias",
  "Render engine (long alias)": "Render Engine Long Alias",
  "Quality preset": "Quality Preset",
  "Pass bundle": "Pass Bundle",
  "Image format": "Image Format",
  "Current frame": "Current Frame",
  "Start frame": "Start Frame",
  "End frame": "End Frame",
  "Frame count": "Frame Count",
  "Frame range": "Frame Range",
  "Frame spec (alias)": "Frame Spec Alias",
  "Material override": "Material Override",
  "Date time": "Date Time",
  "Add Camera Rigs": "Camera Rig Builder",
  "K-Tools: Render Preset Manager": "Render Preset Manager",
  "Hdr Rotation": "HDRI Rotation",
  "HDR Rotation": "HDRI Rotation",
  "Overscan Render": "Render Overscan",
  "Tri-lighting": "Three-Point Lighting",
  "Smart Render Smart": "Render Pipeline Manager"
}

NAME_BY_ID = {row["id"]: (row["new_en"], row["new_ja"]) for row in NAMING_ROWS if row.get("id")}

def label_for(identifier: str, *, language: str = "en", fallback: str = "") -> str:
    names = NAME_BY_ID.get(str(identifier or ""), None)
    if not names:
        return fallback
    return names[1] if str(language).lower().startswith("ja") else names[0]

def renamed_id(identifier: str) -> str:
    return ID_RENAME_MAP.get(str(identifier or ""), str(identifier or ""))
