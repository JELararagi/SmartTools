from __future__ import annotations

import os

from .compat import (
    abspath,
    compositor_node_tree,
    default_output_root,
    ensure_compositor_node_tree,
    ensure_directory,
    file_output_data_inputs,
    file_output_frame_subpath_from_base,
    file_output_item_base_subpath,
    file_output_item_label,
    file_output_item_socket_type,
    remember_file_output_item_base_subpath,
    safe_name,
    safe_set_attr,
    set_image_file_format,
    view_layer,
)
from .planner import (
    available_view_layers,
    effective_queue_blueprint,
    pass_output_folder_name,
    render_element_display_name,
    render_element_socket_allowed,
    render_elements_image_format,
    resolve_item_context,
)
from .translation import t


SRR_RENDER_LAYER_PREFIX = "SRR_RenderLayers::"
SRR_FILE_OUTPUT_PREFIX = "SRR_FileOutput::"
MULTILAYER_FORMAT = "OPEN_EXR_MULTILAYER"



def has_file_output_nodes(scene) -> bool:
    tree = compositor_node_tree(scene)
    if tree is None:
        return False
    for node in getattr(tree, "nodes", []):
        try:
            if getattr(node, "bl_idname", "") == "CompositorNodeOutputFile" or getattr(node, "type", "") == "OUTPUT_FILE":
                return True
        except Exception:
            continue
    return False



def file_output_collection(file_node):
    for attr_name in ("file_output_items", "file_slots", "layer_slots"):
        collection = getattr(file_node, attr_name, None)
        if collection is not None:
            return collection
    return None



def _collection_remove(collection, item_or_index) -> bool:
    remover = getattr(collection, "remove", None)
    if not callable(remover):
        return False
    try:
        remover(item_or_index)
        return True
    except Exception:
        return False



def clear_file_output_items(file_node) -> None:
    collection = file_output_collection(file_node)
    if collection is None:
        return
    while True:
        try:
            length = len(collection)
        except Exception:
            length = 0
        if length <= 0:
            return
        try:
            item = collection[length - 1]
        except Exception:
            item = None
        if item is not None and _collection_remove(collection, item):
            continue
        if _collection_remove(collection, length - 1):
            continue
        break



def _normalized_socket_key(value: str) -> str:
    return safe_name(value).strip().lower()



def _unique_output_item_name(base_name: str, used_names) -> str:
    token = safe_name(base_name) or "element"
    if token not in used_names:
        used_names.add(token)
        return token
    index = 2
    while True:
        candidate = f"{token}_{index}"
        if candidate not in used_names:
            used_names.add(candidate)
            return candidate
        index += 1



def new_file_output_item(file_node, name: str, source_socket=None):
    collection = file_output_collection(file_node)
    if collection is None:
        return None
    safe_token = safe_name(name) or "pass"
    creator = getattr(collection, "new", None)
    created = None
    if callable(creator):
        socket_type = file_output_item_socket_type(source_socket, default="RGBA")
        for args, kwargs in [
            ((socket_type, safe_token), {}),
            ((safe_token,), {}),
            ((), {"name": safe_token}),
        ]:
            try:
                created = creator(*args, **kwargs)
                break
            except Exception:
                continue
    if created is None:
        try:
            created = collection[-1] if len(collection) else None
        except Exception:
            created = None
    if created is not None:
        safe_set_attr(created, "name", safe_token)
        remember_file_output_item_base_subpath(created, safe_token, fallback=safe_token)
    return created



def set_file_output_directory(file_node, directory: str) -> None:
    if not safe_set_attr(file_node, "directory", directory):
        safe_set_attr(file_node, "base_path", directory)


def file_output_format(file_node, fallback: str = "PNG") -> str:
    return str(getattr(getattr(file_node, "format", None), "file_format", "") or fallback or "PNG")



def file_output_is_multilayer(file_node, fallback: str = "PNG") -> bool:
    return file_output_format(file_node, fallback) == MULTILAYER_FORMAT



def set_file_output_basename(file_node, basename: str) -> None:
    raw_value = str(basename or "passes")
    safe_value = safe_name(raw_value) or "passes"
    if raw_value.endswith("_") and not safe_value.endswith("_"):
        safe_value = f"{safe_value}_"
    for attr_name in ("file_name", "filename"):
        if safe_set_attr(file_node, attr_name, safe_value):
            return



def set_file_output_format(file_node, image_format: str) -> None:
    """A new File Output node starts as a multilayer image, so its format has to be set through the media type."""
    set_image_file_format(getattr(file_node, "format", None), image_format)


def set_file_output_frame_names(file_node, layer_name: str, multilayer: bool, padding: int = 4) -> None:
    """Number each frame's files; without # marks every frame overwrites the same file."""
    marks = "#" * max(1, int(padding or 4))
    if multilayer:
        safe_set_attr(file_node, "file_name", f"{safe_name(layer_name)}_{marks}")
        return
    # Item names also become EXR channels / Cryptomatte metadata. Keep those
    # stable; only the file-name template may contain frame placeholders.
    safe_set_attr(file_node, "file_name", marks)
    for index, item in enumerate(list(file_output_collection(file_node) or [])):
        base_name = file_output_item_label(item, f"pass_{index + 1}")
        safe_set_attr(item, "name", base_name)


def set_file_output_item_layer_name(item, layer_name: str) -> None:
    safe_layer = safe_name(layer_name) or "pass"
    safe_set_attr(item, "name", safe_layer)
    for attr_name in ("file_name", "path"):
        safe_set_attr(item, attr_name, "")



def set_file_output_item_path(item, subpath: str, *, remember_base: bool = False, fallback: str = "pass") -> str:
    normalized = safe_name(subpath) if "/" not in str(subpath or "") else str(subpath or "")
    if remember_base:
        normalized = remember_file_output_item_base_subpath(item, normalized, fallback=fallback)
    for attr_name in ("file_name", "path"):
        if safe_set_attr(item, attr_name, normalized):
            return normalized
    return normalized



def file_output_input_for_index(file_node, index: int, *, item=None, item_name: str = ""):
    inputs = file_output_data_inputs(file_node)
    if not inputs:
        return None

    search_keys = []
    if item is not None:
        for value in (getattr(item, "name", ""), getattr(item, "identifier", "")):
            token = _normalized_socket_key(str(value or ""))
            if token:
                search_keys.append(token)
    token = _normalized_socket_key(str(item_name or ""))
    if token:
        search_keys.append(token)

    if search_keys:
        for socket in inputs:
            socket_keys = {
                _normalized_socket_key(str(getattr(socket, "name", "") or "")),
                _normalized_socket_key(str(getattr(socket, "identifier", "") or "")),
            }
            if socket_keys.intersection(search_keys):
                return socket

    try:
        return inputs[index]
    except Exception:
        pass
    try:
        return inputs[-1]
    except Exception:
        return None



def clear_node_input_links(tree, node) -> None:
    links = getattr(tree, "links", None)
    if links is None or node is None:
        return
    for link in list(links):
        try:
            if getattr(link, "to_node", None) == node:
                links.remove(link)
        except Exception:
            continue



def queue_target_layers(context, scene, settings, enabled_only: bool = False):
    items = effective_queue_blueprint(context, scene, settings, enabled_only=enabled_only)
    context_view_layer_name = getattr(getattr(context, "view_layer", None), "name", "")
    layers = []
    seen = set()
    for item in items:
        resolved = resolve_item_context(scene, settings, item, context_view_layer_name=context_view_layer_name)
        layer_name = str(resolved.get("view_layer_name", "") or "")
        layer_item = view_layer(scene, layer_name) if layer_name else None
        if layer_item is None or layer_item.name in seen:
            continue
        seen.add(layer_item.name)
        layers.append(layer_item)
    return layers



def cleanup_srs_compositor_nodes(scene) -> int:
    tree = compositor_node_tree(scene)
    if tree is None:
        return 0
    removed = 0
    for node in list(getattr(tree, "nodes", [])):
        name = str(getattr(node, "name", ""))
        if name.startswith(SRR_RENDER_LAYER_PREFIX) or name.startswith(SRR_FILE_OUTPUT_PREFIX):
            try:
                tree.nodes.remove(node)
                removed += 1
            except Exception:
                pass
    return removed



def configure_srs_file_output_nodes(
    scene,
    image_format: str,
    base_output_dir: str,
    variant_name: str = "base",
    *,
    frame_value: int | None = None,
    padding: int = 4,
    explicit_frame_token: bool = False,
    target_layer_name: str | None = None,
) -> int:
    tree = compositor_node_tree(scene)
    if tree is None:
        return 0
    count = 0
    passes_root = os.path.join(base_output_dir, pass_output_folder_name(getattr(scene, "srr_settings", None)), safe_name(variant_name or "base"))
    for node in getattr(tree, "nodes", []):
        name = str(getattr(node, "name", ""))
        if not name.startswith(SRR_FILE_OUTPUT_PREFIX):
            continue
        layer_name = name.split("::", 1)[1] if "::" in name else name
        if target_layer_name is not None:
            node.mute = layer_name != target_layer_name
            if node.mute:
                continue
        node_dir = os.path.join(passes_root, safe_name(layer_name))
        ensure_directory(node_dir)
        set_file_output_directory(node, node_dir)
        set_file_output_format(node, image_format)
        multilayer_output = file_output_is_multilayer(node, image_format)
        if multilayer_output:
            for index, item in enumerate(list(file_output_collection(node) or [])):
                set_file_output_item_layer_name(item, file_output_item_label(item, f"pass_{index + 1}"))
        set_file_output_frame_names(node, layer_name, multilayer_output, padding)
        count += 1
    return count



def _render_layer_output_sockets(render_node, settings):
    output_sockets = [socket for socket in render_node.outputs if getattr(socket, "enabled", True)]
    if bool(getattr(settings, "render_elements_enabled", False)):
        output_sockets = [
            socket
            for socket in output_sockets
            if render_element_socket_allowed(
                str(getattr(socket, "name", "") or getattr(socket, "identifier", "") or ""),
                settings,
            )
        ]
    if not output_sockets:
        fallback_socket = next((socket for socket in render_node.outputs if getattr(socket, "name", "") in {"Image", "Combined"}), None)
        if fallback_socket is not None:
            output_sockets = [fallback_socket]
    return output_sockets



def _output_socket_item_names(output_sockets, settings):
    used_item_names = set()
    names = []
    for socket_index, socket in enumerate(output_sockets):
        raw_item_name = (
            render_element_display_name(str(getattr(socket, "name", "") or getattr(socket, "identifier", "") or f"pass_{socket_index + 1}"))
            if bool(getattr(settings, "render_elements_enabled", False))
            else (getattr(socket, "name", "") or f"pass_{socket_index + 1}")
        )
        names.append(_unique_output_item_name(raw_item_name, used_item_names))
    return names



def refresh_file_output_node_for_layer(context, layer_item) -> bool:
    """Rebuild one layer's output node when its inputs no longer match the passes that are on."""
    scene = context.scene
    settings = scene.srr_settings
    tree = compositor_node_tree(scene)
    if tree is None or layer_item is None:
        return False
    render_node = tree.nodes.get(f"{SRR_RENDER_LAYER_PREFIX}{layer_item.name}")
    file_node = tree.nodes.get(f"{SRR_FILE_OUTPUT_PREFIX}{layer_item.name}")
    if render_node is None or file_node is None:
        return False
    wanted = _output_socket_item_names(_render_layer_output_sockets(render_node, settings), settings)
    current = [
        file_output_item_label(item, f"pass_{index + 1}")
        for index, item in enumerate(list(file_output_collection(file_node) or []))
    ]
    if sorted(wanted) == sorted(current):
        return False
    render_location = tuple(render_node.location)
    file_location = tuple(file_node.location)
    build_compositor_outputs(context, target_layers=[layer_item], keep_other_nodes=True)
    render_node.location = render_location
    file_node.location = file_location
    return True



def build_compositor_outputs(context, target_layers=None, keep_other_nodes=False):
    scene = context.scene
    settings = scene.srr_settings
    tree = ensure_compositor_node_tree(scene)
    if tree is None:
        return 0, 0, 0

    if target_layers is None:
        layers = available_view_layers(context, settings)
    else:
        layers = []
        seen = set()
        for layer_ref in target_layers:
            layer_item = layer_ref if hasattr(layer_ref, "name") else view_layer(scene, str(layer_ref))
            if layer_item is None or layer_item.name in seen:
                continue
            seen.add(layer_item.name)
            layers.append(layer_item)
        if not layers:
            layers = available_view_layers(context, settings)

    created_nodes = 0
    linked_outputs = 0

    if not keep_other_nodes:
        cleanup_srs_compositor_nodes(scene)

    default_root = os.path.join(
        abspath(settings.output_root or default_output_root(create=True)),
        safe_name(scene.name),
        pass_output_folder_name(settings),
        "base",
    )

    for index, layer_item in enumerate(layers):
        render_name = f"{SRR_RENDER_LAYER_PREFIX}{layer_item.name}"
        file_name = f"{SRR_FILE_OUTPUT_PREFIX}{layer_item.name}"
        render_node = tree.nodes.get(render_name)
        if render_node is None:
            render_node = tree.nodes.new("CompositorNodeRLayers")
            created_nodes += 1
        render_node.name = render_name
        render_node.label = t(settings, f"レンダーレイヤー {layer_item.name}", f"Render Layers {layer_item.name}")
        render_node.location = (-640, -index * 380)
        safe_set_attr(render_node, "scene", scene)
        safe_set_attr(render_node, "layer", layer_item.name)

        file_node = tree.nodes.get(file_name)
        if file_node is None:
            file_node = tree.nodes.new("CompositorNodeOutputFile")
            created_nodes += 1
        file_node.name = file_name
        file_node.label = (
            t(settings, f"レンダーエレメント {layer_item.name}", f"Render Elements {layer_item.name}")
            if bool(getattr(settings, "render_elements_enabled", False))
            else t(settings, f"AOV 出力 {layer_item.name}", f"AOV Output {layer_item.name}")
        )
        safe_set_attr(file_node, "width", 320.0)
        file_node.location = (-120, -index * 380)
        set_file_output_directory(file_node, os.path.join(default_root, safe_name(layer_item.name)))
        output_format = render_elements_image_format(settings) if bool(getattr(settings, "render_elements_enabled", False)) else settings.image_format
        set_file_output_format(file_node, output_format)
        multilayer_output = file_output_is_multilayer(file_node, output_format)

        clear_file_output_items(file_node)
        clear_node_input_links(tree, file_node)

        output_sockets = _render_layer_output_sockets(render_node, settings)
        for socket_index, (socket, item_name) in enumerate(zip(output_sockets, _output_socket_item_names(output_sockets, settings))):
            item = new_file_output_item(file_node, item_name, source_socket=socket)
            if item is not None:
                if multilayer_output:
                    set_file_output_item_layer_name(item, item_name)
                else:
                    set_file_output_item_path(item, item_name, remember_base=True, fallback=item_name)
            try:
                target_input = file_output_input_for_index(file_node, socket_index, item=item, item_name=item_name)
                if target_input is not None:
                    tree.links.new(socket, target_input)
                    linked_outputs += 1
            except Exception:
                continue
        set_file_output_frame_names(file_node, layer_item.name, multilayer_output)

    return created_nodes, linked_outputs, len(layers)
