from __future__ import annotations

import re
from typing import Dict, Iterable, List, Sequence, Tuple


_SANITIZE_RE = re.compile(r"[^0-9A-Za-z_]+")


def _slug(value: object, fallback: str = "node") -> str:
    text = str(value or "").strip().lower()
    if not text:
        return fallback
    text = _SANITIZE_RE.sub("_", text).strip("_")
    return text or fallback


def _node_id(prefix: str, *parts: object, seen: set[str] | None = None) -> str:
    base = "_".join(part for part in [_slug(prefix, prefix)] + [_slug(part, "") for part in parts] if part)
    if not base:
        base = _slug(prefix, prefix)
    if seen is None or base not in seen:
        if seen is not None:
            seen.add(base)
        return base
    suffix = 2
    while f"{base}_{suffix}" in seen:
        suffix += 1
    value = f"{base}_{suffix}"
    seen.add(value)
    return value


def _job_signature(job: Dict[str, object]) -> Tuple[str, str, str, str, Tuple[int, ...]]:
    frames = tuple(int(frame) for frame in (job.get("frames", []) or []) if frame is not None)
    return (
        str(job.get("label", "") or ""),
        str(job.get("variant", "") or job.get("variant_name", "") or ""),
        str(job.get("camera", "") or job.get("camera_name", "") or ""),
        str(job.get("view_layer", "") or job.get("view_layer_name", "") or ""),
        frames,
    )


def _movie_index(post_tasks: Dict[str, object]) -> Dict[Tuple[str, str, str, str, Tuple[int, ...]], Dict[str, object]]:
    result: Dict[Tuple[str, str, str, str, Tuple[int, ...]], Dict[str, object]] = {}
    for item in (post_tasks.get("ffmpeg_jobs", []) or []):
        if not isinstance(item, dict):
            continue
        signature = _job_signature(item)
        result[signature] = item
        label, variant, camera, view_layer, _frames = signature
        result.setdefault((label, variant, camera, view_layer, ()), item)
    return result


def _chunk_frames(chunk: Dict[str, object], job: Dict[str, object]) -> List[int]:
    frames = [int(frame) for frame in (chunk.get("frames", []) or []) if frame is not None]
    if frames:
        return frames
    if chunk.get("start") is not None and chunk.get("end") is not None:
        start = int(chunk.get("start"))
        end = int(chunk.get("end"))
        return list(range(start, end + 1)) if end >= start else [start]
    return [int(frame) for frame in (job.get("frames", []) or []) if frame is not None]


def _max_dependency_depth(nodes: Sequence[Dict[str, object]]) -> int:
    node_map = {str(node.get("id", "")): node for node in nodes if str(node.get("id", ""))}
    cache: Dict[str, int] = {}

    def depth(node_id: str, visiting: set[str]) -> int:
        if node_id in cache:
            return cache[node_id]
        if node_id in visiting:
            return 1
        node = node_map.get(node_id)
        if node is None:
            return 1
        deps = [str(dep) for dep in (node.get("dependencies", []) or []) if str(dep)]
        if not deps:
            cache[node_id] = 1
            return 1
        visiting.add(node_id)
        value = 1 + max(depth(dep, visiting) for dep in deps)
        visiting.remove(node_id)
        cache[node_id] = value
        return value

    max_depth = 0
    for node_id in node_map:
        max_depth = max(max_depth, depth(node_id, set()))
    return max_depth


def _verification_command_preview(job: Dict[str, object]) -> str:
    verification = job.get("verification", {}) or {}
    expected_count = int(verification.get("expected_output_count", 0) or 0)
    min_size = int(verification.get("min_output_size_bytes", 0) or 0)
    retries = int(verification.get("retry_count", 0) or 0)
    delay = float(verification.get("retry_delay_seconds", 0.0) or 0.0)
    label = str(job.get("label", "") or "job")
    return f"verify_outputs --label \"{label}\" --expected {expected_count} --min-bytes {min_size} --retries {retries} --delay {delay:.2f}"


def task_graph_from_manifest(manifest: Dict[str, object]) -> Dict[str, object]:
    resolved_queue = [item for item in (manifest.get("resolved_queue", []) or []) if isinstance(item, dict) and bool(item.get("enabled", True))]
    post_tasks = manifest.get("post_tasks", {}) or {}
    global_verification = manifest.get("verification", {}) or {}
    movie_jobs = _movie_index(post_tasks)

    nodes: List[Dict[str, object]] = []
    edges: List[Dict[str, str]] = []
    seen_ids: set[str] = set()

    def add_node(node: Dict[str, object]) -> Dict[str, object]:
        node_id = str(node.get("id", "") or "")
        if not node_id:
            node_id = _node_id(str(node.get("type", "node") or "node"), node.get("label", "node"), seen=seen_ids)
            node["id"] = node_id
        else:
            if node_id in seen_ids:
                node_id = _node_id(node_id, seen=seen_ids)
                node["id"] = node_id
            else:
                seen_ids.add(node_id)
        dependencies = [str(dep) for dep in (node.get("dependencies", []) or []) if str(dep)]
        node["dependencies"] = dependencies
        nodes.append(node)
        for dep in dependencies:
            edges.append({"from": dep, "to": node_id})
        return node

    for index, job in enumerate(resolved_queue, start=1):
        label = str(job.get("label", "") or job.get("variant", "") or job.get("camera", "") or f"job_{index}")
        variant_name = str(job.get("variant", "") or "")
        camera_name = str(job.get("camera", "") or "")
        view_layer_name = str(job.get("view_layer", "") or "")
        base_parts = [label, variant_name, camera_name, view_layer_name, index]
        render_ids: List[str] = []

        chunk_commands = [chunk for chunk in (job.get("chunk_commands", []) or []) if isinstance(chunk, dict)]
        if chunk_commands:
            total_chunks = max(1, len(chunk_commands))
            for chunk_index, chunk in enumerate(chunk_commands, start=1):
                frames = _chunk_frames(chunk, job)
                node = add_node(
                    {
                        "id": _node_id("render", *base_parts, chunk.get("chunk_index", chunk_index), seen=seen_ids),
                        "type": "render_chunk",
                        "label": str(chunk.get("label", "") or f"{label} [chunk {chunk_index}/{total_chunks}]"),
                        "job_label": label,
                        "variant": variant_name,
                        "camera": camera_name,
                        "view_layer": view_layer_name,
                        "frames": frames,
                        "frames_string": str(chunk.get("frames_string", "") or job.get("frames_string", "") or ""),
                        "resource_profile": dict(job.get("resource_profile", {}) or {}),
                        "command": str(chunk.get("background_command", "") or chunk.get("command", "") or job.get("background_command", "")),
                        "output_directory": str(job.get("output_directory", "") or ""),
                        "first_output": str(job.get("first_output", "") or ""),
                        "dependencies": [],
                        "chunk_index": int(chunk.get("chunk_index", chunk.get("index", chunk_index)) or chunk_index),
                        "chunk_total": int(chunk.get("chunk_total", total_chunks) or total_chunks),
                    }
                )
                render_ids.append(str(node["id"]))
        else:
            frames = [int(frame) for frame in (job.get("frames", []) or []) if frame is not None]
            if not frames:
                start = job.get("frame_start", 1)
                end = job.get("frame_end", start)
                start_i = int(start)
                end_i = int(end)
                frames = list(range(start_i, end_i + 1)) if end_i >= start_i else [start_i]
            node = add_node(
                {
                    "id": _node_id("render", *base_parts, seen=seen_ids),
                    "type": "render_job",
                    "label": label,
                    "job_label": label,
                    "variant": variant_name,
                    "camera": camera_name,
                    "view_layer": view_layer_name,
                    "frames": frames,
                    "frames_string": str(job.get("frames_string", "") or ""),
                    "resource_profile": dict(job.get("resource_profile", {}) or {}),
                    "command": str(job.get("background_command", "") or ""),
                    "output_directory": str(job.get("output_directory", "") or ""),
                    "first_output": str(job.get("first_output", "") or ""),
                    "dependencies": [],
                }
            )
            render_ids.append(str(node["id"]))

        verification = dict(job.get("verification", {}) or {})
        verify_enabled = bool(verification.get("enabled", global_verification.get("enabled", False)))
        verify_id = ""
        if verify_enabled:
            verify_node = add_node(
                {
                    "id": _node_id("verify", *base_parts, seen=seen_ids),
                    "type": "verify_outputs",
                    "label": f"Verify {label}",
                    "job_label": label,
                    "variant": variant_name,
                    "camera": camera_name,
                    "view_layer": view_layer_name,
                    "verification": verification,
                    "expected_output_count": int(verification.get("expected_output_count", 0) or 0),
                    "expected_outputs_preview": list((verification.get("expected_outputs_preview", []) or [])[:16]),
                    "command_preview": _verification_command_preview(job),
                    "dependencies": list(render_ids),
                }
            )
            verify_id = str(verify_node["id"])

        movie_job = movie_jobs.get(_job_signature(job))
        if movie_job is None:
            # Fallback match without frame tuple when the post task only keeps a label/camera/layer signature.
            signature_wo_frames = (
                label,
                variant_name,
                camera_name,
                view_layer_name,
                (),
            )
            movie_job = movie_jobs.get(signature_wo_frames)
        if isinstance(movie_job, dict) and str(movie_job.get("command", "") or "").strip():
            add_node(
                {
                    "id": _node_id("movie", *base_parts, seen=seen_ids),
                    "type": "movie_encode",
                    "label": str(movie_job.get("label", "") or f"Movie {label}"),
                    "job_label": label,
                    "variant": variant_name,
                    "camera": camera_name,
                    "view_layer": view_layer_name,
                    "frames": [int(frame) for frame in (movie_job.get("frames", []) or job.get("frames", []) or []) if frame is not None],
                    "resource_profile": dict(movie_job.get("resource_profile", job.get("resource_profile", {}) or {}) or {}),
                    "command": str(movie_job.get("command", "") or ""),
                    "output_path": str(movie_job.get("output_path", "") or ""),
                    "input_pattern": str(movie_job.get("input_pattern", "") or ""),
                    "preset": str(movie_job.get("preset", "") or ""),
                    "renamed_for_safety": bool(movie_job.get("renamed_for_safety", False)),
                    "safety_suffix": str(movie_job.get("safety_suffix", "") or ""),
                    "dependencies": [verify_id] if verify_id else list(render_ids),
                }
            )

    summary = {
        "job_count": len(resolved_queue),
        "node_count": len(nodes),
        "edge_count": len(edges),
        "render_node_count": sum(1 for node in nodes if str(node.get("type", "")).startswith("render")),
        "verify_node_count": sum(1 for node in nodes if node.get("type") == "verify_outputs"),
        "movie_node_count": sum(1 for node in nodes if node.get("type") == "movie_encode"),
        "post_node_count": sum(1 for node in nodes if node.get("type") in {"verify_outputs", "movie_encode"}),
        "chunk_count": sum(1 for node in nodes if node.get("type") == "render_chunk"),
        "max_dependency_depth": _max_dependency_depth(nodes),
    }

    return {
        "mode": "dependency_graph",
        "nodes": nodes,
        "edges": edges,
        "summary": summary,
    }
