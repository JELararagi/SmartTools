from ..translation import iface_text
import bpy
from ..rna_safety import safe_register_class, safe_unregister_class
from bpy.types import Menu, Panel

from .operators import get_rig_and_cam, poll_base
from ..help_operator import draw_help_button


class CameraRigUIMixin():
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True

    @classmethod
    def poll(cls, context):
        return poll_base(cls, context)




def _safe_rig_cam(context):
    try:
        obj = getattr(context, 'active_object', None)
    except Exception:
        obj = None
    rig, cam = get_rig_and_cam(obj)
    if rig is None or cam is None:
        return None, None, None
    try:
        cam_data = getattr(cam, 'data', None)
    except ReferenceError:
        return None, None, None
    except Exception:
        return None, None, None
    if cam_data is None:
        return None, None, None
    return rig, cam, cam_data


def _safe_pose_bones(rig):
    try:
        return getattr(getattr(rig, 'pose', None), 'bones', None)
    except ReferenceError:
        return None
    except Exception:
        return None


def _rig_id_lower(rig) -> str:
    try:
        return str(rig.get('rig_id', '')).lower()
    except Exception:
        try:
            return str(rig['rig_id']).lower()
        except Exception:
            return ''

class ADD_CAMERA_RIGS_MT_lens_ops(Menu):
    bl_label = "Lens Tools"

    def draw(self, context):
        _rig, _cam, cam_data = _safe_rig_cam(context)
        if cam_data is None:
            return
        layout = self.layout

        try:
            drv = cam_data.animation_data.drivers[0]
            expression = getattr(getattr(drv, 'driver', None), 'expression', '')
        except Exception:
            expression = ''
        if expression == "lens":
            layout.operator("add_camera_rigs.set_dolly_zoom")
        else:
            layout.operator("add_camera_rigs.remove_dolly_zoom")

        layout.operator("add_camera_rigs.shift_to_pivot")
        layout.operator("add_camera_rigs.swap_lens")


class ADD_CAMERA_RIGS_PT_camera_rig_ui(Panel, CameraRigUIMixin):
    bl_label = "Camera Rig"

    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'integrated:camera_rigs')

    def draw(self, context):
        rig, _cam, cam_data = _safe_rig_cam(context)
        pose_bones = _safe_pose_bones(rig)
        if rig is None or cam_data is None or pose_bones is None:
            return
        layout = self.layout
        layout.use_property_split = True

        # Camera lens
        rig_id = _rig_id_lower(rig)
        if rig_id in ("dolly_rig", "crane_rig"):
            col = layout.column(align=True)
            row = col.row(align=False)
            try:
                drv = cam_data.animation_data.drivers[0]
                expression = getattr(getattr(drv, 'driver', None), 'expression', '')
            except Exception:
                expression = ''
            camera_bone = pose_bones.get("Camera") if hasattr(pose_bones, 'get') else None
            if cam_data.type == 'ORTHO':
                row.prop(cam_data, "ortho_scale")
            elif expression == "lens" and camera_bone is not None:
                row.prop(camera_bone, '["lens"]', text=iface_text("Focal Length"))
            else:
                if camera_bone is not None:
                    row.prop(camera_bone, '["lens_offset"]',
                            text=iface_text("Lens Offset"))
                sub = col.row(align=False)
                sub.enabled = True
                sub.prop(cam_data, "lens")
            row.menu("ADD_CAMERA_RIGS_MT_lens_ops", icon='DOWNARROW_HLT', text="")

            col = layout.column(align=True)
            col.prop(cam_data, "shift_x", text=iface_text("Shift X"))
            col.prop(cam_data, "shift_y", text=iface_text("Y"))

        # 2D rig stuff
        elif rig_id == "2d_rig":
            col = layout.column(align=True)
            camera_bone = pose_bones.get("Camera") if hasattr(pose_bones, 'get') else None
            if camera_bone is not None:
                col.prop(camera_bone, '["rotation_shift"]',
                        text=iface_text("Rotation/Shift"))
            if getattr(cam_data, "sensor_width", 36) != 36:
                col.label(text=iface_text("Please set Camera Sensor Width to 36"), icon="ERROR")

        sub = layout.column(align=True)
        sub.prop(cam_data, "clip_start", text=iface_text("Clip Start"))
        sub.prop(cam_data, "clip_end", text=iface_text("End"))

        layout.prop(cam_data, "type")


class ADD_CAMERA_RIGS_PT_camera_rig_ui_dof(Panel, CameraRigUIMixin):
    bl_label = "Depth of Field"
    bl_parent_id = ""

    def draw_header(self, context):
        _rig, _cam, cam_data = _safe_rig_cam(context)
        if cam_data is None:
            return

        layout = self.layout
        layout.prop(cam_data.dof, "use_dof", text="")

    def draw(self, context):
        rig, _cam, cam_data = _safe_rig_cam(context)
        pose_bones = _safe_pose_bones(rig)
        if rig is None or cam_data is None or pose_bones is None:
            return
        layout = self.layout
        layout.use_property_split = True

        col = layout.column(align=False)
        col.active = True
        if cam_data.dof.focus_object is None:
            if _rig_id_lower(rig) == "2d_rig":
                col.operator("add_camera_rigs.set_dof_to_aim_control", text=iface_text("Setup DOF Bone"))
            else:
                col.operator("add_camera_rigs.set_dof_to_aim_control")
        sub = col.column(align=True)
        sub.prop(cam_data.dof, "focus_object", text=iface_text("Focus on Object"))
        focus_object = getattr(cam_data.dof, 'focus_object', None)
        if focus_object is not None and getattr(focus_object, 'type', None) == 'ARMATURE':
            focus_data = getattr(focus_object, 'data', None)
            if focus_data is not None:
                sub.prop_search(cam_data.dof, "focus_subtarget",
                                focus_data, "bones")

        camera_bone = pose_bones.get("Camera") if hasattr(pose_bones, 'get') else None
        if camera_bone is not None:
            row = col.row(align=True)
            row.active = True
            row.prop(camera_bone,
                    '["focus_distance"]', text=iface_text("Focus Distance"))
            col.prop(camera_bone,
                    '["aperture_fstop"]', text=iface_text("F-Stop"))


class ADD_CAMERA_RIGS_PT_camera_rig_ui_viewport(Panel, CameraRigUIMixin):
    bl_label = "Viewport Display"
    bl_parent_id = ""

    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'integrated:camera_rigs')

    def draw(self, context):
        try:
            active_object = getattr(context, 'active_object', None)
        except Exception:
            active_object = None
        _rig, _cam, cam_data = _safe_rig_cam(context)
        if active_object is None or cam_data is None:
            return
        layout = self.layout
        layout.use_property_split = True

        col = layout.column(align=False, heading=iface_text("Show"))
        col.prop(active_object, 'show_in_front',
                    toggle=False, text=iface_text('In Front'))
        col.prop(cam_data, "show_limits", text=iface_text("Limits"))

        col = layout.column(align=False, heading=iface_text("Passepartout"))
        col.use_property_decorate = False
        row = col.row(align=True)
        sub = row.row(align=True)
        sub.prop(cam_data, "show_passepartout", text="")
        sub = sub.row(align=True)
        sub.active = True
        sub.prop(cam_data, "passepartout_alpha", text="")
        row.prop_decorator(cam_data, "passepartout_alpha")

        # Composition guides
        col.separator()
        col.popover(
            panel="ADD_CAMERA_RIGS_PT_composition_guides",
            text=iface_text("Composition Guides"),
        )


class ADD_CAMERA_RIGS_PT_camera_rig_ui_visibility(Panel, CameraRigUIMixin):
    bl_label = "Rig Properties"
    bl_parent_id = ""

    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'integrated:camera_rigs')

    def draw(self, context):
        _rig, cam, _cam_data = _safe_rig_cam(context)
        rig = _rig
        pose_bones = _safe_pose_bones(rig)
        if rig is None or cam is None or pose_bones is None:
            return
        layout = self.layout

        col = layout.column(align=True)
        col.prop(cam, "hide_select", text=iface_text("Make Camera Unselectable"))
        col.operator("add_camera_rigs.add_marker_and_bind_camera",
                     text=iface_text("Add Marker and Bind"), icon="MARKER_HLT")
        col.operator("add_camera_rigs.make_camera_active",
                     text=iface_text("Make Camera Active"), icon='CAMERA_DATA')

        layout.use_property_split = True

        rig_id = _rig_id_lower(rig)
        if rig_id in ("dolly_rig", "crane_rig"):
            # Track to Constraint
            track_to_constraint = None
            camera_bone = pose_bones.get("Camera") if hasattr(pose_bones, 'get') else None
            for con in getattr(camera_bone, 'constraints', []) if camera_bone is not None else []:
                if con.type == 'TRACK_TO':
                    track_to_constraint = con
                    break
            if track_to_constraint is not None:
                col = layout.column(align=True)
                col.prop(track_to_constraint, 'influence',
                         text=iface_text("Aim Lock"), slider=True)

            # Crane arm stuff
            if rig_id == "crane_rig":
                col = layout.column(align=True)
                crane_height = pose_bones.get("Crane_Height") if hasattr(pose_bones, 'get') else None
                crane_arm = pose_bones.get("Crane_Arm") if hasattr(pose_bones, 'get') else None
                if crane_height is not None:
                    col.prop(crane_height,
                             'scale', index=1, text=iface_text("Crane Arm Height"))
                if crane_arm is not None:
                    col.prop(crane_arm,
                             'scale', index=1, text=iface_text("Length"))

        elif rig_id == "2d_rig" and "MCH-DOF_Parent" in pose_bones:
            # DOF constraint
            copy_loc_constraint = None
            dof_parent = pose_bones.get("MCH-DOF_Parent") if hasattr(pose_bones, 'get') else None
            for con in getattr(dof_parent, 'constraints', []) if dof_parent is not None else []:
                if con.type == 'COPY_LOCATION':
                    copy_loc_constraint = con
                    break
            if copy_loc_constraint is not None:
                col = layout.column(align=True)
                col.prop(copy_loc_constraint, 'influence',
                         text=iface_text("Aim DOF"), slider=True)


def register():

    safe_register_class(ADD_CAMERA_RIGS_MT_lens_ops)
    safe_register_class(ADD_CAMERA_RIGS_PT_camera_rig_ui)
    safe_register_class(ADD_CAMERA_RIGS_PT_camera_rig_ui_dof)
    safe_register_class(ADD_CAMERA_RIGS_PT_camera_rig_ui_viewport)
    safe_register_class(ADD_CAMERA_RIGS_PT_camera_rig_ui_visibility)


def unregister():
    safe_unregister_class(ADD_CAMERA_RIGS_MT_lens_ops)
    safe_unregister_class(ADD_CAMERA_RIGS_PT_camera_rig_ui)
    safe_unregister_class(ADD_CAMERA_RIGS_PT_camera_rig_ui_dof)
    safe_unregister_class(ADD_CAMERA_RIGS_PT_camera_rig_ui_viewport)
    safe_unregister_class(ADD_CAMERA_RIGS_PT_camera_rig_ui_visibility)
