import bpy
from bpy.props import PointerProperty, StringProperty
from bpy.types import PropertyGroup

from ..translation import localize_inline, localize_pair


_REGISTER_ERROR = ""
_REGISTERED_POINTER = False

_PROPERTY_NAME = "smart_render_camera_rigs_prefs"


class CAMERA_RIGS_RuntimePreferences(PropertyGroup):
    widget_prefix: StringProperty(
        name=localize_pair("ウィジェット接頭辞", "Widget Prefix"),
        description=localize_inline("Prefix used when Smart Render creates camera rig widget objects. Example: WGT-. / Smart Render がカメラリグ用ウィジェットを作成する時の接頭辞です。例: WGT-."),
        default="WGT-",
    )  # type: ignore

    camera_widget_collection_name: StringProperty(
        name=localize_pair("コレクション名", "Collection Name"),
        description=localize_inline("Collection name used for generated camera rig widgets. A hidden collection is created automatically when needed. / 生成したカメラリグ用ウィジェットを入れるコレクション名です。必要な場合は非表示コレクションを自動作成します。"),
        default="Widgets",
    )  # type: ignore



def get_runtime_preferences(context=None):
    ctx = context or getattr(bpy, "context", None)
    wm = getattr(ctx, "window_manager", None)
    return getattr(wm, _PROPERTY_NAME, None) if wm is not None else None



def _draw_common(layout, settings) -> None:
    col = layout.column(align=True)
    col.prop(settings, "widget_prefix")
    col.prop(settings, "camera_widget_collection_name")



def draw_runtime_settings(layout, context) -> None:
    settings = get_runtime_preferences(context)
    if settings is None:
        layout.label(text=localize_inline("Camera Rig Builder settings are not available yet. / Camera Rig Builder 設定はまだ利用できません。"), icon="ERROR", translate=False)
        return
    box = layout.box()
    box.label(text=localize_inline("Widget generation settings / ウィジェット生成設定"), icon="PREFERENCES")
    _draw_common(box, settings)



def register() -> None:
    global _REGISTER_ERROR, _REGISTERED_POINTER
    _REGISTER_ERROR = ""
    _REGISTERED_POINTER = False
    from ..rna_safety import register_pointer_property
    try:
        _REGISTERED_POINTER = bool(register_pointer_property(bpy.types.WindowManager, "smart_render_camera_rigs_prefs", CAMERA_RIGS_RuntimePreferences))
    except Exception as exc:
        _REGISTER_ERROR = str(exc)
        _REGISTERED_POINTER = False



def unregister() -> None:
    global _REGISTER_ERROR, _REGISTERED_POINTER
    if hasattr(bpy.types.WindowManager, "smart_render_camera_rigs_prefs"):
        try:
            del bpy.types.WindowManager.smart_render_camera_rigs_prefs
        except Exception:
            pass
    try:
        from ..rna_safety import unregister_existing_class
        unregister_existing_class(CAMERA_RIGS_RuntimePreferences)
    except Exception:
        pass
    _REGISTER_ERROR = ""
    _REGISTERED_POINTER = False
