from __future__ import annotations

# Integrated build: add-on preferences are intentionally not registered or used.
# Runtime settings live in camera_rigs/runtime_preferences.py and are drawn in the Smart Render N-panel.

classes = ()


def register():
    return None


def unregister():
    return None
