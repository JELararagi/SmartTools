import bpy
from ..rna_safety import safe_register_class, safe_unregister_class
from bpy.types import Panel

from .operators import get_rig_and_cam, poll_base

class ADD_CAMERA_RIGS_PT_composition_guides(Panel):
    bl_label = "Composition Guides"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_keep_popover_poll = True

    @classmethod
    def poll(cls, context):
        return poll_base(cls, context)

    def draw(self, context):
        layout = self.layout

        _rig, cam = get_rig_and_cam(getattr(context, 'active_object', None))
        if cam is None or getattr(cam, 'data', None) is None:
            return
        cam = cam.data

        layout.prop(cam, "show_safe_areas")
        layout.row().separator()
        layout.prop(cam, "show_composition_center")
        layout.prop(cam, "show_composition_center_diagonal")
        layout.prop(cam, "show_composition_golden")
        layout.prop(cam, "show_composition_golden_tria_a")
        layout.prop(cam, "show_composition_golden_tria_b")
        layout.prop(cam, "show_composition_harmony_tri_a")
        layout.prop(cam, "show_composition_harmony_tri_b")
        layout.prop(cam, "show_composition_thirds")


def register():
    safe_register_class(ADD_CAMERA_RIGS_PT_composition_guides)


def unregister():
    safe_unregister_class(ADD_CAMERA_RIGS_PT_composition_guides)


if __name__ == "__main__":
    register()
