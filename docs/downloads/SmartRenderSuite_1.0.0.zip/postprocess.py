from __future__ import annotations

import os
import re
from typing import Dict, List, Optional

from .compat import safe_name


MOVIE_PRESET_EXTENSIONS = {
    "H264_MP4": "mp4",
    "H264_HIGH_MP4": "mp4",
    "PRORES_PROXY_MOV": "mov",
    "PRORES_422_MOV": "mov",
    "VP9_WEBM": "webm",
    "LOSSLESS_MKV": "mkv",
}


def movie_preset_extension(preset: str) -> str:
    return MOVIE_PRESET_EXTENSIONS.get(str(preset or "H264_MP4"), "mp4")


def _apply_tokens(pattern: str, tokens: Dict[str, str]) -> str:
    result = str(pattern or "")
    for key, value in tokens.items():
        result = result.replace("{" + key + "}", str(value))

    def sanitize_unresolved(match: re.Match[str]) -> str:
        safe_token = safe_name(match.group(1))
        return safe_token or "token"

    result = re.sub(r"\{([^{}]+)\}", sanitize_unresolved, result)
    return result.replace("\\", "/").strip()


def _normalize_movie_stem(path_like: str, ext: str, fallback: str) -> str:
    value = str(path_like or "").replace("\\", "/").strip()
    while value.startswith("/"):
        value = value[1:]
    while value.startswith("./"):
        value = value[2:]
    if not value or value in {".", ".."}:
        value = fallback
    value = os.path.normpath(value).replace("\\", "/")
    if value in {"", "."}:
        value = fallback

    suffix = f".{str(ext or '').strip().lower().lstrip('.')}"
    if suffix and value.lower().endswith(suffix):
        value = value[: -len(suffix)]
    value = value.rstrip(". ") or fallback

    basename = os.path.basename(value)
    if basename in {"", ".", ".."}:
        value = os.path.join(value, fallback).replace("\\", "/")
    return value


def _quote(arg: str) -> str:
    return '"' + str(arg or "").replace('"', "'") + '"'


def _codec_args(preset: str) -> List[str]:
    preset = str(preset or "H264_MP4")
    if preset == "H264_HIGH_MP4":
        return ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "15", "-preset", "slow"]
    if preset == "PRORES_PROXY_MOV":
        return ["-c:v", "prores_ks", "-profile:v", "0", "-pix_fmt", "yuv422p10le"]
    if preset == "PRORES_422_MOV":
        return ["-c:v", "prores_ks", "-profile:v", "3", "-pix_fmt", "yuv422p10le"]
    if preset == "VP9_WEBM":
        return ["-c:v", "libvpx-vp9", "-pix_fmt", "yuv420p", "-crf", "30", "-b:v", "0"]
    if preset == "LOSSLESS_MKV":
        return ["-c:v", "ffv1", "-level", "3"]
    return ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-preset", "medium"]


def build_sequence_input_pattern(first_output: str, frame_start: int, padding: int) -> Optional[str]:
    path = str(first_output or "")
    if not path:
        return None
    directory, filename = os.path.split(path)
    stem, ext = os.path.splitext(filename)
    frame_token = str(int(frame_start)).zfill(max(1, int(padding or 1)))

    if stem.endswith(frame_token):
        seq_stem = stem[: -len(frame_token)] + f"%0{max(1, int(padding or 1))}d"
        return os.path.join(directory, seq_stem + ext)

    match = re.search(rf"(\d{{{max(1, int(padding or 1))}}})(?!.*\d)", stem)
    if match:
        start, end = match.span(1)
        seq_stem = stem[:start] + f"%0{max(1, int(padding or 1))}d" + stem[end:]
        return os.path.join(directory, seq_stem + ext)
    return None


def build_ffmpeg_command(executable: str, fps: str, input_pattern: str, output_path: str, preset: str, overwrite: bool) -> str:
    args = [str(executable or "ffmpeg"), "-hide_banner", "-loglevel", "error", "-stats"]
    args.append("-y" if overwrite else "-n")
    args.extend(["-framerate", str(fps or "24"), "-i", str(input_pattern or "")])
    args.extend(_codec_args(preset))
    args.append(str(output_path or ""))
    def needs_quote(arg: str) -> bool:
        value = str(arg or "")
        return (" " in value) or (not value) or (os.sep in value) or value.endswith((".png", ".exr", ".jpg", ".jpeg", ".mov", ".mp4", ".webm", ".mkv"))
    return " ".join(_quote(arg) if needs_quote(arg) else str(arg) for arg in args)


def build_movie_job(
    output_dir: str,
    movie_pattern: str,
    tokens: Dict[str, str],
    preset: str,
    first_output: str,
    frame_start: int,
    frame_count: int,
    padding: int,
    ffmpeg_executable: str,
    overwrite: bool,
) -> Optional[Dict[str, str]]:
    if int(frame_count or 0) <= 1:
        return None

    sequence_pattern = build_sequence_input_pattern(first_output, frame_start, padding)
    if not sequence_pattern:
        return None

    ext = movie_preset_extension(preset)
    fallback = safe_name(tokens.get("scene") or tokens.get("job") or "render")
    movie_stem = _normalize_movie_stem(_apply_tokens(movie_pattern, tokens), ext, fallback)
    output_path = os.path.join(str(output_dir or ""), movie_stem)
    output_path = os.path.normpath(output_path)
    if ext:
        output_path = f"{output_path}.{ext}"

    fps = tokens.get("fps", "24")
    command = build_ffmpeg_command(ffmpeg_executable, fps, sequence_pattern, output_path, preset, overwrite)
    return {
        "input_pattern": sequence_pattern,
        "output_path": output_path,
        "preset": str(preset or "H264_MP4"),
        "fps": str(fps),
        "command": command,
    }
