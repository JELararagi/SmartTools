# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

from pathlib import Path
from typing import Any

from .tool_folders import TOOL_SPECS

SUITE_META = {
    'smart_render_suite': ('Smart Render', 'navigation_properties'),
}

SUITE_ORDER: tuple[str, ...] = tuple(SUITE_META.keys())

_CACHE: list[dict[str, Any]] | None = None


def package_root() -> Path:
    return Path(__file__).resolve().parent


def tools_root() -> Path:
    return package_root()


def clear_cache() -> None:
    global _CACHE
    _CACHE = None


def _read_bl_info_name_and_description(py_path: Path) -> tuple[str, str]:
    try:
        text = py_path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return '', ''
    import re
    name_match = re.search(r'"name"\s*:\s*"([^"]+)"', text)
    desc_match = re.search(r'"description"\s*:\s*"([^"]+)"', text)
    return (name_match.group(1).strip() if name_match else '', desc_match.group(1).strip() if desc_match else '')


def _iter_addon_dirs():
    root = tools_root()
    for item in TOOL_SPECS:
        dir_name = str(item.get('dir') or '').strip()
        if not dir_name:
            continue
        path = root / dir_name
        if not path.is_dir():
            continue
        if not (path / '__init__.py').exists():
            continue
        yield item, path


def build_specs(force: bool = False) -> list[dict[str, Any]]:
    global _CACHE
    if _CACHE is not None and not force:
        return list(_CACHE)

    results: list[dict[str, Any]] = []
    for item, addon_dir in _iter_addon_dirs():
        alias = str(item.get('dir') or '').strip()
        init_path = addon_dir / '__init__.py'
        spec: dict[str, Any] = {
            'alias': alias,
            'legacy_alias': str(item.get('legacy_alias') or ''),
            'outer_zip': str(item.get('outer_zip') or f'{alias}.zip'),
            'display_name': str(item.get('display_name') or alias),
            'suite': 'smart_render_suite',
            'suite_name': 'Smart Render',
            'load': True,
            'note': '',
            'duplicate_of': '',
            'superseded_by': '',
            'spaces': list(item.get('spaces') or []),
            'addon_dir': str(addon_dir),
            'src_dir': str(addon_dir),
            'source_root': '',
            'original_module_name': str(item.get('original_module_name') or ''),
            'import_mode': 'root_package',
            'init_relpath': '__init__.py',
            'search_root': '',
            'vendor_dir': str(addon_dir),
        }

        name, description = _read_bl_info_name_and_description(init_path)
        if name:
            spec['display_name'] = name
        spec['description'] = description or str(spec.get('display_name') or alias)
        results.append(spec)

    _CACHE = list(results)
    return list(results)
