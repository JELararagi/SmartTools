import numpy as np


from ...translation import iface_text


def get_blender_image_pixels(img):
    array = np.empty(len(img.pixels), dtype=np.single)
    img.pixels.foreach_get(array)
    array.resize(img.size[:] + (4,))  # TODO get number of channels
    return array


def set_blender_image_pixels(img, array):
    img.pixels.foreach_set(np.resize(array, img.size[0] * img.size[1] * 4))


def get_image_material(obj, image=None):
    """Find an image's actual owner; camera planes may have empty slots."""
    for slot in obj.material_slots:
        mat = slot.material
        if mat is None or mat.node_tree is None:
            continue
        for node in mat.node_tree.nodes:
            if node.type == 'TEX_IMAGE' and node.image is not None:
                if image is None or node.image == image:
                    return mat, node
    return None, None


def get_selected_images(objects):
    """Get list of images applied to selected objects"""
    images_selected = []
    valid_objects = []

    for obj in objects:
        for slot in obj.material_slots:
            mat = slot.material
            if mat is None or mat.node_tree is None:
                continue
            for node in mat.node_tree.nodes:
                if (
                    node.type == "TEX_IMAGE"
                    and node.image is not None
                    and node.image not in images_selected
                ):
                    images_selected.append(node.image)
                    valid_objects.append(obj)

    return valid_objects, images_selected



def create_image_buffer(op, size, images_to_process):
    new_image_buff = np.zeros(size + (4,), dtype=np.single)
    for image in images_to_process:
        # Alpha-composite each image from back to front
        image_buff = get_blender_image_pixels(image)
        # Associate alpha...
        if image.alpha_mode == "STRAIGHT":
            image_buff[:, :, :-1] *= image_buff[:, :, -1:]
        try:
            new_image_buff = new_image_buff * (1.0 - image_buff[:, :, -1:]) + image_buff
        except:
            op.report({'ERROR'}, iface_text("Could not group layers"))
            return {'CANCELLED'}
    return new_image_buff
