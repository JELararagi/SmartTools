import addon_utils
import bpy
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    StringProperty,
)

from ..translation import localize_inline, localize_pair
from .utils.properties import (
    get_distance,
    set_distance,
    update_distance,
    get_scale,
    set_scale,
    get_hide,
    set_hide,
    get_lock,
    set_lock,
    get_select,
    set_select,
)

try:
    module_name = addon_utils.modules().mapping[__package__]
    bl_info = addon_utils.module_bl_info(module_name)
    _version = tuple(bl_info.get("version") or (3, 0, 0))
except Exception:
    _version = (3, 0, 0)
BLENDER_VERSION = "{}.{}.{}".format(*_version)


def get_camera(obj):
    if obj is None:
        return None
    try:
        if getattr(obj, 'type', None) == "CAMERA":
            return obj
        parent = getattr(obj, 'parent', None)
        if parent is not None and getattr(parent, 'type', None) == "CAMERA":
            return parent
    except ReferenceError:
        return None
    except Exception:
        return None
    return None


def get_planes(obj, selected=False):
    cam = get_camera(obj)
    if cam is None:
        return []

    planes = []
    try:
        children = list(getattr(cam, 'children', []) or [])
    except ReferenceError:
        return []
    except Exception:
        return []
    for child in children:
        try:
            if "camera_plane" in child and "distance" in child["camera_plane"]:
                planes.append(child)
        except ReferenceError:
            continue
        except Exception:
            continue
    if selected:
        planes_selected = []
        for plane in planes:
            try:
                if plane.select_get():
                    planes_selected.append(plane)
            except ReferenceError:
                continue
            except Exception:
                continue
        if planes_selected:
            planes = planes_selected
    return planes


def _on_auto_load_maintenance_changed(_self, context):
    try:
        import importlib
        package = importlib.import_module(__package__)
        sync_load_handlers = getattr(package, 'sync_load_handlers', None)
        if callable(sync_load_handlers):
            sync_load_handlers(context=context)
    except Exception:
        pass


class CameraPlaneSettings(bpy.types.PropertyGroup):
    sort_type: EnumProperty(
        name="Sort Type",
        items=[
            ('ALPHABETICAL', "Alphabetical", "Alphabetical sort", 'SORTALPHA', 1),
            ('DISTANCE', "Distance", "Sort by distance to camera", 'DRIVER_DISTANCE', 2),
        ],
        default='DISTANCE',
    )
    show_selected: BoolProperty(
        name="Selected Only", description="Show selected planes only", default=False
    )
    filter: StringProperty(name="Plane Filter", maxlen=1024, options={'TEXTEDIT_UPDATE'})
    show_scale: bpy.props.BoolProperty(
        name="Show Scale", description="Show plane scale in the UI", default=False
    )
    show_opacity: BoolProperty(
        name="Show Opacity", description="Show plane opacity in the UI", default=False
    )
    auto_load_maintenance: BoolProperty(
        name=localize_pair("ファイル読込時の自動メンテナンス", "Auto Maintenance on File Load"),
        description=localize_pair(
            "Camera Plane のグループ再構築と旧データ確認は、Nパネル内の「メンテナンスを実行」ボタンで必要な時だけ手動実行します。この項目は旧設定との互換用で、ファイル読込時の自動ハンドラーは登録しません。",
            "Camera Plane group rebuilding and legacy checks now run only from the N-panel Run Maintenance button. This setting is kept for legacy compatibility and does not register file-load handlers.",
        ),
        default=False,
        update=_on_auto_load_maintenance_changed,
    )


class CameraPlaneProperties(bpy.types.PropertyGroup):
    distance: FloatProperty(
        name="Camera Plane Distance",
        description="Distance to the camera",
        subtype="DISTANCE",
        unit="LENGTH",
        step=10.0,
        precision=3,
        get=get_distance,
        set=set_distance,
        update=update_distance,
    )
    scale: FloatProperty(
        name="Camera Plane Scale",
        description="Extra scale applied after distance calculation",
        default=100.0,
        soft_max=500.0,
        min=0.0,
        subtype="PERCENTAGE",
        get=get_scale,
        set=set_scale,
    )
    select: BoolProperty(
        name="Select",
        description="Select plane",
        get=get_select,
        set=set_select,
    )
    hide: BoolProperty(
        name="Disable",
        description="Disable plane in both viewport and render",
        get=get_hide,
        set=set_hide,
    )
    lock: BoolProperty(
        name="Lock",
        description="Lock plane transforms",
        get=get_lock,
        set=set_lock,
    )
    show_group: BoolProperty(
        name="Show Group",
        description="Show settings for planes inside this group",
        default=False,
    )
    version: StringProperty(name="Version", default=BLENDER_VERSION)


def draw_runtime_settings(layout, context) -> None:
    wm = getattr(context, "window_manager", None)
    settings = getattr(wm, "camera_plane_settings", None) if wm is not None else None
    if settings is None:
        layout.label(text=localize_pair("Camera Plane 設定はまだ利用できません。", "Camera Plane settings are not available yet."), icon="ERROR", translate=False)
        return
    box = layout.box()
    box.label(text=localize_pair("ファイル読込メンテナンス", "File Load Maintenance"), icon="PREFERENCES")
    box.operator("camera.run_maintenance", text=localize_pair("メンテナンスを実行", "Run Maintenance"), icon="FILE_REFRESH")
