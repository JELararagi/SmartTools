import os

import bpy
from bpy.props import BoolProperty, CollectionProperty, FloatProperty, StringProperty
from bpy_extras.io_utils import ImportHelper

from ..translation import iface_text, localize_pair

from .properties import (
    get_camera,
    get_planes,
)
from .utils.drivers import (
    create_drivers,
)
from .utils.image import (
    create_image_buffer,
    get_image_material,
    get_selected_images,
    set_blender_image_pixels,
)
from .utils.misc import natural_sort_key
from .utils.nodes import (
    add_opacity_to_material,
    ensure_fix_node_group,
    fix_material_uvs,
)


def object_poll(cls, obj):
    select_poll_error = "Select a camera or its plane children"

    if obj is None:
        cls.poll_message_set(iface_text(select_poll_error))
        return None

    cam = get_camera(obj)
    if cam is None:
        cls.poll_message_set(iface_text(select_poll_error))
        return None
    return cam


def selected_number_poll(cls, cam, minimum=2):
    selected_children = []
    try:
        children = list(getattr(cam, 'children', []) or [])
    except ReferenceError:
        children = []
    except Exception:
        children = []
    for child in children:
        try:
            if child.select_get() and "camera_plane" in child and "distance" in child["camera_plane"]:
                selected_children.append(child)
        except ReferenceError:
            continue
        except Exception:
            continue
    if len(selected_children) < minimum:
        cls.poll_message_set(iface_text(f"Select at least {minimum} image planes"))
        return False
    return True


class CAMERA_OT_Camera_Plane_Add_Opacity(bpy.types.Operator):
    """Add opacity setting to a plane, if it was not added before"""
    bl_idname = "camera.add_plane_opacity"
    bl_label = "Add Plane Opacity"
    bl_options = {'UNDO'}

    plane: StringProperty()

    def execute(self, context):
        plane = bpy.data.objects.get(self.plane)
        if plane is None:
            self.report({'WARNING'}, iface_text("Image plane was not found."))
            return {'CANCELLED'}
        material = plane.active_material
        if material is None:
            return {'CANCELLED'}
        add_opacity_to_material(material)
        if "Opacity Multiplier" not in material.node_tree.nodes:
            self.report({'WARNING'}, iface_text("Could not add opacity: the material has no image texture with a connected alpha."))
            return {'CANCELLED'}
        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Group(bpy.types.Operator):
    """Group selected plane layers into one"""
    bl_idname = "camera.group_selected_planes"
    bl_label = "Group Selected Planes"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)

        cam = object_poll(cls, obj)
        if cam is None:
            return False

        if not selected_number_poll(cls, cam):
            return False

        return True

    def execute(self, context):
        objects = context.selected_objects
        objects = [o for o in objects if "camera_plane" in o and "distance" in o["camera_plane"] and "originals" not in o]
        objects.sort(key=lambda o: o.camera_plane.distance, reverse=True)

        objects, images_to_process = get_selected_images(objects)
        if not images_to_process:
            self.report({'WARNING'}, localize_pair(
                "選択した平面に画像テクスチャがありません。",
                "Selected planes have no image textures."))
            return {'CANCELLED'}
        first_obj = objects[-1]
        first_image = images_to_process[-1]
        first_mat, first_node = get_image_material(first_obj, first_image)
        material_index = next(i for i, slot in enumerate(first_obj.material_slots)
                              if slot.material == first_mat)

        img_sizes = {image.size[:] for image in images_to_process}
        if len(img_sizes) >= 2:
            self.report({'ERROR'}, iface_text("Could not group layers, are they the same size?"))
            return {'CANCELLED'}

        # Assume all images have the same size!
        size = first_image.size[:]

        new_image = bpy.data.images.new("grouped." + first_image.name, size[0], size[1], alpha=True)

        filepath, ext = os.path.splitext(first_image.filepath)
        new_image.filepath = filepath + ".grouped" + ext

        # Create and link object for new image
        new_obj = first_obj.copy()
        new_obj.name = "grouped." + first_obj.name
        new_mesh = first_obj.data.copy()
        new_mesh.name = "grouped." + first_obj.name
        new_mat = first_mat.copy()
        new_mat.name = "grouped." + first_obj.name
        new_obj.data = new_mesh
        new_obj.material_slots[material_index].material = new_mat
        for coll in first_obj.users_collection:
            coll.objects.link(new_obj)

        # Create and assign image data
        new_image_buff = create_image_buffer(self, size, images_to_process)
        if type(new_image_buff) is set:
            # Error
            return new_image_buff
        set_blender_image_pixels(new_image, new_image_buff)
        image_node = new_mat.node_tree.nodes[first_node.name]
        image_node.image = new_image
        new_image.save()

        # Keep track of data in objects
        originals = []
        for obj in objects:
            obj["grouped"] = new_obj
            originals.append(obj)
            for coll in obj.users_collection:
                coll.objects.unlink(obj)
            obj.use_fake_user = True
        new_obj["originals"] = originals

        context.view_layer.objects.active = new_obj

        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Update_Groups(bpy.types.Operator):
    """Recreate layer groups from individual layers if the file could not be found"""
    bl_idname = "camera.update_plane_groups"
    bl_label = "Update Plane Groups"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)

        cam = object_poll(cls, obj)
        if cam is None:
            return False

        for child in cam.children:
            if "camera_plane" in child and "distance" in child["camera_plane"] and "originals" in child:
                _mat, image_node = get_image_material(child)
                image = image_node.image if image_node is not None else None
                if image is not None and not image.has_data:
                    return True
        return False

    def execute(self, context):
        planes = get_planes(context.active_object)
        grouped_planes = [p for p in planes if "originals" in p]

        for grouped_plane in grouped_planes:
            originals = grouped_plane["originals"]

            _mat, image_node = get_image_material(grouped_plane)
            image = image_node.image if image_node is not None else None
            if image is None or image.has_data:
                continue

            objects, images_to_process = get_selected_images(originals)
            if not images_to_process:
                self.report({'WARNING'}, localize_pair(
                    "元の平面に画像テクスチャがありません。",
                    "Original planes have no image textures."))
                continue
            first_image = images_to_process[-1]

            img_sizes = {image.size[:] for image in images_to_process}
            if len(img_sizes) >= 2:
                self.report({'ERROR'}, iface_text("Could not group layers, are they the same size?"))
                return {'CANCELLED'}

            # Assume all images have the same size!
            size = first_image.size[:]

            # Create and assign image data
            new_image = bpy.data.images.new(image.name, size[0], size[1], alpha=True)
            new_image.name = image.name  # force rename
            new_image.filepath = image.filepath
            new_image_buff = create_image_buffer(self, size, images_to_process)
            if type(new_image_buff) is set:
                # Error
                continue

            set_blender_image_pixels(new_image, new_image_buff)
            new_image.save()
            image_node.image = new_image

        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Ungroup(bpy.types.Operator):
    """Extract the layers from this group back to individual planes"""
    bl_idname = "camera.ungroup_planes"
    bl_label = "Ungroup Planes"
    bl_options = {'UNDO'}

    group: StringProperty(options={'HIDDEN'})
    keep_original_distance: BoolProperty(
        name="Keep Original Distance",
        description="Use distance from before grouping, or keep ungrouped planes close together",
    )
    offset: FloatProperty(
        name="Offset",
        default=0.01,
        subtype='DISTANCE',
        unit='LENGTH',
        description="Offset between ungrouped planes if not using original distance",
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        for obj in bpy.context.view_layer.objects:
            obj.select_set(False)

        obj = bpy.data.objects[self.group]
        for i, orig in enumerate(sorted(obj["originals"], key=lambda o: o.camera_plane.distance)):
            if not self.keep_original_distance:
                # Recalculate plane distance from group
                orig.camera_plane.distance = obj.camera_plane.distance + i * self.offset
                # Delete drivers if they were deleted in the group and copy props
                if obj.animation_data is not None:
                    for prop in {"location", "scale"}:  # TODO handle rotation?
                        for index in range(3):
                            grp_driver = obj.animation_data.drivers.find(prop, index=index)
                            if grp_driver is None:
                                orig_driver = orig.animation_data.drivers.find(prop, index=index)
                                if orig_driver is not None:
                                    orig.animation_data.drivers.remove(orig_driver)
                            getattr(orig, prop)[index] = getattr(obj, prop)[index]
                            if prop == "location" and index == 2:
                                getattr(orig, prop)[index] -= i * self.offset
                        # TODO handle animation...
            del orig["grouped"]
        for coll in obj.users_collection:
            for orig in obj["originals"]:
                coll.objects.link(orig)
                orig.select_set(True)
            coll.objects.unlink(obj)

        context.view_layer.objects.active = orig
        bpy.data.objects.remove(obj)
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "keep_original_distance")
        row = layout.row()
        row.active = not self.keep_original_distance
        row.prop(self, "offset")


class CAMERA_OT_Camera_Plane(bpy.types.Operator, ImportHelper):
    """Import a camera plane"""
    bl_idname = "camera.import_camera_plane"
    bl_label = "Import Camera Plane"
    bl_options = {'UNDO'}

    # File props
    files: CollectionProperty(
        type=bpy.types.OperatorFileListElement, options={'HIDDEN', 'SKIP_SAVE'}
    )
    directory: StringProperty(maxlen=1024, subtype='FILE_PATH', options={'HIDDEN', 'SKIP_SAVE'})

    filter_image: BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})
    filter_movie: BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})
    filter_folder: BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})

    scale: FloatProperty(
        name="Scale",
        description="Extra scale applied after calculation",
        default=100.0,
        soft_min=0.0,
        soft_max=500.0,
        min=0.0,
        subtype='PERCENTAGE',
    )
    distance: FloatProperty(
        name="Distance",
        description="Distance from the camera to the farthest plane",
        default=25.0,
        soft_max=1000.0,
        min=0.0,
        step=10.0,
        subtype='DISTANCE',
        unit='LENGTH',
    )
    step: FloatProperty(
        name="Step",
        description="Distance between planes",
        default=0.1,
        soft_max=50.0,
        min=0.0,
        step=10.0,
        subtype='DISTANCE',
        unit='LENGTH',
    )
    reverse_order: BoolProperty(
        name="Reverse Order",
        description="Reverse Order sorting order",
        default=False,
    )

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)

        cam = object_poll(cls, obj)
        if cam is None:
            return False

        return True

    def execute(self, context):
        # Selection Camera
        cam = get_camera(context.active_object)

        files = [os.path.basename(f.name) for f in self.files]
        files.sort(key=natural_sort_key)

        if not self.reverse_order:
            files.reverse()

        imported_planes = []

        for i, f in enumerate(files):
            bpy.ops.image.import_as_mesh_planes(
                files=[{"name": f}],
                directory=self.directory,
                use_transparency=True,
                shader='SHADELESS',
                overwrite_material=False,
            )
            plane = context.active_object
            imported_planes.append(plane)

            # Move plane to camera's collections
            for coll in plane.users_collection:
                coll.objects.unlink(plane)
            for coll in cam.users_collection:
                coll.objects.link(plane)

            # Scale factor: Import images addon imports
            # images with a height of 1
            # this scales it back to a width of 1
            scale_factor = plane.dimensions[0]
            for v in plane.data.vertices:
                v.co /= scale_factor
            plane.parent = cam
            plane.show_wire = True
            plane.matrix_world = cam.matrix_world
            plane.lock_location = (True,) * 3
            plane.lock_rotation = (True,) * 3
            plane.lock_rotation_w = True
            plane.lock_scale = (True,) * 3

            # Multiple planes spacing
            plane.camera_plane.distance = self.distance - i * self.step
            plane.camera_plane.scale = self.scale

            # DRIVERS
            create_drivers(plane=plane, cam=cam)

            # Alpha in material
            add_opacity_to_material(plane.active_material)

        for plane in imported_planes:
            plane.select_set(True)
        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Layers(bpy.types.Operator):
    """Create one view layer per image, to render them separately"""
    bl_idname = "camera.set_up_plane_layers"
    bl_label = "Set Up Plane Layers"
    bl_options = {'UNDO'}

    def execute(self, context):
        scene = context.scene
        planes = get_planes(context.active_object, selected=False)

        # Create collections
        for obj in planes:
            if obj.name not in bpy.data.collections:
                coll = bpy.data.collections.new(obj.name)
                coll.objects.link(obj)
                scene.collection.children.link(coll)

        # Create view layers
        for obj in planes:
            layer = scene.view_layers.get(obj.name)
            if layer is None:
                layer = scene.view_layers.new(obj.name)
            for child_coll in layer.layer_collection.children:
                child_coll.exclude = child_coll.name != obj.name
        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Space(bpy.types.Operator):
    """Space selected planes evenly from closest to farthest"""
    bl_idname = "camera.space_planes_evenly"
    bl_label = "Space Planes Evenly"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)

        cam = object_poll(cls, obj)
        if cam is None:
            return False

        if not selected_number_poll(cls, cam, minimum=3):
            return False

        return True

    def execute(self, context):
        planes = get_planes(context.active_object, selected=True)
        planes.sort(key=lambda p: p.camera_plane.distance)

        low = planes[0].camera_plane.distance
        high = planes[-1].camera_plane.distance
        current = low

        for plane in planes:
            plane.camera_plane.distance = current
            current += (high - low) / max(len(planes) - 1, 1)
            for driver in plane.animation_data.drivers:
                driver.update()

        # Force viewport update
        plane.location.z = plane.location.z
        plane.update_tag(refresh={'OBJECT'})
        context.view_layer.update()

        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Reverse(bpy.types.Operator):
    """Reverse Order the order of the selected planes"""
    bl_idname = "camera.reverse_order"
    bl_label = "Reverse Order"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)

        cam = object_poll(cls, obj)
        if cam is None:
            return False

        if not selected_number_poll(cls, cam):
            return False

        return True

    def execute(self, context):
        planes = get_planes(context.active_object, selected=True)
        planes.sort(key=lambda p: p.camera_plane.distance)
        planes_dist = [p.camera_plane.distance for p in planes]
        planes_dist.reverse()

        for plane, plane_dist in zip(planes, planes_dist):
            plane.camera_plane.distance = plane_dist
            # current += (high - low) / max(len(planes) - 1, 1)
            for driver in plane.animation_data.drivers:
                driver.update()
        plane.location.z = plane.location.z
        plane.update_tag(refresh={'OBJECT'})
        context.view_layer.update()

        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Apply(bpy.types.Operator):
    """Apply transformation on selected planes"""
    bl_idname = "camera.apply_camera_plane"
    bl_label = "Apply Camera Plane"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        cam = object_poll(cls, obj)
        if cam is None:
            return False
        if not selected_number_poll(cls, cam, minimum=1):
            return False
        return True

    def execute(self, context):
        for group_plane in get_planes(context.active_object, selected=True):
            if "originals" not in group_plane:
                continue
            bpy.ops.camera.ungroup_planes(group=group_plane.name)

        for plane in get_planes(context.active_object, selected=True):
            # Remove drivers
            for f_curve in plane.animation_data.drivers:
                if f_curve.data_path in {"delta_location", "delta_scale"}:
                    plane.driver_remove(f_curve.data_path, f_curve.array_index)

            plane.lock_location = (False,) * 3
            plane.lock_rotation = (False,) * 3
            plane.lock_scale = (False,) * 3
            plane.lock_rotation_w = False

            del plane["camera_plane"]

        context.view_layer.objects.active = get_camera(context.active_object)

        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Run_Load_Maintenance(bpy.types.Operator):
    """Run Camera Plane maintenance once on demand."""
    bl_idname = "camera.run_maintenance"
    bl_label = "Run Maintenance"
    bl_description = localize_pair(
        "Camera Plane の読込時メンテナンスを手動で1回だけ実行します。自動メンテナンスを無効にしている時に、必要な場面だけグループ再構築や旧データ移行を行うための実行ボタンです。",
        "Run Camera Plane file-load maintenance once on demand. Use this when automatic maintenance is disabled and you want to rebuild groups or migrate older Camera Plane data only when needed.",
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        from .handlers import camera_plane_group_handler, camera_plane_versioning_handler

        try:
            camera_plane_group_handler(None, force=True)
        except Exception as exc:
            self.report({'WARNING'}, iface_text(f"Group rebuild skipped: {exc}"))

        try:
            camera_plane_versioning_handler(None, force=True)
        except Exception as exc:
            self.report({'WARNING'}, iface_text(f"Legacy version check skipped: {exc}"))

        self.report({'INFO'}, iface_text("Camera Plane maintenance finished."))
        return {'FINISHED'}


class CAMERA_OT_Camera_Mapping(bpy.types.Operator):
    """Convert meshes to a setup of camera mapping."""
    bl_idname = "object.convert_to_camera_mapping"
    bl_label = "Convert to Camera Mapping"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        for obj in getattr(context, 'selected_objects', []) or []:
            try:
                if obj.type == 'MESH':
                    return True
            except ReferenceError:
                continue
            except Exception:
                continue

        cls.poll_message_set(iface_text("No mesh object found in selection"))
        return False

    def execute(self, context):
        scene = context.scene
        camera = None

        for obj in context.selected_objects:
            if obj.type == 'CAMERA':
                camera = obj
                break

        if camera is None:
            self.report({'INFO'}, iface_text("No camera found to use as projector. Creating a new one."))
            camera_data = bpy.data.cameras.new("MappingCamera")
            camera = bpy.data.objects.new("MappingCamera", camera_data)
            scene.collection.objects.link(camera)

        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue

            # Get the UVProject modifier, create a new one if not found
            uvproject_modifier = next(
                (m for m in obj.modifiers if m.type == 'UV_PROJECT'), None
            )
            if uvproject_modifier is None:
                uvproject_modifier = obj.modifiers.new(
                    name="Camera Mapping UVProject", type='UV_PROJECT'
                )

                uv_map = (
                    obj.data.uv_layers[0]
                    if len(obj.data.uv_layers) > 0
                    else obj.data.uv_layers.new()
                )

                # Get object's image resolution, fallback to scene resolution.
                _objects, images = get_selected_images((obj,))
                if images:
                    resolution_x, resolution_y = images[0].size
                else:
                    resolution_x, resolution_y = (scene.render.resolution_x, scene.render.resolution_y)

                # Modifier settings
                uvproject_modifier.uv_layer = uv_map.name
                uvproject_modifier.projectors[0].object = camera
                uvproject_modifier.aspect_x = resolution_x
                uvproject_modifier.aspect_y = resolution_y

            # Get the UVProject modifier, create a new one if not found
            fix_node_group = ensure_fix_node_group()
            fix_camera_mapping_modifier = next(
                (m for m in obj.modifiers if m.type == 'NODES' and m.node_group == fix_node_group),
                None,
            )

            if fix_camera_mapping_modifier is None:
                uv_map = (
                    obj.data.uv_layers[0]
                    if len(obj.data.uv_layers) > 0
                    else obj.data.uv_layers.new()
                )

                fix_camera_mapping_modifier = obj.modifiers.new(
                    name="Camera Mapping Fix UVs", type='NODES'
                )

                # Modifier settings
                fix_camera_mapping_modifier.node_group = fix_node_group
                fix_camera_mapping_modifier.use_pin_to_last = True

                # Assign camera
                modifier_identifier_camera = fix_node_group.interface.items_tree["Camera"].identifier
                fix_camera_mapping_modifier[modifier_identifier_camera] = camera

                # Assign UV layer
                modifier_identifier_uv = next(
                    item.identifier
                    for item in fix_node_group.interface.items_tree
                    if (item.name == "UV"
                        and item.in_out == 'INPUT')
                )
                modifier_identifier_uv += "_attribute_name"
                fix_camera_mapping_modifier[modifier_identifier_uv] = uv_map.name

                # Modify UVs in materials if found (divide by the Z attribute)
                for slot in obj.material_slots:
                    mat = slot.material
                    if mat.node_tree is None:
                        continue
                    fix_material_uvs(mat)

        return {'FINISHED'}
