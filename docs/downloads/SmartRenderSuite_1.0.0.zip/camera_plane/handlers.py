

def _smarttools_console_output(*_args, **_kwargs):
    return None
import bpy
from bpy.app.handlers import persistent

from .utils.drivers import create_drivers


def _maintenance_requested() -> bool:
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        settings = getattr(wm, 'camera_plane_settings', None) if wm is not None else None
        return bool(getattr(settings, 'auto_load_maintenance', False))
    except Exception:
        return False


def _legacy_camera_plane_candidates():
    try:
        objects = tuple(getattr(bpy.data, 'objects', ()) or ())
    except Exception:
        return tuple()
    candidates = []
    for obj in objects:
        try:
            parent = getattr(obj, 'parent', None)
            if (
                parent is not None
                and getattr(parent, 'type', None) == 'CAMERA'
                and "camera_plane_distance" in obj
                and "camera_plane_scale" in obj
            ):
                candidates.append(obj)
        except ReferenceError:
            continue
        except Exception:
            continue
    return tuple(candidates)


@persistent
def camera_plane_group_handler(_self, *, force: bool = False):
    """Regenerate missing groups on file load when explicitly enabled."""
    if not force and not _maintenance_requested():
        return
    try:
        if bpy.ops.camera.update_plane_groups.poll():
            bpy.ops.camera.update_plane_groups()
    except Exception:
        pass


@persistent
def camera_plane_versioning_handler(_self, *, force: bool = False):
    """Attach new Camera Plane metadata to legacy planes without resetting transforms.

    Older builds migrated drivers by removing location/scale drivers and then
    assigning obj.location=(0, 0, 0) and scale=(1, 1, ...). That can look like an
    object transform reset immediately after saving and reopening a scene. This
    handler now performs only a non-destructive bridge migration: it copies the
    legacy distance/scale values into the new custom-property namespace so the
    UI can read them, while leaving all existing transforms and drivers intact.
    The CameraPlaneProperties setters keep the legacy driver properties in sync
    when the user edits distance/scale later.
    """
    if not force and not _maintenance_requested():
        return

    for obj in _legacy_camera_plane_candidates():
        try:
            if "camera_plane" not in obj or not isinstance(obj.get("camera_plane"), dict):
                obj["camera_plane"] = {}
            data = obj["camera_plane"]
            if "distance" not in data:
                data["distance"] = obj["camera_plane_distance"]
            if "scale" not in data:
                data["scale"] = obj["camera_plane_scale"]
            # Do not remove legacy properties; old drivers still reference them.
            _smarttools_console_output(f"Camera Plane: Linked legacy data without resetting transform: {obj.name}")
        except ReferenceError:
            continue
        except Exception:
            continue
