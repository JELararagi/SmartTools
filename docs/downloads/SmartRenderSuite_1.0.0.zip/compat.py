from __future__ import annotations

import os
import re
import shlex
import shutil
from datetime import datetime
from typing import Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

import bpy

from .meta import ADDON_ID
from .translation import localize_inline
from .selectors import resolve_selector_names

LOG_LIMIT = 300
SEVERITY_RANK = {"INFO": 0, "WARNING": 1, "ERROR": 2}
IMAGE_FORMAT_EXTENSIONS = {
    "BMP": "bmp",
    "IRIS": "rgb",
    "PNG": "png",
    "JPEG": "jpg",
    "JPEG2000": "jp2",
    "TARGA": "tga",
    "TARGA_RAW": "tga",
    "CINEON": "cin",
    "DPX": "dpx",
    "OPEN_EXR": "exr",
    "OPEN_EXR_MULTILAYER": "exr",
    "HDR": "hdr",
    "TIFF": "tif",
    "AVI_JPEG": "avi",
    "AVI_RAW": "avi",
    "FFMPEG": "mp4",
    "WEBP": "webp",
}
ENGINE_MODE_MAP = {
    "CYCLES": ("CYCLES",),
    "EEVEE": ("BLENDER_EEVEE", "BLENDER_EEVEE_NEXT"),
    "WORKBENCH": ("BLENDER_WORKBENCH",),
}



def now_local() -> datetime:
    return datetime.now().astimezone()



def collection_clear(collection) -> None:
    while len(collection) > 0:
        collection.remove(len(collection) - 1)



def safe_name(text: str) -> str:
    value = (text or "").strip()
    if not value:
        return "untitled"
    value = re.sub(r'[<>:"/\\|?*\x00-\x1F]+', "_", value)
    value = re.sub(r"\s+", "_", value)
    value = re.sub(r"_+", "_", value)
    return value.strip("._ ") or "untitled"


LEGACY_DEFAULT_MANIFEST_PATH = f"//{ADDON_ID}_manifest.json"



def _normalised_extension_package_id(value: object = "") -> str:
    """Return the root Blender Extension id for any module/package name.

    Blender 5.x loads extensions as ``bl_ext.user_default.<id>``.  Using the
    first dotted component would incorrectly create ``user_default/bl_ext``.
    All bundled modules in this suite share the manifest id as their writable
    user_default root.
    """
    text = str(value or "").strip()
    if not text:
        return ""
    parts = [part for part in text.split(".") if part]
    addon_id = str(ADDON_ID or "smart_render_suite").strip() or "smart_render_suite"
    if "user_default" in parts:
        index = parts.index("user_default")
        if index + 1 < len(parts):
            return parts[index + 1] or addon_id
    if text == addon_id or text.startswith(addon_id + ".") or addon_id in parts:
        return addon_id
    if text == "Smart_Render_Suite" or text.startswith("Smart_Render_Suite."):
        return addon_id
    if text.startswith("bl_ext."):
        return addon_id
    if "." in text:
        return addon_id
    return text



def extension_package_id_candidates() -> Tuple[str, ...]:
    candidates: List[str] = []
    for raw in (ADDON_ID, __package__, __name__):
        candidate = _normalised_extension_package_id(raw)
        if candidate and candidate not in candidates:
            candidates.append(candidate)
    return tuple(candidates) or ("smart_render_suite",)



def extension_package_id() -> str:
    return extension_package_id_candidates()[0]



def extension_user_root(create: bool = False) -> str:
    """Return Smart Render's writable CONFIG root.

    The compatibility name is retained for bundled tools, but it must never
    resolve to the installed Extension package.
    """
    try:
        from . import storage as _srs_storage
        return str(_srs_storage.extension_user_root(create=bool(create)))
    except Exception:
        version = "5.1"
        try:
            app_version = getattr(getattr(bpy, "app", None), "version", None)
            if app_version and len(app_version) >= 2:
                version = f"{int(app_version[0])}.{int(app_version[1])}"
        except Exception:
            pass
        if os.name == "nt":
            roaming = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Roaming")
            config_root = os.path.join(roaming, "Blender Foundation", "Blender", version, "config")
        else:
            config_root = os.path.join(os.path.expanduser("~"), ".config", "blender", version, "config")
        fallback = os.path.join(config_root, "Smart_Render_Suite")
        if create:
            os.makedirs(fallback, exist_ok=True)
        return fallback



def default_output_root(create: bool = False) -> str:
    path = os.path.join(extension_user_root(create=create), "renders")
    if create:
        os.makedirs(path, exist_ok=True)
    return path


def default_manifest_path(create: bool = False) -> str:
    path = os.path.join(extension_user_root(create=create), "exports", f"{ADDON_ID}_manifest.json")
    if create:
        os.makedirs(os.path.dirname(path), exist_ok=True)
    return path



def resolve_manifest_path(path_value: str, *, create_parent: bool = False) -> str:
    raw_value = str(path_value or "").strip()
    if raw_value in {"", LEGACY_DEFAULT_MANIFEST_PATH}:
        resolved = default_manifest_path(create=create_parent)
    else:
        resolved = abspath(raw_value)
        if create_parent:
            ensure_directory(os.path.dirname(resolved))
    return resolved



def parse_name_list(text: str) -> List[str]:
    raw = re.split(r"[\n,;]+", str(text or ""))
    seen = set()
    names: List[str] = []
    for item in raw:
        name = item.strip()
        if name and name not in seen:
            seen.add(name)
            names.append(name)
    return names



def set_image_file_format(image_settings, file_format) -> bool:
    """Each media type accepts only its own formats, so the media type has to change first."""
    media_type = {"OPEN_EXR_MULTILAYER": "MULTI_LAYER_IMAGE", "FFMPEG": "VIDEO"}.get(str(file_format), "IMAGE")
    safe_set_attr(image_settings, "media_type", media_type)
    return safe_set_attr(image_settings, "file_format", file_format)


def safe_set_attr(target, attr_name: str, value) -> bool:
    if target is None or not hasattr(target, attr_name):
        return False
    try:
        setattr(target, attr_name, value)
        return True
    except Exception:
        return False



def safe_get_attr(target, attr_name: str, default=None):
    try:
        return getattr(target, attr_name, default)
    except Exception:
        return default



def enum_keys(owner, prop_name: str) -> List[str]:
    try:
        prop = owner.bl_rna.properties[prop_name]
        return [item.identifier for item in prop.enum_items]
    except Exception:
        return []



# RenderSettings.engine is a dynamic enum: enum_items only lists its static default item.
BUILTIN_ENGINE_IDENTIFIERS = ("BLENDER_EEVEE", "BLENDER_WORKBENCH")


def available_engine_identifiers(scene) -> List[str]:
    identifiers = list(BUILTIN_ENGINE_IDENTIFIERS)
    for engine_class in bpy.types.RenderEngine.__subclasses__():
        # A disabled add-on's class stays listed here after unregistering; only registered ones own bl_rna.
        identifier = getattr(engine_class, "bl_idname", "") if "bl_rna" in vars(engine_class) else ""
        if identifier and identifier not in identifiers:
            identifiers.append(identifier)
    return identifiers



def resolve_engine_identifier(scene, mode: str) -> Optional[str]:
    if mode in {"", None, "KEEP", "SCENE"}:
        return None
    available = set(available_engine_identifiers(scene))
    for candidate in ENGINE_MODE_MAP.get(mode, (mode,)):
        if candidate in available:
            return candidate
    return None



def engine_mode_from_identifier(identifier: str) -> str:
    identifier = str(identifier or "")
    if identifier == "CYCLES":
        return "CYCLES"
    if identifier in {"BLENDER_EEVEE", "BLENDER_EEVEE_NEXT"}:
        return "EEVEE"
    if identifier == "BLENDER_WORKBENCH":
        return "WORKBENCH"
    return "KEEP"



def image_format_extension(file_format: str) -> str:
    return IMAGE_FORMAT_EXTENSIONS.get(str(file_format or "PNG"), "img")



def ensure_directory(path: str) -> None:
    if path:
        os.makedirs(path, exist_ok=True)



def can_write_directory(path: str, create: bool = False) -> bool:
    directory = abspath(path)
    try:
        if not directory:
            return False
        probe_dir = directory if os.path.isdir(directory) else os.path.dirname(directory)
        if not probe_dir:
            probe_dir = directory
        while probe_dir and not os.path.isdir(probe_dir):
            parent = os.path.dirname(probe_dir)
            if parent == probe_dir:
                break
            probe_dir = parent
        if not probe_dir or not os.path.isdir(probe_dir):
            return False
        probe = os.path.join(probe_dir, f".{ADDON_ID}_write_test.tmp")
        with open(probe, "w", encoding="utf-8") as handle:
            handle.write("ok")
        os.remove(probe)
        return True
    except Exception:
        return False



def command_exists(command: str) -> bool:
    command_text = str(command or "").strip()
    if not command_text:
        return False
    try:
        parts = shlex.split(command_text, posix=os.name != 'nt')
    except Exception:
        parts = [command_text]
    executable = parts[0] if parts else command_text
    if os.path.isabs(executable):
        return os.path.isfile(executable) and os.access(executable, os.X_OK)
    return shutil.which(executable) is not None



def abspath(path: str) -> str:
    try:
        return bpy.path.abspath(path)
    except Exception:
        return path



def blender_version() -> Tuple[int, int, int]:
    try:
        version = tuple(int(value) for value in getattr(bpy.app, "version", (0, 0, 0))[:3])
        if len(version) == 3:
            return version
    except Exception:
        pass
    return (0, 0, 0)



def blender_5_or_newer() -> bool:
    return blender_version() >= (5, 0, 0)



def compositor_node_tree(scene):
    tree = safe_get_attr(scene, "compositing_node_group")
    if tree is not None:
        return tree
    return safe_get_attr(scene, "node_tree")



def scene_has_compositor_nodes(scene) -> bool:
    tree = compositor_node_tree(scene)
    if tree is None:
        return False
    try:
        return bool(list(getattr(tree, "nodes", []) or []))
    except Exception:
        return False



def scene_has_file_output_nodes(scene, srr_only: bool = False) -> bool:
    tree = compositor_node_tree(scene)
    if tree is None:
        return False
    for node in getattr(tree, "nodes", []) or []:
        try:
            node_name = str(getattr(node, "name", "") or "")
            node_type = str(getattr(node, "type", "") or "")
            bl_idname = str(getattr(node, "bl_idname", "") or "")
            is_file_output = bl_idname == "CompositorNodeOutputFile" or node_type == "OUTPUT_FILE"
            if not is_file_output:
                continue
            if srr_only and not node_name.startswith("SRR_FileOutput::"):
                continue
            return True
        except Exception:
            continue
    return False



def effective_queue_compositing_mode(scene, requested_mode: str = "AUTO") -> str:
    settings = getattr(scene, "srr_settings", None)
    if bool(settings is not None and getattr(settings, "render_elements_enabled", False)):
        return "COMPOSITOR"

    mode = str(requested_mode or "AUTO").upper()
    if mode in {"DIRECT", "COMPOSITOR"}:
        return mode

    render = getattr(scene, "render", None)
    use_compositing = bool(getattr(render, "use_compositing", False))
    has_file_outputs = scene_has_file_output_nodes(scene)

    if blender_5_or_newer():
        return "COMPOSITOR" if (has_file_outputs or use_compositing) else "DIRECT"

    legacy_use_nodes = bool(getattr(scene, "use_nodes", False))
    has_tree_nodes = scene_has_compositor_nodes(scene)
    return "COMPOSITOR" if (has_file_outputs or use_compositing or (legacy_use_nodes and has_tree_nodes)) else "DIRECT"



def ensure_compositor_node_tree(scene, name_hint: str = "SRR_Compositor"):
    tree = compositor_node_tree(scene)
    if tree is not None:
        return tree

    if hasattr(scene, "compositing_node_group"):
        try:
            group_name = safe_name(f"{getattr(scene, 'name', '')}_{name_hint}")
            tree = bpy.data.node_groups.new(name=group_name, type="CompositorNodeTree")
            safe_set_attr(scene, "compositing_node_group", tree)
            return tree
        except Exception:
            pass

    safe_set_attr(scene, "use_nodes", True)
    tree = safe_get_attr(scene, "node_tree")
    if tree is not None:
        return tree

    if hasattr(bpy.data, "node_groups") and hasattr(scene, "compositing_node_group"):
        try:
            tree = bpy.data.node_groups.new(name=safe_name(name_hint), type="CompositorNodeTree")
            safe_set_attr(scene, "compositing_node_group", tree)
            return tree
        except Exception:
            pass
    return None


FILE_OUTPUT_PARAMETER_SOCKET_KEYS = {
    "directory",
    "dirname",
    "base_path",
    "path_base",
    "file_name",
    "filename",
}
SRR_FILE_OUTPUT_BASE_SUBPATH_KEY = "srr_base_subpath"



def normalized_path_fragment(value: str, fallback: str = "pass") -> str:
    text = str(value or "").replace("\\", "/").strip()
    while text.startswith("/"):
        text = text[1:]
    while text.startswith("./"):
        text = text[2:]
    if not text or text in {".", ".."}:
        text = fallback or "pass"
    stem, ext = os.path.splitext(text)
    if stem and ext:
        text = stem
    text = os.path.normpath(text).replace("\\", "/")
    if text in {"", ".", ".."}:
        return fallback or "pass"
    return text



def file_output_item_label(item, fallback: str = "pass") -> str:
    name = str(getattr(item, "name", "") or fallback or "pass")
    return safe_name(re.sub(r"_?#+$", "", name)) or (fallback or "pass")



def _stored_file_output_base_subpath(item) -> str:
    try:
        if item is not None and SRR_FILE_OUTPUT_BASE_SUBPATH_KEY in item:
            return str(item[SRR_FILE_OUTPUT_BASE_SUBPATH_KEY] or "")
    except Exception:
        pass
    return ""



def remember_file_output_item_base_subpath(item, subpath: str, fallback: str = "pass") -> str:
    normalized = normalized_path_fragment(subpath, fallback=fallback)
    try:
        if item is not None:
            item[SRR_FILE_OUTPUT_BASE_SUBPATH_KEY] = normalized
    except Exception:
        pass
    return normalized



def file_output_item_base_subpath(item, fallback: str = "pass") -> str:
    stored = _stored_file_output_base_subpath(item)
    if stored.strip():
        return normalized_path_fragment(stored, fallback=file_output_item_label(item, fallback))
    raw_value = str(getattr(item, "file_name", "") or getattr(item, "path", "") or "")
    if raw_value.strip():
        return normalized_path_fragment(raw_value, fallback=file_output_item_label(item, fallback))
    return normalized_path_fragment(file_output_item_label(item, fallback), fallback=file_output_item_label(item, fallback))



def file_output_frame_subpath_from_base(
    base_subpath: str,
    frame_value: Optional[int],
    padding: int,
    *,
    explicit_frame: bool = True,
    fallback: str = "pass",
) -> str:
    base = normalized_path_fragment(base_subpath, fallback=fallback)
    if not explicit_frame or frame_value is None:
        return base
    frame_token = str(int(frame_value)).zfill(max(1, int(padding or 1)))
    head, tail = os.path.split(base)
    tail = tail or fallback or "pass"
    composed = f"{tail}_{frame_token}"
    if head:
        return os.path.normpath(os.path.join(head, composed)).replace("\\", "/")
    return composed



def file_output_item_frame_subpath(item, frame_value: Optional[int], padding: int, *, explicit_frame: bool = True, fallback: str = "pass") -> str:
    base = file_output_item_base_subpath(item, fallback=fallback)
    return file_output_frame_subpath_from_base(base, frame_value, padding, explicit_frame=explicit_frame, fallback=fallback)



def file_output_item_candidate_paths(
    base_dir: str,
    item,
    frame_value: int,
    padding: int,
    extension: str,
    *,
    explicit_frame: bool = True,
    fallback: str = "pass",
) -> List[str]:
    directory = os.path.normpath(str(base_dir or ""))
    ext = str(extension or "").strip().lower().lstrip(".")
    frame_token = str(int(frame_value)).zfill(max(1, int(padding or 1)))
    base_subpath = file_output_item_base_subpath(item, fallback=fallback)
    explicit_subpath = file_output_frame_subpath_from_base(base_subpath, frame_value, padding, explicit_frame=explicit_frame, fallback=fallback)

    paths: List[str] = []
    seen = set()

    def add(subpath: str) -> None:
        subpath_text = normalized_path_fragment(subpath, fallback=fallback)
        stem = os.path.normpath(os.path.join(directory, subpath_text))
        path_value = f"{stem}.{ext}" if ext else stem
        if path_value not in seen:
            seen.add(path_value)
            paths.append(path_value)

    add(explicit_subpath)
    add(base_subpath)

    head, tail = os.path.split(base_subpath)
    tail = tail or file_output_item_label(item, fallback)
    add(os.path.join(head, f"{tail}{frame_token}"))
    add(os.path.join(head, f"{tail}_{frame_token}"))
    # Blender 5.1: frame template is a file prefix, item name stays metadata-safe.
    add(os.path.join(head, f"{frame_token}{tail}"))
    return paths



def file_output_item_socket_type(source_socket, default: str = "RGBA") -> str:
    raw_type = str(getattr(source_socket, "type", "") or default).strip().upper()
    type_map = {
        "VALUE": "FLOAT",
        "FLOAT": "FLOAT",
        "INT": "FLOAT",
        "BOOLEAN": "FLOAT",
        "VECTOR": "VECTOR",
        "RGBA": "RGBA",
        "COLOR": "RGBA",
        "IMAGE": "RGBA",
    }
    return type_map.get(raw_type, default)



def is_file_output_parameter_socket(socket) -> bool:
    identifier = str(getattr(socket, "identifier", "") or getattr(socket, "name", "") or "")
    normalized = identifier.strip().lower().replace(" ", "_")
    return normalized in FILE_OUTPUT_PARAMETER_SOCKET_KEYS



def file_output_data_inputs(file_node) -> List[object]:
    inputs = list(getattr(file_node, "inputs", []) or [])
    data_inputs = [socket for socket in inputs if not is_file_output_parameter_socket(socket)]
    return data_inputs or inputs


def uses_relative_blend_path(path: str) -> bool:
    return str(path or "").strip().startswith("//")



def set_scene_camera(scene, camera, clear_if_none: bool = True) -> bool:
    if camera is None and not clear_if_none:
        return False
    return safe_set_attr(scene, "camera", camera)



def scene_object(scene, name: str, type_hint: Optional[str] = None):
    if not name:
        return None
    try:
        obj = scene.objects.get(name)
    except Exception:
        obj = None
        for candidate in scene.objects:
            if candidate.name == name:
                obj = candidate
                break
    if obj is None:
        return None
    if type_hint and getattr(obj, "type", "") != type_hint:
        return None
    return obj



def view_layer(scene, name: str):
    if not name:
        return None
    try:
        return scene.view_layers.get(name)
    except Exception:
        for item in scene.view_layers:
            if item.name == name:
                return item
    return None



def world_by_name(name: str):
    if not name:
        return None
    try:
        return bpy.data.worlds.get(name)
    except Exception:
        for item in bpy.data.worlds:
            if item.name == name:
                return item
    return None



def material_by_name(name: str):
    if not name:
        return None
    try:
        return bpy.data.materials.get(name)
    except Exception:
        for item in bpy.data.materials:
            if item.name == name:
                return item
    return None



def camera_selection(context) -> List:
    selected = list(getattr(context, "selected_objects", []) or [])
    if not selected:
        try:
            selected = [obj for obj in context.view_layer.objects if obj.select_get()]
        except Exception:
            selected = []
    return [obj for obj in selected if getattr(obj, "type", "") == "CAMERA"]



def iter_layer_collections(layer_collection) -> Iterator:
    yield layer_collection
    for child in getattr(layer_collection, "children", []):
        yield from iter_layer_collections(child)



def layer_collection_map(view_layer_obj) -> Dict[str, object]:
    mapping: Dict[str, object] = {}
    root = getattr(view_layer_obj, "layer_collection", None)
    if root is None:
        return mapping
    for item in iter_layer_collections(root):
        try:
            collection_name = item.collection.name
        except Exception:
            collection_name = item.name
        mapping[collection_name] = item
    return mapping



def snapshot_layer_collection_flags(view_layer_obj) -> Dict[str, Dict[str, bool]]:
    result: Dict[str, Dict[str, bool]] = {}
    for name, item in layer_collection_map(view_layer_obj).items():
        result[name] = {
            "exclude": bool(getattr(item, "exclude", False)),
            "holdout": bool(getattr(item, "holdout", False)),
            "indirect_only": bool(getattr(item, "indirect_only", False)),
        }
    return result



def restore_layer_collection_flags(view_layer_obj, state: Dict[str, Dict[str, bool]]) -> None:
    mapping = layer_collection_map(view_layer_obj)
    for name, values in (state or {}).items():
        item = mapping.get(name)
        if item is None:
            continue
        safe_set_attr(item, "exclude", bool(values.get("exclude", False)))
        safe_set_attr(item, "holdout", bool(values.get("holdout", False)))
        safe_set_attr(item, "indirect_only", bool(values.get("indirect_only", False)))


def object_name_map(scene, type_filter: Optional[Sequence[str]] = None) -> Dict[str, object]:
    allowed = {str(item).upper() for item in (type_filter or []) if str(item).strip()}
    result: Dict[str, object] = {}
    for obj in list(getattr(scene, "objects", []) or []):
        name = str(getattr(obj, "name", "") or "").strip()
        obj_type = str(getattr(obj, "type", "") or "").upper()
        if not name:
            continue
        if allowed and obj_type not in allowed:
            continue
        if name not in result:
            result[name] = obj
    return result



def snapshot_object_render_visibility(scene, type_filter: Optional[Sequence[str]] = None) -> Dict[str, bool]:
    return {
        name: bool(getattr(obj, "hide_render", False))
        for name, obj in object_name_map(scene, type_filter=type_filter).items()
    }



def restore_object_render_visibility(scene, state: Dict[str, bool], type_filter: Optional[Sequence[str]] = None) -> None:
    mapping = object_name_map(scene, type_filter=type_filter)
    for name, hide_render in (state or {}).items():
        obj = mapping.get(str(name))
        if obj is None:
            continue
        safe_set_attr(obj, "hide_render", bool(hide_render))



def apply_object_render_overrides(
    scene,
    show_names: Sequence[str],
    hide_names: Sequence[str],
    *,
    reset: bool = False,
    type_filter: Optional[Sequence[str]] = None,
) -> List[str]:
    mapping = object_name_map(scene, type_filter=type_filter)
    available_names = list(mapping.keys())
    missing: List[str] = []

    show_matches, show_missing = resolve_selector_names(show_names, available_names)
    hide_matches, hide_missing = resolve_selector_names(hide_names, available_names)
    missing.extend(show_missing)
    missing.extend(hide_missing)

    if reset:
        for obj in mapping.values():
            safe_set_attr(obj, "hide_render", False)

    for name in show_matches:
        obj = mapping.get(name)
        if obj is not None:
            safe_set_attr(obj, "hide_render", False)

    for name in hide_matches:
        obj = mapping.get(name)
        if obj is not None:
            safe_set_attr(obj, "hide_render", True)

    dedup: List[str] = []
    seen = set()
    for name in missing:
        if name not in seen:
            seen.add(name)
            dedup.append(name)
    return dedup



def apply_layer_collection_overrides(
    view_layer_obj,
    include_names: Sequence[str],
    exclude_names: Sequence[str],
    holdout_names: Sequence[str],
    indirect_names: Sequence[str],
    *,
    reset_exclude: bool = False,
    reset_holdout: bool = False,
    reset_indirect: bool = False,
) -> List[str]:
    mapping = layer_collection_map(view_layer_obj)
    available_names = list(mapping.keys())
    missing: List[str] = []

    include_matches, include_missing = resolve_selector_names(include_names, available_names)
    exclude_matches, exclude_missing = resolve_selector_names(exclude_names, available_names)
    holdout_matches, holdout_missing = resolve_selector_names(holdout_names, available_names)
    indirect_matches, indirect_missing = resolve_selector_names(indirect_names, available_names)
    missing.extend(include_missing)
    missing.extend(exclude_missing)
    missing.extend(holdout_missing)
    missing.extend(indirect_missing)

    if reset_exclude or reset_holdout or reset_indirect:
        for item in mapping.values():
            if reset_exclude:
                safe_set_attr(item, "exclude", False)
            if reset_holdout:
                safe_set_attr(item, "holdout", False)
            if reset_indirect:
                safe_set_attr(item, "indirect_only", False)

    for name in include_matches:
        item = mapping.get(name)
        if item is not None:
            safe_set_attr(item, "exclude", False)

    for name in exclude_matches:
        item = mapping.get(name)
        if item is not None:
            safe_set_attr(item, "exclude", True)

    for name in holdout_matches:
        item = mapping.get(name)
        if item is not None:
            safe_set_attr(item, "holdout", True)

    for name in indirect_matches:
        item = mapping.get(name)
        if item is not None:
            safe_set_attr(item, "indirect_only", True)

    # remove duplicates but keep order
    dedup: List[str] = []
    seen = set()
    for name in missing:
        if name not in seen:
            seen.add(name)
            dedup.append(name)
    return dedup



def worst_severity(*levels: str) -> str:
    worst = "INFO"
    worst_rank = -1
    for level in levels:
        rank = SEVERITY_RANK.get(level, 0)
        if rank > worst_rank:
            worst_rank = rank
            worst = level
    return worst



def log(scene, level: str, message: str) -> None:
    item = scene.srr_logs.add()
    item.level = str(level)
    item.timestamp = now_local().strftime("%H:%M:%S")
    item.message = str(message)
    while len(scene.srr_logs) > LOG_LIMIT:
        scene.srr_logs.remove(0)
    scene.srr_log_index = max(0, len(scene.srr_logs) - 1)



def _check_path(kind: str, name: str, path_value: str, missing: List[dict]) -> None:
    filepath = abspath(path_value)
    if filepath and not os.path.exists(filepath):
        missing.append({"kind": kind, "name": name, "path": filepath})



def missing_external_assets() -> List[dict]:
    missing: List[dict] = []

    for image in getattr(bpy.data, "images", []):
        try:
            if getattr(image, "source", "") != "FILE":
                continue
            if getattr(image, "packed_file", None):
                continue
            _check_path("IMAGE", image.name, image.filepath, missing)
        except Exception:
            continue

    for movieclip in getattr(bpy.data, "movieclips", []):
        try:
            _check_path("MOVIECLIP", movieclip.name, movieclip.filepath, missing)
        except Exception:
            continue

    for sound in getattr(bpy.data, "sounds", []):
        try:
            if getattr(sound, "packed_file", None):
                continue
            _check_path("SOUND", sound.name, sound.filepath, missing)
        except Exception:
            continue

    for cache_file in getattr(bpy.data, "cache_files", []):
        try:
            _check_path("CACHE", cache_file.name, cache_file.filepath, missing)
        except Exception:
            continue

    for lib in getattr(bpy.data, "libraries", []):
        try:
            _check_path("LIBRARY", lib.name or "library", lib.filepath, missing)
        except Exception:
            continue

    for volume in getattr(bpy.data, "volumes", []):
        try:
            if getattr(volume, "packed_file", None):
                continue
            _check_path("VOLUME", volume.name, volume.filepath, missing)
        except Exception:
            continue

    return missing



def unique_output_stem(full_stem: str, ext: str, reserved_paths: Iterable[str], allow_existing: bool) -> Tuple[str, Optional[str]]:
    reserved = set(str(path) for path in reserved_paths)
    full_path = f"{full_stem}.{ext}" if ext else full_stem
    exists = os.path.exists(full_path)
    if full_path not in reserved and (allow_existing or not exists):
        return full_stem, None

    counter = 1
    while True:
        suffix = f"__{counter:03d}"
        candidate_stem = f"{full_stem}{suffix}"
        candidate_path = f"{candidate_stem}.{ext}" if ext else candidate_stem
        if candidate_path in reserved:
            counter += 1
            continue
        if allow_existing or not os.path.exists(candidate_path):
            return candidate_stem, suffix
        counter += 1

# --- Smart Tools unified user_default path patch (2026-03-27) ---
def _smart_tools_manifest_extension_id(default: str = "") -> str:
    default = str(default or "").strip()
    try:
        current = os.path.dirname(os.path.abspath(__file__))
        while True:
            manifest = os.path.join(current, "blender_manifest.toml")
            if os.path.isfile(manifest):
                with open(manifest, "r", encoding="utf-8") as handle:
                    for raw_line in handle:
                        line = raw_line.strip()
                        if not line.startswith("id"):
                            continue
                        _, _, value = line.partition("=")
                        value = str(value or "").strip().strip('"').strip("'")
                        if value:
                            return value
                break
            parent = os.path.dirname(current)
            if parent == current:
                break
            current = parent
    except Exception:
        pass
    if ".user_default." in default or default.startswith("bl_ext."):
        default = default.rsplit(".", 1)[-1]
    if "." in default:
        head = default.split(".", 1)[0].strip()
        if head:
            default = head
    return default

def _smart_tools_version_user_default_root(package_id: str, create: bool = False) -> str:
    # Historical callers used this compatibility name for mutable data.  It
    # must never resolve to Blender's installed Extension package, even when
    # ``bpy.utils.extension_path_user`` is available.
    del package_id
    try:
        from .storage import extension_user_root as _storage_root
        return str(_storage_root(create=bool(create)))
    except Exception:
        return _srs_config_storage_root(create=bool(create))

def _smart_tools_extension_candidates() -> tuple[str, ...]:
    values = []
    try:
        values.extend(list(extension_package_id_candidates()))
    except Exception:
        pass
    values.append(ADDON_ID)
    out = []
    for value in values:
        value = _smart_tools_manifest_extension_id(value)
        if value and value not in out:
            out.append(value)
    return tuple(out) or (_smart_tools_manifest_extension_id(ADDON_ID),)

def _smart_tools_extension_user_root(create: bool = False) -> str:
    for package_id in _smart_tools_extension_candidates():
        path = _smart_tools_version_user_default_root(package_id, create=create)
        if path:
            return str(path)
    return _smart_tools_version_user_default_root(ADDON_ID, create=create)

extension_user_root = _smart_tools_extension_user_root

# --- Smart Tools user_default migration patch (2026-03-27) ---
def _smart_tools_manifest_dir() -> str:
    try:
        current = os.path.dirname(os.path.abspath(__file__))
        while True:
            if os.path.isfile(os.path.join(current, "blender_manifest.toml")):
                return current
            parent = os.path.dirname(current)
            if parent == current:
                break
            current = parent
    except Exception:
        pass
    return os.path.dirname(os.path.abspath(__file__))

def _smart_tools_has_visible_entries(path: str) -> bool:
    try:
        return any(name not in {".DS_Store", "Thumbs.db"} for name in os.listdir(path))
    except Exception:
        return False

def _smart_tools_merge_tree(src: str, dst: str) -> None:
    # Deprecated compatibility entry point.  The storage module performs the
    # only supported migration: a copy-only import of explicitly known legacy
    # mutable trees into CONFIG.  Ignoring arbitrary destinations prevents old
    # integrations from copying code/assets into the installed package.
    del src, dst
    try:
        from .storage import migrate_legacy_package_data
        migrate_legacy_package_data()
    except Exception:
        pass

def _smart_tools_version_user_default_root(package_id: str, create: bool = False) -> str:
    del package_id
    try:
        from .storage import extension_user_root as _storage_root
        return str(_storage_root(create=bool(create)))
    except Exception:
        return _srs_config_storage_root(create=bool(create))

# --- Smart Render canonical Blender 5.1 user_default storage root ---
def _srs_blender_version_dir() -> str:
    try:
        version = getattr(getattr(bpy, "app", None), "version", None)
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return "5.1"


def _srs_config_storage_root(create: bool = False) -> str:
    utils = getattr(bpy, "utils", None)
    config_dir = ""
    if utils is not None:
        user_resource = getattr(utils, "user_resource", None)
        if callable(user_resource):
            try:
                config_dir = str(user_resource("CONFIG", create=create) or "")
            except TypeError:
                try:
                    config_dir = str(user_resource("CONFIG") or "")
                except Exception:
                    config_dir = ""
            except Exception:
                config_dir = ""
    if config_dir:
        base = os.path.join(os.path.normpath(config_dir), "Smart_Render_Suite")
    elif os.name == "nt":
        appdata = os.environ.get("APPDATA") or os.path.expanduser("~")
        base = os.path.join(appdata, "Blender Foundation", "Blender", _srs_blender_version_dir(), "config", "Smart_Render_Suite")
    else:
        base = os.path.join(os.path.expanduser("~"), ".config", "blender", _srs_blender_version_dir(), "config", "Smart_Render_Suite")
    if create:
        os.makedirs(base, exist_ok=True)
    return base


# Retain the old private name for third-party integrations while changing its
# contract to the CONFIG-owned suite root.
_srs_user_default_base = _srs_config_storage_root


def _srs_canonical_package_id() -> str:
    for candidate in _smart_tools_extension_candidates():
        candidate = _smart_tools_manifest_extension_id(candidate)
        if candidate:
            return candidate
    return _smart_tools_manifest_extension_id(ADDON_ID) or "smart_render_suite"


def _srs_extension_user_root(create: bool = False) -> str:
    # Keep the late compatibility override aligned with the primary helper.
    # ``storage`` owns read-only legacy migration and guarantees that the
    # installed package tree is never a write destination.
    try:
        from . import storage as _srs_storage
        return str(_srs_storage.extension_user_root(create=bool(create)))
    except Exception:
        version = _srs_blender_version_dir()
        if os.name == "nt":
            roaming = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Roaming")
            config_root = os.path.join(roaming, "Blender Foundation", "Blender", version, "config")
        else:
            config_root = os.path.join(os.path.expanduser("~"), ".config", "blender", version, "config")
        target_path = os.path.join(config_root, "Smart_Render_Suite")
        if create:
            os.makedirs(target_path, exist_ok=True)
        return target_path


extension_user_root = _srs_extension_user_root
