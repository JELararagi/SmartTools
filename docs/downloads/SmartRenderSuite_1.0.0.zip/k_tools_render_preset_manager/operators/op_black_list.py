import bpy
from .. import utils
from ..properties.function_list import RENDER_SETTINGS

class RENDER_PRESET_OT_sync_blacklist(bpy.types.Operator):
    """
    Scans RENDER_SETTINGS and updates the user's blacklist collection,
    preserving existing user choices.
    """
    bl_options = set()
    _sms_no_undo = True
    bl_idname = "render_preset.sync_property_list"
    bl_label = "Sync Property List"
    
    def execute(self, context):
        prefs = utils.get_addon_preferences(context)
        existing_choices = {item.path: item.is_enabled for item in prefs.blacklist_items}
        prefs.blacklist_items.clear()
        
        for category_name, properties in RENDER_SETTINGS.items():
            for path, friendly_name in properties:
                new_item = prefs.blacklist_items.add()
                
                new_item.name = friendly_name # Popula 'name' em vez de 'friendly_name'
                
                new_item.path = path
                new_item.category = category_name
                new_item.is_enabled = existing_choices.get(path, True)
                
        return {'FINISHED'}
    
classes = (
    RENDER_PRESET_OT_sync_blacklist,
)
