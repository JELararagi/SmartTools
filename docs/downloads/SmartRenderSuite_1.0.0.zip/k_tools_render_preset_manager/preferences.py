from ..translation import iface_text
import bpy
from ..rna_safety import safe_register_class, safe_unregister_class
# ADDON IMPORT
from .properties.properties import BlacklistableProperty
from .properties import function_list
from . import utils
#########################################################
# UI LIST FOR BLACKLIST
#########################################################
class RENDER_PRESET_UL_blacklist(bpy.types.UIList):
    """UIList with functional text search and tab filtering."""
    
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(item, "is_enabled", text="")
            row.label(text=item.name, translate=False)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="")

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        
        # 1. Get search term
        query = getattr(data, "search_term", "").lower()
        
        # 2. Get active tab (adjust 'your_addon_props' to your actual property group)
        blacklist_props = context.scene.blacklist_props 
        active_tab = blacklist_props.engine_blacklist_tab
        
        # 3. Define tab mappings based on RENDER_SETTINGS keys
        BLACKLIST_TABS = {
            'NATIVE': [
                "RENDER_ENGINE",
                "CYCLES", 
                "BLENDER_EEVEE", 
                "BLENDER_WORKBENCH", 
                "BLENDER_OUTPUT", 
                "BLENDER_VIEW_LAYER", 
                "BLENDER_SCENE", 
                function_list.COMMON_COLOR_MANAGEMENT
            ],
            'OCTANE': [
                "RENDER_ENGINE",
                "OCTANE", 
                "OCTANE_VIEW_LAYER", 
                "OCTANE_IMAGER", 
                "OCTANE_POST",
                "BLENDER_OUTPUT",
                #function_list.OCTANE_OUTPUT_PROPS
            ]
        }
        valid_categories = BLACKLIST_TABS.get(active_tab, [])

        flt_flags = []
        flt_neworder = []
        include_item = self.bitflag_filter_item
        
        for item in items:
            show_item = True
            
            # --- FILTER A: Engine Tab Category ---
            # Checks if the item's category belongs to the current active tab
            if item.category not in valid_categories:
                show_item = False
                
            # --- FILTER B: Text Search ---
            # Only process string search if it passed the tab filter
            if show_item and query:
                if query not in item.name.lower():
                    show_item = False
                    
            # --- FINAL DECISION ---
            if show_item:
                flt_flags.append(include_item)
            else:
                flt_flags.append(0)
                
        return flt_flags, flt_neworder


#########################################################
# N-PANEL RUNTIME SETTINGS DRAWING
def get_scraper_sources(self, context):
    """Provides the source items for the scraper tool."""
    return [
        ('SCENE', 'Scene', 'General scene properties (render, eevee, cycles)'),
        ('VIEW_LAYER', 'View Layer', 'Active view layer settings'),
        ('WORLD', 'World', 'World shader and lighting settings'),
    ]

def draw_preferences_contents(layout, context, prefs, *, search_data_path: str) -> None:
    if not str(getattr(prefs, 'user_presets_path', '') or '').strip():
        try:
            prefs.user_presets_path = utils.default_user_presets_path(create=True)
        except Exception:
            pass

    blacklist_props = context.scene.blacklist_props

    box = layout.box()
    box.label(text=iface_text("General Settings"), icon='PREFERENCES')

    col = box.column(align=True)
    col.scale_y = 0.9
    col.label(text=iface_text("User Presets Path:"))
    col.prop(prefs, "user_presets_path", text='')

    col = box.column(align=True)
    col.prop(prefs, "show_filename_in_list")
    col.prop(prefs, "preset_display_style")

    box = layout.box()
    row = box.row(align=True)
    row.label(text=iface_text('Whitelist'), icon='FILTER')
    row.label(text=iface_text(" "))
    row.operator("render_preset.sync_property_list", icon='FILE_REFRESH', text=iface_text('Refresh'))

    if utils.is_engine_available(context, 'octane'):
        row = box.row(align=True)
        row.prop(blacklist_props, 'engine_blacklist_tab', expand=True)

    row = box.row(align=True)
    row.prop(prefs, "search_term", text="", icon='VIEWZOOM')

    if getattr(prefs, 'search_term', ''):
        op = row.operator("wm.context_set_string", text="", icon='X')
        op.data_path = search_data_path
        op.value = ""

    box.template_list(
        "RENDER_PRESET_UL_blacklist",
        "",
        prefs,
        "blacklist_items",
        prefs,
        "blacklist_active_index",
        rows=10
    )


    box = layout.box()
    box.label(text=iface_text("Help & Support"), icon='QUESTION')

    row = box.row(align=True)
    row.operator("wm.url_open", text=iface_text("Documentation"), icon='URL').url = "https://github.com/r-kez/k_tools_render_preset_manager/wiki"
    row.operator("wm.url_open", text=iface_text("Report a Bug"), icon='URL').url = "https://github.com/r-kez/k_tools_render_preset_manager/issues"

    box = layout.box()
    row = box.row(align=True)
    row.prop(prefs, "developer_extras", text=iface_text("Developer Tools"), icon='TRIA_DOWN' if prefs.developer_extras else 'TRIA_RIGHT', emboss=False)

    if prefs.developer_extras:
        box.separator(factor=0.5)
        box.label(text=iface_text("Property Auditor"))

        col = box.column(align=True)
        split = col.split(factor=0.3, align=True)
        split.label(text=iface_text("Source:"))
        split.prop(prefs, "dev_scraper_source_type", text="")

        split = col.split(factor=0.3, align=True)
        split.label(text=iface_text("Filter Path:"))
        split.prop(prefs, "dev_scraper_filter_path", text="")

        split = col.split(factor=0.3, align=True)
        split.label(text=iface_text("Depth:"))
        split.prop(prefs, "dev_scraper_max_depth", text="")

        split = col.split(factor=0.3, align=True)
        split.label(text=iface_text("Show New Props:"))
        split.prop(prefs, "dev_show_new_props", text="")

        row = box.row(align=True)
        row.operator("render_preset.generate_property_list", text=iface_text("Generate List"), icon='TEXT')
        row.operator("render_preset.run_property_audit", text=iface_text("Validate"), icon='FILE_REFRESH')

        row = box.row(align=True)
        row.label(text=iface_text("Fuzz Test:"), icon='GHOST_ENABLED')
        row = box.row(align=True)
        row.operator("render_preset.run_fuzz_test", icon='GHOST_ENABLED')



classes = (
    RENDER_PRESET_UL_blacklist,
)

def register():
    for cls in classes:
        safe_register_class(cls)


def unregister():
    for cls in reversed(classes):
        safe_unregister_class(cls)

if __name__ == "__main__":
    register()