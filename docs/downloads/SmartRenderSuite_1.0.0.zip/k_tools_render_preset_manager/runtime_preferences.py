import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import PropertyGroup

from ..translation import localize_inline, localize_pair
from .preferences import draw_preferences_contents, get_scraper_sources
from .properties.properties import BlacklistableProperty


_REGISTER_ERROR = ""
_REGISTERED_POINTER = False

_PROPERTY_NAME = "smart_render_k_tools_prefs"


class KTOOLS_RuntimePreferences(PropertyGroup):
    user_presets_path: StringProperty(
        name=localize_pair("ユーザープリセット保存先", "User Presets Directory"),
        description=localize_inline("Directory where personal render presets are stored. / 個人用レンダープリセットを保存するディレクトリです。"),
        subtype='DIR_PATH',
        default="",
    )  # type: ignore
    show_filename_in_list: BoolProperty(
        name=localize_pair("一覧にファイル名を表示", "Display Filename in List"),
        description=localize_inline("Show the JSON filename next to the preset name. / プリセット名の横に JSON ファイル名を表示します。"),
        default=False,
    )  # type: ignore
    dev_show_new_props: BoolProperty(
        name=localize_pair("監査で新規プロパティ候補を表示", "Show New Properties in Audit"),
        description=localize_inline("Include newly discovered properties in the generated audit report. / 監査レポートに新規プロパティ候補も表示します。"),
        default=True,
    )  # type: ignore
    panel_location: EnumProperty(
        name=localize_pair("パネル配置", "Panel Location"),
        description=localize_inline("Original standalone placement option kept for compatibility. / 旧単体版との互換のため保持している配置オプションです。"),
        items=[
            ('PREPEND', localize_pair('レンダープロパティ上部', 'Top of Render Properties'), localize_pair('Render タブ上部へ挿入します。', 'Injects the panel at the top of the Render tab')),
            ('HIDE_HEADER', localize_pair('レンダープロパティ下部', 'Bottom of Render Properties'), localize_pair('Render タブ下部へ挿入します。', 'Injects the panel at the bottom of the Render tab')),
            ('PANEL', localize_pair('独立パネル', 'Panel'), localize_pair('独立したパネルとして表示します。', 'Shows the addon as its own separate panel')),
        ],
        default='HIDE_HEADER',
    )  # type: ignore
    developer_extras: BoolProperty(
        name=localize_pair('開発者向け追加機能', 'Enable Developer Extras'),
        description=localize_inline('Show audit and generation tools. / 監査と生成ツールを表示します。'),
        default=False,
    )  # type: ignore
    dev_scraper_source_type: EnumProperty(
        name=localize_pair('ソース', 'Source'),
        description=localize_inline('Select the data source to scrape. / スクレイプ対象のデータソースを選びます。'),
        items=get_scraper_sources,
        default=0,
    )  # type: ignore
    dev_scraper_filter_path: StringProperty(
        name=localize_pair('フィルターパス', 'Filter Path'),
        description=localize_inline('Sub-path to scrape, for example cycles or render.image_settings. / cycles や render.image_settings のようなサブパスを指定します。'),
        default="",
    )  # type: ignore
    dev_scraper_max_depth: IntProperty(
        name=localize_pair('最大深さ', 'Max Depth'),
        description=localize_inline('Recursive scrape depth. / 再帰スクレイプの深さです。'),
        default=6,
        min=1,
        max=10,
    )  # type: ignore
    blacklist_items: CollectionProperty(type=BlacklistableProperty)  # type: ignore
    blacklist_active_index: IntProperty(default=0)  # type: ignore
    search_term: StringProperty(
        name=localize_pair('検索', 'Search'),
        description=localize_inline('Filter properties by name. / プロパティ名で絞り込みます。'),
        default="",
    )  # type: ignore
    preset_display_style: EnumProperty(
        name=localize_pair('プリセット表示形式', 'Preset Display Style'),
        description=localize_inline('Choose how user presets are displayed. / ユーザープリセットの表示方法を選びます。'),
        items=[
            ('DROPDOWN', localize_pair('ドロップダウン', 'Dropdown Menu'), localize_pair('コンパクト表示です。', 'Compact view (Classic)')),
            ('LIST', localize_pair('リスト', 'UI List'), localize_pair('展開済み一覧表示です。', 'Expanded list view')),
        ],
        default='DROPDOWN',
    )  # type: ignore



def get_runtime_preferences(context=None):
    ctx = context or getattr(bpy, "context", None)
    wm = getattr(ctx, "window_manager", None)
    return getattr(wm, _PROPERTY_NAME, None) if wm is not None else None



def draw_runtime_settings(layout, context) -> None:
    prefs = get_runtime_preferences(context)
    if prefs is None:
        layout.label(text=localize_inline("Render Presets settings are not available yet. / Render Presets 設定はまだ利用できません。"), icon="ERROR", translate=False)
        return
    draw_preferences_contents(
        layout,
        context,
        prefs,
        search_data_path="window_manager.smart_render_k_tools_prefs.search_term",
    )



def register() -> None:
    global _REGISTER_ERROR, _REGISTERED_POINTER
    _REGISTER_ERROR = ""
    _REGISTERED_POINTER = False
    from ..rna_safety import register_pointer_property
    try:
        _REGISTERED_POINTER = bool(register_pointer_property(bpy.types.WindowManager, "smart_render_k_tools_prefs", KTOOLS_RuntimePreferences))
    except Exception as exc:
        _REGISTER_ERROR = str(exc)
        _REGISTERED_POINTER = False



def unregister() -> None:
    global _REGISTER_ERROR, _REGISTERED_POINTER
    if hasattr(bpy.types.WindowManager, "smart_render_k_tools_prefs"):
        try:
            del bpy.types.WindowManager.smart_render_k_tools_prefs
        except Exception:
            pass
    try:
        from ..rna_safety import unregister_existing_class
        unregister_existing_class(KTOOLS_RuntimePreferences)
    except Exception:
        pass
    _REGISTER_ERROR = ""
    _REGISTERED_POINTER = False
