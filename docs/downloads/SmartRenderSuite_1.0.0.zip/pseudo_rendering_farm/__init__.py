

def _smarttools_console_output(*_args, **_kwargs):
    return None
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from ..translation import iface_text
bl_info = {
    "name": 'Local Render Farm',
    "author": "JELararagi",
    "version": (0, 9, 0),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Render",
    "description": "Launch and benchmark local parallel render processes inside the Smart Render N-panel workflow.",
    "category": "Render",
}

import bpy
from ..rna_safety import safe_register_class, safe_unregister_class
import os
import shutil
import subprocess
import tempfile
import time
from ..help_operator import draw_help_button


def _create_benchmark_tempdir():
    try:
        from ..storage import user_default_root
        base = str(user_default_root("benchmarks", create=True))
    except Exception:
        try:
            from ..compat import extension_user_root
            base = os.path.join(extension_user_root(create=True), "benchmarks")
        except Exception:
            version = f"{int(bpy.app.version[0])}.{int(bpy.app.version[1])}" if getattr(bpy.app, 'version', None) else '5.1'
            if os.name == 'nt':
                roaming = os.environ.get('APPDATA') or os.path.join(os.path.expanduser('~'), 'AppData', 'Roaming')
                base = os.path.join(roaming, 'Blender Foundation', 'Blender', version, 'config', 'Smart_Render_Suite', 'benchmarks')
            else:
                base = os.path.join(os.path.expanduser('~'), '.config', 'blender', version, 'config', 'Smart_Render_Suite', 'benchmarks')
    os.makedirs(base, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    for index in range(1000):
        suffix = f"_{index:03d}" if index else ""
        candidate = os.path.join(base, f"blender_bench_{stamp}{suffix}")
        try:
            os.makedirs(candidate)
            return candidate
        except FileExistsError:
            continue
    return tempfile.mkdtemp(prefix="blender_bench_", dir=base)


class Globals:
    active_render_processes = []
    is_rendering_active = False
    is_benchmarking = False
    early_exit_benchmark = False
    bench_status_msg = ""
    current_bench_instances = 1
    benchmark_frames = 1
    benchmark_results = {}
    bench_temp_dir = ""
    start_time = 0
    elapsed_time = 0
    seconds_per_frame = 0


def is_image_valid(filepath):
    """Checks if an image file is complete by looking for format-specific footers."""
    if not os.path.exists(filepath) or os.path.getsize(filepath) == 0:
        return False

    ext = os.path.splitext(filepath)[1].lower()

    try:
        with open(filepath, "rb") as f:
            f.seek(-10, 2)
            footer = f.read()

            if ext == ".png":
                return b"\xaeB`\x82" in footer
            elif ext in {".jpg", ".jpeg"}:
                return b"\xff\xd9" in footer
            elif ext == ".exr":
                return os.path.getsize(filepath) > 1000
    except Exception as e:
        _smarttools_console_output(f"Error checking {filepath}: {e}")
        return False

    return True


def cleanup_corrupted_frames():
    scene = bpy.context.scene
    output_path = bpy.path.abspath(scene.render.filepath)
    output_dir = os.path.dirname(output_path)

    if not os.path.exists(output_dir):
        return

    deleted_count = 0
    for filename in os.listdir(output_dir):
        file_path = os.path.join(output_dir, filename)
        if os.path.isfile(file_path):
            if not is_image_valid(file_path):
                try:
                    os.remove(file_path)
                    deleted_count += 1
                except Exception as e:
                    _smarttools_console_output(f"Failed to delete {filename}: {e}")

    return deleted_count


def cleanup_bench_dir():
    if Globals.bench_temp_dir and os.path.exists(Globals.bench_temp_dir):
        try:
            shutil.rmtree(Globals.bench_temp_dir)
        except:
            pass
        Globals.bench_temp_dir = ""


def check_render_status():
    for proc in Globals.active_render_processes[:]:
        if proc.poll() is not None:
            Globals.active_render_processes.remove(proc)

    if Globals.early_exit_benchmark or (
        Globals.is_benchmarking and not Globals.active_render_processes
    ):
        elapsed = time.time() - Globals.start_time
        throughput = Globals.benchmark_frames / max(elapsed, 0.001)

        Globals.benchmark_results[Globals.current_bench_instances] = throughput

        if (
            Globals.early_exit_benchmark
            or Globals.current_bench_instances >= 32
            or (
                Globals.current_bench_instances > 2
                and throughput < Globals.benchmark_results[1]
            )
        ):
            best_count = max(
                Globals.benchmark_results, key=Globals.benchmark_results.get
            )
            bpy.context.scene.pseudo_rendering_farm_instances = best_count

            Globals.is_benchmarking = False
            Globals.early_exit_benchmark = False
            Globals.bench_status_msg = iface_text(f"Optimal found: {best_count}")
            cleanup_bench_dir()

            def draw_popup(self, context):
                self.layout.label(
                    text=iface_text(f"Benchmark is complete, optimal number of instances is {best_count} with {1.0 / Globals.benchmark_results[best_count]:.1f} seconds per frame"),
                    icon="CHECKMARK",
                )

            _smarttools_console_output(f"!!! Benchmarking stats for nerds !!!")
            _smarttools_console_output(Globals.benchmark_results)

            bpy.context.window_manager.popup_menu(
                draw_popup, title=iface_text("Benchmark Complete"), icon="RENDER_RESULT"
            )

            for window in bpy.context.window_manager.windows:
                for area in window.screen.areas:
                    area.tag_redraw()

            return None
        else:
            Globals.current_bench_instances += 1
            for window in bpy.context.window_manager.windows:
                for area in window.screen.areas:
                    area.tag_redraw()
            launch_benchmark_iteration(bpy.context)

    if Globals.is_rendering_active and not Globals.active_render_processes:

        Globals.elapsed_time = time.time() - Globals.start_time
        scene = bpy.context.scene
        frames = scene.frame_end - scene.frame_start + 1
        Globals.seconds_per_frame = Globals.elapsed_time / frames
        Globals.is_rendering_active = False

        def draw_popup(self, context):
            self.layout.label(
                text=iface_text(f"All instances finished in {Globals.elapsed_time:.1f} s at {Globals.seconds_per_frame:.1f} seconds per frame"),
                icon="CHECKMARK",
            )

        bpy.context.window_manager.popup_menu(
            draw_popup, title=iface_text("Local Render Farm Complete"), icon="RENDER_ANIMATION"
        )
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
        return None

    return 1.0


"""
Rendering
"""


class RENDER_OT_pseudo_rendering_farm(bpy.types.Operator):
    """Launch multiple background render instances based on current scene settings"""
    bl_options = set()
    _sms_no_undo = True

    bl_idname = "render.launch_local_render_farm"
    bl_label = "Launch Local Render Farm"

    def execute(self, context):
        scene = context.scene
        rd = scene.render

        if rd.use_overwrite:
            self.report({"ERROR"}, iface_text("Validation Failed: 'Overwrite' must be UNCHECKED"))
            return {"CANCELLED"}

        if not rd.use_placeholder:
            self.report({"ERROR"}, iface_text("Validation Failed: 'Placeholders' must be CHECKED"))
            return {"CANCELLED"}

        if not bpy.data.filepath:
            self.report({"ERROR"}, iface_text("Please save the scene"))
            return {"CANCELLED"}

        bpy.ops.wm.save_mainfile()
        blender_exe = bpy.app.binary_path
        file_path = bpy.data.filepath
        num_instances = scene.pseudo_rendering_farm_instances

        Globals.active_render_processes.clear()
        Globals.start_time = time.time()
        Globals.is_rendering_active = True

        if not bpy.app.timers.is_registered(check_render_status):
            bpy.app.timers.register(check_render_status)

        for i in range(num_instances):
            try:
                Globals.active_render_processes.append(
                    subprocess.Popen([blender_exe, "-b", file_path, "-a"])
                )
            except Exception as e:
                self.report({"ERROR"}, iface_text(f"Failed to launch instance {i}: {str(e)}"))

        self.report({"INFO"}, iface_text(f"Launched {num_instances} render instances."))
        return {"FINISHED"}


class RENDER_OT_cancel_pseudo_rendering_farm(bpy.types.Operator):
    """Stop all background render processes spawned by this plugin"""
    bl_options = set()
    _sms_no_undo = True

    bl_idname = "render.cancel_all_renders"
    bl_label = "Cancel All Renders"

    def execute(self, context):
        if not Globals.active_render_processes:
            self.report({"INFO"}, iface_text("No active processes found"))
            return {"FINISHED"}

        count = 0
        for proc in Globals.active_render_processes:
            if proc.poll() is None:
                proc.terminate()
                count += 1
        Globals.early_exit_benchmark = True
        Globals.is_benchmarking = False

        Globals.active_render_processes.clear()

        time.sleep(0.2)
        cleared = cleanup_corrupted_frames()
        cleanup_bench_dir()

        for area in context.screen.areas:
            area.tag_redraw()

        if count != 0:
            self.report(
                {"WARNING"},
                iface_text(f"Terminated {count} render processes. Removed {cleared} partial files"),
            )
        return {"FINISHED"}


"""
Benchmarking
"""


def launch_benchmark_iteration(context):
    """Spawns processes for the current benchmark step."""
    Globals.start_time = time.time()
    exe = bpy.app.binary_path
    blend = bpy.data.filepath
    scene = bpy.context.scene
    Globals.benchmark_frames = (
        min(scene.frame_end, 50) // Globals.current_bench_instances
    )
    Globals.benchmark_frames *= (
        Globals.current_bench_instances
    )  # Ensure that the amount of frames is divisible

    Globals.bench_status_msg = f"Testing {Globals.current_bench_instances} instances on {Globals.benchmark_frames} frames"

    out_path = os.path.join(
        Globals.bench_temp_dir, f"inst_{Globals.current_bench_instances}", "frame_"
    )
    _smarttools_console_output(out_path)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    for _ in range(Globals.current_bench_instances):
        cmd = [
            exe,
            "-b",
            blend,
            "-o",
            out_path,
            "-s",
            "1",
            "-e",
            str(Globals.benchmark_frames),
            "-a",
        ]
        Globals.active_render_processes.append(subprocess.Popen(cmd))

    if not bpy.app.timers.is_registered(check_render_status):
        bpy.app.timers.register(check_render_status)


class RENDER_OT_benchmarking(bpy.types.Operator):
    """Launch pseudo rendering farm benchmarking"""
    bl_options = set()
    _sms_no_undo = True

    bl_idname = "render.run_benchmark"
    bl_label = "Run Benchmark"

    def execute(self, context):
        if not bpy.data.filepath:
            self.report({"ERROR"}, iface_text("Save file before benchmarking."))
            return {"CANCELLED"}

        Globals.is_benchmarking = True
        Globals.current_bench_instances = 1
        Globals.benchmark_results = {}
        Globals.bench_temp_dir = _create_benchmark_tempdir()

        launch_benchmark_iteration(context)
        return {"FINISHED"}


"""
UI
"""


# Source panel is intentionally hidden in this integrated package.
# Smart Render re-exposes it through its own proxy panel so the
# controls stay available only inside the Smart Render tab.
class RENDER_PT_LOCAL_RENDER_FARM_panel(bpy.types.Panel):
    bl_label = "Local Render Farm"
    bl_idname = "RENDER_PT_LOCAL_RENDER_FARM"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True
    bl_context = "render"

    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'integrated:pseudo_rendering_farm')

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Draw callbacks are display-only.  The registered check_render_status
        # timer owns process-list cleanup; here we only derive the visible state
        # without mutating global runtime data during an N-panel redraw.
        active_process_count = sum(
            1 for proc in Globals.active_render_processes
            if proc.poll() is None
        )
        is_running = active_process_count > 0 or Globals.is_benchmarking
        col = layout.column(align=True)

        sub_col = col.column()
        sub_col.enabled = not is_running
        sub_col.prop(scene, "pseudo_rendering_farm_instances", text=iface_text("Instances"))
        row = col.row(align=True)

        launch_row = row.row(align=True)
        launch_row.enabled = not is_running
        launch_row.operator("render.launch_local_render_farm", icon="RENDER_ANIMATION")
        benchmark_row = row.row(align=True)
        benchmark_row.enabled = not is_running
        benchmark_row.operator("render.run_benchmark", icon="SETTINGS")

        row = col.row(align=True)
        cancel_row = row.row(align=True)
        cancel_row.enabled = is_running
        cancel_row.operator(
            "render.cancel_all_renders", icon="X", text=iface_text("Stop")
        )

        if Globals.is_benchmarking:
            layout.label(text=Globals.bench_status_msg, icon="PLAY")
        elif Globals.is_rendering_active:
            layout.label(
                text=iface_text(f"Rendering: {active_process_count} active"),
                icon="URL",
            )
        else:
            if Globals.elapsed_time != 0:
                layout.label(
                    text=iface_text(f"Ready. Spent {Globals.elapsed_time:.1f} seconds with {Globals.seconds_per_frame:.1f} seconds per frame"),
                    icon="CHECKMARK",
                )
            else:
                layout.label(text=iface_text("Ready"), icon="CHECKMARK")


classes = [
    RENDER_OT_pseudo_rendering_farm,
    RENDER_OT_cancel_pseudo_rendering_farm,
    RENDER_OT_benchmarking,
    RENDER_PT_LOCAL_RENDER_FARM_panel,
]


def register():
    for c in classes:
        safe_register_class(c)
    bpy.types.Scene.is_notifying = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.pseudo_rendering_farm_instances = bpy.props.IntProperty(
        name="Instances", default=2, min=1, max=32
    )


def unregister():
    for c in classes:
        safe_unregister_class(c)
    del bpy.types.Scene.pseudo_rendering_farm_instances
    del bpy.types.Scene.is_notifying


if __name__ == "__main__":
    register()
