# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""English text for UI strings whose source text is Japanese.

Blender translates these in every language other than Japanese, so the labels
stay correct when the language changes while the add-on is enabled.
"""

import bpy

_OWNER = __name__


def _payload() -> dict:
    from .locale_fallback_data import JA_EN

    entries = {}
    for japanese, english in JA_EN.items():
        for context in ("*", "Operator"):
            entries[(context, japanese)] = english
    payload = {"en_US": entries}
    for locale in bpy.app.translations.locales:
        if not str(locale).startswith("ja"):
            payload[locale] = entries
    return payload


def _register_table() -> None:
    try:
        bpy.app.translations.unregister(_OWNER)
    except Exception:
        pass
    bpy.app.translations.register(_OWNER, _payload())


def _unregister_table() -> None:
    try:
        bpy.app.translations.unregister(_OWNER)
    except Exception:
        pass


def wrap(register, unregister):
    def _register(*args, **kwargs):
        result = register(*args, **kwargs)
        _register_table()
        return result

    def _unregister(*args, **kwargs):
        _unregister_table()
        return unregister(*args, **kwargs)

    return _register, _unregister
