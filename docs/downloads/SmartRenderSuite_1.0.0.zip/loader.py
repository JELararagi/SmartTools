# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import importlib
import platform
import traceback
from pathlib import Path
from typing import Any

import bpy
from . import feature_toggle as _feature_toggle

from . import tool_registry as registry
from .tool_catalog import tool_enabled

_RECORDS: list[dict[str, Any]] = []
_RECORDS_BY_ALIAS: dict[str, dict[str, Any]] = {}
_HIDDEN_PANEL_POLLS: dict[type, object] = {}
_MISSING_POLL = object()
_RESTORE_TIMER = None
_RESTORING_SAVED_TOOLS = False



def clear_records() -> None:
    _RECORDS.clear()
    _RECORDS_BY_ALIAS.clear()



def get_records() -> list[dict[str, Any]]:
    return list(_RECORDS)



def get_record(alias: str) -> dict[str, Any] | None:
    return _RECORDS_BY_ALIAS.get(str(alias or '').strip())



def _remember_record(record: dict[str, Any]) -> None:
    alias = str((record.get('spec') or {}).get('alias') or '').strip()
    if alias:
        _RECORDS_BY_ALIAS[alias] = record
    _RECORDS.append(record)



def _root_module_prefix() -> str:
    package = str(__package__ or '').strip()
    if package:
        return package
    module_name = str(__name__.rpartition('.')[0] or '').strip()
    if module_name:
        return module_name
    return 'smart_render_suite'



def _platform_supported(outer_zip: str) -> bool:
    text = str(outer_zip or '').lower()
    system = platform.system().lower()
    machine = platform.machine().lower()
    if 'windows-x64' in text:
        return system == 'windows' and machine in {'amd64', 'x86_64'}
    if 'linux-x64' in text:
        return system == 'linux' and machine in {'amd64', 'x86_64'}
    if 'macos-arm64' in text:
        return system == 'darwin' and machine in {'arm64', 'aarch64'}
    if 'macos-x64' in text:
        return system == 'darwin' and machine in {'amd64', 'x86_64'}
    return True



def _module_name_for_spec(spec: dict[str, Any]) -> str:
    prefix = _root_module_prefix()
    alias = str(spec.get('alias') or 'addon').strip()
    return f'{prefix}.{alias}'



def _safe_unregister_class(cls: type) -> None:
    try:
        from .rna_safety import safe_unregister_class
        safe_unregister_class(cls)
    except Exception:
        pass



def _capture_registered_classes(callable_obj):
    captured: list[type] = []

    def _has_own_bl_rna(cls: type | None) -> bool:
        if cls is None or not isinstance(cls, type):
            return False
        try:
            return getattr(cls, '__dict__', {}).get('bl_rna') is not None
        except Exception:
            return False

    def _registered_classes() -> tuple[type, ...]:
        result: list[type] = []
        seen: set[int] = set()
        stack: list[type] = []
        for base_name in (
            'Operator', 'Panel', 'Menu', 'AddonPreferences', 'PropertyGroup',
            'UIList', 'Gizmo', 'GizmoGroup',
        ):
            base = getattr(bpy.types, base_name, None)
            if isinstance(base, type):
                try:
                    stack.extend(tuple(base.__subclasses__()))
                except Exception:
                    pass
        while stack:
            cls = stack.pop()
            if not isinstance(cls, type) or id(cls) in seen:
                continue
            seen.add(id(cls))
            try:
                stack.extend(tuple(cls.__subclasses__()))
            except Exception:
                pass
            if _has_own_bl_rna(cls):
                result.append(cls)
        return tuple(result)

    before_ids = {id(cls) for cls in _registered_classes()}
    callable_obj()
    module_prefix = str(getattr(callable_obj, '__module__', '') or '').strip()
    for cls in _registered_classes():
        class_module = str(getattr(cls, '__module__', '') or '').strip()
        if module_prefix and not (
            class_module == module_prefix or class_module.startswith(module_prefix + '.')
        ):
            continue
        if id(cls) not in before_ids or module_prefix:
            captured.append(cls)
            try:
                from .rna_safety import ensure_operator_undo_option
                ensure_operator_undo_option(cls)
            except Exception:
                pass
    return captured



def _categorize_classes(classes: list[type]) -> tuple[list[type], list[type], list[type], list[type]]:
    panels: list[type] = []
    operators: list[type] = []
    menus: list[type] = []
    prefs: list[type] = []
    panel_base = getattr(bpy.types, 'Panel', None)
    operator_base = getattr(bpy.types, 'Operator', None)
    menu_base = getattr(bpy.types, 'Menu', None)
    prefs_base = getattr(bpy.types, 'AddonPreferences', None)
    for cls in classes:
        try:
            if panel_base is not None and isinstance(cls, type) and issubclass(cls, panel_base):
                panels.append(cls)
                continue
        except Exception:
            pass
        try:
            if operator_base is not None and isinstance(cls, type) and issubclass(cls, operator_base):
                operators.append(cls)
                continue
        except Exception:
            pass
        try:
            if menu_base is not None and isinstance(cls, type) and issubclass(cls, menu_base):
                menus.append(cls)
                continue
        except Exception:
            pass
        try:
            if prefs_base is not None and isinstance(cls, type) and issubclass(cls, prefs_base):
                prefs.append(cls)
                continue
        except Exception:
            pass
    return panels, operators, menus, prefs



def _hide_original_panels(panels: list[type]) -> None:
    for cls in panels:
        if (
            cls in _HIDDEN_PANEL_POLLS
            or getattr(cls, '_srr_keep_popover_poll', False)
            or getattr(cls, '_srr_integrated_popover', False)
        ):
            continue
        raw_poll = cls.__dict__.get('poll', _MISSING_POLL)

        @classmethod
        def _hidden_poll(_inner_cls, _context):
            return False

        try:
            cls.poll = _hidden_poll
            _HIDDEN_PANEL_POLLS[cls] = raw_poll
        except Exception:
            pass



def _restore_hidden_panels() -> None:
    for cls, raw_poll in list(_HIDDEN_PANEL_POLLS.items()):
        try:
            if raw_poll is _MISSING_POLL:
                if hasattr(cls, 'poll'):
                    setattr(cls, 'poll', classmethod(lambda _cls, _context: True))
            else:
                setattr(cls, 'poll', raw_poll)
        except Exception:
            pass
    _HIDDEN_PANEL_POLLS.clear()



def _base_record(spec: dict[str, Any]) -> dict[str, Any]:
    load_flag = bool(spec.get('load', True))
    supported = _platform_supported(str(spec.get('outer_zip') or ''))
    if not load_flag:
        status = 'disabled'
    elif not supported:
        status = 'unsupported_platform'
    else:
        status = 'ready'
    return {
        'spec': spec,
        'status': status,
        'module': None,
        'registered_classes': [],
        'proxy_panels': [],
        'panels': [],
        'operators': [],
        'menus': [],
        'preferences': [],
        'error': '',
        'enabled_by_user': True,
    }

def register_all() -> list[dict[str, Any]]:
    try:
        _feature_toggle.register_ui(suite_key='smart_render_suite', suite_label='Smart Render', category='Smart Render')
    except Exception:
        pass
    clear_records()
    specs = registry.build_specs(force=False)
    for spec in specs:
        _remember_record(_base_record(spec))
    # Startup-safe behavior: do not import/register every bundled tool here.
    # Each tool is represented in the N-panel as a ready entry. Only tools that
    # the user opens or that are listed in saved N-panel state are loaded.
    return get_records()


def restore_saved_loaded_tools(context=None) -> list[str]:
    global _RESTORING_SAVED_TOOLS
    if _RESTORING_SAVED_TOOLS:
        return []
    try:
        from . import settings as _settings
        aliases = _settings.get_saved_loaded_tools()
    except Exception:
        aliases = []
    if not aliases:
        return []
    loaded: list[str] = []
    _RESTORING_SAVED_TOOLS = True
    try:
        for alias in aliases:
            record = get_record(alias)
            if record is None:
                continue
            status = str(record.get('status') or '')
            if status in {'disabled', 'unsupported_platform'}:
                continue
            result = load_alias(alias, force=False)
            if result is not None and str(result.get('status') or '') == 'loaded':
                loaded.append(alias)
        try:
            from . import settings as _settings
            ctx = context if context is not None else getattr(bpy, 'context', None)
            _settings.apply_context(ctx, force=True)
            _settings.snapshot_context(ctx, force=_settings.is_npanel_state_save_enabled(ctx))
        except Exception:
            pass
        try:
            from . import ui_runtime as _ui_runtime
            schedule = getattr(_ui_runtime, '_schedule_dynamic_ui_rebuild', None)
            if callable(schedule):
                schedule()
        except Exception:
            pass
    finally:
        _RESTORING_SAVED_TOOLS = False
    return loaded


def _restore_saved_loaded_tools_timer():
    global _RESTORE_TIMER
    _RESTORE_TIMER = None
    try:
        restore_saved_loaded_tools(getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def schedule_saved_loaded_tools_restore(context=None, *, first_interval: float = 0.15) -> None:
    global _RESTORE_TIMER
    if not get_records():
        return
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        restore_saved_loaded_tools(context)
        return
    _RESTORE_TIMER = _restore_saved_loaded_tools_timer
    try:
        if timers.is_registered(_RESTORE_TIMER):
            return
    except Exception:
        pass
    try:
        timers.register(_RESTORE_TIMER, first_interval=max(0.0, float(first_interval)))
    except Exception:
        try:
            restore_saved_loaded_tools(context)
        except Exception:
            pass


def cancel_saved_loaded_tools_restore() -> None:
    global _RESTORE_TIMER
    timer = _RESTORE_TIMER
    _RESTORE_TIMER = None
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timer is None or timers is None:
        return
    try:
        if timers.is_registered(timer):
            timers.unregister(timer)
    except Exception:
        pass

def _import_module_for_spec(spec: dict[str, Any], *, force_reload: bool = False):
    module_name = _module_name_for_spec(spec)
    importlib.invalidate_caches()
    module = importlib.import_module(module_name)
    if force_reload:
        module = importlib.reload(module)
    return module



def load_alias(alias: str, *, force: bool = False) -> dict[str, Any] | None:
    alias = str(alias or '').strip()
    record = get_record(alias)
    if record is None:
        return None

    status = str(record.get('status') or '')
    if status == 'loaded' and record.get('module') is not None:
        return record
    if status in {'disabled', 'unsupported_platform'}:
        return record

    spec = dict(record.get('spec') or {})
    module = None
    captured: list[type] = []
    _settings_guard = None
    try:
        try:
            from . import settings as _settings_guard
            _settings_guard.begin_registration()
        except Exception:
            _settings_guard = None
        module = _import_module_for_spec(spec, force_reload=bool(force or status == 'failed'))
        register_fn = getattr(module, 'register', None)
        _ft_alias = str((spec.get('alias') if isinstance(spec, dict) else '') or globals().get('alias', '') or 'integrated_tool').strip()
        _ft_label = str((spec.get('display_name') if isinstance(spec, dict) else '') or _ft_alias or 'Integrated Tool').strip()
        # Load the selected tool only on demand. During that load, record
        # Blender handlers and hotkeys added by the tool and immediately remove
        # them unless the matching entry in "Always-on toggles" is enabled.
        # Timer, msgbus, and draw-handler monkey-patching remains disabled inside
        # feature_toggle, so this keeps Blender 5.x startup safe while
        # still preventing disabled background hooks from staying active.
        if callable(register_fn):
            with _feature_toggle.capture_runtime(_ft_alias, _ft_label):
                captured = _capture_registered_classes(register_fn)
        try:
            from .translation import localize_class_attributes
            localize_class_attributes(captured)
        except Exception:
            pass
        panels, operators, menus, prefs = _categorize_classes(captured)
        _hide_original_panels(panels)
        record['module'] = module
        record['registered_classes'] = captured
        record['panels'] = panels
        record['operators'] = operators
        record['menus'] = menus
        record['preferences'] = prefs
        record['error'] = ''
        record['status'] = 'loaded'
        try:
            from . import controls as _controls
            from . import settings as _settings

            context = getattr(bpy, 'context', None)
            _settings.apply_context(context, force=True)
            _controls.enforce_known_controls(context, load_missing=False)
            try:
                _settings.refresh_change_subscriptions()
            except Exception:
                pass
            _settings.snapshot_context(context, force=_settings.is_npanel_state_save_enabled(context))
        except Exception:
            pass
    except Exception as exc:
        if module is not None:
            try:
                unregister_fn = getattr(module, 'unregister', None)
                if callable(unregister_fn):
                    unregister_fn()
            except Exception:
                pass
        for cls in reversed(captured):
            _safe_unregister_class(cls)
        record['module'] = None
        record['registered_classes'] = []
        record['panels'] = []
        record['operators'] = []
        record['menus'] = []
        record['preferences'] = []
        record['error'] = f'{exc}\n{traceback.format_exc()}'
        record['status'] = 'failed'
    finally:
        if _settings_guard is not None:
            try:
                _settings_guard.end_registration(getattr(bpy, 'context', None))
            except Exception:
                pass
    if str(record.get('status') or '') == 'loaded':
        try:
            from . import settings as _settings
            _settings.reload_and_apply_canonical_settings(getattr(bpy, 'context', None))
        except Exception:
            pass
    return record



def unregister_all() -> None:
    cancel_saved_loaded_tools_restore()
    try:
        from . import settings as _settings
        _settings.snapshot_context(getattr(bpy, 'context', None), force=True)
    except Exception:
        pass
    try:
        _feature_toggle.unregister_all()
    except Exception:
        pass
    for record in reversed(_RECORDS):
        module = record.get('module')
        if module is not None:
            try:
                unregister_fn = getattr(module, 'unregister', None)
                if callable(unregister_fn):
                    unregister_fn()
            except Exception:
                pass
    _restore_hidden_panels()
    clear_records()
    registry.clear_cache()
