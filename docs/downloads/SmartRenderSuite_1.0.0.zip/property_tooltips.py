# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import inspect
import os
from functools import wraps
from typing import Any, Callable

import bpy

_PACKAGE_ROOT = os.path.normcase(os.path.normpath(os.path.dirname(__file__)))
_FACTORY_NAMES = (
    'BoolProperty',
    'StringProperty',
    'EnumProperty',
    'IntProperty',
    'FloatProperty',
    'FloatVectorProperty',
)
_ORIGINALS: dict[str, Callable[..., Any]] = {}


def _caller_is_inside_package() -> bool:
    frame = inspect.currentframe()
    try:
        # current -> _caller_is_inside_package -> _wrapped -> property caller
        caller = None
        if frame is not None and frame.f_back is not None and frame.f_back.f_back is not None:
            caller = frame.f_back.f_back.f_back
        filename = str(getattr(getattr(caller, 'f_code', None), 'co_filename', '') or '')
        if not filename:
            return False
        filename_norm = os.path.normcase(os.path.normpath(filename))
        return filename_norm == _PACKAGE_ROOT or filename_norm.startswith(_PACKAGE_ROOT + os.sep)
    except Exception:
        return False
    finally:
        del frame


def _label_from_kwargs(kwargs: dict[str, Any], factory_name: str) -> str:
    for key in ('name', 'text', 'label'):
        value = kwargs.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return factory_name.replace('Property', '').replace('Vector', ' Vector') or 'Setting'


def _description_for(factory_name: str, label: str) -> str:
    try:
        from .translation import tooltip
        kind_en = factory_name.replace('Property', '').replace('Vector', ' vector').lower()
        if factory_name == 'BoolProperty':
            return tooltip(
                f'「{label}」のオン / オフを切り替えます。',
                f'Turns “{label}” on or off.',
                usage_ja='Nパネルまたはオペレーター設定でチェックを入れると有効、外すと無効になります。変更後は関連する表示・処理・保存内容に反映されます。',
                usage_en='Enable it by checking the option in the N-panel or operator settings, and disable it by clearing the check box. The change is applied to the related display, operation, or saved state.',
                tip_ja='影響範囲が分からない場合は、現在のシーンで結果を確認しながら1項目ずつ切り替えてください。',
                tip_en='If the effect is unclear, toggle one option at a time and check the result in the current scene.',
            )
        if factory_name == 'EnumProperty':
            return tooltip(
                f'「{label}」で使用する方式・対象・表示状態を選択します。',
                f'Selects the mode, target, or display state used by “{label}”.',
                usage_ja='ドロップダウンから目的に合う項目を選びます。選択内容は関連する処理、表示、または出力に反映されます。',
                usage_en='Choose the option that matches your goal from the drop-down menu. The selected value affects the related operation, display, or output.',
                tip_ja='迷った場合は既定値のまま動作を確認し、必要な時だけ変更してください。',
                tip_en='When unsure, test the default value first and change it only when needed.',
            )
        if factory_name in {'IntProperty', 'FloatProperty', 'FloatVectorProperty'}:
            return tooltip(
                f'「{label}」の数値を設定します。',
                f'Sets the numeric value for “{label}”.',
                usage_ja='数値欄へ直接入力するか、ドラッグ操作で値を調整します。大きく変更する前に現在値を確認してください。',
                usage_en='Enter a value directly or drag the numeric field to adjust it. Check the current value before making large changes.',
                tip_ja='結果が強く変わる場合があるため、少しずつ変更すると調整しやすくなります。',
                tip_en='Small incremental changes make it easier to tune the result when the value has a strong effect.',
            )
        return tooltip(
            f'「{label}」の{text_kind_ja(factory_name)}を設定します。',
            f'Sets the {kind_en} value for “{label}”.',
            usage_ja='入力欄に必要な値を設定します。ファイル名・パス・検索文字列の場合は、誤入力がないか確認してください。',
            usage_en='Enter the required value in the field. For file names, paths, and search text, check the text carefully before running related actions.',
            tip_ja='空欄に戻すと既定動作または未指定状態として扱われる項目があります。',
            tip_en='Some fields return to their default or unspecified behavior when left blank.',
        )
    except Exception:
        return f'Sets {label}.'


def text_kind_ja(factory_name: str) -> str:
    if factory_name == 'StringProperty':
        return '文字列'
    if factory_name == 'FloatVectorProperty':
        return '数値ベクトル'
    return '値'


def _wrap_factory(factory_name: str, original: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(original)
    def _wrapped(*args: Any, **kwargs: Any) -> Any:
        if 'description' not in kwargs and _caller_is_inside_package():
            patched = dict(kwargs)
            patched['description'] = _description_for(factory_name, _label_from_kwargs(patched, factory_name))
            kwargs = patched
        return original(*args, **kwargs)

    setattr(_wrapped, '_srs_original', original)
    return _wrapped


def install() -> None:
    props = getattr(bpy, 'props', None)
    if props is None:
        return
    for factory_name in _FACTORY_NAMES:
        try:
            current = getattr(props, factory_name, None)
            if not callable(current):
                continue
            if getattr(current, '_srs_property_tooltip_wrapper', False):
                continue
            _ORIGINALS.setdefault(factory_name, current)
            wrapped = _wrap_factory(factory_name, current)
            setattr(wrapped, '_srs_property_tooltip_wrapper', True)
            setattr(props, factory_name, wrapped)
        except Exception:
            continue
