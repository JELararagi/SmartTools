from __future__ import annotations

from typing import Dict, List


ENGINE_NORMALIZATION = {
    "KEEP": "CYCLES",
    "SCENE": "CYCLES",
    "CYCLES": "CYCLES",
    "EEVEE": "BLENDER_EEVEE_NEXT",
    "BLENDER_EEVEE": "BLENDER_EEVEE_NEXT",
    "BLENDER_EEVEE_NEXT": "BLENDER_EEVEE_NEXT",
    "WORKBENCH": "BLENDER_WORKBENCH",
    "BLENDER_WORKBENCH": "BLENDER_WORKBENCH",
}


def supported_targets() -> List[str]:
    return [
        "GENERIC",
        "MAYA_RENDER_SETUP",
        "MAX_STATE_SETS",
        "BACKBURNER",
        "C4D_TAKES",
        "TEAM_RENDER",
        "HOUDINI_SOLARIS",
        "USD_HYDRA",
        "UNREAL_MRQ",
        "UNITY_RECORDER",
        "KATANA",
        "CLARISSE_IFX",
        "GOLAEM",
        "CROWDRENDER",
        "DEADLINE",
        "FLAMENCO",
        "ROYAL_RENDER",
        "QUBE",
        "SMEDGE",
        "TRACTOR",
        "GRIDMARKETS",
        "DROP_AND_RENDER",
        "PRISM_PIPELINE",
        "REBUSFARM",
        "SHEEPIT",
        "FOX_RENDERFARM",
        "GARAGEFARM",
        "IRENDER",
        "RANCH_COMPUTING",
        "RENDER_NETWORK",
    ]



def _variant_map(manifest: Dict[str, object]) -> Dict[str, dict]:
    result = {}
    for variant in manifest.get("variants", []) or []:
        if isinstance(variant, dict) and variant.get("name"):
            result[str(variant["name"])] = variant
    return result



def _coerce_int(value, default: int) -> int:
    try:
        if value is None or value == "":
            return int(default)
        return int(value)
    except Exception:
        return int(default)



def _normalize_engine_identifier(value: str, fallback: str = "CYCLES") -> str:
    token = str(value or "").strip().upper()
    if not token:
        return fallback
    return ENGINE_NORMALIZATION.get(token, token)



def _frame_spec_string(frame_spec: Dict[str, object], *, blender_cli: bool = False) -> str:
    mode = str(frame_spec.get("mode", "CURRENT"))
    if mode == "CURRENT":
        frame = frame_spec.get("frame_current")
        if frame is None:
            frame = frame_spec.get("start", 1)
        return str(_coerce_int(frame, 1))
    start = _coerce_int(frame_spec.get("start", 1), 1)
    end = _coerce_int(frame_spec.get("end", start), start)
    if start == end:
        return str(start)
    separator = ".." if blender_cli else "-"
    return f"{start}{separator}{end}"



def _background_command(blend_file: str, renderer: str, output_root: str, frames: str) -> str:
    blend_token = blend_file or "<save .blend first>"
    renderer_token = _normalize_engine_identifier(renderer or "CYCLES")
    output_token = output_root or "<output root>"
    frame_token = frames or "1"
    return f'blender -b "{blend_token}" -E {renderer_token} --render-output "{output_token}" --render-frame {frame_token}'



def _merge_execution(manifest: Dict[str, object], source: Dict[str, object]) -> Dict[str, object]:
    base = dict((manifest.get("execution", {}) or {}))
    if isinstance(source, dict):
        for key, value in source.items():
            base[key] = value
    return base



def _jobs(manifest: Dict[str, object]) -> List[dict]:
    variants = _variant_map(manifest)
    jobs: List[dict] = []
    batch = manifest.get("batch", {}) or {}
    execution = manifest.get("execution", {}) or {}
    resolved_queue = manifest.get("resolved_queue", []) or []
    sources = resolved_queue if resolved_queue else (manifest.get("queue", []) or [])
    default_frame = batch.get("custom_frame_start", 1)
    default_output_root = str((manifest.get("output", {}) or {}).get("root", ""))
    default_engine = str((manifest.get("profile", {}) or {}).get("actual_engine_identifier", "") or (manifest.get("profile", {}) or {}).get("engine_mode", "CYCLES"))

    for source in sources:
        if not isinstance(source, dict):
            continue
        variant_name = str(source.get("variant", "") or source.get("variant_name", ""))
        variant = variants.get(variant_name, {})
        frames_list = source.get("frames") if isinstance(source.get("frames"), list) else None
        if frames_list:
            start = _coerce_int(min(frames_list), default_frame)
            end = _coerce_int(max(frames_list), start)
            frame_spec = {
                "mode": "CURRENT" if len(frames_list) == 1 else "CUSTOM",
                "start": start,
                "end": end,
                "frame_current": start,
            }
        else:
            frame_spec = {
                "mode": batch.get("frame_mode", "CURRENT"),
                "start": batch.get("custom_frame_start", default_frame),
                "end": batch.get("custom_frame_end", batch.get("custom_frame_start", default_frame)),
                "frame_current": batch.get("custom_frame_start", default_frame),
            }
            if variant.get("use_custom_frames"):
                frame_spec = {
                    "mode": "CUSTOM",
                    "start": variant.get("frame_start", default_frame),
                    "end": variant.get("frame_end", variant.get("frame_start", default_frame)),
                    "frame_current": variant.get("frame_start", default_frame),
                }
        camera_name = source.get("camera", "") or source.get("camera_name", "") or variant.get("camera_name", "")
        view_layer_name = source.get("view_layer", "") or source.get("view_layer_name", "") or variant.get("view_layer_name", "")
        frame_string = _frame_spec_string(frame_spec)
        cli_frame_string = _frame_spec_string(frame_spec, blender_cli=True)
        engine_identifier = _normalize_engine_identifier(str(source.get("engine_identifier", "") or default_engine))
        output_directory = str(source.get("output_directory", "") or default_output_root)
        background_command = str(source.get("background_command", "") or _background_command(
            str(manifest.get("blend_file", "")),
            engine_identifier,
            output_directory,
            cli_frame_string,
        ))
        resource_profile = _merge_execution(manifest, source.get("resource_profile", {}) or {})
        frame_chunks = []
        for chunk in source.get("frame_chunks", []) or []:
            if not isinstance(chunk, dict):
                continue
            frame_chunks.append(dict(chunk))
        chunk_commands = []
        for chunk in source.get("chunk_commands", []) or []:
            if not isinstance(chunk, dict):
                continue
            chunk_commands.append(dict(chunk))
        if not chunk_commands and frame_chunks:
            for chunk in frame_chunks:
                chunk_commands.append(
                    {
                        "label": f"{source.get('label', variant_name or camera_name or 'job')} [chunk {chunk.get('chunk_index', chunk.get('index', 1))}/{chunk.get('chunk_total', len(frame_chunks))}]",
                        "background_command": _background_command(
                            str(manifest.get("blend_file", "")),
                            engine_identifier,
                            output_directory,
                            str(chunk.get("blender_cli_frames", chunk.get("frames_string", frame_string))),
                        ),
                        **chunk,
                    }
                )
        label = source.get("label") or variant_name or f"{camera_name}|{view_layer_name}"
        variant_chain = list(source.get("variant_chain", []) or variant.get("variant_chain", []) or ([variant_name] if variant_name else []))
        jobs.append(
            {
                "name": label,
                "enabled": bool(source.get("enabled", True)),
                "source_mode": source.get("source_mode", "PAIR"),
                "camera": camera_name,
                "view_layer": view_layer_name,
                "variant": variant_name,
                "parent_variant": source.get("parent_variant", "") or variant.get("parent_variant", "") or variant.get("parent_variant_name", ""),
                "variant_chain": variant_chain,
                "variant_path": source.get("variant_path", "") or variant.get("variant_path", "") or "/".join(variant_chain),
                "frames": frame_spec,
                "frames_string": frame_string,
                "blender_cli_frames": cli_frame_string,
                "frame_start": _coerce_int(source.get("frame_start", frame_spec.get("start", default_frame)), frame_spec.get("start", default_frame)),
                "frame_end": _coerce_int(source.get("frame_end", frame_spec.get("end", default_frame)), frame_spec.get("end", default_frame)),
                "frame_count": _coerce_int(source.get("frame_count", source.get("count", 1)), 1),
                "job_name": source.get("job_name", resource_profile.get("job_name", "")),
                "job_tags": list(source.get("job_tags", resource_profile.get("job_tags", [])) or []),
                "pass_bundle": source.get("pass_bundle", variant.get("pass_bundle", (manifest.get("profile", {}) or {}).get("pass_bundle", "ESSENTIAL"))),
                "image_format": source.get("image_format", (manifest.get("output", {}) or {}).get("image_format", "PNG")),
                "world": source.get("world", variant.get("world_override_name", "")),
                "material": source.get("material", variant.get("material_override_name", "")),
                "view_transform": source.get("view_transform", ""),
                "look": source.get("look", ""),
                "output_tokens": dict(source.get("output_tokens", {}) or {}),
                "variant_overrides": variant,
                "background_command": background_command,
                "engine_identifier": engine_identifier,
                "output_directory": output_directory,
                "first_output": source.get("first_output", ""),
                "resource_profile": resource_profile,
                "frame_chunks": frame_chunks,
                "chunk_commands": chunk_commands,
                "verification": dict(source.get("verification", {}) or {}),
                "render_elements": dict(source.get("render_elements", manifest.get("render_elements", {}) or {})),
            }
        )
    return jobs



def _base(manifest: Dict[str, object], target: str) -> Dict[str, object]:
    profile = manifest.get("profile", {}) or {}
    output = manifest.get("output", {}) or {}
    execution = manifest.get("execution", {}) or {}
    jobs = _jobs(manifest)
    engine_identifier = _normalize_engine_identifier(str(profile.get("actual_engine_identifier", "") or profile.get("engine_mode", "CYCLES")))
    return {
        "source_tool": manifest.get("tool", "Smart Render"),
        "source_schema": manifest.get("schema_version", "unknown"),
        "source_version": manifest.get("version", []),
        "generated_at": manifest.get("generated_at", ""),
        "target": target,
        "scene": manifest.get("scene", ""),
        "blend_file": manifest.get("blend_file", ""),
        "profile": profile,
        "output": output,
        "execution": execution,
        "verification": manifest.get("verification", {}) or {},
        "render_elements": manifest.get("render_elements", {}) or {},
        "network_render": manifest.get("network_render", {}) or {},
        "post_tasks": manifest.get("post_tasks", {}) or {},
        "task_graph": manifest.get("task_graph", {}) or {},
        "token_reference": list(((manifest.get("token_examples", {}) or {}).get("token_reference", []) or [])),
        "jobs": jobs,
        "headless_blender_command": _background_command(
            str(manifest.get("blend_file", "")),
            engine_identifier,
            str(output.get("root", "")),
            ",".join(job.get("blender_cli_frames", job.get("frames_string", "1")) for job in jobs[:4]) if jobs else "1",
        ),
        "notes": [
            "This export is a bridge manifest, not direct remote execution.",
            "Variant overrides, output tokens, execution hints, and queue intent are normalized for downstream adapters.",
            "A PDG-style dependency graph is included when resolved queue data is available.",
        ],
    }



def _quality_samples(quality: str, execution: Dict[str, object] | None = None) -> Dict[str, int]:
    quality = str(quality or "PREVIEW").upper()
    execution = execution or {}
    defaults = {
        "temporal_samples": {"DRAFT": 1, "PREVIEW": 4, "FINAL": 8}.get(quality, 4),
        "spatial_samples": {"DRAFT": 1, "PREVIEW": 1, "FINAL": 4}.get(quality, 1),
        "accumulation_samples": {"DRAFT": 1, "PREVIEW": 8, "FINAL": 16}.get(quality, 8),
    }
    defaults["temporal_samples"] = max(1, _coerce_int(execution.get("temporal_subsamples", defaults["temporal_samples"]), defaults["temporal_samples"]))
    defaults["spatial_samples"] = max(1, _coerce_int(execution.get("spatial_subsamples", defaults["spatial_samples"]), defaults["spatial_samples"]))
    defaults["accumulation_samples"] = max(1, _coerce_int(execution.get("accumulation_samples", defaults["accumulation_samples"]), defaults["accumulation_samples"]))
    return defaults



def _farm_payload(base: Dict[str, object], vendor: str, queue_key: str = "jobs") -> Dict[str, object]:
    output = base.get("output", {}) or {}
    execution = base.get("execution", {}) or {}
    return {
        "vendor": vendor,
        "blend_file": base.get("blend_file", ""),
        "output_root": output.get("root", ""),
        "image_format": output.get("image_format", "PNG"),
        "render_engine": _normalize_engine_identifier((base.get("profile", {}) or {}).get("actual_engine_identifier", "") or (base.get("profile", {}) or {}).get("engine_mode", "CYCLES")),
        "submission_preview": base.get("headless_blender_command", ""),
        "execution": execution,
        "task_graph": base.get("task_graph", {}) or {},
        "render_elements": base.get("render_elements", {}) or {},
        "network_render": base.get("network_render", {}) or {},
        queue_key: base.get("jobs", []),
    }



def build_bridge_export(manifest: Dict[str, object], target: str) -> Dict[str, object]:
    target = str(target or "GENERIC")
    base = _base(manifest, target)
    profile = manifest.get("profile", {}) or {}
    output = manifest.get("output", {}) or {}
    batch = manifest.get("batch", {}) or {}
    execution = base.get("execution", {}) or {}

    if target == "GENERIC":
        return base

    if target == "MAYA_RENDER_SETUP":
        base["maya_render_setup"] = {
            "render_setup_layers": [job["name"] for job in base["jobs"]],
            "aov_bundle": profile.get("pass_bundle", "ESSENTIAL"),
            "output_rules": output,
            "execution_hints": execution,
            "non_destructive_overrides": [
                "camera selection",
                "view layer selection",
                "material override",
                "world override",
                "collection include/exclude/holdout/indirect_only",
                "object render visibility show/hide selectors",
                "proxy/render representation switching",
            ],
        }
        return base

    if target == "MAX_STATE_SETS":
        base["max_state_sets"] = {
            "state_sets": [job["name"] for job in base["jobs"]],
            "batch_render": {
                "frame_mode": batch.get("frame_mode", "CURRENT"),
                "output_tokens": output,
            },
            "render_elements_bundle": profile.get("pass_bundle", "ESSENTIAL"),
            "render_elements": base.get("render_elements", {}) or {},
            "execution_hints": execution,
        }
        return base

    if target == "BACKBURNER":
        base["backburner"] = {
            "job_name": manifest.get("scene", "Smart Render Job"),
            "manager_roles": ["Manager", "Server", "Monitor"],
            "network_submission": {
                "blend_file": manifest.get("blend_file", ""),
                "output_root": output.get("root", ""),
                "frames": [job.get("frames_string", "1") for job in base["jobs"]],
                "priority": execution.get("farm_priority", 50),
                "chunk_size": execution.get("frame_chunk_size", 1),
            },
            "jobs": base["jobs"],
        }
        return base

    if target == "C4D_TAKES":
        base["cinema4d_takes"] = {
            "takes": [job["name"] for job in base["jobs"]],
            "token_system": {
                "dir_pattern": output.get("dir_pattern", ""),
                "file_pattern": output.get("file_pattern", ""),
            },
            "render_queue": base["jobs"],
            "execution_hints": execution,
            "team_render_ready": True,
        }
        return base

    if target == "TEAM_RENDER":
        base["team_render"] = {
            "mode": "peer_to_peer_lan",
            "render_queue": base["jobs"],
            "team_render_server_ready": True,
            "output": output,
            "execution_hints": execution,
            "notes": [
                "Use inside the Cinema 4D ecosystem.",
                "Normalized from Smart Render queue, variants, output rules, and execution hints.",
            ],
        }
        return base

    if target == "HOUDINI_SOLARIS":
        base["houdini"] = {
            "takes": [job["name"] for job in base["jobs"]],
            "solaris_lops": {
                "render_settings": profile,
                "variant_overrides": [job.get("variant_overrides", {}) for job in base["jobs"]],
                "execution_hints": execution,
            },
            "pdg_work_items": [
                {
                    "name": job["name"],
                    "camera": job["camera"],
                    "view_layer": job["view_layer"],
                    "frames": job["frames"],
                    "frame_chunks": job.get("frame_chunks", []),
                    "resource_profile": job.get("resource_profile", execution),
                }
                for job in base["jobs"]
            ],
            "task_graph": base.get("task_graph", {}) or {},
            "tops_post_tasks": [
                {"tool": "FFmpeg", "purpose": "video_encode", "enabled_by_default": False},
                {"tool": "ImageMagick", "purpose": "contact_sheet", "enabled_by_default": False},
                {"tool": "Python", "purpose": "custom_task_graph", "enabled_by_default": True},
            ],
        }
        return base

    if target == "USD_HYDRA":
        base["usd_hydra"] = {
            "render_settings": {
                "engine_mode": profile.get("engine_mode", "KEEP"),
                "quality_mode": profile.get("quality_mode", "PREVIEW"),
                "resolution_percentage": profile.get("resolution_percentage", 100),
                "sampling_hints": _quality_samples(str(profile.get("quality_mode", "PREVIEW")), execution),
            },
            "products": {
                "root": output.get("root", ""),
                "dir_pattern": output.get("dir_pattern", ""),
                "file_pattern": output.get("file_pattern", ""),
            },
            "aov_bundle": profile.get("pass_bundle", "ESSENTIAL"),
            "hydra_delegate_candidates": ["Karma", "Arnold", "Redshift", "RenderMan"],
            "execution_hints": execution,
        }
        return base

    if target == "UNREAL_MRQ":
        samples = _quality_samples(str(profile.get("quality_mode", "PREVIEW")), execution)
        base["unreal_movie_render_queue"] = {
            "queue": base["jobs"],
            "anti_aliasing": {
                "temporal_samples": samples["temporal_samples"],
                "spatial_samples": samples["spatial_samples"],
            },
            "accumulation_samples": samples["accumulation_samples"],
            "output": output,
            "pass_bundle": profile.get("pass_bundle", "ESSENTIAL"),
            "console_variable_overrides": [],
            "execution_hints": execution,
        }
        return base

    if target == "UNITY_RECORDER":
        samples = _quality_samples(str(profile.get("quality_mode", "PREVIEW")), execution)
        recorders = [
            {
                "type": "ImageSequence",
                "format": output.get("image_format", "PNG"),
                "path": output.get("root", ""),
            }
        ]
        if bool(output.get("movie_encode_enabled", False)):
            recorders.append(
                {
                    "type": "Movie",
                    "format": output.get("movie_preset", "H264_MP4"),
                    "path": output.get("root", ""),
                }
            )
        base["unity_recorder"] = {
            "recorders": recorders,
            "accumulation": samples["accumulation_samples"],
            "aov_bundle": profile.get("pass_bundle", "ESSENTIAL"),
            "jobs": base["jobs"],
            "execution_hints": execution,
        }
        return base

    if target == "KATANA":
        base["katana"] = {
            "look_files": [job["name"] for job in base["jobs"]],
            "livegroups": ["lighting", "lookdev", "render_settings"],
            "render_outputs": output,
            "variants": manifest.get("variants", []),
            "execution_hints": execution,
            "jobs": base["jobs"],
        }
        return base

    if target == "CLARISSE_IFX":
        base["clarisse_ifx"] = {
            "progressive_rendering": True,
            "in_place_comp": True,
            "assembly_style": "reference-heavy",
            "execution_hints": execution,
            "output": output,
            "jobs": base["jobs"],
        }
        return base

    if target == "GOLAEM":
        base["golaem"] = {
            "crowd_render_validation": {
                "check_render_settings": True,
                "expected_checks": [
                    "CrowdManager present",
                    "CacheProxy replay mode",
                    "CrowdField assignments",
                    "simulation cache paths",
                ],
            },
            "execution_hints": execution,
            "jobs": base["jobs"],
        }
        return base

    if target == "CROWDRENDER":
        base["crowdrender"] = {
            "distributed_preview": True,
            "distributed_final_render": True,
            "transport": ["LAN", "P2P", "Internet"],
            "execution_hints": execution,
            "jobs": base["jobs"],
        }
        return base

    if target == "DEADLINE":
        frames_value = ",".join(job.get("frames_string", "1") for job in base["jobs"]) if base["jobs"] else _frame_spec_string({
            "mode": batch.get("frame_mode", "CURRENT"),
            "start": batch.get("custom_frame_start", 1),
            "end": batch.get("custom_frame_end", 1),
        })
        base["deadline"] = {
            "job_info": {
                "Name": manifest.get("scene", "Smart Render Job"),
                "Frames": frames_value,
                "OutputDirectory0": output.get("root", ""),
                "Priority": execution.get("farm_priority", 50),
                "ChunkSize": execution.get("frame_chunk_size", 1),
                "ConcurrentTasks": execution.get("concurrent_tasks", 1),
            },
            "plugin_info": {
                "SceneFile": manifest.get("blend_file", ""),
                "Renderer": _normalize_engine_identifier(profile.get("actual_engine_identifier", "") or profile.get("engine_mode", "CYCLES")),
                "DeviceMode": execution.get("device_mode", "AUTO"),
            },
            "jobs": base["jobs"],
        }
        return base

    if target == "FLAMENCO":
        base["flamenco"] = {
            "job_type": "blender-render",
            "blend_file": manifest.get("blend_file", ""),
            "output": output,
            "execution_hints": execution,
            "queue": base["jobs"],
        }
        return base

    if target == "ROYAL_RENDER":
        base["royal_render"] = _farm_payload(base, "Royal Render", queue_key="rr_jobs")
        base["royal_render"]["retry_hint"] = "favor_resume_and_retry"
        return base

    if target == "QUBE":
        base["qube"] = _farm_payload(base, "PipelineFX Qube!", queue_key="qube_jobs")
        base["qube"]["scheduler_capabilities"] = ["dependencies", "priority", "resource_groups"]
        return base

    if target == "SMEDGE":
        base["smedge"] = _farm_payload(base, "Smedge", queue_key="smedge_jobs")
        base["smedge"]["mixed_os_ready"] = True
        return base

    if target == "TRACTOR":
        tasks = []
        task_graph = base.get("task_graph", {}) or {}
        graph_nodes = [node for node in (task_graph.get("nodes", []) or []) if isinstance(node, dict)]
        if graph_nodes:
            for node in graph_nodes:
                command = str(node.get("command", "") or node.get("command_preview", "") or "").strip()
                tasks.append(
                    {
                        "id": str(node.get("id", "") or ""),
                        "title": str(node.get("label", "") or node.get("job_label", "") or node.get("id", "node")),
                        "type": str(node.get("type", "task") or "task"),
                        "argv": ([command] if command else []),
                        "depends_on": list(node.get("dependencies", []) or []),
                        "serialsubtasks": False,
                        "resource_profile": node.get("resource_profile", execution) or execution,
                    }
                )
        else:
            for job in base["jobs"]:
                chunks = job.get("chunk_commands", []) or []
                if chunks:
                    for chunk in chunks:
                        tasks.append(
                            {
                                "title": chunk.get("label", job["name"]),
                                "argv": [chunk.get("background_command", job.get("background_command", "") or base.get("headless_blender_command", ""))],
                                "serialsubtasks": False,
                                "resource_profile": job.get("resource_profile", execution),
                            }
                        )
                else:
                    tasks.append(
                        {
                            "title": job["name"],
                            "argv": [job.get("background_command", "") or base.get("headless_blender_command", "")],
                            "serialsubtasks": False,
                            "resource_profile": job.get("resource_profile", execution),
                        }
                    )
        base["tractor"] = {
            "job": {
                "title": manifest.get("scene", "Smart Render Tractor Job"),
                "priority": execution.get("farm_priority", 50),
                "tasks": tasks,
                "task_graph_summary": dict((task_graph.get("summary", {}) or {})),
            },
            "jobs": base["jobs"],
            "task_graph": task_graph,
        }
        return base

    if target == "GRIDMARKETS":
        base["gridmarkets"] = _farm_payload(base, "GridMarkets")
        base["gridmarkets"]["tops_pdg_ready"] = True
        base["gridmarkets"]["supports"] = ["TOPs", "PDG", "LOPs", "Solaris"]
        base["gridmarkets"]["task_graph_summary"] = dict(((base.get("task_graph", {}) or {}).get("summary", {}) or {}))
        return base

    if target == "DROP_AND_RENDER":
        base["drop_and_render"] = _farm_payload(base, "Drop & Render")
        base["drop_and_render"]["tops_pdg_ready"] = True
        base["drop_and_render"]["supports"] = ["TOPs", "PDG", "dependency_graph", "resume_failed_work_items"]
        base["drop_and_render"]["task_graph_summary"] = dict(((base.get("task_graph", {}) or {}).get("summary", {}) or {}))
        return base

    if target == "PRISM_PIPELINE":
        base["prism_pipeline"] = {
            "project_metadata": {
                "scene": manifest.get("scene", ""),
                "blend_file": manifest.get("blend_file", ""),
                "generated_at": manifest.get("generated_at", ""),
            },
            "render_settings": profile,
            "execution_hints": execution,
            "output_settings": output,
            "variants": manifest.get("variants", []),
            "jobs": base["jobs"],
            "task_graph": base.get("task_graph", {}) or {},
        }
        return base

    if target == "REBUSFARM":
        base["rebusfarm"] = _farm_payload(base, "RebusFarm")
        return base

    if target == "SHEEPIT":
        base["sheepit"] = _farm_payload(base, "SheepIt")
        base["sheepit"]["community_queue"] = True
        return base

    if target == "FOX_RENDERFARM":
        base["fox_renderfarm"] = _farm_payload(base, "Fox Renderfarm")
        return base

    if target == "GARAGEFARM":
        base["garagefarm"] = _farm_payload(base, "GarageFarm")
        return base

    if target == "IRENDER":
        base["irender"] = _farm_payload(base, "iRender")
        base["irender"]["gpu_farm_ready"] = True
        return base

    if target == "RANCH_COMPUTING":
        base["ranch_computing"] = _farm_payload(base, "Ranch Computing")
        return base

    if target == "RENDER_NETWORK":
        base["render_network"] = _farm_payload(base, "Render Network")
        base["render_network"]["nested_scene_ready"] = True
        return base

    return base
