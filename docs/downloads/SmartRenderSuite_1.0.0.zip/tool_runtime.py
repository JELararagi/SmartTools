# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

from . import loader as loader, ui_runtime as ui_runtime


def register() -> None:
    loader.register_all()
    ui_runtime.register()
    # Saved tool inventory is retained in JSON, but modules are not imported at
    # startup.  A tool loads only through its explicit UI action or an enabled
    # Always-on control, keeping the all-OFF/idle state free of tool runtimes.
    loader.cancel_saved_loaded_tools_restore()


def unregister() -> None:
    ui_runtime.unregister()
    loader.unregister_all()
