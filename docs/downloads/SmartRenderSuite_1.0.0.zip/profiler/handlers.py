

def _smarttools_console_output(*_args, **_kwargs):
    return None
import time
import bpy  # type: ignore

from bpy.app.handlers import persistent  # type: ignore
from . import properties
from .server_controller import get_and_clear_pending_mode, get_report_state, set_report_state
from .utils import build_html_report


_last_viewport_update: float = 0.0
_VIEWPORT_THROTTLE_SEC = 1.0
_timer_stop = False
_RUNTIME_HOOKS_ACTIVE = False


def _get_report_mode() -> str:
    """Current report mode from WindowManager (OFF, VIEWPORT, RENDER)."""
    try:
        wm = getattr(bpy.context, "window_manager", None)
        profiler = getattr(wm, "profiler", None) if wm is not None else None
        value = str(getattr(profiler, "report_mode", properties.REPORT_MODE_OFF) or properties.REPORT_MODE_OFF)
        if value in {properties.REPORT_MODE_OFF, properties.REPORT_MODE_VIEWPORT, properties.REPORT_MODE_RENDER}:
            if value != properties.REPORT_MODE_OFF:
                # The mode selector is a persisted profiler preference; only
                # the canonical top-level Always-on toggle is allowed to turn
                # that preference into resident handlers/timers.
                try:
                    from .. import controls
                    if not bool(controls._stored_enabled('profiler', 'report_enabled', None)):
                        return properties.REPORT_MODE_OFF
                except Exception:
                    return properties.REPORT_MODE_OFF
            return value
    except Exception:
        pass
    return properties.REPORT_MODE_OFF


def _append_handler_once(handler_list, fn) -> None:
    if handler_list is None:
        return
    if fn not in handler_list:
        handler_list.append(fn)


def _remove_handler_if_present(handler_list, fn) -> None:
    if handler_list is None:
        return
    try:
        while fn in handler_list:
            handler_list.remove(fn)
    except Exception:
        pass


def _register_timer_once() -> None:
    global _timer_stop
    _timer_stop = False
    try:
        if bpy.app.timers.is_registered(_apply_pending_mode_timer):
            return
    except Exception:
        pass
    try:
        bpy.app.timers.register(_apply_pending_mode_timer, first_interval=0.50, persistent=True)
    except TypeError:
        try:
            bpy.app.timers.register(_apply_pending_mode_timer, first_interval=0.50)
        except Exception:
            pass
    except Exception:
        pass


def _unregister_timer() -> None:
    global _timer_stop
    _timer_stop = True
    try:
        if bpy.app.timers.is_registered(_apply_pending_mode_timer):
            bpy.app.timers.unregister(_apply_pending_mode_timer)
    except Exception:
        pass


def _clear_live_report_payload() -> None:
    try:
        state = get_report_state()
        state["mode"] = "off"
        state["modifiers_html"] = ""
        state["heavy_meshes_html"] = ""
        state["textures_html"] = ""
        state["statistics_html"] = ""
        state["memory_html"] = ""
        state["last_update_html"] = ""
        set_report_state(state)
    except Exception:
        pass


def sync_runtime_hooks(force: bool = False) -> None:
    """Enable callbacks only while the profiler is actually in use."""
    global _RUNTIME_HOOKS_ACTIVE
    mode = _get_report_mode()
    should_enable = mode != properties.REPORT_MODE_OFF

    if should_enable:
        _register_timer_once()
        _append_handler_once(getattr(bpy.app.handlers, "frame_change_post", None), _on_frame_change_post)
        _append_handler_once(getattr(bpy.app.handlers, "depsgraph_update_post", None), _on_depsgraph_update)
        _append_handler_once(getattr(bpy.app.handlers, "load_post", None), _on_file_load_post)
        _RUNTIME_HOOKS_ACTIVE = True
        return

    if not force and not _RUNTIME_HOOKS_ACTIVE:
        return

    _unregister_timer()
    _remove_handler_if_present(getattr(bpy.app.handlers, "frame_change_post", None), _on_frame_change_post)
    _remove_handler_if_present(getattr(bpy.app.handlers, "depsgraph_update_post", None), _on_depsgraph_update)
    _remove_handler_if_present(getattr(bpy.app.handlers, "load_post", None), _on_file_load_post)
    _RUNTIME_HOOKS_ACTIVE = False
    _clear_live_report_payload()


def _apply_pending_mode_timer() -> float | None:
    """Timer callback: apply mode chosen on the web page to Blender and push state."""
    global _timer_stop
    if _timer_stop:
        return None
    if _get_report_mode() == properties.REPORT_MODE_OFF:
        return None

    pending = get_and_clear_pending_mode()
    if pending is not None:
        try:
            wm = bpy.context.window_manager
            if wm and getattr(wm, "profiler", None):
                wm.profiler.report_mode = pending.upper() if pending != "off" else properties.REPORT_MODE_OFF
                state = get_report_state()
                state["mode"] = pending
                state["modifiers_html"] = ""
                state["heavy_meshes_html"] = ""
                state["textures_html"] = ""
                state["statistics_html"] = ""
                state["memory_html"] = ""
                state["last_update_html"] = ""
                set_report_state(state)
        except Exception as e:
            _smarttools_console_output(f"Error applying pending mode: {e}")
    return None if _get_report_mode() == properties.REPORT_MODE_OFF else 0.5


@persistent
def _on_frame_change_post(scene: bpy.types.Scene, depsgraph: bpy.types.Depsgraph) -> None:
    """Collect render data only while render profiling is active."""
    if _get_report_mode() != properties.REPORT_MODE_RENDER:
        return
    if getattr(depsgraph, "mode", None) != "RENDER":
        return

    build_html_report(depsgraph=depsgraph, scene=scene, mode="render")


@persistent
def _on_file_load_post(_file: str) -> None:
    """Update live report state when file is loaded, only if viewport profiling is active."""
    if _get_report_mode() != properties.REPORT_MODE_VIEWPORT:
        return

    try:
        depsgraph = bpy.context.evaluated_depsgraph_get()
        scene = bpy.context.scene
    except Exception:
        return

    build_html_report(depsgraph=depsgraph, scene=scene, mode="viewport")


@persistent
def _on_depsgraph_update(scene: bpy.types.Scene, depsgraph: bpy.types.Depsgraph) -> None:
    """Update live report state on dependency graph updates while viewport profiling is active."""
    if _get_report_mode() != properties.REPORT_MODE_VIEWPORT:
        return
    if getattr(depsgraph, "mode", None) != "VIEWPORT":
        return

    global _last_viewport_update
    now = time.time()
    if now - _last_viewport_update < _VIEWPORT_THROTTLE_SEC:
        return

    _last_viewport_update = now
    build_html_report(depsgraph=depsgraph, scene=scene, mode="viewport")


def register() -> None:
    sync_runtime_hooks(force=True)


def unregister() -> None:
    sync_runtime_hooks(force=True)
