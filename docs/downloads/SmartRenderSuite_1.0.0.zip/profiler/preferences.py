import bpy  # type: ignore
from ..translation import localize_inline, localize_pair


def get_report_font_size() -> float:
    """Return report font size (pixels) from runtime settings."""
    try:
        wm = getattr(bpy.context, "window_manager", None)
        runtime = getattr(wm, "profiler", None) if wm is not None else None
        if runtime is not None and hasattr(runtime, "font_size"):
            return int(getattr(runtime, "font_size", 14))
    except Exception:
        pass
    return 14


def draw_runtime_settings(layout, context) -> None:
    wm = getattr(context, "window_manager", None)
    runtime = getattr(wm, "profiler", None) if wm is not None else None
    if runtime is None:
        layout.label(text=localize_inline("Render Profiler settings are not available yet."), icon="ERROR", translate=False)
        return
    box = layout.box()
    box.label(text=localize_inline("Live Profiler Controls"), icon="PREFERENCES")
    box.prop(runtime, "font_size")
    row = box.row(align=True)
    row.operator("profiler.open_report_in_browser", text=localize_inline("Open Report"), icon="WINDOW")
    row.operator("profiler.stop_profiling", text=localize_inline("Stop"), icon="PANEL_CLOSE")


# Registration
def register():
    return None

def unregister():
    return None
