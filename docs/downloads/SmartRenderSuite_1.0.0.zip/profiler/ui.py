from ..translation import iface_text
import bpy  # type: ignore

from . import properties


_WINDOW_MENU_DRAW_REGISTERED = False
_FILE_CONTEXT_MENU_DRAW_REGISTERED = False
_TOPBAR_DRAW_REGISTERED = False


def _safe_mode(context: bpy.types.Context | None = None) -> str:
    try:
        context = context or getattr(bpy, "context", None)
        wm = getattr(context, "window_manager", None)
        profiler = getattr(wm, "profiler", None) if wm is not None else None
        mode = str(getattr(profiler, "report_mode", properties.REPORT_MODE_OFF) or properties.REPORT_MODE_OFF)
        if mode in {properties.REPORT_MODE_OFF, properties.REPORT_MODE_VIEWPORT, properties.REPORT_MODE_RENDER}:
            return mode
    except Exception:
        pass
    return properties.REPORT_MODE_OFF


def _append_draw_once(owner, fn, *, flag_name: str) -> None:
    if bool(globals().get(flag_name)):
        return
    try:
        owner.append(fn)
        globals()[flag_name] = True
    except Exception:
        pass


def _remove_draw_if_present(owner, fn, *, flag_name: str) -> None:
    remover = getattr(owner, 'remove', None)
    if callable(remover):
        for _ in range(8):
            try:
                remover(fn)
            except Exception:
                break
    globals()[flag_name] = False


def _draw_window_menu_item(self: bpy.types.Menu, context: bpy.types.Context) -> None:
    """Draw the "Render Profiler Report" menu item in the Window menu."""
    self.layout.separator()
    self.layout.operator(
        "profiler.open_report_in_browser",
        icon="WINDOW",
        text=iface_text("Render Profiler Report"),
    )
    runtime = getattr(getattr(context, "window_manager", None), "profiler", None)
    if runtime is not None and hasattr(runtime, "font_size"):
        self.layout.prop(runtime, "font_size", text=iface_text("Report font size (px)"))



def _draw_topbar_profiler(self: bpy.types.Header, context: bpy.types.Context) -> None:
    """Draw profiling indicator and actions in the top bar when profiling is active."""
    mode = _safe_mode(context)
    if mode == properties.REPORT_MODE_OFF:
        return

    region = context.region
    if region.alignment == 'RIGHT':
        return

    mode_label = iface_text(mode.title())
    row = self.layout.row(align=True)
    row.operator("profiler.open_report_in_browser", text=iface_text(f"Profiling ({mode_label})"), icon="WINDOW")
    row.operator("profiler.stop_profiling", text="", icon="PANEL_CLOSE")



def sync_runtime_ui(force: bool = False) -> None:
    """Integrated mode keeps legacy topbar UI disabled at all times."""
    _remove_draw_if_present(bpy.types.TOPBAR_HT_upper_bar, _draw_topbar_profiler, flag_name="_TOPBAR_DRAW_REGISTERED")



def register() -> None:
    # Integrated mode: Smart Tools owns the entry point, so legacy Window/File
    # menu items and the topbar profiler indicator stay disabled here.
    _remove_draw_if_present(bpy.types.TOPBAR_MT_window, _draw_window_menu_item, flag_name="_WINDOW_MENU_DRAW_REGISTERED")
    _remove_draw_if_present(bpy.types.TOPBAR_MT_file_context_menu, _draw_window_menu_item, flag_name="_FILE_CONTEXT_MENU_DRAW_REGISTERED")
    _remove_draw_if_present(bpy.types.TOPBAR_HT_upper_bar, _draw_topbar_profiler, flag_name="_TOPBAR_DRAW_REGISTERED")



def unregister() -> None:
    _remove_draw_if_present(bpy.types.TOPBAR_MT_window, _draw_window_menu_item, flag_name="_WINDOW_MENU_DRAW_REGISTERED")
    _remove_draw_if_present(bpy.types.TOPBAR_MT_file_context_menu, _draw_window_menu_item, flag_name="_FILE_CONTEXT_MENU_DRAW_REGISTERED")
    _remove_draw_if_present(bpy.types.TOPBAR_HT_upper_bar, _draw_topbar_profiler, flag_name="_TOPBAR_DRAW_REGISTERED")
