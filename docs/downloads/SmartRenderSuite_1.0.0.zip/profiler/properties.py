import bpy  # type: ignore
from bpy.props import BoolProperty, EnumProperty, IntProperty, PointerProperty  # type: ignore
from bpy.types import PropertyGroup  # type: ignore
from typing import Any

from ..translation import localize_inline, localize_pair


def _persistent_property(factory):
    def _factory(*args, **kwargs):
        options = dict(kwargs)
        previous = options.get('update')

        def _update(self, context):
            if callable(previous):
                previous(self, context)
            try:
                from .. import settings as _suite_settings
                if not _suite_settings.is_applying_context():
                    _suite_settings.snapshot_context(context, force=False)
            except Exception:
                pass

        options['update'] = _update
        return factory(*args, **options)
    return _factory


BoolProperty = _persistent_property(BoolProperty)
EnumProperty = _persistent_property(EnumProperty)
IntProperty = _persistent_property(IntProperty)


REPORT_MODE_OFF = "OFF"
REPORT_MODE_VIEWPORT = "VIEWPORT"
REPORT_MODE_RENDER = "RENDER"

REPORT_MODE_ITEMS = (
    (
        REPORT_MODE_OFF,
        localize_pair("オフ", "Off"),
        localize_pair('レンダープロファイラーのバックグラウンド更新とコールバックをすべて無効化します。通常時はこの既定状態のままにしてください。', "Disable all Render Profiler background callbacks and live updates. Keep this as the default when you are not actively profiling."),
    ),
    (
        REPORT_MODE_VIEWPORT,
        localize_pair("ビューポート", "Viewport"),
        localize_pair("ライブビューポート計測を有効化します。このモード中だけ依存グラフとタイマーのコールバックを登録します。", "Enable live viewport profiling. Depsgraph and timer callbacks are registered only while this mode is active."),
    ),
    (
        REPORT_MODE_RENDER,
        localize_pair("レンダー", "Render"),
        localize_pair("レンダー時の計測を有効化します。このモード選択中だけレンダー用コールバックを有効にします。", "Enable render-time profiling. Render callbacks are kept active only while this mode is selected."),
    ),
)

# Stored in Python so it persists across New/Load
_report_mode: str = REPORT_MODE_OFF


def _normalize_report_mode(value: Any) -> str:
    """Return one durable profiler mode identifier.

    ``report_mode`` uses a custom EnumProperty getter/setter because the
    profiler PropertyGroup is registered lazily.  The Python backing value is
    therefore not restored by Blender's RNA storage when that lazy module is
    recreated.  Keep normalization in one place so the ordinary RNA setter and
    the suite-level JSON restore path update the same backing value.
    """
    mode = str(value or REPORT_MODE_OFF).strip().upper()
    if mode in {REPORT_MODE_OFF, REPORT_MODE_VIEWPORT, REPORT_MODE_RENDER}:
        return mode
    return REPORT_MODE_OFF


def restore_report_mode(value: Any, *, sync_runtime: bool = True) -> str:
    """Restore the persisted mode without turning the always-on feature on.

    Runtime activation remains exclusively controlled by ``report_enabled``.
    Thus restoring ``VIEWPORT`` or ``RENDER`` while that toggle is OFF retains
    the user's preference but installs no handler, timer, or draw callback.
    """
    global _report_mode
    _report_mode = _normalize_report_mode(value)
    if sync_runtime:
        _sync_report_runtime()
    return _report_mode



def _get_report_mode_prop(_self: Any) -> int:
    """Return enum index (Blender EnumProperty getter expects int)."""
    identifiers = [item[0] for item in REPORT_MODE_ITEMS]
    try:
        return identifiers.index(_report_mode)
    except ValueError:
        return 0



def _set_report_mode_prop(_self: Any, value: int) -> None:
    """Receive enum index and store corresponding mode string."""
    if 0 <= value < len(REPORT_MODE_ITEMS):
        mode = REPORT_MODE_ITEMS[value][0]
    else:
        mode = REPORT_MODE_OFF
    restore_report_mode(mode, sync_runtime=True)


def _sync_report_runtime() -> None:
    try:
        from . import handlers, ui
        handlers.sync_runtime_hooks(force=True)
        ui.sync_runtime_ui(force=True)
    except Exception:
        pass


def _get_report_enabled_prop(_self: Any) -> bool:
    # The canonical top-level Always-on toggle is authoritative for whether
    # resident profiler callbacks may run.  ``report_mode`` is an independent
    # persisted preference (Viewport/Render) and must survive temporarily
    # disabling the resident feature.
    try:
        from .. import settings as _suite_settings
        return bool(_suite_settings.get_known_always_on('profiler', 'report_enabled', False))
    except Exception:
        return False


def _set_report_enabled_prop(_self: Any, value: bool) -> None:
    global _report_mode
    enabled = bool(value)
    try:
        from .. import settings as _suite_settings
        _suite_settings.set_known_always_on('profiler', 'report_enabled', enabled, save=True)
    except Exception:
        pass
    if enabled:
        if _report_mode == REPORT_MODE_OFF:
            _report_mode = REPORT_MODE_VIEWPORT
    # Disabling suspends all runtime work but intentionally retains the user's
    # selected mode so re-enabling resumes the same profiling preference.
    _sync_report_runtime()


class RenderProfilerWMProperties(PropertyGroup):
    """WindowManager settings for the live report (mode switcher)."""

    report_enabled: BoolProperty(  # type: ignore
        name=localize_pair("ライブ更新を有効化", "Enable live updates"),
        description=localize_pair(
            'レンダープロファイラーのバックグラウンドコールバックを有効・無効にします。有効にすると未選択時はビューポートモードになり、無効にするとタイマーとハンドラーを解除します。',
            "Turn Render Profiler background callbacks on or off. Enabling this uses Viewport mode when no mode is selected; disabling it removes the timer and handler callbacks.",
        ),
        get=_get_report_enabled_prop,
        set=_set_report_enabled_prop,
    )

    report_mode: EnumProperty(  # type: ignore
        name=localize_pair("レポート更新", "Report updates"),
        description=localize_pair(
            'レンダープロファイラーがライブ更新コールバックを有効化してよいタイミングを選びます。使わない時はオフのままにすると Blender が軽くなります。',
            "Choose when Render Profiler is allowed to install live update callbacks. Off keeps Blender lighter while the profiler is not in use.",
        ),
        items=REPORT_MODE_ITEMS,
        default=REPORT_MODE_OFF,
        get=_get_report_mode_prop,
        set=_set_report_mode_prop,
    )

    font_size: IntProperty(  # type: ignore
        name=localize_pair("レポート文字サイズ", "Report font size"),
        description=localize_inline("Font size used in the HTML report. Reopen or refresh the report page after changing it. / HTML レポートで使う文字サイズです。変更後はレポートを再表示または更新してください。"),
        subtype="PIXEL",
        default=14,
        min=8,
        max=24,
    )


classes: tuple[type[Any], ...] = (
    RenderProfilerWMProperties,
)



def register() -> None:
    from ..rna_safety import ensure_registered_class, register_pointer_property
    for cls in classes:
        ensure_registered_class(cls)

    register_pointer_property(
        bpy.types.WindowManager,
        "profiler",
        RenderProfilerWMProperties,
        name="Render Profiler",
        description="Render Profiler window settings",
    )



def unregister() -> None:
    if hasattr(bpy.types.WindowManager, "profiler"):
        del bpy.types.WindowManager.profiler
    from ..rna_safety import unregister_existing_class
    for cls in reversed(classes):
        unregister_existing_class(cls)
