# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from . import handlers
from . import operators
from . import preferences
from . import properties
from . import server_controller
from . import ui

bl_info = {
    "name": 'Render Profiler',
    "author": "JELararagi",
    "version": (0, 9, 4),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Render",
    "description": "Render Profile viewport and render performance and review the report from the Smart Render N-panel.",
    "category": "Render",
}

def register() -> None:
    """Register all add-on classes."""
    properties.register()
    operators.register()
    ui.register()
    handlers.register()
    preferences.register()


def unregister() -> None:
    """Unregister all add-on classes and stop the report server."""
    server_controller.stop_report_server()
    preferences.unregister()
    handlers.unregister()
    ui.unregister()
    operators.unregister()
    properties.unregister()


if __name__ == "__main__":
    register()
