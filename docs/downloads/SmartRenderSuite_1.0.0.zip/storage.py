# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Writable storage for Smart Render Suite.

Blender Extension package directories are application code and may be read-only.
All mutable Smart Render data therefore lives below Blender's versioned CONFIG
directory::

    <CONFIG>/Smart_Render_Suite

The legacy Extension-package locations are only inspected as migration sources;
they are never created, changed, or removed by this module.
"""

from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path
from typing import Any, Iterable

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

PACKAGE_ID = 'smart_render_suite'
SUITE_DATA_DIRNAME = 'Smart_Render_Suite'
USER_DATA_DIRNAME = 'user_data'
BUNDLED_TOOL_IDS = {
    'bridges',
    'camera_plane',
    'camera_rigs',
    'dynamic_sky',
    'frame_range_renderer',
    'freestyle_svg_exporter',
    'hdr_rotation',
    'k_tools_render_preset_manager',
    'overscan',
    'profiler',
    'pseudo_rendering_farm',
    'rendernames',
    'render_pipeline',
    'sun_position',
    'tri_lighting',
    'use_for_rendering_plus',
}

# Only these known mutable trees are imported from old package-local releases.
# Source code and bundled assets are intentionally never copied.
_LEGACY_MUTABLE_NAMES = (
    USER_DATA_DIRNAME,
    'renders',
    'exports',
    'relative_paths',
    'benchmarks',
    'settings',
    'render_pipeline',
    SUITE_DATA_DIRNAME,
)
_LEGACY_IGNORED_NAMES = {'.DS_Store', 'Thumbs.db', '__pycache__'}
_MIGRATION_DONE = False
_MIGRATION_ACTIVE = False


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _clean_part(value: object) -> str:
    text = str(value or '').replace('\\', '/').strip('/')
    pieces = [piece for piece in text.split('/') if piece and piece not in {'.', '..'}]
    return '/'.join(pieces)


def _clean_parts(parts: Iterable[object]) -> list[str]:
    result: list[str] = []
    for part in parts:
        cleaned = _clean_part(part)
        if cleaned:
            result.extend(piece for piece in cleaned.split('/') if piece)
    return result


def _blender_version() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None) if bpy is not None else None
        if version and len(version) >= 2:
            return f'{int(version[0])}.{int(version[1])}'
    except Exception:
        pass
    return '5.1'


def config_root(create: bool = True) -> Path:
    """Return Blender's versioned CONFIG directory without package fallback."""
    if bpy is not None:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            for args, kwargs in (
                (('CONFIG',), {'path': '', 'create': bool(create)}),
                (('CONFIG',), {'create': bool(create)}),
            ):
                try:
                    value = user_resource(*args, **kwargs) or ''
                except TypeError:
                    continue
                except Exception:
                    value = ''
                if value:
                    path = Path(str(value)).expanduser()
                    if create:
                        path.mkdir(parents=True, exist_ok=True)
                    return path

    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config'
    elif sys.platform == 'darwin':
        path = Path.home() / 'Library' / 'Application Support' / 'Blender' / version / 'config'
    else:
        base = Path(os.environ.get('XDG_CONFIG_HOME') or (Path.home() / '.config'))
        path = base / 'blender' / version / 'config'
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def _normalise_package_id(value: object = None) -> str:
    text = str(value or '').strip()
    if not text:
        return PACKAGE_ID
    parts = [part for part in text.split('.') if part]
    if 'user_default' in parts:
        index = parts.index('user_default')
        if index + 1 < len(parts):
            text = parts[index + 1]
    if (
        text == PACKAGE_ID
        or text.startswith(PACKAGE_ID + '.')
        or PACKAGE_ID in parts
        or text in BUNDLED_TOOL_IDS
        or text == 'Smart_Render_Suite'
        or text.startswith('Smart_Render_Suite.')
        or text.startswith('bl_ext.')
        or '.' in text
    ):
        return PACKAGE_ID
    return text or PACKAGE_ID


def package_id(default: object = None) -> str:
    return _normalise_package_id(default or PACKAGE_ID)


def manifest_extension_id(default: str = PACKAGE_ID) -> str:
    return package_id(default)


def _path_is_inside_package(path: Path) -> bool:
    try:
        target = Path(path).resolve(strict=False)
        package = _package_root().resolve(strict=False)
        return target == package or package in target.parents
    except Exception:
        return False


def _legacy_package_roots() -> tuple[Path, ...]:
    """Return existing old package roots without creating any of them."""
    candidates: list[Path] = [_package_root()]
    if bpy is not None:
        utils = getattr(bpy, 'utils', None)
        extension_path_user = getattr(utils, 'extension_path_user', None)
        if callable(extension_path_user):
            for args, kwargs in (
                ((PACKAGE_ID,), {'path': '', 'create': False}),
                ((PACKAGE_ID,), {'create': False}),
                ((PACKAGE_ID, ''), {'create': False}),
            ):
                try:
                    value = extension_path_user(*args, **kwargs) or ''
                except TypeError:
                    continue
                except Exception:
                    value = ''
                if value:
                    candidates.append(Path(str(value)))

    version_root = config_root(create=False).parent
    candidates.append(version_root / 'extensions' / 'user_default' / PACKAGE_ID)

    unique: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        try:
            key = str(candidate.resolve(strict=False))
        except Exception:
            key = str(candidate)
        if key in seen:
            continue
        seen.add(key)
        if candidate.exists() and candidate.is_dir():
            unique.append(candidate)
    return tuple(unique)


def _merge_legacy_tree(source: Path, target: Path) -> bool:
    """Copy missing legacy data into CONFIG without mutating ``source``."""
    try:
        source = Path(source)
        target = Path(target)
        if not source.exists():
            return False
        if source.is_file():
            if target.exists():
                return False
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            return True
        if not source.is_dir():
            return False
        copied = False
        target.mkdir(parents=True, exist_ok=True)
        for item in source.iterdir():
            if item.name in _LEGACY_IGNORED_NAMES or item.is_symlink():
                continue
            destination = target / item.name
            if item.is_dir():
                copied = _merge_legacy_tree(item, destination) or copied
            elif item.is_file() and not destination.exists():
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, destination)
                copied = True
        return copied
    except Exception:
        return False


def migrate_legacy_package_data(target_root: Path | None = None) -> bool:
    """Read-only import of known mutable trees from old Extension packages."""
    global _MIGRATION_DONE, _MIGRATION_ACTIVE
    if _MIGRATION_DONE or _MIGRATION_ACTIVE:
        return False
    _MIGRATION_ACTIVE = True
    copied = False
    try:
        target = Path(target_root) if target_root is not None else config_root(create=True) / SUITE_DATA_DIRNAME
        target.mkdir(parents=True, exist_ok=True)
        target_resolved = target.resolve(strict=False)
        for legacy_root in _legacy_package_roots():
            try:
                if legacy_root.resolve(strict=False) == target_resolved:
                    continue
            except Exception:
                pass
            for name in _LEGACY_MUTABLE_NAMES:
                source = legacy_root / name
                if not source.exists():
                    continue
                # An old nested Smart_Render_Suite folder contains the canonical
                # settings file, so merge its contents directly into the target.
                destination = target if name == SUITE_DATA_DIRNAME else target / name
                copied = _merge_legacy_tree(source, destination) or copied
        _MIGRATION_DONE = True
        return copied
    finally:
        _MIGRATION_ACTIVE = False


def suite_data_root(create: bool = True) -> Path:
    path = config_root(create=create) / SUITE_DATA_DIRNAME
    if create:
        path.mkdir(parents=True, exist_ok=True)
        migrate_legacy_package_data(path)
    return path


def extension_user_root(package: object | None = None, *, create: bool = False) -> Path:
    """Compatibility name for the CONFIG-owned mutable Smart Render root."""
    del package
    return suite_data_root(create=create)


def user_default_root(*parts: object, package_id: str | None = None, create: bool = True) -> Path:
    del package_id
    root = suite_data_root(create=create)
    clean = _clean_parts(parts)
    path = root.joinpath(*clean) if clean else root
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def extension_dir(create: bool = False) -> Path:
    return suite_data_root(create=create)


def user_data_dir(*parts: object, create: bool = False) -> Path:
    path = suite_data_root(create=create) / USER_DATA_DIRNAME
    clean = _clean_parts(parts)
    if clean:
        path = path.joinpath(*clean)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def user_data_file(*parts: object, create_parent: bool = False) -> Path:
    clean = _clean_parts(parts)
    if not clean:
        raise ValueError('user_data_file requires a non-empty filename')
    path = user_data_dir(*clean[:-1], create=create_parent) / clean[-1]
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def addon_data_path(*parts: object, create: bool = True) -> Path:
    clean = _clean_parts(parts)
    if not clean:
        return addon_data_dir(create=create)
    return addon_data_dir(*clean[:-1], create=create) / clean[-1]


def storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def storage_path(filename: object, *parts: object, create: bool = True) -> Path:
    clean = _clean_parts([*parts, filename])
    if not clean:
        raise ValueError('storage_path requires a filename')
    path = storage_dir(*clean[:-1], create=create) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def settings_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('settings', *parts, create=create)


def runtime_dir(*parts: object, create: bool = True, package: object | None = None) -> Path:
    del package
    root = suite_data_root(create=create) / USER_DATA_DIRNAME / 'runtime'
    clean = _clean_parts(parts)
    if clean:
        root = root.joinpath(*clean)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def settings_file(name: object, *, create: bool = True) -> Path:
    clean = _clean_part(name)
    if not clean:
        raise ValueError('settings_file requires a filename')
    path = settings_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def runtime_file(filename: object, *subdirs: object, create: bool = True, package: object | None = None) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('runtime_file requires a filename')
    path = runtime_dir(*clean[:-1], create=create, package=package) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_path(filename: object, *subdirs: object, package_id: str | None = None, create: bool = True) -> Path:
    del package_id
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('addon_storage_path requires a filename')
    root = storage_dir(*clean[:-1], create=create)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root / clean[-1]


def write_json(filename: object, payload: Any, subdir: str = 'reports') -> Path:
    path = user_data_file(subdir, filename, create_parent=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    return path


def read_json(path: str | Path, default: Any = None) -> Any:
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return default


def atomic_write_text(path: str | Path, text: str, *, encoding: str = 'utf-8') -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + '.tmp')
    temporary.write_text(text, encoding=encoding)
    temporary.replace(target)


def atomic_write_json(path: str | Path, data: Any, *, indent: int = 2, ensure_ascii: bool = False, sort_keys: bool = False) -> None:
    atomic_write_text(
        path,
        json.dumps(data, indent=indent, ensure_ascii=ensure_ascii, sort_keys=sort_keys, default=str),
        encoding='utf-8',
    )


def migrate_legacy_file(legacy_path: Path | None, target_path: Path | None, *, remove_legacy: bool = True) -> bool:
    if legacy_path is None or target_path is None:
        return False
    legacy = Path(legacy_path)
    target = Path(target_path)
    try:
        if not legacy.exists() or target.exists():
            return False
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(legacy, target)
        # Extension package data is immutable: migration is copy-only even when
        # an older caller asks to remove the legacy source.
        if remove_legacy and not _path_is_inside_package(legacy):
            try:
                legacy.unlink()
            except Exception:
                pass
        return True
    except Exception:
        return False
