from __future__ import annotations

import os
from typing import Dict, List


def _script_paths(base_path: str) -> Dict[str, str]:
    stem, _ext = os.path.splitext(base_path)
    return {
        "shell_path": f"{stem}_headless.sh",
        "batch_path": f"{stem}_headless.bat",
    }


def _ensure_parent(path: str) -> None:
    directory = os.path.dirname(path)
    if directory:
        os.makedirs(directory, exist_ok=True)


def _job_commands(manifest_data: Dict[str, object]) -> List[dict]:
    jobs: List[dict] = []
    for item in manifest_data.get("resolved_queue", []) or []:
        if not isinstance(item, dict):
            continue
        if not bool(item.get("enabled", True)):
            continue
        chunk_commands = []
        for chunk in item.get("chunk_commands", []) or []:
            if isinstance(chunk, dict):
                chunk_commands.append(chunk)
        if chunk_commands:
            for index, chunk in enumerate(chunk_commands, start=1):
                command = str(chunk.get("background_command", "") or chunk.get("command", "")).strip()
                if not command:
                    continue
                jobs.append(
                    {
                        "label": str(chunk.get("label", "") or f"{item.get('label', 'job')} [chunk {index}/{len(chunk_commands)}]"),
                        "command": command,
                    }
                )
            continue
        command = str(item.get("background_command", "") or "").strip()
        if not command:
            continue
        jobs.append(
            {
                "label": str(item.get("label", "") or "job"),
                "command": command,
            }
        )
    return jobs



def _ffmpeg_jobs(manifest_data: Dict[str, object]) -> List[dict]:
    jobs: List[dict] = []
    post_tasks = manifest_data.get("post_tasks", {}) or {}
    if not bool(post_tasks.get("ffmpeg_enabled", False)):
        return jobs
    for item in post_tasks.get("ffmpeg_jobs", []) or []:
        if not isinstance(item, dict):
            continue
        command = str(item.get("command", "") or "").strip()
        if not command:
            continue
        jobs.append(
            {
                "label": str(item.get("label", "") or "movie"),
                "command": command,
            }
        )
    return jobs


def export_headless_scripts(manifest_data: Dict[str, object], base_path: str) -> Dict[str, object]:
    paths = _script_paths(base_path)
    jobs = _job_commands(manifest_data)
    ffmpeg_jobs = _ffmpeg_jobs(manifest_data)

    shell_lines = [
        "#!/usr/bin/env bash",
        "set -u",
        "",
        "# Smart Render headless queue export",
    ]
    batch_lines = [
        "@echo off",
        "setlocal enabledelayedexpansion",
        "",
        "REM Smart Render headless queue export",
    ]

    if not jobs and not ffmpeg_jobs:
        shell_lines.append('echo "No enabled jobs found in manifest."')
        batch_lines.append('echo No enabled jobs found in manifest.')
    else:
        if jobs:
            shell_lines.extend(
                [
                    f'echo "Running {len(jobs)} headless job(s)..."',
                    "",
                ]
            )
            batch_lines.extend(
                [
                    f'echo Running {len(jobs)} headless job(s)...',
                    "",
                ]
            )
        for index, job in enumerate(jobs, start=1):
            label = job["label"].replace('"', "'")
            command = job["command"]
            shell_lines.extend(
                [
                    f'echo "[{index}/{len(jobs)}] {label}"',
                    command,
                    "status=$?",
                    'if [ "$status" -ne 0 ]; then',
                    f'  echo "Job failed: {label}"',
                    '  exit "$status"',
                    "fi",
                    "",
                ]
            )
            batch_lines.extend(
                [
                    f'echo [{index}/{len(jobs)}] {label}',
                    command,
                    'if errorlevel 1 goto :error',
                    "",
                ]
            )
        if ffmpeg_jobs:
            shell_lines.extend([
                f'echo "Running {len(ffmpeg_jobs)} FFmpeg post task(s)..."',
                "",
            ])
            batch_lines.extend([
                f'echo Running {len(ffmpeg_jobs)} FFmpeg post task(s)...',
                "",
            ])
            for index, job in enumerate(ffmpeg_jobs, start=1):
                label = job["label"].replace('"', "'")
                command = job["command"]
                shell_lines.extend(
                    [
                        f'echo "[ffmpeg {index}/{len(ffmpeg_jobs)}] {label}"',
                        command,
                        "status=$?",
                        'if [ "$status" -ne 0 ]; then',
                        f'  echo "FFmpeg task failed: {label}"',
                        '  exit "$status"',
                        "fi",
                        "",
                    ]
                )
                batch_lines.extend(
                    [
                        f'echo [ffmpeg {index}/{len(ffmpeg_jobs)}] {label}',
                        command,
                        'if errorlevel 1 goto :error',
                        "",
                    ]
                )
        batch_lines.extend(
            [
                'echo All jobs completed successfully.',
                'goto :eof',
                '',
                ':error',
                'echo Job failed.',
                'exit /b 1',
            ]
        )

    for key in ["shell_path", "batch_path"]:
        _ensure_parent(paths[key])
    with open(paths["shell_path"], "w", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(shell_lines).rstrip() + "\n")
    with open(paths["batch_path"], "w", encoding="utf-8", newline="\r\n") as handle:
        # newline="\r\n" already turns every "\n" into CRLF.
        handle.write("\n".join(batch_lines).rstrip() + "\n")
    try:
        os.chmod(paths["shell_path"], 0o755)
    except Exception:
        pass

    return {
        **paths,
        "job_count": len(jobs),
        "ffmpeg_job_count": len(ffmpeg_jobs),
    }
