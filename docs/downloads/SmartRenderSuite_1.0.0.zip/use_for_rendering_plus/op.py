from ..translation import iface_text
import bpy
from bpy.types import Operator, Context, Scene, ViewLayer, CompositorNodeRLayers, Collection, CollectionProperty, LayerCollection, bpy_struct, bpy_prop_collection, ViewLayerEEVEE
from bpy.props import BoolProperty
import re
from . import properties as props

############## COMPOSITING ##############
def get_render_node_scene_layer(node: CompositorNodeRLayers) -> tuple[Scene, ViewLayer]:
    if node.type != "R_LAYERS":
        raise ValueError("Active node must be of Render Layer type")
    if node.scene is None:
        return (None, None)
    layer = node.scene.view_layers.get(node.layer, None)
    if layer is None:
        return (node.scene, None)
    return (node.scene, layer)


def get_comp_group(scene: Scene):
    if bpy.app.version < (5, 0, 0):
        return scene.node_tree
    return scene.compositing_node_group 


def get_nodes(unmuted_only=False, selected_only=False):
    scene = getattr(bpy.context, 'scene', None)
    if scene is None:
        return []
    try:
        comp_group = get_comp_group(scene)
    except Exception:
        return []
    if not comp_group:
        return []
    nodes = []
    for n in getattr(comp_group, 'nodes', []) or []:
        try:
            if (n.type == "R_LAYERS"
                    and (not unmuted_only or not n.mute)
                    and (not selected_only or n.select)):
                nodes.append(n)
        except ReferenceError:
            continue
        except Exception:
            continue
    return nodes


def set_all_view_layers(layers: list[ViewLayer], include=True):
    #TODO not really readable
    bpy.context.scene.render.use_single_layer = False
    nb_view_layers = 0
    for scene in bpy.data.scenes:
        scene: Scene
        for vl in scene.view_layers:
            if vl in layers:
                if include:
                    vl.use = True
                    nb_view_layers += 1
                else:
                    vl.use = False
            else:
                if include:
                    vl.use = False
                else:
                    vl.use = True
                    nb_view_layers += 1
    return nb_view_layers


class UFRP_OP_toggle(Operator):
    """Set selected View Layers 'Use for rendering' property"""
    bl_idname = "ufrp.toggle_selected_for_rendering"
    bl_label = "Toggle Selected for Rendering"
    bl_options = {'UNDO'}
    state: BoolProperty(
        name="UseForRenderingState", 
        description="Check or uncheck selected View Layers 'Use for rendering' property"
        ) # type: ignore

    @classmethod
    def poll(cls, context: Context):
        cls.poll_message_set(iface_text("Must select Render Layer nodes"))
        return get_nodes(selected_only=True)

    def execute(self, context: Context):
        nodes = get_nodes(selected_only=True)
        bpy.context.scene.render.use_single_layer = False
        for node in nodes:
            node.mute = not self.state
            scene, layer = get_render_node_scene_layer(node)
            if not layer:
                continue
            layer.use = self.state
        if self.state == True:
            self.report({"INFO"}, iface_text(f"Enabled selected {len(nodes)} View Layers for rendering"))
        else:
            self.report({"INFO"}, iface_text(f"Disabled selected {len(nodes)} View Layers from rendering"))
        return {"FINISHED"}


class UFRP_OP_batch(Operator):
    """Set all View Layers 'Use for rendering' property"""
    bl_idname = "ufrp.batch_toggle_rendering"
    bl_label = "Batch Toggle Rendering"
    bl_options = {'UNDO'}
    state: BoolProperty(
        name="UseForRenderingState", 
        description="Check or uncheck all View Layers 'Use for rendering' property"
        ) # type: ignore

    def execute(self, context: Context):
        if self.state == True:
            nb = set_all_view_layers([], include=False)
        else:
            set_all_view_layers([], include=True)
            # set_all_view_layers only counts the layers it enables.
            nb = sum(len(scene.view_layers) for scene in bpy.data.scenes)
        # update render nodes mute state
        nodes = get_nodes()
        for node in nodes:
            node: CompositorNodeRLayers
            node.mute = not self.state
        if self.state == True:
            self.report({"INFO"}, iface_text(f"Enabled all {nb} View Layers for rendering"))
        else:
            self.report({"INFO"}, iface_text(f"Disabled all {nb} View Layers from rendering"))
        return {"FINISHED"}


class UFRP_OP_OnlyUnmuted(Operator):
    """Only 'use for rendering' unmuted render layer nodes"""
    bl_idname = "ufrp.enable_only_unmuted_nodes"
    bl_label = "Enable Only Unmuted Nodes"
    bl_options = {'UNDO'}
    
    def execute(self, context: Context):
        # get layers to use
        nodes = get_nodes(unmuted_only=True)
        layers_to_use = []
        for node in nodes:
            scene, layer = get_render_node_scene_layer(node)
            if not layer:
                continue
            layers_to_use.append(layer)
        # only activate layers to use
        set_all_view_layers(layers_to_use, include=True)
        self.report({"INFO"}, iface_text(f"Enable only {len(layers_to_use)} active View Layers for rendering"))
        return {"FINISHED"}


class UFRP_OP_OnlySelected(Operator):
    """Only 'use for rendering' selected render layer nodes"""
    bl_idname = "ufrp.enable_only_selected"
    bl_label = "Enable Only Selected"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        cls.poll_message_set(iface_text("Must select Render Layer nodes"))
        return get_nodes(selected_only=True)
    
    def execute(self, context: Context):
        nodes = get_nodes()
        selected_nodes = [node for node in context.selected_nodes if node.type == "R_LAYERS"]
        if not selected_nodes:
            self.report({"ERROR"}, iface_text("Must select at least one render layer node"))
            return {"CANCELLED"}
        layers_to_use = []
        for node in nodes:
            if node not in selected_nodes:
                node.mute = True
                continue
            node.mute = False
            scene, layer = get_render_node_scene_layer(node)
            if not layer:
                continue
            layers_to_use.append(layer)
        set_all_view_layers(layers_to_use, include=True)
        self.report({"INFO"}, iface_text(f"Enable only {len(layers_to_use)} selected View Layers for rendering"))
        return {"FINISHED"}


class UFRP_OP_RenderLayerSwitch(Operator):
    """Switch to active render layer node's View Layer"""
    bl_idname = "ufrp.switch_to_active_render_layer_node"
    bl_label = "Switch to Active Render Layer Node"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        cls.poll_message_set(iface_text("Must select a Render Layer Node"))
        selected_nodes = getattr(context, 'selected_nodes', None)
        active_node = getattr(context, 'active_node', None)
        return bool(
            selected_nodes
            and active_node
            and getattr(active_node, 'type', None) == "R_LAYERS")
    
    def execute(self, context: Context):
        node = context.active_node
        if node.type != "R_LAYERS":
            self.report({"ERROR"}, iface_text("Active node must be of Render Layer type"))
            return {"CANCELLED"}
        scene, layer = get_render_node_scene_layer(node)
        if not scene or not layer:
            self.report({"ERROR"}, iface_text(f"Could not find scene '{scene}' and View Layer '{layer}'"))
            return {"CANCELLED"}
        if context.window.scene == scene and context.window.view_layer == layer:
            self.report({"INFO"}, iface_text(f"Already on '{layer.name}' View Layer"))
            return {"CANCELLED"}
        context.window.scene = scene
        context.window.view_layer = layer
        self.report({"INFO"}, iface_text(f"Switched to '{layer.name}' View Layer"))
        return {"FINISHED"}


############## LAYER MANAGER ##############
class UFRP_OP_ViewLayerAdd(Operator):
    """Add a new View Layer from selected, similar as 'NEW'"""
    bl_idname = "ufrp.add_view_layer"
    bl_label = "Add View Layer"
    bl_options = {'UNDO'}

    def execute(self, context: Context):
        layer_index = props.get_layer_index()
        #TODO check si index correct, peut-etre interdir en dehors du nombre de View Layer dans la proprietee directement
        selected_layer = context.scene.view_layers[layer_index]
        context.scene.view_layers.new(selected_layer.name)
        props.set_layer_index(len(context.scene.view_layers) - 1)
        return {"FINISHED"}


class UFRP_OP_ViewLayerRemove(Operator):
    """Remove selected View Layer"""
    bl_idname = "ufrp.remove_view_layer"
    bl_label = "Remove View Layer"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        cls.poll_message_set(iface_text("Cannot remove last View Layer"))
        return len(getattr(getattr(context, 'scene', None), 'view_layers', []) or []) > 1

    def execute(self, context):
        layer_index = props.get_layer_index()
        selected_layer = context.scene.view_layers[layer_index]
        context.scene.view_layers.remove(selected_layer)
        props.set_layer_index(layer_index - 1)
        return {"FINISHED"}


class UFRP_OP_ViewLayerSwitch(Operator):
    """Switch View Layer"""
    bl_idname = "ufrp.switch_view_layer"
    bl_label = "Switch View Layer"
    bl_options = set()
    _sms_no_undo = True
    layer_name: bpy.props.StringProperty(name="View Layer name") # type: ignore

    def execute(self, context: Context):
        layer = context.scene.view_layers.get(self.layer_name)
        if layer is None or context.window is None:
            self.report({'WARNING'}, iface_text("View Layer was not found."))
            return {'CANCELLED'}
        context.window.view_layer = layer
        switched_index = context.scene.view_layers.keys().index(self.layer_name)
        props.set_layer_index(switched_index)
        self.report({"INFO"}, iface_text(f"Switched to '{self.layer_name}'"))
        return {"FINISHED"}


class UFRP_OP_AllCopyProps(Operator):
    """Toggle All Copy Passes View Layers properties for copy"""
    bl_idname = "ufrp.toggle_all_copy_passes"
    bl_label = "Toggle All Copy Passes"
    bl_options = {'UNDO'}
    action: bpy.props.StringProperty(name="Action for all props") # type: ignore

    def execute(self, context: Context):
        passes = props.get_passes()
        for p in passes:
            match self.action:
                case "ON":
                    p.is_copy = True
                case "OFF":
                    p.is_copy = False
                case "TOGGLE":
                    p.is_copy = not p.is_copy
        return {"FINISHED"}


class UFRP_OP_ReloadPasses(Operator):
    """Reload View Layers copiable passes"""
    bl_idname = "ufrp.reload_copy_passes"
    bl_label = "Reload Copy Passes"
    bl_options = {'UNDO'}

    def execute(self, context: Context):
        props.populate_prop_passes(context)
        return {"FINISHED"}


class UFRP_OP_CopyLayer(Operator):
    """Set selected View Layer's as copy source"""
    bl_idname = "ufrp.copy_layer_settings"
    bl_label = "Copy Layer Settings"
    bl_options = {'UNDO'}

    def execute(self, context: Context):
        layer_index = props.get_layer_index()
        selected_layer = context.scene.view_layers[layer_index]
        props.set_layer_source(selected_layer.name)
        self.report({"INFO"}, iface_text(f"Set '{selected_layer.name}' as copy source"))
        return {"FINISHED"}


class UFRP_OP_PasteLayer(Operator):
    """Paste View Layer's Layer properties and its Collection render settings from source"""
    bl_idname = "ufrp.paste_layer_settings"
    bl_label = "Paste Layer Settings"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context: Context):
        cls.poll_message_set(iface_text("No properties to Copy/Paste, please check at least one option"))
        if props.get_prefs_show_depricated():
            if (    not props.is_copy_exclude() 
                and not props.is_copy_holdout() 
                and not props.is_copy_indirect_only() 
                and not props.is_copy_hide_viewport()
                and not props.is_copy_aovs()
                and not props.is_copy_passes()
                ): return False
        elif (  not props.is_copy_exclude() 
            and not props.is_copy_holdout() 
            and not props.is_copy_indirect_only() 
            and not props.is_copy_hide_viewport()
        ): return False
        return True

    @staticmethod
    def copy_layercollection_settings(source_lc: LayerCollection, target_lc: LayerCollection):
        """Recursively copy View Layer's Layer Collections settings"""
        s = source_lc
        t = target_lc
        if props.is_copy_exclude():
            t.exclude = s.exclude
        if props.is_copy_holdout():
            t.holdout = s.holdout
        if props.is_copy_indirect_only():
            t.indirect_only = s.indirect_only
        if props.is_copy_hide_viewport():
            t.hide_viewport = s.hide_viewport
        for src_child, dst_child in zip(s.children, t.children):
            __class__.copy_layercollection_settings(src_child, dst_child)

    @staticmethod
    def copy_collection_prop(obj_src, obj_trg, prop_name: str):
        assert type(obj_src) == type(obj_trg)
        assert obj_src != obj_trg
        prop_src = getattr(obj_src, prop_name)
        prop_trg = getattr(obj_trg, prop_name)
        for coll_prop in prop_trg:
            prop_trg.remove(coll_prop)
        for coll_prop in prop_src:
            new_prop = prop_trg.add()
            filter = [p.identifier for p in new_prop.bl_rna.properties if props.is_prop_copyable(p)]
            __class__.copy_attrs(coll_prop, new_prop, filter)

    @staticmethod
    def copy_attrs(obj_src, obj_trg, filter=None):
        for attr_name in dir(obj_src):
            if filter is not None and attr_name not in filter:
                continue
            value = getattr(obj_src, attr_name)
            setattr(obj_trg, attr_name, value)

    def execute(self, context: Context):
        # assure passes prop
        passes = props.get_passes()
        if not passes:
            props.populate_prop_passes(context)
            passes = props.get_passes()
        passes_to_copy = [p.identifier for p in passes if p.is_copy]
        # checks
        if (not self.poll(context)
            and (props.get_prefs_show_depricated() and props.is_copy_passes() and not passes_to_copy)):
            self.report({"WARNING"}, iface_text(f"No properties to Copy/Paste, please check at least one option"))
            return {"CANCELLED"}
        source_vl_name = props.get_layer_source()
        if not source_vl_name:
            self.report({"WARNING"}, iface_text(f"Please first copy a View Layer"))
            return {"CANCELLED"}
        source_vl = context.scene.view_layers.get(source_vl_name, None)
        if not source_vl:
            self.report({"WARNING"}, iface_text(f"Source '{source_vl_name}' View Layer is missing, please new View Layer"))
            return {"CANCELLED"}
        layer_index = props.get_layer_index()
        target_vl = context.scene.view_layers[layer_index]
        if source_vl == target_vl:
            self.report({"WARNING"}, iface_text(f"Target View Layer '{target_vl.name}' is already the source"))
            return {"CANCELLED"}
        # copy/paste
        self.copy_layercollection_settings(source_vl.layer_collection, target_vl.layer_collection)
        if props.get_prefs_show_depricated() and props.is_copy_passes() and passes_to_copy:
            self.copy_attrs(source_vl, target_vl, passes_to_copy)
            self.copy_attrs(source_vl.cycles, target_vl.cycles, passes_to_copy)
            self.copy_attrs(source_vl.eevee, target_vl.eevee, passes_to_copy)
        if props.get_prefs_show_depricated() and props.is_copy_aovs():
            self.copy_collection_prop(source_vl, target_vl, "aovs")
        self.report({"INFO"}, iface_text(f"Pasted properties from '{source_vl.name}' to '{target_vl.name}'"))
        return {"FINISHED"}


def get_other_view_layers_items(self, context: Context):
    return [(vl.name, vl.name , "") for vl in context.scene.view_layers if vl!=context.view_layer]

class UFRP_OT_CopyToSelected(Operator):
    """Copy selected collection's render settings to all View Layers"""
    bl_idname = "ufrp.copy_collection_settings"
    bl_label = "Copy Collection Settings"
    bl_options = {'UNDO'}
    view_layers: bpy.props.CollectionProperty(type=props.UFRP_property_select) #type: ignore
    is_copy_exclude: BoolProperty(name="Copy Exclude from View Layer", description="Copy/Paste 'exclude' setting", default=True) # type: ignore
    is_copy_hide_viewport: BoolProperty(name="Copy Hide in Viewport", description="Copy/Paste 'hide_viewport' setting", default=True) # type: ignore
    is_copy_holdout: BoolProperty(name="Copy Holdout", description="Copy/Paste 'holdout' setting", default=True) # type: ignore
    is_copy_indirect_only: BoolProperty(name="Copy Indirect Only", description="Copy/Paste 'indirect_only' setting", default=True) # type: ignore

    @classmethod
    def poll(cls, context: Context):
        cls.poll_message_set(iface_text(f"Must have at least 2 View Layers"))
        return len(getattr(getattr(context, 'scene', None), 'view_layers', []) or []) > 1

    def invoke(self, context, event):
        self.selected = [c for c in context.selected_ids if c.id_type=="COLLECTION"]
        self.view_layers.clear()
        for vl in context.scene.view_layers:
            if vl == context.view_layer:
                continue
            pr = self.view_layers.add()
            pr.name = vl.name
            pr.selected = True
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context: Context):
        lay = self.layout
        lay: bpy.types.UILayout
        lay.label(text=iface_text(f"From {len(self.selected)} selected Collection(s), copy"))
        row = lay.row(align=True)
        row.prop(self, "is_copy_exclude", text="", icon="CHECKBOX_HLT", toggle=True)
        row.prop(self, "is_copy_hide_viewport", text="", icon="HIDE_OFF", toggle=True)
        row.prop(self, "is_copy_holdout", text="", icon="HOLDOUT_ON", toggle=True)
        row.prop(self, "is_copy_indirect_only", text="", icon="INDIRECT_ONLY_ON", toggle=True)
        lay.label(text=iface_text("To the following View Layers"))
        col = lay.column(align=True)
        for pr in self.view_layers:
            col.prop(pr, "selected", text=pr.name, toggle=True, icon="RENDERLAYERS", translate=False)

    def execute(self, context: Context):
        current_vl = context.view_layer
        vls = context.scene.view_layers
        for pr in self.view_layers:
            if not pr.selected:
                continue
            vl = context.scene.view_layers[pr.name]
            self.copy_layercollection_settings(current_vl.layer_collection, vl.layer_collection)
        self.report({"INFO"}, iface_text(f"Copied {len(self.selected)} Layer Collections settings to {len(vls)-1} View Layers"))
        return {"FINISHED"}
    
    def copy_layercollection_settings(self, source_lc: LayerCollection, target_lc: LayerCollection):
        """Recursively copy View Layer's Layer Collections settings"""
        if target_lc.collection in self.selected:
            if self.is_copy_exclude:
                target_lc.exclude = source_lc.exclude
            if self.is_copy_holdout:
                target_lc.holdout = source_lc.holdout
            if self.is_copy_indirect_only:
                target_lc.indirect_only = source_lc.indirect_only
            if self.is_copy_hide_viewport:
                target_lc.hide_viewport = source_lc.hide_viewport
        for src_child, dst_child in zip(source_lc.children, target_lc.children):
            self.copy_layercollection_settings(src_child, dst_child)


def backup_comp_layers(context: Context):
    comp_group = get_comp_group(context.scene)
    if not comp_group:
        return None
    nodes = comp_group.nodes
    old_nodes = [n for n in nodes if n.type=="R_LAYERS"]
    old_layers = [n.layer for n in old_nodes]
    return old_nodes, old_layers

def correct_comp_layers(backup: tuple[list, list]):
    if backup is None:
        return
    old_nodes, old_layers = backup
    for node, layer in zip(old_nodes, old_layers):
        node.layer = layer

class UFRP_OP_MoveLayer(Operator):
    """Move selected View Layer up/down"""
    bl_idname = "ufrp.move_view_layer"
    bl_label = "Move View Layer"
    bl_options = {'UNDO'}
    direction: bpy.props.StringProperty() #type: ignore

    @classmethod
    def poll(cls, context: Context):
        cls.poll_message_set(iface_text("Must have at least two View Layers"))
        return len(getattr(getattr(context, 'scene', None), 'view_layers', []) or []) > 1

    def execute(self, context: Context):
        backup = backup_comp_layers(context)
        layer_index = props.get_layer_index()
        if self.direction == "UP":
            index_to = layer_index - 1
            if index_to < 0:
                index_to = len(context.scene.view_layers) - 1
        elif self.direction == "DOWN":
            index_to = layer_index + 1
            if index_to > len(context.scene.view_layers) - 1:
                index_to = 0
        elif self.direction == "TOP":
            index_to = 0
        elif self.direction == "BOTTOM":
            index_to = len(context.scene.view_layers) - 1
        else:
            self.report({"ERROR"}, iface_text(f"Operator property 'direction' should be in 'UP', 'DOWN', 'TOP' or 'BOTTOM', got '{self.direction}'"))
            return {"CANCELLED"}
        context.scene.view_layers.move(layer_index, index_to)
        props.set_layer_index(index_to)
        correct_comp_layers(backup)
        return {"FINISHED"}


class UFRP_OP_SortLayers(Operator):
    """Sort View Layers by name"""
    bl_idname = "ufrp.sort_view_layers"
    bl_label = "Sort View Layers"
    bl_options = {'UNDO'}
    is_reverse: bpy.props.BoolProperty(default=False) #type: ignore

    @classmethod
    def poll(cls, context: Context):
        cls.poll_message_set(iface_text("Must have at least two View Layers"))
        return len(getattr(getattr(context, 'scene', None), 'view_layers', []) or []) > 1
    
    @staticmethod
    def natural_sort_key(s, _nsre=re.compile("([0-9]+)")):
        """Sort a string in a natural way
        https://stackoverflow.com/a/16090640"""
        return [int(text) if text.isdigit() else text.lower() for text in _nsre.split(s)]

    def execute(self, context: Context):
        backup = backup_comp_layers(context)
        layers = context.scene.view_layers
        sorted_layers = sorted(layers, key=lambda vl: self.natural_sort_key(vl.name))
        if self.is_reverse:
            sorted_layers.reverse()
        layer_index = props.get_layer_index()
        current_layer = layers[layer_index]
        for to_i, layer in enumerate(sorted_layers):
            current_i = [l for l in layers].index(layer)
            layers.move(current_i, to_i)
            if layer == current_layer:
                props.set_layer_index(to_i)
        correct_comp_layers(backup)
        return {"FINISHED"}
