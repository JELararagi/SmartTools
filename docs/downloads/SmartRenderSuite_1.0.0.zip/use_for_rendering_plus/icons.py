# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

from pathlib import Path
from typing import Any

import bpy

try:
    import bpy.utils.previews as _previews  # type: ignore
except Exception:  # pragma: no cover - outside Blender
    _previews = None  # type: ignore[assignment]

_icons: Any | None = None
_PENDING_PREVIEW_REMOVALS: list[Any] = []
_ICON_PREVIEW_STORE_KEY = "JELARARAGI_SRS_UFRP_PREVIEW_COLLECTIONS"

_ICON_FILES: dict[str, str] = {
    "selected": "only_selected.png",
    "switch": "switch_view_layer.png",
}


def _preview_store() -> dict:
    try:
        namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if namespace is None:
            return {}
        store = namespace.setdefault(_ICON_PREVIEW_STORE_KEY, {})
        if isinstance(store, dict):
            return store
    except Exception:
        pass
    return {}


def _remove_preview_collection_later(pcoll: Any) -> None:
    # Release custom icon previews during tool unregister. Owning panels are
    # hidden/unregistered before this path, and best-effort removal prevents
    # ResourceWarning output during Blender shutdown.
    if pcoll is None:
        return None
    try:
        store = _preview_store()
        for key, value in tuple(store.items()):
            if value is pcoll:
                store.pop(key, None)
        retained = store.get('_retained')
        if isinstance(retained, list):
            while pcoll in retained:
                retained.remove(pcoll)
    except Exception:
        pass
    try:
        if _previews is not None:
            _previews.remove(pcoll)
    except Exception:
        pass
    return None


def _icons_dir() -> Path:
    return Path(__file__).resolve().parents[1] / "icons"


def _safe_load(pcoll: Any, key: str, filename: str) -> None:
    path = _icons_dir() / filename
    if not path.exists():
        return
    try:
        pcoll.load(key, str(path), "IMAGE")
    except Exception:
        pass


def register(*, force: bool = False) -> None:
    """Load custom preview icons and keep the collection alive."""
    global _icons
    if _previews is None:
        _icons = None
        return
    if _icons is not None and not force:
        return

    store = _preview_store()
    store_key = tuple(sorted(_ICON_FILES.items()))
    if not force:
        try:
            cached = store.get(store_key)
            if cached is not None:
                _icons = cached
                return
        except Exception:
            pass

    try:
        pcoll = _previews.new()
    except Exception:
        _icons = None
        return
    loaded = False
    for key, filename in _ICON_FILES.items():
        before = len(pcoll.keys()) if hasattr(pcoll, 'keys') else 0
        _safe_load(pcoll, key, filename)
        try:
            loaded = loaded or pcoll.get(key) is not None
        except Exception:
            loaded = loaded or before != (len(pcoll.keys()) if hasattr(pcoll, 'keys') else before)
    _icons = pcoll
    try:
        if loaded:
            old = store.get(store_key)
            if old is not None and old is not pcoll:
                _remove_preview_collection_later(old)
            store[store_key] = pcoll
    except Exception:
        pass


def unregister() -> None:
    global _icons
    if _icons is None:
        return
    pcoll = _icons
    _icons = None
    _remove_preview_collection_later(pcoll)


def _ensure_icons() -> Any | None:
    if _icons is None:
        register()
    return _icons


def get_icon_id(name: str) -> int:
    pcoll = _ensure_icons()
    if pcoll is None:
        return 0
    try:
        item = pcoll.get(str(name))
        return int(getattr(item, "icon_id", 0) or 0)
    except Exception:
        return 0


def get_addon_id() -> int:
    return 0


def get_checked_id() -> int:
    return 0


def get_unchecked_id() -> int:
    return 0


def get_selected_id() -> int:
    return get_icon_id("selected")


def get_switch_id() -> int:
    return get_icon_id("switch")


def get_unmuted_id() -> int:
    return 0
