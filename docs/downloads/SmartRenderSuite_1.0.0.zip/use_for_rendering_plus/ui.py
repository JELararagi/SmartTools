from ..translation import iface_text
import bpy
from bpy.types import Context, Panel, Menu, UIList
from bl_ui.space_node import NODE_MT_context_menu
from bl_ui.space_topbar import TOPBAR_HT_upper_bar
from . import properties as props
from .op import (
    UFRP_OP_toggle, 
    UFRP_OP_batch, 
    UFRP_OP_OnlyUnmuted,
    UFRP_OP_OnlySelected,
    UFRP_OP_RenderLayerSwitch,
    UFRP_OP_AllCopyProps,
    UFRP_OP_ReloadPasses,
    UFRP_OP_CopyLayer,
    UFRP_OP_PasteLayer,
    UFRP_OT_CopyToSelected,
    UFRP_OP_ViewLayerAdd,
    UFRP_OP_ViewLayerRemove,
    UFRP_OP_ViewLayerSwitch,
    UFRP_OP_MoveLayer,
    UFRP_OP_SortLayers,
)
from . import icons
from ..help_operator import draw_help_button


def _safe_scene(context):
    try:
        return getattr(context, 'scene', None)
    except Exception:
        return None


def _safe_ufrp(context):
    scene = _safe_scene(context)
    try:
        return getattr(scene, 'ufrp', None) if scene is not None else None
    except Exception:
        return None


def _safe_icon_value(value) -> int:
    try:
        value = int(value or 0)
    except Exception:
        return 0
    return value if value > 0 else 0


def _operator_with_custom_icon(layout, operator_id, *, icon_value=0, fallback_icon='NONE', text='', **kwargs):
    icon_value = _safe_icon_value(icon_value)
    call_kwargs = dict(text=text)
    if icon_value:
        call_kwargs['icon_value'] = icon_value
    elif fallback_icon and fallback_icon != 'NONE':
        call_kwargs['icon'] = fallback_icon
    op = layout.operator(operator_id, **call_kwargs)
    for key, value in kwargs.items():
        try:
            setattr(op, key, value)
        except Exception:
            pass
    return op


class UFRP_PT_MANAGER_FILTER(Panel):
    """Show View Layer manager list options"""
    _srr_keep_popover_poll = True
    bl_label = "Manager Filter"
    bl_idname = "UFRP_PT_MANAGER_FILTER"
    bl_space_type = 'VIEW_3D'
    bl_region_type = "HEADER"
    bl_context = "view_layer"
    bl_options = {"INSTANCED"}

    def draw(self, context: Context):
        ufrp = _safe_ufrp(context)
        if ufrp is None:
            return
        lay = self.layout
        lay.label(text=iface_text("Filter manager options"))
        row = lay.row(align=True)
        row.prop(ufrp, "show_use", text="", icon="RESTRICT_RENDER_OFF", toggle=True)


class UFRP_PT_COPY_PASS_FILTER(Panel):
    """Choose which View Layer's passes to copy"""
    _srr_keep_popover_poll = True
    bl_label = "Copy Pass Filter"
    bl_idname = "UFRP_PT_COPY_PASS_FILTER"
    bl_space_type = 'VIEW_3D'
    bl_region_type = "HEADER"
    bl_context = "view_layer"
    bl_options = {"INSTANCED"}

    def draw_options_row(self, layout):
        row = layout.row(align=True)
        row.operator(UFRP_OP_AllCopyProps.bl_idname, text="", icon="RESTRICT_SELECT_OFF").action = "ON"
        row.operator(UFRP_OP_AllCopyProps.bl_idname, text="", icon="RESTRICT_SELECT_ON").action = "OFF"
        row.operator(UFRP_OP_AllCopyProps.bl_idname, text="", icon="UV_SYNC_SELECT").action = "TOGGLE"
        row.separator()
        row.operator(UFRP_OP_ReloadPasses.bl_idname, text="", icon="FILE_REFRESH")

    def draw(self, context: Context):
        lay = self.layout
        try:
            passes = props.get_passes()
        except Exception:
            passes = []
        if not passes:
            lay.operator(UFRP_OP_ReloadPasses.bl_idname, icon="FILE_REFRESH")  
            return
        self.draw_options_row(lay)
        col = lay.column(align=True)
        props_sorted = sorted(passes, key=lambda p: f"{p.sub_type}_{p.type}") #TODO sort when creating ?
        last_type = passes[0].type
        last_sub_type = passes[0].sub_type
        for p in props_sorted:
            p: props.UFRP_property_passe
            if p.type != last_type or p.sub_type != last_sub_type:
                last_type = p.type
                last_sub_type = p.sub_type
                col.separator()
                col.label(text=p.sub_type)
            match p.type:
                case "FLOAT":
                    icon = "CON_TRANSFORM"
                case "INT":
                    icon = "CON_TRANSFORM"
                case "BOOLEAN":
                    icon = "CHECKBOX_HLT"
                case "COLLECTION":
                    icon = "MOD_ARRAY"
                case "POINTER":
                    icon = "FILE_3D"
                case "STRING":
                    icon = "SYNTAX_OFF"
                case _:
                    icon = "NONE"
            col.prop(p, "is_copy", text=p.name, icon=icon, toggle=True, translate=False)
        self.draw_options_row(lay)


class UFRP_UL_layers(UIList):
    bl_idname = "UFRP_UL_layers"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if item is None:
            return
        row = layout.row(align=True)
        try:
            current_layer = getattr(context, 'view_layer', None)
        except Exception:
            current_layer = None
        if item == current_layer:
            safe_icon = _safe_icon_value(icon)
            if safe_icon:
                row.prop(item, "name", text="", emboss=False, icon_value=safe_icon)
            else:
                row.prop(item, "name", text="", emboss=False, icon="RENDERLAYERS")
        else:
            op = _operator_with_custom_icon(row, UFRP_OP_ViewLayerSwitch.bl_idname, icon_value=icons.get_switch_id(), fallback_icon="FILE_REFRESH", text="")
            try:
                op.layer_name = item.name
            except Exception:
                pass
            row.prop(item, "name", text="", emboss=False, icon="BLANK1")
        row = row.row(align=True)
        try:
            show_use = props.is_show_use()
        except Exception:
            show_use = False
        if show_use:
            icon = "RESTRICT_RENDER_OFF" if getattr(item, 'use', False) else "RESTRICT_RENDER_ON"
            row.prop(item, "use", icon_only=True, icon=icon)


class UFRP_MT_manager_context_menu(Menu):
    bl_label = "Manager Tools"
    def draw(self, context: Context):
        lay = self.layout
        lay.operator(UFRP_OP_MoveLayer.bl_idname, icon="TRIA_UP_BAR", text=iface_text("Move to Top")).direction = "TOP"
        lay.operator(UFRP_OP_MoveLayer.bl_idname, icon="TRIA_DOWN_BAR", text=iface_text("Move to Bottom")).direction = "BOTTOM"
        lay.separator()
        lay.operator(UFRP_OP_SortLayers.bl_idname, icon="SORT_ASC", text=iface_text("Sort by Name"),).is_reverse = False
        lay.operator(UFRP_OP_SortLayers.bl_idname, icon="SORT_DESC", text=iface_text("Sort reverse")).is_reverse = True
        lay.separator()
        lay.operator(UFRP_OP_batch.bl_idname, text=iface_text("Enable all")).state = True
        lay.operator(UFRP_OP_batch.bl_idname, text=iface_text("Disable all")).state = False


class UFRP_PT_manager(Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "View Layer Manager"
    bl_region_type = "WINDOW"

    def draw(self, context):
        scene = _safe_scene(context)
        ufrp = _safe_ufrp(context)
        if scene is None or ufrp is None:
            return
        lay = self.layout
        row = lay.row()
        col1 = row.column()
        col2 = row.column(align=True)
        # col1 (main)
        col1.template_list(UFRP_UL_layers.bl_idname, "", scene, "view_layers", ufrp, "index")
        if props.get_prefs_show_depricated():
            col1.label(text=iface_text("Copy/Paste View Layers properties"))
        else:
            col1.label(text=iface_text("Copy/Paste Layer Collections settings"))
        row = col1.row(align=True)
        row.prop(ufrp, "is_copy_exclude", text="", icon="CHECKBOX_HLT", toggle=True)
        row.prop(ufrp, "is_copy_hide_viewport", text="", icon="HIDE_OFF", toggle=True)
        row.prop(ufrp, "is_copy_holdout", text="", icon="HOLDOUT_ON", toggle=True)
        row.prop(ufrp, "is_copy_indirect_only", text="", icon="INDIRECT_ONLY_ON", toggle=True)
        row.separator()
        if props.get_prefs_show_depricated():
            row.prop(ufrp, "is_copy_passes", text=iface_text("Passes"), toggle=True)
            row.popover(panel=UFRP_PT_COPY_PASS_FILTER.bl_idname, text="", icon="FILTER")
            row.separator()
            row.prop(ufrp, "is_copy_aovs", text=iface_text("AOVs"), toggle=True)
            row.separator()
        row.operator(UFRP_OP_CopyLayer.bl_idname, text="", icon="COPYDOWN")
        row.operator(UFRP_OP_PasteLayer.bl_idname, text="", icon="PASTEDOWN")
        # col2 (sidebar)
        col2.operator(UFRP_OP_ViewLayerAdd.bl_idname, icon="ADD", text="")
        col2.operator(UFRP_OP_ViewLayerRemove.bl_idname, icon="REMOVE", text="")
        col2.separator()
        col2.popover(panel=UFRP_PT_MANAGER_FILTER.bl_idname, text="", icon="FILTER")
        col2.menu("UFRP_MT_manager_context_menu", icon="DOWNARROW_HLT", text="")
        col2.separator()
        col2.operator(UFRP_OP_MoveLayer.bl_idname, icon="TRIA_UP", text="").direction = "UP"
        col2.operator(UFRP_OP_MoveLayer.bl_idname, icon="TRIA_DOWN", text="").direction = "DOWN"
        draw_help_button(col2, "integrated:use_for_rendering_plus")


class UFRP_PT_manager_topbar(UFRP_PT_manager):
    _srr_keep_popover_poll = True
    bl_idname = "UFRP_PT_UFRP_PT_manager_topbarlayer_manager"
    bl_space_type = "TOPBAR"
    bl_options = {"INSTANCED"}
    bl_ui_units_x = 20
    @classmethod
    def poll(cls, context: Context):
        return props.get_prefs_show_manager_top()


class UFRP_PT_manager_properties(UFRP_PT_manager):
    _srr_keep_popover_poll = True
    bl_idname = "UFRP_PT_manager_properties"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "view_layer"
    bl_options = {"DEFAULT_CLOSED"}
    bl_parent_id = "VIEWLAYER_PT_layer"
    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'integrated:use_for_rendering_plus')

    @classmethod
    def poll(cls, context: Context):
        return props.get_prefs_show_manager_panel()
        

class UFRP_MT_comp_menu(Menu):
    bl_label = "View Layers"
    bl_idname = "UFRP_MT_VIEW_LAYERS"

    @classmethod
    def poll(cls, context):
        return props.get_prefs_show_comp_menu()

    def draw(self, context: Context):
        lay = self.layout
        lay.operator(
            UFRP_OP_toggle.bl_idname,
            text=iface_text("Enable selected"),
            icon="CHECKBOX_HLT"
        ).state = True
        lay.operator(
            UFRP_OP_toggle.bl_idname,
            text=iface_text("Disable selected"),
            icon="CHECKBOX_DEHLT"
        ).state = False
        lay.operator(
            UFRP_OP_batch.bl_idname, 
            text=iface_text("Enable all"),
        ).state = True
        lay.operator(
            UFRP_OP_batch.bl_idname, 
            text=iface_text("Disable all"),
        ).state = False
        lay.operator(
            UFRP_OP_OnlyUnmuted.bl_idname,
            icon="HIDE_OFF")
        _operator_with_custom_icon(
            lay, UFRP_OP_OnlySelected.bl_idname,
            icon_value=icons.get_selected_id(), fallback_icon="RESTRICT_SELECT_OFF")
        _operator_with_custom_icon(
            lay, UFRP_OP_RenderLayerSwitch.bl_idname,
            icon_value=icons.get_switch_id(), fallback_icon="FILE_REFRESH")


def draw_comp_menu(self: NODE_MT_context_menu, context: Context):
    space = getattr(context, 'space_data', None)
    if getattr(space, 'type', None) == "NODE_EDITOR" and getattr(space, 'tree_type', None) == "CompositorNodeTree":
        layout = self.layout
        layout.menu(UFRP_MT_comp_menu.bl_idname)


def draw_comp_context(self: NODE_MT_context_menu, context: Context):
    space_data = getattr(context, 'space_data', None)
    if (props.get_prefs_show_comp_contextual()
        and getattr(space_data, 'tree_type', None) == "CompositorNodeTree"
        and getattr(context, 'active_node', None)):
        lay = self.layout
        lay.separator()
        _operator_with_custom_icon(
            lay, UFRP_OP_RenderLayerSwitch.bl_idname,
            icon_value=icons.get_switch_id(), fallback_icon="FILE_REFRESH")
        _operator_with_custom_icon(
            lay, UFRP_OP_OnlySelected.bl_idname,
            icon_value=icons.get_selected_id(), fallback_icon="RESTRICT_SELECT_OFF")
        lay.operator(
            UFRP_OP_toggle.bl_idname,
            text=iface_text("Enable selected"),
            icon="CHECKBOX_HLT"
        ).state = True
        lay.operator(
            UFRP_OP_toggle.bl_idname,
            text=iface_text("Disable selected"),
            icon="CHECKBOX_DEHLT"
        ).state = False


def draw_manager_topbar(self: TOPBAR_HT_upper_bar, context: Context):
    region = getattr(context, 'region', None)
    if (props.get_prefs_show_manager_top()
        and getattr(region, 'alignment', None) == "RIGHT"):
        lay = self.layout
        lay.popover(panel=UFRP_PT_manager_topbar.bl_idname, text="", icon="RENDERLAYERS")


def draw_outliner_context(self, context: Context):
    if props.get_prefs_show_outliner_contextual():
        lay = self.layout
        lay.separator()
        lay.operator_context = "INVOKE_DEFAULT"
        lay.operator(UFRP_OT_CopyToSelected.bl_idname, icon="RENDERLAYERS")
        lay.operator_context = "EXEC_DEFAULT"


# NOTE right click contextual menu properties panel view layer properties
# def draw_context_passes(self, context: Context):
#     if (context.button_pointer == context.view_layer
#         and context.space_data.context == "VIEW_LAYER"):
#         lay = self.layout
#         lay.label(text=f"Property={context.button_prop.identifier}")
