import bpy
from bpy.props import BoolProperty, PointerProperty
from bpy.types import PropertyGroup

from ..translation import localize_inline, localize_pair


_REGISTER_ERROR = ""
_REGISTERED_POINTER = False

_PROPERTY_NAME = "smart_render_ufrp_prefs"


class UFRP_RuntimePreferences(PropertyGroup):
    show_manager_top: BoolProperty(
        name=localize_pair("トップバーに表示", "Show Manager in Topbar"),
        description=localize_inline("Show or hide the View Layer Manager manager popover in the top bar. / トップバーの View Layer Manager マネージャーポップオーバーを表示または非表示にします。"),
        default=True,
    )  # type: ignore
    show_manager_panel: BoolProperty(
        name=localize_pair("プロパティパネルに表示", "Show Manager in Property Panel"),
        description=localize_inline("Show or hide the View Layer Manager manager in Properties > View Layer. / Properties > View Layer にある View Layer Manager マネージャーの表示を切り替えます。"),
        default=True,
    )  # type: ignore
    show_comp_menu: BoolProperty(
        name=localize_pair('コンポジターのビューレイヤーメニューを表示', "Show Compositing View Layer Menu"),
        description=localize_inline("Show or hide the View Layer menu in the compositor context menu. / コンポジターのコンテキストメニューにある View Layer メニューの表示を切り替えます。"),
        default=True,
    )  # type: ignore
    show_comp_contextual: BoolProperty(
        name=localize_pair("コンポジター右クリック項目を表示", "Show Compositing Context Actions"),
        description=localize_inline("Show or hide right-click actions for compositor nodes. / コンポジターノードの右クリックアクションを表示または非表示にします。"),
        default=True,
    )  # type: ignore
    show_outliner_contextual: BoolProperty(
        name=localize_pair("アウトライナー右クリック項目を表示", "Show Outliner Context Action"),
        description=localize_inline("Show or hide the right-click action for outliner collections. / アウトライナーのコレクション右クリックアクションを表示または非表示にします。"),
        default=True,
    )  # type: ignore
    show_depricated: BoolProperty(
        name=localize_pair("旧式コピー項目を表示", "Show Deprecated Copy Options"),
        description=localize_inline("Show deprecated pass and AOV copy options in the manager. / マネージャー内の旧式パス・AOVコピーオプションを表示します。"),
        default=False,
    )  # type: ignore



def get_runtime_preferences(context=None):
    ctx = context or getattr(bpy, "context", None)
    wm = getattr(ctx, "window_manager", None)
    return getattr(wm, _PROPERTY_NAME, None) if wm is not None else None



def draw_runtime_settings(layout, context) -> None:
    prefs = get_runtime_preferences(context)
    if prefs is None:
        layout.label(text=localize_inline("View Layer Manager settings are not available yet. / View Layer Manager 設定はまだ利用できません。"), icon="ERROR", translate=False)
        return
    box = layout.box()
    box.label(text=localize_inline("Visibility and menu options / 表示とメニュー設定"), icon="PREFERENCES")
    col = box.column(align=True)
    col.prop(prefs, "show_manager_top")
    col.prop(prefs, "show_manager_panel")
    col.prop(prefs, "show_comp_menu")
    col.prop(prefs, "show_comp_contextual")
    col.prop(prefs, "show_outliner_contextual")
    col.prop(prefs, "show_depricated")



def register() -> None:
    global _REGISTER_ERROR, _REGISTERED_POINTER
    _REGISTER_ERROR = ""
    _REGISTERED_POINTER = False
    from ..rna_safety import register_pointer_property
    try:
        _REGISTERED_POINTER = bool(register_pointer_property(bpy.types.WindowManager, "smart_render_ufrp_prefs", UFRP_RuntimePreferences))
    except Exception as exc:
        _REGISTER_ERROR = str(exc)
        _REGISTERED_POINTER = False



def unregister() -> None:
    global _REGISTER_ERROR, _REGISTERED_POINTER
    if hasattr(bpy.types.WindowManager, "smart_render_ufrp_prefs"):
        try:
            del bpy.types.WindowManager.smart_render_ufrp_prefs
        except Exception:
            pass
    try:
        from ..rna_safety import unregister_existing_class
        unregister_existing_class(UFRP_RuntimePreferences)
    except Exception:
        pass
    _REGISTER_ERROR = ""
    _REGISTERED_POINTER = False
