from __future__ import annotations

import math
import re
from typing import Dict, Iterable, List

_TAG_SPLIT_RE = re.compile(r"[\n,;]+")


def _attr_value(obj, attr_name: str, default=None):
    try:
        value = getattr(obj, attr_name, default)
    except Exception:
        return default
    return default if value is None else value


def coerce_positive_int(value, default: int = 1, minimum: int = 1) -> int:
    try:
        result = int(value)
    except Exception:
        result = int(default)
    if result < minimum:
        return int(default) if int(default) >= minimum else minimum
    return result



def coerce_non_negative_float(value, default: float = 0.0) -> float:
    try:
        result = float(value)
    except Exception:
        result = float(default)
    return result if result >= 0.0 else float(default)



def parse_job_tags(text: str) -> List[str]:
    seen = set()
    tags: List[str] = []
    for part in _TAG_SPLIT_RE.split(str(text or "")):
        tag = part.strip()
        if tag and tag not in seen:
            seen.add(tag)
            tags.append(tag)
    return tags



def resolved_job_name(settings, variant=None) -> str:
    value = str(getattr(settings, "job_name", "main") or "main")
    if variant is not None:
        override = str(getattr(variant, "job_name_override", "") or "").strip()
        if override:
            value = override
    value = value.strip()
    return value or "main"



def resolved_job_tags(settings, variant=None) -> List[str]:
    source_text = str(getattr(settings, "job_tags", "") or "")
    if variant is not None:
        override = str(getattr(variant, "job_tags_override", "") or "")
        if override.strip():
            source_text = override
    return parse_job_tags(source_text)



def _frame_string(frames: List[int], *, blender_cli: bool = False) -> str:
    if not frames:
        return "1"
    if len(frames) == 1:
        return str(int(frames[0]))
    contiguous = all((int(frames[i]) + 1) == int(frames[i + 1]) for i in range(len(frames) - 1))
    if contiguous:
        separator = ".." if blender_cli else "-"
        return f"{int(frames[0])}{separator}{int(frames[-1])}"
    return ",".join(str(int(frame)) for frame in frames)



def frame_chunk_specs(frames: Iterable[int], chunk_size: int) -> List[Dict[str, object]]:
    ordered = [int(frame) for frame in frames]
    if not ordered:
        return []
    size = coerce_positive_int(chunk_size, default=1, minimum=1)
    specs: List[Dict[str, object]] = []
    total_chunks = int(math.ceil(len(ordered) / float(size)))
    for index, start_i in enumerate(range(0, len(ordered), size), start=1):
        chunk = ordered[start_i:start_i + size]
        specs.append(
            {
                "index": index,
                "chunk_index": index,
                "chunk_total": total_chunks,
                "start": int(chunk[0]),
                "end": int(chunk[-1]),
                "count": len(chunk),
                "frame_count": len(chunk),
                "frames": list(chunk),
                "frames_string": _frame_string(chunk, blender_cli=False),
                "blender_cli_frames": _frame_string(chunk, blender_cli=True),
            }
        )
    return specs



def resource_profile(settings, frame_count: int = 1, variant=None) -> Dict[str, object]:
    device_mode = str(getattr(settings, "execution_device_mode", "AUTO") or "AUTO")
    farm_priority = coerce_positive_int(getattr(settings, "farm_priority", 50), default=50, minimum=0)
    frame_chunk_size = coerce_positive_int(getattr(settings, "frame_chunk_size", 1), default=1, minimum=1)
    concurrent_tasks = coerce_positive_int(getattr(settings, "concurrent_tasks", 1), default=1, minimum=1)
    memory_gb_hint = coerce_non_negative_float(getattr(settings, "memory_gb_hint", 0.0), default=0.0)
    temporal_subsamples = coerce_positive_int(getattr(settings, "temporal_subsamples", 1), default=1, minimum=1)
    spatial_subsamples = coerce_positive_int(getattr(settings, "spatial_subsamples", 1), default=1, minimum=1)
    accumulation_samples = coerce_positive_int(getattr(settings, "accumulation_samples", 1), default=1, minimum=1)
    tags = resolved_job_tags(settings, variant=variant)
    job_name = resolved_job_name(settings, variant=variant)

    if variant is not None:
        device_override = str(getattr(variant, "execution_device_mode_override", "SCENE") or "SCENE")
        if device_override != "SCENE":
            device_mode = device_override
        priority_override = int(_attr_value(variant, "farm_priority_override", -1))
        if priority_override >= 0:
            farm_priority = coerce_positive_int(priority_override, default=farm_priority, minimum=0)
        chunk_override = int(getattr(variant, "frame_chunk_size_override", 0) or 0)
        if chunk_override > 0:
            frame_chunk_size = coerce_positive_int(chunk_override, default=frame_chunk_size, minimum=1)
        concurrent_override = int(getattr(variant, "concurrent_tasks_override", 0) or 0)
        if concurrent_override > 0:
            concurrent_tasks = coerce_positive_int(concurrent_override, default=concurrent_tasks, minimum=1)
        memory_override = float(_attr_value(variant, "memory_gb_hint_override", -1.0))
        if memory_override >= 0.0:
            memory_gb_hint = coerce_non_negative_float(memory_override, default=memory_gb_hint)
        temporal_override = int(getattr(variant, "temporal_subsamples_override", 0) or 0)
        if temporal_override > 0:
            temporal_subsamples = coerce_positive_int(temporal_override, default=temporal_subsamples, minimum=1)
        spatial_override = int(getattr(variant, "spatial_subsamples_override", 0) or 0)
        if spatial_override > 0:
            spatial_subsamples = coerce_positive_int(spatial_override, default=spatial_subsamples, minimum=1)
        accumulation_override = int(getattr(variant, "accumulation_samples_override", 0) or 0)
        if accumulation_override > 0:
            accumulation_samples = coerce_positive_int(accumulation_override, default=accumulation_samples, minimum=1)

    return {
        "device_mode": device_mode,
        "farm_priority": farm_priority,
        "frame_chunk_size": frame_chunk_size,
        "concurrent_tasks": concurrent_tasks,
        "memory_gb_hint": memory_gb_hint,
        "job_name": job_name,
        "job_tags": tags,
        "temporal_subsamples": temporal_subsamples,
        "spatial_subsamples": spatial_subsamples,
        "accumulation_samples": accumulation_samples,
        "frame_count": max(1, int(frame_count)),
        "sampling": {
            "temporal_subsamples": temporal_subsamples,
            "spatial_subsamples": spatial_subsamples,
            "accumulation_samples": accumulation_samples,
        },
    }
