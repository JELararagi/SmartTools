# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

ADDON_ID = "smart_render_suite"
ADDON_NAME = "Smart Render"
ADDON_VERSION = (1, 0, 0)
ADDON_VERSION_STR = ".".join(str(v) for v in ADDON_VERSION)
BLENDER_MIN_VERSION = (5, 1, 0)
MANIFEST_SCHEMA_VERSION = "srs-manifest-3.15.34"

BL_INFO = {
    "name": ADDON_NAME,
    "author": "JELararagi",
    "version": ADDON_VERSION,
    "blender": BLENDER_MIN_VERSION,
    "location": "View3D > Sidebar > Smart Render",
    "description": (
        "Render orchestration, Render Pipeline Manager precision cockpit workflows, large-icon UI, variants, diagnostics, AOV tools, "
        "override-aware queue rendering, and bridge manifests for Blender 5.1+"
    ),
    "category": "Render",
}
