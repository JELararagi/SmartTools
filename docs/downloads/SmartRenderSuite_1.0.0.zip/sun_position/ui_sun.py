from ..translation import iface_text
import bpy
from bpy.types import Operator
from bl_operators.presets import AddPresetBase
from bl_ui.utils import PresetPanel

from ..translation import localize_inline
from .sun_calc import format_time, format_hms
from .runtime_preferences import get_runtime_preferences
from ..help_operator import draw_help_button


def _get_addon_prefs(context):
    return get_runtime_preferences(context)


# -------------------------------------------------------------------
# Choice list of places, month and day at 12:00 noon
# -------------------------------------------------------------------


class SUNPOS_PT_Presets(PresetPanel, bpy.types.Panel):
    bl_label = "Sun Position Control Presets"
    _srr_keep_popover_poll = True
    preset_subdir = "operator/sun_position"
    preset_operator = "script.execute_preset"
    preset_add_operator = "world.add_sun_position_preset"


class SUNPOS_OT_AddPreset(AddPresetBase, Operator):
    '''Add a new preset for Sun Position Control settings'''
    bl_options = {'UNDO'}
    bl_idname = "world.add_sun_position_preset"
    bl_label = "Add Sun Position Preset"
    preset_menu = "SUNPOS_PT_Presets"

    # variable used for all preset values
    preset_defines = ["sun_props = bpy.context.scene.sun_pos_properties"]

    # properties to store in the preset
    preset_values = [
        "sun_props.day",
        "sun_props.month",
        "sun_props.time",
        "sun_props.year",
        "sun_props.UTC_zone",
        "sun_props.use_daylight_savings",
        "sun_props.latitude",
        "sun_props.longitude",
    ]

    # where to store the preset
    preset_subdir = "operator/sun_position"


# -------------------------------------------------------------------
#
#   Draw the Sun Panel, sliders, et. al.
#
# -------------------------------------------------------------------


class SUNPOS_PT_Panel(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    bl_context = "world"
    bl_label = "Sun Position Control"
    bl_options = {'DEFAULT_CLOSED'}

    def draw_header_preset(self, _context):
        SUNPOS_PT_Presets.draw_panel_header(self.layout)
        draw_help_button(self.layout, 'integrated:sun_position')

    def draw(self, context):
        sun_props = context.scene.sun_pos_properties
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        layout.prop(sun_props, "usage_mode", expand=True)
        layout.separator()

        if sun_props.usage_mode == "ENVIRONMENT":
            self.draw_environment_mode_panel(context)
        else:
            self.draw_normal_mode_panel(context)

    def draw_environment_mode_panel(self, context):
        sun_props = context.scene.sun_pos_properties
        layout = self.layout

        col = layout.column(align=True)
        col.prop_search(sun_props, "sun_object", context.view_layer, "objects")
        if context.scene.world is not None:
            if context.scene.world.node_tree is not None:
                col.prop_search(sun_props, "env_texture", context.scene.world.node_tree, "nodes")
            else:
                col.label(text=iface_text("Please activate Use Nodes in the World panel."), icon="ERROR")
        else:
            col.label(text=iface_text("Please select World in the World panel."), icon="ERROR")

        layout.use_property_decorate = True

        col = layout.column(align=True)
        col.prop(sun_props, "bind_to_sun")
        col.prop(sun_props, "env_azimuth")
        row = col.row(align=True)
        row.active = True
        row.prop(sun_props, "env_elevation")
        col.prop(sun_props, "env_distance")
        col.separator()

        col = layout.column(align=True)
        row = col.row(align=True)
        row.operator("world.pick_sun_in_viewport", icon='LIGHT_SUN')

    def draw_normal_mode_panel(self, context):
        sun_props = context.scene.sun_pos_properties
        addon_prefs = _get_addon_prefs(context)
        layout = self.layout

        col = layout.column(align=True)
        col.prop(sun_props, "sun_object")
        col.separator()

        col.prop(sun_props, "object_collection")
        if sun_props.object_collection:
            col.prop(sun_props, "object_collection_type")
            if sun_props.object_collection_type == 'DIURNAL':
                col.prop(sun_props, "time_spread")
        col.separator()

        if context.scene.world is not None:
            if context.scene.world.node_tree is not None:
                col.prop_search(sun_props, "sky_texture", context.scene.world.node_tree, "nodes")
            else:
                col.label(text=iface_text("Please activate Use Nodes in the World panel."), icon="ERROR")
        else:
            col.label(text=iface_text("Please select World in the World panel."), icon="ERROR")

        if addon_prefs.show_overlays:
            overlay_ops = layout.column(align=True)
            if sun_props.show_analemmas:
                overlay_ops.operator("world.create_analemma_object", text=iface_text("Create Analemmas Object"))
            if sun_props.show_surface:
                overlay_ops.operator("world.create_sun_path_surface", text=iface_text("Create Surface Object"))

        if addon_prefs.show_refraction:
            col = layout.column(align=True, heading=iface_text("Use"))
            col.prop(sun_props, "use_refraction", text=iface_text("Refraction"))


class SUNPOS_PT_Location(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    bl_context = "world"
    bl_label = "Location"
    bl_parent_id = ""

    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'integrated:sun_position')

    @classmethod
    def poll(self, context):
        sun_props = context.scene.sun_pos_properties
        return sun_props.usage_mode != "ENVIRONMENT"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True

        sun_props = context.scene.sun_pos_properties
        addon_prefs = _get_addon_prefs(context)

        col = layout.column(align=True)
        col.prop(sun_props, "coordinates", icon='URL')
        col.prop(sun_props, "latitude")
        col.prop(sun_props, "longitude")

        col.separator()

        col = layout.column(align=True)
        col.prop(sun_props, "north_offset")

        if addon_prefs.show_az_el:
            col = layout.column(align=True)
            col.prop(sun_props, "sun_elevation", text=iface_text("Elevation"))
            col.prop(sun_props, "sun_azimuth", text=iface_text("Azimuth"))
            col.separator()

        col = layout.column()
        col.prop(sun_props, "sun_distance")
        col.separator()


class SUNPOS_PT_Time(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Render'
    bl_context = "world"
    bl_label = "Time"
    bl_parent_id = ""

    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'integrated:sun_position')

    @classmethod
    def poll(self, context):
        sun_props = context.scene.sun_pos_properties
        return sun_props.usage_mode != "ENVIRONMENT"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True

        sun_props = context.scene.sun_pos_properties
        addon_prefs = _get_addon_prefs(context)

        col = layout.column(align=True)
        col.prop(sun_props, "use_day_of_year")
        if sun_props.use_day_of_year:
            col.prop(sun_props, "day_of_year")
        else:
            col.prop(sun_props, "day")
            col.prop(sun_props, "month")
        col.prop(sun_props, "year")
        col.separator()

        col = layout.column(align=True)
        col.prop(sun_props, "time")
        col.prop(sun_props, "UTC_zone")
        col.prop(sun_props, "use_daylight_savings")
        col.separator()

        local_time = format_time(sun_props.time, sun_props.use_daylight_savings)
        utc_time = format_time(sun_props.time, sun_props.use_daylight_savings, sun_props.UTC_zone)

        col = layout.column(align=True)
        col.alignment = 'CENTER'

        split = col.split(factor=0.5, align=True)
        sub = split.column(align=True)
        sub.alignment = 'RIGHT'
        sub.label(text=iface_text("Time Local:"))
        sub.label(text=iface_text("UTC:"))

        sub = split.column(align=True)
        sub.label(text=local_time)
        sub.label(text=utc_time)
        col.separator()

        if addon_prefs.show_rise_set:
            sunrise = format_hms(sun_props.sunrise_time)
            sunset = format_hms(sun_props.sunset_time)

            col = layout.column(align=True)
            col.alignment = 'CENTER'

            split = col.split(factor=0.5, align=True)
            sub = split.column(align=True)
            sub.alignment = 'RIGHT'
            sub.label(text=iface_text("Sunrise:"))
            sub.label(text=iface_text("Sunset:"))

            sub = split.column(align=True)
            sub.label(text=sunrise)
            sub.label(text=sunset)

        col.separator()
