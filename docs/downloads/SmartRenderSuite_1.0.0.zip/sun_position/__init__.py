# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

bl_info = {
    "name": 'Sun Position Control',
    "author": "JELararagi",
    "version": (4, 4, 0),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Render",
    "description": "Physically guided daylight controls and sun positioning integrated into Smart Render N-panel.",
    "category": "Lighting",
}

if "bpy" in locals():
    import importlib

    if "runtime_prefs" not in globals():
        from . import runtime_preferences as runtime_prefs
    importlib.reload(draw)
    importlib.reload(environment)
    importlib.reload(operators)
    importlib.reload(properties)
    importlib.reload(runtime_prefs)
    importlib.reload(sun_calc)
    importlib.reload(translations)
    importlib.reload(ui_sun)
else:
    from . import (
        draw,
        environment,
        operators,
        properties,
        sun_calc,
        translations,
        ui_sun,
    )
    from . import runtime_preferences as runtime_prefs

import bpy
from bpy.app.handlers import persistent


SUN_POSITION_CLASSES = (
    properties.SunPosProperties,
    operators.SUNPOS_OT_Create_Analemmas_Object,
    operators.SUNPOS_OT_Create_Surface_Object,
    ui_sun.SUNPOS_OT_AddPreset,
    ui_sun.SUNPOS_PT_Presets,
    ui_sun.SUNPOS_PT_Panel,
    ui_sun.SUNPOS_PT_Location,
    ui_sun.SUNPOS_PT_Time,
    environment.SUNPOS_OT_ShowEnvironment,
)


@persistent
def sun_frame_handler(scene):
    sun_props = scene.sun_pos_properties
    if not bool(getattr(sun_props, "auto_update_callbacks", False)):
        return
    if sun_props.usage_mode == "ENVIRONMENT":
        sun_calc.move_sun_env(scene)
    else:
        sun_calc.move_sun(scene)

    if not (bpy.app.is_job_running("RENDER") or bpy.app.is_job_running("OBJECT_BAKE")):
        if sun_props.show_surface or sun_props.show_analemmas:
            draw.analemmas_surface_update(scene)
        if sun_props.show_north:
            draw.north_update(scene)


@persistent
def sun_scene_handler(_filename):
    """Update drawing on file load."""
    scene = getattr(bpy.context, "scene", None)
    if scene is None or not hasattr(scene, "sun_pos_properties"):
        return

    sun_props = scene.sun_pos_properties

    # A load handler can still be present from the previously opened file. If
    # this file does not explicitly enable automatic Sun updates, do not touch
    # overlay data, the Sun object, or the environment texture during file load.
    if not bool(getattr(sun_props, "auto_update_callbacks", False)):
        try:
            sync_runtime_handlers(context=getattr(bpy, "context", None))
        except Exception:
            pass
        return

    # Force drawing update only while automatic updates are explicitly enabled.
    draw.analemmas_surface_update(scene)
    draw.north_update(scene)

    # Do not force property self-assignment on file load. That fires update
    # callbacks which can move the configured Sun object immediately after a
    # saved scene is reopened. Normal edits and frame-change callbacks still
    # update the Sun when the user explicitly changes Sun Position settings.

    # Re-evaluate whether callbacks should stay enabled for the newly loaded file.
    try:
        sync_runtime_handlers(context=getattr(bpy, "context", None))
    except Exception:
        pass



def _append_handler_once(handler_list, fn) -> None:
    if handler_list is None:
        return
    if fn not in handler_list:
        handler_list.append(fn)



def _remove_handler_if_present(handler_list, fn) -> None:
    if handler_list is None:
        return
    try:
        while fn in handler_list:
            handler_list.remove(fn)
    except Exception:
        pass



def _runtime_callbacks_requested() -> bool:
    for scene in getattr(bpy.data, "scenes", ()):
        props = getattr(scene, "sun_pos_properties", None)
        if props is None:
            continue
        try:
            if bool(getattr(props, "auto_update_callbacks", False)):
                return True
        except Exception:
            continue
    return False



def sync_runtime_handlers(context=None, *, force_disable: bool = False) -> None:
    """Register heavy timeline/file-load callbacks only when the user enables them."""
    requested = False if force_disable else _runtime_callbacks_requested()

    frame_handlers = getattr(bpy.app.handlers, "frame_change_post", None)
    load_handlers = getattr(bpy.app.handlers, "load_post", None)

    if requested:
        _append_handler_once(frame_handlers, sun_frame_handler)
        _append_handler_once(load_handlers, sun_scene_handler)
        return

    _remove_handler_if_present(frame_handlers, sun_frame_handler)
    _remove_handler_if_present(load_handlers, sun_scene_handler)



def register():
    import os

    from ..rna_safety import ensure_registered_class, register_pointer_property
    for cls in SUN_POSITION_CLASSES:
        ensure_registered_class(cls)
    register_pointer_property(
        bpy.types.Scene,
        "sun_pos_properties",
        properties.SunPosProperties,
        name="Sun Position Control",
        description="Sun Position Control Settings",
    )
    runtime_prefs.register()
    sync_runtime_handlers(context=getattr(bpy, "context", None))
    bpy.app.translations.register(__name__, translations.translations_dict)
    bpy.utils.register_preset_path(os.path.dirname(__file__))



def unregister():
    import os

    bpy.utils.unregister_preset_path(os.path.dirname(__file__))
    bpy.app.translations.unregister(__name__)
    sync_runtime_handlers(context=None, force_disable=True)
    runtime_prefs.unregister()
    if hasattr(bpy.types, "Scene") and hasattr(bpy.types.Scene, "sun_pos_properties"):
        del bpy.types.Scene.sun_pos_properties
    from ..rna_safety import unregister_existing_class
    for cls in reversed(SUN_POSITION_CLASSES):
        unregister_existing_class(cls)
