import bpy
from bpy.props import BoolProperty, PointerProperty
from bpy.types import PropertyGroup
from types import SimpleNamespace

from ..translation import localize_inline, localize_pair


def _persistent_property(factory):
    def _factory(*args, **kwargs):
        options = dict(kwargs)
        previous = options.get('update')

        def _update(self, context):
            if callable(previous):
                previous(self, context)
            try:
                from .. import settings as _suite_settings
                if not _suite_settings.is_applying_context():
                    _suite_settings.snapshot_context(context, force=False)
            except Exception:
                pass

        options['update'] = _update
        return factory(*args, **options)
    return _factory


BoolProperty = _persistent_property(BoolProperty)


_REGISTER_ERROR = ""
_REGISTERED_POINTER = False

_PROPERTY_NAME = "smart_render_sun_position_prefs"
DEFAULT_PREFS = SimpleNamespace(
    show_overlays=True,
    show_refraction=True,
    show_az_el=True,
    show_rise_set=True,
)



def _runtime_refresh(self, context) -> None:
    try:
        scene = getattr(context, "scene", None) or getattr(bpy.context, "scene", None)
        if scene is None:
            return
        from .draw import north_update, analemmas_surface_update
        north_update(scene)
        analemmas_surface_update(scene)
        try:
            from .properties import sun_update
            sun_update(self, context)
        except Exception:
            pass
    except Exception:
        pass


class SUNPOS_RuntimePreferences(PropertyGroup):
    show_overlays: BoolProperty(
        name=localize_pair("オーバーレイを表示", "Show Overlays"),
        description=localize_pair("ビューポート上の北方向、アナレンマ、サーフェスオーバーレイを表示します。", "Display north, analemmas, and surface overlays in the viewport."),
        default=True,
        update=_runtime_refresh,
    )  # type: ignore
    show_refraction: BoolProperty(
        name=localize_pair("屈折を表示", "Refraction"),
        description=localize_pair("Sun Position Control パネル内の屈折オプションを表示します。", "Show the refraction option in the Sun Position Control panel."),
        default=True,
    )  # type: ignore
    show_az_el: BoolProperty(
        name=localize_pair("方位角と高度を表示", "Azimuth and Elevation Info"),
        description=localize_pair("方位角と高度の情報ラベルを表示します。", "Show azimuth and elevation information labels."),
        default=True,
    )  # type: ignore
    show_rise_set: BoolProperty(
        name=localize_pair("日の出と日の入りを表示", "Sunrise and Sunset Info"),
        description=localize_pair("日の出と日の入りの情報ラベルを表示します。", "Show sunrise and sunset information labels."),
        default=True,
    )  # type: ignore



def get_runtime_preferences(context=None, *, fallback: bool = True):
    ctx = context or getattr(bpy, "context", None)
    wm = getattr(ctx, "window_manager", None)
    prefs = getattr(wm, _PROPERTY_NAME, None) if wm is not None else None
    if prefs is not None:
        return prefs
    return DEFAULT_PREFS if fallback else None



def draw_runtime_settings(layout, context) -> None:
    prefs = get_runtime_preferences(context, fallback=False)
    if prefs is None:
        layout.label(text=localize_pair("Sun Position Control の表示設定はまだ利用できません。", "Sun Position Control display settings are not available yet."), icon="ERROR", translate=False)
        return
    box = layout.box()
    box.label(text=localize_pair("表示オプション", "Display Options"), icon="PREFERENCES")
    flow = box.grid_flow(columns=1, even_columns=True, even_rows=False, align=True)
    flow.prop(prefs, "show_refraction")
    flow.prop(prefs, "show_overlays")
    flow.prop(prefs, "show_az_el")
    flow.prop(prefs, "show_rise_set")



def draw_integrated_controls(layout, context) -> None:
    from ..ui_runtime import _call_draw
    from .ui_sun import SUNPOS_PT_Location, SUNPOS_PT_Panel, SUNPOS_PT_Presets, SUNPOS_PT_Time

    SUNPOS_PT_Presets.draw_menu(layout, text=localize_pair("太陽位置プリセット", "Sun Position Presets"))
    _call_draw(SUNPOS_PT_Panel.draw, SUNPOS_PT_Panel, layout.column(), context)
    if context.scene.sun_pos_properties.usage_mode != 'ENVIRONMENT':
        for panel in (SUNPOS_PT_Location, SUNPOS_PT_Time):
            _call_draw(panel.draw, panel, layout.column(), context)


def register() -> None:
    global _REGISTER_ERROR, _REGISTERED_POINTER
    _REGISTER_ERROR = ""
    _REGISTERED_POINTER = False
    from ..rna_safety import register_pointer_property
    try:
        _REGISTERED_POINTER = bool(register_pointer_property(bpy.types.WindowManager, "smart_render_sun_position_prefs", SUNPOS_RuntimePreferences))
    except Exception as exc:
        _REGISTER_ERROR = str(exc)
        _REGISTERED_POINTER = False



def unregister() -> None:
    global _REGISTER_ERROR, _REGISTERED_POINTER
    if hasattr(bpy.types.WindowManager, "smart_render_sun_position_prefs"):
        try:
            del bpy.types.WindowManager.smart_render_sun_position_prefs
        except Exception:
            pass
    try:
        from ..rna_safety import unregister_existing_class
        unregister_existing_class(SUNPOS_RuntimePreferences)
    except Exception:
        pass
    _REGISTER_ERROR = ""
    _REGISTERED_POINTER = False
