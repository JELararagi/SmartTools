from __future__ import annotations

import re
from typing import Dict, List, Tuple

from .compat import default_output_root, parse_name_list
from .translation import enum_label, tooltip
from .verification import verification_scope_requires_passes


_HEAVY_PASS_BUNDLES = {"COMPOSITE", "LOOKDEV", "LIGHTING", "CRYPTOMATTE", "DATASET", "TECHNICAL"}
_IMAGE_FORMATS_BEST_FOR_PASSES = {"OPEN_EXR", "OPEN_EXR_MULTILAYER", "TIFF"}
_REPEATED_SLASH_RE = re.compile(r"/+")
_REPEATED_SEP_RE = re.compile(r"([ _\-.])\1+")
_TRAILING_EXT_RE = re.compile(
    r"(?i)(?:\.(?:png|jpe?g|exr|tiff?|webp|bmp|mov|mp4|webm|mkv|avi)|\.\{ext\}|\.\{format\})+$"
)



def _attr_value(obj, attr_name: str, default=None):
    try:
        value = getattr(obj, attr_name, default)
    except Exception:
        return default
    return default if value is None else value


WORKFLOW_RECIPES: Tuple[Dict[str, str], ...] = (
    {
        "id": "SAFE_REVIEW",
        "label_en": 'Review Stills',
        "label_ja": 'レビュー静止画',
        "description_en": "Fast and safe still-image review settings. Keeps the current engine, writes PNG, verifies the main output only, and disables movie encoding.",
        "description_ja": "現在エンジンを維持しつつ、安全に静止画レビューしやすい設定です。PNG 出力、メイン画像のみ検証、ムービー化オフにします。",
    },
    {
        "id": "FINAL_EXR_COMPOSITE",
        "label_en": 'Final EXR Composite',
        "label_ja": '最終EXR合成',
        "description_en": "Cycles + final quality + multilayer EXR + compositor-oriented verification for downstream compositing.",
        "description_ja": "Cycles / Final / マルチレイヤー EXR / コンポジタ前提の検証へまとめる、合成向け最終出力レシピです。",
    },
    {
        "id": "LOOKDEV_EXR",
        "label_en": 'Lookdev EXR',
        "label_ja": 'ルックデブEXR',
        "description_en": "Cycles preview lookdev preset with broader AOV coverage and EXR outputs for material and lighting iteration.",
        "description_ja": "材質・ライティングの試行に向く、Cycles プレビュー品質 + 広めの AOV + EXR 出力レシピです。",
    },
    {
        "id": "LIGHTING_BREAKDOWN",
        "label_en": 'Lighting Breakdown',
        "label_ja": 'ライティング分解',
        "description_en": "Lighting-oriented EXR preset with compositor output, useful for key/fill/rim and lighting-pass inspection.",
        "description_ja": "ライティング検証向けの EXR レシピです。コンポジタ出力と検証を組み合わせ、照明パスの確認をしやすくします。",
    },
    {
        "id": "NPR_LINEART",
        "label_en": 'NPR Line Art',
        "label_ja": 'NPR線画',
        "description_en": "Preview-friendly line-art recipe enabling Freestyle-style output with lightweight PNG review settings.",
        "description_ja": "Freestyle 系の線画レビューをしやすくする軽量レシピです。PNG ベースで扱いやすくします。",
    },
    {
        "id": "DATASET_EXR",
        "label_en": 'Dataset EXR',
        "label_ja": 'データセットEXR',
        "description_en": "Dataset-oriented EXR recipe with resume-friendly defaults, AOV verification, and safe uniqueness settings.",
        "description_ja": "再開しやすさと AOV 検証を重視した、データセット生成向け EXR レシピです。",
    },
    {
        "id": "ANIMATIC_MOVIE",
        "label_en": 'Review Movie',
        "label_ja": 'レビュー動画',
        "description_en": "Preview movie recipe that keeps outputs simple, enables FFmpeg planning, and favors frame-sequence-to-movie review delivery.",
        "description_ja": "レビュー動画を作りやすくするレシピです。連番画像を基本にしつつ、FFmpeg ムービー化計画を有効にします。",
    },
)


def workflow_recipe_items():
    return [
        (
            recipe["id"],
            enum_label(recipe["label_ja"], recipe["label_en"]),
            tooltip(
                recipe["description_ja"],
                recipe["description_en"],
                usage_ja="まず用途に近いレシピを選んで適用し、そのあと必要な項目だけを微調整してください。大きく迷う場合の安全な出発点として使えます。",
                usage_en="Choose the recipe closest to your goal, apply it, and then tweak only the settings you need. It is meant to be a safe starting point when you are unsure where to begin.",
                tip_ja='適用後はレンダープロファイル、出力、Render Elements、キューの順で確認すると差分を追いやすいです。',
                tip_en="After applying a recipe, review Render Profile, Output, Render Elements, and Queue in that order so it is easier to understand the changes.",
            ),
        )
        for recipe in WORKFLOW_RECIPES
    ]


def workflow_recipe_meta(recipe_id: str) -> Dict[str, str]:
    key = str(recipe_id or "").strip().upper()
    for recipe in WORKFLOW_RECIPES:
        if recipe["id"] == key:
            return dict(recipe)
    return dict(WORKFLOW_RECIPES[0])


def _set_attr(target, attr_name: str, value, changes: List[str], message_ja: str, message_en: str) -> None:
    if target is None or not hasattr(target, attr_name):
        return
    old_value = getattr(target, attr_name)
    if old_value == value:
        return
    setattr(target, attr_name, value)
    changes.append(f"{message_ja} / {message_en}")


def _trim_slashes(text: str) -> str:
    value = str(text or "").replace("\\", "/").strip()
    value = _REPEATED_SLASH_RE.sub("/", value)
    return value.strip()


def _strip_trailing_extension(pattern: str) -> str:
    value = _trim_slashes(pattern)
    if not value:
        return ""
    segments = value.split("/")
    basename = segments[-1]
    basename = _TRAILING_EXT_RE.sub("", basename).strip(" .")
    segments[-1] = basename or "render"
    return "/".join(segment for segment in segments if segment)


def _cleanup_movie_pattern(pattern: str) -> str:
    value = _strip_trailing_extension(pattern)
    if not value:
        return ""
    value = value.replace("{frame}", "")
    value = value.replace("[frame]", "")
    value = re.sub(r"(?i)\{frame\}", "", value)
    value = re.sub(r"/{2,}", "/", value)
    value = _REPEATED_SEP_RE.sub(r"\1", value)
    value = re.sub(r"([ _\-.])+/+", "/", value)
    value = re.sub(r"/+([ _\-.])", "/", value)
    value = re.sub(r"[/ _\-.]+$", "", value)
    value = re.sub(r"^[ _\-.]+", "", value)
    if not value:
        return "{scene}_{variant}_{camera}_{view_layer}"
    return value


def _normalize_name_list_text(text: str) -> str:
    return ", ".join(parse_name_list(text))


def _pair_label(camera_name: str, view_layer_name: str) -> str:
    camera_label = str(camera_name or "").strip() or "Scene Camera"
    layer_label = str(view_layer_name or "").strip() or "Active Layer"
    return f"{camera_label} | {layer_label}"


def apply_workflow_recipe(scene, settings, recipe_id: str) -> List[str]:
    key = str(recipe_id or "").strip().upper()
    changes: List[str] = []

    _set_attr(settings, "auto_create_folders", True, changes, "保存先自動作成を有効化", "Enabled auto-create folders")
    _set_attr(settings, "auto_unique_tokens", True, changes, "安全な一意化を有効化", "Enabled safe auto-unique tokens")
    _set_attr(settings, "verify_outputs_after_render", True, changes, "出力検証を有効化", "Enabled output verification")
    _set_attr(settings, "cleanup_invalid_outputs", True, changes, "壊れた出力の自動削除を有効化", "Enabled cleanup of invalid outputs")

    if key == "FINAL_EXR_COMPOSITE":
        _set_attr(settings, "engine_mode", "CYCLES", changes, "エンジンを Cycles に設定", "Set engine to Cycles")
        _set_attr(settings, "quality_mode", "FINAL", changes, '品質を最終に設定', "Set quality to Final")
        _set_attr(settings, "pass_bundle", "COMPOSITE", changes, 'パスを合成に設定', "Set pass bundle to Composite")
        _set_attr(settings, "image_format", "OPEN_EXR_MULTILAYER", changes, '画像形式を OpenEXR マルチレイヤーに設定', "Set image format to OpenEXR Multilayer")
        _set_attr(settings, "verification_scope", "PRIMARY_AND_PASSES", changes, '検証範囲をメイン + パスに設定', "Set verification scope to Main + Passes")
        _set_attr(settings, "queue_compositing_mode", "COMPOSITOR", changes, 'キュー出力をコンポジター優先に設定', "Prefer compositor output for the queue")
        _set_attr(settings, "enable_movie_encode", False, changes, "ムービー化をオフ", "Disabled movie encoding")
    elif key == "LOOKDEV_EXR":
        _set_attr(settings, "engine_mode", "CYCLES", changes, "エンジンを Cycles に設定", "Set engine to Cycles")
        _set_attr(settings, "quality_mode", "PREVIEW", changes, '品質をプレビューに設定', "Set quality to Preview")
        _set_attr(settings, "pass_bundle", "LOOKDEV", changes, 'パスをルックデブに設定', "Set pass bundle to Lookdev")
        _set_attr(settings, "image_format", "OPEN_EXR", changes, "画像形式を OpenEXR に設定", "Set image format to OpenEXR")
        _set_attr(settings, "verification_scope", "PRIMARY_AND_PASSES", changes, '検証範囲をメイン + パスに設定', "Set verification scope to Main + Passes")
        _set_attr(settings, "queue_compositing_mode", "COMPOSITOR", changes, 'キュー出力をコンポジター優先に設定', "Prefer compositor output for the queue")
        _set_attr(settings, "enable_movie_encode", False, changes, "ムービー化をオフ", "Disabled movie encoding")
    elif key == "LIGHTING_BREAKDOWN":
        _set_attr(settings, "engine_mode", "CYCLES", changes, "エンジンを Cycles に設定", "Set engine to Cycles")
        _set_attr(settings, "quality_mode", "FINAL", changes, '品質を最終に設定', "Set quality to Final")
        _set_attr(settings, "pass_bundle", "LIGHTING", changes, 'パスをライティングに設定', "Set pass bundle to Lighting")
        _set_attr(settings, "image_format", "OPEN_EXR_MULTILAYER", changes, '画像形式を OpenEXR マルチレイヤーに設定', "Set image format to OpenEXR Multilayer")
        _set_attr(settings, "verification_scope", "PRIMARY_AND_PASSES", changes, '検証範囲をメイン + パスに設定', "Set verification scope to Main + Passes")
        _set_attr(settings, "queue_compositing_mode", "COMPOSITOR", changes, 'キュー出力をコンポジター優先に設定', "Prefer compositor output for the queue")
        _set_attr(settings, "enable_movie_encode", False, changes, "ムービー化をオフ", "Disabled movie encoding")
    elif key == "NPR_LINEART":
        _set_attr(settings, "quality_mode", "PREVIEW", changes, '品質をプレビューに設定', "Set quality to Preview")
        _set_attr(settings, "pass_bundle", "TECHNICAL", changes, 'パスをテクニカルに設定', "Set pass bundle to Technical")
        _set_attr(settings, "image_format", "PNG", changes, "画像形式を PNG に設定", "Set image format to PNG")
        _set_attr(settings, "use_freestyle", True, changes, "Freestyle を有効化", "Enabled Freestyle")
        _set_attr(settings, "verification_scope", "PRIMARY_ONLY", changes, '検証範囲をメインのみに設定', "Set verification scope to Main Only")
        _set_attr(settings, "queue_compositing_mode", "DIRECT", changes, 'キュー出力を直接に設定', "Use direct output for the queue")
        _set_attr(settings, "enable_movie_encode", False, changes, "ムービー化をオフ", "Disabled movie encoding")
    elif key == "DATASET_EXR":
        _set_attr(settings, "engine_mode", "CYCLES", changes, "エンジンを Cycles に設定", "Set engine to Cycles")
        _set_attr(settings, "quality_mode", "FINAL", changes, '品質を最終に設定', "Set quality to Final")
        _set_attr(settings, "pass_bundle", "DATASET", changes, 'パスをデータセットに設定', "Set pass bundle to Dataset")
        _set_attr(settings, "image_format", "OPEN_EXR", changes, "画像形式を OpenEXR に設定", "Set image format to OpenEXR")
        _set_attr(settings, "verification_scope", "PRIMARY_AND_PASSES", changes, '検証範囲をメイン + パスに設定', "Set verification scope to Main + Passes")
        _set_attr(settings, "queue_compositing_mode", "COMPOSITOR", changes, 'キュー出力をコンポジター優先に設定', "Prefer compositor output for the queue")
        _set_attr(settings, "skip_existing_frames", True, changes, "既存フレームのスキップを有効化", "Enabled skip existing frames")
        _set_attr(settings, "enable_movie_encode", False, changes, "ムービー化をオフ", "Disabled movie encoding")
    elif key == "ANIMATIC_MOVIE":
        _set_attr(settings, "quality_mode", "PREVIEW", changes, '品質をプレビューに設定', "Set quality to Preview")
        _set_attr(settings, "pass_bundle", "ESSENTIAL", changes, 'パスを基本に設定', "Set pass bundle to Essential")
        _set_attr(settings, "image_format", "PNG", changes, "画像形式を PNG に設定", "Set image format to PNG")
        _set_attr(settings, "verification_scope", "PRIMARY_ONLY", changes, '検証範囲をメインのみに設定', "Set verification scope to Main Only")
        _set_attr(settings, "queue_compositing_mode", "DIRECT", changes, 'キュー出力を直接に設定', "Use direct output for the queue")
        _set_attr(settings, "enable_movie_encode", True, changes, "ムービー化を有効化", "Enabled movie encoding")
        _set_attr(settings, "movie_preset", "H264_HIGH_MP4", changes, "ムービープリセットを H.264 High MP4 に設定", "Set movie preset to H.264 High MP4")
    else:
        _set_attr(settings, "quality_mode", "PREVIEW", changes, '品質をプレビューに設定', "Set quality to Preview")
        _set_attr(settings, "pass_bundle", "ESSENTIAL", changes, 'パスを基本に設定', "Set pass bundle to Essential")
        _set_attr(settings, "image_format", "PNG", changes, "画像形式を PNG に設定", "Set image format to PNG")
        _set_attr(settings, "verification_scope", "PRIMARY_ONLY", changes, '検証範囲をメインのみに設定', "Set verification scope to Main Only")
        _set_attr(settings, "queue_compositing_mode", "DIRECT", changes, 'キュー出力を直接に設定', "Use direct output for the queue")
        _set_attr(settings, "enable_movie_encode", False, changes, "ムービー化をオフ", "Disabled movie encoding")

    return changes


def auto_repair_scene(scene, settings) -> List[str]:
    changes: List[str] = []

    output_dir_pattern = _trim_slashes(getattr(settings, "output_dir_pattern", "") or "")
    if output_dir_pattern:
        _set_attr(settings, "output_dir_pattern", output_dir_pattern, changes, "保存ディレクトリパターンの区切りを正規化", "Normalized directory-pattern separators")

    output_file_pattern = _strip_trailing_extension(getattr(settings, "output_file_pattern", "") or "")
    if output_file_pattern:
        _set_attr(settings, "output_file_pattern", output_file_pattern, changes, "出力ファイル名から拡張子を除去", "Removed explicit extension from the output file pattern")

    movie_pattern = _cleanup_movie_pattern(getattr(settings, "movie_file_pattern", "") or "")
    if movie_pattern:
        _set_attr(settings, "movie_file_pattern", movie_pattern, changes, "ムービー名パターンを整理", "Cleaned the movie file pattern")

    normalized_tags = ", ".join(parse_name_list(getattr(settings, "job_tags", "") or ""))
    _set_attr(settings, "job_tags", normalized_tags, changes, "ジョブタグを整理", "Normalized job tags")

    if not str(getattr(settings, "output_root", "") or "").strip():
        _set_attr(settings, "output_root", default_output_root(create=True), changes, "空の保存先を既定値へ補正", "Repaired empty output root with the default path")

    if not str(getattr(settings, "output_dir_pattern", "") or "").strip():
        _set_attr(settings, "output_dir_pattern", "{blend}/{scene}/{camera}/{view_layer}/{quality}", changes, "空のフォルダーパターンを既定値へ補正", "Repaired an empty directory pattern with the default pattern")

    if not str(getattr(settings, "output_file_pattern", "") or "").strip():
        _set_attr(settings, "output_file_pattern", "{scene}_{camera}_{view_layer}_{frame}", changes, "空のファイル名パターンを既定値へ補正", "Repaired an empty file pattern with the default pattern")

    start = int(_attr_value(settings, "custom_frame_start", 1))
    end = int(_attr_value(settings, "custom_frame_end", 1))
    if start > end:
        _set_attr(settings, "custom_frame_start", end, changes, "カスタム開始フレームを補正", "Normalized custom start frame")
        _set_attr(settings, "custom_frame_end", start, changes, "カスタム終了フレームを補正", "Normalized custom end frame")

    if verification_scope_requires_passes(str(getattr(settings, "verification_scope", "PRIMARY_AND_PASSES")) or "PRIMARY_AND_PASSES") and str(getattr(settings, "queue_compositing_mode", "AUTO") or "AUTO").upper() == "DIRECT":
        _set_attr(settings, "queue_compositing_mode", "AUTO", changes, 'AOV 検証のためキュー出力を自動へ補正', "Adjusted queue compositing mode to AUTO for AOV verification")

    if str(getattr(settings, "pass_bundle", "NONE") or "NONE") in _HEAVY_PASS_BUNDLES and str(getattr(settings, "image_format", "PNG") or "PNG") not in _IMAGE_FORMATS_BEST_FOR_PASSES:
        _set_attr(settings, "image_format", "OPEN_EXR", changes, "高度なパス用途に合わせて画像形式を OpenEXR に補正", "Adjusted the image format to OpenEXR for heavy pass workflows")

    if bool(getattr(settings, "use_stamp", False)) and not str(getattr(settings, "stamp_note", "") or "").strip():
        _set_attr(settings, "stamp_note", "Smart Render", changes, "空のスタンプメモを補正", "Repaired an empty stamp note")

    for index, variant in enumerate(getattr(scene, "srr_variants", []) or [], start=1):
        variant_label = str(getattr(variant, "name", "") or f"Variant {index:02d}").strip() or f"Variant {index:02d}"

        if str(getattr(variant, "parent_variant_name", "") or "").strip() == str(getattr(variant, "name", "") or "").strip() and str(getattr(variant, "parent_variant_name", "") or "").strip():
            _set_attr(variant, "parent_variant_name", "", changes, f"Variant '{variant_label}' の自己親参照を解除", f"Cleared the self-parent reference on variant '{variant_label}'")

        if bool(getattr(variant, "use_custom_frames", False)):
            v_start = int(_attr_value(variant, "frame_start", 1))
            v_end = int(_attr_value(variant, "frame_end", 1))
            if v_start > v_end:
                _set_attr(variant, "frame_start", v_end, changes, f"Variant '{variant_label}' の開始フレームを補正", f"Normalized the start frame for variant '{variant_label}'")
                _set_attr(variant, "frame_end", v_start, changes, f"Variant '{variant_label}' の終了フレームを補正", f"Normalized the end frame for variant '{variant_label}'")

        for attr_name, label_ja, label_en in [
            ("include_collections", 'コレクション含めるを整理', "Normalized collection include selectors"),
            ("exclude_collections", 'コレクション除外を整理', "Normalized collection exclude selectors"),
            ("holdout_collections", 'コレクションホールドアウトを整理', "Normalized collection holdout selectors"),
            ("indirect_only_collections", 'コレクション間接を整理', "Normalized collection indirect-only selectors"),
            ("show_objects", 'オブジェクト表示を整理', "Normalized object show selectors"),
            ("hide_objects", 'オブジェクト非表示を整理', "Normalized object hide selectors"),
        ]:
            normalized = _normalize_name_list_text(getattr(variant, attr_name, "") or "")
            _set_attr(variant, attr_name, normalized, changes, f"Variant '{variant_label}' の {label_ja}", f"{label_en} on variant '{variant_label}'")

        normalized_dir_override = _trim_slashes(getattr(variant, "output_dir_pattern_override", "") or "")
        if normalized_dir_override:
            _set_attr(variant, "output_dir_pattern_override", normalized_dir_override, changes, f"Variant '{variant_label}' のフォルダーパターンを整理", f"Normalized the directory override on variant '{variant_label}'")

        normalized_file_override = _strip_trailing_extension(getattr(variant, "output_file_pattern_override", "") or "")
        if normalized_file_override:
            _set_attr(variant, "output_file_pattern_override", normalized_file_override, changes, f"Variant '{variant_label}' のファイル名パターンを整理", f"Removed explicit extension from the file pattern override on variant '{variant_label}'")

        if str(getattr(variant, "material_override_mode", "SCENE") or "SCENE") == "OVERRIDE" and not str(getattr(variant, "material_override_name", "") or "").strip():
            _set_attr(variant, "material_override_mode", "CLEAR", changes, f"Variant '{variant_label}' の空マテリアル上書きを解除へ補正", f"Turned the empty material override on variant '{variant_label}' into CLEAR")

        if str(getattr(variant, "world_override_mode", "SCENE") or "SCENE") == "OVERRIDE" and not str(getattr(variant, "world_override_name", "") or "").strip():
            _set_attr(variant, "world_override_mode", "CLEAR", changes, f"Variant '{variant_label}' の空ワールド上書きを解除へ補正", f"Turned the empty world override on variant '{variant_label}' into CLEAR")

        if str(getattr(variant, "collection_override_mode", "SCENE") or "SCENE") != "SCENE" and not any(str(getattr(variant, attr_name, "") or "").strip() for attr_name in ("include_collections", "exclude_collections", "holdout_collections", "indirect_only_collections")):
            _set_attr(variant, "collection_override_mode", "SCENE", changes, f"Variant '{variant_label}' の空コレクション上書きを継承へ補正", f"Turned the empty collection override on variant '{variant_label}' back to Inherit")

        if str(getattr(variant, "object_visibility_override_mode", "SCENE") or "SCENE") != "SCENE" and not any(str(getattr(variant, attr_name, "") or "").strip() for attr_name in ("show_objects", "hide_objects")):
            _set_attr(variant, "object_visibility_override_mode", "SCENE", changes, f"Variant '{variant_label}' の空オブジェクト可視上書きを継承へ補正", f"Turned the empty object-visibility override on variant '{variant_label}' back to Inherit")

        if str(getattr(variant, "color_management_mode", "SCENE") or "SCENE") == "OVERRIDE":
            has_real_override = any([
                str(getattr(variant, "view_transform_override", "") or "").strip(),
                str(getattr(variant, "look_override", "") or "").strip(),
                bool(getattr(variant, "use_exposure_override", False)),
                bool(getattr(variant, "use_gamma_override", False)),
            ])
            if not has_real_override:
                _set_attr(variant, "color_management_mode", "SCENE", changes, f"Variant '{variant_label}' の空カラーマネジメント上書きを継承へ補正", f"Turned the empty color-management override on variant '{variant_label}' back to Inherit")

    for item in getattr(scene, "srr_queue", []) or []:
        source_mode = str(getattr(item, "source_mode", "PAIR") or "PAIR")
        label = str(getattr(item, "label", "") or "").strip()
        if label:
            continue
        if source_mode == "VARIANT":
            variant_label = str(getattr(item, "variant_name", "") or "").strip() or "Variant"
            _set_attr(item, "label", variant_label, changes, '空のバリアントキューラベルを補正', "Filled an empty variant-queue label")
        else:
            _set_attr(item, "label", _pair_label(getattr(item, "camera_name", ""), getattr(item, "view_layer_name", "")), changes, '空の組み合わせキューラベルを補正', "Filled an empty pair-queue label")

    return changes
