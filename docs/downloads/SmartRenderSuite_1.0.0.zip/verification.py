from __future__ import annotations

import os
import time
from typing import Callable, Dict, List

from .compat import (
    compositor_node_tree,
    file_output_item_candidate_paths,
    image_format_extension,
    safe_name,
)

PRIMARY_SCOPES = {"PRIMARY_ONLY", "PRIMARY", "PRIMARY_AND_PASSES"}
PASS_SCOPES = {"PASSES_ONLY", "PASSES", "PRIMARY_AND_PASSES"}
MULTILAYER_FORMAT = "OPEN_EXR_MULTILAYER"



def _pass_output_folder_name(scene) -> str:
    settings = getattr(scene, "srr_settings", None)
    return "render_elements" if bool(settings is not None and getattr(settings, "render_elements_enabled", False)) else "passes"



def normalized_verification_scope(scope: str) -> str:
    token = str(scope or "PRIMARY_AND_PASSES").strip().upper()
    if token == "PRIMARY":
        return "PRIMARY_ONLY"
    if token == "PASSES":
        return "PASSES_ONLY"
    if token in {"PRIMARY_ONLY", "PRIMARY_AND_PASSES", "PASSES_ONLY"}:
        return token
    return "PRIMARY_AND_PASSES"



def verification_scope_requires_primary(scope: str) -> bool:
    return normalized_verification_scope(scope) in PRIMARY_SCOPES



def verification_scope_requires_passes(scope: str) -> bool:
    return normalized_verification_scope(scope) in PASS_SCOPES



def effective_verification_scope(scope: str, compositing_mode: str) -> str:
    normalized = normalized_verification_scope(scope)
    if not verification_scope_requires_passes(normalized):
        return "PRIMARY_ONLY"
    return normalized if str(compositing_mode or "DIRECT").upper() == "COMPOSITOR" else "PRIMARY_ONLY"



def _file_output_items(file_node):
    for attr_name in ("file_output_items", "file_slots", "layer_slots"):
        collection = getattr(file_node, attr_name, None)
        if collection is not None:
            return collection
    return []


def _frame_token(frame_value: int, padding: int) -> str:
    width = max(1, int(padding or 1))
    return str(int(frame_value)).zfill(width)



def _file_output_format(file_node, fallback: str = "PNG") -> str:
    return str(getattr(getattr(file_node, "format", None), "file_format", "") or fallback or "PNG")



def _file_output_is_multilayer(file_node, fallback: str = "PNG") -> bool:
    return _file_output_format(file_node, fallback) == MULTILAYER_FORMAT



def _slot_name(slot, fallback: str) -> str:
    return safe_name(str(getattr(slot, "name", "") or fallback or "pass")) or "pass"



def _node_basename(file_node, fallback: str = "passes") -> str:
    value = str(getattr(file_node, "file_name", "") or getattr(file_node, "filename", "") or fallback or "passes")
    value = value.replace("\\", "/").replace("#", "").strip()
    while value.startswith("/"):
        value = value[1:]
    while value.startswith("./"):
        value = value[2:]
    if not value or value in {".", ".."}:
        value = fallback or "passes"
    stem, _ext = os.path.splitext(value)
    if stem and _ext:
        value = stem
    value = os.path.normpath(value).replace("\\", "/")
    if value in {"", ".", ".."}:
        value = fallback or "passes"
    return value



def _normalized_subpath(value: str, fallback: str = "passes") -> str:
    text = str(value or "").replace("\\", "/").strip()
    while text.startswith("/"):
        text = text[1:]
    while text.startswith("./"):
        text = text[2:]
    if not text or text in {".", ".."}:
        text = fallback or "passes"
    stem, _ext = os.path.splitext(text)
    if stem and _ext:
        text = stem
    text = os.path.normpath(text).replace("\\", "/")
    if text in {"", ".", ".."}:
        text = fallback or "passes"
    return text



def _multilayer_candidate_paths(base_dir: str, file_node, frame_value: int, padding: int, extension: str, *, fallback: str = "passes") -> List[str]:
    directory = os.path.normpath(str(base_dir or ""))
    ext = str(extension or "").strip().lower().lstrip(".")
    frame_token = _frame_token(frame_value, padding)
    base_subpath = _node_basename(file_node, fallback=fallback)

    paths: List[str] = []
    seen = set()

    def add(subpath: str) -> None:
        subpath_text = _normalized_subpath(subpath, fallback=fallback)
        stem = os.path.normpath(os.path.join(directory, subpath_text))
        path_value = f"{stem}.{ext}" if ext else stem
        if path_value not in seen:
            seen.add(path_value)
            paths.append(path_value)

    add(f"{base_subpath}{frame_token}")
    add(base_subpath)

    head, tail = os.path.split(base_subpath)
    tail = tail or fallback or "passes"
    add(os.path.join(head, f"{tail}_{frame_token}"))
    add(os.path.join(head, f"{tail}{frame_token}"))
    return paths



def expected_srs_pass_requirements(
    scene,
    base_output_dir: str,
    variant_name: str,
    layer_name: str,
    frame_value: int,
    image_format: str,
    padding: int,
) -> List[Dict[str, object]]:
    tree = compositor_node_tree(scene)
    if tree is None:
        return []
    passes_root = os.path.join(str(base_output_dir or ""), _pass_output_folder_name(scene), safe_name(variant_name or "base"))
    requirements: List[Dict[str, object]] = []
    seen = set()

    for node in getattr(tree, "nodes", []) or []:
        node_name = str(getattr(node, "name", "") or "")
        if not node_name.startswith("SRR_FileOutput::"):
            continue
        node_layer = node_name.split("::", 1)[1] if "::" in node_name else node_name
        if layer_name and node_layer != layer_name:
            continue
        node_dir = os.path.normpath(os.path.join(passes_root, safe_name(node_layer)))
        node_format = _file_output_format(node, str(image_format or "PNG"))
        ext = image_format_extension(str(node_format or image_format or "PNG"))

        if _file_output_is_multilayer(node, str(image_format or "PNG")):
            fallback = f"{safe_name(node_layer)}_"
            candidates = [
                os.path.normpath(path)
                for path in _multilayer_candidate_paths(
                    node_dir,
                    node,
                    int(frame_value),
                    int(padding or 1),
                    ext,
                    fallback=fallback,
                )
            ]
            candidates = [path for path in candidates if path]
            if candidates:
                expected_path = candidates[0]
                signature = (node_layer, "multilayer", expected_path)
                if signature not in seen:
                    seen.add(signature)
                    requirements.append(
                        {
                            "kind": "pass",
                            "layer_name": str(node_layer),
                            "node_name": node_name,
                            "item_name": "multilayer",
                            "expected_path": expected_path,
                            "candidate_paths": candidates,
                            "label": f"{node_layer}:multilayer",
                        }
                    )
            continue

        for index, item in enumerate(_file_output_items(node)):
            fallback = _slot_name(item, fallback=f"pass_{index + 1}")
            candidates = [
                os.path.normpath(path)
                for path in file_output_item_candidate_paths(
                    node_dir,
                    item,
                    int(frame_value),
                    int(padding or 1),
                    ext,
                    explicit_frame=True,
                    fallback=fallback,
                )
            ]
            candidates = [path for path in candidates if path]
            if not candidates:
                continue
            expected_path = candidates[0]
            signature = (node_layer, fallback, expected_path)
            if signature in seen:
                continue
            seen.add(signature)
            requirements.append(
                {
                    "kind": "pass",
                    "layer_name": str(node_layer),
                    "node_name": node_name,
                    "item_name": fallback,
                    "expected_path": expected_path,
                    "candidate_paths": candidates,
                    "label": f"{node_layer}:{fallback}",
                }
            )
    return requirements



def expected_srs_pass_outputs(
    scene,
    base_output_dir: str,
    variant_name: str,
    layer_name: str,
    frame_value: int,
    image_format: str,
    padding: int,
) -> List[str]:
    return [
        requirement["expected_path"]
        for requirement in expected_srs_pass_requirements(
            scene,
            base_output_dir,
            variant_name,
            layer_name,
            frame_value,
            image_format,
            padding,
        )
    ]



def build_output_verification_plan(
    scene,
    primary_path: str,
    base_output_dir: str,
    variant_name: str,
    layer_name: str,
    frame_value: int,
    image_format: str,
    padding: int,
    scope: str,
) -> Dict[str, object]:
    normalized_scope = normalized_verification_scope(scope)
    requirements: List[Dict[str, object]] = []
    if verification_scope_requires_primary(normalized_scope) and str(primary_path or "").strip():
        primary_norm = os.path.normpath(str(primary_path))
        requirements.append(
            {
                "kind": "primary",
                "label": "primary",
                "expected_path": primary_norm,
                "candidate_paths": [primary_norm],
            }
        )
    if verification_scope_requires_passes(normalized_scope):
        requirements.extend(
            expected_srs_pass_requirements(
                scene,
                str(base_output_dir or ""),
                str(variant_name or "base"),
                str(layer_name or ""),
                int(frame_value),
                str(image_format or "PNG"),
                int(padding or 1),
            )
        )

    primary_paths = [requirement["expected_path"] for requirement in requirements if requirement.get("kind") == "primary"]
    pass_paths = [requirement["expected_path"] for requirement in requirements if requirement.get("kind") == "pass"]
    paths = []
    seen = set()
    for requirement in requirements:
        expected = os.path.normpath(str(requirement.get("expected_path", "") or ""))
        if expected and expected not in seen:
            seen.add(expected)
            paths.append(expected)

    return {
        "scope": normalized_scope,
        "frame": int(frame_value),
        "primary_paths": primary_paths,
        "pass_paths": pass_paths,
        "paths": paths,
        "requirements": requirements,
        "expected_output_count": len(requirements),
    }



def _requirement_match(requirement: Dict[str, object], minimum: int = 0):
    candidates = [os.path.normpath(str(path)) for path in (requirement.get("candidate_paths", []) or []) if str(path)]
    seen = set()
    for path in candidates:
        if path in seen:
            continue
        seen.add(path)
        if not os.path.exists(path):
            continue
        try:
            size = int(os.path.getsize(path))
        except Exception:
            size = 0
        if minimum > 0 and size < minimum:
            return {
                "ok": False,
                "path": path,
                "size": size,
                "reason": "too_small",
            }
        return {
            "ok": True,
            "path": path,
            "size": size,
            "reason": "existing",
        }
    return {
        "ok": False,
        "path": os.path.normpath(str(requirement.get("expected_path", "") or "")),
        "size": 0,
        "reason": "missing",
    }



def plan_has_existing_outputs(plan: Dict[str, object], min_size_bytes: int = 0) -> bool:
    requirements = list(plan.get("requirements", []) or [])
    if not requirements:
        return False
    minimum = max(0, int(min_size_bytes or 0))
    return all(_requirement_match(requirement, minimum).get("ok", False) for requirement in requirements)



def plan_has_any_existing_outputs(plan: Dict[str, object], min_size_bytes: int = 0) -> bool:
    requirements = list(plan.get("requirements", []) or [])
    if not requirements:
        return False
    minimum = max(0, int(min_size_bytes or 0))
    return any(_requirement_match(requirement, minimum).get("ok", False) for requirement in requirements)



def verify_output_plan(plan: Dict[str, object], min_size_bytes: int = 0) -> Dict[str, object]:
    requirements = list(plan.get("requirements", []) or [])
    minimum = max(0, int(min_size_bytes or 0))
    existing: List[str] = []
    missing: List[str] = []
    too_small: List[str] = []
    file_sizes: Dict[str, int] = {}
    matched_paths: Dict[str, str] = {}
    requirement_results: List[Dict[str, object]] = []

    for requirement in requirements:
        match = _requirement_match(requirement, minimum)
        requirement_copy = dict(requirement)
        requirement_copy.update(
            {
                "ok": bool(match.get("ok", False)),
                "matched_path": match.get("path", ""),
                "reason": match.get("reason", "missing"),
                "size": int(match.get("size", 0) or 0),
            }
        )
        requirement_results.append(requirement_copy)
        matched_path = os.path.normpath(str(match.get("path", "") or "")) if match.get("path") else ""
        if matched_path:
            matched_paths[str(requirement.get("expected_path", ""))] = matched_path
        if match.get("ok", False):
            if matched_path:
                existing.append(matched_path)
                file_sizes[matched_path] = int(match.get("size", 0) or 0)
            continue
        if match.get("reason") == "too_small":
            if matched_path:
                too_small.append(matched_path)
                file_sizes[matched_path] = int(match.get("size", 0) or 0)
        else:
            missing.append(os.path.normpath(str(requirement.get("expected_path", "") or "")))

    paths = [os.path.normpath(str(path)) for path in (plan.get("paths", []) or []) if str(path)]
    noop = not bool(requirements)
    ok = not missing and not too_small
    return {
        "ok": ok,
        "noop": noop,
        "scope": normalized_verification_scope(str(plan.get("scope", "PRIMARY_AND_PASSES"))),
        "expected_output_count": len(requirements),
        "primary_paths": list(plan.get("primary_paths", []) or []),
        "pass_paths": list(plan.get("pass_paths", []) or []),
        "paths": paths,
        "requirements": requirement_results,
        "existing": existing,
        "missing": missing,
        "too_small": too_small,
        "matched_paths": matched_paths,
        "file_sizes": file_sizes,
        "min_size_bytes": minimum,
    }



def remove_invalid_outputs(verification_result: Dict[str, object]) -> int:
    removed = 0
    for path in verification_result.get("too_small", []) or []:
        try:
            if os.path.exists(path):
                os.remove(path)
                removed += 1
        except Exception:
            continue
    return removed



def verify_output_plan_with_retries(
    plan: Dict[str, object],
    min_size_bytes: int = 0,
    *,
    retries: int = 0,
    delay_seconds: float = 0.0,
    on_retry: Callable[[int, int, Dict[str, object]], None] | None = None,
) -> Dict[str, object]:
    extra_retries = max(0, int(retries or 0))
    total_attempts = 1 + extra_retries
    delay = max(0.0, float(delay_seconds or 0.0))
    last_result: Dict[str, object] | None = None

    for attempt_index in range(total_attempts):
        result = verify_output_plan(plan, min_size_bytes)
        result["attempt"] = attempt_index + 1
        result["attempt_count"] = total_attempts
        result["retry_count"] = extra_retries
        result["retry_delay_seconds"] = delay
        if result.get("ok", False) or result.get("noop", False):
            return result
        last_result = result
        if attempt_index >= total_attempts - 1:
            break
        if on_retry is not None:
            try:
                on_retry(attempt_index + 1, total_attempts, result)
            except Exception:
                pass
        if delay > 0.0:
            time.sleep(delay)

    if last_result is None:
        last_result = verify_output_plan(plan, min_size_bytes)
    last_result.setdefault("attempt", total_attempts)
    last_result.setdefault("attempt_count", total_attempts)
    last_result.setdefault("retry_count", extra_retries)
    last_result.setdefault("retry_delay_seconds", delay)
    return last_result
