# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible helpers for integrated add-ons.

from __future__ import annotations

import os
from types import SimpleNamespace

import bpy


_BUNDLED_TOOL_IDS = {
    'bridges',
    'camera_plane',
    'camera_rigs',
    'dynamic_sky',
    'frame_range_renderer',
    'freestyle_svg_exporter',
    'hdr_rotation',
    'k_tools_render_preset_manager',
    'overscan',
    'profiler',
    'pseudo_rendering_farm',
    'rendernames',
    'render_pipeline',
    'sun_position',
    'tri_lighting',
    'use_for_rendering_plus',
}


def root_module_name(package_name: str = "") -> str:
    package = str(package_name or "").strip()
    if not package:
        return "bl_ext.user_default.smart_render_suite"
    marker = ".integrated_addons"
    if marker in package:
        package = package.split(marker, 1)[0].rstrip('.')
    parts = [part for part in package.split('.') if part]
    if len(parts) >= 3 and parts[0] == 'bl_ext':
        return '.'.join(parts[:3])
    if parts:
        return parts[0]
    return "smart_render_suite"


def root_package_id(package_name: str = "") -> str:
    root = root_module_name(package_name)
    tail = root.rsplit('.', 1)[-1].strip()
    if tail in {'Smart_Render_Suite', 'smart_render_suite'} or tail in _BUNDLED_TOOL_IDS or 'smart_render_suite' in root or root.startswith('bl_ext.user_default'):
        return 'smart_render_suite'
    if '.' in str(package_name or ''):
        return 'smart_render_suite'
    return tail or 'smart_render_suite'


def _blender_version_dir() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None)
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def _addon_collection(context=None):
    context = context or getattr(bpy, 'context', None)
    prefs = getattr(context, 'preferences', None)
    return getattr(prefs, 'addons', None)


def get_addon_entry(package_name: str = "", context=None):
    addons = _addon_collection(context)
    if addons is None:
        return None
    candidates = []
    for candidate in (
        str(package_name or '').strip(),
        root_module_name(package_name),
        root_package_id(package_name),
    ):
        if candidate and candidate not in candidates:
            candidates.append(candidate)
    for candidate in candidates:
        try:
            return addons[candidate]
        except Exception:
            continue
    return None


def get_root_addon_preferences(package_name: str = "", context=None):
    entry = get_addon_entry(package_name, context=context)
    return getattr(entry, 'preferences', None) if entry is not None else None


def namespace_defaults(**kwargs):
    return SimpleNamespace(**kwargs)


def extension_user_path(package_name: str = "", *, path: str = "", create: bool = False) -> str:
    subpath = str(path or '').strip().replace('\\', os.sep).replace('/', os.sep)
    try:
        from .compat import extension_user_root
        base_dir = extension_user_root(create=create)
    except Exception:
        version_dir = _blender_version_dir()
        if os.name == 'nt':
            appdata = os.environ.get('APPDATA') or os.path.expanduser('~')
            base_dir = os.path.join(appdata, 'Blender Foundation', 'Blender', version_dir, 'config', 'Smart_Render_Suite')
        else:
            base_dir = os.path.join(os.path.expanduser('~'), '.config', 'blender', version_dir, 'config', 'Smart_Render_Suite')
        if create:
            os.makedirs(base_dir, exist_ok=True)
    result = os.path.normpath(os.path.join(base_dir, subpath)) if subpath else os.path.normpath(base_dir)
    if create:
        os.makedirs(result, exist_ok=True)
    return result
