# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import copy
import json
import os
import traceback

import bpy
from bpy.props import BoolProperty, EnumProperty, StringProperty
from bpy.types import Operator

from .bridges import build_bridge_export
from .compat import (
    set_image_file_format,
    abspath,
    apply_layer_collection_overrides,
    collection_clear,
    compositor_node_tree,
    effective_queue_compositing_mode,
    ensure_directory,
    engine_mode_from_identifier,
    layer_collection_map,
    log,
    material_by_name,
    now_local,
    parse_name_list,
    resolve_manifest_path,
    safe_name,
    safe_set_attr,
    scene_object,
    set_scene_camera,
    unique_output_stem,
    view_layer,
    world_by_name,
)
from .nodes import (
    build_compositor_outputs,
    cleanup_srs_compositor_nodes,
    configure_srs_file_output_nodes,
    refresh_file_output_node_for_layer,
    has_file_output_nodes,
    queue_target_layers,
)
from .script_export import export_headless_scripts
from .postprocess import build_movie_job
from .variant_graph import effective_variant
from .recipes import WORKFLOW_RECIPES, apply_workflow_recipe, auto_repair_scene, workflow_recipe_items, workflow_recipe_meta
from .verification import build_output_verification_plan, effective_verification_scope, plan_has_any_existing_outputs, plan_has_existing_outputs, remove_invalid_outputs, verify_output_plan_with_retries
from .elements_catalog import RENDER_ELEMENT_CATALOG
from .translation import PROPERTY_CONTEXT, action_tooltip, both_languages, error_log_text, error_text, expand_inline_bilingual_tooltip, iface_text, localize_class_attributes, localize_inline, localize_pair, render_summary_lines, source_text, status_log_text, status_value_pair, status_value_text, t
from .planner import (
    PASS_PROPERTY_NAMES,
    analysis_result,
    apply_manifest,
    apply_pass_bundle,
    apply_profile,
    apply_render_elements_preset,
    apply_variant_scene_overrides,
    available_view_layers,
    build_pair_queue_blueprint,
    build_variant_queue_blueprint,
    collect_output_targets,
    detect_output_collisions,
    effective_queue_blueprint,
    ensure_render_element_item_defaults,
    manifest,
    pass_output_folder_name,
    queue_counts,
    render_elements_effective_bundle,
    render_elements_enabled,
    render_elements_image_format,
    render_elements_preview_names,
    render_element_item_ids_for_preset,
    resolve_item_context,
    resolve_output,
    restore_render_state,
    set_render_element_item_ids,
    snapshot_render_state,
    sync_queue,
    variant_lookup,
)


_PREVIEW_CAPTURE_OPERATOR_IDS = {
    "srr.apply_aov_quick_set",
    "srr.apply_render_profile",
    "srr.prepare_scene_setup",
    "srr.apply_pass_bundle",
    "srr.apply_workflow_recipe",
    "srr.auto_repair_scene",
    "srr.analyze_scene",
    "srr.sync_render_queue",
    "srr.clear_render_queue",
    "srr.add_queue_item",
    "srr.duplicate_queue_item",
    "srr.remove_queue_item",
    "srr.move_queue_item",
    "srr.preview_output_paths",
    "srr.prepare_render_elements",
    "srr.prepare_network_render",
    "srr.import_manifest",
    "srr.add_variant_from_current_state",
    "srr.add_child_variant",
    "srr.duplicate_variant",
    "srr.remove_variant",
    "srr.capture_overrides",
    "srr.apply_variant",
    "srr.build_file_output_nodes",
    "srr.run_render_queue",
}


def _operator_python_id(operator) -> str:
    """Python form of an operator id; a running operator reports SRR_OT_name, not srr.name."""
    operator_id = str(getattr(operator, "bl_idname", "") or "")
    prefix, separator, name = operator_id.partition("_OT_")
    return f"{prefix.lower()}.{name}" if separator else operator_id


def _capture_preview_snapshot(context, operator_id: str) -> None:
    try:
        from . import preview_cache
        preview_cache.capture_scene_snapshot(context, reason=str(operator_id or "operator"), include_output_paths=True)
    except Exception:
        # Derived panel previews must never change the operator's result.
        pass


def _element_preview_log_text(names, limit: int) -> tuple[str, str]:
    """Render element names for a log line, as the panel's check boxes show them (ja, en)."""
    from .planner import RENDER_ELEMENT_CATALOG, _render_element_item_display_name
    labels = {_render_element_item_display_name(item): item for item in RENDER_ELEMENT_CATALOG}
    shown = list(names)[:limit]
    rest = len(names) - len(shown)
    ja = "、".join(str(labels.get(name, {}).get("label_ja") or name) for name in shown)
    en = ", ".join(str(labels.get(name, {}).get("label_en") or name) for name in shown)
    if rest > 0:
        ja += f" ほか {rest} 件"
        en += f", +{rest} more"
    return ja, en


class SRSOperatorMixin:
    def guarded(self, context, label, callback):
        scene = getattr(context, "scene", None)
        try:
            result = callback()
            # Structural N-panel edits (queue/variant add, remove, duplicate,
            # move) do not emit a dependable CollectionProperty msgbus event.
            # Persist their final state synchronously through the same canonical
            # payload used by scalar controls.
            try:
                if isinstance(result, set) and 'FINISHED' in result:
                    from . import settings as _smart_render_settings
                    _smart_render_settings.snapshot_context(
                        context,
                        force=_smart_render_settings.is_npanel_state_save_enabled(context),
                    )
                    operator_id = _operator_python_id(self)
                    if operator_id in _PREVIEW_CAPTURE_OPERATOR_IDS:
                        _capture_preview_snapshot(context, operator_id)
            except Exception:
                pass
            return result
        except Exception as ex:
            try:
                if scene is not None:
                    log(scene, "ERROR", error_log_text(label, ex))
            except Exception:
                pass
            traceback.print_exc()
            self.report({'ERROR'}, error_text(label, ex))
            return {'CANCELLED'}



def _unique_variant_name(scene, base: str = "Variant") -> str:
    existing = {item.name for item in getattr(scene, "srr_variants", [])}
    index = 1
    while True:
        name = f"{base} {index:02d}"
        if name not in existing:
            return name
        index += 1


def _unique_queue_label(scene, base: str = "Queue Item", *, ignore_index: int = -1) -> str:
    """Return a stable, human-readable label unique within the queue."""
    base = str(base or "Queue Item").strip() or "Queue Item"
    existing = {
        str(getattr(item, "label", "") or "")
        for index, item in enumerate(getattr(scene, "srr_queue", []))
        if index != int(ignore_index)
    }
    if base not in existing:
        return base
    index = 2
    while True:
        candidate = f"{base} {index:02d}"
        if candidate not in existing:
            return candidate
        index += 1



def _selected_variant(scene):
    if len(getattr(scene, "srr_variants", [])) == 0:
        return None
    index = max(0, min(int(getattr(scene, "srr_variant_index", 0)), len(scene.srr_variants) - 1))
    scene.srr_variant_index = index
    return scene.srr_variants[index]


class SRR_OT_toggle_properties_tab(SRSOperatorMixin, Operator):
    bl_options = set()
    _sms_no_undo = True
    bl_idname = "srr.refresh_n_panel"
    bl_label = "Refresh N-panel"
    bl_description = action_tooltip(
        "3Dビュー右側の通常Nパネルにある Smart Render カテゴリを再描画します。",
        "Redraw the Smart Render category in the regular N-panel on the right side of the 3D Viewport.",
    )

    activate: BoolProperty(default=True, options={'HIDDEN'})

    def execute(self, context):
        def run():
            try:
                for area in getattr(getattr(context, "screen", None), "areas", ()):
                    if str(getattr(area, "type", "") or "") in {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}:
                        area.tag_redraw()
            except Exception:
                pass
            self.report({'INFO'}, iface_text("Smart Render N-panel refreshed"))
            return {'FINISHED'}

        return self.guarded(context, "Refresh Smart Render N-panel", run)




class SRR_OT_toggle_npanel_section(SRSOperatorMixin, Operator):
    bl_idname = "srr.toggle_npanel_section"
    bl_label = "Toggle N-panel Section"
    bl_description = action_tooltip(
        "Smart Render のNパネル内セクションを開閉します。",
        "Open or close a Smart Render N-panel section.",
        usage_ja="各セクション左端の三角ボタン、またはセクション名をクリックすると、その項目の詳細設定を開閉できます。",
        usage_en="Click the triangle button or the section title to open or close that section's detailed controls.",
        tip_ja='Nパネル状態保存が有効な場合、開閉状態は Blender の設定フォルダー内 Smart_Render_Suite/Smart_Render_Suite.json に保存され、シーン切り替え後や次回起動時にも復元されます。',
        tip_en="When N-panel State Save is enabled, the foldout state is saved to Smart_Render_Suite/Smart_Render_Suite.json in Blender's config directory and restored after scene changes or the next startup.",
    )
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    prop_name: StringProperty(
        name="Section Property",
        description="Internal Smart Render BoolProperty name that stores the open/closed state for this N-panel section.",
        default="",
        options={'SKIP_SAVE'},
    )

    def execute(self, context):
        def run():
            scene = getattr(context, "scene", None)
            settings = getattr(scene, "srr_settings", None) if scene is not None else None
            prop_name = str(getattr(self, "prop_name", "") or "").strip()
            if settings is None or not prop_name:
                self.report({'WARNING'}, t(settings, "セクション状態を変更できません。", "Section state could not be changed."))
                return {'CANCELLED'}
            try:
                if hasattr(settings, prop_name):
                    setattr(settings, prop_name, not bool(getattr(settings, prop_name)))
                elif prop_name.startswith('integrated_tool:') and hasattr(settings, 'integrated_tool_section_state_json'):
                    key = prop_name.split(':', 1)[1].strip()
                    if not key:
                        self.report({'WARNING'}, t(settings, "セクション状態を変更できません。", "Section state could not be changed."))
                        return {'CANCELLED'}
                    try:
                        raw = json.loads(str(getattr(settings, 'integrated_tool_section_state_json', '{}') or '{}'))
                        if not isinstance(raw, dict):
                            raw = {}
                    except Exception:
                        raw = {}
                    raw[key] = not bool(raw.get(key, False))
                    setattr(settings, 'integrated_tool_section_state_json', json.dumps(raw, ensure_ascii=False, sort_keys=True))
                else:
                    self.report({'WARNING'}, t(settings, "セクション状態を変更できません。", "Section state could not be changed."))
                    return {'CANCELLED'}
                try:
                    from . import settings as _smart_render_settings
                    _smart_render_settings.snapshot_context(context, force=_smart_render_settings.is_npanel_state_save_enabled(context))
                except Exception:
                    pass
            except Exception as exc:
                self.report({'WARNING'}, t(settings, "セクション状態を変更できません。", f"Section state could not be changed: {exc}"))
                return {'CANCELLED'}
            try:
                screen = getattr(context, "screen", None)
                for area in getattr(screen, "areas", ()) or ():
                    if str(getattr(area, "type", "") or "") in {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}:
                        area.tag_redraw()
            except Exception:
                pass
            return {'FINISHED'}

        return self.guarded(context, "Toggle Smart Render N-panel section", run)

class SRR_OT_apply_render_elements_quick_set(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.apply_aov_quick_set"
    bl_label = "Apply AOV Quick Set"
    bl_description = action_tooltip(
        "クイックセットや一括操作を、個別 Render Elements リストへ反映します。",
        "Apply a quick set or bulk action to the individual render-elements list.",
    )

    action: EnumProperty(
        items=(
            ("LOAD_PRESET", "Load Quick Set", "Apply the current quick set to the individual element list."),
            ("SELECT_ALL", "Select All", "Enable all render elements."),
            ("CLEAR", "Clear", "Reduce the list back to Beauty only."),
        ),
        default="LOAD_PRESET",
        options={'HIDDEN'},
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            ensure_render_element_item_defaults(settings)

            if self.action == "SELECT_ALL":
                selected_ids = [str(item.get("id", "")) for item in RENDER_ELEMENT_CATALOG]
            elif self.action == "CLEAR":
                selected_ids = ["BEAUTY"]
            else:
                preset_token = str(getattr(settings, "render_elements_preset", "FROM_PASS_BUNDLE") or "FROM_PASS_BUNDLE")
                selected_ids = render_element_item_ids_for_preset(settings, preset=preset_token)
            applied_ids = set_render_element_item_ids(settings, selected_ids)
            preview_names = render_elements_preview_names(settings)
            if not preview_names:
                preview_names = ["Beauty"]
            preview_ja, preview_en = _element_preview_log_text(preview_names, 10)
            log(scene, "INFO", both_languages(
                f"レンダーエレメントの一覧を更新しました: {len(applied_ids)} 件（{preview_ja}）",
                f"Render Elements item list updated: {len(applied_ids)} item(s) ({preview_en})",
            ))
            self.report({'INFO'}, iface_text(f"Render Elements updated: {len(applied_ids)} item(s)"))
            return {'FINISHED'}

        return self.guarded(context, "Apply AOV Quick Set", run)


def _selected_queue(scene):
    if len(getattr(scene, "srr_queue", [])) == 0:
        return None, -1
    index = max(0, min(int(getattr(scene, "srr_queue_index", 0)), len(scene.srr_queue) - 1))
    scene.srr_queue_index = index
    return scene.srr_queue[index], index


def _copy_queue_item(source, target) -> None:
    for prop_name in ["enabled", "source_mode", "camera_name", "view_layer_name", "variant_name", "label"]:
        try:
            setattr(target, prop_name, copy.deepcopy(getattr(source, prop_name)))
        except Exception:
            pass



def _write_json(path: str, data: dict) -> None:
    directory = os.path.dirname(path)
    if directory:
        os.makedirs(directory, exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)



_QUALITY_LABELS = {"DRAFT": ("下書き", "Draft"), "PREVIEW": ("プレビュー", "Preview"), "FINAL": ("最終", "Final")}
_AUDIT_LABELS = {"INFO": ("問題なし", "no issues"), "WARNING": ("警告あり", "warnings"), "ERROR": ("エラーあり", "errors")}


def _labels(table: dict, value) -> tuple[str, str]:
    return table.get(str(value), (str(value), str(value)))


def _log_analysis(scene, analysis: dict, detail_limit: int = 12) -> None:
    audit = _labels(_AUDIT_LABELS, analysis['status'])
    log(scene, "INFO", both_languages(f"診断の結果：{audit[0]}", f"Audit status: {audit[1]}"))
    log(scene, "INFO", f"Risk score: {analysis['risk_score']} / リスクスコア: {analysis['risk_score']}")
    log(scene, "INFO", both_languages(
        f"カメラ {analysis['camera_count']}、ビューレイヤー {analysis['view_layer_count']}、バリアントとテイク {analysis['variant_count']}、キュー {analysis['queue_count']}",
        f"Cameras: {analysis['camera_count']} | View Layers: {analysis['view_layer_count']} | Variants: {analysis['variant_count']} | Queue: {analysis['queue_count']}",
    ))
    log(scene, "INFO", f"Planned renders: {analysis['planned_renders']} / 予定レンダー数: {analysis['planned_renders']}")
    shown = 0
    for issue in analysis.get("issues", []):
        log(scene, issue["level"], issue["message"])
        shown += 1
        if shown >= detail_limit:
            remaining = len(analysis.get("issues", [])) - shown
            if remaining > 0:
                log(scene, "WARNING", f"...and {remaining} more issue(s).")
            break
    if analysis.get("missing_assets"):
        severity = "ERROR" if scene.srr_settings.strict_missing_assets else "WARNING"
        for asset in analysis["missing_assets"][:detail_limit]:
            log(scene, severity, f"Missing {asset['kind']} [{asset['name']}]: {asset['path']}")
    if analysis.get("collisions"):
        severity = "ERROR" if scene.srr_settings.abort_on_collisions else "WARNING"
        for path, bucket in analysis["collisions"][:detail_limit]:
            parts = []
            for entry in bucket[:3]:
                kind = str(entry.get("output_kind", "primary") or "primary")
                if kind == "movie":
                    parts.append(
                        f"movie:{entry.get('label', 'job')}|{entry.get('frame_start', entry.get('frame', ''))}-{entry.get('frame_end', entry.get('frame', ''))}"
                    )
                else:
                    parts.append(
                        f"{kind}:{entry.get('camera_name', '')}|{entry.get('view_layer_name', '')}|{entry.get('frame', '')}"
                    )
            summary = ", ".join(parts)
            if len(bucket) > 3:
                summary += f", +{len(bucket) - 3} more"
            log(scene, severity, f"Collision [{len(bucket)}x]: {path} :: {summary}")



def _active_window_view_layer(context):
    try:
        return context.window.view_layer
    except Exception:
        return None



def _set_window_view_layer(context, layer_item) -> None:
    try:
        context.window.view_layer = layer_item
    except Exception:
        pass



def _choose_queue_compositing_mode(scene, settings) -> str:
    return effective_queue_compositing_mode(scene, str(getattr(settings, "queue_compositing_mode", "AUTO") or "AUTO"))



def _set_queue_compositing(scene, chosen_mode: str) -> None:
    render = getattr(scene, "render", None)
    if render is None:
        return
    if chosen_mode == "COMPOSITOR":
        safe_set_attr(scene, "use_nodes", True)
    safe_set_attr(render, "use_compositing", chosen_mode == "COMPOSITOR")



def _unique_pass_namespace_token(base_name: str, passes_root: str, reserved_paths) -> str:
    base_token = safe_name(base_name or "base") or "base"
    root = os.path.normpath(str(passes_root or ""))

    def candidate_path(token: str) -> str:
        return os.path.normpath(os.path.join(root, token))

    preferred_path = candidate_path(base_token)
    if preferred_path not in reserved_paths and not os.path.exists(preferred_path):
        reserved_paths.add(preferred_path)
        return base_token

    counter = 1
    while True:
        token = safe_name(f"{base_token}__{counter:03d}") or f"{base_token}__{counter:03d}"
        path_value = candidate_path(token)
        if path_value in reserved_paths or os.path.exists(path_value):
            counter += 1
            continue
        reserved_paths.add(path_value)
        return token






def _capture_variant_state(scene, context, settings, variant, capture_profile: bool = True) -> None:
    active_layer = getattr(context, "view_layer", None)
    variant.camera_name = getattr(scene.camera, "name", "")
    variant.view_layer_name = getattr(active_layer, "name", "")

    world_name = getattr(scene.world, "name", "")
    variant.world_override_name = world_name
    variant.world_override_mode = "OVERRIDE" if scene.world is not None else "CLEAR"

    material_name = getattr(getattr(active_layer, "material_override", None), "name", "") if active_layer is not None else ""
    variant.material_override_name = material_name
    variant.material_override_mode = "OVERRIDE" if material_name else "CLEAR"

    variant.freestyle_mode = "ON" if bool(getattr(scene.render, "use_freestyle", False)) else "OFF"
    variant.film_transparent_mode = "ON" if bool(getattr(scene.render, "film_transparent", False)) else "OFF"

    view_settings = getattr(scene, "view_settings", None)
    if view_settings is not None:
        variant.color_management_mode = "OVERRIDE"
        variant.view_transform_override = str(getattr(view_settings, "view_transform", "") or "")
        variant.look_override = str(getattr(view_settings, "look", "") or "")
        variant.use_exposure_override = True
        variant.exposure_override = float(getattr(view_settings, "exposure", 0.0) or 0.0)
        variant.use_gamma_override = True
        variant.gamma_override = float(getattr(view_settings, "gamma", 1.0) or 1.0)

    mapping = layer_collection_map(active_layer) if active_layer is not None else {}
    variant.collection_override_mode = "REPLACE"
    variant.include_collections = ", ".join(sorted(name for name, item in mapping.items() if not getattr(item, "exclude", False)))
    variant.exclude_collections = ", ".join(sorted(name for name, item in mapping.items() if getattr(item, "exclude", False)))
    variant.holdout_collections = ", ".join(sorted(name for name, item in mapping.items() if getattr(item, "holdout", False)))
    variant.indirect_only_collections = ", ".join(sorted(name for name, item in mapping.items() if getattr(item, "indirect_only", False)))

    hidden_objects = sorted(
        str(getattr(obj, "name", "") or "")
        for obj in getattr(scene, "objects", [])
        if str(getattr(obj, "name", "") or "").strip() and bool(getattr(obj, "hide_render", False))
    )
    if hidden_objects:
        variant.object_visibility_override_mode = "MERGE"
        variant.show_objects = ""
        variant.hide_objects = ", ".join(hidden_objects)
    else:
        variant.object_visibility_override_mode = "SCENE"
        variant.show_objects = ""
        variant.hide_objects = ""

    if capture_profile:
        variant.engine_mode = engine_mode_from_identifier(scene.render.engine)
        variant.quality_mode = settings.quality_mode
        variant.pass_bundle = settings.pass_bundle
        variant.image_format_override = scene.render.image_settings.file_format
        variant.resolution_percentage_override = int(scene.render.resolution_percentage)
        variant.sample_multiplier_override = float(settings.sample_multiplier)
        variant.denoise_mode = "ON" if settings.use_denoise else "OFF"
        variant.adaptive_sampling_mode = "ON" if settings.use_adaptive_sampling else "OFF"
        variant.motion_blur_mode = "ON" if settings.use_motion_blur else "OFF"





class SRR_OT_apply_profile(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.apply_render_profile"
    bl_label = "Apply Render Profile"
    bl_description = action_tooltip(
        "品質プリセット・エンジン・保存形式を現在シーンへ適用します。",
        "Apply the selected render profile to the current scene.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            apply_profile(scene, settings, target_layers=available_view_layers(context, settings), logger=lambda level, message: log(scene, level, message))
            log(scene, "INFO", f"Render Profile applied: {settings.quality_mode} / {scene.render.engine}")
            self.report({'INFO'}, iface_text("Smart Render profile applied."))
            return {'FINISHED'}
        return self.guarded(context, "Apply Render Profile", run)




class SRR_OT_prepare_setup(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.prepare_scene_setup"
    bl_label = "Prepare Scene Setup"
    bl_description = action_tooltip(
        'シーンを自動整理、基本レンダープロファイルを適用、レンダーキューを同期、必要時のファイル出力ノード更新、事前診断までをまとめて実行します。',
        "Run auto-repair, apply the core profile, sync the queue, optionally refresh File Output nodes, and finish with a preflight audit.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings

            collection_clear(scene.srr_logs)

            changes = auto_repair_scene(scene, settings)
            if changes:
                log(scene, "INFO", both_languages(f"自動整理：{len(changes)} 件を直しました。", f"Auto repair applied: {len(changes)} change(s)"))
                for message in changes[:8]:
                    log(scene, "INFO", message)
                if len(changes) > 8:
                    log(scene, "INFO", both_languages(f"ほかに {len(changes) - 8} 件を直しました。", f"...and {len(changes) - 8} more repair(s)."))
            else:
                log(scene, "INFO", both_languages("自動整理：直す設定はありませんでした。", "Auto repair found no safe changes to apply."))

            apply_profile(scene, settings, target_layers=available_view_layers(context, settings), logger=lambda level, message: log(scene, level, message))
            log(scene, "INFO", both_languages(f"基本プロファイルを適用しました：{_labels(_QUALITY_LABELS, settings.quality_mode)[0]}、{engine_mode_from_identifier(scene.render.engine)}", f"Core profile applied: {_labels(_QUALITY_LABELS, settings.quality_mode)[1]} / {engine_mode_from_identifier(scene.render.engine)}"))

            if settings.queue_source_mode == "VARIANTS":
                blueprint = build_variant_queue_blueprint(scene)
            else:
                blueprint = build_pair_queue_blueprint(context, scene, settings)
            sync_queue(scene, blueprint)
            log(scene, "INFO", both_languages(f"キューを同期しました：{len(scene.srr_queue)} 件", f"Queue synced: {len(scene.srr_queue)} job(s)"))

            chosen_compositing_mode = effective_queue_compositing_mode(scene, str(getattr(settings, "queue_compositing_mode", "AUTO") or "AUTO"))
            if chosen_compositing_mode == "COMPOSITOR":
                target_layers = queue_target_layers(context, scene, settings, enabled_only=False)
                created_nodes, linked_outputs, layer_count = build_compositor_outputs(context, target_layers=target_layers)
                log(scene, "INFO", both_languages(f"コンポジットの出力を準備しました：ビューレイヤー {layer_count}、接続 {linked_outputs}、ノード {created_nodes}", f"Compositor outputs prepared: {layer_count} layer(s), {linked_outputs} socket link(s), {created_nodes} node(s)."))

            analysis = analysis_result(context, scene, settings)
            _log_analysis(scene, analysis, detail_limit=int(settings.analysis_detail_limit))
            scene.srr_last_analysis_status = str(analysis["status"])
            scene.srr_last_analysis_time = now_local().strftime("%Y-%m-%d %H:%M:%S")
            scene.srr_last_collision_count = len(analysis["collisions"])
            scene.srr_last_missing_asset_count = len(analysis["missing_assets"])
            scene.srr_last_risk_score = int(analysis["risk_score"])
            if analysis["status"] == "INFO":
                log(scene, "INFO", "Preparation finished with no blocking issue / 準備完了。致命的な問題はありません。")
            quality = _labels(_QUALITY_LABELS, settings.quality_mode)
            engine = engine_mode_from_identifier(scene.render.engine)
            audit = _labels(_AUDIT_LABELS, analysis["status"])
            self.report({'INFO'}, localize_pair(
                f"シーン基本設定を準備しました：品質 {quality[0]}、エンジン {engine}、設定の直し {len(changes)} 件、書き出し予定 {len(scene.srr_queue)} 件、診断 {audit[0]}",
                f"Scene setup prepared: quality {quality[1]}, engine {engine}, {len(changes)} repair(s), {len(scene.srr_queue)} queued job(s), audit: {audit[1]}",
            ))
            return {'FINISHED'}
        return self.guarded(context, "Prepare Scene Setup", run)


class SRR_OT_apply_pass_bundle(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.apply_pass_bundle"
    bl_label = "Apply Pass Bundle"
    bl_description = action_tooltip(
        "選択したパスバンドルをビューレイヤーへ一括適用します。",
        "Apply the selected pass bundle to the current view layers.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            target_layers = available_view_layers(context, settings)
            if render_elements_enabled(settings):
                effective_bundle = render_elements_effective_bundle(settings)
                if str(getattr(settings, "render_elements_preset", "FROM_PASS_BUNDLE") or "FROM_PASS_BUNDLE") != "FROM_PASS_BUNDLE":
                    try:
                        settings.pass_bundle = effective_bundle
                    except Exception:
                        pass
                apply_render_elements_preset(scene, settings, target_layers=target_layers)
                set_image_file_format(scene.render.image_settings, render_elements_image_format(settings))
                created_nodes, linked_outputs, layer_count = build_compositor_outputs(context, target_layers=target_layers)
                log(scene, "INFO", both_languages(
                    f"レンダーエレメントを適用しました：クイックセット {status_value_pair(settings.render_elements_preset)[0]}、判定セット {status_value_pair(effective_bundle)[0]}",
                    f"Render Elements applied: quick set {status_value_pair(settings.render_elements_preset)[1]} / detected set {status_value_pair(effective_bundle)[1]}",
                ))
                log(scene, "INFO", f"Compositor outputs prepared: {layer_count} layer(s), {linked_outputs} socket link(s), {created_nodes} node(s).")
                self.report({'INFO'}, iface_text("Render Elements applied."))
                return {'FINISHED'}
            apply_pass_bundle(scene, settings.pass_bundle, target_layers=target_layers)
            log(scene, "INFO", status_log_text("パスバンドルを適用しました", "Pass Bundle applied", settings.pass_bundle))
            self.report({'INFO'}, iface_text("Pass Bundle applied."))
            return {'FINISHED'}
        return self.guarded(context, "Apply Pass Bundle", run)


class SRR_OT_workflow_recipe_dialog(Operator):
    # The dialog itself owns no undo step.  Its OK action delegates exactly once
    # to srr.apply_workflow_recipe, which is the single REGISTER+UNDO operator.
    bl_options = set()
    _sms_no_undo = True
    bl_idname = "srr.workflow_recipes"
    bl_label = "Workflow Recipes"
    bl_description = action_tooltip(
        "小さい Smart Render Nパネルでも一覧が切れにくい専用ダイアログで、ワークフローレシピを選んで適用します。",
        "Choose and apply a workflow recipe from a dedicated dialog that remains readable even when the Smart Render N-panel is small.",
        usage_ja="ボタンを押すとレシピ一覧ダイアログが開きます。目的に合うレシピを選び、下の OK で適用してください。",
        usage_en="Click the button to open the recipe dialog, choose the workflow closest to your goal, and press OK to apply it.",
        tip_ja="各候補にマウスを乗せると、その用途・使い方・適用後の確認ポイントをツールチップで確認できます。",
        tip_en="Hover each option to see a tooltip that explains its purpose, how to use it, and what to review afterwards.",
    )

    recipe_id: EnumProperty(
        name="Workflow Recipe",
        translation_context=PROPERTY_CONTEXT,
        items=workflow_recipe_items(),
        default="SAFE_REVIEW",
    )

    def invoke(self, context, event):
        window_manager = getattr(context, 'window_manager', None)
        if window_manager is None:
            return {'CANCELLED'}
        return window_manager.invoke_props_dialog(self, width=460)

    def draw(self, context):
        layout = self.layout
        try:
            layout.use_property_split = False
            layout.use_property_decorate = False
        except Exception:
            pass
        scene = getattr(context, 'scene', None)
        settings = getattr(scene, 'srr_settings', None)
        col = layout.column(align=True)
        for recipe in WORKFLOW_RECIPES:
            row = col.row(align=True)
            try:
                row.scale_y = 1.05
            except Exception:
                pass
            row.prop_enum(
                self,
                'recipe_id',
                str(recipe.get('id', 'SAFE_REVIEW') or 'SAFE_REVIEW'),
                text=t(settings, str(recipe.get('label_ja', '')), str(recipe.get('label_en', ''))),
            )

    def execute(self, context):
        try:
            result = bpy.ops.srr.apply_workflow_recipe('EXEC_DEFAULT', recipe_id=str(getattr(self, 'recipe_id', 'SAFE_REVIEW') or 'SAFE_REVIEW'))
        except Exception as exc:
            self.report({'ERROR'}, error_text("Apply Workflow Recipe", exc))
            return {'CANCELLED'}
        if isinstance(result, set) and 'FINISHED' in result:
            return {'FINISHED'}
        return {'CANCELLED'}


class SRR_OT_apply_workflow_recipe(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.apply_workflow_recipe"
    bl_label = "Apply Workflow Recipe"
    bl_description = action_tooltip(
        "よくある用途向けの安全な設定一式をワンクリックで適用します。",
        "Apply a safe one-click settings bundle for a common rendering workflow.",
    )

    recipe_id: EnumProperty(
        name="Workflow Recipe",
        translation_context=PROPERTY_CONTEXT,
        items=workflow_recipe_items(),
        default="SAFE_REVIEW",
    )

    @classmethod
    def description(cls, context, properties):
        meta = workflow_recipe_meta(getattr(properties, "recipe_id", "SAFE_REVIEW"))
        return action_tooltip(
            meta["description_ja"],
            meta["description_en"],
            usage_ja="このレシピを押すと、用途に合わせた安全寄りの初期設定をまとめて反映します。適用後に必要な項目だけを細かく調整してください。",
            usage_en="Click the recipe to apply a goal-oriented, safety-first starting setup. After that, fine-tune only the settings you actually need.",
            tip_ja="適用直後はログと各パネルの値を確認すると、どこが変わったか把握しやすくなります。",
            tip_en="Right after applying the recipe, check the logs and panel values so you can quickly understand what changed.",
        )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            meta = workflow_recipe_meta(self.recipe_id)
            changes = apply_workflow_recipe(scene, settings, self.recipe_id)
            apply_profile(scene, settings, target_layers=available_view_layers(context, settings), logger=lambda level, message: log(scene, level, message))
            if changes:
                label = t(settings, meta.get('label_ja', ''), meta.get('label_en', ''))
                log(scene, "INFO", f"{t(settings, 'ワークフローレシピを適用しました', 'Workflow recipe applied')}: {label}")
                for message in changes[:12]:
                    log(scene, "INFO", message)
                if len(changes) > 12:
                    log(scene, "INFO", f"...and {len(changes) - 12} more recipe change(s).")
            else:
                log(scene, "INFO", f"Workflow recipe already matched current settings: {meta['label_en']}")
            self.report({'INFO'}, iface_text(f"Workflow recipe applied: {meta['label_en']}"))
            return {'FINISHED'}
        return self.guarded(context, "Apply Workflow Recipe", run)


class SRR_OT_auto_repair_scene(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.auto_repair_scene"
    bl_label = "Auto Repair Scene"
    bl_description = action_tooltip(
        '逆順フレーム範囲、拡張子重複、空の上書き、重複セレクターなど、壊れやすい設定を安全側へ整理します。',
        "Safely normalize brittle settings such as reversed frame ranges, duplicated extensions, empty overrides, and repeated selectors.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            changes = auto_repair_scene(scene, settings)
            if changes:
                log(scene, "INFO", f"Auto repair applied: {len(changes)} change(s)")
                for message in changes[:20]:
                    log(scene, "INFO", message)
                if len(changes) > 20:
                    log(scene, "INFO", f"...and {len(changes) - 20} more repair(s).")
                self.report({'INFO'}, iface_text(f"Auto repair applied: {len(changes)} change(s)."))
            else:
                log(scene, "INFO", "Auto repair found no safe changes to apply.")
                self.report({'INFO'}, iface_text("No safe repairs were needed."))
            return {'FINISHED'}
        return self.guarded(context, "Auto Repair Scene", run)


class SRR_OT_analyze_scene(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.analyze_scene"
    bl_label = "Analyze Scene"
    bl_description = action_tooltip(
        "出力衝突、欠落アセット、バリアントとテイク参照切れ、保存先状態などを診断します。",
        "Audit the scene for output collisions, missing assets, broken variant references and output-folder readiness.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            collection_clear(scene.srr_logs)
            analysis = analysis_result(context, scene, settings)
            _log_analysis(scene, analysis, detail_limit=int(settings.analysis_detail_limit))
            scene.srr_last_analysis_status = str(analysis["status"])
            scene.srr_last_analysis_time = now_local().strftime("%Y-%m-%d %H:%M:%S")
            scene.srr_last_collision_count = len(analysis["collisions"])
            scene.srr_last_missing_asset_count = len(analysis["missing_assets"])
            scene.srr_last_risk_score = int(analysis["risk_score"])
            if analysis["status"] == "INFO":
                log(scene, "INFO", "Audit finished with no blocking issue / 監査完了。致命的な問題はありません。")
            self.report({'INFO'}, iface_text(f"Audit complete: {analysis['status']}"))
            return {'FINISHED'}
        return self.guarded(context, "Analyze Scene", run)


class SRR_OT_sync_queue(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.sync_render_queue"
    bl_label = "Sync Render Queue"
    bl_description = action_tooltip(
        "現在のキューソース設定から実行キューを再生成します。",
        "Rebuild the execution queue from the current queue-source mode.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            if settings.queue_source_mode == "VARIANTS":
                blueprint = build_variant_queue_blueprint(scene)
            else:
                blueprint = build_pair_queue_blueprint(context, scene, settings)
            sync_queue(scene, blueprint)
            log(scene, "INFO", f"Queue synced: {len(scene.srr_queue)} job(s)")
            self.report({'INFO'}, iface_text(f"Queue synced: {len(scene.srr_queue)}"))
            return {'FINISHED'}
        return self.guarded(context, "Sync Render Queue", run)


class SRR_OT_clear_queue(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.clear_render_queue"
    bl_label = "Clear Render Queue"
    bl_description = action_tooltip(
        "現在のキューを空にします。",
        "Remove every item from the current queue.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            collection_clear(scene.srr_queue)
            log(scene, "INFO", "Queue cleared / キューをクリアしました。")
            return {'FINISHED'}
        return self.guarded(context, "Clear Render Queue", run)



class SRR_OT_add_queue_item(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.add_queue_item"
    bl_label = "Add Queue Item"
    bl_description = action_tooltip(
        "現在カメラ/レイヤーまたは選択中バリアントとテイクから手動キュー項目を追加します。",
        "Add a manual queue item from the current camera/layer or the selected variant.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            item = scene.srr_queue.add()
            item.enabled = True
            variant = _selected_variant(scene)
            active_layer = getattr(context, "view_layer", None)
            if settings.queue_source_mode == "VARIANTS" and variant is not None:
                item.source_mode = "VARIANT"
                item.variant_name = variant.name
                item.camera_name = variant.camera_name
                item.view_layer_name = variant.view_layer_name
                item.label = variant.name or "Variant"
            else:
                item.source_mode = "PAIR"
                item.camera_name = getattr(scene.camera, "name", "")
                item.view_layer_name = getattr(active_layer, "name", "")
                item.variant_name = ""
                if item.camera_name or item.view_layer_name:
                    item.label = f"{item.camera_name or 'Scene Camera'} | {item.view_layer_name or 'Active Layer'}"
                else:
                    item.label = "Queue Item"
            item.label = _unique_queue_label(
                scene,
                item.label,
                ignore_index=len(scene.srr_queue) - 1,
            )
            scene.srr_queue_index = len(scene.srr_queue) - 1
            log(scene, "INFO", f"Queue item added: {item.label}")
            return {'FINISHED'}
        return self.guarded(context, "Add Queue Item", run)


class SRR_OT_duplicate_queue_item(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.duplicate_queue_item"
    bl_label = "Duplicate Queue Item"
    bl_description = action_tooltip(
        "選択中のキュー項目を複製します。",
        "Duplicate the selected queue item.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            source, _index = _selected_queue(scene)
            if source is None:
                self.report({'ERROR'}, iface_text("No queue item selected."))
                return {'CANCELLED'}
            item = scene.srr_queue.add()
            _copy_queue_item(source, item)
            item.label = _unique_queue_label(
                scene,
                f"{item.label} Copy" if item.label else "Queue Item Copy",
                ignore_index=len(scene.srr_queue) - 1,
            )
            scene.srr_queue_index = len(scene.srr_queue) - 1
            log(scene, "INFO", f"Queue item duplicated: {item.label}")
            return {'FINISHED'}
        return self.guarded(context, "Duplicate Queue Item", run)


class SRR_OT_remove_queue_item(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.remove_queue_item"
    bl_label = "Remove Queue Item"
    bl_description = action_tooltip(
        "選択中のキュー項目を削除します。",
        "Remove the selected queue item.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            _item, index = _selected_queue(scene)
            if index < 0:
                return {'CANCELLED'}
            name = scene.srr_queue[index].label
            scene.srr_queue.remove(index)
            scene.srr_queue_index = max(0, min(index, len(scene.srr_queue) - 1))
            log(scene, "INFO", f"Queue item removed: {name}")
            return {'FINISHED'}
        return self.guarded(context, "Remove Queue Item", run)


class SRR_OT_move_queue_item(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.move_queue_item"
    bl_label = "Move Queue Item"
    bl_description = action_tooltip(
        "選択中のキュー項目を上下に移動します。",
        "Move the selected queue item up or down.",
    )

    direction: bpy.props.EnumProperty(
        items=[
            ('UP', 'Up', 'Move the selected queue item earlier in the list.'),
            ('DOWN', 'Down', 'Move the selected queue item later in the list.'),
        ],
        default='UP',
    )

    def execute(self, context):
        def run():
            scene = context.scene
            _item, index = _selected_queue(scene)
            if index < 0:
                return {'CANCELLED'}
            new_index = index - 1 if self.direction == 'UP' else index + 1
            new_index = max(0, min(new_index, len(scene.srr_queue) - 1))
            if new_index == index:
                return {'CANCELLED'}
            scene.srr_queue.move(index, new_index)
            scene.srr_queue_index = new_index
            log(scene, "INFO", f"Queue item moved {self.direction.lower()}: {scene.srr_queue[new_index].label}")
            return {'FINISHED'}
        return self.guarded(context, "Move Queue Item", run)


class SRR_OT_clear_logs(SRSOperatorMixin, Operator):
    bl_options = set()
    _sms_no_undo = True
    bl_idname = "srr.clear_logs"
    bl_label = "Clear Logs"
    bl_description = action_tooltip(
        "ログ一覧を空にします。",
        "Clear the Smart Render log list.",
    )

    def execute(self, context):
        def run():
            collection_clear(context.scene.srr_logs)
            return {'FINISHED'}
        return self.guarded(context, "Clear Logs", run)


class SRR_OT_preview_outputs(SRSOperatorMixin, Operator):
    bl_options = set()
    _sms_no_undo = True
    bl_idname = "srr.preview_output_paths"
    bl_label = "Preview Output Paths"
    bl_description = action_tooltip(
        "実際にはレンダーせず、現在設定で保存されるパスをプレビューします。",
        "Preview the output paths under the current settings without rendering.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            targets = collect_output_targets(context, scene, settings, enabled_only=True)
            if not targets:
                log(scene, "WARNING", "Nothing to preview / プレビュー対象がありません。")
                return {'CANCELLED'}
            log(scene, "INFO", "---- Output Preview / 出力パスを確認 ----")
            shown = 0
            injected_logged = False
            for target in targets:
                if target["injected"] and not injected_logged:
                    log(scene, "WARNING", "Safe uniqueness suffixes active: " + ", ".join(target["injected"]) + " / 上書き防止のため自動トークン補完が有効です。")
                    injected_logged = True
                log(scene, "INFO", f"{target['full_path']}")
                shown += 1
                if shown >= settings.preview_limit:
                    remaining = len(targets) - shown
                    if remaining > 0:
                        log(scene, "INFO", f"...and {remaining} more planned output(s).")
                    break
            collisions, _truncated, _plan = detect_output_collisions(context, scene, settings, enabled_only=True)
            if collisions:
                severity = "ERROR" if settings.abort_on_collisions else "WARNING"
                log(scene, severity, f"Preview found {len(collisions)} collision target(s) / プレビューで {len(collisions)} 件の衝突を検出しました。")
            if bool(getattr(settings, "enable_movie_encode", False)):
                log(scene, "INFO", "---- Movie Encode Preview / ムービー化プレビュー ----")
                queue_items = effective_queue_blueprint(context, scene, settings, enabled_only=True)
                context_view_layer_name = getattr(getattr(context, "view_layer", None), "name", "")
                counts = queue_counts(scene, settings, queue_items) if queue_items else {"camera": 1, "view_layer": 1, "variant": 1, "frame": 1}
                shown_movies = 0
                for item in queue_items:
                    resolved = resolve_item_context(scene, settings, item, context_view_layer_name=context_view_layer_name)
                    if len(resolved.get("frames", []) or []) <= 1:
                        continue
                    first_frame = int(resolved["frames"][0])
                    first_target = resolve_output(scene, settings, item, first_frame, counts, context_view_layer_name=context_view_layer_name)
                    movie_job = build_movie_job(
                        first_target["output_dir"],
                        str(getattr(settings, "movie_file_pattern", "") or "{scene}_{variant}_{camera}_{view_layer}"),
                        dict(first_target["tokens"]),
                        str(getattr(settings, "movie_preset", "H264_MP4") or "H264_MP4"),
                        str(first_target["full_path"]),
                        first_frame,
                        len(resolved["frames"]),
                        int(getattr(settings, "sequence_padding", 4) or 4),
                        str(getattr(settings, "ffmpeg_executable", "ffmpeg") or "ffmpeg"),
                        bool(getattr(settings, "movie_overwrite_existing", False)),
                    )
                    if movie_job is None:
                        log(scene, "WARNING", f"Movie encode preview could not infer input pattern / ムービー化プレビューで連番入力を推定できませんでした: {resolved['label']}")
                        continue
                    log(scene, "INFO", f"{movie_job['output_path']}")
                    shown_movies += 1
                    if shown_movies >= settings.preview_limit:
                        break
            return {'FINISHED'}
        return self.guarded(context, "Preview Outputs", run)


class SRR_OT_setup_render_elements(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.prepare_render_elements"
    bl_label = "Prepare Render Elements"
    bl_description = action_tooltip(
        '3ds Max 風の Render Elements 出力を準備し、必要なパス設定とファイル出力ノードをまとめて整えます。',
        "Prepare a 3ds Max style Render Elements workflow by configuring passes and refreshing the required File Output nodes.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            ensure_render_element_item_defaults(settings)
            settings.render_elements_enabled = True
            try:
                settings.queue_compositing_mode = "COMPOSITOR"
            except Exception:
                pass
            if str(getattr(settings, "verification_scope", "PRIMARY_AND_PASSES") or "PRIMARY_AND_PASSES") == "PRIMARY_ONLY":
                try:
                    settings.verification_scope = "PRIMARY_AND_PASSES"
                except Exception:
                    pass
            effective_bundle = render_elements_effective_bundle(settings)
            if str(getattr(settings, "render_elements_preset", "FROM_PASS_BUNDLE") or "FROM_PASS_BUNDLE") != "FROM_PASS_BUNDLE":
                try:
                    settings.pass_bundle = effective_bundle
                except Exception:
                    pass
            target_layers = queue_target_layers(context, scene, settings, enabled_only=False)
            if not target_layers:
                target_layers = available_view_layers(context, settings)
            apply_profile(scene, settings, target_layers=target_layers, logger=lambda level, message: log(scene, level, message))
            created_nodes, linked_outputs, layer_count = build_compositor_outputs(context, target_layers=target_layers)
            preview_names = list(render_elements_preview_names(settings) or [])
            if not preview_names:
                preview_names = ["Beauty"]
            preview_ja, preview_en = _element_preview_log_text(preview_names, 8)
            preset_label = status_value_pair(settings.render_elements_preset)
            bundle_label = status_value_pair(effective_bundle)
            mode_label = status_value_pair(settings.render_elements_output_mode)
            log(scene, "INFO", both_languages(
                f"レンダーエレメントを準備しました：クイックセット {preset_label[0]}、判定セット {bundle_label[0]}、出力 {mode_label[0]}",
                f"Render Elements prepared: quick set {preset_label[1]} / detected set {bundle_label[1]} / output {mode_label[1]}",
            ))
            log(scene, "INFO", f"Render Elements output folder: {pass_output_folder_name(settings)}")
            log(scene, "INFO", both_languages(f"書き出すレンダーエレメント: {preview_ja}", f"Render Elements preview: {preview_en}"))
            log(scene, "INFO", f"Compositor outputs prepared: {layer_count} layer(s), {linked_outputs} socket link(s), {created_nodes} node(s).")
            self.report({'INFO'}, iface_text(f"Render Elements ready: {len(preview_names)} element(s)"))
            return {'FINISHED'}
        return self.guarded(context, "Prepare Render Elements", run)


class SRR_OT_prepare_network_render(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.prepare_network_render"
    bl_label = "Prepare Network Render"
    bl_description = action_tooltip(
        "ネットワークレンダラー向けに、汎用ブリッジ、ターゲット別 JSON、ヘッドレス実行スクリプトをまとめて書き出します。",
        "Prepare a network-render package by exporting the generic manifest, a target-specific bridge JSON, and headless execution scripts together.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            ensure_render_element_item_defaults(settings)
            settings.network_render_enabled = True
            target = str(getattr(settings, "network_render_target", "GENERIC") or "GENERIC")
            try:
                settings.bridge_target = target
            except Exception:
                pass

            target_layers = queue_target_layers(context, scene, settings, enabled_only=False)
            if not target_layers:
                target_layers = available_view_layers(context, settings)
            apply_profile(scene, settings, target_layers=target_layers, logger=lambda level, message: log(scene, level, message))
            if render_elements_enabled(settings):
                created_nodes, linked_outputs, layer_count = build_compositor_outputs(context, target_layers=target_layers)
                log(scene, "INFO", f"Prepared Render Elements for network export: {layer_count} layer(s), {linked_outputs} socket link(s), {created_nodes} node(s).")

            data = manifest(scene, context)
            base_path = resolve_manifest_path(getattr(settings, "manifest_path", ""), create_parent=True)
            _write_json(base_path, data)

            export_data = build_bridge_export(data, target)
            stem, _ext = os.path.splitext(base_path)
            target_suffix = safe_name(target.lower())
            bridge_path = f"{stem}_{target_suffix}.json"
            _write_json(bridge_path, export_data)

            exported_scripts = export_headless_scripts(data, base_path)
            bundle_summary = {
                "target": target,
                "manifest_path": base_path,
                "bridge_path": bridge_path,
                "shell_path": exported_scripts.get("shell_path", ""),
                "batch_path": exported_scripts.get("batch_path", ""),
                "render_elements": data.get("render_elements", {}) or {},
                "network_render": data.get("network_render", {}) or {},
                "job_count": len(data.get("resolved_queue", []) or []),
                "headless_job_count": int(exported_scripts.get("job_count", 0) or 0),
                "ffmpeg_job_count": int(exported_scripts.get("ffmpeg_job_count", 0) or 0),
                "output_root": str((data.get("output", {}) or {}).get("root", "") or ""),
            }
            bundle_path = f"{stem}_{target_suffix}_network_bundle.json"
            _write_json(bundle_path, bundle_summary)

            if not bpy.data.filepath:
                log(scene, "WARNING", "The .blend file is still unsaved. Save the scene before submitting the exported network package / .blend が未保存です。ネットワーク投入前に保存してください。")
            log(scene, "INFO", f"Network manifest exported: {base_path}")
            log(scene, "INFO", f"Network bridge JSON exported: {bridge_path}")
            log(scene, "INFO", f"Network shell script exported: {exported_scripts.get('shell_path', '')}")
            log(scene, "INFO", f"Network batch script exported: {exported_scripts.get('batch_path', '')}")
            log(scene, "INFO", f"Network bundle summary exported: {bundle_path}")
            self.report({'INFO'}, iface_text(f"Network render package exported: {target}"))
            return {'FINISHED'}
        return self.guarded(context, "Prepare Network Render", run)


class SRR_OT_export_manifest(SRSOperatorMixin, Operator):
    bl_options = set()
    _sms_no_undo = True
    bl_idname = "srr.export_manifest"
    bl_label = "Export Manifest"
    bl_description = action_tooltip(
        "現在の設定・バリアントとテイク・キュー計画を JSON マニフェストとして保存します。",
        "Save the current setup, variants and queue plan as a JSON manifest.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            data = manifest(scene, context)
            path = resolve_manifest_path(getattr(settings, "manifest_path", ""), create_parent=True)
            _write_json(path, data)
            log(scene, "INFO", f"Manifest exported: {path}")
            self.report({'INFO'}, iface_text("Manifest exported."))
            return {'FINISHED'}
        return self.guarded(context, "Export Manifest", run)


class SRR_OT_import_manifest(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.import_manifest"
    bl_label = "Import Manifest"
    bl_description = action_tooltip(
        "保存済み JSON マニフェストから設定・キュー・バリアントとテイクを復元します。",
        "Restore settings, queue items and variants from a saved JSON manifest.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            path = resolve_manifest_path(getattr(settings, "manifest_path", ""), create_parent=True)
            if not os.path.isfile(path):
                raise FileNotFoundError(f"Manifest file not found: {path}")
            with open(path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            apply_manifest(scene, data)
            log(scene, "INFO", f"Manifest imported: {path}")
            self.report({'INFO'}, iface_text("Manifest imported."))
            return {'FINISHED'}
        return self.guarded(context, "Import Manifest", run)


class SRR_OT_export_bridge_manifest(SRSOperatorMixin, Operator):
    bl_options = set()
    _sms_no_undo = True
    bl_idname = "srr.export_bridge_manifest"
    bl_label = "Export Bridge Manifest"
    bl_description = action_tooltip(
        "選択した外部ターゲット向けのブリッジ JSON を書き出します。",
        "Export a target-specific bridge JSON for the selected external pipeline.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            data = manifest(scene, context)
            export_data = build_bridge_export(data, settings.bridge_target)
            base_path = resolve_manifest_path(getattr(settings, "manifest_path", ""), create_parent=True)
            stem, _ext = os.path.splitext(base_path)
            target_suffix = safe_name(settings.bridge_target.lower())
            path = f"{stem}_{target_suffix}.json"
            _write_json(path, export_data)
            log(scene, "INFO", f"Bridge JSON exported: {path}")
            self.report({'INFO'}, iface_text(f"Bridge JSON exported: {settings.bridge_target}"))
            return {'FINISHED'}
        return self.guarded(context, "Export Bridge Manifest", run)


class SRR_OT_export_headless_scripts(SRSOperatorMixin, Operator):
    bl_options = set()
    _sms_no_undo = True
    bl_idname = "srr.export_headless_scripts"
    bl_label = "Export Headless Scripts"
    bl_description = action_tooltip(
        '現在のキューから OS 別のヘッドレスの Blender 実行スクリプト (.sh / .bat) を生成します。',
        "Generate OS-specific headless Blender execution scripts (.sh / .bat) from the current queue.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            data = manifest(scene, context)
            base_path = resolve_manifest_path(getattr(settings, "manifest_path", ""), create_parent=True)
            exported = export_headless_scripts(data, base_path)
            log(scene, "INFO", f"Headless shell script exported: {exported['shell_path']}")
            log(scene, "INFO", f"Headless batch script exported: {exported['batch_path']}")
            log(scene, "INFO", f"Headless job count: {exported['job_count']}")
            log(scene, "INFO", f"FFmpeg post-task count: {exported.get('ffmpeg_job_count', 0)}")
            self.report({'INFO'}, iface_text("Headless scripts exported."))
            return {'FINISHED'}
        return self.guarded(context, "Export Headless Scripts", run)


class SRR_OT_add_variant_from_current(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.add_variant_from_current_state"
    bl_label = "Add Variant From Current State"
    bl_description = action_tooltip(
        '現在のカメラ・ビューレイヤー・ワールドなどを元に新しいバリアントとテイクを追加します。',
        "Create a new variant from the current camera, view layer, World and profile state.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            item = scene.srr_variants.add()
            item.name = _unique_variant_name(scene)
            item.description = ""
            item.parent_variant_name = ""
            item.enabled = True
            _capture_variant_state(scene, context, settings, item, capture_profile=True)
            scene.srr_variant_index = len(scene.srr_variants) - 1
            log(scene, "INFO", f"Variant added: {item.name}")
            self.report({'INFO'}, iface_text(f"Variant added: {item.name}"))
            return {'FINISHED'}
        return self.guarded(context, "Add Variant", run)


class SRR_OT_add_child_variant(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.add_child_variant"
    bl_label = "Add Child Variant"
    bl_description = action_tooltip(
        "選択中バリアントとテイクを親として、継承ベースの子バリアントとテイクを追加します。",
        "Create a child variant that inherits from the selected variant.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            parent = _selected_variant(scene)
            if parent is None:
                self.report({'ERROR'}, iface_text("No parent variant selected."))
                return {'CANCELLED'}
            item = scene.srr_variants.add()
            item.name = _unique_variant_name(scene, base=f"{parent.name}_Child")
            item.description = ""
            item.parent_variant_name = parent.name
            item.enabled = True
            scene.srr_variant_index = len(scene.srr_variants) - 1
            log(scene, "INFO", f"Child variant added: {item.name} <- {parent.name}")
            self.report({'INFO'}, iface_text(f"Child variant added: {item.name}"))
            return {'FINISHED'}
        return self.guarded(context, "Add Child Variant", run)


class SRR_OT_duplicate_variant(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.duplicate_variant"
    bl_label = "Duplicate Variant"
    bl_description = action_tooltip(
        "選択中バリアントとテイクを複製します。",
        "Duplicate the selected variant.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            source = _selected_variant(scene)
            if source is None:
                self.report({'ERROR'}, iface_text("No variant selected."))
                return {'CANCELLED'}
            item = scene.srr_variants.add()
            for prop_name in source.bl_rna.properties.keys():
                if prop_name == "rna_type":
                    continue
                try:
                    setattr(item, prop_name, copy.deepcopy(getattr(source, prop_name)))
                except Exception:
                    pass
            item.name = _unique_variant_name(scene, base=source.name)
            scene.srr_variant_index = len(scene.srr_variants) - 1
            log(scene, "INFO", f"Variant duplicated: {item.name}")
            return {'FINISHED'}
        return self.guarded(context, "Duplicate Variant", run)


class SRR_OT_remove_variant(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.remove_variant"
    bl_label = "Remove Variant"
    bl_description = action_tooltip(
        "選択中バリアントとテイクを削除します。",
        "Remove the selected variant.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            if len(scene.srr_variants) == 0:
                return {'CANCELLED'}
            index = max(0, min(scene.srr_variant_index, len(scene.srr_variants) - 1))
            name = scene.srr_variants[index].name
            child_count = 0
            for item in scene.srr_variants:
                if getattr(item, "parent_variant_name", "") == name:
                    item.parent_variant_name = ""
                    child_count += 1
            scene.srr_variants.remove(index)
            scene.srr_variant_index = max(0, min(index, len(scene.srr_variants) - 1))
            if child_count:
                log(scene, "WARNING", f"Removed parent variant '{name}'. Cleared parent link on {child_count} child variant(s).")
            log(scene, "INFO", f"Variant removed: {name}")
            return {'FINISHED'}
        return self.guarded(context, "Remove Variant", run)


class SRR_OT_capture_variant_overrides(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.capture_overrides"
    bl_label = "Capture Overrides"
    bl_description = action_tooltip(
        '現在のビューレイヤーの上書き状態を選択中バリアントとテイクへ取り込みます。',
        "Capture the current view-layer override state into the selected variant.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            variant = _selected_variant(scene)
            active_layer = getattr(context, "view_layer", None)
            if variant is None or active_layer is None:
                self.report({'ERROR'}, iface_text("Variant or active view layer missing."))
                return {'CANCELLED'}
            _capture_variant_state(scene, context, scene.srr_settings, variant, capture_profile=False)
            log(scene, "INFO", f"Captured overrides into variant: {variant.name}")
            return {'FINISHED'}
        return self.guarded(context, "Capture Variant Overrides", run)


class SRR_OT_apply_variant(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.apply_variant"
    bl_label = "Apply Variant"
    bl_description = action_tooltip(
        "選択中バリアントとテイクを現在のシーンへ適用して確認します。",
        "Apply the selected variant to the current scene for interactive review.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings
            raw_variant = _selected_variant(scene)
            if raw_variant is None:
                self.report({'ERROR'}, iface_text("No variant selected."))
                return {'CANCELLED'}
            variant = effective_variant(scene, raw_variant)
            if variant is None:
                self.report({'ERROR'}, iface_text("Variant resolution failed."))
                return {'CANCELLED'}

            layer_item = view_layer(scene, getattr(variant, "view_layer_name", "")) or getattr(context, "view_layer", None)
            if layer_item is None:
                self.report({'ERROR'}, iface_text("Variant view layer not found."))
                return {'CANCELLED'}
            _set_window_view_layer(context, layer_item)

            if getattr(variant, "camera_name", ""):
                camera = scene_object(scene, variant.camera_name, type_hint="CAMERA")
                if camera is None:
                    self.report({'ERROR'}, iface_text(f"Variant camera not found: {variant.camera_name}"))
                    return {'CANCELLED'}
                if not set_scene_camera(scene, camera, clear_if_none=False):
                    self.report({'ERROR'}, iface_text(f"Unable to assign variant camera: {variant.camera_name}"))
                    return {'CANCELLED'}
            elif scene.camera is None:
                self.report({'ERROR'}, iface_text("No scene camera available."))
                return {'CANCELLED'}

            missing = apply_variant_scene_overrides(scene, layer_item, variant, logger=lambda level, message: log(scene, level, message))
            if missing:
                log(scene, "WARNING", f"Variant references missing collection(s): {', '.join(missing)}")
            apply_profile(scene, settings, variant=variant, target_layers=[layer_item], logger=lambda level, message: log(scene, level, message))
            if getattr(variant, "use_custom_frames", False):
                scene.frame_set(int(min(variant.frame_start, variant.frame_end)))
            log(scene, "INFO", f"Variant applied to scene: {variant.name}")
            self.report({'INFO'}, iface_text(f"Variant applied: {variant.name}"))
            return {'FINISHED'}
        return self.guarded(context, "Apply Variant", run)


class SRR_OT_build_compositor_outputs(SRSOperatorMixin, Operator):
    bl_options = {'UNDO'}
    bl_idname = "srr.build_file_output_nodes"
    bl_label = "Build File Output Nodes"
    bl_description = action_tooltip(
        '現在有効なパスからファイル出力ノード群を構築・更新します。',
        "Build or update File Output nodes from the currently enabled render passes.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            target_layers = queue_target_layers(context, scene, scene.srr_settings, enabled_only=False)
            created_nodes, linked_outputs, layer_count = build_compositor_outputs(context, target_layers=target_layers)
            log(scene, "INFO", f"Compositor outputs updated: {layer_count} layer(s), {linked_outputs} socket link(s), {created_nodes} node(s) created.")
            self.report({'INFO'}, iface_text("Compositor File Output nodes updated."))
            return {'FINISHED'}
        return self.guarded(context, "Build Compositor Outputs", run)


class SRR_OT_render_queue(SRSOperatorMixin, Operator):
    bl_options = set()
    _sms_no_undo = True
    bl_idname = "srr.run_render_queue"
    bl_label = "Run Render Queue"
    bl_description = action_tooltip(
        "キューの有効ジョブを順番に実行します。衝突や既存ファイルは安全側の名前へ自動退避し、必要なら既存フレームを再利用して再開できます。",
        "Execute enabled queue jobs in order with collision-safe output handling, and optionally resume by reusing existing frames.",
    )

    def execute(self, context):
        def run():
            scene = context.scene
            settings = scene.srr_settings

            if len(scene.srr_queue) == 0:
                blueprint = effective_queue_blueprint(context, scene, settings, enabled_only=False)
                sync_queue(scene, blueprint)
            items = effective_queue_blueprint(context, scene, settings, enabled_only=True)
            if not items:
                self.report({'ERROR'}, iface_text("No enabled jobs in queue."))
                return {'CANCELLED'}

            analysis = analysis_result(context, scene, settings)
            has_preflight_error = any(issue.get("level") == "ERROR" for issue in analysis.get("issues", []))
            if has_preflight_error:
                log(scene, "ERROR", "Render queue aborted by preflight / 事前監査エラーのためレンダーキューを実行を中止しました。")
                scene.srr_last_render_summary = json.dumps({"state": "aborted"})
                self.report({'ERROR'}, iface_text("Preflight failed. Run Analyze Scene for details."))
                return {'CANCELLED'}

            counts = queue_counts(scene, settings, items)
            chosen_compositing_mode = _choose_queue_compositing_mode(scene, settings)
            verification_scope = effective_verification_scope(
                str(getattr(settings, "verification_scope", "PRIMARY_AND_PASSES") or "PRIMARY_AND_PASSES"),
                chosen_compositing_mode,
            )
            collisions, _truncated, _plan = detect_output_collisions(context, scene, settings, enabled_only=True)
            collision_paths = {path for path, _bucket in collisions}
            reserved_paths = set()
            reserved_pass_roots = set()
            completed = 0
            failures = 0
            renamed = 0
            skipped_existing = 0
            verified_outputs = 0
            verification_failures = 0
            invalid_removed = 0
            injected_logged = False
            original_window_layer = _active_window_view_layer(context)
            global_state = snapshot_render_state(scene)
            halt_requested = False
            retry_count = max(0, int(getattr(settings, "retry_count", 0))) if bool(getattr(settings, "retry_on_failure", False)) else 0
            verification_enabled = bool(getattr(settings, "verify_outputs_after_render", True))
            verification_min_bytes = int(max(0, int(getattr(settings, "min_output_size_kb", 0) or 0)) * 1024)
            verification_retry_count = max(0, int(getattr(settings, "verification_retry_count", 0) or 0)) if verification_enabled else 0
            verification_retry_delay = max(0.0, float(getattr(settings, "verification_retry_delay", 0.0) or 0.0)) if verification_enabled else 0.0
            cleanup_invalid = bool(getattr(settings, "cleanup_invalid_outputs", True))
            auto_built_for_queue = False

            log(scene, "INFO", f"Render queue start: {len(items)} job(s)")
            log(scene, "INFO", f"Retry policy: retries={retry_count}, halt_on_first_error={bool(getattr(settings, 'halt_on_first_error', False))}")
            log(scene, "INFO", status_log_text("キューのコンポジット", "Queue compositing mode", chosen_compositing_mode))
            log(scene, "INFO", status_log_text("実際の検証範囲", "Effective verification scope", verification_scope))
            if verification_enabled:
                log(scene, "INFO", f"Verification retry policy: retries={verification_retry_count}, delay={verification_retry_delay:.2f}s")
            if chosen_compositing_mode == "COMPOSITOR":
                safe_set_attr(scene, "use_nodes", True)
                if not has_file_output_nodes(scene):
                    queue_layers = queue_target_layers(context, scene, settings, enabled_only=True)
                    built_nodes, built_links, built_layers = build_compositor_outputs(context, target_layers=queue_layers)
                    auto_built_for_queue = True
                    auto_built_tree_name = str(getattr(compositor_node_tree(scene), "name", "") or "")
                    log(scene, "INFO", f"Auto-built compositor outputs for queue: {built_layers} layer(s), {built_links} link(s), {built_nodes} node(s).")
            try:
                for item in items:
                    if halt_requested:
                        break
                    resolved = resolve_item_context(scene, settings, item, context_view_layer_name=getattr(getattr(context, "view_layer", None), "name", ""))
                    variant = resolved["variant"]
                    camera = scene_object(scene, resolved["camera_name"], type_hint="CAMERA") if resolved["camera_name"] else scene.camera
                    layer_item = view_layer(scene, resolved["view_layer_name"])

                    if camera is None:
                        failures += 1
                        log(scene, "ERROR", f"Missing camera: {resolved['camera_name']}")
                        if bool(getattr(settings, "halt_on_first_error", False)):
                            halt_requested = True
                        continue
                    if layer_item is None:
                        failures += 1
                        log(scene, "ERROR", f"Missing view layer: {resolved['view_layer_name']}")
                        if bool(getattr(settings, "halt_on_first_error", False)):
                            halt_requested = True
                        continue

                    item_state = snapshot_render_state(scene, view_layer_obj=layer_item)
                    try:
                        _set_window_view_layer(context, layer_item)
                        _set_queue_compositing(scene, chosen_compositing_mode)
                        if not set_scene_camera(scene, camera, clear_if_none=False):
                            raise RuntimeError(f"Unable to assign camera: {getattr(camera, 'name', '')}")

                        if variant is not None:
                            missing = apply_variant_scene_overrides(scene, layer_item, variant, logger=lambda level, message: log(scene, level, message))
                            if missing:
                                log(scene, "WARNING", f"Variant references missing collection(s): {', '.join(missing)}")

                        apply_profile(scene, settings, variant=variant, target_layers=[layer_item], logger=lambda level, message: log(scene, level, message))
                        if chosen_compositing_mode == "COMPOSITOR" and refresh_file_output_node_for_layer(context, layer_item):
                            log(scene, "INFO", f"Output node updated to match the active passes: {layer_item.name}")

                        for frame_value in resolved["frames"]:
                            if halt_requested:
                                break
                            scene.frame_set(int(frame_value))
                            target = resolve_output(scene, settings, item, int(frame_value), counts, context_view_layer_name=layer_item.name)
                            if target["injected"] and not injected_logged:
                                log(scene, "WARNING", "Safe uniqueness suffixes active: " + ", ".join(target["injected"]) + " / 安全な一意化トークンを自動追加しています。")
                                injected_logged = True
                            if settings.auto_create_folders:
                                ensure_directory(target["output_dir"])
                            elif not os.path.isdir(target["output_dir"]):
                                raise RuntimeError(f"Output directory does not exist: {target['output_dir']}")

                            final_stem = target["full_stem"]
                            final_parent_dir = os.path.dirname(final_stem) or target["output_dir"]
                            if settings.auto_create_folders:
                                ensure_directory(final_parent_dir)
                            elif not os.path.isdir(final_parent_dir):
                                raise RuntimeError(f"Output subdirectory does not exist: {final_parent_dir}")

                            final_ext = target["extension"]
                            primary_path = target["full_path"]
                            frame_padding = int(getattr(settings, "sequence_padding", 4) or 4)
                            variant_namespace = str(target["tokens"].get("variant", "base"))

                            if chosen_compositing_mode == "COMPOSITOR":
                                configure_srs_file_output_nodes(
                                    scene,
                                    str(target["profile"].get("image_format", getattr(settings, "image_format", scene.render.image_settings.file_format))),
                                    str(target["output_dir"]),
                                    variant_name=variant_namespace,
                                    frame_value=int(frame_value),
                                    padding=frame_padding,
                                    explicit_frame_token=True,
                                    target_layer_name=layer_item.name,
                                )

                            primary_verification_plan = build_output_verification_plan(
                                scene,
                                str(primary_path),
                                str(target["output_dir"]),
                                variant_namespace,
                                str(layer_item.name),
                                int(frame_value),
                                str(target["profile"].get("image_format", getattr(settings, "image_format", scene.render.image_settings.file_format))),
                                frame_padding,
                                verification_scope,
                            )
                            predicted_collision_paths = {
                                os.path.normpath(str(requirement.get("expected_path", "") or ""))
                                for requirement in (primary_verification_plan.get("requirements", []) or [])
                                if os.path.normpath(str(requirement.get("expected_path", "") or "")) in collision_paths
                            }
                            has_predicted_collision = bool(predicted_collision_paths)

                            if bool(getattr(settings, "skip_existing_frames", False)) and not has_predicted_collision:
                                if verification_enabled and plan_has_any_existing_outputs(primary_verification_plan, verification_min_bytes):
                                    skip_result = verify_output_plan_with_retries(
                                        primary_verification_plan,
                                        verification_min_bytes,
                                        retries=verification_retry_count,
                                        delay_seconds=verification_retry_delay,
                                        on_retry=lambda attempt, total_attempts, result, path=primary_path: log(
                                            scene,
                                            "WARNING",
                                            f"Retrying verification for existing output [{attempt}/{max(1, total_attempts - 1)}]: {path} (missing={len(result.get('missing', []) or [])}, too_small={len(result.get('too_small', []) or [])})",
                                        ),
                                    )
                                    if skip_result.get("ok", False):
                                        skipped_existing += 1
                                        verified_outputs += 1
                                        reserved_paths.add(primary_path)
                                        log(scene, "INFO", f"Skipped verified existing frame: {primary_path}")
                                        continue
                                    verification_failures += 1
                                    removed_count = remove_invalid_outputs(skip_result) if cleanup_invalid else 0
                                    invalid_removed += removed_count
                                    log(scene, "WARNING", f"Existing output failed verification and will be re-rendered: {primary_path}")
                                elif (not verification_enabled) and plan_has_existing_outputs(primary_verification_plan, 0):
                                    skipped_existing += 1
                                    reserved_paths.add(primary_path)
                                    log(scene, "INFO", f"Skipped existing frame: {primary_path}")
                                    continue

                            allow_existing = bool(settings.overwrite_existing)
                            reserved_for_primary = set(reserved_paths)
                            if has_predicted_collision and not settings.abort_on_collisions:
                                allow_existing = False
                                reserved_for_primary.add(primary_path)
                            final_stem, suffix = unique_output_stem(final_stem, final_ext, reserved_for_primary, allow_existing)
                            final_path = f"{final_stem}.{final_ext}" if final_ext else final_stem
                            if suffix:
                                renamed += 1
                                log(scene, "WARNING", f"Output renamed for safety: {final_path}")
                            reserved_paths.add(final_path)

                            effective_variant_namespace = variant_namespace
                            if chosen_compositing_mode == "COMPOSITOR":
                                if has_predicted_collision or suffix:
                                    preferred_variant_namespace = safe_name(f"{variant_namespace}{suffix or ''}") or safe_name(variant_namespace) or "base"
                                    effective_variant_namespace = _unique_pass_namespace_token(
                                        preferred_variant_namespace,
                                        os.path.join(str(target["output_dir"]), pass_output_folder_name(settings)),
                                        reserved_pass_roots,
                                    )
                                configure_srs_file_output_nodes(
                                    scene,
                                    scene.render.image_settings.file_format,
                                    target["output_dir"],
                                    variant_name=effective_variant_namespace,
                                    frame_value=int(frame_value),
                                    padding=frame_padding,
                                    explicit_frame_token=True,
                                    target_layer_name=layer_item.name,
                                )

                            scene.render.filepath = final_stem
                            scene.render.use_file_extension = True
                            verification_plan = build_output_verification_plan(
                                scene,
                                str(final_path),
                                str(target["output_dir"]),
                                effective_variant_namespace,
                                str(layer_item.name),
                                int(frame_value),
                                str(scene.render.image_settings.file_format or target["profile"].get("image_format", getattr(settings, "image_format", "PNG"))),
                                frame_padding,
                                verification_scope,
                            )
                            last_render_error = None
                            for attempt in range(retry_count + 1):
                                try:
                                    if attempt > 0:
                                        log(scene, "WARNING", f"Retrying render ({attempt}/{retry_count}) for: {final_path}")
                                    bpy.ops.render.render(
                                        'EXEC_DEFAULT',
                                        write_still=True,
                                        use_viewport=False,
                                        scene=scene.name,
                                        layer=layer_item.name,
                                    )
                                    if verification_enabled:
                                        verification_result = verify_output_plan_with_retries(
                                            verification_plan,
                                            verification_min_bytes,
                                            retries=verification_retry_count,
                                            delay_seconds=verification_retry_delay,
                                            on_retry=lambda attempt, total_attempts, result, path=final_path: log(
                                                scene,
                                                "WARNING",
                                                f"Retrying post-render verification [{attempt}/{max(1, total_attempts - 1)}] for {path}: missing={len(result.get('missing', []) or [])} too_small={len(result.get('too_small', []) or [])}",
                                            ),
                                        )
                                        if not verification_result.get("ok", False):
                                            verification_failures += 1
                                            removed_count = remove_invalid_outputs(verification_result) if cleanup_invalid else 0
                                            invalid_removed += removed_count
                                            missing_count = len(verification_result.get("missing", []) or [])
                                            too_small_count = len(verification_result.get("too_small", []) or [])
                                            raise RuntimeError(
                                                f"Output verification failed: expected={verification_result.get('expected_output_count', 0)} missing={missing_count} too_small={too_small_count} attempts={verification_result.get('attempt_count', 1)} / 出力検証失敗"
                                            )
                                        if verification_result.get("noop", False):
                                            log(scene, "INFO", f"Verification plan resolved to no concrete files and was treated as a no-op: {final_path}")
                                        else:
                                            verified_outputs += 1
                                            log(scene, "INFO", f"Verified outputs: {verification_result.get('expected_output_count', 0)} for {final_path}")
                                    completed += 1
                                    log(scene, "INFO", f"Rendered: {final_path}")
                                    last_render_error = None
                                    break
                                except Exception as render_ex:
                                    last_render_error = render_ex
                                    if attempt >= retry_count:
                                        raise
                                    log(scene, "WARNING", f"Render attempt failed [{attempt + 1}/{retry_count + 1}] for {final_path}: {render_ex}")
                            if last_render_error is not None:
                                raise last_render_error
                    except Exception as item_ex:
                        failures += 1
                        log(scene, "ERROR", f"Render failed [{item.get('label') or layer_item.name}]: {item_ex}")
                        if bool(getattr(settings, "halt_on_first_error", False)):
                            halt_requested = True
                    finally:
                        restore_render_state(scene, item_state, view_layer_obj=layer_item)
            finally:
                restore_render_state(scene, global_state)
                _set_window_view_layer(context, original_window_layer)
                if auto_built_for_queue:
                    removed = cleanup_srs_compositor_nodes(scene)
                    if removed:
                        log(scene, "INFO", f"Cleaned temporary compositor nodes: {removed}")
                    original_group_name = str(global_state.get("compositing_node_group_name", "") or "")
                    if auto_built_tree_name and not original_group_name:
                        try:
                            node_group = bpy.data.node_groups.get(auto_built_tree_name)
                        except Exception:
                            node_group = None
                        if node_group is not None:
                            try:
                                bpy.data.node_groups.remove(node_group)
                                log(scene, "INFO", f"Removed temporary compositor group: {auto_built_tree_name}")
                            except Exception:
                                pass

            scene.srr_last_render_summary = json.dumps({
                "state": "halted" if halt_requested and failures else "finished",
                "success": completed,
                "verified": verified_outputs,
                "skipped": skipped_existing,
                "failures": failures,
                "verification_failures": verification_failures,
                "invalid_removed": invalid_removed,
                "renamed": renamed,
            })
            summary = " / ".join(render_summary_lines(scene.srr_last_render_summary, settings)[0])
            log(scene, "INFO", summary)
            self.report({'INFO'}, iface_text(summary))
            return {'FINISHED'}
        return self.guarded(context, "Run Render Queue", run)


OPERATOR_CLASSES = (
    SRR_OT_toggle_properties_tab,
    SRR_OT_toggle_npanel_section,
    SRR_OT_apply_render_elements_quick_set,
    SRR_OT_apply_profile,
    SRR_OT_prepare_setup,
    SRR_OT_apply_pass_bundle,
    SRR_OT_setup_render_elements,
    SRR_OT_prepare_network_render,
    SRR_OT_workflow_recipe_dialog,
    SRR_OT_apply_workflow_recipe,
    SRR_OT_auto_repair_scene,
    SRR_OT_analyze_scene,
    SRR_OT_sync_queue,
    SRR_OT_clear_queue,
    SRR_OT_add_queue_item,
    SRR_OT_duplicate_queue_item,
    SRR_OT_remove_queue_item,
    SRR_OT_move_queue_item,
    SRR_OT_clear_logs,
    SRR_OT_preview_outputs,
    SRR_OT_export_manifest,
    SRR_OT_import_manifest,
    SRR_OT_export_bridge_manifest,
    SRR_OT_export_headless_scripts,
    SRR_OT_add_variant_from_current,
    SRR_OT_add_child_variant,
    SRR_OT_duplicate_variant,
    SRR_OT_remove_variant,
    SRR_OT_capture_variant_overrides,
    SRR_OT_apply_variant,
    SRR_OT_build_compositor_outputs,
    SRR_OT_render_queue,
)



for _operator_cls in OPERATOR_CLASSES:
    try:
        _raw_description = getattr(_operator_cls, "bl_description", "")
        if _raw_description:
            _operator_cls.bl_description = expand_inline_bilingual_tooltip(_raw_description, action=True)
    except Exception:
        pass

try:
    localize_class_attributes(OPERATOR_CLASSES)
except Exception:
    pass


# --- standard N-panel compatibility tooltip ---
try:
    SRR_OT_toggle_properties_tab.bl_label = source_text('Smart Render Nパネル', 'Smart Render N-panel')
    SRR_OT_toggle_properties_tab.bl_description = action_tooltip(
        "3Dビュー右側の通常Nパネルにある Smart Render カテゴリを再描画します。",
        "Refresh the ordinary Smart Render category in the right-side 3D View N-panel.",
        usage_ja="3DビューでNキーを押し、Smart Render タブを選択して使います。",
        usage_en="Press N in the 3D View and choose the Smart Render tab to use it.",
        tip_ja="Blender標準のNパネル表示だけを使います。",
        tip_en="Only Blender's standard N-panel display is used.",
    )
except Exception:
    pass
