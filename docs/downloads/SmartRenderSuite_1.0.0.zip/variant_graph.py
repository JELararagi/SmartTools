from __future__ import annotations

from types import SimpleNamespace
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from .compat import safe_name


def _attr_value(obj, attr_name: str, default=None):
    try:
        value = getattr(obj, attr_name, default)
    except Exception:
        return default
    return default if value is None else value



SCENE_ENUM_PROPS = (
    "engine_mode",
    "quality_mode",
    "denoise_mode",
    "adaptive_sampling_mode",
    "motion_blur_mode",
    "freestyle_mode",
    "pass_bundle",
    "image_format_override",
    "film_transparent_mode",
)
ZERO_OVERRIDE_PROPS = (
    "resolution_percentage_override",
    "sample_multiplier_override",
)
OUTPUT_OVERRIDE_PROPS = (
    "output_root_override",
    "output_dir_pattern_override",
    "output_file_pattern_override",
    "stamp_note_override",
    "job_name_override",
    "job_tags_override",
)
EXECUTION_INT_OVERRIDE_PROPS = (
    "resolution_x_override",
    "resolution_y_override",
    "frame_chunk_size_override",
    "concurrent_tasks_override",
    "temporal_subsamples_override",
    "spatial_subsamples_override",
    "accumulation_samples_override",
)
EXECUTION_SENTINEL_INT_OVERRIDE_PROPS = (
    "farm_priority_override",
)
EXECUTION_FLOAT_OVERRIDE_PROPS = (
    "memory_gb_hint_override",
)
REPRESENTATION_PROPS = (
    "proxy_collections",
    "render_collections",
)
COLLECTION_OVERRIDE_PROPS = (
    "include_collections",
    "exclude_collections",
    "holdout_collections",
    "indirect_only_collections",
)
OBJECT_VISIBILITY_OVERRIDE_PROPS = (
    "show_objects",
    "hide_objects",
)
COLOR_MANAGEMENT_BLOCK_PROPS = (
    "view_transform_override",
    "look_override",
    "use_exposure_override",
    "exposure_override",
    "use_gamma_override",
    "gamma_override",
)


def _variant_items(scene) -> List[object]:
    return list(getattr(scene, "srr_variants", []) or [])


def variant_lookup(scene) -> Dict[str, object]:
    result: Dict[str, object] = {}
    for variant in _variant_items(scene):
        name = str(getattr(variant, "name", "") or "").strip()
        if name and name not in result:
            result[name] = variant
    return result


def duplicate_variant_names(scene) -> List[str]:
    counts: Dict[str, int] = {}
    for variant in _variant_items(scene):
        name = str(getattr(variant, "name", "") or "").strip()
        if not name:
            continue
        counts[name] = counts.get(name, 0) + 1
    return sorted((name for name, count in counts.items() if count > 1), key=str.casefold)


def variant_chain(scene, variant_or_name) -> Tuple[List[object], List[dict]]:
    lookup = variant_lookup(scene)
    current = lookup.get(str(variant_or_name or "").strip()) if isinstance(variant_or_name, str) else variant_or_name
    if current is None:
        return [], []
    trail: List[object] = []
    seen = set()
    issues: List[dict] = []
    while current is not None:
        name = str(getattr(current, "name", "") or "").strip()
        if not name:
            break
        if name in seen:
            issues.append(
                {
                    "type": "cycle",
                    "variant": name,
                    "chain": [str(getattr(item, "name", "") or "") for item in reversed(trail)] + [name],
                }
            )
            break
        trail.append(current)
        seen.add(name)
        parent_name = str(getattr(current, "parent_variant_name", "") or "").strip()
        if not parent_name:
            break
        if parent_name == name:
            issues.append({"type": "self_parent", "variant": name, "parent": parent_name})
            break
        parent = lookup.get(parent_name)
        if parent is None:
            issues.append({"type": "missing_parent", "variant": name, "parent": parent_name})
            break
        current = parent
    return list(reversed(trail)), issues


def variant_path(scene, variant_or_name, separator: str = " / ", *, safe: bool = False) -> str:
    lineage, _issues = variant_chain(scene, variant_or_name)
    if not lineage:
        return ""
    names = [str(getattr(item, "name", "") or "") for item in lineage if str(getattr(item, "name", "") or "")]
    if safe:
        names = [safe_name(name) for name in names]
    return separator.join(name for name in names if name)


def effective_variant_data(scene, variant_or_name) -> Optional[Dict[str, object]]:
    lookup = variant_lookup(scene)
    variant = lookup.get(str(variant_or_name or "").strip()) if isinstance(variant_or_name, str) else variant_or_name
    if variant is None:
        return None

    lineage, issues = variant_chain(scene, variant)
    if not lineage:
        lineage = [variant]

    data: Dict[str, object] = {
        "enabled": True,
        "name": str(getattr(variant, "name", "") or ""),
        "description": "",
        "parent_variant_name": str(getattr(variant, "parent_variant_name", "") or ""),
        "parent_name": "",
        "camera_name": "",
        "view_layer_name": "",
        "engine_mode": "SCENE",
        "quality_mode": "SCENE",
        "resolution_percentage_override": 0,
        "resolution_x_override": 0,
        "resolution_y_override": 0,
        "sample_multiplier_override": 0.0,
        "denoise_mode": "SCENE",
        "adaptive_sampling_mode": "SCENE",
        "motion_blur_mode": "SCENE",
        "freestyle_mode": "SCENE",
        "pass_bundle": "SCENE",
        "image_format_override": "SCENE",
        "use_custom_frames": False,
        "frame_start": int(_attr_value(variant, "frame_start", 1)),
        "frame_end": int(_attr_value(variant, "frame_end", 250)),
        "material_override_mode": "SCENE",
        "material_override_name": "",
        "world_override_mode": "SCENE",
        "world_override_name": "",
        "collection_override_mode": "SCENE",
        "film_transparent_mode": "SCENE",
        "color_management_mode": "SCENE",
        "view_transform_override": "",
        "look_override": "",
        "use_exposure_override": False,
        "exposure_override": float(getattr(variant, "exposure_override", 0.0) or 0.0),
        "use_gamma_override": False,
        "gamma_override": float(getattr(variant, "gamma_override", 1.0) or 1.0),
        "include_collections": "",
        "exclude_collections": "",
        "holdout_collections": "",
        "indirect_only_collections": "",
        "object_visibility_override_mode": "SCENE",
        "show_objects": "",
        "hide_objects": "",
        "representation_mode": "SCENE",
        "proxy_collections": "",
        "render_collections": "",
        "output_root_override": "",
        "output_dir_pattern_override": "",
        "output_file_pattern_override": "",
        "stamp_note_override": "",
        "job_name_override": "",
        "job_tags_override": "",
        "execution_device_mode_override": "SCENE",
        "frame_chunk_size_override": 0,
        "concurrent_tasks_override": 0,
        "farm_priority_override": -1,
        "memory_gb_hint_override": -1.0,
        "temporal_subsamples_override": 0,
        "spatial_subsamples_override": 0,
        "accumulation_samples_override": 0,
    }

    for source in lineage:
        data["enabled"] = bool(data["enabled"]) and bool(getattr(source, "enabled", True))
        if str(getattr(source, "description", "") or "").strip():
            data["description"] = str(getattr(source, "description", "") or "")
        if str(getattr(source, "camera_name", "") or "").strip():
            data["camera_name"] = str(getattr(source, "camera_name", "") or "")
        if str(getattr(source, "view_layer_name", "") or "").strip():
            data["view_layer_name"] = str(getattr(source, "view_layer_name", "") or "")

        for prop_name in SCENE_ENUM_PROPS:
            value = str(getattr(source, prop_name, "SCENE") or "SCENE")
            if value != "SCENE":
                data[prop_name] = value

        resolution_value = int(getattr(source, "resolution_percentage_override", 0) or 0)
        if resolution_value > 0:
            data["resolution_percentage_override"] = resolution_value

        sample_value = float(getattr(source, "sample_multiplier_override", 0.0) or 0.0)
        if sample_value > 0.0:
            data["sample_multiplier_override"] = sample_value

        for prop_name in EXECUTION_INT_OVERRIDE_PROPS:
            value = int(getattr(source, prop_name, 0) or 0)
            if value > 0:
                data[prop_name] = value

        farm_priority_value = int(_attr_value(source, "farm_priority_override", -1))
        if farm_priority_value >= 0:
            data["farm_priority_override"] = farm_priority_value

        memory_value = float(_attr_value(source, "memory_gb_hint_override", -1.0))
        if memory_value >= 0.0:
            data["memory_gb_hint_override"] = memory_value

        execution_device_mode = str(getattr(source, "execution_device_mode_override", "SCENE") or "SCENE")
        if execution_device_mode != "SCENE":
            data["execution_device_mode_override"] = execution_device_mode

        if bool(getattr(source, "use_custom_frames", False)):
            data["use_custom_frames"] = True
            data["frame_start"] = int(_attr_value(source, "frame_start", data["frame_start"]))
            data["frame_end"] = int(_attr_value(source, "frame_end", data["frame_end"]))

        material_mode = str(getattr(source, "material_override_mode", "SCENE") or "SCENE")
        if material_mode != "SCENE":
            data["material_override_mode"] = material_mode
            data["material_override_name"] = str(getattr(source, "material_override_name", "") or "")

        world_mode = str(getattr(source, "world_override_mode", "SCENE") or "SCENE")
        if world_mode != "SCENE":
            data["world_override_mode"] = world_mode
            data["world_override_name"] = str(getattr(source, "world_override_name", "") or "")

        collection_mode = str(getattr(source, "collection_override_mode", "SCENE") or "SCENE")
        if collection_mode != "SCENE":
            data["collection_override_mode"] = collection_mode
            for prop_name in COLLECTION_OVERRIDE_PROPS:
                data[prop_name] = str(getattr(source, prop_name, "") or "")

        object_mode = str(getattr(source, "object_visibility_override_mode", "SCENE") or "SCENE")
        if object_mode != "SCENE":
            data["object_visibility_override_mode"] = object_mode
            for prop_name in OBJECT_VISIBILITY_OVERRIDE_PROPS:
                data[prop_name] = str(getattr(source, prop_name, "") or "")

        representation_mode = str(getattr(source, "representation_mode", "SCENE") or "SCENE")
        if representation_mode != "SCENE":
            data["representation_mode"] = representation_mode
            for prop_name in REPRESENTATION_PROPS:
                data[prop_name] = str(getattr(source, prop_name, "") or "")

        color_mode = str(getattr(source, "color_management_mode", "SCENE") or "SCENE")
        if color_mode != "SCENE":
            data["color_management_mode"] = color_mode
            for prop_name in COLOR_MANAGEMENT_BLOCK_PROPS:
                data[prop_name] = getattr(source, prop_name)

        for prop_name in OUTPUT_OVERRIDE_PROPS:
            value = str(getattr(source, prop_name, "") or "")
            if value.strip():
                data[prop_name] = value

    chain_names = [str(getattr(item, "name", "") or "") for item in lineage if str(getattr(item, "name", "") or "")]
    safe_chain_names = [safe_name(name) for name in chain_names if name]
    data["variant_chain"] = chain_names
    data["variant_path"] = "/".join(safe_chain_names) if safe_chain_names else safe_name(data["name"] or "base")
    data["take_path"] = data["variant_path"]
    data["parent_name"] = chain_names[-2] if len(chain_names) > 1 else ""
    data["inheritance_depth"] = max(0, len(chain_names) - 1)
    data["lineage_issues"] = issues
    data["lineage_issue_count"] = len(issues)
    return data


def effective_variant(scene, variant_or_name):
    data = effective_variant_data(scene, variant_or_name)
    if data is None:
        return None
    return SimpleNamespace(**data)


def variant_inheritance_issues(scene) -> List[dict]:
    issues: List[dict] = []
    seen = set()

    for name in duplicate_variant_names(scene):
        key = ("duplicate", name)
        if key in seen:
            continue
        seen.add(key)
        issues.append({"type": "duplicate_name", "variant": name})

    for variant in _variant_items(scene):
        lineage, lineage_issues = variant_chain(scene, variant)
        variant_name = str(getattr(variant, "name", "") or "").strip()
        for issue in lineage_issues:
            signature = (
                issue.get("type"),
                variant_name,
                issue.get("parent"),
                tuple(issue.get("chain", []) or []),
            )
            if signature in seen:
                continue
            seen.add(signature)
            issues.append(issue)
    return issues
