# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import ast
import re

import bpy

from . import operators as ops
bl_info = {
    "name": 'HDRI Rotation',
    "author": "JELararagi",
    "version": (1, 0, 7),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Render",
    "description": "Rotate HDR environment lighting from the Smart Render N-panel and the 3D View.",
    "category": "3D View",
}

def get_language_list() -> list:
    try:
        bpy.context.preferences.view.language = ""
    except TypeError as e:
        matches = re.findall(r'\(([^()]*)\)', e.args[-1])
        return ast.literal_eval(f"({matches[-1]})")
    return []


def register():
    ops.register()
    language = "ZH_CN" if "ZH_CN" in get_language_list() else "zh_HANS"
    bpy.app.translations.register("hdr_rotation", {language: {
        ("*", "HDRI Rotation"): "HDR旋转",
    }})


def unregister():
    ops.unregister()
    bpy.app.translations.unregister("hdr_rotation")
