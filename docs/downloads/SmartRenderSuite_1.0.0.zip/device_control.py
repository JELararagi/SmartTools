from __future__ import annotations

from typing import Dict

from .compat import engine_mode_from_identifier, safe_get_attr, safe_set_attr
from .resources import resource_profile


def local_execution_device_preview(scene, settings, variant=None) -> Dict[str, object]:
    execution = resource_profile(settings, variant=variant)
    requested = str(execution.get("device_mode", "AUTO") or "AUTO").upper()
    render = getattr(scene, "render", None)
    engine_identifier = str(getattr(render, "engine", "") or "")
    engine_mode = engine_mode_from_identifier(engine_identifier)
    cycles_settings = getattr(scene, "cycles", None)
    current = str(safe_get_attr(cycles_settings, "device", "") or "").upper()

    preview: Dict[str, object] = {
        "requested": requested,
        "engine_identifier": engine_identifier,
        "engine_mode": engine_mode,
        "current": current,
        "target": "",
        "effective": current or requested or "AUTO",
        "applicable": False,
        "applied": False,
        "bridge_only": False,
        "reason_ja": "",
        "reason_en": "",
        "display": requested or "AUTO",
    }

    if requested in {"", "AUTO"}:
        preview["effective"] = current or "AUTO"
        preview["display"] = requested or "AUTO"
        preview["reason_ja"] = '自動は Blender / Cycles の現在デバイス設定を尊重します。'
        preview["reason_en"] = "AUTO respects the current Blender/Cycles device choice."
        return preview

    if engine_mode != "CYCLES":
        preview["bridge_only"] = True
        preview["display"] = f"{requested} (bridge)"
        preview["effective"] = current or requested
        preview["reason_ja"] = 'ローカルの実行デバイス切替は Cycles にのみ適用されます。現在のエンジンではブリッジ / マニフェストへのヒントとして保持します。'
        preview["reason_en"] = "Local execution-device switching is applied only to Cycles. For the current engine the value is kept as a bridge/manifest hint."
        return preview

    if cycles_settings is None or not hasattr(cycles_settings, "device"):
        preview["bridge_only"] = True
        preview["display"] = f"{requested} (bridge)"
        preview["effective"] = requested
        preview["reason_ja"] = 'この環境では Cycles のデバイス設定を操作できないため、ブリッジ / マニフェストへのヒントとして保持します。'
        preview["reason_en"] = "This environment does not expose scene.cycles.device, so the value is kept only as a bridge/manifest hint."
        return preview

    if requested == "HYBRID":
        preview["bridge_only"] = True
        preview["display"] = "HYBRID (bridge)"
        preview["effective"] = current or "HYBRID"
        preview["reason_ja"] = 'ハイブリッドは下流のファーム向けのヒントとしては保持されますが、Blender のシーン単位デバイスは CPU / GPU の二択なのでローカルには安全に強制しません。'
        preview["reason_en"] = "HYBRID is preserved as a downstream farm hint, but Blender's scene-level device control is CPU/GPU only, so it is not forced locally."
        return preview

    target = "GPU" if requested == "GPU" else "CPU"
    preview["target"] = target
    preview["effective"] = target
    preview["applicable"] = True
    preview["display"] = f"{current} → {target}" if current and current != target else target
    preview["reason_ja"] = 'Cycles のデバイス設定にローカル適用できます。'
    preview["reason_en"] = "Can be applied locally through Cycles scene.cycles.device."
    return preview


def apply_local_execution_device(scene, settings, variant=None, logger=None) -> Dict[str, object]:
    preview = local_execution_device_preview(scene, settings, variant=variant)
    if not preview.get("applicable") or not preview.get("target"):
        return preview

    cycles_settings = getattr(scene, "cycles", None)
    target = str(preview.get("target", "") or "").upper()
    before = str(safe_get_attr(cycles_settings, "device", "") or "").upper()
    ok = safe_set_attr(cycles_settings, "device", target)
    after = str(safe_get_attr(cycles_settings, "device", "") or "").upper()
    preview["applied"] = bool(ok and after == target and before != target)
    preview["effective"] = after or target
    preview["display"] = f"{preview['requested']} → {preview['effective']}" if str(preview.get("requested", "")) != str(preview.get("effective", "")) else str(preview.get("effective", ""))

    if logger is not None:
        if after == target:
            logger("INFO", f"Local execution device set for Cycles: {after} / Cycles のローカル実行デバイスを設定しました: {after}")
        elif not ok:
            logger("WARNING", f"Could not apply local execution device '{target}' to Cycles; keeping it as a bridge hint only / Cycles のローカル実行デバイス '{target}' を適用できなかったため、ブリッジヒントとしてのみ保持します。")
    return preview
