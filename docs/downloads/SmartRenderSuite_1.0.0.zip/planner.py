from __future__ import annotations

import os
import re
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import bpy

from .compat import (
    set_image_file_format,
    abspath,
    apply_layer_collection_overrides,
    camera_selection,
    can_write_directory,
    compositor_node_tree,
    command_exists,
    default_output_root,
    collection_clear,
    effective_queue_compositing_mode,
    engine_mode_from_identifier,
    ensure_directory,
    enum_keys,
    IMAGE_FORMAT_EXTENSIONS,
    image_format_extension,
    apply_object_render_overrides,
    layer_collection_map,
    log,
    material_by_name,
    missing_external_assets,
    now_local,
    parse_name_list,
    resolve_engine_identifier,
    resolve_manifest_path,
    restore_layer_collection_flags,
    set_scene_camera,
    safe_get_attr,
    safe_name,
    safe_set_attr,
    scene_object,
    snapshot_layer_collection_flags,
    snapshot_object_render_visibility,
    restore_object_render_visibility,
    unique_output_stem,
    uses_relative_blend_path,
    view_layer,
    world_by_name,
    worst_severity,
)
from .meta import ADDON_NAME, ADDON_VERSION, ADDON_VERSION_STR, MANIFEST_SCHEMA_VERSION
from .postprocess import build_ffmpeg_command, build_movie_job
from .device_control import apply_local_execution_device
from .resources import frame_chunk_specs, resource_profile, resolved_job_name, resolved_job_tags
from .selectors import preview_selector_matches, resolve_selector_diagnostics
from .variant_graph import (
    effective_variant,
    effective_variant_data,
    variant_inheritance_issues,
    variant_lookup as _variant_lookup_impl,
    variant_path as resolved_variant_path,
)
from .task_graph import task_graph_from_manifest
from .token_metadata import all_tokens, token_reference
from .elements_catalog import RENDER_ELEMENT_CATALOG
from .verification import build_output_verification_plan, effective_verification_scope, verification_scope_requires_passes


PASS_PROPERTY_NAMES = [
    "use_pass_combined",
    "use_pass_z",
    "use_pass_mist",
    "use_pass_position",
    "use_pass_normal",
    "use_pass_vector",
    "use_pass_uv",
    "use_pass_object_index",
    "use_pass_material_index",
    "use_pass_ambient_occlusion",
    "use_pass_shadow",
    "use_pass_emit",
    "use_pass_environment",
    "use_pass_diffuse_direct",
    "use_pass_diffuse_indirect",
    "use_pass_diffuse_color",
    "use_pass_glossy_direct",
    "use_pass_glossy_indirect",
    "use_pass_glossy_color",
    "use_pass_transmission_direct",
    "use_pass_transmission_indirect",
    "use_pass_transmission_color",
    "use_pass_subsurface_direct",
    "use_pass_subsurface_indirect",
    "use_pass_subsurface_color",
    "use_pass_volume_direct",
    "use_pass_volume_indirect",
    "use_pass_transparent",
    "use_pass_cryptomatte_object",
    "use_pass_cryptomatte_material",
    "use_pass_cryptomatte_asset",
]
PASS_BUNDLE_MAP = {
    "NONE": [],
    "ESSENTIAL": [
        "use_pass_combined",
        "use_pass_z",
        "use_pass_normal",
        "use_pass_vector",
        "use_pass_ambient_occlusion",
    ],
    "COMPOSITE": [
        "use_pass_combined",
        "use_pass_z",
        "use_pass_position",
        "use_pass_normal",
        "use_pass_vector",
        "use_pass_ambient_occlusion",
        "use_pass_shadow",
        "use_pass_emit",
        "use_pass_environment",
        "use_pass_cryptomatte_object",
        "use_pass_cryptomatte_material",
    ],
    "LOOKDEV": [
        "use_pass_combined",
        "use_pass_z",
        "use_pass_position",
        "use_pass_normal",
        "use_pass_vector",
        "use_pass_ambient_occlusion",
        "use_pass_shadow",
        "use_pass_emit",
        "use_pass_environment",
        "use_pass_diffuse_direct",
        "use_pass_diffuse_indirect",
        "use_pass_diffuse_color",
        "use_pass_glossy_direct",
        "use_pass_glossy_indirect",
        "use_pass_glossy_color",
        "use_pass_transmission_direct",
        "use_pass_transmission_indirect",
        "use_pass_transmission_color",
        "use_pass_subsurface_direct",
        "use_pass_subsurface_indirect",
        "use_pass_subsurface_color",
        "use_pass_cryptomatte_object",
        "use_pass_cryptomatte_material",
        "use_pass_cryptomatte_asset",
    ],
    "LIGHTING": [
        "use_pass_combined",
        "use_pass_shadow",
        "use_pass_emit",
        "use_pass_environment",
        "use_pass_diffuse_direct",
        "use_pass_diffuse_indirect",
        "use_pass_glossy_direct",
        "use_pass_glossy_indirect",
        "use_pass_transmission_direct",
        "use_pass_transmission_indirect",
        "use_pass_volume_direct",
        "use_pass_volume_indirect",
    ],
    "CRYPTOMATTE": [
        "use_pass_combined",
        "use_pass_cryptomatte_object",
        "use_pass_cryptomatte_material",
        "use_pass_cryptomatte_asset",
        "use_pass_object_index",
        "use_pass_material_index",
        "use_pass_z",
        "use_pass_normal",
    ],
    "TECHNICAL": [
        "use_pass_combined",
        "use_pass_z",
        "use_pass_position",
        "use_pass_normal",
        "use_pass_vector",
        "use_pass_uv",
        "use_pass_object_index",
        "use_pass_material_index",
        "use_pass_shadow",
    ],
    "DATASET": [
        "use_pass_combined",
        "use_pass_z",
        "use_pass_position",
        "use_pass_normal",
        "use_pass_vector",
        "use_pass_uv",
        "use_pass_object_index",
        "use_pass_material_index",
        "use_pass_cryptomatte_object",
        "use_pass_cryptomatte_material",
        "use_pass_cryptomatte_asset",
    ],
}
RENDER_ELEMENT_PRESET_TO_BUNDLE = {
    "FROM_PASS_BUNDLE": None,
    "BEAUTY": None,
    "COMPOSITE": "COMPOSITE",
    "LOOKDEV": "LOOKDEV",
    "LIGHTING": "LIGHTING",
    "CRYPTO_ID": "CRYPTOMATTE",
    "TECHNICAL": "TECHNICAL",
    "DATASET": "DATASET",
}
RENDER_ELEMENT_SOCKET_TOKENS = {
    "BEAUTY": {"image", "combined", "alpha"},
    "ESSENTIAL": {"image", "combined", "alpha", "depth", "z", "normal", "vector", "ambientocclusion", "ao"},
    "COMPOSITE": {"image", "combined", "alpha", "depth", "z", "position", "normal", "vector", "ambientocclusion", "ao", "shadow", "emit", "emission", "environment", "env", "cryptoobject", "cryptomaterial"},
    "LOOKDEV": {"image", "combined", "alpha", "depth", "z", "position", "normal", "vector", "ambientocclusion", "ao", "shadow", "emit", "emission", "environment", "env", "diffusedirect", "diffdir", "diffuseindirect", "diffind", "diffusecolor", "diffcol", "glossydirect", "glossdir", "glossyindirect", "glossind", "glossycolor", "glosscol", "transmissiondirect", "transdir", "transmissionindirect", "transind", "transmissioncolor", "transcol", "subsurfacedirect", "subsurfacedir", "subsurfaceindirect", "subsurfaceind", "subsurfacecolor", "subsurfacecol", "cryptoobject", "cryptomaterial", "cryptoasset"},
    "LIGHTING": {"image", "combined", "alpha", "shadow", "emit", "emission", "environment", "env", "diffusedirect", "diffdir", "diffuseindirect", "diffind", "glossydirect", "glossdir", "glossyindirect", "glossind", "transmissiondirect", "transdir", "transmissionindirect", "transind", "volumedirect", "volumedir", "volumeindirect", "volumeind"},
    "CRYPTOMATTE": {"image", "combined", "alpha", "cryptoobject", "cryptomaterial", "cryptoasset", "objectindex", "materialindex", "indexob", "indexma", "depth", "z", "normal"},
    "TECHNICAL": {"image", "combined", "alpha", "depth", "z", "position", "normal", "vector", "uv", "objectindex", "materialindex", "indexob", "indexma", "shadow"},
    "DATASET": {"image", "combined", "alpha", "depth", "z", "position", "normal", "vector", "uv", "objectindex", "materialindex", "indexob", "indexma", "cryptoobject", "cryptomaterial", "cryptoasset"},
}
RENDER_ELEMENT_NAME_MAP = {
    "image": "Beauty",
    "combined": "Beauty",
    "alpha": "Alpha",
    "depth": "ZDepth",
    "z": "ZDepth",
    "mist": "Mist",
    "position": "WorldPosition",
    "normal": "Normal",
    "vector": "Velocity",
    "uv": "UV",
    "objectindex": "ObjectID",
    "indexob": "ObjectID",
    "materialindex": "MaterialID",
    "indexma": "MaterialID",
    "ambientocclusion": "AmbientOcclusion",
    "ao": "AmbientOcclusion",
    "shadow": "Shadow",
    "emit": "SelfIllumination",
    "emission": "SelfIllumination",
    "environment": "Background",
    "env": "Background",
    "diffusedirect": "DiffuseLighting",
    "diffdir": "DiffuseLighting",
    "diffuseindirect": "GlobalIllumination",
    "diffind": "GlobalIllumination",
    "diffusecolor": "DiffuseFilter",
    "diffcol": "DiffuseFilter",
    "glossydirect": "SpecularLighting",
    "glossdir": "SpecularLighting",
    "glossyindirect": "Reflection",
    "glossind": "Reflection",
    "glossycolor": "SpecularColor",
    "glosscol": "SpecularColor",
    "transmissiondirect": "RefractionLighting",
    "transdir": "RefractionLighting",
    "transmissionindirect": "Refraction",
    "transind": "Refraction",
    "transmissioncolor": "RefractionFilter",
    "transcol": "RefractionFilter",
    "subsurfacedirect": "SSSDirect",
    "subsurfacedir": "SSSDirect",
    "subsurfaceindirect": "SSSIndirect",
    "subsurfaceind": "SSSIndirect",
    "subsurfacecolor": "SSSColor",
    "subsurfacecol": "SSSColor",
    "volumedirect": "VolumeLighting",
    "volumedir": "VolumeLighting",
    "volumeindirect": "VolumeIndirect",
    "volumeind": "VolumeIndirect",
    "transparent": "Transparency",
}


def render_elements_enabled(settings) -> bool:
    return bool(settings is not None and getattr(settings, "render_elements_enabled", False))


def _legacy_render_elements_effective_bundle(settings, preset: str | None = None) -> str:
    fallback = str(getattr(settings, "pass_bundle", "ESSENTIAL") or "ESSENTIAL") if settings is not None else "ESSENTIAL"
    token = str(preset or getattr(settings, "render_elements_preset", "FROM_PASS_BUNDLE") or "FROM_PASS_BUNDLE").upper()
    mapped = RENDER_ELEMENT_PRESET_TO_BUNDLE.get(token, fallback)
    if mapped is None:
        return fallback if token == "FROM_PASS_BUNDLE" else "BEAUTY"
    return str(mapped or fallback)


def pass_output_folder_name(settings) -> str:
    return "render_elements" if render_elements_enabled(settings) else "passes"


def render_elements_image_format(settings) -> str:
    output_mode = str(getattr(settings, "render_elements_output_mode", "FILES") or "FILES").upper() if settings is not None else "FILES"
    return "OPEN_EXR_MULTILAYER" if output_mode == "MULTILAYER" else "OPEN_EXR"


def _render_element_catalog_item_ids_from_tokens(tokens: set[str]) -> List[str]:
    item_ids: List[str] = []
    for item in RENDER_ELEMENT_CATALOG:
        aliases = {normalized_render_element_socket_token(token) for token in item.get("socket_tokens", set())}
        if aliases.intersection(tokens):
            item_ids.append(str(item.get("id", "")))
    return item_ids


def render_element_item_ids_for_preset(settings, preset: str | None = None) -> List[str]:
    token = str(preset or getattr(settings, "render_elements_preset", "FROM_PASS_BUNDLE") or "FROM_PASS_BUNDLE").upper()
    if token == "FROM_PASS_BUNDLE":
        effective_bundle = _legacy_render_elements_effective_bundle(settings, preset=token)
        token = "BEAUTY" if effective_bundle == "BEAUTY" else effective_bundle
    allowed = {normalized_render_element_socket_token(name) for name in RENDER_ELEMENT_SOCKET_TOKENS.get(token, set())}
    return _render_element_catalog_item_ids_from_tokens(allowed)


def normalize_render_element_item_ids(element_ids: Sequence[str]) -> List[str]:
    aliases: Dict[str, str] = {}
    ordered_ids: List[str] = []
    for item in RENDER_ELEMENT_CATALOG:
        item_id = str(item.get("id", "") or "").upper()
        if not item_id:
            continue
        ordered_ids.append(item_id)
        alias_values = {
            item_id,
            str(item.get("prop", "") or "").upper(),
            safe_name(str(item.get("label_en", "") or "")).upper(),
            safe_name(str(item.get("label_ja", "") or "")).upper(),
            safe_name(_render_element_item_display_name(item)).upper(),
        }
        for token in item.get("socket_tokens", set()) or set():
            alias_values.add(normalized_render_element_socket_token(str(token or "")).upper())
            alias_values.add(safe_name(str(token or "")).upper())
        for alias in alias_values:
            if alias:
                aliases[alias] = item_id
    normalized: List[str] = []
    seen = set()
    for raw_value in (element_ids or []):
        token = str(raw_value or "").strip()
        if not token:
            continue
        normalized_token = aliases.get(token.upper()) or aliases.get(safe_name(token).upper())
        if not normalized_token or normalized_token in seen:
            continue
        seen.add(normalized_token)
        normalized.append(normalized_token)
    return [item_id for item_id in ordered_ids if item_id in seen]


def set_render_element_item_ids(settings, element_ids: Sequence[str]) -> List[str]:
    wanted = set(normalize_render_element_item_ids(element_ids))
    applied: List[str] = []
    for item in RENDER_ELEMENT_CATALOG:
        item_id = str(item.get("id", "") or "").upper()
        enabled = item_id in wanted
        try:
            setattr(settings, str(item.get("prop", "")), bool(enabled))
        except Exception:
            continue
        if enabled:
            applied.append(str(item.get("id", "")))
    try:
        settings.render_elements_items_initialized = True
    except Exception:
        pass
    return applied


def ensure_render_element_item_defaults(settings) -> List[str]:
    if settings is None:
        return []
    if bool(getattr(settings, "render_elements_items_initialized", False)):
        return configured_render_element_ids(settings)
    preset_token = str(getattr(settings, "render_elements_preset", "FROM_PASS_BUNDLE") or "FROM_PASS_BUNDLE")
    item_ids = render_element_item_ids_for_preset(settings, preset=preset_token)
    set_render_element_item_ids(settings, item_ids)
    return configured_render_element_ids(settings)


def configured_render_element_ids(settings) -> List[str]:
    if settings is None:
        return []
    if not bool(getattr(settings, "render_elements_items_initialized", False)):
        return render_element_item_ids_for_preset(settings, preset=str(getattr(settings, "render_elements_preset", "FROM_PASS_BUNDLE") or "FROM_PASS_BUNDLE"))
    selected: List[str] = []
    for item in RENDER_ELEMENT_CATALOG:
        prop_name = str(item.get("prop", ""))
        if prop_name and bool(getattr(settings, prop_name, False)):
            selected.append(str(item.get("id", "")))
    return selected


def effective_render_element_ids(settings) -> List[str]:
    selected = configured_render_element_ids(settings)
    return selected if selected else ["BEAUTY"]


def render_elements_effective_bundle(settings, preset: str | None = None) -> str:
    if preset is not None:
        return _legacy_render_elements_effective_bundle(settings, preset=preset)

    current_ids = set(effective_render_element_ids(settings))
    beauty_ids = set(render_element_item_ids_for_preset(settings, preset="BEAUTY"))
    if current_ids == {"BEAUTY"} or current_ids == beauty_ids:
        return "BEAUTY"

    legacy_from_pass_bundle_ids = set(render_element_item_ids_for_preset(settings, preset="FROM_PASS_BUNDLE"))
    if current_ids == legacy_from_pass_bundle_ids:
        return _legacy_render_elements_effective_bundle(settings, preset="FROM_PASS_BUNDLE")

    for preset_token in ("COMPOSITE", "LOOKDEV", "LIGHTING", "CRYPTO_ID", "TECHNICAL", "DATASET"):
        if current_ids == set(render_element_item_ids_for_preset(settings, preset=preset_token)):
            return preset_token
    return "CUSTOM"


def render_elements_pass_properties(settings, preset: str | None = None) -> set:
    selected_ids = (render_element_item_ids_for_preset(settings, preset=preset) if preset is not None else effective_render_element_ids(settings))
    enabled_props = set()
    for item in RENDER_ELEMENT_CATALOG:
        if str(item.get("id", "")) not in set(selected_ids):
            continue
        enabled_props.update(set(item.get("pass_props", set()) or set()))
    return {prop_name for prop_name in enabled_props if prop_name in PASS_PROPERTY_NAMES}


def apply_render_elements_preset(scene, settings, target_layers: Optional[Sequence] = None) -> str:
    layers = pass_bundle_target_layers(scene, target_layers)
    enabled_props = render_elements_pass_properties(settings)
    for layer_item in layers:
        for prop_name in PASS_PROPERTY_NAMES:
            if hasattr(layer_item, prop_name):
                safe_set_attr(layer_item, prop_name, prop_name in enabled_props)
    return render_elements_effective_bundle(settings)


def normalized_render_element_socket_token(value: str) -> str:
    return safe_name(str(value or "")).lower().replace("_", "")


def _socket_token_matches(token: str, candidate: str) -> bool:
    if token == candidate:
        return True
    if candidate in {"cryptoobject", "cryptomaterial", "cryptoasset"}:
        return token.startswith(candidate)
    return False


def render_element_socket_allowed(socket_name: str, settings, preset: str | None = None) -> bool:
    token = normalized_render_element_socket_token(socket_name)
    if not token:
        return False
    if token in {"noisyimage", "denoisingnormal", "denoisingalbedo", "denoisingdepth"} or token.startswith("denoising"):
        return False
    selected_ids = (render_element_item_ids_for_preset(settings, preset=preset) if preset is not None else effective_render_element_ids(settings))
    allowed = set()
    for item in RENDER_ELEMENT_CATALOG:
        if str(item.get("id", "")) not in set(selected_ids):
            continue
        allowed.update({normalized_render_element_socket_token(name) for name in item.get("socket_tokens", set())})
    if not allowed:
        allowed = {"image", "combined"}
    return any(_socket_token_matches(token, candidate) for candidate in allowed)


def render_element_display_name(socket_name: str) -> str:
    token = normalized_render_element_socket_token(socket_name)
    if token.startswith("cryptoobject"):
        return "CryptoObject" + token[len("cryptoobject"):].upper()
    if token.startswith("cryptomaterial"):
        return "CryptoMaterial" + token[len("cryptomaterial"):].upper()
    if token.startswith("cryptoasset"):
        return "CryptoAsset" + token[len("cryptoasset"):].upper()
    mapped = RENDER_ELEMENT_NAME_MAP.get(token)
    if mapped:
        return mapped
    raw_value = str(socket_name or "Element").strip()
    if not raw_value:
        raw_value = "Element"
    return safe_name(raw_value)


def _render_element_item_display_name(item: dict) -> str:
    for token in sorted(item.get("socket_tokens", set())):
        display_name = render_element_display_name(token)
        if display_name:
            return display_name
    return safe_name(str(item.get("label_en", item.get("id", "Element")) or "Element"))


def render_elements_preview_names(settings, preset: str | None = None) -> List[str]:
    item_ids = (render_element_item_ids_for_preset(settings, preset=preset) if preset is not None else effective_render_element_ids(settings))
    names: List[str] = []
    seen = set()
    wanted = set(item_ids)
    for item in RENDER_ELEMENT_CATALOG:
        if str(item.get("id", "")) not in wanted:
            continue
        name = _render_element_item_display_name(item)
        if name in seen:
            continue
        seen.add(name)
        names.append(name)
    return names


AVAILABLE_OUTPUT_TOKENS = tuple(all_tokens())
UNRESOLVED_TOKEN_RE = re.compile(r"\{([^{}]+)\}")



def available_cameras(context, settings) -> List:
    scene = context.scene
    if getattr(settings, "selected_cameras_only", False):
        source = camera_selection(context)
    else:
        source = [obj for obj in scene.objects if getattr(obj, "type", "") == "CAMERA"]
    if getattr(settings, "renderable_cameras_only", True):
        source = [cam for cam in source if not getattr(cam, "hide_render", False)]
    if not source and scene.camera is not None:
        source = [scene.camera]
    unique = []
    seen = set()
    for cam in sorted(source, key=lambda obj: obj.name.lower()):
        if cam.name not in seen:
            seen.add(cam.name)
            unique.append(cam)
    return unique



def available_view_layers(context, settings) -> List:
    scene = context.scene
    if getattr(settings, "view_layer_mode", "ACTIVE") == "ACTIVE":
        current = getattr(context, "view_layer", None)
        if current is not None:
            return [current]
        if scene.view_layers:
            return [scene.view_layers[0]]
        return []
    return list(scene.view_layers)



def frame_values(scene, settings, variant=None) -> List[int]:
    if variant is not None and getattr(variant, "use_custom_frames", False):
        start = min(int(variant.frame_start), int(variant.frame_end))
        end = max(int(variant.frame_start), int(variant.frame_end))
        return list(range(start, end + 1))

    mode = getattr(settings, "frame_mode", "CURRENT")
    if mode == "CURRENT":
        return [int(scene.frame_current)]
    if mode == "SCENE":
        start = min(int(scene.frame_start), int(scene.frame_end))
        end = max(int(scene.frame_start), int(scene.frame_end))
        return list(range(start, end + 1))
    start = min(int(settings.custom_frame_start), int(settings.custom_frame_end))
    end = max(int(settings.custom_frame_start), int(settings.custom_frame_end))
    return list(range(start, end + 1))



def pass_bundle_target_layers(scene, target_layers: Optional[Sequence]) -> List:
    if target_layers:
        return [layer for layer in target_layers if layer is not None]
    return list(scene.view_layers)



def apply_pass_bundle(scene, bundle: str, target_layers: Optional[Sequence] = None) -> None:
    layers = pass_bundle_target_layers(scene, target_layers)
    enabled_props = set(PASS_BUNDLE_MAP.get(bundle, []))
    for layer_item in layers:
        for prop_name in PASS_PROPERTY_NAMES:
            if hasattr(layer_item, prop_name):
                safe_set_attr(layer_item, prop_name, prop_name in enabled_props)



def bool_from_override(base_value: bool, mode: str) -> bool:
    if mode == "ON":
        return True
    if mode == "OFF":
        return False
    return bool(base_value)



def apply_variant_scene_overrides(scene, view_layer_obj, variant, logger=None) -> List[str]:
    if variant is None or view_layer_obj is None:
        return []

    def emit(level: str, message: str) -> None:
        if logger is not None:
            logger(level, message)

    material_mode = str(getattr(variant, "material_override_mode", "SCENE") or "SCENE")
    if material_mode == "CLEAR":
        safe_set_attr(view_layer_obj, "material_override", None)
    elif material_mode == "OVERRIDE":
        material_name = str(getattr(variant, "material_override_name", "") or "")
        if material_name:
            material = material_by_name(material_name)
            if material is None:
                emit("WARNING", f"Variant material override not found: {material_name}")
            else:
                safe_set_attr(view_layer_obj, "material_override", material)
        else:
            safe_set_attr(view_layer_obj, "material_override", None)

    world_mode = str(getattr(variant, "world_override_mode", "SCENE") or "SCENE")
    if world_mode == "CLEAR":
        safe_set_attr(scene, "world", None)
    elif world_mode == "OVERRIDE":
        world_name = str(getattr(variant, "world_override_name", "") or "")
        if world_name:
            world = world_by_name(world_name)
            if world is None:
                emit("WARNING", f"Variant world not found: {world_name}")
            else:
                safe_set_attr(scene, "world", world)
        else:
            safe_set_attr(scene, "world", None)

    collection_mode = str(getattr(variant, "collection_override_mode", "SCENE") or "SCENE")
    missing: List[str] = []
    if collection_mode != "SCENE":
        missing = apply_layer_collection_overrides(
            view_layer_obj,
            parse_name_list(getattr(variant, "include_collections", "")),
            parse_name_list(getattr(variant, "exclude_collections", "")),
            parse_name_list(getattr(variant, "holdout_collections", "")),
            parse_name_list(getattr(variant, "indirect_only_collections", "")),
            reset_exclude=(collection_mode == "REPLACE"),
            reset_holdout=(collection_mode == "REPLACE"),
            reset_indirect=(collection_mode == "REPLACE"),
        )

    object_visibility_mode = str(getattr(variant, "object_visibility_override_mode", "SCENE") or "SCENE")
    if object_visibility_mode != "SCENE":
        object_missing = apply_object_render_overrides(
            scene,
            parse_name_list(getattr(variant, "show_objects", "")),
            parse_name_list(getattr(variant, "hide_objects", "")),
            reset=(object_visibility_mode == "REPLACE"),
        )
        missing.extend(object_missing)

    representation_mode = str(getattr(variant, "representation_mode", "SCENE") or "SCENE")
    if representation_mode != "SCENE":
        proxy_selectors = parse_name_list(getattr(variant, "proxy_collections", ""))
        render_selectors = parse_name_list(getattr(variant, "render_collections", ""))
        representation_missing: List[str] = []
        if representation_mode == "SWAP":
            representation_missing = apply_layer_collection_overrides(
                view_layer_obj,
                render_selectors,
                proxy_selectors,
                [],
                [],
                reset_exclude=False,
                reset_holdout=False,
                reset_indirect=False,
            )
        elif representation_mode == "PROXY_ONLY":
            representation_missing = apply_layer_collection_overrides(
                view_layer_obj,
                proxy_selectors,
                render_selectors,
                [],
                [],
                reset_exclude=False,
                reset_holdout=False,
                reset_indirect=False,
            )
        elif representation_mode == "RENDER_ONLY":
            representation_missing = apply_layer_collection_overrides(
                view_layer_obj,
                render_selectors,
                proxy_selectors,
                [],
                [],
                reset_exclude=False,
                reset_holdout=False,
                reset_indirect=False,
            )
        missing.extend(representation_missing)

    film_transparent_mode = str(getattr(variant, "film_transparent_mode", "SCENE") or "SCENE")
    if film_transparent_mode != "SCENE":
        safe_set_attr(getattr(scene, "render", None), "film_transparent", film_transparent_mode == "ON")

    color_management_mode = str(getattr(variant, "color_management_mode", "SCENE") or "SCENE")
    if color_management_mode == "OVERRIDE":
        view_settings = getattr(scene, "view_settings", None)
        if view_settings is not None:
            view_transform = str(getattr(variant, "view_transform_override", "") or "").strip()
            look = str(getattr(variant, "look_override", "") or "").strip()
            if view_transform:
                safe_set_attr(view_settings, "view_transform", view_transform)
            if look:
                safe_set_attr(view_settings, "look", look)
            if bool(getattr(variant, "use_exposure_override", False)):
                safe_set_attr(view_settings, "exposure", float(getattr(variant, "exposure_override", 0.0) or 0.0))
            if bool(getattr(variant, "use_gamma_override", False)):
                safe_set_attr(view_settings, "gamma", float(getattr(variant, "gamma_override", 1.0) or 1.0))

    return missing


def frame_range_string(batch: Dict[str, object]) -> str:
    mode = str(batch.get("mode", "CURRENT"))
    if mode == "CURRENT":
        frame = batch.get("frame_current")
        if frame is None:
            frame = batch.get("start", 1)
        return str(int(frame))
    start = batch.get("start", 1)
    end = batch.get("end", start if start is not None else 1)
    start_i = int(start)
    end_i = int(end)
    return str(start_i) if start_i == end_i else f"{start_i}..{end_i}"


def build_background_command_preview(blend_file: str, engine_identifier: str, output_root: str, frame_range: str) -> str:
    blend_token = blend_file or "<save .blend first>"
    root_token = output_root or "<output root>"
    engine_token = engine_identifier or "CYCLES"
    frames_token = frame_range or "1"
    return f'blender -b "{blend_token}" -E {engine_token} --render-output "{root_token}" --render-frame {frames_token}'



def resolved_profile(settings, scene, variant=None) -> Dict[str, object]:
    engine_mode = getattr(settings, "engine_mode", "KEEP")
    quality_mode = getattr(settings, "quality_mode", "PREVIEW")
    resolution_percentage = int(getattr(settings, "resolution_percentage", 100))
    sample_multiplier = float(getattr(settings, "sample_multiplier", 1.0))
    use_denoise = bool(getattr(settings, "use_denoise", True))
    use_adaptive_sampling = bool(getattr(settings, "use_adaptive_sampling", True))
    use_motion_blur = bool(getattr(settings, "use_motion_blur", False))
    use_freestyle = bool(getattr(settings, "use_freestyle", False))
    pass_bundle = getattr(settings, "pass_bundle", "ESSENTIAL")
    image_format = getattr(settings, "image_format", "PNG")
    if render_elements_enabled(settings):
        image_format = render_elements_image_format(settings)
    stamp_note = getattr(settings, "stamp_note", "")
    base_resolution_x = max(1, int(getattr(scene.render, "resolution_x", 1920) or 1920))
    base_resolution_y = max(1, int(getattr(scene.render, "resolution_y", 1080) or 1080))

    if variant is not None:
        if getattr(variant, "engine_mode", "SCENE") != "SCENE":
            engine_mode = variant.engine_mode
        if getattr(variant, "quality_mode", "SCENE") != "SCENE":
            quality_mode = variant.quality_mode
        if int(getattr(variant, "resolution_percentage_override", 0) or 0) > 0:
            resolution_percentage = int(variant.resolution_percentage_override)
        resolution_x_override = int(getattr(variant, "resolution_x_override", 0) or 0)
        resolution_y_override = int(getattr(variant, "resolution_y_override", 0) or 0)
        if resolution_x_override > 0 and resolution_y_override > 0:
            base_resolution_x = resolution_x_override
            base_resolution_y = resolution_y_override
        elif resolution_x_override > 0:
            aspect = (float(base_resolution_y) / float(base_resolution_x)) if base_resolution_x else 1.0
            base_resolution_x = resolution_x_override
            base_resolution_y = max(1, int(round(float(base_resolution_x) * aspect)))
        elif resolution_y_override > 0:
            aspect = (float(base_resolution_x) / float(base_resolution_y)) if base_resolution_y else 1.0
            base_resolution_y = resolution_y_override
            base_resolution_x = max(1, int(round(float(base_resolution_y) * aspect)))
        if float(getattr(variant, "sample_multiplier_override", 0.0) or 0.0) > 0.0:
            sample_multiplier = float(variant.sample_multiplier_override)
        use_denoise = bool_from_override(use_denoise, getattr(variant, "denoise_mode", "SCENE"))
        use_adaptive_sampling = bool_from_override(use_adaptive_sampling, getattr(variant, "adaptive_sampling_mode", "SCENE"))
        use_motion_blur = bool_from_override(use_motion_blur, getattr(variant, "motion_blur_mode", "SCENE"))
        use_freestyle = bool_from_override(use_freestyle, getattr(variant, "freestyle_mode", "SCENE"))
        if getattr(variant, "pass_bundle", "SCENE") != "SCENE":
            pass_bundle = variant.pass_bundle
        if getattr(variant, "image_format_override", "SCENE") != "SCENE":
            image_format = variant.image_format_override
        if getattr(variant, "stamp_note_override", ""):
            stamp_note = variant.stamp_note_override

    requested_identifier = resolve_engine_identifier(scene, engine_mode)
    actual_identifier = requested_identifier or getattr(scene.render, "engine", "CYCLES")
    resolved_resolution_x = max(1, int(round(float(base_resolution_x) * (float(resolution_percentage) / 100.0))))
    resolved_resolution_y = max(1, int(round(float(base_resolution_y) * (float(resolution_percentage) / 100.0))))
    return {
        "engine_mode": engine_mode,
        "quality_mode": quality_mode,
        "resolution_percentage": resolution_percentage,
        "base_resolution_x": base_resolution_x,
        "base_resolution_y": base_resolution_y,
        "resolved_resolution_x": resolved_resolution_x,
        "resolved_resolution_y": resolved_resolution_y,
        "sample_multiplier": sample_multiplier,
        "use_denoise": use_denoise,
        "use_adaptive_sampling": use_adaptive_sampling,
        "use_motion_blur": use_motion_blur,
        "use_freestyle": use_freestyle,
        "pass_bundle": pass_bundle,
        "image_format": image_format,
        "stamp_note": stamp_note,
        "film_transparent_mode": getattr(variant, "film_transparent_mode", "SCENE") if variant is not None else "SCENE",
        "color_management_mode": getattr(variant, "color_management_mode", "SCENE") if variant is not None else "SCENE",
        "view_transform_override": getattr(variant, "view_transform_override", "") if variant is not None else "",
        "look_override": getattr(variant, "look_override", "") if variant is not None else "",
        "use_exposure_override": bool(getattr(variant, "use_exposure_override", False)) if variant is not None else False,
        "exposure_override": float(getattr(variant, "exposure_override", 0.0) or 0.0) if variant is not None else 0.0,
        "use_gamma_override": bool(getattr(variant, "use_gamma_override", False)) if variant is not None else False,
        "gamma_override": float(getattr(variant, "gamma_override", 1.0) or 1.0) if variant is not None else 1.0,
        "requested_engine_identifier": requested_identifier,
        "actual_engine_identifier": actual_identifier,
        "actual_engine_mode": engine_mode_from_identifier(actual_identifier),
    }



def output_config(settings, variant=None) -> Dict[str, object]:
    root = getattr(settings, "output_root", default_output_root(create=True))
    dir_pattern = getattr(settings, "output_dir_pattern", "{scene}")
    file_pattern = getattr(settings, "output_file_pattern", "{scene}_{frame}")
    image_format = getattr(settings, "image_format", "PNG")
    if variant is not None:
        if getattr(variant, "output_root_override", ""):
            root = variant.output_root_override
        if getattr(variant, "output_dir_pattern_override", ""):
            dir_pattern = variant.output_dir_pattern_override
        if getattr(variant, "output_file_pattern_override", ""):
            file_pattern = variant.output_file_pattern_override
        if getattr(variant, "image_format_override", "SCENE") != "SCENE":
            image_format = variant.image_format_override
    if render_elements_enabled(settings):
        image_format = render_elements_image_format(settings)
    return {
        "root": root,
        "dir_pattern": dir_pattern,
        "file_pattern": file_pattern,
        "image_format": image_format,
    }



def path_tokens(scene, settings, item, frame_value: int, profile: Dict[str, object], variant=None, frame_range: Optional[Sequence[int]] = None) -> Dict[str, str]:
    now = now_local()
    blend_path = bpy.data.filepath or ""
    blend_name = bpy.path.display_name_from_filepath(blend_path) if blend_path else "untitled"
    blend_dir_name = os.path.basename(os.path.dirname(blend_path)) if blend_path else "unsaved"
    if not blend_dir_name:
        blend_dir_name = "unsaved"

    scene_camera_name = getattr(getattr(scene, "camera", None), "name", "") or "no_camera"
    camera_name = item.get("camera_name") or scene_camera_name
    view_layer_name = item.get("view_layer_name") or (scene.view_layers[0].name if scene.view_layers else "view_layer")
    view_layer_obj = view_layer(scene, view_layer_name) if view_layer_name else None
    variant_name = item.get("variant_name") or (variant.name if variant is not None else "base")
    parent_variant_name = str(getattr(variant, "parent_name", "") or "") if variant is not None else ""
    variant_path_token = str(getattr(variant, "variant_path", "") or "") if variant is not None else ""
    if not variant_path_token:
        variant_path_token = safe_name(variant_name or "base")

    variant_chain_names = [str(name) for name in (getattr(variant, "variant_chain", []) or []) if str(name)] if variant is not None else []
    if not variant_chain_names and variant_name:
        variant_chain_names = [str(variant_name)]
    safe_variant_chain = [safe_name(name) for name in variant_chain_names if name]
    parent_variant_path = "/".join(safe_variant_chain[:-1]) if len(safe_variant_chain) > 1 else "root"
    variant_root = safe_variant_chain[0] if safe_variant_chain else safe_name(variant_name or "base")
    variant_chain_flat = "__".join(safe_variant_chain) if safe_variant_chain else safe_name(variant_name or "base")

    quality_mode = str(profile.get("quality_mode", getattr(settings, "quality_mode", "PREVIEW"))).lower()
    engine_identifier = str(profile.get("actual_engine_identifier", scene.render.engine))

    image_format = str(output_config(settings, variant=variant).get("image_format", getattr(scene.render.image_settings, "file_format", "PNG")) or "PNG")
    extension = image_format_extension(image_format)
    resolution_percentage = max(1, int(profile.get("resolution_percentage", getattr(scene.render, "resolution_percentage", 100)) or 100))
    resolution_x = max(1, int(profile.get("resolved_resolution_x", getattr(scene.render, "resolution_x", 0)) or getattr(scene.render, "resolution_x", 0) or 1))
    resolution_y = max(1, int(profile.get("resolved_resolution_y", getattr(scene.render, "resolution_y", 0)) or getattr(scene.render, "resolution_y", 0) or 1))
    base_resolution_x = max(1, int(profile.get("base_resolution_x", getattr(scene.render, "resolution_x", 0)) or getattr(scene.render, "resolution_x", 0) or 1))
    base_resolution_y = max(1, int(profile.get("base_resolution_y", getattr(scene.render, "resolution_y", 0)) or getattr(scene.render, "resolution_y", 0) or 1))
    fps_base = float(getattr(scene.render, "fps_base", 1.0) or 1.0)
    fps_value = float(getattr(scene.render, "fps", 24) or 24) / (fps_base if fps_base else 1.0)
    fps_string = f"{fps_value:.3f}".rstrip("0").rstrip(".")

    frame_values_list = [int(value) for value in (frame_range or [])] or [int(frame_value)]
    frame_start = min(frame_values_list)
    frame_end = max(frame_values_list)
    frame_padding = max(1, int(getattr(settings, "sequence_padding", 4)))
    frame_range_token = str(frame_start).zfill(frame_padding) if frame_start == frame_end else f"{str(frame_start).zfill(frame_padding)}-{str(frame_end).zfill(frame_padding)}"

    label_value = safe_name(item.get("label") or variant_name or f"{camera_name}_{view_layer_name}")
    variant_depth = 0
    if variant is not None:
        try:
            variant_depth = int(getattr(variant, "inheritance_depth", 0) or 0)
        except Exception:
            variant_depth = 0

    job_name = resolved_job_name(settings, variant=variant)
    job_tags = resolved_job_tags(settings, variant=variant)
    job_tags_token = "_".join(safe_name(tag) for tag in job_tags if str(tag).strip()) or "none"
    source_mode_value = safe_name(str(item.get("source_mode", "PAIR") or "PAIR").lower())
    pass_bundle_token = safe_name(str(profile.get("pass_bundle", getattr(settings, "pass_bundle", "ESSENTIAL")) or "ESSENTIAL"))
    resolved_execution_profile = resource_profile(settings, frame_count=max(1, len(frame_values_list)), variant=variant)
    device_token = safe_name(str(resolved_execution_profile.get("device_mode", getattr(settings, "execution_device_mode", "AUTO")) or "AUTO"))

    representation_mode = str(getattr(variant, "representation_mode", "SCENE") or "SCENE") if variant is not None else "SCENE"

    world_name = getattr(getattr(scene, "world", None), "name", "") or "none"
    world_mode = str(getattr(variant, "world_override_mode", "SCENE") or "SCENE") if variant is not None else "SCENE"
    if world_mode == "CLEAR":
        world_name = "none"
    elif world_mode == "OVERRIDE":
        world_name = str(getattr(variant, "world_override_name", "") or "") or "none"

    material_name = getattr(getattr(view_layer_obj, "material_override", None), "name", "") or "none"
    material_mode = str(getattr(variant, "material_override_mode", "SCENE") or "SCENE") if variant is not None else "SCENE"
    if material_mode == "CLEAR":
        material_name = "none"
    elif material_mode == "OVERRIDE":
        material_name = str(getattr(variant, "material_override_name", "") or "") or "none"

    view_settings = getattr(scene, "view_settings", None)
    view_transform = str(getattr(view_settings, "view_transform", "") or "") if view_settings is not None else ""
    look_name = str(getattr(view_settings, "look", "") or "") if view_settings is not None else ""
    if str(profile.get("color_management_mode", "SCENE") or "SCENE") == "OVERRIDE":
        view_transform = str(profile.get("view_transform_override", "") or view_transform)
        look_name = str(profile.get("look_override", "") or look_name)

    tokens = {
        "blend": safe_name(blend_name),
        "blend_file": safe_name(blend_name),
        "blend_dir": safe_name(blend_dir_name),
        "scene": safe_name(scene.name),
        "scene_camera": safe_name(scene_camera_name),
        "camera": safe_name(camera_name),
        "view_layer": safe_name(view_layer_name),
        "render_layer": safe_name(view_layer_name),
        "layer": safe_name(view_layer_name),
        "variant": safe_name(variant_name or "base"),
        "take": safe_name(variant_name or "base"),
        "parent_variant": safe_name(parent_variant_name or "root"),
        "parent_take": safe_name(parent_variant_name or "root"),
        "parent_variant_path": parent_variant_path,
        "variant_path": variant_path_token,
        "take_path": variant_path_token,
        "variant_root": variant_root,
        "variant_chain": variant_chain_flat,
        "variant_depth": str(max(0, variant_depth)),
        "engine": safe_name(engine_identifier),
        "renderer": safe_name(engine_identifier),
        "render_engine": safe_name(engine_identifier),
        "quality": safe_name(quality_mode),
        "pass_bundle": pass_bundle_token,
        "frame": str(int(frame_value)).zfill(frame_padding),
        "frame_start": str(int(frame_start)).zfill(frame_padding),
        "frame_end": str(int(frame_end)).zfill(frame_padding),
        "frame_count": str(max(1, len(frame_values_list))),
        "frame_range": frame_range_token,
        "frame_spec": frame_range_token,
        "fps": safe_name(fps_string or "24"),
        "resolution_x": str(max(1, resolution_x)),
        "resolution_y": str(max(1, resolution_y)),
        "base_resolution_x": str(max(1, base_resolution_x)),
        "base_resolution_y": str(max(1, base_resolution_y)),
        "representation": safe_name(representation_mode.lower()),
        "format": safe_name(image_format.lower()),
        "ext": safe_name(extension.lower()),
        "world": safe_name(world_name),
        "material": safe_name(material_name),
        "view_transform": safe_name(view_transform or "none"),
        "look": safe_name(look_name or "none"),
        "date": now.strftime("%Y-%m-%d"),
        "time": now.strftime("%H-%M-%S"),
        "datetime": now.strftime("%Y-%m-%d_%H-%M-%S"),
        "year": now.strftime("%Y"),
        "month": now.strftime("%m"),
        "day": now.strftime("%d"),
        "hour": now.strftime("%H"),
        "minute": now.strftime("%M"),
        "second": now.strftime("%S"),
        "job": safe_name(job_name),
        "shot": safe_name(job_name),
        "device": device_token,
        "job_tags": job_tags_token,
        "source_mode": source_mode_value,
        "label": label_value,
        "queue_label": label_value,
    }
    return tokens


def apply_tokens(pattern: str, tokens: Dict[str, str]) -> str:
    result = str(pattern or "")
    for key, value in tokens.items():
        result = result.replace("{" + key + "}", str(value))

    def sanitize_unresolved(match: re.Match[str]) -> str:
        safe_token = safe_name(match.group(1))
        return safe_token or "token"

    result = UNRESOLVED_TOKEN_RE.sub(sanitize_unresolved, result)
    result = result.replace("\\", "/")
    result = result.strip()
    return result



def normalize_output_filename(filename: str, ext: str, fallback: str) -> str:
    value = str(filename or "").replace("\\", "/").strip()
    while value.startswith("/"):
        value = value[1:]
    while value.startswith("./"):
        value = value[2:]
    if not value or value in {".", ".."}:
        value = fallback
    value = os.path.normpath(value).replace("\\", "/")
    if value in {"", "."}:
        value = fallback

    ext = str(ext or "").strip().lower().lstrip(".")
    if ext:
        suffix = f".{ext}"
        if value.lower().endswith(suffix):
            value = value[: -len(suffix)]
    value = value.rstrip(". ") or fallback

    basename = os.path.basename(value)
    if basename in {"", ".", ".."}:
        value = os.path.join(value, fallback).replace("\\", "/")
    return value


def file_pattern_extension_warnings(pattern: str) -> List[str]:
    warnings: List[str] = []
    raw = str(pattern or "").strip()
    lowered = raw.lower()
    if not raw:
        return warnings
    if "{ext}" in lowered:
        warnings.append("{ext}")
    for ext in sorted(set(IMAGE_FORMAT_EXTENSIONS.values())):
        if lowered.endswith(f".{ext}"):
            token = f".{ext}"
            if token not in warnings:
                warnings.append(token)
    return warnings


def effective_output_patterns(settings, dir_pattern: str, file_pattern: str, counts: Dict[str, int]) -> Tuple[str, str, List[str]]:
    injected: List[str] = []
    auto_unique = bool(getattr(settings, "auto_unique_tokens", True))
    if not auto_unique:
        return dir_pattern, file_pattern, injected

    def has_any_token(*token_names: str) -> bool:
        return any((token_name in dir_pattern or token_name in file_pattern) for token_name in token_names)

    required = []
    if counts.get("camera", 1) > 1 and not has_any_token("{camera}"):
        required.append("{camera}")
    if counts.get("view_layer", 1) > 1 and not has_any_token("{view_layer}", "{render_layer}", "{layer}"):
        required.append("{view_layer}")
    if counts.get("variant", 1) > 1 and not has_any_token("{variant}", "{take}"):
        required.append("{variant}")
    if counts.get("frame", 1) > 1 and not has_any_token("{frame}"):
        required.append("{frame}")

    if required:
        suffix = "_".join(required)
        file_pattern = f"{file_pattern}_{suffix}"
        injected.extend(required)
    return dir_pattern, file_pattern, injected


def variant_lookup(scene) -> Dict[str, object]:
    return _variant_lookup_impl(scene)



def build_pair_queue_blueprint(context, scene, settings) -> List[dict]:
    blueprint: List[dict] = []
    cameras = available_cameras(context, settings)
    layers = available_view_layers(context, settings)
    for cam in cameras:
        for layer_item in layers:
            blueprint.append(
                {
                    "enabled": True,
                    "source_mode": "PAIR",
                    "camera_name": cam.name,
                    "view_layer_name": layer_item.name,
                    "variant_name": "",
                    "label": f"{cam.name} | {layer_item.name}",
                }
            )
    return blueprint



def build_variant_queue_blueprint(scene) -> List[dict]:
    blueprint: List[dict] = []
    for variant in getattr(scene, "srr_variants", []):
        resolved_variant = effective_variant(scene, variant)
        if resolved_variant is None or not bool(getattr(resolved_variant, "enabled", True)):
            continue
        blueprint.append(
            {
                "enabled": True,
                "source_mode": "VARIANT",
                "camera_name": getattr(resolved_variant, "camera_name", ""),
                "view_layer_name": getattr(resolved_variant, "view_layer_name", ""),
                "variant_name": variant.name,
                "label": resolved_variant_path(scene, variant, separator=" / ") or variant.name,
            }
        )
    return blueprint



def queue_blueprint_from_collection(scene) -> List[dict]:
    blueprint: List[dict] = []
    for item in getattr(scene, "srr_queue", []):
        blueprint.append(
            {
                "enabled": bool(getattr(item, "enabled", True)),
                "source_mode": getattr(item, "source_mode", "PAIR"),
                "camera_name": getattr(item, "camera_name", ""),
                "view_layer_name": getattr(item, "view_layer_name", ""),
                "variant_name": getattr(item, "variant_name", ""),
                "label": getattr(item, "label", ""),
            }
        )
    return blueprint



def effective_queue_blueprint(context, scene, settings, enabled_only: bool = False) -> List[dict]:
    if len(getattr(scene, "srr_queue", [])) > 0:
        items = queue_blueprint_from_collection(scene)
    else:
        if getattr(settings, "queue_source_mode", "PAIRS") == "VARIANTS":
            items = build_variant_queue_blueprint(scene)
        else:
            items = build_pair_queue_blueprint(context, scene, settings)
    if enabled_only:
        items = [item for item in items if bool(item.get("enabled", True))]
    return items



def sync_queue(scene, blueprint: List[dict]) -> None:
    collection_clear(scene.srr_queue)
    for source in blueprint:
        item = scene.srr_queue.add()
        item.enabled = bool(source.get("enabled", True))
        item.source_mode = source.get("source_mode", "PAIR")
        item.camera_name = str(source.get("camera_name", ""))
        item.view_layer_name = str(source.get("view_layer_name", ""))
        item.variant_name = str(source.get("variant_name", ""))
        item.label = str(source.get("label", ""))



def queue_counts(scene, settings, items: Sequence[dict]) -> Dict[str, int]:
    camera_names = set()
    layer_names = set()
    variant_names = set()
    frame_values_set = set()
    fallback_layer_name = scene.view_layers[0].name if getattr(scene, "view_layers", None) else ""
    for item in items:
        source_mode = item.get("source_mode", "PAIR")
        variant = effective_variant(scene, item.get("variant_name", "")) if source_mode == "VARIANT" else None
        if source_mode == "VARIANT":
            camera_name = getattr(variant, "camera_name", "") or item.get("camera_name") or getattr(getattr(scene, "camera", None), "name", "")
            view_layer_name = getattr(variant, "view_layer_name", "") or item.get("view_layer_name") or fallback_layer_name
        else:
            camera_name = item.get("camera_name") or getattr(getattr(scene, "camera", None), "name", "")
            view_layer_name = item.get("view_layer_name") or fallback_layer_name
        if camera_name:
            camera_names.add(camera_name)
        if view_layer_name:
            layer_names.add(view_layer_name)
        if source_mode == "VARIANT" and item.get("variant_name"):
            variant_names.add(item["variant_name"])
        for frame in frame_values(scene, settings, variant=variant):
            frame_values_set.add(int(frame))
    return {
        "camera": max(1, len(camera_names)),
        "view_layer": max(1, len(layer_names)),
        "variant": max(1, len(variant_names)),
        "frame": max(1, len(frame_values_set)),
    }



def resolve_item_context(scene, settings, item: dict, context_view_layer_name: str = "") -> Dict[str, object]:
    source_mode = item.get("source_mode", "PAIR")
    variant = effective_variant(scene, item.get("variant_name", "")) if source_mode == "VARIANT" else None
    if source_mode == "VARIANT":
        camera_name = getattr(variant, "camera_name", "") or item.get("camera_name") or (scene.camera.name if scene.camera else "")
        view_layer_name = getattr(variant, "view_layer_name", "") or item.get("view_layer_name") or context_view_layer_name or (scene.view_layers[0].name if scene.view_layers else "")
    else:
        camera_name = item.get("camera_name") or (scene.camera.name if scene.camera else "")
        view_layer_name = item.get("view_layer_name") or context_view_layer_name or (scene.view_layers[0].name if scene.view_layers else "")
    profile = resolved_profile(settings, scene, variant=variant)
    return {
        "variant": variant,
        "camera_name": camera_name,
        "view_layer_name": view_layer_name,
        "profile": profile,
        "frames": frame_values(scene, settings, variant=variant),
        "source_mode": source_mode,
    }


def resolved_queue_item(scene, settings, item: dict, context_view_layer_name: str = "") -> Dict[str, object]:
    resolved = resolve_item_context(scene, settings, item, context_view_layer_name=context_view_layer_name)
    variant = resolved["variant"]
    camera_name = resolved["camera_name"]
    view_layer_name = resolved["view_layer_name"]
    raw_item = dict(item)
    raw_item["camera_name"] = camera_name
    raw_item["view_layer_name"] = view_layer_name
    label = raw_item.get("label") or getattr(variant, "name", "") or f"{camera_name} | {view_layer_name}"
    raw_item["label"] = label
    return {
        "item": raw_item,
        "label": label,
        **resolved,
    }



def resolve_output(scene, settings, item: dict, frame_value: int, counts: Dict[str, int], context_view_layer_name: str = "") -> Dict[str, object]:
    resolved = resolved_queue_item(scene, settings, item, context_view_layer_name=context_view_layer_name)
    variant = resolved["variant"]
    profile = resolved["profile"]
    resolved_item = resolved["item"]
    output = output_config(settings, variant=variant)
    root = abspath(str(output["root"] or default_output_root(create=True)))
    dir_pattern, file_pattern, injected = effective_output_patterns(settings, str(output["dir_pattern"]), str(output["file_pattern"]), counts)
    tokens = path_tokens(scene, settings, resolved_item, frame_value, profile, variant=variant, frame_range=resolved["frames"])
    subdir = apply_tokens(dir_pattern, tokens)
    ext = image_format_extension(str(output["image_format"] or getattr(settings, "image_format", "PNG")))
    fallback_name = apply_tokens("{scene}_{frame}", tokens) or "render"
    filename_raw = apply_tokens(file_pattern, tokens) or fallback_name
    filename = normalize_output_filename(filename_raw, ext, fallback_name)
    output_dir = os.path.normpath(os.path.join(root, subdir))
    full_stem = os.path.join(output_dir, filename)
    full_path = f"{full_stem}.{ext}" if ext else full_stem
    return {
        "item": resolved_item,
        "variant": variant,
        "profile": profile,
        "camera_name": resolved["camera_name"],
        "view_layer_name": resolved["view_layer_name"],
        "frame": int(frame_value),
        "tokens": tokens,
        "output_dir": output_dir,
        "full_stem": full_stem,
        "full_path": full_path,
        "extension": ext,
        "injected": injected,
        "label": resolved["label"] or tokens.get("variant") or f"{resolved['camera_name']} | {resolved['view_layer_name']}",
        "source_mode": resolved["source_mode"],
    }



def collect_output_targets(context, scene, settings, enabled_only: bool = False) -> List[dict]:
    items = effective_queue_blueprint(context, scene, settings, enabled_only=enabled_only)
    if not items:
        return []
    counts = queue_counts(scene, settings, items)
    context_view_layer_name = getattr(getattr(context, "view_layer", None), "name", "")
    targets: List[dict] = []
    for item in items:
        resolved = resolve_item_context(scene, settings, item, context_view_layer_name=context_view_layer_name)
        for frame_value in resolved["frames"]:
            targets.append(resolve_output(scene, settings, item, int(frame_value), counts, context_view_layer_name=context_view_layer_name))
    return targets



def preview_outputs_for_item(context, scene, settings, item: dict, limit: int = 8) -> List[dict]:
    source_item = dict(item or {})
    if not source_item:
        return []
    if not bool(source_item.get("enabled", True)):
        source_item["enabled"] = True

    queue_items = effective_queue_blueprint(context, scene, settings, enabled_only=True)
    has_match = False
    for queue_item in queue_items:
        same_source = str(queue_item.get("source_mode", "PAIR")) == str(source_item.get("source_mode", "PAIR"))
        if not same_source:
            continue
        if str(queue_item.get("source_mode", "PAIR")) == "VARIANT":
            if str(queue_item.get("variant_name", "")) == str(source_item.get("variant_name", "")):
                has_match = True
                break
            continue
        if (
            str(queue_item.get("camera_name", "")) == str(source_item.get("camera_name", ""))
            and str(queue_item.get("view_layer_name", "")) == str(source_item.get("view_layer_name", ""))
        ):
            has_match = True
            break
    if not has_match:
        queue_items = list(queue_items) + [source_item]

    counts = queue_counts(scene, settings, queue_items or [source_item])
    context_view_layer_name = getattr(getattr(context, "view_layer", None), "name", "")
    resolved = resolve_item_context(scene, settings, source_item, context_view_layer_name=context_view_layer_name)
    preview: List[dict] = []
    for frame_value in resolved["frames"][: max(1, int(limit))]:
        preview.append(resolve_output(scene, settings, source_item, int(frame_value), counts, context_view_layer_name=context_view_layer_name))
    return preview


def _collision_verification_scope(scene, settings) -> str:
    requested = str(getattr(settings, "verification_scope", "PRIMARY_AND_PASSES") or "PRIMARY_AND_PASSES")
    chosen_mode = effective_queue_compositing_mode(scene, str(getattr(settings, "queue_compositing_mode", "AUTO") or "AUTO"))
    return effective_verification_scope(requested, chosen_mode)



def _movie_collision_targets(context, scene, settings, enabled_only: bool = False) -> List[dict]:
    if not bool(getattr(settings, "enable_movie_encode", False)):
        return []

    queue_items = effective_queue_blueprint(context, scene, settings, enabled_only=enabled_only)
    if not queue_items:
        return []

    counts = queue_counts(scene, settings, queue_items)
    context_view_layer_name = getattr(getattr(context, "view_layer", None), "name", "")
    padding = int(getattr(settings, "sequence_padding", 4) or 4)
    movie_targets: List[dict] = []

    for item in queue_items:
        resolved = resolve_item_context(scene, settings, item, context_view_layer_name=context_view_layer_name)
        frames = [int(frame) for frame in (resolved.get("frames", []) or []) if frame is not None]
        if len(frames) <= 1:
            continue
        first_frame = int(frames[0])
        try:
            first_target = resolve_output(scene, settings, item, first_frame, counts, context_view_layer_name=context_view_layer_name)
            movie_job = build_movie_job(
                str(first_target["output_dir"]),
                str(getattr(settings, "movie_file_pattern", "") or "{scene}_{variant}_{camera}_{view_layer}"),
                dict(first_target["tokens"]),
                str(getattr(settings, "movie_preset", "H264_MP4") or "H264_MP4"),
                str(first_target["full_path"]),
                first_frame,
                len(frames),
                padding,
                str(getattr(settings, "ffmpeg_executable", "ffmpeg") or "ffmpeg"),
                bool(getattr(settings, "movie_overwrite_existing", False)),
            )
        except Exception:
            movie_job = None
        if not movie_job:
            continue

        movie_targets.append(
            {
                "item": dict(item),
                "label": str(resolved.get("label", "") or getattr(resolved.get("variant"), "name", "") or f"{resolved.get('camera_name', '')} | {resolved.get('view_layer_name', '')}"),
                "camera_name": str(resolved.get("camera_name", "") or ""),
                "view_layer_name": str(resolved.get("view_layer_name", "") or ""),
                "variant_name": str(getattr(resolved.get("variant"), "name", item.get("variant_name", "")) or item.get("variant_name", "")),
                "frame": first_frame,
                "frame_start": int(min(frames)),
                "frame_end": int(max(frames)),
                "frame_count": int(len(frames)),
                "output_kind": "movie",
                "expected_path": os.path.normpath(str(movie_job.get("output_path", "") or "")),
                "verification_label": "movie",
                "movie_output": str(movie_job.get("output_path", "") or ""),
                "sequence_input_pattern": str(movie_job.get("input_pattern", "") or ""),
            }
        )

    return movie_targets



def detect_output_collisions(context, scene, settings, enabled_only: bool = False, sample_limit: int = 2000):
    targets = collect_output_targets(context, scene, settings, enabled_only=enabled_only)
    movie_targets = _movie_collision_targets(context, scene, settings, enabled_only=enabled_only)
    buckets: Dict[str, List[dict]] = {}
    verification_scope = _collision_verification_scope(scene, settings)
    padding = int(getattr(settings, "sequence_padding", 4) or 4)

    for target in targets:
        verification_plan = build_output_verification_plan(
            scene,
            str(target["full_path"]),
            str(target["output_dir"]),
            str(target["tokens"].get("variant", "base")),
            str(target["view_layer_name"]),
            int(target["frame"]),
            str(target["profile"].get("image_format", getattr(settings, "image_format", "PNG"))),
            padding,
            verification_scope,
        )
        requirements = list(verification_plan.get("requirements", []) or [])
        if not requirements:
            requirements = [
                {
                    "kind": "primary",
                    "expected_path": str(target["full_path"]),
                    "label": "primary",
                }
            ]
        for requirement in requirements:
            path = os.path.normpath(str(requirement.get("expected_path", "") or ""))
            if not path:
                continue
            entry = dict(target)
            entry["output_kind"] = str(requirement.get("kind", "primary") or "primary")
            entry["expected_path"] = path
            entry["verification_label"] = str(requirement.get("label", entry["output_kind"]) or entry["output_kind"])
            buckets.setdefault(path, []).append(entry)

    for movie_target in movie_targets:
        path = os.path.normpath(str(movie_target.get("expected_path", "") or ""))
        if not path:
            continue
        buckets.setdefault(path, []).append(dict(movie_target))

    collisions = [(path, bucket) for path, bucket in buckets.items() if len(bucket) > 1]
    collisions.sort(key=lambda item: item[0].lower())
    plan_sample = targets[: min(sample_limit, len(targets))]
    truncated = len(targets) > sample_limit
    return collisions, truncated, plan_sample



def serialize_queue_item(item) -> Dict[str, object]:
    if isinstance(item, dict):
        return {
            "enabled": bool(item.get("enabled", True)),
            "source_mode": item.get("source_mode", "PAIR"),
            "camera": item.get("camera_name", ""),
            "view_layer": item.get("view_layer_name", ""),
            "variant": item.get("variant_name", ""),
            "label": item.get("label", ""),
        }
    return {
        "enabled": bool(getattr(item, "enabled", True)),
        "source_mode": getattr(item, "source_mode", "PAIR"),
        "camera": getattr(item, "camera_name", ""),
        "view_layer": getattr(item, "view_layer_name", ""),
        "variant": getattr(item, "variant_name", ""),
        "label": getattr(item, "label", ""),
    }



def serialize_variant(scene, variant) -> Dict[str, object]:
    resolved = effective_variant_data(scene, variant) or {}
    return {
        "enabled": bool(variant.enabled),
        "name": variant.name,
        "description": variant.description,
        "parent_variant_name": getattr(variant, "parent_variant_name", ""),
        "variant_chain": resolved.get("variant_chain", [variant.name]),
        "variant_path": resolved.get("variant_path", safe_name(variant.name)),
        "parent_variant": resolved.get("parent_name", ""),
        "camera_name": variant.camera_name,
        "view_layer_name": variant.view_layer_name,
        "engine_mode": variant.engine_mode,
        "quality_mode": variant.quality_mode,
        "resolution_percentage_override": int(variant.resolution_percentage_override),
        "resolution_x_override": int(getattr(variant, "resolution_x_override", 0) or 0),
        "resolution_y_override": int(getattr(variant, "resolution_y_override", 0) or 0),
        "sample_multiplier_override": float(variant.sample_multiplier_override),
        "denoise_mode": variant.denoise_mode,
        "adaptive_sampling_mode": variant.adaptive_sampling_mode,
        "motion_blur_mode": variant.motion_blur_mode,
        "freestyle_mode": variant.freestyle_mode,
        "pass_bundle": variant.pass_bundle,
        "image_format_override": variant.image_format_override,
        "use_custom_frames": bool(variant.use_custom_frames),
        "frame_start": int(variant.frame_start),
        "frame_end": int(variant.frame_end),
        "material_override_mode": getattr(variant, "material_override_mode", "SCENE"),
        "material_override_name": variant.material_override_name,
        "world_override_mode": getattr(variant, "world_override_mode", "SCENE"),
        "world_override_name": variant.world_override_name,
        "collection_override_mode": getattr(variant, "collection_override_mode", "SCENE"),
        "film_transparent_mode": getattr(variant, "film_transparent_mode", "SCENE"),
        "color_management_mode": getattr(variant, "color_management_mode", "SCENE"),
        "view_transform_override": getattr(variant, "view_transform_override", ""),
        "look_override": getattr(variant, "look_override", ""),
        "use_exposure_override": bool(getattr(variant, "use_exposure_override", False)),
        "exposure_override": float(getattr(variant, "exposure_override", 0.0) or 0.0),
        "use_gamma_override": bool(getattr(variant, "use_gamma_override", False)),
        "gamma_override": float(getattr(variant, "gamma_override", 1.0) or 1.0),
        "include_collections": variant.include_collections,
        "exclude_collections": variant.exclude_collections,
        "holdout_collections": variant.holdout_collections,
        "indirect_only_collections": variant.indirect_only_collections,
        "object_visibility_override_mode": getattr(variant, "object_visibility_override_mode", "SCENE"),
        "show_objects": getattr(variant, "show_objects", ""),
        "hide_objects": getattr(variant, "hide_objects", ""),
        "representation_mode": getattr(variant, "representation_mode", "SCENE"),
        "proxy_collections": getattr(variant, "proxy_collections", ""),
        "render_collections": getattr(variant, "render_collections", ""),
        "execution_device_mode_override": getattr(variant, "execution_device_mode_override", "SCENE"),
        "frame_chunk_size_override": int(getattr(variant, "frame_chunk_size_override", 0) or 0),
        "concurrent_tasks_override": int(getattr(variant, "concurrent_tasks_override", 0) or 0),
        "farm_priority_override": int(getattr(variant, "farm_priority_override", -1) if getattr(variant, "farm_priority_override", -1) is not None else -1),
        "memory_gb_hint_override": float(getattr(variant, "memory_gb_hint_override", -1.0) if getattr(variant, "memory_gb_hint_override", -1.0) is not None else -1.0),
        "temporal_subsamples_override": int(getattr(variant, "temporal_subsamples_override", 0) or 0),
        "spatial_subsamples_override": int(getattr(variant, "spatial_subsamples_override", 0) or 0),
        "accumulation_samples_override": int(getattr(variant, "accumulation_samples_override", 0) or 0),
        "output_root_override": variant.output_root_override,
        "output_dir_pattern_override": variant.output_dir_pattern_override,
        "output_file_pattern_override": variant.output_file_pattern_override,
        "stamp_note_override": variant.stamp_note_override,
        "job_name_override": getattr(variant, "job_name_override", ""),
        "job_tags_override": getattr(variant, "job_tags_override", ""),
    }



def apply_manifest(scene, data: dict) -> None:
    if not isinstance(data, dict):
        return
    settings = scene.srr_settings
    profile = data.get("profile", {}) or {}
    output = data.get("output", {}) or {}
    batch = data.get("batch", {}) or {}
    render_elements = data.get("render_elements", {}) or {}
    network_render = data.get("network_render", {}) or {}
    ui = data.get("ui", {}) or {}
    bridge = data.get("bridge", {}) or {}
    execution = data.get("execution", {}) or {}
    verification = data.get("verification", {}) or {}

    for key in [
        "engine_mode",
        "quality_mode",
        "sample_multiplier",
        "resolution_percentage",
        "use_denoise",
        "use_adaptive_sampling",
        "use_motion_blur",
        "use_freestyle",
        "pass_bundle",
    ]:
        if key in profile and hasattr(settings, key):
            try:
                setattr(settings, key, profile[key])
            except Exception:
                pass

    output_map = {
        "output_root": "root",
        "output_dir_pattern": "dir_pattern",
        "output_file_pattern": "file_pattern",
        "image_format": "image_format",
        "overwrite_existing": "overwrite_existing",
        "skip_existing_frames": "skip_existing_frames",
        "use_placeholder": "use_placeholder",
        "auto_create_folders": "auto_create_folders",
        "auto_unique_tokens": "auto_unique_tokens",
        "abort_on_collisions": "abort_on_collisions",
        "strict_missing_assets": "strict_missing_assets",
        "use_stamp": "use_stamp",
        "stamp_note": "stamp_note",
        "enable_movie_encode": "movie_encode_enabled",
        "movie_preset": "movie_preset",
        "movie_file_pattern": "movie_file_pattern",
        "movie_overwrite_existing": "movie_overwrite_existing",
        "ffmpeg_executable": "ffmpeg_executable",
        "job_name": "job_name",
        "sequence_padding": "sequence_padding",
    }
    for target_key, source_key in output_map.items():
        if source_key in output and hasattr(settings, target_key):
            try:
                setattr(settings, target_key, output[source_key])
            except Exception:
                pass

    for key in [
        "frame_mode",
        "custom_frame_start",
        "custom_frame_end",
        "selected_cameras_only",
        "renderable_cameras_only",
        "view_layer_mode",
        "queue_source_mode",
        "queue_compositing_mode",
        "retry_on_failure",
        "retry_count",
        "halt_on_first_error",
    ]:
        if key in batch and hasattr(settings, key):
            try:
                setattr(settings, key, batch[key])
            except Exception:
                pass

    for key in ["compact_mode", "show_advanced"]:
        if key in ui and hasattr(settings, key):
            try:
                setattr(settings, key, ui[key])
            except Exception:
                pass

    render_elements_quick_set = render_elements.get("quick_set", render_elements.get("preset"))
    render_elements_map = {
        "render_elements_enabled": "enabled",
        "render_elements_output_mode": "output_mode",
    }
    for target_key, source_key in render_elements_map.items():
        if source_key not in render_elements or not hasattr(settings, target_key):
            continue
        try:
            setattr(settings, target_key, render_elements[source_key])
        except Exception:
            pass
    if render_elements_quick_set is not None and hasattr(settings, "render_elements_preset"):
        try:
            settings.render_elements_preset = render_elements_quick_set
        except Exception:
            pass
    if render_elements:
        raw_elements = render_elements.get("elements")
        if isinstance(raw_elements, (list, tuple, set)):
            set_render_element_item_ids(settings, raw_elements)
        else:
            preset_token = str(getattr(settings, "render_elements_preset", "FROM_PASS_BUNDLE") or "FROM_PASS_BUNDLE")
            set_render_element_item_ids(settings, render_element_item_ids_for_preset(settings, preset=preset_token))

    network_render_map = {
        "network_render_enabled": "enabled",
        "network_render_target": "target",
    }
    for target_key, source_key in network_render_map.items():
        if source_key not in network_render or not hasattr(settings, target_key):
            continue
        try:
            setattr(settings, target_key, network_render[source_key])
        except Exception:
            pass
    if "target" in network_render and hasattr(settings, "bridge_target"):
        try:
            settings.bridge_target = network_render["target"]
        except Exception:
            pass

    execution_map = {
        "execution_device_mode": "device_mode",
        "farm_priority": "farm_priority",
        "frame_chunk_size": "frame_chunk_size",
        "concurrent_tasks": "concurrent_tasks",
        "memory_gb_hint": "memory_gb_hint",
        "job_tags": "job_tags",
        "temporal_subsamples": "temporal_subsamples",
        "spatial_subsamples": "spatial_subsamples",
        "accumulation_samples": "accumulation_samples",
    }
    for target_key, source_key in execution_map.items():
        if source_key not in execution or not hasattr(settings, target_key):
            continue
        value = execution[source_key]
        if target_key == "job_tags" and isinstance(value, list):
            value = ", ".join(str(tag) for tag in value if str(tag).strip())
        try:
            setattr(settings, target_key, value)
        except Exception:
            pass

    if "manifest_path" in bridge and hasattr(settings, "manifest_path"):
        try:
            settings.manifest_path = bridge["manifest_path"]
        except Exception:
            pass
    if "target" in bridge and hasattr(settings, "bridge_target"):
        try:
            settings.bridge_target = bridge["target"]
        except Exception:
            pass
    if "preview_limit" in bridge and hasattr(settings, "preview_limit"):
        try:
            settings.preview_limit = int(bridge["preview_limit"])
        except Exception:
            pass
    if "analysis_detail_limit" in bridge and hasattr(settings, "analysis_detail_limit"):
        try:
            settings.analysis_detail_limit = int(bridge["analysis_detail_limit"])
        except Exception:
            pass

    verification_map = {
        "verify_outputs_after_render": "enabled",
        "verification_scope": "scope",
        "min_output_size_kb": "min_output_size_kb",
        "verification_retry_count": "retry_count",
        "verification_retry_delay": "retry_delay_seconds",
        "cleanup_invalid_outputs": "cleanup_invalid_outputs",
    }
    for target_key, source_key in verification_map.items():
        if source_key not in verification or not hasattr(settings, target_key):
            continue
        try:
            setattr(settings, target_key, verification[source_key])
        except Exception:
            pass

    collection_clear(scene.srr_variants)
    for source in data.get("variants", []) or []:
        if not isinstance(source, dict):
            continue
        item = scene.srr_variants.add()
        for key, value in source.items():
            if hasattr(item, key):
                try:
                    setattr(item, key, value)
                except Exception:
                    pass

    queue_source = data.get("queue", []) or ((data.get("detected_scene_assets", {}) or {}).get("queue", []))
    collection_clear(scene.srr_queue)
    for source in queue_source:
        if not isinstance(source, dict):
            continue
        item = scene.srr_queue.add()
        item.enabled = bool(source.get("enabled", True))
        item.source_mode = str(source.get("source_mode", source.get("type", "PAIR")))
        item.camera_name = str(source.get("camera", source.get("camera_name", "")))
        item.view_layer_name = str(source.get("view_layer", source.get("view_layer_name", "")))
        item.variant_name = str(source.get("variant", source.get("variant_name", "")))
        item.label = str(source.get("label", ""))



def _unknown_tokens(pattern: str, known_tokens: Sequence[str]) -> List[str]:
    found = []
    for part in str(pattern or "").split("{"):
        if "}" not in part:
            continue
        candidate = part.split("}", 1)[0].strip()
        if not candidate:
            continue
        token = "{" + candidate + "}"
        if token not in known_tokens and token not in found:
            found.append(token)
    return found


def analysis_result(context, scene, settings) -> Dict[str, object]:
    issues: List[Dict[str, str]] = []
    cameras = available_cameras(context, settings)
    layers = available_view_layers(context, settings)
    queue_items = effective_queue_blueprint(context, scene, settings, enabled_only=True)
    variants = list(getattr(scene, "srr_variants", []))
    counts = queue_counts(scene, settings, queue_items) if queue_items else {"camera": 1, "view_layer": 1, "variant": 1, "frame": 1}

    known_tokens = set(AVAILABLE_OUTPUT_TOKENS)

    if not bpy.data.filepath:
        issues.append({"level": "WARNING", "message": "Blend file is unsaved / .blend が未保存です。相対パス // の基準が不安定になります。"})
    if not cameras:
        issues.append({"level": "ERROR", "message": "No renderable camera found / レンダー可能なカメラが見つかりません。"})
    if not layers:
        issues.append({"level": "ERROR", "message": "No view layer found / ビューレイヤーが見つかりません。"})
    if getattr(settings, "queue_source_mode", "PAIRS") == "VARIANTS" and not variants:
        issues.append({"level": "WARNING", "message": "Queue source is Variants but no variant exists / Queue source が Variants ですがバリアントとテイクがありません。"})
    if not queue_items:
        issues.append({"level": "WARNING", "message": "Queue would be empty with current settings / 現在の設定ではキューが空になります。"})

    output_root = abspath(getattr(settings, "output_root", default_output_root(create=True)) or default_output_root(create=True))
    auto_create = bool(getattr(settings, "auto_create_folders", True))

    def selector_matches_and_issues(selectors, available_names):
        diagnostics = resolve_selector_diagnostics(selectors, available_names)
        return (
            list(diagnostics.get("resolved", []) or []),
            list(diagnostics.get("unmatched", []) or []),
            list(diagnostics.get("invalid", []) or []),
        )

    if not os.path.isdir(output_root) and not auto_create:
        issues.append({"level": "WARNING", "message": f"Output root does not exist and auto-create is off / 保存先が存在せず自動作成もオフです: {output_root}"})
    if not can_write_directory(output_root, create=auto_create):
        issues.append({"level": "ERROR", "message": f"Output root is not writable or no writable parent exists / 保存先へ書き込めないか、書き込み可能な親フォルダーが見つかりません: {output_root}"})
    if getattr(settings, "frame_mode", "CURRENT") == "CUSTOM" and int(getattr(settings, "custom_frame_start", 0)) > int(getattr(settings, "custom_frame_end", 0)):
        issues.append({"level": "WARNING", "message": "Custom frame range is reversed; it will be normalized automatically / カスタムフレーム範囲の開始と終了が逆です。自動補正して実行します。"})
    if not bpy.data.filepath and uses_relative_blend_path(getattr(settings, "output_root", default_output_root(create=True))):
        issues.append({"level": "WARNING", "message": "Output root uses // while the .blend file is unsaved / .blend 未保存のまま出力先に // を使っています。"})
    manifest_path_setting = str(getattr(settings, "manifest_path", "") or "")
    if not bpy.data.filepath and manifest_path_setting.strip() and uses_relative_blend_path(manifest_path_setting):
        issues.append({"level": "WARNING", "message": "Manifest path uses // while the .blend file is unsaved / .blend 未保存のまま manifest パスに // を使っています。"})

    heavy_pass_bundle = getattr(settings, "pass_bundle", "NONE") in {"COMPOSITE", "LOOKDEV", "LIGHTING", "CRYPTOMATTE", "DATASET", "TECHNICAL"}
    if heavy_pass_bundle and getattr(settings, "image_format", "PNG") not in {"OPEN_EXR", "OPEN_EXR_MULTILAYER", "TIFF"}:
        issues.append({"level": "WARNING", "message": "Advanced pass bundles work best with EXR/TIFF / 高度なパス用途には EXR/TIFF 系が向いています。"})

    if getattr(settings, "selected_cameras_only", False) and not camera_selection(context):
        issues.append({"level": "WARNING", "message": "Selected Cameras Only is enabled but no camera is selected / Selected Cameras Only がオンですがカメラ選択がありません。"})

    unknown_dir_tokens = _unknown_tokens(getattr(settings, "output_dir_pattern", ""), known_tokens)
    unknown_file_tokens = _unknown_tokens(getattr(settings, "output_file_pattern", ""), known_tokens)
    if unknown_dir_tokens or unknown_file_tokens:
        unknown = ", ".join(unknown_dir_tokens + unknown_file_tokens)
        issues.append({"level": "WARNING", "message": f"Unknown output token(s): {unknown} / 未知の出力トークンがあります: {unknown}"})

    pattern_extension_warnings = file_pattern_extension_warnings(getattr(settings, "output_file_pattern", ""))
    if pattern_extension_warnings:
        issues.append({
            "level": "WARNING",
            "message": "Output file pattern already contains an extension hint; Blender adds the real extension automatically / ファイル名パターンに拡張子指定が含まれています。実際の拡張子は Blender が自動付与します。",
        })

    use_variants_in_queue = bool(
        getattr(settings, "queue_source_mode", "PAIRS") == "VARIANTS"
        or any(item.get("source_mode", "PAIR") == "VARIANT" for item in queue_items)
    )
    variant_names = [str(getattr(variant, "name", "")).strip() for variant in variants if str(getattr(variant, "name", "")).strip()]
    duplicate_variant_names = sorted({name for name in variant_names if variant_names.count(name) > 1})
    duplicate_variant_level = "ERROR" if use_variants_in_queue else "WARNING"
    for name in duplicate_variant_names:
        issues.append({"level": duplicate_variant_level, "message": f"Duplicate variant name breaks deterministic lookup / 重複したバリアントとテイク名は決定的な参照を壊します: {name}"})

    variants_by_name = variant_lookup(scene)
    for item in queue_items:
        source_mode = item.get("source_mode", "PAIR")
        if source_mode == "VARIANT":
            variant_name = str(item.get("variant_name", "") or "")
            if variant_name and variant_name not in variants_by_name:
                issues.append({"level": "ERROR", "message": f"Queue item references missing variant / キュー項目が存在しないバリアントとテイクを参照しています: {variant_name}"})
            continue
        pair_camera_name = str(item.get("camera_name", "") or "")
        pair_layer_name = str(item.get("view_layer_name", "") or "")
        if pair_camera_name and scene_object(scene, pair_camera_name, type_hint="CAMERA") is None:
            issues.append({"level": "ERROR", "message": f"Queue item references missing camera / キュー項目のカメラが見つかりません: {pair_camera_name}"})
        if pair_layer_name and view_layer(scene, pair_layer_name) is None:
            issues.append({"level": "ERROR", "message": f"Queue item references missing view layer / キュー項目のビューレイヤーが見つかりません: {pair_layer_name}"})

    movie_pattern_unknown_tokens = _unknown_tokens(getattr(settings, "movie_file_pattern", ""), known_tokens)
    if getattr(settings, "enable_movie_encode", False) and movie_pattern_unknown_tokens:
        unknown = ", ".join(movie_pattern_unknown_tokens)
        issues.append({"level": "WARNING", "message": f"Movie file pattern contains unknown token(s) / ムービー名パターンに未知のトークンがあります: {unknown}"})
    if getattr(settings, "enable_movie_encode", False) and not command_exists(str(getattr(settings, "ffmpeg_executable", "ffmpeg") or "ffmpeg")):
        issues.append({"level": "WARNING", "message": "FFmpeg executable was not found from the current command/path / 指定された FFmpeg コマンドまたはパスが見つかりません。"})
    effective_compositing_mode = effective_queue_compositing_mode(scene, str(getattr(settings, "queue_compositing_mode", "AUTO") or "AUTO"))
    if bool(getattr(settings, "verify_outputs_after_render", True)) and verification_scope_requires_passes(getattr(settings, "verification_scope", "PRIMARY_AND_PASSES")) and effective_compositing_mode != "COMPOSITOR":
        issues.append({"level": "WARNING", "message": f"Pass verification is enabled but the effective queue compositing mode resolves to Direct Output ({effective_compositing_mode}); only the main output can be verified safely / パス検証は有効ですが、実効 Queue Compositing が Direct Output ({effective_compositing_mode}) と判定されました。安全に検証できるのは主出力のみです。"})
    if bool(getattr(settings, "verify_outputs_after_render", True)) and int(getattr(settings, "min_output_size_kb", 0) or 0) > 512000:
        issues.append({"level": "WARNING", "message": "Minimum output size is set very high and may cause false failures / 最小出力サイズが大きすぎるため誤検出の原因になる可能性があります。"})
    if int(getattr(settings, "frame_chunk_size", 1) or 1) > 1 and getattr(settings, "frame_mode", "CURRENT") == "CURRENT":
        issues.append({"level": "INFO", "message": "Frame chunk size is greater than 1, but the current plan renders only one frame per job / Frame Chunk Size は 1 より大きいですが、現在の設定では各ジョブが単フレームです。"})
    if getattr(settings, "enable_movie_encode", False) and "{frame}" in str(getattr(settings, "movie_file_pattern", "") or ""):
        issues.append({"level": "WARNING", "message": "Movie file pattern usually should not contain {frame} / ムービー名パターンには通常 {frame} を入れません。"})
    if getattr(settings, "enable_movie_encode", False):
        multi_frame_jobs = 0
        movie_preview_failures = 0
        context_view_layer_name = getattr(getattr(context, "view_layer", None), "name", "")
        for item in queue_items:
            resolved = resolve_item_context(scene, settings, item, context_view_layer_name=context_view_layer_name)
            frames = list(resolved.get("frames", []) or [])
            if len(frames) <= 1:
                continue
            multi_frame_jobs += 1
            try:
                first_target = resolve_output(scene, settings, item, int(frames[0]), counts, context_view_layer_name=context_view_layer_name)
                movie_job = build_movie_job(
                    first_target["output_dir"],
                    str(getattr(settings, "movie_file_pattern", "") or "{scene}_{variant}_{camera}_{view_layer}"),
                    dict(first_target["tokens"]),
                    str(getattr(settings, "movie_preset", "H264_MP4") or "H264_MP4"),
                    str(first_target["full_path"]),
                    int(frames[0]),
                    len(frames),
                    int(getattr(settings, "sequence_padding", 4) or 4),
                    str(getattr(settings, "ffmpeg_executable", "ffmpeg") or "ffmpeg"),
                    bool(getattr(settings, "movie_overwrite_existing", False)),
                )
                if not movie_job:
                    movie_preview_failures += 1
            except Exception:
                movie_preview_failures += 1
        if multi_frame_jobs == 0:
            issues.append({"level": "WARNING", "message": "Movie encode is enabled but the queue contains only still/single-frame jobs / ムービー化は有効ですが、キューに単フレームジョブしかありません。"})
        elif movie_preview_failures > 0:
            issues.append({"level": "WARNING", "message": f"Some movie jobs could not derive an FFmpeg input pattern / 一部のムービー化ジョブで FFmpeg 入力パターンを導出できませんでした: {movie_preview_failures}"})

    missing_assets = missing_external_assets()
    if missing_assets:
        issues.append({
            "level": "ERROR" if getattr(settings, "strict_missing_assets", False) else "WARNING",
            "message": f"Missing external assets: {len(missing_assets)} / 欠落している外部アセットがあります: {len(missing_assets)}",
        })

    collisions, truncated, plan_sample = detect_output_collisions(context, scene, settings, enabled_only=True, sample_limit=max(100, int(getattr(settings, 'preview_limit', 16)) * 20))
    if collisions:
        issues.append({
            "level": "ERROR" if getattr(settings, "abort_on_collisions", True) else "WARNING",
            "message": f"Output collisions detected: {len(collisions)} / 出力衝突を検出しました: {len(collisions)}",
        })

    variant_collection_names = sorted(item.name for item in getattr(bpy.data, "collections", []))
    variant_object_names = sorted(obj.name for obj in getattr(scene, "objects", []) if str(getattr(obj, "name", "") or "").strip())
    view_settings = getattr(scene, "view_settings", None)
    view_transform_keys = set(enum_keys(view_settings, "view_transform")) if view_settings is not None else set()
    look_keys = set(enum_keys(view_settings, "look")) if view_settings is not None else set()
    auto_create = bool(getattr(settings, "auto_create_folders", True))

    def selector_matches_and_issues(selectors, available_names):
        diagnostics = resolve_selector_diagnostics(selectors, available_names)
        return (
            list(diagnostics.get("resolved", []) or []),
            list(diagnostics.get("unmatched", []) or []),
            list(diagnostics.get("invalid", []) or []),
        )

    for issue in variant_inheritance_issues(scene):
        issue_type = str(issue.get("type", ""))
        variant_name = str(issue.get("variant", "") or "")
        parent_name = str(issue.get("parent", "") or "")
        if issue_type == "duplicate_name":
            issues.append({"level": "ERROR", "message": f"Duplicate variant name detected / バリアントとテイク名が重複しています: {variant_name}"})
        elif issue_type == "missing_parent":
            issues.append({"level": "ERROR", "message": f"Variant '{variant_name}' references a missing parent / バリアントとテイク '{variant_name}' の親バリアントとテイクが見つかりません: {parent_name}"})
        elif issue_type == "self_parent":
            issues.append({"level": "ERROR", "message": f"Variant '{variant_name}' cannot parent itself / バリアントとテイク '{variant_name}' は自分自身を親にできません。"})
        elif issue_type == "cycle":
            chain_text = " -> ".join(issue.get("chain", []) or [variant_name])
            issues.append({"level": "ERROR", "message": f"Variant inheritance cycle detected / バリアントとテイク継承が循環しています: {chain_text}"})

    for variant in variants:
        resolved_variant = effective_variant(scene, variant)
        level = "ERROR" if (use_variants_in_queue and getattr(variant, "enabled", True)) else "WARNING"
        variant_label = resolved_variant_path(scene, variant, separator=" / ") or variant.name
        if resolved_variant is None:
            continue
        if getattr(resolved_variant, "camera_name", "") and scene_object(scene, resolved_variant.camera_name, type_hint="CAMERA") is None:
            issues.append({"level": level, "message": f"Variant '{variant_label}' references missing camera / バリアントとテイク '{variant_label}' のカメラが見つかりません: {resolved_variant.camera_name}"})
        if getattr(resolved_variant, "view_layer_name", "") and view_layer(scene, resolved_variant.view_layer_name) is None:
            issues.append({"level": level, "message": f"Variant '{variant_label}' references missing view layer / バリアントとテイク '{variant_label}' のビューレイヤーが見つかりません: {resolved_variant.view_layer_name}"})
        if getattr(resolved_variant, "material_override_mode", "SCENE") == "OVERRIDE" and resolved_variant.material_override_name and material_by_name(resolved_variant.material_override_name) is None:
            issues.append({"level": level, "message": f"Variant '{variant_label}' references missing material / バリアントとテイク '{variant_label}' のマテリアルが見つかりません: {resolved_variant.material_override_name}"})
        if getattr(resolved_variant, "world_override_mode", "SCENE") == "OVERRIDE" and resolved_variant.world_override_name and world_by_name(resolved_variant.world_override_name) is None:
            issues.append({"level": level, "message": f"Variant '{variant_label}' references missing world / バリアントとテイク '{variant_label}' のワールドが見つかりません: {resolved_variant.world_override_name}"})
        if bool(getattr(resolved_variant, "use_custom_frames", False)) and int(getattr(resolved_variant, "frame_start", 0)) > int(getattr(resolved_variant, "frame_end", 0)):
            issues.append({"level": "WARNING", "message": f"Variant '{variant_label}' has a reversed custom frame range; it will be normalized automatically / バリアントとテイク '{variant_label}' のカスタムフレーム範囲が逆です。自動補正して実行します。"})

        include_selectors = parse_name_list(getattr(resolved_variant, "include_collections", ""))
        exclude_selectors = parse_name_list(getattr(resolved_variant, "exclude_collections", ""))
        holdout_selectors = parse_name_list(getattr(resolved_variant, "holdout_collections", ""))
        indirect_selectors = parse_name_list(getattr(resolved_variant, "indirect_only_collections", ""))

        include_matches, include_missing, include_invalid = selector_matches_and_issues(include_selectors, variant_collection_names)
        exclude_matches, exclude_missing, exclude_invalid = selector_matches_and_issues(exclude_selectors, variant_collection_names)
        holdout_matches, holdout_missing, holdout_invalid = selector_matches_and_issues(holdout_selectors, variant_collection_names)
        indirect_matches, indirect_missing, indirect_invalid = selector_matches_and_issues(indirect_selectors, variant_collection_names)

        include_names = set(include_matches)
        exclude_names = set(exclude_matches)
        holdout_names = set(holdout_matches)
        indirect_names = set(indirect_matches)

        if getattr(resolved_variant, "collection_override_mode", "SCENE") != "SCENE":
            contradictions = [
                ("include+exclude", include_names & exclude_names),
                ("exclude+holdout", exclude_names & holdout_names),
                ("exclude+indirect", exclude_names & indirect_names),
                ("holdout+indirect", holdout_names & indirect_names),
            ]
            for label, names in contradictions:
                if names:
                    issues.append({"level": level if label == "include+exclude" else "WARNING", "message": f"Variant '{variant_label}' has overlapping collection rules ({label}) / バリアントとテイク '{variant_label}' に重複ルールがあります ({label}): {', '.join(sorted(names))}"})

            for field_label, selectors, missing_selectors, invalid_selectors in [
                ("include", include_selectors, include_missing, include_invalid),
                ("exclude", exclude_selectors, exclude_missing, exclude_invalid),
                ("holdout", holdout_selectors, holdout_missing, holdout_invalid),
                ("indirect_only", indirect_selectors, indirect_missing, indirect_invalid),
            ]:
                for invalid in invalid_selectors:
                    selector = str(invalid.get("selector", "") or "")
                    error = str(invalid.get("error", "") or "")
                    issues.append({"level": "ERROR", "message": f"Variant '{variant_label}' has an invalid collection regex ({field_label}) / バリアントとテイク '{variant_label}' のコレクション正規表現が無効です ({field_label}): {selector} ({error})"})
                for selector in missing_selectors:
                    issues.append({"level": level, "message": f"Variant '{variant_label}' collection selector matched nothing ({field_label}) / バリアントとテイク '{variant_label}' のコレクションセレクターに一致がありません ({field_label}): {selector}"})
                if len(selectors) == 1 and not invalid_selectors:
                    preview = preview_selector_matches(selectors, variant_collection_names, limit=4)
                    if len(preview) >= 4 and isinstance(preview[-1], str) and preview[-1].startswith('+'):
                        issues.append({"level": "WARNING", "message": f"Variant '{variant_label}' collection selector is broad ({field_label}) / バリアントとテイク '{variant_label}' のコレクションセレクターが広範囲です ({field_label}): {selectors[0]} -> {', '.join(preview)}"})

        show_object_selectors = parse_name_list(getattr(resolved_variant, "show_objects", ""))
        hide_object_selectors = parse_name_list(getattr(resolved_variant, "hide_objects", ""))
        show_object_matches, show_object_missing, show_object_invalid = selector_matches_and_issues(show_object_selectors, variant_object_names)
        hide_object_matches, hide_object_missing, hide_object_invalid = selector_matches_and_issues(hide_object_selectors, variant_object_names)
        show_object_names = set(show_object_matches)
        hide_object_names = set(hide_object_matches)

        if getattr(resolved_variant, "object_visibility_override_mode", "SCENE") != "SCENE":
            overlap = show_object_names & hide_object_names
            if overlap:
                issues.append({"level": level, "message": f"Variant '{variant_label}' has overlapping object visibility rules / バリアントとテイク '{variant_label}' のオブジェクト可視ルールが重複しています: {', '.join(sorted(overlap))}"})

            for field_label, selectors, missing_selectors, invalid_selectors in [
                ("show", show_object_selectors, show_object_missing, show_object_invalid),
                ("hide", hide_object_selectors, hide_object_missing, hide_object_invalid),
            ]:
                for invalid in invalid_selectors:
                    selector = str(invalid.get("selector", "") or "")
                    error = str(invalid.get("error", "") or "")
                    issues.append({"level": "ERROR", "message": f"Variant '{variant_label}' has an invalid object regex ({field_label}) / バリアントとテイク '{variant_label}' のオブジェクト正規表現が無効です ({field_label}): {selector} ({error})"})
                for selector in missing_selectors:
                    issues.append({"level": level, "message": f"Variant '{variant_label}' object selector matched nothing ({field_label}) / バリアントとテイク '{variant_label}' のオブジェクトセレクターに一致がありません ({field_label}): {selector}"})
                if len(selectors) == 1 and not invalid_selectors:
                    preview = preview_selector_matches(selectors, variant_object_names, limit=4)
                    if len(preview) >= 4 and isinstance(preview[-1], str) and preview[-1].startswith('+'):
                        issues.append({"level": "WARNING", "message": f"Variant '{variant_label}' object selector is broad ({field_label}) / バリアントとテイク '{variant_label}' のオブジェクトセレクターが広範囲です ({field_label}): {selectors[0]} -> {', '.join(preview)}"})

        representation_mode = str(getattr(resolved_variant, "representation_mode", "SCENE") or "SCENE")
        if representation_mode != "SCENE":
            proxy_selectors = parse_name_list(getattr(resolved_variant, "proxy_collections", ""))
            render_selectors = parse_name_list(getattr(resolved_variant, "render_collections", ""))
            proxy_matches, proxy_missing, proxy_invalid = selector_matches_and_issues(proxy_selectors, variant_collection_names)
            render_matches, render_missing, render_invalid = selector_matches_and_issues(render_selectors, variant_collection_names)
            proxy_names = set(proxy_matches)
            render_names = set(render_matches)

            if not proxy_selectors:
                issues.append({"level": level, "message": f"Variant '{variant_label}' has representation mode enabled but no proxy selectors / バリアントとテイク '{variant_label}' は表現モードが有効ですがプロキシセレクターが未指定です。"})
            if not render_selectors:
                issues.append({"level": level, "message": f"Variant '{variant_label}' has representation mode enabled but no render selectors / バリアントとテイク '{variant_label}' は表現モードが有効ですがレンダーセレクターが未指定です。"})
            overlap = proxy_names & render_names
            if overlap:
                issues.append({"level": "WARNING", "message": f"Variant '{variant_label}' representation groups overlap / バリアントとテイク '{variant_label}' の表現グループが重複しています: {', '.join(sorted(overlap))}"})
            for field_label, selectors, missing_selectors, invalid_selectors in [
                ("proxy", proxy_selectors, proxy_missing, proxy_invalid),
                ("render", render_selectors, render_missing, render_invalid),
            ]:
                for invalid in invalid_selectors:
                    selector = str(invalid.get("selector", "") or "")
                    error = str(invalid.get("error", "") or "")
                    issues.append({"level": "ERROR", "message": f"Variant '{variant_label}' has an invalid representation regex ({field_label}) / バリアントとテイク '{variant_label}' の表現正規表現が無効です ({field_label}): {selector} ({error})"})
                for selector in missing_selectors:
                    issues.append({"level": level, "message": f"Variant '{variant_label}' representation selector matched nothing ({field_label}) / バリアントとテイク '{variant_label}' の表現セレクターに一致がありません ({field_label}): {selector}"})
                if len(selectors) == 1 and not invalid_selectors:
                    preview = preview_selector_matches(selectors, variant_collection_names, limit=4)
                    if len(preview) >= 4 and isinstance(preview[-1], str) and preview[-1].startswith('+'):
                        issues.append({"level": "WARNING", "message": f"Variant '{variant_label}' representation selector is broad ({field_label}) / バリアントとテイク '{variant_label}' の表現セレクターが広範囲です ({field_label}): {selectors[0]} -> {', '.join(preview)}"})

        variant_unknown_dir_tokens = _unknown_tokens(getattr(variant, "output_dir_pattern_override", ""), known_tokens)
        variant_unknown_file_tokens = _unknown_tokens(getattr(variant, "output_file_pattern_override", ""), known_tokens)
        if variant_unknown_dir_tokens or variant_unknown_file_tokens:
            unknown = ", ".join(variant_unknown_dir_tokens + variant_unknown_file_tokens)
            issues.append({"level": level, "message": f"Variant '{variant_label}' contains unknown output token(s) / バリアントとテイク '{variant_label}' に未知の出力トークンがあります: {unknown}"})

        if file_pattern_extension_warnings(getattr(variant, "output_file_pattern_override", "")):
            issues.append({
                "level": level,
                "message": f"Variant '{variant_label}' includes an explicit filename extension; Blender will add the actual extension automatically / バリアントとテイク '{variant_label}' のファイル名パターンに拡張子指定があります。実際の拡張子は Blender が自動付与します。",
            })

        variant_root_override = str(getattr(resolved_variant, "output_root_override", "") or "").strip()
        if variant_root_override:
            variant_root = abspath(variant_root_override)
            if not bpy.data.filepath and uses_relative_blend_path(variant_root_override):
                issues.append({"level": "WARNING", "message": f"Variant '{variant_label}' uses // in the output root while the .blend file is unsaved / バリアントとテイク '{variant_label}' は .blend 未保存のまま保存先に // を使っています。"})
            if not os.path.isdir(variant_root) and not auto_create:
                issues.append({"level": level, "message": f"Variant '{variant_label}' output root does not exist and auto-create is off / バリアントとテイク '{variant_label}' の保存先が存在せず自動作成もオフです: {variant_root}"})
            if not can_write_directory(variant_root, create=auto_create):
                issues.append({"level": level, "message": f"Variant '{variant_label}' output root is not writable / バリアントとテイク '{variant_label}' の保存先へ書き込めません: {variant_root}"})

        if getattr(resolved_variant, "color_management_mode", "SCENE") == "OVERRIDE":
            view_transform_name = str(getattr(resolved_variant, "view_transform_override", "") or "").strip()
            look_name = str(getattr(resolved_variant, "look_override", "") or "").strip()
            if view_transform_name and view_transform_keys and view_transform_name not in view_transform_keys:
                issues.append({"level": level, "message": f"Variant '{variant_label}' uses unknown View Transform / バリアントとテイク '{variant_label}' のビュー変換が不明です: {view_transform_name}"})
            if look_name and look_keys and look_name not in look_keys:
                issues.append({"level": level, "message": f"Variant '{variant_label}' uses unknown Look / バリアントとテイク '{variant_label}' のルックが不明です: {look_name}"})

    error_count = sum(1 for issue in issues if issue["level"] == "ERROR")
    warning_count = sum(1 for issue in issues if issue["level"] == "WARNING")
    risk_score = min(100, error_count * 40 + warning_count * 10)
    status = worst_severity(*(issue["level"] for issue in issues)) if issues else "INFO"

    return {
        "status": status,
        "risk_score": risk_score,
        "issues": issues,
        "camera_count": len(cameras),
        "view_layer_count": len(layers),
        "variant_count": len(variants),
        "queue_count": len(queue_items),
        "planned_renders": len(plan_sample) if not truncated else len(collect_output_targets(context, scene, settings, enabled_only=True)),
        "counts": counts,
        "missing_assets": missing_assets,
        "collisions": collisions,
        "collision_scan_truncated": truncated,
        "output_root": output_root,
    }


def manifest(scene, context) -> Dict[str, object]:
    settings = scene.srr_settings
    queue_items = effective_queue_blueprint(context, scene, settings, enabled_only=False)
    analysis = analysis_result(context, scene, settings)
    collisions, truncated, plan_sample = detect_output_collisions(context, scene, settings, enabled_only=False, sample_limit=64)
    variants_data = [serialize_variant(scene, variant) for variant in getattr(scene, "srr_variants", [])]
    queue_data = [serialize_queue_item(item) for item in queue_items]
    execution = resource_profile(settings)
    context_view_layer_name = getattr(getattr(context, "view_layer", None), "name", "")
    resolved_queue_data = []
    movie_jobs = []
    reserved_movie_paths = set()
    effective_verification_scope_value = _collision_verification_scope(scene, settings)

    for item in queue_items:
        resolved = resolved_queue_item(scene, settings, item, context_view_layer_name=context_view_layer_name)
        frames_list = [int(frame) for frame in (resolved.get("frames", []) or [scene.frame_current])]
        if not frames_list:
            frames_list = [int(scene.frame_current)]
        first_frame = int(frames_list[0])
        first_target = resolve_output(scene, settings, item, first_frame, analysis["counts"], context_view_layer_name=context_view_layer_name)
        variant = resolved["variant"]
        output_root = abspath(output_config(settings, variant=variant)["root"] or default_output_root(create=True))
        engine_identifier = str(resolved["profile"].get("actual_engine_identifier", scene.render.engine))
        job_execution = resource_profile(settings, frame_count=len(frames_list), variant=variant)
        frame_chunks = frame_chunk_specs(frames_list, int(job_execution.get("frame_chunk_size", 1) or 1))
        if not frame_chunks:
            frame_chunks = frame_chunk_specs([first_frame], 1)
        chunk_commands = []
        for chunk in frame_chunks:
            command = build_background_command_preview(
                bpy.data.filepath or "",
                engine_identifier,
                output_root,
                str(chunk.get("blender_cli_frames", chunk.get("frames_string", first_frame))),
            )
            chunk_commands.append(
                {
                    "label": f"{resolved['label']} [chunk {chunk['chunk_index']}/{chunk['chunk_total']}]",
                    "background_command": command,
                    **chunk,
                }
            )

        movie_job = None
        if bool(getattr(settings, "enable_movie_encode", False)):
            movie_job = build_movie_job(
                first_target["output_dir"],
                str(getattr(settings, "movie_file_pattern", "") or "{scene}_{variant}_{camera}_{view_layer}"),
                dict(first_target["tokens"]),
                str(getattr(settings, "movie_preset", "H264_MP4") or "H264_MP4"),
                str(first_target["full_path"]),
                int(first_frame),
                len(frames_list),
                int(getattr(settings, "sequence_padding", 4) or 4),
                str(getattr(settings, "ffmpeg_executable", "ffmpeg") or "ffmpeg"),
                bool(getattr(settings, "movie_overwrite_existing", False)),
            )
            if movie_job is not None:
                raw_movie_output = os.path.normpath(str(movie_job.get("output_path", "") or ""))
                movie_ext = os.path.splitext(raw_movie_output)[1].lstrip(".") if raw_movie_output else ""
                safe_movie_stem = raw_movie_output[:-len(movie_ext) - 1] if raw_movie_output and movie_ext else raw_movie_output
                safe_movie_stem, movie_suffix = unique_output_stem(
                    safe_movie_stem,
                    movie_ext,
                    set(reserved_movie_paths),
                    bool(getattr(settings, "movie_overwrite_existing", False)),
                )
                safe_movie_output = f"{safe_movie_stem}.{movie_ext}" if movie_ext else safe_movie_stem
                safe_movie_output = os.path.normpath(str(safe_movie_output or "")) if safe_movie_output else ""
                if safe_movie_output:
                    reserved_movie_paths.add(safe_movie_output)
                if movie_suffix:
                    movie_job["output_path"] = safe_movie_output
                    movie_job["command"] = build_ffmpeg_command(
                        str(getattr(settings, "ffmpeg_executable", "ffmpeg") or "ffmpeg"),
                        str(movie_job.get("fps", "24") or "24"),
                        str(movie_job.get("input_pattern", "") or ""),
                        safe_movie_output,
                        str(movie_job.get("preset", "H264_MP4") or "H264_MP4"),
                        bool(getattr(settings, "movie_overwrite_existing", False)),
                    )
                    movie_job["renamed_for_safety"] = True
                    movie_job["safety_suffix"] = movie_suffix
                else:
                    movie_job["renamed_for_safety"] = False
                    movie_job["safety_suffix"] = ""

                movie_jobs.append(
                    {
                        "label": resolved["label"],
                        "camera": resolved["camera_name"],
                        "view_layer": resolved["view_layer_name"],
                        "variant": getattr(variant, "name", item.get("variant_name", "")),
                        "frames": list(frames_list),
                        "resource_profile": job_execution,
                        **movie_job,
                    }
                )

        verification_plan = build_output_verification_plan(
            scene,
            str(first_target["full_path"]),
            str(first_target["output_dir"]),
            str(first_target["tokens"].get("variant", "base")),
            str(resolved["view_layer_name"]),
            int(first_frame),
            str(first_target["profile"].get("image_format", getattr(settings, "image_format", "PNG"))),
            int(getattr(settings, "sequence_padding", 4) or 4),
            effective_verification_scope_value,
        )

        resolved_queue_data.append(
            {
                "enabled": bool(item.get("enabled", True)),
                "source_mode": resolved["source_mode"],
                "camera": resolved["camera_name"],
                "view_layer": resolved["view_layer_name"],
                "variant": getattr(variant, "name", item.get("variant_name", "")),
                "parent_variant": getattr(variant, "parent_name", ""),
                "variant_chain": list(getattr(variant, "variant_chain", []) or []),
                "variant_path": getattr(variant, "variant_path", ""),
                "label": resolved["label"],
                "frames": list(frames_list),
                "frame_start": int(min(frames_list)),
                "frame_end": int(max(frames_list)),
                "frame_count": len(frames_list),
                "engine_identifier": engine_identifier,
                "job_name": job_execution.get("job_name", first_target["tokens"].get("job", "main")),
                "job_tags": list(job_execution.get("job_tags", []) or []),
                "pass_bundle": str(resolved["profile"].get("pass_bundle", getattr(settings, "pass_bundle", "ESSENTIAL")) or getattr(settings, "pass_bundle", "ESSENTIAL")),
                "render_elements": {
                    "enabled": bool(render_elements_enabled(settings)),
                    "quick_set": str(getattr(settings, "render_elements_preset", "FROM_PASS_BUNDLE") or "FROM_PASS_BUNDLE"),
                    "preset": str(getattr(settings, "render_elements_preset", "FROM_PASS_BUNDLE") or "FROM_PASS_BUNDLE"),
                    "effective_bundle": render_elements_effective_bundle(settings),
                    "output_mode": str(getattr(settings, "render_elements_output_mode", "FILES") or "FILES"),
                    "folder_name": pass_output_folder_name(settings),
                    "elements": list(effective_render_element_ids(settings)),
                    "elements_preview": render_elements_preview_names(settings),
                },
                "image_format": str(resolved["profile"].get("image_format", getattr(settings, "image_format", "PNG")) or getattr(settings, "image_format", "PNG")),
                "base_resolution_x": int(resolved["profile"].get("base_resolution_x", getattr(scene.render, "resolution_x", 1920)) or getattr(scene.render, "resolution_x", 1920) or 1920),
                "base_resolution_y": int(resolved["profile"].get("base_resolution_y", getattr(scene.render, "resolution_y", 1080)) or getattr(scene.render, "resolution_y", 1080) or 1080),
                "resolved_resolution_x": int(resolved["profile"].get("resolved_resolution_x", getattr(scene.render, "resolution_x", 1920)) or getattr(scene.render, "resolution_x", 1920) or 1920),
                "resolved_resolution_y": int(resolved["profile"].get("resolved_resolution_y", getattr(scene.render, "resolution_y", 1080)) or getattr(scene.render, "resolution_y", 1080) or 1080),
                "representation_mode": str(getattr(variant, "representation_mode", "SCENE") or "SCENE"),
                "world": str(first_target["tokens"].get("world", "") or ""),
                "material": str(first_target["tokens"].get("material", "") or ""),
                "view_transform": str(first_target["tokens"].get("view_transform", "") or ""),
                "look": str(first_target["tokens"].get("look", "") or ""),
                "output_tokens": dict(first_target["tokens"]),
                "output_directory": first_target["output_dir"],
                "first_output": first_target["full_path"],
                "background_command": build_background_command_preview(
                    bpy.data.filepath or "",
                    engine_identifier,
                    output_root,
                    str(min(frames_list)) if len(frames_list) == 1 else f"{min(frames_list)}..{max(frames_list)}",
                ),
                "resource_profile": job_execution,
                "frame_chunks": frame_chunks,
                "chunk_commands": chunk_commands,
                "movie_output": movie_job.get("output_path", "") if movie_job else "",
                "sequence_input_pattern": movie_job.get("input_pattern", "") if movie_job else "",
                "movie_command": movie_job.get("command", "") if movie_job else "",
                "verification": {
                    "enabled": bool(getattr(settings, "verify_outputs_after_render", True)),
                    "scope": verification_plan.get("scope", "PRIMARY_AND_PASSES"),
                    "min_output_size_kb": int(getattr(settings, "min_output_size_kb", 0) or 0),
                    "min_output_size_bytes": int(max(0, int(getattr(settings, "min_output_size_kb", 0) or 0)) * 1024),
                    "retry_count": int(getattr(settings, "verification_retry_count", 0) or 0),
                    "retry_delay_seconds": float(getattr(settings, "verification_retry_delay", 0.0) or 0.0),
                    "cleanup_invalid_outputs": bool(getattr(settings, "cleanup_invalid_outputs", True)),
                    "expected_output_count": int(verification_plan.get("expected_output_count", 0) or 0),
                    "expected_outputs_preview": list((verification_plan.get("paths", []) or [])[:16]),
                },
            }
        )

    data = {
        "tool": ADDON_NAME,
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "version": list(ADDON_VERSION),
        "scene": scene.name,
        "blend_file": bpy.data.filepath or "",
        "generated_at": now_local().isoformat(timespec="seconds"),
        "profile": {
            "engine_mode": settings.engine_mode,
            "quality_mode": settings.quality_mode,
            "sample_multiplier": settings.sample_multiplier,
            "resolution_percentage": settings.resolution_percentage,
            "base_resolution_x": int(getattr(scene.render, "resolution_x", 1920) or 1920),
            "base_resolution_y": int(getattr(scene.render, "resolution_y", 1080) or 1080),
            "resolved_resolution_x": int(round(float(getattr(scene.render, "resolution_x", 1920) or 1920) * (float(getattr(scene.render, "resolution_percentage", 100) or 100) / 100.0))),
            "resolved_resolution_y": int(round(float(getattr(scene.render, "resolution_y", 1080) or 1080) * (float(getattr(scene.render, "resolution_percentage", 100) or 100) / 100.0))),
            "use_denoise": settings.use_denoise,
            "use_adaptive_sampling": settings.use_adaptive_sampling,
            "use_motion_blur": settings.use_motion_blur,
            "use_freestyle": settings.use_freestyle,
            "pass_bundle": settings.pass_bundle,
            "actual_engine_identifier": scene.render.engine,
        },
        "render_elements": {
            "enabled": bool(render_elements_enabled(settings)),
            "quick_set": str(getattr(settings, "render_elements_preset", "FROM_PASS_BUNDLE") or "FROM_PASS_BUNDLE"),
            "preset": str(getattr(settings, "render_elements_preset", "FROM_PASS_BUNDLE") or "FROM_PASS_BUNDLE"),
            "effective_bundle": render_elements_effective_bundle(settings),
            "output_mode": str(getattr(settings, "render_elements_output_mode", "FILES") or "FILES"),
            "folder_name": pass_output_folder_name(settings),
            "elements": list(effective_render_element_ids(settings)),
            "elements_preview": render_elements_preview_names(settings),
        },
        "output": {
            "root": abspath(settings.output_root or default_output_root(create=True)),
            "dir_pattern": settings.output_dir_pattern,
            "file_pattern": settings.output_file_pattern,
            "image_format": str(output_config(settings).get("image_format", settings.image_format) or settings.image_format),
            "overwrite_existing": settings.overwrite_existing,
            "skip_existing_frames": settings.skip_existing_frames,
            "use_placeholder": settings.use_placeholder,
            "auto_create_folders": settings.auto_create_folders,
            "auto_unique_tokens": settings.auto_unique_tokens,
            "abort_on_collisions": settings.abort_on_collisions,
            "strict_missing_assets": settings.strict_missing_assets,
            "use_stamp": settings.use_stamp,
            "stamp_note": settings.stamp_note,
            "movie_encode_enabled": settings.enable_movie_encode,
            "movie_preset": settings.movie_preset,
            "movie_file_pattern": settings.movie_file_pattern,
            "movie_overwrite_existing": settings.movie_overwrite_existing,
            "ffmpeg_executable": settings.ffmpeg_executable,
            "job_name": settings.job_name,
            "sequence_padding": settings.sequence_padding,
        },
        "batch": {
            "frame_mode": settings.frame_mode,
            "custom_frame_start": settings.custom_frame_start,
            "custom_frame_end": settings.custom_frame_end,
            "selected_cameras_only": settings.selected_cameras_only,
            "renderable_cameras_only": settings.renderable_cameras_only,
            "view_layer_mode": settings.view_layer_mode,
            "queue_source_mode": settings.queue_source_mode,
            "queue_compositing_mode": settings.queue_compositing_mode,
            "retry_on_failure": settings.retry_on_failure,
            "retry_count": settings.retry_count,
            "halt_on_first_error": settings.halt_on_first_error,
        },
        "execution": execution,
        "verification": {
            "enabled": bool(getattr(settings, "verify_outputs_after_render", True)),
            "scope": effective_verification_scope_value,
            "min_output_size_kb": int(getattr(settings, "min_output_size_kb", 0) or 0),
            "min_output_size_bytes": int(max(0, int(getattr(settings, "min_output_size_kb", 0) or 0)) * 1024),
            "retry_count": int(getattr(settings, "verification_retry_count", 0) or 0),
            "retry_delay_seconds": float(getattr(settings, "verification_retry_delay", 0.0) or 0.0),
            "cleanup_invalid_outputs": bool(getattr(settings, "cleanup_invalid_outputs", True)),
        },
        "ui": {
            "compact_mode": settings.compact_mode,
            "show_advanced": settings.show_advanced,
        },
        "bridge": {
            "target": settings.bridge_target,
            "manifest_path": resolve_manifest_path(getattr(settings, "manifest_path", "")),
            "preview_limit": settings.preview_limit,
            "analysis_detail_limit": settings.analysis_detail_limit,
        },
        "network_render": {
            "enabled": bool(getattr(settings, "network_render_enabled", False)),
            "target": str(getattr(settings, "network_render_target", "GENERIC") or "GENERIC"),
            "manifest_path": resolve_manifest_path(getattr(settings, "manifest_path", "")),
            "shared_output_root": abspath(settings.output_root or default_output_root(create=True)),
            "frame_chunk_size": int(getattr(settings, "frame_chunk_size", 1) or 1),
            "concurrent_tasks": int(getattr(settings, "concurrent_tasks", 1) or 1),
            "execution_device_mode": str(getattr(settings, "execution_device_mode", "AUTO") or "AUTO"),
            "headless_export_expected": True,
            "bridge_export_expected": True,
        },
        "execution_preview": {
            "background_command": (
                resolved_queue_data[0]["background_command"]
                if resolved_queue_data
                else build_background_command_preview(
                    bpy.data.filepath or "",
                    scene.render.engine,
                    abspath(settings.output_root or default_output_root(create=True)),
                    frame_range_string(
                        {
                            "mode": settings.frame_mode,
                            "start": settings.custom_frame_start,
                            "end": settings.custom_frame_end,
                            "frame_current": scene.frame_current,
                        }
                    ),
                )
            ),
            "chunk_preview_count": sum(len(item.get("frame_chunks", []) or []) for item in resolved_queue_data),
        },
        "analysis": {
            "status": analysis["status"],
            "risk_score": analysis["risk_score"],
            "missing_asset_count": len(analysis["missing_assets"]),
            "collision_count": len(collisions),
            "collision_scan_truncated": truncated,
            "planned_renders": len(collect_output_targets(context, scene, settings, enabled_only=False)),
        },
        "variants": variants_data,
        "queue": queue_data,
        "resolved_queue": resolved_queue_data,
        "detected_scene_assets": {
            "cameras": [cam.name for cam in available_cameras(context, settings)],
            "view_layers": [layer_item.name for layer_item in available_view_layers(context, settings)],
            "queue": queue_data,
            "planned_outputs_sample": [
                {
                    "path": target["full_path"],
                    "camera": target["camera_name"],
                    "view_layer": target["view_layer_name"],
                    "variant": target["tokens"].get("variant", ""),
                    "frame": target["frame"],
                }
                for target in plan_sample
            ],
            "collision_paths_sample": [path for path, _bucket in collisions[:24]],
        },
        "post_tasks": {
            "ffmpeg_enabled": bool(settings.enable_movie_encode),
            "ffmpeg_jobs": movie_jobs,
            "ffmpeg_renamed_count": sum(1 for item in movie_jobs if bool(item.get("renamed_for_safety", False))),
        },
        "token_examples": {
            "available_tokens": list(AVAILABLE_OUTPUT_TOKENS),
            "token_reference": token_reference(),
        },
    }
    data["task_graph"] = task_graph_from_manifest(data)
    return data


def snapshot_render_state(scene, view_layer_obj=None) -> Dict[str, object]:
    state = {
        "camera_name": getattr(scene.camera, "name", ""),
        "frame_current": int(scene.frame_current),
        "world_name": getattr(scene.world, "name", ""),
        "render_engine": scene.render.engine,
        "resolution_x": int(getattr(scene.render, "resolution_x", 1920) or 1920),
        "resolution_y": int(getattr(scene.render, "resolution_y", 1080) or 1080),
        "resolution_percentage": int(scene.render.resolution_percentage),
        "filepath": str(scene.render.filepath),
        "use_file_extension": bool(scene.render.use_file_extension),
        "use_overwrite": bool(scene.render.use_overwrite),
        "use_placeholder": bool(getattr(scene.render, "use_placeholder", False)),
        "use_compositing": bool(getattr(scene.render, "use_compositing", False)),
        "use_nodes": bool(getattr(scene, "use_nodes", False)),
        "compositing_node_group_name": getattr(compositor_node_tree(scene), "name", ""),
        "file_output_mute": [(node, bool(node.mute))
                             for node in getattr(compositor_node_tree(scene), 'nodes', ())
                             if node.bl_idname == 'CompositorNodeOutputFile'],
        "image_format": str(scene.render.image_settings.file_format),
        "use_stamp": bool(getattr(scene.render, "use_stamp", False)),
        "stamp_note_text": str(getattr(scene.render, "stamp_note_text", "")),
        "use_motion_blur": bool(getattr(scene.render, "use_motion_blur", False)),
        "use_freestyle": bool(getattr(scene.render, "use_freestyle", False)),
        "film_transparent": bool(getattr(scene.render, "film_transparent", False)),
        "object_hide_render": snapshot_object_render_visibility(scene),
    }
    if hasattr(scene, "cycles"):
        state["cycles_samples"] = safe_get_attr(scene.cycles, "samples")
        state["cycles_preview_samples"] = safe_get_attr(scene.cycles, "preview_samples")
        state["cycles_use_adaptive_sampling"] = safe_get_attr(scene.cycles, "use_adaptive_sampling")
        state["cycles_use_denoising"] = safe_get_attr(scene.cycles, "use_denoising")
        state["cycles_device"] = safe_get_attr(scene.cycles, "device")
    if hasattr(scene, "eevee"):
        state["eevee_taa_render_samples"] = safe_get_attr(scene.eevee, "taa_render_samples")
        state["eevee_taa_samples"] = safe_get_attr(scene.eevee, "taa_samples")
        state["eevee_use_gtao"] = safe_get_attr(scene.eevee, "use_gtao")
        state["eevee_use_bloom"] = safe_get_attr(scene.eevee, "use_bloom")
        state["eevee_use_motion_blur"] = safe_get_attr(scene.eevee, "use_motion_blur")
    view_settings = getattr(scene, "view_settings", None)
    if view_settings is not None:
        state["view_transform"] = safe_get_attr(view_settings, "view_transform")
        state["look"] = safe_get_attr(view_settings, "look")
        state["exposure"] = safe_get_attr(view_settings, "exposure")
        state["gamma"] = safe_get_attr(view_settings, "gamma")
    if view_layer_obj is not None:
        state["view_layer_name"] = view_layer_obj.name
        state["material_override_name"] = getattr(getattr(view_layer_obj, "material_override", None), "name", "")
        state["view_layer_denoise"] = safe_get_attr(getattr(view_layer_obj, "cycles", None), "use_denoising")
        state["layer_flags"] = snapshot_layer_collection_flags(view_layer_obj)
        state["pass_state"] = {
            prop_name: safe_get_attr(view_layer_obj, prop_name)
            for prop_name in PASS_PROPERTY_NAMES
            if hasattr(view_layer_obj, prop_name)
        }
    return state



def restore_render_state(scene, state: Dict[str, object], view_layer_obj=None) -> None:
    if not state:
        return
    for node, muted in state.get('file_output_mute', ()):
        try:
            node.mute = muted
        except ReferenceError:
            pass  # An output removed during the queue is not recreated.
    restored_camera = scene_object(scene, state.get("camera_name", ""), type_hint="CAMERA")
    set_scene_camera(scene, restored_camera, clear_if_none=True)
    safe_set_attr(scene.render, "engine", state.get("render_engine"))
    safe_set_attr(scene.render, "resolution_x", state.get("resolution_x"))
    safe_set_attr(scene.render, "resolution_y", state.get("resolution_y"))
    safe_set_attr(scene.render, "resolution_percentage", state.get("resolution_percentage"))
    safe_set_attr(scene.render, "filepath", state.get("filepath"))
    safe_set_attr(scene.render, "use_file_extension", state.get("use_file_extension"))
    safe_set_attr(scene.render, "use_overwrite", state.get("use_overwrite"))
    safe_set_attr(scene.render, "use_placeholder", state.get("use_placeholder"))
    safe_set_attr(scene.render, "use_compositing", state.get("use_compositing"))
    safe_set_attr(scene, "use_nodes", state.get("use_nodes"))
    if hasattr(scene, "compositing_node_group"):
        group_name = str(state.get("compositing_node_group_name", "") or "")
        node_group = None
        try:
            node_group = bpy.data.node_groups.get(group_name) if group_name else None
        except Exception:
            node_group = None
        safe_set_attr(scene, "compositing_node_group", node_group)
    set_image_file_format(scene.render.image_settings, state.get("image_format"))
    safe_set_attr(scene.render, "use_stamp", state.get("use_stamp"))
    safe_set_attr(scene.render, "stamp_note_text", state.get("stamp_note_text"))
    safe_set_attr(scene.render, "use_motion_blur", state.get("use_motion_blur"))
    safe_set_attr(scene.render, "use_freestyle", state.get("use_freestyle"))
    safe_set_attr(scene.render, "film_transparent", state.get("film_transparent"))
    restore_object_render_visibility(scene, state.get("object_hide_render", {}))
    if hasattr(scene, "cycles"):
        safe_set_attr(scene.cycles, "samples", state.get("cycles_samples"))
        safe_set_attr(scene.cycles, "preview_samples", state.get("cycles_preview_samples"))
        safe_set_attr(scene.cycles, "use_adaptive_sampling", state.get("cycles_use_adaptive_sampling"))
        safe_set_attr(scene.cycles, "use_denoising", state.get("cycles_use_denoising"))
        safe_set_attr(scene.cycles, "device", state.get("cycles_device"))
    if hasattr(scene, "eevee"):
        safe_set_attr(scene.eevee, "taa_render_samples", state.get("eevee_taa_render_samples"))
        safe_set_attr(scene.eevee, "taa_samples", state.get("eevee_taa_samples"))
        safe_set_attr(scene.eevee, "use_gtao", state.get("eevee_use_gtao"))
        safe_set_attr(scene.eevee, "use_bloom", state.get("eevee_use_bloom"))
        safe_set_attr(scene.eevee, "use_motion_blur", state.get("eevee_use_motion_blur"))
    safe_set_attr(scene, "world", world_by_name(state.get("world_name", "")))
    view_settings = getattr(scene, "view_settings", None)
    if view_settings is not None:
        safe_set_attr(view_settings, "view_transform", state.get("view_transform"))
        safe_set_attr(view_settings, "look", state.get("look"))
        safe_set_attr(view_settings, "exposure", state.get("exposure"))
        safe_set_attr(view_settings, "gamma", state.get("gamma"))
    scene.frame_set(int(state.get("frame_current", scene.frame_current)))
    if view_layer_obj is not None:
        safe_set_attr(view_layer_obj, "material_override", material_by_name(state.get("material_override_name", "")))
        safe_set_attr(getattr(view_layer_obj, "cycles", None), "use_denoising", state.get("view_layer_denoise"))
        restore_layer_collection_flags(view_layer_obj, state.get("layer_flags", {}))
        for prop_name, value in (state.get("pass_state", {}) or {}).items():
            safe_set_attr(view_layer_obj, prop_name, value)



def quality_sample_values(engine_mode: str, quality_mode: str) -> Tuple[int, int]:
    if engine_mode == "CYCLES":
        base = {"DRAFT": 32, "PREVIEW": 96, "FINAL": 512}.get(quality_mode, 96)
        return base, max(1, base // 2)
    if engine_mode == "EEVEE":
        base = {"DRAFT": 8, "PREVIEW": 32, "FINAL": 128}.get(quality_mode, 32)
        return base, max(1, base // 2)
    return 0, 0



def apply_profile(scene, settings, variant=None, target_layers: Optional[Sequence] = None, logger=None) -> Dict[str, object]:
    profile = resolved_profile(settings, scene, variant=variant)
    requested_identifier = profile["requested_engine_identifier"]
    if requested_identifier:
        try:
            scene.render.engine = requested_identifier
        except Exception as ex:
            if logger:
                logger("WARNING", f"Engine not available: {requested_identifier} ({ex})")
    safe_set_attr(scene.render, "resolution_x", int(profile["base_resolution_x"]))
    safe_set_attr(scene.render, "resolution_y", int(profile["base_resolution_y"]))
    scene.render.resolution_percentage = int(profile["resolution_percentage"])
    scene.render.use_file_extension = True
    scene.render.use_overwrite = bool(settings.overwrite_existing)
    safe_set_attr(scene.render, "use_placeholder", bool(settings.use_placeholder))
    set_image_file_format(scene.render.image_settings, profile["image_format"])
    safe_set_attr(scene.render, "use_freestyle", bool(profile["use_freestyle"]))
    safe_set_attr(scene.render, "use_stamp", bool(settings.use_stamp))
    if bool(settings.use_stamp):
        safe_set_attr(scene.render, "use_stamp_camera", True)
        safe_set_attr(scene.render, "use_stamp_scene", True)
        safe_set_attr(scene.render, "use_stamp_frame", True)
        safe_set_attr(scene.render, "use_stamp_render_time", True)
        safe_set_attr(scene.render, "stamp_note_text", profile["stamp_note"])

    actual_engine_mode = engine_mode_from_identifier(scene.render.engine)
    device_preview = apply_local_execution_device(scene, settings, variant=variant, logger=logger)
    profile["local_execution_device"] = device_preview
    samples, preview_samples = quality_sample_values(actual_engine_mode, str(profile["quality_mode"]))
    multiplier = max(0.1, float(profile["sample_multiplier"]))

    if actual_engine_mode == "CYCLES" and hasattr(scene, "cycles"):
        safe_set_attr(scene.cycles, "samples", max(1, int(samples * multiplier)))
        safe_set_attr(scene.cycles, "preview_samples", max(1, int(preview_samples * multiplier)))
        safe_set_attr(scene.cycles, "use_adaptive_sampling", bool(profile["use_adaptive_sampling"]))
        safe_set_attr(scene.cycles, "use_denoising", bool(profile["use_denoise"]))
        safe_set_attr(scene.render, "use_motion_blur", bool(profile["use_motion_blur"]))
        for layer_item in pass_bundle_target_layers(scene, target_layers):
            safe_set_attr(getattr(layer_item, "cycles", None), "use_denoising", bool(profile["use_denoise"]))
    elif actual_engine_mode == "EEVEE" and hasattr(scene, "eevee"):
        safe_set_attr(scene.eevee, "taa_render_samples", max(1, int(samples * multiplier)))
        safe_set_attr(scene.eevee, "taa_samples", max(1, int(preview_samples * multiplier)))
        safe_set_attr(scene.eevee, "use_gtao", profile["quality_mode"] != "DRAFT")
        safe_set_attr(scene.eevee, "use_bloom", profile["quality_mode"] == "FINAL")
        safe_set_attr(scene.eevee, "use_motion_blur", bool(profile["use_motion_blur"]))
        safe_set_attr(scene.render, "use_motion_blur", bool(profile["use_motion_blur"]))
    elif actual_engine_mode == "WORKBENCH":
        aa_keys = enum_keys(scene.display, "render_aa") if hasattr(scene, "display") else []
        preference_map = {
            "DRAFT": ["OFF", "FXAA"],
            "PREVIEW": ["FXAA", "5", "8"],
            "FINAL": ["8", "16", "32"],
        }
        for candidate in preference_map.get(str(profile["quality_mode"]), []):
            if candidate in aa_keys:
                safe_set_attr(scene.display, "render_aa", candidate)
                break

    if render_elements_enabled(settings):
        effective_bundle = apply_render_elements_preset(scene, settings, target_layers=target_layers)
        set_image_file_format(scene.render.image_settings, render_elements_image_format(settings))
        profile["pass_bundle"] = effective_bundle
        profile["image_format"] = str(getattr(scene.render.image_settings, "file_format", profile.get("image_format", "OPEN_EXR")) or profile.get("image_format", "OPEN_EXR"))
    elif str(profile["pass_bundle"]) != "NONE":
        apply_pass_bundle(scene, str(profile["pass_bundle"]), target_layers=target_layers)
    return profile
