# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
import re
import sys

_JA_RE = re.compile(r"[ぁ-んァ-ヴー一-龠々]")
_TRANSLATIONS_REGISTERED = False


_CATALOG_EN_TO_JA: dict[str, str] | None = None
_CATALOG_JA_TO_EN: dict[str, str] | None = None
_SOURCE_PAIRS: dict[str, str] = {}
_SOURCE_PAIRS_DIRTY = False
_ITEM_PAIRS: dict[str, str] = {}
PROPERTY_CONTEXT = "Smart Render"


def _catalog_en_to_ja() -> dict[str, str]:
    global _CATALOG_EN_TO_JA
    if _CATALOG_EN_TO_JA is None:
        table: dict[str, str] = {}
        try:
            from .language_extra import EXTRA_TRANSLATIONS  # type: ignore
            table.update({key[1]: value for key, value in EXTRA_TRANSLATIONS.items() if isinstance(key, tuple)})
        except Exception:
            pass
        try:
            from .translation_catalog import EN_TO_JA  # type: ignore
            table.update(EN_TO_JA)
        except Exception:
            return {}
        _CATALOG_EN_TO_JA = table
    return _CATALOG_EN_TO_JA


def _catalog_ja_to_en() -> dict[str, str]:
    global _CATALOG_JA_TO_EN
    if _CATALOG_JA_TO_EN is None:
        _CATALOG_JA_TO_EN = {ja: en for en, ja in _catalog_en_to_ja().items() if ja and en}
    return _CATALOG_JA_TO_EN


def source_text(ja: str, en: str) -> str:
    """Text for data Blender keeps after registration (labels, enum items, descriptions).

    The English text is the source and the Japanese text goes in the translation
    table, so what is shown follows Blender's current language instead of the
    language at the time the module was imported.
    """
    global _SOURCE_PAIRS_DIRTY
    ja_text = str(ja or "")
    en_text = str(en or "")
    if not en_text:
        return ja_text
    if ja_text and ja_text != en_text and _SOURCE_PAIRS.get(en_text) != ja_text:
        _SOURCE_PAIRS[en_text] = ja_text
        _SOURCE_PAIRS_DIRTY = True
    return en_text


def _blender_locale() -> str:
    try:
        import bpy  # type: ignore

        prefs = getattr(getattr(getattr(bpy, "context", None), "preferences", None), "view", None)
        language = str(getattr(prefs, "language", "") or "").strip()
        if language and language.upper() not in {"DEFAULT", "AUTO", "DEFAULT_AUTO"}:
            return language

        return str(getattr(bpy.app.translations, "locale", "") or "")
    except Exception:
        return ""


def _context_settings():
    try:
        import bpy  # type: ignore

        scene = getattr(getattr(bpy, "context", None), "scene", None)
        if scene is not None:
            settings = getattr(scene, "srr_settings", None)
            if settings is not None:
                return settings
    except Exception:
        pass
    return None


def _settings_language_value(settings=None) -> str:
    candidates = [settings]
    if settings is None:
        context_settings = _context_settings()
        if context_settings is not None:
            candidates.append(context_settings)
    try:
        nested = getattr(settings, "srr_settings", None)
    except Exception:
        nested = None
    if nested is not None and nested is not settings:
        candidates.append(nested)

    for candidate in candidates:
        try:
            value = str(getattr(candidate, "ui_language", "") or "").strip().upper()
        except Exception:
            value = ""
        if value in {"AUTO", "JA", "EN", "BILINGUAL"}:
            return value
    return "AUTO"


def locale_mode(settings=None) -> str:
    language_mode = _settings_language_value(settings)
    if language_mode == "JA":
        return "ja"
    if language_mode == "EN":
        return "en"
    # "BILINGUAL" is kept only for backward compatibility with saved data.
    # It resolves to a single current UI language and never displays both.
    locale = _blender_locale().lower()
    return "ja" if locale.startswith("ja") else "en"


def is_japanese_locale(settings=None) -> bool:
    return locale_mode(settings) == "ja"


def contains_japanese(text: str) -> bool:
    return bool(_JA_RE.search(str(text or "")))


def localize_pair(ja: str, en: str, settings=None) -> str:
    ja_text = str(ja or "").strip()
    en_text = str(en or "").strip()
    if is_japanese_locale(settings):
        return ja_text or en_text
    return en_text or ja_text


def _inline_split_candidates(value: str):
    sep = " / "
    parts = value.split(sep)
    if len(parts) < 2:
        return []
    candidates = []
    for index in range(1, len(parts)):
        left = sep.join(parts[:index]).strip()
        right = sep.join(parts[index:]).strip()
        if not left or not right:
            continue
        left_has_ja = contains_japanese(left)
        right_has_ja = contains_japanese(right)
        if left_has_ja == right_has_ja:
            continue
        # Multiple separators are accepted only for short label-like strings.
        # This prevents Japanese explanations that contain technical slash terms
        # from being cut in half accidentally.
        if len(parts) > 2 and len(value) > 100:
            continue
        ja = left if left_has_ja else right
        en = right if left_has_ja else left
        if len(parts) > 2 and (re.search(r"[ぁ-ん]", ja) or any(mark in ja for mark in "。！？")):
            continue
        score = 10 if len(parts) == 2 else 0
        if len(value) <= 80:
            score += 8
        if sep not in ja:
            score += 6
        # For multi-slash labels such as "Variants and Takes / バリアントとテイク",
        # the Japanese side should usually be the final compact segment.
        score += min(6, len(_JA_RE.findall(ja)))
        score -= len(re.findall(r"[A-Za-z]", ja)) / 8.0
        score -= abs(len(left) - len(right)) / 32.0
        candidates.append((score, ja, en))
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates


def parse_inline_bilingual(text: str) -> tuple[str, str] | None:
    value = str(text or "").strip()
    if not value:
        return None
    # smarttools-ui-style: migration-alias
    if value.startswith("JP:") and " / EN:" in value:
        # smarttools-ui-style: migration-alias
        ja_part, en_part = value[3:].split(" / EN:", 1)
        return ja_part.strip(), en_part.strip()
    # smarttools-ui-style: migration-alias
    if value.startswith("EN:") and " / JP:" in value:
        # smarttools-ui-style: migration-alias
        en_part, ja_part = value[3:].split(" / JP:", 1)
        return ja_part.strip(), en_part.strip()
    candidates = _inline_split_candidates(value)
    if candidates:
        _, ja, en = candidates[0]
        return ja.strip(), en.strip()
    return None



_DYNAMIC_JA_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = tuple(
    (re.compile(pattern), replacement)
    for pattern, replacement in (
        (r"^(\d+) frame\(s\)  \[(.+)\]$", r"\1 フレーム  [\2]"),
        (r"^(.+?)  Rendering in background…$", r"\1  バックグラウンドでレンダー中…"),
        (r"^Preset: (.+)$", r"プリセット: \1"),
        (r"^Profiling \(Viewport\)$", r"計測中（ビューポート）"),
        (r"^Profiling \(Render\)$", r"計測中（レンダー）"),
        (r"^Profiling \(Off\)$", r"計測中（オフ）"),
        (r"^Profiling \((.+)\)$", r"計測中（\1）"),
        (r"^A preset named '(.+)' already exists\.$", r"「\1」という名前のプリセットは既に存在します。"),
        (r"^Runtime settings draw failed: (.+)$", r"ランタイム設定の描画に失敗しました: \1"),
        (r"^Root panel draw failed: (.+)$", r"ルートパネルの描画に失敗しました: \1"),
        (r"^Proxy draw failed: (.+)$", r"プロキシ描画に失敗しました: \1"),
        (r"^Extra draw failed: (.+)$", r"追加UIの描画に失敗しました: \1"),
        (r"^Benchmark is complete, optimal number of instances is (.+) with (.+) seconds per frame$", r"ベンチマーク完了。最適インスタンス数は \1、1フレームあたり \2 秒です"),
        (r"^All instances finished in (.+) s at (.+) seconds per frame$", r"全インスタンスが \1 秒で完了しました。1フレームあたり \2 秒です"),
        (r"^Rendering: (.+) active$", r"レンダー中: アクティブ \1 件"),
        (r"^Ready\. Spent (.+) seconds with (.+) seconds per frame$", r"準備完了。合計 \1 秒、1フレームあたり \2 秒です"),
        (r"^Ready$", r"準備完了"),
        (r"^Optimal found: (.+)$", r"最適値を検出: \1"),
        (r"^Local Settings \((.+) only\)$", r"ローカル設定（\1 のみ）"),
        (r"^From (.+) selected Collection\(s\), copy$", r"選択コレクション \1 件からコピー"),
        (r"^To the following View Layers$", r"以下のビューレイヤーへ"),
        (r"^Successfully applied (.+) settings\.$", r"設定 \1 件を適用しました。"),
        (r"^Successfully applied (.+) settings\. \(Auto-corrected (.+) properties\.\)$", r"設定 \1 件を適用しました（プロパティ \2 件を自動補正）。"),
        (r"^Applied (.+) settings, (.+) failed, (.+) skipped \(blacklist\)\. Check System Console\.$", r"設定 \1 件を適用、\2 件が失敗、ブラックリストにより \3 件をスキップしました。システムコンソールを確認してください。"),
        (r"^Applied (.+) settings, (.+) failed\. Check System Console\.$", r"設定 \1 件を適用、\2 件が失敗しました。システムコンソールを確認してください。"),
        (r"^Applied (.+) settings, (.+) skipped \(blacklist\)\. Check System Console\.$", r"設定 \1 件を適用、ブラックリストにより \2 件をスキップしました。システムコンソールを確認してください。"),
        (r"^(.+) failed, (.+) skipped \(blacklist\)\. Check System Console\.$", r"\1 件が失敗、ブラックリストにより \2 件をスキップしました。システムコンソールを確認してください。"),
        (r"^(.+) failed\. Check System Console\.$", r"\1 件が失敗しました。システムコンソールを確認してください。"),
        (r"^(.+) skipped \(blacklist\)\. Check System Console\.$", r"ブラックリストにより \1 件をスキップしました。システムコンソールを確認してください。"),
        (r"^Template reset to default$", r"テンプレートを既定値に戻しました"),
        (r"^Template is empty$", r"テンプレートが空です"),
        (r"^Render Naming is disabled$", 'レンダー命名は無効です'),
        (r"^Please enter a preset name$", r"プリセット名を入力してください"),
        (r"^No preset selected$", r"プリセットが選択されていません"),
        (r"^Must select at least one render layer node$", r"少なくとも1つのレンダーレイヤーノードを選択してください"),
        (r"^No properties to Copy/Paste, please check at least one option$", r"コピー/貼り付けするプロパティがありません。少なくとも1つのオプションを選択してください"),
        (r"^Please first copy a View Layer$", r"先にビューレイヤーをコピーしてください"),
        (r"^Render Elements updated: (.+) item\(s\)$", r"レンダーエレメントを更新しました: \1 件"),
        (r"^Prepared: queue=(.+) audit=(.+)$", r"準備しました: キュー=\1 診断=\2"),
        (r"^Workflow recipe applied: (.+)$", r"ワークフローレシピを適用しました: \1"),
        (r"^Audit complete: (.+)$", r"診断完了: \1"),
        (r"^Queue synced: (.+)$", r"キューを同期しました: \1"),
        (r"^Render Elements ready: (.+) element\(s\)$", r"レンダーエレメントを準備しました: \1 件"),
        (r"^Network render package exported: (.+)$", r"ネットワークレンダーパッケージを書き出しました: \1"),
        (r"^Bridge JSON exported: (.+)$", r"ブリッジ JSON を書き出しました: \1"),
        (r"^Variant added: (.+)$", r"バリアントとテイクを追加しました: \1"),
        (r"^Child variant added: (.+)$", r"子バリアントとテイクを追加しました: \1"),
        (r"^Variant applied: (.+)$", r"バリアントとテイクを適用しました: \1"),
        (r"^Auto repair applied: (.+) change\(s\)\.$", r"自動整理を適用しました: \1 件"),
        (r"^Variant camera not found: (.+)$", r"バリアントとテイクのカメラが見つかりません: \1"),
        (r"^Unable to assign variant camera: (.+)$", r"バリアントとテイクのカメラを割り当てられません: \1"),
        (r"^Operator invoke failed: (.+)$", r"オペレーターの呼び出しに失敗しました: \1"),
        (r"^Operator not found: (.+)$", r"オペレーターが見つかりません: \1"),
        (r"^Menu invoke failed: (.+)$", r"メニューの呼び出しに失敗しました: \1"),
        (r"^Group rebuild skipped: (.+)$", r"グループ再構築をスキップしました。"),
        (r"^Legacy version check skipped: (.+)$", r"旧版チェックをスキップしました。"),
        (r"^Launched (.+) render instances\.$", r"レンダーインスタンスを起動しました: \1 件"),
        (r"^Failed to launch instance (.+): (.+)$", r"インスタンス \1 の起動に失敗しました。"),
        (r"^Report opened: (.+)$", r"レポートを開きました: \1"),
        (r"^Copied (.+) to clipboard$", r"クリップボードへコピーしました: \1"),
        (r"^Copied: (.+)$", r"コピーしました: \1"),
        (r"^Render path set to: (.+)$", r"レンダーパスを設定しました: \1"),
        (r"^Preset '(.+)' saved$", r"プリセット「\1」を保存しました"),
        (r"^Preset '(.+)' loaded$", r"プリセット「\1」を読み込みました"),
        (r"^Preset '(.+)' deleted$", r"プリセット「\1」を削除しました"),
        (r"^Preset '(.+)' not found$", r"プリセット「\1」が見つかりません"),
        (r"^Could not delete preset '(.+)'$", r"プリセット「\1」を削除できませんでした"),
        (r"^Imported preset '(.+)'$", r"プリセット「\1」を読み込みました"),
        (r"^Exported to (.+)$", r"書き出しました: \1"),
        (r"^Failed to import: (.+)$", r"読み込みに失敗しました。"),
        (r"^Failed to export: (.+)$", r"書き出しに失敗しました。"),
        (r"^Enable only (.+) active View Layers for rendering$", r"レンダー対象をアクティブなビューレイヤー \1 件のみにしました"),
        (r"^Enable only (.+) selected View Layers for rendering$", r"レンダー対象を選択ビューレイヤー \1 件のみにしました"),
        (r"^Switched to '(.+)' View Layer$", r"ビューレイヤー「\1」へ切り替えました"),
        (r"^Switched to '(.+)'$", r"「\1」へ切り替えました"),
        (r"^Set '(.+)' as copy source$", r"「\1」をコピー元に設定しました"),
        (r"^Pasted properties from '(.+)' to '(.+)'$", r"「\1」から「\2」へプロパティを貼り付けました"),
        (r"^Copied (.+) Layer Collections settings to (.+) View Layers$", r"レイヤーコレクション設定 \1 件をビューレイヤー \2 件へコピーしました"),
        (r"^Enabled selected (.+) View Layers for rendering$", r"選択ビューレイヤー \1 件をレンダー対象にしました"),
        (r"^Disabled selected (.+) View Layers from rendering$", r"選択ビューレイヤー \1 件をレンダー対象から外しました"),
        (r"^Enabled all (.+) View Layers for rendering$", r"全ビューレイヤー \1 件をレンダー対象にしました"),
        (r"^Disabled all (.+) View Layers from rendering$", r"全ビューレイヤー \1 件をレンダー対象から外しました"),
        (r"^Could not find scene '(.+)' and View Layer '(.+)'$", r"シーン「\1」とビューレイヤー「\2」が見つかりません"),
        (r"^Already on '(.+)' View Layer$", r"すでにビューレイヤー「\1」です"),
        (r"^Source '(.+)' View Layer is missing, please new View Layer$", r"コピー元ビューレイヤー「\1」がありません。新しいビューレイヤーを作成してください"),
        (r"^Target View Layer '(.+)' is already the source$", r"対象ビューレイヤー「\1」はすでにコピー元です"),
        (r"^Operator property 'direction' should be in 'UP', 'DOWN', 'TOP' or 'BOTTOM', got '(.+)'$", "オペレーターの向きプロパティは 'UP', 'DOWN', 'TOP', 'BOTTOM' のいずれかが必要です。現在値: \\1"),
        (r"^Preset '(.+)' was successfully removed\.$", r"プリセット「\1」を削除しました。"),
        (r"^Failed to remove preset: (.+)$", r"プリセットの削除に失敗しました。"),
        (r"^Audit complete\. Report saved to Text Editor: '(.+)'$", r"監査完了。レポートをテキストエディター「\1」に保存しました"),
        (r"^Generated list in Text Editor: '(.+)'$", r"テキストエディター「\1」にリストを生成しました"),
        (r"^Fuzz Test complete! Randomized (.+) properties\.$", r"ファズテスト完了。プロパティ \1 件をランダム化しました。"),
        (r"^Invalid source or no active (.+)$", r"ソースが無効、またはアクティブな \1 がありません"),
        (r"^Invalid Filter Path: (.+)$", r"フィルターパスが無効です: \1"),
        (r"^Failed to load preset file: (.+)$", r"プリセットファイルの読み込みに失敗しました。"),
        (r"^Applied (.+) settings from '(.+)'\.$", r"「\2」から設定 \1 件を適用しました。"),
        (r"^Preset file not found at: (.+)$", r"プリセットファイルが見つかりません: \1"),
        (r"^Failed to read preset file: (.+)$", r"プリセットファイルの読み込みに失敗しました。"),
        (r"^Failed to apply preset: (.+)$", r"プリセットの適用に失敗しました。"),
        (r"^Undo successful\. Restored (.+) settings\.$", r"元に戻しました。設定 \1 件を復元しました。"),
        (r"^Directory not found: (.+)$", r"ディレクトリが見つかりません: \1"),
        (r"^Failed to load default preset file: (.+)$", r"既定プリセットファイルを読み込めませんでした。"),
        (r"^Error reading presets folder: (.+)$", r"プリセットフォルダーを読み取れませんでした。"),
        (r"^Failed to load preset: (.+)$", r"プリセットの読み込みに失敗しました。"),
        (r"^Missing (.+) \[(.+)\]: (.+)$", r"見つかりません（\1・\2）: \3"),
        (r"^Collision \[(.+)x\]: (.+) :: (.+)$", r"保存先が重なっています（\1 回）: \2 / \3"),
        (r"^Render Profile applied: (.+)$", r"レンダープロファイルを適用しました: \1"),
        (r"^Pass Bundle applied: (.+)$", r"パスバンドルを適用しました: \1"),
        (r"^Queue item added: (.+)$", r"キュー項目を追加しました: \1"),
        (r"^Queue item duplicated: (.+)$", r"キュー項目を複製しました: \1"),
        (r"^Queue item removed: (.+)$", r"キュー項目を削除しました: \1"),
        (r"^Queue item moved up: (.+)$", r"キュー項目を上へ動かしました: \1"),
        (r"^Queue item moved down: (.+)$", r"キュー項目を下へ動かしました: \1"),
        (r"^Render Elements output folder: (.+)$", r"レンダーエレメントの保存先: \1"),
        (r"^Render Elements preview: (.+)$", r"書き出すレンダーエレメント: \1"),
        (r"^Compositor outputs prepared: (.+) layer\(s\), (.+) socket link\(s\), (.+) node\(s\)\.?$", r"コンポジターの出力を準備しました: レイヤー \1・つなぎ \2・ノード \3"),
        (r"^Compositor outputs updated: (.+) layer\(s\), (.+) socket link\(s\), (.+) node\(s\) created\.?$", r"コンポジターの出力を更新しました: レイヤー \1・つなぎ \2・作ったノード \3"),
        (r"^Prepared Render Elements for network export: (.+) layer\(s\), (.+) socket link\(s\), (.+) node\(s\)\.?$", r"ネットワーク書き出し用にレンダーエレメントを準備しました: レイヤー \1・つなぎ \2・ノード \3"),
        (r"^Auto-built compositor outputs for queue: (.+) layer\(s\), (.+) link\(s\), (.+) node\(s\)\.?$", r"キューのためにコンポジターの出力を作りました: レイヤー \1・つなぎ \2・ノード \3"),
        (r"^Network manifest exported: (.+)$", r"ネットワーク用マニフェストを書き出しました: \1"),
        (r"^Network bridge JSON exported: (.+)$", r"ネットワーク用ブリッジ JSON を書き出しました: \1"),
        (r"^Network shell script exported: (.+)$", r"ネットワーク用シェルスクリプトを書き出しました: \1"),
        (r"^Network batch script exported: (.+)$", r"ネットワーク用バッチを書き出しました: \1"),
        (r"^Network bundle summary exported: (.+)$", r"ネットワーク用の概要を書き出しました: \1"),
        (r"^Manifest exported: (.+)$", r"マニフェストを書き出しました: \1"),
        (r"^Manifest imported: (.+)$", r"マニフェストを読み込みました: \1"),
        (r"^Headless shell script exported: (.+)$", r"ヘッドレス用シェルスクリプトを書き出しました: \1"),
        (r"^Headless batch script exported: (.+)$", r"ヘッドレス用バッチを書き出しました: \1"),
        (r"^Headless job count: (.+)$", r"ヘッドレスのジョブ数: \1"),
        (r"^FFmpeg post-task count: (.+)$", r"FFmpeg の後処理の数: \1"),
        (r"^Variant duplicated: (.+)$", r"バリアントとテイクを複製しました: \1"),
        (r"^Variant removed: (.+)$", r"バリアントとテイクを削除しました: \1"),
        (r"^Captured overrides into variant: (.+)$", r"上書きをバリアントとテイクに取り込みました: \1"),
        (r"^Variant applied to scene: (.+)$", r"バリアントとテイクをシーンに適用しました: \1"),
        (r"^Removed parent variant '(.+)'\. Cleared parent link on (.+) child variant\(s\)\.$", r"親のバリアントとテイク「\1」を削除し、子 \2 件の親の指定を外しました。"),
        (r"^Variant references missing collection\(s\): (.+)$", r"バリアントとテイクが、無いコレクションを指しています: \1"),
        (r"^Render queue start: (.+) job\(s\)$", r"レンダーキューを開始: \1 件"),
        (r"^Retry policy: retries=(.+), halt_on_first_error=True$", r"再試行の設定: 回数 \1・最初のエラーで止める"),
        (r"^Retry policy: retries=(.+), halt_on_first_error=False$", r"再試行の設定: 回数 \1・エラーでも続ける"),
        (r"^Queue compositing mode: (.+)$", r"キューのコンポジット: \1"),
        (r"^Effective verification scope: (.+)$", r"実際の検証範囲: \1"),
        (r"^Verification retry policy: retries=(.+), delay=(.+)s$", r"検証の再試行: 回数 \1・間隔 \2 秒"),
        (r"^\.\.\.and (.+) more issue\(s\)\.$", r"ほかに \1 件あります。"),
        (r"^\.\.\.and (.+) more recipe change\(s\)\.$", r"ほかに \1 件の変更があります。"),
        (r"^\.\.\.and (.+) more repair\(s\)\.$", r"ほかに \1 件の整理があります。"),
        (r"^\.\.\.and (.+) more planned output\(s\)\.$", r"ほかに \1 件の出力があります。"),
        (r"^Workflow recipe already matched current settings: (.+)$", r"ワークフローレシピは今の設定と同じです: \1"),
        (r"^Auto repair applied: (.+) change\(s\)$", r"自動整理を適用しました: \1 件"),
        (r"^Auto repair found no safe changes to apply\.$", r"自動整理で直せる所はありませんでした。"),
        (r"^Queue item moved (.+): (.+)$", r"キュー項目を動かしました : "),
        (r"^Retry policy: retries=(.+), halt_on_first_error=(.+)$", r"再試行の設定: 再試行  回・最初のエラーで中断 "),
        (r"^Missing camera: (.+)$", r"カメラが見つかりません: \1"),
        (r"^Missing view layer: (.+)$", r"ビューレイヤーが見つかりません: \1"),
        (r"^Cleaned temporary compositor nodes: (.+)$", r"一時的なコンポジターのノードを片付けました: \1"),
        (r"^Output node updated to match the active passes: (.+)$", r"有効なパスに合わせて書き出しノードを組み直しました: \1"),
        (r"^Removed temporary compositor group: (.+)$", r"一時的なコンポジターのグループを片付けました: \1"),
        (r"^Render failed \[(.+)\]: (.+)$", r"レンダーに失敗しました: \1"),
        (r"^Output renamed for safety: (.+)$", r"上書きを避けて名前を変えました: \1"),
        (r"^Existing output failed verification and will be re-rendered: (.+)$", r"既存の出力が検証に通らないので描き直します: \1"),
        (r"^Rendered: (.+)$", r"レンダーしました: \1"),
        (r"^Skipped verified existing frame: (.+)$", r"検証済みの既存フレームを飛ばしました: \1"),
        (r"^Skipped existing frame: (.+)$", r"既存のフレームを飛ばしました: \1"),
        (r"^Retrying render \((.+)/(.+)\) for: (.+)$", r"レンダーをやり直します（\1/\2）: \3"),
        (r"^Render attempt failed \[(.+)/(.+)\] for (.+): (.+)$", r"レンダーに失敗しました（\1/\2）: \3"),
        (r"^Verification plan resolved to no concrete files and was treated as a no-op: (.+)$", r"検証するファイルが無いので検証を飛ばしました: \1"),
        (r"^Verified outputs: (.+) for (.+)$", r"出力を検証しました: \1 件（\2）"),
        (r"^Retrying verification for existing output \[(.+)/(.+)\]: (.+) \(missing=(.+), too_small=(.+)\)$", r"既存の出力の検証をやり直します（\1/\2）: \3（無い \4・小さすぎる \5）"),
        (r"^Retrying post-render verification \[(.+)/(.+)\] for (.+): missing=(.+) too_small=(.+)$", r"レンダー後の検証をやり直します（\1/\2）: \3（無い \4・小さすぎる \5）"),
        (r"^Failed to load: (.+)$", r"読み込めませんでした: \1"),
        (r"^Rendering (.+) frame\(s\) in a background Blender instance\.$", r"別の Blender で \1 フレームをレンダーしています。"),
        (r"^(.+)\. Check System Console\.$", r"\1。システムコンソールを確認してください。"),
        (r"^Terminated (.+) render processes\. Removed (.+) partial files$", r"レンダーの処理 \1 本を止め、途中のファイル \2 個を消しました"),
        (r"^Select at least (.+) image planes$", r"画像プレーンを \1 枚以上選んでください"),
    )
)



_TECHNICAL_TERM_JA = {
    "Add": "追加",
    "Advanced": "詳細",
    "Adaptive": "適応",
    "Apply": "適用",
    "Auto": "自動",
    "背景": "背景",
    "Base": "基本",
    "Benchmark": "ベンチマーク",
    "Blend": "ブレンド",
    "Camera": "カメラ",
    "Cancel": "キャンセル",
    "Child": "子",
    "Clear": "クリア",
    "Collection": "コレクション",
    "Collections": "コレクション",
    "Color": "カラー",
    "Color Management": "カラーマネジメント",
    "Compositor": "コンポジター",
    "Copy": "コピー",
    "Current": "現在",
    "Default": "既定",
    "Delete": "削除",
    "Denoise": "デノイズ",
    "Denoiser": "デノイザー",
    "Description": "説明",
    "Device": "デバイス",
    "Directory": "ディレクトリ",
    "Display": "表示",
    "Enabled": "有効",
    "Engine": "エンジン",
    "Error": "エラー",
    "Exposure": "露出",
    "Export": "エクスポート",
    "File": "ファイル",
    "Filter": "フィルター",
    "Final": "最終",
    "Frame": "フレーム",
    "Frames": "フレーム",
    "Gamma": "ガンマ",
    "Group": "グループ",
    "Height": "高さ",
    "Import": "インポート",
    "Info": "情報",
    "Input": "入力",
    "Layer": "レイヤー",
    "Layers": "レイヤー",
    "Light": "ライト",
    "Lights": "ライト",
    "Line": "ライン",
    "Load": "読み込み",
    "Loaded": "読み込み済み",
    "Local": "ローカル",
    "Look": "ルック",
    "Management": "管理",
    "Manifest": "マニフェスト",
    "Material": "マテリアル",
    "Max": "最大",
    "Min": "最小",
    "Mode": "モード",
    "Motion": "モーション",
    "Name": "名前",
    "Network": "ネットワーク",
    "Noise": "ノイズ",
    "Object": "オブジェクト",
    "Off": "オフ",
    "On": "オン",
    "Options": "オプション",
    "Output": "出力",
    "All Available": "利用可能なすべての設定",
    "Load all properties from the selected preset": "選択したプリセットのすべての設定を読み込みます",
    "{category} ({count} change)": "{category}（変更 {count} 件）",
    "{category} ({count} changes)": "{category}（変更 {count} 件）",
    "Overwrite": "上書き",
    "Panel": "パネル",
    "Pass": "パス",
    "Passes": "パス",
    "Path": "パス",
    "Preview": "プレビュー",
    "Preset": "プリセット",
    "Presets": "プリセット",
    "Properties": "プロパティ",
    "Quality": "品質",
    "Queue": "キュー",
    "Range": "範囲",
    "Refresh": "更新",
    "Render": "レンダー",
    "Renderer": "レンダラー",
    "Rendering": "レンダー中",
    "Resolution": "解像度",
    "Save": "保存",
    "Saved": "保存済み",
    "Scale": "スケール",
    "Scene": "シーン",
    "Select": "選択",
    "Selected": "選択中",
    "Settings": "設定",
    "Shadow": "シャドウ",
    "Shadows": "シャドウ",
    "Simplify": "簡略化",
    "Size": "サイズ",
    "Source": "ソース",
    "Start": "開始",
    "Status": "状態",
    "Stop": "停止",
    "Sun": "太陽",
    "Target": "ターゲット",
    "Template": "テンプレート",
    "Threshold": "しきい値",
    "Time": "時間",
    "Tool": "ツール",
    "Tools": "ツール",
    "Transparent": "透明",
    "Type": "タイプ",
    "Undo": "元に戻す",
    "Update": "更新",
    "Use": "使用",
    "Value": "値",
    "Variant": "バリアントとテイク",
    "Variants": "バリアントとテイク",
    "View": "ビュー",
    "Viewport": "ビューポート",
    "View Layer": "ビューレイヤー",
    "View Layers": "ビューレイヤー",
    "Visibility": "表示状態",
    "Warning": "警告",
    "Width": "幅",
    "World": "ワールド",
    "Frame Start": "開始フレーム",
    "Frame End": "終了フレーム",
    "Frame Count": "フレーム数",
    "Output Path": "出力パス",
    "Render Engine": "レンダーエンジン",
    "Open Shading Language": "Open Shading Language",
    "Noise Threshold": "ノイズしきい値",
    "Min Samples": "最小サンプル",
    "Max Samples": "最大サンプル",
    "Samples": "サンプル",
    "Denoise Passes": "デノイズパス",
    "Denoise Quality": "デノイズ品質",
    "Denoise Use GPU": "GPUでデノイズ",
    "Start Sample": "開始サンプル",
    "Time Limit": "制限時間",
    "Light Paths": "ライトパス",
    "Max Bounces": "最大バウンス",
    "Min Bounces": "最小バウンス",
    "Transparent Bounces": "透明バウンス",
    "Motion Blur": "モーションブラー",
    "Pixel Filter": "ピクセルフィルター",
    "Persistent Data": "永続データ",
    "File Output": "File Output",
    "Render Profiler": "レンダープロファイラー",
    "Render Naming": "Render Naming",
    "Frame Range Render": "フレーム範囲レンダー",
    "Local Render Farm": "疑似レンダーファーム",
    "K Tools Render Presets": "K Tools レンダープリセットマネージャー",
}


_PATH_LIKE = re.compile(r"[A-Za-z]:[\\/]|\\|(?:^|\s)/{1,2}[^\s/]+")


def _translate_common_technical_label(value: str) -> str:
    """Whole terms only: replacing words inside a sentence leaves half-translated text."""
    text = str(value or "")
    if not text or _PATH_LIKE.search(text):
        return text
    return _TECHNICAL_TERM_JA.get(text, text)


_TECHNICAL_TERM_EN = {ja: en for en, ja in _TECHNICAL_TERM_JA.items() if ja and en and ja != en}


def _translate_common_technical_label_to_en(value: str) -> str:
    text = str(value or "")
    if not text or _PATH_LIKE.search(text):
        return text
    return _TECHNICAL_TERM_EN.get(text, text)


def _lookup_dynamic_text(text: str, settings=None) -> str | None:
    if not is_japanese_locale(settings):
        return None
    value = str(text or "")
    for pattern, replacement in _DYNAMIC_JA_PATTERNS:
        if pattern.search(value):
            return pattern.sub(replacement, value)
    return None

def _lookup_catalog_text(text: str, settings=None) -> str:
    value = str(text or "")
    if not value:
        return value
    if is_japanese_locale(settings):
        exact = _catalog_en_to_ja().get(value)
        if exact is not None:
            return exact
        dynamic = _lookup_dynamic_text(value, settings=settings)
        if dynamic is not None:
            return dynamic
        technical = _translate_common_technical_label(value)
        if technical != value:
            return technical
        return value
    exact_en = _catalog_ja_to_en().get(value)
    if exact_en is not None:
        return exact_en
    technical_en = _translate_common_technical_label_to_en(value)
    if technical_en != value:
        return technical_en
    return value


def localize_inline(text: str, settings=None) -> str:
    value = str(text or "")
    parts = parse_inline_bilingual(value)
    if parts is not None:
        ja, en = parts
        return localize_pair(ja, en, settings=settings)
    return _lookup_catalog_text(value, settings=settings)


def iface_text(text: str, settings=None) -> str:
    return localize_inline(text, settings=settings)


def error_text(label: str, exc, settings=None) -> str:
    """Error shown to the user; Blender's internal exception text stays out of the Japanese UI."""
    if is_japanese_locale(settings):
        return f"{localize_inline(str(label), settings=settings)}: 実行できませんでした。詳しくはシステムコンソールを見てください。"
    return f"{label}: {exc}"


_BOTH_LANGUAGES_MARK = "\x1f"


def both_languages(ja: str, en: str) -> str:
    """Stored text that is shown in the language current at draw time."""
    return f"{en}{_BOTH_LANGUAGES_MARK}{ja}"


def error_log_text(label: str, exc) -> str:
    name = str(label)
    return both_languages(f"{_catalog_en_to_ja().get(name, name)}: 実行できませんでした。詳しくはシステムコンソールを見てください。", f"{name}: {exc}")


def stored_text(value, settings=None) -> str:
    """Display text of a stored log line."""
    text = str(value or "")
    if _BOTH_LANGUAGES_MARK in text:
        en, ja = text.split(_BOTH_LANGUAGES_MARK, 1)
        return localize_pair(ja, en, settings=settings)
    return localize_inline(text, settings=settings)


def wrapped_lines(text: str, width: int) -> list[str]:
    """Split text to lines of at most `width` display units; Japanese may break anywhere."""
    lines: list[str] = []
    current = ""
    used = 0
    limit = max(8, int(width))
    for word in re.findall(r"[\x21-\x7e]+\s*|.", str(text or ""), re.DOTALL):
        size = _text_width(word)
        if used and used + size > limit:
            lines.append(current.rstrip())
            current = ""
            used = 0
        while size > limit:
            count = 0
            taken = 0
            for char in word:
                char_size = _text_width(char)
                if taken + char_size > limit:
                    break
                taken += char_size
                count += 1
            lines.append(word[:count])
            word = word[count:]
            size = _text_width(word)
        current += word
        used += size
    if current.strip():
        lines.append(current.rstrip())
    return lines


def enum_label(ja: str, en: str, separator: str = " / ") -> str:
    """Item of a property with PROPERTY_CONTEXT; short words such as "None" stay out of Blender's shared table."""
    global _SOURCE_PAIRS_DIRTY
    del separator
    ja_text = str(ja or "")
    en_text = str(en or "")
    if not en_text:
        return ja_text
    if ja_text and ja_text != en_text and _ITEM_PAIRS.get(en_text) != ja_text:
        _ITEM_PAIRS[en_text] = ja_text
        _SOURCE_PAIRS_DIRTY = True
    return en_text


def t(settings, ja: str, en: str, separator: str = " / ") -> str:
    del separator
    return localize_pair(ja, en, settings=settings)


def _normalize_sentence(text: str) -> str:
    return " ".join(str(text or "").strip().split())


def _build_single_language_tooltip(
    ja: str,
    en: str,
    *,
    usage_ja: str,
    usage_en: str,
    tip_ja: str,
    tip_en: str,
    heading_ja: str,
    heading_en: str,
    settings=None,
) -> str:
    ja_text = _normalize_sentence(ja)
    en_text = _normalize_sentence(en)
    usage_ja_text = _normalize_sentence(usage_ja)
    usage_en_text = _normalize_sentence(usage_en)
    tip_ja_text = _normalize_sentence(tip_ja)
    tip_en_text = _normalize_sentence(tip_en)

    return source_text(
        (
            f"{heading_ja}: {ja_text or en_text}\n"
            f"使い方: {usage_ja_text or usage_en_text}\n"
            f"目安: {tip_ja_text or tip_en_text}"
        ),
        (
            f"{heading_en}: {en_text or ja_text}\n"
            f"How to use: {usage_en_text or usage_ja_text}\n"
            f"Tip: {tip_en_text or tip_ja_text}"
        ),
    )


def tooltip(ja: str, en: str, *, usage_ja: str | None = None, usage_en: str | None = None, tip_ja: str | None = None, tip_en: str | None = None) -> str:
    usage_ja = usage_ja or "この項目は上の説明どおりの内容を保持または制御します。入力欄なら値を設定し、切替項目ならオンオフし、一覧表示なら内容確認に使ってください。"
    usage_en = usage_en or "This item stores or controls the behavior described above. If it is an input field, set the value you need. If it is a toggle, turn it on or off. If it is a readout, use it to confirm the current state."
    tip_ja = tip_ja or "迷ったら現在値を確認し、関連項目を1つずつ見ながら変更すると影響を追いやすいです。"
    tip_en = tip_en or "When unsure, inspect the current value first and change one related setting at a time so the effect is easier to understand."
    return _build_single_language_tooltip(
        ja,
        en,
        usage_ja=usage_ja,
        usage_en=usage_en,
        tip_ja=tip_ja,
        tip_en=tip_en,
        heading_ja="機能",
        heading_en="Purpose",
    )


def action_tooltip(ja: str, en: str, *, usage_ja: str | None = None, usage_en: str | None = None, tip_ja: str | None = None, tip_en: str | None = None) -> str:
    usage_ja = usage_ja or "このボタンを押すと、現在のシーン設定をもとに処理を実行します。実行前に関連設定と出力先を確認し、必要なら先にプレビューや診断を行ってください。"
    usage_en = usage_en or "Click this button to run the action with the current scene settings. Before running it, review the related options and output path, and use preview or analysis first when helpful."
    tip_ja = tip_ja or "実行後はログや下部の結果表示を確認すると、何が変わったか追いやすくなります。"
    tip_en = tip_en or "After running the action, check the logs or result area so you can see what changed."
    return _build_single_language_tooltip(
        ja,
        en,
        usage_ja=usage_ja,
        usage_en=usage_en,
        tip_ja=tip_ja,
        tip_en=tip_en,
        heading_ja="実行内容",
        heading_en="Action",
    )


def expand_inline_bilingual_tooltip(text: str, *, action: bool = False) -> str:
    parts = parse_inline_bilingual(text)
    if parts is None:
        return registered_text(text)
    ja, en = parts
    return action_tooltip(ja, en) if action else tooltip(ja, en)


def registered_text(text: str) -> str:
    """English source of a label kept by Blender; the table holds its Japanese."""
    value = str(text or "")
    parts = parse_inline_bilingual(value)
    if parts is not None:
        return source_text(*parts)
    if contains_japanese(value):
        return _catalog_ja_to_en().get(value, value)
    return value


def _raw_class_attrs(cls: type) -> dict[str, str]:
    # Only the class's own store: an inherited one would hand this class the
    # label and description of whichever class created it first.
    raw = cls.__dict__.get("__srs_translation_raw_attrs__")
    if not isinstance(raw, dict):
        raw = {}
        try:
            setattr(cls, "__srs_translation_raw_attrs__", raw)
        except Exception:
            return {}
    return raw


def _is_operator_class(cls: type) -> bool:
    try:
        import bpy  # type: ignore
        return isinstance(cls, type) and issubclass(cls, bpy.types.Operator)
    except Exception:
        return False



def _wrap_operator_report(cls: type) -> None:
    if not _is_operator_class(cls):
        return
    try:
        if getattr(cls, "__srs_translation_report_wrapped__", False):
            return
        if "report" in getattr(cls, "__dict__", {}):
            return
        import bpy  # type: ignore

        def _srs_translation_report(self, type, message):
            try:
                message = iface_text(str(message))
            except Exception:
                pass
            return bpy.types.Operator.report(self, type, message)

        setattr(cls, "report", _srs_translation_report)
        setattr(cls, "__srs_translation_report_wrapped__", True)
    except Exception:
        pass

def localize_class_attributes(classes, settings=None, attrs=("bl_label", "bl_description", "bl_category")) -> None:
    for cls in tuple(classes or ()):
        _wrap_operator_report(cls)
        raw_store = _raw_class_attrs(cls)
        for attr in tuple(attrs or ()):
            try:
                current = getattr(cls, attr)
            except Exception:
                continue
            if not isinstance(current, str) or not current:
                continue
            raw = raw_store.get(attr, current)
            raw_store.setdefault(attr, raw)
            try:
                label_ja = getattr(cls, "_srr_bl_label_ja", None) if attr == "bl_label" else None
                label_en = getattr(cls, "_srr_bl_label_en", None) if attr == "bl_label" else None
                if isinstance(label_ja, str) and isinstance(label_en, str) and (label_ja or label_en):
                    localized = source_text(label_ja, label_en)
                elif attr in {"bl_category", "bl_label"} and str(raw).strip() == "Smart Render":
                    # This is the add-on's root N-panel/category/product name. Keep
                    # it stable so both the Sidebar tab and the root panel header are
                    # always named exactly "Smart Render" in Blender's UI.
                    localized = "Smart Render"
                elif attr == "bl_description":
                    localized = expand_inline_bilingual_tooltip(raw, action=_is_operator_class(cls))
                else:
                    localized = registered_text(raw)
                setattr(cls, attr, localized)
            except Exception:
                continue
    flush_source_pairs()


def refresh_loaded_class_attributes(settings=None) -> None:
    package_name = str(__package__ or 'smart_render_suite').strip()
    package = sys.modules.get(package_name)
    stack = [package, sys.modules.get(__name__)]
    seen = set()
    while stack:
        module = stack.pop()
        if module is None or id(module) in seen:
            continue
        seen.add(id(module))
        try:
            values = tuple(vars(module).values())
        except Exception:
            continue
        for value in values:
            if isinstance(value, type):
                localize_class_attributes((value,), settings=settings)
                continue
            module_name = str(getattr(value, '__name__', '') or '')
            if module_name == package_name or module_name.startswith(package_name + '.'):
                stack.append(value)


def tag_redraw_all() -> None:
    try:
        import bpy  # type: ignore

        wm = getattr(bpy.context, "window_manager", None)
        for window in getattr(wm, "windows", ()) or ():
            screen = getattr(window, "screen", None)
            for area in getattr(screen, "areas", ()) or ():
                try:
                    area.tag_redraw()
                except Exception:
                    pass
    except Exception:
        pass


def _closure_value(fn, name: str):
    try:
        code = getattr(fn, "__code__", None)
        cells = getattr(fn, "__closure__", None) or ()
        names = tuple(getattr(code, "co_freevars", ()) or ())
        for index, free_name in enumerate(names):
            if free_name == name and index < len(cells):
                return cells[index].cell_contents
    except Exception:
        pass
    return None


def _restore_legacy_runtime_hooks() -> None:
    """Compatibility no-op; this build never mutates Blender global UI APIs."""
    return None


def install_register_class_hook() -> None:
    _restore_legacy_runtime_hooks()
    return None


def uninstall_register_class_hook() -> None:
    _restore_legacy_runtime_hooks()
    return None


def install_ui_layout_hook() -> None:
    _restore_legacy_runtime_hooks()
    return None


def uninstall_ui_layout_hook() -> None:
    _restore_legacy_runtime_hooks()
    return None


def install_window_manager_hook() -> None:
    _restore_legacy_runtime_hooks()
    return None


def uninstall_window_manager_hook() -> None:
    _restore_legacy_runtime_hooks()
    return None

def _translation_contexts() -> tuple[str, ...]:
    contexts = {"*", PROPERTY_CONTEXT}
    try:
        import bpy  # type: ignore

        context_obj = getattr(getattr(bpy.app, "translations", None), "contexts", None)
        for name in dir(context_obj):
            if name.startswith("_"):
                continue
            try:
                value = getattr(context_obj, name)
            except Exception:
                continue
            if isinstance(value, str) and value:
                contexts.add(value)
    except Exception:
        pass
    return tuple(sorted(contexts))


def flush_source_pairs() -> None:
    """Add texts met after registration (tools load later) to the translation table."""
    if _TRANSLATIONS_REGISTERED and _SOURCE_PAIRS_DIRTY:
        register_translations()


def register_translations() -> None:
    global _TRANSLATIONS_REGISTERED, _SOURCE_PAIRS_DIRTY
    try:
        import bpy  # type: ignore

        translations = getattr(bpy.app, "translations", None)
        if translations is None:
            return
        try:
            translations.unregister(__name__)
        except Exception:
            pass
        en_to_ja = dict(_catalog_en_to_ja())
        en_to_ja.update(_SOURCE_PAIRS)
        if not en_to_ja:
            return
        contexts = _translation_contexts()
        ja_entries: dict[tuple[str, str], str] = {}
        for en, ja in en_to_ja.items():
            if not en or not ja or en == ja:
                continue
            for context in contexts:
                ja_entries[(context, en)] = ja
        for en, ja in _ITEM_PAIRS.items():
            ja_entries[(PROPERTY_CONTEXT, en)] = ja
        translations.register(__name__, {"ja_JP": ja_entries})
        _TRANSLATIONS_REGISTERED = True
        _SOURCE_PAIRS_DIRTY = False
    except Exception:
        _TRANSLATIONS_REGISTERED = False


def unregister_translations() -> None:
    global _TRANSLATIONS_REGISTERED
    try:
        import bpy  # type: ignore

        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
    _TRANSLATIONS_REGISTERED = False


def register() -> None:
    _restore_legacy_runtime_hooks()
    register_translations()


def unregister() -> None:
    _restore_legacy_runtime_hooks()
    unregister_translations()


def icon_for_status(level: str) -> str:
    return {
        "INFO": "CHECKMARK",
        "WARNING": "ERROR",
        "ERROR": "CANCEL",
        "NOT_RUN": "QUESTION",
    }.get(str(level or "").upper(), "QUESTION")


_STATUS_NAME_FACTOR = 0.58
_PROP_NAME_FACTOR = 0.43
_TOGGLE_NAME_FACTOR = 0.86
_FALLBACK_PANEL_WIDTH = 240
_PANEL_MARGIN = 54
_ICON_WIDTH = 20


def _text_width(text: str) -> int:
    return sum(2 if ord(char) > 0x2E7F else 1 for char in str(text))


def _panel_units():
    """Usable sidebar width and interface scale of the panel being drawn."""
    try:
        import bpy  # type: ignore
        scale = float(bpy.context.preferences.system.ui_scale) or 1.0
        region = bpy.context.region
        return (float(region.width) / scale if region is not None else _FALLBACK_PANEL_WIDTH), scale
    except Exception:
        return _FALLBACK_PANEL_WIDTH, 1.0


def _text_pixels(text: str) -> float:
    """Width of the text at 1.0 interface scale."""
    try:
        import blf  # type: ignore
        blf.size(0, 11)
        measured = float(blf.dimensions(0, str(text))[0]) * 1.1
    except Exception:
        measured = 0.0
    return max(measured, _text_width(text) * 5.8)


def _fits_in_column(text: str, factor: float, icon: bool = False) -> bool:
    width, _scale = _panel_units()
    available = (width - _PANEL_MARGIN) * factor - (_ICON_WIDTH if icon else 0) - 14
    return _text_pixels(text) <= available


def wrap_units() -> int:
    """How many display units of text fit on one line of the panel being drawn."""
    width, _scale = _panel_units()
    return max(16, int((width - _PANEL_MARGIN - 2 * _ICON_WIDTH) / 6.2))


def _enum_value_text(data, prop_name: str) -> str:
    """Text an enum field shows now; empty for other kinds of property."""
    try:
        prop = data.bl_rna.properties[prop_name]
        if prop.type != 'ENUM' or prop.is_enum_flag:
            return ""
        name = prop.enum_items[getattr(data, prop_name)].name
        import bpy  # type: ignore
        return bpy.app.translations.pgettext_iface(name, prop.translation_context)
    except Exception:
        return ""


def _prop_name_row(layout, name: str, icon: str, value_text: str = ""):
    """Layout that receives the value: beside the name, or under it when either would not fit."""
    value_fits = not value_text or _fits_in_column(value_text + "      ", 1.0 - _PROP_NAME_FACTOR)
    if value_fits and _fits_in_column(name, _PROP_NAME_FACTOR, icon != 'NONE'):
        split = layout.split(factor=_PROP_NAME_FACTOR, align=True)
        split.label(text=name, icon=icon, translate=False)
        return split
    column = layout.column(align=True)
    column.label(text=name, icon=icon, translate=False)
    return column


def draw_prop(layout, settings, data, prop_name: str, ja: str, en: str, icon: str = 'NONE'):
    supported_targets = frozenset(('abort_on_collisions', 'accumulation_samples', 'accumulation_samples_override', 'adaptive_sampling_mode', 'analysis_detail_limit', 'auto_create_folders', 'auto_unique_tokens', 'bridge_target', 'cleanup_invalid_outputs', 'collection_override_mode', 'color_management_mode', 'compact_mode', 'concurrent_tasks', 'concurrent_tasks_override', 'custom_frame_end', 'custom_frame_start', 'denoise_mode', 'description', 'enable_movie_encode', 'enabled', 'engine_mode', 'exclude_collections', 'execution_device_mode', 'execution_device_mode_override', 'exposure_override', 'farm_priority', 'farm_priority_override', 'ffmpeg_executable', 'film_transparent_mode', 'frame_chunk_size', 'frame_chunk_size_override', 'frame_end', 'frame_mode', 'frame_start', 'freestyle_mode', 'gamma_override', 'halt_on_first_error', 'hide_objects', 'holdout_collections', 'image_format', 'image_format_override', 'include_collections', 'indirect_only_collections', 'job_name', 'job_name_override', 'job_tags', 'job_tags_override', 'label', 'look_override', 'manifest_path', 'material_override_mode', 'memory_gb_hint', 'memory_gb_hint_override', 'min_output_size_kb', 'motion_blur_mode', 'movie_file_pattern', 'movie_overwrite_existing', 'movie_preset', 'name', 'network_render_enabled', 'network_render_target', 'object_visibility_override_mode', 'output_dir_pattern', 'output_dir_pattern_override', 'output_file_pattern', 'output_file_pattern_override', 'output_root', 'output_root_override', 'overwrite_existing', 'pass_bundle', 'preview_limit', 'proxy_collections', 'quality_mode', 'queue_compositing_mode', 'queue_source_mode', 'render_collections', 'render_elements_enabled', 'render_elements_output_mode', 'render_elements_preset', 'renderable_cameras_only', 'representation_mode', 'resolution_percentage', 'resolution_percentage_override', 'resolution_x_override', 'resolution_y_override', 'retry_count', 'retry_on_failure', 'sample_multiplier', 'sample_multiplier_override', 'selected_cameras_only', 'sequence_padding', 'show_advanced', 'show_objects', 'skip_existing_frames', 'source_mode', 'spatial_subsamples', 'spatial_subsamples_override', 'stamp_note', 'stamp_note_override', 'strict_missing_assets', 'temporal_subsamples', 'temporal_subsamples_override', 'use_adaptive_sampling', 'use_custom_frames', 'use_denoise', 'use_exposure_override', 'use_freestyle', 'use_gamma_override', 'use_motion_blur', 'use_placeholder', 'use_stamp', 'verification_retry_count', 'verification_retry_delay', 'verification_scope', 'verify_outputs_after_render', 'view_layer_mode', 'view_transform_override', 'world_override_mode'))
    name = t(settings, ja, en)
    if prop_name not in supported_targets:
        layout.split(factor=_PROP_NAME_FACTOR, align=True).label(text=name, icon=icon, translate=False)
        return
    try:
        is_toggle = data.bl_rna.properties[prop_name].type == 'BOOLEAN'
    except Exception:
        is_toggle = False
    if is_toggle:
        if not _fits_in_column(name, _TOGGLE_NAME_FACTOR, icon != 'NONE'):
            column = layout.column(align=True)
            column.label(text=name, icon=icon, translate=False)
            column.prop(data, prop_name, text="")
            return
        split = layout.split(factor=_TOGGLE_NAME_FACTOR, align=True)
        split.label(text=name, icon=icon, translate=False)
        split.prop(data, prop_name, text="")
        return
    split = _prop_name_row(layout, name, icon, _enum_value_text(data, prop_name))
    split.prop(data, prop_name, text="")


def draw_prop_search(layout, settings, data, prop_name: str, search_data, search_prop: str, ja: str, en: str, icon: str = 'NONE'):
    supported_targets = frozenset(('camera_name', 'material_override_name', 'parent_variant_name', 'variant_name', 'view_layer_name', 'world_override_name'))
    name = t(settings, ja, en)
    if prop_name not in supported_targets:
        layout.split(factor=_PROP_NAME_FACTOR, align=True).label(text=name, icon=icon, translate=False)
        return
    split = _prop_name_row(layout, name, icon)
    split.prop_search(data, prop_name, search_data, search_prop, text="")


def info_line(layout, text: str, icon: str = 'NONE'):
    row = layout.row(align=True)
    row.scale_y = 0.92
    row.label(text=str(text or ""), icon=icon, translate=False)


_STATUS_VALUE_LABELS = {
    "NOT_RUN": ("未実行", "Not run"),
    "INFO": ("問題なし", "No issues"),
    "WARNING": ("警告あり", "Warnings"),
    "ERROR": ("エラーあり", "Errors"),
    "DRAFT": ("下書き", "Draft"),
    "PREVIEW": ("プレビュー", "Preview"),
    "FINAL": ("最終", "Final"),
    "NONE": ("変更なし", "None"),
    "ESSENTIAL": ("基本", "Essentials"),
    "OPEN_EXR": ("OpenEXR", "OpenEXR"),
    "OPEN_EXR_MULTILAYER": ("OpenEXR マルチレイヤー", "OpenEXR Multilayer"),
    "BEAUTY": ("ビューティー", "Beauty"),
    "COMPOSITE": ("合成", "Composite"),
    "LOOKDEV": ("ルックデブ", "Lookdev"),
    "LIGHTING": ("ライティング", "Lighting"),
    "CRYPTOMATTE": ("Crypto / ID", "Crypto / ID"),
    "TECHNICAL": ("テクニカル", "Technical"),
    "DATASET": ("データセット", "Dataset"),
    "PRIMARY_ONLY": ("メイン出力のみ", "Main Output Only"),
    "PRIMARY_AND_PASSES": ("メイン + AOV パス", "Main + AOV Passes"),
    "PASSES_ONLY": ("AOV パスのみ", "AOV Passes Only"),
    "AUTO": ("自動", "Auto"),
    "DIRECT": ("直接出力", "Direct Output"),
    "COMPOSITOR": ("コンポジター", "Compositor"),
    "CPU": ("CPU", "CPU"),
    "GPU": ("GPU", "GPU"),
    "HYBRID": ("ハイブリッド", "Hybrid"),
    "CYCLES": ("Cycles", "Cycles"),
    "BLENDER_EEVEE": ("EEVEE", "EEVEE"),
    "BLENDER_EEVEE_NEXT": ("EEVEE", "EEVEE"),
    "BLENDER_WORKBENCH": ("Workbench", "Workbench"),
    "FROM_PASS_BUNDLE": ("現在のパス構成から", "From Pass Bundle"),
    "CRYPTO_ID": ("Crypto / ID", "Crypto / ID"),
    "CUSTOM": ("カスタム", "Custom"),
    "FILES": ("EXR 分割ファイル", "Split EXR Files"),
    "MULTILAYER": ("マルチレイヤー EXR", "Multilayer EXR"),
}


def status_value_text(value, settings=None) -> str:
    """Display text of a status value; values that are not internal names go through the catalog."""
    text = str(value)
    shown = []
    for part in text.split(" → "):
        bridged = part.endswith(" (bridge)")
        pair = _STATUS_VALUE_LABELS.get(part[:-len(" (bridge)")] if bridged else part)
        if pair is None:
            return localize_inline(text, settings=settings)
        ja, en = pair
        if bridged:
            ja, en = f"{ja}（ブリッジ）", f"{en} (bridge)"
        shown.append(localize_pair(ja, en, settings=settings))
    return " → ".join(shown)


def status_value_pair(value) -> tuple[str, str]:
    """Display text of a status value in both languages (ja, en)."""
    return _STATUS_VALUE_LABELS.get(str(value), (str(value), str(value)))


def status_log_text(ja: str, en: str, value) -> str:
    """Stored log line with a status value in both languages."""
    pair = status_value_pair(value)
    return both_languages(f"{ja}: {pair[0]}", f"{en}: {pair[1]}")


def render_summary_lines(raw, settings=None) -> tuple[list[str], bool]:
    """Display lines of the stored last-queue result and whether it reports a failure."""
    text = str(raw or "")
    try:
        data = json.loads(text)
    except ValueError:
        data = None
    if not isinstance(data, dict):
        return [status_value_text(text or "—", settings)], False
    if data.get("state") == "aborted":
        return [localize_pair("事前診断のエラーで中止", "Aborted by preflight", settings=settings)], True

    def count(key: str) -> int:
        return int(data.get(key, 0) or 0)

    halted = data.get("state") == "halted"
    return [
        localize_pair("エラーで中断" if halted else "完了", "Halted after error" if halted else "Finished", settings=settings),
        localize_pair(f"成功 {count('success')}・検証済み {count('verified')}", f"Success: {count('success')} / Verified: {count('verified')}", settings=settings),
        localize_pair(f"既存スキップ {count('skipped')}・自動改名 {count('renamed')}", f"Skipped existing: {count('skipped')} / Auto-renamed: {count('renamed')}", settings=settings),
        localize_pair(f"失敗 {count('failures')}・検証失敗 {count('verification_failures')}・無効削除 {count('invalid_removed')}", f"Failures: {count('failures')} / Verification failures: {count('verification_failures')} / Invalid removed: {count('invalid_removed')}", settings=settings),
    ], bool(count("failures") or count("verification_failures"))


def status_card(layout, title: str, value, icon: str = 'NONE', alert: bool = False, wide: bool = False):
    """One status row: name and value side by side, or on separate lines for long values."""
    row = layout.row(align=True)
    row.alert = alert
    shown = localize_inline(str(title))
    if not isinstance(value, (list, tuple)):
        value = status_value_text(value)
        wide = wide or not _fits_in_column(shown, _STATUS_NAME_FACTOR, icon != 'NONE') or not _fits_in_column(value, 1.0 - _STATUS_NAME_FACTOR)
    if wide:
        column = row.column(align=True)
        column.label(text=shown, icon=icon, translate=False)
        for line in (value if isinstance(value, (list, tuple)) else [value]):
            column.label(text=str(line), icon='BLANK1', translate=False)
        return
    split = row.split(factor=_STATUS_NAME_FACTOR, align=True)
    split.label(text=shown, icon=icon, translate=False)
    split.label(text=value, translate=False)
