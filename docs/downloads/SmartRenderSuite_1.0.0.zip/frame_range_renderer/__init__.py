# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""
Frame Range Render
====================
Adds a panel to the Output Properties where you can enter frames and
frame ranges (e.g. "1,2,5-6,12-16") and render exactly those frames.
"""


from ..translation import iface_text
bl_info = {
    "name": 'Frame Range Render',
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Render",
    "description": "Render exact frame lists and frame ranges from the migrated Smart Render N-panel workflow.",
    "category": "Render",
}
import bpy
from ..rna_safety import safe_register_class, safe_unregister_class
import subprocess
import time
from bpy.types import Panel, Operator
from bpy.props import StringProperty
from ..help_operator import draw_help_button


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def parse_frame_ranges(ranges_str: str) -> list[int]:
    """Parse a string like '1,2,5-6,12-16' into a sorted list of frame numbers."""
    frames: set[int] = set()
    for part in ranges_str.replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            sides = part.split("-")
            if len(sides) == 2 and all(s.lstrip("-").isdigit() for s in sides):
                try:
                    start, end = int(sides[0]), int(sides[1])
                    frames.update(range(min(start, end), max(start, end) + 1))
                except ValueError:
                    pass
        else:
            try:
                frames.add(int(part))
            except ValueError:
                pass
    return sorted(frames)


# ---------------------------------------------------------------------------
# 背景 process state
# ---------------------------------------------------------------------------

_bg_process: subprocess.Popen | None = None

_SPINNER = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]


def _is_running() -> bool:
    return _bg_process is not None and _bg_process.poll() is None


def _redraw_panels():
    """Timer callback: redraws Properties areas while the process is alive."""
    if not _is_running():
        return None  # unregister timer
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == "PROPERTIES":
                area.tag_redraw()
    return 0.1  # seconds until next call


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class RENDER_OT_clear_frame_input(Operator):
    bl_idname = "render.clear_frame_list"
    bl_label = "Clear Frame List"
    bl_description = "Clear the frame range input"
    bl_options = {'UNDO'}

    def execute(self, context):
        context.scene.frame_range_input = ""
        return {"FINISHED"}


class RENDER_OT_render_frame_ranges(Operator):
    bl_options = set()
    _sms_no_undo = True
    bl_idname = "render.render_frame_ranges"
    bl_label = "Render Frame Ranges"
    bl_description = (
        "Render every frame defined in the text field above in a separate "
        "background Blender instance. The current session stays responsive."
    )

    def execute(self, context):
        scene = context.scene
        frames = parse_frame_ranges(scene.frame_range_input)

        if not frames:
            self.report({"WARNING"}, iface_text("No valid frames found in the input."))
            return {"CANCELLED"}

        blend_file = bpy.data.filepath
        if not blend_file:
            self.report({"ERROR"}, iface_text("Please save the .blend file before rendering."))
            return {"CANCELLED"}

        # Build an inline Python script that renders each frame in the
        # background Blender instance and writes the output file.
        py_expr = (
            "import bpy; "
            f"frames = {frames}; "
            "scene = bpy.context.scene; "
            "base = scene.render.filepath; "
            # A still render does not add the frame to its path, so every frame would overwrite one file.
            "[(scene.frame_set(f), setattr(scene.render, 'filepath', base), "
            "setattr(scene.render, 'filepath', scene.render.frame_path(frame=f)), "
            "bpy.ops.render.render(write_still=True)) for f in frames]"
        )

        cmd = [bpy.app.binary_path, "-b", blend_file, "--python-expr", py_expr]

        global _bg_process
        _bg_process = subprocess.Popen(cmd)

        # Start the redraw timer so the panel animates while rendering
        if not bpy.app.timers.is_registered(_redraw_panels):
            bpy.app.timers.register(_redraw_panels, first_interval=0.1)

        self.report(
            {"INFO"},
            iface_text(f"Rendering {len(frames)} frame(s) in a background Blender instance."),
        )
        return {"FINISHED"}


class RENDER_OT_cancel_frame_ranges(Operator):
    bl_options = set()
    _sms_no_undo = True
    bl_idname = "render.cancel_frame_render"
    bl_label = "Cancel Frame Render"
    bl_description = "Terminate the background Blender render process"

    def execute(self, context):
        global _bg_process
        if _is_running():
            _bg_process.terminate()
            self.report({"INFO"}, iface_text("Background render cancelled."))
        else:
            self.report({"WARNING"}, iface_text("No background render is running."))
        return {"FINISHED"}


# ---------------------------------------------------------------------------
# Panel
# ---------------------------------------------------------------------------

class RENDER_PT_FRAME_RANGE_RENDERER(Panel):
    bl_label = "Frame Range Renderer"
    bl_idname = "RENDER_PT_FRAME_RANGE_RENDERER"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    _srr_integrated_popover = True
    bl_context = "output"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header_preset(self, context):
        draw_help_button(self.layout, 'integrated:frame_range_renderer')

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        scene = context.scene

        row = layout.row(align=True)
        row.prop(scene, "frame_range_input", text=iface_text("Frames"))
        row.operator("render.clear_frame_list", text="", icon="X")

        frames = parse_frame_ranges(scene.frame_range_input)
        if frames:
            layout.label(
                text=iface_text(f"{len(frames)} frame(s)  [{frames[0]}\u2013{frames[-1]}]"),
                icon="RENDER_ANIMATION",
            )
        else:
            layout.label(text=iface_text("No valid frames."), icon="ERROR", translate=False)

        layout.separator()
        row = layout.row()
        row.scale_y = 1.4
        if _is_running():
            spinner = _SPINNER[int(time.time() * 10) % len(_SPINNER)]
            layout.label(text=iface_text(f"{spinner}  Rendering in background\u2026"))
            layout.separator()
            row.operator("render.cancel_frame_render", icon="CANCEL", text=iface_text("Cancel Frame Render"))
        else:
            row.operator("render.render_frame_ranges", icon="RENDER_ANIMATION", text=iface_text("Render in 背景"))


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    RENDER_OT_clear_frame_input,
    RENDER_OT_render_frame_ranges,
    RENDER_OT_cancel_frame_ranges,
    RENDER_PT_FRAME_RANGE_RENDERER,
)


def register():
    for cls in classes:
        safe_register_class(cls)
    bpy.types.Scene.frame_range_input = StringProperty(
        name="Frames",
        description="Frames to render. Use '-' for ranges and ',' to separate. E.g. '1,2,5-6,12-16'",
        default="1-10",
    )


def unregister():
    del bpy.types.Scene.frame_range_input
    for cls in reversed(classes):
        safe_unregister_class(cls)



