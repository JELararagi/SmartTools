# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Bounded, operation-driven snapshots used by Smart Render panels.

Panels never scan Blender data while they are being drawn. A panel that finds no
snapshot, or one older than the scene, asks for a one-shot timer, and the capture
runs there or in an explicit operator through :func:`capture_scene_snapshot`.
"""

from __future__ import annotations

import os
import time
from array import array
from collections import OrderedDict
from itertools import islice
from typing import Any

_MAX_SCENE_SNAPSHOTS = 8
_MAX_QUEUE_SNAPSHOTS = 128
_MAX_VARIANT_SNAPSHOTS = 128
_MAX_EXECUTION_ROWS = 8
_MAX_OUTPUT_PATHS = 3
_MAX_SELECTOR_NAMES = 4096
_MAX_SELECTOR_PREVIEW = 8
_MAX_ERRORS = 16
_MAX_TEXT = 1024

_REFRESH_DELAY = 0.2
_REFRESH_DELAY_MAX = 2.0
_REFRESH_COST_FACTOR = 5.0
_SIGNATURE_CHECK_SECONDS = 0.5

_SCENE_SNAPSHOTS: "OrderedDict[int, dict[str, Any]]" = OrderedDict()
_LAST_SIGNATURE_CHECK = 0.0
_LAST_CHANGE = 0.0
_LAST_CAPTURE_SECONDS = 0.0


def _text(value: Any, limit: int = _MAX_TEXT) -> str:
    return str(value or "")[: max(0, int(limit))]


def _scene_key(scene) -> int:
    if scene is None:
        return 0
    try:
        return int(scene.as_pointer())
    except Exception:
        return int(id(scene))


def _blank_snapshot(scene=None) -> dict[str, Any]:
    return {
        "available": False,
        "scene_name": _text(getattr(scene, "name", "")),
        "reason": "",
        "captured_at": 0.0,
        "camera_count": 0,
        "view_layer_count": 0,
        "queue_count": 0,
        "planned_render_count": 0,
        "output_root": "",
        "output_path_ready": False,
        "requested_compositing_mode": "AUTO",
        "effective_compositing_mode": "AUTO",
        "effective_verification_scope": "PRIMARY_AND_PASSES",
        "device_preview": {},
        "render_elements": {
            "selected_count": 0,
            "effective_bundle": "BEAUTY",
            "image_format": "",
            "preview_names": [],
            "pass_folder": "",
        },
        "execution_rows": [],
        "execution_graph": {
            "job_count": 0,
            "render_node_count": 0,
            "verify_node_count": 0,
            "movie_node_count": 0,
            "node_count": 0,
            "edge_count": 0,
            "max_dependency_depth": 0,
        },
        "queue_items": {},
        "variants": {},
        "errors": [],
    }


def _hidden_render_fingerprint(objects) -> int:
    count = len(objects)
    flags = array("b", bytes(count))
    objects.foreach_get("hide_render", flags)
    return hash(flags.tobytes())


def _selected_camera_names(settings) -> tuple:
    if not getattr(settings, "selected_cameras_only", False):
        return ()
    import bpy
    selected = getattr(bpy.context, "selected_objects", None) or ()
    return tuple(sorted(obj.name for obj in selected if obj.type == "CAMERA"))


def _scene_signature(scene) -> tuple:
    """Cheap fingerprint of what the counts depend on outside the add-on's own settings."""
    try:
        import bpy
        camera = getattr(scene, "camera", None)
        return (
            len(bpy.data.objects),
            _hidden_render_fingerprint(bpy.data.objects),
            _selected_camera_names(getattr(scene, "srr_settings", None)),
            len(scene.view_layers),
            getattr(camera, "name", ""),
            int(scene.frame_start),
            int(scene.frame_end),
            int(scene.frame_step),
            str(scene.render.engine),
            len(getattr(scene, "srr_queue", ())),
            len(getattr(scene, "srr_variants", ())),
        )
    except Exception:
        return ()


def _tag_panels_for_redraw(wm) -> None:
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type in {'VIEW_3D', 'PROPERTIES'}:
                area.tag_redraw()


_ELEMENT_CHECKS_PENDING: set[str] = set()


def _refresh_delay() -> float:
    """Quiet time before a recount; a scene that is slow to count is counted less often."""
    return min(_REFRESH_DELAY_MAX, max(_REFRESH_DELAY, _LAST_CAPTURE_SECONDS * _REFRESH_COST_FACTOR))


def _refresh_timer():
    global _LAST_CAPTURE_SECONDS
    import bpy
    try:
        if bpy.app.is_job_running('RENDER'):
            return 1.0
        wait = _LAST_CHANGE + _refresh_delay() - time.monotonic()
        if wait > 0.0:
            return wait
        wm = bpy.context.window_manager
        captured = False
        for window in wm.windows:
            scene = window.scene
            snapshot = _SCENE_SNAPSHOTS.get(_scene_key(scene))
            if snapshot is not None and not snapshot.get("stale") and snapshot.get("signature") == _scene_signature(scene):
                continue
            started = time.perf_counter()
            with bpy.context.temp_override(window=window):
                capture_scene_snapshot(bpy.context, reason="refresh", include_output_paths=True)
            _LAST_CAPTURE_SECONDS = time.perf_counter() - started
            captured = True
        if captured:
            _tag_panels_for_redraw(wm)
    except Exception:
        pass
    return None


def _request_refresh() -> None:
    try:
        import bpy
        if bpy.app.background or bpy.app.timers.is_registered(_refresh_timer):
            return
        bpy.app.timers.register(_refresh_timer, first_interval=_REFRESH_DELAY)
    except Exception:
        pass


def cancel_refresh() -> None:
    try:
        import bpy
        if bpy.app.timers.is_registered(_refresh_timer):
            bpy.app.timers.unregister(_refresh_timer)
        if bpy.app.timers.is_registered(_fill_element_checks_timer):
            bpy.app.timers.unregister(_fill_element_checks_timer)
    except Exception:
        pass
    _ELEMENT_CHECKS_PENDING.clear()


def _fill_element_checks_timer():
    """Put the starting element set into the check boxes; a panel's draw may not write it."""
    import bpy
    from .planner import ensure_render_element_item_defaults
    names = list(_ELEMENT_CHECKS_PENDING)
    _ELEMENT_CHECKS_PENDING.clear()
    for name in names:
        scene = bpy.data.scenes.get(name)
        settings = getattr(scene, "srr_settings", None) if scene is not None else None
        if settings is None:
            continue
        try:
            ensure_render_element_item_defaults(settings)
            invalidate_scene(scene)
        except Exception:
            pass
    _request_refresh()
    try:
        _tag_panels_for_redraw(bpy.context.window_manager)
    except Exception:
        pass
    return None


def request_element_checks(scene) -> None:
    """Called from the panel while a scene's check boxes have not been filled yet."""
    try:
        import bpy
        _ELEMENT_CHECKS_PENDING.add(scene.name)
        if not bpy.app.timers.is_registered(_fill_element_checks_timer):
            bpy.app.timers.register(_fill_element_checks_timer, first_interval=0.0)
    except Exception:
        pass


def get_scene_snapshot(scene) -> dict[str, Any]:
    global _LAST_SIGNATURE_CHECK
    key = _scene_key(scene)
    snapshot = _SCENE_SNAPSHOTS.get(key)
    if snapshot is None:
        _request_refresh()
        return _blank_snapshot(scene)
    _SCENE_SNAPSHOTS.move_to_end(key)
    now = time.monotonic()
    if snapshot.get("stale"):
        _request_refresh()
    elif now - _LAST_SIGNATURE_CHECK >= _SIGNATURE_CHECK_SECONDS:
        _LAST_SIGNATURE_CHECK = now
        if snapshot.get("signature") != _scene_signature(scene):
            _mark_change()
            _request_refresh()
    else:
        # This redraw may be the last one for a while, so the timer takes the skipped look.
        _request_refresh()
    return snapshot


def get_queue_item_snapshot(scene, index: int) -> dict[str, Any]:
    snapshot = get_scene_snapshot(scene)
    return dict(snapshot.get("queue_items", {}).get(str(max(0, int(index))), {}) or {})


def get_variant_snapshot(scene, index: int, name: str = "") -> dict[str, Any]:
    snapshot = get_scene_snapshot(scene)
    variants = snapshot.get("variants", {}) or {}
    item = variants.get(str(max(0, int(index))))
    if item is None and name:
        wanted = str(name)
        for candidate in variants.values():
            if str(candidate.get("name", "")) == wanted:
                item = candidate
                break
    return dict(item or {})


def _mark_change() -> None:
    global _LAST_CHANGE
    _LAST_CHANGE = time.monotonic()


def invalidate_scene(scene=None) -> None:
    """Keep showing the last counts until the recount replaces them."""
    if scene is None:
        clear_all()
        return
    _mark_change()
    snapshot = _SCENE_SNAPSHOTS.get(_scene_key(scene))
    if snapshot is not None:
        snapshot["stale"] = True


def clear_all() -> None:
    _SCENE_SNAPSHOTS.clear()


def _remember_snapshot(scene, snapshot: dict[str, Any]) -> dict[str, Any]:
    key = _scene_key(scene)
    if key <= 0:
        return snapshot
    snapshot["signature"] = _scene_signature(scene)
    _SCENE_SNAPSHOTS[key] = snapshot
    _SCENE_SNAPSHOTS.move_to_end(key)
    while len(_SCENE_SNAPSHOTS) > _MAX_SCENE_SNAPSHOTS:
        _SCENE_SNAPSHOTS.popitem(last=False)
    return snapshot


def _append_error(snapshot: dict[str, Any], label: str, exc: BaseException) -> None:
    errors = snapshot.setdefault("errors", [])
    if len(errors) < _MAX_ERRORS:
        errors.append(_text(f"{label}: {exc}"))


def _field(item: Any, name: str, default: Any = None) -> Any:
    if isinstance(item, dict):
        return item.get(name, default)
    return getattr(item, name, default)


def _item_dict(item: Any) -> dict[str, Any]:
    return {
        "enabled": bool(_field(item, "enabled", True)),
        "source_mode": _text(_field(item, "source_mode", "PAIR"), 32) or "PAIR",
        "variant_name": _text(_field(item, "variant_name", ""), 256),
        "camera_name": _text(_field(item, "camera_name", ""), 256),
        "view_layer_name": _text(_field(item, "view_layer_name", ""), 256),
        "label": _text(_field(item, "label", ""), 256),
    }


def _frame_label(frames: list[int]) -> str:
    if not frames:
        return ""
    if len(frames) == 1:
        return str(frames[0])
    return f"{frames[0]}-{frames[-1]} ({len(frames)}f)"


def _selector_snapshot(selector_text: str, available_names: list[str]) -> dict[str, Any]:
    from .compat import parse_name_list
    from .selectors import preview_selector_matches, resolve_selector_diagnostics

    selectors = parse_name_list(selector_text)
    if not selectors:
        return {}
    diagnostics = resolve_selector_diagnostics(selectors, available_names)
    invalid = []
    for entry in list(diagnostics.get("invalid", []) or [])[:_MAX_SELECTOR_PREVIEW]:
        if isinstance(entry, dict):
            invalid.append({"selector": _text(entry.get("selector", ""), 256), "error": _text(entry.get("error", ""), 512)})
    return {
        "selector_count": len(selectors),
        "match_count": len(list(diagnostics.get("resolved", []) or [])),
        "missing": [_text(value, 256) for value in list(diagnostics.get("unmatched", []) or [])[:_MAX_SELECTOR_PREVIEW]],
        "invalid": invalid,
        "preview": [_text(value, 256) for value in list(preview_selector_matches(selectors, available_names, limit=_MAX_SELECTOR_PREVIEW) or [])[:_MAX_SELECTOR_PREVIEW]],
    }


def _output_paths_for_item(scene, settings, item: dict[str, Any], counts: dict[str, int], context_layer_name: str, limit: int = _MAX_OUTPUT_PATHS) -> list[str]:
    from .planner import resolve_item_context, resolve_output

    resolved = resolve_item_context(scene, settings, item, context_view_layer_name=context_layer_name)
    frames = [int(value) for value in list(resolved.get("frames", []) or [])]
    paths: list[str] = []
    for frame_value in frames[: max(0, int(limit))]:
        target = resolve_output(scene, settings, item, frame_value, counts, context_view_layer_name=context_layer_name)
        path = _text(target.get("full_path", ""))
        if path:
            paths.append(path)
    return paths


def capture_scene_snapshot(context, *, reason: str = "manual", include_output_paths: bool = True) -> dict[str, Any]:
    """Capture a bounded primitive-only snapshot after an explicit operation."""
    scene = getattr(context, "scene", None) if context is not None else None
    snapshot = _blank_snapshot(scene)
    snapshot["reason"] = _text(reason, 128)
    snapshot["captured_at"] = float(time.time())
    if scene is None:
        return snapshot
    settings = getattr(scene, "srr_settings", None)
    if settings is None:
        return _remember_snapshot(scene, snapshot)

    try:
        from .compat import abspath, default_output_root, effective_queue_compositing_mode
        from .device_control import local_execution_device_preview
        from .planner import (
            available_cameras,
            available_view_layers,
            configured_render_element_ids,
            effective_queue_blueprint,
            frame_values,
            pass_output_folder_name,
            queue_counts,
            render_elements_effective_bundle,
            render_elements_image_format,
            render_elements_preview_names,
            resolve_item_context,
            resolved_profile,
            variant_lookup,
        )
        from .resources import frame_chunk_specs, resource_profile
        from .variant_graph import effective_variant, variant_path
        from .verification import effective_verification_scope
    except Exception as exc:
        _append_error(snapshot, "imports", exc)
        return _remember_snapshot(scene, snapshot)

    context_layer_name = _text(getattr(getattr(context, "view_layer", None), "name", ""), 256)

    try:
        snapshot["camera_count"] = len(available_cameras(context, settings) or [])
        snapshot["view_layer_count"] = len(available_view_layers(context, settings) or [])
    except Exception as exc:
        _append_error(snapshot, "scene inventory", exc)

    try:
        requested_mode = _text(getattr(settings, "queue_compositing_mode", "AUTO"), 64).upper() or "AUTO"
        effective_mode = _text(effective_queue_compositing_mode(scene, requested_mode), 64) or requested_mode
        verify_scope = _text(effective_verification_scope(_text(getattr(settings, "verification_scope", "PRIMARY_AND_PASSES"), 64), effective_mode), 64)
        snapshot["requested_compositing_mode"] = requested_mode
        snapshot["effective_compositing_mode"] = effective_mode
        snapshot["effective_verification_scope"] = verify_scope
    except Exception as exc:
        _append_error(snapshot, "compositing", exc)

    try:
        device = local_execution_device_preview(scene, settings) or {}
        snapshot["device_preview"] = {str(key): (_text(value) if isinstance(value, str) else value) for key, value in dict(device).items() if isinstance(value, (str, int, float, bool))}
    except Exception as exc:
        _append_error(snapshot, "device", exc)

    try:
        output_root = abspath(_text(getattr(settings, "output_root", "")) or default_output_root(create=False))
        snapshot["output_root"] = _text(output_root)
        snapshot["output_path_ready"] = bool(os.path.isdir(output_root) or getattr(settings, "auto_create_folders", False))
    except Exception as exc:
        _append_error(snapshot, "output root", exc)

    try:
        element_ids = list(configured_render_element_ids(settings) or [])
        all_preview_names = list(render_elements_preview_names(settings) or [])
        preview_names = [_text(name, 256) for name in all_preview_names[:32]]
        snapshot["render_elements"] = {
            "selected_count": len(element_ids),
            "effective_bundle": _text(render_elements_effective_bundle(settings), 128),
            "image_format": _text(render_elements_image_format(settings), 64),
            "preview_names": preview_names,
            "preview_name_count": len(all_preview_names),
            "pass_folder": _text(pass_output_folder_name(settings), 256),
        }
    except Exception as exc:
        _append_error(snapshot, "render elements", exc)

    queue_items: list[dict[str, Any]] = []
    try:
        queue_items = [_item_dict(item) for item in list(effective_queue_blueprint(context, scene, settings, enabled_only=True) or [])]
        snapshot["queue_count"] = len(queue_items)
    except Exception as exc:
        _append_error(snapshot, "queue", exc)

    counts: dict[str, int] = {"camera": 1, "view_layer": 1, "variant": 1, "frame": 1}
    try:
        counts = dict(queue_counts(scene, settings, queue_items) or counts) if queue_items else counts
    except Exception as exc:
        _append_error(snapshot, "queue counts", exc)

    execution_rows: list[dict[str, Any]] = []
    planned_renders = 0
    render_nodes = 0
    movie_nodes = 0

    def _capture_queue_item(item: dict[str, Any]) -> tuple[dict[str, Any], int, int, bool]:
        resolved = resolve_item_context(scene, settings, item, context_view_layer_name=context_layer_name)
        frames = [int(value) for value in list(resolved.get("frames", []) or [])]
        variant = resolved.get("variant")
        execution = resource_profile(settings, frame_count=max(1, len(frames)), variant=variant)
        chunks = list(frame_chunk_specs(frames, int(execution.get("frame_chunk_size", getattr(settings, "frame_chunk_size", 1)) or 1)) or [])
        label = _text(item.get("label") or item.get("variant_name") or f"{resolved.get('camera_name', '')} | {resolved.get('view_layer_name', '')}", 256)
        node_count = max(1, len(chunks) or 1)
        movie_candidate = len(frames) > 1
        item_snapshot = {
            "label": label,
            "camera_name": _text(resolved.get("camera_name", ""), 256),
            "view_layer_name": _text(resolved.get("view_layer_name", ""), 256),
            "frame_label": _frame_label(frames),
            "frame_count": len(frames),
            "chunk_count": node_count,
            "first_chunk": _text(chunks[0].get("frames_string", "") if chunks else (str(frames[0]) if frames else ""), 256),
            "movie_candidate": movie_candidate,
            "output_paths": [],
        }
        if include_output_paths:
            item_snapshot["output_paths"] = _output_paths_for_item(scene, settings, item, counts, context_layer_name)
        return item_snapshot, len(frames), node_count, movie_candidate

    for index, item in enumerate(queue_items[:_MAX_QUEUE_SNAPSHOTS]):
        try:
            item_snapshot, frame_count, node_count, movie_candidate = _capture_queue_item(item)
            planned_renders += frame_count
            if len(execution_rows) < _MAX_EXECUTION_ROWS:
                execution_rows.append({key: item_snapshot[key] for key in ("label", "frame_count", "chunk_count", "first_chunk", "movie_candidate")})
            render_nodes += node_count
            if bool(getattr(settings, "enable_movie_encode", False)) and movie_candidate:
                movie_nodes += 1
        except Exception as exc:
            _append_error(snapshot, f"queue item {index}", exc)
    if len(queue_items) > _MAX_QUEUE_SNAPSHOTS:
        try:
            variants = variant_lookup(scene)
            for item in queue_items[_MAX_QUEUE_SNAPSHOTS:]:
                variant = variants.get(item.get("variant_name", "")) if item.get("source_mode") == "VARIANT" else None
                planned_renders += len(frame_values(scene, settings, variant=variant) or [])
        except Exception as exc:
            _append_error(snapshot, "remaining queue count", exc)

    verify_nodes = len(queue_items) if bool(getattr(settings, "verify_outputs_after_render", True)) else 0

    # UI rows are indexed by the actual Scene collection, not by the enabled-only
    # effective blueprint. Capture them separately so disabled rows never read a
    # neighboring row's preview after filtering.
    queue_snapshots: dict[str, dict[str, Any]] = {}
    raw_queue_items = [_item_dict(item) for item in islice(getattr(scene, "srr_queue", []) or [], _MAX_QUEUE_SNAPSHOTS)]
    for raw_index, item in enumerate(raw_queue_items):
        try:
            item_snapshot, _frame_count, _node_count, _movie_candidate = _capture_queue_item(item)
            queue_snapshots[str(raw_index)] = item_snapshot
        except Exception as exc:
            _append_error(snapshot, f"scene queue item {raw_index}", exc)

    snapshot["planned_render_count"] = int(planned_renders)
    snapshot["execution_rows"] = execution_rows
    snapshot["queue_items"] = queue_snapshots
    snapshot["execution_graph"] = {
        "job_count": len(queue_items),
        "render_node_count": render_nodes,
        "verify_node_count": verify_nodes,
        "movie_node_count": movie_nodes,
        "node_count": render_nodes + verify_nodes + movie_nodes,
        "edge_count": verify_nodes + movie_nodes + max(0, render_nodes - len(queue_items)),
        "max_dependency_depth": 3 if movie_nodes else (2 if verify_nodes else 1 if render_nodes else 0),
    }

    variant_snapshots: dict[str, dict[str, Any]] = {}
    variants_collection = list(islice(getattr(scene, "srr_variants", []) or [], _MAX_VARIANT_SNAPSHOTS))
    collection_selector_props = (
        "include_collections",
        "exclude_collections",
        "holdout_collections",
        "indirect_only_collections",
        "proxy_collections",
        "render_collections",
    )
    object_selector_props = ("show_objects", "hide_objects")
    needs_collection_inventory = any(
        str(getattr(variant, prop_name, "") or "").strip()
        for variant in variants_collection
        for prop_name in collection_selector_props
    )
    needs_object_inventory = any(
        str(getattr(variant, prop_name, "") or "").strip()
        for variant in variants_collection
        for prop_name in object_selector_props
    )
    collection_names: list[str] = []
    object_names: list[str] = []
    if needs_collection_inventory:
        try:
            import bpy
            collection_names = sorted(_text(item.name, 256) for item in list(getattr(bpy.data, "collections", [])))[:_MAX_SELECTOR_NAMES]
        except Exception as exc:
            _append_error(snapshot, "collection inventory", exc)
    if needs_object_inventory:
        try:
            object_names = sorted(_text(item.name, 256) for item in list(getattr(scene, "objects", [])))[:_MAX_SELECTOR_NAMES]
        except Exception as exc:
            _append_error(snapshot, "object inventory", exc)
    for index, variant in enumerate(variants_collection):
        try:
            resolved_variant = effective_variant(scene, variant)
            target_variant = resolved_variant or variant
            profile = resolved_profile(settings, scene, variant=target_variant)
            frames = [int(value) for value in list(frame_values(scene, settings, variant=target_variant) or [])]
            execution = resource_profile(settings, frame_count=max(1, len(frames)), variant=target_variant)
            chain = [_text(value, 256) for value in list(getattr(target_variant, "variant_chain", []) or [])[:32]]
            if not chain:
                path_text = _text(variant_path(scene, variant), 1024)
                chain = [part.strip() for part in path_text.split("/") if part.strip()][:32]
            item = {
                "enabled": True,
                "source_mode": "VARIANT",
                "variant_name": _text(getattr(variant, "name", ""), 256),
                "camera_name": _text(getattr(variant, "camera_name", ""), 256),
                "view_layer_name": _text(getattr(variant, "view_layer_name", ""), 256),
                "label": _text(getattr(variant, "name", ""), 256),
            }
            variant_counts = dict(queue_counts(scene, settings, [item]) or counts)
            selector_data: dict[str, Any] = {}
            for prop_name, names in (
                ("include_collections", collection_names),
                ("exclude_collections", collection_names),
                ("holdout_collections", collection_names),
                ("indirect_only_collections", collection_names),
                ("proxy_collections", collection_names),
                ("render_collections", collection_names),
                ("show_objects", object_names),
                ("hide_objects", object_names),
            ):
                value = _text(getattr(variant, prop_name, ""))
                if value.strip():
                    selector_data[prop_name] = _selector_snapshot(value, names)
            variant_snapshots[str(index)] = {
                "name": _text(getattr(variant, "name", ""), 256),
                "chain": chain,
                "path": _text(getattr(target_variant, "variant_path", "") or variant_path(scene, variant), 1024),
                "camera_name": _text(getattr(target_variant, "camera_name", ""), 256),
                "view_layer_name": _text(getattr(target_variant, "view_layer_name", ""), 256),
                "resolution_x": int(profile.get("resolved_resolution_x", 0) or 0),
                "resolution_y": int(profile.get("resolved_resolution_y", 0) or 0),
                "execution_device": _text(execution.get("device_mode", ""), 64),
                "frame_chunk_size": int(execution.get("frame_chunk_size", 0) or 0),
                "farm_priority": int(execution.get("farm_priority", 0) or 0),
                "frame_label": _frame_label(frames),
                "output_paths": _output_paths_for_item(scene, settings, item, variant_counts, context_layer_name) if include_output_paths else [],
                "selectors": selector_data,
            }
        except Exception as exc:
            _append_error(snapshot, f"variant {index}", exc)
    snapshot["variants"] = variant_snapshots
    snapshot["available"] = True
    return _remember_snapshot(scene, snapshot)
