from __future__ import annotations

import fnmatch
import re
from typing import Dict, Iterable, List, Sequence, Tuple

from .translation import localize_pair


WILDCARD_CHARS = set('*?[]')


def selector_mode(selector: str) -> Tuple[str, str]:
    raw = str(selector or "").strip()
    lowered = raw.lower()
    if lowered.startswith("re:"):
        return "regex", raw[3:].strip()
    if lowered.startswith("regex:"):
        return "regex", raw[6:].strip()
    if lowered.startswith("glob:"):
        return "glob", raw[5:].strip()
    if any(char in raw for char in WILDCARD_CHARS):
        return "glob", raw
    return "exact", raw



def selector_compile_error(selector: str) -> str:
    mode, payload = selector_mode(selector)
    if mode != "regex":
        return ""
    if not payload:
        return localize_pair("正規表現が空です", "Empty regular expression")
    try:
        re.compile(payload)
    except re.error as exc:
        return str(exc)
    return ""



def selector_matches_name(selector: str, candidate_name: str) -> bool:
    mode, payload = selector_mode(selector)
    candidate = str(candidate_name or "")
    if not payload or not candidate:
        return False
    if mode == "exact":
        if candidate == payload:
            return True
        return candidate.casefold() == payload.casefold()
    if mode == "glob":
        if fnmatch.fnmatchcase(candidate, payload):
            return True
        return fnmatch.fnmatchcase(candidate.casefold(), payload.casefold())
    try:
        pattern = re.compile(payload)
        if pattern.search(candidate):
            return True
        if not (pattern.flags & re.IGNORECASE):
            return re.compile(payload, re.IGNORECASE).search(candidate) is not None
    except re.error:
        return False
    return False



def resolve_selector_diagnostics(selectors: Sequence[str], available_names: Iterable[str]) -> Dict[str, object]:
    names = [str(name) for name in (available_names or []) if str(name)]
    resolved: List[str] = []
    unmatched: List[str] = []
    invalid: List[Dict[str, str]] = []
    details: List[Dict[str, object]] = []
    seen = set()

    for selector in selectors or []:
        raw_selector = str(selector or "").strip()
        if not raw_selector:
            continue
        mode, payload = selector_mode(raw_selector)
        compile_error = selector_compile_error(raw_selector)
        if compile_error:
            invalid.append(
                {
                    "selector": raw_selector,
                    "mode": mode,
                    "payload": payload,
                    "error": compile_error,
                }
            )
            details.append(
                {
                    "selector": raw_selector,
                    "mode": mode,
                    "payload": payload,
                    "matches": [],
                    "error": compile_error,
                    "invalid": True,
                }
            )
            continue

        matched = [name for name in names if selector_matches_name(raw_selector, name)]
        if not matched:
            unmatched.append(raw_selector)
        else:
            for name in matched:
                if name not in seen:
                    seen.add(name)
                    resolved.append(name)
        details.append(
            {
                "selector": raw_selector,
                "mode": mode,
                "payload": payload,
                "matches": matched,
                "error": "",
                "invalid": False,
            }
        )

    return {
        "selectors": [str(selector or "").strip() for selector in (selectors or []) if str(selector or "").strip()],
        "resolved": resolved,
        "unmatched": unmatched,
        "invalid": invalid,
        "details": details,
    }



def resolve_selector_names(selectors: Sequence[str], available_names: Iterable[str]) -> Tuple[List[str], List[str]]:
    diagnostics = resolve_selector_diagnostics(selectors, available_names)
    unresolved = list(diagnostics.get("unmatched", []) or [])
    for item in diagnostics.get("invalid", []) or []:
        selector = str(item.get("selector", "") or "")
        error = str(item.get("error", "") or "")
        unresolved.append(f"[invalid regex] {selector}: {error}" if error else f"[invalid regex] {selector}")
    return list(diagnostics.get("resolved", []) or []), unresolved



def preview_selector_matches(selectors: Sequence[str], available_names: Iterable[str], limit: int = 8) -> List[str]:
    diagnostics = resolve_selector_diagnostics(selectors, available_names)
    resolved = list(diagnostics.get("resolved", []) or [])
    if len(resolved) <= limit:
        return resolved
    return resolved[: max(1, int(limit))] + [f"+{len(resolved) - max(1, int(limit))} more"]
