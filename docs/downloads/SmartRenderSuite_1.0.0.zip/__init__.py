# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

# Add-on bootstrap: Smart Render
# Format policy: Blender Extension/user_default package import, direct N-panel registration, runtime cleanup.

from __future__ import annotations

import importlib as _importlib
import sys as _sys
from pathlib import Path as _Path

_TOP_LEVEL_PACKAGE_ID = "smart_render_suite"


def _current_package_name() -> str:
    return __package__ or __name__


def _current_package_root() -> _Path:
    try:
        return _Path(__file__).resolve().parent
    except Exception:
        return _Path(".")


def _purge_top_level_alias_modules() -> None:
    """Compatibility no-op; module identity is owned by Blender's loader."""
    return None


def _purge_stale_extension_submodules() -> None:
    """Compatibility no-op; exact unregister preserves class identities."""
    return None


def _cancel_stale_runtime_callbacks_before_module_purge() -> None:
    """Disable callbacks left by an older Smart Render live session.

    Blender keeps timer and handler function objects alive after an Extension
    package is replaced on disk.  If an old callback wakes while Blender 5.1 is
    rebuilding Panel RNA, it can touch stale classes/properties and re-create the
    missing-callback state.  Cancel known callbacks before submodule purge while
    their function objects are still reachable.
    """
    try:
        import bpy as _bpy  # type: ignore
    except Exception:
        return
    try:
        current_module = _sys.modules.get(__name__)
    except Exception:
        current_module = None
    timers = getattr(getattr(_bpy, "app", None), "timers", None)
    is_registered = getattr(timers, "is_registered", None) if timers is not None else None
    unregister_timer = getattr(timers, "unregister", None) if timers is not None else None

    def _cancel_timer(fn) -> None:
        if not callable(fn) or unregister_timer is None:
            return
        try:
            if callable(is_registered):
                if is_registered(fn):
                    unregister_timer(fn)
            else:
                unregister_timer(fn)
        except Exception:
            pass

    known_callback_names = {
        "_smart_render_runtime_watchdog_timer",
        "_smart_render_load_post_handler",
        "_smart_render_load_factory_startup_post_handler",
        "_smart_render_runtime_refresh",
        "_run_startup_sync",
        "_autosave_timer",
        "_flush_timer",
        "_save_once",
        "_timer",
    }
    package_names = tuple(dict.fromkeys((
        str(__package__ or __name__),
        _TOP_LEVEL_PACKAGE_ID,
    )))
    module_names = []
    for package_name in package_names:
        module_names.extend((
            package_name + ".registration",
            package_name + ".ui_runtime",
            package_name + ".settings",
            package_name + ".controls",
            package_name + ".common",
            package_name + ".loader",
        ))
    for name in tuple(module_names):
        module = _sys.modules.get(name)
        if module is None or module is current_module:
            continue
        try:
            for flag in (
                "_REGISTERED",
                "_RUNTIME_SETTINGS_REGISTERED",
                "_INTEGRATED_TOOLS_REGISTERED",
                "_LEGACY_ANCHORS_REGISTERED",
            ):
                if hasattr(module, flag):
                    setattr(module, flag, False)
            for flag in ("_UNREGISTERING", "_SMART_RENDER_STALE_CANCELLED"):
                if hasattr(module, flag):
                    setattr(module, flag, True)
        except Exception:
            pass
        try:
            namespace = dict(getattr(module, "__dict__", {}) or {})
        except Exception:
            namespace = {}
        for attr in known_callback_names:
            _cancel_timer(namespace.get(attr))
        for attr, value in tuple(namespace.items()):
            try:
                value_name = str(getattr(value, "__name__", attr) or attr).lower()
                value_module = str(getattr(value, "__module__", "") or "")
            except Exception:
                value_name = str(attr).lower()
                value_module = ""
            if callable(value) and ("timer" in value_name or "flush" in value_name or "refresh" in value_name) and "smart_render_suite" in value_module.lower():
                _cancel_timer(value)
            if isinstance(value, (set, list, tuple)):
                for item in tuple(value):
                    _cancel_timer(item)
                if isinstance(value, set) and attr in {"_RUNTIME_TIMER_HANDLES", "_LEGACY_ANCHOR_CLEANUP_TIMERS"}:
                    try:
                        value.clear()
                    except Exception:
                        pass
            elif isinstance(value, dict):
                for item in tuple(value.values()):
                    _cancel_timer(item)
        try:
            handlers = getattr(getattr(_bpy, "app", None), "handlers", None)
            for collection_name in (
                "load_post",
                "load_factory_startup_post",
                "save_pre",
                "save_post",
                "depsgraph_update_post",
                "frame_change_pre",
                "frame_change_post",
            ):
                collection = getattr(handlers, collection_name, None) if handlers is not None else None
                if collection is None:
                    continue
                for fn in list(collection):
                    try:
                        fn_module = str(getattr(fn, "__module__", "") or "")
                    except Exception:
                        fn_module = ""
                    if fn_module == name or "smart_render_suite" in fn_module.lower():
                        try:
                            collection.remove(fn)
                        except Exception:
                            pass
        except Exception:
            pass
    try:
        ns = getattr(getattr(_bpy, "app", None), "driver_namespace", None)
        if isinstance(ns, dict):
            ns["SMART_RENDER_SUITE_RUNTIME_TOKEN"] = None
            ns["SMART_RENDER_SUITE_REGISTERING"] = False
    except Exception:
        pass




def _iter_panel_subclasses_for_live_cleanup(base: type | None) -> tuple[type, ...]:
    if base is None:
        return tuple()
    result: list[type] = []
    stack: list[type] = []
    try:
        stack.extend(tuple(base.__subclasses__()))
    except Exception:
        return tuple()
    seen: set[int] = set()
    while stack:
        cls = stack.pop()
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        result.append(cls)
        try:
            stack.extend(tuple(cls.__subclasses__()))
        except Exception:
            pass
    return tuple(result)


def _hidden_live_cleanup_poll(_cls, _context) -> bool:
    return False


def _safe_class_dict(cls: type | None):
    if cls is None or not isinstance(cls, type):
        return {}
    try:
        namespace = type.__getattribute__(cls, "__dict__")
        return namespace if namespace is not None else {}
    except Exception:
        return {}


def _safe_class_name(cls: type | None) -> str:
    if cls is None or not isinstance(cls, type):
        return ""
    try:
        return str(type.__getattribute__(cls, "__name__") or "")
    except Exception:
        return ""


def _safe_class_module(cls: type | None) -> str:
    if cls is None or not isinstance(cls, type):
        return ""
    try:
        return str(type.__getattribute__(cls, "__module__") or "")
    except Exception:
        return ""


def _safe_class_attr_string(cls: type | None, name: str) -> str:
    if name == "__name__":
        return _safe_class_name(cls)
    if name == "__module__":
        return _safe_class_module(cls)
    try:
        value = _safe_class_dict(cls).get(name, "")
    except Exception:
        value = ""
    try:
        return str(value or "")
    except Exception:
        return ""


def _safe_class_attr_bool(cls: type | None, name: str) -> bool:
    try:
        return bool(_safe_class_dict(cls).get(name, False))
    except Exception:
        return False




def _is_current_smart_render_ui_class_for_cleanup(cls: type | None) -> bool:
    if cls is None or not isinstance(cls, type):
        return False
    package = _current_package_name()
    candidate_modules = []
    if package:
        candidate_modules.append(package + ".ui")
    try:
        module_name = _safe_class_module(cls)
        parent_module = module_name.rsplit(".", 1)[0]
        if parent_module:
            candidate_modules.append(parent_module + ".ui")
    except Exception:
        pass
    for module_name in tuple(dict.fromkeys(candidate_modules)):
        module = _sys.modules.get(module_name)
        if module is None:
            continue
        try:
            for current in tuple(getattr(module, "UI_CLASSES", ()) or ()):  # type: ignore[arg-type]
                if cls is current:
                    return True
        except Exception:
            continue
    return False

def _is_stale_smart_render_dynamic_panel(cls: type | None, *, remove_root_panels: bool = True) -> bool:
    if cls is None or not isinstance(cls, type):
        return False
    try:
        name = _safe_class_name(cls)
        bl_idname = _safe_class_attr_string(cls, "bl_idname")
        category = _safe_class_attr_string(cls, "bl_category")
        parent = _safe_class_attr_string(cls, "bl_parent_id")
        module = _safe_class_module(cls)
        host_panel = _safe_class_attr_bool(cls, "_smart_suite_host_panel") or _safe_class_attr_bool(cls, "_smart_suite_npanel_proxy")
    except Exception:
        return False
    if category != "Smart Render" and "smart_render_suite" not in module.lower():
        return False
    if name.startswith("SMART_RENDER_SUITE_PT_sidebar_anchor") or bl_idname.startswith("SMART_RENDER_SUITE_PT_sidebar_anchor"):
        return False
    if name.startswith("SMART_RENDER_SUITE_IMAGE_PT_sidebar_anchor") or bl_idname.startswith("SMART_RENDER_SUITE_IMAGE_PT_sidebar_anchor"):
        return False
    stale_root_ids = {"SRR_PT_MAIN_PANEL", "SRR_IMAGE_PT_MAIN_PANEL"}
    if remove_root_panels and (name in stale_root_ids or bl_idname in stale_root_ids) and not _is_current_smart_render_ui_class_for_cleanup(cls):
        return True
    if name.startswith("SMARTTOOLS_PT_INT") or bl_idname.startswith("SMARTTOOLS_PT_INT"):
        return True
    if name.startswith("SMARTTOOLS_NPANEL_PT_smart_render_suite") or bl_idname.startswith("SMARTTOOLS_NPANEL_PT_smart_render_suite"):
        return True
    if host_panel and (parent.startswith("SRR_PT_") or parent.startswith("SRR_IMAGE_PT_") or "smart_render_suite" in module.lower()):
        return True
    if remove_root_panels and category == "Smart Render" and not parent and "smart_render_suite" in module.lower() and not _is_current_smart_render_ui_class_for_cleanup(cls):
        label = _safe_class_attr_string(cls, "bl_label")
        if label in {"Smart Render", "スマートレンダー"} or _safe_class_attr_bool(cls, "_smart_render_image_editor_panel"):
            return True
    return False


def _unregister_stale_smart_render_dynamic_panels_before_module_purge(*, remove_root_panels: bool = True) -> None:
    """Remove generated child panels left by older live-reloaded builds.

    Older Smart Render builds registered SMARTTOOLS_PT_INT* panels as native
    child panels under SRR_PT_MAIN_PANEL.  Blender 5.1 can leave those child
    headers visible in the Sidebar even when their poll() returns False, so the
    current build removes them before importing the fresh runtime modules.
    """
    try:
        import bpy as _bpy  # type: ignore
    except Exception:
        return
    try:
        if bool(getattr(getattr(_bpy, "app", None), "is_exiting", False)):
            return
    except Exception:
        pass
    try:
        panel_base = getattr(_bpy.types, "Panel", None)
    except Exception:
        panel_base = None
    candidates: list[type] = []
    for cls in _iter_panel_subclasses_for_live_cleanup(panel_base):
        if _is_stale_smart_render_dynamic_panel(cls, remove_root_panels=remove_root_panels):
            candidates.append(cls)
    try:
        for name in tuple(dir(_bpy.types)):
            if not (str(name).startswith("SMARTTOOLS_PT_INT") or str(name).startswith("SMARTTOOLS_NPANEL_PT_smart_render_suite")):
                continue
            cls = getattr(_bpy.types, str(name), None)
            if isinstance(cls, type) and _is_stale_smart_render_dynamic_panel(cls, remove_root_panels=remove_root_panels):
                candidates.append(cls)
    except Exception:
        pass
    seen: set[int] = set()
    for cls in reversed(tuple(candidates)):
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            setattr(cls, "poll", classmethod(_hidden_live_cleanup_poll))
        except Exception:
            pass
        try:
            _bpy.utils.unregister_class(cls)
        except Exception:
            try:
                setattr(cls, "poll", classmethod(_hidden_live_cleanup_poll))
            except Exception:
                pass

_cancel_stale_runtime_callbacks_before_module_purge()
_unregister_stale_smart_render_dynamic_panels_before_module_purge()
_purge_stale_extension_submodules()

import bpy


def _is_blender_exiting() -> bool:
    try:
        return bool(getattr(getattr(bpy, "app", None), "is_exiting", False))
    except Exception:
        return False


_LEGACY_ANCHOR_CLASS_NAMES = (
    "SMART_RENDER_SUITE_PT_sidebar_anchor",
    "SMART_RENDER_SUITE_IMAGE_PT_sidebar_anchor",
)
_GLOBAL_PANEL_POLL_GUARD_MARK = "_smart_render_suite_global_panel_poll_guard"
_GLOBAL_PANEL_POLL_PREVIOUS = globals().get("_GLOBAL_PANEL_POLL_PREVIOUS", None)


def _safe_class_dict(cls: type | None):
    if cls is None or not isinstance(cls, type):
        return {}
    try:
        namespace = type.__getattribute__(cls, "__dict__")
        return namespace if namespace is not None else {}
    except Exception:
        return {}


def _safe_class_name(cls: type | None) -> str:
    if cls is None or not isinstance(cls, type):
        return ""
    try:
        return str(type.__getattribute__(cls, "__name__") or "")
    except Exception:
        return ""


def _safe_class_module(cls: type | None) -> str:
    if cls is None or not isinstance(cls, type):
        return ""
    try:
        return str(type.__getattribute__(cls, "__module__") or "")
    except Exception:
        return ""


def _safe_class_attr_string(cls: type | None, name: str) -> str:
    if name == "__name__":
        return _safe_class_name(cls)
    if name == "__module__":
        return _safe_class_module(cls)
    try:
        value = _safe_class_dict(cls).get(name, "")
    except Exception:
        value = ""
    try:
        return str(value or "")
    except Exception:
        return ""


def _safe_class_attr_bool(cls: type | None, name: str) -> bool:
    try:
        return bool(_safe_class_dict(cls).get(name, False))
    except Exception:
        return False


def _legacy_anchor_identity(cls: type | None) -> tuple[str, str]:
    if cls is None or not isinstance(cls, type):
        return "", ""
    return _safe_class_name(cls), _safe_class_attr_string(cls, "bl_idname")


def _is_legacy_anchor_identity(cls: type | None) -> bool:
    name, bl_idname = _legacy_anchor_identity(cls)
    return name in _LEGACY_ANCHOR_CLASS_NAMES or bl_idname in _LEGACY_ANCHOR_CLASS_NAMES


def _global_panel_poll_guard(cls, context) -> bool:
    """Base Panel.poll fallback for unreachable stale Blender 5.1 callbacks."""
    try:
        if _is_legacy_anchor_identity(cls):
            return False
    except Exception:
        pass
    previous = globals().get("_GLOBAL_PANEL_POLL_PREVIOUS", None)
    if previous is not None:
        try:
            if isinstance(previous, classmethod):
                return bool(previous.__get__(cls, type(cls))(context))
            if callable(previous):
                try:
                    return bool(previous(cls, context))
                except TypeError:
                    return bool(previous(context))
        except Exception:
            return True
    return True


try:
    setattr(_global_panel_poll_guard, _GLOBAL_PANEL_POLL_GUARD_MARK, True)
except Exception:
    pass


def _remove_stale_global_panel_poll_guard() -> bool:
    """Remove only a Smart Render guard retained by an older live reload.

    This build never installs a base ``Panel.poll`` wrapper.  A same-session
    update can nevertheless leave the marked callback from an older build on
    Blender's RNA base type.  Restore its recorded predecessor once, or remove
    the attribute when the predecessor was absent.
    """
    try:
        panel_base = getattr(bpy.types, "Panel", None)
        raw = getattr(panel_base, "__dict__", {}).get("poll") if panel_base is not None else None
        raw_func = getattr(raw, "__func__", raw)
        if not bool(getattr(raw_func, _GLOBAL_PANEL_POLL_GUARD_MARK, False)):
            return False
        old_globals = getattr(raw_func, "__globals__", {}) or {}
        previous = old_globals.get("_GLOBAL_PANEL_POLL_PREVIOUS")
        if previous is None:
            try:
                delattr(panel_base, "poll")
            except Exception:
                return False
        else:
            setattr(panel_base, "poll", previous)
        return True
    except Exception:
        return False


def _install_global_panel_poll_guard() -> None:
    """Compatibility no-op; this build never replaces Panel.poll."""
    return None


def _panel_poll_guard_installed() -> bool:
    try:
        raw = getattr(getattr(bpy.types, "Panel", None), "__dict__", {}).get("poll")
        raw_func = getattr(raw, "__func__", raw)
        return bool(getattr(raw_func, _GLOBAL_PANEL_POLL_GUARD_MARK, False))
    except Exception:
        return False


def _restore_global_panel_poll_guard() -> None:
    global _GLOBAL_PANEL_POLL_PREVIOUS
    _remove_stale_global_panel_poll_guard()
    _GLOBAL_PANEL_POLL_PREVIOUS = None
    return None


_remove_stale_global_panel_poll_guard()
_install_global_panel_poll_guard()

from .meta import ADDON_VERSION, BLENDER_MIN_VERSION

bl_info = {
    "name": 'Smart Render',
    "author": "JELararagi",
    "version": ADDON_VERSION,
    "blender": BLENDER_MIN_VERSION,
    "location": "View3D / Image Editor > Sidebar > Smart Render",
    "description": "Smart Render exposes render orchestration tools in the View3D and Image Editor Sidebar N-panel category Smart Render.",
    "category": "Smart Render",
}

try:
    from . import property_tooltips as _property_tooltips
    _property_tooltips.install()
except Exception:
    pass

try:
    from . import console_clean as _console_clean
    _console_clean.install()
except Exception:
    pass
finally:
    _purge_top_level_alias_modules()

_REGISTERED = False
_RUNTIME_SETTINGS_REGISTERED = False
_CORE_RUNTIME_REGISTER_ERROR = ""
_UNREGISTERING = False

_LEGACY_ANCHOR_CLEANUP_TIMERS: set[object] = set()
_LEGACY_ANCHORS_REGISTERED = False

_SMART_TOOLS_MANAGER_COMPAT_TIMERS = set()


def _iter_smart_tools_manager_runtime_modules():
    return tuple(
        module
        for name in (
            'bl_ext.user_default.smart_tools_manager',
            'smart_tools_manager',
        )
        if (module := _sys.modules.get(name)) is not None
    )


def _install_smart_tools_manager_compat_once() -> bool:
    return False


def _smart_tools_manager_compat_timer_factory(attempts: int = 80):
    del attempts
    return None


def _smart_tools_manager_addon_enabled() -> bool:
    try:
        addons = getattr(getattr(getattr(bpy, 'context', None), 'preferences', None), 'addons', {})
        keys = tuple(getattr(addon, 'module', '') for addon in addons) if not isinstance(addons, dict) else tuple(addons.keys())
    except Exception:
        keys = ()
    for key in keys:
        text = str(key or '').lower()
        if text == 'smart_tools_manager' or text.endswith('.smart_tools_manager'):
            return True
    return False


def _install_smart_tools_manager_compat() -> None:
    return None


def _cancel_smart_tools_manager_compat_timers() -> None:
    for callback in tuple(_SMART_TOOLS_MANAGER_COMPAT_TIMERS):
        try:
            if bpy.app.timers.is_registered(callback):
                bpy.app.timers.unregister(callback)
        except Exception:
            pass
        _SMART_TOOLS_MANAGER_COMPAT_TIMERS.discard(callback)


def _restore_smart_tools_manager_compat() -> None:
    _cancel_smart_tools_manager_compat_timers()



def _legacy_anchor_poll(_cls, _context) -> bool:
    return False


def _legacy_anchor_draw(self, _context) -> None:
    try:
        self.layout.label(text="Smart Render")
    except Exception:
        pass


class SMART_RENDER_SUITE_PT_sidebar_anchor(bpy.types.Panel):
    """Hidden compatibility panel used only to neutralize stale RNA callbacks."""

    bl_label = "Smart Render"
    bl_idname = "SMART_RENDER_SUITE_PT_sidebar_anchor"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "SRS Hidden"
    bl_options = {"HIDE_HEADER"}
    bl_order = -10000

    @classmethod
    def poll(cls, context):
        return _legacy_anchor_poll(cls, context)

    def draw(self, context):
        del context
        _legacy_anchor_draw(self, None)


class SMART_RENDER_SUITE_IMAGE_PT_sidebar_anchor(SMART_RENDER_SUITE_PT_sidebar_anchor):
    bl_idname = "SMART_RENDER_SUITE_IMAGE_PT_sidebar_anchor"
    bl_space_type = "IMAGE_EDITOR"

    @classmethod
    def poll(cls, context):
        return _legacy_anchor_poll(cls, context)


# Assign direct class-dictionary callbacks immediately.  Blender's RNA callback
# resolver asks the registered Python class object for a direct ``poll`` member;
# relying only on inheritance or a later unregister pass can leave a stale class
# without that member during drag-and-drop extension replacement.
try:
    SMART_RENDER_SUITE_PT_sidebar_anchor.poll = classmethod(_legacy_anchor_poll)
    SMART_RENDER_SUITE_IMAGE_PT_sidebar_anchor.poll = classmethod(_legacy_anchor_poll)
except Exception:
    pass


def _iter_all_subclasses(base: type | None) -> tuple[type, ...]:
    if base is None:
        return tuple()
    result: list[type] = []
    stack: list[type] = []
    try:
        stack.extend(tuple(base.__subclasses__()))
    except Exception:
        return tuple()
    seen: set[int] = set()
    while stack:
        cls = stack.pop()
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        result.append(cls)
        try:
            stack.extend(tuple(cls.__subclasses__()))
        except Exception:
            pass
    return tuple(result)


def _registered_type_by_name(name: str):
    try:
        text = str(name or "").strip()
    except Exception:
        text = ""
    if not text:
        return None
    try:
        existing = getattr(bpy.types, text, None) if text.isidentifier() else None
    except Exception:
        existing = None
    if isinstance(existing, type):
        return existing
    # Do not call Panel.bl_rna_get_subclass_py here.  Blender 5.1 can enter
    # recursive RNA subclass lookup while a Sidebar redraw or extension ZIP
    # replacement is in progress; that path is a known crash vector.  Exact
    # attribute lookup, Python subclass scans, and current compatibility anchors
    # are sufficient for safe cleanup without touching the recursive C lookup.
    return None


def _iter_gc_classes_by_name(name: str) -> tuple[type, ...]:
    # Disabled deliberately.  A Windows 5.1.0 exit crash was traced to walking
    # gc.get_objects() and querying RNA-backed class attributes while Blender was
    # already inside addon_utils.disable_all().  Registered Panel classes are
    # reachable through bpy.types exact lookup or Panel.__subclasses__(); those
    # two paths are sufficient and do not touch arbitrary RNA objects.
    del name
    return tuple()


def _find_legacy_anchor_classes(name: str) -> list[type]:
    found: list[type] = []
    existing = _registered_type_by_name(name)
    if isinstance(existing, type):
        found.append(existing)
    try:
        panel_base = getattr(bpy.types, "Panel", None)
    except Exception:
        panel_base = None
    for cls in _iter_all_subclasses(panel_base):
        try:
            if _safe_class_name(cls) == name or _safe_class_attr_string(cls, "bl_idname") == name:
                if cls not in found:
                    found.append(cls)
        except Exception:
            continue
    return found


def _patch_legacy_anchor_class(cls: type | None) -> None:
    _install_global_panel_poll_guard()
    if cls is None or not isinstance(cls, type):
        return
    try:
        setattr(cls, "poll", classmethod(_legacy_anchor_poll))
    except Exception:
        pass
    try:
        if not callable(getattr(cls, "draw", None)):
            setattr(cls, "draw", _legacy_anchor_draw)
    except Exception:
        pass
    try:
        cls.bl_label = "Smart Render Compatibility"
        cls.bl_region_type = "UI"
        # Keep compatibility anchors outside the public Smart Render category.
        # Blender 5.1 can keep root panel headers materialized during Sidebar
        # rebuilds even when poll() is false, which creates duplicate panels.
        cls.bl_category = "SRS Hidden"
        try:
            cls.bl_options = {"HIDE_HEADER"}
        except Exception:
            pass
        identifier = _safe_class_name(cls) or _safe_class_attr_string(cls, "bl_idname")
        cls.bl_space_type = "IMAGE_EDITOR" if "IMAGE" in identifier else "VIEW_3D"
    except Exception:
        pass


def _is_current_legacy_anchor_class(cls: type | None) -> bool:
    return cls in {
        SMART_RENDER_SUITE_PT_sidebar_anchor,
        SMART_RENDER_SUITE_IMAGE_PT_sidebar_anchor,
    }


def _class_has_own_bl_rna(cls: type | None) -> bool:
    if cls is None or not isinstance(cls, type):
        return False
    try:
        return _safe_class_dict(cls).get("bl_rna") is not None
    except Exception:
        return False


def _unregister_legacy_anchor_class(cls: type | None) -> bool:
    if cls is None or not isinstance(cls, type):
        return False
    _patch_legacy_anchor_class(cls)
    try:
        bpy.utils.unregister_class(cls)
        return True
    except Exception:
        # Keep the patched hidden poll in place when Blender refuses to unregister
        # a class during a live UI/RNA refresh.  The next timer pass will try again.
        _patch_legacy_anchor_class(cls)
        return False


def _repair_legacy_anchor_panels() -> None:
    """Neutralize obsolete anchor classes left by older live reloads.

    Blender 5.1 can keep an old ``SMART_RENDER_SUITE_PT_sidebar_anchor`` Python
    class in an RNA callback table after a live extension replacement.  The safe
    repair is to materialize a direct ``poll`` attribute on every exact anchor
    class we can reach and keep it hidden.  Do not unregister those stale anchor
    classes here: unregistering can leave Blender with a C-side callback that
    points at a Python class whose dictionary no longer contains ``poll``.

    This function must not run during Blender shutdown.  The Windows 5.1.0 crash
    log shows addon_utils.disable_all() entering unregister() and then crashing
    while legacy anchor discovery touched RNA-backed class attributes.
    """
    if globals().get("_UNREGISTERING", False) or _is_blender_exiting():
        return
    _install_global_panel_poll_guard()
    for name in _LEGACY_ANCHOR_CLASS_NAMES:
        for cls in tuple(_find_legacy_anchor_classes(name)):
            _patch_legacy_anchor_class(cls)
    try:
        _patch_legacy_anchor_class(SMART_RENDER_SUITE_PT_sidebar_anchor)
        _patch_legacy_anchor_class(SMART_RENDER_SUITE_IMAGE_PT_sidebar_anchor)
    except Exception:
        pass


def _cleanup_legacy_anchor_panels() -> None:
    # Kept as a compatibility alias for older code paths.  It intentionally no
    # longer unregisters anchors and never scans arbitrary GC objects.  During
    # unregister/Blender exit it is a no-op to avoid RNA class inspection while
    # Blender is tearing down the UI type registry.
    if globals().get("_UNREGISTERING", False) or _is_blender_exiting():
        return
    _repair_legacy_anchor_panels()


def _ensure_legacy_anchor_classes_registered() -> None:
    global _LEGACY_ANCHORS_REGISTERED
    # Current builds do not register compatibility anchors as public N-panel
    # classes. Older versions used them as loading placeholders, but keeping a
    # second root class in the Smart Render category can make Blender 5.1 show two
    # Smart Render panels. We only patch already-registered stale anchors and,
    # when Blender is not exiting, unregister them after poll=False is direct.
    _repair_legacy_anchor_panels()
    for name in _LEGACY_ANCHOR_CLASS_NAMES:
        for existing in tuple(_find_legacy_anchor_classes(name)):
            _patch_legacy_anchor_class(existing)
            if _is_blender_exiting() or globals().get("_UNREGISTERING", False):
                continue
            try:
                if 'bl_rna' in existing.__dict__:
                    bpy.utils.unregister_class(existing)
            except Exception:
                _patch_legacy_anchor_class(existing)
    for cls in (SMART_RENDER_SUITE_PT_sidebar_anchor, SMART_RENDER_SUITE_IMAGE_PT_sidebar_anchor):
        _patch_legacy_anchor_class(cls)
    _LEGACY_ANCHORS_REGISTERED = True
    _repair_legacy_anchor_panels()


def _legacy_anchor_cleanup_needed() -> bool:
    # Only schedule a repair timer for classes that are actually registered in
    # Blender's RNA type registry. The current compatibility class definitions
    # also appear in Panel.__subclasses__(), but they are not public panels and
    # do not need an 80-pass repair loop during normal viewport use.
    try:
        return any(isinstance(_registered_type_by_name(name), type) for name in _LEGACY_ANCHOR_CLASS_NAMES)
    except Exception:
        return False


def _schedule_legacy_anchor_cleanup(first_interval: float = 0.02, attempts: int = 80) -> None:
    del first_interval, attempts
    return None


def _cancel_legacy_anchor_cleanup_timers() -> None:
    timers = getattr(getattr(bpy, "app", None), "timers", None)
    unregister_timer = getattr(timers, "unregister", None) if timers is not None else None
    is_registered = getattr(timers, "is_registered", None) if timers is not None else None
    for callback in tuple(_LEGACY_ANCHOR_CLEANUP_TIMERS):
        try:
            if callable(unregister_timer):
                if callable(is_registered):
                    if is_registered(callback):
                        unregister_timer(callback)
                else:
                    unregister_timer(callback)
        except Exception:
            pass
        try:
            _LEGACY_ANCHOR_CLEANUP_TIMERS.discard(callback)
        except Exception:
            pass
    try:
        _LEGACY_ANCHOR_CLEANUP_TIMERS.clear()
    except Exception:
        pass


try:
    _repair_legacy_anchor_panels()
except Exception:
    pass


def _remove_legacy_runtime_preferences_pointer() -> None:
    try:
        if hasattr(bpy.types.WindowManager, "smart_render_suite_runtime_prefs"):
            delattr(bpy.types.WindowManager, "smart_render_suite_runtime_prefs")
    except Exception:
        pass




def _package_module_name(relative_name: str) -> str:
    package = __package__ or __name__
    return f"{package}.{relative_name}"


def _loaded_package_module(relative_name: str):
    """Return an already loaded submodule without reloading it.

    Blender unregister must use the exact Python class objects that were
    registered earlier.  Reloading a module before unregister creates new class
    objects, leaving the old RNA callbacks registered and causing stale callback
    errors during Blender 5.1 live reloads.
    """
    try:
        return _sys.modules.get(_package_module_name(relative_name))
    except Exception:
        return None


def _import_package_module_if_needed(relative_name: str):
    module = _loaded_package_module(relative_name)
    if module is not None:
        return module
    return _importlib.import_module(f".{relative_name}", __package__ or __name__)

def _reload_package_module(relative_name: str):
    """Import or reload a package submodule without creating top-level aliases."""
    package = __package__ or __name__
    fullname = f"{package}.{relative_name}"
    _importlib.invalidate_caches()
    module = _sys.modules.get(fullname)
    if module is None:
        module = _importlib.import_module(f".{relative_name}", package)
    else:
        module = _importlib.reload(module)
    _purge_top_level_alias_modules()
    return module


def _tag_supported_npanel_redraw() -> None:
    try:
        wm = getattr(bpy.context, "window_manager", None)
        for window in getattr(wm, "windows", ()) or ():
            screen = getattr(window, "screen", None)
            for area in getattr(screen, "areas", ()) or ():
                if str(getattr(area, "type", "") or "") in {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}:
                    try:
                        area.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass


def _preflight_cleanup() -> None:
    # Delete only abandoned in-package files/modules from older SmartTools-window
    # builds. This does not patch Blender UI classes, theme values, or panel draw
    # functions.
    try:
        runtime = _reload_package_module("runtime")
        runtime.preflight_cleanup(__package__ or __name__, __name__, __file__)
    except Exception:
        pass

    # Remove broken empty tool-select shortcuts left by previous builds, without
    # creating, cloning, or saving Blender keymaps.
    try:
        console_clean = _reload_package_module("console_clean")
        clean = getattr(console_clean, "clean_keymaps_and_preferences", None)
        if callable(clean):
            clean(save=False)
    except Exception:
        pass


def _register_runtime_settings() -> None:
    global _RUNTIME_SETTINGS_REGISTERED
    if _RUNTIME_SETTINGS_REGISTERED:
        return
    _remove_legacy_runtime_preferences_pointer()
    _reload_package_module("rna_safety")
    preferences = _reload_package_module("preferences")
    preferences.register()
    _RUNTIME_SETTINGS_REGISTERED = True


def _unregister_runtime_settings() -> None:
    global _RUNTIME_SETTINGS_REGISTERED
    if not _RUNTIME_SETTINGS_REGISTERED:
        return
    try:
        preferences = _loaded_package_module("preferences")
        if preferences is not None and callable(getattr(preferences, "unregister", None)):
            preferences.unregister()
    finally:
        _RUNTIME_SETTINGS_REGISTERED = False


def refresh_integrated_runtime_from_settings(context=None) -> bool:
    # Runtime setting update hook. The standard N-panel UI does not use the old
    # SmartTools host runtime, so a redraw is sufficient.
    del context
    try:
        tool_registry = _reload_package_module("tool_registry")
        tool_registry.clear_cache()
    except Exception:
        pass
    _tag_supported_npanel_redraw()
    return True


def is_full_runtime_loaded() -> bool:
    return bool(_REGISTERED)


def ensure_full_runtime_loaded() -> bool:
    if not _REGISTERED:
        register()
    return bool(_REGISTERED)


def release_full_runtime() -> None:
    # Compatibility entry point for older preference callbacks.
    return None


def register() -> None:
    global _REGISTERED, _CORE_RUNTIME_REGISTER_ERROR, _UNREGISTERING
    _UNREGISTERING = False
    _unregister_stale_smart_render_dynamic_panels_before_module_purge()
    if _REGISTERED:
        return

    _CORE_RUNTIME_REGISTER_ERROR = ""
    _install_global_panel_poll_guard()
    _unregister_stale_smart_render_dynamic_panels_before_module_purge()
    _purge_top_level_alias_modules()
    _cleanup_legacy_anchor_panels()
    _ensure_legacy_anchor_classes_registered()
    _remove_legacy_runtime_preferences_pointer()
    _preflight_cleanup()

    registered_translation = False
    registered_runtime_settings = False
    registered_runtime = False
    try:
        translation = _reload_package_module("translation")
        translation.register()
        registered_translation = True

        _register_runtime_settings()
        registered_runtime_settings = True

        registration = _reload_package_module("registration")
        registered_runtime = True
        registration.register()

        _REGISTERED = True
        _cleanup_legacy_anchor_panels()
        _tag_supported_npanel_redraw()
    except Exception as exc:
        _CORE_RUNTIME_REGISTER_ERROR = str(exc)
        if registered_runtime:
            try:
                registration = _reload_package_module("registration")
                registration.unregister()
            except Exception:
                pass
        if registered_runtime_settings:
            try:
                _unregister_runtime_settings()
            except Exception:
                pass
        if registered_translation:
            try:
                translation = _reload_package_module("translation")
                translation.unregister()
            except Exception:
                pass
        _REGISTERED = False
        _cleanup_legacy_anchor_panels()
        _purge_top_level_alias_modules()
        raise


def unregister() -> None:
    global _REGISTERED, _UNREGISTERING
    _UNREGISTERING = True
    try:
        _cancel_legacy_anchor_cleanup_timers()
        try:
            registration = _loaded_package_module("registration")
            if registration is not None and callable(getattr(registration, "unregister", None)):
                registration.unregister()
        except Exception:
            pass
        try:
            _unregister_runtime_settings()
        except Exception:
            pass
        try:
            translation = _loaded_package_module("translation")
            if translation is not None and callable(getattr(translation, "unregister", None)):
                translation.unregister()
        except Exception:
            pass
        # Do not run legacy-anchor discovery or UI redraw during Blender exit.
        # The crash log shows addon_utils.disable_all() entered unregister(), then
        # RNA class inspection in anchor cleanup dereferenced an invalid property
        # path.  At shutdown we only restore the temporary base Panel.poll guard
        # and purge extension-policy aliases; no gc/RNA scan, no redraw.
        _restore_global_panel_poll_guard()
        _purge_top_level_alias_modules()
    finally:
        _REGISTERED = False
        _UNREGISTERING = False


# --- Smart common extension patch START ---
_SMART_ORIGINAL_REGISTER = globals().get("register")
_SMART_ORIGINAL_UNREGISTER = globals().get("unregister")


def _fresh_common_module(*, reload_module: bool = True):
    try:
        if reload_module:
            return _reload_package_module("common")
        return _loaded_package_module("common")
    except Exception:
        return None


def register():
    _unregister_stale_smart_render_dynamic_panels_before_module_purge()
    _SMART_SETTINGS = None
    try:
        _SMART_SETTINGS = _loaded_package_module("settings") or _reload_package_module("settings")
        _begin_settings_registration = getattr(_SMART_SETTINGS, "begin_registration", None)
        if callable(_begin_settings_registration):
            _begin_settings_registration()
    except Exception:
        _SMART_SETTINGS = None
    _SMART_COMMON = _fresh_common_module()
    if _SMART_COMMON is not None:
        try:
            _SMART_COMMON.begin_register()
        except Exception:
            pass
    try:
        if callable(_SMART_ORIGINAL_REGISTER):
            _SMART_ORIGINAL_REGISTER()
        _unregister_stale_smart_render_dynamic_panels_before_module_purge(remove_root_panels=False)
        if _SMART_COMMON is not None:
            _SMART_COMMON.register()
        try:
            _registration_module = _loaded_package_module("registration")
            _ensure_roots = getattr(_registration_module, "ensure_root_panel_classes", None) if _registration_module is not None else None
            if callable(_ensure_roots):
                _ensure_roots()
        except Exception:
            pass
        _install_global_panel_poll_guard()
        try:
            _settings_module = _loaded_package_module("settings")
            _ctx = getattr(bpy, "context", None)
            _apply_context = getattr(_settings_module, "apply_context", None) if _settings_module is not None else None
            _snapshot_context = getattr(_settings_module, "snapshot_context", None) if _settings_module is not None else None
            _is_state_save = getattr(_settings_module, "is_npanel_state_save_enabled", None) if _settings_module is not None else None
            if callable(_apply_context):
                _apply_context(_ctx, force=True)
            if callable(_snapshot_context) and callable(_is_state_save):
                _snapshot_context(_ctx, force=bool(_is_state_save(_ctx)))
        except Exception:
            pass
        try:
            _blend_cleanup = _loaded_package_module("blend_cleanup") or _reload_package_module("blend_cleanup")
            _install_blend_cleanup = getattr(_blend_cleanup, "install", None) if _blend_cleanup is not None else None
            if callable(_install_blend_cleanup):
                _install_blend_cleanup()
        except Exception:
            pass
        _cleanup_legacy_anchor_panels()
        _purge_top_level_alias_modules()
    finally:
        if _SMART_SETTINGS is not None:
            try:
                _end_settings_registration = getattr(_SMART_SETTINGS, "end_registration", None)
                if callable(_end_settings_registration):
                    _end_settings_registration(getattr(bpy, "context", None))
            except Exception:
                pass
        if _SMART_COMMON is not None:
            try:
                _SMART_COMMON.end_register()
            except Exception:
                pass


def unregister():
    global _UNREGISTERING
    _UNREGISTERING = True
    _cancel_legacy_anchor_cleanup_timers()
    _cancel_smart_tools_manager_compat_timers()
    try:
        _blend_cleanup = _loaded_package_module("blend_cleanup")
        _uninstall_blend_cleanup = getattr(_blend_cleanup, "uninstall", None) if _blend_cleanup is not None else None
        if callable(_uninstall_blend_cleanup):
            _uninstall_blend_cleanup()
    except Exception:
        pass
    try:
        _SMART_COMMON = _fresh_common_module(reload_module=False)
        if _SMART_COMMON is not None:
            try:
                _SMART_COMMON.unregister()
            except Exception:
                pass
        if callable(_SMART_ORIGINAL_UNREGISTER):
            _SMART_ORIGINAL_UNREGISTER()
        _restore_global_panel_poll_guard()
        _purge_top_level_alias_modules()
    finally:
        _UNREGISTERING = False
# --- Smart common extension patch END ---


if __name__ == "__main__":
    register()


# --- JELararagi shared single-slot status integration v2 ---
try:
    _JEL_STATUS_ORIGINAL_REGISTER_V2 = register
    _JEL_STATUS_ORIGINAL_UNREGISTER_V2 = unregister
except Exception:
    _JEL_STATUS_ORIGINAL_REGISTER_V2 = None
    _JEL_STATUS_ORIGINAL_UNREGISTER_V2 = None


def _jel_status_instrument_class_v2(cls):
    try:
        from . import status_runtime as _jel_status_runtime_v2
        return _jel_status_runtime_v2.instrument_operator_class(
            cls, 'smart_render_suite', 'Smart Render Suite'
        )
    except Exception:
        return cls


def register():
    if not callable(_JEL_STATUS_ORIGINAL_REGISTER_V2):
        return None
    try:
        from . import status_runtime as _jel_status_runtime_v2
    except Exception:
        _jel_status_runtime_v2 = None
    if _jel_status_runtime_v2 is not None:
        with _jel_status_runtime_v2.capture_registration_callbacks(
            'smart_render_suite', 'Smart Render Suite'
        ):
            result = _JEL_STATUS_ORIGINAL_REGISTER_V2()
    else:
        result = _JEL_STATUS_ORIGINAL_REGISTER_V2()
    try:
        if _jel_status_runtime_v2 is None:
            from . import status_runtime as _jel_status_runtime_v2
        _jel_status_runtime_v2.instrument_loaded_package_operators(
            'smart_render_suite', 'smart_render_suite', 'Smart Render Suite'
        )
    except Exception:
        pass
    return result


def unregister():
    try:
        if callable(_JEL_STATUS_ORIGINAL_UNREGISTER_V2):
            return _JEL_STATUS_ORIGINAL_UNREGISTER_V2()
        return None
    finally:
        try:
            from . import status_runtime as _jel_status_runtime_v2
            _jel_status_runtime_v2.clear_prefix('smart_render_suite')
        except Exception:
            pass

# --- JELararagi shared single-slot status integration v2 --- END

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)

# English text for Japanese source strings.
from .locale_fallback import wrap as _locale_fallback_wrap

register, unregister = _locale_fallback_wrap(register, unregister)
