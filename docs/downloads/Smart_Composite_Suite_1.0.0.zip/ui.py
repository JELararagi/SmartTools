# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from __future__ import annotations

from functools import lru_cache
from textwrap import wrap

import bpy

from .catalog import search_features, search_feature_count
from . import catalog as _catalog_runtime
from .properties import get_settings
from . import properties
from .translation import t
from . import persistent_features, visual_assets
from . import manager_bridge



_APEX_COMMAND_QUICK_PRESETS = (
    ("AOV_DELTA_VERIFIER", "AOV差分", "AOV Delta"),
    ("DEEP_MATTE_FUSION_LAB", "深層マット", "Deep Matte"),
    ("LENS_APERTURE_DESIGNER", "絞り設計", "Lens Design"),
    ("DYNAMIC_RANGE_SCULPTOR", "HDR整形", "HDR Sculpt"),
    ("PERCEPTION_MATCH_ASSISTANT", "知覚マッチ", "Perception"),
    ("ADAPTIVE_DENOISE_PROFILE_LAB", "復元プロファイル", "Denoise Profile"),
    ("MOTION_FLOW_GUARD", "動き保護", "Motion Guard"),
    ("GEOMETRY_SIGNAL_BRIDGE", "3D信号", "Geometry"),
    ("DELIVERY_SANITY_CHECK", "納品QC", "Delivery QC"),
    ("APEX_VISUAL_GUIDE_BOARD", "画像ガイド", "Visual Guide"),
)

_LAUNCHPAD_PRIMARY_PRESETS = (
    ("SCS_ULTRA_LAUNCHPAD", "超精度総合", "Ultra"),
    ("SURPASS_MASTER_WORKSPACE", "凌駕総合", "Surpass"),
    ("AOV_INTEGRITY_MATRIX", "AOV整合", "AOV Integrity"),
    ("MATTE_MICROSURGERY_ENGINE", "マット微細", "Matte Micro"),
    ("PHYSICAL_OPTICS_ENGINE", "物理光学", "Optics"),
    ("PERCEPTUAL_FINISHING_HUB", "知覚カラー", "Perceptual Color"),
    ("ADAPTIVE_RESTORE_ENGINE", "適応復元", "Adaptive Restore"),
    ("PRECISION_QC_SUITE", "精度QC", "Precision QC"),
)

# The preset section shows result images only: the selected preset's packaged
# result image in the panel and every preset's image in the grid that opens from
# it (see result_previews).  Both scales are in UI units.
_RESULT_IMAGE_SCALE = 7.0
_RESULT_GRID_SCALE = 4.0


class _SCS_CompositorPanelMixin:
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Smart Composite"

    @classmethod
    def poll(cls, context):
        # A sidebar category can remain selected while Blender or Smart Tools
        # Manager is still refreshing workspace/editor rules. Returning False
        # here leaves the category tab visible but the panel body/header empty.
        # Keep the add-on's own panel poll context-neutral; Smart Tools Manager
        # controls runtime loading/unloading and side-bar targeting externally.
        return True

def _settings(context):
    return get_settings(context)


_PANEL_HEADER_BUILTIN_ICONS = {
    "aov": "IMAGE_DATA",
    "apex": "NODETREE",
    "audit": "VIEWZOOM",
    "catalog": "FILE_FOLDER",
    "clock": "TIME",
    "delivery": "EXPORT",
    "favorites": "ADD",
    "help": "QUESTION",
    "hero": "PREFERENCES",
    "output": "EXPORT",
    "pipeline": "NODETREE",
    "qc": "CHECKMARK",
    "reference": "IMAGE_DATA",
    "scs_logo": "NODETREE",
    "setup": "NODETREE",
}


@lru_cache(maxsize=64)
def _panel_header_icon(icon_key: str) -> str:
    try:
        return visual_assets.safe_builtin_icon(_PANEL_HEADER_BUILTIN_ICONS.get(str(icon_key or ""), "DOT"), "DOT")
    except Exception:
        return "DOT"


@lru_cache(maxsize=256)
def _preset_icon_spec(preset_id: str) -> tuple[str, int]:
    try:
        return visual_assets.preset_icon_spec(preset_id)
    except Exception:
        return ("ADD", 0)


def _label(layout, ja: str, en: str, settings=None, icon: str = "NONE"):
    layout.label(text=t(ja, en, settings), icon=icon)


def _valid_icon_value(value: int | str | None) -> int:
    try:
        number = int(value or 0)
        return number if number > 0 else 0
    except Exception:
        return 0


def _operator(layout, op_id: str, ja: str, en: str, settings=None, icon: str = "NONE", icon_value: int = 0, emboss=True, icon_key: str = "", **props):
    text = t(ja, en, settings)
    if icon_key:
        resolved_icon, resolved_icon_value = visual_assets.icon_spec(icon_key, icon)
        if resolved_icon_value:
            icon_value = resolved_icon_value
            icon = "NONE"
        else:
            icon = resolved_icon or icon
    icon_value = _valid_icon_value(icon_value)
    if icon_value:
        op = layout.operator(op_id, text=text, icon_value=icon_value, emboss=emboss)
    else:
        op = layout.operator(op_id, text=text, icon=visual_assets.safe_builtin_icon(icon, "NONE"), emboss=emboss)
    for name, value in props.items():
        try:
            setattr(op, name, value)
        except Exception:
            pass
    return op


def _help_button(layout, help_id: str, settings=None, *, scale_x: float = 0.82, leading_gap: bool = False):
    """Draw a compact Help icon-only button."""
    if leading_gap:
        try:
            layout.separator(factor=0.35)
        except TypeError:
            try:
                layout.separator()
            except Exception:
                pass
        except Exception:
            pass
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = float(scale_x)
    except Exception:
        pass
    icon_name, icon_value = visual_assets.icon_spec("help", "QUESTION")
    if icon_value:
        op = row.operator("smart_composite.show_tool_help", text="", icon_value=icon_value, emboss=True)
    else:
        op = row.operator("smart_composite.show_tool_help", text="", icon=icon_name or "QUESTION", emboss=True)
    try:
        op.alias = str(help_id or "root")
    except Exception:
        pass
    return op


def _draw_panel_header(layout, context, icon_key: str, help_id: str, ja: str, en: str):
    settings = _settings(context)
    row = layout.row(align=True)
    # Panel headers are handled by Blender's C-level panel event code.
    # Keep them on validated built-in icons only; custom preview IDs remain
    # available for the actual icon buttons inside the panel.
    row.label(text="", icon=_panel_header_icon(icon_key))
    row.label(text=t(ja, en, settings))
    _help_button(row, help_id, settings)


_PROP_LABELS = {
    "n_panel_state_save": ("Nパネル状態保存", "N-panel State Save"),
    "show_always_on_toggles": ("常時機能切り替え", "Always-on Toggles"),
    "persistent_ui_asset_cache": ("UIアイコンキャッシュ", "UI Icon Cache"),
    "persistent_auto_enable_compositor": ("コンポジター自動維持", "Compositor Keep-Alive"),
    "persistent_auto_render_pass_guard": ("レンダーパス自動維持", "Render Pass Guard"),
    "persistent_auto_precision_output_guard": ("精度出力自動維持", "Precision Output Guard"),
    "persistent_auto_node_tree_sanity": ("ノード健全性ガード", "Node Sanity Guard"),
    "persistent_live_quality_status": ("品質ステータス自動更新", "Auto Quality Status"),
    "ui_launcher_style": ("ランチャー表示", "Launcher Style"),
    "hero_icon_scale": ("ヒーローアイコン倍率", "Hero Icon Scale"),
    "auto_optimize_ui_visibility": ("UI視認性を優先", "Prioritize UI Visibility"),
    "launcher_columns": ("アイコン列数", "Icon Columns"),
    "large_icon_scale": ("アイコン倍率", "Icon Scale"),
    "precision_mode": ("精度モード", "Precision Mode"),
    "artifact_guard": ("破綻抑制", "Artifact Guard"),
    "qc_density": ("QC密度", "QC Density"),
    "glow_quality": ("グロー品質", "Glow Quality"),
    "artifact_guard_strength": ("破綻ガード", "Artifact Guard Strength"),
    "edge_protection": ("エッジ保護", "Edge Protection"),
    "matte_edge_safety": ("マット縁保護", "Matte Edge Safety"),
    "highlight_ceiling": ("ハイライト保護", "Highlight Guard"),
    "optical_realism": ("光学リアリズム", "Optical Realism"),
    "restoration_strength": ("復元強度", "Restoration Strength"),
    "precision_layers": ("精度レイヤー数", "Precision Layers"),
    "matte_edge_radius": ("マット縁半径", "Matte Edge Radius"),
    "depth_near": ("深度手前", "Depth Near"),
    "depth_far": ("深度奥", "Depth Far"),
    "auto_connect_outputs": ("ビューアー／コンポジットへ自動接続", "Auto-connect Viewer/Composite"),
    "create_diagnostic_viewers": ("診断ビューアーを作成", "Create Diagnostic Viewers"),
    "create_file_outputs": ("ファイル出力を作成", "Create File Output"),
    "artifact_diagnostics": ("破綻診断レーン", "Artifact Diagnostic Lanes"),
    "workflow_guidance_level": ("工程ガイド密度", "Workflow Guide Density"),
    "reference_preview_scale": ("リファレンス表示倍率", "Reference Preview Scale"),
    "reference_columns": ("リファレンス列数", "Reference Columns"),
    "show_reference_previews": ("画像リファレンスを表示", "Show Visual References"),
    "output_path": ("出力パス", "Output Path"),
    "node_offset_x": ("追加位置X", "Insertion X Offset"),
    "preset": ("追加プリセット", "Preset to Add"),
    "category_filter": ("カテゴリ", "Category"),
    "source_filter": ("SCSエンジン", "SCS Engine"),
    "catalog_limit": ("表示件数", "Display Count"),
}


def _prop(layout, settings, attr: str, *, text=None, icon=None):
    if text is None:
        ja, en = _PROP_LABELS.get(attr, (attr, attr))
        text = t(ja, en, settings)
    kwargs = {"text": text}
    if icon is not None:
        kwargs["icon"] = icon
    return layout.prop(settings, attr, **kwargs)


_DISCLOSURE_ICONS = {True: "TRIA_DOWN", False: "TRIA_RIGHT"}


def _launcher_style_menu(layout, settings):
    ja, en = _PROP_LABELS.get("ui_launcher_style", ("ランチャー表示", "Launcher Style"))
    return layout.operator_menu_enum("smart_composite.set_launcher_style", "style", text=t(ja, en, settings))


def _icon_only_operator(layout, op_id: str, ja: str, en: str, settings=None, icon: str = "NONE", icon_value: int = 0, icon_key: str = "", **props):
    if icon_key:
        resolved_icon, resolved_icon_value = visual_assets.icon_spec(icon_key, icon)
        if resolved_icon_value:
            icon_value = resolved_icon_value
            icon = "NONE"
        else:
            icon = resolved_icon or icon
    icon_value = _valid_icon_value(icon_value)
    if icon_value:
        op = layout.operator(op_id, text="", icon_value=icon_value, emboss=True)
    else:
        op = layout.operator(op_id, text="", icon=visual_assets.safe_builtin_icon(icon, "NONE"), emboss=True)
    for name, value in props.items():
        try:
            setattr(op, name, value)
        except Exception:
            pass
    return op


def _icon_scale(settings) -> float:
    try:
        base = float(getattr(settings, "large_icon_scale", 6.5) or 6.5)
    except Exception:
        base = 6.5
    try:
        style = str(getattr(settings, "ui_launcher_style", "HERO") or "HERO")
    except Exception:
        style = "HERO"
    if bool(getattr(settings, "auto_optimize_ui_visibility", True)):
        base = max(base, 6.5)
        style = "HERO" if style not in {"COMPACT", "STANDARD"} else style
    if style == "COMPACT":
        base = min(max(base, 2.2), 3.2)
    elif style == "STANDARD":
        base = min(max(base, 3.0), 4.6)
    elif style == "CINEMA":
        base = min(max(base, 4.6), 6.4)
    else:
        base = min(max(base, 6.0), 8.0)
    return max(1.2, min(8.0, base))


def _hero_scale(settings) -> float:
    try:
        base = float(getattr(settings, "hero_icon_scale", 7.5) or 7.5)
    except Exception:
        base = 7.5
    if bool(getattr(settings, "auto_optimize_ui_visibility", True)):
        base = max(base, 7.5)
    return max(2.0, min(10.0, base))


def _grid_columns(settings) -> int:
    try:
        return max(1, min(4, int(getattr(settings, "launcher_columns", 2) or 2)))
    except Exception:
        return 2


def _reference_columns(settings) -> int:
    try:
        return max(1, min(2, int(getattr(settings, "reference_columns", 1) or 1)))
    except Exception:
        return 1


def _big_preset_button(layout, preset_id: str, ja: str, en: str, settings=None, hero: bool = False):
    col = layout.column(align=True)
    row = col.row(align=True)
    row.scale_y = _hero_scale(settings) if hero else _icon_scale(settings)
    icon_name, icon_value = _preset_icon_spec(preset_id)
    _icon_only_operator(row, "smart_composite.add_preset", ja, en, settings, icon_name, icon_value=icon_value, preset_id=preset_id)
    sub = col.row(align=True)
    sub.alignment = "CENTER"
    sub.label(text=t(ja, en, settings))
    _help_button(sub, f"preset:{preset_id}", settings)


def _reference_tile(layout, reference_id: str, settings=None):
    label_ja, label_en = visual_assets.REFERENCE_LABELS.get(reference_id, (reference_id, reference_id))
    col = layout.column(align=True)
    row = col.row(align=True)
    try:
        row.scale_y = max(1.0, min(3.0, float(getattr(settings, "reference_preview_scale", 2.0) or 2.0)))
    except Exception:
        row.scale_y = 2.0
    op = row.operator("smart_composite.open_reference_image", text="", icon="IMAGE_DATA", emboss=True)
    op.reference_id = reference_id
    label_row = col.row(align=True)
    label_row.alignment = "CENTER"
    op = label_row.operator("smart_composite.open_reference_image", text=t(label_ja, label_en, settings), icon="IMAGE_DATA", emboss=False)
    op.reference_id = reference_id




@lru_cache(maxsize=128)
def _section_icon_spec(icon_key: str, fallback: str = "TOOL_SETTINGS") -> tuple[str, int]:
    try:
        return visual_assets.icon_spec(icon_key, fallback)
    except Exception:
        return (fallback, 0)


def _section_state(settings, attr: str, default: bool = False) -> bool:
    try:
        if settings is not None and hasattr(settings, attr):
            return bool(getattr(settings, attr))
    except Exception:
        pass
    return bool(default)


def _section_toggle_operator(layout, attr: str, label: str, *, text: str = "", icon: str = "NONE", icon_value: int = 0, expanded: bool = False, emboss: bool = True):
    icon_value = _valid_icon_value(icon_value)
    if icon_value:
        op = layout.operator("smart_composite.toggle_ui_section", text=text, icon_value=icon_value, emboss=emboss, depress=bool(expanded))
    else:
        op = layout.operator("smart_composite.toggle_ui_section", text=text, icon=visual_assets.safe_builtin_icon(icon or "NONE", "NONE"), emboss=emboss, depress=bool(expanded))
    try:
        op.section_key = str(attr or "")
        op.label = str(label or attr or "")
    except Exception:
        pass
    return op


def _prepare_compact_section(layout, context, *, state_attr: str, icon_key: str, help_id: str, ja: str, en: str, draw_body, default_open: bool = False, container=None):
    settings = _settings(context)
    label = t(ja, en, settings)
    expanded = _section_state(settings, state_attr, default_open)
    box = container if container is not None else layout.box()
    try:
        box.use_property_split = False
        box.use_property_decorate = False
    except Exception:
        pass
    header = box.row(align=True)
    try:
        header.use_property_split = False
        header.use_property_decorate = False
    except Exception:
        pass
    _section_toggle_operator(
        header,
        state_attr,
        label,
        text="",
        icon=_DISCLOSURE_ICONS[bool(expanded)],
        expanded=expanded,
        emboss=True,
    )
    # Shared Smart Tools section header: triangle, borderless icon+title, small gap, compact help.
    try:
        icon_name, icon_value = visual_assets.icon_spec(icon_key, "TOOL_SETTINGS")
    except Exception:
        icon_name, icon_value = ("TOOL_SETTINGS", 0)
    _section_toggle_operator(
        header,
        state_attr,
        label,
        text=label,
        icon=icon_name,
        icon_value=icon_value,
        expanded=expanded,
        emboss=False,
    )
    _help_button(header, help_id, settings, leading_gap=True)
    return {
        "box": box,
        "expanded": bool(expanded),
        "draw_body": draw_body,
        "settings": settings,
    }


def _populate_compact_section(prepared, context):
    box = prepared["box"]
    if not prepared["expanded"]:
        return False
    settings = prepared["settings"]
    body = box.column(align=True)
    try:
        body.use_property_split = False
        body.use_property_decorate = False
    except Exception:
        pass
    try:
        prepared["draw_body"](body, context)
    except Exception:
        warn = body.box()
        warn.alert = True
        warn.label(text=t("このセクションの描画に失敗しました。", "Failed to draw this section.", settings), icon="ERROR")
    return True


def _draw_compact_section(layout, context, *, state_attr: str, icon_key: str, help_id: str, ja: str, en: str, draw_body, default_open: bool = False):
    prepared = _prepare_compact_section(
        layout,
        context,
        state_attr=state_attr,
        icon_key=icon_key,
        help_id=help_id,
        ja=ja,
        en=en,
        draw_body=draw_body,
        default_open=default_open,
    )
    return _populate_compact_section(prepared, context)


def _draw_panel_body(panel_cls, layout, context):
    class _Proxy:
        pass
    proxy = _Proxy()
    proxy.layout = layout
    panel_cls.draw(proxy, context)


def _draw_main_actions_body(layout, context):
    settings = _settings(context)
    if settings is not None and getattr(settings, "last_message", ""):
        box = layout.box()
        box.label(text=str(getattr(settings, "last_message", ""))[:220], translate=False)
    row = layout.row(align=True)
    _operator(row, "smart_composite.open_compositor_workspace", "コンポジターへ移動", "Go to Compositor", settings, "NONE", icon_key="setup")
    _operator(row, "smart_composite.audit_scene", "診断", "Audit", settings, "CHECKMARK", icon_key="audit")
    row = layout.row(align=True)
    _operator(row, "smart_composite.save_preferences", "プリファレンスの保存", "Save Preferences", settings, "PREFERENCES")


def _draw_persistent_toggles_body(layout, context):
    settings = _settings(context)
    if settings is None:
        layout.label(text=t("SCS設定を初期化中です。", "SCS settings are initializing.", settings))
        return
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    narrow = _narrow_sidebar(context)
    _draw_resident_switch(
        col, settings, "n_panel_state_save", t("Nパネル状態保存", "N-panel State Save", settings),
        bool(getattr(settings, "n_panel_state_save", True)), narrow,
    )
    col.separator(factor=0.5)
    for feature in persistent_features.feature_definitions():
        _draw_resident_switch(
            col, settings, feature.suite_property, persistent_features.localized_label(feature, settings),
            bool(persistent_features.feature_value(feature, context)), narrow,
        )


def _narrow_sidebar(context):
    region = context.region
    return region is not None and region.type in {"UI", "TOOL_PROPS"} and region.width <= 180


def _sidebar_lines(text, narrow):
    if not narrow:
        return (text,)
    if text.isascii():
        return wrap(text, width=13, break_long_words=False, break_on_hyphens=False)
    from .help import _wrap_cjk

    return _wrap_cjk(text, 14)


def _sidebar_label(layout, text, narrow):
    for line in _sidebar_lines(text, narrow):
        layout.label(text=line, translate=False)


def _draw_resident_switch(layout, settings, property_name, label, enabled, narrow):
    del narrow  # one shared row format at every sidebar width
    # Shared Smart Tools always-on row: label on the left, right-aligned Enabled/Disabled toggle.
    row = layout.row(align=True)
    row.scale_y = 0.95
    split = row.split(factor=0.72, align=True)
    left = split.row(align=True)
    left.label(text=label)
    right = split.row(align=True)
    right.alignment = "RIGHT"
    right.use_property_split = False
    right.use_property_decorate = False
    if hasattr(settings, property_name):
        right.row(align=True).prop(settings, property_name, text=t("有効", "On", settings) if enabled else t("無効", "Off", settings),
                   icon="CHECKBOX_HLT" if enabled else "CHECKBOX_DEHLT", toggle=True)
    else:
        disabled = right.row(align=True)
        disabled.enabled = False
        disabled.label(text=t("無効", "Off", settings), icon="CHECKBOX_DEHLT")


def _draw_registration_degraded(layout, context) -> None:
    """Render a read-only safe state without touching foreign Scene data."""
    settings = None
    box = layout.box()
    box.alert = True
    box.label(text=t("設定を読み込めません", "Settings unavailable", settings), icon="ERROR")
    col = box.column(align=True)
    for ja, en in (
        ("保存先を別の物が使用中です。", "Storage is in use elsewhere."),
        ("データは変更していません。", "Nothing was changed."),
        ("Blenderを再起動してから、", "Restart Blender, then"),
        ("もう一度有効にしてください。", "enable the add-on again."),
    ):
        col.label(text=t(ja, en, settings))


def _draw_unified_scs_ui(layout, context):
    layout.use_property_split = False
    layout.use_property_decorate = False
    if properties.safe_degradation_active():
        _draw_registration_degraded(layout, context)
        return
    sections = layout.column(align=False)
    top_boxes = tuple(sections.box() for _unused in SECTION_DEFINITIONS)
    prepared_sections = []
    for box, (state_attr, icon_key, help_id, ja, en, draw_body) in zip(
        top_boxes,
        SECTION_DEFINITIONS,
    ):
        prepared_sections.append(
            _prepare_compact_section(
                layout,
                context,
                state_attr=state_attr,
                icon_key=icon_key,
                help_id=help_id,
                ja=ja,
                en=en,
                draw_body=draw_body,
                default_open=False,
                container=box,
            )
        )
    for prepared in prepared_sections:
        _populate_compact_section(prepared, context)


def _draw_persistent_toggles(layout, context):
    settings = _settings(context)
    box = layout.box()
    is_open = bool(getattr(settings, "show_always_on_toggles", True)) if settings is not None else True
    header = box.row(align=True)
    if settings is not None and hasattr(settings, "show_always_on_toggles"):
        header.prop(settings, "show_always_on_toggles", text="", icon=_DISCLOSURE_ICONS[bool(is_open)], emboss=True)
    else:
        header.label(text="", icon=_DISCLOSURE_ICONS[bool(is_open)])
    clock_icon_name, clock_icon = visual_assets.icon_spec("clock", "TIME")
    if clock_icon:
        header.label(text=t("常時機能切り替え", "Always-on Toggles", settings), icon_value=clock_icon)
    else:
        header.label(text=t("常時機能切り替え", "Always-on Toggles", settings), icon=clock_icon_name or "TIME")
    _help_button(header, "persistent_toggles", settings)
    if not is_open:
        return
    if settings is None:
        box.label(text=t("SCS設定を初期化中です。", "SCS settings are initializing.", settings))
        return
    col = box.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    for feature in persistent_features.feature_definitions():
        value = bool(persistent_features.feature_value(feature, context))
        row = col.row(align=True)
        row.scale_y = 0.95
        split = row.split(factor=0.72, align=True)
        left = split.row(align=True)
        left.label(text=persistent_features.localized_label(feature, settings))
        right = split.row(align=True)
        right.use_property_split = False
        right.use_property_decorate = False
        if hasattr(settings, feature.suite_property):
            right.prop(
                settings,
                feature.suite_property,
                text=t("有効", "On", settings) if value else t("無効", "Off", settings),
                icon="CHECKBOX_HLT" if value else "CHECKBOX_DEHLT",
                toggle=True,
            )
        else:
            disabled = right.row(align=True)
            disabled.enabled = False
            disabled.label(text=t("無効", "Off", settings), icon="CHECKBOX_DEHLT")


class SCOMP_PT_root(_SCS_CompositorPanelMixin, bpy.types.Panel):
    bl_idname = "NODE_PT_smart_composite_root"
    bl_label = "Smart Composite"
    bl_order = 0
    _smart_tools_manager_tool_key = "SMART_COMPOSITE"
    _smart_composite_native_sidebar_host = True

    def draw(self, context):
        layout = self.layout
        _draw_unified_scs_ui(layout, context)


class SCOMP_PT_apex_command(_SCS_CompositorPanelMixin, bpy.types.Panel):
    bl_idname = "SCOMP_PT_apex_command"
    bl_label = ""
    bl_parent_id = ""
    bl_order = 3

    def draw_header(self, context):
        _draw_panel_header(self.layout, context, "apex", "apex_command", "Apexコマンドセンター", "Apex Command Center")

    def draw(self, context):
        settings = _settings(context)
        layout = self.layout
        if settings is not None:
            row = layout.row(align=True)
            _launcher_style_menu(row, settings)
            _prop(row, settings, "hero_icon_scale")
            row = layout.row(align=True)
            _prop(row, settings, "auto_optimize_ui_visibility")
            _operator(row, "smart_composite.optimize_ui_visibility", "視認性最適化", "Optimize UI Visibility", settings, "NONE", icon_key="hero")
        hero_grid = layout.grid_flow(row_major=True, columns=1, even_columns=True, even_rows=False, align=True)
        _big_preset_button(hero_grid, "APEX_COMMAND_WORKSPACE", "Apex統合", "Apex Command", settings, hero=True)
        grid = layout.grid_flow(row_major=True, columns=_grid_columns(settings), even_columns=True, even_rows=False, align=True)
        for preset_id, ja, en in _APEX_COMMAND_QUICK_PRESETS:
            _big_preset_button(grid, preset_id, ja, en, settings)


class SCOMP_PT_launchpad(_SCS_CompositorPanelMixin, bpy.types.Panel):
    bl_idname = "SCOMP_PT_launchpad"
    bl_label = ""
    bl_parent_id = ""
    bl_order = 5

    def draw_header(self, context):
        _draw_panel_header(self.layout, context, "scs_logo", "launchpad", "大アイコン・ランチャー", "Large Icon Launchpad")

    def draw(self, context):
        settings = _settings(context)
        layout = self.layout
        if settings is not None:
            controls = layout.column(align=True)
            _launcher_style_menu(controls, settings)
            row = controls.row(align=True)
            _prop(row, settings, "launcher_columns")
            _prop(row, settings, "large_icon_scale")
        layout.separator()
        grid = layout.grid_flow(row_major=True, columns=_grid_columns(settings), even_columns=True, even_rows=False, align=True)
        for preset_id, ja, en in _LAUNCHPAD_PRIMARY_PRESETS:
            _big_preset_button(grid, preset_id, ja, en, settings)
        layout.separator()
        row = layout.row(align=True)
        _operator(row, "smart_composite.apply_precision_settings", "シーン精度を適用", "Apply Scene Precision", settings, "CHECKMARK", icon_key="qc")
        _operator(row, "smart_composite.export_quality_report", "品質レポート", "Quality Report", settings, "EXPORT", icon_key="output")


class SCOMP_PT_precision_dashboard(_SCS_CompositorPanelMixin, bpy.types.Panel):
    bl_idname = "SCOMP_PT_precision_dashboard"
    bl_label = ""
    bl_parent_id = ""
    bl_order = 8

    def draw_header(self, context):
        _draw_panel_header(self.layout, context, "qc", "precision_dashboard", "精度ダッシュボード", "Precision Dashboard")

    def draw(self, context):
        settings = _settings(context)
        layout = self.layout
        if settings is None:
            return
        grid = layout.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for prop_name in (
            "precision_mode", "artifact_guard", "qc_density", "glow_quality",
            "artifact_guard_strength", "edge_protection", "matte_edge_safety",
            "highlight_ceiling", "optical_realism", "restoration_strength",
            "precision_layers", "matte_edge_radius",
        ):
            _prop(grid, settings, prop_name)
        row = layout.row(align=True)
        _prop(row, settings, "depth_near")
        _prop(row, settings, "depth_far")
        layout.separator()
        row = layout.row(align=True)
        _prop(row, settings, "auto_connect_outputs")
        _prop(row, settings, "create_diagnostic_viewers")
        row = layout.row(align=True)
        _prop(row, settings, "create_file_outputs")
        _prop(row, settings, "artifact_diagnostics")


class SCOMP_PT_ui_polish(_SCS_CompositorPanelMixin, bpy.types.Panel):
    bl_idname = "SCOMP_PT_ui_polish"
    bl_label = ""
    bl_parent_id = ""
    bl_order = 10

    def draw_header(self, context):
        _draw_panel_header(self.layout, context, "hero", "ui_polish", "UI洗練", "UI Polish")

    def draw(self, context):
        settings = _settings(context)
        layout = self.layout
        if settings is None:
            return
        col = layout.column(align=True)
        _launcher_style_menu(col, settings)
        _prop(col, settings, "auto_optimize_ui_visibility")
        row = col.row(align=True)
        _prop(row, settings, "large_icon_scale")
        _prop(row, settings, "hero_icon_scale")
        row = col.row(align=True)
        _prop(row, settings, "launcher_columns")
        _prop(row, settings, "workflow_guidance_level")
        row = col.row(align=True)
        _prop(row, settings, "reference_preview_scale")
        _prop(row, settings, "reference_columns")
        _operator(col, "smart_composite.optimize_ui_visibility", "視認性を最大化", "Maximize Visibility", settings, "NONE", icon_key="hero")


class SCOMP_PT_visual_references(_SCS_CompositorPanelMixin, bpy.types.Panel):
    bl_idname = "SCOMP_PT_visual_references"
    bl_label = ""
    bl_parent_id = ""
    bl_order = 12

    def draw_header(self, context):
        _draw_panel_header(self.layout, context, "reference", "visual_references", "画像リファレンス", "Visual References")

    def draw(self, context):
        settings = _settings(context)
        layout = self.layout
        if settings is None:
            return
        row = layout.row(align=True)
        _prop(row, settings, "show_reference_previews")
        _prop(row, settings, "reference_columns")
        _prop(layout, settings, "reference_preview_scale")
        if not bool(getattr(settings, "show_reference_previews", True)):
            return
        grid = layout.grid_flow(row_major=True, columns=_reference_columns(settings), even_columns=True, even_rows=False, align=True)
        for ref in visual_assets.REFERENCE_KEYS:
            _reference_tile(grid, ref, settings)


class SCOMP_PT_setup(_SCS_CompositorPanelMixin, bpy.types.Panel):
    bl_idname = "SCOMP_PT_setup"
    bl_label = ""
    bl_parent_id = ""
    bl_order = 15

    def draw_header(self, context):
        _draw_panel_header(self.layout, context, "setup", "setup", "セットアップ", "Setup")

    def draw(self, context):
        settings = _settings(context)
        layout = self.layout
        col = layout.column(align=True)
        _operator(col, "smart_composite.enable_compositor", "コンポジターを有効化", "Enable Compositor", settings, "NONE", icon_key="setup")
        _operator(col, "smart_composite.enable_render_passes", "レンダーパスを有効化", "Enable Render Passes", settings, "NONE", icon_key="aov")
        _operator(col, "smart_composite.apply_precision_settings", "シーン精度を適用", "Apply Scene Precision", settings, "CHECKMARK", icon_key="qc")
        _operator(col, "smart_composite.optimize_ui_visibility", "UI視認性を最適化", "Optimize UI Visibility", settings, "NONE", icon_key="hero")
        _operator(col, "smart_composite.add_preset", "Apex統合構成を作成", "Build Apex Command Stack", settings, "ADD", icon_key="apex", preset_id="APEX_COMMAND_WORKSPACE")
        _operator(col, "smart_composite.build_master_workspace", "総合作業台を作成", "Build Master Workspace", settings, "NONE", icon_key="pipeline")
        layout.separator()
        if settings is not None:
            col = layout.column(align=True)
            _prop(col, settings, "output_path")
            _prop(col, settings, "node_offset_x")


class SCOMP_PT_presets(_SCS_CompositorPanelMixin, bpy.types.Panel):
    bl_idname = "SCOMP_PT_presets"
    bl_label = ""
    bl_parent_id = ""
    bl_order = 20

    def draw_header(self, context):
        _draw_panel_header(self.layout, context, "favorites", "presets", "プリセット", "Presets")

    def draw(self, context):
        settings = _settings(context)
        layout = self.layout
        if settings is None:
            _label(layout, "設定を初期化中です。", "Settings are initializing.", settings)
            return
        selected = str(getattr(settings, "preset", "") or "")
        narrow = _narrow_sidebar(context)
        col = layout.column(align=True)
        # The preset list; every entry carries its result image as the icon.
        _prop(col, settings, "preset", text="")
        # The selected preset's result image.  Clicking it opens every preset's
        # result image with its name, so the list can also be browsed by image.
        col.template_icon_view(settings, "preset", show_labels=True,
                               scale=_RESULT_IMAGE_SCALE, scale_popup=_RESULT_GRID_SCALE)
        selected_icon, selected_icon_value = _preset_icon_spec(selected)
        apply_row = col.column(align=True) if narrow else col.row(align=True)
        _operator(apply_row, "smart_composite.add_preset",
                  "効果を適用" if narrow else "選択した効果を適用",
                  "Apply Effect" if narrow else "Apply Selected Effect", settings,
                  icon=selected_icon, icon_value=selected_icon_value, preset_id=selected)
        _help_button(apply_row, f"preset:{selected}", settings)


class SCOMP_PT_catalog(_SCS_CompositorPanelMixin, bpy.types.Panel):
    bl_idname = "SCOMP_PT_catalog"
    bl_label = ""
    bl_parent_id = ""
    bl_order = 30

    def draw_header(self, context):
        _draw_panel_header(self.layout, context, "catalog", "catalog", "独自ツールカタログ", "Original Tool Catalog")

    def draw(self, context):
        settings = _settings(context)
        layout = self.layout
        if settings is None:
            return
        col = layout.column(align=True)
        col.prop(settings, "search_text", text="", icon="VIEWZOOM")
        _prop(col, settings, "category_filter")
        _prop(col, settings, "source_filter")
        _prop(col, settings, "catalog_limit")
        limit = int(getattr(settings, "catalog_limit", 18) or 18)
        source_filter = str(getattr(settings, "source_filter", "ALL") or "ALL")
        search_text = getattr(settings, "search_text", "")
        category_filter = getattr(settings, "category_filter", "ALL")
        box = layout.box()
        if not _catalog_runtime.is_loaded():
            # File I/O is forbidden at the draw boundary. The section-toggle
            # update/load event performs the one-time lazy load instead.
            _label(box, "カタログは次の明示操作時に読み込まれます。", "The catalog loads on the next explicit action.", settings)
            return
        matches = search_features(search_text, category_filter, source_filter, limit=limit)
        total_matches = search_feature_count(search_text, category_filter, source_filter)
        if not matches:
            _label(box, "一致する機能はありません。", "No matching features.", settings)
            return
        for entry in matches:
            col = box.column(align=True)
            col.label(text=entry.source, icon="DOT", translate=False)
            row = col.row(align=True)
            if entry.preset_id:
                entry_icon, entry_icon_value = _preset_icon_spec(entry.preset_id)
                op = row.operator("smart_composite.add_preset", text=entry.feature, icon=entry_icon, icon_value=entry_icon_value, translate=False)
                op.preset_id = entry.preset_id
                _help_button(row, f"preset:{entry.preset_id}", settings)
            else:
                row.label(text=entry.feature, translate=False)
        if total_matches > len(matches):
            _label(box, f"ほか {total_matches - len(matches)} 件", f"{total_matches - len(matches)} more", settings)


class SCOMP_PT_pipeline(_SCS_CompositorPanelMixin, bpy.types.Panel):
    bl_idname = "SCOMP_PT_pipeline"
    bl_label = ""
    bl_parent_id = ""
    bl_order = 40

    def draw_header(self, context):
        _draw_panel_header(self.layout, context, "pipeline", "pipeline", "パイプライン", "Pipeline")

    def draw(self, context):
        settings = _settings(context)
        layout = self.layout
        col = layout.column(align=True)
        _operator(col, "smart_composite.add_preset", "納品整合チェックを追加", "Add Delivery Sanity Check", settings, "NONE", icon_key="delivery", preset_id="DELIVERY_SANITY_CHECK")
        _operator(col, "smart_composite.add_preset", "マルチパス出力を追加", "Add Multi-pass Output", settings, "NONE", icon_key="output", preset_id="FILE_OUTPUT_PIPELINE")
        _operator(col, "smart_composite.add_preset", "アセットシェルフ準備", "Prepare Asset Shelf", settings, "NONE", icon_key="catalog", preset_id="ASSET_SHELF_PREP")
        _operator(col, "smart_composite.add_preset", "精度QCツールセットを追加", "Add Precision QC Toolset", settings, "CHECKMARK", icon_key="qc", preset_id="PRECISION_QC_SUITE")
        _operator(col, "smart_composite.export_manifest", "独自ツールカタログを書き出し", "Export Original Tool Catalog", settings, "EXPORT", icon_key="catalog")
        _operator(col, "smart_composite.export_quality_report", "品質レポートを書き出し", "Export Quality Report", settings, "EXPORT", icon_key="audit")
        layout.separator()
        _operator(layout, "smart_composite.clear_scs_nodes", "SCSノードを整理", "Clean SCS Nodes", settings, "TRASH")


def _draw_apex_section_body(body, ctx):
    _draw_panel_body(SCOMP_PT_apex_command, body, ctx)


def _draw_launchpad_section_body(body, ctx):
    _draw_panel_body(SCOMP_PT_launchpad, body, ctx)


def _draw_precision_section_body(body, ctx):
    _draw_panel_body(SCOMP_PT_precision_dashboard, body, ctx)


def _draw_ui_polish_section_body(body, ctx):
    _draw_panel_body(SCOMP_PT_ui_polish, body, ctx)


def _draw_visual_references_section_body(body, ctx):
    _draw_panel_body(SCOMP_PT_visual_references, body, ctx)


def _draw_setup_section_body(body, ctx):
    _draw_panel_body(SCOMP_PT_setup, body, ctx)


def _draw_presets_section_body(body, ctx):
    _draw_panel_body(SCOMP_PT_presets, body, ctx)


def _draw_catalog_section_body(body, ctx):
    _draw_panel_body(SCOMP_PT_catalog, body, ctx)


def _draw_pipeline_section_body(body, ctx):
    _draw_panel_body(SCOMP_PT_pipeline, body, ctx)


def _draw_persistent_section_body(body, ctx):
    _draw_persistent_toggles_body(body, ctx)


SECTION_DEFINITIONS = (
    ("show_always_on_toggles", "clock", "persistent_toggles", "常時機能切り替え", "Always-on Toggles", _draw_persistent_section_body),
    ("show_section_presets", "favorites", "presets", "エフェクト／プリセット", "Effects / Presets", _draw_presets_section_body),
)




# Native N-panel host coverage for Smart Tools Manager.
#
# Blender registers sidebar categories per physical space, while Manager owns
# seventeen logical cells.  Exactly one full-body native root is registered in
# each of Blender's eleven physical sidebar spaces.  Shared roots classify the
# current logical subtype in poll() and query only that exact Manager cell.
def _draw_root_header(self, context):
    _help_button(self.layout, 'root', _settings(context))


def _draw_root_panel(self, context):
    # Blender requires Panel.draw to return None.  Deliberately discard any
    # internal helper status so a boolean can never cross the RNA boundary.
    if self.bl_space_type == "TEXT_EDITOR":
        title = self.layout.column(align=True)
        _sidebar_label(title, "Smart Composite", _narrow_sidebar(context))
        settings = _settings(context)
        help_label = t("ヘルプ", "Help", settings)
        title.operator(
            "smart_composite.show_tool_help", text=help_label, translate=False,
        ).alias = "root"
    _draw_unified_scs_ui(self.layout, context)
    return None


def _draw_legacy_root_panel(self, context):
    layout = self.layout
    settings = _settings(context)
    if properties.safe_degradation_active():
        _draw_registration_degraded(layout, context)
        return
    # An embedded popup uses Blender's menu layout. Make each disclosure a
    # full-width menu item so it receives the menu's text column.
    for state_attr, _icon_key, help_id, ja, en, draw_body in SECTION_DEFINITIONS:
        label = t(ja, en, settings)
        expanded = _section_state(settings, state_attr)
        _section_toggle_operator(
            layout, state_attr, label, text=label,
            icon=_DISCLOSURE_ICONS[bool(expanded)], expanded=expanded,
        )
        _help_button(layout, help_id, settings)
        if expanded:
            draw_body(layout.column(), context)


def _addon_owner_id() -> str:
    package = str(__package__ or "").strip()
    if package:
        return package
    module = str(__name__ or "").strip()
    if "." in module:
        return module.rsplit(".", 1)[0]
    return "smart_composite_suite"


def _enum_text(value) -> str:
    try:
        return str(value or "").strip().upper()
    except Exception:
        return ""


def clear_editor_context_cache() -> None:
    """Release bounded pure-value UI caches; no RNA references are retained."""
    manager_bridge.clear_cache()
    for cached in (_panel_header_icon, _preset_icon_spec, _section_icon_spec):
        try:
            cached.cache_clear()
        except Exception:
            pass


def _detect_scs_editor_key(area) -> str | None:
    return manager_bridge.detect_editor_key(area)


def _scs_area_matches_editor(area, editor_key: str) -> bool:
    return manager_bridge.physical_matches(area, _enum_text(editor_key))


def _root_panel_poll(cls, context):
    """Pure physical-root poll using one exact Manager current-cell decision."""
    if context is None:
        return False
    try:
        expected_physical = _enum_text(getattr(cls, "bl_space_type", ""))
        tool_key = _enum_text(getattr(cls, "_smart_tools_manager_tool_key", ""))
        allowed_logical = tuple(
            _enum_text(value)
            for value in getattr(cls, "_smart_tools_manager_logical_editor_keys", ())
            if _enum_text(value)
        )
        area = getattr(context, "area", None)
    except Exception:
        return False

    # Physical mismatch is invalid even when Manager is absent; fail closed
    # before reading a logical subtype or calling Manager.
    if (
        expected_physical not in manager_bridge.PHYSICAL_SPACE_TYPES
        or manager_bridge.physical_area_type(area) != expected_physical
    ):
        return False

    logical_editor = manager_bridge.detect_editor_key(area)
    if (
        logical_editor is None
        or logical_editor not in allowed_logical
        or manager_bridge.PHYSICAL_SPACE_BY_EDITOR.get(logical_editor) != expected_physical
        or tool_key != "SMART_COMPOSITE"
    ):
        return False

    try:
        return bool(manager_bridge.placement_allowed(context, logical_editor, tool_key))
    except Exception:
        # The bridge itself fails open only for an absent/disabled/NOT_READY
        # Manager.  An unexpected local defect is not an authoritative cell.
        return False


def _make_native_root_panel_class(
    class_name: str,
    bl_idname: str,
    space_type: str,
    logical_editor_keys: tuple[str, ...],
    *,
    region_type: str = "UI",
):
    is_text_editor = space_type == "TEXT_EDITOR"
    return type(
        class_name,
        (_SCS_CompositorPanelMixin, bpy.types.Panel),
        {
            "__module__": __name__,
            "bl_idname": bl_idname,
            "bl_label": "Controls" if is_text_editor else "Smart Composite",
            "bl_space_type": space_type,
            "bl_region_type": region_type,
            "bl_category": "Smart Composite",
            "bl_owner_id": _addon_owner_id(),
            "bl_order": 0,
            "bl_options": set(),
            "_smart_tools_manager_tool_key": "SMART_COMPOSITE",
            "_smart_tools_manager_native_npanel_root": True,
            "_smart_tools_manager_disable_proxy": True,
            "_smart_tools_manager_no_cross_editor_proxy": True,
            "_smart_tools_manager_no_active_object_required": True,
            "_smart_tools_manager_logical_editor_keys": tuple(logical_editor_keys),
            "_smart_composite_native_sidebar_host": True,
            "poll": classmethod(_root_panel_poll),
            "draw": _draw_root_panel,
            "draw_header_preset": _draw_root_header,
        },
    )


def _make_legacy_logical_panel_class(
    class_name: str,
    bl_idname: str,
    space_type: str,
    editor_key: str,
    parent_id: str,
):
    """Keep the older Python/Blender ID surface without registering a root.

    These compatibility identities register only as hidden deterministic
    children of the one physical root.  They preserve the older public Panel
    IDs without creating another top-level category root or Manager proxy.
    """
    return type(
        class_name,
        (_SCS_CompositorPanelMixin, bpy.types.Panel),
        {
            "__module__": __name__,
            "bl_idname": bl_idname,
            "bl_label": "Smart Composite",
            "bl_space_type": space_type,
            "bl_region_type": "UI",
            "bl_category": "Smart Composite",
            "bl_owner_id": _addon_owner_id(),
            "bl_order": 0,
            "bl_parent_id": parent_id,
            "bl_options": {"DEFAULT_CLOSED"},
            "_smart_tools_manager_tool_key": "SMART_COMPOSITE",
            "_smart_tools_manager_editor_key": editor_key,
            "_smart_tools_manager_native_npanel_root": False,
            "_smart_tools_manager_ignore": True,
            "_smart_composite_legacy_logical_panel": True,
            "poll": classmethod(lambda cls, context: False),
            "draw": _draw_legacy_root_panel,
            "draw_header_preset": _draw_root_header,
        },
    )


# Eleven authoritative physical roots.
SCOMP_PT_root_view_3d = _make_native_root_panel_class(
    "SCOMP_PT_root_view_3d", "VIEW3D_PT_smart_composite_view_3d",
    "VIEW_3D", ("VIEW_3D",),
)
SCOMP_PT_root_image_editor = _make_native_root_panel_class(
    "SCOMP_PT_root_image_editor", "IMAGE_PT_smart_composite_image",
    "IMAGE_EDITOR", ("IMAGE_EDITOR", "UV_EDITOR"),
)
SCOMP_PT_root_compositor = _make_native_root_panel_class(
    "SCOMP_PT_root_compositor", "NODE_PT_smart_composite_compositor",
    "NODE_EDITOR", ("SHADER_EDITOR", "COMPOSITOR", "GEOMETRY_NODE_EDITOR", "TEXTURE_NODE_EDITOR"),
)
SCOMP_PT_root_sequence_editor = _make_native_root_panel_class(
    "SCOMP_PT_root_sequence_editor", "SEQUENCER_PT_smart_composite_video",
    "SEQUENCE_EDITOR", ("VIDEO_SEQUENCER",),
)
SCOMP_PT_root_clip_editor = _make_native_root_panel_class(
    "SCOMP_PT_root_clip_editor", "CLIP_PT_smart_composite_movie_clip",
    "CLIP_EDITOR", ("MOVIE_CLIP_EDITOR",),
)
SCOMP_PT_root_dopesheet_editor = _make_native_root_panel_class(
    "SCOMP_PT_root_dopesheet_editor", "DOPESHEET_PT_smart_composite_dope_sheet",
    "DOPESHEET_EDITOR", ("DOPE_SHEET",),
)
SCOMP_PT_root_graph_editor = _make_native_root_panel_class(
    "SCOMP_PT_root_graph_editor", "GRAPH_PT_smart_composite_graph",
    "GRAPH_EDITOR", ("GRAPH_EDITOR", "DRIVERS"),
)
SCOMP_PT_root_nla_editor = _make_native_root_panel_class(
    "SCOMP_PT_root_nla_editor", "NLA_PT_smart_composite_nla",
    "NLA_EDITOR", ("NLA_EDITOR",),
)
SCOMP_PT_root_text_editor = _make_native_root_panel_class(
    "SCOMP_PT_root_text_editor", "TEXT_PT_smart_composite_text",
    "TEXT_EDITOR", ("TEXT_EDITOR",),
)
SCOMP_PT_root_file_browser = _make_native_root_panel_class(
    "SCOMP_PT_root_file_browser", "FILEBROWSER_PT_smart_composite_file",
    "FILE_BROWSER", ("FILE_BROWSER",),
)
SCOMP_PT_root_spreadsheet = _make_native_root_panel_class(
    "SCOMP_PT_root_spreadsheet", "SPREADSHEET_PT_smart_composite_sheet",
    "SPREADSHEET", ("SPREADSHEET",),
)


# Six former logical roots register only as hidden compatibility children.
SCOMP_PT_root_uv_editor = _make_legacy_logical_panel_class(
    "SCOMP_PT_root_uv_editor", "IMAGE_PT_smart_composite_uv", "IMAGE_EDITOR", "UV_EDITOR",
    SCOMP_PT_root_image_editor.bl_idname,
)
SCOMP_PT_root_shader_editor = _make_legacy_logical_panel_class(
    "SCOMP_PT_root_shader_editor", "NODE_PT_smart_composite_shader", "NODE_EDITOR", "SHADER_EDITOR",
    SCOMP_PT_root_compositor.bl_idname,
)
SCOMP_PT_root_geometry_node_editor = _make_legacy_logical_panel_class(
    "SCOMP_PT_root_geometry_node_editor", "NODE_PT_smart_composite_geometry", "NODE_EDITOR", "GEOMETRY_NODE_EDITOR",
    SCOMP_PT_root_compositor.bl_idname,
)
SCOMP_PT_root_texture_node_editor = _make_legacy_logical_panel_class(
    "SCOMP_PT_root_texture_node_editor", "NODE_PT_smart_composite_texture", "NODE_EDITOR", "TEXTURE_NODE_EDITOR",
    SCOMP_PT_root_compositor.bl_idname,
)
SCOMP_PT_root_drivers = _make_legacy_logical_panel_class(
    "SCOMP_PT_root_drivers", "GRAPH_PT_smart_composite_drivers", "GRAPH_EDITOR", "DRIVERS",
    SCOMP_PT_root_graph_editor.bl_idname,
)
SCOMP_PT_root_asset_browser = _make_native_root_panel_class(
    "SCOMP_PT_root_asset_browser", "FILEBROWSER_PT_smart_composite_asset",
    "FILE_BROWSER", ("ASSET_BROWSER",), region_type="TOOL_PROPS",
)


OBSOLETE_UI_CLASSES = (
    SCOMP_PT_root,
    SCOMP_PT_apex_command,
    SCOMP_PT_launchpad,
    SCOMP_PT_precision_dashboard,
    SCOMP_PT_ui_polish,
    SCOMP_PT_visual_references,
    SCOMP_PT_setup,
    SCOMP_PT_presets,
    SCOMP_PT_catalog,
    SCOMP_PT_pipeline,
)


UI_CLASSES = (
    SCOMP_PT_root_view_3d,
    SCOMP_PT_root_image_editor,
    SCOMP_PT_root_compositor,
    SCOMP_PT_root_sequence_editor,
    SCOMP_PT_root_clip_editor,
    SCOMP_PT_root_dopesheet_editor,
    SCOMP_PT_root_graph_editor,
    SCOMP_PT_root_nla_editor,
    SCOMP_PT_root_text_editor,
    SCOMP_PT_root_file_browser,
    SCOMP_PT_root_asset_browser,
    SCOMP_PT_root_spreadsheet,
    # Registered compatibility children preserve all older public Panel IDs.
    SCOMP_PT_root_uv_editor,
    SCOMP_PT_root_shader_editor,
    SCOMP_PT_root_geometry_node_editor,
    SCOMP_PT_root_texture_node_editor,
    SCOMP_PT_root_drivers,
)
