# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from __future__ import annotations

from pathlib import Path
from functools import lru_cache

_PREVIEWS = globals().get("_PREVIEWS")
_CUSTOM_ICONS_ENABLED = bool(globals().get("_CUSTOM_ICONS_ENABLED", False))

ICON_KEYS = ('aov', 'apex', 'audit', 'catalog', 'clock', 'delivery', 'favorites', 'help', 'hero', 'output', 'pipeline', 'qc', 'reference', 'scs_logo', 'setup')

REFERENCE_KEYS = ('reference_master_flow', 'reference_precision_qc', 'reference_light_optics', 'reference_matte_edges', 'reference_color_finish', 'reference_cleanroom', 'reference_apex_command', 'reference_aov_integrity', 'reference_physical_optics', 'reference_adaptive_restore', 'reference_motion_flow', 'reference_geometry_bridge', 'reference_delivery_check', 'reference_ui_map')

PRESET_ICONS = {'AOV_SHUFFLE_MATRIX': 'aov_shuffle', 'CRYPTOMATTE_EXTRACTOR': 'crypto_matte', 'FILE_OUTPUT_PIPELINE': 'output', 'SMART_MERGE': 'smart_merge', 'MATTE_REFINER': 'matte_refine', 'SLAP_COMP': 'slap_comp', 'CHROMA_KEY_STUDIO': 'chroma_key', 'AI_MASK_BRIDGE': 'ai_mask', 'BEAUTY_RETOUCH': 'beauty', 'BOKEH_DEPTH_BLUR': 'bokeh_depth', 'VECTOR_MOTION_BLUR': 'motion_blur', 'OPTICAL_DISTORT': 'optical_distort', 'TIME_ECHO': 'clock', 'ADVANCED_GLOW': 'advanced_glow', 'EDGE_RAYS': 'edge_rays', 'LENS_FLARE_BUILDER': 'lens_flare', 'COLOR_GRADE_PANEL': 'color_grade', 'FILM_LOOK_BUILDER': 'film_look', 'COLOR_MATCH_LOOK': 'color_match', 'LUT_MANAGER': 'lut', 'VIGNETTE_FINISH': 'vignette', 'DEBAND_DENOISE_RESTORE': 'deband_restore', 'SHARPEN_DETAIL': 'sharpen', 'HEAT_HAZE_DISTORT': 'heat_haze', 'GLITCH_STYLIZE': 'glitch', 'DEPTH_FOG_RELIGHT': 'depth_fog', 'NORMAL_RELIGHT': 'normal_relight', 'HEIGHT_TO_NORMAL_PROXY': 'normal_relight', 'PARTICLE_LIGHTS': 'particle_lights', 'ASSET_SHELF_PREP': 'catalog', 'BUILD_MASTER_WORKSPACE': 'master_workspace', 'PRECISION_MASTER_WORKSPACE': 'precision', 'SURPASS_MASTER_WORKSPACE': 'surpass_workspace', 'PRECISION_OVERDRIVE_WORKSPACE': 'overdrive', 'PRECISION_QC_SUITE': 'precision', 'PRECISION_QC_LAB': 'precision', 'SIGNAL_INTEGRITY_GUARD': 'signal_guard', 'PRECISION_DIAGNOSTICS_HUB': 'precision_diag', 'MATTE_EDGE_LAB': 'matte_edge', 'SUBPIXEL_MATTE_LAB': 'subpixel_matte', 'SPECTRAL_LIGHT_LAB': 'spectral_light', 'OPTICAL_BLOOM_LAB': 'optical_bloom', 'HDR_HIGHLIGHT_GUARD': 'hdr', 'DEPTH_NORMALIZER': 'depth', 'DEPTH_VECTOR_AUDIT': 'depth_audit', 'COLOR_WARPER_LAB': 'color_warp', 'CLEANROOM_PLUS': 'cleanroom', 'RESTORATION_LAB': 'restoration_lab', 'SCS_ULTRA_LAUNCHPAD': 'ultra_launchpad', 'PERCEPTUAL_FINISHING_HUB': 'perceptual_finish', 'AOV_INTEGRITY_MATRIX': 'aov_check', 'ADAPTIVE_RESTORE_ENGINE': 'restore', 'PHYSICAL_OPTICS_ENGINE': 'optics', 'MATTE_MICROSURGERY_ENGINE': 'matte_micro', 'APEX_COMMAND_WORKSPACE': 'apex', 'AOV_DELTA_VERIFIER': 'aov_delta', 'DEEP_MATTE_FUSION_LAB': 'deep_matte', 'LENS_APERTURE_DESIGNER': 'lens', 'DYNAMIC_RANGE_SCULPTOR': 'hdr', 'PERCEPTION_MATCH_ASSISTANT': 'perception', 'ADAPTIVE_DENOISE_PROFILE_LAB': 'denoise_profile', 'MOTION_FLOW_GUARD': 'motion_guard', 'GEOMETRY_SIGNAL_BRIDGE': 'geometry_bridge', 'DELIVERY_SANITY_CHECK': 'delivery', 'APEX_VISUAL_GUIDE_BOARD': 'apex_guide', 'UI_ICON_LAUNCHPAD': 'icon_grid', 'VISUAL_REFERENCE_BOARD': 'reference_board'}

ICON_SPECS = {'aov': ('custom', 'aov_layers'), 'apex': ('custom', 'apex_command'), 'audit': ('builtin', 'VIEWZOOM'), 'catalog': ('builtin', 'FILE_FOLDER'), 'clock': ('builtin', 'TIME'), 'delivery': ('custom', 'delivery_check'), 'favorites': ('custom', 'favorite_star'), 'help': ('builtin', 'QUESTION'), 'hero': ('custom', 'ui_visibility'), 'output': ('builtin', 'EXPORT'), 'pipeline': ('builtin', 'NODETREE'), 'qc': ('builtin', 'CHECKMARK'), 'reference': ('builtin', 'IMAGE_DATA'), 'scs_logo': ('custom', 'scs_logo'), 'setup': ('builtin', 'NODETREE'), 'aov_shuffle': ('custom', 'aov_shuffle'), 'aov_check': ('custom', 'aov_check'), 'aov_delta': ('custom', 'aov_delta'), 'crypto_matte': ('custom', 'crypto_matte'), 'matte_refine': ('custom', 'matte_refine'), 'matte_edge': ('custom', 'matte_edge'), 'subpixel_matte': ('custom', 'subpixel_matte'), 'deep_matte': ('custom', 'deep_matte'), 'matte_micro': ('custom', 'matte_micro'), 'ai_mask': ('custom', 'ai_mask'), 'chroma_key': ('custom', 'chroma_key'), 'beauty': ('custom', 'beauty'), 'bokeh_depth': ('custom', 'bokeh_depth'), 'motion_blur': ('custom', 'motion_blur'), 'motion_guard': ('custom', 'motion_guard'), 'optical_distort': ('custom', 'optical_distort'), 'optics': ('custom', 'optics'), 'advanced_glow': ('custom', 'advanced_glow'), 'edge_rays': ('custom', 'edge_rays'), 'lens_flare': ('custom', 'lens_flare'), 'spectral_light': ('custom', 'spectral_light'), 'optical_bloom': ('custom', 'optical_bloom'), 'color_grade': ('custom', 'color_grade'), 'film_look': ('custom', 'film_look'), 'color_match': ('custom', 'color_match'), 'lut': ('custom', 'lut'), 'vignette': ('custom', 'vignette'), 'color_warp': ('custom', 'color_warp'), 'perception': ('custom', 'perception'), 'perceptual_finish': ('custom', 'perceptual_finish'), 'restore': ('custom', 'restore'), 'denoise_profile': ('custom', 'denoise_profile'), 'deband_restore': ('custom', 'deband_restore'), 'sharpen': ('custom', 'sharpen'), 'cleanroom': ('custom', 'cleanroom'), 'restoration_lab': ('custom', 'restoration_lab'), 'heat_haze': ('custom', 'heat_haze'), 'glitch': ('custom', 'glitch'), 'depth': ('custom', 'depth'), 'depth_fog': ('custom', 'depth_fog'), 'depth_audit': ('custom', 'depth_audit'), 'normal_relight': ('custom', 'normal_relight'), 'particle_lights': ('custom', 'particle_lights'), 'smart_merge': ('custom', 'smart_merge'), 'slap_comp': ('custom', 'slap_comp'), 'master_workspace': ('custom', 'master_workspace'), 'precision': ('custom', 'precision'), 'overdrive': ('custom', 'overdrive'), 'signal_guard': ('custom', 'signal_guard'), 'precision_diag': ('custom', 'precision_diag'), 'ultra_launchpad': ('custom', 'ultra_launchpad'), 'surpass_workspace': ('custom', 'surpass_workspace'), 'apex_guide': ('custom', 'apex_guide'), 'geometry_bridge': ('custom', 'geometry_bridge'), 'icon_grid': ('custom', 'icon_grid'), 'reference_board': ('custom', 'reference_board'), 'hdr': ('custom', 'hdr'), 'lens': ('builtin', 'CAMERA_DATA')}

# Static whitelist avoids querying RNA enum tables during panel drawing/register.
_BUILTIN_ICONS = {
    'NONE', 'DOT', 'BLANK1', 'INFO', 'QUESTION', 'ERROR', 'PLAY', 'PREFERENCES',
    'CHECKMARK', 'CHECKBOX_HLT', 'CHECKBOX_DEHLT', 'TRIA_DOWN', 'TRIA_RIGHT',
    'TIME', 'VIEWZOOM', 'FILE_FOLDER', 'IMAGE_DATA', 'EXPORT', 'TRASH', 'ADD',
    'NODETREE', 'NODE_COMPOSITING', 'CAMERA_DATA', 'TOOL_SETTINGS', 'RENDER_RESULT',
    'WORLD_DATA', 'SCENE_DATA', 'OUTLINER_OB_MESH', 'MODIFIER', 'SHADING_RENDERED',
    'IMAGE_DATA', 'IMAGE_DATA', 'ORIENTATION_GLOBAL', 'EMPTY_ARROWS',
    'CON_TRACKTO', 'FILE_TICK', 'VIEWZOOM', 'COLOR', 'LIGHT', 'VIEWZOOM', 'PLUGIN',
    'FILE_FOLDER', 'PACKAGE', 'LINKED', 'DECORATE_OVERRIDE', 'HIDE_OFF', 'HIDE_ON',
}

# Built-in fallback per semantic custom key.  Blender 5.1.0 panel crashes were in the
# C-level panel handler, so live UI uses built-in icons by default while keeping the
# 32px PNG assets packaged for future/non-5.1 preview-capable contexts.
ICON_BUILTIN_FALLBACKS = {
    'aov': 'IMAGE_DATA', 'aov_layers': 'IMAGE_DATA', 'aov_shuffle': 'IMAGE_DATA',
    'aov_check': 'CHECKMARK', 'aov_delta': 'VIEWZOOM', 'apex': 'NODETREE',
    'apex_command': 'NODETREE', 'apex_guide': 'IMAGE_DATA', 'audit': 'VIEWZOOM',
    'catalog': 'FILE_FOLDER', 'clock': 'TIME', 'delivery': 'EXPORT',
    'delivery_check': 'EXPORT', 'favorites': 'ADD', 'favorite_star': 'ADD',
    'help': 'QUESTION', 'hero': 'PREFERENCES', 'ui_visibility': 'PREFERENCES',
    'output': 'EXPORT', 'pipeline': 'NODETREE', 'qc': 'CHECKMARK',
    'reference': 'IMAGE_DATA', 'reference_board': 'IMAGE_DATA', 'scs_logo': 'NODETREE',
    'setup': 'NODETREE', 'crypto_matte': 'VIEWZOOM', 'matte_refine': 'VIEWZOOM',
    'matte_edge': 'VIEWZOOM', 'subpixel_matte': 'VIEWZOOM', 'deep_matte': 'VIEWZOOM',
    'matte_micro': 'VIEWZOOM', 'ai_mask': 'VIEWZOOM', 'chroma_key': 'IMAGE_DATA',
    'beauty': 'SHADING_RENDERED', 'bokeh_depth': 'CAMERA_DATA', 'motion_blur': 'TIME',
    'motion_guard': 'TIME', 'optical_distort': 'CAMERA_DATA', 'optics': 'CAMERA_DATA',
    'advanced_glow': 'LIGHT', 'edge_rays': 'LIGHT', 'lens_flare': 'LIGHT',
    'spectral_light': 'LIGHT', 'optical_bloom': 'LIGHT', 'color_grade': 'COLOR',
    'film_look': 'COLOR', 'color_match': 'COLOR', 'lut': 'COLOR', 'vignette': 'CAMERA_DATA',
    'color_warp': 'COLOR', 'perception': 'HIDE_OFF', 'perceptual_finish': 'COLOR',
    'restore': 'FILE_TICK', 'denoise_profile': 'FILE_TICK', 'deband_restore': 'FILE_TICK',
    'sharpen': 'VIEWZOOM', 'cleanroom': 'FILE_TICK', 'restoration_lab': 'FILE_TICK',
    'heat_haze': 'IMAGE_DATA', 'glitch': 'MODIFIER', 'depth': 'ORIENTATION_GLOBAL',
    'depth_fog': 'WORLD_DATA', 'depth_audit': 'VIEWZOOM', 'normal_relight': 'LIGHT',
    'particle_lights': 'LIGHT', 'smart_merge': 'NODETREE', 'slap_comp': 'NODE_COMPOSITING',
    'master_workspace': 'NODETREE', 'precision': 'CHECKMARK', 'overdrive': 'CHECKMARK',
    'signal_guard': 'CHECKMARK', 'precision_diag': 'VIEWZOOM', 'ultra_launchpad': 'NODETREE',
    'surpass_workspace': 'NODETREE', 'geometry_bridge': 'OUTLINER_OB_MESH', 'icon_grid': 'FILE_FOLDER',
    'hdr': 'IMAGE_DATA', 'lens': 'CAMERA_DATA',
}

REFERENCE_LABELS = {'reference_master_flow': ('総合フロー', 'Master Flow'), 'reference_precision_qc': ('精度QC', 'Precision QC'), 'reference_light_optics': ('光学構造', 'Light Optics'), 'reference_matte_edges': ('マット縁', 'Matte Edges'), 'reference_color_finish': ('カラー仕上げ', 'Color Finish'), 'reference_cleanroom': ('復元工程', 'CleanRoom'), 'reference_apex_command': ('Apex操作導線', 'Apex Command'), 'reference_aov_integrity': ('AOV整合', 'AOV Integrity'), 'reference_physical_optics': ('物理光学', 'Physical Optics'), 'reference_adaptive_restore': ('適応復元', 'Adaptive Restore'), 'reference_motion_flow': ('モーションフロー', 'Motion Flow'), 'reference_geometry_bridge': ('ジオメトリ連携', 'Geometry Bridge'), 'reference_delivery_check': ('納品チェック', 'Delivery Check'), 'reference_ui_map': ('UI配置図', 'UI Map')}


def _package_dir() -> Path:
    return Path(__file__).resolve().parent


@lru_cache(maxsize=1)
def _blender_version() -> tuple[int, int, int]:
    try:
        import bpy  # type: ignore
        value = getattr(getattr(bpy, 'app', None), 'version', ()) or ()
        result = tuple(int(part) for part in value[:3])
        while len(result) < 3:
            result += (0,)
        return result  # type: ignore[return-value]
    except Exception:
        return (0, 0, 0)


def custom_previews_allowed() -> bool:
    # The supplied Blender 5.1.0 crash log terminates in blender::ui::ui_handler_panel
    # after mode/selection transitions.  Avoiding live custom preview handles in that
    # UI path is the most conservative mitigation.
    version = _blender_version()
    if version >= (5, 1, 0):
        return False
    return True


@lru_cache(maxsize=256)
def safe_builtin_icon(name: str, fallback: str = 'NONE') -> str:
    candidate = str(name or 'NONE').strip() or 'NONE'
    fallback_name = str(fallback or 'NONE').strip() or 'NONE'
    if candidate in _BUILTIN_ICONS:
        return candidate
    if fallback_name in _BUILTIN_ICONS:
        return fallback_name
    return 'NONE'


@lru_cache(maxsize=512)
def _builtin_fallback_for_key(key: str, fallback: str = 'NONE') -> str:
    name = str(key or '').strip()
    if name in REFERENCE_KEYS:
        return safe_builtin_icon('IMAGE_DATA', fallback)
    spec = ICON_SPECS.get(name)
    if spec is not None:
        kind, value = spec
        if kind == 'builtin':
            return safe_builtin_icon(str(value), fallback)
        return safe_builtin_icon(ICON_BUILTIN_FALLBACKS.get(name) or ICON_BUILTIN_FALLBACKS.get(str(value)) or fallback, fallback)
    if name.isupper():
        return safe_builtin_icon(name, fallback)
    return safe_builtin_icon(ICON_BUILTIN_FALLBACKS.get(name, fallback), fallback)


def set_custom_icons_enabled(enabled: bool) -> None:
    global _CUSTOM_ICONS_ENABLED
    new_value = bool(enabled) and custom_previews_allowed()
    changed = new_value != _CUSTOM_ICONS_ENABLED
    _CUSTOM_ICONS_ENABLED = new_value
    if changed:
        clear_runtime_caches()
        try:
            from . import ui
            ui.clear_editor_context_cache()
        except Exception:
            pass
    if _CUSTOM_ICONS_ENABLED:
        register()
    else:
        # Release the one exact preview collection immediately when the feature
        # is disabled. Long sessions cannot accumulate dormant collections.
        _release_preview_collection()


def custom_icons_enabled() -> bool:
    return bool(_CUSTOM_ICONS_ENABLED and custom_previews_allowed())


def _custom_preview_key(key: str) -> str:
    name = str(key or '').strip()
    if not name:
        return ''
    if name in REFERENCE_KEYS:
        return name
    spec = ICON_SPECS.get(name)
    if spec and spec[0] == 'custom':
        return str(spec[1])
    # Unknown keys never probe the filesystem from panel drawing. All packaged
    # custom names are enumerated by ICON_SPECS and PRESET_ICONS above.
    return ''


def _all_custom_icons() -> tuple[str, ...]:
    names = {str(value) for kind, value in ICON_SPECS.values() if kind == 'custom'}
    return tuple(sorted(names))


def _load_many(previews, names: tuple[str, ...], folder: str) -> None:
    base = _package_dir() / folder
    loaded: set[str] = set()
    for name in names:
        if not name or name in loaded:
            continue
        loaded.add(name)
        path = base / f'{name}.png'
        if not path.exists():
            continue
        try:
            previews.load(name, str(path), 'IMAGE')
        except Exception:
            pass


def register() -> None:
    global _PREVIEWS
    if _PREVIEWS is not None or not custom_previews_allowed():
        return
    try:
        import bpy.utils.previews as preview_api  # type: ignore
        pcoll = preview_api.new()
    except Exception:
        _PREVIEWS = None
        return
    _load_many(pcoll, _all_custom_icons(), 'icons')
    # Reference PNGs are opened as files instead of being cached as UI preview
    # icons.  This avoids extra icon_value handles in Blender 5.1 panel redraws.
    _PREVIEWS = pcoll


def clear_runtime_caches() -> None:
    """Clear every bounded pure-value cache; no Blender/RNA references retained."""
    for cached in (_blender_version, safe_builtin_icon, _builtin_fallback_for_key, _icon_spec_cached, preset_icon_spec):
        try:
            cached.cache_clear()
        except Exception:
            pass


def _release_preview_collection() -> None:
    global _PREVIEWS
    collection = _PREVIEWS
    if collection is None:
        return
    try:
        import bpy.utils.previews as preview_api  # type: ignore
        preview_api.remove(collection)
    except Exception:
        # Retain no Python reference even when Blender has already invalidated the
        # exact collection during shutdown/reload. No replacement is searched.
        pass
    _PREVIEWS = None


def unregister() -> None:
    global _CUSTOM_ICONS_ENABLED
    _CUSTOM_ICONS_ENABLED = False
    clear_runtime_caches()
    _release_preview_collection()


def icon_id(key: str, fallback: str = '') -> int:
    if not custom_icons_enabled() or _PREVIEWS is None:
        return 0
    for name in (str(key or ''), str(fallback or '')):
        preview_key = _custom_preview_key(name)
        if not preview_key:
            continue
        try:
            item = _PREVIEWS.get(preview_key)
            if item is not None:
                return int(item.icon_id)
        except Exception:
            pass
    return 0


@lru_cache(maxsize=1024)
def _icon_spec_cached(key: str, fallback: str, custom_enabled: bool) -> tuple[str, int]:
    for name in (str(key or '').strip(), str(fallback or '').strip()):
        if not name:
            continue
        if custom_enabled:
            if name in REFERENCE_KEYS:
                icon_value = icon_id(name)
                if icon_value:
                    return ('NONE', icon_value)
                return (_builtin_fallback_for_key(name, fallback), 0)
            spec = ICON_SPECS.get(name)
            if spec is not None:
                kind, value = spec
                if kind == 'builtin':
                    return (safe_builtin_icon(str(value), fallback), 0)
                icon_value = icon_id(str(value))
                if icon_value:
                    return ('NONE', icon_value)
                return (_builtin_fallback_for_key(name, fallback), 0)
        return (_builtin_fallback_for_key(name, fallback), 0)
    return (safe_builtin_icon(fallback, 'NONE'), 0)


def icon_spec(key: str, fallback: str = 'NONE') -> tuple[str, int]:
    return _icon_spec_cached(str(key or '').strip(), str(fallback or 'NONE').strip() or 'NONE', custom_icons_enabled())


def preset_icon_id(preset_id: str) -> int:
    key = PRESET_ICONS.get(str(preset_id or '').upper(), 'scs_logo')
    return icon_id(key)


@lru_cache(maxsize=256)
def preset_icon_spec(preset_id: str) -> tuple[str, int]:
    key = PRESET_ICONS.get(str(preset_id or '').upper(), 'scs_logo')
    return icon_spec(key, 'ADD')


def reference_path(reference_id: str) -> Path:
    name = str(reference_id or 'reference_master_flow').strip()
    if name not in REFERENCE_KEYS:
        name = 'reference_master_flow'
    return _package_dir() / 'references' / f'{name}.png'
