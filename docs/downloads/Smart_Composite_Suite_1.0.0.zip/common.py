# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Legacy compatibility shim for older Smart Composite Suite builds.

Older packages imported :mod:`common` to add preference-panel patches,
standalone VIEW_3D panels, and broad autosave hooks.  The current extension
keeps all user-facing controls in the Node Editor N-panel and stores runtime
files through :mod:`storage`, so this module is intentionally side-effect free.
"""

from __future__ import annotations

import os
from pathlib import Path

PACKAGE_ID = "smart_composite_suite"
ADDON_NAME = "Smart_Composite_Suite"


def package_root() -> Path:
    return Path(__file__).resolve().parent


def storage_root(create: bool = True) -> Path:
    try:
        from . import storage

        return storage.user_data_dir(create=create)
    except Exception:
        version = "5.1"
        if os.name == "nt":
            base = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming")
            root = base / "Blender Foundation" / "Blender" / version / "config" / ADDON_NAME / "sidecars" / "user_data"
        else:
            root = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "blender" / version / "config" / ADDON_NAME / "sidecars" / "user_data"
        if create:
            root.mkdir(parents=True, exist_ok=True)
        return root


def storage_path(*parts: str, create_parent: bool = True) -> Path:
    path = storage_root(create=True).joinpath(*parts)
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def settings_path() -> Path:
    try:
        from . import storage

        return storage.n_panel_settings_file(create=True)
    except Exception:
        version = "5.1"
        if os.name == "nt":
            base = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming")
            root = base / "Blender Foundation" / "Blender" / version / "config"
        else:
            root = Path.home() / ".config" / "blender" / version / "config"
        target_dir = root / "Smart_Composite_Suite"
        target_dir.mkdir(parents=True, exist_ok=True)
        return target_dir / "Smart_Composite_Suite.json"


def begin_register() -> None:
    return None


def end_register() -> None:
    return None


def register() -> None:
    return None


def unregister() -> None:
    return None
