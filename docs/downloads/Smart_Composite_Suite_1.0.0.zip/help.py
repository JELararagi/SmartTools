# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Lazy help system for Smart Composite.

The popup Operator is registered with the suite so every public Operator identity
is stable. Topic resolution and popup drawing remain demand-driven; ordinary
N-panel polling performs no help-side work.
"""

import textwrap
import unicodedata

import bpy
from bpy.props import StringProperty

from .translation import t, locale_mode

_POPUP_WIDTH = 860
_WRAP = 92
_WRAP_JA_CELLS = 116
_NO_LINE_START = '、。）」』，．・ー々'
_REGISTERED = bool(globals().get("_REGISTERED", False))
_REGISTERED_CLASS = globals().get("_REGISTERED_CLASS")
_REGISTER_TOKEN = str(globals().get("_REGISTER_TOKEN", "") or "")
_REGISTER_GENERATION = int(globals().get("_REGISTER_GENERATION", 0) or 0)
_CLASS_OWNER_ATTR = "_scs_help_owner"
_CLASS_PACKAGE_ATTR = "_scs_help_package"
_CLASS_TOKEN_ATTR = "_scs_help_token"
_CLASS_GENERATION_ATTR = "_scs_help_generation"


def _settings(context=None):
    try:
        from .properties import get_settings
        return get_settings(context)
    except Exception:
        return None


def _pair(data, settings=None):
    if isinstance(data, dict):
        return t(data.get('ja', ''), data.get('en', ''), settings)
    if isinstance(data, (tuple, list)) and len(data) >= 2:
        return t(str(data[0]), str(data[1]), settings)
    return str(data or '')


def _cell_width(char) -> int:
    return 2 if unicodedata.east_asian_width(char) in {'W', 'F', 'A'} else 1


def _wrap_cjk(text, cells):
    """Japanese has no spaces, so break by display width, preferring a break after punctuation."""
    lines = []
    line = ''
    used = 0
    last_break = -1
    for char in text:
        width = _cell_width(char)
        if used + width > cells:
            if char in _NO_LINE_START and line:
                line += char
                lines.append(line)
                line, used, last_break = '', 0, -1
                continue
            if last_break >= len(line) // 2:
                rest = line[last_break + 1:]
                lines.append(line[:last_break + 1])
                line = rest
                used = sum(_cell_width(c) for c in line)
            else:
                lines.append(line)
                line, used = '', 0
            last_break = -1
        line += char
        used += width
        if char in '、。）」／':
            last_break = len(line) - 1
    if line:
        lines.append(line)
    return lines


def _wrap_label(layout, text, *, icon='NONE', settings=None, width=_WRAP):
    raw = str(text or '').strip()
    if not raw:
        return
    locale = None
    for para in raw.split('\n'):
        para = para.strip()
        if not para:
            layout.separator()
            continue
        if locale is None:
            locale = locale_mode(settings)
        if locale == 'ja':
            lines = _wrap_cjk(para, _WRAP_JA_CELLS)
        else:
            lines = textwrap.wrap(para, width=width, break_long_words=False, break_on_hyphens=False) or [para]
        for line in lines:
            layout.label(text=line, icon=icon)
            icon = 'BLANK1'


def _draw_bullets(layout, lines, settings=None):
    for line in lines or ():
        _wrap_label(layout, _pair(line, settings), icon='DOT', settings=settings)


def _draw_section(layout, title_ja, title_en, lines, settings=None, icon='NONE'):
    box = layout.box()
    header = box.row(align=True)
    header.label(text=t(title_ja, title_en, settings), icon=icon)
    _draw_bullets(box, lines, settings)


SETTING_HELP = {
    'n_panel_state_save': {
        'label': ('Nパネル状態保存', 'N-panel State Save'),
        'text': ('有効時はNパネルの全設定変更をBlender 5.1 config内のSmart_Composite_Suite/Smart_Composite_Suite.jsonへ即時保存します。無効化操作を最後に1回保存した後は、再度有効にするまで手動・強制・終了時を含む全書込みを停止します。',
                 'When enabled, every N-panel setting change is immediately saved to Smart_Composite_Suite/Smart_Composite_Suite.json in Blender 5.1 config. Disabling commits OFF once, then blocks manual, forced, and shutdown writes until re-enabled.'),
    },
    'show_always_on_toggles': {
        'label': ('常時機能切り替えグループ', 'Always-on Toggles Group'),
        'text': ('Nパネル最上部の時計アイコン付き常時機能切り替えグループを開閉します。閉じても各機能の有効状態は保持され、無効な常時機能は所有リソースを登録しません。',
                 'Opens or closes the clock-marked Always-on Toggles group at the top of the N-panel. Closing it does not change feature states, and disabled resident helpers register no owned resources.'),
    },
    'persistent_ui_asset_cache': {
        'label': ('UIアイコンキャッシュ', 'UI Icon Cache'),
        'text': ('互換性のあるBlenderバージョンで独自PNGプレビューを使用する切り替えです。Blender 5.1では安定性を優先して常に標準アイコンを使用します。',
                 'Controls custom PNG preview use on compatible Blender versions. Blender 5.1 always uses built-in icons for stability. Opening visual references separately remains available while this is disabled.'),
    },
    'persistent_auto_enable_compositor': {
        'label': ('コンポジター自動維持', 'Compositor Keep-Alive'),
        'text': ('Blender起動時、.blend読込後、この項目を有効にした時、またはSCS操作前に、シーンのコンポジター使用状態とレンダー合成を一回確認して有効に保ちます。元に戻す／やり直しではシーン設定を再適用せず、周期監視も行いません。共同作業やテンプレートで無効化されやすい場合だけ使います。',
                 'Checks once at Blender startup, after .blend load, when this item is enabled, or before SCS operations to keep scene node compositing and render compositing enabled. It does not reapply scene settings during Undo/Redo and does not poll periodically. Use only when shared scenes or templates often disable them.'),
    },
    'persistent_auto_render_pass_guard': {
        'label': ('レンダーパス自動維持', 'Render Pass Guard'),
        'text': ('Z、ミスト、法線、ベクトル、AO、シャドウ、放射、クリプトマットなど、合成診断で必要なパスを補助的に維持します。手動管理したいシーンでは無効にします。',
                 'Helps keep passes such as Z, Mist, Normal, Vector, AO, Shadow, Emission, and Cryptomatte enabled for compositing diagnostics. Disable it when you want manual pass control.'),
    },
    'persistent_auto_precision_output_guard': {
        'label': ('精度出力自動維持', 'Precision Output Guard'),
        'text': ('OpenEXR Multilayer、RGBA、高ビット深度、ZIP圧縮などの高精度出力設定を維持します。納品直前の固定設定用です。',
                 'Maintains high-precision output settings such as OpenEXR Multilayer, RGBA, high bit depth, and ZIP compression. Use for locked delivery scenes.'),
    },
    'persistent_auto_node_tree_sanity': {
        'label': ('ノード健全性ガード', 'Node Sanity Guard'),
        'text': ('コンポジターのノードツリー、レンダーレイヤー、ビューアー、コンポジットの最低限の存在を確認し、足りない物だけを作ります。レンダーレイヤーをつなぐのは、まだ何もつながっていないビューアーと出力だけで、既にあるノードやつながりは変えません。',
                 'Checks for a compositor node tree plus basic Render Layers, Viewer, and Composite nodes, adding only what is missing. Render Layers is connected only to a Viewer or output that has no input yet, so existing nodes and connections stay as they are.'),
    },
    'persistent_live_quality_status': {
        'label': ('品質ステータス自動更新', 'Auto Quality Status'),
        'text': ('ノード数、SCSノード数、出力ノード、レンダーパス数を軽量に集計し、品質スコアを計算して記録します。大規模ショットでは必要時だけ有効化します。',
                 'Lightly counts total nodes, SCS nodes, output nodes, and render passes, then calculates and records a quality score. Enable only when useful in large shots.'),
    },
    'search_text': {
        'label': ('検索', 'Search'),
        'text': ('独自ツールカタログを文字列で絞り込みます。SCSツール名、カテゴリ、SCSエンジン、内部参照名、プリセットIDを対象にします。',
                 'Filters the original tool catalog. It searches SCS tool names, categories, SCS engines, hidden reference names, and preset IDs.'),
    },
    'category_filter': {
        'label': ('カテゴリ', 'Category'),
        'text': ('AOV、マット、レンズ、カラー、復元など目的別にカタログを絞り込みます。「全カテゴリ」で全部の表示に戻します。',
                 'Filters the catalog by purpose such as AOV, Matte, Lens, Color, or Restoration. Use ALL to show every category.'),
    },
    'source_filter': {
        'label': ('SCSエンジン', 'SCS Engine'),
        'text': ('PrismPass、MatteForge、SpectraLight、ChromaForge、CleanRoomなど、SCS独自エンジン単位で機能を絞り込みます。',
                 'Filters by original SCS engine, such as PrismPass, MatteForge, SpectraLight, ChromaForge, or CleanRoom.'),
    },
    'catalog_limit': {
        'label': ('表示件数', 'Display Count'),
        'text': ('カタログに一度に表示する行数です。増やすと一覧性は上がりますがNパネルが長くなります。',
                 'Number of catalog rows shown at once. Higher values show more entries but make the N-panel longer.'),
    },
    'preset': {
        'label': ('追加プリセット', 'Preset to Add'),
        'text': ('コンポジターへ追加するSCSノードスタックを選びます。選択後に追加ボタンを押すと、現在のノードツリーへフレーム付きで生成します。',
                 'Selects the SCS node stack to add to the compositor. Press the add button to create it in the current node tree inside labeled frames.'),
    },
    'precision_mode': {
        'label': ('精度モード', 'Precision Mode'),
        'text': ('プレビュー、バランス、最終、極限、凌駕から、新規生成するSCSスタックの密度と診断量を選びます。既存ノードは自動変更しません。',
                 'Chooses the density and diagnostic depth of newly-created SCS stacks: PREVIEW, BALANCED, FINAL, EXTREME, or SURPASS. Existing nodes are not automatically changed.'),
    },
    'artifact_guard': {
        'label': ('破綻抑制', 'Artifact Guard'),
        'text': ('安全、強、凌駕から、白飛び、マット縁、過剰復元、過剰グローを抑える保護傾向を選びます。',
                 'Chooses SAFE, STRONG, or SURPASS protection behavior against clipping, matte-edge defects, over-restoration, and excessive glow.'),
    },
    'qc_density': {
        'label': ('QC密度', 'QC Density'),
        'text': ('軽量、標準、詳細診断、網羅診断から、診断ビューアー、QCレーン、出力確認ノードの量を選びます。',
                 'Chooses diagnostic volume: LIGHT, STANDARD, DEEP, or EXHAUSTIVE. It affects diagnostic viewers, QC lanes, and output checks.'),
    },
    'glow_quality': {
        'label': ('グロー品質', 'Glow Quality'),
        'text': ('発光・フレア系スタックの多層ブルーム、ストリーク、色収差、ハイライト保護の密度を決めます。',
                 'Controls the density of multi-lobe bloom, streaks, chromatic detail, and highlight protection in glow/flare stacks.'),
    },
    'highlight_ceiling': {
        'label': ('ハイライト保護', 'Highlight Guard'),
        'text': ('強い発光やHDRハイライトの白飛びを抑える基準値です。低めにすると保護が強く、高めにすると発光を残しやすくなります。',
                 'Threshold-like guard value for clipping in strong glow or HDR highlights. Lower values protect more; higher values preserve stronger light.'),
    },
    'matte_edge_radius': {
        'label': ('マット縁半径', 'Matte Edge Radius'),
        'text': ('マットのチョーク、拡張、フェザー、縁QCに使う基準半径です。髪や細線では小さめ、硬いIDマットではやや大きめから調整します。',
                 'Base radius for matte choke, expansion, feathering, and edge QC. Use smaller values for hair/thin lines and somewhat larger values for hard ID mattes.'),
    },
    'auto_connect_outputs': {
        'label': ('ビューアー／コンポジットへ自動接続', 'Auto-connect Viewer/Composite'),
        'text': ('生成したスタックの主要出力をビューアーまたはコンポジットへ自動接続します。既存の複雑な出力配線を守りたい場合はオフにします。',
                 'Automatically connects the main output of generated stacks to Viewer or Composite. Disable it when preserving complex existing output wiring matters.'),
    },
    'create_file_outputs': {
        'label': ('ファイル出力を作成', 'Create File Output'),
        'text': ('オンの時、パスを書き出すファイル出力ノードをプリセットと一緒に作ります。オフにすると作らないので、レンダーのたびにファイルが書かれません。「マルチパス出力」と「納品整合チェック」は、オフの時は何も追加しません。',
                 'When on, File Output nodes that write passes are created with the presets. When off, none are created, so renders write no extra files. Multi-pass File Output and Delivery Sanity Check add nothing while it is off.'),
    },
    'create_diagnostic_viewers': {
        'label': ('診断ビューアーを作成', 'Create Diagnostic Viewers'),
        'text': ('アルファ、Z、法線、ベクトル、HDR、復元結果などを確認するビューアーノードを追加します。作業台の視認性を優先する設定です。',
                 'Adds Viewer nodes for Alpha, Z, Normal, Vector, HDR, and restoration results. This prioritizes inspectability.'),
    },
    'artifact_guard_strength': {
        'label': ('破綻ガード', 'Artifact Guard Strength'),
        'text': ('破綻抑制の強度です。高いほど白飛び、縁破綻、過剰処理を抑えますが、効果が控えめになります。',
                 'Strength of artifact protection. Higher values reduce clipping, edge defects, and over-processing but make effects more conservative.'),
    },
    'edge_protection': {
        'label': ('エッジ保護', 'Edge Protection'),
        'text': ('マット、デノイズ、グロー、深度ブラーで輪郭を残す比率です。髪、細線、半透明素材では高めが安定します。',
                 'Ratio for preserving contours in matte, denoise, glow, and depth-blur stacks. Higher values help hair, thin lines, and translucent materials.'),
    },
    'artifact_diagnostics': {
        'label': ('破綻診断レーン', 'Artifact Diagnostic Lanes'),
        'text': ('白飛び、マット縁、深度範囲、復元副作用を確認する診断レーンを追加します。不要な場合はオフにしてノード量を減らします。',
                 'Adds lanes that inspect clipping, matte edges, depth range, and restoration side effects. Disable to reduce node count.'),
    },
    'matte_edge_safety': {
        'label': ('マット縁保護', 'Matte Edge Safety'),
        'text': ('マットのチョーク、拡張、フェザー、密度調整を安全側へ寄せる比率です。人物マットでは高め、硬いIDマットでは低めから調整します。',
                 'Safety-side balance for matte choke, expansion, feather, and density shaping. Start higher for people mattes and lower for hard ID mattes.'),
    },
    'optical_realism': {
        'label': ('光学リアリズム', 'Optical Realism'),
        'text': ('グロー、ブルーム、フレア、ストリーク、色収差の複合量です。上げるほどレンズ由来の多層感が増えます。',
                 'Combined amount for glow, bloom, flare, streak, and chromatic-aberration layers. Higher values add more lens-like layering.'),
    },
    'restoration_strength': {
        'label': ('復元強度', 'Restoration Strength'),
        'text': ('デノイズ、デバンド、ディテール回復、ミックスバックの全体強度です。上げすぎると質感が弱くなるため、素材に合わせて調整します。',
                 'Overall strength for denoise, deband, detail recovery, and mix-back. Too much can weaken texture, so tune per source.'),
    },
    'output_path': {
        'label': ('出力パス', 'Output Path'),
        'text': ('ファイル出力やJSON書き出しの既定保存先です。未指定時と初期値はBlender 5.1のCONFIG/Smart_Composite_Suite内にあるSCS専用exportsフォルダーです。手動で.blend相対パスまたは絶対パスを指定した場合のみ、その場所へ書き出します。',
                 'Default destination for File Output nodes and exported JSON files. When blank or left at the default, it uses the dedicated SCS exports folder inside Blender 5.1 CONFIG/Smart_Composite_Suite. A .blend-relative or absolute path is used only when you manually set one.'),
    },
    'node_offset_x': {
        'label': ('追加位置X', 'Insertion X Offset'),
        'text': ('新規ノードフレームを既存ノードの右側へ配置する距離です。既存ツリーと重なる場合は値を大きくします。',
                 'Horizontal distance used to place new node frames to the right of existing nodes. Increase it if new stacks overlap the current tree.'),
    },
    'depth_near': {
        'label': ('深度手前', 'Depth Near'),
        'text': ('奥行きを使うプリセットが効き始める距離です。「深度フォグ」などを追加する時に使います。「Zボケ」はカメラのピントを基準にするので、シーンにカメラがある時は使いません。追加した後のノードは変わりません。',
                 'The distance where presets that use depth begin to act, used when adding Depth Fog and similar presets. Z Blur follows the camera focus, so it uses this only when the scene has no camera. Nodes already added do not change.'),
    },
    'depth_far': {
        'label': ('深度奥', 'Depth Far'),
        'text': ('奥行きを使うプリセットが最大に効く距離です。深度手前より大きい値にします。「Zボケ」は、シーンにカメラがある時は使いません。追加した後のノードは変わりません。',
                 'The distance where presets that use depth reach full strength. Keep it greater than Depth Near. Z Blur uses this only when the scene has no camera. Nodes already added do not change.'),
    },
    'precision_layers': {
        'label': ('精度レイヤー数', 'Precision Layers'),
        'text': ('高精度スタックで使用する解析、保護、光学、復元レイヤーの上限数です。重い素材では少なめ、納品前に増やします。',
                 'Maximum number of analysis, guard, optical, and restoration layers used by high-precision stacks. Use fewer for heavy sources and more before delivery.'),
    },
    'ui_launcher_style': {
        'label': ('ランチャー表示', 'Launcher Style'),
        'text': ('大アイコンボタンの表示密度を選びます。超大型は図形を最大限見せ、コンパクトは一覧性を優先します。',
                 'Display density for large icon buttons. HERO maximizes symbol visibility; COMPACT prioritizes more buttons per area.'),
    },
    'launcher_columns': {
        'label': ('アイコン列数', 'Icon Columns'),
        'text': ('大アイコンランチャーの列数です。Nパネルが狭い場合は1〜2列が見やすくなります。',
                 'Column count for the large icon launcher. One or two columns are usually clearer in narrow N-panels.'),
    },
    'large_icon_scale': {
        'label': ('アイコン倍率', 'Icon Scale'),
        'text': ('通常ランチャーアイコンの縦方向スケールです。枠無しボタン内で図形をできるだけ大きく見せるために使います。',
                 'Vertical scale for normal launcher icons. It helps frameless icon buttons show symbols as large as practical.'),
    },
    'hero_icon_scale': {
        'label': ('ヒーローアイコン倍率', 'Hero Icon Scale'),
        'text': ('最重要ボタン用の大型アイコン倍率です。Apex統合などを大きく表示したい場合に使います。',
                 'Large icon scale for the most important buttons, such as Apex Command.'),
    },
    'workflow_guidance_level': {
        'label': ('工程ガイド密度', 'Workflow Guide Density'),
        'text': ('UI内ガイドの密度です。現在はNパネルを簡素化するため、詳細説明はヘルプポップアップへ集約しています。',
                 'Density of workflow guidance. Detailed explanations are centralized into help popups to keep the N-panel compact.'),
    },
    'auto_optimize_ui_visibility': {
        'label': ('UI視認性を優先', 'Prioritize UI Visibility'),
        'text': ('有効時はアイコンを大きめにし、超大型系の視認性を優先します。狭い画面では必要に応じて無効化します。',
                 'When enabled, SCS favors larger icons and HERO-style visibility. Disable on very narrow layouts if needed.'),
    },
    'reference_preview_scale': {
        'label': ('リファレンス表示倍率', 'Reference Preview Scale'),
        'text': ('画像リファレンスのプレビュー倍率です。工程図をNパネル内で大きく確認したい場合に上げます。',
                 'Preview scale for visual reference images. Increase it to inspect workflow diagrams more clearly in the N-panel.'),
    },
    'show_reference_previews': {
        'label': ('画像リファレンスを表示', 'Show Visual References'),
        'text': ('Nパネル内に独自画像リファレンスを表示します。軽さを優先する場合は無効にし、必要時だけ画像を開きます。',
                 'Shows custom visual references inside the N-panel. Disable for a lighter panel and open images only when needed.'),
    },
    'reference_columns': {
        'label': ('リファレンス列数', 'Reference Columns'),
        'text': ('画像リファレンスの列数です。大きく見たい場合は1列、一覧性を優先する場合は2列にします。',
                 'Column count for visual references. Use one column for larger previews or two for overview density.'),
    },
    'last_message': {
        'label': ('状態メッセージ', 'Status Message'),
        'text': ('直近のSCS操作結果と、品質ステータス自動更新が有効な場合のイベント駆動診断結果を表示する一時状態欄です。編集用ではなく、JSONや.blendには保存されません。詳細は品質レポートJSONで確認します。',
                 'A transient status field showing the latest SCS operation result and event-driven diagnostic result when Auto Quality Status is enabled. It is not editable or stored in JSON or the .blend file. Use the quality report JSON for details.'),
    },
}

ALL_SETTINGS = tuple(SETTING_HELP.keys())

HELP_TOPICS = {
    'root': {
        'label': ('Smart Composite', 'Smart Composite'),
        'icon': 'scs_logo',
        'overview': [
            ('このアドオンの入口です。常時機能の切り替えと、エフェクトの追加をまとめています。', 'Entry point of this add-on. It holds the resident-feature toggles and adding effects.'),
            ('エフェクトはBlender標準のノードで組むので、追加した後に自由に調整できます。', 'Effects are built from standard Blender nodes, so they can be adjusted freely after adding.'),
        ],
        'usage': [
            ('必要な常時起動機能だけを有効にします。Blender 5.1ではUIアイコンキャッシュを含む全項目を、必要がなければ無効のまま使用できます。表示言語はBlender本体の言語設定に追従します。', 'Enable only the persistent helpers you need. On Blender 5.1, every optional toggle, including UI Icon Cache, may remain disabled when not needed. Display language follows Blender language settings.'),
            ('エフェクトの追加はボタンを押した時だけ動作します。Nパネル状態保存を無効にすると無効の状態を最後に1回保存し、再度有効にするまで設定JSONを書き換えません。', 'Adding effects runs only when its button is pressed. Disabling N-panel State Save commits OFF once and leaves the settings JSON unchanged until re-enabled.'),
        ],
        'settings': ('preset', 'node_offset_x'),
    },
    'persistent_toggles': {
        'label': ('常時機能切り替え', 'Always-on Toggles'),
        'icon': 'clock',
        'overview': [
            ('常時起動が必要な機能だけを集約したグループです。無効の項目はハンドラー、タイマー、キャッシュ処理を登録せず、UI表示以外の負荷を持ちません。', 'This group centralizes only features that may need persistence. Disabled items register no handlers, timers, or cache work and add no cost beyond UI drawing.'),
        ],
        'usage': [
            ('左に機能名、右に有効/無効チェックを表示します。有効時はBlender標準のトグル描画で青いアクティブ表示になります。', 'The feature name is shown on the left and the Enabled/Disabled checkbox on the right. Enabled items use Blender toggle drawing for a stable blue active state.'),
            ('最終QCやテンプレート維持など、明確な理由がある項目だけ有効にします。', 'Enable only items with a clear reason, such as final QC or template maintenance.'),
        ],
        'settings': ('n_panel_state_save','show_always_on_toggles','persistent_ui_asset_cache','persistent_auto_enable_compositor','persistent_auto_render_pass_guard','persistent_auto_precision_output_guard','persistent_auto_node_tree_sanity','persistent_live_quality_status'),
    },
    'apex_command': {
        'label': ('Apexコマンドセンター', 'Apex Command Center'),
        'icon': 'apex',
        'overview': [
            ('最重要の総合ワークスペースと診断系スタックを大アイコンから実行するランチャーです。', 'Launcher for the most important integrated workspaces and diagnostic stacks through large icon buttons.'),
            ('AOV差分、深層マット、レンズ設計、HDR整形、知覚マッチ、適応復元、モーション、3D信号、納品QCを短い導線で作成します。', 'Creates AOV delta, deep matte, lens design, HDR sculpting, perception matching, adaptive restoration, motion, 3D signals, and delivery QC with short interaction paths.'),
        ],
        'usage': [
            ('Apex統合を押すと、複数の高精度作業台をまとめて生成します。個別アイコンは必要な作業台だけ追加したい場合に使います。', 'Press Apex Command to create multiple high-precision workbenches together. Use individual icons when you want only one stack.'),
            ('生成後はBlender標準ノードとして各ノードを直接調整します。', 'After generation, adjust the result directly as regular Blender nodes.'),
        ],
        'settings': ('ui_launcher_style','hero_icon_scale','auto_optimize_ui_visibility','launcher_columns','large_icon_scale','precision_mode','qc_density','artifact_guard'),
    },
    'launchpad': {
        'label': ('大アイコン・ランチャー', 'Large Icon Launchpad'),
        'icon': 'scs_logo',
        'overview': [
            ('主要プリセットを枠無しの大型アイコンで追加する実行パネルです。図形を最大表示し、ラベルはボタン外に分離しています。', 'Execution panel for major presets through frameless large icons. Symbols are maximized and labels are separated from the buttons.'),
        ],
        'usage': [
            ('列数と倍率を調整して、Nパネル幅に合わせます。超大型や大きめの倍率は視認性重視、列数増加は一覧性重視です。', 'Adjust columns and scale for your N-panel width. HERO/larger scales prioritize visibility; more columns prioritize overview density.'),
        ],
        'settings': ('ui_launcher_style','launcher_columns','large_icon_scale','hero_icon_scale','auto_optimize_ui_visibility','precision_mode','glow_quality','create_diagnostic_viewers','create_file_outputs'),
    },
    'precision_dashboard': {
        'label': ('精度ダッシュボード', 'Precision Dashboard'),
        'icon': 'qc',
        'overview': [
            ('新規生成するSCSノードスタックの精度、保護、診断、深度、出力接続を制御する設定パネルです。', 'Settings panel controlling precision, guards, diagnostics, depth, and output wiring for newly-created SCS node stacks.'),
        ],
        'usage': [
            ('プレビュー中は軽め、納品前は最終または凌駕へ上げます。既存ノードは自動変更しないため、必要なスタックを追加し直して反映します。', 'Use lighter settings during preview and FINAL or SURPASS before delivery. Existing nodes are not auto-changed, so add a fresh stack when you want updated settings.'),
        ],
        'settings': ('precision_mode','artifact_guard','qc_density','glow_quality','artifact_guard_strength','edge_protection','matte_edge_safety','highlight_ceiling','optical_realism','restoration_strength','precision_layers','matte_edge_radius','depth_near','depth_far','auto_connect_outputs','create_diagnostic_viewers','create_file_outputs','artifact_diagnostics'),
    },
    'ui_polish': {
        'label': ('UI洗練', 'UI Polish'),
        'icon': 'hero',
        'overview': [
            ('SCSの大アイコンUI、リファレンス表示、工程ガイド密度を調整するUI専用パネルです。', 'UI-only panel for adjusting SCS large icons, reference previews, and workflow guidance density.'),
        ],
        'usage': [
            ('視認性を最大化を押すと、超大型表示、2列、大きめのアイコン、1列リファレンスへ寄せます。', 'Press Maximize Visibility to favor HERO display, two columns, larger icons, and one-column references.'),
        ],
        'settings': ('ui_launcher_style','auto_optimize_ui_visibility','large_icon_scale','hero_icon_scale','launcher_columns','workflow_guidance_level','reference_preview_scale','reference_columns','show_reference_previews'),
    },
    'visual_references': {
        'label': ('画像リファレンス', 'Visual References'),
        'icon': 'reference',
        'overview': [
            ('SCS独自の言語非依存PNG工程図を表示・開くためのパネルです。画像内に固定言語テキストを入れず、説明はUIとヘルプに集約しています。', 'Panel for showing and opening SCS-original language-independent PNG workflow diagrams. The images contain no fixed-language text; explanations live in UI and help.'),
        ],
        'usage': [
            ('表示が重い場合はプレビューをオフにし、必要な画像だけクリックして開きます。', 'If previews feel heavy, disable them and open only the needed image on demand.'),
        ],
        'settings': ('show_reference_previews','reference_columns','reference_preview_scale','persistent_ui_asset_cache'),
    },
    'setup': {
        'label': ('セットアップ', 'Setup'),
        'icon': 'setup',
        'overview': [
            ('コンポジター使用、レンダーパス、高精度出力、Apex構成、総合作業台など、制作開始時に使う一回実行系ツールです。', 'One-shot startup tools for compositor use, render passes, high-precision output, Apex stacks, and master workspaces.'),
        ],
        'usage': [
            ('通常はコンポジター有効化、レンダーパス有効化、シーン精度適用の順に実行し、その後に必要な作業台を追加します。', 'Normally run Enable Compositor, Enable Render Passes, and Apply Scene Precision, then add the needed workspace.'),
            ('常時起動ではないため、押さない限りシーン設定やノードツリーを変更しません。Nパネル設定、標準書き出し先、実行時キャッシュはすべてBlender 5.1のCONFIG/Smart_Composite_Suite配下へ収めます。', 'These are not persistent; they do not change scene settings or node trees unless pressed. N-panel settings, default exports, and runtime caches are all kept below Blender 5.1 CONFIG/Smart_Composite_Suite.'),
        ],
        'settings': ('output_path','node_offset_x','precision_mode','create_file_outputs','auto_connect_outputs'),
    },
    'presets': {
        'label': ('エフェクト／プリセット', 'Effects / Presets'),
        'icon': 'favorites',
        'overview': [
            ('効果をノードのまとまりとしてコンポジターに追加します。下の6つのボタンはよく使う効果です。', 'Adds effects to the compositor as groups of nodes. The six buttons below are common effects.'),
        ],
        'usage': [
            ('「追加プリセット」で選び、「選択した効果を適用」を押します。隣の「？」で、選んだプリセットの働きを読めます。', 'Choose one in Preset to Add and press Apply Selected Effect. The ? next to it explains the chosen preset.'),
            ('続けて押すと、前の効果の結果に次の効果が重なります。押した順に効きます。白黒の確認用プリセットの次の効果は、レンダーの絵から始まります。総合の作業台は、仕上げの段だけを順につなぎます。マット、外部の画像を使う段、確認用、強い効果は、ノードを置くだけで出力にはつなぎません。', 'Pressing another effect stacks it on the result of the previous one, in the order you press them. After a black-and-white check preset, the next effect starts from the render. A workspace connects only its finishing stages in order. Matte, external-image, check, and strong-look stages are placed but not connected to the output.'),
            ('「Zボケ」は、カメラのピントの距離を基準にぼかします。カメラの撮影距離を変えたらもう一度押すと、足したボケを合わせ直します。F 値は「SCS 絞りのボケ」のノードで変えられ、小さいほど強くぼけます。', 'Z Blur is based on the camera focus distance, and pressing it again after changing the focus re-aims the blur already added. Change the F-stop on the SCS Aperture Defocus node. A smaller value blurs more.'),
            ('「SCSノードを整理」は、このアドオンが追加したノードをまとめて消します。', 'Clean SCS Nodes removes the nodes this add-on added.'),
        ],
        'settings': ('preset', 'node_offset_x', 'depth_near', 'depth_far', 'create_file_outputs'),
    },
    'catalog': {
        'label': ('独自ツールカタログ', 'Original Tool Catalog'),
        'icon': 'catalog',
        'overview': [
            ('コンポジットの機能を目的や名前で探して追加できるカタログです。', 'Search catalog that converts compositing software and plugin goals from the research document into SCS-original names.'),
            ('検索結果にプリセットIDがある場合は、その行から対応スタックを直接追加できます。', 'When a result has a preset ID, the corresponding stack can be added directly from that row.'),
        ],
        'usage': [
            ('検索語、カテゴリ、SCSエンジン、表示件数で絞り込みます。Nパネル上は簡易一覧だけを表示し、詳細解説はこのヘルプに集約しています。', 'Filter by search text, category, SCS engine, and display count. The N-panel shows only a compact list; detailed explanations are centralized in this help.'),
        ],
        'settings': ('search_text','category_filter','source_filter','catalog_limit','preset'),
    },
    'pipeline': {
        'label': ('パイプライン', 'Pipeline'),
        'icon': 'pipeline',
        'overview': [
            ('納品チェック、マルチパス出力、アセットシェルフ準備、QCツールセット、カタログJSON、品質レポート、SCSノード整理を扱うパネルです。', 'Panel for delivery checks, multipass output, Asset Shelf prep, QC suite, catalog JSON, quality reports, and SCS node cleanup.'),
        ],
        'usage': [
            ('作業終盤で納品整合チェック、マルチパス出力、品質レポートを書き出します。未指定時の書き出し先はCONFIG/Smart_Composite_Suite内のSCS exportsで、手動出力パスを指定した場合のみそのフォルダーを使います。SCSノード整理はSCSが作成した識別付きノードだけを対象にします。', 'Near delivery, add Delivery Sanity Check, multipass outputs, and export the quality report. Without a manual output path, exports go to the SCS exports folder under CONFIG/Smart_Composite_Suite; a manually chosen path is used only when set. Clean SCS Nodes targets only SCS-tagged nodes.'),
        ],
        'settings': ('output_path','create_file_outputs','auto_connect_outputs','artifact_diagnostics','qc_density','precision_mode'),
    },
}


def _build_preset_topic(key: str):
    preset_id = str(key or '').partition(':')[2].strip().upper()
    if not preset_id:
        return HELP_TOPICS['presets']
    try:
        from .visual_assets import PRESET_ICONS
        icon_key = PRESET_ICONS.get(preset_id, 'help')
    except Exception:
        icon_key = 'help'
    try:
        from .preset_help import PRESET_OVERVIEW
        from .properties import _preset_label_pair
        label = _preset_label_pair(preset_id)
        overview = PRESET_OVERVIEW.get(preset_id)
    except Exception:
        label = ('プリセット', 'Preset')
        overview = None
    return {
        'label': label,
        'icon': icon_key,
        'overview': [overview or ('コンポジターにノードのまとまりを追加します。', 'Adds a group of nodes to the compositor.')],
        'usage': [
            ('「選択した効果を適用」を押すと、今のノードの右側に枠で囲んだノードのまとまりを追加します。', 'Press Apply Selected Effect to add a framed group of nodes to the right of the current nodes.'),
            ('追加した後は普通のノードとして調整できます。要らなくなったら「SCSノードを整理」で消せます。SCSのノードだけがつながっていたグループ出力は、レンダーレイヤーへつなぎ直します。', 'After adding, adjust them as normal nodes. Remove them with Clean SCS Nodes; a Group Output that only SCS nodes fed is reconnected to Render Layers.'),
        ],
        'settings': ('preset', 'node_offset_x'),
    }


def _resolve_topic(key: str):
    normalized = str(key or 'root').strip() or 'root'
    if normalized.startswith('preset:'):
        return _build_preset_topic(normalized)
    return HELP_TOPICS.get(normalized, HELP_TOPICS['root'])


_HELP_BUILTIN_ICONS = {
    'root': 'NODETREE',
    'persistent_toggles': 'TIME',
    'apex_command': 'NODETREE',
    'launchpad': 'NODETREE',
    'precision_dashboard': 'CHECKMARK',
    'ui_polish': 'PREFERENCES',
    'visual_references': 'IMAGE_DATA',
    'setup': 'NODETREE',
    'presets': 'ADD',
    'catalog': 'FILE_FOLDER',
    'pipeline': 'EXPORT',
}


def _icon_for(key, settings=None):
    normalized = str(key or 'root').strip() or 'root'
    if normalized.startswith('preset:'):
        return ('ADD', 0)
    try:
        from . import visual_assets
        return (visual_assets.safe_builtin_icon(_HELP_BUILTIN_ICONS.get(normalized, 'QUESTION'), 'QUESTION'), 0)
    except Exception:
        return ('QUESTION', 0)


def _draw_setting_items(layout, keys, settings=None):
    seen = set()
    for key in keys or ():
        if key in seen:
            continue
        seen.add(key)
        data = SETTING_HELP.get(key)
        if not data:
            continue
        box = layout.box()
        label = _pair(data['label'], settings)
        _wrap_label(box, label, icon='DOT', settings=settings)
        _wrap_label(box, _pair(data['text'], settings), icon='BLANK1', settings=settings)


def _topic_label(key, settings=None):
    topic = _resolve_topic(key)
    return _pair(topic.get('label', ('Smart Composite','Smart Composite')), settings)


class SCOMP_OT_tool_help_popup(bpy.types.Operator):
    bl_idname = 'smart_composite.tool_help_popup'
    bl_label = t('Smart Compositeヘルプ', 'Smart Composite Help')
    bl_description = t('Smart Compositeの詳細ヘルプを表示します。', 'Display detailed Smart Composite help.')
    bl_options = set()
    _sms_no_undo = True

    alias: StringProperty(options={'SKIP_SAVE'}, default='root')  # type: ignore

    @classmethod
    def description(cls, context, properties):
        settings = _settings(context)
        return t('選択したSmart Compositeグループの詳細ヘルプを表示します。', 'Display detailed help for the selected Smart Composite group.', settings)

    def invoke(self, context, event):
        from . import status_runtime
        self._scs_status_token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        return context.window_manager.invoke_props_dialog(self, width=_POPUP_WIDTH, title=t('Smart Compositeヘルプ', 'Smart Composite Help', _settings(context)))

    def execute(self, context):
        from . import status_runtime
        token = str(getattr(self, "_scs_status_token", "") or "") or status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        status_runtime.finish_operation(token, self.bl_idname)
        return {'FINISHED'}

    def cancel(self, context):
        from . import status_runtime
        token = str(getattr(self, "_scs_status_token", "") or "") or status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        status_runtime.cancel_operation(token, self.bl_idname, "Esc")

    def draw(self, context):
        settings = _settings(context)
        key = str(getattr(self, 'alias', '') or 'root').strip() or 'root'
        topic = _resolve_topic(key)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        header = layout.box()
        builtin_icon, icon_value = _icon_for(key, settings)
        if icon_value:
            header.label(text=_topic_label(key, settings), icon_value=icon_value)
        else:
            header.label(text=_topic_label(key, settings), icon=builtin_icon)
        _draw_section(layout, '機能概要', 'Feature Overview', topic.get('overview', ()), settings, icon='NONE')
        _draw_section(layout, '使用方法', 'How to Use', topic.get('usage', ()), settings, icon='PLAY')
        settings_box = layout.box()
        settings_box.label(text=t('設定', 'Settings', settings), icon='PREFERENCES')
        _draw_setting_items(settings_box, topic.get('settings', ()), settings)


def _current_lifecycle_identity() -> tuple[str, int]:
    try:
        from . import registration
        token = str(registration.current_owner_token() or "")
        generation = int(registration.current_generation() or 0)
    except Exception:
        return "", 0
    if not token or token == "unregistered" or generation <= 0:
        return "", 0
    return token, generation


def _class_registered_exact(cls) -> bool:
    try:
        return bool(cls is not None and getattr(cls, "is_registered", False))
    except Exception:
        return False


def _class_owner_matches(cls, token: str, generation: int) -> bool:
    try:
        return bool(
            str(getattr(cls, _CLASS_OWNER_ATTR, "")) == "JELararagi"
            and str(getattr(cls, _CLASS_PACKAGE_ATTR, "")) == "smart_composite_suite"
            and str(getattr(cls, _CLASS_TOKEN_ATTR, "")) == token
            and int(getattr(cls, _CLASS_GENERATION_ATTR, -1)) == generation
        )
    except Exception:
        return False


def register():
    global _REGISTERED, _REGISTERED_CLASS, _REGISTER_TOKEN, _REGISTER_GENERATION
    token, generation = _current_lifecycle_identity()
    if not token or generation <= 0:
        return False
    if registration_identity_valid():
        return True
    # Recover only the exact class object preserved by this module. Never resolve
    # a stale operator through bpy.types or bl_idname.
    if _REGISTERED_CLASS is not None:
        if _class_registered_exact(_REGISTERED_CLASS):
            if not _class_owner_matches(_REGISTERED_CLASS, _REGISTER_TOKEN, _REGISTER_GENERATION):
                return False
            try:
                bpy.utils.unregister_class(_REGISTERED_CLASS)
            except Exception:
                return False
        _REGISTERED_CLASS = None
        _REGISTERED = False
    cls = SCOMP_OT_tool_help_popup
    try:
        setattr(cls, _CLASS_OWNER_ATTR, "JELararagi")
        setattr(cls, _CLASS_PACKAGE_ATTR, "smart_composite_suite")
        setattr(cls, _CLASS_TOKEN_ATTR, token)
        setattr(cls, _CLASS_GENERATION_ATTR, generation)
        bpy.utils.register_class(cls)
    except Exception:
        # Track native partial success by exact identity and immediately rollback.
        if _class_registered_exact(cls):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                _REGISTERED_CLASS = cls
                _REGISTERED = True
                _REGISTER_TOKEN = token
                _REGISTER_GENERATION = generation
                return False
        _REGISTERED_CLASS = None
        _REGISTERED = False
        return False
    _REGISTERED_CLASS = cls
    _REGISTER_TOKEN = token
    _REGISTER_GENERATION = generation
    _REGISTERED = True
    if not registration_identity_valid():
        unregister()
        return False
    return True


def unregister():
    global _REGISTERED, _REGISTERED_CLASS, _REGISTER_TOKEN, _REGISTER_GENERATION
    target = _REGISTERED_CLASS
    if target is not None and _class_registered_exact(target):
        if not _class_owner_matches(target, _REGISTER_TOKEN, _REGISTER_GENERATION):
            return False
        try:
            bpy.utils.unregister_class(target)
        except Exception:
            return False
        if _class_registered_exact(target):
            return False
    _REGISTERED_CLASS = None
    _REGISTERED = False
    _REGISTER_TOKEN = ""
    _REGISTER_GENERATION = 0
    return True


def registered_class_identity():
    return _REGISTERED_CLASS


def registration_identity_valid() -> bool:
    token, generation = _current_lifecycle_identity()
    return bool(
        _REGISTERED
        and _REGISTERED_CLASS is SCOMP_OT_tool_help_popup
        and token == _REGISTER_TOKEN
        and generation == _REGISTER_GENERATION
        and _class_registered_exact(_REGISTERED_CLASS)
        and _class_owner_matches(_REGISTERED_CLASS, token, generation)
    )


def show_tool_help(context, alias: str) -> bool:
    key = str(alias or 'root').strip() or 'root'
    if not register():
        return False
    try:
        bpy.ops.smart_composite.tool_help_popup('INVOKE_DEFAULT', alias=key)
        return True
    except Exception:
        def _draw(menu, popup_context):
            settings = _settings(popup_context)
            layout = menu.layout
            topic = _resolve_topic(key)
            _wrap_label(layout, _topic_label(key, settings), icon='NONE', settings=settings)
            _draw_section(layout, '機能概要', 'Feature Overview', topic.get('overview', ()), settings, icon='NONE')
            _draw_section(layout, '使用方法', 'How to Use', topic.get('usage', ()), settings, icon='PLAY')
            box = layout.box()
            box.label(text=t('設定', 'Settings', settings), icon='PREFERENCES')
            _draw_setting_items(box, topic.get('settings', ()), settings)
        try:
            context.window_manager.popup_menu(_draw, title=_topic_label(key, _settings(context)), icon='QUESTION')
            return True
        except Exception:
            return False
