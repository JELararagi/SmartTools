# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from __future__ import annotations

import json
import os
from datetime import datetime
from typing import Any

import bpy
from bpy.props import StringProperty

from . import status_runtime, storage, transaction
from .catalog import export_dict
from .properties import batch_settings_update, get_settings
from .tooltips import build_tooltip
from .translation import t


def _builders_module():
    from . import builders
    return builders


def _node_utils_module():
    from . import node_utils
    return node_utils


def _quality_module():
    from . import quality
    return quality


def _set_status(context, message: str) -> None:
    settings = get_settings(context)
    if settings is None:
        return
    try:
        transaction.set_attr(settings, "last_message", str(message or ""))
    except Exception:
        pass


def _resolve_output_directory(settings=None) -> str:
    try:
        base = str(getattr(settings, "output_path", "") or "").strip()
    except Exception:
        base = ""
    if not base:
        return str(storage.default_export_dir(create=True))
    try:
        if base.startswith("//"):
            return bpy.path.abspath(base)
    except Exception:
        pass
    return base


def _safe_filename(value: object, fallback: str) -> str:
    name = os.path.basename(str(value or "").replace("\\", "/"))
    if not name or name in {".", ".."}:
        name = fallback
    if not name.lower().endswith(".json"):
        name += ".json"
    return name


def _apply_enabled_event_guards(context, *, include_quality: bool = False) -> None:
    from . import persistent_features
    persistent_features.apply_enabled_event_guards(context, include_quality=include_quality)


def _refresh_enabled_quality_status(context) -> None:
    try:
        from . import persistent_features
        if persistent_features.feature_value("live_quality_status", context):
            persistent_features.refresh_live_quality_status(context)
    except Exception:
        pass


def _preserve_transforms(context):
    try:
        from .transform_guard import preserve_object_transforms
        return preserve_object_transforms(context)
    except Exception:
        from contextlib import nullcontext
        return nullcontext()


def _result_message(result: Any) -> str:
    message = str(getattr(result, "message", "") or "")
    nodes = int(getattr(result, "nodes_created", 0) or 0)
    links = int(getattr(result, "links_created", 0) or 0)
    if nodes or links:
        template = t("{message} ノード {nodes} 個、リンク {links} 本。", "{message} {nodes} nodes, {links} links.")
        message = template.format(message=message, nodes=nodes, links=links)
    return message


def _report(operator, level: set[str], message: str) -> None:
    try:
        operator.report(level, message)
    except Exception:
        pass


def _failure(operator, context, token: str, message: str) -> set[str]:
    # CANCELLED/failed operators must not leave RNA status mutations behind.
    # User feedback is delivered through the Operator report and primitive
    # generation-owned status record only.
    _report(operator, {"ERROR"}, message)
    status_runtime.fail_operation(token, operator.bl_idname, message)
    return {"CANCELLED"}


def _cancel(operator, context, token: str, message: str) -> set[str]:
    _report(operator, {"ERROR"}, message)
    status_runtime.cancel_operation(token, operator.bl_idname, message)
    return {"CANCELLED"}


class SCOMP_OT_enable_compositor(bpy.types.Operator):
    bl_idname = "smart_composite.enable_compositor"
    bl_label = t("コンポジターを有効化", "Enable Compositor")
    bl_description = build_tooltip("enable_compositor")
    bl_options = {"UNDO"}

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        try:
            with transaction.mutation_transaction(self.bl_idname) as active:
                _apply_enabled_event_guards(context, include_quality=False)
                with _preserve_transforms(context):
                    result = _builders_module().enable_compositor(context)
                active.commit()
            message = _result_message(result)
            _set_status(context, message)
            _report(self, {"INFO"}, message)
            status_runtime.finish_operation(token, self.bl_idname, message)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("コンポジター有効化に失敗しました", f"Failed to enable compositor: {exc}"))


class SCOMP_OT_enable_render_passes(bpy.types.Operator):
    bl_idname = "smart_composite.enable_render_passes"
    bl_label = t("レンダーパスを有効化", "Enable Render Passes")
    bl_description = build_tooltip("passes")
    bl_options = {"UNDO"}

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        try:
            with transaction.mutation_transaction(self.bl_idname) as active:
                _apply_enabled_event_guards(context, include_quality=False)
                with _preserve_transforms(context):
                    result = _builders_module().enable_render_passes(context)
                active.commit()
            message = _result_message(result)
            _set_status(context, message)
            _report(self, {"INFO"}, message)
            status_runtime.finish_operation(token, self.bl_idname, message)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("レンダーパスの有効化に失敗しました", f"Failed to enable Render Passes: {exc}"))


class SCOMP_OT_build_master_workspace(bpy.types.Operator):
    bl_idname = "smart_composite.build_master_workspace"
    bl_label = t("総合作業台を作成", "Build Master Workspace")
    bl_description = build_tooltip("build_workspace")
    bl_options = {"UNDO"}

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        try:
            with transaction.mutation_transaction(self.bl_idname) as active:
                _apply_enabled_event_guards(context, include_quality=False)
                with _preserve_transforms(context):
                    result = _builders_module().build_master_workspace(context)
                active.commit()
            message = _result_message(result)
            _set_status(context, message)
            _report(self, {"INFO"}, message)
            status_runtime.finish_operation(token, self.bl_idname, message)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("総合作業台の作成に失敗しました", f"Failed to build the master workspace: {exc}"))


class SCOMP_OT_add_preset(bpy.types.Operator):
    bl_idname = "smart_composite.add_preset"
    bl_label = t("選択プリセットを追加", "Add Selected Preset")
    bl_description = build_tooltip("add_preset")
    bl_options = {"UNDO"}

    preset_id: StringProperty(
        name=t("プリセットID", "Preset ID"),
        description=t("追加するSmart CompositeプリセットIDです。空の場合はNパネルの選択値を使用します。", "Smart Composite preset ID to add. If empty, the N-panel selected preset is used."),
        default="",
    )  # type: ignore

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        settings = get_settings(context)
        preset_id = str(getattr(self, "preset_id", "") or "").strip()
        if not preset_id and settings is not None:
            preset_id = str(getattr(settings, "preset", "") or "").strip()
        if not preset_id:
            return _cancel(self, context, token, t("プリセットが選択されていません。", "No preset selected."))
        try:
            with transaction.mutation_transaction(self.bl_idname) as active:
                _apply_enabled_event_guards(context, include_quality=False)
                with _preserve_transforms(context):
                    result = _builders_module().build_preset(preset_id, context)
                active.commit()
            message = _result_message(result)
            _set_status(context, message)
            _report(self, {"INFO"}, message)
            status_runtime.finish_operation(token, self.bl_idname, message)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("実行に失敗しました", f"Operation failed: {exc}"))


class SCOMP_OT_clear_scs_nodes(bpy.types.Operator):
    bl_idname = "smart_composite.clear_scs_nodes"
    bl_label = t("SCSノードを整理", "Clean SCS Nodes")
    bl_description = build_tooltip("clear_scs")
    bl_options = {"UNDO"}

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        try:
            node_utils = _node_utils_module()
            with transaction.mutation_transaction(self.bl_idname) as active:
                with _preserve_transforms(context):
                    tree = node_utils.existing_compositor_tree(context)
                    count = node_utils.delete_scs_nodes(tree) if tree is not None else 0
                active.commit()
            node_utils.release_empty_created_tree(context)
            try:
                from .proxy_cleanup import cleanup_scene_proxy_data
                cleanup_scene_proxy_data(context)
            except Exception:
                pass
            message = t(f"Smart Compositeノードを削除しました: {count}件。", f"Deleted Smart Composite nodes: {count} item(s).")
            _set_status(context, message)
            _refresh_enabled_quality_status(context)
            _report(self, {"INFO"}, message)
            status_runtime.finish_operation(token, self.bl_idname, message)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("整理に失敗しました", f"Cleanup failed: {exc}"))


class SCOMP_OT_audit_scene(bpy.types.Operator):
    bl_idname = "smart_composite.audit_scene"
    bl_label = t("合成設定を診断", "Audit Composite Setup")
    bl_description = build_tooltip("audit")
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        scene = getattr(context, "scene", None)
        view_layer = getattr(context, "view_layer", None)
        try:
            node_utils = _node_utils_module()
            tree = node_utils.existing_compositor_tree(context)
            summary = node_utils.tree_summary(tree) if tree is not None else {"total_nodes": 0, "smart_nodes": 0, "output_nodes": 0, "frames": 0}
            pass_names = []
            for attr in (
                "use_pass_z", "use_pass_mist", "use_pass_normal", "use_pass_vector",
                "use_pass_cryptomatte_object", "use_pass_cryptomatte_material",
                "use_pass_diffuse_direct", "use_pass_glossy_direct", "use_pass_emit", "use_pass_ambient_occlusion",
            ):
                if view_layer is not None and bool(getattr(view_layer, attr, False)):
                    pass_names.append(attr.replace("use_pass_", ""))
            if scene is not None and hasattr(scene, "compositing_node_group"):
                compositor_ready = getattr(scene, "compositing_node_group", None) is not None
            else:
                compositor_ready = bool(getattr(scene, "use_nodes", False)) if scene is not None else False
            _quality_module().quality_report(context, get_settings(context))
            message = t(
                f"診断完了：コンポジターのノードツリーは{'あり' if compositor_ready else 'なし'}、ノード {summary['total_nodes']} 個（うち SCS {summary['smart_nodes']} 個）、出力 {summary['output_nodes']} 個、有効なパス {len(pass_names)} 個です。",
                f"Audit complete: compositor node tree {'found' if compositor_ready else 'missing'}, {summary['total_nodes']} nodes ({summary['smart_nodes']} SCS), {summary['output_nodes']} outputs, {len(pass_names)} passes on.",
            )
            _set_status(context, message)
            _refresh_enabled_quality_status(context)
            _report(self, {"INFO"}, message)
            status_runtime.finish_operation(token, self.bl_idname, message)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("診断に失敗しました", f"Audit failed: {exc}"))


class SCOMP_OT_export_manifest(bpy.types.Operator):
    bl_idname = "smart_composite.export_manifest"
    bl_label = t("独自ツールカタログを書き出し", "Export Original Tool Catalog")
    bl_description = build_tooltip("export_manifest")
    bl_options = set()
    _sms_no_undo = True

    filename: StringProperty(
        name=t("ファイル名", "File Name"),
        description=t("書き出すJSONファイル名です。", "Name of the JSON file to export."),
        default="smart_composite_suite_original_tool_catalog.json",
    )  # type: ignore

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        settings = get_settings(context)
        base = _resolve_output_directory(settings)
        try:
            os.makedirs(base, exist_ok=True)
            filename = _safe_filename(getattr(self, "filename", "smart_composite_suite_original_tool_catalog.json"), "smart_composite_suite_original_tool_catalog.json")
            path = os.path.join(base, filename)
            payload = export_dict()
            payload.update({
                "exported_at": datetime.now().isoformat(timespec="seconds"),
                "settings": {
                    "preset": getattr(settings, "preset", "") if settings else "",
                    "precision_mode": getattr(settings, "precision_mode", "FINAL") if settings else "FINAL",
                    "glow_quality": getattr(settings, "glow_quality", "FINAL") if settings else "FINAL",
                    "precision_layers": int(getattr(settings, "precision_layers", 4) or 4) if settings else 4,
                    "artifact_guard": getattr(settings, "artifact_guard", "STRONG") if settings else "STRONG",
                    "matte_edge_safety": float(getattr(settings, "matte_edge_safety", 0.65) or 0.65) if settings else 0.65,
                    "optical_realism": float(getattr(settings, "optical_realism", 0.72) or 0.72) if settings else 0.72,
                    "restoration_strength": float(getattr(settings, "restoration_strength", 0.38) or 0.38) if settings else 0.38,
                    "category_filter": getattr(settings, "category_filter", "ALL") if settings else "ALL",
                    "source_filter": getattr(settings, "source_filter", "ALL") if settings else "ALL",
                    "catalog_limit": int(getattr(settings, "catalog_limit", 18) or 18) if settings else 18,
                    "auto_connect_outputs": bool(getattr(settings, "auto_connect_outputs", True)) if settings else True,
                    "create_file_outputs": bool(getattr(settings, "create_file_outputs", True)) if settings else True,
                    "create_diagnostic_viewers": bool(getattr(settings, "create_diagnostic_viewers", True)) if settings else True,
                    "artifact_diagnostics": bool(getattr(settings, "artifact_diagnostics", True)) if settings else True,
                    "artifact_guard_strength": float(getattr(settings, "artifact_guard_strength", 0.78) or 0.78) if settings else 0.78,
                    "edge_protection": float(getattr(settings, "edge_protection", 0.72) or 0.72) if settings else 0.72,
                    "output_path": base,
                    "ui_launcher_style": getattr(settings, "ui_launcher_style", "HERO") if settings else "HERO",
                    "large_icon_scale": float(getattr(settings, "large_icon_scale", 6.5) or 6.5) if settings else 6.5,
                    "hero_icon_scale": float(getattr(settings, "hero_icon_scale", 7.5) or 7.5) if settings else 7.5,
                    "reference_preview_scale": float(getattr(settings, "reference_preview_scale", 5.4) or 5.4) if settings else 5.4,
                    "reference_columns": int(getattr(settings, "reference_columns", 1) or 1) if settings else 1,
                    "workflow_guidance_level": getattr(settings, "workflow_guidance_level", "GUIDED") if settings else "GUIDED",
                    "auto_optimize_ui_visibility": bool(getattr(settings, "auto_optimize_ui_visibility", True)) if settings else True,
                },
            })
            try:
                from .properties import settings_to_dict
                payload["n_panel_settings"] = settings_to_dict(settings)
            except Exception:
                pass
            storage.atomic_write_json(path, payload, indent=2, ensure_ascii=False, sort_keys=False)
            message = t(f"独自ツールカタログを書き出しました: {path}", f"Exported original tool catalog: {path}")
            _set_status(context, message)
            _report(self, {"INFO"}, message)
            status_runtime.finish_operation(token, self.bl_idname, message)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("JSON書き出しに失敗しました", f"Failed to export JSON: {exc}"))


class SCOMP_OT_apply_precision_settings(bpy.types.Operator):
    bl_idname = "smart_composite.apply_precision_settings"
    bl_label = t("シーン精度を適用", "Apply Scene Precision")
    bl_description = build_tooltip("apply_precision")
    bl_options = {"UNDO"}

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        settings = get_settings(context)
        try:
            with transaction.mutation_transaction(self.bl_idname) as active:
                with _preserve_transforms(context):
                    result = _quality_module().apply_scene_precision(context, settings)
                active.commit()
            changed = len(result.get("changed", []))
            skipped = len(result.get("skipped", []))
            message = t(f"シーン精度を適用しました: {changed}件、未対応{skipped}件。", f"Applied scene precision: {changed} item(s), skipped {skipped}.")
            _set_status(context, message)
            _report(self, {"INFO"}, message)
            status_runtime.finish_operation(token, self.bl_idname, message)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("シーン精度の適用に失敗しました", f"Failed to apply scene precision: {exc}"))


class SCOMP_OT_export_quality_report(bpy.types.Operator):
    bl_idname = "smart_composite.export_quality_report"
    bl_label = t("品質レポートを書き出し", "Export Quality Report")
    bl_description = build_tooltip("quality_report")
    bl_options = set()
    _sms_no_undo = True

    filename: StringProperty(
        name=t("ファイル名", "File Name"),
        description=t("書き出す品質診断JSONファイル名です。", "Name of the quality diagnostic JSON file to export."),
        default="smart_composite_suite_quality_report.json",
    )  # type: ignore

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        settings = get_settings(context)
        base = _resolve_output_directory(settings)
        try:
            os.makedirs(base, exist_ok=True)
            filename = _safe_filename(getattr(self, "filename", "smart_composite_suite_quality_report.json"), "smart_composite_suite_quality_report.json")
            path = os.path.join(base, filename)
            payload = _quality_module().quality_report(context, settings)
            payload["exported_at"] = datetime.now().isoformat(timespec="seconds")
            try:
                from .properties import settings_to_dict
                payload["n_panel_settings"] = settings_to_dict(settings)
            except Exception:
                pass
            storage.atomic_write_json(path, payload, indent=2, ensure_ascii=False, sort_keys=False)
            message = t(f"品質レポートを書き出しました: {path}", f"Exported quality report: {path}")
            _set_status(context, message)
            _refresh_enabled_quality_status(context)
            _report(self, {"INFO"}, message)
            status_runtime.finish_operation(token, self.bl_idname, message)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("品質レポート書き出しに失敗しました", f"Failed to export quality report: {exc}"))


class SCOMP_OT_save_preferences(bpy.types.Operator):
    bl_idname = "smart_composite.save_preferences"
    bl_label = t("プリファレンスを保存", "Save Preferences")
    bl_description = build_tooltip("save_preferences")
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        settings = get_settings(context)
        if settings is None:
            return _cancel(self, context, token, t("SCS設定が見つかりません。", "SCS settings were not found."))
        try:
            from .properties import n_panel_settings_path, save_n_panel_settings
            state_save_enabled = bool(getattr(settings, "n_panel_state_save", True))
            if state_save_enabled and not save_n_panel_settings(context, force=True):
                return _failure(self, context, token, t("Nパネル設定を保存できませんでした。", "Could not save N-panel settings."))
            try:
                bpy.ops.wm.save_userpref()
            except Exception:
                pass
            if state_save_enabled:
                settings_path = str(n_panel_settings_path(create=False))
                message = t(
                    f"Nパネル設定を外部設定ファイルへ保存しました: {settings_path}",
                    f"Saved N-panel settings to the external settings file: {settings_path}",
                )
            else:
                message = t(
                    "Nパネル状態保存は無効です。SCS設定JSONは変更せず、Blenderプリファレンスだけを保存しました。",
                    "N-panel State Save is disabled. The SCS settings JSON was unchanged; only Blender preferences were saved.",
                )
            _set_status(context, message)
            _report(self, {"INFO"}, message)
            status_runtime.finish_operation(token, self.bl_idname, message)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("Nパネル設定の保存に失敗しました", f"Failed to save N-panel settings: {exc}"))


class SCOMP_OT_optimize_ui_visibility(bpy.types.Operator):
    bl_idname = "smart_composite.optimize_ui_visibility"
    bl_label = t("UI視認性を最適化", "Optimize UI Visibility")
    bl_description = t(
        "Apexランチャーのアイコンを枠無し・大表示に寄せ、Nパネル内で図形が見えやすいUI設定へ一括調整します。",
        "Adjusts the Apex launcher toward frameless, large icon-first settings so symbols are easier to see inside the N-panel.",
    )
    bl_options = {"UNDO"}

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        settings = get_settings(context)
        if settings is None:
            return _cancel(self, context, token, t("SCS設定が見つかりません。", "SCS settings were not found."))
        changes = {
            "ui_launcher_style": "HERO", "launcher_columns": 2,
            "large_icon_scale": 6.8, "hero_icon_scale": 8.4,
            "reference_preview_scale": 5.6, "reference_columns": 1,
            "workflow_guidance_level": "GUIDED", "auto_optimize_ui_visibility": True,
            "show_reference_previews": True,
        }
        try:
            with transaction.mutation_transaction(self.bl_idname) as active:
                changed = 0
                with batch_settings_update(context):
                    for name, value in changes.items():
                        if hasattr(settings, name):
                            transaction.set_attr(settings, name, value)
                            changed += 1
                active.commit()
            message = t(f"UI視認性を最適化しました: {changed}項目。", f"Optimized UI visibility: {changed} item(s).")
            _set_status(context, message)
            _report(self, {"INFO"}, message)
            status_runtime.finish_operation(token, self.bl_idname, message)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("UI視認性の最適化に失敗しました", f"Failed to optimize UI visibility: {exc}"))


class SCOMP_OT_open_compositor_workspace(bpy.types.Operator):
    bl_idname = "smart_composite.open_compositor_workspace"
    bl_label = t("コンポジターへ移動", "Go to Compositor")
    bl_description = t("現在の画面を可能な範囲でコンポジター作業に適した状態へ切り替えます。既存ワークスペースは削除しません。", "Switches the current screen toward a compositor-friendly state where possible. It does not delete existing workspaces.")
    bl_options = {"UNDO"}

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        try:
            with transaction.mutation_transaction(self.bl_idname) as active:
                area = getattr(context, "area", None)
                if area is not None and hasattr(area, "type"):
                    transaction.set_attr(area, "type", "NODE_EDITOR")
                space = getattr(getattr(area, "spaces", None), "active", None) if area is not None else getattr(context, "space_data", None)
                if space is not None and hasattr(space, "tree_type"):
                    transaction.set_attr(space, "tree_type", "CompositorNodeTree")
                _apply_enabled_event_guards(context, include_quality=False)
                _builders_module().enable_compositor(context)
                active.commit()
            message = t("コンポジター表示を準備しました。", "Prepared compositor view.")
            _set_status(context, message)
            _report(self, {"INFO"}, message)
            status_runtime.finish_operation(token, self.bl_idname, message)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("コンポジター表示の準備に失敗しました", f"Failed to prepare the compositor view: {exc}"))


class SCOMP_OT_open_reference_image(bpy.types.Operator):
    bl_idname = "smart_composite.open_reference_image"
    bl_label = t("ビジュアルリファレンスを開く", "Open Visual Reference")
    bl_description = t(
        "SCS独自の工程リファレンスPNGを開きます。画像自体には固定言語の説明を入れず、UI側のラベルとツールチップはBlender本体の言語設定に追従します。",
        "Opens an SCS-original workflow reference PNG. The image avoids fixed-language text; UI labels and tooltips follow Blender's language setting.",
    )
    bl_options = {"UNDO"}

    reference_id: StringProperty(
        name=t("リファレンスID", "Reference ID"),
        description=t("開くSCS独自画像リファレンスのIDです。", "ID of the SCS-original visual reference to open."),
        default="reference_master_flow",
    )  # type: ignore

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        try:
            from . import visual_assets
            path = visual_assets.reference_path(getattr(self, "reference_id", "reference_master_flow"))
        except Exception as exc:
            return _failure(self, context, token, t("リファレンス画像の解決に失敗しました", f"Failed to resolve reference image: {exc}"))
        if not path.exists():
            return _cancel(self, context, token, t(f"リファレンス画像が見つかりません: {path.name}", f"Reference image not found: {path.name}"))
        try:
            with transaction.mutation_transaction(self.bl_idname) as active:
                before = {id(image) for image in tuple(getattr(bpy.data, "images", ()) or ())}
                image = bpy.data.images.load(str(path), check_existing=True)
                is_new = id(image) not in before
                if is_new:
                    transaction.record_collection_created(bpy.data.images, image)
                    node_utils = _node_utils_module()
                    node_utils.mark_owned_image(image, getattr(context, "scene", None))
                    transaction.set_attr(image, "name", f"SCS Reference - {path.stem}")
                    if hasattr(image, "use_fake_user"):
                        transaction.set_attr(image, "use_fake_user", False)
                area = getattr(context, "area", None)
                if area is not None and str(getattr(area, "type", "")) == "IMAGE_EDITOR":
                    for space in tuple(getattr(area, "spaces", ()) or ()):
                        if str(getattr(space, "type", "")) == "IMAGE_EDITOR" and hasattr(space, "image"):
                            transaction.set_attr(space, "image", image)
                            break
                active.commit()
            message = t(f"リファレンス画像を読み込みました: {path.name}", f"Loaded reference image: {path.name}")
            _set_status(context, message)
            _report(self, {"INFO"}, message)
            status_runtime.finish_operation(token, self.bl_idname, message)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("リファレンス画像を開けませんでした", f"Could not open reference image: {exc}"))


class SCOMP_OT_toggle_ui_section(bpy.types.Operator):
    bl_idname = "smart_composite.toggle_ui_section"
    bl_label = t("セクション開閉", "Toggle Section")
    bl_description = t(
        "Smart CompositeのNパネル内セクションを開閉します。閉じても設定値や有効状態は変更されません。",
        "Expand or collapse a Smart Composite N-panel section. Collapsing does not change settings or enabled states.",
    )
    bl_options = {"INTERNAL"}
    _sms_no_undo = True

    section_key: StringProperty(
        name=t("セクションID", "Section ID"),
        description=t("開閉するSCSセクションの設定プロパティ名です。", "Settings property name of the SCS section to toggle."),
        default="", options={"SKIP_SAVE"},
    )  # type: ignore
    label: StringProperty(
        name=t("セクション名", "Section Label"),
        description=t("開閉するセクションの表示名です。", "Display label of the section to toggle."),
        default="", options={"SKIP_SAVE"},
    )  # type: ignore

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, "label", "") or getattr(properties, "section_key", "") or "").strip()
        return t(
            f"{label or 'Smart Composite'} セクションを開閉します。閉じても設定値や機能の有効状態は保持されます。",
            f"Expand or collapse the {label or 'Smart Composite'} section. Collapsing keeps settings and enabled states unchanged.",
            get_settings(context),
        )

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        key = str(getattr(self, "section_key", "") or "").strip()
        settings = get_settings(context)
        if (settings is None
                or not (key == "show_always_on_toggles" or key.startswith("show_section_"))
                or not isinstance(getattr(settings, key, None), bool)):
            return _cancel(self, context, token, t("開閉対象のセクションが見つかりません。", "The target section was not found."))
        try:
            with transaction.mutation_transaction(self.bl_idname) as active:
                transaction.set_attr(settings, key, not bool(getattr(settings, key)))
                active.commit()
            status_runtime.finish_operation(token, self.bl_idname, key)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("セクションを開閉できませんでした", f"Could not toggle the section: {exc}"))


class SCOMP_OT_show_tool_help(bpy.types.Operator):
    bl_idname = "smart_composite.show_tool_help"
    bl_label = t("ヘルプ", "Help")
    bl_description = t(
        "選択したSmart Compositeツールグループの詳細ヘルプを表示します。ヘルプ本文はクリック時だけ別ファイルから読み込みます。",
        "Displays detailed help for the selected Smart Composite tool group. The help body is loaded from a separate file only when clicked.",
    )
    bl_options = set()
    _sms_no_undo = True

    alias: StringProperty(
        name=t("ヘルプID", "Help ID"),
        description=t("表示するSCSヘルプ項目のIDです。", "ID of the SCS help topic to display."),
        default="root", options={"SKIP_SAVE"},
    )  # type: ignore

    @classmethod
    def description(cls, context, properties):
        settings = get_settings(context)
        try:
            from . import help as help_module
            name = help_module._topic_label(getattr(properties, "alias", ""), settings)
        except Exception:
            name = "Smart Composite"
        return t(f"「{name}」の解説を開きます。", f"Open the help for {name}.", settings)

    def execute(self, context):
        token = status_runtime.begin_operation(self.bl_idname, "Smart Composite Suite")
        key = str(getattr(self, "alias", "") or "root").strip() or "root"
        try:
            from . import help as help_module
            if not help_module.show_tool_help(context, key):
                return _cancel(self, context, token, t("このヘルプ項目は見つかりません。", "This help topic was not found.", get_settings(context)))
            status_runtime.finish_operation(token, self.bl_idname, key)
            return {"FINISHED"}
        except Exception as exc:
            return _failure(self, context, token, t("ヘルプを開けませんでした", f"Failed to open help: {exc}", get_settings(context)))


OPERATOR_CLASSES = (
    SCOMP_OT_toggle_ui_section,
    SCOMP_OT_enable_compositor,
    SCOMP_OT_enable_render_passes,
    SCOMP_OT_build_master_workspace,
    SCOMP_OT_add_preset,
    SCOMP_OT_clear_scs_nodes,
    SCOMP_OT_audit_scene,
    SCOMP_OT_export_manifest,
    SCOMP_OT_apply_precision_settings,
    SCOMP_OT_export_quality_report,
    SCOMP_OT_save_preferences,
    SCOMP_OT_optimize_ui_visibility,
    SCOMP_OT_open_compositor_workspace,
    SCOMP_OT_open_reference_image,
    SCOMP_OT_show_tool_help,
)
