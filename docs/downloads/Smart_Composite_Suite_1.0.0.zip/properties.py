# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from contextlib import contextmanager
import hashlib
import inspect
import json
from pathlib import Path
from typing import Any

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty

from . import storage
from .catalog import CATEGORIES, preset_ids, source_items
from .translation import locale_mode, t, tooltip

_CATEGORY_LABELS = {
    "3D / Depth": ("3D / 深度", "3D / Depth"),
    "AOV / Channel": ("AOV / チャンネル", "AOV / Channel"),
    "AI / Bridge": ("AI / ブリッジ", "AI / Bridge"),
    "AI / ML": ("AI / 機械学習", "AI / ML"),
    "Blur": ("ブラー", "Blur"),
    "Blur / Focus": ("ブラー / フォーカス", "Blur / Focus"),
    "Blur / Motion": ("ブラー / モーション", "Blur / Motion"),
    "Color": ("カラー", "Color"),
    "Color / Grade": ("カラー / グレード", "Color / Grade"),
    "Color / Look": ("カラー / ルック", "Color / Look"),
    "Composite": ("合成", "Composite"),
    "Depth / 3D": ("深度 / 3D", "Depth / 3D"),
    "Depth / Geometry": ("深度 / ジオメトリ", "Depth / Geometry"),
    "Distort / Stylize": ("歪み / スタイライズ", "Distort / Stylize"),
    "Distortion / Stylize": ("歪み / スタイライズ", "Distortion / Stylize"),
    "Key / Matte": ("キー / マット", "Key / Matte"),
    "Lens": ("レンズ", "Lens"),
    "Lens / Light": ("レンズ / 光", "Lens / Light"),
    "Light / Glow / Flare": ("光 / グロー / フレア", "Light / Glow / Flare"),
    "Light / Lens": ("光 / レンズ", "Light / Lens"),
    "Matte": ("マット", "Matte"),
    "Matte / Key": ("マット / キー", "Matte / Key"),
    "Motion / Temporal": ("モーション / 時間", "Motion / Temporal"),
    "Pipeline": ("パイプライン", "Pipeline"),
    "Pipeline / Delivery": ("パイプライン / 納品", "Pipeline / Delivery"),
    "Precision": ("精度", "Precision"),
    "Precision / QC": ("精度 / QC", "Precision / QC"),
    "Restoration": ("復元", "Restoration"),
    "Temporal": ("時間", "Temporal"),
    "Time / Retiming": ("時間 / リタイミング", "Time / Retiming"),
    "UI / Operation": ("UI / 操作", "UI / Operation"),
    "UI / Workflow": ("UI / ワークフロー", "UI / Workflow"),
    "Utility": ("ユーティリティ", "Utility"),
}
_ENUM_ITEM_CACHE_KINDS = frozenset({"category", "source", "preset"})
_ENUM_ITEM_CACHE_LANGS = frozenset({"JA", "EN"})
_ENUM_ITEMS_CACHE_MAX = len(_ENUM_ITEM_CACHE_KINDS) * len(_ENUM_ITEM_CACHE_LANGS)
_ENUM_ITEMS_CACHE: dict[tuple[str, str], tuple[tuple[str, str, str], ...]] = globals().get("_ENUM_ITEMS_CACHE") if isinstance(globals().get("_ENUM_ITEMS_CACHE"), dict) else {}
for _cache_key in tuple(_ENUM_ITEMS_CACHE):
    try:
        _kind, _lang = str(_cache_key[0]), str(_cache_key[1])
    except Exception:
        _ENUM_ITEMS_CACHE.pop(_cache_key, None)
        continue
    if _kind not in _ENUM_ITEM_CACHE_KINDS or _lang not in _ENUM_ITEM_CACHE_LANGS:
        _ENUM_ITEMS_CACHE.pop(_cache_key, None)
while len(_ENUM_ITEMS_CACHE) > _ENUM_ITEMS_CACHE_MAX:
    _ENUM_ITEMS_CACHE.pop(next(iter(_ENUM_ITEMS_CACHE)), None)

SETTINGS_SCHEMA_VERSION = 5
N_PANEL_SETTINGS_FILENAME = "Smart_Composite_Suite.json"
_PERSISTENCE_APPLYING = bool(globals().get("_PERSISTENCE_APPLYING", False))
_PERSISTENCE_APPLIED_ONCE = bool(globals().get("_PERSISTENCE_APPLIED_ONCE", False))
_PERSISTENCE_DIRTY = bool(globals().get("_PERSISTENCE_DIRTY", False))
_PENDING_SETTINGS_SNAPSHOT: dict[str, Any] | None = globals().get("_PENDING_SETTINGS_SNAPSHOT")
_PENDING_SETTINGS_KEY = str(globals().get("_PENDING_SETTINGS_KEY", "") or "")
_LAST_WRITTEN_SETTINGS_KEY = str(globals().get("_LAST_WRITTEN_SETTINGS_KEY", "") or "")
# Exact persistence-resource records survive importlib.reload in the same module
# dictionary. Older identities are retained only long enough to release
# those exact callbacks/owner objects; no name-based handler or msgbus scan occurs.
_LEGACY_SCENE_MSGBUS_OWNER = globals().get("_SCENE_MSGBUS_OWNER")
_LEGACY_SCENE_MSGBUS_OWNED = bool(globals().get("_SCENE_MSGBUS_OWNED", False))
_LEGACY_PERSISTENCE_HANDLER_OWNERS = (
    globals().get("_PERSISTENCE_HANDLER_OWNERS")
    if isinstance(globals().get("_PERSISTENCE_HANDLER_OWNERS"), set)
    else set()
)
_PERSISTENCE_HANDLER_RECORDS: list[dict[str, Any]] = (
    globals().get("_PERSISTENCE_HANDLER_RECORDS")
    if isinstance(globals().get("_PERSISTENCE_HANDLER_RECORDS"), list)
    else []
)
_SCENE_MSGBUS_RECORDS: list[dict[str, Any]] = (
    globals().get("_SCENE_MSGBUS_RECORDS")
    if isinstance(globals().get("_SCENE_MSGBUS_RECORDS"), list)
    else []
)
_SCENE_MSGBUS_OWNER = None
_SCENE_MSGBUS_OWNED = False
_PERSISTENCE_BATCH_DEPTH = int(globals().get("_PERSISTENCE_BATCH_DEPTH", 0) or 0)
_PERSISTENCE_BATCH_DIRTY = bool(globals().get("_PERSISTENCE_BATCH_DIRTY", False))
_PERSISTENCE_BATCH_CONTEXT = globals().get("_PERSISTENCE_BATCH_CONTEXT")
_PERSISTENCE_BATCH_SETTINGS = globals().get("_PERSISTENCE_BATCH_SETTINGS")
_PERSISTENCE_BATCH_OFF_CAPABILITY = None
_RESTORE_BARRIER_DEPTH = int(globals().get("_RESTORE_BARRIER_DEPTH", 0) or 0)
_LOCAL_MUTATION_SERIAL = int(globals().get("_LOCAL_MUTATION_SERIAL", 0) or 0)
_DEFERRED_RESTORE_CALLBACK = globals().get("_DEFERRED_RESTORE_CALLBACK")
_DEFERRED_RESTORE_ATTEMPTS = int(globals().get("_DEFERRED_RESTORE_ATTEMPTS", 0) or 0)
_DEFERRED_RESTORE_TOKEN = str(globals().get("_DEFERRED_RESTORE_TOKEN", "") or "")
_DEFERRED_RESTORE_GENERATION = int(globals().get("_DEFERRED_RESTORE_GENERATION", 0) or 0)
_DEFERRED_RESTORE_SERIAL = int(globals().get("_DEFERRED_RESTORE_SERIAL", 0) or 0)
_DEFERRED_RESTORE_MAX_ATTEMPTS = 8
_TRANSIENT_SETTING_NAMES = frozenset({"last_message"})
# Persistence authority is deliberately independent of lazy RNA and payload
# bytes. A new source generation is cold until one complete restore (including
# the missing-file/default case) establishes the exact live settings owner.
_PERSISTENCE_AUTHORITY_PHASE = "COLD"
_LIVE_STATE_SAVE_ENABLED: bool | None = None
# Stable RNA identity record. ``reference`` is retained only for lifetime
# validation; authority comparisons use the underlying pointers plus exact
# owner generation and Scene association, never Python wrapper identity.
_LIVE_SETTINGS_IDENTITY: dict[str, Any] | None = None
_OFF_COMMIT_CAPABILITY: dict[str, Any] | None = None


def _release_transient_persistence_refs() -> None:
    global _PERSISTENCE_APPLYING, _PERSISTENCE_BATCH_DEPTH, _PERSISTENCE_BATCH_DIRTY
    global _PERSISTENCE_BATCH_CONTEXT, _PERSISTENCE_BATCH_SETTINGS
    global _PERSISTENCE_BATCH_OFF_CAPABILITY
    global _RESTORE_BARRIER_DEPTH
    global _PERSISTENCE_AUTHORITY_PHASE, _LIVE_STATE_SAVE_ENABLED
    global _LIVE_SETTINGS_IDENTITY, _OFF_COMMIT_CAPABILITY
    _PERSISTENCE_APPLYING = False
    _RESTORE_BARRIER_DEPTH = 0
    _PERSISTENCE_BATCH_DEPTH = 0
    _PERSISTENCE_BATCH_DIRTY = False
    _PERSISTENCE_BATCH_CONTEXT = None
    _PERSISTENCE_BATCH_SETTINGS = None
    _PERSISTENCE_BATCH_OFF_CAPABILITY = None
    _PERSISTENCE_AUTHORITY_PHASE = "COLD"
    _LIVE_STATE_SAVE_ENABLED = None
    _LIVE_SETTINGS_IDENTITY = None
    _OFF_COMMIT_CAPABILITY = None


def _authority_barrier_allows_ordinary() -> bool:
    """Pure first barrier: no context, RNA, path, allocation, or filesystem."""
    return bool(
        _PERSISTENCE_AUTHORITY_PHASE == "READY"
        and _RESTORE_BARRIER_DEPTH == 0
        and not _PERSISTENCE_APPLYING
        and _LIVE_STATE_SAVE_ENABLED is True
        and _LIVE_SETTINGS_IDENTITY is not None
    )


def _safe_rna_pointer(value) -> int | None:
    """Return one live bpy_struct pointer, failing closed on removed RNA."""
    try:
        pointer = int(value.as_pointer())
        return pointer if pointer > 0 else None
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _settings_identity_snapshot(settings) -> dict[str, Any] | None:
    """Validate settings membership, id_data Scene, and Scene binding."""
    try:
        if not isinstance(settings, SCS_Settings):
            return None
        scene = settings.id_data
        if not isinstance(scene, bpy.types.Scene):
            return None
        settings_pointer = _safe_rna_pointer(settings)
        scene_pointer = _safe_rna_pointer(scene)
        if settings_pointer is None or scene_pointer is None:
            return None
        bound = getattr(scene, SCENE_PROPERTY_NAME, None)
        if _safe_rna_pointer(bound) != settings_pointer:
            return None
        token, generation = _current_lifecycle_identity()
        if (
            not token
            or token != _PROPERTY_OWNER_TOKEN
            or int(generation) != int(_PROPERTY_GENERATION)
            or generation <= 0
            or _PROPERTY_PHASE != "READY"
        ):
            return None
        return {
            "settings_pointer": settings_pointer,
            "scene_pointer": scene_pointer,
            "owner_token": token,
            "generation": int(generation),
            "reference": settings,
        }
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _same_settings_rna_identity(left: dict[str, Any] | None, right: dict[str, Any] | None) -> bool:
    if not isinstance(left, dict) or not isinstance(right, dict):
        return False
    return bool(
        int(left.get("settings_pointer", 0)) > 0
        and int(left.get("settings_pointer", 0)) == int(right.get("settings_pointer", -1))
        and int(left.get("scene_pointer", 0)) > 0
        and int(left.get("scene_pointer", 0)) == int(right.get("scene_pointer", -1))
        and str(left.get("owner_token", "")) == str(right.get("owner_token", ""))
        and int(left.get("generation", -1)) == int(right.get("generation", -2))
    )


def _live_authority_identity_valid() -> bool:
    record = _LIVE_SETTINGS_IDENTITY
    if not isinstance(record, dict):
        return False
    current = _settings_identity_snapshot(record.get("reference"))
    if not _same_settings_rna_identity(current, record):
        return False
    try:
        active_scene = getattr(getattr(bpy, "context", None), "scene", None)
        return _safe_rna_pointer(active_scene) == int(record.get("scene_pointer", -1))
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _settings_matches_live_identity(settings) -> bool:
    if not _live_authority_identity_valid():
        return False
    return _same_settings_rna_identity(_settings_identity_snapshot(settings), _LIVE_SETTINGS_IDENTITY)


def _settings_identity_key(settings) -> str | None:
    identity = _settings_identity_snapshot(settings)
    if identity is None:
        return None
    return f"{identity['settings_pointer']}:{identity['scene_pointer']}:{identity['owner_token']}:{identity['generation']}"


def _ordinary_writer_authorized() -> bool:
    # Cold/restore/OFF short-circuit before touching the retained RNA reference.
    return bool(_authority_barrier_allows_ordinary() and _live_authority_identity_valid())


def _owner_identity_matches_capability(record: dict[str, Any]) -> bool:
    try:
        token, generation = _current_lifecycle_identity()
        live = _LIVE_SETTINGS_IDENTITY
        return bool(
            token
            and token == record.get("owner_token")
            and int(generation) == int(record.get("generation", -1))
            and _PROPERTY_PHASE == "READY"
            and _live_authority_identity_valid()
            and isinstance(live, dict)
            and int(live.get("settings_pointer", 0)) == int(record.get("settings_pointer", -1))
            and int(live.get("scene_pointer", 0)) == int(record.get("scene_pointer", -1))
        )
    except Exception:
        return False


def _off_commit_capability_valid(capability) -> bool:
    record = _OFF_COMMIT_CAPABILITY
    if not isinstance(record, dict) or capability is not record.get("token"):
        return False
    if bool(record.get("used")) or _PERSISTENCE_AUTHORITY_PHASE != "READY":
        return False
    if _RESTORE_BARRIER_DEPTH or _PERSISTENCE_APPLYING:
        return False
    if _LIVE_STATE_SAVE_ENABLED is not False or not _owner_identity_matches_capability(record):
        return False
    return True


def _consume_off_commit_capability(capability) -> bool:
    """Consume the sole real ON->OFF event permit before any writer effect."""
    if not _off_commit_capability_valid(capability):
        return False
    _OFF_COMMIT_CAPABILITY["used"] = True
    return True


def _writer_route_authorized(off_capability=None) -> bool:
    if off_capability is None:
        return _ordinary_writer_authorized()
    return _off_commit_capability_valid(off_capability)


def _retire_off_commit_capability(capability=None) -> None:
    global _OFF_COMMIT_CAPABILITY
    record = _OFF_COMMIT_CAPABILITY
    if capability is None or (isinstance(record, dict) and capability is record.get("token")):
        _OFF_COMMIT_CAPABILITY = None


def _issue_off_commit_capability(settings):
    """Authenticate one exact live owner and one genuine READY ON->OFF edge."""
    global _LIVE_STATE_SAVE_ENABLED, _OFF_COMMIT_CAPABILITY
    if not _ordinary_writer_authorized() or not _settings_matches_live_identity(settings):
        return None
    try:
        if bool(getattr(settings, "n_panel_state_save", True)):
            return None
    except Exception:
        return None
    token, generation = _current_lifecycle_identity()
    if not token or generation <= 0 or _PROPERTY_PHASE != "READY":
        return None
    capability = object()
    _LIVE_STATE_SAVE_ENABLED = False
    _OFF_COMMIT_CAPABILITY = {
        "token": capability,
        "owner_token": token,
        "generation": int(generation),
        "settings_pointer": int(_LIVE_SETTINGS_IDENTITY["settings_pointer"]),
        "scene_pointer": int(_LIVE_SETTINGS_IDENTITY["scene_pointer"]),
        "used": False,
    }
    return capability


def _authorize_live_on_transition(settings) -> bool:
    global _LIVE_STATE_SAVE_ENABLED
    if (
        _PERSISTENCE_AUTHORITY_PHASE != "READY"
        or _RESTORE_BARRIER_DEPTH
        or _PERSISTENCE_APPLYING
        or not _settings_matches_live_identity(settings)
        or _LIVE_STATE_SAVE_ENABLED is not False
    ):
        return False
    try:
        enabled = bool(getattr(settings, "n_panel_state_save", False))
    except Exception:
        return False
    token, generation = _current_lifecycle_identity()
    if not enabled or not token or generation <= 0 or _PROPERTY_PHASE != "READY":
        return False
    _retire_off_commit_capability()
    _LIVE_STATE_SAVE_ENABLED = True
    return True


def _establish_ready_authority(settings) -> bool:
    global _PERSISTENCE_AUTHORITY_PHASE, _LIVE_STATE_SAVE_ENABLED, _LIVE_SETTINGS_IDENTITY
    if settings is None or _RESTORE_BARRIER_DEPTH or _PERSISTENCE_APPLYING:
        return False
    token, generation = _current_lifecycle_identity()
    if not token or generation <= 0 or _PROPERTY_PHASE != "READY":
        return False
    try:
        enabled = bool(getattr(settings, "n_panel_state_save", True))
    except Exception:
        return False
    identity = _settings_identity_snapshot(settings)
    if identity is None:
        return False
    _retire_off_commit_capability()
    _LIVE_SETTINGS_IDENTITY = identity
    _LIVE_STATE_SAVE_ENABLED = enabled
    _PERSISTENCE_AUTHORITY_PHASE = "READY"
    return True


def _enter_cold_authority() -> None:
    global _PERSISTENCE_AUTHORITY_PHASE, _LIVE_STATE_SAVE_ENABLED, _LIVE_SETTINGS_IDENTITY
    _retire_off_commit_capability()
    _PERSISTENCE_AUTHORITY_PHASE = "COLD"
    _LIVE_STATE_SAVE_ENABLED = None
    _LIVE_SETTINGS_IDENTITY = None


def _default_output_path() -> str:
    try:
        return str(storage.default_export_dir(create=False))
    except Exception:
        return ""


def _settings_auto_save_enabled(settings=None) -> bool:
    try:
        if settings is None:
            settings = get_settings()
        return bool(getattr(settings, "n_panel_state_save", True))
    except Exception:
        return False


def _note_local_mutation() -> None:
    global _LOCAL_MUTATION_SERIAL
    _LOCAL_MUTATION_SERIAL += 1


def _capture_settings_snapshot(settings=None) -> dict[str, Any]:
    try:
        return dict(settings_to_dict(settings))
    except Exception:
        return {}


def _mark_persistence_dirty(settings=None) -> None:
    global _PERSISTENCE_DIRTY, _PENDING_SETTINGS_SNAPSHOT, _PENDING_SETTINGS_KEY
    _PERSISTENCE_DIRTY = True
    try:
        snapshot = _capture_settings_snapshot(settings)
        snapshot_key = json.dumps(snapshot, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        if snapshot_key != _PENDING_SETTINGS_KEY:
            _PENDING_SETTINGS_SNAPSHOT = snapshot
            _PENDING_SETTINGS_KEY = snapshot_key
    except Exception:
        _PENDING_SETTINGS_SNAPSHOT = None
        _PENDING_SETTINGS_KEY = ""


def _persist_after_mutation(
    context,
    settings,
    *,
    force: bool = False,
    off_capability=None,
) -> None:
    if off_capability is None and not _ordinary_writer_authorized():
        return
    try:
        if not save_n_panel_settings(context, force=force, _off_capability=off_capability):
            raise RuntimeError("Smart Composite settings persistence failed")
    finally:
        if off_capability is not None:
            _retire_off_commit_capability(off_capability)


def _schedule_persistence(
    context,
    settings,
    *,
    force: bool = False,
    off_capability=None,
) -> None:
    if not _writer_route_authorized(off_capability):
        return
    settings_key = _settings_identity_key(settings)
    if settings_key is None or not _settings_matches_live_identity(settings):
        return
    try:
        from . import transaction
        active = transaction.current()
    except Exception:
        active = None
    if active is None:
        _persist_after_mutation(
            context,
            settings,
            force=force,
            off_capability=off_capability,
        )
        return
    key = f"settings-persist:{settings_key}:{int(bool(force))}:{id(off_capability)}"
    if active.mark_once(key):
        active.add_commit(
            lambda context=context, settings=settings, force=force, off_capability=off_capability:
            _persist_after_mutation(
                context,
                settings,
                force=force,
                off_capability=off_capability,
            )
        )


def _persist_setting_update(self=None, context=None):
    global _PERSISTENCE_BATCH_DIRTY, _PERSISTENCE_BATCH_CONTEXT, _PERSISTENCE_BATCH_SETTINGS
    if _PERSISTENCE_APPLYING:
        return
    if not _ordinary_writer_authorized():
        return
    _note_local_mutation()
    settings = self or get_settings(context)
    if _PERSISTENCE_BATCH_DEPTH > 0:
        _PERSISTENCE_BATCH_DIRTY = True
        if context is not None:
            _PERSISTENCE_BATCH_CONTEXT = context
        if settings is not None:
            _PERSISTENCE_BATCH_SETTINGS = settings
        return
    if settings is None:
        return
    try:
        _schedule_persistence(context, settings, force=False)
    except Exception:
        _mark_persistence_dirty(settings)
        raise


def _update_n_panel_state_save(self=None, context=None):
    global _PERSISTENCE_BATCH_DIRTY, _PERSISTENCE_BATCH_CONTEXT, _PERSISTENCE_BATCH_SETTINGS
    global _PERSISTENCE_BATCH_OFF_CAPABILITY
    if _PERSISTENCE_APPLYING:
        return
    if _PERSISTENCE_AUTHORITY_PHASE != "READY" or _RESTORE_BARRIER_DEPTH:
        return
    _note_local_mutation()
    settings = self or get_settings(context)
    if settings is None:
        return
    enabled = bool(getattr(settings, "n_panel_state_save", True))
    off_capability = None
    if enabled:
        if _LIVE_STATE_SAVE_ENABLED is False and not _authorize_live_on_transition(settings):
            return
        if not _ordinary_writer_authorized():
            return
    else:
        off_capability = _issue_off_commit_capability(settings)
        if off_capability is None:
            return
    if _PERSISTENCE_BATCH_DEPTH > 0:
        _PERSISTENCE_BATCH_DIRTY = True
        if context is not None:
            _PERSISTENCE_BATCH_CONTEXT = context
        if settings is not None:
            _PERSISTENCE_BATCH_SETTINGS = settings
            if off_capability is not None:
                _PERSISTENCE_BATCH_OFF_CAPABILITY = off_capability
        return
    try:
        if off_capability is not None:
            # The sole OFF commit is an immediate public-event write. Do not
            # leave its one-use authority captured by an outer transaction.
            _persist_after_mutation(
                context, settings, force=True, off_capability=off_capability
            )
        else:
            _schedule_persistence(context, settings, force=True)
        if not _sync_persistence_hooks_for_settings(settings):
            raise RuntimeError("PERSISTENCE_RESOURCE_TRANSITION_FAILED")
    except Exception:
        if off_capability is not None:
            _sync_persistence_hooks_for_settings(settings)
        _mark_persistence_dirty(settings)
        raise


@contextmanager
def batch_settings_update(context=None):
    """Coalesce RNA setting updates into one transaction-aware JSON write."""
    global _PERSISTENCE_BATCH_DEPTH, _PERSISTENCE_BATCH_DIRTY
    global _PERSISTENCE_BATCH_CONTEXT, _PERSISTENCE_BATCH_SETTINGS
    global _PERSISTENCE_BATCH_OFF_CAPABILITY

    outermost = _PERSISTENCE_BATCH_DEPTH == 0
    if outermost:
        _PERSISTENCE_BATCH_DIRTY = False
        _PERSISTENCE_BATCH_CONTEXT = context
        _PERSISTENCE_BATCH_SETTINGS = get_settings(context)
        _PERSISTENCE_BATCH_OFF_CAPABILITY = None
    _PERSISTENCE_BATCH_DEPTH += 1
    try:
        yield
    finally:
        _PERSISTENCE_BATCH_DEPTH = max(0, _PERSISTENCE_BATCH_DEPTH - 1)
        if _PERSISTENCE_BATCH_DEPTH == 0:
            dirty = bool(_PERSISTENCE_BATCH_DIRTY)
            batch_context = _PERSISTENCE_BATCH_CONTEXT or context
            settings = _PERSISTENCE_BATCH_SETTINGS or get_settings(batch_context)
            off_capability = _PERSISTENCE_BATCH_OFF_CAPABILITY
            _PERSISTENCE_BATCH_DIRTY = False
            _PERSISTENCE_BATCH_CONTEXT = None
            _PERSISTENCE_BATCH_SETTINGS = None
            _PERSISTENCE_BATCH_OFF_CAPABILITY = None
            if dirty and settings is not None:
                try:
                    if off_capability is not None:
                        _persist_after_mutation(
                            batch_context, settings, force=True,
                            off_capability=off_capability,
                        )
                    else:
                        _schedule_persistence(batch_context, settings, force=False)
                    if not _sync_persistence_hooks_for_settings(settings):
                        raise RuntimeError("PERSISTENCE_RESOURCE_TRANSITION_FAILED")
                except Exception:
                    if off_capability is not None:
                        _sync_persistence_hooks_for_settings(settings)
                    _mark_persistence_dirty(settings)
                    raise


def _custom_icon_previews_allowed() -> bool:
    try:
        from . import visual_assets
        return bool(visual_assets.custom_previews_allowed())
    except Exception:
        return True


def _enum_lang(settings=None) -> str:
    try:
        return "JA" if locale_mode(settings) == "ja" else "EN"
    except Exception:
        return "EN"



def _cache_enum_items(key, rows):
    # Blender keeps references to dynamic enum strings. Store the tuple at module
    # level so callback-generated labels/descriptions are not garbage-collected.
    # The key space is fixed to 3 enum kinds x 2 languages, so this cache is
    # intrinsically bounded without evicting strings that Blender may still use.
    stable = tuple((str(identifier), str(name), str(description)) for identifier, name, description in rows)
    try:
        kind, lang = str(key[0]), str(key[1])
    except Exception:
        return stable
    cache_key = (kind, lang)
    if kind not in _ENUM_ITEM_CACHE_KINDS or lang not in _ENUM_ITEM_CACHE_LANGS:
        return stable
    _ENUM_ITEMS_CACHE[cache_key] = stable
    return stable



def _category_items(self=None, context=None):
    try:
        settings = get_settings(context)
    except Exception:
        settings = None
    lang = _enum_lang(settings)
    cache_key = ("category", lang)
    cached = _ENUM_ITEMS_CACHE.get(cache_key)
    if cached is not None:
        return cached
    rows = [("ALL", "全カテゴリ" if lang == "JA" else "All Categories", "全カテゴリを表示します。" if lang == "JA" else "Show all categories.")]
    for category in CATEGORIES:
        ja, en = _CATEGORY_LABELS.get(str(category or ""), (str(category or ""), str(category or "")))
        label = ja if lang == "JA" else en
        rows.append((category, label, label))
    return _cache_enum_items(cache_key, rows)


def _source_items(self=None, context=None):
    try:
        settings = get_settings(context)
    except Exception:
        settings = None
    lang = _enum_lang(settings)
    cache_key = ("source", lang)
    cached = _ENUM_ITEMS_CACHE.get(cache_key)
    if cached is not None:
        return cached
    try:
        rows = source_items(lang)
    except Exception:
        rows = (("ALL", "全エンジン" if lang == "JA" else "All Engines", "すべてのSCS独自エンジンを表示します。" if lang == "JA" else "Show all SCS original engines."),)
    return _cache_enum_items(cache_key, rows)


def _preset_label_pair(preset_id: str) -> tuple[str, str]:
    labels = {
        "AOV_SHUFFLE_MATRIX": ("AOVシャッフル・マトリクス", "AOV Shuffle Matrix"),
        "CRYPTOMATTE_EXTRACTOR": ("クリプトマット抽出", "Cryptomatte Extractor"),
        "FILE_OUTPUT_PIPELINE": ("マルチパス出力", "Multi-pass File Output"),
        "SMART_MERGE": ("スマートマージ", "Smart Merge"),
        "MATTE_REFINER": ("マット調整", "Matte Refiner"),
        "SLAP_COMP": ("スラップコンプ作業台", "Slap Comp Workbench"),
        "CHROMA_KEY_STUDIO": ("クロマキー・スタジオ", "Chroma Key Studio"),
        "AI_MASK_BRIDGE": ("AIマスク・ブリッジ", "AI Mask Bridge"),
        "BEAUTY_RETOUCH": ("ビューティ補正", "Beauty Retouch"),
        "BOKEH_DEPTH_BLUR": ("Z深度ボケ", "Z-Depth Bokeh Blur"),
        "VECTOR_MOTION_BLUR": ("ベクトルモーションブラー", "Vector Motion Blur"),
        "OPTICAL_DISTORT": ("光学歪み", "Optical Distort"),
        "TIME_ECHO": ("時間残像", "Time Echo"),
        "ADVANCED_GLOW": ("高品質グロー", "Advanced Glow"),
        "EDGE_RAYS": ("エッジレイズ", "Edge Rays"),
        "LENS_FLARE_BUILDER": ("レンズフレア・ビルダー", "Lens Flare Builder"),
        "COLOR_GRADE_PANEL": ("カラーグレード・パネル", "Color Grade Panel"),
        "FILM_LOOK_BUILDER": ("フィルムルック・ビルダー", "Film Look Builder"),
        "COLOR_MATCH_LOOK": ("カラーマッチ", "Color Match Look"),
        "LUT_MANAGER": ("LUTマネージャー", "LUT Manager"),
        "VIGNETTE_FINISH": ("ビネット仕上げ", "Vignette Finish"),
        "DEBAND_DENOISE_RESTORE": ("デバンド/デノイズ復元", "Deband / Denoise Restore"),
        "SHARPEN_DETAIL": ("シャープ/ディテール", "Sharpen Detail"),
        "HEAT_HAZE_DISTORT": ("陽炎歪み", "Heat Haze Distort"),
        "GLITCH_STYLIZE": ("グリッチ/デジタルダメージ", "Glitch Stylize"),
        "DEPTH_FOG_RELIGHT": ("深度フォグ/遠近", "Depth Fog / Atmosphere"),
        "NORMAL_RELIGHT": ("法線疑似リライト", "Normal Relight"),
        "HEIGHT_TO_NORMAL_PROXY": ("高さから法線", "Height to Normal"),
        "UI_ICON_LAUNCHPAD": ("大アイコンランチャー", "Large Icon Launchpad"),
        "VISUAL_REFERENCE_BOARD": ("画像リファレンスボード", "Visual Reference Board"),
        "PARTICLE_LIGHTS": ("光粒子/ノイズ生成", "Particle Lights"),
        "ASSET_SHELF_PREP": ("アセットシェルフ準備", "Asset Shelf Prep"),
        "BUILD_MASTER_WORKSPACE": ("総合作業台", "Master Workspace"),
        "PRECISION_MASTER_WORKSPACE": ("精度強化総合作業台", "Precision Master Workspace"),
        "SIGNAL_INTEGRITY_GUARD": ("信号整合性ガード", "Signal Integrity Guard"),
        "PRECISION_DIAGNOSTICS_HUB": ("精度診断ハブ", "Precision Diagnostics Hub"),
        "SURPASS_MASTER_WORKSPACE": ("凌駕精度総合作業台", "Surpass Master Workspace"),
        "PRECISION_QC_SUITE": ("精度QCツールセット", "Precision QC Toolset"),
        "MATTE_EDGE_LAB": ("マット縁精度ラボ", "Matte Edge Lab"),
        "SPECTRAL_LIGHT_LAB": ("スペクトル光学ラボ", "Spectral Light Lab"),
        "DEPTH_NORMALIZER": ("深度正規化ラボ", "Depth Normalizer"),
        "COLOR_WARPER_LAB": ("色相ワーパーラボ", "Color Warper Lab"),
        "CLEANROOM_PLUS": ("CleanRoom Plus", "CleanRoom Plus"),

        "PRECISION_QC_LAB": ("精度診断ラボ", "Precision QC Lab"),
        "HDR_HIGHLIGHT_GUARD": ("HDRハイライト保護", "HDR Highlight Guard"),
        "SUBPIXEL_MATTE_LAB": ("サブピクセルマットラボ", "Subpixel Matte Lab"),
        "OPTICAL_BLOOM_LAB": ("光学ブルームラボ", "Optical Bloom Lab"),
        "RESTORATION_LAB": ("復元精度ラボ", "Restoration Lab"),
        "DEPTH_VECTOR_AUDIT": ("深度／ベクトル診断", "Depth / Vector Audit"),
        "PRECISION_OVERDRIVE_WORKSPACE": ("精度極限作業台", "Precision Overdrive Workspace"),

        "SCS_ULTRA_LAUNCHPAD": ("SCS超精度ランチャー", "SCS Ultra Launchpad"),
        "PERCEPTUAL_FINISHING_HUB": ("知覚仕上げハブ", "Perceptual Finishing Hub"),
        "AOV_INTEGRITY_MATRIX": ("AOV整合性マトリクス", "AOV Integrity Matrix"),
        "ADAPTIVE_RESTORE_ENGINE": ("適応復元エンジン", "Adaptive Restore Engine"),
        "PHYSICAL_OPTICS_ENGINE": ("物理光学エンジン", "Physical Optics Engine"),
        "MATTE_MICROSURGERY_ENGINE": ("マット微細調整エンジン", "Matte Microsurgery Engine"),
        "APEX_COMMAND_WORKSPACE": ("Apex統合作業台", "Apex Command Workspace"),
        "AOV_DELTA_VERIFIER": ("AOV差分検証", "AOV Delta Verifier"),
        "DEEP_MATTE_FUSION_LAB": ("深層マット融合ラボ", "Deep Matte Fusion Lab"),
        "LENS_APERTURE_DESIGNER": ("レンズ絞り設計", "Lens Aperture Designer"),
        "DYNAMIC_RANGE_SCULPTOR": ("ダイナミックレンジ整形", "Dynamic Range Sculptor"),
        "PERCEPTION_MATCH_ASSISTANT": ("知覚マッチ補助", "Perception Match Assistant"),
        "ADAPTIVE_DENOISE_PROFILE_LAB": ("適応デノイズプロファイル", "Adaptive Denoise Profile Lab"),
        "MOTION_FLOW_GUARD": ("モーションフロー保護", "Motion Flow Guard"),
        "GEOMETRY_SIGNAL_BRIDGE": ("ジオメトリ信号ブリッジ", "Geometry Signal Bridge"),
        "DELIVERY_SANITY_CHECK": ("納品整合チェック", "Delivery Sanity Check"),
        "APEX_VISUAL_GUIDE_BOARD": ("Apex画像ガイドボード", "Apex Visual Guide Board"),
    }
    return labels.get(preset_id, (preset_id.replace("_", " ").title(), preset_id.replace("_", " ").title()))


def _preset_label(preset_id: str, settings=None) -> str:
    ja, en = _preset_label_pair(preset_id)
    return t(ja, en, settings)



@contextmanager
def _persistence_restore_barrier():
    """Nestable barrier that blocks every event writer during restoration."""
    global _PERSISTENCE_APPLYING, _RESTORE_BARRIER_DEPTH, _PERSISTENCE_AUTHORITY_PHASE
    previous = bool(_PERSISTENCE_APPLYING)
    previous_phase = _PERSISTENCE_AUTHORITY_PHASE
    _RESTORE_BARRIER_DEPTH += 1
    _PERSISTENCE_APPLYING = True
    _PERSISTENCE_AUTHORITY_PHASE = "RESTORING"
    try:
        yield
    finally:
        _RESTORE_BARRIER_DEPTH = max(0, _RESTORE_BARRIER_DEPTH - 1)
        _PERSISTENCE_APPLYING = True if _RESTORE_BARRIER_DEPTH else previous
        _PERSISTENCE_AUTHORITY_PHASE = "RESTORING" if _RESTORE_BARRIER_DEPTH else previous_phase


def _restore_feature_toggle(settings, prop_name: str, value: Any) -> None:
    with _persistence_restore_barrier():
        try:
            setattr(settings, prop_name, value)
        except Exception:
            pass


def _apply_persistent_feature_update(feature_id: str, self=None, context=None) -> None:
    global _PERSISTENCE_APPLYING
    if _PERSISTENCE_APPLYING:
        return
    from . import persistent_features, transaction
    feature = persistent_features.get_feature(feature_id)
    settings = self or get_settings(context)
    if feature is None or settings is None or not _settings_matches_live_identity(settings):
        return
    settings_key = _settings_identity_key(settings)
    if settings_key is None:
        return
    old_value = persisted_setting_value(feature.suite_property, feature.default)
    try:
        with transaction.operation_transaction(f"persistent.toggle.{feature_id}") as (active, owner):
            if active.mark_once(f"restore-toggle:{settings_key}:{feature.suite_property}"):
                active.add_undo(
                    lambda settings=settings, prop=feature.suite_property, old=old_value:
                    _restore_feature_toggle(settings, prop, old)
                )
            persistent_features.apply_feature(feature_id, context)
            _persist_setting_update(settings, context)
            if owner:
                active.commit()
    except Exception:
        _mark_persistence_dirty(settings)


def _update_persistent_ui_asset_cache(self=None, context=None):
    _apply_persistent_feature_update("ui_asset_cache", self, context)


def _update_persistent_auto_enable_compositor(self=None, context=None):
    _apply_persistent_feature_update("auto_enable_compositor", self, context)


def _update_persistent_auto_render_pass_guard(self=None, context=None):
    _apply_persistent_feature_update("auto_render_pass_guard", self, context)


def _update_persistent_auto_precision_output_guard(self=None, context=None):
    _apply_persistent_feature_update("auto_precision_output_guard", self, context)


def _update_persistent_auto_node_tree_sanity(self=None, context=None):
    _apply_persistent_feature_update("auto_node_tree_sanity", self, context)


def _update_persistent_live_quality_status(self=None, context=None):
    _apply_persistent_feature_update("live_quality_status", self, context)


def _update_show_section_catalog(self=None, context=None):
    if not _PERSISTENCE_APPLYING and bool(getattr(self, "show_section_catalog", False)):
        # The 655 KiB catalog is loaded only by this explicit user action (or the
        # load/apply event below), never from Panel.draw/poll or registration.
        try:
            from . import catalog
            catalog.ensure_loaded()
        except Exception:
            pass
    _persist_setting_update(self, context)


def _update_persistent_feature(self=None, context=None):
    if _PERSISTENCE_APPLYING:
        return
    try:
        from . import persistent_features, transaction
        with transaction.operation_transaction("persistent.toggle.all") as (active, owner):
            persistent_features.apply_all_persistent_features(context)
            _persist_setting_update(self, context)
            if owner:
                active.commit()
    except Exception:
        _mark_persistence_dirty(self)


def _preset_items(self=None, context=None):
    try:
        settings = get_settings(context)
    except Exception:
        settings = None
    lang = _enum_lang(settings)
    preferred = [
        "APEX_COMMAND_WORKSPACE",
        "AOV_DELTA_VERIFIER",
        "DEEP_MATTE_FUSION_LAB",
        "LENS_APERTURE_DESIGNER",
        "DYNAMIC_RANGE_SCULPTOR",
        "PERCEPTION_MATCH_ASSISTANT",
        "ADAPTIVE_DENOISE_PROFILE_LAB",
        "MOTION_FLOW_GUARD",
        "GEOMETRY_SIGNAL_BRIDGE",
        "DELIVERY_SANITY_CHECK",
        "APEX_VISUAL_GUIDE_BOARD",
        "AOV_SHUFFLE_MATRIX",
        "MATTE_REFINER",
        "ADVANCED_GLOW",
        "BOKEH_DEPTH_BLUR",
        "COLOR_GRADE_PANEL",
        "LENS_FLARE_BUILDER",
        "DEBAND_DENOISE_RESTORE",
        "DEPTH_FOG_RELIGHT",
        "AI_MASK_BRIDGE",
        "PRECISION_MASTER_WORKSPACE",
        "PRECISION_OVERDRIVE_WORKSPACE",
        "PRECISION_QC_LAB",
        "HDR_HIGHLIGHT_GUARD",
        "SUBPIXEL_MATTE_LAB",
        "OPTICAL_BLOOM_LAB",
        "RESTORATION_LAB",
        "DEPTH_VECTOR_AUDIT",
        "SCS_ULTRA_LAUNCHPAD",
        "PERCEPTUAL_FINISHING_HUB",
        "AOV_INTEGRITY_MATRIX",
        "ADAPTIVE_RESTORE_ENGINE",
        "PHYSICAL_OPTICS_ENGINE",
        "MATTE_MICROSURGERY_ENGINE",
    ]
    all_ids = list(preferred)
    for preset_id in preset_ids():
        if preset_id not in all_ids:
            all_ids.append(preset_id)
    cache_key = ("preset", lang)
    cached = _ENUM_ITEMS_CACHE.get(cache_key)
    if cached is not None:
        return cached
    rows = []
    for preset_id in all_ids:
        label = _preset_label(preset_id, settings)
        rows.append((preset_id, label, label))
    return _cache_enum_items(cache_key, rows)


class SCS_Settings(bpy.types.PropertyGroup):
    n_panel_state_save: BoolProperty(
        name=t("Nパネル状態保存", "N-panel State Save"),
        description=tooltip(
            "Nパネルで変更した全設定をBlender 5.1のconfig内にあるSmart_Composite_SuiteフォルダのSmart_Composite_Suite.jsonへ保存するタイミングを切り替えます。",
            "Controls when every N-panel setting change is saved to Smart_Composite_Suite/Smart_Composite_Suite.json in Blender 5.1 config.",
            usage_ja="有効時は、常時機能切り替え、セクション開閉、検索、プリセット、精度、出力、UI表示など全設定を変更のたびに保存し、シーン切り替え時とBlender起動時に復元します。無効化操作そのものを最後に1回保存した後は、再度有効にするまで通常・強制・終了時の全書込みを停止します。",
            usage_en="When enabled, every setting including resident toggles, section states, search, preset, precision, output, and UI display settings is saved on every change and restored on scene switch and Blender startup. Disabling commits that OFF state once, then blocks ordinary, forced, and shutdown writes until re-enabled.",
            tip_ja="保存先は C:\\Users\\ユーザー名\\AppData\\Roaming\\Blender Foundation\\Blender\\5.1\\config\\Smart_Composite_Suite\\Smart_Composite_Suite.json です。通常は有効のまま使うと、Nパネル状態が常に維持されます。",
            tip_en="The Windows path is C:\\Users\\<user>\\AppData\\Roaming\\Blender Foundation\\Blender\\5.1\\config\\Smart_Composite_Suite\\Smart_Composite_Suite.json. Keep this enabled for continuously maintained N-panel state.",
        ),
        default=True,
        update=_update_n_panel_state_save,
    )  # type: ignore

    show_always_on_toggles: BoolProperty(
        name=t("常時機能切り替えグループ", "Resident Features Group"),
        description=tooltip(
            "Nパネル最上部の時計アイコン付き常時機能切り替えグループを開閉します。",
            "Opens or closes the clock-marked Resident Features group at the top of the N-panel.",
            usage_ja="常時起動系の機能はこのグループにだけ集約しています。閉じても有効状態は保持されます。",
            usage_en="All event-driven persistent helpers are centralized only in this group. Closing it does not change enabled states.",
            tip_ja="起動負荷を抑えるため、各補助機能は有効化時、起動時、.blend読込時、SCS操作前だけ一回実行され、常時タイマー監視は行いません。",
            tip_en="To keep startup light, each helper runs once when enabled, at startup, after .blend load, or before SCS operations, and does not use continuous timer monitoring.",
        ),
        default=False,
        update=_persist_setting_update,
    )  # type: ignore


    show_section_main_actions: BoolProperty(
        name=t("基本操作グループ", "Main Actions Group"),
        description=tooltip(
            "Smart Compositeの移動、診断、設定保存など基本操作グループを開閉します。",
            "Opens or closes the main Smart Composite action group for workspace navigation, audit, and preference saving.",
            usage_ja="閉じても機能状態は変更されません。必要な時だけ開いて実行してください。",
            usage_en="Closing the group does not change any feature state. Open it only when you need to run those commands.",
            tip_ja="このグループは実行ボタンだけをまとめます。シーンやノードはボタンを押した時だけ変更します。",
            tip_en="This group only gathers manual command buttons. Scenes and nodes are changed only when you press a command.",
        ),
        default=False,
        update=_persist_setting_update,
    )  # type: ignore

    show_section_apex_command: BoolProperty(
        name=t("Apexコマンドセンターグループ", "Apex Command Center Group"),
        description=tooltip(
            "Apex統合構成と主要な高精度プリセットをまとめたグループを開閉します。",
            "Opens or closes the group that gathers Apex stacks and major high-precision presets.",
            usage_ja="頻繁に使う代表プリセットだけを素早く呼び出したい時に開きます。",
            usage_en="Open this when you want quick access to representative frequently used presets.",
            tip_ja="閉じている間は大きなアイコンボタンを描画しないため、Nパネルを軽く保てます。",
            tip_en="When collapsed, large icon buttons are not drawn, keeping the N-panel lighter.",
        ),
        default=False,
        update=_persist_setting_update,
    )  # type: ignore

    show_section_launchpad: BoolProperty(
        name=t("大アイコンランチャーグループ", "Large Icon Launchpad Group"),
        description=tooltip(
            "大きなプリセットアイコンを使うランチャーグループを開閉します。",
            "Opens or closes the large-icon preset launcher group.",
            usage_ja="視認性を優先してプリセットを選びたい時に開きます。",
            usage_en="Open this when you want to choose presets using highly visible icon buttons.",
            tip_ja="大アイコンは開いた時だけ描画されます。閉じるとスクロール量と描画負荷を抑えられます。",
            tip_en="Large icons are drawn only while expanded. Collapse this group to reduce scrolling and drawing cost.",
        ),
        default=False,
        update=_persist_setting_update,
    )  # type: ignore

    show_section_precision_dashboard: BoolProperty(
        name=t("精度ダッシュボードグループ", "Precision Dashboard Group"),
        description=tooltip(
            "精度、破綻抑制、深度範囲、診断出力などの設定グループを開閉します。",
            "Opens or closes the settings group for precision, artifact guards, depth range, and diagnostic output.",
            usage_ja="新規追加するSCSスタックの品質や診断密度を調整する時に開きます。",
            usage_en="Open this when tuning the quality and diagnostic density of newly added SCS stacks.",
            tip_ja="既存ノードの値はこの設定表示だけでは変更されません。プリセット追加時や手動実行時に参照されます。",
            tip_en="Displaying these settings does not change existing nodes. They are referenced when adding presets or running commands.",
        ),
        default=False,
        update=_persist_setting_update,
    )  # type: ignore

    show_section_ui_polish: BoolProperty(
        name=t("UI洗練グループ", "UI Polish Group"),
        description=tooltip(
            "ランチャー列数、アイコン倍率、リファレンス表示などUI調整グループを開閉します。",
            "Opens or closes the UI tuning group for launcher columns, icon scale, and visual reference display.",
            usage_ja="Nパネルの見やすさや表示密度を調整したい時に開きます。",
            usage_en="Open this when adjusting N-panel readability or display density.",
            tip_ja="設定値はBlender 5.1のconfig内にあるSmart_Composite_SuiteフォルダのSmart_Composite_Suite.jsonへ保存され、次回起動時にも復元されます。",
            tip_en="Values are saved to Smart_Composite_Suite/Smart_Composite_Suite.json in Blender 5.1 config and restored on the next launch.",
        ),
        default=False,
        update=_persist_setting_update,
    )  # type: ignore

    show_section_visual_references: BoolProperty(
        name=t("画像リファレンスグループ", "Visual References Group"),
        description=tooltip(
            "SCSの視覚リファレンス画像を表示するグループを開閉します。",
            "Opens or closes the group that displays Smart Composite visual reference images.",
            usage_ja="構成例や品質確認の目安を画像で確認したい時に開きます。",
            usage_en="Open this when you want image-based references for structures and quality checks.",
            tip_ja="画像プレビューは開いた時だけ描画されます。重い場合は閉じてください。",
            tip_en="Image previews are drawn only while expanded. Collapse this group if drawing feels heavy.",
        ),
        default=False,
        update=_persist_setting_update,
    )  # type: ignore

    show_section_setup: BoolProperty(
        name=t("セットアップグループ", "Setup Group"),
        description=tooltip(
            "コンポジター有効化、レンダーパス有効化、作業台作成など初期設定グループを開閉します。",
            "Opens or closes the setup group for enabling the compositor, enabling render passes, and building workspaces.",
            usage_ja="制作開始時やテンプレート準備時に開いて順番に実行します。",
            usage_en="Open this at the start of production or template preparation and run commands in order.",
            tip_ja="常時起動機能ではなく、押したボタンだけが実行されます。",
            tip_en="These are not always-on features. Only the pressed button runs.",
        ),
        default=False,
        update=_persist_setting_update,
    )  # type: ignore

    show_section_presets: BoolProperty(
        name=t("プリセットグループ", "Presets Group"),
        description=tooltip(
            "選択プリセットと代表的なクイックプリセットのグループを開閉します。",
            "Opens or closes the group for the selected preset and representative quick presets.",
            usage_ja="一覧からプリセットを選ぶ場合や、代表プリセットを直接追加する場合に開きます。",
            usage_en="Open this when selecting a preset from the list or directly adding a representative preset.",
            tip_ja="ヘルプボタンから各プリセットの概要と使用方法を確認できます。",
            tip_en="Use the Help buttons to inspect each preset's overview and usage method.",
        ),
        default=False,
        update=_persist_setting_update,
    )  # type: ignore

    show_section_catalog: BoolProperty(
        name=t("独自ツールカタロググループ", "Original Tool Catalog Group"),
        description=tooltip(
            "SCS独自ツールカタログの検索・絞り込みグループを開閉します。",
            "Opens or closes the search and filter group for the SCS original tool catalog.",
            usage_ja="カテゴリ、SCSエンジン、検索語で機能を探す時に開きます。",
            usage_en="Open this when searching by category, SCS engine, or keyword.",
            tip_ja="表示件数を上げすぎるとNパネルが長くなるため、必要な時だけ開いてください。",
            tip_en="High display counts make the N-panel long, so expand this group only when needed.",
        ),
        default=False,
        update=_update_show_section_catalog,
    )  # type: ignore

    show_section_pipeline: BoolProperty(
        name=t("パイプライングループ", "Pipeline Group"),
        description=tooltip(
            "納品チェック、マルチパス出力、品質レポート、SCSノード整理のグループを開閉します。",
            "Opens or closes the pipeline group for delivery checks, multi-pass output, quality reports, and SCS node cleanup.",
            usage_ja="納品前の確認、仕様書き出し、SCSノード整理を行う時に開きます。",
            usage_en="Open this for pre-delivery checks, specification export, and SCS node cleanup.",
            tip_ja="削除系ボタンはSCSが作成したノード整理のみを対象にします。実行前に内容を確認してください。",
            tip_en="Cleanup targets SCS-created node structures. Check the scene before running removal commands.",
        ),
        default=False,
        update=_persist_setting_update,
    )  # type: ignore

    persistent_ui_asset_cache: BoolProperty(
        name=t("UIアイコンキャッシュ", "UI Icon Cache"),
        description=tooltip(
            "SCS独自PNGアイコンと画像リファレンスのプレビュー使用を切り替えます。Blender 5.1ではUIパネル安定性を優先し、標準アイコン表示へ安全フォールバックします。",
            "Toggles preview use for SCS original PNG icons and visual references. In Blender 5.1, UI panel stability is prioritized and the UI safely falls back to built-in icons.",
            usage_ja="通常は無効のままにしてください。無効でも全機能、全セクション、全ヘルプ、全リファレンス画像オープン機能は使えます。",
            usage_en="Keep this disabled in normal use. All features, sections, help, and reference-image opening remain available while disabled.",
            tip_ja="Blender 5.1.0のUIパネルイベント中クラッシュ対策として、ライブUIでは標準アイコンを優先します。",
            tip_en="As a safeguard against Blender 5.1.0 UI panel event crashes, the live UI prioritizes built-in icons.",
        ),
        default=False,
        update=_update_persistent_ui_asset_cache,
    )  # type: ignore

    persistent_auto_enable_compositor: BoolProperty(
        name=t("コンポジター自動維持", "Compositor Keep-Alive"),
        description=tooltip(
            "Blender起動時、.blend読込後、有効化時、SCS操作前に、現在シーンのコンポジター使用とレンダー合成を一回確認して有効状態へ戻します。",
            "At Blender startup, after .blend load, when enabling this item, or before SCS operations, checks once and restores compositor and render compositing on the current scene.",
            usage_ja="シーン読込時や共同作業でコンポジター設定が戻る場合だけ有効にします。不要な場合は無効のままにしてください。",
            usage_en="Enable only when scene load or shared files often disable compositor setup. Keep it disabled when not needed.",
            tip_ja="無効時は何もしません。有効時も常時タイマー監視は登録せず、決まったSCS処理タイミングで一回だけ実行します。",
            tip_en="When disabled it does nothing. When enabled it does not register continuous timer monitoring and only runs once at deterministic SCS workflow points.",
        ),
        default=False,
        update=_update_persistent_auto_enable_compositor,
    )  # type: ignore

    persistent_auto_render_pass_guard: BoolProperty(
        name=t("レンダーパス自動維持", "Render Pass Guard"),
        description=tooltip(
            "Blender起動時、.blend読込後、有効化時、SCS操作前に、Z、ミスト、法線、ベクトル、AO、シャドウ、放射、クリプトマットなど合成で必要なビューレイヤーパスを一回確認して補います。",
            "At Blender startup, after .blend load, when enabling this item, or before SCS operations, checks once and fills compositor-oriented View Layer passes such as Z, Mist, Normal, Vector, AO, Shadow, Emission, and Cryptomatte.",
            usage_ja="AOV確認や深度／法線／ベクトル診断を読込時に揃えたいショットで有効にします。レンダー前設定を手動管理したい場合は無効にします。",
            usage_en="Enable for shots that should have AOV, depth, normal, or vector diagnostics prepared on load. Disable when you want to manage render-pass settings manually.",
            tip_ja="無効時はパス設定へ一切触れません。有効時も存在しないBlenderプロパティは安全にスキップします。",
            tip_en="When disabled it never touches pass settings. When enabled it safely skips Blender properties that do not exist.",
        ),
        default=False,
        update=_update_persistent_auto_render_pass_guard,
    )  # type: ignore

    persistent_auto_precision_output_guard: BoolProperty(
        name=t("精度出力自動維持", "Precision Output Guard"),
        description=tooltip(
            "Blender起動時、.blend読込後、有効化時、SCS操作前に、OpenEXR Multilayer、RGBA、高ビット深度、ZIP圧縮など高精度コンポジット向けの出力設定を一回確認して補います。",
            "At Blender startup, after .blend load, when enabling this item, or before SCS operations, checks once and fills high-precision compositing output settings such as OpenEXR Multilayer, RGBA, high bit depth, and ZIP compression.",
            usage_ja="納品前の.blendを読込時に高精度出力へ戻したい場合だけ有効にします。実験中や通常作業では無効推奨です。",
            usage_en="Enable only when delivery scenes should return to high-precision output on load. For experiments or normal work, keeping it disabled is recommended.",
            tip_ja="無効時は出力設定を自動変更しません。ビュー変換や既存ノードも勝手に変更しません。",
            tip_en="When disabled it does not auto-change output settings. It also does not silently alter View Transform or existing nodes.",
        ),
        default=False,
        update=_update_persistent_auto_precision_output_guard,
    )  # type: ignore

    persistent_auto_node_tree_sanity: BoolProperty(
        name=t("ノード健全性ガード", "Node Sanity Guard"),
        description=tooltip(
            "コンポジターのノードツリー、レンダーレイヤー、ビューアー、コンポジットの最低限の存在確認を行い、不足時だけ安全に補います。",
            "Checks the compositor node tree and minimum Render Layers, Viewer, and Composite availability, adding only missing safe basics.",
            usage_ja="テンプレート作成、教育用ファイル、レビュー用シーンなど、読込時に確認表示を整えたい場合に有効にします。",
            usage_en="Enable for templates, learning files, or review scenes that should be made reviewable on load.",
            tip_ja="無効時はノードツリーを一切変更しません。有効時も既存ノードの削除や再配線は行いません。",
            tip_en="When disabled it never changes the node tree. When enabled it does not delete or rewire existing nodes.",
        ),
        default=False,
        update=_update_persistent_auto_node_tree_sanity,
    )  # type: ignore

    persistent_live_quality_status: BoolProperty(
        name=t("品質ステータス自動更新", "Auto Quality Status"),
        description=tooltip(
            "ノード数、SCSノード数、出力ノード数、レンダーパス数を軽量に集計し、品質スコアを計算して記録します。",
            "Lightly counts nodes, SCS nodes, output nodes, and render passes, then calculates and records a quality score.",
            usage_ja="読込後やSCS診断・品質操作後にセットアップ漏れを自動で確認したい場合に有効にします。必要ない場合は手動の診断ボタンだけを使います。",
            usage_en="Enable when setup omissions should be checked automatically after load or SCS audit/quality operations. Otherwise use only the manual audit button.",
            tip_ja="常時タイマー監視は行いません。大規模ノードツリーで軽さを優先する場合は無効にしてください。",
            tip_en="No continuous timer monitoring is used. Keep it disabled for very large node trees when idle performance matters.",
        ),
        default=False,
        update=_update_persistent_live_quality_status,
    )  # type: ignore

    search_text: StringProperty(
        name=t("検索", "Search"),
        description=tooltip(
            "SCS独自ツールカタログとプリセット一覧を検索します。",
            "Searches the SCS original tool catalog and preset list.",
            usage_ja="グロー、深度、デバンド、または参照元の機能名でも絞り込めます。UI上のツール名はSCS独自名で表示します。",
            usage_en="Filter with Glow, Depth, Deband, or research-reference names. User-facing tool names remain SCS-original.",
            tip_ja="検索は大文字小文字を区別せず、SCSツール名、独自エンジン名、カテゴリ名、参照元の参照名、プリセットIDを対象にします。",
            tip_en="Search is case-insensitive and checks SCS tool names, original engine names, hidden research references, categories, and preset IDs.",
        ),
        default="",
        update=_persist_setting_update,
    )  # type: ignore

    category_filter: EnumProperty(
        name=t("カテゴリ", "Category"),
        description=tooltip(
            "表示するSCS独自ツールカテゴリを選択します。",
            "Selects the SCS original tool category to display.",
            usage_ja="AOV、カラー、ブラー、復元など、目的別にカタログを絞り込みます。",
            usage_en="Filter the catalog by purpose, such as AOV, color, blur, or restoration.",
            tip_ja="「全カテゴリ」に戻すと、すべてのSCS独自ツールを表示します。",
            tip_en="Set the category back to All Categories to show every SCS original tool.",
        ),
        items=_category_items,
        update=_persist_setting_update,
    )  # type: ignore

    source_filter: EnumProperty(
        name=t("SCSエンジン", "SCS Engine"),
        description=tooltip(
            "独自ツールカタログで表示するSCSエンジンを選択します。",
            "Selects the SCS engine shown in the original tool catalog.",
            usage_ja="PrismPass、MatteForge、SpectraLight、ChromaForgeなどのSCS独自エンジンで絞り込めます。",
            usage_en="Filter by original SCS engines such as PrismPass, MatteForge, SpectraLight, or ChromaForge.",
            tip_ja="「全エンジン」に戻すと、全エンジンの機能をまとめて表示します。",
            tip_en="Set this back to All Engines to browse every SCS engine.",
        ),
        items=_source_items,
        update=_persist_setting_update,
    )  # type: ignore

    catalog_limit: IntProperty(
        name=t("表示件数", "Display Count"),
        description=tooltip(
            "独自ツールカタログに一度に表示する件数です。",
            "Number of original tool catalog entries shown at once.",
            usage_ja="検索語やカテゴリ、SCSエンジンで絞り込んだあと、必要に応じて件数を増やします。",
            usage_en="After filtering by search text, category, or SCS engine, increase this value when you need to inspect more entries.",
            tip_ja="件数を増やしすぎるとNパネルが長くなります。通常は14〜24件程度が扱いやすいです。",
            tip_en="Very high values make the N-panel long. Values around 14 to 24 are usually practical.",
        ),
        default=18,
        min=4,
        max=80,
        update=_persist_setting_update,
    )  # type: ignore

    preset: EnumProperty(
        name=t("追加プリセット", "Preset to Add"),
        description=tooltip(
            "コンポジターに追加するSmartノードスタックを選択します。",
            "Selects the Smart node stack to add to the compositor.",
            usage_ja="選択後に「選択プリセットを追加」を押すと、現在のノードツリーへフレーム付きで追加されます。",
            usage_en="After selecting, press Add Selected Preset to insert it into the current node tree inside a labeled frame.",
            tip_ja="各プリセットはBlender標準ノードで構成されるため、追加後に自由に調整できます。",
            tip_en="Each preset is built from Blender-native nodes, so you can freely adjust it after insertion.",
        ),
        items=_preset_items,
        update=_persist_setting_update,
    )  # type: ignore

    precision_mode: EnumProperty(
        name=t("精度モード", "Precision Mode"),
        description=tooltip(
            "SCSが追加するノードスタックの精度、ノード密度、アーティファクト抑制量を選択します。",
            "Selects the precision, node density, and artifact-suppression level used by SCS node stacks.",
            usage_ja="プレビューは軽量確認、バランスは通常制作、最終は最終品質、極限は重くても品質を優先する検証用、凌駕はAOV診断・保護レーン・多段ミックスバックを最大化する納品前確認用です。",
            usage_en="PREVIEW is for lightweight checking, BALANCED for normal production, FINAL for finishing, EXTREME for heavy verification, and SURPASS for maximum AOV diagnostics, protection lanes, and multi-stage mix-back before delivery.",
            tip_ja="既存ノードの値は自動変更しません。新しく追加するSCSスタックにのみ反映されます。重い素材ではプレビューまたはバランスで作業し、最後に最終/極限を追加してください。",
            tip_en="Existing node values are not changed automatically. This affects newly added SCS stacks only. Work in PREVIEW or BALANCED for heavy footage, then add FINAL/EXTREME for finishing.",
        ),
        items=(
            ("PREVIEW", t("プレビュー", "Preview"), t("軽量確認用スタック", "Fast inspection stack")),
            ("BALANCED", t("バランス", "Balanced"), t("制作向けバランススタック", "Balanced production stack")),
            ("FINAL", t("最終", "Final"), t("最終仕上げ品質スタック", "Finishing quality stack")),
            ("EXTREME", t("極限", "Extreme"), t("最大品質・診断スタック", "Maximum quality and diagnostic stack")),
            ("SURPASS", t("凌駕", "Surpass"), t("最大診断・保護スタック", "Maximum diagnostic and protection stack")),
        ),
        default="SURPASS",
        update=_persist_setting_update,
    )  # type: ignore

    artifact_guard: EnumProperty(
        name=t("破綻抑制レベル", "Artifact Guard Level"),
        description=tooltip(
            "強い合成処理で起きやすい白飛び、マット縁の硬さ、深度飽和、過剰シャープを抑える保護レベルを選択します。",
            "Selects the protection level for clipping, hard matte edges, depth saturation, and over-sharpening caused by aggressive compositing.",
            usage_ja="安全は控えめ、強は制作標準、凌駕は重くても診断レーンと保護レーンを増やして最終確認を優先します。",
            usage_en="SAFE is conservative, STRONG is production-standard, and SURPASS adds heavier diagnostic and protection lanes for final review.",
            tip_ja="既存ノードは変更しません。新しく追加するSCSスタックのノード数、ミックス量、QCレーンに反映します。",
            tip_en="Existing nodes are not changed. This affects node count, mix amount, and QC lanes in newly added SCS stacks.",
        ),
        items=(
            ("SAFE", t("安全", "Safe"), t("控えめな破綻保護", "Conservative artifact protection")),
            ("STRONG", t("強", "Strong"), t("制作向け破綻保護", "Production artifact protection")),
            ("SURPASS", t("凌駕", "Surpass"), t("最大診断・保護レーン", "Maximum diagnostic and protection lanes")),
        ),
        default="STRONG",
        update=_persist_setting_update,
    )  # type: ignore

    qc_density: EnumProperty(
        name=t("QC密度", "QC Density"),
        description=tooltip(
            "精度QCツールセットや品質レポートで作成・検査する診断レーンの密度を選びます。",
            "Selects the density of diagnostic lanes created or inspected by the Precision QC Toolset and quality reports.",
            usage_ja="軽量は最小確認、標準は通常確認、詳細診断は納品前確認、網羅診断は最大確認です。",
            usage_en="LIGHT is minimal checking, STANDARD is normal checking, DEEP is pre-delivery checking, and EXHAUSTIVE is maximum checking.",
            tip_ja="網羅診断はノード数が増えます。重いショットでは詳細診断で確認し、必要な箇所だけ網羅診断を追加してください。",
            tip_en="EXHAUSTIVE adds more nodes. For heavy shots, inspect with DEEP and add EXHAUSTIVE only where needed.",
        ),
        items=(
            ("LIGHT", t("軽量", "Light"), t("最小限の診断", "Minimal diagnostics")),
            ("STANDARD", t("標準", "Standard"), t("標準診断", "Standard diagnostics")),
            ("DEEP", t("詳細診断", "Deep"), t("詳細診断", "Deep diagnostics")),
            ("EXHAUSTIVE", t("網羅診断", "Exhaustive"), t("最大診断", "Maximum diagnostics")),
        ),
        default="DEEP",
        update=_persist_setting_update,
    )  # type: ignore

    highlight_ceiling: FloatProperty(
        name=t("ハイライト保護", "Highlight Guard"),
        description=tooltip(
            "発光・フレア・カラー系スタックで、白飛びを抑えながらHDR感を残すための基準強度です。",
            "Reference intensity used by glow, flare, and color stacks to preserve HDR feel while reducing clipping.",
            usage_ja="値を低くすると保守的になり、高くすると強い光を残します。まず1.0前後から調整してください。",
            usage_en="Lower values are conservative; higher values preserve stronger light. Start around 1.0 and adjust.",
            tip_ja="この値は新規SCSノードの初期値補助です。正確な最終値は素材の露出とビュー変換に合わせて調整してください。",
            tip_en="This is an initial-value helper for new SCS nodes. Tune the final value according to footage exposure and View Transform.",
        ),
        default=1.0,
        min=0.05,
        soft_max=8.0,
        update=_persist_setting_update,
    )  # type: ignore

    matte_edge_radius: IntProperty(
        name=t("マット縁半径", "Matte Edge Radius"),
        description=tooltip(
            "マット縁精度ラボで使うチョーク、拡張、フェザーの基準半径です。",
            "Base radius for choke, expand, and feather operations in the Matte Edge Lab.",
            usage_ja="髪や半透明エッジは小さめ、硬い物体は少し大きめにします。",
            usage_en="Use smaller values for hair or translucent edges and slightly larger values for hard objects.",
            tip_ja="強すぎると輪郭が痩せたり太ったりします。QC表示で白黒の縁を確認しながら調整してください。",
            tip_en="Too much radius makes edges shrink or grow. Check the black/white QC edge display while tuning.",
        ),
        default=3,
        min=0,
        max=32,
        update=_persist_setting_update,
    )  # type: ignore

    auto_connect_outputs: BoolProperty(
        name=t("ビューアー／コンポジットへ自動接続", "Auto-connect Viewer/Composite"),
        description=tooltip(
            "追加したノードスタックの最終出力をビューアーとコンポジットへ自動接続します。",
            "Automatically connects the final output of a new node stack to Viewer and Composite nodes.",
            usage_ja="結果をすぐ確認したい場合はオンにします。既存の最終出力を維持したい場合はオフにしてください。",
            usage_en="Enable this when you want to see results immediately. Disable it when you want to preserve an existing final output.",
            tip_ja="自動接続は出力ソケットが見つかった場合のみ実行します。ノード構成は削除しません。",
            tip_en="Auto-connect only runs when an output socket is found. It does not delete node setups.",
        ),
        default=True,
        update=_persist_setting_update,
    )  # type: ignore

    create_file_outputs: BoolProperty(
        name=t("ファイル出力を作成", "Create File Output"),
        description=tooltip(
            "AOVや中間結果を書き出すファイル出力ノードを作成します。",
            "Creates File Output nodes for AOVs and intermediate results.",
            usage_ja="EXRパス確認や外部AI/編集ソフトへの受け渡しを行う場合にオンにします。",
            usage_en="Enable this when checking EXR passes or handing outputs to external AI/editing tools.",
            tip_ja="オフにすると作らないので、レンダーのたびにファイルが書かれません。",
            tip_en="When off, none are created, so renders write no extra files.",
        ),
        default=True,
        update=_persist_setting_update,
    )  # type: ignore


    create_diagnostic_viewers: BoolProperty(
        name=t("診断ビューアーを作成", "Create Diagnostic Viewers"),
        description=tooltip(
            "AOV、マット、深度、法線、ベクトル、光学効果の中間結果を確認するビューアーノードを追加します。",
            "Adds Viewer nodes for inspecting intermediate AOV, matte, depth, normal, vector, and optical-effect results.",
            usage_ja="最終品質確認や破綻箇所の特定を優先する場合にオンにします。大規模ノードツリーではビューアーが増えるため、軽量確認時はオフにできます。",
            usage_en="Enable this when final review or artifact hunting is more important than graph compactness. Disable it for lightweight inspection in large node trees.",
            tip_ja="既存ビューアーは削除しません。SCSが追加した診断ビューアーのみSCSノード整理の対象になります。",
            tip_en="Existing viewers are not deleted. Only SCS-created diagnostic viewers are targeted by SCS cleanup.",
        ),
        default=True,
        update=_persist_setting_update,
    )  # type: ignore

    artifact_guard_strength: FloatProperty(
        name=t("破綻ガード強度", "Artifact Guard Strength"),
        description=tooltip(
            "白飛び、過剰グロー、マット縁のにじみ、復元処理の効きすぎを抑える保護ミックス量です。",
            "Protection mix amount used to reduce clipping, excessive glow, matte-edge bleeding, and over-applied restoration.",
            usage_ja="0.0で保護を弱く、1.0で保護を強くします。凌駕では既定値のまま品質診断向けに使います。",
            usage_en="0.0 weakens protection and 1.0 strengthens it. In SURPASS mode the default is intended for quality review.",
            tip_ja="強すぎると効果が穏やかになります。最終ルック決定時は0.55〜0.85の範囲で調整してください。",
            tip_en="Too much protection makes effects more conservative. Tune around 0.55 to 0.85 for final looks.",
        ),
        default=0.78,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
        update=_persist_setting_update,
    )  # type: ignore

    edge_protection: FloatProperty(
        name=t("エッジ保護", "Edge Protection"),
        description=tooltip(
            "マット、デノイズ、グロー、深度ブラーで輪郭を残すための保護比率です。",
            "Protection ratio used to preserve contours in matte, denoise, glow, and depth-blur stacks.",
            usage_ja="髪・細線・透明素材・強い発光境界を扱う場合は値を高めにします。背景の大きなぼかしでは低めでも構いません。",
            usage_en="Use higher values for hair, thin lines, translucent materials, or strong glowing edges. Lower values are acceptable for broad background blur.",
            tip_ja="この値は新規追加するSCSスタックの初期値に反映され、既存ノードは自動変更しません。",
            tip_en="This affects initial values for newly added SCS stacks and does not automatically modify existing nodes.",
        ),
        default=0.72,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
        update=_persist_setting_update,
    )  # type: ignore

    output_path: StringProperty(
        name=t("出力パス", "Output Path"),
        description=tooltip(
            "ファイル出力やJSON仕様書き出しの既定保存先です。",
            "Default destination for File Output nodes and exported JSON specifications.",
            usage_ja="未指定時と初期値はBlender 5.1のCONFIG/Smart_Composite_Suite内にあるSCS専用exportsフォルダーです。手動で.blend相対パスまたは絶対パスを指定した場合のみ、その指定先を使います。",
            usage_en="When blank or left at the default, SCS uses its dedicated exports folder inside Blender 5.1 CONFIG/Smart_Composite_Suite. A .blend-relative or absolute path is used only when you manually set it here.",
            tip_ja="フォルダーが存在しない場合は、書き出し時に可能な範囲で作成します。Nパネル設定、標準書き出し先、実行時キャッシュはすべてBlender 5.1のCONFIG/Smart_Composite_Suite配下に維持します。",
            tip_en="If the folder does not exist, export operators create it when possible. N-panel settings, default exports, and runtime caches all remain below Blender 5.1 CONFIG/Smart_Composite_Suite.",
        ),
        default=_default_output_path(),
        subtype="DIR_PATH",
        update=_persist_setting_update,
    )  # type: ignore

    node_offset_x: IntProperty(
        name=t("追加位置X", "Insertion X Offset"),
        description=tooltip(
            "新しいノードフレームを既存ノードの右側へ配置する距離です。",
            "Horizontal distance used to place a new node frame to the right of existing nodes.",
            usage_ja="既存ツリーと重なる場合は値を大きくしてください。",
            usage_en="Increase this value if new stacks overlap your existing node tree.",
            tip_ja="自動配置専用の値で、既存ノードの位置は変更しません。",
            tip_en="This only affects automatic placement and does not move existing nodes.",
        ),
        default=520,
        min=160,
        max=2000,
        update=_persist_setting_update,
    )  # type: ignore

    glow_quality: EnumProperty(
        name=t("グロー品質", "Glow Quality"),
        description=tooltip(
            "発光・フレア系スタックの光学レイヤー数、グレア品質、ハイライト保護量を選びます。",
            "Selects optical layer count, Glare quality, and highlight protection for glow and flare stacks.",
            usage_ja="プレビューは軽量、バランスは標準、最終は多層グロー、極限は追加診断、凌駕は光源分離・エッジ光・白飛び保護を最大化します。",
            usage_en="PREVIEW is lightweight, BALANCED is standard, FINAL adds multi-layer glow, EXTREME adds diagnostics, and SURPASS maximizes light isolation, edge energy, and highlight protection.",
            tip_ja="精度モードと合わせて使用します。強い発光は白飛びしやすいため、最終／極限ではミックス強度を下げてから調整してください。",
            tip_en="Use this together with Precision Mode. Strong glow can clip highlights, so lower Mix strength first in Final/Extreme and then tune upward.",
        ),
        items=(
            ("PREVIEW", t("プレビュー", "Preview"), t("高速プレビュースタック", "Fast preview stack")),
            ("BALANCED", t("バランス", "Balanced"), t("バランススタック", "Balanced stack")),
            ("FINAL", t("最終", "Final"), t("最終品質スタック", "Final quality stack")),
            ("EXTREME", t("極限", "Extreme"), t("最大光学レイヤー", "Maximum optical layers")),
            ("SURPASS", t("凌駕", "Surpass"), t("最大光学診断・保護レイヤー", "Maximum optical diagnostics and guard layers")),
        ),
        default="SURPASS",
        update=_persist_setting_update,
    )  # type: ignore

    depth_near: FloatProperty(
        name=t("深度手前", "Depth Near"),
        description=tooltip(
            "奥行きを使うプリセットが効き始める距離です。",
            "The distance where presets that use depth begin to act.",
            usage_ja="深度フォグなどを追加する時に使います。Zボケはカメラのピントを基準にします。",
            usage_en="Used when adding Depth Fog and similar presets. Z Blur follows the camera focus.",
            tip_ja="シーンの大きさに合わせて決めてください。",
            tip_en="Choose it to suit the size of the scene.",
        ),
        default=1.0,
        min=0.0,
        soft_max=100.0,
        update=_persist_setting_update,
    )  # type: ignore

    depth_far: FloatProperty(
        name=t("深度奥", "Depth Far"),
        description=tooltip(
            "奥行きを使うプリセットが最大に効く距離です。",
            "The distance where presets that use depth reach full strength.",
            usage_ja="深度フォグなどを追加する時に使います。Zボケはカメラのピントを基準にします。",
            usage_en="Used when adding Depth Fog and similar presets. Z Blur follows the camera focus.",
            tip_ja="深度手前より大きい値にしてください。",
            tip_en="Keep it greater than Depth Near.",
        ),
        default=100.0,
        min=0.001,
        soft_max=10000.0,
        update=_persist_setting_update,
    )  # type: ignore


    precision_layers: IntProperty(
        name=t("精度レイヤー数", "Precision Layers"),
        description=tooltip(
            "高精度スタックで使用する解析・保護・光学レイヤーの上限数です。",
            "Maximum number of analysis, protection, and optical layers used by high-precision stacks.",
            usage_ja="値を上げるほど、多段グロー、マット診断、復元ミックスバック、深度／ベクトル確認レーンが増えます。",
            usage_en="Higher values add more multi-lobe glow, matte diagnostics, restoration mix-back, and Depth/Vector inspection lanes.",
            tip_ja="重い素材では3〜4から始め、納品前だけ5以上に上げると安定します。既存ノードは変更しません。",
            tip_en="For heavy footage, start at 3 to 4 and raise above 5 only before delivery. Existing nodes are not changed.",
        ),
        default=4,
        min=1,
        max=8,
        update=_persist_setting_update,
    )  # type: ignore

    artifact_diagnostics: BoolProperty(
        name=t("破綻診断レーン", "Artifact Diagnostic Lanes"),
        description=tooltip(
            "高精度スタックに白飛び、マット縁、深度範囲、復元副作用を確認する診断レーンを追加します。",
            "Adds diagnostic lanes for clipping, matte edges, depth range, and restoration side effects to high-precision stacks.",
            usage_ja="オンにすると最終出力とは別にQC用ノードやビューアーが増えます。作業中の破綻検出に使います。",
            usage_en="When enabled, extra QC nodes and viewers are added separately from the final output. Use them to find artifacts while working.",
            tip_ja="最終画に直接混ぜない診断ノードも作成するため、不要な場合はオフにして軽量化できます。",
            tip_en="Some diagnostics are not mixed into the final image, so disable this for a lighter graph when not needed.",
        ),
        default=True,
        update=_persist_setting_update,
    )  # type: ignore

    matte_edge_safety: FloatProperty(
        name=t("マット縁保護", "Matte Edge Safety"),
        description=tooltip(
            "マットのチョーク、拡張、フェザー、密度調整の安全側バランスです。",
            "Safety-side balance for matte choke, expansion, feathering, and density shaping.",
            usage_ja="値を上げると縁のジャギーや穴を抑えやすくなりますが、細い髪や透明物は甘くなる場合があります。",
            usage_en="Higher values reduce jagged edges and holes, but fine hair or translucent edges may become softer.",
            tip_ja="人物マスクは0.55〜0.75、硬い物体のIDマットは0.25〜0.45から調整してください。",
            tip_en="Start around 0.55 to 0.75 for people masks, and 0.25 to 0.45 for hard object ID mattes.",
        ),
        default=0.65,
        min=0.0,
        max=1.0,
        soft_min=0.0,
        soft_max=1.0,
        update=_persist_setting_update,
    )  # type: ignore

    optical_realism: FloatProperty(
        name=t("光学リアリズム", "Optical Realism"),
        description=tooltip(
            "グロー、ブルーム、フレア、ストリーク、色収差の複合量を調整します。",
            "Controls the combined amount of glow, bloom, flare, streak, and chromatic-aberration layers.",
            usage_ja="値を上げるとレンズ由来の多層感が増えます。HDRハイライト素材では低めから上げてください。",
            usage_en="Higher values increase layered lens character. With HDR highlights, start low and raise gradually.",
            tip_ja="白飛びを避けるため、強い発光ではHDRハイライト保護プリセットと併用してください。",
            tip_en="To avoid clipping, combine strong optical effects with the HDR Highlight Guard preset.",
        ),
        default=0.72,
        min=0.0,
        max=1.0,
        soft_min=0.0,
        soft_max=1.0,
        update=_persist_setting_update,
    )  # type: ignore

    restoration_strength: FloatProperty(
        name=t("復元強度", "Restoration Strength"),
        description=tooltip(
            "デノイズ、デバンド、ディテール回復、ミックスバックの全体強度です。",
            "Overall strength for denoise, deband, detail recovery, and mix-back.",
            usage_ja="値を上げるとノイズやバンディングは抑えやすくなりますが、質感が弱くなる場合があります。",
            usage_en="Higher values suppress noise and banding more strongly, but texture can become weaker.",
            tip_ja="肌や空は0.35〜0.55、細部の多いCGレンダーは0.20〜0.40から調整してください。",
            tip_en="Start around 0.35 to 0.55 for skin or skies, and 0.20 to 0.40 for detail-heavy CG renders.",
        ),
        default=0.38,
        min=0.0,
        max=1.0,
        soft_min=0.0,
        soft_max=1.0,
        update=_persist_setting_update,
    )  # type: ignore



    ui_launcher_style: EnumProperty(
        name=t("ランチャー表示", "Launcher Style"),
        description=tooltip(
            "大きな独自アイコンボタンの表示密度を選択します。",
            "Selects the display density of the large original icon buttons.",
            usage_ja="コンパクトは横に多く並べ、標準は見やすさと密度のバランスを取り、シネマはボタンを大きくし、超大型は図形を限界まで大きく見せる操作モードです。",
            usage_en="COMPACT places more buttons per row, STANDARD balances readability and density, CINEMA enlarges buttons, and HERO pushes symbols to the largest practical visual mode.",
            tip_ja="アイコンは枠無し・透明背景で、図形がキャンバスいっぱいに入るよう生成されています。",
            tip_en="Icons are frameless with transparent backgrounds, generated so the symbol fills the canvas as much as practical.",
        ),
        items=(
            ("COMPACT", t("コンパクト", "Compact"), t("高密度ランチャーグリッド", "Dense launcher grid")),
            ("STANDARD", t("標準", "Standard"), t("バランス型ランチャーグリッド", "Balanced launcher grid")),
            ("CINEMA", t("シネマ", "Cinema"), t("大型ビジュアルランチャーグリッド", "Large visual launcher grid")),
            ("HERO", t("超大型", "Hero"), t("最大アイコン優先ランチャーグリッド", "Maximum icon-first launcher grid")),
        ),
        default="HERO",
        update=_persist_setting_update,
    )  # type: ignore

    launcher_columns: IntProperty(
        name=t("アイコン列数", "Icon Columns"),
        description=tooltip(
            "大アイコンランチャーの列数です。",
            "Number of columns in the large icon launcher.",
            usage_ja="小さいモニターでは2、広いNパネルでは3〜4にすると操作しやすくなります。",
            usage_en="Use 2 on small monitors and 3 to 4 on wider N-panels.",
            tip_ja="列数を増やすとボタン幅が狭くなります。図形を最大限見せたい場合は2または3を推奨します。",
            tip_en="More columns make buttons narrower. Use 2 or 3 when you want the largest visible symbols.",
        ),
        default=2,
        min=1,
        max=4,
        update=_persist_setting_update,
    )  # type: ignore

    large_icon_scale: FloatProperty(
        name=t("アイコン倍率", "Icon Scale"),
        description=tooltip(
            "独自PNGアイコンをNパネル内で表示するときの高さ倍率です。",
            "Height scale used when drawing original PNG icons in the N-panel.",
            usage_ja="値を上げると枠無しアイコンボタンが縦方向に大きく表示されます。",
            usage_en="Higher values make frameless icon buttons taller.",
            tip_ja="BlenderのテーマやNパネル幅によって見え方が変わります。シネマ表示では2.6〜3.2が見やすい範囲です。",
            tip_en="Appearance depends on Blender theme and N-panel width. With CINEMA style, 2.6 to 3.2 is usually readable.",
        ),
        default=6.5,
        min=1.2,
        max=8.0,
        soft_min=2.0,
        soft_max=8.0,
        update=_persist_setting_update,
    )  # type: ignore

    reference_preview_scale: FloatProperty(
        name=t("リファレンス表示倍率", "Reference Preview Scale"),
        description=tooltip(
            "独自画像リファレンスをUI内で表示するときの倍率です。",
            "Scale used when drawing original visual reference images in the UI.",
            usage_ja="大きくすると工程図を確認しやすくなります。Nパネルが狭い場合は下げてください。",
            usage_en="Increase it to inspect workflow diagrams more clearly. Lower it when the N-panel is narrow.",
            tip_ja="画像自体には固定テキストを入れず、UI側のラベルはBlender本体の言語設定に追従します。",
            tip_en="The images avoid fixed text; UI labels follow Blender's language setting.",
        ),
        default=4.2,
        min=1.0,
        max=8.0,
        soft_min=2.0,
        soft_max=6.0,
        update=_persist_setting_update,
    )  # type: ignore

    show_reference_previews: BoolProperty(
        name=t("画像リファレンスを表示", "Show Visual References"),
        description=tooltip(
            "Nパネル内にSCS独自の工程リファレンス画像を表示します。",
            "Shows SCS-original workflow reference images in the N-panel.",
            usage_ja="総合フロー、精度QC、光学、マット縁、カラー、復元の構造をアイコン図として確認できます。",
            usage_en="Inspect the structure of master flow, precision QC, optics, matte edges, color, and restoration as icon diagrams.",
            tip_ja="画像はPNGとして同梱しています。読み込めない環境でも通常のボタンは使えます。",
            tip_en="Images are bundled as PNG files and loaded through bpy.utils.previews. Normal buttons remain usable even if previews fail to load.",
        ),
        default=True,
        update=_persist_setting_update,
    )  # type: ignore


    reference_columns: IntProperty(
        name=t("リファレンス列数", "Reference Columns"),
        description=tooltip(
            "画像リファレンスをNパネル内に並べる列数です。",
            "Number of columns used for visual reference previews in the N-panel.",
            usage_ja="工程図を大きく確認したい場合は1、複数工程をまとめて見たい場合は2にします。",
            usage_en="Use 1 for large workflow diagrams and 2 to compare several references at once.",
            tip_ja="画像は言語非依存の図形だけで構成され、説明はUIラベルとツールチップで表示します。",
            tip_en="Images use language-independent symbols only; explanations are provided by UI labels and tooltips.",
        ),
        default=1,
        min=1,
        max=2,
        update=_persist_setting_update,
    )  # type: ignore

    hero_icon_scale: FloatProperty(
        name=t("ヒーローアイコン倍率", "Hero Icon Scale"),
        description=tooltip(
            "Apexコマンドセンターの最上段ボタンを通常ランチャーよりさらに大きく表示する倍率です。",
            "Scale used to draw the top Apex Command Center buttons even larger than normal launcher buttons.",
            usage_ja="図形の視認性を最優先する場合は7.0〜9.0にします。Nパネルが狭い場合は6.0前後に下げてください。",
            usage_en="Use 7.0 to 9.0 when symbol readability is the priority. Lower to around 6.0 if the N-panel is narrow.",
            tip_ja="ボタン枠は使わず、透明PNGの図形だけを可能な限り大きく表示します。",
            tip_en="Buttons are frameless and display the transparent PNG symbol as large as Blender's UI allows.",
        ),
        default=7.5,
        min=2.0,
        max=10.0,
        soft_min=4.0,
        soft_max=9.0,
        update=_persist_setting_update,
    )  # type: ignore

    workflow_guidance_level: EnumProperty(
        name=t("工程ガイド密度", "Workflow Guide Density"),
        description=tooltip(
            "UI上に表示する工程説明の密度を選択します。",
            "Selects how much workflow guidance is shown in the UI.",
            usage_ja="「最小限」はボタン中心、「ガイド」は要点表示、「詳細ガイド」は作業順と破綻確認ポイントを多めに表示します。",
            usage_en="MINIMAL is button-first, GUIDED shows essentials, and DETAILED adds workflow order and artifact-check points.",
            tip_ja="初心者や複雑なショットでは「詳細ガイド」、慣れた作業では「ガイド」か「最小限」が向きます。",
            tip_en="Use DETAILED for beginners or complex shots, and GUIDED or MINIMAL for familiar workflows.",
        ),
        items=(
            ("MINIMAL", t("最小限", "Minimal"), t("ボタン優先UI", "Button-first UI")),
            ("GUIDED", t("ガイド", "Guided"), t("バランス型ガイド", "Balanced guidance")),
            ("DETAILED", t("詳細ガイド", "Detailed"), t("詳細工程ガイド", "Detailed workflow guidance")),
        ),
        default="GUIDED",
        update=_persist_setting_update,
    )  # type: ignore

    auto_optimize_ui_visibility: BoolProperty(
        name=t("UI視認性を優先", "Prioritize UI Visibility"),
        description=tooltip(
            "大きなアイコン、少ない列数、画像リファレンス重視のUI設定を優先します。",
            "Prioritizes large icons, fewer columns, and visual-reference oriented UI settings.",
            usage_ja="オンにするとApexランチャーで図形が最大限目立つ設定を前提に表示します。オフにしても手動設定は保持されます。",
            usage_en="When enabled, Apex launchers assume settings that maximize symbol visibility. Manual settings are still preserved when disabled.",
            tip_ja="実際の値を一括変更したい場合は、ApexコマンドセンターのUI視認性最適化ボタンを実行してください。",
            tip_en="Run the Optimize UI Visibility button in the Apex Command Center when you want to apply the values directly.",
        ),
        default=True,
        update=_persist_setting_update,
    )  # type: ignore


    last_message: StringProperty(
        name=t("状態", "Status"),
        description=tooltip(
            "最後に実行したSmart Composite操作の結果メッセージです。",
            "Result message from the last Smart Composite operation.",
            usage_ja="診断結果や追加したプリセット名を確認できます。",
            usage_en="Use it to check audit results or the last added preset.",
            tip_ja="一時的な状態表示であり、Nパネル設定JSONや.blendへ永続設定として保存しません。詳細は品質レポートを書き出して確認できます。",
            tip_en="This is a transient status display and is not stored as a persistent N-panel setting in JSON or the .blend. Export a quality report for detailed results.",
        ),
        default="",
        options={'SKIP_SAVE'},
    )  # type: ignore


PERSISTENT_SETTING_NAMES = (
    'n_panel_state_save',
    'show_always_on_toggles',
    'persistent_ui_asset_cache',
    'show_section_main_actions',
    'show_section_apex_command',
    'show_section_launchpad',
    'show_section_precision_dashboard',
    'show_section_ui_polish',
    'show_section_visual_references',
    'show_section_setup',
    'show_section_presets',
    'show_section_catalog',
    'show_section_pipeline',
    'persistent_auto_enable_compositor',
    'persistent_auto_render_pass_guard',
    'persistent_auto_precision_output_guard',
    'persistent_auto_node_tree_sanity',
    'persistent_live_quality_status',
    'search_text',
    'category_filter',
    'source_filter',
    'catalog_limit',
    'preset',
    'precision_mode',
    'artifact_guard',
    'qc_density',
    'highlight_ceiling',
    'matte_edge_radius',
    'auto_connect_outputs',
    'create_file_outputs',
    'create_diagnostic_viewers',
    'artifact_guard_strength',
    'edge_protection',
    'output_path',
    'node_offset_x',
    'glow_quality',
    'depth_near',
    'depth_far',
    'precision_layers',
    'artifact_diagnostics',
    'matte_edge_safety',
    'optical_realism',
    'restoration_strength',
    'ui_launcher_style',
    'launcher_columns',
    'large_icon_scale',
    'reference_preview_scale',
    'show_reference_previews',
    'reference_columns',
    'hero_icon_scale',
    'workflow_guidance_level',
    'auto_optimize_ui_visibility',
)



def _iter_persistent_setting_names() -> tuple[str, ...]:
    """Return every user-facing N-panel setting stored in Smart_Composite_Suite.json."""
    names = list(PERSISTENT_SETTING_NAMES)
    try:
        annotations = getattr(SCS_Settings, "__annotations__", {}) or {}
    except Exception:
        annotations = {}
    for name in annotations.keys():
        text = str(name or "")
        if text and not text.startswith("_") and text not in _TRANSIENT_SETTING_NAMES and text not in names:
            names.append(text)
    return tuple(name for name in names if name not in _TRANSIENT_SETTING_NAMES)



def n_panel_settings_path(create: bool = True) -> Path:
    try:
        return storage.n_panel_settings_file(create=create)
    except Exception:
        return storage.blender_config_file(N_PANEL_SETTINGS_FILENAME, create=create)


def _settings_file_exists() -> bool:
    try:
        return bool(n_panel_settings_path(create=False).exists())
    except Exception:
        return False


def _any_settings_candidate_exists() -> bool:
    """Read-only existence probe; callers must already hold restore authority."""
    path = n_panel_settings_path(create=False)
    candidates = [path, _central_settings_path(path)]
    try:
        candidates.extend(storage.legacy_n_panel_settings_candidates(path))
    except Exception:
        pass
    return any(bool(candidate.exists()) for candidate in candidates)


def _json_safe_value(value: Any) -> Any:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def settings_to_dict(settings=None) -> dict[str, Any]:
    if settings is None:
        settings = get_settings()
    data: dict[str, Any] = {}
    if settings is None:
        return data
    for name in _iter_persistent_setting_names():
        try:
            data[name] = _json_safe_value(getattr(settings, name))
        except Exception:
            continue
    return data


def _central_settings_path(path: Path) -> Path:
    return path.with_name(path.stem + ".central.json")


def _settings_checksum(schema_version: int, generation: int, settings_data: dict[str, Any]) -> str:
    canonical = json.dumps(
        {"schema_version": int(schema_version), "generation": int(generation), "settings": settings_data},
        ensure_ascii=False, sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _validate_settings_payload(payload: Any) -> bool:
    if not isinstance(payload, dict):
        return False
    try:
        schema_version = int(payload.get("schema_version", -1))
        generation = int(payload.get("generation", -1))
    except Exception:
        return False
    settings_data = payload.get("settings")
    if schema_version != SETTINGS_SCHEMA_VERSION or generation < 0 or not isinstance(settings_data, dict):
        return False
    checksum = str(payload.get("checksum", "") or "")
    return bool(checksum) and checksum == _settings_checksum(schema_version, generation, settings_data)


def _load_settings_payload_details(*, repair_main: bool = False) -> tuple[dict[str, Any] | None, Path | None, int]:
    path = n_panel_settings_path(create=False)
    legacy_paths = ()
    try:
        legacy_paths = storage.legacy_n_panel_settings_candidates(path)
    except Exception:
        legacy_paths = ()
    data, source, generation = storage.load_json_recovering(
        path, validator=_validate_settings_payload,
        central_paths=(_central_settings_path(path), *legacy_paths),
        default=None, repair_main=repair_main,
    )
    return (data if isinstance(data, dict) else None), source, int(generation or 0)


def _load_settings_payload(*, repair_main: bool = False) -> tuple[dict[str, Any] | None, int]:
    data, _source, generation = _load_settings_payload_details(repair_main=repair_main)
    return data, generation


def _build_settings_payload(
    settings_data: dict[str, Any],
    generation: int,
    path: Path,
    *,
    base_payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    clean_settings = dict(settings_data or {})
    payload = dict(base_payload) if isinstance(base_payload, dict) else {}
    payload.update({
        "schema_version": SETTINGS_SCHEMA_VERSION,
        "generation": max(0, int(generation)),
        "addon": "Smart Composite Suite",
        "owner": "JELararagi",
        "storage": "config/Smart_Composite_Suite/Smart_Composite_Suite.json",
        "path": str(path),
        "settings": clean_settings,
    })
    payload["checksum"] = _settings_checksum(SETTINGS_SCHEMA_VERSION, payload["generation"], clean_settings)
    return payload


def _write_n_panel_settings_payload(
    settings_data: dict[str, Any],
    *,
    allow_disabled_commit: bool = False,
    _off_capability=None,
) -> bool:
    global _PERSISTENCE_APPLIED_ONCE, _PERSISTENCE_DIRTY
    global _PENDING_SETTINGS_SNAPSHOT, _PENDING_SETTINGS_KEY, _LAST_WRITTEN_SETTINGS_KEY
    # This is the lowest writer boundary. Reject cold/restore/live-OFF and the
    # retired public Boolean before payload inspection, path resolution, or IO.
    if allow_disabled_commit:
        return False
    if _off_capability is None and not bool(
        globals().get("_PERSISTENCE_AUTHORITY_PHASE") == "READY"
        and int(globals().get("_RESTORE_BARRIER_DEPTH", 0) or 0) == 0
        and not bool(globals().get("_PERSISTENCE_APPLYING", False))
        and globals().get("_LIVE_STATE_SAVE_ENABLED") is True
        and globals().get("_LIVE_SETTINGS_IDENTITY") is not None
        and callable(globals().get("_live_authority_identity_valid"))
        and globals()["_live_authority_identity_valid"]()
    ):
        return False
    if _off_capability is not None and not _consume_off_commit_capability(_off_capability):
        return False
    try:
        requested_known = dict(settings_data or {})
        requested_enabled = bool(requested_known.get("n_panel_state_save", True))
        if (_off_capability is None and not requested_enabled) or (
            _off_capability is not None and requested_enabled
        ):
            return False
    # Guard the lower writer before directory creation or any filesystem effect.
        path = n_panel_settings_path(create=False)
        central_path = _central_settings_path(path)
        existing, existing_source, existing_generation = _load_settings_payload_details(repair_main=False)
        candidate_paths = (path, central_path, *storage.legacy_n_panel_settings_candidates(path))
        any_existing_candidate = any(bool(candidate.exists()) for candidate in candidate_paths)
        if any_existing_candidate and existing is None:
        # Existing unreadable/malformed data is never silently replaced.
            _mark_persistence_dirty(None)
            return False
        existing_settings = existing.get("settings") if isinstance(existing, dict) else None
        requested_settings = dict(existing_settings) if isinstance(existing_settings, dict) else {}
    # Preserve unknown nested settings while known portable keys take authority.
        requested_settings.update(requested_known)

        same_payload = isinstance(existing, dict) and existing.get("settings") == requested_settings
        if same_payload and existing_source == path:
        # The authoritative main itself is valid and already contains the exact
        # requested generation/settings. Only then may a no-op save clear dirty.
            try:
                payload_key = json.dumps(existing, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            except Exception:
                payload_key = ""
            _LAST_WRITTEN_SETTINGS_KEY = payload_key
            _PERSISTENCE_APPLIED_ONCE = True
            _PERSISTENCE_DIRTY = False
            _PENDING_SETTINGS_SNAPSHOT = None
            _PENDING_SETTINGS_KEY = ""
            return True

        if same_payload and isinstance(existing, dict):
        # A newer central/backup copy may exist after a failed main replace. A
        # retry with unchanged settings must repair and validate main rather than
        # incorrectly reporting success from the recovery copy alone.
            generation = int(existing_generation)
            payload = dict(existing)
            readback = storage.atomic_write_json(
                path, payload, indent=2, ensure_ascii=False, sort_keys=True,
                validator=_validate_settings_payload, generation=generation, max_backups=3,
            )
            if not _validate_settings_payload(readback):
                raise ValueError("N-panel settings repair readback validation failed")
            payload_key = json.dumps(readback, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        else:
            generation = int(existing_generation) + 1
            payload = _build_settings_payload(
            requested_settings,
            generation,
            path,
            base_payload=existing,
        )
            # The central mirror is written first. If the main replace fails,
            # the operation remains dirty/failed while the validated newest
            # generation remains recoverable on the next load/retry.
            storage.atomic_write_json(
                central_path, payload, indent=2, ensure_ascii=False, sort_keys=True,
                validator=_validate_settings_payload, generation=generation, max_backups=3,
            )
            readback = storage.atomic_write_json(
                path, payload, indent=2, ensure_ascii=False, sort_keys=True,
                validator=_validate_settings_payload, generation=generation, max_backups=3,
            )
            if not _validate_settings_payload(readback):
                raise ValueError("N-panel settings readback validation failed")
            payload_key = json.dumps(readback, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        _LAST_WRITTEN_SETTINGS_KEY = payload_key
        _PERSISTENCE_APPLIED_ONCE = True
        _PERSISTENCE_DIRTY = False
        _PENDING_SETTINGS_SNAPSHOT = None
        _PENDING_SETTINGS_KEY = ""
        return True
    except Exception:
        _mark_persistence_dirty(None)
        return False
    finally:
        if _off_capability is not None:
            _retire_off_commit_capability(_off_capability)

def flush_deferred_n_panel_settings(
    context=None,
    *,
    allow_disabled_commit: bool = False,
    _off_capability=None,
) -> bool:
    global _PERSISTENCE_DIRTY, _PENDING_SETTINGS_SNAPSHOT
    ordinary_ready = bool(
        globals().get("_PERSISTENCE_AUTHORITY_PHASE") == "READY"
        and int(globals().get("_RESTORE_BARRIER_DEPTH", 0) or 0) == 0
        and not bool(globals().get("_PERSISTENCE_APPLYING", False))
        and globals().get("_LIVE_STATE_SAVE_ENABLED") is True
        and globals().get("_LIVE_SETTINGS_IDENTITY") is not None
        and callable(globals().get("_live_authority_identity_valid"))
        and globals()["_live_authority_identity_valid"]()
    )
    off_ready = bool(
        _off_capability is not None
        and callable(globals().get("_off_commit_capability_valid"))
        and globals()["_off_commit_capability_valid"](_off_capability)
    )
    if allow_disabled_commit or not (ordinary_ready if _off_capability is None else off_ready):
        return False
    if not _PERSISTENCE_DIRTY:
        return False
    settings = get_settings(context)
    snapshot = _PENDING_SETTINGS_SNAPSHOT
    if not snapshot:
        if settings is None:
            return False
        snapshot = settings_to_dict(settings)
    return _write_n_panel_settings_payload(
        dict(snapshot),
        _off_capability=_off_capability,
    )


def save_n_panel_settings(
    context=None,
    *,
    force: bool = True,
    allow_disabled_commit: bool = False,
    _off_capability=None,
) -> bool:
    ordinary_ready = bool(
        globals().get("_PERSISTENCE_AUTHORITY_PHASE") == "READY"
        and int(globals().get("_RESTORE_BARRIER_DEPTH", 0) or 0) == 0
        and not bool(globals().get("_PERSISTENCE_APPLYING", False))
        and globals().get("_LIVE_STATE_SAVE_ENABLED") is True
        and globals().get("_LIVE_SETTINGS_IDENTITY") is not None
        and callable(globals().get("_live_authority_identity_valid"))
        and globals()["_live_authority_identity_valid"]()
    )
    off_ready = bool(
        _off_capability is not None
        and callable(globals().get("_off_commit_capability_valid"))
        and globals()["_off_commit_capability_valid"](_off_capability)
    )
    if allow_disabled_commit or not (ordinary_ready if _off_capability is None else off_ready):
        return False
    settings = get_settings(context)
    if settings is None:
        return False
    if not _settings_matches_live_identity(settings):
        return False
    return _write_n_panel_settings_payload(
        settings_to_dict(settings),
        _off_capability=_off_capability,
    )


def load_n_panel_settings() -> dict[str, Any]:
    try:
        # Restoration is strictly read-only; repair is an explicit later write.
        data, _generation = _load_settings_payload(repair_main=False)
    except Exception:
        return {}
    if not isinstance(data, dict) or not _validate_settings_payload(data):
        return {}
    raw = data.get("settings")
    result: dict[str, Any] = {}
    for name in _iter_persistent_setting_names():
        if isinstance(raw, dict) and name in raw:
            result[name] = raw[name]
    return result

def persisted_setting_value(name: str, default: Any = None) -> Any:
    try:
        return load_n_panel_settings().get(name, default)
    except Exception:
        return default


def _mark_applied_once() -> None:
    global _PERSISTENCE_APPLIED_ONCE
    _PERSISTENCE_APPLIED_ONCE = True


def apply_n_panel_settings(context=None, *, save_after: bool = False) -> bool:
    settings = None
    try:
        # The authority barrier precedes even lazy RNA lookup. This prevents a
        # cold default-ON instance from writing over an existing saved-OFF file.
        with _persistence_restore_barrier():
            settings = get_settings(context)
            if settings is None:
                return False
            payload, _source, _generation = _load_settings_payload_details(repair_main=False)
            if payload is None:
                # Missing is a fresh profile. Existing-but-invalid/unreadable is
                # not: remain cold so lazy default ON can never authorize writes.
                if _any_settings_candidate_exists():
                    return False
                # Fresh profile: establish default resources without creating a
                # file. READY authority is published only after this scope exits.
                if not _sync_persistence_hooks_for_settings(settings):
                    return False
                data = None
            else:
                raw = payload.get("settings")
                if not isinstance(raw, dict):
                    return False
                data = {
                    name: raw[name]
                    for name in _iter_persistent_setting_names()
                    if name in raw
                }
            if data is None:
                pass
            else:
                from . import transaction
                with transaction.operation_transaction("settings.apply_n_panel") as (active, owner):
                    for name, value in data.items():
                        if hasattr(settings, name):
                            transaction.set_attr(settings, name, value)
                    from . import persistent_features
                    persistent_features.apply_all_persistent_features(context)
                    if bool(getattr(settings, "show_section_catalog", False)):
                        from . import catalog
                        catalog.ensure_loaded()
                    active.add_commit(
                        lambda: _require_persistence_resource_state(settings)
                    )
                    active.add_commit(_mark_applied_once)
                    if owner:
                        active.commit()
        return _establish_ready_authority(settings)
    except Exception:
        return False


def _clear_deferred_restore_record() -> None:
    global _DEFERRED_RESTORE_CALLBACK, _DEFERRED_RESTORE_ATTEMPTS
    global _DEFERRED_RESTORE_TOKEN, _DEFERRED_RESTORE_GENERATION, _DEFERRED_RESTORE_SERIAL
    _DEFERRED_RESTORE_CALLBACK = None
    _DEFERRED_RESTORE_ATTEMPTS = 0
    _DEFERRED_RESTORE_TOKEN = ""
    _DEFERRED_RESTORE_GENERATION = 0
    _DEFERRED_RESTORE_SERIAL = 0


def _cancel_deferred_restore() -> None:
    callback = _DEFERRED_RESTORE_CALLBACK
    timers = getattr(getattr(bpy, "app", None), "timers", None)
    if callback is not None and timers is not None:
        try:
            if bool(timers.is_registered(callback)):
                timers.unregister(callback)
        except Exception:
            pass
    _clear_deferred_restore_record()


def _deferred_restore_once():
    """Bounded context-ready restore; never becomes a settings poller."""
    global _DEFERRED_RESTORE_ATTEMPTS
    if _DEFERRED_RESTORE_CALLBACK is not _deferred_restore_once:
        return None
    token, generation = _current_lifecycle_identity()
    if (
        token != _DEFERRED_RESTORE_TOKEN
        or generation != _DEFERRED_RESTORE_GENERATION
        or _LOCAL_MUTATION_SERIAL != _DEFERRED_RESTORE_SERIAL
        or not _rna_registration_identity_valid()
    ):
        _clear_deferred_restore_record()
        return None
    # Only after all ownership/staleness guards may context or disk be touched.
    settings = get_settings(getattr(bpy, "context", None))
    if settings is None:
        _DEFERRED_RESTORE_ATTEMPTS += 1
        if _DEFERRED_RESTORE_ATTEMPTS < _DEFERRED_RESTORE_MAX_ATTEMPTS:
            return 0.05
        _clear_deferred_restore_record()
        return None
    _clear_deferred_restore_record()
    apply_n_panel_settings(getattr(bpy, "context", None))
    return None


def _schedule_deferred_restore() -> bool:
    global _DEFERRED_RESTORE_CALLBACK, _DEFERRED_RESTORE_ATTEMPTS
    global _DEFERRED_RESTORE_TOKEN, _DEFERRED_RESTORE_GENERATION, _DEFERRED_RESTORE_SERIAL
    _cancel_deferred_restore()
    token, generation = _current_lifecycle_identity()
    if not token or generation <= 0:
        return False
    timers = getattr(getattr(bpy, "app", None), "timers", None)
    register_timer = getattr(timers, "register", None)
    if not callable(register_timer):
        return False
    _DEFERRED_RESTORE_CALLBACK = _deferred_restore_once
    _DEFERRED_RESTORE_ATTEMPTS = 0
    _DEFERRED_RESTORE_TOKEN = token
    _DEFERRED_RESTORE_GENERATION = generation
    _DEFERRED_RESTORE_SERIAL = _LOCAL_MUTATION_SERIAL
    try:
        register_timer(_deferred_restore_once, first_interval=0.0, persistent=False)
    except Exception:
        _clear_deferred_restore_record()
        return False
    return True


@persistent
def _handler_save(_dummy=None) -> None:
    if not _ordinary_writer_authorized():
        return
    try:
        save_n_panel_settings(getattr(bpy, "context", None), force=True)
    except Exception:
        pass


@persistent
def _handler_scene_close(_dummy=None) -> None:
    if not _ordinary_writer_authorized():
        return
    try:
        # State-save OFF blocks this writer; no force/fallback path bypasses it.
        save_n_panel_settings(getattr(bpy, "context", None), force=True)
    except Exception:
        pass


@persistent
def _handler_load(_dummy=None) -> None:
    _cancel_deferred_restore()
    applied = False
    try:
        applied = bool(apply_n_panel_settings())
    except Exception:
        pass
    if applied and _LIVE_STATE_SAVE_ENABLED is True:
        _resubscribe_scene_change_subscription()


def _on_active_scene_changed() -> None:
    """Apply the canonical profile to the newly active Scene, event-only."""
    if _PERSISTENCE_APPLYING:
        return
    try:
        apply_n_panel_settings()
    except Exception:
        pass


@persistent
def _handler_undo_redo(_dummy=None) -> None:
    if not _ordinary_writer_authorized():
        return
    try:
        settings = get_settings(getattr(bpy, "context", None))
        if settings is None or not _settings_auto_save_enabled(settings):
            return
        # Sync external JSON only on the Undo/Redo event; do not reapply scene
        # guards or introduce a timer/polling loop.
        save_n_panel_settings(getattr(bpy, "context", None), force=False)
    except Exception:
        pass


def _lifecycle_identity_for_resource() -> tuple[str, int]:
    try:
        return _current_lifecycle_identity()
    except Exception:
        return "", 0


def _handler_collection(name: str):
    handlers = getattr(getattr(bpy, "app", None), "handlers", None)
    return getattr(handlers, str(name), None) if handlers is not None else None


def _remove_exact_callback(collection, callback) -> None:
    if collection is None or callback is None:
        return
    # Remove every duplicate occurrence of this exact object. Blender handler
    # collections are small; this is bounded to resources recorded by this suite.
    while True:
        try:
            collection.remove(callback)
        except (ValueError, RuntimeError, AttributeError):
            break


def _release_legacy_persistence_resources() -> None:
    global _LEGACY_SCENE_MSGBUS_OWNED
    legacy = _LEGACY_PERSISTENCE_HANDLER_OWNERS
    for name, callback in tuple(legacy):
        _remove_exact_callback(_handler_collection(str(name)), callback)
        try:
            legacy.discard((name, callback))
        except Exception:
            pass
    if _LEGACY_SCENE_MSGBUS_OWNED and _LEGACY_SCENE_MSGBUS_OWNER is not None:
        try:
            bpy.msgbus.clear_by_owner(_LEGACY_SCENE_MSGBUS_OWNER)
        except Exception:
            pass
    _LEGACY_SCENE_MSGBUS_OWNED = False


def _handler_record_is_ours(record: object) -> bool:
    return bool(
        isinstance(record, dict)
        and str(record.get("owner", "")) == _PROPERTY_OWNER
        and str(record.get("package", "")) == _PROPERTY_PACKAGE
        and record.get("callback") is not None
    )


def _remove_handler_record(record: dict[str, Any]) -> None:
    _remove_exact_callback(_handler_collection(str(record.get("name", ""))), record.get("callback"))
    try:
        _PERSISTENCE_HANDLER_RECORDS.remove(record)
    except ValueError:
        pass


def _release_stale_handler_records(token: str, generation: int) -> None:
    for record in tuple(_PERSISTENCE_HANDLER_RECORDS):
        if not _handler_record_is_ours(record):
            continue
        if str(record.get("token", "")) != str(token) or int(record.get("generation", -1)) != int(generation):
            _remove_handler_record(record)


def _append_handler_exact(name: str, fn) -> bool:
    token, generation = _lifecycle_identity_for_resource()
    if not token or generation <= 0:
        return False
    collection = _handler_collection(name)
    if collection is None:
        return False
    _release_stale_handler_records(token, generation)
    matches = [
        record for record in _PERSISTENCE_HANDLER_RECORDS
        if _handler_record_is_ours(record)
        and str(record.get("token", "")) == token
        and int(record.get("generation", -1)) == generation
        and str(record.get("name", "")) == str(name)
        and record.get("callback") is fn
    ]
    # Collapse only exact self-owned duplicates; no other callback is inspected.
    _remove_exact_callback(collection, fn)
    try:
        collection.append(fn)
    except Exception:
        return False
    if matches:
        keep = matches[0]
        for duplicate in matches[1:]:
            try:
                _PERSISTENCE_HANDLER_RECORDS.remove(duplicate)
            except ValueError:
                pass
        keep["active"] = True
    else:
        _PERSISTENCE_HANDLER_RECORDS.append({
            "owner": _PROPERTY_OWNER,
            "package": _PROPERTY_PACKAGE,
            "token": token,
            "generation": generation,
            "name": str(name),
            "callback": fn,
            "active": True,
        })
    return sum(1 for item in collection if item is fn) == 1


def _remove_owned_handlers() -> None:
    for record in reversed(tuple(_PERSISTENCE_HANDLER_RECORDS)):
        if _handler_record_is_ours(record):
            _remove_handler_record(record)
    _release_legacy_persistence_resources()


def _handler_resources_identity_valid() -> bool:
    token, generation = _lifecycle_identity_for_resource()
    expected = (
        ("load_pre", _handler_scene_close),
        ("load_post", _handler_load),
        ("undo_post", _handler_undo_redo),
        ("redo_post", _handler_undo_redo),
    )
    current = [
        record for record in _PERSISTENCE_HANDLER_RECORDS
        if _handler_record_is_ours(record)
        and str(record.get("token", "")) == token
        and int(record.get("generation", -1)) == generation
    ]
    if len(current) != len(expected):
        return False
    for name, callback in expected:
        records = [r for r in current if str(r.get("name", "")) == name and r.get("callback") is callback]
        collection = _handler_collection(name)
        if len(records) != 1 or collection is None or sum(1 for item in collection if item is callback) != 1:
            return False
    return True


def _msgbus_record_is_ours(record: object) -> bool:
    return bool(
        isinstance(record, dict)
        and str(record.get("owner_name", "")) == _PROPERTY_OWNER
        and str(record.get("package", "")) == _PROPERTY_PACKAGE
        and record.get("owner") is not None
    )


def _clear_msgbus_record(record: dict[str, Any]) -> None:
    owner = record.get("owner")
    if owner is not None:
        try:
            bpy.msgbus.clear_by_owner(owner)
        except Exception:
            pass
    record["active"] = False
    try:
        _SCENE_MSGBUS_RECORDS.remove(record)
    except ValueError:
        pass


def _release_stale_msgbus_records(token: str, generation: int) -> None:
    for record in tuple(_SCENE_MSGBUS_RECORDS):
        if not _msgbus_record_is_ours(record):
            continue
        if str(record.get("token", "")) != str(token) or int(record.get("generation", -1)) != int(generation):
            _clear_msgbus_record(record)


def _register_scene_change_subscription(*, resubscribe: bool = False) -> bool:
    global _SCENE_MSGBUS_OWNER, _SCENE_MSGBUS_OWNED
    token, generation = _lifecycle_identity_for_resource()
    if not token or generation <= 0:
        return False
    _release_legacy_persistence_resources()
    _release_stale_msgbus_records(token, generation)
    matches = [
        record for record in _SCENE_MSGBUS_RECORDS
        if _msgbus_record_is_ours(record)
        and str(record.get("token", "")) == token
        and int(record.get("generation", -1)) == generation
    ]
    record = matches[0] if matches else None
    for duplicate in matches[1:]:
        _clear_msgbus_record(duplicate)
    if record is None:
        record = {
            "owner_name": _PROPERTY_OWNER,
            "package": _PROPERTY_PACKAGE,
            "token": token,
            "generation": generation,
            "owner": object(),
            "notify": _on_active_scene_changed,
            "active": False,
        }
        _SCENE_MSGBUS_RECORDS.append(record)
    if resubscribe and bool(record.get("active", False)):
        try:
            bpy.msgbus.clear_by_owner(record["owner"])
        except Exception:
            pass
        record["active"] = False
    if not bool(record.get("active", False)):
        try:
            bpy.msgbus.subscribe_rna(
                key=(bpy.types.Window, "scene"),
                owner=record["owner"],
                args=(),
                notify=_on_active_scene_changed,
                options={"PERSISTENT"},
            )
        except Exception:
            _clear_msgbus_record(record)
            _SCENE_MSGBUS_OWNER = None
            _SCENE_MSGBUS_OWNED = False
            return False
        record["notify"] = _on_active_scene_changed
        record["active"] = True
    _SCENE_MSGBUS_OWNER = record["owner"]
    _SCENE_MSGBUS_OWNED = True
    return True


def _resubscribe_scene_change_subscription() -> bool:
    # load_post can invalidate msgbus internals. Clear and recreate this exact
    # generation's owner once; old owners are never left subscribed.
    return _register_scene_change_subscription(resubscribe=True)


def _unregister_scene_change_subscription() -> None:
    global _SCENE_MSGBUS_OWNER, _SCENE_MSGBUS_OWNED
    for record in reversed(tuple(_SCENE_MSGBUS_RECORDS)):
        if _msgbus_record_is_ours(record):
            _clear_msgbus_record(record)
    _release_legacy_persistence_resources()
    _SCENE_MSGBUS_OWNER = None
    _SCENE_MSGBUS_OWNED = False


def _msgbus_resource_identity_valid() -> bool:
    token, generation = _lifecycle_identity_for_resource()
    current = [
        record for record in _SCENE_MSGBUS_RECORDS
        if _msgbus_record_is_ours(record)
        and str(record.get("token", "")) == token
        and int(record.get("generation", -1)) == generation
        and bool(record.get("active", False))
        and record.get("notify") is _on_active_scene_changed
    ]
    return bool(
        len(current) == 1
        and _SCENE_MSGBUS_OWNED
        and _SCENE_MSGBUS_OWNER is current[0].get("owner")
    )


def _register_persistence_hooks() -> bool:
    # Event-only hooks. There is no startup timer, watchdog, idle poll, or redraw.
    _release_legacy_persistence_resources()
    token, generation = _lifecycle_identity_for_resource()
    _release_stale_handler_records(token, generation)
    _release_stale_msgbus_records(token, generation)
    for name, callback in (
        ("load_pre", _handler_scene_close),
        ("load_post", _handler_load),
        ("undo_post", _handler_undo_redo),
        ("redo_post", _handler_undo_redo),
    ):
        if not _append_handler_exact(name, callback):
            _unregister_persistence_hooks()
            return False
    if not _register_scene_change_subscription():
        _unregister_persistence_hooks()
        return False
    return _handler_resources_identity_valid() and _msgbus_resource_identity_valid()


def _unregister_persistence_hooks() -> None:
    _unregister_scene_change_subscription()
    _remove_owned_handlers()


def _persistence_hooks_identity_valid() -> bool:
    return _handler_resources_identity_valid() and _msgbus_resource_identity_valid()


def _persistence_hooks_released() -> bool:
    own_handlers = any(_handler_record_is_ours(record) for record in _PERSISTENCE_HANDLER_RECORDS)
    own_msgbus = any(_msgbus_record_is_ours(record) for record in _SCENE_MSGBUS_RECORDS)
    return not own_handlers and not own_msgbus and not _SCENE_MSGBUS_OWNED


def _sync_persistence_hooks_for_settings(settings) -> bool:
    """Make the state-save toggle own either all exact hooks or none."""
    if _settings_auto_save_enabled(settings):
        return _register_persistence_hooks()
    _unregister_persistence_hooks()
    return _persistence_hooks_released()


def _require_persistence_resource_state(settings) -> None:
    if not _sync_persistence_hooks_for_settings(settings):
        raise RuntimeError("PERSISTENCE_RESOURCE_IDENTITY_FAILED")


def _persistence_resource_state_valid() -> bool:
    # Do not call get_settings() here: this predicate is part of that public
    # registration validity boundary. RNA identity has already been validated.
    scene = getattr(getattr(bpy, "context", None), "scene", None)
    settings = getattr(scene, SCENE_PROPERTY_NAME, None) if scene is not None else None
    if settings is None:
        return _PERSISTENCE_AUTHORITY_PHASE == "COLD" and _persistence_hooks_released()
    if (
        _PERSISTENCE_AUTHORITY_PHASE != "READY"
        or not _settings_matches_live_identity(settings)
        or _LIVE_STATE_SAVE_ENABLED is None
    ):
        return False
    if _LIVE_STATE_SAVE_ENABLED:
        return _persistence_hooks_identity_valid()
    return _persistence_hooks_released()


PROPERTY_GROUP_CLASSES = (SCS_Settings,)
SCENE_PROPERTY_NAME = "scs_settings"
_PROPERTY_OWNER = "JELararagi"
_PROPERTY_PACKAGE = "smart_composite_suite"
_CLASS_OWNER_TOKEN_ATTR = "_scs_property_owner_token"
_CLASS_OWNER_GENERATION_ATTR = "_scs_property_owner_generation"
_CLASS_OWNER_PACKAGE_ATTR = "_scs_property_owner_package"

# importlib.reload preserves the module dictionary.  These fields therefore keep
# the exact class and Scene descriptor objects acquired by the previous source
# generation; no bpy.types/name search is needed or permitted.
_PROPERTY_REGISTERED = bool(globals().get("_PROPERTY_REGISTERED", False))
_REGISTERED_PROPERTY_CLASSES: list[type] = (
    globals().get("_REGISTERED_PROPERTY_CLASSES")
    if isinstance(globals().get("_REGISTERED_PROPERTY_CLASSES"), list)
    else []
)
_SCENE_POINTER_IDENTITY = globals().get("_SCENE_POINTER_IDENTITY")
_PROPERTY_OWNER_TOKEN = str(globals().get("_PROPERTY_OWNER_TOKEN", "") or "")
_PROPERTY_GENERATION = int(globals().get("_PROPERTY_GENERATION", 0) or 0)
_PROPERTY_PHASE = str(globals().get("_PROPERTY_PHASE", "IDLE") or "IDLE")
_PROPERTY_DEGRADED_REASON = str(globals().get("_PROPERTY_DEGRADED_REASON", "") or "")
_FOREIGN_SCENE_POINTER_IDENTITY = globals().get("_FOREIGN_SCENE_POINTER_IDENTITY")


def _static_scene_pointer():
    try:
        return inspect.getattr_static(bpy.types.Scene, SCENE_PROPERTY_NAME)
    except Exception:
        return None


def _current_lifecycle_identity() -> tuple[str, int]:
    """Return the outer exact lifecycle token/generation without mutating it."""
    try:
        from . import registration
        token = str(registration.current_owner_token() or "")
        generation = int(registration.current_generation() or 0)
    except Exception:
        return "", 0
    if not token or token == "unregistered" or generation <= 0:
        return "", 0
    return token, generation


def _class_is_registered_exact(cls: type) -> bool:
    try:
        return bool(getattr(cls, "is_registered", False))
    except Exception:
        return False


def _mark_class_owner(cls: type, token: str, generation: int) -> bool:
    try:
        setattr(cls, _CLASS_OWNER_TOKEN_ATTR, str(token))
        setattr(cls, _CLASS_OWNER_GENERATION_ATTR, int(generation))
        setattr(cls, _CLASS_OWNER_PACKAGE_ATTR, _PROPERTY_PACKAGE)
        return True
    except Exception:
        return False


def _class_owner_matches(cls: type, token: str, generation: int) -> bool:
    try:
        return bool(
            str(getattr(cls, _CLASS_OWNER_PACKAGE_ATTR, "") or "") == _PROPERTY_PACKAGE
            and str(getattr(cls, _CLASS_OWNER_TOKEN_ATTR, "") or "") == str(token)
            and int(getattr(cls, _CLASS_OWNER_GENERATION_ATTR, -1)) == int(generation)
        )
    except Exception:
        return False


def _migrate_preserved_0735_identity() -> None:
    """Attach token metadata to an exact older ledger preserved by reload.

    Older loads already retained exact class and PointerProperty objects in module
    globals, but did not stamp the outer owner token/generation.  Migration is
    allowed only when that exact descriptor is still installed and the outer
    lifecycle exposes a valid token.  No name-based RNA lookup is performed.
    """
    global _PROPERTY_OWNER_TOKEN, _PROPERTY_GENERATION
    if not _PROPERTY_REGISTERED or _SCENE_POINTER_IDENTITY is None:
        return
    if _static_scene_pointer() is not _SCENE_POINTER_IDENTITY:
        return
    if _PROPERTY_OWNER_TOKEN and _PROPERTY_GENERATION > 0:
        return
    token, generation = _current_lifecycle_identity()
    if not token or generation <= 0:
        return
    if not _REGISTERED_PROPERTY_CLASSES:
        return
    _PROPERTY_OWNER_TOKEN = token
    _PROPERTY_GENERATION = generation
    for cls in tuple(_REGISTERED_PROPERTY_CLASSES):
        _mark_class_owner(cls, token, generation)


def _owned_generation_exact() -> bool:
    if not _PROPERTY_REGISTERED:
        return False
    if not _PROPERTY_OWNER_TOKEN or _PROPERTY_GENERATION <= 0:
        return False
    if _SCENE_POINTER_IDENTITY is None or _static_scene_pointer() is not _SCENE_POINTER_IDENTITY:
        return False
    if not _REGISTERED_PROPERTY_CLASSES:
        return False
    return all(
        isinstance(cls, type)
        and _class_is_registered_exact(cls)
        and _class_owner_matches(cls, _PROPERTY_OWNER_TOKEN, _PROPERTY_GENERATION)
        for cls in tuple(_REGISTERED_PROPERTY_CLASSES)
    )


def _set_degraded(reason: str, foreign_pointer=None) -> None:
    global _PROPERTY_REGISTERED, _PROPERTY_PHASE, _PROPERTY_DEGRADED_REASON
    global _FOREIGN_SCENE_POINTER_IDENTITY
    # A degraded RNA state never keeps event resources from a prior generation.
    _unregister_persistence_hooks()
    _PROPERTY_REGISTERED = False
    _PROPERTY_PHASE = "DEGRADED"
    _PROPERTY_DEGRADED_REASON = str(reason or "REGISTRATION_UNAVAILABLE")
    _FOREIGN_SCENE_POINTER_IDENTITY = foreign_pointer


def _clear_degraded() -> None:
    global _PROPERTY_DEGRADED_REASON, _FOREIGN_SCENE_POINTER_IDENTITY
    _PROPERTY_DEGRADED_REASON = ""
    _FOREIGN_SCENE_POINTER_IDENTITY = None


def _remove_scene_pointer_exact(pointer_identity, token: str, generation: int) -> bool:
    """Remove only the descriptor acquired by this exact owner generation."""
    if pointer_identity is None:
        return True
    if str(token or "") != _PROPERTY_OWNER_TOKEN or int(generation) != _PROPERTY_GENERATION:
        return False
    if _static_scene_pointer() is not pointer_identity:
        return False
    try:
        delattr(bpy.types.Scene, SCENE_PROPERTY_NAME)
    except Exception:
        return False
    return _static_scene_pointer() is not pointer_identity


def _unregister_property_class_exact(cls: type, token: str, generation: int) -> bool:
    """Unregister one exact self-owned class; never resolve a class by name."""
    if cls not in _REGISTERED_PROPERTY_CLASSES:
        return True
    if not _class_owner_matches(cls, token, generation):
        return False
    if _class_is_registered_exact(cls):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            return False
        if _class_is_registered_exact(cls):
            return False
    try:
        _REGISTERED_PROPERTY_CLASSES.remove(cls)
    except ValueError:
        pass
    return True


def _release_owned_generation_exact() -> bool:
    """Release the preserved self-owned generation in dependency-safe order."""
    global _PROPERTY_REGISTERED, _SCENE_POINTER_IDENTITY
    global _PROPERTY_OWNER_TOKEN, _PROPERTY_GENERATION, _PROPERTY_PHASE
    if not _owned_generation_exact():
        return False
    token = _PROPERTY_OWNER_TOKEN
    generation = _PROPERTY_GENERATION
    pointer = _SCENE_POINTER_IDENTITY
    # The PointerProperty must disappear before its PropertyGroup class.
    if not _remove_scene_pointer_exact(pointer, token, generation):
        return False
    _SCENE_POINTER_IDENTITY = None
    for cls in reversed(tuple(_REGISTERED_PROPERTY_CLASSES)):
        if not _unregister_property_class_exact(cls, token, generation):
            return False
    _PROPERTY_REGISTERED = False
    _PROPERTY_OWNER_TOKEN = ""
    _PROPERTY_GENERATION = 0
    _PROPERTY_PHASE = "IDLE"
    return True


def _rollback_new_generation_exact(token: str, generation: int) -> bool:
    """Rollback only objects acquired during the current register() call."""
    global _PROPERTY_REGISTERED, _SCENE_POINTER_IDENTITY
    global _PROPERTY_OWNER_TOKEN, _PROPERTY_GENERATION, _PROPERTY_PHASE
    ok = True
    pointer = _SCENE_POINTER_IDENTITY
    if pointer is not None:
        if _remove_scene_pointer_exact(pointer, token, generation):
            _SCENE_POINTER_IDENTITY = None
        else:
            ok = False
    for cls in reversed(tuple(_REGISTERED_PROPERTY_CLASSES)):
        if _class_owner_matches(cls, token, generation):
            if not _unregister_property_class_exact(cls, token, generation):
                ok = False
    if ok:
        _PROPERTY_REGISTERED = False
        _PROPERTY_OWNER_TOKEN = ""
        _PROPERTY_GENERATION = 0
        _PROPERTY_PHASE = "IDLE"
    return ok


def _register_property_class_exact(cls: type, token: str, generation: int) -> bool:
    """Register only the supplied class identity; there is no stale fallback."""
    if not _mark_class_owner(cls, token, generation):
        return False
    try:
        bpy.utils.register_class(cls)
    except Exception:
        # Some Blender/native failure paths can raise after installing the exact
        # class object. Retain that exact identity so the caller's rollback can
        # unregister it; never adopt or search a stale class by RNA name.
        if _class_is_registered_exact(cls) and cls not in _REGISTERED_PROPERTY_CLASSES:
            _REGISTERED_PROPERTY_CLASSES.append(cls)
        return False
    if not _class_is_registered_exact(cls):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
        return False
    _REGISTERED_PROPERTY_CLASSES.append(cls)
    return True


def _rna_registration_identity_valid() -> bool:
    if not _PROPERTY_REGISTERED or _PROPERTY_PHASE != "READY":
        return False
    token, generation = _current_lifecycle_identity()
    if not token or token != _PROPERTY_OWNER_TOKEN or generation != _PROPERTY_GENERATION:
        return False
    if tuple(_REGISTERED_PROPERTY_CLASSES) != PROPERTY_GROUP_CLASSES:
        return False
    if not all(
        _class_is_registered_exact(cls)
        and _class_owner_matches(cls, token, generation)
        for cls in PROPERTY_GROUP_CLASSES
    ):
        return False
    return bool(
        _SCENE_POINTER_IDENTITY is not None
        and _static_scene_pointer() is _SCENE_POINTER_IDENTITY
    )


def registration_identity_valid() -> bool:
    return bool(_rna_registration_identity_valid() and _persistence_resource_state_valid())


def degraded_registration_valid() -> bool:
    if _PROPERTY_PHASE != "DEGRADED" or not _PROPERTY_DEGRADED_REASON:
        return False
    if _PROPERTY_REGISTERED or _REGISTERED_PROPERTY_CLASSES or _SCENE_POINTER_IDENTITY is not None:
        return False
    if not _persistence_hooks_released():
        return False
    if _FOREIGN_SCENE_POINTER_IDENTITY is None:
        return _static_scene_pointer() is None
    return _static_scene_pointer() is _FOREIGN_SCENE_POINTER_IDENTITY


def safe_degradation_active() -> bool:
    return bool(degraded_registration_valid())


def registration_degraded_reason() -> str:
    return str(_PROPERTY_DEGRADED_REASON or "") if safe_degradation_active() else ""


def registration_state_snapshot() -> dict[str, Any]:
    live = _LIVE_SETTINGS_IDENTITY if isinstance(_LIVE_SETTINGS_IDENTITY, dict) else {}
    return {
        "phase": str(_PROPERTY_PHASE),
        "owner": _PROPERTY_OWNER,
        "package": _PROPERTY_PACKAGE,
        "owner_token": str(_PROPERTY_OWNER_TOKEN),
        "generation": int(_PROPERTY_GENERATION),
        "registered_class_ids": tuple(id(cls) for cls in _REGISTERED_PROPERTY_CLASSES),
        "pointer_identity_id": id(_SCENE_POINTER_IDENTITY) if _SCENE_POINTER_IDENTITY is not None else 0,
        "foreign_pointer_identity_id": id(_FOREIGN_SCENE_POINTER_IDENTITY) if _FOREIGN_SCENE_POINTER_IDENTITY is not None else 0,
        "degraded_reason": registration_degraded_reason(),
        "handler_record_count": sum(1 for record in _PERSISTENCE_HANDLER_RECORDS if _handler_record_is_ours(record)),
        "msgbus_record_count": sum(1 for record in _SCENE_MSGBUS_RECORDS if _msgbus_record_is_ours(record)),
        "persistence_hooks_valid": _persistence_hooks_identity_valid() if _PROPERTY_PHASE == "READY" else False,
        "persistence_authority_phase": str(_PERSISTENCE_AUTHORITY_PHASE),
        "live_state_save_enabled": _LIVE_STATE_SAVE_ENABLED,
        "live_settings_pointer": int(live.get("settings_pointer", 0) or 0),
        "live_scene_pointer": int(live.get("scene_pointer", 0) or 0),
        "live_identity_valid": _live_authority_identity_valid() if live else False,
    }


def registered_class_identities() -> tuple[type, ...]:
    return tuple(_REGISTERED_PROPERTY_CLASSES)


def pointer_identity():
    return _SCENE_POINTER_IDENTITY


def get_settings(context=None):
    """Return only this generation's exact Scene settings instance.

    A foreign ``Scene.scs_settings`` descriptor is deliberately hidden from all
    Smart Composite code so operators and draw functions cannot read or mutate
    another add-on's data while the suite is in safe degradation mode.
    """
    if not _rna_registration_identity_valid():
        return None
    ctx = context or getattr(bpy, "context", None)
    scene = getattr(ctx, "scene", None)
    return getattr(scene, SCENE_PROPERTY_NAME, None) if scene is not None else None


def register() -> bool:
    """Acquire Scene.scs_settings by exact owner token/generation identity.

    Self-owned preserved generations are released by their stored class and
    descriptor objects. A foreign descriptor or an unrecoverable registration
    conflict is never deleted and enters a non-throwing safe degradation state.
    """
    global _PROPERTY_REGISTERED, _SCENE_POINTER_IDENTITY
    global _PROPERTY_OWNER_TOKEN, _PROPERTY_GENERATION, _PROPERTY_PHASE

    _migrate_preserved_0735_identity()
    token, generation = _current_lifecycle_identity()
    if not token or generation <= 0:
        _unregister_persistence_hooks()
        _set_degraded("LIFECYCLE_IDENTITY_UNAVAILABLE", _static_scene_pointer())
        return False

    if registration_identity_valid():
        return True

    _enter_cold_authority()

    current_pointer = _static_scene_pointer()
    if _owned_generation_exact():
        _unregister_persistence_hooks()
        if not _release_owned_generation_exact():
            _set_degraded("EXACT_OLD_GENERATION_RELEASE_FAILED", current_pointer)
            return False
        current_pointer = _static_scene_pointer()
    elif _PROPERTY_REGISTERED or _REGISTERED_PROPERTY_CLASSES or _SCENE_POINTER_IDENTITY is not None:
        # Local flags exist but their exact class/descriptor identity no longer
        # matches. Never guess ownership or unregister a bpy.types name.
        _set_degraded("LOCAL_IDENTITY_MISMATCH", current_pointer)
        return False

    if current_pointer is not None:
        _set_degraded("FOREIGN_SCENE_POINTER", current_pointer)
        return False

    _clear_degraded()
    _PROPERTY_OWNER_TOKEN = token
    _PROPERTY_GENERATION = generation
    _PROPERTY_PHASE = "REGISTERING"

    for cls in PROPERTY_GROUP_CLASSES:
        if not _register_property_class_exact(cls, token, generation):
            _rollback_new_generation_exact(token, generation)
            _set_degraded("PROPERTY_GROUP_REGISTRATION_FAILED", _static_scene_pointer())
            return False

    # Recheck immediately before assignment so a concurrently registered foreign
    # descriptor is never overwritten by setattr.
    if _static_scene_pointer() is not None:
        _rollback_new_generation_exact(token, generation)
        foreign_pointer = _static_scene_pointer()
        _set_degraded("FOREIGN_SCENE_POINTER_RACE", foreign_pointer)
        return False

    try:
        setattr(bpy.types.Scene, SCENE_PROPERTY_NAME, PointerProperty(type=SCS_Settings))
    except Exception:
        _rollback_new_generation_exact(token, generation)
        _set_degraded("POINTER_REGISTRATION_FAILED", _static_scene_pointer())
        return False

    _SCENE_POINTER_IDENTITY = _static_scene_pointer()
    if _SCENE_POINTER_IDENTITY is None:
        _rollback_new_generation_exact(token, generation)
        _set_degraded("POINTER_IDENTITY_UNAVAILABLE", _static_scene_pointer())
        return False

    _PROPERTY_REGISTERED = True
    _PROPERTY_PHASE = "READY"
    if not _rna_registration_identity_valid():
        _rollback_new_generation_exact(token, generation)
        _set_degraded("PROPERTY_IDENTITY_VALIDATION_FAILED", _static_scene_pointer())
        return False

    try:
        # Apply only when Blender currently exposes an active Scene. Missing
        # settings are not created during registration.
        if get_settings(getattr(bpy, "context", None)) is not None:
            if not apply_n_panel_settings(getattr(bpy, "context", None)):
                raise RuntimeError("PERSISTENCE_RESOURCE_IDENTITY_FAILED")
        else:
            _unregister_persistence_hooks()
            # Restricted registration context: one exact, bounded and
            # cancelable context-ready callback. It never scans settings.
            _schedule_deferred_restore()
        if not registration_identity_valid():
            raise RuntimeError("PERSISTENCE_RESOURCE_IDENTITY_FAILED")
    except Exception:
        _unregister_persistence_hooks()
        _rollback_new_generation_exact(token, generation)
        _set_degraded("PERSISTENCE_HOOK_REGISTRATION_FAILED", _static_scene_pointer())
        return False
    return True


def unregister() -> bool:
    """Release only this exact owner generation; foreign data is untouched."""
    global _PROPERTY_REGISTERED, _SCENE_POINTER_IDENTITY
    global _PROPERTY_OWNER_TOKEN, _PROPERTY_GENERATION, _PROPERTY_PHASE

    _cancel_deferred_restore()

    if safe_degradation_active():
        _unregister_persistence_hooks()
        _clear_degraded()
        _PROPERTY_PHASE = "IDLE"
        _ENUM_ITEMS_CACHE.clear()
        _release_transient_persistence_refs()
        return True

    if not _PROPERTY_REGISTERED and not _REGISTERED_PROPERTY_CLASSES and _SCENE_POINTER_IDENTITY is None:
        _PROPERTY_PHASE = "IDLE"
        _clear_degraded()
        _ENUM_ITEMS_CACHE.clear()
        _release_transient_persistence_refs()
        return True

    if _ordinary_writer_authorized():
        try:
            flush_deferred_n_panel_settings(getattr(bpy, "context", None))
        except Exception:
            # Persistence failure must not broaden RNA ownership cleanup.
            pass
    _unregister_persistence_hooks()

    if not _owned_generation_exact():
        # An external replacement or identity loss is not ours to modify. Keep
        # the ledger so a later exact recovery can still release it safely.
        _PROPERTY_PHASE = "RELEASE_BLOCKED"
        _release_transient_persistence_refs()
        return False

    if not _release_owned_generation_exact():
        _PROPERTY_PHASE = "RELEASE_BLOCKED"
        _release_transient_persistence_refs()
        return False

    _clear_degraded()
    _ENUM_ITEMS_CACHE.clear()
    _release_transient_persistence_refs()
    return True


_migrate_preserved_0735_identity()
