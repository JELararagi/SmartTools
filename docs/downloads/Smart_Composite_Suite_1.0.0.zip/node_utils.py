# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from __future__ import annotations

import hashlib
import json
import re
from typing import Iterable, Sequence, Any
import unicodedata
import uuid

import bpy

from . import transaction as _tx
from .node_labels import display_label
from .translation import t

SCS_FLAG = "smart_composite_suite"  # retained legacy public constant; never used as ownership evidence
SCS_PREFIX = "SCS"                  # retained UI naming constant; never used as ownership evidence
SCS_CREATED_TREE_FLAG = "smart_composite_suite_created_tree"

_OWNER_ID = "smart_composite_suite"
_TREE_UUID_KEY = "_scs_tree_uuid_v2"
_TREE_CREATED_KEY = "_scs_tree_created_v2"
_TREE_OWNER_KEY = "_scs_tree_owner_v2"
_TREE_OWNER_TOKEN_KEY = "_scs_tree_owner_token_v2"
_TREE_FILE_GENERATION_KEY = "_scs_tree_file_generation_v2"
_TREE_SESSION_GENERATION_KEY = "_scs_tree_session_generation_v2"
_TREE_LEDGER_KEY = "_scs_node_ledger_v2"
_SCENE_FILE_GENERATION_KEY = "_scs_file_generation_v2"
_SCENE_RESOURCE_LEDGER_KEY = "_scs_resource_ledger_v2"
_NOTE_TEXT_KEY = "_scs_note_text_v2"
_NOTE_FONT_SIZE = 13
_NOTE_COLUMNS = 42
_NODE_UUID_KEY = "_scs_node_uuid_v2"
_NODE_OWNER_KEY = "_scs_node_owner_v2"
_NODE_OWNER_TOKEN_KEY = "_scs_node_owner_token_v2"
_NODE_FILE_GENERATION_KEY = "_scs_node_file_generation_v2"
_NODE_SESSION_GENERATION_KEY = "_scs_node_session_generation_v2"
_NODE_PRESET_KEY = "_scs_node_preset_v2"
_IMAGE_OWNER_KEY = "_scs_image_owner_v2"
_IMAGE_UUID_KEY = "_scs_image_uuid_v2"
_IMAGE_OWNER_TOKEN_KEY = "_scs_image_owner_token_v2"
_IMAGE_FILE_GENERATION_KEY = "_scs_image_file_generation_v2"
_IMAGE_SESSION_GENERATION_KEY = "_scs_image_session_generation_v2"

_NODE_TYPE_FALLBACKS = {
    "CompositorNodeComposite": ("NodeGroupOutput",),
    "CompositorNodeCombRGBA": ("CompositorNodeCombineColor",),
    "CompositorNodeSepRGBA": ("CompositorNodeSeparateColor",),
    "CompositorNodeValToRGB": ("ShaderNodeValToRGB",),
    "CompositorNodeMath": ("ShaderNodeMath",),
    "CompositorNodeMapRange": ("ShaderNodeMapRange",),
    "CompositorNodeMixRGB": ("ShaderNodeMixRGB", "ShaderNodeMix"),
    "CompositorNodeTexture": ("ShaderNodeTexNoise",),
    "CompositorNodeSunBeams": ("CompositorNodeGlare",),
}

_SOCKET_ALIASES = {
    "fac": ("Factor", "Fac", "Value"), "factor": ("Factor", "Fac", "Value"),
    "val": ("Value", "Result", "Factor"), "value": ("Value", "Result", "Factor"),
    "result": ("Result", "Value", "Image", "Color"),
    "image": ("Image", "Color", "Result"), "color": ("Color", "Image", "Result"),
    "rgba": ("Image", "Color", "Result"), "r": ("R", "Red", "X"),
    "g": ("G", "Green", "Y"), "b": ("B", "Blue", "Z"), "a": ("A", "Alpha"),
    "red": ("Red", "R", "X"), "green": ("Green", "G", "Y"),
    "blue": ("Blue", "B", "Z"), "alpha": ("Alpha", "A"),
    "input": ("Input", "Image", "Value"),
    "output": ("Output", "Image", "Value", "Result", "Color"),
    "distort": ("Distortion",), "distance": ("Size",), "z": ("Z", "Depth"),
}

# Node properties that are input sockets on this Blender: (node, property) -> (socket, enum values).
_NODE_PROPERTY_SOCKETS = {
    ("CompositorNodeDilateErode", "distance"): ("Size", None),
    ("CompositorNodeDilateErode", "mode"): ("Type", {"STEP": "Steps", "THRESHOLD": "Threshold", "DISTANCE": "Distance", "FEATHER": "Feather"}),
    ("CompositorNodeTonemap", "tonemap_type"): ("Type", {"RD_PHOTORECEPTOR": "R/D Photoreceptor", "RH_SIMPLE": "Rh Simple"}),
    ("CompositorNodeLensdist", "use_jitter"): ("Jitter", None),
    ("CompositorNodeLensdist", "use_fit"): ("Fit", None),
    ("CompositorNodeVecBlur", "samples"): ("Samples", None),
    ("CompositorNodeVecBlur", "factor"): ("Shutter", None),
}

_MIX_MODE_FALLBACKS = {"MAXIMUM": "LIGHTEN", "MINIMUM": "DARKEN"}

# Requested output names that any node may answer with its first output.
# A render pass name (Z, Normal, Vector...) is not one of them: when the pass is off nothing is linked.
_GENERIC_OUTPUT_NAMES = frozenset((
    "image", "color", "rgba", "result", "value", "val", "alpha", "output", "input",
    "fac", "factor", "r", "g", "b", "a", "red", "green", "blue", "0",
))


def _runtime_identity() -> tuple[str, int]:
    try:
        from . import registration
        return str(registration.current_owner_token()), int(registration.current_generation())
    except Exception:
        return "unregistered", 0


def _id_get(obj: Any, key: str, default: Any = None) -> Any:
    try:
        return obj.get(key, default)
    except Exception:
        try:
            return obj[key]
        except Exception:
            return default


def _id_set(obj: Any, key: str, value: Any) -> None:
    _tx.set_item(obj, key, value)


def _id_delete(obj: Any, key: str) -> None:
    transaction = _tx.current()
    if transaction is not None:
        transaction.record_item(obj, key)
    try:
        del obj[key]
    except Exception:
        pass


def _ledger(tree: Any) -> dict[str, dict[str, Any]]:
    raw = _id_get(tree, _TREE_LEDGER_KEY, "")
    if isinstance(raw, dict):
        data = raw
    else:
        try:
            data = json.loads(str(raw or "{}"))
        except Exception:
            data = {}
    if not isinstance(data, dict):
        return {}
    result: dict[str, dict[str, Any]] = {}
    for key, value in data.items():
        if isinstance(value, dict):
            result[str(key)] = {str(k): v for k, v in value.items() if isinstance(v, (str, int, float, bool)) or v is None}
    return result


def _write_ledger(tree: Any, ledger: dict[str, dict[str, Any]]) -> None:
    payload = json.dumps(ledger, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    _id_set(tree, _TREE_LEDGER_KEY, payload)




def _resource_ledger(scene: Any) -> dict[str, dict[str, dict[str, Any]]]:
    raw = _id_get(scene, _SCENE_RESOURCE_LEDGER_KEY, "") if scene is not None else ""
    try:
        data = raw if isinstance(raw, dict) else json.loads(str(raw or "{}"))
    except Exception:
        data = {}
    if not isinstance(data, dict):
        data = {}
    result: dict[str, dict[str, dict[str, Any]]] = {"node_groups": {}, "images": {}}
    for kind in tuple(result):
        values = data.get(kind, {})
        if not isinstance(values, dict):
            continue
        for resource_uuid, value in values.items():
            if isinstance(value, dict):
                result[kind][str(resource_uuid)] = {
                    str(key): item for key, item in value.items()
                    if isinstance(item, (str, int, float, bool)) or item is None
                }
    return result


def _write_resource_ledger(scene: Any, ledger: dict[str, dict[str, dict[str, Any]]]) -> None:
    if scene is None:
        return
    payload = json.dumps(ledger, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    _id_set(scene, _SCENE_RESOURCE_LEDGER_KEY, payload)


def _register_scene_resource(scene: Any, kind: str, resource_uuid: str, *, owner_token: str, file_generation: str, session_generation: int) -> None:
    if scene is None or kind not in {"node_groups", "images"} or not resource_uuid:
        return
    ledger = _resource_ledger(scene)
    ledger[kind][str(resource_uuid)] = {
        "owner": _OWNER_ID,
        "owner_token": str(owner_token),
        "file_generation": str(file_generation),
        "session_generation": int(session_generation),
    }
    _write_resource_ledger(scene, ledger)


def _resource_matches_scene(scene: Any, kind: str, resource_uuid: str, identity: dict[str, Any]) -> bool:
    entry = _resource_ledger(scene).get(kind, {}).get(str(resource_uuid))
    return bool(
        isinstance(entry, dict)
        and str(entry.get("owner", "")) == _OWNER_ID
        and str(entry.get("owner_token", "")) == str(identity.get("owner_token", ""))
        and str(entry.get("file_generation", "")) == str(identity.get("file_generation", ""))
        and int(entry.get("session_generation", -1)) == int(identity.get("session_generation", -2))
    )


def _forget_scene_resource(scene: Any, kind: str, resource_uuid: str) -> None:
    if scene is None:
        return
    ledger = _resource_ledger(scene)
    values = ledger.get(kind, {})
    if str(resource_uuid) not in values:
        return
    values.pop(str(resource_uuid), None)
    _write_resource_ledger(scene, ledger)


def _all_scenes() -> tuple[Any, ...]:
    try:
        return tuple(bpy.data.scenes)
    except Exception:
        return ()


def _scene_for_tree(tree: Any) -> Any:
    for scene in _all_scenes():
        try:
            if getattr(scene, "compositing_node_group", None) is tree or getattr(scene, "node_tree", None) is tree:
                return scene
        except Exception:
            continue
    return None


def _scene_file_generation(scene: Any) -> str:
    value = str(_id_get(scene, _SCENE_FILE_GENERATION_KEY, "") or "") if scene is not None else ""
    if value:
        return value
    value = uuid.uuid4().hex
    if scene is not None:
        _id_set(scene, _SCENE_FILE_GENERATION_KEY, value)
    return value


def _tree_uuid(tree: Any) -> str:
    value = str(_id_get(tree, _TREE_UUID_KEY, "") or "")
    if value:
        return value
    value = uuid.uuid4().hex
    _id_set(tree, _TREE_UUID_KEY, value)
    return value


def _safe_set_scene_use_nodes(scene) -> None:
    try:
        if hasattr(scene, "compositing_node_group"):
            return
    except Exception:
        pass
    try:
        _tx.set_attr(scene, "use_nodes", True)
    except Exception:
        pass


def existing_compositor_tree(context=None):
    ctx = context or bpy.context
    space = getattr(ctx, "space_data", None)
    if getattr(space, "type", "") == "NODE_EDITOR" and getattr(space, "tree_type", "") == "CompositorNodeTree":
        edit_tree = getattr(space, "edit_tree", None)
        if edit_tree is not None:
            return edit_tree
    scene = getattr(ctx, "scene", None)
    if scene is None:
        return None
    try:
        if hasattr(scene, "compositing_node_group"):
            return getattr(scene, "compositing_node_group", None)
    except Exception:
        pass
    try:
        return getattr(scene, "node_tree", None)
    except Exception:
        return None


def ensure_tree_output_socket(tree) -> None:
    """A Group Output only passes the image to the render when the tree has an output socket."""
    interface = getattr(tree, "interface", None)
    if interface is None:
        return
    for item in interface.items_tree:
        if getattr(item, "item_type", "") == "SOCKET" and getattr(item, "in_out", "") == "OUTPUT":
            return
    interface.new_socket("Image", in_out="OUTPUT", socket_type="NodeSocketColor")


def ensure_compositor_tree(context=None):
    ctx = context or bpy.context
    scene = getattr(ctx, "scene", None)
    if scene is None:
        raise RuntimeError("No active scene is available.")
    try:
        if hasattr(scene, "compositing_node_group"):
            tree = getattr(scene, "compositing_node_group", None)
            if tree is None:
                name = f"{getattr(scene, 'name', 'Scene')} Smart Composite"
                tree = bpy.data.node_groups.new(name, "CompositorNodeTree")
                _tx.record_collection_created(bpy.data.node_groups, tree)
                owner_token, session_generation = _runtime_identity()
                file_generation = _scene_file_generation(scene)
                _id_set(tree, SCS_CREATED_TREE_FLAG, True)
                _id_set(tree, _TREE_CREATED_KEY, True)
                _id_set(tree, _TREE_OWNER_KEY, _OWNER_ID)
                _id_set(tree, _TREE_OWNER_TOKEN_KEY, owner_token)
                _id_set(tree, _TREE_FILE_GENERATION_KEY, file_generation)
                _id_set(tree, _TREE_SESSION_GENERATION_KEY, session_generation)
                tree_uuid = _tree_uuid(tree)
                _write_ledger(tree, {})
                _register_scene_resource(
                    scene, "node_groups", tree_uuid,
                    owner_token=owner_token,
                    file_generation=file_generation,
                    session_generation=session_generation,
                )
                ensure_tree_output_socket(tree)
                # Starts like Blender's own New button: plain nodes, so Clean SCS Nodes never strips the input and output.
                source = tree.nodes.new("CompositorNodeRLayers")
                source.location = (-300, 0)
                output = tree.nodes.new("NodeGroupOutput")
                output.location = (200, 0)
                link(tree, source, output, ("Image",), ("Image",))
                _tx.set_attr(scene, "compositing_node_group", tree)
            return tree
    except Exception as exc:
        raise RuntimeError(f"Could not create Blender 5.1 compositor node group: {exc}") from exc
    _safe_set_scene_use_nodes(scene)
    tree = getattr(scene, "node_tree", None)
    if tree is None:
        raise RuntimeError("The active scene has no compositor node tree.")
    return tree


def active_compositor_tree(context=None):
    return existing_compositor_tree(context) or ensure_compositor_tree(context)


def mark_node(node, preset_id: str = "", tree=None):
    tree = tree or getattr(node, "id_data", None)
    if tree is None:
        raise RuntimeError("Smart Composite node ownership requires an owning node tree.")
    owner_token, session_generation = _runtime_identity()
    file_generation = str(_id_get(tree, _TREE_FILE_GENERATION_KEY, "") or "")
    if not file_generation:
        try:
            file_generation = _scene_file_generation(getattr(bpy.context, "scene", None))
        except Exception:
            file_generation = uuid.uuid4().hex
        _id_set(tree, _TREE_FILE_GENERATION_KEY, file_generation)
    node_uuid = uuid.uuid4().hex
    _tree_uuid(tree)
    _id_set(node, SCS_FLAG, True)  # compatibility marker only
    _id_set(node, _NODE_UUID_KEY, node_uuid)
    _id_set(node, _NODE_OWNER_KEY, _OWNER_ID)
    _id_set(node, _NODE_OWNER_TOKEN_KEY, owner_token)
    _id_set(node, _NODE_FILE_GENERATION_KEY, file_generation)
    _id_set(node, _NODE_SESSION_GENERATION_KEY, session_generation)
    if preset_id:
        _id_set(node, "scs_preset_id", str(preset_id))
        _id_set(node, _NODE_PRESET_KEY, str(preset_id))
    ledger = _ledger(tree)
    ledger[node_uuid] = {
        "owner": _OWNER_ID,
        "owner_token": owner_token,
        "file_generation": file_generation,
        "session_generation": session_generation,
        "tree_uuid": _tree_uuid(tree),
        "preset_id": str(preset_id or ""),
    }
    _write_ledger(tree, ledger)
    return node


def _node_identity(node: Any) -> dict[str, Any] | None:
    node_uuid = str(_id_get(node, _NODE_UUID_KEY, "") or "")
    owner = str(_id_get(node, _NODE_OWNER_KEY, "") or "")
    owner_token = str(_id_get(node, _NODE_OWNER_TOKEN_KEY, "") or "")
    file_generation = str(_id_get(node, _NODE_FILE_GENERATION_KEY, "") or "")
    session_generation = _id_get(node, _NODE_SESSION_GENERATION_KEY, None)
    if not node_uuid or owner != _OWNER_ID or not owner_token or not file_generation:
        return None
    try:
        session_generation = int(session_generation)
    except Exception:
        return None
    return {
        "uuid": node_uuid,
        "owner": owner,
        "owner_token": owner_token,
        "file_generation": file_generation,
        "session_generation": session_generation,
    }


def _node_uuid_is_unique(node: Any, tree: Any, node_uuid: str) -> bool:
    """Reject duplicated ownership metadata instead of deleting a user copy."""
    matches: list[Any] = []
    try:
        candidates = tuple(getattr(tree, "nodes", ()) or ())
    except Exception:
        candidates = ()
    for candidate in candidates:
        candidate_identity = _node_identity(candidate)
        if candidate_identity is not None and candidate_identity.get("uuid") == node_uuid:
            matches.append(candidate)
            if len(matches) > 1:
                return False
    return len(matches) == 1 and matches[0] == node


def is_scs_node(node, tree=None) -> bool:
    identity = _node_identity(node)
    if identity is None:
        return False
    tree = tree or getattr(node, "id_data", None)
    if tree is None or not _node_uuid_is_unique(node, tree, identity["uuid"]):
        return False
    entry = _ledger(tree).get(identity["uuid"])
    if not isinstance(entry, dict):
        return False
    return (
        str(entry.get("owner", "")) == identity["owner"]
        and str(entry.get("owner_token", "")) == identity["owner_token"]
        and str(entry.get("file_generation", "")) == identity["file_generation"]
        and int(entry.get("session_generation", -1)) == identity["session_generation"]
        and str(entry.get("tree_uuid", "")) == str(_id_get(tree, _TREE_UUID_KEY, "") or "")
        and str(_id_get(tree, _TREE_FILE_GENERATION_KEY, "") or "") == identity["file_generation"]
    )


def _remove_owned_nodes_now(tree: Any, targets: tuple[Any, ...]) -> int:
    ledger = _ledger(tree)
    removed = 0
    target_names = {node.name for node in targets}
    fed_outputs = [
        link.to_socket.identifier for link in tree.links
        if link.to_node.bl_idname == "NodeGroupOutput" and link.to_node.name not in target_names and link.from_node.name in target_names
    ]
    for node in reversed(targets):
        identity = _node_identity(node)
        if identity is None or not is_scs_node(node, tree):
            continue
        try:
            tree.nodes.remove(node)
        except Exception:
            continue
        ledger.pop(identity["uuid"], None)
        removed += 1
    _write_ledger(tree, ledger)
    _remove_unused_note_texts()
    _reconnect_render_layers(tree, fed_outputs)
    return removed


def _reconnect_render_layers(tree, output_identifiers) -> None:
    """Give a Group Output that only SCS nodes fed its Render Layers image back."""
    source = next((node for node in tree.nodes if node.bl_idname == "CompositorNodeRLayers"), None)
    output = next((node for node in tree.nodes if node.bl_idname == "NodeGroupOutput"), None)
    if source is None or output is None:
        return
    for socket in output.inputs:
        if socket.identifier in output_identifiers and not socket.is_linked:
            tree.links.new(source.outputs["Image"], socket)


def delete_scs_nodes(tree) -> int:
    if tree is None:
        return 0
    targets = tuple(node for node in tuple(getattr(tree, "nodes", ()) or ()) if is_scs_node(node, tree))
    transaction = _tx.current()
    if transaction is None:
        return _remove_owned_nodes_now(tree, targets)
    # Deletion is delayed until commit. CANCELLED/exception therefore leaves the
    # complete original tree untouched, including links and user/foreign nodes.
    transaction.add_commit(lambda tree=tree, targets=targets: _remove_owned_nodes_now(tree, targets))
    return len(targets)


def release_empty_created_tree(context=None) -> None:
    """A tree SCS created has no use once it is empty, and an empty tree would blank the render."""
    scene = getattr(context or bpy.context, "scene", None)
    tree = getattr(scene, "compositing_node_group", None)
    if tree is None or len(tree.nodes) or not _id_get(tree, _TREE_CREATED_KEY, False):
        return
    scene.compositing_node_group = None
    bpy.data.node_groups.remove(tree)


def _node_extents(tree) -> tuple[float, float]:
    xs: list[float] = []
    ys: list[float] = []
    for node in getattr(tree, "nodes", ()) or ():
        try:
            x, y = node.location_absolute
            xs.append(float(x) + float(node.width))
            if node.parent is None:
                ys.append(float(y))
        except Exception:
            pass
    return (max(xs), max(ys)) if xs else (0.0, 0.0)


def next_location(tree, settings=None) -> tuple[float, float]:
    max_x, max_y = _node_extents(tree)
    try:
        offset = float(getattr(settings, "node_offset_x", 520) or 520)
    except Exception:
        offset = 520.0
    return max_x + offset, max_y


def align_frame_left_edge(tree, frame) -> None:
    """Move the frame so its leftmost child starts at the frame's anchor location."""
    children = [node for node in tree.nodes if node.parent == frame]
    if not children:
        return
    left = min(float(node.location_absolute[0]) for node in children)
    x, y = frame.location_absolute
    _tx.set_attr(frame, "location", (float(frame.location[0]) + float(x) - left, float(frame.location[1])))


def _record_created_node(tree: Any, node: Any) -> None:
    transaction = _tx.current()
    if transaction is None:
        return
    def remove_node(tree=tree, node=node):
        try:
            identity = _node_identity(node)
            tree.nodes.remove(node)
            if identity is not None:
                ledger = _ledger(tree); ledger.pop(identity["uuid"], None); _write_ledger(tree, ledger)
        except Exception:
            pass
    transaction.add_undo(remove_node)


def add_frame(tree, label: str, location=(0, 0), width: float = 480.0, height: float = 320.0, preset_id: str = ""):
    node = tree.nodes.new("NodeFrame")
    _record_created_node(tree, node)
    _tx.set_attr(node, "label", label); _tx.set_attr(node, "name", label); _tx.set_attr(node, "location", location)
    try:
        _tx.set_attr(node, "width", width); _tx.set_attr(node, "height", height)
    except Exception:
        pass
    return mark_node(node, preset_id, tree)


def new_node(tree, node_type: str, label: str = "", location=(0, 0), frame=None, preset_id: str = ""):
    attempted = (str(node_type),) + tuple(_NODE_TYPE_FALLBACKS.get(str(node_type), ()))
    node = None
    last_error = None
    for candidate in attempted:
        try:
            node = tree.nodes.new(candidate)
            break
        except Exception as exc:
            last_error = exc
    if node is None:
        try:
            node = tree.nodes.new("NodeFrame")
            label = label or f"SCS Unsupported Node: {node_type}"
        except Exception as exc:
            raise RuntimeError(f"Node type unavailable: {node_type}: {last_error or exc}") from exc
    _record_created_node(tree, node)
    if node.bl_idname == "NodeGroupOutput":
        ensure_tree_output_socket(tree)
    if label:
        _tx.set_attr(node, "label", display_label(label))
        try:
            _tx.set_attr(node, "name", label)
        except Exception:
            pass
    if frame is not None:
        try:
            _tx.set_attr(node, "parent", frame)
        except Exception:
            pass
    # Assigned after the parent so the coordinates are relative to the frame.
    try:
        _tx.set_attr(node, "location", location)
    except Exception:
        pass
    if node.bl_idname == "CompositorNodeLensdist":
        # Keeps the distorted image over the whole frame, so the frame edge stays opaque.
        safe_set_input(node, "Fit", True)
    return mark_node(node, preset_id, tree)


def _remove_unused_note_texts() -> None:
    blocks = {block for block in bpy.data.texts if _id_get(block, _NOTE_TEXT_KEY, False)}
    if not blocks:
        return
    for block, users in bpy.data.user_map(subset=blocks).items():
        if not users:
            bpy.data.texts.remove(block)


def _wrap_note(text: str) -> str:
    """Frames only wrap at spaces, so Japanese runs need line breaks of their own."""
    lines = []
    line = ""
    used = 0
    for token in re.findall(r"[!-~]+|\s|.", text):
        if token.isspace():
            if line:
                line += " "
                used += 1
            continue
        columns = sum(2 if unicodedata.east_asian_width(ch) in "WF" else 1 for ch in token)
        if line and used + columns > _NOTE_COLUMNS and token not in "。、，．）」』":
            lines.append(line.rstrip())
            line = ""
            used = 0
        line += token
        used += columns
    if line:
        lines.append(line.rstrip())
    return "\n".join(lines)


def _note_text_block(body: str):
    """Frame labels stop at 63 bytes, so the note body lives in a Text the frame shows."""
    name = f"SCS Note {hashlib.sha1(body.encode('utf-8')).hexdigest()[:12]}"
    block = bpy.data.texts.get(name)
    if block is not None:
        return block
    block = bpy.data.texts.new(name)
    block.from_string(body)
    _id_set(block, _NOTE_TEXT_KEY, True)
    transaction = _tx.current()
    if transaction is not None:
        transaction.add_undo(_remove_unused_note_texts)
    return block


def add_note(tree, text: str, location=(0, 0), frame=None, preset_id: str = ""):
    body = _wrap_note(text)
    # Created before the node so a rollback removes the node first and the Text after it.
    block = _note_text_block(body)
    note = new_node(tree, "NodeFrame", f"SCS Note - {text[:48]}", location, frame, preset_id)
    _tx.set_attr(note, "label", t("SCS メモ", "SCS Note"))
    _tx.set_attr(note, "text", block)
    _tx.set_attr(note, "label_size", _NOTE_FONT_SIZE)
    try:
        _tx.set_attr(note, "width", 360); _tx.set_attr(note, "height", 80.0 + 16.0 * (body.count("\n") + 1))
    except Exception:
        pass
    return note


def _estimated_node_height(node) -> float:
    drawn = float(node.dimensions[1])
    if drawn > 0.0:
        return drawn
    rows = sum(1 for socket in (*node.inputs, *node.outputs) if socket.enabled and not socket.hide)
    widgets = 260.0 if getattr(node, "mapping", None) is not None else 0.0
    return 100.0 + widgets + 24.0 * rows + 48.0 * sum(1 for socket in node.inputs if socket.type == "VECTOR")


def move_notes_clear_of_nodes(tree) -> None:
    """Nodes draw over frames, so a note that sits under a node has its text hidden."""
    all_notes = [node for node in tree.nodes if node.bl_idname == "NodeFrame" and _id_get(node.text, _NOTE_TEXT_KEY, False)] if tree else []
    for note in all_notes:
        others = []
        for node in tree.nodes:
            if node == note or node.parent != note.parent or node.bl_idname == "NodeReroute":
                continue
            if node.bl_idname != "NodeFrame":
                others.append((node, _estimated_node_height(node)))
            elif node in all_notes and all_notes.index(node) < all_notes.index(note):
                others.append((node, float(node.height)))
        x, y = (float(value) for value in note.location)
        while True:
            hits = [
                float(node.location[1]) - height
                for node, height in others
                if x < float(node.location[0]) + float(node.width) and float(node.location[0]) < x + float(note.width)
                and y - float(note.height) < float(node.location[1]) and float(node.location[1]) - height < y
            ]
            if not hits:
                break
            y = min(hits) - 30.0
        if y != float(note.location[1]):
            _tx.set_attr(note, "location", (x, y))


def socket_by_names(collection, names: Sequence[str] | str):
    if isinstance(names, str):
        names = (names,)
    expanded: list[str] = []
    for name in names:
        text = str(name); expanded.append(text); expanded.extend(_SOCKET_ALIASES.get(text.lower(), ()))
    for name in expanded:
        try:
            socket = collection.get(name)
            if socket is not None:
                return socket
        except Exception:
            pass
    wanted = {str(name).lower() for name in expanded}
    try:
        for socket in collection:
            if str(getattr(socket, "name", "")).lower() in wanted:
                return socket
    except Exception:
        pass
    for name in names:
        try:
            text = str(name)
            if text.isdigit():
                return collection[int(text)]
        except Exception:
            pass
    return None


def first_socket(collection):
    try:
        return collection[0]
    except Exception:
        return None


def output_socket(node, names: Sequence[str] | str = ("Image", "Color", "Result", "Value", "Alpha", "Output")):
    outputs = getattr(node, "outputs", ())
    socket = socket_by_names(outputs, names)
    if socket is not None:
        return socket
    requested = (names,) if isinstance(names, str) else names
    if not any(str(name).lower() in _GENERIC_OUTPUT_NAMES for name in requested):
        return None
    return first_socket(outputs)


def input_socket(node, names: Sequence[str] | str = ("Image", "Color", "Factor", "Value", "Alpha", "Input")):
    inputs = getattr(node, "inputs", ())
    socket = socket_by_names(inputs, names)
    requested = (names,) if isinstance(names, str) else names
    if any(str(name).lower() in {"image", "color", "rgba"} for name in requested) and getattr(socket, "type", "") != "RGBA":
        # An image goes to a color input (Color1, Background), never to a factor.
        for candidate in inputs:
            if candidate.type == "RGBA" and candidate.enabled:
                return candidate
    return socket or first_socket(inputs)


def link_sockets(tree, out, inn) -> bool:
    if out is None or inn is None:
        return False
    created = tree.links.new(out, inn)
    transaction = _tx.current()
    if transaction is not None:
        def remove_link(tree=tree, created=created):
            try:
                tree.links.remove(created)
            except Exception:
                pass
        transaction.add_undo(remove_link)
    return True


def link(tree, from_node, to_node, from_names: Sequence[str] | str = ("Image",), to_names: Sequence[str] | str = ("Image",)) -> bool:
    return link_sockets(tree, output_socket(from_node, from_names), input_socket(to_node, to_names))


def safe_set(obj, name: str, value) -> bool:
    mapped = _NODE_PROPERTY_SOCKETS.get((str(getattr(obj, "bl_idname", "")), name))
    if mapped is not None:
        socket_name, values = mapped
        return safe_set_socket(socket_by_names(obj.inputs, (socket_name,)), values.get(value, value) if values else value)
    try:
        _tx.set_attr(obj, name, value)
        return True
    except Exception:
        return False


def safe_set_socket(socket, value) -> bool:
    if socket is None:
        return False
    if socket.type == "INT":
        try:
            value = int(round(value))
        except (TypeError, ValueError):
            return False
    return safe_set(socket, "default_value", value)


def set_edges_extend(node) -> None:
    """Pixels pulled from outside the frame repeat the edge instead of turning transparent."""
    safe_set_input(node, "Extension X", "Extend")
    safe_set_input(node, "Extension Y", "Extend")


def safe_set_input(node, name: str, value) -> bool:
    return safe_set_socket(socket_by_names(getattr(node, "inputs", ()), (name,)), value)


def safe_set_output(node, name: str, value) -> bool:
    return safe_set_socket(socket_by_names(getattr(node, "outputs", ()), (name,)), value)


def find_output_nodes(tree):
    composite = None; viewer = None
    for node in tree.nodes:
        node_type = str(getattr(node, "bl_idname", "") or getattr(node, "type", ""))
        if (node_type in {"CompositorNodeComposite", "NodeGroupOutput"} or "Composite" in node_type) and composite is None:
            composite = node
        if "Viewer" in node_type and viewer is None:
            viewer = node
    return composite, viewer


def ensure_output_nodes(tree, location=(900, 0), frame=None, preset_id: str = ""):
    composite, viewer = find_output_nodes(tree)
    x, y = location
    if composite is None:
        composite = new_node(tree, "CompositorNodeComposite", "SCS Composite Output", (x, y), frame, preset_id)
    ensure_tree_output_socket(tree)
    if viewer is None:
        viewer = new_node(tree, "CompositorNodeViewer", "SCS Viewer Output", (x, y - 140), frame, preset_id)
    return composite, viewer


def ensure_render_layers(tree, location=(-500, 0), frame=None, preset_id: str = ""):
    for node in tree.nodes:
        try:
            if str(getattr(node, "bl_idname", "")) == "CompositorNodeRLayers":
                return node
        except Exception:
            pass
    return new_node(tree, "CompositorNodeRLayers", "SCS Render Layers", location, frame, preset_id)


def connect_to_outputs(tree, source_node, settings=None, frame=None, preset_id: str = "") -> int:
    if settings is not None and not bool(getattr(settings, "auto_connect_outputs", True)):
        return 0
    composite, viewer = ensure_output_nodes(tree, location=(source_node.location.x + 360, source_node.location.y), frame=frame, preset_id=preset_id)
    count = int(link(tree, source_node, composite, ("Image", "Result", "Output"), ("Image",)))
    count += int(link(tree, source_node, viewer, ("Image", "Result", "Output"), ("Image",)))
    return count


def set_node_color(node, color=(0.25, 0.25, 0.25)):
    safe_set(node, "use_custom_color", True); safe_set(node, "color", color)


def set_mix_mode(node, mode: str) -> None:
    mode = _MIX_MODE_FALLBACKS.get(mode, mode)
    for attr in ("blend_type", "data_type", "factor_mode"):
        try:
            getattr(node, attr)
        except Exception:
            continue
        if safe_set(node, attr, mode):
            return


def add_file_output(tree, label: str, base_path: str, slots: Iterable[str], location=(0, 0), frame=None, preset_id: str = ""):
    node = new_node(tree, "CompositorNodeOutputFile", label, location, frame, preset_id)
    safe_set(node, "directory", base_path)
    safe_set(node, "file_name", preset_id or "SCS_Output")
    for slot_name in (str(slot) for slot in slots if str(slot).strip()):
        item = node.file_output_items.new("RGBA", slot_name)
        _tx.record_collection_created(node.file_output_items, item)
    return node


def add_file_output_slot(node, slot_name: str):
    item = node.file_output_items.new("RGBA", slot_name)
    _tx.record_collection_created(node.file_output_items, item)
    return item


def mark_owned_image(image: Any, scene: Any = None) -> str:
    scene = scene or getattr(getattr(bpy, "context", None), "scene", None)
    owner_token, session_generation = _runtime_identity()
    image_uuid = str(_id_get(image, _IMAGE_UUID_KEY, "") or "") or uuid.uuid4().hex
    file_generation = _scene_file_generation(scene)
    _id_set(image, _IMAGE_OWNER_KEY, _OWNER_ID)
    _id_set(image, _IMAGE_UUID_KEY, image_uuid)
    _id_set(image, _IMAGE_OWNER_TOKEN_KEY, owner_token)
    _id_set(image, _IMAGE_FILE_GENERATION_KEY, file_generation)
    _id_set(image, _IMAGE_SESSION_GENERATION_KEY, session_generation)
    _register_scene_resource(
        scene, "images", image_uuid,
        owner_token=owner_token,
        file_generation=file_generation,
        session_generation=session_generation,
    )
    return image_uuid


def _image_identity(image: Any) -> dict[str, Any] | None:
    try:
        image_uuid = str(_id_get(image, _IMAGE_UUID_KEY, "") or "")
        owner_token = str(_id_get(image, _IMAGE_OWNER_TOKEN_KEY, "") or "")
        file_generation = str(_id_get(image, _IMAGE_FILE_GENERATION_KEY, "") or "")
        session_generation = int(_id_get(image, _IMAGE_SESSION_GENERATION_KEY, -1))
        if str(_id_get(image, _IMAGE_OWNER_KEY, "")) != _OWNER_ID or not image_uuid or not owner_token or not file_generation or session_generation < 0:
            return None
        return {
            "uuid": image_uuid,
            "owner_token": owner_token,
            "file_generation": file_generation,
            "session_generation": session_generation,
        }
    except Exception:
        return None


def _image_uuid_is_unique(image: Any, image_uuid: str) -> bool:
    matches: list[Any] = []
    try:
        candidates = tuple(bpy.data.images)
    except Exception:
        candidates = ()
    for candidate in candidates:
        candidate_identity = _image_identity(candidate)
        if candidate_identity is not None and candidate_identity.get("uuid") == image_uuid:
            matches.append(candidate)
            if len(matches) > 1:
                return False
    return len(matches) == 1 and matches[0] is image


def is_owned_image(image: Any, scene: Any = None) -> bool:
    identity = _image_identity(image)
    if identity is None or not _image_uuid_is_unique(image, identity["uuid"]):
        return False
    scenes = (scene,) if scene is not None else _all_scenes()
    return any(_resource_matches_scene(item, "images", identity["uuid"], identity) for item in scenes if item is not None)


def _tree_identity(tree: Any) -> dict[str, Any] | None:
    try:
        tree_uuid = str(_id_get(tree, _TREE_UUID_KEY, "") or "")
        owner_token = str(_id_get(tree, _TREE_OWNER_TOKEN_KEY, "") or "")
        file_generation = str(_id_get(tree, _TREE_FILE_GENERATION_KEY, "") or "")
        session_generation = int(_id_get(tree, _TREE_SESSION_GENERATION_KEY, -1))
        if (
            not bool(_id_get(tree, _TREE_CREATED_KEY, False))
            or str(_id_get(tree, _TREE_OWNER_KEY, "")) != _OWNER_ID
            or not tree_uuid or not owner_token or not file_generation or session_generation < 0
        ):
            return None
        return {
            "uuid": tree_uuid,
            "owner_token": owner_token,
            "file_generation": file_generation,
            "session_generation": session_generation,
        }
    except Exception:
        return None


def _tree_uuid_is_unique(tree: Any, tree_uuid: str) -> bool:
    matches: list[Any] = []
    try:
        candidates = tuple(bpy.data.node_groups)
    except Exception:
        candidates = ()
    for candidate in candidates:
        candidate_identity = _tree_identity(candidate)
        if candidate_identity is not None and candidate_identity.get("uuid") == tree_uuid:
            matches.append(candidate)
            if len(matches) > 1:
                return False
    return len(matches) == 1 and matches[0] is tree


def is_owned_node_group(tree: Any, scene: Any = None) -> bool:
    """Return True only for one uniquely identified, Scene-ledger-owned group."""
    identity = _tree_identity(tree)
    if identity is None or not _tree_uuid_is_unique(tree, identity["uuid"]):
        return False
    scenes = (scene,) if scene is not None else _all_scenes()
    return any(
        item is not None and _resource_matches_scene(item, "node_groups", identity["uuid"], identity)
        for item in scenes
    )


def cleanup_owned_orphans(context=None) -> dict[str, int]:
    """Delete only resources authorized by a matching Scene resource ledger."""
    result = {"node_groups": 0, "images": 0, "nodes": 0}
    scenes = _all_scenes()
    assigned: set[int] = set()
    for scene in scenes:
        try:
            for tree in (getattr(scene, "compositing_node_group", None), getattr(scene, "node_tree", None)):
                if tree is not None:
                    assigned.add(id(tree))
        except Exception:
            continue

    try:
        node_groups = tuple(bpy.data.node_groups)
    except Exception:
        node_groups = ()
    for tree in node_groups:
        if id(tree) in assigned:
            continue
        identity = _tree_identity(tree)
        if identity is None or not _tree_uuid_is_unique(tree, identity["uuid"]):
            continue
        owners = tuple(scene for scene in scenes if _resource_matches_scene(scene, "node_groups", identity["uuid"], identity))
        if not owners:
            continue
        nodes = tuple(getattr(tree, "nodes", ()) or ())
        if any(not is_scs_node(node, tree) for node in nodes):
            continue
        try:
            if nodes:
                result["nodes"] += _remove_owned_nodes_now(tree, nodes)
            if tuple(getattr(tree, "nodes", ()) or ()):
                continue
            bpy.data.node_groups.remove(tree)
            result["node_groups"] += 1
            for scene in owners:
                _forget_scene_resource(scene, "node_groups", identity["uuid"])
        except Exception:
            continue

    try:
        images = tuple(bpy.data.images)
    except Exception:
        images = ()
    for image in images:
        identity = _image_identity(image)
        if identity is None or not _image_uuid_is_unique(image, identity["uuid"]):
            continue
        owners = tuple(scene for scene in scenes if _resource_matches_scene(scene, "images", identity["uuid"], identity))
        if not owners:
            continue
        try:
            if int(getattr(image, "users", 0) or 0) != 0 or bool(getattr(image, "use_fake_user", False)):
                continue
            bpy.data.images.remove(image)
            result["images"] += 1
            for scene in owners:
                _forget_scene_resource(scene, "images", identity["uuid"])
        except Exception:
            continue
    return result


def tree_summary(tree) -> dict[str, int]:
    total = smart = outputs = frames = 0
    for node in getattr(tree, "nodes", ()) or ():
        total += 1
        if is_scs_node(node, tree):
            smart += 1
        blid = str(getattr(node, "bl_idname", "") or "")
        if blid in {"CompositorNodeComposite", "NodeGroupOutput", "CompositorNodeViewer", "CompositorNodeOutputFile"}:
            outputs += 1
        if blid == "NodeFrame":
            frames += 1
    return {"total_nodes": total, "smart_nodes": smart, "output_nodes": outputs, "frames": frames}
