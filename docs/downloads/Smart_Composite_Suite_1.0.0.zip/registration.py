# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Generation-owned exact Blender RNA lifecycle for Smart Composite Suite."""

from __future__ import annotations

from dataclasses import dataclass, field
import uuid
from typing import Any, Callable

import bpy

from .operators import OPERATOR_CLASSES
from .ui import UI_CLASSES

_NAMESPACE_KEY = "_jelararagi_smart_composite_lifecycle_v2"
_OWNER = "JELararagi"
_PACKAGE = "smart_composite_suite"
_VERSION = "1.0.0"
_CLASS_OWNER_ATTR = "_scs_runtime_owner"
_CLASS_PACKAGE_ATTR = "_scs_runtime_package"
_CLASS_TOKEN_ATTR = "_scs_runtime_token"
_CLASS_GENERATION_ATTR = "_scs_runtime_generation"
_MAX_REGISTER_ATTEMPTS = 2
_DIAGNOSTIC_LIMIT = 8


@dataclass
class _Acquisition:
    kind: str
    identity: Any
    release: Callable[[], None]


@dataclass
class _Ledger:
    token: str = ""
    generation: int = 0
    phase: str = "IDLE"
    acquisitions: list[_Acquisition] = field(default_factory=list)
    classes: list[type] = field(default_factory=list)
    pointer_identity: Any = None
    degraded_reason: str = ""


# importlib.reload preserves the module dictionary; retaining this exact ledger
# prevents a reloaded source file from guessing ownership by class name.
_prior_ledger = globals().get("_LEDGER")
_REQUIRED_LEDGER_FIELDS = ("token", "generation", "phase", "acquisitions", "classes", "pointer_identity")
_LEDGER: _Ledger = _prior_ledger if all(hasattr(_prior_ledger, name) for name in _REQUIRED_LEDGER_FIELDS) else _Ledger()
if not hasattr(_LEDGER, "degraded_reason"):
    _LEDGER.degraded_reason = ""
_REGISTERED = bool(globals().get("_REGISTERED", False))
_prior_diagnostics = globals().get("_REGISTER_DIAGNOSTICS")
_REGISTER_DIAGNOSTICS: list[dict[str, Any]] = (
    _prior_diagnostics if isinstance(_prior_diagnostics, list) else []
)
while len(_REGISTER_DIAGNOSTICS) > _DIAGNOSTIC_LIMIT:
    _REGISTER_DIAGNOSTICS.pop(0)


def _record_lifecycle_warning(
    code: str,
    *,
    attempt: int = 0,
    error: BaseException | None = None,
    rollback_errors: tuple[str, ...] = (),
) -> None:
    """Store one bounded primitive diagnostic without writing to the console.

    Registration fault injection and native partial-registration failures must not
    emit a traceback from Blender's add-on enable path.  The diagnostic is kept as
    primitive data only, published with the current lifecycle record, and never
    retains an exception, class, callback, or RNA object.
    """
    try:
        item = {
            "tag": "SCS_LIFECYCLE_WARNING",
            "code": str(code or "REGISTER_WARNING"),
            "attempt": max(0, int(attempt)),
            "exception_type": type(error).__name__ if error is not None else "",
            "message": str(error or "")[:512],
            "rollback_errors": tuple(str(value)[:160] for value in rollback_errors[:8]),
        }
        _REGISTER_DIAGNOSTICS.append(item)
        while len(_REGISTER_DIAGNOSTICS) > _DIAGNOSTIC_LIMIT:
            _REGISTER_DIAGNOSTICS.pop(0)
    except Exception:
        # Diagnostics must never become a new registration failure source.
        pass


def lifecycle_diagnostics() -> tuple[dict[str, Any], ...]:
    """Return a detached primitive snapshot for diagnostics and regression tests."""
    result: list[dict[str, Any]] = []
    for item in tuple(_REGISTER_DIAGNOSTICS):
        if isinstance(item, dict):
            result.append(dict(item))
    return tuple(result)


def _namespace() -> dict[str, Any] | None:
    try:
        value = bpy.app.driver_namespace
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _shared_record() -> dict[str, Any] | None:
    namespace = _namespace()
    if namespace is None:
        return None
    value = namespace.get(_NAMESPACE_KEY)
    return value if isinstance(value, dict) else None


def _all_required_class_identities() -> tuple[type, ...]:
    identities: list[type] = list(_LEDGER.classes)
    try:
        from . import properties
        identities.extend(properties.registered_class_identities())
    except Exception:
        pass
    try:
        from . import help
        help_cls = help.registered_class_identity()
        if isinstance(help_cls, type):
            identities.append(help_cls)
    except Exception:
        pass
    return tuple(identities)


def _publish(phase: str) -> None:
    namespace = _namespace()
    if namespace is None:
        return
    namespace[_NAMESPACE_KEY] = {
        "schema": 2,
        "owner": _OWNER,
        "package": _PACKAGE,
        "version": _VERSION,
        "token": str(_LEDGER.token),
        "generation": int(_LEDGER.generation),
        "phase": str(phase),
        "class_identity_ids": [int(id(cls)) for cls in _all_required_class_identities()],
        "pointer_identity_id": int(id(_LEDGER.pointer_identity)) if _LEDGER.pointer_identity is not None else 0,
        "degraded_reason": str(_LEDGER.degraded_reason or ""),
        "warnings": [dict(item) for item in lifecycle_diagnostics()],
    }


def _shared_is_ours() -> bool:
    record = _shared_record()
    return bool(
        record
        and str(record.get("owner", "")) == _OWNER
        and str(record.get("package", "")) == _PACKAGE
        and str(record.get("token", "")) == _LEDGER.token
        and int(record.get("generation", -1)) == _LEDGER.generation
    )


def current_owner_token() -> str:
    return str(_LEDGER.token or "unregistered")


def current_generation() -> int:
    return int(_LEDGER.generation or 0)


def lifecycle_phase() -> str:
    return str(_LEDGER.phase)


def _class_identity_valid(cls: type) -> bool:
    """Validate the exact class object Blender registered; never search by name."""
    try:
        return bool(getattr(cls, "is_registered", False))
    except Exception:
        return False


def _mark_class_owner(cls: type) -> None:
    setattr(cls, _CLASS_OWNER_ATTR, _OWNER)
    setattr(cls, _CLASS_PACKAGE_ATTR, _PACKAGE)
    setattr(cls, _CLASS_TOKEN_ATTR, str(_LEDGER.token))
    setattr(cls, _CLASS_GENERATION_ATTR, int(_LEDGER.generation))


def _class_owner_matches(cls: type) -> bool:
    try:
        return bool(
            str(getattr(cls, _CLASS_OWNER_ATTR, "")) == _OWNER
            and str(getattr(cls, _CLASS_PACKAGE_ATTR, "")) == _PACKAGE
            and str(getattr(cls, _CLASS_TOKEN_ATTR, "")) == str(_LEDGER.token)
            and int(getattr(cls, _CLASS_GENERATION_ATTR, -1)) == int(_LEDGER.generation)
        )
    except Exception:
        return False


def _record_class_acquisition(cls: type) -> None:
    if cls not in _LEDGER.classes:
        _LEDGER.classes.append(cls)
    if any(item.kind == "class" and item.identity is cls for item in _LEDGER.acquisitions):
        return

    token = str(_LEDGER.token)
    generation = int(_LEDGER.generation)

    def release(cls=cls, token=token, generation=generation):
        if cls not in _LEDGER.classes:
            return
        if not (
            str(getattr(cls, _CLASS_OWNER_ATTR, "")) == _OWNER
            and str(getattr(cls, _CLASS_PACKAGE_ATTR, "")) == _PACKAGE
            and str(getattr(cls, _CLASS_TOKEN_ATTR, "")) == token
            and int(getattr(cls, _CLASS_GENERATION_ATTR, -1)) == generation
        ):
            raise RuntimeError("Exact RNA class ownership token changed")
        if bool(getattr(cls, "is_registered", False)):
            bpy.utils.unregister_class(cls)
            if bool(getattr(cls, "is_registered", False)):
                raise RuntimeError("Exact RNA class remained registered after unregister")
        try:
            _LEDGER.classes.remove(cls)
        except ValueError:
            pass

    _LEDGER.acquisitions.append(_Acquisition("class", cls, release))


def _register_class_exact(cls: type) -> None:
    """Register one supplied class identity and ledger partial native success."""
    _mark_class_owner(cls)
    try:
        bpy.utils.register_class(cls)
    except Exception:
        # Some native failure paths raise after installing the exact class. Keep
        # that exact identity so current-generation rollback can release it.
        if _class_identity_valid(cls) and _class_owner_matches(cls):
            _record_class_acquisition(cls)
        raise
    if not _class_identity_valid(cls) or not _class_owner_matches(cls):
        if _class_identity_valid(cls):
            _record_class_acquisition(cls)
        raise RuntimeError("Exact RNA class identity validation failed")
    _record_class_acquisition(cls)


def _acquire_module(kind: str, register_fn: Callable[[], Any], unregister_fn: Callable[[], Any], validator: Callable[[], bool] | None = None) -> None:
    result = register_fn()
    if result is False:
        raise RuntimeError(f"Smart Composite failed to acquire {kind}")

    # Record the exact release callable immediately after acquisition. If the
    # subsequent identity validation fails, the outer generation rollback owns
    # and retries this exact module acquisition instead of losing it between the
    # register and validation phases.
    def release_module(unregister_fn=unregister_fn, kind=kind):
        result = unregister_fn()
        if result is False:
            raise RuntimeError(f"Smart Composite failed to release {kind}")

    _LEDGER.acquisitions.append(_Acquisition(kind, register_fn, release_module))
    if validator is not None and not validator():
        raise RuntimeError(f"Smart Composite {kind} identity validation failed")


def _acquire_properties_module(properties) -> bool:
    """Acquire exact properties or a validated non-mutating degraded state."""
    result = properties.register()

    def release_module(properties=properties):
        released = properties.unregister()
        if released is False:
            raise RuntimeError("Smart Composite failed to release properties")

    _LEDGER.acquisitions.append(_Acquisition("properties", properties, release_module))
    if result is False:
        if not properties.degraded_registration_valid():
            raise RuntimeError("Smart Composite properties failed without a safe degraded state")
        _LEDGER.degraded_reason = str(properties.registration_degraded_reason() or "PROPERTY_REGISTRATION_UNAVAILABLE")
        return False
    if not properties.registration_identity_valid():
        raise RuntimeError("Smart Composite properties identity validation failed")
    _LEDGER.degraded_reason = ""
    return True


def _required_operator_classes() -> tuple[type, ...]:
    from .help import SCOMP_OT_tool_help_popup
    return tuple(OPERATOR_CLASSES) + (SCOMP_OT_tool_help_popup,)


def _validate_ready() -> bool:
    from . import properties, help, proxy_cleanup, persistent_features, translation
    required_operators = tuple(OPERATOR_CLASSES)
    required_panels = tuple(UI_CLASSES)
    required_property_groups = tuple(properties.PROPERTY_GROUP_CLASSES)
    help_class = help.registered_class_identity()
    if len(required_panels) != 17 or len(required_operators) != 15:
        return False
    if help_class is not getattr(help, "SCOMP_OT_tool_help_popup", None):
        return False
    if tuple(_LEDGER.classes) != required_operators + required_panels:
        return False
    required_all = required_operators + (help_class,) + required_panels + required_property_groups
    if len(required_all) != 34:
        return False
    if not all(isinstance(cls, type) and _class_identity_valid(cls) for cls in required_all):
        return False
    if tuple(properties.registered_class_identities()) != required_property_groups:
        return False
    if not properties.registration_identity_valid():
        return False
    if not help.registration_identity_valid():
        return False
    if not proxy_cleanup.registration_identity_valid():
        return False
    if not persistent_features.registration_identity_valid():
        return False
    if not translation.registration_identity_valid():
        return False
    pointer = properties.pointer_identity()
    if pointer is None:
        return False
    _LEDGER.pointer_identity = pointer
    return True


def _validate_degraded() -> bool:
    from . import properties, help, proxy_cleanup, persistent_features, translation
    required_operators = tuple(OPERATOR_CLASSES)
    required_panels = tuple(UI_CLASSES)
    help_class = help.registered_class_identity()
    if len(required_panels) != 17 or len(required_operators) != 15:
        return False
    if help_class is not getattr(help, "SCOMP_OT_tool_help_popup", None):
        return False
    if tuple(_LEDGER.classes) != required_operators + required_panels:
        return False
    required_all = required_operators + (help_class,) + required_panels
    if len(required_all) != 33:
        return False
    if not all(isinstance(cls, type) and _class_identity_valid(cls) for cls in required_all):
        return False
    if properties.registered_class_identities() or properties.pointer_identity() is not None:
        return False
    if not properties.degraded_registration_valid():
        return False
    if not help.registration_identity_valid() or not proxy_cleanup.registration_identity_valid():
        return False
    if not persistent_features.registration_identity_valid():
        return False
    if not translation.registration_identity_valid():
        return False
    return bool(_LEDGER.degraded_reason and _LEDGER.degraded_reason == properties.registration_degraded_reason())


def _release_exact_acquisitions(*, failure_phase: str) -> tuple[str, ...]:
    """Release exact acquisitions in reverse, retrying once without losing identity."""
    failed: list[_Acquisition] = []
    errors: list[str] = []
    for acquisition in reversed(tuple(_LEDGER.acquisitions)):
        released = False
        last_error = ""
        for _attempt in range(2):
            try:
                acquisition.release()
                released = True
                break
            except Exception as exc:
                last_error = f"{acquisition.kind}: {type(exc).__name__}"
        if not released:
            failed.append(acquisition)
            errors.append(last_error or acquisition.kind)
    failed_ids = {id(item) for item in failed}
    _LEDGER.acquisitions[:] = [item for item in _LEDGER.acquisitions if id(item) in failed_ids]
    if errors:
        _LEDGER.phase = failure_phase
        _publish(failure_phase)
    return tuple(errors)


def _rollback_current_generation() -> tuple[str, ...]:
    errors = _release_exact_acquisitions(failure_phase="ROLLBACK_FAILED")
    if errors:
        return errors
    _LEDGER.acquisitions.clear()
    _LEDGER.classes.clear()
    _LEDGER.pointer_identity = None
    _LEDGER.degraded_reason = ""
    _LEDGER.phase = "ROLLED_BACK"
    if _shared_is_ours():
        namespace = _namespace()
        if namespace is not None:
            namespace.pop(_NAMESPACE_KEY, None)
    return ()


def _clear_local_ledger_after_release() -> None:
    _LEDGER.acquisitions.clear()
    _LEDGER.classes.clear()
    _LEDGER.pointer_identity = None
    _LEDGER.degraded_reason = ""


def _recover_exact_local_residue() -> bool:
    """Release only exact identities retained by this module across reload."""
    global _REGISTERED
    try:
        from . import transaction
        transaction.rollback_all()
    except Exception:
        pass
    if not _LEDGER.acquisitions:
        _REGISTERED = False
        return True
    shared_ours = _shared_is_ours()
    _LEDGER.phase = "RECOVERING"
    if shared_ours:
        _publish("RECOVERING")
    errors = _release_exact_acquisitions(failure_phase="RECOVERY_FAILED")
    if errors:
        _REGISTERED = True
        return False
    _clear_local_ledger_after_release()
    namespace = _namespace()
    if namespace is not None and shared_ours:
        current = namespace.get(_NAMESPACE_KEY)
        if isinstance(current, dict) and str(current.get("token", "")) == _LEDGER.token and int(current.get("generation", -1)) == _LEDGER.generation:
            namespace.pop(_NAMESPACE_KEY, None)
    _LEDGER.phase = "IDLE"
    _REGISTERED = False
    return True


def _begin_new_generation(existing: dict[str, Any] | None) -> None:
    prior_generation = max(
        int(_LEDGER.generation or 0),
        int(existing.get("generation", 0) or 0) if existing else 0,
    )
    _LEDGER.token = uuid.uuid4().hex
    _LEDGER.generation = prior_generation + 1
    _LEDGER.phase = "REGISTERING"
    _LEDGER.acquisitions.clear()
    _LEDGER.classes.clear()
    _LEDGER.pointer_identity = None
    _LEDGER.degraded_reason = ""
    _publish("REGISTERING")


def _acquire_current_generation() -> bool:
    """Acquire the currently prepared generation or raise for exact rollback."""
    from . import translation, properties, persistent_features, proxy_cleanup, help

    _acquire_module("translation", translation.register, translation.unregister, translation.registration_identity_valid)
    _acquire_module("proxy_cleanup", proxy_cleanup.register, proxy_cleanup.unregister, proxy_cleanup.registration_identity_valid)
    # The feature owner performs stale-resource cleanup before properties
    # restores saved ON/OFF state. Restoration therefore becomes the single
    # final application after all relevant owners exist.
    _acquire_module("persistent_features", persistent_features.register, persistent_features.unregister, persistent_features.registration_identity_valid)
    properties_ready = _acquire_properties_module(properties)
    for cls in OPERATOR_CLASSES:
        _register_class_exact(cls)
    _acquire_module("help_popup", help.register, help.unregister, help.registration_identity_valid)
    for cls in UI_CLASSES:
        _register_class_exact(cls)
    if properties_ready:
        if not _validate_ready():
            raise RuntimeError("Smart Composite required RNA identity validation failed")
        _LEDGER.phase = "READY"
        return True
    if not _validate_degraded():
        raise RuntimeError("Smart Composite degraded RNA identity validation failed")
    _LEDGER.phase = "DEGRADED"
    return True


def register() -> bool:
    """Acquire one complete generation with one bounded transient-failure retry.

    Native ``register_class`` can fail after partially installing the supplied
    class identity.  The first failed attempt is rolled back exactly and retried
    once with a fresh owner generation.  No exception is allowed to escape the
    Blender add-on enable boundary; persistent failures remain fail-closed with a
    bounded tagged diagnostic and zero partial resources.
    """
    global _REGISTERED
    if _REGISTERED or _LEDGER.acquisitions:
        try:
            shared_ours = _shared_is_ours()
            if _LEDGER.phase == "READY" and shared_ours and _validate_ready():
                return True
            if _LEDGER.phase == "DEGRADED" and shared_ours and _validate_degraded():
                return True
        except Exception as exc:
            # A stale live-reload identity must be treated as invalid state, not
            # allowed to leak a traceback through Blender's add-on enable path.
            _record_lifecycle_warning("CURRENT_GENERATION_VALIDATION_FAILED", error=exc)
        # Live source replacement changed Python identities. Recover only exact
        # identities retained in this generation ledger, then acquire a fresh
        # generation. No bpy.types/name search or foreign resource mutation.
        try:
            recovered = _recover_exact_local_residue()
        except Exception as exc:
            _record_lifecycle_warning("EXACT_RESIDUE_RECOVERY_EXCEPTION", error=exc)
            return False
        if not recovered:
            _record_lifecycle_warning("EXACT_RESIDUE_RECOVERY_FAILED")
            return False

    existing = _shared_record()
    if existing and str(existing.get("phase", "")) in {"REGISTERING", "READY", "DEGRADED"}:
        # A visible/transitioning foreign generation exists. Never unregister or
        # replace it by class name during live reload.
        if str(existing.get("token", "")) != _LEDGER.token:
            _record_lifecycle_warning("FOREIGN_VISIBLE_GENERATION")
            return False

    _REGISTER_DIAGNOSTICS.clear()
    for attempt in range(1, _MAX_REGISTER_ATTEMPTS + 1):
        existing = _shared_record()
        if existing and str(existing.get("phase", "")) in {"REGISTERING", "READY", "DEGRADED"}:
            if str(existing.get("token", "")) != _LEDGER.token:
                _record_lifecycle_warning("FOREIGN_VISIBLE_GENERATION", attempt=attempt)
                return False
        try:
            _begin_new_generation(existing)
            if not _acquire_current_generation():
                raise RuntimeError("Smart Composite generation acquisition returned false")
        except Exception as exc:
            rollback_errors = _rollback_current_generation()
            _REGISTERED = bool(rollback_errors)
            _record_lifecycle_warning(
                "REGISTER_ATTEMPT_ROLLED_BACK" if not rollback_errors else "REGISTER_ROLLBACK_FAILED",
                attempt=attempt,
                error=exc,
                rollback_errors=rollback_errors,
            )
            if rollback_errors or attempt >= _MAX_REGISTER_ATTEMPTS:
                return False
            continue
        _REGISTERED = True
        _publish(_LEDGER.phase)
        return True
    return False


def unregister() -> bool:
    """Release only identities acquired by this exact generation, in reverse."""
    global _REGISTERED
    try:
        from . import transaction
        transaction.rollback_all()
    except Exception:
        pass
    if not _REGISTERED and not _LEDGER.acquisitions:
        return False
    # Local acquisitions contain the exact identities this generation obtained.
    # A missing or replaced shared primitive record must not strand those exact
    # identities.  Releasing them cannot unregister a replacement class because
    # no bpy.types/name lookup is performed.  Publish only while the shared cell
    # still belongs to this generation.
    shared_ours = _shared_is_ours()
    _LEDGER.phase = "UNREGISTERING"
    if shared_ours:
        _publish("UNREGISTERING")
    release_errors = _release_exact_acquisitions(failure_phase="UNREGISTER_FAILED")
    if release_errors:
        _REGISTERED = True
        return False
    _LEDGER.acquisitions.clear()
    _LEDGER.classes.clear()
    _LEDGER.pointer_identity = None
    _LEDGER.degraded_reason = ""
    try:
        from . import ui, manager_bridge, catalog, visual_assets, status_runtime
        ui.clear_editor_context_cache()
        manager_bridge.clear_cache()
        catalog.clear_cache()
        visual_assets.unregister()
        status_runtime.clear_prefix()
    except Exception:
        pass
    namespace = _namespace()
    if namespace is not None and shared_ours:
        current = namespace.get(_NAMESPACE_KEY)
        if isinstance(current, dict) and str(current.get("token", "")) == _LEDGER.token and int(current.get("generation", -1)) == _LEDGER.generation:
            namespace.pop(_NAMESPACE_KEY, None)
    _LEDGER.phase = "IDLE"
    _REGISTERED = False
    return True


def is_ready() -> bool:
    try:
        return bool(_REGISTERED and _LEDGER.phase == "READY" and _shared_is_ours() and _validate_ready())
    except Exception:
        return False


def is_active() -> bool:
    try:
        if not _REGISTERED or not _shared_is_ours():
            return False
        if _LEDGER.phase == "READY":
            return _validate_ready()
        if _LEDGER.phase == "DEGRADED":
            return _validate_degraded()
    except Exception:
        return False
    return False


def owned_identity_snapshot() -> dict[str, Any]:
    return {
        "token": _LEDGER.token,
        "generation": _LEDGER.generation,
        "phase": _LEDGER.phase,
        "class_ids": tuple(id(cls) for cls in _LEDGER.classes),
        "pointer_id": id(_LEDGER.pointer_identity) if _LEDGER.pointer_identity is not None else 0,
        "degraded_reason": str(_LEDGER.degraded_reason or ""),
    }
