# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Result images for the preset list.

Every PNG in ``data/result_previews`` is the composite result of one preset
applied by this add-on's own preset builder to the same small sample scene.
The files are decoded here with the standard library and copied into one
``bpy.utils.previews`` collection as custom preview pixels, so Blender writes no
thumbnail files and every image is ready before the panel first draws.

The collection is created by ``register`` and always removed by ``unregister``.
Draw code only reads integer icon ids from a plain dict.
"""

from __future__ import annotations

import struct
import zlib
from array import array
from pathlib import Path

# Kept across a live module reload so the exact collection can still be removed.
_PREVIEWS = globals().get("_PREVIEWS")
_ICON_IDS = globals().get("_ICON_IDS") if isinstance(globals().get("_ICON_IDS"), dict) else {}
_FAILED = globals().get("_FAILED") if isinstance(globals().get("_FAILED"), dict) else {}

_FOLDER_PARTS = ("data", "result_previews")
_PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
_MAX_SIDE = 1024
ICON_SIZE = (32, 18)

# Presets that leave the output unchanged on the sample scene: their image is
# what the preset sends to its own Viewer node instead.
VIEWER_IMAGE_IDS = frozenset({
    "AOV_INTEGRITY_MATRIX", "AOV_SHUFFLE_MATRIX", "COLOR_MATCH_LOOK",
    "PRECISION_DIAGNOSTICS_HUB", "PRECISION_QC_LAB", "SIGNAL_INTEGRITY_GUARD",
})
# Presets that change neither the output nor their Viewer on the sample scene:
# their image is the sample scene as rendered.
UNCHANGED_IMAGE_IDS = frozenset({
    "APEX_VISUAL_GUIDE_BOARD", "AOV_DELTA_VERIFIER", "ASSET_SHELF_PREP",
    "DEEP_MATTE_FUSION_LAB", "DELIVERY_SANITY_CHECK", "FILE_OUTPUT_PIPELINE",
    "GEOMETRY_SIGNAL_BRIDGE", "LUT_MANAGER", "MATTE_MICROSURGERY_ENGINE",
})


def _folder() -> Path:
    return Path(__file__).resolve().parent.joinpath(*_FOLDER_PARTS)


def _decode_rgb_png(data: bytes) -> tuple[int, int, bytes]:
    """Decode the packaged layout: 8-bit RGB, no interlace, row filters None/Up.

    Up rows are undone for a whole row at once with a carry-free bytewise add on
    Python integers, so no per-pixel Python loop runs at registration.
    """
    if data[:8] != _PNG_SIGNATURE:
        raise ValueError("not a PNG file")
    pos = 8
    width = height = 0
    chunks = []
    while pos + 8 <= len(data):
        length, kind = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + length]
        pos += 12 + length
        if kind == b"IHDR":
            width, height, depth, color_type, _compression, _filter, interlace = struct.unpack(">IIBBBBB", body)
            if depth != 8 or color_type != 2 or interlace != 0:
                raise ValueError("unsupported PNG layout")
        elif kind == b"IDAT":
            chunks.append(body)
        elif kind == b"IEND":
            break
    if not (0 < width <= _MAX_SIDE and 0 < height <= _MAX_SIDE):
        raise ValueError("unsupported PNG size")
    raw = zlib.decompress(b"".join(chunks))
    stride = width * 3
    if len(raw) != height * (stride + 1):
        raise ValueError("PNG data length mismatch")
    low = int.from_bytes(b"\x7f" * stride, "big")
    high = int.from_bytes(b"\x80" * stride, "big")
    rows = []
    previous = 0
    for y in range(height):
        start = y * (stride + 1)
        row_filter = raw[start]
        line = int.from_bytes(raw[start + 1:start + 1 + stride], "big")
        if row_filter == 2:
            line = ((line & low) + (previous & low)) ^ ((line ^ previous) & high)
        elif row_filter != 0:
            raise ValueError("unsupported PNG row filter")
        rows.append(line.to_bytes(stride, "big"))
        previous = line
    return width, height, b"".join(rows)


def _rgba_bottom_up(width: int, height: int, rgb: bytes) -> bytes:
    """Blender preview pixels start at the bottom row and carry alpha."""
    stride = width * 3
    flipped = b"".join(rgb[(height - 1 - y) * stride:(height - y) * stride] for y in range(height))
    count = width * height
    rgba = bytearray(count * 4)
    rgba[0::4] = flipped[0::3]
    rgba[1::4] = flipped[1::3]
    rgba[2::4] = flipped[2::3]
    rgba[3::4] = b"\xff" * count
    return bytes(rgba)


def _icon_rgba(width: int, height: int, rgba: bytes) -> bytes:
    icon_w, icon_h = ICON_SIZE
    xs = [min(width - 1, int((index + 0.5) * width / icon_w)) for index in range(icon_w)]
    ys = [min(height - 1, int((index + 0.5) * height / icon_h)) for index in range(icon_h)]
    out = bytearray()
    for y in ys:
        row = y * width * 4
        for x in xs:
            offset = row + x * 4
            out += rgba[offset:offset + 4]
    return bytes(out)


def _set_pixels(target, rgba: bytes) -> None:
    # One 32-bit int per pixel; the bytes keep Blender's RGBA memory order.
    values = array("i")
    if values.itemsize != 4:
        raise ValueError("32-bit int array unavailable")
    values.frombytes(rgba)
    target.foreach_set(values)


def _release_collection() -> None:
    global _PREVIEWS
    collection = _PREVIEWS
    _PREVIEWS = None
    _ICON_IDS.clear()
    if collection is None:
        return
    try:
        import bpy.utils.previews as preview_api  # type: ignore
        preview_api.remove(collection)
    except Exception:
        # Blender may already have freed it during shutdown; keep no reference.
        pass


def register() -> bool:
    """Create the collection and load every packaged result image."""
    global _PREVIEWS
    _release_collection()
    _FAILED.clear()
    try:
        import bpy.utils.previews as preview_api  # type: ignore
        collection = preview_api.new()
    except Exception as exc:
        _FAILED["__collection__"] = type(exc).__name__
        return True
    _PREVIEWS = collection
    try:
        paths = sorted(path for path in _folder().iterdir() if path.suffix.lower() == ".png")
    except OSError:
        paths = []
    for path in paths:
        preset_id = path.stem.upper()
        try:
            width, height, rgb = _decode_rgb_png(path.read_bytes())
            rgba = _rgba_bottom_up(width, height, rgb)
            preview = collection.new(preset_id)
            preview.image_size = (width, height)
            _set_pixels(preview.image_pixels, rgba)
            preview.icon_size = ICON_SIZE
            _set_pixels(preview.icon_pixels, _icon_rgba(width, height, rgba))
            icon = int(preview.icon_id)
            if icon > 0:
                _ICON_IDS[preset_id] = icon
            else:
                _FAILED[preset_id] = "NO_ICON_ID"
        except Exception as exc:
            _FAILED[preset_id] = type(exc).__name__
    return True


def unregister() -> bool:
    _release_collection()
    _FAILED.clear()
    return True


def registration_identity_valid() -> bool:
    return _PREVIEWS is not None or not _ICON_IDS


def icon_id(preset_id: str) -> int:
    return int(_ICON_IDS.get(str(preset_id or "").strip().upper(), 0))


def ready_ids() -> tuple[str, ...]:
    return tuple(sorted(_ICON_IDS))


def failed() -> dict[str, str]:
    return dict(_FAILED)
