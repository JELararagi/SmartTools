# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import re
import bpy

from . import node_utils as nu
from . import storage
from .translation import t


@dataclass
class BuildResult:
    preset_id: str
    message: str
    frame_name: str = ""
    final_node_name: str = ""
    nodes_created: int = 0
    links_created: int = 0


def _settings(context=None):
    try:
        from .properties import get_settings
        return get_settings(context)
    except Exception:
        return None


def _base_path(settings=None) -> str:
    try:
        value = str(getattr(settings, "output_path", "") or "").strip()
    except Exception:
        value = ""
    if not value:
        return str(storage.default_export_dir(create=True))
    try:
        if value.startswith("//"):
            return bpy.path.abspath(value)
    except Exception:
        pass
    return value


def _origin(tree, settings=None) -> tuple[float, float]:
    return nu.next_location(tree, settings)


def _frame(tree, preset_id: str, label: str, settings=None):
    x, y = _origin(tree, settings)
    return nu.add_frame(tree, f"SCS {label}", (x, y), preset_id=preset_id)


def _image_source(tree, frame, preset_id: str, location=(-380, 40)):
    node = nu.new_node(tree, "CompositorNodeRLayers", "SCS Render Layers", location, frame, preset_id)
    return node


def _add_basic_output(tree, source, settings=None, frame=None, preset_id: str = "") -> int:
    return nu.connect_to_outputs(tree, source, settings, frame, preset_id)


def _safe_link(tree, a, b, out_names=("Image",), in_names=("Image",)) -> int:
    return 1 if nu.link(tree, a, b, out_names, in_names) else 0


def _link_if_free(tree, a, b) -> int:
    socket = nu.input_socket(b, ("Image",))
    return 0 if socket is not None and socket.is_linked else _safe_link(tree, a, b)











def _glare_quality(settings=None) -> str:
    return "HIGH" if max(_quality_rank(settings), _glow_rank(settings), _guard_rank(settings)) >= 2 else "MEDIUM"


def _guard_rank(settings=None) -> int:
    try:
        value = str(getattr(settings, "artifact_guard", "STRONG") or "STRONG").upper()
    except Exception:
        value = "STRONG"
    return {"SAFE": 0, "STRONG": 1, "SURPASS": 2}.get(value, 1)


def _qc_rank(settings=None) -> int:
    try:
        value = str(getattr(settings, "qc_density", "DEEP") or "DEEP").upper()
    except Exception:
        value = "DEEP"
    return {"LIGHT": 0, "STANDARD": 1, "DEEP": 2, "EXHAUSTIVE": 3}.get(value, 2)


def _float_setting(settings=None, name: str = "", default: float = 0.0) -> float:
    try:
        return float(getattr(settings, name, default) or default)
    except Exception:
        return float(default)


def _int_setting(settings=None, name: str = "", default: int = 0) -> int:
    try:
        return int(getattr(settings, name, default) or default)
    except Exception:
        return int(default)



def _setting_float(settings=None, attr: str = "", default: float = 0.0) -> float:
    try:
        return float(getattr(settings, attr, default))
    except Exception:
        return float(default)


def _setting_int(settings=None, attr: str = "", default: int = 0) -> int:
    try:
        return int(getattr(settings, attr, default))
    except Exception:
        return int(default)


def _artifact_guard(settings=None) -> bool:
    try:
        explicit = getattr(settings, "artifact_diagnostics", None)
        if explicit is not None:
            return bool(explicit)
    except Exception:
        pass
    try:
        level = str(getattr(settings, "artifact_guard", "STRONG") or "STRONG").upper()
        return level != "SAFE"
    except Exception:
        return True


def _precision_layers(settings=None, minimum: int = 1, maximum: int = 8) -> int:
    layers = _setting_int(settings, "precision_layers", 4)
    layers = max(minimum, min(maximum, layers))
    return max(layers, _quality_value(settings, 2, 3, 4, 6))


def _set_glare(node, glare_type: str = "FOG_GLOW", threshold: float = 0.8, size: int = 6, quality: str | None = None) -> None:
    """Configure a Glare node from a size step of 1-9 (mapped onto the 0-1 Size input)."""
    _configure_glare(node, glare_type, threshold, (float(size) - 1.0) / 8.0, quality or "HIGH")


def _set_sun_beams(node, threshold: float = 0.2) -> None:
    """Sun Beams is a Glare type on this Blender; the rays start from the frame centre."""
    socket = nu.socket_by_names(node.inputs, ("Type",))
    if socket is None or not nu.safe_set_socket(socket, "Sun Beams") or socket.default_value != "Sun Beams":
        raise RuntimeError("Compositor Glare Type was not applied: Sun Beams")
    nu.safe_set_input(node, "Threshold", float(threshold))


def _configure_glare(node, glare_type: str, threshold: float, size: float, quality: str, streaks: int | None = None) -> None:
    menus = (
        ("Type", {"FOG_GLOW": "Fog Glow", "STREAKS": "Streaks", "GHOSTS": "Ghosts"}[glare_type]),
        ("Quality", {"HIGH": "High", "MEDIUM": "Medium"}[quality]),
    )
    for name, value in menus:
        socket = nu.socket_by_names(node.inputs, (name,))
        if socket is None or not nu.safe_set_socket(socket, value) or socket.default_value != value:
            raise RuntimeError(f"Compositor Glare {name} was not applied: {value}")
    nu.safe_set_input(node, "Threshold", float(threshold))
    nu.safe_set_input(node, "Size", max(0.0, min(1.0, float(size))))
    if streaks is not None:
        nu.safe_set_input(node, "Streaks", int(streaks))


def _set_color_ramp_stops(node, stops: tuple[tuple[float, tuple[float, float, float, float]], ...]) -> None:
    ramp = node.color_ramp
    while len(ramp.elements) < len(stops):
        element = ramp.elements.new(stops[len(ramp.elements)][0])
        from . import transaction as _transaction
        _transaction.record_collection_created(ramp.elements, element)
    for element, (position, color) in zip(ramp.elements, stops):
        if not nu.safe_set(element, "position", float(position)):
            raise RuntimeError("Could not set color-ramp position")
        if not nu.safe_set(element, "color", color):
            raise RuntimeError("Could not set color-ramp color")


def _math_node(tree, label: str, operation: str, location, frame=None, preset_id: str = "", value: float | None = None):
    node = nu.new_node(tree, "CompositorNodeMath", label, location, frame, preset_id)
    nu.safe_set(node, "operation", operation)
    if value is not None:
        nu.safe_set_input(node, "Value", value)
        try:
            if len(getattr(node, "inputs", [])) > 1:
                nu.safe_set_socket(node.inputs[1], value)
        except Exception:
            pass
    return node


def _set_mid_grey_contrast(node, contrast: float, pivot: float = 0.18) -> None:
    """Contrast on a Color Balance node, pivoting on scene-linear mid grey.

    Bright/Contrast pivots on 0.5 and pushes dark values below zero per channel, which
    leaves a blue cast where red and green go negative first. A power curve cannot go negative.
    """
    power = 1.0 + float(contrast) / 100.0
    nu.safe_set_input(node, "Type", "Offset/Power/Slope (ASC-CDL)")
    nu.safe_set_input(node, "Power", power)
    nu.safe_set_input(node, "Slope", pivot ** (1.0 / power - 1.0))


def _set_highlight_rolloff(node) -> None:
    """Fixed curve on an RGB Curves node: below 0.8 stays as is, HDR values above roll off.

    The Tonemap node normalizes by the average of the image, so it also lifts a dark scene.
    """
    mapping = node.mapping
    mapping.clip_max_x = 16.0
    mapping.clip_max_y = 16.0
    curve = mapping.curves[3]
    curve.points[-1].location = (16.0, 4.0)
    for x, y in ((0.8, 0.8), (1.5, 1.3), (3.0, 1.95), (8.0, 3.0)):
        curve.points.new(x, y)
    mapping.update()


def _viewer_probe(tree, source, label: str, location, frame=None, preset_id: str = "") -> int:
    viewer = nu.new_node(tree, "CompositorNodeViewer", label, location, frame, preset_id)
    return _safe_link(tree, source, viewer, ("Image", "Value", "Alpha"), ("Image",))


def _set_blur(node, size: int) -> None:
    socket = nu.socket_by_names(node.inputs, ("Size",))
    if socket is None or socket.bl_idname != "NodeSocketVector2D" or not socket.enabled or socket.is_linked:
        raise RuntimeError("Compositor Blur requires an unlinked 2D Size input")
    value = (float(size), float(size))
    if not nu.safe_set_socket(socket, value) or tuple(socket.default_value) != value:
        raise RuntimeError("Compositor Blur Size was not applied")


def _set_filter(node, legacy_type: str) -> None:
    mapping = {"SOFTEN": "Soften", "SHARPEN": "Box Sharpen", "SOBEL": "Sobel"}
    value = mapping[legacy_type]
    socket = nu.socket_by_names(node.inputs, ("Type",))
    if socket is None or socket.bl_idname != "NodeSocketMenu" or not socket.enabled or socket.is_linked:
        raise RuntimeError("Compositor Filter requires an unlinked Type menu input")
    if not nu.safe_set_socket(socket, value) or socket.default_value != value:
        raise RuntimeError(f"Compositor Filter Type was not applied: {legacy_type}")


def _set_file_format(node, fmt: str = "OPEN_EXR_MULTILAYER") -> None:
    try:
        nu.safe_set(node.format, "file_format", fmt)
    except Exception:
        try:
            nu.safe_set(node, "file_format", fmt)
        except Exception:
            pass
    try:
        nu.safe_set(node.format, "color_depth", "32")
    except Exception:
        pass


def _mix_add(tree, base, layer, label: str, location, frame=None, preset_id: str = "", fac: float = 0.35, layer_outputs=("Image",), base_outputs=("Image",)):
    mix = nu.new_node(tree, "CompositorNodeMixRGB", label, location, frame, preset_id)
    nu.set_mix_mode(mix, "ADD")
    nu.safe_set_input(mix, "Fac", float(fac))
    links = 0
    links += _safe_link(tree, base, mix, base_outputs, (1, "Image"))
    links += _safe_link(tree, layer, mix, layer_outputs, (2, "Image"))
    return mix, links


def _mix_blend(tree, base, layer, label: str, location, frame=None, preset_id: str = "", blend: str = "MIX", fac: float = 0.5):
    mix = nu.new_node(tree, "CompositorNodeMixRGB", label, location, frame, preset_id)
    nu.set_mix_mode(mix, blend)
    nu.safe_set_input(mix, "Fac", float(fac))
    links = 0
    links += _safe_link(tree, base, mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, layer, mix, ("Image",), (2, "Image"))
    return mix, links


def _chain_links(tree, nodes, socket=("Image",)) -> int:
    links = 0
    for a, bnode in zip(nodes, nodes[1:]):
        links += _safe_link(tree, a, bnode, socket, ("Image",))
    return links




def _link_keys(tree) -> set:
    return {
        (link.from_node.name, link.from_socket.identifier, link.to_node.name, link.to_socket.identifier)
        for link in tree.links
    } if tree is not None else set()


def enable_compositor(context=None) -> BuildResult:
    ctx = context or bpy.context
    # The scene's own tree, as ensure_compositor_tree uses: the editor may be showing an opened group.
    existing = getattr(getattr(ctx, "scene", None), "compositing_node_group", None)
    start = len(existing.nodes) if existing is not None else 0
    links_before = _link_keys(existing)
    tree = nu.ensure_compositor_tree(ctx)
    render = getattr(getattr(ctx, "scene", None), "render", None)
    if render is not None and hasattr(render, "use_compositing") and not render.use_compositing:
        from . import transaction as _transaction
        _transaction.set_attr(render, "use_compositing", True)
    rlayers = None
    composite = None
    viewer = None
    for node in tree.nodes:
        blid = str(getattr(node, "bl_idname", "") or "")
        if blid == "CompositorNodeRLayers" and rlayers is None:
            rlayers = node
        elif blid == "CompositorNodeComposite" and composite is None:
            composite = node
        elif blid == "CompositorNodeViewer" and viewer is None:
            viewer = node
    if rlayers is None:
        rlayers = nu.new_node(tree, "CompositorNodeRLayers", "SCS Render Layers", (-300, 120), None, "ENABLE_COMPOSITOR")
    if composite is None or viewer is None:
        output = next((node for node in tree.nodes if node.bl_idname == "NodeGroupOutput"), None)
        location = tuple(output.location_absolute) if output is not None else (220, 100)
        composite, viewer = nu.ensure_output_nodes(tree, location, None, "ENABLE_COMPOSITOR")
    if rlayers and composite:
        _link_if_free(tree, rlayers, composite)
    if rlayers and viewer:
        _link_if_free(tree, rlayers, viewer)
    return BuildResult("ENABLE_COMPOSITOR", t("コンポジターを有効化しました。", "Compositor enabled."), nodes_created=max(0, len(tree.nodes) - start), links_created=len(_link_keys(tree) - links_before))


def enable_render_passes(context=None) -> BuildResult:
    ctx = context or bpy.context
    scene = getattr(ctx, "scene", None)
    view_layer = getattr(ctx, "view_layer", None)
    changed: list[str] = []
    skipped: list[str] = []
    if scene is not None:
        try:
            if nu.existing_compositor_tree(ctx) is not None:
                changed.append("Scene.compositor_tree")
        except Exception as exc:
            skipped.append(f"Scene.compositor_tree:{exc}")
    if view_layer is None:
        return BuildResult("ENABLE_RENDER_PASSES", t("ビューレイヤーが見つかりません。", "No View Layer found."))

    pass_attrs = (
        "use_pass_z",
        "use_pass_mist",
        "use_pass_normal",
        "use_pass_vector",
        "use_pass_diffuse_direct",
        "use_pass_diffuse_indirect",
        "use_pass_diffuse_color",
        "use_pass_glossy_direct",
        "use_pass_glossy_indirect",
        "use_pass_glossy_color",
        "use_pass_transmission_direct",
        "use_pass_transmission_indirect",
        "use_pass_transmission_color",
        "use_pass_emit",
        "use_pass_environment",
        "use_pass_ambient_occlusion",
        "use_pass_shadow",
        "use_pass_position",
        "use_pass_cryptomatte_object",
        "use_pass_cryptomatte_material",
        "use_pass_cryptomatte_asset",
    )
    for attr in pass_attrs:
        if hasattr(view_layer, attr):
            try:
                if getattr(view_layer, attr) is not True:
                    nu.safe_set(view_layer, attr, True)
                changed.append(attr)
            except Exception:
                skipped.append(attr)
        else:
            skipped.append(attr)
    try:
        if hasattr(view_layer, "pass_cryptomatte_depth"):
            nu.safe_set(view_layer, "pass_cryptomatte_depth", max(6, int(getattr(view_layer, "pass_cryptomatte_depth", 6) or 6)))
            changed.append("pass_cryptomatte_depth")
    except Exception:
        pass
    # Add custom AOV placeholders only when Blender exposes aovs.add().
    aovs = getattr(view_layer, "aovs", None)
    existing = {str(getattr(aov, "name", "")) for aov in aovs} if aovs is not None else set()
    for name in ("SCS_UtilityMask", "SCS_RelightMask", "SCS_BeautyMask"):
        if aovs is not None and name not in existing:
            aov = aovs.add()
            from . import transaction as _transaction
            _transaction.record_collection_created(aovs, aov)
            if not nu.safe_set(aov, "name", name):
                raise RuntimeError(f"Could not name compositor AOV: {name}")
            changed.append(f"AOV:{name}")
    text = t(f"合成用パスを有効化しました: {len(changed)}件。", f"Enabled compositor passes: {len(changed)} item(s).")
    if skipped:
        text += " " + t(f"未対応項目: {len(skipped)}件。", f"Unsupported/skipped: {len(skipped)} item(s).")
    return BuildResult("ENABLE_RENDER_PASSES", text)








def build_cryptomatte_extractor(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "CRYPTOMATTE_EXTRACTOR", t("クリプトマット抽出", "Cryptomatte Extractor"), settings)
    rl = _image_source(tree, frame, "CRYPTOMATTE_EXTRACTOR")
    crypto = nu.new_node(tree, "CompositorNodeCryptomatteV2", "SCS Cryptomatte Picker", (20, 80), frame, "CRYPTOMATTE_EXTRACTOR")
    if str(getattr(crypto, "bl_idname", "")) == "NodeFrame":
        crypto = nu.new_node(tree, "CompositorNodeCryptomatte", "SCS Cryptomatte Picker", (20, 80), frame, "CRYPTOMATTE_EXTRACTOR")
    blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Matte Softness", (320, 0), frame, "CRYPTOMATTE_EXTRACTOR")
    ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Matte Contrast", (560, 0), frame, "CRYPTOMATTE_EXTRACTOR")
    links = 0
    links += _safe_link(tree, rl, crypto, ("Image",), ("Image",))
    links += _safe_link(tree, crypto, blur, ("Matte", "Alpha", "Image"), ("Image",))
    links += _safe_link(tree, blur, ramp, ("Image",), ("Fac", "Value"))
    links += _add_basic_output(tree, ramp, settings, frame, "CRYPTOMATTE_EXTRACTOR")
    nu.add_note(tree, t("クリプトマットパスが未レンダーの場合は、レンダーパス有効化後に再レンダーしてください。", "If Cryptomatte passes have not been rendered, enable render passes and render again."), (40, -210), frame, "CRYPTOMATTE_EXTRACTOR")
    return BuildResult("CRYPTOMATTE_EXTRACTOR", t("クリプトマット抽出スタックを追加しました。", "Added Cryptomatte Extractor stack."), frame.name, getattr(ramp, "name", ""), len(tree.nodes) - start, links)








def build_smart_merge(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "SMART_MERGE", t("スマートマージ", "Smart Merge"), settings)
    bg = nu.new_node(tree, "CompositorNodeImage", "SCS Background Input", (-380, 120), frame, "SMART_MERGE")
    fg = nu.new_node(tree, "CompositorNodeImage", "SCS Foreground Input", (-380, -60), frame, "SMART_MERGE")
    alpha = nu.new_node(tree, "CompositorNodeAlphaOver", "SCS Alpha Over", (-80, 60), frame, "SMART_MERGE")
    add = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Add / Screen Blend", (170, 40), frame, "SMART_MERGE")
    nu.set_mix_mode(add, "ADD")
    nu.safe_set_input(add, "Fac", 0.35)
    links = 0
    links += _safe_link(tree, bg, alpha, ("Image",), ("Background",))
    links += _safe_link(tree, fg, alpha, ("Image",), ("Foreground",))
    links += _safe_link(tree, alpha, add)
    links += _safe_link(tree, fg, add, ("Image",), (2, "Image"))
    links += _add_basic_output(tree, add, settings, frame, "SMART_MERGE")
    nu.add_note(tree, t("合成の入口です。背景と前景の素材を画像のノードに割り当ててください。", "Composite entry. Assign background and foreground footage to the Image nodes."), (-350, -250), frame, "SMART_MERGE")
    return BuildResult("SMART_MERGE", t("スマートマージを追加しました。", "Added Smart Merge."), frame.name, getattr(add, "name", ""), len(tree.nodes) - start, links)




























def build_edge_rays(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "EDGE_RAYS", t("エッジレイズ", "Edge Rays"), settings)
    src = _image_source(tree, frame, "EDGE_RAYS")
    edge = nu.new_node(tree, "CompositorNodeFilter", "SCS Edge Extract", (-100, 120), frame, "EDGE_RAYS")
    ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Edge Energy Curve", (140, 120), frame, "EDGE_RAYS")
    rays = nu.new_node(tree, "CompositorNodeSunBeams", "SCS Radial Edge Rays", (390, 120), frame, "EDGE_RAYS")
    blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Ray Diffusion", (640, 120), frame, "EDGE_RAYS")
    glare = nu.new_node(tree, "CompositorNodeGlare", "SCS Ray Glow", (890, 120), frame, "EDGE_RAYS")
    _set_filter(edge, "SOBEL")
    _set_blur(blur, _quality_value(settings, 1, 2, 3, 5))
    _set_sun_beams(rays)
    _set_glare(glare, "FOG_GLOW", 0.22, quality=_glare_quality(settings))
    links = 0
    links += _safe_link(tree, src, edge)
    links += _safe_link(tree, edge, ramp, ("Image",), ("Fac", "Value"))
    links += _safe_link(tree, ramp, rays)
    links += _safe_link(tree, rays, blur)
    links += _safe_link(tree, blur, glare)
    mix, c = _mix_add(tree, src, glare, "SCS Composite Rays", (1140, 120), frame, "EDGE_RAYS", 0.28); links += c
    _add_precision_note(tree, frame, "EDGE_RAYS", settings, (-100, -220))
    links += _add_basic_output(tree, mix, settings, frame, "EDGE_RAYS")
    return BuildResult("EDGE_RAYS", t("精度強化エッジレイズを追加しました。", "Added precision Edge Rays."), frame.name, getattr(mix, "name", ""), len(tree.nodes) - start, links)


















def build_vector_motion_blur(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "VECTOR_MOTION_BLUR", t("ベクトルモーションブラー", "Vector Motion Blur"), settings)
    src = _image_source(tree, frame, "VECTOR_MOTION_BLUR")
    vec = nu.new_node(tree, "CompositorNodeVecBlur", "SCS Vector Motion Blur", (120, 120), frame, "VECTOR_MOTION_BLUR")
    clean = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Motion Blur Mix Back", (400, 120), frame, "VECTOR_MOTION_BLUR")
    nu.safe_set(vec, "samples", _quality_value(settings, 16, 32, 64, 96))
    nu.safe_set(vec, "factor", _quality_value(settings, 0.35, 0.5, 0.65, 0.75))
    nu.safe_set_input(clean, "Fac", _quality_value(settings, 0.65, 0.78, 0.88, 0.95))
    links = 0
    links += _safe_link(tree, src, vec, ("Image",), ("Image",))
    links += _safe_link(tree, src, vec, ("Z", "Depth"), ("Z",))
    links += _safe_link(tree, src, vec, ("Vector",), ("Speed", "Vector"))
    links += _safe_link(tree, src, clean, ("Image",), (1, "Image"))
    links += _safe_link(tree, vec, clean, ("Image",), (2, "Image"))
    _add_precision_note(tree, frame, "VECTOR_MOTION_BLUR", settings, (120, -180))
    links += _add_basic_output(tree, clean, settings, frame, "VECTOR_MOTION_BLUR")
    return BuildResult("VECTOR_MOTION_BLUR", t("精度強化ベクトルモーションブラーを追加しました。", "Added precision Vector Motion Blur."), frame.name, getattr(clean, "name", ""), len(tree.nodes) - start, links)






def build_color_grade_panel(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "COLOR_GRADE_PANEL", t("カラーグレード・パネル", "Color Grade Panel"), settings)
    src = _image_source(tree, frame, "COLOR_GRADE_PANEL")
    exposure = nu.new_node(tree, "CompositorNodeExposure", "SCS Exposure / Offset", (-120, 130), frame, "COLOR_GRADE_PANEL")
    balance = nu.new_node(tree, "CompositorNodeColorBalance", "SCS Lift Gamma Gain", (130, 130), frame, "COLOR_GRADE_PANEL")
    bc = nu.new_node(tree, "CompositorNodeBrightContrast", "SCS Contrast Pivot", (390, 130), frame, "COLOR_GRADE_PANEL")
    hue = nu.new_node(tree, "CompositorNodeHueSat", "SCS Hue / Saturation", (640, 130), frame, "COLOR_GRADE_PANEL")
    curves = nu.new_node(tree, "CompositorNodeCurveRGB", "SCS RGB Curves", (890, 130), frame, "COLOR_GRADE_PANEL")
    tonemap = nu.new_node(tree, "CompositorNodeCurveRGB", "SCS Highlight Roll-off", (1140, 130), frame, "COLOR_GRADE_PANEL")
    _set_highlight_rolloff(tonemap)
    clamp = nu.new_node(tree, "CompositorNodeBrightContrast", "SCS Delivery Trim", (1390, 130), frame, "COLOR_GRADE_PANEL")
    nu.safe_set_input(clamp, "Contrast", 0)
    nu.safe_set_input(clamp, "Brightness", 0)
    links = 0
    chain = [src, exposure, balance, bc, hue, curves, tonemap, clamp]
    for a, bnode in zip(chain, chain[1:]):
        links += _safe_link(tree, a, bnode)
    _add_precision_note(tree, frame, "COLOR_GRADE_PANEL", settings, (120, -170))
    links += _add_basic_output(tree, clamp, settings, frame, "COLOR_GRADE_PANEL")
    return BuildResult("COLOR_GRADE_PANEL", t("精度強化カラーグレード・パネルを追加しました。", "Added precision Color Grade Panel."), frame.name, getattr(clamp, "name", ""), len(tree.nodes) - start, links)






def build_film_look_builder(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "FILM_LOOK_BUILDER", t("フィルムルック・ビルダー", "Film Look Builder"), settings)
    src = _image_source(tree, frame, "FILM_LOOK_BUILDER")
    tone = nu.new_node(tree, "CompositorNodeTonemap", "SCS Filmic Tone Map", (-100, 150), frame, "FILM_LOOK_BUILDER")
    curves = nu.new_node(tree, "CompositorNodeCurveRGB", "SCS Film Contrast Curve", (160, 150), frame, "FILM_LOOK_BUILDER")
    hue = nu.new_node(tree, "CompositorNodeHueSat", "SCS Film Stock Saturation", (420, 150), frame, "FILM_LOOK_BUILDER")
    grain = nu.new_node(tree, "CompositorNodeTexture", "SCS Fine Grain Driver", (420, -90), frame, "FILM_LOOK_BUILDER")
    grain_mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Subtle Grain Mix", (680, 150), frame, "FILM_LOOK_BUILDER")
    vignette = _vignette_nodes(tree, frame, "FILM_LOOK_BUILDER", (930, 100), grain_mix)
    nu.set_mix_mode(grain_mix, "ADD")
    nu.safe_set_input(grain_mix, "Fac", _quality_value(settings, 0.015, 0.02, 0.025, 0.03))
    links = 0
    links += _safe_link(tree, src, tone)
    links += _safe_link(tree, tone, curves)
    links += _safe_link(tree, curves, hue)
    links += _safe_link(tree, hue, grain_mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, grain, grain_mix, ("Value", "Color", "Image"), (2, "Image"))
    final = vignette if vignette else grain_mix
    _add_precision_note(tree, frame, "FILM_LOOK_BUILDER", settings, (150, -300))
    links += _add_basic_output(tree, final, settings, frame, "FILM_LOOK_BUILDER")
    return BuildResult("FILM_LOOK_BUILDER", t("精度強化フィルムルック・ビルダーを追加しました。", "Added precision Film Look Builder."), frame.name, getattr(final, "name", ""), len(tree.nodes) - start, links)






def build_color_match_look(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "COLOR_MATCH_LOOK", t("カラーマッチ", "Color Match Look"), settings)
    target = _image_source(tree, frame, "COLOR_MATCH_LOOK", (-460, 140))
    reference = nu.new_node(tree, "CompositorNodeImage", "SCS Reference Image", (-460, -80), frame, "COLOR_MATCH_LOOK")
    target_view = nu.new_node(tree, "CompositorNodeViewer", "SCS Target QC Viewer", (-160, 260), frame, "COLOR_MATCH_LOOK")
    ref_view = nu.new_node(tree, "CompositorNodeViewer", "SCS Reference QC Viewer", (-160, -220), frame, "COLOR_MATCH_LOOK")
    curves = nu.new_node(tree, "CompositorNodeCurveRGB", "SCS Manual Match Curves", (-120, 140), frame, "COLOR_MATCH_LOOK")
    balance = nu.new_node(tree, "CompositorNodeColorBalance", "SCS Match Balance", (140, 140), frame, "COLOR_MATCH_LOOK")
    mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Match Strength", (400, 140), frame, "COLOR_MATCH_LOOK")
    nu.safe_set_input(mix, "Fac", 0.65)
    links = 0
    links += _safe_link(tree, target, target_view)
    links += _safe_link(tree, reference, ref_view)
    links += _safe_link(tree, target, curves)
    links += _safe_link(tree, curves, balance)
    links += _safe_link(tree, target, mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, balance, mix, ("Image",), (2, "Image"))
    _add_precision_note(tree, frame, "COLOR_MATCH_LOOK", settings, (-120, -340))
    links += _add_basic_output(tree, mix, settings, frame, "COLOR_MATCH_LOOK")
    return BuildResult("COLOR_MATCH_LOOK", t("精度強化カラーマッチ構成を追加しました。", "Added precision Color Match Look setup."), frame.name, getattr(mix, "name", ""), len(tree.nodes) - start, links)




def build_lut_manager(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "LUT_MANAGER", t("LUTマネージャー", "LUT Manager"), settings)
    src = _image_source(tree, frame, "LUT_MANAGER")
    curves = nu.new_node(tree, "CompositorNodeCurveRGB", "SCS LUT Trim Curves", (-40, 100), frame, "LUT_MANAGER")
    exposure = nu.new_node(tree, "CompositorNodeExposure", "SCS Pre/Post LUT Exposure", (210, 100), frame, "LUT_MANAGER")
    links = 0
    links += _safe_link(tree, src, curves)
    links += _safe_link(tree, curves, exposure)
    links += _add_basic_output(tree, exposure, settings, frame, "LUT_MANAGER")
    nu.add_note(tree, t("Blender標準コンポジターには汎用LUTノードが無いため、OCIO/色管理はBlender側設定と外部LUTワークフローで管理します。", "Blender's compositor does not expose a generic LUT node in all builds, so OCIO/color management is handled through Blender settings and external LUT workflows."), (-50, -170), frame, "LUT_MANAGER")
    return BuildResult("LUT_MANAGER", t("LUT管理レーンを追加しました。", "Added LUT management lane."), frame.name, getattr(exposure, "name", ""), len(tree.nodes) - start, links)


def _vignette_nodes(tree, frame, preset_id: str, location, source_node=None):
    x, y = location
    ellipse = nu.new_node(tree, "CompositorNodeEllipseMask", "SCS Vignette Mask", (x, y - 160), frame, preset_id)
    blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Vignette Feather", (x + 210, y - 160), frame, preset_id)
    invert = nu.new_node(tree, "CompositorNodeInvert", "SCS Invert Vignette", (x + 430, y - 160), frame, preset_id)
    mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Vignette Mix", (x + 650, y), frame, preset_id)
    render = bpy.context.scene.render
    width = max(1.0, render.resolution_x * render.resolution_percentage / 100.0)
    height = max(1.0, render.resolution_y * render.resolution_percentage / 100.0)
    # Mask Size is relative to the image width, so the height is scaled to follow the frame shape.
    nu.safe_set_input(ellipse, "Size", (1.12, 1.12 * height / width))
    _set_blur(blur, max(1, int(width * 0.16)))
    nu.set_mix_mode(mix, "MULTIPLY")
    nu.safe_set_socket(nu.input_socket(mix, ("Color2",)), (0.3, 0.3, 0.3, 1.0))
    nu.link_sockets(tree, nu.output_socket(ellipse, ("Mask", "Image")), nu.input_socket(blur, ("Image",)))
    nu.link_sockets(tree, nu.output_socket(blur), nu.input_socket(invert, ("Color", "Image", "Fac")))
    nu.link_sockets(tree, nu.output_socket(invert), nu.input_socket(mix, ("Fac",)))
    if source_node is not None:
        _safe_link(tree, source_node, mix, ("Image",), (1, "Image"))
    return mix


def build_vignette_finish(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "VIGNETTE_FINISH", t("ビネット仕上げ", "Vignette Finish"), settings)
    src = _image_source(tree, frame, "VIGNETTE_FINISH")
    mix = _vignette_nodes(tree, frame, "VIGNETTE_FINISH", (-70, 80), src)
    links = _add_basic_output(tree, mix, settings, frame, "VIGNETTE_FINISH")
    return BuildResult("VIGNETTE_FINISH", t("ビネット仕上げを追加しました。", "Added Vignette Finish."), frame.name, getattr(mix, "name", ""), len(tree.nodes) - start, links)










def build_beauty_retouch(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "BEAUTY_RETOUCH", t("ビューティ補正", "Beauty Retouch"), settings)
    src = _image_source(tree, frame, "BEAUTY_RETOUCH")
    mask = nu.new_node(tree, "CompositorNodeImage", "SCS Optional Skin / Person Mask", (-420, -100), frame, "BEAUTY_RETOUCH")
    blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Frequency Soft Layer", (-80, 120), frame, "BEAUTY_RETOUCH")
    sharpen = nu.new_node(tree, "CompositorNodeFilter", "SCS Detail Preserve", (-80, -80), frame, "BEAUTY_RETOUCH")
    mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Beauty Mix", (190, 120), frame, "BEAUTY_RETOUCH")
    detail, links = _mix_add(tree, mix, sharpen, "SCS Restore Texture", (460, 120), frame, "BEAUTY_RETOUCH", 0.10)
    _set_blur(blur, _quality_value(settings, 5, 8, 12, 16))
    _set_filter(sharpen, "SHARPEN")
    nu.safe_set_input(mix, "Fac", 0.28)
    links += _safe_link(tree, src, blur)
    links += _safe_link(tree, src, sharpen)
    links += _safe_link(tree, src, mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, blur, mix, ("Image",), (2, "Image"))
    links += _safe_link(tree, mask, mix, ("Image", "Alpha"), ("Fac",))
    _add_precision_note(tree, frame, "BEAUTY_RETOUCH", settings, (-80, -250))
    links += _add_basic_output(tree, detail, settings, frame, "BEAUTY_RETOUCH")
    return BuildResult("BEAUTY_RETOUCH", t("精度強化ビューティ補正を追加しました。", "Added precision Beauty Retouch."), frame.name, getattr(detail, "name", ""), len(tree.nodes) - start, links)






def build_sharpen_detail(context=None) -> BuildResult:
    """Boost local contrast as a gain on the log luminance, so HDR edges cannot ring into negative or tinted pixels."""
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    pid = "SHARPEN_DETAIL"
    frame = _frame(tree, pid, t("シャープ/ディテール", "Sharpen Detail"), settings)
    src = _image_source(tree, frame, pid)
    luma = nu.new_node(tree, "CompositorNodeRGBToBW", "SCS Detail Luminance", (-100, 300), frame, pid)
    floor = _math_node(tree, "SCS Log Floor", "ADD", (100, 300), frame, pid, 0.01)
    log_luma = _math_node(tree, "SCS Log Luminance", "LOGARITHM", (300, 300), frame, pid, 2.718282)
    blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Low Frequency Blur", (300, 80), frame, pid)
    highpass = _math_node(tree, "SCS High-pass Difference", "SUBTRACT", (540, 300), frame, pid)
    square = _math_node(tree, "SCS Edge Strength", "MULTIPLY", (740, 80), frame, pid)
    falloff = _math_node(tree, "SCS Highlight Edge Falloff", "MULTIPLY_ADD", (940, 80), frame, pid)
    limited = _math_node(tree, "SCS Highlight Edge Limiter", "DIVIDE", (1140, 300), frame, pid)
    gain = _math_node(tree, "SCS Detail Gain", "MULTIPLY", (1340, 300), frame, pid, _quality_value(settings, 1.2, 1.6, 2.0, 2.4))
    ratio = _math_node(tree, "SCS Detail Ratio", "EXPONENT", (1540, 300), frame, pid)
    final = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Detail Amount", (1740, 100), frame, pid)
    _set_blur(blur, _quality_value(settings, 1, 2, 3, 4))
    nu.safe_set_socket(falloff.inputs[1], 11.0)
    nu.safe_set_socket(falloff.inputs[2], 1.0)
    nu.set_mix_mode(final, "MULTIPLY")
    nu.safe_set_input(final, "Fac", 1.0)
    links = 0
    links += _safe_link(tree, src, luma)
    links += int(nu.link_sockets(tree, nu.output_socket(luma), floor.inputs[0]))
    links += int(nu.link_sockets(tree, nu.output_socket(floor), log_luma.inputs[0]))
    links += int(nu.link_sockets(tree, nu.output_socket(log_luma), nu.input_socket(blur)))
    links += int(nu.link_sockets(tree, nu.output_socket(log_luma), highpass.inputs[0]))
    links += int(nu.link_sockets(tree, nu.output_socket(blur), highpass.inputs[1]))
    links += int(nu.link_sockets(tree, nu.output_socket(highpass), square.inputs[0]))
    links += int(nu.link_sockets(tree, nu.output_socket(highpass), square.inputs[1]))
    links += int(nu.link_sockets(tree, nu.output_socket(square), falloff.inputs[0]))
    links += int(nu.link_sockets(tree, nu.output_socket(highpass), limited.inputs[0]))
    links += int(nu.link_sockets(tree, nu.output_socket(falloff), limited.inputs[1]))
    links += int(nu.link_sockets(tree, nu.output_socket(limited), gain.inputs[0]))
    links += int(nu.link_sockets(tree, nu.output_socket(gain), ratio.inputs[0]))
    links += _safe_link(tree, src, final, ("Image",), (1, "Image"))
    links += int(nu.link_sockets(tree, nu.output_socket(ratio), final.inputs[2]))
    _add_precision_note(tree, frame, pid, settings, (-90, -230))
    links += _add_basic_output(tree, final, settings, frame, pid)
    return BuildResult(pid, t("精度強化シャープ/ディテールを追加しました。", "Added precision Sharpen Detail."), frame.name, getattr(final, "name", ""), len(tree.nodes) - start, links)




def build_optical_distort(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "OPTICAL_DISTORT", t("光学歪み", "Optical Distort"), settings)
    src = _image_source(tree, frame, "OPTICAL_DISTORT")
    lens = nu.new_node(tree, "CompositorNodeLensdist", "SCS Lens Distortion / Dispersion", (-80, 110), frame, "OPTICAL_DISTORT")
    transform = nu.new_node(tree, "CompositorNodeTransform", "SCS Optical Transform", (180, 110), frame, "OPTICAL_DISTORT")
    mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Distortion Amount", (430, 110), frame, "OPTICAL_DISTORT")
    nu.safe_set_input(lens, "Distort", 0.04)
    nu.safe_set_input(lens, "Dispersion", 0.015)
    nu.safe_set_input(mix, "Fac", 0.5)
    links = 0
    links += _safe_link(tree, src, lens)
    links += _safe_link(tree, lens, transform)
    links += _safe_link(tree, src, mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, transform, mix, ("Image",), (2, "Image"))
    links += _add_basic_output(tree, mix, settings, frame, "OPTICAL_DISTORT")
    return BuildResult("OPTICAL_DISTORT", t("光学歪みを追加しました。", "Added Optical Distort."), frame.name, getattr(mix, "name", ""), len(tree.nodes) - start, links)


def build_heat_haze_distort(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "HEAT_HAZE_DISTORT", t("陽炎歪み", "Heat Haze Distort"), settings)
    src = _image_source(tree, frame, "HEAT_HAZE_DISTORT")
    tex = nu.new_node(tree, "CompositorNodeTexture", "SCS Animated Noise Driver", (-100, -100), frame, "HEAT_HAZE_DISTORT")
    amount = nu.new_node(tree, "ShaderNodeVectorMath", "SCS Heat Amount", (-100, -540), frame, "HEAT_HAZE_DISTORT")
    clock = nu.new_node(tree, "CompositorNodeSceneTime", "SCS Heat Clock", (-560, -100), frame, "HEAT_HAZE_DISTORT")
    speed = _math_node(tree, "SCS Heat Speed", "MULTIPLY", (-330, -100), frame, "HEAT_HAZE_DISTORT", 0.05)
    displace = nu.new_node(tree, "CompositorNodeDisplace", "SCS Heat Displace", (160, 90), frame, "HEAT_HAZE_DISTORT")
    blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Heat Softening", (420, 90), frame, "HEAT_HAZE_DISTORT")
    nu.safe_set(tex, "noise_dimensions", "4D")
    nu.set_edges_extend(displace)
    nu.safe_set(amount, "operation", "MULTIPLY_ADD")
    nu.safe_set_socket(amount.inputs[1], (24.0, 12.0, 0.0))
    nu.safe_set_socket(amount.inputs[2], (-12.0, -6.0, 0.0))
    _set_blur(blur, 1)
    links = 0
    links += _safe_link(tree, src, displace, ("Image",), ("Image",))
    links += int(nu.link_sockets(tree, nu.socket_by_names(clock.outputs, ("Frame",)), speed.inputs[0]))
    links += _safe_link(tree, speed, tex, ("Value",), ("W",))
    links += int(nu.link_sockets(tree, nu.socket_by_names(tex.outputs, ("Color",)), amount.inputs[0]))
    links += _safe_link(tree, amount, displace, ("Vector",), ("Displacement",))
    links += _safe_link(tree, displace, blur)
    links += _add_basic_output(tree, blur, settings, frame, "HEAT_HAZE_DISTORT")
    nu.add_note(tree, t("ノイズの「スケール」で揺らぎの細かさ、「陽炎の量」の値で揺らぎの大きさを変えられます。", "Noise Scale sets the shimmer detail, and the Heat Amount multiplier sets its size."), (170, -250), frame, "HEAT_HAZE_DISTORT")
    return BuildResult("HEAT_HAZE_DISTORT", t("陽炎歪みを追加しました。", "Added Heat Haze Distort."), frame.name, getattr(blur, "name", ""), len(tree.nodes) - start, links)


def build_glitch_stylize(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "GLITCH_STYLIZE", t("グリッチ/デジタルダメージ", "Glitch Stylize"), settings)
    src = _image_source(tree, frame, "GLITCH_STYLIZE")
    sep = nu.new_node(tree, "CompositorNodeSepRGBA", "SCS RGB Split", (-80, 100), frame, "GLITCH_STYLIZE")
    txr = nu.new_node(tree, "CompositorNodeTranslate", "SCS Red Channel Offset", (160, 170), frame, "GLITCH_STYLIZE")
    txb = nu.new_node(tree, "CompositorNodeTranslate", "SCS Blue Channel Offset", (160, 20), frame, "GLITCH_STYLIZE")
    comb = nu.new_node(tree, "CompositorNodeCombRGBA", "SCS Recombine Glitch", (420, 90), frame, "GLITCH_STYLIZE")
    mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Glitch Amount", (670, 90), frame, "GLITCH_STYLIZE")
    nu.safe_set_input(txr, "X", 8.0)
    nu.safe_set_input(txb, "X", -8.0)
    nu.set_edges_extend(txr)
    nu.set_edges_extend(txb)
    nu.safe_set_input(mix, "Fac", 0.5)
    links = 0
    links += _safe_link(tree, src, sep)
    links += int(nu.link_sockets(tree, nu.socket_by_names(sep.outputs, ("R",)), txr.inputs[0]))
    links += int(nu.link_sockets(tree, nu.socket_by_names(sep.outputs, ("B",)), txb.inputs[0]))
    links += int(nu.link_sockets(tree, nu.output_socket(txr), nu.socket_by_names(comb.inputs, ("R",))))
    links += int(nu.link_sockets(tree, nu.socket_by_names(sep.outputs, ("G",)), nu.socket_by_names(comb.inputs, ("G",))))
    links += int(nu.link_sockets(tree, nu.output_socket(txb), nu.socket_by_names(comb.inputs, ("B",))))
    links += int(nu.link_sockets(tree, nu.socket_by_names(sep.outputs, ("A",)), nu.socket_by_names(comb.inputs, ("A",))))
    links += _safe_link(tree, src, mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, comb, mix, ("Image",), (2, "Image"))
    links += _add_basic_output(tree, mix, settings, frame, "GLITCH_STYLIZE")
    return BuildResult("GLITCH_STYLIZE", t("グリッチ/デジタルダメージを追加しました。", "Added Glitch Stylize."), frame.name, getattr(mix, "name", ""), len(tree.nodes) - start, links)




def build_depth_fog_relight(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "DEPTH_FOG_RELIGHT", t("深度フォグ/遠近", "Depth Fog / Atmosphere"), settings)
    src = _image_source(tree, frame, "DEPTH_FOG_RELIGHT")
    maprange = nu.new_node(tree, "CompositorNodeMapRange", "SCS Depth Normalize", (-120, -90), frame, "DEPTH_FOG_RELIGHT")
    ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Fog Density Curve", (140, -90), frame, "DEPTH_FOG_RELIGHT")
    blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Depth Matte Smooth", (380, -90), frame, "DEPTH_FOG_RELIGHT")
    fog_color = nu.new_node(tree, "CompositorNodeRGB", "SCS Fog Color", (140, 170), frame, "DEPTH_FOG_RELIGHT")
    mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Depth Fog Mix", (650, 110), frame, "DEPTH_FOG_RELIGHT")
    _set_blur(blur, _quality_value(settings, 1, 2, 4, 6))
    nu.safe_set_input(maprange, "From Min", float(getattr(settings, "depth_near", 1.0) or 1.0))
    nu.safe_set_input(maprange, "From Max", float(getattr(settings, "depth_far", 100.0) or 100.0))
    nu.safe_set_output(fog_color, "Image", (0.65, 0.72, 0.82, 1.0))
    nu.safe_set_output(fog_color, "Color", (0.65, 0.72, 0.82, 1.0))
    links = 0
    links += _safe_link(tree, src, maprange, ("Z", "Depth", "Mist"), ("Value",))
    links += _safe_link(tree, maprange, ramp, ("Value",), ("Fac", "Value"))
    links += _safe_link(tree, ramp, blur)
    links += _safe_link(tree, blur, mix, ("Image", "Alpha"), ("Fac",))
    links += _safe_link(tree, src, mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, fog_color, mix, ("Image", "Color"), (2, "Image"))
    _add_precision_note(tree, frame, "DEPTH_FOG_RELIGHT", settings, (-100, -300))
    links += _add_basic_output(tree, mix, settings, frame, "DEPTH_FOG_RELIGHT")
    return BuildResult("DEPTH_FOG_RELIGHT", t("精度強化深度フォグ/遠近を追加しました。", "Added precision Depth Fog / Atmosphere."), frame.name, getattr(mix, "name", ""), len(tree.nodes) - start, links)






def build_normal_relight(context=None) -> BuildResult:
    """Brighten each pixel by the dot product of its Normal pass and a light direction, keeping the image colors."""
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    pid = "NORMAL_RELIGHT"
    frame = _frame(tree, pid, t("法線疑似リライト", "Normal Relight"), settings)
    src = _image_source(tree, frame, pid)
    direction = nu.new_node(tree, "ShaderNodeVectorMath", "SCS Light Direction", (-90, -240), frame, pid)
    facing = nu.new_node(tree, "ShaderNodeVectorMath", "SCS Normal Dot Light", (150, -60), frame, pid)
    lit = _math_node(tree, "SCS Lit Side Only", "MAXIMUM", (390, -60), frame, pid, 0.0)
    blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Relight Diffusion", (620, -60), frame, pid)
    light = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Relight Light", (860, -60), frame, pid)
    shade = nu.new_node(tree, "CompositorNodeHueSat", "SCS Relight Tint", (1100, -60), frame, pid)
    mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Relight Composite", (1340, 100), frame, pid)
    nu.safe_set(direction, "operation", "NORMALIZE")
    nu.safe_set_socket(direction.inputs[0], (-0.5, -0.6, 0.62))
    nu.safe_set(facing, "operation", "DOT_PRODUCT")
    _set_blur(blur, _quality_value(settings, 0, 1, 2, 3))
    nu.set_mix_mode(light, "MULTIPLY")
    nu.safe_set_input(light, "Fac", 1.0)
    nu.set_mix_mode(mix, "ADD")
    nu.safe_set_input(mix, "Fac", _quality_value(settings, 0.35, 0.5, 0.65, 0.8))
    links = 0
    normal = nu.socket_by_names(src.outputs, ("Normal",))
    has_normal = normal is not None and normal.enabled
    if has_normal:
        links += int(nu.link_sockets(tree, normal, facing.inputs[0]))
    links += int(nu.link_sockets(tree, nu.socket_by_names(direction.outputs, ("Vector",)), facing.inputs[1]))
    links += int(nu.link_sockets(tree, nu.socket_by_names(facing.outputs, ("Value",)), lit.inputs[0]))
    links += int(nu.link_sockets(tree, nu.output_socket(lit), nu.input_socket(blur)))
    links += _safe_link(tree, src, light, ("Image",), (1, "Image"))
    links += _safe_link(tree, blur, light, ("Image",), (2, "Image"))
    links += _safe_link(tree, light, shade)
    links += _safe_link(tree, src, mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, shade, mix, ("Image",), (2, "Image"))
    _add_precision_note(tree, frame, pid, settings, (-80, -420))
    nu.add_note(tree, t("「光の向き」の入力で光の向き、「リライトの合成」の係数で強さを変えられます。", "The Light Direction input sets the light direction, and the Relight Composite Fac sets its strength."), (150, -280), frame, pid)
    links += _add_basic_output(tree, mix, settings, frame, pid)
    if has_normal:
        message = t("精度強化法線疑似リライトを追加しました。", "Added precision Normal Relight.")
    else:
        message = t("法線パスが無いので画像は変わりません。法線パスを有効にしてから追加し直してください。", "The Normal pass is off, so the image stays unchanged. Enable the Normal pass, then add this again.")
    return BuildResult(pid, message, frame.name, getattr(mix, "name", ""), len(tree.nodes) - start, links)


def build_height_to_normal(context=None) -> BuildResult:
    """Make a normal map from height: the Depth pass when it is on, otherwise the image brightness."""
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    pid = "HEIGHT_TO_NORMAL_PROXY"
    frame = _frame(tree, pid, t("高さから法線", "Height to Normal"), settings)
    src = _image_source(tree, frame, pid)
    links = 0
    depth = nu.socket_by_names(src.outputs, ("Depth", "Z"))
    has_depth = depth is not None and depth.enabled
    if has_depth:
        raised = _math_node(tree, "SCS Near Is High", "SUBTRACT", (150, 100), frame, pid)
        nu.safe_set_socket(raised.inputs[0], 0.0)
        links += int(nu.link_sockets(tree, depth, raised.inputs[1]))
        height = nu.output_socket(raised)
    else:
        luma = nu.new_node(tree, "CompositorNodeRGBToBW", "SCS Brightness Height", (150, 100), frame, pid)
        links += _safe_link(tree, src, luma)
        height = nu.output_socket(luma)
    slopes = []
    for axis, y in (("X", 300), ("Y", -60)):
        ahead = nu.new_node(tree, "CompositorNodeTranslate", f"SCS Height {axis} +1", (390, y), frame, pid)
        behind = nu.new_node(tree, "CompositorNodeTranslate", f"SCS Height {axis} -1", (390, y - 150), frame, pid)
        nu.safe_set_input(ahead, axis, 1.0)
        nu.safe_set_input(behind, axis, -1.0)
        nu.set_edges_extend(ahead)
        nu.set_edges_extend(behind)
        slope = _math_node(tree, f"SCS Slope {axis}", "SUBTRACT", (630, y - 60), frame, pid)
        links += int(nu.link_sockets(tree, height, ahead.inputs[0]))
        links += int(nu.link_sockets(tree, height, behind.inputs[0]))
        links += int(nu.link_sockets(tree, nu.output_socket(ahead), slope.inputs[0]))
        links += int(nu.link_sockets(tree, nu.output_socket(behind), slope.inputs[1]))
        slopes.append(slope)
    strength = nu.new_node(tree, "ShaderNodeValue", "SCS Normal Strength", (630, 60), frame, pid)
    nu.safe_set_output(strength, "Value", 50.0 if has_depth else 6.0)
    combine = nu.new_node(tree, "ShaderNodeCombineXYZ", "SCS Normal Vector", (1110, 120), frame, pid)
    nu.safe_set_input(combine, "Z", 1.0)
    for slope, name, y in ((slopes[0], "X", 240), (slopes[1], "Y", 0)):
        scaled = _math_node(tree, f"SCS Scaled Slope {name}", "MULTIPLY", (870, y), frame, pid)
        links += int(nu.link_sockets(tree, nu.output_socket(slope), scaled.inputs[0]))
        links += int(nu.link_sockets(tree, nu.output_socket(strength), scaled.inputs[1]))
        links += int(nu.link_sockets(tree, nu.output_socket(scaled), nu.socket_by_names(combine.inputs, (name,))))
    unit = nu.new_node(tree, "ShaderNodeVectorMath", "SCS Normal Normalize", (1350, 120), frame, pid)
    nu.safe_set(unit, "operation", "NORMALIZE")
    encode = nu.new_node(tree, "ShaderNodeVectorMath", "SCS Normal Encode", (1590, 120), frame, pid)
    nu.safe_set(encode, "operation", "MULTIPLY_ADD")
    nu.safe_set_socket(encode.inputs[1], (0.5, 0.5, 0.5))
    nu.safe_set_socket(encode.inputs[2], (0.5, 0.5, 0.5))
    mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Normal Preview", (1830, 120), frame, pid)
    nu.safe_set_input(mix, "Fac", 1.0)
    links += int(nu.link_sockets(tree, nu.socket_by_names(combine.outputs, ("Vector",)), unit.inputs[0]))
    links += int(nu.link_sockets(tree, nu.socket_by_names(unit.outputs, ("Vector",)), encode.inputs[0]))
    links += _safe_link(tree, src, mix, ("Image",), (1, "Image"))
    links += int(nu.link_sockets(tree, nu.socket_by_names(encode.outputs, ("Vector",)), mix.inputs[2]))
    nu.add_note(tree, t("「法線の強さ」の値で凹凸の強さ、「法線のプレビュー」の係数で元の画像との混ざり具合を変えられます。", "Normal Strength sets the relief, and the Normal Preview Fac blends with the original image."), (870, -260), frame, pid)
    links += _add_basic_output(tree, mix, settings, frame, pid)
    if has_depth:
        message = t("深度パスを高さにして法線を作りました。", "Built a normal map from the Depth pass.")
    else:
        message = t("深度パスが無いので、画像の明るさを高さにして法線を作りました。", "The Depth pass is off, so the image brightness was used as height.")
    return BuildResult(pid, message, frame.name, getattr(mix, "name", ""), len(tree.nodes) - start, links)






def build_particle_lights(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "PARTICLE_LIGHTS", t("光粒子/ノイズ生成", "Particle Lights"), settings)
    src = _image_source(tree, frame, "PARTICLE_LIGHTS")
    tex = nu.new_node(tree, "CompositorNodeTexture", "SCS Procedural Noise / Dust", (-110, -80), frame, "PARTICLE_LIGHTS")
    ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Particle Threshold", (150, -80), frame, "PARTICLE_LIGHTS")
    blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Particle Softness", (400, -80), frame, "PARTICLE_LIGHTS")
    glare = nu.new_node(tree, "CompositorNodeGlare", "SCS Particle Glow", (650, -80), frame, "PARTICLE_LIGHTS")
    mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Add Particles", (910, 90), frame, "PARTICLE_LIGHTS")
    nu.safe_set_input(tex, "Scale", 60.0)
    nu.safe_set_input(tex, "Detail", 0.0)
    _set_color_ramp_stops(ramp, ((0.72, (0.0, 0.0, 0.0, 1.0)), (0.76, (1.0, 1.0, 1.0, 1.0))))
    _set_blur(blur, _quality_value(settings, 0, 1, 2, 3))
    _set_glare(glare, "FOG_GLOW", 0.35, quality=_glare_quality(settings))
    nu.set_mix_mode(mix, "ADD")
    nu.safe_set_input(mix, "Fac", _quality_value(settings, 0.15, 0.22, 0.28, 0.34))
    links = 0
    links += _safe_link(tree, tex, ramp, ("Value", "Color", "Image"), ("Fac", "Value"))
    links += _safe_link(tree, ramp, blur)
    links += _safe_link(tree, blur, glare)
    links += _safe_link(tree, src, mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, glare, mix, ("Image",), (2, "Image"))
    _add_precision_note(tree, frame, "PARTICLE_LIGHTS", settings, (-90, -300))
    links += _add_basic_output(tree, mix, settings, frame, "PARTICLE_LIGHTS")
    return BuildResult("PARTICLE_LIGHTS", t("精度強化光粒子/ノイズ生成を追加しました。", "Added precision Particle Lights."), frame.name, getattr(mix, "name", ""), len(tree.nodes) - start, links)






def build_time_echo(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "TIME_ECHO", t("時間残像", "Time Echo"), settings)
    current = _image_source(tree, frame, "TIME_ECHO", (-460, 160))
    prev = nu.new_node(tree, "CompositorNodeImage", "SCS Previous Frame / Echo Plate", (-460, -30), frame, "TIME_ECHO")
    nextp = nu.new_node(tree, "CompositorNodeImage", "SCS Next Frame / Forward Echo", (-460, -220), frame, "TIME_ECHO")
    # Alpha Over keeps the render untouched while a plate has no image assigned.
    mix1 = nu.new_node(tree, "CompositorNodeAlphaOver", "SCS Backward Echo Mix", (-130, 90), frame, "TIME_ECHO")
    mix2 = nu.new_node(tree, "CompositorNodeAlphaOver", "SCS Forward Echo Mix", (130, 90), frame, "TIME_ECHO")
    blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Temporal Softness", (390, 90), frame, "TIME_ECHO")
    nu.safe_set_input(mix1, "Fac", 0.28)
    nu.safe_set_input(mix2, "Fac", 0.18)
    _set_blur(blur, _quality_value(settings, 0, 1, 2, 3))
    links = 0
    links += _safe_link(tree, current, mix1, ("Image",), ("Background",))
    links += _safe_link(tree, prev, mix1, ("Image",), ("Foreground",))
    links += _safe_link(tree, mix1, mix2, ("Image",), ("Background",))
    links += _safe_link(tree, nextp, mix2, ("Image",), ("Foreground",))
    links += _safe_link(tree, mix2, blur)
    _add_precision_note(tree, frame, "TIME_ECHO", settings, (-420, -390))
    links += _add_basic_output(tree, blur, settings, frame, "TIME_ECHO")
    return BuildResult("TIME_ECHO", t("精度強化時間残像スタックを追加しました。", "Added precision Time Echo stack."), frame.name, getattr(blur, "name", ""), len(tree.nodes) - start, links)






def build_slap_comp(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "SLAP_COMP", t("スラップコンプ作業台", "Slap Comp Workbench"), settings)
    plate = nu.new_node(tree, "CompositorNodeImage", "SCS Plate / Background", (-460, 180), frame, "SLAP_COMP")
    render = _image_source(tree, frame, "SLAP_COMP", (-460, 0))
    shadow = nu.new_node(tree, "CompositorNodeImage", "SCS Shadow / Contact Pass", (-460, -180), frame, "SLAP_COMP")
    merge = nu.new_node(tree, "CompositorNodeAlphaOver", "SCS CG Over Plate", (-130, 80), frame, "SLAP_COMP")
    # Alpha Over over its default white: no shadow image multiplies by white and changes nothing.
    shadow_plate = nu.new_node(tree, "CompositorNodeAlphaOver", "SCS Shadow Over White", (-130, -180), frame, "SLAP_COMP")
    shadow_mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Contact Shadow Mix", (150, 80), frame, "SLAP_COMP")
    grade = nu.new_node(tree, "CompositorNodeColorBalance", "SCS Match Grade", (410, 80), frame, "SLAP_COMP")
    grain = nu.new_node(tree, "CompositorNodeAlphaOver", "SCS Plate Grain Integration", (670, 80), frame, "SLAP_COMP")
    nu.set_mix_mode(shadow_mix, "MULTIPLY")
    nu.safe_set_input(shadow_mix, "Fac", 0.35)
    nu.safe_set_input(grain, "Fac", 0.08)
    links = 0
    links += _safe_link(tree, plate, merge, ("Image",), ("Background",))
    links += _safe_link(tree, render, merge, ("Image",), ("Foreground",))
    links += _safe_link(tree, merge, shadow_mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, shadow, shadow_plate, ("Image",), ("Foreground",))
    links += _safe_link(tree, shadow_plate, shadow_mix, ("Image",), (2, "Image"))
    links += _safe_link(tree, shadow_mix, grade)
    links += _safe_link(tree, grade, grain, ("Image",), ("Background",))
    links += _safe_link(tree, plate, grain, ("Image",), ("Foreground",))
    _add_precision_note(tree, frame, "SLAP_COMP", settings, (-120, -320))
    links += _add_basic_output(tree, grain, settings, frame, "SLAP_COMP")
    return BuildResult("SLAP_COMP", t("精度強化スラップコンプ作業台を追加しました。", "Added precision Slap Comp Workbench."), frame.name, getattr(grain, "name", ""), len(tree.nodes) - start, links)




def build_asset_shelf_prep(context=None) -> BuildResult:
    ctx = context or bpy.context
    tree = nu.active_compositor_tree(ctx)
    count = 0
    from . import transaction
    active = transaction.current()
    for node_group in tuple(getattr(bpy.data, "node_groups", ()) or ()):
        if not nu.is_owned_node_group(node_group, getattr(ctx, "scene", None)):
            continue
        asset_mark = getattr(node_group, "asset_mark", None)
        if not callable(asset_mark):
            continue
        try:
            already_marked = getattr(node_group, "asset_data", None) is not None
        except Exception:
            already_marked = False
        if already_marked:
            continue
        asset_mark()
        if active is not None:
            def restore_asset_state(group=node_group):
                try:
                    clear = getattr(group, "asset_clear", None)
                    if callable(clear):
                        clear()
                except Exception:
                    pass
            active.add_undo(restore_asset_state)
        count += 1
    if count == 0:
        # Add visible note instead of silently doing nothing.
        settings = _settings(ctx)
        frame = _frame(tree, "ASSET_SHELF_PREP", t("アセットシェルフ準備", "Asset Shelf Prep"), settings)
        nu.add_note(tree, t("アセット化できるSCSノードグループはまだありません。今後のグループ化プリセット用の互換枠です。", "No SCS node groups are available for asset marking yet. This is a compatibility slot for future grouped presets."), (0, 0), frame, "ASSET_SHELF_PREP")
    return BuildResult("ASSET_SHELF_PREP", t(f"アセット化処理を実行しました: {count}件。", f"Asset marking executed: {count} item(s)."), nodes_created=0)



def build_precision_qc_lab(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "PRECISION_QC_LAB", t("精度診断ラボ", "Precision QC Lab"), settings)
    src = _image_source(tree, frame, "PRECISION_QC_LAB", (-520, 180))
    luma = nu.new_node(tree, "CompositorNodeRGBToBW", "SCS Luminance Probe", (-250, 260), frame, "PRECISION_QC_LAB")
    clip_ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS HDR Clip Risk Mask", (0, 260), frame, "PRECISION_QC_LAB")
    _set_color_ramp_stops(clip_ramp, ((0.70, (0.0, 0.0, 0.0, 1.0)), (0.96, (1.0, 1.0, 1.0, 1.0))))
    alpha_ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Alpha Edge Risk Mask", (0, 80), frame, "PRECISION_QC_LAB")
    _set_color_ramp_stops(alpha_ramp, ((0.02, (0.0, 0.0, 0.0, 1.0)), (0.20, (1.0, 1.0, 1.0, 1.0))))
    depth_norm = nu.new_node(tree, "CompositorNodeNormalize", "SCS Z Normalize Probe", (-250, -110), frame, "PRECISION_QC_LAB")
    depth_ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Z Range Heatmap", (0, -110), frame, "PRECISION_QC_LAB")
    normal_sep = nu.new_node(tree, "CompositorNodeSepRGBA", "SCS Normal Channel Probe", (-250, -300), frame, "PRECISION_QC_LAB")
    vector_sep = nu.new_node(tree, "CompositorNodeSepRGBA", "SCS Vector Channel Probe", (-250, -500), frame, "PRECISION_QC_LAB")
    links = 0
    links += _safe_link(tree, src, luma)
    links += _safe_link(tree, luma, clip_ramp, ("Val", "Value", "Image"), ("Fac", "Value"))
    links += _safe_link(tree, src, alpha_ramp, ("Alpha",), ("Fac", "Value"))
    links += _safe_link(tree, src, depth_norm, ("Z", "Depth"), ("Value", "Image"))
    links += _safe_link(tree, depth_norm, depth_ramp, ("Value", "Image"), ("Fac", "Value"))
    links += _safe_link(tree, src, normal_sep, ("Normal",), ("Image",))
    links += _safe_link(tree, src, vector_sep, ("Vector",), ("Image",))
    if _artifact_guard(settings):
        links += _viewer_probe(tree, clip_ramp, "SCS Viewer - HDR Clip Risk", (260, 260), frame, "PRECISION_QC_LAB")
        links += _viewer_probe(tree, alpha_ramp, "SCS Viewer - Alpha Edge Risk", (260, 80), frame, "PRECISION_QC_LAB")
        links += _viewer_probe(tree, depth_ramp, "SCS Viewer - Z Range", (260, -110), frame, "PRECISION_QC_LAB")
    if bool(getattr(settings, "create_file_outputs", True)):
        fout = nu.add_file_output(tree, "SCS QC EXR Diagnostic Output", _base_path(settings), ("HDR_Clip_Risk", "Alpha_Edge_Risk", "Z_Range", "Normal_QC", "Vector_QC"), (520, -70), frame, "PRECISION_QC_LAB")
        _set_file_format(fout)
        links += _safe_link(tree, clip_ramp, fout, ("Image", "Value"), ("HDR_Clip_Risk", "Image"))
        links += _link_file_input(tree, alpha_ramp, fout, ("Image",), ("Alpha_Edge_Risk",))
        links += _link_file_input(tree, depth_ramp, fout, ("Image",), ("Z_Range",))
        links += _link_file_input(tree, src, fout, ("Normal",), ("Normal_QC",))
        links += _link_file_input(tree, src, fout, ("Vector",), ("Vector_QC",))
    _add_precision_note(tree, frame, "PRECISION_QC_LAB", settings, (-220, -720))
    links += _add_basic_output(tree, src, settings, frame, "PRECISION_QC_LAB")
    return BuildResult("PRECISION_QC_LAB", t("精度診断ラボを追加しました。", "Added Precision QC Lab."), frame.name, getattr(src, "name", ""), len(tree.nodes) - start, links)


def build_hdr_highlight_guard(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "HDR_HIGHLIGHT_GUARD", t("HDRハイライト保護", "HDR Highlight Guard"), settings)
    src = _image_source(tree, frame, "HDR_HIGHLIGHT_GUARD", (-520, 120))
    luma = nu.new_node(tree, "CompositorNodeRGBToBW", "SCS HDR Luma Analyze", (-260, -80), frame, "HDR_HIGHLIGHT_GUARD")
    mask = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Highlight Isolation", (-20, -80), frame, "HDR_HIGHLIGHT_GUARD")
    softness = max(0.68, 0.86 - _setting_float(settings, "optical_realism", 0.72) * 0.12)
    _set_color_ramp_stops(mask, ((softness, (0.0, 0.0, 0.0, 1.0)), (0.98, (1.0, 1.0, 1.0, 1.0))))
    blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Soft Highlight Matte", (230, -80), frame, "HDR_HIGHLIGHT_GUARD")
    _set_blur(blur, _quality_value(settings, 2, 4, 7, 10))
    rolloff = nu.new_node(tree, "CompositorNodeTonemap", "SCS Filmic Rolloff Core", (-30, 140), frame, "HDR_HIGHLIGHT_GUARD")
    exposure = nu.new_node(tree, "CompositorNodeExposure", "SCS Protected Exposure Trim", (210, 140), frame, "HDR_HIGHLIGHT_GUARD")
    mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Highlight Guard Mix", (500, 140), frame, "HDR_HIGHLIGHT_GUARD")
    nu.safe_set_input(exposure, "Exposure", -0.08 * _quality_value(settings, 1, 2, 3, 4))
    nu.safe_set_input(mix, "Fac", min(0.82, 0.35 + _setting_float(settings, "optical_realism", 0.72) * 0.35))
    links = 0
    links += _safe_link(tree, src, luma)
    links += _safe_link(tree, luma, mask, ("Val", "Value", "Image"), ("Fac", "Value"))
    links += _safe_link(tree, mask, blur)
    links += _safe_link(tree, src, rolloff)
    links += _safe_link(tree, rolloff, exposure)
    links += _safe_link(tree, blur, mix, ("Image", "Value"), ("Fac",))
    links += _safe_link(tree, src, mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, exposure, mix, ("Image",), (2, "Image"))
    if _artifact_guard(settings):
        links += _viewer_probe(tree, blur, "SCS Viewer - Highlight Matte", (500, -120), frame, "HDR_HIGHLIGHT_GUARD")
    _add_precision_note(tree, frame, "HDR_HIGHLIGHT_GUARD", settings, (-60, -300))
    links += _add_basic_output(tree, mix, settings, frame, "HDR_HIGHLIGHT_GUARD")
    return BuildResult("HDR_HIGHLIGHT_GUARD", t("HDRハイライト保護を追加しました。", "Added HDR Highlight Guard."), frame.name, getattr(mix, "name", ""), len(tree.nodes) - start, links)


def build_subpixel_matte_lab(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "SUBPIXEL_MATTE_LAB", t("サブピクセルマットラボ", "Subpixel Matte Lab"), settings)
    src = _image_source(tree, frame, "SUBPIXEL_MATTE_LAB", (-560, 140))
    matte_input = nu.new_node(tree, "CompositorNodeImage", "SCS Optional External Matte", (-560, -110), frame, "SUBPIXEL_MATTE_LAB")
    luma = nu.new_node(tree, "CompositorNodeRGBToBW", "SCS Matte Luma Fallback", (-310, 140), frame, "SUBPIXEL_MATTE_LAB")
    pre = nu.new_node(tree, "CompositorNodeBlur", "SCS Noise Pre-smooth", (-70, 140), frame, "SUBPIXEL_MATTE_LAB")
    density = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Density / Hole Control", (170, 140), frame, "SUBPIXEL_MATTE_LAB")
    safety = _setting_float(settings, "matte_edge_safety", 0.65)
    _set_color_ramp_stops(density, ((0.10 + safety * 0.10, (0.0, 0.0, 0.0, 1.0)), (0.78 - safety * 0.18, (1.0, 1.0, 1.0, 1.0))))
    choke = nu.new_node(tree, "CompositorNodeDilateErode", "SCS Subpixel Choke", (420, 220), frame, "SUBPIXEL_MATTE_LAB")
    expand = nu.new_node(tree, "CompositorNodeDilateErode", "SCS Subpixel Expand", (420, 40), frame, "SUBPIXEL_MATTE_LAB")
    nu.safe_set(choke, "distance", -max(1, int(1 + safety * 5)))
    nu.safe_set(expand, "distance", max(1, int(1 + safety * 4)))
    core_mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Core / Fringe Balance", (670, 130), frame, "SUBPIXEL_MATTE_LAB")
    nu.safe_set_input(core_mix, "Fac", min(0.82, 0.30 + safety * 0.45))
    feather = nu.new_node(tree, "CompositorNodeBlur", "SCS Subpixel Feather", (920, 130), frame, "SUBPIXEL_MATTE_LAB")
    _set_blur(feather, max(1, int(_quality_value(settings, 2, 4, 6, 9) * (0.6 + safety))))
    setalpha = nu.new_node(tree, "CompositorNodeSetAlpha", "SCS Apply Laboratory Alpha", (1180, 130), frame, "SUBPIXEL_MATTE_LAB")
    edge_qc = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Matte Edge QC", (920, -80), frame, "SUBPIXEL_MATTE_LAB")
    links = 0
    links += _safe_link(tree, src, luma)
    links += _safe_link(tree, luma, pre)
    links += _safe_link(tree, pre, density, ("Image", "Value"), ("Fac", "Value"))
    links += _safe_link(tree, density, choke)
    links += _safe_link(tree, density, expand)
    links += _safe_link(tree, choke, core_mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, expand, core_mix, ("Image",), (2, "Image"))
    links += _safe_link(tree, core_mix, feather)
    links += _safe_link(tree, feather, edge_qc, ("Image", "Value"), ("Fac", "Value"))
    links += _safe_link(tree, src, setalpha, ("Image",), ("Image",))
    links += _safe_link(tree, feather, setalpha, ("Image", "Value"), ("Alpha",))
    # Optional external matte is intentionally left unconnected so an empty Image node cannot override the generated matte.
    if _artifact_guard(settings):
        links += _viewer_probe(tree, edge_qc, "SCS Viewer - Matte Edge QC", (1180, -80), frame, "SUBPIXEL_MATTE_LAB")
    _add_precision_note(tree, frame, "SUBPIXEL_MATTE_LAB", settings, (160, -310))
    links += _add_basic_output(tree, setalpha, settings, frame, "SUBPIXEL_MATTE_LAB")
    return BuildResult("SUBPIXEL_MATTE_LAB", t("サブピクセルマットラボを追加しました。", "Added Subpixel Matte Lab."), frame.name, getattr(setalpha, "name", ""), len(tree.nodes) - start, links)


def build_optical_bloom_lab(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "OPTICAL_BLOOM_LAB", t("光学ブルームラボ", "Optical Bloom Lab"), settings)
    src = _image_source(tree, frame, "OPTICAL_BLOOM_LAB", (-560, 180))
    realism = _setting_float(settings, "optical_realism", 0.72)
    layers = max(3, min(6, _precision_layers(settings, 3, 6)))
    links = 0
    current = src
    for index in range(layers):
        y = 230 - index * 150
        glare = nu.new_node(tree, "CompositorNodeGlare", f"SCS Multi-lobe Bloom {index + 1}", (-270, y), frame, "OPTICAL_BLOOM_LAB")
        glare_type = "FOG_GLOW" if index % 3 == 0 else ("STREAKS" if index % 3 == 1 else "GHOSTS")
        _set_glare(glare, glare_type, max(0.18, 0.92 - realism * 0.35 - index * 0.08), min(9, 4 + index), _glare_quality(settings))
        blur = nu.new_node(tree, "CompositorNodeBlur", f"SCS Optical Spread {index + 1}", (-20, y), frame, "OPTICAL_BLOOM_LAB")
        _set_blur(blur, int(2 + index * 3 + realism * 4))
        links += _safe_link(tree, src, glare)
        links += _safe_link(tree, glare, blur, ("Glare",))
        current, add_links = _mix_add(tree, current, blur, f"SCS Energy-preserved Add {index + 1}", (260 + index * 230, y), frame, "OPTICAL_BLOOM_LAB", fac=min(0.28, 0.08 + realism * 0.16))
        links += add_links
    lens = nu.new_node(tree, "CompositorNodeLensdist", "SCS Micro Chromatic Dispersion", (260 + layers * 230, -80), frame, "OPTICAL_BLOOM_LAB")
    nu.safe_set(lens, "use_fit", True)
    nu.safe_set_input(lens, "Dispersion", 0.01 + realism * 0.035)
    final, add_links = _mix_blend(tree, current, lens, "SCS Bloom / Dispersion Composite", (520 + layers * 230, 80), frame, "OPTICAL_BLOOM_LAB", fac=0.18 + realism * 0.14)
    links += _safe_link(tree, current, lens)
    links += add_links
    if _artifact_guard(settings):
        links += _viewer_probe(tree, final, "SCS Viewer - Optical Bloom QC", (800 + layers * 230, 80), frame, "OPTICAL_BLOOM_LAB")
    _add_precision_note(tree, frame, "OPTICAL_BLOOM_LAB", settings, (-260, -600))
    links += _add_basic_output(tree, final, settings, frame, "OPTICAL_BLOOM_LAB")
    return BuildResult("OPTICAL_BLOOM_LAB", t("光学ブルームラボを追加しました。", "Added Optical Bloom Lab."), frame.name, getattr(final, "name", ""), len(tree.nodes) - start, links)


def build_restoration_lab(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "RESTORATION_LAB", t("復元精度ラボ", "Restoration Lab"), settings)
    src = _image_source(tree, frame, "RESTORATION_LAB", (-520, 120))
    strength = _setting_float(settings, "restoration_strength", 0.38)
    denoise = nu.new_node(tree, "CompositorNodeDenoise", "SCS Profile-style Denoise", (-250, 160), frame, "RESTORATION_LAB")
    bilateral = nu.new_node(tree, "CompositorNodeBilateralblur", "SCS Edge-preserve Smooth", (20, 160), frame, "RESTORATION_LAB")
    low = nu.new_node(tree, "CompositorNodeBlur", "SCS Low-frequency Deband", (280, 160), frame, "RESTORATION_LAB")
    _set_blur(low, max(1, int(2 + strength * 8 + _quality_rank(settings))))
    high = nu.new_node(tree, "CompositorNodeFilter", "SCS High-frequency Detail", (280, -50), frame, "RESTORATION_LAB")
    _set_filter(high, "SHARPEN")
    rebuild = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Detail-safe Rebuild", (560, 120), frame, "RESTORATION_LAB")
    nu.safe_set_input(rebuild, "Fac", min(0.75, 0.22 + strength * 0.55))
    compare = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Before / After Compare", (830, 120), frame, "RESTORATION_LAB")
    nu.safe_set_input(compare, "Fac", 1.0)
    links = 0
    links += _safe_link(tree, src, denoise, ("Image",), ("Image",))
    links += _safe_link(tree, src, denoise, ("Normal",), ("Normal",))
    links += _safe_link(tree, src, denoise, ("DiffCol", "Diffuse Color", "Albedo"), ("Albedo",))
    links += _safe_link(tree, denoise, bilateral)
    links += _safe_link(tree, bilateral, low)
    links += _safe_link(tree, src, high)
    links += _safe_link(tree, low, rebuild, ("Image",), (1, "Image"))
    links += _safe_link(tree, high, rebuild, ("Image",), (2, "Image"))
    links += _safe_link(tree, src, compare, ("Image",), (1, "Image"))
    links += _safe_link(tree, rebuild, compare, ("Image",), (2, "Image"))
    if _artifact_guard(settings):
        diff = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Restoration Delta QC", (830, -90), frame, "RESTORATION_LAB")
        nu.set_mix_mode(diff, "DIFFERENCE")
        nu.safe_set_input(diff, "Fac", 1.0)
        links += _safe_link(tree, src, diff, ("Image",), (1, "Image"))
        links += _safe_link(tree, rebuild, diff, ("Image",), (2, "Image"))
        links += _viewer_probe(tree, diff, "SCS Viewer - Restoration Delta", (1090, -90), frame, "RESTORATION_LAB")
    _add_precision_note(tree, frame, "RESTORATION_LAB", settings, (-80, -300))
    links += _add_basic_output(tree, rebuild, settings, frame, "RESTORATION_LAB")
    return BuildResult("RESTORATION_LAB", t("復元精度ラボを追加しました。", "Added Restoration Lab."), frame.name, getattr(rebuild, "name", ""), len(tree.nodes) - start, links)


def build_depth_vector_audit(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "DEPTH_VECTOR_AUDIT", t("深度／ベクトル診断", "Depth / Vector Audit"), settings)
    src = _image_source(tree, frame, "DEPTH_VECTOR_AUDIT", (-500, 160))
    z_norm = nu.new_node(tree, "CompositorNodeNormalize", "SCS Z Normalized", (-230, 220), frame, "DEPTH_VECTOR_AUDIT")
    z_ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Z Heatmap", (20, 220), frame, "DEPTH_VECTOR_AUDIT")
    mist_ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Mist Heatmap", (20, 40), frame, "DEPTH_VECTOR_AUDIT")
    normal_sep = nu.new_node(tree, "CompositorNodeSepRGBA", "SCS Normal Split", (-230, -150), frame, "DEPTH_VECTOR_AUDIT")
    vector_sep = nu.new_node(tree, "CompositorNodeSepRGBA", "SCS Vector Split", (-230, -360), frame, "DEPTH_VECTOR_AUDIT")
    links = 0
    links += _safe_link(tree, src, z_norm, ("Z", "Depth"), ("Value", "Image"))
    links += _safe_link(tree, z_norm, z_ramp, ("Value", "Image"), ("Fac", "Value"))
    links += _safe_link(tree, src, mist_ramp, ("Mist",), ("Fac", "Value"))
    links += _safe_link(tree, src, normal_sep, ("Normal",), ("Image",))
    links += _safe_link(tree, src, vector_sep, ("Vector",), ("Image",))
    if _artifact_guard(settings):
        links += _viewer_probe(tree, z_ramp, "SCS Viewer - Z Heatmap", (290, 220), frame, "DEPTH_VECTOR_AUDIT")
        links += _viewer_probe(tree, mist_ramp, "SCS Viewer - Mist Heatmap", (290, 40), frame, "DEPTH_VECTOR_AUDIT")
        links += _viewer_probe(tree, normal_sep, "SCS Viewer - Normal QC", (290, -150), frame, "DEPTH_VECTOR_AUDIT")
        links += _viewer_probe(tree, vector_sep, "SCS Viewer - Vector QC", (290, -360), frame, "DEPTH_VECTOR_AUDIT")
    if bool(getattr(settings, "create_file_outputs", True)):
        fout = nu.add_file_output(tree, "SCS Depth Vector Audit EXR", _base_path(settings), ("Z_Normalized", "Mist_QC", "Normal_QC", "Vector_QC"), (560, 30), frame, "DEPTH_VECTOR_AUDIT")
        _set_file_format(fout)
        links += _safe_link(tree, z_ramp, fout, ("Image", "Value"), ("Image", "Z_Normalized"))
        links += _link_file_input(tree, mist_ramp, fout, ("Image",), ("Mist_QC",))
        links += _link_file_input(tree, src, fout, ("Normal",), ("Normal_QC",))
        links += _link_file_input(tree, src, fout, ("Vector",), ("Vector_QC",))
    _add_precision_note(tree, frame, "DEPTH_VECTOR_AUDIT", settings, (-200, -600))
    links += _add_basic_output(tree, z_ramp, settings, frame, "DEPTH_VECTOR_AUDIT")
    return BuildResult("DEPTH_VECTOR_AUDIT", t("深度／ベクトル診断を追加しました。", "Added Depth / Vector Audit."), frame.name, getattr(z_ramp, "name", ""), len(tree.nodes) - start, links)


def build_precision_overdrive_workspace(context=None) -> BuildResult:
    ctx = context or bpy.context
    results = [enable_compositor(ctx), enable_render_passes(ctx)]
    functions = (
        build_precision_qc_lab,
        build_hdr_highlight_guard,
        build_subpixel_matte_lab,
        build_optical_bloom_lab,
        build_restoration_lab,
        build_depth_vector_audit,
        build_aov_shuffle_matrix,
        build_color_grade_panel,
        build_file_output_pipeline,
    )
    results.extend(_run_workbench_stages(ctx, functions))
    nodes = sum(result.nodes_created for result in results)
    links = sum(result.links_created for result in results)
    return BuildResult("PRECISION_OVERDRIVE_WORKSPACE", t("精度極限コンポジット作業台を追加しました。", "Added Precision Overdrive Composite Workspace."), nodes_created=nodes, links_created=links)


def build_precision_qc_suite(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "PRECISION_QC_SUITE", t("精度QCツールセット", "Precision QC Toolset"), settings)
    src = _image_source(tree, frame, "PRECISION_QC_SUITE", (-520, 260))
    sep = nu.new_node(tree, "CompositorNodeSepRGBA", "SCS RGBA Channel Probe", (-230, 260), frame, "PRECISION_QC_SUITE")
    luma = nu.new_node(tree, "CompositorNodeRGBToBW", "SCS Luma Probe", (-230, 60), frame, "PRECISION_QC_SUITE")
    alpha_ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Alpha Edge Heatmap", (40, 140), frame, "PRECISION_QC_SUITE")
    luma_ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Luma Range Heatmap", (40, -60), frame, "PRECISION_QC_SUITE")
    depth_norm = nu.new_node(tree, "CompositorNodeNormalize", "SCS Z Normalize", (-230, -250), frame, "PRECISION_QC_SUITE")
    depth_ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Z Range Heatmap", (40, -250), frame, "PRECISION_QC_SUITE")
    normal_probe = nu.new_node(tree, "NodeReroute", "SCS Normal Probe", (-20, -460), frame, "PRECISION_QC_SUITE")
    vector_probe = nu.new_node(tree, "NodeReroute", "SCS Vector Probe", (-20, -570), frame, "PRECISION_QC_SUITE")
    highlight = nu.new_node(tree, "CompositorNodeBrightContrast", "SCS Highlight Clip Probe", (320, 80), frame, "PRECISION_QC_SUITE")
    nu.safe_set_input(highlight, "Brightness", -_float_setting(settings, "highlight_ceiling", 1.0) * 0.05)
    nu.safe_set_input(highlight, "Contrast", 24 + _qc_rank(settings) * 6)
    links = 0
    links += _safe_link(tree, src, sep)
    links += _safe_link(tree, src, luma)
    links += _safe_link(tree, sep, alpha_ramp, ("A", "Alpha", "Image"), ("Fac", "Value"))
    links += _safe_link(tree, luma, luma_ramp, ("Val", "Image", "Value"), ("Fac", "Value"))
    links += _safe_link(tree, src, depth_norm, ("Z", "Depth"), ("Value", "Image"))
    links += _safe_link(tree, depth_norm, depth_ramp, ("Value", "Image"), ("Fac", "Value"))
    links += _safe_link(tree, src, normal_probe, ("Normal",), ("Input",))
    links += _safe_link(tree, src, vector_probe, ("Vector",), ("Input",))
    links += _safe_link(tree, src, highlight)
    if bool(getattr(settings, "create_file_outputs", True)):
        slots = ("QC_Beauty", "QC_Alpha", "QC_Luma", "QC_Depth", "QC_Normal", "QC_Vector", "QC_Highlight")
        fout = nu.add_file_output(tree, "SCS Precision QC Output", _base_path(settings), slots, (620, -140), frame, "PRECISION_QC_SUITE")
        _set_file_format(fout)
        links += _safe_link(tree, src, fout, ("Image",), ("QC_Beauty", "Image"))
        links += _safe_link(tree, alpha_ramp, fout, ("Image", "Color"), ("QC_Alpha",))
        links += _safe_link(tree, luma_ramp, fout, ("Image", "Color"), ("QC_Luma",))
        links += _safe_link(tree, depth_ramp, fout, ("Image", "Color"), ("QC_Depth",))
        links += _safe_link(tree, highlight, fout, ("Image",), ("QC_Highlight",))
        links += _link_file_input(tree, src, fout, ("Normal",), ("QC_Normal",))
        links += _link_file_input(tree, src, fout, ("Vector",), ("QC_Vector",))
    if _qc_rank(settings) >= 2:
        nu.add_note(tree, t("QCは最終絵を作るノードではなく、破綻を見つける診断レーンです。アルファ、Z、法線、ベクトル、ハイライトを個別にビューアーへ接続して確認してください。", "QC lanes are diagnostics, not the final look. Connect Alpha, Z, Normal, Vector, and Highlight probes to Viewer individually when checking."), (320, -390), frame, "PRECISION_QC_SUITE")
    if _qc_rank(settings) >= 3:
        nu.add_note(tree, t("最大QCでは、マット縁、白飛び、深度飽和、ベクトル欠落を優先確認します。レンダーパスが無い項目は空出力になります。", "Exhaustive QC prioritizes matte edges, clipping, depth saturation, and missing vector data. Lanes without rendered passes may stay empty."), (320, -540), frame, "PRECISION_QC_SUITE")
    links += _add_basic_output(tree, luma_ramp, settings, frame, "PRECISION_QC_SUITE")
    return BuildResult("PRECISION_QC_SUITE", t("精度QCツールセットを追加しました。", "Added Precision QC Toolset."), frame.name, getattr(luma_ramp, "name", ""), len(tree.nodes) - start, links)


def build_matte_edge_lab(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "MATTE_EDGE_LAB", t("マット縁精度ラボ", "Matte Edge Lab"), settings)
    plate = _image_source(tree, frame, "MATTE_EDGE_LAB", (-520, 160))
    matte = nu.new_node(tree, "CompositorNodeImage", "SCS Matte Input / External Mask", (-520, -80), frame, "MATTE_EDGE_LAB")
    bw = nu.new_node(tree, "CompositorNodeRGBToBW", "SCS Matte Luma", (-250, -80), frame, "MATTE_EDGE_LAB")
    pre = nu.new_node(tree, "CompositorNodeBlur", "SCS Pre-filter Speckle", (-20, -80), frame, "MATTE_EDGE_LAB")
    ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Core Density Curve", (230, -80), frame, "MATTE_EDGE_LAB")
    choke = nu.new_node(tree, "CompositorNodeDilateErode", "SCS Inner Choke", (480, 50), frame, "MATTE_EDGE_LAB")
    expand = nu.new_node(tree, "CompositorNodeDilateErode", "SCS Outer Expand", (480, -200), frame, "MATTE_EDGE_LAB")
    inner = nu.new_node(tree, "CompositorNodeBlur", "SCS Inner Feather", (720, 50), frame, "MATTE_EDGE_LAB")
    outer = nu.new_node(tree, "CompositorNodeBlur", "SCS Outer Feather", (720, -200), frame, "MATTE_EDGE_LAB")
    blend = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Edge Fusion", (980, -60), frame, "MATTE_EDGE_LAB")
    setalpha = nu.new_node(tree, "CompositorNodeSetAlpha", "SCS Apply Edge Matte", (1230, 120), frame, "MATTE_EDGE_LAB")
    qc = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Matte Edge QC", (1230, -140), frame, "MATTE_EDGE_LAB")
    radius = _int_setting(settings, "matte_edge_radius", 3)
    _set_blur(pre, 1 if _guard_rank(settings) else 0)
    _set_blur(inner, max(1, radius + _quality_rank(settings)))
    _set_blur(outer, max(1, radius + _quality_rank(settings) + _guard_rank(settings)))
    nu.safe_set(choke, "distance", -max(1, radius))
    nu.safe_set(expand, "distance", max(1, radius))
    nu.safe_set_input(blend, "Fac", 0.50 if _guard_rank(settings) < 2 else 0.42)
    links = 0
    links += _safe_link(tree, matte, bw)
    links += _safe_link(tree, bw, pre, ("Val", "Image", "Value"), ("Image",))
    links += _safe_link(tree, pre, ramp, ("Image",), ("Fac", "Value"))
    links += _safe_link(tree, ramp, choke)
    links += _safe_link(tree, ramp, expand)
    links += _safe_link(tree, choke, inner)
    links += _safe_link(tree, expand, outer)
    links += _safe_link(tree, inner, blend, ("Image",), (1, "Image"))
    links += _safe_link(tree, outer, blend, ("Image",), (2, "Image"))
    links += _safe_link(tree, plate, setalpha, ("Image",), ("Image",))
    links += _safe_link(tree, blend, setalpha, ("Image",), ("Alpha", "Fac"))
    links += _safe_link(tree, blend, qc, ("Image",), ("Fac", "Value"))
    _add_precision_note(tree, frame, "MATTE_EDGE_LAB", settings, (-60, -410))
    links += _add_basic_output(tree, setalpha, settings, frame, "MATTE_EDGE_LAB")
    return BuildResult("MATTE_EDGE_LAB", t("マット縁精度ラボを追加しました。", "Added Matte Edge Lab."), frame.name, getattr(setalpha, "name", ""), len(tree.nodes) - start, links)


def build_spectral_light_lab(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "SPECTRAL_LIGHT_LAB", t("スペクトル光学ラボ", "Spectral Light Lab"), settings)
    src = _image_source(tree, frame, "SPECTRAL_LIGHT_LAB", (-520, 160))
    isolate = nu.new_node(tree, "CompositorNodeBrightContrast", "SCS HDR Highlight Isolation", (-240, 160), frame, "SPECTRAL_LIGHT_LAB")
    core = nu.new_node(tree, "CompositorNodeGlare", "SCS Micro Bloom", (40, 260), frame, "SPECTRAL_LIGHT_LAB")
    mid = nu.new_node(tree, "CompositorNodeGlare", "SCS Mid Bloom", (40, 80), frame, "SPECTRAL_LIGHT_LAB")
    wide = nu.new_node(tree, "CompositorNodeGlare", "SCS Atmos Bloom", (40, -100), frame, "SPECTRAL_LIGHT_LAB")
    streak = nu.new_node(tree, "CompositorNodeGlare", "SCS Lens Streak Field", (40, -280), frame, "SPECTRAL_LIGHT_LAB")
    rays = nu.new_node(tree, "CompositorNodeSunBeams", "SCS Stray-light Rays", (330, -280), frame, "SPECTRAL_LIGHT_LAB")
    chroma = nu.new_node(tree, "CompositorNodeLensdist", "SCS Chromatic Edge Guard", (620, -80), frame, "SPECTRAL_LIGHT_LAB")
    trim = nu.new_node(tree, "CompositorNodeBrightContrast", "SCS Highlight Safety Trim", (870, 120), frame, "SPECTRAL_LIGHT_LAB")
    q = _quality_rank(settings)
    guard = _guard_rank(settings)
    ceiling = _float_setting(settings, "highlight_ceiling", 1.0)
    nu.safe_set_input(isolate, "Brightness", 0.02 - (ceiling * 0.01))
    nu.safe_set_input(isolate, "Contrast", 20 + q * 5 + guard * 5)
    for node, gtype, thr, size in ((core, "FOG_GLOW", 0.20, 3), (mid, "FOG_GLOW", 0.35, 5), (wide, "FOG_GLOW", 0.55, 7), (streak, "STREAKS", 0.45, 5)):
        _set_glare(node, gtype, thr, size + q, _glare_quality(settings))
    nu.safe_set_input(streak, "Streaks", 4 + q + guard)
    _set_sun_beams(rays)
    nu.safe_set_input(chroma, "Dispersion", 0.010 + 0.004 * guard)
    nu.safe_set_input(chroma, "Distort", 0.005 * guard)
    nu.safe_set_input(trim, "Brightness", -0.02 * guard)
    nu.safe_set_input(trim, "Contrast", -2 if guard else 0)
    links = 0
    links += _safe_link(tree, src, isolate)
    for node in (core, mid, wide, streak):
        links += _safe_link(tree, isolate, node)
    links += _safe_link(tree, streak, rays, ("Glare",))
    mix1, c = _mix_add(tree, src, core, "SCS Add Micro Bloom", (330, 250), frame, "SPECTRAL_LIGHT_LAB", 0.22, ("Glare",)); links += c
    mix2, c = _mix_add(tree, mix1, mid, "SCS Add Mid Bloom", (570, 250), frame, "SPECTRAL_LIGHT_LAB", 0.18, ("Glare",)); links += c
    mix3, c = _mix_add(tree, mix2, wide, "SCS Add Atmos Bloom", (810, 250), frame, "SPECTRAL_LIGHT_LAB", 0.12, ("Glare",)); links += c
    mix4, c = _mix_add(tree, mix3, rays, "SCS Add Stray-light Rays", (1050, 250), frame, "SPECTRAL_LIGHT_LAB", 0.10, ("Glare",)); links += c
    links += _safe_link(tree, mix4, chroma)
    links += _safe_link(tree, chroma, trim)
    _add_precision_note(tree, frame, "SPECTRAL_LIGHT_LAB", settings, (330, -500))
    links += _add_basic_output(tree, trim, settings, frame, "SPECTRAL_LIGHT_LAB")
    return BuildResult("SPECTRAL_LIGHT_LAB", t("スペクトル光学ラボを追加しました。", "Added Spectral Light Lab."), frame.name, getattr(trim, "name", ""), len(tree.nodes) - start, links)


def build_depth_normalizer(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "DEPTH_NORMALIZER", t("深度正規化ラボ", "Depth Normalizer"), settings)
    src = _image_source(tree, frame, "DEPTH_NORMALIZER", (-500, 120))
    map_range = nu.new_node(tree, "CompositorNodeMapRange", "SCS Near/Far Depth Map", (-210, -80), frame, "DEPTH_NORMALIZER")
    normalize = nu.new_node(tree, "CompositorNodeNormalize", "SCS Auto Depth Normalize", (-210, -260), frame, "DEPTH_NORMALIZER")
    ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Depth Falloff Curve", (80, -80), frame, "DEPTH_NORMALIZER")
    blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Depth Anti-band Smooth", (350, -80), frame, "DEPTH_NORMALIZER")
    qc = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Depth QC Heatmap", (350, -280), frame, "DEPTH_NORMALIZER")
    nu.safe_set_input(map_range, "From Min", _float_setting(settings, "depth_near", 1.0))
    nu.safe_set_input(map_range, "From Max", _float_setting(settings, "depth_far", 100.0))
    nu.safe_set_input(map_range, "To Min", 0.0)
    nu.safe_set_input(map_range, "To Max", 1.0)
    _set_blur(blur, _quality_value(settings, 0, 1, 2, 3))
    links = 0
    links += _safe_link(tree, src, map_range, ("Z", "Depth"), ("Value", "Image"))
    links += _safe_link(tree, src, normalize, ("Z", "Depth"), ("Value", "Image"))
    links += _safe_link(tree, map_range, ramp, ("Value", "Image"), ("Fac", "Value"))
    links += _safe_link(tree, ramp, blur)
    links += _safe_link(tree, normalize, qc, ("Value", "Image"), ("Fac", "Value"))
    _add_precision_note(tree, frame, "DEPTH_NORMALIZER", settings, (80, -470))
    links += _add_basic_output(tree, blur, settings, frame, "DEPTH_NORMALIZER")
    return BuildResult("DEPTH_NORMALIZER", t("深度正規化ラボを追加しました。", "Added Depth Normalizer."), frame.name, getattr(blur, "name", ""), len(tree.nodes) - start, links)


def build_color_warper_lab(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "COLOR_WARPER_LAB", t("色相ワーパーラボ", "Color Warper Lab"), settings)
    src = _image_source(tree, frame, "COLOR_WARPER_LAB", (-500, 140))
    exposure = nu.new_node(tree, "CompositorNodeExposure", "SCS Exposure Anchor", (-220, 140), frame, "COLOR_WARPER_LAB")
    balance = nu.new_node(tree, "CompositorNodeColorBalance", "SCS Lift Gamma Gain Anchor", (40, 140), frame, "COLOR_WARPER_LAB")
    hue = nu.new_node(tree, "CompositorNodeHueSat", "SCS Hue Vector Isolation", (300, 140), frame, "COLOR_WARPER_LAB")
    curve = nu.new_node(tree, "CompositorNodeCurveRGB", "SCS Tone Mesh Curve", (560, 140), frame, "COLOR_WARPER_LAB")
    tonemap = nu.new_node(tree, "CompositorNodeCurveRGB", "SCS Highlight Roll-off", (820, 140), frame, "COLOR_WARPER_LAB")
    _set_highlight_rolloff(tonemap)
    split = nu.new_node(tree, "CompositorNodeSepRGBA", "SCS Channel Inspect Split", (300, -120), frame, "COLOR_WARPER_LAB")
    guard = nu.new_node(tree, "CompositorNodeBrightContrast", "SCS Delivery Safety Trim", (1080, 140), frame, "COLOR_WARPER_LAB")
    nu.safe_set_input(exposure, "Exposure", 0.0)
    nu.safe_set_input(guard, "Brightness", -0.01 * _guard_rank(settings))
    nu.safe_set_input(guard, "Contrast", -1 * _guard_rank(settings))
    links = 0
    for a, b in ((src, exposure), (exposure, balance), (balance, hue), (hue, curve), (curve, tonemap), (tonemap, guard)):
        links += _safe_link(tree, a, b)
    links += _safe_link(tree, hue, split)
    _add_precision_note(tree, frame, "COLOR_WARPER_LAB", settings, (300, -340))
    links += _add_basic_output(tree, guard, settings, frame, "COLOR_WARPER_LAB")
    return BuildResult("COLOR_WARPER_LAB", t("色相ワーパーラボを追加しました。", "Added Color Warper Lab."), frame.name, getattr(guard, "name", ""), len(tree.nodes) - start, links)


def build_cleanroom_plus(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "CLEANROOM_PLUS", t("CleanRoom Plus", "CleanRoom Plus"), settings)
    src = _image_source(tree, frame, "CLEANROOM_PLUS", (-520, 160))
    denoise = nu.new_node(tree, "CompositorNodeDenoise", "SCS Multi-pass Denoise", (-240, 160), frame, "CLEANROOM_PLUS")
    edge = nu.new_node(tree, "CompositorNodeBilateralblur", "SCS Edge-aware Clean", (20, 160), frame, "CLEANROOM_PLUS")
    band = nu.new_node(tree, "CompositorNodeBlur", "SCS Band Gradient Smooth", (280, 160), frame, "CLEANROOM_PLUS")
    detail = nu.new_node(tree, "CompositorNodeFilter", "SCS Detail Rebuild", (540, 160), frame, "CLEANROOM_PLUS")
    mix_clean = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Clean/Original Balance", (800, 160), frame, "CLEANROOM_PLUS")
    sharpen_guard = nu.new_node(tree, "CompositorNodeFilter", "SCS Over-sharpen Guard", (800, -80), frame, "CLEANROOM_PLUS")
    final = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Restored Finish", (1060, 160), frame, "CLEANROOM_PLUS")
    _set_blur(band, _quality_value(settings, 1, 2, 4, 6) + _guard_rank(settings))
    _set_filter(detail, "SHARPEN")
    _set_filter(sharpen_guard, "SOFTEN")
    nu.safe_set_input(mix_clean, "Fac", _quality_value(settings, 0.22, 0.30, 0.38, 0.46))
    nu.safe_set_input(final, "Fac", 0.18 if _guard_rank(settings) >= 2 else 0.24)
    links = 0
    links += _safe_link(tree, src, denoise, ("Image",), ("Image",))
    links += _safe_link(tree, src, denoise, ("Normal",), ("Normal",))
    links += _safe_link(tree, src, denoise, ("DiffCol", "Diffuse Color", "Albedo"), ("Albedo",))
    links += _safe_link(tree, denoise, edge)
    links += _safe_link(tree, edge, band)
    links += _safe_link(tree, band, detail)
    links += _safe_link(tree, src, mix_clean, ("Image",), (1, "Image"))
    links += _safe_link(tree, detail, mix_clean, ("Image",), (2, "Image"))
    links += _safe_link(tree, mix_clean, sharpen_guard)
    links += _safe_link(tree, mix_clean, final, ("Image",), (1, "Image"))
    links += _safe_link(tree, sharpen_guard, final, ("Image",), (2, "Image"))
    _add_precision_note(tree, frame, "CLEANROOM_PLUS", settings, (-220, -240))
    links += _add_basic_output(tree, final, settings, frame, "CLEANROOM_PLUS")
    return BuildResult("CLEANROOM_PLUS", t("CleanRoom Plusを追加しました。", "Added CleanRoom Plus."), frame.name, getattr(final, "name", ""), len(tree.nodes) - start, links)




def build_master_workspace(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    links_before = _link_keys(nu.existing_compositor_tree(ctx))
    results = [enable_compositor(ctx), enable_render_passes(ctx)]
    results.extend(_run_workbench_stages(ctx, (
        build_aov_shuffle_matrix, build_color_grade_panel, build_advanced_glow,
        build_bokeh_depth_blur, build_depth_fog_relight, build_file_output_pipeline,
    )))
    nodes = sum(result.nodes_created for result in results)
    links = len(_link_keys(nu.existing_compositor_tree(ctx)) - links_before)
    return BuildResult("BUILD_MASTER_WORKSPACE", t("総合コンポジット作業台を追加しました。", "Added Master Composite Workspace."), nodes_created=nodes, links_created=links)





# -----------------------------------------------------------------------------
# Precision Surpass+ overrides
# -----------------------------------------------------------------------------

def _precision_mode(settings=None) -> str:
    try:
        mode = str(getattr(settings, "precision_mode", "SURPASS") or "SURPASS").upper()
    except Exception:
        mode = "SURPASS"
    if mode not in {"PREVIEW", "BALANCED", "FINAL", "EXTREME", "SURPASS"}:
        mode = "FINAL"
    return mode


def _quality_rank(settings=None) -> int:
    return {"PREVIEW": 0, "BALANCED": 1, "FINAL": 2, "EXTREME": 3, "SURPASS": 4}.get(_precision_mode(settings), 2)


def _quality_value(settings=None, preview=0, balanced=1, final=2, extreme=3, surpass=None):
    values = (preview, balanced, final, extreme, extreme if surpass is None else surpass)
    return values[_quality_rank(settings)]


def _glow_rank(settings=None) -> int:
    try:
        mode = str(getattr(settings, "glow_quality", "SURPASS") or "SURPASS").upper()
    except Exception:
        mode = "SURPASS"
    return {"PREVIEW": 0, "BALANCED": 1, "FINAL": 2, "EXTREME": 3, "SURPASS": 4}.get(mode, 2)


def _diagnostic_enabled(settings=None) -> bool:
    try:
        return bool(getattr(settings, "create_diagnostic_viewers", True))
    except Exception:
        return True


def _guard_strength(settings=None) -> float:
    try:
        value = float(getattr(settings, "artifact_guard_strength", 0.78) or 0.78)
    except Exception:
        value = 0.78
    return max(0.0, min(1.0, value))


def _edge_protection(settings=None) -> float:
    try:
        value = float(getattr(settings, "edge_protection", 0.72) or 0.72)
    except Exception:
        value = 0.72
    return max(0.0, min(1.0, value))


def _diagnostic_viewer(tree, source, label: str, location, frame=None, preset_id: str = "", settings=None, out_names=("Image", "Value", "Alpha")) -> int:
    if not _diagnostic_enabled(settings):
        return 0
    viewer = nu.new_node(tree, "CompositorNodeViewer", label, location, frame, preset_id)
    return _safe_link(tree, source, viewer, out_names, ("Image",))


def _link_file_input(tree, source, fout, output_names, input_names) -> int:
    out = nu.socket_by_names(source.outputs, output_names)
    inn = nu.socket_by_names(fout.inputs, input_names)
    if out is None or inn is None:
        return 0
    return 1 if nu.link_sockets(tree, out, inn) else 0


_FILE_SLOT_MAPPINGS = (
    (("Image",), ("Beauty", "Image")),
    (("Alpha",), ("Alpha",)),
    (("Z", "Depth"), ("Z", "Depth")),
    (("Mist",), ("Mist",)),
    (("Normal",), ("Normal",)),
    (("Vector",), ("Vector",)),
    (("Position",), ("Position",)),
    (("AO", "Ambient Occlusion"), ("AO", "Ambient_Occlusion")),
    (("Shadow",), ("Shadow",)),
    (("Diffuse Direct",), ("Diffuse_Direct",)),
    (("Diffuse Indirect",), ("Diffuse_Indirect",)),
    (("Diffuse Color", "DiffCol"), ("Diffuse_Color",)),
    (("Glossy Direct",), ("Glossy_Direct",)),
    (("Glossy Indirect",), ("Glossy_Indirect",)),
    (("Glossy Color",), ("Glossy_Color",)),
    (("Emit", "Emission"), ("Emission", "Emit")),
    (("Environment",), ("Environment",)),
    (("SCS_UtilityMask",), ("UtilityMask",)),
    (("SCS_RelightMask",), ("RelightMask",)),
    (("SCS_BeautyMask",), ("BeautyMask",)),
)


_CRYPTO_LAYER_PREFIXES = ("CryptoObject", "CryptoMaterial", "CryptoAsset")


def _extra_file_slots(rlayers, used: set[str]) -> list[tuple[str, str]]:
    """Enabled outputs outside the table (the user's own AOVs, Cycles-only passes) as (output name, slot name)."""
    mapped = {socket.name for socket in (nu.socket_by_names(rlayers.outputs, names) for names, _inputs in _FILE_SLOT_MAPPINGS) if socket is not None}
    extras = []
    for output in rlayers.outputs:
        if output.name in mapped or not getattr(output, "enabled", True) or output.name.startswith(_CRYPTO_LAYER_PREFIXES):
            continue
        base = slot = re.sub(r"\W+", "_", output.name).strip("_") or "Pass"
        number = 2
        while slot in used:
            slot = f"{base}_{number}"
            number += 1
        used.add(slot)
        extras.append((output.name, slot))
    return extras


def _available_file_slots(rlayers) -> list[str]:
    """Every pass this render really has gets a slot, and no slot stays empty."""
    slots = []
    for output_names, input_names in _FILE_SLOT_MAPPINGS:
        socket = nu.socket_by_names(rlayers.outputs, output_names)
        if socket is not None and getattr(socket, "enabled", True):
            slots.append(input_names[0])
    used = {names[0] for _outputs, names in _FILE_SLOT_MAPPINGS}
    slots.extend(slot for _name, slot in _extra_file_slots(rlayers, used))
    return slots


def _file_outputs_enabled(settings=None) -> bool:
    return bool(getattr(settings, "create_file_outputs", True)) if settings is not None else True


def _file_outputs_off_result(preset_id: str) -> BuildResult:
    return BuildResult(preset_id, t("「ファイル出力を作成」がオフなので、追加しませんでした。", "Nothing was added because Create File Output is off."))


def _connect_file_slots_from_render_layers(tree, rlayers, fout, include_qc=None) -> int:
    count = 0
    for output_names, input_names in _FILE_SLOT_MAPPINGS:
        count += _link_file_input(tree, rlayers, fout, output_names, input_names)
    used = {names[0] for _outputs, names in _FILE_SLOT_MAPPINGS}
    for output_name, slot in _extra_file_slots(rlayers, used):
        count += _link_file_input(tree, rlayers, fout, (output_name,), (slot,))
    # Cryptomatte comes as numbered layers (CryptoObject00, 01, 02...), each needs its own slot.
    for prefix in _CRYPTO_LAYER_PREFIXES:
        layers = [output for output in rlayers.outputs if output.name.startswith(prefix)]
        for item in fout.file_output_items:
            if layers and item.name == prefix:
                nu.safe_set(item, "name", layers[0].name)
                break
        for output in layers:
            if nu.socket_by_names(fout.inputs, (output.name,)) is None:
                nu.add_file_output_slot(fout, output.name)
            count += _link_file_input(tree, rlayers, fout, (output.name,), (output.name,))
    if include_qc:
        for node, names in include_qc:
            count += _link_file_input(tree, node, (fout), ("Image", "Value", "Alpha"), names)
    return count


_PRECISION_MODE_LABELS_JA = {"PREVIEW": "プレビュー", "BALANCED": "バランス", "FINAL": "最終", "EXTREME": "極限", "SURPASS": "凌駕"}


def _add_precision_note(tree, frame, preset_id: str, settings=None, location=(0, -320)):
    mode = _precision_mode(settings)
    return nu.add_note(
        tree,
        t(
            f"SCS 精度強化：現在の精度モードは{_PRECISION_MODE_LABELS_JA.get(mode, mode)}です。AOV診断、エッジ保護、白飛びガード、多段ミックスバック、外部ブリッジ受け取りを追加し、Blender標準ノード内で破綻を抑える構成にしています。",
            f"SCS PrecisionCore+: current precision mode is {mode}. The stack adds AOV diagnostics, edge protection, highlight guards, multi-stage mix-back, and external bridge intake to reduce artifacts within Blender-native nodes.",
        ),
        location,
        frame,
        preset_id,
    )


def build_aov_shuffle_matrix(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "AOV_SHUFFLE_MATRIX", t("AOVシャッフル・マトリクス", "AOV Shuffle Matrix"), settings)
    rl = _image_source(tree, frame, "AOV_SHUFFLE_MATRIX")
    x0, y0 = 0, 220
    lanes = [
        ("Image", "SCS Beauty / Image", 0), ("Alpha", "SCS Alpha Matte", -90),
        ("Z", "SCS Z Depth", -180), ("Mist", "SCS Mist", -270),
        ("Normal", "SCS Normal", -360), ("Vector", "SCS Motion Vector", -450),
        ("Position", "SCS Position", -540), ("AO", "SCS Ambient Occlusion", -630), ("Shadow", "SCS Shadow", -720),
        ("Diffuse Direct", "SCS Diffuse Direct", -810), ("Diffuse Indirect", "SCS Diffuse Indirect", -900), ("Diffuse Color", "SCS Diffuse Color", -990),
        ("Glossy Direct", "SCS Glossy Direct", -1080), ("Glossy Indirect", "SCS Glossy Indirect", -1170), ("Glossy Color", "SCS Glossy Color", -1260),
        ("Emit", "SCS Emission", -1350), ("Environment", "SCS Environment", -1440),
        ("CryptoObject00", "SCS Crypto Object", -1530), ("CryptoMaterial00", "SCS Crypto Material", -1620), ("CryptoAsset00", "SCS Crypto Asset", -1710),
    ]
    links = 0
    for socket_name, label, dy in lanes:
        r = nu.new_node(tree, "NodeReroute", label, (x0, y0 + dy), frame, "AOV_SHUFFLE_MATRIX")
        links += _safe_link(tree, rl, r, (socket_name, "Depth" if socket_name == "Z" else socket_name), ("Input",))
    sep = nu.new_node(tree, "CompositorNodeSepRGBA", "SCS RGBA Precision Split", (x0 + 240, y0 + 20), frame, "AOV_SHUFFLE_MATRIX")
    comb = nu.new_node(tree, "CompositorNodeCombRGBA", "SCS RGBA Precision Combine", (x0 + 520, y0 + 20), frame, "AOV_SHUFFLE_MATRIX")
    alpha_ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Alpha Edge QC", (x0 + 520, y0 - 140), frame, "AOV_SHUFFLE_MATRIX")
    z_norm = nu.new_node(tree, "CompositorNodeNormalize", "SCS Depth Normalize QC", (x0 + 240, y0 - 320), frame, "AOV_SHUFFLE_MATRIX")
    z_ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Depth Range QC", (x0 + 520, y0 - 320), frame, "AOV_SHUFFLE_MATRIX")
    mist_ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Mist Range QC", (x0 + 520, y0 - 500), frame, "AOV_SHUFFLE_MATRIX")
    normal_curve = nu.new_node(tree, "CompositorNodeCurveRGB", "SCS Normal Vector QC", (x0 + 520, y0 - 680), frame, "AOV_SHUFFLE_MATRIX")
    vector_curve = nu.new_node(tree, "CompositorNodeCurveRGB", "SCS Motion Vector QC", (x0 + 520, y0 - 860), frame, "AOV_SHUFFLE_MATRIX")
    links += _safe_link(tree, rl, sep)
    for channel in ("R", "G", "B", "A"):
        links += int(nu.link_sockets(tree, nu.socket_by_names(sep.outputs, (channel,)), nu.socket_by_names(comb.inputs, (channel,))))
    links += _safe_link(tree, rl, alpha_ramp, ("Alpha",), ("Fac", "Value"))
    links += _safe_link(tree, rl, z_norm, ("Z", "Depth"), ("Value", "Image"))
    links += _safe_link(tree, z_norm, z_ramp, ("Value", "Image"), ("Fac", "Value"))
    links += _safe_link(tree, rl, mist_ramp, ("Mist",), ("Fac", "Value"))
    links += _safe_link(tree, rl, normal_curve, ("Normal",), ("Image",))
    links += _safe_link(tree, rl, vector_curve, ("Vector",), ("Image",))
    links += _diagnostic_viewer(tree, comb, "SCS Beauty QC Viewer", (x0 + 800, y0 + 160), frame, "AOV_SHUFFLE_MATRIX", settings)
    links += _diagnostic_viewer(tree, alpha_ramp, "SCS Alpha QC Viewer", (x0 + 800, y0 - 20), frame, "AOV_SHUFFLE_MATRIX", settings)
    links += _diagnostic_viewer(tree, z_ramp, "SCS Depth QC Viewer", (x0 + 800, y0 - 200), frame, "AOV_SHUFFLE_MATRIX", settings)
    links += _diagnostic_viewer(tree, normal_curve, "SCS Normal QC Viewer", (x0 + 800, y0 - 380), frame, "AOV_SHUFFLE_MATRIX", settings)
    if bool(getattr(settings, "create_file_outputs", True)):
        slots = (*_available_file_slots(rl), "Depth_QC", "Alpha_QC", "Normal_QC", "Vector_QC")
        fout = nu.add_file_output(tree, "SCS 32-bit EXR / AOV Precision Output", _base_path(settings), slots, (x0 + 1080, y0 - 260), frame, "AOV_SHUFFLE_MATRIX")
        _set_file_format(fout)
        links += _connect_file_slots_from_render_layers(tree, rl, fout)
        links += _link_file_input(tree, z_ramp, fout, ("Image", "Value"), ("Depth_QC",))
        links += _link_file_input(tree, alpha_ramp, fout, ("Image", "Value"), ("Alpha_QC",))
        links += _link_file_input(tree, normal_curve, fout, ("Image",), ("Normal_QC",))
        links += _link_file_input(tree, vector_curve, fout, ("Image",), ("Vector_QC",))
    _add_precision_note(tree, frame, "AOV_SHUFFLE_MATRIX", settings, (x0 + 180, y0 - 1920))
    links += _add_basic_output(tree, comb, settings, frame, "AOV_SHUFFLE_MATRIX")
    return BuildResult("AOV_SHUFFLE_MATRIX", t("AOV診断と多パス結線を強化したAOVシャッフル・マトリクスを追加しました。", "Added AOV Shuffle Matrix with stronger diagnostics and multi-pass wiring."), frame.name, getattr(comb, "name", ""), len(tree.nodes) - start, links)


def build_file_output_pipeline(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    if not _file_outputs_enabled(settings):
        return _file_outputs_off_result("FILE_OUTPUT_PIPELINE")
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "FILE_OUTPUT_PIPELINE", t("マルチパス出力", "Multi-pass File Output"), settings)
    rl = _image_source(tree, frame, "FILE_OUTPUT_PIPELINE")
    slots = _available_file_slots(rl)
    fout = nu.add_file_output(tree, "SCS 32-bit EXR / AOV Output Hub", _base_path(settings), slots, (120, 100), frame, "FILE_OUTPUT_PIPELINE")
    _set_file_format(fout)
    links = _connect_file_slots_from_render_layers(tree, rl, fout)
    _add_precision_note(tree, frame, "FILE_OUTPUT_PIPELINE", settings, (120, -300))
    return BuildResult("FILE_OUTPUT_PIPELINE", t("AOV個別スロット結線付きマルチパス出力ハブを追加しました。", "Added multi-pass output hub with per-AOV slot wiring."), frame.name, getattr(fout, "name", ""), len(tree.nodes) - start, links)


def build_matte_refiner(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "MATTE_REFINER", t("マット調整", "Matte Refiner"), settings)
    source = _image_source(tree, frame, "MATTE_REFINER")
    luma = nu.new_node(tree, "CompositorNodeRGBToBW", "SCS Matte Source Luma", (-180, 150), frame, "MATTE_REFINER")
    edge_smooth = nu.new_node(tree, "CompositorNodeBilateralblur", "SCS Edge-aware Matte Smooth", (40, 150), frame, "MATTE_REFINER")
    preblur = nu.new_node(tree, "CompositorNodeBlur", "SCS Subpixel Pre-smooth", (280, 150), frame, "MATTE_REFINER")
    density = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Matte Density Curve", (520, 150), frame, "MATTE_REFINER")
    choke = nu.new_node(tree, "CompositorNodeDilateErode", "SCS Core Choke", (760, 220), frame, "MATTE_REFINER")
    expand = nu.new_node(tree, "CompositorNodeDilateErode", "SCS Fringe Expand", (760, 70), frame, "MATTE_REFINER")
    edge = nu.new_node(tree, "CompositorNodeFilter", "SCS Matte Edge Detector", (760, -90), frame, "MATTE_REFINER")
    edge_blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Edge Halo Softener", (1000, -90), frame, "MATTE_REFINER")
    blend = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Core/Fringe Protected Blend", (1030, 150), frame, "MATTE_REFINER")
    feather = nu.new_node(tree, "CompositorNodeBlur", "SCS Precision Feather", (1290, 150), frame, "MATTE_REFINER")
    final_curve = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Final Matte Clamp", (1530, 150), frame, "MATTE_REFINER")
    setalpha = nu.new_node(tree, "CompositorNodeSetAlpha", "SCS Apply Refined Alpha", (1780, 150), frame, "MATTE_REFINER")
    _set_blur(preblur, _quality_value(settings, 0, 1, 1, 2, 3))
    _set_blur(edge_blur, _quality_value(settings, 1, 2, 3, 5, 7))
    _set_blur(feather, _quality_value(settings, 2, 3, 5, 7, 10))
    nu.safe_set(choke, "distance", -_quality_value(settings, 1, 1, 2, 3, 4))
    nu.safe_set(expand, "distance", _quality_value(settings, 1, 1, 2, 3, 4))
    _set_filter(edge, "SOBEL")
    nu.safe_set_input(blend, "Fac", _edge_protection(settings))
    links = 0
    links += _safe_link(tree, source, luma)
    links += _safe_link(tree, luma, edge_smooth, ("Val", "Image", "Value"), ("Image",))
    links += _safe_link(tree, edge_smooth, preblur)
    links += _safe_link(tree, preblur, density, ("Image",), ("Fac", "Value"))
    links += _safe_link(tree, density, choke)
    links += _safe_link(tree, density, expand)
    links += _safe_link(tree, density, edge)
    links += _safe_link(tree, edge, edge_blur)
    links += _safe_link(tree, choke, blend, ("Image",), (1, "Image"))
    links += _safe_link(tree, expand, blend, ("Image",), (2, "Image"))
    links += _safe_link(tree, blend, feather)
    links += _safe_link(tree, feather, final_curve, ("Image",), ("Fac", "Value"))
    links += _safe_link(tree, source, setalpha, ("Image",), ("Image",))
    links += _safe_link(tree, final_curve, setalpha, ("Image", "Alpha", "Value"), ("Alpha", "Fac"))
    links += _diagnostic_viewer(tree, final_curve, "SCS Matte QC Viewer", (1780, -70), frame, "MATTE_REFINER", settings)
    _add_precision_note(tree, frame, "MATTE_REFINER", settings, (40, -300))
    links += _add_basic_output(tree, setalpha, settings, frame, "MATTE_REFINER")
    return BuildResult("MATTE_REFINER", t("エッジ保護と多段フェザーを強化したマット調整スタックを追加しました。", "Added Matte Refiner with stronger edge protection and multi-stage feathering."), frame.name, getattr(setalpha, "name", ""), len(tree.nodes) - start, links)


def build_chroma_key_studio(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "CHROMA_KEY_STUDIO", t("クロマキー・スタジオ", "Chroma Key Studio"), settings)
    plate = nu.new_node(tree, "CompositorNodeImage", "SCS Screen Plate", (-500, 170), frame, "CHROMA_KEY_STUDIO")
    garbage = nu.new_node(tree, "CompositorNodeImage", "SCS Optional Garbage / Holdout Mask", (-500, -110), frame, "CHROMA_KEY_STUDIO")
    key = nu.new_node(tree, "CompositorNodeKeying", "SCS Precision Screen Key", (-200, 170), frame, "CHROMA_KEY_STUDIO")
    despill = nu.new_node(tree, "CompositorNodeColorSpill", "SCS Spill Suppression", (70, 170), frame, "CHROMA_KEY_STUDIO")
    density = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Matte Density Curve", (70, -40), frame, "CHROMA_KEY_STUDIO")
    choke = nu.new_node(tree, "CompositorNodeDilateErode", "SCS Edge Choke", (320, -40), frame, "CHROMA_KEY_STUDIO")
    expand = nu.new_node(tree, "CompositorNodeDilateErode", "SCS Fringe Expand", (320, -210), frame, "CHROMA_KEY_STUDIO")
    blend = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Key Core/Fringe Blend", (570, -40), frame, "CHROMA_KEY_STUDIO")
    feather = nu.new_node(tree, "CompositorNodeBlur", "SCS Edge Feather", (820, -40), frame, "CHROMA_KEY_STUDIO")
    setalpha = nu.new_node(tree, "CompositorNodeSetAlpha", "SCS Final Keyed Plate", (1080, 170), frame, "CHROMA_KEY_STUDIO")
    _set_blur(feather, _quality_value(settings, 2, 3, 5, 7, 10))
    nu.safe_set(choke, "distance", -_quality_value(settings, 1, 1, 2, 3, 4))
    nu.safe_set(expand, "distance", _quality_value(settings, 1, 1, 2, 2, 3))
    nu.safe_set_input(blend, "Fac", _edge_protection(settings))
    links = 0
    links += _safe_link(tree, plate, key)
    links += _safe_link(tree, key, despill, ("Image",), ("Image",))
    links += _safe_link(tree, key, density, ("Matte", "Alpha", "Image"), ("Fac", "Value"))
    links += _safe_link(tree, density, choke)
    links += _safe_link(tree, density, expand)
    links += _safe_link(tree, choke, blend, ("Image",), (1, "Image"))
    links += _safe_link(tree, expand, blend, ("Image",), (2, "Image"))
    links += _safe_link(tree, blend, feather)
    links += _safe_link(tree, despill, setalpha, ("Image",), ("Image",))
    links += _safe_link(tree, feather, setalpha, ("Image",), ("Alpha", "Fac"))
    links += _diagnostic_viewer(tree, feather, "SCS Key Matte QC Viewer", (1080, -70), frame, "CHROMA_KEY_STUDIO", settings)
    _add_precision_note(tree, frame, "CHROMA_KEY_STUDIO", settings, (-180, -360))
    links += _add_basic_output(tree, setalpha, settings, frame, "CHROMA_KEY_STUDIO")
    return BuildResult("CHROMA_KEY_STUDIO", t("スピル抑制と輪郭保護を強化したクロマキー・スタジオを追加しました。", "Added Chroma Key Studio with stronger spill suppression and edge protection."), frame.name, getattr(setalpha, "name", ""), len(tree.nodes) - start, links)


def build_ai_mask_bridge(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "AI_MASK_BRIDGE", t("AIマスク・ブリッジ", "AI Mask Bridge"), settings)
    plate = _image_source(tree, frame, "AI_MASK_BRIDGE", (-520, 180))
    mask = nu.new_node(tree, "CompositorNodeImage", "SCS External Alpha / Object Mask", (-520, -40), frame, "AI_MASK_BRIDGE")
    depth = nu.new_node(tree, "CompositorNodeImage", "SCS External Depth Map", (-520, -250), frame, "AI_MASK_BRIDGE")
    clean = nu.new_node(tree, "CompositorNodeImage", "SCS External Clean Plate", (-520, -460), frame, "AI_MASK_BRIDGE")
    bw = nu.new_node(tree, "CompositorNodeRGBToBW", "SCS Mask Luma Convert", (-240, -40), frame, "AI_MASK_BRIDGE")
    normalize = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Mask Normalize / Clamp", (0, -40), frame, "AI_MASK_BRIDGE")
    edge = nu.new_node(tree, "CompositorNodeDilateErode", "SCS Mask Edge Guard", (250, -40), frame, "AI_MASK_BRIDGE")
    feather = nu.new_node(tree, "CompositorNodeBlur", "SCS Mask Feather", (500, -40), frame, "AI_MASK_BRIDGE")
    setalpha = nu.new_node(tree, "CompositorNodeSetAlpha", "SCS Apply External Matte", (780, 160), frame, "AI_MASK_BRIDGE")
    diff = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Clean Plate Difference QC", (-240, -430), frame, "AI_MASK_BRIDGE")
    depth_norm = nu.new_node(tree, "CompositorNodeNormalize", "SCS External Depth Normalize QC", (-240, -250), frame, "AI_MASK_BRIDGE")
    _set_blur(feather, _quality_value(settings, 2, 3, 5, 8, 11))
    nu.safe_set(edge, "distance", _quality_value(settings, 0, 0, 1, 1, 2))
    nu.set_mix_mode(diff, "SUBTRACT")
    nu.safe_set_input(diff, "Fac", 1.0)
    links = 0
    links += _safe_link(tree, mask, bw)
    links += _safe_link(tree, bw, normalize, ("Val", "Image", "Value"), ("Fac", "Value"))
    links += _safe_link(tree, normalize, edge)
    links += _safe_link(tree, edge, feather)
    links += _safe_link(tree, plate, setalpha, ("Image",), ("Image",))
    links += _safe_link(tree, feather, setalpha, ("Image",), ("Alpha",))
    links += _safe_link(tree, plate, diff, ("Image",), (1, "Image"))
    links += _safe_link(tree, clean, diff, ("Image",), (2, "Image"))
    links += _safe_link(tree, depth, depth_norm)
    links += _diagnostic_viewer(tree, feather, "SCS External Mask QC Viewer", (780, -90), frame, "AI_MASK_BRIDGE", settings)
    links += _diagnostic_viewer(tree, depth_norm, "SCS External Depth QC Viewer", (60, -250), frame, "AI_MASK_BRIDGE", settings)
    links += _diagnostic_viewer(tree, diff, "SCS Clean Plate Difference Viewer", (60, -430), frame, "AI_MASK_BRIDGE", settings)
    _add_precision_note(tree, frame, "AI_MASK_BRIDGE", settings, (-500, -650))
    links += _add_basic_output(tree, setalpha, settings, frame, "AI_MASK_BRIDGE")
    return BuildResult("AI_MASK_BRIDGE", t("外部AIマスク、深度、クリーンプレートの品質確認を強化したブリッジを追加しました。", "Added AI bridge with stronger external mask, depth, and clean-plate QC."), frame.name, getattr(setalpha, "name", ""), len(tree.nodes) - start, links)


def build_advanced_glow(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "ADVANCED_GLOW", t("高品質グロー", "Advanced Glow"), settings)
    src = _image_source(tree, frame, "ADVANCED_GLOW")
    isolate = nu.new_node(tree, "CompositorNodeBrightContrast", "SCS Highlight Isolation", (-170, 190), frame, "ADVANCED_GLOW")
    core = nu.new_node(tree, "CompositorNodeGlare", "SCS Core Bloom", (110, 280), frame, "ADVANCED_GLOW")
    mid = nu.new_node(tree, "CompositorNodeGlare", "SCS Mid Bloom", (110, 100), frame, "ADVANCED_GLOW")
    wide = nu.new_node(tree, "CompositorNodeGlare", "SCS Wide Diffusion", (110, -80), frame, "ADVANCED_GLOW")
    streak = nu.new_node(tree, "CompositorNodeGlare", "SCS Spectral Streaks", (110, -260), frame, "ADVANCED_GLOW")
    edge = nu.new_node(tree, "CompositorNodeFilter", "SCS Edge Energy", (110, -440), frame, "ADVANCED_GLOW")
    edge_glow = nu.new_node(tree, "CompositorNodeGlare", "SCS Edge Bloom", (390, -440), frame, "ADVANCED_GLOW")
    nu.safe_set_input(isolate, "Contrast", _quality_value(settings, 10, 16, 22, 30, 38))
    nu.safe_set_input(isolate, "Brightness", 0.04)
    size_bonus = _quality_value(settings, 0.0, 0.03, 0.06, 0.08, 0.10)
    for node, gtype, thr, size in ((core, "FOG_GLOW", 0.40, 0.30), (mid, "FOG_GLOW", 0.50, 0.50), (wide, "FOG_GLOW", 0.60, 0.70), (streak, "STREAKS", 0.54, 0.50), (edge_glow, "FOG_GLOW", 0.30, 0.15)):
        _configure_glare(node, gtype, thr, size + size_bonus, _glare_quality(settings))
    nu.safe_set_input(streak, "Streaks", _quality_value(settings, 4, 4, 6, 8, 8))
    _set_filter(edge, "SOBEL")
    links = 0
    links += _safe_link(tree, src, isolate)
    for node in (core, mid, wide, streak):
        links += _safe_link(tree, isolate, node)
    links += _safe_link(tree, isolate, edge)
    links += _safe_link(tree, edge, edge_glow)
    mix1, c = _mix_add(tree, src, core, "SCS Add Core Bloom", (410, 270), frame, "ADVANCED_GLOW", 0.80, ("Glare",)); links += c
    mix2, c = _mix_add(tree, mix1, mid, "SCS Add Mid Bloom", (660, 270), frame, "ADVANCED_GLOW", 0.80, ("Glare",)); links += c
    mix3, c = _mix_add(tree, mix2, wide, "SCS Add Wide Diffusion", (910, 270), frame, "ADVANCED_GLOW", 0.80, ("Glare",)); links += c
    mix4, c = _mix_add(tree, mix3, streak, "SCS Add Spectral Streaks", (1160, 270), frame, "ADVANCED_GLOW", 0.12, ("Glare",)); links += c
    mix5, c = _mix_add(tree, mix4, edge_glow, "SCS Add Edge Bloom", (1410, 270), frame, "ADVANCED_GLOW", 0.10, ("Glare",)); links += c
    color = nu.new_node(tree, "CompositorNodeHueSat", "SCS Glow Color Bias", (1660, 270), frame, "ADVANCED_GLOW")
    safety = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Highlight Guard Mix", (1910, 270), frame, "ADVANCED_GLOW")
    nu.set_mix_mode(safety, "MIX")
    nu.safe_set_input(safety, "Fac", 1.0 - (0.32 * _guard_strength(settings)))
    links += _safe_link(tree, mix5, color)
    links += _safe_link(tree, src, safety, ("Image",), (1, "Image"))
    links += _safe_link(tree, color, safety, ("Image",), (2, "Image"))
    links += _diagnostic_viewer(tree, isolate, "SCS Glow Isolation QC Viewer", (410, 520), frame, "ADVANCED_GLOW", settings)
    _add_precision_note(tree, frame, "ADVANCED_GLOW", settings, (-150, -640))
    links += _add_basic_output(tree, safety, settings, frame, "ADVANCED_GLOW")
    return BuildResult("ADVANCED_GLOW", t("白飛び保護と多層光学レーンを強化したグローを追加しました。", "Added glow with stronger highlight guard and multi-layer optical lanes."), frame.name, getattr(safety, "name", ""), len(tree.nodes) - start, links)


def build_lens_flare_builder(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "LENS_FLARE_BUILDER", t("レンズフレア・ビルダー", "Lens Flare Builder"), settings)
    src = _image_source(tree, frame, "LENS_FLARE_BUILDER")
    flare_map = nu.new_node(tree, "CompositorNodeImage", "SCS Optional Flare Map / Light Matte", (-420, -120), frame, "LENS_FLARE_BUILDER")
    isolate = nu.new_node(tree, "CompositorNodeBrightContrast", "SCS Light Source Isolation", (-120, 180), frame, "LENS_FLARE_BUILDER")
    iris = nu.new_node(tree, "CompositorNodeGlare", "SCS Iris Streak Layer", (160, 300), frame, "LENS_FLARE_BUILDER")
    ghosts = nu.new_node(tree, "CompositorNodeGlare", "SCS Internal Ghost Layer", (160, 100), frame, "LENS_FLARE_BUILDER")
    beams = nu.new_node(tree, "CompositorNodeSunBeams", "SCS Stray Light Beams", (160, -100), frame, "LENS_FLARE_BUILDER")
    ring_blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Ghost/Ring Softness", (430, 100), frame, "LENS_FLARE_BUILDER")
    chroma = nu.new_node(tree, "CompositorNodeLensdist", "SCS Chromatic Dispersion", (710, 120), frame, "LENS_FLARE_BUILDER")
    tint = nu.new_node(tree, "CompositorNodeHueSat", "SCS Coating Color Bias", (960, 120), frame, "LENS_FLARE_BUILDER")
    safety = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Flare Guard Mix", (1450, 160), frame, "LENS_FLARE_BUILDER")
    nu.safe_set_input(isolate, "Contrast", _quality_value(settings, 14, 20, 28, 36, 44))
    nu.safe_set_input(isolate, "Brightness", 0.04)
    for node, gtype, thr in ((iris, "STREAKS", 0.48), (ghosts, "GHOSTS", 0.56)):
        _set_glare(node, gtype, thr, quality=_glare_quality(settings))
    nu.safe_set_input(iris, "Streaks", _quality_value(settings, 4, 6, 8, 8, 8))
    _set_sun_beams(beams)
    _set_blur(ring_blur, _quality_value(settings, 2, 3, 5, 7, 10))
    nu.safe_set(lens := chroma, "use_jitter", True)
    nu.safe_set_input(lens, "Dispersion", _quality_value(settings, 0.012, 0.018, 0.024, 0.032, 0.04))
    nu.set_mix_mode(safety, "ADD")
    nu.safe_set_input(safety, "Fac", 0.16 + 0.16 * (1.0 - _guard_strength(settings)))
    links = 0
    links += _safe_link(tree, src, isolate)
    links += _safe_link(tree, isolate, iris)
    links += _safe_link(tree, isolate, ghosts)
    links += _safe_link(tree, isolate, beams)
    links += _safe_link(tree, ghosts, ring_blur, ("Glare",))
    merge1, c = _mix_add(tree, iris, ring_blur, "SCS Iris/Ghost Merge", (430, 270), frame, "LENS_FLARE_BUILDER", 0.52, base_outputs=("Glare",)); links += c
    merge2, c = _mix_add(tree, merge1, beams, "SCS Beam Merge", (710, 270), frame, "LENS_FLARE_BUILDER", 0.24, ("Glare",)); links += c
    links += _safe_link(tree, merge2, chroma)
    links += _safe_link(tree, chroma, tint)
    links += _safe_link(tree, src, safety, ("Image",), (1, "Image"))
    links += _safe_link(tree, tint, safety, ("Image",), (2, "Image"))
    links += _diagnostic_viewer(tree, isolate, "SCS Flare Source QC Viewer", (430, 500), frame, "LENS_FLARE_BUILDER", settings)
    _add_precision_note(tree, frame, "LENS_FLARE_BUILDER", settings, (-120, -410))
    links += _add_basic_output(tree, safety, settings, frame, "LENS_FLARE_BUILDER")
    return BuildResult("LENS_FLARE_BUILDER", t("光源マット受け取りと白飛び保護を強化したレンズフレア・ビルダーを追加しました。", "Added Lens Flare Builder with light-matte intake and stronger highlight protection."), frame.name, getattr(safety, "name", ""), len(tree.nodes) - start, links)


def _camera_focus_distance(scene):
    """The distance the Defocus node focuses at: the camera's focus object or focus distance."""
    camera = getattr(scene, "camera", None)
    if camera is None or getattr(camera, "type", "") != "CAMERA":
        return None
    dof = camera.data.dof
    target = dof.focus_object
    if target is None:
        return max(float(dof.focus_distance), 1e-3)
    location = target.matrix_world.translation
    if target.type == "ARMATURE" and dof.focus_subtarget:
        bone = target.pose.bones.get(dof.focus_subtarget)
        if bone is not None:
            location = target.matrix_world @ bone.matrix.translation
    view_axis = camera.matrix_world.col[2].to_3d().normalized()
    return max(abs(view_axis.dot(camera.matrix_world.translation - location)), 1e-3)


def _visible_f_stop(scene, focus: float, widest_default: float) -> float:
    """F-stop that makes something twice as far as the focus visibly soft, whatever the lens and distance."""
    camera = scene.camera.data
    lens = float(camera.lens) * 0.001
    sensor = max(float(camera.sensor_width), float(camera.sensor_height)) * 0.001
    focus_m = max(focus * float(scene.unit_settings.scale_length or 1.0), lens + 1e-3)
    wanted_blur = 0.012 * sensor
    return max(0.2, min(float(widest_default), 0.5 * lens * lens / ((focus_m - lens) * wanted_blur)))


def _ensure_depth_pass(scene, rlayers) -> bool:
    """The blur reads the Depth pass, which a new scene has off. Returns True when it had to be turned on."""
    view_layer = scene.view_layers.get(str(rlayers.layer))
    if view_layer is None or view_layer.use_pass_z:
        return False
    return bool(nu.safe_set(view_layer, "use_pass_z", True))


def _apply_bokeh_focus(ctx, settings, nodes: dict) -> float | None:
    """Sets the blur from the camera focus as it is now. Returns the focus, or None without a camera."""
    defocus, z_range, falloff = nodes["SCS Aperture Defocus"], nodes["SCS Normalize Z Depth"], nodes["SCS Focus Falloff Curve"]
    f_stop = _quality_value(settings, 4.0, 3.2, 2.8, 2.2, 1.8)
    focus = _camera_focus_distance(ctx.scene)
    if focus is not None:
        f_stop = _visible_f_stop(ctx.scene, focus, f_stop)
        # The focus sits in the middle of the range: sharp there, softer towards the camera, full blur from twice the distance.
        nu.safe_set_input(z_range, "From Min", 0.0)
        nu.safe_set_input(z_range, "From Max", focus * 2.0)
        _set_color_ramp_stops(falloff, (
            (0.0, (1.0, 1.0, 1.0, 1.0)),
            (0.45, (0.0, 0.0, 0.0, 1.0)),
            (0.55, (0.0, 0.0, 0.0, 1.0)),
            (1.0, (1.0, 1.0, 1.0, 1.0)),
        ))
    else:
        nu.safe_set_input(z_range, "From Min", float(getattr(settings, "depth_near", 1.0) or 1.0))
        nu.safe_set_input(z_range, "From Max", float(getattr(settings, "depth_far", 100.0) or 100.0))
        _set_color_ramp_stops(falloff, ((0.0, (0.0, 0.0, 0.0, 1.0)), (1.0, (1.0, 1.0, 1.0, 1.0))))
    nu.safe_set(defocus, "f_stop", f_stop)
    return focus


def _bokeh_message(focus, f_stop: float, depth_turned_on: bool, updated: bool) -> str:
    if focus is not None and updated:
        message = t(f"Z深度ボケをカメラのピント {focus:.2f} m に合わせ直し、F 値 {f_stop:.2f} にしました。", f"Z-depth bokeh now follows the camera focus at {focus:.2f} m, with F-stop {f_stop:.2f}.")
    elif focus is not None:
        message = t(f"Z深度ボケを追加しました。カメラのピント {focus:.2f} m を基準に、F 値 {f_stop:.2f} にしました。", f"Added Z-depth bokeh. It is based on the camera focus at {focus:.2f} m, with F-stop {f_stop:.2f}.")
    elif updated:
        message = t("Z深度ボケを深度手前と深度奥の範囲に合わせ直しました。", "Z-depth bokeh now follows the Depth Near to Depth Far range.")
    else:
        message = t("Z深度ボケを追加しました。シーンにカメラが無いので、深度手前と深度奥の範囲でぼかします。", "Added Z-depth bokeh. The scene has no camera, so it blurs over the Depth Near to Depth Far range.")
    if depth_turned_on:
        message += t("深度パスがオフだったので有効にしました。", " The Depth pass was off, so it was turned on.")
    return message


def _bokeh_stack_on_output(tree) -> dict | None:
    """The nodes of the Z-depth bokeh that reaches the output now, by base name."""
    feeds = _output_feeds(tree)
    pending = [feeds[0][0]] if feeds else []
    seen = set()
    guard = None
    while pending and guard is None:
        for link in pending.pop().links:
            node = link.from_node
            if node.name in seen:
                continue
            seen.add(node.name)
            if node.name.split(".")[0] == "SCS Bokeh Highlight Guard":
                guard = node
                break
            pending.extend(node.inputs)
    if guard is None or guard.parent is None:
        return None
    nodes = {node.name.split(".")[0]: node for node in tree.nodes if node.parent == guard.parent}
    wanted = ("SCS Render Layers", "SCS Aperture Defocus", "SCS Normalize Z Depth", "SCS Focus Falloff Curve")
    return nodes if all(name in nodes for name in wanted) else None


def build_bokeh_depth_blur(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    existing = _bokeh_stack_on_output(tree)
    if existing is not None:
        # Pressing again re-aims the blur already in the chain, so two blurs never stack up.
        src = existing["SCS Render Layers"]
        depth_turned_on = _ensure_depth_pass(ctx.scene, src)
        links = _safe_link(tree, src, existing["SCS Normalize Z Depth"], ("Z", "Depth"), ("Value",))
        links += _safe_link(tree, src, existing["SCS Aperture Defocus"], ("Z", "Depth"), ("Z",))
        focus = _apply_bokeh_focus(ctx, settings, existing)
        return BuildResult("BOKEH_DEPTH_BLUR", _bokeh_message(focus, existing["SCS Aperture Defocus"].f_stop, depth_turned_on, True), "", "", 0, links)
    frame = _frame(tree, "BOKEH_DEPTH_BLUR", t("Z深度ボケ", "Z-Depth Bokeh Blur"), settings)
    src = _image_source(tree, frame, "BOKEH_DEPTH_BLUR")
    depth_turned_on = _ensure_depth_pass(ctx.scene, src)
    aperture = nu.new_node(tree, "CompositorNodeImage", "SCS Optional Aperture Shape", (-160, -330), frame, "BOKEH_DEPTH_BLUR")
    z_range = nu.new_node(tree, "CompositorNodeMapRange", "SCS Normalize Z Depth", (-130, -110), frame, "BOKEH_DEPTH_BLUR")
    falloff = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Focus Falloff Curve", (130, -110), frame, "BOKEH_DEPTH_BLUR")
    z_smooth = nu.new_node(tree, "CompositorNodeBlur", "SCS Depth Matte Smooth", (390, -110), frame, "BOKEH_DEPTH_BLUR")
    defocus = nu.new_node(tree, "CompositorNodeDefocus", "SCS Aperture Defocus", (140, 150), frame, "BOKEH_DEPTH_BLUR")
    lens = nu.new_node(tree, "CompositorNodeLensdist", "SCS Bokeh Chromatic Edge", (420, 150), frame, "BOKEH_DEPTH_BLUR")
    matte_mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Depth-gated Blur Mix", (680, 150), frame, "BOKEH_DEPTH_BLUR")
    highlights = nu.new_node(tree, "CompositorNodeGlare", "SCS Highlight Bokeh Energy", (680, 360), frame, "BOKEH_DEPTH_BLUR")
    guard = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Bokeh Highlight Guard", (950, 180), frame, "BOKEH_DEPTH_BLUR")
    nu.safe_set(defocus, "use_zbuffer", True)
    focus = _apply_bokeh_focus(ctx, settings, {"SCS Aperture Defocus": defocus, "SCS Normalize Z Depth": z_range, "SCS Focus Falloff Curve": falloff})
    nu.safe_set(defocus, "blur_max", _quality_value(settings, 24, 32, 48, 64, 80))
    _set_blur(z_smooth, _quality_value(settings, 0, 1, 2, 3, 5))
    nu.safe_set_input(lens, "Dispersion", _quality_value(settings, 0.004, 0.008, 0.012, 0.016, 0.022))
    _set_glare(highlights, "FOG_GLOW", 0.82, quality=_glare_quality(settings))
    nu.set_mix_mode(guard, "ADD")
    nu.safe_set_input(guard, "Fac", 0.12 + 0.08 * (1.0 - _guard_strength(settings)))
    links = 0
    links += _safe_link(tree, src, z_range, ("Z", "Depth"), ("Value",))
    links += _safe_link(tree, z_range, falloff, ("Value",), ("Fac", "Value"))
    links += _safe_link(tree, falloff, z_smooth)
    links += _safe_link(tree, src, defocus, ("Image",), ("Image",))
    links += _safe_link(tree, src, defocus, ("Z", "Depth"), ("Z",))
    links += _safe_link(tree, defocus, lens)
    links += _safe_link(tree, src, matte_mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, lens, matte_mix, ("Image",), (2, "Image"))
    links += _safe_link(tree, z_smooth, matte_mix, ("Image", "Value"), ("Fac",))
    links += _safe_link(tree, lens, highlights)
    links += _safe_link(tree, matte_mix, guard, ("Image",), (1, "Image"))
    links += _safe_link(tree, highlights, guard, ("Glare",), (2, "Image"))
    links += _diagnostic_viewer(tree, z_smooth, "SCS Depth Blur Matte QC Viewer", (680, -120), frame, "BOKEH_DEPTH_BLUR", settings)
    _add_precision_note(tree, frame, "BOKEH_DEPTH_BLUR", settings, (-90, -470))
    links += _add_basic_output(tree, guard, settings, frame, "BOKEH_DEPTH_BLUR")
    return BuildResult("BOKEH_DEPTH_BLUR", _bokeh_message(focus, defocus.f_stop, depth_turned_on, False), frame.name, getattr(guard, "name", ""), len(tree.nodes) - start, links)


def build_deband_denoise_restore(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "DEBAND_DENOISE_RESTORE", t("デバンド/デノイズ復元", "Deband / Denoise Restore"), settings)
    src = _image_source(tree, frame, "DEBAND_DENOISE_RESTORE")
    denoise = nu.new_node(tree, "CompositorNodeDenoise", "SCS Denoise With Pass Inputs", (-160, 180), frame, "DEBAND_DENOISE_RESTORE")
    edge_smooth = nu.new_node(tree, "CompositorNodeBilateralblur", "SCS Edge-aware Low-pass", (110, 180), frame, "DEBAND_DENOISE_RESTORE")
    band_smooth = nu.new_node(tree, "CompositorNodeBlur", "SCS Band Smoothing", (380, 180), frame, "DEBAND_DENOISE_RESTORE")
    detail_blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Low Frequency Reference", (110, -80), frame, "DEBAND_DENOISE_RESTORE")
    highpass = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Detail Difference", (380, -80), frame, "DEBAND_DENOISE_RESTORE")
    detail_mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Micro Detail Reinjection", (650, 180), frame, "DEBAND_DENOISE_RESTORE")
    grain = nu.new_node(tree, "CompositorNodeTexture", "SCS Fine Dither Driver", (650, -90), frame, "DEBAND_DENOISE_RESTORE")
    dither = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Anti-band Dither", (920, 180), frame, "DEBAND_DENOISE_RESTORE")
    mix = nu.new_node(tree, "CompositorNodeMixRGB", "SCS Restore Mix Back", (1190, 180), frame, "DEBAND_DENOISE_RESTORE")
    _set_blur(band_smooth, _quality_value(settings, 1, 2, 3, 4, 5))
    _set_blur(detail_blur, _quality_value(settings, 2, 3, 4, 5, 6))
    nu.set_mix_mode(highpass, "SUBTRACT")
    nu.set_mix_mode(detail_mix, "ADD")
    nu.set_mix_mode(dither, "ADD")
    nu.safe_set_input(detail_mix, "Fac", 0.08 + 0.10 * _edge_protection(settings))
    nu.safe_set_input(dither, "Fac", _quality_value(settings, 0.004, 0.006, 0.008, 0.010, 0.012))
    nu.safe_set_input(mix, "Fac", _quality_value(settings, 0.18, 0.26, 0.34, 0.42, 0.50) * _guard_strength(settings))
    links = 0
    links += _safe_link(tree, src, denoise, ("Image",), ("Image",))
    links += _safe_link(tree, src, denoise, ("Normal",), ("Normal",))
    links += _safe_link(tree, src, denoise, ("DiffCol", "Diffuse Color", "Albedo"), ("Albedo",))
    links += _safe_link(tree, denoise, edge_smooth)
    links += _safe_link(tree, edge_smooth, band_smooth)
    links += _safe_link(tree, src, detail_blur)
    links += _safe_link(tree, src, highpass, ("Image",), (1, "Image"))
    links += _safe_link(tree, detail_blur, highpass, ("Image",), (2, "Image"))
    links += _safe_link(tree, band_smooth, detail_mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, highpass, detail_mix, ("Image",), (2, "Image"))
    links += _safe_link(tree, detail_mix, dither, ("Image",), (1, "Image"))
    links += _safe_link(tree, grain, dither, ("Value", "Color", "Image"), (2, "Image"))
    links += _safe_link(tree, src, mix, ("Image",), (1, "Image"))
    links += _safe_link(tree, dither, mix, ("Image",), (2, "Image"))
    links += _diagnostic_viewer(tree, dither, "SCS Restore QC Viewer", (1190, -80), frame, "DEBAND_DENOISE_RESTORE", settings)
    _add_precision_note(tree, frame, "DEBAND_DENOISE_RESTORE", settings, (-140, -300))
    links += _add_basic_output(tree, mix, settings, frame, "DEBAND_DENOISE_RESTORE")
    return BuildResult("DEBAND_DENOISE_RESTORE", t("多段デノイズ、デバンド、微細ディテール戻しを強化した復元スタックを追加しました。", "Added restoration stack with stronger multi-stage denoise, deband, and micro-detail reinjection."), frame.name, getattr(mix, "name", ""), len(tree.nodes) - start, links)


def build_signal_integrity_guard(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "SIGNAL_INTEGRITY_GUARD", t("信号整合性ガード", "Signal Integrity Guard"), settings)
    src = _image_source(tree, frame, "SIGNAL_INTEGRITY_GUARD")
    alpha = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Alpha Range Guard", (-80, 160), frame, "SIGNAL_INTEGRITY_GUARD")
    z_norm = nu.new_node(tree, "CompositorNodeNormalize", "SCS Depth Normalize Guard", (-80, -20), frame, "SIGNAL_INTEGRITY_GUARD")
    high = nu.new_node(tree, "CompositorNodeBrightContrast", "SCS Highlight Clip Sentinel", (-80, -200), frame, "SIGNAL_INTEGRITY_GUARD")
    nu.safe_set_input(high, "Contrast", 18)
    nu.safe_set_input(high, "Brightness", 0.02)
    links = 0
    links += _safe_link(tree, src, alpha, ("Alpha",), ("Fac", "Value"))
    links += _safe_link(tree, src, z_norm, ("Z", "Depth"), ("Value", "Image"))
    links += _safe_link(tree, src, high)
    links += _diagnostic_viewer(tree, alpha, "SCS Alpha Guard Viewer", (230, 260), frame, "SIGNAL_INTEGRITY_GUARD", settings)
    links += _diagnostic_viewer(tree, z_norm, "SCS Depth Guard Viewer", (230, -100), frame, "SIGNAL_INTEGRITY_GUARD", settings)
    links += _diagnostic_viewer(tree, high, "SCS Highlight Clip Viewer", (230, -300), frame, "SIGNAL_INTEGRITY_GUARD", settings)
    _add_precision_note(tree, frame, "SIGNAL_INTEGRITY_GUARD", settings, (-80, -430))
    links += _add_basic_output(tree, src, settings, frame, "SIGNAL_INTEGRITY_GUARD")
    return BuildResult("SIGNAL_INTEGRITY_GUARD", t("アルファ、深度、ハイライトの破綻確認用ガードを追加しました。", "Added guard stack for checking alpha, depth, and highlight integrity."), frame.name, getattr(src, "name", ""), len(tree.nodes) - start, links)


def build_precision_diagnostics_hub(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, "PRECISION_DIAGNOSTICS_HUB", t("精度診断ハブ", "Precision Diagnostics Hub"), settings)
    rl = _image_source(tree, frame, "PRECISION_DIAGNOSTICS_HUB", (-420, 160))
    links = 0
    diagnostics = [
        (("Image",), "SCS Beauty Diagnostics", (-120, 260)),
        (("Alpha",), "SCS Alpha Diagnostics", (-120, 120)),
        (("Z", "Depth"), "SCS Depth Diagnostics", (-120, -20)),
        (("Mist",), "SCS Mist Diagnostics", (-120, -160)),
        (("Normal",), "SCS Normal Diagnostics", (-120, -300)),
        (("Vector",), "SCS Vector Diagnostics", (-120, -440)),
        (("Position",), "SCS Position Diagnostics", (-120, -580)),
    ]
    for names, label, loc in diagnostics:
        node = nu.new_node(tree, "NodeReroute", label, loc, frame, "PRECISION_DIAGNOSTICS_HUB")
        links += _safe_link(tree, rl, node, names, ("Input",))
        links += _diagnostic_viewer(tree, node, f"{label} Viewer", (loc[0] + 260, loc[1]), frame, "PRECISION_DIAGNOSTICS_HUB", settings, ("Output", "Image", "Value", "Alpha"))
    if bool(getattr(settings, "create_file_outputs", True)):
        slots = ("Beauty", "Alpha", "Z", "Mist", "Normal", "Vector", "Position")
        fout = nu.add_file_output(tree, "SCS Diagnostics EXR Output", _base_path(settings), slots, (560, 30), frame, "PRECISION_DIAGNOSTICS_HUB")
        _set_file_format(fout)
        links += _connect_file_slots_from_render_layers(tree, rl, fout)
    _add_precision_note(tree, frame, "PRECISION_DIAGNOSTICS_HUB", settings, (-120, -760))
    final = rl
    links += _add_basic_output(tree, final, settings, frame, "PRECISION_DIAGNOSTICS_HUB")
    return BuildResult("PRECISION_DIAGNOSTICS_HUB", t("AOV、アルファ、深度、法線、ベクトルの診断ハブを追加しました。", "Added diagnostics hub for AOV, alpha, depth, normal, and vector signals."), frame.name, getattr(final, "name", ""), len(tree.nodes) - start, links)


def build_precision_master_workspace(context=None) -> BuildResult:
    ctx = context or bpy.context
    results = [enable_compositor(ctx), enable_render_passes(ctx)]
    functions = (
        build_aov_shuffle_matrix,
        build_precision_diagnostics_hub,
        build_signal_integrity_guard,
        build_cryptomatte_extractor,
        build_smart_merge,
        build_matte_refiner,
        build_chroma_key_studio,
        build_ai_mask_bridge,
        build_color_grade_panel,
        build_film_look_builder,
        build_color_match_look,
        build_lut_manager,
        build_advanced_glow,
        build_edge_rays,
        build_lens_flare_builder,
        build_bokeh_depth_blur,
        build_vector_motion_blur,
        build_beauty_retouch,
        build_deband_denoise_restore,
        build_sharpen_detail,
        build_optical_distort,
        build_heat_haze_distort,
        build_glitch_stylize,
        build_depth_fog_relight,
        build_normal_relight,
        build_particle_lights,
        build_time_echo,
        build_slap_comp,
        build_file_output_pipeline,
    )
    results.extend(_run_workbench_stages(ctx, functions))
    nodes = sum(result.nodes_created for result in results)
    links = sum(result.links_created for result in results)
    return BuildResult("PRECISION_MASTER_WORKSPACE", t("診断・保護レーンを増強した精度強化総合コンポジット作業台を追加しました。", "Added Precision Master Composite Workspace with stronger diagnostics and protection lanes."), nodes_created=nodes, links_created=links)


def build_surpass_master_workspace(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    old_mode = old_glow = None
    try:
        if settings is not None:
            old_mode = getattr(settings, "precision_mode", None)
            old_glow = getattr(settings, "glow_quality", None)
            nu.safe_set(settings, "precision_mode", "SURPASS")
            nu.safe_set(settings, "glow_quality", "SURPASS")
    except Exception:
        pass
    try:
        result = build_precision_master_workspace(ctx)
        result.preset_id = "SURPASS_MASTER_WORKSPACE"
        result.message = t("凌駕精度総合作業台を追加しました。", "Added Surpass Master Workspace.")
        return result
    finally:
        try:
            if settings is not None and old_mode is not None:
                nu.safe_set(settings, "precision_mode", old_mode)
            if settings is not None and old_glow is not None:
                nu.safe_set(settings, "glow_quality", old_glow)
        except Exception:
            pass


# -----------------------------------------------------------------------------
# Visual/precision engines. These are Blender-native high-density stacks
# designed to raise fidelity without copying proprietary commercial internals.
# -----------------------------------------------------------------------------

def build_aov_integrity_matrix(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    preset = "AOV_INTEGRITY_MATRIX"
    frame = _frame(tree, preset, t("AOV整合性マトリクス", "AOV Integrity Matrix"), settings)
    rl = _image_source(tree, frame, preset, (-460, 150))
    links = 0
    lanes = [
        ("Image", "SCS Beauty Integrity", 140), ("Alpha", "SCS Alpha Integrity", 40),
        ("Z", "SCS Z Integrity", -60), ("Depth", "SCS Depth Alias Integrity", -160),
        ("Mist", "SCS Mist Integrity", -260), ("Normal", "SCS Normal Integrity", -360),
        ("Vector", "SCS Vector Integrity", -460), ("Position", "SCS Position Integrity", -560),
        ("AO", "SCS AO Integrity", -660), ("Shadow", "SCS Shadow Integrity", -760),
        ("Emit", "SCS Emission Integrity", -860),
    ]
    for socket_name, label, y in lanes:
        r = nu.new_node(tree, "NodeReroute", label, (-120, y), frame, preset)
        links += _safe_link(tree, rl, r, (socket_name,), ("Input",))
    z_norm = nu.new_node(tree, "CompositorNodeNormalize", "SCS Z Normalized Inspection", (130, -60), frame, preset)
    z_ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Z Heat Range", (360, -60), frame, preset)
    alpha_ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Alpha Fringe Inspection", (360, 40), frame, preset)
    normal_sep = nu.new_node(tree, "CompositorNodeSepRGBA", "SCS Normal Channel Split", (130, -360), frame, preset)
    vector_sep = nu.new_node(tree, "CompositorNodeSepRGBA", "SCS Vector Channel Split", (130, -460), frame, preset)
    links += _safe_link(tree, rl, z_norm, ("Z", "Depth"), ("Value", "Image"))
    links += _safe_link(tree, z_norm, z_ramp, ("Value", "Image"), ("Fac", "Value"))
    links += _safe_link(tree, rl, alpha_ramp, ("Alpha",), ("Fac", "Value"))
    links += _safe_link(tree, rl, normal_sep, ("Normal",), ("Image",))
    links += _safe_link(tree, rl, vector_sep, ("Vector",), ("Image",))
    if bool(getattr(settings, "create_file_outputs", True)):
        slots = ("Beauty", "Alpha_QC", "Z_QC", "Mist_QC", "Normal_QC", "Vector_QC", "Position_QC", "Emission_QC")
        fout = nu.add_file_output(tree, "SCS Integrity EXR Output", _base_path(settings), slots, (670, -140), frame, preset)
        _set_file_format(fout)
        links += _safe_link(tree, rl, fout, ("Image",), ("Image",))
        links += _link_file_input(tree, alpha_ramp, fout, ("Image",), ("Alpha_QC",))
        links += _link_file_input(tree, z_ramp, fout, ("Image",), ("Z_QC",))
        for pass_names, slot_name in ((("Mist",), "Mist_QC"), (("Normal",), "Normal_QC"), (("Vector",), "Vector_QC"), (("Position",), "Position_QC"), (("Emit", "Emission"), "Emission_QC")):
            links += _link_file_input(tree, rl, fout, pass_names, (slot_name,))
    if bool(getattr(settings, "create_diagnostic_viewers", True)):
        links += _viewer_probe(tree, z_ramp, "SCS Viewer / Z Integrity", (670, -410), frame, preset)
        links += _viewer_probe(tree, alpha_ramp, "SCS Viewer / Alpha Integrity", (670, -540), frame, preset)
    _add_precision_note(tree, frame, preset, settings, (120, -1010))
    links += _add_basic_output(tree, rl, settings, frame, preset)
    return BuildResult(preset, t("AOV整合性マトリクスを追加しました。", "Added AOV Integrity Matrix."), frame.name, getattr(rl, "name", ""), len(tree.nodes)-start, links)


def build_matte_microsurgery_engine(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    preset = "MATTE_MICROSURGERY_ENGINE"
    frame = _frame(tree, preset, t("マット微細調整エンジン", "Matte Microsurgery Engine"), settings)
    rl = _image_source(tree, frame, preset, (-430, 120))
    blur_micro = nu.new_node(tree, "CompositorNodeBlur", "SCS Subpixel Pre-filter", (-140, 80), frame, preset)
    _set_blur(blur_micro, max(1, int(_float_setting(settings, "matte_edge_radius", 2.0))))
    erode = nu.new_node(tree, "CompositorNodeDilateErode", "SCS Core Choke / Expand", (90, 80), frame, preset)
    nu.safe_set(erode, "mode", "DISTANCE")
    nu.safe_set_input(erode, "Distance", -1.0 * _float_setting(settings, "matte_edge_radius", 2.0))
    ramp_core = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Core Density Curve", (330, 80), frame, preset)
    fringe = nu.new_node(tree, "CompositorNodeDilateErode", "SCS Fringe Recovery", (90, -80), frame, preset)
    nu.safe_set(fringe, "mode", "DISTANCE")
    nu.safe_set_input(fringe, "Distance", max(1.0, _float_setting(settings, "matte_edge_radius", 2.0)))
    blur_fringe = nu.new_node(tree, "CompositorNodeBlur", "SCS Fringe Feather", (330, -80), frame, preset)
    _set_blur(blur_fringe, max(2, int(_float_setting(settings, "matte_edge_radius", 2.0) * 2)))
    combine, mix_links = _mix_blend(tree, ramp_core, blur_fringe, "SCS Core + Fringe Matte", (590, 0), frame, preset, "MAXIMUM", 0.55)
    set_alpha = nu.new_node(tree, "CompositorNodeSetAlpha", "SCS Matte Apply", (840, 40), frame, preset)
    links = mix_links
    links += _safe_link(tree, rl, blur_micro, ("Alpha", "Image"), ("Image",))
    links += _safe_link(tree, blur_micro, erode)
    links += _safe_link(tree, erode, ramp_core, ("Image", "Value"), ("Fac", "Value"))
    links += _safe_link(tree, blur_micro, fringe)
    links += _safe_link(tree, fringe, blur_fringe)
    links += _safe_link(tree, rl, set_alpha, ("Image",), ("Image",))
    links += _safe_link(tree, combine, set_alpha, ("Image",), ("Alpha", "Fac"))
    if bool(getattr(settings, "create_diagnostic_viewers", True)):
        links += _viewer_probe(tree, combine, "SCS Viewer / Matte Microsurgery", (840, -160), frame, preset)
    _add_precision_note(tree, frame, preset, settings, (80, -330))
    links += _add_basic_output(tree, set_alpha, settings, frame, preset)
    return BuildResult(preset, t("マット微細調整エンジンを追加しました。", "Added Matte Microsurgery Engine."), frame.name, getattr(set_alpha, "name", ""), len(tree.nodes)-start, links)


def build_physical_optics_engine(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    preset = "PHYSICAL_OPTICS_ENGINE"
    frame = _frame(tree, preset, t("物理光学エンジン", "Physical Optics Engine"), settings)
    rl = _image_source(tree, frame, preset, (-470, 170))
    threshold = max(0.02, min(2.5, _float_setting(settings, "highlight_ceiling", 0.82)))
    realism = max(0.0, min(1.0, _float_setting(settings, "optical_realism", 0.72)))
    isolate = nu.new_node(tree, "CompositorNodeBrightContrast", "SCS Highlight Isolation", (-180, 160), frame, preset)
    nu.safe_set_input(isolate, "Brightness", 0.08)
    nu.safe_set_input(isolate, "Contrast", 0.42 + realism)
    bloom_wide = nu.new_node(tree, "CompositorNodeGlare", "SCS Wide Bloom Lobe", (70, 210), frame, preset)
    _set_glare(bloom_wide, "FOG_GLOW", threshold, 9, _glare_quality(settings))
    bloom_core = nu.new_node(tree, "CompositorNodeGlare", "SCS Core Bloom Lobe", (70, 50), frame, preset)
    _set_glare(bloom_core, "FOG_GLOW", max(0.02, threshold * 0.72), 6, _glare_quality(settings))
    streak = nu.new_node(tree, "CompositorNodeGlare", "SCS Lens Streak Lobe", (70, -110), frame, preset)
    _set_glare(streak, "STREAKS", max(0.02, threshold * 0.86), 7, _glare_quality(settings))
    mix1, l1 = _mix_add(tree, rl, bloom_wide, "SCS Add Wide Bloom", (360, 160), frame, preset, 0.22 + realism * 0.18, ("Glare",))
    mix2, l2 = _mix_add(tree, mix1, bloom_core, "SCS Add Core Bloom", (610, 160), frame, preset, 0.18 + realism * 0.18, ("Glare",))
    mix3, l3 = _mix_add(tree, mix2, streak, "SCS Add Lens Streak", (860, 160), frame, preset, 0.12 + realism * 0.16, ("Glare",))
    lens = nu.new_node(tree, "CompositorNodeLensdist", "SCS Micro Chromatic Lens", (1110, 160), frame, preset)
    nu.safe_set_input(lens, "Distort", 0.004 + realism * 0.006)
    nu.safe_set_input(lens, "Dispersion", 0.010 + realism * 0.020)
    guard = nu.new_node(tree, "CompositorNodeCurveRGB", "SCS Highlight Roll-off Guard", (1340, 160), frame, preset)
    _set_highlight_rolloff(guard)
    links = l1 + l2 + l3
    links += _safe_link(tree, rl, isolate)
    links += _safe_link(tree, isolate, bloom_wide)
    links += _safe_link(tree, isolate, bloom_core)
    links += _safe_link(tree, isolate, streak)
    links += _safe_link(tree, mix3, lens)
    links += _safe_link(tree, lens, guard)
    if bool(getattr(settings, "create_diagnostic_viewers", True)):
        links += _viewer_probe(tree, isolate, "SCS Viewer / Highlight Isolation", (360, -180), frame, preset)
        links += _viewer_probe(tree, guard, "SCS Viewer / Physical Optics", (1340, -20), frame, preset)
    _add_precision_note(tree, frame, preset, settings, (420, -350))
    links += _add_basic_output(tree, guard, settings, frame, preset)
    return BuildResult(preset, t("物理光学エンジンを追加しました。", "Added Physical Optics Engine."), frame.name, getattr(guard, "name", ""), len(tree.nodes)-start, links)


def build_adaptive_restore_engine(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    preset = "ADAPTIVE_RESTORE_ENGINE"
    frame = _frame(tree, preset, t("適応復元エンジン", "Adaptive Restore Engine"), settings)
    rl = _image_source(tree, frame, preset, (-440, 120))
    strength = max(0.0, min(1.0, _float_setting(settings, "restoration_strength", 0.38)))
    denoise = nu.new_node(tree, "CompositorNodeDenoise", "SCS Profile Denoise Core", (-160, 120), frame, preset)
    bilateral = nu.new_node(tree, "CompositorNodeBilateralblur", "SCS Edge-aware Smooth", (100, 120), frame, preset)
    blur = nu.new_node(tree, "CompositorNodeBlur", "SCS Band Smoothing", (360, 120), frame, preset)
    _set_blur(blur, max(2, int(3 + strength * 5)))
    curves = nu.new_node(tree, "CompositorNodeCurveRGB", "SCS Micro Detail Rebuild", (610, 120), frame, preset)
    sharpen = nu.new_node(tree, "CompositorNodeFilter", "SCS Detail Guard Sharpen", (850, 120), frame, preset)
    _set_filter(sharpen, "SHARPEN")
    mix, ml = _mix_blend(tree, rl, sharpen, "SCS Restoration Mix-back", (1090, 120), frame, preset, "MIX", max(0.05, min(0.85, strength)))
    links = ml
    links += _safe_link(tree, rl, denoise)
    links += _safe_link(tree, denoise, bilateral)
    links += _safe_link(tree, bilateral, blur)
    links += _safe_link(tree, blur, curves)
    links += _safe_link(tree, curves, sharpen)
    if bool(getattr(settings, "create_diagnostic_viewers", True)):
        links += _viewer_probe(tree, denoise, "SCS Viewer / Denoise Core", (100, -80), frame, preset)
        links += _viewer_probe(tree, mix, "SCS Viewer / Restore Mix", (1090, -80), frame, preset)
    _add_precision_note(tree, frame, preset, settings, (320, -270))
    links += _add_basic_output(tree, mix, settings, frame, preset)
    return BuildResult(preset, t("適応復元エンジンを追加しました。", "Added Adaptive Restore Engine."), frame.name, getattr(mix, "name", ""), len(tree.nodes)-start, links)


def build_perceptual_finishing_hub(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    preset = "PERCEPTUAL_FINISHING_HUB"
    frame = _frame(tree, preset, t("知覚仕上げハブ", "Perceptual Finishing Hub"), settings)
    rl = _image_source(tree, frame, preset, (-430, 120))
    exposure = nu.new_node(tree, "CompositorNodeExposure", "SCS Exposure Anchor", (-160, 120), frame, preset)
    balance = nu.new_node(tree, "CompositorNodeColorBalance", "SCS Lift Gamma Gain Trim", (80, 120), frame, preset)
    hue = nu.new_node(tree, "CompositorNodeHueSat", "SCS Hue Vector Trim", (330, 120), frame, preset)
    nu.safe_set_input(hue, "Saturation", 1.02)
    curves = nu.new_node(tree, "CompositorNodeCurveRGB", "SCS Perceptual Tone Curve", (580, 120), frame, preset)
    tonemap = nu.new_node(tree, "CompositorNodeCurveRGB", "SCS Delivery Roll-off", (830, 120), frame, preset)
    _set_highlight_rolloff(tonemap)
    links = _chain_links(tree, [rl, exposure, balance, hue, curves, tonemap])
    if bool(getattr(settings, "create_diagnostic_viewers", True)):
        links += _viewer_probe(tree, curves, "SCS Viewer / Tone Curve", (830, -90), frame, preset)
    _add_precision_note(tree, frame, preset, settings, (260, -280))
    links += _add_basic_output(tree, tonemap, settings, frame, preset)
    return BuildResult(preset, t("知覚仕上げハブを追加しました。", "Added Perceptual Finishing Hub."), frame.name, getattr(tonemap, "name", ""), len(tree.nodes)-start, links)


def build_scs_ultra_launchpad(context=None) -> BuildResult:
    ctx = context or bpy.context
    functions = (
        build_aov_integrity_matrix,
        build_matte_microsurgery_engine,
        build_physical_optics_engine,
        build_perceptual_finishing_hub,
        build_adaptive_restore_engine,
        build_precision_qc_suite,
        build_signal_integrity_guard,
    )
    results = _run_workbench_stages(ctx, functions)
    return BuildResult(
        "SCS_ULTRA_LAUNCHPAD",
        t("SCS超精度ランチャー構成を追加しました。", "Added SCS Ultra Launchpad stack set."),
        nodes_created=sum(r.nodes_created for r in results),
        links_created=sum(r.links_created for r in results),
    )


# ---------------------------------------------------------------------------
# Apex Precision UX builders
# ---------------------------------------------------------------------------

def _apex_apply_node_settings(node, spec: dict, settings=None) -> None:
    for attr, value in spec.get("attrs", {}).items():
        if attr == "filter_type":
            _set_filter(node, value)
        else:
            nu.safe_set(node, attr, value)
    for input_name, value in spec.get("inputs", {}).items():
        nu.safe_set_input(node, input_name, value)
    if spec.get("contrast") is not None:
        _set_mid_grey_contrast(node, float(spec["contrast"]))
    if spec.get("rolloff"):
        _set_highlight_rolloff(node)
    if spec.get("blur_size") is not None:
        _set_blur(node, int(spec.get("blur_size") or 1))
    if spec.get("glare"):
        glare = spec.get("glare") or {}
        _set_glare(
            node,
            glare.get("type", "FOG_GLOW"),
            float(glare.get("threshold", _float_setting(settings, "highlight_ceiling", 1.0))),
            int(glare.get("size", 7)),
            glare.get("quality", _glare_quality(settings)),
        )
    if spec.get("ramp"):
        _set_color_ramp_stops(node, spec["ramp"])
    if spec.get("mix"):
        mix = spec["mix"]
        nu.set_mix_mode(node, str(mix.get("blend", "MIX")))
        nu.safe_set_input(node, "Fac", float(mix.get("fac", 0.5)))


def _apex_linear_stack(context, preset: str, title_ja: str, title_en: str, chain: tuple[dict, ...], note_ja: str, note_en: str, slots: tuple[str, ...] = ()) -> BuildResult:
    ctx = context or bpy.context
    tree = nu.active_compositor_tree(ctx)
    settings = _settings(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, preset, t(title_ja, title_en), settings)
    rlayers = _image_source(tree, frame, preset, (-620, 180))
    current = rlayers
    probe = None
    links = 0
    viewer_source = None
    slot_sources = {}
    for index, spec in enumerate(chain):
        node = nu.new_node(
            tree,
            str(spec.get("type", "CompositorNodeMixRGB")),
            str(spec.get("label", f"SCS {preset} {index + 1}")),
            (-300 + index * 270, int(spec.get("y", 180 - (index % 3) * 95))),
            frame,
            preset,
        )
        _apex_apply_node_settings(node, spec, settings)
        to_names = spec.get("to", ("Image", "Value", "Alpha"))
        if spec.get("mix"):
            # Blends the processed result back over the original render.
            links += _safe_link(tree, rlayers, node, ("Image",), (1, "Image"))
            to_names = (2, "Image")
        elif str(spec.get("type")) == "CompositorNodeSetAlpha":
            # The matte built so far becomes the alpha of the original render.
            links += _safe_link(tree, rlayers, node, ("Image",), ("Image",))
            to_names = ("Alpha",)
        for out_names, in_names in spec.get("render_links", ()):
            links += _link_file_input(tree, rlayers, node, out_names, in_names)
        if spec.get("slot"):
            slot_sources[spec["slot"]] = node
        if spec.get("view"):
            viewer_source = node
        links += _safe_link(
            tree,
            rlayers if spec.get("from_render") else (probe or current) if spec.get("probe") else current,
            node,
            spec.get("from", ("Image", "Value", "Alpha", "Z", "Depth", "Normal", "Vector")),
            to_names,
        )
        if spec.get("probe"):
            # Diagnostic lane: fed by the stack, but not part of the image result.
            probe = node
        else:
            current = node

    if bool(getattr(settings, "create_diagnostic_viewers", True)) if settings is not None else True:
        links += _viewer_probe(tree, viewer_source or current, f"SCS Viewer / {preset}", (520 + len(chain) * 270, -80), frame, preset)
    if slots and (bool(getattr(settings, "create_file_outputs", True)) if settings is not None else True):
        file_node = nu.add_file_output(tree, f"SCS Output / {preset}", _base_path(settings), slots, (520 + len(chain) * 270, 170), frame, preset)
        _set_file_format(file_node)
        for slot in slots:
            links += _link_file_input(tree, slot_sources.get(slot, current), file_node, ("Image", "Mask", "Normal", "Val", "Value", "Alpha"), (slot,))
    nu.add_note(tree, t(note_ja, note_en), (-300, -360), frame, preset)
    _add_precision_note(tree, frame, preset, settings, (130, -360))
    links += _add_basic_output(tree, current, settings, frame, preset)
    return BuildResult(preset, t(f"{title_ja}を追加しました。", f"Added {title_en}."), frame.name, getattr(current, "name", ""), len(tree.nodes) - start, links)


def build_aov_delta_verifier(context=None) -> BuildResult:
    return _apex_linear_stack(
        context,
        "AOV_DELTA_VERIFIER",
        "AOV差分検証",
        "AOV Delta Verifier",
        (
            {"type": "CompositorNodeMapRange", "label": "SCS Depth Range Clamp", "probe": True, "from": ("Z", "Depth", "Image"), "to": ("Value", "Image"), "inputs": {"From Min": _float_setting(_settings(context), "depth_near", 1.0), "From Max": _float_setting(_settings(context), "depth_far", 100.0)}},
            {"type": "CompositorNodeNormalize", "label": "SCS Z Normalize / Delta Base", "probe": True, "from": ("Result", "Value", "Image"), "to": ("Value", "Image")},
            {"type": "CompositorNodeValToRGB", "label": "SCS AOV Heat Ramp", "probe": True, "slot": "depth_heat", "from": ("Value", "Image"), "to": ("Fac", "Value"), "ramp": ((0.0, (0.0, 0.0, 0.0, 1.0)), (0.5, (0.2, 0.6, 1.0, 1.0)), (1.0, (1.0, 0.4, 0.1, 1.0)))},
            {"type": "CompositorNodeMixRGB", "label": "SCS Beauty / AOV Overlay", "probe": True, "slot": "aov_overlay", "from": ("Image", "Value"), "to": (2, "Image"), "mix": {"blend": "ADD", "fac": 0.35}},
            {"type": "CompositorNodeBrightContrast", "label": "SCS Delta Contrast Guard", "probe": True, "view": True, "from": ("Image",), "to": ("Image",), "inputs": {"Contrast": 22.0}},
        ),
        "ビューティ、アルファ、Z、法線、ベクトルなどのAOV差分を視覚化し、欠落・極端値・範囲破綻を発見しやすくする検証スタックです。",
        "A verification stack for visualizing Beauty, Alpha, Z, Normal, Vector, and other AOV deltas so missing passes, extreme values, and range artifacts are easier to catch.",
        ("beauty_delta", "depth_heat", "aov_overlay"),
    )


def build_deep_matte_fusion_lab(context=None) -> BuildResult:
    radius = max(1, _int_setting(_settings(context), "matte_edge_radius", 3))
    return _apex_linear_stack(
        context,
        "DEEP_MATTE_FUSION_LAB",
        "深層マット融合ラボ",
        "Deep Matte Fusion Lab",
        (
            {"type": "CompositorNodeBlur", "label": "SCS Matte Pre-smooth", "blur_size": radius, "from": ("Alpha", "Image"), "to": ("Image", "Value")},
            {"type": "CompositorNodeDilateErode", "label": "SCS Core Matte Choke", "slot": "matte_core", "attrs": {"distance": -radius}, "from": ("Image", "Value"), "to": ("Mask", "Image", "Value")},
            {"type": "CompositorNodeDilateErode", "label": "SCS Fringe Matte Expand", "slot": "matte_fringe", "attrs": {"distance": radius + 1}, "from": ("Image", "Value"), "to": ("Mask", "Image", "Value")},
            {"type": "CompositorNodeValToRGB", "label": "SCS Edge Density Curve", "from": ("Image", "Value"), "to": ("Fac", "Value"), "ramp": ((0.0, (0, 0, 0, 1)), (0.62, (0.65, 0.65, 0.65, 1)), (1.0, (1, 1, 1, 1)))},
            {"type": "CompositorNodeSetAlpha", "label": "SCS Rebuilt Subpixel Alpha", "slot": "matte_rebuilt", "from": ("Image", "Value", "Alpha"), "to": ("Image", "Alpha")},
        ),
        "コアマットとフリンジマットを分け、髪・細線・半透明縁の密度を後から調整しやすい形に整えます。",
        "Separates core and fringe mattes so hair, thin lines, and translucent edges can be density-tuned after extraction.",
        ("matte_core", "matte_fringe", "matte_rebuilt"),
    )


def build_lens_aperture_designer(context=None) -> BuildResult:
    settings = _settings(context)
    return _apex_linear_stack(
        context,
        "LENS_APERTURE_DESIGNER",
        "レンズ絞り設計",
        "Lens Aperture Designer",
        (
            {"type": "CompositorNodeGlare", "label": "SCS Aperture Core Bloom", "slot": "aperture_core", "inputs": {"Strength": 0.4}, "glare": {"type": "FOG_GLOW", "threshold": _float_setting(settings, "highlight_ceiling", 1.0), "size": 7}},
            {"type": "CompositorNodeGlare", "label": "SCS Aperture Streak Lobe", "slot": "aperture_streak", "inputs": {"Strength": 0.3}, "glare": {"type": "STREAKS", "threshold": 0.85, "size": 6}},
            {"type": "CompositorNodeLensdist", "label": "SCS Aperture Micro Dispersion", "attrs": {"use_fit": True, "use_jitter": True}, "inputs": {"Dispersion": min(0.18, _float_setting(settings, "optical_realism", 0.72) * 0.12)}},
            {"type": "CompositorNodeMixRGB", "label": "SCS Lens Energy Blend", "mix": {"blend": "MIX", "fac": min(0.65, _float_setting(settings, "optical_realism", 0.72))}},
            {"type": "CompositorNodeCurveRGB", "label": "SCS Highlight Roll-off", "slot": "highlight_guard", "rolloff": True},
        ),
        "グロー、ストリーク、微細色収差、ハイライトロールオフを分離し、レンズ由来の光学感を破綻しにくい順序で構築します。",
        "Separates glow, streaks, micro chromatic dispersion, and highlight roll-off so lens-like optical energy is built in an artifact-resistant order.",
        ("aperture_core", "aperture_streak", "highlight_guard"),
    )


def build_dynamic_range_sculptor(context=None) -> BuildResult:
    settings = _settings(context)
    return _apex_linear_stack(
        context,
        "DYNAMIC_RANGE_SCULPTOR",
        "ダイナミックレンジ整形",
        "Dynamic Range Sculptor",
        (
            {"type": "CompositorNodeColorBalance", "label": "SCS Exposure Anchor", "contrast": 8.0},
            {"type": "CompositorNodeColorBalance", "label": "SCS Lift Gamma Gain Guard"},
            {"type": "CompositorNodeRGBToBW", "label": "SCS Luma Safety Probe", "probe": True, "slot": "delivery_luma"},
            {"type": "CompositorNodeValToRGB", "label": "SCS HDR Safety Ramp", "probe": True, "slot": "hdr_probe", "from": ("Val", "Value", "Image"), "to": ("Fac", "Value"), "ramp": ((0.0, (0, 0, 0, 1)), (0.72, (0.8, 0.8, 0.8, 1)), (1.0, (1, 0.82, 0.32, 1)))},
            {"type": "CompositorNodeCurveRGB", "label": "SCS Delivery Roll-off", "slot": "rolloff", "rolloff": True},
            {"type": "CompositorNodeMixRGB", "label": "SCS HDR Mix-back", "mix": {"blend": "MIX", "fac": max(0.2, 1.0 - _float_setting(settings, "artifact_guard_strength", 0.78) * 0.45)}},
        ),
        "HDR発光をつぶさず、白飛びと彩度破綻を確認しながら納品向けの階調へ整形します。",
        "Shapes HDR values toward delivery-safe tone while preserving highlight energy and checking clipping or saturation artifacts.",
        ("hdr_probe", "rolloff", "delivery_luma"),
    )


def build_perception_match_assistant(context=None) -> BuildResult:
    return _apex_linear_stack(
        context,
        "PERCEPTION_MATCH_ASSISTANT",
        "知覚マッチ補助",
        "Perception Match Assistant",
        (
            {"type": "CompositorNodeColorBalance", "label": "SCS Neutral Balance"},
            {"type": "CompositorNodeHueSat", "label": "SCS Hue Vector Trim", "inputs": {"Saturation": 1.0, "Value": 1.0}},
            {"type": "CompositorNodeCurveRGB", "label": "SCS Perceptual Tone Curve"},
            {"type": "CompositorNodeColorBalance", "label": "SCS Local Contrast Anchor", "slot": "perception_grade", "contrast": 6.0},
            {"type": "CompositorNodeMixRGB", "label": "SCS Reference Match Mix-back", "slot": "match_preview", "mix": {"blend": "MIX", "fac": 0.72}},
        ),
        "参照画像やプレートに合わせやすいよう、ホワイトバランス、色相、階調、局所コントラスト、ミックスバックを一列で調整します。",
        "Arranges white balance, hue, tone, local contrast, and mix-back in a single lane for easier matching to a reference or plate.",
        ("perception_grade", "match_preview"),
    )


def build_adaptive_denoise_profile_lab(context=None) -> BuildResult:
    settings = _settings(context)
    strength = _float_setting(settings, "restoration_strength", 0.38)
    return _apex_linear_stack(
        context,
        "ADAPTIVE_DENOISE_PROFILE_LAB",
        "適応デノイズプロファイル",
        "Adaptive Denoise Profile Lab",
        (
            {"type": "CompositorNodeDenoise", "label": "SCS Profile Denoise Intake", "slot": "denoise_profile"},
            {"type": "CompositorNodeBlur", "label": "SCS Band Smooth Pass", "slot": "band_smooth", "blur_size": max(1, int(2 + strength * 8))},
            {"type": "CompositorNodeFilter", "label": "SCS Detail Recovery Filter", "attrs": {"filter_type": "SHARPEN"}},
            {"type": "CompositorNodeMixRGB", "label": "SCS Texture Preserve Mix", "slot": "texture_mix", "mix": {"blend": "MIX", "fac": max(0.18, min(0.78, strength))}},
            {"type": "CompositorNodeColorBalance", "label": "SCS Overclean Guard", "contrast": 2.0},
        ),
        "復元を置換ではなくミックスバック前提で組み、ノイズ・バンディングを抑えながら元の質感を残します。",
        "Builds restoration as a mix-back workflow, reducing noise and banding while retaining original texture.",
        ("denoise_profile", "band_smooth", "texture_mix"),
    )


def build_motion_flow_guard(context=None) -> BuildResult:
    return _apex_linear_stack(
        context,
        "MOTION_FLOW_GUARD",
        "モーションフロー保護",
        "Motion Flow Guard",
        (
            {"type": "CompositorNodeVecBlur", "label": "SCS Vector Motion Intake", "slot": "motion_blur", "from": ("Image",), "to": ("Image",), "render_links": ((("Vector",), ("Speed",)), (("Z", "Depth"), ("Depth",))), "inputs": {"Samples": 16}},
            {"type": "CompositorNodeBlur", "label": "SCS Motion Edge Safety", "blur_size": 2},
            {"type": "CompositorNodeMixRGB", "label": "SCS Motion Mix-back", "slot": "motion_guard", "mix": {"blend": "MIX", "fac": 0.55}},
            {"type": "CompositorNodeValToRGB", "label": "SCS Motion Intensity Map", "probe": True, "slot": "motion_map", "to": ("Fac", "Value"), "ramp": ((0.0, (0, 0, 0, 1)), (0.7, (0.2, 0.8, 1, 1)), (1.0, (1, 0.2, 0.1, 1)))},
        ),
        "ベクトルパス由来のブラーをミックスバックし、過剰ブラーやエッジ破綻を診断しやすい形にします。",
        "Mixes back vector-based blur and exposes diagnostic lanes for excessive blur or edge artifacts.",
        ("motion_blur", "motion_guard", "motion_map"),
    )


def build_geometry_signal_bridge(context=None) -> BuildResult:
    return _apex_linear_stack(
        context,
        "GEOMETRY_SIGNAL_BRIDGE",
        "ジオメトリ信号ブリッジ",
        "Geometry Signal Bridge",
        (
            {"type": "CompositorNodeNormalize", "label": "SCS Depth Normalized", "probe": True, "from": ("Z", "Depth", "Image"), "to": ("Value", "Image")},
            {"type": "CompositorNodeValToRGB", "label": "SCS Depth / Height Ramp", "probe": True, "slot": "depth_signal", "from": ("Value", "Image"), "to": ("Fac", "Value"), "ramp": ((0.0, (0.05, 0.05, 0.1, 1)), (0.5, (0.25, 0.55, 0.85, 1)), (1.0, (0.9, 0.9, 0.9, 1)))},
            {"type": "CompositorNodeMixRGB", "label": "SCS Geometry Signal Overlay", "probe": True, "slot": "geometry_overlay", "mix": {"blend": "ADD", "fac": 0.28}},
            {"type": "CompositorNodeBlur", "label": "SCS AO Soft Proxy", "probe": True, "view": True, "blur_size": 3},
            {"type": "CompositorNodeNormal", "label": "SCS Normal Relight Probe", "probe": True, "slot": "normal_probe", "from_render": True, "from": ("Normal",), "to": ("Normal",)},
        ),
        "深度、法線、高さ／AO的な信号を確認・受け渡ししやすいブリッジとしてまとめます。",
        "Collects depth, normal, and height/AO-like signals into a bridge for inspection and downstream handoff.",
        ("depth_signal", "normal_probe", "geometry_overlay"),
    )


def build_delivery_sanity_check(context=None) -> BuildResult:
    ctx = context or bpy.context
    settings = _settings(ctx)
    preset = "DELIVERY_SANITY_CHECK"
    if not _file_outputs_enabled(settings):
        return _file_outputs_off_result(preset)
    tree = nu.active_compositor_tree(ctx)
    start = len(tree.nodes)
    frame = _frame(tree, preset, t("納品整合チェック", "Delivery Sanity Check"), settings)
    rlayers = _image_source(tree, frame, preset, (-520, 120))
    links = 0
    output = nu.add_file_output(
        tree,
        "SCS Delivery QC EXR Output",
        _base_path(settings),
        ("beauty", "alpha", "depth", "normal", "vector", "matte_qc", "hdr_qc", "delivery_preview"),
        (-120, 120),
        frame,
        preset,
    )
    _set_file_format(output)
    for socket_name, slot_index in (("Image", 0), ("Alpha", 1), ("Z", 2), ("Normal", 3), ("Vector", 4)):
        links += _link_file_input(tree, rlayers, output, (socket_name,), (slot_index,))
    luma = nu.new_node(tree, "CompositorNodeRGBToBW", "SCS Delivery Luma", (-400, -120), frame, preset)
    hdr_ramp = nu.new_node(tree, "CompositorNodeValToRGB", "SCS Delivery HDR Clip", (-400, -260), frame, preset)
    _set_color_ramp_stops(hdr_ramp, ((0.70, (0.0, 0.0, 0.0, 1.0)), (0.96, (1.0, 1.0, 1.0, 1.0))))
    links += _safe_link(tree, rlayers, luma)
    links += _safe_link(tree, luma, hdr_ramp, ("Val", "Value", "Image"), ("Fac", "Value"))
    links += _link_file_input(tree, rlayers, output, ("Alpha",), ("matte_qc",))
    links += _link_file_input(tree, hdr_ramp, output, ("Image",), ("hdr_qc",))
    links += _link_file_input(tree, rlayers, output, ("Image",), ("delivery_preview",))
    viewer = nu.new_node(tree, "CompositorNodeViewer", "SCS Delivery Viewer", (280, 80), frame, preset)
    composite = nu.new_node(tree, "CompositorNodeComposite", "SCS Delivery Composite", (280, -70), frame, preset)
    links += _safe_link(tree, rlayers, viewer, ("Image",), ("Image",))
    links += _safe_link(tree, rlayers, composite, ("Image",), ("Image",))
    nu.add_note(tree, t("32bit EXR、RGBA、AOVスロット、ビューアー／コンポジットの最終接続を確認する納品前チェックフレームです。", "Pre-delivery check frame for 32-bit EXR, RGBA, AOV slots, and final Viewer/Composite connections."), (-120, -260), frame, preset)
    _add_precision_note(tree, frame, preset, settings, (280, -260))
    return BuildResult(preset, t("納品整合チェックを追加しました。", "Added Delivery Sanity Check."), frame.name, getattr(output, "name", ""), len(tree.nodes) - start, links)


_GUIDE_HEAD_JA = {"Matte": "マット", "Optics": "光学", "Color": "色", "Restore": "復元", "Delivery": "納品"}


def build_apex_visual_guide_board(context=None) -> BuildResult:
    ctx = context or bpy.context
    tree = nu.active_compositor_tree(ctx)
    settings = _settings(ctx)
    preset = "APEX_VISUAL_GUIDE_BOARD"
    start = len(tree.nodes)
    frame = _frame(tree, preset, t("Apex画像ガイドボード", "Apex Visual Guide Board"), settings)
    links = 0
    guides = (
        ("AOV", "AOV差分、深度範囲、法線／ベクトルの欠落を先に確認します。", "Check AOV deltas, depth range, and missing Normal/Vector first."),
        ("Matte", "コア、フリンジ、フェザー、ハロー抑制を分離します。", "Separate core, fringe, feather, and halo suppression."),
        ("Optics", "光源抽出、ブルーム、ストリーク、色収差、ロールオフを順番に重ねます。", "Layer light isolation, bloom, streaks, chromatic effects, and roll-off in order."),
        ("Color", "露出、バランス、色相、カーブ、納品トリムを分けます。", "Separate exposure, balance, hue, curve, and delivery trim."),
        ("Restore", "デノイズ、デバンド、ディテール回復をミックスバックで戻します。", "Return denoise, deband, and detail recovery through mix-back."),
        ("Delivery", "品質レポートとEXR出力で最後に検査します。", "Finish by checking the quality report and EXR outputs."),
    )
    for i, (head, ja, en) in enumerate(guides):
        note = nu.add_note(tree, t(f"{_GUIDE_HEAD_JA.get(head, head)}: {ja}", f"{head}: {en}"), (-420 + (i % 2) * 430, 120 - (i // 2) * 170), frame, preset)
        try:
            nu.safe_set(note, "width", 400)
        except Exception:
            pass
    rlayers = _image_source(tree, frame, preset, (-520, -420))
    reroute = nu.new_node(tree, "NodeReroute", "SCS Guide Board Input", (-120, -420), frame, preset)
    links += _safe_link(tree, rlayers, reroute)
    return BuildResult(preset, t("Apex画像ガイドボードを追加しました。", "Added Apex Visual Guide Board."), frame.name, getattr(reroute, "name", ""), len(tree.nodes) - start, links)


def build_apex_command_workspace(context=None) -> BuildResult:
    ctx = context or bpy.context
    functions = (
        build_aov_delta_verifier,
        build_deep_matte_fusion_lab,
        build_lens_aperture_designer,
        build_dynamic_range_sculptor,
        build_perception_match_assistant,
        build_adaptive_denoise_profile_lab,
        build_motion_flow_guard,
        build_geometry_signal_bridge,
        build_delivery_sanity_check,
        build_apex_visual_guide_board,
    )
    results = [enable_render_passes(ctx)]
    results.extend(_run_workbench_stages(ctx, functions))
    return BuildResult(
        "APEX_COMMAND_WORKSPACE",
        t("Apex統合作業台を追加しました。", "Added Apex Command Workspace."),
        nodes_created=sum(r.nodes_created for r in results),
        links_created=sum(r.links_created for r in results),
    )


BUILDERS: dict[str, Callable[[object | None], BuildResult]] = {
    "SCS_ULTRA_LAUNCHPAD": build_scs_ultra_launchpad,
    "PERCEPTUAL_FINISHING_HUB": build_perceptual_finishing_hub,
    "AOV_INTEGRITY_MATRIX": build_aov_integrity_matrix,
    "ADAPTIVE_RESTORE_ENGINE": build_adaptive_restore_engine,
    "PHYSICAL_OPTICS_ENGINE": build_physical_optics_engine,
    "MATTE_MICROSURGERY_ENGINE": build_matte_microsurgery_engine,
    "AOV_SHUFFLE_MATRIX": build_aov_shuffle_matrix,
    "CRYPTOMATTE_EXTRACTOR": build_cryptomatte_extractor,
    "FILE_OUTPUT_PIPELINE": build_file_output_pipeline,
    "SMART_MERGE": build_smart_merge,
    "MATTE_REFINER": build_matte_refiner,
    "SLAP_COMP": build_slap_comp,
    "CHROMA_KEY_STUDIO": build_chroma_key_studio,
    "AI_MASK_BRIDGE": build_ai_mask_bridge,
    "BEAUTY_RETOUCH": build_beauty_retouch,
    "BOKEH_DEPTH_BLUR": build_bokeh_depth_blur,
    "VECTOR_MOTION_BLUR": build_vector_motion_blur,
    "OPTICAL_DISTORT": build_optical_distort,
    "TIME_ECHO": build_time_echo,
    "ADVANCED_GLOW": build_advanced_glow,
    "EDGE_RAYS": build_edge_rays,
    "LENS_FLARE_BUILDER": build_lens_flare_builder,
    "COLOR_GRADE_PANEL": build_color_grade_panel,
    "FILM_LOOK_BUILDER": build_film_look_builder,
    "COLOR_MATCH_LOOK": build_color_match_look,
    "LUT_MANAGER": build_lut_manager,
    "VIGNETTE_FINISH": build_vignette_finish,
    "DEBAND_DENOISE_RESTORE": build_deband_denoise_restore,
    "SHARPEN_DETAIL": build_sharpen_detail,
    "HEAT_HAZE_DISTORT": build_heat_haze_distort,
    "GLITCH_STYLIZE": build_glitch_stylize,
    "DEPTH_FOG_RELIGHT": build_depth_fog_relight,
    "NORMAL_RELIGHT": build_normal_relight,
    "PARTICLE_LIGHTS": build_particle_lights,
    "SIGNAL_INTEGRITY_GUARD": build_signal_integrity_guard,
    "PRECISION_DIAGNOSTICS_HUB": build_precision_diagnostics_hub,
    "SURPASS_MASTER_WORKSPACE": build_surpass_master_workspace,
    "PRECISION_QC_SUITE": build_precision_qc_suite,
    "MATTE_EDGE_LAB": build_matte_edge_lab,
    "SPECTRAL_LIGHT_LAB": build_spectral_light_lab,
    "DEPTH_NORMALIZER": build_depth_normalizer,
    "COLOR_WARPER_LAB": build_color_warper_lab,
    "CLEANROOM_PLUS": build_cleanroom_plus,
    # SCS original purpose aliases. These are neutral internal IDs that route to
    # editable Blender-native stacks or bridge workbenches.
    "CHANNEL_BROWSER": build_aov_shuffle_matrix,
    "MULTI_LAYER_EXR_PIPELINE": build_aov_shuffle_matrix,
    "CHANNEL_BOOLEAN_MATRIX": build_aov_shuffle_matrix,
    "AOV_SLAPCOMP_LAYER": build_slap_comp,
    "DEEP_HOLDOUT_PROXY": build_depth_fog_relight,
    "AOV_SEGMENTATION_BRIDGE": build_ai_mask_bridge,
    "SCREEN_KEYER_BRIDGE": build_chroma_key_studio,
    "ROTO_EDGE_BRIDGE": build_ai_mask_bridge,
    "OBJECT_MATTE_BRIDGE": build_ai_mask_bridge,
    "SHOT_LEARNER_BRIDGE": build_ai_mask_bridge,
    "CLEAN_PLATE_BRIDGE": build_ai_mask_bridge,
    "PLANAR_TRACKING_BRIDGE": build_ai_mask_bridge,
    "MATTE_ASSIST_BRIDGE": build_ai_mask_bridge,
    "SEMANTIC_KEYER_BRIDGE": build_ai_mask_bridge,
    "DEPTH_ESTIMATE_BRIDGE": build_ai_mask_bridge,
    "BEAUTY_RETOUCH_STACK": build_beauty_retouch,
    "EDGE_AWARE_BEAUTY": build_beauty_retouch,
    "BILATERAL_RESTORE": build_deband_denoise_restore,
    "PROFILE_DENOISE_FRAME": build_deband_denoise_restore,
    "GUIDED_DENOISE_INTAKE": build_deband_denoise_restore,
    "DEBAND_ADVANCED": build_deband_denoise_restore,
    "DEBLOCK_RESTORE": build_deband_denoise_restore,
    "DETAIL_UPSCALE_INTAKE": build_deband_denoise_restore,
    "FRAME_FIXER_INTAKE": build_deband_denoise_restore,
    "DETAIL_PRESERVE_SHARPEN": build_sharpen_detail,
    "BOKEH_APERTURE_EDITOR": build_bokeh_depth_blur,
    "APERTURE_DOF_STACK": build_bokeh_depth_blur,
    "CAMERA_LENS_BLUR_PLUS": build_bokeh_depth_blur,
    "VECTORLESS_MOTION_BRIDGE": build_vector_motion_blur,
    "TEMPORAL_INTERPOLATOR_BRIDGE": build_time_echo,
    "OPTICAL_FLOW_RETIME_BRIDGE": build_time_echo,
    "DIRECTIONAL_BLUR_STACK": build_optical_distort,
    "EDGE_RAYS_PLUS": build_edge_rays,
    "ADAPTIVE_BLOOM_FIELD": build_advanced_glow,
    "PHYSICAL_LENS_ARTIFACT_EDITOR": build_lens_flare_builder,
    "LAYERED_LENS_LIGHT_INTAKE": build_lens_flare_builder,
    "LENS_ARTIFACT_LAYER": build_lens_flare_builder,
    "FILM_BURN_TRANSITION": build_lens_flare_builder,
    "CAUSTICS_LIGHT_PATTERN": build_particle_lights,
    "AURORA_SPLINE_LIGHT": build_particle_lights,
    "LIGHT_LEAK_LAYER": build_lens_flare_builder,
    "VOLUMETRIC_RAYS": build_edge_rays,
    "CHROMATIC_ABERRATION_LAYER": build_optical_distort,
    "UNIFIED_GRADE_PANEL": build_color_grade_panel,
    "COLOR_WHEELS_PANEL": build_color_grade_panel,
    "CINE_LOOK_BUILDER": build_film_look_builder,
    "HUE_MESH_REMAPPER": build_color_grade_panel,
    "MATCH_GRADE_BRIDGE": build_color_match_look,
    "HUE_VECTOR_ISOLATOR": build_color_grade_panel,
    "OCIO_LUT_MANAGER": build_lut_manager,
    "VIGNETTE_LOOK": build_vignette_finish,
    "HEAT_DISTORT_PLUS": build_heat_haze_distort,
    "MESH_WARP_BRIDGE": build_optical_distort,
    "LENS_CORRECTION_STACK": build_optical_distort,
    "GLITCH_DAMAGE_STACK": build_glitch_stylize,
    "DIGITAL_DAMAGE_STACK": build_glitch_stylize,
    "FRACTAL_NOISE_TEXTURE": build_particle_lights,
    "BEAM_LIGHT_GENERATOR": build_lens_flare_builder,
    "PARTICLE_PLATE_BRIDGE": build_particle_lights,
    "PARTICLE_FIELD_BRIDGE": build_particle_lights,
    "NORMAL_RELIGHT_PLUS": build_normal_relight,
    "HEIGHT_TO_NORMAL_PROXY": build_height_to_normal,
    "DEPTH_FOG_PLUS": build_depth_fog_relight,
    "HEIGHT_TO_AO_PROXY": build_depth_fog_relight,
    "SDF_MASK_EXPAND": build_matte_refiner,
    "SCENE_PROXY_WORKBENCH": build_slap_comp,
    "GEOMETRY_NODES_BRIDGE": build_slap_comp,
    "GPU_IMAGE_GRAPH_PROXY": build_slap_comp,
    "OPEN_FILTER_BRIDGE": build_glitch_stylize,
    "BATCH_EXPORT_PIPELINE": build_file_output_pipeline,
    "PYTHON_PIPELINE_HOOKS": build_asset_shelf_prep,
    "ASSET_SHELF_PREP": build_asset_shelf_prep,
    "BUILD_MASTER_WORKSPACE": build_master_workspace,
    "PRECISION_QC_LAB": build_precision_qc_lab,
    "HDR_HIGHLIGHT_GUARD": build_hdr_highlight_guard,
    "SUBPIXEL_MATTE_LAB": build_subpixel_matte_lab,
    "OPTICAL_BLOOM_LAB": build_optical_bloom_lab,
    "RESTORATION_LAB": build_restoration_lab,
    "DEPTH_VECTOR_AUDIT": build_depth_vector_audit,
    "PRECISION_OVERDRIVE_WORKSPACE": build_precision_overdrive_workspace,
    "PRECISION_MASTER_WORKSPACE": build_precision_master_workspace,
    "PRECISIONCORE_MASTER": build_precision_master_workspace,
    "SURPASSCORE_MASTER": build_surpass_master_workspace,
    "ARTIFACT_GUARD_MATRIX": build_signal_integrity_guard,
    "AOV_DIAGNOSTIC_HUB": build_precision_diagnostics_hub,
    "MATTE_EDGE_PRECISION": build_matte_edge_lab,
    "LIGHT_SURPASS_LAB": build_spectral_light_lab,
    "DEPTH_QC_NORMALIZER": build_depth_normalizer,
    "COLOR_MESH_SURPASS": build_color_warper_lab,
    "RESTORE_SURPASS_PLUS": build_cleanroom_plus,
    "FIDELITY_QC_LAB": build_precision_qc_lab,
    "CLIP_GUARD": build_hdr_highlight_guard,
    "GAMUT_ROLLOFF_GUARD": build_hdr_highlight_guard,
    "MATTE_HALO_SUPPRESSOR": build_subpixel_matte_lab,
    "HAIR_EDGE_REFINER": build_subpixel_matte_lab,
    "MULTI_LOBE_BLOOM_CORE": build_optical_bloom_lab,
    "ENERGY_PRESERVED_GLOW": build_optical_bloom_lab,
    "FREQUENCY_RESTORE_CORE": build_restoration_lab,
    "BANDING_DIAGNOSTIC_RESTORE": build_restoration_lab,
    "DEPTH_VECTOR_INTEGRITY": build_depth_vector_audit,
    "PRECISION_OVERDRIVE_MASTER": build_precision_overdrive_workspace,
    "UI_ICON_LAUNCHPAD": build_scs_ultra_launchpad,
    "VISUAL_REFERENCE_BOARD": build_scs_ultra_launchpad,
    "AOV_INTEGRITY_MATRIX_PLUS": build_aov_integrity_matrix,
    "MATTE_MICROSURGERY_PLUS": build_matte_microsurgery_engine,
    "PHYSICAL_OPTICS_PLUS": build_physical_optics_engine,
    "PERCEPTUAL_FINISHING_PLUS": build_perceptual_finishing_hub,
    "ADAPTIVE_RESTORE_PLUS": build_adaptive_restore_engine,
}


BUILDERS.update({
    "APEX_COMMAND_WORKSPACE": build_apex_command_workspace,
    "AOV_DELTA_VERIFIER": build_aov_delta_verifier,
    "DEEP_MATTE_FUSION_LAB": build_deep_matte_fusion_lab,
    "LENS_APERTURE_DESIGNER": build_lens_aperture_designer,
    "DYNAMIC_RANGE_SCULPTOR": build_dynamic_range_sculptor,
    "PERCEPTION_MATCH_ASSISTANT": build_perception_match_assistant,
    "ADAPTIVE_DENOISE_PROFILE_LAB": build_adaptive_denoise_profile_lab,
    "MOTION_FLOW_GUARD": build_motion_flow_guard,
    "GEOMETRY_SIGNAL_BRIDGE": build_geometry_signal_bridge,
    "DELIVERY_SANITY_CHECK": build_delivery_sanity_check,
    "APEX_VISUAL_GUIDE_BOARD": build_apex_visual_guide_board,
    "AOV_DELTA_QC": build_aov_delta_verifier,
    "MATTE_FUSION_CORE": build_deep_matte_fusion_lab,
    "APERTURE_LAYER_EDITOR": build_lens_aperture_designer,
    "HDR_RANGE_GUARD": build_dynamic_range_sculptor,
    "PERCEPTUAL_MATCH_CORE": build_perception_match_assistant,
    "PROFILE_RESTORE_CORE": build_adaptive_denoise_profile_lab,
    "MOTION_VECTOR_SANITY": build_motion_flow_guard,
    "GEOMETRY_SIGNAL_WORKBENCH": build_geometry_signal_bridge,
    "DELIVERY_QC_PIPELINE": build_delivery_sanity_check,
    "VISUAL_WORKFLOW_BOARD": build_apex_visual_guide_board,
})


def _align_result_frame(context, result: BuildResult) -> BuildResult:
    tree = nu.active_compositor_tree(context or bpy.context)
    nu.move_notes_clear_of_nodes(tree)
    frame = tree.nodes.get(result.frame_name) if result.frame_name else None
    if frame is not None:
        nu.align_frame_left_edge(tree, frame)
    return result


# These send a black-and-white check image to the output, so the next effect starts from the render again.
_CHECK_IMAGE_PRESETS = frozenset({"CRYPTOMATTE_EXTRACTOR", "DEPTH_VECTOR_AUDIT", "DEPTH_NORMALIZER", "PRECISION_QC_SUITE"})


def _socket_key(socket):
    return (socket.node.name, socket.identifier) if socket is not None else None


def _socket_from_key(tree, key):
    node = tree.nodes.get(key[0]) if key else None
    return next((socket for socket in node.outputs if socket.identifier == key[1]), None) if node is not None else None


def _output_feeds(tree) -> list:
    """Each output node's image input, with the key of the socket feeding it now."""
    feeds = []
    for node in nu.find_output_nodes(tree):
        socket = nu.input_socket(node, ("Image",)) if node is not None else None
        if socket is not None:
            feeds.append((socket, _socket_key(socket.links[0].from_socket) if socket.is_linked else None))
    return feeds


def _carries_image_result(tree, key) -> bool:
    node = tree.nodes.get(key[0]) if key else None
    if node is None or node.bl_idname == "CompositorNodeRLayers":
        return False
    return str(node.get("scs_preset_id", "")) not in _CHECK_IMAGE_PRESETS


def _stack_on_previous_result(tree, result: BuildResult, feeds: list) -> int:
    """A new effect takes the image that reached the output before it, instead of the raw render."""
    frame = tree.nodes.get(result.frame_name) if result.frame_name else None
    previous = feeds[0][1] if feeds else None
    if frame is None or not _carries_image_result(tree, previous):
        return 0
    output_input = feeds[0][0]
    current = output_input.links[0].from_socket if output_input.is_linked else None
    if current is None or _socket_key(current) == previous or result.preset_id in _CHECK_IMAGE_PRESETS:
        return 0
    previous_socket = _socket_from_key(tree, previous)
    if previous_socket is None:
        return 0
    count = 0
    if current.node.bl_idname == "CompositorNodeRLayers":
        # A check stack that only passes the render through leaves the finished image at the output.
        for socket, key in feeds:
            source = _socket_from_key(tree, key)
            if source is not None:
                count += int(nu.link_sockets(tree, source, socket))
        return count
    for link in list(tree.links):
        source = link.from_node
        if source.bl_idname == "CompositorNodeRLayers" and source.parent == frame and link.from_socket.name == "Image":
            count += int(nu.link_sockets(tree, previous_socket, link.to_socket))
    return count


# Inside a workbench these are placed ready to use, but stay off the line to the output: check images,
# stacks that wait for outside images or a matte setup (black or dark until then), and strong looks to opt into.
_WORKBENCH_OFF_LINE_PRESETS = _CHECK_IMAGE_PRESETS | frozenset({
    "SMART_MERGE", "CHROMA_KEY_STUDIO", "AI_MASK_BRIDGE", "MATTE_REFINER", "SUBPIXEL_MATTE_LAB", "HDR_HIGHLIGHT_GUARD",
    "LENS_APERTURE_DESIGNER", "FILM_LOOK_BUILDER", "EDGE_RAYS", "LENS_FLARE_BUILDER", "OPTICAL_DISTORT",
    "HEAT_HAZE_DISTORT", "GLITCH_STYLIZE", "NORMAL_RELIGHT", "PARTICLE_LIGHTS", "TIME_ECHO",
})


def _run_workbench_stages(ctx, functions) -> list[BuildResult]:
    """A workbench's stages feed each other in turn, the same as effects added one by one."""
    tree = nu.active_compositor_tree(ctx)
    results = []
    for function in functions:
        feeds = _output_feeds(tree)
        result = function(ctx)
        results.append(result)
        if result.preset_id in _WORKBENCH_OFF_LINE_PRESETS:
            for socket, key in feeds:
                source = _socket_from_key(tree, key)
                if source is not None:
                    nu.link_sockets(tree, source, socket)
        else:
            result.links_created += _stack_on_previous_result(tree, result, feeds)
    return results


def build_preset(preset_id: str, context=None) -> BuildResult:
    tree = nu.active_compositor_tree(context or bpy.context)
    feeds = _output_feeds(tree)
    links_before = _link_keys(tree)
    result = _build_preset_stack(preset_id, context)
    _stack_on_previous_result(tree, result, feeds)
    # The builders tally each link request, but later steps replace some of those links.
    result.links_created = len(_link_keys(tree) - links_before)
    return result


def _build_preset_stack(preset_id: str, context=None) -> BuildResult:
    key = str(preset_id or "").strip().upper()
    builder = BUILDERS.get(key)
    if builder is None:
        tree = nu.active_compositor_tree(context or bpy.context)
        settings = _settings(context)
        entries = []
        try:
            from .catalog import find_preset
            entries = list(find_preset(key))
        except Exception:
            entries = []
        title = entries[0].feature if entries else (key or "Original Tool Workbench").replace("_", " ").title()
        frame = _frame(tree, key or "CATALOG_BRIDGE", f"{t('独自ツール作業台', 'Original Tool Workbench')}: {title}", settings)
        start = len(tree.nodes)
        rlayers = _image_source(tree, frame, key or "CATALOG_BRIDGE", (-420, 80))
        reroute = nu.new_node(tree, "NodeReroute", f"SCS {title} Input", (-120, 80), frame, key)
        links = _safe_link(tree, rlayers, reroute, ("Image",), ("Input",))
        note_y = -80.0
        if entries:
            for index, entry in enumerate(entries[:6]):
                note = t(
                    f"{entry.source} / {entry.category}: {entry.feature}。{entry.summary_ja}",
                    f"{entry.source} / {entry.category}: {entry.feature}. {entry.summary_en}",
                )
                note_node = nu.add_note(tree, note, (-120, note_y), frame, key)
                note_y -= float(note_node.height) + 30.0
            if len(entries) > 6:
                note_node = nu.add_note(
                    tree,
                    t(f"同じプリセットIDに {len(entries) - 6} 件の追加カタログ項目があります。Nパネルの検索またはJSON書き出しで確認してください。",
                      f"There are {len(entries) - 6} additional catalog entries with the same preset ID. Inspect them through N-panel search or JSON export."),
                    (-120, note_y),
                    frame,
                    key,
                )
                note_y -= float(note_node.height) + 30.0
        else:
            note_node = nu.add_note(tree, t(f"SCS独自ツール項目として作業台を作成しました: {key}", f"Created an SCS original tool workbench for catalog ID: {key}"), (-120, note_y), frame, key)
            note_y -= float(note_node.height) + 30.0
        nu.add_note(
            tree,
            t("商用ソフト/プラグインの専有コード、AIモデル、OFXバイナリは含めません。機能の目的をSCS独自ノード、外部結果入力、手動調整用レーンとして再設計します。",
              "No proprietary commercial code, AI model, or OFX binary is bundled. The feature purpose is redesigned as SCS-original Blender nodes, external-result inputs, and editable adjustment lanes."),
            (-120, note_y),
            frame,
            key,
        )
        return _align_result_frame(context, BuildResult(key, t(f"独自ツール作業台を追加しました: {title}", f"Added original tool workbench: {title}"), frame.name, getattr(reroute, "name", ""), len(tree.nodes) - start, links))
    return _align_result_frame(context, builder(context))
