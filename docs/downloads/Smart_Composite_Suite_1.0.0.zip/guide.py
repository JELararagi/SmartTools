# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Compatibility wrapper for the lazy Smart Composite help system.

The active help popup implementation lives in :mod:`help`.  This file remains
only so older internal references to ``guide`` resolve to the same corrected
help catalog without reintroducing legacy preference UI.
"""

from __future__ import annotations


def show(context=None, key: str = "root") -> bool:
    from . import help as help_module

    return bool(help_module.show_tool_help(context, key))


def topics():
    from . import help as help_module

    return help_module.HELP_TOPICS


def setting_help():
    from . import help as help_module

    return help_module.SETTING_HELP


__all__ = ["show", "topics", "setting_help"]
