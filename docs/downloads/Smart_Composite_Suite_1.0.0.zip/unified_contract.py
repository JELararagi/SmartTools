# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Machine-readable SmartTools unified N-panel contract (constants only)."""

CONTRACT_VERSION = 1
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
EXTENSION_ID = "smart_composite_suite"
CONFIG_FOLDER = "Smart_Composite_Suite"
CONFIG_FILE = "Smart_Composite_Suite.json"
STATE_SAVE_PATH = "scene.scs_settings.n_panel_state_save"
SECTION_OPEN_PATH = "scene.scs_settings.show_always_on_toggles"
RUNTIME_TOGGLE_PATHS = (
    "scene.scs_settings.persistent_ui_asset_cache",
    "scene.scs_settings.persistent_auto_enable_compositor",
    "scene.scs_settings.persistent_auto_render_pass_guard",
    "scene.scs_settings.persistent_auto_precision_output_guard",
    "scene.scs_settings.persistent_auto_node_tree_sanity",
    "scene.scs_settings.persistent_live_quality_status",
)
# Smart Composite owns one visible native root per logical editor. FILES
# and ASSETS use different Blender regions and disjoint polls.
ROOT_PANEL_IDS = (
    "VIEW3D_PT_smart_composite_view_3d",
    "IMAGE_PT_smart_composite_image",
    "NODE_PT_smart_composite_compositor",
    "SEQUENCER_PT_smart_composite_video",
    "CLIP_PT_smart_composite_movie_clip",
    "DOPESHEET_PT_smart_composite_dope_sheet",
    "GRAPH_PT_smart_composite_graph",
    "NLA_PT_smart_composite_nla",
    "TEXT_PT_smart_composite_text",
    "FILEBROWSER_PT_smart_composite_file",
    "FILEBROWSER_PT_smart_composite_asset",
    "SPREADSHEET_PT_smart_composite_sheet",
)
# These five older Blender Panel IDs remain registered only as hidden,
# deterministic children. They are not category roots or Manager proxies.
COMPATIBILITY_PANEL_IDS = (
    "IMAGE_PT_smart_composite_uv",
    "NODE_PT_smart_composite_shader",
    "NODE_PT_smart_composite_geometry",
    "NODE_PT_smart_composite_texture",
    "GRAPH_PT_smart_composite_drivers",
)
PERSISTENCE_ROOTS = ("scene.scs_settings",)
EXCLUDED_TRANSIENT_PATHS = (
    "scene.scs_settings.last_message",
    "scene.scs_settings.*status*",
    "scene.scs_settings.*signature*",
    "scene.scs_settings.name",
)
