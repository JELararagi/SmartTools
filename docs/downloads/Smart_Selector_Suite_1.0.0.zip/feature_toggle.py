# SPDX-License-Identifier: GPL-3.0-or-later
"""Present stored Selector settings to the feature panel."""

_SUITE = "smart_selector_suite"


def all_feature_aliases():
    return (_SUITE,)


def feature_entries(alias=None):
    from . import always_on

    entries = []
    owner = str(alias or _SUITE).strip() or _SUITE
    for definition in always_on.feature_definitions():
        key = str(definition.get("key") or "").strip()
        if key:
            entries.append({
                **definition,
                "alias": owner,
                "feature_key": key,
                "enabled": always_on.is_feature_enabled(key, default=bool(definition.get("default"))),
            })
    return entries


def set_feature_enabled(alias, feature_key, enabled):
    from .always_on import set_feature_enabled as store_feature

    return bool(store_feature(str(feature_key or ""), bool(enabled), apply=True))
