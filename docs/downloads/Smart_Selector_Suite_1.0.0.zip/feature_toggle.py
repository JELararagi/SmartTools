# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Compatibility bridge for Smart Selector always-on feature toggles.

The editable UI remains in the N-panel. This module only exposes a small stable
API used by the common help/toggle panel so the actual toggle state stays backed
by always_on.py and its user_default JSON store.
"""

from __future__ import annotations

from typing import Any


_DEFAULT_ALIAS = 'smart_selector_suite'


def all_feature_aliases() -> tuple[str, ...]:
    return (_DEFAULT_ALIAS,)


def feature_entries(alias: str | None = None) -> list[dict[str, Any]]:
    from . import always_on

    alias_value = str(alias or _DEFAULT_ALIAS).strip() or _DEFAULT_ALIAS
    entries: list[dict[str, Any]] = []
    for item in always_on.feature_definitions():
        info = dict(item)
        key = str(info.get('key') or '').strip()
        if not key:
            continue
        info['alias'] = alias_value
        info['feature_key'] = key
        info['enabled'] = always_on.is_feature_enabled(key, default=bool(info.get('default', False)))
        entries.append(info)
    return entries


def set_feature_enabled(alias: str | None, feature_key: str, enabled: bool) -> bool:
    del alias
    from . import always_on

    return bool(always_on.set_feature_enabled(str(feature_key or ''), bool(enabled), apply=True))
