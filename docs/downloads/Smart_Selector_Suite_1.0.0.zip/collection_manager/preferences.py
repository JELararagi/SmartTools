# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

_RUNTIME_FLAG_DEFAULTS = {
    "enable_disable_objects_override": False,
    "enable_qcd": True,
    "enable_qcd_view_hotkeys": True,
    "enable_qcd_view_edit_mode_hotkeys": True,
    "enable_qcd_3dview_header_widget": True,
}

# Fixed runtime colors for the QCD popup widget. These values are local to the
# QCD GPU widget and are not exposed as UI settings. No Blender theme value is
# read or written here.
_QCD_WIDGET_COLORS = {
    "qcd_ogl_widget_tool_text": (0.86, 0.86, 0.86),
    "qcd_ogl_widget_tool_text_sel": (1.0, 1.0, 1.0),
    "qcd_ogl_widget_tool_inner": (0.20, 0.20, 0.20, 1.0),
    "qcd_ogl_widget_tool_inner_sel": (0.30, 0.43, 0.78, 1.0),
    "qcd_ogl_widget_tool_outline": (0.05, 0.05, 0.05, 1.0),
    "qcd_ogl_widget_menu_back_text": (0.90, 0.90, 0.90),
    "qcd_ogl_widget_menu_back_inner": (0.14, 0.14, 0.14, 1.0),
    "qcd_ogl_widget_menu_back_outline": (0.04, 0.04, 0.04, 1.0),
    "qcd_ogl_widget_tooltip_text": (0.92, 0.92, 0.92),
    "qcd_ogl_widget_tooltip_inner": (0.08, 0.08, 0.08, 1.0),
    "qcd_ogl_widget_tooltip_outline": (0.02, 0.02, 0.02, 1.0),
}

_RUNTIME_FLAGS = dict(_RUNTIME_FLAG_DEFAULTS)

_RUNTIME_FLAG_TO_ALWAYS_ON = {
    'enable_disable_objects_override': 'collection_manager_disable_objects_override',
    'enable_qcd': 'qcd_system',
    'enable_qcd_view_hotkeys': 'qcd_view_hotkeys',
    'enable_qcd_view_edit_mode_hotkeys': 'qcd_edit_mode_hotkeys',
    'enable_qcd_3dview_header_widget': 'qcd_header_widget',
}


def _always_on_value(name: str, default):
    feature_key = _RUNTIME_FLAG_TO_ALWAYS_ON.get(str(name or '').strip())
    if not feature_key:
        return default
    try:
        from .. import always_on
        return bool(always_on.is_feature_enabled(feature_key, default=bool(default)))
    except Exception:
        return default


def _set_always_on_value(name: str, value) -> bool:
    feature_key = _RUNTIME_FLAG_TO_ALWAYS_ON.get(str(name or '').strip())
    if not feature_key:
        return False
    try:
        from .. import always_on
        return bool(always_on.set_feature_enabled(feature_key, bool(value), apply=True))
    except Exception:
        return False


class _IntegratedRuntimePreferencesProxy:
    """Runtime-only compatibility proxy for Collection Manager options.

    It reads fixed widget colors from this module and runtime flags from the
    Smart Selector Always-on Toggles store. It never reads editable
    properties from Blender's separate preferences editor.
    """

    __slots__ = ()

    def __getattr__(self, name):
        if name in _QCD_WIDGET_COLORS:
            return _QCD_WIDGET_COLORS[name]
        if name in _RUNTIME_FLAGS:
            return _always_on_value(name, _RUNTIME_FLAGS[name])
        raise AttributeError(name)


def get_cm_preferences(context=None):
    del context
    return _IntegratedRuntimePreferencesProxy()


def set_runtime_flag(name: str, value) -> bool:
    key = str(name or '').strip()
    if key in _QCD_WIDGET_COLORS:
        return False
    if key not in _RUNTIME_FLAGS:
        return False
    default_value = _RUNTIME_FLAG_DEFAULTS.get(key)
    if isinstance(default_value, bool):
        _RUNTIME_FLAGS[key] = bool(value)
    elif isinstance(default_value, int):
        _RUNTIME_FLAGS[key] = int(value)
    elif isinstance(default_value, (tuple, list)):
        try:
            _RUNTIME_FLAGS[key] = tuple(float(v) for v in value)
        except Exception:
            _RUNTIME_FLAGS[key] = tuple(default_value)
    else:
        try:
            _RUNTIME_FLAGS[key] = float(value)
        except Exception:
            _RUNTIME_FLAGS[key] = default_value
    _set_always_on_value(key, _RUNTIME_FLAGS[key])
    return True


def get_runtime_flag(name: str, default=None):
    key = str(name or '').strip()
    if key in _QCD_WIDGET_COLORS:
        return _QCD_WIDGET_COLORS[key]
    if key in _RUNTIME_FLAGS:
        return _always_on_value(key, _RUNTIME_FLAGS.get(key))
    return default


def update_disable_objects_hotkeys_status(self, context):
    set_runtime_flag('enable_disable_objects_override', bool(self.enable_disable_objects_override))


def update_qcd_status(self, context):
    set_runtime_flag('enable_qcd', bool(self.enable_qcd))


def update_qcd_view_hotkeys_status(self, context):
    set_runtime_flag('enable_qcd_view_hotkeys', bool(self.enable_qcd_view_hotkeys))


def update_qcd_view_edit_mode_hotkeys_status(self, context):
    set_runtime_flag('enable_qcd_view_edit_mode_hotkeys', bool(self.enable_qcd_view_edit_mode_hotkeys))


def update_qcd_3dview_header_widget_status(self, context):
    set_runtime_flag('enable_qcd_3dview_header_widget', bool(self.enable_qcd_3dview_header_widget))


class CMPreferences:
    """Compatibility shell only; this class is not registered."""

    bl_idname = __package__

    def draw(self, context):
        del context
        return None
