# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Runtime options bridge for the Collection Manager tools inside Smart Selector."""

_flags = {
    "enable_disable_objects_override": ("collection_manager_disable_objects_override", False),
    "enable_qcd": ("qcd_system", True),
    "enable_qcd_view_hotkeys": ("qcd_view_hotkeys", True),
    "enable_qcd_view_edit_mode_hotkeys": ("qcd_edit_mode_hotkeys", True),
    "enable_qcd_3dview_header_widget": ("qcd_header_widget", True),
}
_local = dict((name, initial) for name, (_, initial) in _flags.items())

_palette = {f"qcd_ogl_widget_{suffix}": rgba for suffix, rgba in {
    "tool_text": (0.86, 0.86, 0.86),
    "tool_text_sel": (1.0, 1.0, 1.0),
    "tool_inner": (0.2, 0.2, 0.2, 1.0),
    "tool_inner_sel": (0.3, 0.43, 0.78, 1.0),
    "tool_outline": (0.05, 0.05, 0.05, 1.0),
    "menu_back_text": (0.9, 0.9, 0.9),
    "menu_back_inner": (0.14, 0.14, 0.14, 1.0),
    "menu_back_outline": (0.04, 0.04, 0.04, 1.0),
    "tooltip_text": (0.92, 0.92, 0.92),
    "tooltip_inner": (0.08, 0.08, 0.08, 1.0),
    "tooltip_outline": (0.02, 0.02, 0.02, 1.0),
}.items()}


class _IntegratedRuntimePreferencesProxy:
    __slots__ = ()

    def __getattr__(self, name):
        if name in _flags or name in _palette:
            return get_runtime_flag(name)
        raise AttributeError(name)


def get_cm_preferences(context=None):
    return _IntegratedRuntimePreferencesProxy()


def get_runtime_flag(name: str, default=None):
    key = str(name or "").strip()
    if key in _palette:
        return _palette[key]
    if key not in _flags:
        return default
    feature, _ = _flags[key]
    local_value = _local[key]
    try:
        from .. import always_on
        return bool(always_on.is_feature_enabled(feature, default=local_value))
    except (ImportError, AttributeError, RuntimeError, TypeError, ValueError):
        return local_value


def set_runtime_flag(name: str, value):
    key = str(name or "").strip()
    if key not in _flags:
        return False
    _local[key] = bool(value)
    try:
        from .. import always_on
        always_on.set_feature_enabled(_flags[key][0], _local[key], apply=True)
    except (ImportError, AttributeError, RuntimeError, TypeError, ValueError):
        pass
    return True


def update_disable_objects_hotkeys_status(self, context):
    set_runtime_flag("enable_disable_objects_override", self.enable_disable_objects_override)


def update_qcd_status(self, context):
    set_runtime_flag("enable_qcd", self.enable_qcd)


def update_qcd_view_hotkeys_status(self, context):
    set_runtime_flag("enable_qcd_view_hotkeys", self.enable_qcd_view_hotkeys)


def update_qcd_view_edit_mode_hotkeys_status(self, context):
    set_runtime_flag("enable_qcd_view_edit_mode_hotkeys", self.enable_qcd_view_edit_mode_hotkeys)


def update_qcd_3dview_header_widget_status(self, context):
    set_runtime_flag("enable_qcd_3dview_header_widget", self.enable_qcd_3dview_header_widget)


class CMPreferences:
    """Keep the legacy name available for code that imports Collection Manager."""
    bl_idname = __package__

    def draw(self, context):
        return None
