# Historical code in this module derives from Blender Object Collection Manager.
# SPDX-FileCopyrightText: 2011 Ryan Inch
# SPDX-License-Identifier: GPL-2.0-or-later
from . import persistent_data
import ast
from unicodedata import east_asian_width
import bpy
from bpy.types import PropertyGroup, Operator
from bpy.props import StringProperty, IntProperty
try:
    from ..translation_data import report_runtime_message as _sssuite_report
except Exception:

    def _sssuite_report(operator, report_types, message):
        try:
            operator.report(report_types, str(message or ''))
        except Exception:
            pass
move_triggered = False
move_selection = []
move_active = None
layer_collections = {}
collection_tree = []
collection_state = {}
qcd_collection_state = {}
expanded = set()
row_index = 0
max_lvl = 0
rto_history = {'exclude': {}, 'exclude_all': {}, 'select': {}, 'select_all': {}, 'hide': {}, 'hide_all': {}, 'disable': {}, 'disable_all': {}, 'render': {}, 'render_all': {}, 'holdout': {}, 'holdout_all': {}, 'indirect': {}, 'indirect_all': {}}
qcd_history = {}
expand_history = {'target': '', 'history': []}
phantom_history = {'view_layer': '', 'initial_state': {}, 'exclude_history': {}, 'select_history': {}, 'hide_history': {}, 'disable_history': {}, 'render_history': {}, 'holdout_history': {}, 'indirect_history': {}, 'exclude_all_history': [], 'select_all_history': [], 'hide_all_history': [], 'disable_all_history': [], 'render_all_history': [], 'holdout_all_history': [], 'indirect_all_history': []}
copy_buffer = {'RTO': '', 'values': []}
swap_buffer = {'A': {'RTO': '', 'values': []}, 'B': {'RTO': '', 'values': []}}

class QCDSlots:
    """QCD assignments in insertion order, shared with persisted runtime data."""

    allow_update = True
    _NUMBERED_SLOTS = tuple(map(str, range(1, 21)))

    def __init__(self):
        self._slots = persistent_data.slots
        self.overrides = persistent_data.overrides
        # A running session can still have integer keys from an earlier load.
        if any(type(key) is int for key in self._slots):
            migrated = {self._slot_key(key): label for key, label in self._slots.items()}
            self._slots.clear()
            self._slots.update(migrated)

    @staticmethod
    def _slot_key(index):
        # QCD's RNA properties and operator parameters use string slot numbers.
        return str(index) if type(index) is int else index

    def __iter__(self):
        return iter(self._slots.items())

    def __repr__(self):
        return repr(self._slots)

    def contains(self, *, idx=None, name=None):
        if not (idx or name):
            raise
        return self._slot_key(idx) in self._slots if idx else name in self._slots.values()

    def object_in_slots(self, obj):
        return any(self.contains(name=coll.name) for coll in obj.users_collection)

    def get_data_for_blend(self):
        return "\n".join((repr(self), repr(self.overrides)))

    def load_blend_data(self, data):
        assignments, separator, remaining = str(data or "").partition("\n")
        if not separator:
            return
        disabled, _, _ = remaining.partition("\n")
        try:
            raw_assignments = ast.literal_eval(assignments)
            raw_overrides = ast.literal_eval(disabled)
        except Exception:
            return

        decoded = {}
        if isinstance(raw_assignments, dict):
            for number, label in raw_assignments.items():
                try:
                    decoded[str(int(number))] = str(label)
                except Exception:
                    continue
        overrides = set()
        if isinstance(raw_overrides, (list, tuple, set)):
            for label in raw_overrides:
                try:
                    overrides.add(str(label))
                except Exception:
                    continue

        # Preserve the backing containers held by save/load and undo callers.
        self._slots.clear()
        self._slots.update(decoded)
        self.overrides.clear()
        self.overrides.update(overrides)

    def length(self):
        return len(self._slots)

    def get_idx(self, name, r_value=None):
        return next((slot for slot, label in self if label == name), r_value)

    def get_name(self, idx, r_value=None):
        return self._slots.get(self._slot_key(idx), r_value)

    def add_slot(self, idx, name):
        self._slots[self._slot_key(idx)] = name
        self.overrides.discard(name)

    def update_slot(self, idx, name):
        self.add_slot(idx, name)

    def del_slot(self, *, idx=None, name=None):
        if bool(idx) == bool(name):
            raise
        key = self._slot_key(idx) if idx else self.get_idx(name)
        del self._slots[key]

    def add_override(self, name):
        self.del_slot(name=name)
        self.overrides.add(name)

    def clear_slots(self):
        self._slots.clear()

    def update_qcd(self):
        orphan_slots = [key for key, name in self if not layer_collections.get(name)]
        for key in orphan_slots:
            del self._slots[key]

    @staticmethod
    def _layer_names(roots):
        from collections import deque

        pending = deque(roots)
        while pending:
            current = pending.popleft()
            pending.extend(current.children)
            yield current.name

    def auto_numerate(self):
        if self.length() >= len(self._NUMBERED_SLOTS):
            return
        available = iter(number for number in self._NUMBERED_SLOTS if number not in self._slots)
        existing = set(self._slots.values())
        root = bpy.context.view_layer.layer_collection
        for name in self._layer_names(root.children):
            if name in self.overrides or name in existing:
                continue
            number = next(available, None)
            if number is None:
                break
            self.add_slot(number, name)
            existing.add(name)
            if self.length() > len(self._NUMBERED_SLOTS):
                break

    @staticmethod
    def _depth_order(entries, starting_name, constrain):
        from itertools import dropwhile

        sequence = dropwhile(lambda row: row["name"] != starting_name, entries.values())
        first = next(sequence, None)
        if first is None:
            return
        yield first["name"]
        branch_parent = first["parent"]["name"] if constrain else None
        for row in sequence:
            if constrain and row["parent"]["name"] == branch_parent:
                break
            yield row["name"]

    def renumerate(self, *, beginning=False, depth_first=False, constrain=False):
        from itertools import dropwhile, islice

        roots = bpy.context.view_layer.layer_collection.children
        if not roots:
            return
        anchor = None if beginning else self.get_name("1")
        if anchor not in layer_collections:
            anchor = roots[0].name

        if depth_first:
            order = self._depth_order(layer_collections, anchor, constrain)
        else:
            parent = layer_collections[anchor]["parent"]["ptr"]
            siblings = dropwhile(lambda child: child.name != anchor, parent.children)
            order = self._layer_names(islice(siblings, 1) if constrain else siblings)

        assigned = dict(zip(self._NUMBERED_SLOTS, order))
        all_names = {row["name"] for row in layer_collections.values()}
        self.clear_slots()
        self._slots.update(assigned)
        self.overrides.clear()
        self.overrides.update(all_names.difference(assigned.values()))
qcd_slots = QCDSlots()

def update_col_name(self, context):
    global layer_collections
    global qcd_slots
    global rto_history
    global expand_history
    if self.name != self.last_name:
        if self.name == '':
            self.name = self.last_name
            return
        if self.last_name != '':
            view_layer_name = context.view_layer.name
            layer_collections[self.last_name]['ptr'].collection.name = self.name
            orig_expanded = {x for x in expanded}
            if self.last_name in orig_expanded:
                expanded.remove(self.last_name)
                expanded.add(self.name)
            idx = qcd_slots.get_idx(self.last_name)
            if idx:
                qcd_slots.update_slot(idx, self.name)
            if self.last_name in qcd_slots.overrides:
                qcd_slots.overrides.remove(self.last_name)
                qcd_slots.overrides.add(self.name)
            rtos = ['exclude', 'select', 'hide', 'disable', 'render', 'holdout', 'indirect']
            orig_targets = {rto: rto_history[rto][view_layer_name]['target'] for rto in rtos if rto_history[rto].get(view_layer_name)}
            for rto in rtos:
                history = rto_history[rto].get(view_layer_name)
                if history and orig_targets[rto] == self.last_name:
                    history['target'] = self.name
            orig_expand_target = expand_history['target']
            orig_expand_history = [x for x in expand_history['history']]
            if orig_expand_target == self.last_name:
                expand_history['target'] = self.name
            for x, name in enumerate(orig_expand_history):
                if name == self.last_name:
                    expand_history['history'][x] = self.name
            cm_list_collection = context.scene.collection_manager.cm_list_collection
            count = 0
            # Reverse-backed stack preserves the previous left-to-right DFS
            # order without repeated front insertion/removal list shifts.
            laycol_iter_list = list(reversed(list(context.view_layer.layer_collection.children)))
            while laycol_iter_list:
                layer_collection = laycol_iter_list.pop()
                cm_list_item = cm_list_collection[count]
                if cm_list_item.name != layer_collection.name:
                    if cm_list_item.last_name in orig_expanded:
                        if not cm_list_item.last_name in layer_collections:
                            expanded.remove(cm_list_item.name)
                        expanded.add(layer_collection.name)
                    idx = cm_list_item.qcd_slot_idx
                    if idx:
                        qcd_slots.update_slot(idx, layer_collection.name)
                    if cm_list_item.name in qcd_slots.overrides:
                        if not cm_list_item.name in layer_collections:
                            qcd_slots.overrides.remove(cm_list_item.name)
                        qcd_slots.overrides.add(layer_collection.name)
                    for rto in rtos:
                        history = rto_history[rto].get(view_layer_name)
                        if history and orig_targets[rto] == cm_list_item.last_name:
                            history['target'] = layer_collection.name
                    if orig_expand_target == cm_list_item.last_name:
                        expand_history['target'] = layer_collection.name
                    for x, name in enumerate(orig_expand_history):
                        if name == cm_list_item.last_name:
                            expand_history['history'][x] = layer_collection.name
                if layer_collection.children:
                    laycol_iter_list.extend(reversed(list(layer_collection.children)))
                count += 1
            update_property_group(context)
        self.last_name = self.name

def update_qcd_slot(self, context):
    global qcd_slots
    if not qcd_slots.allow_update:
        return
    update_needed = False
    try:
        int(self.qcd_slot_idx)
    except ValueError:
        if self.qcd_slot_idx == '':
            qcd_slots.add_override(self.name)
        if qcd_slots.contains(name=self.name):
            qcd_slots.allow_update = False
            self.qcd_slot_idx = qcd_slots.get_idx(self.name)
            qcd_slots.allow_update = True
        if self.name in qcd_slots.overrides:
            qcd_slots.allow_update = False
            self.qcd_slot_idx = ''
            qcd_slots.allow_update = True
        return
    if qcd_slots.contains(name=self.name):
        qcd_slots.del_slot(name=self.name)
        update_needed = True
    if qcd_slots.contains(idx=self.qcd_slot_idx):
        qcd_slots.add_override(qcd_slots.get_name(self.qcd_slot_idx))
        update_needed = True
    if int(self.qcd_slot_idx) > 20:
        self.qcd_slot_idx = '20'
    if int(self.qcd_slot_idx) < 1:
        self.qcd_slot_idx = '1'
    qcd_slots.add_slot(self.qcd_slot_idx, self.name)
    if update_needed:
        update_property_group(context)

class CMListCollection(PropertyGroup):
    name: StringProperty(update=update_col_name, description='Function: supplies the Name parameter used by the CMListCollection command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')
    last_name: StringProperty(description='Function: stores the Last Name value used by CMListCollection. How to use: change it only through the matching N-panel control or operator dialog so the add-on can keep the value synchronized.')
    qcd_slot_idx: StringProperty(name='QCD Slot', update=update_qcd_slot, description='Function: stores the QCD Slot Idx value used by CMListCollection. How to use: change it only through the matching N-panel control or operator dialog so the add-on can keep the value synchronized.')

def refresh_collection_tree(context):
    global max_lvl
    global row_index
    global collection_tree
    global layer_collections
    global qcd_slots
    collection_tree.clear()
    layer_collections.clear()
    max_lvl = 0
    row_index = 0
    layer_collection = context.view_layer.layer_collection
    init_laycol_list = layer_collection.children
    master_laycol = {'id': 0, 'name': layer_collection.name, 'lvl': -1, 'row_index': -1, 'visible': True, 'has_children': True, 'expanded': True, 'parent': None, 'children': [], 'ptr': layer_collection}
    get_all_collections(context, init_laycol_list, master_laycol, master_laycol['children'], visible=True)
    for laycol in master_laycol['children']:
        collection_tree.append(laycol)

def update_collection_tree(context, *, auto_numerate=True):
    refresh_collection_tree(context)
    qcd_slots.update_qcd()
    if auto_numerate:
        qcd_slots.auto_numerate()

def get_all_collections(context, collections, parent, tree, level=0, visible=False):
    global row_index
    global max_lvl
    if level > max_lvl:
        max_lvl = level
    for item in collections:
        laycol = {'id': len(layer_collections) + 1, 'name': item.name, 'lvl': level, 'row_index': row_index, 'visible': visible, 'has_children': False, 'expanded': False, 'parent': parent, 'children': [], 'ptr': item}
        row_index += 1
        layer_collections[item.name] = laycol
        tree.append(laycol)
        if len(item.children) > 0:
            laycol['has_children'] = True
            if item.name in expanded and laycol['visible']:
                laycol['expanded'] = True
                get_all_collections(context, item.children, laycol, laycol['children'], level + 1, visible=True)
            else:
                get_all_collections(context, item.children, laycol, laycol['children'], level + 1)

def update_property_group(context, *, auto_numerate=True):
    global collection_tree
    global qcd_slots
    qcd_slots.allow_update = False
    update_collection_tree(context, auto_numerate=auto_numerate)
    context.scene.collection_manager.cm_list_collection.clear()
    create_property_group(context, collection_tree)
    qcd_slots.allow_update = True

def create_property_group(context, tree):
    global in_filter
    global qcd_slots
    cm = context.scene.collection_manager
    for laycol in tree:
        new_cm_listitem = cm.cm_list_collection.add()
        new_cm_listitem.name = laycol['name']
        new_cm_listitem.qcd_slot_idx = qcd_slots.get_idx(laycol['name'], '')
        if laycol['has_children']:
            create_property_group(context, laycol['children'])

def get_modifiers(event):
    modifiers = []
    if event.alt:
        modifiers.append('alt')
    if event.ctrl:
        modifiers.append('ctrl')
    if event.oskey:
        modifiers.append('oskey')
    if event.shift:
        modifiers.append('shift')
    return set(modifiers)

def generate_state(*, qcd=False):
    global layer_collections
    global qcd_slots
    state = {'name': [], 'exclude': [], 'select': [], 'hide': [], 'disable': [], 'render': [], 'holdout': [], 'indirect': []}
    for name, laycol in layer_collections.items():
        state['name'].append(name)
        state['exclude'].append(laycol['ptr'].exclude)
        state['select'].append(laycol['ptr'].collection.hide_select)
        state['hide'].append(laycol['ptr'].hide_viewport)
        state['disable'].append(laycol['ptr'].collection.hide_viewport)
        state['render'].append(laycol['ptr'].collection.hide_render)
        state['holdout'].append(laycol['ptr'].holdout)
        state['indirect'].append(laycol['ptr'].indirect_only)
    if qcd:
        state['qcd'] = dict(qcd_slots)
    return state

def check_state(context, *, cm_popup=False, phantom_mode=False, qcd=False):
    view_layer = context.view_layer
    if cm_popup and collection_state:
        new_state = generate_state()
        if new_state['name'] != collection_state['name']:
            copy_buffer['RTO'] = ''
            copy_buffer['values'].clear()
            swap_buffer['A']['RTO'] = ''
            swap_buffer['A']['values'].clear()
            swap_buffer['B']['RTO'] = ''
            swap_buffer['B']['values'].clear()
            for name in list(expanded):
                laycol = layer_collections.get(name)
                if not laycol or not laycol['has_children']:
                    expanded.remove(name)
            for name in list(expand_history['history']):
                laycol = layer_collections.get(name)
                if not laycol or not laycol['has_children']:
                    expand_history['history'].remove(name)
            for rto, history in rto_history.items():
                if view_layer.name in history:
                    del history[view_layer.name]
        else:
            for rto in ['exclude', 'select', 'hide', 'disable', 'render', 'holdout', 'indirect']:
                if new_state[rto] != collection_state[rto]:
                    if view_layer.name in rto_history[rto]:
                        del rto_history[rto][view_layer.name]
                    if view_layer.name in rto_history[rto + '_all']:
                        del rto_history[rto + '_all'][view_layer.name]
    if phantom_mode:
        cm = context.scene.collection_manager
        if cm.in_phantom_mode:
            if layer_collections.keys() != phantom_history['initial_state'].keys():
                cm.in_phantom_mode = False
            if view_layer.name != phantom_history['view_layer']:
                cm.in_phantom_mode = False
            if not cm.in_phantom_mode:
                for key, value in phantom_history.items():
                    try:
                        value.clear()
                    except AttributeError:
                        if key == 'view_layer':
                            phantom_history['view_layer'] = ''
    if qcd and qcd_collection_state:
        from .qcd_operators import QCDAllBase
        new_state = generate_state(qcd=True)
        if new_state['name'] != qcd_collection_state['name'] or new_state['exclude'] != qcd_collection_state['exclude'] or new_state['qcd'] != qcd_collection_state['qcd']:
            if view_layer.name in qcd_history:
                del qcd_history[view_layer.name]
                qcd_collection_state.clear()
                QCDAllBase.clear()

def get_move_selection(*, names_only=False):
    global move_selection
    if not move_selection:
        try:
            selected = getattr(bpy.context, 'selected_objects', ()) or ()
            move_selection = {str(getattr(obj, 'name', '') or '') for obj in selected if getattr(obj, 'name', '')}
        except Exception:
            move_selection = set()
    if names_only:
        return set(move_selection)
    try:
        if len(move_selection) <= 5:
            return {bpy.data.objects[name] for name in tuple(move_selection) if name in bpy.data.objects}
        return {obj for obj in bpy.data.objects if obj.name in move_selection}
    except Exception:
        return set()

def get_move_active(*, always=False):
    global move_active
    global move_selection
    if not move_active:
        try:
            view_layer = getattr(bpy.context, 'view_layer', None)
            active = getattr(getattr(view_layer, 'objects', None), 'active', None)
            move_active = getattr(active, 'name', None)
        except Exception:
            move_active = None
    if not always and move_active not in get_move_selection(names_only=True):
        move_active = None
    try:
        return bpy.data.objects.get(move_active) if move_active else None
    except Exception:
        return None

def update_qcd_header():
    try:
        scene = getattr(bpy.context, 'scene', None)
        cm = getattr(scene, 'collection_manager', None) if scene is not None else None
        if cm is None:
            return None
        cm.update_header.clear()
        new_update_header = cm.update_header.add()
        new_update_header.name = 'updated'
    except Exception:
        pass
    return None

class CMSendReport(Operator):
    bl_label = 'Send Report'
    bl_description = 'Function: runs the Send Report command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.'
    bl_idname = 'view3d.cm_send_report'
    message: StringProperty(description='Function: supplies the Message parameter used by the CMSendReport command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        first = True
        string = ''
        for num, char in enumerate(self.message):
            if char == '\n':
                if first:
                    col.row(align=True).label(text=string, icon='ERROR')
                    first = False
                else:
                    col.row(align=True).label(text=string, icon='BLANK1')
                string = ''
                continue
            string = string + char
        if first:
            col.row(align=True).label(text=string, icon='ERROR')
        else:
            col.row(align=True).label(text=string, icon='BLANK1')

    def invoke(self, context, event):
        try:
            if bool(getattr(bpy.app, 'background', False)) or context is None or getattr(context, 'window', None) is None:
                return self.execute(context)
            wm = getattr(context, 'window_manager', None)
            if wm is None:
                return self.execute(context)
        except Exception:
            return self.execute(context)
        max_len = max(
            (sum(2 if east_asian_width(char) in {'F', 'W'} else 1 for char in line)
             for line in self.message.split('\n')),
            default=0,
        )
        try:
            return wm.invoke_popup(self, width=int(30 + max_len * 5.5))
        except Exception:
            return self.execute(context)

    def execute(self, context):
        _sssuite_report(self, {'INFO'}, self.message)
        pass
        return {'FINISHED'}

def send_report(message):

    def report():
        try:
            wm = getattr(bpy.context, 'window_manager', None)
            windows = getattr(wm, 'windows', ()) if wm is not None else ()
            window = windows[0] if windows else None
            if window is not None and hasattr(bpy.context, 'temp_override'):
                with bpy.context.temp_override(window=window, screen=window.screen):
                    bpy.ops.view3d.cm_send_report('INVOKE_DEFAULT', message=message)
            else:
                bpy.ops.view3d.cm_send_report('INVOKE_DEFAULT', message=message)
        except Exception:
            try:
                pass
            except Exception:
                pass
        return None
    try:
        bpy.app.timers.register(report, first_interval=0.0)
    except Exception:
        report()

def add_vertical_separator_line(row):
    row.separator(factor=0.4)

def get_w_kwargs(func, **kwargs):

    def wrapper_func(self):
        return func(self, **kwargs)
    return wrapper_func

def get_transform_w_kwargs(func, **kwargs):

    def wrapper_func(self, curr_value, is_set):
        return func(self, curr_value, is_set, **kwargs)
    return wrapper_func

def set_w_kwargs(func, **kwargs):

    def wrapper_func(self, values):
        func(self, values, **kwargs)
    return wrapper_func

def set_transform_w_kwargs(func, **kwargs):

    def wrapper_func(self, new_value, curr_value, is_set):
        return func(self, new_value, curr_value, is_set, **kwargs)
    return wrapper_func
