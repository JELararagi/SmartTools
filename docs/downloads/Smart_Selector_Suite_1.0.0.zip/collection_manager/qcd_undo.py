# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Atomic Blender Undo/Redo bridge for QCD view state.

LayerCollection exclusion, the active layer collection and the add-on's QCD
history are not reliably restored by Blender's ordinary global undo snapshot.
A hidden, SKIP_SAVE Scene token gives each QCD click one native undo boundary;
undo_post/redo_post then applies the complete state associated with that token.

The bridge is event-driven.  It registers no timers, depsgraph polling or draw
callbacks and is dormant when no QCD operation or Undo/Redo event is running.
"""

from __future__ import annotations

import copy
from collections import OrderedDict
from typing import Any

import bpy
from bpy.app.handlers import persistent
from bpy.props import IntProperty

from . import internals

_TOKEN_PROP = "smart_selector_qcd_undo_token"
_MAX_STATES = 256
_REGISTERED = False
_APPLY_DEPTH = 0
_NEXT_TOKEN = 0
_STATES: "OrderedDict[int, dict[str, Any]]" = OrderedDict()
_LAST_TOKEN_BY_SCENE: dict[str, int] = {}
_SAVE_TOKENS: dict[str, int] = {}


def is_applying() -> bool:
    return _APPLY_DEPTH > 0


def _scene(context=None):
    try:
        return getattr(context or bpy.context, "scene", None)
    except Exception:
        return None


def _view_layer(context=None):
    try:
        return getattr(context or bpy.context, "view_layer", None)
    except Exception:
        return None


def _walk_layer_collections(root):
    if root is None:
        return
    stack = [(root, (str(getattr(root, "name", "") or ""),))]
    while stack:
        item, path = stack.pop()
        yield item, path
        children = list(getattr(item, "children", ()) or ())
        for child in reversed(children):
            stack.append((child, path + (str(getattr(child, "name", "") or ""),)))


def _layer_collection_map(view_layer):
    root = getattr(view_layer, "layer_collection", None)
    by_path = {}
    by_name = {}
    for item, path in _walk_layer_collections(root):
        by_path[path] = item
        by_name.setdefault(str(getattr(item, "name", "") or ""), item)
    return by_path, by_name


def _active_layer_path(view_layer):
    active = getattr(view_layer, "active_layer_collection", None)
    if active is None:
        return ()
    root = getattr(view_layer, "layer_collection", None)
    for item, path in _walk_layer_collections(root):
        if item == active:
            return path
    return (str(getattr(active, "name", "") or ""),)


def _copy_qcd_collection_state():
    try:
        return copy.deepcopy(dict(internals.qcd_collection_state))
    except Exception:
        return {}


def capture(context=None) -> dict[str, Any]:
    ctx = context or getattr(bpy, "context", None)
    view_layer = _view_layer(ctx)
    scene = _scene(ctx)
    if view_layer is None or scene is None:
        return {}

    excludes = []
    root = getattr(view_layer, "layer_collection", None)
    for item, path in _walk_layer_collections(root):
        excludes.append((path, bool(getattr(item, "exclude", False))))

    selected = []
    selected_memberships = {}
    try:
        selected_objects = tuple(getattr(ctx, "selected_objects", ()) or ())
        selected = [str(obj.name) for obj in selected_objects]
        selected_memberships = {
            str(obj.name): sorted(str(collection.name) for collection in tuple(getattr(obj, "users_collection", ()) or ()))
            for obj in selected_objects
        }
    except Exception:
        selected = []
        selected_memberships = {}

    active_object = ""
    try:
        active = getattr(getattr(view_layer, "objects", None), "active", None)
        active_object = str(getattr(active, "name", "") or "")
    except Exception:
        active_object = ""

    mode = "OBJECT"
    try:
        mode = str(getattr(ctx, "mode", "OBJECT") or "OBJECT")
    except Exception:
        pass

    view_layer_name = str(getattr(view_layer, "name", "") or "")
    try:
        history = list(internals.qcd_history.get(view_layer_name, ()) or ())
    except Exception:
        history = []

    try:
        slots = dict(internals.qcd_slots)
    except Exception:
        slots = {}
    try:
        overrides = sorted(str(name) for name in set(internals.qcd_slots.overrides))
    except Exception:
        overrides = []

    return {
        "scene": str(getattr(scene, "name", "") or ""),
        "view_layer": view_layer_name,
        "exclude": excludes,
        "active_layer_path": _active_layer_path(view_layer),
        "selected_objects": selected,
        "selected_memberships": selected_memberships,
        "active_object": active_object,
        "mode": mode,
        "qcd_history": history,
        "qcd_collection_state": _copy_qcd_collection_state(),
        "qcd_slots": slots,
        "qcd_overrides": overrides,
    }


def _freeze(value):
    """Convert nested runtime state into a deterministic immutable value."""
    if isinstance(value, dict):
        return tuple(sorted((str(key), _freeze(item)) for key, item in value.items()))
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(item) for item in value)
    if isinstance(value, set):
        return tuple(sorted(_freeze(item) for item in value))
    if isinstance(value, (str, int, float, bool, type(None))):
        return value
    return repr(value)


def _semantic_state(state: dict[str, Any] | None):
    if not isinstance(state, dict):
        return ()
    return (
        tuple((tuple(path), bool(value)) for path, value in state.get("exclude", ())),
        tuple(state.get("active_layer_path", ()) or ()),
        tuple(sorted(str(name) for name in state.get("selected_objects", ()) or ())),
        tuple(sorted(
            (str(name), tuple(sorted(str(collection) for collection in collections)))
            for name, collections in dict(state.get("selected_memberships", {}) or {}).items()
        )),
        str(state.get("active_object", "") or ""),
        str(state.get("mode", "OBJECT") or "OBJECT"),
        tuple(bool(value) for value in state.get("qcd_history", ()) or ()),
        tuple(sorted((str(k), str(v)) for k, v in dict(state.get("qcd_slots", {}) or {}).items())),
        tuple(sorted(str(name) for name in state.get("qcd_overrides", ()) or ())),
        _freeze(state.get("qcd_collection_state", {}) or {}),
    )


def states_equal(a: dict[str, Any] | None, b: dict[str, Any] | None) -> bool:
    return _semantic_state(a) == _semantic_state(b)


def _set_token(scene, value: int) -> bool:
    try:
        setattr(scene, _TOKEN_PROP, int(value))
        return True
    except Exception:
        return False


def _get_token(scene) -> int:
    try:
        return int(getattr(scene, _TOKEN_PROP, 0) or 0)
    except Exception:
        return 0


def _scene_key(scene) -> str:
    try:
        uid = int(getattr(scene, "session_uid", 0) or 0)
    except Exception:
        uid = 0
    return f"{uid}:{str(getattr(scene, 'name', '') or '')}"


def _remember(token: int, state: dict[str, Any]) -> None:
    _STATES[int(token)] = copy.deepcopy(state)
    _STATES.move_to_end(int(token))
    while len(_STATES) > _MAX_STATES:
        _STATES.popitem(last=False)


def initialize(context=None) -> bool:
    """Capture the current state for the Scene's existing undo token."""
    global _NEXT_TOKEN
    scene = _scene(context)
    if scene is None or not hasattr(bpy.types.Scene, _TOKEN_PROP):
        return False
    token = _get_token(scene)
    _NEXT_TOKEN = max(_NEXT_TOKEN, token)
    _LAST_TOKEN_BY_SCENE[_scene_key(scene)] = token
    state = capture(context)
    if not state:
        return False
    _remember(token, state)
    return True


def begin(context=None) -> dict[str, Any]:
    """Return the complete state immediately before one user action."""
    return capture(context)


def commit(context, before: dict[str, Any] | None) -> bool:
    """Store pre/post states and advance the undoable Scene token once.

    Call only from an Operator that owns ``UNDO``.  Returning False means the
    operation produced no semantic change and should return CANCELLED.
    """
    global _NEXT_TOKEN
    if is_applying() or not isinstance(before, dict) or not before:
        return False
    scene = _scene(context)
    if scene is None or not hasattr(bpy.types.Scene, _TOKEN_PROP):
        return False
    after = capture(context)
    if not after or states_equal(before, after):
        return False

    old_token = _get_token(scene)
    _remember(old_token, before)
    _NEXT_TOKEN = max(_NEXT_TOKEN, old_token) + 1
    new_token = _NEXT_TOKEN
    if not _set_token(scene, new_token):
        return False
    _remember(new_token, after)
    _LAST_TOKEN_BY_SCENE[_scene_key(scene)] = new_token
    return True


def _restore_mode(context, mode: str, active_object) -> None:
    if not mode or mode == "OBJECT" or active_object is None:
        return
    mode_map = {
        "EDIT_MESH": "EDIT",
        "EDIT_CURVE": "EDIT",
        "EDIT_SURFACE": "EDIT",
        "EDIT_TEXT": "EDIT",
        "EDIT_ARMATURE": "EDIT",
        "EDIT_METABALL": "EDIT",
        "EDIT_LATTICE": "EDIT",
        "POSE": "POSE",
        "SCULPT": "SCULPT",
        "PAINT_WEIGHT": "WEIGHT_PAINT",
        "WEIGHT_PAINT": "WEIGHT_PAINT",
        "PAINT_VERTEX": "VERTEX_PAINT",
        "VERTEX_PAINT": "VERTEX_PAINT",
        "PAINT_TEXTURE": "TEXTURE_PAINT",
        "TEXTURE_PAINT": "TEXTURE_PAINT",
    }
    target = mode_map.get(str(mode), "")
    if not target:
        return
    try:
        if getattr(active_object, "mode", "OBJECT") != target:
            bpy.ops.object.mode_set(mode=target)
    except Exception:
        pass


def apply_state(state: dict[str, Any] | None, context=None) -> bool:
    global _APPLY_DEPTH
    if not isinstance(state, dict) or not state:
        return False
    ctx = context or getattr(bpy, "context", None)
    scene = _scene(ctx)
    view_layer = _view_layer(ctx)
    if scene is None or view_layer is None:
        return False
    wanted_view_layer = str(state.get("view_layer", "") or "")
    if wanted_view_layer and str(getattr(view_layer, "name", "") or "") != wanted_view_layer:
        return False

    _APPLY_DEPTH += 1
    try:
        by_path, by_name = _layer_collection_map(view_layer)
        for path, value in state.get("exclude", ()) or ():
            item = by_path.get(tuple(path))
            if item is None and path:
                item = by_name.get(str(path[-1]))
            if item is None:
                continue
            try:
                item.exclude = bool(value)
            except Exception:
                pass

        # Restore QCD slot bookkeeping before rebuilding the UI property group.
        try:
            internals.qcd_slots.clear_slots()
            internals.qcd_slots.overrides.clear()
            for key, value in dict(state.get("qcd_slots", {}) or {}).items():
                internals.qcd_slots.add_slot(str(key), str(value))
            internals.qcd_slots.overrides.update(str(name) for name in state.get("qcd_overrides", ()) or ())
        except Exception:
            pass

        view_layer_name = str(getattr(view_layer, "name", "") or "")
        try:
            history = list(state.get("qcd_history", ()) or ())
            if history:
                internals.qcd_history[view_layer_name] = history
            else:
                internals.qcd_history.pop(view_layer_name, None)
        except Exception:
            pass
        try:
            internals.qcd_collection_state.clear()
            internals.qcd_collection_state.update(copy.deepcopy(state.get("qcd_collection_state", {}) or {}))
        except Exception:
            pass

        active_path = tuple(state.get("active_layer_path", ()) or ())
        active_layer = by_path.get(active_path)
        if active_layer is None and active_path:
            active_layer = by_name.get(str(active_path[-1]))
        if active_layer is not None:
            try:
                view_layer.active_layer_collection = active_layer
            except Exception:
                pass

        # Restore collection membership for objects changed by QCD move actions.
        for object_name, collection_names in dict(state.get("selected_memberships", {}) or {}).items():
            try:
                obj = bpy.data.objects.get(str(object_name))
                if obj is None:
                    continue
                targets = [bpy.data.collections.get(str(name)) for name in collection_names]
                targets = [collection for collection in targets if collection is not None]
                if not targets:
                    continue
                for collection in targets:
                    if obj.name not in collection.objects:
                        collection.objects.link(obj)
                for collection in tuple(getattr(obj, "users_collection", ()) or ()):
                    if collection not in targets and len(tuple(getattr(obj, "users_collection", ()) or ())) > 1:
                        collection.objects.unlink(obj)
            except Exception:
                pass

        # Restore object selection only after collection visibility is restored.
        try:
            for obj in tuple(getattr(ctx, "selected_objects", ()) or ()):
                obj.select_set(False)
        except Exception:
            pass
        for name in state.get("selected_objects", ()) or ():
            try:
                obj = bpy.data.objects.get(str(name))
                if obj is not None and obj.name in view_layer.objects:
                    obj.select_set(True)
            except Exception:
                pass

        active_object = None
        try:
            active_name = str(state.get("active_object", "") or "")
            active_object = bpy.data.objects.get(active_name) if active_name else None
            if active_object is not None and active_object.name in view_layer.objects:
                view_layer.objects.active = active_object
            elif active_object is None:
                view_layer.objects.active = None
        except Exception:
            active_object = None

        _restore_mode(ctx, str(state.get("mode", "OBJECT") or "OBJECT"), active_object)

        try:
            from .internals import update_property_group
            update_property_group(ctx, auto_numerate=False)
        except Exception:
            pass
        try:
            from .internals import update_qcd_header
            update_qcd_header()
        except Exception:
            pass
        return True
    finally:
        _APPLY_DEPTH = max(0, _APPLY_DEPTH - 1)


def apply_current(context=None) -> bool:
    scene = _scene(context)
    if scene is None:
        return False
    token = _get_token(scene)
    key = _scene_key(scene)
    if _LAST_TOKEN_BY_SCENE.get(key) == token:
        return False
    applied = apply_state(_STATES.get(token), context)
    if applied:
        _LAST_TOKEN_BY_SCENE[key] = token
    return applied


@persistent
def undo_post_handler(*_args):
    try:
        apply_current(getattr(bpy, "context", None))
    except Exception:
        pass


@persistent
def redo_post_handler(*_args):
    try:
        apply_current(getattr(bpy, "context", None))
    except Exception:
        pass


@persistent
def save_pre_handler(*_args):
    """Temporarily zero the undo token so runtime history is never serialized."""
    _SAVE_TOKENS.clear()
    for scene in tuple(getattr(bpy.data, "scenes", ()) or ()):
        if not hasattr(bpy.types.Scene, _TOKEN_PROP):
            break
        key = _scene_key(scene)
        token = _get_token(scene)
        _SAVE_TOKENS[key] = token
        try:
            setattr(scene, _TOKEN_PROP, 0)
        except Exception:
            pass


@persistent
def save_post_handler(*_args):
    """Restore in-memory undo tokens after Blender finishes saving."""
    if not hasattr(bpy.types.Scene, _TOKEN_PROP):
        _SAVE_TOKENS.clear()
        return
    for scene in tuple(getattr(bpy.data, "scenes", ()) or ()):
        key = _scene_key(scene)
        if key not in _SAVE_TOKENS:
            continue
        try:
            setattr(scene, _TOKEN_PROP, int(_SAVE_TOKENS[key]))
        except Exception:
            pass
    _SAVE_TOKENS.clear()


@persistent
def load_pre_handler(*_args):
    _SAVE_TOKENS.clear()
    clear_runtime(reset_scene_token=False)


def _append_once(handler_list, callback) -> None:
    if handler_list is None:
        return
    try:
        if callback not in handler_list:
            handler_list.append(callback)
    except Exception:
        pass


def _remove_all(handler_list, callback) -> None:
    if handler_list is None:
        return
    try:
        while callback in handler_list:
            handler_list.remove(callback)
    except Exception:
        pass


def register() -> None:
    global _REGISTERED
    if _REGISTERED:
        initialize(getattr(bpy, "context", None))
        return
    if not hasattr(bpy.types.Scene, _TOKEN_PROP):
        setattr(
            bpy.types.Scene,
            _TOKEN_PROP,
            IntProperty(
                name="QCD Undo State",
                description="Internal Smart Selector QCD undo state",
                default=0,
                options={"HIDDEN", "SKIP_SAVE"},
            ),
        )
    _append_once(getattr(bpy.app.handlers, "undo_post", None), undo_post_handler)
    _append_once(getattr(bpy.app.handlers, "redo_post", None), redo_post_handler)
    _append_once(getattr(bpy.app.handlers, "save_pre", None), save_pre_handler)
    _append_once(getattr(bpy.app.handlers, "save_post", None), save_post_handler)
    _append_once(getattr(bpy.app.handlers, "load_pre", None), load_pre_handler)
    _REGISTERED = True
    initialize(getattr(bpy, "context", None))


def clear_runtime(*, reset_scene_token: bool = True) -> None:
    global _NEXT_TOKEN
    _STATES.clear()
    _LAST_TOKEN_BY_SCENE.clear()
    _SAVE_TOKENS.clear()
    _NEXT_TOKEN = 0
    if reset_scene_token:
        scene = _scene(getattr(bpy, "context", None))
        if scene is not None and hasattr(bpy.types.Scene, _TOKEN_PROP):
            try:
                setattr(scene, _TOKEN_PROP, 0)
            except Exception:
                pass


def unregister() -> None:
    global _REGISTERED
    _remove_all(getattr(bpy.app.handlers, "undo_post", None), undo_post_handler)
    _remove_all(getattr(bpy.app.handlers, "redo_post", None), redo_post_handler)
    _remove_all(getattr(bpy.app.handlers, "save_pre", None), save_pre_handler)
    _remove_all(getattr(bpy.app.handlers, "save_post", None), save_post_handler)
    _remove_all(getattr(bpy.app.handlers, "load_pre", None), load_pre_handler)
    clear_runtime(reset_scene_token=True)
    if hasattr(bpy.types.Scene, _TOKEN_PROP):
        try:
            delattr(bpy.types.Scene, _TOKEN_PROP)
        except Exception:
            pass
    _REGISTERED = False


def snapshot() -> dict[str, Any]:
    return {
        "registered": bool(_REGISTERED),
        "applying": int(_APPLY_DEPTH),
        "next_token": int(_NEXT_TOKEN),
        "state_tokens": list(_STATES.keys()),
        "state_count": len(_STATES),
        "last_tokens": dict(_LAST_TOKEN_BY_SCENE),
        "save_tokens": dict(_SAVE_TOKENS),
    }
