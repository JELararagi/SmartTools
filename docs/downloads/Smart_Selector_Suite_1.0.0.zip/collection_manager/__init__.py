# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

if "bpy" in locals():
    import importlib

    importlib.reload(cm_init)
    importlib.reload(internals)
    importlib.reload(operator_utils)
    importlib.reload(operators)
    importlib.reload(qcd_move_widget)
    importlib.reload(qcd_operators)
    importlib.reload(ui)
    importlib.reload(qcd_init)
    importlib.reload(preferences)

else:
    from . import cm_init
    from . import internals
    from . import operator_utils
    from . import operators
    from . import qcd_move_widget
    from . import qcd_operators
    from . import ui
    from . import qcd_init
    from . import preferences

import bpy

_DEFERRED_UNREGISTER_PENDING = False
_DEFERRED_UNREGISTER_RUNNING = False


def _popup_active() -> bool:
    try:
        cls = getattr(ui, 'CollectionManager', None)
        return bool(
            cls is not None
            and (
                int(getattr(cls, 'active_popup_count', 0) or 0) > 0
                or bool(getattr(cls, 'window_open', False))
            )
        )
    except Exception:
        return False


def _unregister_now() -> None:
    global _DEFERRED_UNREGISTER_PENDING, _DEFERRED_UNREGISTER_RUNNING
    _DEFERRED_UNREGISTER_PENDING = False
    _DEFERRED_UNREGISTER_RUNNING = False
    qcd_init.unregister_qcd()
    cm_init.unregister_cm()


def _deferred_unregister_tick():
    global _DEFERRED_UNREGISTER_RUNNING
    if not _DEFERRED_UNREGISTER_PENDING:
        _DEFERRED_UNREGISTER_RUNNING = False
        return None
    if _popup_active():
        return 0.10
    try:
        _unregister_now()
    finally:
        _DEFERRED_UNREGISTER_RUNNING = False
    return None


def register():
    global _DEFERRED_UNREGISTER_PENDING
    _DEFERRED_UNREGISTER_PENDING = False
    cm_init.register_cm()

    if preferences.get_cm_preferences(getattr(bpy, 'context', None)).enable_qcd:
        qcd_init.register_qcd()


def unregister():
    global _DEFERRED_UNREGISTER_PENDING, _DEFERRED_UNREGISTER_RUNNING
    if _popup_active():
        # Blender 5.1 must not unregister an Operator/UIList/PropertyGroup class
        # while an invoke_popup owner is still alive.  Defer only for the popup
        # lifetime; the timer stops immediately after execute/cancel/destruction.
        _DEFERRED_UNREGISTER_PENDING = True
        if not _DEFERRED_UNREGISTER_RUNNING:
            _DEFERRED_UNREGISTER_RUNNING = True
            try:
                bpy.app.timers.register(_deferred_unregister_tick, first_interval=0.10)
            except Exception:
                _DEFERRED_UNREGISTER_RUNNING = False
        return
    _unregister_now()


if __name__ == "__main__":
    register()
