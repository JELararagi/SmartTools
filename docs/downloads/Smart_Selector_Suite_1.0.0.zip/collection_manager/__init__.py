# Copyright (C) 2026 JELararagi
# Historical attribution for this package entry point: 2011 Ryan Inch.
# SPDX-FileCopyrightText: 2011 Ryan Inch
# SPDX-License-Identifier: GPL-2.0-or-later
# Source history: blender/blender-addons object_collection_manager at
# de26298989520dc7114966f5788ad711fa4d3f62.

from importlib import import_module, reload

import bpy


# The suite loader reloads this package during on-demand activation. Keep its
# component refresh sequence stable for registration and existing class caches.
_COMPONENTS = (
    "cm_init", "internals", "operator_utils", "operators", "qcd_move_widget",
    "qcd_operators", "ui", "qcd_init", "preferences",
)
refresh = globals().get("_package_loaded", False)
for component in _COMPONENTS:
    module = import_module(f".{component}", __package__)
    globals()[component] = reload(module) if refresh else module
_package_loaded = True
del component, module, refresh


class PopupShutdown:
    """Own at most one timer while a Collection Manager popup keeps RNA alive."""

    interval = 0.10

    def __init__(self, popup_type, teardown, timers):
        self.popup_type = popup_type
        self.teardown = teardown
        self.timers = timers
        self.requested = False
        self.callback = self.poll

    def popup_is_open(self):
        try:
            operator = self.popup_type()
            return bool(operator.window_open or int(operator.active_popup_count or 0) > 0)
        except Exception:
            return False

    def cancel(self):
        self.requested = False

    def request(self):
        self.requested = True
        if not self.popup_is_open():
            self.poll()
            return
        try:
            if not self.timers.is_registered(self.callback):
                self.timers.register(self.callback, first_interval=self.interval)
        except Exception:
            # Leave the request pending so the next disable can retry scheduling.
            pass

    def poll(self):
        if self.requested:
            if self.popup_is_open():
                return self.interval
            self.cancel()
            self.teardown()
        return None


def _remove_components():
    # QCD callbacks refer to Collection Manager RNA during cleanup.
    qcd_init.unregister_qcd()
    cm_init.unregister_cm()


_previous_shutdown = globals().get("_shutdown")
if _previous_shutdown is not None:
    _previous_shutdown.cancel()
del _previous_shutdown
_shutdown = PopupShutdown(lambda: ui.CollectionManager, _remove_components, bpy.app.timers)


def register():
    _shutdown.cancel()
    cm_init.register_cm()
    settings = preferences.get_cm_preferences(getattr(bpy, "context", None))
    if settings.enable_qcd:
        qcd_init.register_qcd()


def unregister():
    _shutdown.request()


if __name__ == "__main__":
    register()

