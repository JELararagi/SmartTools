# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

if "bpy" in locals():
    import importlib

    importlib.reload(internals)
    importlib.reload(operator_utils)
    importlib.reload(operators)
    importlib.reload(ui)
    importlib.reload(preferences)

else:
    from . import internals
    from . import operator_utils
    from . import operators
    from . import ui
    from . import preferences

import bpy
from .. import settings as _sssuite_settings
from ..translation import localize_class as _i18n_localize_class, operator_label as _i18n_operator_label
from bpy.app.handlers import persistent
from bpy.types import PropertyGroup
from bpy.props import (
    CollectionProperty,
    EnumProperty,
    IntProperty,
    BoolProperty,
    StringProperty,
    PointerProperty,
    )


def _sssuite_get_bool_setting(key: str, default: bool = False) -> bool:
    return bool(_sssuite_settings.get_value(key, bool(default)))


def _sssuite_set_bool_setting(key: str, value) -> None:
    _sssuite_settings.set_value(key, bool(value))


def _sssuite_bool_getter(key: str, default: bool = False):
    return lambda _self: _sssuite_get_bool_setting(key, default)


def _sssuite_bool_setter(key: str):
    return lambda _self, value: _sssuite_set_bool_setting(key, value)


def _sssuite_get_setting(key: str, default=None):
    return _sssuite_settings.get_value(key, default)


def _sssuite_set_setting(key: str, value) -> None:
    _sssuite_settings.set_value(key, value)


def _sssuite_getter(key: str, default=None, cast=None):
    def _get(_self):
        value = _sssuite_get_setting(key, default)
        if cast is None:
            return value
        try:
            return cast(value)
        except Exception:
            return cast(default)
    return _get


def _sssuite_setter(key: str, cast=None):
    def _set(_self, value):
        if cast is not None:
            try:
                value = cast(value)
            except Exception:
                pass
        _sssuite_set_setting(key, value)
    return _set


class CollectionManagerProperties(PropertyGroup):
    cm_list_collection: CollectionProperty(type=internals.CMListCollection, description='Function: stores Collection manager List Collection runtime data used by this tool. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.')
    cm_list_index: IntProperty(get=_sssuite_getter('cm_list_index', 0, int), set=_sssuite_setter('cm_list_index', int), description='Function: stores the Collection manager List Index value used by this tool. How to use: change it only through the matching N-panel control or operator dialog so the add-on can keep the value synchronized.')

    show_exclude: BoolProperty(name="[EC] Exclude from View Layer", get=_sssuite_bool_getter('cm_show_exclude', True), set=_sssuite_bool_setter('cm_show_exclude'), description='Function: controls the Collection Manager Exclude from View Layer column. How to use: toggle it in the N-panel to show or hide that control column; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.')
    show_selectable: BoolProperty(name="[SS] Disable Selection", get=_sssuite_bool_getter('cm_show_selectable', True), set=_sssuite_bool_setter('cm_show_selectable'), description='Function: controls the Collection Manager Disable Selection column. How to use: toggle it in the N-panel to show or hide that control column; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.')
    show_hide_viewport: BoolProperty(name="[VV] Hide in Viewport", get=_sssuite_bool_getter('cm_show_hide_viewport', True), set=_sssuite_bool_setter('cm_show_hide_viewport'), description='Function: controls the Collection Manager Hide in Viewport column. How to use: toggle it in the N-panel to show or hide that control column; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.')
    show_disable_viewport: BoolProperty(name="[DV] Disable in Viewports", get=_sssuite_bool_getter('cm_show_disable_viewport', False), set=_sssuite_bool_setter('cm_show_disable_viewport'), description='Function: controls the Collection Manager Disable in Viewports column. How to use: toggle it in the N-panel to show or hide that control column; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.')
    show_render: BoolProperty(name="[RR] Disable in Renders", get=_sssuite_bool_getter('cm_show_render', False), set=_sssuite_bool_setter('cm_show_render'), description='Function: controls the Collection Manager Disable in Renders column. How to use: toggle it in the N-panel to show or hide that control column; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.')
    show_holdout: BoolProperty(name="[HH] Holdout", get=_sssuite_bool_getter('cm_show_holdout', False), set=_sssuite_bool_setter('cm_show_holdout'), description='Function: controls the Collection Manager Holdout column. How to use: toggle it in the N-panel to show or hide that control column; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.')
    show_indirect_only: BoolProperty(name="[IO] Indirect Only", get=_sssuite_bool_getter('cm_show_indirect_only', False), set=_sssuite_bool_setter('cm_show_indirect_only'), description='Function: controls the Collection Manager Indirect Only column. How to use: toggle it in the N-panel to show or hide that control column; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.')

    align_local_ops: BoolProperty(name="Align Local Options",
                                  description="Function: aligns local Collection Manager option buttons in a right-side column. How to use: toggle this in the Collection Manager N-panel or popup when you want local row controls visually separated; the choice is saved according to N-panel State Save and restored after Blender restarts or scene changes.",
                                  get=_sssuite_bool_getter('cm_align_local_ops', False),
                                  set=_sssuite_bool_setter('cm_align_local_ops'))

    in_phantom_mode: BoolProperty(get=_sssuite_getter('in_phantom_mode', False, bool), set=_sssuite_setter('in_phantom_mode', bool), description='Function: stores the In Phantom Mode value used by this tool. How to use: change it only through the matching N-panel control or operator dialog so the add-on can keep the value synchronized.')

    update_header: CollectionProperty(type=internals.CMListCollection, description='Function: stores Update Header runtime data used by this tool. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.')

    ui_separator: StringProperty(name="", get=_sssuite_getter('ui_separator', '', str), set=_sssuite_setter('ui_separator', str), description='Function: stores the UI Separator value used by this tool. How to use: change it only through the matching N-panel control or operator dialog so the add-on can keep the value synchronized.')

    qcd_slots_blend_data: StringProperty(get=_sssuite_getter('qcd_slots_blend_data', '', str), set=_sssuite_setter('qcd_slots_blend_data', str), description='Function: stores the QCD Slots Blend Data value used by this tool. How to use: change it only through the matching N-panel control or operator dialog so the add-on can keep the value synchronized.')


addon_keymaps = []
addon_disable_objects_hotkey_keymaps = []


def _safe_register_class(cls):
    existing = getattr(bpy.types, getattr(cls, '__name__', ''), None)
    if isinstance(existing, type):
        try:
            bpy.utils.unregister_class(existing)
        except Exception:
            pass
    bpy.utils.register_class(_i18n_localize_class(cls))


def _safe_unregister_class(cls):
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


def _safe_draw_append(container, callback, *, prepend=False):
    try:
        container.remove(callback)
    except Exception:
        pass
    try:
        if prepend and hasattr(container, 'prepend'):
            container.prepend(callback)
        else:
            container.append(callback)
    except Exception:
        pass


def _safe_draw_remove(container, callback):
    try:
        container.remove(callback)
    except Exception:
        pass


def _safe_handler_append(handler_list, callback):
    try:
        if callback in handler_list:
            handler_list.remove(callback)
    except Exception:
        try:
            handler_list.remove(callback)
        except Exception:
            pass
    try:
        handler_list.append(callback)
    except Exception:
        pass


def _safe_handler_remove(handler_list, callback):
    try:
        if callback in handler_list:
            handler_list.remove(callback)
            return
    except Exception:
        pass
    try:
        handler_list.remove(callback)
    except Exception:
        pass


def _addon_keymaps_collection():
    wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    kc = getattr(getattr(wm, 'keyconfigs', None), 'addon', None)
    return getattr(kc, 'keymaps', None)


def _prune_empty_addon_keymaps(*names):
    keymaps = _addon_keymaps_collection()
    if keymaps is None:
        return
    normalized = tuple(str(name or '').strip() for name in names if str(name or '').strip())
    removed = 0
    finder = getattr(keymaps, 'find', None)
    getter = getattr(keymaps, 'get', None)
    for target_name in normalized:
        for _attempt in range(16):
            km = None
            if callable(getter):
                try:
                    km = getter(target_name)
                except Exception:
                    km = None
            if km is None and callable(finder):
                for call in (
                    lambda: finder(target_name),
                    lambda: finder(name=target_name),
                    lambda: finder(name=target_name, space_type='EMPTY', region_type='WINDOW'),
                ):
                    try:
                        km = call()
                    except Exception:
                        km = None
                    if km is not None:
                        break
            if km is None:
                break
            try:
                item_count = len(getattr(km, 'keymap_items', ()) or ())
            except Exception:
                item_count = 0
            if item_count:
                break
            try:
                keymaps.remove(km)
                removed += 1
            except Exception:
                break
    if removed:
        return
    wanted = {name.lower() for name in normalized}
    stale = []
    try:
        iterable = tuple(keymaps)
    except Exception:
        iterable = ()
    for km in iterable:
        try:
            name = str(getattr(km, 'name', '') or '').strip()
        except Exception:
            name = ''
        if wanted and name.lower() not in wanted:
            continue
        try:
            item_count = len(getattr(km, 'keymap_items', ()) or ())
        except Exception:
            item_count = 0
        if item_count:
            continue
        stale.append(km)
    for km in stale:
        try:
            keymaps.remove(km)
        except Exception:
            pass


def _new_addon_keymap_item(name: str, operator_id: str, key: str, value: str, **mods):
    keymaps = _addon_keymaps_collection()
    if keymaps is None:
        return None, None
    km = keymaps.new(name=name)
    try:
        kmi = km.keymap_items.new(operator_id, key, value, **mods)
    except Exception:
        try:
            if not len(getattr(km, 'keymap_items', ()) or ()):
                keymaps.remove(km)
        except Exception:
            pass
        raise
    return km, kmi

classes = (
    internals.CMListCollection,
    internals.CMSendReport,
    operators.SetActiveCollection,
    operators.ExpandAllOperator,
    operators.ExpandSublevelOperator,
    operators.CMExcludeOperator,
    operators.CMUnExcludeAllOperator,
    operators.CMRestrictSelectOperator,
    operators.CMUnRestrictSelectAllOperator,
    operators.CMHideOperator,
    operators.CMUnHideAllOperator,
    operators.CMDisableViewportOperator,
    operators.CMUnDisableViewportAllOperator,
    operators.CMDisableRenderOperator,
    operators.CMUnDisableRenderAllOperator,
    operators.CMHoldoutOperator,
    operators.CMUnHoldoutAllOperator,
    operators.CMIndirectOnlyOperator,
    operators.CMUnIndirectOnlyAllOperator,
    operators.CMNewCollectionOperator,
    operators.CMRemoveCollectionOperator,
    operators.CMRemoveEmptyCollectionsOperator,
    operators.CMSelectCollectionObjectsOperator,
    operators.SelectAllCumulativeObjectsOperator,
    operators.CMSendObjectsToCollectionOperator,
    operators.CMPhantomModeOperator,
    operators.CMApplyPhantomModeOperator,
    operators.CMDisableObjectsOperator,
    operators.CMDisableUnSelectedObjectsOperator,
    operators.CMRestoreDisabledObjectsOperator,
    operators.CMUndoWrapper,
    operators.CMRedoWrapper,
    ui.CM_UL_items,
    ui.CollectionManager,
    ui.CMDisplayOptionsPanel,
    ui.SpecialsMenu,
    CollectionManagerProperties,
    )


@persistent
def depsgraph_update_post_handler(*args):
    try:
        if internals.move_triggered:
            internals.move_triggered = False
            return
        internals.move_selection.clear()
        internals.move_active = None
    except Exception:
        pass

@persistent
def undo_redo_post_handler(*args):
    try:
        internals.move_selection.clear()
        internals.move_active = None
    except Exception:
        pass


@persistent
def global_load_pre_handler(*args):
    try:
        internals.move_triggered = False
        internals.move_selection.clear()
        internals.move_active = None
    except Exception:
        pass


def menu_addition(self, context):
    layout = self.layout

    layout.operator('view3d.collection_manager', text=_i18n_operator_label('view3d.collection_manager'))

    if preferences.get_cm_preferences(getattr(bpy, 'context', None)).enable_qcd:
        layout.operator('view3d.qcd_move_widget', text=_i18n_operator_label('view3d.qcd_move_widget'))

    layout.separator()

def disable_objects_menu_addition(self, context):
    addon_prefs = preferences.get_cm_preferences(getattr(bpy, 'context', None))
    if addon_prefs.enable_disable_objects_override:
        layout = self.layout
        layout.separator()
        layout.operator('view3d.disable_selected_objects', text=_i18n_operator_label('view3d.disable_selected_objects'))
        layout.operator('view3d.disable_unselected_objects', text=_i18n_operator_label('view3d.disable_unselected_objects'))
        layout.operator('view3d.restore_disabled_objects', text=_i18n_operator_label('view3d.restore_disabled_objects'))


def register_disable_objects_hotkeys():
    if addon_disable_objects_hotkey_keymaps:
        # guard to handle default value updates (mouse hover + backspace)
        return

    keymaps = _addon_keymaps_collection()
    if keymaps is not None: # not present when started with --background
        km, kmi = _new_addon_keymap_item('Object Mode', 'view3d.disable_selected_objects', 'H', 'PRESS')
        if km is not None and kmi is not None:
            addon_disable_objects_hotkey_keymaps.append((km, kmi))

        km, kmi = _new_addon_keymap_item('Object Mode', 'view3d.disable_unselected_objects', 'H', 'PRESS', shift=True)
        if km is not None and kmi is not None:
            addon_disable_objects_hotkey_keymaps.append((km, kmi))

        km, kmi = _new_addon_keymap_item('Object Mode', 'view3d.restore_disabled_objects', 'H', 'PRESS', alt=True)
        if km is not None and kmi is not None:
            addon_disable_objects_hotkey_keymaps.append((km, kmi))

def unregister_disable_objects_hotkeys():
    # remove keymaps when disable objects hotkeys are deactivated
    for km, kmi in addon_disable_objects_hotkey_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_disable_objects_hotkey_keymaps.clear()
    _prune_empty_addon_keymaps('Object Mode')


def _always_enabled(feature_key: str, default: bool = True) -> bool:
    try:
        from .. import always_on
        return bool(always_on.is_feature_enabled(feature_key, default=default))
    except Exception:
        return bool(default)


def _safe_bpy_type(name: str):
    try:
        return getattr(bpy.types, str(name or ''), None)
    except Exception:
        return None

def _safe_handler_list(name: str):
    try:
        return getattr(bpy.app.handlers, str(name or ''), None)
    except Exception:
        return None

def register_collection_manager_popup_hotkey():
    if addon_keymaps:
        return
    keymaps = _addon_keymaps_collection()
    if keymaps is not None:
        km, kmi = _new_addon_keymap_item('Object Mode', 'view3d.collection_manager', 'M', 'PRESS')
        if km is not None and kmi is not None:
            addon_keymaps.append((km, kmi))


def unregister_collection_manager_popup_hotkey():
    for km, kmi in addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_keymaps.clear()
    _prune_empty_addon_keymaps('Object Mode')


def register_collection_manager_object_menu():
    _safe_draw_append(_safe_bpy_type('VIEW3D_MT_object_collection'), menu_addition, prepend=True)


def unregister_collection_manager_object_menu():
    _safe_draw_remove(_safe_bpy_type('VIEW3D_MT_object_collection'), menu_addition)


def register_disable_objects_override():
    _safe_draw_append(_safe_bpy_type('VIEW3D_MT_object_showhide'), disable_objects_menu_addition)
    register_disable_objects_hotkeys()


def unregister_disable_objects_override():
    unregister_disable_objects_hotkeys()
    _safe_draw_remove(_safe_bpy_type('VIEW3D_MT_object_showhide'), disable_objects_menu_addition)


def register_collection_manager_state_handlers():
    _safe_handler_append(_safe_handler_list('depsgraph_update_post'), depsgraph_update_post_handler)
    _safe_handler_append(_safe_handler_list('undo_post'), undo_redo_post_handler)
    _safe_handler_append(_safe_handler_list('redo_post'), undo_redo_post_handler)
    _safe_handler_append(_safe_handler_list('load_pre'), global_load_pre_handler)


def unregister_collection_manager_state_handlers():
    _safe_handler_remove(_safe_handler_list('depsgraph_update_post'), depsgraph_update_post_handler)
    _safe_handler_remove(_safe_handler_list('undo_post'), undo_redo_post_handler)
    _safe_handler_remove(_safe_handler_list('redo_post'), undo_redo_post_handler)
    _safe_handler_remove(_safe_handler_list('load_pre'), global_load_pre_handler)


def register_cm():
    for cls in classes:
        _safe_register_class(cls)

    try:
        if hasattr(bpy.types.Scene, 'collection_manager'):
            del bpy.types.Scene.collection_manager
    except Exception:
        pass
    bpy.types.Scene.collection_manager = PointerProperty(type=CollectionManagerProperties, description='Function: stores Collection Manager runtime data used by Smart Selector storage. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.')

    if _always_enabled('collection_manager_popup_hotkey', False):
        register_collection_manager_popup_hotkey()

    if _always_enabled('collection_manager_object_menu', False):
        register_collection_manager_object_menu()

    if _always_enabled('collection_manager_state_handlers', False):
        register_collection_manager_state_handlers()

    if _always_enabled('collection_manager_disable_objects_override', False):
        register_disable_objects_override()
    else:
        unregister_disable_objects_override()


def unregister_cm():
    unregister_disable_objects_override()
    unregister_collection_manager_popup_hotkey()
    unregister_collection_manager_object_menu()
    unregister_collection_manager_state_handlers()

    for cls in reversed(classes):
        _safe_unregister_class(cls)

    try:
        if hasattr(bpy.types.Scene, 'collection_manager'):
            del bpy.types.Scene.collection_manager
    except Exception:
        pass
