# SPDX-License-Identifier: GPL-3.0-or-later
"""Session-local QCD state shared by the collection management operators."""

slots: dict = {}
overrides: set = set()
