# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

# QCD
slots = {}
overrides = set()
