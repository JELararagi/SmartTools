# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import time

import bpy

from bpy.types import (
    Menu,
    Operator,
    Panel,
    UIList,
)

from bpy.props import (
    BoolProperty,
    StringProperty,
)

# For VARS
from . import internals
from . import preferences
from .. import settings as _sssuite_settings
from ..translation import operator_label as _cm_operator_label, t as _cm_text

# For FUNCTIONS
from .internals import (
    update_collection_tree,
    update_property_group,
    generate_state,
    check_state,
    get_move_selection,
    get_move_active,
    update_qcd_header,
    add_vertical_separator_line,
)

preview_collections = {}
last_icon_theme_text = None
last_icon_theme_text_sel = None
_QCD_HEADER_CACHE = {'view_layer': '', 'last_refresh': 0.0}
_QCD_HEADER_MIN_REFRESH = 0.20


class _SSS_DummyUIOperator:
    def __setattr__(self, _name, _value):
        return None
    def __getattr__(self, _name):
        return ''


def _safe_icon_string(icon: str, fallback: str = 'NONE') -> str:
    value = str(icon or fallback or 'NONE').strip() or 'NONE'
    return value if value.upper() != 'NONE' else 'NONE'


def _operator_with_icon(layout, operator_id: str, *args, text=None, icon='NONE', **kwargs):
    """Draw operator buttons defensively for Blender 5.1 UI redraws."""
    icon = str(icon or 'NONE')
    if text is None:
        text = _cm_operator_label(operator_id)
    call_kwargs = dict(kwargs)
    icon_token = icon.strip().upper()
    has_icon = icon_token not in {'', 'NONE', 'BLANK1'}
    if text is not None and str(text or '') == '' and has_icon and call_kwargs.get('emboss') is False:
        call_kwargs.pop('emboss', None)
    try:
        explicit_icon_value = int(call_kwargs.pop('icon_value', 0) or 0)
    except Exception:
        explicit_icon_value = 0
    if explicit_icon_value > 0:
        icon_kwargs = {'icon_value': explicit_icon_value}
    else:
        try:
            from .. import icons as _sssuite_icons
            icon_kwargs = dict(_sssuite_icons.kwargs_for_blender_icon(icon, icon))
        except Exception:
            icon_kwargs = {'icon': icon}
    try:
        if text is None:
            return layout.operator(operator_id, *args, **icon_kwargs, **call_kwargs)
        return layout.operator(operator_id, *args, text=text, **icon_kwargs, **call_kwargs)
    except Exception:
        pass
    try:
        if text is None:
            return layout.operator(operator_id, *args, icon=_safe_icon_string(icon), **call_kwargs)
        return layout.operator(operator_id, *args, text=text, icon=_safe_icon_string(icon), **call_kwargs)
    except Exception:
        pass
    try:
        if text is None:
            return layout.operator(operator_id, *args, icon='NONE', **call_kwargs)
        return layout.operator(operator_id, *args, text=text, icon='NONE', **call_kwargs)
    except Exception:
        try:
            layout.label(text=str(text or '') if text is not None else '', icon='ERROR')
        except Exception:
            pass
        return _SSS_DummyUIOperator()


def _prop_with_icon(layout, data, property_name: str, *args, text=None, icon='NONE', **kwargs):
    """Draw property buttons/toggles defensively for Blender 5.1 UI redraws."""
    icon = str(icon or 'NONE')
    call_kwargs = dict(kwargs)
    try:
        explicit_icon_value = int(call_kwargs.pop('icon_value', 0) or 0)
    except Exception:
        explicit_icon_value = 0
    if explicit_icon_value > 0:
        icon_kwargs = {'icon_value': explicit_icon_value}
    else:
        try:
            from .. import icons as _sssuite_icons
            icon_kwargs = dict(_sssuite_icons.kwargs_for_blender_icon(icon, icon))
        except Exception:
            icon_kwargs = {'icon': icon}
    try:
        if text is None:
            return layout.prop(data, property_name, *args, **icon_kwargs, **call_kwargs)
        return layout.prop(data, property_name, *args, text=text, **icon_kwargs, **call_kwargs)
    except Exception:
        pass
    try:
        if text is None:
            return layout.prop(data, property_name, *args, icon=_safe_icon_string(icon), **call_kwargs)
        return layout.prop(data, property_name, *args, text=text, icon=_safe_icon_string(icon), **call_kwargs)
    except Exception:
        pass
    try:
        if text is None:
            return layout.prop(data, property_name, *args, icon='NONE', **call_kwargs)
        return layout.prop(data, property_name, *args, text=text, icon='NONE', **call_kwargs)
    except Exception:
        return None


def _can_invoke_blender_ui(context) -> bool:
    try:
        if bool(getattr(bpy.app, 'background', False)):
            return False
        if context is None:
            return False
        if getattr(context, 'window_manager', None) is None:
            return False
        if getattr(context, 'window', None) is None:
            return False
        return True
    except Exception:
        return False

def _sssuite_get_string_setting(key: str, default: str = '') -> str:
    return str(_sssuite_settings.get_value(key, str(default)) or '')


def _sssuite_set_string_setting(key: str, value) -> None:
    _sssuite_settings.set_value(key, str(value if value is not None else ''))


def _sssuite_get_bool_setting(key: str, default: bool = False) -> bool:
    return bool(_sssuite_settings.get_value(key, bool(default)))


def _sssuite_set_bool_setting(key: str, value) -> None:
    _sssuite_settings.set_value(key, bool(value))


def _sssuite_string_getter(key: str, default: str = ''):
    return lambda _self: _sssuite_get_string_setting(key, default)


def _sssuite_string_setter(key: str):
    return lambda _self, value: _sssuite_set_string_setting(key, value)


def _sssuite_bool_getter(key: str, default: bool = False):
    return lambda _self: _sssuite_get_bool_setting(key, default)


def _sssuite_bool_setter(key: str):
    return lambda _self, value: _sssuite_set_bool_setting(key, value)


class _QCDIconColor:
    __slots__ = ('r', 'g', 'b', 'hsv')

    def __init__(self, r, g, b):
        self.r = float(r)
        self.g = float(g)
        self.b = float(b)
        self.hsv = (self.r, self.g, self.b)


_QCD_ICON_TEXT_COLOR = _QCDIconColor(0.86, 0.86, 0.86)
_QCD_ICON_TEXT_SELECTED_COLOR = _QCDIconColor(1.0, 1.0, 1.0)


def _safe_register_timer(callback, *, first_interval=0.1):
    try:
        timers = getattr(bpy.app, 'timers', None)
        if timers is None:
            return
        if hasattr(timers, 'is_registered') and timers.is_registered(callback):
            return
        timers.register(callback, first_interval=first_interval)
    except Exception:
        pass


class CollectionManager(Operator):
    '''Manage and control collections, with advanced features, in a popup UI'''
    bl_label = "Collection Manager"
    # Opening/closing the manager is UI-only.  The child collection operators
    # own their actual scene edits and Undo records.
    bl_options = {'INTERNAL'}
    _sms_no_undo = True
    bl_description = 'Function: Manage and control collections, with advanced features, in a popup UI. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_idname = "view3d.collection_manager"

    last_view_layer = ""

    # Keep a Python-only active-owner count so add-on teardown can defer RNA
    # unregistration until Blender has closed every popup.  This avoids
    # invalidating a live wmOperator pointer (a Blender 5.1 crash condition).
    window_open = False
    active_popup_count = 0

    master_collection: StringProperty(
        default='Scene Collection',
        name="",
        description='Function: identifies the master scene collection row in Collection Manager. How to use: this label is managed automatically and marks the top of the collection tree.'
        )

    @classmethod
    def poll(cls, context):
        try:
            scene = getattr(context, 'scene', None) if context is not None else None
            view_layer = getattr(context, 'view_layer', None) if context is not None else None
            return bool(_can_invoke_blender_ui(context) and scene is not None and view_layer is not None and hasattr(scene, 'collection_manager'))
        except Exception:
            return False

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.window_open = False
        self._cm_popup_counted = False

    def _mark_popup_open(self):
        if getattr(self, '_cm_popup_counted', False):
            return
        self._cm_popup_counted = True
        self.window_open = True
        cls = type(self)
        cls.active_popup_count = max(0, int(getattr(cls, 'active_popup_count', 0))) + 1
        cls.window_open = True

    def draw(self, context):
        cls = CollectionManager
        layout = self.layout
        try:
            scene = getattr(context, 'scene', None) if context is not None else None
            view_layer = getattr(context, 'view_layer', None) if context is not None else None
            if scene is None or view_layer is None or not hasattr(scene, 'collection_manager'):
                layout.label(text=_cm_text('Collection Manager is not available in the current context.', '現在のコンテキストではコレクションマネージャーを使用できません。'), icon='ERROR')
                return
            cm = scene.collection_manager
            prefs = preferences.get_cm_preferences(context)
            layer_collection = getattr(view_layer, 'layer_collection', None)
            collection = getattr(layer_collection, 'collection', None)
            if collection is None:
                layout.label(text=_cm_text('View layer collection is not available.', 'ビュー レイヤーのコレクションを取得できません。'), icon='ERROR')
                return
        except Exception:
            layout.label(text=_cm_text('Collection Manager draw was skipped for safety.', '安全のためコレクションマネージャーの描画をスキップしました。'), icon='ERROR')
            return

        # title and view layer
        title_row = layout.split(factor=0.5)
        main = title_row.row()
        view = title_row.row(align=True)
        view.alignment = 'RIGHT'

        main.label(text=_cm_text("Collection Manager", "コレクションマネージャー"))
        _cm_help_button(main, 'collection_manager')

        view.prop(view_layer, "use", text="")
        view.separator()

        window = context.window
        scene = window.scene
        view.template_search(
            window, "view_layer",
            scene, "view_layers",
            new="scene.view_layer_add",
            unlink="scene.view_layer_remove")

        layout.row().separator()
        layout.row().separator()

        # buttons
        button_row_1 = layout.row()

        op_sec = button_row_1.row()
        op_sec.alignment = 'LEFT'

        collapse_sec = op_sec.row()
        collapse_sec.alignment = 'LEFT'
        collapse_sec.enabled = True

        if len(internals.expanded) > 0:
            text = _cm_text("Collapse All Items", "全項目を折りたたむ")
        else:
            text = _cm_text("Expand All Items", "全項目を展開")

        _operator_with_icon(collapse_sec, "view3d.expand_all_items", text=text)

        for laycol in internals.collection_tree:
            if laycol["has_children"]:
                collapse_sec.enabled = True
                break

        if prefs.enable_qcd:
            renum_sec = op_sec.row()
            renum_sec.alignment = 'LEFT'
            _operator_with_icon(renum_sec, "view3d.renumerate_qcd_slots")

        undo_sec = op_sec.row(align=True)
        undo_sec.alignment = 'LEFT'
        _operator_with_icon(undo_sec, "view3d.undo_wrapper", text="", icon='LOOP_BACK')
        _operator_with_icon(undo_sec, "view3d.redo_wrapper", text="", icon='LOOP_FORWARDS')

        # menu & filter
        right_sec = button_row_1.row()
        right_sec.alignment = 'RIGHT'

        specials_menu = right_sec.row()
        specials_menu.alignment = 'RIGHT'
        specials_menu.menu("VIEW3D_MT_CM_specials_menu")

        display_options = right_sec.row()
        display_options.alignment = 'RIGHT'
        display_options.popover(panel="COLLECTIONMANAGER_PT_display_options",
                           text="", icon='FILTER')

        mc_box = layout.box()
        master_collection_row = mc_box.row(align=True)

        # collection icon
        c_icon = master_collection_row.row()
        highlight = False
        if (context.view_layer.active_layer_collection ==
            context.view_layer.layer_collection):
                highlight = True

        prop = _operator_with_icon(c_icon, "view3d.set_active_collection",
                                              text='', icon='GROUP', depress=highlight)
        prop.is_master_collection = True
        prop.collection_name = 'Scene Collection'

        master_collection_row.separator()

        # name
        name_row = master_collection_row.row(align=True)
        name_field = name_row.row(align=True)
        name_field.prop(self, "master_collection", text='')
        name_field.enabled = True

        # set selection
        setsel = name_row.row(align=True)
        icon = 'DOT'
        some_selected = False

        if not collection.objects:
            icon = 'BLANK1'
            setsel.active = True

        else:
            all_selected = None
            all_unreachable = None

            for obj in collection.objects:
                if not obj.visible_get() or obj.hide_select:
                    if all_unreachable != False:
                        all_unreachable = True

                else:
                    all_unreachable = False

                if obj.select_get() == False:
                    # some objects remain unselected
                    icon = 'KEYFRAME'
                    all_selected = False

                else:
                    some_selected = True

                    if all_selected == False:
                        break

                    all_selected = True


            if all_selected:
                # all objects are selected
                icon = 'KEYFRAME_HLT'

            if all_unreachable:
                if collection.objects:
                    icon = 'DOT'

                setsel.active = True

        prop = _operator_with_icon(setsel, "view3d.select_collection_objects",
                                   text="",
                                   icon=icon,
                                   depress=some_selected,
                                   )
        prop.is_master_collection = True
        prop.collection_name = 'Scene Collection'


        # global rtos
        global_rto_row = master_collection_row.row()
        global_rto_row.alignment = 'RIGHT'

        # used as a separator (actual separator not wide enough)
        global_rto_row.label()


        # set collection
        row_setcol = global_rto_row.row()
        row_setcol.alignment = 'LEFT'
        row_setcol.operator_context = 'INVOKE_DEFAULT'

        selected_objects = get_move_selection()
        active_object = get_move_active()
        CM_UL_items.selected_objects = selected_objects
        CM_UL_items.active_object = active_object

        collection = context.view_layer.layer_collection.collection

        icon = 'IMPORT'

        if collection.objects:
            icon = 'MESH_CUBE'

        if selected_objects:
            if active_object and active_object.name in collection.objects:
                icon = 'SNAP_VOLUME'

            elif not selected_objects.isdisjoint(collection.objects):
                icon = 'STICKY_UVS_LOC'

        else:
            row_setcol.active = True


        add_vertical_separator_line(row_setcol)

        # add operator
        prop = _operator_with_icon(row_setcol, "view3d.send_objects_to_collection", text="",
                                   icon=icon)
        prop.is_master_collection = True
        prop.collection_name = 'Scene Collection'

        add_vertical_separator_line(row_setcol)

        copy_icon = 'COPYDOWN'
        swap_icon = 'ARROW_LEFTRIGHT'
        copy_swap_icon = 'SELECT_INTERSECT'

        if cm.show_exclude:
            exclude_all_history = internals.rto_history["exclude_all"].get(view_layer.name, [])
            depress = True if len(exclude_all_history) else False
            icon = 'CHECKBOX_HLT'
            buffers = [False, False]

            if internals.copy_buffer["RTO"] == "exclude":
                icon = copy_icon
                buffers[0] = True

            if internals.swap_buffer["A"]["RTO"] == "exclude":
                icon = swap_icon
                buffers[1] = True

            if buffers[0] and buffers[1]:
                icon = copy_swap_icon

            _operator_with_icon(global_rto_row, "view3d.un_exclude_all_collections", text="", icon=icon, depress=depress)

        if cm.show_selectable:
            select_all_history = internals.rto_history["select_all"].get(view_layer.name, [])
            depress = True if len(select_all_history) else False
            icon = 'RESTRICT_SELECT_OFF'
            buffers = [False, False]

            if internals.copy_buffer["RTO"] == "select":
                icon = copy_icon
                buffers[0] = True

            if internals.swap_buffer["A"]["RTO"] == "select":
                icon = swap_icon
                buffers[1] = True

            if buffers[0] and buffers[1]:
                icon = copy_swap_icon

            _operator_with_icon(global_rto_row, "view3d.un_restrict_select_all_collections", text="", icon=icon, depress=depress)

        if cm.show_hide_viewport:
            hide_all_history = internals.rto_history["hide_all"].get(view_layer.name, [])
            depress = True if len(hide_all_history) else False
            icon = 'HIDE_OFF'
            buffers = [False, False]

            if internals.copy_buffer["RTO"] == "hide":
                icon = copy_icon
                buffers[0] = True

            if internals.swap_buffer["A"]["RTO"] == "hide":
                icon = swap_icon
                buffers[1] = True

            if buffers[0] and buffers[1]:
                icon = copy_swap_icon

            _operator_with_icon(global_rto_row, "view3d.un_hide_all_collections", text="", icon=icon, depress=depress)

        if cm.show_disable_viewport:
            disable_all_history = internals.rto_history["disable_all"].get(view_layer.name, [])
            depress = True if len(disable_all_history) else False
            icon = 'RESTRICT_VIEW_OFF'
            buffers = [False, False]

            if internals.copy_buffer["RTO"] == "disable":
                icon = copy_icon
                buffers[0] = True

            if internals.swap_buffer["A"]["RTO"] == "disable":
                icon = swap_icon
                buffers[1] = True

            if buffers[0] and buffers[1]:
                icon = copy_swap_icon

            _operator_with_icon(global_rto_row, "view3d.un_disable_viewport_all_collections", text="", icon=icon, depress=depress)

        if cm.show_render:
            render_all_history = internals.rto_history["render_all"].get(view_layer.name, [])
            depress = True if len(render_all_history) else False
            icon = 'RESTRICT_RENDER_OFF'
            buffers = [False, False]

            if internals.copy_buffer["RTO"] == "render":
                icon = copy_icon
                buffers[0] = True

            if internals.swap_buffer["A"]["RTO"] == "render":
                icon = swap_icon
                buffers[1] = True

            if buffers[0] and buffers[1]:
                icon = copy_swap_icon

            _operator_with_icon(global_rto_row, "view3d.un_disable_render_all_collections", text="", icon=icon, depress=depress)

        if cm.show_holdout:
            holdout_all_history = internals.rto_history["holdout_all"].get(view_layer.name, [])
            depress = True if len(holdout_all_history) else False
            icon = 'HOLDOUT_ON'
            buffers = [False, False]

            if internals.copy_buffer["RTO"] == "holdout":
                icon = copy_icon
                buffers[0] = True

            if internals.swap_buffer["A"]["RTO"] == "holdout":
                icon = swap_icon
                buffers[1] = True

            if buffers[0] and buffers[1]:
                icon = copy_swap_icon

            _operator_with_icon(global_rto_row, "view3d.un_holdout_all_collections", text="", icon=icon, depress=depress)

        if cm.show_indirect_only:
            indirect_all_history = internals.rto_history["indirect_all"].get(view_layer.name, [])
            depress = True if len(indirect_all_history) else False
            icon = 'INDIRECT_ONLY_ON'
            buffers = [False, False]

            if internals.copy_buffer["RTO"] == "indirect":
                icon = copy_icon
                buffers[0] = True

            if internals.swap_buffer["A"]["RTO"] == "indirect":
                icon = swap_icon
                buffers[1] = True

            if buffers[0] and buffers[1]:
                icon = copy_swap_icon

            _operator_with_icon(global_rto_row, "view3d.un_indirect_only_all_collections", text="", icon=icon, depress=depress)

        # treeview
        layout.row().template_list("CM_UL_items", "",
                                   cm, "cm_list_collection",
                                   cm, "cm_list_index",
                                   rows=15,
                                   sort_lock=True)

        # add collections
        button_row_2 = layout.row()
        prop = _operator_with_icon(button_row_2, "view3d.add_collection", text=_cm_text("Add Collection", "コレクションを追加"),
                               icon='COLLECTION_NEW')
        prop.child = False

        prop = _operator_with_icon(button_row_2, "view3d.add_collection", text=_cm_text("Add SubCollection", "サブコレクションを追加"),
                               icon='COLLECTION_NEW')
        prop.child = True


        button_row_3 = layout.row()

        # phantom mode
        phantom_mode = button_row_3.row(align=True)
        toggle_text = _cm_text("Disable Phantom Mode", "ファントムモードを無効化") if cm.in_phantom_mode else _cm_text("Enable Phantom Mode", "ファントムモードを有効化")
        _operator_with_icon(phantom_mode, "view3d.toggle_phantom_mode", text=toggle_text)
        _operator_with_icon(phantom_mode, "view3d.apply_phantom_mode", text="", icon='CHECKMARK')

        if cm.in_phantom_mode:
            view.enabled = True

            if prefs.enable_qcd:
                renum_sec.enabled = True

            undo_sec.enabled = True
            specials_menu.enabled = True

            c_icon.enabled = True
            row_setcol.enabled = True
            button_row_2.enabled = True


    def _prepare_popup(self, context):
        try:
            wm = getattr(context, 'window_manager', None)
            scene = getattr(context, 'scene', None)
            view_layer = getattr(context, 'view_layer', None)
            if wm is None or scene is None or view_layer is None or not hasattr(scene, 'collection_manager'):
                return None, None
            if not _can_invoke_blender_ui(context):
                return None, None
            update_property_group(context)
            cm = scene.collection_manager
            self.view_layer = view_layer.name
            if cm.cm_list_index >= len(cm.cm_list_collection):
                cm.cm_list_index = -1
            check_state(context, cm_popup=True, phantom_mode=True)
        except Exception:
            return None, None

        max_width = 960
        min_width = 456
        row_indent_width = 15
        width_step = 21
        qcd_width = 30
        scrollbar_width = 21
        width = min_width + row_indent_width + (width_step * internals.max_lvl)
        try:
            prefs = preferences.get_cm_preferences(context)
            if bool(getattr(prefs, 'enable_qcd', False)):
                width += qcd_width
        except Exception:
            pass
        if len(internals.layer_collections) > 14:
            width += scrollbar_width
        return wm, min(width, max_width)

    def _finish_popup(self, *, store_state=True):
        """Finish one popup owner while its RNA is still valid."""
        counted = bool(getattr(self, '_cm_popup_counted', False))
        self._cm_popup_counted = False
        self.window_open = False
        cls = type(self)
        if counted:
            cls.active_popup_count = max(0, int(getattr(cls, 'active_popup_count', 0)) - 1)
        cls.window_open = bool(getattr(cls, 'active_popup_count', 0))
        if not counted or not store_state:
            return
        try:
            state = generate_state()
            if isinstance(state, dict):
                internals.collection_state.clear()
                internals.collection_state.update(state)
        except Exception:
            pass

    def invoke(self, context, event):
        del event
        wm, width = self._prepare_popup(context)
        if wm is None or width is None:
            self.window_open = False
            return {'CANCELLED'}
        self.master_collection = _cm_text('Scene Collection')
        try:
            self._mark_popup_open()
            result = wm.invoke_popup(self, width=width)
            if 'RUNNING_MODAL' not in set(result or ()):
                self._finish_popup(store_state=False)
            return result
        except Exception:
            self._finish_popup(store_state=False)
            return {'CANCELLED'}

    def execute(self, context):
        del context
        self._finish_popup()
        return {'FINISHED'}

    def cancel(self, context):
        del context
        self._finish_popup()

    def __del__(self):
        # Python destructors can run after Blender has already invalidated RNA
        # during add-on reload or application shutdown.  Update Python-only
        # ownership counters, but never access bpy data here.
        try:
            self._finish_popup(store_state=False)
        except Exception:
            pass


class CM_UL_items(UIList):
    filtering = False
    last_filter_value = ""

    selected_objects = set()
    active_object = None

    visible_items = []
    new_collections = []

    filter_name: StringProperty(
                        name="Filter By Name",
                        description="Function: filters Collection Manager rows by collection name. How to use: type part of a collection name in the filter field to narrow the visible collection list; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.",
                        get=_sssuite_string_getter('cm_filter_name', ''),
                        set=_sssuite_string_setter('cm_filter_name'),
                        update=lambda self, context:
                            CM_UL_items.new_collections.clear(),
                        )

    use_filter_invert: BoolProperty(
                        name="Invert",
                        description="Function: inverts the current Collection Manager filter result. How to use: enable this after entering a filter when you want to show the collections that would normally be hidden; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.",
                        get=_sssuite_bool_getter('cm_use_filter_invert', False),
                        set=_sssuite_bool_setter('cm_use_filter_invert'),
                        )

    filter_by_selected: BoolProperty(
                        name="Filter By Selected",
                        description="Function: filters the Collection Manager list to collections that contain the currently selected objects. How to use: select objects in the scene, then enable this filter to focus on their collections; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.",
                        get=_sssuite_bool_getter('cm_filter_by_selected', False),
                        set=_sssuite_bool_setter('cm_filter_by_selected'),
                        update=lambda self, context:
                            CM_UL_items.new_collections.clear(),
                        )
    filter_by_qcd: BoolProperty(
                        name="Filter By QCD",
                        description="Function: filters the Collection Manager list to collections assigned to QCD slots. How to use: enable this when you want to work only with QCD-managed collections; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.",
                        get=_sssuite_bool_getter('cm_filter_by_qcd', False),
                        set=_sssuite_bool_setter('cm_filter_by_qcd'),
                        update=lambda self, context:
                            CM_UL_items.new_collections.clear(),
                        )

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        try:
            scene = getattr(context, 'scene', None) if context is not None else None
            item_name = str(getattr(item, 'name', '') or '')
            if scene is None or not hasattr(scene, 'collection_manager'):
                layout.label(text=item_name, icon='OUTLINER_COLLECTION', translate=False)
                return
            if not item_name or item_name not in internals.layer_collections:
                layout.label(text=item_name, icon='OUTLINER_COLLECTION', translate=False)
                return
            return self._draw_item_impl(context, layout, data, item, icon, active_data, active_propname, index)
        except Exception:
            try:
                layout.label(text=str(getattr(item, 'name', '') or ''), icon='ERROR', translate=False)
            except Exception:
                pass
            return

    def _draw_item_impl(self, context, layout, data, item, icon, active_data, active_propname, index):
        self.use_filter_show = True

        cm = context.scene.collection_manager
        prefs = preferences.get_cm_preferences(context)
        view_layer = context.view_layer
        laycol = internals.layer_collections[item.name]
        collection = laycol["ptr"].collection
        selected_objects = CM_UL_items.selected_objects
        active_object = CM_UL_items.active_object

        column = layout.column(align=True)

        main_row = column.row()

        s1 = main_row.row(align=True)
        s1.alignment = 'LEFT'

        s2 = main_row.row(align=True)
        s2.alignment = 'RIGHT'

        row = s1

        # allow room to select the row from the beginning
        row.separator()

        # indent child items
        if laycol["lvl"] > 0:
            for _ in range(laycol["lvl"]):
                row.label(icon='BLANK1')

        # add expander if collection has children to make UIList act like tree view
        if laycol["has_children"]:
            if laycol["expanded"]:
                highlight = True if internals.expand_history["target"] == item.name else False

                prop = _operator_with_icon(row, "view3d.expand_sublevel", text="",
                                    icon='DISCLOSURE_TRI_DOWN',
                                    emboss=highlight, depress=highlight)
                prop.expand = False
                prop.name = item.name
                prop.index = index

            else:
                highlight = True if internals.expand_history["target"] == item.name else False

                prop = _operator_with_icon(row, "view3d.expand_sublevel", text="",
                                    icon='DISCLOSURE_TRI_RIGHT',
                                    emboss=highlight, depress=highlight)
                prop.expand = True
                prop.name = item.name
                prop.index = index

        else:
            row.label(icon='BLANK1')


        # collection icon
        c_icon = row.row()
        highlight = False
        if (context.view_layer.active_layer_collection == laycol["ptr"]):
                highlight = True

        prop = _operator_with_icon(c_icon, "view3d.set_active_collection", text='', icon='GROUP',
                                              emboss=highlight, depress=highlight)

        prop.is_master_collection = False
        prop.collection_name = item.name

        if prefs.enable_qcd:
            QCD = row.row()
            QCD.scale_x = 0.4
            QCD.prop(item, "qcd_slot_idx", text="")

        # collection name
        c_name = row.row(align=True)

        #if rename[0] and index == cm.cm_list_index:
            #c_name.activate_init = True
            #rename[0] = False

        c_name.prop(item, "name", text="", expand=True)

        # set selection
        setsel = c_name.row(align=True)
        icon = 'DOT'
        some_selected = False

        if not collection.objects:
            icon = 'BLANK1'
            setsel.active = True

        if any((laycol["ptr"].exclude,
               collection.hide_select,
               collection.hide_viewport,
               laycol["ptr"].hide_viewport,)):
            # objects cannot be selected
            setsel.active = True

        else:
            all_selected = None
            all_unreachable = None

            for obj in collection.objects:
                if not obj.visible_get() or obj.hide_select:
                    if all_unreachable != False:
                        all_unreachable = True

                else:
                    all_unreachable = False

                if obj.select_get() == False:
                    # some objects remain unselected
                    icon = 'KEYFRAME'
                    all_selected = False

                else:
                    some_selected = True

                    if all_selected == False:
                        break

                    all_selected = True


            if all_selected:
                # all objects are selected
                icon = 'KEYFRAME_HLT'

            if all_unreachable:
                if collection.objects:
                    icon = 'DOT'

                setsel.active = True


        prop = _operator_with_icon(setsel, "view3d.select_collection_objects",
                                   text="",
                                   icon=icon,
                                   depress=some_selected
                                   )
        prop.is_master_collection = False
        prop.collection_name = item.name

        # used as a separator (actual separator not wide enough)
        row.label()

        row = s2 if cm.align_local_ops else s1


        add_vertical_separator_line(row)


        # add send_objects_to_collection op
        set_obj_col = row.row()
        set_obj_col.operator_context = 'INVOKE_DEFAULT'

        icon = 'IMPORT'

        if collection.objects:
            icon = 'MESH_CUBE'

        if selected_objects:
            if active_object and active_object.name in collection.objects:
                icon = 'SNAP_VOLUME'

            elif not selected_objects.isdisjoint(collection.objects):
                icon = 'STICKY_UVS_LOC'

        else:
            set_obj_col.enabled = True


        prop = _operator_with_icon(set_obj_col, "view3d.send_objects_to_collection", text="",
                                   icon=icon)
        prop.is_master_collection = False
        prop.collection_name = item.name

        add_vertical_separator_line(row)


        if cm.show_exclude:
            exclude_history_base = internals.rto_history["exclude"].get(view_layer.name, {})
            exclude_target = exclude_history_base.get("target", "")
            exclude_history = exclude_history_base.get("history", [])

            highlight = bool(exclude_history and exclude_target == item.name)
            icon = 'CHECKBOX_DEHLT' if laycol["ptr"].exclude else 'CHECKBOX_HLT'

            prop = _operator_with_icon(row, "view3d.exclude_collection", text="", icon=icon,
                         emboss=highlight, depress=highlight)
            prop.name = item.name

        if cm.show_selectable:
            select_history_base = internals.rto_history["select"].get(view_layer.name, {})
            select_target = select_history_base.get("target", "")
            select_history = select_history_base.get("history", [])

            highlight = bool(select_history and select_target == item.name)
            icon = ('RESTRICT_SELECT_ON' if laycol["ptr"].collection.hide_select else
                    'RESTRICT_SELECT_OFF')

            prop = _operator_with_icon(row, "view3d.restrict_select_collection", text="", icon=icon,
                         emboss=highlight, depress=highlight)
            prop.name = item.name

        if cm.show_hide_viewport:
            hide_history_base = internals.rto_history["hide"].get(view_layer.name, {})
            hide_target = hide_history_base.get("target", "")
            hide_history = hide_history_base.get("history", [])

            highlight = bool(hide_history and hide_target == item.name)
            icon = 'HIDE_ON' if laycol["ptr"].hide_viewport else 'HIDE_OFF'

            prop = _operator_with_icon(row, "view3d.hide_collection", text="", icon=icon,
                         emboss=highlight, depress=highlight)
            prop.name = item.name

        if cm.show_disable_viewport:
            disable_history_base = internals.rto_history["disable"].get(view_layer.name, {})
            disable_target = disable_history_base.get("target", "")
            disable_history = disable_history_base.get("history", [])

            highlight = bool(disable_history and disable_target == item.name)
            icon = ('RESTRICT_VIEW_ON' if laycol["ptr"].collection.hide_viewport else
                    'RESTRICT_VIEW_OFF')

            prop = _operator_with_icon(row, "view3d.disable_viewport_collection", text="", icon=icon,
                         emboss=highlight, depress=highlight)
            prop.name = item.name

        if cm.show_render:
            render_history_base = internals.rto_history["render"].get(view_layer.name, {})
            render_target = render_history_base.get("target", "")
            render_history = render_history_base.get("history", [])

            highlight = bool(render_history and render_target == item.name)
            icon = ('RESTRICT_RENDER_ON' if laycol["ptr"].collection.hide_render else
                    'RESTRICT_RENDER_OFF')

            prop = _operator_with_icon(row, "view3d.disable_render_collection", text="", icon=icon,
                         emboss=highlight, depress=highlight)
            prop.name = item.name

        if cm.show_holdout:
            holdout_history_base = internals.rto_history["holdout"].get(view_layer.name, {})
            holdout_target = holdout_history_base.get("target", "")
            holdout_history = holdout_history_base.get("history", [])

            highlight = bool(holdout_history and holdout_target == item.name)
            icon = ('HOLDOUT_ON' if laycol["ptr"].holdout else
                    'HOLDOUT_OFF')

            prop = _operator_with_icon(row, "view3d.holdout_collection", text="", icon=icon,
                         emboss=highlight, depress=highlight)
            prop.name = item.name

        if cm.show_indirect_only:
            indirect_history_base = internals.rto_history["indirect"].get(view_layer.name, {})
            indirect_target = indirect_history_base.get("target", "")
            indirect_history = indirect_history_base.get("history", [])

            highlight = bool(indirect_history and indirect_target == item.name)
            icon = ('INDIRECT_ONLY_ON' if laycol["ptr"].indirect_only else
                    'INDIRECT_ONLY_OFF')

            prop = _operator_with_icon(row, "view3d.indirect_only_collection", text="", icon=icon,
                         emboss=highlight, depress=highlight)
            prop.name = item.name


        row = s2

        row.separator()
        row.separator()

        rm_op = row.row()
        prop = _operator_with_icon(rm_op, "view3d.remove_collection", text="", icon='X')
        prop.collection_name = item.name


        if len(data.cm_list_collection) > index + 1:
            line_separator = column.row(align=True)
            line_separator.ui_units_y = 0.01
            line_separator.scale_y = 0.1
            line_separator.enabled = True

            line_separator.separator()
            line_separator.label(icon='BLANK1')

            for _ in range(laycol["lvl"] + 1):
                line_separator.label(icon='BLANK1')

            line_separator.prop(cm, "ui_separator")

        if cm.in_phantom_mode:
            c_icon.enabled = True
            c_name.enabled = True
            set_obj_col.enabled = True
            rm_op.enabled = True

            if prefs.enable_qcd:
                QCD.enabled = True


    def draw_filter(self, context, layout):
        row = layout.row()

        subrow = row.row(align=True)
        subrow.prop(self, "filter_name", text="")
        _prop_with_icon(subrow, self, "use_filter_invert", text="", icon='ARROW_LEFTRIGHT')

        subrow = row.row(align=True)
        _prop_with_icon(subrow, self, "filter_by_selected", text="", icon='STICKY_UVS_LOC')

        try:
            prefs = preferences.get_cm_preferences(context)
            enable_qcd = bool(getattr(prefs, 'enable_qcd', False))
        except Exception:
            enable_qcd = False
        if enable_qcd:
            _prop_with_icon(subrow, self, "filter_by_qcd", text="", icon='EVENT_Q')

    def filter_items(self, context, data, propname):
        CM_UL_items.filtering = False

        flt_flags = []
        flt_neworder = []
        try:
            list_items = getattr(data, propname)
        except Exception:
            return [], []
        try:
            selected_objects = set(getattr(context, 'selected_objects', []) or [])
        except Exception:
            selected_objects = set()


        if self.filter_name:
            CM_UL_items.filtering = True

            new_flt_flags = filter_items_by_name_custom(self.filter_name, self.bitflag_filter_item, list_items)

            flt_flags = merge_flt_flags(flt_flags, new_flt_flags)


        if self.filter_by_selected:
            CM_UL_items.filtering = True
            new_flt_flags = [0] * len(list_items)

            for idx, item in enumerate(list_items):
                laycol_info = internals.layer_collections.get(item.name)
                collection = getattr(getattr(laycol_info, "ptr", None), "collection", None) if laycol_info else None
                if collection is None and isinstance(laycol_info, dict):
                    collection = getattr(laycol_info.get("ptr"), "collection", None)

                # check if any of the selected objects are in the collection
                try:
                    if collection is not None and not selected_objects.isdisjoint(collection.objects):
                        new_flt_flags[idx] = self.bitflag_filter_item
                except Exception:
                    pass

                # add in any recently created collections
                if item.name in CM_UL_items.new_collections:
                    new_flt_flags[idx] = self.bitflag_filter_item

            flt_flags = merge_flt_flags(flt_flags, new_flt_flags)


        if self.filter_by_qcd:
            CM_UL_items.filtering = True
            new_flt_flags = [0] * len(list_items)

            for idx, item in enumerate(list_items):
                if item.qcd_slot_idx:
                    new_flt_flags[idx] = self.bitflag_filter_item

                # add in any recently created collections
                if item.name in CM_UL_items.new_collections:
                    new_flt_flags[idx] = self.bitflag_filter_item

            flt_flags = merge_flt_flags(flt_flags, new_flt_flags)


        if not CM_UL_items.filtering: # display as treeview
            CM_UL_items.new_collections.clear()
            flt_flags = [0] * len(list_items)

            for idx, item in enumerate(list_items):
                laycol_info = internals.layer_collections.get(item.name)
                if isinstance(laycol_info, dict) and laycol_info.get("visible"):
                    flt_flags[idx] = self.bitflag_filter_item


        if self.use_filter_invert:
            CM_UL_items.filtering = True # invert can act as pseudo filtering
            for idx, flag in enumerate(flt_flags):
                flt_flags[idx] = 0 if flag else self.bitflag_filter_item


        # update visible items list
        CM_UL_items.visible_items.clear()
        CM_UL_items.visible_items.extend(flt_flags)

        return flt_flags, flt_neworder


    def invoke(self, context, event):
        pass


def _cm_help_button(row, topic_id):
    """1.10.51: the ? help of the Smart Selector suite (SmartTools common help spec 2026-10-17)."""
    try:
        op = row.operator('smart_selector_suite.show_help', text='', icon='QUESTION', emboss=True)
        op.topic_id = str(topic_id or 'collection_manager')
    except Exception:
        pass


class CMDisplayOptionsPanel(Panel):
    bl_label = "Display Options"
    bl_idname = "COLLECTIONMANAGER_PT_display_options"

    # set space type to VIEW_3D and region type to HEADER
    # because we only need it in a popover in the 3D View
    # and don't want it always present in the UI/N-panel
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'

    def draw(self, context):
        layout = self.layout
        try:
            scene = getattr(context, 'scene', None) if context is not None else None
            if scene is None or not hasattr(scene, 'collection_manager'):
                layout.label(text=_cm_text('Display options are not available in the current context.', '現在のコンテキストでは表示オプションを使用できません。'), icon='ERROR')
                return
            cm = scene.collection_manager
        except Exception:
            layout.label(text=_cm_text('Display options draw was skipped for safety.', '安全のため表示オプションの描画をスキップしました。'), icon='ERROR')
            return


        panel_header = layout.row()
        panel_header.alignment = 'CENTER'
        panel_header.label(text=_cm_text("Display Options", "表示オプション"))
        _cm_help_button(panel_header, 'collection_manager_display')

        layout.separator()

        section_header = layout.row()
        section_header.alignment = 'LEFT'
        section_header.label(text=_cm_text("Restriction Toggles", "制限トグル"))

        row = layout.row()
        _prop_with_icon(row, cm, "show_exclude", icon='CHECKBOX_HLT', icon_only=True)
        _prop_with_icon(row, cm, "show_selectable", icon='RESTRICT_SELECT_OFF', icon_only=True)
        _prop_with_icon(row, cm, "show_hide_viewport", icon='HIDE_OFF', icon_only=True)
        _prop_with_icon(row, cm, "show_disable_viewport", icon='RESTRICT_VIEW_OFF', icon_only=True)
        _prop_with_icon(row, cm, "show_render", icon='RESTRICT_RENDER_OFF', icon_only=True)
        _prop_with_icon(row, cm, "show_holdout", icon='HOLDOUT_ON', icon_only=True)
        _prop_with_icon(row, cm, "show_indirect_only", icon='INDIRECT_ONLY_ON', icon_only=True)

        layout.separator()

        section_header = layout.row()
        section_header.label(text=_cm_text("Layout", "レイアウト"))

        row = layout.row()
        row.prop(cm, "align_local_ops")


class SpecialsMenu(Menu):
    bl_label = "Specials"
    bl_idname = "VIEW3D_MT_CM_specials_menu"

    def draw(self, context):
        layout = self.layout

        prop = _operator_with_icon(layout, "view3d.remove_empty_collections")
        prop.without_objects = False

        prop = _operator_with_icon(layout, "view3d.remove_empty_collections",
                               text=_cm_text("Purge All Collections Without Objects", "オブジェクトのないコレクションを一括削除"))
        prop.without_objects = True

        layout.separator()

        _operator_with_icon(layout, "view3d.select_all_cumulative_objects")


class EnableAllQCDSlotsMenu(Menu):
    bl_label = "Global QCD Slot Actions"
    bl_idname = "VIEW3D_MT_CM_qcd_enable_all_menu"

    def draw(self, context):
        layout = self.layout

        _operator_with_icon(layout, "view3d.create_all_qcd_slots")

        layout.separator()

        _operator_with_icon(layout, "view3d.enable_all_qcd_slots")
        _operator_with_icon(layout, "view3d.enable_all_qcd_slots_isolated")

        layout.separator()

        _operator_with_icon(layout, "view3d.isolate_selected_objects_collections")
        if context.mode == 'OBJECT':
            _operator_with_icon(layout, "view3d.disable_selected_objects_collections")

        layout.separator()

        _operator_with_icon(layout, "view3d.disable_all_non_qcd_slots")
        _operator_with_icon(layout, "view3d.disable_all_collections")

        if context.mode == 'OBJECT':
            layout.separator()
            _operator_with_icon(layout, "view3d.select_all_qcd_objects")

        layout.separator()

        _operator_with_icon(layout, "view3d.discard_qcd_history")



def _qcd_selected_name_set(context):
    try:
        return {str(getattr(obj, 'name', '') or '') for obj in (getattr(context, 'selected_objects', ()) or ()) if getattr(obj, 'name', '')}
    except Exception:
        return set()


def _qcd_active_name(context):
    try:
        obj = getattr(context, 'active_object', None)
        return str(getattr(obj, 'name', '') or '') if obj is not None else ''
    except Exception:
        return ''


def _qcd_collection_contains_any(collection_objects, names: set[str]) -> bool:
    if not names:
        return False
    try:
        if len(names) <= 6:
            return any(name in collection_objects for name in names)
        collection_names = {str(getattr(obj, 'name', '') or '') for obj in collection_objects}
        return not names.isdisjoint(collection_names)
    except Exception:
        return False


def _prepare_qcd_header_runtime(context) -> None:
    """Refresh expensive QCD header state at a bounded rate.

    The 3D View header redraws on every viewport orbit/pan/zoom frame. Rebuilding
    the complete collection tree and QCD history on every header draw causes
    click/drag navigation to feel delayed in larger scenes. This keeps the header
    responsive while preserving QCD behavior; explicit QCD operators and load/save
    handlers still update state immediately, and the header refreshes within the
    short interval below when passive changes occur.
    """
    try:
        view_layer = getattr(context, 'view_layer', None)
        view_layer_name = str(getattr(view_layer, 'name', '') or '')
    except Exception:
        view_layer_name = ''
    try:
        now = time.monotonic()
    except Exception:
        now = 0.0
    try:
        stale = (
            not internals.layer_collections
            or view_layer_name != str(_QCD_HEADER_CACHE.get('view_layer') or '')
            or not _QCD_HEADER_CACHE.get('last_refresh')
            or (now and now - float(_QCD_HEADER_CACHE.get('last_refresh') or 0.0) >= _QCD_HEADER_MIN_REFRESH)
        )
    except Exception:
        stale = True
    if not stale:
        return
    try:
        update_collection_tree(context)
    except Exception:
        pass
    try:
        check_state(context, qcd=True)
    except Exception:
        pass
    _QCD_HEADER_CACHE['view_layer'] = view_layer_name
    _QCD_HEADER_CACHE['last_refresh'] = now or 0.0

def view3d_header_qcd_slots(self, context):
    try:
        return _view3d_header_qcd_slots_impl(self, context)
    except Exception:
        return None


def _view3d_header_qcd_slots_impl(self, context):
    if context is None or getattr(context, 'view_layer', None) is None:
        return None

    view_layer = context.view_layer
    layout = self.layout
    idx = 1

    main_row = layout.row(align=True)
    current_qcd_history = internals.qcd_history.get(context.view_layer.name, [])

    main_row.operator_menu_hold("view3d.enable_all_qcd_slots_meta",
                                text="",
                                icon='HIDE_OFF',
                                depress=bool(current_qcd_history),
                                menu="VIEW3D_MT_CM_qcd_enable_all_menu")


    split = main_row.split()
    col = split.column(align=True)
    row = col.row(align=True)
    row.scale_y = 0.5

    selected_names = _qcd_selected_name_set(context)
    active_name = _qcd_active_name(context)

    for x in range(20):
        qcd_slot_name = internals.qcd_slots.get_name(str(x+1))

        if qcd_slot_name:
            laycol_info = internals.layer_collections.get(qcd_slot_name)
            qcd_laycol = laycol_info.get("ptr") if isinstance(laycol_info, dict) else None
            if qcd_laycol is None or getattr(qcd_laycol, 'collection', None) is None:
                prop = _operator_with_icon(row, "view3d.unassigned_qcd_slot", text="", icon='X')
                prop.slot = str(x+1)
                if idx%5==0:
                    row.separator()
                if idx == 10:
                    row = col.row(align=True)
                    row.scale_y = 0.5
                idx += 1
                continue
            collection_objects = qcd_laycol.collection.objects

            icon_value = 0

            # if the active object is in the current collection use Blender's active-layer icon
            if active_name and active_name in selected_names and active_name in collection_objects:
                icon = 'LAYER_ACTIVE'

            # if there are selected objects use LAYER_ACTIVE
            elif _qcd_collection_contains_any(collection_objects, selected_names):
                icon = 'LAYER_USED'

            # If there are objects, use Blender's standard used-layer icon.
            elif collection_objects:
                icon = 'LAYER_USED'

            else:
                icon = 'BLANK1'


            prop = _operator_with_icon(row, "view3d.view_move_qcd_slot", text="", icon=icon,
                                icon_value=icon_value, depress=not qcd_laycol.exclude)
            prop.slot = str(x+1)

        else:
            prop = _operator_with_icon(row, "view3d.unassigned_qcd_slot", text="", icon='X')
            prop.slot = str(x+1)


        if idx%5==0:
            row.separator()

        if idx == 10:
            row = col.row(align=True)
            row.scale_y = 0.5

        idx += 1


def view_layer_update(self, context):
    # Kept as a compatibility callback for installations that still have the
    # old hook appended.  Header drawing is strictly read-only; Collection
    # Manager operators and lifecycle handlers refresh the cached tree.
    return None


def get_active_icon(context, qcd_laycol):
    # Legacy QCD preview icon hook.  Custom preview-based active icons were
    # removed for Blender 5.1 UI stability; callers should use standard Blender
    # icons.  Return 0 so layout code falls back to its icon argument.
    return 0


def filter_items_by_name_custom(pattern, bitflag, items, propname="name", flags=None, reverse=False):
        """
        Set FILTER_ITEM for items which name matches filter_name one (case-insensitive).
        pattern is the filtering pattern.
        propname is the name of the string property to use for filtering.
        flags must be a list of integers the same length as items, or None!
        return a list of flags (based on given flags if not None),
        or an empty list if no flags were given and no filtering has been done.
        """
        import fnmatch

        if not pattern or not items:  # Empty pattern or list = no filtering!
            return flags or []

        if flags is None:
            flags = [0] * len(items)

        # Make pattern case-insensitive
        pattern = pattern.lower()

        # Implicitly add heading/trailing wildcards.
        pattern = "*" + pattern + "*"

        for i, item in enumerate(items):
            name = getattr(item, propname, None)
            name = str(name or '').lower()

            # This is similar to a logical xor
            if bool(name and fnmatch.fnmatch(name, pattern)) is not bool(reverse):
                flags[i] |= bitflag

            # add in any recently created collections
            if item.name in CM_UL_items.new_collections:
                flags[i] |= bitflag

        return flags

def merge_flt_flags(l1, l2):
    for idx, _ in enumerate(l1):
        l1[idx] &= l2.pop(0)

    return l1 + l2
