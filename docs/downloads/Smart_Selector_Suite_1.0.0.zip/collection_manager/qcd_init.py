# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

if "bpy" in locals():
    import importlib

    importlib.reload(internals)
    importlib.reload(qcd_move_widget)
    if "qcd_undo" in locals():
        importlib.reload(qcd_undo)
    else:
        from . import qcd_undo
    importlib.reload(qcd_operators)
    importlib.reload(ui)
    importlib.reload(preferences)

else:
    from . import internals
    from . import qcd_move_widget
    from . import qcd_undo
    from . import qcd_operators
    from . import ui
    from . import preferences

import os
import bpy
from ..translation import localize_class as _i18n_localize_class
import bpy.utils.previews
from bpy.app.handlers import persistent


addon_qcd_keymaps = []
addon_qcd_view_hotkey_keymaps = []
addon_qcd_view_edit_mode_hotkey_keymaps = []
qcd_registered = False


def _safe_bpy_type(name: str):
    try:
        return getattr(bpy.types, str(name or ''), None)
    except Exception:
        return None

def _safe_handler_list(name: str):
    try:
        return getattr(bpy.app.handlers, str(name or ''), None)
    except Exception:
        return None

def _safe_register_class(cls):
    existing = getattr(bpy.types, getattr(cls, '__name__', ''), None)
    if isinstance(existing, type):
        try:
            bpy.utils.unregister_class(existing)
        except Exception:
            pass
    bpy.utils.register_class(_i18n_localize_class(cls))


def _safe_unregister_class(cls):
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


def _safe_handler_append(handler_list, callback):
    try:
        if callback in handler_list:
            handler_list.remove(callback)
    except Exception:
        try:
            handler_list.remove(callback)
        except Exception:
            pass
    try:
        handler_list.append(callback)
    except Exception:
        pass


def _safe_handler_remove(handler_list, callback):
    try:
        if callback in handler_list:
            handler_list.remove(callback)
            return
    except Exception:
        pass
    try:
        handler_list.remove(callback)
    except Exception:
        pass


def _safe_draw_append(container, callback):
    try:
        container.remove(callback)
    except Exception:
        pass
    try:
        container.append(callback)
    except Exception:
        pass


def _safe_draw_remove(container, callback):
    try:
        container.remove(callback)
    except Exception:
        pass


def _clear_preview_collections():
    for pcoll in tuple(ui.preview_collections.values()):
        try:
            bpy.utils.previews.remove(pcoll)
        except Exception:
            pass
    ui.preview_collections.clear()
    ui.last_icon_theme_text = None
    ui.last_icon_theme_text_sel = None


def _addon_keymaps_collection():
    wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    kc = getattr(getattr(wm, 'keyconfigs', None), 'addon', None)
    return getattr(kc, 'keymaps', None)


def _prune_empty_addon_keymaps(*names):
    keymaps = _addon_keymaps_collection()
    if keymaps is None:
        return
    normalized = tuple(str(name or '').strip() for name in names if str(name or '').strip())
    removed = 0
    finder = getattr(keymaps, 'find', None)
    getter = getattr(keymaps, 'get', None)
    for target_name in normalized:
        for _attempt in range(16):
            km = None
            if callable(getter):
                try:
                    km = getter(target_name)
                except Exception:
                    km = None
            if km is None and callable(finder):
                for call in (
                    lambda: finder(target_name),
                    lambda: finder(name=target_name),
                    lambda: finder(name=target_name, space_type='EMPTY', region_type='WINDOW'),
                ):
                    try:
                        km = call()
                    except Exception:
                        km = None
                    if km is not None:
                        break
            if km is None:
                break
            try:
                item_count = len(getattr(km, 'keymap_items', ()) or ())
            except Exception:
                item_count = 0
            if item_count:
                break
            try:
                keymaps.remove(km)
                removed += 1
            except Exception:
                break
    if removed:
        return
    wanted = {name.lower() for name in normalized}
    stale = []
    try:
        iterable = tuple(keymaps)
    except Exception:
        iterable = ()
    for km in iterable:
        try:
            name = str(getattr(km, 'name', '') or '').strip()
        except Exception:
            name = ''
        if wanted and name.lower() not in wanted:
            continue
        try:
            item_count = len(getattr(km, 'keymap_items', ()) or ())
        except Exception:
            item_count = 0
        if item_count:
            continue
        stale.append(km)
    for km in stale:
        try:
            keymaps.remove(km)
        except Exception:
            pass


def _new_addon_keymap_item(name: str, operator_id: str, key: str, value: str, **mods):
    keymaps = _addon_keymaps_collection()
    if keymaps is None:
        return None, None
    km = keymaps.new(name=name)
    try:
        kmi = km.keymap_items.new(operator_id, key, value, **mods)
    except Exception:
        try:
            if not len(getattr(km, 'keymap_items', ()) or ()):
                keymaps.remove(km)
        except Exception:
            pass
        raise
    return km, kmi

qcd_classes = (
    qcd_move_widget.QCDMoveWidget,
    qcd_operators.EnableAllQCDSlotsMeta,
    qcd_operators.EnableAllQCDSlots,
    qcd_operators.EnableAllQCDSlotsIsolated,
    qcd_operators.IsolateSelectedObjectsCollections,
    qcd_operators.DisableSelectedObjectsCollections,
    qcd_operators.DisableAllNonQCDSlots,
    qcd_operators.DisableAllCollections,
    qcd_operators.SelectAllQCDObjects,
    qcd_operators.DiscardQCDHistory,
    qcd_operators.MoveToQCDSlot,
    qcd_operators.ViewQCDSlot,
    qcd_operators.ViewMoveQCDSlot,
    qcd_operators.UnassignedQCDSlot,
    qcd_operators.CreateAllQCDSlots,
    qcd_operators.RenumerateQCDSlots,
    ui.EnableAllQCDSlotsMenu,
    )


def _handler_scene_collection_manager(args):
    try:
        scene = args[0] if args and hasattr(args[0], 'collection_manager') else getattr(bpy.context, 'scene', None)
    except Exception:
        scene = None
    try:
        return getattr(scene, 'collection_manager', None) if scene is not None else None
    except Exception:
        return None


@persistent
def save_internal_data(*args):
    cm = _handler_scene_collection_manager(args)
    if cm is None:
        return
    try:
        cm.qcd_slots_blend_data = internals.qcd_slots.get_data_for_blend()
    except Exception:
        pass


@persistent
def load_internal_data(*args):
    cm = _handler_scene_collection_manager(args)
    if cm is None:
        return
    try:
        data = cm.qcd_slots_blend_data
    except Exception:
        data = ''
    if not data:
        return
    try:
        internals.qcd_slots.load_blend_data(data)
    except Exception:
        pass


@persistent
def load_pre_handler(*args):
    try:
        internals.qcd_collection_state.clear()
        for key in list(internals.qcd_history.keys()):
            del internals.qcd_history[key]
    except Exception:
        pass


def register_qcd():
    global qcd_registered
    if qcd_registered:
        # guard to handle default value updates (mouse hover + backspace)
        return

    for cls in qcd_classes:
        _safe_register_class(cls)

    # QCD LayerCollection state needs an explicit Scene-token bridge because
    # Blender's native global undo does not restore exclusion state by itself.
    qcd_undo.register()

    _clear_preview_collections()

    if not addon_qcd_keymaps:
        keymaps = _addon_keymaps_collection()
        if keymaps is not None: # not present when started with --background
            km, kmi = _new_addon_keymap_item('Object Mode', 'view3d.qcd_move_widget', 'V', 'PRESS')
            if km is not None and kmi is not None:
                addon_qcd_keymaps.append((km, kmi))

    _safe_handler_append(_safe_handler_list('save_pre'), save_internal_data)
    _safe_handler_append(_safe_handler_list('load_post'), load_internal_data)
    _safe_handler_append(_safe_handler_list('load_pre'), load_pre_handler)

    try:
        prefs = preferences.get_cm_preferences(getattr(bpy, 'context', None))
    except Exception:
        prefs = None

    if bool(getattr(prefs, 'enable_qcd_view_hotkeys', False)):
        register_qcd_view_hotkeys()

    if bool(getattr(prefs, 'enable_qcd_view_edit_mode_hotkeys', False)):
        register_qcd_view_edit_mode_hotkeys()

    if bool(getattr(prefs, 'enable_qcd_3dview_header_widget', False)):
        register_qcd_3dview_header_widget()

    qcd_registered = True


def register_qcd_view_hotkeys():
    if addon_qcd_view_hotkey_keymaps:
        # guard to handle default value updates (mouse hover + backspace)
        return

    wm = bpy.context.window_manager
    if wm.keyconfigs.addon: # not present when started with --background
        # create qcd hotkeys
        qcd_hotkeys = [
            ["ONE", False, "1"],
            ["TWO", False, "2"],
            ["THREE", False, "3"],
            ["FOUR", False, "4"],
            ["FIVE", False, "5"],
            ["SIX", False, "6"],
            ["SEVEN", False, "7"],
            ["EIGHT", False, "8"],
            ["NINE", False, "9"],
            ["ZERO", False, "10"],
            ["ONE", True, "11"],
            ["TWO", True, "12"],
            ["THREE", True, "13"],
            ["FOUR", True, "14"],
            ["FIVE", True, "15"],
            ["SIX", True, "16"],
            ["SEVEN", True, "17"],
            ["EIGHT", True, "18"],
            ["NINE", True, "19"],
            ["ZERO", True, "20"],
        ]

        for mode in ['Object Mode', 'Pose', 'Weight Paint']:
            for key in qcd_hotkeys:
                km, kmi = _new_addon_keymap_item(mode, 'view3d.view_qcd_slot', key[0], 'PRESS', alt=key[1])
                if km is not None and kmi is not None:
                    kmi.properties.slot = key[2]
                    kmi.properties.toggle = False
                    addon_qcd_view_hotkey_keymaps.append((km, kmi))

                km, kmi = _new_addon_keymap_item(mode, 'view3d.view_qcd_slot', key[0], 'PRESS', shift=True, alt=key[1])
                if km is not None and kmi is not None:
                    kmi.properties.slot = key[2]
                    kmi.properties.toggle = True
                    addon_qcd_view_hotkey_keymaps.append((km, kmi))

            km, kmi = _new_addon_keymap_item(mode, 'view3d.enable_all_qcd_slots', 'PLUS', 'PRESS', shift=True)
            if km is not None and kmi is not None:
                addon_qcd_view_hotkey_keymaps.append((km, kmi))

            km, kmi = _new_addon_keymap_item(mode, 'view3d.isolate_selected_objects_collections', 'EQUAL', 'PRESS')
            if km is not None and kmi is not None:
                addon_qcd_view_hotkey_keymaps.append((km, kmi))

            km, kmi = _new_addon_keymap_item(mode, 'view3d.disable_selected_objects_collections', 'MINUS', 'PRESS')
            if km is not None and kmi is not None:
                addon_qcd_view_hotkey_keymaps.append((km, kmi))

            km, kmi = _new_addon_keymap_item(mode, 'view3d.disable_all_non_qcd_slots', 'PLUS', 'PRESS', shift=True, alt=True)
            if km is not None and kmi is not None:
                addon_qcd_view_hotkey_keymaps.append((km, kmi))

            km, kmi = _new_addon_keymap_item(mode, 'view3d.disable_all_collections', 'EQUAL', 'PRESS', alt=True, ctrl=True)
            if km is not None and kmi is not None:
                addon_qcd_view_hotkey_keymaps.append((km, kmi))

            km, kmi = _new_addon_keymap_item(mode, 'view3d.select_all_qcd_objects', 'PLUS', 'PRESS', shift=True, ctrl=True)
            if km is not None and kmi is not None:
                addon_qcd_view_hotkey_keymaps.append((km, kmi))


            km, kmi = _new_addon_keymap_item(mode, 'view3d.discard_qcd_history', 'EQUAL', 'PRESS', alt=True)
            if km is not None and kmi is not None:
                addon_qcd_view_hotkey_keymaps.append((km, kmi))


def register_qcd_view_edit_mode_hotkeys():
    if addon_qcd_view_edit_mode_hotkey_keymaps:
        # guard to handle default value updates (mouse hover + backspace)
        return

    wm = bpy.context.window_manager
    if wm.keyconfigs.addon: # not present when started with --background
        # create qcd hotkeys
        qcd_hotkeys = [
            ["ONE", False, "1"],
            ["TWO", False, "2"],
            ["THREE", False, "3"],
            ["FOUR", False, "4"],
            ["FIVE", False, "5"],
            ["SIX", False, "6"],
            ["SEVEN", False, "7"],
            ["EIGHT", False, "8"],
            ["NINE", False, "9"],
            ["ZERO", False, "10"],
            ["ONE", True, "11"],
            ["TWO", True, "12"],
            ["THREE", True, "13"],
            ["FOUR", True, "14"],
            ["FIVE", True, "15"],
            ["SIX", True, "16"],
            ["SEVEN", True, "17"],
            ["EIGHT", True, "18"],
            ["NINE", True, "19"],
            ["ZERO", True, "20"],
        ]

        for mode in ["Mesh", "Curve", "Armature", "Metaball", "Lattice", "Grease Pencil Stroke Edit Mode"]:
            for key in qcd_hotkeys:
                km, kmi = _new_addon_keymap_item(mode, 'view3d.view_qcd_slot', key[0], 'PRESS', alt=key[1])
                if km is not None and kmi is not None:
                    kmi.properties.slot = key[2]
                    kmi.properties.toggle = False
                    addon_qcd_view_edit_mode_hotkey_keymaps.append((km, kmi))

                km, kmi = _new_addon_keymap_item(mode, 'view3d.view_qcd_slot', key[0], 'PRESS', shift=True, alt=key[1])
                if km is not None and kmi is not None:
                    kmi.properties.slot = key[2]
                    kmi.properties.toggle = True
                    addon_qcd_view_edit_mode_hotkey_keymaps.append((km, kmi))

            km, kmi = _new_addon_keymap_item(mode, 'view3d.enable_all_qcd_slots', 'PLUS', 'PRESS', shift=True)
            if km is not None and kmi is not None:
                addon_qcd_view_edit_mode_hotkey_keymaps.append((km, kmi))

            km, kmi = _new_addon_keymap_item(mode, 'view3d.isolate_selected_objects_collections', 'EQUAL', 'PRESS')
            if km is not None and kmi is not None:
                addon_qcd_view_edit_mode_hotkey_keymaps.append((km, kmi))

            km, kmi = _new_addon_keymap_item(mode, 'view3d.disable_all_non_qcd_slots', 'PLUS', 'PRESS', shift=True, alt=True)
            if km is not None and kmi is not None:
                addon_qcd_view_edit_mode_hotkey_keymaps.append((km, kmi))

            km, kmi = _new_addon_keymap_item(mode, 'view3d.disable_all_collections', 'EQUAL', 'PRESS', alt=True, ctrl=True)
            if km is not None and kmi is not None:
                addon_qcd_view_edit_mode_hotkey_keymaps.append((km, kmi))

            km, kmi = _new_addon_keymap_item(mode, 'view3d.discard_qcd_history', 'EQUAL', 'PRESS', alt=True)
            if km is not None and kmi is not None:
                addon_qcd_view_edit_mode_hotkey_keymaps.append((km, kmi))


        km, kmi = _new_addon_keymap_item("Mesh", 'wm.call_menu', 'ACCENT_GRAVE', 'PRESS')
        if km is not None and kmi is not None:
            kmi.properties.name = "VIEW3D_MT_edit_mesh_select_mode"
            addon_qcd_view_edit_mode_hotkey_keymaps.append((km, kmi))


def register_qcd_3dview_header_widget():
    # unregister first to guard against default value updates (mouse hover + backspace)
    # if the widget isn't registered it will just do nothing
    unregister_qcd_3dview_header_widget()

    # Build the cache once at the explicit registration boundary. Header draw
    # callbacks only consume this state and never register timers or mutate RNA.
    try:
        ui._prepare_qcd_header_runtime(getattr(bpy, 'context', None))
    except Exception:
        pass
    _safe_draw_append(_safe_bpy_type('VIEW3D_HT_header'), ui.view3d_header_qcd_slots)


def unregister_qcd():
    global qcd_registered

    try:
        qcd_move_widget.cancel_pending_widget_moves()
    except Exception:
        pass

    try:
        qcd_undo.unregister()
    except Exception:
        pass

    unregister_qcd_3dview_header_widget()

    for cls in reversed(qcd_classes):
        _safe_unregister_class(cls)

    _safe_handler_remove(_safe_handler_list('save_pre'), save_internal_data)
    _safe_handler_remove(_safe_handler_list('load_post'), load_internal_data)
    _safe_handler_remove(_safe_handler_list('load_pre'), load_pre_handler)

    _clear_preview_collections()

    # remove keymaps when qcd is deactivated
    for km, kmi in addon_qcd_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_qcd_keymaps.clear()
    _prune_empty_addon_keymaps('Object Mode')

    unregister_qcd_view_hotkeys()

    unregister_qcd_view_edit_mode_hotkeys()

    qcd_registered = False


def unregister_qcd_view_hotkeys():
    # remove keymaps when qcd view hotkeys are deactivated
    for km, kmi in addon_qcd_view_hotkey_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_qcd_view_hotkey_keymaps.clear()
    _prune_empty_addon_keymaps('Object Mode', 'Pose', 'Weight Paint')


def unregister_qcd_view_edit_mode_hotkeys():
    # remove keymaps when qcd view hotkeys are deactivated
    for km, kmi in addon_qcd_view_edit_mode_hotkey_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_qcd_view_edit_mode_hotkey_keymaps.clear()
    _prune_empty_addon_keymaps('Mesh', 'Curve', 'Armature', 'Metaball', 'Lattice', 'Grease Pencil Stroke Edit Mode')


def unregister_qcd_3dview_header_widget():
    _safe_draw_remove(_safe_bpy_type('VIEW3D_HT_header'), ui.view3d_header_qcd_slots)
    _safe_draw_remove(_safe_bpy_type('TOPBAR_HT_upper_bar'), ui.view_layer_update)
