# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import textwrap

import bpy

from . import settings as _sss_settings
from . import registry as tool_registry
from .translation import is_japanese_locale as _i18n_is_japanese_locale


def _is_japanese_locale() -> bool:
    return _i18n_is_japanese_locale()


def _lang_text(en: str, ja: str) -> str:
    return str(ja if _is_japanese_locale() else en)


def _draw_help_header(layout, title: str, icon: str = 'NONE', topic_id: str = ''):
    row = layout.row(align=True)
    row.label(text=str(title or ''), icon=icon)
    if topic_id:
        try:
            help_row = row.row(align=True)
            help_row.scale_x = 0.82
            help_row.scale_y = 1.0
        except Exception:
            help_row = row
        try:
            op = help_row.operator('smart_selector_suite.show_help', text='', icon='QUESTION')
            op.topic_id = str(topic_id or '')
        except Exception:
            pass
    return row

def _section_key(key: str) -> str:
    raw = str(key or '').strip()
    if not raw:
        return ''
    if raw.startswith('show_') or raw.startswith('ui_show_'):
        return raw
    clean = ''.join(ch.lower() if ch.isalnum() else '_' for ch in raw).strip('_')
    return f'ui_show_{clean}' if clean else ''


def _section_open(key: str, default: bool = False) -> bool:
    setting_key = _section_key(key)
    if not setting_key:
        return bool(default)
    try:
        return bool(_sss_settings.get_value(setting_key, bool(default)))
    except Exception:
        return bool(default)


def _assign_toggle(op, key: str, label: str, default: bool = False) -> None:
    try:
        op.section_key = str(key or '')
        op.label = str(label or '')
        op.default_state = bool(default)
    except Exception:
        pass


def _draw_group_help(row, topic_id: str) -> None:
    if not topic_id:
        return
    try:
        row.separator(factor=0.35)
    except Exception:
        pass
    try:
        help_row = row.row(align=True)
        help_row.scale_x = 0.82
        help_row.scale_y = 1.0
    except Exception:
        help_row = row
    try:
        op = help_row.operator('smart_selector_suite.show_help', text='', icon='QUESTION', emboss=True)
        op.topic_id = str(topic_id or '')
    except TypeError:
        try:
            op = help_row.operator('smart_selector_suite.show_help', text='', icon='QUESTION')
            op.topic_id = str(topic_id or '')
        except Exception:
            pass
    except Exception:
        pass

def _settings_panel_prop_name(key: str) -> str:
    setting_key = _section_key(key)
    return setting_key if setting_key and setting_key.startswith('ui_show_') else ''


def _settings_panel_state_owner(context=None):
    try:
        ctx = context or getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        if wm is None or not hasattr(bpy.types.WindowManager, 'smart_selector_suite_npanel_settings'):
            return None
        return getattr(wm, 'smart_selector_suite_npanel_settings', None)
    except Exception:
        return None


def _collapsible_settings_box(layout, *, key: str, label: str, icon: str = 'NONE', topic_id: str = '', default: bool = False):
    """Draw a settings child section only through Blender's native panel API."""
    del icon
    display = str(label or '')
    prop_name = _settings_panel_prop_name(key)
    state_owner = _settings_panel_state_owner()
    header = None
    panel = None

    if state_owner is not None and prop_name and hasattr(state_owner, prop_name) and hasattr(layout, 'panel_prop'):
        try:
            header, panel = layout.panel_prop(state_owner, prop_name)
        except Exception:
            header = None
            panel = None

    if header is None:
        if not hasattr(layout, 'panel'):
            return layout, None
        panel_key = ''.join(ch if ch.isalnum() else '_' for ch in str(key or 'section'))
        try:
            header, panel = layout.panel(
                f'SSSUITE_CHILD_{panel_key}',
                default_closed=not bool(default),
            )
        except Exception:
            return layout, None

    header.use_property_split = False
    header.use_property_decorate = False
    try:
        header.label(text=display)
    except Exception:
        pass
    # 1.10.51: the ? help sits at the right end of the header (SmartTools common help spec 2026-10-17).
    try:
        help_lane = header.row(align=True)
        help_lane.alignment = 'RIGHT'
    except Exception:
        help_lane = header
    _draw_group_help(help_lane, topic_id)

    if panel is None:
        return header, None
    panel.use_property_split = True
    panel.use_property_decorate = False
    body = panel.column(align=True)
    body.use_property_split = True
    body.use_property_decorate = False
    return header, body

_PREFS_SAVE_PENDING = False


def _save_user_preferences_timer():
    try:
        from . import settings as _settings
        _settings.flush_user_preferences_save()
    except Exception:
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
    return None


def _queue_user_preferences_save() -> None:
    try:
        from . import settings as _settings
        _settings.queue_user_preferences_save()
        return
    except Exception:
        pass
    try:
        bpy.ops.wm.save_userpref()
    except Exception:
        pass


def _wrap_labels(layout, text: str, width: int = 88, icon: str = 'NONE') -> None:
    cleaned = str(text or '').strip()
    if not cleaned:
        return
    lines = textwrap.wrap(cleaned, width=max(32, int(width))) or [cleaned]
    first = True
    for line in lines:
        if first:
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)


def _localized_spec_text(spec: dict, en_key: str, ja_key: str, fallback: str = '') -> str:
    en = str(spec.get(en_key) or '').strip()
    ja = str(spec.get(ja_key) or '').strip()
    if ja or en:
        return _lang_text(en, ja)
    return str(fallback or '')


def _integrated_tool_spec(alias: str) -> dict:
    alias = str(alias or '').strip()
    for spec in tool_registry.tool_definitions():
        if str(spec.get('alias') or '').strip() == alias:
            return dict(spec)
    return {}


def _draw_integrated_tool_section(layout, settings_obj, *, alias: str, show_prop: str) -> None:
    spec = _integrated_tool_spec(alias)
    if not spec or settings_obj is None or not hasattr(settings_obj, show_prop):
        return

    display_name = _localized_spec_text(spec, 'display_name', 'display_name_ja', alias)
    header = None
    panel = None
    if hasattr(layout, 'panel_prop'):
        try:
            header, panel = layout.panel_prop(settings_obj, show_prop)
        except Exception:
            header = None
            panel = None

    if header is None:
        if not hasattr(layout, 'panel'):
            return
        panel_key = ''.join(ch if ch.isalnum() else '_' for ch in str(show_prop or alias or 'tool'))
        try:
            header, panel = layout.panel(
                f'SSSUITE_CHILD_{panel_key}',
                default_closed=not bool(getattr(settings_obj, show_prop)),
            )
        except Exception:
            return

    header.label(text=display_name)
    if panel is None:
        return
    panel.label(text=_lang_text('Use the top Always-on Toggles group.', '最上部の常時機能切り替えを使用してください。'), icon='TOOL_SETTINGS')

def draw_settings_into_layout(layout, settings_obj) -> None:
    """Draw all user-editable settings into the Smart Selector N-panel.

    No separate preferences-panel properties are registered or used. Every displayed
    property belongs to the WindowManager N-panel settings group and is saved to
    CONFIG/Smart_Selector_Suite/Smart_Selector_Suite.json according to N-panel State Save when edited.
    """
    if layout is None or settings_obj is None:
        return

    layout.use_property_split = True
    layout.use_property_decorate = False

    _storage_box, storage = _collapsible_settings_box(
        layout,
        key='settings_storage',
        label=_lang_text('Data Storage', 'データ保存先'),
        icon='FILE_FOLDER',
        topic_id='settings_storage',
        default=False,
    )
    if storage is not None:
        storage.use_property_split = False
        storage.label(text=_lang_text('Data Save Root Directory', 'データ保存ルートディレクトリ'))
        storage.prop(settings_obj, 'root_dir', text='')

    _perf_box, perf = _collapsible_settings_box(
        layout,
        key='settings_performance',
        label=_lang_text('Performance / Safety', 'パフォーマンスと安全性'),
        icon='TOOL_SETTINGS',
        topic_id='settings_performance',
        default=False,
    )
    if perf is not None:
        perf.prop(settings_obj, 'state_update_interval')
        perf.prop(settings_obj, 'max_backup_generations')
        perf.prop(settings_obj, 'enable_exec_script')

    _project_box, project = _collapsible_settings_box(
        layout,
        key='settings_project_list',
        label=_lang_text('Project List', 'プロジェクト一覧'),
        icon='FILE_FOLDER',
        topic_id='settings_project_list',
        default=False,
    )
    if project is not None:
        project.use_property_split = False
        project.prop(settings_obj, 'show_archived_projects')

    layout.use_property_split = False


def register():
    return None


def unregister():
    global _PREFS_SAVE_PENDING
    _PREFS_SAVE_PENDING = False
    try:
        if bpy.app.timers.is_registered(_save_user_preferences_timer):
            bpy.app.timers.unregister(_save_user_preferences_timer)
    except Exception:
        pass
