from __future__ import annotations
import importlib
import platform
import traceback
from pathlib import Path
from typing import Any
import bpy
from .translation import localize_class as _i18n_localize_class
from . import registry as registry
_RECORDS: list[dict[str, Any]] = []
_HIDDEN_PANEL_POLLS: dict[type, object] = {}
_MISSING_POLL = object()

def clear_records() -> None:
    _RECORDS.clear()

def get_records() -> list[dict[str, Any]]:
    return list(_RECORDS)

def get_record(alias: str) -> dict[str, Any] | None:
    alias = str(alias or '').strip()
    if not alias:
        return None
    for record in _RECORDS:
        spec = record.get('spec') or {}
        if str(spec.get('alias') or '').strip() == alias:
            return record
    return None

def _root_module_prefix() -> str:
    package = str(__package__ or '').strip()
    return package or 'smart_selector_suite'

def _platform_supported(outer_zip: str) -> bool:
    text = str(outer_zip or '').lower()
    system = platform.system().lower()
    machine = platform.machine().lower()
    if 'windows-x64' in text:
        return system == 'windows' and machine in {'amd64', 'x86_64'}
    if 'linux-x64' in text:
        return system == 'linux' and machine in {'amd64', 'x86_64'}
    if 'macos-arm64' in text:
        return system == 'darwin' and machine in {'arm64', 'aarch64'}
    if 'macos-x64' in text:
        return system == 'darwin' and machine in {'amd64', 'x86_64'}
    return True

def _module_name_for_spec(spec: dict[str, Any]) -> str:
    prefix = _root_module_prefix()
    alias = str(spec.get('alias') or 'addon').strip()
    return f'{prefix}.{alias}'

def _spec_import_paths(spec: dict[str, Any]) -> tuple[str, str, Path]:
    src_dir = Path(str(spec.get('src_dir') or ''))
    init_relpath = Path(str(spec.get('init_relpath') or ''))
    init_path = (src_dir / init_relpath).resolve() if src_dir and init_relpath else Path()
    module_name = _module_name_for_spec(spec)
    package_dir = init_path.parent if init_path.name == '__init__.py' else src_dir
    return (module_name, str(init_path), package_dir)

def _load_module_from_spec(spec: dict[str, Any]):
    alias = str(spec.get('alias') or '').strip()
    if not alias:
        raise ImportError('Missing integrated tool alias')
    module_name, init_path_str, _package_dir = _spec_import_paths(spec)
    if not init_path_str:
        raise FileNotFoundError('init_relpath is empty')
    init_path = Path(init_path_str)
    if not init_path.exists():
        raise FileNotFoundError(f'Missing init file: {init_path}')
    relative_name = f'.{alias}'
    try:
        module = importlib.import_module(relative_name, __package__)
    except Exception:
        module = importlib.import_module(module_name)
    try:
        module = importlib.reload(module)
    except Exception:
        pass
    return module

def _capture_registered_classes(callable_obj):
    captured: list[type] = []
    original_register_class = bpy.utils.register_class

    def _wrapped_register_class(cls):
        cls = _i18n_localize_class(cls)
        try:
            cls = _wrap_operator_poll_safely(cls)
        except Exception:
            pass
        original_register_class(cls)
        captured.append(cls)
        return None
    pass
    try:
        callable_obj()
    finally:
        pass
    return captured

def _wrap_operator_poll_safely(cls: type) -> type:
    if getattr(cls, '_sss_loader_safe_poll_wrapped', False):
        return cls
    try:
        operator_base = getattr(bpy.types, 'Operator', None)
        if operator_base is None or not issubclass(cls, operator_base):
            return cls
    except Exception:
        return cls
    raw = cls.__dict__.get('poll')
    if raw is None:
        return cls
    func = raw.__func__ if isinstance(raw, classmethod) else raw
    if not callable(func):
        return cls

    def _make_safe_poll(_func):

        @classmethod
        def _safe_poll(_cls, context):
            try:
                try:
                    return bool(_func(_cls, context))
                except TypeError:
                    return bool(_func(context))
            except Exception:
                return False
        return _safe_poll
    try:
        pass
        cls._sss_loader_safe_poll_wrapped = True
    except Exception:
        pass
    return cls

def _categorize_classes(classes: list[type]) -> tuple[list[type], list[type], list[type], list[type]]:
    panels: list[type] = []
    operators: list[type] = []
    menus: list[type] = []
    prefs: list[type] = []
    panel_base = getattr(bpy.types, 'Panel', None)
    operator_base = getattr(bpy.types, 'Operator', None)
    menu_base = getattr(bpy.types, 'Menu', None)
    for cls in classes:
        try:
            if panel_base is not None and isinstance(cls, type) and issubclass(cls, panel_base):
                panels.append(cls)
                continue
        except Exception:
            pass
        try:
            if operator_base is not None and isinstance(cls, type) and issubclass(cls, operator_base):
                operators.append(_wrap_operator_poll_safely(cls))
                continue
        except Exception:
            pass
        try:
            if menu_base is not None and isinstance(cls, type) and issubclass(cls, menu_base):
                menus.append(cls)
                continue
        except Exception:
            pass
    return (panels, operators, menus, prefs)

def _declared_panel_classes(module) -> list[type]:
    panel_base = getattr(bpy.types, 'Panel', None)
    if panel_base is None or module is None:
        return []
    declared: list[type] = []
    seen: set[type] = set()

    def _push_from(value):
        if not isinstance(value, (list, tuple, set)):
            return
        for cls in value:
            try:
                if not isinstance(cls, type) or not issubclass(cls, panel_base):
                    continue
            except Exception:
                continue
            if cls in seen:
                continue
            seen.add(cls)
            declared.append(cls)
    for attr_name in ('SMART_SELECTOR_PANEL_CLASSES', 'smart_selector_panel_classes', 'LEGACY_PANEL_CLASSES', 'legacy_panel_classes', 'classes'):
        try:
            _push_from(getattr(module, attr_name, None))
        except Exception:
            pass
    return declared

def _iter_legacy_sidebar_panels(panels: list[type]):
    for cls in panels or ():
        try:
            space = str(getattr(cls, 'bl_space_type', '') or '')
            region = str(getattr(cls, 'bl_region_type', '') or '')
        except Exception:
            continue
        if region != 'UI':
            continue
        if space not in {'VIEW_3D', 'IMAGE_EDITOR'}:
            continue
        yield cls

def _retire_legacy_sidebar_panels(panels: list[type]) -> None:
    for cls in _iter_legacy_sidebar_panels(panels):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

def _call_module_unregister_tolerant(callable_obj) -> None:
    original_unregister_class = bpy.utils.unregister_class

    def _wrapped_unregister_class(cls):
        try:
            original_unregister_class(cls)
        except Exception:
            return None
        return None
    pass
    try:
        callable_obj()
    finally:
        pass

def _hide_original_panels(panels: list[type]) -> None:
    for cls in panels:
        if cls in _HIDDEN_PANEL_POLLS:
            continue
        raw_poll = cls.__dict__.get('poll', _MISSING_POLL)

        @classmethod
        def _hidden_poll(_inner_cls, _context):
            return False
        try:
            pass
            _HIDDEN_PANEL_POLLS[cls] = raw_poll
        except Exception:
            pass

def _restore_hidden_panels() -> None:
    for cls, raw_poll in list(_HIDDEN_PANEL_POLLS.items()):
        try:
            if raw_poll is _MISSING_POLL:
                if hasattr(cls, 'poll'):
                    setattr(cls, 'poll', classmethod(lambda _cls, _context: True))
            else:
                setattr(cls, 'poll', raw_poll)
        except Exception:
            pass
    _HIDDEN_PANEL_POLLS.clear()

def _new_record(spec: dict[str, Any]) -> dict[str, Any]:
    return {'spec': spec, 'status': 'disabled', 'module': None, 'registered_classes': [], 'proxy_panels': [], 'panels': [], 'operators': [], 'menus': [], 'preferences': [], 'error': ''}

def _reset_record_runtime(record: dict[str, Any], *, status: str) -> dict[str, Any]:
    record['status'] = str(status or 'standby')
    record['module'] = None
    record['registered_classes'] = []
    record['proxy_panels'] = []
    record['panels'] = []
    record['operators'] = []
    record['menus'] = []
    record['preferences'] = []
    record['error'] = ''
    return record

def _load_record(record: dict[str, Any]) -> dict[str, Any]:
    spec = dict(record.get('spec') or {})
    _reset_record_runtime(record, status='loading')
    module = None
    captured: list[type] = []
    try:
        module = _load_module_from_spec(spec)
        record['module'] = module
        register_fn = getattr(module, 'register', None)
        _ft_alias = str((spec.get('alias') if isinstance(spec, dict) else '') or globals().get('alias', '') or 'integrated_tool').strip()
        _ft_label = str((spec.get('display_name') if isinstance(spec, dict) else '') or _ft_alias or 'Tool Command').strip()
        if callable(register_fn):
            captured = _capture_registered_classes(register_fn)
        panels, operators, menus, prefs = _categorize_classes(captured)
        for panel_cls in _declared_panel_classes(module):
            if panel_cls not in panels:
                panels.append(panel_cls)
        _retire_legacy_sidebar_panels(panels)
        record['registered_classes'] = [cls for cls in captured if cls not in set(_iter_legacy_sidebar_panels(panels))]
        record['panels'] = [cls for cls in panels if cls not in set(_iter_legacy_sidebar_panels(panels))]
        record['operators'] = operators
        record['menus'] = menus
        record['preferences'] = prefs
        try:
            from . import tooltip_audit as _tooltip_audit
            ensure_audit = getattr(_tooltip_audit, 'ensure_runtime_audit', None)
            if callable(ensure_audit):
                ensure_audit()
        except Exception:
            pass
        record['status'] = 'loaded'
        record['error'] = ''
        return record
    except Exception as exc:
        record['status'] = 'failed'
        record['error'] = f'{exc}\n{traceback.format_exc()}'
        try:
            if module is not None:
                unregister_fn = getattr(module, 'unregister', None)
                if callable(unregister_fn):
                    _call_module_unregister_tolerant(unregister_fn)
        except Exception:
            pass
        record['module'] = None
        return record

def ensure_record_loaded(alias: str) -> dict[str, Any] | None:
    record = get_record(alias)
    if record is None:
        return None
    status = str(record.get('status') or '')
    if status == 'loaded':
        return record
    spec = record.get('spec') or {}
    if not bool(spec.get('load', True)):
        record['status'] = 'disabled'
        return record
    if not _platform_supported(str(spec.get('outer_zip') or '')):
        record['status'] = 'unsupported_platform'
        return record
    return _load_record(record)

def ensure_record_unloaded(alias: str) -> dict[str, Any] | None:
    record = get_record(alias)
    if record is None:
        return None
    module = record.get('module')
    if module is not None:
        try:
            unregister_fn = getattr(module, 'unregister', None)
            if callable(unregister_fn):
                _call_module_unregister_tolerant(unregister_fn)
        except Exception:
            pass
    spec = record.get('spec') or {}
    if not bool(spec.get('load', True)):
        return _reset_record_runtime(record, status='disabled')
    if not _platform_supported(str(spec.get('outer_zip') or '')):
        return _reset_record_runtime(record, status='unsupported_platform')
    return _reset_record_runtime(record, status='standby')

def register_all() -> list[dict[str, Any]]:
    """Register lightweight tool records without importing integrated tools.

    Integrated tool packages are loaded only when a user runs a command, or when
    an enabled always-on feature explicitly requires that package. This keeps
    Blender startup and ordinary N-panel drawing light while preserving the
    visible tool entry points.
    """
    clear_records()
    specs = registry.build_specs(force=False)
    for spec in specs:
        record = _new_record(spec)
        if not _platform_supported(str(spec.get('outer_zip') or '')):
            record['status'] = 'unsupported_platform'
        elif not bool(spec.get('load', True)):
            record['status'] = 'disabled'
        else:
            record['status'] = 'standby'
        _RECORDS.append(record)
    return get_records()

def unregister_all() -> None:
    for record in reversed(_RECORDS):
        module = record.get('module')
        if module is None:
            continue
        try:
            unregister_fn = getattr(module, 'unregister', None)
            if callable(unregister_fn):
                _call_module_unregister_tolerant(unregister_fn)
        except Exception:
            pass
    _restore_hidden_panels()
    clear_records()
    registry.clear_cache()
