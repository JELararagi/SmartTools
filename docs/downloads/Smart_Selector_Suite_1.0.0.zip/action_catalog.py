# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Catalog-bound lazy loading of external Actions (1.10.60).

A model can move Actions out to archive .blend files and describe them in an Action catalog (JSON):

    portable_libraries: {<library name>: {relative_path, bytes, sha256}}
    external_actions:   {<action name>: {library, signature, readback_evidence, literal_text_references}}
    dynamic_references: [{text, selector, status}]      (legacy Texts that need an archived Action)

This module is the safe core.  Rules (frozen by the NY-1101 source request):

* Only a library the catalog declares, by a RELATIVE path that stays inside the catalog folder, whose
  size and SHA-256 match exactly, is ever opened.  Absolute paths, drive letters, ``..`` and links that
  leave the folder are refused.
* One Action per request; nothing is preloaded in bulk.
* No name is replaced silently: when an Action of that name already exists and does not come from the
  same library file, the request is refused before anything is linked.
* Before a target is changed, its Action, slot and the current values of every property the new
  Action animates are recorded.  A failure in the middle puts every target of the request back and
  removes what this request linked.  Restore puts the recorded state back.
* No embedded Text is executed.

The functions that touch Blender take ``data`` (``bpy.data``) as an argument and import nothing from
``bpy`` at module level, so the pure parts can be tested with mocks outside Blender.
"""

from __future__ import annotations

import hashlib
import json
import os

CATALOG_SCHEMA = 1
_HASH_CHUNK = 1 << 20

# (abs path, size, mtime_ns) -> sha256 hex (lowercase)
_SHA_CACHE: dict = {}
# abs catalog path -> (size, mtime_ns, catalog dict)
_CATALOG_CACHE: dict = {}


class CatalogError(Exception):
    """A refusal.  ``code`` is a stable machine key, ``args[0]`` the English text, ``ja`` the Japanese."""

    def __init__(self, code: str, en: str, ja: str = ''):
        super().__init__(en)
        self.code = code
        self.en = en
        self.ja = ja or en

    def text(self, ja: bool) -> str:
        return self.ja if ja else self.en


# ------------------------------------------------------------------------------------------- catalog
def _norm_hex(value) -> str:
    s = str(value or '').strip().lower()
    if len(s) != 64 or any(c not in '0123456789abcdef' for c in s):
        return ''
    return s


def parse_catalog(raw: dict, path: str) -> dict:
    """Validate the catalog structure and return a normalised copy."""
    if not isinstance(raw, dict):
        raise CatalogError('catalog_shape', 'The Action catalog is not a JSON object', 'Action カタログが JSON のオブジェクトではありません')
    if raw.get('schema') != CATALOG_SCHEMA:
        raise CatalogError('catalog_schema', 'Unsupported Action catalog schema: %r' % (raw.get('schema'),),
                           'Action カタログの schema が対応外です：%r' % (raw.get('schema'),))
    libs_in = raw.get('portable_libraries')
    acts_in = raw.get('external_actions')
    if not isinstance(libs_in, dict) or not isinstance(acts_in, dict):
        raise CatalogError('catalog_shape', 'The catalog lacks portable_libraries / external_actions',
                           'カタログに portable_libraries・external_actions がありません')
    libraries = {}
    for name, ent in libs_in.items():
        if not isinstance(ent, dict):
            continue
        sha = _norm_hex(ent.get('sha256'))
        rel = ent.get('relative_path')
        size = ent.get('bytes')
        libraries[str(name)] = {
            'relative_path': rel if isinstance(rel, str) else '',
            'bytes': size if isinstance(size, int) and not isinstance(size, bool) else None,
            'sha256': sha,
        }
    actions = {}
    for name, ent in acts_in.items():
        if not isinstance(ent, dict):
            continue
        actions[str(name)] = {
            'library': str(ent.get('library') or ''),
            'literal_text_references': [str(t) for t in (ent.get('literal_text_references') or []) if isinstance(t, str)],
        }
    dyn = []
    for ent in raw.get('dynamic_references') or []:
        if isinstance(ent, dict) and isinstance(ent.get('text'), str) and ent.get('text'):
            dyn.append({'text': ent['text'], 'selector': str(ent.get('selector') or ''), 'status': str(ent.get('status') or '')})
    return {
        'path': os.path.abspath(path),
        'dir': os.path.dirname(os.path.abspath(path)),
        'libraries': libraries,
        'actions': actions,
        'dynamic_references': dyn,
        'retained_count': len(raw.get('retained_model_actions') or []),
    }


def read_catalog(path: str) -> dict:
    """Read and validate an Action catalog; cached on (size, mtime) so the panel can call it per draw."""
    if not path:
        raise CatalogError('catalog_unset', 'No Action catalog chosen', 'Action カタログが選ばれていません')
    ap = os.path.abspath(path)
    try:
        st = os.stat(ap)
    except OSError:
        raise CatalogError('catalog_missing', 'Action catalog not found: %s' % ap, 'Action カタログがありません：%s' % ap)
    hit = _CATALOG_CACHE.get(ap)
    if hit and hit[0] == st.st_size and hit[1] == st.st_mtime_ns:
        return hit[2]
    try:
        with open(ap, 'r', encoding='utf-8-sig') as fh:
            raw = json.load(fh)
    except (OSError, ValueError) as exc:
        raise CatalogError('catalog_unreadable', 'Action catalog unreadable: %s' % exc, 'Action カタログを読めません')
    cat = parse_catalog(raw, ap)
    _CATALOG_CACHE[ap] = (st.st_size, st.st_mtime_ns, cat)
    return cat


def clear_caches() -> None:
    _SHA_CACHE.clear()
    _CATALOG_CACHE.clear()


# ------------------------------------------------------------------------------------------- library
def _within(base: str, target: str) -> bool:
    try:
        return os.path.commonpath([os.path.normcase(base), os.path.normcase(target)]) == os.path.normcase(base)
    except ValueError:
        return False


def safe_library_path(catalog: dict, library: str) -> str:
    """The absolute path of a catalog library, or CatalogError.  Never opens the file."""
    ent = catalog['libraries'].get(library)
    if ent is None:
        raise CatalogError('library_undeclared', 'Library "%s" is not declared in the catalog' % library,
                           'ライブラリ「%s」はカタログに書かれていません' % library)
    rel = ent['relative_path']
    if not rel or not ent['sha256']:
        raise CatalogError('library_entry', 'Library "%s" has no relative_path / sha256 in the catalog' % library,
                           'カタログのライブラリ「%s」に relative_path・sha256 がありません' % library)
    unified = rel.replace('\\', '/')
    drive, _rest = os.path.splitdrive(rel)
    if drive or unified.startswith('/') or os.path.isabs(rel) or ':' in unified:
        raise CatalogError('path_escape', 'Library path "%s" is absolute; only paths relative to the catalog are allowed' % rel,
                           'ライブラリのパス「%s」は絶対パスです。カタログからの相対パスだけ使えます' % rel)
    parts = [p for p in unified.split('/') if p not in ('', '.')]
    if not parts or any(p == '..' for p in parts):
        raise CatalogError('path_escape', 'Library path "%s" leaves the catalog folder' % rel,
                           'ライブラリのパス「%s」がカタログのフォルダーの外を指しています' % rel)
    base = os.path.realpath(catalog['dir'])
    full = os.path.realpath(os.path.join(base, *parts))
    if not _within(base, full):
        raise CatalogError('path_escape', 'Library path "%s" leaves the catalog folder' % rel,
                           'ライブラリのパス「%s」がカタログのフォルダーの外を指しています' % rel)
    return full


def file_sha256(path: str) -> str:
    st = os.stat(path)
    key = (path, st.st_size, st.st_mtime_ns)
    hit = _SHA_CACHE.get(key)
    if hit:
        return hit
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        while True:
            chunk = fh.read(_HASH_CHUNK)
            if not chunk:
                break
            h.update(chunk)
    value = h.hexdigest()
    _SHA_CACHE[key] = value
    return value


def verify_library(catalog: dict, library: str) -> str:
    """Resolve, then check existence, size and SHA-256.  Returns the absolute path."""
    full = safe_library_path(catalog, library)
    ent = catalog['libraries'][library]
    if not os.path.isfile(full):
        raise CatalogError('library_missing', 'Library file is missing: %s' % full, 'ライブラリのファイルがありません：%s' % full)
    size = os.path.getsize(full)
    if ent['bytes'] is not None and size != ent['bytes']:
        raise CatalogError('library_size', 'Library "%s" is %d bytes; the catalog says %d' % (library, size, ent['bytes']),
                           'ライブラリ「%s」は %d バイトで、カタログの %d と違います' % (library, size, ent['bytes']))
    actual = file_sha256(full)
    if actual != ent['sha256']:
        raise CatalogError('library_sha', 'Library "%s" SHA-256 %s does not match the catalog %s' % (library, actual[:12], ent['sha256'][:12]),
                           'ライブラリ「%s」の SHA-256（%s）がカタログ（%s）と違います' % (library, actual[:12], ent['sha256'][:12]))
    return full


def _same_file(a: str, b: str) -> bool:
    try:
        return os.path.normcase(os.path.realpath(a)) == os.path.normcase(os.path.realpath(b))
    except Exception:
        return False


def plan_load(catalog: dict, action_name: str, existing) -> dict:
    """Decide how one Action is loaded.  ``existing``: iterable of (name, library_abs_path_or_None) for
    every Action already in the file.  Refuses a name collision before anything is linked."""
    ent = catalog['actions'].get(action_name)
    if ent is None:
        raise CatalogError('action_undeclared', 'Action "%s" is not in the catalog' % action_name,
                           'Action「%s」はカタログにありません' % action_name)
    full = verify_library(catalog, ent['library'])
    reuse = False
    for name, lib in existing:
        if name != action_name:
            continue
        if lib and _same_file(lib, full):
            reuse = True
            continue
        where = lib or 'this file'
        raise CatalogError('name_collision',
                           'An Action named "%s" already exists (%s); it is not replaced. Rename or remove it first' % (action_name, where),
                           '同じ名前の Action「%s」が既にあります（%s）。置き換えません。先に名前を変えるか消してください' %
                           (action_name, 'このファイル' if not lib else lib))
    return {'action': action_name, 'library': ent['library'], 'path': full, 'reuse': reuse}


def legacy_text_blocks(catalog, script: str) -> list:
    """Texts named by the catalog's dynamic_references that ``script`` would run.  Such a legacy Text
    needs an archived Action first, so the Selector refuses it and points to the external Action section."""
    if not catalog or not script:
        return []
    hits = []
    for ent in catalog.get('dynamic_references') or []:
        name = ent.get('text') or ''
        if name and name in script and name not in hits:
            hits.append(name)
    return hits


# --------------------------------------------------------------------------- Blender side (data passed in)
def _lib_path(idb):
    lib = getattr(idb, 'library', None)
    if lib is None:
        return None
    try:
        import bpy  # noqa: WPS433 (only inside Blender)
        return os.path.abspath(bpy.path.abspath(lib.filepath, library=getattr(lib, 'library', None)))
    except Exception:
        return os.path.abspath(str(getattr(lib, 'filepath', '') or ''))


def existing_actions(data) -> list:
    return [(a.name, _lib_path(a)) for a in data.actions]


def find_action(data, name: str, lib_path):
    for a in data.actions:
        if a.name != name:
            continue
        lp = _lib_path(a)
        if (lib_path is None and lp is None) or (lib_path and lp and _same_file(lp, lib_path)):
            return a
    return None


def link_action(data, plan: dict, relative: bool):
    """Link exactly one Action from the verified library.  Returns (action, newly_linked)."""
    if plan['reuse']:
        act = find_action(data, plan['action'], plan['path'])
        if act is not None:
            return act, False
    with data.libraries.load(plan['path'], link=True, relative=relative) as (src, dst):
        if plan['action'] not in list(src.actions):
            raise CatalogError('action_absent', 'Action "%s" is not inside %s' % (plan['action'], plan['library']),
                               'Action「%s」が %s の中にありません' % (plan['action'], plan['library']))
        dst.actions = [plan['action']]
    act = find_action(data, plan['action'], plan['path'])
    if act is None or getattr(act, 'is_missing', False):
        raise CatalogError('link_failed', 'Linking Action "%s" failed' % plan['action'], 'Action「%s」をリンクできませんでした' % plan['action'])
    return act, True


# ID.id_type / ActionSlot.target_id_type -> bpy.data collection (types an Action is usually assigned to).
ID_COLLECTIONS = {
    'OBJECT': 'objects', 'KEY': 'shape_keys', 'MESH': 'meshes', 'ARMATURE': 'armatures', 'LIGHT': 'lights',
    'CAMERA': 'cameras', 'MATERIAL': 'materials', 'WORLD': 'worlds', 'CURVE': 'curves', 'NODETREE': 'node_groups',
    'SCENE': 'scenes', 'LATTICE': 'lattices', 'SPEAKER': 'speakers',
}


def _id_type(idb) -> str:
    value = getattr(idb, 'id_type', None)
    if isinstance(value, str) and value:
        return value
    rna = getattr(idb, 'bl_rna', None)
    ident = getattr(rna, 'identifier', '') if rna is not None else ''
    return 'KEY' if ident == 'Key' else 'OBJECT'


def _slot_fcurves(action, slot):
    try:
        from bpy_extras import anim_utils  # noqa: WPS433
        bag = anim_utils.action_get_channelbag_for_slot(action, slot)
    except ImportError:
        bag = None
        for layer in getattr(action, 'layers', ()):
            for strip in getattr(layer, 'strips', ()):
                bag = strip.channelbag(slot)
                if bag:
                    break
            if bag:
                break
    return list(bag.fcurves) if bag else []


def _read_value(idb, data_path: str, index: int):
    try:
        value = idb.path_resolve(data_path)
    except Exception:
        return None
    if index >= 0:
        try:
            value = value[index]
        except Exception:
            return None
    if isinstance(value, bool):
        return bool(value)
    if isinstance(value, (int, float)):
        return float(value) if isinstance(value, float) else int(value)
    return None


def _write_value(idb, data_path: str, index: int, value) -> bool:
    if '.' in data_path or '[' in data_path:
        head, _sep, tail = data_path.rpartition('.')
        if tail and '[' not in tail and head:
            try:
                owner = idb.path_resolve(head)
            except Exception:
                return False
            attr = tail
        else:
            # A path ending in a subscript (custom property ["x"]).
            cut = data_path.rfind('[')
            try:
                owner = idb.path_resolve(data_path[:cut]) if cut > 0 else idb
                key = json.loads(data_path[cut + 1:-1].replace("'", '"'))
            except Exception:
                return False
            try:
                if index >= 0:
                    owner[key][index] = value
                else:
                    owner[key] = value
                return True
            except Exception:
                return False
    else:
        owner, attr = idb, data_path
    try:
        if index >= 0:
            arr = getattr(owner, attr)
            arr[index] = value
        else:
            setattr(owner, attr, value)
        return True
    except Exception:
        return False


def check_target(idb) -> None:
    """Refuse before mutation what cannot be preserved."""
    if getattr(idb, 'library', None) is not None or getattr(idb, 'override_library', None) is not None:
        raise CatalogError('target_linked', '"%s" is linked / overridden; its Action is not changed' % idb.name,
                           '「%s」はリンク・オーバーライドなので、Action を変えません' % idb.name)
    ad = getattr(idb, 'animation_data', None)
    if ad is not None and getattr(ad, 'use_tweak_mode', False):
        raise CatalogError('target_tweak', '"%s" is in NLA tweak mode; leave it first' % idb.name,
                           '「%s」は NLA の編集中です。先に編集を終えてください' % idb.name)


def snapshot(idb, action, slot, record=None) -> dict:
    """Record (or extend) the restore state of ``idb`` before ``action``/``slot`` is assigned to it."""
    if record is None:
        ad = getattr(idb, 'animation_data', None)
        cur = getattr(ad, 'action', None) if ad is not None else None
        cur_slot = getattr(ad, 'action_slot', None) if ad is not None else None
        record = {
            'id_type': _id_type(idb),
            'id_name': idb.name,
            'had_anim': ad is not None,
            'action': [cur.name, _lib_path(cur)] if cur is not None else None,
            'slot': str(getattr(cur_slot, 'identifier', '') or '') if cur_slot is not None else '',
            # A local Action loses its only user while it is switched away and would not be saved: it is
            # kept with a fake user until Restore, which puts this flag back.
            'fake_user': bool(getattr(cur, 'use_fake_user', False)) if cur is not None and getattr(cur, 'library', None) is None else None,
            'values': [],
        }
    seen = {(v[0], v[1]) for v in record['values']}
    for fc in _slot_fcurves(action, slot):
        key = (fc.data_path, int(fc.array_index))
        if key in seen:
            continue
        val = _read_value(idb, key[0], key[1])
        if val is None:
            continue
        record['values'].append([key[0], key[1], val])
        seen.add(key)
    return record


def protect_current(idb) -> None:
    """Give the Action ``idb`` uses now a fake user, so it survives a save while switched away."""
    ad = getattr(idb, 'animation_data', None)
    cur = getattr(ad, 'action', None) if ad is not None else None
    if cur is not None and getattr(cur, 'library', None) is None and not getattr(cur, 'use_fake_user', False):
        cur.use_fake_user = True


def assign(idb, action, slot) -> None:
    ad = idb.animation_data
    if ad is None:
        ad = idb.animation_data_create()
    ad.action = action
    if slot is not None and getattr(ad, 'action_slot', None) != slot:
        ad.action_slot = slot
    if ad.action != action or (slot is not None and ad.action_slot != slot):
        raise CatalogError('assign_failed', 'Assigning "%s" to "%s" did not take' % (action.name, idb.name),
                           '「%s」を「%s」に割り当てられませんでした' % (action.name, idb.name))


def id_collection(data, id_type: str):
    name = ID_COLLECTIONS.get(str(id_type or ''))
    return getattr(data, name, None) if name else None


def resolve_id(data, record):
    coll = id_collection(data, record['id_type'])
    if coll is None:
        return None
    for idb in coll:
        if idb.name == record['id_name'] and getattr(idb, 'library', None) is None:
            return idb
    return None


def restore(data, record) -> list:
    """Put one record back.  Returns a list of problems (empty = exact)."""
    problems = []
    idb = resolve_id(data, record)
    if idb is None:
        return ['missing target %s' % record['id_name']]
    ad = getattr(idb, 'animation_data', None)
    orig = None
    if record['action']:
        orig = find_action(data, record['action'][0], record['action'][1])
        if orig is None:
            problems.append('original action %s missing' % record['action'][0])
    if ad is None and (orig is not None or record['had_anim']):
        ad = idb.animation_data_create()
    if ad is not None:
        if orig is not None:
            ad.action = orig
            if record['slot']:
                for sl in orig.slots:
                    if sl.identifier == record['slot']:
                        if ad.action_slot != sl:
                            ad.action_slot = sl
                        break
                else:
                    problems.append('slot %s missing' % record['slot'])
            if record.get('fake_user') is not None and getattr(orig, 'library', None) is None:
                orig.use_fake_user = bool(record['fake_user'])
        elif not record['action']:
            ad.action = None
            if not record['had_anim'] and not len(getattr(ad, 'drivers', ())) and not len(getattr(ad, 'nla_tracks', ())):
                idb.animation_data_clear()
    for data_path, index, value in record['values']:
        if not _write_value(idb, data_path, int(index), value):
            problems.append('value %s[%d] not written' % (data_path, int(index)))
    return problems


def remove_if_unused(data, act) -> bool:
    """Remove an Action this module linked, when nothing uses it any more; then its Library when empty."""
    if act is None or getattr(act, 'library', None) is None or act.users > 0:
        return False
    lib = act.library
    data.actions.remove(act)
    try:
        still = any(getattr(a, 'library', None) == lib for a in data.actions)
        if not still:
            for coll_name in ('objects', 'meshes', 'materials', 'node_groups', 'images', 'texts', 'collections',
                              'armatures', 'shape_keys', 'cameras', 'lights', 'worlds'):
                coll = getattr(data, coll_name, ())
                if any(getattr(i, 'library', None) == lib for i in coll):
                    still = True
                    break
        if not still:
            data.libraries.remove(lib)
    except Exception:
        pass
    return True
