# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

# Standard N-panel compatibility module.
# This module intentionally does not create host windows, proxy regions,
# custom headers, overlay draw handlers, or theme/style controls. It only keeps the small runtime API used by ui_runtime.py
# while the actual UI is registered as ordinary VIEW_3D / UI panels.

_ACTIVE_OWNER = ''


def _normalize_owner(addon_key: object = '') -> str:
    return str(addon_key or '').strip()


def _tag_redraw_all_view3d_areas() -> None:
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    except Exception:
        wm = None
    for window in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    area.tag_redraw()
            except Exception:
                pass


def prepare_panel_classes(panel_classes, addon_key: str | None = None):
    del addon_key
    return tuple(cls for cls in tuple(panel_classes or ()) if isinstance(cls, type))


def install(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int = 0, **_kwargs) -> bool:
    del label, icon, operator_id, panel_classes, order
    set_active_owner(addon_key=addon_key)
    return True


def refresh_runtime(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int = 0, **kwargs) -> bool:
    return install(addon_key, label, icon, operator_id, panel_classes, order=order, **kwargs)


def refresh_entry(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int = 0, **kwargs) -> bool:
    return install(addon_key, label, icon, operator_id, panel_classes, order=order, **kwargs)


def uninstall(addon_key: str, **_kwargs) -> bool:
    global _ACTIVE_OWNER
    if not addon_key or _ACTIVE_OWNER == _normalize_owner(addon_key):
        _ACTIVE_OWNER = ''
    _tag_redraw_all_view3d_areas()
    return True


def is_active(context=None, addon_key: str = '') -> bool:
    del context, addon_key
    return True


def set_active_owner(context=None, addon_key: str | None = None) -> None:
    global _ACTIVE_OWNER
    del context
    _ACTIVE_OWNER = _normalize_owner(addon_key)
    _tag_redraw_all_view3d_areas()


def clear_active_owner(addon_key: str = '') -> None:
    uninstall(addon_key)


def toggle_active(context=None, addon_key: str = '') -> None:
    set_active_owner(context, addon_key)


def get_active_owner(context=None) -> str:
    del context
    return _ACTIVE_OWNER


def runtime_needs_refresh(addon_key: str = '') -> bool:
    del addon_key
    return False


def runtime_has_existing_host_candidates(addon_key: str = '') -> bool:
    del addon_key
    return False


def force_runtime_refresh(preferred_owner: str | None = None, **_kwargs) -> bool:
    set_active_owner(addon_key=preferred_owner or _ACTIVE_OWNER)
    return True


def refresh_ui_runtime(context=None, addon_key: str | None = None, activate_if_properties: bool = False, **_kwargs) -> bool:
    del activate_if_properties
    if addon_key:
        set_active_owner(context, addon_key)
    else:
        _tag_redraw_all_view3d_areas()
    return True


def register_runtime(*_args, **_kwargs) -> bool:
    _tag_redraw_all_view3d_areas()
    return True


def unregister_runtime(*_args, **_kwargs) -> None:
    _tag_redraw_all_view3d_areas()


def pre_reload_cleanup(*_args, **_kwargs) -> None:
    _tag_redraw_all_view3d_areas()


__all__ = (
    'clear_active_owner',
    'force_runtime_refresh',
    'get_active_owner',
    'install',
    'is_active',
    'prepare_panel_classes',
    'pre_reload_cleanup',
    'refresh_entry',
    'refresh_runtime',
    'refresh_ui_runtime',
    'register_runtime',
    'runtime_has_existing_host_candidates',
    'runtime_needs_refresh',
    'set_active_owner',
    'toggle_active',
    'uninstall',
    'unregister_runtime',
)
