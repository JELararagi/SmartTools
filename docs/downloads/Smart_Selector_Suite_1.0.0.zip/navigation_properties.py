# SPDX-License-Identifier: GPL-3.0-or-later
"""Owner bookkeeping for SmartSelector's native Blender sidebar."""
from contextlib import suppress

import bpy

_owner = ""


def _owner_name(value):
    return str(value or "").strip()


def _redraw_views():
    manager = getattr(bpy.context, "window_manager", None)
    for window in getattr(manager, "windows", ()):
        for region in getattr(window.screen, "areas", ()):
            if region.type == "VIEW_3D":
                with suppress(ReferenceError, RuntimeError):
                    region.tag_redraw()


def prepare_panel_classes(panel_classes, addon_key=None):
    return tuple(panel for panel in (panel_classes or ()) if isinstance(panel, type))


def install(addon_key, label, icon, operator_id, panel_classes, order=0, **kwargs):
    set_active_owner(addon_key=addon_key)
    return True


refresh_runtime = refresh_entry = install


def uninstall(addon_key, **kwargs):
    if not addon_key or _owner == _owner_name(addon_key):
        _change_owner("")
    else:
        _redraw_views()
    return True


def _change_owner(owner):
    global _owner
    _owner = owner
    _redraw_views()


def set_active_owner(context=None, addon_key=None):
    _change_owner(_owner_name(addon_key))


def clear_active_owner(addon_key=""):
    uninstall(addon_key)


def toggle_active(context=None, addon_key=""):
    set_active_owner(context, addon_key)


def get_active_owner(context=None):
    return _owner


def is_active(context=None, addon_key=""):
    return True


def runtime_needs_refresh(addon_key=""):
    return False


runtime_has_existing_host_candidates = runtime_needs_refresh


def force_runtime_refresh(preferred_owner=None, **kwargs):
    set_active_owner(addon_key=preferred_owner or _owner)
    return True


def refresh_ui_runtime(context=None, addon_key=None, activate_if_properties=False, **kwargs):
    if addon_key:
        set_active_owner(context, addon_key)
    else:
        _redraw_views()
    return True


def register_runtime(*args, **kwargs):
    _redraw_views()
    return True


def unregister_runtime(*args, **kwargs):
    _redraw_views()


pre_reload_cleanup = unregister_runtime

__all__ = (
    "clear_active_owner", "force_runtime_refresh", "get_active_owner", "install",
    "is_active", "prepare_panel_classes", "pre_reload_cleanup", "refresh_entry",
    "refresh_runtime", "refresh_ui_runtime", "register_runtime",
    "runtime_has_existing_host_candidates", "runtime_needs_refresh",
    "set_active_owner", "toggle_active", "uninstall", "unregister_runtime",
)
