# Smart Selector 1.0.0

Blender 5.1.2 用。ZIP を Blender のプリファレンスからインストールし、Smart Selector のサイドバーを開きます。

- **コレクションを整理する** — 「常時機能切り替え」からコレクションマネージャーを有効にします。コレクションを表示するか、選択できるかを切り替えます。よく切り替えるコレクションは QCD スロットに割り当てられます。
- **グリースペンシルを整理する** — GP セレクトを有効にしてグリースペンシルのオブジェクトを選択します。レイヤー名、マスク、マテリアルを確認しながら操作できます。

操作手順とトラブルシューティングは Smart Selector の解説・ヘルプを参照してください。コードのライセンスは同梱のライセンス文書に記載しています。

**English** — Install the ZIP in Blender 5.1.2 and open the Smart Selector sidebar. Turn on Collection Manager for collection visibility and QCD slots, or enable GP Select to organize Grease Pencil layers. See the Smart Selector Help for the complete workflows.
