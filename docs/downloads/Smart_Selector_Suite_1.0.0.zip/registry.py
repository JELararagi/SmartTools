# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from pathlib import Path
from typing import Any

import bpy

SUITE_META = {
    'smart_selector_suite': ('Smart Selector', 'navigation_properties'),
}

SUITE_ORDER: tuple[str, ...] = tuple(SUITE_META.keys())

_TOOL_DEFS: tuple[dict[str, Any], ...] = (
    {
        'alias': 'collection_manager',
        'folder': 'collection_manager',
        'display_name': 'Collection Manager',
        'display_name_ja': 'コレクションマネージャー',
        'suite': 'smart_selector_suite',
        'suite_name': 'Smart Selector',
        'load': True,
        'enabled_default': True,
        'availability_prop': 'enable_collection_manager_tool',
        'lazy_load': True,
        'note': '',
        'duplicate_of': '',
        'superseded_by': '',
        'spaces': ['VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'],
        'abolish_legacy_sidebar': False,
        'overview_en': 'Manage scene collections, visibility restrictions, selection restrictions, holdout, indirect-only flags, and QCD slot workflows from one integrated package.',
        'overview_ja': 'シーン内コレクションの管理、表示制限、選択制限、ホールドアウト、Indirect Only、そして QCD スロット運用をまとめて扱うツールです。',
        'usage_en': 'Enable this tool from the Smart Selector N-panel Always-on Toggles, then use the quick buttons or migrated child panels. QCD remains active automatically while this suite is enabled.',
        'usage_ja': 'まずスマートセレクターの Nパネルの「常時機能切り替え」でこのツールを有効化してください。クイックボタンまたは移植済み子パネルから各機能を使えます。QCD はこのツールセットが有効な間、自動的に有効になります。',
    },
    {
        'alias': 'gp_select',
        'folder': 'gp_select',
        'display_name': 'GP Select',
        'display_name_ja': 'GP セレクト',
        'suite': 'smart_selector_suite',
        'suite_name': 'Smart Selector',
        'load': True,
        'enabled_default': True,
        'availability_prop': 'enable_gp_select_tool',
        'lazy_load': True,
        'note': '',
        'duplicate_of': '',
        'superseded_by': '',
        'spaces': ['VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'],
        'abolish_legacy_sidebar': False,
        'overview_en': 'Provides Grease Pencil selection, layer management, renaming, masking, material utilities, pass-index workflows, and rigging helpers inside the integrated Smart Selector environment.',
        'overview_ja': 'Grease Pencil 向けの選択、レイヤー管理、リネーム、マスク、マテリアル補助、パスインデックス運用、そしてリギング補助をスマートセレクター内へまとめたツールです。',
        'usage_en': 'Enable this tool from the Smart Selector N-panel Always-on Toggles, then expand the migrated GP Select panels. Use the renamed sections in order: selection and cleanup first, then layer utilities, then rigging tools when needed.',
        'usage_ja': 'まずスマートセレクターの Nパネルの「常時機能切り替え」でこのツールを有効化し、スマートセレクター内の移植済み GP Select パネルを開いてください。基本的には、選択・整理系 → レイヤー補助系 → 必要時のみリギング系、の順で使うと把握しやすい構成です。',
    },
)

_CACHE: list[dict[str, Any]] | None = None


def package_root() -> Path:
    return Path(__file__).resolve().parent


def clear_cache() -> None:
    global _CACHE
    _CACHE = None


def tool_definitions() -> list[dict[str, Any]]:
    root = package_root()
    items: list[dict[str, Any]] = []
    for definition in _TOOL_DEFS:
        folder = str(definition.get('folder') or definition.get('alias') or '').strip()
        if folder and not (root / folder).exists():
            continue
        items.append(dict(definition))
    return items


def _tool_enabled_from_always_on(availability_prop: str, default: bool = True) -> bool:
    mapping = {
        'enable_collection_manager_tool': 'collection_manager',
        'enable_gp_select_tool': 'gp_select',
    }
    alias = mapping.get(str(availability_prop or '').strip())
    if not alias:
        return bool(default)
    try:
        from . import always_on
        return bool(always_on.tool_enabled(alias, default=default))
    except Exception:
        return bool(default)

def _read_bl_info_name_and_description(py_path: Path) -> tuple[str, str]:
    try:
        text = py_path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return '', ''

    import re
    name_match = re.search(r'"name"\s*:\s*"([^"]+)"', text)
    desc_match = re.search(r'"description"\s*:\s*"([^"]+)"', text)
    return (name_match.group(1).strip() if name_match else '', desc_match.group(1).strip() if desc_match else '')


def build_specs(force: bool = False) -> list[dict[str, Any]]:
    global _CACHE
    if _CACHE is not None and not force:
        return list(_CACHE)

    root = package_root()
    results: list[dict[str, Any]] = []
    for definition in tool_definitions():
        spec = dict(definition)
        folder = str(spec.get('folder') or spec.get('alias') or '').strip()
        src_dir = root / folder
        if not src_dir.exists():
            continue
        init_relpath = '__init__.py'
        spec['src_dir'] = str(src_dir)
        spec['source_root'] = folder
        spec['import_mode'] = 'package'
        spec['init_relpath'] = init_relpath
        spec['search_root'] = folder
        spec['vendor_dir'] = str(src_dir)
        init_path = src_dir / init_relpath
        name, description = _read_bl_info_name_and_description(init_path)
        if name and not spec.get('display_name'):
            spec['display_name'] = name
        if not description:
            description = str(spec.get('overview_en') or spec.get('display_name') or folder)
        spec['description'] = description

        enabled_default = bool(spec.get('enabled_default', spec.get('load', True)))
        availability_prop = str(spec.get('availability_prop') or '').strip()
        availability_enabled = _tool_enabled_from_always_on(availability_prop, enabled_default) if availability_prop else True
        spec['load'] = bool(spec.get('load', True)) and availability_enabled
        if not spec['load'] and availability_prop:
            spec['disabled_reason'] = 'always_on'

        results.append(spec)

    _CACHE = list(results)
    return list(results)
