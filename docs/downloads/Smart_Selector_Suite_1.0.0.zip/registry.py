# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Build the optional-tool inventory from the installed Smart Selector package."""
import ast
from copy import deepcopy
from functools import cache
from pathlib import Path

SUITE_META = {"smart_selector_suite": ("Smart Selector", "navigation_properties")}
SUITE_ORDER = tuple(SUITE_META)

_SPACES = ("VIEW_3D", "IMAGE_EDITOR", "NODE_EDITOR", "SEQUENCE_EDITOR", "CLIP_EDITOR",
           "DOPESHEET_EDITOR", "GRAPH_EDITOR", "NLA_EDITOR", "TEXT_EDITOR",
           "FILE_BROWSER", "SPREADSHEET")
_FEATURES = (
    ("collection_manager", "Collection Manager", "コレクションマネージャー",
     "Manage collections, selection and visibility rules, holdout and indirect-only rendering, and QCD slots.",
     "コレクションを整理し、選択・表示の制限、ホールドアウト、間接光のみ、QCDスロットを設定します。",
     "Enable Collection Manager in Always-on Toggles. Use the quick controls for visibility or assign a QCD slot.",
     "「常時機能切り替え」でコレクションマネージャーを有効にし、表示の切り替えやQCDスロットの割り当てを行います。"),
    ("gp_select", "GP Select", "GP セレクト",
     "Select and organize Grease Pencil drawings, their layers, names, masks, materials, and pass indices. Rigging controls are also available.",
     "グリースペンシルの描画やレイヤーを選択・整理し、名前、マスク、マテリアル、パスインデックスを設定します。リグの補助操作も使えます。",
     "Enable GP Select in Always-on Toggles. Open its panel and choose an operation for the selected Grease Pencil object.",
     "「常時機能切り替え」でGPセレクトを有効にし、グリースペンシルのオブジェクトを選んでパネルから操作します。"),
)


def package_root():
    return Path(__file__).resolve().parent


def tool_definitions():
    root = package_root()
    result = []
    for alias, english, japanese, overview_en, overview_ja, usage_en, usage_ja in _FEATURES:
        if not (root / alias).is_dir():
            continue
        result.append(dict(alias=alias, folder=alias, display_name=english, display_name_ja=japanese,
                           suite=SUITE_ORDER[0], suite_name=SUITE_META[SUITE_ORDER[0]][0],
                           load=True, enabled_default=True, availability_prop=f"enable_{alias}_tool",
                           lazy_load=True, note="", duplicate_of="", superseded_by="", spaces=list(_SPACES),
                           abolish_legacy_sidebar=False, overview_en=overview_en, overview_ja=overview_ja,
                           usage_en=usage_en, usage_ja=usage_ja))
    return result


def _description(file):
    try:
        module = ast.parse(file.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, SyntaxError):
        return ""
    for statement in module.body:
        if not isinstance(statement, ast.Assign) or not isinstance(statement.value, ast.Dict):
            continue
        if not any(isinstance(target, ast.Name) and target.id == "bl_info" for target in statement.targets):
            continue
        for key, value in zip(statement.value.keys, statement.value.values):
            if isinstance(key, ast.Constant) and key.value == "description" and isinstance(value, ast.Constant):
                return str(value.value).strip()
    return ""


def _enabled(alias, default):
    try:
        from .always_on import tool_enabled
        return bool(tool_enabled(alias, default=default))
    except (AttributeError, ImportError, RuntimeError, TypeError, ValueError):
        return default


@cache
def _installed_specs():
    result = []
    root = package_root()
    for model in tool_definitions():
        alias = model["alias"]
        folder = root / alias
        initializer = "__init__.py"
        enabled = _enabled(alias, model["enabled_default"])
        model.update(src_dir=str(folder), source_root=alias, import_mode="package",
                     init_relpath=initializer, search_root=alias, vendor_dir=str(folder),
                     description=_description(folder / initializer) or model["overview_en"],
                     load=enabled)
        if not enabled:
            model["disabled_reason"] = "always_on"
        result.append(model)
    return result


def clear_cache():
    _installed_specs.cache_clear()


def build_specs(force=False):
    if force:
        clear_cache()
    return deepcopy(_installed_specs())
