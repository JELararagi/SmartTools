import json
import os
import sys
import time
import bpy
import traceback
from bpy.props import BoolProperty, FloatProperty, IntProperty, StringProperty
from bpy.types import PropertyGroup
from . import settings, utils
from .translation import exception_text, localize_class as _i18n_localize_class
_SERVER_MODULE = None
_PREFS_UI_MODULE = None
_ALWAYS_ON_MODULE = None
_SUITE_TOOLS_UI_MODULE = None
_HELP_RUNTIME_MODULE = None
_ICONS_RUNTIME_MODULE = None
_NPANEL_SUPPORTED_SPACE_TYPES = ('VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET')
_NPANEL_PANEL_ID_PREFIX_BY_SPACE = {'VIEW_3D': 'VIEW3D', 'IMAGE_EDITOR': 'IMAGE', 'NODE_EDITOR': 'NODE', 'SEQUENCE_EDITOR': 'SEQUENCER', 'CLIP_EDITOR': 'CLIP', 'DOPESHEET_EDITOR': 'DOPESHEET', 'GRAPH_EDITOR': 'GRAPH', 'NLA_EDITOR': 'NLA', 'TEXT_EDITOR': 'TEXT', 'FILE_BROWSER': 'FILEBROWSER', 'SPREADSHEET': 'SPREADSHEET'}
_NPANEL_CATEGORY = 'Smart Selector'
_NPANEL_VISIBLE_CATEGORY = 'Smart Selector'

_WARNED = set()


def _warn_once(key, msg):
    if key not in _WARNED:
        _WARNED.add(key)
        print('[Smart Selector] %s: %s' % (key, msg))


def _n_panel_owner_id() -> str:
    return str(__package__ or __name__.rsplit('.', 1)[0] or __name__ or 'smart_selector_suite').strip()
_NPANEL_EDITOR_SPECS = (('VIEW_3D', 'VIEW_3D'), ('IMAGE_EDITOR', 'IMAGE_EDITOR'), ('UV_EDITOR', 'IMAGE_EDITOR'), ('SHADER_EDITOR', 'NODE_EDITOR'), ('COMPOSITOR', 'NODE_EDITOR'), ('GEOMETRY_NODE_EDITOR', 'NODE_EDITOR'), ('TEXTURE_NODE_EDITOR', 'NODE_EDITOR'), ('VIDEO_SEQUENCER', 'SEQUENCE_EDITOR'), ('MOVIE_CLIP_EDITOR', 'CLIP_EDITOR'), ('DOPE_SHEET', 'DOPESHEET_EDITOR'), ('GRAPH_EDITOR', 'GRAPH_EDITOR'), ('DRIVERS', 'GRAPH_EDITOR'), ('NLA_EDITOR', 'NLA_EDITOR'), ('TEXT_EDITOR', 'TEXT_EDITOR'), ('ASSET_BROWSER', 'FILE_BROWSER'), ('FILE_BROWSER', 'FILE_BROWSER'), ('SPREADSHEET', 'SPREADSHEET'))
_NPANEL_SPACE_TYPE_BY_EDITOR = dict(_NPANEL_EDITOR_SPECS)
_NPANEL_EDITOR_KEYS_BY_SPACE = {}
for _editor_key, _space_type in _NPANEL_EDITOR_SPECS:
    _NPANEL_EDITOR_KEYS_BY_SPACE.setdefault(_space_type, []).append(_editor_key)
_NPANEL_SPACE_PANEL_SPECS = tuple(((space_type, tuple(editor_keys)) for space_type, editor_keys in _NPANEL_EDITOR_KEYS_BY_SPACE.items()))

def _server_runtime():
    global _SERVER_MODULE
    if _SERVER_MODULE is None:
        from . import server as _module
        _SERVER_MODULE = _module
    return _SERVER_MODULE

def _prefs_ui_runtime():
    global _PREFS_UI_MODULE
    if _PREFS_UI_MODULE is None:
        from . import preferences as _module
        _PREFS_UI_MODULE = _module
    return _PREFS_UI_MODULE

def _always_on():
    global _ALWAYS_ON_MODULE
    if _ALWAYS_ON_MODULE is None:
        from . import always_on as _module
        _ALWAYS_ON_MODULE = _module
    return _ALWAYS_ON_MODULE

def _ui_runtime():
    global _SUITE_TOOLS_UI_MODULE
    if _SUITE_TOOLS_UI_MODULE is None:
        from . import ui_runtime as _module
        _SUITE_TOOLS_UI_MODULE = _module
    return _SUITE_TOOLS_UI_MODULE

def _help_runtime():
    global _HELP_RUNTIME_MODULE
    if _HELP_RUNTIME_MODULE is None:
        from . import help as _module
        _HELP_RUNTIME_MODULE = _module
    return _HELP_RUNTIME_MODULE

def _icons_runtime():
    global _ICONS_RUNTIME_MODULE
    if _ICONS_RUNTIME_MODULE is None:
        try:
            from . import icons as _module
        except Exception:
            _module = None
        _ICONS_RUNTIME_MODULE = _module
    return _ICONS_RUNTIME_MODULE

def _icon_value(name: str) -> int:
    runtime = _icons_runtime()
    if runtime is None:
        return 0
    try:
        return int(runtime.icon_value(str(name or '').strip()) or 0)
    except Exception:
        return 0

def _icon_kwargs(name: str, fallback: str='NONE') -> dict:
    runtime = _icons_runtime()
    if runtime is not None:
        try:
            return dict(runtime.kwargs(str(name or '').strip(), fallback))
        except Exception:
            pass
    return {'icon': fallback}

class _SSS_DummyUIOperator:
    """No-op sink used when a UI operator cannot be drawn safely."""

    def __setattr__(self, _name, _value):
        return None

    def __getattr__(self, _name):
        return ''

def _safe_icon_string(icon: str, fallback: str='NONE') -> str:
    value = str(icon or fallback or 'NONE').strip() or 'NONE'
    return value if value.upper() != 'NONE' else 'NONE'

def _label_with_icon(layout, text: str, icon_name: str, fallback: str='NONE') -> None:
    label = str(text or '')
    try:
        layout.label(text=label, **_icon_kwargs(icon_name, fallback))
        return
    except Exception:
        pass
    try:
        layout.label(text=label, icon=_safe_icon_string(fallback))
        return
    except Exception:
        pass
    try:
        layout.label(text=label, icon='NONE')
    except Exception:
        pass

def _operator_with_icon(layout, operator_id: str, *, text: str='', icon_name: str='', fallback: str='NONE', **kwargs):
    label = str(text or '')
    call_kwargs = dict(kwargs)
    has_icon = bool(str(icon_name or '').strip()) or str(fallback or '').strip().upper() not in {'', 'NONE'}
    if label == '' and has_icon and (call_kwargs.get('emboss') is False):
        call_kwargs.pop('emboss', None)
    try:
        explicit_icon_value = int(call_kwargs.pop('icon_value', 0) or 0)
    except Exception:
        explicit_icon_value = 0
    icon_kwargs = {'icon_value': explicit_icon_value} if explicit_icon_value > 0 else _icon_kwargs(icon_name, fallback)
    try:
        return layout.operator(operator_id, text=label, **icon_kwargs, **call_kwargs)
    except Exception:
        pass
    try:
        call_kwargs.pop('icon_value', None)
        call_kwargs.pop('icon', None)
        return layout.operator(operator_id, text=label, icon=_safe_icon_string(fallback), **call_kwargs)
    except Exception:
        pass
    try:
        call_kwargs.pop('icon', None)
        return layout.operator(operator_id, text=label, icon='NONE', **call_kwargs)
    except Exception:
        try:
            layout.label(text=label if label else '', icon='ERROR')
        except Exception:
            pass
        return _SSS_DummyUIOperator()

def _ui_section_setting_key(section_key: str) -> str:
    key = str(section_key or '').strip()
    if not key:
        return ''
    if key.startswith('show_') or key.startswith('ui_show_'):
        return key
    clean = ''.join((ch.lower() if ch.isalnum() else '_' for ch in key)).strip('_')
    return f'ui_show_{clean}' if clean else ''

def _ui_section_state_get(section_key: str, default: bool=False) -> bool:
    key = _ui_section_setting_key(section_key)
    if not key:
        return bool(default)
    try:
        return bool(settings.get_value(key, bool(default)))
    except Exception:
        return bool(default)

def _ui_section_state_set(section_key: str, value: bool) -> None:
    key = _ui_section_setting_key(section_key)
    if not key:
        return
    try:
        settings.set_value(key, bool(value))
    except Exception:
        pass
    try:
        settings.tag_view3d_redraw()
    except Exception:
        _tag_redraw_all_view3d()

def _assign_toggle_props(op, section_key: str, label: str, default: bool=False) -> None:
    try:
        op.section_key = str(section_key or '')
        op.label = str(label or '')
        op.default_state = bool(default)
    except Exception:
        pass

def _draw_group_help_button(row, topic_id: str, *, align_right: bool=True) -> None:
    del align_right
    if not topic_id:
        return
    try:
        row.separator(factor=0.35)
    except Exception:
        pass
    try:
        help_row = row.row(align=True)
        help_row.scale_x = 0.82
        help_row.scale_y = 1.0
    except Exception:
        help_row = row
    try:
        op = help_row.operator('smart_selector_suite.show_help', text='', icon='QUESTION', emboss=True)
        op.topic_id = str(topic_id or '')
    except TypeError:
        try:
            op = help_row.operator('smart_selector_suite.show_help', text='', icon='QUESTION')
            op.topic_id = str(topic_id or '')
        except Exception:
            pass
    except Exception:
        pass

def _draw_section_toggle_header(box, *, section_key: str, label: str, icon: str='NONE', icon_name: str='', help_topic: str='', default: bool=False) -> bool:
    display = str(label or '')
    expanded = _ui_section_state_get(section_key, default)
    row = box.row(align=True)
    row.use_property_split = False
    row.use_property_decorate = False
    try:
        op = row.operator('smart_selector_suite.toggle_ui_section', text='', icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT', emboss=True, depress=expanded)
        _assign_toggle_props(op, section_key, display, default)
    except Exception:
        row.label(text='', icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT')
    icon_token = str(icon_name or _section_icon_name(icon, display) or '').strip()
    # Shared Smart Tools top-level section header: triangle, borderless
    # icon+title toggling the same section, then the small gap and the compact
    # embossed help (_draw_group_help_button adds the 0.35 gap and 0.82 row).
    title_op = _operator_with_icon(row, 'smart_selector_suite.toggle_ui_section', text=display, icon_name=icon_token, fallback=icon, emboss=False, depress=expanded)
    _assign_toggle_props(title_op, section_key, display, default)
    _draw_group_help_button(row, help_topic, align_right=True)
    return bool(expanded)

def _collapsible_section_box(layout, *, section_key: str, label: str, icon: str='NONE', icon_name: str='', help_topic: str='', default: bool=False):
    box = layout.box()
    expanded = _draw_section_toggle_header(box, section_key=section_key, label=label, icon=icon, icon_name=icon_name, help_topic=help_topic, default=default)
    if not expanded:
        return (box, None)
    body = box.column(align=True)
    body.use_property_split = False
    body.use_property_decorate = False
    return (box, body)

def _child_panel_prop_name(section_key: str) -> str:
    key = _ui_section_setting_key(section_key)
    return key if key and key.startswith('ui_show_') else ''

def _child_panel_state_owner(context=None):
    try:
        ctx = context or getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        if wm is None or not hasattr(bpy.types.WindowManager, 'smart_selector_suite_npanel_settings'):
            return None
        return getattr(wm, 'smart_selector_suite_npanel_settings', None)
    except Exception:
        return None

def _child_collapsible_section_box(layout, *, section_key: str, label: str, help_topic: str='', default: bool=False):
    """Draw a nested section only through Blender's native panel API."""
    display = str(label or '')
    prop_name = _child_panel_prop_name(section_key)
    state_owner = _child_panel_state_owner()
    header = None
    panel = None

    if state_owner is not None and prop_name and hasattr(state_owner, prop_name) and hasattr(layout, 'panel_prop'):
        try:
            header, panel = layout.panel_prop(state_owner, prop_name)
        except Exception:
            header = None
            panel = None

    if header is None:
        if not hasattr(layout, 'panel'):
            return (layout, None)
        panel_key = ''.join(ch if ch.isalnum() else '_' for ch in str(section_key or 'section'))
        try:
            header, panel = layout.panel(
                f'SSSUITE_CHILD_{panel_key}',
                default_closed=not bool(default),
            )
        except Exception:
            return (layout, None)

    header.use_property_split = False
    header.use_property_decorate = False
    try:
        header.label(text=display)
    except Exception:
        pass
    # 1.10.51: the ? help sits at the right end of the header (SmartTools common help spec 2026-10-17).
    try:
        help_lane = header.row(align=True)
        help_lane.alignment = 'RIGHT'
    except Exception:
        help_lane = header
    _draw_group_help_button(help_lane, help_topic, align_right=True)

    if panel is None:
        return (header, None)
    panel.use_property_split = False
    panel.use_property_decorate = False
    body = panel.column(align=True)
    body.use_property_split = False
    body.use_property_decorate = False
    return (header, body)

_UI_UNREGISTERING = False
_TOOLTIP_AUDIT_READY = False
_SELECTOR_FILES_CACHE = {}
_MANAGER_POLICY_LAST_SYNC = 0.0

def _can_invoke_blender_ui(context) -> bool:
    try:
        if bool(getattr(bpy.app, 'background', False)):
            return False
        if context is None:
            return False
        if getattr(context, 'window_manager', None) is None:
            return False
        if getattr(context, 'window', None) is None:
            return False
        return True
    except Exception:
        return False

# 1.10.54: width of the ? help popup.
# invoke_props_dialog(width=W) takes W in UI units: Blender draws the dialog W x scale real pixels wide, where
# scale is preferences.system.ui_scale (read-only: the effective scale = Resolution Scale x the OS display DPI).
# help.draw_help(dialog_width=P) measures the text in pixels with blf at 11 x its own scale, so it gets the same
# width expressed in those pixels: P = W x help scale.  Window.width is the window width in pixels.
# 1.10.53 opened at a fixed 820 units: 820 x 2 = 1640 pixels at scale 2, wider than a 1280-pixel window.
_HELP_POPUP_DESIRED_UNITS = 820
_HELP_POPUP_MIN_UNITS = 300
_HELP_POPUP_SIDE_MARGIN_UNITS = 32
_HELP_POPUP_LAST = None


def _help_popup_scale(context=None) -> float:
    """Effective UI scale (preferences.system.ui_scale); 1.0 when Blender has not set it (background)."""
    try:
        prefs = getattr(context, 'preferences', None) or bpy.context.preferences
        value = float(getattr(getattr(prefs, 'system', None), 'ui_scale', 0.0) or 0.0)
    except Exception:
        value = 0.0
    return value if value > 0.0 else 1.0


def _help_measure_scale(context=None) -> float:
    """The scale help.py measures its text with (its own _ui_scale), so both sides use one number."""
    try:
        fn = getattr(_help_runtime(), '_ui_scale', None)
        if callable(fn):
            value = float(fn(context))
            if value > 0.0:
                return value
    except Exception:
        pass
    return max(0.75, min(_help_popup_scale(context), 2.5))


def help_popup_width(context=None) -> dict:
    """Width of the ? help popup for this window and UI scale.

    units: the width given to invoke_props_dialog (UI units).
    dialog_px: the real width of the dialog in pixels (units x scale).
    help_px: the same width given to help.draw_help (units x the scale help measures text with).
    The dialog is at most the desired 820 units and never wider than the window minus a margin on both sides.
    Without a window (background) it is the desired 820 units, as in 1.10.53.
    Minimum 300 units (the help body needs 116 units of padding + 180 pixels of text); only a window narrower
    than that minimum plus the margins gets a dialog as wide as the window allows.
    """
    scale = _help_popup_scale(context)
    try:
        window_px = int(getattr(getattr(context, 'window', None), 'width', 0) or 0)
    except Exception:
        window_px = 0
    units = _HELP_POPUP_DESIRED_UNITS
    available_units = None
    if window_px > 0:
        available_units = int(window_px / scale) - 2 * _HELP_POPUP_SIDE_MARGIN_UNITS
        units = min(_HELP_POPUP_DESIRED_UNITS, max(_HELP_POPUP_MIN_UNITS, available_units))
        if available_units < _HELP_POPUP_MIN_UNITS:
            units = max(1, available_units)
    measure = _help_measure_scale(context)
    return {
        'units': int(units),
        'dialog_px': int(round(units * scale)),
        'help_px': int(round(units * measure)),
        'scale': scale,
        'measure_scale': measure,
        'window_px': window_px,
        'available_units': available_units,
    }


def _safe_invoke_props_dialog(operator, context, *, width=360):
    if not _can_invoke_blender_ui(context):
        return {'CANCELLED'}
    try:
        return context.window_manager.invoke_props_dialog(operator, width=width)
    except Exception:
        return {'CANCELLED'}

def _safe_invoke_confirm(operator, context, event):
    if not _can_invoke_blender_ui(context):
        return {'CANCELLED'}
    try:
        return context.window_manager.invoke_confirm(operator, event)
    except Exception:
        return {'CANCELLED'}

def _ui_runtime_alive() -> bool:
    return not bool(_UI_UNREGISTERING)

def _scene_has_active_project_prop(scene) -> bool:
    return scene is not None and hasattr(scene, 'smart_selector_suite_active_project')

def _scene_has_favorites_prop(scene) -> bool:
    return scene is not None and hasattr(scene, 'smart_selector_suite_show_favorites_only')

def _safe_scene_project(scene) -> str:
    value = str(getattr(scene, 'smart_selector_suite_active_project', '') or 'Default_Project')
    try:
        return utils.sanitize_name(value, 'Default_Project')
    except Exception:
        return value or 'Default_Project'

def _safe_scene_show_favorites_only(scene) -> bool:
    return bool(getattr(scene, 'smart_selector_suite_show_favorites_only', False))

def _ensure_lazy_tooltip_audit() -> None:
    global _TOOLTIP_AUDIT_READY
    if _TOOLTIP_AUDIT_READY:
        return
    try:
        from . import tooltip_audit as _tooltip_audit
        ensure_audit = getattr(_tooltip_audit, 'ensure_runtime_audit', None)
        if callable(ensure_audit):
            ensure_audit()
    except Exception:
        pass
    _TOOLTIP_AUDIT_READY = True

def _set_scene_active_project(scene, value: str):
    if _scene_has_active_project_prop(scene):
        try:
            clean_value = utils.sanitize_name(str(value or 'Default_Project'), 'Default_Project')
        except Exception:
            clean_value = str(value or 'Default_Project')
        scene.smart_selector_suite_active_project = clean_value
        try:
            _refresh_selector_files_cache(scene)
        except Exception:
            pass

def _get_blender_lang_code() -> str:
    try:
        lang = str(getattr(bpy.context.preferences.view, 'language', '') or '').strip()
        if lang and lang != 'DEFAULT':
            return lang
    except Exception:
        pass
    try:
        return str(getattr(bpy.app.translations, 'locale', '') or '').strip()
    except Exception:
        return ''

def _is_japanese() -> bool:
    return _get_blender_lang_code().lower().startswith('ja')

def tr_iface(key: str, fallback: str=None) -> str:
    txt = bpy.app.translations.pgettext_iface(key)
    if txt != key:
        return txt
    return fallback if fallback is not None else key

def tr_tip(key: str, fallback: str=None) -> str:
    txt = bpy.app.translations.pgettext_tip(key)
    if txt != key:
        return txt
    return fallback if fallback is not None else key

def current_lang() -> str:
    return 'ja' if _is_japanese() else 'en'

def _lang_text(en: str, ja: str) -> str:
    return str(ja if _is_japanese() else en)
_LOCALIZED_STRING_DEFAULTS = {'bridge_exec_script_payload': ('{"script":"print("Hello Smart Selector")"}', '{"script":"print("スマートセレクターからこんにちは")"}')}

def _localized_string_default(key: str, default: str) -> str:
    pair = _LOCALIZED_STRING_DEFAULTS.get(str(key or '').strip())
    if pair:
        return _lang_text(pair[0], pair[1])
    return str(default or '')

def _persisted_string_getter(key: str, default: str):

    def _getter(_self):
        try:
            if not settings.has_saved_value(key):
                return _localized_string_default(key, default)
        except Exception:
            pass
        return str(settings.get_value(key, _localized_string_default(key, default)) or '')
    return _getter

def _persisted_string_setter(key: str):

    def _setter(_self, value):
        settings.set_value(key, str(value if value is not None else ''))
        try:
            _prefs_ui_runtime()._queue_user_preferences_save()
        except Exception:
            pass
        settings.tag_view3d_redraw()
    return _setter

def _root_dir_setter(_self, value):
    _persisted_string_setter('root_dir')(_self, value)
    # The active project must exist under the new root; otherwise it would stay listed nowhere and a save would recreate it empty.
    scene = getattr(bpy.context, 'scene', None)
    if not _scene_has_active_project_prop(scene):
        return
    try:
        if utils.find_existing_project_dir(_safe_scene_project(scene)) is None:
            _set_scene_active_project(scene, (utils.list_projects() or ['Default_Project'])[0])
        else:
            _refresh_selector_files_cache(scene)
    except Exception:
        pass

def _persisted_bool_getter(key: str, default: bool):

    def _getter(_self):
        return bool(settings.get_value(key, bool(default)))
    return _getter

def _persisted_bool_setter(key: str):

    def _setter(_self, value):
        settings.set_value(key, bool(value))
        try:
            _prefs_ui_runtime()._queue_user_preferences_save()
        except Exception:
            pass
        settings.tag_view3d_redraw()
    return _setter

def _persisted_float_getter(key: str, default: float):

    def _getter(_self):
        try:
            return float(settings.get_value(key, float(default)))
        except Exception:
            return float(default)
    return _getter

def _persisted_float_setter(key: str):

    def _setter(_self, value):
        try:
            settings.set_value(key, float(value))
        except Exception:
            settings.set_value(key, 0.0)
        try:
            _prefs_ui_runtime()._queue_user_preferences_save()
        except Exception:
            pass
        settings.tag_view3d_redraw()
    return _setter

def _persisted_int_getter(key: str, default: int):

    def _getter(_self):
        try:
            return int(settings.get_value(key, int(default)))
        except Exception:
            return int(default)
    return _getter

def _persisted_int_setter(key: str):

    def _setter(_self, value):
        try:
            settings.set_value(key, int(value))
        except Exception:
            settings.set_value(key, 0)
        try:
            _prefs_ui_runtime()._queue_user_preferences_save()
        except Exception:
            pass
        settings.tag_view3d_redraw()
    return _setter

def _tag_redraw_all_view3d():
    try:
        supported = set(_NPANEL_SUPPORTED_SPACE_TYPES)
        for wm in bpy.data.window_managers:
            for window in wm.windows:
                screen = window.screen
                if not screen:
                    continue
                for area in screen.areas:
                    if str(getattr(area, 'type', '') or '') in supported:
                        area.tag_redraw()
    except Exception:
        pass

def _smart_tools_manager_modules():
    modules = []
    try:
        for name, module in list(sys.modules.items()):
            lname = str(name or '').lower()
            if lname.endswith('smart_tools_manager.manager') or lname.endswith('smart_tools_manager'):
                modules.append(module)
    except Exception:
        pass
    return tuple(modules)

def _smart_tools_manager_module():
    """Return the Manager implementation module, not only its package shell.

    Python normally inserts the ``smart_tools_manager`` package into
    ``sys.modules`` before ``smart_tools_manager.manager``. Returning the first
    match can therefore select a package object that does not expose the
    workspace/editor rule API and silently makes every Smart Selector panel
    visible. Prefer the concrete module that owns the read-only rule helpers.
    """
    modules = _smart_tools_manager_modules()
    if not modules:
        return None
    candidates = []
    for module in modules:
        if module is None:
            continue
        candidates.append(module)
        try:
            nested = getattr(module, 'manager', None)
        except Exception:
            nested = None
        if nested is not None and nested not in candidates:
            candidates.append(nested)

    def _score(module) -> int:
        score = 0
        name = str(getattr(module, '__name__', '') or '').lower()
        if name.endswith('.manager'):
            score += 16
        for attribute in ('_rule_value', '_context_editor_key', '_active_workspace_key', '_load_settings'):
            try:
                if callable(getattr(module, attribute, None)):
                    score += 4
            except Exception:
                pass
        return score
    return max(candidates, key=_score)

def _ensure_manager_policy_current(*, force: bool=False) -> None:
    """Compatibility no-op; Smart Tools Manager owns event-driven repair."""
    del force
    return None

def _area_text(value, *names) -> str:
    for name in names:
        try:
            found = getattr(value, name, None)
        except Exception:
            found = None
        if found is not None:
            text = str(found or '').strip().upper()
            if text:
                return text
    return ''

def _active_space_for_area(area):
    try:
        spaces = getattr(area, 'spaces', None)
        active = getattr(spaces, 'active', None)
        if active is not None:
            return active
        if spaces:
            return spaces[0]
    except Exception:
        pass
    return None

def _context_space_type(context) -> str:
    area = getattr(context, 'area', None) if context is not None else None
    space = _active_space_for_area(area)
    space_type = _area_text(space, 'type')
    area_type = _area_text(area, 'type')
    return space_type or area_type

def _panel_space_type(cls) -> str:
    return str(getattr(cls, '_sssuite_space_type', '') or getattr(cls, 'bl_space_type', '') or '').strip().upper()

def _context_matches_panel_space(context, space_type: str) -> bool:
    space_type = str(space_type or '').strip().upper()
    if not space_type:
        return False
    area = getattr(context, 'area', None) if context is not None else None
    if area is None:
        return True
    return _context_space_type(context) == space_type

def _area_matches_editor_fallback(area, editor_key: str) -> bool:
    editor_key = str(editor_key or '').strip().upper()
    area_type = _area_text(area, 'type')
    area_ui_type = _area_text(area, 'ui_type')
    space = _active_space_for_area(area)
    space_type = _area_text(space, 'type')
    actual = space_type or area_type
    tree_type = _area_text(space, 'tree_type') or area_ui_type
    image_mode = _area_text(space, 'mode', 'ui_mode') or area_ui_type
    graph_mode = _area_text(space, 'mode', 'ui_mode') or area_ui_type
    dopesheet_mode = _area_text(space, 'mode', 'ui_mode') or area_ui_type
    sequence_mode = _area_text(space, 'view_type', 'display_mode', 'mode')
    browse_mode = _area_text(space, 'browse_mode', 'mode') or _area_text(getattr(space, 'params', None), 'browse_mode') or area_ui_type
    if editor_key == 'VIEW_3D':
        return actual == 'VIEW_3D'
    if editor_key == 'IMAGE_EDITOR':
        return actual == 'IMAGE_EDITOR' and image_mode not in {'UV', 'UV_EDIT', 'UVS', 'UV_EDITOR'} and (area_ui_type not in {'UV', 'UV_EDIT', 'UVS', 'UV_EDITOR'})
    if editor_key == 'UV_EDITOR':
        return actual == 'IMAGE_EDITOR' and (image_mode in {'UV', 'UV_EDIT', 'UVS', 'UV_EDITOR'} or area_ui_type in {'UV', 'UV_EDIT', 'UVS', 'UV_EDITOR'})
    if editor_key == 'SHADER_EDITOR':
        node_type = tree_type or area_ui_type
        return actual == 'NODE_EDITOR' and (not node_type or node_type in {'SHADERNODETREE', 'SHADER', 'SHADER_NODE_TREE'})
    if editor_key == 'COMPOSITOR':
        node_type = tree_type or area_ui_type
        return actual == 'NODE_EDITOR' and node_type in {'COMPOSITORNODETREE', 'COMPOSITOR', 'COMPOSITOR_NODE_TREE'}
    if editor_key == 'GEOMETRY_NODE_EDITOR':
        node_type = tree_type or area_ui_type
        return actual == 'NODE_EDITOR' and node_type in {'GEOMETRYNODETREE', 'GEOMETRY', 'GEOMETRY_NODE_TREE'}
    if editor_key == 'TEXTURE_NODE_EDITOR':
        node_type = tree_type or area_ui_type
        return actual == 'NODE_EDITOR' and node_type in {'TEXTURENODETREE', 'TEXTURE', 'TEXTURE_NODE_TREE'}
    if editor_key == 'VIDEO_SEQUENCER':
        return actual == 'SEQUENCE_EDITOR' and sequence_mode not in {'PREVIEW'}
    if editor_key == 'MOVIE_CLIP_EDITOR':
        return actual == 'CLIP_EDITOR'
    if editor_key == 'DOPE_SHEET':
        return actual == 'DOPESHEET_EDITOR' and dopesheet_mode not in {'DRIVERS', 'DRIVER', 'TIMELINE'} and (area_ui_type not in {'DRIVERS', 'DRIVER', 'TIMELINE'})
    if editor_key == 'GRAPH_EDITOR':
        return actual == 'GRAPH_EDITOR' and graph_mode not in {'DRIVERS', 'DRIVER'} and (area_ui_type not in {'DRIVERS', 'DRIVER'})
    if editor_key == 'DRIVERS':
        return actual == 'GRAPH_EDITOR' and (graph_mode in {'DRIVERS', 'DRIVER'} or area_ui_type in {'DRIVERS', 'DRIVER'})
    if editor_key == 'NLA_EDITOR':
        return actual == 'NLA_EDITOR'
    if editor_key == 'TEXT_EDITOR':
        return actual == 'TEXT_EDITOR'
    if editor_key == 'ASSET_BROWSER':
        return actual == 'FILE_BROWSER' and (browse_mode in {'ASSETS', 'ASSET_BROWSER'} or area_ui_type in {'ASSETS', 'ASSET_BROWSER'})
    if editor_key == 'FILE_BROWSER':
        return actual == 'FILE_BROWSER' and browse_mode not in {'ASSETS', 'ASSET_BROWSER'} and (area_ui_type not in {'ASSETS', 'ASSET_BROWSER'})
    if editor_key == 'SPREADSHEET':
        return actual == 'SPREADSHEET'
    return False

def _context_editor_key_fallback(context) -> str:
    area = getattr(context, 'area', None) if context is not None else None
    if area is not None:
        for editor_key, _space_type in _NPANEL_EDITOR_SPECS:
            try:
                if _area_matches_editor_fallback(area, editor_key):
                    return editor_key
            except Exception:
                continue
    space_type = _context_space_type(context)
    candidates = _NPANEL_EDITOR_KEYS_BY_SPACE.get(space_type, ())
    return str(candidates[0] if candidates else '').strip().upper()

def _context_editor_key(context) -> str:
    manager = _smart_tools_manager_module()
    current = getattr(manager, '_context_editor_key', None) if manager is not None else None
    if callable(current):
        try:
            key = str(current(context) or '').strip().upper()
            if key:
                return key
        except Exception:
            pass
    return _context_editor_key_fallback(context)

def _manager_rule_value(manager, workspace_key: str, editor_key: str) -> bool | None:
    if manager is None or not workspace_key or (not editor_key):
        return None
    rule = getattr(manager, '_rule_value', None)
    if callable(rule):
        try:
            return bool(rule(workspace_key, editor_key, 'SMART_SELECTOR'))
        except Exception:
            return None
    try:
        load = getattr(manager, '_load_settings', None)
        if callable(load):
            data = load()
            return bool(((data.get('rules') or {}).get(workspace_key) or {}).get(editor_key, {}).get('SMART_SELECTOR', False))
    except Exception:
        pass
    return None

def _manager_workspace_key(manager, context) -> str:
    active_workspace_key = getattr(manager, '_active_workspace_key', None) if manager is not None else None
    if callable(active_workspace_key):
        try:
            key = str(active_workspace_key(context) or '').strip().upper()
            if key:
                return key
        except Exception:
            pass
    try:
        workspace = getattr(context, 'workspace', None)
        name = str(getattr(workspace, 'name', '') or '').strip().upper().replace(' ', '_')
        return name
    except Exception:
        return ''

def _manager_allows_current_panel(context, panel_cls=None) -> bool:
    manager = _smart_tools_manager_module()
    if manager is None:
        return True
    workspace_key = _manager_workspace_key(manager, context)
    if not workspace_key:
        return True
    editor_key = _context_editor_key(context)
    if editor_key:
        value = _manager_rule_value(manager, workspace_key, editor_key)
        if value is not None:
            return bool(value)
    space_type = _panel_space_type(panel_cls) if panel_cls is not None else _context_space_type(context)
    any_known = False
    for candidate in _NPANEL_EDITOR_KEYS_BY_SPACE.get(space_type, ()):
        value = _manager_rule_value(manager, workspace_key, candidate)
        if value is None:
            continue
        any_known = True
        if value:
            return True
    return True if not any_known else False

def _panel_editor_key(cls) -> str:
    key = str(getattr(cls, '_sssuite_editor_key', '') or '').strip().upper()
    if key:
        return key
    keys = _NPANEL_EDITOR_KEYS_BY_SPACE.get(_panel_space_type(cls), ())
    return str(keys[0] if keys else 'VIEW_3D')

def _get_prefs(context=None):
    try:
        ctx = context or getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        if wm is not None and hasattr(bpy.types.WindowManager, 'smart_selector_suite_npanel_settings'):
            value = getattr(wm, 'smart_selector_suite_npanel_settings', None)
            if value is not None:
                return value
    except Exception:
        pass
    return utils.get_prefs()

def _available_projects():
    prefs = _get_prefs()
    include_archived = bool(getattr(prefs, 'show_archived_projects', False)) if prefs is not None else False
    try:
        projects = list(utils.list_projects(include_archived=include_archived))
    except Exception:
        projects = []
    normalized = []
    for project_name in projects:
        name = str(project_name or '').strip()
        if not name:
            continue
        if name not in normalized:
            normalized.append(name)
    if not normalized:
        normalized.append('Default_Project')
    return normalized

def _json_load(s: str, default):
    try:
        return json.loads(s) if s else default
    except Exception:
        return default

def _payload_dict(operator, payload: str) -> dict:
    try:
        data = json.loads(payload or '{}')
    except Exception as exc:
        try:
            operator.report({'ERROR'}, _lang_text(f'Invalid JSON payload: {exc}', 'JSONペイロードが無効です。'))
        except Exception:
            pass
        return {}
    if not isinstance(data, dict):
        try:
            operator.report({'ERROR'}, _lang_text('JSON payload must be an object.', 'JSONペイロードはオブジェクト形式である必要があります。'))
        except Exception:
            pass
        return {}
    return data

def _payload_bool(value, default: bool=False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return bool(default)
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        text = value.strip().lower()
        if text in {'1', 'true', 'yes', 'on', 'y'}:
            return True
        if text in {'0', 'false', 'no', 'off', 'n', 'none', 'null', ''}:
            return False
    return bool(default)

def _payload_string_list(value) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        text = value.strip()
        return [text] if text else []
    if isinstance(value, (list, tuple, set)):
        result = []
        for item in value:
            text = str(item).strip()
            if text:
                result.append(text)
        return result
    text = str(value).strip()
    return [text] if text else []

def _payload_int_list(value) -> list[int]:
    if value is None:
        return []
    if isinstance(value, str):
        parts = [p.strip() for p in value.replace(';', ',').split(',')]
    elif isinstance(value, (list, tuple, set)):
        parts = list(value)
    else:
        parts = [value]
    result = []
    for item in parts:
        try:
            result.append(int(item))
        except Exception:
            pass
    return result

def _payload_string(value, default: str='') -> str:
    try:
        text = str(value if value is not None else '').strip()
    except Exception:
        text = ''
    return text if text else str(default or '')

def _bridge_warning(op, message: str) -> None:
    """WARNING report that also reaches the browser (bpy.ops keeps WARNING reports in the console only)."""
    op.report({'WARNING'}, message)
    utils.note_bridge_warning(message)

def _data_path_refusal_text(exc) -> str:
    reason = str(getattr(exc, 'reason', '') or '')
    path = str(getattr(exc, 'path', '') or '')
    type_name = str(getattr(exc, 'type_name', '') or '')
    if reason == 'string':
        return _lang_text(f'Data path "{path}" holds text; sliders only change boolean, integer and float values.', f'データパス「{path}」は文字列です。スライダーで変更できるのはブール値・整数・浮動小数点数だけです。')
    if reason == 'enum':
        return _lang_text(f'Data path "{path}" is an enum; sliders only change boolean, integer and float values.', f'データパス「{path}」は列挙型です。スライダーで変更できるのはブール値・整数・浮動小数点数だけです。')
    if reason == 'array':
        return _lang_text(f'Data path "{path}" is an array; add an index such as [0].', f'データパス「{path}」は配列です。[0] のようにインデックスを付けてください。')
    if reason == 'non_finite':
        return _lang_text('The slider value must be a finite number.', 'スライダーの値は有限の数値である必要があります。')
    return _lang_text(f'Data path "{path}" holds a {type_name} value that a slider cannot set.', f'データパス「{path}」の値（{type_name}）はスライダーで設定できません。')

def _json_dump(obj) -> str:
    try:
        return json.dumps(obj, ensure_ascii=False)
    except Exception:
        return '{}'

def _get_fav_map(prefs):
    return _json_load(getattr(prefs, 'favorite_selectors_json', '{}'), {})

def _set_fav_map(prefs, data):
    try:
        prefs.favorite_selectors_json = _json_dump(data)
        try:
            from . import preferences as _prefs_runtime
            queue_save = getattr(_prefs_runtime, '_queue_user_preferences_save', None)
            if callable(queue_save):
                queue_save()
        except Exception:
            pass
    except Exception:
        pass

def _favorite_name_set(project: str, prefs=None, fav_map=None) -> set[str]:
    prefs = prefs or _get_prefs()
    if not prefs:
        return set()
    if fav_map is None:
        fav_map = _get_fav_map(prefs)
    try:
        return set(fav_map.get(project, []))
    except Exception:
        return set()

def is_favorite(project: str, filename: str) -> bool:
    return filename in _favorite_name_set(project)

def toggle_favorite(project: str, filename: str) -> bool:
    prefs = _get_prefs()
    if not prefs:
        return False
    mp = _get_fav_map(prefs)
    s = set(mp.get(project, []))
    if filename in s:
        s.remove(filename)
        on = False
    else:
        s.add(filename)
        on = True
    mp[project] = sorted(list(s))
    _set_fav_map(prefs, mp)
    return on

class SSSUITE_OT_show_help(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.show_help'
    bl_label = 'Smart Selector Help'
    bl_options = {'INTERNAL'}
    topic_id: StringProperty(description='Function: supplies the Topic ID parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.', name='Help Topic', default='smart_selector', options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        return _lang_text('Open detailed help for this Smart Selector group.', 'このスマートセレクターのグループの詳細ヘルプを開きます。')

    def invoke(self, context, event):
        try:
            _help_runtime().prepare_topic(str(getattr(self, 'topic_id', '') or 'smart_selector'))
        except Exception:
            pass
        if not _can_invoke_blender_ui(context):
            return self.execute(context)
        global _HELP_POPUP_LAST
        width = help_popup_width(context)
        _HELP_POPUP_LAST = width
        try:
            self._ss_help_width = width
        except Exception:
            pass
        try:
            return context.window_manager.invoke_props_dialog(self, width=width['units'])
        except Exception:
            return self.execute(context)

    def draw(self, context):
        _ensure_manager_policy_current(force=True)
        layout = self.layout
        # 1.10.54: the body is wrapped at the width the dialog was opened with (the same units, in help pixels).
        width = getattr(self, '_ss_help_width', None) or _HELP_POPUP_LAST or help_popup_width(context)
        try:
            _help_runtime().draw_help(layout, str(getattr(self, 'topic_id', '') or 'smart_selector'), context=context, dialog_width=width['help_px'])
        except Exception as exc:
            box = layout.box()
            box.alert = True
            box.label(text=_lang_text(f'Help draw failed: {exc}', 'ヘルプを表示できませんでした。'), icon='ERROR')

    def execute(self, context):
        return {'FINISHED'}

class SSSUITE_OT_open_project_folder(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.open_project_folder'
    bl_label = 'Open Project Folder'

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_open_project_folder', 'Open this project folder on disk (where selector .json files and images are stored). Use this for backup, copy, or manual file management.')

    def execute(self, context):
        folder = utils.get_project_dir(_safe_scene_project(getattr(context, 'scene', None)))
        try:
            if hasattr(os, 'startfile'):
                os.startfile(folder)
            else:
                import subprocess, sys
                if sys.platform == 'darwin':
                    subprocess.Popen(['open', folder])
                else:
                    subprocess.Popen(['xdg-open', folder])
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, _lang_text(f'Could not open project folder: {exc}', 'プロジェクトフォルダーを開けませんでした。'))
            return {'CANCELLED'}

class SSSUITE_OT_set_active_project(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.set_active_project'
    bl_label = 'Set Active Project'
    bl_options = {'UNDO', 'INTERNAL'}
    project_name: StringProperty(name='Project', default='Default_Project', description='Function: supplies the project folder name that will become active in Smart Selector. How to use: the project picker fills this automatically when you choose a project; manual editing is normally unnecessary. The chosen project is saved according to N-panel State Save and restored after Blender restarts or scene changes.')

    @classmethod
    def description(cls, context, properties):
        project_name = str(getattr(properties, 'project_name', '') or '').strip()
        if project_name:
            return tr_tip('tt_set_active_project', f'Switch the active Project to “{project_name}”.')
        return tr_tip('tt_set_active_project', 'Switch the active Project shown in Smart Selector.')

    @classmethod
    def poll(cls, context):
        return _ui_runtime_alive() and getattr(context, 'scene', None) is not None

    def execute(self, context):
        project_name = str(getattr(self, 'project_name', '') or '').strip()
        if not project_name:
            return {'CANCELLED'}
        try:
            _set_scene_active_project(getattr(context, 'scene', None), project_name)
        except Exception:
            return {'CANCELLED'}
        _tag_redraw_area(getattr(context, 'area', None))
        _tag_redraw_all_view3d()
        return {'FINISHED'}

class SSSUITE_MT_project_list(bpy.types.Menu):
    bl_label = 'Project List'
    bl_idname = 'SMART_SELECTOR_SUITE_MT_project_list'

    def draw(self, context):
        _ensure_manager_policy_current(force=True)
        layout = self.layout
        scene = getattr(context, 'scene', None)
        current_project = _safe_scene_project(scene)
        for project_name in _available_projects():
            active = project_name == current_project
            op = _operator_with_icon(layout, 'smart_selector_suite.set_active_project', text=project_name, icon_name='apply' if active else 'project', fallback='RADIOBUT_ON' if active else 'RADIOBUT_OFF', translate=False)
            op.project_name = project_name

class SSSUITE_OT_project_create(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.project_create'
    bl_label = 'Create Project'
    bl_options = {'UNDO', 'INTERNAL'}
    new_name: StringProperty(name='Project Name', default='New_Project', description='Function: sets the folder name for a new Smart Selector project. How to use: enter a safe project name, then confirm the dialog; the folder is created inside the current project root, which defaults to CONFIG/Smart_Selector_Suite unless a manual root directory is set.')

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_project_create', 'Create a new Project (a job folder). Each Project keeps its own selector .json files and images so different jobs do not get mixed.')

    def invoke(self, context, event):
        self.new_name = 'New_Project'
        return _safe_invoke_props_dialog(self, context, width=360)

    def execute(self, context):
        try:
            name = utils.create_project(self.new_name)
            _set_scene_active_project(getattr(context, 'scene', None), name)
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, exception_text(e))
            return {'CANCELLED'}

class SSSUITE_OT_project_rename(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.project_rename'
    bl_label = 'Rename Project'
    bl_options = {'UNDO', 'INTERNAL'}
    new_name: StringProperty(name='New Name', default='', description='Function: sets the destination folder name when renaming the active Smart Selector project. How to use: enter the new name and confirm; selector JSON files and images stay inside the renamed folder. Existing projects are not overwritten.')

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_project_rename', 'Rename the current Project folder on disk. All selector .json files and images stay inside the renamed folder.')

    def invoke(self, context, event):
        self.new_name = _safe_scene_project(getattr(context, 'scene', None))
        return _safe_invoke_props_dialog(self, context, width=360)

    def execute(self, context):
        try:
            old = _safe_scene_project(getattr(context, 'scene', None))
            new = utils.rename_project(old, self.new_name)
            _set_scene_active_project(getattr(context, 'scene', None), new)
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, exception_text(e))
            return {'CANCELLED'}

class SSSUITE_OT_project_duplicate(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.project_duplicate'
    bl_label = 'Duplicate Project'
    bl_options = {'UNDO', 'INTERNAL'}
    new_name: StringProperty(name='New Project Name', default='', description='Function: sets the folder name created by Duplicate Project. How to use: enter the copy name and confirm; all selector JSON files and images from the active project are copied into the new folder without changing the original project.')

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_project_duplicate', 'Duplicate the current Project folder (all selectors and images) into a new Project name. Useful for making a backup or creating variations.')

    def invoke(self, context, event):
        base = _safe_scene_project(getattr(context, 'scene', None))
        self.new_name = base + '_copy'
        return _safe_invoke_props_dialog(self, context, width=360)

    def execute(self, context):
        try:
            src = _safe_scene_project(getattr(context, 'scene', None))
            new = utils.duplicate_project(src, self.new_name)
            _set_scene_active_project(getattr(context, 'scene', None), new)
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, exception_text(e))
            return {'CANCELLED'}

class SSSUITE_OT_project_archive(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.project_archive'
    bl_label = 'Archive Project'
    bl_options = {'UNDO', 'INTERNAL'}

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_project_archive', 'Archive this Project by moving it into the __ARCHIVE__ folder. Archived projects are hidden by default; enable “Show Archived Projects” in Smart Selector N-panel Settings to show them again.')

    def invoke(self, context, event):
        return _safe_invoke_confirm(self, context, event)

    def execute(self, context):
        try:
            name = _safe_scene_project(getattr(context, 'scene', None))
            utils.archive_project(name)
            _set_scene_active_project(getattr(context, 'scene', None), 'Default_Project')
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, exception_text(e))
            return {'CANCELLED'}

class SSSUITE_OT_toggle_favorite(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.toggle_favorite'
    bl_label = 'Toggle Favorite'
    bl_options = {'UNDO', 'INTERNAL'}
    filename: StringProperty(description='Function: supplies the Filename parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_toggle_favorite', 'Toggle Favorite (star) for this selector. Favorites are saved per Project and can be filtered using “Favorites Only”.')

    def execute(self, context):
        project = _safe_scene_project(getattr(context, 'scene', None))
        toggle_favorite(project, self.filename)
        try:
            context.area.tag_redraw()
        except Exception:
            pass
        _tag_redraw_all_view3d()
        return {'FINISHED'}

class SSSUITE_OT_project_pick_search(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.project_pick_search'
    bl_label = 'Project List'
    bl_options = {'INTERNAL'}

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_project_pick_search', 'Open the Project list popup and choose the active Project. This keeps registration stable on Blender 5.1 while still letting you switch projects from the same button.')

    @classmethod
    def poll(cls, context):
        return _ui_runtime_alive() and getattr(context, 'scene', None) is not None

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        try:
            bpy.ops.wm.call_menu(name='SMART_SELECTOR_SUITE_MT_project_list')
        except Exception:
            return {'CANCELLED'}
        return {'FINISHED'}

class SSSUITE_OT_new_selector(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.new_selector'
    bl_label = 'Create New Selector'
    mode: StringProperty(default='edit', description='Function: supplies the Mode parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_new_selector', 'Open a new, empty selector in the browser (Edit Mode). After placing buttons/sliders, use “Save As” in the browser to create a new .json file.')

    def execute(self, context):
        try:
            if not _always_on().is_feature_enabled('smart_selector_browser_server', True):
                self.report({'WARNING'}, _lang_text('Browser server is disabled in Always-on Toggles.', 'ブラウザーサーバーは「常時機能切り替え」で無効になっています。'))
                return {'CANCELLED'}
        except Exception:
            pass
        started = _server_runtime().start_server(_safe_scene_project(getattr(context, 'scene', None)), '', self.mode, lang=current_lang())
        if not started:
            self.report({'WARNING'}, _lang_text('Browser server is disabled in Always-on Toggles.', 'ブラウザーサーバーは「常時機能切り替え」で無効になっています。'))
            return {'CANCELLED'}
        return {'FINISHED'}

class SSSUITE_OT_refresh_selector_files(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.refresh_selector_files'
    bl_label = 'Refresh Selector Data List'
    bl_description = 'Rescan the active Project folder and refresh the cached Selector data list. The N-panel itself never performs filesystem scans while drawing.'
    bl_options = {'INTERNAL'}

    def execute(self, context):
        files = _refresh_selector_files_cache(getattr(context, 'scene', None))
        self.report({'INFO'}, f'Selector data list refreshed: {len(files)}')
        _tag_redraw_all_view3d()
        return {'FINISHED'}

class SSSUITE_OT_open_selector(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.open_selector'
    bl_label = 'Open Selector'
    filename: StringProperty(description='Function: supplies the Filename parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')
    mode: StringProperty(default='edit', description='Function: supplies the Mode parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_open_selector', 'Open this selector in Edit Mode (layout editing). You can move elements, assign actions, then “Save” to overwrite the file. Use “Save As” if you want a copy.') if getattr(properties, 'mode', 'edit') == 'edit' else tr_tip('tt_open_selector_play', 'Open this selector in Select Mode (use mode). The layout is locked; clicking buttons/sliders runs the assigned actions in Blender.')

    def invoke(self, context, event):
        if self.mode == 'play_dbl':
            if getattr(event, 'value', '') == 'DOUBLE_CLICK':
                self.mode = 'play'
                return self.execute(context)
            return {'CANCELLED'}
        return self.execute(context)

    def execute(self, context):
        try:
            if not _always_on().is_feature_enabled('smart_selector_browser_server', True):
                self.report({'WARNING'}, _lang_text('Browser server is disabled in Always-on Toggles.', 'ブラウザーサーバーは「常時機能切り替え」で無効になっています。'))
                return {'CANCELLED'}
        except Exception:
            pass
        started = _server_runtime().start_server(_safe_scene_project(getattr(context, 'scene', None)), self.filename, self.mode, lang=current_lang())
        if not started:
            self.report({'WARNING'}, _lang_text('Browser server is disabled in Always-on Toggles.', 'ブラウザーサーバーは「常時機能切り替え」で無効になっています。'))
            return {'CANCELLED'}
        return {'FINISHED'}

class SSSUITE_OT_exec_script(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.exec_script'
    bl_label = 'Execute Smart Selector Script'
    bl_options = {'UNDO', 'INTERNAL'}
    payload: StringProperty(options={'SKIP_SAVE'}, description='Function: supplies the Payload parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_exec_script', 'Run the Python Script assigned to a selector button. For safety, you can disable this in Smart Selector N-panel Settings (recommended when using shared selector files).')

    def execute(self, context):
        prefs = _get_prefs()
        if prefs and (not getattr(prefs, 'enable_exec_script', True)):
            _bridge_warning(self, _lang_text('Execute Script is disabled in Smart Selector N-panel Settings.', 'スマートセレクターの Nパネル設定で「スクリプト実行を許可」がOFFになっています。'))
            return {'CANCELLED'}
        data = _payload_dict(self, self.payload)
        if not data:
            return {'CANCELLED'}
        script_code = data.get('script', '')
        if not script_code:
            return {'CANCELLED'}
        # 1.10.60: a legacy Text that the Action catalog says needs an archived Action is not run.
        try:
            from . import action_catalog_ui as _acu
            blocked = _acu.legacy_block(context, script_code)
        except Exception:
            blocked = []
        if blocked:
            names = ', '.join(blocked)
            _bridge_warning(self, _lang_text(
                f'Not run: this script runs the legacy Text "{names}", whose Actions are in the archive. Use Face ARKit > External Actions (archive).',
                f'実行しませんでした：この台本は、Action が保管庫に移った古い Text「{names}」を動かします。「顔 ARKit」→「外部 Action（保管庫）」で切り替えてください。'))
            return {'CANCELLED'}
        try:
            ctx_dict = _server_runtime().get_view3d_context()
            glb = {'bpy': bpy, 'C': bpy.context, 'D': bpy.data, '__name__': '__smart_selector_suite__'}
            if ctx_dict:
                with bpy.context.temp_override(**ctx_dict):
                    exec(script_code, glb)
            else:
                exec(script_code, glb)
            if context.edit_object and context.edit_object.type == 'MESH':
                import bmesh
                bmesh.update_edit_mesh(context.edit_object.data, loop_triangles=False, destructive=False)
            _tag_redraw_all_view3d()
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, _lang_text('Script failed: %s: %s' % (type(e).__name__, e), 'スクリプトを実行できませんでした：%s: %s' % (type(e).__name__, e)))
            return {'CANCELLED'}

class SSSUITE_OT_set_shapekey(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.set_shapekey'
    bl_label = 'Set Shape Key'
    bl_options = {'UNDO', 'INTERNAL'}
    payload: StringProperty(options={'SKIP_SAVE'}, description='Function: supplies the Payload parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_set_shapekey', 'Change a Shape Key value from the browser. Works on a mesh object that has Shape Keys. Actions can be undone in Blender.')

    def execute(self, context):
        data = _payload_dict(self, self.payload)
        if not data:
            return {'CANCELLED'}
        obj_name = _payload_string(data.get('obj'))
        key_name = _payload_string(data.get('key'))
        obj = bpy.data.objects.get(obj_name) if obj_name else None
        if not obj:
            self.report({'WARNING'}, _lang_text('Shape Key target object was not found.', 'シェイプキー対象オブジェクトが見つかりません。'))
            return {'CANCELLED'}
        if not getattr(obj.data, 'shape_keys', None):
            self.report({'WARNING'}, _lang_text('The target object has no Shape Keys.', '対象オブジェクトにシェイプキーがありません。'))
            return {'CANCELLED'}
        kb = obj.data.shape_keys.key_blocks.get(key_name) if key_name else None
        if not kb:
            self.report({'WARNING'}, _lang_text('Shape Key name was not found on the target object.', '対象オブジェクトに指定したシェイプキー名が見つかりません。'))
            return {'CANCELLED'}
        try:
            kb.value = float(data.get('value'))
        except Exception as exc:
            self.report({'ERROR'}, _lang_text(f'Invalid Shape Key value: {exc}', 'シェイプキー値が無効です。'))
            return {'CANCELLED'}
        _tag_redraw_all_view3d()
        return {'FINISHED'}

class SSSUITE_OT_set_custom_prop(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.set_custom_prop'
    bl_label = 'Set Custom Property'
    bl_options = {'UNDO', 'INTERNAL'}
    payload: StringProperty(options={'SKIP_SAVE'}, description='Function: supplies the Payload parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_set_custom_prop', 'Change a Custom Property (data-path) value from the browser. Use this for object/scene/custom properties you want to control with buttons or sliders.')

    def execute(self, context):
        data = _payload_dict(self, self.payload)
        if not data:
            return {'CANCELLED'}
        obj_name = _payload_string(data.get('obj'))
        path = _payload_string(data.get('path'))
        obj = bpy.data.objects.get(obj_name) if obj_name else None
        if not obj:
            _bridge_warning(self, _lang_text('Custom Property target object was not found.', 'カスタムプロパティ対象オブジェクトが見つかりません。'))
            return {'CANCELLED'}
        if not path:
            _bridge_warning(self, _lang_text('Custom Property data path is empty.', 'カスタムプロパティのデータパスが空です。'))
            return {'CANCELLED'}
        try:
            utils.assign_numeric_data_path(obj, path, data.get('value'))
        except utils.DataPathValueRefused as refused:
            _bridge_warning(self, _data_path_refusal_text(refused))
            return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, _lang_text(f'Custom property assignment failed: {e}', 'カスタムプロパティの割り当てに失敗しました。'))
            return {'CANCELLED'}
        # Writing an ID property does not re-evaluate drivers/constraints that read it until the owner is
        # tagged (measured on 5.1.2: an ARP switch stayed at its old influence until update_tag).
        obj.update_tag()
        _tag_redraw_all_view3d()
        return {'FINISHED'}

def _selection_view_layer():
    """The view layer the user sees (window with a 3D View), else the context one."""
    override = _server_runtime().get_view3d_context()
    view_layer = override.get('view_layer') if override else None
    return view_layer if view_layer is not None else bpy.context.view_layer


def _deselect_view_layer_objects(view_layer) -> None:
    """Deselect only what this view layer holds; objects of other scenes or excluded collections are left alone."""
    if view_layer is None:
        return
    for obj in view_layer.objects:
        obj.select_set(False, view_layer=view_layer)


def _selection_snapshot(view_layer):
    if view_layer is None:
        return None
    return ([obj for obj in view_layer.objects if obj.select_get(view_layer=view_layer)], view_layer.objects.active)


def _selection_restore(view_layer, snapshot) -> None:
    """Put the previous object selection back after an unexpected failure half way through."""
    if view_layer is None or snapshot is None:
        return
    selected, active = snapshot
    try:
        _deselect_view_layer_objects(view_layer)
        for obj in selected:
            obj.select_set(True, view_layer=view_layer)
        view_layer.objects.active = active
    except Exception:
        _warn_once('ui:1501', traceback.format_exc())


def _names_text(names) -> str:
    names = list(names)
    return ', '.join(names[:8]) + (' ...' if len(names) > 8 else '')


def _resolve_collection_targets(op, cols, include_children, view_layer, for_visibility):
    """Resolve every requested collection and its objects BEFORE anything changes.

    Returns the de-duplicated objects, or None after a bridge warning (missing name, nothing assigned,
    nothing inside, or any requested object outside the current view layer). Nothing is partially applied.
    """
    if not cols:
        if for_visibility:
            _bridge_warning(op, _lang_text('No collections are assigned to this collection visibility button; nothing was changed.', 'このコレクション表示切替にはコレクションが割り当てられていないため、何も変更しませんでした。'))
        else:
            _bridge_warning(op, _lang_text('No collections are assigned to this collection selection button; nothing was changed.', 'このコレクション選択にはコレクションが割り当てられていないため、何も変更しませんでした。'))
        return None
    missing = [cn for cn in cols if bpy.data.collections.get(cn) is None]
    if missing:
        _bridge_warning(op, _lang_text(f'Collection(s) not found: {_names_text(missing)}; nothing was changed.', f'見つからないコレクションがあります: {_names_text(missing)}。何も変更しませんでした。'))
        return None

    def iter_cols(col):
        yield col
        if include_children:
            for ch in col.children:
                yield from iter_cols(ch)
    objects = []
    for cn in cols:
        for c in iter_cols(bpy.data.collections[cn]):
            objects.extend(c.objects)
    # An object linked into several of these collections is handled once.
    objects = list(dict.fromkeys(objects))
    if not objects:
        _bridge_warning(op, _lang_text(f'The collection(s) {_names_text(cols)} contain no objects; nothing was changed.', f'コレクション {_names_text(cols)} にはオブジェクトがないため、何も変更しませんでした。'))
        return None
    if view_layer is not None:
        outside = [o.name for o in objects if view_layer.objects.get(o.name) is None]
        if outside:
            _bridge_warning(op, _lang_text(f'{len(outside)} object(s) of the collection(s) are not in the current view layer (excluded collection or another scene): {_names_text(outside)}; nothing was changed.', f'コレクション内の {len(outside)} 個のオブジェクトが現在のビューレイヤーにありません（除外されたコレクションか別のシーン）: {_names_text(outside)}。何も変更しませんでした。'))
            return None
    return objects


class SSSUITE_OT_apply_selection(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.apply_selection'
    bl_label = 'Apply Selection'
    bl_options = {'UNDO', 'INTERNAL'}
    payload: StringProperty(options={'SKIP_SAVE'}, description='Function: supplies the Payload parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_apply_selection', 'Run a selection action (select objects / collections / bones / mesh component sets depending on the action settings).')

    def execute(self, context):
        data = _payload_dict(self, self.payload)
        if not data:
            return {'CANCELLED'}
        target_type = str(data.get('target_type') or data.get('kind') or 'object').lower()
        is_shift = _payload_bool(data.get('shift', False), False)
        is_ctrl = _payload_bool(data.get('ctrl', False), False)
        try:
            if target_type in {'object', 'node', 'objects'}:
                targets = list(dict.fromkeys(_payload_string_list(data.get('objects', []) or data.get('targets', []) or [])))
                view_layer = _selection_view_layer()
                if not targets:
                    # The page's empty-canvas click sends an explicit empty list: plain click clears the selection
                    # of the current view layer (the documented behaviour); Shift/Ctrl with nothing is a no-op.
                    if not is_shift and (not is_ctrl):
                        _deselect_view_layer_objects(view_layer)
                    _tag_redraw_all_view3d()
                    return {'FINISHED'}
                # Resolve every requested name before changing anything.
                missing = [name for name in targets if bpy.data.objects.get(name) is None]
                if missing:
                    _bridge_warning(self, _lang_text(f'Object(s) not found: {_names_text(missing)}; the selection was not changed.', f'見つからないオブジェクトがあります: {_names_text(missing)}。選択は変更していません。'))
                    return {'CANCELLED'}
                outside = [name for name in targets if view_layer is not None and view_layer.objects.get(name) is None]
                if outside:
                    _bridge_warning(self, _lang_text(f'Object(s) not in the current view layer (excluded collection or another scene): {_names_text(outside)}; the selection was not changed.', f'現在のビューレイヤーにないオブジェクトがあります（除外されたコレクションか別のシーン）: {_names_text(outside)}。選択は変更していません。'))
                    return {'CANCELLED'}
                resolved = [bpy.data.objects[name] for name in targets]
                snapshot = _selection_snapshot(view_layer)
                try:
                    if not is_shift and (not is_ctrl):
                        _deselect_view_layer_objects(view_layer)
                    for obj in resolved:
                        if is_ctrl:
                            obj.select_set(False, view_layer=view_layer)
                        else:
                            obj.select_set(True, view_layer=view_layer)
                            if view_layer is not None:
                                view_layer.objects.active = obj
                except Exception:
                    _selection_restore(view_layer, snapshot)
                    raise
            elif target_type in {'collection', 'collection_select'}:
                cols = list(dict.fromkeys(_payload_string_list(data.get('collections', []) or [])))
                include_children = _payload_bool(data.get('include_children', True), True)
                # The window's view layer (the one the user sees), not the timer context's default one.
                view_layer = _selection_view_layer()
                objects = _resolve_collection_targets(self, cols, include_children, view_layer, for_visibility=False)
                if objects is None:
                    return {'CANCELLED'}
                snapshot = _selection_snapshot(view_layer)
                try:
                    if not is_shift and (not is_ctrl):
                        _deselect_view_layer_objects(view_layer)
                    for obj in objects:
                        if is_ctrl:
                            obj.select_set(False, view_layer=view_layer)
                        else:
                            obj.select_set(True, view_layer=view_layer)
                            if view_layer is not None:
                                view_layer.objects.active = obj
                except Exception:
                    _selection_restore(view_layer, snapshot)
                    raise
            elif target_type in {'collection_visibility', 'collection_vis'}:
                cols = list(dict.fromkeys(_payload_string_list(data.get('collections', []) or [])))
                action = _payload_string(data.get('action'), 'toggle').lower()
                if action not in {'show', 'hide', 'toggle'}:
                    action = 'toggle'
                include_children = _payload_bool(data.get('include_children', True), True)
                # hide_set() acts on the context view layer; every requested object must be in it.
                view_layer = bpy.context.view_layer
                objects = _resolve_collection_targets(self, cols, include_children, view_layer, for_visibility=True)
                if objects is None:
                    return {'CANCELLED'}
                previous = [(obj, obj.hide_get()) for obj in objects]
                try:
                    # Viewport visibility only: render visibility (hide_render) is saved data and is left alone.
                    for obj in objects:
                        if action == 'show':
                            obj.hide_set(False)
                        elif action == 'hide':
                            obj.hide_set(True)
                        else:
                            obj.hide_set(not obj.hide_get())
                except Exception:
                    for obj, was_hidden in previous:
                        try:
                            obj.hide_set(was_hidden)
                        except Exception:
                            _warn_once('ui:1648', traceback.format_exc())
                    raise
            elif target_type in {'bone', 'bone_select'}:
                arm_name = _payload_string(data.get('armature', '') or data.get('object', ''))
                bones = _payload_string_list(data.get('bones', []) or [])
                arm = bpy.data.objects.get(arm_name) if arm_name else None
                if not arm or arm.type != 'ARMATURE':
                    _bridge_warning(self, _lang_text('Bone selection target armature was not found.', 'ボーン選択対象のアーマチュアが見つかりません。'))
                    return {'CANCELLED'}
                if not bones:
                    _bridge_warning(self, _lang_text('No bones are assigned to this bone selection.', 'このボーン選択にはボーンが割り当てられていません。'))
                    return {'CANCELLED'}
                # Blender 5.x: selection lives on PoseBone.select (Bone.select no longer exists).
                pose_bones = arm.pose.bones if arm.pose is not None else None
                found = []
                missing = []
                for bn in bones:
                    pb = pose_bones.get(bn) if pose_bones is not None else None
                    if pb is None:
                        missing.append(bn)
                    else:
                        found.append(pb)
                missing_text = ', '.join(missing[:8]) + (' ...' if len(missing) > 8 else '')
                if not found:
                    _bridge_warning(self, _lang_text(f'None of the assigned bones exist on armature "{arm.name}": {missing_text}', f'アーマチュア「{arm.name}」に割り当てたボーンが見つかりません: {missing_text}'))
                    return {'CANCELLED'}
                # Same view layer as the mode_set override below (the window's), not the timer context's default one.
                override = _server_runtime().get_view3d_context()
                view_layer = override.get('view_layer') if override else bpy.context.view_layer
                if view_layer is not None and view_layer.objects.get(arm.name) is None:
                    _bridge_warning(self, _lang_text(f'Armature "{arm.name}" is not in the current view layer, so it cannot be selected.', f'アーマチュア「{arm.name}」は現在のビューレイヤーに含まれていないため選択できません。'))
                    return {'CANCELLED'}
                # A hidden armature still enters Pose Mode and gets its bones selected (as before);
                # only say that the result is not visible in the viewport. Visibility is not changed.
                if not arm.visible_get(view_layer=view_layer):
                    _bridge_warning(self, _lang_text(f'Armature "{arm.name}" is hidden in the viewport; its bones are selected but not visible until it is shown.', f'アーマチュア「{arm.name}」はビューポートで非表示です。ボーンは選択しましたが、表示するまで見えません。'))
                current = view_layer.objects.active if view_layer is not None else None
                # Weight painting a mesh deformed by this armature (armature already in Pose Mode):
                # keep the mesh active and in Weight Paint, change only the bone selection and the
                # active vertex group (Blender's own bone picking while weight painting).
                keep_weight_paint = (
                    current is not None and current != arm and current.mode == 'WEIGHT_PAINT'
                    and arm.mode == 'POSE'
                    and any(md.type == 'ARMATURE' and md.object == arm for md in current.modifiers))
                # Another object in Edit / Sculpt / Paint mode would be left behind in that mode once the
                # armature becomes active; leave it first (same as switching objects by hand).
                if (not keep_weight_paint) and current is not None and current != arm and current.mode != 'OBJECT':
                    exit_error = ''
                    try:
                        if override:
                            with bpy.context.temp_override(**override):
                                bpy.ops.object.mode_set(mode='OBJECT')
                        else:
                            bpy.ops.object.mode_set(mode='OBJECT')
                    except RuntimeError as exc:
                        exit_error = exception_text(exc, '')
                    if current.mode != 'OBJECT':
                        _bridge_warning(self, _lang_text(f'Could not leave the current mode of "{current.name}", so the bones were not selected. {exit_error}', f'「{current.name}」の現在のモードを抜けられなかったため、ボーンを選択していません。{exit_error}').strip())
                        return {'CANCELLED'}
                if not keep_weight_paint:
                    if not is_shift and (not is_ctrl):
                        _deselect_view_layer_objects(view_layer)
                    arm.select_set(True, view_layer=view_layer)
                    if view_layer is not None:
                        view_layer.objects.active = arm
                mode_error = ''
                if arm.mode != 'POSE':
                    try:
                        if override:
                            with bpy.context.temp_override(**override):
                                bpy.ops.object.mode_set(mode='POSE')
                        else:
                            bpy.ops.object.mode_set(mode='POSE')
                    except RuntimeError as exc:
                        mode_error = exception_text(exc, '')
                if arm.mode != 'POSE':
                    _bridge_warning(self, _lang_text(f'Could not enter Pose Mode on "{arm.name}". {mode_error}', f'「{arm.name}」をポーズモードにできませんでした。{mode_error}').strip())
                if not is_shift and (not is_ctrl):
                    for pb in pose_bones:
                        pb.select = False
                for pb in found:
                    pb.select = not is_ctrl
                # Read back: a bone the setter did not change (e.g. hidden or unselectable) is reported, not assumed.
                unchanged = [pb.name for pb in found if bool(pb.select) == bool(is_ctrl)]
                if not is_ctrl:
                    active_bone = arm.data.bones.active
                    if active_bone is None or active_bone.name not in {pb.name for pb in found}:
                        arm.data.bones.active = found[0].bone
                    if keep_weight_paint and arm.data.bones.active is not None:
                        vgroup = current.vertex_groups.get(arm.data.bones.active.name)
                        if vgroup is not None:
                            current.vertex_groups.active_index = vgroup.index
                if missing:
                    _bridge_warning(self, _lang_text(f'{len(missing)} assigned bone(s) were not found on armature "{arm.name}": {missing_text}', f'アーマチュア「{arm.name}」に見つからないボーンが {len(missing)} 本あります: {missing_text}'))
                if unchanged:
                    unchanged_text = ', '.join(unchanged[:8]) + (' ...' if len(unchanged) > 8 else '')
                    _bridge_warning(self, _lang_text(f'{len(unchanged)} bone(s) on armature "{arm.name}" did not change selection (hidden or unselectable?): {unchanged_text}', f'アーマチュア「{arm.name}」の {len(unchanged)} 本のボーンは選択状態が変わりませんでした（非表示または選択不可の可能性）: {unchanged_text}'))
            elif target_type in {'mesh_elems', 'mesh_selectset'}:
                obj_name = _payload_string(data.get('object', '') or data.get('mesh', ''))
                elem_mode = _payload_string(data.get('elem_mode'), 'VERT').upper()
                if elem_mode not in {'VERT', 'EDGE', 'FACE'}:
                    elem_mode = 'VERT'
                indices = _payload_int_list(data.get('indices', []) or [])
                obj = bpy.data.objects.get(obj_name) if obj_name else None
                if not obj or obj.type != 'MESH':
                    _bridge_warning(self, _lang_text('Mesh element selection target mesh was not found.', 'メッシュ要素選択対象のメッシュが見つかりません。'))
                    return {'CANCELLED'}
                if obj and obj.type == 'MESH':
                    # Same view layer as the mode_set override below (the window's), not the timer context's default one.
                    override = _server_runtime().get_view3d_context()
                    view_layer = override.get('view_layer') if override else bpy.context.view_layer
                    if view_layer is not None and view_layer.objects.get(obj.name) is None:
                        _bridge_warning(self, _lang_text(f'Mesh "{obj.name}" is not in the current view layer, so its elements cannot be selected.', f'メッシュ「{obj.name}」は現在のビューレイヤーに含まれていないため、要素を選択できません。'))
                        return {'CANCELLED'}
                    if view_layer is not None:
                        view_layer.objects.active = obj
                    obj.select_set(True, view_layer=view_layer)
                    mode_error = ''
                    try:
                        if override:
                            with bpy.context.temp_override(**override):
                                bpy.ops.object.mode_set(mode='EDIT')
                        else:
                            bpy.ops.object.mode_set(mode='EDIT')
                    except RuntimeError as exc:
                        mode_error = exception_text(exc, '')
                    if getattr(obj, 'mode', '') != 'EDIT':
                        message = _lang_text('Mesh element selection requires the target object to enter Edit Mode.', 'メッシュ要素選択には対象オブジェクトが編集モードに入る必要があります。')
                        _bridge_warning(self, f'{message} {mode_error}'.strip())
                        return {'CANCELLED'}
                    import bmesh
                    bm = bmesh.from_edit_mesh(obj.data)
                    if elem_mode == 'EDGE':
                        elems = bm.edges
                    elif elem_mode == 'FACE':
                        elems = bm.faces
                    else:
                        elems = bm.verts
                    # Random access (elems[i]) needs a fresh lookup table after from_edit_mesh.
                    elems.ensure_lookup_table()
                    if not is_shift and (not is_ctrl):
                        # Replace clears every element type: deselecting only verts (or edges) leaves the
                        # faces and edges that use them selected.
                        for seq in (bm.faces, bm.edges, bm.verts):
                            for e in seq:
                                e.select = False
                    elem_count = len(elems)
                    out_of_range = 0
                    for idx in indices:
                        if 0 <= idx < elem_count:
                            elems[idx].select = not is_ctrl
                        else:
                            out_of_range += 1
                    # Recompute edge/face (or face) flags from the current select mode, as Blender's own
                    # select operators do (scripts/startup/bl_operators/mesh.py), so a VERT/EDGE subtract
                    # does not leave faces selected.
                    bm.select_flush_mode()
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                    if out_of_range:
                        _bridge_warning(self, _lang_text(f'{out_of_range} stored element index(es) are out of range for "{obj.name}"; the mesh may have changed since capture.', f'「{obj.name}」で範囲外の要素番号が {out_of_range} 件あります。キャプチャ後にメッシュが変更された可能性があります。'))
            else:
                _bridge_warning(self, _lang_text(f'Unknown selection target type: {target_type}', f'未対応の選択ターゲット種別です: {target_type}'))
                return {'CANCELLED'}
            _tag_redraw_all_view3d()
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, exception_text(e))
            pass
            return {'CANCELLED'}

def _history_override():
    """Window/screen/area/region of the 3D View for ed.undo / ed.redo -- never scene or view_layer.

    Undo/redo re-reads the database; a scene or view layer pinned in the override would be stale
    afterwards, and the operator call updates the context view layer right after undo returns.
    """
    ctx_dict = _server_runtime().get_view3d_context()
    if not ctx_dict:
        return None
    return {key: ctx_dict[key] for key in ('window', 'screen', 'area', 'region') if ctx_dict.get(key) is not None}


class SSSUITE_OT_blender_undo(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.blender_undo'
    bl_label = 'Blender Undo'
    bl_options = {'INTERNAL'}

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_blender_undo', 'Run Blender Undo (same as Ctrl+Z). Useful in Select Mode to undo the last action you executed from the selector.')

    @classmethod
    def poll(cls, context):
        try:
            if bool(getattr(bpy.app, 'background', False)):
                return False
            ctx_dict = _history_override()
            if ctx_dict:
                with bpy.context.temp_override(**ctx_dict):
                    return bool(bpy.ops.ed.undo.poll())
            return bool(bpy.ops.ed.undo.poll())
        except Exception:
            return False

    def execute(self, context):
        if bool(getattr(bpy.app, 'background', False)):
            return {'CANCELLED'}
        ctx_dict = _history_override()
        try:
            if ctx_dict:
                with bpy.context.temp_override(**ctx_dict):
                    if not bpy.ops.ed.undo.poll():
                        return {'CANCELLED'}
                    bpy.ops.ed.undo()
            else:
                if not bpy.ops.ed.undo.poll():
                    return {'CANCELLED'}
                bpy.ops.ed.undo()
            _tag_redraw_all_view3d()
            return {'FINISHED'}
        except Exception as e:
            self.report({'WARNING'}, _lang_text(f'Undo failed: {e}', '元に戻せませんでした。'))
            return {'CANCELLED'}

class SSSUITE_OT_blender_redo(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.blender_redo'
    bl_label = 'Blender Redo'
    bl_options = {'INTERNAL'}

    @classmethod
    def description(cls, context, properties):
        return tr_tip('tt_blender_redo', 'Run Blender Redo (same as Ctrl+Shift+Z). Useful after Undo to step forward again.')

    @classmethod
    def poll(cls, context):
        try:
            if bool(getattr(bpy.app, 'background', False)):
                return False
            ctx_dict = _history_override()
            if ctx_dict:
                with bpy.context.temp_override(**ctx_dict):
                    return bool(bpy.ops.ed.redo.poll())
            return bool(bpy.ops.ed.redo.poll())
        except Exception:
            return False

    def execute(self, context):
        if bool(getattr(bpy.app, 'background', False)):
            return {'CANCELLED'}
        ctx_dict = _history_override()
        try:
            if ctx_dict:
                with bpy.context.temp_override(**ctx_dict):
                    if not bpy.ops.ed.redo.poll():
                        return {'CANCELLED'}
                    bpy.ops.ed.redo()
            else:
                if not bpy.ops.ed.redo.poll():
                    return {'CANCELLED'}
                bpy.ops.ed.redo()
            _tag_redraw_all_view3d()
            return {'FINISHED'}
        except Exception as e:
            self.report({'WARNING'}, _lang_text(f'Redo failed: {e}', 'やり直せませんでした。'))
            return {'CANCELLED'}

def _tag_redraw_area(area):
    if area is None:
        return
    try:
        area.tag_redraw()
        return
    except Exception:
        pass
    for region in getattr(area, 'regions', ()):
        try:
            region.tag_redraw()
        except Exception:
            pass

def _selector_files_for_scene(scene):
    project = _safe_scene_project(scene)
    prefs = _get_prefs()
    fav_map = _get_fav_map(prefs) if prefs else {}
    favorite_names = _favorite_name_set(project, prefs=prefs, fav_map=fav_map)
    files = list(_SELECTOR_FILES_CACHE.get(project, ()))
    if _safe_scene_show_favorites_only(scene):
        files = [f for f in files if f in favorite_names]
    files = sorted(files, key=lambda f: (f not in favorite_names, os.path.splitext(f)[0].lower()))
    return (project, files, favorite_names)

def _refresh_selector_files_cache(scene=None):
    scene = scene or getattr(getattr(bpy, 'context', None), 'scene', None)
    project = _safe_scene_project(scene)
    try:
        files = tuple(utils.get_selector_files(project) or ())
    except Exception:
        files = ()
    _SELECTOR_FILES_CACHE.clear()
    _SELECTOR_FILES_CACHE[project] = files
    return files

def _draw_selector_rows(layout, scene):
    project, files, favorite_names = _selector_files_for_scene(scene)
    if not files:
        layout.label(text=tr_iface('(No data available)'), icon='NONE')
        return
    box = layout.box()
    for fn in files:
        name = os.path.splitext(fn)[0]
        row = box.row(align=True)
        row.scale_y = 1.22
        fav_on = fn in favorite_names
        fav_icon = 'SOLO_ON' if fav_on else 'SOLO_OFF'
        fav = _operator_with_icon(row, 'smart_selector_suite.toggle_favorite', text='', icon_name='favorite_on' if fav_on else 'favorite_off', fallback=fav_icon, depress=fav_on)
        fav.filename = fn
        op = _operator_with_icon(row, 'smart_selector_suite.open_selector', text=name, icon_name='play', fallback='PLAY', emboss=True, translate=False)
        op.filename = fn
        op.mode = 'play'
        op = _operator_with_icon(row, 'smart_selector_suite.open_selector', text='', icon_name='edit', fallback='GREASEPENCIL')
        op.filename = fn
        op.mode = 'edit'

class SSSUITE_BridgePayloadProperties(PropertyGroup):
    exec_script_payload: StringProperty(name='Script Payload', description='Function: stores the JSON payload used by the internal Execute Script bridge operator. How to use: paste a JSON object such as {"script":"print(\'Hello\')"} and press Execute Script below. This text is saved according to N-panel State Save and remains after Blender restarts or scene changes.', get=_persisted_string_getter('bridge_exec_script_payload', '{"script":"print("Hello Smart Selector")"}'), set=_persisted_string_setter('bridge_exec_script_payload'))
    shapekey_payload: StringProperty(name='Shape Key Payload', description='Function: stores the JSON payload used by the internal Shape Key bridge operator. How to use: paste a JSON object such as {"obj":"Character","key":"Smile","value":1.0} and press Set Shape Key below. This text is saved according to N-panel State Save and remains after Blender restarts or scene changes.', get=_persisted_string_getter('bridge_shapekey_payload', '{"obj":"Object","key":"Key 1","value":1.0}'), set=_persisted_string_setter('bridge_shapekey_payload'))
    custom_prop_payload: StringProperty(name='Custom Property Payload', description='Function: stores the JSON payload used by the internal Custom Property bridge operator. How to use: paste a JSON object such as {"obj":"Cube","path":"location[0]","value":1.0} and press Set Custom Property below. This text is saved according to N-panel State Save and remains after Blender restarts or scene changes.', get=_persisted_string_getter('bridge_custom_prop_payload', '{"obj":"Object","path":"location[0]","value":1.0}'), set=_persisted_string_setter('bridge_custom_prop_payload'))
    selection_payload: StringProperty(name='Selection Payload', description='Function: stores the JSON payload used by the internal selection bridge operator. How to use: paste a JSON object such as {"target_type":"object","objects":["Cube"]} and press Apply Selection below. This text is saved according to N-panel State Save and remains after Blender restarts or scene changes.', get=_persisted_string_getter('bridge_selection_payload', '{"target_type":"object","objects":["Cube"]}'), set=_persisted_string_setter('bridge_selection_payload'))

class SSSUITE_NPanelSettings(PropertyGroup):
    root_dir: StringProperty(name='Data Save Root Directory', subtype='DIR_PATH', description='Function: chooses the root folder for Smart Selector project folders. How to use: leave this blank to store all automatically generated project data inside CONFIG/Smart_Selector_Suite. Enter a directory only when you intentionally want manual external project storage; existing projects are not moved automatically. If the active project is not in the new location, the first project there becomes active.', get=_persisted_string_getter('root_dir', ''), set=_root_dir_setter)
    state_update_interval: FloatProperty(name='State Sync Interval (s)', description='Function: controls how often Blender selection, active object, object lists, collection lists, and watched Shape Key values are synchronized to the browser bridge. How to use: lower values update faster; raise this to reduce overhead in heavy scenes. Typical values are 0.5 to 1.0 seconds. This setting is saved according to N-panel State Save and remains after Blender restarts or scene changes.', get=_persisted_float_getter('state_update_interval', 0.5), set=_persisted_float_setter('state_update_interval'), min=0.1, max=2.0, step=1, precision=2)
    max_backup_generations: IntProperty(name='Backup Generations', description='Function: sets how many .bak backup generations are kept beside saved selector JSON and image files. How to use: set 0 to disable backups, or increase the value when you need more restore points. Higher values use more disk space. This setting is saved according to N-panel State Save and remains after Blender restarts or scene changes.', get=_persisted_int_getter('max_backup_generations', 20), set=_persisted_int_setter('max_backup_generations'), min=0, max=200)
    enable_exec_script: BoolProperty(name='Allow Execute Script', description='Function: allows selector buttons to execute Python scripts sent from the browser. How to use: keep this off when opening shared or untrusted selector files, and turn it on only when you need script buttons to control Blender. This setting is saved according to N-panel State Save and remains after Blender restarts or scene changes.', get=_persisted_bool_getter('enable_exec_script', True), set=_persisted_bool_setter('enable_exec_script'))
    show_archived_projects: BoolProperty(name='Show Archived Projects', description='Function: includes project folders stored in the __ARCHIVE__ folder in the Project list. How to use: enable this when you need to reopen an archived job; disable it to keep the Project list focused on active projects. This setting is saved according to N-panel State Save and remains after Blender restarts or scene changes.', get=_persisted_bool_getter('show_archived_projects', False), set=_persisted_bool_setter('show_archived_projects'))
    favorite_selectors_json: StringProperty(name='Favorite Selectors', description='Function: stores the internal per-project favorite selector map used by the star buttons and Favorites Only filter. How to use: edit this only for recovery or migration; normal favorite changes are made with the star buttons. This value is saved according to N-panel State Save and remains after Blender restarts or scene changes.', get=_persisted_string_getter('favorite_selectors_json', '{}'), set=_persisted_string_setter('favorite_selectors_json'), options={'HIDDEN'})
    enable_collection_manager_tool: BoolProperty(name='Collection Manager Integration', description='Function: stores the N-panel integration flag for Collection Manager compatibility. How to use: use the Always-on Toggles group to control actual availability; this saved value remains for migration compatibility and does not create any separate settings UI.', get=_persisted_bool_getter('enable_collection_manager_tool', True), set=_persisted_bool_setter('enable_collection_manager_tool'), options={'HIDDEN'})
    enable_gp_select_tool: BoolProperty(name='GP Select Integration', description='Function: stores the N-panel integration flag for GP Select compatibility. How to use: use the Always-on Toggles group to control actual availability; this saved value remains for migration compatibility and does not create any separate settings UI.', get=_persisted_bool_getter('enable_gp_select_tool', True), set=_persisted_bool_setter('enable_gp_select_tool'), options={'HIDDEN'})
    show_integrated_tools: BoolProperty(name='Tool Groups', description='Function: stores the open or closed state of the integrated tool information group in the Smart Selector N-panel. How to use: this is maintained automatically by the N-panel UI and saved according to N-panel State Save.', get=_persisted_bool_getter('show_integrated_tools', True), set=_persisted_bool_setter('show_integrated_tools'))
    show_collection_manager_section: BoolProperty(name='Collection Manager', description='Function: opens or closes the Collection Manager information section inside Smart Selector settings. How to use: click the row triangle to show what the integrated tool does and where to control it. This state is saved according to N-panel State Save and remains after Blender restarts or scene changes.', get=_persisted_bool_getter('show_collection_manager_section', False), set=_persisted_bool_setter('show_collection_manager_section'))
    show_gp_select_section: BoolProperty(name='GP Select', description='Function: opens or closes the GP Select information section inside Smart Selector settings. How to use: click the row triangle to show what the integrated tool does and where to control it. This state is saved according to N-panel State Save and remains after Blender restarts or scene changes.', get=_persisted_bool_getter('show_gp_select_section', False), set=_persisted_bool_setter('show_gp_select_section'))
    show_always_on_toggles: BoolProperty(name='Always-on Toggles', description='Function: opens or closes the Always-on Toggles group at the top of the Smart Selector N-panel. How to use: click the triangle in the group header. The open/closed state is saved according to N-panel State Save and remains after Blender restarts or scene changes.', get=_persisted_bool_getter('show_always_on_toggles', False), set=_persisted_bool_setter('show_always_on_toggles'))
    ui_show_settings_storage: BoolProperty(name='Data Storage Section', description='Function: stores the open or closed state of the Data Storage child section in the Smart Selector N-panel. How to use: click the standard disclosure arrow in the section header; the state is written to Smart_Selector_Suite.json according to the N-panel state-save policy.', get=_persisted_bool_getter('ui_show_settings_storage', False), set=_persisted_bool_setter('ui_show_settings_storage'), options={'HIDDEN'})
    ui_show_settings_performance: BoolProperty(name='Performance / Safety Section', description='Function: stores the open or closed state of the Performance / Safety child section in the Smart Selector N-panel. How to use: click the standard disclosure arrow in the section header; the state is written to Smart_Selector_Suite.json according to the N-panel state-save policy.', get=_persisted_bool_getter('ui_show_settings_performance', False), set=_persisted_bool_setter('ui_show_settings_performance'), options={'HIDDEN'})
    ui_show_settings_project_list: BoolProperty(name='Project List Section', description='Function: stores the open or closed state of the Project List child section in the Smart Selector N-panel. How to use: click the standard disclosure arrow in the section header; the state is written to Smart_Selector_Suite.json according to the N-panel state-save policy.', get=_persisted_bool_getter('ui_show_settings_project_list', False), set=_persisted_bool_setter('ui_show_settings_project_list'), options={'HIDDEN'})
    ui_show_bridge_undo_redo: BoolProperty(name='Undo / Redo Section', description='Function: stores the open or closed state of the Undo / Redo child section in the Smart Selector N-panel. How to use: click the standard disclosure arrow in the section header; the state is written to Smart_Selector_Suite.json according to the N-panel state-save policy.', get=_persisted_bool_getter('ui_show_bridge_undo_redo', False), set=_persisted_bool_setter('ui_show_bridge_undo_redo'), options={'HIDDEN'})
    ui_show_bridge_selection: BoolProperty(name='Apply Selection Payload Section', description='Function: stores the open or closed state of the Apply Selection Payload child section in the Smart Selector N-panel. How to use: click the standard disclosure arrow in the section header; the state is written to Smart_Selector_Suite.json according to the N-panel state-save policy.', get=_persisted_bool_getter('ui_show_bridge_selection', False), set=_persisted_bool_setter('ui_show_bridge_selection'), options={'HIDDEN'})
    ui_show_bridge_shapekey: BoolProperty(name='Shape Key Payload Section', description='Function: stores the open or closed state of the Shape Key Payload child section in the Smart Selector N-panel. How to use: click the standard disclosure arrow in the section header; the state is written to Smart_Selector_Suite.json according to the N-panel state-save policy.', get=_persisted_bool_getter('ui_show_bridge_shapekey', False), set=_persisted_bool_setter('ui_show_bridge_shapekey'), options={'HIDDEN'})
    ui_show_bridge_custom_prop: BoolProperty(name='Custom Property Payload Section', description='Function: stores the open or closed state of the Custom Property Payload child section in the Smart Selector N-panel. How to use: click the standard disclosure arrow in the section header; the state is written to Smart_Selector_Suite.json according to the N-panel state-save policy.', get=_persisted_bool_getter('ui_show_bridge_custom_prop', False), set=_persisted_bool_setter('ui_show_bridge_custom_prop'), options={'HIDDEN'})
    ui_show_bridge_script: BoolProperty(name='Script Payload Section', description='Function: stores the open or closed state of the Script Payload child section in the Smart Selector N-panel. How to use: click the standard disclosure arrow in the section header; the state is written to Smart_Selector_Suite.json according to the N-panel state-save policy.', get=_persisted_bool_getter('ui_show_bridge_script', False), set=_persisted_bool_setter('ui_show_bridge_script'), options={'HIDDEN'})
    ui_show_collection_manager_commands: BoolProperty(name='Collection Manager Commands Section', description='Function: stores the open or closed state of the Collection Manager Commands child section in the Smart Selector N-panel. How to use: click the standard disclosure arrow in the section header; the state is written to Smart_Selector_Suite.json according to the N-panel state-save policy.', get=_persisted_bool_getter('ui_show_collection_manager_commands', False), set=_persisted_bool_setter('ui_show_collection_manager_commands'), options={'HIDDEN'})
    ui_show_gp_select_main: BoolProperty(name='GP Select Controls Section', description='Function: stores the open or closed state of the GP Select Controls child section in the Smart Selector N-panel. How to use: click the standard disclosure arrow in the section header; the state is written to Smart_Selector_Suite.json according to the N-panel state-save policy.', get=_persisted_bool_getter('ui_show_gp_select_main', False), set=_persisted_bool_setter('ui_show_gp_select_main'), options={'HIDDEN'})
    ui_show_gp_select_renaming_pass: BoolProperty(name='Renaming and Pass Index Section', description='Function: stores the open or closed state of the Renaming and Pass Index child section in the Smart Selector N-panel. How to use: click the standard disclosure arrow in the section header; the state is written to Smart_Selector_Suite.json according to the N-panel state-save policy.', get=_persisted_bool_getter('ui_show_gp_select_renaming_pass', False), set=_persisted_bool_setter('ui_show_gp_select_renaming_pass'), options={'HIDDEN'})
    ui_show_gp_select_rigging: BoolProperty(name='Rigging Tools Section', description='Function: stores the open or closed state of the Rigging Tools child section in the Smart Selector N-panel. How to use: click the standard disclosure arrow in the section header; the state is written to Smart_Selector_Suite.json according to the N-panel state-save policy.', get=_persisted_bool_getter('ui_show_gp_select_rigging', False), set=_persisted_bool_setter('ui_show_gp_select_rigging'), options={'HIDDEN'})

class SSSUITE_OT_toggle_ui_section(bpy.types.Operator):
    bl_idname = 'smart_selector_suite.toggle_ui_section'
    bl_label = 'Toggle UI Section'
    bl_options = {'UNDO', 'INTERNAL'}
    section_key: StringProperty(name='Section Key', description='Function: stores which Smart Selector UI section should be opened or closed. How to use: this is filled automatically by the section header; manual editing is normally unnecessary.', default='', options={'SKIP_SAVE'})
    label: StringProperty(name='Section Label', description='Function: stores the display label for the section being toggled. How to use: this is filled automatically by the section header and is used only for reports and tooltips.', default='', options={'SKIP_SAVE'})
    default_state: BoolProperty(name='Default State', description='Function: stores the fallback open/closed state for a section that has not yet been saved. How to use: this is filled automatically by the section header.', default=False, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        label = str(getattr(properties, 'label', '') or '').strip() or _lang_text('UI Section', 'UIセクション')
        is_open = _ui_section_state_get(str(getattr(properties, 'section_key', '') or ''), bool(getattr(properties, 'default_state', False)))
        if _is_japanese():
            action = '閉じます' if is_open else '開きます'
            return f'機能: {label} セクションを{action}。使い方: このヘッダーをクリックすると、セクション内のUI表示を折りたたみ/展開できます。状態は保存され、Blender再起動後も保持されます。'
        action = 'collapse' if is_open else 'expand'
        return f'Function: {action} the {label} section. How to use: click this header to hide or show the controls inside this section. The state is saved and restored after Blender restarts.'

    def execute(self, context):
        key = str(self.section_key or '').strip()
        if not key:
            return {'CANCELLED'}
        current = _ui_section_state_get(key, bool(self.default_state))
        _ui_section_state_set(key, not current)
        return {'FINISHED'}

def _ensure_bridge_payload_storage() -> bool:
    try:
        if not hasattr(bpy.types.WindowManager, 'smart_selector_suite_bridge_payloads'):
            bpy.types.WindowManager.smart_selector_suite_bridge_payloads = bpy.props.PointerProperty(type=SSSUITE_BridgePayloadProperties, description='Function: stores Smart Selector Bridge Payloads runtime data used by Smart Selector storage. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.')
    except Exception:
        return False
    return hasattr(bpy.types.WindowManager, 'smart_selector_suite_bridge_payloads')

def _ensure_npanel_settings_storage() -> bool:
    try:
        if not hasattr(bpy.types.WindowManager, 'smart_selector_suite_npanel_settings'):
            bpy.types.WindowManager.smart_selector_suite_npanel_settings = bpy.props.PointerProperty(type=SSSUITE_NPanelSettings, description='Function: stores Smart Selector Npanel Settings runtime data used by Smart Selector storage. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.')
    except Exception:
        return False
    return hasattr(bpy.types.WindowManager, 'smart_selector_suite_npanel_settings')

def _npanel_settings(context):
    try:
        if not hasattr(bpy.types.WindowManager, 'smart_selector_suite_npanel_settings'):
            return None
    except Exception:
        return None
    wm = getattr(context, 'window_manager', None)
    if wm is None:
        return None
    return getattr(wm, 'smart_selector_suite_npanel_settings', None)

def _bridge_payload_props(context):
    try:
        if not hasattr(bpy.types.WindowManager, 'smart_selector_suite_bridge_payloads'):
            return None
    except Exception:
        return None
    wm = getattr(context, 'window_manager', None)
    if wm is None:
        return None
    return getattr(wm, 'smart_selector_suite_bridge_payloads', None)

def _draw_help_button(row, topic_id: str) -> None:
    if not topic_id:
        return
    try:
        help_row = row.row(align=True)
        help_row.scale_x = 0.82
        help_row.scale_y = 1.0
    except Exception:
        help_row = row
    try:
        op = _operator_with_icon(help_row, 'smart_selector_suite.show_help', text='', icon_name='help', fallback='QUESTION')
        op.topic_id = str(topic_id or '')
    except Exception:
        pass

# Blender icon id -> custom preview icon name for section headers.  Was referenced but never defined
# (NameError for any section drawn without icon_name, since 1.10.45); empty = fall back to the title.
_SECTION_ICON_NAME_MAP: dict = {}


def _section_icon_name(icon: str, title: str='') -> str:
    key = str(icon or '').strip()
    if key in _SECTION_ICON_NAME_MAP:
        return _SECTION_ICON_NAME_MAP[key]
    text = str(title or '').lower()
    if 'collection' in text or 'コレクション' in text:
        return 'collection'
    if 'gp' in text or 'grease' in text or 'セレクト' in text:
        return 'gp_select'
    if 'bridge' in text or 'ブリッジ' in text:
        return 'bridge'
    if 'setting' in text or '設定' in text:
        return 'settings'
    if 'selector' in text or 'セレクター' in text:
        return 'selector_list'
    if 'project' in text or 'プロジェクト' in text:
        return 'project'
    return ''

def _draw_section_header(layout, title: str, icon: str='NONE', help_topic: str=''):
    row = layout.row(align=True)
    _label_with_icon(row, str(title or ''), _section_icon_name(icon, title), icon)
    _draw_help_button(row, help_topic)
    return row

def _draw_project_section(layout, context) -> None:
    scene = getattr(context, 'scene', None)
    if scene is None:
        layout.label(text=_lang_text('Scene is not available.', 'シーンを取得できません。'), icon='ERROR')
        return
    col = layout.column(align=True)
    row = col.row(align=True)
    current_project = _safe_scene_project(scene)
    picker = row.row(align=True)
    try:
        picker.operator_context = 'INVOKE_DEFAULT'
    except Exception:
        pass
    picker.scale_y = 1.18
    _operator_with_icon(picker, 'smart_selector_suite.project_pick_search', text=current_project, icon_name='project', fallback='FILE_FOLDER', translate=False)
    _operator_with_icon(row, 'smart_selector_suite.open_project_folder', text='', icon_name='folder', fallback='FILE_FOLDER')
    tools = col.row(align=True)
    tools.scale_y = 1.25
    _operator_with_icon(tools, 'smart_selector_suite.project_create', text='', icon_name='add', fallback='ADD')
    _operator_with_icon(tools, 'smart_selector_suite.project_rename', text='', icon_name='rename', fallback='FILE_REFRESH')
    _operator_with_icon(tools, 'smart_selector_suite.project_duplicate', text='', icon_name='duplicate', fallback='DUPLICATE')
    _operator_with_icon(tools, 'smart_selector_suite.project_archive', text='', icon_name='archive', fallback='TRASH')

def _draw_selectors_section(layout, context) -> None:
    scene = getattr(context, 'scene', None)
    if scene is None:
        layout.label(text=_lang_text('Scene is not available.', 'シーンを取得できません。'), icon='ERROR')
        return
    header = layout.row(align=True)
    header.scale_y = 1.18
    _new_op = _operator_with_icon(header, 'smart_selector_suite.new_selector', text=tr_iface('Create New Selector'), icon_name='add', fallback='ADD')
    _new_op.mode = 'edit'
    tools = layout.row(align=True)
    tools.scale_y = 1.18
    _operator_with_icon(tools, 'smart_selector_suite.refresh_selector_files', text='', icon_name='refresh', fallback='FILE_REFRESH')
    if _scene_has_favorites_prop(scene):
        tools.prop(scene, 'smart_selector_suite_show_favorites_only', text=tr_iface('Favorites Only'), toggle=True)
    else:
        tools.label(text=tr_iface('Favorites Only'))
    _draw_selector_rows(layout, scene)

def _draw_settings_section(layout, context) -> None:
    layout.use_property_split = True
    layout.use_property_decorate = False
    prefs = _get_prefs(context)
    if prefs is None:
        layout.label(text=_lang_text('Settings are not available.', '設定を取得できません。'), icon='ERROR')
        layout.use_property_split = False
        return
    prefs_ui = _prefs_ui_runtime()
    draw_settings = getattr(prefs_ui, 'draw_settings_into_layout', None)
    if callable(draw_settings):
        draw_settings(layout, prefs)
        layout.use_property_split = False
        return
    _storage_box, storage_body = _child_collapsible_section_box(layout, section_key='settings_storage', label=_lang_text('Data Storage', 'データ保存先'), help_topic='settings_storage', default=False)
    if storage_body is not None:
        storage_body.use_property_split = False
        storage_body.label(text=_lang_text('Data Save Root Directory', 'データ保存ルートディレクトリ'))
        storage_body.prop(prefs, 'root_dir', text='')
    _perf_box, perf = _child_collapsible_section_box(layout, section_key='settings_performance', label=_lang_text('Performance / Safety', 'パフォーマンスと安全性'), help_topic='settings_performance', default=False)
    if perf is not None:
        perf.prop(prefs, 'state_update_interval')
        perf.prop(prefs, 'max_backup_generations')
        perf.prop(prefs, 'enable_exec_script')
    _projects_box, projects = _child_collapsible_section_box(layout, section_key='settings_project_list', label=_lang_text('Project List', 'プロジェクト一覧'), help_topic='settings_project_list', default=False)
    if projects is not None:
        projects.use_property_split = False
        projects.prop(prefs, 'show_archived_projects')
    layout.use_property_split = False

def _draw_bridge_actions_section(layout, context) -> None:
    layout.use_property_split = False
    layout.use_property_decorate = False
    props = _bridge_payload_props(context)
    if props is None:
        layout.label(text=_lang_text('Bridge payload storage is not available.', 'ブリッジ用ペイロード領域を取得できません。'), icon='ERROR')
        return
    _history_box, history = _child_collapsible_section_box(layout, section_key='bridge_undo_redo', label=_lang_text('Undo / Redo', '元に戻す・やり直し'), help_topic='bridge_undo_redo', default=False)
    if history is not None:
        row = history.row(align=True)
        row.scale_y = 1.18
        _operator_with_icon(row, 'smart_selector_suite.blender_undo', text=_lang_text('Undo', '元に戻す'), icon_name='undo', fallback='LOOP_BACK')
        _operator_with_icon(row, 'smart_selector_suite.blender_redo', text=_lang_text('Redo', 'やり直し'), icon_name='redo', fallback='LOOP_FORWARDS')
    _selection_box, selection_body = _child_collapsible_section_box(layout, section_key='bridge_selection', label=_lang_text('Apply Selection Payload', '選択ペイロード適用'), help_topic='bridge_selection', default=False)
    if selection_body is not None:
        selection_body.prop(props, 'selection_payload', text='JSON', translate=False)
        op = _operator_with_icon(selection_body, 'smart_selector_suite.apply_selection', text=_lang_text('Apply Selection', '選択を適用'), icon_name='apply', fallback='CHECKMARK')
        op.payload = props.selection_payload
    _shapekey_box, shapekey_body = _child_collapsible_section_box(layout, section_key='bridge_shapekey', label=_lang_text('Shape Key Payload', 'シェイプキーペイロード'), help_topic='bridge_shapekey', default=False)
    if shapekey_body is not None:
        shapekey_body.prop(props, 'shapekey_payload', text='JSON', translate=False)
        op = _operator_with_icon(shapekey_body, 'smart_selector_suite.set_shapekey', text=_lang_text('Set Shape Key', 'シェイプキーを設定'), icon_name='shapekey', fallback='SHAPEKEY_DATA')
        op.payload = props.shapekey_payload
    _custom_box, custom_body = _child_collapsible_section_box(layout, section_key='bridge_custom_prop', label=_lang_text('Custom Property Payload', 'カスタムプロパティペイロード'), help_topic='bridge_custom_prop', default=False)
    if custom_body is not None:
        custom_body.prop(props, 'custom_prop_payload', text='JSON', translate=False)
        op = _operator_with_icon(custom_body, 'smart_selector_suite.set_custom_prop', text=_lang_text('Set Custom Property', 'カスタムプロパティを設定'), icon_name='property', fallback='RNA')
        op.payload = props.custom_prop_payload
    _script_box, script_body = _child_collapsible_section_box(layout, section_key='bridge_script', label=_lang_text('Script Payload', 'スクリプトペイロード'), help_topic='bridge_script', default=False)
    if script_body is not None:
        script_body.prop(props, 'exec_script_payload', text='JSON', translate=False)
        op = _operator_with_icon(script_body, 'smart_selector_suite.exec_script', text=_lang_text('Execute Script', 'スクリプトを実行'), icon_name='script', fallback='TEXT')
        op.payload = props.exec_script_payload

def _draw_selection_sets_section(layout, context) -> None:
    try:
        from . import selection_sets as _selection_sets
        draw = getattr(_selection_sets, 'draw_selection_sets', None)
        if callable(draw):
            draw(layout, context)
            return
    except Exception as exc:
        try:
            layout.label(text=_lang_text(f'Selection Sets draw failed: {exc}', '選択セットを表示できませんでした。'), icon='ERROR')
        except Exception:
            pass
        return
    layout.label(text=_lang_text('Selection Sets are not available.', '選択セットを利用できません。'), icon='ERROR')

def _draw_integrated_tools_sections(layout, context) -> None:
    try:
        draw = getattr(_ui_runtime(), 'draw_integrated_sections', None)
        if callable(draw):
            draw(layout, context)
            return
    except Exception as exc:
        layout.label(text=_lang_text(f'Tool section draw failed: {exc}', 'このグループを表示できませんでした。'), icon='ERROR')
        return
    layout.label(text=_lang_text('Integrated tools are not available.', '統合ツールを取得できません。'), icon='ERROR')

def _draw_ark_face_section(layout, context) -> None:
    """「顔 ARKit」 section (1.10.46). Opens by default only in a file that has the ARKit face rig."""
    try:
        from . import ark_face as _ark_face
    except Exception:
        return
    try:
        rig_present = _ark_face.find_rig() is not None
    except Exception:
        rig_present = False
    _ark_box, ark_body = _collapsible_section_box(layout, section_key='ark_face', label=_lang_text('Face ARKit', '顔 ARKit'), icon='SHAPEKEY_DATA', icon_name='shapekey', help_topic='ark_face', default=rig_present)
    if ark_body is None:
        return
    try:
        _ark_face.draw_section(ark_body, context)
    except Exception as exc:
        try:
            ark_body.label(text=_lang_text(f'Face ARKit draw failed: {exc}', '顔 ARKit を表示できませんでした。'), icon='ERROR')
        except Exception:
            pass

def _draw_root_panel_body(context, layout):
    try:
        _always_on().draw_toggle_group(layout, context, _npanel_settings(context))
    except Exception:
        pass
    _draw_ark_face_section(layout, context)
    _selection_sets_box, selection_sets_body = _collapsible_section_box(layout, section_key='selection_sets', label=_lang_text('Selection Sets', '選択セット'), icon='GROUP', icon_name='group', help_topic='selection_sets', default=False)
    if selection_sets_body is not None:
        _draw_selection_sets_section(selection_sets_body, context)
    scene = getattr(context, 'scene', None)
    if scene is not None:
        _summary_box, summary = _collapsible_section_box(layout, section_key='summary', label='Smart Selector', icon='EVENT_S', icon_name='smart_selector', help_topic='smart_selector', default=False)
        if summary is not None:
            project, files, _favorite_names = _selector_files_for_scene(scene)
            _label_with_icon(summary, f"{tr_iface('Project')}: {project}", 'project', 'FILE_FOLDER')
            _label_with_icon(summary, f"{tr_iface('Selector Data List:')} {len(files)}", 'selector_list', 'PRESET')
            _summary_new = _operator_with_icon(summary, 'smart_selector_suite.new_selector', text=tr_iface('Create New Selector'), icon_name='add', fallback='ADD')
            _summary_new.mode = 'edit'
    _project_box, project_body = _collapsible_section_box(layout, section_key='project', label=tr_iface('Project'), icon='FILE_FOLDER', icon_name='project', help_topic='project', default=False)
    if project_body is not None:
        _draw_project_section(project_body, context)
    _selector_box, selector_body = _collapsible_section_box(layout, section_key='selector_data', label=tr_iface('Selector Data List'), icon='PRESET', icon_name='selector_list', help_topic='selector_data', default=False)
    if selector_body is not None:
        _draw_selectors_section(selector_body, context)
    _draw_integrated_tools_sections(layout, context)
    _settings_box, settings_body = _collapsible_section_box(layout, section_key='settings', label=_lang_text('Settings', '設定'), icon='PREFERENCES', icon_name='settings', help_topic='settings', default=False)
    if settings_body is not None:
        _draw_settings_section(settings_body, context)
    _bridge_box, bridge_body = _collapsible_section_box(layout, section_key='bridge_actions', label=_lang_text('Bridge Actions', 'ブリッジ操作'), icon='URL', icon_name='bridge', help_topic='bridge_actions', default=False)
    if bridge_body is not None:
        _draw_bridge_actions_section(bridge_body, context)

class SSSUITE_PT_root:
    bl_label = 'Smart Selector'
    bl_idname = 'VIEW3D_PT_smart_selector_suite_root'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = _NPANEL_CATEGORY
    bl_owner_id = _n_panel_owner_id()
    _sssuite_space_type = 'VIEW_3D'
    bl_description = 'Launch and manage every Smart Selector function from one standard Sidebar N-panel. Named selection sets, project tools, selector data, integrated tools, settings, and bridge actions are grouped inside this single panel.'

    @classmethod
    def poll(cls, context):
        if not _ui_runtime_alive() or context is None:
            return False
        _ensure_manager_policy_current()
        try:
            if getattr(context, 'scene', None) is None:
                return False
        except Exception:
            return False
        space_type = _panel_space_type(cls)
        if not _context_matches_panel_space(context, space_type):
            return False
        return bool(_manager_allows_current_panel(context, cls))

    def draw(self, context):
        _ensure_manager_policy_current(force=True)
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False
        try:
            _draw_root_panel_body(context, layout)
        except Exception as exc:
            try:
                box = layout.box()
                box.alert = True
                box.label(text=_lang_text(f'Smart Selector UI draw skipped: {exc}', 'このグループを表示できませんでした。'), icon='ERROR')
            except Exception:
                pass

    def _draw_safe(self, context, layout):
        _draw_root_panel_body(context, layout)

def _root_draw_header_preset(self, context):
    """1.10.52 (review fix 2): the ? help at the right end of the header of every root N-panel (SmartTools common help spec)."""
    del context
    try:
        _draw_help_button(self.layout, 'smart_selector')
    except Exception:
        pass

def _make_npanel_root_class(space_type: str, editor_keys=()):
    space = str(space_type or '').strip().upper()
    prefix = _NPANEL_PANEL_ID_PREFIX_BY_SPACE.get(space, space.replace('_', ''))
    suffix = space.lower()
    class_name = f'SSSUITE_PT_root_{suffix}'
    bl_idname = f'{prefix}_PT_smart_selector_suite_root'

    def _space_poll(cls, context):
        return SSSUITE_PT_root.poll.__func__(cls, context)

    def _space_draw(self, context):
        return SSSUITE_PT_root.draw(self, context)

    def _space_draw_safe(self, context, layout):
        return SSSUITE_PT_root._draw_safe(self, context, layout)

    def _space_draw_header(self, context):
        del self, context
        return None
    attrs = {'__module__': __name__, 'bl_label': SSSUITE_PT_root.bl_label, 'bl_idname': bl_idname, 'bl_space_type': space, 'bl_region_type': 'UI', 'bl_category': _NPANEL_CATEGORY, 'bl_owner_id': _n_panel_owner_id(), 'bl_description': SSSUITE_PT_root.bl_description, 'poll': classmethod(_space_poll), 'draw': _space_draw, '_draw_safe': _space_draw_safe, 'draw_header': _space_draw_header, 'draw_header_preset': _root_draw_header_preset, '_sssuite_space_type': space, '_sssuite_editor_keys': tuple((str(k or '').strip().upper() for k in editor_keys or ())), '_smart_tools_manager_no_cross_editor_proxy': True, '_smart_tools_manager_source_panel_is_native': True}
    return type(class_name, (SSSUITE_PT_root, bpy.types.Panel), attrs)
_SSSUITE_NPANEL_CLASSES = tuple((_make_npanel_root_class(space_type, editor_keys) for space_type, editor_keys in _NPANEL_SPACE_PANEL_SPECS))

def _native_npanel_method_bundle():

    def _space_poll(cls, context):
        return SSSUITE_PT_root.poll.__func__(cls, context)

    def _space_draw(self, context):
        return SSSUITE_PT_root.draw(self, context)

    def _space_draw_safe(self, context, layout):
        return SSSUITE_PT_root._draw_safe(self, context, layout)

    def _space_draw_header(self, context):
        del self, context
        return None
    return (_space_poll, _space_draw, _space_draw_safe, _space_draw_header)

def repair_native_npanel_classes() -> int:
    """Restore native callbacks only when an external wrapper replaced them.

    The stable path performs no RNA callback assignment. This matters because
    Blender may call this compatibility check while a Sidebar category is open;
    mutating registered Panel methods on every redraw can cause visible latency
    and is unsafe for the C-side ui_handler_panel callback cache.
    """
    repaired = 0
    space_poll, space_draw, space_draw_safe, space_draw_header = _native_npanel_method_bundle()
    for cls in _SSSUITE_NPANEL_CLASSES:
        targets = []
        try:
            existing = bpy.types.Panel.bl_rna_get_subclass_py(str(getattr(cls, 'bl_idname', '') or ''))
            if isinstance(existing, type):
                targets.append(existing)
        except Exception:
            pass
        if cls not in targets:
            targets.append(cls)
        for target in targets:
            try:
                if str(getattr(target, 'bl_category', '') or '') != _NPANEL_CATEGORY:
                    setattr(target, 'bl_category', _NPANEL_CATEGORY)
                    repaired += 1
                owner_id = _n_panel_owner_id()
                if str(getattr(target, 'bl_owner_id', '') or '') != owner_id:
                    setattr(target, 'bl_owner_id', owner_id)
                    repaired += 1
                current_poll = getattr(target, 'poll', None)
                poll_func = getattr(current_poll, '__func__', current_poll)
                poll_module = str(getattr(poll_func, '__module__', '') or '')
                poll_wrapped = bool(getattr(poll_func, '_smart_tools_manager_wrapper', False))
                if poll_wrapped or 'smart_tools_manager' in poll_module:
                    setattr(target, 'poll', classmethod(space_poll))
                    repaired += 1
                current_draw = getattr(target, 'draw', None)
                draw_func = getattr(current_draw, '__func__', current_draw)
                draw_module = str(getattr(draw_func, '__module__', '') or '')
                draw_wrapped = bool(getattr(draw_func, '_smart_tools_manager_wrapper', False))
                if draw_wrapped or 'smart_tools_manager' in draw_module or (not callable(current_draw)):
                    setattr(target, 'draw', space_draw)
                    setattr(target, '_draw_safe', space_draw_safe)
                    repaired += 1
                current_header = getattr(target, 'draw_header', None)
                header_func = getattr(current_header, '__func__', current_header)
                header_module = str(getattr(header_func, '__module__', '') or '')
                header_wrapped = bool(getattr(header_func, '_smart_tools_manager_wrapper', False))
                if header_wrapped or 'smart_tools_manager' in header_module:
                    setattr(target, 'draw_header', space_draw_header)
                    setattr(target, 'draw_header_preset', _root_draw_header_preset)
                    repaired += 1
                if not bool(getattr(target, '_smart_tools_manager_no_cross_editor_proxy', False)):
                    setattr(target, '_smart_tools_manager_no_cross_editor_proxy', True)
                    repaired += 1
                if not bool(getattr(target, '_smart_tools_manager_source_panel_is_native', False)):
                    setattr(target, '_smart_tools_manager_source_panel_is_native', True)
                    repaired += 1
            except Exception:
                pass
    return repaired

def _purge_legacy_npanel_classes() -> None:
    """Compatibility no-op. Process-global patching and name-based purge are intentionally disabled."""
    return None
_PANEL_CLASSES = [*_SSSUITE_NPANEL_CLASSES]

def _safe_register_class(cls):
    existing = getattr(bpy.types, cls.__name__, None)
    if existing is cls:
        return
    if isinstance(existing, type):
        try:
            bpy.utils.unregister_class(existing)
        except Exception:
            pass
    try:
        bpy.utils.register_class(_i18n_localize_class(cls))
    except RuntimeError as exc:
        if 'already registered as a subclass' not in str(exc):
            raise
        existing = getattr(bpy.types, cls.__name__, None)
        if isinstance(existing, type):
            try:
                bpy.utils.unregister_class(existing)
            except Exception:
                pass
        bpy.utils.register_class(_i18n_localize_class(cls))
    except ValueError as exc:
        if 'already registered as a subclass' not in str(exc):
            raise

def _safe_unregister_class(cls):
    target = getattr(bpy.types, cls.__name__, None)
    if isinstance(target, type):
        try:
            bpy.utils.unregister_class(target)
            return
        except Exception:
            pass
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass
classes = (SSSUITE_BridgePayloadProperties, SSSUITE_NPanelSettings, SSSUITE_OT_show_help, SSSUITE_OT_toggle_ui_section, SSSUITE_OT_open_project_folder, SSSUITE_OT_set_active_project, SSSUITE_MT_project_list, SSSUITE_OT_project_pick_search, SSSUITE_OT_project_create, SSSUITE_OT_project_rename, SSSUITE_OT_project_duplicate, SSSUITE_OT_project_archive, SSSUITE_OT_new_selector, SSSUITE_OT_refresh_selector_files, SSSUITE_OT_open_selector, SSSUITE_OT_exec_script, SSSUITE_OT_set_shapekey, SSSUITE_OT_set_custom_prop, SSSUITE_OT_apply_selection, SSSUITE_OT_blender_undo, SSSUITE_OT_blender_redo, SSSUITE_OT_toggle_favorite, *_SSSUITE_NPANEL_CLASSES)

def pre_reload_cleanup():
    global _UI_UNREGISTERING
    _UI_UNREGISTERING = True
    _tag_redraw_all_view3d()

def register():
    global _UI_UNREGISTERING, _TOOLTIP_AUDIT_READY
    _UI_UNREGISTERING = False
    _TOOLTIP_AUDIT_READY = False
    _SELECTOR_FILES_CACHE.clear()
    _purge_legacy_npanel_classes()
    for cls in classes:
        _safe_register_class(cls)
    try:
        repair_native_npanel_classes()
    except Exception:
        pass
    try:
        _ensure_bridge_payload_storage()
    except Exception:
        pass
    try:
        _ensure_npanel_settings_storage()
    except Exception:
        pass
    try:
        _refresh_selector_files_cache(getattr(bpy.context, 'scene', None))
    except Exception:
        pass
    _tag_redraw_all_view3d()

def unregister():
    global _UI_UNREGISTERING, _TOOLTIP_AUDIT_READY
    _UI_UNREGISTERING = True
    _TOOLTIP_AUDIT_READY = False
    _SELECTOR_FILES_CACHE.clear()
    _tag_redraw_all_view3d()
    _purge_legacy_npanel_classes()
    try:
        if hasattr(bpy.types.WindowManager, 'smart_selector_suite_bridge_payloads'):
            del bpy.types.WindowManager.smart_selector_suite_bridge_payloads
    except Exception:
        pass
    try:
        if hasattr(bpy.types.WindowManager, 'smart_selector_suite_npanel_settings'):
            del bpy.types.WindowManager.smart_selector_suite_npanel_settings
    except Exception:
        pass
    for cls in reversed(classes):
        _safe_unregister_class(cls)
