# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Keep Selector settings and generated data in Blender's private configuration."""

from contextlib import suppress
from errno import ENOSYS, ENOTSUP, EPERM
import json
import os
from pathlib import Path
from shutil import copy2, copyfileobj, copystat
import sys
from tempfile import NamedTemporaryFile

try:
    import bpy
except ImportError:
    bpy = None

PACKAGE_ID = "smart_selector_suite"
USER_DATA_DIRNAME = "user_data"
CONFIG_DIRNAME = "Smart_Selector_Suite"


def _configuration():
    if bpy is not None:
        try:
            root = bpy.utils.user_resource("CONFIG", create=False)
        except TypeError:
            try:
                root = bpy.utils.user_resource("CONFIG")
            except (OSError, RuntimeError, TypeError):
                root = None
        except (OSError, RuntimeError):
            root = None
        if root:
            return Path(root).expanduser()
    version = ".".join(map(str, bpy.app.version[:2])) if bpy else "5.1"
    if sys.platform == "win32":
        roaming = Path(os.environ.get("APPDATA") or Path.home() / "AppData/Roaming")
        parent = roaming / "Blender Foundation/Blender"
    elif sys.platform == "darwin":
        parent = Path.home() / "Library/Application Support/Blender"
    else:
        parent = Path.home() / ".config/blender"
    return parent / version / "config"


def _components(parts):
    """Use legacy relative names while keeping drive and stream names out."""
    items = []
    for part in parts:
        for item in str(part or "").replace("\\", "/").split("/"):
            if item in ("", ".", ".."):
                continue
            if ":" in item or "\0" in item:
                raise ValueError("Expected a relative file or directory name")
            items.append(item)
    return items


def _directory(path, create):
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def _file(root, parts, create, allow_empty=False):
    suffix = _components(parts)
    if not suffix:
        if allow_empty:
            return _directory(root, create)
        raise ValueError("A file name is required")
    path = root.joinpath(*suffix)
    _directory(path.parent, create)
    return path


def mutable_root(*parts, create=False):
    base = _configuration() / CONFIG_DIRNAME
    return _directory(base.joinpath(*_components(parts)), create)


def package_id(default=None):
    name = str(default or PACKAGE_ID).strip().rsplit(".", 1)[-1].strip().strip("\"'")
    if any(symbol in name for symbol in ("/", "\\", ":", "\0")):
        raise ValueError("Expected a Blender package identifier")
    return name or PACKAGE_ID


def manifest_extension_id(default=PACKAGE_ID):
    return package_id(default)


def extension_user_root(package=None, *, create=False):
    """Resolve the read-only extension path, including installs in user_default."""
    identifier = package_id(package)
    module_root = Path(__file__).resolve().parent
    if (identifier == PACKAGE_ID and module_root.name == PACKAGE_ID
            and module_root.parent.name == "user_default"
            and module_root.parent.parent.name == "extensions"):
        return module_root
    config = _configuration()
    version_root = config.parent if config.name.lower() == "config" else config
    return version_root / "extensions" / "user_default" / identifier


def extension_dir(create=False):
    return extension_user_root()


def user_default_root(*parts, package_id=None, create=True):
    return mutable_root(*parts, create=create)


def user_data_dir(*parts, create=False):
    return mutable_root(USER_DATA_DIRNAME, *parts, create=create)


def user_data_file(*parts, create_parent=False):
    return _file(user_data_dir(), parts, create_parent)


def addon_data_dir(*parts, create=True):
    return user_data_dir("data", *parts, create=create)


def addon_data_path(*parts, create=True):
    return _file(addon_data_dir(create=False), parts, create, allow_empty=True)


def storage_dir(*parts, create=True):
    return user_data_dir("storage", *parts, create=create)


def storage_path(filename, *parts, create=True):
    return _file(storage_dir(create=False), (*parts, filename), create)


addon_storage_dir = storage_dir
data_dir = addon_data_dir


def settings_dir(*parts, create=True):
    return user_data_dir("settings", *parts, create=create)


def runtime_dir(*parts, create=True, package=None):
    return user_data_dir("runtime", *parts, create=create)


def settings_file(name, *, create=True):
    return _file(settings_dir(create=False), (name,), create)


def runtime_file(filename, *subdirs, create=True, package=None):
    return _file(runtime_dir(create=False, package=package), (*subdirs, filename), create)


def addon_storage_path(filename, *subdirs, package_id=None, create=True):
    return storage_path(filename, *subdirs, create=create)


def write_json(filename, payload, subdir="reports"):
    path = user_data_file(subdir, filename, create_parent=True)
    atomic_write_json(path, payload)
    return path


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError, TypeError):
        return default


def atomic_write_text(path, text, *, encoding="utf-8"):
    target = Path(path)
    _directory(target.parent, True)
    pending = None
    try:
        with NamedTemporaryFile(mode="w", encoding=encoding, dir=target.parent,
                                prefix="." + target.name + "-", suffix=".tmp",
                                delete=False) as output:
            pending = Path(output.name)
            output.write(text)
        pending.replace(target)
    finally:
        if pending is not None:
            pending.unlink(missing_ok=True)


def atomic_write_json(path, data, *, indent=2, ensure_ascii=False, sort_keys=False):
    message = json.dumps(data, indent=indent, ensure_ascii=ensure_ascii,
                         sort_keys=sort_keys, default=str)
    atomic_write_text(path, message)


def migrate_legacy_file(legacy_path, target_path, *, remove_legacy=False):
    """Copy once to the new location and keep the legacy file intact."""
    if legacy_path is None or target_path is None:
        return False
    source, target = Path(legacy_path), Path(target_path)
    if not source.is_file() or target.exists():
        return False
    pending = None
    try:
        _directory(target.parent, True)
        with NamedTemporaryFile(dir=target.parent, prefix=".migration-", delete=False) as staged:
            pending = Path(staged.name)
        copy2(source, pending)
        # Link the complete payload into place without claiming a concurrent writer's file.
        if sys.platform == "win32":
            pending.rename(target)  # Windows rename never replaces an existing file.
        else:
            try:
                os.link(pending, target)
            except OSError as error:
                if error.errno not in (ENOSYS, ENOTSUP, EPERM):
                    raise
                # Some file systems lack hard links. Create exclusively there too.
                with pending.open("rb") as original:
                    output = target.open("xb")
                    try:
                        with output:
                            copyfileobj(original, output)
                        copystat(pending, target)
                    except OSError:
                        target.unlink(missing_ok=True)
                        raise
        return True
    except OSError:
        return False
    finally:
        if pending is not None:
            with suppress(OSError):
                pending.unlink(missing_ok=True)
