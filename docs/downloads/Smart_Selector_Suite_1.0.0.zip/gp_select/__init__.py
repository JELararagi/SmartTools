import bpy
from .. import settings as _sssuite_settings
from ..translation import is_japanese_locale as _i18n_is_japanese_locale, localize_class as _i18n_localize_class, operator_label as _i18n_operator_label, t as _i18n_text
import re
import time
import bmesh
from mathutils import Vector
from math import radians, sin, cos, pi
from bpy.app.handlers import persistent
from bpy.props import IntProperty, StringProperty, FloatProperty
try:
    from ..translation_data import report_runtime_message as _sssuite_report
except Exception:

    def _sssuite_report(operator, report_types, message):
        try:
            operator.report(report_types, str(message or ''))
        except Exception:
            pass

class _SSS_DummyUIOperator:

    def __setattr__(self, _name, _value):
        return None

    def __getattr__(self, _name):
        return ''

def _can_invoke_blender_ui(context) -> bool:
    try:
        if bool(getattr(bpy.app, 'background', False)):
            return False
        if context is None:
            return False
        if getattr(context, 'window_manager', None) is None:
            return False
        if getattr(context, 'window', None) is None:
            return False
        return True
    except Exception:
        return False

def _safe_invoke_props_dialog(operator, context, *, width=None):
    if not _can_invoke_blender_ui(context):
        return {'CANCELLED'}
    try:
        wm = context.window_manager
        if width is None:
            return wm.invoke_props_dialog(operator)
        return wm.invoke_props_dialog(operator, width=width)
    except Exception:
        return {'CANCELLED'}

def _safe_invoke_confirm(operator, context, event, **kwargs):
    if not _can_invoke_blender_ui(context):
        return {'CANCELLED'}
    try:
        return context.window_manager.invoke_confirm(operator, event, **kwargs)
    except TypeError:
        try:
            return context.window_manager.invoke_confirm(operator, event)
        except Exception:
            return {'CANCELLED'}
    except Exception:
        return {'CANCELLED'}

def _safe_icon_string(icon: str, fallback: str='NONE') -> str:
    value = str(icon or fallback or 'NONE').strip() or 'NONE'
    return value if value.upper() != 'NONE' else 'NONE'

def _operator_with_icon(layout, operator_id: str, *args, text=None, icon='NONE', **kwargs):
    """Draw operator buttons defensively for Blender 5.1 UI redraws."""
    icon = str(icon or 'NONE')
    if text is None:
        text = _i18n_operator_label(operator_id)
    call_kwargs = dict(kwargs)
    icon_token = icon.strip().upper()
    has_icon = icon_token not in {'', 'NONE', 'BLANK1'}
    if text is not None and str(text or '') == '' and has_icon and (call_kwargs.get('emboss') is False):
        call_kwargs.pop('emboss', None)
    try:
        explicit_icon_value = int(call_kwargs.pop('icon_value', 0) or 0)
    except Exception:
        explicit_icon_value = 0
    if explicit_icon_value > 0:
        icon_kwargs = {'icon_value': explicit_icon_value}
    else:
        try:
            from .. import icons as _sssuite_icons
            icon_kwargs = dict(_sssuite_icons.kwargs_for_blender_icon(icon, icon))
        except Exception:
            icon_kwargs = {'icon': icon}
    try:
        if text is None:
            return layout.operator(operator_id, *args, **icon_kwargs, **call_kwargs)
        return layout.operator(operator_id, *args, text=text, **icon_kwargs, **call_kwargs)
    except Exception:
        pass
    try:
        if text is None:
            return layout.operator(operator_id, *args, icon=_safe_icon_string(icon), **call_kwargs)
        return layout.operator(operator_id, *args, text=text, icon=_safe_icon_string(icon), **call_kwargs)
    except Exception:
        pass
    try:
        if text is None:
            return layout.operator(operator_id, *args, icon='NONE', **call_kwargs)
        return layout.operator(operator_id, *args, text=text, icon='NONE', **call_kwargs)
    except Exception:
        try:
            layout.label(text=str(text or '') if text is not None else '', icon='ERROR')
        except Exception:
            pass
        return _SSS_DummyUIOperator()

def _prop_with_icon(layout, data, property_name: str, *args, text=None, icon='NONE', **kwargs):
    """Draw property widgets defensively for Blender 5.1 UI redraws."""
    icon = str(icon or 'NONE')
    call_kwargs = dict(kwargs)
    try:
        explicit_icon_value = int(call_kwargs.pop('icon_value', 0) or 0)
    except Exception:
        explicit_icon_value = 0
    if explicit_icon_value > 0:
        icon_kwargs = {'icon_value': explicit_icon_value}
    else:
        try:
            from .. import icons as _sssuite_icons
            icon_kwargs = dict(_sssuite_icons.kwargs_for_blender_icon(icon, icon))
        except Exception:
            icon_kwargs = {'icon': icon}
    try:
        if text is None:
            return layout.prop(data, property_name, *args, **icon_kwargs, **call_kwargs)
        return layout.prop(data, property_name, *args, text=text, **icon_kwargs, **call_kwargs)
    except Exception:
        pass
    try:
        if text is None:
            return layout.prop(data, property_name, *args, icon=_safe_icon_string(icon), **call_kwargs)
        return layout.prop(data, property_name, *args, text=text, icon=_safe_icon_string(icon), **call_kwargs)
    except Exception:
        pass
    try:
        if text is None:
            return layout.prop(data, property_name, *args, icon='NONE', **call_kwargs)
        return layout.prop(data, property_name, *args, text=text, icon='NONE', **call_kwargs)
    except Exception:
        return None

def _sssuite_handler_list(name: str):
    try:
        return getattr(bpy.app.handlers, str(name or ''), None)
    except Exception:
        return None

def _sssuite_handler_contains(name: str, callback) -> bool:
    h_list = _sssuite_handler_list(name)
    try:
        return h_list is not None and callback in h_list
    except Exception:
        return False

def _sssuite_handler_remove(name: str, callback) -> bool:
    h_list = _sssuite_handler_list(name)
    if h_list is None:
        return False
    try:
        if callback in h_list:
            h_list.remove(callback)
            return True
    except Exception:
        pass
    return False

def _sssuite_handler_append_once(name: str, callback) -> bool:
    h_list = _sssuite_handler_list(name)
    if h_list is None:
        return False
    try:
        if callback in h_list:
            h_list.remove(callback)
        h_list.append(callback)
        return True
    except Exception:
        return False

def _gp_lang_text(en: str, ja: str) -> str:
    try:
        return str(ja if _i18n_is_japanese_locale() else en)
    except Exception:
        return str(en)

def _sssuite_get_string_setting(key: str, default: str='') -> str:
    return str(_sssuite_settings.get_value(key, default) or '')

def _sssuite_set_string_setting(key: str, value) -> None:
    _sssuite_settings.set_value(key, str(value if value is not None else ''))

def _sssuite_get_float_setting(key: str, default: float=0.0) -> float:
    try:
        return float(_sssuite_settings.get_value(key, default))
    except Exception:
        return float(default)

def _sssuite_set_float_setting(key: str, value) -> None:
    try:
        _sssuite_settings.set_value(key, float(value))
    except Exception:
        _sssuite_settings.set_value(key, 0.0)

def _sssuite_get_int_setting(key: str, default: int=0) -> int:
    try:
        return int(_sssuite_settings.get_value(key, default))
    except Exception:
        return int(default)

def _sssuite_set_int_setting(key: str, value) -> None:
    try:
        _sssuite_settings.set_value(key, int(value))
    except Exception:
        _sssuite_settings.set_value(key, 0)

def _sssuite_string_getter(key: str, default: str=''):
    return lambda _self: _sssuite_get_string_setting(key, default)

def _sssuite_string_setter(key: str):
    return lambda _self, value: _sssuite_set_string_setting(key, value)

def _sssuite_float_getter(key: str, default: float=0.0):
    return lambda _self: _sssuite_get_float_setting(key, default)

def _sssuite_float_setter(key: str):
    return lambda _self, value: _sssuite_set_float_setting(key, value)

def _sssuite_int_getter(key: str, default: int=0):
    return lambda _self: _sssuite_get_int_setting(key, default)

def _sssuite_int_setter(key: str):
    return lambda _self, value: _sssuite_set_int_setting(key, value)

class GPRenamerProperties(bpy.types.PropertyGroup):
    rename_str: bpy.props.StringProperty(name='Text', description='Function: stores the text used as a prefix or suffix for selected Grease Pencil layer names. How to use: enter the affix text, then press Prefix or Suffix in the Renaming and Pass Index group; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.', get=_sssuite_string_getter('gp_rename_str', ''), set=_sssuite_string_setter('gp_rename_str'))
    full_name: bpy.props.StringProperty(name='New Name', description='Function: stores the full replacement name for selected Grease Pencil layers. How to use: enter the new layer name, then press Rename in the Renaming and Pass Index group; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.', get=_sssuite_string_getter('gp_full_name', ''), set=_sssuite_string_setter('gp_full_name'))
    find_str: bpy.props.StringProperty(description='Function: stores the Grease Pencil layer rename find str text. How to use: enter text in the GP Select rename panel, then run the matching find-and-replace command.', name='Find', get=_sssuite_string_getter('gp_find_str', ''), set=_sssuite_string_setter('gp_find_str'))
    replace_str: bpy.props.StringProperty(description='Function: stores the Grease Pencil layer rename replace str text. How to use: enter text in the GP Select rename panel, then run the matching find-and-replace command.', name='Replace', get=_sssuite_string_getter('gp_replace_str', ''), set=_sssuite_string_setter('gp_replace_str'))
    target_opacity: bpy.props.FloatProperty(name='Opacity', description='Function: stores the opacity value applied to layers that contain selected Grease Pencil strokes. How to use: set the slider value, then press the opacity apply button; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.', get=_sssuite_float_getter('gp_target_opacity', 0.5), set=_sssuite_float_setter('gp_target_opacity'), min=0.0, max=1.0, precision=3)
    target_pass_index: bpy.props.IntProperty(name='Pass Index', description='Function: stores the Pass Index value applied to selected Grease Pencil layers or materials. How to use: enter the numeric Pass value, then press the layer or material Pass Index button; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.', min=0, get=_sssuite_int_getter('gp_target_pass_index', 0), set=_sssuite_int_setter('gp_target_pass_index'))
    target_sensitivity: bpy.props.FloatProperty(name='Sensitivity', description='Function: stores the Time Offset Driver Generator sensitivity value. How to use: adjust this before creating or updating GP Select rigging drivers; the value is saved according to N-panel State Save and restored after Blender restarts or scene changes.', min=0.0, get=_sssuite_float_getter('gp_target_sensitivity', 5.0), set=_sssuite_float_setter('gp_target_sensitivity'))

class GP_OT_rename_prefix(bpy.types.Operator):
    """Add Prefix to layers with selected strokes"""
    bl_idname = 'gpencil.rename_selected_layers'
    bl_label = 'Add Prefix to Selected'
    bl_description = 'Function: Add Prefix to layers with selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        scene = context.scene
        props = scene.gp_renamer_props
        current_frame_num = scene.frame_current
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        gp_data = obj.data
        selected_layers = set()
        count = 0
        for layer in gp_data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                active_frame = None
                for frame in layer.frames:
                    if frame.frame_number <= current_frame_num:
                        if active_frame is None or frame.frame_number > active_frame.frame_number:
                            active_frame = frame
                if active_frame and active_frame.drawing:
                    if any((s.select for s in active_frame.drawing.strokes)):
                        selected_layers.add(layer)
        for layer in selected_layers:
            if not layer.name.startswith(props.rename_str):
                layer.name = props.rename_str + layer.name
                count += 1
        _sssuite_report(self, {'INFO'}, f'Renamed {count} layers.')
        return {'FINISHED'}

class GP_OT_rename_full_selected(bpy.types.Operator):
    """Replace full name of layers """
    bl_idname = 'gpencil.rename_full_selected'
    bl_label = 'Rename Full Name'
    bl_description = 'Function: Replace full name of layers. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        scene = context.scene
        props = scene.gp_renamer_props
        current_frame_num = scene.frame_current
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        gp_data = obj.data
        selected_layers = set()
        for layer in gp_data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                active_frame = None
                for frame in layer.frames:
                    if frame.frame_number <= current_frame_num:
                        if active_frame is None or frame.frame_number > active_frame.frame_number:
                            active_frame = frame
                if active_frame and active_frame.drawing:
                    if any((s.select for s in active_frame.drawing.strokes)):
                        selected_layers.add(layer)
        for layer in selected_layers:
            layer.name = props.full_name
        _sssuite_report(self, {'INFO'}, f"Renamed {len(selected_layers)} layers to '{props.full_name}'.")
        return {'FINISHED'}

class GP_OT_rename_suffix_selected(bpy.types.Operator):
    """Add suffix to layers with selected strokes"""
    bl_idname = 'gpencil.rename_suffix_selected'
    bl_label = 'Add Suffix'
    bl_description = 'Function: Add suffix to layers with selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        scene = context.scene
        props = scene.gp_renamer_props
        current_frame_num = scene.frame_current
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        gp_data = obj.data
        selected_layers = set()
        count = 0
        for layer in gp_data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                active_frame = None
                for frame in layer.frames:
                    if frame.frame_number <= current_frame_num:
                        if active_frame is None or frame.frame_number > active_frame.frame_number:
                            active_frame = frame
                if active_frame and active_frame.drawing:
                    if any((s.select for s in active_frame.drawing.strokes)):
                        selected_layers.add(layer)
        if not selected_layers:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        for layer in selected_layers:
            if not layer.name.endswith(props.rename_str):
                layer.name = layer.name + props.rename_str
                count += 1
        _sssuite_report(self, {'INFO'}, f'Added suffix to {count} layers.')
        return {'FINISHED'}

class GP_OT_clean_layer_names(bpy.types.Operator):
    """Remove Digits and Punctuation from layers with selected strokes"""
    bl_idname = 'gpencil.clean_selected_layer_names'
    bl_label = 'Clean Digits/Punctuation'
    bl_description = 'Function: Remove Digits and Punctuation from layers with selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        scene = context.scene
        current_frame_num = scene.frame_current
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        gp_data = obj.data
        selected_layers = set()
        count = 0
        for layer in gp_data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                active_frame = None
                for frame in layer.frames:
                    if frame.frame_number <= current_frame_num:
                        if active_frame is None or frame.frame_number > active_frame.frame_number:
                            active_frame = frame
                if active_frame and active_frame.drawing:
                    if any((s.select for s in active_frame.drawing.strokes)):
                        selected_layers.add(layer)
        for layer in selected_layers:
            old_name = layer.name
            new_name = re.sub('[^a-zA-Z\\s]+$', '', old_name).strip()
            if not new_name:
                new_name = 'Cleaned_Layer'
            if old_name != new_name:
                layer.name = new_name
                count += 1
        _sssuite_report(self, {'INFO'}, f'Cleaned {count} layer names.')
        return {'FINISHED'}

class GP_OT_find_replace_selected(bpy.types.Operator):
    """Find and replace text in layers of selected strokes"""
    bl_idname = 'gpencil.find_replace_selected'
    bl_label = 'Replace Text'
    bl_description = 'Function: Find and replace text in layers of selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        valid_found = False
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frame = layer.current_frame()
                if frame and frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    valid_found = True
                    break
            if valid_found:
                break
        if not valid_found:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        scene = context.scene
        props = scene.gp_renamer_props
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        selected_layers = []
        for l in obj.data.layers:
            parent_hidden = l.parent_group.hide if l.parent_group else False
            if not l.hide and (not l.lock) and (not parent_hidden):
                if any((s.select for f in l.frames if f.drawing for s in f.drawing.strokes)):
                    selected_layers.append(l)
        if not selected_layers:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        count = 0
        for layer in selected_layers:
            if props.find_str in layer.name:
                layer.name = layer.name.replace(props.find_str, props.replace_str)
                count += 1
        _sssuite_report(self, {'INFO'}, f'Modified {count} layer names.')
        return {'FINISHED'}

class GP_OT_clear_single_field(bpy.types.Operator):
    """Clear a specific text field"""
    bl_idname = 'gpencil.clear_single_field'
    bl_label = 'Clear'
    bl_description = 'Function: Clear a specific text field. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO', 'INTERNAL'}
    field_name: bpy.props.StringProperty(description='Function: supplies the Field Name parameter used by this command. How to use: the N-panel button or browser bridge fills this automatically before execution; manual editing is normally unnecessary.')

    def execute(self, context):
        props = context.scene.gp_renamer_props
        setattr(props, self.field_name, '')
        return {'FINISHED'}

class GP_OT_select_similar_prefix(bpy.types.Operator):
    """Select strokes in all layers that share the same prefixes as the selected strokes ( Respects the Multiframe setting.You only need one of each selected ) """
    bl_idname = 'gpencil.select_similar_prefix'
    bl_label = 'Select Similar Prefix'
    bl_description = 'Function: Select strokes in all layers that share the same prefixes as the selected strokes ( Respects the Multiframe setting.You only need one of each selected ). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        scene = context.scene
        if not obj or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        gp_data = obj.data
        current_frame_num = scene.frame_current
        ts = context.scene.tool_settings
        use_multiframe = ts.use_grease_pencil_multi_frame_editing
        detected_prefixes = set()
        for layer in gp_data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frames_to_check = layer.frames if use_multiframe else [layer.current_frame()]
                for f in frames_to_check:
                    if f and hasattr(f, 'drawing') and f.drawing:
                        if any((s.select for s in f.drawing.strokes)):
                            name = layer.name
                            prefix = ''
                            if ' ' in name:
                                prefix = name.split(' ')[0] + ' '
                            elif ')' in name:
                                prefix = name.split(')')[0] + ')'
                            elif ':' in name:
                                prefix = name.split(':')[0] + ':'
                            else:
                                prefix = name if len(name) > 0 else ''
                            if prefix:
                                detected_prefixes.add(prefix)
                                break
        if not detected_prefixes:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        for layer in gp_data.layers:
            for frame in layer.frames:
                if hasattr(frame, 'drawing') and frame.drawing:
                    for stroke in frame.drawing.strokes:
                        stroke.select = False
        stroke_count = 0
        for layer in gp_data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                if any((layer.name.startswith(p) for p in detected_prefixes)):
                    if use_multiframe:
                        target_frames = [f for f in layer.frames if hasattr(f, 'drawing') and f.drawing]
                    else:
                        active_frame = None
                        for frame in layer.frames:
                            if frame.frame_number <= current_frame_num:
                                if active_frame is None or frame.frame_number > active_frame.frame_number:
                                    active_frame = frame
                        target_frames = [active_frame] if active_frame else []
                    for frame in target_frames:
                        if frame and hasattr(frame, 'drawing') and frame.drawing:
                            for stroke in frame.drawing.strokes:
                                stroke.select = True
                                stroke_count += 1
        current_mode = context.object.mode
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode=current_mode)
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
        prefix_list_str = ', '.join((f"'{p}'" for p in detected_prefixes))
        _sssuite_report(self, {'INFO'}, f'Selected: {prefix_list_str}')
        return {'FINISHED'}

class GP_OT_select_similar_suffix(bpy.types.Operator):
    """Select strokes in all layers that share the same suffixes as the selected strokes( Works with Punctuation. Respects the Multiframe setting. You only need one of each selected )"""
    bl_idname = 'gpencil.select_similar_suffix'
    bl_label = 'Select Similar Suffix'
    bl_description = 'Function: Select strokes in all layers that share the same suffixes as the selected strokes( Works with Punctuation. Respects the Multiframe setting. You only need one of each selected ). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        scene = context.scene
        if not obj or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        gp_data = obj.data
        current_frame_num = scene.frame_current
        ts = context.scene.tool_settings
        use_multiframe = ts.use_grease_pencil_multi_frame_editing
        detected_suffixes = set()
        for layer in gp_data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frames_to_check = layer.frames if use_multiframe else [layer.current_frame()]
                for f in frames_to_check:
                    if f and hasattr(f, 'drawing') and f.drawing:
                        if any((s.select for s in f.drawing.strokes)):
                            name = layer.name
                            match = re.search('[ ._][^ ._]+$', name)
                            if match:
                                suffix = match.group(0)
                                detected_suffixes.add(suffix)
                                break
                            elif name:
                                detected_suffixes.add(name)
                                break
        if not detected_suffixes:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        for layer in gp_data.layers:
            for frame in layer.frames:
                if hasattr(frame, 'drawing') and frame.drawing:
                    for stroke in frame.drawing.strokes:
                        stroke.select = False
        for layer in gp_data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                if any((layer.name.endswith(s) for s in detected_suffixes)):
                    if use_multiframe:
                        target_frames = [f for f in layer.frames if hasattr(f, 'drawing') and f.drawing]
                    else:
                        active_frame = None
                        for frame in layer.frames:
                            if frame.frame_number <= current_frame_num:
                                if active_frame is None or frame.frame_number > active_frame.frame_number:
                                    active_frame = frame
                        target_frames = [active_frame] if active_frame else []
                    for frame in target_frames:
                        if frame and hasattr(frame, 'drawing') and frame.drawing:
                            for stroke in frame.drawing.strokes:
                                stroke.select = True
        current_mode = context.object.mode
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode=current_mode)
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
        suffix_list_str = ', '.join((f"'{s}'" for s in detected_suffixes))
        _sssuite_report(self, {'INFO'}, f'Selected suffix: {suffix_list_str}')
        return {'FINISHED'}

class GP_OT_select_similar_infix(bpy.types.Operator):
    """Select strokes in all layers that share the same infix as the selected strokes( Respects the Multiframe setting. You only need one of each selected ) """
    bl_idname = 'gpencil.select_similar_infix'
    bl_label = 'Select Similar Infix'
    bl_description = 'Function: Select strokes in all layers that share the same infix as the selected strokes( Respects the Multiframe setting. You only need one of each selected ). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        scene = context.scene
        if not obj or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        gp_data = obj.data
        current_frame_num = scene.frame_current
        ts = context.scene.tool_settings
        use_multiframe = ts.use_grease_pencil_multi_frame_editing
        detected_infixes = set()
        for layer in gp_data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frames_to_check = layer.frames if use_multiframe else [layer.current_frame()]
                for f in frames_to_check:
                    if f and hasattr(f, 'drawing') and f.drawing:
                        if any((s.select for s in f.drawing.strokes)):
                            name = layer.name
                            infix = ''
                            for sep in [' ', '.', '_']:
                                if name.count(sep) >= 2:
                                    parts = name.split(sep)
                                    infix = parts[1]
                                    break
                            if infix:
                                detected_infixes.add(infix)
                                break
        if not detected_infixes:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        for layer in gp_data.layers:
            for frame in layer.frames:
                if hasattr(frame, 'drawing') and frame.drawing:
                    for stroke in frame.drawing.strokes:
                        stroke.select = False
        for layer in gp_data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                if any((inf in layer.name for inf in detected_infixes)):
                    if use_multiframe:
                        target_frames = [f for f in layer.frames if hasattr(f, 'drawing') and f.drawing]
                    else:
                        active_frame = None
                        for frame in layer.frames:
                            if frame.frame_number <= current_frame_num:
                                if active_frame is None or frame.frame_number > active_frame.frame_number:
                                    active_frame = frame
                        target_frames = [active_frame] if active_frame else []
                    for frame in target_frames:
                        if frame and hasattr(frame, 'drawing') and frame.drawing:
                            for stroke in frame.drawing.strokes:
                                stroke.select = True
        current_mode = context.object.mode
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode=current_mode)
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
        infix_list_str = ', '.join((f"'{i}'" for i in detected_infixes))
        _sssuite_report(self, {'INFO'}, f'Selected infix: {infix_list_str}')
        return {'FINISHED'}
last_weight_paint_exit = 0.0

@persistent
def unlock_gp_on_mode_change(*args):
    """Restore temporary GP weight-paint locks after mode changes.

    Blender 5.1 handlers may pass either (scene) or (scene, depsgraph).  Accept
    *args so handler dispatch never raises during redraw/mode switching.
    """
    global last_weight_paint_exit
    try:
        scene = args[0] if args and hasattr(args[0], 'objects') else getattr(bpy.context, 'scene', None)
    except Exception:
        scene = None
    try:
        obj = getattr(bpy.context, 'active_object', None)
    except Exception:
        obj = None
    if scene is None:
        _sssuite_handler_remove('depsgraph_update_post', unlock_gp_on_mode_change)
        return
    try:
        in_weight_mode = bool(obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode == 'WEIGHT_GREASE_PENCIL'))
    except Exception:
        in_weight_mode = False
    if in_weight_mode:
        return
    last_weight_paint_exit = time.time()
    try:
        for o in tuple(getattr(scene, 'objects', ()) or ()):
            try:
                if o.get('_was_locked_by_gp'):
                    o.hide_select = False
                    del o['_was_locked_by_gp']
            except Exception:
                pass
    except Exception:
        pass
    try:
        if obj and obj.type in {'GPENCIL', 'GREASEPENCIL'}:
            auto_lock_active = getattr(obj.data, 'use_autolock_layers', False)
            if not auto_lock_active:
                for layer in getattr(obj.data, 'layers', ()) or ():
                    try:
                        layer.lock = False
                    except Exception:
                        pass
            for slot in getattr(obj, 'material_slots', ()) or ():
                try:
                    if slot.material and hasattr(slot.material, 'grease_pencil'):
                        slot.material.grease_pencil.lock = False
                except Exception:
                    pass
    except Exception:
        pass
    _sssuite_handler_remove('depsgraph_update_post', unlock_gp_on_mode_change)

def _weight_cleanup_handlers_enabled() -> bool:
    try:
        from .. import always_on
        return bool(always_on.is_feature_enabled('gp_select_weight_cleanup_handlers', default=True))
    except Exception:
        return True

def remove_weight_cleanup_handlers() -> None:
    _sssuite_handler_remove('depsgraph_update_post', unlock_gp_on_mode_change)
    _sssuite_handler_remove('undo_post', undo_handler)
    _sssuite_handler_remove('redo_post', undo_handler)

def add_weight_cleanup_handlers() -> None:
    if not _weight_cleanup_handlers_enabled():
        remove_weight_cleanup_handlers()
        return
    _sssuite_handler_append_once('depsgraph_update_post', unlock_gp_on_mode_change)
    _sssuite_handler_append_once('undo_post', undo_handler)
    _sssuite_handler_append_once('redo_post', undo_handler)

@persistent
def undo_handler(*args):
    """Safety: Re-registers the cleanup handler after Undo/Redo"""
    if not _weight_cleanup_handlers_enabled():
        remove_weight_cleanup_handlers()
        return
    if not _sssuite_handler_contains('depsgraph_update_post', unlock_gp_on_mode_change):
        _sssuite_handler_append_once('depsgraph_update_post', unlock_gp_on_mode_change)

class GP_OT_setup_weight_paint(bpy.types.Operator):
    """Locks Layers and Materials of the Selected strokes, Selects the Armature, makes other objects unselectable, and enters Weight Paint mode ( Toggleable. unlocks when switching modes. Respects the Multiframe setting, and Auto lock )"""
    bl_idname = 'gpencil.setup_weight_paint'
    bl_label = 'Weight Selected'
    bl_description = 'Function: Locks Layers and Materials of the Selected strokes, Selects the Armature, makes other objects unselectable, and enters Weight Paint mode ( Toggleable. unlocks when switching modes. Respects the Multiframe setting, and Auto lock ). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'WEIGHT_GREASE_PENCIL', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        global last_weight_paint_exit
        obj = context.active_object
        scene = context.scene
        if obj.mode == 'WEIGHT_GREASE_PENCIL':
            bpy.ops.object.mode_set(mode='EDIT')
            return {'FINISHED'}
        if time.time() - last_weight_paint_exit < 0.3:
            return {'CANCELLED'}
        armature = obj.parent if obj.parent and obj.parent.type == 'ARMATURE' else None
        if not armature:
            armature = next((m.object for m in obj.modifiers if m.type == 'ARMATURE' and m.object), None)
        is_parented = bool(armature and obj.parent == armature)
        gp_data = obj.data
        current_f = scene.frame_current
        sel_mats, sel_layers = (set(), set())
        active_layer = None
        active_material = 0
        use_multiframe = context.scene.tool_settings.use_grease_pencil_multi_frame_editing
        for layer in gp_data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not parent_hidden):
                frames_to_check = layer.frames if use_multiframe else [next((f for f in reversed(layer.frames) if f.frame_number <= current_f), None)]
                for frame in frames_to_check:
                    if frame and frame.drawing:
                        for s in frame.drawing.strokes:
                            if s.select:
                                sel_mats.add(s.material_index)
                                sel_layers.add(layer)
                                active_layer = layer
                                active_material = s.material_index
        if not sel_layers:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        for o in scene.objects:
            if o != obj and o != armature:
                if not o.hide_select:
                    o.hide_select = True
                    o['_was_locked_by_gp'] = True
        if obj and obj.type in {'GPENCIL', 'GREASEPENCIL'}:
            for layer in obj.data.layers:
                layer.lock = False
            for slot in obj.material_slots:
                if slot.material and hasattr(slot.material, 'grease_pencil'):
                    slot.material.grease_pencil.lock = False
        gp_data.layers.active = active_layer
        obj.active_material_index = active_material
        auto_lock_active = getattr(context.scene.tool_settings.gpencil_paint, 'use_autolock_layers', False)
        if not auto_lock_active:
            for layer in gp_data.layers:
                layer.lock = layer not in sel_layers
        for i, slot in enumerate(obj.material_slots):
            if slot.material and hasattr(slot.material, 'grease_pencil'):
                slot.material.grease_pencil.lock = i not in sel_mats
        lock_modes = context.scene.tool_settings.lock_object_mode
        if armature:
            if not (not lock_modes and (not is_parented)):
                armature.select_set(True)
        bpy.ops.object.mode_set(mode='WEIGHT_GREASE_PENCIL')
        add_weight_cleanup_handlers()
        return {'FINISHED'}

class GP_OT_duplicate_hide_selected(bpy.types.Operator):
    """Duplicate layers of selected strokes and hide the originals"""
    bl_idname = 'gpencil.duplicate_hide_selected'
    bl_label = 'Duplicate & Hide Original'
    bl_description = 'Function: Duplicate layers of selected strokes and hide the originals. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        gp_data = obj.data
        layers_to_process = []
        for layer in gp_data.layers:
            is_parent_hidden = False
            p_group = layer.parent_group
            while p_group:
                if p_group.hide:
                    is_parent_hidden = True
                    break
                p_group = p_group.parent_group
            if not layer.hide and (not layer.lock) and (not is_parent_hidden):
                cf = layer.current_frame()
                if cf and cf.drawing and any((s.select for s in cf.drawing.strokes)):
                    layers_to_process.append(layer.name)
        if not layers_to_process:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        for name in layers_to_process:
            gp_data.layers.active = gp_data.layers[name]
            bpy.ops.grease_pencil.layer_duplicate()
            gp_data.layers[name].hide = True
        for layer in obj.data.layers:
            for frame in layer.frames:
                if frame.drawing:
                    for stroke in frame.drawing.strokes:
                        stroke.select = False
        _sssuite_report(self, {'INFO'}, f'Duplicated {len(layers_to_process)} layers')
        return {'FINISHED'}

class GP_OT_rename_layer_to_vgroup(bpy.types.Operator):
    """Rename stroke's layer based off the selected vertex group (Use inside WP mode For Assign Weight by Name)"""
    bl_idname = 'gpencil.rename_layer_to_vgroup'
    bl_label = 'Sync Layer Name'
    bl_description = "Function: Rename stroke's layer based off the selected vertex group (Use inside WP mode For Assign Weight by Name). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'WEIGHT_GREASE_PENCIL'

    def invoke(self, context, event):
        obj = context.active_object
        self.target_name = obj.vertex_groups.active.name if obj and obj.vertex_groups.active else None
        if not self.target_name:
            _sssuite_report(self, {'WARNING'}, 'No active Vertex Group found')
            return {'CANCELLED'}
        self.selected_layers = []
        for layer in obj.data.layers:
            if not layer.hide and (not layer.lock):
                found = False
                cf = layer.current_frame()
                if cf and cf.drawing and any((s.select for s in cf.drawing.strokes)):
                    found = True
                else:
                    for frame in layer.frames:
                        if frame.drawing and any((s.select for s in frame.drawing.strokes)):
                            found = True
                            break
                if found:
                    self.selected_layers.append(layer)
        if len(self.selected_layers) > 1:
            _sssuite_report(self, {'WARNING'}, 'Only Works on Single layers')
            return {'CANCELLED'}
        if not self.selected_layers:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        return _safe_invoke_props_dialog(self, context)

    def draw(self, context):
        layout = self.layout
        layer = self.selected_layers[0]
        layout.label(text=_i18n_text(f'Current Name: {layer.name}', f'現在の名前: {layer.name}'))
        layout.label(text=_i18n_text(f'New Name: {self.target_name}', f'新しい名前: {self.target_name}'))
        layout.separator()
        layout.label(text=_i18n_text('Proceed?'))

    def execute(self, context):
        self.selected_layers[0].name = self.target_name
        return {'FINISHED'}

class GP_OT_layers_to_vgroups(bpy.types.Operator):
    """Assign weight to selected stroke Layers from Vertex Groups of the same name (For Premade rigs with already set names. Or use Sync layer names in WP mode)"""
    bl_idname = 'gpencil.layers_to_vgroups'
    bl_label = 'Assign Weight by Name'
    bl_description = 'Function: Assign weight to selected stroke Layers from Vertex Groups of the same name (For Premade rigs with already set names. Or use Sync layer names in WP mode). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'WEIGHT_GREASE_PENCIL', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        if not obj.vertex_groups:
            _sssuite_report(self, {'WARNING'}, 'No V-Groups Found')
            return {'CANCELLED'}
        handler_active = False
        if 'unlock_gp_on_mode_change' in globals():
            if _sssuite_handler_remove('depsgraph_update_post', unlock_gp_on_mode_change):
                handler_active = True
        gp_data = obj.data
        layer_locks = {l.name: l.lock for l in gp_data.layers}
        mat_locks = {}
        for slot in obj.material_slots:
            if slot.material and hasattr(slot.material, 'grease_pencil'):
                mat_locks[slot.material.name] = slot.material.grease_pencil.lock
        original_mode = obj.mode
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        count = 0
        for layer in gp_data.layers:
            vgroup_name = layer.name
            if vgroup_name not in obj.vertex_groups:
                continue
            for frame in layer.frames:
                drawing = frame.drawing
                if not drawing:
                    continue
                point_indices = []
                current_offset = 0
                for stroke in drawing.strokes:
                    num_points = len(stroke.points)
                    if stroke.select:
                        point_indices.extend(range(current_offset, current_offset + num_points))
                    current_offset += num_points
                if point_indices:
                    drawing.vertex_group_assign(vgroup_name, point_indices, 1.0)
                    count += len(point_indices)
        if obj.mode != original_mode:
            bpy.ops.object.mode_set(mode=original_mode)
        for l in gp_data.layers:
            if l.name in layer_locks:
                l.lock = layer_locks[l.name]
        for slot in obj.material_slots:
            if slot.material and slot.material.name in mat_locks:
                slot.material.grease_pencil.lock = mat_locks[slot.material.name]
        if handler_active and _weight_cleanup_handlers_enabled():
            _sssuite_handler_append_once('depsgraph_update_post', unlock_gp_on_mode_change)
        if count > 0:
            _sssuite_report(self, {'INFO'}, 'Weight Assigned')
            return {'FINISHED'}
        else:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}

class GP_OT_vgroups_to_layers(bpy.types.Operator):
    """Create Layers from Vertex Group names ( For premade rigs, Then you can draw on the layers that have the correct names)"""
    bl_idname = 'gpencil.vgroups_to_layers'
    bl_label = 'Make layers From Groups'
    bl_description = 'Function: Create Layers from Vertex Group names ( For premade rigs, Then you can draw on the layers that have the correct names). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GPENCIL', 'SCULPT_GREASE_PENCIL'})

    def invoke(self, context, event):
        return _safe_invoke_confirm(self, context, event, message='Make V-Group Layers?')

    def execute(self, context):
        obj = context.active_object
        # モードを変える前に確かめる。後で確かめると、取り消しても OBJECT モードのまま残る。
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            _sssuite_report(self, {'ERROR'}, 'Select A Grease Pencil Object.')
            return {'CANCELLED'}
        original_mode = obj.mode
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        gp_data = obj.data
        for vg in obj.vertex_groups:
            if vg.name not in gp_data.layers:
                new_layer = gp_data.layers.new(name=vg.name)
                gp_data.layers.active = new_layer
                bpy.ops.grease_pencil.insert_blank_frame(all_layers=False)
        if obj.mode != original_mode:
            bpy.ops.object.mode_set(mode=original_mode)
        return {'FINISHED'}

class GP_OT_switch_to_layer(bpy.types.Operator):
    """Switch to the selected stroke's layer (Hotkey This, and Lasso for best results) """
    bl_idname = 'gpencil.switch_to_layer'
    bl_label = 'Switch to Layer'
    bl_description = "Function: Switch to the selected stroke's layer (Hotkey This, and Lasso for best results). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        data = obj.data
        target_layer = None
        for layer in data.layers:
            parent_hidden = False
            if layer.parent_group and layer.parent_group.hide:
                parent_hidden = True
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                cf = layer.current_frame()
                if cf and cf.drawing and any((s.select for s in cf.drawing.strokes)):
                    target_layer = layer
                    break
        if target_layer:
            data.layers.active = target_layer
            return {'FINISHED'}
        _sssuite_report(self, {'INFO'}, 'No selected strokes found')
        return {'CANCELLED'}

class Gp_OT_move_Above(bpy.types.Operator):
    """Move the selected stroke's layers Above the active layer"""
    bl_idname = 'gpencil.move_above'
    bl_label = 'Move Selected Above'
    bl_description = "Function: Move the selected stroke's layers Above the active layer. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        gp_data = obj.data
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        active_layer = gp_data.layers.active
        if active_layer and active_layer.parent_group and active_layer.parent_group.hide:
            _sssuite_report(self, {'WARNING'}, "Active layer's group is hidden")
            return {'CANCELLED'}
        active_group = gp_data.layer_groups.active if hasattr(gp_data, 'layer_groups') else None
        target_group = active_layer.parent_group if active_layer else active_group
        layers_to_move = [l for l in gp_data.layers if l != active_layer and (not l.hide) and (not l.lock) and (not l.parent_group or not l.parent_group.hide) and (f := l.current_frame()) and f.drawing and any((s.select for s in f.drawing.strokes))]
        if not layers_to_move:
            return {'FINISHED'}
        for layer in layers_to_move:
            gp_data.layers.move_to_layer_group(layer, target_group)
            for _ in range(250):
                current_list = list(gp_data.layers)
                curr_idx = current_list.index(layer)
                if active_layer:
                    active_idx = current_list.index(active_layer)
                    target_idx = active_idx + 1 if curr_idx < active_idx else active_idx + 1
                else:
                    target_idx = len(current_list) - 1
                target_idx = min(len(gp_data.layers) - 1, target_idx)
                if curr_idx == target_idx:
                    break
                old_idx = curr_idx
                move_type = 'UP' if curr_idx < target_idx else 'DOWN'
                gp_data.layers.move(layer, type=move_type)
                if list(gp_data.layers).index(layer) == old_idx:
                    gp_data.layers.move(layer, type=move_type)
                    if list(gp_data.layers).index(layer) == old_idx:
                        break
        return {'FINISHED'}

class GP_OT_move_Bellow(bpy.types.Operator):
    """Move the selected stroke's layers Bellow the active layer"""
    bl_idname = 'gpencil.move_below'
    bl_label = 'Move Selected Below'
    bl_description = "Function: Move the selected stroke's layers Bellow the active layer. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        gp_data = obj.data
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        active_layer = gp_data.layers.active
        if active_layer and active_layer.parent_group and active_layer.parent_group.hide:
            _sssuite_report(self, {'WARNING'}, "Active layer's group is hidden")
            return {'CANCELLED'}
        active_group = gp_data.layer_groups.active if hasattr(gp_data, 'layer_groups') else None
        target_group = active_layer.parent_group if active_layer else active_group
        layers_to_move = [l for l in gp_data.layers if l != active_layer and (not l.hide) and (not l.lock) and (not l.parent_group or not l.parent_group.hide) and (f := l.current_frame()) and f.drawing and any((s.select for s in f.drawing.strokes))]
        if not layers_to_move:
            return {'FINISHED'}
        for layer in reversed(layers_to_move):
            gp_data.layers.move_to_layer_group(layer, target_group)
            for _ in range(250):
                current_list = list(gp_data.layers)
                curr_idx = current_list.index(layer)
                if active_layer:
                    active_idx = current_list.index(active_layer)
                    target_idx = active_idx if curr_idx > active_idx else active_idx - 1
                else:
                    target_idx = 0
                target_idx = max(0, target_idx)
                if curr_idx == target_idx:
                    break
                old_idx = curr_idx
                move_type = 'UP' if curr_idx < target_idx else 'DOWN'
                gp_data.layers.move(layer, type=move_type)
                if list(gp_data.layers).index(layer) == old_idx:
                    gp_data.layers.move(layer, type=move_type)
                    if list(gp_data.layers).index(layer) == old_idx:
                        break
        return {'FINISHED'}

def get_target_info(gp_data, active_group):
    """Finds the target layer and the group's visual posision."""
    target_layer = None
    for layer in gp_data.layers:
        if not hasattr(layer, 'current_frame'):
            continue
        if layer == active_group or (hasattr(layer, 'parent_group') and layer.parent_group == active_group):
            continue
        cf = layer.current_frame()
        if cf and cf.drawing and any((s.select for s in cf.drawing.strokes)):
            target_layer = layer
            break
    if not target_layer:
        return (None, None, None)
    all_items = list(gp_data.layers)
    try:
        t_idx = all_items.index(target_layer)
        g_indices = [i for i, item in enumerate(all_items) if item == active_group or (hasattr(item, 'parent_group') and item.parent_group == active_group)]
        if not g_indices:
            return (t_idx, None, None)
        return (t_idx, min(g_indices), max(g_indices))
    except ValueError:
        return (None, None, None)

class Gp_OT_move_Group_Above(bpy.types.Operator):
    """Move the active Group above the selected stroke layer"""
    bl_idname = 'gpencil.move_group_above'
    bl_label = 'Move Group Above Selection'
    bl_description = 'Function: Move the active Group above the selected stroke layer. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        gp_data = context.active_object.data
        active_group = gp_data.layer_groups.active
        if not active_group:
            _sssuite_report(self, {'INFO'}, 'No Active Group Found')
            return {'CANCELLED'}
        target_layer = None
        for layer in gp_data.layers:
            if not hasattr(layer, 'current_frame'):
                continue
            if layer == active_group or (hasattr(layer, 'parent_group') and layer.parent_group == active_group):
                continue
            cf = layer.current_frame()
            if cf and cf.drawing and any((s.select for s in cf.drawing.strokes)):
                target_layer = layer
                break
        if not target_layer:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        if active_group.parent_group != target_layer.parent_group:
            gp_data.layer_groups.move_to_layer_group(active_group, target_layer.parent_group)
        for _ in range(250):
            t_idx, g_min, g_max = get_target_info(gp_data, active_group)
            if t_idx is None or g_min is None:
                break
            if g_min == t_idx + 1:
                break
            old_min = g_min
            move_type = 'UP' if g_min < t_idx + 1 else 'DOWN'
            gp_data.layer_groups.move(active_group, type=move_type)
            _, new_min, _ = get_target_info(gp_data, active_group)
            if new_min == old_min:
                gp_data.layer_groups.move(active_group, type=move_type)
                _, final_min, _ = get_target_info(gp_data, active_group)
                if final_min == old_min:
                    break
        return {'FINISHED'}

class Gp_OT_move_Group_Below(bpy.types.Operator):
    """Move the active Group Bellow the selected stroke layer"""
    bl_idname = 'gpencil.move_group_below'
    bl_label = 'Move Group Below Selection'
    bl_description = 'Function: Move the active Group Bellow the selected stroke layer. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        gp_data = context.active_object.data
        active_group = gp_data.layer_groups.active
        if not active_group:
            _sssuite_report(self, {'INFO'}, 'No Active Group Found')
            return {'CANCELLED'}
        target_layer = None
        for layer in gp_data.layers:
            if not hasattr(layer, 'current_frame'):
                continue
            if layer == active_group or (hasattr(layer, 'parent_group') and layer.parent_group == active_group):
                continue
            cf = layer.current_frame()
            if cf and cf.drawing and any((s.select for s in cf.drawing.strokes)):
                target_layer = layer
                break
        if not target_layer:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        if active_group.parent_group != target_layer.parent_group:
            gp_data.layer_groups.move_to_layer_group(active_group, target_layer.parent_group)
        for _ in range(250):
            t_idx, g_min, g_max = get_target_info(gp_data, active_group)
            if t_idx is None or g_max is None:
                break
            if g_max == t_idx - 1:
                break
            old_max = g_max
            move_type = 'DOWN' if g_max > t_idx - 1 else 'UP'
            gp_data.layer_groups.move(active_group, type=move_type)
            _, _, new_max = get_target_info(gp_data, active_group)
            if new_max == old_max:
                gp_data.layer_groups.move(active_group, type=move_type)
                _, _, final_max = get_target_info(gp_data, active_group)
                if final_max == old_max:
                    break
        return {'FINISHED'}

class GP_OT_move_layer_top(bpy.types.Operator):
    """Move layers of the selected strokes to the top"""
    bl_idname = 'gpencil.move_layer_top'
    bl_label = 'Move Layers to Top'
    bl_description = 'Function: Move layers of the selected strokes to the top. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        layers_to_move = []
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frame = layer.current_frame()
                if frame and frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    layers_to_move.append(layer)
        if not layers_to_move:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        for layer in layers_to_move:
            obj.data.layers.move_top(layer)
            _sssuite_report(self, {'INFO'}, 'Layer sent to Top.')
        return {'FINISHED'}

class GP_OT_move_layer_bottom(bpy.types.Operator):
    """Move layers of the selected strokes to the bottom"""
    bl_idname = 'gpencil.move_layer_bottom'
    bl_label = 'Move Layers to Bottom'
    bl_description = 'Function: Move layers of the selected strokes to the bottom. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        layers_to_move = []
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frame = layer.current_frame()
                if frame and frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    layers_to_move.append(layer)
        if not layers_to_move:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        for layer in reversed(layers_to_move):
            obj.data.layers.move_bottom(layer)
            _sssuite_report(self, {'INFO'}, 'Layer sent to Bottom.')
        return {'FINISHED'}

class GP_OT_hide_selected_layers(bpy.types.Operator):
    """Hide layer of the selected strokes"""
    bl_idname = 'gpencil.hide_selected_layers'
    bl_label = 'Hide Selected Layers'
    bl_description = 'Function: Hide layer of the selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        valid_found = False
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frame = layer.current_frame()
                if frame and frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    valid_found = True
                    break
            if valid_found:
                break
        if not valid_found:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        layers_to_hide = set()
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                for frame in layer.frames:
                    if frame.drawing and any((s.select for s in frame.drawing.strokes)):
                        layers_to_hide.add(layer)
                        break
        if not layers_to_hide:
            return {'CANCELLED'}
        for layer in obj.data.layers:
            for frame in layer.frames:
                if frame.drawing:
                    for stroke in frame.drawing.strokes:
                        stroke.select = False
        for layer in layers_to_hide:
            layer.hide = True
        return {'FINISHED'}

class GP_OT_lock_unselected_materials(bpy.types.Operator):
    """Lock materials of unselected stroke's (Toggleable)"""
    bl_idname = 'gpencil.lock_unselected_materials'
    bl_label = 'Isolate Selected'
    bl_description = "Function: Lock materials of unselected stroke's (Toggleable). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        is_any_locked = any((slot.material.grease_pencil.lock for slot in obj.material_slots if slot.material and hasattr(slot.material, 'grease_pencil')))
        if is_any_locked:
            for slot in obj.material_slots:
                if slot.material and hasattr(slot.material, 'grease_pencil'):
                    slot.material.grease_pencil.lock = False
            return {'FINISHED'}
        sel_mats = set()
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not parent_hidden):
                f = layer.current_frame()
                if f and f.drawing:
                    for s in f.drawing.strokes:
                        if s.select:
                            sel_mats.add(s.material_index)
        if sel_mats:
            for i, slot in enumerate(obj.material_slots):
                if slot.material and hasattr(slot.material, 'grease_pencil'):
                    slot.material.grease_pencil.lock = i not in sel_mats
            return {'FINISHED'}
        return {'CANCELLED'}

class GP_OT_delete_selected_layers(bpy.types.Operator):
    """Delete layers of the selected strokes"""
    bl_idname = 'gpencil.delete_selected_layers'
    bl_label = 'Delete Layers?'
    bl_description = 'Function: Delete layers of the selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def invoke(self, context, event):
        obj = context.active_object
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        valid_found = False
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                cf = layer.current_frame()
                if cf and cf.drawing and any((s.select for s in cf.drawing.strokes)):
                    valid_found = True
                    break
            if valid_found:
                break
        if not valid_found:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        return _safe_invoke_props_dialog(self, context)

    def execute(self, context):
        obj = context.active_object
        layers_to_delete = []
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                cf = layer.current_frame()
                if cf and cf.drawing and any((s.select for s in cf.drawing.strokes)):
                    layers_to_delete.append(layer)
        if layers_to_delete:
            for layer in layers_to_delete:
                obj.data.layers.remove(layer)
            _sssuite_report(self, {'INFO'}, f'Deleted {len(layers_to_delete)} layers')
            return {'FINISHED'}
        _sssuite_report(self, {'INFO'}, 'No selected strokes found')
        return {'CANCELLED'}

class GP_OT_clear_stroke_weights(bpy.types.Operator):
    """Clear all vertex weight from the selected strokes"""
    bl_idname = 'gpencil.clear_stroke_weights'
    bl_label = 'Clear Selected Stroke Weights'
    bl_description = 'Function: Clear all vertex weight from the selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'WEIGHT_GREASE_PENCIL', 'SCULPT_GREASE_PENCIL'})

    def invoke(self, context, event):
        return _safe_invoke_confirm(self, context, event)

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        obj.select_set(True)
        context.view_layer.objects.active = obj
        gp_data = obj.data
        found_selected = False
        original_mode = obj.mode
        try:
            for layer in gp_data.layers:
                parent_hidden = False
                p_grp = layer.parent_group
                while p_grp:
                    if p_grp.hide:
                        parent_hidden = True
                        break
                    p_grp = p_grp.parent_group
                if layer.hide or layer.lock or parent_hidden:
                    continue
                for frame in layer.frames:
                    if frame.drawing:
                        for stroke in frame.drawing.strokes:
                            if stroke.select:
                                found_selected = True
                                bpy.ops.object.vertex_group_remove_from(use_all_groups=True, use_all_verts=False)
                                break
        except RuntimeError as e:
            _sssuite_report(self, {'WARNING'}, 'Not in Gp Edit mode')
            return {'CANCELLED'}
        if not found_selected:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        _sssuite_report(self, {'INFO'}, 'Cleared weights from selected strokes')
        return {'FINISHED'}

class GP_OT_dim_selected_layers(bpy.types.Operator):
    """Set opacity for all layers Of the selected strokes"""
    bl_idname = 'gpencil.dim_selected_layers'
    bl_label = 'Apply Opacity'
    bl_description = 'Function: Set opacity for all layers Of the selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        valid_found = False
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frame = layer.current_frame()
                if frame and frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    valid_found = True
                    break
            if valid_found:
                break
        if not valid_found:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        props = context.scene.gp_renamer_props
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        layers_to_change = set()
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                for frame in layer.frames:
                    if frame.drawing and any((s.select for s in frame.drawing.strokes)):
                        layers_to_change.add(layer)
                        break
        if layers_to_change:
            for layer in layers_to_change:
                layer.opacity = props.target_opacity
            return {'FINISHED'}
        _sssuite_report(self, {'INFO'}, 'No selected strokes found')
        return {'CANCELLED'}

class GP_OT_reset_layer_opacity(bpy.types.Operator):
    """Reset all layers to 100% opacity"""
    bl_idname = 'gpencil.reset_layer_opacity'
    bl_label = 'Restore All Opacity'
    bl_description = 'Function: Reset all layers to 100% opacity. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                layer.opacity = 1.0
        return {'FINISHED'}

class GP_OT_mask_to_active(bpy.types.Operator):
    """Mask selected strokes layers to the active layer """
    bl_idname = 'gpencil.mask_to_active'
    bl_label = 'Mask to Active'
    bl_description = 'Function: Mask selected strokes layers to the active layer. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        gp_data = obj.data
        target_mask_layer = gp_data.layers.active
        if not target_mask_layer:
            return {'CANCELLED'}
        target_parent_hidden = target_mask_layer.parent_group.hide if target_mask_layer.parent_group else False
        if target_parent_hidden or target_mask_layer.hide:
            _sssuite_report(self, {'WARNING'}, 'layer is hidden, cannot apply mask')
            return {'CANCELLED'}
        layers_to_modify = []
        for layer in gp_data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frame = layer.current_frame()
                if frame and frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    if layer != target_mask_layer:
                        if layer.mask_layers.find(target_mask_layer.name) == -1:
                            layers_to_modify.append(layer)
        if not layers_to_modify:
            return {'FINISHED'}
        original_active = gp_data.layers.active
        for layer in layers_to_modify:
            gp_data.layers.active = layer
            layer.use_masks = True
            bpy.ops.grease_pencil.layer_mask_add(name=target_mask_layer.name)
        gp_data.layers.active = original_active
        _sssuite_report(self, {'INFO'}, f"Applied '{target_mask_layer.name}' as mask to {len(layers_to_modify)} layers")
        return {'FINISHED'}

class GP_OT_mask_active_to_selected(bpy.types.Operator):
    """Mask the active layer to the selected strokes layers"""
    bl_idname = 'gpencil.mask_active_to_selected'
    bl_label = 'Mask Active to Selected'
    bl_description = 'Function: Mask the active layer to the selected strokes layers. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        gp_data = obj.data
        active_layer = gp_data.layers.active
        if not active_layer:
            return {'CANCELLED'}
        active_parent_hidden = active_layer.parent_group.hide if active_layer.parent_group else False
        if active_parent_hidden or active_layer.hide:
            _sssuite_report(self, {'WARNING'}, 'layer is hidden, cannot apply mask')
            return {'CANCELLED'}
        mask_sources = []
        for layer in gp_data.layers:
            if layer == active_layer:
                continue
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frame = layer.current_frame()
                if frame and frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    if active_layer.mask_layers.find(layer.name) == -1:
                        mask_sources.append(layer)
        if not mask_sources:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'FINISHED'}
        active_layer.use_masks = True
        for source_layer in mask_sources:
            bpy.ops.grease_pencil.layer_mask_add(name=source_layer.name)
        _sssuite_report(self, {'INFO'}, f'Added {len(mask_sources)} new mask layers to {active_layer.name}')
        return {'FINISHED'}

class GP_OT_unmask_selected(bpy.types.Operator):
    """ Remove all masks from layers of the selected strokes """
    bl_idname = 'gpencil.unmask_selected'
    bl_label = 'Unmask Selected'
    bl_description = 'Function: Remove all masks from layers of the selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'WEIGHT_GREASE_PENCIL', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        gp_data = obj.data
        original_active = gp_data.layers.active
        if original_active:
            active_parent_hidden = original_active.parent_group.hide if original_active.parent_group else False
            if active_parent_hidden or original_active.hide:
                _sssuite_report(self, {'WARNING'}, 'Active layer is hidden')
                return {'CANCELLED'}
        layers_to_clear = []
        for layer in gp_data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frame = layer.current_frame()
                if frame and frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    layers_to_clear.append(layer)
        if not layers_to_clear:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'FINISHED'}
        for layer in layers_to_clear:
            gp_data.layers.active = layer
            while len(layer.mask_layers) > 0:
                bpy.ops.grease_pencil.layer_mask_remove()
            layer.use_masks = False
        if original_active:
            gp_data.layers.active = original_active
            while len(original_active.mask_layers) > 0:
                bpy.ops.grease_pencil.layer_mask_remove()
            original_active.use_masks = False
        gp_data.layers.active = original_active
        _sssuite_report(self, {'INFO'}, f'Unmasked {len(layers_to_clear)} layers')
        return {'FINISHED'}

class GP_OT_invert_masks_selected(bpy.types.Operator):
    """Invert masks on layers of the selected strokes"""
    bl_idname = 'gpencil.invert_masks_selected'
    bl_label = 'Invert Masks'
    bl_description = 'Function: Invert masks on layers of the selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'WEIGHT_GREASE_PENCIL', 'PAINT_GREASE_PENCIL', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL', 'ARMATURE'}:
            return {'CANCELLED'}
        gp_data = obj.data
        active_layer = gp_data.layers.active
        layers_with_selection = []
        selected_names = set()
        for layer in gp_data.layers:
            if not layer.hide and (not layer.lock):
                frame = layer.current_frame()
                if frame and frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    layers_with_selection.append(layer)
                    selected_names.add(layer.name)
        if not layers_with_selection:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'FINISHED'}
        for layer in layers_with_selection:
            if layer.use_masks:
                for mask_entry in layer.mask_layers:
                    mask_entry.invert = not mask_entry.invert
        # Selected layers were already inverted above, including the active one.
        if active_layer and active_layer.use_masks and active_layer.name not in selected_names:
            for mask_entry in active_layer.mask_layers:
                if mask_entry.name in selected_names:
                    mask_entry.invert = not mask_entry.invert
        _sssuite_report(self, {'INFO'}, 'Inverted masks')
        return {'FINISHED'}

class GP_OT_toggle_all_masks(bpy.types.Operator):
    """ Toggles mask visablity of all layers """
    bl_idname = 'gpencil.toggle_all_masks'
    bl_label = 'Toggle All Masks'
    bl_description = 'Function: Toggles mask visablity of all layers. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        layers = obj.data.layers
        first_masked_layer = next((l for l in layers if l.mask_layers), None)
        if not first_masked_layer:
            _sssuite_report(self, {'WARNING'}, 'No layers have masks')
            return {'CANCELLED'}
        new_state = not first_masked_layer.use_masks
        for layer in layers:
            if layer.mask_layers:
                layer.use_masks = new_state
        status = 'ON' if new_state else 'OFF'
        _sssuite_report(self, {'INFO'}, f'All masks turned {status}')
        return {'FINISHED'}

class GP_OT_group_selected_stroke_layers(bpy.types.Operator):
    """Adds all layers of the selected strokes to a new group"""
    bl_idname = 'gpencil.group_selected_stroke_layers'
    bl_label = 'Group Selected Stroke Layers'
    bl_description = 'Function: Adds all layers of the selected strokes to a new group. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})
    group_name: bpy.props.StringProperty(description='Function: stores the new Grease Pencil layer group name. How to use: enter a clear group name before grouping the selected stroke layers.', name='Group Name', default='Stroke Group', options={'SKIP_SAVE'})

    def invoke(self, context, event):
        obj = context.active_object
        if not obj or not obj.select_get() or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        valid_found = False
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frame = layer.current_frame()
                if frame and frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    valid_found = True
                    break
        if not valid_found:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        return _safe_invoke_props_dialog(self, context)

    def execute(self, context):
        obj = context.active_object
        gp_data = obj.data
        layers_to_move = []
        highest_target_idx = -1
        target_parent = None
        for i, layer in enumerate(gp_data.layers):
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frame = layer.current_frame()
                if frame and frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    layers_to_move.append(layer)
                    highest_target_idx = i
                    target_parent = layer.parent_group
        if not layers_to_move:
            return {'FINISHED'}
        new_group = gp_data.layer_groups.new(name=self.group_name)
        if target_parent:
            gp_data.layer_groups.move_to_layer_group(new_group, parent_group=target_parent)
        gp_data.layer_groups.move_top(new_group)
        current_pos = len(gp_data.layers) - 1
        while current_pos > highest_target_idx:
            gp_data.layer_groups.move(new_group, type='DOWN')
            current_pos -= 1
        for layer in layers_to_move:
            gp_data.layers.move_to_layer_group(layer, layer_group=new_group)
        gp_data.layer_groups.active = new_group
        return {'FINISHED'}

class GP_OT_Lock_selected_Layers(bpy.types.Operator):
    """Lock the layers of selected strokes (Toggleable)"""
    bl_idname = 'gpencil.lock_selected_layers'
    bl_label = 'Lock Selected layers'
    bl_description = 'Function: Lock the layers of selected strokes (Toggleable). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def execute(self, context):
        obj = context.active_object
        valid_found = False
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not parent_hidden):
                frame = layer.current_frame()
                if frame and frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    valid_found = True
                    break
            if valid_found:
                break
        if not valid_found:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        if not obj or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        data = obj.data
        layers_to_toggle = set()
        for layer in data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if layer.hide or parent_hidden:
                continue
            found_selection = False
            for frame in layer.frames:
                if frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    found_selection = True
                    break
            if found_selection:
                layers_to_toggle.add(layer)
        if not layers_to_toggle:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        should_lock = any((not l.lock for l in layers_to_toggle))
        for layer in layers_to_toggle:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not parent_hidden):
                layer.lock = should_lock
        return {'FINISHED'}

class GP_OT_duplicate_assign_material(bpy.types.Operator):
    """Duplicate Stroke's material and assign the new one(s) to the strokes."""
    bl_idname = 'gpencil.duplicate_assign_material'
    bl_label = 'Duplicate & Assign Material'
    bl_description = "Function: Duplicate Stroke's material and assign the new one(s) to the strokes.. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available."
    bl_options = {'UNDO'}
    use_single_material: bpy.props.BoolProperty(name='Use Single Material for All', description='Function: controls whether all selected strokes share one duplicated material during Duplicate & Assign Material. How to use: enable this in the operator dialog when every selected stroke should receive the same new material; disable it when each source material should be duplicated separately.', default=False)
    name_1: bpy.props.StringProperty(name='New Name', description='Function: stores candidate material name 1 for duplicate-and-assign workflows. How to use: set the material name when assigning copied stroke content to new materials.')
    name_2: bpy.props.StringProperty(name='New Name', description='Function: stores candidate material name 2 for duplicate-and-assign workflows. How to use: set the material name when assigning copied stroke content to new materials.')
    name_3: bpy.props.StringProperty(name='New Name', description='Function: stores candidate material name 3 for duplicate-and-assign workflows. How to use: set the material name when assigning copied stroke content to new materials.')
    name_4: bpy.props.StringProperty(name='New Name', description='Function: stores candidate material name 4 for duplicate-and-assign workflows. How to use: set the material name when assigning copied stroke content to new materials.')
    name_5: bpy.props.StringProperty(name='New Name', description='Function: stores candidate material name 5 for duplicate-and-assign workflows. How to use: set the material name when assigning copied stroke content to new materials.')
    found_stroke_count: bpy.props.IntProperty(default=0, description='Function: stores the Found Stroke Count value for this command. How to use: set the value from the operator dialog or N-panel before running the operation.')
    layer_names: bpy.props.CollectionProperty(type=bpy.types.PropertyGroup, description='Function: stores Layer Names runtime data used by this tool. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.')
    mat_names: bpy.props.CollectionProperty(type=bpy.types.PropertyGroup, description='Function: stores Mat Names runtime data used by this tool. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.')

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'}

    def draw(self, context):
        layout = self.layout
        if self.found_stroke_count > 1:
            _prop_with_icon(layout, self, 'use_single_material', toggle=True, icon='MATERIAL')
            layout.separator()
        names = ['name_1', 'name_2', 'name_3', 'name_4', 'name_5']
        if self.use_single_material and self.found_stroke_count > 1:
            box = layout.box()
            box.label(text=_i18n_text('Shared Material Name'), icon='GREASEPENCIL')
            box.prop(self, 'name_1')
        else:
            for i in range(min(self.found_stroke_count, 5)):
                layer_label = self.layer_names[i].name if i < len(self.layer_names) else 'Unknown Layer'
                orig_mat_name = self.mat_names[i].name if i < len(self.mat_names) else 'Unknown Material'
                box = layout.box()
                box.label(text=_i18n_text(f'Duplicating: {orig_mat_name} (Layer: {layer_label})', f'複製対象: {orig_mat_name}（レイヤー: {layer_label}）'), icon='GREASEPENCIL')
                box.prop(self, names[i])
            if self.found_stroke_count > 5:
                extra_count = self.found_stroke_count - 5
                layout.label(text=_i18n_text(f'...and {extra_count} more strokes', f'ほか {extra_count} 件のストローク'), icon='NONE')

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        data = obj.data
        names = [self.name_1, self.name_2, self.name_3, self.name_4, self.name_5]
        processed_count = 0
        shared_mat = None
        for layer in data.layers:
            if not layer.hide and (not layer.lock):
                cf = layer.current_frame()
                if cf and cf.drawing:
                    selected_strokes = [s for s in cf.drawing.strokes if s.select]
                    for stroke in selected_strokes:
                        orig_idx = stroke.material_index
                        if orig_idx < len(obj.material_slots) and obj.material_slots[orig_idx].material:
                            if self.use_single_material and self.found_stroke_count > 1:
                                if not shared_mat:
                                    shared_mat = obj.material_slots[orig_idx].material.copy()
                                    if self.name_1.strip():
                                        shared_mat.name = self.name_1
                                    data.materials.append(shared_mat)
                                stroke.material_index = len(data.materials) - 1
                            else:
                                orig_mat = obj.material_slots[orig_idx].material
                                new_mat = orig_mat.copy()
                                if processed_count < 5 and names[processed_count].strip():
                                    new_mat.name = names[processed_count]
                                data.materials.append(new_mat)
                                stroke.material_index = len(data.materials) - 1
                            processed_count += 1
        if processed_count == 0:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        return {'FINISHED'}

    def invoke(self, context, event):
        obj = context.active_object
        if not obj or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        self.use_single_material = False
        self.layer_names.clear()
        self.mat_names.clear()
        stroke_count = 0
        for layer in obj.data.layers:
            if not layer.hide and (not layer.lock):
                cf = layer.current_frame()
                if cf and cf.drawing:
                    for s in cf.drawing.strokes:
                        if s.select:
                            stroke_count += 1
                            if len(self.layer_names) < 5:
                                item = self.layer_names.add()
                                item.name = layer.name
                                m_item = self.mat_names.add()
                                m_idx = s.material_index
                                if m_idx < len(obj.material_slots) and obj.material_slots[m_idx].material:
                                    m_item.name = obj.material_slots[m_idx].material.name
                                else:
                                    m_item.name = 'None'
        self.found_stroke_count = stroke_count
        self.name_1 = self.name_2 = self.name_3 = self.name_4 = self.name_5 = ''
        return _safe_invoke_props_dialog(self, context)

class GP_OT_assign_weight_to_selected(bpy.types.Operator):
    """Assign weight to selected strokes using the selected bone/v-group. Works on Mutiple frames with Multiframe on ( Use with Weight selected )"""
    bl_idname = 'gpencil.assign_weight_to_selected'
    bl_label = 'Assign Weight To Selected'
    bl_description = 'Function: Assign weight to selected strokes using the selected bone/v-group. Works on Mutiple frames with Multiframe on ( Use with Weight selected ). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type in {'GPENCIL', 'GREASEPENCIL'} and (context.mode == 'WEIGHT_GREASE_PENCIL')

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        target_vgroup = obj.vertex_groups.active.name if obj.vertex_groups.active else None
        if not target_vgroup:
            _sssuite_report(self, {'WARNING'}, 'No active Vertex Group selected')
            return {'CANCELLED'}
        gp_data = obj.data
        handler_active = False
        if 'unlock_gp_on_mode_change' in globals():
            if _sssuite_handler_remove('depsgraph_update_post', unlock_gp_on_mode_change):
                handler_active = True
        layer_locks = {l.name: l.lock for l in gp_data.layers}
        mat_locks = {}
        for slot in obj.material_slots:
            if slot.material and hasattr(slot.material, 'grease_pencil'):
                mat_locks[slot.material.name] = slot.material.grease_pencil.lock
        original_mode = obj.mode
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        count = 0
        use_multiframe = context.scene.tool_settings.use_grease_pencil_multi_frame_editing
        for layer in gp_data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer_locks.get(layer.name, False) and (not layer.hide) and (not parent_hidden):
                frames_to_check = layer.frames if use_multiframe else [layer.current_frame()]
                for frame in frames_to_check:
                    if not frame:
                        continue
                    drawing = frame.drawing
                    if not drawing:
                        continue
                    point_indices = []
                    current_offset = 0
                    for stroke in drawing.strokes:
                        num_points = len(stroke.points)
                        if stroke.select:
                            point_indices.extend(range(current_offset, current_offset + num_points))
                        current_offset += num_points
                    if point_indices:
                        drawing.vertex_group_assign(target_vgroup, point_indices, 1.0)
                        count += len(point_indices)
        if obj.mode != original_mode:
            bpy.ops.object.mode_set(mode=original_mode)
        for l in gp_data.layers:
            if l.name in layer_locks:
                l.lock = layer_locks[l.name]
        for slot in obj.material_slots:
            if slot.material and slot.material.name in mat_locks:
                slot.material.grease_pencil.lock = mat_locks[slot.material.name]
        if handler_active and _weight_cleanup_handlers_enabled():
            _sssuite_handler_append_once('depsgraph_update_post', unlock_gp_on_mode_change)
        if count > 0:
            _sssuite_report(self, {'INFO'}, f'Assigned {count} points to {target_vgroup}')
            return {'FINISHED'}
        else:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}

class GP_OT_apply_pass_index(bpy.types.Operator):
    """Set -> Layer <- Pass Index For Multiple selected strokes"""
    bl_idname = 'gpencil.apply_pass_index'
    bl_label = 'Apply Layer Pass Index?'
    bl_description = 'Function: Set -> Layer <- Pass Index For Multiple selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def invoke(self, context, event):
        return _safe_invoke_confirm(self, context, event)

    def execute(self, context):
        obj = context.active_object
        valid_found = False
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frame = layer.current_frame()
                if frame and frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    valid_found = True
                    break
            if valid_found:
                break
        if not valid_found:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        props = context.scene.gp_renamer_props
        layers_to_update = set()
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if layer.hide or layer.lock or parent_hidden:
                continue
            for frame in layer.frames:
                drawing = frame.drawing
                if drawing and any((s.select for s in drawing.strokes)):
                    layers_to_update.add(layer)
                    break
        if not layers_to_update:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        for layer in layers_to_update:
            layer.pass_index = props.target_pass_index
        _sssuite_report(self, {'INFO'}, f'Set layers Pass Index to {props.target_pass_index} ')
        return {'FINISHED'}

class GP_OT_set_material_pass_index(bpy.types.Operator):
    """Set -> Material <- Pass Index For Multiple selected strokes"""
    bl_idname = 'gpencil.set_material_pass_index'
    bl_label = 'Set Material Pass Index?'
    bl_description = 'Function: Set -> Material <- Pass Index For Multiple selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def invoke(self, context, event):
        return _safe_invoke_confirm(self, context, event)

    def execute(self, context):
        obj = context.active_object
        valid_found = False
        for layer in obj.data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                frame = layer.current_frame()
                if frame and frame.drawing and any((s.select for s in frame.drawing.strokes)):
                    valid_found = True
                    break
            if valid_found:
                break
        if not valid_found:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        props = context.scene.gp_renamer_props
        data = obj.data
        materials_to_update = set()
        found_selection = False
        for layer in data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                cf = layer.current_frame()
                if cf and cf.drawing:
                    for stroke in cf.drawing.strokes:
                        if stroke.select:
                            found_selection = True
                            idx = stroke.material_index
                            if 0 <= idx < len(data.materials):
                                mat = data.materials[idx]
                                if mat and hasattr(mat, 'grease_pencil'):
                                    materials_to_update.add(mat)
        if not found_selection:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        for mat in materials_to_update:
            mat.grease_pencil.pass_index = props.target_pass_index
        _sssuite_report(self, {'INFO'}, f'Set Material Pass Index to {props.target_pass_index}')
        return {'FINISHED'}

class GP_OT_reset_all_pass_indexes(bpy.types.Operator):
    """Reset layers and materials Pass Index to 0 for the selected strokes"""
    bl_idname = 'gpencil.reset_all_pass_indexes'
    bl_label = 'Reset Indexes?'
    bl_description = 'Function: Reset layers and materials Pass Index to 0 for the selected strokes. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def invoke(self, context, event):
        return _safe_invoke_confirm(self, context, event)

    def execute(self, context):
        obj = context.active_object
        data = obj.data
        layers_updated = 0
        materials_updated = set()
        found_selection = False
        for layer in data.layers:
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                cf = layer.current_frame()
                if cf and cf.drawing:
                    layer_has_selection = False
                    for stroke in cf.drawing.strokes:
                        if stroke.select:
                            found_selection = True
                            layer_has_selection = True
                            idx = stroke.material_index
                            if 0 <= idx < len(data.materials):
                                mat = data.materials[idx]
                                if mat and hasattr(mat, 'grease_pencil'):
                                    materials_updated.add(mat)
                    if layer_has_selection:
                        layer.pass_index = 0
                        layers_updated += 1
        if not found_selection:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found')
            return {'CANCELLED'}
        for mat in materials_updated:
            mat.grease_pencil.pass_index = 0
        _sssuite_report(self, {'INFO'}, f'Reset Pass Indexes to 0 ')
        return {'FINISHED'}

class GP_OT_UnlockAll(bpy.types.Operator):
    """Unlocks all GP layers/materials and Makes all objects selectable"""
    bl_idname = 'gpencil.unlock_all'
    bl_label = 'Unlock All'
    bl_description = 'Function: Unlocks all GP layers/materials and Makes all objects selectable. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    def execute(self, context):
        for obj in context.scene.objects:
            if obj.hide_select:
                obj.hide_select = False
            if '_was_locked_by_gp' in obj:
                del obj['_was_locked_by_gp']
        active_obj = context.active_object
        if active_obj and active_obj.type in {'GPENCIL', 'GREASEPENCIL'}:
            if active_obj.data:
                for layer in active_obj.data.layers:
                    layer.lock = False
            for slot in active_obj.material_slots:
                if slot.material and hasattr(slot.material, 'grease_pencil'):
                    slot.material.grease_pencil.lock = False
        _sssuite_report(self, {'INFO'}, 'All objects made selectable')
        return {'FINISHED'}

class GP_OT_remove_empty_layers(bpy.types.Operator):
    """Delete empty Grease Pencil layers (Skips Hidden, Locked, or Hidden Groups)"""
    bl_idname = 'gpencil.remove_empty_layers'
    bl_label = 'Delete Empty Layers: Are you sure!?'
    bl_description = 'Function: Delete empty Grease Pencil layers (Skips Hidden, Locked, or Hidden Groups). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type in {'GPENCIL', 'GREASEPENCIL'} and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def invoke(self, context, event):
        return _safe_invoke_props_dialog(self, context, width=550)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        row = box.row()
        row.alert = False
        row.label(text=_i18n_text('ONLY FOR CLEAN UP. This deletes layers with nothing found on them.'), icon='ERROR')
        col = layout.column()
        col.label(text=_i18n_text('• Only layers that are NOT hidden or locked will be checked.'))
        col.label(text=_i18n_text('• This includes checking nested groups.'))
        col.separator()
        col.label(text=_i18n_text('Proceed with cleanup?'))

    def execute(self, context):
        obj = context.active_object
        gp_data = obj.data
        layers = gp_data.layers
        layers_to_remove = []
        for layer in layers:
            if layer.hide or layer.lock:
                continue
            parent_hidden = False
            p_grp = layer.parent_group
            while p_grp:
                if p_grp.hide:
                    parent_hidden = True
                    break
                p_grp = p_grp.parent_group
            if parent_hidden:
                continue
            has_strokes = False
            for frame in layer.frames:
                if hasattr(frame, 'drawing') and frame.drawing:
                    if len(frame.drawing.strokes) > 0:
                        has_strokes = True
                        break
            if not has_strokes:
                layers_to_remove.append(layer)
        count = len(layers_to_remove)
        for layer in layers_to_remove:
            layers.remove(layer)
        if count > 0:
            _sssuite_report(self, {'INFO'}, f'Removed {count} empty layer(s)')
        else:
            _sssuite_report(self, {'INFO'}, 'No empty layers found')
        return {'FINISHED'}

class GP_OT_apply_time_sensitivity(bpy.types.Operator):
    """Update Time Drivers based on Selected Strokes OR Selected Rig Bones"""
    bl_idname = 'gpencil.apply_time_sensitivity'
    bl_label = 'Apply Sensitivity'
    bl_description = 'Function: Update Time Drivers based on Selected Strokes OR Selected Rig Bones. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if not obj:
            return False
        if obj.type == 'ARMATURE' and context.active_pose_bone:
            bone_name = context.active_pose_bone.name
            for gp in [o for o in bpy.data.objects if o.type in {'GPENCIL', 'GREASEPENCIL'}]:
                anim_data = []
                if gp.animation_data:
                    anim_data.append(gp.animation_data)
                if gp.data and gp.data.animation_data:
                    anim_data.append(gp.data.animation_data)
                for anim in anim_data:
                    for drv in anim.drivers:
                        if 'modifier' in drv.data_path.lower():
                            for var in drv.driver.variables:
                                for target in var.targets:
                                    if target.id == obj and (bone_name == target.bone_target or f'["{bone_name}"]' in target.data_path):
                                        return True
            return False
        if obj.type in {'GPENCIL', 'GREASEPENCIL'}:
            for layer in obj.data.layers:
                cf = layer.current_frame()
                if cf and cf.drawing and any((s.select for s in cf.drawing.strokes)):
                    return True
        return False

    def execute(self, context):
        active_obj = context.active_object
        props = context.scene.gp_renamer_props
        updated_count = 0
        for obj in bpy.data.objects:
            if obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
                continue
            anim_sources = []
            if obj.animation_data:
                anim_sources.append(obj.animation_data)
            if obj.data and obj.data.animation_data:
                anim_sources.append(obj.data.animation_data)
            for anim in anim_sources:
                for drv in anim.drivers:
                    if 'modifiers' not in drv.data_path:
                        continue
                    is_target = False
                    if active_obj.type == 'ARMATURE' and context.selected_pose_bones:
                        for pbone in context.selected_pose_bones:
                            for var in drv.driver.variables:
                                for target in var.targets:
                                    if target.id == active_obj and (pbone.name == target.bone_target or f'["{pbone.name}"]' in target.data_path):
                                        is_target = True
                                        break
                    elif active_obj == obj:
                        for layer in obj.data.layers:
                            if layer.hide or layer.lock:
                                continue
                            cf = layer.current_frame()
                            if cf and cf.drawing and any((s.select for s in cf.drawing.strokes)):
                                if f'["Time_{layer.name}"]' in drv.data_path or f'["{layer.name}"]' in drv.data_path:
                                    is_target = True
                                    break
                    if is_target:
                        for m in drv.modifiers:
                            if m.type == 'GENERATOR':
                                m.coefficients[1] = props.target_sensitivity
                                updated_count += 1
                                break
        if updated_count > 0:
            _sssuite_report(self, {'INFO'}, f'Updated sensitivity for {updated_count} drivers.')
        else:
            _sssuite_report(self, {'WARNING'}, 'No connected Time Offset drivers found for selection.')
        return {'FINISHED'}

class GP_OT_toggle_time_visibility(bpy.types.Operator):
    """Toggle Viewport Visibility of Time Drivers for Selected Strokes or Bones"""
    bl_idname = 'gpencil.toggle_time_visibility'
    bl_label = 'Toggle Time Visibility'
    bl_description = 'Function: Toggle Viewport Visibility of Time Drivers for Selected Strokes or Bones. How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if not obj:
            return False
        if obj.type == 'ARMATURE' and context.active_pose_bone:
            bone_name = context.active_pose_bone.name
            for gp in [o for o in bpy.data.objects if o.type in {'GPENCIL', 'GREASEPENCIL'}]:
                anim_data = []
                if gp.animation_data:
                    anim_data.append(gp.animation_data)
                if gp.data and gp.data.animation_data:
                    anim_data.append(gp.data.animation_data)
                for anim in anim_data:
                    for drv in anim.drivers:
                        if 'modifier' in drv.data_path.lower():
                            for var in drv.driver.variables:
                                for target in var.targets:
                                    if target.id == obj and (bone_name == target.bone_target or f'["{bone_name}"]' in target.data_path):
                                        return True
            return False
        if obj.type in {'GPENCIL', 'GREASEPENCIL'}:
            for layer in obj.data.layers:
                cf = layer.current_frame()
                if cf and cf.drawing and any((s.select for s in cf.drawing.strokes)):
                    return True
        return False

    def execute(self, context):
        active_obj = context.active_object
        found_modifiers = []
        for obj in bpy.data.objects:
            if obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
                continue
            anim_sources = []
            if obj.animation_data:
                anim_sources.append(obj.animation_data)
            if obj.data and obj.data.animation_data:
                anim_sources.append(obj.data.animation_data)
            for anim in anim_sources:
                for drv in anim.drivers:
                    if 'modifiers' not in drv.data_path:
                        continue
                    is_linked = False
                    if active_obj.type == 'ARMATURE' and context.selected_pose_bones:
                        for pbone in context.selected_pose_bones:
                            for var in drv.driver.variables:
                                for target in var.targets:
                                    if target.id == active_obj and (pbone.name == target.bone_target or f'["{pbone.name}"]' in target.data_path):
                                        is_linked = True
                                        break
                    elif active_obj == obj:
                        for layer in obj.data.layers:
                            cf = layer.current_frame()
                            if cf and cf.drawing and any((s.select for s in cf.drawing.strokes)):
                                if f'["Time_{layer.name}"]' in drv.data_path or f'["{layer.name}"]' in drv.data_path:
                                    is_linked = True
                                    break
                    if is_linked:
                        parts = drv.data_path.split('"')
                        if len(parts) > 1:
                            mod_name = parts[1]
                            mod = obj.modifiers.get(mod_name)
                            if mod and mod not in found_modifiers:
                                mod.show_viewport = not mod.show_viewport
                                status = 'ON' if mod.show_viewport else 'OFF'
                                found_modifiers.append(mod)
                                _sssuite_report(self, {'INFO'}, f'Toggled {mod_name}: {status}')
        if not found_modifiers:
            _sssuite_report(self, {'WARNING'}, 'No connected Time Offset modifiers found.')
        return {'FINISHED'}

class GP_OT_create_time_offset_rig(bpy.types.Operator):
    """Create a Time Offset Controller for every selected stroke layer ( Will make a new armature if you don't have one parented )"""
    bl_idname = 'gpencil.create_time_offset_rig'
    bl_label = 'Create Time Offset Rig'
    bl_description = "Function: Create a Time Offset Controller for every selected stroke layer ( Will make a new armature if you don't have one parented ). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'GREASEPENCIL' and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def create_arrow_mesh(self, name='WGT_Arrow'):
        if name in bpy.data.objects:
            return bpy.data.objects[name]
        mesh = bpy.data.meshes.new(name)
        obj = bpy.data.objects.new(name, mesh)
        bpy.context.collection.objects.link(obj)
        bm = bmesh.new()
        verts = [(0, 0, 0), (0.3, -0.2, 0), (0.1, -0.2, 0), (0.1, -0.5, 0), (-0.1, -0.5, 0), (-0.1, -0.2, 0), (-0.3, -0.2, 0)]
        for v in verts:
            bm.verts.new(v)
        bm.verts.ensure_lookup_table()
        bm.faces.new(bm.verts)
        bm.to_mesh(mesh)
        bm.free()
        obj.hide_viewport = True
        return obj

    def create_dial_mesh(self, name='WGT_Dial'):
        if name in bpy.data.objects:
            return bpy.data.objects[name]
        mesh = bpy.data.meshes.new(name)
        obj = bpy.data.objects.new(name, mesh)
        bpy.context.collection.objects.link(obj)
        bm = bmesh.new()
        segments = 16
        inner_r = 0.2
        inner_verts = [bm.verts.new((inner_r * cos(2 * pi * i / segments), 0, inner_r * sin(2 * pi * i / segments))) for i in range(segments)]
        for i in range(segments):
            bm.edges.new((inner_verts[i], inner_verts[(i + 1) % segments]))
        arc_segments = 8
        outer_r = 0.8
        outer_verts = [bm.verts.new((outer_r * cos(pi / 2 * (i / arc_segments)), 0, outer_r * sin(pi / 2 * (i / arc_segments)))) for i in range(arc_segments + 1)]
        for i in range(arc_segments):
            bm.edges.new((outer_verts[i], outer_verts[i + 1]))
        bm.to_mesh(mesh)
        bm.free()
        obj.hide_viewport = True
        return obj

    def invoke(self, context, event):
        return _safe_invoke_confirm(self, context, event)

    def execute(self, context):
        gp_obj = context.active_object
        data = gp_obj.data
        arrow_shape = self.create_arrow_mesh()
        dial_shape = self.create_dial_mesh()
        target_layers = []
        for layer in data.layers:
            if not layer.hide and (not layer.lock):
                cf = layer.current_frame()
                if cf and cf.drawing and any((s.select for s in cf.drawing.strokes)):
                    target_layers.append(layer)
        if not target_layers:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found.')
            return {'CANCELLED'}
        cursor_loc = context.scene.cursor.location.copy()
        rig_obj = gp_obj.parent if gp_obj.parent and gp_obj.parent.type == 'ARMATURE' else None
        if not rig_obj:
            arm_data = bpy.data.armatures.new('TimeOffset_ArmData')
            rig_obj = bpy.data.objects.new('TimeOffset_Rig', arm_data)
            context.collection.objects.link(rig_obj)
            rig_obj.location = cursor_loc
        arm_data = rig_obj.data
        local_origin = rig_obj.matrix_world.inverted() @ cursor_loc
        for i, target_layer in enumerate(target_layers):
            layer_name = target_layer.name
            root_name, con_name = (f'{layer_name}_Root', f'{layer_name}_Con')
            bone_pos = local_origin + Vector((i * 1.0, 0, 0))
            context.view_layer.objects.active = rig_obj
            bpy.ops.object.mode_set(mode='EDIT')
            root = arm_data.edit_bones.new(root_name)
            root.head = bone_pos
            root.tail = bone_pos + Vector((0.5, 0, 0))
            con = arm_data.edit_bones.new(con_name)
            con.head = bone_pos
            con.tail = bone_pos + Vector((0, 0, 0.5))
            con.parent = root
            bpy.ops.object.mode_set(mode='POSE')
            proot = rig_obj.pose.bones[root_name]
            proot.custom_shape = dial_shape
            proot.bone.show_wire = True
            proot.color.palette = 'THEME06'
            proot.custom_shape_rotation_euler[1] = radians(270)
            proot.custom_shape_rotation_euler[2] = radians(90)
            pcon = rig_obj.pose.bones[con_name]
            pcon.rotation_mode = 'XYZ'
            pcon.custom_shape = arrow_shape
            pcon.bone.show_wire = True
            pcon.custom_shape_scale_xyz = (1.0, 2.0, 1.0)
            pcon.custom_shape_translation[1] = 0.5
            pcon.color.palette = 'THEME03'
            rot_con = pcon.constraints.new('LIMIT_ROTATION')
            rot_con.use_limit_z, rot_con.min_z, rot_con.max_z = (True, 0.0, radians(90))
            rot_con.owner_space, rot_con.use_transform_limit = ('LOCAL', True)
            dist_con = pcon.constraints.new('LIMIT_DISTANCE')
            dist_con.target, dist_con.subtarget = (rig_obj, root_name)
            dist_con.distance, dist_con.limit_mode = (0.0, 'LIMITDIST_INSIDE')
            mod = gp_obj.modifiers.new(name=f'Time_{layer_name}', type='GREASE_PENCIL_TIME')
            mod.mode, mod.tree_node_filter = ('FIX', layer_name)
            fcurve = mod.driver_add('offset')
            fcurve.driver.type = 'AVERAGE'
            var = fcurve.driver.variables.new()
            var.name, var.type = ('rotation_euler', 'SINGLE_PROP')
            var.targets[0].id = rig_obj
            var.targets[0].data_path = f'pose.bones["{con_name}"].rotation_euler[2]'
            fcurve.modifiers.new(type='GENERATOR').coefficients = (0.0, context.scene.gp_renamer_props.target_sensitivity)
            if not any((f.frame_number == 0 for f in target_layer.frames)):
                frame_1 = next((f for f in target_layer.frames if f.frame_number == 1), None)
                if frame_1:
                    f0 = target_layer.frames.new(0)
                    f0.drawing = frame_1.drawing
        bpy.ops.object.mode_set(mode='POSE')
        return {'FINISHED'}

class GP_OT_create_indexed_time_offset_rig(bpy.types.Operator):
    """Create a Time Offset rig/modifier to control multiple layers with Pass Index ( For the Selected strokes. Will make a rig if gp is not parented )"""
    bl_idname = 'gpencil.create_indexed_time_offset_rig'
    bl_label = 'Create Indexed Time Offset Rig'
    bl_description = 'Function: Create a Time Offset rig/modifier to control multiple layers with Pass Index ( For the Selected strokes. Will make a rig if gp is not parented ). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}
    target_pass_index: bpy.props.IntProperty(description='Function: stores the Target Pass Index value for this command. How to use: set the value from the operator dialog or N-panel before running the operation.', name='Pass Index', default=0, min=0)
    new_mod_name: bpy.props.StringProperty(description='Function: stores the New Mod Name value for this command. How to use: set the value from the operator dialog or N-panel before running the operation.', name='Modifier Name', default='')

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'GREASEPENCIL' and (obj.mode in {'EDIT', 'SCULPT_GREASE_PENCIL'})

    def create_arrow_mesh(self, name='WGT_Arrow'):
        if name in bpy.data.objects:
            return bpy.data.objects[name]
        mesh = bpy.data.meshes.new(name)
        obj = bpy.data.objects.new(name, mesh)
        bpy.context.collection.objects.link(obj)
        bm = bmesh.new()
        verts = [(0, 0, 0), (0.3, -0.2, 0), (0.1, -0.2, 0), (0.1, -0.5, 0), (-0.1, -0.5, 0), (-0.1, -0.2, 0), (-0.3, -0.2, 0)]
        for v in verts:
            bm.verts.new(v)
        bm.verts.ensure_lookup_table()
        bm.faces.new(bm.verts)
        bm.to_mesh(mesh)
        bm.free()
        obj.hide_viewport = True
        obj.hide_render = True
        return obj

    def create_dial_mesh(self, name='WGT_Dial'):
        if name in bpy.data.objects:
            return bpy.data.objects[name]
        mesh = bpy.data.meshes.new(name)
        obj = bpy.data.objects.new(name, mesh)
        bpy.context.collection.objects.link(obj)
        bm = bmesh.new()
        segments = 16
        inner_r = 0.2
        inner_verts = [bm.verts.new((inner_r * cos(2 * pi * i / segments), 0, inner_r * sin(2 * pi * i / segments))) for i in range(segments)]
        for i in range(segments):
            bm.edges.new((inner_verts[i], inner_verts[(i + 1) % segments]))
        arc_segments = 8
        outer_r = 0.8
        outer_verts = [bm.verts.new((outer_r * cos(pi / 2 * (i / arc_segments)), 0, outer_r * sin(pi / 2 * (i / arc_segments)))) for i in range(arc_segments + 1)]
        for i in range(arc_segments):
            bm.edges.new((outer_verts[i], outer_verts[i + 1]))
        bm.to_mesh(mesh)
        bm.free()
        obj.hide_viewport = True
        obj.hide_render = True
        return obj

    def invoke(self, context, event):
        self.new_mod_name = ''
        if hasattr(context.scene, 'gp_renamer_props'):
            self.target_pass_index = context.scene.gp_renamer_props.target_pass_index
        return _safe_invoke_props_dialog(self, context)

    def execute(self, context):
        gp_obj = context.active_object
        data = gp_obj.data
        arrow_shape = self.create_arrow_mesh()
        dial_shape = self.create_dial_mesh()
        target_layers = []
        for layer in data.layers:
            parent_hidden = False
            if layer.parent_group and layer.parent_group.hide:
                parent_hidden = True
            if not layer.hide and (not layer.lock) and (not parent_hidden):
                cf = layer.current_frame()
                if cf and cf.drawing and any((s.select for s in cf.drawing.strokes)):
                    target_layers.append(layer)
        if not target_layers:
            _sssuite_report(self, {'INFO'}, 'No selected strokes found.')
            return {'CANCELLED'}
        cursor_loc = context.scene.cursor.location.copy()
        rig_obj = gp_obj.parent if gp_obj.parent and gp_obj.parent.type == 'ARMATURE' else None
        if not rig_obj:
            arm_data = bpy.data.armatures.new('TimeOffset_ArmData')
            rig_obj = bpy.data.objects.new('TimeOffset_Rig', arm_data)
            context.collection.objects.link(rig_obj)
            rig_obj.location = cursor_loc
        arm_data = rig_obj.data
        context.view_layer.objects.active = rig_obj
        bpy.ops.object.mode_set(mode='EDIT')
        local_pos = rig_obj.matrix_world.inverted() @ cursor_loc
        clean_name = self.new_mod_name.replace(' ', '_')
        root_name, con_name = (f'{clean_name}_Root', f'{clean_name}_Con')
        root = arm_data.edit_bones.new(root_name)
        root.head = local_pos
        root.tail = local_pos + Vector((0.5, 0, 0))
        con = arm_data.edit_bones.new(con_name)
        con.head = local_pos
        con.tail = local_pos + Vector((0, 0, 0.5))
        con.parent = root
        bpy.ops.object.mode_set(mode='POSE')
        proot = rig_obj.pose.bones[root_name]
        proot.custom_shape = dial_shape
        proot.bone.show_wire = True
        proot.color.palette = 'THEME06'
        proot.custom_shape_rotation_euler[1] = radians(270)
        proot.custom_shape_rotation_euler[2] = radians(90)
        pcon = rig_obj.pose.bones[con_name]
        pcon.rotation_mode = 'XYZ'
        pcon.custom_shape = arrow_shape
        pcon.bone.show_wire = True
        pcon.custom_shape_scale_xyz = (1.0, 2.0, 1.0)
        pcon.custom_shape_translation[1] = 0.5
        pcon.color.palette = 'THEME03'
        rot_con = pcon.constraints.new('LIMIT_ROTATION')
        rot_con.use_limit_z, rot_con.min_z, rot_con.max_z = (True, 0.0, radians(90))
        rot_con.owner_space, rot_con.use_transform_limit = ('LOCAL', True)
        dist_con = pcon.constraints.new('LIMIT_DISTANCE')
        dist_con.target, dist_con.subtarget = (rig_obj, root_name)
        dist_con.distance, dist_con.limit_mode = (0.0, 'LIMITDIST_INSIDE')
        mod = gp_obj.modifiers.new(name=self.new_mod_name, type='GREASE_PENCIL_TIME')
        mod.mode = 'FIX'
        mod.use_layer_pass_filter = True
        mod.layer_pass_filter = self.target_pass_index
        fcurve = mod.driver_add('offset')
        fcurve.driver.type = 'AVERAGE'
        var = fcurve.driver.variables.new()
        var.name, var.type = ('rotation', 'SINGLE_PROP')
        var.targets[0].id = rig_obj
        var.targets[0].data_path = f'pose.bones["{con_name}"].rotation_euler[2]'
        fcurve.modifiers.new(type='GENERATOR').coefficients = (0.0, context.scene.gp_renamer_props.target_sensitivity)
        for target_layer in target_layers:
            target_layer.pass_index = self.target_pass_index
            if not any((f.frame_number == 0 for f in target_layer.frames)):
                frame_1 = next((f for f in target_layer.frames if f.frame_number == 1), None)
                if frame_1:
                    f0 = target_layer.frames.new(0)
                    f0.drawing = frame_1.drawing
        bpy.ops.object.mode_set(mode='OBJECT')
        context.view_layer.objects.active = rig_obj
        bpy.ops.object.mode_set(mode='POSE')
        _sssuite_report(self, {'INFO'}, f'Created rig for: {self.new_mod_name}')
        return {'FINISHED'}

class GP_OT_remove_setup_from_selection(bpy.types.Operator):
    """Reset layers, remove the GP modifiers, and delete control bones (Select the control bone for this)"""
    bl_idname = 'gpencil.remove_setup_from_selection'
    bl_label = 'Remove Setup From Selected Bone'
    bl_description = 'Function: Reset layers, remove the GP modifiers, and delete control bones (Select the control bone for this). How to use: click this command from the Smart Selector N-panel or its matching popup; use the modifier-key hints in the tooltip when available.'
    bl_options = {'UNDO'}

    def invoke(self, context, event):
        return _safe_invoke_confirm(self, context, event)

    @classmethod
    def poll(cls, context):
        if not (context.active_object and context.active_object.type == 'ARMATURE' and context.active_pose_bone):
            return False
        bone_name = context.active_pose_bone.name
        rig_obj = context.active_object
        for obj in bpy.data.objects:
            anim_data = []
            if obj.animation_data:
                anim_data.append(obj.animation_data)
            if obj.type == 'GPENCIL' and obj.data and obj.data.animation_data:
                anim_data.append(obj.data.animation_data)
            for anim in anim_data:
                for drv in anim.drivers:
                    d_path = drv.data_path.lower()
                    if 'modifier' in d_path and ('time' in d_path or 'offset' in d_path):
                        for var in drv.driver.variables:
                            for target in var.targets:
                                if target.id == rig_obj:
                                    if bone_name == target.bone_target or f'["{bone_name}"]' in target.data_path:
                                        return True
        return False

    def execute(self, context):
        rig_obj = context.active_object
        selected_pbone = context.active_pose_bone
        bone_name = selected_pbone.name
        target_obj = None
        target_mod_name = ''
        for obj in bpy.data.objects:
            anim_sources = [obj.animation_data] if obj.animation_data else []
            if obj.type == 'GPENCIL' and obj.data and obj.data.animation_data:
                anim_sources.append(obj.data.animation_data)
            for anim in anim_sources:
                if not anim:
                    continue
                for drv in anim.drivers:
                    found_bone = False
                    for var in drv.driver.variables:
                        for target in var.targets:
                            if target.id == rig_obj and (bone_name == target.bone_target or f'["{bone_name}"]' in target.data_path):
                                found_bone = True
                                break
                        if found_bone:
                            break
                    if found_bone and 'modifiers' in drv.data_path:
                        target_obj = obj
                        parts = drv.data_path.split('"')
                        if len(parts) > 1:
                            target_mod_name = parts[1]
                        break
                if target_obj:
                    break
        target_transform_state = None
        if target_obj:
            try:
                target_transform_state = {'parent': target_obj.parent, 'parent_type': str(getattr(target_obj, 'parent_type', '') or ''), 'parent_bone': str(getattr(target_obj, 'parent_bone', '') or ''), 'matrix_parent_inverse': target_obj.matrix_parent_inverse.copy(), 'matrix_basis': target_obj.matrix_basis.copy(), 'location': target_obj.location.copy(), 'rotation_mode': str(getattr(target_obj, 'rotation_mode', '') or ''), 'rotation_euler': target_obj.rotation_euler.copy(), 'rotation_quaternion': target_obj.rotation_quaternion.copy(), 'rotation_axis_angle': tuple(target_obj.rotation_axis_angle), 'scale': target_obj.scale.copy()}
            except Exception:
                target_transform_state = None
        if target_obj and target_mod_name:
            mod_stack = None
            if target_mod_name in target_obj.modifiers:
                mod_stack = target_obj.modifiers
            elif hasattr(target_obj, 'grease_pencil_modifiers') and target_mod_name in target_obj.grease_pencil_modifiers:
                mod_stack = target_obj.grease_pencil_modifiers
            if mod_stack:
                mod = mod_stack.get(target_mod_name)
                if mod and hasattr(mod, 'layer_pass_filter'):
                    target_idx = mod.layer_pass_filter
                    for layer in target_obj.data.layers:
                        if layer.pass_index == target_idx:
                            layer.pass_index = 0
                mod_stack.remove(mod)
                _sssuite_report(self, {'INFO'}, f'Removed: {target_mod_name}')
        if target_obj and target_transform_state:
            try:
                if target_obj.parent is not target_transform_state['parent']:
                    target_obj.parent = target_transform_state['parent']
                if target_transform_state['parent_type']:
                    target_obj.parent_type = target_transform_state['parent_type']
                target_obj.parent_bone = target_transform_state['parent_bone']
                target_obj.matrix_parent_inverse = target_transform_state['matrix_parent_inverse']
                target_obj.matrix_basis = target_transform_state['matrix_basis']
            except Exception:
                try:
                    target_obj.location = target_transform_state['location']
                    target_obj.rotation_mode = target_transform_state['rotation_mode']
                    if target_transform_state['rotation_mode'] == 'QUATERNION':
                        target_obj.rotation_quaternion = target_transform_state['rotation_quaternion']
                    elif target_transform_state['rotation_mode'] == 'AXIS_ANGLE':
                        target_obj.rotation_axis_angle = target_transform_state['rotation_axis_angle']
                    else:
                        target_obj.rotation_euler = target_transform_state['rotation_euler']
                    target_obj.scale = target_transform_state['scale']
                    target_obj.matrix_parent_inverse = target_transform_state['matrix_parent_inverse']
                except Exception:
                    pass
        context.view_layer.objects.active = rig_obj
        root_name = selected_pbone.parent.name if selected_pbone.parent else None
        bpy.ops.object.mode_set(mode='EDIT')
        arm_data = rig_obj.data
        if bone_name in arm_data.edit_bones:
            arm_data.edit_bones.remove(arm_data.edit_bones[bone_name])
        if root_name and 'Root' in root_name and (root_name in arm_data.edit_bones):
            arm_data.edit_bones.remove(arm_data.edit_bones[root_name])
        bpy.ops.object.mode_set(mode='POSE')
        return {'FINISHED'}

def _gp_mode_matches(current_mode, target_mode):
    current = str(current_mode or '').strip()
    target = str(target_mode or '').strip()
    if not target:
        return True
    if current == target:
        return True
    if target == 'EDIT' and current in {'EDIT', 'EDIT_GPENCIL', 'EDIT_GREASE_PENCIL'}:
        return True
    if target == 'PAINT_GREASE_PENCIL' and current in {'PAINT_GPENCIL', 'PAINT_GREASE_PENCIL'}:
        return True
    if target == 'SCULPT_GREASE_PENCIL' and current in {'SCULPT_GPENCIL', 'SCULPT_GREASE_PENCIL'}:
        return True
    return False

def _view3d_override_candidates(context):
    seen = set()

    def _push(area):
        if area is None:
            return
        try:
            if str(getattr(area, 'type', '') or '') != 'VIEW_3D':
                return
            key = id(area)
            if key in seen:
                return
            seen.add(key)
            yield area
        except Exception:
            return
    area = getattr(context, 'area', None)
    for item in _push(area) or ():
        yield item
    screen = getattr(context, 'screen', None)
    for item in getattr(screen, 'areas', ()) if screen is not None else ():
        for pushed in _push(item) or ():
            yield pushed

def _safe_set_view3d_tool(context, tool_id):
    tool_id = str(tool_id or '').strip()
    if not tool_id:
        return False
    window = getattr(context, 'window', None)
    screen = getattr(context, 'screen', None)
    for area in _view3d_override_candidates(context):
        region = None
        try:
            for candidate in getattr(area, 'regions', ()):
                if str(getattr(candidate, 'type', '') or '') == 'WINDOW':
                    region = candidate
                    break
        except Exception:
            region = None
        space = None
        try:
            space = getattr(getattr(area, 'spaces', None), 'active', None)
        except Exception:
            space = None
        try:
            if hasattr(context, 'temp_override'):
                override = {'area': area}
                if region is not None:
                    override['region'] = region
                if space is not None:
                    override['space_data'] = space
                if window is not None:
                    override['window'] = window
                if screen is not None:
                    override['screen'] = screen
                with context.temp_override(**override):
                    bpy.ops.wm.tool_set_by_id(name=tool_id)
            else:
                bpy.ops.wm.tool_set_by_id(name=tool_id)
            return True
        except Exception as exc:
            pass
            continue
    return False

def sync_gp3_tool(context, target_mode, is_brush, asset_path):
    """Ensures Mode and Tool/Asset sync without sending an empty VIEW_3D tool id."""
    target_mode = str(target_mode or '').strip()
    asset_path = str(asset_path or '').strip()
    is_brush = bool(is_brush)
    if target_mode and (not _gp_mode_matches(getattr(context, 'mode', ''), target_mode)):
        try:
            bpy.ops.object.mode_set(mode=target_mode)
        except Exception as exc:
            pass
            return False
    try:
        context.view_layer.update()
    except Exception:
        pass

    def delayed_activation():
        if target_mode and (not _gp_mode_matches(getattr(context, 'mode', ''), target_mode)):
            return None
        if not asset_path:
            return None
        if is_brush:
            try:
                bpy.ops.brush.asset_activate(asset_library_type='ESSENTIALS', relative_asset_identifier=asset_path)
            except Exception as e:
                pass
        else:
            _safe_set_view3d_tool(context, asset_path)
        try:
            for area in getattr(getattr(context, 'screen', None), 'areas', ()):
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    area.tag_redraw()
        except Exception:
            pass
        return None
    try:
        bpy.app.timers.register(delayed_activation, first_interval=0.1)
    except Exception:
        delayed_activation()
    return True

class GP_OT_Switch_sync:
    _target_mode = 'OBJECT'
    _target_tool = ''
    _is_asset = False

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type not in {'GPENCIL', 'GREASEPENCIL'}:
            return {'CANCELLED'}
        if not str(getattr(self, '_target_tool', '') or '').strip():
            return {'CANCELLED'}
        sync_gp3_tool(context, self._target_mode, self._is_asset, self._target_tool)
        return {'FINISHED'}

class GP_OT_EditLasso(GP_OT_Switch_sync, bpy.types.Operator):
    bl_idname = 'gpencil.lasso_edit'
    bl_label = 'Lasso Edit'
    bl_options = {'UNDO'}
    bl_description = 'Function: runs the Lasso Edit command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.'
    _target_mode = 'EDIT'
    _target_tool = 'builtin.select_lasso'
    _is_asset = False

class GP_OT_DrawBrush(GP_OT_Switch_sync, bpy.types.Operator):
    bl_idname = 'gpencil.draw_brush'
    bl_label = 'Draw Brush'
    bl_options = {'UNDO'}
    bl_description = 'Function: runs the Draw Brush command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.'
    _target_mode = 'PAINT_GREASE_PENCIL'
    _target_tool = 'brushes/essentials_brushes-gp_draw.blend/Brush/Ink Pen'
    _is_asset = True

class GP_OT_SculptPull(GP_OT_Switch_sync, bpy.types.Operator):
    bl_idname = 'gpencil.pull_brush'
    bl_label = 'Pull'
    bl_options = {'UNDO'}
    bl_description = 'Function: runs the Pull command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.'
    _target_mode = 'SCULPT_GREASE_PENCIL'
    _target_tool = 'brushes/essentials_brushes-gp_sculpt.blend/Brush/Pull'
    _is_asset = True

class GP_OT_SculptPinch(GP_OT_Switch_sync, bpy.types.Operator):
    bl_idname = 'gpencil.sculpt_pinch'
    bl_label = 'Pinch'
    bl_options = {'UNDO'}
    bl_description = 'Function: runs the Pinch command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.'
    _target_mode = 'SCULPT_GREASE_PENCIL'
    _target_tool = 'brushes/essentials_brushes-gp_sculpt.blend/Brush/Pinch'
    _is_asset = True

class GP_OT_SculptStrength(GP_OT_Switch_sync, bpy.types.Operator):
    bl_idname = 'gpencil.sculpt_strength'
    bl_label = 'Strength'
    bl_options = {'UNDO'}
    bl_description = 'Function: runs the Strength command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.'
    _target_mode = 'SCULPT_GREASE_PENCIL'
    _target_tool = 'brushes/essentials_brushes-gp_sculpt.blend/Brush/Strength'
    _is_asset = True

class GP_OT_SculptThickness(GP_OT_Switch_sync, bpy.types.Operator):
    bl_idname = 'gpencil.sculpt_thickness'
    bl_label = 'Thickness'
    bl_options = {'UNDO'}
    bl_description = 'Function: runs the Thickness command. How to use: click this command from the Smart Selector N-panel or its matching popup; the add-on applies the operation to the current Blender context.'
    _target_mode = 'SCULPT_GREASE_PENCIL'
    _target_tool = 'brushes/essentials_brushes-gp_sculpt.blend/Brush/Thickness'
    _is_asset = True

class GP_UI_gp_select_body:
    """Creates a Panel in the 3D Viewport Sidebar"""
    bl_label = 'GP Select'

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.separator()
        col.label(text=_i18n_text('Modes'))
        col.separator()
        _operator_with_icon(col, 'gpencil.draw_brush', icon='GREASEPENCIL', text=_i18n_text('Draw'))
        col.separator()
        _operator_with_icon(col, 'gpencil.lasso_edit', icon='IPO_ELASTIC', text=_i18n_text('Lasso'))
        col.separator()
        _operator_with_icon(col, 'gpencil.pull_brush', icon='VIEW_PAN', text=_i18n_text('Pull'))
        col.separator()
        _operator_with_icon(col, 'gpencil.sculpt_pinch', icon='FULLSCREEN_EXIT', text=_i18n_text('Pinch'))
        col.separator()
        _operator_with_icon(col, 'gpencil.sculpt_strength', icon='STROKE', text=_i18n_text('Strength'))
        col.separator()
        _operator_with_icon(col, 'gpencil.sculpt_thickness', icon='SHAPEKEY_DATA', text=_i18n_text('Thickness'))
        col.separator(factor=0.5)
        col = layout.column(align=True)
        col.separator()
        col.label(text=_i18n_text('Rigging'))
        col.separator(factor=1.2)
        box = col.box()
        box.scale_y = 1.2
        _operator_with_icon(box, 'gpencil.setup_weight_paint', icon='WPAINT_HLT', text=_i18n_text('Weight Selected'))
        col.separator(factor=1.0)
        row = col.row(align=True)
        row.separator(factor=1.5)
        _operator_with_icon(row, 'gpencil.assign_weight_to_selected', text=_i18n_text('Assign Weight'), icon='BONE_DATA')
        row = col.row(align=True)
        row.separator(factor=1.5)
        _operator_with_icon(row, 'gpencil.duplicate_assign_material', text='', icon='MATERIAL')
        row.separator()
        _operator_with_icon(row, 'gpencil.rename_layer_to_vgroup', text='', icon='SMALL_CAPS')
        row.separator()
        _operator_with_icon(row, 'gpencil.layers_to_vgroups', icon='CURRENT_FILE', text='')
        row.separator()
        _operator_with_icon(row, 'gpencil.clear_stroke_weights', icon='X', text='')
        col.separator()
        col = layout.column(align=True)
        col.label(text=_i18n_text('Selection & Reordering'))
        box = col.box()
        box.scale_y = 1.2
        _operator_with_icon(box, 'gpencil.switch_to_layer', icon='TRANSFORM_ORIGINS')
        col.separator(factor=2.0)
        _operator_with_icon(col, 'gpencil.lock_unselected_materials', icon='UNPINNED', text=_i18n_text('Isolate Stroke'))
        col.separator()
        _operator_with_icon(col, 'gpencil.lock_selected_layers', icon='DECORATE_LOCKED')
        col.separator()
        _operator_with_icon(col, 'gpencil.move_layer_top', icon='TRIA_UP_BAR', text=_i18n_text('Send to Top'))
        col.separator(factor=0.2)
        _operator_with_icon(col, 'gpencil.move_layer_bottom', icon='TRIA_DOWN_BAR', text=_i18n_text('Send to Bottom'))
        col.separator(factor=2.0)
        split = col.split(factor=0.72, align=False)
        box = split.box()
        left_col = box.column(align=True)
        left_col.scale_y = 1.2
        _operator_with_icon(left_col, 'gpencil.move_above', icon='TRACKING_REFINE_FORWARDS', text=_i18n_text('Move Above'))
        left_col.separator(factor=0.5)
        _operator_with_icon(left_col, 'gpencil.move_below', icon='TRACKING_REFINE_BACKWARDS', text=_i18n_text('Move Below'))
        right_col = split.column(align=True)
        right_col.scale_y = 1.3
        _operator_with_icon(right_col, 'gpencil.move_group_above', icon='PASTEFLIPUP', text='A', translate=False)
        right_col.separator()
        _operator_with_icon(right_col, 'gpencil.move_group_below', icon='PASTEFLIPDOWN', text='B', translate=False)
        col.separator(factor=1.5)
        col.label(text=_i18n_text('Select By:'))
        box = col.box()
        row = box.row(align=True)
        _operator_with_icon(row, 'gpencil.select_similar_prefix', icon='ZOOM_ALL', text=_i18n_text('Prefix'))
        row.separator()
        _operator_with_icon(row, 'gpencil.select_similar_infix', icon='ZOOM_SELECTED', text=_i18n_text('Infix'))
        row.separator()
        _operator_with_icon(row, 'gpencil.select_similar_suffix', icon='ZOOM_ALL', text=_i18n_text('Suffix'))
        col.separator()
        _operator_with_icon(col, 'gpencil.unlock_all', icon='UNLOCKED', text=_i18n_text('Unlock All'))
        col.separator()
        col.separator()
        col = layout.column(align=True)
        col.label(text=_i18n_text('Visibility & Opacity'))
        props = context.scene.gp_renamer_props
        col.separator()
        row = col.row(align=False)
        row.scale_y = 1.3
        row.prop(props, 'target_opacity', text=_i18n_text('Value'), slider=True)
        sub = row.row(align=True)
        sub.scale_x = 1.2
        sub.scale_y = 0.9
        box_dim = sub.box()
        _operator_with_icon(box_dim, 'gpencil.dim_selected_layers', icon='CHECKMARK', text='')
        box_reset = sub.box()
        _operator_with_icon(box_reset, 'gpencil.reset_layer_opacity', icon='FILE_REFRESH', text='')
        col.separator()
        _operator_with_icon(col, 'gpencil.hide_selected_layers', icon='FILE_HIDDEN', text=_i18n_text('Hide Selected'))
        col.separator()
        col = layout.column(align=True)
        col.label(text=_i18n_text('Layer Tools'))
        _operator_with_icon(col, 'gpencil.duplicate_hide_selected', icon='DUPLICATE', text=_i18n_text('Dup & Hide Original'))
        col.separator()
        _operator_with_icon(col, 'gpencil.delete_selected_layers', icon='TRASH', text=_i18n_text('Delete Selected Layers'))
        col.separator()
        _operator_with_icon(col, 'gpencil.group_selected_stroke_layers', icon='FILEBROWSER', text=_i18n_text('Group selected'))
        col.separator(factor=2.0)
        row = col.row()
        row.label(text='')
        row.scale_y = 1.3
        row.scale_x = 2.0
        _operator_with_icon(row, 'gpencil.vgroups_to_layers', icon='OUTLINER_COLLECTION', text='')
        _operator_with_icon(row, 'gpencil.remove_empty_layers', icon='TRASH', text='')
        col.separator()
        col.label(text=_i18n_text('Mask:'), icon='MOD_MASK')
        mask_stack = col.column(align=True)
        mask_stack.scale_y = 1.2
        box1 = mask_stack.box()
        _operator_with_icon(box1, 'gpencil.mask_to_active', icon='STROKE', text=_i18n_text('Stroke-> Layer'))
        box2 = mask_stack.box()
        _operator_with_icon(box2, 'gpencil.mask_active_to_selected', icon='FILE_BLANK', text=_i18n_text('Mask Layer with Strokes'))
        icon_row_split = col.split(factor=0.5)
        icon_row_split.label(text='')
        right_icons = icon_row_split.row(align=True)
        right_icons.scale_y = 1.3
        right_icons.scale_x = 2.0
        box3 = right_icons.box()
        _operator_with_icon(box3, 'gpencil.unmask_selected', icon='X', text='')
        box4 = right_icons.box()
        _operator_with_icon(box4, 'gpencil.invert_masks_selected', icon='IMAGE_ALPHA', text='')
        box5 = right_icons.box()
        _operator_with_icon(box5, 'gpencil.toggle_all_masks', icon='FILE_HIDDEN', text='')

class GP_UI_renaming_pass_body:
    bl_label = 'Renaming and Pass Index'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        if not hasattr(scene, 'gp_renamer_props'):
            layout.label(text=_i18n_text('Initializing...'), icon='TIME')
            return
        props = scene.gp_renamer_props
        col = layout.column(align=False)
        sub = col.column(align=True)
        row = sub.row(align=True)
        row.scale_y = 1.4
        row.prop(props, 'target_pass_index', text=_i18n_text('Pass'))
        row.separator(factor=0.1)
        row.separator()
        box1 = row.box()
        box1.scale_y = 0.8
        _operator_with_icon(box1, 'gpencil.apply_pass_index', text='', icon='OUTLINER_DATA_GP_LAYER')
        row.separator()
        box2 = row.box()
        box2.scale_y = 0.8
        _operator_with_icon(box2, 'gpencil.set_material_pass_index', text='', icon='MATERIAL')
        row.separator()
        box3 = row.box()
        box3.scale_y = 0.8
        _operator_with_icon(box3, 'gpencil.reset_all_pass_indexes', text='', icon='LOOP_BACK')
        col.separator(factor=2.0)
        sub = col.column(align=True)
        row = sub.row(align=True)
        row.prop(props, 'rename_str', text=_i18n_text('Affixes'))
        _operator_with_icon(row, 'gpencil.clear_single_field', text='', icon='X').field_name = 'rename_str'
        row_btns = sub.row(align=False)
        _operator_with_icon(row_btns, 'gpencil.rename_selected_layers', icon='AXIS_FRONT', text=_i18n_text('Prefix'))
        _operator_with_icon(row_btns, 'gpencil.rename_suffix_selected', icon='AXIS_SIDE', text=_i18n_text('Suffix'))
        col.separator()
        sub = col.column(align=True)
        row = sub.row(align=True)
        row.prop(props, 'full_name', text=_i18n_text('Rename'))
        _operator_with_icon(row, 'gpencil.clear_single_field', text='', icon='X').field_name = 'full_name'
        _operator_with_icon(sub, 'gpencil.rename_full_selected', icon='GREASEPENCIL', text=_i18n_text('Rename'))
        col.separator()
        sub = col.column(align=True)
        row_find = sub.row(align=True)
        row_find.prop(props, 'find_str', text=_i18n_text('Find'))
        _operator_with_icon(row_find, 'gpencil.clear_single_field', text='', icon='X').field_name = 'find_str'
        row_rep = sub.row(align=True)
        row_rep.prop(props, 'replace_str', text=_i18n_text('Replace'))
        _operator_with_icon(row_rep, 'gpencil.clear_single_field', text='', icon='X').field_name = 'replace_str'
        split = sub.split(factor=0.5, align=False)
        _operator_with_icon(split, 'gpencil.find_replace_selected', icon='GREASEPENCIL', text=_i18n_text('Replace'))
        row.separator()
        _operator_with_icon(split, 'gpencil.clean_selected_layer_names', icon='DRIVER_TRANSFORM', text=_i18n_text('Strip'))
        col.separator()

class GP_UI_rigging_body:
    bl_label = 'Rigging Tools'

    def draw(self, context):
        layout = self.layout
        props = context.scene.gp_renamer_props
        col = layout.column(align=True)
        _operator_with_icon(col, 'gpencil.create_time_offset_rig', icon='MOD_TIME', text=_i18n_text('Create Layer Time Control'))
        col.separator()
        _operator_with_icon(col, 'gpencil.create_indexed_time_offset_rig', icon='MOD_TIME', text=_i18n_text('Create Pass Index Time Control'))
        col.separator()
        _operator_with_icon(col, 'gpencil.remove_setup_from_selection', icon='X', text=_i18n_text('Remove Setup'))
        col.separator()
        box = col.box()
        sub = box.column(align=True)
        sub.label(text=_i18n_text('Controller Sensitivity:'), icon='DRIVER')
        row = sub.row(align=True)
        row.prop(props, 'target_sensitivity', text='')
        row.separator()
        row.separator()
        _operator_with_icon(row, 'gpencil.apply_time_sensitivity', text='', icon='CHECKMARK')
        row.separator()
        _operator_with_icon(row, 'gpencil.toggle_time_visibility', text='', icon='RESTRICT_VIEW_OFF')

class _SuitePanelBodyProxy:
    __slots__ = ('layout',)

    def __init__(self, layout):
        self.layout = layout

def _safe_active_object(context):
    try:
        return getattr(context, 'active_object', None)
    except Exception:
        return None

def _safe_scene(context):
    try:
        return getattr(context, 'scene', None)
    except Exception:
        return None

def _active_object_type(context) -> str:
    obj = _safe_active_object(context)
    try:
        return str(getattr(obj, 'type', '') or '')
    except Exception:
        return ''

def _can_draw_gp_object_controls(context) -> bool:
    return _active_object_type(context) in {'GPENCIL', 'GREASEPENCIL'}

def _can_draw_gp_rig_controls(context) -> bool:
    return _active_object_type(context) in {'GPENCIL', 'GREASEPENCIL', 'ARMATURE'}

def _draw_gp_context_message(layout, context) -> None:
    del context
    col = layout.column(align=True)
    col.label(text=_gp_lang_text('Select a Grease Pencil object', 'Grease Pencil を選ぶと'), icon='GREASEPENCIL')
    col.label(text=_gp_lang_text('to show these controls.', 'GP セレクトの操作が出ます。'), icon='BLANK1')

def _wrap_operator_poll_safely(cls):
    if getattr(cls, '_sss_safe_poll_wrapped', False):
        return cls
    raw = cls.__dict__.get('poll')
    if raw is None:
        return cls
    func = raw.__func__ if isinstance(raw, classmethod) else raw
    if not callable(func):
        return cls

    @classmethod
    def _safe_poll(_cls, context, _func=func):
        try:
            return bool(_func(_cls, context))
        except Exception:
            return False
    try:
        pass
        cls._sss_safe_poll_wrapped = True
    except Exception:
        pass
    return cls

def _draw_panel_body(panel_cls, layout, context) -> None:
    try:
        panel_cls.draw(_SuitePanelBodyProxy(layout), context)
    except Exception as exc:
        box = layout.box()
        box.alert = True
        label = _gp_lang_text(f'Draw failed: {exc}', '表示できませんでした。')
        box.label(text=label, icon='ERROR')

def _sssuite_draw_help_button(row, topic_id: str) -> None:
    if not topic_id:
        return
    try:
        row.separator(factor=0.35)
    except Exception:
        pass
    try:
        help_row = row.row(align=True)
        help_row.scale_x = 0.82
        help_row.scale_y = 1.0
    except Exception:
        help_row = row
    try:
        op = help_row.operator('smart_selector_suite.show_help', text='', icon='QUESTION', emboss=True)
        op.topic_id = str(topic_id or '')
    except TypeError:
        try:
            op = help_row.operator('smart_selector_suite.show_help', text='', icon='QUESTION')
            op.topic_id = str(topic_id or '')
        except Exception:
            pass
    except Exception:
        pass

def _sssuite_section_setting_key(section_key: str) -> str:
    key = str(section_key or '').strip()
    if not key:
        return ''
    if key.startswith('show_') or key.startswith('ui_show_'):
        return key
    clean = ''.join((ch.lower() if ch.isalnum() else '_' for ch in key)).strip('_')
    return f'ui_show_{clean}' if clean else ''

def _sssuite_section_open(section_key: str, default: bool=False) -> bool:
    key = _sssuite_section_setting_key(section_key)
    if not key:
        return bool(default)
    try:
        return bool(_sssuite_settings.get_value(key, bool(default)))
    except Exception:
        return bool(default)

def _sssuite_assign_toggle(op, section_key: str, label: str, default: bool=False) -> None:
    try:
        op.section_key = str(section_key or '')
        op.label = str(label or '')
        op.default_state = bool(default)
    except Exception:
        pass

def _sssuite_child_panel_prop_name(section_key: str) -> str:
    key = _sssuite_section_setting_key(section_key)
    return key if key and key.startswith('ui_show_') else ''

def _sssuite_child_panel_state_owner(context=None):
    try:
        ctx = context or getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
        if wm is None or not hasattr(bpy.types.WindowManager, 'smart_selector_suite_npanel_settings'):
            return None
        return getattr(wm, 'smart_selector_suite_npanel_settings', None)
    except Exception:
        return None

def _sssuite_section_box(layout, *, section_key: str, label: str, icon: str, topic_id: str, default: bool=False):
    """Draw a GP Select child section only through Blender's native panel API."""
    del icon
    display = _i18n_text(str(label or ''))
    prop_name = _sssuite_child_panel_prop_name(section_key)
    state_owner = _sssuite_child_panel_state_owner()
    header = None
    panel = None

    if state_owner is not None and prop_name and hasattr(state_owner, prop_name) and hasattr(layout, 'panel_prop'):
        try:
            header, panel = layout.panel_prop(state_owner, prop_name)
        except Exception:
            header = None
            panel = None

    if header is None:
        if not hasattr(layout, 'panel'):
            return (layout, None)
        panel_key = ''.join(ch if ch.isalnum() else '_' for ch in str(section_key or 'section'))
        try:
            header, panel = layout.panel(
                f'SSSUITE_CHILD_{panel_key}',
                default_closed=not bool(default),
            )
        except Exception:
            return (layout, None)

    header.use_property_split = False
    header.use_property_decorate = False
    try:
        header.label(text=display)
    except Exception:
        pass
    # 1.10.51: the ? help sits at the right end of the header (SmartTools common help spec 2026-10-17).
    try:
        help_lane = header.row(align=True)
        help_lane.alignment = 'RIGHT'
    except Exception:
        help_lane = header
    _sssuite_draw_help_button(help_lane, topic_id)

    if panel is None:
        return (header, None)
    panel.use_property_split = False
    panel.use_property_decorate = False
    body = panel.column(align=True)
    body.use_property_split = False
    body.use_property_decorate = False
    return (header, body)

def _sssuite_section_header(box, label: str, icon: str, topic_id: str) -> None:
    row = box.row(align=True)
    row.label(text=_i18n_text(label), icon=icon)
    _sssuite_draw_help_button(row, topic_id)

def draw_gp_select_into_layout(layout, context) -> None:
    """Draw GP Select controls only when the current context can support them.

    Blender can redraw Sidebar panels while the active object is temporarily
    absent or while the mode is changing. During those transient states, drawing
    GP-specific operator grids causes Blender to query many operator polls in an
    invalid context. Keep the section visible, but skip mode-sensitive controls
    until a compatible active object exists.
    """
    layout.use_property_split = False
    layout.use_property_decorate = False
    scene = _safe_scene(context)
    if scene is None or not hasattr(scene, 'gp_renamer_props'):
        layout.label(text=_gp_lang_text('GP Select is initializing.', 'GP セレクトを初期化中です。'), icon='TIME')
        return
    _main_box, main = _sssuite_section_box(layout, section_key='gp_select_main', label='GP Select Controls', icon='GREASEPENCIL', topic_id='gp_select', default=False)
    if main is not None:
        if not _can_draw_gp_object_controls(context):
            _draw_gp_context_message(main, context)
        else:
            _draw_panel_body(GP_UI_gp_select_body, main, context)
    if _can_draw_gp_object_controls(context):
        _rename_box, rename = _sssuite_section_box(layout, section_key='gp_select_renaming_pass', label='Renaming and Pass Index', icon='SORTALPHA', topic_id='gp_select_renaming_pass', default=False)
        if rename is not None:
            _draw_panel_body(GP_UI_renaming_pass_body, rename, context)
    if _can_draw_gp_rig_controls(context):
        _rig_box, rig = _sssuite_section_box(layout, section_key='gp_select_rigging', label='Rigging Tools', icon='ARMATURE_DATA', topic_id='gp_select_rigging', default=False)
        if rig is not None:
            _draw_panel_body(GP_UI_rigging_body, rig, context)

def _purge_legacy_panel_classes() -> None:
    for name in ('GP_PT_gp_select_panel', 'GP_PT_renaming_subpanel', 'GP_PT_rigging_subpanel'):
        cls = getattr(bpy.types, name, None)
        if isinstance(cls, type):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
SMART_SELECTOR_PANEL_CLASSES = ()
REGISTER_CLASSES = (GPRenamerProperties, GP_OT_EditLasso, GP_OT_DrawBrush, GP_OT_SculptPull, GP_OT_SculptThickness, GP_OT_SculptPinch, GP_OT_SculptStrength, GP_OT_clear_single_field, GP_OT_clear_stroke_weights, GP_OT_find_replace_selected, GP_OT_clean_layer_names, GP_OT_reset_layer_opacity, GP_OT_dim_selected_layers, GP_OT_rename_prefix, GP_OT_rename_full_selected, GP_OT_rename_suffix_selected, GP_OT_setup_weight_paint, GP_OT_duplicate_hide_selected, GP_OT_layers_to_vgroups, GP_OT_vgroups_to_layers, GP_OT_switch_to_layer, GP_OT_move_layer_top, GP_OT_move_layer_bottom, GP_OT_hide_selected_layers, GP_OT_lock_unselected_materials, GP_OT_delete_selected_layers, GP_OT_mask_to_active, GP_OT_unmask_selected, GP_OT_invert_masks_selected, GP_OT_mask_active_to_selected, GP_OT_toggle_all_masks, GP_OT_group_selected_stroke_layers, GP_OT_Lock_selected_Layers, GP_OT_duplicate_assign_material, GP_OT_rename_layer_to_vgroup, GP_OT_assign_weight_to_selected, Gp_OT_move_Above, GP_OT_move_Bellow, GP_OT_select_similar_prefix, GP_OT_select_similar_suffix, GP_OT_select_similar_infix, GP_OT_apply_pass_index, GP_OT_set_material_pass_index, GP_OT_reset_all_pass_indexes, GP_OT_UnlockAll, GP_OT_create_time_offset_rig, GP_OT_apply_time_sensitivity, GP_OT_toggle_time_visibility, GP_OT_create_indexed_time_offset_rig, GP_OT_remove_setup_from_selection, Gp_OT_move_Group_Above, Gp_OT_move_Group_Below, GP_OT_remove_empty_layers)
classes = REGISTER_CLASSES

def _safe_unregister_class_if_present(cls):
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass

def _remove_legacy_ui_panels():
    for cls in reversed(SMART_SELECTOR_PANEL_CLASSES):
        _safe_unregister_class_if_present(cls)

def _safe_register_class_if_needed(cls):
    existing = getattr(bpy.types, getattr(cls, '__name__', ''), None)
    if isinstance(existing, type):
        try:
            bpy.utils.unregister_class(existing)
        except Exception:
            pass
    try:
        bpy.utils.register_class(_i18n_localize_class(cls))
    except RuntimeError as exc:
        if 'already registered as a subclass' not in str(exc):
            raise

def register():
    _purge_legacy_panel_classes()
    for cls in classes:
        _wrap_operator_poll_safely(cls)
        _safe_register_class_if_needed(cls)
    bpy.types.Scene.gp_renamer_props = bpy.props.PointerProperty(type=GPRenamerProperties, description='Function: stores GP Renamer Props runtime data used by Smart Selector storage. How to use: this data is managed automatically by the add-on; edit it only when scripting or diagnosing saved state.')

def unregister():
    _purge_legacy_panel_classes()
    remove_weight_cleanup_handlers()
    if hasattr(bpy.types.WindowManager, 'gp_selection_sync_active'):
        del bpy.types.WindowManager.gp_selection_sync_active
    if hasattr(bpy.types.Scene, 'gp_renamer_props'):
        del bpy.types.Scene.gp_renamer_props
    for cls in reversed(classes):
        _safe_unregister_class_if_present(cls)
if __name__ == '__main__':
    register()
