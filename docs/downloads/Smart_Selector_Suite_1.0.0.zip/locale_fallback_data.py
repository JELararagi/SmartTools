# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Japanese source strings and their English text."""

JA_EN = {
 'Blender やり直し': 'Blender Redo',
 'Blender 元に戻す': 'Blender Undo',
 'スマートセレクターのすべての機能を、標準のサイドバーNパネル1つから起動・管理します。名前付き選択セット、プロジェクトツール、セレクターデータ、統合ツール、設定、ブリッジ操作をこの単一パネル内にまとめています。': 'Launch and manage every Smart Selector function from one standard Sidebar N-panel. Named selection sets, project tools, selector data, integrated tools, settings, and bridge actions are grouped inside this single panel.',
 'スマートセレクターの常時起動機能の有効・無効を切り替えます。保存タイミングは「Nパネル状態保存」に従います。': 'Switch an always-on Smart Selector feature on or off. The save timing follows N-panel State Save.',
 'スマートセレクター スクリプトを実行': 'Execute Smart Selector Script',
 'スマートセレクター ヘルプ': 'Smart Selector Help',
 'UIセクションの開閉': 'Toggle UI Section',
 'お気に入りを切替': 'Toggle Favorite',
 'アクティブなプロジェクトフォルダーを再スキャンし、キャッシュされたセレクターデータ一覧を更新します。Nパネル自体は描画中にファイルシステムのスキャンを行いません。': 'Rescan the active Project folder and refresh the cached Selector data list. The N-panel itself never performs filesystem scans while drawing.',
 'アクティブプロジェクトを設定': 'Set Active Project',
 'カスタムプロパティを設定': 'Set Custom Property',
 'シェイプキーを設定': 'Set Shape Key',
 'セレクターを開く': 'Open Selector',
 'セレクターデータ一覧を更新': 'Refresh Selector Data List',
 'ツールUIを読み込む': 'Load Tool UI',
 'ツールコマンド': 'Tool Command',
 'プロジェクトをアーカイブ': 'Archive Project',
 'プロジェクトを複製': 'Duplicate Project',
 'プロジェクトフォルダーを開く': 'Open Project Folder',
 'プロジェクト一覧': 'Project List',
 'プロジェクト作成': 'Create Project',
 'プロジェクト名を変更': 'Rename Project',
 '常時起動機能を切り替え': 'Toggle Always-on Feature',
 '新規セレクターを作成': 'Create New Selector',
 '統合アドオン情報': 'Integrated Add-on Info',
 '選択を適用': 'Apply Selection',
}
