# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""English UI labels keyed by the Japanese text declared by Smart Selector."""

JA_EN = {
    "Blender やり直し": "Blender Redo",
    "Blender 元に戻す": "Blender Undo",
    "スマートセレクター ヘルプ": "Smart Selector Help",
    "スマートセレクター スクリプトを実行": "Execute Smart Selector Script",
    "お気に入りを切替": "Toggle Favorite",
    "セレクターを開く": "Open Selector",
    "新規セレクターを作成": "Create New Selector",
    "セレクターデータ一覧を更新": "Refresh Selector Data List",
    "選択を適用": "Apply Selection",
    "カスタムプロパティを設定": "Set Custom Property",
    "シェイプキーを設定": "Set Shape Key",
    "プロジェクト一覧": "Project List",
    "プロジェクト作成": "Create Project",
    "プロジェクト名を変更": "Rename Project",
    "プロジェクトを複製": "Duplicate Project",
    "プロジェクトをアーカイブ": "Archive Project",
    "プロジェクトフォルダーを開く": "Open Project Folder",
    "アクティブプロジェクトを設定": "Set Active Project",
    "ツールUIを読み込む": "Load Tool UI",
    "ツールコマンド": "Tool Command",
    "統合アドオン情報": "Integrated Add-on Info",
    "UIセクションの開閉": "Toggle UI Section",
    "常時起動機能を切り替え": "Toggle Always-on Feature",
    ("スマートセレクターのすべての機能を、標準のサイドバーNパネル1つから起動・管理します。"
     "名前付き選択セット、プロジェクトツール、セレクターデータ、統合ツール、設定、ブリッジ操作をこの単一パネル内にまとめています。"):
        ("Open the Sidebar to manage Smart Selector in one place. The panel contains named selection sets, "
         "project commands, Selector data, integrated tools, settings, and Bridge commands."),
    ("スマートセレクターの常時起動機能の有効・無効を切り替えます。"
     "保存タイミングは「Nパネル状態保存」に従います。"):
        "Turn a Smart Selector always-on feature on or off. N-panel State Save controls when it is saved.",
    ("アクティブなプロジェクトフォルダーを再スキャンし、キャッシュされたセレクターデータ一覧を更新します。"
     "Nパネル自体は描画中にファイルシステムのスキャンを行いません。"):
        "Scan the active project folder again and refresh the Selector data list. Drawing the Sidebar uses the cached list.",
}
