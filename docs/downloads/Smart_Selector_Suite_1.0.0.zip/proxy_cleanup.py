# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Remove legacy non-functional Smart Tool proxy markers from .blend data.

Older Smart Tools Manager / Smart Selector integration builds could leave small
runtime owner markers on Screen data-blocks. Those markers are not needed for
current behavior because N-panel routing is controlled by the external Manager
JSON and by runtime panel registration. Keeping them in production .blend files
only increases stale-state risk, so Smart Selector removes the known legacy
markers at safe event points.
"""

from __future__ import annotations

import time
from typing import Iterable

import bpy
from bpy.app.handlers import persistent

# Exact/prefix markers known to be non-functional legacy routing/proxy metadata.
# Keep this list conservative. Do not delete transform snapshots, tool settings,
# brush/material/object state, or any generic "proxy" keys that other Smart
# Tools may use for actual scene behavior.
_LEGACY_IDPROP_PREFIXES = (
    '_smart_tools_screen_owner',
    '_smart_tools_area_owner',
    '_smart_tools_region_owner',
    '_smart_tools_sidebar_owner',
    '_smart_tools_panel_proxy',
    '_smart_tools_proxy_panel',
    '_smart_tools_manager_panel_proxy',
    '_smart_selector_suite_panel_proxy',
    '_smart_selector_suite_proxy_panel',
    '_sssuite_panel_proxy',
    '_sssuite_proxy_panel',
)

_LEGACY_IDPROP_EXACT = {
    '_smart_tools_screen_owner_v300',
}

_CLEANUP_INTERVAL_SECONDS = 300.0
_CLEANUP_BURST_DELAYS = (5.0, 30.0)
_LAST_CLEANUP_AT = 0.0
_REGISTERED = False
_TIMER_REGISTERED = False
_PENDING_BURST_COUNT = 0


def _key_is_legacy_proxy_marker(key) -> bool:
    text = str(key or '').strip()
    if text in _LEGACY_IDPROP_EXACT:
        return True
    lower = text.lower()
    return any(lower.startswith(prefix) for prefix in _LEGACY_IDPROP_PREFIXES)


def _iter_idprop_containers() -> Iterable[object]:
    # ID data-blocks where old runtime/UI routing markers have appeared or could
    # have been written by earlier builds. Areas/spaces are included defensively;
    # many Blender runtime structs do not allow ID-property deletion, which is
    # handled safely by the caller.
    for collection_name in ('screens', 'workspaces', 'scenes', 'window_managers'):
        collection = getattr(bpy.data, collection_name, None)
        if collection is None:
            continue
        try:
            for item in collection:
                yield item
        except Exception:
            pass

    try:
        screens = tuple(bpy.data.screens)
    except Exception:
        screens = ()
    for screen in screens:
        try:
            for area in getattr(screen, 'areas', ()):
                yield area
                try:
                    spaces = getattr(area, 'spaces', None)
                    if spaces is not None:
                        for space in spaces:
                            yield space
                except Exception:
                    active = getattr(getattr(area, 'spaces', None), 'active', None)
                    if active is not None:
                        yield active
        except Exception:
            pass


def cleanup_legacy_proxy_data(*, reason: str = 'manual', force: bool = True) -> int:
    """Delete known stale proxy owner markers from the currently open .blend.

    The function is intentionally narrow and fast. It only removes exact legacy
    Smart Tool proxy/routing custom property names. It never removes user data,
    object transforms, Smart Tool functional caches, or keys merely containing
    the word "proxy".
    """
    global _LAST_CLEANUP_AT
    now = time.monotonic()
    if not force and _LAST_CLEANUP_AT and (now - _LAST_CLEANUP_AT) < 1.0:
        return 0
    _LAST_CLEANUP_AT = now

    removed = 0
    seen = set()
    for container in _iter_idprop_containers():
        ident = id(container)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            keys = tuple(container.keys())
        except Exception:
            continue
        for key in keys:
            if not _key_is_legacy_proxy_marker(key):
                continue
            try:
                del container[key]
                removed += 1
            except Exception:
                pass
    return removed


def run_load_post() -> None:
    # Called from the package's one load_post handler; does nothing unless the cleanup switch is on.
    if _REGISTERED:
        _schedule_burst_cleanup()


def run_save_pre() -> None:
    # Called from the package's one save_pre handler; does nothing unless the cleanup switch is on.
    if _REGISTERED:
        cleanup_legacy_proxy_data(reason='save_pre', force=True)


@persistent
def _undo_redo_cleanup(_dummy=None, *args):
    del args
    # Undo/Redo can restore ID-properties from older history states. Clean them
    # once after the undo stack event without adding per-frame overhead.
    _schedule_burst_cleanup()


def _append_handler(handler_list, callback) -> None:
    try:
        if callback not in handler_list:
            handler_list.append(callback)
    except Exception:
        pass


def _remove_handler(handler_list, callback) -> None:
    try:
        if callback in handler_list:
            handler_list.remove(callback)
    except Exception:
        pass


def _maintenance_timer():
    global _TIMER_REGISTERED
    try:
        if not _REGISTERED:
            _TIMER_REGISTERED = False
            return None
        cleanup_legacy_proxy_data(reason='periodic', force=False)
        return _CLEANUP_INTERVAL_SECONDS
    except Exception:
        return _CLEANUP_INTERVAL_SECONDS if _REGISTERED else None


def _burst_cleanup_timer():
    global _PENDING_BURST_COUNT
    if not _REGISTERED:
        _PENDING_BURST_COUNT = 0
        return None
    try:
        cleanup_legacy_proxy_data(reason='delayed_burst', force=True)
    except Exception:
        pass
    _PENDING_BURST_COUNT -= 1
    if _PENDING_BURST_COUNT <= 0:
        return None
    index = max(0, len(_CLEANUP_BURST_DELAYS) - _PENDING_BURST_COUNT)
    try:
        return float(_CLEANUP_BURST_DELAYS[min(index, len(_CLEANUP_BURST_DELAYS) - 1)])
    except Exception:
        return 1.0


def _schedule_burst_cleanup() -> None:
    global _PENDING_BURST_COUNT
    _PENDING_BURST_COUNT = max(_PENDING_BURST_COUNT, len(_CLEANUP_BURST_DELAYS))
    try:
        if not bpy.app.timers.is_registered(_burst_cleanup_timer):
            bpy.app.timers.register(_burst_cleanup_timer, first_interval=_CLEANUP_BURST_DELAYS[0], persistent=False)
    except Exception:
        pass


def _undo_redo_hooks(on) -> None:
    handlers = bpy.app.handlers
    for lst in (handlers.undo_post, handlers.redo_post):
        if on:
            _append_handler(lst, _undo_redo_cleanup)
        else:
            _remove_handler(lst, _undo_redo_cleanup)


def enable() -> None:
    global _REGISTERED, _TIMER_REGISTERED
    _REGISTERED = True
    _schedule_burst_cleanup()

    _undo_redo_hooks(True)

    try:
        if not bpy.app.timers.is_registered(_maintenance_timer):
            bpy.app.timers.register(_maintenance_timer, first_interval=_CLEANUP_INTERVAL_SECONDS, persistent=True)
        _TIMER_REGISTERED = True
    except Exception:
        _TIMER_REGISTERED = False


def disable() -> None:
    global _REGISTERED, _TIMER_REGISTERED, _PENDING_BURST_COUNT
    _REGISTERED = False
    _PENDING_BURST_COUNT = 0

    _undo_redo_hooks(False)

    try:
        if bpy.app.timers.is_registered(_maintenance_timer):
            bpy.app.timers.unregister(_maintenance_timer)
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(_burst_cleanup_timer):
            bpy.app.timers.unregister(_burst_cleanup_timer)
    except Exception:
        pass
    _TIMER_REGISTERED = False
