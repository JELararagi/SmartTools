# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Scene-local named object selection sets.

The implementation follows the core 3ds Max named-selection-set workflow:
create a named set from the current object selection, recall it later, combine it
with the current selection, and maintain its membership. Object pointers are
stored in the .blend so object renames remain valid and selection sets travel
with the scene.
"""

from __future__ import annotations

from typing import Iterable

import bpy
from bpy.props import CollectionProperty, EnumProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, PropertyGroup, UIList

from . import settings

_SCENE_SETS_PROP = "smart_selector_suite_selection_sets"
_SCENE_INDEX_PROP = "smart_selector_suite_selection_set_index"
_WM_NEW_NAME_PROP = "smart_selector_suite_selection_set_new_name"
_MAX_SET_NAME = 128


def _language_code() -> str:
    try:
        value = str(getattr(bpy.context.preferences.view, "language", "") or "").strip()
        if value and value.upper() != "DEFAULT":
            return value
    except Exception:
        pass
    try:
        return str(getattr(bpy.app.translations, "locale", "") or "").strip()
    except Exception:
        return ""


def _is_japanese() -> bool:
    return _language_code().lower().startswith("ja")


def _t(en: str, ja: str) -> str:
    return str(ja if _is_japanese() else en)


def _default_set_name() -> str:
    return _t("Selection Set", "選択セット")


def _clean_name(value: object) -> str:
    text = " ".join(str(value or "").replace("\r", " ").replace("\n", " ").split()).strip()
    return text[:_MAX_SET_NAME]


def _scene_sets(scene):
    if scene is None:
        return None
    try:
        return getattr(scene, _SCENE_SETS_PROP, None)
    except Exception:
        return None


def _active_index(scene) -> int:
    try:
        return int(getattr(scene, _SCENE_INDEX_PROP, 0) or 0)
    except Exception:
        return 0


def _set_active_index(scene, value: int) -> None:
    sets = _scene_sets(scene)
    count = len(sets) if sets is not None else 0
    index = 0 if count <= 0 else max(0, min(int(value), count - 1))
    try:
        setattr(scene, _SCENE_INDEX_PROP, index)
    except Exception:
        pass


def _active_set(scene):
    sets = _scene_sets(scene)
    if sets is None or len(sets) <= 0:
        return None, -1
    index = max(0, min(_active_index(scene), len(sets) - 1))
    return sets[index], index


def _object_pointer(obj) -> int:
    try:
        return int(obj.as_pointer())
    except Exception:
        return 0


def _object_in_scene(obj, scene) -> bool:
    if obj is None or scene is None:
        return False
    try:
        return scene.objects.get(obj.name) is obj
    except Exception:
        return False


def _member_object(member):
    try:
        return member.object
    except (ReferenceError, AttributeError):
        return None
    except Exception:
        return None


def _valid_member_objects(set_item, scene) -> list[bpy.types.Object]:
    result: list[bpy.types.Object] = []
    seen: set[int] = set()
    for member in getattr(set_item, "members", ()) or ():
        obj = _member_object(member)
        pointer = _object_pointer(obj)
        if pointer <= 0 or pointer in seen or not _object_in_scene(obj, scene):
            continue
        seen.add(pointer)
        result.append(obj)
    return result


def _compact_members(set_item, scene) -> int:
    """Remove stale/duplicate pointers outside draw callbacks."""
    members = getattr(set_item, "members", None)
    if members is None:
        return 0
    seen: set[int] = set()
    removed = 0
    for index in range(len(members) - 1, -1, -1):
        obj = _member_object(members[index])
        pointer = _object_pointer(obj)
        if pointer <= 0 or pointer in seen or not _object_in_scene(obj, scene):
            try:
                members.remove(index)
                removed += 1
            except Exception:
                pass
            continue
        seen.add(pointer)
    try:
        active = set_item.active_object
        if active is not None and _object_pointer(active) not in seen:
            set_item.active_object = None
    except Exception:
        pass
    return removed


def _selected_scene_objects(context) -> list[bpy.types.Object]:
    scene = getattr(context, "scene", None)
    if scene is None:
        return []
    try:
        selected = tuple(getattr(context, "selected_objects", ()) or ())
    except Exception:
        selected = ()
    result: list[bpy.types.Object] = []
    seen: set[int] = set()
    view_layer = getattr(context, "view_layer", None)
    active_objects = getattr(view_layer, "objects", None)
    try:
        active_obj = getattr(active_objects, "active", None)
    except Exception:
        active_obj = None

    # Blender can keep an active object after it has been deselected. A named
    # selection set must contain only the current selection, so use the active
    # object merely to order selected members first, never to add an unselected
    # object implicitly.
    selected_pointers = {_object_pointer(obj) for obj in selected}
    active_pointer = _object_pointer(active_obj)
    active_is_selected = active_pointer > 0 and active_pointer in selected_pointers
    if not active_is_selected and active_obj is not None and view_layer is not None:
        try:
            active_is_selected = bool(active_obj.select_get(view_layer=view_layer))
        except Exception:
            active_is_selected = False
    ordered = ([active_obj] if active_is_selected else []) + list(selected)
    for obj in ordered:
        pointer = _object_pointer(obj)
        if pointer <= 0 or pointer in seen or not _object_in_scene(obj, scene):
            continue
        seen.add(pointer)
        result.append(obj)
    return result


def _replace_members(set_item, objects: Iterable[bpy.types.Object], active_object=None) -> int:
    members = getattr(set_item, "members", None)
    if members is None:
        return 0
    members.clear()
    seen: set[int] = set()
    count = 0
    for obj in objects:
        pointer = _object_pointer(obj)
        if pointer <= 0 or pointer in seen:
            continue
        try:
            entry = members.add()
            entry.object = obj
        except Exception:
            continue
        seen.add(pointer)
        count += 1
    try:
        set_item.active_object = active_object if _object_pointer(active_object) in seen else (objects[0] if isinstance(objects, list) and objects else None)
    except Exception:
        pass
    return count


def _unique_name(scene, desired: str, *, ignore_index: int = -1) -> str:
    base = _clean_name(desired) or _default_set_name()
    sets = _scene_sets(scene)
    used: set[str] = set()
    if sets is not None:
        for index, item in enumerate(sets):
            if index == ignore_index:
                continue
            try:
                used.add(_clean_name(item.name).casefold())
            except Exception:
                pass
    if base.casefold() not in used:
        return base
    root = base
    counter = 1
    while counter < 10000:
        suffix = f".{counter:03d}"
        candidate = f"{root[: max(1, _MAX_SET_NAME - len(suffix))]}{suffix}"
        if candidate.casefold() not in used:
            return candidate
        counter += 1
    return f"{root[: max(1, _MAX_SET_NAME - 5)]}.9999"


def _new_name_get(_self) -> str:
    value = str(settings.get_value("selection_set_new_name", "") or "")
    return value


def _new_name_set(_self, value) -> None:
    settings.set_value("selection_set_new_name", _clean_name(value))
    settings.tag_view3d_redraw()


def _tag_redraw() -> None:
    try:
        settings.tag_view3d_redraw()
    except Exception:
        pass


class SSSUITE_SelectionSetMember(PropertyGroup):
    object: PointerProperty(
        name="Object",
        type=bpy.types.Object,
        description="Object reference stored in this named selection set.",
    )


class SSSUITE_SelectionSetItem(PropertyGroup):
    name: StringProperty(
        name="Selection Set Name",
        description="Name shown for this named object selection set.",
        default="Selection Set",
        maxlen=_MAX_SET_NAME,
    )
    active_object: PointerProperty(
        name="Active Object",
        type=bpy.types.Object,
        description="Object that was active when this selection set was last updated.",
    )
    members: CollectionProperty(
        name="Selection Set Members",
        type=SSSUITE_SelectionSetMember,
        description="Object references contained in this named selection set. Use the Add and Remove member buttons in the N-panel to edit this list.",
    )


class SSSUITE_UL_selection_sets(UIList):
    bl_idname = "SSSUITE_UL_selection_sets"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        del context, data, icon, active_data, active_propname, index
        row = layout.row(align=True)
        try:
            name = _clean_name(item.name) or _default_set_name()
        except Exception:
            name = _default_set_name()
        row.label(text=name, icon="GROUP", translate=False)
        try:
            count = sum(1 for member in item.members if _member_object(member) is not None)
        except Exception:
            count = 0
        row.label(text=str(count), icon="OBJECT_DATA")


class _SelectionSetOperatorBase:
    @classmethod
    def poll(cls, context):
        scene = getattr(context, "scene", None) if context is not None else None
        return scene is not None and _scene_sets(scene) is not None

    def _resolve(self, context):
        scene = getattr(context, "scene", None)
        sets = _scene_sets(scene)
        index = int(getattr(self, "index", -1))
        if index < 0:
            index = _active_index(scene)
        if sets is None or index < 0 or index >= len(sets):
            self.report({"WARNING"}, _t("No valid selection set is active.", "有効な選択セットがアクティブではありません。"))
            return scene, sets, None, -1
        return scene, sets, sets[index], index


class SSSUITE_OT_selection_set_create(_SelectionSetOperatorBase, Operator):
    bl_idname = "smart_selector_suite.selection_set_create"
    bl_label = "Create Selection Set"
    bl_options = {'UNDO'}

    name: StringProperty(name="Selection Set Name", default="", maxlen=_MAX_SET_NAME)

    @classmethod
    def description(cls, context, properties):
        del cls, context, properties
        return _t(
            "Create one named object selection set from the objects currently selected in the scene. The set is saved in the .blend and object renames remain linked.",
            "現在シーンで選択中のオブジェクトから、名前付き選択セットを1つ作成します。セットは.blendへ保存され、オブジェクト名を変更しても参照は維持されます。",
        )

    def execute(self, context):
        scene = context.scene
        selected = _selected_scene_objects(context)
        if not selected:
            self.report({"WARNING"}, _t("Select one or more objects first.", "先に1つ以上のオブジェクトを選択してください。"))
            return {"CANCELLED"}
        sets = _scene_sets(scene)
        if sets is None:
            return {"CANCELLED"}
        desired = _clean_name(self.name)
        if not desired:
            try:
                desired = _clean_name(getattr(context.window_manager, _WM_NEW_NAME_PROP, ""))
            except Exception:
                desired = ""
        item = sets.add()
        item.name = _unique_name(scene, desired or _default_set_name(), ignore_index=len(sets) - 1)
        active = getattr(getattr(context, "view_layer", None), "objects", None)
        active_obj = getattr(active, "active", None) if active is not None else None
        count = _replace_members(item, selected, active_obj)
        _set_active_index(scene, len(sets) - 1)
        _tag_redraw()
        self.report({"INFO"}, _t(f'Created "{item.name}" with {count} object(s).', f'「{item.name}」を{count}個のオブジェクトで作成しました。'))
        return {"FINISHED"}


class SSSUITE_OT_selection_set_apply(_SelectionSetOperatorBase, Operator):
    bl_idname = "smart_selector_suite.selection_set_apply"
    bl_label = "Apply Selection Set"
    bl_options = {'UNDO'}

    index: IntProperty(default=-1, options={"HIDDEN"})
    mode: EnumProperty(
        name="Selection Mode",
        items=(
            ("REPLACE", "Replace", "Replace the current object selection with this set"),
            ("ADD", "Add", "Add this set to the current object selection"),
            ("SUBTRACT", "Subtract", "Remove this set from the current object selection"),
            ("TOGGLE", "Toggle", "Toggle each object in this set"),
        ),
        default="REPLACE",
        options={"HIDDEN"},
    )

    @classmethod
    def description(cls, context, properties):
        del cls, context
        mode = str(getattr(properties, "mode", "REPLACE") or "REPLACE")
        descriptions = {
            "REPLACE": _t("Replace the current object selection with the active named selection set.", "現在のオブジェクト選択を、アクティブな名前付き選択セットへ置き換えます。"),
            "ADD": _t("Add every available object in the active named selection set to the current selection.", "アクティブな名前付き選択セット内の利用可能な全オブジェクトを現在の選択へ追加します。"),
            "SUBTRACT": _t("Remove every object in the active named selection set from the current selection.", "アクティブな名前付き選択セット内の全オブジェクトを現在の選択から除外します。"),
            "TOGGLE": _t("Toggle the selection state of every object in the active named selection set.", "アクティブな名前付き選択セット内の各オブジェクトの選択状態を反転します。"),
        }
        return descriptions.get(mode, descriptions["REPLACE"])

    def execute(self, context):
        scene, _sets, item, index = self._resolve(context)
        if item is None:
            return {"CANCELLED"}
        _compact_members(item, scene)
        targets = _valid_member_objects(item, scene)
        view_layer = getattr(context, "view_layer", None)
        if view_layer is None:
            self.report({"WARNING"}, _t("The current editor has no active view layer.", "現在のエディターにはアクティブなビューレイヤーがありません。"))
            return {"CANCELLED"}

        available: list[bpy.types.Object] = []
        for obj in targets:
            try:
                if view_layer.objects.get(obj.name) is obj:
                    available.append(obj)
            except Exception:
                pass

        changed = 0
        failed = 0
        if self.mode == "REPLACE":
            try:
                current = tuple(getattr(context, "selected_objects", ()) or ())
            except Exception:
                current = ()
            for obj in current:
                try:
                    obj.select_set(False, view_layer=view_layer)
                    changed += 1
                except Exception:
                    failed += 1

        for obj in available:
            try:
                if self.mode == "SUBTRACT":
                    desired = False
                elif self.mode == "TOGGLE":
                    desired = not bool(obj.select_get(view_layer=view_layer))
                else:
                    desired = True
                if bool(obj.select_get(view_layer=view_layer)) != desired:
                    obj.select_set(desired, view_layer=view_layer)
                    changed += 1
            except Exception:
                failed += 1

        if self.mode in {"REPLACE", "ADD"}:
            candidate = None
            try:
                stored_active = item.active_object
                if stored_active in available:
                    candidate = stored_active
            except Exception:
                candidate = None
            if candidate is None and available:
                candidate = available[0]
            if candidate is not None:
                try:
                    view_layer.objects.active = candidate
                except Exception:
                    failed += 1

        _set_active_index(scene, index)
        _tag_redraw()
        unavailable = max(0, len(targets) - len(available))
        if unavailable or failed:
            self.report(
                {"WARNING"},
                _t(
                    f"Applied the set; {unavailable + failed} object operation(s) were unavailable in the current view layer or mode.",
                    f"セットを適用しました。現在のビューレイヤーまたはモードでは{unavailable + failed}件のオブジェクト操作を実行できませんでした。",
                ),
            )
        elif not available:
            self.report({"WARNING"}, _t("This set has no available objects in the current view layer.", "このセットには現在のビューレイヤーで利用可能なオブジェクトがありません。"))
        return {"FINISHED"}


class SSSUITE_OT_selection_set_update(_SelectionSetOperatorBase, Operator):
    bl_idname = "smart_selector_suite.selection_set_update"
    bl_label = "Replace Selection Set Contents"
    bl_options = {'UNDO'}

    index: IntProperty(default=-1, options={"HIDDEN"})

    @classmethod
    def description(cls, context, properties):
        del cls, context, properties
        return _t(
            "Replace every member of the active selection set with the objects currently selected. The operation is stored as one Undo step.",
            "アクティブな選択セットの全メンバーを、現在選択中のオブジェクトへ置き換えます。操作全体は1回分のUndoとして記録されます。",
        )

    def execute(self, context):
        scene, _sets, item, index = self._resolve(context)
        if item is None:
            return {"CANCELLED"}
        selected = _selected_scene_objects(context)
        if not selected:
            self.report({"WARNING"}, _t("Select one or more objects before replacing the set contents.", "セット内容を置き換える前に1つ以上のオブジェクトを選択してください。"))
            return {"CANCELLED"}
        active = getattr(getattr(context, "view_layer", None), "objects", None)
        active_obj = getattr(active, "active", None) if active is not None else None
        count = _replace_members(item, selected, active_obj)
        _set_active_index(scene, index)
        _tag_redraw()
        self.report({"INFO"}, _t(f'Updated "{item.name}" with {count} object(s).', f'「{item.name}」を{count}個のオブジェクトで更新しました。'))
        return {"FINISHED"}


class SSSUITE_OT_selection_set_add_members(_SelectionSetOperatorBase, Operator):
    bl_idname = "smart_selector_suite.selection_set_add_members"
    bl_label = "Add Objects to Selection Set"
    bl_options = {'UNDO'}

    index: IntProperty(default=-1, options={"HIDDEN"})

    @classmethod
    def description(cls, context, properties):
        del cls, context, properties
        return _t(
            "Add the currently selected objects to the active selection set without removing its existing members.",
            "既存メンバーを残したまま、現在選択中のオブジェクトをアクティブな選択セットへ追加します。",
        )

    def execute(self, context):
        scene, _sets, item, index = self._resolve(context)
        if item is None:
            return {"CANCELLED"}
        selected = _selected_scene_objects(context)
        if not selected:
            self.report({"WARNING"}, _t("Select one or more objects to add.", "追加するオブジェクトを1つ以上選択してください。"))
            return {"CANCELLED"}
        _compact_members(item, scene)
        existing = {_object_pointer(obj) for obj in _valid_member_objects(item, scene)}
        added = 0
        for obj in selected:
            pointer = _object_pointer(obj)
            if pointer <= 0 or pointer in existing:
                continue
            try:
                entry = item.members.add()
                entry.object = obj
                existing.add(pointer)
                added += 1
            except Exception:
                pass
        try:
            active = context.view_layer.objects.active
            if _object_pointer(active) in existing:
                item.active_object = active
        except Exception:
            pass
        _set_active_index(scene, index)
        _tag_redraw()
        self.report({"INFO"}, _t(f"Added {added} object(s) to the set.", f"セットへ{added}個のオブジェクトを追加しました。"))
        return {"FINISHED"}


class SSSUITE_OT_selection_set_remove_members(_SelectionSetOperatorBase, Operator):
    bl_idname = "smart_selector_suite.selection_set_remove_members"
    bl_label = "Remove Objects from Selection Set"
    bl_options = {'UNDO'}

    index: IntProperty(default=-1, options={"HIDDEN"})

    @classmethod
    def description(cls, context, properties):
        del cls, context, properties
        return _t(
            "Remove the currently selected objects from the active selection set. The objects remain in the scene.",
            "現在選択中のオブジェクトをアクティブな選択セットから除外します。シーン内のオブジェクト自体は削除されません。",
        )

    def execute(self, context):
        scene, _sets, item, index = self._resolve(context)
        if item is None:
            return {"CANCELLED"}
        selected = {_object_pointer(obj) for obj in _selected_scene_objects(context)}
        selected.discard(0)
        if not selected:
            self.report({"WARNING"}, _t("Select one or more objects to remove from the set.", "セットから除外するオブジェクトを1つ以上選択してください。"))
            return {"CANCELLED"}
        removed = 0
        for member_index in range(len(item.members) - 1, -1, -1):
            obj = _member_object(item.members[member_index])
            if _object_pointer(obj) in selected:
                try:
                    item.members.remove(member_index)
                    removed += 1
                except Exception:
                    pass
        _compact_members(item, scene)
        try:
            if item.active_object is None and len(item.members):
                item.active_object = _member_object(item.members[0])
        except Exception:
            pass
        _set_active_index(scene, index)
        _tag_redraw()
        self.report({"INFO"}, _t(f"Removed {removed} object(s) from the set.", f"セットから{removed}個のオブジェクトを除外しました。"))
        return {"FINISHED"}


class SSSUITE_OT_selection_set_rename(_SelectionSetOperatorBase, Operator):
    bl_idname = "smart_selector_suite.selection_set_rename"
    bl_label = "Rename Selection Set"
    bl_options = {'UNDO'}

    index: IntProperty(default=-1, options={"HIDDEN"})
    new_name: StringProperty(name="New Name", default="", maxlen=_MAX_SET_NAME)

    @classmethod
    def description(cls, context, properties):
        del cls, context, properties
        return _t("Rename the active selection set without changing its object membership.", "オブジェクトメンバーを変更せず、アクティブな選択セット名を変更します。")

    def invoke(self, context, event):
        scene, _sets, item, index = self._resolve(context)
        if item is None:
            return {"CANCELLED"}
        self.index = index
        self.new_name = _clean_name(item.name)
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        del context
        self.layout.prop(self, "new_name", text=_t("New Name", "新しい名前"))

    def execute(self, context):
        scene, _sets, item, index = self._resolve(context)
        if item is None:
            return {"CANCELLED"}
        desired = _clean_name(self.new_name)
        if not desired:
            self.report({"WARNING"}, _t("Enter a selection set name.", "選択セット名を入力してください。"))
            return {"CANCELLED"}
        old_name = _clean_name(item.name)
        item.name = _unique_name(scene, desired, ignore_index=index)
        _set_active_index(scene, index)
        _tag_redraw()
        self.report({"INFO"}, _t(f'Renamed "{old_name}" to "{item.name}".', f'「{old_name}」を「{item.name}」へ変更しました。'))
        return {"FINISHED"}


class SSSUITE_OT_selection_set_delete(_SelectionSetOperatorBase, Operator):
    bl_idname = "smart_selector_suite.selection_set_delete"
    bl_label = "Delete Selection Set"
    bl_options = {'UNDO'}

    index: IntProperty(default=-1, options={"HIDDEN"})

    @classmethod
    def description(cls, context, properties):
        del cls, context, properties
        return _t(
            "Delete the active named selection set. Its member objects remain unchanged in the scene.",
            "アクティブな名前付き選択セットを削除します。セット内のオブジェクトはシーンにそのまま残ります。",
        )

    def execute(self, context):
        scene, sets, item, index = self._resolve(context)
        if item is None or sets is None:
            return {"CANCELLED"}
        name = _clean_name(item.name)
        sets.remove(index)
        _set_active_index(scene, min(index, len(sets) - 1))
        _tag_redraw()
        self.report({"INFO"}, _t(f'Deleted selection set "{name}".', f'選択セット「{name}」を削除しました。'))
        return {"FINISHED"}


def draw_selection_sets(layout, context) -> None:
    """Draw the content of the top-level Selection Sets section."""
    scene = getattr(context, "scene", None)
    wm = getattr(context, "window_manager", None)
    sets = _scene_sets(scene)
    if scene is None or wm is None or sets is None:
        layout.label(text=_t("Selection set storage is not available.", "選択セット保存領域を取得できません。"), icon="ERROR")
        return

    create_row = layout.row(align=True)
    try:
        create_row.prop(wm, _WM_NEW_NAME_PROP, text="")
    except Exception:
        pass
    create = create_row.operator("smart_selector_suite.selection_set_create", text=_t("Create", "作成"), icon="ADD")
    try:
        create.name = str(getattr(wm, _WM_NEW_NAME_PROP, "") or "")
    except Exception:
        pass

    if len(sets) <= 0:
        layout.label(text=_t("No selection sets yet.", "選択セットはまだありません。"), icon="NONE")
        return

    rows = max(2, min(6, len(sets)))
    layout.template_list(
        "SSSUITE_UL_selection_sets",
        "",
        scene,
        _SCENE_SETS_PROP,
        scene,
        _SCENE_INDEX_PROP,
        rows=rows,
    )

    item, index = _active_set(scene)
    if item is None:
        return
    try:
        name = _clean_name(item.name) or _default_set_name()
        member_count = sum(1 for member in item.members if _member_object(member) is not None)
    except Exception:
        name, member_count = _default_set_name(), 0
    info = layout.row(align=True)
    info.label(text=name, icon="GROUP", translate=False)
    info.label(text=_t(f"{member_count} objects", f"{member_count} オブジェクト"), icon="OBJECT_DATA")

    select_row = layout.row(align=True)
    for mode, text, icon in (
        ("REPLACE", _t("Select", "選択"), "RESTRICT_SELECT_OFF"),
        ("ADD", _t("Add", "追加"), "ADD"),
        ("SUBTRACT", _t("Subtract", "除外"), "REMOVE"),
        ("TOGGLE", _t("Toggle", "切り替え"), "ARROW_LEFTRIGHT"),
    ):
        op = select_row.operator("smart_selector_suite.selection_set_apply", text=text, icon=icon)
        op.index = index
        op.mode = mode

    edit_row = layout.row(align=True)
    update = edit_row.operator("smart_selector_suite.selection_set_update", text=_t("Update", "更新"), icon="FILE_REFRESH")
    update.index = index
    add_members = edit_row.operator("smart_selector_suite.selection_set_add_members", text="", icon="ADD")
    add_members.index = index
    remove_members = edit_row.operator("smart_selector_suite.selection_set_remove_members", text="", icon="REMOVE")
    remove_members.index = index
    rename = edit_row.operator("smart_selector_suite.selection_set_rename", text="", icon="GREASEPENCIL")
    rename.index = index
    delete = edit_row.operator("smart_selector_suite.selection_set_delete", text="", icon="TRASH")
    delete.index = index


_CLASSES = (
    SSSUITE_SelectionSetMember,
    SSSUITE_SelectionSetItem,
    SSSUITE_UL_selection_sets,
    SSSUITE_OT_selection_set_create,
    SSSUITE_OT_selection_set_apply,
    SSSUITE_OT_selection_set_update,
    SSSUITE_OT_selection_set_add_members,
    SSSUITE_OT_selection_set_remove_members,
    SSSUITE_OT_selection_set_rename,
    SSSUITE_OT_selection_set_delete,
)


def _safe_register_class(cls) -> None:
    existing = getattr(bpy.types, cls.__name__, None)
    if isinstance(existing, type) and existing is not cls:
        try:
            bpy.utils.unregister_class(existing)
        except Exception:
            pass
    if getattr(bpy.types, cls.__name__, None) is cls:
        return
    try:
        bpy.utils.register_class(cls)
    except (RuntimeError, ValueError):
        existing = getattr(bpy.types, cls.__name__, None)
        if isinstance(existing, type) and existing is not cls:
            try:
                bpy.utils.unregister_class(existing)
            except Exception:
                pass
        if getattr(bpy.types, cls.__name__, None) is not cls:
            bpy.utils.register_class(cls)


def _safe_unregister_class(cls) -> None:
    target = getattr(bpy.types, cls.__name__, None)
    if isinstance(target, type):
        try:
            bpy.utils.unregister_class(target)
            return
        except Exception:
            pass
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


def register() -> None:
    for cls in _CLASSES:
        _safe_register_class(cls)
    if not hasattr(bpy.types.Scene, _SCENE_SETS_PROP):
        setattr(
            bpy.types.Scene,
            _SCENE_SETS_PROP,
            CollectionProperty(
                name="Selection Sets",
                type=SSSUITE_SelectionSetItem,
                description="Named object selection sets stored in this scene.",
            ),
        )
    if not hasattr(bpy.types.Scene, _SCENE_INDEX_PROP):
        setattr(
            bpy.types.Scene,
            _SCENE_INDEX_PROP,
            IntProperty(
                name="Active Selection Set",
                description="Active row in the Smart Selector selection-set list.",
                default=0,
                min=0,
                options={"HIDDEN"},
            ),
        )
    if not hasattr(bpy.types.WindowManager, _WM_NEW_NAME_PROP):
        setattr(
            bpy.types.WindowManager,
            _WM_NEW_NAME_PROP,
            StringProperty(
                name="New Selection Set Name",
                description="Name used when creating the next selection set. This UI value follows N-panel State Save.",
                get=_new_name_get,
                set=_new_name_set,
                maxlen=_MAX_SET_NAME,
            ),
        )


def unregister() -> None:
    for owner, name in (
        (bpy.types.WindowManager, _WM_NEW_NAME_PROP),
        (bpy.types.Scene, _SCENE_INDEX_PROP),
        (bpy.types.Scene, _SCENE_SETS_PROP),
    ):
        try:
            if hasattr(owner, name):
                delattr(owner, name)
        except Exception:
            pass
    for cls in reversed(_CLASSES):
        _safe_unregister_class(cls)
