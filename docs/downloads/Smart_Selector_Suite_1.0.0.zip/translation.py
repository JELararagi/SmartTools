# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import re
from functools import lru_cache
from typing import Any

import bpy

_JA_RE = re.compile(r"[ぁ-んァ-ヶ一-龯]")
_SPACE_RE = re.compile(r"\s+")


def _clean(text: object) -> str:
    return _SPACE_RE.sub(" ", str(text or "").strip())


def current_language_code(context=None) -> str:
    """Return Blender's active UI language code, preferring an explicit language setting."""
    prefs = None
    try:
        prefs = getattr(context, 'preferences', None) if context is not None else None
    except Exception:
        prefs = None
    if prefs is None:
        try:
            prefs = getattr(getattr(bpy, 'context', None), 'preferences', None)
        except Exception:
            prefs = None
    try:
        language = str(getattr(getattr(prefs, 'view', None), 'language', '') or '').strip()
        if language and language.upper() != 'DEFAULT':
            return language
    except Exception:
        pass
    try:
        return str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').strip()
    except Exception:
        return ''


def is_japanese_locale(context=None) -> bool:
    code = current_language_code(context).strip().lower()
    return code.startswith('ja') or code in {'japanese', 'jp'}


@lru_cache(maxsize=1)
def _ja_map() -> dict[str, str]:
    result: dict[str, str] = {}
    try:
        from . import translation_data as _translation
    except Exception:
        return result
    try:
        table = getattr(_translation, 'blender_translations', {}).get('ja_JP', {}) or {}
        for key, value in table.items():
            if isinstance(key, tuple) and len(key) >= 2:
                msgid = _clean(key[1])
            else:
                msgid = _clean(key)
            msgstr = _clean(value)
            if msgid and msgstr:
                result[msgid] = msgstr
    except Exception:
        pass
    try:
        extra_fn = getattr(_translation, 'safe_extra_ja_texts', None)
        if callable(extra_fn):
            for key, value in (extra_fn() or {}).items():
                msgid = _clean(key)
                msgstr = _clean(value)
                if msgid and msgstr:
                    result[msgid] = msgstr
    except Exception:
        pass
    return result


@lru_cache(maxsize=1)
def _en_reverse_map() -> dict[str, str]:
    reverse: dict[str, str] = {}
    for en, ja in _ja_map().items():
        if en and ja and en != ja:
            reverse.setdefault(ja, en)
    return reverse


def _source_text(text: object) -> str:
    value = _clean(text)
    if not value:
        return value
    return _en_reverse_map().get(value, value)


def _ja_status(status: str) -> str:
    key = _clean(status).lower()
    mapping = {
        'on': 'オン',
        'off': 'オフ',
        'enabled': '有効',
        'disabled': '無効',
        'true': 'オン',
        'false': 'オフ',
        'visible': '表示',
        'hidden': '非表示',
        'locked': 'ロック',
        'unlocked': 'ロック解除',
    }
    return mapping.get(key, status)


def _dynamic_ja(text: str) -> str | None:
    value = _clean(text)
    if not value:
        return None

    simple_patterns: tuple[tuple[str, str], ...] = (
        (r"Renamed (\d+) layers\.", r"\1 件のレイヤー名を変更しました。"),
        (r"Added suffix to (\d+) layers\.", r"\1 件のレイヤーに接尾辞を追加しました。"),
        (r"Added prefix to (\d+) layers\.", r"\1 件のレイヤーに接頭辞を追加しました。"),
        (r"Cleaned (\d+) layer names\.", r"\1 件のレイヤー名を整理しました。"),
        (r"Modified (\d+) layer names\.", r"\1 件のレイヤー名を変更しました。"),
        (r"Duplicated (\d+) layers", r"\1 件のレイヤーを複製しました。"),
        (r"Deleted (\d+) layers", r"\1 件のレイヤーを削除しました。"),
        (r"Unmasked (\d+) layers", r"\1 件のレイヤーのマスクを解除しました。"),
        (r"Added (\d+) new mask layers", r"\1 件の新しいマスクレイヤーを追加しました。"),
        (r"Assigned (\d+) points", r"\1 点に割り当てました。"),
        (r"Removed (\d+) empty layer\(s\)", r"空のレイヤーを \1 件削除しました。"),
        (r"Updated sensitivity for (\d+) drivers\.", r"\1 件のドライバー感度を更新しました。"),
        (r"Selector data list refreshed: (\d+)", r"セレクターデータ一覧を更新しました（\1 件）。"),
        (r"Removed (\d+) collections", r"\1 件のコレクションを削除しました。"),
    )
    for pattern, repl in simple_patterns:
        if re.fullmatch(pattern, value):
            return re.sub(pattern, repl, value)

    match = re.fullmatch(r"Renamed (\d+) layers to '(.+)'\.", value)
    if match:
        return f"{match.group(1)} 件のレイヤー名を「{match.group(2)}」に変更しました。"
    match = re.fullmatch(r"Applied '(.+)' as mask to (\d+) layers", value)
    if match:
        return f"「{match.group(1)}」を {match.group(2)} 件のレイヤーにマスクとして適用しました。"
    match = re.fullmatch(r"Added (\d+) new mask layers to (.+)", value)
    if match:
        return f"{match.group(2)} に {match.group(1)} 件の新しいマスクレイヤーを追加しました。"
    match = re.fullmatch(r"All masks turned (.+)", value)
    if match:
        return f"すべてのマスクを{_ja_status(match.group(1))}にしました。"
    match = re.fullmatch(r"Assigned (\d+) points to (.+)", value)
    if match:
        return f"{match.group(2)} に {match.group(1)} 点を割り当てました。"
    match = re.fullmatch(r"Set layers Pass Index to (.+)", value)
    if match:
        return f"レイヤーの Pass Index を {match.group(1)} に設定しました。"
    match = re.fullmatch(r"Set Material Pass Index to (.+)", value)
    if match:
        return f"マテリアルの Pass Index を {match.group(1)} に設定しました。"
    match = re.fullmatch(r"Toggled (.+): (.+)", value)
    if match:
        return f"{match.group(1)} を切り替えました: {_ja_status(match.group(2))}"
    match = re.fullmatch(r"Created rig for: (.+)", value)
    if match:
        return f"リグを作成しました: {match.group(1)}"
    match = re.fullmatch(r"Removed: (.+)", value)
    if match:
        return f"削除しました: {match.group(1)}"
    match = re.fullmatch(r"Selected: (.+)", value)
    if match:
        return f"選択: {match.group(1)}"
    match = re.fullmatch(r"Selected suffix: (.+)", value)
    if match:
        return f"選択した接尾辞: {match.group(1)}"
    match = re.fullmatch(r"Selected infix: (.+)", value)
    if match:
        return f"選択した中間文字列: {match.group(1)}"
    match = re.fullmatch(r"Undo failed: (.+)", value)
    if match:
        return f"元に戻す操作に失敗しました: {match.group(1)}"
    match = re.fullmatch(r"Redo failed: (.+)", value)
    if match:
        return f"やり直し操作に失敗しました: {match.group(1)}"
    match = re.fullmatch(r"(\d+)/(\d+) Cumulative Objects Selected", value)
    if match:
        return f"累計 {match.group(2)} 個中 {match.group(1)} 個のオブジェクトを選択しました。"
    return None


def t(text: object, ja: object | None = None, context=None) -> str:
    """Translate one visible UI/report string according to the active Blender language."""
    value = _clean(text)
    if not value:
        return value
    if ja is not None:
        return _clean(ja) if is_japanese_locale(context) else value
    if is_japanese_locale(context):
        exact = _ja_map().get(value)
        if exact:
            return exact
        dynamic = _dynamic_ja(value)
        if dynamic:
            return dynamic
        try:
            translated = bpy.app.translations.pgettext_iface(value)
            if translated and translated != value:
                return translated
        except Exception:
            pass
        try:
            translated = bpy.app.translations.pgettext_tip(value)
            if translated and translated != value:
                return translated
        except Exception:
            pass
        return value
    return _en_reverse_map().get(value, value)


def t_pair(en: object, ja: object, context=None) -> str:
    return t(en, ja, context=context)


def _class_source(cls: type, attr: str, fallback: str = '') -> str:
    cache_name = f'_safe_i18n_source_{attr}'
    cached = getattr(cls, cache_name, None)
    if isinstance(cached, str) and cached:
        return cached
    value = _clean(getattr(cls, attr, '') or fallback)
    value = _source_text(value)
    if value:
        try:
            setattr(cls, cache_name, value)
        except Exception:
            pass
    return value


def _wrap_report(cls: type) -> None:
    try:
        operator_base = getattr(bpy.types, 'Operator', None)
        if operator_base is None or not issubclass(cls, operator_base):
            return
    except Exception:
        return
    try:
        if getattr(cls, '_safe_i18n_report_wrapped', False):
            return
        own_report = cls.__dict__.get('report')
        if own_report is None:
            base_report = getattr(bpy.types.Operator, 'report', None)
            if not callable(base_report):
                return

            def _safe_i18n_report(self, report_type, message):
                return base_report(self, report_type, t(message, context=getattr(self, 'context', None)))
        else:
            def _safe_i18n_report(self, report_type, message):
                return own_report(self, report_type, t(message, context=getattr(self, 'context', None)))

        _safe_i18n_report.__name__ = 'report'
        setattr(cls, 'report', _safe_i18n_report)
        setattr(cls, '_safe_i18n_report_wrapped', True)
    except Exception:
        pass


def exception_text(exc: object, fallback_ja: str = '処理を完了できませんでした。') -> str:
    """Exception text for the screen: Blender's internal English stays off a Japanese UI."""
    value = _clean(exc).replace('Error: ', '')
    if not is_japanese_locale():
        return value
    translated = t(value)
    return translated if _JA_RE.search(translated) else fallback_ja


_OPERATOR_LABEL_SOURCE: dict[str, str] = {}


def operator_label(idname: object) -> str | None:
    """Label of one of this add-on's operators in the current language (bl_label is fixed at registration)."""
    source = _OPERATOR_LABEL_SOURCE.get(str(idname or ''))
    return t(source) if source else None


def localize_class(cls: type) -> type:
    """Normalize Blender class labels/descriptions and report messages for JA/EN display."""
    if not isinstance(cls, type):
        return cls
    try:
        for attr in ('bl_label', 'bl_description', 'bl_category'):
            fallback = ''
            if attr == 'bl_description':
                fallback = _clean(getattr(cls, '__doc__', '') or '')
            source = _class_source(cls, attr, fallback=fallback)
            if source:
                setattr(cls, attr, t(source))
                if attr == 'bl_label' and getattr(cls, 'bl_idname', ''):
                    _OPERATOR_LABEL_SOURCE[str(cls.bl_idname)] = source
    except Exception:
        pass
    _wrap_report(cls)
    return cls


def clear_translation_cache() -> None:
    _ja_map.cache_clear()
    _en_reverse_map.cache_clear()

# Blender translations are stored in the generated catalog module.  Re-export
# them here as well so both ``translation`` and ``translation_data`` imports are
# valid after the unified file-name normalization.
try:
    from .translation_data import blender_translations  # type: ignore F401
except Exception:
    blender_translations = {}
