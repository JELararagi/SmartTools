# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Persistent RNA owner paths and public panel identifiers for Smart Selector."""
CONTRACT_VERSION = 1
EXTENSION_ID = "smart_selector_suite"
CONFIG_FOLDER = "Smart_Selector_Suite"
CONFIG_FILE = CONFIG_FOLDER + ".json"

_TOGGLES = f"window_manager.{EXTENSION_ID}_always_on_toggle_state"
_OPTIONS = f"window_manager.{EXTENSION_ID}_npanel_settings"
_PAYLOAD = f"window_manager.{EXTENSION_ID}_bridge_payloads"
STATE_SAVE_PATH = _TOGGLES + ".npanel_state_save"
SECTION_OPEN_PATH = _OPTIONS + ".show_always_on_toggles"

RUNTIME_TOGGLE_PATHS = tuple(f"{_TOGGLES}.{key}" for key in (
    "collection_manager_state_handlers", "collection_manager_object_menu",
    "collection_manager_popup_hotkey", "collection_manager_disable_objects_override",
    "qcd_system", "qcd_view_hotkeys", "qcd_edit_mode_hotkeys", "qcd_header_widget",
    "legacy_proxy_cleanup", "gp_select_weight_cleanup_handlers", "smart_selector_browser_server",
))
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()

ROOT_PANEL_IDS = tuple(f"{area}_PT_{EXTENSION_ID}_root" for area in (
    "VIEW3D", "IMAGE", "NODE", "SEQUENCER", "CLIP", "DOPESHEET", "GRAPH",
    "NLA", "TEXT", "FILEBROWSER", "SPREADSHEET",
))
PERSISTENCE_ROOTS = (_TOGGLES, _OPTIONS, _PAYLOAD, f"scene.{EXTENSION_ID}_active_project",
                     f"scene.{EXTENSION_ID}_show_favorites_only")
PERSISTED_DYNAMIC_RNA_PATTERNS = ("scene.collection_manager", "scene.gp_renamer_props")
EXCLUDED_TRANSIENT_PATHS = tuple(path + ".name" for path in (
    "scene.gp_renamer_props", "scene.collection_manager", _TOGGLES, _OPTIONS, _PAYLOAD,
))
