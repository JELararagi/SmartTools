# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Smart Selector icon lookup with native previews and Blender icon fallbacks."""

from pathlib import Path

try:
    from bpy.utils import previews
except ImportError:
    previews = None


_custom = ("smart_selector", "selector_list", "rename", "archive", "bridge")
_collection = None
_default_icons = dict(
    smart_selector="RESTRICT_SELECT_OFF", always_on="TIME", clock="TIME", project="FILE_FOLDER",
    selector_list="PRESET", folder="FILE_FOLDER", add="ADD", rename="FILE_REFRESH",
    duplicate="DUPLICATE", archive="TRASH", trash="TRASH", favorite_on="SOLO_ON",
    favorite_off="SOLO_OFF", play="PLAY", edit="GREASEPENCIL", help="QUESTION",
    settings="PREFERENCES", bridge="URL", undo="LOOP_BACK", redo="LOOP_FORWARDS",
    apply="CHECKMARK", shapekey="SHAPEKEY_DATA", property="RNA", script="TEXT",
    collection="OUTLINER_COLLECTION", gp_select="GREASEPENCIL", menu="MENU_PANEL", lock="LOCKED",
    cancel="X", visibility="HIDE_OFF", hidden="HIDE_ON", select="RESTRICT_SELECT_OFF",
    render="RESTRICT_RENDER_OFF", group="GROUP", material="MATERIAL", bone="BONE_DATA",
    layer="OUTLINER_DATA_GP_LAYER", move_up="TRIA_UP_BAR", move_down="TRIA_DOWN_BAR",
    search="VIEWZOOM", time="TIME", brush="STROKE", weight="WPAINT_HLT", file="CURRENT_FILE",
    send="FORWARD", header="RESTRICT_SELECT_OFF",
)


def _key(value):
    return str(value or "").strip()


def register():
    global _collection
    if previews is None or _collection is not None:
        return

    _collection = previews.new()
    assets = Path(__file__).resolve().with_name("icons")
    for name in _custom:
        image = assets / f"{name}.png"
        if image.is_file():
            try:
                _collection.load(name, str(image), "IMAGE", force_reload=True)
            except (OSError, RuntimeError, ValueError):
                continue


def unregister():
    global _collection
    active, _collection = _collection, None
    if active is not None and previews is not None:
        try:
            previews.remove(active)
        except (KeyError, ReferenceError, RuntimeError, ValueError):
            pass


def icon_value(name: str):
    key = _key(name)
    if _collection is None or key not in _custom:
        return 0
    icon = _collection.get(key)
    try:
        return int(getattr(icon, "icon_id", 0))
    except (ReferenceError, RuntimeError, TypeError, ValueError):
        return 0


def fallback_icon(name: str, default: str = "NONE"):
    preferred = _key(default)
    if preferred and preferred == preferred.upper() and preferred != "NONE":
        return preferred
    return _default_icons.get(_key(name)) or ("NONE" if preferred.upper() == "NONE" else preferred or "NONE")


def kwargs(name: str, fallback: str = "NONE"):
    custom = icon_value(name)
    if custom:
        return {"icon_value": custom}
    return {"icon": fallback_icon(name, fallback)}


def custom_name_for_blender_icon(icon: str):
    # Standard icon names have no custom overrides.
    return ""


def kwargs_for_blender_icon(icon: str, default: str = "NONE"):
    key = _key(icon or default) or "NONE"
    if key in _custom:
        return kwargs(key, fallback_icon(key, default))
    if key in _default_icons and key.upper() != key:
        return {"icon": _default_icons[key]}
    return {"icon": key}
