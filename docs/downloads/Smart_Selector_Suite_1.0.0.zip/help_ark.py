# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""1.10.51: the ? help of the 「顔 ARKit」 section and its eight sub-panels (SmartTools common help spec 2026-10-17).

The notes that used to be printed in the panel body (light display stage 2, Esc, srs.hygiene_clamp_face, layers,
Rest Position and so on) were moved here word for word in meaning, together with the user guide
(MIK_顔の使い方の手引き_20261015.md) so that no separate manual is needed.

Only plain data.  Imported lazily by help.py when a help popup is drawn; never at registration.
"""

from __future__ import annotations


def topics(_t) -> dict[str, dict[str, object]]:
    return {
        # ------------------------------------------------------------------------------------------ whole section
        'ark_face': {
            'title': _t('Face ARKit Help', '顔 ARKit ヘルプ'),
            'overview': [
                _t('Tools for a face rig driven by the 52 ARKit expressions (an armature with the bone cc_arkit_board). You can view and adjust the captured face, bake it to hand keys, put it back, work in layers, and lighten the viewport.',
                   'ARKit の 52 表情で動く顔のリグ（骨 cc_arkit_board を持つアーマチュア）のための道具です。取り込んだ顔を見る・直す、手付け用のキーに焼く、元へ戻す、層で直す、画面を軽くする、ができます。'),
                _t('Two modes: Expression mode — the 52 sliders and 2D pads move the face. Hand-key mode — after baking, you key the ARP face controls (c_*) directly.',
                   'モードは 2 つです。表情モード：52 本のスライダーと 2D パッドで顔が動きます。手付けモード：焼いた後、ARP の顔のコントローラー（c_*）に直接キーを打ちます。'),
                _t('Two different "bakes": Smart Shapekey > "Facial CSV Capture" > "Bake Facial CSV" brings a recording into the controller bones (RAW and EDIT actions). "Bake face for hand keys" here moves the expression-mode result into keys on every frame of the hand-key controls.',
                   '「焼く」は 2 種類あり、別の操作です。Smart Shapekey の「フェイシャルCSV収録」→「フェイシャルCSVをベイク」は、収録をコントローラーの骨へ取り込みます（RAW と EDIT ができます）。ここの「顔を手付け用に焼く」は、表情モードの結果を、手付け用のコントローラーの全コマのキーへ移します。'),
            ],
            'prep': [
                _t('Work on a copy of the model saved under a new name. Before importing a capture, before baking and before restoring, save another copy each time.',
                   'モデルの写しを別名で保存して作業します。収録の取り込み・焼く・戻すの前には、そのつど別名で控えを残します。'),
                _t('The file must contain the rig Texts ARK_facial_tools.py and ARK_board_layout.json (shipped inside the rig). If they are missing the panel says "Rig Texts missing" — stop there.',
                   'ファイルにリグの Text（ARK_facial_tools.py と ARK_board_layout.json。リグに入っています）がある事。無いとパネルに「リグの Text がありません」と出ます。その時は先へ進みません。'),
                _t('Settings > Performance / Safety > Allow Execute Script must be on, and the file must be trusted (Auto Run). Otherwise the panel says so in red and the buttons that run the rig Texts are refused or ask first.',
                   '「設定」→「パフォーマンスと安全性」→「スクリプト実行を許可」がオンで、ファイルが信頼されている（Python の自動実行）事。そうでないと、パネルに赤で出て、リグの Text を動かすボタンは断られるか、実行の前に確認します。'),
            ],
            'usage': [
                _t('Read the top lines: "Mode: Expression" or "Mode: Hand keys", and the rig name.',
                   '一番上の行を読みます：「モード：表情モード」か「モード：手付けモード」と、リグ名。'),
                _t('Expression mode: check the face with "52 expressions" or "2D pads"; fix the capture in the EDIT action with the Dope Sheet / Graph Editor.',
                   '表情モード：「52 表情」か「2D パッド」で顔を確かめます。収録の気になる所は、EDIT の Action をドープシート／グラフエディターで直します。'),
                _t('Save under a new name, then "Bake / restore / re-apply" > "Bake face for hand keys". The mode becomes Hand keys.',
                   '別名で保存してから「焼き・戻し・当て直し」→「顔を手付け用に焼く」。モードが手付けモードになります。'),
                _t('Hand-key mode: key the ARP face controls c_*, cc_nose_sneer.l/.r and the helper values ark_hand_*. Use "Clean-up after baking" to smooth keys.',
                   '手付けモード：ARP の顔の c_*、cc_nose_sneer.l/.r、補助の値 ark_hand_* にキーを打ちます。キーをなだらかにするのは「手直しの補助」です。'),
                _t('To take a new capture: "Back to capture state", then import the new CSV in Smart Shapekey (keep "Keep Existing Actions for New Take" on).',
                   '新しい収録にする時：「流し込み直しの状態に戻す」を押してから、Smart Shapekey で新しい CSV を取り込みます（「既存Actionを保持して新しいテイクを作る」をオン）。'),
                _t('Each sub-group below has its own ? help with the details.', '下の各小グループに、詳しい ？ があります。'),
            ],
            'functions': [
                (_t('Light display', '軽い表示'), _t('Turns subdivision off in the viewport so playback is fast.', 'ビューポートの細分化を止めて、再生を速くします。')),
                (_t('Reset / mirror', 'リセット・反転'), _t('Expressions to 0, face to default, paste flipped, check state.', '表情を 0、顔を既定へ、左右反転して貼る、状態を確かめる。')),
                (_t('Bake / restore / re-apply', '焼き・戻し・当て直し'), _t('Bake to hand keys, go back to capture state, re-apply after an ARP update.', '手付け用に焼く、流し込み直しの状態に戻す、ARP 更新の後に当て直す。')),
                (_t('Layers', '層'), _t('Keep fixes on separate NLA layers above the base action, then collapse them.', '手直しを基層の上の別の NLA の層に分けて置き、後で畳み込みます。')),
                (_t('2D pads / 52 expressions / Helper sliders', '2D パッド・52 表情・補助のスライダー'), _t('Move the face in expression mode.', '表情モードで顔を動かします。')),
                (_t('Clean-up after baking', '手直しの補助'), _t('Smooth, ease, decimate keys; relax or push poses.', 'キーのなだらか・イーズ・間引き、姿勢のほぐし・強め。')),
            ],
            'check': [
                _t('After every operation a report line appears under the mode line (green check = OK, red = failed or CHECK). Read it before going on.',
                   '操作のたびに、モードの行の下に報告の行が出ます（緑のチェック＝合格、赤＝失敗か要確認）。先へ進む前に読みます。'),
                _t('"Check state" (Reset / mirror) reports the current mode, the ARK constraints and the light display.', '「状態を確かめる」（リセット・反転）で、今のモード・ARK の拘束・軽い表示を報告に出します。'),
            ],
            'notes': [
                _t('Rest Position / Edit Mode: the 52 board children may appear up to about 15.5 m away. This is normal; do not move the board children in Edit Mode.',
                   'レスト位置・編集モードでは、ボードの子 52 本が最大約 15.5m 離れて見えます。異常ではありません。ボードの子を編集モードで動かさないでください。'),
                _t('Never apply the SmartRig jaw / teeth / tongue clamp to this rig: it breaks the jaw, teeth and tongue limits.', 'このリグにSmartRig の顎・歯・舌のクランプを当てません。顎・歯・舌の上限が壊れます。'),
                _t('Do not use Match to Rig, and do not rebuild the rest shape. After an ARP Update Armature, always run "Re-apply after ARP update".', 'Match to Rig を使わず、レストの形を作り直しません。ARP の Update Armature の後は、必ず「ARP 更新の後に当て直す」を行います。'),
                _t('Do not continue while any of these is shown: missing columns, missing bones, missing Texts, an execution permission you cannot confirm.', '次が出ている間は先へ進みません：足りない列、無い骨、Text が無い、確かめられない実行の許可。'),
                _t('Do not overwrite or delete the original file, RAW, old takes or the backup actions (rigAction_prebake_NNN).', '原本・RAW・古いテイク・控えの Action（rigAction_prebake_NNN）を上書きしたり消したりしません。'),
                _t('Expressions that a capture cannot measure: tongueOut and cheekPuff are hand keys only; noseSneer and cheekSquint are estimated from other expressions.', '収録で取れない表情：tongueOut（舌）と cheekPuff（頬ふくらみ）は手付け専用。noseSneer（鼻のしわ）と cheekSquint（頬の持ち上げ）は他の表情からの推定です。'),
            ],
        },
        # ------------------------------------------------------------------------------------------ light display
        'ark_light': {
            'title': _t('Light Display Help', '軽い表示 ヘルプ'),
            'overview': [
                _t('Makes the viewport light for animating: it switches subdivision modifiers off in the viewport only. The final render (F12) is not changed: it uses the render visibility of each modifier, which this tool does not touch.',
                   'アニメーションの作業用に、画面を軽くします。細分化のモディファイアーをビューポートだけで止めます。F12 の本番レンダーはモディファイアーのレンダー表示の設定を使い、この道具はそれを変えないので、影響しません。'),
                _t('Measured once on a copy of MIK_192: stage 2 with Solid played at about 40 fps (about 4 fps without the light display). Your machine may differ.',
                   'MIK_192 の写しで 1 回測った時、段 2・ソリッドの再生は約 40fps でした（軽い表示なしは約 4fps）。手元で同じ速さになるとは限りません。'),
            ],
            'prep': [
                _t('No selection needed. Choose the stage first.', '選ぶ物はありません。先に段を選びます。'),
            ],
            'usage': [
                _t('Choose the stage: "Stage 1 (Light)" or "Stage 2 (Animator)" (the default).', '段を選びます：「段 1（軽い表示）」か「段 2（作業用）」（既定）。'),
                _t('Stage 2 only: decide Hide small props and the Props name list. The line "N objects match" shows how many objects will be hidden.', '段 2 だけ：「小物を隠す」と「小物」の名前の一覧を決めます。「○ 個が当たります」の行に、隠れる物の数が出ます。'),
                _t('Press "Light display" to turn it on. The 3D View header shows a red "Light display ON" button.', '「軽い表示」を押すとオンです。3D ビューのヘッダーに赤い「軽い表示 中」が出ます。'),
                _t('Press it again, or press the red header button, to turn it off.', 'もう一度押すか、ヘッダーの赤いボタンを押すとオフです。'),
                _t('While it is on, use the "Release and ..." buttons for other bakes (cache, viewport render, SmartRig jiggle / parts / cloth).', 'オンの間、他の焼き（キャッシュ・ビューポートレンダー・SmartRig の揺れ・部位・クロス）は「解除して…」のボタンから行います。'),
            ],
            'functions': [
                (_t('Light display', '軽い表示'), _t('On / off. "(ON)" is added to the button while it is on.', 'オン・オフ。オンの間はボタンに「（オン）」が付きます。')),
                (_t('Release and ...', '解除して…'), _t('The buttons whose names start with these words. Turn the light display off just for that operation, run it, then turn it back on. SmartRig bakes that continue in a dialog stay released: press Light display again afterwards.', 'この言葉で名前が始まるボタンです。その操作の間だけ軽い表示を外し、実行して、終わったら戻します。SmartRig の焼きで確認の画面などが続く時は、外したままにします（終わったら「軽い表示」をもう一度押します）。')),
            ],
            'settings': [
                (_t('Stage 1 (Light)', '段 1（軽い表示）'), _t('Stops every subdivision that is not the last of its modifier stack.', '各メッシュで、スタックの最後ではない細分化を止めます。')),
                (_t('Stage 2 (Animator)', '段 2（作業用）'), _t('Recommended. Stage 1, plus the last subdivision, plus hiding the small props, plus Solid shading in Material / Rendered views.', 'おすすめ。段 1 に加えて、最後の細分化も止め、小物を隠し、マテリアル／レンダーのビューをソリッドにします。')),
                (_t('Smooth face', '顔は滑らかに'), _t('Keeps subdivision on the face pair only. About +13 ms per frame. Off by default; turn on when you judge facial shapes.', '顔の組だけ細分化を残します。1 フレーム約 +13ms 重くなります。既定はオフ。表情の形を見る時にオンにします。')),
                (_t('Hide small props', '小物を隠す'), _t('Stage 2: hides necklaces, belt, piercings, hair metal parts and so on. On by default.', '段 2：ネックレス・ベルト・ピアス・髪の金具などを隠します。既定はオン。')),
                (_t('Props', '小物'), _t('Comma-separated name fragments (case-sensitive). An object property ark_light_prop = 1 / 0 always includes / excludes that object.', '名前の一部をカンマで区切って書きます（大文字と小文字を区別）。物のプロパティ ark_light_prop＝1／0 で、その物を必ず含める／外せます。')),
            ],
            'check': [
                _t('While on, the panel shows in red "Light display ON (stage N)" and how many modifiers are stopped on how many objects; stage 2 also shows the hidden props and the views set to Solid.',
                   'オンの間、パネルに赤で「軽い表示 中（段 N）」と、何個の物で何個の細分化を止めているかが出ます。段 2 では、隠した小物の数とソリッドにしたビューの数も出ます。'),
            ],
            'notes': [
                _t('Stage 2: clothes and props look faceted and the small props are hidden. Do not use it to check the final look (shape, clothes, props, intersections, expressions): turn it off first.',
                   '段 2：服・小物が角ばって見え、小物が隠れます。最終の見た目（形・服・小物・交差・表情）の確認には使わず、先にオフにしてください。'),
                _t('Hidden props are not evaluated, so their positions are stale. Turn it off before measuring or before a check script reads them.', '隠れた小物は計算されず、位置が古いままです。測る前・検査の台本が読む前にオフにします。'),
                _t('View: the view is switched to Solid and put back when released. A normal save releases it for the save and turns it back on after.', '表示：ビューはソリッドに切り替え、外す時に元へ戻します。ふつうの保存は、保存の直前に外して書き、保存の後に同じ段へ戻します。'),
                _t('Auto-save, recovered files and quit.blend keep the light display ON. After opening one, switch it OFF once and check.', '自動保存・復旧のファイル・quit.blend には、軽い表示が入ったまま書かれます。開いたら一度オフにして確かめてください。'),
                _t('Bakes of other add-ons (SmartRig jiggle, cloth) run on the coarse mesh while this is ON. Use the "Release and ..." buttons, or switch it OFF first. "Bake face for hand keys" releases it by itself.',
                   '他のアドオンの焼き（SmartRig の揺れ・クロス等）は、オンのままだと粗いメッシュで計算されます。「解除して…」のボタンから行うか、先にオフにしてください。「顔を手付け用に焼く」は自動で外して戻します。'),
                _t('Before disabling Smart Selector, switch it OFF (disabling also releases it).', 'スマートセレクターを無効にする前にオフにしてください（無効にする時も自動で戻します）。'),
                _t('Running the bake from the rig Text directly does not bring back the hidden props and Solid views.', 'リグの Text から焼きを直接実行した時は、隠した小物とソリッドのビューは戻りません。'),
            ],
        },
        # ------------------------------------------------------------------------------------------ reset / mirror
        'ark_buttons': {
            'title': _t('Reset / Mirror Help', 'リセット・反転 ヘルプ'),
            'overview': [
                _t('Quick buttons that change the current face values and pose: set expressions to 0, put the face to default, paste the face flipped left/right, and print the rig state.',
                   '今の顔の値と姿勢を変える早押しのボタンです：表情を 0、顔を既定へ、左右反転して貼る、リグの状態を出す。'),
            ],
            'prep': [
                _t('The face rig must be in the file. Go to the frame you want to change. For Paste flipped, select the face bones to copy (none selected = all face ARKit bones).', '顔のリグがファイルにある事。変えたいフレームへ行きます。「左右反転して貼る」は写したい顔の骨を選びます（選ばなければ顔 ARKit の骨すべて）。'),
            ],
            'usage': [
                _t('Press the button you need.', '要るボタンを押します。'),
                _t('Read the report line at the top of the Face ARKit section.', '「顔 ARKit」の上に出る報告の行を読みます。'),
            ],
            'functions': [
                (_t('Expressions to 0', '表情を 0'), _t('Sets the 52 cc_arkit_* values to 0. No keys are inserted.', '52 本の cc_arkit_* の値を 0 にします。キーは打ちません。')),
                (_t('Face to default', '顔を既定へ'), _t('Puts location, rotation and scale of the ARK-driven c_* and cc_nose_sneer, and the ark_hand_* values, back to the defaults (also the ark_* values that ARP Reset All does not reset).', 'ARK で動く c_* と cc_nose_sneer の位置・回転・拡大と、ark_hand_* の値を既定へ戻します（ARP の Reset All が戻さない ark_* の値も戻します）。')),
                (_t('Paste flipped', '左右反転して貼る'), _t('Copies the current pose of the selected face bones and pastes it mirrored (like Paste Flipped in Blender). With no visible face bone selected, all face ARKit bones are used, also while they are hidden. The mouthPress helper values are swapped left and right too.', '選んだ顔の骨の今の姿勢を写し、左右反転して貼ります（Blender の左右反転の貼り付けと同じです）。見えている顔の骨を選んでいなければ、隠れていても顔 ARKit の骨すべてを使います。補助の値 mouthPress の左右も入れ替えます。')),
                (_t('Check state', '状態を確かめる'), _t('Changes nothing; reports the mode, the ARK constraints (how many are enabled) and the light display.', '何も変えません。モード、ARK の拘束（有効な数）、軽い表示を報告します。')),
            ],
            'check': [
                _t('The face in the viewport changes at once, and the report line says what was done.', 'ビューポートの顔がすぐ変わり、報告の行に何をしたかが出ます。'),
            ],
            'notes': [
                _t('These change values and the pose only. They do not cancel a capture or restore the whole action. Ctrl+Z undoes them.', '値と姿勢を変えるだけです。収録を取り消したり、Action 全体を戻したりはしません。Ctrl+Z で戻せます。'),
                _t('Watch for unwanted automatic keys when Auto Keying is on (Face to default and Paste flipped move bones).', '自動キーがオンの時は、思わぬキーが入らないか確かめます（「顔を既定へ」「左右反転して貼る」は骨を動かします）。'),
            ],
        },
        # ------------------------------------------------------------------------------------------ bake / restore
        'ark_bake': {
            'title': _t('Bake / Restore / Re-apply Help', '焼き・戻し・当て直し ヘルプ'),
            'overview': [
                _t('"Bake face for hand keys" turns the expression-mode result into keys on every frame of the hand-key controls and switches to Hand-key mode. "Back to capture state" removes those keys and goes back to Expression mode. "Re-apply after ARP update" puts the face setup back after Auto-Rig Pro rebuilt the armature.',
                   '「顔を手付け用に焼く」は、表情モードの結果を、手付け用のコントローラーの全コマのキーにして、手付けモードへ切り替えます。「流し込み直しの状態に戻す」は、そのキーを消して表情モードへ戻します。「ARP 更新の後に当て直す」は、Auto-Rig Pro がアーマチュアを作り直した後に、顔の仕掛けを当て直します。'),
            ],
            'prep': [
                _t('Mode: Expression mode, with the EDIT action of the capture chosen. Save under a new name right before baking.', 'モードは表情モード、収録の EDIT の Action を選んだ状態。焼く直前に別名で保存します。'),
                _t('Check the range: everything from the scene start to end plus every frame that has slider (cc_arkit_*) or ark_hand_* keys is baked — even outside the timeline range. Remove unwanted far-away keys first.',
                   '範囲を確かめます：シーンの開始〜終了と、スライダー（cc_arkit_*）・ark_hand_* のキーがある範囲を合わせて、全部焼きます。タイムラインの外のキーも焼くので、遠いコマの要らないキーは先に消します。'),
                _t('If a layer moves the 52 sliders (cc_arkit_*), collapse it first ("Layers" > "Collapse"), or turn that layer off.', '52 本のスライダー（cc_arkit_*）を動かす層があれば、先に「層」→「畳み込む」か、その層を無効にします。'),
            ],
            'usage': [
                _t('Press "Bake face for hand keys". Answer the confirmation ("Bake the 52 sliders into hand keys?"). If Blender asks to run the rig Text, read the file and Text names and allow only trusted ones.',
                   '「顔を手付け用に焼く」を押します。確認（「52 本の表情を手付け用のキーに焼きますか」）に答えます。Text の実行の確認が出たら、ファイルと Text の名前を読み、信頼できる物だけ許可します。'),
                _t('Wait. Esc cancels; a cancelled bake restores everything from the backup.', '待ちます。Esc で中断でき、中断した時は控えから元へ戻します。'),
                _t('Read the report: channels, frames, constraints stopped, the shape difference before/after in mm (PASS / CHECK), and the backup name.', '報告を読みます：チャンネル数、フレーム、止めた拘束の数、焼く前後の形の差（mm、合格／要確認）、控えの名前。'),
                _t('Check that the top line says "Mode: Hand keys". Save under a new name.', '一番上が「モード：手付けモード」になった事を確かめ、別名で保存します。'),
                _t('To go back: save your work, then press "Back to capture state" and confirm ("Remove the baked keys and return to expression mode? (the backup is kept)").', '戻す時：今の作業を保存してから「流し込み直しの状態に戻す」を押し、確認（「焼いたキーを消して表情モードへ戻しますか（控えは残ります）」）に答えます。'),
                _t('After an ARP Update Armature: press "Dry run" first to see how much differs, then "Re-apply after ARP update".', 'ARP の Update Armature の後：まず「ずれを見る」でずれの数を見てから、「ARP 更新の後に当て直す」を押します。'),
            ],
            'functions': [
                (_t('Bake face for hand keys', '顔を手付け用に焼く'), _t('Bakes all frames, stops the ARK constraints, switches to Hand-key mode. Active layers are muted while it runs and put back after.', '全コマを焼き、ARK の拘束を止め、手付けモードへ切り替えます。有効な層は、その間だけミュートして終わったら戻します。')),
                (_t('Back to capture state', '流し込み直しの状態に戻す'), _t('Deletes the baked keys, restores the keys you had before the bake from the bake backup, and returns to Expression mode.', '焼いたキーを消し、焼く前に打ってあったキーを焼いた時の控えから戻し、表情モードへ戻します。')),
                (_t('Re-apply after ARP update', 'ARP 更新の後に当て直す'), _t('Re-creates the face constraints and drivers after Auto-Rig Pro rebuilt the rig.', 'Auto-Rig Pro がリグを作り直した後に、顔の拘束とドライバーを作り直します。')),
                (_t('Dry run', 'ずれを見る'), _t('Changes nothing; only reports how many things differ.', '何も変えません。ずれている物の数だけを報告します。')),
            ],
            'settings': [
                (_t('Also reset SmartRig limits', 'SmartRig の上限も戻す'), _t('When re-applying, also puts the 12 SmartRig jaw / teeth / tongue limits back to the MIK_192 values. On by default (recommended).', '当て直す時に、SmartRig の顎・歯・舌の上限 12 個も MIK_192 の値へ戻します。既定はオン（おすすめ）。')),
            ],
            'check': [
                _t('After the bake: "Mode: Hand keys", the report says pass, and the mouth, eyes, nose, tongue and body still move as before.', '焼いた後：「モード：手付けモード」、報告が合格、口・目・鼻・舌と体の動きが前と同じ。'),
                _t('After restoring: "Mode: Expression", and the body, frames outside the range and channels that were not baked did not change.', '戻した後：「モード：表情モード」、体・範囲の外・焼いていないチャンネルが変わっていない。'),
            ],
            'notes': [
                _t('Never apply the SmartRig jaw / teeth / tongue clamp to this rig (it broke the jaw, teeth and tongue limits). If you suspect it was applied, save under a new name and report it.', 'このリグにはSmartRig の顎・歯・舌のクランプを当てません（顎・歯・舌の上限を壊した実証があります）。当てた疑いがある時は、別名で保存して報告します。'),
                _t('If the report says "CHECK" or a failure, do not continue editing as if it were baked.', '報告が「要確認」や失敗の時は、焼けた物として手直しを続けません。'),
                _t('After a cancelled bake, check the report, mode, pose and keys; do not assume everything came back.', '中断した後は、報告・モード・姿勢・キーを確かめます。完全に戻ったと決めつけません。'),
                _t('Restoring does not carry your hand fixes over to a new capture. Each restore adds one more backup action (rigAction_prebake_NNN); do not delete them blindly.', '戻しても、焼いた後の手直しが新しい収録へ引き継がれるわけではありません。戻すたびに控えの Action（rigAction_prebake_NNN）が 1 つ増えます。むやみに消さないでください。'),
                _t('If restoring the pre-bake keys fails, the report says so and it counts as a failure: restore them by hand from rigAction_prebake_NNN.', '焼く前のキーを戻せなかった時は報告にそう出て、失敗として扱います。控えの rigAction_prebake_NNN から手で戻します。'),
                _t('"Dry run" only checks. Re-apply does not rebuild the shape of lost corrective shape keys.', '「ずれを見る」は確かめるだけです。当て直しは、消えた補正のシェイプキーの形までは戻しません。'),
                _t('A face bake stops (nothing is baked) when an active layer moves the 52 sliders, or, without layers, when a live non-layer NLA track moves a baked channel the base does not key. The report names the track. Mute that track or collapse first.',
                   '有効な層が 52 本のスライダーを動かしている時や、層が無い時に、基層にキーの無い焼くチャンネルを層ではない NLA のトラックが動かしている時は、焼きは止まります（何も焼きません）。報告にトラック名が出ます。そのトラックをミュートするか、先に畳み込みます。'),
            ],
        },
        # ------------------------------------------------------------------------------------------ layers
        'ark_layers': {
            'title': _t('Layers Help', '層 ヘルプ'),
            'overview': [
                _t('Keeps fixes on separate layers above the current animation (the base), like the animation layers of 3ds Max Biped. Base = the current action; normal keys go into it. A layer = another action on an NLA track, named <base>_L1, _L2 ...',
                   '今のアニメーション（基層）の上に、手直しを別の層として重ねます（3ds Max の Biped のアニメーションレイヤーに似ています）。基層＝今の Action で、ふつうのキーはここに入ります。層＝NLA のトラックに入る別の Action で、名前は <基層の名>_L1、_L2 … です。'),
                _t('The target is the selected armature; without one, the face rig. It works for body bones too.', '対象は、選んでいるアーマチュアです。選んでいなければ顔のリグです。体の骨にも使えます。'),
            ],
            'prep': [
                _t('Select the armature. The armature must have an action (the base); otherwise "Add layer" is greyed — key something first.', 'アーマチュアを選びます。アーマチュアに Action（基層）がある事。無いと「層を足す」が灰色です（先にキーを打ちます）。'),
            ],
            'usage': [
                _t('Check "Target: <name>" at the top.', '一番上の「対象：（名前）」を確かめます。'),
                _t('Press "Add layer". <base>_L1 is made: blend Add, weight 1, same range as the base.', '「層を足す」を押します。<基層の名>_L1 ができます（合成は加算、重み 1、範囲は基層と同じ）。'),
                _t('Press the pencil on the layer row to edit it. The row turns red and the panel says "Editing layer ...: keys go into the layer". Key as usual.', '層の行の鉛筆を押すと、その層の編集に入ります。行が赤くなり「層「…」を編集中：キーは層に入ります」と出ます。ふつうにキーを打ちます。'),
                _t('Press the pencil again, or "Stop editing the layer", to finish.', '鉛筆をもう一度押すか「層の編集を終える」で終わります。'),
                _t('On each row: the checkbox turns the layer on/off, Weight sets how strong it is (0-1), Add/Replace switches the blend, X removes the layer (asks first).', '各行で：チェックで層の有効・無効、「重み」で効き具合（0〜1）、「加算」／「置換」で合成のしかた、× で層を消します（確認が出ます）。'),
                _t('When the fix is final, press "Collapse": base + active layers are computed on every frame of the range and written as base keys.', '手直しが決まったら「畳み込む」：基層＋有効な層を範囲の全フレームで計算し、基層のキーとして書きます。'),
            ],
            'functions': [
                (_t('Add layer', '層を足す'), _t('Makes a new layer above the others.', '新しい層を一番上に作ります。')),
                (_t('Pencil / Stop editing the layer', '鉛筆・層の編集を終える'), _t('Enter / leave editing of that layer.', 'その層の編集に入る・出る。')),
                (_t('Checkbox', 'チェック'), _t('Enable / disable the layer. Disabling here puts the values that only this layer moved back to their default.', '層の有効・無効。ここで無効にすると、その層だけが動かしていた値を既定へ戻します。')),
                (_t('Weight', '重み'), _t('NLA strip influence (0-1).', 'NLA のストリップの影響度（0〜1）。')),
                (_t('Add / Replace', '加算／置換'), _t('Add adds to what is below (default); Replace overwrites it. Each press switches.', '加算は下に足す（既定）、置換は下を上書き。押すたびに切り替わります。')),
                (_t('X', '×'), _t('Removes the layer. Removing the last layer puts the base blend back to the value it had before (usually Replace).', '層を消します。最後の層を消すと、基層の合成は層を足す前の値（ふつうは置換）に戻ります。')),
                (_t('Collapse', '畳み込む'), _t('Bakes base + active layers into the base keys (integer frames only). Asks first; Esc cancels and writes nothing. Collapsed layers are muted and kept as a backup.', '基層＋有効な層を基層のキーへ焼きます（整数のフレームだけ）。確認が出ます。Esc で中断でき、その時は何も書きません。畳み込んだ層はミュートされ、控えとして残ります。')),
            ],
            'settings': [
                (_t('Show base while editing', '編集中も基層を見せる'), _t('While a layer is edited, shows the base under it through the guide track SS_BASE_VIEW. On by default (recommended for face work).', '層の編集中に、表示用のトラック SS_BASE_VIEW で基層も下に敷いて見せます。既定はオン（顔の作業ではおすすめ）。')),
            ],
            'check': [
                _t('The layer list shows each layer (top layer first) and below it "Base: <action>"; with layers, "blend Add" (or "blend Replace") is shown on the same row.', '層の一覧に各層（上の層から）と、その下に「基層：（Action の名前）」が出ます。層がある時は、同じ行に「合成 加算」（か「合成 置換」）が出ます。'),
                _t('Play the animation and compare with the layer on and off.', '再生して、層の有効と無効で比べます。'),
            ],
            'notes': [
                _t('Bake / restore / re-apply mute the active layers while they run and put them back; the report ends with "N layers muted during the run and put back". You can press them as they are.', '焼き・戻し・当て直しは、その間だけ有効な層をミュートして、終わったら戻します。報告の最後に「層 ○ 本をその間だけミュートして戻しました」と出ます。そのまま押して構いません。'),
                _t('A layer on the 52 sliders (cc_arkit_*) must be collapsed (or disabled) before the face bake; otherwise the bake stops and changes nothing.', '52 本のスライダー（cc_arkit_*）を動かす層は、顔を焼く前に畳み込む（か無効にする）必要があります。そうしないと焼きは止まり、何も変えません。'),
                _t('Showing the base: a rotation keyed on another axis than the base rotation may differ slightly between editing and playback (tests: up to about 1.4 degrees on the spine). Location, scale and custom properties match. After fixing body rotations in a layer, always check by playing back; turning "Show base while editing" off makes them match.',
                   '基層を見せる時：基層と違う軸の回転は、編集中と再生で少しずれる事があります（試験で背骨が最大約 1.4°）。位置・拡大・カスタムプロパティは一致します。体の回転を層で直した時は必ず再生で確かめます。「編集中も基層を見せる」をオフにすると一致します。'),
                _t('"The base is not shown while editing (Blender tweak mode)" appears when the guide track is off: Blender itself does not show the base action in tweak mode.', '「編集中は基層が見えていません（Blender の微調整モードの動き）」は、表示用のトラックが無い時に出ます。Blender は微調整モードの間、基層を見せません。'),
                _t('Disable layers with this checkbox, not by muting in the NLA editor (Blender keeps the last value and the shape looks wrong).', '層の無効はこのチェックで行います。NLA エディターで直接ミュートすると、Blender は最後の値を残し、形がずれて見えます。'),
                _t('The Weight slider cannot be keyed with I. To animate the weight, key the strip influence in the NLA editor. When the weight already has several keys, moving the slider keys the current frame.', '重みのスライダーには I でキーを打てません。重みを時間で変える時は、NLA エディターでストリップの影響度 にキーを打ちます。既にキーが複数ある時は、スライダーを動かすと今のフレームにキーが入ります。'),
                _t('The layer range is the base range at the time it was added; it does not grow later.', '層の範囲は、足した時の基層の範囲です。後で基層を伸ばしても、層は伸びません。'),
                _t('Non-layer NLA tracks (pushed-down actions, mocap tracks) are not layers. When one is live the panel says "Other NLA tracks are live (not layers): ...", and the base is then added on top of it — check the shape.', '層ではない NLA トラック（プッシュダウン した物・流し込んだモーキャップ）は層として扱いません。効いている時はパネルに「層ではない NLA のトラックが効いています：…」と出て、基層はそのトラックに足されるようになります。形を確かめます。'),
                _t('"NLA is off for this object: the layers have no effect" means the NLA of that object is turned off.', '「この物は NLA がオフです：層は効きません」は、その物の NLA がオフという事です。'),
                _t('A normal save (Ctrl+S) is safe while editing. Auto-save is not: the guide track SS_BASE_VIEW stays on in an auto-saved file; opened without Smart Selector, mute SS_BASE_VIEW before leaving the edit. Disabling Smart Selector while editing leaves the edit by itself.', 'ふつうの保存（Ctrl+S）は編集中でも安全です。自動保存は違い、SS_BASE_VIEW が効いたまま書かれます。スマートセレクターの無い所で開いた時は、SS_BASE_VIEW をミュートしてから編集を出ます。編集中にスマートセレクターを無効にすると、自動で編集を出ます。'),
                _t('Collapse evaluates every frame: about 5 minutes for 385 frames. Wait until it ends. Layers, weights and mute are saved and can be undone.', '畳み込みは毎コマ評価するので時間が掛かります（385 コマで約 5 分）。終わるまで待ちます。層・重み・ミュートは保存され、元に戻すもできます。'),
            ],
        },
        # ------------------------------------------------------------------------------------------ 2D pads
        'ark_pads': {
            'title': _t('2D Pads Help', '2D パッド ヘルプ'),
            'overview': [
                _t('Each pad moves 2 to 4 paired expressions (cc_arkit_*) at once with two sliders, without new bones. Below each pad the expressions it drives are listed.', '各パッドは、2 本のスライダーで、対になった 2〜4 個の表情（cc_arkit_*）を一度に動かします。新しい骨は作りません。パッドの下に、動かす表情の名前が出ます。'),
            ],
            'prep': [
                _t('Expression mode. In Hand-key mode the pads are greyed and the panel says "Hand-key mode: the pads have no effect."', '表情モードにします。手付けモードではパッドは灰色で、「手付けモード：パッドは効きません。」と出ます。'),
            ],
            'usage': [
                _t('Drag L/R (left/right) and D/U (down/up). Above 0 is the second side (right / up), below 0 the first side (left / down).', '「左右」「下上」を動かします。0 より上は 2 つ目の側（右・上）、0 より下は 1 つ目の側（左・下）です。'),
                _t('Turn Auto Keying on if you want keys.', 'キーを残したい時は自動キーをオンにします。'),
            ],
            'settings': [
                (_t('L/R, D/U', '左右・下上'), _t('-1 to 1. 0 = no change. Start with small values (±0.3).', '−1〜1。0＝変化なし。小さい値（±0.3）から試します。')),
            ],
            'check': [
                _t('The listed expression sliders in "52 expressions" move together.', '「52 表情」の、名前の出ているスライダーが一緒に動きます。'),
            ],
            'notes': [
                _t('Ctrl+Z undoes. Keys are inserted only when Auto Keying is on. Do not put the same fix in both a pad and a slider (it doubles).', 'Ctrl+Z で戻せます。キーは自動キーがオンの時だけ入ります。同じ直しをパッドとスライダーの両方に入れないでください（二重になります）。'),
            ],
        },
        # ------------------------------------------------------------------------------------------ 52 sliders
        'ark_sliders': {
            'title': _t('52 Expressions Help', '52 表情 ヘルプ'),
            'overview': [
                _t('One row per ARKit expression: the button with the expression name selects its bone (a hidden bone is made visible), the number is the bone value (location Y).', 'ARKit の表情ごとに 1 行です。表情名のボタンでその骨を選び（隠れていれば表示します）、数の欄はその骨の値（位置の Y）です。'),
                _t('A hand icon marks the expressions that are hand keys only (tongueOut, cheekPuff): a capture never writes them.', '手のアイコンは手付け専用の表情です（tongueOut、cheekPuff）。収録では書きません。'),
            ],
            'prep': [
                _t('Expression mode. In Hand-key mode the 52 are greyed and only jawForward stays live (the panel says so).', '表情モードにします。手付けモードでは 52 本は灰色で、jawForward だけが効きます（パネルにそう出ます）。'),
            ],
            'usage': [
                _t('Drag the number to try an expression, or click the name to select the bone and key it.', '数を動かして表情を試すか、名前を押して骨を選び、キーを打ちます。'),
                _t('For tongueOut, open the jaw first (the red line under it gives the rig\'s own condition, for example "open the jaw 0.3 or more first").', 'tongueOut は先に顎を開けます（下の赤い行に、リグの条件が出ます。例：「顎を 0.3 以上開けてから」）。'),
            ],
            'settings': [
                (_t('Expression value', '表情の値'), _t('0 = off, 1 = full. Most fixes need 0.1 to 0.5.', '0＝無し、1＝最大。手直しはたいてい 0.1〜0.5 で足ります。')),
            ],
            'check': [
                _t('The face changes in the viewport. A row in red "...: bone missing" means the rig lacks that bone — stop and report.', 'ビューポートの顔が変わります。赤の「…：骨がありません」の行は、リグにその骨が無いという事です。止めて報告します。'),
            ],
            'notes': [
                _t('Moving a slider is not a key: check Auto Keying, the target action and channel. Ctrl+Z undoes.', 'スライダーを動かしただけではキーになりません。自動キー・対象の Action・チャンネルを確かめます。Ctrl+Z で戻せます。'),
                _t('A strong tongueOut puts the tongue below the lower lip: key it gently and check the image.', 'tongueOut を強く打つと、舌が下唇の下に出ます。控えめに打ち、画像で確かめます。'),
                _t('Known limits: mouthPress does not close the lips fully; mouthPucker can look weak; mouthClose above 0 lowers the upper lip; jawLeft/Right stop at about ±1.9 mm (ARP limit).', '分かっている限界：mouthPress で唇が閉じ切らない、mouthPucker が弱く見える事がある、mouthClose が 0 より大きいと上唇が下がる、jawLeft／Right は約 ±1.9mm で頭打ち（ARP の制限）。'),
            ],
        },
        # ------------------------------------------------------------------------------------------ helper sliders
        'ark_hand': {
            'title': _t('Helper Sliders Help', '補助のスライダー ヘルプ'),
            'overview': [
                _t('The helper values ark_hand_* on the rig: lips_retain and the auxiliary mouth shapes (Funnel, Pucker, PressLeft, PressRight).', 'リグの補助の値 ark_hand_* です：lips_retain と、口の補助の形（Funnel・Pucker・PressLeft・PressRight）。'),
                _t('Helper values ark_hand_*: in Expression mode they are added on top of the capture; in Hand-key mode they are the value itself.', '補助の値 ark_hand_*：表情モードでは収録に上乗せ、手付けモードではそのままの値です。'),
            ],
            'prep': [
                _t('The face rig must be in the file. A red "... missing" row means the rig lacks that property.', '顔のリグがファイルにある事。赤の「… がありません」の行は、リグにそのプロパティが無いという事です。'),
            ],
            'usage': [
                _t('Drag a slider (0 to 1). Turn Auto Keying on, or key it with I over the slider.', 'スライダーを動かします（0〜1）。自動キーをオンにするか、スライダーの上で I を押してキーを打ちます。'),
                _t('The grey row c_jawbone.x ["lips_retain"] is driven: enter the hand value in lips_retain above, not there.', '灰色の行 c_jawbone.x ["lips_retain"] はドライバー付きです。手の値は、そこではなく上の lips_retain で入れます。'),
            ],
            'settings': [
                (_t('lips_retain', 'lips_retain'), _t('Keeps the lips together while the jaw opens.', '顎が開く時に唇を合わせたままにします。')),
                (_t('aux_mouthFunnel / aux_mouthPressLeft / aux_mouthPressRight', 'aux_mouthFunnel・aux_mouthPressLeft・aux_mouthPressRight'), _t('Extra strength for those mouth shapes. Start at 0.2 to 0.5.', 'その口の形の強さの足し。0.2〜0.5 から試します。')),
                (_t('aux_mouthPucker', 'aux_mouthPucker'), _t('No effect on this rig: its helper key is empty (the panel says so in red). The ARKit mouthPucker itself still works.', 'このリグでは効きません。補助のキーが空です（パネルに赤で出ます）。ARKit の mouthPucker そのものは効きます。')),
            ],
            'check': [
                _t('The mouth shape changes in the viewport.', 'ビューポートの口の形が変わります。'),
            ],
            'notes': [
                _t('Ctrl+Z undoes. Do not put the same fix in both a helper value and the expression slider.', 'Ctrl+Z で戻せます。同じ直しを補助の値と表情のスライダーの両方に入れないでください。'),
            ],
        },
        # ------------------------------------------------------------------------------------------ clean-up
        'ark_curves': {
            'title': _t('Clean-up after Baking Help', '手直しの補助 ヘルプ'),
            'overview': [
                _t('Blender\'s own key clean-up tools gathered in one place for the baked face keys: smooth, blend, ease and decimate keys in the Graph Editor, and relax / push poses at the current frame.', '焼いた顔のキーの手直し用に、Blender の道具を 1 か所に集めました。グラフエディターのキーのなだらか・寄せ・イーズ・間引きと、今のフレームの姿勢のほぐし・強めです。'),
            ],
            'prep': [
                _t('Save a backup first. Graph Editor buttons: open a Graph Editor and select only the face keys (do not include body keys). Pose buttons: Pose Mode with the face bones selected.', '先に控えを保存します。グラフエディターのボタン：グラフエディターを開き、顔のキーだけを選びます（体のキーを一緒に選ばない）。ポーズのボタン：ポーズモードで顔の骨を選びます。'),
            ],
            'usage': [
                _t('Set Clean-up Strength (and Allowed error for decimation).', '「強さ」（間引きでは「許す誤差」も）を決めます。'),
                _t('Press a Graph Editor button for the selected keys, or a Pose button for the current frame.', '選んだキーにはグラフエディターのボタン、今のフレームにはポーズのボタンを押します。'),
                _t('Read the report (decimation reports the difference to the original).', '報告を読みます（間引きは元との差を報告します）。'),
            ],
            'functions': [
                (_t('Smooth (Gaussian) / Smooth (Butterworth)', 'なだらか（ガウス）・なだらか（バターワース）'), _t('Smooth the selected keys; Butterworth removes fine jitter by frequency.', '選んだキーをなだらかにします。バターワースは細かい揺れを周波数で落とします。')),
                (_t('Blend Keys to Neighbor / Ease Keys / Blend Keys Offset', '隣へ寄せる・イーズ・ずらして寄せる'), _t('Move the selected keys toward, between, or along the neighbouring keys.', '選んだキーを前後のキーへ寄せる・間をイーズで並べる・塊ごとずらして合わせます。')),
                (_t('Decimate Keys', 'キーを間引く'), _t('Removes keys within the allowed error.', '許す誤差の中でキーを間引きます。')),
                (_t('Relax Pose / Push Pose / Blend to Neighbor Pose', 'ほぐす・強める・隣のポーズへ寄せる'), _t('Change the current-frame pose of the selected bones relative to the nearest keys before and after it. Blend to Neighbor Pose: strength 0 keeps the pose, 1 takes the next key\'s pose.', '選んだ骨の今のフレームの姿勢を、直前と直後のキーに対して変えます。隣のポーズへ寄せる：強さ 0 で今のまま、1 で次のキーの姿勢になります。')),
            ],
            'settings': [
                (_t('Clean-up Strength', '強さ'), _t('0 to 1, default 0.5. Start low (0.2 to 0.5) and repeat rather than one strong pass.', '0〜1、既定 0.5。弱め（0.2〜0.5）から始め、強く 1 回より弱く数回にします。')),
                (_t('Allowed error', '許す誤差'), _t('Decimation tolerance, default 0.001. Larger removes more keys and changes the motion more.', '間引きの許す差、既定 0.001。大きいほど多く間引き、動きも変わります。')),
            ],
            'check': [
                _t('Play back and compare with the backup; look at the curves in the Graph Editor.', '再生して控えと比べます。グラフエディターで曲線を見ます。'),
            ],
            'notes': [
                _t('Ctrl+Z undoes each press. A button is greyed when its editor or mode is not available.', '押すたびに Ctrl+Z で戻せます。その画面やモードが無い時は、ボタンが灰色になります。'),
                _t('This sub-group starts collapsed.', 'この小グループは、最初は折りたたまれています。'),
            ],
        },
        # ------------------------------------------------------------------------------------------ external Actions
        'ark_archive': {
            'title': _t('External Actions (archive) Help', '外部 Action（保管庫） ヘルプ'),
            'overview': [
                _t('Brings back, one at a time, an Action that the model moved out to an archive .blend (recordings, face captures, clip variants), and puts the originals back with one button. The model\'s Action catalog (JSON) says which library holds which Action.',
                   'モデルから保管庫の .blend へ移した Action（収録・顔のキャプチャー・クリップの候補など）を 1 つずつ呼び戻し、ボタン 1 つで元へ戻します。どの Action がどのライブラリにあるかは、モデルの Action カタログ（JSON）に書かれています。'),
                _t('This replaces the old clip-switch Texts: a selector script that runs a Text the catalog lists as using those Actions is refused, because its Actions are no longer in the file.',
                   '古いクリップ切り替えの Text の代わりです。カタログに「その Action を使う」と書かれた Text を動かすセレクターの台本は、その Action がもうファイルに無いので、実行しません。'),
            ],
            'prep': [
                _t('Save a copy of the model under a new name first.', '先にモデルの写しを別名で保存します。'),
                _t('Keep the catalog JSON and the archive .blend files in the folder layout the catalog describes (paths are relative to the catalog).',
                   'カタログの JSON と保管庫の .blend は、カタログに書かれたフォルダーの形のまま置きます（パスはカタログからの相対です）。'),
            ],
            'usage': [
                _t('Choose the catalog JSON in "Catalog". The line below shows how many archived Actions and libraries it lists.',
                   '「カタログ」でカタログの JSON を選びます。下の行に、保管庫の Action とライブラリの数が出ます。'),
                _t('Narrow the list with "Library" (one recording or the face captures) and the filter field.', '「ライブラリ」（収録 1 本や顔のキャプチャー）と絞り込みの欄で一覧を絞ります。'),
                _t('Choose where it goes: "By slot name" (the objects / shape keys the Action was made for) or "Active object".',
                   '割り当て先を選びます：「スロットの名前の相手」（その Action を作った時のオブジェクト・シェイプキー）か「アクティブなオブジェクト」。'),
                _t('Press an Action name. It is linked (not copied) from its library and assigned. Press another name to switch again.',
                   'Action の名前を押します。ライブラリから（写さずに）リンクして割り当てます。別の名前を押せば、また切り替わります。'),
                _t('Press "Restore originals" to put back the Actions, slots and values from before the first switch.', '「元に戻す」で、最初の切り替えの前の Action・スロット・値に戻します。'),
            ],
            'settings': [
                (_t('Catalog', 'カタログ'), _t('The model\'s Action catalog JSON. Saved with the scene.', 'モデルの Action カタログの JSON。シーンと一緒に保存されます。')),
                (_t('Library', 'ライブラリ'), _t('Show the Actions of one archive library. Click the field for the library names of the catalog; leave it empty for all libraries. Choosing another catalog empties it, and a name the catalog does not list shows all.',
                                                    '1 本の保管庫のライブラリの Action を出します。欄を押すとカタログのライブラリの名前が出ます。空欄なら全部のライブラリです。別のカタログを選ぶと空欄に戻り、カタログにない名前なら全部を出します。')),
                (_t('By slot name / Active object', 'スロットの名前の相手・アクティブなオブジェクト'), _t('Recommended: By slot name. Active object is for a single-slot Action on another character copy.', 'おすすめは「スロットの名前の相手」。「アクティブなオブジェクト」は、スロットが 1 つの Action を別の写しに当てる時に使います。')),
            ],
            'check': [
                _t('The line under the list shows the Action and the objects it went to. Play back to see it.', '一覧の下の行に、Action と割り当てた相手が出ます。再生して確かめます。'),
                _t('After "Restore originals" the count returns to 0 and the original Action plays again.', '「元に戻す」の後は数が 0 に戻り、元の Action が再生されます。'),
            ],
            'notes': [
                _t('Safety: only a library the catalog lists, by a path inside the catalog folder, with exactly the catalog\'s size and SHA-256, is opened. Anything else is refused with the reason in red.',
                   '安全のため、カタログに書かれ、カタログのフォルダーの中のパスで、大きさと SHA-256 がカタログと完全に一致するライブラリだけを開きます。それ以外は、理由を赤で出して断ります。'),
                _t('An Action whose name already exists in the file (not from the same library) is refused, never renamed or replaced.', '同じ名前の Action が（同じライブラリからでなく）既にファイルにあると断ります。名前を変えたり置き換えたりはしません。'),
                _t('Refused before any change: linked / overridden targets and objects in NLA tweak mode. "Restore originals" also refuses while a target is in NLA tweak mode: finish the edit and press it again. If assigning fails half way, everything of that press is put back.', '変える前に断る物：リンク・オーバーライドの相手、NLA の編集中のオブジェクト。「元に戻す」も、相手が NLA の編集中なら断るので、編集を終えてからもう一度押します。割り当てが途中で失敗したら、その 1 回の分を全部戻します。'),
                _t('Ctrl+Z undoes each press. No Text inside the file is run and nothing is loaded in bulk.', '押すたびに Ctrl+Z で戻せます。ファイルの中の Text は実行せず、まとめて読み込む事もしません。'),
                _t('This sub-group starts collapsed.', 'この小グループは、最初は折りたたまれています。'),
            ],
        },
    }
