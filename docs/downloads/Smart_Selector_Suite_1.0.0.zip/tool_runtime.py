# SPDX-License-Identifier: GPL-3.0-or-later
"""Load Selector tool families and keep their lazy activation through refresh."""
from contextlib import suppress

import bpy

from . import loader, ui_runtime

_registered = False
_resume_aliases = ()


def is_registered():
    return _registered


def _loaded_aliases():
    aliases = []
    for record in loader.get_records():
        with suppress(AttributeError, TypeError):
            if record.get("status") == "loaded":
                alias = str((record.get("spec") or {}).get("alias") or "").strip()
                if alias:
                    aliases.append(alias)
    return tuple(aliases)


def _invalidate():
    with suppress(Exception):
        ui_runtime.mark_record_cache_dirty()


def _mount(aliases):
    loader.register_all()
    _invalidate()
    for alias in aliases:
        with suppress(Exception):
            loader.ensure_record_loaded(alias)
    ui_runtime.register()


def _unmount():
    ui_runtime.unregister()
    loader.unregister_all()
    _invalidate()


def register():
    global _registered, _resume_aliases
    if not _registered:
        _mount(_resume_aliases)
        _resume_aliases = ()
        _registered = True


def unregister():
    global _registered, _resume_aliases
    if _registered:
        _resume_aliases = _loaded_aliases()
        _unmount()
        _registered = False


def rebuild_if_registered(context=None):
    if _registered:
        aliases = _loaded_aliases()
        _unmount()
        _mount(aliases)
        _invalidate()
        with suppress(Exception):
            ui_runtime.refresh_all_suites(context or bpy.context)
