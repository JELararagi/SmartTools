# SPDX-License-Identifier: GPL-3.0-or-later
"""Selector's package location and import-cache boundary."""
from importlib import invalidate_caches
from pathlib import Path


def package_root(file):
    if file is None:
        return None
    try:
        return Path(file).resolve().parent
    except (OSError, RuntimeError, TypeError, ValueError):
        return None


def _normalized_ids(package, name, file):
    package_id, name_id = (str(value or "").strip().strip(".") for value in (package, name))
    identifiers = list(dict.fromkeys(value for value in (package_id, name_id) if value))
    last = identifiers[-1] if identifiers else ""
    parent = (last if "." in last else name_id).rpartition(".")[0]
    root = package_root(file) if file else None
    for value in (parent, root.name if root else ""):
        if value and value not in identifiers:
            identifiers.append(value)
    return tuple(identifiers)


def preflight_cleanup(package=None, name=None, file=None):
    """Refresh import discovery without mutating the installation."""
    invalidate_caches()


def get_addon_preferences(context=None, package=None, name=None, file=None):
    """Settings belong to the Selector N-panel."""
    return None
