# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import importlib
import shutil
from pathlib import Path

import bpy


_PREFLIGHT_CLEANED_ROOTS: set[str] = set()


def _normalized_ids(package: str | None, name: str | None, file: str | None) -> tuple[str, ...]:
    values: list[str] = []

    def _push(value: object) -> None:
        text = str(value or '').strip().strip('.')
        if not text:
            return
        if text not in values:
            values.append(text)

    _push(package)
    _push(name)
    if values and '.' in values[-1]:
        _push(values[-1].rsplit('.', 1)[0])
    else:
        text = str(name or '').strip().strip('.')
        if '.' in text:
            _push(text.rsplit('.', 1)[0])
    try:
        if file:
            _push(Path(file).resolve().parent.name)
    except Exception:
        pass
    return tuple(values)


def package_root(file: str | None) -> Path | None:
    try:
        return Path(file).resolve().parent
    except Exception:
        return None


def preflight_cleanup(package: str | None = None, name: str | None = None, file: str | None = None) -> None:
    del package, name
    importlib.invalidate_caches()

    root = package_root(file)
    if root is None or not root.exists():
        return

    try:
        root_key = str(root.resolve())
    except Exception:
        root_key = str(root)
    if root_key in _PREFLIGHT_CLEANED_ROOTS:
        return
    _PREFLIGHT_CLEANED_ROOTS.add(root_key)

    # Keep validated runtime bytecode caches.  Python invalidates stale cache
    # entries automatically; recursively deleting them here caused every
    # Blender restart to recompile the whole suite.  Distribution archives are
    # cleaned separately and never contain __pycache__ or *.pyc.
    return


def get_addon_preferences(context=None, package: str | None = None, name: str | None = None, file: str | None = None):
    # Smart Selector intentionally does not expose editable Add-on
    # Preferences. Settings are stored through CONFIG/Smart_Selector_Suite.
    del context, package, name, file
    return None
