# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

"""Generation-aware ownership for every bundled modal class.

The wrappers are attached to exact class objects before Blender registration.
No process-global Blender API is replaced.  Operator and Gizmo modal signatures
are both supported.  Exception, Esc/right-click, explicit cancel, lazy-tool
unload and Suite reload all pass through the same idempotent cleanup path.
"""

from dataclasses import dataclass, field
from typing import Any, Callable
from types import MemberDescriptorType

import bpy

from . import smart_tools_manager_compat as manager_compat

_ACTIVE: dict[int, "ModalRecord"] = {}
_INSTRUMENTED: dict[type, dict[str, Any]] = {}
_MAX_ACTIVE = 128
_MAX_RESOURCES_PER_MODAL = 256

_TERMINAL_RESULTS = {"FINISHED", "CANCELLED"}
_CONTINUING_RESULTS = {"RUNNING_MODAL", "PASS_THROUGH", "INTERFACE"}
_CANCEL_EVENTS = {"ESC", "RIGHTMOUSE"}
_CANCEL_REASONS = {
    "invoke_exception", "modal_exception", "escape_cancel", "cancel",
    "generation_release", "registry_bound", "unload", "reload",
}
_WORKSPACE_RUNTIME_MODAL_PACKAGES = frozenset({"sakura_poselib", "storytools"})


@dataclass(slots=True)
class ModalResource:
    kind: str
    label: str
    remover: Callable[[], None]
    active: bool = True

    def release(self) -> None:
        if not self.active:
            return
        result = self.remover()
        if result is False:
            raise RuntimeError(f'modal remover returned False: {self.kind}:{self.label}')
        self.active = False


@dataclass(slots=True)
class ModalRecord:
    instance: Any
    generation: int
    context: Any = None
    owner_module: str = ""
    workspace_runtime_suppressed: bool = False
    workspace_runtime_header_released: bool = False
    workspace_runtime_area_pointer: int = 0
    resources: list[ModalResource] = field(default_factory=list)
    snapshot: dict[str, Any] = field(default_factory=dict)
    cleaned: bool = False
    cleaning: bool = False


def _result_set(value: Any) -> set[str]:
    try:
        return {str(item) for item in value}
    except Exception:
        return set()


def _is_modal_class(cls: type) -> bool:
    if not isinstance(cls, type) or not callable(vars(cls).get("modal")):
        return False
    bases = (getattr(bpy.types, "Operator", object), getattr(bpy.types, "Gizmo", object))
    try:
        return any(base is not object and issubclass(cls, base) for base in bases)
    except Exception:
        return False


def _event_from_args(args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
    event = kwargs.get("event")
    if event is not None:
        return event
    # Bound wrapper receives context as args[0], event as args[1].  Gizmo modal
    # can have a third ``tweak`` argument; it does not change event location.
    return args[1] if len(args) >= 2 else None


def _context_from_args(args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
    return kwargs.get("context") or (args[0] if args else None)


def _workspace_runtime_modal_owner(cls: type) -> bool:
    module_parts = frozenset(str(getattr(cls, "__module__", "") or "").split("."))
    return bool(module_parts.intersection(_WORKSPACE_RUNTIME_MODAL_PACKAGES))


def _context_area_pointer(context: Any) -> int:
    area = getattr(context, "area", None)
    if area is None:
        return 0
    try:
        return int(area.as_pointer())
    except Exception:
        return id(area)


def _workspace_runtime_modal_allowed(context: Any) -> bool:
    return manager_compat.workspace_runtime_allows_context(context)


def _suppress_workspace_modal_runtime(record: ModalRecord | None, context: Any) -> None:
    """Release visible/input affordances while retaining modal resources."""
    if record is None:
        return
    if not record.workspace_runtime_suppressed:
        record.workspace_runtime_suppressed = True
        window = getattr(context, "window", None)
        try:
            window.cursor_set("DEFAULT")
        except Exception:
            pass
    if record.workspace_runtime_header_released:
        return
    area = getattr(context, "area", None)
    if _context_area_pointer(context) != record.workspace_runtime_area_pointer:
        return
    # The first OFF event can arrive in another workspace/area. Keep this
    # release pending until the retained modal receives an event in its own
    # live area, then perform it at most once for the current OFF period.
    record.workspace_runtime_header_released = True
    try:
        area.header_text_set(None)
    except Exception:
        pass
    try:
        area.tag_redraw()
    except Exception:
        pass


def _capture_snapshot(context: Any) -> dict[str, Any]:
    """Capture only exact references/scalars needed to rollback a cancelled modal."""
    snap: dict[str, Any] = {}
    if context is None:
        return snap
    try:
        snap["mode"] = str(getattr(context, "mode", "") or "")
    except Exception:
        pass
    try:
        view_layer = getattr(context, "view_layer", None)
        snap["active_object"] = getattr(getattr(view_layer, "objects", None), "active", None)
    except Exception:
        pass
    try:
        snap["selected_objects"] = tuple(getattr(context, "selected_objects", ()) or ())[:4096]
    except Exception:
        snap["selected_objects"] = ()
    try:
        scene = getattr(context, "scene", None)
        snap["frame_current"] = int(getattr(scene, "frame_current", 0))
        cursor = getattr(scene, "cursor", None)
        if cursor is not None:
            snap["cursor_location"] = tuple(float(v) for v in cursor.location)
            snap["cursor_rotation_mode"] = str(getattr(cursor, "rotation_mode", "") or "")
            if snap["cursor_rotation_mode"] == "QUATERNION":
                snap["cursor_rotation"] = tuple(float(v) for v in cursor.rotation_quaternion)
            else:
                snap["cursor_rotation"] = tuple(float(v) for v in cursor.rotation_euler)
    except Exception:
        pass
    return snap


def _record(instance: Any, *, context: Any = None, generation: int = 0) -> ModalRecord:
    key = id(instance)
    record = _ACTIVE.get(key)
    if record is None or record.instance is not instance:
        if len(_ACTIVE) >= _MAX_ACTIVE:
            oldest_key = next(iter(_ACTIVE), None)
            if oldest_key is not None:
                cleanup_instance(_ACTIVE[oldest_key].instance, reason="registry_bound")
        record = ModalRecord(
            instance=instance,
            generation=int(generation or 0),
            context=context,
            owner_module=str(getattr(instance.__class__, "__module__", "") or ""),
            workspace_runtime_area_pointer=_context_area_pointer(context),
            snapshot=_capture_snapshot(context),
        )
        _ACTIVE[key] = record
    elif context is not None:
        record.context = context
        record.workspace_runtime_area_pointer = _context_area_pointer(context)
    return record


def register_resource(instance: Any, *, kind: str, remover: Callable[[], None], label: str = "") -> bool:
    if instance is None or not callable(remover):
        return False
    record = _record(instance)
    if len(record.resources) >= _MAX_RESOURCES_PER_MODAL:
        return False
    record.resources.append(ModalResource(str(kind or "resource"), str(label or kind or "resource"), remover))
    return True


def register_event_timer(instance: Any, window_manager: Any, timer: Any, *, label: str = "") -> Any:
    if timer is None:
        return None
    register_resource(
        instance, kind="event_timer", label=label or "event timer",
        remover=lambda wm=window_manager, value=timer: wm.event_timer_remove(value),
    )
    return timer


def register_draw_handler(instance: Any, space_type: Any, handle: Any, region_type: str, *, label: str = "") -> Any:
    if handle is None:
        return None
    register_resource(
        instance, kind="draw_handler", label=label or "draw handler",
        remover=lambda owner=space_type, value=handle, region=region_type: owner.draw_handler_remove(value, region),
    )
    return handle


def register_offscreen(instance: Any, offscreen: Any, *, label: str = "") -> Any:
    if offscreen is None:
        return None
    register_resource(
        instance, kind="offscreen", label=label or "GPU offscreen",
        remover=lambda value=offscreen: value.free(),
    )
    return offscreen


def _safe_call(method: Any, *args: Any) -> None:
    if not callable(method):
        return
    try:
        method(*args)
    except TypeError:
        try:
            method()
        except Exception:
            pass
    except Exception:
        pass


def _restore_snapshot(record: ModalRecord, context: Any) -> None:
    snap = record.snapshot
    if not snap or context is None:
        return
    try:
        scene = getattr(context, "scene", None)
        if scene is not None and "frame_current" in snap:
            scene.frame_set(int(snap["frame_current"]))
    except Exception:
        pass
    try:
        scene = getattr(context, "scene", None)
        cursor = getattr(scene, "cursor", None)
        if cursor is not None and "cursor_location" in snap:
            cursor.location = snap["cursor_location"]
            mode = snap.get("cursor_rotation_mode")
            if mode:
                cursor.rotation_mode = mode
            rotation = snap.get("cursor_rotation")
            if rotation is not None:
                if mode == "QUATERNION":
                    cursor.rotation_quaternion = rotation
                else:
                    cursor.rotation_euler = rotation
    except Exception:
        pass
    try:
        selected = tuple(snap.get("selected_objects", ()) or ())
        view_layer = getattr(context, "view_layer", None)
        objects = tuple(getattr(getattr(view_layer, "objects", None), "__iter__", lambda: ())())
        for obj in objects:
            try:
                obj.select_set(any(obj is item for item in selected))
            except Exception:
                pass
        active = snap.get("active_object")
        if view_layer is not None and active is not None:
            view_layer.objects.active = active
    except Exception:
        pass
    # Restore mode last, after exact active-object/selection restoration.
    try:
        wanted = str(snap.get("mode") or "")
        current = str(getattr(context, "mode", "") or "")
        active = snap.get("active_object")
        if wanted and wanted != current and active is not None:
            mode_map = {
                "EDIT_MESH": "EDIT", "EDIT_CURVE": "EDIT", "EDIT_SURFACE": "EDIT",
                "EDIT_ARMATURE": "EDIT", "EDIT_TEXT": "EDIT", "POSE": "POSE",
                "SCULPT": "SCULPT", "PAINT_WEIGHT": "WEIGHT_PAINT",
                "PAINT_VERTEX": "VERTEX_PAINT", "PAINT_TEXTURE": "TEXTURE_PAINT",
                "OBJECT": "OBJECT",
            }
            target = mode_map.get(wanted)
            if target:
                bpy.ops.object.mode_set(mode=target)
    except Exception:
        pass


def _instance_owned_attributes(instance: Any) -> tuple:
    attributes = dict(getattr(instance, "__dict__", {}))
    for owner in type(instance).__mro__:
        for name, descriptor in vars(owner).items():
            if not isinstance(descriptor, MemberDescriptorType) or name in attributes:
                continue
            try:
                attributes[name] = descriptor.__get__(instance, type(instance))
            except AttributeError:
                continue
    return tuple(attributes.items())


def _release_common_attributes(instance: Any, context: Any, *, restore_state: bool) -> None:
    wm = getattr(context, "window_manager", None) if context is not None else None
    window = getattr(context, "window", None) if context is not None else None
    area = getattr(context, "area", None) if context is not None else None
    workspace = getattr(context, "workspace", None) if context is not None else None

    for name in (
        "_sas_modal_cleanup", "_modal_cleanup", "_cleanup_modal", "_cleanup",
        "cleanup", "_remove_handlers", "_remove_draw_handler", "remove_draw_handler",
    ):
        _safe_call(getattr(instance, name, None), context)
    if restore_state:
        for name in ("_restore_context", "_restore_state", "restore_state", "exit_modal"):
            _safe_call(getattr(instance, name, None), context)

    if wm is not None:
        for name, value in _instance_owned_attributes(instance):
            if value is None or "timer" not in str(name).lower():
                continue
            try:
                wm.event_timer_remove(value)
                setattr(instance, name, None)
            except Exception:
                pass
    for name, value in _instance_owned_attributes(instance):
        lower = str(name).lower()
        if value is None:
            continue
        if "offscreen" in lower or lower.endswith("_gpu_buffer"):
            try:
                free = getattr(value, "free", None)
                if callable(free):
                    free()
                setattr(instance, name, None)
            except Exception:
                pass
    try:
        if window is not None and callable(getattr(window, "cursor_modal_restore", None)):
            window.cursor_modal_restore()
    except Exception:
        pass
    try:
        if area is not None and callable(getattr(area, "header_text_set", None)):
            area.header_text_set(None)
    except Exception:
        pass
    try:
        if workspace is not None and callable(getattr(workspace, "status_text_set", None)):
            workspace.status_text_set(None)
    except Exception:
        pass



def _draw_space_candidates(context: Any) -> tuple[Any, ...]:
    names = []
    area_type = str(getattr(getattr(context, "area", None), "type", "") or "")
    area_map = {
        "VIEW_3D": "SpaceView3D", "DOPESHEET_EDITOR": "SpaceDopeSheetEditor",
        "GRAPH_EDITOR": "SpaceGraphEditor", "IMAGE_EDITOR": "SpaceImageEditor",
        "NODE_EDITOR": "SpaceNodeEditor", "SEQUENCE_EDITOR": "SpaceSequenceEditor",
        "CLIP_EDITOR": "SpaceClipEditor", "NLA_EDITOR": "SpaceNLA",
        "TEXT_EDITOR": "SpaceTextEditor", "FILE_BROWSER": "SpaceFileBrowser",
        "SPREADSHEET": "SpaceSpreadsheet", "INFO": "SpaceInfo",
    }
    preferred = area_map.get(area_type)
    if preferred:
        names.append(preferred)
    names.extend((
        "SpaceView3D", "SpaceDopeSheetEditor", "SpaceGraphEditor",
        "SpaceImageEditor", "SpaceNodeEditor", "SpaceSequenceEditor",
        "SpaceClipEditor", "SpaceNLA", "SpaceTextEditor", "SpaceInfo",
    ))
    result = []
    seen = set()
    for name in names:
        value = getattr(bpy.types, name, None)
        if value is not None and id(value) not in seen:
            seen.add(id(value))
            result.append(value)
    return tuple(result)


def _remove_draw_handle_exact(handle: Any, context: Any) -> None:
    # Blender draw handles are opaque and expose no owning Space class. Try only
    # the fixed compatible Space types; the correct owner accepts the exact
    # handle, all others raise without changing foreign resources.
    for space_type in _draw_space_candidates(context):
        for region in ("WINDOW", "HEADER"):
            try:
                space_type.draw_handler_remove(handle, region)
                return
            except Exception:
                continue


def _looks_like_draw_handle_name(name: str) -> bool:
    text = str(name or "").lower()
    return (
        text.endswith("handle") or text.endswith("_handle")
        or "draw_handle" in text or text in {
            "_text_handle", "_line_handle", "_grid_handle", "_pip_handle",
            "_pos_handle", "_guide_handle", "draw_handle_2d", "draw_handle_3d",
        }
    )


def _adopt_instance_resources(record: ModalRecord, context: Any) -> None:
    """Adopt finite instance-owned modal resources immediately after callbacks."""
    instance = record.instance
    existing = {(item.kind, item.label) for item in record.resources if item.active}
    try:
        values = _instance_owned_attributes(instance)[:512]
    except Exception:
        values = ()
    wm = getattr(context, "window_manager", None) if context is not None else None
    for name, value in values:
        if len(record.resources) >= _MAX_RESOURCES_PER_MODAL:
            break
        if value is None:
            continue
        label = str(name or "")[:128]
        lower = label.lower()
        if "timer" in lower and wm is not None:
            item_label = f"{label}:{id(value):x}"
            marker = ("event_timer", item_label)
            if marker not in existing:
                record.resources.append(ModalResource(
                    "event_timer", item_label,
                    lambda _wm=wm, _value=value: _wm.event_timer_remove(_value),
                ))
                existing.add(marker)
            continue
        if _looks_like_draw_handle_name(label):
            handles = value if isinstance(value, (tuple, list)) else (value,)
            for index, handle in enumerate(tuple(handles)[:64]):
                if handle is None or len(record.resources) >= _MAX_RESOURCES_PER_MODAL:
                    break
                base_label = f"{label}[{index}]" if isinstance(value, (tuple, list)) else label
                item_label = f"{base_label}:{id(handle):x}"
                marker = ("draw_handler", item_label)
                if marker in existing:
                    continue
                record.resources.append(ModalResource(
                    "draw_handler", item_label,
                    lambda _handle=handle, _context=context: _remove_draw_handle_exact(_handle, _context),
                ))
                existing.add(marker)
        if "offscreen" in lower or lower.endswith("_gpu_buffer"):
            item_label = f"{label}:{id(value):x}"
            marker = ("offscreen", item_label)
            if marker not in existing and callable(getattr(value, "free", None)):
                record.resources.append(ModalResource(
                    "offscreen", item_label, lambda _value=value: _value.free(),
                ))
                existing.add(marker)


def _call_original_cancel(instance: Any, original: Any, context: Any) -> None:
    if not callable(original):
        return
    try:
        original(instance, context)
    except TypeError:
        try:
            original(instance)
        except Exception:
            pass
    except Exception:
        pass

def _invalidate_animation_cache(context=None) -> None:
    try:
        from . import ui
        ui.invalidate_performance_cache(reason="modal_finished", context=context)
    except Exception:
        pass


def cleanup_instance(instance: Any, *, context: Any = None, reason: str = "") -> bool:
    if instance is None:
        return False
    key = id(instance)
    record = _ACTIVE.get(key)
    restore = str(reason or "") in _CANCEL_REASONS
    if record is not None and record.instance is instance:
        if record.cleaned:
            _ACTIVE.pop(key, None)
            return True
        if record.cleaning:
            return False
        record.cleaning = True
        context = context or record.context
        # Two finite reverse passes handle Blender teardown dependencies without
        # polling, broad scans, or abandoning the exact resource identity.
        for _pass_index in range(2):
            for resource in reversed(record.resources):
                if not resource.active:
                    continue
                try:
                    resource.release()
                except Exception:
                    pass
            if not any(item.active for item in record.resources):
                break
        if restore:
            _restore_snapshot(record, context)
    _release_common_attributes(instance, context, restore_state=restore)
    if record is not None and record.instance is instance:
        complete = not any(item.active for item in record.resources)
        record.cleaning = False
        record.cleaned = complete
        if not complete:
            return False
    _ACTIVE.pop(key, None)
    try:
        setattr(instance, "_sas_modal_registry_cleaned", True)
    except Exception:
        pass
    return True


def active_count(*, generation: int | None = None, owner_prefix: str = "") -> int:
    prefix = str(owner_prefix or "")
    return sum(
        1 for record in _ACTIVE.values()
        if (generation is None or record.generation == int(generation))
        and (not prefix or record.owner_module == prefix or record.owner_module.startswith(prefix + "."))
    )


def cancel_all_active(*, generation: int | None = None, context: Any = None, owner_prefix: str = "") -> int:
    cancelled = 0
    prefix = str(owner_prefix or "")
    for record in tuple(_ACTIVE.values()):
        if generation is not None and record.generation != int(generation):
            continue
        if prefix and not (record.owner_module == prefix or record.owner_module.startswith(prefix + ".")):
            continue
        instance = record.instance
        ctx = context or record.context or getattr(bpy, "context", None)
        original = getattr(instance.__class__, "_sas_modal_original_cancel", None)
        try:
            if callable(original):
                original(instance, ctx)
        except Exception:
            pass
        finally:
            cleanup_instance(instance, context=ctx, reason="generation_release")
        cancelled += 1
    return cancelled


def _restore_instrumented_class(cls: type, metadata: dict[str, Any]) -> None:
    originals = dict(metadata.get("originals") or {})
    wrappers = dict(metadata.get("wrappers") or {})
    for name in ("invoke", "modal", "cancel", "exit"):
        wrapper = wrappers.get(name)
        if wrapper is None or vars(cls).get(name) is not wrapper:
            continue
        original = originals.get(name)
        try:
            if callable(original):
                setattr(cls, name, original)
            else:
                delattr(cls, name)
        except Exception:
            pass
    token = metadata.get("token")
    try:
        if vars(cls).get("_sas_modal_registry_token") is token:
            delattr(cls, "_sas_modal_registry_token")
    except Exception:
        pass
    try:
        stored = vars(cls).get("_sas_modal_original_cancel", object())
        if stored is originals.get("cancel"):
            delattr(cls, "_sas_modal_original_cancel")
    except Exception:
        pass


def instrument_operator_class(cls: type, *, generation: int = 0) -> type:
    """Instrument an exact Operator/Gizmo class before Blender registration."""
    if not _is_modal_class(cls):
        return cls
    existing = _INSTRUMENTED.get(cls)
    if existing is not None:
        if int(existing.get("generation", 0) or 0) == int(generation or 0):
            return cls
        _restore_instrumented_class(cls, existing)
        _INSTRUMENTED.pop(cls, None)

    token = object()
    originals: dict[str, Callable[..., Any]] = {}
    wrappers: dict[str, Callable[..., Any]] = {}
    for name in ("invoke", "modal", "cancel", "exit"):
        value = vars(cls).get(name)
        if callable(value):
            originals[name] = value
    original_invoke = originals.get("invoke")
    original_modal = originals["modal"]
    original_cancel = originals.get("cancel")
    original_exit = originals.get("exit")
    workspace_runtime_owner = _workspace_runtime_modal_owner(cls)
    gizmo_type = getattr(bpy.types, "Gizmo", None)
    try:
        is_gizmo = isinstance(gizmo_type, type) and issubclass(cls, gizmo_type)
    except Exception:
        is_gizmo = False

    if original_invoke is not None:
        def invoke(self, context, event):
            if workspace_runtime_owner and not _workspace_runtime_modal_allowed(context):
                return {"PASS_THROUGH"}
            record = _record(self, context=context, generation=generation)
            record.workspace_runtime_suppressed = False
            record.workspace_runtime_header_released = False
            try:
                result = original_invoke(self, context, event)
                _adopt_instance_resources(record, context)
            except Exception:
                _adopt_instance_resources(record, context)
                _call_original_cancel(self, original_cancel, context)
                cleanup_instance(self, context=context, reason="invoke_exception")
                return {"CANCELLED"}
            values = _result_set(result)
            if "RUNNING_MODAL" not in values and values & _TERMINAL_RESULTS:
                cleanup_instance(self, context=context, reason="invoke_terminal")
            return result
        invoke.__name__ = getattr(original_invoke, "__name__", "invoke")
        invoke.__doc__ = getattr(original_invoke, "__doc__", None)
        setattr(invoke, "_sas_modal_wrapper_token", token)
        setattr(cls, "invoke", invoke)
        wrappers["invoke"] = invoke

    def _run_modal(self, context, event, original_args):
        active_record = _ACTIVE.get(id(self))
        if active_record is not None and active_record.instance is not self:
            active_record = None
        if workspace_runtime_owner and not _workspace_runtime_modal_allowed(context):
            # Keep the modal instance/resources available for an ON workspace,
            # but let Blender and other handlers receive events while this one
            # is inactive.  No Suite feature work or registry mutation occurs.
            _suppress_workspace_modal_runtime(active_record, context)
            return {"PASS_THROUGH"}
        if active_record is not None:
            active_record.workspace_runtime_suppressed = False
            active_record.workspace_runtime_header_released = False
        record = _record(self, context=context, generation=generation)
        try:
            result = original_modal(self, *original_args)
            _adopt_instance_resources(record, context)
        except Exception:
            _adopt_instance_resources(record, context)
            _call_original_cancel(self, original_cancel, context)
            cleanup_instance(self, context=context, reason="modal_exception")
            return {"CANCELLED"}
        values = _result_set(result)
        event_type = str(getattr(event, "type", "") or "").upper()
        if event_type in _CANCEL_EVENTS and "FINISHED" in values and not bool(getattr(self, "_sas_escape_commits", False)):
            _call_original_cancel(self, original_cancel, context)
            cleanup_instance(self, context=context, reason="escape_cancel")
            return {"CANCELLED"}
        if values & _TERMINAL_RESULTS and not values & _CONTINUING_RESULTS:
            reason = "cancel" if "CANCELLED" in values else "modal_terminal"
            cleanup_instance(self, context=context, reason=reason)
            if "FINISHED" in values:
                _invalidate_animation_cache(context)
        return result

    if is_gizmo:
        def modal(self, context, event, tweak):
            return _run_modal(self, context, event, (context, event, tweak))
    else:
        def modal(self, context, event):
            return _run_modal(self, context, event, (context, event))
    modal.__name__ = getattr(original_modal, "__name__", "modal")
    modal.__doc__ = getattr(original_modal, "__doc__", None)
    setattr(modal, "_sas_modal_wrapper_token", token)
    setattr(cls, "modal", modal)
    wrappers["modal"] = modal

    if is_gizmo:
        def exit(self, context, cancel):
            try:
                if callable(original_exit):
                    original_exit(self, context, cancel)
            except Exception:
                pass
            finally:
                cleanup_instance(
                    self, context=context,
                    reason="cancel" if bool(cancel) else "modal_terminal",
                )
            return None
        setattr(exit, "_sas_modal_wrapper_token", token)
        setattr(cls, "exit", exit)
        wrappers["exit"] = exit
    else:
        def cancel(self, context):
            try:
                if callable(original_cancel):
                    original_cancel(self, context)
            except Exception:
                pass
            finally:
                cleanup_instance(self, context=context, reason="cancel")
            return None
        setattr(cancel, "_sas_modal_wrapper_token", token)
        setattr(cls, "cancel", cancel)
        wrappers["cancel"] = cancel
    setattr(cls, "_sas_modal_original_cancel", original_cancel)
    setattr(cls, "_sas_modal_registry_token", token)
    _INSTRUMENTED[cls] = {
        "token": token, "generation": int(generation or 0),
        "originals": originals, "wrappers": wrappers,
    }
    return cls

def instrument_classes(classes: Any, *, generation: int = 0) -> tuple[type, ...]:
    return tuple(instrument_operator_class(cls, generation=generation) for cls in tuple(classes or ()))


def clear_instrumentation_metadata(*, generation: int | None = None) -> None:
    for cls, metadata in tuple(_INSTRUMENTED.items()):
        if generation is not None and int(metadata.get("generation", 0) or 0) != int(generation):
            continue
        _restore_instrumented_class(cls, metadata)
        _INSTRUMENTED.pop(cls, None)
