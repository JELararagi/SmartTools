# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

# Add-on Preferences are intentionally not registered or exposed.
# Smart Animation keeps all user-facing controls in the 3D View N-panel
# and stores generated settings under Blender CONFIG/Smart_Animation_Suite.

classes = ()

def register() -> None:
    return None

def unregister() -> None:
    return None
