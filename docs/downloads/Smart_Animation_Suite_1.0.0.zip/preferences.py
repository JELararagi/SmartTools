# SPDX-License-Identifier: GPL-3.0-or-later
"""Settings are exposed in the editor sidebar; this module owns no RNA."""

classes = ()


def register():
    """Compatibility entry point for integrations that import preferences."""


unregister = register
