# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Transactional lazy loader for the bundled Smart Animation tools.

The loader never replaces Blender process-global APIs, never unregisters a class
by looking up its name on ``bpy.types``, and never removes modules by a package
prefix.  Each tool is a child transaction of the active Suite generation. Every
acquired class, RNA property, handler, keymap item and module is recorded by
exact identity before the record can become ``READY``.
"""

from __future__ import annotations

import ast
import importlib
import platform
import sys
import types
from pathlib import Path
from typing import Any, Callable, Iterable

import bpy

from . import config_store, lifecycle, modal_registry, registry, runtime_persistence
from .panel_header_guard import harden_class_callbacks
from .translation import (
    normalize_class_ui_metadata,
    register_dynamic_ui_translations,
    sas_english_source_text,
)
from .undo_support import ensure_operator_undo

_RECORDS: list[dict[str, Any]] = []
_RECORDS_BY_ALIAS: dict[str, dict[str, Any]] = {}
_TOOL_LEDGERS: dict[str, lifecycle.GenerationLedger] = {}
_SUITE_LEDGER: lifecycle.GenerationLedger | None = None
_BACKGROUND_DIRTY = False
_BACKGROUND_LOADED = False
_MAX_ERROR_CHARS = 32768

# No Blender standard keymap is created, repaired, or removed automatically.
def prune_empty_keymaps(*, include_user_ui_fix: bool = False) -> None:
    del include_user_ui_fix
    return None


def _normalize_property_definition(prop_def: Any) -> None:
    try:
        keywords = getattr(prop_def, 'keywords', None)
    except Exception:
        keywords = None
    if keywords is None and isinstance(prop_def, tuple) and len(prop_def) >= 2 and isinstance(prop_def[1], dict):
        keywords = prop_def[1]
    if not isinstance(keywords, dict):
        return
    for key in ('name', 'description', 'text', 'placeholder'):
        if isinstance(keywords.get(key), str):
            keywords[key] = sas_english_source_text(keywords[key])
    items = keywords.get('items')
    if not isinstance(items, (tuple, list)):
        return
    normalized = []
    for item in items:
        if not isinstance(item, (tuple, list)):
            normalized.append(item)
            continue
        parts = list(item)
        for index in (1, 2):
            if len(parts) > index and isinstance(parts[index], str):
                parts[index] = sas_english_source_text(parts[index])
        normalized.append(tuple(parts) if isinstance(item, tuple) else parts)
    keywords['items'] = tuple(normalized) if isinstance(items, tuple) else normalized


def _prepare_class_for_localized_registration(cls: type, generation: int) -> type:
    try:
        normalize_class_ui_metadata(cls)
    except Exception:
        for attr in ('bl_label', 'bl_description', 'bl_category'):
            try:
                value = getattr(cls, attr, None)
                if isinstance(value, str):
                    setattr(cls, attr, sas_english_source_text(value))
            except Exception:
                pass
        for prop_def in (getattr(cls, '__annotations__', {}) or {}).values():
            _normalize_property_definition(prop_def)
    ensure_operator_undo(cls)
    harden_class_callbacks(cls)
    modal_registry.instrument_operator_class(cls, generation=generation)
    return cls


_NON_ALWAYS_ON_REPLACEMENTS = {'animall': ('attribute_migration_load_handler',),
 'transform_offset': ('transform_offset_hotkeys',),
 'bezier_curve_editor': ('editor_header_callbacks',),
 'simplify_curves_plus': ('curve_menu_entries',),
 'storytools': ('viewport_storyboard_header',
                'grease_pencil_overlay_options',
                'main_toolbar_gizmo',
                'tool_preset_gizmo_bar',
                'draw_tool_hotkeys',
                'locked_view_pan_hotkeys',
                'minimap_toolbar_gizmo'),
 'sakura_poselib': ('pose_library_hotkeys',)}

_BACKGROUND_OPTIONS = {'animall': ({'key': 'attribute_migration_load_handler',
              'label_en': 'Attribute Migration Load Handler',
              'label_ja': '属性移行ロードハンドラー',
              'description_en': 'Runs the AnimAll attribute migration callback after a file is loaded. Enable it only '
                                'for files that require legacy attribute migration.',
              'description_ja': 'ファイル読込後に AnimAll の旧属性移行コールバックを実行します。旧属性の移行が必要なファイルでのみ有効にしてください。',
              'module_path': '',
              'enable_fn': 'enable_attribute_migration_handler',
              'disable_fn': 'disable_attribute_migration_handler',
              'default': False},),
 'transform_offset': ({'key': 'transform_offset_hotkeys',
                       'label_en': 'Transform Offset Hotkeys',
                       'label_ja': 'トランスフォームオフセット・ホットキー',
                       'description_en': "Registers the Transform Offset shortcuts in Blender's add-on key "
                                         'configuration. Disabling removes every shortcut owned by this feature.',
                       'description_ja': 'トランスフォームオフセットのショートカットを Blender '
                                         'のアドオンキーマップへ登録します。無効にすると、この機能が所有するショートカットをすべて削除します。',
                       'module_path': '',
                       'enable_fn': 'enable_hotkeys',
                       'disable_fn': 'disable_hotkeys',
                       'default': False},),
 'bezier_curve_editor': ({'key': 'editor_header_callbacks',
                          'label_en': 'Bezier Editor Header Controls',
                          'label_ja': 'ベジェエディターヘッダー操作',
                          'description_en': 'Keeps Bezier Curve Editor controls injected into editor headers. Disable '
                                            'it to remove the header callbacks completely.',
                          'description_ja': 'ベジェカーブエディター操作をエディターヘッダーへ常設します。無効にするとヘッダーコールバックを完全に削除します。',
                          'module_path': 'main',
                          'enable_fn': 'enable_header_callbacks',
                          'disable_fn': 'disable_header_callbacks',
                          'default': False},),
 'simplify_curves_plus': ({'key': 'curve_menu_entries',
                           'label_en': 'Curve Menu Entries',
                           'label_ja': 'カーブメニュー項目',
                           'description_en': 'Adds Simplify Curves Plus commands to Blender curve menus. Disable it to '
                                             'remove every menu callback.',
                           'description_ja': 'Simplify Curves Plus のコマンドを Blender '
                                             'のカーブメニューへ追加します。無効にするとメニューコールバックをすべて削除します。',
                           'module_path': '',
                           'enable_fn': 'enable_menu_callbacks',
                           'disable_fn': 'disable_menu_callbacks',
                           'default': False},),
 'storytools': ({'key': 'viewport_storyboard_header',
                 'label_en': 'Storyboard Header Controls',
                 'label_ja': 'ストーリーボードヘッダー操作',
                 'description_en': 'Keeps Storytools storyboard controls in compatible editor headers. Disable it to '
                                   'remove the header callbacks.',
                 'description_ja': 'Storytools のストーリーボード操作を対応エディターヘッダーへ常設します。無効にするとヘッダーコールバックを削除します。',
                 'module_path': 'setup.ui',
                 'enable_fn': 'enable_header_callbacks',
                 'disable_fn': 'disable_header_callbacks',
                 'default': False},
                {'key': 'grease_pencil_overlay_options',
                 'label_en': 'Grease Pencil Overlay Options',
                 'label_ja': 'グリースペンシルオーバーレイ設定',
                 'description_en': 'Keeps Storytools overlay controls attached to the compatible viewport UI. Disable '
                                   'it to remove those callbacks.',
                 'description_ja': 'Storytools のオーバーレイ操作を対応ビューポートUIへ常設します。無効にするとコールバックを削除します。',
                 'module_path': 'ui',
                 'enable_fn': 'enable_overlay_callbacks',
                 'disable_fn': 'disable_overlay_callbacks',
                 'default': False},
                {'key': 'main_toolbar_gizmo',
                 'label_en': 'Main Toolbar Gizmo',
                 'label_ja': 'メインツールバーギズモ',
                 'description_en': 'Registers the Storytools main toolbar gizmo group. Disable it when the persistent '
                                   'gizmo is not needed.',
                 'description_ja': 'Storytools のメインツールバーギズモグループを登録します。常設ギズモが不要な場合は無効にしてください。',
                 'module_path': 'gizmo_toolbar',
                 'enable_fn': 'enable_main_toolbar_gizmo',
                 'disable_fn': 'disable_main_toolbar_gizmo',
                 'default': False},
                {'key': 'tool_preset_gizmo_bar',
                 'label_en': 'Tool Preset Gizmo Bar',
                 'label_ja': 'ツールプリセット・ギズモバー',
                 'description_en': 'Registers the Storytools preset gizmo bar. Disable it to remove the gizmo group.',
                 'description_ja': 'Storytools のプリセットギズモバーを登録します。無効にするとギズモグループを削除します。',
                 'module_path': 'gizmo_toolpreset_bar',
                 'enable_fn': 'enable_toolpreset_bar',
                 'disable_fn': 'disable_toolpreset_bar',
                 'default': False},
                {'key': 'draw_tool_hotkeys',
                 'label_en': 'Draw Tool Hotkeys',
                 'label_ja': '描画ツール・ホットキー',
                 'description_en': "Registers Storytools draw-tool shortcuts in Blender's add-on key configuration. "
                                   'Disabling removes them all.',
                 'description_ja': 'Storytools 描画ツールのショートカットを Blender のアドオンキーマップへ登録します。無効にするとすべて削除します。',
                 'module_path': 'keymaps',
                 'enable_fn': 'enable_draw_tool_hotkeys',
                 'disable_fn': 'disable_draw_tool_hotkeys',
                 'default': False},
                {'key': 'locked_view_pan_hotkeys',
                 'label_en': 'Locked View Pan Hotkeys',
                 'label_ja': 'ロックビュー移動ホットキー',
                 'description_en': 'Registers Storytools locked-view pan shortcuts. Disabling removes every owned '
                                   'KeyMapItem.',
                 'description_ja': 'Storytools のロックビュー移動ショートカットを登録します。無効にすると所有する全 KeyMapItem を削除します。',
                 'module_path': 'gizmos_camera.view_locked_pan',
                 'enable_fn': 'enable_view_locked_pan_hotkeys',
                 'disable_fn': 'disable_view_locked_pan_hotkeys',
                 'default': False},
                {'key': 'minimap_toolbar_gizmo',
                 'label_en': 'Minimap Toolbar Gizmo',
                 'label_ja': 'ミニマップツールバーギズモ',
                 'description_en': 'Registers the Storytools minimap toolbar gizmo. Disable it to remove the gizmo '
                                   'group.',
                 'description_ja': 'Storytools のミニマップツールバーギズモを登録します。無効にするとギズモグループを削除します。',
                 'module_path': 'map.gizmo_map_toolbar',
                 'enable_fn': 'enable_minimap_toolbar_gizmo',
                 'disable_fn': 'disable_minimap_toolbar_gizmo',
                 'default': False},
                {'key': 'layer_material_sync',
                 'label_en': 'Layer / Material Auto Sync Callbacks',
                 'label_ja': 'レイヤー / マテリアル自動同期コールバック',
                 'description_en': 'Enable only the Storytools callbacks that automatically keep Grease Pencil layer '
                                   'and material synchronization up to date while you work. Leave this off when you '
                                   'prefer manual N-panel operations.',
                 'description_ja': '作業中に Grease Pencil のレイヤーとマテリアル同期を自動更新する Storytools '
                                   'コールバックだけを有効化します。Nパネルから手動操作する場合は無効のままにしてください。',
                 'module_path': 'handles',
                 'enable_fn': 'enable_background_callbacks',
                 'disable_fn': 'disable_background_callbacks',
                 'default': False},
                {'key': 'camera_exclusion_watch',
                 'label_en': 'Camera Exclusion Auto Update',
                 'label_ja': 'カメラ除外の自動更新',
                 'description_en': 'Enable the Storytools camera-change watcher so object and collection exclusion '
                                   'visibility updates automatically when the active camera changes. This is kept as '
                                   'an always-on option because the function depends on reacting to camera changes.',
                 'description_ja': 'アクティブカメラ変更時にオブジェクト / コレクション除外表示を自動更新する Storytools '
                                   '監視を有効化します。カメラ変更への反応が必要な機能のため、常時起動項目として残しています。',
                 'module_path': 'camera_operators.cam_exclude_filter',
                 'enable_fn': 'enable_runtime_callbacks',
                 'disable_fn': 'disable_runtime_callbacks',
                 'default': False},
                {'key': 'minimap_draw_handler',
                 'label_en': 'Minimap Draw Handler',
                 'label_ja': 'ミニマップ描画ハンドラー',
                 'description_en': 'Enable the Storytools viewport draw handler that keeps the minimap overlay visible '
                                   'in minimap viewports. Use this only when you need the overlay to remain visible '
                                   'continuously.',
                 'description_ja': 'ミニマップ用ビューポートでミニマップオーバーレイを表示し続ける Storytools '
                                   '描画ハンドラーを有効化します。オーバーレイを継続表示したい場合だけ有効にしてください。',
                 'module_path': 'map.handler_draw_map',
                 'enable_fn': 'enable_minimap_draw_handler',
                 'disable_fn': 'disable_minimap_draw_handler',
                 'default': False},
                {'key': 'scale_figure_draw_handler',
                 'label_en': 'Scale Figure Draw Handler',
                 'label_ja': 'スケールフィギュア描画ハンドラー',
                 'description_en': 'Enable the Storytools viewport draw handler that keeps scale reference figures '
                                   'visible for Grease Pencil scenes. Use this only when persistent scale guides are '
                                   'required.',
                 'description_ja': 'Grease Pencil シーン用のスケール参照図を表示し続ける Storytools '
                                   '描画ハンドラーを有効化します。常駐のスケールガイドが必要な場合だけ有効にしてください。',
                 'module_path': 'scale_figure.draw_scale_figure',
                 'enable_fn': 'enable_scale_figure_draw_handler',
                 'disable_fn': 'disable_scale_figure_draw_handler',
                 'default': False}),
 'sakura_poselib': ({'key': 'pose_library_hotkeys',
                     'label_en': 'Pose Library Hotkeys',
                     'label_ja': 'ポーズライブラリ・ホットキー',
                     'description_en': "Registers Sakura PoseLib shortcuts in Blender's add-on key configuration. "
                                       'Disabling removes every owned shortcut.',
                     'description_ja': 'Sakura PoseLib のショートカットを Blender のアドオンキーマップへ登録します。無効にすると所有するショートカットをすべて削除します。',
                     'module_path': 'hotkey',
                     'enable_fn': 'enable_hotkeys',
                     'disable_fn': 'disable_hotkeys',
                     'default': False},
                    {'key': 'pose_maintenance',
                     'label_en': 'Pose Library Background Maintenance',
                     'label_ja': 'ポーズライブラリのバックグラウンド保守',
                     'description_en': 'Enable Sakura PoseLib timer/msgbus maintenance for linked armature proxy '
                                       'upkeep, action maintenance, and bone-rename tracking. Keep this disabled '
                                       'unless those automatic maintenance tasks are required.',
                     'description_ja': 'リンクアーマチュア用プロキシ維持、アクション保守、ボーン名変更追跡のための Sakura PoseLib タイマー / msgbus '
                                       '保守を有効化します。これらの自動保守が必要な場合だけ有効にしてください。',
                     'module_path': 'handlers',
                     'enable_fn': 'enable_background_handlers',
                     'disable_fn': 'disable_background_handlers',
                     'default': False})}

_BACKGROUND_STATE: dict[str, dict[str, bool]] = {
    alias: {str(item['key']): bool(item.get('default', False)) for item in items}
    for alias, items in _BACKGROUND_OPTIONS.items()
}


def _declared_background_state() -> dict[str, dict[str, bool]]:
    clean: dict[str, dict[str, bool]] = {}
    for alias, items in _BACKGROUND_OPTIONS.items():
        source = _BACKGROUND_STATE.setdefault(alias, {})
        values: dict[str, bool] = {}
        for item in items:
            key = str(item.get('key') or '').strip()
            if key:
                values[key] = bool(source.get(key, bool(item.get('default', False))))
        if values:
            clean[alias] = values
    return clean


def _load_background_state() -> None:
    global _BACKGROUND_LOADED, _BACKGROUND_DIRTY
    if _BACKGROUND_LOADED:
        return
    raw = config_store.get_section('background_feature_toggles', {})
    if isinstance(raw, dict):
        for alias, values in raw.items():
            if alias not in _BACKGROUND_OPTIONS or not isinstance(values, dict):
                continue
            declared = {str(item.get('key') or '').strip() for item in _BACKGROUND_OPTIONS[alias]}
            target = _BACKGROUND_STATE.setdefault(str(alias), {})
            for key, value in values.items():
                key = str(key or '').strip()
                if key in declared:
                    target[key] = bool(value)
    _BACKGROUND_LOADED = True
    _BACKGROUND_DIRTY = False


def _npanel_auto_save_enabled() -> bool:
    try:
        from . import core
        return bool(core.npanel_auto_save_enabled(context=getattr(bpy, 'context', None)))
    except Exception:
        return True


def _save_background_state(*, force: bool = False) -> bool:
    global _BACKGROUND_DIRTY
    snapshot = _declared_background_state()
    _BACKGROUND_DIRTY = True
    if not force and not _npanel_auto_save_enabled():
        return True
    ok = bool(config_store.set_section('background_feature_toggles', snapshot))
    if ok:
        _BACKGROUND_DIRTY = False
    return ok


def commit_dirty_state() -> bool:
    global _BACKGROUND_DIRTY, _BACKGROUND_LOADED
    if not _BACKGROUND_DIRTY:
        return True
    try:
        intentionally_disabled = bool(
            not _npanel_auto_save_enabled()
            and not config_store.write_enabled()
            and not config_store.restore_active()
        )
    except Exception:
        intentionally_disabled = False
    if intentionally_disabled:
        # An OFF-session resident edit is deliberately not persisted. Reset the
        # in-process cache to declared defaults and force the next registration
        # to reload the last committed JSON instead of resurrecting this edit.
        for alias, items in _BACKGROUND_OPTIONS.items():
            _BACKGROUND_STATE[alias] = {
                str(item['key']): bool(item.get('default', False)) for item in items
            }
        _BACKGROUND_DIRTY = False
        _BACKGROUND_LOADED = False
        return True
    return _save_background_state(force=True)


def background_option_property_name(alias: str, key: str) -> str:
    def clean(value: str) -> str:
        return ''.join(ch if ch.isalnum() else '_' for ch in str(value or '').strip().lower()).strip('_')
    return f'always_on_{clean(alias)}_{clean(key)}'


def background_option_from_property(prop_name: str) -> tuple[str, str] | None:
    wanted = str(prop_name or '').strip()
    for alias, items in _BACKGROUND_OPTIONS.items():
        for item in items:
            key = str(item.get('key') or '').strip()
            if key and background_option_property_name(alias, key) == wanted:
                return alias, key
    return None


def is_background_option_enabled(alias: str, key: str) -> bool:
    # Read-only cached query. Disk loading is confined to initialize_records().
    alias = str(alias or '').strip()
    key = str(key or '').strip()
    item = next((entry for entry in _BACKGROUND_OPTIONS.get(alias, ()) if str(entry.get('key') or '') == key), None)
    return bool(_BACKGROUND_STATE.get(alias, {}).get(key, bool((item or {}).get('default', False))))


def tool_background_entries(alias: str) -> list[dict[str, Any]]:
    # Panel.draw calls this path; never perform file I/O or migration here.
    alias = str(alias or '').strip()
    result: list[dict[str, Any]] = []
    state = _BACKGROUND_STATE.get(alias, {})
    for item in _BACKGROUND_OPTIONS.get(alias, ()):
        key = str(item.get('key') or '').strip()
        if not key:
            continue
        result.append({
            **item,
            'alias': alias,
            'enabled': bool(state.get(key, bool(item.get('default', False)))),
            'property_name': background_option_property_name(alias, key),
        })
    return result


def all_background_option_entries() -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for alias in registry.TOOL_ALIASES:
        entries.extend(tool_background_entries(alias))
    return entries


def aliases_with_enabled_background_options() -> tuple[str, ...]:
    _load_background_state()
    return tuple(
        alias for alias in registry.TOOL_ALIASES
        if any(is_background_option_enabled(alias, str(item.get('key') or '')) for item in _BACKGROUND_OPTIONS.get(alias, ()))
    )


def _platform_supported(outer_zip: str) -> bool:
    lower = str(outer_zip or '').lower()
    system = platform.system().lower()
    if 'windows' in lower or 'win64' in lower:
        return system == 'windows'
    if 'linux' in lower:
        return system == 'linux'
    if 'macos' in lower or 'darwin' in lower:
        return system == 'darwin'
    return True


def _make_empty_record(spec: dict[str, Any]) -> dict[str, Any]:
    return {
        'spec': spec,
        'status': 'AVAILABLE',
        'module': None,
        'registered_classes': [],
        'panels': [],
        'operators': [],
        'menus': [],
        'preferences': [],
        'registered_props': [],
        'registered_handlers': [],
        'registered_keymaps': [],
        'imported_modules': [],
        'resource_counts': {},
        'error': '',
    }


def _apply_base_status(record: dict[str, Any]) -> dict[str, Any]:
    spec = record.get('spec') or {}
    if not bool(spec.get('load', True)):
        record['status'] = 'DISABLED'
    elif not _platform_supported(str(spec.get('outer_zip') or '')):
        record['status'] = 'UNSUPPORTED_PLATFORM'
    else:
        record['status'] = 'AVAILABLE'
    return record


def clear_records() -> None:
    _RECORDS.clear()
    _RECORDS_BY_ALIAS.clear()


def get_records() -> list[dict[str, Any]]:
    return list(_RECORDS)


def get_record(alias: str) -> dict[str, Any] | None:
    return _RECORDS_BY_ALIAS.get(str(alias or '').strip())


def is_tool_loaded(alias: str) -> bool:
    record = get_record(alias)
    return bool(record and str(record.get('status') or '') == 'READY')


def loaded_aliases() -> list[str]:
    return [
        str((record.get('spec') or {}).get('alias') or '')
        for record in _RECORDS if str(record.get('status') or '') == 'READY'
    ]


def initialize_records(*, force: bool = False, ledger: lifecycle.GenerationLedger | None = None) -> list[dict[str, Any]]:
    global _SUITE_LEDGER
    if ledger is not None:
        _SUITE_LEDGER = ledger
    _load_background_state()
    specs = list(registry.build_specs(force=force) or ())
    if not _RECORDS:
        for spec in specs:
            record = _apply_base_status(_make_empty_record(spec))
            alias = str(spec.get('alias') or '').strip()
            _RECORDS.append(record)
            if alias:
                _RECORDS_BY_ALIAS[alias] = record
        return get_records()

    current = dict(_RECORDS_BY_ALIAS)
    wanted = {str(spec.get('alias') or '').strip() for spec in specs}
    for alias in tuple(current):
        if alias not in wanted:
            unload_tool(alias)
    next_records: list[dict[str, Any]] = []
    next_by_alias: dict[str, dict[str, Any]] = {}
    for spec in specs:
        alias = str(spec.get('alias') or '').strip()
        record = current.get(alias)
        if record is None:
            record = _apply_base_status(_make_empty_record(spec))
        else:
            record['spec'] = spec
            if str(record.get('status') or '') != 'READY':
                _apply_base_status(record)
        next_records.append(record)
        if alias:
            next_by_alias[alias] = record
    _RECORDS[:] = next_records
    _RECORDS_BY_ALIAS.clear()
    _RECORDS_BY_ALIAS.update(next_by_alias)
    return get_records()


def sync_tool_enabled_from_preferences(alias: str, enabled: bool | None = None) -> dict[str, Any] | None:
    del enabled
    record = get_record(alias)
    if record is None:
        return None
    _apply_base_status(record)
    if str(record.get('status') or '') == 'AVAILABLE':
        return load_tool(alias)
    return record


_RNA_OWNER_NAMES = (
    'Scene', 'WindowManager', 'Object', 'Camera', 'Armature', 'Bone', 'PoseBone',
    'Action', 'Collection', 'Material', 'World', 'Curve', 'Mesh', 'Image',
)
_RNA_PROPERTY_FACTORY_NAMES = frozenset({
    'BoolProperty', 'BoolVectorProperty', 'CollectionProperty', 'EnumProperty',
    'FloatProperty', 'FloatVectorProperty', 'IntProperty', 'IntVectorProperty',
    'PointerProperty', 'StringProperty',
})
_HANDLER_NAMES = (
    'load_pre', 'load_post', 'load_factory_preferences_post', 'save_pre', 'save_post',
    'quit_pre', 'blend_import_pre', 'blend_import_post', 'translation_update_post',
    'frame_change_pre', 'frame_change_post', 'depsgraph_update_pre', 'depsgraph_update_post',
    'undo_pre', 'undo_post', 'redo_pre', 'redo_post', 'version_update',
    'render_init', 'render_pre', 'render_post', 'render_complete', 'render_cancel',
    'render_write', 'animation_playback_pre', 'animation_playback_post',
    'object_bake_pre', 'object_bake_complete', 'object_bake_cancel',
    'composite_pre', 'composite_post', 'composite_cancel', 'annotation_pre',
    'xr_session_start_pre',
)
_BLENDER_BASE_NAMES = (
    'Operator', 'Panel', 'PropertyGroup', 'Menu', 'UIList', 'Gizmo', 'GizmoGroup',
    'AddonPreferences', 'RenderEngine', 'Node', 'NodeSocket',
)


def _tool_module_names(spec: dict[str, Any]) -> tuple[str, ...]:
    alias = str(spec.get('alias') or '').strip()
    root_name = f'{__package__}.{alias}'
    root = Path(str(spec.get('addon_dir') or '')).resolve()
    names: list[str] = [root_name]
    if root.is_dir():
        for path in sorted(root.rglob('*.py')):
            if '__pycache__' in path.parts:
                continue
            rel = path.relative_to(root)
            parts = list(rel.parts)
            if parts[-1] == '__init__.py':
                parts = parts[:-1]
            else:
                parts[-1] = parts[-1][:-3]
            if parts:
                names.append(root_name + '.' + '.'.join(parts))
    return tuple(dict.fromkeys(names))


def _import_root_module(spec: dict[str, Any], child: lifecycle.GenerationLedger) -> types.ModuleType:
    names = _tool_module_names(spec)
    root_name = names[0]
    missing = object()
    before = {name: sys.modules.get(name, missing) for name in names}
    occupied = [name for name, value in before.items() if value is not missing]
    if occupied:
        raise lifecycle.LifecycleError(
            f'unowned module names already occupied: {occupied[:8]}'
        )
    parent_before: dict[str, tuple[types.ModuleType | None, str, bool, Any]] = {}
    for name in names:
        parent_name, _separator, attribute = name.rpartition('.')
        parent = sys.modules.get(parent_name)
        had_attribute = isinstance(parent, types.ModuleType) and attribute in vars(parent)
        previous_attribute = (
            vars(parent).get(attribute) if had_attribute else missing
        )
        parent_before[name] = (
            parent if isinstance(parent, types.ModuleType) else None,
            attribute,
            had_attribute,
            previous_attribute,
        )

    recorded: dict[str, types.ModuleType] = {}
    ordered_names = tuple(sorted(names, key=lambda value: (value.count('.'), value)))

    def capture_new_exact_bindings() -> None:
        for name in ordered_names:
            value = sys.modules.get(name, missing)
            if value is missing:
                continue
            if not isinstance(value, types.ModuleType):
                raise lifecycle.LifecycleError(f'import did not bind a module: {name}')
            previous = recorded.get(name)
            if previous is not None:
                if value is not previous:
                    raise lifecycle.LifecycleError(
                        f'imported module identity changed during transaction: {name}'
                    )
                continue
            initial_parent, attribute, had_attribute, previous_attribute = parent_before[name]
            parent_name = name.rpartition('.')[0]
            parent = sys.modules.get(parent_name)
            if initial_parent is not None and parent is not None and parent is not initial_parent:
                raise lifecycle.LifecycleError(f'imported module parent identity changed: {name}')
            record_kwargs = {
                'parent_module': (
                    parent if isinstance(parent, types.ModuleType) else initial_parent
                ),
                'parent_attribute': attribute,
                'parent_had_attribute': had_attribute,
            }
            if had_attribute:
                record_kwargs['parent_previous_attribute'] = previous_attribute
            child.record_module(name, value, **record_kwargs)
            recorded[name] = value

    try:
        module = importlib.import_module(root_name)
    finally:
        capture_new_exact_bindings()
    if not isinstance(module, types.ModuleType):
        raise lifecycle.LifecycleError(f'import did not return a module: {root_name}')

    # Import the finite, filesystem-declared module set before registration so
    # every modal/class can be prepared and identity-checked before Blender sees
    # it. This is not a sys.modules prefix scan.
    for name in sorted(names[1:], key=lambda value: (value.count('.'), value)):
        value = sys.modules.get(name, missing)
        if value is missing:
            try:
                value = importlib.import_module(name)
            finally:
                capture_new_exact_bindings()
        if not isinstance(value, types.ModuleType):
            raise lifecycle.LifecycleError(f'import did not return a module: {name}')
        capture_new_exact_bindings()
    return module


def _iter_tool_modules(root_module: types.ModuleType) -> tuple[types.ModuleType, ...]:
    prefix = str(root_module.__name__)
    result: list[types.ModuleType] = []
    queue: list[types.ModuleType] = [root_module]
    seen: set[int] = set()
    while queue and len(result) < 512:
        module = queue.pop(0)
        if id(module) in seen:
            continue
        seen.add(id(module))
        name = str(getattr(module, '__name__', '') or '')
        if name != prefix and not name.startswith(prefix + '.'):
            continue
        result.append(module)
        for value in tuple(vars(module).values()):
            if isinstance(value, types.ModuleType):
                child_name = str(getattr(value, '__name__', '') or '')
                if child_name == prefix or child_name.startswith(prefix + '.'):
                    queue.append(value)
            elif isinstance(value, (tuple, list)) and len(value) <= 256:
                for item in value:
                    if isinstance(item, types.ModuleType):
                        child_name = str(getattr(item, '__name__', '') or '')
                        if child_name == prefix or child_name.startswith(prefix + '.'):
                            queue.append(item)
    return tuple(result)


def _registration_modules(root_module: types.ModuleType) -> tuple[types.ModuleType, ...]:
    """Follow the tool's finite, declared ``modules`` registration graph.

    The loader imports every filesystem-declared module so identities can be
    rolled back exactly.  Imported-but-unreferenced legacy files are not,
    however, part of the public ``register()`` transaction and their classes
    must not be required.  Tools without a root ``modules`` declaration keep
    the existing bounded module traversal.
    """
    declared = vars(root_module).get('modules')
    if declared is None:
        return _iter_tool_modules(root_module)
    if not isinstance(declared, (tuple, list)) or len(declared) > 512:
        raise lifecycle.LifecycleError(
            f'invalid root modules registration graph: {root_module.__name__}'
        )
    prefix = str(root_module.__name__)
    result: list[types.ModuleType] = []
    queue: list[types.ModuleType] = [root_module]
    seen: set[int] = set()
    while queue and len(result) < 512:
        module = queue.pop(0)
        if id(module) in seen:
            continue
        name = str(getattr(module, '__name__', '') or '')
        if name != prefix and not name.startswith(prefix + '.'):
            raise lifecycle.LifecycleError(
                f'foreign module in registration graph: {name}'
            )
        seen.add(id(module))
        result.append(module)
        children = vars(module).get('modules')
        if children is None:
            continue
        if not isinstance(children, (tuple, list)) or len(children) > 512:
            raise lifecycle.LifecycleError(
                f'invalid modules registration graph: {name}'
            )
        for child in children:
            if not isinstance(child, types.ModuleType):
                raise lifecycle.LifecycleError(
                    f'non-module registration graph member: {name}'
                )
            queue.append(child)
    if queue:
        raise lifecycle.LifecycleError('registration module graph exceeds finite bound')
    return tuple(result)


def _is_blender_class(value: Any) -> bool:
    if not isinstance(value, type):
        return False
    for base_name in _BLENDER_BASE_NAMES:
        base = getattr(bpy.types, base_name, None)
        try:
            if base is not None and issubclass(value, base):
                return value is not base
        except Exception:
            continue
    return False


def _module_ast(module: types.ModuleType) -> ast.Module | None:
    path = getattr(module, '__file__', None)
    if not path:
        return None
    try:
        return ast.parse(Path(path).read_text(encoding='utf-8'), filename=str(path))
    except Exception:
        return None


def _optional_class_groups(modules: Iterable[types.ModuleType]) -> dict[str, tuple[type, ...]]:
    groups: dict[str, list[type]] = {}
    seen: dict[str, set[int]] = {}
    for module in tuple(modules):
        declared = getattr(module, '_SMARTTOOLS_OPTIONAL_CLASS_GROUPS', {})
        if declared in (None, {}):
            continue
        if not isinstance(declared, dict) or len(declared) > 32:
            raise lifecycle.LifecycleError(
                f'invalid optional class groups: {module.__name__}'
            )
        for raw_key, values in declared.items():
            key = str(raw_key or '').strip()
            if not key or not isinstance(values, (tuple, list)) or len(values) > 512:
                raise lifecycle.LifecycleError(
                    f'invalid optional class group: {module.__name__}.{key}'
                )
            target = groups.setdefault(key, [])
            markers = seen.setdefault(key, set())
            for cls in values:
                if (
                    not _is_blender_class(cls)
                    or str(getattr(cls, '__module__', '')) != str(module.__name__)
                ):
                    raise lifecycle.LifecycleError(
                        f'foreign optional class declaration: {module.__name__}.{key}'
                    )
                if id(cls) not in markers:
                    markers.add(id(cls))
                    target.append(cls)
    return {key: tuple(values) for key, values in groups.items()}


def _candidate_classes(modules: Iterable[types.ModuleType]) -> tuple[tuple[type, ...], tuple[type, ...], dict[str, tuple[type, ...]]]:
    candidates: list[type] = []
    required: list[type] = []
    seen_candidates: set[int] = set()
    seen_required: set[int] = set()

    def add_candidate(value: Any, *, is_required: bool = False) -> None:
        if not _is_blender_class(value):
            return
        if id(value) not in seen_candidates:
            seen_candidates.add(id(value))
            candidates.append(value)
        if is_required and id(value) not in seen_required:
            seen_required.add(id(value))
            required.append(value)

    module_items = tuple(modules)
    optional_groups = _optional_class_groups(module_items)
    optional_ids = {
        id(cls) for values in optional_groups.values() for cls in values
    }

    for module in module_items:
        for name, value in tuple(vars(module).items()):
            if isinstance(value, type) and str(getattr(value, '__module__', '')) == str(module.__name__):
                add_candidate(value)
            if isinstance(value, (tuple, list)) and 'class' in str(name).lower() and len(value) <= 512:
                for item in value:
                    add_candidate(item, is_required=True)
        tree = _module_ast(module)
        if tree is None:
            continue
        names = vars(module)
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func_name = ''
            if isinstance(node.func, ast.Name):
                func_name = node.func.id
            elif isinstance(node.func, ast.Attribute):
                func_name = node.func.attr
            if func_name == 'register_class' and node.args and isinstance(node.args[0], ast.Name):
                add_candidate(names.get(node.args[0].id), is_required=True)
            elif func_name == 'register_classes_factory' and node.args:
                arg = node.args[0]
                if isinstance(arg, (ast.Tuple, ast.List)):
                    for item in arg.elts:
                        if isinstance(item, ast.Name):
                            add_candidate(names.get(item.id), is_required=True)
    return (
        tuple(candidates),
        tuple(cls for cls in required if id(cls) not in optional_ids),
        optional_groups,
    )


def _declared_rna_targets(
    spec: dict[str, Any],
    modules: Iterable[types.ModuleType] | None = None,
) -> tuple[tuple[Any, str], ...]:
    """Return only RNA properties reachable from registration transactions.

    Some bundled tools assign ordinary runtime cache values on ``bpy.types``
    from event callbacks.  A filesystem-wide assignment scan misclassifies
    those conditional values as mandatory registration-time RNA.  Follow the
    finite local call graph rooted at register/unregister helpers instead.
    """
    owner_map = {name: getattr(bpy.types, name, None) for name in _RNA_OWNER_NAMES}
    targets: list[tuple[Any, str]] = []
    seen: set[tuple[int, str]] = set()
    if modules is None:
        root = Path(str(spec.get('addon_dir') or ''))
        paths = tuple(sorted(root.rglob('*.py'))) if root.is_dir() else ()
    else:
        paths = tuple(sorted({
            Path(str(path))
            for module in modules
            for path in (getattr(module, '__file__', None),)
            if path
        }))
    for path in paths:
        try:
            tree = ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
        except Exception:
            continue
        functions = {
            node.name: node
            for node in tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
        queue = [
            functions[name]
            for name in ('register', 'unregister', '_register_impl')
            if name in functions
        ]
        registration_functions: list[ast.AST] = []
        visited: set[str] = set()
        while queue and len(registration_functions) < 256:
            function = queue.pop(0)
            name = str(getattr(function, 'name', '') or '')
            if name in visited:
                continue
            visited.add(name)
            registration_functions.append(function)
            for call in ast.walk(function):
                if not isinstance(call, ast.Call) or not isinstance(call.func, ast.Name):
                    continue
                target = functions.get(call.func.id)
                if target is not None and call.func.id not in visited:
                    queue.append(target)
        if queue:
            raise lifecycle.LifecycleError(
                f'RNA registration call graph exceeds finite bound: {path}'
            )
        for node in (
            candidate
            for function in registration_functions
            for candidate in ast.walk(function)
        ):
            target_nodes: list[ast.AST] = []
            definition: ast.AST | None = None
            if isinstance(node, (ast.Assign, ast.AnnAssign)):
                target_nodes = list(node.targets) if isinstance(node, ast.Assign) else [node.target]
                definition = node.value
            if not isinstance(definition, ast.Call):
                continue
            factory_name = ''
            if isinstance(definition.func, ast.Name):
                factory_name = definition.func.id
            elif isinstance(definition.func, ast.Attribute):
                factory_name = definition.func.attr
            if factory_name not in _RNA_PROPERTY_FACTORY_NAMES:
                continue
            for target in target_nodes:
                if not isinstance(target, ast.Attribute):
                    continue
                owner_expr = target.value
                if not (isinstance(owner_expr, ast.Attribute) and isinstance(owner_expr.value, ast.Attribute)):
                    continue
                if not (
                    isinstance(owner_expr.value.value, ast.Name)
                    and owner_expr.value.value.id == 'bpy'
                    and owner_expr.value.attr == 'types'
                ):
                    continue
                owner = owner_map.get(owner_expr.attr)
                name = str(target.attr or '')
                marker = (id(owner), name)
                if owner is not None and name and marker not in seen:
                    seen.add(marker)
                    targets.append((owner, name))
    return tuple(targets)


def _rna_property(owner: Any, name: str) -> Any:
    try:
        props = owner.bl_rna.properties
        try:
            return props.get(name)
        except Exception:
            return props[name]
    except Exception:
        return None


def _snapshot_rna() -> dict[tuple[Any, str], tuple[str, int]]:
    result: dict[tuple[Any, str], tuple[str, int]] = {}
    for owner_name in _RNA_OWNER_NAMES:
        owner = getattr(bpy.types, owner_name, None)
        if owner is None:
            continue
        try:
            properties = tuple(owner.bl_rna.properties)
        except Exception:
            properties = ()
        for prop in properties:
            name = str(getattr(prop, 'identifier', '') or '')
            identity = lifecycle.rna_property_identity(owner, name) if name else None
            if identity is not None:
                result[(owner, name)] = identity
    return result


def _snapshot_handlers() -> dict[tuple[str, int], tuple[Any, Callable[..., Any]]]:
    result: dict[tuple[str, int], tuple[Any, Callable[..., Any]]] = {}
    handlers = getattr(bpy.app, 'handlers', None)
    # Include Blender's current public handler collections while retaining a
    # stable fallback list for restricted/fake environments. This is a finite
    # host-API inventory, not a module/package ownership scan.
    names = set(_HANDLER_NAMES)
    try:
        for name in tuple(dir(handlers))[:256]:
            if not str(name).startswith('_'):
                value = getattr(handlers, name, None)
                if isinstance(value, list) or (hasattr(value, '__iter__') and hasattr(value, 'append') and hasattr(value, 'remove')):
                    names.add(str(name))
    except Exception:
        pass
    for name in sorted(names):
        collection = getattr(handlers, name, None)
        if collection is None:
            continue
        try:
            callbacks = tuple(collection)
        except Exception:
            callbacks = ()
        for callback in callbacks:
            result[(name, id(callback))] = (collection, callback)
    return result


def _snapshot_keymaps() -> dict[tuple[tuple[str, int], tuple[str, int]], tuple[Any, Any]]:
    result: dict[tuple[tuple[str, int], tuple[str, int]], tuple[Any, Any]] = {}
    try:
        kc = bpy.context.window_manager.keyconfigs.addon
        keymaps = tuple(kc.keymaps) if kc is not None else ()
    except Exception:
        keymaps = ()
    for keymap in keymaps:
        try:
            items = tuple(keymap.keymap_items)
        except Exception:
            items = ()
        for item in items:
            marker = (
                lifecycle.rna_resource_pointer_identity(keymap),
                lifecycle.rna_resource_pointer_identity(item),
            )
            result[marker] = (keymap, item)
    return result


def _categorize_classes(classes: Iterable[type]) -> tuple[list[type], list[type], list[type], list[type]]:
    panels: list[type] = []
    operators: list[type] = []
    menus: list[type] = []
    prefs: list[type] = []
    for cls in classes:
        try:
            if issubclass(cls, bpy.types.Panel):
                panels.append(cls)
            elif issubclass(cls, bpy.types.Operator):
                operators.append(cls)
            elif issubclass(cls, bpy.types.Menu):
                menus.append(cls)
            elif issubclass(cls, bpy.types.AddonPreferences):
                prefs.append(cls)
        except Exception:
            pass
    return panels, operators, menus, prefs


def _verify_and_adopt_resources(
    child: lifecycle.GenerationLedger,
    *, candidates: tuple[type, ...], required_classes: tuple[type, ...],
    declared_rna: tuple[tuple[Any, str], ...], before_rna: dict,
    before_handlers: dict, before_keymaps: dict,
) -> tuple[list[type], list[dict[str, str]], list[str], list[str]]:
    registered: list[type] = []
    for cls in candidates:
        identity = lifecycle.class_registration_identity(cls)
        if identity is not None:
            child.adopt_registered_class(cls, required=True)
            registered.append(cls)
    for cls in required_classes:
        child.require(
            lifecycle.class_registration_identity(cls) is not None,
            f'required class is not registered: {cls.__module__}.{cls.__name__}',
        )
    child.require(bool(registered), 'tool registered no Blender classes')

    after_rna = _snapshot_rna()
    for key, before_identity in before_rna.items():
        after_identity = after_rna.get(key)
        child.require(
            after_identity == before_identity,
            f'foreign RNA identity changed: {getattr(key[0], "__name__", key[0])}.{key[1]}',
        )
    registered_props: list[dict[str, str]] = []
    for (owner, name), identity in after_rna.items():
        if (owner, name) in before_rna:
            continue
        child.adopt_rna_property(owner, name, required=True)
        registered_props.append({'owner': getattr(owner, '__name__', str(owner)), 'name': name})
    for owner, name in declared_rna:
        child.require(
            lifecycle.rna_property_identity(owner, name) is not None,
            f'declared RNA property missing after registration: {getattr(owner, "__name__", owner)}.{name}',
        )

    after_handlers = _snapshot_handlers()
    for marker, (collection, callback) in before_handlers.items():
        current = after_handlers.get(marker)
        child.require(
            current is not None and current[0] is collection and current[1] is callback,
            f'foreign handler identity changed: {marker[0]}:{getattr(callback, "__name__", "callback")}',
        )
    handler_labels: list[str] = []
    for marker, (collection, callback) in after_handlers.items():
        if marker in before_handlers:
            continue
        name = marker[0]
        child.record_callback(
            kind='handler', label=f'{name}:{getattr(callback, "__name__", "callback")}', identity=id(callback),
            verifier=lambda _collection=collection, _callback=callback: any(item is _callback for item in _collection),
            remover=lambda _collection=collection, _callback=callback: _remove_exact_from_collection(_collection, _callback),
            metadata={'collection': collection, 'callback': callback},
        )
        handler_labels.append(f'{name}:{getattr(callback, "__name__", "callback")}')

    after_keymaps = _snapshot_keymaps()
    for marker, (keymap, item) in before_keymaps.items():
        current = after_keymaps.get(marker)
        child.require(
            current is not None,
            f'foreign keymap identity changed: {getattr(item, "idname", marker)}',
        )
    keymap_labels: list[str] = []
    for marker, (keymap, item) in after_keymaps.items():
        if marker in before_keymaps:
            continue
        child.record_keymap_item(keymap=keymap, item=item, label=str(getattr(item, 'idname', 'keymap')))
        keymap_labels.append(str(getattr(item, 'idname', 'keymap')))
    return registered, registered_props, handler_labels, keymap_labels


def _remove_exact_from_collection(collection: Any, callback: Any) -> None:
    last_error = None
    try:
        for index in range(len(collection) - 1, -1, -1):
            if collection[index] is callback:
                try:
                    collection.remove(callback)
                except Exception as exc:
                    last_error = exc
    except Exception as exc:
        last_error = exc
    try:
        remained = any(item is callback for item in collection)
    except Exception as exc:
        raise lifecycle.LifecycleError(f'exact handler verification failed: {exc}') from exc
    if remained:
        detail = f': {last_error}' if last_error is not None else ''
        raise lifecycle.LifecycleError(f'exact handler identity remained after removal{detail}')


def _adopt_partial_resources_after_failure(
    child: lifecycle.GenerationLedger, *, candidates: Iterable[type],
    before_rna: dict, before_handlers: dict, before_keymaps: dict,
) -> None:
    """Capture every exact resource visible immediately after a failed register.

    Bundled code can raise after several successful Blender calls. This finite
    post-call capture occurs before invoking its unregister function, ensuring the
    current transaction can still reverse only the resources it just acquired.
    """
    for cls in tuple(candidates or ()):
        try:
            if lifecycle.class_registration_identity(cls) is not None:
                child.adopt_registered_class(cls, required=False)
        except Exception:
            pass
    try:
        after_rna = _snapshot_rna()
        for (owner, name), identity in after_rna.items():
            if (owner, name) not in before_rna:
                try:
                    child.adopt_rna_property(owner, name, required=False)
                except Exception:
                    pass
    except Exception:
        pass
    try:
        for marker, (collection, callback) in _snapshot_handlers().items():
            if marker in before_handlers:
                continue
            if any(
                item.kind == 'handler' and item.metadata.get('callback') is callback
                for item in child.records
            ):
                continue
            child.record_callback(
                kind='handler', label=f'{marker[0]}:{getattr(callback, "__name__", "callback")}',
                identity=id(callback),
                verifier=lambda _collection=collection, _callback=callback: any(item is _callback for item in _collection),
                remover=lambda _collection=collection, _callback=callback: _remove_exact_from_collection(_collection, _callback),
                metadata={'collection': collection, 'callback': callback},
            )
    except Exception:
        pass
    try:
        for marker, (keymap, item) in _snapshot_keymaps().items():
            if marker in before_keymaps:
                continue
            if any(entry.kind == 'keymap' and entry.identity == marker for entry in child.records):
                continue
            child.record_keymap_item(keymap=keymap, item=item, label=str(getattr(item, 'idname', 'keymap')))
    except Exception:
        pass


def _resolve_relative_module(root_module: types.ModuleType, module_path: str) -> types.ModuleType | None:
    text = str(module_path or '').strip().strip('.')
    if not text:
        return root_module
    current: Any = root_module
    for part in text.split('.'):
        current = getattr(current, part, None)
        if current is None:
            try:
                current = importlib.import_module(f'{root_module.__name__}.{text}')
            except Exception:
                return None
            break
    return current if isinstance(current, types.ModuleType) else None


def _record_optional_class_groups(record: dict[str, Any]) -> dict[str, tuple[type, ...]]:
    stored = record.get('optional_class_groups')
    if isinstance(stored, dict):
        return {
            str(key): tuple(values)
            for key, values in stored.items()
            if isinstance(values, (tuple, list))
        }
    module = record.get('module')
    if not isinstance(module, types.ModuleType):
        return {}
    return _optional_class_groups(_iter_tool_modules(module))


def _optional_group_registered(record: dict[str, Any], key: str) -> bool:
    classes = _record_optional_class_groups(record).get(str(key or ''), ())
    return not classes or all(
        lifecycle.class_registration_identity(cls) is not None for cls in classes
    )


def _optional_group_absent(record: dict[str, Any], key: str) -> bool:
    classes = _record_optional_class_groups(record).get(str(key or ''), ())
    return all(
        lifecycle.class_registration_identity(cls) is None for cls in classes
    )


def _apply_background_option(record: dict[str, Any], option: dict[str, Any], enabled: bool) -> bool:
    module = record.get('module')
    if not isinstance(module, types.ModuleType):
        return False
    target = _resolve_relative_module(module, str(option.get('module_path') or '')) or module
    fn_name = str(option.get('enable_fn') if enabled else option.get('disable_fn') or '').strip()
    fn = getattr(target, fn_name, None)
    if not callable(fn):
        return False
    result = fn()
    if result is False:
        raise lifecycle.LifecycleError(f'background option returned False: {record["spec"]["alias"]}.{fn_name}')
    key = str(option.get('key') or '').strip()
    if enabled and not _optional_group_registered(record, key):
        disable_name = str(option.get('disable_fn') or '').strip()
        disable_fn = getattr(target, disable_name, None)
        if callable(disable_fn):
            try:
                disable_fn()
            except Exception:
                pass
        raise lifecycle.LifecycleError(
            f'optional class group is incomplete after enable: {record["spec"]["alias"]}.{key}'
        )
    if not enabled and not _optional_group_absent(record, key):
        raise lifecycle.LifecycleError(
            f'optional class group remained after disable: {record["spec"]["alias"]}.{key}'
        )
    return True


def _disable_background_option_exact(
    record: dict[str, Any], option: dict[str, Any], disable_fn: Callable[..., Any],
) -> None:
    result = disable_fn()
    key = str(option.get('key') or '').strip()
    if result is False or not _optional_group_absent(record, key):
        raise lifecycle.LifecycleError(
            f'background option exact disable failed: {record["spec"]["alias"]}.{key}'
        )


def _record_enabled_background_option(
    child: lifecycle.GenerationLedger, record: dict[str, Any], option: dict[str, Any],
) -> None:
    module = record.get('module')
    if not isinstance(module, types.ModuleType):
        raise lifecycle.LifecycleError('background option module is missing')
    target = _resolve_relative_module(module, str(option.get('module_path') or '')) or module
    disable_name = str(option.get('disable_fn') or '').strip()
    disable_fn = getattr(target, disable_name, None)
    if not callable(disable_fn):
        raise lifecycle.LifecycleError(f'background disable callback is missing: {disable_name}')
    key = str(option.get('key') or disable_name)
    child.record_callback(
        kind='background_feature',
        label=f'{(record.get("spec") or {}).get("alias", "tool")}.{key}',
        identity=(id(target), id(disable_fn)),
        verifier=lambda _target=target, _name=disable_name, _fn=disable_fn: getattr(_target, _name, None) is _fn,
        remover=lambda _record=record, _option=option, _fn=disable_fn: _disable_background_option_exact(
            _record, _option, _fn
        ),
        metadata={'module': target, 'disable_fn': disable_fn, 'key': key},
    )


def _background_feature_record(
    child: lifecycle.GenerationLedger | None, record: dict[str, Any], option: dict[str, Any],
    *, active_only: bool = True,
):
    if child is None:
        return None
    alias = str((record.get('spec') or {}).get('alias') or '')
    key = str(option.get('key') or '').strip()
    for resource in reversed(child.records):
        if resource.kind != 'background_feature':
            continue
        if active_only and not resource.active:
            continue
        if resource.label == f'{alias}.{key}':
            return resource
    return None


def _adopt_runtime_background_option(record: dict[str, Any], option: dict[str, Any]) -> bool:
    alias = str((record.get('spec') or {}).get('alias') or '')
    child = _TOOL_LEDGERS.get(alias)
    if child is None or child.released:
        return False
    resource = _background_feature_record(child, record, option)
    if resource is None:
        resource = _background_feature_record(child, record, option, active_only=False)
        if resource is None:
            _record_enabled_background_option(child, record, option)
        else:
            module = record.get('module')
            if not isinstance(module, types.ModuleType):
                return False
            target = _resolve_relative_module(module, str(option.get('module_path') or '')) or module
            disable_name = str(option.get('disable_fn') or '').strip()
            disable_fn = getattr(target, disable_name, None)
            if not callable(disable_fn):
                return False
            # Re-arm the same bounded record instead of appending one record per
            # toggle cycle. Exact identity and remover are refreshed together.
            resource.identity = (id(target), id(disable_fn))
            resource.remover = lambda _record=record, _option=option, _fn=disable_fn: _disable_background_option_exact(
                _record, _option, _fn
            )
            resource.verifier = lambda _target=target, _name=disable_name, _fn=disable_fn: getattr(_target, _name, None) is _fn
            resource.metadata = {'module': target, 'disable_fn': disable_fn, 'key': str(option.get('key') or disable_name)}
            resource.active = True
    record['resource_counts'] = _resource_counts(child)
    return True


def _release_runtime_background_option(record: dict[str, Any], option: dict[str, Any]) -> bool:
    alias = str((record.get('spec') or {}).get('alias') or '')
    child = _TOOL_LEDGERS.get(alias)
    resource = _background_feature_record(child, record, option)
    if resource is None:
        return False
    resource.release()
    if child is not None:
        record['resource_counts'] = _resource_counts(child)
    return True


def _disable_non_always_on_replacements(record: dict[str, Any]) -> None:
    alias = str((record.get('spec') or {}).get('alias') or '')
    module = record.get('module')
    if not isinstance(module, types.ModuleType):
        return
    for key in _NON_ALWAYS_ON_REPLACEMENTS.get(alias, ()):
        option = next((item for item in _BACKGROUND_OPTIONS.get(alias, ()) if str(item.get('key') or '') == key), None)
        if option is None:
            continue
        try:
            _apply_background_option(record, option, False)
        except Exception:
            pass


def apply_background_defaults(alias: str) -> dict[str, Any] | None:
    record = get_record(alias)
    if record is None or str(record.get('status') or '') != 'READY':
        return record
    _disable_non_always_on_replacements(record)
    for option in _BACKGROUND_OPTIONS.get(str(alias or ''), ()):
        key = str(option.get('key') or '').strip()
        _apply_background_option(record, option, is_background_option_enabled(alias, key))
    return record


def set_background_options_batch(updates) -> bool:
    """Apply changed background toggles with at most one config commit.

    ``updates`` is a finite iterable of ``(alias, key, enabled)`` tuples. Values
    equal to the already-loaded state are skipped entirely: no setter callback,
    resource transition, JSON write, fsync, or atomic replace is performed.
    """
    _load_background_state()
    changed: list[tuple[str, dict[str, Any], bool]] = []
    for item in updates or ():
        try:
            alias, key, enabled = item
        except Exception:
            continue
        alias = str(alias or '').strip()
        key = str(key or '').strip()
        desired = bool(enabled)
        option = next(
            (entry for entry in _BACKGROUND_OPTIONS.get(alias, ()) if str(entry.get('key') or '') == key),
            None,
        )
        if option is None:
            continue
        state = _BACKGROUND_STATE.setdefault(alias, {})
        current = bool(state.get(key, bool(option.get('default', False))))
        if current == desired:
            continue
        state[key] = desired
        changed.append((alias, option, desired))

    if not changed:
        return True

    persisted = bool(_save_background_state(force=False))
    applied = True
    for alias, option, desired in changed:
        record = get_record(alias)
        if record is None or str(record.get('status') or '') != 'READY':
            continue
        try:
            if desired:
                if not _apply_background_option(record, option, True):
                    applied = False
                    continue
                if not _adopt_runtime_background_option(record, option):
                    # A READY tool without its exact child ledger is a degraded
                    # state. Disable immediately rather than leaving an unowned
                    # handler/msgbus/draw/keymap resource live.
                    _apply_background_option(record, option, False)
                    applied = False
            else:
                if not _release_runtime_background_option(record, option):
                    if not _apply_background_option(record, option, False):
                        applied = False
        except Exception:
            applied = False
    return bool(persisted and applied)


def set_background_option(alias: str, key: str, enabled: bool) -> bool:
    return set_background_options_batch(((alias, key, bool(enabled)),))




def _invalidate_animation_cache(reason: str) -> None:
    try:
        from . import ui
        ui.invalidate_performance_cache(reason=str(reason or 'loader'), clear=True)
    except Exception:
        pass

def _format_error(exc: BaseException) -> str:
    return f'{type(exc).__name__}: {exc}'[:_MAX_ERROR_CHARS]


def load_tool(alias: str) -> dict[str, Any] | None:
    alias = str(alias or '').strip()
    record = get_record(alias)
    if record is None:
        return None
    status = str(record.get('status') or '')
    if status == 'READY':
        return record
    if status in {'DISABLED', 'UNSUPPORTED_PLATFORM'}:
        return record
    existing_child = _TOOL_LEDGERS.get(alias)
    if existing_child is not None and not existing_child.released:
        unload_tool(alias)
        if alias in _TOOL_LEDGERS:
            record['status'] = 'FAILED'
            record['error'] = 'LifecycleError: previous exact cleanup is still pending'
            return record
    # A file load replaces bpy.app.driver_namespace, which used to strand the
    # live generation record and made this guard refuse every lazily loaded tool
    # for the rest of the session.  Re-publish the anchored record first: user
    # work must never be refused by namespace dormancy alone.
    lifecycle.ensure_current_state()
    parent = _SUITE_LEDGER
    if parent is None or not lifecycle.is_current(parent):
        record['status'] = 'FAILED'
        record['error'] = 'LifecycleError: no current Suite generation'
        return record
    child = parent.child(f'Smart Animation integrated tool: {alias}')
    module: types.ModuleType | None = None
    candidates: tuple[type, ...] = ()
    before_rna: dict = {}
    before_handlers: dict = {}
    before_keymaps: dict = {}
    optional_class_groups: dict[str, tuple[type, ...]] = {}
    record['error'] = ''
    previous_applying = bool(getattr(runtime_persistence, '_APPLYING', False))
    runtime_persistence._APPLYING = True
    try:
        spec = record.get('spec') or {}
        before_rna = _snapshot_rna()
        before_handlers = _snapshot_handlers()
        before_keymaps = _snapshot_keymaps()
        module = _import_root_module(spec, child)
        modules = _registration_modules(module)
        declared_rna = _declared_rna_targets(spec, modules)
        for owner, name in declared_rna:
            child.require(
                (owner, name) not in before_rna,
                f'foreign/existing RNA property preserved: {getattr(owner, "__name__", owner)}.{name}',
            )
        candidates, required_classes, optional_class_groups = _candidate_classes(modules)
        for cls in candidates:
            _prepare_class_for_localized_registration(cls, child.generation)
        # Do not live-replace the Suite translation domain while panels/RNA are live.

        register_fn = getattr(module, 'register', None)
        child.require(callable(register_fn), f'missing register() for {alias}')
        result = register_fn()
        child.require(result is not False, f'register() returned False for {alias}')

        # Keep the module available to explicit background option callbacks while
        # the record is still non-READY. Enabled options are part of the same
        # transaction and receive exact disable callbacks in the ledger.
        record['module'] = module
        record['optional_class_groups'] = optional_class_groups
        _disable_non_always_on_replacements(record)
        for option in _BACKGROUND_OPTIONS.get(alias, ()):
            key = str(option.get('key') or '').strip()
            enabled = is_background_option_enabled(alias, key)
            _apply_background_option(record, option, enabled)
            if enabled:
                _record_enabled_background_option(child, record, option)

        registered, props, handlers, keymaps = _verify_and_adopt_resources(
            child,
            candidates=candidates,
            required_classes=required_classes,
            declared_rna=declared_rna,
            before_rna=before_rna,
            before_handlers=before_handlers,
            before_keymaps=before_keymaps,
        )

        unregister_fn = getattr(module, 'unregister', None)
        child.require(callable(unregister_fn), f'missing unregister() for {alias}')
        # Added last so reverse rollback invokes the module-specific cleanup first;
        # exact records then remove only resources still owned by this transaction.
        child.record_callback(
            kind='tool_unregister', label=f'{alias}.unregister', identity=id(unregister_fn),
            remover=lambda _fn=unregister_fn: _call_unregister_exact(_fn),
        )

        panels, operators, menus, prefs = _categorize_classes(registered)
        record.update({
            'module': module,
            'registered_classes': list(registered),
            'panels': panels,
            'operators': operators,
            'menus': menus,
            'preferences': prefs,
            'registered_props': props,
            'registered_handlers': handlers,
            'registered_keymaps': keymaps,
            'imported_modules': [r.label for r in child.records if r.kind == 'module'],
            'optional_class_groups': optional_class_groups,
        })

        runtime_persistence.track_registered_props(props)
        runtime_persistence.apply_saved_runtime_properties(
            context=getattr(bpy, 'context', None), force=True,
        )
        child.commit()
        _TOOL_LEDGERS[alias] = child
        record['resource_counts'] = _resource_counts(child)
        record['status'] = 'READY'
        _invalidate_animation_cache(f'load:{alias}')
        return record
    except Exception as exc:
        _adopt_partial_resources_after_failure(
            child, candidates=candidates, before_rna=before_rna,
            before_handlers=before_handlers, before_keymaps=before_keymaps,
        )
        # If unregister was already recorded, reverse rollback invokes that exact
        # callback first.  Otherwise call the exact module callback once before the
        # transaction releases individually captured resources.
        has_unregister_record = any(item.kind == 'tool_unregister' for item in child.records)
        if not has_unregister_record:
            try:
                unregister_fn = getattr(module, 'unregister', None) if module is not None else None
                if callable(unregister_fn):
                    _call_unregister_exact(unregister_fn)
            except Exception:
                pass
        child.rollback()
        cleanup_complete = bool(child.released)
        if cleanup_complete:
            _TOOL_LEDGERS.pop(alias, None)
        else:
            # Preserve the exact child ledger and module identity for one later
            # bounded cleanup retry. Never rediscover by package/name.
            _TOOL_LEDGERS[alias] = child
        _invalidate_animation_cache(f'load_failed:{alias}')
        error_text = _format_error(exc)
        if not cleanup_complete:
            error_text = (error_text + '; exact cleanup deferred')[:_MAX_ERROR_CHARS]
        record.update({
            'status': 'FAILED', 'error': error_text,
            'module': None if cleanup_complete else module,
            'registered_classes': [] if cleanup_complete else [
                item.metadata.get('class') for item in child.records
                if item.active and item.kind == 'class' and item.metadata.get('class') is not None
            ],
            'panels': [], 'operators': [], 'menus': [], 'preferences': [],
            'registered_props': [], 'registered_handlers': [],
            'registered_keymaps': [],
            'imported_modules': [] if cleanup_complete else [
                item.label for item in child.records if item.active and item.kind == 'module'
            ],
            'resource_counts': {} if cleanup_complete else _resource_counts(child),
            'optional_class_groups': {} if cleanup_complete else optional_class_groups,
        })
        return record
    finally:
        runtime_persistence._APPLYING = previous_applying


def _resource_counts(ledger: lifecycle.GenerationLedger) -> dict[str, int]:
    counts: dict[str, int] = {}
    for record in ledger.records:
        counts[record.kind] = counts.get(record.kind, 0) + 1
    return counts


def _call_unregister_exact(unregister_fn: Callable[..., Any]) -> None:
    try:
        result = unregister_fn()
        if result is False:
            raise lifecycle.LifecycleError('unregister() returned False')
    except Exception:
        # The exact ledger is authoritative and continues reverse cleanup even if
        # a bundled unregister implementation is not idempotent.
        pass


def unload_tool(alias: str) -> dict[str, Any] | None:
    """Release one lazy tool by its captured exact child ledger.

    A failed exact remover remains retryable; the ledger/module identity is not
    discarded and no foreign module, class, RNA, keymap, handler, or msgbus
    resource is scanned or removed by name.
    """
    alias = str(alias or '').strip()
    record = get_record(alias)
    if record is None:
        return None
    child = _TOOL_LEDGERS.get(alias)
    module = record.get('module')
    owner_prefix = str(getattr(module, '__name__', '') or '')
    if child is not None:
        try:
            modal_registry.cancel_all_active(
                generation=child.generation, owner_prefix=owner_prefix or None,
                context=getattr(bpy, 'context', None),
            )
        except Exception as exc:
            child.note_failure(f'modal cancellation failed during unload: {type(exc).__name__}: {exc}')
        child.rollback()
        if not child.released:
            record.update({
                'status': 'FAILED',
                'error': 'LifecycleError: exact cleanup deferred',
                'resource_counts': _resource_counts(child),
            })
            _invalidate_animation_cache(f'unload_deferred:{alias}')
            return record
        _TOOL_LEDGERS.pop(alias, None)

    _invalidate_animation_cache(f'unload:{alias}')
    record.update({
        'module': None, 'registered_classes': [], 'panels': [], 'operators': [],
        'menus': [], 'preferences': [], 'registered_props': [],
        'registered_handlers': [], 'registered_keymaps': [], 'imported_modules': [],
        'resource_counts': {}, 'error': '',
        'optional_class_groups': {},
    })
    _apply_base_status(record)
    return record


def register_all() -> list[dict[str, Any]]:
    initialize_records(force=False, ledger=_SUITE_LEDGER)
    for record in tuple(_RECORDS):
        if str(record.get('status') or '') == 'AVAILABLE':
            load_tool(str((record.get('spec') or {}).get('alias') or ''))
    return get_records()


def unregister_all() -> bool:
    global _SUITE_LEDGER
    healthy = True
    for alias in reversed(tuple(_TOOL_LEDGERS)):
        unload_tool(alias)
        if alias in _TOOL_LEDGERS:
            healthy = False
    if commit_dirty_state() is False:
        healthy = False
    if not _TOOL_LEDGERS:
        clear_records()
        registry.clear_cache()
        _SUITE_LEDGER = None
    return healthy
