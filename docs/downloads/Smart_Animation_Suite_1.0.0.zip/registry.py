# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

SUITE_META = {
    'smart_animation_suite': ('Smart Animation', ''),
}

SUITE_ORDER: tuple[str, ...] = tuple(SUITE_META.keys())

TOOL_META: dict[str, dict[str, Any]] = {
    'offset': {
        'display_name': 'Ani Offset',
        'outer_zip': 'add-on-ani-offset-v3.2.2.zip',
        'spaces': ['VIEW_3D'],
        'overview_en': 'Capture a reference pose, then propagate the transform delta to keyed pose-bone channels inside the selected Action and slot frame range.',
        'overview_ja': '基準ポーズを記録し、変更後の差分を選択中 Action / スロットの指定フレーム範囲へ一括反映するポーズ補正ツールです。',
        'usage_en': 'Select an armature in Pose Mode, choose the target Action and slot, set the frame range, capture the reference pose, move the bones, then run Propagate Offset once.',
        'usage_ja': 'Pose モードのアーマチュアを選択し、対象 Action とスロット、反映範囲を指定して基準ポーズを記録し、ボーンを動かしたあとで Propagate Offset を 1 回実行してください。',
    },
    'animall': {
        'display_name': 'AnimAll',
        'outer_zip': 'add-on-animall-v0.14.0.zip',
        'spaces': ['VIEW_3D'],
        'overview_en': 'Animate mesh, curve, lattice, UV, attribute, bevel, crease, and other element-level data that standard object transforms do not cover.',
        'overview_ja': '通常のオブジェクト変形では扱えない頂点・UV・属性・ベベル・クリースなど、要素単位データへキーフレームを打てるツールです。',
        'usage_en': 'Enter the supported edit mode, enable the element channels you want, edit the data, then insert or delete keys from the migrated AnimAll panel or operators.',
        'usage_ja': '対応する編集モードに入り、記録したい要素チャンネルを有効にしてデータを編集し、移植済み AnimAll パネルまたはオペレーターからキーの挿入・削除を行ってください。',
    },
    'transform_offset': {
        'display_name': 'Animation Transform Offset',
        'outer_zip': 'add-on-animation-transform-offset-v1.0.0.zip',
        'spaces': ['VIEW_3D'],
        'overview_en': 'Move, rotate, or scale animated objects while applying the same transform offset to their existing location, rotation, or scale keyframes.',
        'overview_ja': 'アニメーション済みオブジェクトを移動・回転・拡縮しつつ、その差分を既存の位置・回転・スケールキーへまとめて反映するツールです。',
        'usage_en': 'Select animated objects, run Grab / Rotate / Scale Offset or use the bundled Shift+G / Shift+R / Shift+S shortcuts, then confirm the transform to bake the delta into the action.',
        'usage_ja': 'アニメーション済みオブジェクトを選択し、Grab / Rotate / Scale Offset か Shift+G / Shift+R / Shift+S を実行して変形を確定すると、その差分がアクションへ焼き込まれます。',
    },
    'bezier_curve_editor': {
        'display_name': 'Bezier Curve Editor Overlay',
        'outer_zip': 'add-on-bezier-curve-editor-v1.0.4.zip',
        'spaces': ['DOPESHEET_EDITOR'],
        'overview_en': 'Display an overlay editor for selected keyframe handles so you can adjust Bezier easing directly with an on-screen curve widget.',
        'overview_ja': '選択キーフレームのハンドルをオーバーレイ上で直接編集し、ベジェ補間のイージング形状を視覚的に調整できるツールです。',
        'usage_en': 'Open the migrated Bezier Curve Editor panel in the relevant animation editor, select keyframes, then use the overlay controls to reshape easing and handle behavior.',
        'usage_ja': '対応するアニメーションエディターで移植済み Bezier Curve Editor パネルを開き、キーフレームを選択してオーバーレイ操作でイージングやハンドル挙動を調整してください。',
    },
    'camera_shakify': {
        'display_name': 'Camera Shakify',
        'outer_zip': 'add-on-camera-shakify-v0.5.1.zip',
        'spaces': ['PROPERTIES'],
        'overview_en': 'Add layered camera shake, wobble, and captured handheld motion patterns to cameras through reusable shake actions and controls.',
        'overview_ja': '再利用可能なシェイクアクションを使い、カメラへ揺れ・手持ち風モーション・ワブルを重ね掛けできるカメラ演出ツールです。',
        'usage_en': 'Select a camera, open the migrated Camera Shakify controls, choose a shake preset or generated action, then adjust amplitude, timing, and blend settings as needed.',
        'usage_ja': 'カメラを選択して移植済み Camera Shakify 設定を開き、プリセットまたは生成アクションを選んでから、強さ・タイミング・ブレンドを調整してください。',
    },
    'easeit': {
        'display_name': 'EaseIt',
        'outer_zip': 'add-on-easeit-v1.0.1.zip',
        'spaces': ['DOPESHEET_EDITOR', 'GRAPH_EDITOR'],
        'overview_en': 'Apply curated easing presets to selected animation keyframes from icon-based controls in the Graph Editor or related animation editors.',
        'overview_ja': 'グラフエディターなどで選択したキーフレームへ、アイコン付きプリセットから各種イージングを素早く適用できるツールです。',
        'usage_en': 'Select editable keyframes in the Graph Editor, open the migrated EaseIt panel, then click a preset icon to update the selected keyframe easing.',
        'usage_ja': 'グラフエディターで編集可能なキーフレームを選択し、移植済み EaseIt パネルからプリセットアイコンを押してイージングを適用してください。',
    },
    'sakura_poselib': {
        'display_name': 'Sakura PoseLib',
        'outer_zip': 'add-on-sakura-poselib-v1.4.4.zip',
        'spaces': ['PROPERTIES', 'VIEW_3D'],
        'overview_en': 'Manage reusable armature pose books, pose sliders, conversion utilities, and pose maintenance helpers for character animation workflows.',
        'overview_ja': 'アーマチュア用の再利用ポーズ集、スライダー制御、変換補助、保守機能をまとめたキャラクター向けポーズライブラリツールです。',
        'usage_en': 'Select an armature, open the migrated Sakura PoseLib panels, create or update a pose book, then store, organize, apply, mix, or convert poses as needed.',
        'usage_ja': 'アーマチュアを選択して移植済み Sakura PoseLib パネルを開き、ポーズブックを作成・更新したうえで、ポーズの保存・整理・適用・ミックス・変換を行ってください。',
    },
    'simplify_curves_plus': {
        'display_name': 'Simplify Curves+',
        'outer_zip': 'add-on-simplify-curves-plus-v1.1.3.zip',
        'spaces': ['GRAPH_EDITOR', 'VIEW_3D'],
        'overview_en': 'Reduce point counts in curve objects and selected animation F-Curves with distance-based or curvature-based simplification.',
        'overview_ja': '距離基準または曲率基準の簡略化で、カーブオブジェクトや選択 F-Curve の点数を削減する軽量化ツールです。',
        'usage_en': 'Select the target curve object or animation F-Curves, choose the simplification mode and tolerance, then execute the migrated Simplify operator.',
        'usage_ja': '対象のカーブオブジェクトまたはアニメーション F-Curve を選択し、簡略化モードと許容値を決めてから移植済み Simplify オペレーターを実行してください。',
    },
    'stop_motion_style_animator': {
        'display_name': 'Stop Motion Style Animator',
        'outer_zip': 'add-on-stop-motion-style-animator-v0.3.1.zip',
        'spaces': ['DOPESHEET_EDITOR'],
        'overview_en': 'Convert animation to a stepped stop-motion look by thinning keys, forcing constant interpolation, and optionally adding jitter noise.',
        'overview_ja': 'キーの間引き、コンスタント補間化、任意のジッターノイズ付与により、アニメーションをストップモーション風に変換するツールです。',
        'usage_en': 'Select an animated object, set the frame step, offset, and jitter strength, then run Apply Stop Motion. Use Reset / Clean to remove the generated jitter.',
        'usage_ja': 'アニメーション済みオブジェクトを選択し、フレーム間隔・オフセット・ジッター強度を設定して Apply Stop Motion を実行してください。生成したジッターは Reset / Clean で除去できます。',
    },
    'storytools': {
        'display_name': 'Storytools - Storyboard Tools',
        'outer_zip': 'add-on-storytools-v3.3.2.zip',
        'spaces': ['DOPESHEET_EDITOR', 'VIEW_3D'],
        'overview_en': 'Provide storyboard-oriented Grease Pencil, camera, object, map, and setup tools for rapid shot planning and previs workflows.',
        'overview_ja': 'Grease Pencil、カメラ、オブジェクト、マップ、初期設定をまとめ、ショット設計やプリビズを素早く進めるためのストーリーボード支援ツール群です。',
        'usage_en': 'Open the migrated Storytools panels or menus from the Overview Task N-panel section and use the sub-tools that match your storyboard task, such as camera setup, layer sync, map placement, or shot organization.',
        'usage_ja': '概要タスクのNパネル表示から移植済み Storytools パネルやメニューを開き、カメラ設定、レイヤー同期、マップ配置、ショット整理など、目的に合うサブツールを使用してください。',
    },
}

TOOL_ALIASES: tuple[str, ...] = tuple(
    alias for alias in TOOL_META
    if (Path(__file__).resolve().parent / alias / '__init__.py').is_file()
)

# Transient interaction state of the bundled tools; nothing a user should edit.
INTERNAL_RUNTIME_PROPERTIES = frozenset({
    'tlfc_h1x', 'tlfc_h1y', 'tlfc_h2x', 'tlfc_h2y',
    'tlfc_view_zoom', 'tlfc_view_pan_x', 'tlfc_view_pan_y',
    'tlfc_pan_start_x', 'tlfc_pan_start_y', 'tlfc_pan_origin_x', 'tlfc_pan_origin_y',
    'tlfc_mouse_editing', 'tlfc_hover_sidebar', 'tlfc_hover_sidebar_edge', 'tlfc_dragging_sidebar',
    'tlfc_hover_button', 'tlfc_pressed_button', 'tlfc_hover_handle',
})

TOOL_OVERVIEW_GROUPS: dict[str, str] = {
    'offset': 'Pose',
    'animall': 'Key Data',
    'transform_offset': 'Transform',
    'bezier_curve_editor': 'Curve',
    'camera_shakify': 'Camera',
    'easeit': 'Timing',
    'sakura_poselib': 'Pose',
    'simplify_curves_plus': 'Curve',
    'stop_motion_style_animator': 'Timing',
    'storytools': 'Storyboard',
}

TOOL_OVERVIEW_GROUP_ORDER: tuple[str, ...] = (
    'Pose',
    'Key Data',
    'Transform',
    'Timing',
    'Curve',
    'Camera',
    'Storyboard',
)


def overview_task_identifier(alias: str) -> str:
    safe = sanitize_alias(alias).upper()
    return f'INT_TOOL_{safe}'


def overview_task_alias(identifier: str) -> str:
    text = str(identifier or '').strip()
    if not text.startswith('INT_TOOL_'):
        return ''
    wanted = text[len('INT_TOOL_'):].lower()
    for alias in TOOL_ALIASES:
        if sanitize_alias(alias).lower() == wanted:
            return alias
    return wanted


def overview_group_identifier(group: str) -> str:
    safe = sanitize_alias(group).upper()
    return f'INT_GROUP_{safe}'


def overview_group_name(identifier: str) -> str:
    text = str(identifier or '').strip()
    if not text.startswith('INT_GROUP_'):
        return ''
    wanted = text[len('INT_GROUP_'):].lower()
    for group in TOOL_OVERVIEW_GROUP_ORDER:
        if sanitize_alias(group).lower() == wanted:
            return group
    return ''


def overview_group_aliases(group: str) -> tuple[str, ...]:
    group = str(group or '').strip()
    return tuple(
        alias for alias in sorted(TOOL_ALIASES, key=_overview_task_sort_key)
        if TOOL_OVERVIEW_GROUPS.get(alias, 'Tools') == group
    )


def all_overview_group_aliases() -> tuple[str, ...]:
    aliases: list[str] = []
    for group in TOOL_OVERVIEW_GROUP_ORDER:
        aliases.extend(overview_group_aliases(group))
    return tuple(aliases)


def _overview_task_sort_key(alias: str) -> tuple[int, str]:
    group = TOOL_OVERVIEW_GROUPS.get(alias, 'Tools')
    try:
        group_order = TOOL_OVERVIEW_GROUP_ORDER.index(group)
    except ValueError:
        group_order = len(TOOL_OVERVIEW_GROUP_ORDER)
    display = str((TOOL_META.get(alias) or {}).get('display_name') or alias).lower()
    return group_order, display


def integrated_overview_task_items() -> tuple[tuple[str, str, str], ...]:
    items: list[tuple[str, str, str]] = []
    for alias in sorted(TOOL_ALIASES, key=_overview_task_sort_key):
        meta = TOOL_META.get(alias) or {}
        group = str(TOOL_OVERVIEW_GROUPS.get(alias, 'Tools')).strip() or 'Tools'
        display_name = str(meta.get('display_name') or alias).strip()
        overview = str(meta.get('overview_en') or meta.get('description') or display_name).strip()
        usage = str(meta.get('usage_en') or '').strip()
        description = overview
        if usage:
            description = f'{overview} How to use: {usage}' if overview else usage
        items.append((overview_task_identifier(alias), f'{group}: {display_name}', description))
    return tuple(items)


def integrated_overview_group_items() -> tuple[tuple[str, str, str], ...]:
    descriptions = {
        'Pose': 'Show migrated pose-library and pose-offset tools in the N-panel.',
        'Key Data': 'Show migrated mesh, curve, UV, attribute, and element-keying tools in the N-panel.',
        'Transform': 'Show migrated transform-offset tools for animated objects in the N-panel.',
        'Timing': 'Show migrated timing, easing, and stepped-animation tools in the N-panel.',
        'Curve': 'Show migrated curve-editing and curve-simplification tools in the N-panel.',
        'Camera': 'Show migrated camera-motion and camera-shake tools in the N-panel.',
        'Storyboard': 'Show migrated storyboard, Grease Pencil, camera, map, and shot-planning tools in the N-panel.',
    }
    items: list[tuple[str, str, str]] = []
    for group in TOOL_OVERVIEW_GROUP_ORDER:
        if overview_group_aliases(group):
            items.append((overview_group_identifier(group), group, descriptions.get(group, f'Show migrated {group} tools in the N-panel.')))
    return tuple(items)

_CACHE: list[dict[str, Any]] | None = None


def package_root() -> Path:
    return Path(__file__).resolve().parent



def clear_cache() -> None:
    global _CACHE
    _CACHE = None



def sanitize_alias(filename: str) -> str:
    text = str(filename or '').strip()
    if text.lower().endswith('.zip'):
        text = text[:-4]
    text = text.replace(' ', '_')
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    if not text:
        text = 'tool'
    if not re.match(r'[A-Za-z_]', text):
        text = '_' + text
    return text



def tool_enabled_prop(alias: str) -> str:
    return f'enable_tool_{sanitize_alias(alias)}'



def tool_expand_prop(alias: str) -> str:
    return f'show_tool_{sanitize_alias(alias)}'




def tool_dir(alias: str) -> Path:
    return package_root() / str(alias or '').strip()



def _read_bl_info_name_and_description(py_path: Path) -> tuple[str, str]:
    try:
        text = py_path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return '', ''
    name_match = re.search(r'"name"\s*:\s*"([^"]+)"', text)
    desc_match = re.search(r'"description"\s*:\s*"([^"]+)"', text)
    return (name_match.group(1).strip() if name_match else '', desc_match.group(1).strip() if desc_match else '')



def build_specs(force: bool = False) -> list[dict[str, Any]]:
    global _CACHE
    if _CACHE is not None and not force:
        return list(_CACHE)

    results: list[dict[str, Any]] = []
    suite_key = 'smart_animation_suite'
    suite_name = SUITE_META[suite_key][0]

    for alias in TOOL_ALIASES:
        meta = dict(TOOL_META.get(alias) or {})
        addon_dir = tool_dir(alias)
        init_path = addon_dir / '__init__.py'
        if not addon_dir.is_dir() or not init_path.exists():
            continue

        name, init_description = _read_bl_info_name_and_description(init_path)
        display_name = str(meta.get('display_name') or name or alias).strip()
        overview_en = str(meta.get('overview_en') or meta.get('description') or init_description or display_name).strip()
        overview_ja = str(meta.get('overview_ja') or overview_en or display_name).strip()
        usage_en = str(meta.get('usage_en') or '').strip()
        usage_ja = str(meta.get('usage_ja') or '').strip()
        description = str(meta.get('description') or overview_en or init_description or display_name).strip()
        description_ja = str(meta.get('description_ja') or overview_ja or description).strip()

        spec = {
            'alias': alias,
            'outer_zip': str(meta.get('outer_zip') or f'{alias}.zip'),
            'display_name': display_name,
            'suite': suite_key,
            'suite_name': suite_name,
            'load': bool(meta.get('load', True)),
            'note': str(meta.get('note') or ''),
            'duplicate_of': str(meta.get('duplicate_of') or ''),
            'superseded_by': str(meta.get('superseded_by') or ''),
            'spaces': list(meta.get('spaces') or []),
            'description': description,
            'description_ja': description_ja,
            'overview_en': overview_en,
            'overview_ja': overview_ja,
            'usage_en': usage_en,
            'usage_ja': usage_ja,
            'addon_dir': str(addon_dir),
            'src_dir': str(addon_dir),
            'source_root': '',
            'import_mode': 'root_package',
            'init_relpath': '__init__.py',
            'search_root': '',
        }
        results.append(spec)

    _CACHE = list(results)
    return list(results)
