# ============================================================================
# Smart Animation
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
# ============================================================================

import bpy
from collections import OrderedDict
from contextlib import contextmanager
import difflib
import hashlib
import json
import math
import re
from pathlib import Path
from bpy.types import PropertyGroup, UIList
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)

from .translation import (
    sas_is_japanese,
    sas_text,
    sas_info,
    TAB_ITEMS,
    BAKE_RANGE_ITEMS,
)
from . import registry
from .storage import addon_data_path

from .action_compat import (
    action_curve_count,
    assign_action_to_datablock,
    clear_action_from_datablock,
    ensure_action_fcurve,
    ensure_action_slot,
    find_action_fcurve,
    iter_action_fcurves,
    remove_action_fcurve,
    sync_nla_strip_action_slot,
)

# General utilities
# -----------------------------------------------------------------------------

def active_object(context):
    try:
        obj = getattr(context, 'active_object', None) or getattr(context, 'object', None)
        if obj is None:
            return None
        # After object.select_all(action='DESELECT'), Blender can still expose a
        # stale active object while UI panels are redrawing. Treat an unselected
        # Object-mode active object as absent so draw code does not pass its RNA
        # pointers into template widgets during mode changes.
        if str(getattr(context, 'mode', '') or '') == 'OBJECT':
            try:
                if hasattr(obj, 'select_get') and not bool(obj.select_get()):
                    return None
            except Exception:
                return None
        return obj
    except Exception:
        return None


def active_action(context, obj=None):
    obj = obj or active_object(context)
    try:
        anim_data = getattr(obj, 'animation_data', None) if obj else None
        action = getattr(anim_data, 'action', None) if anim_data else None
        return action if action else None
    except Exception:
        return None


def current_targets(context):
    try:
        if str(getattr(context, 'mode', '') or '') == 'POSE':
            return list(getattr(context, 'selected_pose_bones', None) or [])
        return list(getattr(context, 'selected_objects', None) or [])
    except Exception:
        return []


def fcurve_is_editable(fcurve, settings=None):
    if fcurve is None:
        return False
    if settings is None:
        return True
    if getattr(settings, "skip_locked_curves", True) and getattr(fcurve, "lock", False):
        return False
    if getattr(settings, "skip_muted_curves", True) and getattr(fcurve, "mute", False):
        return False
    if getattr(settings, "skip_hidden_curves", True) and getattr(fcurve, "hide", False):
        return False
    return True



def filter_editable_fcurves(curves, settings=None):
    return [fcurve for fcurve in list(curves or []) if fcurve_is_editable(fcurve, settings=settings)]



def selected_fcurves(context, action, obj=None):
    settings = context.scene.sas_settings
    curves = iter_action_fcurves(action, datablock=obj or active_object(context))
    if settings.only_selected_curves:
        curves = [fc for fc in curves if fc.select]
    return filter_editable_fcurves(curves, settings)


_backup_batches = set()


@contextmanager
def batch_action_backup(context, action, reason):
    """Use one pre-edit snapshot for nested operations on the same Action."""
    backup = ensure_action_backup(context, reason, action=action)
    if backup is None:
        yield
        return
    action_id = action.as_pointer()
    _backup_batches.add(action_id)
    try:
        yield
    finally:
        _backup_batches.remove(action_id)


def ensure_action_backup(context, reason="backup", obj=None, action=None):
    settings = context.scene.sas_settings
    action = action or active_action(context, obj=obj)
    if not settings.auto_backup_action or action is None or action.as_pointer() in _backup_batches:
        return None
    base = f"{action.name}_SAS_{reason.upper()}"
    name = base
    index = 1
    while bpy.data.actions.get(name):
        name = f"{base}_{index:02d}"
        index += 1
    backup = action.copy()
    backup.name = name
    backup.use_fake_user = True
    add_log(context, "INFO", f"Created action backup '{name}'.", f"アクションバックアップ「{name}」を作成しました。")
    return backup


def discard_action_backup(context, backup):
    """Remove a backup made for an edit that ended up changing nothing."""
    if backup is None or bpy.data.actions.get(backup.name) is not backup:
        return
    name = backup.name
    bpy.data.actions.remove(backup)
    add_log(context, "INFO", f"Removed unused action backup '{name}'.", f"未使用のアクションバックアップ「{name}」を削除しました。")


def ensure_object_animation_data(obj):
    if obj and obj.animation_data is None:
        obj.animation_data_create()
    return obj.animation_data if obj else None


def count_keyframes(action, obj=None):
    if not action:
        return 0
    return sum(len(fc.keyframe_points) for fc in iter_action_fcurves(action, datablock=obj))


def action_stats(action, obj=None):
    if not action:
        return {"fcurves": 0, "keys": 0}
    return {"fcurves": action_curve_count(action, datablock=obj), "keys": count_keyframes(action, obj=obj)}


def unique_action_name(base_name):
    name = base_name
    index = 1
    while bpy.data.actions.get(name):
        name = f"{base_name}_{index:02d}"
        index += 1
    return name


def get_action_density(action, obj=None):
    curve_count = action_curve_count(action, datablock=obj)
    if not action or curve_count == 0:
        return 0.0, "None"
    density = count_keyframes(action, obj=obj) / max(1, curve_count)
    if density < 2:
        return density, "Sparse"
    if density < 20:
        return density, "Balanced"
    if density < 60:
        return density, "Dense"
    return density, "Very Dense"


def health_score_from_issues(issues):
    score = 100
    for level, _en, _ja in issues:
        if level == "ERROR":
            score -= 25
        elif level == "WARN":
            score -= 10
        else:
            score -= 2
    return max(0, min(100, score))


def is_sas_retarget_constraint(constraint_or_name):
    name = constraint_or_name if isinstance(constraint_or_name, str) else getattr(constraint_or_name, "name", "")
    return name == "SAS_LiveRetarget" or name.startswith("SAS_RETARGET_")


def count_sas_retarget_constraints(target_obj):
    if not target_obj or target_obj.type != 'ARMATURE' or not getattr(target_obj, "pose", None):
        return 0
    total = 0
    for pose_bone in target_obj.pose.bones:
        total += sum(1 for constraint in pose_bone.constraints if is_sas_retarget_constraint(constraint))
    return total


def strip_sas_retarget_constraints(target_obj):
    if not target_obj or target_obj.type != 'ARMATURE' or not getattr(target_obj, "pose", None):
        return 0
    removed = 0
    for pose_bone in target_obj.pose.bones:
        for constraint in list(pose_bone.constraints):
            if is_sas_retarget_constraint(constraint):
                pose_bone.constraints.remove(constraint)
                removed += 1
    return removed


def get_or_create_action_for_object(obj, base_name=None):
    anim_data = ensure_object_animation_data(obj)
    if anim_data.action:
        return anim_data.action
    action = bpy.data.actions.new(name=unique_action_name(base_name or f"{obj.name}_Action"))
    assign_action_to_datablock(obj, action, name_hint=obj.name)
    return action


def push_action_to_nla_strip(obj, action, track_name_prefix="SAS", blend_type='REPLACE'):
    anim_data = ensure_object_animation_data(obj)
    track = anim_data.nla_tracks.new()
    track.name = unique_nla_track_name(anim_data, f"{track_name_prefix}_{action.name}")
    start = int(math.floor(action.frame_range[0])) if action and action.frame_range else 1
    end = int(math.ceil(action.frame_range[1])) if action and action.frame_range else start
    strip = track.strips.new(action.name, start, action)
    strip.frame_start = start
    strip.frame_end = max(start + 1, start + (end - start))
    try:
        strip.blend_type = blend_type
    except Exception:
        pass
    sync_nla_strip_action_slot(strip, obj, action=action)
    return track, strip


def list_mapped_bone_items(settings):
    return [item for item in settings.bone_map if item.target_name]


def format_log_message(item, context):
    return sas_text(item.raw_en or item.message, item.raw_ja or item.message, context)


def nla_track_count(obj):
    if obj and obj.animation_data:
        return len(obj.animation_data.nla_tracks)
    return 0


def unique_snapshot_name(scene, base_name):
    settings = scene.sas_settings
    existing = {snap.name for snap in settings.pose_snapshots}
    if not base_name:
        base_name = f"Pose_{len(settings.pose_snapshots) + 1:02d}"
    name = base_name
    index = 1
    while name in existing:
        name = f"{base_name}_{index:02d}"
        index += 1
    return name


def unique_selection_set_name(scene, base_name):
    settings = scene.sas_settings
    existing = {item.name for item in settings.selection_sets}
    if not base_name:
        base_name = f"Selection_{len(settings.selection_sets) + 1:02d}"
    name = base_name
    index = 1
    while name in existing:
        name = f"{base_name}_{index:02d}"
        index += 1
    return name


def bone_rotation_data(pose_bone):
    mode = pose_bone.rotation_mode
    if mode == 'QUATERNION':
        return list(pose_bone.rotation_quaternion), mode
    if mode == 'AXIS_ANGLE':
        return list(pose_bone.rotation_axis_angle), mode
    return list(pose_bone.rotation_euler), mode


def restore_bone_rotation(pose_bone, values, mode):
    try:
        pose_bone.rotation_mode = mode
    except Exception:
        pass
    if mode == 'QUATERNION':
        pose_bone.rotation_quaternion = values
    elif mode == 'AXIS_ANGLE':
        pose_bone.rotation_axis_angle = values
    else:
        pose_bone.rotation_euler = values


def sanitize_name(name, strip_namespaces=True):
    text = name.strip()
    if strip_namespaces:
        text = text.split("|")[-1]
        text = text.split(":")[-1]
    return text


def normalize_name(name, strip_namespaces=True, use_side_aliases=True):
    lowered = sanitize_name(name, strip_namespaces=strip_namespaces).lower().strip()
    lowered = lowered.replace("def-", "").replace("org-", "").replace("mch-", "").replace("ctrl-", "")
    lowered = lowered.replace("bone.", "")
    side = ""

    if use_side_aliases:
        patterns = [
            (".l", "l"), ("_l", "l"), ("-l", "l"), (" l", "l"),
            (".r", "r"), ("_r", "r"), ("-r", "r"), (" r", "r"),
            ("left", "l"), ("right", "r"),
            ("_left", "l"), ("_right", "r"),
            ("-left", "l"), ("-right", "r"),
        ]
        for suffix, side_value in patterns:
            if lowered.endswith(suffix):
                side = side_value
                lowered = lowered[:-len(suffix)]
                break
        if not side:
            prefix_patterns = [
                ("l_", "l"), ("r_", "r"), ("left_", "l"), ("right_", "r"),
                ("l-", "l"), ("r-", "r"), ("left-", "l"), ("right-", "r"),
            ]
            for prefix, side_value in prefix_patterns:
                if lowered.startswith(prefix):
                    side = side_value
                    lowered = lowered[len(prefix):]
                    break

    lowered = lowered.replace(" ", "").replace("_", "").replace("-", "").replace(".", "")
    aliases = {
        "upperarm": "arm",
        "uparm": "arm",
        "lowerarm": "forearm",
        "forearmtwist": "forearm",
        "handik": "hand",
        "thigh": "upleg",
        "upperleg": "upleg",
        "shin": "lowerleg",
        "calf": "lowerleg",
        "leglower": "lowerleg",
        "pelvis": "hips",
        "hip": "hips",
        "rootmotion": "root",
        "rootctrl": "root",
        "spine1": "spine",
        "spine2": "spine",
        "spine3": "spine",
        "spine4": "spine",
        "neck1": "neck",
        "neck2": "neck",
        "clavicle": "shoulder",
        "collar": "shoulder",
        "footik": "foot",
        "toeend": "toe",
        "ball": "toe",
        "wrist": "hand",
    }
    lowered = aliases.get(lowered, lowered)
    return lowered, side


def build_target_name_index(armature_obj, strip_namespaces=True, use_side_aliases=True):
    exact = {}
    candidates = []
    for bone in armature_obj.data.bones:
        base, side = normalize_name(bone.name, strip_namespaces=strip_namespaces, use_side_aliases=use_side_aliases)
        exact.setdefault((base, side), bone.name)
        exact.setdefault((base, ""), bone.name)
        exact.setdefault((base[:10], side), bone.name)
        exact.setdefault((base[:10], ""), bone.name)
        candidates.append({"name": bone.name, "base": base, "side": side})
    return {"exact": exact, "candidates": candidates}


def match_target_bone(source_name, target_index, strip_namespaces=True, use_side_aliases=True):
    base, side = normalize_name(source_name, strip_namespaces=strip_namespaces, use_side_aliases=use_side_aliases)
    exact = target_index.get("exact", target_index)
    if (base, side) in exact:
        return exact[(base, side)], 1.0, "exact"
    if (base, "") in exact:
        return exact[(base, "")], 0.82, "base-only"
    short = base[:10]
    if (short, side) in exact:
        return exact[(short, side)], 0.7, "short-name"
    if (short, "") in exact:
        return exact[(short, "")], 0.6, "short-base"

    best_name = ""
    best_score = 0.0
    for entry in target_index.get("candidates", []):
        score = difflib.SequenceMatcher(None, base, entry["base"]).ratio()
        if side and entry["side"]:
            if side == entry["side"]:
                score += 0.08
            else:
                score -= 0.18
        if base.startswith(entry["base"]) or entry["base"].startswith(base):
            score += 0.04
        if score > best_score:
            best_score = score
            best_name = entry["name"]

    if best_score >= 0.90:
        return best_name, min(0.95, best_score), "fuzzy-strong"
    if best_score >= 0.78:
        return best_name, min(0.89, best_score), "fuzzy"
    if best_score >= 0.68:
        return best_name, min(0.79, best_score), "weak-fuzzy"
    return "", 0.0, "unmatched"


def safe_remove_keyframe_points(fcurve, indices):
    removed = 0
    for idx in sorted(set(indices), reverse=True):
        if 0 <= idx < len(fcurve.keyframe_points):
            fcurve.keyframe_points.remove(fcurve.keyframe_points[idx])
            removed += 1
    if removed:
        fcurve.update()
    return removed


def is_rotation_euler_data_path(data_path):
    return isinstance(data_path, str) and data_path.endswith("rotation_euler")



def preserve_extrema_indices(points, threshold=1e-8):
    keep = set()
    if len(points) <= 2:
        return keep
    for idx in range(1, len(points) - 1):
        prev_v = float(points[idx - 1][1])
        curr_v = float(points[idx][1])
        next_v = float(points[idx + 1][1])
        left = curr_v - prev_v
        right = next_v - curr_v
        if (left > threshold and right < -threshold) or (left < -threshold and right > threshold):
            keep.add(idx)
        elif abs(left) > threshold and abs(right) <= threshold:
            keep.add(idx)
        elif abs(left) <= threshold and abs(right) > threshold:
            keep.add(idx)
    return keep



def simplify_point_indices(points, epsilon, preserve_extrema=True, threshold=1e-8):
    if len(points) <= 2:
        return set(range(len(points)))

    keep = {0, len(points) - 1}
    if preserve_extrema:
        keep.update(preserve_extrema_indices(points, threshold=threshold))

    def recurse(start_idx, end_idx):
        if end_idx - start_idx <= 1:
            return
        max_dev = -1.0
        max_index = None
        f1, v1 = points[start_idx]
        f2, v2 = points[end_idx]
        for idx in range(start_idx + 1, end_idx):
            fi, vi = points[idx]
            pred = v1 if abs(f2 - f1) < 1e-8 else v1 + (v2 - v1) * ((fi - f1) / (f2 - f1))
            dev = abs(vi - pred)
            if dev > max_dev:
                max_dev = dev
                max_index = idx
        if max_index is not None and max_dev > epsilon:
            keep.add(max_index)
            recurse(start_idx, max_index)
            recurse(max_index, end_idx)

    protected = sorted(keep)
    for start_idx, end_idx in zip(protected, protected[1:]):
        recurse(start_idx, end_idx)
    if protected[0] != 0:
        recurse(0, protected[0])
    if protected[-1] != len(points) - 1:
        recurse(protected[-1], len(points) - 1)
    return keep


def key_options_from_settings(settings, visual=False):
    options = set()
    if settings.only_selected_curves:
        options.add("INSERTKEY_AVAILABLE")
    if visual:
        options.add("INSERTKEY_VISUAL")
    return options


def get_bake_range(scene, settings):
    if settings.bake_range == 'CUSTOM':
        start = settings.custom_frame_start
        end = settings.custom_frame_end
    elif settings.bake_range == 'PREVIEW' and scene.use_preview_range:
        start = scene.frame_preview_start
        end = scene.frame_preview_end
    else:
        start = scene.frame_start
        end = scene.frame_end
    if end < start:
        start, end = end, start
    return int(start), int(end)


def get_or_create_text(name):
    text_block = bpy.data.texts.get(name)
    if text_block is None:
        text_block = bpy.data.texts.new(name)
    else:
        text_block.clear()
    return text_block


def ui_search_match(settings, *tokens):
    query = getattr(settings, "ui_search", "").strip().lower()
    if not query:
        return True
    haystack = " ".join(str(token).lower() for token in tokens if token)
    return query in haystack


def root_motion_data_path(obj, bone_name):
    bone_name = (bone_name or "").strip()
    if obj and obj.type == 'ARMATURE' and bone_name:
        return f'pose.bones["{bone_name}"].location'
    return "location"


def enabled_root_motion_axes(settings):
    axes = []
    if getattr(settings, "root_motion_axis_x", True):
        axes.append(0)
    if getattr(settings, "root_motion_axis_y", True):
        axes.append(1)
    if getattr(settings, "root_motion_axis_z", False):
        axes.append(2)
    return axes


def count_matching_root_curves(action, obj, settings):
    if not action:
        return 0
    data_path = root_motion_data_path(obj, settings.root_motion_bone)
    axes = set(enabled_root_motion_axes(settings))
    return sum(1 for fc in iter_action_fcurves(action, datablock=obj) if fc.data_path == data_path and fc.array_index in axes)


def get_action_frame_range(action, scene=None, obj=None):
    if action and iter_action_fcurves(action, datablock=obj):
        start, end = action.frame_range
        return int(math.floor(start)), int(math.ceil(end))
    if scene is not None:
        return int(scene.frame_start), int(scene.frame_end)
    return 0, 0


def get_timing_range(context, action, settings):
    if settings.retime_use_range:
        start = settings.retime_range_start
        end = settings.retime_range_end
    else:
        start, end = get_action_frame_range(action, context.scene, obj=active_object(context))
    if end < start:
        start, end = end, start
    return float(start), float(end)


def get_timing_pivot(context, action, settings, start=None, end=None):
    start = start if start is not None else get_timing_range(context, action, settings)[0]
    end = end if end is not None else get_timing_range(context, action, settings)[1]
    mode = settings.retime_pivot_mode
    if mode == 'CURRENT':
        return float(context.scene.frame_current)
    if mode == 'START':
        return float(start)
    if mode == 'CENTER':
        return float(start + (end - start) * 0.5)
    return float(settings.retime_custom_pivot)


def count_keys_in_frame_range(curves, start, end):
    total = 0
    for fcurve in curves:
        for kp in fcurve.keyframe_points:
            if start <= kp.co.x <= end:
                total += 1
    return total


def shift_fcurve_keys(curves, offset, start, end):
    moved = 0
    for fcurve in curves:
        changed = False
        for kp in fcurve.keyframe_points:
            if start <= kp.co.x <= end:
                kp.co.x += offset
                kp.handle_left.x += offset
                kp.handle_right.x += offset
                moved += 1
                changed = True
        if changed:
            fcurve.update()
    return moved


def scale_fcurve_keys(curves, factor, pivot, start, end):
    moved = 0
    for fcurve in curves:
        changed = False
        for kp in fcurve.keyframe_points:
            if start <= kp.co.x <= end:
                kp.co.x = pivot + (kp.co.x - pivot) * factor
                kp.handle_left.x = pivot + (kp.handle_left.x - pivot) * factor
                kp.handle_right.x = pivot + (kp.handle_right.x - pivot) * factor
                moved += 1
                changed = True
        if changed:
            fcurve.update()
    return moved


def active_shape_key_data(obj):
    if not obj:
        return None
    data = getattr(obj, 'data', None)
    return getattr(data, 'shape_keys', None)


def shape_key_count(obj):
    shape_keys = active_shape_key_data(obj)
    if not shape_keys:
        return 0
    return max(0, len(shape_keys.key_blocks) - 1)


def get_shape_key_action(obj, create=False, base_name=None):
    shape_keys = active_shape_key_data(obj)
    if shape_keys is None:
        return None
    anim_data = getattr(shape_keys, "animation_data", None)
    if anim_data is None and create and hasattr(shape_keys, "animation_data_create"):
        try:
            anim_data = shape_keys.animation_data_create()
        except Exception:
            anim_data = getattr(shape_keys, "animation_data", None)
    if anim_data is None:
        return None
    if getattr(anim_data, "action", None) is not None:
        return anim_data.action
    if not create:
        return None
    action = bpy.data.actions.new(name=unique_action_name(base_name or f"{obj.name}_ShapeKeys"))
    assign_action_to_datablock(shape_keys, action, name_hint=base_name or f"{obj.name}_ShapeKeys")
    return action


def iter_shape_key_fcurves(obj, create=False):
    shape_keys = active_shape_key_data(obj)
    if shape_keys is None:
        return []
    action = get_shape_key_action(obj, create=create)
    if action is None:
        return []
    curves = []
    for fcurve in iter_action_fcurves(action, datablock=shape_keys):
        data_path = getattr(fcurve, "data_path", "")
        if data_path.startswith('key_blocks["') or data_path.startswith("key_blocks['"):
            if data_path.endswith('].value'):
                curves.append(fcurve)
    return curves


def smooth_fcurve_values(curves, factor, iterations=1, selected_keys_only=False):
    changed = 0
    factor = max(0.0, min(1.0, float(factor)))
    iterations = max(1, int(iterations))
    for _iteration in range(iterations):
        for fcurve in curves:
            keys = fcurve.keyframe_points
            if len(keys) <= 2:
                continue
            new_values = {}
            for index in range(1, len(keys) - 1):
                key = keys[index]
                if selected_keys_only and not getattr(key, 'select_control_point', False):
                    continue
                local_average = (keys[index - 1].co.y + key.co.y + keys[index + 1].co.y) / 3.0
                new_values[index] = key.co.y + (local_average - key.co.y) * factor
            if not new_values:
                continue
            for index, value in new_values.items():
                delta = value - keys[index].co.y
                keys[index].co.y = value
                try:
                    keys[index].handle_left.y += delta
                    keys[index].handle_right.y += delta
                except Exception:
                    keys[index].handle_left.y = value
                    keys[index].handle_right.y = value
                changed += 1
            fcurve.update()
    return changed


def push_pull_curve_values(curves, factor, frame=None, selected_keys_only=False, tolerance=1e-4):
    changed = 0
    factor = float(factor)
    for fcurve in curves:
        keys = fcurve.keyframe_points
        if len(keys) <= 2:
            continue
        if selected_keys_only:
            target_indices = [idx for idx, key in enumerate(keys) if 0 < idx < len(keys) - 1 and getattr(key, 'select_control_point', False)]
        elif frame is not None:
            target_indices = [idx for idx, key in enumerate(keys) if 0 < idx < len(keys) - 1 and abs(float(key.co.x) - float(frame)) <= tolerance]
        else:
            target_indices = list(range(1, len(keys) - 1))
        if not target_indices:
            continue
        for index in target_indices:
            prev_key = keys[index - 1]
            key = keys[index]
            next_key = keys[index + 1]
            denominator = float(next_key.co.x) - float(prev_key.co.x)
            if abs(denominator) <= tolerance:
                continue
            t = (float(key.co.x) - float(prev_key.co.x)) / denominator
            baseline = float(prev_key.co.y) + (float(next_key.co.y) - float(prev_key.co.y)) * t
            new_value = baseline + (float(key.co.y) - baseline) * (1.0 + factor)
            delta = new_value - float(key.co.y)
            key.co.y = new_value
            try:
                key.handle_left.y += delta
                key.handle_right.y += delta
            except Exception:
                key.handle_left.y = new_value
                key.handle_right.y = new_value
            changed += 1
        fcurve.update()
    return changed



def scale_keys_to_neighbor_span(curves, factor, start=None, end=None, selected_keys_only=True, tolerance=1e-4):
    changed = 0
    factor = float(factor)
    for fcurve in curves:
        keys = list(getattr(fcurve, 'keyframe_points', []))
        if len(keys) < 3:
            continue

        if selected_keys_only:
            target_indices = [
                idx for idx, key in enumerate(keys)
                if getattr(key, 'select_control_point', False) or getattr(key, 'select_left_handle', False) or getattr(key, 'select_right_handle', False)
            ]
        else:
            start_frame = float(start)
            end_frame = float(end)
            if end_frame < start_frame:
                start_frame, end_frame = end_frame, start_frame
            target_indices = [
                idx for idx, key in enumerate(keys)
                if start_frame - tolerance <= float(key.co.x) <= end_frame + tolerance
            ]

        if not target_indices:
            continue

        first_index = min(target_indices)
        last_index = max(target_indices)
        if first_index <= 0 or last_index >= len(keys) - 1:
            continue

        left_anchor = keys[first_index - 1]
        right_anchor = keys[last_index + 1]
        span = float(right_anchor.co.x) - float(left_anchor.co.x)
        if abs(span) <= tolerance:
            continue

        curve_changed = 0
        left_frame = float(left_anchor.co.x)
        left_value = float(left_anchor.co.y)
        right_value = float(right_anchor.co.y)
        for idx in target_indices:
            key = keys[idx]
            t = (float(key.co.x) - left_frame) / span
            baseline = left_value + (right_value - left_value) * t
            new_value = baseline + (float(key.co.y) - baseline) * factor
            delta = new_value - float(key.co.y)
            key.co.y = new_value
            try:
                key.handle_left.y += delta
                key.handle_right.y += delta
            except Exception:
                key.handle_left.y = new_value
                key.handle_right.y = new_value
            curve_changed += 1

        if curve_changed:
            changed += curve_changed
            fcurve.update()
    return changed

def ensure_active_action(context, obj=None, base_name=None):
    obj = obj or active_object(context)
    if obj is None:
        return None
    return get_or_create_action_for_object(obj, base_name=base_name or f"{obj.name}_Action")


def find_neighbor_keyframes(fcurve, frame, tolerance=1e-4):
    prev_key = None
    exact_key = None
    next_key = None
    for key in fcurve.keyframe_points:
        key_frame = float(key.co.x)
        if abs(key_frame - frame) <= tolerance:
            exact_key = key
        elif key_frame < frame and (prev_key is None or key_frame > prev_key.co.x):
            prev_key = key
        elif key_frame > frame and (next_key is None or key_frame < next_key.co.x):
            next_key = key
    return prev_key, exact_key, next_key


def ensure_key_at_frame(fcurve, frame, value):
    _prev, exact, _next = find_neighbor_keyframes(fcurve, frame)
    if exact is not None:
        exact.co.y = value
        exact.handle_left.y = value
        exact.handle_right.y = value
        fcurve.update()
        return exact
    key = fcurve.keyframe_points.insert(frame, value, options={'FAST'})
    fcurve.update()
    return key


def set_key_interpolation_at_frame(fcurve, frame, interpolation='CONSTANT', tolerance=1e-4):
    changed = 0
    for key in fcurve.keyframe_points:
        if abs(float(key.co.x) - frame) <= tolerance:
            try:
                key.interpolation = interpolation
                changed += 1
            except Exception:
                pass
    if changed:
        fcurve.update()
    return changed


def remove_sas_modifiers(fcurve, name_prefix):
    removed = 0
    for modifier in list(fcurve.modifiers):
        if modifier.name.startswith(name_prefix):
            fcurve.modifiers.remove(modifier)
            removed += 1
    return removed


def dynamic_parent_constraint_name(target_name, subtarget_name=""):
    safe_target = sanitize_name(target_name or "Target", strip_namespaces=False).replace('"', '')
    safe_sub = sanitize_name(subtarget_name or "", strip_namespaces=False).replace('"', '')
    return f"SAS_DYN_PARENT_{safe_target}__{safe_sub}" if safe_sub else f"SAS_DYN_PARENT_{safe_target}"


def is_sas_dynamic_parent_constraint(constraint_or_name):
    name = constraint_or_name if isinstance(constraint_or_name, str) else getattr(constraint_or_name, "name", "")
    return name.startswith("SAS_DYN_PARENT_")


def safety_status_label(context, issues):
    settings = context.scene.sas_settings
    if any(level == "ERROR" for level, _en, _ja in issues):
        return sas_text("Risky", "注意", context), 'CANCEL'
    if any(level == "WARN" for level, _en, _ja in issues) or not settings.auto_backup_action:
        return sas_text("Review", "要確認", context), 'ERROR'
    return sas_text("Protected", "保護済み", context), 'CHECKMARK'


def add_log(context, level, en_message, ja_message):
    scene = getattr(context, "scene", None)
    if scene is None or not hasattr(scene, "sas_settings"):
        return
    settings = scene.sas_settings
    item = settings.operation_log.add()
    item.level = level
    item.message = sas_text(en_message, ja_message, context)
    item.raw_en = en_message
    item.raw_ja = ja_message
    while len(settings.operation_log) > max(1, settings.log_limit):
        settings.operation_log.remove(0)
    settings.operation_log_index = len(settings.operation_log) - 1


def operation_log_count(context, level=None):
    settings = context.scene.sas_settings
    if level is None:
        return len(settings.operation_log)
    return sum(1 for item in settings.operation_log if item.level == level)


def collect_scene_issues(context):
    issues = []
    obj = active_object(context)
    action = active_action(context)
    scene = context.scene
    settings = scene.sas_settings

    if obj is None:
        issues.append(("ERROR", "No active object.", "アクティブオブジェクトがありません。"))
        return issues

    if obj.animation_data is None:
        issues.append(("WARN", "Active object has no animation data yet.", "アクティブオブジェクトにはまだアニメーションデータがありません。"))
    if action is None:
        issues.append(("WARN", "No active action is assigned.", "アクティブアクションが割り当てられていません。"))
    else:
        if action_curve_count(action, datablock=obj) == 0:
            issues.append(("WARN", "The active action has no F-Curves.", "アクティブアクションに F カーブがありません。"))
        if count_keyframes(action, obj=obj) == 0:
            issues.append(("WARN", "The active action has no keyframes.", "アクティブアクションにキーフレームがありません。"))
        empty_curves = sum(1 for fc in iter_action_fcurves(action, datablock=obj) if len(fc.keyframe_points) == 0)
        if empty_curves:
            issues.append(("WARN", f"{empty_curves} empty F-Curves were found.", f"{empty_curves} 個の空の F カーブが見つかりました。"))
        muted_curves = sum(1 for fc in iter_action_fcurves(action, datablock=obj) if fc.mute)
        if muted_curves:
            issues.append(("INFO", f"{muted_curves} muted F-Curves are present.", f"{muted_curves} 個のミュートされた F カーブがあります。"))

    if scene.use_preview_range and scene.frame_preview_end < scene.frame_preview_start:
        issues.append(("ERROR", "Preview range end is smaller than start.", "プレビュー範囲の終了が開始より小さくなっています。"))

    if settings.retime_use_range and settings.retime_range_end < settings.retime_range_start:
        issues.append(("WARN", "Timing range end is smaller than start. Smart Animation will swap them automatically.", "タイミング範囲の終了が開始より小さいです。Smart Animation は自動的に入れ替えて処理します。"))

    if obj.type == 'ARMATURE':
        names = {bone.name for bone in obj.data.bones}
        l_count = 0
        missing_mirror = 0
        for bone_name in names:
            lower = bone_name.lower()
            if lower.endswith(".l"):
                l_count += 1
                if bone_name[:-2] + ".R" not in names and bone_name[:-2] + ".r" not in names:
                    missing_mirror += 1
        if l_count and missing_mirror:
            issues.append(("INFO", f"{missing_mirror} left-side bones do not have an obvious .R pair.", f"{missing_mirror} 個の左側ボーンに明確な .R 対応がありません。"))

    if settings.retarget_source and settings.retarget_source.type != 'ARMATURE':
        issues.append(("ERROR", "Retarget source is not an armature.", "リターゲットのソースがアーマチュアではありません。"))
    if settings.retarget_target and settings.retarget_target.type != 'ARMATURE':
        issues.append(("ERROR", "Retarget target is not an armature.", "リターゲットのターゲットがアーマチュアではありません。"))
    if settings.retarget_source and settings.retarget_target and settings.retarget_source == settings.retarget_target:
        issues.append(("WARN", "Retarget source and target are the same object.", "リターゲットのソースとターゲットが同一オブジェクトです。"))
    if settings.bone_map and all(not item.target_name for item in settings.bone_map):
        issues.append(("WARN", "The current bone map contains no matches.", "現在のボーン対応表に一致がありません。"))
    if obj and obj.type == 'ARMATURE' and settings.root_motion_bone.strip() and settings.root_motion_bone not in obj.data.bones:
        issues.append(("INFO", "The configured root-motion bone was not found on the active armature.", "設定されたルートモーション用ボーンがアクティブアーマチュア上に見つかりません。"))

    live_constraints = count_sas_retarget_constraints(settings.retarget_target)
    if live_constraints:
        issues.append(("INFO", f"{live_constraints} live retarget constraints are active on the target rig.", f"ターゲットリグで {live_constraints} 個のライブリターゲット拘束が有効です。"))

    missing_library = sum(1 for item in settings.action_library if bpy.data.actions.get(item.action_name) is None)
    if missing_library:
        issues.append(("WARN", f"{missing_library} motion library entries point to missing actions.", f"{missing_library} 件のモーションライブラリエントリが存在しないアクションを参照しています。"))

    stale_selection_sets = 0
    for item in settings.selection_sets:
        try:
            target_names = json.loads(item.targets_json or "[]")
        except Exception:
            target_names = []
        if item.selection_mode == 'POSE':
            set_obj = bpy.data.objects.get(item.object_name)
            if set_obj is None or getattr(set_obj, 'type', '') != 'ARMATURE':
                stale_selection_sets += 1
                continue
            pose_bones = getattr(getattr(set_obj, 'pose', None), 'bones', None)
            if not target_names or pose_bones is None or not any(name in pose_bones for name in target_names):
                stale_selection_sets += 1
        else:
            if not target_names or not any(bpy.data.objects.get(name) is not None for name in target_names):
                stale_selection_sets += 1
    if stale_selection_sets:
        issues.append(("WARN", f"{stale_selection_sets} selection sets point to missing objects or bones.", f"{stale_selection_sets} 件の選択セットが存在しないオブジェクトまたはボーンを参照しています。"))

    helper_trails = 0
    helper_ghosts = 0
    helper_ballistics = 0
    motion_stretch_objects = 0
    motion_signal_objects = 0
    vehicle_drive_objects = 0
    deform_reveal_objects = 0
    for helper_obj in bpy.data.objects:
        try:
            if helper_obj.get("sas_trail"):
                helper_trails += 1
            if helper_obj.get("sas_ghost"):
                helper_ghosts += 1
            if helper_obj.get("sas_ballistic"):
                helper_ballistics += 1
            if helper_obj.get("sas_motion_stretch_active"):
                motion_stretch_objects += 1
            if helper_obj.get("sas_motion_signal_active"):
                motion_signal_objects += 1
            if helper_obj.get("sas_vehicle_drive_active"):
                vehicle_drive_objects += 1
            if helper_obj.get("sas_deform_reveal_active"):
                deform_reveal_objects += 1
        except Exception:
            continue
    if helper_trails or helper_ghosts or helper_ballistics:
        issues.append((
            "INFO",
            f"SAS helper visuals currently in the scene — Trails: {helper_trails}, Ghosts: {helper_ghosts}, Ballistics: {helper_ballistics}.",
            f"現在シーンにある SAS 補助表示 — トレイル: {helper_trails}、ゴースト: {helper_ghosts}、弾道: {helper_ballistics}。"
        ))
    if motion_stretch_objects or motion_signal_objects or vehicle_drive_objects or deform_reveal_objects:
        issues.append((
            "INFO",
            f"SAS motion-fx helpers currently tracked — Motion Stretch: {motion_stretch_objects}, Motion Signal: {motion_signal_objects}, Vehicle Drive: {vehicle_drive_objects}, Deformer Reveal: {deform_reveal_objects}.",
            f"現在追跡中の SAS モーション補助 — Motion Stretch: {motion_stretch_objects}、Motion Signal: {motion_signal_objects}、Vehicle Drive: {vehicle_drive_objects}、Deformer Reveal: {deform_reveal_objects}。"
        ))

    density, density_label = get_action_density(action, obj=obj)
    if density_label in {"Dense", "Very Dense"}:
        issues.append(("INFO", f"The current action is {density_label.lower()} ({density:.1f} keys per F-Curve on average).", f"現在のアクションはキーが{'非常に多い' if density_label == 'Very Dense' else '多い'}状態です（F カーブあたり平均 {density:.1f} キー）。"))

    if action is not None:
        protected_curves = sum(1 for fcurve in iter_action_fcurves(action, datablock=obj) if not fcurve_is_editable(fcurve, settings))
        if protected_curves:
            issues.append(("INFO", f"{protected_curves} protected F-Curves are excluded by the curve safety filters.", f"カーブ安全フィルターにより {protected_curves} 本の保護 F カーブが除外されています。"))

    return issues


def summarize_cleanup(action, curves, threshold, simplify_factor):
    duplicate_count = 0
    static_count = 0
    simplify_count = 0

    for fcurve in curves:
        keys = fcurve.keyframe_points
        values = [kp.co.y for kp in keys]
        if not values or max(values) - min(values) <= threshold:
            static_count += 1

        remove = []
        for idx in range(1, len(keys)):
            prev = keys[idx - 1]
            curr = keys[idx]
            if abs(curr.co.x - prev.co.x) <= 1e-8:
                remove.append(idx)
        for idx in range(1, len(keys) - 1):
            prev = keys[idx - 1]
            curr = keys[idx]
            nxt = keys[idx + 1]
            if abs(prev.co.y - curr.co.y) <= threshold and abs(curr.co.y - nxt.co.y) <= threshold:
                remove.append(idx)
        duplicate_count += len(set(remove))

        points = [(kp.co.x, kp.co.y) for kp in keys]
        keep = simplify_point_indices(points, simplify_factor, preserve_extrema=True, threshold=threshold)
        simplify_count += max(0, len(points) - len(keep))

    return {
        "duplicate_keys": duplicate_count,
        "static_channels": static_count,
        "simplify_keys": simplify_count,
    }




def count_mapped_bones(settings):
    total = len(settings.bone_map)
    matched = sum(1 for item in settings.bone_map if item.target_name)
    high_conf = sum(1 for item in settings.bone_map if item.target_name and item.confidence >= 0.9)
    return {"total": total, "matched": matched, "high_conf": high_conf, "unmatched": max(0, total - matched)}


def live_retarget_constraint_name():
    return "SAS_LiveRetarget"



def count_live_retarget_constraints(target_armature):
    return count_sas_retarget_constraints(target_armature)



def clear_live_retarget_constraints(target_armature):
    return strip_sas_retarget_constraints(target_armature)



def unique_nla_track_name(anim_data, base_name):
    existing = {track.name for track in anim_data.nla_tracks}
    name = base_name
    index = 1
    while name in existing:
        name = f"{base_name}_{index:02d}"
        index += 1
    return name



def build_recommendations(context, issues):
    settings = context.scene.sas_settings
    obj = active_object(context)
    action = active_action(context)
    mapping = count_mapped_bones(settings)
    recs = []

    if obj is None:
        recs.append(("OBJECT_DATA", "Select an object to begin.", "開始するにはオブジェクトを選択してください。"))
        return recs

    if obj.animation_data is None:
        recs.append(("ACTION", "Run Auto Fix or create animation data before editing.", "編集前に自動修復を実行するか、アニメーションデータを作成してください。"))

    if action is None:
        recs.append(("ADD", "Create or assign an action, then start keying with Timeline Hub in the Animation Tools task.", "アクションを作成または割り当ててから、タスク「アニメーションツール」のタイムラインハブでキー作業を始めてください。"))
    elif count_keyframes(action, obj=obj) == 0:
        recs.append(("KEY_HLT", "Insert your first keys with Timeline Hub in the Animation Tools task.", "タスク「アニメーションツール」のタイムラインハブで最初のキーを挿入してください。"))
    else:
        recs.append(("VIEWZOOM", "Use Cleanup Preview before destructive cleanup on dense animation.", "密なアニメーションを整理する前に、整理プレビューで影響を確認してください。"))

    if error_count := sum(1 for level, _en, _ja in issues if level == "ERROR"):
        recs.append(("CANCEL", f"Resolve {error_count} blocking issue(s) shown in Current Findings.", f"現在の検出結果に表示された{error_count}件の停止要因を先に解消してください。"))

    if settings.retarget_source and settings.retarget_target and not settings.bone_map:
        recs.append(("ARROW_LEFTRIGHT", "Build a bone map before creating a live retarget preview.", "ライブリターゲットの前にボーン対応表を作成してください。"))
    elif mapping["total"] and mapping["matched"] < mapping["total"]:
        recs.append(("BONE_DATA", f"Review unmatched retarget pairs ({mapping['unmatched']} bones) before baking anything.", f"未一致の対応 ({mapping['unmatched']} 本) を確認してからベイクしてください。"))
    elif mapping["matched"] and count_live_retarget_constraints(settings.retarget_target) == 0:
        recs.append(("CONSTRAINT", "Build a live retarget preview to test the mapping non-destructively.", "非破壊で対応確認するため、ライブリターゲットプレビューを作成してください。"))

    if not recs:
        recs.append(("CHECKMARK", "The scene looks ready. Continue animating or export a report for review.", "シーンの準備状態は良好です。作業を続けるか、確認用レポートを出力してください。"))
    return recs[:5]



def scene_readiness(context, issues):
    settings = context.scene.sas_settings
    obj = active_object(context)
    action = active_action(context)
    mapping = count_mapped_bones(settings)
    score = 0
    if obj:
        score += 20
    if obj and obj.animation_data:
        score += 15
    if action:
        score += 15
    if action and count_keyframes(action, obj=obj) > 0:
        score += 15
    if not any(level == "ERROR" for level, _en, _ja in issues):
        score += 15
    if settings.auto_backup_action:
        score += 5
    if settings.preview_only:
        score += 5
    if mapping["total"] == 0:
        score += 10
    elif mapping["matched"] >= max(1, int(mapping["total"] * 0.7)):
        score += 10
    return min(100, score)

# -----------------------------------------------------------------------------
# Property groups and UI lists
# -----------------------------------------------------------------------------


_COMPACT_OVERVIEW_TASK_ITEMS = [
    ('ALL', "All Functions", "Show every Smart Animation section, Animation Recipes, and every migrated bundled tool group directly in the N-panel."),
    ('SMART', "Animation Recipes", "Show the upgraded Animation Recipes hub that maps the attached animation-assistance feature list into Blender-native tools."),
    ('OVERVIEW', "Overview / Diagnostics", "Show scene summary, diagnostics, setup checks, recommendations, report export, and the operation log in the N-panel."),
    ('ANIMATE', "Animation Tools", "Show timeline, timing, cleanup, and motion-FX tools in the N-panel."),
    ('ASSETS', "Asset Tools", "Show selection sets, pose snapshots, motion-library tools, and data I/O tools in the N-panel."),
    ('TRANSFER', "Transfer Tools", "Show retargeting, root-motion, bone-map, and transfer tools in the N-panel."),
] + list(registry.integrated_overview_group_items())

_SMART_RECIPE_ITEMS = [
    ('ANIMBOT', "animBot / AnimAide Motion Director", "Tween, push/pull, and scale-to-neighbor recipe for current-frame pose refinement."),
    ('GRAPHKIT', "GraphKit / Key Manager Optimizer", "Euler filter, duplicate/static cleanup, smoothing, and unbake-style graph optimization."),
    ('VISUALIZER', "Motion Trail / Ghost / Ballistic Visualizer", "Motion trails, ghosts, motion paths, and ballistic spacing review."),
    ('PHYSICS', "BroDynamics / Cascadeur AutoPhysics", "Ballistic, fulcrum, spring, and rigid-body-to-key physics-assist recipe."),
    ('LIMITED', "Twosify / OmniStep Limited Animation", "Stepped preview and editable held-key baking."),
    ('OVERLAP', "Overlapper / Jiggle / Spring", "Overlap, cascade delay, and spring secondary-motion recipe."),
    ('POSE_LIBRARY', "Studio Library / Pose Manager", "Store reusable poses and add current motion to the action library."),
    ('PICKER', "AnimSchool Picker / Skin Controls", "Store the current object or pose-bone selection as a reusable picker set."),
    ('DYNAMIC_PARENT', "Dynamic Parent Plus", "Switch dynamic parent constraints while preserving the current transform."),
    ('MOTION_MIXER', "MotionBuilder Story / NLA Mixer", "Push current actions to NLA and sequence library clips."),
    ('RETARGET', "Red9 / KineFX / MotionBuilder Retarget", "Build a bone map and create a live retarget preview."),
    ('LOCOMOTION', "MotionMaker / CMotion Locomotion", "Generate an editable cyclic locomotion base."),
    ('SIGNAL', "Signal / MoGraph Procedural Motion", "Apply procedural signal and loop helpers."),
    ('TRANSFORM_REVEAL', "Transform / Unfolder / Scroll Roll", "Create transform or deformer reveal animation."),
    ('CAMERA_STORY', "Camera Animator / GorillaCam", "Create camera story markers, review split, and shake polish."),
    ('SHAPE_CONTROL', "Pose Morph / OverMorpher / Dorito", "Create custom-property shape-key controls and drivers."),
    ('IFL', "IFL Playback Manager", "Synchronize image-sequence texture timing."),
    ('UNBAKE', "Cascadeur Animation Unbaking", "Convert dense baked curves into sparse editable keys."),
    ('PRECISION_POLISH', "Smart Precision Polish", "Run adaptive cleanup, flow-safe handles, sparse unbake, and quality reporting in one pass."),
    ('QUALITY_REPORT', "Smart Quality Report", "Analyze key density, duplicate keys, static channels, Euler jumps, spacing speed, and polish risks."),
    ('STAGE_DIRECTOR', "Smart Stage Director", "Run a context-aware studio pass that selects the best Animation Recipes workflow for the current shot stage."),
    ('SUPER_DIRECTOR', "Smart Superior Director", "Run stage resolution, contact stabilization, timing intent, precision polish, quality gate, and optional visual review in one pass."),
    ('CONTACT_STABILIZER', "Smart Contact Stabilizer", "Flatten planted vertical contact keys and reduce contact drift while preserving editable keyframes."),
    ('TIMING_INTENT', "Smart Timing Intent Solver", "Apply blocking, spline, impact, float, or mechanical interpolation intent to editable curves."),
    ('REPORT', "Feature Coverage Report", "Write the full source-tool mapping to a Text datablock."),
]

_SMART_MOTION_DIRECTOR_ITEMS = [
    ('FULL', "Full Director", "Run tween, push/pull, and scale-to-neighbor passes."),
    ('TWEEN', "Tween Only", "Create an intelligent in-between key from neighboring keys."),
    ('PUSH_PULL', "Push/Pull Only", "Exaggerate or soften the current-frame key."),
    ('SCALE_NEIGHBORS', "Scale To Neighbors Only", "Scale selected key values around neighboring anchors."),
]

_SMART_VISUALIZER_ITEMS = [
    ('ALL', "All Visuals", "Create trails, ghosts, motion paths, and ballistic guides where possible."),
    ('TRAIL_GHOST', "Trail + Ghost", "Create motion trail and ghost preview helpers."),
    ('PATHS', "Motion Paths", "Calculate Blender motion paths for selected animated targets."),
    ('BALLISTIC', "Ballistic", "Create ballistic trajectory guides."),
]

_SMART_PHYSICS_DIRECTOR_ITEMS = [
    ('AUTO', "Auto", "Run a safe combination of ballistic guide, fulcrum cleanup, and spring pass where possible."),
    ('BALLISTIC_GUIDE', "Ballistic Guide", "Create a ballistic trajectory guide."),
    ('BALLISTIC_BAKE', "Ballistic Bake", "Bake a ballistic correction into editable location keys."),
    ('FULCRUM', "Fulcrum / Contact", "Clean planted-contact ranges and contact holds."),
    ('SPRING', "Spring", "Bake secondary spring or Spring Magic motion."),
    ('RIGID_BODY', "Rigid Body", "Bake rigid-body simulation to editable keys."),
]

_SMART_PRECISION_PROFILE_ITEMS = [
    ('HERO', "Hero", "Use the most conservative cleanup for final hero shots and highly intentional hand-polished arcs."),
    ('SAFE', "Safe", "Use conservative adaptive cleanup and preserve more keys for hand-polished shots."),
    ('BALANCED', "Balanced", "Use balanced adaptive cleanup for most mocap, retarget, and hand-keyed shots."),
    ('MOCAP', "Mocap Cleanup", "Use stronger but curvature-aware cleanup for retargeted or densely baked motion-capture data."),
    ('AGGRESSIVE', "Aggressive", "Remove more visually redundant keys after dense baking while preserving extremes."),
]

_SMART_STAGE_ITEMS = [
    ('AUTO', "Auto Stage", "Let Smart Stage Director choose the best pass from the current action, selection, density, and quality score."),
    ('BLOCKING', "Blocking", "Prioritize pose checkpoints, tweening, and safe key insertion while roughing out the shot."),
    ('SPLINE', "Spline", "Prioritize curve flow, in-between control, and auto-clamped handles while converting blocking to polished motion."),
    ('MOCAP', "Mocap / Retarget", "Prioritize Euler continuity, dense-curve cleanup, unbaking, and quality reporting."),
    ('PHYSICS', "Physics / Overlap", "Prioritize ballistic, contact, spring, and visual review helpers."),
    ('POLISH', "Final Polish", "Prioritize precision cleanup, quality gates, and non-destructive reports before handoff."),
    ('REVIEW', "Review", "Prioritize diagnostics and visual helpers without unnecessary destructive edits."),
]

_SMART_UI_DENSITY_ITEMS = [
    ('COMPACT', "Compact", "Show a cleaner production dashboard with the main controls and hide deep controls unless Advanced Controls is enabled."),
    ('BALANCED', "Balanced", "Show the dashboard plus the commonly used control groups."),
    ('STUDIO', "Studio", "Show the full professional control surface for precise shot work."),
]

_SMART_TIMING_INTENT_ITEMS = [
    ('AUTO', "Auto Intent", "Choose the interpolation intent from the current workflow stage."),
    ('BLOCKING', "Blocking Holds", "Use stepped holds for readable blocking poses."),
    ('SPLINE', "Spline Flow", "Use auto-clamped Bezier handles for polished spline motion."),
    ('IMPACT', "Impact Control", "Use stronger linear-to-clamped treatment around abrupt value changes."),
    ('FLOAT', "Float / Drift", "Use smooth Bezier handles for soft drifting motion."),
    ('MECHANICAL', "Mechanical Linear", "Use linear interpolation for mechanical timing and procedural rigs."),
]

_SMART_LOCOMOTION_STYLE_ITEMS = [
    ('WALK', "Walk", "Two contact-like bobs per cycle for a walk-style blocking base."),
    ('RUN', "Run", "One stronger airborne bounce per cycle for a run or jumpy action base."),
    ('MECHANICAL', "Mechanical", "Linear mechanical travel without bob or yaw swing."),
    ('CINEMATIC', "Cinematic", "Smooth-eased travel inside each cycle for director-friendly blocking."),
]

class SAS_PoseSnapshot(PropertyGroup):
    name: StringProperty(name="Name", description="User-facing snapshot label shown in the Pose snapshot list.")
    data_json: StringProperty(
        name="Data",
        description="Serialized pose snapshot data stored internally by Smart Animation.",
        options={'HIDDEN'},
    )


class SAS_BoneMapItem(PropertyGroup):
    source_name: StringProperty(name="Source", description="Source bone name for this retarget row.")
    target_name: StringProperty(name="Target", description="Matched target bone name used by the current retarget preview row.")
    confidence: FloatProperty(name="Confidence", description="Confidence score for name-based matching in this retarget row.", default=0.0, min=0.0, max=1.0)
    status: StringProperty(name="Status", description="Matching state for this bone-map row, such as matched, guessed, or unmatched.", default="unmatched")


class SAS_LogItem(PropertyGroup):
    level: StringProperty(name="Level", description="Severity level used by the recent operation log row.", default="INFO")
    message: StringProperty(name="Message", description="Localized message shown in the recent operation log list.")
    raw_en: StringProperty(name="English", description="Original English log text kept internally for bilingual log display.", options={'HIDDEN'})
    raw_ja: StringProperty(name="Japanese", description="Original Japanese log text kept internally for bilingual log display.", options={'HIDDEN'})


class SAS_ActionLibraryItem(PropertyGroup):
    action_name: StringProperty(name="Action", description="Action data-block name stored in the in-panel motion library.")
    source_object: StringProperty(name="Source", description="Object name associated with the stored action when it was added to the motion library.")
    note: StringProperty(name="Note", description="Optional short note shown next to the stored library action.")


class SAS_SelectionSetItem(PropertyGroup):
    name: StringProperty(name="Name", description="User-facing name shown in the selection-set list.")
    selection_mode: StringProperty(name="Mode", description="Stored selection type: OBJECT or POSE.", default="OBJECT")
    object_name: StringProperty(name="Stored Object", description="Active object or armature name associated with this selection set.")
    targets_json: StringProperty(name="Targets", description="Serialized object or bone names kept internally for the stored selection set.", options={'HIDDEN'})


_SAS_SETTINGS_PERSIST_VERSION = 3
_SAS_SETTINGS_APPLYING = False
_SAS_ALWAYS_ON_SYNCING = False
_SAS_SETTINGS_LAST_DUMP = ''
_SAS_SETTINGS_LAST_HASH = ''
_SAS_SETTINGS_DIRTY = False
_SAS_SETTINGS_PENDING_PAYLOAD: dict = {}
_SAS_SETTINGS_PENDING_HASH = ''
_SAS_SETTINGS_PAYLOAD_LOADED = False
_SAS_SETTINGS_HANDLER_LEDGER = None
_SAS_SETTINGS_OWNER_GENERATION = 0
_SAS_SETTINGS_LAST_ERROR = ''
_SAS_SETTINGS_EXPLICIT_UPDATES: set[str] = set()
_SAS_SETTINGS_HANDLER_REGISTERED = False
_SAS_SETTINGS_TIMER_REGISTERED = False
_SAS_SETTINGS_READY_TIMER_REGISTERED = False
_SAS_SETTINGS_READY_GENERATION = 0
_SAS_SETTINGS_SCENE_MARKER = '_sas_npanel_settings_global_hash'
_SAS_SETTINGS_SCENE_CACHE_MAX = 128
_SAS_SETTINGS_SCENE_HASHES: OrderedDict[int, str] = OrderedDict()
_SAS_SCENE_DATA_SETTING_KEYS = {
    # These select rows in Scene-owned collections. They are UI cursors over
    # user animation data, not portable preferences, and are never restored
    # into a different Scene.
    'pose_snapshot_index',
    'bone_map_index',
    'operation_log_index',
    'action_library_index',
    'selection_set_index',
}


def _sas_is_portable_setting_identifier(identifier: str) -> bool:
    ident = str(identifier or '').strip()
    return bool(ident and ident != 'rna_type' and ident not in _SAS_SCENE_DATA_SETTING_KEYS)


def _sas_scene_key(scene) -> int:
    try:
        return int(scene.as_pointer())
    except Exception:
        try:
            return id(scene)
        except Exception:
            return 0


def _sas_scene_hash(scene) -> str:
    key = _sas_scene_key(scene)
    if not key:
        return ''
    value = str(_SAS_SETTINGS_SCENE_HASHES.get(key, '') or '')
    if key in _SAS_SETTINGS_SCENE_HASHES:
        try:
            _SAS_SETTINGS_SCENE_HASHES.move_to_end(key)
        except Exception:
            pass
    return value


def _sas_mark_scene_hash(scene, value: str) -> None:
    key = _sas_scene_key(scene)
    if not key:
        return
    _SAS_SETTINGS_SCENE_HASHES[key] = str(value or '')
    try:
        _SAS_SETTINGS_SCENE_HASHES.move_to_end(key)
    except Exception:
        pass
    while len(_SAS_SETTINGS_SCENE_HASHES) > _SAS_SETTINGS_SCENE_CACHE_MAX:
        try:
            _SAS_SETTINGS_SCENE_HASHES.popitem(last=False)
        except Exception:
            break


def _sas_settings_path() -> Path | None:
    # Legacy per-extension location kept only for migrating older settings.
    try:
        return addon_data_path('settings', 'smart_animation_suite_npanel_settings.json', create=True)
    except Exception:
        return None


def _sas_simple_prop_value(ptr, prop):
    ident = str(getattr(prop, 'identifier', '') or '')
    ptype = str(getattr(prop, 'type', '') or '').upper()
    try:
        value = getattr(ptr, ident)
    except Exception:
        return None
    if ptype in {'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM', 'BOOLEAN_ARRAY', 'INT_ARRAY', 'FLOAT_ARRAY'}:
        try:
            if isinstance(value, (bool, int, float, str)) or value is None:
                return value
            if hasattr(value, '__iter__') and not isinstance(value, (str, bytes)):
                return list(value)
        except Exception:
            pass
        try:
            return str(value)
        except Exception:
            return None
    if ptype in {'POINTER', 'COLLECTION'}:
        # User-default settings must not persist file/datablock-specific pointers
        # or collections.  Reapplying them on file load can trigger tool update
        # callbacks and reset transforms/poses.
        return None
    return None


def _sas_pointer_library_path(datablock) -> str:
    try:
        library = getattr(datablock, 'library', None)
        return str(getattr(library, 'filepath', '') or '') if library is not None else ''
    except Exception:
        return ''


def _sas_stable_pointer_record(prop, value) -> dict:
    type_name = _sas_pointer_fixed_type(prop)
    if value is not None:
        try:
            type_name = str(getattr(getattr(value, 'bl_rna', None), 'identifier', '') or type_name)
        except Exception:
            pass
    return {
        '__pointer__': str(type_name or ''),
        'name': str(getattr(value, 'name', '') or '') if value is not None else '',
        'library': _sas_pointer_library_path(value) if value is not None else '',
    }


def _sas_pointer_is_blender_id(prop, value) -> bool:
    try:
        if value is not None and isinstance(value, bpy.types.ID):
            return True
    except Exception:
        pass
    return _sas_pointer_fixed_type(prop).lower() in {
        'object', 'collection', 'action', 'material', 'camera', 'light',
        'armature', 'mesh', 'curve', 'scene', 'world', 'image', 'text',
    }


def _sas_serialize_pointer(ptr, *, include_collections: bool = True) -> dict:
    result = {}
    try:
        props = getattr(getattr(ptr, 'bl_rna', None), 'properties', None)
    except Exception:
        props = None
    if props is not None:
        for prop in props:
            try:
                ident = str(getattr(prop, 'identifier', '') or '')
                if not _sas_is_portable_setting_identifier(ident):
                    continue
                if bool(getattr(prop, 'is_readonly', False)):
                    continue
                ptype = str(getattr(prop, 'type', '') or '').upper()
                if ptype in {'POINTER', 'COLLECTION'}:
                    continue
                value = _sas_simple_prop_value(ptr, prop)
                if value is not None:
                    result[ident] = value
            except Exception:
                continue
    try:
        for key, value in ptr.items():
            ident = str(key or '').strip()
            if not ident.startswith('ui_section_'):
                continue
            if isinstance(value, bool):
                result[ident] = bool(value)
            elif isinstance(value, (int, float)):
                result[ident] = bool(value)
    except Exception:
        pass
    return result


def _sas_settings_payload(settings) -> dict:
    return {
        'version': _SAS_SETTINGS_PERSIST_VERSION,
        'settings': _sas_serialize_pointer(settings, include_collections=True),
    }


def _sas_payload_dump(payload: dict) -> str:
    try:
        return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    except Exception:
        return ''



def npanel_auto_save_enabled(settings=None, *, context=None) -> bool:
    """Return the global N-panel auto-save policy.

    Defaults to True for a fresh install. When disabled, every writer is blocked
    after the toggle's one final self-commit, including force/fallback/shutdown.
    """
    try:
        if settings is None:
            scene = getattr(context, 'scene', None) if context is not None else getattr(bpy.context, 'scene', None)
            settings = getattr(scene, 'sas_settings', None)
    except Exception:
        settings = None
    try:
        if settings is not None and hasattr(settings, 'npanel_state_auto_save'):
            return bool(getattr(settings, 'npanel_state_auto_save'))
    except Exception:
        pass
    try:
        from . import config_store
        section = config_store.get_section('npanel_settings', {})
        values = section.get('settings') if isinstance(section, dict) and isinstance(section.get('settings'), dict) else {}
        if 'npanel_state_auto_save' in values:
            return bool(values.get('npanel_state_auto_save'))
    except Exception:
        pass
    return True


def save_all_external_settings(
    *, context=None, force: bool = True, include_npanel_settings: bool = True,
) -> None:
    """Flush every external Smart Animation setting store to one config JSON."""
    ctx = context or getattr(bpy, 'context', None)
    if include_npanel_settings:
        try:
            save_settings_if_changed(context=ctx, force=force)
        except Exception:
            pass
    try:
        from . import common
        save_common = getattr(common, 'save_persistent_settings', None)
        if callable(save_common):
            save_common(ctx, force=force)
    except Exception:
        pass
    try:
        from . import loader
        save_background = getattr(loader, '_save_background_state', None)
        if callable(save_background):
            try:
                save_background(force=force)
            except TypeError:
                save_background()
    except Exception:
        pass
    try:
        from . import feature_toggle
        save_feature = getattr(feature_toggle, '_save_state', None)
        if callable(save_feature):
            try:
                save_feature(force=force)
            except TypeError:
                save_feature()
    except Exception:
        pass
    try:
        from . import runtime_persistence
        save_runtime = getattr(runtime_persistence, 'save_runtime_properties_if_changed', None)
        if callable(save_runtime):
            save_runtime(context=ctx, force=force)
    except Exception:
        pass


def _sas_write_settings_payload(payload: dict, *, context=None, off_commit_capability=None) -> bool:
    global _SAS_SETTINGS_LAST_DUMP, _SAS_SETTINGS_LAST_HASH, _SAS_SETTINGS_DIRTY
    global _SAS_SETTINGS_PENDING_PAYLOAD, _SAS_SETTINGS_PENDING_HASH
    global _SAS_SETTINGS_PAYLOAD_LOADED
    try:
        from . import config_store
        dump = _sas_payload_dump(payload)
        if not dump:
            _SAS_SETTINGS_DIRTY = True
            return False
        if dump == _SAS_SETTINGS_LAST_DUMP and not _SAS_SETTINGS_DIRTY:
            _SAS_SETTINGS_EXPLICIT_UPDATES.clear()
            return False
        if not config_store.update_section(
            'npanel_settings', payload,
            off_commit_capability=off_commit_capability,
        ):
            _SAS_SETTINGS_DIRTY = True
            return False
        _SAS_SETTINGS_LAST_DUMP = dump
        _SAS_SETTINGS_LAST_HASH = hashlib.sha1(dump.encode('utf-8')).hexdigest()
        _SAS_SETTINGS_DIRTY = False
        _SAS_SETTINGS_PENDING_PAYLOAD = dict(payload)
        _SAS_SETTINGS_PENDING_HASH = _SAS_SETTINGS_LAST_HASH
        _SAS_SETTINGS_PAYLOAD_LOADED = True
        _SAS_SETTINGS_EXPLICIT_UPDATES.clear()
        try:
            scene = getattr(context, 'scene', None) if context is not None else getattr(bpy.context, 'scene', None)
            if scene is not None:
                _sas_mark_scene_hash(scene, _SAS_SETTINGS_LAST_HASH)
        except Exception:
            pass
        return True
    except Exception:
        _SAS_SETTINGS_DIRTY = True
        return False


def save_settings_if_changed(
    settings=None, *, context=None, force: bool = False,
    off_commit_capability=None,
) -> bool:
    """Capture a scalar snapshot on every update and commit per save policy.

    With N-panel State Save disabled the snapshot remains memory-only and dirty.
    No lifecycle ``force`` path may cross the lower config-store barrier; only
    the OFF action's exact opaque transition capability can commit the disabled state.
    """
    global _SAS_SETTINGS_DIRTY, _SAS_SETTINGS_PENDING_PAYLOAD
    global _SAS_SETTINGS_PENDING_HASH, _SAS_SETTINGS_PAYLOAD_LOADED
    if _SAS_SETTINGS_APPLYING:
        return False
    if settings is None:
        settings = _sas_resolve_settings_instance(None, context)
    elif not _sas_is_live_settings_instance(settings, context):
        settings = None
    if settings is None:
        _SAS_SETTINGS_DIRTY = True
        return False
    if settings is not None:
        try:
            _SAS_SETTINGS_PENDING_PAYLOAD = _sas_settings_payload(settings)
            pending_dump = _sas_payload_dump(_SAS_SETTINGS_PENDING_PAYLOAD)
            _SAS_SETTINGS_PENDING_HASH = (
                hashlib.sha1(pending_dump.encode('utf-8')).hexdigest() if pending_dump else ''
            )
            _SAS_SETTINGS_PAYLOAD_LOADED = True
            _SAS_SETTINGS_DIRTY = True
            # The current Scene already contains this user-authored snapshot.
            # Advance its in-memory marker immediately so a subsequent RNA
            # update cannot be mistaken for first materialisation and restored
            # over with the preceding snapshot while deferred-save is active.
            try:
                scene = getattr(settings, 'id_data', None)
                if scene is None:
                    scene = getattr(context, 'scene', None) if context is not None else getattr(bpy.context, 'scene', None)
                if scene is not None and _SAS_SETTINGS_PENDING_HASH:
                    _sas_mark_scene_hash(scene, _SAS_SETTINGS_PENDING_HASH)
            except Exception:
                pass
        except Exception:
            _SAS_SETTINGS_DIRTY = True
            return False
    elif not _SAS_SETTINGS_PENDING_PAYLOAD:
        _SAS_SETTINGS_DIRTY = True
        return False
    if off_commit_capability is None and not npanel_auto_save_enabled(settings, context=context):
        return False
    payload = dict(_SAS_SETTINGS_PENDING_PAYLOAD)
    settings_payload = payload.get('settings')
    if isinstance(settings_payload, dict):
        payload['settings'] = dict(settings_payload)
    return _sas_write_settings_payload(payload, context=context, off_commit_capability=off_commit_capability)


def commit_dirty_settings(*, context=None) -> bool:
    global _SAS_SETTINGS_DIRTY, _SAS_SETTINGS_PENDING_PAYLOAD
    global _SAS_SETTINGS_PENDING_HASH, _SAS_SETTINGS_PAYLOAD_LOADED
    if not _SAS_SETTINGS_DIRTY:
        return True
    try:
        from . import config_store
        intentionally_disabled = bool(
            not npanel_auto_save_enabled(context=context)
            and not config_store.write_enabled()
            and not config_store.restore_active()
        )
    except Exception:
        intentionally_disabled = False
    if intentionally_disabled:
        # OFF is an explicit no-persistence policy, not a failed disk write.
        # Drop only the transient pending snapshot so it cannot reappear after
        # disable/re-enable; the last committed JSON remains untouched.
        _SAS_SETTINGS_DIRTY = False
        _SAS_SETTINGS_PENDING_PAYLOAD = {}
        _SAS_SETTINGS_PENDING_HASH = ''
        _SAS_SETTINGS_PAYLOAD_LOADED = False
        _SAS_SETTINGS_EXPLICIT_UPDATES.clear()
        return True
    save_settings_if_changed(context=context, force=True)
    return not _SAS_SETTINGS_DIRTY

def _sas_load_settings_payload(*, refresh: bool = False) -> dict:
    """Return the canonical N-panel payload from one bounded snapshot load.

    ``refresh`` is used only at explicit lifecycle boundaries (initial register
    and ``load_post``).  All scene restores in the same transaction receive the
    returned payload directly, so the 283-key section is never re-read once per
    scene or by ``common`` a second time.
    """
    global _SAS_SETTINGS_LAST_DUMP, _SAS_SETTINGS_LAST_HASH
    global _SAS_SETTINGS_PENDING_PAYLOAD, _SAS_SETTINGS_PENDING_HASH
    global _SAS_SETTINGS_PAYLOAD_LOADED

    if not refresh and _SAS_SETTINGS_PAYLOAD_LOADED:
        return _SAS_SETTINGS_PENDING_PAYLOAD

    payload = {}
    try:
        from . import config_store
        section = config_store.get_section('npanel_settings', {})
        if isinstance(section, dict):
            payload = section
    except Exception:
        payload = {}
    if not payload:
        # Legacy fallbacks are centralized here so the lifecycle still yields
        # one authoritative payload object. ``common`` receives that object and
        # never performs an independent second read of the same 283-key state.
        legacy_paths = []
        path = _sas_settings_path()
        if path is not None:
            legacy_paths.append(path)
        try:
            from . import common
            legacy_paths.extend(common._legacy_settings_candidates())
        except Exception:
            pass
        seen_paths = set()
        for legacy_path in legacy_paths:
            try:
                marker = str(legacy_path)
                if not marker or marker in seen_paths:
                    continue
                seen_paths.add(marker)
                if legacy_path.exists():
                    candidate = json.loads(legacy_path.read_text(encoding='utf-8'))
                    if isinstance(candidate, dict):
                        payload = candidate
                        break
            except Exception:
                continue
    if not isinstance(payload, dict):
        payload = {}
    if 'settings' not in payload and isinstance(payload.get('scene'), dict):
        try:
            sas_data = payload.get('scene', {}).get('sas_settings')
            if isinstance(sas_data, dict):
                payload = {'version': _SAS_SETTINGS_PERSIST_VERSION, 'settings': dict(sas_data)}
        except Exception:
            payload = {}

    dump = _sas_payload_dump(payload) if payload else ''
    if dump:
        payload_hash = hashlib.sha1(dump.encode('utf-8')).hexdigest()
        _SAS_SETTINGS_LAST_DUMP = dump
        _SAS_SETTINGS_LAST_HASH = payload_hash
        _SAS_SETTINGS_PENDING_PAYLOAD = payload
        _SAS_SETTINGS_PENDING_HASH = payload_hash
    else:
        _SAS_SETTINGS_LAST_DUMP = ''
        _SAS_SETTINGS_LAST_HASH = ''
        _SAS_SETTINGS_PENDING_PAYLOAD = {}
        _SAS_SETTINGS_PENDING_HASH = ''
    _SAS_SETTINGS_PAYLOAD_LOADED = True
    try:
        from . import config_store
        settings_data = _SAS_SETTINGS_PENDING_PAYLOAD.get('settings', {})
        enabled = True
        if isinstance(settings_data, dict) and 'npanel_state_auto_save' in settings_data:
            enabled = bool(settings_data.get('npanel_state_auto_save'))
        config_store.set_write_enabled(enabled)
    except Exception:
        pass
    return _SAS_SETTINGS_PENDING_PAYLOAD


def load_settings_payload(*, refresh: bool = False) -> dict:
    """Public lifecycle helper returning the single canonical payload snapshot."""
    return _sas_load_settings_payload(refresh=refresh)


def _sas_current_payload_hash(payload: dict | None = None) -> str:
    # The canonical loader returns the exact cached object whose digest was
    # already computed during the single config read. Avoid serialising the
    # 283-key payload a second time in the all-Scene transaction.
    if payload is _SAS_SETTINGS_PENDING_PAYLOAD and _SAS_SETTINGS_PENDING_HASH:
        return str(_SAS_SETTINGS_PENDING_HASH)
    if isinstance(payload, dict):
        dump = _sas_payload_dump(payload)
        if dump:
            return hashlib.sha1(dump.encode('utf-8')).hexdigest()
    return str(_SAS_SETTINGS_PENDING_HASH or _SAS_SETTINGS_LAST_HASH or '')



def _sas_pointer_fixed_type(prop) -> str:
    try:
        return str(getattr(getattr(prop, 'fixed_type', None), 'identifier', '') or '')
    except Exception:
        return ''


def _sas_resolve_pointer_target(prop, name: str, payload=None):
    name = str(name or '').strip()
    if not name:
        return None
    fixed_type = _sas_pointer_fixed_type(prop)
    payload_type = ''
    if isinstance(payload, dict):
        payload_type = str(payload.get('__pointer__') or payload.get('__pointer_type__') or '').strip()
    wanted_library = str(payload.get('library') or '') if isinstance(payload, dict) else ''
    candidates: list[object] = []
    lookup_order = (fixed_type, payload_type)
    for data_type in lookup_order:
        key = str(data_type or '').lower()
        if key in {'object', 'objects'}:
            candidates.append(getattr(getattr(bpy, 'data', None), 'objects', None))
        elif key in {'collection', 'collections'}:
            candidates.append(getattr(getattr(bpy, 'data', None), 'collections', None))
        elif key in {'action', 'actions'}:
            candidates.append(getattr(getattr(bpy, 'data', None), 'actions', None))
        elif key in {'material', 'materials'}:
            candidates.append(getattr(getattr(bpy, 'data', None), 'materials', None))
        elif key in {'camera', 'cameras'}:
            candidates.append(getattr(getattr(bpy, 'data', None), 'cameras', None))
        elif key in {'armature', 'armatures'}:
            candidates.append(getattr(getattr(bpy, 'data', None), 'armatures', None))
        elif key in {'scene', 'scenes'}:
            candidates.append(getattr(getattr(bpy, 'data', None), 'scenes', None))
        elif key in {'world', 'worlds'}:
            candidates.append(getattr(getattr(bpy, 'data', None), 'worlds', None))
    for data_store_name in ('objects', 'collections', 'actions', 'materials', 'cameras', 'armatures', 'scenes', 'worlds'):
        candidates.append(getattr(getattr(bpy, 'data', None), data_store_name, None))
    seen: set[int] = set()
    for data_store in candidates:
        if data_store is None:
            continue
        marker = id(data_store)
        if marker in seen:
            continue
        seen.add(marker)
        try:
            matches = [target for target in data_store if str(getattr(target, 'name', '') or '') == name]
        except Exception:
            matches = []
        for target in matches:
            actual_library = _sas_pointer_library_path(target)
            if not wanted_library and not actual_library:
                return target
            if wanted_library:
                try:
                    same_library = wanted_library == actual_library or bpy.path.abspath(wanted_library) == bpy.path.abspath(actual_library)
                except Exception:
                    same_library = wanted_library == actual_library
                if same_library:
                    return target
    return None

def _sas_numeric_equal(left, right) -> bool:
    try:
        return math.isclose(float(left), float(right), rel_tol=1.0e-7, abs_tol=1.0e-8)
    except Exception:
        return False


def _sas_values_equal(current, stored, ptype: str = '') -> bool:
    """Compare an RNA value without invoking its update callback."""
    ptype = str(ptype or '').upper()
    try:
        if ptype == 'BOOLEAN':
            return bool(current) is bool(stored)
        if ptype == 'INT':
            return int(current) == int(stored)
        if ptype == 'FLOAT':
            return _sas_numeric_equal(current, stored)
        if ptype in {'BOOLEAN_ARRAY', 'INT_ARRAY', 'FLOAT_ARRAY'}:
            left = tuple(current)
            right = tuple(stored)
            if len(left) != len(right):
                return False
            if ptype == 'FLOAT_ARRAY':
                return all(_sas_numeric_equal(a, b) for a, b in zip(left, right))
            return left == right
        if ptype == 'ENUM' and isinstance(current, (set, frozenset)):
            if isinstance(stored, str):
                return current == {stored}
            return current == set(stored or ())
        if isinstance(current, (set, frozenset)):
            return set(current) == set(stored or ())
        if hasattr(current, '__iter__') and not isinstance(current, (str, bytes, dict)):
            if isinstance(stored, (list, tuple)):
                return tuple(current) == tuple(stored)
        return current == stored
    except Exception:
        return False


def _sas_assignment_value(current, stored, ptype: str = ''):
    ptype = str(ptype or '').upper()
    if ptype == 'ENUM' and isinstance(current, (set, frozenset)):
        if isinstance(stored, str):
            return {stored}
        try:
            return set(stored or ())
        except Exception:
            return stored
    return stored


def _sas_apply_pointer_value(ptr, prop, value, context=None) -> bool:
    del context
    ident = str(getattr(prop, 'identifier', '') or '')
    ptype = str(getattr(prop, 'type', '') or '').upper()
    if not ident:
        return False
    if ident.lower() in {'location', 'rotation_euler', 'rotation_quaternion', 'rotation_axis_angle', 'scale', 'matrix_world', 'matrix_local', 'matrix_basis', 'matrix_parent_inverse'}:
        return False
    if not _sas_is_portable_setting_identifier(ident):
        return False
    if ptype in {'POINTER', 'COLLECTION'}:
        return False
    try:
        current = getattr(ptr, ident)
    except Exception:
        current = object()
    assigned = _sas_assignment_value(current, value, ptype)
    if _sas_values_equal(current, assigned, ptype):
        return False
    try:
        setattr(ptr, ident, assigned)
        return True
    except Exception:
        return False


def _sas_apply_settings_dict(ptr, data: dict, *, context=None, include_collections: bool = True) -> int:
    del include_collections
    try:
        props = getattr(getattr(ptr, 'bl_rna', None), 'properties', None)
    except Exception:
        props = None
    if not isinstance(data, dict) or props is None:
        return 0
    assignments = 0
    for raw_ident, value in data.items():
        try:
            ident = str(raw_ident or '').strip()
            if not ident or ident == 'rna_type':
                continue
            try:
                prop = props.get(ident)
            except Exception:
                prop = None
            if prop is None or bool(getattr(prop, 'is_readonly', False)):
                continue
            if _sas_apply_pointer_value(ptr, prop, value, context=context):
                assignments += 1
        except Exception:
            continue
    # Unknown legacy keys are intentionally ignored. Every supported child
    # section is declared as BoolProperty before class registration; neither
    # restoration nor Panel.draw may create IDProperties or UI metadata.
    return assignments


def apply_saved_settings_to_scene(
    scene=None, *, force: bool = False, payload: dict | None = None,
    payload_hash: str = '', sync_background: bool = True,
) -> bool:
    """Apply one already-loaded profile to one Scene at most once per hash."""
    global _SAS_SETTINGS_APPLYING
    scene = scene or getattr(bpy.context, 'scene', None)
    if scene is None or not hasattr(scene, 'sas_settings'):
        return False
    if not isinstance(payload, dict):
        payload = _sas_load_settings_payload(refresh=bool(force))
    data = payload.get('settings') if isinstance(payload, dict) else None
    if not isinstance(data, dict) or not data:
        return False
    payload_hash = str(payload_hash or _sas_current_payload_hash(payload) or '')
    if not payload_hash:
        return False
    if _sas_scene_hash(scene) == payload_hash:
        return False

    previous_applying = bool(_SAS_SETTINGS_APPLYING)
    _SAS_SETTINGS_APPLYING = True
    try:
        from . import config_store
        with config_store.restore_transaction():
            _sas_apply_settings_dict(
                scene.sas_settings, data, context=getattr(bpy, 'context', None),
                include_collections=True,
            )
            _sas_mark_scene_hash(scene, payload_hash)
            if sync_background:
                sync_always_on_properties_to_loader(
                    scene.sas_settings, context=getattr(bpy, 'context', None),
                    load_enabled=False,
                )
        return True
    except Exception:
        return False
    finally:
        _SAS_SETTINGS_APPLYING = previous_applying


def apply_saved_settings_to_all_scenes(
    *, force: bool = False, payload: dict | None = None,
) -> int:
    """Apply one payload snapshot to every unmarked Scene, then sync globals once."""
    if not isinstance(payload, dict):
        payload = _sas_load_settings_payload(refresh=bool(force))
    data = payload.get('settings') if isinstance(payload, dict) else None
    if not isinstance(data, dict) or not data:
        return 0
    payload_hash = _sas_current_payload_hash(payload)
    if not payload_hash:
        return 0
    try:
        scenes = list(getattr(bpy.data, 'scenes', ()) or ())
    except Exception:
        scenes = []
    processed = 0
    first_scene = None
    for scene in scenes:
        if first_scene is None:
            first_scene = scene
        try:
            if apply_saved_settings_to_scene(
                scene, force=False, payload=payload, payload_hash=payload_hash,
                sync_background=False,
            ):
                processed += 1
        except Exception:
            pass

    # Loader/background state is process-global, not Scene-local.  Synchronize
    # it once from the active Scene after the entire payload transaction rather
    # than once per Scene (which previously caused repeated config writes).
    if processed:
        try:
            active_scene = getattr(getattr(bpy, 'context', None), 'scene', None) or first_scene
            settings = getattr(active_scene, 'sas_settings', None) if active_scene is not None else None
            sync_always_on_properties_to_loader(
                settings, context=getattr(bpy, 'context', None), load_enabled=False,
            )
        except Exception:
            pass
    try:
        active_scene = getattr(getattr(bpy, 'context', None), 'scene', None) or first_scene
        active_settings = getattr(active_scene, 'sas_settings', None) if active_scene is not None else None
        if _sas_is_live_settings_instance(active_settings, getattr(bpy, 'context', None)):
            _sas_set_settings_handlers_enabled(bool(getattr(active_settings, 'npanel_state_auto_save', True)))
    except Exception:
        pass
    return processed


def ensure_settings_loaded_for_scene(scene=None) -> None:
    try:
        scene = scene or getattr(bpy.context, 'scene', None)
        payload_hash = _sas_current_payload_hash()
        if scene is not None and payload_hash and _sas_scene_hash(scene) == payload_hash:
            return
        apply_saved_settings_to_scene(scene, force=False)
    except Exception:
        pass



@persistent
def _sas_settings_load_pre(_dummy=None):
    global _SAS_SETTINGS_PAYLOAD_LOADED
    # Scene switch/reload is an explicit commit boundary for deferred scalar
    # snapshots. Failure leaves the dirty flag set and never overwrites a corrupt
    # config with defaults.
    try:
        save_all_external_settings(
            context=getattr(bpy, 'context', None), force=True,
            include_npanel_settings=bool(_SAS_SETTINGS_DIRTY),
        )
    except Exception:
        pass
    _SAS_SETTINGS_SCENE_HASHES.clear()
    _SAS_SETTINGS_PAYLOAD_LOADED = False
    try:
        from . import ui
        ui.invalidate_performance_cache(reason='load_pre', clear=True)
    except Exception:
        pass
    try:
        from . import runtime_persistence
        runtime_persistence.clear_runtime_caches()
    except Exception:
        pass
    try:
        from . import config_store
        config_store.clear_cache()
    except Exception:
        pass
    return None


@persistent
def _sas_settings_load_post(_dummy=None):
    # One authoritative read for the complete N-panel section.  The same
    # immutable snapshot is passed to the all-Scene restore and the common
    # WindowManager compatibility layer; common no longer reapplies Scene RNA.
    payload = _sas_load_settings_payload(refresh=True)
    processed_scenes = apply_saved_settings_to_all_scenes(force=False, payload=payload)
    try:
        from . import common
        common_payload = common.load_settings_file(payload=payload)
        common.apply_persistent_settings(
            getattr(bpy, 'context', None), payload=common_payload,
        )
    except Exception:
        pass
    try:
        from . import runtime_persistence
        runtime_persistence.apply_saved_runtime_properties(
            context=getattr(bpy, 'context', None), force=True,
        )
    except Exception:
        pass
    # A processed Scene already synchronized process-global background
    # options and performed the finite enabled-tool refresh exactly once.
    # Retain the fallback only for payload-less files/no-Scene contexts.
    if not processed_scenes:
        try:
            _sas_schedule_enabled_background_tools()
        except Exception:
            pass
    # A public addon enable runs register() inside RestrictBlend. The first
    # unrestricted load boundary therefore rebinds the exact live Scene owner
    # only after the saved ON/OFF policy has been restored.
    _sas_bind_settings_owner_if_ready(getattr(bpy, 'context', None))
    return None


@persistent
def _sas_settings_save_pre(_dummy=None):
    try:
        save_all_external_settings(context=getattr(bpy, 'context', None), force=True)
    except Exception:
        pass
    return None


@persistent
def _sas_settings_quit_pre(_dummy=None):
    try:
        save_all_external_settings(context=getattr(bpy, 'context', None), force=True)
    except Exception:
        pass
    return None


def _sas_settings_autosave_timer():
    """Compatibility callback for old generations; never reschedules."""
    return None


def _register_settings_autosave_timer() -> None:
    global _SAS_SETTINGS_TIMER_REGISTERED
    # Blender 5.1 runtime verification showed that persistent autosave timers can
    # keep background startup tests alive after the script has finished. Settings
    # are still saved by explicit property update callbacks and save_pre, so keep
    # this timer disabled to avoid UI/mode-transition and headless-exit hazards.
    _SAS_SETTINGS_TIMER_REGISTERED = False
    try:
        if bpy.app.timers.is_registered(_sas_settings_autosave_timer):
            bpy.app.timers.unregister(_sas_settings_autosave_timer)
    except Exception:
        pass


def _unregister_settings_autosave_timer() -> None:
    global _SAS_SETTINGS_TIMER_REGISTERED
    _SAS_SETTINGS_TIMER_REGISTERED = False
    try:
        if bpy.app.timers.is_registered(_sas_settings_autosave_timer):
            bpy.app.timers.unregister(_sas_settings_autosave_timer)
    except Exception:
        pass


def _sas_cancel_settings_owner_ready(generation: int = 0) -> None:
    """Cancel only this generation's bounded context-ready callback."""
    global _SAS_SETTINGS_READY_TIMER_REGISTERED, _SAS_SETTINGS_READY_GENERATION
    expected = int(generation or 0)
    pending = int(_SAS_SETTINGS_READY_GENERATION or 0)
    if expected and pending not in {0, expected}:
        return
    try:
        if bpy.app.timers.is_registered(_sas_settings_context_ready_once):
            bpy.app.timers.unregister(_sas_settings_context_ready_once)
    except Exception:
        pass
    _SAS_SETTINGS_READY_TIMER_REGISTERED = False
    if not expected or pending == expected:
        _SAS_SETTINGS_READY_GENERATION = 0


def _sas_bind_settings_owner_if_ready(context=None, settings=None) -> bool:
    """Bind the exact live RNA owner without reading or writing configuration."""
    generation = int(_SAS_SETTINGS_OWNER_GENERATION or 0)
    if generation <= 0:
        return False
    try:
        from . import lifecycle
        if int(lifecycle.current_generation() or 0) != generation:
            return False
        if settings is None:
            settings = _sas_resolve_settings_instance(None, context)
        if not _sas_is_live_settings_instance(settings, context):
            return False
        scene = getattr(settings, 'id_data', None)
        from . import config_store
        return bool(config_store.bind_owner_generation(
            generation,
            settings_pointer=int(settings.as_pointer()),
            scene_pointer=int(scene.as_pointer()),
        ))
    except Exception:
        return False


def _sas_initialize_settings_owner_if_ready(expected_generation: int) -> bool:
    """Restore the cold policy first, then bind one exact current owner."""
    generation = int(expected_generation or 0)
    if generation <= 0 or generation != int(_SAS_SETTINGS_OWNER_GENERATION or 0):
        return False
    try:
        from . import lifecycle
        if int(lifecycle.current_generation() or 0) != generation:
            return False
        context = getattr(bpy, 'context', None)
        settings = _sas_resolve_settings_instance(None, context)
        if settings is None:
            return False
        payload = _sas_load_settings_payload(refresh=True)
        apply_saved_settings_to_all_scenes(force=False, payload=payload)
        settings = _sas_resolve_settings_instance(None, context)
        return _sas_bind_settings_owner_if_ready(context, settings)
    except Exception:
        return False


def _sas_settings_context_ready_once():
    """One nonpersistent post-register attempt; never reschedules."""
    global _SAS_SETTINGS_READY_TIMER_REGISTERED, _SAS_SETTINGS_READY_GENERATION
    generation = int(_SAS_SETTINGS_READY_GENERATION or 0)
    _SAS_SETTINGS_READY_TIMER_REGISTERED = False
    _SAS_SETTINGS_READY_GENERATION = 0
    _sas_initialize_settings_owner_if_ready(generation)
    return None


def _sas_schedule_settings_owner_ready(ledger, generation: int) -> bool:
    """Schedule one generation-owned, cancelable context-ready attempt."""
    global _SAS_SETTINGS_READY_TIMER_REGISTERED, _SAS_SETTINGS_READY_GENERATION
    value = int(generation or 0)
    if value <= 0:
        return False
    _SAS_SETTINGS_READY_GENERATION = value
    try:
        if not bpy.app.timers.is_registered(_sas_settings_context_ready_once):
            result = bpy.app.timers.register(
                _sas_settings_context_ready_once, first_interval=0.0, persistent=False,
            )
            if result is False:
                _SAS_SETTINGS_READY_GENERATION = 0
                return False
        _SAS_SETTINGS_READY_TIMER_REGISTERED = True
        if ledger is not None:
            ledger.record_callback(
                kind='settings_context_ready_once',
                label='settings context-ready owner bind',
                identity=(value, id(_sas_settings_context_ready_once)),
                remover=lambda _generation=value: _sas_cancel_settings_owner_ready(_generation),
                metadata={'callback': _sas_settings_context_ready_once, 'generation': value},
            )
        return True
    except Exception:
        _sas_cancel_settings_owner_ready(value)
        return False


def _sas_request_settings_owner_ready(generation: int) -> bool:
    """Record a deferred bind request without arming a timer in RestrictBlend."""
    global _SAS_SETTINGS_READY_GENERATION
    value = int(generation or 0)
    if value <= 0:
        return False
    _SAS_SETTINGS_READY_GENERATION = value
    return True


def arm_settings_context_ready(ledger) -> bool:
    """Arm the one-shot only after runtime publishes the current generation."""
    generation = int(_SAS_SETTINGS_READY_GENERATION or 0)
    if generation <= 0:
        return True
    if generation != int(_SAS_SETTINGS_OWNER_GENERATION or 0):
        return False
    if ledger is None or generation != int(getattr(ledger, 'generation', 0) or 0):
        return False
    try:
        from . import lifecycle
        if int(lifecycle.current_generation() or 0) != generation:
            return False
    except Exception:
        return False
    return _sas_schedule_settings_owner_ready(ledger, generation)


def install_settings_persistence(ledger=None) -> bool:
    """Register lifecycle handlers independently without a hard enable failure."""
    global _SAS_SETTINGS_HANDLER_REGISTERED, _SAS_SETTINGS_HANDLER_LEDGER
    global _SAS_SETTINGS_OWNER_GENERATION
    _register_settings_autosave_timer()
    if _SAS_SETTINGS_HANDLER_REGISTERED:
        return True
    pairs = [
        (bpy.app.handlers.load_pre, _sas_settings_load_pre, 'settings.load_pre'),
        (bpy.app.handlers.load_post, _sas_settings_load_post, 'settings.load_post'),
        (bpy.app.handlers.save_pre, _sas_settings_save_pre, 'settings.save_pre'),
    ]
    quit_pre = getattr(bpy.app.handlers, 'quit_pre', None)
    if quit_pre is not None:
        pairs.append((quit_pre, _sas_settings_quit_pre, 'settings.quit_pre'))
    acquired = []
    healthy = True
    for collection, callback, label in pairs:
        try:
            if ledger is not None:
                if not ledger.append_handler(collection, callback, label=label):
                    healthy = False
                    ledger.note_failure(f'handler registration returned False: {label}')
            else:
                if not any(item is callback for item in collection):
                    collection.append(callback)
                if any(item is callback for item in collection):
                    acquired.append((collection, callback))
                else:
                    healthy = False
        except Exception as exc:
            healthy = False
            if ledger is not None:
                try:
                    ledger.note_failure(f'handler registration failed {label}: {type(exc).__name__}: {exc}')
                except Exception:
                    pass
    expected = len(pairs)
    if ledger is not None:
        owned = sum(
            1 for collection, callback, _label in pairs
            if any(
                record.kind == 'handler'
                and record.metadata.get('collection') is collection
                and record.metadata.get('callback') is callback
                and record.active
                for record in ledger.records
            )
        )
        complete = owned == expected
    else:
        complete = len(acquired) == expected
    _SAS_SETTINGS_HANDLER_REGISTERED = bool(complete)
    _SAS_SETTINGS_HANDLER_LEDGER = ledger if complete else None
    _SAS_SETTINGS_OWNER_GENERATION = int(getattr(ledger, 'generation', 0) or 0) if complete else 0
    owner_ready = bool(complete and _sas_bind_settings_owner_if_ready(getattr(bpy, 'context', None)))
    owner_deferred = bool(
        complete and not owner_ready
        and _sas_request_settings_owner_ready(_SAS_SETTINGS_OWNER_GENERATION)
    )
    return bool(healthy and complete and (owner_ready or owner_deferred))


def _sas_settings_handler_pairs():
    pairs = [
        (bpy.app.handlers.load_pre, _sas_settings_load_pre, 'settings.load_pre'),
        (bpy.app.handlers.load_post, _sas_settings_load_post, 'settings.load_post'),
        (bpy.app.handlers.save_pre, _sas_settings_save_pre, 'settings.save_pre'),
    ]
    quit_pre = getattr(bpy.app.handlers, 'quit_pre', None)
    if quit_pre is not None:
        pairs.append((quit_pre, _sas_settings_quit_pre, 'settings.quit_pre'))
    return pairs


def _sas_set_settings_handlers_enabled(enabled: bool) -> bool:
    """Acquire/release only the exact N-panel persistence handler identities."""
    global _SAS_SETTINGS_HANDLER_REGISTERED
    pairs = _sas_settings_handler_pairs()
    if enabled:
        healthy = True
        for collection, callback, label in pairs:
            try:
                if _SAS_SETTINGS_HANDLER_LEDGER is not None:
                    _SAS_SETTINGS_HANDLER_LEDGER.append_handler(collection, callback, label=label)
                elif not any(item is callback for item in collection):
                    collection.append(callback)
                healthy = healthy and any(item is callback for item in collection)
            except Exception:
                healthy = False
        _SAS_SETTINGS_HANDLER_REGISTERED = bool(healthy)
        return bool(healthy)
    for collection, callback, _label in pairs:
        try:
            for index in range(len(collection) - 1, -1, -1):
                if collection[index] is callback:
                    collection.remove(callback)
        except Exception:
            pass
    _SAS_SETTINGS_HANDLER_REGISTERED = False
    return not any(any(item is callback for item in collection) for collection, callback, _label in pairs)


def uninstall_settings_persistence(*, remove_handlers: bool = True) -> None:
    global _SAS_SETTINGS_HANDLER_REGISTERED, _SAS_SETTINGS_HANDLER_LEDGER
    global _SAS_SETTINGS_PAYLOAD_LOADED, _SAS_SETTINGS_OWNER_GENERATION
    # The central barrier decides whether unregister may write. Save-OFF never
    # gains an implicit force exception here.
    try:
        save_all_external_settings(context=getattr(bpy, 'context', None), force=True)
    except Exception:
        pass
    if remove_handlers:
        _sas_set_settings_handlers_enabled(False)
    _unregister_settings_autosave_timer()
    _sas_cancel_settings_owner_ready(_SAS_SETTINGS_OWNER_GENERATION)
    _SAS_SETTINGS_SCENE_HASHES.clear()
    _SAS_SETTINGS_PAYLOAD_LOADED = False
    try:
        from . import ui
        ui.invalidate_performance_cache(reason='unregister', clear=True)
    except Exception:
        pass
    _SAS_SETTINGS_HANDLER_REGISTERED = False
    _SAS_SETTINGS_HANDLER_LEDGER = None
    try:
        from . import config_store
        config_store.clear_owner_generation(_SAS_SETTINGS_OWNER_GENERATION)
    except Exception:
        pass
    _SAS_SETTINGS_OWNER_GENERATION = 0


def _sas_is_live_settings_instance(settings, context=None) -> bool:
    """Validate exact live RNA/Scene/generation ownership using scalar identity."""
    if settings is None or not _SAS_SETTINGS_OWNER_GENERATION:
        return False
    try:
        from . import lifecycle
        if int(lifecycle.current_generation() or 0) != int(_SAS_SETTINGS_OWNER_GENERATION):
            return False
        settings_pointer = int(settings.as_pointer())
        scene = getattr(settings, 'id_data', None)
        if settings_pointer <= 0 or not isinstance(scene, bpy.types.Scene):
            return False
        if int(scene.as_pointer()) <= 0:
            return False
        bound = getattr(scene, 'sas_settings', None)
        if bound is None or int(bound.as_pointer()) != settings_pointer:
            return False
        context_scene = getattr(context, 'scene', None) if context is not None else None
        if context_scene is not None and int(context_scene.as_pointer()) != int(scene.as_pointer()):
            return False
        return True
    except Exception:
        return False

def _sas_resolve_settings_instance(self, context=None):
    try:
        if hasattr(self, 'compact_diag_mode') and hasattr(self, 'ui_tab'):
            return self if _sas_is_live_settings_instance(self, context) else None
    except Exception:
        if self is not None:
            return None
    try:
        scene = getattr(context, 'scene', None) if context is not None else getattr(bpy.context, 'scene', None)
        settings = getattr(scene, 'sas_settings', None)
        return settings if _sas_is_live_settings_instance(settings, context) else None
    except Exception:
        return None


def _sas_restore_scene_before_first_update(settings, context=None, preserve_identifier: str = '') -> bool:
    """Seed a newly activated Scene before any default RNA update can save.

    Blender may materialise a Scene's PointerProperty while ``window.scene`` is
    changing.  Some RNA defaults then emit update callbacks before load_post or
    the first panel draw.  Without this guard that pristine default group can
    replace the canonical user profile.  A marked Scene has already been
    restored; an unmarked Scene is seeded once and the synthetic update is
    consumed without writing.
    """
    global _SAS_SETTINGS_APPLYING
    payload_hash = _sas_current_payload_hash()
    if _SAS_SETTINGS_APPLYING or not payload_hash or not _sas_is_live_settings_instance(settings, context):
        return False
    try:
        scene = getattr(settings, 'id_data', None)
        if not isinstance(scene, bpy.types.Scene):
            scene = getattr(context, 'scene', None) if context is not None else getattr(bpy.context, 'scene', None)
    except Exception:
        scene = None
    if scene is None or _sas_scene_hash(scene) == payload_hash:
        return False
    preserve_identifier = str(preserve_identifier or '').strip()
    preserved_value = None
    has_preserved_value = False
    if preserve_identifier and _sas_is_portable_setting_identifier(preserve_identifier):
        try:
            preserved_value = getattr(settings, preserve_identifier)
            if hasattr(preserved_value, '__iter__') and not isinstance(preserved_value, (str, bytes, dict, set, frozenset)):
                preserved_value = tuple(preserved_value)
            elif isinstance(preserved_value, (set, frozenset)):
                preserved_value = set(preserved_value)
            has_preserved_value = True
        except Exception:
            has_preserved_value = False
    try:
        payload = _sas_load_settings_payload(refresh=False)
        restored = apply_saved_settings_to_scene(
            scene, force=False, payload=payload, payload_hash=payload_hash,
        )
        # A real update that arrived after a bounded/deferred restore was queued
        # is newer authority. Restore the remainder of the profile, then put the
        # changed scalar back while callbacks are suppressed so stale saved data
        # can never overwrite the later event.
        if restored and has_preserved_value:
            previous_applying = bool(_SAS_SETTINGS_APPLYING)
            _SAS_SETTINGS_APPLYING = True
            try:
                setattr(settings, preserve_identifier, preserved_value)
            finally:
                _SAS_SETTINGS_APPLYING = previous_applying
        return bool(restored)
    except Exception:
        return False


def _sas_make_persisting_update(existing_update, identifier: str = ''):
    def _update(self, context):
        settings = _sas_resolve_settings_instance(self, context)
        _sas_restore_scene_before_first_update(settings, context, str(identifier or ''))
        if _sas_bind_settings_owner_if_ready(context, settings):
            _sas_cancel_settings_owner_ready(_SAS_SETTINGS_OWNER_GENERATION)
        if not _SAS_SETTINGS_APPLYING:
            _SAS_SETTINGS_EXPLICIT_UPDATES.add(str(identifier or '').strip())
        if callable(existing_update):
            try:
                existing_update(self, context)
            except TypeError:
                try:
                    existing_update(context)
                except Exception:
                    pass
            except Exception:
                pass
        save_settings_if_changed(settings, context=context)
        if not _SAS_SETTINGS_APPLYING:
            try:
                from . import ui
                ui.invalidate_performance_cache(reason='settings_update', context=context)
            except Exception:
                pass
    return _update


_SAS_PERSISTENCE_WRAPPED_PROPS: set[int] = set()


def _sas_install_update_callbacks(*classes) -> None:
    for cls in classes:
        try:
            annotations = getattr(cls, '__annotations__', {}) or {}
        except Exception:
            annotations = {}
        if not isinstance(annotations, dict):
            continue
        for identifier, prop_def in annotations.items():
            marker = id(prop_def)
            if marker in _SAS_PERSISTENCE_WRAPPED_PROPS:
                continue
            try:
                keywords = getattr(prop_def, 'keywords', None)
            except Exception:
                keywords = None
            if keywords is None and isinstance(prop_def, tuple) and len(prop_def) >= 2 and isinstance(prop_def[1], dict):
                keywords = prop_def[1]
            if not isinstance(keywords, dict):
                continue
            # CollectionProperty does not support an update callback. Skip the
            # parent collection property itself; item properties are wrapped
            # separately below, and the panel draw path still persists changed
            # collection content when it changes.
            try:
                if keywords.get('type') in classes:
                    continue
            except Exception:
                pass
            existing = keywords.get('update')
            keywords['update'] = _sas_make_persisting_update(existing, str(identifier or ''))
            _SAS_PERSISTENCE_WRAPPED_PROPS.add(marker)


def _sas_overview_task_update(self, context):
    # Changing the Overview Task dropdown only switches the N-panel display.
    # Bundled tool modules are not imported until the user explicitly loads or
    # runs a tool, keeping startup and normal UI drawing lightweight.
    save_settings_if_changed(self, context=context)



def _sas_npanel_state_auto_save_update(self, context):
    """Persist the save-mode toggle itself immediately.

    Even when the toggle is turned off, the disabled state must be written to
    config/Smart_Animation_Suite/Smart_Animation_Suite.json so the next Blender launch keeps the same
    saving policy.
    """
    # Applying a saved profile sets this BoolProperty like every other RNA
    # field.  Treat that callback as restoration, not as a user action: a force
    # flush here would serialize the partially restored new Scene and replace
    # later settings with their defaults before the loop reaches them.
    if _SAS_SETTINGS_APPLYING:
        return
    global _SAS_SETTINGS_LAST_ERROR
    try:
        settings = _sas_resolve_settings_instance(self, context)
        if settings is None:
            _SAS_SETTINGS_LAST_ERROR = 'OFF_REJECTED_INVALID_OWNER'
            return
        if not _sas_bind_settings_owner_if_ready(context, settings):
            _SAS_SETTINGS_LAST_ERROR = 'OFF_REJECTED_UNBOUND_OWNER'
            return
        from . import config_store
        enabled = bool(getattr(settings, 'npanel_state_auto_save', True))
        if enabled:
            config_store.set_write_enabled(True)
            _sas_set_settings_handlers_enabled(True)
            if not save_settings_if_changed(settings, context=context, force=True):
                _SAS_SETTINGS_LAST_ERROR = str(config_store.read_status().get('last_write_status') or 'ON_SNAPSHOT_FAILED')
            else:
                save_all_external_settings(context=context, force=True, include_npanel_settings=False)
                _SAS_SETTINGS_LAST_ERROR = ''
        else:
            scene = getattr(settings, 'id_data', None)
            capability = config_store.issue_off_commit_capability(
                owner_generation=_SAS_SETTINGS_OWNER_GENERATION,
                settings_pointer=int(settings.as_pointer()),
                scene_pointer=int(scene.as_pointer()),
                previous_enabled=bool(config_store.write_enabled()),
                current_enabled=False,
            )
            if capability is None:
                _SAS_SETTINGS_LAST_ERROR = str(config_store.read_status().get('last_write_status') or 'OFF_CAPABILITY_REJECTED')
                return
            committed = save_settings_if_changed(
                settings, context=context, force=True,
                off_commit_capability=capability,
            )
            _SAS_SETTINGS_LAST_ERROR = '' if committed else str(
                config_store.read_status().get('last_write_status') or 'OFF_COMMIT_FAILED'
            )
            _sas_set_settings_handlers_enabled(False)
    except Exception:
        _SAS_SETTINGS_LAST_ERROR = 'SETTINGS_TOGGLE_EXCEPTION'


class SAS_Settings(PropertyGroup):
    ui_tab: EnumProperty(
        name="Workspace",
        description="Internal record of the workspace suggested by Smart Assist. To change what the N-panel shows, use the Task selector in Overview Task.",
        items=TAB_ITEMS,
        default='DASHBOARD',
    )
    show_inline_help: BoolProperty(
        name="Show Inline Help",
        description="Show short beginner-friendly explanations inside each section in addition to tooltips.",
        default=True,
    )
    show_always_on_toggle_group: BoolProperty(
        name="Show Always-on Toggle Group",
        description="Open the centralized always-on toggle group at the top of the Sidebar N-panel. This is disabled by default when the add-on is installed so the group starts closed.",
        default=False,
    )
    npanel_state_auto_save: BoolProperty(
        name="N-panel State Save",
        description="Function: controls whether Smart Animation writes all portable N-panel state and always-on switch values to config/Smart_Animation_Suite/Smart_Animation_Suite.json. How to use: enable this to save every supported setting change immediately; disabling writes the OFF state once and then blocks every automatic, force, fallback, save, load, shutdown, and unregister writer until you enable it again.",
        default=True,
        update=_sas_npanel_state_auto_save_update,
    )
    ui_section_overview_task_dropdown: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_overview: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_animation_recipes: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_animation: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_assets: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_transfer: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_migrated: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_scene_snapshot: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_recommended_next_step: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_action_slot: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_overview_actions: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_current_findings: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_operation_log: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_smart_studio_dashboard: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_smart_motion_director: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_smart_graph_optimizer: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_smart_visualizer: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_smart_physics_director: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_smart_contact_timing: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_smart_locomotion: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_smart_shape_control: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_smart_ifl: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_smart_retarget: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_cleanup_preview: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_timeline_hub: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_timing_hub: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_fx_hub: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_cleanup_hub: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_selection_sets: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_pose_snapshots: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_action_nla: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_motion_library: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_library_sequence: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_data_io: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_transfer_hub: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_retarget_profile: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    ui_section_mapping_preview: BoolProperty(
        name="UI Section State",
        description="Stores whether this Smart Animation UI section is open in the Sidebar N-panel.",
        default=False,
    )
    auto_backup_action: BoolProperty(
        name="Auto Backup Action",
        description="Before destructive cleanup operations, duplicate the current action as a safety backup.",
        default=True,
    )
    preview_only: BoolProperty(
        name="Preview Only",
        description="When enabled, cleanup tools do not modify data and instead report how many keys or channels would change.",
        default=False,
    )
    only_selected_curves: BoolProperty(
        name="Only Selected Curves",
        description="When enabled, cleanup tools affect only selected F-Curves in the active action.",
        default=False,
    )
    skip_locked_curves: BoolProperty(
        name="Skip Locked Curves",
        description="Do not edit F-Curves that are locked in the Graph Editor. This helps prevent accidental changes to protected channels.",
        default=True,
    )
    skip_muted_curves: BoolProperty(
        name="Skip Muted Curves",
        description="Do not edit muted F-Curves. This keeps intentionally disabled channels untouched during cleanup and procedural passes.",
        default=True,
    )
    skip_hidden_curves: BoolProperty(
        name="Skip Hidden Curves",
        description="Do not edit hidden F-Curves. Enable this for a safer compact workflow where only visible channels are changed.",
        default=True,
    )
    simplify_factor: FloatProperty(
        name="Simplify Factor",
        description="Allowed value deviation when removing in-between keys. Larger values remove more keys.",
        default=0.01,
        min=0.00001,
        max=100.0,
        precision=4,
    )
    remove_threshold: FloatProperty(
        name="Threshold",
        description="Small numerical threshold used to detect flat channels or duplicate values.",
        default=0.0001,
        min=0.0,
        max=10.0,
        precision=5,
    )
    marker_name: StringProperty(
        name="Marker Name",
        description="Name used when adding a new timeline marker on the current frame.",
        default="SAS Marker",
    )
    camera_sequence_start: IntProperty(
        name="Shot Start",
        description="Start frame used by the camera-sequence builder. This is the first cut marker frame when generating a compact shot board from selected cameras.",
        default=1,
        min=-100000,
        max=100000,
    )
    camera_sequence_shot_length: IntProperty(
        name="Shot Length",
        description="Number of frames assigned to each camera when creating a camera-shot marker sequence.",
        default=24,
        min=1,
        max=100000,
    )
    camera_sequence_gap: IntProperty(
        name="Shot Gap",
        description="Number of empty frames inserted between generated camera shots. Use 0 for back-to-back cuts.",
        default=0,
        min=0,
        max=100000,
    )
    camera_sequence_clear_existing: BoolProperty(
        name="Clear Older SAS Shots",
        description="Before building a new camera sequence, remove older Smart Animation shot markers so the generated shot board stays compact and predictable.",
        default=True,
    )
    camera_sequence_set_preview: BoolProperty(
        name="Preview Range from Shots",
        description="After building a camera-shot sequence, set the scene preview range to the generated shot range.",
        default=True,
    )
    camera_review_split_factor: FloatProperty(
        name="Review Split Ratio",
        description="Fraction used when splitting the current 3D View for camera review. Lower values keep a smaller camera side, while larger values make the split more even.",
        default=0.50,
        min=0.20,
        max=0.80,
        precision=2,
    )
    camera_review_split_direction: EnumProperty(
        name="Review Split Direction",
        description="Choose whether the review split opens side-by-side or top-and-bottom.",
        items=[
            ('VERTICAL', "Vertical", "Split the current 3D View left/right so one side can stay free and the other can show the scene camera."),
            ('HORIZONTAL', "Horizontal", "Split the current 3D View top/bottom so one side can stay free and the other can show the scene camera."),
        ],
        default='VERTICAL',
    )
    camera_review_lock_camera: BoolProperty(
        name="Lock Camera Review",
        description="Lock the camera side of the split to the scene camera so orbiting in the free view does not disturb the shot-review side.",
        default=True,
    )
    bake_range: EnumProperty(
        name="Bake Range",
        description="Choose whether baking uses the scene range, preview range, or a custom range.",
        items=BAKE_RANGE_ITEMS,
        default='SCENE',
    )
    custom_frame_start: IntProperty(
        name="Custom Start",
        description="Start frame used when Bake Range is set to Custom.",
        default=1,
    )
    custom_frame_end: IntProperty(
        name="Custom End",
        description="End frame used when Bake Range is set to Custom.",
        default=250,
    )
    frame_step: IntProperty(
        name="Bake Step",
        description="Frame step used by baking tools. 1 means every frame.",
        default=1,
        min=1,
        max=100,
    )
    physics_bake_clear_range: BoolProperty(
        name="Physics Bake Clear Existing Range",
        description="Before baking rigid-body motion, remove existing editable transform keys inside the bake range on the selected objects so the result stays clean and predictable.",
        default=True,
    )
    retime_use_range: BoolProperty(
        name="Use Range",
        description="When enabled, timing tools affect only keys inside the configured frame range. When disabled, they affect the full active action.",
        default=False,
    )
    retime_range_start: IntProperty(
        name="Range Start",
        description="Start frame used by timing tools when Timing Range is enabled.",
        default=1,
    )
    retime_range_end: IntProperty(
        name="Range End",
        description="End frame used by timing tools when Timing Range is enabled.",
        default=48,
    )
    retime_offset: IntProperty(
        name="Shift Frames",
        description="Number of frames used by Shift Keys. Positive values move keys later, negative values move keys earlier.",
        default=5,
        min=-100000,
        max=100000,
    )
    retime_scale: FloatProperty(
        name="Scale Factor",
        description="Timing scale multiplier used by Scale Key Timing. Values above 1.0 expand timing, values below 1.0 compress it.",
        default=1.1,
        min=0.01,
        max=100.0,
        precision=3,
    )
    retime_pivot_mode: EnumProperty(
        name="Pivot",
        description="Choose which frame acts as the pivot when scaling timing.",
        items=[
            ('CURRENT', "Current Frame", "Use the current scene frame as the timing pivot."),
            ('START', "Range Start", "Use the timing range start frame as the pivot."),
            ('CENTER', "Range Center", "Use the center of the timing range as the pivot."),
            ('CUSTOM', "Custom Frame", "Use a custom frame number as the pivot."),
        ],
        default='CURRENT',
    )
    retime_custom_pivot: IntProperty(
        name="Custom Pivot",
        description="Custom pivot frame used when Pivot is set to Custom Frame.",
        default=1,
    )
    snapshot_name: StringProperty(
        name="Snapshot Name",
        description="Name used when storing a pose snapshot. If empty, a default name is generated.",
        default="",
    )
    selection_set_name: StringProperty(
        name="Selection Set Name",
        description="Name used when storing the current object or pose-bone selection as a reusable set. If empty, a default name is generated.",
        default="",
    )
    selection_set_text_name: StringProperty(
        name="Selection Set Text",
        description="Blender text datablock used when exporting or importing selection-set JSON so picker-style sets can move between shots or scenes.",
        default="Smart Animation Selection Sets",
    )
    pose_profile_name: StringProperty(
        name="Pose Profile Text",
        description="Blender text datablock name used when exporting or importing pose snapshot JSON profiles.",
        default="SAS_Pose_Snapshots",
    )
    retarget_source: PointerProperty(
        name="Source Rig",
        description="Armature object that contains the source skeleton for retarget preparation.",
        type=bpy.types.Object,
    )
    retarget_target: PointerProperty(
        name="Target Rig",
        description="Armature object that will receive the mapped source skeleton names.",
        type=bpy.types.Object,
    )
    strip_namespaces: BoolProperty(
        name="Strip Namespaces",
        description="Ignore namespace prefixes like CharacterA:Arm.L when trying to match bones.",
        default=True,
    )
    use_side_aliases: BoolProperty(
        name="Use Side Aliases",
        description="Treat common left/right naming styles like .L, _R, Left, and Right as equivalent.",
        default=True,
    )
    retarget_replace_existing: BoolProperty(
        name="Replace Existing SAS Constraints",
        description="Before building a live retarget preview, remove older Smart Animation retarget constraints from the target rig so the preview stays clean and predictable.",
        default=True,
    )
    retarget_constraint_influence: FloatProperty(
        name="Retarget Influence",
        description="Live retarget constraints created by Smart Animation. 1.0 means full influence, smaller values allow blending with the target rig's existing motion.",
        default=1.0,
        min=0.0,
        max=1.0,
        precision=3,
    )
    retarget_space: EnumProperty(
        name="Retarget Space",
        description="Choose whether live retarget preview constraints copy pose-space transforms or world-space transforms. Pose is usually better for similarly structured rigs, World is a fallback for unusual setups.",
        items=[
            ('POSE', "Pose", "Copy pose-space transforms for bone-to-bone preview."),
            ('WORLD', "World", "Copy world-space transforms for bone-to-bone preview."),
        ],
        default='POSE',
    )
    clear_constraints_after_bake: BoolProperty(
        name="Clear Constraints After Bake",
        description="After baking a live retarget preview into keys, automatically remove Smart Animation retarget constraints from the target rig.",
        default=True,
    )
    library_assign_mode: EnumProperty(
        name="Library Assign Mode",
        description="Choose whether a library action is assigned as a linked original or as a duplicated editable copy.",
        items=[
            ('COPY', "Copy", "Assign a safe duplicated copy so edits do not affect the library source."),
            ('LINK', "Link", "Assign the original action directly."),
        ],
        default='COPY',
    )
    library_sequence_start: IntProperty(
        name="Sequence Start",
        description="Start frame used when laying out motion-library actions sequentially into NLA clips.",
        default=1,
        min=-100000,
        max=100000,
    )
    library_sequence_gap: IntProperty(
        name="Sequence Gap",
        description="Frame gap inserted between motion-library clips when sequencing them into NLA.",
        default=4,
        min=0,
        max=100000,
    )
    library_sequence_clear_existing: BoolProperty(
        name="Clear Older SAS Sequences",
        description="Before sequencing the library into NLA, remove older Smart Animation sequence tracks so the result stays readable.",
        default=True,
    )
    log_limit: IntProperty(
        name="Log Limit",
        description="Maximum number of recent operations kept in the in-panel activity log.",
        default=12,
        min=3,
        max=100,
    )
    ui_search: StringProperty(
        name="Find Tool",
        description="Filter visible sections by keyword. Search in English or Japanese to focus the panel on tools like bake, retarget, cleanup, or root motion.",
        default="",
    )
    compact_tab: EnumProperty(
        name="Compact Workspace",
        description="Internal record of the task suggested by Smart Assist. To change what the N-panel shows, use the Task selector in Overview Task.",
        items=[
            ('OVERVIEW', "Overview", "Scene summary, diagnostics, and one-click guidance."),
            ('SMART', "Smart", "upgraded Animation Recipe hub for advanced animation-assistance workflows."),
            ('ANIMATE', "Animate", "Daily timeline, timing, cleanup, and motion-FX tools."),
            ('ASSETS', "Assets", "Reusable poses, selections, and motion-library tools."),
            ('TRANSFER', "Transfer", "Retarget, root motion, and mapping tools."),
        ],
        default='OVERVIEW',
    )
    compact_diag_mode: EnumProperty(
        name="Overview Task",
        description="Choose which Smart Animation function group is displayed in the N-panel. All Functions shows every built-in section and every migrated bundled tool group.",
        items=_COMPACT_OVERVIEW_TASK_ITEMS,
        default='ALL',
        update=_sas_overview_task_update,
    )
    compact_timeline_mode: EnumProperty(
        name="Timeline Mode",
        description="Choose a combined timeline or review action from the compact animation hub.",
        items=[
            ('NEW_ACTION', "New Action", "Create a new action on the active object."),
            ('DUPLICATE_ACTION', "Duplicate Action", "Duplicate the current action for safe variation work."),
            ('INSERT_KEYS', "Insert All Keys", "Insert location, rotation, and scale keys on the current frame."),
            ('INSERT_LOC_KEYS', "Insert Location Keys", "Insert only location keys on the current frame."),
            ('INSERT_ROT_KEYS', "Insert Rotation Keys", "Insert only rotation keys on the current frame."),
            ('INSERT_SCALE_KEYS', "Insert Scale Keys", "Insert only scale keys on the current frame."),
            ('INSERT_VISUAL_KEYS', "Insert Visual Keys", "Insert visually evaluated transform keys on the current frame."),
            ('BAKE_VISUAL', "Bake Visual Range", "Bake the current selection to editable visual keys across the chosen frame range."),
            ('SHAPE_KEYS_ALL', "Shape Keys: All", "Insert keys on all available shape keys."),
            ('SHAPE_KEYS_ACTIVE', "Shape Keys: Active", "Insert a key on the active shape key only."),
            ('ADD_MARKER', "Add Marker", "Add a named marker on the current frame."),
            ('MARK_SELECTED_KEYS', "Mark Selected Keys", "Add markers on the selected keyframes."),
            ('PREV_MARKER', "Jump Prev Marker", "Jump to the previous timeline marker."),
            ('NEXT_MARKER', "Jump Next Marker", "Jump to the next timeline marker."),
            ('ADD_CAMERA_MARKER', "Add Camera Marker", "Add a camera marker from the active or scene camera."),
            ('PREV_CAMERA_MARKER', "Jump Prev Camera Marker", "Jump to the previous camera marker."),
            ('NEXT_CAMERA_MARKER', "Jump Next Camera Marker", "Jump to the next camera marker."),
            ('PREVIEW_FROM_KEYS', "Preview from Keys", "Set the preview range from the active key span."),
            ('PREVIEW_FROM_SOUND', "Preview from Sound", "Set the preview range from the active sound strip."),
            ('PREVIEW_FROM_CURRENT_SHOT', "Preview from Current Shot", "Set the preview range from the current camera-marker shot."),
            ('PREVIEW_FROM_ALL_SHOTS', "Preview from All Shots", "Set the preview range from all camera markers."),
            ('CLEAR_PREVIEW', "Clear Preview", "Clear the preview range."),
            ('PLAYBACK_BLOCKING', "Playback: Blocking", "Apply blocking-friendly playback settings."),
            ('PLAYBACK_REVIEW', "Playback: Review", "Apply review-friendly playback settings."),
            ('PLAYBACK_LIPSYNC', "Playback: Lip Sync", "Apply lip-sync-friendly playback settings."),
            ('CAMERA_SEQUENCE', "Camera Sequence", "Build evenly spaced camera cut markers from selected cameras."),
            ('CAMERA_REVIEW_SPLIT', "Dual View Review", "Split the 3D View into free and camera-locked review panes."),
        ],
        default='INSERT_KEYS',
    )
    compact_timing_mode: EnumProperty(
        name="Timing Mode",
        description="Choose the timing or spacing tool used by the compact timing hub.",
        items=[
            ('SHIFT', "Shift Keys", "Offset keys forward or backward in time."),
            ('SCALE', "Scale Timing", "Scale key timing around a pivot."),
            ('EVEN', "Even Timing", "Distribute the affected keys evenly."),
            ('TWEEN', "Tween", "Create or refresh an in-between on the current frame."),
            ('PUSH_PULL', "Push Pull", "Push or pull keyed values away from their current pose."),
            ('SCALE_TO_NEIGHBORS', "Scale to Neighbors", "Scale selected keys relative to the surrounding anchors."),
            ('CONTACT_HOLD', "Contact Hold", "Flatten curves across a hold range from the current value."),
            ('STEPPED_PREVIEW', "Stepped Preview", "Create a stepped preview pass for blocking review."),
            ('OVERLAP', "Overlap Pass", "Apply a lightweight overlap pass to selected keys."),
            ('CASCADE', "Cascade Delay", "Delay the selected objects or controls in sequence."),
            ('RANDOMIZE', "Randomize Timing", "Randomize key timing inside the configured range."),
            ('AUTO_FULCRUM', "Auto Fulcrum", "Auto-clean planted contacts and fulcrum-style holds."),
        ],
        default='SHIFT',
    )
    compact_fx_mode: EnumProperty(
        name="FX Mode",
        description="Choose the secondary-motion, helper, or baked-FX task used by the compact FX hub.",
        items=[
            ('LIMITED', "Limited Bake", "Create an editable on-twos / on-fours style duplicate action."),
            ('SPRING', "Spring Dynamics", "Bake overlap, drag, and jiggle into editable curves."),
            ('SPRING_MAGIC', "Spring Magic", "Bake higher-precision chain secondary motion with optional collision."),
            ('PHYSICS', "Physics Bake", "Bake rigid-body transforms back into editable keys."),
            ('SIGNAL', "Motion Signal", "Generate editable signal-based delta motion."),
            ('STRETCH', "Motion Stretch", "Bake smear-like delta scale from motion travel."),
            ('VEHICLE', "Vehicle Drive", "Bake wheel spin and optional steering from a moving vehicle source."),
            ('TRANSFORM_REVEAL', "Transform Reveal", "Create a staggered transform-based reveal on selected objects."),
            ('REVEAL', "Deformer Reveal", "Build a modifier-based reveal or unfold effect."),
            ('TRAIL', "Trail Curve", "Generate a sampled trail curve."),
            ('GHOST', "Ghost Preview", "Generate past and future ghost preview copies."),
            ('BALLISTIC_GUIDE', "Ballistic Guide", "Generate a ballistic guide arc."),
            ('BALLISTIC_BAKE', "Ballistic Bake", "Bake a ballistic correction back into keys."),
            ('CAMERA_SHAKE', "Camera Shake", "Apply a camera shake preset."),
            ('LOOP', "Loop Helper", "Apply a cycles-based loop preset."),
            ('NOISE', "Noise Modifier", "Apply a procedural noise modifier."),
            ('PATHS', "Motion Paths", "Calculate motion paths."),
            ('DYNAMIC_PARENT', "Dynamic Parent", "Switch dynamic parenting for the current selection."),
            ('COPY_GLOBAL', "Copy Global", "Copy the current global transform."),
            ('PASTE_GLOBAL', "Paste Global", "Paste the copied global transform."),
        ],
        default='LIMITED',
    )
    compact_cleanup_mode: EnumProperty(
        name="Cleanup Mode",
        description="Choose the cleanup or curve-fix task used by the compact cleanup hub.",
        items=[
            ('PREVIEW', "Preview Cleanup", "Estimate what the cleanup tools would change."),
            ('SIMPLIFY', "Simplify Curves", "Remove in-between keys using the simplify threshold."),
            ('SMOOTH', "Smooth Curves", "Smooth editable curves."),
            ('REMOVE_DUPLICATES', "Remove Duplicates", "Remove duplicate keys."),
            ('DELETE_STATIC', "Delete Static", "Delete static channels with no meaningful change."),
            ('UNBAKE', "Smart Unbake", "Reduce dense baked animation into lighter editable keys."),
            ('EULER', "Euler Filter", "Fix Euler flips in rotation curves."),
            ('TANGENT', "Tangent Preset", "Apply the selected tangent or interpolation preset."),
            ('SHAPE_SMOOTH', "Shape Smooth", "Smooth shape-key curves."),
            ('SHAPE_OPTIMIZE', "Shape Optimize", "Optimize shape-key curves."),
            ('CLEAR_STEP', "Clear Step Preview", "Remove Smart Animation stepped preview keys."),
            ('CLEAR_TRAILS', "Clear Trails", "Remove Smart Animation trail objects."),
            ('CLEAR_GHOSTS', "Clear Ghosts", "Remove Smart Animation ghost preview objects."),
            ('CLEAR_BALLISTICS', "Clear Ballistics", "Remove Smart Animation ballistic guides."),
            ('CLEAR_SHAKE', "Clear Shake", "Remove Smart Animation camera shake keys or modifiers."),
            ('CLEAR_LOOP', "Clear Loop", "Remove Smart Animation loop modifiers."),
            ('CLEAR_NOISE', "Clear Noise", "Remove Smart Animation noise modifiers."),
            ('CLEAR_PATHS', "Clear Paths", "Clear motion paths."),
            ('CLEAR_DYNAMIC_PARENT', "Clear Dynamic Parent", "Clear Smart Animation dynamic parenting."),
        ],
        default='PREVIEW',
    )
    compact_data_mode: EnumProperty(
        name="Data Mode",
        description="Choose the asset or retarget import/export task used by the compact data hub.",
        items=[
            ('POSE_EXPORT', "Export Poses", "Export pose snapshots to Blender text data and the clipboard."),
            ('POSE_IMPORT', "Import Poses", "Import pose snapshots from Blender text data."),
            ('SELECTION_EXPORT', "Export Selections", "Export selection sets to Blender text data and the clipboard."),
            ('SELECTION_IMPORT', "Import Selections", "Import selection sets from Blender text data."),
            ('LIBRARY_EXPORT', "Export Library", "Export the motion library manifest."),
            ('LIBRARY_IMPORT', "Import Library", "Import the motion library manifest."),
            ('LIBRARY_PRUNE', "Prune Library", "Remove invalid motion-library entries."),
            ('MAP_EXPORT', "Export Bone Map", "Export the retarget bone map."),
            ('MAP_IMPORT', "Import Bone Map", "Import the retarget bone map."),
        ],
        default='POSE_EXPORT',
    )
    compact_transfer_mode: EnumProperty(
        name="Transfer Mode",
        description="Choose the retarget or root-motion action used by the compact transfer hub.",
        items=[
            ('BUILD_MAP', "Build Bone Map", "Build a name-based source-to-target preview mapping."),
            ('LIVE_PREVIEW', "Rebuild + Live", "Rebuild the mapping and apply a live retarget preview."),
            ('APPLY_CURRENT_MAP', "Apply Current Map", "Apply the current bone map without rebuilding it first."),
            ('REFRESH_PREVIEW', "Refresh Preview", "Refresh the current live retarget preview."),
            ('BAKE_TO_KEYS', "Bake Preview", "Bake the current live retarget preview into regular keys."),
            ('CLEAR_PREVIEW', "Clear Preview", "Remove the current live retarget preview constraints."),
            ('ROOT_MOTION', "Extract Root Motion", "Create a root-motion helper action."),
            ('IN_PLACE', "Create In Place", "Create an in-place version of the current action."),
        ],
        default='BUILD_MAP',
    )
    show_safety_hints: BoolProperty(
        name="Show Safety Hints",
        description="Show risk badges and safety reminders around destructive and retarget-related actions.",
        default=True,
    )
    retarget_profile_name: StringProperty(
        name="Retarget Profile Text",
        description="Blender text datablock name used when exporting or importing bone-map JSON profiles.",
        default="SAS_Retarget_Profile",
    )
    root_motion_bone: StringProperty(
        name="Root Bone",
        description="Root or hips bone name used by root-motion utilities. Leave empty to operate on the object transform instead of a pose bone.",
        default="root",
    )
    root_motion_axis_x: BoolProperty(
        name="Root Motion X",
        description="Preserve or isolate movement on the X axis when generating root-motion helper actions.",
        default=True,
    )
    root_motion_axis_y: BoolProperty(
        name="Root Motion Y",
        description="Preserve or isolate movement on the Y axis when generating root-motion helper actions.",
        default=True,
    )
    root_motion_axis_z: BoolProperty(
        name="Root Motion Z",
        description="Preserve or isolate movement on the Z axis when generating root-motion helper actions.",
        default=False,
    )
    nla_blend_mode: EnumProperty(
        name="NLA Blend",
        description="Blend mode used when Smart Animation pushes an action into NLA. Replace behaves like a normal layer, while Add and Combine are useful for layer-style animation stacking.",
        items=[
            ('REPLACE', "Replace", "Use a standard replacing strip."),
            ('COMBINE', "Combine", "Combine compatible channels additively where possible."),
            ('ADD', "Add", "Add the strip on top of lower animation."),
            ('SUBTRACT', "Subtract", "Subtract the strip from lower animation."),
            ('MULTIPLY', "Multiply", "Multiply compatible channels."),
        ],
        default='REPLACE',
    )
    layer_action_name: StringProperty(
        name="Layer Action Name",
        description="Create the editable action name used when Smart Animation builds a new non-destructive animation layer.",
        default="SAS_Layer",
    )
    tween_factor: FloatProperty(
        name="Tween Factor",
        description="Blend between neighboring keys on the current frame. 0.0 matches the previous key, 1.0 matches the next key, and values outside that range create anticipation or overshoot.",
        default=0.5,
        min=-2.0,
        max=2.0,
        precision=3,
    )
    tween_mode: EnumProperty(
        name="Tween Mode",
        description="Choose how Tween computes the in-between. Linear matches classic tween tools, Ease softens the ends with a smoothstep curve, and Hermite uses surrounding keys to preserve motion flow for a smarter breakdown.",
        items=[
            ('LINEAR', "Linear", "Blend the previous and next keys directly. This matches classic tween tools."),
            ('EASE', "Ease", "Use a smoothstep ease between the neighboring keys for softer breakdowns near the ends."),
            ('HERMITE', "Hermite", "Use surrounding keys to preserve motion flow and create a smarter in-between."),
        ],
        default='LINEAR',
    )
    push_pull_factor: FloatProperty(
        name="Push/Pull Factor",
        description="animBot-style push or pull amount applied around the current frame. Positive values exaggerate spacing away from the straight interpolation, while negative values pull the key back toward the in-between line.",
        default=0.25,
        min=-1.0,
        max=5.0,
        precision=3,
    )

    neighbor_scale_factor: FloatProperty(
        name="Scale To Neighbors",
        description="Scale selected keys, or the active timing range when no keys are selected, around the straight line formed by the surrounding anchor keys. 1.0 keeps the current shape, 0.0 flattens to the neighboring span, and values above 1 exaggerate the shape.",
        default=1.0,
        min=-3.0,
        max=5.0,
        precision=3,
    )
    contact_hold_start: IntProperty(
        name="Contact Hold Start",
        description="Start frame of the planted-contact or fulcrum hold range. Use this to keep feet, hands, or held props stable while they stay in contact.",
        default=1,
        min=-100000,
        max=100000,
    )
    contact_hold_end: IntProperty(
        name="Contact Hold End",
        description="End frame of the planted-contact or fulcrum hold range. Use this to keep feet, hands, or held props stable while they stay in contact.",
        default=12,
        min=-100000,
        max=100000,
    )
    fulcrum_velocity_threshold: FloatProperty(
        name="Fulcrum Threshold",
        description="Maximum frame-to-frame value change treated as planted motion by the automatic fulcrum cleanup. Lower values are stricter and safer.",
        default=0.001,
        min=0.0,
        max=10.0,
        precision=5,
    )
    fulcrum_min_hold: IntProperty(
        name="Minimum Hold",
        description="Minimum number of consecutive frames that must stay under the fulcrum threshold before Smart Animation converts them into a planted hold.",
        default=3,
        min=2,
        max=1000,
    )
    fulcrum_only_location: BoolProperty(
        name="Location Only",
        description="Limit automatic fulcrum cleanup to location-style curves. Keep this enabled for safer foot-lock and prop-contact cleanup.",
        default=True,
    )
    snapshot_blend_factor: FloatProperty(
        name="Pose Blend",
        description="Blend strength used when applying the highlighted pose snapshot. 1.0 applies the full stored pose, while smaller values partially blend from the current pose.",
        default=1.0,
        min=0.0,
        max=1.0,
        precision=3,
    )
    step_preview_frames: IntProperty(
        name="Step Size",
        description="Number of frames held by the stepped tools. 1 works every frame, 2 approximates animating on twos, 3 on threes, 4 on fours, and larger values create longer held timing.",
        default=2,
        min=1,
        max=24,
    )
    step_preview_replace_existing: BoolProperty(
        name="Replace SAS Step",
        description="Remove older Smart Animation stepped-preview modifiers before adding a new one so the result stays predictable.",
        default=True,
    )
    limited_bake_step: IntProperty(
        name="Limited Step",
        description="Step size used by the limited-animation baker. 2 creates an editable on-twos style copy, 4 approximates on-fours, and larger values create stronger held timing.",
        default=2,
        min=1,
        max=24,
    )
    limited_interpolation: EnumProperty(
        name="Limited Interpolation",
        description="Interpolation used by the baked limited-animation copy. Constant gives the clearest held look, Linear is a lighter stepped feel, and Bezier keeps editable handles.",
        items=[
            ('CONSTANT', "Constant", "Bake held timing with constant interpolation for a clear limited-animation look."),
            ('LINEAR', "Linear", "Bake held timing with linear interpolation for simple straight breakdowns."),
            ('BEZIER', "Bezier", "Bake held timing with Bezier interpolation for a softer editable result."),
        ],
        default='CONSTANT',
    )
    spring_stiffness: FloatProperty(
        name="Spring Stiffness",
        description="How strongly the baked spring pass chases the original motion. Higher values react faster and lower values create softer drag.",
        default=0.28,
        min=0.0,
        max=2.0,
        precision=3,
    )
    spring_damping: FloatProperty(
        name="Spring Damping",
        description="How quickly the baked spring pass settles down. Higher values keep more motion and lower values damp the motion faster.",
        default=0.82,
        min=0.0,
        max=0.999,
        precision=3,
    )
    spring_blend: FloatProperty(
        name="Spring Blend",
        description="Blend between the original animation and the baked spring result. 0 keeps the original motion and 1 applies the full spring pass.",
        default=1.0,
        min=0.0,
        max=1.0,
        precision=3,
    )
    spring_sample_step: IntProperty(
        name="Spring Sample Step",
        description="Frame step used while baking the spring dynamics pass. 1 samples every frame for the most detail, larger values create lighter results.",
        default=1,
        min=1,
        max=24,
    )
    spring_auto_simplify: BoolProperty(
        name="Spring Auto Simplify",
        description="After baking the spring pass, simplify the resulting dense keys using the Smart Unbake tolerance settings.",
        default=True,
    )
    spring_magic_axis: EnumProperty(
        name="Spring Magic Axis",
        description="Local chain axis used by Spring Magic. For Blender bones this is usually Y, while linked helper objects may use X depending on how their pivots are aligned.",
        items=[
            ('X_POS', "+X", "Use the positive local X axis as the chain direction. Useful for linked helper objects aligned to X."),
            ('X_NEG', "-X", "Use the negative local X axis as the chain direction."),
            ('Y_POS', "+Y", "Use the positive local Y axis as the chain direction. This is the safest default for Blender pose bones."),
            ('Y_NEG', "-Y", "Use the negative local Y axis as the chain direction."),
            ('Z_POS', "+Z", "Use the positive local Z axis as the chain direction."),
            ('Z_NEG', "-Z", "Use the negative local Z axis as the chain direction."),
        ],
        default='Y_POS',
    )
    spring_magic_mode: EnumProperty(
        name="Spring Magic Mode",
        description="Choose how much of the Spring Magic style result is baked. Swing rotates the chain only, Swing + Twist adds springy roll around the chain axis, and Swing + Twist + Scale also writes squash-and-stretch style scale.",
        items=[
            ('SWING', "Swing", "Bake swing and follow-through rotation only."),
            ('SWING_TWIST', "Swing + Twist", "Bake swing plus delayed twist around the chosen chain axis."),
            ('SWING_TWIST_SCALE', "Swing + Twist + Scale", "Bake swing, twist, and squash-and-stretch style scale for a fuller Spring Magic style pass."),
        ],
        default='SWING_TWIST',
    )
    spring_magic_twist_strength: FloatProperty(
        name="Spring Magic Twist",
        description="How strongly Spring Magic delays twist around the chosen chain axis. Higher values exaggerate corkscrew style follow-through.",
        default=0.75,
        min=0.0,
        max=2.0,
        precision=3,
    )
    spring_magic_scale_strength: FloatProperty(
        name="Spring Magic Scale",
        description="How strongly Spring Magic adds squash-and-stretch from the spring lag amount. 0 disables scale exaggeration even in the Scale mode.",
        default=0.35,
        min=0.0,
        max=3.0,
        precision=3,
    )
    spring_magic_scale_max: FloatProperty(
        name="Spring Magic Scale Max",
        description="Maximum stretch multiplier written by Spring Magic when scale mode is active. Lower values are safer, higher values create broader cartoony deformation.",
        default=1.35,
        min=1.0,
        max=5.0,
        precision=3,
    )
    spring_magic_clear_range: BoolProperty(
        name="Spring Magic Clear Range",
        description="Before baking Spring Magic, remove existing editable rotation and scale keys for the targeted channels inside the bake range so the result stays predictable.",
        default=True,
    )
    spring_magic_substeps: IntProperty(
        name="Spring Magic Substeps",
        description="Internal substeps used inside each baked Spring Magic sample. Higher values improve stability, reduce tunneling, and make collision and fast motion more accurate, but they also increase bake time.",
        default=4,
        min=1,
        max=24,
    )
    spring_magic_collision_iterations: IntProperty(
        name="Spring Magic Collision Iterations",
        description="How many push-out passes Spring Magic performs after each simulation substep. Higher values help tips settle more reliably against colliders with less clipping, especially around corners or thin blockers.",
        default=3,
        min=1,
        max=16,
    )
    spring_magic_collision_object_enabled: BoolProperty(
        name="Spring Magic Use Collider Object",
        description="Also treat one explicitly chosen object as a Spring Magic collider. This is useful when you want a single torso, helmet, wall, or proxy object to collide without building a dedicated collection first.",
        default=False,
    )
    spring_magic_collision_object: PointerProperty(
        name="Spring Magic Collider Object",
        description="Explicit object used as an extra Spring Magic collider. Mesh-like objects use their evaluated surface, while other objects fall back to a bounds-based blocker so ordinary scene objects can still act as colliders.",
        type=bpy.types.Object,
    )
    spring_magic_collision_mode: EnumProperty(
        name="Spring Magic Collision",
        description="Choose whether Spring Magic uses no collision, a simple global floor plane, a collider collection, or both together.",
        items=[
            ('NONE', "None", "Do not apply collision during Spring Magic baking."),
            ('FLOOR', "Floor", "Use a simple world-space floor plane for collision."),
            ('COLLECTION', "Collection", "Use mesh objects from the chosen collection as Spring Magic colliders."),
            ('BOTH', "Floor + Collection", "Use both the floor plane and the collider collection together."),
        ],
        default='NONE',
    )
    spring_magic_collision_collection: PointerProperty(
        name="Spring Magic Collider Collection",
        description="Collection whose mesh-like objects are treated as Spring Magic collision surfaces. This is useful for floors, walls, torsos, helmets, or any simple collision blockers.",
        type=bpy.types.Collection,
    )
    spring_magic_collision_radius: FloatProperty(
        name="Spring Magic Collision Radius",
        description="Sphere radius used around each simulated Spring Magic tip when testing collisions. Increase this to keep tails, ears, straps, or linked helpers farther away from colliders.",
        default=0.02,
        min=0.0,
        max=10.0,
        precision=4,
    )
    spring_magic_collision_margin: FloatProperty(
        name="Spring Magic Collision Margin",
        description="Extra collision padding added on top of the collision radius when Spring Magic pushes simulated tips away from colliders.",
        default=0.005,
        min=0.0,
        max=10.0,
        precision=4,
    )
    spring_magic_floor_height: FloatProperty(
        name="Spring Magic Floor Height",
        description="World-space Z height used by the simple Spring Magic floor collider. Use 0 for a standard ground plane, or raise/lower it to match your scene.",
        default=0.0,
        min=-10000.0,
        max=10000.0,
        precision=3,
    )

    motion_stretch_axis: EnumProperty(
        name="Stretch Axis",
        description="Axis that receives the main stretch when Motion Stretch writes editable delta-scale keys. Match this to the visual long direction of the object.",
        items=[
            ('X', "X", "Stretch along the local X axis."),
            ('Y', "Y", "Stretch along the local Y axis."),
            ('Z', "Z", "Stretch along the local Z axis."),
        ],
        default='Y',
    )
    motion_stretch_plane: EnumProperty(
        name="Stretch Plane",
        description="World-space movement plane sampled when Motion Stretch estimates speed. Use XY for ground motion, XZ or YZ for side views, and XYZ for full 3D movement.",
        items=[
            ('XY', "XY", "Use horizontal XY motion when estimating stretch speed."),
            ('XZ', "XZ", "Use XZ motion when estimating stretch speed."),
            ('YZ', "YZ", "Use YZ motion when estimating stretch speed."),
            ('XYZ', "XYZ", "Use full 3D motion when estimating stretch speed."),
        ],
        default='XYZ',
    )
    motion_stretch_strength: FloatProperty(
        name="Stretch Strength",
        description="How strongly sampled travel speed is converted into stretch length. Increase this for stronger smear-style exaggeration and reduce it for subtle polish.",
        default=0.12,
        min=0.0,
        max=50.0,
        precision=4,
    )
    motion_stretch_squash: FloatProperty(
        name="Squash",
        description="How much the two non-stretch axes compress while Motion Stretch elongates the chosen stretch axis. Lower values keep volume changes subtle and higher values create a more cartoon look.",
        default=0.5,
        min=0.0,
        max=2.0,
        precision=3,
    )
    motion_stretch_max: FloatProperty(
        name="Max Stretch",
        description="Maximum total stretch multiplier written by Motion Stretch. 1.0 disables extra stretch, 2.0 allows doubling the chosen axis, and larger values create more extreme smear.",
        default=1.75,
        min=1.0,
        max=20.0,
        precision=3,
    )
    motion_stretch_replace_existing: BoolProperty(
        name="Replace Older SAS Stretch",
        description="Before writing new Motion Stretch curves, clear older Smart Animation stretch curves on the same objects. Non-SAS delta-scale animation is never removed automatically.",
        default=True,
    )
    vehicle_wheel_axis: EnumProperty(
        name="Wheel Axis",
        description="Rotation axis used when baking wheel spin. Match this to the local spin axis of the selected wheel objects.",
        items=[
            ('X', "X", "Spin the wheels around the local X axis."),
            ('Y', "Y", "Spin the wheels around the local Y axis."),
            ('Z', "Z", "Spin the wheels around the local Z axis."),
        ],
        default='X',
    )
    vehicle_motion_plane: EnumProperty(
        name="Motion Plane",
        description="World-space plane sampled from the active source object's travel when calculating wheel distance. Use XY for top-down motion, XZ for most ground vehicles, and XYZ for unusual full-3D setups.",
        items=[
            ('XY', "XY", "Use XY travel when accumulating wheel distance."),
            ('XZ', "XZ", "Use XZ travel when accumulating wheel distance."),
            ('YZ', "YZ", "Use YZ travel when accumulating wheel distance."),
            ('XYZ', "XYZ", "Use full 3D travel when accumulating wheel distance."),
        ],
        default='XY',
    )
    vehicle_radius_mode: EnumProperty(
        name="Radius Mode",
        description="Choose whether wheel radius is estimated automatically from the selected wheel objects or forced to a single manual value.",
        items=[
            ('AUTO', "Auto", "Estimate each wheel radius from its dimensions."),
            ('MANUAL', "Manual", "Use the manual wheel radius value for every selected wheel."),
        ],
        default='AUTO',
    )
    vehicle_wheel_radius: FloatProperty(
        name="Manual Wheel Radius",
        description="Manual wheel radius used when Radius Mode is set to Manual. This value is measured in scene units.",
        default=0.35,
        min=0.0001,
        max=100000.0,
        precision=4,
    )
    vehicle_spin_direction: EnumProperty(
        name="Spin Direction",
        description="Base spin direction used by the wheel baker before any optional side flipping is applied.",
        items=[
            ('FORWARD', "Forward", "Spin wheels in the forward direction."),
            ('REVERSE', "Reverse", "Spin wheels in the opposite direction."),
        ],
        default='FORWARD',
    )
    vehicle_auto_side_flip: BoolProperty(
        name="Auto Side Flip",
        description="Automatically invert the spin sign on obvious right-side wheel names such as .R or Right. This helps mirrored wheel setups that use opposite local axis orientation.",
        default=True,
    )
    vehicle_enable_steering: BoolProperty(
        name="Enable Steering",
        description="Also bake path-following steering onto the chosen steering axis. Select only the steering wheels or steering controls when you want front-only steering.",
        default=False,
    )
    vehicle_steering_axis: EnumProperty(
        name="Steering Axis",
        description="Rotation axis used for steering when Enable Steering is active.",
        items=[
            ('X', "X", "Use the X axis for steering."),
            ('Y', "Y", "Use the Y axis for steering."),
            ('Z', "Z", "Use the Z axis for steering."),
        ],
        default='Z',
    )
    vehicle_steering_max: FloatProperty(
        name="Max Steering",
        description="Maximum steering angle written by the vehicle helper. This clamps the path-based steering so the result stays art-directable.",
        default=0.785398,
        min=0.0,
        max=3.141593,
        precision=4,
        subtype='ANGLE',
    )
    vehicle_steering_reverse: BoolProperty(
        name="Reverse Steering",
        description="Invert the steering sign when the selected steering controls use the opposite local rotation direction.",
        default=False,
    )
    vehicle_replace_existing: BoolProperty(
        name="Replace Older SAS Wheel Drive",
        description="Before writing new wheel-drive curves, clear older Smart Animation wheel curves on the same objects. Non-SAS delta-rotation animation is never removed automatically.",
        default=True,
    )
    transform_reveal_distance: FloatProperty(
        name="Reveal Distance",
        description="How far selected objects start away from their final position when creating a transform reveal.",
        default=1.0,
        min=-100000.0,
        max=100000.0,
        precision=3,
    )
    transform_reveal_axis: EnumProperty(
        name="Reveal Axis",
        description="Axis used by the transform reveal helper when offsetting selected objects before they animate back into place.",
        items=[
            ('X_POS', "+X", "Offset reveals from the positive X axis."),
            ('X_NEG', "-X", "Offset reveals from the negative X axis."),
            ('Y_POS', "+Y", "Offset reveals from the positive Y axis."),
            ('Y_NEG', "-Y", "Offset reveals from the negative Y axis."),
            ('Z_POS', "+Z", "Offset reveals from the positive Z axis."),
            ('Z_NEG', "-Z", "Offset reveals from the negative Z axis."),
        ],
        default='Z_POS',
    )
    transform_reveal_stagger: IntProperty(
        name="Reveal Stagger",
        description="Frame delay added between each selected object when building a transform reveal.",
        default=2,
        min=0,
        max=100000,
    )
    transform_reveal_duration: IntProperty(
        name="Reveal Duration",
        description="Number of frames each object takes to travel from its reveal offset back to its stored final position.",
        default=8,
        min=1,
        max=100000,
    )
    transform_reveal_order: EnumProperty(
        name="Reveal Order",
        description="How selected objects are ordered when creating a staggered transform reveal.",
        items=[
            ('SELECTION', "Selection", "Use the current selected-object order."),
            ('NAME', "Name", "Sort selected objects by name before creating the reveal."),
            ('X', "X", "Sort selected objects by X location."),
            ('Y', "Y", "Sort selected objects by Y location."),
            ('Z', "Z", "Sort selected objects by Z location."),
        ],
        default='SELECTION',
    )
    deform_reveal_mode: EnumProperty(
        name="Deformer Reveal Mode",
        description="Choose a modifier-based reveal workflow. Build creates sequential polygon reveals, Roll adds a bend-driven scroll or roll style reveal, and Unfold adds a lighter sheet-opening pass for cards or panels.",
        items=[
            ('BUILD', "Build", "Create a Build modifier reveal for sequential polygon appearance."),
            ('ROLL', "Roll", "Create a bend-driven scroll or roll style reveal."),
            ('UNFOLD', "Unfold", "Create a bend-driven unfold reveal for sheet, card, and panel style assets."),
        ],
        default='BUILD',
    )
    deform_reveal_axis: EnumProperty(
        name="Deformer Reveal Axis",
        description="Axis used by the deformer reveal helper. For Roll mode, match this to the main roll axis of the selected mesh.",
        items=[
            ('X', "X", "Use the X axis for the roll-based reveal."),
            ('Y', "Y", "Use the Y axis for the roll-based reveal."),
            ('Z', "Z", "Use the Z axis for the roll-based reveal."),
        ],
        default='Y',
    )
    deform_reveal_angle: FloatProperty(
        name="Roll Angle",
        description="Total bend angle used by the Roll deformer reveal. 6.283 approximates one full revolution, while larger values create tighter rolls.",
        default=6.283185,
        min=0.0,
        max=62.83185,
        precision=4,
        subtype='ANGLE',
    )
    deform_reveal_replace_existing: BoolProperty(
        name="Replace Older SAS Deformer Reveal",
        description="Before creating a new modifier-based reveal, remove older Smart Animation reveal modifiers and helper empties from the same objects.",
        default=True,
    )
    signal_mode: EnumProperty(
        name="Signal Mode",
        description="Choose the procedural signal shape used by Motion Signal. Sine creates smooth looping motion, Noise creates organic drift, Pulse creates square-wave hits, and Step creates held stop-motion style motion.",
        items=[
            ('SINE', "Sine", "Use a smooth sine wave for looping procedural motion."),
            ('NOISE', "Noise", "Use layered pseudo-noise for organic wobble and drift."),
            ('PULSE', "Pulse", "Use a square-wave style pulse for snappy on/off motion."),
            ('STEP', "Step", "Use held stop-motion style motion sampled on stepped frames."),
        ],
        default='SINE',
    )
    signal_target: EnumProperty(
        name="Signal Target",
        description="Choose which delta-transform channel Motion Signal writes to. Delta channels keep the original animation intact and make the generated signal easy to clear.",
        items=[
            ('LOCATION', "Location", "Write the signal to delta location for offset motion."),
            ('ROTATION', "Rotation", "Write the signal to delta rotation for oscillation or shake."),
            ('SCALE', "Scale", "Write the signal to delta scale for pulsing or squash-and-stretch style motion."),
        ],
        default='LOCATION',
    )
    signal_axes: EnumProperty(
        name="Signal Axes",
        description="Axes affected by Motion Signal on the chosen delta channel.",
        items=[
            ('X', "X", "Affect the X axis only."),
            ('Y', "Y", "Affect the Y axis only."),
            ('Z', "Z", "Affect the Z axis only."),
            ('XY', "XY", "Affect the X and Y axes."),
            ('XZ', "XZ", "Affect the X and Z axes."),
            ('YZ', "YZ", "Affect the Y and Z axes."),
            ('XYZ', "XYZ", "Affect all three axes."),
        ],
        default='Y',
    )
    signal_time_mode: EnumProperty(
        name="Signal Time Mode",
        description="Choose whether Motion Signal interprets its rate as cycles per second or as beats per minute.",
        items=[
            ('HZ', "Frequency", "Interpret the signal rate as cycles per second."),
            ('BPM', "BPM", "Interpret the signal rate as beats per minute for music-synced timing."),
        ],
        default='HZ',
    )
    signal_amplitude: FloatProperty(
        name="Signal Amplitude",
        description="Amplitude of the Motion Signal on the chosen delta channel. For location this is distance, for rotation this is radians, and for scale this acts as a multiplier around 1.0.",
        default=0.25,
        min=0.0,
        max=100000.0,
        precision=4,
    )
    signal_frequency: FloatProperty(
        name="Signal Frequency",
        description="Cycles per second used by Motion Signal when Signal Time Mode is set to Frequency.",
        default=1.0,
        min=0.0,
        max=10000.0,
        precision=4,
    )
    signal_bpm: FloatProperty(
        name="Signal BPM",
        description="Beats per minute used by Motion Signal when Signal Time Mode is set to BPM.",
        default=120.0,
        min=1.0,
        max=10000.0,
        precision=3,
    )
    signal_phase: FloatProperty(
        name="Signal Phase",
        description="Global cycle offset applied to Motion Signal before it is written as keys. Use this to line up the loop with a beat or pose accent.",
        default=0.0,
        min=-1000.0,
        max=1000.0,
        precision=4,
    )
    signal_object_phase_offset: FloatProperty(
        name="Object Phase Offset",
        description="Extra cycle offset added per selected object order. This creates delay-chain or MoGraph-style cascades from one object to the next.",
        default=0.15,
        min=-1000.0,
        max=1000.0,
        precision=4,
    )
    signal_step_frames: IntProperty(
        name="Signal Step Frames",
        description="Number of frames held by the Step signal mode before a new value is sampled. Higher values create a stronger stop-motion feel.",
        default=2,
        min=1,
        max=100000,
    )
    signal_noise_seed: IntProperty(
        name="Signal Noise Seed",
        description="Seed offset used by the Motion Signal pseudo-noise generator. Change this when you want a different organic wobble pattern.",
        default=0,
        min=0,
        max=1000000,
    )
    signal_order: EnumProperty(
        name="Signal Order",
        description="How selected objects are ordered before Motion Signal applies the per-object phase offset.",
        items=[
            ('SELECTION', "Selection", "Use the current selected-object order."),
            ('NAME', "Name", "Sort selected objects by name before offsetting the signal."),
            ('X', "X", "Sort selected objects by X location before offsetting the signal."),
            ('Y', "Y", "Sort selected objects by Y location before offsetting the signal."),
            ('Z', "Z", "Sort selected objects by Z location before offsetting the signal."),
        ],
        default='SELECTION',
    )
    signal_replace_existing: BoolProperty(
        name="Replace Older SAS Signal",
        description="Before writing new Motion Signal curves, clear older Smart Animation signal curves on the same objects. Non-SAS delta animation is never removed automatically.",
        default=True,
    )
    noise_strength: FloatProperty(
        name="Noise Strength",
        description="Amplitude used by the procedural noise modifier helper. Small values are useful for handheld camera shake and subtle organic motion.",
        default=0.1,
        min=0.0,
        max=100.0,
        precision=3,
    )
    noise_scale: FloatProperty(
        name="Noise Scale",
        description="Time scale of the procedural noise modifier. Larger values create slower, broader motion and smaller values create tighter vibration.",
        default=15.0,
        min=0.001,
        max=1000.0,
        precision=3,
    )
    noise_phase: FloatProperty(
        name="Noise Phase",
        description="Phase offset used when creating or refreshing the procedural noise modifier.",
        default=0.0,
        min=-1000.0,
        max=1000.0,
        precision=3,
    )
    noise_depth: IntProperty(
        name="Noise Depth",
        description="Number of noise layers used by the procedural modifier. Higher values create more complex motion but may be harder to art-direct.",
        default=1,
        min=0,
        max=10,
    )
    curve_smooth_factor: FloatProperty(
        name="Smooth Factor",
        description="How strongly the curve smoothing tool moves key values toward a local average. Smaller values are safer for preserving performance detail.",
        default=0.5,
        min=0.0,
        max=1.0,
        precision=3,
    )
    curve_smooth_iterations: IntProperty(
        name="Smooth Iterations",
        description="How many passes the curve smoothing tool performs over each F-Curve.",
        default=1,
        min=1,
        max=32,
    )
    cascade_delay_frames: IntProperty(
        name="Cascade Delay",
        description="Frame offset added progressively to selected targets when using the cascade delay helper. Useful for overlap, follow-through, and staggered timing.",
        default=1,
        min=-250,
        max=250,
    )
    overlap_pass_frames: IntProperty(
        name="Overlap Frames",
        description="Frame delay used by the baked overlap helper. Larger values create more drag and follow-through on later target groups.",
        default=1,
        min=0,
        max=250,
    )
    overlap_pass_blend: FloatProperty(
        name="Overlap Blend",
        description="How strongly the overlap helper pulls keys toward earlier motion. Higher values exaggerate drag, lower values preserve more of the original timing.",
        default=0.65,
        min=0.0,
        max=1.0,
        precision=3,
    )
    overlap_pass_decay: FloatProperty(
        name="Overlap Decay",
        description="How much the overlap strength decreases for each successive target group. Lower values make deeper chains settle sooner, while 1.0 keeps the same strength on every group.",
        default=0.85,
        min=0.0,
        max=1.0,
        precision=3,
    )
    random_seed: IntProperty(
        name="Random Seed",
        description="Seed used by random timing tools so you can reproduce or vary a staggered result.",
        default=0,
        min=0,
        max=1000000,
    )
    random_timing_min: IntProperty(
        name="Random Min",
        description="Minimum frame offset used by the random timing helper.",
        default=-2,
        min=-1000,
        max=1000,
    )
    random_timing_max: IntProperty(
        name="Random Max",
        description="Maximum frame offset used by the random timing helper.",
        default=2,
        min=-1000,
        max=1000,
    )
    unbake_tolerance: FloatProperty(
        name="Unbake Tolerance",
        description="Allowed value deviation when converting dense baked curves into a sparse editable result. Smaller values preserve more detail, larger values remove more in-betweens.",
        default=0.02,
        min=0.0,
        max=1000.0,
        precision=4,
    )
    unbake_preserve_extrema: BoolProperty(
        name="Preserve Extremes",
        description="Keep obvious peaks, valleys, and plateau transition keys while simplifying baked curves into a sparse editable pass.",
        default=True,
    )
    tangent_mode: EnumProperty(
        name="Tangent Mode",
        description="Tangent and interpolation preset used by the tangent utility buttons. Flat makes plateau keys easier to clean, Broken creates a discontinuity-style sharp change, Auto and Auto Clamped restore smoothing, Vector creates straight handles, Linear changes interpolation, and Constant is useful for blocking.",
        items=[
            ('FLAT', "Flat", "Flatten selected or all key handles horizontally for cleanup or planted contacts."),
            ('BROKEN', "Broken", "Break the left and right handles so a key can change direction sharply like a discontinuity key."),
            ('AUTO', "Auto", "Use Blender's automatic Bezier handles for smooth motion."),
            ('AUTO_CLAMPED', "Auto Clamped", "Use clamped automatic handles to reduce overshoot."),
            ('VECTOR', "Vector", "Use straight vector handles for sharper directional changes."),
            ('LINEAR', "Linear", "Change interpolation to linear for even timing between keys."),
            ('CONSTANT', "Constant", "Change interpolation to constant for blocking or stepped results."),
        ],
        default='AUTO_CLAMPED',
    )
    trail_step: IntProperty(
        name="Trail Step",
        description="Frame increment used when sampling trail curves. 1 captures every frame, larger values create lighter preview trails.",
        default=1,
        min=1,
        max=24,
    )
    trail_resolution: IntProperty(
        name="Trail Resolution",
        description="Viewport and render resolution used for generated trail curves.",
        default=8,
        min=1,
        max=64,
    )
    trail_radius: FloatProperty(
        name="Trail Radius",
        description="Bevel radius used for generated trail curves. Small values work well for motion accents and sword arcs.",
        default=0.01,
        min=0.0,
        max=10.0,
        precision=4,
    )
    trail_radius_mode: EnumProperty(
        name="Trail Radius Mode",
        description="Choose whether the trail keeps a constant thickness or scales its thickness based on sampled speed. Speed mode is useful for accenting fast arcs and heavier impacts.",
        items=[
            ('CONSTANT', "Constant", "Keep one consistent trail thickness."),
            ('SPEED', "Speed", "Scale trail point radius from sampled motion speed."),
        ],
        default='CONSTANT',
    )
    trail_speed_scale: FloatProperty(
        name="Trail Speed Scale",
        description="Extra thickness added in Speed mode when the sampled motion becomes faster. Larger values exaggerate velocity changes in the trail.",
        default=1.0,
        min=0.0,
        max=10.0,
        precision=3,
    )
    trail_keep_previous: BoolProperty(
        name="Keep Previous Trails",
        description="When disabled, older Smart Animation trail objects are removed before a new trail is generated.",
        default=False,
    )
    ballistic_step: IntProperty(
        name="Ballistic Step",
        description="Frame step used when drawing the ballistic guide. Smaller values create denser arcs and larger values create lighter previews.",
        default=2,
        min=1,
        max=24,
    )
    ballistic_blend: FloatProperty(
        name="Ballistic Blend",
        description="Blend between the original sampled motion and the predicted ballistic arc when baking ballistic keys. 0 keeps the original motion, 1 writes the full physics arc, and values in-between act like a lightweight AutoPhysics-style correction.",
        default=1.0,
        min=0.0,
        max=1.0,
        precision=3,
    )
    ballistic_clear_range: BoolProperty(
        name="Clear Existing Ballistic Range",
        description="Before baking ballistic keys, remove existing location keys inside the bake range on the source so the new arc stays clean and editable.",
        default=True,
    )
    ballistic_keep_previous: BoolProperty(
        name="Keep Previous Ballistics",
        description="When disabled, older Smart Animation ballistic guide curves are removed before a new ballistic guide is generated.",
        default=False,
    )
    camera_shake_preset: EnumProperty(
        name="Camera Shake Preset",
        description="Preset used by the camera-shake helper. Subtle suits handheld polish, Heavy is useful for energetic cameras, and Impact is for hits or landings.",
        items=[
            ('SUBTLE', "Subtle", "Gentle handheld noise for light camera polish."),
            ('HEAVY', "Heavy", "Stronger handheld noise for active camera motion."),
            ('IMPACT', "Impact", "Short, sharper shake intended for hits or landings."),
        ],
        default='SUBTLE',
    )

    ghost_past_frames: IntProperty(
        name="Ghost Past",
        description="How many past ghost samples to generate on the active object or its driven meshes. Larger values show more history but create more preview objects.",
        default=2,
        min=0,
        max=48,
    )
    ghost_future_frames: IntProperty(
        name="Ghost Future",
        description="How many future ghost samples to generate on the active object or its driven meshes. Use this to inspect spacing and silhouette progression ahead of the current frame.",
        default=2,
        min=0,
        max=48,
    )
    ghost_step: IntProperty(
        name="Ghost Step",
        description="Frame spacing between ghost samples. 1 uses every frame, 2 approximates twos, and larger values create lighter previews.",
        default=2,
        min=1,
        max=24,
    )
    ghost_keep_previous: BoolProperty(
        name="Keep Previous Ghosts",
        description="When disabled, older Smart Animation ghost preview objects are removed before new ghosts are generated.",
        default=False,
    )
    loop_modifier_mode: EnumProperty(
        name="Loop Mode",
        description="Cycles modifier preset used by the loop helper. Repeat loops cleanly, Repeat Offset keeps value offsets, and Ping-Pong mirrors the motion back and forth.",
        items=[
            ('REPEAT', "Repeat", "Repeat the motion with a seamless loop."),
            ('REPEAT_OFFSET', "Repeat Offset", "Repeat while preserving the value offset between loop cycles."),
            ('MIRROR', "Ping-Pong", "Mirror the motion back and forth like a ping-pong loop."),
        ],
        default='REPEAT',
    )
    loop_modifier_scope: EnumProperty(
        name="Loop Scope",
        description="Choose whether the loop helper extends before the first key, after the last key, or in both directions.",
        items=[
            ('AFTER', "After", "Loop after the final key range."),
            ('BEFORE', "Before", "Loop before the first key range."),
            ('BOTH', "Both", "Loop in both directions."),
        ],
        default='BOTH',
    )
    loop_cycles_before: IntProperty(
        name="Cycles Before",
        description="Cycle count limit applied before the keyed range when the loop helper affects the Before or Both directions.",
        default=0,
        min=0,
        max=10000,
    )
    loop_cycles_after: IntProperty(
        name="Cycles After",
        description="Cycle count limit applied after the keyed range when the loop helper affects the After or Both directions.",
        default=0,
        min=0,
        max=10000,
    )
    pose_snapshot_text_name: StringProperty(
        name="Pose Snapshot Text",
        description="Blender text datablock used when exporting or importing pose snapshot JSON so poses can be shared between scenes without extra files.",
        default="Smart Animation Pose Snapshots",
    )
    library_manifest_text_name: StringProperty(
        name="Library Manifest Text",
        description="Blender text datablock used when exporting or importing the motion-library manifest JSON.",
        default="Smart Animation Motion Library",
    )
    smart_recipe: EnumProperty(
        name="Smart Recipe",
        description="Choose the upgraded Animation Recipe to run. Each recipe is a Blender-native equivalent of one or more researched animation-assistance tools, such as animBot, BroDynamics, MotionBuilder Story, Cascadeur AutoPhysics, or Cinema 4D Signal.",
        items=_SMART_RECIPE_ITEMS,
        default='SUPER_DIRECTOR',
    )
    smart_report_text_name: StringProperty(
        name="Coverage Text",
        description="Text datablock name used when Animation Recipes writes the feature coverage report that maps every researched source function to its built-in equivalent.",
        default="Animation Recipes Coverage",
    )
    smart_workflow_stage: EnumProperty(
        name="Smart Workflow Stage",
        description="Choose the production stage used by Smart Stage Director. Auto inspects the current context and selects a suitable pass; the other stages force a specific professional workflow.",
        items=_SMART_STAGE_ITEMS,
        default='AUTO',
    )
    smart_ui_density: EnumProperty(
        name="Smart UI Density",
        description="Choose how dense the Animation Recipes N-panel should be. Compact keeps the panel fast and clean, Balanced exposes common controls, and Studio exposes the full professional control surface.",
        items=_SMART_UI_DENSITY_ITEMS,
        default='BALANCED',
    )
    smart_show_advanced_controls: BoolProperty(
        name="Smart Advanced Controls",
        description="Show deep Animation Recipes control groups even when the UI Density is Compact. Enable this when you need per-feature tuning instead of the dashboard workflow.",
        default=False,
    )
    smart_preflight_before_run: BoolProperty(
        name="Smart Preflight Before Run",
        description="Before context-aware Smart Stage Director operations, run a lightweight quality check so dense curves, Euler jumps, static channels, and duplicate keys can steer the selected pass.",
        default=True,
    )
    smart_quality_gate_min_score: IntProperty(
        name="Smart Quality Gate",
        description="Minimum acceptable Smart Quality Report score for final review. When the score is below this value, Smart Stage Director writes a report and recommends polish before handoff.",
        default=85,
        min=0,
        max=100,
    )
    smart_motion_director_mode: EnumProperty(
        name="Motion Director Mode",
        description="Choose which animBot/AnimAide-style pose refinement pass Smart Motion Director runs. Full Director runs tween, push/pull, and scale-to-neighbor in sequence.",
        items=_SMART_MOTION_DIRECTOR_ITEMS,
        default='FULL',
    )
    smart_graph_include_unbake: BoolProperty(
        name="Graph Include Unbake",
        description="When enabled, Smart Graph Optimizer also runs Smart Unbake after safer cleanup passes, reducing dense baked curves into editable keyframes where possible.",
        default=True,
    )
    smart_graph_auto_clamped: BoolProperty(
        name="Graph Auto Clamped Handles",
        description="After Smart Graph Optimizer runs, set edited key handles to Auto Clamped Bezier so smoothed curves avoid common overshoot while staying editable.",
        default=True,
    )
    smart_precision_profile: EnumProperty(
        name="Smart Precision Profile",
        description="Choose how strongly Animation Recipes removes visually redundant keys during adaptive cleanup. Safe preserves the most hand-made detail, Balanced suits most production shots, and Aggressive is intended for dense baked data.",
        items=_SMART_PRECISION_PROFILE_ITEMS,
        default='BALANCED',
    )
    smart_enable_adaptive_precision: BoolProperty(
        name="Adaptive Precision",
        description="Enable range-aware sparse-key cleanup inside Smart Graph Optimizer and Precision Polish. The pass preserves endpoints and obvious extremes while reducing redundant in-between keys.",
        default=True,
    )
    smart_precision_curvature_guard: BoolProperty(
        name="Curvature Guard",
        description="During adaptive cleanup, preserve keys that define strong curvature, holds, slope direction changes, or high acceleration. This keeps arcs, impacts, and hand-made timing from being over-simplified.",
        default=True,
    )
    smart_motion_preserve_flow: BoolProperty(
        name="Preserve Flow Handles",
        description="After Motion Director creates or adjusts keys, set editable Bezier handles to Auto Clamped so pose changes keep smooth spacing without common overshoot artifacts.",
        default=True,
    )
    smart_quality_report_text_name: StringProperty(
        name="Quality Report Text",
        description="Text datablock name used when Smart Quality Report writes key density, duplicate, static-channel, Euler, and spacing diagnostics into the current Blender file.",
        default="Animation Recipes Quality Report",
    )
    smart_quality_sample_step: IntProperty(
        name="Quality Sample Step",
        description="Frame interval used when Smart Quality Report samples selected object motion to estimate maximum speed and acceleration. Smaller values are more precise but slower on long scenes.",
        default=2,
        min=1,
        max=1000,
    )
    smart_timing_intent: EnumProperty(
        name="Smart Timing Intent",
        description="Choose the interpolation intent used by Smart Timing Intent Solver. Auto follows the workflow stage; Blocking creates stepped holds, Spline creates auto-clamped flow, Impact protects hits, Float softens drift, and Mechanical keeps linear motion.",
        items=_SMART_TIMING_INTENT_ITEMS,
        default='AUTO',
    )
    smart_contact_floor_epsilon: FloatProperty(
        name="Contact Floor Epsilon",
        description="Vertical tolerance used by Smart Contact Stabilizer and Quality Report when detecting planted contact keys. Larger values catch more contacts, smaller values avoid flattening intentional lift-off.",
        default=0.015,
        min=0.0,
        max=10000.0,
        precision=4,
    )
    smart_contact_min_span: IntProperty(
        name="Contact Minimum Span",
        description="Minimum number of neighboring contact keys that must be detected before Smart Contact Stabilizer flattens the vertical channel. Use higher values to avoid changing one-frame taps.",
        default=2,
        min=1,
        max=64,
    )
    smart_contact_flatten_handles: BoolProperty(
        name="Flatten Contact Handles",
        description="When Smart Contact Stabilizer flattens contact keys, also flatten Bezier handles at the contact floor to reduce foot sliding, floating, and rebound jitter.",
        default=True,
    )
    smart_super_visual_review: BoolProperty(
        name="Super Pass Visual Review",
        description="After Smart Superior Director runs precision and timing passes, also create motion visual helpers so arcs, contact, and spacing can be reviewed immediately.",
        default=True,
    )
    smart_icon_button_scale: FloatProperty(
        name="Smart Icon Button Scale",
        description="Controls the height of the custom borderless Animation Recipes icon buttons. Higher values make the generated icon figures fill the N-panel button area more aggressively for faster visual recognition.",
        default=4.0,
        min=1.0,
        max=8.0,
        precision=2,
    )
    smart_show_icon_labels: BoolProperty(
        name="Show Icon Labels",
        description="Show a small localized label below each large Animation Recipes icon button. Disable this when you want a cleaner icon-first dashboard.",
        default=True,
    )
    smart_preserve_selected_keys: BoolProperty(
        name="Preserve Selected Keys",
        description="Protect selected keyframes during adaptive precision cleanup so intentional hand-edited timing and poses are not removed by automatic key reduction.",
        default=True,
    )
    smart_preserve_extreme_keys: BoolProperty(
        name="Preserve Extremes",
        description="Protect local extremes, hold boundaries, and obvious direction changes during adaptive key reduction. This keeps animation arcs and acting accents editable.",
        default=True,
    )
    smart_overshoot_tolerance: FloatProperty(
        name="Overshoot Tolerance",
        description="Relative tolerance used by Smart Quality Report when detecting Bezier overshoot candidates between neighboring keys. Lower values flag subtler overshoot; higher values ignore small artistic ease overshoot.",
        default=0.015,
        min=0.0,
        max=1.0,
        precision=4,
    )
    smart_visualizer_mode: EnumProperty(
        name="Visualizer Mode",
        description="Choose which motion review helpers Smart Visualize Motion creates: trails and ghosts, motion paths, ballistic guides, or all supported helpers.",
        items=_SMART_VISUALIZER_ITEMS,
        default='ALL',
    )
    smart_physics_director_mode: EnumProperty(
        name="Physics Director Mode",
        description="Choose the Cascadeur/BroDynamics-style physics-assist pass: automatic safe mix, ballistic guide, ballistic bake, fulcrum contact cleanup, spring motion, or rigid-body bake.",
        items=_SMART_PHYSICS_DIRECTOR_ITEMS,
        default='AUTO',
    )
    smart_locomotion_axis: EnumProperty(
        name="Locomotion Axis",
        description="World axis used as the forward travel direction when Smart Locomotion generates editable cyclic movement keys.",
        items=[
            ('X', "+X", "Move forward along world +X."),
            ('Y', "+Y", "Move forward along world +Y."),
            ('Z', "+Z", "Move forward along world +Z."),
            ('NEG_X', "-X", "Move forward along world -X."),
            ('NEG_Y', "-Y", "Move forward along world -Y."),
            ('NEG_Z', "-Z", "Move forward along world -Z."),
        ],
        default='X',
    )
    smart_locomotion_distance: FloatProperty(
        name="Locomotion Distance",
        description="Total travel distance written over the selected bake range by the Smart Locomotion generator.",
        default=2.0,
        min=-100000.0,
        max=100000.0,
        precision=3,
    )
    smart_locomotion_cycle_length: IntProperty(
        name="Locomotion Cycle",
        description="Cycle length in frames used by Smart Locomotion for bobbing and optional loop helper timing.",
        default=24,
        min=2,
        max=10000,
    )
    smart_locomotion_sample_density: IntProperty(
        name="Locomotion Sample Density",
        description="Number of generated samples per locomotion cycle. Higher values create smoother editable blocking keys and better contact timing at the cost of more keys.",
        default=12,
        min=4,
        max=64,
    )
    smart_locomotion_contact_lock: BoolProperty(
        name="Locomotion Contact Lock",
        description="Flatten the generated bob around walk or run contact phases so the blocking pass has more planted, less floaty contact timing.",
        default=True,
    )
    smart_locomotion_stride_width: FloatProperty(
        name="Locomotion Stride Width",
        description="Optional side-to-side offset added to generated locomotion for a clearer weight-shift read. Use 0 to keep the original centerline.",
        default=0.0,
        min=-10000.0,
        max=10000.0,
        precision=4,
    )
    smart_locomotion_style: EnumProperty(
        name="Locomotion Style",
        description="Choose the procedural blocking style used by Smart Locomotion. Walk, Run, Mechanical, and Cinematic produce different bob, yaw, and travel-ease patterns while still writing ordinary editable keys.",
        items=_SMART_LOCOMOTION_STYLE_ITEMS,
        default='WALK',
    )
    smart_locomotion_bob: FloatProperty(
        name="Locomotion Bob",
        description="Vertical bob amount added to generated Smart Locomotion keys. Use 0 for straight mechanical movement.",
        default=0.08,
        min=-10000.0,
        max=10000.0,
        precision=4,
    )
    smart_locomotion_yaw_degrees: FloatProperty(
        name="Locomotion Yaw",
        description="Optional side-to-side yaw amount in degrees for generated Smart Locomotion keys. Use 0 to keep rotation unchanged.",
        default=0.0,
        min=-180.0,
        max=180.0,
        precision=2,
    )
    smart_locomotion_add_cycles: BoolProperty(
        name="Add Cycle Modifier",
        description="After Smart Locomotion writes keys, add Cycles modifiers to generated curves so the base motion can repeat like CMotion-style procedural movement.",
        default=True,
    )
    smart_ifl_frame_start: IntProperty(
        name="IFL Start",
        description="Start frame applied to image texture sequence users by Smart Image Sequence Manager.",
        default=1,
        min=-100000,
        max=100000,
    )
    smart_ifl_frame_duration: IntProperty(
        name="IFL Duration",
        description="Playback duration in frames applied to image texture sequence users by Smart Image Sequence Manager.",
        default=100,
        min=1,
        max=100000,
    )
    smart_ifl_match_scene_range: BoolProperty(
        name="IFL Match Scene Range",
        description="Before applying image-sequence timing, copy the current scene frame start and frame duration into the IFL start and duration settings so monitor or 2D-effect playback matches the shot length.",
        default=False,
    )
    smart_ifl_frame_offset: IntProperty(
        name="IFL Offset",
        description="Frame offset applied to image texture sequence users. Key this value to synchronize monitor screens or 2D effects with animation timing.",
        default=0,
        min=-100000,
        max=100000,
    )
    smart_ifl_use_cyclic: BoolProperty(
        name="IFL Cyclic",
        description="Enable cyclic playback on compatible image texture sequence users.",
        default=False,
    )
    smart_ifl_key_offset: BoolProperty(
        name="Key IFL Offset",
        description="Insert a keyframe on the image sequence frame offset at the current frame after applying IFL settings.",
        default=False,
    )
    smart_shape_control_prefix: StringProperty(
        name="Shape Control Prefix",
        description="Prefix used for the custom properties created by Smart Shape Control Mixer. These properties drive matching shape-key values and can be keyed like normal controls.",
        default="SAS_Shape_",
    )
    smart_shape_control_key_controls: BoolProperty(
        name="Key Shape Controls",
        description="When creating or refreshing Smart Shape Control drivers, also insert a keyframe on each generated custom property at the current frame. This makes the controls immediately visible in the Dope Sheet and Graph Editor.",
        default=False,
    )

    pose_snapshots: CollectionProperty(type=SAS_PoseSnapshot, name="Pose Snapshots", description="Stored pose snapshots available for quick reapplication.")
    pose_snapshot_index: IntProperty(default=0, description="Currently selected pose snapshot row in the Smart Animation workspace list.")
    bone_map: CollectionProperty(type=SAS_BoneMapItem, name="Bone Mapping Preview", description="Preview list of source-to-target bone matches used by retarget tools.")
    bone_map_index: IntProperty(default=0, description="Currently selected bone mapping row in the retarget preview list.")
    operation_log: CollectionProperty(type=SAS_LogItem, name="Operation Log", description="Recent Smart Animation operations shown in the workspace log.")
    operation_log_index: IntProperty(default=0, description="Currently selected entry in the recent operation log list.")
    action_library: CollectionProperty(type=SAS_ActionLibraryItem, name="Action Library", description="In-panel action library entries for reuse and NLA pushing.")
    action_library_index: IntProperty(default=0, description="Currently selected action in the in-panel motion library list.")
    selection_sets: CollectionProperty(type=SAS_SelectionSetItem, name="Selection Sets", description="Reusable object or pose-bone selection sets stored in the current scene.")
    selection_set_index: IntProperty(default=0, description="Currently selected selection-set row in the Smart Animation workspace list.")



def _sas_tag_always_on_redraw(context=None) -> None:
    tagged: set[int] = set()
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) in {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}:
                    marker = id(area)
                    if marker not in tagged:
                        tagged.add(marker)
                        area.tag_redraw()
    except Exception:
        pass
    try:
        area = getattr(context, 'area', None) if context is not None else None
        if area is not None and id(area) not in tagged:
            area.tag_redraw()
    except Exception:
        pass


def _sas_schedule_enabled_background_tools() -> None:
    try:
        from . import tool_runtime
        schedule = getattr(tool_runtime, '_schedule_enabled_always_on_tools', None)
        if callable(schedule):
            schedule()
    except Exception:
        pass


def _sas_background_option_update_factory(alias: str, key: str, prop_name: str):
    alias = str(alias or '').strip()
    key = str(key or '').strip()
    prop_name = str(prop_name or '').strip()

    def _update(self, context):
        global _SAS_ALWAYS_ON_SYNCING
        if _SAS_ALWAYS_ON_SYNCING:
            return
        try:
            desired = bool(getattr(self, prop_name, False))
        except Exception:
            desired = False
        try:
            from . import loader
            if desired and not _SAS_SETTINGS_APPLYING:
                try:
                    loader.load_tool(alias)
                except Exception:
                    pass
                try:
                    from . import ui_runtime
                    collect_records = getattr(ui_runtime, '_collect_records', None)
                    if callable(collect_records):
                        collect_records()
                except Exception:
                    pass
            loader.set_background_option(alias, key, desired)
            if desired and _SAS_SETTINGS_APPLYING:
                _sas_schedule_enabled_background_tools()
        except Exception:
            pass
        save_settings_if_changed(_sas_resolve_settings_instance(self, context), context=context)
        _sas_tag_always_on_redraw(context)

    return _update


_SAS_STATIC_SECTION_KEYS = (
    'overview_task_dropdown', 'scene_snapshot', 'recommended_next_step', 'action_slot',
    'current_findings', 'operation_log', 'overview_actions', 'show_always_on_toggle_group',
    'smart_studio_dashboard', 'section_overview', 'section_animation_recipes',
    'section_animation', 'section_assets', 'section_transfer', 'section_migrated',
    'cleanup_preview', 'selection_sets', 'pose_snapshots', 'action_nla', 'motion_library',
    'library_sequence', 'data_io', 'smart_motion_director', 'smart_graph_optimizer',
    'smart_visualizer', 'smart_physics_director', 'smart_contact_timing',
    'smart_locomotion', 'smart_shape_control', 'smart_ifl', 'smart_retarget',
    'timeline_hub', 'timing_hub', 'fx_hub', 'cleanup_hub', 'transfer_hub',
    'retarget_profile', 'mapping_preview',
)
_SAS_RUNTIME_SECTION_SUFFIXES = (
    '', '_background', '_original_panels', '_runtime_properties',
    '_menus', '_operators', '_quick_access',
)
_SAS_RUNTIME_TOOL_ALIASES = (
    'offset', 'animall', 'transform_offset', 'bezier_curve_editor', 'camera_shakify',
    'easeit', 'sakura_poselib', 'simplify_curves_plus',
    'stop_motion_style_animator', 'storytools',
)
_SAS_OVERVIEW_GROUP_NAMES = ('pose', 'key_data', 'transform', 'timing', 'curve', 'camera', 'storyboard')


def _sas_section_storage_key(value: str) -> str:
    value = re.sub(r'[^0-9A-Za-z_]+', '_', str(value or '').strip()).strip('_').lower()
    if not value:
        value = 'section'
    if value == 'show_always_on_toggle_group':
        return value
    if value.startswith('ui_section_'):
        return value
    if value.startswith('section_'):
        return 'ui_' + value
    return 'ui_section_' + value


def _sas_install_static_section_properties() -> None:
    """Define every native/integrated collapsible state before RNA registration."""
    try:
        annotations = dict(getattr(SAS_Settings, '__annotations__', {}) or {})
    except Exception:
        annotations = {}
    names = list(_SAS_STATIC_SECTION_KEYS)
    names.extend(f'group_{group}' for group in _SAS_OVERVIEW_GROUP_NAMES)
    for alias in _SAS_RUNTIME_TOOL_ALIASES:
        names.extend(f'tool_{alias}{suffix}' for suffix in _SAS_RUNTIME_SECTION_SUFFIXES)
    for logical_name in names:
        prop_name = _sas_section_storage_key(logical_name)
        if prop_name in annotations:
            continue
        annotations[prop_name] = BoolProperty(
            name='UI Section State',
            description=(
                'Function: stores whether this Smart Animation N-panel section is open. '
                'How to use: click the section header to expand or collapse it; the value '
                'is persisted according to N-panel State Save.'
            ),
            default=False,
        )
    SAS_Settings.__annotations__ = annotations


def _sas_install_always_on_properties() -> None:
    try:
        from . import loader
        entries = list(loader.all_background_option_entries() or [])
    except Exception:
        entries = []
    if not entries:
        return
    try:
        annotations = getattr(SAS_Settings, '__annotations__', {}) or {}
    except Exception:
        annotations = {}
    if not isinstance(annotations, dict):
        annotations = {}
    changed = False
    for entry in entries:
        alias = str(entry.get('alias') or '').strip()
        key = str(entry.get('key') or '').strip()
        prop_name = str(entry.get('property_name') or '').strip()
        if not alias or not key or not prop_name or prop_name in annotations:
            continue
        label_en = str(entry.get('label_en') or key)
        desc_en = str(entry.get('description_en') or label_en)
        tooltip_en = (
            f'Function: {desc_en} '
            'How to use: enable this only when you need the feature to stay active continuously. '
            'Keep it disabled for manual N-panel operation and lighter startup.'
        )
        annotations[prop_name] = BoolProperty(
            name=label_en,
            description=tooltip_en,
            default=bool(entry.get('default', False)),
            update=_sas_background_option_update_factory(alias, key, prop_name),
        )
        changed = True
    if changed:
        try:
            SAS_Settings.__annotations__ = annotations
        except Exception:
            pass


def sync_always_on_properties_from_loader(settings=None, *, context=None) -> None:
    """Mirror loader background state into the visible N-panel BoolProperties.

    The loader JSON is the source of truth for already-saved background state;
    this function only makes the displayed BoolProperty match it so Blender's
    native toggle drawing remains stable and blue when enabled.
    """
    global _SAS_ALWAYS_ON_SYNCING
    if settings is None:
        try:
            scene = getattr(context, 'scene', None) if context is not None else getattr(bpy.context, 'scene', None)
            settings = getattr(scene, 'sas_settings', None)
        except Exception:
            settings = None
    if settings is None:
        return
    try:
        from . import loader
        entries = list(loader.all_background_option_entries() or [])
    except Exception:
        return
    _SAS_ALWAYS_ON_SYNCING = True
    try:
        for entry in entries:
            prop_name = str(entry.get('property_name') or '').strip()
            if not prop_name or not hasattr(settings, prop_name):
                continue
            desired = bool(entry.get('enabled', False))
            try:
                if bool(getattr(settings, prop_name)) != desired:
                    setattr(settings, prop_name, desired)
            except Exception:
                pass
    finally:
        _SAS_ALWAYS_ON_SYNCING = False


def sync_always_on_properties_to_loader(settings=None, *, context=None, load_enabled: bool = False) -> None:
    """Synchronize visible always-on values to loader state in one finite batch.

    The previous implementation called ``set_background_option`` for every
    option, even when unchanged; each call could atomically rewrite the config.
    This version compares cached values and performs at most one persistence
    commit for the whole payload transaction.
    """
    if settings is None:
        try:
            scene = getattr(context, 'scene', None) if context is not None else getattr(bpy.context, 'scene', None)
            settings = getattr(scene, 'sas_settings', None)
        except Exception:
            settings = None
    if settings is None:
        return
    try:
        from . import loader
        entries = list(loader.all_background_option_entries() or [])
    except Exception:
        return

    updates: list[tuple[str, str, bool]] = []
    any_enabled = False
    for entry in entries:
        alias = str(entry.get('alias') or '').strip()
        key = str(entry.get('key') or '').strip()
        prop_name = str(entry.get('property_name') or '').strip()
        if not alias or not key or not prop_name or not hasattr(settings, prop_name):
            continue
        try:
            enabled = bool(getattr(settings, prop_name))
        except Exception:
            enabled = False
        any_enabled = any_enabled or enabled
        if enabled and load_enabled:
            try:
                loader.load_tool(alias)
            except Exception:
                pass
        updates.append((alias, key, enabled))

    try:
        batch = getattr(loader, 'set_background_options_batch', None)
        if callable(batch):
            batch(updates)
        else:
            for alias, key, enabled in updates:
                try:
                    if bool(loader.is_background_option_enabled(alias, key)) != enabled:
                        loader.set_background_option(alias, key, enabled)
                except Exception:
                    pass
    except Exception:
        pass
    if any_enabled and not load_enabled:
        _sas_schedule_enabled_background_tools()



_sas_install_static_section_properties()
_sas_install_always_on_properties()

_sas_install_update_callbacks(
    SAS_Settings,
    SAS_PoseSnapshot,
    SAS_BoneMapItem,
    SAS_LogItem,
    SAS_ActionLibraryItem,
    SAS_SelectionSetItem,
)


class SAS_UL_pose_snapshots(UIList):
    bl_idname = "SAS_UL_pose_snapshots"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.label(text=item.name, translate=False, icon='POSE_HLT')
        else:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='POSE_HLT')


class SAS_UL_bone_map(UIList):
    bl_idname = "SAS_UL_bone_map"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0):
        confidence_text = f"{int(item.confidence * 100)}%"
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.label(text=item.source_name, translate=False, icon='BONE_DATA')
            row.label(text="→")
            row.label(text=item.target_name if item.target_name else "-", translate=False, icon='BONE_DATA')
            row.label(text=confidence_text, icon='CHECKMARK' if item.target_name else 'ERROR')
        else:
            layout.alignment = 'CENTER'
            layout.label(text=confidence_text)


class SAS_UL_operation_log(UIList):
    bl_idname = "SAS_UL_operation_log"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0):
        icon_name = 'DOT'
        if item.level == "WARN":
            icon_name = 'ERROR'
        elif item.level == "ERROR":
            icon_name = 'CANCEL'
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.label(text=format_log_message(item, context), icon=icon_name)
        else:
            layout.alignment = 'CENTER'
            layout.label(text="", icon=icon_name)


class SAS_UL_selection_sets(UIList):
    bl_idname = "SAS_UL_selection_sets"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0):
        icon_name = 'ARMATURE_DATA' if item.selection_mode == 'POSE' else 'RESTRICT_SELECT_OFF'
        detail = item.object_name or '-'
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.label(text=item.name, translate=False, icon=icon_name)
            row.label(text=detail, translate=False, icon='OBJECT_DATA')
        else:
            layout.alignment = 'CENTER'
            layout.label(text="", icon=icon_name)


class SAS_UL_action_library(UIList):
    bl_idname = "SAS_UL_action_library"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0):
        action = bpy.data.actions.get(item.action_name)
        keys = count_keyframes(action) if action else 0
        icon_name = 'ACTION' if action else 'ERROR'
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.label(text=item.action_name, translate=False, icon=icon_name)
            row.label(text=item.source_object or '-', translate=False, icon='OBJECT_DATA')
            row.label(text=str(keys), icon='KEY_HLT')
        else:
            layout.alignment = 'CENTER'
            layout.label(text="", icon=icon_name)


# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------

CORE_CLASSES = (
    SAS_PoseSnapshot,
    SAS_BoneMapItem,
    SAS_LogItem,
    SAS_ActionLibraryItem,
    SAS_SelectionSetItem,
    SAS_Settings,
    SAS_UL_pose_snapshots,
    SAS_UL_bone_map,
    SAS_UL_operation_log,
    SAS_UL_selection_sets,
    SAS_UL_action_library,
)
