# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import ast
import unicodedata
from functools import lru_cache
from pathlib import Path
from typing import Iterable

import bpy
from bpy.props import StringProperty

from .translation import sas_text, sas_localize_text, sanitize_bilingual_text, sas_is_japanese
from . import registry
try:
    from .panel_header_guard import harden_class_callbacks
except Exception:
    def harden_class_callbacks(cls):
        return cls


_POPUP_WIDTH = 760
_MIN_WRAP_PIXELS = 140
_POPUP_TEXT_INSET = 74
_BOX_TEXT_INSET = 22
_NESTED_BOX_TEXT_INSET = 28
_ICON_TEXT_INSET = 28
_BREAK_AFTER = set(' 、。，．・,.;:!?！？)]}）】」』》〉>/-')
_NO_LINE_START = set('、。，．・,.;:!?！？)]}）】」』》〉>')
_TRANSLATION_DOMAIN = 'smart_animation_suite_lazy_help_popup'
_TRANSLATIONS_REGISTERED = False
_TRANSLATIONS = {
    'ja_JP': {
        ('*', 'Smart Animation Help'): 'Smart Animation ヘルプ',
        ('*', 'Display detailed Smart Animation help.'): 'Smart Animation の詳細ヘルプを表示します。',
    },
}


def _t(context, en_text: str, ja_text: str) -> str:
    return sanitize_bilingual_text(sas_text(str(en_text or ''), str(ja_text or ''), context), context)


def _lt(context, text: str) -> str:
    return sanitize_bilingual_text(sas_localize_text(str(text or ''), context), context)


def _item_text(context, item: dict, key: str) -> str:
    en = str(item.get(f'{key}_en') or item.get(key) or '').strip()
    explicit_ja = item.get(f'{key}_ja')
    if explicit_ja is not None:
        return _t(context, en, str(explicit_ja or en).strip())
    return _lt(context, en)


def _ui_scale(context) -> float:
    try:
        return float(getattr(getattr(getattr(context, 'preferences', None), 'system', None), 'ui_scale', 1.0) or 1.0)
    except Exception:
        return 1.0


def _ui_font_size(context) -> int:
    points = 11.0
    try:
        styles = getattr(getattr(context, 'preferences', None), 'ui_styles', None)
        style = styles[0] if styles else None
        for attr in ('widget_label', 'widget', 'panel_title'):
            value = getattr(getattr(style, attr, None), 'points', None)
            if value:
                points = float(value)
                break
    except Exception:
        points = 11.0
    return max(8, int(round(points * max(0.75, min(2.5, _ui_scale(context))))))


def _fallback_text_pixels(context, text: str) -> float:
    font_px = float(_ui_font_size(context))
    total = 0.0
    for ch in str(text or ''):
        if ch in {'\n', '\r'}:
            continue
        if ch == '\t':
            total += font_px * 0.65
        elif ch == ' ':
            total += font_px * 0.36
        elif unicodedata.east_asian_width(ch) in {'F', 'W'}:
            total += font_px * 1.02
        else:
            total += font_px * 0.58
    return total


def _text_pixels(context, text: str) -> float:
    value = str(text or '')
    if not value:
        return 0.0
    try:
        import blf  # Blender font drawing API. Available only inside Blender.
        font_id = 0
        font_size = _ui_font_size(context)
        try:
            blf.size(font_id, font_size)
        except TypeError:
            try:
                blf.size(font_id, font_size, 72)
            except Exception:
                pass
        dimensions = blf.dimensions(font_id, value)
        width = float(dimensions[0])
        if width > 0.0:
            return width
    except Exception:
        pass
    return _fallback_text_pixels(context, value)


def _popup_text_pixels(context, *, nested_level: int = 1, icon: bool = False, extra_inset: int = 0) -> int:
    try:
        popup_width = int(_POPUP_WIDTH)
    except Exception:
        popup_width = 760
    scale = max(1.0, min(2.5, _ui_scale(context)))
    inset = _POPUP_TEXT_INSET + (_BOX_TEXT_INSET * max(0, int(nested_level or 0))) + int(extra_inset or 0)
    if nested_level > 1:
        inset += _NESTED_BOX_TEXT_INSET * (int(nested_level) - 1)
    if icon:
        inset += _ICON_TEXT_INSET
    return max(_MIN_WRAP_PIXELS, int(round(popup_width - (inset * scale))))


def _fit_prefix_index(context, text: str, max_pixels: int) -> int:
    value = str(text or '')
    if not value:
        return 0
    if _text_pixels(context, value) <= max_pixels:
        return len(value)
    low = 1
    high = len(value)
    best = 1
    while low <= high:
        mid = (low + high) // 2
        if _text_pixels(context, value[:mid]) <= max_pixels:
            best = max(1, mid)
            low = mid + 1
        else:
            high = mid - 1
    return best


def _preferred_break_index(text: str, prefix_len: int) -> int:
    value = str(text or '')
    if prefix_len >= len(value):
        return len(value)
    prefix_len = max(1, min(prefix_len, len(value)))
    min_index = max(1, int(prefix_len * 0.45))
    for index in range(prefix_len - 1, min_index - 1, -1):
        if value[index].isspace():
            return index + 1
    for index in range(prefix_len - 1, min_index - 1, -1):
        if value[index] in _BREAK_AFTER:
            return index + 1
    return prefix_len


def _wrap_line_to_pixels(context, raw: str, max_pixels: int) -> list[str]:
    raw = str(raw or '').replace('\t', ' ').strip()
    if not raw:
        return ['']
    if _text_pixels(context, raw) <= max_pixels:
        return [raw]

    lines: list[str] = []
    remaining = raw
    guard = 0
    while remaining and guard < 1000:
        guard += 1
        if _text_pixels(context, remaining) <= max_pixels:
            lines.append(remaining.strip())
            break
        prefix_len = _fit_prefix_index(context, remaining, max_pixels)
        break_index = _preferred_break_index(remaining, prefix_len)
        while 1 < break_index < len(remaining) and remaining[break_index] in _NO_LINE_START:
            break_index -= 1
        left = remaining[:break_index].strip()
        right = remaining[break_index:].strip()
        if not left:
            left = remaining[:max(1, prefix_len)].strip()
            right = remaining[max(1, prefix_len):].strip()
        if left:
            lines.append(left)
        if right == remaining:
            right = remaining[max(1, prefix_len):].strip()
        remaining = right
    if guard >= 1000 and remaining:
        lines.append(remaining.strip())
    return lines or ['']


def _wrap(text: str, context, *, nested_level: int = 1, icon: bool = False, extra_inset: int = 0) -> list[str]:
    text = str(text or '').replace('\r', '').strip()
    if not text:
        return []
    first_budget = _popup_text_pixels(context, nested_level=nested_level, icon=icon, extra_inset=extra_inset)
    normal_budget = _popup_text_pixels(context, nested_level=nested_level, icon=False, extra_inset=extra_inset)
    lines: list[str] = []
    first_visible_line = True
    for raw in text.split('\n'):
        raw = raw.strip()
        if not raw:
            lines.append('')
            continue
        budget = first_budget if first_visible_line else normal_budget
        wrapped = _wrap_line_to_pixels(context, raw, budget)
        lines.extend(wrapped)
        first_visible_line = False
    return lines


def _draw_wrapped(layout, context, text: str, *, icon: str = 'NONE', nested_level: int = 1, extra_inset: int = 0) -> None:
    first = True
    for line in _wrap(text, context, nested_level=nested_level, icon=(icon != 'NONE'), extra_inset=extra_inset):
        if line:
            layout.label(text=line, icon=icon if first else 'NONE')
        else:
            layout.separator(factor=0.3)
        first = False

def _draw_heading(layout, context, en: str, ja: str, icon: str) -> None:
    row = layout.row(align=True)
    row.label(text=_t(context, en, ja), icon=icon)


def _draw_setting_items(layout, context, items: Iterable[dict]) -> None:
    col = layout.column(align=True)
    rendered = False
    for item in items or ():
        name = _item_text(context, item, 'name')
        desc = _item_text(context, item, 'description')
        if not name and not desc:
            continue
        rendered = True
        box = col.box()
        if name:
            _draw_wrapped(box, context, name, icon='DOT', nested_level=2)
        if desc:
            _draw_wrapped(box, context, desc, nested_level=2)
        enum_items = item.get('enum_items') or ()
        if enum_items:
            sub = box.column(align=True)
            for enum_name, enum_desc in enum_items:
                enum_label = _lt(context, enum_name)
                enum_text = _lt(context, enum_desc) if enum_desc else ''
                if enum_text:
                    _draw_wrapped(sub, context, f'• {enum_label}: {enum_text}', nested_level=2, extra_inset=14)
                else:
                    _draw_wrapped(sub, context, f'• {enum_label}', nested_level=2, extra_inset=14)
    if not rendered:
        _draw_wrapped(layout, context, _t(context, 'No editable setting is required for this item.', 'この項目で必須の編集設定はありません。'), icon='NONE', nested_level=1)


def _rna_setting_items(context, prop_names: Iterable[str], *, include_enum_items: bool = True) -> list[dict]:
    items: list[dict] = []
    settings = getattr(getattr(context, 'scene', None), 'sas_settings', None)
    rna = getattr(settings, 'bl_rna', None)
    properties = getattr(rna, 'properties', None)
    if properties is None:
        return items
    for prop_name in prop_names:
        try:
            prop = properties[str(prop_name)]
        except Exception:
            continue
        name = str(getattr(prop, 'name', '') or prop_name)
        desc = str(getattr(prop, 'description', '') or '')
        enum_rows = []
        if include_enum_items:
            try:
                if str(getattr(prop, 'type', '') or '') == 'ENUM':
                    for enum_item in getattr(prop, 'enum_items', ()):
                        enum_rows.append((str(getattr(enum_item, 'name', '') or getattr(enum_item, 'identifier', '') or ''), str(getattr(enum_item, 'description', '') or '')))
            except Exception:
                enum_rows = []
        items.append({'name': name, 'description': desc, 'enum_items': enum_rows})
    return items


def _always_on_items(context) -> list[dict]:
    rows: list[dict] = [
        {
            'name_en': 'Group Foldout',
            'name_ja': 'グループ展開',
            'description_en': 'Opens or closes the centralized always-on switch list. This is only a UI foldout and does not start background processing by itself.',
            'description_ja': '常時機能切り替えリストを開閉します。これはUIの折りたたみだけで、単独ではバックグラウンド処理を起動しません。',
        }
    ]
    try:
        from . import loader
        for alias in registry.TOOL_ALIASES:
            tool_name = str((registry.TOOL_META.get(alias) or {}).get('display_name') or alias)
            for entry in loader.tool_background_entries(alias):
                label_en = str(entry.get('label_en') or entry.get('key') or '')
                label_ja = str(entry.get('label_ja') or entry.get('label_en') or entry.get('key') or '')
                desc_en = str(entry.get('description_en') or '')
                desc_ja = str(entry.get('description_ja') or entry.get('description_en') or '')
                rows.append({
                    'name_en': f'{tool_name}: {label_en}',
                    'name_ja': f'{tool_name}: {label_ja}',
                    'description_en': desc_en,
                    'description_ja': desc_ja,
                })
    except Exception:
        pass
    # Only declared optional always-on features are documented here.  Runtime
    # callback captures are kept internal so the visible UI remains a stable
    # BoolProperty-based switch list with reliable active-state drawing.
    seen = set()
    unique = []
    for row in rows:
        marker = (row.get('name'), row.get('description'))
        if marker in seen:
            continue
        seen.add(marker)
        unique.append(row)
    return unique


NATIVE_TOPICS: dict[str, dict] = {
    'always_on': {
        'title_en': 'Always-on Toggles',
        'title_ja': '常時機能切り替え',
        'overview_en': 'Centralized switches for N-panel state saving and only the optional background features that genuinely need persistent callbacks or draw handlers to work continuously. Header buttons, menu injections, ordinary hotkeys, and one-shot tools are intentionally kept out of this section and remain available from normal N-panel commands.',
        'overview_ja': 'Nパネル状態保存と、継続動作に本当に常駐コールバックまたは描画ハンドラーが必要な任意機能だけを集約した切り替え欄です。ヘッダーボタン、メニュー追加、通常ホットキー、単発実行ツールはこの欄から外し、通常のNパネルコマンドとして使用します。',
        "usage_en": "Open the group only when needed. The first row controls whether N-panel settings are saved immediately. The remaining rows show only features that still require continuous background behavior; the right side is the saved Enabled/Disabled BoolProperty toggle.",
        'usage_ja': '必要な時だけグループを開きます。先頭行でNパネル設定を即時保存するかを切り替えます。以降の行には継続したバックグラウンド動作が必要な機能だけを表示し、右側に保存対象の有効 / 無効 BoolProperty トグルを配置しています。',
        'settings_source': 'always_on',
        'props': ['show_always_on_toggle_group'],
    },
    'overview_task_dropdown': {
        'title_en': 'Overview Task Dropdown',
        'title_ja': '概要タスク ドロップダウン',
        'overview_en': 'Main display switch for the Smart Animation N-panel. It selects whether all functions, built-in sections, or migrated bundled tool groups are shown.',
        'overview_ja': 'Smart Animation のNパネル表示を切り替える主設定です。全機能、内蔵セクション、移植済み同梱ツールグループのどれを表示するかを選びます。',
        'usage_en': 'Choose All Functions to show everything, or select a specific category to keep the N-panel focused on one workflow.',
        'usage_ja': '全体を見たい場合は「全機能」を選び、特定作業に集中したい場合は該当カテゴリを選んでください。',
        'props': ['compact_diag_mode', 'ui_search'],
    },
    'camera_shakify_utilities': {
        'title_en': 'Camera Shakify Utilities',
        'title_ja': 'Camera Shakify ユーティリティ',
        'overview_en': 'Repair the drivers for all camera shakes, or prepare the file for rendering on a render farm.',
        'overview_ja': 'すべてのカメラ揺れのドライバーを修復したり、レンダーファーム用にファイルを準備したりします。',
        'usage_en': 'Run Fix Camera Shakes to repair existing shakes after loading a file. Use the render-farm preparation command before sending the file to render nodes.',
        'usage_ja': 'ファイルの読み込み後に既存の揺れを修復するには、カメラ揺れの修復を実行します。レンダーノードにファイルを送る前には、レンダーファーム用の準備を実行します。',
    },
    'section_overview': {
        'title_en': 'Overview / Diagnostics',
        'title_ja': '概要 / 診断',
        'overview_en': 'Scene status, action slot access, diagnostic recommendations, quick maintenance actions, and the operation log.',
        'overview_ja': 'シーン状態、アクションスロット、診断おすすめ操作、保守用クイック操作、操作ログをまとめた確認用セクションです。',
        'usage_en': 'Use this section before editing or export to check whether the current scene has missing actions, invalid ranges, retarget issues, or other setup problems.',
        'usage_ja': '編集や書き出し前に、アクション欠落、不正な範囲、リターゲット問題などのセットアップ不備がないか確認するために使います。',
        'props': ['auto_backup_action', 'preview_only', 'show_safety_hints', 'log_limit'],
    },
    'section_animation_recipes': {
        'title_en': 'Animation Recipes',
        'title_ja': 'Animation Recipes',
        'overview_en': 'A new upgraded recipe hub that converts the researched animation-assistance functions into Blender-native Smart Animation workflows. It groups animBot-style curve editing, Cascadeur-style physics assistance, MotionBuilder-style motion mixing, Cinema 4D-style procedural motion, shape-control mixing, image-sequence timing, retargeting, feature coverage reporting, and the large borderless custom-icon dashboard.',
        'overview_ja': '調査リストのアニメーション補助機能を Blender 内で扱える Smart Animation ワークフローへ変換した、新しい上位互換レシピハブです。animBot 風カーブ編集、Cascadeur 風物理補助、MotionBuilder 風モーションミックス、Cinema 4D 風プロシージャルモーション、シェイプ制御、画像シーケンス同期、リターゲット、対応表作成、大型の枠無し独自アイコンダッシュボードをまとめています。',
        'usage_en': 'Select a recipe, adjust the visible settings for that group, then run the recipe or the dedicated operator button. The output is ordinary Blender data such as keyframes, NLA strips, drivers, Text datablocks, or helper objects so it remains editable without external plug-ins.',
        'usage_ja': 'レシピを選び、該当グループの表示設定を調整してから、レシピまたは専用ボタンを実行します。出力は通常の Blender データ、つまりキーフレーム、NLA ストリップ、ドライバー、テキストデータブロック、補助オブジェクトなので、外部プラグインなしで編集を続けられます。',
        'props': ['smart_recipe', 'smart_workflow_stage', 'smart_ui_density', 'smart_show_advanced_controls', 'smart_preflight_before_run', 'smart_quality_gate_min_score', 'smart_precision_profile', 'smart_enable_adaptive_precision', 'smart_precision_curvature_guard', 'smart_preserve_selected_keys', 'smart_preserve_extreme_keys', 'smart_overshoot_tolerance', 'smart_icon_button_scale', 'smart_show_icon_labels', 'smart_quality_report_text_name', 'smart_quality_sample_step', 'smart_timing_intent', 'smart_contact_floor_epsilon', 'smart_super_visual_review', 'smart_report_text_name'],
    },
    'smart_studio_dashboard': {
        'title_en': 'Animation Recipes Studio Dashboard',
        'title_ja': 'アニメーション レシピ スタジオダッシュボード',
        'overview_en': 'The refined production control surface for Animation Recipes. It places large borderless icon buttons, stage selection, recipe execution, quality gates, precision settings, visual review, and advanced-control visibility in one compact studio panel.',
        'overview_ja': 'アニメーション レシピ の制作向け統合操作面です。大型の枠無し独自アイコンボタン、段階選択、レシピ実行、品質ゲート、精度設定、可視レビュー、詳細操作表示を1つのコンパクトなスタジオパネルにまとめています。',
        'usage_en': 'Use the large icon buttons for the fastest workflow. Icon Size controls how strongly the generated symbol fills the button area, and Icon Labels can be hidden for an icon-first dashboard. Choose Auto Stage or a specific stage, then let Superior Director combine contact, timing, precision, quality, and visual review passes.',
        'usage_ja': '最短操作では大型アイコンボタンを使います。アイコンサイズで生成済み図形をボタン領域へどれだけ大きく表示するか調整でき、アイコンラベルを非表示にするとアイコン中心の表示になります。Auto Stage または任意の段階を選び、Superior Director で接地、タイミング、精密化、品質診断、可視レビューをまとめて実行します。',
        'props': ['smart_workflow_stage', 'smart_ui_density', 'smart_show_advanced_controls', 'smart_icon_button_scale', 'smart_show_icon_labels', 'smart_preflight_before_run', 'smart_quality_gate_min_score', 'smart_recipe', 'smart_precision_profile', 'smart_enable_adaptive_precision', 'smart_precision_curvature_guard', 'smart_preserve_selected_keys', 'smart_preserve_extreme_keys', 'smart_overshoot_tolerance', 'smart_timing_intent', 'smart_contact_floor_epsilon', 'smart_super_visual_review'],
    },
    'smart_motion_director': {
        'title_en': 'Motion Director',
        'title_ja': 'モーションディレクター',
        'overview_en': 'animBot, Tweeener, AnimAide, and AI-inbetweening style pose refinement. It creates current-frame in-betweens, push/pull exaggeration, and neighbor-based curve scaling from existing keys.',
        'overview_ja': 'animBot、Tweeener、AnimAide、AIインビトウィーンに近いポーズ調整です。既存キーから現在フレームの中割り、プッシュ / プル誇張、近隣キー基準のカーブスケールを作成します。',
        'usage_en': 'Place the playhead between keyed poses, choose the director mode, set Tween, Push/Pull, and Neighbor Scale values, then run Motion Director. Values outside the normal tween range can create anticipation or overshoot.',
        'usage_ja': 'キー済みポーズの間へ再生ヘッドを置き、ディレクターモード、トゥイーン、プッシュ / プル、近隣スケールを設定して実行します。通常のトゥイーン範囲外の値を使うと、予備動作やオーバーシュートを作れます。',
        'props': ['smart_motion_director_mode', 'tween_factor', 'tween_mode', 'push_pull_factor', 'neighbor_scale_factor', 'smart_motion_preserve_flow'],
    },
    'smart_graph_optimizer': {
        'title_en': 'Graph Optimizer',
        'title_ja': 'グラフ最適化',
        'overview_en': 'A GraphKit, Key Manager, MotionBuilder F-Curve, and Cascadeur unbake inspired cleanup stack. It combines Euler filtering, duplicate/static cleanup, smoothing, selected-key protection, extreme protection, auto-clamped handles, overshoot risk review, and optional sparse-key unbaking.',
        'overview_ja': 'GraphKit、Key Manager、MotionBuilder Fカーブ、Cascadeurアンベイクを参考にした整理スタックです。オイラー補正、重複 / 静的チャンネル整理、平滑化、選択キー保護、極値保護、自動クランプハンドル、オーバーシュートリスク確認、任意の疎キー化を組み合わせます。',
        'usage_en': 'Use on the active action after mocap import, retargeting, dense baking, or aggressive edits. Enable Preview Only before destructive cleanup checks when you want a non-destructive estimate.',
        'usage_ja': 'モーキャプ読み込み、リターゲット、高密度ベイク、大きな編集の後に、アクティブアクションへ使用します。破壊的整理の前に結果を見積もりたい場合は「プレビューのみ」を有効にしてください。',
        'props': ['smart_graph_include_unbake', 'smart_graph_auto_clamped', 'smart_precision_profile', 'smart_enable_adaptive_precision', 'smart_precision_curvature_guard', 'smart_preserve_selected_keys', 'smart_preserve_extreme_keys', 'smart_overshoot_tolerance', 'remove_threshold', 'curve_smooth_factor', 'unbake_tolerance'],
    },
    'smart_visualizer': {
        'title_en': 'Motion Visualizer',
        'title_ja': 'モーション可視化',
        'overview_en': 'Motion trail, ghost, motion-path, and ballistic trajectory review in one place. It helps inspect arcs, silhouette spacing, and jump or throw trajectories before changing curves.',
        'overview_ja': 'モーショントレイル、ゴースト、モーションパス、弾道軌道確認を一箇所にまとめた機能です。カーブ編集前に、アーク、シルエット間隔、ジャンプや投げの軌道を確認できます。',
        'usage_en': 'Select an animated object or pose target, choose the visualizer mode, set ghost sample counts and step, then create visual helpers. Clear old helper objects from the existing visualizer tools when they are no longer needed.',
        'usage_ja': 'アニメーション済みオブジェクトまたはポーズ対象を選択し、可視化モード、ゴースト数、間隔を設定してヘルパーを作成します。不要になった補助オブジェクトは既存の可視化ツールから削除してください。',
        'props': ['smart_visualizer_mode', 'ghost_past_frames', 'ghost_future_frames', 'ghost_step', 'ballistic_step'],
    },
    'smart_physics_director': {
        'title_en': 'Physics Director',
        'title_ja': '物理ディレクター',
        'overview_en': 'BroDynamics, BoneDynamics, Cascadeur AutoPhysics, fulcrum cleanup, and rigid-body bake equivalents. The result is editable Blender keys or helper curves rather than a dependency on an external simulation plug-in.',
        'overview_ja': 'BroDynamics、BoneDynamics、Cascadeur AutoPhysics、接地点整理、剛体ベイクに相当する機能です。結果は外部シミュレーションプラグイン依存ではなく、編集可能な Blender キーまたは補助カーブになります。',
        'usage_en': 'Choose the physics mode that matches the shot: Ballistic for jumps and throws, Fulcrum for planted contacts, Spring for tails or accessories, and Rigid Body for simulated props that need to become keyframes.',
        'usage_ja': 'ショットに合わせて物理モードを選びます。ジャンプや投げは弾道、接地は支点、しっぽや小物はスプリング、シミュレーション済み小物をキー化する場合は剛体を使います。',
        'props': ['smart_physics_director_mode', 'ballistic_blend', 'spring_blend', 'contact_hold_start', 'contact_hold_end', 'physics_bake_clear_range'],
    },
    'smart_contact_timing': {
        'title_en': 'Contact / Timing Stabilizer',
        'title_ja': '接地 / タイミング安定化',
        'overview_en': 'A studio precision layer for planted contacts and interpolation intent. It detects stable low vertical keys, flattens contact height and handles, and applies the chosen curve timing feel to editable F-curves.',
        'overview_ja': '接地と補間意図を扱うスタジオ精度レイヤーです。低い位置で安定したキーを接地候補として検出し、接地高さとハンドルを平坦化し、選択した動きの意図に応じた補間を編集可能Fカーブへ適用します。',
        'usage_en': 'Use after blocking, retargeting, locomotion generation, or physics passes. Raise Contact Floor Epsilon when true contacts are not detected; lower it when lift-off poses are being flattened too aggressively.',
        'usage_ja': 'ブロッキング、リターゲット、ロコモーション生成、物理処理の後に使います。接地が検出されない場合は接地εを上げ、離陸ポーズまで平坦化される場合は下げてください。',
        'props': ['smart_timing_intent', 'smart_contact_floor_epsilon', 'smart_contact_min_span', 'smart_contact_flatten_handles', 'smart_super_visual_review'],
    },
    'smart_locomotion': {
        'title_en': 'Locomotion Generator',
        'title_ja': 'ロコモーション生成',
        'overview_en': 'A MotionMaker and CMotion inspired generator for editable cyclic movement. It writes ordinary location and optional yaw keys over the selected bake range and can add cycle modifiers for repeatable motion.',
        'overview_ja': 'MotionMaker と CMotion を参考にした、編集可能なサイクル移動生成機能です。選択したベイク範囲へ通常の位置キーと任意のヨーキーを書き込み、繰り返し用のサイクルモディファイアも追加できます。',
        'usage_en': 'Select one or more objects, choose the bake range, axis, distance, cycle length, bob amount, and yaw amount, then generate locomotion. Use the generated result as a blocking pass and refine the curves manually afterward.',
        'usage_ja': '1つ以上のオブジェクトを選び、ベイク範囲、軸、距離、周期、上下量、ヨー量を設定して生成します。生成結果はブロッキングとして使い、後から手動でカーブを調整してください。',
        'props': ['bake_range', 'custom_frame_start', 'custom_frame_end', 'smart_locomotion_axis', 'smart_locomotion_distance', 'smart_locomotion_cycle_length', 'smart_locomotion_sample_density', 'smart_locomotion_contact_lock', 'smart_locomotion_style', 'smart_locomotion_bob', 'smart_locomotion_yaw_degrees', 'smart_locomotion_stride_width', 'smart_locomotion_add_cycles'],
    },
    'smart_shape_control': {
        'title_en': 'Shape Control Mixer',
        'title_ja': 'シェイプ制御ミキサー',
        'overview_en': 'Pose Morph, OverMorpher, Dorito, and ShapeKeyPro style control creation for Blender shape keys. It creates custom properties on the active object and drives non-Basis shape key values from those properties.',
        'overview_ja': 'Pose Morph、OverMorpher、Dorito、ShapeKeyPro に近い Blender シェイプキー制御作成機能です。アクティブオブジェクトにカスタムプロパティを作成し、それらで Basis 以外のシェイプキー値を駆動します。',
        'usage_en': 'Select an object with shape keys, set the property prefix, then create controls. Animate the generated custom properties like normal controls. Use Clear Controls to remove the generated drivers while keeping the shape keys.',
        'usage_ja': 'シェイプキーを持つオブジェクトを選び、プロパティ接頭辞を設定して制御を作成します。生成されたカスタムプロパティを通常のコントロールのようにアニメートしてください。制御解除でシェイプキーを残したままドライバーを削除できます。',
        'props': ['smart_shape_control_prefix', 'smart_shape_control_key_controls'],
    },
    'smart_ifl': {
        'title_en': 'Image Sequence Manager',
        'title_ja': '画像シーケンス管理',
        'overview_en': 'A Blender-native equivalent of 3ds Max IFL Playback Manager for image texture sequence timing. It updates image-user start, duration, offset, cyclic playback, and optional keying.',
        'overview_ja': '3ds Max の IFL Playback Manager に相当する、Blender 内の画像テクスチャシーケンス用タイミング管理です。画像ユーザーの開始、長さ、オフセット、循環再生、任意のキー挿入を更新します。',
        'usage_en': 'Select objects with image texture nodes, set the start, duration, offset, and cyclic option, then apply image timing. Enable Key Offset when the texture playback must be animated over time.',
        'usage_ja': '画像テクスチャノードを持つオブジェクトを選択し、開始、長さ、オフセット、循環を設定して適用します。テクスチャ再生自体を時間変化させたい場合は「オフセットキー」を有効にします。',
        'props': ['smart_ifl_frame_start', 'smart_ifl_frame_duration', 'smart_ifl_match_scene_range', 'smart_ifl_frame_offset', 'smart_ifl_use_cyclic', 'smart_ifl_key_offset'],
    },
    'smart_quality': {
        'title_en': 'Smart Quality / Precision Polish',
        'title_ja': 'スマート品質診断 / 精密ポリッシュ',
        'overview_en': 'A production-check layer that raises the reliability of every Animation Recipe. It detects duplicate keys, static channels, dense baked curves, Euler discontinuities, Bezier overshoot, handle risks, contact drift, and spacing risks, then optionally runs an adaptive polish pass that keeps endpoints, selected keys, and extremes while removing visually redundant keys.',
        'overview_ja': 'アニメーション レシピ の各レシピの信頼性を高める制作チェック層です。重複キー、静的チャンネル、高密度ベイクカーブ、オイラー不連続、ベジェのオーバーシュート、ハンドルリスク、接地横滑り、スペーシングリスクを検出し、必要に応じて端点、選択キー、極値を保ちながら視覚的に不要なキーを削減する適応ポリッシュを実行します。',
        'usage_en': 'Use Quality Report first when you want a non-destructive audit. Use Preview Only with Precision Polish to estimate changes, then disable Preview Only to apply cleanup after confirming the report.',
        'usage_ja': '非破壊で確認したい場合は、まず品質診断を使います。精密ポリッシュは「プレビューのみ」で変更量を見積もり、レポート確認後にプレビューのみを解除して適用します。',
        'props': ['preview_only', 'smart_precision_profile', 'smart_enable_adaptive_precision', 'smart_precision_curvature_guard', 'smart_preserve_selected_keys', 'smart_preserve_extreme_keys', 'smart_overshoot_tolerance', 'smart_quality_gate_min_score', 'smart_quality_report_text_name', 'smart_quality_sample_step', 'smart_contact_floor_epsilon', 'smart_contact_min_span', 'smart_contact_flatten_handles', 'smart_timing_intent'],
    },
    'smart_retarget': {
        'title_en': 'Retarget Director',
        'title_ja': 'リターゲットディレクター',
        'overview_en': 'Red9, Houdini KineFX, and MotionBuilder retargeting equivalents using Smart Animation bone maps and live retarget constraints. It prepares a non-destructive preview before baking.',
        'overview_ja': 'Red9、Houdini KineFX、MotionBuilder リターゲットに相当する、Smart Animation のボーン対応表とライブリターゲット拘束を使う機能です。ベイク前に非破壊プレビューを準備します。',
        'usage_en': 'Set source and target armatures, choose matching and constraint options, then build the preview. Inspect the target rig before baking, then use Bake Retarget when the result is acceptable.',
        'usage_ja': 'ソースとターゲットのアーマチュアを設定し、名前対応と拘束設定を選んでプレビューを作成します。ターゲットリグを確認し、結果が問題なければリターゲットベイクを実行します。',
        'props': ['retarget_source', 'retarget_target', 'strip_namespaces', 'use_side_aliases', 'retarget_constraint_influence', 'retarget_space', 'clear_constraints_after_bake'],
    },
    'section_animation': {
        'title_en': 'Animation Tools',
        'title_ja': 'アニメーションツール',
        'overview_en': 'Built-in timeline, timing, secondary-motion, bake, FX, cleanup, and curve-maintenance tools.',
        'overview_ja': 'タイムライン、タイミング、セカンダリモーション、ベイク、演出、整理、カーブ保守を行う内蔵ツール群です。',
        'usage_en': 'Choose the task in each hub, adjust the visible settings, then run the hub command. Use Preview Only for destructive cleanup checks.',
        'usage_ja': '各ハブでタスクを選び、表示された設定を調整してから実行します。破壊的な整理を確認したい場合は「プレビューのみ」を使います。',
        'props': ['compact_timeline_mode', 'compact_timing_mode', 'compact_fx_mode', 'compact_cleanup_mode', 'bake_range', 'custom_frame_start', 'custom_frame_end', 'frame_step', 'preview_only'],
    },
    'section_assets': {
        'title_en': 'Asset Tools',
        'title_ja': 'アセットツール',
        'overview_en': 'Reusable selection sets, pose snapshots, action management, motion library operations, and text-based data import/export.',
        'overview_ja': '再利用できる選択セット、ポーズスナップショット、アクション管理、モーションライブラリ、テキスト経由の入出力を扱うツール群です。',
        'usage_en': 'Store frequently used poses, selections, and actions, then apply or export them when moving between shots and scenes.',
        'usage_ja': 'よく使うポーズ、選択状態、アクションを保存し、ショットやシーン間で必要に応じて適用・書き出し・読み込みします。',
        'props': ['selection_set_name', 'selection_set_text_name', 'snapshot_name', 'snapshot_blend_factor', 'pose_snapshot_text_name', 'library_assign_mode', 'library_sequence_start', 'library_sequence_gap', 'library_sequence_clear_existing', 'compact_data_mode'],
    },
    'section_transfer': {
        'title_en': 'Transfer Tools',
        'title_ja': '転送ツール',
        'overview_en': 'Retarget preparation, source-to-target bone mapping, live preview constraints, baking, profile import/export, and root-motion helpers.',
        'overview_ja': 'リターゲット準備、ボーン対応、ライブプレビュー制約、ベイク、プロファイル入出力、ルートモーション補助を扱うツール群です。',
        'usage_en': 'Set source and target rigs, build or import a bone map, preview the transfer, then bake or clear the preview when needed.',
        'usage_ja': 'ソースリグとターゲットリグを指定し、ボーン対応を作成または読み込み、転送を確認してから必要に応じてベイクまたは解除します。',
        'props': ['retarget_source', 'retarget_target', 'strip_namespaces', 'use_side_aliases', 'retarget_constraint_influence', 'retarget_space', 'retarget_replace_existing', 'clear_constraints_after_bake', 'compact_transfer_mode', 'root_motion_bone', 'root_motion_axis_x', 'root_motion_axis_y', 'root_motion_axis_z', 'retarget_profile_name'],
    },
    'section_migrated': {
        'title_en': 'Migrated Bundled Tools',
        'title_ja': '移植済み同梱ツール',
        'overview_en': 'Bundled external animation tools integrated into the Smart Animation Overview Task system. They stay lightweight until explicitly loaded.',
        'overview_ja': 'Smart Animation の概要タスクへ統合された外部同梱アニメーションツール群です。明示的に読み込むまで軽量表示のまま維持されます。',
        'usage_en': 'Select a genre or All Functions, read the tool name, then press Load Tool only when you need its commands or settings in the N-panel.',
        'usage_ja': 'ジャンルまたは全機能を選び、必要なツールだけ「ツールを読み込む」でNパネル内にコマンドや設定を表示してください。',
        'settings': [
            {'name': 'Load Tool', 'description': 'Imports and registers the selected bundled tool on demand.'},
            {'name': 'Quick Access', 'description': 'Shows the most relevant migrated menus and operators after the tool is loaded.'},
            {'name': 'Commands', 'description': 'Lists migrated operators and menus that can be invoked from the N-panel.'},
            {'name': 'Runtime Properties', 'description': 'Shows editable Scene or Window Manager runtime properties registered by the loaded tool when they are safe to expose in the N-panel.'},
            {'name': 'N-panel Persistence', 'description': 'Runtime settings changed from the N-panel are saved under Blender CONFIG/Smart_Animation_Suite and restored after Blender restarts or another scene is opened.'},
        ],
    },
    'overview_actions': {
        'title_en': 'Overview Actions',
        'title_ja': '概要アクション',
        'overview_en': 'One-click diagnostics, repair, report export, and log cleanup actions for the current scene.',
        'overview_ja': '現在のシーンに対する診断、修復、レポート書き出し、ログ消去をワンクリックで行う機能です。',
        'usage_en': 'Run Smart Assist to switch the Task to the one suited to the current scene, Auto Fix for safe basic repairs, Audit for diagnostics, Export Report for a text report, or Clear Log to remove panel log entries.',
        'usage_ja': '今の状況に合うタスクへ切り替える時はスマートアシスト、基本修復は自動修復、診断は監査、記録保存はレポート書き出し、ログ整理はログ消去を実行します。',
        'settings': [
            {'name': 'Auto Backup Action', 'description': 'Creates safety duplicates before destructive operations when applicable.'},
            {'name': 'Preview Only', 'description': 'Keeps compatible cleanup operations in report-only mode.'},
            {'name': 'Show Safety Hints', 'description': 'Displays risk warnings around destructive or retarget-related actions.'},
            {'name': 'Log Limit', 'description': 'Controls how many recent panel messages are kept.'},
        ],
    },
    'scene_snapshot': {
        'title_en': 'Scene Snapshot',
        'title_ja': 'シーン要約',
        'overview_en': 'Read-only summary of the active object, action, key count, marker count, NLA count, readiness, density, issues, bone mapping, and live-retarget state.',
        'overview_ja': 'アクティブオブジェクト、アクション、キー数、マーカー数、NLA数、準備度、密度、問題数、ボーン対応、ライブリターゲット状態を確認する読み取り専用の要約です。',
        'usage_en': 'Use it to confirm the current editing target and detect setup problems before running tools.',
        'usage_ja': 'ツール実行前に、現在の編集対象とセットアップ上の問題を確認するために使います。',
        'settings': [],
    },
    'action_slot': {
        'title_en': 'Current Action Slot',
        'title_ja': '現在のアクションスロット',
        'overview_en': 'Direct access to the action assigned to the active object animation data.',
        'overview_ja': 'アクティブオブジェクトのアニメーションデータに割り当てられているアクションへ直接アクセスする欄です。',
        'usage_en': 'Choose an existing action or create a new one before inserting keys, cleaning curves, or building NLA layers.',
        'usage_ja': 'キー挿入、カーブ整理、NLAレイヤー作成の前に、既存アクションを選ぶか新規作成してください。',
        'settings': [{'name': 'Action', 'description': 'The animation action edited by the selected object.'}],
    },
    'recommended_next_step': {
        'title_en': 'Recommended Next Step',
        'title_ja': 'おすすめの次操作',
        'overview_en': 'Context-based hints generated from the current scene state and diagnostic findings.',
        'overview_ja': '現在のシーン状態と診断結果から生成される状況別の次操作案内です。',
        'usage_en': 'Check this before running a task if you are unsure what setup step is missing.',
        'usage_ja': '不足している準備が分からない場合、タスク実行前にここを確認してください。',
        'settings': [],
    },
    'current_findings': {
        'title_en': 'Current Findings',
        'title_ja': '現在の検出結果',
        'overview_en': 'Detected scene issues such as missing animation data, invalid preview ranges, or retarget setup problems.',
        'overview_ja': 'アニメーションデータ欠落、不正なプレビュー範囲、リターゲット設定問題など、検出されたシーン上の問題を表示します。',
        'usage_en': 'Resolve blocking findings before destructive edits, retarget baking, or export.',
        'usage_ja': '破壊的編集、リターゲットベイク、書き出しの前に、停止要因となる検出結果を解消してください。',
        'settings': [{'name': 'Show Safety Hints', 'description': 'Controls whether these warnings are shown in the N-panel.'}],
    },
    'operation_log': {
        'title_en': 'Operation Log',
        'title_ja': '操作ログ',
        'overview_en': 'Recent Smart Animation operation messages, warnings, and errors.',
        'overview_ja': 'Smart Animation の最近の操作メッセージ、警告、エラーを表示するログです。',
        'usage_en': 'Use it to confirm what the last tool did. Clear it when you want a clean diagnostic view.',
        'usage_ja': '直前のツール処理内容を確認するために使います。診断表示を整理したい場合はクリアしてください。',
        'props': ['log_limit'],
    },
    'timeline_hub': {
        'title_en': 'Timeline Hub',
        'title_ja': 'タイムラインハブ',
        'overview_en': 'Key insertion, marker control, preview-range setup, playback presets, camera shot sequencing, camera review split, and shape-key keying.',
        'overview_ja': 'キー挿入、マーカー操作、プレビュー範囲設定、再生プリセット、カメラショット並べ、カメラレビュー分割、シェイプキー挿入を扱います。',
        'usage_en': 'Choose the timeline task, adjust the visible range or camera options when shown, then run the timeline task.',
        'usage_ja': 'タイムラインタスクを選び、表示された範囲やカメラ設定を調整してから実行します。',
        'props': ['compact_timeline_mode', 'marker_name', 'camera_sequence_start', 'camera_sequence_shot_length', 'camera_sequence_gap', 'camera_sequence_clear_existing', 'camera_sequence_set_preview', 'camera_review_split_direction', 'camera_review_split_factor', 'camera_review_lock_camera', 'bake_range', 'custom_frame_start', 'custom_frame_end', 'frame_step'],
    },
    'timing_hub': {
        'title_en': 'Timing Hub',
        'title_ja': 'タイミングハブ',
        'overview_en': 'Timing offset, scaling, even spacing, tweening, contact holds, stepped previews, overlap, cascades, randomization, and automatic fulcrum cleanup.',
        'overview_ja': 'タイミング移動、拡縮、均等化、トゥイーン、接地ホールド、ステッププレビュー、オーバーラップ、カスケード、ランダム化、自動支点整理を扱います。',
        'usage_en': 'Select the task, set the range and task-specific parameters, then apply it to selected keys or the active action range.',
        'usage_ja': 'タスクを選び、範囲と専用パラメータを設定してから、選択キーまたはアクティブアクション範囲へ適用します。',
        'props': ['compact_timing_mode', 'tween_mode', 'retime_use_range', 'retime_range_start', 'retime_range_end', 'retime_offset', 'retime_scale', 'retime_pivot_mode', 'retime_custom_pivot', 'tween_factor', 'push_pull_factor', 'neighbor_scale_factor', 'contact_hold_start', 'contact_hold_end', 'fulcrum_velocity_threshold', 'fulcrum_min_hold', 'fulcrum_only_location', 'step_preview_frames', 'step_preview_replace_existing', 'overlap_pass_frames', 'overlap_pass_blend', 'overlap_pass_decay', 'cascade_delay_frames', 'random_seed', 'random_timing_min', 'random_timing_max'],
    },
    'fx_hub': {
        'title_en': 'Bake / FX Hub',
        'title_ja': 'ベイク / FX ハブ',
        'overview_en': 'Limited animation baking, spring dynamics, physics baking, signal motion, motion stretch, vehicle helpers, reveal effects, trails, ghosts, ballistic guides, camera shake, loops, noise, paths, dynamic parenting, and global transform copy/paste.',
        'overview_ja': 'リミテッドアニメーションベイク、スプリング、物理ベイク、信号モーション、モーションストレッチ、車輪補助、リビール、軌跡、ゴースト、弾道ガイド、カメラ揺れ、ループ、ノイズ、パス、ダイナミック親子、グローバル変形コピーを扱います。',
        'usage_en': 'Choose an FX task, set the bake range and task-specific controls, then Apply. For generated helper effects, use Clear when available.',
        'usage_ja': '演出タスクを選び、ベイク範囲と専用設定を調整してから適用します。生成系補助は表示される場合に解除を使います。',
        'props': ['compact_fx_mode', 'bake_range', 'custom_frame_start', 'custom_frame_end', 'frame_step', 'physics_bake_clear_range', 'limited_bake_step', 'limited_interpolation', 'spring_stiffness', 'spring_damping', 'spring_blend', 'spring_sample_step', 'spring_auto_simplify', 'spring_magic_axis', 'spring_magic_mode', 'spring_magic_twist_strength', 'spring_magic_scale_strength', 'spring_magic_scale_max', 'spring_magic_clear_range', 'spring_magic_substeps', 'spring_magic_collision_iterations', 'spring_magic_collision_object_enabled', 'spring_magic_collision_object', 'spring_magic_collision_mode', 'spring_magic_collision_collection', 'spring_magic_collision_radius', 'spring_magic_collision_margin', 'spring_magic_floor_height', 'motion_stretch_axis', 'motion_stretch_plane', 'motion_stretch_strength', 'motion_stretch_squash', 'motion_stretch_max', 'motion_stretch_replace_existing', 'vehicle_wheel_axis', 'vehicle_motion_plane', 'vehicle_radius_mode', 'vehicle_wheel_radius', 'vehicle_spin_direction', 'vehicle_auto_side_flip', 'vehicle_enable_steering', 'vehicle_steering_axis', 'vehicle_steering_max', 'vehicle_steering_reverse', 'vehicle_replace_existing', 'transform_reveal_distance', 'transform_reveal_axis', 'transform_reveal_stagger', 'transform_reveal_duration', 'transform_reveal_order', 'deform_reveal_mode', 'deform_reveal_axis', 'deform_reveal_angle', 'deform_reveal_replace_existing', 'signal_mode', 'signal_target', 'signal_axes', 'signal_time_mode', 'signal_amplitude', 'signal_frequency', 'signal_bpm', 'signal_phase', 'signal_object_phase_offset', 'signal_step_frames', 'signal_noise_seed', 'signal_order', 'signal_replace_existing', 'noise_strength', 'noise_scale', 'noise_phase', 'noise_depth', 'trail_step', 'trail_resolution', 'trail_radius', 'trail_radius_mode', 'trail_speed_scale', 'trail_keep_previous', 'ballistic_step', 'ballistic_blend', 'ballistic_clear_range', 'ballistic_keep_previous', 'camera_shake_preset', 'ghost_past_frames', 'ghost_future_frames', 'ghost_step', 'ghost_keep_previous', 'loop_modifier_mode', 'loop_modifier_scope', 'loop_cycles_before', 'loop_cycles_after'],
    },
    'cleanup_hub': {
        'title_en': 'Cleanup Hub',
        'title_ja': '整理ハブ',
        'overview_en': 'Preview, simplify, smooth, duplicate removal, static-channel deletion, smart unbake, Euler filtering, tangent presets, shape-key cleanup, and generated helper cleanup.',
        'overview_ja': 'プレビュー、簡略化、スムーズ、重複削除、静的チャンネル削除、スマートアンベイク、オイラー補正、接線プリセット、シェイプキー整理、生成補助の解除を扱います。',
        'usage_en': 'Use Preview Cleanup or Preview Only before destructive operations. Adjust selection filters and thresholds, then run the cleanup task.',
        'usage_ja': '破壊的処理の前に整理プレビューまたはプレビューのみを使います。対象フィルターとしきい値を調整してから整理タスクを実行してください。',
        'props': ['compact_cleanup_mode', 'preview_only', 'auto_backup_action', 'only_selected_curves', 'skip_locked_curves', 'skip_muted_curves', 'skip_hidden_curves', 'simplify_factor', 'remove_threshold', 'curve_smooth_factor', 'curve_smooth_iterations', 'unbake_tolerance', 'unbake_preserve_extrema', 'tangent_mode'],
    },
    'selection_sets': {
        'features': [
            {'description_en': 'Quick buttons apply saved selection sets for faster control picking.', 'description_ja': 'クイックボタンから、保存した選択セットをすぐ適用できます。'},
        ],
        'title_en': 'Selection Sets',
        'title_ja': '選択セット',
        'overview_en': 'Stores reusable object or pose-bone selections for fast recall.',
        'overview_ja': 'オブジェクトまたはポーズボーンの選択状態を再利用できるセットとして保存します。',
        'usage_en': 'Enter a name, store the current selection, then apply it later to restore the same target set.',
        'usage_ja': '名前を入力して現在の選択状態を保存し、後で適用して同じ対象セットを復元します。',
        'props': ['selection_set_name', 'selection_set_text_name'],
    },
    'pose_snapshots': {
        'features': [
            {'description_en': 'Quick buttons apply saved pose snapshots, like a small pose palette.', 'description_ja': 'クイックボタンから、保存したポーズスナップショットをすぐ適用できます。'},
        ],
        'title_en': 'Pose Snapshots',
        'title_ja': 'ポーズスナップショット',
        'overview_en': 'Stores reusable pose snapshots, applies them, blends them, mirrors the current pose, or resets pose transforms.',
        'overview_ja': '再利用ポーズを保存・適用・ブレンドし、現在ポーズの反転やリセットも行います。',
        'usage_en': 'Select an armature or pose bones, store a snapshot, then apply or blend it later as a reusable pose source.',
        'usage_ja': 'アーマチュアまたはポーズボーンを選択し、スナップショットを保存して、後から再利用ポーズとして適用またはブレンドします。',
        'props': ['snapshot_name', 'snapshot_blend_factor', 'pose_snapshot_text_name'],
    },
    'action_nla': {
        'title_en': 'Action / NLA Workflow',
        'title_ja': 'アクション / NLA ワークフロー',
        'overview_en': 'Manages the active action, pushes actions to NLA, creates layer stacks, and adds animation layers.',
        'overview_ja': 'アクティブアクションの管理、NLAへのプッシュ、レイヤースタック作成、アニメーションレイヤー追加を行います。',
        'usage_en': 'Assign or create an action first, choose blend and layer naming options, then push or build layers as needed.',
        'usage_ja': '先にアクションを割り当てまたは作成し、ブレンド方式とレイヤー名を決めてからプッシュやレイヤー作成を行います。',
        'props': ['nla_blend_mode', 'layer_action_name'],
    },
    'motion_library': {
        'features': [
            {'description_en': 'Quick buttons assign saved motions or push them to NLA for faster shot assembly.', 'description_ja': 'クイックボタンから、保存したモーションを割り当てたり NLA へ積んだりできます。'},
        ],
        'title_en': 'Motion Library',
        'title_ja': 'モーションライブラリ',
        'overview_en': 'Stores, assigns, sequences, and prunes reusable actions in an in-panel motion library.',
        'overview_ja': 'パネル内モーションライブラリで再利用アクションの保存、割り当て、連番配置、整理を行います。',
        'usage_en': 'Add the current action to the library, assign it to the active object, push it to NLA, or sequence multiple library entries.',
        'usage_ja': '現在のアクションをライブラリへ追加し、アクティブオブジェクトへ割り当て、NLAへ追加、または複数項目を順番に配置します。',
        'props': ['library_assign_mode', 'library_sequence_start', 'library_sequence_gap', 'library_sequence_clear_existing'],
    },
    'library_sequence': {
        'title_en': 'Library Sequence',
        'title_ja': 'ライブラリシーケンス',
        'overview_en': 'Places motion-library actions sequentially as NLA clips.',
        'overview_ja': 'モーションライブラリ内のアクションをNLAクリップとして順番に配置します。',
        'usage_en': 'Set the start frame, gap, and cleanup option, then sequence the selected library actions to NLA.',
        'usage_ja': '開始フレーム、ギャップ、古いシーケンス整理を設定してから、ライブラリアクションをNLAへ並べます。',
        'props': ['library_sequence_start', 'library_sequence_gap', 'library_sequence_clear_existing'],
    },
    'data_io': {
        'title_en': 'Data I/O Hub',
        'title_ja': 'データ入出力ハブ',
        'overview_en': 'Exports and imports pose snapshots, selection sets, motion-library manifests, and retarget bone maps through Blender text data.',
        'overview_ja': 'ポーズスナップショット、選択セット、モーションライブラリマニフェスト、リターゲットボーン対応を Blender テキストデータ経由で書き出し・読み込みします。',
        'usage_en': 'Choose the data task, select the text datablock name, then run the data command.',
        'usage_ja': 'データタスクを選び、使用するテキストデータ名を指定してからデータ実行を押します。',
        'props': ['compact_data_mode', 'pose_snapshot_text_name', 'selection_set_text_name', 'library_manifest_text_name', 'retarget_profile_name'],
    },
    'transfer_hub': {
        'title_en': 'Transfer Hub',
        'title_ja': '転送ハブ',
        'overview_en': 'Main retarget and root-motion operation hub.',
        'overview_ja': 'リターゲットとルートモーション処理を行う中心ハブです。',
        'usage_en': 'Set source and target rigs, configure matching and constraint settings, select the transfer task, then run it.',
        'usage_ja': 'ソースリグとターゲットリグ、照合条件、制約設定を指定し、転送タスクを選んで実行します。',
        'props': ['retarget_source', 'retarget_target', 'strip_namespaces', 'use_side_aliases', 'retarget_constraint_influence', 'retarget_space', 'retarget_replace_existing', 'clear_constraints_after_bake', 'compact_transfer_mode', 'root_motion_bone', 'root_motion_axis_x', 'root_motion_axis_y', 'root_motion_axis_z'],
    },
    'retarget_profile': {
        'title_en': 'Retarget Profile',
        'title_ja': 'リターゲットプロファイル',
        'overview_en': 'Exports or imports the current bone map as JSON stored in a Blender text datablock.',
        'overview_ja': '現在のボーン対応を Blender テキストデータ内の JSON として書き出し・読み込みします。',
        'usage_en': 'Choose the profile text name, then export the current mapping or import an existing one.',
        'usage_ja': 'プロファイルテキスト名を選び、現在の対応を書き出すか既存の対応を読み込みます。',
        'props': ['retarget_profile_name'],
    },
    'mapping_preview': {
        'title_en': 'Mapping Preview',
        'title_ja': '対応プレビュー',
        'overview_en': 'Displays the current source-to-target bone matching state and confidence counts.',
        'overview_ja': '現在のソースからターゲットへのボーン対応状態と信頼度数を表示します。',
        'usage_en': 'Review unmatched or low-confidence rows before applying live retarget or baking.',
        'usage_ja': 'ライブリターゲットやベイク前に、未一致や低信頼の行を確認してください。',
        'props': ['retarget_source', 'retarget_target', 'strip_namespaces', 'use_side_aliases', 'bone_map', 'bone_map_index'],
    },
}


GROUP_HELP = {
    'Pose': {
        'title_en': 'Pose Tools',
        'title_ja': 'ポーズツール',
        'overview_en': 'Migrated pose offset and pose-library tools for pose reuse, pose editing, and pose management.',
        'overview_ja': 'ポーズの再利用、編集、管理に使う移植済みポーズオフセット・ポーズライブラリ系ツールです。',
        'usage_en': 'Load only the pose tool you need, then use its migrated commands or settings from the N-panel.',
        'usage_ja': '必要なポーズ系ツールだけを読み込み、Nパネル内の移植済みコマンドや設定から操作してください。',
    },
    'Key Data': {
        'title_en': 'Key Data Tools',
        'title_ja': 'キーデータツール',
        'overview_en': 'Migrated tools for keying nonstandard mesh, curve, UV, attribute, and element data.',
        'overview_ja': 'メッシュ、カーブ、UV、属性、要素データなど通常以外のデータへキーを打つ移植済みツールです。',
        'usage_en': 'Select editable geometry or supported data, load the tool, then choose which data channels should be keyed.',
        'usage_ja': '編集対象のジオメトリや対応データを選択し、ツールを読み込んでキー対象チャンネルを選びます。',
    },
    'Transform': {
        'title_en': 'Transform Tools',
        'title_ja': '変形ツール',
        'overview_en': 'Migrated tools for offsetting animated transforms and adjusting motion in transform space.',
        'overview_ja': 'アニメーション済み変形のオフセットや、変形空間でのモーション調整を行う移植済みツールです。',
        'usage_en': 'Load the transform tool, select the animated object or controls, then apply offsets with the tool-specific command.',
        'usage_ja': '変形ツールを読み込み、アニメーション済みオブジェクトまたはコントロールを選択して専用コマンドでオフセットを適用します。',
    },
    'Timing': {
        'title_en': 'Timing Tools',
        'title_ja': 'タイミングツール',
        'overview_en': 'Migrated easing, timing, and stop-motion style tools.',
        'overview_ja': 'イージング、タイミング、ストップモーション風処理を行う移植済みツールです。',
        'usage_en': 'Select keyframes or animated objects, load the relevant tool, then apply the timing or easing operation.',
        'usage_ja': 'キーフレームまたはアニメーション済みオブジェクトを選択し、該当ツールを読み込んでタイミングやイージング処理を適用します。',
    },
    'Curve': {
        'title_en': 'Curve Tools',
        'title_ja': 'カーブツール',
        'overview_en': 'Migrated Bezier editing and curve simplification tools.',
        'overview_ja': 'ベジェ編集とカーブ簡略化を扱う移植済みツールです。',
        'usage_en': 'Load the curve tool, select F-Curves or curve splines, then adjust easing or simplification settings.',
        'usage_ja': 'カーブツールを読み込み、Fカーブまたはカーブスプラインを選択して、イージングや簡略化設定を調整します。',
    },
    'Camera': {
        'title_en': 'Camera Tools',
        'title_ja': 'カメラツール',
        'overview_en': 'Migrated camera-shake and camera-motion support tools.',
        'overview_ja': 'カメラ揺れやカメラモーション補助を行う移植済みツールです。',
        'usage_en': 'Select a camera, load the camera tool, then add or edit camera shake settings.',
        'usage_ja': 'カメラを選択し、カメラツールを読み込んで、カメラ揺れ設定を追加または編集します。',
    },
    'Storyboard': {
        'title_en': 'Storyboard Tools',
        'title_ja': 'ストーリーボードツール',
        'overview_en': 'Migrated storyboard, Grease Pencil, camera setup, minimap, and shot-planning tools.',
        'overview_ja': 'ストーリーボード、Grease Pencil、カメラ設定、ミニマップ、ショット設計を扱う移植済みツールです。',
        'usage_en': 'Load Storytools only when needed, then use its storyboard-specific commands and optional always-on switches.',
        'usage_ja': '必要な時だけ Storytools を読み込み、ストーリーボード用コマンドと必要な常時起動スイッチを使います。',
    },
}


INTEGRATED_GENERIC_SETTINGS = [
    {
        'name_en': 'Load Tool',
        'name_ja': 'ツール読込',
        'description_en': 'Loads the bundled tool from the N-panel only when you request it.',
        'description_ja': '必要な時だけ、Nパネルから同梱ツールを読み込みます。',
    },
    {
        'name_en': 'Quick Access',
        'name_ja': 'クイックアクセス',
        'description_en': 'Displays high-priority commands in the N-panel after the tool is loaded.',
        'description_ja': 'ツール読込後、使用頻度の高いコマンドをNパネルに表示します。',
    },
    {
        'name_en': 'Commands',
        'name_ja': 'コマンド',
        'description_en': 'Displays migrated operators and menus that belong to the loaded tool.',
        'description_ja': '読み込んだツールに含まれる移植済みオペレーターとメニューを表示します。',
    },
    {
        'name_en': 'Runtime Properties',
        'name_ja': '実行時プロパティ',
        'description_en': 'Displays editable runtime properties exposed by the loaded tool when available. Add-on Preferences properties are not used.',
        'description_ja': '読み込んだツールが公開する実行時プロパティがある場合、Nパネル内に表示します。アドオンプリファレンスのプロパティは使用しません。',
    },
    {
        'name_en': 'N-panel Persistence',
        'name_ja': 'Nパネル設定の永続化',
        'description_en': 'Settings changed from the N-panel are saved under Blender CONFIG/Smart_Animation_Suite and restored after Blender restarts or another scene is opened.',
        'description_ja': 'Nパネルで変更した設定は Blender の CONFIG/Smart_Animation_Suite 配下へ保存され、Blender再起動後や別シーンを開いた後も復元されます。',
    },
]


def _base_name(base) -> str:
    if isinstance(base, ast.Name):
        return str(base.id or '')
    if isinstance(base, ast.Attribute):
        left = _base_name(base.value)
        return f'{left}.{base.attr}' if left else str(base.attr or '')
    if isinstance(base, ast.Subscript):
        return _base_name(base.value)
    return ''


def _class_uses_addon_preferences(node: ast.ClassDef) -> bool:
    for base in node.bases or ():
        name = _base_name(base)
        if name.endswith('AddonPreferences') or name.endswith('.AddonPreferences'):
            return True
    return False


def _is_legacy_preferences_class(node: ast.ClassDef) -> bool:
    name = str(getattr(node, 'name', '') or '')
    lowered = name.lower()
    if _class_uses_addon_preferences(node):
        return True
    if lowered.endswith('addonpreferences') or lowered.endswith('_preferences') or lowered.endswith('_prefs'):
        return True
    return name in {'SPL_Preferences', 'STORYTOOLS_prefs', 'TLFC_AP_preferences'}


def _collect_addon_preferences_descendants(tree: ast.AST) -> set[int]:
    skipped: set[int] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and _is_legacy_preferences_class(node):
            for child in ast.walk(node):
                skipped.add(id(child))
    return skipped


@lru_cache(maxsize=32)
def _static_tool_settings(alias: str) -> tuple[tuple[str, str], ...]:
    alias = str(alias or '').strip()
    if not alias:
        return ()
    root = Path(__file__).resolve().parent / alias
    if not root.exists() or not root.is_dir():
        return ()
    rows: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for py_file in sorted(root.rglob('*.py')):
        try:
            source = py_file.read_text(encoding='utf-8')
            tree = ast.parse(source)
        except Exception:
            continue
        skip_ids = _collect_addon_preferences_descendants(tree)
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and any(getattr(target, 'attr', '') in registry.INTERNAL_RUNTIME_PROPERTIES for target in node.targets):
                skip_ids.add(id(node.value))
        for node in ast.walk(tree):
            if id(node) in skip_ids or not isinstance(node, ast.Call):
                continue
            func = node.func
            func_name = ''
            if isinstance(func, ast.Name):
                func_name = func.id
            elif isinstance(func, ast.Attribute):
                func_name = func.attr
            if not str(func_name).endswith('Property'):
                continue
            name = ''
            desc = ''
            for kw in node.keywords or ():
                if kw.arg not in {'name', 'description'}:
                    continue
                value = kw.value
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    if kw.arg == 'name':
                        name = value.value.strip()
                    else:
                        desc = value.value.strip()
            if not name and not desc:
                continue
            if not name or name.startswith('_'):
                continue
            marker = (name, desc)
            if marker in seen:
                continue
            seen.add(marker)
            rows.append(marker)
    return tuple(rows)


def _integrated_tool_topic(alias: str, context) -> dict:
    alias = str(alias or '').strip()
    meta = registry.TOOL_META.get(alias) or {}
    name = str(meta.get('display_name') or alias.replace('_', ' ').title() or 'Integrated Tool')
    overview_en = str(meta.get('overview_en') or f'{name} is a migrated bundled tool inside Smart Animation.')
    overview_ja = str(meta.get('overview_ja') or f'{name} は Smart Animation に移植された同梱ツールです。')
    usage_en = str(meta.get('usage_en') or 'Load the tool from the N-panel, then use its migrated commands, properties, and settings.')
    usage_ja = str(meta.get('usage_ja') or 'Nパネルからツールを読み込み、移植済みコマンド、プロパティ、設定を使用してください。')
    settings = list(INTEGRATED_GENERIC_SETTINGS)
    for setting_name, setting_desc in _static_tool_settings(alias):
        localized_name = sas_localize_text(setting_name, context)
        localized_desc = sas_localize_text(setting_desc, context) if setting_desc else ''
        if sas_is_japanese(context) and setting_desc and localized_desc == setting_desc:
            localized_desc = 'この設定は同梱ツールが登録した実行時設定です。値を変更すると、そのツールの動作または表示に反映されます。'
        settings.append({
            'name_en': setting_name,
            'name_ja': localized_name,
            'description_en': setting_desc or 'Editable runtime setting registered by this bundled tool.',
            'description_ja': localized_desc or 'この設定は同梱ツールが登録した実行時設定です。値を変更すると、そのツールの動作または表示に反映されます。',
        })
    if len(settings) == len(INTEGRATED_GENERIC_SETTINGS):
        settings.append({
            'name_en': 'Tool-specific Runtime Settings',
            'name_ja': 'ツール固有の実行時設定',
            'description_en': 'No statically declared editable runtime setting was found before loading this tool. Any properties registered after loading are shown in the migrated tool section when available.',
            'description_ja': 'このツールの読み込み前に静的定義された編集可能な実行時設定は見つかりませんでした。読み込み後に登録されるプロパティがある場合は、移植済みツールの項目に表示されます。',
        })
    return {
        'title_en': name,
        'title_ja': name,
        'overview_en': overview_en,
        'overview_ja': overview_ja,
        'usage_en': usage_en,
        'usage_ja': usage_ja,
        'settings': settings,
    }


def _integrated_group_topic(group: str, context) -> dict:
    group = str(group or '').strip()
    base = GROUP_HELP.get(group, {})
    aliases = registry.overview_group_aliases(group)
    settings = [
        {'name': 'Overview Task', 'description': 'Selects this migrated tool genre in the N-panel.'},
        {'name': 'Load Tool', 'description': 'Loads an individual bundled tool only when you explicitly request it.'},
    ]
    features = []
    if aliases:
        names = ', '.join(str((registry.TOOL_META.get(alias) or {}).get('display_name') or alias) for alias in aliases)
        settings.append({'name_en': 'Included Tools', 'name_ja': '含まれるツール', 'description_en': names, 'description_ja': names})
        for alias in aliases:
            meta = registry.TOOL_META.get(alias) or {}
            display = str(meta.get('display_name') or alias)
            features.append({
                'description_en': f'{display}: {meta.get("overview_en") or display}',
                'description_ja': f'{display}: {meta.get("overview_ja") or meta.get("overview_en") or display}',
            })
    return {
        'title_en': base.get('title_en', f'{group} Tools'),
        'title_ja': base.get('title_ja', f'{group}ツール'),
        'overview_en': base.get('overview_en', f'Migrated bundled tools for {group.lower()} workflows.'),
        'overview_ja': base.get('overview_ja', f'{group} 用の移植済み同梱ツール群です。'),
        'usage_en': base.get('usage_en', 'Load only the tool you need, then use its migrated commands and settings.'),
        'usage_ja': base.get('usage_ja', '必要なツールだけを読み込み、移植済みコマンドと設定を使用してください。'),
        'features': features,
        'settings': settings,
    }


def _topic(topic_key: str, context) -> dict:
    key = str(topic_key or '').strip()
    if key.startswith('tool:'):
        return _integrated_tool_topic(key.split(':', 1)[1], context)
    if key.startswith('group:'):
        return _integrated_group_topic(key.split(':', 1)[1], context)
    return NATIVE_TOPICS.get(key) or {
        'title_en': 'Smart Animation Help',
        'title_ja': 'Smart Animation ヘルプ',
        'overview_en': 'Help for the selected Smart Animation item.',
        'overview_ja': '選択した Smart Animation 項目のヘルプです。',
        'usage_en': 'Use the visible N-panel controls for the selected workflow.',
        'usage_ja': '選択したワークフローのNパネル操作を使用してください。',
        'settings': [],
    }


def _topic_settings(topic: dict, context) -> list[dict]:
    source = topic.get('settings_source')
    items = list(topic.get('settings') or [])
    props = topic.get('props') or []
    if props:
        items.extend(_rna_setting_items(context, props, include_enum_items=True))
    if source == 'always_on':
        items.extend(_always_on_items(context))
    return items


def _draw_help(layout, context, topic_key: str) -> None:
    topic = _topic(topic_key, context)
    title = _t(context, str(topic.get('title_en') or 'Help'), str(topic.get('title_ja') or topic.get('title_en') or 'ヘルプ'))
    layout.use_property_split = False
    layout.use_property_decorate = False

    title_box = layout.box()
    _draw_wrapped(title_box, context, title, icon='HELP', nested_level=1)

    overview = sas_text(str(topic.get('overview_en') or ''), str(topic.get('overview_ja') or ''), context)
    usage = sas_text(str(topic.get('usage_en') or ''), str(topic.get('usage_ja') or ''), context)

    box = layout.box()
    _draw_heading(box, context, 'Feature Overview', '機能概要', 'QUESTION')
    _draw_wrapped(box, context, overview, nested_level=1)
    for feature in topic.get('features') or ():
        text = _item_text(context, feature, 'description') if isinstance(feature, dict) else _lt(context, str(feature or ''))
        if text:
            _draw_wrapped(box, context, f'• {text}', nested_level=1, extra_inset=14)

    box = layout.box()
    _draw_heading(box, context, 'Usage', '使用方法', 'PLAY')
    _draw_wrapped(box, context, usage, nested_level=1)

    box = layout.box()
    _draw_heading(box, context, 'Settings', '設定項目', 'PREFERENCES')
    _draw_setting_items(box, context, _topic_settings(topic, context))


def _register_translations() -> None:
    global _TRANSLATIONS_REGISTERED
    if _TRANSLATIONS_REGISTERED:
        return
    try:
        bpy.app.translations.register(_TRANSLATION_DOMAIN, _TRANSLATIONS)
        _TRANSLATIONS_REGISTERED = True
    except Exception:
        pass


def _unregister_translations() -> None:
    global _TRANSLATIONS_REGISTERED
    if not _TRANSLATIONS_REGISTERED:
        return
    try:
        bpy.app.translations.unregister(_TRANSLATION_DOMAIN)
    except Exception:
        pass
    _TRANSLATIONS_REGISTERED = False


class SAS_OT_help_popup(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = 'sas.help_popup'
    bl_label = 'Smart Animation Help'
    bl_description = 'Display detailed Smart Animation help.'
    bl_options = {'INTERNAL'}

    topic_key: StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        topic_key = str(getattr(properties, 'topic_key', '') or '').strip()
        topic = _topic(topic_key, context)
        title = _t(context, str(topic.get('title_en') or 'Help'), str(topic.get('title_ja') or topic.get('title_en') or 'ヘルプ'))
        return _t(
            context,
            f'Open detailed help for {title}.',
            f'{title} の詳細ヘルプを開きます。ヘルプカタログはこのボタンを押した時だけ読み込まれます。',
        )

    def invoke(self, context, _event):
        try:
            return context.window_manager.invoke_popup(self, width=_POPUP_WIDTH)
        except Exception:
            return context.window_manager.invoke_props_dialog(self, width=_POPUP_WIDTH)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        _draw_help(self.layout, context, str(self.topic_key or ''))


_REGISTERED = False


def register() -> None:
    global _REGISTERED
    if _REGISTERED:
        return
    _register_translations()
    try:
        bpy.utils.register_class(harden_class_callbacks(SAS_OT_help_popup))
    except ValueError:
        pass
    _REGISTERED = True


def unregister() -> None:
    global _REGISTERED
    if not _REGISTERED:
        _unregister_translations()
        return
    try:
        bpy.utils.unregister_class(SAS_OT_help_popup)
    except Exception:
        pass
    _unregister_translations()
    _REGISTERED = False


def show_help(context, topic_key: str) -> bool:
    return show_help_popup(context, topic_key)


def show_help_popup(context, topic_key: str) -> bool:
    key = str(topic_key or '').strip()
    register()
    try:
        bpy.ops.sas.help_popup('INVOKE_DEFAULT', topic_key=key)
        return True
    except Exception:
        def _draw(menu, popup_context):
            try:
                _draw_help(menu.layout, popup_context, key)
            except Exception:
                menu.layout.label(text=_t(popup_context, 'Failed to draw help.', 'ヘルプ描画に失敗しました。'), icon='ERROR')
        try:
            topic = _topic(key, context)
            title = _t(context, str(topic.get('title_en') or 'Help'), str(topic.get('title_ja') or topic.get('title_en') or 'ヘルプ'))
            context.window_manager.popup_menu(_draw, title=title, icon='HELP')
            return True
        except Exception:
            return False


def invoke_help_popup(operator, context):
    # Compatibility wrapper for older dispatcher code. New N-panel code calls
    # show_help_popup(), so the popup class and catalog remain lazy-loaded.
    return show_help_popup(context, str(getattr(operator, 'topic_key', '') or '')) and {'FINISHED'} or {'CANCELLED'}


def draw_help_popup(layout, context, topic_key: str) -> None:
    # Compatibility wrapper for external callers that already imported help.py.
    _draw_help(layout, context, topic_key)
