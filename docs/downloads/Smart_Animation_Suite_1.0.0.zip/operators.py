# ============================================================================
# Smart Animation
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
# ============================================================================

import bpy
import json
import math
import random
from mathutils import Quaternion, Vector
from bpy.types import Operator
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)

from .translation import sas_error_reason, sas_text, sas_info
from .core import *
from .algorithms import (
    advanced_tween_value,
    frame_sequence,
    key_indices_in_range,
    radii_from_speeds,
    rebuild_curve_range_from_samples,
    speed_values_from_points,
)


def _selection_set_names(item):
    try:
        return list(json.loads(item.targets_json or "[]"))
    except Exception:
        return []


def _all_objects_from_context(context):
    data_objects = list(getattr(getattr(bpy, 'data', None), 'objects', []) or [])
    scene_objects = list(getattr(getattr(context, 'scene', None), 'objects', []) or [])
    if data_objects:
        return data_objects
    return scene_objects


def _set_active_object(context, obj):
    try:
        context.view_layer.objects.active = obj
        return True
    except Exception:
        pass
    try:
        context.view_layer.objects.active = obj
        return True
    except Exception:
        return False


def _area_window_region(area):
    for region in getattr(area, 'regions', ()):
        if getattr(region, 'type', '') == 'WINDOW':
            return region
    return None



def _find_context_area(context, area_types=('VIEW_3D',)):
    if isinstance(area_types, str):
        area_types = (area_types,)
    area = getattr(context, 'area', None)
    if area is not None and getattr(area, 'type', '') in area_types:
        return area
    for candidate in getattr(getattr(context, 'screen', None), 'areas', ()):
        if getattr(candidate, 'type', '') in area_types:
            return candidate
    return None



def _run_op_in_area(context, callback, area_types=('VIEW_3D',), **override_kwargs):
    if not hasattr(context, 'temp_override'):
        return callback()
    area = _find_context_area(context, area_types)
    if area is None:
        return callback()
    override = {}
    window = getattr(context, 'window', None)
    screen = getattr(context, 'screen', None)
    if window is not None:
        override['window'] = window
    if screen is not None:
        override['screen'] = screen
    override['area'] = area
    region = _area_window_region(area)
    if region is not None:
        override['region'] = region
    for key, value in override_kwargs.items():
        if value is not None:
            override[key] = value
    with context.temp_override(**override):
        return callback()


def _deselect_all_objects(context):
    try:
        _run_op_in_area(context, lambda: bpy.ops.object.mode_set(mode='OBJECT'))
    except Exception:
        pass
    try:
        _run_op_in_area(context, lambda: bpy.ops.object.select_all(action='DESELECT'))
        return
    except Exception:
        pass
    for obj in _all_objects_from_context(context):
        try:
            obj.select_set(False)
        except Exception:
            pass



def _selected_key_frames(curves):
    frames = set()
    for fcurve in curves:
        for key in getattr(fcurve, 'keyframe_points', []):
            selected = False
            for attr in ('select_control_point', 'select_left_handle', 'select_right_handle'):
                if getattr(key, attr, False):
                    selected = True
                    break
            if selected:
                try:
                    frames.add(int(round(float(key.co.x))))
                except Exception:
                    pass
    return sorted(frames)


def _tween_surrounding_keys(fcurve, frame, tolerance=1e-4):
    keys = []
    for key in getattr(fcurve, 'keyframe_points', []):
        try:
            keys.append((float(key.co.x), key))
        except Exception:
            continue
    keys.sort(key=lambda item: item[0])
    prev_prev = None
    prev_key = None
    exact_key = None
    next_key = None
    next_next = None
    for key_frame, key in keys:
        if abs(key_frame - float(frame)) <= tolerance:
            exact_key = key
            continue
        if key_frame < float(frame):
            prev_prev = prev_key
            prev_key = key
            continue
        if next_key is None:
            next_key = key
        elif next_next is None:
            next_next = key
            break
    return prev_prev, prev_key, exact_key, next_key, next_next


def _selected_key_positions(curves):
    positions = set()
    for fcurve in curves:
        for key in getattr(fcurve, 'keyframe_points', []):
            selected = False
            for attr in ('select_control_point', 'select_left_handle', 'select_right_handle'):
                if getattr(key, attr, False):
                    selected = True
                    break
            if selected:
                try:
                    positions.add(round(float(key.co.x), 6))
                except Exception:
                    pass
    return sorted(positions)


def _key_positions_in_range(curves, start, end):
    positions = set()
    for fcurve in curves:
        for key in getattr(fcurve, 'keyframe_points', []):
            try:
                x = float(key.co.x)
            except Exception:
                continue
            if start <= x <= end:
                positions.add(round(x, 6))
    return sorted(positions)


def _distribute_key_times_evenly(curves, old_positions):
    old_positions = sorted(round(float(value), 6) for value in old_positions)
    if len(old_positions) < 3:
        return 0, {}
    start = float(old_positions[0])
    end = float(old_positions[-1])
    if math.isclose(start, end):
        return 0, {}
    mapping = {}
    span = end - start
    count = len(old_positions) - 1
    for index, old in enumerate(old_positions):
        mapping[round(old, 6)] = start + (span * index / count)

    moved = 0
    for fcurve in curves:
        changed = False
        for key in getattr(fcurve, 'keyframe_points', []):
            old_key = round(float(key.co.x), 6)
            new_x = mapping.get(old_key)
            if new_x is None:
                continue
            delta = float(new_x) - float(key.co.x)
            if abs(delta) <= 1.0e-9:
                continue
            key.co.x += delta
            try:
                key.handle_left.x += delta
                key.handle_right.x += delta
            except Exception:
                pass
            moved += 1
            changed = True
        if changed:
            try:
                fcurve.update()
            except Exception:
                pass
    return moved, mapping


def _set_scene_preview_range(scene, start, end):
    start = int(round(float(start)))
    end = int(round(float(end)))
    if end < start:
        start, end = end, start
    try:
        scene.use_preview_range = True
    except Exception:
        pass
    try:
        scene.frame_preview_start = start
        scene.frame_preview_end = end
    except Exception:
        pass
    return start, end


def _sound_strip_frame_range(scene, selected_only=False):
    seq_editor = getattr(scene, 'sequence_editor', None)
    if seq_editor is None:
        return None
    sequences = getattr(seq_editor, 'strips_all', None) or getattr(seq_editor, 'strips', None) or []
    sound_strips = []
    for strip in sequences:
        if getattr(strip, 'type', '') != 'SOUND':
            continue
        if selected_only and not getattr(strip, 'select', False):
            continue
        sound_strips.append(strip)
    if selected_only and not sound_strips:
        active_strip = getattr(seq_editor, 'active_strip', None)
        if active_strip is not None and getattr(active_strip, 'type', '') == 'SOUND':
            sound_strips.append(active_strip)
    if not sound_strips:
        return None

    def _start(strip):
        for attr in ('frame_final_start', 'frame_start'):
            if hasattr(strip, attr):
                try:
                    return float(getattr(strip, attr))
                except Exception:
                    pass
        return 0.0

    def _end(strip):
        for attr in ('frame_final_end', 'frame_end'):
            if hasattr(strip, attr):
                try:
                    value = float(getattr(strip, attr))
                    return value - 1.0 if 'final' in attr or attr == 'frame_end' else value
                except Exception:
                    pass
        start = _start(strip)
        duration = float(getattr(strip, 'frame_duration', 1.0) or 1.0)
        return start + duration - 1.0

    start = min(_start(strip) for strip in sound_strips)
    end = max(_end(strip) for strip in sound_strips)
    if end < start:
        end = start
    return start, end, sound_strips


def _enum_identifiers(owner, prop_name):
    try:
        properties = getattr(getattr(owner, "bl_rna", None), "properties", None)
        if properties is None:
            return []
        prop = properties.get(prop_name)
        if prop is None:
            return []
        return [item.identifier for item in getattr(prop, "enum_items", [])]
    except Exception:
        return []


def _safe_set_attr(owner, prop_name, value):
    if owner is None or not hasattr(owner, prop_name):
        return False
    try:
        setattr(owner, prop_name, value)
        return True
    except Exception:
        return False


def _set_sync_mode(scene, preferred):
    identifiers = _enum_identifiers(scene, "sync_mode")
    for identifier in preferred:
        if identifier in identifiers:
            try:
                scene.sync_mode = identifier
                return identifier
            except Exception:
                pass
    if identifiers:
        try:
            scene.sync_mode = identifiers[0]
            return identifiers[0]
        except Exception:
            pass
    return ""


def _ensure_preview_range_is_valid(scene):
    if scene is None:
        return 0, 0
    scene_start = int(getattr(scene, "frame_start", 1))
    scene_end = int(getattr(scene, "frame_end", scene_start))
    try:
        start = int(getattr(scene, "frame_preview_start"))
        end = int(getattr(scene, "frame_preview_end"))
    except Exception:
        start, end = scene_start, scene_end
    if end < start:
        start, end = scene_start, scene_end
    return _set_scene_preview_range(scene, start, end)


GLOBAL_TRANSFORM_CLIPBOARD = {
    'matrix': None,
    'source_kind': '',
    'source_name': '',
}


def _active_pose_bone_from_context(context):
    bone = getattr(context, 'active_pose_bone', None)
    if bone is not None:
        return bone
    selected = getattr(context, 'selected_pose_bones', None) or []
    return selected[0] if selected else None


def _clipboard_target_from_context(context):
    if getattr(context, 'mode', '') == 'POSE':
        bone = _active_pose_bone_from_context(context)
        if bone is not None:
            return 'POSE_BONE', bone, bone.id_data
    obj = active_object(context)
    if obj is not None:
        return 'OBJECT', obj, None
    return None, None, None


def _insert_transform_keys_if_autokey(context, target):
    tool_settings = getattr(getattr(context, 'scene', None), 'tool_settings', None)
    if not getattr(tool_settings, 'use_keyframe_insert_auto', False):
        return 0
    frame = getattr(getattr(context, 'scene', None), 'frame_current', 0)
    paths = ['location', 'scale']
    rotation_mode = getattr(target, 'rotation_mode', '')
    if rotation_mode == 'QUATERNION':
        paths.insert(1, 'rotation_quaternion')
    elif rotation_mode == 'AXIS_ANGLE':
        paths.insert(1, 'rotation_axis_angle')
    else:
        paths.insert(1, 'rotation_euler')
    inserted = 0
    for path in paths:
        try:
            target.keyframe_insert(data_path=path, frame=frame)
            inserted += 1
        except Exception:
            pass
    return inserted



def _owner_world_matrix(context, owner, armature=None):
    if getattr(context, 'mode', '') == 'POSE' and armature is not None and owner is not None:
        try:
            return armature.matrix_world @ owner.matrix.copy()
        except Exception:
            return None
    if owner is not None:
        try:
            return owner.matrix_world.copy()
        except Exception:
            return None
    return None



def _restore_owner_world_matrix(context, owner, world_matrix, armature=None):
    if owner is None or world_matrix is None:
        return False
    try:
        if getattr(context, 'mode', '') == 'POSE' and armature is not None:
            owner.matrix = armature.matrix_world.inverted() @ world_matrix
        else:
            owner.matrix_world = world_matrix.copy()
        return True
    except Exception:
        return False



def _set_childof_inverse(context, constraint, owner, armature=None):
    if constraint is None or owner is None:
        return False
    owner_type = 'BONE' if armature is not None and getattr(context, 'mode', '') == 'POSE' else 'OBJECT'
    try:
        if hasattr(context, 'temp_override'):
            if owner_type == 'BONE':
                with context.temp_override(object=armature, active_object=armature, pose_bone=owner, active_pose_bone=owner, constraint=constraint):
                    bpy.ops.constraint.childof_set_inverse(constraint=constraint.name, owner='BONE')
                    return True
            else:
                with context.temp_override(object=owner, active_object=owner, constraint=constraint):
                    bpy.ops.constraint.childof_set_inverse(constraint=constraint.name, owner='OBJECT')
                    return True
    except Exception:
        pass
    try:
        constraint.set_inverse_pending = True
        return True
    except Exception:
        return False



class SAS_OT_insert_keys(Operator):
    bl_idname = "sas.insert_keys"
    bl_label = "Insert Keys"
    bl_options = {'UNDO'}

    mode: EnumProperty(
        name="Insert Key Mode",
        description="Choose which transform channels are keyed by Insert Keys. Use Visual when constraints or parenting mean you want the evaluated pose baked instead of raw local values.",
        items=[
            ('ALL', "All", "Insert location, rotation, and scale keys."),
            ('LOC', "Location", "Insert location keys only."),
            ('ROT', "Rotation", "Insert rotation keys only."),
            ('SCALE', "Scale", "Insert scale keys only."),
            ('VISUAL', "Visual", "Insert visually evaluated location, rotation, and scale keys."),
        ],
        default='ALL',
    )

    @classmethod
    def description(cls, context, properties):
        if properties.mode == 'LOC':
            return sas_text(
                "Insert location keys on selected bones in Pose Mode or selected objects in Object Mode.",
                "ポーズモードでは選択ボーンに、オブジェクトモードでは選択オブジェクトに位置キーを打ちます。",
                context,
            )
        if properties.mode == 'ROT':
            return sas_text(
                "Insert rotation keys on selected bones in Pose Mode or selected objects in Object Mode.",
                "ポーズモードでは選択ボーンに、オブジェクトモードでは選択オブジェクトに回転キーを打ちます。",
                context,
            )
        if properties.mode == 'SCALE':
            return sas_text(
                "Insert scale keys on selected bones in Pose Mode or selected objects in Object Mode.",
                "ポーズモードでは選択ボーンに、オブジェクトモードでは選択オブジェクトにスケールキーを打ちます。",
                context,
            )
        if properties.mode == 'VISUAL':
            return sas_text(
                "Insert visual keys so constrained motion is baked as the current visible transform on the current frame.",
                "コンストレイント結果を含む見た目どおりの変形を、現在フレームへビジュアルキーとして記録します。",
                context,
            )
        return sas_text(
            "Insert location, rotation, and scale keys on the current frame for the current selection.",
            "現在の選択に対して、現在フレームへ位置・回転・スケールのキーを打ちます。",
            context,
        )

    def execute(self, context):
        targets = current_targets(context)
        if not targets:
            self.report({'WARNING'}, sas_text("Nothing selected.", "何も選択されていません。", context))
            add_log(context, "WARN", "Insert Keys cancelled because nothing was selected.", "何も選択されていないためキー挿入を中止しました。")
            return {'CANCELLED'}

        settings = context.scene.sas_settings
        visual = self.mode == 'VISUAL'
        options = key_options_from_settings(settings, visual=visual)
        frame = context.scene.frame_current
        inserted = 0

        try:
            if context.mode == 'POSE':
                ensure_active_action(context, base_name=f"{active_object(context).name}_Action")
            for target in targets:
                if context.mode != 'POSE' and hasattr(target, 'animation_data_create'):
                    ensure_active_action(context, obj=target, base_name=f"{target.name}_Action")
                data_paths = []
                if self.mode in {'ALL', 'LOC', 'VISUAL'}:
                    data_paths.append("location")
                if self.mode in {'ALL', 'ROT', 'VISUAL'}:
                    if hasattr(target, "rotation_mode"):
                        if target.rotation_mode == 'QUATERNION':
                            data_paths.append("rotation_quaternion")
                        elif target.rotation_mode == 'AXIS_ANGLE':
                            data_paths.append("rotation_axis_angle")
                        else:
                            data_paths.append("rotation_euler")
                if self.mode in {'ALL', 'SCALE', 'VISUAL'}:
                    data_paths.append("scale")

                for path in data_paths:
                    target.keyframe_insert(data_path=path, frame=frame, options=options)
                    inserted += 1

            self.report({'INFO'}, sas_text(f"Inserted {inserted} key paths.", f"{inserted} 個のキーパスを挿入しました。", context))
            add_log(context, "INFO", f"Inserted {inserted} key paths ({ {'ALL': 'All', 'LOC': 'Location', 'ROT': 'Rotation', 'SCALE': 'Scale', 'VISUAL': 'Visual'}.get(self.mode, '') }).", f"{inserted} 個のキーパスを挿入しました（{ {'ALL': '全チャンネル', 'LOC': '位置', 'ROT': '回転', 'SCALE': 'スケール', 'VISUAL': 'ビジュアル'}.get(self.mode, '') }）。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Key insert failed: {exc}", f"キー挿入に失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Key insert failed: {exc}", f"キー挿入に失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}


class SAS_OT_bake_visual_keys(Operator):
    bl_idname = "sas.bake_visual_keys"
    bl_label = "Bake Visual Keys"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Bake the current selection over the chosen frame range using visual keying. This is useful after constraints or drivers create a result you want to convert into regular keys.",
            "選択したフレーム範囲に対して、現在の選択をビジュアルキーでベイクします。コンストレイントやドライバーの結果を通常キーに変換したいときに便利です。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        has_targets = bool(context.selected_objects) or bool(getattr(context, 'selected_pose_bones', None))
        if not has_targets:
            self.report({'WARNING'}, sas_text("Nothing selected to bake.", "ベイク対象が選択されていません。", context))
            add_log(context, "WARN", "Bake Visual Keys cancelled because nothing was selected.", "何も選択されていないためビジュアルベイクを中止しました。")
            return {'CANCELLED'}

        start, end = get_bake_range(context.scene, settings)
        bake_types = {'POSE'} if context.mode == 'POSE' else {'OBJECT'}
        target = active_object(context)
        try:
            _run_op_in_area(
                context,
                lambda: bpy.ops.nla.bake(
                    frame_start=start,
                    frame_end=end,
                    step=settings.frame_step,
                    only_selected=True,
                    visual_keying=True,
                    clear_constraints=False,
                    clear_parents=False,
                    use_current_action=True,
                    clean_curves=False,
                    bake_types=bake_types,
                ),
                object=target,
                active_object=target,
            )
            self.report({'INFO'}, sas_text("Visual bake completed.", "ビジュアルベイクが完了しました。", context))
            add_log(context, "INFO", f"Visual bake completed for frames {start}-{end} step {settings.frame_step}.", f"フレーム {start}-{end} を間隔 {settings.frame_step} でビジュアルベイクしました。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Bake failed: {exc}", f"ベイクに失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Visual bake failed: {exc}", f"ビジュアルベイクに失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}


class SAS_OT_add_marker(Operator):
    bl_idname = "sas.add_marker"
    bl_label = "Add Marker"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Add a timeline marker on the current frame using the marker name field.",
            "マーカー名フィールドの内容で、現在フレームにタイムラインマーカーを追加します。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.sas_settings
        name = settings.marker_name.strip() or "SAS Marker"
        marker = scene.timeline_markers.new(name=name, frame=scene.frame_current)
        self.report({'INFO'}, sas_text(f"Added marker '{marker.name}'.", f"マーカー「{marker.name}」を追加しました。", context))
        add_log(context, "INFO", f"Added timeline marker '{marker.name}' at frame {scene.frame_current}.", f"フレーム {scene.frame_current} にタイムラインマーカー「{marker.name}」を追加しました。")
        return {'FINISHED'}


class SAS_OT_jump_marker(Operator):
    bl_idname = "sas.jump_marker"
    bl_label = "Jump Marker"
    bl_options = {'UNDO'}

    direction: EnumProperty(
        name="Marker Direction",
        description="Choose whether Jump Marker moves backward or forward through the timeline-marker list.",
        items=[
            ('PREV', "Previous", "Jump to the previous marker."),
            ('NEXT', "Next", "Jump to the next marker."),
        ],
        default='NEXT',
    )

    @classmethod
    def description(cls, context, properties):
        if properties.direction == 'PREV':
            return sas_text("Jump to the previous timeline marker.", "前のタイムラインマーカーへ移動します。", context)
        return sas_text("Jump to the next timeline marker.", "次のタイムラインマーカーへ移動します。", context)

    def execute(self, context):
        scene = context.scene
        current = scene.frame_current
        frames = sorted(marker.frame for marker in scene.timeline_markers)
        if not frames:
            self.report({'WARNING'}, sas_text("No markers found.", "マーカーが見つかりません。", context))
            add_log(context, "WARN", "Jump Marker cancelled because no markers were found.", "マーカーがないためマーカー移動を中止しました。")
            return {'CANCELLED'}

        target = None
        if self.direction == 'PREV':
            for frame in reversed(frames):
                if frame < current:
                    target = frame
                    break
        else:
            for frame in frames:
                if frame > current:
                    target = frame
                    break

        if target is None:
            self.report({'INFO'}, sas_text("No more markers in that direction.", "その方向にはこれ以上マーカーがありません。", context))
            add_log(context, "INFO", f"No {'previous' if self.direction == 'PREV' else 'next'} marker found.", f"{'前' if self.direction == 'PREV' else '次'}のマーカーがありませんでした。")
            return {'CANCELLED'}

        scene.frame_current = int(target)
        self.report({'INFO'}, sas_text(f"Jumped to frame {target}.", f"フレーム {target} に移動しました。", context))
        add_log(context, "INFO", f"Jumped to marker frame {target}.", f"マーカーのあるフレーム {target} に移動しました。")
        return {'FINISHED'}


class SAS_OT_mark_selected_keys(Operator):
    bl_idname = "sas.mark_selected_keys"
    bl_label = "Mark Selected Keys"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create timeline markers on the frames of selected keyframes. This is useful for contact beats, lip-sync notes, camera cuts, or review checkpoints.",
            "選択中キーフレームのフレーム位置にタイムラインマーカーを作成します。接地タイミング、リップシンクのメモ、カメラカット、レビュー用チェックポイント作成に便利です。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        action = active_action(context)
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Mark Selected Keys cancelled because there is no active action.", "アクティブアクションがないため選択キーのマーカー化を中止しました。")
            return {'CANCELLED'}

        curves = _selected_or_all_curves(context, action)
        frames = _selected_key_frames(curves)
        if not frames:
            self.report({'WARNING'}, sas_text("No selected keyframes were found.", "選択中のキーフレームが見つかりません。", context))
            add_log(context, "WARN", "Mark Selected Keys found no selected keyframes.", "選択中キーフレームが見つからないためマーカー化を中止しました。")
            return {'CANCELLED'}

        if settings.preview_only:
            self.report({'INFO'}, sas_text(f"Marker preview — {len(frames)} frames would receive markers.", f"マーカープレビュー — {len(frames)} フレームにマーカーが作成されます。", context))
            add_log(context, "INFO", f"Marker preview for {len(frames)} selected-key frames.", f"{len(frames)} フレームの選択キーに対するマーカープレビューを実行しました。")
            return {'FINISHED'}

        prefix = (settings.marker_name or "Key").strip() or "Key"
        existing_frames = {int(getattr(marker, 'frame', -9999999)) for marker in context.scene.timeline_markers}
        created = 0
        for frame in frames:
            if frame in existing_frames:
                continue
            name = f"{prefix}_{frame:04d}"
            try:
                context.scene.timeline_markers.new(name, frame=frame)
            except TypeError:
                context.scene.timeline_markers.new(name=name, frame=frame)
            created += 1
            existing_frames.add(frame)

        self.report({'INFO'}, sas_text(f"Created {created} timeline markers from selected keys.", f"選択キーから {created} 個のタイムラインマーカーを作成しました。", context))
        add_log(context, "INFO", f"Created {created} timeline markers from selected keys.", f"選択キーから {created} 個のタイムラインマーカーを作成しました。")
        return {'FINISHED'}


class SAS_OT_shift_keys(Operator):
    bl_idname = "sas.shift_keys"
    bl_label = "Shift Keys"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Shift all keys in the active action by the configured frame offset. Use this when you need the whole motion to start earlier or later without editing values.",
            "アクティブアクションの全キーを、設定したフレーム量だけ移動します。動きの値は変えず、開始タイミングだけ前後させたいときに使います。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if not action:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Shift Keys cancelled because there is no active action.", "アクティブアクションがないため Shift Keys を中止しました。")
            return {'CANCELLED'}

        curves = selected_fcurves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves to retime.", "タイミング変更する F カーブがありません。", context))
            add_log(context, "WARN", "Shift Keys found no F-Curves to retime.", "タイミング変更する F カーブがないため Shift Keys を中止しました。")
            return {'CANCELLED'}

        ensure_action_backup(context, "shift")
        start, end = get_timing_range(context, action, settings)
        moved = shift_fcurve_keys(curves, settings.retime_offset, start, end)
        self.report({'INFO'}, sas_text(f"Shifted {moved} keys by {settings.retime_offset} frames.", f"{moved} 個のキーを {settings.retime_offset} フレーム移動しました。", context))
        add_log(context, "INFO", f"Shifted {moved} keys by {settings.retime_offset} frames in range {start:.0f}-{end:.0f}.", f"範囲 {start:.0f}-{end:.0f} で {moved} 個のキーを {settings.retime_offset} フレーム移動しました。")
        return {'FINISHED'}


class SAS_OT_scale_key_timing(Operator):
    bl_idname = "sas.scale_key_timing"
    bl_label = "Scale Key Timing"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Scale the timing of keys in the active action around the chosen pivot frame. Use values above 1.0 to stretch timing and values below 1.0 to compress it.",
            "アクティブアクション内のキータイミングを、選んだ基準フレームを中心に拡大縮小します。1.0 より大きいと伸ばし、小さいと圧縮します。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if not action:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Scale Key Timing cancelled because there is no active action.", "アクティブアクションがないため Scale Key Timing を中止しました。")
            return {'CANCELLED'}

        curves = selected_fcurves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves to retime.", "タイミング変更する F カーブがありません。", context))
            add_log(context, "WARN", "Scale Key Timing found no F-Curves to retime.", "タイミング変更する F カーブがないため Scale Key Timing を中止しました。")
            return {'CANCELLED'}

        factor = settings.retime_scale
        if factor <= 0.0:
            self.report({'ERROR'}, sas_text("Scale factor must be greater than zero.", "スケール係数は 0 より大きい必要があります。", context))
            add_log(context, "ERROR", "Scale Key Timing failed because the scale factor was not greater than zero.", "スケール係数が 0 以下のため Scale Key Timing に失敗しました。")
            return {'CANCELLED'}

        ensure_action_backup(context, "retime")
        start, end = get_timing_range(context, action, settings)
        pivot = get_timing_pivot(context, action, settings, start, end)
        moved = scale_fcurve_keys(curves, factor, pivot, start, end)
        self.report({'INFO'}, sas_text(f"Scaled timing of {moved} keys by {factor:.3f}.", f"{moved} 個のキーのタイミングを {factor:.3f} 倍にしました。", context))
        add_log(context, "INFO", f"Scaled timing of {moved} keys by {factor:.3f} around pivot {pivot:.2f} in range {start:.0f}-{end:.0f}.", f"範囲 {start:.0f}-{end:.0f} で {moved} 個のキーをピボット {pivot:.2f} 基準で {factor:.3f} 倍にしました。")
        return {'FINISHED'}




class SAS_OT_distribute_key_timing(Operator):
    bl_idname = "sas.distribute_key_timing"
    bl_label = "Even Key Timing"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Evenly redistribute selected keyframes between the outermost keys. If no keys are selected, use the current Timing range. This is useful for blocking passes, stepped timing cleanup, and restoring consistent spacing after rough edits.",
            "外側のキーを固定したまま、選択キーフレームを等間隔に再配置します。キー選択がない場合は現在のタイミング範囲を使います。ブロッキング、段階補間の整理、荒い編集後の均一な間隔の復元に便利です。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if not action:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Even Key Timing cancelled because there is no active action.", "アクティブアクションがないため等間隔タイミングを中止しました。")
            return {'CANCELLED'}

        curves = selected_fcurves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves to retime.", "タイミング変更する F カーブがありません。", context))
            add_log(context, "WARN", "Even Key Timing found no F-Curves to retime.", "タイミング変更する F カーブがないため等間隔タイミングを中止しました。")
            return {'CANCELLED'}

        selected_positions = _selected_key_positions(curves)
        source_en = "selected keys"
        source_ja = "選択キー"
        positions = selected_positions

        if len(positions) < 3:
            start, end = get_timing_range(context, action, settings)
            positions = _key_positions_in_range(curves, start, end)
            source_en = "timing range"
            source_ja = "タイミング範囲"

        if len(positions) < 3:
            self.report({'WARNING'}, sas_text("Select at least 3 keys, or define a Timing range that contains at least 3 keyframes.", "少なくとも 3 個のキーを選択するか、3 個以上のキーフレームを含むタイミング範囲を指定してください。", context))
            add_log(context, "WARN", "Even Key Timing cancelled because fewer than 3 usable key positions were found.", "使用できるキー位置が 3 個未満のため等間隔タイミングを中止しました。")
            return {'CANCELLED'}

        if math.isclose(float(positions[0]), float(positions[-1])):
            self.report({'WARNING'}, sas_text("The outer keyframes sit on the same frame, so spacing cannot be redistributed.", "外側キーが同じフレームにあるため、間隔を再配置できません。", context))
            add_log(context, "WARN", "Even Key Timing cancelled because the outer key positions were identical.", "外側キー位置が同一のため等間隔タイミングを中止しました。")
            return {'CANCELLED'}

        ensure_action_backup(context, "even_timing")
        moved, mapping = _distribute_key_times_evenly(curves, positions)
        if moved <= 0:
            self.report({'INFO'}, sas_text("The targeted keys are already evenly distributed.", "対象キーはすでに等間隔です。", context))
            add_log(context, "INFO", "Even Key Timing found no key positions that needed redistribution.", "等間隔に再配置が必要なキーは見つかりませんでした。")
            return {'FINISHED'}

        start = float(positions[0])
        end = float(positions[-1])
        self.report({'INFO'}, sas_text(f"Evenly redistributed {len(mapping)} key positions from {source_en} across {start:.2f}-{end:.2f}.", f"{source_ja}から {len(mapping)} 個のキー位置を {start:.2f}-{end:.2f} の範囲で等間隔に再配置しました。", context))
        add_log(context, "INFO", f"Even Key Timing redistributed {len(mapping)} key positions from {source_en} across {start:.2f}-{end:.2f} and moved {moved} key points.", f"{source_ja}から {len(mapping)} 個のキー位置を {start:.2f}-{end:.2f} で等間隔に再配置し、{moved} 個のキーポイントを移動しました。")
        return {'FINISHED'}


class SAS_OT_insert_shape_key_keys(Operator):
    bl_idname = "sas.insert_shape_key_keys"
    bl_label = "Insert Shape Keys"
    bl_options = {'UNDO'}

    mode: EnumProperty(
        name="Shape Key Insert Mode",
        description="Choose whether to key every non-Basis shape key or only the active one on the current frame.",
        items=[
            ('ALL', "All Shape Keys", "Key all non-Basis shape keys on the active object at the current frame."),
            ('ACTIVE', "Active Shape Key", "Key only the currently active shape key on the active object at the current frame."),
        ],
        default='ALL',
    )

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Insert shape-key values as keyframes on the current frame. Use this for facial controls, visemes, or corrective blendshapes on the active object.",
            "現在フレームにシェイプキー値をキーフレームとして記録します。アクティブオブジェクトのフェイシャル、口形素、補正ブレンドシェイプに使います。",
            context,
        )

    def execute(self, context):
        obj = active_object(context)
        shape_keys = active_shape_key_data(obj)
        if obj is None or shape_keys is None or len(shape_keys.key_blocks) <= 1:
            self.report({'WARNING'}, sas_text("The active object has no usable shape keys.", "アクティブオブジェクトに使用可能なシェイプキーがありません。", context))
            add_log(context, "WARN", "Insert Shape Keys cancelled because the active object has no usable shape keys.", "アクティブオブジェクトに使用可能なシェイプキーがないため Insert Shape Keys を中止しました。")
            return {'CANCELLED'}

        frame = context.scene.frame_current
        inserted = 0
        targets = []
        if self.mode == 'ACTIVE':
            active_key = getattr(obj, 'active_shape_key', None)
            if active_key and active_key.name != 'Basis':
                targets = [active_key]
        else:
            targets = [kb for kb in shape_keys.key_blocks if kb.name != 'Basis']

        if not targets:
            self.report({'WARNING'}, sas_text("No shape keys matched the requested mode.", "指定モードに一致するシェイプキーがありません。", context))
            add_log(context, "WARN", "Insert Shape Keys found no matching shape keys.", "指定モードに一致するシェイプキーがないため Insert Shape Keys を中止しました。")
            return {'CANCELLED'}

        for key_block in targets:
            shape_keys.keyframe_insert(data_path=f'key_blocks["{key_block.name}"].value', frame=frame)
            inserted += 1

        self.report({'INFO'}, sas_text(f"Inserted shape-key keys for {inserted} channels.", f"{inserted} 個のシェイプキーチャンネルにキーを挿入しました。", context))
        add_log(context, "INFO", f"Inserted shape-key keys for {inserted} channels.", f"{inserted} 個のシェイプキーチャンネルにキーを挿入しました。")
        return {'FINISHED'}


class SAS_OT_smooth_shape_key_curves(Operator):
    bl_idname = "sas.smooth_shape_key_curves"
    bl_label = "Smooth Shape Key Curves"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Smooth animated Shape Key value curves on the active object. This is useful for facial animation, viseme transitions, and corrective blendshape polish.",
            "アクティブオブジェクトのシェイプキー値カーブをスムージングします。フェイシャル、口形素のつなぎ、補正ブレンドシェイプの仕上げに便利です。",
            context,
        )

    def execute(self, context):
        obj = active_object(context)
        if obj is None:
            self.report({'WARNING'}, sas_text("No active object.", "アクティブオブジェクトがありません。", context))
            add_log(context, "WARN", "Smooth Shape Key Curves cancelled because there is no active object.", "アクティブオブジェクトがないためシェイプキースムージングを中止しました。")
            return {'CANCELLED'}
        action = get_shape_key_action(obj, create=False)
        curves = _shape_key_curves(context, obj)
        settings = context.scene.sas_settings
        if action is None or not curves:
            self.report({'WARNING'}, sas_text("No animated Shape Key curves were found.", "アニメーション済みのシェイプキーカーブが見つかりません。", context))
            add_log(context, "WARN", "Smooth Shape Key Curves found no animated Shape Key curves.", "アニメーション済みのシェイプキーカーブがないためシェイプキースムージングを中止しました。")
            return {'CANCELLED'}
        backup = ensure_action_backup(context, "shape_smooth", action=action)
        changed = smooth_fcurve_values(curves, settings.curve_smooth_factor, settings.curve_smooth_iterations)
        if changed == 0:
            discard_action_backup(context, backup)
            self.report({'WARNING'}, sas_text("Shape Key smoothing found nothing to change.", "変更対象のシェイプキー値が見つかりませんでした。", context))
            add_log(context, "WARN", "Smooth Shape Key Curves found no editable in-between keys.", "編集可能な中間キーが見つからないためシェイプキースムージングを中止しました。")
            return {'CANCELLED'}
        self.report({'INFO'}, sas_text(f"Smoothed {changed} Shape Key values.", f"{changed} 個のシェイプキー値をスムージングしました。", context))
        add_log(context, "INFO", f"Smoothed {changed} Shape Key values on '{obj.name}'.", f"「{obj.name}」のシェイプキー値を {changed} 個スムージングしました。")
        return {'FINISHED'}


class SAS_OT_optimize_shape_key_curves(Operator):
    bl_idname = "sas.optimize_shape_key_curves"
    bl_label = "Optimize Shape Key Curves"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Optimize animated Shape Key curves on the active object by removing duplicates, deleting static channels, and simplifying dense in-betweens.",
            "アクティブオブジェクトのアニメーション済みシェイプキーカーブを最適化します。重複キー削除、静的チャンネル削除、密な中間キーの簡略化をまとめて行います。",
            context,
        )

    def execute(self, context):
        obj = active_object(context)
        shape_keys = active_shape_key_data(obj)
        if obj is None or shape_keys is None:
            self.report({'WARNING'}, sas_text("The active object has no Shape Keys.", "アクティブオブジェクトにシェイプキーがありません。", context))
            add_log(context, "WARN", "Optimize Shape Key Curves cancelled because the active object has no Shape Keys.", "アクティブオブジェクトにシェイプキーがないためシェイプキー最適化を中止しました。")
            return {'CANCELLED'}
        action = get_shape_key_action(obj, create=False)
        curves = _shape_key_curves(context, obj)
        settings = context.scene.sas_settings
        if action is None or not curves:
            self.report({'WARNING'}, sas_text("No animated Shape Key curves were found.", "アニメーション済みのシェイプキーカーブが見つかりません。", context))
            add_log(context, "WARN", "Optimize Shape Key Curves found no animated Shape Key curves.", "アニメーション済みのシェイプキーカーブがないためシェイプキー最適化を中止しました。")
            return {'CANCELLED'}
        if settings.preview_only:
            summary = summarize_cleanup(action, curves, settings.remove_threshold, settings.simplify_factor)
            message_en = f"Shape Key Preview — simplify keys: {summary['simplify_keys']}, duplicate keys: {summary['duplicate_keys']}, static channels: {summary['static_channels']}."
            message_ja = f"シェイプキープレビュー — 簡略化キー: {summary['simplify_keys']}、重複キー: {summary['duplicate_keys']}、静的チャンネル: {summary['static_channels']}。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}
        ensure_action_backup(context, "shape_cleanup", action=action)
        threshold = settings.remove_threshold
        simplify_factor = settings.simplify_factor
        removed_duplicates = 0
        removed_static = 0
        removed_simplified = 0
        for fcurve in list(curves):
            keys = fcurve.keyframe_points
            remove = []
            for index in range(1, len(keys)):
                prev = keys[index - 1]
                curr = keys[index]
                if abs(curr.co.x - prev.co.x) <= 1e-8:
                    remove.append(index)
            for index in range(1, len(keys) - 1):
                prev = keys[index - 1]
                curr = keys[index]
                nxt = keys[index + 1]
                if abs(prev.co.y - curr.co.y) <= threshold and abs(curr.co.y - nxt.co.y) <= threshold:
                    remove.append(index)
            removed_duplicates += safe_remove_keyframe_points(fcurve, remove)
        curves = _shape_key_curves(context, obj)
        for fcurve in list(curves):
            values = [kp.co.y for kp in fcurve.keyframe_points]
            if not values or max(values) - min(values) <= threshold:
                if remove_action_fcurve(action, fcurve, datablock=shape_keys):
                    removed_static += 1
        curves = _shape_key_curves(context, obj)
        for fcurve in curves:
            points = [(kp.co.x, kp.co.y) for kp in fcurve.keyframe_points]
            keep = simplify_point_indices(points, simplify_factor, preserve_extrema=True, threshold=threshold)
            remove = [index for index in range(len(points)) if index not in keep]
            removed_simplified += safe_remove_keyframe_points(fcurve, remove)
        total = removed_duplicates + removed_static + removed_simplified
        self.report({'INFO'}, sas_text(
            f"Optimized Shape Key curves. Removed duplicates: {removed_duplicates}, static channels: {removed_static}, simplified keys: {removed_simplified}.",
            f"シェイプキーカーブを最適化しました。重複削除: {removed_duplicates}、静的チャンネル: {removed_static}、簡略化キー: {removed_simplified}。",
            context,
        ))
        add_log(context, "INFO", f"Optimized Shape Key curves on '{obj.name}' and removed/condensed {total} items.", f"「{obj.name}」のシェイプキーカーブを最適化し、合計 {total} 件を削除または簡略化しました。")
        return {'FINISHED'}


class SAS_OT_preview_cleanup(Operator):
    bl_idname = "sas.preview_cleanup"
    bl_label = "Preview Cleanup"
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Analyze the current action and report how many keys or channels would be simplified, removed as duplicates, or deleted as static, without changing any data.",
            "現在のアクションを解析し、データを変更せずに、どれだけのキーやチャンネルが簡略化・重複削除・静的削除の対象になるかを報告します。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        if not action:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Cleanup preview cancelled because there is no active action.", "アクティブアクションがないため整理プレビューを中止しました。")
            return {'CANCELLED'}

        curves = selected_fcurves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves to inspect.", "確認する F カーブがありません。", context))
            add_log(context, "WARN", "Cleanup preview found no F-Curves to inspect.", "確認する F カーブがないため整理プレビューを中止しました。")
            return {'CANCELLED'}

        settings = context.scene.sas_settings
        summary = summarize_cleanup(action, curves, settings.remove_threshold, settings.simplify_factor)
        message_en = (
            f"Preview — simplify keys: {summary['simplify_keys']}, duplicate keys: {summary['duplicate_keys']}, static channels: {summary['static_channels']}."
        )
        message_ja = (
            f"プレビュー — 簡略化キー: {summary['simplify_keys']}、重複キー: {summary['duplicate_keys']}、静的チャンネル: {summary['static_channels']}。"
        )
        self.report({'INFO'}, sas_text(message_en, message_ja, context))
        add_log(context, "INFO", message_en, message_ja)
        return {'FINISHED'}


class SAS_OT_simplify_curves(Operator):
    bl_idname = "sas.simplify_curves"
    bl_label = "Simplify Curves"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove in-between keys whose values stay within the simplify factor from a straight-line interpolation. Use Preview Cleanup first if you want to see the impact before editing.",
            "直線補間との差が簡略化係数以内の中間キーを削除します。編集前に影響を見たい場合は先に整理プレビューを使ってください。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if not action:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Simplify Curves cancelled because there is no active action.", "アクティブアクションがないためカーブ簡略化を中止しました。")
            return {'CANCELLED'}

        curves = selected_fcurves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves to simplify.", "簡略化する F カーブがありません。", context))
            add_log(context, "WARN", "Simplify Curves found no F-Curves to edit.", "対象 F カーブがないためカーブ簡略化を中止しました。")
            return {'CANCELLED'}

        if settings.preview_only:
            return bpy.ops.sas.preview_cleanup()

        ensure_action_backup(context, "simplify")
        threshold = settings.simplify_factor
        total_removed = 0

        def simplify_points(points, epsilon):
            if len(points) <= 2:
                return set(range(len(points)))

            keep = {0, len(points) - 1}

            def recurse(start_idx, end_idx):
                max_dev = -1.0
                max_index = None
                f1, v1 = points[start_idx]
                f2, v2 = points[end_idx]
                for idx in range(start_idx + 1, end_idx):
                    fi, vi = points[idx]
                    pred = v1 if abs(f2 - f1) < 1e-8 else v1 + (v2 - v1) * ((fi - f1) / (f2 - f1))
                    dev = abs(vi - pred)
                    if dev > max_dev:
                        max_dev = dev
                        max_index = idx
                if max_index is not None and max_dev > epsilon:
                    keep.add(max_index)
                    recurse(start_idx, max_index)
                    recurse(max_index, end_idx)

            recurse(0, len(points) - 1)
            return keep

        for fcurve in curves:
            points = [(kp.co.x, kp.co.y) for kp in fcurve.keyframe_points]
            keep = simplify_points(points, threshold)
            remove = [idx for idx in range(len(points)) if idx not in keep]
            total_removed += safe_remove_keyframe_points(fcurve, remove)

        self.report({'INFO'}, sas_text(f"Removed {total_removed} in-between keys.", f"{total_removed} 個の中間キーを削除しました。", context))
        add_log(context, "INFO", f"Simplified curves and removed {total_removed} in-between keys.", f"カーブを簡略化し、{total_removed} 個の中間キーを削除しました。")
        return {'FINISHED'}


class SAS_OT_delete_static_channels(Operator):
    bl_idname = "sas.delete_static_channels"
    bl_label = "Delete Static Channels"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Delete F-Curves whose key values stay flat inside the threshold. This is useful to clean imported animation that contains unnecessary channels.",
            "キー値がしきい値内で変化しない F カーブを削除します。不要なチャンネルを多く含む読み込みアニメーションの整理に便利です。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if not action:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Delete Static Channels cancelled because there is no active action.", "アクティブアクションがないため静的チャンネル削除を中止しました。")
            return {'CANCELLED'}

        curves = selected_fcurves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves to inspect.", "確認する F カーブがありません。", context))
            add_log(context, "WARN", "Delete Static Channels found no F-Curves to inspect.", "確認する F カーブがないため静的チャンネル削除を中止しました。")
            return {'CANCELLED'}

        if settings.preview_only:
            return bpy.ops.sas.preview_cleanup()

        ensure_action_backup(context, "static")
        threshold = settings.remove_threshold
        to_remove = []

        for fcurve in curves:
            values = [kp.co.y for kp in fcurve.keyframe_points]
            if not values:
                to_remove.append(fcurve)
                continue
            if max(values) - min(values) <= threshold:
                to_remove.append(fcurve)

        removed = 0
        for fcurve in to_remove:
            remove_action_fcurve(action, fcurve, datablock=active_object(context))
            removed += 1

        self.report({'INFO'}, sas_text(f"Deleted {removed} static channels.", f"{removed} 個の静的チャンネルを削除しました。", context))
        add_log(context, "INFO", f"Deleted {removed} static channels.", f"{removed} 個の静的チャンネルを削除しました。")
        return {'FINISHED'}


class SAS_OT_remove_duplicate_keys(Operator):
    bl_idname = "sas.remove_duplicate_keys"
    bl_label = "Remove Duplicate Keys"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove exact same-frame duplicates and flat middle keys using the threshold. This helps reduce clutter after imports or aggressive baking.",
            "同一フレームの重複キーと、しきい値内で平坦な中間キーを削除します。読み込み後や強いベイク後の整理に役立ちます。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if not action:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Remove Duplicate Keys cancelled because there is no active action.", "アクティブアクションがないため重複キー削除を中止しました。")
            return {'CANCELLED'}

        curves = selected_fcurves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves to inspect.", "確認する F カーブがありません。", context))
            add_log(context, "WARN", "Remove Duplicate Keys found no F-Curves to inspect.", "確認する F カーブがないため重複キー削除を中止しました。")
            return {'CANCELLED'}

        if settings.preview_only:
            return bpy.ops.sas.preview_cleanup()

        ensure_action_backup(context, "duplicates")
        threshold = settings.remove_threshold
        total_removed = 0

        for fcurve in curves:
            keys = fcurve.keyframe_points
            remove = []

            for idx in range(1, len(keys)):
                prev = keys[idx - 1]
                curr = keys[idx]
                if abs(curr.co.x - prev.co.x) <= 1e-8:
                    remove.append(idx)

            for idx in range(1, len(keys) - 1):
                prev = keys[idx - 1]
                curr = keys[idx]
                nxt = keys[idx + 1]
                if abs(prev.co.y - curr.co.y) <= threshold and abs(curr.co.y - nxt.co.y) <= threshold:
                    remove.append(idx)

            total_removed += safe_remove_keyframe_points(fcurve, remove)

        self.report({'INFO'}, sas_text(f"Removed {total_removed} duplicate keys.", f"{total_removed} 個の重複キーを削除しました。", context))
        add_log(context, "INFO", f"Removed {total_removed} duplicate keys.", f"{total_removed} 個の重複キーを削除しました。")
        return {'FINISHED'}


class SAS_OT_pose_mirror(Operator):
    bl_idname = "sas.pose_mirror"
    bl_label = "Mirror Pose"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE' and bool(context.selected_pose_bones)

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Mirror the selected pose using Blender's flipped pose copy/paste. Best results use standard side names like .L and .R.",
            "Blender の反転コピーペーストを使って選択ポーズをミラーします。.L / .R などの標準的な左右命名で最もよく機能します。",
            context,
        )

    def execute(self, context):
        armature = active_object(context)
        try:
            _run_op_in_area(context, lambda: bpy.ops.pose.copy(), object=armature, active_object=armature)
            _run_op_in_area(context, lambda: bpy.ops.pose.paste(flipped=True), object=armature, active_object=armature)
            self.report({'INFO'}, sas_text("Mirrored pose.", "ポーズをミラーしました。", context))
            add_log(context, "INFO", "Mirrored the selected pose.", "選択ポーズをミラーしました。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Mirror failed: {exc}", f"ミラーに失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Mirror Pose failed: {exc}", f"ポーズミラーに失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}


class SAS_OT_pose_reset(Operator):
    bl_idname = "sas.pose_reset"
    bl_label = "Reset Selected Pose"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE' and bool(context.selected_pose_bones)

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Reset location, rotation, and scale on selected pose bones to their neutral values.",
            "選択したポーズボーンの位置・回転・スケールを中立値へ戻します。",
            context,
        )

    def execute(self, context):
        count = 0
        try:
            for bone in context.selected_pose_bones:
                bone.location = (0.0, 0.0, 0.0)
                if bone.rotation_mode == 'QUATERNION':
                    bone.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
                elif bone.rotation_mode == 'AXIS_ANGLE':
                    bone.rotation_axis_angle = (0.0, 0.0, 1.0, 0.0)
                else:
                    bone.rotation_euler = (0.0, 0.0, 0.0)
                bone.scale = (1.0, 1.0, 1.0)
                count += 1
            self.report({'INFO'}, sas_text(f"Reset {count} bones.", f"{count} 本のボーンをリセットしました。", context))
            add_log(context, "INFO", f"Reset {count} pose bones to neutral values.", f"{count} 本のポーズボーンを中立値へリセットしました。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Reset failed: {exc}", f"リセットに失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Pose reset failed: {exc}", f"ポーズリセットに失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}


class SAS_OT_store_pose_snapshot(Operator):
    bl_idname = "sas.store_pose_snapshot"
    bl_label = "Store Pose Snapshot"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE' and bool(active_object(context)) and active_object(context).type == 'ARMATURE'

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Store the current selected pose bones, or all pose bones if nothing is selected, as a reusable snapshot.",
            "現在の選択ポーズボーンを、未選択なら全ポーズボーンを、再利用できるスナップショットとして保存します。",
            context,
        )

    def execute(self, context):
        arm = active_object(context)
        settings = context.scene.sas_settings
        bones = list(context.selected_pose_bones or arm.pose.bones)
        if not bones:
            self.report({'WARNING'}, sas_text("No pose bones available.", "利用可能なポーズボーンがありません。", context))
            add_log(context, "WARN", "Store Pose Snapshot found no pose bones.", "利用可能なポーズボーンがないためスナップショット保存を中止しました。")
            return {'CANCELLED'}

        payload = {}
        for bone in bones:
            rot_values, rot_mode = bone_rotation_data(bone)
            payload[bone.name] = {
                "location": list(bone.location),
                "rotation": rot_values,
                "rotation_mode": rot_mode,
                "scale": list(bone.scale),
            }

        snapshot_name = unique_snapshot_name(context.scene, settings.snapshot_name)
        item = settings.pose_snapshots.add()
        item.name = snapshot_name
        item.data_json = json.dumps(payload, ensure_ascii=False)
        settings.pose_snapshot_index = len(settings.pose_snapshots) - 1

        self.report({'INFO'}, sas_text(f"Stored snapshot '{item.name}'.", f"スナップショット「{item.name}」を保存しました。", context))
        add_log(context, "INFO", f"Stored pose snapshot '{item.name}' with {len(payload)} bones.", f"{len(payload)} 本のボーンを含むポーズスナップショット「{item.name}」を保存しました。")
        return {'FINISHED'}


class SAS_OT_apply_pose_snapshot(Operator):
    bl_idname = "sas.apply_pose_snapshot"
    bl_label = "Apply Pose Snapshot"
    bl_options = {'UNDO'}

    set_index: IntProperty(
        name="Pose Snapshot Index",
        description="Optional stored pose-snapshot index to apply directly from compact picker buttons. Leave at -1 to use the current list selection.",
        default=-1,
        options={'SKIP_SAVE'},
    )

    @classmethod
    def poll(cls, context):
        settings = context.scene.sas_settings
        return context.mode == 'POSE' and len(settings.pose_snapshots) > 0

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Apply the currently highlighted pose snapshot to matching pose bones on the active armature.",
            "現在ハイライトされているポーズスナップショットを、アクティブアーマチュアの一致するポーズボーンへ適用します。",
            context,
        )

    def execute(self, context):
        arm = active_object(context)
        settings = context.scene.sas_settings
        requested_index = int(self.set_index) if int(self.set_index) >= 0 else int(settings.pose_snapshot_index)
        index = max(0, min(requested_index, len(settings.pose_snapshots) - 1))
        settings.pose_snapshot_index = index
        if index < 0 or index >= len(settings.pose_snapshots):
            self.report({'WARNING'}, sas_text("No snapshot selected.", "スナップショットが選択されていません。", context))
            add_log(context, "WARN", "Apply Pose Snapshot found no selected snapshot.", "選択中のスナップショットがないため適用を中止しました。")
            return {'CANCELLED'}

        snapshot = settings.pose_snapshots[index]
        try:
            payload = json.loads(snapshot.data_json)
            applied = 0
            for bone_name, data in payload.items():
                bone = arm.pose.bones.get(bone_name)
                if bone is None:
                    continue
                bone.location = data["location"]
                restore_bone_rotation(bone, data["rotation"], data["rotation_mode"])
                bone.scale = data["scale"]
                applied += 1
            self.report({'INFO'}, sas_text(f"Applied snapshot to {applied} bones.", f"{applied} 本のボーンにスナップショットを適用しました。", context))
            add_log(context, "INFO", f"Applied pose snapshot '{snapshot.name}' to {applied} bones.", f"ポーズスナップショット「{snapshot.name}」を {applied} 本のボーンへ適用しました。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Snapshot apply failed: {exc}", f"スナップショット適用に失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Apply Pose Snapshot failed: {exc}", f"ポーズスナップショット適用に失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}


class SAS_OT_remove_pose_snapshot(Operator):
    bl_idname = "sas.remove_pose_snapshot"
    bl_label = "Remove Pose Snapshot"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        settings = context.scene.sas_settings
        return len(settings.pose_snapshots) > 0

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Delete the currently highlighted pose snapshot from the list.",
            "現在ハイライトされているポーズスナップショットを一覧から削除します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        index = settings.pose_snapshot_index
        if index < 0 or index >= len(settings.pose_snapshots):
            self.report({'WARNING'}, sas_text("No snapshot selected.", "スナップショットが選択されていません。", context))
            add_log(context, "WARN", "Remove Pose Snapshot found no selected snapshot.", "選択中のスナップショットがないため削除を中止しました。")
            return {'CANCELLED'}
        removed_name = settings.pose_snapshots[index].name
        settings.pose_snapshots.remove(index)
        settings.pose_snapshot_index = min(max(0, index - 1), len(settings.pose_snapshots) - 1)
        self.report({'INFO'}, sas_text(f"Removed snapshot '{removed_name}'.", f"スナップショット「{removed_name}」を削除しました。", context))
        add_log(context, "INFO", f"Removed pose snapshot '{removed_name}'.", f"ポーズスナップショット「{removed_name}」を削除しました。")
        return {'FINISHED'}




class SAS_OT_export_pose_snapshots(Operator):
    bl_idname = "sas.export_pose_snapshots"
    bl_label = "Export Pose JSON"
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Export the current pose snapshots as JSON into Blender text data and copy the JSON to the clipboard.",
            "現在のポーズスナップショットを JSON として Blender テキストデータへ書き出し、同時にクリップボードへコピーします。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        if not settings.pose_snapshots:
            self.report({'WARNING'}, sas_text("No pose snapshots to export.", "書き出すポーズスナップショットがありません。", context))
            add_log(context, "WARN", "Export Pose Snapshots cancelled because there are no stored snapshots.", "保存済みスナップショットがないためポーズ JSON 書き出しを中止しました。")
            return {'CANCELLED'}
        items = []
        for item in settings.pose_snapshots:
            try:
                data = json.loads(item.data_json) if item.data_json else {}
            except Exception:
                data = {}
            items.append({"name": item.name, "data": data})
        payload = {"items": items}
        text_name = (settings.pose_snapshot_text_name or "").strip() or "Smart Animation Pose Snapshots"
        encoded = json.dumps(payload, ensure_ascii=False, indent=2)
        text_block = get_or_create_text(text_name)
        text_block.write(encoded)
        context.window_manager.clipboard = encoded
        self.report({'INFO'}, sas_text("Pose snapshots exported to Blender text data and clipboard.", "ポーズスナップショットを Blender テキストデータとクリップボードへ書き出しました。", context))
        add_log(context, "INFO", f"Exported {len(settings.pose_snapshots)} pose snapshots to '{text_name}'.", f"{len(settings.pose_snapshots)} 件のポーズスナップショットを「{text_name}」へ書き出しました。")
        return {'FINISHED'}


class SAS_OT_import_pose_snapshots(Operator):
    bl_idname = "sas.import_pose_snapshots"
    bl_label = "Import Pose JSON"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Import pose snapshots from the configured Blender text datablock and append them with unique names.",
            "設定した Blender テキストデータからポーズスナップショットを読み込み、重複しない名前で追加します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        text_name = (settings.pose_snapshot_text_name or "").strip() or "Smart Animation Pose Snapshots"
        text_block = bpy.data.texts.get(text_name)
        if text_block is None:
            self.report({'WARNING'}, sas_text("Pose snapshot text was not found.", "ポーズスナップショット用テキストが見つかりません。", context))
            add_log(context, "WARN", f"Import Pose Snapshots cancelled because text '{text_name}' was not found.", f"テキスト「{text_name}」が見つからないためポーズ JSON 読み込みを中止しました。")
            return {'CANCELLED'}
        try:
            payload = json.loads(text_block.as_string())
        except Exception as exc:
            self.report({'WARNING'}, sas_text("Pose snapshot JSON could not be parsed.", "ポーズスナップショット JSON を解析できませんでした。", context))
            add_log(context, "WARN", f"Import Pose Snapshots JSON parse failed: {exc}", f"ポーズ JSON の解析に失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}
        items = payload.get("items", []) if isinstance(payload, dict) else []
        imported = 0
        for entry in items:
            if not isinstance(entry, dict):
                continue
            name = unique_snapshot_name(context.scene, entry.get("name", "Pose"))
            data = entry.get("data", {})
            item = settings.pose_snapshots.add()
            item.name = name
            item.data_json = json.dumps(data if isinstance(data, dict) else {}, ensure_ascii=False)
            imported += 1
        if imported == 0:
            self.report({'WARNING'}, sas_text("No pose snapshots were imported.", "読み込めるポーズスナップショットがありませんでした。", context))
            add_log(context, "WARN", "Import Pose Snapshots found no valid items.", "有効なポーズスナップショットが見つからないため読み込みを中止しました。")
            return {'CANCELLED'}
        settings.pose_snapshot_index = max(0, len(settings.pose_snapshots) - imported)
        self.report({'INFO'}, sas_text(f"Imported {imported} pose snapshots.", f"{imported} 件のポーズスナップショットを読み込みました。", context))
        add_log(context, "INFO", f"Imported {imported} pose snapshots from '{text_name}'.", f"「{text_name}」から {imported} 件のポーズスナップショットを読み込みました。")
        return {'FINISHED'}


class SAS_OT_store_selection_set(Operator):
    bl_idname = "sas.store_selection_set"
    bl_label = "Store Selection Set"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Store the current object selection or the current pose-bone selection as a reusable set. This acts as a lightweight picker-style shortcut for repeated animation work.",
            "現在のオブジェクト選択、または現在のポーズボーン選択を再利用できるセットとして保存します。繰り返し作業用の軽量なピッカー風ショートカットとして使えます。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        name = unique_selection_set_name(context.scene, settings.selection_set_name.strip())

        if context.mode == 'POSE':
            obj = active_object(context)
            bones = [bone.name for bone in (context.selected_pose_bones or [])]
            if not obj or obj.type != 'ARMATURE' or not bones:
                self.report({'WARNING'}, sas_text("Select pose bones on an active armature first.", "先にアクティブなアーマチュア上でポーズボーンを選択してください。", context))
                add_log(context, "WARN", "Store Selection Set cancelled because no pose bones were selected.", "ポーズボーンが選択されていないため選択セット保存を中止しました。")
                return {'CANCELLED'}
            item = settings.selection_sets.add()
            item.name = name
            item.selection_mode = 'POSE'
            item.object_name = obj.name
            item.targets_json = json.dumps(bones, ensure_ascii=False)
        else:
            objects = [obj.name for obj in (context.selected_objects or []) if getattr(obj, 'name', None)]
            if not objects:
                self.report({'WARNING'}, sas_text("Select one or more objects first.", "先に 1 つ以上のオブジェクトを選択してください。", context))
                add_log(context, "WARN", "Store Selection Set cancelled because no objects were selected.", "オブジェクトが選択されていないため選択セット保存を中止しました。")
                return {'CANCELLED'}
            item = settings.selection_sets.add()
            item.name = name
            item.selection_mode = 'OBJECT'
            item.object_name = active_object(context).name if active_object(context) else ''
            item.targets_json = json.dumps(objects, ensure_ascii=False)

        settings.selection_set_index = len(settings.selection_sets) - 1
        self.report({'INFO'}, sas_text(f"Stored selection set '{name}'.", f"選択セット「{name}」を保存しました。", context))
        add_log(context, "INFO", f"Stored selection set '{name}'.", f"選択セット「{name}」を保存しました。")
        return {'FINISHED'}


class SAS_OT_apply_selection_set(Operator):
    bl_idname = "sas.apply_selection_set"
    bl_label = "Apply Selection Set"
    bl_options = {'UNDO'}

    set_index: IntProperty(
        name="Selection Set Index",
        description="Optional stored selection-set index to apply directly from compact picker buttons. Leave at -1 to use the current list selection.",
        default=-1,
        options={'SKIP_SAVE'},
    )

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Restore the highlighted selection set. Object sets reselect saved objects, and pose sets reactivate the saved armature and reselect its stored bones.",
            "選択中の選択セットを復元します。オブジェクトセットは保存済みオブジェクトを再選択し、ポーズセットは保存されたアーマチュアを再アクティブ化して保存ボーンを再選択します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        if not settings.selection_sets:
            self.report({'WARNING'}, sas_text("No selection sets are stored yet.", "まだ選択セットが保存されていません。", context))
            add_log(context, "WARN", "Apply Selection Set cancelled because there are no stored sets.", "保存済みセットがないため選択セット適用を中止しました。")
            return {'CANCELLED'}

        requested_index = int(self.set_index) if int(self.set_index) >= 0 else int(settings.selection_set_index)
        index = max(0, min(requested_index, len(settings.selection_sets) - 1))
        settings.selection_set_index = index
        item = settings.selection_sets[index]
        names = _selection_set_names(item)
        if not names:
            self.report({'WARNING'}, sas_text("The stored selection set is empty.", "保存された選択セットが空です。", context))
            add_log(context, "WARN", f"Selection set '{item.name}' was empty.", f"選択セット「{item.name}」は空でした。")
            return {'CANCELLED'}

        if item.selection_mode == 'POSE':
            obj = bpy.data.objects.get(item.object_name) if getattr(bpy, 'data', None) else None
            if obj is None or obj.type != 'ARMATURE':
                self.report({'WARNING'}, sas_text("The armature saved in this selection set is missing.", "この選択セットに保存されたアーマチュアが見つかりません。", context))
                add_log(context, "WARN", f"Selection set '{item.name}' could not find armature '{item.object_name}'.", f"選択セット「{item.name}」でアーマチュア「{item.object_name}」が見つかりませんでした。")
                return {'CANCELLED'}
            _deselect_all_objects(context)
            try:
                obj.select_set(True)
            except Exception:
                pass
            _set_active_object(context, obj)
            try:
                _run_op_in_area(context, lambda: bpy.ops.object.mode_set(mode='POSE'), object=obj, active_object=obj)
            except Exception:
                pass
            try:
                _run_op_in_area(context, lambda: bpy.ops.pose.select_all(action='DESELECT'), object=obj, active_object=obj)
            except Exception:
                pass
            selected = 0
            active_bone = None
            for bone_name in names:
                pose_bone = getattr(obj.pose, 'bones', {}).get(bone_name) if getattr(obj, 'pose', None) else None
                if pose_bone is None and getattr(obj, 'pose', None):
                    try:
                        pose_bone = obj.pose.bones[bone_name]
                    except Exception:
                        pose_bone = None
                if pose_bone is None:
                    continue
                try:
                    pose_bone.select = True
                    selected += 1
                    if active_bone is None:
                        active_bone = pose_bone.bone
                except Exception:
                    pass
            if active_bone is not None:
                try:
                    obj.data.bones.active = active_bone
                except Exception:
                    pass
            self.report({'INFO'}, sas_text(f"Restored pose selection set '{item.name}' with {selected} bones.", f"ポーズ選択セット「{item.name}」を復元し、{selected} 本のボーンを選択しました。", context))
            add_log(context, "INFO", f"Restored pose selection set '{item.name}' with {selected} bones.", f"ポーズ選択セット「{item.name}」を復元し、{selected} 本のボーンを選択しました。")
            return {'FINISHED'}

        _deselect_all_objects(context)
        found = 0
        first_obj = None
        objects_source = getattr(getattr(bpy, 'data', None), 'objects', None)
        for object_name in names:
            obj = objects_source.get(object_name) if objects_source and hasattr(objects_source, 'get') else None
            if obj is None:
                continue
            try:
                obj.select_set(True)
                found += 1
                if first_obj is None:
                    first_obj = obj
            except Exception:
                pass
        if first_obj is not None:
            _set_active_object(context, first_obj)
        self.report({'INFO'}, sas_text(f"Restored object selection set '{item.name}' with {found} objects.", f"オブジェクト選択セット「{item.name}」を復元し、{found} 個のオブジェクトを選択しました。", context))
        add_log(context, "INFO", f"Restored object selection set '{item.name}' with {found} objects.", f"オブジェクト選択セット「{item.name}」を復元し、{found} 個のオブジェクトを選択しました。")
        return {'FINISHED'}


class SAS_OT_remove_selection_set(Operator):
    bl_idname = "sas.remove_selection_set"
    bl_label = "Remove Selection Set"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove the highlighted reusable selection set from the current scene. This only deletes the stored shortcut, not the objects, bones, or actions themselves.",
            "現在のシーンから選択中の再利用用選択セットを削除します。削除されるのは保存済みショートカットだけで、オブジェクト、ボーン、アクション本体は消えません。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        if not settings.selection_sets:
            self.report({'WARNING'}, sas_text("No selection sets are stored yet.", "まだ選択セットが保存されていません。", context))
            add_log(context, "WARN", "Remove Selection Set cancelled because there are no stored sets.", "保存済みセットがないため選択セット削除を中止しました。")
            return {'CANCELLED'}

        index = max(0, min(settings.selection_set_index, len(settings.selection_sets) - 1))
        name = settings.selection_sets[index].name
        settings.selection_sets.remove(index)
        settings.selection_set_index = max(0, min(index, len(settings.selection_sets) - 1)) if settings.selection_sets else 0
        self.report({'INFO'}, sas_text(f"Removed selection set '{name}'.", f"選択セット「{name}」を削除しました。", context))
        add_log(context, "INFO", f"Removed selection set '{name}'.", f"選択セット「{name}」を削除しました。")
        return {'FINISHED'}


class SAS_OT_export_selection_sets(Operator):
    bl_idname = "sas.export_selection_sets"
    bl_label = "Export Selection Sets"
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Export the current reusable selection sets as JSON into Blender text data and copy the JSON to the clipboard.",
            "現在の再利用用選択セットを JSON として Blender テキストデータへ書き出し、同時にクリップボードへコピーします。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        if not settings.selection_sets:
            self.report({'WARNING'}, sas_text("No selection sets to export.", "書き出す選択セットがありません。", context))
            add_log(context, "WARN", "Export Selection Sets cancelled because there are no stored sets.", "保存済みセットがないため選択セット JSON 書き出しを中止しました。")
            return {'CANCELLED'}
        payload = {
            "items": [
                {
                    "name": item.name,
                    "selection_mode": item.selection_mode,
                    "object_name": item.object_name,
                    "targets": _selection_set_names(item),
                }
                for item in settings.selection_sets
            ]
        }
        text_name = (settings.selection_set_text_name or "").strip() or "Smart Animation Selection Sets"
        encoded = json.dumps(payload, ensure_ascii=False, indent=2)
        text_block = get_or_create_text(text_name)
        text_block.write(encoded)
        context.window_manager.clipboard = encoded
        self.report({'INFO'}, sas_text("Selection sets exported to Blender text data and clipboard.", "選択セットを Blender テキストデータとクリップボードへ書き出しました。", context))
        add_log(context, "INFO", f"Exported {len(settings.selection_sets)} selection sets to '{text_name}'.", f"{len(settings.selection_sets)} 件の選択セットを「{text_name}」へ書き出しました。")
        return {'FINISHED'}


class SAS_OT_import_selection_sets(Operator):
    bl_idname = "sas.import_selection_sets"
    bl_label = "Import Selection Sets"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Import reusable selection sets from the configured Blender text datablock and append them with unique names.",
            "設定した Blender テキストデータから再利用用選択セットを読み込み、重複しない名前で追加します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        text_name = (settings.selection_set_text_name or "").strip() or "Smart Animation Selection Sets"
        text_block = bpy.data.texts.get(text_name)
        if text_block is None:
            self.report({'WARNING'}, sas_text("Selection-set text was not found.", "選択セット用テキストが見つかりません。", context))
            add_log(context, "WARN", f"Import Selection Sets cancelled because text '{text_name}' was not found.", f"テキスト「{text_name}」が見つからないため選択セット JSON 読み込みを中止しました。")
            return {'CANCELLED'}
        try:
            payload = json.loads(text_block.as_string())
        except Exception as exc:
            self.report({'WARNING'}, sas_text("Selection-set JSON could not be parsed.", "選択セット JSON を解析できませんでした。", context))
            add_log(context, "WARN", f"Import Selection Sets JSON parse failed: {exc}", f"選択セット JSON の解析に失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}
        imported = 0
        for entry in payload.get("items", []) if isinstance(payload, dict) else []:
            if not isinstance(entry, dict):
                continue
            targets = entry.get("targets", [])
            if not isinstance(targets, list) or not targets:
                continue
            name = unique_selection_set_name(context.scene, (entry.get("name") or "Selection Set").strip())
            item = settings.selection_sets.add()
            item.name = name
            item.selection_mode = (entry.get("selection_mode") or "OBJECT").strip() or 'OBJECT'
            item.object_name = (entry.get("object_name") or "").strip()
            item.targets_json = json.dumps([str(value) for value in targets if str(value).strip()], ensure_ascii=False)
            imported += 1
        if imported == 0:
            self.report({'WARNING'}, sas_text("No selection sets were imported.", "読み込める選択セットがありませんでした。", context))
            add_log(context, "WARN", "Import Selection Sets found no valid items.", "有効な選択セットが見つからないため読み込みを中止しました。")
            return {'CANCELLED'}
        settings.selection_set_index = max(0, len(settings.selection_sets) - imported)
        self.report({'INFO'}, sas_text(f"Imported {imported} selection sets.", f"{imported} 件の選択セットを読み込みました。", context))
        add_log(context, "INFO", f"Imported {imported} selection sets from '{text_name}'.", f"「{text_name}」から {imported} 件の選択セットを読み込みました。")
        return {'FINISHED'}


class SAS_OT_new_action(Operator):
    bl_idname = "sas.new_action"
    bl_label = "New Action"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create a fresh empty action and assign it to the active object.",
            "新しい空のアクションを作成し、アクティブオブジェクトへ割り当てます。",
            context,
        )

    def execute(self, context):
        obj = active_object(context)
        if obj is None:
            self.report({'WARNING'}, sas_text("No active object.", "アクティブオブジェクトがありません。", context))
            add_log(context, "WARN", "New Action cancelled because no active object exists.", "アクティブオブジェクトがないため新規アクション作成を中止しました。")
            return {'CANCELLED'}
        anim_data = ensure_object_animation_data(obj)
        name = unique_action_name(f"{obj.name}_Action")
        action = bpy.data.actions.new(name=name)
        assign_action_to_datablock(obj, action, name_hint=obj.name)
        self.report({'INFO'}, sas_text(f"Created action '{name}'.", f"アクション「{name}」を作成しました。", context))
        add_log(context, "INFO", f"Created a new action '{name}'.", f"新しいアクション「{name}」を作成しました。")
        return {'FINISHED'}


class SAS_OT_duplicate_action(Operator):
    bl_idname = "sas.duplicate_action"
    bl_label = "Duplicate Action"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Duplicate the active action and assign the copy to the active object. Useful for safe non-destructive editing.",
            "アクティブアクションを複製し、そのコピーをアクティブオブジェクトへ割り当てます。安全な非破壊編集に便利です。",
            context,
        )

    def execute(self, context):
        obj = active_object(context)
        action = active_action(context, obj)
        if obj is None or action is None:
            self.report({'WARNING'}, sas_text("No active action to duplicate.", "複製するアクティブアクションがありません。", context))
            add_log(context, "WARN", "Duplicate Action cancelled because there is no active action.", "複製するアクティブアクションがないため中止しました。")
            return {'CANCELLED'}
        duplicate = action.copy()
        duplicate.name = unique_action_name(f"{action.name}_SAS")
        assign_action_to_datablock(obj, duplicate, name_hint=obj.name)
        self.report({'INFO'}, sas_text(f"Duplicated action as '{duplicate.name}'.", f"アクションを「{duplicate.name}」として複製しました。", context))
        add_log(context, "INFO", f"Duplicated action '{action.name}' as '{duplicate.name}'.", f"アクション「{action.name}」を「{duplicate.name}」として複製しました。")
        return {'FINISHED'}


class SAS_OT_push_action_to_nla(Operator):
    bl_idname = "sas.push_action_to_nla"
    bl_label = "Push Action to NLA"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create a new NLA track and convert the active action into a strip on that track, then clear the active action slot.",
            "新しい NLA トラックを作成し、アクティブアクションをそのトラック上のストリップへ変換した後、アクティブアクションスロットを空にします。",
            context,
        )

    def execute(self, context):
        obj = active_object(context)
        action = active_action(context, obj)
        if obj is None or action is None:
            self.report({'WARNING'}, sas_text("No active action to push.", "プッシュするアクティブアクションがありません。", context))
            add_log(context, "WARN", "Push Action to NLA cancelled because there is no active action.", "プッシュするアクティブアクションがないため中止しました。")
            return {'CANCELLED'}

        try:
            track, _strip = push_action_to_nla_strip(
                obj,
                action,
                track_name_prefix="SAS",
                blend_type=context.scene.sas_settings.nla_blend_mode,
            )
            clear_action_from_datablock(obj)
            self.report({'INFO'}, sas_text(f"Pushed '{action.name}' to NLA.", f"「{action.name}」を NLA にプッシュしました。", context))
            add_log(context, "INFO", f"Pushed action '{action.name}' to NLA track '{track.name}'.", f"アクション「{action.name}」を NLA トラック「{track.name}」へプッシュしました。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"NLA push failed: {exc}", f"NLA へのプッシュに失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Push Action to NLA failed: {exc}", f"NLA へのプッシュに失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}


class SAS_OT_build_layer_stack(Operator):
    bl_idname = "sas.build_layer_stack"
    bl_label = "Build Layer Stack"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Push the current action into NLA as a protected base layer and create a fresh editable action on top. This is a Blender-native approximation of animation-layer workflows from Maya and MotionBuilder.",
            "現在のアクションを保護用のベースレイヤーとして NLA へ退避し、その上に新しい編集用アクションを作成します。Maya や MotionBuilder のアニメーションレイヤー作業を Blender ネイティブで近似します。",
            context,
        )

    def execute(self, context):
        obj = active_object(context)
        settings = context.scene.sas_settings
        action = active_action(context, obj)
        if obj is None or action is None:
            self.report({'WARNING'}, sas_text("Select an animated object with an active action first.", "先にアクションを持つアニメーション対象オブジェクトを選択してください。", context))
            add_log(context, "WARN", "Build Layer Stack cancelled because there is no animated active object.", "アニメーション対象のアクティブオブジェクトがないためレイヤースタック作成を中止しました。")
            return {'CANCELLED'}

        anim_data = ensure_object_animation_data(obj)
        try:
            if not _action_is_in_nla(obj, action):
                push_action_to_nla_strip(obj, action, track_name_prefix="SAS_Base", blend_type='REPLACE')
            layer_base_name = settings.layer_action_name.strip() or f"{action.name}_Layer"
            new_action = bpy.data.actions.new(name=unique_action_name(layer_base_name))
            assign_action_to_datablock(obj, new_action, name_hint=obj.name)
            try:
                anim_data.action_blend_type = settings.nla_blend_mode
            except Exception:
                pass
            self.report({'INFO'}, sas_text(f"Built a layer stack and assigned editable action '{new_action.name}'.", f"レイヤースタックを作成し、編集用アクション「{new_action.name}」を割り当てました。", context))
            add_log(context, "INFO", f"Built an animation layer stack on '{obj.name}' and assigned '{new_action.name}'.", f"「{obj.name}」にアニメーションレイヤースタックを構築し、「{new_action.name}」を割り当てました。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Build Layer Stack failed: {exc}", f"レイヤースタック作成に失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Build Layer Stack failed: {exc}", f"レイヤースタック作成に失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}


class SAS_OT_add_animation_layer(Operator):
    bl_idname = "sas.add_animation_layer"
    bl_label = "Add Animation Layer"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Push the current editable action into NLA using the chosen blend mode, then create a new empty action above it. Use this to keep stacking offset or additive passes without destroying lower motion.",
            "現在の編集用アクションを選択中のブレンド方式で NLA へ送った後、その上に新しい空アクションを作成します。下層モーションを壊さず、オフセットや加算のパスを重ねていく用途に使います。",
            context,
        )

    def execute(self, context):
        obj = active_object(context)
        settings = context.scene.sas_settings
        action = active_action(context, obj)
        if obj is None or action is None:
            self.report({'WARNING'}, sas_text("No active action is available to turn into a layer.", "レイヤー化するアクティブアクションがありません。", context))
            add_log(context, "WARN", "Add Animation Layer cancelled because there is no active action.", "アクティブアクションがないためアニメーションレイヤー追加を中止しました。")
            return {'CANCELLED'}

        anim_data = ensure_object_animation_data(obj)
        try:
            track, strip = push_action_to_nla_strip(
                obj,
                action,
                track_name_prefix="SAS_Layer",
                blend_type=settings.nla_blend_mode,
            )
            layer_base_name = settings.layer_action_name.strip() or f"{action.name}_Layer"
            new_action = bpy.data.actions.new(name=unique_action_name(layer_base_name))
            assign_action_to_datablock(obj, new_action, name_hint=obj.name)
            try:
                anim_data.action_blend_type = settings.nla_blend_mode
            except Exception:
                pass
            self.report({'INFO'}, sas_text(f"Added animation layer '{new_action.name}'.", f"アニメーションレイヤー「{new_action.name}」を追加しました。", context))
            add_log(context, "INFO", f"Added animation layer '{new_action.name}' after pushing '{action.name}' to strip '{strip.name}'.", f"アクション「{action.name}」をストリップ「{strip.name}」へ送った後、アニメーションレイヤー「{new_action.name}」を追加しました。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Add Animation Layer failed: {exc}", f"アニメーションレイヤー追加に失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Add Animation Layer failed: {exc}", f"アニメーションレイヤー追加に失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}


class SAS_OT_add_camera_marker(Operator):
    bl_idname = "sas.add_camera_marker"
    bl_label = "Add Camera Marker"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create or reuse a timeline marker on the current frame and bind a camera to it. This gives you a compact camera-cut workflow inspired by camera animator and story tools.",
            "現在フレームにタイムラインマーカーを作成または再利用し、カメラをバインドします。Camera Animator や Story Tool に近い、コンパクトなカメラカット作業を行えます。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.sas_settings
        camera = _preferred_camera(context)
        if camera is None:
            self.report({'WARNING'}, sas_text("No camera is available. Select a camera or set the scene camera first.", "利用できるカメラがありません。カメラを選択するか、シーンカメラを設定してください。", context))
            add_log(context, "WARN", "Add Camera Marker cancelled because no camera is available.", "利用可能なカメラがないためカメラマーカー追加を中止しました。")
            return {'CANCELLED'}

        marker = next((item for item in scene.timeline_markers if item.frame == scene.frame_current and getattr(item, 'camera', None) == camera), None)
        if marker is None:
            base_name = settings.marker_name.strip() or camera.name
            marker = scene.timeline_markers.new(name=_unique_marker_name(scene, base_name), frame=scene.frame_current)
        try:
            marker.camera = camera
        except Exception:
            pass
        try:
            scene.camera = camera
        except Exception:
            pass
        self.report({'INFO'}, sas_text(f"Bound camera '{camera.name}' to marker '{marker.name}'.", f"カメラ「{camera.name}」をマーカー「{marker.name}」へ関連付けました。", context))
        add_log(context, "INFO", f"Bound camera '{camera.name}' to marker '{marker.name}' at frame {marker.frame}.", f"フレーム {marker.frame} のマーカー「{marker.name}」へカメラ「{camera.name}」を関連付けました。")
        return {'FINISHED'}


class SAS_OT_jump_camera_marker(Operator):
    bl_idname = "sas.jump_camera_marker"
    bl_label = "Jump Camera Marker"
    bl_options = {'UNDO'}

    direction: EnumProperty(
        name="Camera Marker Direction",
        description="Choose whether Jump Camera Marker moves backward or forward through camera-bound cut markers.",
        items=[
            ('PREV', "Previous", "Jump to the previous camera-bound marker."),
            ('NEXT', "Next", "Jump to the next camera-bound marker."),
        ],
        default='NEXT',
    )

    @classmethod
    def description(cls, context, properties):
        if properties.direction == 'PREV':
            return sas_text("Jump to the previous camera-bound marker and activate its camera.", "前のカメラ付きマーカーへ移動し、そのカメラを有効化します。", context)
        return sas_text("Jump to the next camera-bound marker and activate its camera.", "次のカメラ付きマーカーへ移動し、そのカメラを有効化します。", context)

    def execute(self, context):
        scene = context.scene
        markers = _camera_markers(scene)
        if not markers:
            self.report({'WARNING'}, sas_text("No camera-bound markers were found.", "カメラ付きマーカーが見つかりません。", context))
            add_log(context, "WARN", "Jump Camera Marker cancelled because there are no camera markers.", "カメラ付きマーカーがないため移動を中止しました。")
            return {'CANCELLED'}

        current = scene.frame_current
        if self.direction == 'PREV':
            candidates = [marker for marker in markers if marker.frame < current]
            marker = candidates[-1] if candidates else markers[-1]
        else:
            candidates = [marker for marker in markers if marker.frame > current]
            marker = candidates[0] if candidates else markers[0]

        try:
            scene.frame_set(marker.frame)
        except Exception:
            scene.frame_current = marker.frame
        if getattr(marker, 'camera', None) is not None:
            try:
                scene.camera = marker.camera
            except Exception:
                pass
        camera_name = marker.camera.name if getattr(marker, 'camera', None) is not None else "-"
        self.report({'INFO'}, sas_text(f"Jumped to marker '{marker.name}' with camera '{camera_name}'.", f"カメラ「{camera_name}」のマーカー「{marker.name}」へ移動しました。", context))

        add_log(context, "INFO", f"Jumped to camera marker '{marker.name}' on frame {marker.frame}.", f"フレーム {marker.frame} のカメラマーカー「{marker.name}」へ移動しました。")
        return {'FINISHED'}


class SAS_OT_set_preview_range_from_keys(Operator):
    bl_idname = "sas.set_preview_range_from_keys"
    bl_label = "Preview Range from Keys"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Set the scene preview range from selected keyframes. If no keys are selected, use the current action range instead.",
            "選択キーフレームからシーンのプレビュー範囲を設定します。キー選択が無い場合は現在のアクション範囲を使います。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Preview Range from Keys cancelled because there is no active action.", "アクティブアクションがないためキーからのプレビュー範囲設定を中止しました。")
            return {'CANCELLED'}

        curves = _selected_or_all_curves(context, action)
        frames = _selected_key_frames(curves)
        if frames:
            start, end = min(frames), max(frames)
            source_en = "selected keyframes"
            source_ja = "選択キーフレーム"
        else:
            start, end = get_action_frame_range(action, context.scene, obj=active_object(context))
            source_en = "the action range"
            source_ja = "アクション範囲"

        start, end = _set_scene_preview_range(context.scene, start, end)
        self.report({'INFO'}, sas_text(f"Preview range set to {start}-{end} from {source_en}.", f"{source_ja}からプレビュー範囲を {start}-{end} に設定しました。", context))
        add_log(context, "INFO", f"Set preview range to {start}-{end} from {source_en}.", f"{source_ja}からプレビュー範囲を {start}-{end} に設定しました。")
        return {'FINISHED'}


class SAS_OT_set_preview_range_from_camera_markers(Operator):
    bl_idname = "sas.set_preview_range_from_camera_markers"
    bl_label = "Shot Range"
    bl_options = {'UNDO'}

    mode: EnumProperty(
        name="Camera Range Mode",
        description="Choose whether Shot Range isolates the current shot only or spans every camera marker in the scene.",
        items=[
            ('CURRENT', "Current Shot", "Use the current camera cut and the next one."),
            ('ALL', "All Camera Marks", "Use the full span of all camera markers."),
        ],
        default='CURRENT',
    )

    @classmethod
    def description(cls, context, properties):
        if properties.mode == 'ALL':
            return sas_text("Set the scene preview range to the full span covered by camera markers.", "カメラマーカー全体がカバーする範囲にシーンのプレビュー範囲を設定します。", context)
        return sas_text("Set the scene preview range to the current camera shot, using the active cut marker and the next camera marker.", "現在のカメラショット、つまり現在のカットマーカーから次のカメラマーカーまでにプレビュー範囲を設定します。", context)

    def execute(self, context):
        scene = context.scene
        markers = _camera_markers(scene)
        if not markers:
            self.report({'WARNING'}, sas_text("No camera markers were found.", "カメラマーカーが見つかりません。", context))
            add_log(context, "WARN", "Shot Range cancelled because there are no camera markers.", "カメラマーカーがないためショット範囲設定を中止しました。")
            return {'CANCELLED'}

        markers = sorted(markers, key=lambda item: int(getattr(item, 'frame', 0)))
        if self.mode == 'ALL' or len(markers) == 1:
            start = int(markers[0].frame)
            end = int(markers[-1].frame)
            if len(markers) == 1:
                end = max(end, int(scene.frame_end))
            source_en = "camera markers"
            source_ja = "カメラマーカー"
        else:
            current = int(scene.frame_current)
            current_index = 0
            for index, marker in enumerate(markers):
                if int(marker.frame) <= current:
                    current_index = index
                else:
                    break
            current_marker = markers[current_index]
            next_marker = markers[current_index + 1] if current_index + 1 < len(markers) else None
            start = int(current_marker.frame)
            end = int(next_marker.frame) - 1 if next_marker is not None else int(scene.frame_end)
            if end < start:
                end = start
            source_en = f"camera shot '{current_marker.name}'"
            source_ja = f"カメラショット「{current_marker.name}」"

        start, end = _set_scene_preview_range(scene, start, end)
        self.report({'INFO'}, sas_text(f"Preview range set to {start}-{end} from {source_en}.", f"{source_ja}からプレビュー範囲を {start}-{end} に設定しました。", context))
        add_log(context, "INFO", f"Set preview range to {start}-{end} from {source_en}.", f"{source_ja}からプレビュー範囲を {start}-{end} に設定しました。")
        return {'FINISHED'}


class SAS_OT_set_contact_hold_range_from_keys(Operator):
    bl_idname = "sas.set_contact_hold_range_from_keys"
    bl_label = "Contact Hold Range from Keys"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Read the selected keyframes and use their first and last frames as the Contact Hold range. This is useful before applying planted-foot or fulcrum cleanup.",
            "選択中のキーフレームを読み取り、最初と最後のフレームをコンタクト保持範囲として設定します。接地足や支点クリーンアップの前準備に便利です。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        action = active_action(context)
        curves = _hold_target_curves(context, action)
        frames = _selected_key_frames(curves)
        if not frames:
            self.report({'WARNING'}, sas_text("No selected keys were found.", "選択されているキーが見つかりません。", context))
            add_log(context, "WARN", "Contact Hold Range from Keys cancelled because no selected keys were found.", "選択キーが見つからないためコンタクト保持範囲設定を中止しました。")
            return {'CANCELLED'}
        settings.contact_hold_start = int(frames[0])
        settings.contact_hold_end = int(frames[-1])
        self.report({'INFO'}, sas_text(f"Contact Hold range set to {frames[0]}-{frames[-1]}.", f"コンタクト保持範囲を {frames[0]}-{frames[-1]} に設定しました。", context))
        add_log(context, "INFO", f"Set Contact Hold range from selected keys to {frames[0]}-{frames[-1]}.", f"選択キーからコンタクト保持範囲を {frames[0]}-{frames[-1]} に設定しました。")
        return {'FINISHED'}


class SAS_OT_set_preview_range_from_sound(Operator):
    bl_idname = "sas.set_preview_range_from_sound"
    bl_label = "Sound Range"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Set the scene preview range from selected sound strips. If no sound strips are selected, use all sound strips in the sequence editor instead. This is helpful for lip-sync and dialogue review.",
            "選択中のサウンドストリップからシーンのプレビュー範囲を設定します。選択が無い場合はシーケンスエディター内の全サウンドストリップを使います。リップシンクや台詞確認に便利です。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        range_data = _sound_strip_frame_range(scene, selected_only=True)
        source_en = "selected sound strips"
        source_ja = "選択サウンドストリップ"
        if range_data is None:
            range_data = _sound_strip_frame_range(scene, selected_only=False)
            source_en = "all sound strips"
            source_ja = "全サウンドストリップ"
        if range_data is None:
            self.report({'WARNING'}, sas_text("No sound strips were found in the sequence editor.", "シーケンスエディターにサウンドストリップが見つかりません。", context))
            add_log(context, 'WARN', 'Sound Range cancelled because no sound strips were found.', 'サウンドストリップがないため Sound Range を中止しました。')
            return {'CANCELLED'}

        start, end, strips = range_data
        start, end = _set_scene_preview_range(scene, start, end)
        self.report({'INFO'}, sas_text(f"Preview range set to {start}-{end} from {source_en}.", f"{source_ja}からプレビュー範囲を {start}-{end} に設定しました。", context))
        add_log(context, 'INFO', f"Set preview range to {start}-{end} from {source_en} ({len(strips)} strips).", f"{source_ja}からプレビュー範囲を {start}-{end} に設定しました（{len(strips)} 本）。")
        return {'FINISHED'}


class SAS_OT_clear_preview_range(Operator):
    bl_idname = "sas.clear_preview_range"
    bl_label = "Clear Preview Range"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text("Disable the scene preview range and return playback to the full scene frame range.", "シーンのプレビュー範囲を無効化し、再生範囲をシーン全体へ戻します。", context)

    def execute(self, context):
        try:
            context.scene.use_preview_range = False
        except Exception:
            pass
        self.report({'INFO'}, sas_text("Preview range disabled.", "プレビュー範囲を無効化しました。", context))
        add_log(context, "INFO", "Disabled the scene preview range.", "シーンのプレビュー範囲を無効化しました。")
        return {'FINISHED'}




class SAS_OT_apply_playback_preset(Operator):
    bl_idname = "sas.apply_playback_preset"
    bl_label = "Apply Playback Preset"
    bl_options = {'UNDO'}

    preset: EnumProperty(
        name="Playback Preset",
        description="Choose a ready-made playback setup for blocking, review, or lip-sync passes so the timeline behaves the way that task needs.",
        items=(
            ('BLOCKING', "Blocking", "Blocking-friendly playback and keying settings"),
            ('REVIEW', "Review", "Shot review playback settings"),
            ('LIPSYNC', "Lip Sync", "Playback settings tuned for lip-sync review"),
        ),
        default='REVIEW',
    )

    @classmethod
    def description(cls, context, properties):
        preset = getattr(properties, 'preset', 'REVIEW')
        if preset == 'BLOCKING':
            return sas_text(
                "Switch Blender to a blocking-friendly setup: Auto Key on, preview-range off, audio scrub off, and a lightweight realtime sync mode when available.",
                "Blender をブロッキング向け設定へ切り替えます。オートキーを有効、プレビュー範囲を無効、音声スクラブを無効、可能なら軽量なリアルタイム同期へ設定します。",
                context,
            )
        if preset == 'LIPSYNC':
            return sas_text(
                "Switch Blender to a lip-sync review setup: preview-range on, Auto Key off, audio scrub on, and audio sync when Blender supports it.",
                "Blender を口パク確認向け設定へ切り替えます。プレビュー範囲を有効、オートキーを無効、音声スクラブを有効、可能なら音声同期へ設定します。",
                context,
            )
        return sas_text(
            "Switch Blender to a review-friendly setup: preview-range on, Auto Key off, audio scrub off, and a stable playback sync mode when available.",
            "Blender をレビュー向け設定へ切り替えます。プレビュー範囲を有効、オートキーを無効、音声スクラブを無効、可能なら安定した再生同期へ設定します。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        tool_settings = getattr(scene, 'tool_settings', None)
        applied = []

        def set_bool(owner, attr, value, en_label, ja_label):
            if owner is not None and hasattr(owner, attr):
                try:
                    setattr(owner, attr, value)
                    applied.append(sas_text(en_label, ja_label, context))
                    return True
                except Exception:
                    return False
            return False

        def set_enum(owner, attr, value, en_label, ja_label):
            if owner is not None and hasattr(owner, attr):
                try:
                    setattr(owner, attr, value)
                    applied.append(sas_text(en_label, ja_label, context))
                    return True
                except Exception:
                    return False
            return False

        preset = self.preset
        if preset == 'BLOCKING':
            set_bool(tool_settings, 'use_keyframe_insert_auto', True, 'Auto Key on', 'オートキー有効')
            set_bool(scene, 'use_preview_range', False, 'Preview range off', 'プレビュー範囲無効')
            set_bool(scene, 'use_audio_scrub', False, 'Audio scrub off', '音声スクラブ無効')
            set_enum(scene, 'sync_mode', 'FRAME_DROP', 'Sync = Frame Drop', '同期 = フレームドロップ')
        elif preset == 'LIPSYNC':
            set_bool(tool_settings, 'use_keyframe_insert_auto', False, 'Auto Key off', 'オートキー無効')
            set_bool(scene, 'use_preview_range', True, 'Preview range on', 'プレビュー範囲有効')
            set_bool(scene, 'use_audio_scrub', True, 'Audio scrub on', '音声スクラブ有効')
            if not set_enum(scene, 'sync_mode', 'AUDIO_SYNC', 'Sync = Audio Sync', '同期 = 音声同期'):
                set_enum(scene, 'sync_mode', 'FRAME_DROP', 'Sync = Frame Drop', '同期 = フレームドロップ')
            range_data = _sound_strip_frame_range(scene, selected_only=True) or _sound_strip_frame_range(scene, selected_only=False)
            if range_data is not None:
                start, end, strips = range_data
                start, end = _set_scene_preview_range(scene, start, end)
                applied.append(sas_text(f'Preview range = sound {start}-{end}', f'プレビュー範囲 = サウンド {start}-{end}', context))
        else:
            set_bool(tool_settings, 'use_keyframe_insert_auto', False, 'Auto Key off', 'オートキー無効')
            set_bool(scene, 'use_preview_range', True, 'Preview range on', 'プレビュー範囲有効')
            set_bool(scene, 'use_audio_scrub', False, 'Audio scrub off', '音声スクラブ無効')
            set_enum(scene, 'sync_mode', 'FRAME_DROP', 'Sync = Frame Drop', '同期 = フレームドロップ')

        if not applied:
            self.report({'WARNING'}, sas_text('Playback preset could not change any settings in this context.', 'この環境では再生プリセットが変更できる設定を見つけられませんでした。', context))
            add_log(context, 'WARN', f"Playback preset '{preset}' changed no settings.", f"再生プリセット「{preset}」で変更できる設定がありませんでした。")
            return {'CANCELLED'}

        summary_en = ', '.join(item for item in applied)
        summary_ja = '、'.join(item for item in applied)
        self.report({'INFO'}, sas_text(f"Applied playback preset: {preset.title()} ({summary_en}).", f"再生プリセットを適用しました: {preset.title()}（{summary_ja}）。", context))
        add_log(context, 'INFO', f"Applied playback preset '{preset}' with changes: {summary_en}.", f"再生プリセット「{preset}」を適用しました: {summary_ja}。")
        return {'FINISHED'}


class SAS_OT_build_bone_map(Operator):
    bl_idname = "sas.build_bone_map"
    bl_label = "Build Bone Map"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Build a practical name-based preview map from the source rig to the target rig. This inspects naming compatibility before you commit to a fuller retarget pipeline.",
            "ソースリグからターゲットリグへの実用的な名前ベース対応表を作成します。本格的なリターゲット作業の前に命名互換性を確認できます。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        source = settings.retarget_source
        target = settings.retarget_target

        if not source or source.type != 'ARMATURE':
            self.report({'WARNING'}, sas_text("Select a valid source armature.", "有効なソースアーマチュアを選択してください。", context))
            add_log(context, "WARN", "Build Bone Map cancelled because the source rig is invalid.", "ソースリグが無効なためボーン対応作成を中止しました。")
            return {'CANCELLED'}
        if not target or target.type != 'ARMATURE':
            self.report({'WARNING'}, sas_text("Select a valid target armature.", "有効なターゲットアーマチュアを選択してください。", context))
            add_log(context, "WARN", "Build Bone Map cancelled because the target rig is invalid.", "ターゲットリグが無効なためボーン対応作成を中止しました。")
            return {'CANCELLED'}
        if source == target:
            self.report({'WARNING'}, sas_text("Source and target must be different armatures.", "ソースとターゲットは別のアーマチュアである必要があります。", context))
            add_log(context, "WARN", "Build Bone Map cancelled because source and target are the same object.", "ソースとターゲットが同一のためボーン対応作成を中止しました。")
            return {'CANCELLED'}

        settings.bone_map.clear()
        target_index = build_target_name_index(
            target,
            strip_namespaces=settings.strip_namespaces,
            use_side_aliases=settings.use_side_aliases,
        )
        matched = 0

        for source_bone in source.data.bones:
            target_name, confidence, status = match_target_bone(
                source_bone.name,
                target_index,
                strip_namespaces=settings.strip_namespaces,
                use_side_aliases=settings.use_side_aliases,
            )
            item = settings.bone_map.add()
            item.source_name = source_bone.name
            item.target_name = target_name
            item.confidence = confidence
            item.status = status
            if target_name:
                matched += 1

        settings.bone_map_index = 0
        total = len(settings.bone_map)
        self.report({'INFO'}, sas_text(f"Mapped {matched}/{total} bones.", f"{matched}/{total} 本のボーンを対応付けました。", context))
        add_log(context, "INFO", f"Built bone map with {matched}/{total} matched bones.", f"{matched}/{total} 本の一致を含むボーン対応表を作成しました。")
        return {'FINISHED'}


class SAS_OT_export_bone_map(Operator):
    bl_idname = "sas.export_bone_map"
    bl_label = "Export Bone Map"
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Export the current retarget preview as JSON into the configured Blender text data-block and copy the JSON to the clipboard.",
            "現在のリターゲットプレビューを、設定した Blender テキストデータへ JSON として書き出し、同時にクリップボードにもコピーします。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        if not settings.bone_map:
            self.report({'WARNING'}, sas_text("No bone map to export.", "書き出すボーン対応表がありません。", context))
            add_log(context, "WARN", "Export Bone Map cancelled because no bone map exists.", "ボーン対応表がないため書き出しを中止しました。")
            return {'CANCELLED'}

        payload = {
            "source_rig": settings.retarget_source.name if settings.retarget_source else "",
            "target_rig": settings.retarget_target.name if settings.retarget_target else "",
            "strip_namespaces": settings.strip_namespaces,
            "use_side_aliases": settings.use_side_aliases,
            "items": [
                {
                    "source_name": item.source_name,
                    "target_name": item.target_name,
                    "confidence": round(float(item.confidence), 4),
                    "status": item.status,
                }
                for item in settings.bone_map
            ],
        }
        profile_name = (settings.retarget_profile_name or "").strip() or "SAS_Retarget_Profile"
        text_block = get_or_create_text(profile_name)
        text_block.write(json.dumps(payload, ensure_ascii=False, indent=2))
        context.window_manager.clipboard = json.dumps(payload, ensure_ascii=False)
        self.report({'INFO'}, sas_text("Bone map exported to Blender text data and clipboard.", "ボーン対応表を Blender テキストデータとクリップボードへ書き出しました。", context))
        add_log(context, "INFO", "Exported the retarget profile to Blender text data and the clipboard.", "リターゲットプロファイルを Blender テキストデータとクリップボードへ書き出しました。")
        return {'FINISHED'}


class SAS_OT_import_bone_map(Operator):
    bl_idname = "sas.import_bone_map"
    bl_label = "Import Bone Map"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Import the current retarget JSON profile from a Blender text datablock and rebuild the in-panel bone map list.",
            "Blender テキストデータから現在のリターゲット JSON プロファイルを読み込み、パネル内のボーン対応表を再構築します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        profile_name = (settings.retarget_profile_name or "").strip() or "SAS_Retarget_Profile"
        text_block = bpy.data.texts.get(profile_name)
        if text_block is None:
            self.report({'WARNING'}, sas_text("Profile text was not found.", "プロファイル用テキストが見つかりません。", context))
            add_log(context, "WARN", "Import Bone Map cancelled because the profile text was not found.", "プロファイル用テキストが見つからないためボーン対応表の読み込みを中止しました。")
            return {'CANCELLED'}

        try:
            payload = json.loads(text_block.as_string())
        except Exception as exc:
            self.report({'WARNING'}, sas_text("Profile JSON could not be parsed.", "プロファイル JSON を解析できませんでした。", context))
            add_log(context, "ERROR", f"Import Bone Map failed because JSON parsing raised: {exc}", f"JSON 解析エラーのためボーン対応表読み込みに失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}

        items = payload.get("items", [])
        if not isinstance(items, list):
            self.report({'WARNING'}, sas_text("Profile JSON does not contain an items list.", "プロファイル JSON に items リストがありません。", context))
            add_log(context, "WARN", "Import Bone Map cancelled because the JSON payload has no items list.", "JSON に items リストがないためボーン対応表の読み込みを中止しました。")
            return {'CANCELLED'}

        settings.bone_map.clear()
        imported = 0
        for data in items:
            item = settings.bone_map.add()
            item.source_name = str(data.get("source_name", ""))
            item.target_name = str(data.get("target_name", ""))
            try:
                item.confidence = max(0.0, min(1.0, float(data.get("confidence", 0.0))))
            except Exception:
                item.confidence = 0.0
            item.status = str(data.get("status", "imported"))
            imported += 1
        settings.bone_map_index = max(0, len(settings.bone_map) - 1)
        settings.strip_namespaces = bool(payload.get("strip_namespaces", settings.strip_namespaces))
        settings.use_side_aliases = bool(payload.get("use_side_aliases", settings.use_side_aliases))
        self.report({'INFO'}, sas_text(f"Imported {imported} bone-map rows from the profile text.", f"プロファイルテキストから {imported} 件のボーン対応を読み込みました。", context))
        add_log(context, "INFO", f"Imported {imported} rows from retarget profile '{profile_name}'.", f"リターゲットプロファイル「{profile_name}」から {imported} 行を読み込みました。")
        return {'FINISHED'}


class SAS_OT_create_root_motion_action(Operator):
    bl_idname = "sas.create_root_motion_action"
    bl_label = "Create Root Motion Action"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create a non-destructive copy of the current action that keeps only the configured root-motion translation curves.",
            "設定したルートモーション移動カーブだけを残した非破壊コピーアクションを作成します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        obj = active_object(context)
        action = active_action(context)
        if obj is None or action is None:
            self.report({'WARNING'}, sas_text("Select an animated object with an active action first.", "先にアクションを持つアニメーション対象オブジェクトを選択してください。", context))
            add_log(context, "WARN", "Create Root Motion Action cancelled because no animated active object is available.", "アニメーション対象のアクティブオブジェクトがないため、ルートモーションアクション作成を中止しました。")
            return {'CANCELLED'}

        axes = set(enabled_root_motion_axes(settings))
        if not axes:
            self.report({'WARNING'}, sas_text("Enable at least one root-motion axis.", "少なくとも 1 つのルートモーション軸を有効にしてください。", context))
            add_log(context, "WARN", "Create Root Motion Action cancelled because no axes were enabled.", "有効な軸がないため、ルートモーションアクション作成を中止しました。")
            return {'CANCELLED'}

        data_path = root_motion_data_path(obj, settings.root_motion_bone)
        matching = [fc for fc in iter_action_fcurves(action, datablock=obj) if fc.data_path == data_path and fc.array_index in axes]
        if not matching:
            self.report({'WARNING'}, sas_text("No matching root-motion location curves were found.", "一致するルートモーション位置カーブが見つかりません。", context))
            add_log(context, "WARN", "Create Root Motion Action cancelled because no matching root-motion curves were found.", "一致するルートモーションカーブが見つからないため、ルートモーションアクション作成を中止しました。")
            return {'CANCELLED'}

        new_action = action.copy()
        new_action.name = unique_action_name(f"{action.name}_RootMotion")
        for fc in list(iter_action_fcurves(new_action, datablock=obj)):
            keep = fc.data_path == data_path and fc.array_index in axes
            if not keep:
                remove_action_fcurve(new_action, fc, datablock=obj)
        self.report({'INFO'}, sas_text(f"Created root-motion action '{new_action.name}'.", f"ルートモーション用アクション「{new_action.name}」を作成しました。", context))
        add_log(context, "INFO", f"Created root-motion action '{new_action.name}' from '{action.name}'.", f"アクション「{action.name}」からルートモーション用アクション「{new_action.name}」を作成しました。")
        return {'FINISHED'}


class SAS_OT_create_in_place_action(Operator):
    bl_idname = "sas.create_in_place_action"
    bl_label = "Create In-Place Copy"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create a safe duplicated action and zero the configured root-motion translation curves in that copy, making an in-place version while preserving the original.",
            "元アクションを残したまま安全な複製アクションを作成し、その中で指定ルートモーション移動カーブをゼロ化してインプレース版を作成します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        obj = active_object(context)
        action = active_action(context)
        if obj is None or action is None:
            self.report({'WARNING'}, sas_text("Select an animated object with an active action first.", "先にアクションを持つアニメーション対象オブジェクトを選択してください。", context))
            add_log(context, "WARN", "Create In-Place Copy cancelled because no animated active object is available.", "アニメーション対象のアクティブオブジェクトがないため、インプレース複製作成を中止しました。")
            return {'CANCELLED'}

        axes = set(enabled_root_motion_axes(settings))
        if not axes:
            self.report({'WARNING'}, sas_text("Enable at least one root-motion axis.", "少なくとも 1 つのルートモーション軸を有効にしてください。", context))
            add_log(context, "WARN", "Create In-Place Copy cancelled because no axes were enabled.", "有効な軸がないため、インプレース複製作成を中止しました。")
            return {'CANCELLED'}

        data_path = root_motion_data_path(obj, settings.root_motion_bone)
        new_action = action.copy()
        new_action.name = unique_action_name(f"{action.name}_InPlace")
        matching = [fc for fc in iter_action_fcurves(new_action, datablock=obj) if fc.data_path == data_path and fc.array_index in axes]
        if not matching:
            bpy.data.actions.remove(new_action)
            self.report({'WARNING'}, sas_text("No matching root-motion location curves were found.", "一致するルートモーション位置カーブが見つかりません。", context))
            add_log(context, "WARN", "Create In-Place Copy cancelled because no matching root-motion curves were found.", "一致するルートモーションカーブが見つからないため、インプレース複製作成を中止しました。")
            return {'CANCELLED'}

        for fc in matching:
            for key in fc.keyframe_points:
                key.co.y = 0.0
                key.handle_left.y = 0.0
                key.handle_right.y = 0.0
            fc.update()
        assign_action_to_datablock(obj, new_action, name_hint=obj.name)
        self.report({'INFO'}, sas_text(f"Created and assigned in-place action '{new_action.name}'.", f"インプレース用アクション「{new_action.name}」を作成して割り当てました。", context))
        add_log(context, "INFO", f"Created and assigned in-place action '{new_action.name}' from '{action.name}'.", f"アクション「{action.name}」からインプレース用アクション「{new_action.name}」を作成して割り当てました。")
        return {'FINISHED'}


class SAS_OT_build_live_retarget(Operator):
    bl_idname = "sas.build_live_retarget"
    bl_label = "Live Retarget"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Rebuild the name-based bone map from the current source and target rigs, then apply a live Copy Transforms preview. Use this when rigs changed and you want a fresh preview in one click.",
            "現在のソースリグとターゲットリグから名前ベースのボーン対応を再作成し、その後でライブ Copy Transforms プレビューを適用します。リグが変わった後に、1クリックで新しいプレビューを作りたい時に使います。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        source = settings.retarget_source
        target = settings.retarget_target
        if not source or source.type != 'ARMATURE':
            self.report({'WARNING'}, sas_text("Select a valid source armature.", "有効なソースアーマチュアを選択してください。", context))
            add_log(context, 'WARN', 'Live Retarget cancelled because the source rig was invalid.', 'ソースリグが無効なためライブリターゲットを中止しました。')
            return {'CANCELLED'}
        if not target or target.type != 'ARMATURE':
            self.report({'WARNING'}, sas_text("Select a valid target armature.", "有効なターゲットアーマチュアを選択してください。", context))
            add_log(context, 'WARN', 'Live Retarget cancelled because the target rig was invalid.', 'ターゲットリグが無効なためライブリターゲットを中止しました。')
            return {'CANCELLED'}

        map_result = bpy.ops.sas.build_bone_map()
        if 'FINISHED' not in map_result:
            self.report({'WARNING'}, sas_text("Bone map rebuild did not complete.", "ボーン対応の再作成が完了しませんでした。", context))
            add_log(context, 'WARN', 'Live Retarget cancelled because the bone map rebuild did not complete.', 'ボーン対応再作成が完了しなかったためライブリターゲットを中止しました。')
            return {'CANCELLED'}

        result = bpy.ops.sas.apply_live_retarget()
        if 'FINISHED' in result:
            add_log(context, 'INFO', 'Rebuilt the bone map and applied a fresh live retarget preview.', 'ボーン対応を再作成し、新しいライブリターゲットプレビューを適用しました。')
            return {'FINISHED'}
        self.report({'WARNING'}, sas_text("Live retarget preview did not complete.", "ライブリターゲットプレビューは完了しませんでした。", context))
        add_log(context, 'WARN', 'Live retarget preview did not complete after rebuilding the bone map.', 'ボーン対応再作成後のライブリターゲットプレビューは完了しませんでした。')
        return {'CANCELLED'}




class SAS_OT_refresh_live_retarget(Operator):
    bl_idname = "sas.refresh_live_retarget"
    bl_label = "Refresh Live Retarget"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Rebuild the live retarget preview using the current bone map, influence, and space settings. This is useful after changing mappings without having to clear and reapply manually.",
            "現在のボーン対応、影響度、空間設定でライブリターゲットプレビューを再構築します。マップ変更後に、手動で解除して再適用し直す手間を減らせます。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        source = settings.retarget_source
        target = settings.retarget_target
        if not source or source.type != 'ARMATURE':
            self.report({'WARNING'}, sas_text("Select a valid source armature.", "有効なソースアーマチュアを選択してください。", context))
            add_log(context, 'WARN', 'Refresh Live Retarget cancelled because the source rig was invalid.', 'ソースリグが無効なためライブリターゲット更新を中止しました。')
            return {'CANCELLED'}
        if not target or target.type != 'ARMATURE':
            self.report({'WARNING'}, sas_text("Select a valid target armature.", "有効なターゲットアーマチュアを選択してください。", context))
            add_log(context, 'WARN', 'Refresh Live Retarget cancelled because the target rig was invalid.', 'ターゲットリグが無効なためライブリターゲット更新を中止しました。')
            return {'CANCELLED'}
        if not settings.bone_map:
            try:
                bpy.ops.sas.build_bone_map()
            except Exception:
                pass
        if not list_mapped_bone_items(settings):
            self.report({'WARNING'}, sas_text("No mapped bones are available for live retargeting.", "ライブリターゲットに使える対応ボーンがありません。", context))
            add_log(context, 'WARN', 'Refresh Live Retarget found no mapped bones.', '対応ボーンがないためライブリターゲット更新を中止しました。')
            return {'CANCELLED'}

        removed = strip_sas_retarget_constraints(target)
        result = bpy.ops.sas.apply_live_retarget()
        if 'FINISHED' in result:
            self.report({'INFO'}, sas_text(f"Refreshed the live retarget preview after removing {removed} older constraints.", f"{removed} 個の古い拘束を削除してライブリターゲットプレビューを更新しました。", context))
            add_log(context, 'INFO', f"Refreshed live retarget preview after removing {removed} older constraints.", f"{removed} 個の古い拘束を削除してライブリターゲットプレビューを更新しました。")
            return {'FINISHED'}
        self.report({'WARNING'}, sas_text("Live retarget refresh did not complete.", "ライブリターゲット更新は完了しませんでした。", context))
        add_log(context, 'WARN', 'Live retarget refresh did not complete.', 'ライブリターゲット更新は完了しませんでした。')
        return {'CANCELLED'}


class SAS_OT_auto_fix_scene_basics(Operator):
    bl_idname = "sas.auto_fix_scene_basics"
    bl_label = "Auto-Fix Basics"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create missing animation data or an action on the active object, repair an invalid preview range, and clear invalid retarget object assignments.",
            "アクティブオブジェクトに不足しているアニメーションデータやアクションを作成し、不正なプレビュー範囲を修正し、無効なリターゲット割り当てを解除します。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.sas_settings
        obj = active_object(context)
        changes = 0
        notes_en = []
        notes_ja = []

        try:
            if obj:
                anim_data = ensure_object_animation_data(obj)
                if anim_data and anim_data.action is None:
                    action = bpy.data.actions.new(name=unique_action_name(f"{obj.name}_Action"))
                    assign_action_to_datablock(obj, action, name_hint=obj.name)
                    changes += 1
                    notes_en.append(f"created action '{action.name}'")
                    notes_ja.append(f"アクション「{action.name}」を作成")

            if scene.use_preview_range and scene.frame_preview_end < scene.frame_preview_start:
                scene.frame_preview_start = scene.frame_start
                scene.frame_preview_end = scene.frame_end
                changes += 1
                notes_en.append("reset invalid preview range")
                notes_ja.append("不正なプレビュー範囲を修正")

            if settings.retarget_source and settings.retarget_source.type != 'ARMATURE':
                settings.retarget_source = None
                changes += 1
                notes_en.append("cleared invalid source rig")
                notes_ja.append("無効なソースリグ指定を解除")
            if settings.retarget_target and settings.retarget_target.type != 'ARMATURE':
                settings.retarget_target = None
                changes += 1
                notes_en.append("cleared invalid target rig")
                notes_ja.append("無効なターゲットリグ指定を解除")

            if changes == 0:
                self.report({'INFO'}, sas_text("Auto-Fix Basics found nothing to repair.", "基本自動修復で修正対象は見つかりませんでした。", context))
                add_log(context, "INFO", "Auto-Fix Basics found nothing to repair.", "基本自動修復で修正対象は見つかりませんでした。")
                return {'FINISHED'}

            message_en = "Auto-Fix Basics completed: " + ", ".join(notes_en) + "."
            message_ja = "基本自動修復を実行しました: " + "、".join(notes_ja) + "。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Auto-Fix Basics failed: {exc}", f"基本自動修復に失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Auto-Fix Basics failed: {exc}", f"基本自動修復に失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}


class SAS_OT_run_scene_audit(Operator):
    bl_idname = "sas.run_scene_audit"
    bl_label = "Run Scene Audit"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Inspect the active scene for common animation workflow issues and write the findings into the activity log.",
            "アクティブシーンにある一般的なアニメーション作業上の問題を点検し、結果をアクティビティログへ記録します。",
            context,
        )

    def execute(self, context):
        issues = collect_scene_issues(context)
        settings = context.scene.sas_settings
        settings.operation_log.clear()
        settings.operation_log_index = 0

        if not issues:
            add_log(context, "INFO", "Scene audit found no obvious issues.", "シーン監査で明確な問題は見つかりませんでした。")
            self.report({'INFO'}, sas_text("Scene audit found no obvious issues.", "シーン監査で明確な問題は見つかりませんでした。", context))
            return {'FINISHED'}

        for level, en_message, ja_message in issues:
            add_log(context, "ERROR" if level == "ERROR" else ("WARN" if level == "WARN" else "INFO"), en_message, ja_message)

        warn_count = operation_log_count(context, "WARN")
        err_count = operation_log_count(context, "ERROR")
        self.report({'INFO'}, sas_text(f"Scene audit recorded {err_count} errors and {warn_count} warnings.", f"シーン監査で {err_count} 件のエラーと {warn_count} 件の警告を記録しました。", context))
        return {'FINISHED'}


class SAS_OT_clear_operation_log(Operator):
    bl_idname = "sas.clear_operation_log"
    bl_label = "Clear Operation Log"
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Clear the in-panel operation log so you can start a fresh review.",
            "パネル内の操作ログを消去して、新しい確認を始められるようにします。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        settings.operation_log.clear()
        settings.operation_log_index = 0
        self.report({'INFO'}, sas_text("Operation log cleared.", "操作ログをクリアしました。", context))
        return {'FINISHED'}


class SAS_OT_export_report(Operator):
    bl_idname = "sas.export_report"
    bl_label = "Export Report"
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Write a scene, cleanup, and retarget summary into Blender's internal text editor as 'Smart Animation Report'.",
            "シーン、整理、リターゲットの要約を、Blender 内部テキストエディタの「Smart Animation Report」へ書き出します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        obj = active_object(context)
        action = active_action(context)
        issues = collect_scene_issues(context)
        report = get_or_create_text("Smart Animation Report")

        lines = []
        lines.append(sas_text("Smart Animation Report", "Smart Animation レポート", context))
        lines.append("=" * 32)
        lines.append(f"Scene: {context.scene.name}")
        lines.append(f"Active Object: {obj.name if obj else '-'}")
        lines.append(f"Mode: {context.mode}")
        lines.append(f"Current Action: {action.name if action else '-'}")
        lines.append(f"F-Curves: {action_curve_count(action, datablock=obj) if action else 0}")
        lines.append(f"Keyframes: {count_keyframes(action, obj=obj)}")
        lines.append(f"Timeline Markers: {len(context.scene.timeline_markers)}")
        lines.append(f"NLA Tracks: {nla_track_count(obj)}")
        lines.append(f"Stored Pose Snapshots: {len(settings.pose_snapshots)}")
        lines.append("")
        lines.append(sas_text("Cleanup Summary", "整理概要", context))
        lines.append("-" * 32)
        if action:
            summary = summarize_cleanup(action, selected_fcurves(context, action), settings.remove_threshold, settings.simplify_factor)
            lines.append(f"Preview Simplify Keys: {summary['simplify_keys']}")
            lines.append(f"Preview Duplicate Keys: {summary['duplicate_keys']}")
            lines.append(f"Preview Static Channels: {summary['static_channels']}")
        else:
            lines.append("No active action available.")
        lines.append("")
        lines.append(sas_text("Retarget Preview", "リターゲットプレビュー", context))
        lines.append("-" * 32)
        lines.append(f"Source Rig: {settings.retarget_source.name if settings.retarget_source else '-'}")
        lines.append(f"Target Rig: {settings.retarget_target.name if settings.retarget_target else '-'}")
        lines.append(f"Namespace Stripping: {settings.strip_namespaces}")
        lines.append(f"Side Aliases: {settings.use_side_aliases}")
        if settings.bone_map:
            for item in settings.bone_map:
                lines.append(f"{item.source_name} -> {item.target_name or '-'} [{int(item.confidence * 100)}% | {item.status}]")
        else:
            lines.append("No bone map built yet.")
        lines.append("")
        lines.append(sas_text("Scene Audit", "シーン監査", context))
        lines.append("-" * 32)
        if issues:
            for level, en_message, _ja_message in issues:
                lines.append(f"[{level}] {en_message}")
        else:
            lines.append("No obvious issues found.")
        lines.append("")
        lines.append(sas_text("Recent Operation Log", "最近の操作ログ", context))
        lines.append("-" * 32)
        if settings.operation_log:
            for item in settings.operation_log:
                lines.append(f"[{item.level}] {item.raw_en or item.message}")
        else:
            lines.append("No logged operations yet.")

        report.write("\n".join(lines))
        self.report({'INFO'}, sas_text("Report exported to Blender text data.", "レポートを Blender のテキストデータへ出力しました。", context))
        add_log(context, "INFO", "Exported the Smart Animation report.", "Smart Animation レポートを出力しました。")
        return {'FINISHED'}


class SAS_OT_smart_assist(Operator):
    bl_idname = "sas.smart_assist"
    bl_label = "Smart Assist"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Inspect the current context and switch the Task to the most relevant one without changing your animation data.",
            "現在の状況を確認し、アニメーションデータを変更せずに最も関連性の高いタスクへ切り替えます。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        obj = active_object(context)
        action = active_action(context)
        next_tab = 'OVERVIEW'
        legacy_tab = 'DASHBOARD'
        message_en = "Smart Assist switched the Task to Overview / Diagnostics."
        message_ja = "スマートアシストはタスクを「概要 / 診断」に切り替えました。"

        if settings.retarget_source and settings.retarget_target and (not settings.bone_map or not list_mapped_bone_items(settings)):
            next_tab = 'TRANSFER'
            legacy_tab = 'RETARGET'
            message_en = "Smart Assist switched the Task to Transfer Tools because source and target rigs are set, but the mapping is incomplete."
            message_ja = "ソースとターゲットのリグは設定されていますが対応表が不完全なため、スマートアシストはタスクを「転送ツール」に切り替えました。"
        elif obj is None:
            next_tab = 'OVERVIEW'
            legacy_tab = 'DASHBOARD'
            message_en = "Smart Assist switched the Task to Overview / Diagnostics because no active object is selected yet."
            message_ja = "アクティブオブジェクトがまだ選択されていないため、スマートアシストはタスクを「概要 / 診断」に切り替えました。"
        elif action is None:
            next_tab = 'ANIMATE'
            legacy_tab = 'QUICK'
            message_en = "Smart Assist switched the Task to Animation Tools so you can create an action and start keying."
            message_ja = "アクション作成とキー打ちを始められるよう、スマートアシストはタスクを「アニメーションツール」に切り替えました。"
        elif context.mode == 'POSE' and (settings.pose_snapshots or settings.selection_sets):
            next_tab = 'ASSETS'
            legacy_tab = 'POSE'
            message_en = "Smart Assist switched the Task to Asset Tools because pose snapshots or selection sets are likely useful in Pose Mode."
            message_ja = "ポーズモードではポーズスナップショットや選択セットが役立つため、スマートアシストはタスクを「アセットツール」に切り替えました。"
        else:
            density, density_label = get_action_density(action, obj=obj)
            if density_label in {'Dense', 'Very Dense'}:
                next_tab = 'ANIMATE'
                legacy_tab = 'CLEAN'
                message_en = f"Smart Assist switched the Task to Animation Tools because the active action is {density_label.lower()} ({density:.1f} keys per F-Curve) and the cleanup hub is there."
                message_ja = f"アクティブアクションのキーが{'非常に多い' if density_label == 'Very Dense' else '多い'}状態（F カーブあたり平均 {density:.1f} キー）で、整理ハブがアニメーションツールにあるため、スマートアシストはタスクを「アニメーションツール」に切り替えました。"
            else:
                next_tab = 'ANIMATE'
                legacy_tab = 'QUICK'
                message_en = "Smart Assist switched the Task to Animation Tools for everyday keying and timing work."
                message_ja = "日常的なキー作業とタイミング調整向けに、スマートアシストはタスクを「アニメーションツール」に切り替えました。"

        settings.compact_tab = next_tab
        settings.ui_tab = legacy_tab
        settings.compact_diag_mode = next_tab
        self.report({'INFO'}, sas_text(message_en, message_ja, context))
        add_log(context, "INFO", message_en, message_ja)
        return {'FINISHED'}


class SAS_OT_add_action_to_library(Operator):
    bl_idname = "sas.add_action_to_library"
    bl_label = "Add Current Action to Library"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Register the current active action in the internal motion library list so it can be reassigned or pushed to NLA later.",
            "現在のアクティブアクションを内部モーションライブラリ一覧へ登録し、後で再割り当てや NLA 追加に使えるようにします。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        obj = active_object(context)
        action = active_action(context)
        if action is None:
            self.report({'WARNING'}, sas_text("No active action to store.", "保存するアクティブアクションがありません。", context))
            add_log(context, "WARN", "Add Action to Library cancelled because there is no active action.", "アクティブアクションがないためライブラリ登録を中止しました。")
            return {'CANCELLED'}
        for existing in settings.action_library:
            if existing.action_name == action.name:
                self.report({'INFO'}, sas_text("That action is already in the library.", "そのアクションはすでにライブラリに登録されています。", context))
                add_log(context, "INFO", f"Action '{action.name}' was already present in the library.", f"アクション「{action.name}」はすでにライブラリに登録されています。")
                return {'CANCELLED'}
        item = settings.action_library.add()
        item.action_name = action.name
        item.source_object = obj.name if obj else ""
        item.note = f"{count_keyframes(action, obj=obj)} keys"
        settings.action_library_index = len(settings.action_library) - 1
        self.report({'INFO'}, sas_text(f"Added '{action.name}' to the motion library.", f"「{action.name}」をモーションライブラリへ追加しました。", context))
        add_log(context, "INFO", f"Added action '{action.name}' to the motion library.", f"アクション「{action.name}」をモーションライブラリへ追加しました。")
        return {'FINISHED'}


class SAS_OT_remove_action_from_library(Operator):
    bl_idname = "sas.remove_action_from_library"
    bl_label = "Remove Action from Library"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove the highlighted entry from the internal motion library list. The original Blender action data-block is not deleted.",
            "ハイライト中のエントリを内部モーションライブラリ一覧から外します。元の Blender アクションデータブロック自体は削除されません。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        index = settings.action_library_index
        if index < 0 or index >= len(settings.action_library):
            self.report({'WARNING'}, sas_text("No library action selected.", "ライブラリアクションが選択されていません。", context))
            add_log(context, "WARN", "Remove Action from Library found no selected entry.", "選択中のライブラリエントリがないため削除を中止しました。")
            return {'CANCELLED'}
        name = settings.action_library[index].action_name
        settings.action_library.remove(index)
        settings.action_library_index = min(max(0, index - 1), len(settings.action_library) - 1)
        self.report({'INFO'}, sas_text(f"Removed '{name}' from the motion library list.", f"「{name}」をモーションライブラリ一覧から削除しました。", context))
        add_log(context, "INFO", f"Removed action '{name}' from the motion library list.", f"アクション「{name}」をモーションライブラリ一覧から削除しました。")
        return {'FINISHED'}


class SAS_OT_assign_library_action(Operator):
    bl_idname = "sas.assign_library_action"
    bl_label = "Assign Library Action"
    bl_options = {'UNDO'}

    set_index: IntProperty(
        name="Library Action Index",
        description="Optional motion-library index to assign directly from compact picker buttons. Leave at -1 to use the current list selection.",
        default=-1,
        options={'SKIP_SAVE'},
    )

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Assign the highlighted library action to the active object, either as a linked original or as a duplicated editable copy.",
            "ハイライト中のライブラリアクションを、元データのままリンクするか編集用複製コピーとして、アクティブオブジェクトへ割り当てます。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        obj = active_object(context)
        requested_index = int(self.set_index) if int(self.set_index) >= 0 else int(settings.action_library_index)
        index = max(0, min(requested_index, len(settings.action_library) - 1)) if settings.action_library else -1
        settings.action_library_index = index
        if obj is None:
            self.report({'WARNING'}, sas_text("No active object.", "アクティブオブジェクトがありません。", context))
            add_log(context, "WARN", "Assign Library Action cancelled because no active object exists.", "アクティブオブジェクトがないためライブラリアクション割り当てを中止しました。")
            return {'CANCELLED'}
        if index < 0 or index >= len(settings.action_library):
            self.report({'WARNING'}, sas_text("No library action selected.", "ライブラリアクションが選択されていません。", context))
            add_log(context, "WARN", "Assign Library Action found no selected library entry.", "選択中のライブラリエントリがないため割り当てを中止しました。")
            return {'CANCELLED'}
        item = settings.action_library[index]
        action = bpy.data.actions.get(item.action_name)
        if action is None:
            self.report({'WARNING'}, sas_text("The selected library action no longer exists.", "選択中のライブラリアクションはすでに存在しません。", context))
            add_log(context, "WARN", f"Assign Library Action failed because '{item.action_name}' no longer exists.", f"「{item.action_name}」が存在しないためライブラリアクション割り当てに失敗しました。")
            return {'CANCELLED'}
        anim_data = ensure_object_animation_data(obj)
        if settings.library_assign_mode == 'COPY':
            assigned = action.copy()
            assigned.name = unique_action_name(f"{action.name}_SASLIB")
            assign_action_to_datablock(obj, assigned, name_hint=obj.name)
            name = assigned.name
            mode_text_en = "copy"
            mode_text_ja = "複製コピー"
        else:
            assign_action_to_datablock(obj, action, name_hint=obj.name)
            name = action.name
            mode_text_en = "linked original"
            mode_text_ja = "元データリンク"
        self.report({'INFO'}, sas_text(f"Assigned library action '{name}' to '{obj.name}'.", f"ライブラリアクション「{name}」を「{obj.name}」へ割り当てました。", context))
        add_log(context, "INFO", f"Assigned library action '{name}' to '{obj.name}' as a {mode_text_en}.", f"ライブラリアクション「{name}」を「{obj.name}」へ {mode_text_ja} として割り当てました。")
        return {'FINISHED'}


class SAS_OT_push_library_action_to_nla(Operator):
    bl_idname = "sas.push_library_action_to_nla"
    bl_label = "Push Library Action to NLA"
    bl_options = {'UNDO'}

    set_index: IntProperty(
        name="Library Action Index",
        description="Optional motion-library index to push directly from compact picker buttons. Leave at -1 to use the current list selection.",
        default=-1,
        options={'SKIP_SAVE'},
    )

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create a new NLA strip on the active object from the highlighted motion library action.",
            "ハイライト中のモーションライブラリアクションから、アクティブオブジェクトに新しい NLA ストリップを作成します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        obj = active_object(context)
        requested_index = int(self.set_index) if int(self.set_index) >= 0 else int(settings.action_library_index)
        index = max(0, min(requested_index, len(settings.action_library) - 1)) if settings.action_library else -1
        settings.action_library_index = index
        if obj is None:
            self.report({'WARNING'}, sas_text("No active object.", "アクティブオブジェクトがありません。", context))
            add_log(context, "WARN", "Push Library Action to NLA cancelled because no active object exists.", "アクティブオブジェクトがないためライブラリアクションの NLA 追加を中止しました。")
            return {'CANCELLED'}
        if index < 0 or index >= len(settings.action_library):
            self.report({'WARNING'}, sas_text("No library action selected.", "ライブラリアクションが選択されていません。", context))
            add_log(context, "WARN", "Push Library Action to NLA found no selected library entry.", "選択中のライブラリエントリがないため NLA 追加を中止しました。")
            return {'CANCELLED'}
        item = settings.action_library[index]
        action = bpy.data.actions.get(item.action_name)
        if action is None:
            self.report({'WARNING'}, sas_text("The selected library action no longer exists.", "選択中のライブラリアクションはすでに存在しません。", context))
            add_log(context, "WARN", f"Push Library Action to NLA failed because '{item.action_name}' no longer exists.", f"「{item.action_name}」が存在しないためライブラリアクションの NLA 追加に失敗しました。")
            return {'CANCELLED'}
        try:
            track, strip = push_action_to_nla_strip(obj, action, track_name_prefix="SAS_LIB", blend_type=context.scene.sas_settings.nla_blend_mode)
            self.report({'INFO'}, sas_text(f"Pushed library action '{action.name}' to NLA.", f"ライブラリアクション「{action.name}」を NLA に追加しました。", context))
            add_log(context, "INFO", f"Pushed library action '{action.name}' to NLA track '{track.name}'.", f"ライブラリアクション「{action.name}」を NLA トラック「{track.name}」へ追加しました。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"NLA push failed: {exc}", f"NLA 追加に失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Push Library Action to NLA failed: {exc}", f"ライブラリアクションの NLA 追加に失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}


class SAS_OT_export_library_manifest(Operator):
    bl_idname = "sas.export_library_manifest"
    bl_label = "Export Library Manifest"
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Export the current motion library list as JSON into Blender text data and copy it to the clipboard.",
            "現在のモーションライブラリ一覧を JSON として Blender テキストデータへ出力し、クリップボードにもコピーします。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        payload = {
            "items": [
                {
                    "action_name": item.action_name,
                    "source_object": item.source_object,
                    "note": item.note,
                    "exists": bpy.data.actions.get(item.action_name) is not None,
                    "key_count": count_keyframes(bpy.data.actions.get(item.action_name)),
                }
                for item in settings.action_library
            ]
        }
        text_name = (settings.library_manifest_text_name or "").strip() or "Smart Animation Motion Library"
        text_block = get_or_create_text(text_name)
        encoded = json.dumps(payload, ensure_ascii=False, indent=2)
        text_block.write(encoded)
        context.window_manager.clipboard = encoded
        self.report({'INFO'}, sas_text("Motion library manifest exported to Blender text data and clipboard.", "モーションライブラリ一覧を Blender テキストデータとクリップボードへ書き出しました。", context))
        add_log(context, "INFO", f"Exported the motion library manifest to '{text_name}'.", f"モーションライブラリ一覧を「{text_name}」へ書き出しました。")
        return {'FINISHED'}




class SAS_OT_import_library_manifest(Operator):
    bl_idname = "sas.import_library_manifest"
    bl_label = "Import Library Manifest"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Read the motion-library manifest JSON from Blender text data and rebuild matching library entries for actions that exist in the current file.",
            "Blender テキストデータからモーションライブラリ一覧 JSON を読み込み、現在のファイルに存在するアクションだけでライブラリエントリを再構築します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        text_name = (settings.library_manifest_text_name or "").strip() or "Smart Animation Motion Library"
        text_block = bpy.data.texts.get(text_name)
        if text_block is None:
            self.report({'WARNING'}, sas_text("Library manifest text was not found.", "ライブラリ一覧用テキストが見つかりません。", context))
            add_log(context, "WARN", f"Import Library Manifest cancelled because text '{text_name}' was not found.", f"テキスト「{text_name}」が見つからないためライブラリ一覧読み込みを中止しました。")
            return {'CANCELLED'}
        try:
            payload = json.loads(text_block.as_string())
        except Exception as exc:
            self.report({'WARNING'}, sas_text("Library manifest JSON could not be parsed.", "ライブラリ一覧 JSON を解析できませんでした。", context))
            add_log(context, "WARN", f"Import Library Manifest JSON parse failed: {exc}", f"ライブラリ一覧 JSON の解析に失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}
        imported = 0
        updated = 0
        missing = 0
        for entry in payload.get("items", []) if isinstance(payload, dict) else []:
            if not isinstance(entry, dict):
                continue
            action_name = (entry.get("action_name") or "").strip()
            if not action_name:
                continue
            action = bpy.data.actions.get(action_name)
            if action is None:
                missing += 1
                continue
            item = None
            for existing in settings.action_library:
                if existing.action_name == action_name:
                    item = existing
                    break
            if item is None:
                item = settings.action_library.add()
                imported += 1
            else:
                updated += 1
            item.action_name = action_name
            item.source_object = entry.get("source_object", getattr(action, "name", ""))
            item.note = entry.get("note", "")
        if imported == 0 and updated == 0 and missing == 0:
            self.report({'WARNING'}, sas_text("No valid library entries were found.", "有効なライブラリエントリが見つかりませんでした。", context))
            add_log(context, "WARN", "Import Library Manifest found no valid entries.", "有効なライブラリエントリが見つからないため読み込みを中止しました。")
            return {'CANCELLED'}
        self.report({'INFO'}, sas_text(f"Imported {imported} and refreshed {updated} library entries. Missing actions skipped: {missing}.", f"{imported} 件を追加し、{updated} 件を更新しました。存在しないアクションは {missing} 件スキップしました。", context))
        add_log(context, "INFO", f"Imported {imported} and refreshed {updated} library entries from '{text_name}'. Missing actions skipped: {missing}.", f"「{text_name}」から {imported} 件を追加し、{updated} 件を更新しました。存在しないアクションは {missing} 件スキップしました。")
        return {'FINISHED'}


class SAS_OT_prune_action_library(Operator):
    bl_idname = "sas.prune_action_library"
    bl_label = "Prune Missing Entries"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove duplicate or missing motion-library entries so the library stays compact and predictable.",
            "重複または欠損したモーションライブラリエントリを削除し、一覧をコンパクトで分かりやすい状態に保ちます。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        keep = []
        seen = set()
        removed = 0
        for item in settings.action_library:
            action_name = (item.action_name or "").strip()
            if not action_name or action_name in seen or bpy.data.actions.get(action_name) is None:
                removed += 1
                continue
            seen.add(action_name)
            keep.append((action_name, item.source_object, item.note))
        while len(settings.action_library):
            settings.action_library.remove(0)
        for action_name, source_object, note in keep:
            item = settings.action_library.add()
            item.action_name = action_name
            item.source_object = source_object
            item.note = note
        settings.action_library_index = min(settings.action_library_index, max(0, len(settings.action_library) - 1))
        self.report({'INFO'}, sas_text(f"Pruned {removed} motion-library entries.", f"{removed} 件のモーションライブラリエントリを整理しました。", context))
        add_log(context, "INFO", f"Pruned {removed} motion-library entries.", f"{removed} 件のモーションライブラリエントリを整理しました。")
        return {'FINISHED'}


class SAS_OT_apply_live_retarget(Operator):
    bl_idname = "sas.apply_live_retarget"
    bl_label = "Apply Live Retarget"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create live copy-transform constraints on the target rig from the current bone map so you can preview retargeting before baking.",
            "現在のボーン対応表を使ってターゲットリグにライブの Copy Transforms 拘束を作成し、ベイク前にリターゲット結果をプレビューできるようにします。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        source = settings.retarget_source
        target = settings.retarget_target
        if not source or source.type != 'ARMATURE':
            self.report({'WARNING'}, sas_text("Select a valid source armature.", "有効なソースアーマチュアを選択してください。", context))
            add_log(context, "WARN", "Apply Live Retarget cancelled because the source rig is invalid.", "ソースリグが無効なためライブリターゲット適用を中止しました。")
            return {'CANCELLED'}
        if not target or target.type != 'ARMATURE':
            self.report({'WARNING'}, sas_text("Select a valid target armature.", "有効なターゲットアーマチュアを選択してください。", context))
            add_log(context, "WARN", "Apply Live Retarget cancelled because the target rig is invalid.", "ターゲットリグが無効なためライブリターゲット適用を中止しました。")
            return {'CANCELLED'}
        if not settings.bone_map:
            bpy.ops.sas.build_bone_map()
        if not list_mapped_bone_items(settings):
            self.report({'WARNING'}, sas_text("No mapped bones are available for live retargeting.", "ライブリターゲットに使える対応ボーンがありません。", context))
            add_log(context, "WARN", "Apply Live Retarget found no mapped bones.", "対応ボーンがないためライブリターゲット適用を中止しました。")
            return {'CANCELLED'}

        if settings.retarget_replace_existing:
            removed = strip_sas_retarget_constraints(target)
            if removed:
                add_log(context, "INFO", f"Removed {removed} older Smart Animation retarget constraints before applying a new preview.", f"新しいプレビュー適用前に {removed} 個の古い Smart Animation リターゲット拘束を削除しました。")
        applied = 0
        failed = 0
        for item in list_mapped_bone_items(settings):
            source_bone = source.pose.bones.get(item.source_name) if getattr(source, 'pose', None) else None
            target_bone = target.pose.bones.get(item.target_name) if getattr(target, 'pose', None) else None
            if source_bone is None or target_bone is None:
                failed += 1
                continue
            try:
                expected_name = f"SAS_RETARGET_{item.source_name}__{item.target_name}"
                constraint = next((con for con in target_bone.constraints if is_sas_retarget_constraint(con) and getattr(con, 'subtarget', '') == item.source_name), None)
                if constraint is None:
                    constraint = target_bone.constraints.new(type='COPY_TRANSFORMS')
                constraint.name = expected_name
                constraint.target = source
                constraint.subtarget = item.source_name
                if hasattr(constraint, 'mix_mode'):
                    try:
                        constraint.mix_mode = 'REPLACE'
                    except Exception:
                        pass
                try:
                    constraint.target_space = settings.retarget_space
                    constraint.owner_space = settings.retarget_space
                except Exception:
                    pass
                try:
                    constraint.influence = settings.retarget_constraint_influence
                except Exception:
                    pass
                applied += 1
            except Exception:
                failed += 1

        self.report({'INFO'}, sas_text(f"Applied {applied} live retarget constraints.", f"{applied} 個のライブリターゲット拘束を適用しました。", context))
        add_log(context, "INFO", f"Applied {applied} live retarget constraints with {failed} failures.", f"{applied} 個のライブリターゲット拘束を適用し、{failed} 件失敗しました。")
        return {'FINISHED'}


class SAS_OT_clear_live_retarget(Operator):
    bl_idname = "sas.clear_live_retarget"
    bl_label = "Clear Live Retarget"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove Smart Animation live retarget constraints from the target rig without touching other user constraints.",
            "Smart Animation のライブリターゲット拘束だけをターゲットリグから削除し、他のユーザー拘束には触れません。",
            context,
        )

    def execute(self, context):
        target = context.scene.sas_settings.retarget_target
        if not target or target.type != 'ARMATURE':
            self.report({'WARNING'}, sas_text("Select a valid target armature.", "有効なターゲットアーマチュアを選択してください。", context))
            add_log(context, "WARN", "Clear Live Retarget cancelled because the target rig is invalid.", "ターゲットリグが無効なためライブリターゲット解除を中止しました。")
            return {'CANCELLED'}
        removed = strip_sas_retarget_constraints(target)
        self.report({'INFO'}, sas_text(f"Removed {removed} live retarget constraints.", f"{removed} 個のライブリターゲット拘束を削除しました。", context))
        add_log(context, "INFO", f"Removed {removed} live retarget constraints.", f"{removed} 個のライブリターゲット拘束を削除しました。")
        return {'FINISHED'}


class SAS_OT_bake_live_retarget(Operator):
    bl_idname = "sas.bake_live_retarget"
    bl_label = "Bake Live Retarget"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Bake the active Smart Animation live retarget preview on the target rig into regular keys over the chosen frame range.",
            "有効な Smart Animation ライブリターゲットプレビューを、選択したフレーム範囲で通常キーとしてターゲットリグへベイクします。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        target = settings.retarget_target
        if not target or target.type != 'ARMATURE':
            self.report({'WARNING'}, sas_text("Select a valid target armature.", "有効なターゲットアーマチュアを選択してください。", context))
            add_log(context, "WARN", "Bake Live Retarget cancelled because the target rig is invalid.", "ターゲットリグが無効なためライブリターゲットベイクを中止しました。")
            return {'CANCELLED'}
        live_count = count_sas_retarget_constraints(target)
        if live_count == 0:
            self.report({'WARNING'}, sas_text("No live retarget constraints are active on the target rig.", "ターゲットリグに有効なライブリターゲット拘束がありません。", context))
            add_log(context, "WARN", "Bake Live Retarget found no active live retarget constraints.", "有効なライブリターゲット拘束がないためベイクを中止しました。")
            return {'CANCELLED'}

        scene = context.scene
        start, end = get_bake_range(scene, settings)
        original_frame = scene.frame_current
        action = get_or_create_action_for_object(target, base_name=f"{target.name}_Retarget")
        key_paths = 0

        constrained_bones = []
        for bone in target.pose.bones:
            if any(is_sas_retarget_constraint(constraint) for constraint in bone.constraints):
                constrained_bones.append(bone)
        if not constrained_bones:
            self.report({'WARNING'}, sas_text("No constrained bones were found on the target rig.", "ターゲットリグに制約付きボーンが見つかりませんでした。", context))
            add_log(context, "WARN", "Bake Live Retarget found no constrained bones on the target rig.", "ターゲットリグに制約付きボーンが見つからないためライブリターゲットベイクを中止しました。")
            return {'CANCELLED'}
        ensure_action_backup(context, "retarget_bake", obj=target)

        try:
            for frame in range(start, end + 1, max(1, settings.frame_step)):
                scene.frame_set(frame)
                for bone in constrained_bones:
                    for path in ("location", "rotation_quaternion" if bone.rotation_mode == 'QUATERNION' else ("rotation_axis_angle" if bone.rotation_mode == 'AXIS_ANGLE' else "rotation_euler"), "scale"):
                        try:
                            bone.keyframe_insert(data_path=path, frame=frame, options={"INSERTKEY_VISUAL"})
                        except Exception:
                            bone.keyframe_insert(data_path=path, frame=frame)
                        key_paths += 1
            if settings.clear_constraints_after_bake:
                removed = strip_sas_retarget_constraints(target)
                add_log(context, "INFO", f"Removed {removed} live retarget constraints after bake.", f"ベイク後に {removed} 個のライブリターゲット拘束を削除しました。")
            self.report({'INFO'}, sas_text(f"Baked live retarget into action '{action.name}'.", f"ライブリターゲットをアクション「{action.name}」へベイクしました。", context))
            add_log(context, "INFO", f"Baked live retarget on '{target.name}' over frames {start}-{end} with {key_paths} keyed paths.", f"「{target.name}」に対してフレーム {start}-{end} へライブリターゲットをベイクし、{key_paths} 個のキーパスを記録しました。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Live retarget bake failed: {exc}", f"ライブリターゲットベイクに失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Bake Live Retarget failed: {exc}", f"ライブリターゲットベイクに失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}
        finally:
            scene.frame_set(original_frame)





def _selected_or_all_curves(context, action):
    curves = selected_fcurves(context, action)
    if curves:
        return curves
    settings = context.scene.sas_settings
    return filter_editable_fcurves(iter_action_fcurves(action, datablock=active_object(context)), settings)


def _shape_key_curves(context, obj):
    curves = iter_shape_key_fcurves(obj, create=False)
    settings = context.scene.sas_settings
    if settings.only_selected_curves:
        selected = [fcurve for fcurve in curves if getattr(fcurve, "select", False)]
        if selected:
            return filter_editable_fcurves(selected, settings)
    return filter_editable_fcurves(curves, settings)


def _apply_snapshot_payload(armature_obj, payload, blend_factor=1.0):
    applied = 0
    blend_factor = max(0.0, min(1.0, float(blend_factor)))
    for bone_name, data in payload.items():
        bone = armature_obj.pose.bones.get(bone_name)
        if bone is None:
            continue
        current_loc = bone.location
        target_loc = list(data['location']) if 'location' in data else list(current_loc)
        bone.location = [current_loc[i] + (target_loc[i] - current_loc[i]) * blend_factor for i in range(3)]

        target_mode = data.get('rotation_mode', bone.rotation_mode)
        if target_mode == 'QUATERNION':
            try:
                current_quaternion = bone.rotation_quaternion
                current_q = Quaternion(current_quaternion)
                target_q = Quaternion(data['rotation']) if 'rotation' in data else Quaternion(current_quaternion)
                bone.rotation_mode = 'QUATERNION'
                bone.rotation_quaternion = current_q.slerp(target_q, blend_factor)
            except Exception:
                current_quaternion = bone.rotation_quaternion
                target_rot = list(data['rotation']) if 'rotation' in data else list(current_quaternion)
                bone.rotation_quaternion = [current_quaternion[i] + (target_rot[i] - current_quaternion[i]) * blend_factor for i in range(4)]
        elif target_mode == 'AXIS_ANGLE':
            current_axis_angle = bone.rotation_axis_angle
            target_rot = list(data['rotation']) if 'rotation' in data else list(current_axis_angle)
            bone.rotation_mode = 'AXIS_ANGLE'
            bone.rotation_axis_angle = [current_axis_angle[i] + (target_rot[i] - current_axis_angle[i]) * blend_factor for i in range(4)]
        else:
            current_euler = bone.rotation_euler
            target_rot = list(data['rotation']) if 'rotation' in data else list(current_euler)
            bone.rotation_mode = target_mode
            bone.rotation_euler = [current_euler[i] + (target_rot[i] - current_euler[i]) * blend_factor for i in range(3)]

        current_scale = bone.scale
        target_scale = list(data['scale']) if 'scale' in data else list(current_scale)
        bone.scale = [current_scale[i] + (target_scale[i] - current_scale[i]) * blend_factor for i in range(3)]
        applied += 1
    return applied


def _set_constraint_influence_key(context, owner, constraint, frame, value):
    constraint.influence = value
    constraint.keyframe_insert(data_path='influence', frame=frame)
    try:
        action = active_action(context, active_object(context) if context.mode == 'POSE' else owner)
        if action is not None:
            fcurve = find_action_fcurve(action, active_object(context) if context.mode == 'POSE' else owner, constraint.path_from_id('influence'))
            if fcurve is not None:
                set_key_interpolation_at_frame(fcurve, frame, 'CONSTANT')
    except Exception:
        pass


def _cascade_curve_groups(context, action):
    def bone_depth(bone):
        depth = 0
        current = getattr(bone, 'parent', None)
        while current is not None:
            depth += 1
            current = getattr(current, 'parent', None)
        return depth

    if context.mode == 'POSE' and getattr(context, 'selected_pose_bones', None):
        bones = list(context.selected_pose_bones)
        bones.sort(key=bone_depth)
        groups = []
        for bone in bones:
            prefix = f'pose.bones["{bone.name}"].'
            curves = [fc for fc in iter_action_fcurves(action, datablock=active_object(context)) if fc.data_path.startswith(prefix)]
            if curves:
                groups.append((bone.name, curves))
        return groups
    return [(active_object(context).name if active_object(context) else 'Action', _selected_or_all_curves(context, action))]



def _overlap_curve_groups(context, action):
    groups = _cascade_curve_groups(context, action)
    if len(groups) == 1:
        label, curves = groups[0]
        if len(curves) > 1:
            return [(f"{label}:{index + 1}", [curve]) for index, curve in enumerate(curves)]
    return groups


def _target_curves_for_action(context, action, target_obj):
    return iter_action_fcurves(action, datablock=target_obj) if target_obj is not None else _selected_or_all_curves(context, action)


def _collect_euler_fcurves(context, action, target_obj=None):
    curves = _target_curves_for_action(context, action, target_obj)
    return [fcurve for fcurve in curves if is_rotation_euler_data_path(getattr(fcurve, "data_path", ""))]


def _apply_noise_to_curves(curves, strength, scale, phase, depth):
    affected = 0
    for fcurve in curves:
        modifier = next((mod for mod in fcurve.modifiers if mod.name.startswith('SAS_NOISE')), None)
        if modifier is None:
            modifier = fcurve.modifiers.new(type='NOISE')
        modifier.name = 'SAS_NOISE'
        for attr, value in (('strength', strength), ('scale', scale), ('phase', phase), ('depth', depth)):
            try:
                setattr(modifier, attr, value)
            except Exception:
                pass
        affected += 1
    return affected


CAMERA_SHAKE_BASE_KEYS_PROP = "sas_camera_shake_base_keys"
CAMERA_SHAKE_CHANNEL_PHASE_STEP = 7.31


def _remove_camera_shake_base_curves(camera_obj, action):
    # Only the single holding keys that Apply Camera Shake added itself are removed.
    base_keys = set(str(camera_obj.get(CAMERA_SHAKE_BASE_KEYS_PROP, "")).split(";")) - {""}
    for fcurve in list(iter_action_fcurves(action, datablock=camera_obj)):
        if f"{fcurve.data_path}:{fcurve.array_index}" in base_keys and len(fcurve.keyframe_points) <= 1 and len(fcurve.modifiers) == 0:
            # The property still holds the last evaluated noisy value; return it to the held value.
            if len(fcurve.keyframe_points) == 1:
                getattr(camera_obj, fcurve.data_path)[fcurve.array_index] = fcurve.keyframe_points[0].co.y
            remove_action_fcurve(action, fcurve, datablock=camera_obj)
    if CAMERA_SHAKE_BASE_KEYS_PROP in camera_obj:
        del camera_obj[CAMERA_SHAKE_BASE_KEYS_PROP]


def _clear_noise_from_curves(curves):
    removed = 0
    for fcurve in curves:
        removed += remove_sas_modifiers(fcurve, 'SAS_NOISE')
    return removed


def _action_is_in_nla(obj, action):
    anim_data = getattr(obj, 'animation_data', None)
    if anim_data is None or action is None:
        return False
    for track in getattr(anim_data, 'nla_tracks', []):
        for strip in getattr(track, 'strips', []):
            if getattr(strip, 'action', None) == action:
                return True
    return False


def _preferred_camera(context):
    obj = active_object(context)
    if obj is not None and getattr(obj, 'type', None) == 'CAMERA':
        return obj
    scene_camera = getattr(context.scene, 'camera', None)
    if scene_camera is not None and getattr(scene_camera, 'type', None) == 'CAMERA':
        return scene_camera
    for candidate in getattr(context.scene, 'objects', []):
        if getattr(candidate, 'type', None) == 'CAMERA':
            return candidate
    return None


def _camera_markers(scene):
    markers = [marker for marker in scene.timeline_markers if getattr(marker, 'camera', None) is not None]
    markers.sort(key=lambda marker: (marker.frame, marker.name))
    return markers


def _unique_marker_name(scene, base_name):
    existing = {marker.name for marker in scene.timeline_markers}
    name = base_name or "SAS Marker"
    if name not in existing:
        return name
    index = 1
    while f"{name}_{index:02d}" in existing:
        index += 1
    return f"{name}_{index:02d}"


def _world_position_for_trail(context):
    if context.mode == 'POSE' and getattr(context, 'active_pose_bone', None) is not None:
        arm = active_object(context)
        if arm is not None:
            bone = context.active_pose_bone
            return (arm.matrix_world @ bone.matrix).translation.copy()
    obj = active_object(context)
    if obj is None:
        return None
    return obj.matrix_world.translation.copy()


def _trail_source_label(context):
    if context.mode == 'POSE' and getattr(context, 'active_pose_bone', None) is not None and active_object(context) is not None:
        return f"{active_object(context).name}_{context.active_pose_bone.name}"
    obj = active_object(context)
    return obj.name if obj is not None else "Trail"


def _remove_sas_trail_objects(scene):
    removed = 0
    for obj in list(bpy.data.objects):
        try:
            is_trail = bool(obj.get("sas_trail"))
        except Exception:
            is_trail = False
        if not is_trail:
            continue
        curve_data = getattr(obj, "data", None)
        bpy.data.objects.remove(obj, do_unlink=True)
        if curve_data is not None and getattr(curve_data, "users", 0) == 0:
            try:
                bpy.data.curves.remove(curve_data)
            except Exception:
                pass
        removed += 1
    return removed


def _ghost_collection(scene, ensure=False):
    name = "SAS_Ghosts"
    collection = bpy.data.collections.get(name)
    if collection is None and ensure:
        collection = bpy.data.collections.new(name)
        try:
            scene.collection.children.link(collection)
        except Exception:
            pass
    return collection


def _deduplicated_objects(objects):
    result = []
    seen = set()
    for obj in objects or []:
        if obj is None:
            continue
        key = getattr(obj, "name_full", None) or getattr(obj, "name", None) or id(obj)
        if key in seen:
            continue
        seen.add(key)
        result.append(obj)
    return result


def _ghost_source_objects(context):
    selected = list(getattr(context, "selected_objects", []) or [])
    if context.mode == 'POSE' and active_object(context) is not None:
        selected = [active_object(context)] + selected
    if not selected and active_object(context) is not None:
        selected = [active_object(context)]

    expanded = []
    for obj in selected:
        if obj is None:
            continue
        if getattr(obj, "type", None) == 'ARMATURE':
            child_meshes = []
            for child in getattr(obj, "children_recursive", []) or []:
                if getattr(child, "type", None) == 'MESH':
                    child_meshes.append(child)
            if child_meshes:
                expanded.extend(child_meshes)
            else:
                expanded.append(obj)
        else:
            expanded.append(obj)
    return _deduplicated_objects(expanded)


def _remove_sas_ghost_objects(scene):
    removed = 0
    collection = _ghost_collection(scene, ensure=False)
    for obj in list(bpy.data.objects):
        try:
            is_ghost = bool(obj.get("sas_ghost"))
        except Exception:
            is_ghost = False
        if not is_ghost:
            continue
        data_block = getattr(obj, "data", None)
        bpy.data.objects.remove(obj, do_unlink=True)
        if data_block is not None and getattr(data_block, "users", 0) == 0:
            try:
                if hasattr(bpy.data, "meshes") and data_block.__class__.__name__ == 'Mesh':
                    bpy.data.meshes.remove(data_block)
                elif hasattr(bpy.data, "curves") and data_block.__class__.__name__ == 'Curve':
                    bpy.data.curves.remove(data_block)
                elif hasattr(bpy.data, "cameras") and data_block.__class__.__name__ == 'Camera':
                    bpy.data.cameras.remove(data_block)
            except Exception:
                pass
        removed += 1
    if collection is not None and not list(getattr(collection, "objects", []) or []):
        try:
            bpy.data.collections.remove(collection)
        except Exception:
            pass
    return removed


def _ballistic_collection(scene, ensure=False):
    name = "SAS_Ballistics"
    collection = bpy.data.collections.get(name)
    if collection is None and ensure:
        collection = bpy.data.collections.new(name)
        try:
            scene.collection.children.link(collection)
        except Exception:
            pass
    return collection


def _remove_sas_ballistic_objects(scene):
    removed = 0
    collection = _ballistic_collection(scene, ensure=False)
    for obj in list(bpy.data.objects):
        try:
            is_ballistic = bool(obj.get("sas_ballistic"))
        except Exception:
            is_ballistic = False
        if not is_ballistic:
            continue
        data_block = getattr(obj, "data", None)
        bpy.data.objects.remove(obj, do_unlink=True)
        if data_block is not None and getattr(data_block, "users", 0) == 0:
            try:
                bpy.data.curves.remove(data_block)
            except Exception:
                pass
        removed += 1
    if collection is not None and not list(getattr(collection, "objects", []) or []):
        try:
            bpy.data.collections.remove(collection)
        except Exception:
            pass
    return removed


def _ballistic_source(context):
    if context.mode == 'POSE' and getattr(context, 'active_pose_bone', None) is not None and active_object(context) is not None:
        armature_obj = active_object(context)
        bone_name = context.active_pose_bone.name
        return 'POSE_BONE', armature_obj, bone_name, f"{armature_obj.name}_{bone_name}"
    obj = active_object(context)
    if obj is None:
        return None, None, None, None
    return 'OBJECT', obj, None, obj.name


def _sample_source_world_position(depsgraph, source_kind, source_obj, bone_name=None):
    if source_obj is None:
        return None
    try:
        source_eval = source_obj.evaluated_get(depsgraph)
    except Exception:
        source_eval = source_obj
    if source_kind == 'POSE_BONE':
        pose = getattr(source_eval, 'pose', None)
        bone = pose.bones.get(bone_name) if pose is not None else None
        if bone is None:
            return None
        try:
            return (source_eval.matrix_world @ bone.matrix).translation.copy()
        except Exception:
            return None
    try:
        return source_eval.matrix_world.translation.copy()
    except Exception:
        return None


def _ballistic_frame_range(context, action):
    scene = context.scene
    settings = scene.sas_settings
    if settings.retime_use_range:
        start = settings.retime_range_start
        end = settings.retime_range_end
    elif action is not None:
        start, end = get_action_frame_range(action, scene=scene, obj=active_object(context))
    elif getattr(scene, 'use_preview_range', False):
        start = scene.frame_preview_start
        end = scene.frame_preview_end
    else:
        start = scene.frame_start
        end = scene.frame_end
    start, end = sorted((int(math.floor(start)), int(math.ceil(end))))
    if end <= start:
        end = start + max(1, int(settings.ballistic_step))
    return start, end



def _ballistic_location_path(source_kind, bone_name=None):
    if source_kind == 'POSE_BONE' and bone_name:
        return f'pose.bones["{bone_name}"].location'
    return 'location'



def _remove_location_keys_in_range(action, datablock, data_path, start, end):
    removed = 0
    for fcurve in iter_action_fcurves(action, datablock=datablock):
        if getattr(fcurve, 'data_path', '') != data_path or getattr(fcurve, 'array_index', -1) not in {0, 1, 2}:
            continue
        removed += safe_remove_keyframe_points(fcurve, key_indices_in_range(fcurve, start, end))
    return removed


def _hold_target_curves(context, action):
    obj = active_object(context)
    settings = context.scene.sas_settings
    if context.mode == 'POSE' and getattr(context, 'selected_pose_bones', None) and obj is not None:
        prefixes = [f'pose.bones["{bone.name}"].' for bone in context.selected_pose_bones]
        curves = [
            fcurve for fcurve in iter_action_fcurves(action, datablock=obj)
            if any(getattr(fcurve, 'data_path', '').startswith(prefix) for prefix in prefixes)
        ]
        if settings.only_selected_curves:
            selected = [fcurve for fcurve in curves if getattr(fcurve, 'select', False)]
            if selected:
                curves = selected
        if curves:
            return curves
    return _selected_or_all_curves(context, action)


def _make_sas_ghost_object(context, source_obj, frame):
    scene = context.scene
    depsgraph = context.evaluated_depsgraph_get()
    source_eval = source_obj.evaluated_get(depsgraph)
    name = unique_action_name(f"SAS_Ghost_{source_obj.name}_{int(frame)}")
    ghost_object = None

    if getattr(source_obj, "type", None) == 'MESH':
        mesh_data = None
        try:
            mesh_data = bpy.data.meshes.new_from_object(source_eval, preserve_all_data_layers=False, depsgraph=depsgraph)
        except Exception:
            mesh_data = None
        if mesh_data is not None:
            ghost_object = bpy.data.objects.new(name, mesh_data)

    if ghost_object is None:
        try:
            ghost_object = source_obj.copy()
            if getattr(source_obj, "data", None) is not None:
                try:
                    ghost_object.data = source_obj.data.copy()
                except Exception:
                    ghost_object.data = source_obj.data
        except Exception:
            return None

    try:
        ghost_object.animation_data_clear()
    except Exception:
        pass

    try:
        ghost_object.matrix_world = source_eval.matrix_world.copy()
    except Exception:
        pass

    ghost_object["sas_ghost"] = True
    ghost_object["sas_ghost_frame"] = int(frame)
    ghost_object.hide_render = True
    ghost_object.hide_select = True
    try:
        ghost_object.display_type = 'WIRE'
    except Exception:
        pass
    try:
        ghost_object.show_in_front = True
    except Exception:
        pass

    collection = _ghost_collection(scene, ensure=True)
    linked = False
    if collection is not None:
        try:
            collection.objects.link(ghost_object)
            linked = True
        except Exception:
            linked = False
    if not linked:
        try:
            scene.collection.objects.link(ghost_object)
        except Exception:
            return None
    return ghost_object


def _find_sas_cycles_modifier(fcurve):
    return next((mod for mod in getattr(fcurve, "modifiers", []) if getattr(mod, "name", "") == "SAS_CYCLES"), None)


def _clear_sas_cycles_from_curves(curves):
    removed = 0
    for fcurve in curves:
        for modifier in list(getattr(fcurve, "modifiers", [])):
            if getattr(modifier, "name", "") == "SAS_CYCLES":
                try:
                    fcurve.modifiers.remove(modifier)
                    removed += 1
                except Exception:
                    pass
    return removed


def _camera_target_object(context):
    obj = active_object(context)
    if obj is not None and getattr(obj, "type", None) == 'CAMERA':
        return obj
    scene_camera = getattr(context.scene, "camera", None)
    if scene_camera is not None and getattr(scene_camera, "type", None) == 'CAMERA':
        return scene_camera
    return None


def _camera_shake_values(preset):
    preset = (preset or 'SUBTLE').upper()
    if preset == 'HEAVY':
        return {
            "label_en": "Heavy",
            "label_ja": "強め",
            "strength_loc": 0.04,
            "strength_rot": 0.06,
            "scale": 18.0,
            "depth": 2,
        }
    if preset == 'IMPACT':
        return {
            "label_en": "Impact",
            "label_ja": "インパクト",
            "strength_loc": 0.08,
            "strength_rot": 0.12,
            "scale": 9.0,
            "depth": 1,
        }
    return {
        "label_en": "Subtle",
        "label_ja": "控えめ",
        "strength_loc": 0.01,
        "strength_rot": 0.02,
        "scale": 24.0,
        "depth": 1,
    }


class SAS_OT_smart_unbake(Operator):
    bl_idname = "sas.smart_unbake"
    bl_label = "Smart Unbake"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Convert dense baked curves into a sparser editable result by removing in-betweens that stay within the unbake tolerance. Extremes can be preserved so the result remains animator-friendly.",
            "高密度にベイクされたカーブを、アンベイク許容値内の中間キーを削除して、編集しやすい疎な状態へ変換します。極値を保持できるため、アニメーターが扱いやすい結果を残せます。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Smart Unbake cancelled because there is no active action.", "アクティブアクションがないため Smart Unbake を中止しました。")
            return {'CANCELLED'}

        curves = _selected_or_all_curves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves are available.", "対象の F カーブがありません。", context))
            add_log(context, "WARN", "Smart Unbake found no F-Curves.", "対象 F カーブがないため Smart Unbake を中止しました。")
            return {'CANCELLED'}

        if settings.preview_only:
            removable = 0
            for fcurve in curves:
                points = [(kp.co.x, kp.co.y) for kp in fcurve.keyframe_points]
                keep = simplify_point_indices(points, settings.unbake_tolerance, preserve_extrema=settings.unbake_preserve_extrema, threshold=settings.remove_threshold)
                removable += max(0, len(points) - len(keep))
            message_en = f"Smart Unbake preview — removable in-between keys: {removable}."
            message_ja = f"Smart Unbake プレビュー — 削除候補の中間キー: {removable}。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        ensure_action_backup(context, "unbake")
        removed = 0
        affected_curves = 0
        for fcurve in curves:
            points = [(kp.co.x, kp.co.y) for kp in fcurve.keyframe_points]
            if len(points) <= 2:
                continue
            keep = simplify_point_indices(points, settings.unbake_tolerance, preserve_extrema=settings.unbake_preserve_extrema, threshold=settings.remove_threshold)
            remove = [idx for idx in range(len(points)) if idx not in keep]
            count = safe_remove_keyframe_points(fcurve, remove)
            if count:
                affected_curves += 1
                removed += count
                for key in fcurve.keyframe_points:
                    try:
                        if key.interpolation != 'CONSTANT':
                            key.interpolation = 'BEZIER'
                        key.handle_left_type = 'AUTO_CLAMPED'
                        key.handle_right_type = 'AUTO_CLAMPED'
                    except Exception:
                        pass
                fcurve.update()

        self.report({'INFO'}, sas_text(f"Smart Unbake removed {removed} keys across {affected_curves} curves.", f"Smart Unbake により {affected_curves} 本のカーブから {removed} 個のキーを削除しました。", context))
        add_log(context, "INFO", f"Smart Unbake removed {removed} keys across {affected_curves} curves.", f"Smart Unbake により {affected_curves} 本のカーブから {removed} 個のキーを削除しました。")
        return {'FINISHED'}


class SAS_OT_euler_filter(Operator):
    bl_idname = "sas.euler_filter"
    bl_label = "Euler Filter"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove 360-degree Euler flips by re-wrapping rotation-euler key values to the nearest continuous angle. This is useful after mocap import, retargeting, or aggressive pose edits.",
            "360 度回転の飛びを抑えるため、rotation_euler のキー値を最も連続的になる角度へ再ラップします。モーキャプ読み込み後、リターゲット後、大きなポーズ編集後に便利です。",
            context,
        )

    def execute(self, context):
        obj = active_object(context)
        action = active_action(context)
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Euler Filter cancelled because there is no active action.", "アクティブアクションがないためオイラーフィルターを中止しました。")
            return {'CANCELLED'}

        curves = _collect_euler_fcurves(context, action, obj)
        if not curves:
            self.report({'WARNING'}, sas_text("No Euler rotation curves were found.", "オイラー回転カーブが見つかりません。", context))
            add_log(context, "WARN", "Euler Filter found no Euler rotation curves.", "対象のオイラー回転カーブがないためオイラーフィルターを中止しました。")
            return {'CANCELLED'}

        ensure_action_backup(context, "euler")
        changed_keys = 0
        full_turn = math.tau
        half_turn = math.pi
        for fcurve in curves:
            keys = list(fcurve.keyframe_points)
            if len(keys) <= 1:
                continue
            local_changed = 0
            previous_value = float(keys[0].co.y)
            for key in keys[1:]:
                original = float(key.co.y)
                value = original
                while value - previous_value > half_turn:
                    value -= full_turn
                while value - previous_value < -half_turn:
                    value += full_turn
                delta = value - original
                if abs(delta) > 1e-8:
                    key.co.y += delta
                    key.handle_left.y += delta
                    key.handle_right.y += delta
                    changed_keys += 1
                    local_changed += 1
                previous_value = float(key.co.y)
            if local_changed:
                fcurve.update()

        self.report({'INFO'}, sas_text(f"Euler Filter adjusted {changed_keys} keys.", f"オイラーフィルターで {changed_keys} 個のキーを補正しました。", context))
        add_log(context, "INFO", f"Euler Filter adjusted {changed_keys} keys.", f"オイラーフィルターで {changed_keys} 個のキーを補正しました。")
        return {'FINISHED'}


class SAS_OT_apply_tangent_preset(Operator):
    bl_idname = "sas.apply_tangent_preset"
    bl_label = "Apply Tangent Preset"
    bl_options = {'UNDO'}

    mode: EnumProperty(
        name="Mode",
        description="Choose which tangent or interpolation preset is applied to the targeted keys.",
        items=[
            ('FLAT', "Flat", "Flatten selected or all key handles horizontally."),
            ('BROKEN', "Broken", "Break left and right handles for a sharp discontinuity-style change."),
            ('AUTO', "Auto", "Use automatic Bezier handles."),
            ('AUTO_CLAMPED', "Auto Clamped", "Use clamped automatic handles."),
            ('VECTOR', "Vector", "Use vector handles for straighter transitions."),
            ('LINEAR', "Linear", "Change interpolation to linear."),
            ('CONSTANT', "Constant", "Change interpolation to constant."),
        ],
        default='AUTO_CLAMPED',
    )

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Apply a tangent or interpolation preset to selected or active curves. Use Flat for planted contacts, Broken for discontinuity-style direction changes, Auto / Auto Clamped to restore smoothing, Vector for sharp changes, Linear for even timing, and Constant for blocking.",
            "選択または対象カーブへ、接線または補間のプリセットを適用します。Flat は接地や停止、Broken は不連続風の鋭い方向転換、Auto / Auto Clamped は滑らかさの復元、Vector は鋭い変化、Linear は均等タイミング、Constant はブロッキングに向いています。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Apply Tangent Preset cancelled because there is no active action.", "アクティブアクションがないため接線プリセット適用を中止しました。")
            return {'CANCELLED'}

        curves = _selected_or_all_curves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves are available.", "対象の F カーブがありません。", context))
            add_log(context, "WARN", "Apply Tangent Preset found no F-Curves.", "対象 F カーブがないため接線プリセット適用を中止しました。")
            return {'CANCELLED'}

        ensure_action_backup(context, "tangent")
        changed = 0
        for fcurve in curves:
            keys = list(fcurve.keyframe_points)
            if not keys:
                continue
            for key in keys:
                if self.mode == 'FLAT':
                    try:
                        key.interpolation = 'BEZIER'
                    except Exception:
                        pass
                    for attr in ("handle_left_type", "handle_right_type"):
                        try:
                            setattr(key, attr, 'FREE')
                        except Exception:
                            pass
                    try:
                        key.handle_left.y = key.co.y
                        key.handle_right.y = key.co.y
                    except Exception:
                        pass
                elif self.mode == 'BROKEN':
                    try:
                        key.interpolation = 'BEZIER'
                    except Exception:
                        pass
                    for attr in ("handle_left_type", "handle_right_type"):
                        try:
                            setattr(key, attr, 'FREE')
                        except Exception:
                            pass
                    try:
                        dx_left = abs(float(key.handle_left.x) - float(key.co.x)) or 0.333333
                        dx_right = abs(float(key.handle_right.x) - float(key.co.x)) or 0.333333
                        key.handle_left.x = float(key.co.x) - dx_left
                        key.handle_right.x = float(key.co.x) + dx_right
                        key.handle_left.y = float(key.co.y)
                        key.handle_right.y = float(key.co.y)
                    except Exception:
                        pass
                elif self.mode in {'AUTO', 'AUTO_CLAMPED', 'VECTOR'}:
                    try:
                        key.interpolation = 'BEZIER'
                    except Exception:
                        pass
                    for attr in ("handle_left_type", "handle_right_type"):
                        try:
                            setattr(key, attr, self.mode)
                        except Exception:
                            pass
                elif self.mode in {'LINEAR', 'CONSTANT'}:
                    try:
                        key.interpolation = self.mode
                    except Exception:
                        pass
                changed += 1
            fcurve.update()

        label_en = self.mode.replace('_', ' ').title()
        label_ja = {
            'FLAT': 'フラット',
            'BROKEN': 'ブロークン',
            'AUTO': 'オート',
            'AUTO_CLAMPED': 'オートクランプ',
            'VECTOR': 'ベクター',
            'LINEAR': 'リニア',
            'CONSTANT': 'コンスタント',
        }.get(self.mode, self.mode)
        self.report({'INFO'}, sas_text(f"Applied {label_en} tangent preset to {len(curves)} curves.", f"{len(curves)} 本のカーブへ {label_ja} 接線プリセットを適用しました。", context))
        add_log(context, "INFO", f"Applied tangent preset {label_en} to {len(curves)} curves and {changed} keys.", f"{len(curves)} 本のカーブと {changed} 個のキーへ接線プリセット {label_ja} を適用しました。")
        return {'FINISHED'}


class SAS_OT_create_trail_curve(Operator):
    bl_idname = "sas.create_trail_curve"
    bl_label = "Create Trail Curve"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Sample the active object or active pose bone over time and generate a real 3D trail curve. In Speed mode the trail can thicken automatically on faster motion, making arcs and impact accents easier to read.",
            "アクティブオブジェクトまたはアクティブポーズボーンを時間方向にサンプリングし、実体のある 3D トレイルカーブを生成します。速度モードでは速い動きほど太くできるため、アークやインパクトの読み取りがしやすくなります。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.sas_settings
        source = active_object(context)
        if source is None:
            self.report({'WARNING'}, sas_text("No active object.", "アクティブオブジェクトがありません。", context))
            add_log(context, "WARN", "Create Trail Curve cancelled because there is no active object.", "アクティブオブジェクトがないためトレイル生成を中止しました。")
            return {'CANCELLED'}

        if not settings.trail_keep_previous:
            removed = _remove_sas_trail_objects(scene)
            if removed:
                add_log(context, "INFO", f"Removed {removed} previous trail objects.", f"以前のトレイルオブジェクトを {removed} 個削除しました。")

        start, end = get_bake_range(scene, settings)
        step = max(1, settings.trail_step)
        original_frame = int(scene.frame_current)
        points = []
        try:
            for frame in range(int(start), int(end) + 1, step):
                scene.frame_set(frame)
                position = _world_position_for_trail(context)
                if position is not None:
                    points.append((float(position.x), float(position.y), float(position.z)))
        finally:
            scene.frame_set(original_frame)

        if len(points) < 2:
            self.report({'WARNING'}, sas_text("Not enough sampled points were collected for a trail.", "トレイル生成に必要なサンプル点が足りません。", context))
            add_log(context, "WARN", "Create Trail Curve found fewer than two sample points.", "サンプル点が 2 個未満のためトレイル生成を中止しました。")
            return {'CANCELLED'}

        name = unique_action_name(f"SAS_Trail_{_trail_source_label(context)}")
        curve_data = bpy.data.curves.new(name=name, type='CURVE')
        curve_data.dimensions = '3D'
        curve_data.resolution_u = settings.trail_resolution
        curve_data.bevel_depth = settings.trail_radius
        spline = curve_data.splines.new('POLY')
        spline.points.add(len(points) - 1)
        radii = radii_from_speeds(
            settings.trail_radius,
            speed_values_from_points(points, frame_step=step),
            mode=settings.trail_radius_mode,
            scale=settings.trail_speed_scale,
        )
        for index, (x_value, y_value, z_value) in enumerate(points):
            spline.points[index].co = (x_value, y_value, z_value, 1.0)
            try:
                spline.points[index].radius = radii[index] / max(settings.trail_radius, 1.0e-8)
            except Exception:
                pass

        trail_obj = bpy.data.objects.new(name, curve_data)
        trail_obj["sas_trail"] = True
        trail_obj.display_type = 'WIRE'
        trail_obj.hide_select = False

        linked = False
        for collection in getattr(source, "users_collection", []) or []:
            try:
                collection.objects.link(trail_obj)
                linked = True
                break
            except Exception:
                continue
        if not linked:
            context.scene.collection.objects.link(trail_obj)

        self.report({'INFO'}, sas_text(f"Created trail curve '{name}'.", f"トレイルカーブ「{name}」を作成しました。", context))
        add_log(context, "INFO", f"Created trail curve '{name}' with {len(points)} sampled points.", f"{len(points)} 点を使ってトレイルカーブ「{name}」を作成しました。")
        return {'FINISHED'}


class SAS_OT_clear_trail_curves(Operator):
    bl_idname = "sas.clear_trail_curves"
    bl_label = "Clear Trail Curves"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Delete Smart Animation trail-curve objects from the file.",
            "Smart Animation が生成したトレイルカーブオブジェクトをファイルから削除します。",
            context,
        )

    def execute(self, context):
        removed = _remove_sas_trail_objects(context.scene)
        self.report({'INFO'}, sas_text(f"Removed {removed} trail curves.", f"{removed} 個のトレイルカーブを削除しました。", context))
        add_log(context, "INFO", f"Removed {removed} trail curves.", f"{removed} 個のトレイルカーブを削除しました。")
        return {'FINISHED'}


class SAS_OT_apply_camera_shake_preset(Operator):
    bl_idname = "sas.apply_camera_shake_preset"
    bl_label = "Apply Camera Shake Preset"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Apply a camera-friendly procedural noise setup to the active camera or scene camera. This gives a quick GorillaCam-style handheld pass without destroying the base animation.",
            "アクティブカメラまたはシーンカメラへ、カメラ向けのプロシージャルノイズ設定を適用します。ベースアニメーションを壊さずに、GorillaCam 的な手持ち風揺れを素早く追加できます。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        camera_obj = _camera_target_object(context)
        if camera_obj is None:
            self.report({'WARNING'}, sas_text("No camera object is available.", "利用できるカメラオブジェクトがありません。", context))
            add_log(context, "WARN", "Apply Camera Shake Preset cancelled because no camera was available.", "カメラが見つからないためカメラシェイク適用を中止しました。")
            return {'CANCELLED'}

        action = ensure_active_action(context, obj=camera_obj, base_name=f"{camera_obj.name}_Action")
        if action is None:
            self.report({'WARNING'}, sas_text("The camera action could not be prepared.", "カメラ用アクションを準備できませんでした。", context))
            add_log(context, "WARN", "Apply Camera Shake Preset could not prepare a camera action.", "カメラ用アクションを準備できないためカメラシェイク適用を中止しました。")
            return {'CANCELLED'}

        preset = _camera_shake_values(settings.camera_shake_preset)
        rotation_path = "rotation_quaternion" if getattr(camera_obj, "rotation_mode", 'XYZ') == 'QUATERNION' else ("rotation_axis_angle" if getattr(camera_obj, "rotation_mode", 'XYZ') == 'AXIS_ANGLE' else "rotation_euler")
        target_curves = []
        base_keys = set(str(camera_obj.get(CAMERA_SHAKE_BASE_KEYS_PROP, "")).split(";")) - {""}
        for path_name, strength in (("location", preset["strength_loc"]), (rotation_path, preset["strength_rot"])):
            array_size = 4 if path_name in {"rotation_quaternion", "rotation_axis_angle"} else 3
            for array_index in range(array_size):
                fcurve = ensure_action_fcurve(action, camera_obj, path_name, index=array_index, group_name="Camera")
                if fcurve is None:
                    continue
                # Blender does not evaluate an F-Curve that has only a Noise modifier and no keys,
                # so hold the current value on one key for the noise to act on.
                if len(fcurve.keyframe_points) == 0:
                    fcurve.keyframe_points.insert(context.scene.frame_current, float(getattr(camera_obj, path_name)[array_index]))
                    fcurve.update()
                    base_keys.add(f"{path_name}:{array_index}")
                target_curves.append((fcurve, strength))

        camera_obj[CAMERA_SHAKE_BASE_KEYS_PROP] = ";".join(sorted(base_keys))
        affected = 0
        # Noise is a function of frame and phase only: channels sharing a phase move in
        # lockstep, so the shake would travel along one diagonal instead of shaking.
        for channel_index, (fcurve, strength) in enumerate(target_curves):
            phase = settings.noise_phase + channel_index * CAMERA_SHAKE_CHANNEL_PHASE_STEP
            affected += _apply_noise_to_curves([fcurve], strength, preset["scale"], phase, preset["depth"])

        self.report({'INFO'}, sas_text(f"Applied {preset['label_en']} camera shake to {camera_obj.name}.", f"{camera_obj.name} に {preset['label_ja']} カメラシェイクを適用しました。", context))
        add_log(context, "INFO", f"Applied {preset['label_en']} camera shake to '{camera_obj.name}' using {affected} noise modifiers.", f"カメラ「{camera_obj.name}」へ {affected} 個のノイズモディファイアで {preset['label_ja']} カメラシェイクを適用しました。")
        return {'FINISHED'}


class SAS_OT_clear_camera_shake(Operator):
    bl_idname = "sas.clear_camera_shake"
    bl_label = "Clear Camera Shake"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove Smart Animation noise modifiers from the active camera or scene camera.",
            "アクティブカメラまたはシーンカメラから Smart Animation のノイズモディファイアを削除します。",
            context,
        )

    def execute(self, context):
        camera_obj = _camera_target_object(context)
        if camera_obj is None or camera_obj.animation_data is None or camera_obj.animation_data.action is None:
            self.report({'WARNING'}, sas_text("No animated camera was found.", "アニメーション付きカメラが見つかりません。", context))
            add_log(context, "WARN", "Clear Camera Shake found no animated camera action.", "アニメーション付きカメラアクションがないためカメラシェイク解除を中止しました。")
            return {'CANCELLED'}

        action = camera_obj.animation_data.action
        curves = iter_action_fcurves(action, datablock=camera_obj)
        removed = _clear_noise_from_curves(curves)
        _remove_camera_shake_base_curves(camera_obj, action)
        self.report({'INFO'}, sas_text(f"Removed {removed} camera-shake modifiers from {camera_obj.name}.", f"{camera_obj.name} から {removed} 個のカメラシェイク用モディファイアを削除しました。", context))
        add_log(context, "INFO", f"Removed {removed} camera-shake modifiers from '{camera_obj.name}'.", f"カメラ「{camera_obj.name}」から {removed} 個のカメラシェイク用モディファイアを削除しました。")
        return {'FINISHED'}




class SAS_OT_create_ghost_preview(Operator):
    bl_idname = "sas.create_ghost_preview"
    bl_label = "Create Ghost Preview"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create viewport ghost objects on past and future frames for the current selection. This gives a BH Ghost / Ghostool style silhouette and spacing preview without altering the source animation.",
            "現在の選択に対して、過去と未来フレームにビューポート用ゴーストオブジェクトを生成します。元のアニメーションを壊さずに、BH Ghost / Ghostool 風のシルエットとスペーシング確認を行えます。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        scene = context.scene
        sources = _ghost_source_objects(context)
        if not sources:
            self.report({'WARNING'}, sas_text("No suitable objects were found for ghost preview.", "ゴーストプレビューに使えるオブジェクトが見つかりません。", context))
            add_log(context, "WARN", "Create Ghost Preview found no suitable objects.", "対象オブジェクトが見つからないためゴーストプレビュー生成を中止しました。")
            return {'CANCELLED'}

        if not settings.ghost_keep_previous:
            removed = _remove_sas_ghost_objects(scene)
            if removed:
                add_log(context, "INFO", f"Removed {removed} previous ghost preview objects.", f"以前のゴーストプレビューを {removed} 個削除しました。")

        offsets = []
        step = max(1, int(settings.ghost_step))
        for index in range(int(settings.ghost_past_frames), 0, -1):
            offsets.append(-index * step)
        for index in range(1, int(settings.ghost_future_frames) + 1):
            offsets.append(index * step)

        if not offsets:
            self.report({'WARNING'}, sas_text("Ghost preview has no past or future frames configured.", "ゴーストプレビューの過去・未来フレーム数が 0 に設定されています。", context))
            add_log(context, "WARN", "Create Ghost Preview cancelled because no ghost offsets were configured.", "ゴーストオフセットが 0 のためゴーストプレビュー生成を中止しました。")
            return {'CANCELLED'}

        original_frame = int(scene.frame_current)
        created = 0
        try:
            for offset in offsets:
                scene.frame_set(original_frame + offset)
                for source in sources:
                    ghost_object = _make_sas_ghost_object(context, source, scene.frame_current)
                    if ghost_object is not None:
                        created += 1
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Ghost preview failed: {exc}", f"ゴーストプレビュー生成に失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Create Ghost Preview failed: {exc}", f"ゴーストプレビュー生成に失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}
        finally:
            scene.frame_set(original_frame)

        self.report({'INFO'}, sas_text(f"Created {created} ghost preview objects.", f"{created} 個のゴーストプレビューを生成しました。", context))
        add_log(context, "INFO", f"Created {created} ghost preview objects from {len(sources)} source objects.", f"{len(sources)} 個のソースから {created} 個のゴーストプレビューを生成しました。")
        return {'FINISHED'}


class SAS_OT_clear_ghost_preview(Operator):
    bl_idname = "sas.clear_ghost_preview"
    bl_label = "Clear Ghost Preview"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Delete Smart Animation ghost preview objects from the file.",
            "Smart Animation が生成したゴーストプレビューオブジェクトをファイルから削除します。",
            context,
        )

    def execute(self, context):
        removed = _remove_sas_ghost_objects(context.scene)
        self.report({'INFO'}, sas_text(f"Removed {removed} ghost preview objects.", f"{removed} 個のゴーストプレビューを削除しました。", context))
        add_log(context, "INFO", f"Removed {removed} ghost preview objects.", f"{removed} 個のゴーストプレビューを削除しました。")
        return {'FINISHED'}


class SAS_OT_create_ballistic_guide(Operator):
    bl_idname = "sas.create_ballistic_guide"
    bl_label = "Create Ballistic Guide"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create a predicted ballistic arc from the current object or active pose bone using the current scene gravity and initial motion. This is useful for jump and throw checks inspired by Cascadeur-style trajectory tools.",
            "現在のオブジェクトまたはアクティブポーズボーンの初速とシーン重力を使って、予測弾道アークを作成します。Cascadeur 風のジャンプや投擲の軌道確認に便利です。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.sas_settings
        action = active_action(context)
        source_kind, source_obj, bone_name, label = _ballistic_source(context)
        if source_obj is None:
            self.report({'WARNING'}, sas_text("Select an animated object or active pose bone first.", "先にアニメーション対象オブジェクトまたはアクティブポーズボーンを選択してください。", context))
            add_log(context, "WARN", "Create Ballistic Guide cancelled because there is no valid source.", "有効なソースがないため弾道ガイド作成を中止しました。")
            return {'CANCELLED'}

        start, end = _ballistic_frame_range(context, action)
        step = max(1, int(settings.ballistic_step))
        if end <= start:
            self.report({'WARNING'}, sas_text("The ballistic range is too short.", "弾道ガイド範囲が短すぎます。", context))
            add_log(context, "WARN", "Create Ballistic Guide cancelled because the frame range is too short.", "フレーム範囲が短すぎるため弾道ガイド作成を中止しました。")
            return {'CANCELLED'}

        removed = 0
        if not settings.ballistic_keep_previous:
            removed = _remove_sas_ballistic_objects(scene)

        current_frame = int(scene.frame_current)
        fps = 24.0
        try:
            fps = float(scene.render.fps) / max(1e-8, float(scene.render.fps_base))
        except Exception:
            fps = 24.0
        fps = max(1e-6, fps)

        frames = list(range(start, end + 1, step))
        if not frames:
            frames = [start, end]
        if len(frames) == 1:
            frames.append(end)
        if frames[-1] != end:
            frames.append(end)

        depsgraph = context.evaluated_depsgraph_get()
        try:
            gravity_value = getattr(scene, 'gravity', (0.0, 0.0, -9.81))
            gravity = Vector((float(gravity_value[0]), float(gravity_value[1]), float(gravity_value[2])))
        except Exception:
            gravity = Vector((0.0, 0.0, -9.81))

        try:
            scene.frame_set(frames[0])
            p0 = _sample_source_world_position(depsgraph, source_kind, source_obj, bone_name)
            scene.frame_set(frames[1])
            p1 = _sample_source_world_position(depsgraph, source_kind, source_obj, bone_name)
            if p0 is None or p1 is None:
                raise RuntimeError("source evaluation failed")

            dt_frames = max(1.0, float(frames[1] - frames[0]))
            dt_seconds = dt_frames / fps
            initial_velocity = (p1 - p0) / dt_seconds

            points = []
            for frame in frames:
                t = (float(frame) - float(start)) / fps
                position = p0 + (initial_velocity * t) + (0.5 * gravity * (t * t))
                points.append(position)
        except Exception as exc:
            scene.frame_set(current_frame)
            self.report({'ERROR'}, sas_text(f"Ballistic guide creation failed: {exc}", f"弾道ガイド作成に失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Create Ballistic Guide failed: {exc}", f"弾道ガイド作成に失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}
        finally:
            try:
                scene.frame_set(current_frame)
            except Exception:
                pass

        name = unique_action_name(f"SAS_Ballistic_{label}")
        try:
            curve_data = bpy.data.curves.new(name=name, type='CURVE')
            curve_data.dimensions = '3D'
            curve_data.resolution_u = max(1, int(settings.trail_resolution))
            curve_data.bevel_depth = max(0.0, float(settings.trail_radius) * 0.5)
            spline = curve_data.splines.new('POLY')
            spline.points.add(max(0, len(points) - 1))
            for index, point in enumerate(points):
                spline.points[index].co = (float(point.x), float(point.y), float(point.z), 1.0)
            guide_obj = bpy.data.objects.new(name, curve_data)
            guide_obj["sas_ballistic"] = True
            guide_obj["sas_ballistic_source"] = label
            guide_obj["sas_ballistic_start"] = int(start)
            guide_obj["sas_ballistic_end"] = int(end)
            guide_obj.hide_render = True
            try:
                guide_obj.display_type = 'WIRE'
            except Exception:
                pass
            try:
                guide_obj.show_in_front = True
            except Exception:
                pass
            collection = _ballistic_collection(scene, ensure=True)
            linked = False
            if collection is not None:
                try:
                    collection.objects.link(guide_obj)
                    linked = True
                except Exception:
                    linked = False
            if not linked:
                scene.collection.objects.link(guide_obj)
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Ballistic guide creation failed: {exc}", f"弾道ガイド作成に失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Create Ballistic Guide failed while creating the curve: {exc}", f"弾道ガイドのカーブ生成中に失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}

        self.report({'INFO'}, sas_text(f"Created ballistic guide '{name}'.", f"弾道ガイド「{name}」を作成しました。", context))
        add_log(context, "INFO", f"Created ballistic guide '{name}' for {label} over frames {start}-{end}.", f"{label} 用にフレーム {start}-{end} の弾道ガイド「{name}」を作成しました。")
        if removed:
            add_log(context, "INFO", f"Removed {removed} older ballistic guide objects before creating the new guide.", f"新しいガイド作成前に {removed} 個の古い弾道ガイドを削除しました。")
        return {'FINISHED'}


class SAS_OT_bake_ballistic_keys(Operator):
    bl_idname = "sas.bake_ballistic_keys"
    bl_label = "Bake Ballistic Keys"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Bake the predicted ballistic arc back into editable location keys on the current object or active pose bone. Use Ballistic Blend below 1.0 for a lighter AutoPhysics-style correction instead of a full replacement.",
            "予測した弾道アークを、現在のオブジェクトまたはアクティブポーズボーンの編集可能な位置キーへベイクします。Ballistic Blend を 1.0 未満にすると、完全置換ではなく軽い AutoPhysics 風の補正として使えます。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        settings = scene.sas_settings
        action = active_action(context)
        source_kind, source_obj, bone_name, label = _ballistic_source(context)
        if source_obj is None:
            self.report({'WARNING'}, sas_text("Select an animated object or active pose bone first.", "先にアニメーション対象オブジェクトまたはアクティブポーズボーンを選択してください。", context))
            add_log(context, "WARN", "Bake Ballistic Keys cancelled because there is no valid source.", "有効なソースがないため Ballistic Keys ベイクを中止しました。")
            return {'CANCELLED'}

        owner = context.active_pose_bone if source_kind == 'POSE_BONE' else source_obj
        armature = source_obj if source_kind == 'POSE_BONE' else None
        if owner is None:
            self.report({'WARNING'}, sas_text("No valid ballistic owner was found.", "有効な弾道ベイク対象が見つかりません。", context))
            add_log(context, "WARN", "Bake Ballistic Keys cancelled because the owner could not be resolved.", "対象の所有者を解決できないため Ballistic Keys ベイクを中止しました。")
            return {'CANCELLED'}

        start, end = _ballistic_frame_range(context, action)
        step = max(1, int(settings.ballistic_step))
        if end <= start:
            self.report({'WARNING'}, sas_text("The ballistic range is too short.", "弾道ベイク範囲が短すぎます。", context))
            add_log(context, "WARN", "Bake Ballistic Keys cancelled because the frame range is too short.", "フレーム範囲が短すぎるため Ballistic Keys ベイクを中止しました。")
            return {'CANCELLED'}

        frames = list(range(start, end + 1, step))
        if not frames:
            frames = [start, end]
        if len(frames) == 1:
            frames.append(end)
        if frames[-1] != end:
            frames.append(end)

        if settings.preview_only:
            message_en = f"Ballistic Keys Preview — source '{label}', frames {start}-{end}, {len(frames)} samples, blend {float(settings.ballistic_blend):.3f}, clear range {bool(settings.ballistic_clear_range)}."
            message_ja = f"Ballistic Keys プレビュー — ソース「{label}」、範囲 {start}-{end}、{len(frames)} サンプル、ブレンド {float(settings.ballistic_blend):.3f}、範囲クリア {bool(settings.ballistic_clear_range)}。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        depsgraph = None
        try:
            depsgraph = context.evaluated_depsgraph_get()
        except Exception:
            depsgraph = None

        fps = 24.0
        try:
            fps = float(scene.render.fps) / max(1e-8, float(scene.render.fps_base))
        except Exception:
            fps = 24.0
        fps = max(1e-6, fps)

        current_frame = int(scene.frame_current)
        restore_matrix = _owner_world_matrix(context, owner, armature=armature)
        removed_keys = 0
        baked = 0
        failed = 0
        try:
            gravity_value = getattr(scene, 'gravity', (0.0, 0.0, -9.81))
            gravity = Vector((float(gravity_value[0]), float(gravity_value[1]), float(gravity_value[2])))
            scene.frame_set(frames[0])
            p0 = _sample_source_world_position(depsgraph, source_kind, source_obj, bone_name)
            scene.frame_set(frames[1])
            p1 = _sample_source_world_position(depsgraph, source_kind, source_obj, bone_name)
            if p0 is None or p1 is None:
                raise RuntimeError('source evaluation failed')
            dt_frames = max(1.0, float(frames[1] - frames[0]))
            dt_seconds = dt_frames / fps
            initial_velocity = (p1 - p0) / dt_seconds

            samples = {}
            original_positions = {}
            for frame in frames:
                scene.frame_set(frame)
                original = _sample_source_world_position(depsgraph, source_kind, source_obj, bone_name)
                if original is None:
                    failed += 1
                    continue
                original_positions[int(frame)] = original
                t = (float(frame) - float(start)) / fps
                ballistic = p0 + (initial_velocity * t) + (0.5 * gravity * (t * t))
                blend = max(0.0, min(1.0, float(settings.ballistic_blend)))
                samples[int(frame)] = original.lerp(ballistic, blend)

            target_action = get_or_create_action_for_object(source_obj, base_name=f"{source_obj.name}_Ballistic")
            ensure_action_backup(context, "ballistic_keys", obj=source_obj, action=target_action)
            if settings.ballistic_clear_range:
                removed_keys = _remove_location_keys_in_range(target_action, source_obj, _ballistic_location_path(source_kind, bone_name), start, end)

            for frame in frames:
                sample = samples.get(int(frame))
                if sample is None:
                    continue
                scene.frame_set(int(frame))
                world_matrix = _owner_world_matrix(context, owner, armature=armature)
                if world_matrix is None:
                    failed += 1
                    continue
                try:
                    world_matrix.translation = sample
                except Exception:
                    try:
                        world_matrix.translation = Vector((float(sample.x), float(sample.y), float(sample.z)))
                    except Exception:
                        failed += 1
                        continue
                if not _restore_owner_world_matrix(context, owner, world_matrix, armature=armature):
                    failed += 1
                    continue
                try:
                    owner.keyframe_insert(data_path='location', frame=float(frame))
                    baked += 1
                except Exception:
                    failed += 1
                    continue
        except Exception as exc:
            try:
                scene.frame_set(current_frame)
            except Exception:
                pass
            if restore_matrix is not None:
                _restore_owner_world_matrix(context, owner, restore_matrix, armature=armature)
            self.report({'ERROR'}, sas_text(f"Ballistic key baking failed: {exc}", f"弾道キーのベイクに失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Bake Ballistic Keys failed: {exc}", f"弾道キーのベイクに失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}
        finally:
            try:
                scene.frame_set(current_frame)
            except Exception:
                pass
            if restore_matrix is not None:
                _restore_owner_world_matrix(context, owner, restore_matrix, armature=armature)

        if baked == 0:
            self.report({'WARNING'}, sas_text("No ballistic keys were baked. Check the source and range.", "弾道キーはベイクされませんでした。ソースと範囲を確認してください。", context))
            add_log(context, "WARN", f"Bake Ballistic Keys produced no keys for {label}.", f"{label} に対して弾道キーは作成されませんでした。")
            return {'CANCELLED'}

        message_en = f"Baked ballistic location keys for {label} across frames {start}-{end} using {baked} sampled frames, blend {float(settings.ballistic_blend):.3f}, removed {removed_keys} existing location keys, failures {failed}."
        message_ja = f"{label} に対してフレーム {start}-{end} の弾道位置キーを {baked} サンプルでベイクしました。ブレンド {float(settings.ballistic_blend):.3f}、既存位置キー削除 {removed_keys}、失敗 {failed}。"
        self.report({'INFO'}, sas_text(message_en, message_ja, context))
        add_log(context, "INFO", message_en, message_ja)
        return {'FINISHED'}


class SAS_OT_clear_ballistic_guides(Operator):
    bl_idname = "sas.clear_ballistic_guides"
    bl_label = "Clear Ballistic Guides"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Delete Smart Animation ballistic guide curves from the file.",
            "Smart Animation が生成した弾道ガイドカーブをファイルから削除します。",
            context,
        )

    def execute(self, context):
        removed = _remove_sas_ballistic_objects(context.scene)
        self.report({'INFO'}, sas_text(f"Removed {removed} ballistic guide objects.", f"{removed} 個の弾道ガイドを削除しました。", context))
        add_log(context, "INFO", f"Removed {removed} ballistic guide objects.", f"{removed} 個の弾道ガイドを削除しました。")
        return {'FINISHED'}


class SAS_OT_apply_cycles_preset(Operator):
    bl_idname = "sas.apply_cycles_preset"
    bl_label = "Apply Loop Preset"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Add or refresh a non-destructive Cycles modifier on the selected or active curves. This is useful for looping motion, repeat-offset actions, and ping-pong previews inspired by Track View or Signal-style workflows.",
            "選択または対象 F カーブに、非破壊の Cycles モディファイアを追加または更新します。ループモーション、オフセット繰り返し、Track View や Signal 風のピンポンプレビューに便利です。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Apply Loop Preset cancelled because there is no active action.", "アクティブアクションがないためループプリセット適用を中止しました。")
            return {'CANCELLED'}

        curves = _selected_or_all_curves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves are available.", "対象の F カーブがありません。", context))
            add_log(context, "WARN", "Apply Loop Preset found no F-Curves.", "対象 F カーブがないためループプリセット適用を中止しました。")
            return {'CANCELLED'}

        mode = settings.loop_modifier_mode
        scope = settings.loop_modifier_scope
        before_count = int(getattr(settings, 'loop_cycles_before', 0))
        after_count = int(getattr(settings, 'loop_cycles_after', 0))
        affected = 0
        for fcurve in curves:
            modifier = _find_sas_cycles_modifier(fcurve)
            if modifier is None:
                try:
                    modifier = fcurve.modifiers.new(type='CYCLES')
                    modifier.name = "SAS_CYCLES"
                except Exception:
                    continue
            try:
                modifier.mode_before = mode if scope in {'BEFORE', 'BOTH'} else 'NONE'
            except Exception:
                pass
            try:
                modifier.mode_after = mode if scope in {'AFTER', 'BOTH'} else 'NONE'
            except Exception:
                pass
            try:
                modifier.cycles_before = before_count
            except Exception:
                pass
            try:
                modifier.cycles_after = after_count
            except Exception:
                pass
            affected += 1

        label_ja = {'REPEAT': '繰り返し', 'REPEAT_OFFSET': 'オフセット繰り返し', 'MIRROR': 'ピンポン'}.get(mode, mode)
        self.report({'INFO'}, sas_text(f"Applied loop preset to {affected} curves.", f"{affected} 本のカーブへ {label_ja} ループプリセットを適用しました。", context))
        add_log(context, "INFO", f"Applied loop preset {mode}/{scope} to {affected} curves with before={before_count} and after={after_count}.", f"{affected} 本のカーブへ {label_ja} / {scope} のループプリセットを適用しました。前方向 {before_count}、後方向 {after_count}。")
        return {'FINISHED'}


class SAS_OT_clear_cycles_preset(Operator):
    bl_idname = "sas.clear_cycles_preset"
    bl_label = "Clear Loop Preset"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove Smart Animation loop modifiers from the selected or active curves.",
            "選択または対象 F カーブから Smart Animation のループモディファイアを削除します。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Clear Loop Preset cancelled because there is no active action.", "アクティブアクションがないためループプリセット解除を中止しました。")
            return {'CANCELLED'}

        curves = _selected_or_all_curves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves are available.", "対象の F カーブがありません。", context))
            add_log(context, "WARN", "Clear Loop Preset found no F-Curves.", "対象 F カーブがないためループプリセット解除を中止しました。")
            return {'CANCELLED'}

        removed = _clear_sas_cycles_from_curves(curves)
        self.report({'INFO'}, sas_text(f"Removed {removed} loop modifiers.", f"{removed} 個のループモディファイアを削除しました。", context))
        add_log(context, "INFO", f"Removed {removed} loop modifiers.", f"{removed} 個のループモディファイアを削除しました。")
        return {'FINISHED'}


class SAS_OT_apply_tween(Operator):
    bl_idname = "sas.apply_tween"
    bl_label = "Apply Tween"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create or update a key on the current frame by blending between the previous and next keys. Values outside 0 to 1 create anticipation and overshoot like advanced tween tools.",
            "前後のキーをブレンドして、現在フレームにキーを作成または更新します。0 から 1 の範囲外を使うと、高度なトゥイーンツールのように予備動作やオーバーシュートを作れます。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Apply Tween cancelled because there is no active action.", "アクティブアクションがないためトゥイーン作成を中止しました。")
            return {'CANCELLED'}

        curves = _selected_or_all_curves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves are available for tweening.", "トゥイーンに使える F カーブがありません。", context))
            add_log(context, "WARN", "Apply Tween found no usable F-Curves.", "使用できる F カーブがないためトゥイーン作成を中止しました。")
            return {'CANCELLED'}

        backup = ensure_action_backup(context, "tween")
        frame = float(context.scene.frame_current)
        factor = float(settings.tween_factor)
        mode = getattr(settings, 'tween_mode', 'LINEAR')
        changed = 0
        for fcurve in curves:
            prev_prev, prev_key, _exact, next_key, next_next = _tween_surrounding_keys(fcurve, frame)
            if prev_key is None or next_key is None:
                continue
            value = advanced_tween_value(
                float(prev_prev.co.y) if prev_prev is not None else None,
                float(prev_key.co.y),
                float(next_key.co.y),
                float(next_next.co.y) if next_next is not None else None,
                factor,
                mode=mode,
            )
            ensure_key_at_frame(fcurve, frame, value)
            changed += 1

        if changed == 0:
            discard_action_backup(context, backup)
            self.report({'WARNING'}, sas_text("Tweening needs keys on both sides of the current frame.", "トゥイーン作成には現在フレームの前後両側にキーが必要です。", context))
            add_log(context, "WARN", "Apply Tween found no curves with valid neighboring keys.", "前後キーが見つからないためトゥイーン作成を中止しました。")
            return {'CANCELLED'}

        self.report({'INFO'}, sas_text(f"Created or updated tween keys on {changed} curves using {mode.lower()} tweening.", f"{mode} モードで {changed} 本のカーブにトゥイーンキーを作成または更新しました。", context))
        add_log(context, "INFO", f"Applied {mode.lower()} tween keys on {changed} curves with factor {factor:.3f}.", f"{mode} モード、係数 {factor:.3f} で {changed} 本のカーブにトゥイーンキーを適用しました。")
        return {'FINISHED'}


class SAS_OT_push_pull_keys(Operator):
    bl_idname = "sas.push_pull_keys"
    bl_label = "Push / Pull Keys"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Push or pull the current-frame key away from, or back toward, the straight interpolation between its neighbors. This is a compact animBot-style spacing control for polish work.",
            "現在フレームのキーを、前後キーの直線補間から遠ざけたり近づけたりします。詰め作業に使える、コンパクトな animBot 風スペーシング調整です。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Push / Pull Keys cancelled because there is no active action.", "アクティブアクションがないためプッシュ / プルを中止しました。")
            return {'CANCELLED'}
        curves = _selected_or_all_curves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves are available for push / pull.", "プッシュ / プルに使える F カーブがありません。", context))
            add_log(context, "WARN", "Push / Pull Keys found no usable F-Curves.", "使用できる F カーブがないためプッシュ / プルを中止しました。")
            return {'CANCELLED'}
        backup = ensure_action_backup(context, "push_pull")
        frame = float(context.scene.frame_current)
        factor = float(settings.push_pull_factor)
        changed = push_pull_curve_values(curves, factor, frame=frame, selected_keys_only=False)
        if changed == 0:
            discard_action_backup(context, backup)
            self.report({'WARNING'}, sas_text("Push / Pull needs a keyed frame with keys on both sides.", "プッシュ / プルには、現在フレームのキーと前後両側のキーが必要です。", context))
            add_log(context, "WARN", "Push / Pull Keys found no keys that had valid neighbors on both sides.", "前後キーの条件を満たすキーがないためプッシュ / プルを中止しました。")
            return {'CANCELLED'}
        self.report({'INFO'}, sas_text(f"Adjusted {changed} keys with push / pull.", f"{changed} 個のキーをプッシュ / プルで調整しました。", context))
        add_log(context, "INFO", f"Adjusted {changed} keys with push / pull factor {factor:.3f}.", f"係数 {factor:.3f} で {changed} 個のキーをプッシュ / プル調整しました。")
        return {'FINISHED'}


class SAS_OT_scale_to_neighbors(Operator):
    bl_idname = "sas.scale_to_neighbors"
    bl_label = "Scale To Neighbors"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Scale selected keys, or the active timing range when no keys are selected, around the straight line between the surrounding anchor keys. This is a compact animBot-style polish tool for preserving or exaggerating a block of spacing.",
            "選択キー、またはキー未選択時はアクティブなタイミング範囲を、外側アンカーキー間の直線基準で拡縮します。スペーシングの塊を保ったまま強弱を付けられる、コンパクトな animBot 風の詰め作業ツールです。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Scale To Neighbors cancelled because there is no active action.", "アクティブアクションがないため Scale To Neighbors を中止しました。")
            return {'CANCELLED'}

        curves = _selected_or_all_curves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves are available for scale-to-neighbors.", "Scale To Neighbors に使える F カーブがありません。", context))
            add_log(context, "WARN", "Scale To Neighbors found no usable F-Curves.", "使用できる F カーブがないため Scale To Neighbors を中止しました。")
            return {'CANCELLED'}

        has_selected_keys = bool(_selected_key_frames(curves))
        start = end = None
        selected_keys_only = has_selected_keys
        if not has_selected_keys:
            if not settings.retime_use_range:
                self.report({'WARNING'}, sas_text(
                    "Select keys first, or enable Use Range in Timing Tools so Scale To Neighbors knows which section to reshape.",
                    "まずキーを選択するか、Timing Tools の「範囲を使用」を有効にして、Scale To Neighbors の対象区間を指定してください。",
                    context,
                ))
                add_log(context, "WARN", "Scale To Neighbors needs either selected keys or an enabled timing range.", "Scale To Neighbors には選択キーまたは有効なタイミング範囲が必要です。")
                return {'CANCELLED'}
            start, end = get_timing_range(context, action, settings)
            selected_keys_only = False

        backup = ensure_action_backup(context, "scale_neighbors")
        factor = float(settings.neighbor_scale_factor)
        changed = scale_keys_to_neighbor_span(curves, factor, start=start, end=end, selected_keys_only=selected_keys_only)
        if changed == 0:
            discard_action_backup(context, backup)
            self.report({'WARNING'}, sas_text(
                "Scale To Neighbors needs keys with anchor keys on both sides of the edited block.",
                "Scale To Neighbors には、編集ブロックの両外側にアンカーキーが必要です。",
                context,
            ))
            add_log(context, "WARN", "Scale To Neighbors found no editable blocks with valid surrounding anchors.", "有効な外側アンカーを持つ編集ブロックがないため Scale To Neighbors を中止しました。")
            return {'CANCELLED'}

        if selected_keys_only:
            message_en = f"Scaled {changed} selected keys around neighboring anchors with factor {factor:.3f}."
            message_ja = f"係数 {factor:.3f} で、外側アンカー基準に {changed} 個の選択キーを拡縮しました。"
        else:
            message_en = f"Scaled {changed} keys in the timing range around neighboring anchors with factor {factor:.3f}."
            message_ja = f"係数 {factor:.3f} で、タイミング範囲内の {changed} 個のキーを外側アンカー基準で拡縮しました。"
        self.report({'INFO'}, sas_text(message_en, message_ja, context))
        add_log(context, "INFO", message_en, message_ja)
        return {'FINISHED'}


class SAS_OT_apply_contact_hold(Operator):
    bl_idname = "sas.apply_contact_hold"
    bl_label = "Apply Contact Hold"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Flatten selected or targeted curves to the current-frame value across a frame range. This is useful for planted feet, hand contacts, held props, and fulcrum-style cleanup.",
            "選択または対象カーブを、指定範囲で現在フレームの値へ平坦化します。接地した足、手の接触、保持中の小物、Fulcrum 風の整理に便利です。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Apply Contact Hold cancelled because there is no active action.", "アクティブアクションがないためコンタクト保持を中止しました。")
            return {'CANCELLED'}

        curves = _hold_target_curves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No target curves are available for contact hold.", "コンタクト保持に使える対象カーブがありません。", context))
            add_log(context, "WARN", "Apply Contact Hold found no usable target curves.", "使用できる対象カーブがないためコンタクト保持を中止しました。")
            return {'CANCELLED'}

        start = float(min(settings.contact_hold_start, settings.contact_hold_end))
        end = float(max(settings.contact_hold_start, settings.contact_hold_end))
        source_frame = float(context.scene.frame_current)

        if settings.preview_only:
            key_count = count_keys_in_frame_range(curves, start, end)
            message_en = f"Contact Hold preview — {len(curves)} curves, {key_count} keys inside frames {int(start)}-{int(end)}."
            message_ja = f"コンタクト保持プレビュー — {len(curves)} 本のカーブ、フレーム {int(start)}-{int(end)} 内のキー数は {key_count} です。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        ensure_action_backup(context, "contact")
        changed_curves = 0
        flattened_keys = 0
        for fcurve in curves:
            try:
                value = float(fcurve.evaluate(source_frame))
            except Exception:
                continue

            _prev, exact_start, _next = find_neighbor_keyframes(fcurve, start)
            _prev2, exact_end, _next2 = find_neighbor_keyframes(fcurve, end)
            # Judge the change before the boundary keys are overwritten with the held value.
            moved_keys = sum(
                1 for key in fcurve.keyframe_points
                if start <= float(key.co.x) <= end and abs(float(key.co.y) - value) > 1e-8
            )
            flattened_keys += moved_keys
            local_changed = exact_start is None or exact_end is None or moved_keys > 0
            ensure_key_at_frame(fcurve, start, value)
            ensure_key_at_frame(fcurve, end, value)

            for key in fcurve.keyframe_points:
                key_frame = float(key.co.x)
                if start <= key_frame <= end:
                    key.co.y = value
                    try:
                        key.interpolation = 'BEZIER'
                    except Exception:
                        pass
                    for attr in ('handle_left_type', 'handle_right_type'):
                        try:
                            setattr(key, attr, 'FREE')
                        except Exception:
                            pass
                    try:
                        key.handle_left.y = value
                        key.handle_right.y = value
                    except Exception:
                        pass

            if local_changed:
                changed_curves += 1
                fcurve.update()

        self.report({'INFO'}, sas_text(f"Applied contact hold to {changed_curves} curves.", f"{changed_curves} 本のカーブへコンタクト保持を適用しました。", context))
        add_log(context, "INFO", f"Applied contact hold to {changed_curves} curves across frames {int(start)}-{int(end)}.", f"フレーム {int(start)}-{int(end)} で {changed_curves} 本のカーブへコンタクト保持を適用しました。")
        return {'FINISHED'}


class SAS_OT_apply_snapshot_blend(Operator):
    bl_idname = "sas.apply_snapshot_blend"
    bl_label = "Blend Pose Snapshot"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        settings = context.scene.sas_settings
        return context.mode == 'POSE' and len(settings.pose_snapshots) > 0 and active_object(context) is not None and active_object(context).type == 'ARMATURE'

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Blend the highlighted pose snapshot onto the current pose using the Pose Blend slider. This behaves like a compact pose-morph helper for animation blocking and polish.",
            "選択中のポーズスナップショットを、ポーズブレンドの値で現在ポーズへ重ねます。ブロッキングや詰めの作業で使える、コンパクトなポーズモーフ補助です。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        arm = active_object(context)
        index = settings.pose_snapshot_index
        if index < 0 or index >= len(settings.pose_snapshots):
            self.report({'WARNING'}, sas_text("No snapshot selected.", "スナップショットが選択されていません。", context))
            add_log(context, "WARN", "Blend Pose Snapshot found no selected snapshot.", "選択中のスナップショットがないためブレンドを中止しました。")
            return {'CANCELLED'}
        snapshot = settings.pose_snapshots[index]
        try:
            payload = json.loads(snapshot.data_json)
        except Exception as exc:
            self.report({'ERROR'}, sas_text("Snapshot data could not be parsed.", "スナップショットデータを解析できませんでした。", context))
            add_log(context, "ERROR", f"Blend Pose Snapshot failed because JSON parsing raised: {exc}", f"JSON 解析エラーのためポーズブレンドに失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}

        applied = _apply_snapshot_payload(arm, payload, settings.snapshot_blend_factor)
        self.report({'INFO'}, sas_text(f"Blended snapshot onto {applied} bones.", f"{applied} 本のボーンへスナップショットをブレンドしました。", context))
        add_log(context, "INFO", f"Blended pose snapshot '{snapshot.name}' onto {applied} bones with factor {settings.snapshot_blend_factor:.3f}.", f"ポーズスナップショット「{snapshot.name}」を係数 {settings.snapshot_blend_factor:.3f} で {applied} 本へブレンドしました。")
        return {'FINISHED'}


class SAS_OT_apply_stepped_preview(Operator):
    bl_idname = "sas.apply_stepped_preview"
    bl_label = "Apply Stepped Preview"
    bl_options = {'UNDO'}

    step_override: IntProperty(
        name="Step Override",
        description="Optional hold length used by quick stepped-preview buttons. Leave at 0 to use the main Stepped Preview setting instead.",
        default=0,
        min=0,
        soft_max=12,
        options={'SKIP_SAVE'},
    )

    @classmethod
    def description(cls, context, properties):
        if getattr(properties, 'step_override', 0):
            step = int(properties.step_override)
            return sas_text(
                f"Apply a non-destructive stepped interpolation modifier using a fixed step of {step}. 2 approximates animation on twos and 4 approximates fours.",
                f"固定ステップ {step} で、非破壊の段階補間モディファイアを適用します。2 は 2 コマ打ち、4 は 4 コマ打ちの近似です。",
                context,
            )
        return sas_text(
            "Apply a non-destructive stepped interpolation modifier to the selected or active curves. Use 2 for animation on twos and 4 for fours.",
            "選択または対象カーブに、非破壊の段階補間モディファイアを適用します。2 で 2 コマ打ち、4 で 4 コマ打ちのプレビューに使えます。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Apply Stepped Preview cancelled because there is no active action.", "アクティブアクションがないため段階プレビューを中止しました。")
            return {'CANCELLED'}
        curves = _selected_or_all_curves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves are available.", "対象の F カーブがありません。", context))
            add_log(context, "WARN", "Apply Stepped Preview found no F-Curves.", "対象 F カーブがないため段階プレビューを中止しました。")
            return {'CANCELLED'}

        selected_frames = _selected_key_frames(curves)
        if selected_frames:
            start = float(selected_frames[0])
            end = float(selected_frames[-1])
            use_range = True
        else:
            start, end = get_timing_range(context, action, settings)
            use_range = bool(settings.retime_use_range)
        step_size = max(1, int(self.step_override or settings.step_preview_frames))
        affected = 0
        for fcurve in curves:
            if settings.step_preview_replace_existing:
                remove_sas_modifiers(fcurve, 'SAS_STEP')
            modifier = next((mod for mod in fcurve.modifiers if mod.name.startswith('SAS_STEP')), None)
            if modifier is None:
                modifier = fcurve.modifiers.new(type='STEPPED')
            modifier.name = 'SAS_STEP'
            try:
                modifier.frame_step = step_size
            except Exception:
                pass
            # RNA clamps each bound against the other. Move the far bound first
            # when the new interval lies above the modifier's current end.
            bounds = [('frame_start', start), ('frame_end', end)]
            if start > modifier.frame_end:
                bounds.reverse()
            for attr, value in (('use_frame_start', use_range), ('use_frame_end', use_range), *bounds, ('frame_offset', 0.0)):
                try:
                    setattr(modifier, attr, value)
                except Exception:
                    pass
            affected += 1

        self.report({'INFO'}, sas_text(f"Applied stepped preview to {affected} curves.", f"{affected} 本のカーブに段階プレビューを適用しました。", context))
        add_log(context, "INFO", f"Applied stepped preview to {affected} curves with step size {step_size}.", f"ステップサイズ {step_size} で {affected} 本のカーブに段階プレビューを適用しました。")
        return {'FINISHED'}


class SAS_OT_bake_step_keys(Operator):
    bl_idname = "sas.bake_step_keys"
    bl_label = "Bake Step Keys"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Convert the current action into real held step keys on the chosen frame interval. When keyframes are selected, their first and last frames define the conversion span automatically.",
            "現在のアクションを、指定したコマ間隔の実ステップキーへ変換します。キーフレームが選択されている場合は、その最初と最後のフレームを変換範囲として自動使用します。",
            context,
        )

    def execute(self, context):
        obj = active_object(context)
        action = active_action(context, obj=obj)
        settings = context.scene.sas_settings
        if obj is None or action is None:
            self.report({'WARNING'}, sas_text("No active action to convert.", "変換するアクティブアクションがありません。", context))
            add_log(context, "WARN", "Bake Step Keys cancelled because there is no active action.", "アクティブアクションがないため Step Keys を中止しました。")
            return {'CANCELLED'}

        curves = _selected_or_all_curves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No editable F-Curves were found.", "編集可能な F カーブが見つかりません。", context))
            add_log(context, "WARN", "Bake Step Keys found no editable F-Curves.", "編集可能な F カーブがないため Step Keys を中止しました。")
            return {'CANCELLED'}

        step_size = max(1, int(settings.step_preview_frames))
        selected_frames = _selected_key_frames(curves)
        if selected_frames:
            start = float(selected_frames[0])
            end = float(selected_frames[-1])
            range_source_en = "selected keys"
            range_source_ja = "選択キー"
        else:
            start, end = get_timing_range(context, action, settings)
            if settings.retime_use_range:
                range_source_en = "timing range"
                range_source_ja = "タイミング範囲"
            else:
                range_source_en = "action range"
                range_source_ja = "アクション範囲"
        if end < start:
            start, end = end, start
        frames = frame_sequence(start, end, step_size, include_end=True)
        if not frames:
            frames = [float(int(round(start)))]

        if settings.preview_only:
            message_en = f"Step Keys Preview — {len(curves)} curves, {len(frames)} held samples, frames {int(start)}-{int(end)}, step {step_size}, source {range_source_en}."
            message_ja = f"Step Keys プレビュー — {len(curves)} 本のカーブ、{len(frames)} 個の保持サンプル、範囲 {int(start)}-{int(end)}、ステップ {step_size}、基準 {range_source_ja}。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        ensure_action_backup(context, "step_keys", obj=obj, action=action)
        baked_curves = 0
        key_total = 0
        removed_modifiers = 0
        for fcurve in curves:
            samples = {frame: float(fcurve.evaluate(frame)) for frame in frames}
            removed_modifiers += remove_sas_modifiers(fcurve, 'SAS_STEP')
            rebuild_curve_range_from_samples(
                fcurve,
                samples,
                interpolation='CONSTANT',
                handle_type='VECTOR',
                start=start,
                end=end,
            )
            baked_curves += 1
            key_total += len(samples)

        self.report({'INFO'}, sas_text(
            f"Baked {key_total} step keys across {baked_curves} curves.",
            f"{baked_curves} 本のカーブへ {key_total} 個のステップキーをベイクしました。",
            context,
        ))
        add_log(
            context,
            "INFO",
            f"Baked step keys across {baked_curves} curves using step {step_size} over frames {int(start)}-{int(end)} from {range_source_en}; removed {removed_modifiers} SAS stepped-preview modifiers.",
            f"{range_source_ja}の範囲 {int(start)}-{int(end)} をステップ {step_size} で {baked_curves} 本のカーブへステップキー化し、SAS 段階プレビューモディファイア {removed_modifiers} 個を削除しました。",
        )
        return {'FINISHED'}


class SAS_OT_clear_stepped_preview(Operator):
    bl_idname = "sas.clear_stepped_preview"
    bl_label = "Clear Stepped Preview"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove Smart Animation stepped-preview modifiers from the selected or active curves.",
            "選択または対象カーブから Smart Animation の段階プレビュー用モディファイアを削除します。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Clear Stepped Preview cancelled because there is no active action.", "アクティブアクションがないため段階プレビュー解除を中止しました。")
            return {'CANCELLED'}
        removed = 0
        for fcurve in _selected_or_all_curves(context, action):
            removed += remove_sas_modifiers(fcurve, 'SAS_STEP')
        self.report({'INFO'}, sas_text(f"Removed {removed} stepped preview modifiers.", f"{removed} 個の段階プレビュー用モディファイアを削除しました。", context))
        add_log(context, "INFO", f"Removed {removed} stepped preview modifiers.", f"{removed} 個の段階プレビュー用モディファイアを削除しました。")
        return {'FINISHED'}


class SAS_OT_apply_noise_modifier(Operator):
    bl_idname = "sas.apply_noise_modifier"
    bl_label = "Apply Noise Modifier"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Apply a procedural noise modifier to the selected or active curves. This is useful for handheld camera shake, subtle breathing, cloth flutter, and procedural motion design.",
            "選択または対象カーブにプロシージャルなノイズモディファイアを適用します。手持ちカメラの揺れ、呼吸、布の微振動、モーショングラフィックスに便利です。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Apply Noise Modifier cancelled because there is no active action.", "アクティブアクションがないためノイズ適用を中止しました。")
            return {'CANCELLED'}
        curves = _selected_or_all_curves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves are available.", "対象の F カーブがありません。", context))
            add_log(context, "WARN", "Apply Noise Modifier found no F-Curves.", "対象 F カーブがないためノイズ適用を中止しました。")
            return {'CANCELLED'}

        affected = 0
        for fcurve in curves:
            modifier = next((mod for mod in fcurve.modifiers if mod.name.startswith('SAS_NOISE')), None)
            if modifier is None:
                modifier = fcurve.modifiers.new(type='NOISE')
            modifier.name = 'SAS_NOISE'
            for attr, value in (('strength', settings.noise_strength), ('scale', settings.noise_scale), ('phase', settings.noise_phase), ('depth', settings.noise_depth)):
                try:
                    setattr(modifier, attr, value)
                except Exception:
                    pass
            affected += 1

        self.report({'INFO'}, sas_text(f"Applied noise modifiers to {affected} curves.", f"{affected} 本のカーブにノイズモディファイアを適用しました。", context))
        add_log(context, "INFO", f"Applied noise modifiers to {affected} curves.", f"{affected} 本のカーブにノイズモディファイアを適用しました。")
        return {'FINISHED'}


class SAS_OT_clear_noise_modifier(Operator):
    bl_idname = "sas.clear_noise_modifier"
    bl_label = "Clear Noise Modifier"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove Smart Animation noise modifiers from the selected or active curves.",
            "選択または対象カーブから Smart Animation のノイズモディファイアを削除します。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Clear Noise Modifier cancelled because there is no active action.", "アクティブアクションがないためノイズ解除を中止しました。")
            return {'CANCELLED'}
        removed = 0
        for fcurve in _selected_or_all_curves(context, action):
            removed += remove_sas_modifiers(fcurve, 'SAS_NOISE')
        self.report({'INFO'}, sas_text(f"Removed {removed} noise modifiers.", f"{removed} 個のノイズモディファイアを削除しました。", context))
        add_log(context, "INFO", f"Removed {removed} noise modifiers.", f"{removed} 個のノイズモディファイアを削除しました。")
        return {'FINISHED'}


class SAS_OT_calculate_motion_paths(Operator):
    bl_idname = "sas.calculate_motion_paths"
    bl_label = "Calculate Motion Paths"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Calculate motion paths for the selected bones or objects over the chosen frame range so you can inspect arcs and spacing visually.",
            "選択ボーンまたはオブジェクトのモーションパスを指定範囲で計算し、アークやスペーシングを視覚的に確認できるようにします。",
            context,
        )

    def execute(self, context):
        start, end = get_bake_range(context.scene, context.scene.sas_settings)
        target = active_object(context)
        try:
            if target is None:
                self.report({'WARNING'}, sas_text("No active object.", "アクティブオブジェクトがありません。", context))
                return {'CANCELLED'}
            # Blender 5.1 can crash in the native motion-path operator when it
            # is called after layered-action edits without a 3D View context
            # (notably in background automation). Never enter that C operator
            # without the same area context used by the visible tool.
            if bpy.app.background or _find_context_area(context, ('VIEW_3D',)) is None:
                self.report({'WARNING'}, sas_text(
                    "Calculate Motion Paths requires an open 3D View.",
                    "モーションパス計算には3Dビューが必要です。",
                    context,
                ))
                return {'CANCELLED'}
            motion_settings = target.animation_visualization.motion_path
            motion_settings.type = 'RANGE'
            motion_settings.range = 'MANUAL'
            motion_settings.frame_start = int(start)
            motion_settings.frame_end = int(end)
            if context.mode == 'POSE' and getattr(context, 'selected_pose_bones', None):
                _run_op_in_area(
                    context,
                    lambda: bpy.ops.pose.paths_calculate(display_type='RANGE', range='MANUAL'),
                    object=target,
                    active_object=target,
                )
            else:
                _run_op_in_area(
                    context,
                    lambda: bpy.ops.object.paths_calculate(display_type='RANGE', range='MANUAL'),
                    object=target,
                    active_object=target,
                )
            self.report({'INFO'}, sas_text("Motion paths calculated.", "モーションパスを計算しました。", context))
            add_log(context, "INFO", f"Calculated motion paths for frames {start}-{end}.", f"フレーム {start}-{end} のモーションパスを計算しました。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Motion path calculation failed: {exc}", f"モーションパス計算に失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Motion path calculation failed: {exc}", f"モーションパス計算に失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}


class SAS_OT_clear_motion_paths(Operator):
    bl_idname = "sas.clear_motion_paths"
    bl_label = "Clear Motion Paths"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Clear visible motion paths from the current selection.",
            "現在の選択に表示されているモーションパスをクリアします。",
            context,
        )

    def execute(self, context):
        target = active_object(context)
        try:
            if context.mode == 'POSE' and getattr(context, 'selected_pose_bones', None):
                _run_op_in_area(context, lambda: bpy.ops.pose.paths_clear(only_selected=True), object=target, active_object=target)
            else:
                _run_op_in_area(context, lambda: bpy.ops.object.paths_clear(only_selected=True), object=target, active_object=target)
            self.report({'INFO'}, sas_text("Motion paths cleared.", "モーションパスをクリアしました。", context))
            add_log(context, "INFO", "Cleared motion paths.", "モーションパスをクリアしました。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Clearing motion paths failed: {exc}", f"モーションパスのクリアに失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Clearing motion paths failed: {exc}", f"モーションパスのクリアに失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}


class SAS_OT_dynamic_parent_switch(Operator):
    bl_idname = "sas.dynamic_parent_switch"
    bl_label = "Switch Dynamic Parent"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Create or switch a Child Of-based dynamic parent while preserving the current transform. In Pose Mode, the active bone becomes the child and another selected bone becomes the parent target.",
            "現在の見た目を保ったまま、Child Of ベースの動的親子切り替えを作成または切り替えます。ポーズモードではアクティブボーンが子、他の選択ボーンが親ターゲットになります。",
            context,
        )

    def execute(self, context):
        scene = context.scene
        frame = scene.frame_current
        arm = None

        if context.mode == 'POSE':
            arm = active_object(context)
            owner = context.active_pose_bone
            others = [bone for bone in (context.selected_pose_bones or []) if bone != owner]
            if arm is None or owner is None or not others:
                self.report({'WARNING'}, sas_text("Select an active child bone and one parent target bone.", "子にするアクティブボーンと、親ターゲットとなる別のボーンを選択してください。", context))
                add_log(context, "WARN", "Switch Dynamic Parent cancelled because the pose-bone selection was incomplete.", "ボーン選択が不足しているため動的親切り替えを中止しました。")
                return {'CANCELLED'}
            target_obj = arm
            target_subtarget = others[0].name
            owner_constraints = owner.constraints
            ensure_active_action(context, obj=arm, base_name=f"{arm.name}_Action")
        else:
            owner = active_object(context)
            others = [obj for obj in context.selected_objects if obj != owner]
            if owner is None or not others:
                self.report({'WARNING'}, sas_text("Select an active child object and one parent target object.", "子にするアクティブオブジェクトと、親ターゲットとなる別のオブジェクトを選択してください。", context))
                add_log(context, "WARN", "Switch Dynamic Parent cancelled because the object selection was incomplete.", "オブジェクト選択が不足しているため動的親切り替えを中止しました。")
                return {'CANCELLED'}
            target_obj = others[0]
            target_subtarget = ""
            owner_constraints = owner.constraints
            ensure_active_action(context, obj=owner, base_name=f"{owner.name}_Action")

        preserved_world = _owner_world_matrix(context, owner, armature=arm)
        constraint_name = dynamic_parent_constraint_name(target_obj.name, target_subtarget)
        constraint = next((con for con in owner_constraints if con.name == constraint_name), None)
        if constraint is None:
            constraint = owner_constraints.new(type='CHILD_OF')
            constraint.name = constraint_name
        constraint.target = target_obj
        if hasattr(constraint, 'subtarget'):
            constraint.subtarget = target_subtarget
        constraint.influence = 1.0
        _set_childof_inverse(context, constraint, owner, armature=arm)
        try:
            context.view_layer.update()
        except Exception:
            pass

        if preserved_world is not None:
            _restore_owner_world_matrix(context, owner, preserved_world, armature=arm)
            try:
                context.view_layer.update()
            except Exception:
                pass

        for con in list(owner_constraints):
            if not is_sas_dynamic_parent_constraint(con):
                continue
            if con == constraint:
                _set_constraint_influence_key(context, owner, con, frame - 1, 0.0)
                _set_constraint_influence_key(context, owner, con, frame, 1.0)
            else:
                _set_constraint_influence_key(context, owner, con, frame - 1, float(getattr(con, 'influence', 0.0)))
                _set_constraint_influence_key(context, owner, con, frame, 0.0)

        inserted = _insert_transform_keys_if_autokey(context, owner)
        target_label = f"{target_obj.name}{':' + target_subtarget if target_subtarget else ''}"
        if inserted:
            self.report({'INFO'}, sas_text("Dynamic parent switched and keyed the preserved transform.", "動的親を切り替え、保持した変形をキー化しました。", context))
            add_log(context, "INFO", f"Switched dynamic parent to '{target_label}' and inserted {inserted} transform key paths.", f"動的親を「{target_label}」へ切り替え、{inserted} 個の変形キーパスを挿入しました。")
        else:
            self.report({'INFO'}, sas_text("Dynamic parent switched.", "動的親を切り替えました。", context))
            add_log(context, "INFO", f"Switched dynamic parent to '{target_label}'.", f"動的親を「{target_label}」へ切り替えました。")
        return {'FINISHED'}


class SAS_OT_clear_dynamic_parent(Operator):
    bl_idname = "sas.clear_dynamic_parent"
    bl_label = "Clear Dynamic Parent"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Remove Smart Animation dynamic-parent constraints from the active object or active pose bone.",
            "アクティブオブジェクトまたはアクティブポーズボーンから Smart Animation の動的親制約を削除します。",
            context,
        )

    def execute(self, context):
        if context.mode == 'POSE':
            owner = context.active_pose_bone
            if owner is None:
                self.report({'WARNING'}, sas_text("No active pose bone.", "アクティブなポーズボーンがありません。", context))
                add_log(context, "WARN", "Clear Dynamic Parent cancelled because there is no active pose bone.", "アクティブポーズボーンがないため動的親解除を中止しました。")
                return {'CANCELLED'}
            owner_constraints = owner.constraints
        else:
            owner = active_object(context)
            if owner is None:
                self.report({'WARNING'}, sas_text("No active object.", "アクティブオブジェクトがありません。", context))
                add_log(context, "WARN", "Clear Dynamic Parent cancelled because there is no active object.", "アクティブオブジェクトがないため動的親解除を中止しました。")
                return {'CANCELLED'}
            owner_constraints = owner.constraints

        removed = 0
        for con in list(owner_constraints):
            if is_sas_dynamic_parent_constraint(con):
                # The switch keyed this constraint's influence; drop that curve
                # with the constraint so no invalid channel stays in the action.
                datablock = con.id_data
                action = getattr(getattr(datablock, 'animation_data', None), 'action', None)
                fcurve = find_action_fcurve(action, datablock, con.path_from_id('influence')) if action is not None else None
                if fcurve is not None:
                    remove_action_fcurve(action, fcurve, datablock=datablock)
                owner_constraints.remove(con)
                removed += 1
        self.report({'INFO'}, sas_text(f"Removed {removed} dynamic-parent constraints.", f"{removed} 個の動的親制約を削除しました。", context))
        add_log(context, "INFO", f"Removed {removed} dynamic-parent constraints.", f"{removed} 個の動的親制約を削除しました。")
        return {'FINISHED'}


class SAS_OT_apply_overlap_pass(Operator):
    bl_idname = "sas.apply_overlap_pass"
    bl_label = "Apply Overlap Pass"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Apply a baked overlap pass that pulls later targets toward earlier motion. This is useful for drag, follow-through, tails, ropes, props, and mechanical chain offsets.",
            "後続ターゲットを少し前の動きへ引き寄せるベイク済みオーバーラップ処理を適用します。ドラッグ、フォロースルー、しっぽ、ロープ、小物、機械チェーンの遅れ表現に便利です。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Apply Overlap Pass cancelled because there is no active action.", "アクティブアクションがないためオーバーラップ処理を中止しました。")
            return {'CANCELLED'}

        groups = _overlap_curve_groups(context, action)
        if not groups:
            self.report({'WARNING'}, sas_text("No target curves are available.", "対象カーブがありません。", context))
            add_log(context, "WARN", "Apply Overlap Pass found no target curves.", "対象カーブがないためオーバーラップ処理を中止しました。")
            return {'CANCELLED'}

        start, end = get_timing_range(context, action, settings)
        if settings.preview_only:
            key_count = sum(count_keys_in_frame_range(curves, start, end) for _label, curves in groups)
            message_en = f"Overlap preview — {len(groups)} groups, {key_count} keys inside frames {int(start)}-{int(end)}."
            message_ja = f"オーバーラッププレビュー — {len(groups)} グループ、フレーム {int(start)}-{int(end)} 内のキー数は {key_count} です。"
            self.report({'INFO'}, sas_text(message_en, message_ja, context))
            add_log(context, "INFO", message_en, message_ja)
            return {'FINISHED'}

        ensure_action_backup(context, "overlap")
        changed_keys = 0
        affected_groups = 0
        multi_group = len(groups) > 1
        for index, (_label, curves) in enumerate(groups):
            delay_multiplier = index if multi_group else (index + 1)
            if delay_multiplier <= 0:
                continue
            frame_delay = float(settings.overlap_pass_frames * delay_multiplier)
            strength = float(settings.overlap_pass_blend) * (float(settings.overlap_pass_decay) ** max(0, index - (1 if multi_group else 0)))
            if frame_delay <= 0.0 or strength <= 0.0:
                continue
            local_changes = 0
            for fcurve in curves:
                keys = [key for key in getattr(fcurve, 'keyframe_points', []) if start <= float(key.co.x) <= end]
                if not keys:
                    continue
                samples = {}
                for key in keys:
                    frame = float(key.co.x)
                    try:
                        delayed_value = float(fcurve.evaluate(frame - frame_delay))
                    except Exception:
                        delayed_value = float(key.co.y)
                    samples[frame] = delayed_value
                for key in keys:
                    frame = float(key.co.x)
                    original_value = float(key.co.y)
                    new_value = original_value + (samples[frame] - original_value) * strength
                    if abs(new_value - original_value) <= 1e-8:
                        continue
                    key.co.y = new_value
                    try:
                        key.handle_left.y = new_value
                        key.handle_right.y = new_value
                    except Exception:
                        pass
                    changed_keys += 1
                    local_changes += 1
                try:
                    fcurve.update()
                except Exception:
                    pass
            if local_changes:
                affected_groups += 1

        self.report({'INFO'}, sas_text(f"Applied overlap pass to {affected_groups} groups and {changed_keys} key values.", f"{affected_groups} グループ、{changed_keys} 個のキー値へオーバーラップ処理を適用しました。", context))
        add_log(context, "INFO", f"Applied overlap pass with frame delay {settings.overlap_pass_frames}, blend {settings.overlap_pass_blend:.3f}, decay {settings.overlap_pass_decay:.3f}; affected {affected_groups} groups and {changed_keys} key values.", f"フレーム遅延 {settings.overlap_pass_frames}、ブレンド {settings.overlap_pass_blend:.3f}、減衰 {settings.overlap_pass_decay:.3f} でオーバーラップ処理を適用し、{affected_groups} グループ、{changed_keys} 個のキー値を変更しました。")
        return {'FINISHED'}


class SAS_OT_cascade_delay(Operator):
    bl_idname = "sas.cascade_delay"
    bl_label = "Cascade Delay"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Progressively offset selected targets in time. This is useful for overlap, follow-through, chain motion, and staggered mechanical timing.",
            "選択ターゲットを段階的に時間オフセットします。オーバーラップ、フォロースルー、チェーンモーション、機械系の段差タイミングに便利です。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Cascade Delay cancelled because there is no active action.", "アクティブアクションがないためカスケード遅延を中止しました。")
            return {'CANCELLED'}

        groups = _cascade_curve_groups(context, action)
        if not groups:
            self.report({'WARNING'}, sas_text("No selected targets or curves are available.", "選択ターゲットまたは対象カーブがありません。", context))
            add_log(context, "WARN", "Cascade Delay found no target curve groups.", "対象グループがないためカスケード遅延を中止しました。")
            return {'CANCELLED'}

        ensure_action_backup(context, "cascade")
        start, end = get_timing_range(context, action, settings)
        for index, (_label, curves) in enumerate(groups):
            shift_fcurve_keys(curves, settings.cascade_delay_frames * index, start, end)

        self.report({'INFO'}, sas_text(f"Applied cascade delay to {len(groups)} target groups.", f"{len(groups)} 個のターゲットグループへカスケード遅延を適用しました。", context))
        add_log(context, "INFO", f"Applied cascade delay of {settings.cascade_delay_frames} frames across {len(groups)} groups.", f"{len(groups)} グループへ {settings.cascade_delay_frames} フレームのカスケード遅延を適用しました。")
        return {'FINISHED'}


class SAS_OT_randomize_key_timing(Operator):
    bl_idname = "sas.randomize_key_timing"
    bl_label = "Randomize Key Timing"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Randomly offset each selected or active F-Curve within the configured frame limits. This is useful for crowds, props, and mechanical systems that should not move in perfect sync.",
            "選択または対象の各 F カーブを、設定範囲内でランダムに時間オフセットします。群衆、小物、機械系が完全同期しすぎないようにしたい場合に便利です。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Randomize Key Timing cancelled because there is no active action.", "アクティブアクションがないためランダムタイミングを中止しました。")
            return {'CANCELLED'}
        curves = _selected_or_all_curves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves are available.", "対象の F カーブがありません。", context))
            add_log(context, "WARN", "Randomize Key Timing found no F-Curves.", "対象 F カーブがないためランダムタイミングを中止しました。")
            return {'CANCELLED'}

        ensure_action_backup(context, "randomize")
        start, end = get_timing_range(context, action, settings)
        low = min(settings.random_timing_min, settings.random_timing_max)
        high = max(settings.random_timing_min, settings.random_timing_max)
        rng = random.Random(settings.random_seed)
        for fcurve in curves:
            shift_fcurve_keys([fcurve], rng.randint(low, high), start, end)

        self.report({'INFO'}, sas_text(f"Randomized timing on {len(curves)} curves.", f"{len(curves)} 本のカーブにランダムタイミングを適用しました。", context))
        add_log(context, "INFO", f"Randomized timing on {len(curves)} curves using seed {settings.random_seed} and range {low} to {high}.", f"シード {settings.random_seed}、範囲 {low} から {high} で {len(curves)} 本のカーブにランダムタイミングを適用しました。")
        return {'FINISHED'}


class SAS_OT_smooth_curves(Operator):
    bl_idname = "sas.smooth_curves"
    bl_label = "Smooth Curves"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Smooth selected or active F-Curve values with a gentle averaging pass. This is useful for facial curves, mocap cleanup, and noisy secondary motion.",
            "選択または対象 F カーブの値を、穏やかな平均化でスムージングします。フェイシャル、モーキャプ整理、ノイジーな二次モーションの整形に便利です。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        settings = context.scene.sas_settings
        if action is None:
            self.report({'WARNING'}, sas_text("No active action.", "アクティブなアクションがありません。", context))
            add_log(context, "WARN", "Smooth Curves cancelled because there is no active action.", "アクティブアクションがないためカーブスムージングを中止しました。")
            return {'CANCELLED'}
        curves = _selected_or_all_curves(context, action)
        if not curves:
            self.report({'WARNING'}, sas_text("No F-Curves are available.", "対象の F カーブがありません。", context))
            add_log(context, "WARN", "Smooth Curves found no F-Curves.", "対象 F カーブがないためカーブスムージングを中止しました。")
            return {'CANCELLED'}

        ensure_action_backup(context, "smooth")
        factor = settings.curve_smooth_factor
        iterations = settings.curve_smooth_iterations
        changed = 0
        for _iteration in range(iterations):
            for fcurve in curves:
                keys = fcurve.keyframe_points
                if len(keys) <= 2:
                    continue
                new_values = [keys[0].co.y]
                for index in range(1, len(keys) - 1):
                    local_average = (keys[index - 1].co.y + keys[index].co.y + keys[index + 1].co.y) / 3.0
                    new_values.append(keys[index].co.y + (local_average - keys[index].co.y) * factor)
                new_values.append(keys[-1].co.y)
                for index, value in enumerate(new_values[1:-1], start=1):
                    keys[index].co.y = value
                    keys[index].handle_left.y = value
                    keys[index].handle_right.y = value
                    changed += 1
                fcurve.update()

        self.report({'INFO'}, sas_text(f"Smoothed {changed} key values.", f"{changed} 個のキー値をスムージングしました。", context))
        add_log(context, "INFO", f"Smoothed {changed} key values across {len(curves)} curves.", f"{len(curves)} 本のカーブで {changed} 個のキー値をスムージングしました。")
        return {'FINISHED'}


class SAS_OT_copy_global_transform(Operator):
    bl_idname = "sas.copy_global_transform"
    bl_label = "Copy Global Transform"
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Copy the active object's or active pose bone's world-space transform. This is useful when you want to snap another control to the same placement later without guessing offsets.",
            "アクティブオブジェクト、またはアクティブポーズボーンのワールド変形をコピーします。あとで別のコントロールを同じ位置にスナップしたいときに、オフセットを推測せず使えます。",
            context,
        )

    def execute(self, context):
        kind, target, owner = _clipboard_target_from_context(context)
        if target is None:
            self.report({'WARNING'}, sas_text("No active object or pose bone to copy.", "コピー対象のアクティブオブジェクトまたはポーズボーンがありません。", context))
            add_log(context, "WARN", "Copy Global Transform cancelled because there was no active object or pose bone.", "アクティブオブジェクトまたはポーズボーンがないためワールド変形コピーを中止しました。")
            return {'CANCELLED'}
        try:
            if kind == 'POSE_BONE':
                matrix = owner.matrix_world @ target.matrix.copy()
                name = f"{owner.name}/{target.name}"
            else:
                matrix = target.matrix_world.copy()
                name = target.name
            GLOBAL_TRANSFORM_CLIPBOARD['matrix'] = matrix
            GLOBAL_TRANSFORM_CLIPBOARD['source_kind'] = kind
            GLOBAL_TRANSFORM_CLIPBOARD['source_name'] = name
            self.report({'INFO'}, sas_text(f"Copied global transform from {name}.", f"{name} のワールド変形をコピーしました。", context))
            add_log(context, "INFO", f"Copied global transform from {name}.", f"{name} のワールド変形をコピーしました。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Copy Global Transform failed: {exc}", f"ワールド変形コピーに失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Copy Global Transform failed: {exc}", f"ワールド変形コピーに失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}


class SAS_OT_paste_global_transform(Operator):
    bl_idname = "sas.paste_global_transform"
    bl_label = "Paste Global Transform"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Paste the stored world-space transform onto the active object or active pose bone. When Blender Auto Key is enabled, the snapped result is keyed on the current frame.",
            "保存したワールド変形を、アクティブオブジェクトまたはアクティブポーズボーンへ貼り付けます。Blender の自動キーが有効なら、スナップ結果を現在フレームにキー化します。",
            context,
        )

    def execute(self, context):
        stored = GLOBAL_TRANSFORM_CLIPBOARD.get('matrix')
        if stored is None:
            self.report({'WARNING'}, sas_text("The global-transform clipboard is empty.", "ワールド変形クリップボードが空です。", context))
            add_log(context, "WARN", "Paste Global Transform cancelled because the clipboard was empty.", "ワールド変形クリップボードが空のため貼り付けを中止しました。")
            return {'CANCELLED'}

        kind, target, owner = _clipboard_target_from_context(context)
        if target is None:
            self.report({'WARNING'}, sas_text("No active object or pose bone to paste onto.", "貼り付け先のアクティブオブジェクトまたはポーズボーンがありません。", context))
            add_log(context, "WARN", "Paste Global Transform cancelled because there was no active object or pose bone.", "アクティブオブジェクトまたはポーズボーンがないためワールド変形貼り付けを中止しました。")
            return {'CANCELLED'}

        try:
            if kind == 'POSE_BONE':
                target.matrix = owner.matrix_world.inverted() @ stored
                name = f"{owner.name}/{target.name}"
            else:
                target.matrix_world = stored.copy()
                name = target.name

            try:
                context.view_layer.update()
            except Exception:
                pass

            inserted = _insert_transform_keys_if_autokey(context, target)
            source_name = GLOBAL_TRANSFORM_CLIPBOARD.get('source_name') or 'clipboard'
            if inserted:
                self.report({'INFO'}, sas_text(f"Pasted global transform from {source_name} to {name} and inserted {inserted} key paths.", f"{source_name} から {name} へワールド変形を貼り付け、{inserted} 個のキーパスを挿入しました。", context))
                add_log(context, "INFO", f"Pasted global transform from {source_name} to {name} with {inserted} auto keys.", f"{source_name} から {name} へワールド変形を貼り付け、{inserted} 個の自動キーを挿入しました。")
            else:
                self.report({'INFO'}, sas_text(f"Pasted global transform from {source_name} to {name}.", f"{source_name} から {name} へワールド変形を貼り付けました。", context))
                add_log(context, "INFO", f"Pasted global transform from {source_name} to {name}.", f"{source_name} から {name} へワールド変形を貼り付けました。")
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Paste Global Transform failed: {exc}", f"ワールド変形貼り付けに失敗しました: {sas_error_reason(exc)}", context))
            add_log(context, "ERROR", f"Paste Global Transform failed: {exc}", f"ワールド変形貼り付けに失敗しました: {sas_error_reason(exc)}")
            return {'CANCELLED'}


OPERATOR_CLASSES = (
    SAS_OT_smart_assist,
    SAS_OT_insert_keys,
    SAS_OT_bake_visual_keys,
    SAS_OT_add_marker,
    SAS_OT_jump_marker,
    SAS_OT_mark_selected_keys,
    SAS_OT_shift_keys,
    SAS_OT_scale_key_timing,
    SAS_OT_distribute_key_timing,
    SAS_OT_insert_shape_key_keys,
    SAS_OT_smooth_shape_key_curves,
    SAS_OT_optimize_shape_key_curves,
    SAS_OT_apply_tween,
    SAS_OT_push_pull_keys,
    SAS_OT_scale_to_neighbors,
    SAS_OT_apply_contact_hold,
    SAS_OT_smart_unbake,
    SAS_OT_euler_filter,
    SAS_OT_apply_tangent_preset,
    SAS_OT_apply_stepped_preview,
    SAS_OT_bake_step_keys,
    SAS_OT_clear_stepped_preview,
    SAS_OT_apply_noise_modifier,
    SAS_OT_clear_noise_modifier,
    SAS_OT_apply_cycles_preset,
    SAS_OT_clear_cycles_preset,
    SAS_OT_calculate_motion_paths,
    SAS_OT_clear_motion_paths,
    SAS_OT_create_trail_curve,
    SAS_OT_clear_trail_curves,
    SAS_OT_create_ghost_preview,
    SAS_OT_clear_ghost_preview,
    SAS_OT_create_ballistic_guide,
    SAS_OT_bake_ballistic_keys,
    SAS_OT_clear_ballistic_guides,
    SAS_OT_apply_camera_shake_preset,
    SAS_OT_clear_camera_shake,
    SAS_OT_dynamic_parent_switch,
    SAS_OT_clear_dynamic_parent,
    SAS_OT_copy_global_transform,
    SAS_OT_paste_global_transform,
    SAS_OT_apply_overlap_pass,
    SAS_OT_cascade_delay,
    SAS_OT_randomize_key_timing,
    SAS_OT_preview_cleanup,
    SAS_OT_simplify_curves,
    SAS_OT_smooth_curves,
    SAS_OT_delete_static_channels,
    SAS_OT_remove_duplicate_keys,
    SAS_OT_pose_mirror,
    SAS_OT_pose_reset,
    SAS_OT_store_selection_set,
    SAS_OT_apply_selection_set,
    SAS_OT_remove_selection_set,
    SAS_OT_export_selection_sets,
    SAS_OT_import_selection_sets,
    SAS_OT_store_pose_snapshot,
    SAS_OT_apply_pose_snapshot,
    SAS_OT_apply_snapshot_blend,
    SAS_OT_remove_pose_snapshot,
    SAS_OT_export_pose_snapshots,
    SAS_OT_import_pose_snapshots,
    SAS_OT_new_action,
    SAS_OT_duplicate_action,
    SAS_OT_push_action_to_nla,
    SAS_OT_build_layer_stack,
    SAS_OT_add_animation_layer,
    SAS_OT_add_camera_marker,
    SAS_OT_jump_camera_marker,
    SAS_OT_set_preview_range_from_keys,
    SAS_OT_set_preview_range_from_sound,
    SAS_OT_set_preview_range_from_camera_markers,
    SAS_OT_set_contact_hold_range_from_keys,
    SAS_OT_clear_preview_range,
    SAS_OT_apply_playback_preset,
    SAS_OT_add_action_to_library,
    SAS_OT_remove_action_from_library,
    SAS_OT_assign_library_action,
    SAS_OT_push_library_action_to_nla,
    SAS_OT_export_library_manifest,
    SAS_OT_import_library_manifest,
    SAS_OT_prune_action_library,
    SAS_OT_build_bone_map,
    SAS_OT_refresh_live_retarget,
    SAS_OT_apply_live_retarget,
    SAS_OT_bake_live_retarget,
    SAS_OT_export_bone_map,
    SAS_OT_import_bone_map,
    SAS_OT_create_root_motion_action,
    SAS_OT_create_in_place_action,
    SAS_OT_build_live_retarget,
    SAS_OT_clear_live_retarget,
    SAS_OT_auto_fix_scene_basics,
    SAS_OT_run_scene_audit,
    SAS_OT_clear_operation_log,
    SAS_OT_export_report,
)

# -----------------------------------------------------------------------------
# Panel
# -----------------------------------------------------------------------------
