# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Prepare suite operators for a single Blender undo step per data edit."""

from functools import wraps

try:
    import bpy
except ImportError:
    bpy = None

# UI, file, configuration and navigation commands do not edit scene data.
_ID_EXCLUSIONS = {
    "ui": (
        "show_help", "open_help", "show_popup", "help_popup", "toggle_ui_section",
        "toggle_section", "toggle_editor_mode", "sidebar", "set_storyboard_workspace",
    ),
    "config": (
        "set_always_on", "toggle_persistent_feature", "save_preferences", "save_settings",
        "load_settings", "write_config", "read_config", "preferences", "keymap_item",
        "tool_preset_shortcut",
    ),
    "runtime": (
        "load_tool", "unload_tool", "refresh_tool", "reload_tool", "diagnostic", "run_scene_audit",
        "status", "refresh_status",
    ),
    "files": (
        "export_", "import_", "save_to_", "load_from_", "save_pose_to_", "load_pose_from_",
        "prep_file_for_farm", "open_preset_file", "save_preset", "load_preset", "browse_",
        "pick_file", "open_url", "copy_to_clipboard", "copy_path",
    ),
    "navigation": ("jump_marker", "jump_camera_marker", "apply_playback_preset"),
}
_NON_UNDO_ID_FRAGMENTS = tuple(key for group in _ID_EXCLUSIONS.values() for key in group)
_undo_flags = {"UNDO", "UNDO_GROUPED"}


def is_operator_class(cls):
    return bpy is not None and isinstance(cls, type) and issubclass(cls, bpy.types.Operator)


def _option_set(cls):
    value = getattr(cls, "bl_options", None)
    if isinstance(value, str):
        return {value}
    try:
        return set(value or ())
    except TypeError:
        return set()


def operator_is_non_undo(cls):
    if getattr(cls, "_sms_no_undo", False) or getattr(cls, "_sas_no_undo", False):
        return True
    if getattr(cls, "_sas_data_operator", False):
        return False
    identifier = str(getattr(cls, "bl_idname", "") or "").lower()
    return any(phrase in identifier for phrase in _NON_UNDO_ID_FRAGMENTS)


def _invalidate_animation_cache(context=None):
    try:
        from . import ui
        ui.invalidate_performance_cache(reason="operator_finished", context=context)
    except Exception:
        # A redraw/cache problem must not undo a successful data edit.
        return


def _result_finished(result):
    try:
        return any(str(signal) == "FINISHED" for signal in result)
    except Exception:
        return False


def _wrap_explicit_execute(cls):
    local = vars(cls)
    operation = local.get("execute")
    if local.get("_sas_cache_invalidation_wrapped") or not callable(operation):
        return

    @wraps(operation)
    def finish(self, context):
        outcome = operation(self, context)
        if _result_finished(outcome):
            _invalidate_animation_cache(context)
        return outcome

    cls.execute = finish
    cls._sas_original_execute = operation
    cls._sas_cache_invalidation_wrapped = True


def ensure_operator_undo(cls):
    if not is_operator_class(cls):
        return cls
    flags = _option_set(cls)
    if {"REGISTER", "UNDO"} <= flags:
        flags.remove("REGISTER")
    if operator_is_non_undo(cls):
        flags.difference_update(_undo_flags)
    elif "UNDO_GROUPED" in flags or getattr(cls, "_sas_data_operator", False):
        flags.discard("UNDO_GROUPED")
        flags.add("UNDO")
    cls.bl_options = flags
    _wrap_explicit_execute(cls)
    return cls
