# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

"""Strict, crash-safe JSON persistence for Smart Animation Suite.

The public helpers deliberately perform file I/O only when called from property
updates or explicit lifecycle/operator boundaries.  Panel ``draw`` and ``poll``
code must never call this module.
"""

import copy
from contextlib import contextmanager
import json
import os
from pathlib import Path
import shutil
import tempfile
from typing import Any

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover - static/unit harness
    bpy = None  # type: ignore

CONFIG_DIRNAME = 'Smart_Animation_Suite'
CONFIG_FILENAME = 'Smart_Animation_Suite.json'
CONFIG_SCHEMA_VERSION = 3
CONFIG_ADDON_NAME = 'Smart Animation Suite'
_MAX_CONFIG_BYTES = 8 * 1024 * 1024
_MAX_REVISION = (1 << 63) - 1

_LAST_WRITTEN_TEXT: str | None = None
_LAST_READ_SIGNATURE: tuple[int, int] | None = None
_LAST_READ_PAYLOAD: dict[str, Any] | None = None
_LAST_READ_SOURCE = 'NONE'
_READ_BLOCKED_BY_CORRUPTION = False
_WRITE_ENABLED = True
_RESTORE_DEPTH = 0
_LAST_WRITE_STATUS = 'NONE'
_OWNER_GENERATION = 0
_OWNER_SETTINGS_POINTER = 0
_OWNER_SCENE_POINTER = 0
_CAPABILITY_SENTINEL = object()
_ACTIVE_OFF_CAPABILITY = None


class _OffCommitCapability:
    __slots__ = ('_sentinel', 'generation', 'settings_pointer', 'scene_pointer', 'consumed')

    def __init__(self, sentinel, generation: int, settings_pointer: int, scene_pointer: int):
        if sentinel is not _CAPABILITY_SENTINEL:
            raise TypeError('opaque capability')
        self._sentinel = sentinel
        self.generation = int(generation)
        self.settings_pointer = int(settings_pointer)
        self.scene_pointer = int(scene_pointer)
        self.consumed = False


def set_write_enabled(enabled: bool) -> None:
    """Set the process-wide event-persistence policy without touching disk."""
    global _WRITE_ENABLED, _ACTIVE_OFF_CAPABILITY
    if _ACTIVE_OFF_CAPABILITY is not None:
        _ACTIVE_OFF_CAPABILITY.consumed = True
        _ACTIVE_OFF_CAPABILITY = None
    _WRITE_ENABLED = bool(enabled)


def write_enabled() -> bool:
    return bool(_WRITE_ENABLED)


def restore_active() -> bool:
    return bool(_RESTORE_DEPTH > 0)


@contextmanager
def restore_transaction():
    """Block every writer while saved RNA is being restored.

    The barrier lives below all feature-specific writers, so a nested callback,
    force/fallback flush, or shutdown path cannot serialize a partial restore.
    """
    global _RESTORE_DEPTH
    _RESTORE_DEPTH += 1
    try:
        yield
    finally:
        _RESTORE_DEPTH = max(0, _RESTORE_DEPTH - 1)


def bind_owner_generation(
    generation: int, *, settings_pointer: int, scene_pointer: int,
) -> bool:
    """Bind the lower writer to one exact live Suite owner identity."""
    global _OWNER_GENERATION, _OWNER_SETTINGS_POINTER, _OWNER_SCENE_POINTER
    global _ACTIVE_OFF_CAPABILITY
    value = int(generation or 0)
    settings_key = int(settings_pointer or 0)
    scene_key = int(scene_pointer or 0)
    if value <= 0 or settings_key <= 0 or scene_key <= 0 or restore_active():
        return False
    if (
        value == int(_OWNER_GENERATION)
        and settings_key == int(_OWNER_SETTINGS_POINTER)
        and scene_key == int(_OWNER_SCENE_POINTER)
    ):
        # Re-observing the same live owner is idempotent. In particular, it
        # must not revoke a genuine OFF capability between issue and commit.
        return True
    if _ACTIVE_OFF_CAPABILITY is not None:
        _ACTIVE_OFF_CAPABILITY.consumed = True
        _ACTIVE_OFF_CAPABILITY = None
    _OWNER_GENERATION = value
    _OWNER_SETTINGS_POINTER = settings_key
    _OWNER_SCENE_POINTER = scene_key
    return True


def clear_owner_generation(generation: int = 0) -> None:
    global _OWNER_GENERATION, _OWNER_SETTINGS_POINTER, _OWNER_SCENE_POINTER
    global _ACTIVE_OFF_CAPABILITY
    if generation and int(generation) != int(_OWNER_GENERATION):
        return
    if _ACTIVE_OFF_CAPABILITY is not None:
        _ACTIVE_OFF_CAPABILITY.consumed = True
        _ACTIVE_OFF_CAPABILITY = None
    _OWNER_GENERATION = 0
    _OWNER_SETTINGS_POINTER = 0
    _OWNER_SCENE_POINTER = 0


def issue_off_commit_capability(
    *, owner_generation: int, settings_pointer: int, scene_pointer: int,
    previous_enabled: bool, current_enabled: bool,
):
    """Consume the genuine process ON->OFF edge and mint one opaque commit.

    Issuance itself closes the ordinary writer gate. The returned object is
    valid only by exact identity and is consumed before the first read, even
    when the eventual atomic replace fails.
    """
    global _WRITE_ENABLED, _ACTIVE_OFF_CAPABILITY, _LAST_WRITE_STATUS
    generation = int(owner_generation or 0)
    settings_key = int(settings_pointer or 0)
    scene_key = int(scene_pointer or 0)
    if (
        restore_active() or not _WRITE_ENABLED or generation <= 0
        or generation != int(_OWNER_GENERATION)
        or settings_key <= 0 or scene_key <= 0
        or settings_key != int(_OWNER_SETTINGS_POINTER)
        or scene_key != int(_OWNER_SCENE_POINTER)
        or previous_enabled is not True or current_enabled is not False
        or (_ACTIVE_OFF_CAPABILITY is not None and not _ACTIVE_OFF_CAPABILITY.consumed)
    ):
        _LAST_WRITE_STATUS = 'OFF_CAPABILITY_REJECTED'
        return None
    capability = _OffCommitCapability(_CAPABILITY_SENTINEL, generation, settings_key, scene_key)
    _ACTIVE_OFF_CAPABILITY = capability
    _WRITE_ENABLED = False
    _LAST_WRITE_STATUS = 'OFF_CAPABILITY_ISSUED'
    return capability


def _authorize_write(capability=None) -> bool:
    global _ACTIVE_OFF_CAPABILITY, _LAST_WRITE_STATUS
    if restore_active():
        if capability is not None and capability is _ACTIVE_OFF_CAPABILITY:
            capability.consumed = True
            _ACTIVE_OFF_CAPABILITY = None
        _LAST_WRITE_STATUS = 'BLOCKED_RESTORE'
        return False
    if _WRITE_ENABLED:
        if capability is not None:
            _LAST_WRITE_STATUS = 'UNEXPECTED_CAPABILITY_WHILE_ENABLED'
            return False
        if int(_OWNER_GENERATION) <= 0:
            _LAST_WRITE_STATUS = 'BLOCKED_UNBOUND'
            return False
        return True
    valid = (
        capability is not None
        and capability is _ACTIVE_OFF_CAPABILITY
        and isinstance(capability, _OffCommitCapability)
        and capability._sentinel is _CAPABILITY_SENTINEL
        and not capability.consumed
        and int(capability.generation) == int(_OWNER_GENERATION)
        and int(capability.settings_pointer) == int(_OWNER_SETTINGS_POINTER)
        and int(capability.scene_pointer) == int(_OWNER_SCENE_POINTER)
    )
    if not valid:
        _LAST_WRITE_STATUS = 'BLOCKED_DISABLED'
        return False
    # Consume before read/path/filesystem work; failures cannot be retried.
    capability.consumed = True
    _ACTIVE_OFF_CAPABILITY = None
    _LAST_WRITE_STATUS = 'OFF_CAPABILITY_CONSUMED'
    return True


def _blender_version() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None) if bpy is not None else None
        if version and len(version) >= 2:
            return f'{int(version[0])}.{int(version[1])}'
    except Exception:
        pass
    return '5.1'


def blender_config_root(*, create: bool = True) -> Path:
    """Return Blender's versioned user config directory."""
    if bpy is not None:
        try:
            user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource')
            value = user_resource('CONFIG', create=bool(create))
        except Exception:
            value = ''
        if value:
            path = Path(value)
            if create:
                path.mkdir(parents=True, exist_ok=True)
            return path

    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config'
    else:
        path = Path.home() / '.config' / 'blender' / version / 'config'
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def config_dir(*, create: bool = True) -> Path:
    path = blender_config_root(create=create) / CONFIG_DIRNAME
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def config_path(*, create: bool = True) -> Path:
    path = config_dir(create=create) / CONFIG_FILENAME
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def backup_path(*, create: bool = True) -> Path:
    path = config_path(create=create)
    return path.with_suffix(path.suffix + '.bak')


def legacy_config_path(*, create: bool = False) -> Path:
    path = blender_config_root(create=create) / CONFIG_FILENAME
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _base_payload() -> dict[str, Any]:
    return {
        'schema_version': CONFIG_SCHEMA_VERSION,
        'revision': 0,
        'addon': CONFIG_ADDON_NAME,
    }


def _file_signature(path: Path) -> tuple[int, int] | None:
    try:
        stat = path.stat()
        return (
            int(getattr(stat, 'st_mtime_ns', int(stat.st_mtime * 1_000_000_000))),
            int(stat.st_size),
        )
    except Exception:
        return None


def _normalize_payload(raw: Any, *, permit_legacy: bool = True) -> dict[str, Any] | None:
    if not isinstance(raw, dict):
        return None
    payload = copy.deepcopy(raw)
    schema = payload.get('schema_version', 1 if permit_legacy else None)
    try:
        schema_int = int(schema)
    except Exception:
        return None
    if schema_int < 1 or schema_int > CONFIG_SCHEMA_VERSION:
        return None
    addon = str(payload.get('addon') or '').strip()
    if addon and addon not in {CONFIG_ADDON_NAME, 'Smart_Animation_Suite'}:
        return None
    try:
        revision = int(payload.get('revision', 0) or 0)
    except Exception:
        return None
    if revision < 0 or revision > _MAX_REVISION:
        return None
    payload['schema_version'] = CONFIG_SCHEMA_VERSION
    payload['revision'] = revision
    payload['addon'] = CONFIG_ADDON_NAME
    return payload


def _read_validated(path: Path, *, permit_legacy: bool = True) -> tuple[dict[str, Any] | None, str]:
    try:
        if not path.exists():
            return None, 'MISSING'
        if not path.is_file():
            return None, 'NOT_FILE'
        size = int(path.stat().st_size)
        if size <= 0 or size > _MAX_CONFIG_BYTES:
            return None, 'SIZE'
        text = path.read_text(encoding='utf-8')
        raw = json.loads(text)
        payload = _normalize_payload(raw, permit_legacy=permit_legacy)
        if payload is None:
            return None, 'SCHEMA'
        return payload, 'OK'
    except UnicodeDecodeError:
        return None, 'UTF8'
    except json.JSONDecodeError:
        return None, 'JSON'
    except Exception:
        return None, 'IO'


def _deepcopy(value: dict[str, Any]) -> dict[str, Any]:
    try:
        return copy.deepcopy(value)
    except Exception:
        return dict(value)


def read_status() -> dict[str, Any]:
    """Return scalar diagnostics; no file handles or RNA references are exposed."""
    return {
        'source': str(_LAST_READ_SOURCE),
        'blocked_by_corruption': bool(_READ_BLOCKED_BY_CORRUPTION),
        'cached': isinstance(_LAST_READ_PAYLOAD, dict),
        'write_enabled': bool(_WRITE_ENABLED),
        'restore_depth': int(_RESTORE_DEPTH),
        'owner_generation': int(_OWNER_GENERATION),
        'off_capability_active': bool(_ACTIVE_OFF_CAPABILITY is not None and not _ACTIVE_OFF_CAPABILITY.consumed),
        'last_write_status': str(_LAST_WRITE_STATUS),
    }


def clear_cache() -> None:
    global _LAST_WRITTEN_TEXT, _LAST_READ_SIGNATURE, _LAST_READ_PAYLOAD
    global _LAST_READ_SOURCE, _READ_BLOCKED_BY_CORRUPTION
    _LAST_WRITTEN_TEXT = None
    _LAST_READ_SIGNATURE = None
    _LAST_READ_PAYLOAD = None
    _LAST_READ_SOURCE = 'NONE'
    _READ_BLOCKED_BY_CORRUPTION = False


def read_all() -> dict[str, Any]:
    """Read the authoritative config, recovering from a validated backup.

    A malformed primary file is never silently replaced with defaults.  When no
    validated backup exists, the returned base payload is read-only and future
    writes are blocked until the user repairs/removes the corrupt file.
    """
    global _LAST_READ_SIGNATURE, _LAST_READ_PAYLOAD, _LAST_READ_SOURCE
    global _READ_BLOCKED_BY_CORRUPTION

    primary = config_path(create=False)
    signature = _file_signature(primary)
    if signature is not None and signature == _LAST_READ_SIGNATURE and isinstance(_LAST_READ_PAYLOAD, dict):
        return _deepcopy(_LAST_READ_PAYLOAD)

    payload, status = _read_validated(primary)
    source = 'PRIMARY'
    blocked = False

    if payload is None and status != 'MISSING':
        recovered, backup_status = _read_validated(backup_path(create=False))
        if recovered is not None:
            payload = recovered
            source = 'BACKUP'
        else:
            blocked = True
            source = f'CORRUPT_PRIMARY:{status};BACKUP:{backup_status}'

    if payload is None and status == 'MISSING':
        recovered, backup_status = _read_validated(backup_path(create=False))
        if recovered is not None:
            payload = recovered
            source = 'BACKUP_ONLY'
        else:
            legacy, legacy_status = _read_validated(legacy_config_path(create=False))
            if legacy is not None:
                payload = legacy
                source = 'LEGACY'
            else:
                payload = _base_payload()
                source = 'NEW' if legacy_status == 'MISSING' else f'LEGACY_INVALID:{legacy_status}'

    normalized = _normalize_payload(payload)
    if normalized is None:
        normalized = _base_payload()
        blocked = True
        if not str(source).startswith('CORRUPT_PRIMARY:'):
            source = 'INVALID_MEMORY_PAYLOAD'

    _LAST_READ_SIGNATURE = signature
    _LAST_READ_PAYLOAD = _deepcopy(normalized)
    _LAST_READ_SOURCE = source
    _READ_BLOCKED_BY_CORRUPTION = blocked
    return _deepcopy(normalized)


def _json_text(payload: dict[str, Any]) -> str | None:
    try:
        return json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + '\n'
    except Exception:
        return None


def _fsync_directory(path: Path) -> None:
    if os.name == 'nt':
        return
    try:
        fd = os.open(str(path), os.O_RDONLY)
    except Exception:
        return
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _atomic_write_text(path: Path, text: str) -> bool:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_name = ''
    try:
        with tempfile.NamedTemporaryFile(
            mode='w', encoding='utf-8', newline='\n',
            prefix=f'.{path.name}.', suffix='.tmp', dir=str(path.parent), delete=False,
        ) as handle:
            temp_name = handle.name
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        temp_path = Path(temp_name)
        verified, status = _read_validated(temp_path, permit_legacy=False)
        if verified is None or status != 'OK':
            return False
        os.replace(temp_path, path)
        temp_name = ''
        _fsync_directory(path.parent)
        return True
    except Exception:
        return False
    finally:
        if temp_name:
            try:
                Path(temp_name).unlink(missing_ok=True)
            except Exception:
                pass


def _copy_valid_file_atomic(source: Path, target: Path) -> bool:
    payload, status = _read_validated(source)
    if payload is None or status != 'OK':
        return False
    text = _json_text(payload)
    return bool(text is not None and _atomic_write_text(target, text))


def _write_all_authorized(data: dict[str, Any], *, allow_corrupt_recovery: bool = False) -> bool:
    """Atomically write a validated revision and verify the readback.

    Unless a valid backup was loaded, a corrupt primary file blocks writes. This
    prevents a partially initialized/default snapshot from destroying the only
    evidence of the user's configuration.
    """
    global _LAST_WRITTEN_TEXT, _LAST_READ_SIGNATURE, _LAST_READ_PAYLOAD
    global _LAST_READ_SOURCE, _READ_BLOCKED_BY_CORRUPTION
    global _LAST_WRITE_STATUS

    if not isinstance(data, dict):
        _LAST_WRITE_STATUS = 'INVALID_DATA'
        return False

    # Refresh corruption state before deciding whether a write is safe.
    current = read_all()
    if _READ_BLOCKED_BY_CORRUPTION and not allow_corrupt_recovery:
        _LAST_WRITE_STATUS = 'BLOCKED_CORRUPTION'
        return False

    payload = _normalize_payload(data)
    if payload is None:
        _LAST_WRITE_STATUS = 'INVALID_SCHEMA'
        return False
    comparable_current = _deepcopy(current)
    comparable_payload = _deepcopy(payload)
    comparable_current.pop('revision', None)
    comparable_payload.pop('revision', None)
    if comparable_current == comparable_payload:
        _LAST_WRITE_STATUS = 'UNCHANGED'
        return True
    try:
        current_revision = int(current.get('revision', 0) or 0)
        requested_revision = int(payload.get('revision', 0) or 0)
        payload['revision'] = max(current_revision, requested_revision) + 1
    except Exception:
        return False
    payload['schema_version'] = CONFIG_SCHEMA_VERSION
    payload['addon'] = CONFIG_ADDON_NAME

    text = _json_text(payload)
    if text is None or len(text.encode('utf-8')) > _MAX_CONFIG_BYTES:
        return False

    path = config_path(create=True)
    backup = backup_path(create=True)

    existing, existing_status = _read_validated(path)
    if existing is not None and existing_status == 'OK':
        if not _copy_valid_file_atomic(path, backup):
            _LAST_WRITE_STATUS = 'BACKUP_FAILED'
            return False
    elif existing_status != 'MISSING':
        recovered, _ = _read_validated(backup)
        if recovered is None and not allow_corrupt_recovery:
            _READ_BLOCKED_BY_CORRUPTION = True
            _LAST_WRITE_STATUS = f'BLOCKED_EXISTING:{existing_status}'
            return False

    if not _atomic_write_text(path, text):
        _LAST_WRITE_STATUS = 'REPLACE_FAILED'
        return False

    readback, status = _read_validated(path, permit_legacy=False)
    if readback is None or status != 'OK':
        # Restore only a validated backup; never copy an invalid file.
        _copy_valid_file_atomic(backup, path)
        return False
    if readback != payload:
        _copy_valid_file_atomic(backup, path)
        return False

    # Ensure a first successful write also leaves a validated recovery point.
    backup_payload, _ = _read_validated(backup)
    if backup_payload is None:
        _copy_valid_file_atomic(path, backup)

    _LAST_WRITTEN_TEXT = text
    _LAST_READ_SIGNATURE = _file_signature(path)
    _LAST_READ_PAYLOAD = _deepcopy(payload)
    _LAST_READ_SOURCE = 'PRIMARY'
    _READ_BLOCKED_BY_CORRUPTION = False
    _LAST_WRITE_STATUS = 'WRITTEN'
    return True


def write_all(
    data: dict[str, Any], *, allow_corrupt_recovery: bool = False,
    off_commit_capability=None,
) -> bool:
    # Authority is consumed before read_all/config_path/filesystem effects.
    if not _authorize_write(off_commit_capability):
        return False
    return _write_all_authorized(data, allow_corrupt_recovery=allow_corrupt_recovery)


def get_section(name: str, default: Any = None) -> Any:
    key = str(name or '').strip()
    if not key:
        return default
    data = read_all()
    value = data.get(key, default)
    try:
        return copy.deepcopy(value)
    except Exception:
        return value


def set_section(name: str, value: Any, *, off_commit_capability=None) -> bool:
    global _LAST_WRITE_STATUS
    key = str(name or '').strip()
    if not key:
        return False
    if not _authorize_write(off_commit_capability):
        return False
    data = read_all()
    if _READ_BLOCKED_BY_CORRUPTION:
        _LAST_WRITE_STATUS = 'BLOCKED_CORRUPTION'
        return False
    try:
        data[key] = copy.deepcopy(value)
    except Exception:
        data[key] = value
    return _write_all_authorized(data)


def _deep_merge_dict(target: dict[str, Any], updates: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(target)
    for key, value in updates.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge_dict(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def update_section(name: str, values: dict[str, Any], *, off_commit_capability=None) -> bool:
    global _LAST_WRITE_STATUS
    key = str(name or '').strip()
    if not key or not isinstance(values, dict):
        return False
    if not _authorize_write(off_commit_capability):
        return False
    data = read_all()
    if _READ_BLOCKED_BY_CORRUPTION:
        _LAST_WRITE_STATUS = 'BLOCKED_CORRUPTION'
        return False
    section = data.get(key)
    if not isinstance(section, dict):
        section = {}
    section = _deep_merge_dict(section, values)
    data[key] = section
    return _write_all_authorized(data)
