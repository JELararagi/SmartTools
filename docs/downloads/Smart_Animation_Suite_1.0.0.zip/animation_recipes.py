# ============================================================================
# Animation Recipes
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
# ============================================================================

from __future__ import annotations

import json
import math
from typing import Iterable

import bpy
from bpy.types import Operator
from mathutils import Vector

from .translation import sas_error_reason, sas_is_japanese, sas_text
from .core import (
    discard_action_backup,
    active_action,
    active_object,
    add_log,
    batch_action_backup,
    ensure_action_backup,
    filter_editable_fcurves,
    get_bake_range,
    get_or_create_action_for_object,
    get_or_create_text,
    safe_remove_keyframe_points,
    selected_fcurves,
    simplify_point_indices,
)
from .action_compat import iter_action_fcurves


# -----------------------------------------------------------------------------
# Feature matrix
# -----------------------------------------------------------------------------

SMART_FEATURE_MATRIX = (
    ("Maya Graph Editor", "Graph Optimizer / Tangent Presets / Euler Filter", "sas.smart_graph_optimizer, sas.apply_tangent_preset, sas.euler_filter"),
    ("Maya Animation Layers", "NLA Layer Stack Plus", "sas.add_animation_layer, sas.build_layer_stack"),
    ("Maya Motion Trails / Ghosting", "Smart Visualizer", "sas.smart_visualize_motion, sas.create_trail_curve, sas.create_ghost_preview"),
    ("Maya Cached Playback", "Viewport-safe diagnostic and preview workflow", "sas.run_scene_audit, Blender playback cache"),
    ("Maya Time Slider / Range Slider", "Timeline Range Hub", "sas.set_preview_range_from_keys, sas.set_preview_range_from_sound"),
    ("animBot", "Motion Director", "sas.smart_motion_director, sas.apply_tween, sas.push_pull_keys, sas.scale_to_neighbors"),
    ("Studio Library", "Pose / Motion Catalog", "sas.store_pose_snapshot, sas.add_action_to_library, sas.sequence_library_actions"),
    ("BroDynamics", "Physics Director / Spring Bake", "sas.smart_physics_director, sas.bake_spring_dynamics, sas.bake_spring_magic"),
    ("Tweeener", "Overshoot-aware Tween", "sas.apply_tween"),
    ("TwosifyAnimation", "Limited Animation Baker", "sas.bake_step_keys, sas.bake_limited_animation"),
    ("Overlapper", "Overlap / Cascade / Spring Pass", "sas.apply_overlap_pass, sas.cascade_delay, sas.bake_spring_dynamics"),
    ("BH Ghost", "Mesh Ghost Preview", "sas.create_ghost_preview"),
    ("Red9 Studio Pack", "Pose Mirror / Retarget / Transfer", "sas.pose_mirror, sas.build_live_retarget, sas.bake_live_retarget"),
    ("AnimSchool Picker", "Selection Set Picker", "sas.store_selection_set, sas.apply_selection_set"),
    ("Carbon Kinematic Nodes", "Physics/constraint bridge to editable keys", "sas.bake_rigid_body_keys, sas.dynamic_parent_switch"),
    ("MotionMaker", "Cycle Locomotion Generator", "sas.smart_generate_locomotion_cycle"),
    ("Blender Dope Sheet / Action Editor", "Action / Timing Hub", "sas.shift_keys, sas.scale_key_timing, sas.distribute_key_timing"),
    ("Blender Graph Editor Modifiers", "Loop / Noise / Graph Cleaner", "sas.apply_cycles_preset, sas.apply_noise_modifier, sas.smart_graph_optimizer"),
    ("Blender NLA", "Motion Mixer Plus", "sas.push_action_to_nla, sas.sequence_library_actions"),
    ("Blender Shape Keys", "Shape Control Mixer", "sas.smart_shape_control_mixer"),
    ("Pose Library", "Pose Snapshot Blend", "sas.store_pose_snapshot, sas.apply_snapshot_blend"),
    ("Ultimate Animators Bundle", "GraphKit-style Cleanup Bundle", "sas.smart_graph_optimizer"),
    ("AnimAide", "Motion Director", "sas.smart_motion_director"),
    ("Ghostool", "Smart Visualizer", "sas.smart_visualize_motion"),
    ("Simply Trails", "Trail Curve Generator", "sas.create_trail_curve"),
    ("BoneDynamics Pro", "Spring Magic / Spring Dynamics", "sas.bake_spring_magic, sas.bake_spring_dynamics"),
    ("Dynamic Parent", "Dynamic Parent Plus", "sas.dynamic_parent_switch"),
    ("Animall", "Bundled AnimAll integration", "animall integrated tool"),
    ("OmniStep", "Stepped Preview / Step Baker", "sas.apply_stepped_preview, sas.bake_step_keys"),
    ("ShapeKeyPro / Shape Key Smoother", "Shape Key Manager Plus", "sas.smooth_shape_key_curves, sas.optimize_shape_key_curves, sas.smart_shape_control_mixer"),
    ("3ds Max Track View", "Graph Optimizer / Key Tools", "sas.smart_graph_optimizer"),
    ("3ds Max Set Key Mode", "Safe Key Insert", "sas.insert_keys"),
    ("3ds Max Motion Mixer", "NLA Motion Mixer Plus", "sas.sequence_library_actions"),
    ("3ds Max Biped / CAT", "Retarget / Root Motion / Locomotion", "sas.build_bone_map, sas.create_root_motion_action, sas.smart_generate_locomotion_cycle"),
    ("Key Manager", "Key Manager Plus", "sas.apply_tangent_preset, sas.shift_keys, sas.scale_key_timing"),
    ("Key Mover", "Key Mover Plus", "sas.randomize_key_timing, sas.cascade_delay"),
    ("Pose Manager", "Pose Snapshot Catalog", "sas.store_pose_snapshot, sas.apply_pose_snapshot"),
    ("IFL Playback Manager", "Image Sequence Timing Manager", "sas.smart_ifl_sequence_manager"),
    ("Camera Animator", "Camera Story Animator", "sas.build_camera_sequence, sas.add_camera_marker"),
    ("OverMorpher Toolset", "Shape Control Mixer", "sas.smart_shape_control_mixer"),
    ("Dorito / Custom Controls", "Shape Custom Property Drivers", "sas.smart_shape_control_mixer"),
    ("Cinema 4D F-Curve / Timeline", "Graph / Timing Hub", "sas.smart_graph_optimizer, sas.scale_key_timing"),
    ("Cinema 4D Pose Morph", "Pose Snapshot / Shape Control Mixer", "sas.apply_snapshot_blend, sas.smart_shape_control_mixer"),
    ("CMotion", "Cycle Locomotion Generator", "sas.smart_generate_locomotion_cycle"),
    ("MoGraph Effectors", "Motion Signal / Transform Reveal", "sas.apply_motion_signal, sas.transform_reveal"),
    ("Signal", "Motion Signal", "sas.apply_motion_signal"),
    ("Transform", "Transform Reveal", "sas.transform_reveal"),
    ("GorillaCam", "Camera Shake Preset", "sas.apply_camera_shake_preset"),
    ("Motion Stretch Deformer", "Motion Stretch", "sas.apply_motion_stretch"),
    ("Gelatine / Jiggle", "Spring Dynamics", "sas.bake_spring_dynamics, sas.bake_spring_magic"),
    ("Scroll Roll Deformer", "Deformer Reveal", "sas.apply_deformer_reveal"),
    ("Unfolder", "Deformer Reveal", "sas.apply_deformer_reveal"),
    ("Drive", "Vehicle Drive", "sas.bake_vehicle_wheel_rotation"),
    ("Houdini APEX Scene Animate", "Smart Motion Director / Direct Key Hub", "sas.smart_motion_director, sas.insert_keys"),
    ("Houdini Animation Catalog", "Motion Library", "sas.add_action_to_library"),
    ("Houdini Motion Mixer", "NLA Motion Mixer Plus", "sas.sequence_library_actions"),
    ("Houdini Ragdoll / Physics", "Physics Director", "sas.smart_physics_director, sas.bake_rigid_body_keys"),
    ("KineFX Retargeting", "Retarget Director", "sas.smart_retarget_director"),
    ("Tear Off Viewport", "Camera Review Split", "sas.create_camera_review_split"),
    ("Skin Controls", "Selection / Pose Snapshot Direct Controls", "sas.store_selection_set, sas.store_pose_snapshot"),
    ("Cascadeur AutoPosing", "AutoPose Key Assistant", "sas.smart_pose_assistant"),
    ("Cascadeur AutoPhysics", "Physics Director", "sas.smart_physics_director"),
    ("Ballistic Trajectories", "Ballistic Guide / Bake", "sas.create_ballistic_guide, sas.bake_ballistic_keys"),
    ("Fulcrum Points", "Fulcrum Cleanup", "sas.auto_fulcrum_cleanup"),
    ("Animation Unbaking", "Smart Unbake", "sas.smart_unbake"),
    ("AI Inbetweening", "Motion Director Hermite Tween", "sas.apply_tween"),
    ("MotionBuilder Story Tool", "Camera / Motion Story", "sas.build_camera_sequence, sas.sequence_library_actions"),
    ("MotionBuilder Animation Layers", "NLA Layer Stack Plus", "sas.add_animation_layer"),
    ("MotionBuilder F-Curve Key Types", "Tangent / Step / Euler Tools", "sas.apply_tangent_preset, sas.bake_step_keys, sas.euler_filter"),
    ("MotionBuilder Character Controls / Retargeting", "Retarget Director", "sas.smart_retarget_director"),
    ("Cross-DCC Quality Gates", "Smart Quality Report / Precision Polish", "sas.smart_quality_report, sas.smart_precision_polish"),
    ("Adaptive Key Reduction", "Range-aware sparse unbake with extrema preservation", "sas.smart_precision_polish, sas.smart_graph_optimizer"),
    ("Director Review Workflow", "One-click reportable polish pass", "sas.smart_precision_polish"),
    ("Context-Aware Studio Workflow", "Smart Stage Director", "sas.smart_stage_director"),
    ("Curvature-Safe Curve Cleanup", "Curvature Guard adaptive precision", "sas.smart_graph_optimizer, sas.smart_precision_polish"),
    ("Contact-Aware Procedural Blocking", "Planted locomotion generator", "sas.smart_generate_locomotion_cycle"),
    ("Professional UI Consolidation", "Studio Dashboard with compact/balanced/studio density", "Animation Recipes N-panel"),
    ("Studio Superior Director", "One-click stage, contact, timing, precision, quality, and visual review pass", "sas.smart_superior_director"),
    ("Fulcrum / Foot Sliding Cleanup", "Contact Stabilizer with drift-aware quality reporting", "sas.smart_contact_stabilizer"),
    ("Intent-Based Interpolation", "Timing Intent Solver for blocking, spline, impact, float, and mechanical motion", "sas.smart_timing_intent_solver"),
)


SMART_RECIPE_ITEMS = [
    ('ANIMBOT', "animBot / AnimAide Motion Director", "Create tween, push/pull, and scale-to-neighbor edits from the current frame and surrounding keys."),
    ('GRAPHKIT', "GraphKit / Key Manager Optimizer", "Run Euler filtering, duplicate/static cleanup, smoothing, and optional unbake-style simplification."),
    ('VISUALIZER', "Motion Trail / Ghost / Ballistic Visualizer", "Create motion trails, ghost previews, motion paths, and ballistic guides for spacing review."),
    ('PHYSICS', "BroDynamics / Cascadeur AutoPhysics", "Run a physics-assist pass for ballistic guides, contact holds, rigid-body baking, or secondary spring motion."),
    ('LIMITED', "Twosify / OmniStep Limited Animation", "Create a stepped preview or bake editable on-twos/on-fours style keys."),
    ('OVERLAP', "Overlapper / Jiggle / Spring", "Apply overlap, cascade delay, and spring-style secondary motion to selected animation curves."),
    ('POSE_LIBRARY', "Studio Library / Pose Manager", "Store and blend reusable poses and add the current action to the motion library."),
    ('PICKER', "AnimSchool Picker / Skin Controls", "Store the current object or pose-bone selection as an in-panel picker selection set."),
    ('DYNAMIC_PARENT', "Dynamic Parent Plus", "Switch a Child Of based dynamic parent while preserving the visible transform."),
    ('MOTION_MIXER', "MotionBuilder Story / NLA Mixer", "Push the current action to NLA and sequence stored library actions as editable motion clips."),
    ('RETARGET', "Red9 / KineFX / MotionBuilder Retarget", "Build or refresh a bone map and create a live retarget preview."),
    ('LOCOMOTION', "MotionMaker / CMotion Locomotion", "Generate an editable cyclic locomotion base on selected objects."),
    ('SIGNAL', "Signal / MoGraph Procedural Motion", "Apply procedural motion-signal noise and loop helpers to selected animated curves."),
    ('TRANSFORM_REVEAL', "Transform / Unfolder / Scroll Roll", "Create transform or deformer reveal animation from selected objects."),
    ('CAMERA_STORY', "Camera Animator / GorillaCam", "Build camera shot markers, optional review split, and camera shake polish."),
    ('SHAPE_CONTROL', "Pose Morph / OverMorpher / Dorito", "Create shape-key custom-property controls and drivers on the active mesh."),
    ('IFL', "IFL Playback Manager", "Apply image-sequence timing to texture nodes on selected objects."),
    ('UNBAKE', "Cascadeur Animation Unbaking", "Convert dense baked curves into a sparse animator-editable result."),
    ('PRECISION_POLISH', "Smart Precision Polish", "Run adaptive graph cleanup, flow-safe handles, optional sparse unbake, and a quality report in one reviewable pass."),
    ('QUALITY_REPORT', "Smart Quality Report", "Analyze key density, duplicate keys, static channels, Euler jumps, spacing speed, and polish risks into a Text datablock."),
    ('STAGE_DIRECTOR', "Smart Stage Director", "Run a context-aware studio pass that chooses blocking, spline, mocap, physics, polish, or review actions from the current shot state."),
    ('SUPER_DIRECTOR', "Smart Superior Director", "Run the strongest studio pass: stage resolution, contact stabilization, timing intent, precision polish, quality gate, and optional visual review."),
    ('CONTACT_STABILIZER', "Smart Contact Stabilizer", "Flatten planted vertical contact keys and reduce contact drift for feet, props, and fulcrum points."),
    ('TIMING_INTENT', "Smart Timing Intent Solver", "Convert curve interpolation to the intended production feel: blocking, spline, impact, float, or mechanical."),
    ('REPORT', "Feature Coverage Report", "Write the full source-tool to Animation Recipes feature mapping into a Text datablock."),
]


# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

def _settings(context):
    return getattr(getattr(context, 'scene', None), 'sas_settings', None)


def _selected_objects(context) -> list:
    try:
        return list(context.selected_objects or [])
    except Exception:
        obj = active_object(context)
        return [obj] if obj else []


def _op_callable(op_id: str):
    try:
        group, name = str(op_id).split('.', 1)
        ops_group = getattr(bpy.ops, group, None)
        if ops_group is None:
            return None
        return getattr(ops_group, name, None)
    except Exception:
        return None


def _run_op(context, op_id: str, *, fail_silently: bool = True) -> bool:
    del context
    op = _op_callable(op_id)
    if op is None:
        return False
    try:
        result = op()
        if isinstance(result, set):
            return 'FINISHED' in result
        return bool(result)
    except Exception:
        if not fail_silently:
            raise
    return False


def _run_ops(context, op_ids: Iterable[str]) -> tuple[int, list[str]]:
    finished = 0
    failed: list[str] = []
    for op_id in op_ids:
        if _run_op(context, op_id):
            finished += 1
        else:
            failed.append(str(op_id))
    return finished, failed


def _set_keyframe_interpolation(action, interpolation: str = 'BEZIER', handle_type: str = 'AUTO_CLAMPED') -> int:
    changed = 0
    if action is None:
        return changed
    for fcurve in iter_action_fcurves(action):
        for key in getattr(fcurve, 'keyframe_points', ()):
            try:
                key.interpolation = interpolation
                changed += 1
            except Exception:
                pass
            try:
                key.handle_left_type = handle_type
                key.handle_right_type = handle_type
            except Exception:
                pass
        try:
            fcurve.update()
        except Exception:
            pass
    return changed


def _add_cycles_to_action(action) -> int:
    count = 0
    if action is None:
        return 0
    for fcurve in iter_action_fcurves(action):
        try:
            exists = any(getattr(mod, 'type', '') == 'CYCLES' and getattr(mod, 'name', '').startswith('SAS_SMART_LOOP') for mod in fcurve.modifiers)
        except Exception:
            exists = False
        if exists:
            continue
        try:
            mod = fcurve.modifiers.new(type='CYCLES')
            mod.name = 'SAS_SMART_LOOP'
            count += 1
        except Exception:
            pass
    return count


def _axis_vector(axis: str) -> Vector:
    axis = str(axis or 'X').upper()
    if axis == 'Y':
        return Vector((0.0, 1.0, 0.0))
    if axis == 'Z':
        return Vector((0.0, 0.0, 1.0))
    if axis in {'-X', 'NEG_X'}:
        return Vector((-1.0, 0.0, 0.0))
    if axis in {'-Y', 'NEG_Y'}:
        return Vector((0.0, -1.0, 0.0))
    if axis in {'-Z', 'NEG_Z'}:
        return Vector((0.0, 0.0, -1.0))
    return Vector((1.0, 0.0, 0.0))


def _material_image_users(obj):
    for slot in getattr(obj, 'material_slots', ()) or ():
        material = getattr(slot, 'material', None)
        if material is None:
            continue
        if getattr(material, 'use_nodes', False):
            nodes = getattr(getattr(material, 'node_tree', None), 'nodes', ()) or ()
            for node in nodes:
                if getattr(node, 'type', '') == 'TEX_IMAGE' and getattr(node, 'image', None) is not None:
                    image_user = getattr(node, 'image_user', None)
                    if image_user is not None:
                        yield material, node, image_user
        try:
            texture_slots = getattr(material, 'texture_slots', None) or ()
            for tex_slot in texture_slots:
                texture = getattr(tex_slot, 'texture', None)
                image_user = getattr(texture, 'image_user', None)
                if image_user is not None:
                    yield material, texture, image_user
        except Exception:
            pass


def _shape_driver_prop_name(prefix: str, key_name: str) -> str:
    safe = ''.join(ch if ch.isalnum() or ch in {'_', '-'} else '_' for ch in str(key_name or 'Shape'))
    return f'{prefix}{safe}'


def _iter_shape_keys(obj):
    shape_keys = getattr(getattr(obj, 'data', None), 'shape_keys', None)
    key_blocks = getattr(shape_keys, 'key_blocks', None)
    if key_blocks is None:
        return []
    return [key for key in key_blocks if getattr(key, 'name', '') != 'Basis']


def _shape_key_driver_fcurve(key):
    try:
        data_path = key.path_from_id('value')
        anim_data = getattr(getattr(key, 'id_data', None), 'animation_data', None)
        for fcurve in getattr(anim_data, 'drivers', ()) or ():
            if getattr(fcurve, 'data_path', '') == data_path:
                return fcurve
    except Exception:
        pass
    return None


def _driver_uses_smart_shape_prefix(fcurve, obj, prefix: str) -> bool:
    if fcurve is None:
        return False
    try:
        for variable in getattr(getattr(fcurve, 'driver', None), 'variables', ()) or ():
            for target in getattr(variable, 'targets', ()) or ():
                if getattr(target, 'id', None) == obj and str(getattr(target, 'data_path', '') or '').startswith(f'["{prefix}'):
                    return True
    except Exception:
        pass
    return False


def _write_coverage_text(context) -> str:
    settings = _settings(context)
    text_name = getattr(settings, 'smart_report_text_name', 'Animation Recipes Coverage') if settings else 'Animation Recipes Coverage'
    text_block = get_or_create_text(text_name)
    payload = {
        'tool': 'Animation Recipes',
        'author': 'JELararagi',
        'coverage_count': len(SMART_FEATURE_MATRIX),
        'features': [
            {'source_feature': src, 'smart_equivalent': equivalent, 'operators': operators}
            for src, equivalent, operators in SMART_FEATURE_MATRIX
        ],
    }
    if sas_is_japanese(context):
        lines = [
            'アニメーション レシピ - 機能対応表',
            'Copyright (C) 2026 JELararagi',
            '',
            '調査済みアニメーション補助機能を、Blender 内で扱える アニメーション レシピ の対応機能へ整理したレポートです。',
            '',
        ]
        for index, (source, equivalent, operators) in enumerate(SMART_FEATURE_MATRIX, start=1):
            lines.append(f'{index:02d}. {source}')
            lines.append(f'    Smart 側対応: {equivalent}')
            lines.append(f'    オペレーター / 領域: {operators}')
    else:
        lines = [
            'Animation Recipes - Feature Coverage Report',
            'Copyright (C) 2026 JELararagi',
            '',
            'This report maps the researched animation-assistance functions to Blender-native Animation Recipes equivalents.',
            '',
        ]
        for index, (source, equivalent, operators) in enumerate(SMART_FEATURE_MATRIX, start=1):
            lines.append(f'{index:02d}. {source}')
            lines.append(f'    Smart Equivalent: {equivalent}')
            lines.append(f'    Operator / Area: {operators}')
    lines.extend(['', 'JSON:', json.dumps(payload, ensure_ascii=False, indent=2)])
    try:
        text_block.clear()
    except Exception:
        pass
    text_block.write('\n'.join(lines))
    return text_block.name


def _call_shape_control_report(context, created: int, cleared: int = 0):
    if created:
        return sas_text(
            f"Created or refreshed {created} shape-key driver controls.",
            f"{created} 個のシェイプキードライバー制御を作成または更新しました。",
            context,
        )
    if cleared:
        return sas_text(
            f"Cleared {cleared} shape-key driver controls.",
            f"{cleared} 個のシェイプキードライバー制御を解除しました。",
            context,
        )
    return sas_text("No compatible shape keys were found.", "対応するシェイプキーが見つかりません。", context)



# -----------------------------------------------------------------------------
# Precision / quality helpers
# -----------------------------------------------------------------------------

def _active_editable_action_curves(context):
    obj = active_object(context)
    action = active_action(context, obj)
    if action is None:
        return None, []
    settings = _settings(context)
    try:
        curves = list(selected_fcurves(context, action, obj=obj))
    except Exception:
        curves = list(iter_action_fcurves(action, datablock=obj))
    return action, filter_editable_fcurves(curves, settings=settings)


def _key_points(fcurve):
    points = []
    for index, key in enumerate(getattr(fcurve, 'keyframe_points', ()) or ()): 
        try:
            points.append((index, float(key.co.x), float(key.co.y), key))
        except Exception:
            continue
    points.sort(key=lambda item: (item[1], item[0]))
    return points


def _value_range(points) -> float:
    if not points:
        return 0.0
    values = [float(item[2]) for item in points]
    return max(values) - min(values)


def _precision_profile_key(settings) -> str:
    return str(getattr(settings, 'smart_precision_profile', 'BALANCED') or 'BALANCED').upper()


def _precision_profile_multiplier(settings) -> float:
    profile = _precision_profile_key(settings)
    if profile == 'HERO':
        return 0.22
    if profile == 'SAFE':
        return 0.45
    if profile == 'MOCAP':
        return 1.35
    if profile == 'AGGRESSIVE':
        return 1.85
    return 1.0


def _adaptive_tolerance(settings, points) -> float:
    base = max(0.0, float(getattr(settings, 'unbake_tolerance', 0.02)))
    scale = _precision_profile_multiplier(settings)
    span = _value_range(points)
    if span > 0.0:
        profile = _precision_profile_key(settings)
        relative = span * {
            'HERO': 0.00015,
            'SAFE': 0.0004,
            'BALANCED': 0.0012,
            'MOCAP': 0.0024,
            'AGGRESSIVE': 0.0042,
        }.get(profile, 0.0012)
        cap_ratio = {'HERO': 0.025, 'SAFE': 0.04, 'BALANCED': 0.075, 'MOCAP': 0.09, 'AGGRESSIVE': 0.12}.get(profile, 0.075)
        return max(1e-9, min(max(base * scale, relative), span * cap_ratio))
    return max(1e-9, base * scale)


def _curve_slope(left, right) -> float:
    frame_delta = float(right[1]) - float(left[1])
    if abs(frame_delta) <= 1e-8:
        return 0.0
    return (float(right[2]) - float(left[2])) / frame_delta


def _selected_key_local_indices(points) -> set[int]:
    selected = set()
    for local_index, (_global_index, _frame, _value, key) in enumerate(points):
        try:
            if bool(getattr(key, 'select_control_point', False)) or bool(getattr(key, 'select_left_handle', False)) or bool(getattr(key, 'select_right_handle', False)):
                selected.add(local_index)
        except Exception:
            continue
    return selected


def _count_sampled_overshoot(fcurve, settings) -> int:
    points = _key_points(fcurve)
    if len(points) <= 2:
        return 0
    span = max(_value_range(points), 1.0e-8)
    tol = max(0.0, float(getattr(settings, 'smart_overshoot_tolerance', 0.015) if settings else 0.015)) * span
    count = 0
    for left, right in zip(points, points[1:]):
        min_v = min(float(left[2]), float(right[2])) - tol
        max_v = max(float(left[2]), float(right[2])) + tol
        for key in (left[3], right[3]):
            try:
                for handle in (key.handle_left, key.handle_right):
                    hv = float(handle.y)
                    if hv < min_v or hv > max_v:
                        count += 1
                        break
            except Exception:
                continue
    return count


def _handle_risk_count(fcurve, settings) -> int:
    points = _key_points(fcurve)
    if len(points) <= 1:
        return 0
    span = max(_value_range(points), 1.0e-8)
    tol = max(float(getattr(settings, 'remove_threshold', 1e-5) if settings else 1e-5), span * 0.0001)
    risk = 0
    for _global_index, frame, value, key in points:
        try:
            for handle in (key.handle_left, key.handle_right):
                hdx = abs(float(handle.x) - float(frame))
                hdy = abs(float(handle.y) - float(value))
                if hdx > 0.0 and hdy / max(hdx, 1.0e-8) > span * 0.25 + tol:
                    risk += 1
                    break
        except Exception:
            continue
    return risk


def _protected_precision_indices(points, settings) -> set[int]:
    protected = {0, len(points) - 1} if points else set()
    if not points:
        return protected
    if bool(getattr(settings, 'smart_preserve_selected_keys', True)):
        protected.update(_selected_key_local_indices(points))
    if len(points) <= 2:
        return protected

    preserve_extremes = bool(getattr(settings, 'smart_preserve_extreme_keys', True))
    curvature_guard = bool(getattr(settings, 'smart_precision_curvature_guard', True))
    if not preserve_extremes and not curvature_guard:
        return protected

    span = max(_value_range(points), 1.0e-8)
    threshold = max(float(getattr(settings, 'remove_threshold', 1e-5)), span * 0.00025)
    slope_guard = span * {'HERO': 0.003, 'SAFE': 0.006, 'BALANCED': 0.012, 'MOCAP': 0.018, 'AGGRESSIVE': 0.026}.get(_precision_profile_key(settings), 0.012)
    accel_guard = slope_guard * 1.75
    for index in range(1, len(points) - 1):
        prev_item = points[index - 1]
        item = points[index]
        next_item = points[index + 1]
        left_slope = _curve_slope(prev_item, item)
        right_slope = _curve_slope(item, next_item)
        left_delta = float(item[2]) - float(prev_item[2])
        right_delta = float(next_item[2]) - float(item[2])
        direction_flip = (left_delta > threshold and right_delta < -threshold) or (left_delta < -threshold and right_delta > threshold)
        hold_edge = (abs(left_delta) <= threshold < abs(right_delta)) or (abs(right_delta) <= threshold < abs(left_delta))
        constant_edge = False
        try:
            constant_edge = str(getattr(item[3], 'interpolation', '')) == 'CONSTANT' or str(getattr(prev_item[3], 'interpolation', '')) == 'CONSTANT'
        except Exception:
            constant_edge = False
        curvature = abs(right_slope - left_slope)
        high_slope = max(abs(left_slope), abs(right_slope))
        if preserve_extremes and (direction_flip or hold_edge or constant_edge):
            protected.add(index)
        elif curvature_guard and (curvature >= accel_guard or high_slope >= slope_guard):
            protected.add(index)
    return protected


def _max_linear_error_against_keep(points, keep: set[int]) -> float:
    if len(points) <= 2:
        return 0.0
    ordered_keep = sorted(index for index in keep if 0 <= index < len(points))
    if len(ordered_keep) <= 1:
        return 0.0
    max_error = 0.0
    for start_index, end_index in zip(ordered_keep, ordered_keep[1:]):
        if end_index - start_index <= 1:
            continue
        _global_a, frame_a, value_a, _key_a = points[start_index]
        _global_b, frame_b, value_b, _key_b = points[end_index]
        frame_delta = float(frame_b) - float(frame_a)
        for idx in range(start_index + 1, end_index):
            _global_i, frame_i, value_i, _key_i = points[idx]
            if abs(frame_delta) <= 1e-8:
                predicted = float(value_a)
            else:
                predicted = float(value_a) + (float(value_b) - float(value_a)) * ((float(frame_i) - float(frame_a)) / frame_delta)
            max_error = max(max_error, abs(float(value_i) - predicted))
    return max_error


def _remove_duplicate_frames(fcurve, *, threshold: float = 1e-8) -> int:
    points = _key_points(fcurve)
    if len(points) <= 1:
        return 0
    remove = []
    seen = {}
    for index, frame, value, _key in points:
        rounded = round(frame, 6)
        previous = seen.get(rounded)
        if previous is None:
            seen[rounded] = (index, value)
            continue
        _prev_index, prev_value = previous
        if abs(value - prev_value) <= threshold:
            remove.append(index)
        else:
            # When two keys share a frame but differ, preserve the later point
            # and remove the older one. Blender evaluates a single value at a
            # frame, so keeping both creates unpredictable editor feedback.
            remove.append(_prev_index)
            seen[rounded] = (index, value)
    return safe_remove_keyframe_points(fcurve, sorted(set(remove)))


def _count_duplicate_frames(fcurve, *, threshold: float = 1e-8) -> int:
    points = _key_points(fcurve)
    seen = {}
    duplicates = 0
    for _index, frame, value, _key in points:
        rounded = round(frame, 6)
        previous = seen.get(rounded)
        if previous is None:
            seen[rounded] = value
        elif abs(float(value) - float(previous)) <= threshold:
            duplicates += 1
        else:
            duplicates += 1
            seen[rounded] = value
    return duplicates


def _is_static_curve(fcurve, threshold: float = 1e-8) -> bool:
    values = [item[2] for item in _key_points(fcurve)]
    if len(values) <= 1:
        return False
    return (max(values) - min(values)) <= float(threshold)


def _set_flow_safe_handles(fcurve, *, interpolation='BEZIER', handle_type='AUTO_CLAMPED') -> int:
    changed = 0
    for key in getattr(fcurve, 'keyframe_points', ()) or ():
        try:
            if getattr(key, 'interpolation', None) != 'CONSTANT':
                key.interpolation = interpolation
                changed += 1
        except Exception:
            pass
        for attr in ('handle_left_type', 'handle_right_type'):
            try:
                if getattr(key, attr, None) != handle_type:
                    setattr(key, attr, handle_type)
                    changed += 1
            except Exception:
                pass
    try:
        fcurve.update()
    except Exception:
        pass
    return changed


def _simplify_curve_adaptive(fcurve, settings, *, preview_only: bool = False) -> tuple[int, int, int, float]:
    points = _key_points(fcurve)
    if len(points) <= 2:
        return 0, 0, 0, 0.0
    threshold = float(getattr(settings, 'remove_threshold', 1e-5))
    tolerance = _adaptive_tolerance(settings, points)
    keep = simplify_point_indices([(frame, value) for _idx, frame, value, _key in points], tolerance, preserve_extrema=True, threshold=threshold)
    keep = set(keep or ())
    protected = _protected_precision_indices(points, settings)
    keep.update(protected)
    max_error = _max_linear_error_against_keep(points, keep)
    removable = [global_index for local_index, (global_index, _frame, _value, _key) in enumerate(points) if local_index not in keep]
    if preview_only:
        return len(removable), 0, max(0, len(protected) - 2), max_error
    removed = safe_remove_keyframe_points(fcurve, removable)
    if removed:
        _set_flow_safe_handles(fcurve)
    return len(removable), removed, max(0, len(protected) - 2), max_error


def _smart_precision_curve_pass(context, *, preview_only: bool | None = None) -> dict:
    settings = _settings(context)
    action, curves = _active_editable_action_curves(context)
    if action is None or settings is None:
        return {'action': None, 'curves': 0, 'duplicate_removed': 0, 'simplify_candidates': 0, 'simplified_removed': 0, 'handles_changed': 0}
    if preview_only is None:
        preview_only = bool(getattr(settings, 'preview_only', False))
    threshold = float(getattr(settings, 'remove_threshold', 1e-5))
    metrics = {
        'action': action.name,
        'curves': len(curves),
        'duplicate_removed': 0,
        'simplify_candidates': 0,
        'simplified_removed': 0,
        'handles_changed': 0,
        'curvature_protected': 0,
        'max_curve_error': 0.0,
    }
    for fcurve in curves:
        if preview_only:
            metrics['duplicate_removed'] += _count_duplicate_frames(fcurve, threshold=threshold)
        else:
            metrics['duplicate_removed'] += _remove_duplicate_frames(fcurve, threshold=threshold)
        candidates, removed, protected, max_error = _simplify_curve_adaptive(fcurve, settings, preview_only=preview_only)
        metrics['simplify_candidates'] += candidates
        metrics['simplified_removed'] += removed
        metrics['curvature_protected'] += protected
        metrics['max_curve_error'] = max(float(metrics.get('max_curve_error', 0.0)), float(max_error or 0.0))
        if bool(getattr(settings, 'smart_graph_auto_clamped', True)) and not preview_only:
            metrics['handles_changed'] += _set_flow_safe_handles(fcurve)
    return metrics


def _euler_jump_count(action) -> int:
    if action is None:
        return 0
    jumps = 0
    for fcurve in iter_action_fcurves(action):
        if 'rotation_euler' not in str(getattr(fcurve, 'data_path', '')):
            continue
        previous = None
        for _index, _frame, value, _key in _key_points(fcurve):
            if previous is not None and abs(float(value) - previous) > math.pi:
                jumps += 1
            previous = float(value)
    return jumps


def _sample_object_motion_quality(context, objects, step: int) -> dict:
    scene = getattr(context, 'scene', None)
    if scene is None or not objects:
        return {'objects': 0, 'samples': 0, 'max_speed': 0.0, 'average_speed': 0.0, 'speed_jitter': 0.0, 'max_acceleration': 0.0, 'acceleration_spikes': 0}
    settings = _settings(context)
    try:
        start, end = get_bake_range(scene, settings)
    except Exception:
        start, end = int(scene.frame_start), int(scene.frame_end)
    step = max(1, int(step or 1))
    frames = list(range(int(start), int(end) + 1, step))
    if not frames or frames[-1] != int(end):
        frames.append(int(end))
    old_frame = int(getattr(scene, 'frame_current', start))
    max_speed = 0.0
    max_accel = 0.0
    sample_count = 0
    all_speeds = []
    all_accels = []
    try:
        for obj in objects:
            positions = []
            for frame in frames:
                try:
                    scene.frame_set(frame)
                    positions.append(Vector(getattr(obj, 'matrix_world').translation))
                    sample_count += 1
                except Exception:
                    continue
            speeds = []
            for prev, cur in zip(positions, positions[1:]):
                speed = (cur - prev).length / float(step)
                speeds.append(speed)
                all_speeds.append(speed)
                max_speed = max(max_speed, speed)
            for prev, cur in zip(speeds, speeds[1:]):
                accel = abs(cur - prev) / float(step)
                all_accels.append(accel)
                max_accel = max(max_accel, accel)
    finally:
        try:
            scene.frame_set(old_frame)
        except Exception:
            pass
    if all_speeds:
        average_speed = sum(all_speeds) / float(len(all_speeds))
        variance = sum((value - average_speed) ** 2 for value in all_speeds) / float(len(all_speeds))
        speed_jitter = (math.sqrt(variance) / max(average_speed, 1.0e-8)) if average_speed > 1.0e-8 else 0.0
    else:
        average_speed = 0.0
        speed_jitter = 0.0
    accel_average = (sum(all_accels) / float(len(all_accels))) if all_accels else 0.0
    spike_limit = accel_average * 2.5 + 1.0e-8
    spikes = sum(1 for value in all_accels if value > spike_limit) if all_accels else 0
    return {
        'objects': len(objects),
        'samples': sample_count,
        'max_speed': max_speed,
        'average_speed': average_speed,
        'speed_jitter': speed_jitter,
        'max_acceleration': max_accel,
        'acceleration_spikes': spikes,
    }


def _collect_smart_quality(context) -> dict:
    settings = _settings(context)
    obj = active_object(context)
    action = active_action(context, obj)
    action_name = getattr(action, 'name', '-') if action else '-'
    curves = list(iter_action_fcurves(action, datablock=obj)) if action else []
    threshold = float(getattr(settings, 'remove_threshold', 1e-5)) if settings else 1e-5
    total_keys = sum(len(getattr(fc, 'keyframe_points', ()) or ()) for fc in curves)
    duplicate_keys = sum(_count_duplicate_frames(fc, threshold=threshold) for fc in curves)
    static_curves = sum(1 for fc in curves if _is_static_curve(fc, threshold=threshold))
    very_dense_curves = sum(1 for fc in curves if len(getattr(fc, 'keyframe_points', ()) or ()) >= 60)
    euler_jumps = _euler_jump_count(action)
    density = (float(total_keys) / float(max(1, len(curves)))) if curves else 0.0
    curvature_candidates = 0
    overshoot_candidates = 0
    handle_risks = 0
    if settings is not None:
        for fc in curves:
            points = _key_points(fc)
            if len(points) > 2:
                curvature_candidates += max(0, len(_protected_precision_indices(points, settings)) - 2)
            overshoot_candidates += _count_sampled_overshoot(fc, settings)
            handle_risks += _handle_risk_count(fc, settings)
    motion = _sample_object_motion_quality(context, _selected_objects(context), getattr(settings, 'smart_quality_sample_step', 2) if settings else 2)
    contact = _contact_drift_metrics(context)
    jitter_ratio = float(motion.get('speed_jitter', 0.0) or 0.0)
    acceleration_spikes = int(motion.get('acceleration_spikes', 0) or 0)
    score = 100
    score -= min(25, duplicate_keys * 2)
    score -= min(20, static_curves * 4)
    score -= min(25, euler_jumps * 5)
    score -= min(20, max(0, very_dense_curves - 2) * 2)
    score -= min(12, int(jitter_ratio * 6.0))
    score -= min(10, acceleration_spikes)
    score -= min(18, int(overshoot_candidates) * 2)
    score -= min(12, int(handle_risks * 0.5))
    score -= min(10, int(float(contact.get('max_drift', 0.0) or 0.0) * 50.0))
    score = max(0, min(100, score))
    return {
        'object': getattr(obj, 'name', '-') if obj else '-',
        'action': action_name,
        'curves': len(curves),
        'keys': total_keys,
        'density': density,
        'duplicate_keys': duplicate_keys,
        'static_curves': static_curves,
        'very_dense_curves': very_dense_curves,
        'curvature_candidates': curvature_candidates,
        'overshoot_candidates': overshoot_candidates,
        'handle_risks': handle_risks,
        'euler_jumps': euler_jumps,
        'motion': motion,
        'contact': contact,
        'score': score,
    }


def _write_quality_report(context, metrics: dict | None = None, precision_metrics: dict | None = None) -> str:
    settings = _settings(context)
    text_name = getattr(settings, 'smart_quality_report_text_name', 'Animation Recipes Quality Report') if settings else 'Animation Recipes Quality Report'
    text_block = get_or_create_text(text_name)
    metrics = metrics or _collect_smart_quality(context)
    precision_metrics = precision_metrics or {}
    ja = sas_is_japanese(context)
    recommendations = []
    if metrics.get('duplicate_keys', 0):
        recommendations.append('精密ポリッシュまたはグラフ最適化で、同一フレームの重複キーを削除してください。' if ja else 'Run Precision Polish or Graph Optimizer to remove duplicate same-frame keys.')
    if metrics.get('static_curves', 0):
        recommendations.append('書き出しや受け渡し前に、静的チャンネルを削除してください。' if ja else 'Delete static channels before exporting or handing off the shot.')
    if metrics.get('euler_jumps', 0):
        recommendations.append('最終グラフ調整またはリターゲットベイク前に、オイラーフィルターを実行してください。' if ja else 'Run Euler filtering before final graph polish or retarget bake.')
    if metrics.get('very_dense_curves', 0):
        recommendations.append('Smart Unbake または適応精度処理で、高密度ベイクモーションを編集しやすいキーへ変換してください。' if ja else 'Use Smart Unbake / adaptive precision to convert dense baked motion into animator-editable keys.')
    if metrics.get('overshoot_candidates', 0):
        recommendations.append('ベジェハンドル由来のオーバーシュート候補が検出されています。Timing Intent Solver または Auto Clamped ハンドルで確認してください。' if ja else 'Bezier-handle overshoot candidates were detected. Review with Timing Intent Solver or Auto Clamped handles.')
    if metrics.get('handle_risks', 0):
        recommendations.append('急角度のハンドルが検出されています。流れ保持ハンドルと品質レポートでカーブを確認してください。' if ja else 'Steep handle-risk candidates were detected. Review curve flow with flow-safe handles and Quality Report.')
    if metrics.get('motion', {}).get('acceleration_spikes', 0):
        recommendations.append('スペーシングの急変が検出されています。モーション可視化と流れ保持ハンドルでアークと加速度を確認してください。' if ja else 'Spacing acceleration spikes were detected. Use Motion Visualizer and flow-safe handles to review arcs and acceleration.')
    if float(metrics.get('contact', {}).get('max_drift', 0.0) or 0.0) > float(getattr(settings, 'smart_contact_floor_epsilon', 0.015) if settings else 0.015):
        recommendations.append('接地候補で横滑りが検出されています。Smart Contact Stabilizer で接地Zとハンドルを安定化してください。' if ja else 'Horizontal drift was detected on contact candidates. Run Smart Contact Stabilizer to stabilize planted Z keys and handles.')
    gate = int(getattr(settings, 'smart_quality_gate_min_score', 85)) if settings else 85
    if int(metrics.get('score', 0) or 0) < gate:
        recommendations.append(f'品質スコアがゲート {gate}/100 を下回っています。最終受け渡し前に精密ポリッシュと再診断を行ってください。' if ja else f'Quality score is below the {gate}/100 gate. Run Precision Polish and re-check before final handoff.')
    if not recommendations:
        recommendations.append('この静的チェックでは、大きな技術的アニメーションリスクは検出されませんでした。' if ja else 'No major technical animation risks were detected by this static pass.')
    gate = int(getattr(settings, 'smart_quality_gate_min_score', 85)) if settings else 85
    gate_pass = int(metrics.get('score', 0) or 0) >= gate
    payload = {'quality': metrics, 'quality_gate': {'minimum_score': gate, 'passed': gate_pass}, 'precision_pass': precision_metrics, 'recommendations': recommendations}
    if ja:
        lines = [
            'アニメーション レシピ - 品質レポート',
            'Copyright (C) 2026 JELararagi',
            '',
            f"オブジェクト: {metrics.get('object', '-')}",
            f"アクション: {metrics.get('action', '-')}",
            f"品質スコア: {metrics.get('score', 0)}/100",
            f"品質ゲート: {'合格' if gate_pass else '要調整'} ({gate}/100)",
            '',
            'カーブ指標:',
            f"  Fカーブ: {metrics.get('curves', 0)}",
            f"  キー数: {metrics.get('keys', 0)}",
            f"  平均キー数 / カーブ: {metrics.get('density', 0.0):.3f}",
            f"  同一フレーム重複キー: {metrics.get('duplicate_keys', 0)}",
            f"  静的カーブ: {metrics.get('static_curves', 0)}",
            f"  高密度カーブ: {metrics.get('very_dense_curves', 0)}",
            f"  カーブ保護候補: {metrics.get('curvature_candidates', 0)}",
            f"  オーバーシュート候補: {metrics.get('overshoot_candidates', 0)}",
            f"  ハンドルリスク: {metrics.get('handle_risks', 0)}",
            f"  オイラー飛び候補: {metrics.get('euler_jumps', 0)}",
            '',
            'モーションサンプリング:',
            f"  サンプル対象オブジェクト: {metrics.get('motion', {}).get('objects', 0)}",
            f"  サンプル数: {metrics.get('motion', {}).get('samples', 0)}",
            f"  最大速度 / フレーム: {metrics.get('motion', {}).get('max_speed', 0.0):.6f}",
            f"  平均速度 / フレーム: {metrics.get('motion', {}).get('average_speed', 0.0):.6f}",
            f"  速度ジッター率: {metrics.get('motion', {}).get('speed_jitter', 0.0):.6f}",
            f"  最大加速度 / フレーム: {metrics.get('motion', {}).get('max_acceleration', 0.0):.6f}",
            f"  加速度スパイク: {metrics.get('motion', {}).get('acceleration_spikes', 0)}",
            f"  接地サンプル: {metrics.get('contact', {}).get('contact_samples', 0)}",
            f"  接地横滑り合計: {metrics.get('contact', {}).get('drift', 0.0):.6f}",
            f"  最大接地横滑り: {metrics.get('contact', {}).get('max_drift', 0.0):.6f}",
            '',
            '精密処理:',
            f"  アクション: {precision_metrics.get('action', '-')}",
            f"  確認カーブ数: {precision_metrics.get('curves', 0)}",
            f"  重複キー削除 / 候補: {precision_metrics.get('duplicate_removed', 0)}",
            f"  適応簡略化候補: {precision_metrics.get('simplify_candidates', 0)}",
            f"  適応簡略化削除: {precision_metrics.get('simplified_removed', 0)}",
            f"  カーブ保護キー: {precision_metrics.get('curvature_protected', 0)}",
            f"  最大推定誤差: {precision_metrics.get('max_curve_error', 0.0):.8f}",
            f"  ハンドル編集: {precision_metrics.get('handles_changed', 0)}",
            '',
            '推奨対応:',
        ]
    else:
        lines = [
            'Animation Recipes - Quality Report',
            'Copyright (C) 2026 JELararagi',
            '',
            f"Object: {metrics.get('object', '-')}",
            f"Action: {metrics.get('action', '-')}",
            f"Quality Score: {metrics.get('score', 0)}/100",
            f"Quality Gate: {'Passed' if gate_pass else 'Needs Polish'} ({gate}/100)",
            '',
            'Curve Metrics:',
            f"  F-Curves: {metrics.get('curves', 0)}",
            f"  Keys: {metrics.get('keys', 0)}",
            f"  Average Keys / Curve: {metrics.get('density', 0.0):.3f}",
            f"  Duplicate Same-Frame Keys: {metrics.get('duplicate_keys', 0)}",
            f"  Static Curves: {metrics.get('static_curves', 0)}",
            f"  Very Dense Curves: {metrics.get('very_dense_curves', 0)}",
            f"  Curvature Guard Candidates: {metrics.get('curvature_candidates', 0)}",
            f"  Overshoot Candidates: {metrics.get('overshoot_candidates', 0)}",
            f"  Handle Risks: {metrics.get('handle_risks', 0)}",
            f"  Euler Jump Candidates: {metrics.get('euler_jumps', 0)}",
            '',
            'Motion Sampling:',
            f"  Sampled Objects: {metrics.get('motion', {}).get('objects', 0)}",
            f"  Samples: {metrics.get('motion', {}).get('samples', 0)}",
            f"  Max Speed / Frame: {metrics.get('motion', {}).get('max_speed', 0.0):.6f}",
            f"  Average Speed / Frame: {metrics.get('motion', {}).get('average_speed', 0.0):.6f}",
            f"  Speed Jitter Ratio: {metrics.get('motion', {}).get('speed_jitter', 0.0):.6f}",
            f"  Max Acceleration / Frame: {metrics.get('motion', {}).get('max_acceleration', 0.0):.6f}",
            f"  Acceleration Spikes: {metrics.get('motion', {}).get('acceleration_spikes', 0)}",
            f"  Contact Samples: {metrics.get('contact', {}).get('contact_samples', 0)}",
            f"  Total Contact Drift: {metrics.get('contact', {}).get('drift', 0.0):.6f}",
            f"  Max Contact Drift: {metrics.get('contact', {}).get('max_drift', 0.0):.6f}",
            '',
            'Precision Pass:',
            f"  Action: {precision_metrics.get('action', '-')}",
            f"  Curves Reviewed: {precision_metrics.get('curves', 0)}",
            f"  Duplicate Keys Removed / Candidates: {precision_metrics.get('duplicate_removed', 0)}",
            f"  Adaptive Simplify Candidates: {precision_metrics.get('simplify_candidates', 0)}",
            f"  Adaptive Simplify Removed: {precision_metrics.get('simplified_removed', 0)}",
            f"  Curvature-Protected Keys: {precision_metrics.get('curvature_protected', 0)}",
            f"  Max Estimated Error: {precision_metrics.get('max_curve_error', 0.0):.8f}",
            f"  Handle Edits: {precision_metrics.get('handles_changed', 0)}",
            '',
            'Recommendations:',
        ]
    lines.extend(f'  - {item}' for item in recommendations)
    lines.extend(['', 'JSON:', json.dumps(payload, ensure_ascii=False, indent=2)])
    try:
        text_block.clear()
    except Exception:
        pass
    text_block.write('\n'.join(lines))
    return text_block.name


def _smoothstep(value: float) -> float:
    value = max(0.0, min(1.0, float(value)))
    return value * value * (3.0 - 2.0 * value)


def _phase_distance(a: float, b: float) -> float:
    return abs((float(a) - float(b) + 0.5) % 1.0 - 0.5)


def _contact_unlock_factor(phase: float, style: str) -> float:
    style = str(style or 'WALK').upper()
    if style == 'MECHANICAL':
        return 0.0
    contacts = (0.0, 0.5) if style in {'WALK', 'CINEMATIC'} else (0.0,)
    nearest = min(_phase_distance(phase, contact) for contact in contacts)
    return _smoothstep(nearest / 0.105)


def _apply_locomotion_style(phase: float, style: str, bob: float, yaw: float, *, contact_lock: bool = True) -> tuple[float, float, float]:
    style = str(style or 'WALK').upper()
    phase = float(phase)
    if style == 'RUN':
        vertical = max(0.0, math.sin(phase * math.tau)) * bob * 1.35
        yaw_value = math.sin(phase * math.tau) * yaw * 0.65
        travel_ease = phase
    elif style == 'MECHANICAL':
        vertical = 0.0
        yaw_value = 0.0
        travel_ease = phase
    elif style == 'CINEMATIC':
        t = phase - math.floor(phase)
        ease = _smoothstep(t)
        vertical = math.sin(t * math.tau * 2.0) * bob * 0.75
        yaw_value = math.sin(t * math.tau) * yaw
        travel_ease = math.floor(phase) + ease
    else:
        vertical = abs(math.sin(phase * math.tau * 2.0)) * bob
        yaw_value = math.sin(phase * math.tau) * yaw
        travel_ease = phase
    if contact_lock:
        vertical *= _contact_unlock_factor(phase, style)
    return travel_ease, vertical, yaw_value


def _axis_side_vector(axis: Vector) -> Vector:
    try:
        forward = Vector(axis).normalized()
    except Exception:
        forward = Vector((1.0, 0.0, 0.0))
    up = Vector((0.0, 0.0, 1.0))
    if abs(forward.dot(up)) > 0.98:
        up = Vector((0.0, 1.0, 0.0))
    side = up.cross(forward)
    if side.length <= 1.0e-8:
        return Vector((0.0, 1.0, 0.0))
    return side.normalized()


def _locomotion_sample_frames(start: int, end: int, cycle: int, density: int, style: str) -> list[int]:
    step = max(1, int(round(float(cycle) / float(max(4, density)))))
    samples = set(range(int(start), int(end) + 1, step))
    samples.add(int(start))
    samples.add(int(end))
    style = str(style or 'WALK').upper()
    contact_offsets = [0]
    if style in {'WALK', 'CINEMATIC'}:
        contact_offsets.append(max(1, int(round(cycle * 0.5))))
    for base in range(int(start), int(end) + 1, max(1, int(cycle))):
        for offset in contact_offsets:
            frame = int(base + offset)
            if int(start) <= frame <= int(end):
                samples.add(frame)
    return sorted(samples)



def _contact_drift_metrics(context) -> dict:
    settings = _settings(context)
    objects = _selected_objects(context)
    scene = getattr(context, 'scene', None)
    if scene is None or not objects:
        return {'objects': 0, 'contact_samples': 0, 'drift': 0.0, 'max_drift': 0.0}
    epsilon = float(getattr(settings, 'smart_contact_floor_epsilon', 0.015) if settings else 0.015)
    step = max(1, int(getattr(settings, 'smart_quality_sample_step', 2) if settings else 2))
    try:
        start, end = get_bake_range(scene, settings)
    except Exception:
        start, end = int(scene.frame_start), int(scene.frame_end)
    frames = list(range(int(start), int(end) + 1, step))
    if frames and frames[-1] != int(end):
        frames.append(int(end))
    old_frame = int(getattr(scene, 'frame_current', start))
    total_drift = 0.0
    max_drift = 0.0
    contact_samples = 0
    try:
        for obj in objects:
            samples = []
            for frame in frames:
                try:
                    scene.frame_set(frame)
                    loc = Vector(getattr(obj, 'matrix_world').translation)
                    samples.append((frame, loc))
                except Exception:
                    pass
            if not samples:
                continue
            floor_z = min(float(loc.z) for _frame, loc in samples)
            contacts = [(frame, loc) for frame, loc in samples if float(loc.z) <= floor_z + epsilon]
            contact_samples += len(contacts)
            for (_a_frame, a), (_b_frame, b) in zip(contacts, contacts[1:]):
                drift = math.hypot(float(b.x - a.x), float(b.y - a.y))
                total_drift += drift
                max_drift = max(max_drift, drift)
    finally:
        try:
            scene.frame_set(old_frame)
        except Exception:
            pass
    return {'objects': len(objects), 'contact_samples': contact_samples, 'drift': total_drift, 'max_drift': max_drift}


def _flatten_contact_handles(key, value: float) -> None:
    try:
        key.interpolation = 'BEZIER'
    except Exception:
        pass
    try:
        key.handle_left_type = 'FREE'
        key.handle_right_type = 'FREE'
        key.handle_left.y = float(value)
        key.handle_right.y = float(value)
    except Exception:
        try:
            key.handle_left_type = 'AUTO_CLAMPED'
            key.handle_right_type = 'AUTO_CLAMPED'
        except Exception:
            pass


def _contact_groups(points, epsilon: float, min_span: int) -> list[list[tuple]]:
    if not points:
        return []
    floor_value = min(float(value) for _idx, _frame, value, _key in points)
    groups = []
    current = []
    previous_frame = None
    for point in points:
        _idx, frame, value, _key = point
        if float(value) <= floor_value + epsilon:
            if previous_frame is None or abs(float(frame) - float(previous_frame)) <= 2.5:
                current.append(point)
            else:
                if len(current) >= max(1, int(min_span)):
                    groups.append(current)
                current = [point]
            previous_frame = frame
        else:
            if len(current) >= max(1, int(min_span)):
                groups.append(current)
            current = []
            previous_frame = None
    if len(current) >= max(1, int(min_span)):
        groups.append(current)
    return groups


def _apply_contact_stabilizer(context) -> dict:
    settings = _settings(context)
    objects = _selected_objects(context)
    epsilon = float(getattr(settings, 'smart_contact_floor_epsilon', 0.015) if settings else 0.015)
    min_span = int(getattr(settings, 'smart_contact_min_span', 2) if settings else 2)
    flatten_handles = bool(getattr(settings, 'smart_contact_flatten_handles', True) if settings else True)
    metrics = {'objects': 0, 'curves': 0, 'groups': 0, 'keys_flattened': 0}
    backed_up_actions = set()
    for obj in objects:
        action = active_action(context, obj)
        if action is None:
            continue
        z_curve = None
        for fcurve in iter_action_fcurves(action, datablock=obj):
            if str(getattr(fcurve, 'data_path', '')) == 'location' and int(getattr(fcurve, 'array_index', -1)) == 2:
                z_curve = fcurve
                break
        if z_curve is None:
            continue
        action_id = getattr(action, 'name', '') or str(id(action))
        if action_id not in backed_up_actions:
            try:
                ensure_action_backup(context, 'contact_stabilizer', obj=obj, action=action)
            except Exception:
                pass
            backed_up_actions.add(action_id)
        points = _key_points(z_curve)
        if len(points) < 2:
            continue
        groups = _contact_groups(points, epsilon, min_span)
        if not groups:
            continue
        metrics['objects'] += 1
        metrics['curves'] += 1
        metrics['groups'] += len(groups)
        for group in groups:
            floor_value = min(float(value) for _idx, _frame, value, _key in group)
            for _idx, _frame, _value, key in group:
                try:
                    key.co.y = floor_value
                    if flatten_handles:
                        _flatten_contact_handles(key, floor_value)
                    metrics['keys_flattened'] += 1
                except Exception:
                    pass
        try:
            z_curve.update()
        except Exception:
            pass
    return metrics


def _resolve_timing_intent(context, settings) -> str:
    intent = str(getattr(settings, 'smart_timing_intent', 'AUTO') if settings else 'AUTO').upper()
    if intent != 'AUTO':
        return intent
    stage = str(getattr(settings, 'smart_workflow_stage', 'AUTO') if settings else 'AUTO').upper()
    if stage == 'BLOCKING':
        return 'BLOCKING'
    if stage == 'PHYSICS':
        return 'IMPACT'
    if stage == 'MOCAP':
        return 'SPLINE'
    if stage == 'POLISH':
        return 'SPLINE'
    return 'SPLINE'


def _apply_timing_intent(context) -> dict:
    settings = _settings(context)
    action, curves = _active_editable_action_curves(context)
    if action is None or settings is None:
        return {'action': None, 'curves': 0, 'keys': 0, 'intent': 'AUTO'}
    intent = _resolve_timing_intent(context, settings)
    changed = 0
    curve_count = 0
    for fcurve in curves:
        points = _key_points(fcurve)
        if not points:
            continue
        curve_count += 1
        previous_value = None
        for _idx, _frame, value, key in points:
            try:
                if intent == 'BLOCKING':
                    key.interpolation = 'CONSTANT'
                elif intent == 'MECHANICAL':
                    key.interpolation = 'LINEAR'
                else:
                    key.interpolation = 'BEZIER'
                    if intent == 'FLOAT':
                        key.handle_left_type = 'AUTO'
                        key.handle_right_type = 'AUTO'
                    else:
                        key.handle_left_type = 'AUTO_CLAMPED'
                        key.handle_right_type = 'AUTO_CLAMPED'
                    if intent == 'IMPACT' and previous_value is not None and abs(float(value) - float(previous_value)) > float(getattr(settings, 'remove_threshold', 1e-5)) * 32.0:
                        key.handle_left_type = 'VECTOR'
                        key.handle_right_type = 'AUTO_CLAMPED'
                changed += 1
            except Exception:
                pass
            previous_value = float(value)
        try:
            fcurve.update()
        except Exception:
            pass
    return {'action': getattr(action, 'name', None), 'curves': curve_count, 'keys': changed, 'intent': intent}

def _stage_ops_for_context(context, stage: str, metrics: dict | None = None) -> tuple[str, list[str]]:
    settings = _settings(context)
    stage = str(stage or 'AUTO').upper()
    metrics = metrics or {}
    if stage == 'AUTO':
        action = active_action(context)
        if action is None:
            stage = 'BLOCKING' if active_object(context) is not None else 'REVIEW'
        elif metrics.get('euler_jumps', 0) or metrics.get('very_dense_curves', 0) or metrics.get('density', 0.0) >= 48.0:
            stage = 'MOCAP'
        elif metrics.get('overshoot_candidates', 0) or metrics.get('handle_risks', 0):
            stage = 'POLISH'
        elif metrics.get('score', 100) < int(getattr(settings, 'smart_quality_gate_min_score', 85) if settings else 85):
            stage = 'POLISH'
        elif metrics.get('motion', {}).get('acceleration_spikes', 0):
            stage = 'PHYSICS'
        elif getattr(context, 'mode', '') == 'POSE':
            stage = 'SPLINE'
        else:
            stage = 'REVIEW'
    mapping = {
        'BLOCKING': ['sas.smart_pose_assistant', 'sas.smart_motion_director'],
        'SPLINE': ['sas.smart_motion_director', 'sas.smart_timing_intent_solver', 'sas.smart_graph_optimizer'],
        'MOCAP': ['sas.smart_graph_optimizer', 'sas.smart_timing_intent_solver', 'sas.smart_precision_polish'],
        'PHYSICS': ['sas.smart_physics_director', 'sas.smart_contact_stabilizer', 'sas.smart_visualize_motion'],
        'POLISH': ['sas.smart_contact_stabilizer', 'sas.smart_timing_intent_solver', 'sas.smart_precision_polish', 'sas.smart_quality_report'],
        'REVIEW': ['sas.smart_quality_report', 'sas.smart_visualize_motion'],
    }
    return stage, list(mapping.get(stage, mapping['REVIEW']))

# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------


class SAS_OT_smart_contact_stabilizer(Operator):
    bl_idname = "sas.smart_contact_stabilizer"
    bl_label = "Smart Contact Stabilizer"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Flatten detected planted contact keys on selected objects' vertical location curves and align their handles. This reduces foot sliding, prop floating, and fulcrum jitter while keeping the result as editable Blender keyframes.",
            "選択オブジェクトの上下位置カーブから接地候補キーを検出し、接地中のZ値とハンドルを安定化します。足滑り、小物の浮き、支点のジッターを抑え、結果は編集可能な Blender キーフレームとして残ります。",
            context,
        )

    def execute(self, context):
        if not _selected_objects(context):
            self.report({'WARNING'}, sas_text("Select at least one animated object.", "アニメーション済みオブジェクトを1つ以上選択してください。", context))
            return {'CANCELLED'}
        try:
            metrics = _apply_contact_stabilizer(context)
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Contact stabilizer failed: {exc}", f"接地安定化に失敗しました: {sas_error_reason(exc)}", context))
            return {'CANCELLED'}
        if int(metrics.get('keys_flattened', 0) or 0) <= 0:
            self.report({'WARNING'}, sas_text("No stable contact key group was detected.", "安定化対象の接地キーグループは検出されませんでした。", context))
            return {'CANCELLED'}
        add_log(context, "INFO", f"Smart Contact Stabilizer flattened {metrics.get('keys_flattened', 0)} key(s) across {metrics.get('groups', 0)} contact group(s).", f"Smart Contact Stabilizer は {metrics.get('groups', 0)} 個の接地グループで {metrics.get('keys_flattened', 0)} 個のキーを安定化しました。")
        self.report({'INFO'}, sas_text(f"Flattened {metrics.get('keys_flattened', 0)} contact key(s).", f"接地キー {metrics.get('keys_flattened', 0)} 個を安定化しました。", context))
        return {'FINISHED'}


class SAS_OT_smart_timing_intent_solver(Operator):
    bl_idname = "sas.smart_timing_intent_solver"
    bl_label = "Smart Timing Intent Solver"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Apply intent-based interpolation to editable curves: stepped blocking, auto-clamped spline flow, impact-aware vector hits, floating Bezier drift, or mechanical linear timing. Use it to turn technical curve cleanup into a deliberate animation feel.",
            "編集可能カーブへ意図別補間を適用します。ステップ式ブロッキング、自動クランプのスプライン、インパクト向けベクトル処理、浮遊感のあるベジェ、機械的リニアを選べます。技術的なカーブ整理を、意図を持った動きの質感へ変換します。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        if action is None:
            self.report({'WARNING'}, sas_text("No active action to solve timing intent.", "タイミング意図を適用するアクティブアクションがありません。", context))
            return {'CANCELLED'}
        backup = ensure_action_backup(context, "timing_intent")
        metrics = _apply_timing_intent(context)
        if int(metrics.get('keys', 0) or 0) <= 0:
            discard_action_backup(context, backup)
            self.report({'WARNING'}, sas_text("No editable keyframes were found.", "編集可能なキーフレームが見つかりませんでした。", context))
            return {'CANCELLED'}
        add_log(context, "INFO", f"Smart Timing Intent Solver applied {metrics.get('intent', 'AUTO')} to {metrics.get('keys', 0)} key(s).", f"Smart Timing Intent Solver は {metrics.get('intent', 'AUTO')} を {metrics.get('keys', 0)} 個のキーへ適用しました。")
        self.report({'INFO'}, sas_text(f"Timing intent applied to {metrics.get('keys', 0)} key(s).", f"タイミング意図を {metrics.get('keys', 0)} 個のキーへ適用しました。", context))
        return {'FINISHED'}


class SAS_OT_smart_superior_director(Operator):
    bl_idname = "sas.smart_superior_director"
    bl_label = "Smart Superior Director"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Run the strongest Animation Recipes studio pass: quality preflight, context-aware stage operations, contact stabilization, timing-intent solving, precision polish, quality gate report, and optional visual review helpers.",
            "アニメーション レシピ の最強スタジオパスを実行します。品質事前診断、文脈対応の段階処理、接地安定化、タイミング意図適用、精密ポリッシュ、品質ゲートレポート、任意の可視レビューをまとめます。",
            context,
        )

    def execute(self, context):
        settings = _settings(context)
        if settings is None:
            self.report({'WARNING'}, sas_text("Smart Animation settings are not available.", "Smart Animation 設定が利用できません。", context))
            return {'CANCELLED'}
        metrics = {}
        try:
            metrics = _collect_smart_quality(context)
        except Exception:
            metrics = {}
        requested_stage = getattr(settings, 'smart_workflow_stage', 'AUTO')
        _resolved_stage, stage_ops = _stage_ops_for_context(context, requested_stage, metrics)
        ops = []
        for op_id in list(stage_ops) + ['sas.smart_contact_stabilizer', 'sas.smart_timing_intent_solver', 'sas.smart_precision_polish', 'sas.smart_quality_report']:
            if op_id not in ops:
                ops.append(op_id)
        if bool(getattr(settings, 'smart_super_visual_review', True)) and 'sas.smart_visualize_motion' not in ops:
            ops.append('sas.smart_visualize_motion')
        finished, failed = _run_ops(context, ops)
        if finished == 0:
            self.report({'WARNING'}, sas_text("Smart Superior Director could not run in the current context. Check selection and action data.", "現在のコンテキストでは Smart Superior Director を実行できませんでした。選択とアクションデータを確認してください。", context))
            return {'CANCELLED'}
        add_log(context, "INFO", f"Smart Superior Director ran {finished} operation(s); skipped {len(failed)}.", f"Smart Superior Director は {finished} 個の操作を実行し、{len(failed)} 個をスキップしました。")
        self.report({'INFO'}, sas_text(f"Superior Director ran {finished} operation(s).", f"Superior Director で {finished} 個の操作を実行しました。", context))
        return {'FINISHED'}


class SAS_OT_smart_quality_report(Operator):
    bl_idname = "sas.smart_quality_report"
    bl_label = "Smart Quality Report"
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Analyze the active action and selected objects for production risks: duplicate keys, static channels, dense baked curves, Euler jumps, Bezier overshoot, handle risk, contact drift, spacing speed, and acceleration. The result is written to a Text datablock so it can be reviewed or archived with the scene.",
            "アクティブアクションと選択オブジェクトを解析し、重複キー、静的チャンネル、高密度ベイクカーブ、オイラー飛び、ベジェのオーバーシュート、ハンドルリスク、接地横滑り、スペーシング速度、加速度などの制作リスクを検出します。結果はテキストデータブロックへ書き出され、シーン内で確認・保管できます。",
            context,
        )

    def execute(self, context):
        try:
            metrics = _collect_smart_quality(context)
            text_name = _write_quality_report(context, metrics=metrics)
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Quality report failed: {exc}", f"品質レポート作成に失敗しました: {sas_error_reason(exc)}", context))
            return {'CANCELLED'}
        add_log(context, "INFO", f"Smart Quality Report written to {text_name} with score {metrics.get('score', 0)}/100.", f"Smart Quality Report を {text_name} に作成しました。スコアは {metrics.get('score', 0)}/100 です。")
        self.report({'INFO'}, sas_text(f"Quality report written to {text_name}.", f"品質レポートを {text_name} に作成しました。", context))
        return {'FINISHED'}


class SAS_OT_smart_precision_polish(Operator):
    bl_idname = "sas.smart_precision_polish"
    bl_label = "Smart Precision Polish"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Run a director-grade polish pass: Euler filter, duplicate/static cleanup, adaptive sparse-key reduction, flow-safe handles, and a quality report. Preview Only turns it into a non-destructive estimate.",
            "ディレクター確認向けの精密ポリッシュを実行します。オイラー補正、重複 / 静的整理、適応型の疎キー化、流れを保つハンドル調整、品質レポート作成をまとめて行います。「プレビューのみ」では非破壊の見積もりになります。",
            context,
        )

    def execute(self, context):
        settings = _settings(context)
        action = active_action(context)
        if action is None or settings is None:
            self.report({'WARNING'}, sas_text("No active action to polish.", "ポリッシュするアクティブアクションがありません。", context))
            return {'CANCELLED'}
        if not bool(getattr(settings, 'preview_only', False)):
            ensure_action_backup(context, "precision_polish")
            _run_ops(context, ['sas.euler_filter', 'sas.remove_duplicate_keys', 'sas.delete_static_channels'])
            if bool(getattr(settings, 'smart_graph_include_unbake', True)):
                _run_op(context, 'sas.smart_unbake')
        precision = _smart_precision_curve_pass(context, preview_only=bool(getattr(settings, 'preview_only', False)))
        metrics = _collect_smart_quality(context)
        try:
            text_name = _write_quality_report(context, metrics=metrics, precision_metrics=precision)
        except Exception:
            text_name = '-'
        if bool(getattr(settings, 'preview_only', False)):
            message_en = f"Precision preview: {precision.get('duplicate_removed', 0)} duplicate and {precision.get('simplify_candidates', 0)} adaptive candidate key(s)."
            message_ja = f"精密プレビュー: 重複候補 {precision.get('duplicate_removed', 0)} 個、適応削減候補 {precision.get('simplify_candidates', 0)} 個です。"
        else:
            message_en = f"Precision polish removed {precision.get('duplicate_removed', 0) + precision.get('simplified_removed', 0)} key(s), adjusted {precision.get('handles_changed', 0)} handles, and wrote {text_name}."
            message_ja = f"精密ポリッシュで {precision.get('duplicate_removed', 0) + precision.get('simplified_removed', 0)} 個のキーを削減し、{precision.get('handles_changed', 0)} 個のハンドルを調整し、{text_name} を作成しました。"
        add_log(context, "INFO", message_en, message_ja)
        self.report({'INFO'}, sas_text(message_en, message_ja, context))
        return {'FINISHED'}


class SAS_OT_smart_feature_coverage_report(Operator):
    bl_idname = "sas.smart_feature_coverage_report"
    bl_label = "Smart Feature Coverage Report"
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Create a Text datablock that maps every researched source feature to its Animation Recipes equivalent. Use it to confirm where each upgraded function is located.",
            "調査リストの各元機能を アニメーション レシピ 側の対応機能へ対応付けたテキストデータブロックを作成します。各アップグレード機能の場所確認に使います。",
            context,
        )

    def execute(self, context):
        try:
            text_name = _write_coverage_text(context)
        except Exception as exc:
            self.report({'ERROR'}, sas_text(f"Coverage report failed: {exc}", f"カバレッジレポート作成に失敗しました: {sas_error_reason(exc)}", context))
            return {'CANCELLED'}
        add_log(context, "INFO", f"Animation Recipes coverage report written to {text_name}.", f"アニメーション レシピ カバレッジレポートを {text_name} に作成しました。")
        self.report({'INFO'}, sas_text(f"Coverage report written to {text_name}.", f"カバレッジレポートを {text_name} に作成しました。", context))
        return {'FINISHED'}


class SAS_OT_smart_graph_optimizer(Operator):
    bl_idname = "sas.smart_graph_optimizer"
    bl_label = "Smart Graph Optimizer"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Run a GraphKit-style optimization pass: Euler continuity, duplicate-key removal, static-channel cleanup, curve smoothing, and optional unbaking. It respects the normal safety settings such as Preview Only and Auto Backup where the underlying operators support them.",
            "GraphKit 風の最適化として、オイラー連続化、重複キー削除、静的チャンネル整理、カーブ平滑化、必要に応じたアンベイクをまとめて実行します。基礎オペレーターが対応する範囲でプレビューのみ・自動バックアップなどの安全設定を尊重します。",
            context,
        )

    def execute(self, context):
        action = active_action(context)
        if action is None:
            self.report({'WARNING'}, sas_text("No active action to optimize.", "最適化するアクティブアクションがありません。", context))
            return {'CANCELLED'}
        settings = _settings(context)
        preview_only = bool(getattr(settings, 'preview_only', False)) if settings else False
        finished = 0
        failed: list[str] = []
        changed = 0
        if not preview_only:
            ops = ['sas.euler_filter', 'sas.remove_duplicate_keys', 'sas.delete_static_channels', 'sas.smooth_curves']
            if settings and getattr(settings, 'smart_graph_include_unbake', True):
                ops.append('sas.smart_unbake')
            with batch_action_backup(context, action, "smart_graph"):
                finished, failed = _run_ops(context, ops)
                if settings and getattr(settings, 'smart_graph_auto_clamped', True):
                    changed = _set_keyframe_interpolation(action, 'BEZIER', 'AUTO_CLAMPED')
        precision = {}
        if settings and getattr(settings, 'smart_enable_adaptive_precision', True):
            precision = _smart_precision_curve_pass(context, preview_only=preview_only)
            changed += int(precision.get('handles_changed', 0) or 0)
        if preview_only:
            add_log(context, "INFO", f"Smart Graph Optimizer preview found {precision.get('duplicate_removed', 0) if precision else 0} duplicate and {precision.get('simplify_candidates', 0) if precision else 0} adaptive candidate key(s).", f"Smart Graph Optimizer プレビューで、重複候補 {precision.get('duplicate_removed', 0) if precision else 0} 個、適応削減候補 {precision.get('simplify_candidates', 0) if precision else 0} 個を検出しました。")
            self.report({'INFO'}, sas_text(f"Graph optimizer preview: {precision.get('simplify_candidates', 0) if precision else 0} adaptive candidate key(s).", f"グラフ最適化プレビュー: 適応削減候補 {precision.get('simplify_candidates', 0) if precision else 0} 個です。", context))
            return {'FINISHED'}
        add_log(context, "INFO", f"Smart Graph Optimizer finished {finished} passes; failed or skipped {len(failed)}; adjusted {changed} handles; adaptive removed {precision.get('simplified_removed', 0) if precision else 0} keys; protected {precision.get('curvature_protected', 0) if precision else 0} curvature keys.", f"Smart Graph Optimizer は {finished} 個の処理を完了し、{len(failed)} 個を失敗またはスキップし、{changed} 個のハンドルを調整し、適応処理で {precision.get('simplified_removed', 0) if precision else 0} 個のキーを削減し、{precision.get('curvature_protected', 0) if precision else 0} 個のカーブ重要キーを保護しました。")
        self.report({'INFO'}, sas_text(f"Graph optimizer finished {finished} pass(es); adaptive removed {precision.get('simplified_removed', 0) if precision else 0} key(s).", f"グラフ最適化で {finished} 個の処理を完了し、適応処理で {precision.get('simplified_removed', 0) if precision else 0} 個のキーを削減しました。", context))
        return {'FINISHED'}


class SAS_OT_smart_motion_director(Operator):
    bl_idname = "sas.smart_motion_director"
    bl_label = "Smart Motion Director"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Run an animBot/AnimAide-style pose and curve director. It can create intelligent tween keys, push or pull the current frame, and scale selected key shapes relative to neighboring keys.",
            "animBot / AnimAide 風のポーズ・カーブ調整を実行します。スマートトゥイーン、現在フレームのプッシュ / プル、近隣キー基準の形状スケールをまとめて扱えます。",
            context,
        )

    def execute(self, context):
        settings = _settings(context)
        mode = getattr(settings, 'smart_motion_director_mode', 'FULL') if settings else 'FULL'
        mapping = {
            'TWEEN': ['sas.apply_tween'],
            'PUSH_PULL': ['sas.push_pull_keys'],
            'SCALE_NEIGHBORS': ['sas.scale_to_neighbors'],
            'FULL': ['sas.apply_tween', 'sas.push_pull_keys', 'sas.scale_to_neighbors'],
        }
        ops = mapping.get(mode, mapping['FULL'])
        finished, failed = _run_ops(context, ops)
        if finished == 0:
            self.report({'WARNING'}, sas_text("Motion Director needs an active action with neighboring keys.", "Motion Director には前後キーを持つアクティブアクションが必要です。", context))
            return {'CANCELLED'}
        flow_handles = 0
        if settings and getattr(settings, 'smart_motion_preserve_flow', True):
            _action, curves = _active_editable_action_curves(context)
            for fcurve in curves:
                flow_handles += _set_flow_safe_handles(fcurve)
        add_log(context, "INFO", f"Smart Motion Director ran {finished} pass(es); skipped {len(failed)}; adjusted {flow_handles} flow-safe handles.", f"Smart Motion Director は {finished} 個の処理を実行し、{len(failed)} 個をスキップし、{flow_handles} 個の流れ保持ハンドルを調整しました。")
        self.report({'INFO'}, sas_text(f"Motion Director ran {finished} pass(es).", f"Motion Director で {finished} 個の処理を実行しました。", context))
        return {'FINISHED'}


class SAS_OT_smart_visualize_motion(Operator):
    bl_idname = "sas.smart_visualize_motion"
    bl_label = "Smart Visualize Motion"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Create spacing review helpers similar to advanced motion trails, ghosting, and ballistic trajectory tools. Use this before changing curves to evaluate arcs, silhouette spacing, and physics plausibility.",
            "高度なモーショントレイル、ゴースト、弾道軌道ツールに近いスペーシング確認用ヘルパーを作成します。カーブ編集前に、アーク、シルエット間隔、物理的な自然さを確認できます。",
            context,
        )

    def execute(self, context):
        settings = _settings(context)
        mode = getattr(settings, 'smart_visualizer_mode', 'ALL') if settings else 'ALL'
        mapping = {
            'TRAIL_GHOST': ['sas.create_trail_curve', 'sas.create_ghost_preview'],
            'PATHS': ['sas.calculate_motion_paths'],
            'BALLISTIC': ['sas.create_ballistic_guide'],
            'ALL': ['sas.create_trail_curve', 'sas.create_ghost_preview', 'sas.calculate_motion_paths', 'sas.create_ballistic_guide'],
        }
        finished, failed = _run_ops(context, mapping.get(mode, mapping['ALL']))
        if finished == 0:
            self.report({'WARNING'}, sas_text("No motion visualization helper could be created for the current selection.", "現在の選択ではモーション可視化ヘルパーを作成できませんでした。", context))
            return {'CANCELLED'}
        add_log(context, "INFO", f"Smart Visualizer created or updated {finished} helper type(s); skipped {len(failed)}.", f"Smart Visualizer は {finished} 種類のヘルパーを作成または更新し、{len(failed)} 個をスキップしました。")
        self.report({'INFO'}, sas_text(f"Created {finished} visualization helper type(s).", f"{finished} 種類の可視化ヘルパーを作成しました。", context))
        return {'FINISHED'}


class SAS_OT_smart_physics_director(Operator):
    bl_idname = "sas.smart_physics_director"
    bl_label = "Smart Physics Director"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Run a Cascadeur/BroDynamics-style physics assistant. Depending on the selected mode it creates ballistic guides, bakes AutoPhysics-like location arcs, cleans planted fulcrums, bakes spring follow-through, or converts rigid-body motion into editable keys.",
            "Cascadeur / BroDynamics 風の物理アシスタントを実行します。モードに応じて、弾道ガイド作成、AutoPhysics 風の位置補正ベイク、接地点整理、スプリングフォロースルー、剛体モーションの編集可能キー化を行います。",
            context,
        )

    def execute(self, context):
        settings = _settings(context)
        mode = getattr(settings, 'smart_physics_director_mode', 'AUTO') if settings else 'AUTO'
        mapping = {
            'BALLISTIC_GUIDE': ['sas.create_ballistic_guide'],
            'BALLISTIC_BAKE': ['sas.bake_ballistic_keys'],
            'FULCRUM': ['sas.auto_fulcrum_cleanup', 'sas.apply_contact_hold'],
            'SPRING': ['sas.bake_spring_dynamics', 'sas.bake_spring_magic'],
            'RIGID_BODY': ['sas.bake_rigid_body_keys'],
            'AUTO': ['sas.create_ballistic_guide', 'sas.auto_fulcrum_cleanup', 'sas.bake_spring_dynamics'],
        }
        finished, failed = _run_ops(context, mapping.get(mode, mapping['AUTO']))
        if finished == 0:
            self.report({'WARNING'}, sas_text("Physics Director could not run on the current selection.", "現在の選択では Physics Director を実行できませんでした。", context))
            return {'CANCELLED'}
        add_log(context, "INFO", f"Smart Physics Director ran {finished} physics pass(es); skipped {len(failed)}.", f"Smart Physics Director は {finished} 個の物理処理を実行し、{len(failed)} 個をスキップしました。")
        self.report({'INFO'}, sas_text(f"Physics Director ran {finished} pass(es).", f"Physics Director で {finished} 個の処理を実行しました。", context))
        return {'FINISHED'}


class SAS_OT_smart_generate_locomotion_cycle(Operator):
    bl_idname = "sas.smart_generate_locomotion_cycle"
    bl_label = "Generate Smart Locomotion Cycle"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Generate an editable MotionMaker/CMotion-style cyclic locomotion base on selected objects. The result is ordinary keyframes, so it can be edited in the Dope Sheet, Graph Editor, or NLA after generation.",
            "選択オブジェクトに MotionMaker / CMotion 風の編集可能なサイクル移動ベースを生成します。結果は通常のキーフレームなので、生成後にドープシート、グラフエディター、NLAで編集できます。",
            context,
        )

    def execute(self, context):
        settings = _settings(context)
        if settings is None:
            return {'CANCELLED'}
        objects = _selected_objects(context)
        if not objects:
            self.report({'WARNING'}, sas_text("Select at least one object.", "少なくとも1つのオブジェクトを選択してください。", context))
            return {'CANCELLED'}

        scene = context.scene
        start, end = get_bake_range(scene, settings)
        cycle = max(2, int(getattr(settings, 'smart_locomotion_cycle_length', 24)))
        distance = float(getattr(settings, 'smart_locomotion_distance', 2.0))
        bob = float(getattr(settings, 'smart_locomotion_bob', 0.08))
        yaw = math.radians(float(getattr(settings, 'smart_locomotion_yaw_degrees', 0.0)))
        axis = _axis_vector(getattr(settings, 'smart_locomotion_axis', 'X'))
        side_axis = _axis_side_vector(axis)
        style = getattr(settings, 'smart_locomotion_style', 'WALK')
        sample_density = max(4, int(getattr(settings, 'smart_locomotion_sample_density', 12)))
        stride_width = float(getattr(settings, 'smart_locomotion_stride_width', 0.0))
        contact_lock = bool(getattr(settings, 'smart_locomotion_contact_lock', True))
        frames = _locomotion_sample_frames(start, end, cycle, sample_density, style)

        old_frame = scene.frame_current
        keyed_objects = 0
        try:
            for obj in objects:
                base_loc = Vector(getattr(obj, 'location', (0.0, 0.0, 0.0))).copy()
                try:
                    base_rot = obj.rotation_euler.copy()
                except Exception:
                    base_rot = None
                get_or_create_action_for_object(obj, base_name=f"{obj.name}_SmartLocomotion")
                for frame in frames:
                    scene.frame_set(int(frame))
                    progress = (float(frame) - float(start)) / max(1.0, float(end - start))
                    raw_phase = (float(frame) - float(start)) / float(cycle)
                    cycle_phase = raw_phase - math.floor(raw_phase)
                    travel_ease, vertical, yaw_value = _apply_locomotion_style(cycle_phase, style, bob, yaw, contact_lock=contact_lock)
                    loc = base_loc + axis * (distance * progress)
                    if str(style).upper() == 'CINEMATIC':
                        cycle_index = math.floor(raw_phase)
                        cycle_progress = (cycle_index + travel_ease) * float(cycle) / max(1.0, float(end - start))
                        loc = base_loc + axis * (distance * max(0.0, min(1.0, cycle_progress)))
                    if abs(stride_width) > 1.0e-9:
                        loc += side_axis * (math.sin(cycle_phase * math.tau) * stride_width)
                    loc.z += vertical
                    obj.location = loc
                    obj.keyframe_insert(data_path='location', frame=int(frame))
                    if base_rot is not None and abs(yaw) > 1e-9:
                        rot = base_rot.copy()
                        rot.z = base_rot.z + yaw_value
                        obj.rotation_euler = rot
                        obj.keyframe_insert(data_path='rotation_euler', frame=int(frame))
                action = active_action(context, obj)
                if getattr(settings, 'smart_locomotion_add_cycles', True):
                    _add_cycles_to_action(action)
                keyed_objects += 1
        finally:
            try:
                scene.frame_set(old_frame)
            except Exception:
                pass

        add_log(context, "INFO", f"Generated Smart Locomotion cycles on {keyed_objects} object(s).", f"{keyed_objects} 個のオブジェクトに Smart Locomotion サイクルを生成しました。")
        self.report({'INFO'}, sas_text(f"Generated locomotion keys on {keyed_objects} object(s).", f"{keyed_objects} 個のオブジェクトにロコモーションキーを生成しました。", context))
        return {'FINISHED'}


class SAS_OT_smart_ifl_sequence_manager(Operator):
    bl_idname = "sas.smart_ifl_sequence_manager"
    bl_label = "Smart Image Sequence Manager"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Apply IFL Playback Manager-style timing to image texture sequence users on selected objects. It sets start frame, duration, offset, cyclic playback, and can key the offset for timeline-synchronized screens or 2D effects.",
            "選択オブジェクト上の画像テクスチャシーケンスに IFL Playback Manager 風のタイミングを適用します。開始フレーム、継続フレーム、オフセット、循環再生を設定し、画面表示や2Dエフェクト同期用にオフセットへキーを打てます。",
            context,
        )

    def execute(self, context):
        settings = _settings(context)
        objects = _selected_objects(context)
        if settings is None or not objects:
            self.report({'WARNING'}, sas_text("Select objects that use image texture nodes.", "画像テクスチャノードを使うオブジェクトを選択してください。", context))
            return {'CANCELLED'}

        if bool(getattr(settings, 'smart_ifl_match_scene_range', False)):
            try:
                settings.smart_ifl_frame_start = int(context.scene.frame_start)
                settings.smart_ifl_frame_duration = max(1, int(context.scene.frame_end) - int(context.scene.frame_start) + 1)
            except Exception:
                pass

        changed = 0
        keyed = 0
        for obj in objects:
            for _material, _node, image_user in _material_image_users(obj):
                for attr, value in (
                    ('frame_start', int(settings.smart_ifl_frame_start)),
                    ('frame_duration', max(1, int(settings.smart_ifl_frame_duration))),
                    ('frame_offset', int(settings.smart_ifl_frame_offset)),
                    ('use_cyclic', bool(settings.smart_ifl_use_cyclic)),
                ):
                    if hasattr(image_user, attr):
                        try:
                            setattr(image_user, attr, value)
                            changed += 1
                        except Exception:
                            pass
                if bool(settings.smart_ifl_key_offset):
                    try:
                        image_user.keyframe_insert(data_path='frame_offset', frame=int(context.scene.frame_current))
                        keyed += 1
                    except Exception:
                        pass
        if changed == 0:
            self.report({'WARNING'}, sas_text("No image sequence users were found on the selected objects.", "選択オブジェクトに画像シーケンスユーザーが見つかりません。", context))
            return {'CANCELLED'}
        add_log(context, "INFO", f"Smart Image Sequence Manager updated {changed} image-user settings and keyed {keyed} offsets.", f"Smart Image Sequence Manager は {changed} 個の画像ユーザー設定を更新し、{keyed} 個のオフセットへキーを打ちました。")
        self.report({'INFO'}, sas_text(f"Updated {changed} image sequence setting(s).", f"{changed} 個の画像シーケンス設定を更新しました。", context))
        return {'FINISHED'}


class SAS_OT_smart_shape_control_mixer(Operator):
    bl_idname = "sas.smart_shape_control_mixer"
    bl_label = "Smart Shape Control Mixer"
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        name="Mode",
        description="Choose whether shape-key custom controls are created/refreshed or removed.",
        items=[
            ('CREATE', "Create / Refresh", "Create or refresh custom-property drivers for shape keys."),
            ('CLEAR', "Clear", "Remove Smart Shape Control drivers from shape keys."),
        ],
        default='CREATE',
        options={'SKIP_SAVE'},
    )

    @classmethod
    def description(cls, context, properties):
        mode = getattr(properties, 'mode', 'CREATE')
        if mode == 'CLEAR':
            return sas_text(
                "Remove Smart Shape Control drivers from the active mesh shape keys. Shape key values remain at their current evaluated values.",
                "アクティブメッシュのシェイプキーから Smart Shape Control ドライバーを削除します。シェイプキー値は現在の評価値のまま残ります。",
                context,
            )
        return sas_text(
            "Create OverMorpher/Dorito/Pose-Morph-style custom-property controls for every non-Basis shape key on the active mesh. The generated properties drive shape-key values and can be keyed like ordinary animation controls.",
            "アクティブメッシュの Basis 以外の各シェイプキーに、OverMorpher / Dorito / Pose Morph 風のカスタムプロパティ制御を作成します。生成されたプロパティはシェイプキー値を駆動し、通常のアニメーション制御と同じようにキーを打てます。",
            context,
        )

    def execute(self, context):
        obj = active_object(context)
        settings = _settings(context)
        if obj is None or getattr(obj, 'type', '') not in {'MESH', 'CURVE', 'SURFACE', 'LATTICE'}:
            self.report({'WARNING'}, sas_text("Select an object with shape keys.", "シェイプキーを持つオブジェクトを選択してください。", context))
            return {'CANCELLED'}
        keys = _iter_shape_keys(obj)
        if not keys:
            self.report({'WARNING'}, sas_text("The active object has no non-Basis shape keys.", "アクティブオブジェクトに Basis 以外のシェイプキーがありません。", context))
            return {'CANCELLED'}

        prefix = getattr(settings, 'smart_shape_control_prefix', 'SAS_Shape_') if settings else 'SAS_Shape_'
        if getattr(self, 'mode', 'CREATE') == 'CLEAR':
            cleared = 0
            for key in keys:
                try:
                    fcurve = _shape_key_driver_fcurve(key)
                    if fcurve is None or not _driver_uses_smart_shape_prefix(fcurve, obj, prefix):
                        continue
                    key.driver_remove('value')
                    obj.pop(_shape_driver_prop_name(prefix, key.name), None)
                    cleared += 1
                except Exception:
                    pass
            self.report({'INFO'}, _call_shape_control_report(context, 0, cleared))
            add_log(context, "INFO", f"Cleared {cleared} Smart Shape Control drivers.", f"{cleared} 個の Smart Shape Control ドライバーを解除しました。")
            return {'FINISHED'}

        created = 0
        skipped = 0
        for key in keys:
            prop_name = _shape_driver_prop_name(prefix, key.name)
            try:
                existing_driver = _shape_key_driver_fcurve(key)
                if existing_driver is not None and not _driver_uses_smart_shape_prefix(existing_driver, obj, prefix):
                    skipped += 1
                    continue
                obj[prop_name] = float(getattr(key, 'value', 0.0))
                try:
                    obj.id_properties_ui(prop_name).update(min=0.0, max=1.0, soft_min=0.0, soft_max=1.0, description=f"Smart Shape Control for {key.name}")
                except Exception:
                    pass
                if existing_driver is not None:
                    try:
                        key.driver_remove('value')
                    except Exception:
                        pass
                fcurve = key.driver_add('value')
                driver = fcurve.driver
                driver.type = 'SCRIPTED'
                driver.expression = 'var'
                while len(driver.variables):
                    driver.variables.remove(driver.variables[0])
                variable = driver.variables.new()
                variable.name = 'var'
                variable.type = 'SINGLE_PROP'
                variable.targets[0].id = obj
                variable.targets[0].data_path = f'["{prop_name}"]'
                if bool(getattr(settings, 'smart_shape_control_key_controls', False)):
                    try:
                        obj.keyframe_insert(data_path=f'["{prop_name}"]', frame=int(context.scene.frame_current))
                    except Exception:
                        pass
                created += 1
            except Exception:
                continue
        self.report({'INFO'}, _call_shape_control_report(context, created))
        add_log(context, "INFO", f"Created {created} Smart Shape Control drivers on {obj.name}; skipped {skipped} existing non-SAS drivers.", f"{obj.name} に {created} 個の Smart Shape Control ドライバーを作成し、既存の非SASドライバー {skipped} 個をスキップしました。")
        return {'FINISHED' if created else 'CANCELLED'}


class SAS_OT_smart_pose_assistant(Operator):
    bl_idname = "sas.smart_pose_assistant"
    bl_label = "Smart AutoPose Assistant"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Create a lightweight Cascadeur-style posing checkpoint by storing the current pose snapshot, inserting pose keys, and optionally mirroring or blending with existing snapshots through the existing pose tools.",
            "現在のポーズスナップショット保存とポーズキー挿入を行い、既存のポーズツールと連携してミラーやブレンドへ進められる、軽量な Cascadeur 風ポージングチェックポイントを作成します。",
            context,
        )

    def execute(self, context):
        if active_object(context) is None:
            self.report({'WARNING'}, sas_text("Select a posed object or armature first.", "先にポーズ済みオブジェクトまたはアーマチュアを選択してください。", context))
            return {'CANCELLED'}
        finished, failed = _run_ops(context, ['sas.store_pose_snapshot', 'sas.insert_keys'])
        if finished == 0:
            self.report({'WARNING'}, sas_text("AutoPose Assistant could not store or key the current pose.", "AutoPose Assistant は現在のポーズ保存またはキー挿入を実行できませんでした。", context))
            return {'CANCELLED'}
        add_log(context, "INFO", f"Smart AutoPose Assistant completed {finished} setup operation(s).", f"Smart AutoPose Assistant は {finished} 個のセットアップ操作を完了しました。")
        self.report({'INFO'}, sas_text("AutoPose checkpoint created.", "AutoPose チェックポイントを作成しました。", context))
        return {'FINISHED'}


class SAS_OT_smart_retarget_director(Operator):
    bl_idname = "sas.smart_retarget_director"
    bl_label = "Smart Retarget Director"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Run a Red9/KineFX/MotionBuilder-style retarget setup. It builds or refreshes the bone map, creates a live non-destructive retarget preview, and leaves baking to the dedicated bake command.",
            "Red9 / KineFX / MotionBuilder 風のリターゲット準備を実行します。ボーン対応表を作成または更新し、非破壊のライブリターゲットプレビューを作成します。最終ベイクは専用ベイクコマンドで行います。",
            context,
        )

    def execute(self, context):
        finished, failed = _run_ops(context, ['sas.build_bone_map', 'sas.build_live_retarget'])
        if finished == 0:
            self.report({'WARNING'}, sas_text("Retarget Director needs valid source and target armatures.", "Retarget Director には有効なソースとターゲットのアーマチュアが必要です。", context))
            return {'CANCELLED'}
        add_log(context, "INFO", f"Smart Retarget Director completed {finished} retarget operation(s); skipped {len(failed)}.", f"Smart Retarget Director は {finished} 個のリターゲット処理を完了し、{len(failed)} 個をスキップしました。")
        self.report({'INFO'}, sas_text("Retarget Director updated the preview setup.", "Retarget Director がプレビュー設定を更新しました。", context))
        return {'FINISHED'}


class SAS_OT_smart_stage_director(Operator):
    bl_idname = "sas.smart_stage_director"
    bl_label = "Smart Stage Director"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Run a context-aware studio workflow. It analyzes the current shot stage, active action, key density, Euler risks, spacing spikes, and quality gate, then launches the most suitable Animation Recipes pass.",
            "現在のショット段階、アクティブアクション、キー密度、オイラーリスク、スペーシングスパイク、品質ゲートを解析し、最適な アニメーション レシピ 処理を実行する文脈対応のスタジオワークフローです。",
            context,
        )

    def execute(self, context):
        settings = _settings(context)
        if settings is None:
            self.report({'WARNING'}, sas_text("Smart Animation settings are not available.", "Smart Animation 設定が利用できません。", context))
            return {'CANCELLED'}
        metrics = {}
        if bool(getattr(settings, 'smart_preflight_before_run', True)):
            try:
                metrics = _collect_smart_quality(context)
            except Exception:
                metrics = {}
        requested_stage = getattr(settings, 'smart_workflow_stage', 'AUTO')
        resolved_stage, ops = _stage_ops_for_context(context, requested_stage, metrics)
        if metrics and int(metrics.get('score', 100) if metrics.get('score', None) is not None else 100) < int(getattr(settings, 'smart_quality_gate_min_score', 85)) and 'sas.smart_quality_report' not in ops:
            ops.append('sas.smart_quality_report')
        finished, failed = _run_ops(context, ops)
        if finished == 0:
            self.report({'WARNING'}, sas_text("Smart Stage Director could not run in the current context. Check the selection, active action, and N-panel settings.", "現在のコンテキストでは Smart Stage Director を実行できませんでした。選択、アクティブアクション、Nパネル設定を確認してください。", context))
            return {'CANCELLED'}
        score_text = f" score {metrics.get('score', '-')}" if metrics else ""
        add_log(context, "INFO", f"Smart Stage Director resolved {requested_stage} to {resolved_stage} and ran {finished} operation(s); skipped {len(failed)};{score_text}.", f"Smart Stage Director は {requested_stage} を {resolved_stage} と判定し、{finished} 個の操作を実行、{len(failed)} 個をスキップしました。品質スコア: {metrics.get('score', '-') if metrics else '-'}。")
        self.report({'INFO'}, sas_text(f"Stage Director ran {finished} operation(s) for {resolved_stage}.", f"Stage Director は {resolved_stage} 用に {finished} 個の操作を実行しました。", context))
        return {'FINISHED'}


class SAS_OT_animation_recipe(Operator):
    bl_idname = "sas.animation_recipe"
    bl_label = "Run Animation Recipe"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, _properties):
        return sas_text(
            "Run the selected Animation Recipe. Recipes are upper-compatible Blender-native equivalents of the functions listed in the attached research document.",
            "選択中の アニメーション レシピを実行します。各レシピは、添付調査リストの機能を Blender 内で扱える上位互換相当としてまとめたものです。",
            context,
        )

    def execute(self, context):
        settings = _settings(context)
        recipe = getattr(settings, 'smart_recipe', 'REPORT') if settings else 'REPORT'
        recipe_ops = {
            'ANIMBOT': ['sas.smart_motion_director'],
            'GRAPHKIT': ['sas.smart_graph_optimizer'],
            'VISUALIZER': ['sas.smart_visualize_motion'],
            'PHYSICS': ['sas.smart_physics_director'],
            'LIMITED': ['sas.apply_stepped_preview', 'sas.bake_step_keys'],
            'OVERLAP': ['sas.apply_overlap_pass', 'sas.cascade_delay', 'sas.bake_spring_dynamics'],
            'POSE_LIBRARY': ['sas.store_pose_snapshot', 'sas.add_action_to_library'],
            'PICKER': ['sas.store_selection_set'],
            'DYNAMIC_PARENT': ['sas.dynamic_parent_switch'],
            'MOTION_MIXER': ['sas.push_action_to_nla', 'sas.sequence_library_actions'],
            'RETARGET': ['sas.smart_retarget_director'],
            'LOCOMOTION': ['sas.smart_generate_locomotion_cycle'],
            'SIGNAL': ['sas.apply_motion_signal', 'sas.apply_cycles_preset'],
            'TRANSFORM_REVEAL': ['sas.transform_reveal', 'sas.apply_deformer_reveal'],
            'CAMERA_STORY': ['sas.build_camera_sequence', 'sas.create_camera_review_split', 'sas.apply_camera_shake_preset'],
            'SHAPE_CONTROL': ['sas.smart_shape_control_mixer'],
            'IFL': ['sas.smart_ifl_sequence_manager'],
            'UNBAKE': ['sas.smart_unbake'],
            'PRECISION_POLISH': ['sas.smart_precision_polish'],
            'QUALITY_REPORT': ['sas.smart_quality_report'],
            'STAGE_DIRECTOR': ['sas.smart_stage_director'],
            'SUPER_DIRECTOR': ['sas.smart_superior_director'],
            'CONTACT_STABILIZER': ['sas.smart_contact_stabilizer'],
            'TIMING_INTENT': ['sas.smart_timing_intent_solver'],
            'REPORT': ['sas.smart_feature_coverage_report'],
        }
        ops = recipe_ops.get(recipe, ['sas.smart_feature_coverage_report'])
        finished, failed = _run_ops(context, ops)
        if finished == 0:
            self.report({'WARNING'}, sas_text("The selected recipe could not run in the current context. Check the selection and required settings.", "選択中のレシピは現在のコンテキストでは実行できませんでした。選択状態と必要設定を確認してください。", context))
            return {'CANCELLED'}
        add_log(context, "INFO", f"Animation Recipe {recipe} finished {finished} operation(s); skipped {len(failed)}.", f"アニメーション レシピ {recipe} は {finished} 個の操作を完了し、{len(failed)} 個をスキップしました。")
        self.report({'INFO'}, sas_text(f"Recipe finished with {finished} operation(s).", f"レシピで {finished} 個の操作を完了しました。", context))
        return {'FINISHED'}


OPERATOR_ANIMATION_RECIPES_CLASSES = (
    SAS_OT_smart_contact_stabilizer,
    SAS_OT_smart_timing_intent_solver,
    SAS_OT_smart_superior_director,
    SAS_OT_smart_quality_report,
    SAS_OT_smart_precision_polish,
    SAS_OT_smart_feature_coverage_report,
    SAS_OT_smart_graph_optimizer,
    SAS_OT_smart_motion_director,
    SAS_OT_smart_visualize_motion,
    SAS_OT_smart_physics_director,
    SAS_OT_smart_generate_locomotion_cycle,
    SAS_OT_smart_ifl_sequence_manager,
    SAS_OT_smart_shape_control_mixer,
    SAS_OT_smart_pose_assistant,
    SAS_OT_smart_retarget_director,
    SAS_OT_smart_stage_director,
    SAS_OT_animation_recipe,
)
