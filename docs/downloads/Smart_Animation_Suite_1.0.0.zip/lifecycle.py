# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Generation-scoped, exact-identity lifecycle ownership.

Every resource acquired by Smart Animation is recorded immediately together with
an exact remover.  Rollback and unregister walk only the current transaction's
records in reverse order.  No resource is identified only by a package string or
by looking up a same-named class on ``bpy.types``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Iterable
import sys
import types
import warnings

import bpy

_STATE_KEY = "SMART_ANIMATION_SUITE_LIFECYCLE_V1"
_BASE_RNA_IDENTIFIERS = {
    "Operator", "Panel", "PropertyGroup", "Menu", "UIList", "Gizmo",
    "GizmoGroup", "AddonPreferences", "RenderEngine", "Node", "NodeSocket",
}
_MISSING = object()
_MAX_WARNING_KEYS = 32

# Blender REPLACES ``bpy.app.driver_namespace`` with a fresh dict on EVERY file
# load (measured on 5.1.2 ec6e62d40fa9).  The generation record published there
# was the only reference to the live ``(current_generation, current_token)``
# pair, so once the user opened any .blend ``_driver_state()`` minted a zeroed
# record, ``is_current()`` was False for the live ledger forever, and
# ``loader.load_tool()`` refused every lazily loaded integrated tool with
# ``LifecycleError: no current Suite generation`` until Blender restarted.
#
# A synthetic ``sys.modules`` entry has process lifetime: it survives file loads
# and this package's own live-update submodule purge, which removes only
# ``<package>.`` keys.  Anchoring the exact state dict there keeps the live
# ``current_token`` sentinel reachable, so re-publishing it into a freshly
# replaced namespace restores identity comparison exactly rather than
# regenerating a token the live ledger would not match.  The anchor is scoped to
# this package alone and holds no foreign or user resource.
_ANCHOR_MODULE_NAME = "jelararagi_smart_animation_suite_lifecycle_anchor_v1"


class LifecycleError(RuntimeError):
    pass


def _new_state() -> dict[str, Any]:
    return {"next_generation": 0, "current_generation": 0, "current_token": None, "current_cleanup": None}


def _anchor_store() -> dict[str, Any]:
    module = sys.modules.get(_ANCHOR_MODULE_NAME)
    if not isinstance(module, types.ModuleType):
        module = types.ModuleType(_ANCHOR_MODULE_NAME)
        module.__doc__ = (
            "Smart Animation Suite lifecycle-state anchor.  Keeps the exact "
            "generation state dict reachable across Blender file loads, which "
            "replace bpy.app.driver_namespace.  Not an importable module."
        )
        module.SAS_LIFECYCLE_STATE = {}
        sys.modules[_ANCHOR_MODULE_NAME] = module
    store = getattr(module, "SAS_LIFECYCLE_STATE", None)
    if not isinstance(store, dict):
        store = {}
        module.SAS_LIFECYCLE_STATE = store
    return store


def _driver_state() -> dict[str, Any]:
    try:
        namespace = bpy.app.driver_namespace
        state = namespace.get(_STATE_KEY)
        if not isinstance(state, dict):
            # Missing here means either "never published" or "a file load
            # replaced the namespace".  Only the anchor can tell them apart, so
            # adopt the anchored record before minting a zeroed one.
            anchored = _anchor_store().get(_STATE_KEY)
            state = anchored if isinstance(anchored, dict) else _new_state()
            namespace[_STATE_KEY] = state
        # Keep the anchor pointing at the exact live record, including one
        # published by another generation of this package.
        _anchor_store()[_STATE_KEY] = state
        return state
    except Exception:
        # Headless static harnesses can provide a reduced bpy object.  The local
        # fallback remains process-scoped and has the same generation semantics.
        state = getattr(_driver_state, "_fallback", None)
        if not isinstance(state, dict):
            state = _new_state()
            setattr(_driver_state, "_fallback", state)
        return state


def _rna_identity(value: Any) -> tuple[str, int]:
    if value is None:
        return ("none", 0)
    try:
        return ("ptr", int(value.as_pointer()))
    except Exception:
        return ("id", id(value))


def rna_resource_pointer_identity(value: Any) -> tuple[str, int]:
    """Return a strict positive RNA pointer identity for owned resources.

    Iterating an RNA collection may create fresh Python wrappers, so ``id`` and
    ``is`` are not valid ownership identities.  Unlike the generic helper used
    for non-RNA values, this function deliberately has no fallback.
    """
    try:
        pointer = int(value.as_pointer())
    except Exception as exc:
        raise LifecycleError(f'RNA resource pointer is unavailable: {exc}') from exc
    if pointer <= 0:
        raise LifecycleError('RNA resource pointer is not positive')
    return ("ptr", pointer)


def class_registration_identity(cls: type) -> tuple[str, int] | None:
    """Return the class-owned RNA identity, never an inherited base identity."""
    try:
        rna = vars(cls).get("bl_rna")
    except Exception:
        rna = None
    if rna is None:
        return None
    try:
        identifier = str(getattr(rna, "identifier", "") or "")
    except Exception:
        identifier = ""
    if not identifier or identifier in _BASE_RNA_IDENTIFIERS:
        return None
    return _rna_identity(rna)


def class_is_registered_exact(cls: type, expected: tuple[str, int] | None = None) -> bool:
    identity = class_registration_identity(cls)
    if identity is None:
        return False
    return expected is None or identity == expected


def _rna_property(owner_type: Any, name: str) -> Any:
    try:
        properties = getattr(getattr(owner_type, "bl_rna", None), "properties", None)
        if properties is None:
            return None
        try:
            return properties.get(name)
        except Exception:
            return properties[name]
    except Exception:
        return None


def rna_property_identity(owner_type: Any, name: str) -> tuple[str, int] | None:
    prop = _rna_property(owner_type, name)
    return _rna_identity(prop) if prop is not None else None


def rna_fixed_type_identity(owner_type: Any, name: str) -> tuple[str, int] | None:
    prop = _rna_property(owner_type, name)
    try:
        fixed = getattr(prop, "fixed_type", None)
    except Exception:
        fixed = None
    return _rna_identity(fixed) if fixed is not None else None


@dataclass(slots=True)
class ResourceRecord:
    kind: str
    label: str
    identity: Any
    remover: Callable[[], None]
    verifier: Callable[[], bool] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    active: bool = True

    def verify(self) -> bool:
        if not self.active:
            return True
        if self.verifier is None:
            return True
        try:
            return bool(self.verifier())
        except Exception:
            return False

    def release(self) -> None:
        """Release once by the captured exact remover.

        The active flag is cleared only after a successful remover return.  A
        transient Blender teardown-order failure therefore remains retryable by
        the bounded second reverse pass in :meth:`GenerationLedger.rollback` and
        by a later exact generation cleanup.
        """
        if not self.active:
            return
        result = self.remover()
        if result is False:
            raise LifecycleError(f'exact remover returned False: {self.kind}:{self.label}')
        self.active = False


class GenerationLedger:
    """One exact-ownership transaction for one Suite or lazy tool generation."""

    def __init__(self, *, label: str, generation: int, token: object):
        self.label = str(label or "Smart Animation")
        self.generation = int(generation)
        self.token = token
        self.records: list[ResourceRecord] = []
        self.failures: list[str] = []
        self.committed = False
        self.released = False

    @classmethod
    def begin(cls, label: str = "Smart Animation Suite") -> "GenerationLedger":
        state = _driver_state()
        # A reloaded module cannot safely discover resources owned by the old
        # Python generation.  The previous generation therefore publishes one
        # captured exact-identity teardown callback.  Invoke only that callback;
        # never scan bpy.types/sys.modules or release by a package-name prefix.
        previous_cleanup = state.get("current_cleanup")
        deferred_cleanup = None
        if callable(previous_cleanup) and state.get("current_token") is not None:
            try:
                cleanup_result = previous_cleanup()
                if cleanup_result is False:
                    deferred_cleanup = previous_cleanup
            except Exception:
                # Preserve the exact captured callback for one later bounded retry.
                # The new generation never scans or adopts the old generation by
                # package/name, and normal acquisition will degrade on conflicts.
                deferred_cleanup = previous_cleanup
        generation = int(state.get("next_generation", 0) or 0) + 1
        token = object()
        state["next_generation"] = generation
        state["current_generation"] = generation
        state["current_token"] = token
        state["current_cleanup"] = None
        ledger = cls(label=label, generation=generation, token=token)
        if callable(deferred_cleanup):
            ledger.note_failure("previous exact generation cleanup deferred")
            ledger.record_callback(
                kind="prior_generation_cleanup",
                label="previous exact generation cleanup",
                identity=id(deferred_cleanup),
                remover=deferred_cleanup,
            )
        return ledger

    def child(self, label: str) -> "GenerationLedger":
        # Child ledgers share the generation/token but own only their own records.
        return GenerationLedger(label=label, generation=self.generation, token=self.token)

    def absorb(self, child: "GenerationLedger") -> None:
        """Transfer a successful child transaction into this generation."""
        if child is self:
            return
        if child.generation != self.generation or child.token is not self.token:
            raise LifecycleError(f"{self.label}: foreign child ledger")
        if child.released:
            raise LifecycleError(f"{self.label}: released child ledger")
        self.records.extend(child.records)
        self.failures.extend(child.failures)
        child.records.clear()
        child.released = True
        child.committed = False

    def add(self, record: ResourceRecord) -> ResourceRecord:
        if self.released:
            raise LifecycleError(f"{self.label}: cannot acquire after release")
        self.records.append(record)
        return record

    def note_failure(self, message: str) -> None:
        text = str(message or "registration failed")
        self.failures.append(text)

    def require(self, condition: bool, message: str) -> None:
        if not condition:
            self.note_failure(message)
            raise LifecycleError(message)

    def verify_all(self) -> bool:
        failed = [record.label for record in self.records if record.active and not record.verify()]
        if failed:
            self.failures.extend(f"identity verification failed: {label}" for label in failed)
            return False
        return not self.failures

    def commit(self) -> None:
        if not self.verify_all():
            raise LifecycleError("; ".join(self.failures[-8:]) or f"{self.label}: verification failed")
        self.committed = True

    def commit_degraded(self) -> bool:
        """Finalize every verified exact resource without raising.

        Register-time conflicts and restricted-context failures are recorded but
        never escape the add-on ``register()`` boundary. Any record whose exact
        verifier fails is released immediately, so the degraded generation owns
        only resources that can still be removed by exact identity.
        """
        invalid: list[ResourceRecord] = []
        for record in tuple(self.records):
            if record.active and not record.verify():
                invalid.append(record)
                self.note_failure(f"identity verification failed: {record.label}")
        for record in reversed(invalid):
            try:
                record.release()
            except Exception as exc:
                self.note_failure(f"invalid resource release failed: {record.kind}:{record.label}:{exc}")
        self.committed = True
        return not self.failures

    def rollback(self) -> None:
        """Release exact resources in reverse order with one bounded retry pass."""
        if self.released:
            return
        errors: list[str] = []
        # Some Blender RNA resources become removable only after a later class or
        # callback has been retired.  Two reverse passes are finite, deterministic,
        # and keep exact identity; no global scan or name-based cleanup is used.
        for _pass_index in range(2):
            pass_errors: list[str] = []
            for record in reversed(self.records):
                if not record.active:
                    continue
                try:
                    record.release()
                except Exception as exc:
                    pass_errors.append(f"{record.kind}:{record.label}:{exc}")
            errors = pass_errors
            if not any(record.active for record in self.records):
                break
        self.released = not any(record.active for record in self.records)
        self.committed = False
        if errors:
            self.failures.extend(errors)

    release = rollback

    def register_class(self, cls: type, *, required: bool = True) -> tuple[str, int] | None:
        existing = class_registration_identity(cls)
        if existing is not None:
            # Exact same Python class object and class-owned RNA identity: adopt it
            # once so the current generation still has an exact remover.
            if not any(record.kind == "class" and record.metadata.get("class") is cls for record in self.records):
                self.adopt_registered_class(cls, required=required)
            return existing
        try:
            result = bpy.utils.register_class(cls)
        except Exception as exc:
            self.note_failure(f"class register failed {getattr(cls, '__name__', cls)!s}: {exc}")
            if required:
                raise
            return None
        if result is False:
            message = f"class register returned False: {getattr(cls, '__name__', cls)!s}"
            self.note_failure(message)
            if required:
                raise LifecycleError(message)
            return None
        identity = class_registration_identity(cls)
        if identity is None:
            message = f"class has no class-owned RNA after registration: {getattr(cls, '__name__', cls)!s}"
            self.note_failure(message)
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
            if required:
                raise LifecycleError(message)
            return None

        def _verify(_cls=cls, _identity=identity):
            return class_is_registered_exact(_cls, _identity)

        def _remove(_cls=cls, _identity=identity):
            if class_is_registered_exact(_cls, _identity):
                bpy.utils.unregister_class(_cls)

        self.add(ResourceRecord(
            kind="class", label=f"{cls.__module__}.{cls.__name__}", identity=identity,
            remover=_remove, verifier=_verify,
            metadata={"class": cls, "generation": self.generation},
        ))
        return identity

    def adopt_registered_class(self, cls: type, *, required: bool = True) -> tuple[str, int] | None:
        identity = class_registration_identity(cls)
        if identity is None:
            if required:
                message = f"required class is not registered: {getattr(cls, '__name__', cls)!s}"
                self.note_failure(message)
                raise LifecycleError(message)
            return None
        if any(record.kind == "class" and record.metadata.get("class") is cls for record in self.records):
            return identity

        def _verify(_cls=cls, _identity=identity):
            return class_is_registered_exact(_cls, _identity)

        def _remove(_cls=cls, _identity=identity):
            if class_is_registered_exact(_cls, _identity):
                bpy.utils.unregister_class(_cls)

        self.add(ResourceRecord(
            kind="class", label=f"{cls.__module__}.{cls.__name__}", identity=identity,
            remover=_remove, verifier=_verify,
            metadata={"class": cls, "generation": self.generation, "adopted": True},
        ))
        return identity

    def set_rna_property(
        self, owner_type: Any, name: str, definition: Any, *, fixed_type: type | None = None,
        required: bool = True,
    ) -> Any:
        name = str(name or "").strip()
        if not name:
            raise LifecycleError("RNA property name is empty")
        before = _rna_property(owner_type, name)
        if before is not None:
            # Reuse only when the existing PointerProperty targets the exact same
            # currently registered class. Never replace an unknown/foreign RNA.
            if fixed_type is not None:
                current_fixed = getattr(before, "fixed_type", None)
                expected_rna = vars(fixed_type).get("bl_rna")
                if current_fixed is expected_rna:
                    self.adopt_rna_property(owner_type, name, fixed_type=fixed_type, required=required)
                    return before
            message = f"foreign/existing RNA property preserved: {getattr(owner_type, '__name__', owner_type)}.{name}"
            self.note_failure(message)
            if required:
                raise LifecycleError(message)
            return None
        try:
            setattr(owner_type, name, definition)
        except Exception as exc:
            self.note_failure(f"RNA register failed {getattr(owner_type, '__name__', owner_type)}.{name}: {exc}")
            if required:
                raise
            return None
        prop = _rna_property(owner_type, name)
        identity = _rna_identity(prop) if prop is not None else None
        if identity is None:
            try:
                delattr(owner_type, name)
            except Exception:
                pass
            message = f"RNA property missing after assignment: {getattr(owner_type, '__name__', owner_type)}.{name}"
            self.note_failure(message)
            if required:
                raise LifecycleError(message)
            return None
        expected_fixed_identity = None
        if fixed_type is not None:
            expected_rna = vars(fixed_type).get("bl_rna")
            expected_fixed_identity = _rna_identity(expected_rna) if expected_rna is not None else None
            actual_fixed = getattr(prop, "fixed_type", None)
            actual_fixed_identity = _rna_identity(actual_fixed) if actual_fixed is not None else None
            if expected_fixed_identity is None or actual_fixed_identity != expected_fixed_identity:
                try:
                    if rna_property_identity(owner_type, name) == identity:
                        delattr(owner_type, name)
                except Exception:
                    pass
                message = f"RNA fixed_type identity mismatch: {getattr(owner_type, '__name__', owner_type)}.{name}"
                self.note_failure(message)
                if required:
                    raise LifecycleError(message)
                return None

        def _verify(_owner=owner_type, _name=name, _identity=identity, _fixed=expected_fixed_identity):
            if rna_property_identity(_owner, _name) != _identity:
                return False
            return _fixed is None or rna_fixed_type_identity(_owner, _name) == _fixed

        def _remove(_owner=owner_type, _name=name, _identity=identity, _fixed=expected_fixed_identity):
            if rna_property_identity(_owner, _name) != _identity:
                return
            if _fixed is not None and rna_fixed_type_identity(_owner, _name) != _fixed:
                return
            delattr(_owner, _name)

        self.add(ResourceRecord(
            kind="rna", label=f"{getattr(owner_type, '__name__', owner_type)}.{name}",
            identity=identity, remover=_remove, verifier=_verify,
            metadata={"owner": owner_type, "name": name, "fixed_type_identity": expected_fixed_identity},
        ))
        return prop

    def adopt_rna_property(
        self, owner_type: Any, name: str, *, fixed_type: type | None = None,
        required: bool = True,
    ) -> Any:
        prop = _rna_property(owner_type, str(name or ""))
        if prop is None:
            message = f"required RNA property is missing: {getattr(owner_type, '__name__', owner_type)}.{name}"
            self.note_failure(message)
            if required:
                raise LifecycleError(message)
            return None
        identity = _rna_identity(prop)
        expected_fixed_identity = None
        if fixed_type is not None:
            expected = vars(fixed_type).get("bl_rna")
            expected_fixed_identity = _rna_identity(expected) if expected is not None else None
            actual = getattr(prop, "fixed_type", None)
            if expected_fixed_identity is None or _rna_identity(actual) != expected_fixed_identity:
                message = f"RNA fixed_type identity mismatch: {getattr(owner_type, '__name__', owner_type)}.{name}"
                self.note_failure(message)
                if required:
                    raise LifecycleError(message)
                return None
        for record in self.records:
            if record.kind == "rna" and record.metadata.get("owner") is owner_type and record.metadata.get("name") == name:
                return prop

        def _verify(_owner=owner_type, _name=name, _identity=identity, _fixed=expected_fixed_identity):
            if rna_property_identity(_owner, _name) != _identity:
                return False
            return _fixed is None or rna_fixed_type_identity(_owner, _name) == _fixed

        def _remove(_owner=owner_type, _name=name, _identity=identity, _fixed=expected_fixed_identity):
            if rna_property_identity(_owner, _name) != _identity:
                return
            if _fixed is not None and rna_fixed_type_identity(_owner, _name) != _fixed:
                return
            delattr(_owner, _name)

        self.add(ResourceRecord(
            kind="rna", label=f"{getattr(owner_type, '__name__', owner_type)}.{name}",
            identity=identity, remover=_remove, verifier=_verify,
            metadata={"owner": owner_type, "name": name, "fixed_type_identity": expected_fixed_identity, "adopted": True},
        ))
        return prop

    def append_handler(self, collection: Any, callback: Callable[..., Any], *, label: str = "") -> bool:
        try:
            already_present = any(item is callback for item in collection)
            if not already_present:
                collection.append(callback)
        except Exception as exc:
            self.note_failure(f"handler append failed {label or callback}: {exc}")
            raise
        if not any(item is callback for item in collection):
            message = f"handler identity missing after append: {label or callback}"
            self.note_failure(message)
            raise LifecycleError(message)

        def _verify(_collection=collection, _callback=callback):
            return any(item is _callback for item in _collection)

        def _remove(_collection=collection, _callback=callback):
            last_error = None
            for index in range(len(_collection) - 1, -1, -1):
                try:
                    if _collection[index] is _callback:
                        _collection.remove(_callback)
                except Exception as exc:
                    last_error = exc
            if any(item is _callback for item in _collection):
                detail = f': {last_error}' if last_error is not None else ''
                raise LifecycleError(f'exact handler identity remained after removal{detail}')

        if any(record.kind == "handler" and record.metadata.get("collection") is collection and record.metadata.get("callback") is callback for record in self.records):
            return True
        self.add(ResourceRecord(
            kind="handler", label=label or getattr(callback, "__name__", "handler"),
            identity=id(callback), remover=_remove, verifier=_verify,
            metadata={"collection": collection, "callback": callback},
        ))
        return True

    def register_timer(self, callback: Callable[..., Any], *, first_interval: float = 0.0, persistent: bool = False, label: str = "") -> bool:
        timers = bpy.app.timers
        already_registered = False
        try:
            already_registered = bool(timers.is_registered(callback))
            if not already_registered:
                result = timers.register(callback, first_interval=float(first_interval), persistent=bool(persistent))
                if result is False:
                    raise LifecycleError(f"timer register returned False: {label or callback}")
        except TypeError:
            if not already_registered:
                result = timers.register(callback, first_interval=float(first_interval))
                if result is False:
                    raise LifecycleError(f"timer register returned False: {label or callback}")
        if not timers.is_registered(callback):
            raise LifecycleError(f"timer missing after register: {label or callback}")

        if any(record.kind == "timer" and record.metadata.get("callback") is callback for record in self.records):
            return True
        def _verify(_callback=callback):
            return bool(timers.is_registered(_callback))

        def _remove(_callback=callback):
            if timers.is_registered(_callback):
                timers.unregister(_callback)

        self.add(ResourceRecord(
            kind="timer", label=label or getattr(callback, "__name__", "timer"),
            identity=id(callback), remover=_remove, verifier=_verify,
            metadata={"callback": callback},
        ))
        return True

    def subscribe_msgbus(self, *, owner: object, key: Any, args: tuple = (), notify: Callable[..., Any], options: set[str] | None = None, label: str = "") -> bool:
        kwargs = {"owner": owner, "key": key, "args": tuple(args), "notify": notify}
        if options:
            kwargs["options"] = set(options)
        result = bpy.msgbus.subscribe_rna(**kwargs)
        if result is False:
            raise LifecycleError(f"msgbus subscribe returned False: {label or notify}")

        def _remove(_owner=owner):
            return bpy.msgbus.clear_by_owner(_owner)

        self.add(ResourceRecord(
            kind="msgbus", label=label or getattr(notify, "__name__", "msgbus"),
            identity=id(owner), remover=_remove, verifier=None,
            metadata={"owner": owner, "key": key, "notify": notify},
        ))
        return True

    def record_draw_handler(self, *, space_type: Any, handle: Any, region_type: str, label: str = "") -> Any:
        if handle is None:
            raise LifecycleError(f"draw handler add returned None: {label}")

        def _remove(_space=space_type, _handle=handle, _region=region_type):
            _space.draw_handler_remove(_handle, _region)

        self.add(ResourceRecord(
            kind="draw_handler", label=label or str(space_type), identity=_rna_identity(handle),
            remover=_remove, verifier=None,
            metadata={"space_type": space_type, "handle": handle, "region_type": region_type},
        ))
        return handle

    def record_event_timer(self, *, window_manager: Any, timer: Any, label: str = "") -> Any:
        if timer is None:
            raise LifecycleError(f"event timer add returned None: {label}")

        def _remove(_wm=window_manager, _timer=timer):
            _wm.event_timer_remove(_timer)

        self.add(ResourceRecord(
            kind="event_timer", label=label or "event_timer", identity=_rna_identity(timer),
            remover=_remove, verifier=None, metadata={"timer": timer, "window_manager": window_manager},
        ))
        return timer

    def record_keymap_item(self, *, keymap: Any, item: Any, label: str = "") -> Any:
        if item is None:
            raise LifecycleError(f"keymap item add returned None: {label}")

        keymap_identity = rna_resource_pointer_identity(keymap)
        item_identity = rna_resource_pointer_identity(item)

        def _remove(
            _keymap=keymap,
            _keymap_identity=keymap_identity,
            _item_identity=item_identity,
        ):
            try:
                if rna_resource_pointer_identity(_keymap) != _keymap_identity:
                    raise LifecycleError('exact keymap identity changed before removal')
                matches = tuple(
                    candidate for candidate in _keymap.keymap_items
                    if rna_resource_pointer_identity(candidate) == _item_identity
                )
                if len(matches) > 1:
                    raise LifecycleError('duplicate exact keymap item identity')
                if matches:
                    _keymap.keymap_items.remove(matches[0])
            except Exception as exc:
                raise LifecycleError(f'exact keymap removal failed: {exc}') from exc
            if any(
                rna_resource_pointer_identity(candidate) == _item_identity
                for candidate in _keymap.keymap_items
            ):
                raise LifecycleError('exact keymap item remained after removal')

        self.add(ResourceRecord(
            kind="keymap", label=label or str(getattr(item, "idname", "keymap")),
            identity=(keymap_identity, item_identity), remover=_remove, verifier=None,
            metadata={
                "keymap": keymap, "item": item,
                "keymap_identity": keymap_identity, "item_identity": item_identity,
            },
        ))
        return item

    def record_module(
        self,
        name: str,
        module: Any,
        *,
        parent_module: Any = None,
        parent_attribute: str = "",
        parent_had_attribute: bool = False,
        parent_previous_attribute: Any = _MISSING,
    ) -> Any:
        name = str(name or "")
        if not name or module is None:
            raise LifecycleError("module identity is incomplete")
        parent_attribute = str(parent_attribute or "")
        if parent_had_attribute and parent_previous_attribute is _MISSING:
            raise LifecycleError("module parent binding snapshot is incomplete")

        def _verify(
            _name=name,
            _module=module,
        ):
            return sys.modules.get(_name) is _module

        def _remove(
            _name=name,
            _module=module,
            _parent=parent_module,
            _parent_attribute=parent_attribute,
            _parent_had_attribute=bool(parent_had_attribute),
            _parent_previous_attribute=parent_previous_attribute,
        ):
            current = sys.modules.get(_name, _MISSING)
            if current is _module:
                sys.modules.pop(_name, None)
            if _parent is None or not _parent_attribute:
                return
            current_attribute = vars(_parent).get(_parent_attribute, _MISSING)
            if current_attribute is _module:
                if _parent_had_attribute:
                    setattr(_parent, _parent_attribute, _parent_previous_attribute)
                else:
                    delattr(_parent, _parent_attribute)

        self.add(ResourceRecord(
            kind="module", label=name, identity=(name, id(module)), remover=_remove, verifier=_verify,
            metadata={
                "name": name,
                "module": module,
                "parent_module": parent_module,
                "parent_attribute": parent_attribute,
                "parent_had_attribute": bool(parent_had_attribute),
                "parent_previous_attribute": parent_previous_attribute,
            },
        ))
        return module

    def record_callback(self, *, kind: str, label: str, identity: Any, remover: Callable[[], None], verifier: Callable[[], bool] | None = None, metadata: dict[str, Any] | None = None) -> ResourceRecord:
        return self.add(ResourceRecord(
            kind=str(kind or "resource"), label=str(label or kind or "resource"),
            identity=identity, remover=remover, verifier=verifier,
            metadata=dict(metadata or {}),
        ))


def current_generation() -> int:
    try:
        return int(_driver_state().get("current_generation", 0) or 0)
    except Exception:
        return 0


def is_current(ledger: GenerationLedger | None) -> bool:
    if ledger is None:
        return False
    state = _driver_state()
    return int(state.get("current_generation", 0) or 0) == ledger.generation and state.get("current_token") is ledger.token


def publish_current_cleanup(ledger: GenerationLedger, cleanup: Callable[[], None]) -> None:
    state = _driver_state()
    if not is_current(ledger):
        raise LifecycleError("cannot publish cleanup for a stale generation")
    if not callable(cleanup):
        raise LifecycleError("cleanup callback is not callable")
    state["current_cleanup"] = cleanup


def publish_current_cleanup_soft(ledger: GenerationLedger, cleanup: Callable[[], None]) -> bool:
    """Publish the captured exact cleanup without leaking a register exception."""
    try:
        publish_current_cleanup(ledger, cleanup)
        return True
    except Exception as exc:
        try:
            ledger.note_failure(f"current cleanup publication failed: {exc}")
        except Exception:
            pass
        return False


def warn_once(tag: str, message: str) -> bool:
    """Emit one bounded, tagged warning for a degraded registration event."""
    tag_text = str(tag or "REGISTER_DEGRADED").strip().upper() or "REGISTER_DEGRADED"
    message_text = str(message or "registration completed in degraded mode").strip()
    key = f"{tag_text}:{message_text}"[:512]
    state = _driver_state()
    seen = state.get("warning_keys")
    if not isinstance(seen, list):
        seen = []
        state["warning_keys"] = seen
    if key in seen:
        return False
    seen.append(key)
    if len(seen) > _MAX_WARNING_KEYS:
        del seen[:-_MAX_WARNING_KEYS]
    try:
        warnings.warn(
            f"[Smart Animation Suite][{tag_text}] {message_text}",
            RuntimeWarning,
            stacklevel=2,
        )
    except Exception:
        pass
    return True


def current_state_snapshot() -> dict[str, Any]:
    state = _driver_state()
    return {
        "next_generation": int(state.get("next_generation", 0) or 0),
        "current_generation": int(state.get("current_generation", 0) or 0),
        "has_current_token": state.get("current_token") is not None,
        "has_current_cleanup": callable(state.get("current_cleanup")),
    }


def clear_current_if_owned(ledger: GenerationLedger | None) -> None:
    if ledger is None:
        return
    state = _driver_state()
    if int(state.get("current_generation", 0) or 0) == ledger.generation and state.get("current_token") is ledger.token:
        state["current_generation"] = 0
        state["current_token"] = None
        state["current_cleanup"] = None


def ensure_current_state() -> dict[str, Any]:
    """Best-effort re-publication of the anchored generation record.

    Reading the record re-publishes the anchored dict into a freshly replaced
    ``bpy.app.driver_namespace`` (see :func:`_driver_state`).  It never begins,
    adopts or retires a generation, touches no foreign resource, and never
    raises, so a user-work entry point can call it immediately before its own
    ownership check and can never be refused by namespace dormancy alone.
    """
    try:
        return _driver_state()
    except Exception:
        return {}


def _persistent(callback: Callable[..., Any]) -> Callable[..., Any]:
    """Mark *callback* persistent when Blender's handler API is available.

    A non-persistent ``load_post`` handler is dropped by the very file load it
    exists to survive.  Static harnesses provide a reduced ``bpy``; there the
    undecorated callable is returned and the handler is simply never appended.
    """
    try:
        return bpy.app.handlers.persistent(callback)
    except Exception:
        return callback


@_persistent
def _rearm_state_after_load(*_args) -> None:
    """Re-publish the anchored generation record after a file load.

    Acquired as the first record of the Suite generation, so it is journaled and
    released by the same exact rollback as every other resource.  Never raises:
    a persistent handler must not break foreign handlers or the user's load.
    """
    try:
        ensure_current_state()
    except Exception:
        pass
    try:
        from . import core
        core._sas_run_settings_load_post()
    except Exception:
        pass


def record_state_rearm_handler(ledger: GenerationLedger | None) -> bool:
    """Journal the ``load_post`` generation re-arm on *ledger*; never raises."""
    if ledger is None:
        return False
    try:
        handlers = bpy.app.handlers.load_post
    except Exception:
        return False
    try:
        return bool(ledger.append_handler(
            handlers, _rearm_state_after_load,
            label="lifecycle generation re-arm (load_post)",
        ))
    except Exception as exc:
        try:
            ledger.note_failure(f"lifecycle generation re-arm acquisition failed: {exc}")
        except Exception:
            pass
        return False
