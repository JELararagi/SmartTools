# ============================================================================
# Smart Animation
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
# ============================================================================

import bpy
from bpy.types import Operator

from . import registry
from .translation import sas_error_reason, sas_text


def _invoke_sas(self, context, op_name, **kwargs):
    try:
        operator = getattr(getattr(bpy.ops, "sas"), op_name)
    except AttributeError:
        self.report({'ERROR'}, sas_text(f"Operator sas.{op_name} is not available.", f"オペレーター sas.{op_name} が見つかりません。", context))
        return {'CANCELLED'}

    try:
        result = operator(**kwargs) if kwargs else operator()
        return result if isinstance(result, set) else {'FINISHED'}
    except Exception as exc:
        self.report({'ERROR'}, sas_text(f'The command failed: {exc}', f'操作の実行に失敗しました: {sas_error_reason(exc)}', context))
        return {'CANCELLED'}

def _invoke_integrated_overview_task(self, context, mode: str):
    alias = registry.overview_task_alias(mode)
    if not alias:
        self.report({'ERROR'}, sas_text("Integrated overview task is not recognized.", "概要タスクに移行した統合ツールを識別できません。", context))
        return {'CANCELLED'}
    try:
        operator = getattr(getattr(bpy.ops, "smart_animation_suite"), "integrated_overview_task")
    except AttributeError:
        self.report({'ERROR'}, sas_text("Integrated overview task runner is not available.", "概要タスク用の統合ツール実行機能が見つかりません。", context))
        return {'CANCELLED'}

    try:
        result = operator('INVOKE_DEFAULT', addon_alias=alias)
        return result if isinstance(result, set) else {'FINISHED'}
    except Exception as exc:
        self.report({'ERROR'}, sas_text(f"Integrated overview task failed: {exc}", f"概要タスクの統合ツール実行に失敗しました: {sas_error_reason(exc)}", context))
        return {'CANCELLED'}


TIMELINE_ACTIONS = {
    'NEW_ACTION': ('new_action', {}),
    'DUPLICATE_ACTION': ('duplicate_action', {}),
    'INSERT_KEYS': ('insert_keys', {'mode': 'ALL'}),
    'INSERT_LOC_KEYS': ('insert_keys', {'mode': 'LOC'}),
    'INSERT_ROT_KEYS': ('insert_keys', {'mode': 'ROT'}),
    'INSERT_SCALE_KEYS': ('insert_keys', {'mode': 'SCALE'}),
    'INSERT_VISUAL_KEYS': ('insert_keys', {'mode': 'VISUAL'}),
    'BAKE_VISUAL': ('bake_visual_keys', {}),
    'SHAPE_KEYS_ALL': ('insert_shape_key_keys', {'mode': 'ALL'}),
    'SHAPE_KEYS_ACTIVE': ('insert_shape_key_keys', {'mode': 'ACTIVE'}),
    'ADD_MARKER': ('add_marker', {}),
    'MARK_SELECTED_KEYS': ('mark_selected_keys', {}),
    'PREV_MARKER': ('jump_marker', {'direction': 'PREV'}),
    'NEXT_MARKER': ('jump_marker', {'direction': 'NEXT'}),
    'ADD_CAMERA_MARKER': ('add_camera_marker', {}),
    'PREV_CAMERA_MARKER': ('jump_camera_marker', {'direction': 'PREV'}),
    'NEXT_CAMERA_MARKER': ('jump_camera_marker', {'direction': 'NEXT'}),
    'PREVIEW_FROM_KEYS': ('set_preview_range_from_keys', {}),
    'PREVIEW_FROM_SOUND': ('set_preview_range_from_sound', {}),
    'PREVIEW_FROM_CURRENT_SHOT': ('set_preview_range_from_camera_markers', {'mode': 'CURRENT'}),
    'PREVIEW_FROM_ALL_SHOTS': ('set_preview_range_from_camera_markers', {'mode': 'ALL'}),
    'CLEAR_PREVIEW': ('clear_preview_range', {}),
    'PLAYBACK_BLOCKING': ('apply_playback_preset', {'preset': 'BLOCKING'}),
    'PLAYBACK_REVIEW': ('apply_playback_preset', {'preset': 'REVIEW'}),
    'PLAYBACK_LIPSYNC': ('apply_playback_preset', {'preset': 'LIPSYNC'}),
    'CAMERA_SEQUENCE': ('build_camera_sequence', {}),
    'CAMERA_REVIEW_SPLIT': ('create_camera_review_split', {}),
}

TIMING_ACTIONS = {
    'SHIFT': ('shift_keys', {}),
    'SCALE': ('scale_key_timing', {}),
    'EVEN': ('distribute_key_timing', {}),
    'TWEEN': ('apply_tween', {}),
    'PUSH_PULL': ('push_pull_keys', {}),
    'SCALE_TO_NEIGHBORS': ('scale_to_neighbors', {}),
    'CONTACT_HOLD': ('apply_contact_hold', {}),
    'STEPPED_PREVIEW': ('apply_stepped_preview', {}),
    'OVERLAP': ('apply_overlap_pass', {}),
    'CASCADE': ('cascade_delay', {}),
    'RANDOMIZE': ('randomize_key_timing', {}),
    'AUTO_FULCRUM': ('auto_fulcrum_cleanup', {}),
}

FX_APPLY_ACTIONS = {
    'LIMITED': ('bake_limited_animation', {}),
    'SPRING': ('bake_spring_dynamics', {}),
    'SPRING_MAGIC': ('bake_spring_magic', {}),
    'PHYSICS': ('bake_rigid_body_keys', {}),
    'SIGNAL': ('apply_motion_signal', {}),
    'STRETCH': ('apply_motion_stretch', {}),
    'VEHICLE': ('bake_vehicle_wheel_rotation', {}),
    'TRANSFORM_REVEAL': ('transform_reveal', {}),
    'REVEAL': ('apply_deformer_reveal', {}),
    'TRAIL': ('create_trail_curve', {}),
    'GHOST': ('create_ghost_preview', {}),
    'BALLISTIC_GUIDE': ('create_ballistic_guide', {}),
    'BALLISTIC_BAKE': ('bake_ballistic_keys', {}),
    'CAMERA_SHAKE': ('apply_camera_shake_preset', {}),
    'LOOP': ('apply_cycles_preset', {}),
    'NOISE': ('apply_noise_modifier', {}),
    'PATHS': ('calculate_motion_paths', {}),
    'DYNAMIC_PARENT': ('dynamic_parent_switch', {}),
    'COPY_GLOBAL': ('copy_global_transform', {}),
    'PASTE_GLOBAL': ('paste_global_transform', {}),
}

FX_CLEAR_ACTIONS = {
    'SIGNAL': ('clear_motion_signal', {}),
    'STRETCH': ('clear_motion_stretch', {}),
    'VEHICLE': ('clear_vehicle_wheel_rotation', {}),
    'REVEAL': ('clear_deformer_reveal', {}),
    'TRAIL': ('clear_trail_curves', {}),
    'GHOST': ('clear_ghost_preview', {}),
    'BALLISTIC_GUIDE': ('clear_ballistic_guides', {}),
    'BALLISTIC_BAKE': ('clear_ballistic_guides', {}),
    'CAMERA_SHAKE': ('clear_camera_shake', {}),
    'LOOP': ('clear_cycles_preset', {}),
    'NOISE': ('clear_noise_modifier', {}),
    'PATHS': ('clear_motion_paths', {}),
    'DYNAMIC_PARENT': ('clear_dynamic_parent', {}),
}

CLEANUP_ACTIONS = {
    'PREVIEW': ('preview_cleanup', {}),
    'SIMPLIFY': ('simplify_curves', {}),
    'SMOOTH': ('smooth_curves', {}),
    'REMOVE_DUPLICATES': ('remove_duplicate_keys', {}),
    'DELETE_STATIC': ('delete_static_channels', {}),
    'UNBAKE': ('smart_unbake', {}),
    'EULER': ('euler_filter', {}),
    'TANGENT': ('apply_tangent_preset', {}),
    'SHAPE_SMOOTH': ('smooth_shape_key_curves', {}),
    'SHAPE_OPTIMIZE': ('optimize_shape_key_curves', {}),
    'CLEAR_STEP': ('clear_stepped_preview', {}),
    'CLEAR_TRAILS': ('clear_trail_curves', {}),
    'CLEAR_GHOSTS': ('clear_ghost_preview', {}),
    'CLEAR_BALLISTICS': ('clear_ballistic_guides', {}),
    'CLEAR_SHAKE': ('clear_camera_shake', {}),
    'CLEAR_LOOP': ('clear_cycles_preset', {}),
    'CLEAR_NOISE': ('clear_noise_modifier', {}),
    'CLEAR_PATHS': ('clear_motion_paths', {}),
    'CLEAR_DYNAMIC_PARENT': ('clear_dynamic_parent', {}),
}

DATA_ACTIONS = {
    'POSE_EXPORT': ('export_pose_snapshots', {}),
    'POSE_IMPORT': ('import_pose_snapshots', {}),
    'SELECTION_EXPORT': ('export_selection_sets', {}),
    'SELECTION_IMPORT': ('import_selection_sets', {}),
    'LIBRARY_EXPORT': ('export_library_manifest', {}),
    'LIBRARY_IMPORT': ('import_library_manifest', {}),
    'LIBRARY_PRUNE': ('prune_action_library', {}),
    'MAP_EXPORT': ('export_bone_map', {}),
    'MAP_IMPORT': ('import_bone_map', {}),
}

TRANSFER_ACTIONS = {
    'BUILD_MAP': ('build_bone_map', {}),
    'LIVE_PREVIEW': ('build_live_retarget', {}),
    'APPLY_CURRENT_MAP': ('apply_live_retarget', {}),
    'REFRESH_PREVIEW': ('refresh_live_retarget', {}),
    'BAKE_TO_KEYS': ('bake_live_retarget', {}),
    'CLEAR_PREVIEW': ('clear_live_retarget', {}),
    'ROOT_MOTION': ('create_root_motion_action', {}),
    'IN_PLACE': ('create_in_place_action', {}),
}

DIAG_ACTIONS = {
    'ASSIST': ('smart_assist', {}),
    'AUTO_FIX': ('auto_fix_scene_basics', {}),
    'AUDIT': ('run_scene_audit', {}),
    'REPORT': ('export_report', {}),
    'CLEAR_LOG': ('clear_operation_log', {}),
}


class SAS_OT_run_compact_timeline(Operator):
    bl_idname = "sas.run_compact_timeline"
    bl_label = "Run Timeline Hub"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Run the currently selected timeline task from the compact hub.",
            "コンパクトハブで選択中のタイムライン作業を実行します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        op_name, kwargs = TIMELINE_ACTIONS.get(settings.compact_timeline_mode, ('new_action', {}))
        return _invoke_sas(self, context, op_name, **kwargs)


class SAS_OT_run_compact_timing(Operator):
    bl_idname = "sas.run_compact_timing"
    bl_label = "Run Timing Hub"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Run the currently selected timing or spacing task from the compact hub.",
            "コンパクトハブで選択中のタイミング / スペーシング作業を実行します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        op_name, kwargs = TIMING_ACTIONS.get(settings.compact_timing_mode, ('shift_keys', {}))
        return _invoke_sas(self, context, op_name, **kwargs)


class SAS_OT_run_compact_fx(Operator):
    bl_idname = "sas.run_compact_fx"
    bl_label = "Run FX Hub"
    bl_options = {'UNDO'}

    clear_mode: bpy.props.BoolProperty(
        name="Clear Existing",
        description="Run the matching clear/remove action for the current compact FX mode when available.",
        default=False,
        options={'SKIP_SAVE'},
    )

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Run the currently selected bake / procedural / helper motion task from the compact FX hub.",
            "コンパクト FX ハブで選択中のベイク / プロシージャル / 補助モーション作業を実行します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        mode = settings.compact_fx_mode
        if self.clear_mode:
            if mode not in FX_CLEAR_ACTIONS:
                self.report({'WARNING'}, sas_text("This FX mode has no dedicated clear action.", "この FX モードには専用の解除処理がありません。", context))
                return {'CANCELLED'}
            op_name, kwargs = FX_CLEAR_ACTIONS[mode]
        else:
            op_name, kwargs = FX_APPLY_ACTIONS.get(mode, ('bake_limited_animation', {}))
        return _invoke_sas(self, context, op_name, **kwargs)


class SAS_OT_run_compact_cleanup(Operator):
    bl_idname = "sas.run_compact_cleanup"
    bl_label = "Run Cleanup Hub"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Run the currently selected cleanup or curve-fix task from the compact hub.",
            "コンパクトハブで選択中の整理 / カーブ修正作業を実行します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        op_name, kwargs = CLEANUP_ACTIONS.get(settings.compact_cleanup_mode, ('preview_cleanup', {}))
        if op_name == 'apply_tangent_preset':
            kwargs = dict(kwargs, mode=settings.tangent_mode)
        return _invoke_sas(self, context, op_name, **kwargs)


class SAS_OT_run_compact_data(Operator):
    bl_idname = "sas.run_compact_data"
    bl_label = "Run Data I/O Hub"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Run the currently selected asset or retarget import/export task from the compact data hub.",
            "コンパクトデータハブで選択中のアセット / リターゲット入出力作業を実行します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        op_name, kwargs = DATA_ACTIONS.get(settings.compact_data_mode, ('export_pose_snapshots', {}))
        return _invoke_sas(self, context, op_name, **kwargs)


class SAS_OT_run_compact_transfer(Operator):
    bl_idname = "sas.run_compact_transfer"
    bl_label = "Run Transfer Hub"
    bl_options = {'UNDO'}

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Run the currently selected retarget or root-motion task from the compact transfer hub.",
            "コンパクト転送ハブで選択中のリターゲット / ルートモーション作業を実行します。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        op_name, kwargs = TRANSFER_ACTIONS.get(settings.compact_transfer_mode, ('build_bone_map', {}))
        return _invoke_sas(self, context, op_name, **kwargs)


class SAS_OT_run_compact_diagnostics(Operator):
    bl_idname = "sas.run_compact_diagnostics"
    bl_label = "Run Overview Task"
    bl_options = set()
    _sms_no_undo = True

    @classmethod
    def description(cls, context, properties):
        return sas_text(
            "Legacy command for the selected overview task. The N-panel now switches displayed tools immediately when the Overview Task dropdown changes.",
            "選択中の概要タスク用の互換コマンドです。現在は概要タスクのドロップダウン変更時に、Nパネル内の表示ツールが即時切り替わります。",
            context,
        )

    def execute(self, context):
        settings = context.scene.sas_settings
        mode = str(settings.compact_diag_mode or '')
        if mode.startswith('INT_TOOL_'):
            return _invoke_integrated_overview_task(self, context, mode)
        op_name, kwargs = DIAG_ACTIONS.get(mode, ('smart_assist', {}))
        return _invoke_sas(self, context, op_name, **kwargs)


OPERATOR_COMPACT_CLASSES = (
    SAS_OT_run_compact_timeline,
    SAS_OT_run_compact_timing,
    SAS_OT_run_compact_fx,
    SAS_OT_run_compact_cleanup,
    SAS_OT_run_compact_data,
    SAS_OT_run_compact_transfer,
    SAS_OT_run_compact_diagnostics,
)
