# SPDX-License-Identifier: GPL-3.0-or-later
"""Expose the curve overlay's native registration callbacks."""

from . import main


bl_info = dict(
    name="Bezier Curve Editor Overlay", author="JELararagi", version=(1, 0, 0),
    blender=(5, 1, 0), location="Dope Sheet > Sidebar", category="Animation",
    description="Bezier curve overlay editor for Timeline keyframe easing",
)
__all__ = ("register", "unregister")


def register():
    return main.register()


def unregister():
    return main.unregister()
